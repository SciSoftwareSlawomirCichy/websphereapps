package com.ibm.ISecurityUtilityImpl;

import org.omg.CORBA.UserException;

public class InvalidPasswordEncodingException extends UserException {
	private static final long serialVersionUID = 1868689009769673329L;
}