package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Sets.1;
import com.google.common.collect.Sets.2;
import com.google.common.collect.Sets.3;
import com.google.common.collect.Sets.CartesianSet;
import com.google.common.collect.Sets.FilteredNavigableSet;
import com.google.common.collect.Sets.FilteredSet;
import com.google.common.collect.Sets.FilteredSortedSet;
import com.google.common.collect.Sets.PowerSet;
import com.google.common.collect.Sets.SetFromMap;
import com.google.common.collect.Sets.SetView;
import com.google.common.collect.Sets.UnmodifiableNavigableSet;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
public final class Sets {
	@GwtCompatible(serializable = true)
	public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(E anElement, E... otherElements) {
		return ImmutableEnumSet.asImmutable(EnumSet.of(anElement, otherElements));
	}

	@GwtCompatible(serializable = true)
	public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(Iterable<E> elements) {
		if (elements instanceof ImmutableEnumSet) {
			return (ImmutableEnumSet) elements;
		} else if (elements instanceof Collection) {
			Collection<E> collection = (Collection) elements;
			return collection.isEmpty() ? ImmutableSet.of() : ImmutableEnumSet.asImmutable(EnumSet.copyOf(collection));
		} else {
			Iterator<E> itr = elements.iterator();
			if (itr.hasNext()) {
				EnumSet<E> enumSet = EnumSet.of((Enum) itr.next());
				Iterators.addAll(enumSet, itr);
				return ImmutableEnumSet.asImmutable(enumSet);
			} else {
				return ImmutableSet.of();
			}
		}
	}

	public static <E extends Enum<E>> EnumSet<E> newEnumSet(Iterable<E> iterable, Class<E> elementType) {
		EnumSet<E> set = EnumSet.noneOf(elementType);
		Iterables.addAll(set, iterable);
		return set;
	}

	public static <E> HashSet<E> newHashSet() {
		return new HashSet();
	}

	public static <E> HashSet<E> newHashSet(E... elements) {
		HashSet<E> set = newHashSetWithExpectedSize(elements.length);
		Collections.addAll(set, elements);
		return set;
	}

	public static <E> HashSet<E> newHashSetWithExpectedSize(int expectedSize) {
		return new HashSet(Maps.capacity(expectedSize));
	}

	public static <E> HashSet<E> newHashSet(Iterable<? extends E> elements) {
		return elements instanceof Collection
				? new HashSet(Collections2.cast(elements))
				: newHashSet(elements.iterator());
	}

	public static <E> HashSet<E> newHashSet(Iterator<? extends E> elements) {
		HashSet set = newHashSet();

		while (elements.hasNext()) {
			set.add(elements.next());
		}

		return set;
	}

	public static <E> LinkedHashSet<E> newLinkedHashSet() {
		return new LinkedHashSet();
	}

	public static <E> LinkedHashSet<E> newLinkedHashSetWithExpectedSize(int expectedSize) {
		return new LinkedHashSet(Maps.capacity(expectedSize));
	}

	public static <E> LinkedHashSet<E> newLinkedHashSet(Iterable<? extends E> elements) {
		if (elements instanceof Collection) {
			return new LinkedHashSet(Collections2.cast(elements));
		} else {
			LinkedHashSet<E> set = newLinkedHashSet();
			Iterator i$ = elements.iterator();

			while (i$.hasNext()) {
				E element = i$.next();
				set.add(element);
			}

			return set;
		}
	}

	public static <E extends Comparable> TreeSet<E> newTreeSet() {
		return new TreeSet();
	}

	public static <E extends Comparable> TreeSet<E> newTreeSet(Iterable<? extends E> elements) {
		TreeSet<E> set = newTreeSet();
		Iterator i$ = elements.iterator();

		while (i$.hasNext()) {
			E element = (Comparable) i$.next();
			set.add(element);
		}

		return set;
	}

	public static <E> TreeSet<E> newTreeSet(Comparator<? super E> comparator) {
		return new TreeSet((Comparator) Preconditions.checkNotNull(comparator));
	}

	public static <E> Set<E> newIdentityHashSet() {
		return newSetFromMap(Maps.newIdentityHashMap());
	}

	@GwtIncompatible("CopyOnWriteArraySet")
	public static <E> CopyOnWriteArraySet<E> newCopyOnWriteArraySet() {
		return new CopyOnWriteArraySet();
	}

	@GwtIncompatible("CopyOnWriteArraySet")
	public static <E> CopyOnWriteArraySet<E> newCopyOnWriteArraySet(Iterable<? extends E> elements) {
		Collection<? extends E> elementsCollection = elements instanceof Collection
				? Collections2.cast(elements)
				: Lists.newArrayList(elements);
		return new CopyOnWriteArraySet((Collection) elementsCollection);
	}

	public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection) {
		if (collection instanceof EnumSet) {
			return EnumSet.complementOf((EnumSet) collection);
		} else {
			Preconditions.checkArgument(!collection.isEmpty(),
					"collection is empty; use the other version of this method");
			Class<E> type = ((Enum) collection.iterator().next()).getDeclaringClass();
			return makeComplementByHand(collection, type);
		}
	}

	public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection, Class<E> type) {
		Preconditions.checkNotNull(collection);
		return collection instanceof EnumSet
				? EnumSet.complementOf((EnumSet) collection)
				: makeComplementByHand(collection, type);
	}

	private static <E extends Enum<E>> EnumSet<E> makeComplementByHand(Collection<E> collection, Class<E> type) {
		EnumSet<E> result = EnumSet.allOf(type);
		result.removeAll(collection);
		return result;
	}

	public static <E> Set<E> newSetFromMap(Map<E, Boolean> map) {
		return new SetFromMap(map);
	}

	public static <E> SetView<E> union(Set<? extends E> set1, Set<? extends E> set2) {
      Preconditions.checkNotNull(set1, "set1");
      Preconditions.checkNotNull(set2, "set2");
      Set<? extends E> set2minus1 = difference(set2, set1);
      return new 1(set1, set2minus1, set2);
   }

	public static <E> SetView<E> intersection(Set<E> set1, Set<?> set2) {
      Preconditions.checkNotNull(set1, "set1");
      Preconditions.checkNotNull(set2, "set2");
      Predicate<Object> inSet2 = Predicates.in(set2);
      return new 2(set1, inSet2, set2);
   }

	public static <E> SetView<E> difference(Set<E> set1, Set<?> set2) {
      Preconditions.checkNotNull(set1, "set1");
      Preconditions.checkNotNull(set2, "set2");
      Predicate<Object> notInSet2 = Predicates.not(Predicates.in(set2));
      return new 3(set1, notInSet2, set2);
   }

	public static <E> SetView<E> symmetricDifference(Set<? extends E> set1, Set<? extends E> set2) {
		Preconditions.checkNotNull(set1, "set1");
		Preconditions.checkNotNull(set2, "set2");
		return difference(union(set1, set2), intersection(set1, set2));
	}

	public static <E> Set<E> filter(Set<E> unfiltered, Predicate<? super E> predicate) {
		if (unfiltered instanceof SortedSet) {
			return filter((SortedSet) unfiltered, predicate);
		} else if (unfiltered instanceof FilteredSet) {
			FilteredSet<E> filtered = (FilteredSet) unfiltered;
			Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
			return new FilteredSet((Set) filtered.unfiltered, combinedPredicate);
		} else {
			return new FilteredSet((Set) Preconditions.checkNotNull(unfiltered),
					(Predicate) Preconditions.checkNotNull(predicate));
		}
	}

	public static <E> SortedSet<E> filter(SortedSet<E> unfiltered, Predicate<? super E> predicate) {
		return Platform.setsFilterSortedSet(unfiltered, predicate);
	}

	static <E> SortedSet<E> filterSortedIgnoreNavigable(SortedSet<E> unfiltered, Predicate<? super E> predicate) {
		if (unfiltered instanceof FilteredSet) {
			FilteredSet<E> filtered = (FilteredSet) unfiltered;
			Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
			return new FilteredSortedSet((SortedSet) filtered.unfiltered, combinedPredicate);
		} else {
			return new FilteredSortedSet((SortedSet) Preconditions.checkNotNull(unfiltered),
					(Predicate) Preconditions.checkNotNull(predicate));
		}
	}

	@GwtIncompatible("NavigableSet")
	public static <E> NavigableSet<E> filter(NavigableSet<E> unfiltered, Predicate<? super E> predicate) {
		if (unfiltered instanceof FilteredSet) {
			FilteredSet<E> filtered = (FilteredSet) unfiltered;
			Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
			return new FilteredNavigableSet((NavigableSet) filtered.unfiltered, combinedPredicate);
		} else {
			return new FilteredNavigableSet((NavigableSet) Preconditions.checkNotNull(unfiltered),
					(Predicate) Preconditions.checkNotNull(predicate));
		}
	}

	public static <B> Set<List<B>> cartesianProduct(List<? extends Set<? extends B>> sets) {
		Iterator i$ = sets.iterator();

		Set set;
		do {
			if (!i$.hasNext()) {
				return CartesianSet.create(sets);
			}

			set = (Set) i$.next();
		} while (!set.isEmpty());

		return ImmutableSet.of();
	}

	public static <B> Set<List<B>> cartesianProduct(Set... sets) {
		return cartesianProduct(Arrays.asList(sets));
	}

	@GwtCompatible(serializable = false)
	public static <E> Set<Set<E>> powerSet(Set<E> set) {
		ImmutableSet<E> input = ImmutableSet.copyOf(set);
		Preconditions.checkArgument(input.size() <= 30, "Too many elements to create power set: %s > 30",
				new Object[]{input.size()});
		return new PowerSet(input);
	}

	static int hashCodeImpl(Set<?> s) {
		int hashCode = 0;

		for (Iterator i$ = s.iterator(); i$.hasNext(); hashCode = ~(~hashCode)) {
			Object o = i$.next();
			hashCode += o != null ? o.hashCode() : 0;
		}

		return hashCode;
	}

	static boolean equalsImpl(Set<?> s, @Nullable Object object) {
		if (s == object) {
			return true;
		} else if (object instanceof Set) {
			Set o = (Set) object;

			try {
				return s.size() == o.size() && s.containsAll(o);
			} catch (NullPointerException var4) {
				return false;
			} catch (ClassCastException var5) {
				return false;
			}
		} else {
			return false;
		}
	}

	@GwtIncompatible("NavigableSet")
	public static <E> NavigableSet<E> unmodifiableNavigableSet(NavigableSet<E> set) {
		return (NavigableSet) (!(set instanceof ImmutableSortedSet) && !(set instanceof UnmodifiableNavigableSet)
				? new UnmodifiableNavigableSet(set)
				: set);
	}

	@GwtIncompatible("NavigableSet")
	public static <E> NavigableSet<E> synchronizedNavigableSet(NavigableSet<E> navigableSet) {
		return Synchronized.navigableSet(navigableSet);
	}

	static boolean removeAllImpl(Set<?> set, Iterator<?> iterator) {
		boolean changed;
		for (changed = false; iterator.hasNext(); changed |= set.remove(iterator.next())) {
			;
		}

		return changed;
	}

	static boolean removeAllImpl(Set<?> set, Collection<?> collection) {
		Preconditions.checkNotNull(collection);
		if (collection instanceof Multiset) {
			collection = ((Multiset) collection).elementSet();
		}

		if (collection instanceof Set && ((Collection) collection).size() > set.size()) {
			Iterator<?> setIterator = set.iterator();
			boolean changed = false;

			while (setIterator.hasNext()) {
				if (((Collection) collection).contains(setIterator.next())) {
					changed = true;
					setIterator.remove();
				}
			}

			return changed;
		} else {
			return removeAllImpl(set, ((Collection) collection).iterator());
		}
	}

	static <T> SortedSet<T> cast(Iterable<T> iterable) {
		return (SortedSet) iterable;
	}
}