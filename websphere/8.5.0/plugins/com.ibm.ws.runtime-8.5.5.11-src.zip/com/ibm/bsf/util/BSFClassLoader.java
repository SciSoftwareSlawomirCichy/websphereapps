package com.ibm.bsf.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.Hashtable;

class BSFClassLoader extends ClassLoader {
	Hashtable cache = new Hashtable();
	String tempDir = ".";

	public synchronized Class loadClass(String var1, boolean var2) throws ClassNotFoundException {
		Class var3 = (Class) this.cache.get(var1);
		if (var3 == null) {
			try {
				var3 = this.findSystemClass(var1);
				this.cache.put(var1, var3);
				return var3;
			} catch (ClassNotFoundException var6) {
				try {
					byte[] var4 = this.loadClassData(var1);
					var3 = this.defineClass(var1, var4, 0, var4.length);
					this.cache.put(var1, var3);
				} catch (Exception var5) {
					var5.printStackTrace();
					throw new ClassNotFoundException("unable to resolve class '" + var1 + "'");
				}
			}
		}

		if (var2) {
			this.resolveClass(var3);
		}

		return var3;
	}

	private byte[] loadClassData(String var1) throws Exception {
		String var2 = this.tempDir + File.separatorChar + var1 + ".class";
		FileInputStream var3 = new FileInputStream(var2);
		byte[] var4 = new byte[var3.available()];
		var3.read(var4);
		var3.close();
		return var4;
	}

	public void setTempDir(String var1) {
		this.tempDir = var1;
	}
}