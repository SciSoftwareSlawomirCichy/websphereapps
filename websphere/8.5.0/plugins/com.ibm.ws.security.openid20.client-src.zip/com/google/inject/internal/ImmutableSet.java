package com.google.inject.internal;

import com.google.inject.internal.ImmutableSet.1;
import com.google.inject.internal.ImmutableSet.Builder;
import com.google.inject.internal.ImmutableSet.SerializedForm;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public abstract class ImmutableSet<E> extends ImmutableCollection<E> implements Set<E> {
	private static final ImmutableSet<?> EMPTY_IMMUTABLE_SET = new ImmutableSet.EmptyImmutableSet((1)null);

	public static <E> ImmutableSet<E> of() {
		return EMPTY_IMMUTABLE_SET;
	}

	public static <E> ImmutableSet<E> of(E element) {
		return new ImmutableSet.SingletonImmutableSet(element, element.hashCode());
	}

	public static <E> ImmutableSet<E> of(E... elements) {
		switch (elements.length) {
			case 0 :
				return of();
			case 1 :
				return of(elements[0]);
			default :
				return create(Arrays.asList(elements), elements.length);
		}
	}

	public static <E> ImmutableSet<E> copyOf(Iterable<? extends E> elements) {
		if (elements instanceof ImmutableSet) {
			ImmutableSet<E> set = (ImmutableSet) elements;
			return set;
		} else {
			return copyOfInternal(Collections2.toCollection(elements));
		}
	}

	public static <E> ImmutableSet<E> copyOf(Iterator<? extends E> elements) {
		Collection<E> list = Lists.newArrayList(elements);
		return copyOfInternal(list);
	}

	private static <E> ImmutableSet<E> copyOfInternal(Collection<? extends E> collection) {
		switch (collection.size()) {
			case 0 :
				return of();
			case 1 :
				return of(collection.iterator().next());
			default :
				return create(collection, collection.size());
		}
	}

	boolean isHashCodeFast() {
		return false;
	}

	public boolean equals(@Nullable Object object) {
		if (object == this) {
			return true;
		} else {
			return object instanceof ImmutableSet && this.isHashCodeFast() && ((ImmutableSet) object).isHashCodeFast()
					&& this.hashCode() != object.hashCode() ? false : Collections2.setEquals(this, object);
		}
	}

	public int hashCode() {
		int hashCode = 0;

		Object o;
		for (Iterator i$ = this.iterator(); i$.hasNext(); hashCode += o.hashCode()) {
			o = i$.next();
		}

		return hashCode;
	}

	public abstract UnmodifiableIterator<E> iterator();

	public String toString() {
		if (this.isEmpty()) {
			return "[]";
		} else {
			Iterator<E> iterator = this.iterator();
			StringBuilder result = new StringBuilder(this.size() * 16);
			result.append('[').append(iterator.next().toString());

			for (int i = 1; i < this.size(); ++i) {
				result.append(", ").append(iterator.next().toString());
			}

			return result.append(']').toString();
		}
	}

	private static <E> ImmutableSet<E> create(Iterable<? extends E> iterable, int count) {
		int tableSize = Hashing.chooseTableSize(count);
		Object[] table = new Object[tableSize];
		int mask = tableSize - 1;
		List<E> elements = new ArrayList(count);
		int hashCode = 0;
		Iterator i$ = iterable.iterator();

		while (true) {
			while (i$.hasNext()) {
				E element = i$.next();
				int hash = element.hashCode();
				int i = Hashing.smear(hash);

				while (true) {
					int index = i & mask;
					Object value = table[index];
					if (value == null) {
						table[index] = element;
						elements.add(element);
						hashCode += hash;
						break;
					}

					if (value.equals(element)) {
						break;
					}

					++i;
				}
			}

			return (ImmutableSet) (elements.size() == 1
					? new ImmutableSet.SingletonImmutableSet(elements.get(0), hashCode)
					: new ImmutableSet.RegularImmutableSet(elements.toArray(), hashCode, table, mask));
		}
	}

	Object writeReplace() {
		return new SerializedForm(this.toArray());
	}

	public static <E> Builder<E> builder() {
		return new Builder();
	}

	abstract static class TransformedImmutableSet<D, E> extends ImmutableSet<E> {
		final D[] source;
		final int hashCode;

		TransformedImmutableSet(D[] source, int hashCode) {
			this.source = source;
			this.hashCode = hashCode;
		}

		abstract E transform(D var1);

		public int size() {
			return this.source.length;
		}

		public boolean isEmpty() {
			return false;
		}

		public UnmodifiableIterator<E> iterator() {
         Iterator<E> iterator = new com.google.inject.internal.ImmutableSet.TransformedImmutableSet.1(this);
         return Iterators.unmodifiableIterator(iterator);
      }

		public Object[] toArray() {
			return this.toArray(new Object[this.size()]);
		}

		public <T> T[] toArray(T[] array) {
			int size = this.size();
			if (array.length < size) {
				array = ObjectArrays.newArray(array, size);
			} else if (array.length > size) {
				array[size] = null;
			}

			for (int i = 0; i < this.source.length; ++i) {
				array[i] = this.transform(this.source[i]);
			}

			return array;
		}

		public final int hashCode() {
			return this.hashCode;
		}

		boolean isHashCodeFast() {
			return true;
		}
	}

	private static final class RegularImmutableSet<E> extends ImmutableSet.ArrayImmutableSet<E> {
		final Object[] table;
		final int mask;
		final int hashCode;

		RegularImmutableSet(Object[] elements, int hashCode, Object[] table, int mask) {
			super(elements);
			this.table = table;
			this.mask = mask;
			this.hashCode = hashCode;
		}

		public boolean contains(Object target) {
			if (target == null) {
				return false;
			} else {
				int i = Hashing.smear(target.hashCode());

				while (true) {
					Object candidate = this.table[i & this.mask];
					if (candidate == null) {
						return false;
					}

					if (candidate.equals(target)) {
						return true;
					}

					++i;
				}
			}
		}

		public int hashCode() {
			return this.hashCode;
		}

		boolean isHashCodeFast() {
			return true;
		}
	}

	abstract static class ArrayImmutableSet<E> extends ImmutableSet<E> {
		final Object[] elements;

		ArrayImmutableSet(Object[] elements) {
			this.elements = elements;
		}

		public int size() {
			return this.elements.length;
		}

		public boolean isEmpty() {
			return false;
		}

		public UnmodifiableIterator<E> iterator() {
			return Iterators.forArray(this.elements);
		}

		public Object[] toArray() {
			Object[] array = new Object[this.size()];
			System.arraycopy(this.elements, 0, array, 0, this.size());
			return array;
		}

		public <T> T[] toArray(T[] array) {
			int size = this.size();
			if (array.length < size) {
				array = ObjectArrays.newArray(array, size);
			} else if (array.length > size) {
				array[size] = null;
			}

			System.arraycopy(this.elements, 0, array, 0, size);
			return array;
		}

		public boolean containsAll(Collection<?> targets) {
			if (targets == this) {
				return true;
			} else if (!(targets instanceof ImmutableSet.ArrayImmutableSet)) {
				return super.containsAll(targets);
			} else if (targets.size() > this.size()) {
				return false;
			} else {
				Object[] arr$ = ((ImmutableSet.ArrayImmutableSet) targets).elements;
				int len$ = arr$.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					Object target = arr$[i$];
					if (!this.contains(target)) {
						return false;
					}
				}

				return true;
			}
		}
	}

	private static final class SingletonImmutableSet<E> extends ImmutableSet<E> {
		final E element;
		final int hashCode;

		SingletonImmutableSet(E element, int hashCode) {
			this.element = element;
			this.hashCode = hashCode;
		}

		public int size() {
			return 1;
		}

		public boolean isEmpty() {
			return false;
		}

		public boolean contains(Object target) {
			return this.element.equals(target);
		}

		public UnmodifiableIterator<E> iterator() {
			return Iterators.singletonIterator(this.element);
		}

		public Object[] toArray() {
			return new Object[]{this.element};
		}

		public <T> T[] toArray(T[] array) {
			if (array.length == 0) {
				array = ObjectArrays.newArray(array, 1);
			} else if (array.length > 1) {
				array[1] = null;
			}

			array[0] = this.element;
			return array;
		}

		public boolean equals(@Nullable Object object) {
			if (object == this) {
				return true;
			} else if (!(object instanceof Set)) {
				return false;
			} else {
				Set<?> that = (Set) object;
				return that.size() == 1 && this.element.equals(that.iterator().next());
			}
		}

		public final int hashCode() {
			return this.hashCode;
		}

		boolean isHashCodeFast() {
			return true;
		}

		public String toString() {
			String elementToString = this.element.toString();
			return (new StringBuilder(elementToString.length() + 2)).append('[').append(elementToString).append(']')
					.toString();
		}
	}

	private static final class EmptyImmutableSet extends ImmutableSet<Object> {
		private static final Object[] EMPTY_ARRAY = new Object[0];

		private EmptyImmutableSet() {
		}

		public int size() {
			return 0;
		}

		public boolean isEmpty() {
			return true;
		}

		public boolean contains(Object target) {
			return false;
		}

		public UnmodifiableIterator<Object> iterator() {
			return Iterators.emptyIterator();
		}

		public Object[] toArray() {
			return EMPTY_ARRAY;
		}

		public <T> T[] toArray(T[] a) {
			if (a.length > 0) {
				a[0] = null;
			}

			return a;
		}

		public boolean containsAll(Collection<?> targets) {
			return targets.isEmpty();
		}

		public boolean equals(@Nullable Object object) {
			if (object instanceof Set) {
				Set<?> that = (Set) object;
				return that.isEmpty();
			} else {
				return false;
			}
		}

		public final int hashCode() {
			return 0;
		}

		boolean isHashCodeFast() {
			return true;
		}

		public String toString() {
			return "[]";
		}
	}
}