package com.ibm.ws.wim.registry.dataobject;

import com.ibm.ws.wim.registry.WIMUserRegistryDefines;

public class IDAndRealm implements WIMUserRegistryDefines {
	public static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String id = "";
	private String delimiter = "";
	private String realm = "";
	private boolean realmDefined = false;

	public IDAndRealm() {
		String var1 = "IDAndRealm";
	}

	public IDAndRealm(String var1, String var2) {
		String var3 = "IDAndRealm(String, String)";
		this.setId(var1);
		this.setRealm(var2);
	}

	public String getId() {
		return this.id;
	}

	public void setId(String var1) {
		if (var1 != null && !var1.equals("")) {
			this.id = var1;
		}

	}

	public String getRealm() {
		return this.realm;
	}

	public void setRealm(String var1) {
		if (var1 != null && !var1.equals("")) {
			this.realm = var1;
			this.setRealmDefined(true);
		}

	}

	public boolean isRealmDefined() {
		return this.realmDefined;
	}

	private void setRealmDefined(boolean var1) {
		this.realmDefined = var1;
	}

	public String getDelimiter() {
		return this.delimiter;
	}

	public void setDelimiter(String var1) {
		if (var1 != null && !var1.equals("")) {
			this.delimiter = var1;
		}

	}

	public String toString() {
		String var1 = "toString";
		StringBuffer var2 = new StringBuffer();
		var2.append(IDAndRealm.class.getName());
		var2.append(" ID = \"" + this.getId() + "\"");
		var2.append(" Realm = \"" + this.getRealm() + "\"");
		var2.append(" isRealmDefined = \"" + this.isRealmDefined() + "\"");
		return var2.toString();
	}

	public boolean equals(Object var1) {
		String var2 = "equals";
		boolean var3 = false;
		if (var1 != null && var1 instanceof IDAndRealm) {
			if (this.getId().equals(((IDAndRealm) var1).getId())
					&& this.getRealm().equals(((IDAndRealm) var1).getRealm())
					&& this.isRealmDefined() == ((IDAndRealm) var1).isRealmDefined()) {
				var3 = true;
			} else {
				var3 = false;
			}
		} else {
			var3 = false;
		}

		return var3;
	}

	public int hashCode() {
		String var1 = "hashCode";
		byte var2 = 0;
		int var3 = var2 + this.getId().hashCode();
		var3 += this.getRealm().hashCode();
		var3 += Boolean.valueOf(this.isRealmDefined()).hashCode();
		return var3;
	}
}