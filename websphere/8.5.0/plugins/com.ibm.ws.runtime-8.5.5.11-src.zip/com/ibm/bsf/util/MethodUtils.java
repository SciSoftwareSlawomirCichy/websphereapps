package com.ibm.bsf.util;

import com.ibm.bsf.util.MethodUtils.1;
import com.ibm.bsf.util.MethodUtils.MoreSpecific;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class MethodUtils {
	private static boolean areMethodConvertable(Class[] var0, Class[] var1) {
		if (var0.length != var1.length) {
			return false;
		} else {
			for (int var2 = 0; var2 < var0.length; ++var2) {
				if (!isMethodConvertable(var0[var2], var1[var2])) {
					return false;
				}
			}

			return true;
		}
	}

	private static String callToString(Class var0, String var1, Class[] var2, boolean var3) {
		StringBuffer var4 = new StringBuffer();
		if (var3) {
			var4.append("static ");
		}

		var4.append(StringUtils.getClassName(var0));
		if (var1 != null) {
			var4.append(".").append(var1);
		}

		var4.append("(");
		if (var2 != null && var2.length > 0) {
			var4.append(StringUtils.getClassName(var2[0]));

			for (int var5 = 1; var5 < var2.length; ++var5) {
				var4.append(",").append(StringUtils.getClassName(var2[var5]));
			}
		} else {
			var4.append("[none]");
		}

		var4.append(")");
		return var4.toString();
	}

	static int entryGetModifiers(Object var0) {
		return var0 instanceof Method ? ((Method) var0).getModifiers() : ((Constructor) var0).getModifiers();
	}

	static String entryGetName(Object var0) {
		return var0 instanceof Method ? ((Method) var0).getName() : ((Constructor) var0).getName();
	}

	static Class[] entryGetParameterTypes(Object var0) {
		return var0 instanceof Method ? ((Method) var0).getParameterTypes() : ((Constructor) var0).getParameterTypes();
	}

	static String entryToString(Object var0) {
		return var0 instanceof Method ? ((Method) var0).toString() : ((Constructor) var0).toString();
	}

	public static Constructor getConstructor(Class var0, Class[] var1) throws SecurityException, NoSuchMethodException {
		return (Constructor) getEntryPoint(var0, (String) null, var1, true);
	}

	private static Object getEntryPoint(Class var0, String var1, Class[] var2, boolean var3) throws SecurityException, NoSuchMethodException {
      Object var4 = null;

      try {
         if (var1 != null) {
            Method var10 = var0.getMethod(var1, var2);
            if (var3 && !Modifier.isStatic(entryGetModifiers(var10))) {
               throw new NoSuchMethodException(callToString(var0, var1, var2, var3) + " resolved to instance " + var10);
            } else {
               return var10;
            }
         } else {
            return var0.getConstructor(var2);
         }
      } catch (NoSuchMethodException var9) {
         if (var2 != null && var2.length != 0) {
            Object var5;
            if (var1 != null) {
               var5 = var0.getMethods();
            } else {
               var5 = var0.getConstructors();
            }

            if (0 == ((Object[])var5).length) {
               throw new NoSuchMethodException("No methods!");
            } else {
               MoreSpecific var6 = new MoreSpecific((1)null);

               for(int var7 = 0; var7 < ((Object[])var5).length; ++var7) {
                  Object var8 = ((Object[])var5)[var7];
                  if (Modifier.isPublic(entryGetModifiers(var8)) && (var1 == null || entryGetName(var8).equals(var1)) && areMethodConvertable(entryGetParameterTypes(var8), var2)) {
                     var6.addItem(var8);
                  }
               }

               var4 = var6.getMostSpecific(var0, var1, var2, var3);
               if (var4 == null) {
                  throw new NoSuchMethodException(callToString(var0, var1, var2, var3) + " -- no signature match");
               } else if (var1 != null && var3 && !Modifier.isStatic(entryGetModifiers(var4))) {
                  throw new NoSuchMethodException(callToString(var0, var1, var2, var3) + " resolved to instance: " + var4);
               } else {
                  return var4;
               }
            }
         } else {
            throw new NoSuchMethodException(callToString(var0, var1, var2, var3) + " not found.");
         }
      }
   }

	public static Method getMethod(Class var0, String var1, Class[] var2, boolean var3)
			throws SecurityException, NoSuchMethodException {
		return (Method) getEntryPoint(var0, var1, var2, var3);
	}

	public static Method getMethod(Object var0, String var1, Class[] var2)
			throws SecurityException, NoSuchMethodException {
		boolean var3 = var0 instanceof Class;
		return getMethod(var3 ? (Class) var0 : var0.getClass(), var1, var2, var3);
	}

	private static boolean isAssignmentConvertable(Class var0, Class var1) {
		return var1.equals(Integer.TYPE)
				&& (var0.equals(Byte.TYPE) || var0.equals(Short.TYPE) || var0.equals(Character.TYPE))
				|| isMethodConvertable(var0, var1);
	}

	private static boolean isMethodConvertable(Class var0, Class var1) {
		if (var0.equals(var1)) {
			return true;
		} else if (var1 == null) {
			return !var0.isPrimitive();
		} else {
			while (var0.isArray()) {
				if (!var1.isArray()) {
					return false;
				}

				var0 = var0.getComponentType();
				var1 = var1.getComponentType();
			}

			if (var1.isArray()) {
				return false;
			} else if (var0.isAssignableFrom(var1)) {
				return true;
			} else if (!var0.equals(Void.TYPE) && !var0.equals(Boolean.TYPE) && !var1.equals(Void.TYPE)
					&& !var1.equals(Boolean.TYPE)) {
				Class[] var2 = new Class[]{Character.TYPE, Byte.TYPE, Short.TYPE, Integer.TYPE, Long.TYPE, Float.TYPE,
						Double.TYPE};

				int var3;
				for (var3 = 0; var3 < var2.length && !var0.equals(var2[var3]); ++var3) {
					;
				}

				if (var3 >= var2.length) {
					return false;
				} else {
					int var4;
					for (var4 = 0; var4 < var2.length && !var1.equals(var2[var4]); ++var4) {
						;
					}

					if (var4 >= var2.length) {
						return false;
					} else {
						return var4 < var3 && (var4 != 0 || var3 > 2);
					}
				}
			} else {
				return false;
			}
		}
	}
}