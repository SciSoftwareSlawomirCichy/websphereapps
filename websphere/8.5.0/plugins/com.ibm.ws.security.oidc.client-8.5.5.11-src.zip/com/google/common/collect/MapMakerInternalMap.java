package com.google.common.collect;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Equivalence;
import com.google.common.base.Preconditions;
import com.google.common.base.Ticker;
import com.google.common.collect.GenericMapMaker.NullListener;
import com.google.common.collect.MapMaker.RemovalListener;
import com.google.common.collect.MapMaker.RemovalNotification;
import com.google.common.collect.MapMakerInternalMap.1;
import com.google.common.collect.MapMakerInternalMap.2;
import com.google.common.collect.MapMakerInternalMap.EntryFactory;
import com.google.common.collect.MapMakerInternalMap.EntrySet;
import com.google.common.collect.MapMakerInternalMap.KeySet;
import com.google.common.collect.MapMakerInternalMap.NullEntry;
import com.google.common.collect.MapMakerInternalMap.ReferenceEntry;
import com.google.common.collect.MapMakerInternalMap.Segment;
import com.google.common.collect.MapMakerInternalMap.SerializationProxy;
import com.google.common.collect.MapMakerInternalMap.Strength;
import com.google.common.collect.MapMakerInternalMap.ValueReference;
import com.google.common.collect.MapMakerInternalMap.Values;
import com.google.common.primitives.Ints;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;
import javax.annotation.concurrent.GuardedBy;

class MapMakerInternalMap<K, V> extends AbstractMap<K, V> implements ConcurrentMap<K, V>, Serializable {
	static final int MAXIMUM_CAPACITY = 1073741824;
	static final int MAX_SEGMENTS = 65536;
	static final int CONTAINS_VALUE_RETRIES = 3;
	static final int DRAIN_THRESHOLD = 63;
	static final int DRAIN_MAX = 16;
	static final long CLEANUP_EXECUTOR_DELAY_SECS = 60L;
	private static final Logger logger = Logger.getLogger(MapMakerInternalMap.class.getName());
	final transient int segmentMask;
	final transient int segmentShift;
	final transient Segment<K, V>[] segments;
	final int concurrencyLevel;
	final Equivalence<Object> keyEquivalence;
	final Equivalence<Object> valueEquivalence;
	final Strength keyStrength;
	final Strength valueStrength;
	final int maximumSize;
	final long expireAfterAccessNanos;
	final long expireAfterWriteNanos;
	final Queue<RemovalNotification<K, V>> removalNotificationQueue;
	final RemovalListener<K, V> removalListener;
	final transient EntryFactory entryFactory;
	final Ticker ticker;
	static final ValueReference<Object, Object> UNSET = new 1();
	static final Queue<? extends Object> DISCARDING_QUEUE = new 2();
	transient Set<K> keySet;
	transient Collection<V> values;
	transient Set<Entry<K, V>> entrySet;
	private static final long serialVersionUID = 5L;

	MapMakerInternalMap(MapMaker builder) {
		this.concurrencyLevel = Math.min(builder.getConcurrencyLevel(), 65536);
		this.keyStrength = builder.getKeyStrength();
		this.valueStrength = builder.getValueStrength();
		this.keyEquivalence = builder.getKeyEquivalence();
		this.valueEquivalence = this.valueStrength.defaultEquivalence();
		this.maximumSize = builder.maximumSize;
		this.expireAfterAccessNanos = builder.getExpireAfterAccessNanos();
		this.expireAfterWriteNanos = builder.getExpireAfterWriteNanos();
		this.entryFactory = EntryFactory.getFactory(this.keyStrength, this.expires(), this.evictsBySize());
		this.ticker = builder.getTicker();
		this.removalListener = builder.getRemovalListener();
		this.removalNotificationQueue = (Queue) (this.removalListener == NullListener.INSTANCE
				? discardingQueue()
				: new ConcurrentLinkedQueue());
		int initialCapacity = Math.min(builder.getInitialCapacity(), 1073741824);
		if (this.evictsBySize()) {
			initialCapacity = Math.min(initialCapacity, this.maximumSize);
		}

		int segmentShift = 0;

		int segmentCount;
		for (segmentCount = 1; segmentCount < this.concurrencyLevel
				&& (!this.evictsBySize() || segmentCount * 2 <= this.maximumSize); segmentCount <<= 1) {
			++segmentShift;
		}

		this.segmentShift = 32 - segmentShift;
		this.segmentMask = segmentCount - 1;
		this.segments = this.newSegmentArray(segmentCount);
		int segmentCapacity = initialCapacity / segmentCount;
		if (segmentCapacity * segmentCount < initialCapacity) {
			++segmentCapacity;
		}

		int segmentSize;
		for (segmentSize = 1; segmentSize < segmentCapacity; segmentSize <<= 1) {
			;
		}

		int maximumSegmentSize;
		if (this.evictsBySize()) {
			maximumSegmentSize = this.maximumSize / segmentCount + 1;
			int remainder = this.maximumSize % segmentCount;

			for (int i = 0; i < this.segments.length; ++i) {
				if (i == remainder) {
					--maximumSegmentSize;
				}

				this.segments[i] = this.createSegment(segmentSize, maximumSegmentSize);
			}
		} else {
			for (maximumSegmentSize = 0; maximumSegmentSize < this.segments.length; ++maximumSegmentSize) {
				this.segments[maximumSegmentSize] = this.createSegment(segmentSize, -1);
			}
		}

	}

	boolean evictsBySize() {
		return this.maximumSize != -1;
	}

	boolean expires() {
		return this.expiresAfterWrite() || this.expiresAfterAccess();
	}

	boolean expiresAfterWrite() {
		return this.expireAfterWriteNanos > 0L;
	}

	boolean expiresAfterAccess() {
		return this.expireAfterAccessNanos > 0L;
	}

	boolean usesKeyReferences() {
		return this.keyStrength != Strength.STRONG;
	}

	boolean usesValueReferences() {
		return this.valueStrength != Strength.STRONG;
	}

	static <K, V> ValueReference<K, V> unset() {
		return UNSET;
	}

	static <K, V> ReferenceEntry<K, V> nullEntry() {
		return NullEntry.INSTANCE;
	}

	static <E> Queue<E> discardingQueue() {
		return DISCARDING_QUEUE;
	}

	static int rehash(int h) {
		h += h << 15 ^ -12931;
		h ^= h >>> 10;
		h += h << 3;
		h ^= h >>> 6;
		h += (h << 2) + (h << 14);
		return h ^ h >>> 16;
	}

	@GuardedBy("Segment.this")
	@VisibleForTesting
	ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable ReferenceEntry<K, V> next) {
		return this.segmentFor(hash).newEntry(key, hash, next);
	}

	@GuardedBy("Segment.this")
	@VisibleForTesting
	ReferenceEntry<K, V> copyEntry(ReferenceEntry<K, V> original, ReferenceEntry<K, V> newNext) {
		int hash = original.getHash();
		return this.segmentFor(hash).copyEntry(original, newNext);
	}

	@GuardedBy("Segment.this")
	@VisibleForTesting
	ValueReference<K, V> newValueReference(ReferenceEntry<K, V> entry, V value) {
		int hash = entry.getHash();
		return this.valueStrength.referenceValue(this.segmentFor(hash), entry, value);
	}

	int hash(Object key) {
		int h = this.keyEquivalence.hash(key);
		return rehash(h);
	}

	void reclaimValue(ValueReference<K, V> valueReference) {
		ReferenceEntry<K, V> entry = valueReference.getEntry();
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimValue(entry.getKey(), hash, valueReference);
	}

	void reclaimKey(ReferenceEntry<K, V> entry) {
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimKey(entry, hash);
	}

	@VisibleForTesting
	boolean isLive(ReferenceEntry<K, V> entry) {
		return this.segmentFor(entry.getHash()).getLiveValue(entry) != null;
	}

	Segment<K, V> segmentFor(int hash) {
		return this.segments[hash >>> this.segmentShift & this.segmentMask];
	}

	Segment<K, V> createSegment(int initialCapacity, int maxSegmentSize) {
		return new Segment(this, initialCapacity, maxSegmentSize);
	}

	V getLiveValue(ReferenceEntry<K, V> entry) {
		if (entry.getKey() == null) {
			return null;
		} else {
			V value = entry.getValueReference().get();
			if (value == null) {
				return null;
			} else {
				return this.expires() && this.isExpired(entry) ? null : value;
			}
		}
	}

	boolean isExpired(ReferenceEntry<K, V> entry) {
		return this.isExpired(entry, this.ticker.read());
	}

	boolean isExpired(ReferenceEntry<K, V> entry, long now) {
		return now - entry.getExpirationTime() > 0L;
	}

	@GuardedBy("Segment.this")
	static <K, V> void connectExpirables(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next) {
		previous.setNextExpirable(next);
		next.setPreviousExpirable(previous);
	}

	@GuardedBy("Segment.this")
	static <K, V> void nullifyExpirable(ReferenceEntry<K, V> nulled) {
		ReferenceEntry<K, V> nullEntry = nullEntry();
		nulled.setNextExpirable(nullEntry);
		nulled.setPreviousExpirable(nullEntry);
	}

	void processPendingNotifications() {
		RemovalNotification notification;
		while ((notification = (RemovalNotification) this.removalNotificationQueue.poll()) != null) {
			try {
				this.removalListener.onRemoval(notification);
			} catch (Exception var3) {
				logger.log(Level.WARNING, "Exception thrown by removal listener", var3);
			}
		}

	}

	@GuardedBy("Segment.this")
	static <K, V> void connectEvictables(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next) {
		previous.setNextEvictable(next);
		next.setPreviousEvictable(previous);
	}

	@GuardedBy("Segment.this")
	static <K, V> void nullifyEvictable(ReferenceEntry<K, V> nulled) {
		ReferenceEntry<K, V> nullEntry = nullEntry();
		nulled.setNextEvictable(nullEntry);
		nulled.setPreviousEvictable(nullEntry);
	}

	final Segment<K, V>[] newSegmentArray(int ssize) {
		return new Segment[ssize];
	}

	public boolean isEmpty() {
		long sum = 0L;
		Segment<K, V>[] segments = this.segments;

		int i;
		for (i = 0; i < segments.length; ++i) {
			if (segments[i].count != 0) {
				return false;
			}

			sum += (long) segments[i].modCount;
		}

		if (sum != 0L) {
			for (i = 0; i < segments.length; ++i) {
				if (segments[i].count != 0) {
					return false;
				}

				sum -= (long) segments[i].modCount;
			}

			if (sum != 0L) {
				return false;
			}
		}

		return true;
	}

	public int size() {
		Segment<K, V>[] segments = this.segments;
		long sum = 0L;

		for (int i = 0; i < segments.length; ++i) {
			sum += (long) segments[i].count;
		}

		return Ints.saturatedCast(sum);
	}

	public V get(@Nullable Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).get(key, hash);
		}
	}

	ReferenceEntry<K, V> getEntry(@Nullable Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).getEntry(key, hash);
		}
	}

	public boolean containsKey(@Nullable Object key) {
		if (key == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).containsKey(key, hash);
		}
	}

	public boolean containsValue(@Nullable Object value) {
		if (value == null) {
			return false;
		} else {
			Segment<K, V>[] segments = this.segments;
			long last = -1L;

			for (int i = 0; i < 3; ++i) {
				long sum = 0L;
				Segment[] arr$ = segments;
				int len$ = segments.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					Segment<K, V> segment = arr$[i$];
					int c = segment.count;
					AtomicReferenceArray<ReferenceEntry<K, V>> table = segment.table;

					for (int j = 0; j < table.length(); ++j) {
						for (ReferenceEntry e = (ReferenceEntry) table.get(j); e != null; e = e.getNext()) {
							V v = segment.getLiveValue(e);
							if (v != null && this.valueEquivalence.equivalent(value, v)) {
								return true;
							}
						}
					}

					sum += (long) segment.modCount;
				}

				if (sum == last) {
					break;
				}

				last = sum;
			}

			return false;
		}
	}

	public V put(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, false);
	}

	public V putIfAbsent(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, true);
	}

	public void putAll(Map<? extends K, ? extends V> m) {
		Iterator i$ = m.entrySet().iterator();

		while (i$.hasNext()) {
			Entry<? extends K, ? extends V> e = (Entry) i$.next();
			this.put(e.getKey(), e.getValue());
		}

	}

	public V remove(@Nullable Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash);
		}
	}

	public boolean remove(@Nullable Object key, @Nullable Object value) {
		if (key != null && value != null) {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash, value);
		} else {
			return false;
		}
	}

	public boolean replace(K key, @Nullable V oldValue, V newValue) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(newValue);
		if (oldValue == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).replace(key, hash, oldValue, newValue);
		}
	}

	public V replace(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).replace(key, hash, value);
	}

	public void clear() {
		Segment[] arr$ = this.segments;
		int len$ = arr$.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Segment<K, V> segment = arr$[i$];
			segment.clear();
		}

	}

	public Set<K> keySet() {
		Set<K> ks = this.keySet;
		return ks != null ? ks : (this.keySet = new KeySet(this));
	}

	public Collection<V> values() {
		Collection<V> vs = this.values;
		return vs != null ? vs : (this.values = new Values(this));
	}

	public Set<Entry<K, V>> entrySet() {
		Set<Entry<K, V>> es = this.entrySet;
		return es != null ? es : (this.entrySet = new EntrySet(this));
	}

	Object writeReplace() {
		return new SerializationProxy(this.keyStrength, this.valueStrength, this.keyEquivalence, this.valueEquivalence,
				this.expireAfterWriteNanos, this.expireAfterAccessNanos, this.maximumSize, this.concurrencyLevel,
				this.removalListener, this);
	}
}