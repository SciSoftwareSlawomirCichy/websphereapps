package com.ibm.ffdc.provider;

import com.ibm.ffdc.Manager;
import com.ibm.ffdc.config.DataCollector;
import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.config.IncidentForwarder;

public interface FfdcProvider extends Manager {
	void register(Formatter var1);

	void deregister(Formatter var1);

	void register(DataCollector var1);

	void deregister(DataCollector var1);

	void register(IncidentForwarder var1);

	void deregister(IncidentForwarder var1);

	void release();
}