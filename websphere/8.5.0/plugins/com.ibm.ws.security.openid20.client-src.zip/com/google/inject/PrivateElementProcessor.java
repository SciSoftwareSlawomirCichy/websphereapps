package com.google.inject;

import com.google.inject.InjectorShell.Builder;
import com.google.inject.internal.Errors;
import com.google.inject.internal.Lists;
import com.google.inject.spi.PrivateElements;
import java.util.List;

class PrivateElementProcessor extends AbstractProcessor {
	private final Stage stage;
	private final List<Builder> injectorShellBuilders = Lists.newArrayList();

	PrivateElementProcessor(Errors errors, Stage stage) {
		super(errors);
		this.stage = stage;
	}

	public Boolean visit(PrivateElements privateElements) {
		Builder builder = (new Builder()).parent(this.injector).stage(this.stage).privateElements(privateElements);
		this.injectorShellBuilders.add(builder);
		return true;
	}

	public List<Builder> getInjectorShellBuilders() {
		return this.injectorShellBuilders;
	}
}