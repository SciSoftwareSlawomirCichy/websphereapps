package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.copyright.IBMCopyright;

public interface ControlOIDList {
	String COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2014;
	String PASSWD_POLICY_REQ = "1.3.6.1.4.1.42.2.27.8.5.1";
	String PASSWD_POLICY_RESP = "1.3.6.1.4.1.42.2.27.8.5.1";
}