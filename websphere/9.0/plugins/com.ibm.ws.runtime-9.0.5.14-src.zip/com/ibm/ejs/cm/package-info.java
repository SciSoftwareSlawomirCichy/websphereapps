package com.ibm.ejs.cm;

interface package-info {
}