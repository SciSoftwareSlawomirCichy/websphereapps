package com.ibm.ws.ssl.core;

import javax.net.ssl.KeyManager;

public class KeyManagerHolder {
	private KeyManager[] kmArray = null;

	public void setKeyManagers(KeyManager[] km) {
		this.kmArray = km;
	}

	public KeyManager[] getKeyManagers() {
		return this.kmArray;
	}
}