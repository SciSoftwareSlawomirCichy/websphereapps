package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.IOException;
import java.rmi.UnmarshalException;
import org.omg.CORBA_2_3.portable.InputStream;

public final class RemoteSerialFilter {
	private static final TraceComponent tc = Tr.register(RemoteSerialFilter.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final boolean isRemoteSerialFilterDisabled;
	private static final int MAX_BYTES = 3800;

	public static void checkInput(InputStream in, String beanId, String methodName) throws IOException {
		if (!isRemoteSerialFilterDisabled) {
			int streamBytes = in.available();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkInput: in.available=" + streamBytes);
			}

			if (streamBytes > 3800) {
				UnmarshalException umex = new UnmarshalException(
						"Error unmarshalling arguments; nested exception is: java.io.InvalidClassException: filter status: REJECTED");
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkInput: ", umex);
				}

				Tr.error(tc, "NON_APPLICATION_EXCEPTION_METHOD_ON_BEAN_CNTR0020E",
						new Object[]{umex.toString(), methodName, beanId});
				throw umex;
			}
		}
	}

	static {
		isRemoteSerialFilterDisabled = ContainerProperties.DisableRemoteSerialFilter;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isRemoteSerialFilterDisabled=" + isRemoteSerialFilterDisabled);
		}

	}
}