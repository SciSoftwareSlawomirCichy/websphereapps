package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.util.concurrent.AbstractScheduledService.1;
import com.google.common.util.concurrent.AbstractScheduledService.2;
import com.google.common.util.concurrent.AbstractScheduledService.3;
import com.google.common.util.concurrent.AbstractScheduledService.Scheduler;
import com.google.common.util.concurrent.Service.Listener;
import com.google.common.util.concurrent.Service.State;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.logging.Logger;

@Beta
public abstract class AbstractScheduledService implements Service {
	private static final Logger logger = Logger.getLogger(AbstractScheduledService.class.getName());
	private final AbstractService delegate = new 1(this);

	protected abstract void runOneIteration() throws Exception;

	protected void startUp() throws Exception {
	}

	protected void shutDown() throws Exception {
	}

	protected abstract Scheduler scheduler();

	protected ScheduledExecutorService executor() {
      ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(new 2(this));
      this.addListener(new 3(this, executor), MoreExecutors.sameThreadExecutor());
      return executor;
   }

	protected String serviceName() {
		return this.getClass().getSimpleName();
	}

	public String toString() {
		return this.serviceName() + " [" + this.state() + "]";
	}

	public final ListenableFuture<State> start() {
		return this.delegate.start();
	}

	public final State startAndWait() {
		return this.delegate.startAndWait();
	}

	public final boolean isRunning() {
		return this.delegate.isRunning();
	}

	public final State state() {
		return this.delegate.state();
	}

	public final ListenableFuture<State> stop() {
		return this.delegate.stop();
	}

	public final State stopAndWait() {
		return this.delegate.stopAndWait();
	}

	public final void addListener(Listener listener, Executor executor) {
		this.delegate.addListener(listener, executor);
	}

	public final Throwable failureCause() {
		return this.delegate.failureCause();
	}
}