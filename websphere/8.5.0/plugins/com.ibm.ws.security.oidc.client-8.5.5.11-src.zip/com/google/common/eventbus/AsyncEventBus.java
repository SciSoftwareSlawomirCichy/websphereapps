package com.google.common.eventbus;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.eventbus.AsyncEventBus.1;
import com.google.common.eventbus.EventBus.EventWithHandler;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;

@Beta
public class AsyncEventBus extends EventBus {
	private final Executor executor;
	private final ConcurrentLinkedQueue<EventWithHandler> eventsToDispatch = new ConcurrentLinkedQueue();

	public AsyncEventBus(String identifier, Executor executor) {
		super(identifier);
		this.executor = (Executor) Preconditions.checkNotNull(executor);
	}

	public AsyncEventBus(Executor executor) {
		this.executor = (Executor) Preconditions.checkNotNull(executor);
	}

	void enqueueEvent(Object event, EventHandler handler) {
		this.eventsToDispatch.offer(new EventWithHandler(event, handler));
	}

	protected void dispatchQueuedEvents() {
		while (true) {
			EventWithHandler eventWithHandler = (EventWithHandler) this.eventsToDispatch.poll();
			if (eventWithHandler == null) {
				return;
			}

			this.dispatch(eventWithHandler.event, eventWithHandler.handler);
		}
	}

	void dispatch(Object event, EventHandler handler) {
      Preconditions.checkNotNull(event);
      Preconditions.checkNotNull(handler);
      this.executor.execute(new 1(this, event, handler));
   }
}