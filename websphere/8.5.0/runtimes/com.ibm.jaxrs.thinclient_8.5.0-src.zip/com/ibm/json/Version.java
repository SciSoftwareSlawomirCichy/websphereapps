package com.ibm.json;

import java.io.File;
import java.net.URL;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.jar.Attributes.Name;

public class Version {
	private static String DEFAULT = "UNKNOWN";
	private String buildDate;
	private String specTitle;
	private String specVersion;
	private String specVendor;
	private String implTitle;
	private String implVersion;
	private String implVendor;
	private String file;

	public static void main(String[] var0) {
		try {
			Version var1 = new Version();
			System.out.println("");
			System.out.println("MANIFEST information for jar: [" + var1.getFile() + "]");
			System.out.println("");
			System.out.println("Specification:");
			System.out.println("\tTitle: [" + var1.getSpecificationTitle() + "]");
			System.out.println("\tVersion: [" + var1.getSpecificationVersion() + "]");
			System.out.println("\tVendor: [" + var1.getSpecificationVendor() + "]");
			System.out.println("");
			System.out.println("Implementation:");
			System.out.println("\tTitle: [" + var1.getImplementationTitle() + "]");
			System.out.println("\tVersion: [" + var1.getImplementationVersion() + "]");
			System.out.println("\tVendor: [" + var1.getImplementationVendor() + "]");
			System.out.println("");
			System.out.println("Build date: [" + var1.getBuildDate() + "]");
		} catch (Exception var2) {
			System.out.println("Fatal error: " + var2.toString());
			var2.printStackTrace();
		}

	}

	public Version() {
		this.buildDate = DEFAULT;
		this.specTitle = DEFAULT;
		this.specVersion = DEFAULT;
		this.specVendor = DEFAULT;
		this.implTitle = DEFAULT;
		this.implVersion = DEFAULT;
		this.implVendor = DEFAULT;
		this.file = DEFAULT;

		try {
			Class var1 = this.getClass();
			ProtectionDomain var2 = var1.getProtectionDomain();
			CodeSource var3 = var2.getCodeSource();
			URL var4 = var3.getLocation();
			String var5 = var4.getFile();
			if (var5 != null) {
				File var6 = new File(var5);
				this.file = var6.getAbsolutePath();
				JarFile var7 = new JarFile(var5);
				Manifest var8 = var7.getManifest();
				var7.close();
				if (var8 != null) {
					Attributes var9 = var8.getMainAttributes();
					if (var9.getValue("Build-Date") != null) {
						this.buildDate = var9.getValue("Build-Date");
					}

					if (var9.getValue(Name.SPECIFICATION_TITLE) != null) {
						this.specTitle = var9.getValue(Name.SPECIFICATION_TITLE);
					}

					if (var9.getValue(Name.SPECIFICATION_VERSION) != null) {
						this.specVersion = var9.getValue(Name.SPECIFICATION_VERSION);
					}

					if (var9.getValue(Name.SPECIFICATION_VENDOR) != null) {
						this.specVendor = var9.getValue(Name.SPECIFICATION_VENDOR);
					}

					if (var9.getValue(Name.IMPLEMENTATION_TITLE) != null) {
						this.implTitle = var9.getValue(Name.IMPLEMENTATION_TITLE);
					}

					if (var9.getValue(Name.IMPLEMENTATION_VERSION) != null) {
						this.implVersion = var9.getValue(Name.IMPLEMENTATION_VERSION);
					}

					if (var9.getValue(Name.IMPLEMENTATION_VENDOR) != null) {
						this.implVendor = var9.getValue(Name.IMPLEMENTATION_VENDOR);
					}
				}
			}
		} catch (Exception var10) {
			System.out.println("Fatal error: " + var10.toString());
			var10.printStackTrace();
		}

	}

	public String getBuildDate() {
		return this.buildDate;
	}

	public String getSpecificationVersion() {
		return this.specVersion;
	}

	public String getSpecificationTitle() {
		return this.specTitle;
	}

	public String getSpecificationVendor() {
		return this.specVendor;
	}

	public String getImplementationVersion() {
		return this.implVersion;
	}

	public String getImplementationTitle() {
		return this.implTitle;
	}

	public String getImplementationVendor() {
		return this.implVendor;
	}

	public String getFile() {
		return this.file;
	}
}