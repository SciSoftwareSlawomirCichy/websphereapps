package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class RealmConfigurationTypeImpl extends EDataObjectImpl implements RealmConfigurationType {
	protected EList realms = null;
	protected static final String DEFAULT_REALM_EDEFAULT = null;
	protected String defaultRealm;

	protected RealmConfigurationTypeImpl() {
		this.defaultRealm = DEFAULT_REALM_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getRealmConfigurationType();
	}

	public RealmType[] getRealmsAsArray() {
		List var1 = this.getRealms();
		return (RealmType[]) ((RealmType[]) var1.toArray(new RealmType[var1.size()]));
	}

	public List getRealms() {
		if (this.realms == null) {
			this.realms = new EObjectContainmentEList(RealmType.class, this, 0);
		}

		return this.realms;
	}

	public RealmType createRealms() {
		RealmType var1 = ConfigmodelFactory.eINSTANCE.createRealmType();
		this.getRealms().add(var1);
		return var1;
	}

	public String getDefaultRealm() {
		return this.defaultRealm;
	}

	public void setDefaultRealm(String var1) {
		String var2 = this.defaultRealm;
		this.defaultRealm = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.defaultRealm));
		}

	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getRealms()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getRealms();
			case 1 :
				return this.getDefaultRealm();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getRealms().clear();
				this.getRealms().addAll((Collection) var2);
				return;
			case 1 :
				this.setDefaultRealm((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getRealms().clear();
				return;
			case 1 :
				this.setDefaultRealm(DEFAULT_REALM_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.realms != null && !this.realms.isEmpty();
			case 1 :
				return DEFAULT_REALM_EDEFAULT == null
						? this.defaultRealm != null
						: !DEFAULT_REALM_EDEFAULT.equals(this.defaultRealm);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (defaultRealm: ");
			var1.append(this.defaultRealm);
			var1.append(')');
			return var1.toString();
		}
	}
}