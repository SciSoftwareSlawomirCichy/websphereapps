package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.util.concurrent.AbstractExecutionThreadService.1;
import com.google.common.util.concurrent.AbstractExecutionThreadService.2;
import com.google.common.util.concurrent.Service.Listener;
import com.google.common.util.concurrent.Service.State;
import java.util.concurrent.Executor;
import java.util.logging.Logger;

@Beta
public abstract class AbstractExecutionThreadService implements Service {
	private static final Logger logger = Logger.getLogger(AbstractExecutionThreadService.class.getName());
	private final Service delegate = new 1(this);

	protected void startUp() throws Exception {
	}

	protected abstract void run() throws Exception;

	protected void shutDown() throws Exception {
	}

	protected void triggerShutdown() {
	}

	protected Executor executor() {
      return new 2(this);
   }

	public String toString() {
		return this.serviceName() + " [" + this.state() + "]";
	}

	public final ListenableFuture<State> start() {
		return this.delegate.start();
	}

	public final State startAndWait() {
		return this.delegate.startAndWait();
	}

	public final boolean isRunning() {
		return this.delegate.isRunning();
	}

	public final State state() {
		return this.delegate.state();
	}

	public final ListenableFuture<State> stop() {
		return this.delegate.stop();
	}

	public final State stopAndWait() {
		return this.delegate.stopAndWait();
	}

	public final void addListener(Listener listener, Executor executor) {
		this.delegate.addListener(listener, executor);
	}

	public final Throwable failureCause() {
		return this.delegate.failureCause();
	}

	protected String serviceName() {
		return this.getClass().getSimpleName();
	}
}