package com.ibm.ws.ffdc;

import com.ibm.ws.ffdc.impl.FFDCHelper;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

public class AnalysisEngineTool {
	private static FileInputStream fis = null;
	private static int readLineCount = 0;
	private static String databaseName = null;
	private static final String startHeader = "------Start";
	private static final String startCallStack = "Stack Dump = ";
	private static final String atString = "at ";
	private static final String exHeader = "Exception =";
	private static final String srcHeader = "Source =";
	private static final String prbHeader = "probeid =";
	private static int verbose = 0;
	private static String filename = null;
	private static boolean calledByDMTest = false;
	private static Vector vector = new Vector(100, 100);

	private static BufferedReader openFile() {
		BufferedReader open = null;

		try {
			if (filename != null) {
				fis = new FileInputStream(filename);
				open = new BufferedReader(new InputStreamReader(fis));
			}
		} catch (Exception var2) {
			error("Error occured opening the file : " + filename);
			error(var2.toString());
			System.exit(0);
		}

		return open;
	}

	public static void closeFile(BufferedReader di) {
		try {
			di.close();
			fis.close();
		} catch (IOException var2) {
			error(var2.toString());
		}

	}

	public static String readLine(BufferedReader inn) {
		try {
			++readLineCount;
			String returnString = inn.readLine();
			debug("debug read : " + readLineCount + " " + returnString);
			return returnString;
		} catch (IOException var2) {
			error(var2.toString());
			return null;
		}
	}

	private static void usage(String inMessage) {
		System.out.println(inMessage);
		System.out.println(
				"Usage : java -Djava.ext.dirs=<install_root>\\lib com.ibm.ws.ffdc.AnalysisEngineTool <install_root>\\logs\\ffdc\\<filename> <instal_root>\\properties\\logbr\\ffdc\\adv\\ffdcdb.xml");
		System.out.println("\t<install_root> - location of the websphere install");
		System.out.println("\t<filename> - name of the ffdc file which will be processed");
		System.out.println("\tAlternately, a different database can be specified for the last parameter");
	}

	private static void msg(String inMsg) {
		if (verbose != 0) {
			System.out.println("***** " + inMsg + " ******");
		}

	}

	private static void error(String inMsg) {
		System.out.println("----- " + inMsg + "------");
	}

	private static void debug(String inMsg) {
		if (verbose == 2) {
			System.out.println("!!!!! " + inMsg + " !!!!!");
		}

	}

	private static boolean parseParams(String[] params) {
		switch (params.length) {
			case 3 :
				if (params[2].equalsIgnoreCase("verbose")) {
					verbose = 1;
				}

				if (params[2].equalsIgnoreCase("debug")) {
					verbose = 2;
				}

				if (params[2].equalsIgnoreCase("directives")) {
					verbose = 1;
				}
			case 2 :
				if (!params[1].equalsIgnoreCase("default")) {
					databaseName = params[1];
				} else {
					databaseName = null;
				}
			case 1 :
				if (params[0].indexOf("txt") == -1) {
					error("Filename specified is not a FFDC txt file: " + params[0]);
					return false;
				}

				filename = params[0];
				return true;
			default :
				error("Wrong number of parameters specified");
				usage("Number of parameter specified was : " + params.length + ", should be at least 1");
				return false;
		}
	}

	private static String processHeader(String inLine) {
		msg("This is the header : " + inLine);
		return inLine;
	}

	private static String processException(String inLine) {
		msg("This is the exception : " + inLine);
		int equalIndex = false;
		int endIndex = false;
		String equalString = " = ";
		char sepChar = 58;
		String exceptionName = null;
		debug("Start to look for the = sign");
		int equalIndex = inLine.indexOf(equalString);
		debug("The value of the index is : " + equalIndex);
		if (equalIndex == -1) {
			msg("Something seems wrong");
			return (String) null;
		} else {
			equalIndex += equalString.length();
			debug("The index value is : " + equalIndex);
			int endIndex = inLine.indexOf(sepChar);
			if (endIndex == -1) {
				endIndex = inLine.length();
			}

			exceptionName = inLine.substring(equalIndex, endIndex);
			debug("The exception name is : |" + exceptionName + '|');
			return exceptionName;
		}
	}

	private static String processExceptionHeader(String inLine) {
		msg("Look for the exception in : " + inLine);
		int index = false;
		String exceptionName = null;
		int index = inLine.indexOf("Exception =");
		if (index != -1) {
			index += "Exception =".length();
			exceptionName = inLine.substring(index);
		}

		return exceptionName;
	}

	private static String processSourceHeader(String inLine) {
		msg("Look for the Source in : " + inLine);
		int index = false;
		String sourceName = null;
		int index = inLine.indexOf("Source =");
		if (index != -1) {
			index += "Source =".length();
			sourceName = inLine.substring(index);
		}

		return sourceName;
	}

	private static String processProbeHeader(String inLine) {
		msg("Look for the Probe in : " + inLine);
		int index = false;
		String probeName = null;
		int index = inLine.indexOf("probeid =");
		if (index != -1) {
			index += "probeid =".length();
			probeName = inLine.substring(index);
		}

		return probeName;
	}

	private static String processMethodName(String inLine) {
		debug("This is the method name : " + inLine);
		int atIndex = false;
		int endIndex = false;
		String methodName = null;
		int atIndex = inLine.indexOf("at ");
		if (atIndex == -1) {
			return (String) null;
		} else {
			atIndex += "at ".length();
			int endIndex = inLine.indexOf(40);
			if (endIndex == -1) {
				endIndex = inLine.length();
			}

			methodName = inLine.substring(atIndex, endIndex);
			debug("The name of the method is : " + methodName);
			return methodName;
		}
	}

	private static String[] convertVectorToCallStack(Vector inVector) {
		msg("Convert the vector to a call stack array");
		int vectorSize = false;
		int vectorSize = inVector.size();
		String[] returnArray = new String[vectorSize];
		inVector.copyInto(returnArray);
		inVector.removeAllElements();
		return returnArray;
	}

	private static String[] checkKnowledgeBase(String exceptionName, String[] callStack, String header,
			String printStackForDisplay) {
		String[] directives = null;
		msg("Check the knowlege base");
		directives = AnalysisEngineWrapper.checkKnowledgeBase(exceptionName, callStack, header, printStackForDisplay,
				1048576, 1);
		if (directives != null) {
			debug("Directives do exist here");

			for (int i = 0; i < directives.length; ++i) {
				msg("directive[" + i + "] = " + directives[i]);
			}
		}

		msg("Return from knowledgebase");
		return directives;
	}

	public static String[] processFile() {
		BufferedReader theFile = null;
		String readString = null;
		String exceptionName = null;
		String newExceptionInformation = "";
		String exceptionKey = null;
		String sourceKey = null;
		String probeKey = null;
		String methodName = null;
		String[] callStack = null;
		String solution = null;
		String printStackTrace = " ";
		String[] saveDirectives = null;
		theFile = openFile();
		String lineSepChar = null;
		if (lineSepChar == null) {
			lineSepChar = FFDCHelper.getSystemProperty("line.separator");
		}

		while (true) {
			do {
				readString = readLine(theFile);
				if (readString == null) {
					msg("Reached the end of the file");
					return saveDirectives;
				}

				if (readString.indexOf("------Start") != -1) {
					processHeader(readString);
				}

				if (readString.indexOf("Exception =") != -1) {
					exceptionKey = processExceptionHeader(readString);
				}

				if (readString.indexOf("Source =") != -1) {
					sourceKey = processSourceHeader(readString);
				}

				if (readString.indexOf("probeid =") != -1) {
					probeKey = processProbeHeader(readString);
				}
			} while (readString.indexOf("Stack Dump = ") == -1);

			for (exceptionName = processException(readString); readString.trim()
					.indexOf("at ") != 0; readString = readLine(theFile)) {
				newExceptionInformation = newExceptionInformation + readString;
			}

			printStackTrace = newExceptionInformation;

			while (readString.indexOf("at ") != -1) {
				printStackTrace = printStackTrace + lineSepChar + readString;
				methodName = processMethodName(readString);
				vector.add(methodName);
				readString = readLine(theFile);
				if (readString == null) {
					break;
				}
			}

			callStack = convertVectorToCallStack(vector);
			String[] tempDirectives = checkKnowledgeBase(exceptionName, callStack, exceptionKey + sourceKey + probeKey,
					printStackTrace);
			if (calledByDMTest && tempDirectives != null && tempDirectives.length > 0) {
				if (saveDirectives != null) {
					error("Directives from previous call stack are being overwritten");
					error("This test environment should only be used to process a single call stack");
					error("Modify the input file to contain only a single call stack and reissue command");
					error("Processing of the last set of directives will continue");
				}

				saveDirectives = tempDirectives;
			}
		}
	}

	public static String[] unitTestDMCall(String inFilename, String inDatabase, String inOutput) {
		String[] parameter = new String[3];
		String[] directives = null;
		calledByDMTest = true;
		if (inFilename != null) {
			parameter[0] = inFilename;
			if (inDatabase == null) {
				parameter[1] = "default";
			} else {
				parameter[1] = inDatabase;
			}

			if (inOutput == null) {
				parameter[2] = "nooutput";
			} else {
				parameter[2] = inOutput;
			}

			try {
				parseParams(parameter);
				AnalysisEngineWrapper.setUpForCommandLineCall(databaseName);
				directives = processFile();
				return directives;
			} catch (Throwable var6) {
				System.err.println("A problem was encountered with the tool");
				var6.printStackTrace();
				return (String[]) null;
			}
		} else {
			System.err.println("Filename was null, need to specify a file for processing");
			return (String[]) null;
		}
	}

	public static void main(String[] args) {
		if (!parseParams(args)) {
			msg("problem encountered with the parameters");
		} else {
			msg("Start of parsing file : " + filename);

			try {
				AnalysisEngineWrapper.setUpForCommandLineCall(databaseName);
				processFile();
			} catch (Throwable var2) {
				error("Problem has been encountered during the execution of the program");
				var2.printStackTrace();
			}

		}
	}
}