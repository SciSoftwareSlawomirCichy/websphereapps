package com.ibm.ws.security.oidc.client.filter;

import com.ibm.ws.security.oidc.util.MessageHelper;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IPAddressRange {
	private static Logger log = Logger.getLogger(IPAddressRange.class.getName());
	InetAddress ipHigher;
	InetAddress ipLower;
	String ipRange;

	public IPAddressRange(String iprange) throws FilterException {
		this.ipRange = iprange;
		log.log(Level.FINE, "ip range is {0}", iprange);
		String lowerAddr = new String();
		String upperAddr = new String();
		StringTokenizer tokens = new StringTokenizer(iprange, ".:", true);
		boolean foundRange = false;
		String currentTop = "FFFF";

		while (true) {
			String delim;
			while (tokens.hasMoreTokens()) {
				String ipPiece = tokens.nextToken();
				if (ipPiece.equals(":")) {
					upperAddr = upperAddr + ipPiece;
					lowerAddr = lowerAddr + ipPiece;
				} else {
					if (tokens.hasMoreElements()) {
						delim = tokens.nextToken();
					} else {
						delim = "";
					}

					ipPiece = ipPiece.trim();
					if (".".equals(delim)) {
						currentTop = "255";
					}

					if (foundRange) {
						if (!ipPiece.equals("*")) {
							String msg = MessageHelper.getMessage("security.tai.malformed.iprange",
									new Object[]{ipPiece});
							throw new FilterException(msg);
						}

						upperAddr = upperAddr + currentTop;
						lowerAddr = lowerAddr + "0";
					} else if (ipPiece.startsWith("[") && ipPiece.endsWith("]")) {
						int dash = ipPiece.indexOf(45);
						String startStr = ipPiece.substring(1, dash);
						lowerAddr = lowerAddr + startStr;
						int bracket = ipPiece.lastIndexOf(93);
						String lastStr = ipPiece.substring(dash + 1, bracket);
						upperAddr = upperAddr + lastStr;
						foundRange = true;
					} else if (ipPiece.equals("*")) {
						upperAddr = upperAddr + currentTop;
						lowerAddr = lowerAddr + "0";
						foundRange = true;
					} else {
						upperAddr = upperAddr + ipPiece;
						lowerAddr = lowerAddr + ipPiece;
					}

					upperAddr = upperAddr + delim;
					lowerAddr = lowerAddr + delim;
					if (log.isLoggable(Level.FINEST)) {
						log.log(Level.FINEST, "upperAddr is " + upperAddr);
						log.log(Level.FINEST, "lowerAddr is " + lowerAddr);
					}
				}
			}

			try {
				this.ipHigher = InetAddress.getByName(upperAddr);
			} catch (UnknownHostException var14) {
				delim = MessageHelper.getMessage("security.tai.unknown.host", new Object[]{upperAddr});
				throw new FilterException(delim, var14);
			}

			try {
				this.ipLower = InetAddress.getByName(lowerAddr);
				return;
			} catch (UnknownHostException var13) {
				delim = MessageHelper.getMessage("security.tai.unknown.host", new Object[]{lowerAddr});
				throw new FilterException(delim, var13);
			}
		}
	}

	public boolean inRange(InetAddress ip) {
		if (greaterThan(ip, this.ipHigher)) {
			return false;
		} else {
			return !lessThan(ip, this.ipLower);
		}
	}

	public boolean aboveRange(InetAddress ip) {
		if (log.isLoggable(Level.FINEST)) {
			log.log(Level.FINEST, "aboveRange, ip is " + ip);
			log.log(Level.FINEST, "aboveRange, ipHigher is " + this.ipHigher);
		}

		return greaterThan(ip, this.ipHigher);
	}

	public boolean belowRange(InetAddress ip) {
		if (log.isLoggable(Level.FINEST)) {
			log.log(Level.FINEST, "belowRange, ip is " + ip);
			log.log(Level.FINEST, "belowRange, ipLower is " + this.ipLower);
		}

		return lessThan(ip, this.ipLower);
	}

	public static boolean greaterThan(InetAddress a1, InetAddress a2) {
		return compare(a1, a2) > 0;
	}

	public static boolean lessThan(InetAddress a1, InetAddress a2) {
		return compare(a1, a2) < 0;
	}

	public static int compare(InetAddress a1, InetAddress a2) {
		if (log.isLoggable(Level.FINEST)) {
			log.log(Level.FINEST, "compare, a1 is " + a1);
			log.log(Level.FINEST, "compare, a2 is " + a2);
		}

		byte[] byte1 = a1.getAddress();
		byte[] byte2 = a2.getAddress();
		int base1 = 0;
		int base2 = 0;
		if (log.isLoggable(Level.FINEST)) {
			log.log(Level.FINEST, "compare, byte1.length is " + byte1.length);
			log.log(Level.FINEST, "compare, byte2.length is " + byte2.length);
		}

		int len;
		if (byte1.length > byte2.length) {
			len = byte2.length;
			base1 = byte1.length - len;
			if (!isZeros(byte1, byte1.length - len)) {
				return 1;
			}
		} else if (byte1.length < byte2.length) {
			len = byte1.length;
			base2 = byte2.length - len;
			if (!isZeros(byte2, byte2.length - len)) {
				return -1;
			}
		} else {
			len = byte1.length;
		}

		for (int i = 0; i < len; ++i) {
			if (byte1[base1] != byte2[base2]) {
				int b1 = byte1[base1];
				if (b1 < 0) {
					b1 += 256;
				}

				int b2 = byte2[base2];
				if (b2 < 0) {
					b2 += 256;
				}

				if (log.isLoggable(Level.FINEST)) {
					log.log(Level.FINEST, "compare, b1 is " + b1);
					log.log(Level.FINEST, "compare, b2 is " + b2);
				}

				if (b1 > b2) {
					return 1;
				}

				return -1;
			}

			++base1;
			++base2;
		}

		return 0;
	}

	private static boolean isZeros(byte[] bytes, int len) {
		for (int i = 0; i < len; ++i) {
			if (bytes[i] != 0) {
				return false;
			}
		}

		return true;
	}

	public String toString() {
		return this.ipRange;
	}
}