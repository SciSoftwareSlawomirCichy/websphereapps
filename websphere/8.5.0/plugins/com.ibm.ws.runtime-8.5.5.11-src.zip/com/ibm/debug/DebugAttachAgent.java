package com.ibm.debug;

import com.ibm.debug.DebugAttachAgent.DaemonConversation;
import com.ibm.debug.DebugAttachAgent.WaitThread;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.ByteArrayOutputStream;
import java.io.CharArrayReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import org.apache.xerces.dom.DocumentImpl;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.Serializer;
import org.apache.xml.serialize.SerializerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class DebugAttachAgent {
	private static final int SUCCESS = 0;
	private static final int BAD_XML = 1;
	private static final int SUPER_ADAPTER_NOT_FOUND = 2;
	private static final int ELEMENT_CREATION_FAILED = 3;
	private static final int USER_DISABLED = 4;
	private static boolean fIsInitialized = false;
	private static volatile int fIsAttached = 0;
	private static volatile String fSuperAdapterId = "";
	private static volatile String fDaemonHost = "";
	private static volatile int fDaemonPort = -1;
	private static final Object fWaitObject = new Object();
	private static Thread fWaitThread = null;
	private static InterruptedException fInterruptedException = new InterruptedException();
	private static final TraceComponent tc = Tr.register(DebugAttachAgent.class.getName(), "DebugComponent");

	public static void initialize() {
		if (!fIsInitialized) {
			Tr.debug(tc, "Initializing attach agent.");
			System.setProperty("com.ibm.debug.service.register.class", "com.ibm.debug.DebugAttachAgent");
			System.setProperty("com.ibm.debug.service.register.method", "registerElement");
			fIsInitialized = true;
		}
	}

	public static boolean xsltEnabled() {
		String enabled = System.getProperty("com.ibm.debug.attach.agent.xslt.enabled");
		return enabled == null || !enabled.equals("false");
	}

	public static Object registerElement(String inputXMLString) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Registering: " + inputXMLString);
		}

		if (fIsAttached == 0) {
			Tr.debug(tc, "Returning wait object.");
			if (fWaitThread == null) {
				fWaitThread = new WaitThread();
				fWaitThread.start();
			}

			return fWaitObject;
		} else {
			DaemonConversation daemonConversation = null;

			try {
				daemonConversation = new DaemonConversation(fDaemonHost, fDaemonPort);
			} catch (Exception var5) {
				Tr.debug(tc, "Exception creating DaemonConversation: " + var5);
				return null;
			}

			String xmlString = getXMLString(inputXMLString);
			if (xmlString == null) {
				Tr.debug(tc, "XML registration string is null.");
				return null;
			} else {
				try {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Sending XML string to deamon: " + xmlString);
					}

					int result = daemonConversation.startConversation(xmlString);
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Result of startConversation: " + result);
					}

					switch (result) {
						case 0 :
							return daemonConversation.getSocket();
						case 1 :
						case 2 :
						case 4 :
							daemonConversation.closeSocket();
							return null;
						case 3 :
					}
				} catch (Exception var4) {
					Tr.debug(tc, "Exception from startConversation: " + var4);
				}

				daemonConversation.closeSocket();
				return null;
			}
		}
	}

	private static String getXMLString(String inputXMLString) {
		DOMParser parser = new DOMParser();

		try {
			char[] charArray = inputXMLString.toCharArray();
			Reader reader = new CharArrayReader(charArray);
			InputSource inputSource = new InputSource(reader);
			parser.parse(inputSource);
		} catch (SAXException var12) {
			Tr.debug(tc, "Exception parsing XML registration string: " + var12);
			return null;
		} catch (IOException var13) {
			Tr.debug(tc, "Exception parsing XML registration string: " + var13);
			return null;
		}

		Document elementDocument = parser.getDocument();
		Document daemonDocument = new DocumentImpl();
		Element superAdapterNode = daemonDocument.createElement("superAdapter");
		daemonDocument.appendChild(superAdapterNode);
		superAdapterNode.setAttribute("id", fSuperAdapterId);
		NodeList elementNodes = elementDocument.getElementsByTagName("extensionElement");
		if (elementNodes != null && elementNodes.getLength() > 0) {
			Node elementNode = elementNodes.item(0);
			NamedNodeMap attrMap = elementNode.getAttributes();
			if (attrMap != null && attrMap.getLength() > 0) {
				Element newNode = daemonDocument.createElement(elementNode.getNodeName());

				for (int i = 0; i < attrMap.getLength(); ++i) {
					Node attr = attrMap.item(i);
					newNode.setAttribute(attr.getNodeName(), attr.getNodeValue());
				}

				superAdapterNode.appendChild(newNode);
				String xmlString = null;

				try {
					xmlString = serializeDocument(daemonDocument);
				} catch (IOException var11) {
					Tr.debug(tc, "Exception serializing final XML string: " + var11);
				}

				return xmlString;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	private static String serializeDocument(Document document) throws IOException {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		OutputFormat format = new OutputFormat();
		format.setIndenting(true);
		format.setLineSeparator(System.getProperty("line.separator"));
		Serializer serializer = SerializerFactory.getSerializerFactory("xml")
				.makeSerializer(new OutputStreamWriter(stream, "UTF8"), format);
		serializer.asDOMSerializer().serialize(document);
		return stream.toString("UTF8");
	}
}