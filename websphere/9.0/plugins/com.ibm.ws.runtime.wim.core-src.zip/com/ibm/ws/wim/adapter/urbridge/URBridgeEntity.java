package com.ibm.ws.wim.adapter.urbridge;

import com.ibm.websphere.security.UserRegistry;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.util.StringUtil;
import com.ibm.ws.wim.util.UniqueNameHelper;
import commonj.sdo.DataObject;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class URBridgeEntity {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	public static final String CLASSNAME = URBridgeEntity.class.getName();
	private static final Logger trcLogger;
	public static final String LOCAL_DOMAIN_REGISTRY_PROP = "com.ibm.websphere.registry.UseRegistry";
	public static final String LOCAL_DOMAIN_REGISTRY_PRINCIPALNAME_AS_USERID = "localAndDomainRegistryReturnPrincipalNameAsUserId";
	public static final String SECURITY_NAME_RDN_PROP = "ldap.basedn";
	Map attrMap;
	String baseEntryName;
	UserRegistry reg;
	DataObject entity;
	Map entityConfigMap;
	protected String securityNameProp;
	protected String uniqueIdProp;
	protected String displayNameProp;
	protected String rdnProp;

	public URBridgeEntity(DataObject var1, UserRegistry var2, Map var3, String var4, Map var5) {
		this.entity = var1;
		this.reg = var2;
		this.attrMap = var3;
		this.entityConfigMap = var5;
		this.baseEntryName = var4;
	}

	public abstract String getSecurityNameForEntity(String var1) throws Exception;

	public abstract String getUniqueIdForEntity(String var1) throws Exception;

	public abstract String getDisplayNameForEntity(String var1) throws Exception;

	public void populateEntity(List var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "populateEntity");
		}

		this.setIdentifierProperties();

		for (int var4 = 0; var4 < var1.size(); ++var4) {
			String var5 = (String) var1.get(var4);

			try {
				if (var5.equals(this.displayNameProp)) {
					this.getDisplayName(true);
				} else if (var5.equals(this.rdnProp)) {
					this.entity.setString(this.rdnProp,
							this.stripRDN(this.entity.getDataObject("identifier").getString(this.securityNameProp)));
				} else if (var5.equals("principalName")) {
					if ((!this.attrMap.containsKey("com.ibm.websphere.registry.UseRegistry") || !this.attrMap
							.get("com.ibm.websphere.registry.UseRegistry").toString().equalsIgnoreCase("local")
							&& !this.attrMap.get("com.ibm.websphere.registry.UseRegistry").toString()
									.equalsIgnoreCase("domain"))
							&& !this.attrMap.containsKey("ldap.basedn")
							&& (!this.attrMap.containsKey("localAndDomainRegistryReturnPrincipalNameAsUserId")
									|| !this.attrMap.get("localAndDomainRegistryReturnPrincipalNameAsUserId").toString()
											.equalsIgnoreCase("userId"))) {
						this.entity.setString("principalName", this
								.stripRDN(this.entity.getDataObject("identifier").getString(this.securityNameProp)));
					} else {
						this.entity.setString("principalName", this.reg.getUserSecurityName(this.getUniqueId(true)));
					}
				}
			} catch (Exception var7) {
				throw new WIMApplicationException(CLASSNAME, "populateEntity", var7);
			}
		}

		if (this.entity.getDataObject("identifier").isSet(this.uniqueIdProp)) {
			this.entity.getDataObject("identifier").setString("externalId",
					this.entity.getDataObject("identifier").getString(this.uniqueIdProp));
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "populateEntity");
		}

	}

	public void setSecurityNameProp(String var1) {
		if (var1 != null) {
			this.entity.getDataObject("identifier").setString(this.securityNameProp, var1);
		}

	}

	public void setPrincipalName(String var1) {
		if (var1 != null) {
			this.entity.setString("principalName", var1);
		}

	}

	public String getSecurityName(boolean var1) throws Exception {
		String var3 = null;
		if (this.entity.getDataObject("identifier").isSet(this.securityNameProp)) {
			var3 = this.entity.getDataObject("identifier").getString(this.securityNameProp);
		}

		if (var3 == null && !this.entity.getDataObject("identifier").isSet(this.uniqueIdProp)) {
			throw new WIMApplicationException("REQUIRED_IDENTIFIERS_MISSING", (Object[]) null, Level.WARNING, CLASSNAME,
					"getSecurityName");
		} else {
			String var4;
			if (var3 == null) {
				var4 = this.entity.getDataObject("identifier").getString(this.uniqueIdProp);
				var3 = this.getSecurityNameForEntity(var4);
			}

			if (var1) {
				var3 = UniqueNameHelper.isDN(var3) != null
						&& StringUtil.endsWithIgnoreCase(var3, "," + this.baseEntryName) ? var3 : this.buildRDN(var3);
				this.entity.getDataObject("identifier").setString(this.securityNameProp, var3);
			}

			var4 = null;
			if (this.attrMap.containsKey("ldap.basedn")) {
				var3 = var3;
			} else {
				var3 = this.stripRDN(var3);
			}

			return var3;
		}
	}

	public void setIdentifierProperties() throws WIMException {
		try {
			this.getUniqueId(true);
			this.getSecurityName(true);
		} catch (Exception var3) {
			throw new WIMApplicationException(CLASSNAME, "setIdentifierProperties", var3);
		}
	}

	public String getUniqueId(boolean var1) throws Exception {
		String var3 = null;
		String var4 = null;
		if (this.entity.getDataObject("identifier").isSet(this.uniqueIdProp)) {
			var4 = this.entity.getDataObject("identifier").getString(this.uniqueIdProp);
			return var4;
		} else {
			var3 = this.entity.getDataObject("identifier").getString(this.securityNameProp);
			if (var4 == null && var3 == null) {
				throw new WIMApplicationException("REQUIRED_IDENTIFIERS_MISSING", (Object[]) null, Level.WARNING,
						CLASSNAME, "getUniqueId");
			} else {
				var3 = this.stripRDN(var3);
				var4 = this.getUniqueIdForEntity(var3);
				if (var1) {
					this.entity.getDataObject("identifier").setString(this.uniqueIdProp, var4);
				}

				return var4;
			}
		}
	}

	public String getDisplayName(boolean var1) throws Exception {
		String var2 = null;
		String var3 = this.stripRDN(this.getSecurityName(false));
		var2 = this.getDisplayNameForEntity(var3);
		if (var2 != null && var2.trim().length() != 0 && var1) {
			this.entity.getList("displayName").add(var2);
		}

		return var2;
	}

	public String stripRDN(String var1) {
		if (var1 == null) {
			return var1;
		} else {
			int var2 = var1.indexOf(61);
			int var3 = var1.indexOf(",");
			if (var2 >= 0 && var3 >= 0 && var2 <= var3) {
				String var4 = var1.substring(var2 + 1, var3);
				return var4;
			} else {
				return var1;
			}
		}
	}

	public String buildRDN(String var1) {
		String var2 = (String) this.entityConfigMap.get(this.entity.getType().getName());
		String var3 = var2 + "=" + var1 + "," + this.baseEntryName;
		return var3;
	}

	public void setRDNPropValue(String var1) {
		if (var1 != null) {
			this.entity.setString((String) this.entityConfigMap.get(this.entity.getType().getName()), var1);
		}

	}

	public void getGroupsForUser(List var1, int var2) throws Exception {
		throw new WIMApplicationException("METHOD_NOT_IMPLEMENTED",
				WIMMessageHelper.generateMsgParms("getGroupsForUser", CLASSNAME), Level.WARNING, CLASSNAME,
				"getGroupsForUser");
	}

	public void getUsersForGroup(List var1, int var2) throws Exception {
		throw new WIMApplicationException("METHOD_NOT_IMPLEMENTED",
				WIMMessageHelper.generateMsgParms("getUsersForGroup", CLASSNAME), Level.WARNING, CLASSNAME,
				"getUsersForGroup");
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}