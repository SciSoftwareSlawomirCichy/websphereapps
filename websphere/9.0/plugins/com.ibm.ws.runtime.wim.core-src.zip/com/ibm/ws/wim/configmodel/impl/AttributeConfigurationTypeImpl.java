package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.AttributeConfigurationType;
import com.ibm.ws.wim.configmodel.AttributeType;
import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.PropertiesNotSupportedType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class AttributeConfigurationTypeImpl extends EDataObjectImpl implements AttributeConfigurationType {
	protected EList externalIdAttributes = null;
	protected EList attributes = null;
	protected EList propertiesNotSupported = null;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getAttributeConfigurationType();
	}

	public AttributeType[] getExternalIdAttributesAsArray() {
		List var1 = this.getExternalIdAttributes();
		return (AttributeType[]) ((AttributeType[]) var1.toArray(new AttributeType[var1.size()]));
	}

	public List getExternalIdAttributes() {
		if (this.externalIdAttributes == null) {
			this.externalIdAttributes = new EObjectContainmentEList(AttributeType.class, this, 0);
		}

		return this.externalIdAttributes;
	}

	public AttributeType createExternalIdAttributes() {
		AttributeType var1 = ConfigmodelFactory.eINSTANCE.createAttributeType();
		this.getExternalIdAttributes().add(var1);
		return var1;
	}

	public AttributeType[] getAttributesAsArray() {
		List var1 = this.getAttributes();
		return (AttributeType[]) ((AttributeType[]) var1.toArray(new AttributeType[var1.size()]));
	}

	public List getAttributes() {
		if (this.attributes == null) {
			this.attributes = new EObjectContainmentEList(AttributeType.class, this, 1);
		}

		return this.attributes;
	}

	public AttributeType createAttributes() {
		AttributeType var1 = ConfigmodelFactory.eINSTANCE.createAttributeType();
		this.getAttributes().add(var1);
		return var1;
	}

	public PropertiesNotSupportedType[] getPropertiesNotSupportedAsArray() {
		List var1 = this.getPropertiesNotSupported();
		return (PropertiesNotSupportedType[]) ((PropertiesNotSupportedType[]) var1
				.toArray(new PropertiesNotSupportedType[var1.size()]));
	}

	public List getPropertiesNotSupported() {
		if (this.propertiesNotSupported == null) {
			this.propertiesNotSupported = new EObjectContainmentEList(PropertiesNotSupportedType.class, this, 2);
		}

		return this.propertiesNotSupported;
	}

	public PropertiesNotSupportedType createPropertiesNotSupported() {
		PropertiesNotSupportedType var1 = ConfigmodelFactory.eINSTANCE.createPropertiesNotSupportedType();
		this.getPropertiesNotSupported().add(var1);
		return var1;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getExternalIdAttributes()).basicRemove(var1, var4);
				case 1 :
					return ((InternalEList) this.getAttributes()).basicRemove(var1, var4);
				case 2 :
					return ((InternalEList) this.getPropertiesNotSupported()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getExternalIdAttributes();
			case 1 :
				return this.getAttributes();
			case 2 :
				return this.getPropertiesNotSupported();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getExternalIdAttributes().clear();
				this.getExternalIdAttributes().addAll((Collection) var2);
				return;
			case 1 :
				this.getAttributes().clear();
				this.getAttributes().addAll((Collection) var2);
				return;
			case 2 :
				this.getPropertiesNotSupported().clear();
				this.getPropertiesNotSupported().addAll((Collection) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getExternalIdAttributes().clear();
				return;
			case 1 :
				this.getAttributes().clear();
				return;
			case 2 :
				this.getPropertiesNotSupported().clear();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.externalIdAttributes != null && !this.externalIdAttributes.isEmpty();
			case 1 :
				return this.attributes != null && !this.attributes.isEmpty();
			case 2 :
				return this.propertiesNotSupported != null && !this.propertiesNotSupported.isEmpty();
			default :
				return this.eDynamicIsSet(var1);
		}
	}
}