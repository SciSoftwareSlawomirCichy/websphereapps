package com.ibm.ws.wim.adapter.file.was;

import com.ibm.ejs.util.am.Alarm;
import com.ibm.ejs.util.am.AlarmListener;
import com.ibm.ejs.util.am.AlarmManager;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.ffdc.FFDCFilter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AccountLockoutCacheConfig implements AlarmListener {
	private static final String CLASSNAME = AccountLockoutCacheConfig.class.getName();
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private final int accountLockoutThreshold;
	private final long accountLockoutDurationMs;
	private final long ignoreFailedLoginAfterMs;
	private final Map<String, FileUserAccountLockoutData> lockoutCache;
	private final ReadWriteLock accountLockoutRWlock = new ReentrantReadWriteLock();
	private Alarm accountLockoutCacheChecker;
	private volatile boolean isRunning = false;
	private Object alarmRunningCheck = new Object();
	private long schedulerTimeMs = -1L;

	protected AccountLockoutCacheConfig(int var1, long var2, long var4) {
		this.accountLockoutThreshold = var1;
		this.accountLockoutDurationMs = var2;
		this.ignoreFailedLoginAfterMs = var4;
		this.lockoutCache = new ConcurrentHashMap(5);
		this.schedulerTimeMs = (this.accountLockoutDurationMs > this.ignoreFailedLoginAfterMs
				? this.accountLockoutDurationMs
				: this.ignoreFailedLoginAfterMs) + 60000L;
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "init",
					"accountLockoutCacheChecker scheduler time is set to " + this.schedulerTimeMs + "ms");
		}

	}

	protected int getAccountLockoutThreshold() {
		return this.accountLockoutThreshold;
	}

	protected long getAccountLockoutDuration() {
		return this.accountLockoutDurationMs;
	}

	protected long getIgnoreFailedLoginAfter() {
		return this.ignoreFailedLoginAfterMs;
	}

	protected boolean isLockoutCacheEmpty() {
		return this.lockoutCache.isEmpty();
	}

	protected int getLockoutCacheSize() {
		return this.lockoutCache.size();
	}

	protected FileUserAccountLockoutData getLockoutEntry(String var1) {
		return (FileUserAccountLockoutData) this.lockoutCache.get(var1);
	}

	protected boolean isUserInLockoutCache(String var1) {
		return this.lockoutCache.containsKey(var1);
	}

	protected void putLockoutEntry(String var1, FileUserAccountLockoutData var2) {
		this.lockoutCache.put(var1, var2);
	}

	public void alarm(Object var1) {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "run", "Scheduled account lockout reaper thread is running.");
		}

		boolean var19 = false;

		try {
			var19 = true;
			HashSet var3 = new HashSet(this.lockoutCache.size());
			this.acquireReadLock();

			try {
				Iterator var4 = this.lockoutCache.entrySet().iterator();

				label218 : while (true) {
					while (true) {
						if (!var4.hasNext()) {
							break label218;
						}

						Entry var5 = (Entry) var4.next();
						long var6 = System.currentTimeMillis();
						String var8 = (String) var5.getKey();
						FileUserAccountLockoutData var9 = (FileUserAccountLockoutData) var5.getValue();
						if (var9.isLocked() && var9.getLastTimeStamp() + this.accountLockoutDurationMs < var6) {
							var3.add(var8);
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "run",
										var8 + ": account lockout expired and will be removed from the cache");
							}
						} else if (var9.getLastTimeStamp() + this.ignoreFailedLoginAfterMs < var6) {
							var3.add(var8);
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "run",
										var8 + ": bad logins expired and will be removed from the cache");
							}
						}
					}
				}
			} finally {
				this.releaseReadLock();
			}

			this.clearUsersFromCache(var3, "scheduled thread cleaned up expired entries");
			var19 = false;
		} finally {
			if (var19) {
				Object var13 = this.alarmRunningCheck;
				synchronized (this.alarmRunningCheck) {
					this.isRunning = false;
					if (!this.lockoutCache.isEmpty()) {
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "run",
									"Lockout cache still has " + this.lockoutCache.size()
											+ " entries, kicking off reaper thread again.\n  Cache entries are: "
											+ this.lockoutCache);
						}

						this.startAccountLockoutCacheChecker();
					}

				}
			}
		}

		Object var28 = this.alarmRunningCheck;
		synchronized (this.alarmRunningCheck) {
			this.isRunning = false;
			if (!this.lockoutCache.isEmpty()) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "run", "Lockout cache still has " + this.lockoutCache.size()
							+ " entries, kicking off reaper thread again.\n  Cache entries are: " + this.lockoutCache);
				}

				this.startAccountLockoutCacheChecker();
			}

		}
	}

	protected void clearUsersFromCache(Set<String> var1, String var2) {
		try {
			if (var1.isEmpty()) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "clearUserFromAccountLockoutCaches",
							"DN list is empty, nothing to clear after " + var2);
				}

				return;
			}

			HashSet var4 = new HashSet();
			this.acquireWriteLock();

			try {
				Iterator var5 = var1.iterator();

				while (var5.hasNext()) {
					String var6 = (String) var5.next();
					FileUserAccountLockoutData var7 = (FileUserAccountLockoutData) this.lockoutCache.remove(var6);
					if (var7 != null) {
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "clearUserFromAccountLockoutCaches",
									var6 + " was removed from the lockoutCache after " + var2);
						}

						if (var7.isLocked()) {
							var4.add(var6);
						}
					} else if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "clearUserFromAccountLockoutCaches",
								var6 + " was not in the lockoutCache, no clear occurred after " + var2);
					}
				}
			} finally {
				this.releaseWriteLock();
			}

			if (!var4.isEmpty()) {
				msgLogger.logp(Level.INFO, CLASSNAME, "clearUserFromAccountLockoutCaches",
						"FILE_REPOSITORY_ACCOUNTS_UNLOCKED", WIMMessageHelper.generateMsgParms(var4));
			}
		} catch (Exception var12) {
			FFDCFilter.processException(var12, CLASSNAME + "." + "clearUserFromAccountLockoutCaches", "285");
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "clearUserFromAccountLockoutCaches",
						"Exception while trying to clear " + var1, var12);
			}

			msgLogger.logp(Level.SEVERE, CLASSNAME, "clearUserFromAccountLockoutCaches", "GENERIC",
					WIMMessageHelper.generateMsgParms(var12));
		}

	}

	protected void acquireWriteLock() {
		this.accountLockoutRWlock.writeLock().lock();
	}

	protected void releaseWriteLock() {
		this.accountLockoutRWlock.writeLock().unlock();
	}

	protected void acquireReadLock() {
		this.accountLockoutRWlock.readLock().lock();
	}

	protected void releaseReadLock() {
		this.accountLockoutRWlock.readLock().unlock();
	}

	protected FileUserAccountLockoutData reviewAccountStatus(String var1) {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "reviewAccountStatus",
					var1 + " is in the lockout cache, check if the lockout or failed logins have expired.");
		}

		FileUserAccountLockoutData var3 = null;

		try {
			long var4 = System.currentTimeMillis();
			var3 = (FileUserAccountLockoutData) this.lockoutCache.get(var1);
			if (var3 == null) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "reviewAccountStatus",
							var1 + ": already removed from the lockout cache.");
				}
			} else if (var3.isLocked() && var3.getLastTimeStamp() + this.accountLockoutDurationMs < var4) {
				this.lockoutCache.remove(var1);
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "reviewAccountStatus",
							var1 + ": account lockout expired and was removed from the cache");
				}

				msgLogger.logp(Level.INFO, CLASSNAME, "reviewAccountStatus", "FILE_REPOSITORY_ACCOUNTS_UNLOCKED",
						WIMMessageHelper.generateMsgParms(var1));
				var3 = null;
			} else if (var3.getLastTimeStamp() + this.ignoreFailedLoginAfterMs < var4) {
				this.lockoutCache.remove(var1);
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "reviewAccountStatus",
							var1 + ": bad logins expired and was removed from the cache");
				}

				var3 = null;
			}
		} catch (Exception var6) {
			FFDCFilter.processException(var6, CLASSNAME + "." + "reviewAccountStatus", "357");
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "reviewAccountStatus",
						"Exception while trying to run expire check on " + var1, var6);
			}

			msgLogger.logp(Level.SEVERE, CLASSNAME, "reviewAccountStatus", "GENERIC",
					WIMMessageHelper.generateMsgParms(var6));
		}

		return var3;
	}

	protected void startAccountLockoutCacheChecker() {
		try {
			Object var2 = this.alarmRunningCheck;
			synchronized (this.alarmRunningCheck) {
				if (this.accountLockoutCacheChecker == null || !this.isRunning) {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "startAccountLockoutCacheChecker",
								"Scheduling accountLockoutCacheChecker to run at " + FileUtils
										.getPrintableTimeStamp(System.currentTimeMillis() + this.schedulerTimeMs));
					}

					this.isRunning = true;
					this.accountLockoutCacheChecker = AlarmManager.createDeferrable(this.schedulerTimeMs, this);
				}
			}
		} catch (Exception var5) {
			FFDCFilter.processException(var5, CLASSNAME + "." + "startAccountLockoutCacheChecker", "396");
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "startAccountLockoutCacheChecker",
						"Exception while trying to start accountLockoutCacheChecker task", var5);
			}

			msgLogger.logp(Level.SEVERE, CLASSNAME, "startAccountLockoutCacheChecker", "GENERIC",
					WIMMessageHelper.generateMsgParms(var5));
		}

	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
	}
}