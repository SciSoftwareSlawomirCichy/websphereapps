package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;

public class UserInfo {
	private static final TraceComponent tc = Tr.register(UserInfo.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private String alias;
	private String uriType;
	private int count;
	private boolean required;

	UserInfo(String alias, String uriType, int count, boolean required) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "UserInfo(alias[" + alias + "],uriType[" + uriType + "],count[" + count + "],required["
					+ required + "])");
		}

		this.alias = alias;
		this.uriType = uriType;
		this.count = count;
		this.required = required;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "UserInfo");
		}

	}

	public String getAlias() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getAlias returns [" + this.alias + "]");
		}

		return this.alias;
	}

	public int getCount() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getCount returns [" + this.count + "]");
		}

		return this.count;
	}

	public boolean getRequired() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getRequired returns [" + this.required + "]");
		}

		return this.required;
	}

	public String getType() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getType returns [" + this.uriType + "]");
		}

		return this.uriType;
	}

	public String toString() {
		return "[" + this.alias + "," + this.uriType + "," + this.count + "," + this.required + "]";
	}
}