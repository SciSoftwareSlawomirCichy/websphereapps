package com.ibm.ejs.cm;

import com.ibm.websphere.advanced.cm.factory.CMFactoryException;
import javax.naming.NamingException;
import javax.sql.DataSource;

public interface DSFactory {
	void shutdown();

	DataSource getDataSource(CMProperties var1) throws ClassNotFoundException, CMFactoryException;

	DataSource removeDataSource(String var1);

	void verifyConfiguration() throws NamingException;
}