package com.ibm.ejs.cm.pool;

import com.ibm.ejs.cm.portability.PortableConnection;
import java.sql.Connection;
import java.sql.SQLException;

public interface ExtendedConnection extends PortableConnection {
	Connection getPhysicalConnection() throws SQLException;

	void unilateralCommit() throws SQLException;
}