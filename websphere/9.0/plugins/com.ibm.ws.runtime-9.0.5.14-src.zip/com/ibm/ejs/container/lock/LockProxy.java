package com.ibm.ejs.container.lock;

public interface LockProxy {
	boolean isLock();
}