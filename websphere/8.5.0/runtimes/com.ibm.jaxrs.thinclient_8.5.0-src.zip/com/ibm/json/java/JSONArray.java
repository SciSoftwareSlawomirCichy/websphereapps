package com.ibm.json.java;

import com.ibm.json.java.internal.Serializer;
import com.ibm.json.java.internal.SerializerVerbose;
import java.io.BufferedWriter;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class JSONArray extends ArrayList implements JSONArtifact {
	private static final long serialVersionUID = 9076798781015779954L;

	public JSONArray() {
	}

	public JSONArray(int var1) {
		super(var1);
	}

	public void add(int var1, Object var2) {
		this.checkElement(var2);
		super.add(var1, var2);
	}

	public boolean add(Object var1) {
		this.checkElement(var1);
		return super.add(var1);
	}

	public boolean addAll(Collection var1) {
		this.checkElements(var1);
		return super.addAll(var1);
	}

	public boolean addAll(int var1, Collection var2) {
		this.checkElements(var2);
		return super.addAll(var1, var2);
	}

	public Object set(int var1, Object var2) {
		this.checkElement(var2);
		return super.set(var1, var2);
	}

	public static JSONArray parse(InputStream var0) throws IOException {
		InputStreamReader var1 = null;

		try {
			var1 = new InputStreamReader(var0, "UTF-8");
		} catch (Exception var3) {
			var1 = new InputStreamReader(var0);
		}

		return parse((Reader) var1);
	}

	public static JSONArray parse(Reader var0) throws IOException {
		StringBuffer var1 = new StringBuffer("");
		var1.append("{\"jsonArray\":");
		char[] var2 = new char[8196];
		boolean var3 = false;

		for (int var5 = var0.read(var2, 0, 8196); var5 != -1; var5 = var0.read(var2, 0, 8196)) {
			var1.append(var2, 0, var5);
		}

		var1.append("}");
		JSONObject var4 = JSONObject.parse(var1.toString());
		return (JSONArray) var4.get("jsonArray");
	}

	public static JSONArray parse(String var0) throws IOException {
		StringReader var1 = new StringReader(var0);
		return parse((Reader) var1);
	}

	public void serialize(OutputStream var1) throws IOException {
		this.serialize(var1, false);
	}

	public void serialize(OutputStream var1, boolean var2) throws IOException {
		BufferedWriter var3 = null;

		try {
			var3 = new BufferedWriter(new OutputStreamWriter(var1, "UTF-8"));
		} catch (UnsupportedEncodingException var6) {
			IOException var5 = new IOException(var6.toString());
			var5.initCause(var6);
			throw var5;
		}

		this.serialize((Writer) var3, var2);
	}

	public void serialize(Writer var1) throws IOException {
		this.serialize(var1, false);
	}

	public void serialize(Writer var1, boolean var2) throws IOException {
		Class var4 = var1.getClass();
		if (!StringWriter.class.isAssignableFrom(var4) && !CharArrayWriter.class.isAssignableFrom(var4)
				&& !BufferedWriter.class.isAssignableFrom(var4)) {
			var1 = new BufferedWriter((Writer) var1);
		}

		Object var3;
		if (var2) {
			var3 = new SerializerVerbose((Writer) var1);
		} else {
			var3 = new Serializer((Writer) var1);
		}

		((Serializer) var3).writeArray(this).flush();
	}

	public String serialize(boolean var1) throws IOException {
		StringWriter var3 = new StringWriter();
		Object var2;
		if (var1) {
			var2 = new SerializerVerbose(var3);
		} else {
			var2 = new Serializer(var3);
		}

		((Serializer) var2).writeArray(this).flush();
		return var3.toString();
	}

	public String serialize() throws IOException {
		return this.serialize(false);
	}

	private void checkElement(Object var1) {
		if (!JSONObject.isValidObject(var1)) {
			throw new IllegalArgumentException("invalid type of element");
		}
	}

	private void checkElements(Collection var1) {
		Iterator var2 = var1.iterator();

		do {
			if (!var2.hasNext()) {
				return;
			}
		} while (JSONObject.isValidObject(var2.next()));

		throw new IllegalArgumentException("invalid type of element");
	}
}