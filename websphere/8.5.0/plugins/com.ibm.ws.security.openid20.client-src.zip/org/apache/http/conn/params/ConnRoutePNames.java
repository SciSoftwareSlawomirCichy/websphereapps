package org.apache.http.conn.params;

public interface ConnRoutePNames {
	String DEFAULT_PROXY = "http.route.default-proxy";
	String LOCAL_ADDRESS = "http.route.local-address";
	String FORCED_ROUTE = "http.route.forced-route";
}