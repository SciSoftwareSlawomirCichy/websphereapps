package com.ibm.ws.wim.dao;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.ws.wim.adapter.db.DBAccount;
import com.ibm.ws.wim.adapter.db.DBEntity;
import com.ibm.ws.wim.adapter.db.DBExtIdReposId;
import com.ibm.ws.wim.adapter.db.DBPropertyCache;
import com.ibm.ws.wim.dao.schema.DBRepositoryProperty;
import com.ibm.ws.wim.lookaside.LAEntity;
import com.ibm.ws.wim.lookaside.LAPropertyCache;
import commonj.sdo.DataObject;
import java.sql.Connection;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.sql.DataSource;

public interface DataAccessObject {
	String COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;

	Connection getConnection() throws WIMException;

	Connection getDirectAccessConnection() throws WIMException;

	DataSource dsLookup();

	QuerySet getQuerySet();

	void closeConnection(Connection var1);

	long createDBEntity(DBEntity var1) throws WIMException;

	void createParentRelationship(long var1, DBEntity var3) throws WIMException;

	void createProperties(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException;

	Long createCompositePropValue(short var1, Integer var2, long var3, Long var5, String var6) throws WIMException;

	void createGroupRelationsForEntity(String var1, String var2, List var3) throws WIMException;

	void createGroupRelationsForGroup(long var1, List var3, String var4) throws WIMException;

	int createPropertyDefinition(DBRepositoryProperty var1) throws WIMException;

	void createNewPropertyEntityRelationInDB(String var1, String var2, DBPropertyCache var3) throws WIMException;

	void createNewPropertyEntityRelationInLA(String var1, String var2, LAPropertyCache var3) throws WIMException;

	boolean checkIfEntityHasDescendants(String var1) throws WIMException;

	void deleteDBGroupRelation(Hashtable var1) throws WIMException;

	void deleteEntityWithDescendants(String var1) throws WIMException;

	List findDBEntitysByParentName(String var1) throws WIMException;

	String findUniqueIdByUniqueName(String var1) throws WIMException;

	DBEntity findDBEntityByUniqueId(String var1) throws WIMException;

	DBEntity findDBEntityByUniqueNameKey(String var1) throws WIMException;

	String getDBPropValuesByEntityQuery(short var1);

	void readDBProperties(long var1, StringBuffer var3, short var4, DataObject var5) throws WIMException;

	void readAllDBPropertiesForEntity(long var1, DataObject var3) throws WIMException;

	void readAllLAPropertiesForEntity(long var1, DataObject var3) throws WIMException;

	DBEntity findParent(long var1) throws WIMException;

	String getSpecificDatatypePropertyForEntitiesQuery(short var1);

	void getObjectProperties(Map var1, String var2, String var3, boolean var4) throws WIMException;

	void getCompositeProperties(Map var1, String var2, boolean[] var3, String var4, boolean var5) throws WIMException;

	void getDBEntityInformation(String var1, DataObject var2, String var3, String var4) throws WIMException;

	List getAllDescendantsByUniqueNameKey(String var1, List var2) throws WIMException;

	List getChildrenByUniqueNameKey(String var1, List var2) throws WIMException;

	List getChildrenByEntityIdList(List var1, List var2) throws WIMException;

	List getImmediateGroupsForEntity(String var1, String var2, List var3) throws WIMException;

	List getNestedGroupsForEntity(String var1, String var2, String var3, List var4, List var5) throws WIMException;

	String getOperator(String var1, short var2);

	Set[] getImmediateGroupMembers(long var1, List var3, List var4) throws WIMException;

	Set[] getNestedGroupMembers(long var1, List var3, List var4) throws WIMException;

	String renameEntity(long var1, String var3) throws WIMException;

	void updateAccount(long var1, byte[] var3, String var4, String var5, String var6) throws WIMException;

	void updateProperties(short var1, long var2, Hashtable[] var4) throws WIMException;

	void replaceProperties(short var1, long var2, Hashtable[] var4, Set var5, String var6, boolean var7)
			throws WIMException;

	void deleteProperties(short var1, long var2, Hashtable[] var4, Set var5, String var6) throws WIMException;

	void deleteCompositeProperties(short var1, long var2, Hashtable var4) throws WIMException;

	void assignMemberToGroups(DBExtIdReposId var1, List var2) throws WIMException;

	void unassignMemberFromAllGroups(DBExtIdReposId var1) throws WIMException;

	void unassignMemberFromGroups(DBExtIdReposId var1, List var2) throws WIMException;

	void assignMembersToGroup(List var1, long var2) throws WIMException;

	void unassignAllMembersFromGroup(long var1) throws WIMException;

	void unassignMembersFromGroup(List var1, long var2, String var4) throws WIMException;

	Map search(String var1, List var2, boolean var3, DataObject var4, String var5, int var6) throws WIMException;

	Map searchLA(String var1, List var2, boolean var3, DataObject var4, String var5, int var6) throws WIMException;

	DBAccount getDBAccountByEntId(long var1) throws WIMException;

	boolean isMemberInGroup(long var1, String var3, String var4, String var5, int var6) throws WIMException;

	void createAccount(long var1, byte[] var3, String var4, String var5, String var6) throws WIMException;

	long createLAEntity(LAEntity var1) throws WIMException;

	int createLookAsidePropertyDefinition(DBRepositoryProperty var1) throws WIMException;

	LAEntity findLAEntityByExtIdReposId(String var1, String var2) throws WIMException;

	void readLAProperties(long var1, StringBuffer var3, short var4, DataObject var5) throws WIMException;

	String getLAPropValuesByEntityQuery(short var1);

	void deleteLAEntity(String var1, String var2) throws WIMException;

	void deleteLAPropertyDataForEntityTypes(String var1, List var2) throws WIMException;

	void reload(String var1) throws WIMException;

	boolean isValidSchema(String var1) throws WIMException;

	void createProperties1(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException;

	void setUseTriggerForIdInLARepo(boolean var1) throws WIMException;
}