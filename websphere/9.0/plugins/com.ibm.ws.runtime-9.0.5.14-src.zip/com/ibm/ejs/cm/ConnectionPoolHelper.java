package com.ibm.ejs.cm;

import com.ibm.ejs.cm.ConnectionPoolHelper.1;
import com.ibm.ejs.cm.ConnectionPoolHelper.2;
import com.ibm.ejs.cm.ConnectionPoolHelper.3;
import com.ibm.ejs.cm.ConnectionPoolHelper.4;
import com.ibm.ejs.cm.ConnectionPoolHelper.5;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.advanced.cm.factory.DataSourceFactory;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.Vector;
import javax.sql.PooledConnection;

public abstract class ConnectionPoolHelper {
	private static final TraceComponent tc = Tr.register(ConnectionPoolHelper.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");
	public static final String[] SUPPORTED_DATASOURCE_CLASS_NAMES = new String[]{
			"COM.ibm.db2.jdbc.DB2ConnectionPoolDataSource", "com.ibm.as400.access.AS400JDBCConnectionPoolDataSource",
			"com.ibm.db2.jdbc.app.DB2StdConnectionPoolDataSource", "com.ibm.db2.jdbc.app.UDBConnectionPoolDataSource",
			"oracle.jdbc.pool.OracleConnectionPoolDataSource", "com.sybase.jdbc2.jdbc.SybConnectionPoolDataSource",
			"com.merant.datadirect.jdbcx.sqlserver.SQLServerDataSource",
			"com.ddtek.jdbcx.sqlserver.SQLServerDataSource", "com.microsoft.jdbcx.sqlserver.SQLServerDataSource",
			"com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource",
			"com.merant.sequelink.jdbcx.datasource.SequeLinkDataSource",
			"com.ddtek.jdbcx.sequelink.SequeLinkDataSource", "com.ibm.db2.jcc.DB2ConnectionPoolDataSource"};
	public static final String[] SUPPORTED_XADATASOURCE_CLASS_NAMES = new String[]{"COM.ibm.db2.jdbc.DB2XADataSource",
			"com.ibm.as400.access.AS400JDBCXADataSource", "com.ibm.db2.jdbc.app.DB2StdXADataSource",
			"com.ibm.db2.jdbc.app.UDBXADataSource", "oracle.jdbc.xa.client.OracleXADataSource",
			"com.sybase.jdbc2.jdbc.SybXADataSource", "com.merant.datadirect.jdbcx.sqlserver.SQLServerDataSource",
			"com.ddtek.jdbcx.sqlserver.SQLServerDataSource", "com.microsoft.jdbcx.sqlserver.SQLServerDataSource",
			"com.microsoft.sqlserver.jdbc.SQLServerXADataSource",
			"com.merant.sequelink.jdbcx.datasource.SequeLinkDataSource",
			"com.ddtek.jdbcx.sequelink.SequeLinkDataSource", "com.ibm.db2.jcc.DB2XADataSource"};
	public static final String[] CM_PROPS = new String[]{"name", "dataSourceClassName", "description",
			"minimumPoolSize", "maximumPoolSize", "connectionTimeout", "idleTimeout", "orphanTimeout", "agedTimeout",
			"statementCacheSize", "user", "password", "disableAutoConnectionCleanup", "errorMap", "oemId",
			"informixLockModeWait", "informixAllowNewLine", "disable2Phase", "transactionBranchesLooselyCoupled"};
	private static final boolean HELPER_TEST_IF_DATASOURCE_LOADED = true;
	private static Hashtable loaders = new Hashtable();

	public static Vector getPropertiesForDataSource(String dsClassName, String providerLibPath)
			throws ClassNotFoundException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPropertiesForDataSource", new Object[]{dsClassName, providerLibPath});
		}

		Vector propList = new Vector();
		String[] arr = getRequiredPropertiesForDataSource(dsClassName);
		Vector requiredProps = arr == null ? new Vector() : new Vector(Arrays.asList(arr));
		int numRequiredProps = requiredProps.size();

		for (int i = 0; i < numRequiredProps; ++i) {
			propList.add(new PropertyEntry((String) requiredProps.get(i), true));
		}

		SortedSet optionalProps = new TreeSet();
		boolean hasUserProperty = false;
		boolean hasPasswordProperty = false;

		try {
			Class dsClass = loadDataSourceClass(dsClassName, providerLibPath);
			PropertyDescriptor[] propDescriptions = Introspector.getBeanInfo(dsClass).getPropertyDescriptors();

			for (int i = 0; i < propDescriptions.length; ++i) {
				PropertyDescriptor pd = propDescriptions[i];
				String propertyName = pd.getName();
				if (!requiredProps.contains(propertyName) && pd.getWriteMethod() != null) {
					if (propertyName.equals("user")) {
						hasUserProperty = true;
					} else if (propertyName.equals("password")) {
						hasPasswordProperty = true;
					} else {
						optionalProps.add(new PropertyEntry(propertyName, false));
					}
				}
			}
		} catch (IntrospectionException var14) {
			Tr.warning(tc, "MSG_CONM_7001E", new Object[]{dsClassName, var14});
		}

		if (hasUserProperty) {
			propList.add(new PropertyEntry("user", false));
		}

		if (hasPasswordProperty) {
			propList.add(new PropertyEntry("password", false));
		}

		propList.addAll(optionalProps);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getPropertiesForDataSource");
		}

		return propList;
	}

	public static String[] getRequiredPropertiesForDataSource(String dataSourceClassName) {
		if (!dataSourceClassName.equals("COM.ibm.db2.jdbc.DB2ConnectionPoolDataSource")
				&& !dataSourceClassName.equals("COM.ibm.db2.jdbc.DB2XADataSource")) {
			if (dataSourceClassName.equals("com.ibm.db2.jcc.DB2ConnectionPoolDataSource")) {
				return new String[]{"databaseName"};
			} else if (dataSourceClassName.equals("com.ibm.db2.jcc.DB2XADataSource")) {
				return new String[]{"databaseName", "serverName", "portNumber", "driverType"};
			} else if (!dataSourceClassName.equals("com.ibm.as400.access.AS400JDBCConnectionPoolDataSource")
					&& !dataSourceClassName.equals("com.ibm.as400.access.AS400JDBCXADataSource")) {
				if (!dataSourceClassName.equals("com.ibm.db2.jdbc.app.DB2StdConnectionPoolDataSource")
						&& !dataSourceClassName.equals("com.ibm.db2.jdbc.app.DB2StdXADataSource")
						&& !dataSourceClassName.equals("com.ibm.db2.jdbc.app.UDBConnectionPoolDataSource")
						&& !dataSourceClassName.equals("com.ibm.db2.jdbc.app.UDBXADataSource")) {
					if (!dataSourceClassName.equals("oracle.jdbc.pool.OracleConnectionPoolDataSource")
							&& !dataSourceClassName.equals("oracle.jdbc.xa.client.OracleXADataSource")) {
						if (!dataSourceClassName.equals("com.sybase.jdbc2.jdbc.SybConnectionPoolDataSource")
								&& !dataSourceClassName.equals("com.sybase.jdbc2.jdbc.SybXADataSource")) {
							if (!dataSourceClassName.equals("com.merant.sequelink.jdbcx.datasource.SequeLinkDataSource")
									&& !dataSourceClassName.equals("com.ddtek.jdbcx.sequelink.SequeLinkDataSource")
									&& !dataSourceClassName
											.equals("com.merant.datadirect.jdbcx.sqlserver.SQLServerDataSource")
									&& !dataSourceClassName.equals("com.ddtek.jdbcx.sqlserver.SQLServerDataSource")
									&& !dataSourceClassName
											.equals("com.microsoft.jdbcx.sqlserver.SQLServerDataSource")) {
								if (!dataSourceClassName
										.equals("com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource")
										&& !dataSourceClassName
												.equals("com.microsoft.sqlserver.jdbc.SQLServerXADataSource")) {
									return !dataSourceClassName.equals("com.informix.jdbcx.IfxConnectionPoolDataSource")
											&& !dataSourceClassName.equals("com.informix.jdbcx.IfxXADataSource")
													? null
													: new String[]{"databaseName", "ifxIFXHOST", "informixLockModeWait",
															"portNumber", "serverName"};
								} else {
									return new String[]{"serverName"};
								}
							} else {
								return new String[]{"serverName"};
							}
						} else {
							return new String[]{"databaseName", "portNumber", "serverName"};
						}
					} else {
						return new String[]{"URL"};
					}
				} else {
					return new String[0];
				}
			} else {
				return new String[]{"serverName"};
			}
		} else {
			return new String[]{"databaseName"};
		}
	}

	protected static String getSQLExceptionInfo(SQLException ex) {
		return "(SQL State: " + ex.getSQLState() + ", Error Code: " + ex.getErrorCode() + ") ";
	}

	protected static String getStackTrace(Throwable ex) {
		StringWriter sw = new StringWriter();
		ex.printStackTrace(new PrintWriter(sw));
		return sw.toString();
	}

	protected static Class loadDataSourceClass(String dsClassName, String providerLibPath) throws ClassNotFoundException {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "loadDataSourceClass", new Object[]{dsClassName, providerLibPath});
      }

      URLClassLoader ul = (URLClassLoader)loaders.get(providerLibPath);
      if (tc.isDebugEnabled()) {
         Tr.debug(tc, "loadDataSourceClass:  ul = " + ul);
      }

      try {
         Class dsClass = Class.forName(dsClassName, true, Thread.currentThread().getContextClassLoader());
         if (ul != null && dsClass == null) {
            dsClass = Class.forName(dsClassName, true, ul);
         }

         if (dsClass != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "loadDataSourceClass: DataSource class already loaded, ", dsClassName);
            }

            if (tc.isEntryEnabled()) {
               Tr.exit(tc, "loadDataSourceClass");
            }

            return dsClass;
         }
      } catch (ClassNotFoundException var17) {
         ;
      }

      Vector jars = new Vector();
      String sep = providerLibPath.indexOf(92) < 0 && providerLibPath.indexOf(59) < 0 ? File.pathSeparator : ";";
      StringTokenizer path = new StringTokenizer(providerLibPath, sep);

      while(path.hasMoreTokens()) {
         File file = new File(path.nextToken());
         if (file.isFile()) {
            jars.add(file);
         } else {
            File[] moreJars = file.listFiles(new 1());
            if (moreJars != null) {
               jars.addAll(Arrays.asList(moreJars));
            }
         }
      }

      int numJars = jars.size();
      URL[] urls;
      if (numJars < 1) {
         Tr.warning(tc, "MSG_CONM_7011W", new Object[]{dsClassName, providerLibPath});
         urls = null;
         String dsClassNameFinal = dsClassName;

         Class dsClass;
         try {
            dsClass = (Class)AccessController.doPrivileged(new 2(dsClassNameFinal, providerLibPath));
         } catch (PrivilegedActionException var15) {
            Tr.error(tc, "MSG_CONM_7012E", new Object[]{dsClassName, providerLibPath});
            throw new ClassNotFoundException("No jar or zip files found in " + providerLibPath + " and not found in current class loader", var15.getException());
         }

         if (dsClass != null) {
            if (tc.isEntryEnabled()) {
               Tr.exit(tc, "loadDataSourceClass");
            }

            return dsClass;
         } else {
            Tr.error(tc, "MSG_CONM_7012E", new Object[]{dsClassName, providerLibPath});
            throw new ClassNotFoundException("No jar or zip files found in " + providerLibPath);
         }
      } else {
         urls = new URL[numJars];

         try {
            for(int i = 0; i < numJars; ++i) {
               urls[i] = ((File)jars.get(i)).toURL();
            }
         } catch (MalformedURLException var18) {
            throw new ClassNotFoundException("Unable to find JDBC resource provider classes.", var18);
         }

         URL[] finalURL = urls;
         String fdsClassName = dsClassName;
         String fproviderLibPath = providerLibPath;
         URLClassLoader final_ul = ul;

         Class aClass;
         try {
            aClass = (Class)AccessController.doPrivileged(new 3(final_ul, finalURL, fproviderLibPath, fdsClassName));
         } catch (PrivilegedActionException var16) {
            throw (ClassNotFoundException)var16.getException();
         }

         if (tc.isEntryEnabled()) {
            Tr.exit(tc, "loadDataSourceClass");
         }

         return aClass;
      }
   }

	protected static void setProperty(Object obj, PropertyDescriptor pd, String value) throws Exception {
		Object param = null;
		Method setter = pd.getWriteMethod();
		if (setter == null) {
			throw new NoSuchMethodException("No setter method for property: " + pd.getName());
		} else {
			Class paramType = setter.getParameterTypes()[0];
			if (!paramType.isPrimitive()) {
				if (paramType.equals(Character.class)) {
					param = new Character(value.charAt(0));
				} else {
					param = paramType.getConstructor(String.class).newInstance(value);
				}
			} else if (paramType.equals(Integer.TYPE)) {
				param = new Integer(value);
			} else if (paramType.equals(Long.TYPE)) {
				param = new Long(value);
			} else if (paramType.equals(Boolean.TYPE)) {
				param = new Boolean(value);
			} else if (paramType.equals(Double.TYPE)) {
				param = new Double(value);
			} else if (paramType.equals(Float.TYPE)) {
				param = new Float(value);
			} else if (paramType.equals(Short.TYPE)) {
				param = new Short(value);
			} else if (paramType.equals(Byte.TYPE)) {
				param = new Byte(value);
			} else if (paramType.equals(Character.TYPE)) {
				param = new Character(value.charAt(0));
			}

			setter.invoke(obj, param);
		}
	}

	public static Object[] testConnectionToDataSource(String dsClassName, Properties dataSourceProps, String providerLibPath) throws ClassNotFoundException {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "testConnectionToDataSource - dsClassName, dataSourceProps, providerLibPath", new Object[]{dsClassName, dataSourceProps, providerLibPath});
      }

      int numWarnings = 0;
      Object[] result = new Object[2];
      String results = "";
      String user = dataSourceProps.getProperty("user");
      String password = dataSourceProps.getProperty("password");
      Properties dsProps = new Properties();
      dsProps.putAll(dataSourceProps);
      Vector cmProps = new Vector(Arrays.asList(DataSourceFactory.getCMProperties()));

      try {
         Class dsClass = loadDataSourceClass(dsClassName, providerLibPath);
         Object ds = null;
         Class fdsClass = dsClass;

         try {
            ds = AccessController.doPrivileged(new 4(fdsClass));
         } catch (PrivilegedActionException var22) {
            throw var22.getException();
         }

         PropertyDescriptor[] propDescriptions = Introspector.getBeanInfo(dsClass).getPropertyDescriptors();

         String propName;
         String className;
         for(int i = 0; i < propDescriptions.length; ++i) {
            PropertyDescriptor pd = propDescriptions[i];
            propName = pd.getName();
            if (dsProps.containsKey(propName)) {
               try {
                  setProperty(ds, pd, (String)dsProps.remove(propName));
               } catch (NoSuchMethodException var23) {
                  ++numWarnings;
                  className = "Warning: property not found for " + dsClassName + ": " + propName;
                  Tr.warning(tc, "MSG_CONM_7003W", new Object[]{propName, dsClassName});
                  results = results + className + "\n";
               } catch (Exception var24) {
                  Exception ex = var24;
                  if (var24 instanceof InvocationTargetException) {
                     ex = (Exception)((InvocationTargetException)var24).getTargetException();
                  }

                  ++numWarnings;
                  className = ex.getClass().getName();
                  String exMessage = ex.toString();
                  String warning = "Warning: error setting '" + propName + "': " + (exMessage.indexOf(className) < 0 ? className + ": " : "") + exMessage;
                  Tr.warning(tc, "MSG_CONM_7004W", new Object[]{propName, className, ex});
                  results = results + warning + "\n";
               }
            }
         }

         Enumeration pConn = dsProps.propertyNames();

         String userName;
         while(pConn.hasMoreElements()) {
            propName = (String)pConn.nextElement();
            if (!cmProps.contains(propName)) {
               ++numWarnings;
               userName = "Warning: property not found for " + dsClassName + ": " + propName;
               Tr.warning(tc, "MSG_CONM_7003W", new Object[]{propName, dsClassName});
               results = results + userName + "\n";
            }
         }

         pConn = null;
         userName = user;
         className = password;
         Object fds = ds;

         PooledConnection pConn;
         try {
            pConn = (PooledConnection)AccessController.doPrivileged(new 5(userName, className, fds));
         } catch (PrivilegedActionException var21) {
            throw var21.getException();
         }

         Connection conn = pConn.getConnection();
         conn.close();
         pConn.close();
         result[0] = new Boolean(true);
         if (numWarnings > 0) {
            result[1] = results;
         } else {
            result[1] = null;
         }
      } catch (ClassNotFoundException var25) {
         throw var25;
      } catch (NoClassDefFoundError var26) {
         throw new ClassNotFoundException(getStackTrace(var26));
      } catch (Exception var27) {
         results = results + "Failed to connect to data source. Encountered " + var27.getClass().getName() + ": ";
         if (var27 instanceof SQLException) {
            results = results + getSQLExceptionInfo((SQLException)var27);
         }

         results = results + var27.getMessage();
         result[0] = new Boolean(false);
         result[1] = results;
         Tr.warning(tc, "MSG_CONM_7014W", var27);
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "testConnectionToDataSource - result", new Object[]{result[0], result[1]});
      }

      return result;
   }

	public static boolean isPropertyRequired(String propName, String dsClassName) {
		String[] requiredProps = getRequiredPropertiesForDataSource(dsClassName);
		if (requiredProps == null) {
			return false;
		} else {
			for (int i = 0; i < requiredProps.length; ++i) {
				if (requiredProps[i].equals(propName)) {
					return true;
				}
			}

			return false;
		}
	}
}