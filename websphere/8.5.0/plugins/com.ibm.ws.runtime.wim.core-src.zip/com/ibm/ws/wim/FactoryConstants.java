package com.ibm.ws.wim;

public interface FactoryConstants {
	String FACTORY_PROP_FILENAME = "factoryClasses.properties";
	String FACTORY_CLASS_KEY_AUTH_SERVICE = "com.ibm.ws.wim.env.IAuthorizationService.className";
	String FACTORY_CLASS_KEY_CACHE_UTIL = "com.ibm.ws.wim.env.ICacheUtil.className";
	String FACTORY_CLASS_KEY_ENCRYPT_UTIL = "com.ibm.ws.wim.env.IEncryptionUtil.className";
	String FACTORY_CLASS_KEY_SSL_UTIL = "com.ibm.ws.wim.env.ISSLUtil.className";
	String FACTORY_CLASS_KEY_TRANSACTION_UTIL = "com.ibm.ws.wim.env.ITransactionUtil.className";
	String FACTORY_CLASS_KEY_VAR_RESOLVER = "com.ibm.ws.wim.env.IVariableResolver.className";
	String FACTORY_CLASS_KEY_XML_DOC_BUILDER = "javax.xml.parsers.DocumentBuilderFactory.className";
}