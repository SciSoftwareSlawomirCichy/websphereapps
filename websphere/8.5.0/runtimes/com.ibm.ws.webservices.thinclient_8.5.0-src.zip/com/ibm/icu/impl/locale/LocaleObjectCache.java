package com.ibm.icu.impl.locale;

import com.ibm.icu.impl.locale.LocaleObjectCache.WeakValueRef;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.util.concurrent.ConcurrentHashMap;

public class LocaleObjectCache<K, V> {
	private ConcurrentHashMap<K, WeakValueRef<V>> _map = new ConcurrentHashMap();
	private ReferenceQueue<V> _rq = new ReferenceQueue();

	public V get(Object key) {
		this.expungeStaleEntries();
		WeakValueRef<V> ref = (WeakValueRef) this._map.get(key);
		return ref != null ? ref.get() : null;
	}

	public V put(K key, V value) {
		this.expungeStaleEntries();
		WeakValueRef<V> ref = (WeakValueRef) this._map.get(key);
		if (ref != null) {
			V valInCache = ref.get();
			if (valInCache != null) {
				return valInCache;
			}
		}

		this._map.put(key, new WeakValueRef(key, value, this._rq));
		return value;
	}

	private void expungeStaleEntries() {
		Reference val;
		while ((val = this._rq.poll()) != null) {
			Object key = ((WeakValueRef) val).getKey();
			this._map.remove(key);
		}

	}
}