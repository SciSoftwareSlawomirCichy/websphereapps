package com.ibm.ejs.container.util;

interface package-info {
}