package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ActivitySession.ActivitySessionAlreadyActiveException;
import com.ibm.websphere.ActivitySession.ActivitySessionPendingException;
import com.ibm.websphere.ActivitySession.ActivitySessionResetException;
import com.ibm.websphere.ActivitySession.ContextPendingException;
import com.ibm.websphere.ActivitySession.MixedOutcomeException;
import com.ibm.websphere.ActivitySession.NoActivitySessionException;
import com.ibm.websphere.ActivitySession.NotOriginatorException;
import com.ibm.websphere.ActivitySession.NotSupportedException;
import com.ibm.websphere.ActivitySession.SystemException;
import com.ibm.websphere.ActivitySession.TimeoutOutOfRangeException;
import com.ibm.websphere.ActivitySession.TransactionPendingException;
import com.ibm.websphere.ActivitySession.UserActivitySession;
import com.ibm.ws.ActivitySession.UserActivitySessionFactory;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.LocalTransaction.LocalTransactionCurrent;
import com.ibm.ws.Transaction.TransactionManagerFactory;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.ffdc.FFDCFilter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.rmi.RemoteException;

public final class UserActivitySessionWrapper implements UserActivitySession, Serializable {
	static final long serialVersionUID = -8304522672290578469L;
	private static final TraceComponent tc = Tr.register(UserActivitySessionWrapper.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.UserActivitySessionWrapper";
	private transient UserActivitySession userASImpl;
	private transient EJSContainer container;

	UserActivitySessionWrapper(UserActivitySession userASImpl, EJSContainer container) {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "UserActivitySessionWrapper.<init>");
		}

		this.userASImpl = userASImpl;
		this.container = container;
		if (entryEnabled) {
			Tr.exit(tc, "UserActivitySessionWrapper.<init>");
		}

	}

	private int getCurrentLocalTranBoundary(EJBThreadData threadData) {
		return threadData.getCallbackBeanO().home.beanMetaData.getLocalTranConfigData().getValueBoundary();
	}

	public void beginSession() throws ActivitySessionAlreadyActiveException, TransactionPendingException,
			NotSupportedException, SystemException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "UserActivitySessionWrapper.beginSession");
		}

		EJBThreadData threadData = EJSContainer.getUserTransactionThreadData();
		int localTxBoundary = this.getCurrentLocalTranBoundary(threadData);
		Exception e;
		if (localTxBoundary == 1) {
			LocalTransactionCurrent ltcCurrent;
			LocalTransactionCoordinator lCoord;
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				ltcCurrent = TransactionManagerFactory.getLocalTransactionCurrent();
				lCoord = ltcCurrent.getLocalTranCoord();
				if (lCoord != null) {
					Tr.event(tc, "AS Service will complete LTC cntxt: " + System.identityHashCode(lCoord));
				} else {
					Tr.event(tc, "AS Service will complete LTC cntxt: null Coordinator!");
				}
			}

			this.userASImpl.beginSession();
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "User Code began AS cntxt: " + this.userASImpl.getSessionName());
				ltcCurrent = TransactionManagerFactory.getLocalTransactionCurrent();
				lCoord = ltcCurrent.getLocalTranCoord();
				if (lCoord != null) {
					Tr.event(tc, "AS Service began LTC cntxt: " + System.identityHashCode(lCoord));
				} else {
					Tr.event(tc, "AS Service began LTC cntxt: null Coordinator!");
				}
			}

			try {
				this.container.processTxContextChange(threadData, true);
			} catch (Exception var9) {
				e = var9;

				try {
					this.userASImpl.setResetOnly();
					FFDCFilter.processException(e, "com.ibm.ejs.container.UserActivitySessionWrapper.endSession", "193",
							this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Exception during beginSession()", e);
					}
				} catch (NoActivitySessionException var6) {
					;
				}

				throw new SystemException(var9.getMessage());
			}
		} else {
			this.userASImpl.beginSession();
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "User Code began AS cntxt: " + this.userASImpl.getSessionName());
			}

			try {
				ContainerTx tx = this.container.getCurrentTx();
				tx.setContainerAS(this.container.getCurrentSessionalUOW(false));
			} catch (Exception var8) {
				e = var8;

				try {
					this.userASImpl.setResetOnly();
					FFDCFilter.processException(e, "com.ibm.ejs.container.UserActivitySessionWrapper.beginSession",
							"203", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Exception during beginSession()", e);
					}
				} catch (NoActivitySessionException var7) {
					;
				}

				throw new SystemException(var8.getMessage());
			}
		}

		if (entryEnabled) {
			Tr.exit(tc, "UserActivitySessionWrapper.beginSession");
		}

	}

	public void endSession(int EndMode) throws ActivitySessionPendingException, ContextPendingException,
			NoActivitySessionException, NotOriginatorException, MixedOutcomeException, ActivitySessionResetException,
			NotSupportedException, SystemException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "UserActivitySessionWrapper.endSession");
		}

		EJBThreadData threadData = EJSContainer.getUserTransactionThreadData();
		int localTxBoundary = this.getCurrentLocalTranBoundary(threadData);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			Tr.event(tc, "User Code ending AS cntxt: " + this.userASImpl.getSessionName());
		}

		UOWCurrent uowBeforeASEnd = TransactionManagerFactory.getUOWCurrent();
		boolean isGlobal = uowBeforeASEnd.getUOWCoord().isGlobal();
		if (!isGlobal && localTxBoundary == 1) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				LocalTransactionCurrent ltcCurrent = TransactionManagerFactory.getLocalTransactionCurrent();
				LocalTransactionCoordinator lCoord = ltcCurrent.getLocalTranCoord();
				if (lCoord != null) {
					Tr.event(tc, "AS Service will complete LTC cntxt: " + System.identityHashCode(lCoord));
				} else {
					Tr.event(tc, "AS Service will complete LTC cntxt: null Coordinator!");
				}
			}

			try {
				this.userASImpl.endSession(EndMode);
				this.changeToLocalContext(threadData);
			} catch (ActivitySessionResetException var10) {
				try {
					this.changeToLocalContext(threadData);
				} catch (Throwable var9) {
					FFDCFilter.processException(var9, "com.ibm.ejs.container.UserActivitySessionWrapper.endSession",
							"317", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "Exception during endSession()", var9);
					}

					throw new SystemException(var9.toString());
				}

				if (entryEnabled) {
					Tr.exit(tc, "UserActivitySessionWrapper.endSession");
				}

				throw var10;
			} catch (RemoteException var11) {
				FFDCFilter.processException(var11, "com.ibm.ejs.container.UserActivitySessionWrapper.endSession", "357",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "Exception during endSession()", var11);
				}

				throw new SystemException(var11.toString());
			}
		} else {
			this.userASImpl.endSession(EndMode);
		}

		if (entryEnabled) {
			Tr.exit(tc, "UserActivitySessionWrapper.endSession");
		}

	}

	public void resetSession() throws ActivitySessionPendingException, NoActivitySessionException,
			NotOriginatorException, NotSupportedException, SystemException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "UserActivitySessionWrapper.resetSession");
		}

		this.userASImpl.resetSession();
		if (entryEnabled) {
			Tr.exit(tc, "UserActivitySessionWrapper.resetSession");
		}

	}

	public void checkpointSession()
			throws ActivitySessionPendingException, NoActivitySessionException, NotOriginatorException,
			MixedOutcomeException, ActivitySessionResetException, NotSupportedException, SystemException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "UserActivitySessionWrapper.checkpointSession");
		}

		this.userASImpl.checkpointSession();
		if (entryEnabled) {
			Tr.exit(tc, "UserActivitySessionWrapper.checkpointSession");
		}

	}

	public int getStatus() throws SystemException {
		return this.userASImpl.getStatus();
	}

	public String getSessionName() throws SystemException {
		return this.userASImpl.getSessionName();
	}

	public void setSessionTimeout(int timeout) throws TimeoutOutOfRangeException, SystemException {
		this.userASImpl.setSessionTimeout(timeout);
	}

	public int getSessionTimeout() throws SystemException {
		return this.userASImpl.getSessionTimeout();
	}

	public void setResetOnly() throws NoActivitySessionException, SystemException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "UserActivitySessionWrapper.setResetOnly");
		}

		this.userASImpl.setResetOnly();
		if (entryEnabled) {
			Tr.exit(tc, "UserActivitySessionWrapper.setResetOnly");
		}

	}

	private void changeToLocalContext(EJBThreadData threadData) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			LocalTransactionCurrent ltcCurrent = TransactionManagerFactory.getLocalTransactionCurrent();
			LocalTransactionCoordinator lCoord = ltcCurrent.getLocalTranCoord();
			if (lCoord != null) {
				Tr.event(tc, "AS Service began LTC cntxt:  tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
			} else {
				Tr.event(tc, "AS Service began LTC cntxt: null Coordinator!");
			}
		}

		this.container.processTxContextChange(threadData, true);
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		EJSDeployedSupport s = EJSContainer.getMethodContext();
		if (s == null) {
			throw new IllegalStateException("UserActivitySession accessed outside EJB method");
		} else {
			this.container = s.getContainer();

			try {
				this.userASImpl = UserActivitySessionFactory.createUserActivitySession();
			} catch (Exception var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.container.UserActivitySessionWrapper.readObject", "582",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Exception creating UserActivitySessionImpl", var4);
				}

				throw new RuntimeException(var4);
			}
		}
	}
}