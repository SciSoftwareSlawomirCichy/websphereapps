package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.sql.SQLException;

class GenericPortabilityLayer extends PortabilityLayerImpl {
	private static final TraceComponent tc = Tr.register(GenericPortabilityLayer.class);
	private static GenericPortabilityLayer instance;

	protected GenericPortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
			Tr.exit(tc, "<init>");
		}

	}

	public static PortabilityLayer getInstance(DataSourceProperties dsProps) throws SQLException {
		if (instance == null) {
			instance = new GenericPortabilityLayer();
		}

		return instance;
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new GenericPortabilityLayer();
		}

		return instance;
	}
}