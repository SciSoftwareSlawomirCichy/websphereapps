package com.ibm.ejs.csi;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.dopriv.SystemGetPropertyPrivileged;
import com.ibm.websphere.csi.ResRef;
import com.ibm.websphere.csi.ResRefList;
import com.ibm.ws.resource.ResourceRefConfig;
import com.ibm.ws.resource.ResourceRefConfigList;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.util.ResRefAccessor;
import java.util.Iterator;
import java.util.Vector;

public class BasicResRefListImpl implements ResRefList, ResourceRefConfigList {
	protected Vector<ResRef> _resRefVector = new Vector();
	private static final TraceComponent tc = Tr.register(BasicResRefListImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public ResRef findByJNDIName(String s) {
		return ResRefAccessor.getResRef();
	}

	public ResRefImpl findByName(String s) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "findByName " + s);
		}

		Iterator<ResRef> resRefIterator = this._resRefVector.iterator();
		ResRefImpl resRef = null;
		if (s == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "null resource reference name");
			}

			return null;
		} else {
			while (resRefIterator.hasNext()) {
				resRef = (ResRefImpl) resRefIterator.next();
				if (s.equals(resRef.getName())) {
					break;
				}

				resRef = null;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				if (resRef == null) {
					Tr.debug(tc, "Resource with name '" + s + "' not found. Returning null.");
				} else {
					Tr.debug(tc, "Returning " + resRef.toString());
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "findByName " + s);
			}

			return resRef;
		}
	}

	public ResRefImpl findOrAddByName(String name) {
		ResRefImpl result = this.findByName(name);
		if (name != null) {
			if (result == null) {
				result = new ResRefImpl(name);
				this.add(result);
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc,
					"Null Resource Ref name.  Typically this happens because the resource-reference in the extension.xmi file has an id that does not match any EJB defined in the ejb-jar.xml.");
		}

		return result;
	}

	public int size() {
		return this._resRefVector.size();
	}

	public ResRef get(int i) {
		ResRef resRef = null;
		if (i > -1 && i < this._resRefVector.size()) {
			resRef = (ResRef) this._resRefVector.get(i);
		}

		return resRef;
	}

	public ResourceRefConfig getResourceRefConfig(int i) {
		return (ResourceRefConfig) this._resRefVector.get(i);
	}

	public String toString() {
		String separator = (String) AccessController
				.doPrivileged(new SystemGetPropertyPrivileged("line.separator", "\n"));
		String sep = "                                 ";
		StringBuffer sb = new StringBuffer();
		int size = this._resRefVector.size();
		sb.append(separator + sep + "    ******* ResRefList ******* ");
		sb.append(separator + sep + "ResRefList size=" + size);

		for (int i = 0; i < size; ++i) {
			sb.append(((ResRefImpl) this._resRefVector.get(i)).toString());
		}

		return sb.toString();
	}

	public void add(ResRef resRef) {
		this._resRefVector.add(resRef);
	}
}