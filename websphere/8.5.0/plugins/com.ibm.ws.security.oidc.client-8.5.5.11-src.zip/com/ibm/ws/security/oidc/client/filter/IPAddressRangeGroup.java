package com.ibm.ws.security.oidc.client.filter;

import java.net.InetAddress;
import java.util.Iterator;
import java.util.LinkedList;

public class IPAddressRangeGroup {
	LinkedList<IPAddressRange> ranges = new LinkedList();

	public void addRange(String rangeStr) throws FilterException {
		IPAddressRange range = new IPAddressRange(rangeStr);
		this.ranges.add(range);
	}

	public boolean inRange(InetAddress ip) throws FilterException {
		Iterator iter = this.ranges.iterator();

		IPAddressRange range;
		do {
			if (!iter.hasNext()) {
				return false;
			}

			range = (IPAddressRange) iter.next();
		} while (!range.inRange(ip));

		return true;
	}
}