package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIAccessException;
import com.ibm.websphere.csi.CSIActivityCompletedException;
import com.ibm.websphere.csi.CSIActivityRequiredException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSIInvalidActivityException;
import com.ibm.websphere.csi.CSIInvalidTransactionException;
import com.ibm.websphere.csi.CSINoSuchObjectException;
import com.ibm.websphere.csi.CSITransactionRequiredException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.websphere.ejbcontainer.EJBStoppedException;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.javax.activity.ActivityCompletedException;
import com.ibm.ws.javax.activity.ActivityRequiredException;
import com.ibm.ws.javax.activity.InvalidActivityException;
import com.ibm.ws.javax.ejb.ActivityCompletedLocalException;
import com.ibm.ws.javax.ejb.ActivityRequiredLocalException;
import com.ibm.ws.javax.ejb.InvalidActivityLocalException;
import java.rmi.AccessException;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.AccessLocalException;
import javax.ejb.EJBException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.TransactionRequiredLocalException;
import javax.ejb.TransactionRolledbackLocalException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.InvalidTransactionException;
import javax.transaction.TransactionRequiredException;
import javax.transaction.TransactionRolledbackException;

public class LocalExceptionMappingStrategy extends ExceptionMappingStrategy {
	private static final String CLASS_NAME = LocalExceptionMappingStrategy.class.getName();
	private static final TraceComponent tc = Tr.register(LocalExceptionMappingStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	static final ExceptionMappingStrategy INSTANCE = new LocalExceptionMappingStrategy();

	private EJBException mapCSIException(EJSDeployedSupport s, CSIException e, Exception rootEx) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "mapCSIException: " + e);
		}

		String message = " ";
		Object ejbex;
		if (e instanceof CSITransactionRolledbackException) {
			if (e.detail instanceof HeuristicMixedException) {
				ejbex = ExceptionUtil.EJBException(message, rootEx);
			} else if (ContainerProperties.IncludeNestedExceptionsExtended
					&& (s.began || ContainerProperties.AllowSpecViolationOnRollback)
					&& e.detail instanceof HeuristicRollbackException) {
				ejbex = ExceptionUtil.EJBException(message, rootEx);
			} else {
				ejbex = new TransactionRolledbackLocalException(message, rootEx);
			}
		} else if (e instanceof CSIAccessException) {
			ejbex = new AccessLocalException(message, rootEx);
		} else if (e instanceof CSIInvalidTransactionException) {
			ejbex = new InvalidTransactionLocalException(message, rootEx);
		} else if (e instanceof CSINoSuchObjectException) {
			ejbex = new NoSuchObjectLocalException(message, rootEx);
		} else if (e instanceof CSITransactionRequiredException) {
			ejbex = new TransactionRequiredLocalException(message);
		} else if (e instanceof CSIInvalidActivityException) {
			ejbex = new InvalidActivityLocalException(message, rootEx);
		} else if (e instanceof CSIActivityRequiredException) {
			ejbex = new ActivityRequiredLocalException(message, rootEx);
		} else if (e instanceof CSIActivityCompletedException) {
			ejbex = new ActivityCompletedLocalException(message, rootEx);
		} else if (rootEx instanceof EJBException) {
			ejbex = (EJBException) rootEx;
		} else {
			ejbex = ExceptionUtil.EJBException(rootEx);
		}

		if (rootEx != null && rootEx != ejbex && ((EJBException) ejbex).getCause() == null) {
			((EJBException) ejbex).initCause(rootEx);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "mapCSIException returning: " + ejbex);
		}

		return (EJBException) ejbex;
	}

	private EJBException mapException(EJSDeployedSupport s, Throwable ex) {
		String message = null;
		Exception rootEx = ExceptionUtil.Exception(s.rootEx);
		Object ejbex;
		if (ex instanceof CSIException) {
			ejbex = this.mapCSIException(s, (CSIException) ex, rootEx);
		} else if (ex instanceof NoSuchObjectException) {
			ejbex = new NoSuchObjectLocalException((String) message, rootEx);
		} else if (ex instanceof EJBStoppedException) {
			ejbex = new NoSuchObjectLocalException((String) message, rootEx);
		} else if (ex instanceof HomeDisabledException) {
			ejbex = new NoSuchObjectLocalException((String) message, rootEx);
		} else if (ex instanceof TransactionRequiredException) {
			ejbex = new TransactionRequiredLocalException((String) message);
		} else if (ex instanceof TransactionRolledbackException) {
			ejbex = new TransactionRolledbackLocalException((String) message, rootEx);
		} else if (ex instanceof InvalidTransactionException) {
			ejbex = new InvalidTransactionLocalException((String) message, rootEx);
		} else if (ex instanceof AccessException) {
			ejbex = new AccessLocalException((String) message, rootEx);
		} else if (ex instanceof ActivityRequiredException) {
			ejbex = new ActivityRequiredLocalException((String) message, rootEx);
		} else if (ex instanceof InvalidActivityException) {
			ejbex = new InvalidActivityLocalException((String) message, rootEx);
		} else if (ex instanceof ActivityCompletedException) {
			ejbex = new ActivityCompletedLocalException((String) message, rootEx);
		} else if (ex instanceof EJBException) {
			ejbex = ExceptionUtil.EJBException(ex);
		} else if (ex instanceof RemoteException) {
			if (((RemoteException) ex).detail instanceof EJBException) {
				ejbex = ExceptionUtil.EJBException(ex);
			} else {
				ejbex = ExceptionUtil.EJBException(rootEx);
			}
		} else if (ex instanceof IllegalArgumentException) {
			ejbex = ExceptionUtil.EJBException(rootEx);
		} else {
			ejbex = new UnknownLocalException((String) message, rootEx);
		}

		if (rootEx != null && rootEx != ejbex && ((EJBException) ejbex).getCause() == null) {
			((EJBException) ejbex).initCause(rootEx);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "mapException returning: " + ejbex);
		}

		return (EJBException) ejbex;
	}

	public final Throwable setUncheckedException(EJSDeployedSupport s, Throwable ex) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "setUncheckedException in param:" + ex);
		}

		if (s.ivException != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "setting unchecked exception again", ex);
				Tr.event(tc, "original exception", s.ivException);
				Tr.exit(tc, "setUncheckedException returning: " + s.ivException);
			}

			return s.ivException;
		} else {
			Boolean applicationExceptionRollback = null;
			int moduleVersion = s.ivWrapper.bmd.ivModuleVersion;
			if (moduleVersion >= 30 && ex instanceof Exception && !(ex instanceof RemoteException)) {
				applicationExceptionRollback = s.getApplicationExceptionRollback((Throwable) ex);
			}

			if (applicationExceptionRollback != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "ApplicationException with rollback set to true, changing to a checked exception", ex);
				}

				s.exType = ExceptionType.CHECKED_EXCEPTION;
				s.ivException = (Throwable) ex;
				s.rootEx = (Throwable) ex;
				if (applicationExceptionRollback == Boolean.TRUE) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "ApplicationException with rollback set to true, setting rollback only", ex);
					}

					s.currentTx.setRollbackOnly();
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "setUncheckedException returning: " + s.ivException);
				}

				return s.ivException;
			} else {
				if (s.preInvokeException
						&& (ex instanceof NoSuchObjectException || ex instanceof EJBStoppedException
								|| ex instanceof HomeDisabledException || ex instanceof CSIAccessException
								|| ex instanceof BeanNotReentrantException)
						|| !s.preInvokeException
								&& s.methodInfo.isCMRSetMethod && ex instanceof IllegalArgumentException
						|| ex instanceof HomeDisabledException
						|| ex instanceof CreateFailureException
								&& (((Throwable) ex).getCause() instanceof HomeDisabledException
										|| ((Throwable) ex).getCause() instanceof EJBStoppedException)) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception should not cause rollback, changing to checked exception");
					}

					if (ex instanceof BeanNotReentrantException) {
						s.beanO = null;
					}

					s.exType = ExceptionType.CHECKED_EXCEPTION;
				} else if (EJSContainer.defaultContainer == null) {
					s.exType = ExceptionType.UNCHECKED_EXCEPTION;
					ex = new EJBException(
							"The Enterprise JavaBeans (EJB) features have been deactivated. No further EJB processing is allowed");
					ExceptionUtil.logException(tc, (Throwable) ex, s.getEJBMethodMetaData(), s.getBeanO());
				} else {
					s.exType = ExceptionType.UNCHECKED_EXCEPTION;
					ExceptionUtil.logException(tc, (Throwable) ex, s.getEJBMethodMetaData(), s.getBeanO());
					FFDCFilter.processException((Throwable) ex, CLASS_NAME + ".setUncheckedException", "178", this);
				}

				s.rootEx = this.findRootCause((Throwable) ex);
				s.ivException = this.mapException(s, (Throwable) ex);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "setUncheckedException returning: " + s.ivException);
				}

				s.ivException.setStackTrace(s.rootEx.getStackTrace());
				return s.ivException;
			}
		}
	}

	public Exception mapCSITransactionRolledBackException(EJSDeployedSupport s, CSITransactionRolledbackException ex)
			throws CSIException {
		if (s.rootEx == null) {
			s.rootEx = ExceptionUtil.findRootCause(ex);
		}

		Exception mappedEx = this.mapException(s, ex);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "MappedException = " + mappedEx);
		}

		mappedEx.setStackTrace(s.rootEx.getStackTrace());
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "returning: " + mappedEx);
		}

		return mappedEx;
	}
}