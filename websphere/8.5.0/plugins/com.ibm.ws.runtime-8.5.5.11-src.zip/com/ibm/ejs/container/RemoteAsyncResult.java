package com.ibm.ejs.container;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public interface RemoteAsyncResult extends Remote {
	boolean cancel(boolean var1) throws RemoteException;

	Object get() throws CancellationException, ExecutionException, InterruptedException, RemoteException;

	Object get(long var1, String var3)
			throws CancellationException, ExecutionException, InterruptedException, TimeoutException, RemoteException;

	boolean isCancelled() throws RemoteException;

	boolean isDone() throws RemoteException;
}