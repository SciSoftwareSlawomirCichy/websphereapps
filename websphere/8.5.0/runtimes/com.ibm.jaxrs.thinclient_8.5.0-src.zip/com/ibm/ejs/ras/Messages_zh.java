package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_zh extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: 检测到已安装的应用程序服务器客户机组件的构建级别不一致。已安装的客户机组件 {0} 的构建级别是 {1}，此级别与客户机组件 {2} 的构建级别 {3} 不同。"},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E", "CWSJE0002E: 已安装的应用程序服务器客户机组件的构建级别不一致，导致无法继续执行。"},
			{"EXCP_CWSJE0003E", "CWSJE0003E: 由于发生以下异常，因此无法访问资源 {1}：{0}"}};

	public Object[][] getContents() {
		return resources;
	}
}