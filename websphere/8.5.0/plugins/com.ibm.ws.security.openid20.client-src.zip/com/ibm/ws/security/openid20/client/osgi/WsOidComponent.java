package com.ibm.ws.security.openid20.client.osgi;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.exception.RuntimeError;
import com.ibm.ws.exception.RuntimeWarning;
import com.ibm.wsspi.runtime.component.WsComponentImpl;

public class WsOidComponent extends WsComponentImpl {
	private static TraceComponent tc = Tr.register(WsOidComponent.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");

	public void start() throws RuntimeError, RuntimeWarning {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "start");
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "nothing to do for WsOidcClientComponent start()");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "start");
		}

	}

	public void stop() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "stop");
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "nothing to do for WsOidcClientComponent stop()");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "stop");
		}

	}
}