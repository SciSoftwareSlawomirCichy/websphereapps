package com.ibm.ws.wim.configmodel;

public interface ContextPoolType {
	boolean isEnabled();

	void setEnabled(boolean var1);

	void unsetEnabled();

	boolean isSetEnabled();

	int getInitPoolSize();

	void setInitPoolSize(int var1);

	void unsetInitPoolSize();

	boolean isSetInitPoolSize();

	int getMaxPoolSize();

	void setMaxPoolSize(int var1);

	void unsetMaxPoolSize();

	boolean isSetMaxPoolSize();

	int getPoolTimeOut();

	void setPoolTimeOut(int var1);

	void unsetPoolTimeOut();

	boolean isSetPoolTimeOut();

	int getPoolWaitTime();

	void setPoolWaitTime(int var1);

	void unsetPoolWaitTime();

	boolean isSetPoolWaitTime();

	int getPrefPoolSize();

	void setPrefPoolSize(int var1);

	void unsetPrefPoolSize();

	boolean isSetPrefPoolSize();
}