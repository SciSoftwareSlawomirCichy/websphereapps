package com.ibm.ffdc.config;

import com.ibm.ffdc.config.IncidentStream.Writer;
import java.io.OutputStream;

public interface IncidentStream {
	void write(String var1, Object var2);

	void write(String var1, Object var2, int var3);

	void write(Writer<OutputStream> var1);
}