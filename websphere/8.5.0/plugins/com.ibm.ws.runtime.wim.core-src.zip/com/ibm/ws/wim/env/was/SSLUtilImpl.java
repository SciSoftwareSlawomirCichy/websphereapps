package com.ibm.ws.wim.env.was;

import com.ibm.websphere.ssl.JSSEHelper;
import com.ibm.websphere.ssl.SSLConfigChangeListener;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.env.ISSLUtil;
import java.net.URL;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SSLUtilImpl implements ISSLUtil {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public Properties getSSLPropertiesOnThread() {
		return JSSEHelper.getInstance().getSSLPropertiesOnThread();
	}

	public void setSSLPropertiesOnThread(Properties var1) {
		JSSEHelper.getInstance().setSSLPropertiesOnThread(var1);
	}

	public void setSSLAlias(String var1, Hashtable var2) throws WIMConfigurationException {
		trcLogger.entering(CLASSNAME, "setSSLAlias");

		try {
			HashMap var4 = null;
			String var6 = (String) var2.get("java.naming.provider.url");
			if (var6 != null) {
				StringTokenizer var7 = new StringTokenizer(var6);
				var6 = var7.nextToken();
				var6 = var6.replaceFirst("ldap", "http");
				URL var8 = new URL(var6);
				var4 = new HashMap();
				var4.put("com.ibm.ssl.direction", "outbound");
				var4.put("com.ibm.ssl.remoteHost", var8.getHost());
				var4.put("com.ibm.ssl.remotePort", var8.getPort() == -1 ? "636" : Integer.toString(var8.getPort()));
			}

			Properties var5;
			if (var4 != null) {
				var5 = JSSEHelper.getInstance().getProperties(var1, var4, (SSLConfigChangeListener) null);
			} else {
				var5 = JSSEHelper.getInstance().getProperties(var1);
			}

			JSSEHelper.getInstance().setSSLPropertiesOnThread(var5);
			trcLogger.logp(Level.FINE, CLASSNAME, "setSSLAlias", "Properties for SSL Alias '" + var1 + "':" + var5);
		} catch (Exception var9) {
			throw new WIMConfigurationException("INVALID_INIT_PROPERTY",
					WIMMessageHelper.generateMsgParms("sslConfiguration"), CLASSNAME, "setSSLAlias", var9);
		}

		trcLogger.exiting(CLASSNAME, "setSSLAlias");
	}

	public void resetSSLAlias() {
		JSSEHelper.getInstance().setSSLPropertiesOnThread((Properties) null);
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010;
		CLASSNAME = SSLUtilImpl.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}