package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_hu extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: Az OpenID megbízható partner (RP) nem tudta átirányítani a felhasználót az OpenID szolgáltatóhoz (OP) hitelesítésre a következő kivétel miatt: [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: Az OpenID megbízható partner (RP) inicializálása meghiúsult, mert nem sikerült beolvasni a WebSphere kiszolgáló alapértelmezett SSLContext értékét. A kivétel: [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: Az OpenID megbízható partner (RP) nem tudott csatlakozni a(z) [{0}] azonosítóval megadott OpenID szolgáltatóhoz a következő kivétel miatt: [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: Az OpenID megbízható partner (RP) inicializálása meghiúsult a következő kivétel miatt: [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: Az OpenID megbízható partner (RP) inicializálása meghiúsult, mert a(z) [{0}] tulajdonság értéke hibásan van formázva."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: Az OpenID megbízható partner (RP) nem tudott hitelesíteni egy kérést az alapszintű hitelesítési tokennel, mert a token értéke nem érvényes."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: Az OpenID megbízható partner (RP) inicializálása meghiúsult, mert a(z) [{0}] tulajdonság hibásan van megadva. Érvényes URL címnek kell lennie."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: Az OpenID megbízható partner (RP) érvénytelen választ kapott az OpenID szolgáltatótól (OP). A hiba oka: [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: Az OpenID megbízható partner (RP) nem tudta elvégezni a hitelesítést, mert elérte a belső gyorsítótár maximális kapacitását."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: Az OpenID megbízható partner (RP) inicializálása meghiúsult, mert az axRequiredAttribute[n] kötelező tulajdonság hiányzik. Legalább egy tulajdonságot meg kell határozni."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: Az OpenID megbízható partner (RP) inicializálása meghiúsult, mert a(z) [{0}] kötelező tulajdonság értéke hiányzik vagy üres."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: Az OpenID megbízható partner (RP) SSL-t (HTTPS) igényel, de az OpenID szolgáltató (OP) URL címe HTTP: [{0}].  A(z) [{1}] attribútumnak meg kell egyeznie a cél URL sémával. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: Az OpenID megbízható partner (RP) olyan választ kapott az OpenID szolgáltatótól (OP), amely nem támogatja az OpenID specifikáció 2-es verzióját."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: Az OpenID megbízható partner (RP) meghiúsult az OpenID szolgáltatótól (OP) kapott válasz ellenőrzése során. A kivétel: [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}