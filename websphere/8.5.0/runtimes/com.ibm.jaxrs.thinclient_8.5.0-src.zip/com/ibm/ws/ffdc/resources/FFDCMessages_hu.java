package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_hu extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Az elemző alrendszer által használt adatbázis: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: FFDC incidens lett kiadva a következő helyen: {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: FFDC naplófájl-felügyelet megpróbálta törölni a(z) {0} fájlt."},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: Az FFDC naplófájl-felügyelet eltávolított {0} fájl a(z) {1} közül, amelyek elérték a beállított maximális élettartamot."},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: Az FFDC naplófájl-felügyelet nem tudta törölni a(z) {0} fájlt."},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: Az FFDC naplófájl-felügyelet nem tudta lekérni a kivételfájlok listáját"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: Az FFDC bezárta az incidens folyamfájlt: {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: Az FFDC incidens folyamfájlt nyitott meg: {0}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: Az FFDC nem tudta bezárni az incidens folyamfájlt: {0}, kapott kivétel: {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: Az FFDC nem tudta megnyitni vagy bezárni az incidens folyamfájlt: {0}, kapott kivétel: {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: Az FFDC nem tudta írni az incidens folyamfájlt: {0}, kapott kivétel: {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}