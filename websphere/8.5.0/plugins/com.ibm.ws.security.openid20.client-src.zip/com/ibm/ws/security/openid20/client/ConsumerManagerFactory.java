package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.openid20.util.OidUtil;
import javax.net.ssl.SSLContext;
import org.openid4java.association.AssociationException;
import org.openid4java.association.AssociationSessionType;
import org.openid4java.consumer.ConsumerManager;
import org.openid4java.consumer.InMemoryConsumerAssociationStore;
import org.openid4java.consumer.InMemoryNonceVerifier;
import org.openid4java.discovery.Discovery;
import org.openid4java.discovery.html.HtmlResolver;
import org.openid4java.discovery.xri.XriResolver;
import org.openid4java.discovery.yadis.YadisResolver;
import org.openid4java.server.RealmVerifierFactory;
import org.openid4java.util.HttpFetcherFactory;

public class ConsumerManagerFactory {
	private static final TraceComponent tc = Tr.register(ConsumerManagerFactory.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private ConsumerManager consumerManager;

	public ConsumerManagerFactory(ConsumerManager consumerManager) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "ConsumerManagerFactory(consumerManager[" + OidUtil.getObjState(consumerManager) + "])");
		}

		this.consumerManager = consumerManager;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addToSubjectAsPublicCredentials");
		}

	}

	public ConsumerManager getConsumerManager(OpenIDClientConfig openidClientConfig, SSLContext sslContext) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getConsumerManager(openidClientConfig[" + OidUtil.getObjState(openidClientConfig)
					+ "],sslContext[" + OidUtil.getObjState(sslContext) + "])");
		}

		HttpFetcherFactory httpFetcherFactory = this.getHttpFetcherFactory(sslContext, openidClientConfig);
		YadisResolver yadisResolver = new YadisResolver(httpFetcherFactory);
		RealmVerifierFactory realmFactory = new RealmVerifierFactory(yadisResolver);
		HtmlResolver htmlResolver = new HtmlResolver(httpFetcherFactory);
		XriResolver xriResolver = Discovery.getXriResolver();
		Discovery discovery = new Discovery(htmlResolver, yadisResolver, xriResolver);
		this.consumerManager = this.createConsumerManager(httpFetcherFactory, realmFactory, discovery,
				openidClientConfig);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc,
					"getConsumerManager returns consumerManager [" + OidUtil.getObjState(this.consumerManager) + "]");
		}

		return this.consumerManager;
	}

	protected ConsumerManager createConsumerManager(HttpFetcherFactory httpFetcherFactory,
			RealmVerifierFactory realmFactory, Discovery discovery, OpenIDClientConfig openidClientConfig) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc,
					"createConsumerManager(httpFetcherFactory[" + OidUtil.getObjState(httpFetcherFactory)
							+ "],realmFactory[" + OidUtil.getObjState(realmFactory) + "],discovery["
							+ OidUtil.getObjState(discovery) + "],openidClientConfig["
							+ OidUtil.getObjState(openidClientConfig) + "])");
		}

		ConsumerManager cm = new ConsumerManager(realmFactory, discovery, httpFetcherFactory);
		cm.setSocketTimeout((int) openidClientConfig.getSocketTimeout());
		cm.setConnectTimeout((int) openidClientConfig.getConnectTimeout());
		cm.setAllowStateless(openidClientConfig.getAllowStateless());
		cm.setMaxAssocAttempts(openidClientConfig.getMaxAssociationAttemps());
		AssociationSessionType associationSessionType = null;
		if (openidClientConfig.getMaxAssociationAttemps() > 0) {
			try {
				associationSessionType = AssociationSessionType.create(openidClientConfig.getSessionEncryptionType(),
						openidClientConfig.getSignatureAlgorithm());
				cm.setPrefAssocSessEnc(associationSessionType);
				cm.setMinAssocSessEnc(associationSessionType);
			} catch (AssociationException var8) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Un-expected exception while performing association type create", var8);
				}
			}
		}

		cm.setAssociations(new InMemoryConsumerAssociationStore());
		cm.setNonceVerifier(new InMemoryNonceVerifier((int) openidClientConfig.getNonceValidTime()));
		cm.setMaxNonceAge((int) openidClientConfig.getNonceValidTime());
		if ("checkid_immediate".equals(openidClientConfig.getAuthenticationMode())) {
			cm.setImmediateAuth(true);
		} else {
			cm.setImmediateAuth(false);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isImmediateAuth:" + cm.isImmediateAuth());
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createConsumerManager returns consumerManager [" + OidUtil.getObjState(cm) + "]");
		}

		return cm;
	}

	protected HttpFetcherFactory getHttpFetcherFactory(SSLContext sslContext, OpenIDClientConfig openidClientConfig) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getHttpFetcherFactory(sslContext[" + OidUtil.getObjState(sslContext) + "],openidClientConfig["
					+ OidUtil.getObjState(openidClientConfig) + "])");
		}

		HttpFetcherFactory httpFetcherFactory = null;
		if (openidClientConfig.isHostNameVerificationEnabled()) {
			httpFetcherFactory = new OpenIDHttpFetcherFactory(sslContext, openidClientConfig);
		} else {
			httpFetcherFactory = new OpenIDHttpFetcherFactory(sslContext, new OpenIDDefaultHostnameVerifier(),
					openidClientConfig);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getHttpFetcherFactory returns HttpFetcherFactory [" + OidUtil.getObjState(httpFetcherFactory)
					+ "]");
		}

		return httpFetcherFactory;
	}
}