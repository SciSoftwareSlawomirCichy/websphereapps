package com.ibm.ws.wim.configmodel;

public interface PropertyExtensionRepositoryType extends RepositoryType {
	String getDatabaseType();

	void setDatabaseType(String var1);

	String getDataSourceName();

	void setDataSourceName(String var1);

	String getDbAdminId();

	void setDbAdminId(String var1);

	String getDbAdminPassword();

	void setDbAdminPassword(String var1);

	String getDbURL();

	void setDbURL(String var1);

	String getDbSchema();

	void setDbSchema(String var1);

	int getEntityRetrievalLimit();

	void setEntityRetrievalLimit(int var1);

	void unsetEntityRetrievalLimit();

	boolean isSetEntityRetrievalLimit();

	String getJDBCDriverClass();

	void setJDBCDriverClass(String var1);
}