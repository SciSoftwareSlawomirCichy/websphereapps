package com.ibm.ws.wim.adapter.urbridge;

import com.ibm.websphere.security.UserRegistry;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import commonj.sdo.DataObject;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class URBridgeEntityFactory {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	public static final String CLASSNAME = URBridgeEntityFactory.class.getName();
	private static final Logger trcLogger;

	public URBridgeEntity createObject(DataObject var1, UserRegistry var2, Map var3, String var4, Map var5)
			throws WIMException {
		boolean var7 = trcLogger.isLoggable(Level.FINER);
		if (var7) {
			trcLogger.entering(CLASSNAME, "createObject", WIMTraceHelper.printDataGraph(var1));
		}

		String var8 = var1.getType().getName();
		Object var9 = null;
		if (URBridgeHelper.isSuperType("Group", var8)) {
			var9 = new URBridgeGroup(var1, var2, var3, var4, var5);
		} else {
			if (!URBridgeHelper.isSuperType("LoginAccount", var8)) {
				throw new WIMApplicationException("ENTITY_TYPE_NOT_SUPPORTED", WIMMessageHelper.generateMsgParms(var8),
						Level.WARNING, CLASSNAME, "createObject");
			}

			var9 = new URBridgePerson(var1, var2, var3, var4, var5);
		}

		if (var7) {
			trcLogger.exiting(CLASSNAME, "createObject", WIMTraceHelper.printDataGraph(var1));
		}

		return (URBridgeEntity) var9;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}