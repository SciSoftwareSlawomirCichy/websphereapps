package com.google.common.base;

import com.google.common.annotations.GwtIncompatible;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtIncompatible
public final class Defaults {
	private static final Double DOUBLE_DEFAULT = 0.0;
	private static final Float FLOAT_DEFAULT = 0.0F;

	private Defaults() {
	}

	@NullableDecl
	public static <T> T defaultValue(Class<T> type) {
		Preconditions.checkNotNull(type);
		if (type == Boolean.TYPE) {
			return Boolean.FALSE;
		} else if (type == Character.TYPE) {
			return ' ';
		} else if (type == Byte.TYPE) {
			return 0;
		} else if (type == Short.TYPE) {
			return Short.valueOf((short) 0);
		} else if (type == Integer.TYPE) {
			return 0;
		} else if (type == Long.TYPE) {
			return 0L;
		} else if (type == Float.TYPE) {
			return FLOAT_DEFAULT;
		} else {
			return type == Double.TYPE ? DOUBLE_DEFAULT : null;
		}
	}
}