package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.util.provider.IncidentEntry.1;
import com.ibm.ffdc.util.provider.IncidentEntry.Key;
import com.ibm.ffdc.util.provider.IncidentEntry.STATE;
import java.lang.ref.WeakReference;
import java.util.Date;

public final class IncidentEntry implements Incident {
	private final Key key;
	private final WeakReference<ClassLoader> classLoaderRef;
	private int count = 1;
	private long timeStamp;
	private final Date dateOfFirstOccurrence;
	private STATE state;
	private static final int MAXLABELLENGTH = 1024;
	private String label;

	IncidentEntry(Key key, ClassLoader cldr) {
		this.state = STATE.READY_TO_LOG;
		this.key = key;
		this.timeStamp = System.currentTimeMillis();
		this.dateOfFirstOccurrence = new Date(this.timeStamp);
		this.count = 1;
		this.classLoaderRef = cldr == null ? null : new WeakReference(cldr);
	}

	public synchronized void increment() {
		++this.count;
		this.timeStamp = System.currentTimeMillis();
	}

	synchronized boolean tag() {
      switch(1.$SwitchMap$com$ibm$ffdc$util$provider$IncidentEntry$STATE[this.state.ordinal()]) {
      case 1:
         this.state = STATE.ABOUT_TO_LOG;
         return true;
      default:
         return false;
      }
   }

	private synchronized boolean allowIncidentLogging() {
		if (this.state != STATE.ALREADY_LOGGED) {
			this.state = STATE.ALREADY_LOGGED;
			return true;
		} else {
			return false;
		}
	}

	protected void log(FfdcProvider provider, Object reporter, Throwable th, Object[] capturedDataElements) {
		if (this.allowIncidentLogging()) {
			try {
				provider.log(this, reporter, th, capturedDataElements);
			} catch (Throwable var6) {
				provider.ffdcerror(var6);
			}
		}

	}

	public int getCount() {
		return this.count;
	}

	public String getSourceId() {
		return Key.access$000(this.key);
	}

	public String getProbeId() {
		return Key.access$100(this.key);
	}

	public String getExceptionName() {
		return Key.access$200(this.key);
	}

	public boolean hasSameClassLoader(ClassLoader cldr) {
		return cldr == null
				? this.classLoaderRef == null
				: this.classLoaderRef != null && this.classLoaderRef.get() == cldr;
	}

	public synchronized long getTimeStamp() {
		return this.timeStamp;
	}

	public Date getDateOfFirstOccurrence() {
		return this.dateOfFirstOccurrence;
	}

	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		if (label != null) {
			if (label.length() <= 1024) {
				this.label = label;
			} else {
				int discarded = label.length() - 1024;
				this.label = label.substring(0, 1024) + " ...characters cut off:" + discarded;
			}
		}
	}

	public void unblockLogging() {
		this.state = STATE.READY_TO_LOG;
	}
}