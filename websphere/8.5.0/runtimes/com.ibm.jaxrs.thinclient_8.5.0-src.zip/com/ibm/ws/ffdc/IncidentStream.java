package com.ibm.ws.ffdc;

public interface IncidentStream {
	void write(String var1, boolean var2);

	void write(String var1, byte var2);

	void write(String var1, char var2);

	void write(String var1, short var2);

	void write(String var1, int var2);

	void write(String var1, long var2);

	void write(String var1, float var2);

	void write(String var1, double var2);

	void write(String var1, String var2);

	void write(String var1, Object var2);

	void introspectAndWrite(String var1, Object var2);

	void introspectAndWrite(String var1, Object var2, int var3);

	void introspectAndWrite(String var1, Object var2, int var3, int var4);

	void writeLine(String var1, boolean var2);

	void writeLine(String var1, byte var2);

	void writeLine(String var1, char var2);

	void writeLine(String var1, short var2);

	void writeLine(String var1, int var2);

	void writeLine(String var1, long var2);

	void writeLine(String var1, float var2);

	void writeLine(String var1, double var2);

	void writeLine(String var1, String var2);

	void writeLine(String var1, Object var2);

	void introspectAndWriteLine(String var1, Object var2);

	void introspectAndWriteLine(String var1, Object var2, int var3);

	void introspectAndWriteLine(String var1, Object var2, int var3, int var4);
}