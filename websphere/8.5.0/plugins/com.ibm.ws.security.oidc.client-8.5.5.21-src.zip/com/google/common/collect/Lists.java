package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists.1;
import com.google.common.collect.Lists.2;
import com.google.common.collect.Lists.AbstractListWrapper;
import com.google.common.collect.Lists.CharSequenceAsList;
import com.google.common.collect.Lists.OnePlusArrayList;
import com.google.common.collect.Lists.Partition;
import com.google.common.collect.Lists.RandomAccessPartition;
import com.google.common.collect.Lists.RandomAccessReverseList;
import com.google.common.collect.Lists.ReverseList;
import com.google.common.collect.Lists.StringAsImmutableList;
import com.google.common.collect.Lists.TransformingRandomAccessList;
import com.google.common.collect.Lists.TransformingSequentialList;
import com.google.common.collect.Lists.TwoPlusArrayList;
import com.google.common.primitives.Ints;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import java.util.concurrent.CopyOnWriteArrayList;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
public final class Lists {
	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayList() {
		return new ArrayList();
	}

	@SafeVarargs
	@CanIgnoreReturnValue
	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayList(E... elements) {
		Preconditions.checkNotNull(elements);
		int capacity = computeArrayListCapacity(elements.length);
		ArrayList<E> list = new ArrayList(capacity);
		Collections.addAll(list, elements);
		return list;
	}

	@CanIgnoreReturnValue
	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayList(Iterable<? extends E> elements) {
		Preconditions.checkNotNull(elements);
		return elements instanceof Collection
				? new ArrayList(Collections2.cast(elements))
				: newArrayList(elements.iterator());
	}

	@CanIgnoreReturnValue
	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayList(Iterator<? extends E> elements) {
		ArrayList<E> list = newArrayList();
		Iterators.addAll(list, elements);
		return list;
	}

	@VisibleForTesting
	static int computeArrayListCapacity(int arraySize) {
		CollectPreconditions.checkNonnegative(arraySize, "arraySize");
		return Ints.saturatedCast(5L + (long) arraySize + (long) (arraySize / 10));
	}

	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayListWithCapacity(int initialArraySize) {
		CollectPreconditions.checkNonnegative(initialArraySize, "initialArraySize");
		return new ArrayList(initialArraySize);
	}

	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayListWithExpectedSize(int estimatedSize) {
		return new ArrayList(computeArrayListCapacity(estimatedSize));
	}

	@GwtCompatible(serializable = true)
	public static <E> LinkedList<E> newLinkedList() {
		return new LinkedList();
	}

	@GwtCompatible(serializable = true)
	public static <E> LinkedList<E> newLinkedList(Iterable<? extends E> elements) {
		LinkedList<E> list = newLinkedList();
		Iterables.addAll(list, elements);
		return list;
	}

	@GwtIncompatible
	public static <E> CopyOnWriteArrayList<E> newCopyOnWriteArrayList() {
		return new CopyOnWriteArrayList();
	}

	@GwtIncompatible
	public static <E> CopyOnWriteArrayList<E> newCopyOnWriteArrayList(Iterable<? extends E> elements) {
		Collection<? extends E> elementsCollection = elements instanceof Collection
				? Collections2.cast(elements)
				: newArrayList(elements);
		return new CopyOnWriteArrayList((Collection) elementsCollection);
	}

	public static <E> List<E> asList(@NullableDecl E first, E[] rest) {
		return new OnePlusArrayList(first, rest);
	}

	public static <E> List<E> asList(@NullableDecl E first, @NullableDecl E second, E[] rest) {
		return new TwoPlusArrayList(first, second, rest);
	}

	public static <B> List<List<B>> cartesianProduct(List<? extends List<? extends B>> lists) {
		return CartesianList.create(lists);
	}

	@SafeVarargs
	public static <B> List<List<B>> cartesianProduct(List... lists) {
		return cartesianProduct(Arrays.asList(lists));
	}

	public static <F, T> List<T> transform(List<F> fromList, Function<? super F, ? extends T> function) {
		return (List) (fromList instanceof RandomAccess
				? new TransformingRandomAccessList(fromList, function)
				: new TransformingSequentialList(fromList, function));
	}

	public static <T> List<List<T>> partition(List<T> list, int size) {
		Preconditions.checkNotNull(list);
		Preconditions.checkArgument(size > 0);
		return (List) (list instanceof RandomAccess
				? new RandomAccessPartition(list, size)
				: new Partition(list, size));
	}

	public static ImmutableList<Character> charactersOf(String string) {
		return new StringAsImmutableList((String) Preconditions.checkNotNull(string));
	}

	@Beta
	public static List<Character> charactersOf(CharSequence sequence) {
		return new CharSequenceAsList((CharSequence) Preconditions.checkNotNull(sequence));
	}

	public static <T> List<T> reverse(List<T> list) {
		if (list instanceof ImmutableList) {
			return ((ImmutableList) list).reverse();
		} else if (list instanceof ReverseList) {
			return ((ReverseList) list).getForwardList();
		} else {
			return (List) (list instanceof RandomAccess ? new RandomAccessReverseList(list) : new ReverseList(list));
		}
	}

	static int hashCodeImpl(List<?> list) {
		int hashCode = 1;

		for (Iterator var2 = list.iterator(); var2.hasNext(); hashCode = ~(~hashCode)) {
			Object o = var2.next();
			hashCode = 31 * hashCode + (o == null ? 0 : o.hashCode());
		}

		return hashCode;
	}

	static boolean equalsImpl(List<?> thisList, @NullableDecl Object other) {
		if (other == Preconditions.checkNotNull(thisList)) {
			return true;
		} else if (!(other instanceof List)) {
			return false;
		} else {
			List<?> otherList = (List) other;
			int size = thisList.size();
			if (size != otherList.size()) {
				return false;
			} else if (thisList instanceof RandomAccess && otherList instanceof RandomAccess) {
				for (int i = 0; i < size; ++i) {
					if (!Objects.equal(thisList.get(i), otherList.get(i))) {
						return false;
					}
				}

				return true;
			} else {
				return Iterators.elementsEqual(thisList.iterator(), otherList.iterator());
			}
		}
	}

	static <E> boolean addAllImpl(List<E> list, int index, Iterable<? extends E> elements) {
		boolean changed = false;
		ListIterator<E> listIterator = list.listIterator(index);

		for (Iterator var5 = elements.iterator(); var5.hasNext(); changed = true) {
			E e = var5.next();
			listIterator.add(e);
		}

		return changed;
	}

	static int indexOfImpl(List<?> list, @NullableDecl Object element) {
		if (list instanceof RandomAccess) {
			return indexOfRandomAccess(list, element);
		} else {
			ListIterator listIterator = list.listIterator();

			do {
				if (!listIterator.hasNext()) {
					return -1;
				}
			} while (!Objects.equal(element, listIterator.next()));

			return listIterator.previousIndex();
		}
	}

	private static int indexOfRandomAccess(List<?> list, @NullableDecl Object element) {
		int size = list.size();
		int i;
		if (element == null) {
			for (i = 0; i < size; ++i) {
				if (list.get(i) == null) {
					return i;
				}
			}
		} else {
			for (i = 0; i < size; ++i) {
				if (element.equals(list.get(i))) {
					return i;
				}
			}
		}

		return -1;
	}

	static int lastIndexOfImpl(List<?> list, @NullableDecl Object element) {
		if (list instanceof RandomAccess) {
			return lastIndexOfRandomAccess(list, element);
		} else {
			ListIterator listIterator = list.listIterator(list.size());

			do {
				if (!listIterator.hasPrevious()) {
					return -1;
				}
			} while (!Objects.equal(element, listIterator.previous()));

			return listIterator.nextIndex();
		}
	}

	private static int lastIndexOfRandomAccess(List<?> list, @NullableDecl Object element) {
		int i;
		if (element == null) {
			for (i = list.size() - 1; i >= 0; --i) {
				if (list.get(i) == null) {
					return i;
				}
			}
		} else {
			for (i = list.size() - 1; i >= 0; --i) {
				if (element.equals(list.get(i))) {
					return i;
				}
			}
		}

		return -1;
	}

	static <E> ListIterator<E> listIteratorImpl(List<E> list, int index) {
		return (new AbstractListWrapper(list)).listIterator(index);
	}

	static <E> List<E> subListImpl(List<E> list, int fromIndex, int toIndex) {
      Object wrapper;
      if (list instanceof RandomAccess) {
         wrapper = new 1(list);
      } else {
         wrapper = new 2(list);
      }

      return ((List)wrapper).subList(fromIndex, toIndex);
   }

	static <T> List<T> cast(Iterable<T> iterable) {
		return (List) iterable;
	}
}