package com.google.inject;

import com.google.inject.MembersInjectorImpl.1;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.ImmutableList;
import com.google.inject.internal.ImmutableSet;
import com.google.inject.internal.InternalContext;
import com.google.inject.internal.ImmutableSet.Builder;
import com.google.inject.spi.InjectionListener;
import com.google.inject.spi.InjectionPoint;
import java.util.Iterator;

class MembersInjectorImpl<T> implements MembersInjector<T> {
	private final TypeLiteral<T> typeLiteral;
	private final InjectorImpl injector;
	private final ImmutableList<SingleMemberInjector> memberInjectors;
	private final ImmutableList<MembersInjector<? super T>> userMembersInjectors;
	private final ImmutableList<InjectionListener<? super T>> injectionListeners;
	private final ImmutableList<MethodAspect> addedAspects;

	MembersInjectorImpl(InjectorImpl injector, TypeLiteral<T> typeLiteral, EncounterImpl<T> encounter,
			ImmutableList<SingleMemberInjector> memberInjectors) {
		this.injector = injector;
		this.typeLiteral = typeLiteral;
		this.memberInjectors = memberInjectors;
		this.userMembersInjectors = encounter.getMembersInjectors();
		this.injectionListeners = encounter.getInjectionListeners();
		this.addedAspects = encounter.getAspects();
	}

	public ImmutableList<SingleMemberInjector> getMemberInjectors() {
		return this.memberInjectors;
	}

	public void injectMembers(T instance) {
		Errors errors = new Errors(this.typeLiteral);

		try {
			this.injectAndNotify(instance, errors);
		} catch (ErrorsException var4) {
			errors.merge(var4.getErrors());
		}

		errors.throwProvisionExceptionIfErrorsExist();
	}

	void injectAndNotify(T instance, Errors errors) throws ErrorsException {
      if (instance != null) {
         this.injector.callInContext(new 1(this, instance, errors));
         this.notifyListeners(instance, errors);
      }
   }

	void notifyListeners(T instance, Errors errors) throws ErrorsException {
		int numErrorsBefore = errors.size();
		Iterator i$ = this.injectionListeners.iterator();

		while (i$.hasNext()) {
			InjectionListener injectionListener = (InjectionListener) i$.next();

			try {
				injectionListener.afterInjection(instance);
			} catch (RuntimeException var7) {
				errors.errorNotifyingInjectionListener(injectionListener, this.typeLiteral, var7);
			}
		}

		errors.throwIfNewErrors(numErrorsBefore);
	}

	void injectMembers(T t, Errors errors, InternalContext context) {
		int i = 0;

		int size;
		for (size = this.memberInjectors.size(); i < size; ++i) {
			((SingleMemberInjector) this.memberInjectors.get(i)).inject(errors, context, t);
		}

		i = 0;

		for (size = this.userMembersInjectors.size(); i < size; ++i) {
			MembersInjector userMembersInjector = (MembersInjector) this.userMembersInjectors.get(i);

			try {
				userMembersInjector.injectMembers(t);
			} catch (RuntimeException var8) {
				errors.errorInUserInjector(userMembersInjector, this.typeLiteral, var8);
			}
		}

	}

	public String toString() {
		return "MembersInjector<" + this.typeLiteral + ">";
	}

	public ImmutableSet<InjectionPoint> getInjectionPoints() {
		Builder<InjectionPoint> builder = ImmutableSet.builder();
		Iterator i$ = this.memberInjectors.iterator();

		while (i$.hasNext()) {
			SingleMemberInjector memberInjector = (SingleMemberInjector) i$.next();
			builder.add(memberInjector.getInjectionPoint());
		}

		return builder.build();
	}

	public ImmutableList<MethodAspect> getAddedAspects() {
		return this.addedAspects;
	}
}