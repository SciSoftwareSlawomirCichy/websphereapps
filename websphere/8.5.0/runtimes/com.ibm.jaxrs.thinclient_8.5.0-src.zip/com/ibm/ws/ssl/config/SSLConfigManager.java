package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.websphere.models.config.ipc.ssl.KeyManager;
import com.ibm.websphere.models.config.ipc.ssl.KeyStore;
import com.ibm.websphere.models.config.ipc.ssl.SSLSecurityLevel;
import com.ibm.websphere.models.config.ipc.ssl.SecureSocketLayer;
import com.ibm.websphere.models.config.ipc.ssl.TrustManager;
import com.ibm.websphere.models.config.properties.DescriptiveProperty;
import com.ibm.websphere.models.config.properties.Property;
import com.ibm.websphere.ssl.JSSEHelper;
import com.ibm.websphere.ssl.SSLConfigChangeEvent;
import com.ibm.websphere.ssl.SSLConfigChangeListener;
import com.ibm.websphere.ssl.SSLException;
import com.ibm.ws.security.config.CSIv2Config;
import com.ibm.ws.security.config.SecurityConfigObject;
import com.ibm.ws.security.config.SecurityConfigObjectList;
import com.ibm.ws.security.config.SecurityObjectLocator;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.ssl.JSSEProviderFactory;
import com.ibm.ws.ssl.config.SSLConfigManager.1;
import com.ibm.ws.ssl.config.SSLConfigManager.2;
import com.ibm.ws.ssl.config.SSLConfigManager.3;
import com.ibm.ws.ssl.config.SSLConfigManager.4;
import com.ibm.ws.ssl.core.Constants;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider;
import com.ibm.ws.util.PlatformHelperFactory;
import java.io.File;
import java.io.FileNotFoundException;
import java.security.Security;
import java.security.cert.Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.Map.Entry;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;

public class SSLConfigManager {
	private static final TraceComponent tc = Tr.register(SSLConfigManager.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private static SSLConfigManager thisClass = null;
	private boolean isServerProcess = false;
	private boolean clientSSLInitializedOnce = false;
	private KeyStoreManager keyStoreManager = KeyStoreManager.getInstance();
	private Properties globalConfigProperties = new Properties();
	private HashMap sslConfigMap = new HashMap();
	private ArrayList keyManagerArrayList = new ArrayList();
	private ArrayList trustManagerArrayList = new ArrayList();
	private HashMap sslConfigDynamicSelectionMap = new HashMap();
	private TreeSet sslConfigDynamicSelectionCacheMissTreeSet = new TreeSet(new DynamicSSLCacheMissComparator());
	private HashMap sslConfigDynamicLookupCache = new HashMap();
	private HashSet clientFilesAlreadyProcessed = new HashSet();
	private HashMap sslConfigListenerMap = new HashMap();
	private HashMap sslConfigListenerEventMap = new HashMap();
	protected static int DISABLE_CACHE_MISS_PROP_NEVER_LOOKED_UP = 0;
	private static int CACHE_MISS_DISABLED = -1;
	private static int CACHE_MISS_ENABLED = 1;
	protected int disableCacheMiss;
	private static String[][] SystemSSLCiphers = new String[][]{{"05", "SSL_RSA_WITH_RC4_128_SHA"},
			{"04", "SSL_RSA_WITH_RC4_128_MD5"}, {"35", "SSL_RSA_WITH_AES_256_CBC_SHA"},
			{"36", "SSL_DH_DSS_WITH_AES_256_CBC_SHA"}, {"37", "SSL_DH_RSA_WITH_AES_256_CBC_SHA"},
			{"38", "SSL_DHE_DSS_WITH_AES_256_CBC_SHA"}, {"39", "SSL_DHE_RSA_WITH_AES_256_CBC_SHA"},
			{"2F", "SSL_RSA_WITH_AES_128_CBC_SHA"}, {"30", "SSL_DH_DSS_WITH_AES_128_CBC_SHA"},
			{"31", "SSL_DH_RSA_WITH_AES_128_CBC_SHA"}, {"32", "SSL_DHE_DSS_WITH_AES_128_CBC_SHA"},
			{"33", "SSL_DHE_RSA_WITH_AES_128_CBC_SHA"}, {"0A", "SSL_RSA_WITH_3DES_EDE_CBC_SHA"},
			{"16", "SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA"}, {"13", "SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA"},
			{"10", "SSL_DH_RSA_WITH_3DES_EDE_CBC_SHA"}, {"0D", "SSL_HD_DSS_WITH_3DES_EDE_CBC_SHA"},
			{"09", "SSL_RSA_WITH_DES_CBC_SHA"}, {"15", "SSL_DHE_RSA_WITH_DES_CBC_SHA"},
			{"12", "SSL_DHE_DSS_WITH_DES_CBC_SHA"}, {"0F", "SSL_DH_RSA_WITH_DES_CBC_SHA"},
			{"0C", "SSL_DH_DSS_WITH_DES_CBC_SHA"}, {"03", "SSL_RSA_EXPORT_WITH_RC4_40_MD5"},
			{"06", "SSL_RSA_EXPORT_WITH_RC2_CBC_40_MD5"}, {"02", "SSL_RSA_NULL_SHA"}, {"01", "SSL_RSA_NULL_MD5"},
			{"00", "SSL_NULL_WITH_NULL_NULL"}};

	private SSLConfigManager() {
		this.disableCacheMiss = DISABLE_CACHE_MISS_PROP_NEVER_LOOKED_UP;
		JSSEProviderFactory.getInstance();
	}

	public static SSLConfigManager getInstance() {
		if (thisClass == null) {
			thisClass = new SSLConfigManager();
		}

		return thisClass;
	}

	public synchronized void initializeServerSSL(SecurityConfigObject security, boolean reinitialize)
			throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeServerSSL");
		}

		if (security == null) {
			throw new SSLException("Cannot get security object from WCCM.");
		} else {
			try {
				if (reinitialize) {
					AbstractJSSEProvider.clearSSLContextCache();
				}

				this.isServerProcess = true;
				this.loadGlobalProperties(security);
				FIPSManager.getInstance().initializeFIPS();
				KeyStoreManager.getInstance().loadKeyStores(security);
				this.loadKeyManagers(security);
				this.loadTrustManagers(security);
				String[] existingAliases = null;
				Set newAliases = null;
				if (reinitialize) {
					newAliases = new HashSet();
					existingAliases = (String[]) ((String[]) this.sslConfigMap.keySet().toArray(new String[0]));
				}

				SecurityConfigObjectList repertoire = security.getObjectList("repertoire");

				int i;
				for (i = 0; i < repertoire.size(); ++i) {
					SecurityConfigObject sslConfig = repertoire.get(i);
					if (sslConfig != null) {
						String alias = sslConfig.getString("alias");
						SSLConfig config = this.parseSSLConfig(sslConfig, reinitialize);
						if (config != null && config.requiredPropertiesArePresent()) {
							config.setProperty("com.ibm.ssl.alias", alias);
							config.setProperty("com.ibm.ssl.configURLLoadedFrom", "security.xml");
							config.decodePasswords();
							if (reinitialize) {
								newAliases.add(alias);
								SSLConfig oldConfig = (SSLConfig) this.sslConfigMap.get(alias);
								if (oldConfig == null) {
									this.addSSLConfigToMap(alias, config, reinitialize);
								} else if (!oldConfig.equals(config)) {
									this.removeSSLConfigFromMap(alias, oldConfig);
									this.addSSLConfigToMap(alias, config, reinitialize);
									this.notifySSLConfigChangeListener(alias, "changed");
								} else if (tc.isDebugEnabled()) {
									Tr.debug(tc, "New SSL config equals old SSL config for alias: " + alias);
								}
							} else {
								this.addSSLConfigToMap(alias, config);
							}
						}
					}
				}

				if (reinitialize) {
					for (i = 0; i < existingAliases.length; ++i) {
						String oldAlias = existingAliases[i];
						SSLConfig oldConfig = (SSLConfig) this.sslConfigMap.get(oldAlias);
						String oldConfigURL = oldConfig.getProperty("com.ibm.ssl.configURLLoadedFrom");
						if (oldConfig != null && !newAliases.contains(oldAlias)
								&& (oldConfigURL == null || oldConfigURL.equals("security.xml"))) {
							this.removeSSLConfigFromMap(oldAlias, oldConfig);
							this.notifySSLConfigChangeListener(oldAlias, "deleted");
						}
					}
				}

				this.getDefaultSystemProperties(reinitialize);
				this.loadDynamicSSLSelectionInfo(security);
				ManagementScopeManager.getInstance().loadSSLConfigGroups(security, reinitialize);
			} catch (Exception var11) {
				Manager.Ffdc.log(var11, this, "com.ibm.ws.ssl.core.SSLConfigManager.initializeServerSSL", "312",
						new Object[]{this});
				throw new SSLException(var11);
			}

			this.checkURLHostNameVerificationProperty(reinitialize);
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Total Number of SSLConfigs: " + this.sslConfigMap.size());
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "initializeServerSSL");
			}

		}
	}

	public void initializeClientSSL() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeClientSSL");
		}

		try {
			if (!this.isServerProcess() && !this.clientSSLInitializedOnce) {
				String sasConfigURL = System.getProperty("com.ibm.CORBA.ConfigURL");
				if (sasConfigURL != null) {
					this.parseConfigURL("IIOP", sasConfigURL, false);
				}

				String soapConfigURL = System.getProperty("com.ibm.SOAP.ConfigURL");
				if (soapConfigURL != null) {
					this.parseConfigURL("ADMIN_SOAP", soapConfigURL, false);
				}

				String sslConfigURL = System.getProperty("com.ibm.SSL.ConfigURL");
				this.parseSSLConfigURL(sslConfigURL, false);
				FIPSManager.getInstance().initializeFIPS();
				this.getDefaultSystemProperties(false);
				this.checkURLHostNameVerificationProperty(false);
				this.clientSSLInitializedOnce = true;
			}
		} catch (Exception var4) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception initializing SSL properties from ConfigURL.", new Object[]{var4});
			}

			Manager.Ffdc.log(var4, this, "com.ibm.ws.ssl.core.SSLConfigManager.reinitializeClientSSL", "%c%",
					new Object[]{this});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initializeClientSSL");
		}

	}

	public void reinitializeClientSSL() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "reinitializeClientSSL");
		}

		try {
			if (!this.isServerProcess()) {
				AbstractJSSEProvider.clearSSLContextCache();
				FIPSManager.getInstance().initializeFIPS();
				String sasConfigURL = System.getProperty("com.ibm.CORBA.ConfigURL");
				if (sasConfigURL != null) {
					this.parseConfigURL("IIOP", sasConfigURL, true);
				}

				String soapConfigURL = System.getProperty("com.ibm.SOAP.ConfigURL");
				if (soapConfigURL != null) {
					this.parseConfigURL("ADMIN_SOAP", soapConfigURL, true);
				}

				String sslConfigURL = System.getProperty("com.ibm.SSL.ConfigURL");
				this.parseSSLConfigURL(sslConfigURL, true);
				this.getDefaultSystemProperties(true);
			}
		} catch (Exception var4) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception reinitializing SSL properties from ConfigURL.", new Object[]{var4});
			}

			Manager.Ffdc.log(var4, this, "com.ibm.ws.ssl.core.SSLConfigManager.reinitializeClientSSL", "410",
					new Object[]{this});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "reinitializeClientSSL");
		}

	}

	public void loadTrustManagers(SecurityConfigObject security) {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadTrustManagers");
		}

		this.trustManagerArrayList.clear();
		SecurityConfigObjectList tmList = security.getObjectList("trustManagers");
		if (tmList != null) {
			for (int i = 0; i < tmList.size(); ++i) {
				SecurityConfigObject tm = tmList.get(i);
				SecurityConfigObject scope = tm.getObject("managementScope");
				String scopeString = null;
				if (scope != null) {
					scopeString = scope.getString("scopeName");
				} else {
					scopeString = ManagementScopeManager.getInstance().getCellScopeName();
				}

				if (ManagementScopeManager.getInstance().currentScopeContained(scopeString)) {
					String name = tm.getString("name");
					String algorithm = tm.getString("algorithm");
					String provider = tm.getString("provider");
					String customClass = tm.getString("trustManagerClass");
					Properties customClassAttributes = tm.getProperties("additionalTrustManagerAttrs");
					TrustManagerData tmData = new TrustManagerData(name, provider, algorithm, customClass,
							customClassAttributes, scopeString);
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Adding trustManager name: " + name + " with values: " + tmData);
					}

					this.trustManagerArrayList.add(tmData);
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadTrustManagers");
		}

	}

	public void loadKeyManagers(SecurityConfigObject security) {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadKeyManagers");
		}

		this.keyManagerArrayList.clear();
		SecurityConfigObjectList kmList = security.getObjectList("keyManagers");
		if (kmList != null) {
			for (int i = 0; i < kmList.size(); ++i) {
				SecurityConfigObject km = kmList.get(i);
				SecurityConfigObject scope = km.getObject("managementScope");
				String scopeString = null;
				if (scope != null) {
					scopeString = scope.getString("scopeName");
				} else {
					scopeString = ManagementScopeManager.getInstance().getCellScopeName();
				}

				if (ManagementScopeManager.getInstance().currentScopeContained(scopeString)) {
					String name = km.getString("name");
					String algorithm = km.getString("algorithm");
					String provider = km.getString("provider");
					String customClass = km.getString("keyManagerClass");
					Properties customClassAttributes = km.getProperties("additionalKeyManagerAttrs");
					KeyManagerData kmData = new KeyManagerData(name, provider, algorithm, customClass,
							customClassAttributes, scopeString);
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Adding KeyManager name: " + name + " with values: " + kmData);
					}

					this.keyManagerArrayList.add(kmData);
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadKeyManagers");
		}

	}

	public TrustManagerData getTrustManagerData(String name) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTrustManagerData", new Object[]{name});
		}

		for (int i = 0; i < this.trustManagerArrayList.size(); ++i) {
			TrustManagerData data = (TrustManagerData) this.trustManagerArrayList.get(i);
			if (data != null && data.getName().equalsIgnoreCase(name)
					&& ManagementScopeManager.getInstance().currentScopeContained(data.getManagementScope())) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getTrustManagerData (" + name + ")");
				}

				return data;
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTrustManagerData (null)");
		}

		return null;
	}

	public KeyManagerData getKeyManagerData(String name) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getKeyManagerData", new Object[]{name});
		}

		for (int i = 0; i < this.keyManagerArrayList.size(); ++i) {
			KeyManagerData data = (KeyManagerData) this.keyManagerArrayList.get(i);
			if (data != null && data.getName().equalsIgnoreCase(name)
					&& ManagementScopeManager.getInstance().currentScopeContained(data.getManagementScope())) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getKeyManagerData (" + name + ")");
				}

				return data;
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getKeyManagerData (null)");
		}

		return null;
	}

	public synchronized void loadDynamicSSLSelectionInfo(SecurityConfigObject security) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadDynamicSSLSelectionInfo");
		}

		this.sslConfigDynamicSelectionMap.clear();
		if (this.isCacheMissEnabled()) {
			TreeSet var2 = this.sslConfigDynamicSelectionCacheMissTreeSet;
			synchronized (this.sslConfigDynamicSelectionCacheMissTreeSet) {
				this.sslConfigDynamicSelectionCacheMissTreeSet.clear();
			}
		}

		this.sslConfigDynamicLookupCache.clear();
		SecurityConfigObjectList dynamicSelections = security.getObjectList("dynamicSSLConfigSelections");
		if (dynamicSelections != null) {
			for (int i = 0; i < dynamicSelections.size(); ++i) {
				SecurityConfigObject selection = dynamicSelections.get(i);
				if (selection != null) {
					SecurityConfigObject mgmtScope = selection.getObject("managementScope");
					String selectionInfo;
					if (mgmtScope != null) {
						selectionInfo = mgmtScope.getString("scopeName");
						if (selectionInfo != null && !selectionInfo.equals("")
								&& !ManagementScopeManager.getInstance().currentScopeContained(selectionInfo)) {
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "Scope \"" + selectionInfo + "\" is out of scope for this process.");
							}
							continue;
						}
					}

					selectionInfo = selection.getString("dynamicSelectionInfo");
					String sslAlias = selection.getObject("sslConfig").getString("alias");
					String certAlias = selection.getString("certificateAlias");
					if (selectionInfo != null && sslAlias != null) {
						if (certAlias != null) {
							String selectionAlias = sslAlias + ":" + certAlias;
							this.sslConfigDynamicSelectionMap.put(selectionInfo, selectionAlias);
						} else {
							this.sslConfigDynamicSelectionMap.put(selectionInfo, sslAlias);
						}
					}
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadDynamicSSLSelectionInfo", new Object[]{this.sslConfigDynamicSelectionMap});
		}

	}

	public SSLConfig parseSSLConfig(SecurityConfigObject sslConfig, boolean reinitialize) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "parseSSLConfig");
		}

		if (sslConfig == null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "parseSSLConfig -> null");
			}

			return null;
		} else {
			String alias = sslConfig.getString("alias");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Parsing SSLConfig with alias: " + alias);
			}

			SecurityConfigObject mgmtScope = sslConfig.getObject("managementScope");
			String managementScope;
			if (mgmtScope != null) {
				managementScope = mgmtScope.getString("scopeName");
				if (managementScope != null && !managementScope.equals("")
						&& !ManagementScopeManager.getInstance().currentScopeContained(managementScope)) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "SSLConfig with alias \"" + alias + "\" and scope (\"" + managementScope
								+ "\") is not in the current process scope");
					}

					return null;
				}
			}

			managementScope = sslConfig.getString("type", "JSSE");
			SSLConfig config = this.parseSecureSocketLayer1(alias, managementScope, sslConfig.getObject("setting"),
					reinitialize);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "parseSSLConfig");
			}

			return config;
		}
	}

	public SSLConfig parseSSLConfig(com.ibm.websphere.models.config.security.SSLConfig sslConfig, boolean reinitialize)
			throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "parseSSLConfig");
		}

		if (sslConfig == null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "parseSSLConfig -> null");
			}

			return null;
		} else {
			String alias = sslConfig.getAlias();
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Parsing SSLConfig with alias: " + alias);
			}

			String managementScope;
			if (sslConfig.getManagementScope() != null) {
				managementScope = sslConfig.getManagementScope().getScopeName();
				if (managementScope != null && !managementScope.equals("")
						&& !ManagementScopeManager.getInstance().currentScopeContained(managementScope)) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "SSLConfig with alias \"" + alias + "\" and scope (\"" + managementScope
								+ "\") is not in the current process scope");
					}

					return null;
				}
			}

			managementScope = null;
			if (null != sslConfig.getType()) {
				managementScope = sslConfig.getType().getName();
			}

			SSLConfig config = this.parseSecureSocketLayer(alias, managementScope, sslConfig.getSetting(),
					reinitialize);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "parseSSLConfig");
			}

			return config;
		}
	}

	public SSLConfig parseSecureSocketLayer(String alias, String sslType, SecureSocketLayer ssl, boolean reinitialize) throws Exception {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "parseSecureSocketLayer");
      }

      SSLConfig sslprops = new SSLConfig();
      String defaultkeyManager;
      String clientKeyAlias;
      if (ssl != null) {
         KeyStore wccmKS = ssl.getKeyStore();
         WSKeyStore wsks_key = null;
         defaultkeyManager = null;
         if (wccmKS != null) {
            defaultkeyManager = wccmKS.getName();
            wsks_key = KeyStoreManager.getInstance().getKeyStore(defaultkeyManager);
         }

         Certificate signer = null;
         if (wsks_key != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Adding keystore properties from KeyStore object.");
            }

            sslprops.setProperty("com.ibm.ssl.keyStoreName", defaultkeyManager);
            this.addSSLPropertiesFromKeyStore(wsks_key, sslprops);
            signer = KeyStoreManager.getInstance().checkIfKeyStoreExistsAndCreateIfNot(wsks_key, sslprops);
            wsks_key.initializeKeyStore(reinitialize);
         }

         KeyStore wccmTS = ssl.getTrustStore();
         WSKeyStore wsks_trust = null;
         clientKeyAlias = null;
         if (wccmTS != null) {
            clientKeyAlias = wccmTS.getName();
            wsks_trust = KeyStoreManager.getInstance().getKeyStore(clientKeyAlias);
         }

         if (wsks_trust != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Adding truststore properties from KeyStore object.");
            }

            sslprops.setProperty("com.ibm.ssl.trustStoreName", clientKeyAlias);
            this.addSSLPropertiesFromTrustStore(wsks_trust, sslprops);
            KeyStoreManager.getInstance().checkIfTrustStoreExistsAndCreateIfNot(wsks_trust, sslprops, signer);
            wsks_trust.initializeKeyStore(reinitialize);
         }
      }

      WSKeyStore[] old_wsks_list = KeyStoreManager.getInstance().loadOldWCCMKeyStores(alias, sslType, ssl);
      String customTrustManagerList;
      if (old_wsks_list != null) {
         for(int i = 0; i < old_wsks_list.length; ++i) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Adding key/trust store properties from old attributes.");
            }

            WSKeyStore ks = old_wsks_list[i];
            if (ks != null) {
               customTrustManagerList = ks.getProperty("com.ibm.ssl.keyStoreName");
               if (customTrustManagerList.endsWith("_trust")) {
                  sslprops.setProperty("com.ibm.ssl.trustStoreName", customTrustManagerList);
                  this.addSSLPropertiesFromTrustStore(ks, sslprops);
               }

               if (customTrustManagerList.endsWith("_key")) {
                  sslprops.setProperty("com.ibm.ssl.keyStoreName", customTrustManagerList);
                  this.addSSLPropertiesFromKeyStore(ks, sslprops);
               }
            }

            old_wsks_list[i].initializeKeyStore(reinitialize);
         }
      }

      KeyManager keyManager = null;
      if (ssl != null) {
         keyManager = ssl.getKeyManager();
      }

      if (keyManager != null) {
         if (keyManager.getAlgorithm() != null && (keyManager.getAlgorithm().equalsIgnoreCase("IbmPKIX") || keyManager.getAlgorithm().equalsIgnoreCase("IbmX509"))) {
            defaultkeyManager = null;
            if (keyManager.getAlgorithm() != null && keyManager.getProvider() != null) {
               defaultkeyManager = keyManager.getAlgorithm() + "|" + keyManager.getProvider();
            } else {
               defaultkeyManager = keyManager.getAlgorithm();
            }

            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Setting KeyManager: " + defaultkeyManager);
            }

            sslprops.setProperty("com.ibm.ssl.keyManager", defaultkeyManager);
         } else if ((keyManager.getAlgorithm() == null || keyManager.getProvider() == null) && keyManager.getKeyManagerClass() == null) {
            defaultkeyManager = JSSEProviderFactory.getKeyManagerFactoryAlgorithm();
            if (defaultkeyManager != null) {
               if (tc.isDebugEnabled()) {
                  Tr.debug(tc, "Setting default KeyManager: " + defaultkeyManager);
               }

               sslprops.setProperty("com.ibm.ssl.keyManager", defaultkeyManager);
            }
         } else {
            defaultkeyManager = keyManager.getName();
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Setting custom KeyManager: " + defaultkeyManager);
            }

            sslprops.setProperty("com.ibm.ssl.customKeyManager", defaultkeyManager);
            customTrustManagerList = JSSEProviderFactory.getKeyManagerFactoryAlgorithm();
            if (customTrustManagerList != null) {
               if (tc.isDebugEnabled()) {
                  Tr.debug(tc, "Setting default KeyManager: " + customTrustManagerList);
               }

               sslprops.setProperty("com.ibm.ssl.keyManager", customTrustManagerList);
            }
         }
      } else {
         defaultkeyManager = JSSEProviderFactory.getKeyManagerFactoryAlgorithm();
         if (defaultkeyManager != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Setting default KeyManager: " + defaultkeyManager);
            }

            sslprops.setProperty("com.ibm.ssl.keyManager", defaultkeyManager);
         }
      }

      List tmList = null;
      if (ssl != null) {
         tmList = ssl.getTrustManager();
      }

      if (tmList != null && tmList.size() > 0) {
         customTrustManagerList = null;

         for(int i = 0; i < tmList.size(); ++i) {
            TrustManager tm = (TrustManager)tmList.get(i);
            if (i == 0 && tm != null && tm.getAlgorithm() != null && (tm.getAlgorithm().equalsIgnoreCase("IbmX509") || tm.getAlgorithm().equalsIgnoreCase("IbmPKIX"))) {
               clientKeyAlias = null;
               if (tm.getProvider() != null) {
                  clientKeyAlias = tm.getAlgorithm() + "|" + tm.getProvider();
               } else {
                  clientKeyAlias = tm.getAlgorithm();
               }

               if (tm.getAlgorithm().equalsIgnoreCase("IbmPKIX")) {
                  AccessController.doPrivileged(new 1(this, tm));
                  if (tc.isDebugEnabled()) {
                     this.printTrustManagerProperties();
                  }
               }

               if (tc.isDebugEnabled()) {
                  Tr.debug(tc, "Setting TrustManager: " + clientKeyAlias);
               }

               sslprops.setProperty("com.ibm.ssl.trustManager", clientKeyAlias);
            } else if (i > 0 && tm != null) {
               if (customTrustManagerList != null) {
                  customTrustManagerList = customTrustManagerList + "," + tm.getName();
               } else {
                  customTrustManagerList = tm.getName();
               }
            }
         }

         if (customTrustManagerList != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Setting custom TrustManager(s): " + customTrustManagerList);
            }

            sslprops.setProperty("com.ibm.ssl.customTrustManagers", customTrustManagerList);
         }
      } else {
         customTrustManagerList = JSSEProviderFactory.getTrustManagerFactoryAlgorithm();
         if (customTrustManagerList != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Setting default TrustManager: " + customTrustManagerList);
            }

            sslprops.setProperty("com.ibm.ssl.trustManager", customTrustManagerList);
         }
      }

      String serverKeyAlias;
      String enabledCiphers;
      String contextProvider;
      String clientAuthenticationSupported;
      if (ssl != null) {
         customTrustManagerList = ssl.getSslProtocol();
         if (customTrustManagerList != null && !customTrustManagerList.equals("")) {
            sslprops.setProperty("com.ibm.ssl.protocol", customTrustManagerList);
         }

         contextProvider = ssl.getJsseProvider();
         if (contextProvider != null && !contextProvider.equals("")) {
            if (contextProvider.equalsIgnoreCase("IBMJSSE") || contextProvider.equalsIgnoreCase("IBMJSSEFIPS")) {
               contextProvider = "IBMJSSE2";
            }

            sslprops.setProperty("com.ibm.ssl.contextProvider", contextProvider);
         }

         if (ssl.isSetClientAuthentication()) {
            clientAuthenticationSupported = Boolean.toString(ssl.isClientAuthentication());
            if (clientAuthenticationSupported != null) {
               sslprops.setProperty("com.ibm.ssl.clientAuthentication", clientAuthenticationSupported);
            }
         }

         clientAuthenticationSupported = Boolean.toString(ssl.isClientAuthenticationSupported());
         if (clientAuthenticationSupported != null) {
            sslprops.setProperty("com.ibm.ssl.clientAuthenticationSupported", clientAuthenticationSupported);
         }

         if (ssl.isSetSecurityLevel()) {
            clientKeyAlias = this.getSecurityLevel(ssl.getSecurityLevel());
            if (clientKeyAlias != null && !clientKeyAlias.equals("")) {
               sslprops.setProperty("com.ibm.ssl.securityLevel", clientKeyAlias);
            }
         }

         clientKeyAlias = ssl.getClientKeyAlias();
         if (clientKeyAlias != null && !clientKeyAlias.equals("")) {
            sslprops.setProperty("com.ibm.ssl.keyStoreClientAlias", clientKeyAlias);
         }

         serverKeyAlias = ssl.getServerKeyAlias();
         if (serverKeyAlias != null && !serverKeyAlias.equals("")) {
            sslprops.setProperty("com.ibm.ssl.keyStoreServerAlias", serverKeyAlias);
         }

         enabledCiphers = ssl.getEnabledCiphers();
         if (enabledCiphers != null && !enabledCiphers.equals("")) {
            sslprops.setProperty("com.ibm.ssl.enabledCipherSuites", enabledCiphers);
         }

         for(int j = 0; j < ssl.getProperties().size(); ++j) {
            Property sslproperty = (Property)ssl.getProperties().get(j);
            if (sslproperty != null && sslproperty.getValue() != null && !sslproperty.getValue().equals("")) {
               String value = sslproperty.getValue();
               if (sslproperty.getName().equals("com.ibm.ssl.contextProvider") && (value.equalsIgnoreCase("IBMJSSE") || value.equalsIgnoreCase("IBMJSSEFIPS"))) {
                  value = "IBMJSSE2";
               }

               sslprops.setProperty(sslproperty.getName(), value);
            }
         }
      } else {
         customTrustManagerList = System.getProperty("com.ibm.ssl.protocol");
         if (customTrustManagerList != null && !customTrustManagerList.equals("")) {
            sslprops.setProperty("com.ibm.ssl.protocol", customTrustManagerList);
         }

         contextProvider = System.getProperty("com.ibm.ssl.contextProvider");
         if (contextProvider != null && !contextProvider.equals("")) {
            if (contextProvider.equalsIgnoreCase("IBMJSSE") || contextProvider.equalsIgnoreCase("IBMJSSEFIPS")) {
               contextProvider = "IBMJSSE2";
            }

            sslprops.setProperty("com.ibm.ssl.contextProvider", contextProvider);
         }

         clientAuthenticationSupported = System.getProperty("com.ibm.CSI.performTLClientAuthenticationRequired");
         if (clientAuthenticationSupported != null && !clientAuthenticationSupported.equals("")) {
            sslprops.setProperty("com.ibm.ssl.clientAuthentication", clientAuthenticationSupported);
         }

         clientKeyAlias = System.getProperty("com.ibm.CSI.performTLClientAuthenticationSupported");
         if (clientKeyAlias != null && !clientKeyAlias.equals("")) {
            sslprops.setProperty("com.ibm.ssl.clientAuthenticationSupported", clientKeyAlias);
         }

         serverKeyAlias = System.getProperty("com.ibm.ssl.securityLevel");
         if (serverKeyAlias != null && !serverKeyAlias.equals("")) {
            sslprops.setProperty("com.ibm.ssl.securityLevel", serverKeyAlias);
         }

         enabledCiphers = System.getProperty("com.ibm.ssl.keyStoreClientAlias");
         if (enabledCiphers != null && !enabledCiphers.equals("")) {
            sslprops.setProperty("com.ibm.ssl.keyStoreClientAlias", enabledCiphers);
         }

         String serverKeyAlias = System.getProperty("com.ibm.ssl.keyStoreServerAlias");
         if (serverKeyAlias != null && !serverKeyAlias.equals("")) {
            sslprops.setProperty("com.ibm.ssl.keyStoreServerAlias", serverKeyAlias);
         }

         String enabledCiphers = System.getProperty("com.ibm.ssl.enabledCipherSuites");
         if (enabledCiphers != null && !enabledCiphers.equals("")) {
            sslprops.setProperty("com.ibm.ssl.enabledCipherSuites", enabledCiphers);
         }
      }

      if (FIPSManager.getInstance().isFIPSEnabled()) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "FIPS enabled, setting SSL protocol to TLS.");
         }

         sslprops.put("com.ibm.ssl.protocol", "TLS");
      }

      if (tc.isDebugEnabled()) {
         Tr.debug(tc, "Saving SSLConfig.");
      }

      if (tc.isDebugEnabled()) {
         Tr.debug(tc, sslprops.toString());
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "parseSecureSocketLayer");
      }

      return sslprops;
   }

	private void printTrustManagerProperties() {
		Tr.debug(tc, "Trust Manager Properties:");
		Tr.debug(tc, " com.ibm.jsse2.checkRevocation - " + System.getProperty("com.ibm.jsse2.checkRevocation"));
		Tr.debug(tc, " com.ibm.security.enableCRLDP - " + System.getProperty("com.ibm.security.enableCRLDP"));
		Tr.debug(tc, " com.ibm.security.enableNULLCRLDP - " + System.getProperty("com.ibm.security.enableNULLCRLDP"));
		Tr.debug(tc, " ocsp.enable - " + Security.getProperty("ocsp.enable"));
		Tr.debug(tc, " ocsp.responderURL - " + Security.getProperty("ocsp.responderURL"));
		Tr.debug(tc, " ocsp.responderCertSubjectName - " + Security.getProperty("ocsp.responderCertSubjectName"));
		Tr.debug(tc, " ocsp.responderCertIssuerName - " + Security.getProperty("ocsp.responderCertIssuerName"));
		Tr.debug(tc, " ocsp.responderCertSerialNumber - " + Security.getProperty("ocsp.responderCertSerialNumber"));
		Tr.debug(tc, " com.ibm.security.ldap.certstore.host - "
				+ System.getProperty("com.ibm.security.ldap.certstore.host"));
		Tr.debug(tc, " com.ibm.security.ldap.certstore.port - "
				+ System.getProperty("com.ibm.security.ldap.certstore.port"));
	}

	public SSLConfig parseSecureSocketLayer1(String alias, String sslType, SecurityConfigObject ssl, boolean reinitialize) throws Exception {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "parseSecureSocketLayer");
      }

      SSLConfig sslprops = new SSLConfig();
      String algorithm;
      SecurityConfigObject keyManagerString;
      String clientKeyAlias;
      if (ssl != null) {
         SecurityConfigObject wccmKS = ssl.getObject("keyStore");
         WSKeyStore wsks_key = null;
         algorithm = null;
         if (wccmKS != null) {
            algorithm = wccmKS.getString("name");
            wsks_key = KeyStoreManager.getInstance().getKeyStore(algorithm);
         }

         Certificate signer = null;
         if (wsks_key != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Adding keystore properties from KeyStore object.");
            }

            sslprops.setProperty("com.ibm.ssl.keyStoreName", algorithm);
            this.addSSLPropertiesFromKeyStore(wsks_key, sslprops);
            signer = KeyStoreManager.getInstance().checkIfKeyStoreExistsAndCreateIfNot(wsks_key, sslprops);
            wsks_key.initializeKeyStore(reinitialize);
         }

         keyManagerString = ssl.getObject("trustStore");
         WSKeyStore wsks_trust = null;
         clientKeyAlias = null;
         if (keyManagerString != null) {
            clientKeyAlias = keyManagerString.getString("name");
            wsks_trust = KeyStoreManager.getInstance().getKeyStore(clientKeyAlias);
         }

         if (wsks_trust != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Adding truststore properties from KeyStore object.");
            }

            sslprops.setProperty("com.ibm.ssl.trustStoreName", clientKeyAlias);
            this.addSSLPropertiesFromTrustStore(wsks_trust, sslprops);
            KeyStoreManager.getInstance().checkIfTrustStoreExistsAndCreateIfNot(wsks_trust, sslprops, signer);
            wsks_trust.initializeKeyStore(reinitialize);
         }
      }

      WSKeyStore[] old_wsks_list = KeyStoreManager.getInstance().loadOldWCCMKeyStores(alias, sslType, ssl);
      String customTrustManagerList;
      if (old_wsks_list != null) {
         for(int i = 0; i < old_wsks_list.length; ++i) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Adding key/trust store properties from old attributes.");
            }

            WSKeyStore ks = old_wsks_list[i];
            if (ks != null) {
               customTrustManagerList = ks.getProperty("com.ibm.ssl.keyStoreName");
               if (customTrustManagerList.endsWith("_trust")) {
                  sslprops.setProperty("com.ibm.ssl.trustStoreName", customTrustManagerList);
                  this.addSSLPropertiesFromTrustStore(ks, sslprops);
               }

               if (customTrustManagerList.endsWith("_key")) {
                  sslprops.setProperty("com.ibm.ssl.keyStoreName", customTrustManagerList);
                  this.addSSLPropertiesFromKeyStore(ks, sslprops);
               }
            }

            old_wsks_list[i].initializeKeyStore(reinitialize);
         }
      }

      SecurityConfigObject keyManager = null;
      if (ssl != null) {
         keyManager = ssl.getObject("keyManager");
      }

      String contextProvider;
      String clientAuthenticationSupported;
      if (keyManager != null) {
         algorithm = keyManager.getString("algorithm");
         customTrustManagerList = keyManager.getString("provider");
         if (algorithm == null || !algorithm.equalsIgnoreCase("IbmPKIX") && !algorithm.equalsIgnoreCase("IbmX509")) {
            if ((algorithm == null || customTrustManagerList == null) && keyManager.getString("keyManagerClass") == null) {
               contextProvider = JSSEProviderFactory.getKeyManagerFactoryAlgorithm();
               if (contextProvider != null) {
                  if (tc.isDebugEnabled()) {
                     Tr.debug(tc, "Setting default KeyManager: " + contextProvider);
                  }

                  sslprops.setProperty("com.ibm.ssl.keyManager", contextProvider);
               }
            } else {
               contextProvider = keyManager.getString("name");
               if (tc.isDebugEnabled()) {
                  Tr.debug(tc, "Setting custom KeyManager: " + contextProvider);
               }

               sslprops.setProperty("com.ibm.ssl.customKeyManager", contextProvider);
               clientAuthenticationSupported = JSSEProviderFactory.getKeyManagerFactoryAlgorithm();
               if (clientAuthenticationSupported != null) {
                  if (tc.isDebugEnabled()) {
                     Tr.debug(tc, "Setting default KeyManager: " + clientAuthenticationSupported);
                  }

                  sslprops.setProperty("com.ibm.ssl.keyManager", clientAuthenticationSupported);
               }
            }
         } else {
            keyManagerString = null;
            if (algorithm != null && customTrustManagerList != null) {
               contextProvider = algorithm + "|" + customTrustManagerList;
            } else {
               contextProvider = algorithm;
            }

            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Setting KeyManager: " + contextProvider);
            }

            sslprops.setProperty("com.ibm.ssl.keyManager", contextProvider);
         }
      } else {
         algorithm = JSSEProviderFactory.getKeyManagerFactoryAlgorithm();
         if (algorithm != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Setting default KeyManager: " + algorithm);
            }

            sslprops.setProperty("com.ibm.ssl.keyManager", algorithm);
         }
      }

      SecurityConfigObjectList tmList = null;
      if (ssl != null) {
         tmList = ssl.getObjectList("trustManager");
      }

      String serverKeyAlias;
      if (tmList != null && tmList.size() > 0) {
         customTrustManagerList = null;

         for(int i = 0; i < tmList.size(); ++i) {
            SecurityConfigObject tm = tmList.get(i);
            clientKeyAlias = tm.getString("algorithm");
            if (i != 0 || tm == null || clientKeyAlias == null || !clientKeyAlias.equalsIgnoreCase("IbmX509") && !clientKeyAlias.equalsIgnoreCase("IbmPKIX")) {
               if (i > 0 && tm != null) {
                  if (customTrustManagerList != null) {
                     customTrustManagerList = customTrustManagerList + "," + tm.getString("name");
                  } else {
                     customTrustManagerList = tm.getString("name");
                  }
               }
            } else {
               serverKeyAlias = null;
               if (tm.getString("provider") != null) {
                  serverKeyAlias = clientKeyAlias + "|" + tm.getString("provider");
               } else {
                  serverKeyAlias = clientKeyAlias;
               }

               if (clientKeyAlias.equalsIgnoreCase("IbmPKIX")) {
                  AccessController.doPrivileged(new 2(this, tm));
                  if (tc.isDebugEnabled()) {
                     this.printTrustManagerProperties();
                  }
               }

               if (tc.isDebugEnabled()) {
                  Tr.debug(tc, "Setting TrustManager: " + serverKeyAlias);
               }

               sslprops.setProperty("com.ibm.ssl.trustManager", serverKeyAlias);
            }
         }

         if (customTrustManagerList != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Setting custom TrustManager(s): " + customTrustManagerList);
            }

            sslprops.setProperty("com.ibm.ssl.customTrustManagers", customTrustManagerList);
         }
      } else {
         customTrustManagerList = JSSEProviderFactory.getTrustManagerFactoryAlgorithm();
         if (customTrustManagerList != null) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Setting default TrustManager: " + customTrustManagerList);
            }

            sslprops.setProperty("com.ibm.ssl.trustManager", customTrustManagerList);
         }
      }

      if (ssl != null) {
         customTrustManagerList = ssl.getString("sslProtocol");
         if (customTrustManagerList != null && !customTrustManagerList.equals("")) {
            sslprops.setProperty("com.ibm.ssl.protocol", customTrustManagerList);
         }

         contextProvider = ssl.getString("jsseProvider");
         if (contextProvider != null && !contextProvider.equals("")) {
            if (contextProvider.equalsIgnoreCase("IBMJSSE") || contextProvider.equalsIgnoreCase("IBMJSSEFIPS")) {
               contextProvider = "IBMJSSE2";
            }

            sslprops.setProperty("com.ibm.ssl.contextProvider", contextProvider);
         }

         if (ssl.isSet("clientAuthentication")) {
            clientAuthenticationSupported = ssl.getBoolean("clientAuthentication").toString();
            if (clientAuthenticationSupported != null) {
               sslprops.setProperty("com.ibm.ssl.clientAuthentication", clientAuthenticationSupported);
            }
         }

         clientAuthenticationSupported = ssl.getBoolean("clientAuthenticationSupported").toString();
         if (clientAuthenticationSupported != null) {
            sslprops.setProperty("com.ibm.ssl.clientAuthenticationSupported", clientAuthenticationSupported);
         }

         if (ssl.isSet("securityLevel")) {
            clientKeyAlias = ssl.getString("securityLevel", "HIGH");
            if (clientKeyAlias != null && !clientKeyAlias.equals("")) {
               sslprops.setProperty("com.ibm.ssl.securityLevel", clientKeyAlias);
            }
         }

         clientKeyAlias = ssl.getString("clientKeyAlias");
         if (clientKeyAlias != null && !clientKeyAlias.equals("")) {
            sslprops.setProperty("com.ibm.ssl.keyStoreClientAlias", clientKeyAlias);
         }

         serverKeyAlias = ssl.getString("serverKeyAlias");
         if (serverKeyAlias != null && !serverKeyAlias.equals("")) {
            sslprops.setProperty("com.ibm.ssl.keyStoreServerAlias", serverKeyAlias);
         }

         String enabledCiphers = ssl.getString("enabledCiphers");
         if (enabledCiphers != null && !enabledCiphers.equals("")) {
            sslprops.setProperty("com.ibm.ssl.enabledCipherSuites", enabledCiphers);
         }

         SecurityConfigObjectList props = ssl.getObjectList("properties");

         for(int j = 0; j < props.size(); ++j) {
            SecurityConfigObject sslproperty = props.get(j);
            if (sslproperty != null) {
               String value = sslproperty.getString("value");
               if (value != null && !value.equals("")) {
                  String name = sslproperty.getString("name");
                  if (name.equals("com.ibm.ssl.contextProvider") && (value.equalsIgnoreCase("IBMJSSE") || value.equalsIgnoreCase("IBMJSSEFIPS"))) {
                     value = "IBMJSSE2";
                  }

                  sslprops.setProperty(name, value);
               }
            }
         }
      }

      if (FIPSManager.getInstance().isFIPSEnabled()) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "FIPS enabled, setting SSL protocol to TLS.");
         }

         customTrustManagerList = this.getSSLProtocolForFipsLevel(sslprops);
         sslprops.put("com.ibm.ssl.protocol", customTrustManagerList);
      }

      if (tc.isDebugEnabled()) {
         Tr.debug(tc, "Saving SSLConfig.");
      }

      if (tc.isDebugEnabled()) {
         Tr.debug(tc, sslprops.toString());
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "parseSecureSocketLayer");
      }

      return sslprops;
   }

	protected void setCheckRevocationProperties(String key, String value) {
		if (key != null && key.length() > 0 && value != null && value.length() > 0) {
			if (key.equals("com.ibm.jsse2.checkRevocation")) {
				System.setProperty("com.ibm.jsse2.checkRevocation", value);
			} else if (key.equals("com.ibm.security.enableCRLDP")) {
				System.setProperty("com.ibm.security.enableCRLDP", value);
				if (System.getProperty("com.ibm.security.enableNULLCRLDP") == null) {
					System.setProperty("com.ibm.security.enableNULLCRLDP", "true");
				}
			} else if (key.equals("com.ibm.security.enableNULLCRLDP")) {
				System.setProperty("com.ibm.security.enableNULLCRLDP", value);
			} else if (key.equals("com.ibm.security.ldap.certstore.host")) {
				System.setProperty("com.ibm.security.ldap.certstore.host", value);
				if (System.getProperty("com.ibm.security.ldap.certstore.port") == null) {
					System.setProperty("com.ibm.security.ldap.certstore.port", "389");
				}
			} else if (key.equals("com.ibm.security.ldap.certstore.port")) {
				System.setProperty("com.ibm.security.ldap.certstore.port", value);
			} else if (key.equals("ocsp.enable")) {
				Security.setProperty("ocsp.enable", value);
			} else if (key.equals("ocsp.responderURL")) {
				Security.setProperty("ocsp.responderURL", value);
			} else if (key.equals("ocsp.responderCertSubjectName")) {
				Security.setProperty("ocsp.responderCertSubjectName", value);
			} else if (key.equals("ocsp.responderCertIssuerName")) {
				Security.setProperty("ocsp.responderCertIssuerName", value);
			} else if (key.equals("ocsp.responderCertSerialNumber")) {
				Security.setProperty("ocsp.responderCertSerialNumber", value);
			}
		}

	}

	public void addSSLPropertiesFromKeyStore(WSKeyStore wsks, SSLConfig sslprops) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "addSSLPropertiesFromKeyStore");
		}

		Enumeration e = wsks.propertyNames();

		while (e.hasMoreElements()) {
			String property = (String) e.nextElement();
			String value = wsks.getProperty(property);
			sslprops.setProperty(property, value);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addSSLPropertiesFromKeyStore");
		}

	}

	public void addSSLPropertiesFromTrustStore(WSKeyStore wsts, SSLConfig sslprops) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "addSSLPropertiesFromTrustStore");
		}

		Enumeration e = wsts.propertyNames();

		while (e.hasMoreElements()) {
			String property = (String) e.nextElement();
			String value = wsts.getProperty(property);
			String trustManagerProperty = null;
			if (property.startsWith("com.ibm.ssl.keyStore")) {
				int index = property.indexOf("com.ibm.ssl.keyStore");
				String lastPart = null;
				if (index + "com.ibm.ssl.keyStore".length() < property.length()) {
					lastPart = property.substring(index + "com.ibm.ssl.keyStore".length());
				}

				if (lastPart != null) {
					trustManagerProperty = "com.ibm.ssl.trustStore" + lastPart;
				} else {
					trustManagerProperty = "com.ibm.ssl.trustStore";
				}
			}

			if (trustManagerProperty != null && value != null) {
				sslprops.setProperty(trustManagerProperty, value);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addSSLPropertiesFromKeyStore");
		}

	}

	public String[] getSSLConfigAliases() {
		return (String[]) ((String[]) this.sslConfigMap.keySet().toArray(new String[0]));
	}

	public SSLConfig getSSLConfig(String alias) throws IllegalArgumentException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLConfig", alias);
		}

		if (alias != null && !alias.equals("")) {
			SSLConfig ssl = (SSLConfig) this.sslConfigMap.get(alias);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getSSLConfig", ssl);
			}

			return ssl;
		} else {
			return this.getDefaultSSLConfig();
		}
	}

	public void loadGlobalProperties(SecurityConfigObject security) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadGlobalProperties");
		}

		SecurityConfigObjectList globalConfigList = security.getObjectList("properties");
		if (this.globalConfigProperties != null && globalConfigList != null) {
			this.globalConfigProperties.clear();

			for (int i = 0; i < globalConfigList.size(); ++i) {
				SecurityConfigObject p = globalConfigList.get(i);
				String name = p.getString("name");
				if (name.startsWith("com.ibm.ssl") || name.startsWith("com.ibm.security")
						|| name.startsWith("com.ibm.websphere")
						|| name.startsWith("was.com.ibm.websphere.security.zos.csiv2")) {
					String value = null;
					if (name.equals("com.ibm.ssl.defaultCertReqSubjectDN")) {
						value = p.getUnexpandedString("value");
					} else {
						value = p.getString("value");
					}

					if (value != null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Setting global property: " + name + "=" + value);
						}

						this.globalConfigProperties.setProperty(name, value);
					} else if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Value is null, skip setting global property: " + name);
					}
				}
			}
		}

		this.loadCSIv2SSLProperties(security);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadGlobalProperties");
		}

	}

	public void loadCSIv2SSLProperties(SecurityConfigObject security) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadCSIv2SSLProperties");
		}

		SecurityConfigObject csiv2 = security.getObject("CSI");
		if (csiv2 != null) {
			SecurityConfigObject claimCSI = csiv2.getObject("claims");
			SecurityConfigObjectList layers = claimCSI.getObjectList("layers");
			SecurityConfigObject csiv2ClaimIIOPTransportLayer = null;

			SecurityConfigObject csiv2PerformIIOPTransportLayer;
			for (int i = 0; i < layers.size(); ++i) {
				csiv2PerformIIOPTransportLayer = layers.get(i);
				if (csiv2PerformIIOPTransportLayer.instanceOf(
						"http://www.ibm.com/websphere/appserver/schemas/5.0/orb.securityprotocol.xmi",
						"TransportLayer")) {
					csiv2ClaimIIOPTransportLayer = csiv2PerformIIOPTransportLayer;
					break;
				}
			}

			SecurityConfigObject csiv2ClaimIIOPTransportSSLServerAuth;
			SecurityConfigObject csiv2ClaimTransportQOPSupported;
			if (csiv2ClaimIIOPTransportLayer != null) {
				csiv2ClaimTransportQOPSupported = csiv2ClaimIIOPTransportLayer.getObject("supportedQOP");
				if (csiv2ClaimTransportQOPSupported.getBoolean("enableProtection")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimTransportAssocSSLTLSSupported", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimTransportAssocSSLTLSSupported", "false");
				}

				if (csiv2ClaimTransportQOPSupported.getBoolean("establishTrustInClient")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimTLClientAuthenticationSupported", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimTLClientAuthenticationSupported",
							"false");
				}

				if (csiv2ClaimTransportQOPSupported.getBoolean("integrity")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimMessageIntegritySupported", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimMessageIntegritySupported", "false");
				}

				if (csiv2ClaimTransportQOPSupported.getBoolean("confidentiality")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimMessageConfidentialitySupported", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimMessageConfidentialitySupported",
							"false");
				}

				csiv2PerformIIOPTransportLayer = csiv2ClaimIIOPTransportLayer.getObject("requiredQOP");
				if (csiv2PerformIIOPTransportLayer.getBoolean("enableProtection")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimTransportAssocSSLTLSRequired", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimTransportAssocSSLTLSRequired", "false");
				}

				if (csiv2PerformIIOPTransportLayer.getBoolean("establishTrustInClient")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimTLClientAuthenticationRequired", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimTLClientAuthenticationRequired", "false");
				}

				if (csiv2PerformIIOPTransportLayer.getBoolean("integrity")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimMessageIntegrityRequired", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimMessageIntegrityRequired", "false");
				}

				if (csiv2PerformIIOPTransportLayer.getBoolean("confidentiality")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimMessageConfidentialityRequired", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.claimMessageConfidentialityRequired", "false");
				}

				csiv2ClaimIIOPTransportSSLServerAuth = csiv2ClaimIIOPTransportLayer.getObject("serverAuthentication");
				String sslAlias = null;
				if (PlatformHelperFactory.getPlatformHelper().isZOS()) {
					sslAlias = this.globalConfigProperties
							.getProperty("was.com.ibm.websphere.security.zos.csiv2.inbound.transport.sslconfig");
				}

				if (sslAlias == null) {
					sslAlias = csiv2ClaimIIOPTransportSSLServerAuth.getString("sslConfig");
				}

				if (sslAlias != null) {
					this.globalConfigProperties.setProperty("com.ibm.ssl.csi.inbound.alias", sslAlias);
				}
			}

			csiv2ClaimTransportQOPSupported = csiv2.getObject("performs");
			layers = csiv2ClaimTransportQOPSupported.getObjectList("layers");
			csiv2PerformIIOPTransportLayer = null;

			SecurityConfigObject csiv2PerformTransportQOPRequired;
			for (int i = 0; i < layers.size(); ++i) {
				csiv2PerformTransportQOPRequired = layers.get(i);
				if (csiv2PerformTransportQOPRequired.instanceOf(
						"http://www.ibm.com/websphere/appserver/schemas/5.0/orb.securityprotocol.xmi",
						"TransportLayer")) {
					csiv2PerformIIOPTransportLayer = csiv2PerformTransportQOPRequired;
					break;
				}
			}

			if (csiv2PerformIIOPTransportLayer != null) {
				csiv2ClaimIIOPTransportSSLServerAuth = csiv2PerformIIOPTransportLayer.getObject("supportedQOP");
				if (csiv2ClaimIIOPTransportSSLServerAuth.getBoolean("enableProtection")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performTransportAssocSSLTLSSupported", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performTransportAssocSSLTLSSupported",
							"false");
				}

				if (csiv2ClaimIIOPTransportSSLServerAuth.getBoolean("integrity")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performMessageIntegritySupported", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performMessageIntegritySupported", "false");
				}

				if (csiv2ClaimIIOPTransportSSLServerAuth.getBoolean("confidentiality")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performMessageConfidentialitySupported",
							"true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performMessageConfidentialitySupported",
							"false");
				}

				if (csiv2ClaimIIOPTransportSSLServerAuth.getBoolean("establishTrustInClient")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performTLClientAuthenticationSupported",
							"true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performTLClientAuthenticationSupported",
							"false");
				}

				csiv2PerformTransportQOPRequired = csiv2PerformIIOPTransportLayer.getObject("requiredQOP");
				if (csiv2PerformTransportQOPRequired.getBoolean("enableProtection")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performTransportAssocSSLTLSRequired", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performTransportAssocSSLTLSRequired", "false");
				}

				if (csiv2PerformTransportQOPRequired.getBoolean("integrity")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performMessageIntegrityRequired", "true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performMessageIntegrityRequired", "false");
				}

				if (csiv2PerformTransportQOPRequired.getBoolean("confidentiality")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performMessageConfidentialityRequired",
							"true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performMessageConfidentialityRequired",
							"false");
				}

				if (csiv2PerformTransportQOPRequired.getBoolean("establishTrustInClient")) {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performTLClientAuthenticationRequired",
							"true");
				} else {
					this.globalConfigProperties.setProperty("com.ibm.CSI.performTLClientAuthenticationRequired",
							"false");
				}

				SecurityConfigObject csiv2PerformIIOPTransportSSLServerAuth = csiv2PerformIIOPTransportLayer
						.getObject("serverAuthentication");
				String sslAlias = null;
				if (PlatformHelperFactory.getPlatformHelper().isZOS()) {
					sslAlias = this.globalConfigProperties
							.getProperty("was.com.ibm.websphere.security.zos.csiv2.outbound.transport.sslconfig");
				}

				if (sslAlias == null) {
					sslAlias = csiv2PerformIIOPTransportSSLServerAuth.getString("sslConfig");
				}

				if (sslAlias != null) {
					this.globalConfigProperties.setProperty("com.ibm.ssl.csi.outbound.alias", sslAlias);
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadCSIv2SSLProperties");
		}

	}

	public Properties determineIfCSIv2SettingsApply(Properties config, Map connectionInfo) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "determineIfCSIv2SettingsApply", new Object[]{connectionInfo});
		}

		Properties newConfig = null;
		if (connectionInfo != null) {
			String endPointName = (String) connectionInfo.get("com.ibm.ssl.endPointName");
			String direction = (String) connectionInfo.get("com.ibm.ssl.direction");
			String sslAlias;
			if (endPointName != null
					&& (endPointName.equals("ORB_SSL_LISTENER_ADDRESS")
							|| endPointName.equals("CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS")
							|| endPointName.equals("CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS"))
					&& direction != null && direction.equals("inbound")) {
				sslAlias = this.globalConfigProperties.getProperty("com.ibm.ssl.csi.inbound.alias");
				if (sslAlias != null && sslAlias.length() > 0) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Getting inbound SSL config with alias: " + sslAlias);
					}

					newConfig = this.getProperties(sslAlias);
				}

				if (newConfig != null) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Cloning CSIv2 alias reference configuration.");
					}

					newConfig = (Properties) newConfig.clone();
				} else {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Cloning JSSEHelper configuration.");
					}

					newConfig = (Properties) config.clone();
				}

				if (newConfig != null) {
					String claimSSLClientAuthSupported = this.globalConfigProperties
							.getProperty("com.ibm.CSI.claimTLClientAuthenticationSupported");
					String claimSSLClientAuthRequired = this.globalConfigProperties
							.getProperty("com.ibm.CSI.claimTLClientAuthenticationRequired");
					if (claimSSLClientAuthSupported != null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Setting client auth supported: " + claimSSLClientAuthSupported);
						}

						newConfig.setProperty("com.ibm.ssl.clientAuthenticationSupported", claimSSLClientAuthSupported);
					}

					if (claimSSLClientAuthRequired != null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Setting client auth required: " + claimSSLClientAuthRequired);
						}

						newConfig.setProperty("com.ibm.ssl.clientAuthentication", claimSSLClientAuthRequired);
					}

					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "determineIfCSIv2SettingsApply (settings applied)");
					}

					return newConfig;
				}
			} else if ("IIOP".equals(endPointName) && "outbound".equals(direction)) {
				sslAlias = this.globalConfigProperties.getProperty("com.ibm.ssl.csi.outbound.alias");
				if (sslAlias != null && sslAlias.length() > 0) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Getting outbound SSL config with alias: " + sslAlias);
					}

					newConfig = this.getProperties(sslAlias);
				}

				if (newConfig != null) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Cloning CSIv2 alias reference configuration.");
					}

					newConfig = (Properties) newConfig.clone();
				} else {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Cloning JSSEHelper configuration.");
					}

					newConfig = (Properties) config.clone();
				}

				if (newConfig != null) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "determineIfCSIv2SettingsApply (settings applied)");
					}

					return newConfig;
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "determineIfCSIv2SettingsApply (original settings)");
		}

		return config;
	}

	public Properties getDefaultSystemProperties(boolean reinitialize) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDefaultSystemProperties");
		}

		if (!reinitialize && this.sslConfigMap.get("DefaultSystemProperties") != null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getDefaultSystemProperties -> already present.");
			}

			return (Properties) this.sslConfigMap.get("DefaultSystemProperties");
		} else {
			SSLConfig config = this.parseSecureSocketLayer("DefaultSystemProperties", "JSSE", (SecureSocketLayer) null,
					reinitialize);
			if (config != null && config.requiredPropertiesArePresent()) {
				config.setProperty("com.ibm.ssl.alias", "DefaultSystemProperties");
				config.setProperty("com.ibm.ssl.configURLLoadedFrom", "System Properties");
				config.decodePasswords();
				SSLConfig oldConfig = (SSLConfig) this.sslConfigMap.get("DefaultSystemProperties");
				if (oldConfig == null) {
					this.addSSLConfigToMap("DefaultSystemProperties", config, reinitialize);
				} else if (!oldConfig.equals(config)) {
					this.removeSSLConfigFromMap("DefaultSystemProperties", oldConfig);
					this.addSSLConfigToMap("DefaultSystemProperties", config, reinitialize);
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "New SSL config equals old SSL config for alias: DefaultSystemProperties");
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getDefaultSystemProperties -> found valid system properties");
				}

				return config;
			} else {
				this.setDefaultSystemPropertiesIfNecessary();
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getDefaultSystemProperties -> null");
				}

				return null;
			}
		}
	}

	public void setDefaultSystemPropertiesIfNecessary() {
      String defaultSSLSocketFactory = JSSEProviderFactory.getDefaultSSLSocketFactory();
      String defaultSSLServerSocketFactory = JSSEProviderFactory.getDefaultSSLServerSocketFactory();
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "setDefaultSystemPropertiesIfNecessary", new Object[]{defaultSSLSocketFactory, defaultSSLServerSocketFactory});
      }

      if (defaultSSLSocketFactory == null || defaultSSLServerSocketFactory == null || defaultSSLSocketFactory != null && !defaultSSLSocketFactory.equals("com.ibm.websphere.ssl.protocol.SSLSocketFactory") || defaultSSLServerSocketFactory != null && !defaultSSLServerSocketFactory.equals("com.ibm.websphere.ssl.protocol.SSLServerSocketFactory")) {
         SSLConfig systemPropertyConfig = (SSLConfig)this.sslConfigMap.get("DefaultSystemProperties");
         if (systemPropertyConfig == null) {
            systemPropertyConfig = this.getDefaultSSLConfig();
            if (systemPropertyConfig != null) {
               AccessController.doPrivileged(new 3(this, systemPropertyConfig));
               if (tc.isDebugEnabled()) {
                  Tr.debug(tc, "Set System JSSE properties using the following SSL config: " + systemPropertyConfig.toString());
               }
            }
         }
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "setDefaultSystemPropertiesIfNecessary");
      }

   }

	public SSLConfig getDefaultSSLConfig() throws IllegalArgumentException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDefaultSSLConfig");
		}

		String ignoreJVMKeystores = this.getGlobalProperty("com.ibm.websphere.ssl.ignore.jvm.keystores", "false");
		if (ignoreJVMKeystores.equalsIgnoreCase("true")) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getDefaultSSLConfig -> null as com.ibm.websphere.ssl.ignore.jvm.keystores is set.");
			}

			return null;
		} else {
			SSLConfig defaultSSLConfig = null;
			String defaultAlias = this.getGlobalProperty("com.ibm.ssl.defaultAlias");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "defaultAlias: " + defaultAlias);
			}

			if (defaultAlias != null) {
				defaultSSLConfig = (SSLConfig) this.sslConfigMap.get(defaultAlias);
				if (defaultSSLConfig != null) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "defaultAlias not null, getDefaultSSLConfig for: " + defaultAlias);
					}

					return defaultSSLConfig;
				}
			}

			String sslConfigAlias;
			String mapKey;
			if (defaultSSLConfig == null) {
				sslConfigAlias = ManagementScopeManager.getInstance().getProcessType();
				Iterator sslConfigIterator;
				Entry current;
				SSLConfig mapValue;
				if (sslConfigAlias.equals("DeploymentManager")) {
					sslConfigIterator = this.sslConfigMap.entrySet().iterator();

					while (sslConfigIterator.hasNext()) {
						current = (Entry) sslConfigIterator.next();
						mapValue = (SSLConfig) current.getValue();
						mapKey = (String) current.getKey();
						if (mapValue != null) {
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "getDefaultSSLConfig: " + mapKey);
							}

							if (mapKey.equals("CellDefaultSSLSettings")) {
								if (tc.isDebugEnabled()) {
									Tr.debug(tc, "defaultSSLConfig: " + mapValue.toString());
								}

								return mapValue;
							}
						}
					}
				} else {
					sslConfigIterator = this.sslConfigMap.entrySet().iterator();

					while (sslConfigIterator.hasNext()) {
						current = (Entry) sslConfigIterator.next();
						mapValue = (SSLConfig) current.getValue();
						mapKey = (String) current.getKey();
						if (mapValue != null) {
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "getDefaultSSLConfig: " + mapKey);
							}

							if (mapKey.equals("NodeDefaultSSLSettings")) {
								if (tc.isDebugEnabled()) {
									Tr.debug(tc, "defaultSSLConfig: " + mapValue.toString());
								}

								return mapValue;
							}
						}
					}
				}
			}

			if (defaultSSLConfig == null) {
				sslConfigAlias = "DefaultSystemProperties";
				SSLConfig defaultSystemConfig = new SSLConfig();
				defaultSystemConfig.setProperty("com.ibm.ssl.alias", sslConfigAlias);
				String keyStoreLocation = System.getProperty("javax.net.ssl.keyStore");
				if (keyStoreLocation != null) {
					defaultSystemConfig.setProperty("com.ibm.ssl.keyStore", keyStoreLocation);
				}

				String keyStorePassword = System.getProperty("javax.net.ssl.keyStorePassword");
				if (keyStorePassword != null) {
					defaultSystemConfig.setProperty("com.ibm.ssl.keyStorePassword", keyStorePassword);
				}

				mapKey = System.getProperty("javax.net.ssl.keyStoreType");
				if (mapKey != null) {
					defaultSystemConfig.setProperty("com.ibm.ssl.keyStoreType", mapKey);
				}

				String keyStoreProvider = System.getProperty("javax.net.ssl.keyStoreProvider");
				if (keyStoreProvider != null) {
					defaultSystemConfig.setProperty("com.ibm.ssl.keyStoreProvider", keyStoreProvider);
				}

				String trustStoreLocation = System.getProperty("javax.net.ssl.trustStore");
				if (trustStoreLocation != null) {
					defaultSystemConfig.setProperty("com.ibm.ssl.trustStore", trustStoreLocation);
				}

				String trustStorePassword = System.getProperty("javax.net.ssl.trustStorePassword");
				if (trustStorePassword != null) {
					defaultSystemConfig.setProperty("com.ibm.ssl.trustStorePassword", trustStorePassword);
				}

				String trustStoreType = System.getProperty("javax.net.ssl.trustStoreType");
				if (trustStoreType != null) {
					defaultSystemConfig.setProperty("com.ibm.ssl.trustStoreType", trustStoreType);
				}

				String trustStoreProvider = System.getProperty("javax.net.ssl.trustStoreProvider");
				if (trustStoreProvider != null) {
					defaultSystemConfig.setProperty("com.ibm.ssl.trustStoreProvider", trustStoreProvider);
				}

				try {
					if (defaultSystemConfig.requiredPropertiesArePresent()) {
						this.addSSLConfigToMap(sslConfigAlias, defaultSystemConfig);
					}
				} catch (Exception var15) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception adding default System properties to configuration.",
								new Object[]{var15});
					}

					Manager.Ffdc.log(var15, this, "com.ibm.ws.ssl.core.SSLConfigManager.getDefaultSSLConfig", "2058",
							new Object[]{this});
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getDefaultSSLConfig -> null");
			}

			return null;
		}
	}

	public Properties getPropertiesFromDynamicSelectionInfo(Map connectionInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPropertiesFromDynamicSelectionInfo", new Object[]{connectionInfo});
		}

		if (connectionInfo == null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getPropertiesFromDynamicSelectionInfo -> null (no connection info)");
			}

			return null;
		} else if (this.sslConfigDynamicSelectionMap.size() == 0) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getPropertiesFromDynamicSelectionInfo -> null (no dynamic selections configured)");
			}

			return null;
		} else {
			if (this.isCacheMissEnabled()) {
				TreeSet var2 = this.sslConfigDynamicSelectionCacheMissTreeSet;
				synchronized (this.sslConfigDynamicSelectionCacheMissTreeSet) {
					if (this.sslConfigDynamicSelectionCacheMissTreeSet.contains(connectionInfo)) {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "getPropertiesFromDynamicSelectionInfo -> previous cache miss.");
						}

						return null;
					}
				}
			}

			SSLConfig cachedConfig = (SSLConfig) this.sslConfigDynamicLookupCache.get(connectionInfo);
			if (cachedConfig != null) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getPropertiesFromDynamicSelectionInfo -> cached.");
				}

				return cachedConfig;
			} else {
				String direction = (String) connectionInfo.get("com.ibm.ssl.direction");
				if (direction != null && direction.equals("inbound")) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getPropertiesFromDynamicSelectionInfo -> null (direction inbound).");
					}

					return null;
				} else {
					String connInfoProtocolName = (String) connectionInfo.get("com.ibm.ssl.endPointName");
					String connInfoRemoteHost = (String) connectionInfo.get("com.ibm.ssl.remoteHost");
					String connInfoRemotePort = (String) connectionInfo.get("com.ibm.ssl.remotePort");
					if (connInfoProtocolName != null && connInfoProtocolName.equals("ADMIN_SOAP")) {
						SSLConfig oldSOAPConfig = this.getSSLConfig("ADMIN_SOAP");
						if (oldSOAPConfig != null) {
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "getPropertiesFromDynamicSelectionInfo -> returning old soap config.");
							}

							this.sslConfigDynamicLookupCache.put(connectionInfo, oldSOAPConfig);
							return oldSOAPConfig;
						}
					}

					Set sslConfigDynamicSelectionSet = this.sslConfigDynamicSelectionMap.keySet();
					Iterator sslConfigDynamicSelectionIterator = null;
					if (sslConfigDynamicSelectionSet != null && sslConfigDynamicSelectionSet.size() > 0) {
						sslConfigDynamicSelectionIterator = sslConfigDynamicSelectionSet.iterator();
					}

					if (sslConfigDynamicSelectionIterator != null) {
						label239 : while (true) {
							String dynamicSelectionInfo;
							String[] dynamicSelectionEntries;
							do {
								do {
									do {
										if (!sslConfigDynamicSelectionIterator.hasNext()) {
											break label239;
										}

										dynamicSelectionInfo = (String) sslConfigDynamicSelectionIterator.next();
										if (tc.isDebugEnabled()) {
											Tr.debug(tc, "SSLConfig dynamic selection info: " + dynamicSelectionInfo);
										}
									} while (dynamicSelectionInfo == null);

									dynamicSelectionEntries = dynamicSelectionInfo.split("\\|");
								} while (dynamicSelectionEntries == null);
							} while (dynamicSelectionEntries.length <= 0);

							for (int j = 0; j < dynamicSelectionEntries.length; ++j) {
								if (tc.isDebugEnabled()) {
									Tr.debug(tc, "Parsing entry " + j + " of " + dynamicSelectionEntries.length + ": "
											+ dynamicSelectionEntries[j]);
								}

								String[] dynamicSelectionAttributes = dynamicSelectionEntries[j].split(",");
								if (tc.isDebugEnabled()) {
									Tr.debug(tc,
											"This entry has " + dynamicSelectionAttributes.length + " attributes.");
								}

								if (dynamicSelectionAttributes != null && dynamicSelectionAttributes.length == 3) {
									String protocol = dynamicSelectionAttributes[0];
									String host = dynamicSelectionAttributes[1];
									String port = dynamicSelectionAttributes[2];
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Protocol: " + protocol + ", Host: " + host + ", Port: " + port);
									}

									if (protocol != null && host != null && port != null) {
										if (protocol.equals("*") || connInfoProtocolName != null
												&& protocol.equalsIgnoreCase(connInfoProtocolName)) {
											if (!this.doesHostMatch(host, connInfoRemoteHost)) {
												if (tc.isDebugEnabled()) {
													Tr.debug(tc, "Host does not match.");
												}
											} else if (!port.equals("*") && (connInfoRemotePort == null
													|| !port.equalsIgnoreCase(connInfoRemotePort))) {
												if (tc.isDebugEnabled()) {
													Tr.debug(tc, "Port does not match.");
												}
											} else {
												if (tc.isDebugEnabled()) {
													Tr.debug(tc, "Found a dynamic selection match!");
												}

												String sslAliasAndCert = (String) this.sslConfigDynamicSelectionMap
														.get(dynamicSelectionInfo);
												String sslAlias = null;
												String sslCert = null;
												if (sslAliasAndCert != null && sslAliasAndCert.indexOf(":") != -1) {
													String[] split = sslAliasAndCert.split(":");
													if (split != null && split.length == 2) {
														sslAlias = split[0];
														sslCert = split[1];
													}
												} else if (sslAliasAndCert != null) {
													sslAlias = sslAliasAndCert;
												}

												SSLConfig config = (SSLConfig) this.sslConfigMap.get(sslAlias);
												if (config != null) {
													if (sslCert != null) {
														String clientAlias = config
																.getProperty("com.ibm.ssl.keyStoreClientAlias");
														if (clientAlias == null || !clientAlias.equals(sslAlias)) {
															config = new SSLConfig(config);
															config.setProperty("com.ibm.ssl.keyStoreClientAlias",
																	sslCert);
														}
													}

													this.sslConfigDynamicLookupCache.put(connectionInfo, config);
													if (tc.isEntryEnabled()) {
														Tr.exit(tc, "getPropertiesFromDynamicSelectionInfo -> found.");
													}

													return config;
												}

												if (tc.isDebugEnabled()) {
													Tr.debug(tc, "Could not find the associated SSL configuration.");
												}
											}
										} else if (tc.isDebugEnabled()) {
											Tr.debug(tc, "Protocol does not match.");
										}
									} else if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Ending evaluation, one of the values is null.");
									}
								}
							}
						}
					}

					if (this.isCacheMissEnabled()) {
						TreeSet var26 = this.sslConfigDynamicSelectionCacheMissTreeSet;
						synchronized (this.sslConfigDynamicSelectionCacheMissTreeSet) {
							if (this.sslConfigDynamicSelectionCacheMissTreeSet.size() > 50) {
								if (tc.isDebugEnabled()) {
									Tr.debug(tc, "Cache miss tree set size is > 50, clearing the TreeSet.");
								}

								this.sslConfigDynamicSelectionCacheMissTreeSet.clear();
							}

							this.sslConfigDynamicSelectionCacheMissTreeSet.add(connectionInfo);
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Cache miss tree set size is "
										+ this.sslConfigDynamicSelectionCacheMissTreeSet.size() + " entries.");
							}
						}
					}

					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getPropertiesFromDynamicSelectionInfo -> null (not found).");
					}

					return null;
				}
			}
		}
	}

	boolean doesHostMatch(String host, String connInfoRemoteHost) {
		return host.equals("*") || connInfoRemoteHost != null && (connInfoRemoteHost.equalsIgnoreCase(host)
				|| connInfoRemoteHost.toLowerCase().endsWith(host.toLowerCase()));
	}

	public Properties getProperties(String alias) throws IllegalArgumentException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProperties", alias);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getProperties");
		}

		return this.getSSLConfig(alias);
	}

	public String getGlobalProperty(String name) {
		String value = null;
		if (this.globalConfigProperties != null) {
			value = System.getProperty(name);
			if (value == null) {
				value = this.globalConfigProperties.getProperty(name);
			}

			if (tc.isDebugEnabled() && value != null) {
				Tr.debug(tc, "getGlobalProperties -> " + value);
			}

			return value;
		} else {
			value = System.getProperty(name);
			if (tc.isDebugEnabled() && value != null) {
				Tr.debug(tc, "getGlobalProperties -> " + value);
			}

			return value;
		}
	}

	public String getGlobalProperty(String name, String defaultValue) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getGlobalProperty", new Object[]{name, defaultValue});
		}

		String value = this.getGlobalProperty(name);
		if (value == null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getGlobalProperty -> " + defaultValue);
			}

			return defaultValue;
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getGlobalProperty -> " + value);
			}

			return value;
		}
	}

	public String[] parseEnabledCiphers(String enabledCiphers) {
		return enabledCiphers != null ? enabledCiphers.split("\\s") : null;
	}

	public String[] adjustSupportedCiphersToSecurityLevel(String[] supportedCiphers, String securityLevel) {
		return Constants.adjustSupportedCiphersToSecurityLevel(supportedCiphers, securityLevel);
	}

	public String convertCipherListToString(String[] cipherList) {
		if (cipherList != null && cipherList.length != 0) {
			StringBuffer sb = new StringBuffer();

			for (int i = 0; i < cipherList.length; ++i) {
				sb.append(cipherList[i]);
				sb.append(" ");
			}

			return sb.toString();
		} else {
			return "null";
		}
	}

	public String getSecurityLevel(SSLSecurityLevel level) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSecurityLevel");
		}

		int value = level.getValue();
		String securityLevel = null;
		switch (value) {
			case 0 :
			default :
				securityLevel = "HIGH";
				break;
			case 1 :
				securityLevel = "MEDIUM";
				break;
			case 2 :
				securityLevel = "LOW";
				break;
			case 3 :
				securityLevel = "CUSTOM";
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSecurityLevel -> " + securityLevel);
		}

		return securityLevel;
	}

	public static String mask(String inString) {
		String outString = null;
		if (inString != null) {
			char[] outStringBuffer = new char[inString.length()];

			for (int i = 0; i < inString.length(); ++i) {
				outStringBuffer[i] = '*';
			}

			outString = new String(outStringBuffer);
		}

		return outString;
	}

	public void parseConfigURL(String defaultAlias, String configURL, boolean reinitialize) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "parseConfigURL", new Object[]{configURL});
		}

		if (configURL != null && (!this.clientFilesAlreadyProcessed.contains(configURL) || reinitialize)) {
			try {
				SSLConfig sslConfig = new SSLConfig(configURL);
				String alias = sslConfig.getProperty("com.ibm.ssl.alias");
				if (alias == null) {
					alias = defaultAlias;
					sslConfig.setProperty("com.ibm.ssl.alias", defaultAlias);
				}

				if (configURL.indexOf("soap.client.props") != -1) {
					if (sslConfig.getProperty("com.ibm.ssl.keyStoreType") == null) {
						sslConfig.setProperty("com.ibm.ssl.keyStoreType", "JKS");
					}

					if (sslConfig.getProperty("com.ibm.ssl.trustStoreType") == null) {
						sslConfig.setProperty("com.ibm.ssl.trustStoreType", "JKS");
					}
				}

				if (configURL.indexOf("sas.client.props") != -1) {
					this.globalConfigProperties.put("com.ibm.CSI.performTLClientAuthenticationRequired",
							sslConfig.getProperty("com.ibm.CSI.performTLClientAuthenticationRequired"));
					this.globalConfigProperties.put("com.ibm.CSI.performTLClientAuthenticationSupported",
							sslConfig.getProperty("com.ibm.CSI.performTLClientAuthenticationSupported"));
				}

				SSLConfig oldConfig;
				if (sslConfig.requiredPropertiesArePresent()) {
					sslConfig.setProperty("com.ibm.ssl.configURLLoadedFrom", configURL);
					sslConfig.decodePasswords();
					if (reinitialize) {
						oldConfig = (SSLConfig) this.sslConfigMap.get(alias);
						if (oldConfig == null) {
							this.addSSLConfigToMap(alias, sslConfig, reinitialize);
						} else if (!oldConfig.equals(sslConfig)) {
							this.removeSSLConfigFromMap(alias, sslConfig);
							this.addSSLConfigToMap(alias, sslConfig, reinitialize);
							this.notifySSLConfigChangeListener(alias, "changed");
						} else if (tc.isDebugEnabled()) {
							Tr.debug(tc, "New SSL config equals old SSL config for alias: " + alias);
						}
					} else {
						this.addSSLConfigToMap(alias, sslConfig);
					}
				} else if (reinitialize) {
					oldConfig = (SSLConfig) this.sslConfigMap.get(alias);
					if (oldConfig != null) {
						this.removeSSLConfigFromMap(alias, oldConfig);
						this.notifySSLConfigChangeListener(alias, "deleted");
					}
				}

				this.clientFilesAlreadyProcessed.add(configURL);
			} catch (Exception var7) {
				Tr.error(tc, "ssl.client.config.parse.CWPKI0019E",
						new Object[]{configURL,
								var7.getMessage() != null
										? var7.getClass().getName() + ":" + var7.getMessage()
										: var7.getClass().getName()});
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception parsing SSL properties from ConfigURL.", new Object[]{var7});
				}

				Manager.Ffdc.log(var7, this, "com.ibm.ws.ssl.core.SSLConfigManager.parseConfigURL", "2567",
						new Object[]{this});
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "parseConfigURL");
		}

	}

	public void parseSSLConfigURL(String configURL, boolean reinitialize) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "parseSSLConfigURL", new Object[]{configURL, new Boolean(reinitialize)});
		}

		if (configURL != null && (!this.clientFilesAlreadyProcessed.contains(configURL) || reinitialize)) {
			try {
				String[] existingAliases = null;
				Set newAliases = null;
				if (reinitialize) {
					newAliases = new HashSet();
					existingAliases = (String[]) ((String[]) this.sslConfigMap.keySet().toArray(new String[0]));
				}

				SSLConfig tempSSLConfig = new SSLConfig();
				SSLConfig[] sslConfigArray = tempSSLConfig.loadPropertiesFile(configURL, true);
				int i;
				if (sslConfigArray == null) {
					new File(configURL);
					if (!(new File(configURL)).exists()) {
						throw new FileNotFoundException(configURL);
					}
				} else {
					for (i = 0; i < sslConfigArray.length; ++i) {
						String alias;
						if (i == 0 && sslConfigArray[0] != null) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Getting global SSL properties.");
							}

							if (tc.isDebugEnabled()) {
								Tr.debug(tc, sslConfigArray[i].toString());
							}

							this.globalConfigProperties.putAll(sslConfigArray[0]);
							Enumeration lists = this.globalConfigProperties.propertyNames();

							while (lists.hasMoreElements()) {
								alias = (String) lists.nextElement();
								this.setCheckRevocationProperties(alias,
										(String) this.globalConfigProperties.get(alias));
							}

							if (tc.isDebugEnabled()) {
								this.printTrustManagerProperties();
							}
						} else if (sslConfigArray[i] != null && sslConfigArray[i].requiredPropertiesArePresent()) {
							SSLConfig sslConfig = sslConfigArray[i];
							alias = sslConfig.getProperty("com.ibm.ssl.alias");
							sslConfig.setProperty("com.ibm.ssl.configURLLoadedFrom", configURL);
							sslConfig.decodePasswords();
							if (reinitialize) {
								newAliases.add(alias);
								SSLConfig oldConfig = (SSLConfig) this.sslConfigMap.get(alias);
								if (oldConfig == null) {
									this.addSSLConfigToMap(alias, sslConfig, reinitialize);
								} else if (!oldConfig.equals(sslConfig)) {
									this.removeSSLConfigFromMap(alias, sslConfig);
									this.addSSLConfigToMap(alias, sslConfig, reinitialize);
									this.notifySSLConfigChangeListener(alias, "changed");
								} else if (tc.isDebugEnabled()) {
									Tr.debug(tc, "New SSL config equals old SSL config for alias: " + alias);
								}
							} else {
								this.addSSLConfigToMap(alias, sslConfig);
							}
						}
					}
				}

				this.clientFilesAlreadyProcessed.add(configURL);
				if (reinitialize) {
					for (i = 0; i < existingAliases.length; ++i) {
						String oldAlias = existingAliases[i];
						SSLConfig oldConfig = (SSLConfig) this.sslConfigMap.get(oldAlias);
						String oldConfigURL = oldConfig.getProperty("com.ibm.ssl.configURLLoadedFrom");
						if (oldConfig != null && !newAliases.contains(oldAlias) && oldConfigURL.equals(configURL)) {
							this.removeSSLConfigFromMap(oldAlias, oldConfig);
							this.notifySSLConfigChangeListener(oldAlias, "deleted");
						}
					}
				}
			} catch (Exception var11) {
				Tr.error(tc, "ssl.client.config.parse.CWPKI0019E",
						new Object[]{configURL,
								var11.getMessage() != null
										? var11.getClass().getName() + ":" + var11.getMessage()
										: var11.getClass().getName()});
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception parsing SSL properties from ssl.client.props.", new Object[]{var11});
				}

				Manager.Ffdc.log(var11, this, "com.ibm.ws.ssl.core.SSLConfigManager.parseSSLConfigURL", "2765",
						new Object[]{this});
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "parseSSLConfigURL");
		}

	}

	public void removeSSLConfigFromMap(String alias, SSLConfig sslConfig) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "removeSSLConfigFromMap", new Object[]{alias});
		}

		String dynamicSelectionInfo = sslConfig.getDynamicSelectionProperty();
		if (dynamicSelectionInfo != null && !dynamicSelectionInfo.equals("")) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Removing old SSL properties from dynamic selection info list.");
			}

			this.sslConfigDynamicSelectionMap.remove(dynamicSelectionInfo);
		}

		this.sslConfigMap.remove(alias);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "removeSSLConfigFromMap");
		}

	}

	public void addSSLConfigToMap(String alias, SSLConfig sslConfig) throws Exception {
		this.addSSLConfigToMap(alias, sslConfig, false);
	}

	public void addSSLConfigToMap(String alias, SSLConfig sslConfig, boolean reinitialize) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "addSSLConfigToMap");
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Adding SSL properties for alias: " + alias);
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, sslConfig.toString());
		}

		sslConfig.expandPaths();
		if (this.validationEnabled()) {
			sslConfig.validateSSLConfig();
		}

		if (!this.isServerProcess) {
			if (reinitialize) {
				KeyStoreManager.getInstance().refreshClientKeyStoreAndTrustStore(sslConfig);
			} else {
				KeyStoreManager.getInstance().checkIfClientKeyStoreAndTrustStoreExistsAndCreateIfNot(sslConfig);
			}
		}

		this.sslConfigMap.put(alias, sslConfig);
		String dynamicSelectionInfo = sslConfig.getDynamicSelectionProperty();
		if (dynamicSelectionInfo != null && !dynamicSelectionInfo.equals("")) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Adding SSL properties to dynamic selection list with value: " + dynamicSelectionInfo);
			}

			this.sslConfigDynamicSelectionMap.put(dynamicSelectionInfo, alias);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addSSLConfigToMap");
		}

	}

	public String toString() {
		if (this.sslConfigMap.size() <= 0) {
			return "SSLConfigManager does not contain any SSL configurations.";
		} else {
			Iterator sslConfigIterator = this.sslConfigMap.entrySet().iterator();
			StringBuffer sb = new StringBuffer();
			sb.append("SSLConfigManager configuration: \n");

			while (sslConfigIterator.hasNext()) {
				Entry current = (Entry) sslConfigIterator.next();
				SSLConfig mapValue = (SSLConfig) current.getValue();
				String mapKey = (String) current.getKey();
				sb.append(mapKey);
				sb.append("===");
				sb.append(mapValue.toString());
			}

			return sb.toString();
		}
	}

	public boolean validationEnabled() {
		String validate = this.getGlobalProperty("com.ibm.ssl.validationEnabled");
		return validate != null && (validate.equalsIgnoreCase("true") || validate.equalsIgnoreCase("yes"));
	}

	public boolean isCacheMissEnabled() {
		if (this.disableCacheMiss == DISABLE_CACHE_MISS_PROP_NEVER_LOOKED_UP) {
			String value = this.getGlobalProperty("com.ibm.websphere.crypto.config.disableCacheMiss");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "value = " + value);
			}

			if (value == null || !value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("yes")) {
				this.disableCacheMiss = CACHE_MISS_ENABLED;
			} else {
				this.disableCacheMiss = CACHE_MISS_DISABLED;
			}
		}

		if (this.disableCacheMiss == CACHE_MISS_DISABLED) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Cached miss is disabled");
			}

			return false;
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Cached miss is enabled");
			}

			return true;
		}
	}

	public void checkURLHostNameVerificationProperty(boolean reinitialize) {
      String urlHostNameVerification = this.getGlobalProperty("com.ibm.ssl.performURLHostNameVerification");
      if (urlHostNameVerification == null || urlHostNameVerification.equalsIgnoreCase("false") || urlHostNameVerification.equalsIgnoreCase("no")) {
         HostnameVerifier verifier = new 4(this);
         HttpsURLConnection.setDefaultHostnameVerifier(verifier);
         if (!reinitialize) {
            Tr.info(tc, "ssl.disable.url.hostname.verification.CWPKI0027I");
         }
      }

   }

	public synchronized void notifySSLConfigChangeListener(String alias, String state) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "notifySSLConfigChangeListener", new Object[]{alias, state});
		}

		if (alias != null) {
			List listenerList = (List) this.sslConfigListenerMap.get(alias);
			if (listenerList != null && listenerList.size() > 0) {
				SSLConfigChangeListener[] listenerArray = (SSLConfigChangeListener[]) ((SSLConfigChangeListener[]) listenerList
						.toArray(new SSLConfigChangeListener[listenerList.size()]));

				for (int i = 0; i < listenerArray.length; ++i) {
					SSLConfigChangeEvent event = null;
					event = (SSLConfigChangeEvent) this.sslConfigListenerEventMap.get(listenerArray[i]);
					if (event != null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Notifying listener[" + i + "]: " + listenerArray[i].getClass().getName());
						}

						event.setState(state);
						SSLConfig changedConfig = (SSLConfig) this.sslConfigMap.get(alias);
						event.setChangedSSLConfig(changedConfig);
						listenerArray[i].stateChanged(event);
						if (state.equals("deleted")) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Deregistering event for listener.");
							}

							this.sslConfigListenerEventMap.remove(listenerArray[i]);
						}
					}
				}

				if (state.equals("deleted")) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Deregistering all listeners for this alias due to alias deletion.");
					}

					this.sslConfigListenerMap.remove(alias);
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "notifySSLConfigChangeListener");
		}

	}

	public synchronized void registerSSLConfigChangeListener(SSLConfigChangeListener listener,
			SSLConfigChangeEvent event) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "registerSSLConfigChangeListener", new Object[]{listener, event});
		}

		List listenerList = (List) this.sslConfigListenerMap.get(event.getAlias());
		if (listenerList != null) {
			listenerList.add(listener);
			this.sslConfigListenerMap.put(event.getAlias(), listenerList);
		} else {
			List listenerList = new ArrayList();
			listenerList.add(listener);
			this.sslConfigListenerMap.put(event.getAlias(), listenerList);
		}

		this.sslConfigListenerEventMap.put(listener, event);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "registerSSLConfigChangeListener");
		}

	}

	public synchronized void deregisterSSLConfigChangeListener(SSLConfigChangeListener listener) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "deregisterSSLConfigChangeListener", new Object[]{listener});
		}

		SSLConfigChangeEvent event = null;
		if (listener != null && this.sslConfigListenerEventMap.containsKey(listener)) {
			event = (SSLConfigChangeEvent) this.sslConfigListenerEventMap.get(listener);
		}

		if (event != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Removing listener: " + listener.getClass().getName());
			}

			String alias = event.getAlias();
			if (this.sslConfigListenerMap.containsKey(alias)) {
				List listenerList = (List) this.sslConfigListenerMap.get(alias);
				if (listenerList != null) {
					int index = listenerList.indexOf(listener);
					if (index != -1) {
						listenerList.remove(index);
					}
				}
			}

			this.sslConfigListenerEventMap.remove(listener);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "deregisterSSLConfigChangeListener");
		}

	}

	public boolean isServerProcess() {
		return this.isServerProcess;
	}

	public String[] getSystemSSLCiphers() throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSystemSSLCiphers");
		}

		ArrayList cipherList = new ArrayList();
		boolean extendedPolicy = false;
		if (this.isExtendedPolicy()) {
			extendedPolicy = true;
		}

		for (int i = 0; i < SystemSSLCiphers.length; ++i) {
			if (SystemSSLCiphers[i][1].indexOf("AES_256") != -1) {
				if (extendedPolicy) {
					cipherList.add(SystemSSLCiphers[i][1]);
				}
			} else {
				cipherList.add(SystemSSLCiphers[i][1]);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSystemSSLCiphers");
		}

		return (String[]) ((String[]) cipherList.toArray(new String[0]));
	}

	public String convertCiphersList(String cipherString) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "convertCiphersList", new Object[]{cipherString});
		}

		String[] orderedCipherList = new String[SystemSSLCiphers.length];
		String[] ciphers = cipherString.split(" ");

		int i;
		for (int i = 0; i < ciphers.length; ++i) {
			for (i = 0; i < SystemSSLCiphers.length; ++i) {
				if (SystemSSLCiphers[i][1].equals(ciphers[i])) {
					orderedCipherList[i] = SystemSSLCiphers[i][0];
					break;
				}
			}
		}

		String orderedCiphers = "";

		for (i = 0; i < orderedCipherList.length; ++i) {
			if (orderedCipherList[i] != null) {
				orderedCiphers = orderedCiphers + orderedCipherList[i];
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "convertCiphersList");
		}

		return orderedCiphers;
	}

	public String getSystemSSLList(String ciphers) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSystemSSLList", new Object[]{ciphers});
		}

		StringBuffer cipherBuffer = new StringBuffer();

		for (int i = 0; i < ciphers.length(); i += 2) {
			String key = ciphers.substring(i, i + 2);

			for (int j = 0; j < SystemSSLCiphers.length; ++j) {
				if (SystemSSLCiphers[j][0].equals(key)) {
					cipherBuffer.append(SystemSSLCiphers[j][1]);
					cipherBuffer.append(" ");
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSystemSSLList");
		}

		return cipherBuffer.toString();
	}

	public boolean isExtendedPolicy() throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isExtendedPolicy");
		}

		boolean extendedPolicy = false;
		String[] SUITE_B_UNRESTRICTED_POLICY_ONLY_CIPER_SUITES = new String[]{
				"SSL_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384"};
		String[] NON_SUITE_B_UNRESTRICTED_POLICY_ONLY_CIPER_SUITES = new String[]{"SSL_RSA_WITH_AES_256_CBC_SHA"};
		boolean suiteBMode = false;
		String[] suites = null;
		String suiteBProp = System.getProperty("com.ibm.jsse2.suiteB");
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "JDK System Property:com.ibm.jsse2.suiteB is " + suiteBProp);
		}

		if (suiteBProp != null && (suiteBProp.equalsIgnoreCase("128") || suiteBProp.equalsIgnoreCase("192"))) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Using suiteB ciphers to check policy");
			}

			suites = SUITE_B_UNRESTRICTED_POLICY_ONLY_CIPER_SUITES;
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Using non-suiteB ciphers to check policy");
			}

			suites = NON_SUITE_B_UNRESTRICTED_POLICY_ONLY_CIPER_SUITES;
		}

		try {
			SSLContext context = JSSEHelper.getInstance().getSSLContext((String) null, (Map) null,
					(SSLConfigChangeListener) null);
			SSLServerSocketFactory factory = context.getServerSocketFactory();
			SSLServerSocket ssl_sock = null;
			ssl_sock = (SSLServerSocket) factory.createServerSocket();
			ssl_sock.setEnabledCipherSuites(suites);
			extendedPolicy = true;
		} catch (IllegalArgumentException var10) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Extened policy is not availible");
			}
		} catch (Exception var11) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception while checking restricted/unrestricted policy");
			}

			throw var11;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isExtendedPolicy", extendedPolicy);
		}

		return extendedPolicy;
	}

	public SSLSocket setCipherListOnSocket(Properties props, SSLSocket socket) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setCipherListOnSocket");
		}

		if (props == null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setCipherListOnSocket props == null");
			}

			return socket;
		} else {
			String[] ciphers = null;
			String cipherString = props != null ? props.getProperty("com.ibm.ssl.enabledCipherSuites") : null;
			if (socket != null) {
				try {
					if (cipherString != null) {
						ciphers = cipherString.split("\\s");
					} else {
						String securityLevel = props.getProperty("com.ibm.ssl.securityLevel");
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "securityLevel from properties is " + securityLevel);
						}

						if (securityLevel == null) {
							securityLevel = "HIGH";
						}

						String[] supportedCiphers = socket.getSupportedCipherSuites();
						ciphers = getInstance().adjustSupportedCiphersToSecurityLevel(supportedCiphers, securityLevel);
					}

					if (ciphers != null) {
						socket.setEnabledCipherSuites(ciphers);
					}
				} catch (Exception var7) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception setting ciphers in SSL Socket Factory.", new Object[]{var7});
					}
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setCipherListOnSocket");
			}

			return socket;
		}
	}

	public SSLServerSocket setCipherListOnServerSocket(Properties props, SSLServerSocket socket) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setCipherListOnServerSocket");
		}

		if (props == null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setCipherListOnServerSocket props == null");
			}

			return socket;
		} else {
			String[] ciphers = null;
			String cipherString = props.getProperty("com.ibm.ssl.enabledCipherSuites");
			if (socket != null) {
				try {
					String clientAuthSupported;
					if (cipherString != null) {
						ciphers = cipherString.split("\\s");
					} else {
						clientAuthSupported = props.getProperty("com.ibm.ssl.securityLevel");
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "securityLevel from properties is " + clientAuthSupported);
						}

						if (clientAuthSupported == null) {
							clientAuthSupported = "HIGH";
						}

						String[] supportedCiphers = socket.getSupportedCipherSuites();
						ciphers = getInstance().adjustSupportedCiphersToSecurityLevel(supportedCiphers,
								clientAuthSupported);
					}

					if (ciphers != null) {
						socket.setEnabledCipherSuites(ciphers);
					}

					clientAuthSupported = props.getProperty("com.ibm.ssl.clientAuthenticationSupported");
					if (clientAuthSupported != null && clientAuthSupported.equals("true")) {
						socket.setWantClientAuth(true);
					}

					String clientAuth = props.getProperty("com.ibm.ssl.clientAuthentication");
					if (clientAuth != null && clientAuth.equals("true")) {
						socket.setNeedClientAuth(true);
					}
				} catch (Exception var7) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception setting ciphers in SSL Socket Factory.", new Object[]{var7});
					}
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setCipherListOnServerSocket");
			}

			return socket;
		}
	}

	public boolean isClientAuthenticationEnabled() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isClientAuthenticationEnabled");
		}

		boolean auth = false;
		CSIv2Config csiv2 = SecurityObjectLocator.getCSIv2Config();
		if (csiv2 != null) {
			boolean domainReq = csiv2.getBoolean("com.ibm.CSI.performTLClientAuthenticationRequired");
			boolean domainSup = csiv2.getBoolean("com.ibm.CSI.performTLClientAuthenticationSupported");
			auth = domainReq || domainSup;
			Tr.debug(tc, "isClientAuthenticationEnabled - from CSIv2Config - performs TL client auth required is "
					+ domainReq + " and supported is " + domainSup);
		} else {
			Tr.debug(tc, "is ClientAuthenticationEnabled - CSIv2Config is null so use global properties");
			String claimSSLClientAuthSupported = this
					.getGlobalProperty("com.ibm.CSI.performTLClientAuthenticationSupported");
			String claimSSLClientAuthRequired = this
					.getGlobalProperty("com.ibm.CSI.performTLClientAuthenticationRequired");
			Tr.debug(tc, "Global properties for supported is " + claimSSLClientAuthSupported + " and required is "
					+ claimSSLClientAuthRequired);
			if (claimSSLClientAuthRequired != null && claimSSLClientAuthSupported != null
					&& (claimSSLClientAuthRequired.equalsIgnoreCase("true")
							|| claimSSLClientAuthSupported.equalsIgnoreCase("true"))) {
				auth = true;
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isClientAuthenticationEnabled", new Boolean(auth));
		}

		return auth;
	}

	void processIbmPKIXTrustManagerProperties(TrustManager tm) {
		List<?> attrs = tm.getAdditionalTrustManagerAttrs();

		for (int j = 0; j < attrs.size(); ++j) {
			DescriptiveProperty property = (DescriptiveProperty) attrs.get(j);
			String value = property.getValue();
			if (value != null && !value.equalsIgnoreCase("")) {
				this.setCheckRevocationProperties(property.getName(), value);
			}
		}

	}

	public String getSSLProtocolForFipsLevel(SSLConfig sslprops) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLProtocolForFipsLevel");
		}

		String protocol = sslprops.getProperty("com.ibm.ssl.protocol");
		boolean fipsEnabled = FIPSManager.getInstance().isFIPSEnabled();
		String fipsLevel = FIPSManager.getInstance().getFipsLevel();
		String suiteBLevel = FIPSManager.getInstance().getSuiteBLevel();
		List<String> validProtocols = FIPSUtils.getProtocolTypes(fipsEnabled, fipsLevel, suiteBLevel);
		int securityMode = FIPSUtils.getFipsSecurityMode(fipsEnabled, fipsLevel, suiteBLevel);
		if (!validProtocols.contains(protocol)) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc,
						"Invalid SSL Protocol:" + protocol + " found in the configuration. "
								+ "Valid protocols for FipsLevel:" + Constants.securityModeName[securityMode] + " is "
								+ validProtocols + " Setting protocol to " + (String) validProtocols.get(0));
			}

			protocol = (String) validProtocols.get(0);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSSLProtocolForFipsLevel", protocol);
		}

		return protocol;
	}
}