package com.google.common.hash;

import com.google.common.hash.Murmur3_128HashFunction.Murmur3_128Hasher;
import java.io.Serializable;

final class Murmur3_128HashFunction extends AbstractStreamingHashFunction implements Serializable {
	private final int seed;
	private static final long serialVersionUID = 0L;

	Murmur3_128HashFunction(int seed) {
		this.seed = seed;
	}

	public int bits() {
		return 128;
	}

	public Hasher newHasher() {
		return new Murmur3_128Hasher(this.seed);
	}

	public String toString() {
		return "Hashing.murmur3_128(" + this.seed + ")";
	}
}