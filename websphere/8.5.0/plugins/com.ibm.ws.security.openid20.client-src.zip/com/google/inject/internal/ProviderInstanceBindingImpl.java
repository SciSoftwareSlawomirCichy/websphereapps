package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.Provider;
import com.google.inject.spi.BindingTargetVisitor;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.HasDependencies;
import com.google.inject.spi.InjectionPoint;
import com.google.inject.spi.ProviderInstanceBinding;
import java.util.Set;

public final class ProviderInstanceBindingImpl<T> extends BindingImpl<T> implements ProviderInstanceBinding<T> {
	final Provider<? extends T> providerInstance;
	final ImmutableSet<InjectionPoint> injectionPoints;

	public ProviderInstanceBindingImpl(Injector injector, Key<T> key, Object source,
			InternalFactory<? extends T> internalFactory, Scoping scoping, Provider<? extends T> providerInstance,
			Set<InjectionPoint> injectionPoints) {
		super(injector, key, source, internalFactory, scoping);
		this.providerInstance = providerInstance;
		this.injectionPoints = ImmutableSet.copyOf(injectionPoints);
	}

	public ProviderInstanceBindingImpl(Object source, Key<T> key, Scoping scoping, Set<InjectionPoint> injectionPoints,
			Provider<? extends T> providerInstance) {
		super(source, key, scoping);
		this.injectionPoints = ImmutableSet.copyOf(injectionPoints);
		this.providerInstance = providerInstance;
	}

	public <V> V acceptTargetVisitor(BindingTargetVisitor<? super T, V> visitor) {
		return visitor.visit(this);
	}

	public Provider<? extends T> getProviderInstance() {
		return this.providerInstance;
	}

	public Set<InjectionPoint> getInjectionPoints() {
		return this.injectionPoints;
	}

	public Set<Dependency<?>> getDependencies() {
		return (Set) (this.providerInstance instanceof HasDependencies
				? ImmutableSet.copyOf(((HasDependencies) this.providerInstance).getDependencies())
				: Dependency.forInjectionPoints(this.injectionPoints));
	}

	public BindingImpl<T> withScoping(Scoping scoping) {
		return new ProviderInstanceBindingImpl(this.getSource(), this.getKey(), scoping, this.injectionPoints,
				this.providerInstance);
	}

	public BindingImpl<T> withKey(Key<T> key) {
		return new ProviderInstanceBindingImpl(this.getSource(), key, this.getScoping(), this.injectionPoints,
				this.providerInstance);
	}

	public void applyTo(Binder binder) {
		this.getScoping().applyTo(
				binder.withSource(this.getSource()).bind(this.getKey()).toProvider(this.getProviderInstance()));
	}

	public String toString() {
		return (new ToStringBuilder(ProviderInstanceBinding.class)).add("key", this.getKey())
				.add("source", this.getSource()).add("scope", this.getScoping()).add("provider", this.providerInstance)
				.toString();
	}
}