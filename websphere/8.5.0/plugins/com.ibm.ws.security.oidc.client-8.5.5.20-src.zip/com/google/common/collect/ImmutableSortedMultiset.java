package com.google.common.collect;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.math.IntMath;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.concurrent.LazyInit;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

@GwtIncompatible
public abstract class ImmutableSortedMultiset<E> extends ImmutableSortedMultisetFauxverideShim<E>
		implements
			SortedMultiset<E> {
	@LazyInit
	transient ImmutableSortedMultiset<E> descendingMultiset;

	public static <E> ImmutableSortedMultiset<E> of() {
		return RegularImmutableSortedMultiset.NATURAL_EMPTY_MULTISET;
	}

	public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E element) {
		RegularImmutableSortedSet<E> elementSet = (RegularImmutableSortedSet) ImmutableSortedSet.of(element);
		long[] cumulativeCounts = new long[]{0L, 1L};
		return new RegularImmutableSortedMultiset(elementSet, cumulativeCounts, 0, 1);
	}

	public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2) {
		return copyOf(Ordering.natural(), (Iterable) Arrays.asList(e1, e2));
	}

	public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3) {
		return copyOf(Ordering.natural(), (Iterable) Arrays.asList(e1, e2, e3));
	}

	public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3, E e4) {
		return copyOf(Ordering.natural(), (Iterable) Arrays.asList(e1, e2, e3, e4));
	}

	public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3, E e4, E e5) {
		return copyOf(Ordering.natural(), (Iterable) Arrays.asList(e1, e2, e3, e4, e5));
	}

	public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3, E e4, E e5, E e6,
			E... remaining) {
		int size = remaining.length + 6;
		List<E> all = Lists.newArrayListWithCapacity(size);
		Collections.addAll(all, new Comparable[]{e1, e2, e3, e4, e5, e6});
		Collections.addAll(all, remaining);
		return copyOf(Ordering.natural(), (Iterable) all);
	}

	public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> copyOf(E[] elements) {
		return copyOf(Ordering.natural(), (Iterable) Arrays.asList(elements));
	}

	public static <E> ImmutableSortedMultiset<E> copyOf(Iterable<? extends E> elements) {
		Ordering<E> naturalOrder = Ordering.natural();
		return copyOf(naturalOrder, (Iterable) elements);
	}

	public static <E> ImmutableSortedMultiset<E> copyOf(Iterator<? extends E> elements) {
		Ordering<E> naturalOrder = Ordering.natural();
		return copyOf(naturalOrder, (Iterator) elements);
	}

	public static <E> ImmutableSortedMultiset<E> copyOf(Comparator<? super E> comparator,
			Iterator<? extends E> elements) {
		Preconditions.checkNotNull(comparator);
		return (new Builder(comparator)).addAll(elements).build();
	}

	public static <E> ImmutableSortedMultiset<E> copyOf(Comparator<? super E> comparator,
			Iterable<? extends E> elements) {
		if (elements instanceof ImmutableSortedMultiset) {
			ImmutableSortedMultiset<E> multiset = (ImmutableSortedMultiset) elements;
			if (comparator.equals(multiset.comparator())) {
				if (multiset.isPartialView()) {
					return copyOfSortedEntries(comparator, multiset.entrySet().asList());
				}

				return multiset;
			}
		}

		return (new Builder(comparator)).addAll(elements).build();
	}

	public static <E> ImmutableSortedMultiset<E> copyOfSorted(SortedMultiset<E> sortedMultiset) {
		return copyOfSortedEntries(sortedMultiset.comparator(), Lists.newArrayList(sortedMultiset.entrySet()));
	}

	private static <E> ImmutableSortedMultiset<E> copyOfSortedEntries(Comparator<? super E> comparator,
			Collection<Multiset.Entry<E>> entries) {
		if (entries.isEmpty()) {
			return emptyMultiset(comparator);
		} else {
			ImmutableList.Builder<E> elementsBuilder = new ImmutableList.Builder(entries.size());
			long[] cumulativeCounts = new long[entries.size() + 1];
			int i = 0;

			for (Iterator var5 = entries.iterator(); var5.hasNext(); ++i) {
				Multiset.Entry<E> entry = (Multiset.Entry) var5.next();
				elementsBuilder.add(entry.getElement());
				cumulativeCounts[i + 1] = cumulativeCounts[i] + (long) entry.getCount();
			}

			return new RegularImmutableSortedMultiset(
					new RegularImmutableSortedSet(elementsBuilder.build(), comparator), cumulativeCounts, 0,
					entries.size());
		}
	}

	static <E> ImmutableSortedMultiset<E> emptyMultiset(Comparator<? super E> comparator) {
		return (ImmutableSortedMultiset) (Ordering.natural().equals(comparator)
				? RegularImmutableSortedMultiset.NATURAL_EMPTY_MULTISET
				: new RegularImmutableSortedMultiset(comparator));
	}

	ImmutableSortedMultiset() {
	}

	public final Comparator<? super E> comparator() {
		return this.elementSet().comparator();
	}

	public abstract ImmutableSortedSet<E> elementSet();

	public ImmutableSortedMultiset<E> descendingMultiset() {
		ImmutableSortedMultiset<E> result = this.descendingMultiset;
		return result == null
				? (this.descendingMultiset = (ImmutableSortedMultiset) (this.isEmpty()
						? emptyMultiset(Ordering.from(this.comparator()).reverse())
						: new DescendingImmutableSortedMultiset(this)))
				: result;
	}

	/** @deprecated */
	@Deprecated
	@CanIgnoreReturnValue
	public final Multiset.Entry<E> pollFirstEntry() {
		throw new UnsupportedOperationException();
	}

	/** @deprecated */
	@Deprecated
	@CanIgnoreReturnValue
	public final Multiset.Entry<E> pollLastEntry() {
		throw new UnsupportedOperationException();
	}

	public abstract ImmutableSortedMultiset<E> headMultiset(E var1, BoundType var2);

	public ImmutableSortedMultiset<E> subMultiset(E lowerBound, BoundType lowerBoundType, E upperBound,
			BoundType upperBoundType) {
		Preconditions.checkArgument(this.comparator().compare(lowerBound, upperBound) <= 0,
				"Expected lowerBound <= upperBound but %s > %s", lowerBound, upperBound);
		return this.tailMultiset(lowerBound, lowerBoundType).headMultiset(upperBound, upperBoundType);
	}

	public abstract ImmutableSortedMultiset<E> tailMultiset(E var1, BoundType var2);

	public static <E> Builder<E> orderedBy(Comparator<E> comparator) {
		return new Builder(comparator);
	}

	public static <E extends Comparable<?>> Builder<E> reverseOrder() {
		return new Builder(Ordering.natural().reverse());
	}

	public static <E extends Comparable<?>> Builder<E> naturalOrder() {
		return new Builder(Ordering.natural());
	}

	Object writeReplace() {
		return new SerializedForm(this);
	}

	private static final class SerializedForm<E> implements Serializable {
		final Comparator<? super E> comparator;
		final E[] elements;
		final int[] counts;

		SerializedForm(SortedMultiset<E> multiset) {
			this.comparator = multiset.comparator();
			int n = multiset.entrySet().size();
			this.elements = (Object[]) (new Object[n]);
			this.counts = new int[n];
			int i = 0;

			for (Iterator var4 = multiset.entrySet().iterator(); var4.hasNext(); ++i) {
				Multiset.Entry<E> entry = (Multiset.Entry) var4.next();
				this.elements[i] = entry.getElement();
				this.counts[i] = entry.getCount();
			}

		}

		Object readResolve() {
			int n = this.elements.length;
			Builder<E> builder = new Builder(this.comparator);

			for (int i = 0; i < n; ++i) {
				builder.addCopies(this.elements[i], this.counts[i]);
			}

			return builder.build();
		}
	}

	public static class Builder<E> extends ImmutableMultiset.Builder<E> {
		private final Comparator<? super E> comparator;
		@VisibleForTesting
		E[] elements;
		private int[] counts;
		private int length;
		private boolean forceCopyElements;

		public Builder(Comparator<? super E> comparator) {
			super(true);
			this.comparator = (Comparator) Preconditions.checkNotNull(comparator);
			this.elements = (Object[]) (new Object[4]);
			this.counts = new int[4];
		}

		private void maintenance() {
			if (this.length == this.elements.length) {
				this.dedupAndCoalesce(true);
			} else if (this.forceCopyElements) {
				this.elements = Arrays.copyOf(this.elements, this.elements.length);
			}

			this.forceCopyElements = false;
		}

		private void dedupAndCoalesce(boolean maybeExpand) {
			if (this.length != 0) {
				E[] sortedElements = Arrays.copyOf(this.elements, this.length);
				Arrays.sort(sortedElements, this.comparator);
				int uniques = 1;

				for (int i = 1; i < sortedElements.length; ++i) {
					if (this.comparator.compare(sortedElements[uniques - 1], sortedElements[i]) < 0) {
						sortedElements[uniques] = sortedElements[i];
						++uniques;
					}
				}

				Arrays.fill(sortedElements, uniques, this.length, (Object) null);
				if (maybeExpand && uniques * 4 > this.length * 3) {
					sortedElements = Arrays.copyOf(sortedElements,
							IntMath.saturatedAdd(this.length, this.length / 2 + 1));
				}

				int[] sortedCounts = new int[sortedElements.length];

				for (int i = 0; i < this.length; ++i) {
					int index = Arrays.binarySearch(sortedElements, 0, uniques, this.elements[i], this.comparator);
					if (this.counts[i] >= 0) {
						sortedCounts[index] += this.counts[i];
					} else {
						sortedCounts[index] = ~this.counts[i];
					}
				}

				this.elements = sortedElements;
				this.counts = sortedCounts;
				this.length = uniques;
			}
		}

		@CanIgnoreReturnValue
		public Builder<E> add(E element) {
			return this.addCopies(element, 1);
		}

		@CanIgnoreReturnValue
		public Builder<E> add(E... elements) {
			Object[] var2 = elements;
			int var3 = elements.length;

			for (int var4 = 0; var4 < var3; ++var4) {
				E element = var2[var4];
				this.add(element);
			}

			return this;
		}

		@CanIgnoreReturnValue
		public Builder<E> addCopies(E element, int occurrences) {
			Preconditions.checkNotNull(element);
			CollectPreconditions.checkNonnegative(occurrences, "occurrences");
			if (occurrences == 0) {
				return this;
			} else {
				this.maintenance();
				this.elements[this.length] = element;
				this.counts[this.length] = occurrences;
				++this.length;
				return this;
			}
		}

		@CanIgnoreReturnValue
		public Builder<E> setCount(E element, int count) {
			Preconditions.checkNotNull(element);
			CollectPreconditions.checkNonnegative(count, "count");
			this.maintenance();
			this.elements[this.length] = element;
			this.counts[this.length] = ~count;
			++this.length;
			return this;
		}

		@CanIgnoreReturnValue
		public Builder<E> addAll(Iterable<? extends E> elements) {
			Iterator var2;
			if (elements instanceof Multiset) {
				var2 = ((Multiset) elements).entrySet().iterator();

				while (var2.hasNext()) {
					Multiset.Entry<? extends E> entry = (Multiset.Entry) var2.next();
					this.addCopies(entry.getElement(), entry.getCount());
				}
			} else {
				var2 = elements.iterator();

				while (var2.hasNext()) {
					E e = var2.next();
					this.add(e);
				}
			}

			return this;
		}

		@CanIgnoreReturnValue
		public Builder<E> addAll(Iterator<? extends E> elements) {
			while (elements.hasNext()) {
				this.add(elements.next());
			}

			return this;
		}

		private void dedupAndCoalesceAndDeleteEmpty() {
			this.dedupAndCoalesce(false);
			int size = 0;

			for (int i = 0; i < this.length; ++i) {
				if (this.counts[i] > 0) {
					this.elements[size] = this.elements[i];
					this.counts[size] = this.counts[i];
					++size;
				}
			}

			Arrays.fill(this.elements, size, this.length, (Object) null);
			Arrays.fill(this.counts, size, this.length, 0);
			this.length = size;
		}

		public ImmutableSortedMultiset<E> build() {
			this.dedupAndCoalesceAndDeleteEmpty();
			if (this.length == 0) {
				return ImmutableSortedMultiset.emptyMultiset(this.comparator);
			} else {
				RegularImmutableSortedSet<E> elementSet = (RegularImmutableSortedSet) ImmutableSortedSet
						.construct(this.comparator, this.length, this.elements);
				long[] cumulativeCounts = new long[this.length + 1];

				for (int i = 0; i < this.length; ++i) {
					cumulativeCounts[i + 1] = cumulativeCounts[i] + (long) this.counts[i];
				}

				this.forceCopyElements = true;
				return new RegularImmutableSortedMultiset(elementSet, cumulativeCounts, 0, this.length);
			}
		}
	}
}