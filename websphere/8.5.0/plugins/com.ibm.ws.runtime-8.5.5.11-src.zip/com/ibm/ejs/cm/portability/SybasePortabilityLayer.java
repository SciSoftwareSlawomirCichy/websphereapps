package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.CMProperties;
import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import javax.sql.PooledConnection;
import javax.sql.XAConnection;

class SybasePortabilityLayer extends PortabilityLayerImpl {
	private static SybasePortabilityLayer instance = null;
	private static final TraceComponent tc = Tr.register(SybasePortabilityLayer.class);
	private static String dataBaseVersion = "0";
	private static final String[] SPECIAL_KEYS = new String[]{"connectionProperties"};

	protected SybasePortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.errorMap.put(new Integer(2601), DuplicateKeyException.class);
		this.errorMap.put(new Integer(2714), TableAlreadyExistsException.class);
		this.errorMap.put("JZ006", "MaybeStale");
		this.errorMap.put("JZ0C1", StaleConnectionException.class);
		this.errorMap.put("JZ0C0", StaleConnectionException.class);
		this.errorMap.put(new Integer(1923), PrimarykeyAlreadyDefinedException.class);
		this.errorMap.put(new Integer(3701), TableDoesNotExistException.class);
		this.errorMap.put(new Integer(208), TableDoesNotExistException.class);
		this.typeMap.setElementAt(" VARCHAR(64) NULL ", 2);
		this.typeMap.setElementAt(" VARCHAR(255) NOT NULL ", 3);
		this.typeMap.setElementAt(" VARCHAR(255) NULL ", 4);
		this.typeMap.setElementAt(" TEXT NOT NULL ", 5);
		this.typeMap.setElementAt(" TEXT NULL ", 6);
		this.typeMap.setElementAt(" TEXT NOT NULL ", 7);
		this.typeMap.setElementAt(" TEXT NULL ", 8);
		this.typeMap.setElementAt(" IMAGE NULL ", 9);
		this.typeMap.setElementAt(" IMAGE NULL ", 10);
		this.typeMap.setElementAt(" VARCHAR(64) NOT NULL ", 11);
		this.typeMap.setElementAt(" VARCHAR(64) NULL ", 12);
		this.defaultDataSourceProps.setProperty("connectionProperties", "SELECT_OPENS_CURSOR=true");
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void createTable(Connection connection, String schema, String sql) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTable", new Object[]{connection, schema, sql});
		}

		String mungedSql = replaceString(sql, "BLOB(1M)", "IMAGE NULL");
		super.createTable(connection, schema, mungedSql);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTable");
		}

	}

	public static PortabilityLayer getInstance(DataSourceProperties dsProps) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance", dsProps);
		}

		if (instance != null) {
			return instance;
		} else {
			PortabilityLayer pl = null;
			Connection conn = null;
			PooledConnection pconn = null;
			XAConnection xaconn = null;

			try {
				String user = dsProps.getProperty("user");
				if ((dsProps.getDataSourceType() & 2) != 0) {
					if (user == null) {
						pconn = dsProps.getConnectionPoolDataSource().getPooledConnection(
								dsProps.getProperty("tmpUser"), dsProps.getProperty("tmpPassword"));
					} else {
						pconn = dsProps.getConnectionPoolDataSource().getPooledConnection(user,
								dsProps.getProperty("password"));
					}

					conn = pconn.getConnection();
					pl = getPortabilityLayer(conn);
				} else if ((dsProps.getDataSourceType() & 4) != 0) {
					if (user == null) {
						xaconn = dsProps.getXADataSource().getXAConnection(dsProps.getProperty("tmpUser"),
								dsProps.getProperty("tmpPassword"));
					} else {
						xaconn = dsProps.getXADataSource().getXAConnection(user, dsProps.getProperty("password"));
					}

					conn = xaconn.getConnection();
					pl = getPortabilityLayer(conn);
				} else if ((dsProps.getDataSourceType() & 1) != 0) {
					if (user == null) {
						conn = dsProps.getDataSource().getConnection(dsProps.getProperty("tmpUser"),
								dsProps.getProperty("tmpPassword"));
					} else {
						conn = dsProps.getDataSource().getConnection(user, dsProps.getProperty("password"));
					}

					pl = getPortabilityLayer(conn);
				}
			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException var17) {
						;
					}
				}

				if (pconn != null) {
					try {
						pconn.close();
					} catch (SQLException var16) {
						;
					}
				}

				if (xaconn != null) {
					try {
						xaconn.close();
					} catch (SQLException var15) {
						;
					}
				}

				if (pl == null) {
					pl = GenericPortabilityLayer.getInstance(dsProps);
				}

			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getInstance", pl);
			}

			return pl;
		}
	}

	static PortabilityLayer getPortabilityLayer(Connection conn) throws SQLException {
		String productVersion = null;
		DatabaseMetaData metaData = null;

		try {
			metaData = conn.getMetaData();
		} catch (SQLException var4) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "getPortabilityLayer - exception getting metaData, using property", var4);
			}
		}

		if (metaData != null) {
			productVersion = metaData.getDatabaseProductVersion();
		} else {
			productVersion = dataBaseVersion;
		}

		if (productVersion != null && productVersion.indexOf("11.") != -1) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "getPortabilityLayer - returning Sybase11PortabilityLayer", productVersion);
			}

			return Sybase11PortabilityLayer.getInstance();
		} else {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "getPortabilityLayer - returning SybasePortabilityLayer", productVersion);
			}

			return getInstance();
		}
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new SybasePortabilityLayer();
		}

		return instance;
	}

	public void configureConnection(Connection conn, CMProperties props) throws SQLException {
		dataBaseVersion = props.getDataBaseVersion();
	}

	protected boolean keyIsSpecial(String key) {
		for (int i = 0; i < SPECIAL_KEYS.length; ++i) {
			if (key.equals(SPECIAL_KEYS[i])) {
				return true;
			}
		}

		return false;
	}

	protected void handleSpecialKey(DataSourceProperties dsProps, Properties defaultProps, String key) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "handleSpecialKey", key);
		}

		if (key.equals(SPECIAL_KEYS[0])) {
			String dsPropsValue = dsProps.getProperty(key);
			String defaultPropsValue = defaultProps.getProperty(key);
			StringTokenizer dsPropsTokens = null;
			StringTokenizer defaultPropsTokens = null;
			if (dsPropsValue != null) {
				dsPropsTokens = new StringTokenizer(dsPropsValue, ";");
			}

			if (defaultPropsValue != null) {
				defaultPropsTokens = new StringTokenizer(defaultPropsValue, ";");
			}

			if (dsPropsValue == null && defaultPropsValue == null) {
				return;
			}

			if (defaultPropsValue == null) {
				return;
			}

			if (dsPropsValue == null) {
				dsProps.setProperty(key, defaultPropsValue);
			}

			if (dsPropsValue != null && defaultPropsValue != null) {
				Properties mergedProps = new Properties();
				String mergedString = null;

				int var10;
				String thisDSPToken;
				int eqIndex;
				for (var10 = 0; defaultPropsTokens.hasMoreTokens(); ++var10) {
					thisDSPToken = defaultPropsTokens.nextToken();

					try {
						eqIndex = thisDSPToken.indexOf("=");
						if (eqIndex == -1) {
							mergedProps.setProperty(thisDSPToken, "");
						} else {
							mergedProps.setProperty(thisDSPToken.substring(0, eqIndex),
									thisDSPToken.substring(eqIndex + 1));
						}
					} catch (NullPointerException var15) {
						;
					}
				}

				for (var10 = 0; dsPropsTokens.hasMoreTokens(); ++var10) {
					thisDSPToken = dsPropsTokens.nextToken();

					try {
						eqIndex = thisDSPToken.indexOf("=");
						if (eqIndex == -1) {
							mergedProps.setProperty(thisDSPToken, "");
						} else {
							mergedProps.setProperty(thisDSPToken.substring(0, eqIndex),
									thisDSPToken.substring(eqIndex + 1));
						}
					} catch (NullPointerException var14) {
						;
					}
				}

				Enumeration mergedKeys = mergedProps.propertyNames();
				String value;
				if (mergedKeys.hasMoreElements()) {
					thisDSPToken = (String) mergedKeys.nextElement();
					value = mergedProps.getProperty(thisDSPToken);
					mergedString = thisDSPToken + "=" + value;
				}

				while (mergedKeys.hasMoreElements()) {
					thisDSPToken = (String) mergedKeys.nextElement();
					value = mergedProps.getProperty(thisDSPToken);
					mergedString = mergedString + ";" + thisDSPToken + "=" + value;
				}

				dsProps.setProperty(key, mergedString);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "handleSpecialKey", dsProps);
		}

	}
}