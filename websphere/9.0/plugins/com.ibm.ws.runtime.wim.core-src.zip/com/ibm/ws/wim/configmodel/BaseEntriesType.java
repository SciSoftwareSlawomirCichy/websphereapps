package com.ibm.ws.wim.configmodel;

public interface BaseEntriesType {
	String getName();

	void setName(String var1);

	String getNameInRepository();

	void setNameInRepository(String var1);
}