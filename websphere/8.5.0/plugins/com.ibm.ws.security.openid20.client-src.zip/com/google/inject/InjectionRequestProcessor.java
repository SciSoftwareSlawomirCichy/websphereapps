package com.google.inject;

import com.google.inject.InjectionRequestProcessor.StaticInjection;
import com.google.inject.internal.Errors;
import com.google.inject.internal.Lists;
import com.google.inject.spi.InjectionRequest;
import com.google.inject.spi.StaticInjectionRequest;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

class InjectionRequestProcessor extends AbstractProcessor {
	private final List<StaticInjection> staticInjections = Lists.newArrayList();
	private final Initializer initializer;

	InjectionRequestProcessor(Errors errors, Initializer initializer) {
		super(errors);
		this.initializer = initializer;
	}

	public Boolean visit(StaticInjectionRequest request) {
		this.staticInjections.add(new StaticInjection(this, this.injector, request));
		return true;
	}

	public Boolean visit(InjectionRequest request) {
		Set injectionPoints;
		try {
			injectionPoints = request.getInjectionPoints();
		} catch (ConfigurationException var4) {
			this.errors.merge(var4.getErrorMessages());
			injectionPoints = (Set) var4.getPartialValue();
		}

		this.initializer.requestInjection(this.injector, request.getInstance(), request.getSource(), injectionPoints);
		return true;
	}

	public void validate() {
		Iterator i$ = this.staticInjections.iterator();

		while (i$.hasNext()) {
			StaticInjection staticInjection = (StaticInjection) i$.next();
			staticInjection.validate();
		}

	}

	public void injectMembers() {
		Iterator i$ = this.staticInjections.iterator();

		while (i$.hasNext()) {
			StaticInjection staticInjection = (StaticInjection) i$.next();
			staticInjection.injectMembers();
		}

	}
}