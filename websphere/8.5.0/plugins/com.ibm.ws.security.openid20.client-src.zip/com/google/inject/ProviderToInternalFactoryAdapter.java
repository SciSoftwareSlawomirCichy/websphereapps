package com.google.inject;

import com.google.inject.ProviderToInternalFactoryAdapter.1;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.InternalFactory;

class ProviderToInternalFactoryAdapter<T> implements Provider<T> {
	private final InjectorImpl injector;
	private final InternalFactory<? extends T> internalFactory;

	public ProviderToInternalFactoryAdapter(InjectorImpl injector, InternalFactory<? extends T> internalFactory) {
		this.injector = injector;
		this.internalFactory = internalFactory;
	}

	public T get() {
      Errors errors = new Errors();

      try {
         T t = this.injector.callInContext(new 1(this, errors));
         errors.throwIfNewErrors(0);
         return t;
      } catch (ErrorsException var3) {
         throw new ProvisionException(errors.merge(var3.getErrors()).getMessages());
      }
   }

	public String toString() {
		return this.internalFactory.toString();
	}
}