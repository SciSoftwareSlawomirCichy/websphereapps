package com.ibm.ws.jaxrs.wink.client;

import com.ibm.ws.ssl.config.SSLConfigManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RestClientSSLConfigManager {
	private static final Logger logger = LoggerFactory.getLogger(RestClientSSLConfigManager.class);

	public void initializeSSL() throws Throwable {
		try {
			SSLConfigManager.getInstance().initializeClientSSL();
			if (logger.isDebugEnabled()) {
				logger.debug("RestClientSSLConfigManager.initializeSSL() completed successfully");
			}

		} catch (Throwable var2) {
			if (logger.isDebugEnabled()) {
				logger.debug("RestClientSSLConfigManager.initializeSSL() could not intitializeClientSSL due to: ",
						var2);
			}

			throw var2;
		}
	}
}