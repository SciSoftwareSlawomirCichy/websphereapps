package com.google.inject;

import com.google.inject.BindingProcessor.CreationListener;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.InternalContext;
import com.google.inject.internal.InternalFactory;
import com.google.inject.internal.ToStringBuilder;
import com.google.inject.spi.Dependency;

class FactoryProxy<T> implements InternalFactory<T>, CreationListener {
	private final InjectorImpl injector;
	private final Key<T> key;
	private final Key<? extends T> targetKey;
	private final Object source;
	private InternalFactory<? extends T> targetFactory;

	FactoryProxy(InjectorImpl injector, Key<T> key, Key<? extends T> targetKey, Object source) {
		this.injector = injector;
		this.key = key;
		this.targetKey = targetKey;
		this.source = source;
	}

	public void notify(Errors errors) {
		try {
			this.targetFactory = this.injector.getInternalFactory(this.targetKey, errors.withSource(this.source));
		} catch (ErrorsException var3) {
			errors.merge(var3.getErrors());
		}

	}

	public T get(Errors errors, InternalContext context, Dependency<?> dependency) throws ErrorsException {
		return this.targetFactory.get(errors.withSource(this.targetKey), context, dependency);
	}

	public String toString() {
		return (new ToStringBuilder(FactoryProxy.class)).add("key", this.key).add("provider", this.targetFactory)
				.toString();
	}
}