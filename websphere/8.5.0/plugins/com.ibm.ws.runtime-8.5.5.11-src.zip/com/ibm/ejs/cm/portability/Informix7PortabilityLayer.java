package com.ibm.ejs.cm.portability;

import java.sql.SQLException;

class Informix7PortabilityLayer extends InformixPortabilityLayer {
	private static InformixPortabilityLayer instance;

	protected Informix7PortabilityLayer() {
		this.namedColumnSpec_cosnaming_name = "VARCHAR(184) not null";
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new Informix7PortabilityLayer();
		}

		return instance;
	}
}