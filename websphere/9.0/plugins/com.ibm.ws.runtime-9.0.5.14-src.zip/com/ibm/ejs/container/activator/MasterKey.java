package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.ContainerTx;

class MasterKey extends TransactionKey {
	MasterKey(BeanId id) {
		super((ContainerTx) null, id);
	}

	public String toString() {
		return "MasterKey(" + this.id + ")";
	}
}