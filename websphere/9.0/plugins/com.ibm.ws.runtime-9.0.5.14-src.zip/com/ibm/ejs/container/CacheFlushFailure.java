package com.ibm.ejs.container;

public class CacheFlushFailure extends ContainerException {
	private static final long serialVersionUID = -2647042063557834894L;

	public CacheFlushFailure(Throwable ex) {
		super(ex);
	}
}