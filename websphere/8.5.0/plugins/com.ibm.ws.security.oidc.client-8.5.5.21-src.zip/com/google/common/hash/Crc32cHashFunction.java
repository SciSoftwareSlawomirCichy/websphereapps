package com.google.common.hash;

import com.google.common.hash.Crc32cHashFunction.Crc32cHasher;
import com.google.errorprone.annotations.Immutable;

@Immutable
final class Crc32cHashFunction extends AbstractHashFunction {
	static final HashFunction CRC_32_C = new Crc32cHashFunction();

	public int bits() {
		return 32;
	}

	public Hasher newHasher() {
		return new Crc32cHasher();
	}

	public String toString() {
		return "Hashing.crc32c()";
	}
}