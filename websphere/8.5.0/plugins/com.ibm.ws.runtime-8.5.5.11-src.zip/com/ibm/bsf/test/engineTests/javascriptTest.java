package com.ibm.bsf.test.engineTests;

import com.ibm.bsf.BSFEngine;
import com.ibm.bsf.BSFException;
import com.ibm.bsf.test.BSFEngineTestTmpl;

public class javascriptTest extends BSFEngineTestTmpl {
	private BSFEngine javascriptEngine;

	public javascriptTest(String var1) {
		super(var1);
	}

	public void setUp() {
		super.setUp();

		try {
			this.javascriptEngine = this.bsfManager.loadScriptingEngine("javascript");
		} catch (Exception var2) {
			fail(this.failMessage("Failure attempting to load Rhino", var2));
		}

	}

	public void testExec() {
		try {
			this.javascriptEngine.exec("Test.js", 0, 0, "java.lang.System.out.print (\"PASSED\");");
		} catch (Exception var2) {
			fail(this.failMessage("exec() test failed", var2));
		}

		assertEquals("PASSED", this.getTmpOutStr());
	}

	public void testEval() {
		Double var1 = null;

		try {
			var1 = new Double(this.javascriptEngine.eval("Test.js", 0, 0, "1 + 1;").toString());
		} catch (Exception var3) {
			fail(this.failMessage("eval() test failed", var3));
		}

		assertEquals(new Double(2.0D), var1);
	}

	public void testCall() {
		Object[] var1 = new Object[]{new Double(1.0D)};
		Double var2 = null;

		try {
			this.javascriptEngine.exec("Test.js", 0, 0, "function addOne (f) {\n return f + 1;\n}");
			var2 = new Double(this.javascriptEngine.call((Object) null, "addOne", var1).toString());
		} catch (Exception var4) {
			fail(this.failMessage("call() test failed", var4));
		}

		assertEquals(new Double(2.0D), var2);
	}

	public void testIexec() {
		try {
			this.javascriptEngine.iexec("Test.js", 0, 0, "java.lang.System.out.print (\"PASSED\");");
		} catch (Exception var2) {
			fail(this.failMessage("iexec() test failed", var2));
		}

		assertEquals("PASSED", this.getTmpOutStr());
	}

	public void testBSFManagerEval() {
		Double var1 = null;

		try {
			var1 = new Double(this.bsfManager.eval("javascript", "Test.js", 0, 0, "1 + 1;").toString());
		} catch (Exception var3) {
			fail(this.failMessage("BSFManager eval() test failed", var3));
		}

		assertEquals(new Double(2.0D), var1);
	}

	public void testBSFManagerAvailability() {
		Object var1 = null;

		try {
			var1 = this.javascriptEngine.eval("Test.js", 0, 0, "bsf.lookupBean(\"foo\");");
		} catch (Exception var3) {
			fail(this.failMessage("Test of BSFManager availability failed", var3));
		}

		assertNull(var1);
	}

	public void testRegisterBean() {
		Double var1 = new Double(1.0D);
		Double var2 = null;

		try {
			this.bsfManager.registerBean("foo", var1);
			var2 = (Double) this.javascriptEngine.eval("Test.js", 0, 0, "bsf.lookupBean(\"foo\");");
		} catch (Exception var4) {
			fail(this.failMessage("registerBean() test failed", var4));
		}

		assertEquals(var1, var2);
	}

	public void testUnregisterBean() {
		Double var1 = new Double(1.0D);
		Double var2 = null;

		try {
			this.bsfManager.registerBean("foo", var1);
			this.bsfManager.unregisterBean("foo");
			var2 = (Double) this.javascriptEngine.eval("Test.js", 0, 0, "bsf.lookupBean(\"foo\");");
		} catch (Exception var4) {
			fail(this.failMessage("unregisterBean() test failed", var4));
		}

		assertNull(var2);
	}

	public void testDeclareBean() {
		Double var1 = new Double(1.0D);
		Double var2 = null;

		try {
			this.bsfManager.declareBean("foo", var1,
					class$java$lang$Double == null
							? (class$java$lang$Double = class$("java.lang.Double"))
							: class$java$lang$Double);
			var2 = (Double) this.javascriptEngine.eval("Test.js", 0, 0, "foo + 1;");
		} catch (Exception var4) {
			fail(this.failMessage("declareBean() test failed", var4));
		}

		assertEquals(new Double(2.0D), var2);
	}

	public void testUndeclareBean() {
		Double var1 = new Double(1.0D);
		Double var2 = null;

		try {
			this.bsfManager.declareBean("foo", var1,
					class$java$lang$Double == null
							? (class$java$lang$Double = class$("java.lang.Double"))
							: class$java$lang$Double);
			this.bsfManager.undeclareBean("foo");
			var2 = (Double) this.javascriptEngine.eval("Test.js", 0, 0, "foo + 1");
		} catch (BSFException var4) {
			;
		} catch (Exception var5) {
			fail(this.failMessage("undeclareBean() test failed", var5));
		}

		assertNull(var2);
	}
}