package com.google.inject;

import com.google.inject.internal.BindingImpl;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ImmutableList;
import com.google.inject.internal.Lists;
import com.google.inject.internal.Maps;
import com.google.inject.internal.MatcherAndConverter;
import com.google.inject.internal.Preconditions;
import com.google.inject.internal.ImmutableList.Builder;
import com.google.inject.spi.TypeListenerBinding;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

class InheritingState implements State {
	private final State parent;
	private final Map<Key<?>, Binding<?>> explicitBindingsMutable = Maps.newLinkedHashMap();
	private final Map<Key<?>, Binding<?>> explicitBindings;
	private final Map<Class<? extends Annotation>, Scope> scopes;
	private final List<MatcherAndConverter> converters;
	private final List<MethodAspect> methodAspects;
	private final List<TypeListenerBinding> listenerBindings;
	private final WeakKeySet blacklistedKeys;
	private final Object lock;

	InheritingState(State parent) {
		this.explicitBindings = Collections.unmodifiableMap(this.explicitBindingsMutable);
		this.scopes = Maps.newHashMap();
		this.converters = Lists.newArrayList();
		this.methodAspects = Lists.newArrayList();
		this.listenerBindings = Lists.newArrayList();
		this.blacklistedKeys = new WeakKeySet();
		this.parent = (State) Preconditions.checkNotNull(parent, "parent");
		this.lock = parent == State.NONE ? this : parent.lock();
	}

	public State parent() {
		return this.parent;
	}

	public <T> BindingImpl<T> getExplicitBinding(Key<T> key) {
		Binding<?> binding = (Binding) this.explicitBindings.get(key);
		return binding != null ? (BindingImpl) binding : this.parent.getExplicitBinding(key);
	}

	public Map<Key<?>, Binding<?>> getExplicitBindingsThisLevel() {
		return this.explicitBindings;
	}

	public void putBinding(Key<?> key, BindingImpl<?> binding) {
		this.explicitBindingsMutable.put(key, binding);
	}

	public Scope getScope(Class<? extends Annotation> annotationType) {
		Scope scope = (Scope) this.scopes.get(annotationType);
		return scope != null ? scope : this.parent.getScope(annotationType);
	}

	public void putAnnotation(Class<? extends Annotation> annotationType, Scope scope) {
		this.scopes.put(annotationType, scope);
	}

	public Iterable<MatcherAndConverter> getConvertersThisLevel() {
		return this.converters;
	}

	public void addConverter(MatcherAndConverter matcherAndConverter) {
		this.converters.add(matcherAndConverter);
	}

	public MatcherAndConverter getConverter(String stringValue, TypeLiteral<?> type, Errors errors, Object source) {
		MatcherAndConverter matchingConverter = null;

		for (Object s = this; s != State.NONE; s = ((State) s).parent()) {
			Iterator i$ = ((State) s).getConvertersThisLevel().iterator();

			while (i$.hasNext()) {
				MatcherAndConverter converter = (MatcherAndConverter) i$.next();
				if (converter.getTypeMatcher().matches(type)) {
					if (matchingConverter != null) {
						errors.ambiguousTypeConversion(stringValue, source, type, matchingConverter, converter);
					}

					matchingConverter = converter;
				}
			}
		}

		return matchingConverter;
	}

	public void addMethodAspect(MethodAspect methodAspect) {
		this.methodAspects.add(methodAspect);
	}

	public ImmutableList<MethodAspect> getMethodAspects() {
		return (new Builder()).addAll(this.parent.getMethodAspects()).addAll(this.methodAspects).build();
	}

	public void addTypeListener(TypeListenerBinding listenerBinding) {
		this.listenerBindings.add(listenerBinding);
	}

	public List<TypeListenerBinding> getTypeListenerBindings() {
		List<TypeListenerBinding> parentBindings = this.parent.getTypeListenerBindings();
		List<TypeListenerBinding> result = new ArrayList(parentBindings.size() + 1);
		result.addAll(parentBindings);
		result.addAll(this.listenerBindings);
		return result;
	}

	public void blacklist(Key<?> key) {
		this.parent.blacklist(key);
		this.blacklistedKeys.add(key);
	}

	public boolean isBlacklisted(Key<?> key) {
		return this.blacklistedKeys.contains(key);
	}

	public Object lock() {
		return this.lock;
	}
}