package com.ibm.json.xml.internal;

import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JSONObject {
	private static String className = "com.ibm.json.xml.internal.JSONObject";
	private static Logger logger;
	private static final String indent = "   ";
	private String objectName = null;
	private Properties attrs = null;
	private Hashtable jsonObjects = null;
	private String tagText = null;

	public JSONObject(String var1, Properties var2) {
		this.objectName = var1;
		this.attrs = var2;
		this.jsonObjects = new Hashtable();
	}

	public void addJSONObject(JSONObject var1) {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "addJSONObject(JSONObject)");
		}

		Vector var2 = (Vector) this.jsonObjects.get(var1.objectName);
		if (var2 != null) {
			var2.add(var1);
		} else {
			var2 = new Vector();
			var2.add(var1);
			this.jsonObjects.put(var1.objectName, var2);
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "addJSONObject(JSONObject)");
		}

	}

	public void setTagText(String var1) {
		this.tagText = var1;
	}

	public String getTagText() {
		return this.tagText;
	}

	public void writeObject(Writer var1, int var2, boolean var3) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeObject(Writer, int, boolean)");
		}

		this.writeObject(var1, var2, var3, false);
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeObject(Writer, int, boolean)");
		}

	}

	public void writeObject(Writer var1, int var2, boolean var3, boolean var4) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeObject(Writer, int, boolean, boolean)");
		}

		if (var1 != null) {
			try {
				if (this.isEmptyObject()) {
					this.writeEmptyObject(var1, var2, var3, var4);
				} else if (this.isTextOnlyObject()) {
					this.writeTextOnlyObject(var1, var2, var3, var4);
				} else {
					this.writeComplexObject(var1, var2, var3, var4);
				}
			} catch (Exception var7) {
				IOException var6 = new IOException("Error occurred on serialization of JSON text.");
				var6.initCause(var7);
				throw var6;
			}

			if (logger.isLoggable(Level.FINER)) {
				logger.entering(className, "writeObject(Writer, int, boolean, boolean)");
			}

		} else {
			throw new IOException("The writer cannot be null.");
		}
	}

	private void writeAttribute(Writer var1, String var2, String var3, int var4, boolean var5) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeAttribute(Writer, String, String, int)");
		}

		if (!var5) {
			this.writeIndention(var1, var4);
		}

		try {
			if (!var5) {
				var1.write("\"" + var2 + "\"" + " : " + "\"" + this.escapeStringSpecialCharacters(var3) + "\"");
			} else {
				var1.write("\"" + var2 + "\"" + ":" + "\"" + this.escapeStringSpecialCharacters(var3) + "\"");
			}
		} catch (Exception var8) {
			IOException var7 = new IOException("Error occurred on serialization of JSON text.");
			var7.initCause(var8);
			throw var7;
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "writeAttribute(Writer, String, String, int)");
		}

	}

	private void writeIndention(Writer var1, int var2) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeIndention(Writer, int)");
		}

		try {
			for (int var3 = 0; var3 < var2; ++var3) {
				var1.write("   ");
			}
		} catch (Exception var5) {
			IOException var4 = new IOException("Error occurred on serialization of JSON text.");
			var4.initCause(var5);
			throw var4;
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "writeIndention(Writer, int)");
		}

	}

	private void writeAttributes(Writer var1, Properties var2, int var3, boolean var4) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeAttributes(Writer, Properties, int, boolean)");
		}

		if (var2 != null) {
			Enumeration var5 = var2.propertyNames();
			if (var5 != null && var5.hasMoreElements()) {
				while (var5.hasMoreElements()) {
					String var6 = (String) var5.nextElement();
					this.writeAttribute(var1, this.escapeAttributeNameSpecialCharacters(var6), (String) var2.get(var6),
							var3 + 1, var4);
					if (var5.hasMoreElements()) {
						try {
							if (!var4) {
								var1.write(",\n");
							} else {
								var1.write(",");
							}
						} catch (Exception var9) {
							IOException var8 = new IOException("Error occurred on serialization of JSON text.");
							var8.initCause(var9);
							throw var8;
						}
					}
				}
			}
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "writeAttributes(Writer, Properties, int, boolean)");
		}

	}

	private String escapeAttributeNameSpecialCharacters(String var1) {
		if (var1 != null) {
			StringBuffer var2 = new StringBuffer("");

			for (int var3 = 0; var3 < var1.length(); ++var3) {
				char var4 = var1.charAt(var3);
				switch (var4) {
					case ':' :
						var2.append("_ns-sep_");
						break;
					default :
						var2.append(var4);
				}
			}

			var1 = var2.toString();
		}

		return var1;
	}

	private String escapeStringSpecialCharacters(String var1) {
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "escapeStringSpecialCharacters(String)");
		}

		if (var1 != null) {
			StringBuffer var2 = new StringBuffer("");

			for (int var3 = 0; var3 < var1.length(); ++var3) {
				char var4 = var1.charAt(var3);
				StringBuffer var5;
				switch (var4) {
					case '\b' :
						var2.append("\\b");
						continue;
					case '\t' :
						var2.append("\\t");
						continue;
					case '\f' :
						var2.append("\\f");
						continue;
					case '\r' :
						var2.append("\\r");
						continue;
					case '"' :
						var2.append("\\\"");
						continue;
					case '/' :
						var2.append("\\/");
						continue;
					case '\\' :
						var2.append("\\\\");
						continue;
					default :
						if (var4 >= ' ' && var4 <= '~') {
							var2.append(var4);
							continue;
						}

						var2.append("\\u");
						var5 = new StringBuffer(Integer.toHexString(var4));
				}

				while (var5.length() < 4) {
					var5.insert(0, '0');
				}

				var2.append(var5.toString());
			}

			var1 = var2.toString();
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "escapeStringSpecialCharacters(String)");
		}

		return var1;
	}

	private void writeChildren(Writer var1, int var2, boolean var3) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeChildren(Writer, int, boolean)");
		}

		if (!this.jsonObjects.isEmpty()) {
			Enumeration var4 = this.jsonObjects.keys();

			label106 : while (true) {
				while (true) {
					String var5;
					Vector var6;
					do {
						do {
							if (!var4.hasMoreElements()) {
								break label106;
							}

							var5 = (String) var4.nextElement();
							var6 = (Vector) this.jsonObjects.get(var5);
						} while (var6 == null);
					} while (var6.isEmpty());

					if (var6.size() == 1) {
						if (logger.isLoggable(Level.FINEST)) {
							logger.logp(Level.FINEST, className, "writeChildren(Writer, int, boolean)",
									"Writing child object: [" + var5 + "]");
						}

						JSONObject var12 = (JSONObject) var6.elementAt(0);
						var12.writeObject(var1, var2 + 1, false, var3);
						if (var4.hasMoreElements()) {
							try {
								if (!var3) {
									if (!var12.isTextOnlyObject() && !var12.isEmptyObject()) {
										this.writeIndention(var1, var2 + 1);
									}

									var1.write(",\n");
								} else {
									var1.write(",");
								}
							} catch (Exception var10) {
								IOException var9 = new IOException("Error occurred on serialization of JSON text.");
								var9.initCause(var10);
								throw var9;
							}
						} else if (var12.isTextOnlyObject() && !var3) {
							var1.write("\n");
						}
					} else {
						if (logger.isLoggable(Level.FINEST)) {
							logger.logp(Level.FINEST, className, "writeChildren(Writer, int, boolean)",
									"Writing array of JSON objects with attribute name: [" + var5 + "]");
						}

						try {
							if (!var3) {
								this.writeIndention(var1, var2 + 1);
								var1.write("\"" + var5 + "\"");
								var1.write(" : [\n");
							} else {
								var1.write("\"" + var5 + "\"");
								var1.write(":[");
							}

							for (int var7 = 0; var7 < var6.size(); ++var7) {
								JSONObject var13 = (JSONObject) var6.elementAt(var7);
								var13.writeObject(var1, var2 + 2, true, var3);
								if (var7 != var6.size() - 1) {
									if (!var3) {
										if (!var13.isTextOnlyObject() && !var13.isEmptyObject()) {
											this.writeIndention(var1, var2 + 2);
										}

										var1.write(",\n");
									} else {
										var1.write(",");
									}
								}
							}

							if (!var3) {
								var1.write("\n");
								this.writeIndention(var1, var2 + 1);
							}

							var1.write("]");
							if (var4.hasMoreElements()) {
								var1.write(",");
							}

							if (!var3) {
								var1.write("\n");
							}
						} catch (Exception var11) {
							IOException var8 = new IOException("Error occurred on serialization of JSON text.");
							var8.initCause(var11);
							throw var8;
						}
					}
				}
			}
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "writeChildren(Writer, int, boolean)");
		}

	}

	private void writeEmptyObject(Writer var1, int var2, boolean var3, boolean var4) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeEmptyObject(Writer, int, boolean, boolean)");
		}

		if (!var3) {
			if (!var4) {
				this.writeIndention(var1, var2);
				var1.write("\"" + this.objectName + "\"");
				var1.write(" : true");
			} else {
				var1.write("\"" + this.objectName + "\"");
				var1.write(":true");
			}
		} else if (!var4) {
			this.writeIndention(var1, var2);
			var1.write("true");
		} else {
			var1.write("true");
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "writeEmptyObject(Writer, int, boolean, boolean)");
		}

	}

	private void writeTextOnlyObject(Writer var1, int var2, boolean var3, boolean var4) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeTextOnlyObject(Writer, int, boolean, boolean)");
		}

		if (!var3) {
			this.writeAttribute(var1, this.objectName, this.tagText.trim(), var2, var4);
		} else if (!var4) {
			this.writeIndention(var1, var2);
			var1.write("\"" + this.escapeStringSpecialCharacters(this.tagText.trim()) + "\"");
		} else {
			var1.write("\"" + this.escapeStringSpecialCharacters(this.tagText.trim()) + "\"");
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "writeTextOnlyObject(Writer, int, boolean, boolean)");
		}

	}

	private void writeComplexObject(Writer var1, int var2, boolean var3, boolean var4) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "writeComplexObject(Writer, int, boolean, boolean)");
		}

		boolean var5 = false;
		if (!var3) {
			if (logger.isLoggable(Level.FINEST)) {
				logger.logp(Level.FINEST, className, "writeComplexObject(Writer, int, boolean, boolean)",
						"Writing object: [" + this.objectName + "]");
			}

			if (!var4) {
				this.writeIndention(var1, var2);
			}

			var1.write("\"" + this.objectName + "\"");
			if (!var4) {
				var1.write(" : {\n");
			} else {
				var1.write(":{");
			}
		} else {
			if (logger.isLoggable(Level.FINEST)) {
				logger.logp(Level.FINEST, className, "writeObject(Writer, int, boolean, boolean)",
						"Writing object contents as an anonymous object (usually an array entry)");
			}

			if (!var4) {
				this.writeIndention(var1, var2);
				var1.write("{\n");
			} else {
				var1.write("{");
			}
		}

		if (this.tagText != null && !this.tagText.equals("") && !this.tagText.trim().equals("")) {
			this.writeAttribute(var1, "content", this.tagText.trim(), var2 + 1, var4);
			var5 = true;
		}

		if (this.attrs != null && !this.attrs.isEmpty() && var5) {
			if (!var4) {
				var1.write(",\n");
			} else {
				var1.write(",");
			}
		}

		this.writeAttributes(var1, this.attrs, var2, var4);
		if (!this.jsonObjects.isEmpty()) {
			if (this.attrs != null && (!this.attrs.isEmpty() || var5)) {
				if (!var4) {
					var1.write(",\n");
				} else {
					var1.write(",");
				}
			} else if (!var4) {
				var1.write("\n");
			}

			this.writeChildren(var1, var2, var4);
		} else if (!var4) {
			var1.write("\n");
		}

		if (!var4) {
			this.writeIndention(var1, var2);
			var1.write("}\n");
		} else {
			var1.write("}");
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "writeComplexObject(Writer, int, boolean, boolean)");
		}

	}

	private boolean isEmptyObject() {
		boolean var1 = false;
		if ((this.attrs == null || this.attrs != null && this.attrs.isEmpty()) && this.jsonObjects.isEmpty()
				&& (this.tagText == null || this.tagText != null && this.tagText.trim().equals(""))) {
			var1 = true;
		}

		return var1;
	}

	private boolean isTextOnlyObject() {
		boolean var1 = false;
		if ((this.attrs == null || this.attrs != null && this.attrs.isEmpty()) && this.jsonObjects.isEmpty()
				&& this.tagText != null && !this.tagText.trim().equals("")) {
			var1 = true;
		}

		return var1;
	}

	static {
		logger = Logger.getLogger(className, (String) null);
	}
}