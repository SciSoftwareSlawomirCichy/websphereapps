package com.ibm.ffdc;

interface package-info {
}