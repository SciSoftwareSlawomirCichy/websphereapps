package com.ibm.ejs.cm.exception;

import com.ibm.ejs.cm.portability.PortableSQLException;

public class WorkRolledbackException extends PortableSQLException {
	private static final long serialVersionUID = 5518428435998367169L;

	public WorkRolledbackException() {
		super("Outstanding work on this connection which was not comitted or rolledback by the user has been rolledback.");
	}
}