package com.ibm.websphere.ssl;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.websphere.security.WebSphereRuntimePermission;
import com.ibm.ws.ssl.JSSEProviderFactory;
import com.ibm.ws.ssl.config.FIPSUtils;
import com.ibm.ws.ssl.config.ManagementScopeManager;
import com.ibm.ws.ssl.config.SSLConfig;
import com.ibm.ws.ssl.config.SSLConfigManager;
import com.ibm.ws.ssl.config.ThreadManager;
import com.ibm.ws.ssl.core.TraceNLSHelper;
import java.net.URLStreamHandler;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocketFactory;

public class JSSEHelper {
	private static final TraceComponent tc = Tr.register(JSSEHelper.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private static JSSEHelper thisClass = null;
	private static final WebSphereRuntimePermission GET_SSLCONFIG = new WebSphereRuntimePermission("getSSLConfig");
	private static final WebSphereRuntimePermission SET_SSLCONFIG = new WebSphereRuntimePermission("setSSLConfig");
	public static final String DIRECTION_INBOUND = "inbound";
	public static final String DIRECTION_OUTBOUND = "outbound";
	public static final String DIRECTION_UNKNOWN = "unknown";
	public static final String ENDPOINT_IIOP = "IIOP";
	public static final String ENDPOINT_HTTP = "HTTP";
	public static final String ENDPOINT_SIP = "SIP";
	public static final String ENDPOINT_JMS = "JMS";
	public static final String ENDPOINT_BUS_CLIENT = "BUS_CLIENT";
	public static final String ENDPOINT_BUS_TO_WEBSPHERE_MQ = "BUS_TO_WEBSPHERE_MQ";
	public static final String ENDPOINT_BUS_TO_BUS = "BUS_TO_BUS";
	public static final String ENDPOINT_CLIENT_TO_WEBSPHERE_MQ = "CLIENT_TO_WEBSPHERE_MQ";
	public static final String ENDPOINT_LDAP = "LDAP";
	public static final String ENDPOINT_ADMIN_SOAP = "ADMIN_SOAP";
	public static final String ENDPOINT_ADMIN_IPC = "ADMIN_IPC";
	public static final String CONNECTION_INFO_DIRECTION = "com.ibm.ssl.direction";
	public static final String CONNECTION_INFO_ENDPOINT_NAME = "com.ibm.ssl.endPointName";
	public static final String CONNECTION_INFO_REMOTE_HOST = "com.ibm.ssl.remoteHost";
	public static final String CONNECTION_INFO_REMOTE_PORT = "com.ibm.ssl.remotePort";
	public static final String CONNECTION_INFO_CERT_MAPPING_HOST = "com.ibm.ssl.certMappingHost";
	public static final String CONNECTION_INFO_IS_WEB_CONTAINER_INBOUND = "com.ibm.ssl.isWebContainerInbound";
	public static final int SECURITY_MODE_FIPS_DISABLED = 0;
	public static final int SECURITY_MODE_FIPS_140_2 = 1;
	public static final int SECURITY_MODE_SP_800_131_TRANSITION = 2;
	public static final int SECURITY_MODE_SP_800_131_STRICT = 3;
	public static final int SECURITY_MODE_SUITE_B_128 = 4;
	public static final int SECURITY_MODE_SUITE_B_192 = 5;

	public static JSSEHelper getInstance() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance");
		}

		if (thisClass == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Creating new instance of JSSEHelper.");
			}

			thisClass = new JSSEHelper();
			if (!SSLConfigManager.getInstance().isServerProcess()) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Attempting to initialize client configuration, if not already done.");
				}

				SSLConfigManager.getInstance().initializeClientSSL();
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance", thisClass);
		}

		return thisClass;
	}

	public void setSSLPropertiesOnThread(Properties props) {
		if (tc.isEntryEnabled()) {
			String debug = "Clearing thread properties.";
			if (props != null) {
				debug = props != null && props.getProperty("com.ibm.ssl.alias") != null
						? "Setting thread properties: " + props.getProperty("com.ibm.ssl.alias")
						: "Setting thread properties: " + props.toString();
			}

			Tr.entry(tc, "setSSLPropertiesOnThread", new Object[]{debug});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + SET_SSLCONFIG.toString());
			}

			sm.checkPermission(SET_SSLCONFIG);
		}

		if (props != null) {
			String alias = props.getProperty("com.ibm.ssl.alias");
			if (alias != null) {
				SSLConfig config = SSLConfigManager.getInstance().getSSLConfig(alias);
				if (config == null) {
					config = new SSLConfig(props);
					if (config != null) {
						try {
							SSLConfigManager.getInstance().addSSLConfigToMap(alias, config);
						} catch (Exception var6) {
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "The following exception occurred in setSSLPropertiesOnThread().",
										new Object[]{var6});
							}

							Manager.Ffdc.log(var6, this, "com.ibm.websphere.ssl.JSSEHelper.setSSLPropertiesOnThread",
									"303", new Object[]{this});
						}
					}
				}
			}
		}

		ThreadManager.getInstance().setPropertiesOnThread(props);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setSSLPropertiesOnThread");
		}

	}

	public Properties getSSLPropertiesOnThread() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLPropertiesOnThread");
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_SSLCONFIG.toString());
			}

			sm.checkPermission(GET_SSLCONFIG);
		}

		Properties props = ThreadManager.getInstance().getPropertiesOnThread();
		if (tc.isEntryEnabled()) {
			String debug = "Thread properties are NULL.";
			if (props != null) {
				debug = props != null && props.getProperty("com.ibm.ssl.alias") != null
						? "Found thread properties: " + props.getProperty("com.ibm.ssl.alias")
						: "Found thread properties: " + props.toString();
			}

			Tr.entry(tc, "getSSLPropertiesOnThread", new Object[]{debug});
		}

		return props;
	}

	public Properties getProperties(String sslAliasName) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProperties", new Object[]{sslAliasName});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_SSLCONFIG.toString());
			}

			sm.checkPermission(GET_SSLCONFIG);
		}

		try {
			if (sslAliasName != null && sslAliasName.length() > 0) {
				Properties directSelectionProperties = SSLConfigManager.getInstance().getProperties(sslAliasName);
				if (directSelectionProperties != null) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getProperties -> direct");
					}

					return directSelectionProperties;
				}
			}
		} catch (Exception var4) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getProperties().", new Object[]{var4});
			}

			Manager.Ffdc.log(var4, this, "com.ibm.websphere.ssl.JSSEHelper.getProperties", "408", new Object[]{this});
			if (var4 instanceof SSLException) {
				throw (SSLException) var4;
			}

			throw new SSLException(var4);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getProperties -> null");
		}

		return null;
	}

	public SSLContext getSSLContext(Map connectionInfo, Properties props) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLContext", new Object[]{connectionInfo});
		}

		if (props == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc,
						"SSL client config properties are missing. The property 'com.ibm.SSL.ConfigURL' may not be set properly.");
			}

			String message = TraceNLSHelper.getInstance().getString("ssl.no.properties.error.CWPKI0315E",
					"SSL configuration properites are null. Could be a problem parsing the SSL client configuraton.");
			throw new SSLException(message);
		} else {
			SSLConfig newConfig = new SSLConfig(props);
			String contextProvider = props.getProperty("com.ibm.ssl.contextProvider");
			if (contextProvider == null) {
				contextProvider = "IBMJSSE2";
			}

			SSLContext context = null;

			try {
				context = JSSEProviderFactory.getInstance(contextProvider).getSSLContext(connectionInfo, newConfig);
			} catch (Exception var7) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "The following exception occurred getting the SSLContext.", new Object[]{var7});
				}

				Manager.Ffdc.log(var7, this, "com.ibm.websphere.ssl.JSSEHelper.getSSLContext", "452",
						new Object[]{this});
				if (var7 instanceof SSLException) {
					throw (SSLException) var7;
				}

				throw new SSLException(var7.getMessage(), var7);
			}

			if (context == null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "The SSLContext is null.  Throwing exception.");
				}

				throw new SSLException("The SSLContext returned is null.  Validate the Properties passed in.");
			} else {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getSSLContext");
				}

				return context;
			}
		}
	}

	public URLStreamHandler getURLStreamHandler(Properties props) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getURLStreamHandler");
		}

		try {
			SSLConfig newConfig = new SSLConfig(props);
			String contextProvider = newConfig.getProperty("com.ibm.ssl.contextProvider");
			if (contextProvider == null) {
				contextProvider = "IBMJSSE2";
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getURLStreamHandler");
			}

			return JSSEProviderFactory.getInstance(contextProvider).getURLStreamHandler(newConfig);
		} catch (Exception var4) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred getting the SSLContext.", new Object[]{var4});
			}

			Manager.Ffdc.log(var4, this, "com.ibm.websphere.ssl.JSSEHelper.getSSLContext", "495", new Object[]{this});
			if (var4 instanceof SSLException) {
				throw (SSLException) var4;
			} else {
				throw new SSLException(var4.getMessage(), var4);
			}
		}
	}

	public SSLServerSocketFactory getSSLServerSocketFactory(Properties props) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLServerSocketFactory");
		}

		try {
			SSLConfig newConfig = new SSLConfig(props);
			String contextProvider = newConfig.getProperty("com.ibm.ssl.contextProvider");
			if (contextProvider == null) {
				contextProvider = "IBMJSSE2";
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getSSLServerSocketFactory");
			}

			return JSSEProviderFactory.getInstance(contextProvider).getSSLServerSocketFactory(newConfig);
		} catch (Exception var4) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getSSLServerSocketFactory().", new Object[]{var4});
			}

			Manager.Ffdc.log(var4, this, "com.ibm.websphere.ssl.JSSEHelper.getSSLServerSocketFactory", "538",
					new Object[]{this});
			if (var4 instanceof SSLException) {
				throw (SSLException) var4;
			} else {
				throw new SSLException(var4);
			}
		}
	}

	public SSLSocketFactory getSSLSocketFactory(Map connectionInfo, Properties props) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLSocketFactory");
		}

		try {
			SSLConfig newConfig = new SSLConfig(props);
			String contextProvider = newConfig.getProperty("com.ibm.ssl.contextProvider");
			if (contextProvider == null) {
				contextProvider = "IBMJSSE2";
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getSSLSocketFactory");
			}

			return JSSEProviderFactory.getInstance(contextProvider).getSSLSocketFactory(connectionInfo, newConfig);
		} catch (Exception var5) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getSSLSocketFactory().", new Object[]{var5});
			}

			Manager.Ffdc.log(var5, this, "com.ibm.websphere.ssl.JSSEHelper.getSSLSocketFactory", "579",
					new Object[]{this});
			if (var5 instanceof SSLException) {
				throw (SSLException) var5;
			} else {
				throw new SSLException(var5);
			}
		}
	}

	public SSLContext getSSLContext(String sslAliasName, Map connectionInfo, SSLConfigChangeListener listener)
			throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLContext", new Object[]{sslAliasName, connectionInfo, listener});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_SSLCONFIG.toString());
			}

			sm.checkPermission(GET_SSLCONFIG);
		}

		try {
			SSLConfig props = (SSLConfig) this.getProperties(sslAliasName, connectionInfo, listener);
			if (props != null) {
				String contextProvider = props.getProperty("com.ibm.ssl.contextProvider");
				if (contextProvider == null) {
					contextProvider = "IBMJSSE2";
				}

				SSLContext context = JSSEProviderFactory.getInstance(contextProvider).getSSLContext(connectionInfo,
						props);
				if (context != null) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getSSLContext");
					}

					return context;
				} else {
					throw new SSLException("SSLContext could not be created from specified SSL properties.");
				}
			} else {
				throw new SSLException("SSLContext could not be created due to null SSL properties.");
			}
		} catch (Exception var8) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getSSLContext().", new Object[]{var8});
			}

			Manager.Ffdc.log(var8, this, "com.ibm.websphere.ssl.JSSEHelper.getSSLContext", "704", new Object[]{this});
			if (var8 instanceof SSLException) {
				throw (SSLException) var8;
			} else {
				throw new SSLException(var8);
			}
		}
	}

	public URLStreamHandler getURLStreamHandler(String sslAliasName, Map connectionInfo,
			SSLConfigChangeListener listener) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getURLStreamHandler", new Object[]{sslAliasName, connectionInfo, listener});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_SSLCONFIG.toString());
			}

			sm.checkPermission(GET_SSLCONFIG);
		}

		URLStreamHandler urlStreamHandler = null;

		try {
			Properties sslProperties = this.getProperties(sslAliasName, connectionInfo, listener);
			String contextProvider = "IBMJSSE2";
			if (sslProperties != null) {
				contextProvider = sslProperties.getProperty("com.ibm.ssl.contextProvider");
				if (contextProvider == null) {
					contextProvider = "IBMJSSE2";
				}
			}

			urlStreamHandler = JSSEProviderFactory.getInstance(contextProvider)
					.getURLStreamHandler((SSLConfig) sslProperties);
		} catch (Exception var8) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getURLStreamHandler().", new Object[]{var8});
			}

			Manager.Ffdc.log(var8, this, "com.ibm.websphere.ssl.JSSEHelper.getURLStreamHandler", "766",
					new Object[]{this});
			if (var8 instanceof SSLException) {
				throw (SSLException) var8;
			}

			throw new SSLException(var8);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getURLStreamHandler");
		}

		return urlStreamHandler;
	}

	public SSLSocketFactory getSSLSocketFactory(String sslAliasName, Map connectionInfo,
			SSLConfigChangeListener listener) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLSocketFactory", new Object[]{sslAliasName, connectionInfo, listener});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_SSLCONFIG.toString());
			}

			sm.checkPermission(GET_SSLCONFIG);
		}

		SSLSocketFactory sslSocketFactory = null;

		try {
			SSLConfig sslProperties = (SSLConfig) this.getProperties(sslAliasName, connectionInfo, listener);
			String contextProvider = sslProperties.getProperty("com.ibm.ssl.contextProvider");
			if (contextProvider == null) {
				contextProvider = "IBMJSSE2";
			}

			sslSocketFactory = JSSEProviderFactory.getInstance(contextProvider).getSSLSocketFactory(connectionInfo,
					sslProperties);
		} catch (Exception var8) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getSSLSocketFactory().", new Object[]{var8});
			}

			Manager.Ffdc.log(var8, this, "com.ibm.websphere.ssl.JSSEHelper.getSSLSocketFactory", "825",
					new Object[]{this});
			if (var8 instanceof SSLException) {
				throw (SSLException) var8;
			}

			throw new SSLException(var8);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSSLSocketFactory");
		}

		return sslSocketFactory;
	}

	public SSLServerSocketFactory getSSLServerSocketFactory(String sslAliasName, Map connectionInfo,
			SSLConfigChangeListener listener) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLServerSocketFactory", new Object[]{sslAliasName, connectionInfo, listener});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_SSLCONFIG.toString());
			}

			sm.checkPermission(GET_SSLCONFIG);
		}

		SSLServerSocketFactory sslServerSocketFactory = null;

		try {
			SSLConfig sslProperties = (SSLConfig) this.getProperties(sslAliasName, connectionInfo, listener);
			String contextProvider = sslProperties.getProperty("com.ibm.ssl.contextProvider");
			if (contextProvider == null) {
				contextProvider = "IBMJSSE2";
			}

			sslServerSocketFactory = JSSEProviderFactory.getInstance(contextProvider)
					.getSSLServerSocketFactory(sslProperties);
		} catch (Exception var8) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getSSLServerSocketFactory().", new Object[]{var8});
			}

			Manager.Ffdc.log(var8, this, "com.ibm.websphere.ssl.JSSEHelper.getSSLServerSocketFactory", "883",
					new Object[]{this});
			if (var8 instanceof SSLException) {
				throw (SSLException) var8;
			}

			throw new SSLException(var8);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSSLServerSocketFactory");
		}

		return sslServerSocketFactory;
	}

	public Properties getProperties(String sslAliasName, Map connectionInfo, SSLConfigChangeListener listener)
			throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProperties", new Object[]{sslAliasName, connectionInfo, listener});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_SSLCONFIG.toString());
			}

			sm.checkPermission(GET_SSLCONFIG);
		}

		try {
			String direction = null;
			if (connectionInfo != null) {
				direction = (String) connectionInfo.get("com.ibm.ssl.direction");
			}

			Properties programmaticProperties = this.getSSLPropertiesOnThread();
			SSLConfig dynamicSelectionConfig;
			String configCertAliases;
			if (programmaticProperties != null && direction != null && direction.equals("outbound")) {
				dynamicSelectionConfig = new SSLConfig(programmaticProperties);
				if (listener != null) {
					configCertAliases = dynamicSelectionConfig.getProperty("com.ibm.ssl.alias");
					if (configCertAliases == null) {
						configCertAliases = sslAliasName;
					}

					this.registerEvent(listener, configCertAliases, dynamicSelectionConfig, "thread", connectionInfo);
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getProperties -> programmatic");
				}

				return dynamicSelectionConfig;
			} else {
				dynamicSelectionConfig = (SSLConfig) SSLConfigManager.getInstance()
						.getPropertiesFromDynamicSelectionInfo(connectionInfo);
				if (dynamicSelectionConfig != null) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getProperties -> dynamic");
					}

					if (listener != null) {
						configCertAliases = dynamicSelectionConfig.getProperty("com.ibm.ssl.alias");
						if (configCertAliases == null) {
							configCertAliases = sslAliasName;
						}

						this.registerEvent(listener, configCertAliases, dynamicSelectionConfig, "dynamic",
								connectionInfo);
					}

					return dynamicSelectionConfig;
				} else {
					if (sslAliasName != null && sslAliasName.length() > 0) {
						Properties directSelectionProperties = SSLConfigManager.getInstance()
								.getProperties(sslAliasName);
						if (directSelectionProperties != null) {
							directSelectionProperties = SSLConfigManager.getInstance()
									.determineIfCSIv2SettingsApply(directSelectionProperties, connectionInfo);
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "getProperties -> direct");
							}

							if (listener != null) {
								this.registerEvent(listener, sslAliasName, directSelectionProperties, "direct",
										connectionInfo);
							}

							return directSelectionProperties;
						}
					}

					if (SSLConfigManager.getInstance().isServerProcess()) {
						configCertAliases = ManagementScopeManager.getInstance()
								.getConfigAndCertAliasesFromGroups(connectionInfo);
						if (configCertAliases != null) {
							String configAlias = null;
							String certAlias = null;
							StringTokenizer t = new StringTokenizer(configCertAliases, ",");
							String[] aliases = new String[t.countTokens()];

							for (int var13 = 0; t.hasMoreTokens(); aliases[var13++] = t.nextToken()) {
								;
							}

							if (aliases != null && aliases.length == 2) {
								configAlias = aliases[0];
								certAlias = aliases[1];
							} else if (aliases != null && aliases.length == 1) {
								configAlias = aliases[0];
							}

							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "configAlias: " + configAlias + ", certAlias: " + certAlias);
							}

							if (configAlias != null) {
								Properties groupSelectionProperties = SSLConfigManager.getInstance()
										.getProperties(configAlias);
								if (groupSelectionProperties != null) {
									if (certAlias != null) {
										groupSelectionProperties = (Properties) groupSelectionProperties.clone();
									}

									if (certAlias != null && connectionInfo != null) {
										if (direction != null && direction.equals("inbound")) {
											groupSelectionProperties.setProperty("com.ibm.ssl.keyStoreServerAlias",
													certAlias);
										} else if (direction != null && direction.equals("outbound")) {
											groupSelectionProperties.setProperty("com.ibm.ssl.keyStoreClientAlias",
													certAlias);
										}
									} else if (certAlias != null) {
										groupSelectionProperties.setProperty("com.ibm.ssl.keyStoreServerAlias",
												certAlias);
										groupSelectionProperties.setProperty("com.ibm.ssl.keyStoreClientAlias",
												certAlias);
									}

									groupSelectionProperties = SSLConfigManager.getInstance()
											.determineIfCSIv2SettingsApply(groupSelectionProperties, connectionInfo);
									if (listener != null) {
										this.registerEvent(listener, configAlias, groupSelectionProperties, "scoped",
												connectionInfo);
									}

									if (tc.isEntryEnabled()) {
										Tr.exit(tc, "getProperties -> group");
									}

									return groupSelectionProperties;
								}
							}
						}
					}

					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getProperties -> default");
					}

					return SSLConfigManager.getInstance().getDefaultSSLConfig();
				}
			}
		} catch (Exception var15) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getSSLContext().", new Object[]{var15});
			}

			Manager.Ffdc.log(var15, this, "com.ibm.websphere.ssl.JSSEHelper.getSSLContext", "1059", new Object[]{this});
			throw new SSLException(var15);
		}
	}

	private void registerEvent(SSLConfigChangeListener listener, String alias, Properties config, String selection,
			Map connInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "registerEvent", new Object[]{listener, alias, selection});
		}

		if (listener != null) {
			SSLConfigChangeEvent event = new SSLConfigChangeEvent(alias, config, selection, connInfo);
			SSLConfigManager.getInstance().registerSSLConfigChangeListener(listener, event);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "registerEvent");
		}

	}

	public void registerSSLConfigChangeListener(String sslAliasName, Map connectionInfo,
			SSLConfigChangeListener listener) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "registerSSLConfigChangeListener", new Object[]{sslAliasName, connectionInfo, listener});
		}

		this.getProperties(sslAliasName, connectionInfo, listener);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "registerSSLConfigChangeListener");
		}

	}

	public void deregisterSSLConfigChangeListener(SSLConfigChangeListener listener) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "deregisterSSLConfigChangeListener", new Object[]{listener});
		}

		SSLConfigManager.getInstance().deregisterSSLConfigChangeListener(listener);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "deregisterSSLConfigChangeListener");
		}

	}

	public boolean doesSSLConfigExist(String sslAliasName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "doesSSLConfigExist", new Object[]{sslAliasName});
		}

		if (sslAliasName == null) {
			throw new IllegalArgumentException("sslAliasName is null.");
		} else {
			boolean exists = false;
			Properties props = SSLConfigManager.getInstance().getProperties(sslAliasName);
			if (props != null) {
				exists = true;
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "doesSSLConfigExist -> " + exists);
			}

			return exists;
		}
	}

	public void loadClientSSLPropertiesFromURL(String configURL, boolean reinitialize) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "parseClientSSLPropertiesURL", new Object[]{configURL});
		}

		if (configURL == null) {
			throw new IllegalArgumentException("configURL is null.");
		} else {
			if (configURL != null && configURL.indexOf("soap.client.props") != -1) {
				SSLConfigManager.getInstance().parseConfigURL("ADMIN_SOAP", configURL, reinitialize);
			} else if (configURL != null && configURL.indexOf("sas.client.props") != -1) {
				SSLConfigManager.getInstance().parseConfigURL("IIOP", configURL, reinitialize);
			} else {
				SSLConfigManager.getInstance().parseSSLConfigURL(configURL, reinitialize);
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "parseClientSSLPropertiesURL");
			}

		}
	}

	public void reinitializeClientDefaultSSLProperties() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "reinitializeClientDefaultSSLProperties");
		}

		SSLConfigManager.getInstance().reinitializeClientSSL();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "reinitializeClientDefaultSSLProperties");
		}

	}

	public void validateSSLProperties(Properties props) throws SSLException {
		SSLConfig testConfig = new SSLConfig(props);

		try {
			testConfig.validateSSLConfig();
		} catch (Exception var4) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred validating the SSL properties.", new Object[]{var4});
			}

			Manager.Ffdc.log(var4, this, "com.ibm.websphere.ssl.JSSEHelper.validateSSLProperties", "1208",
					new Object[]{this});
			if (var4 instanceof SSLException) {
				throw (SSLException) var4;
			} else {
				throw new SSLException(var4.getMessage(), var4);
			}
		}
	}

	public Map getInboundConnectionInfo() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInboundConnectionInfo");
		}

		Map inboundConnectionInfo = ThreadManager.getInstance().getInboundConnectionInfo();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInboundConnectionInfo", inboundConnectionInfo);
		}

		return inboundConnectionInfo;
	}

	public void setInboundConnectionInfo(Map connectionInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setInboundConnectionInfo", connectionInfo);
		}

		ThreadManager.getInstance().setInboundConnectionInfo(connectionInfo);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setInboundConnectionInfo");
		}

	}

	public Map getOutboundConnectionInfo() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getOutboundConnectionInfo");
		}

		Map outboundConnectionInfo = ThreadManager.getInstance().getOutboundConnectionInfo();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getOutboundConnectionInfo", outboundConnectionInfo);
		}

		return outboundConnectionInfo;
	}

	public void setOutboundConnectionInfo(Map connectionInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setOutboundConnectionInfo", connectionInfo);
		}

		ThreadManager.getInstance().setOutboundConnectionInfo(connectionInfo);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setOutboundConnectionInfo");
		}

	}

	public int getFipsInfo() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getFipsInfo");
		}

		int ret = false;
		boolean fipsEnabled = FIPSUtils.checkFipsEnabled();
		String fipsLevel = FIPSUtils.checkFipsLevel();
		String suiteBLevel = FIPSUtils.checkSuiteBLevel();
		int ret = FIPSUtils.getFipsSecurityMode(fipsEnabled, fipsLevel, suiteBLevel);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getFipsInfo=" + ret);
		}

		return ret;
	}
}