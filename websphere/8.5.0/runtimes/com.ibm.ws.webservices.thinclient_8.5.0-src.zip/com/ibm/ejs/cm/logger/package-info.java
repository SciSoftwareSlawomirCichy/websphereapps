package com.ibm.ejs.cm.logger;

interface package-info {
}