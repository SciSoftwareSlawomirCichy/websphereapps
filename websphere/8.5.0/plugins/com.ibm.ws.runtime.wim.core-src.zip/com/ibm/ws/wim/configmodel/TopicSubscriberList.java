package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface TopicSubscriberList {
	List getTopicSubscriber();

	TopicSubscriber[] getTopicSubscriberAsArray();

	TopicSubscriber createTopicSubscriber();
}