package com.ibm.ejs.container;

public class SingletonBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, EJSHome h) {
		return new SingletonBeanO(c, h);
	}
}