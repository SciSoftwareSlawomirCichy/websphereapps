package com.ibm.ws.wim.dao.db2iseries;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.ws.wim.dao.QuerySet;

public class DB2iSeriesQuerySet extends QuerySet {
	static final String COPYRIGHT_NOTICE;

	public DB2iSeriesQuerySet() {
	}

	public DB2iSeriesQuerySet(String var1) {
		super(var1);
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
	}
}