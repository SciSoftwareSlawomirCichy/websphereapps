package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class java_awt_event_MouseAdapter extends EventAdapterImpl implements MouseListener {
	public void mouseClicked(MouseEvent var1) {
		this.eventProcessor.processEvent("mouseClicked", new Object[]{var1});
	}

	public void mouseEntered(MouseEvent var1) {
		this.eventProcessor.processEvent("mouseEntered", new Object[]{var1});
	}

	public void mouseExited(MouseEvent var1) {
		this.eventProcessor.processEvent("mouseExited", new Object[]{var1});
	}

	public void mousePressed(MouseEvent var1) {
		this.eventProcessor.processEvent("mousePressed", new Object[]{var1});
	}

	public void mouseReleased(MouseEvent var1) {
		this.eventProcessor.processEvent("mouseReleased", new Object[]{var1});
	}
}