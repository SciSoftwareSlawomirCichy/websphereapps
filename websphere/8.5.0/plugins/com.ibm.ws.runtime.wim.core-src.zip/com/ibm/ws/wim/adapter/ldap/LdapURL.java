package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class LdapURL {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = LdapURL.class.getName();
	private static final Logger trcLogger;
	public static final String SCHEMENAME = "ldap";
	public static final String SCHEMENAMESSL = "ldaps";
	private String ENCODING = "UTF-8";
	private String ldapurl;
	private String scheme;
	private String hostport;
	private String host;
	private String port;
	private String dn;
	private String attributesBuffer;
	private String[] attributes;
	private String scope;
	private String filter;
	private String[] extensions;
	private boolean parsedOK;
	private String parseMsg;
	private boolean parsedone;
	private int length;

	public LdapURL(String var1) {
		this.ldapurl = var1;
		this.length = var1.length();
		this.parsedOK = false;
		this.parseMsg = "Unparsed";
		this.parsedone = false;
	}

	public LdapURL() {
		this.ldapurl = null;
		this.parsedOK = false;
		this.parseMsg = "Unparsed";
		this.parsedone = false;
	}

	private void parse() throws UnsupportedEncodingException {
		int var1 = this.ldapurl.indexOf("://");
		this.schemeParser(0, var1);
		if (!this.parsedone) {
			int var2 = this.ldapurl.indexOf("/", var1 + 3);
			this.hostPortParser(var1 + 3, var2);
			if (!this.parsedone) {
				int var3 = this.ldapurl.indexOf("?", var2 + 1);
				this.searchBaseDnParser(var2 + 1, var3);
				if (!this.parsedone) {
					int var4 = this.ldapurl.indexOf("?", var3 + 1);
					this.attributesParser(var3 + 1, var4);
					if (!this.parsedone) {
						int var5 = this.ldapurl.indexOf("?", var4 + 1);
						this.scopeParser(var4 + 1, var5);
						if (!this.parsedone) {
							int var6 = this.ldapurl.indexOf("?", var5 + 1);
							this.filterParser(var5 + 1, var6);
							if (!this.parsedone) {
								this.extensionsParser(var6 + 1);
								if (!this.parsedone) {
									;
								}
							}
						}
					}
				}
			}
		}
	}

	private void schemeParser(int var1, int var2) {
		if (var2 > var1) {
			this.scheme = this.ldapurl.substring(var1, var2);
			if (this.scheme.compareToIgnoreCase("ldap") != 0 && this.scheme.compareToIgnoreCase("ldaps") != 0) {
				this.parseMsg = "invalid ldap url";
				this.parsedone = true;
			} else {
				this.parseMsg = "scheme parsed";
			}
		} else {
			this.parseMsg = "invalid ldap url";
			this.parsedone = true;
		}

	}

	private void hostPortParser(int var1, int var2) throws UnsupportedEncodingException {
		if (var2 > var1) {
			this.hostport = this.ldapurl.substring(var1, var2);
			this.hostPortSubParser();
			this.parseMsg = "hostport parsed";
		} else if (var2 == var1) {
			this.parseMsg = "no hostport";
		} else if (var2 == -1) {
			if (this.length >= var1 + 1) {
				this.hostport = this.ldapurl.substring(var1);
				this.hostPortSubParser();
				this.parseMsg = "hostport parsed";
				this.parsedOK = true;
			}

			this.parsedone = true;
		}

	}

	private void hostPortSubParser() throws UnsupportedEncodingException {
		if (this.hostport.length() > 0) {
			int var1 = this.hostport.lastIndexOf(":");
			if (var1 == -1) {
				this.host = URLDecoder.decode(this.hostport, this.ENCODING);
			} else {
				String var2 = this.hostport.substring(0, var1);
				this.host = URLDecoder.decode(var2, this.ENCODING);
				String var3 = this.hostport.substring(var1 + 1);
				this.port = URLDecoder.decode(var3, this.ENCODING);
			}
		}

	}

	private void searchBaseDnParser(int var1, int var2) throws UnsupportedEncodingException {
		String var3;
		if (var2 > var1) {
			var3 = this.ldapurl.substring(var1, var2);
			this.dn = URLDecoder.decode(var3, this.ENCODING);
			this.parseMsg = "dn parsed";
		} else if (var2 == var1) {
			this.parseMsg = "invalid ldap url";
			this.parsedone = true;
		} else if (var2 == -1) {
			if (this.length >= var1 + 1) {
				var3 = this.ldapurl.substring(var1);
				this.dn = URLDecoder.decode(var3, this.ENCODING);
				this.parseMsg = "dn parsed";
				this.parsedOK = true;
			}

			this.parsedone = true;
		}

	}

	private void attributesParser(int var1, int var2) {
		if (var2 > var1) {
			this.attributesBuffer = this.ldapurl.substring(var1, var2);
			this.attributesSubParser();
			this.parseMsg = "attributes parsed";
		} else if (var2 == var1) {
			this.parseMsg = "no attributes";
		} else if (var2 == -1) {
			if (this.length >= var1 + 1) {
				this.attributesBuffer = this.ldapurl.substring(var1);
				this.attributesSubParser();
				this.parseMsg = "attributes parsed";
				this.parsedOK = true;
			}

			this.parsedone = true;
		}

	}

	private void attributesSubParser() {
		this.attributes = this.attributesBuffer.split(",");
	}

	private void scopeParser(int var1, int var2) {
		if (var2 > var1) {
			this.scope = this.ldapurl.substring(var1, var2);
			this.parseMsg = "scope parsed";
		} else if (var2 == var1) {
			this.parseMsg = "no scope";
		} else if (var2 == -1) {
			if (this.length >= var1 + 1) {
				this.scope = this.ldapurl.substring(var1);
				this.parseMsg = "scope parsed";
				this.parsedOK = true;
			}

			this.parsedone = true;
		}

	}

	private void filterParser(int var1, int var2) throws UnsupportedEncodingException {
		String var3;
		if (var2 > var1) {
			var3 = this.ldapurl.substring(var1, var2);
			this.filter = URLDecoder.decode(var3, this.ENCODING);
			this.parseMsg = "filter parsed";
		} else if (var2 == var1) {
			this.parseMsg = "no filter";
		} else if (var2 == -1) {
			if (this.length >= var1 + 1) {
				var3 = this.ldapurl.substring(var1);
				this.filter = URLDecoder.decode(var3, this.ENCODING);
				this.parseMsg = "filter parsed";
				this.parsedOK = true;
			}

			this.parsedone = true;
		}

	}

	private void extensionsParser(int var1) {
		if (this.length >= var1 + 1) {
			String var2 = this.ldapurl.substring(var1);
			boolean var6 = false;
			int var5 = var2.length();
			int var3 = 0;

			for (int var7 = 0; var5 > var3 + 1; ++var7) {
				int var4 = var2.indexOf(",", var3);
				if (var4 > 0) {
					this.extensions[var7] = var2.substring(var3, var4);
				} else if (var4 == -1) {
					this.extensions[var7] = var2.substring(var3);
					break;
				}

				var3 = var4 + 1;
			}

			this.parseMsg = "extensions parsed";
		}

		this.parsedOK = true;
		this.parsedone = true;
	}

	public boolean parsedOK() throws WIMSystemException {
		String var1 = "parsedOK";

		try {
			if (!this.parsedone) {
				this.parse();
			}
		} catch (UnsupportedEncodingException var3) {
			trcLogger.logp(Level.SEVERE, CLASSNAME, var1, var3.toString());
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var3.toString()), CLASSNAME,
					var1);
		} catch (Exception var4) {
			this.parsedOK = false;
		}

		return this.parsedOK;
	}

	public String get_parseMsg() {
		return this.parseMsg;
	}

	public String get_url() {
		return this.ldapurl;
	}

	public String get_host() {
		return this.host;
	}

	public String get_port() {
		return this.port;
	}

	public String get_dn() {
		return this.dn;
	}

	public String[] get_attributes() {
		return this.attributes;
	}

	public String get_scope() {
		return this.scope;
	}

	public String get_filter() {
		return this.filter;
	}

	public int get_searchScope() {
		byte var1 = 0;
		String var2 = this.get_scope();
		if (var2 != null) {
			if (var2.compareToIgnoreCase("base") == 0) {
				var1 = 0;
			} else if (var2.compareToIgnoreCase("one") == 0) {
				var1 = 1;
			} else if (var2.compareToIgnoreCase("sub") == 0) {
				var1 = 2;
			}
		}

		return var1;
	}

	public String[] get_extensions() {
		return this.extensions;
	}

	public void dump() {
		trcLogger.log(Level.FINER, "---- URL Dump ---- ");
		trcLogger.log(Level.FINER, "URL: " + this.ldapurl);
		trcLogger.log(Level.FINER, "Parse message: " + this.parseMsg);
		trcLogger.log(Level.FINER, "host: " + this.host);
		trcLogger.log(Level.FINER, "port: " + this.port);
		trcLogger.log(Level.FINER, "DN: " + this.dn);
		trcLogger.log(Level.FINER, "scope: " + this.scope);
		trcLogger.log(Level.FINER, "filter: " + this.filter);
		trcLogger.log(Level.FINER, "attributes: ");

		for (int var1 = 0; var1 < this.attributes.length; ++var1) {
			trcLogger.log(Level.FINER, "    " + this.attributes[var1]);
		}

	}

	public String toString() {
		return this.ldapurl;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}