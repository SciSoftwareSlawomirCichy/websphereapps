package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_cs extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Stroj pro analýzu používající databázi: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Událost FFDC byla vydána v umístění {0} {1} {2}."},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: Správa souborů s protokolem FFDC se pokouší o odstranění souboru {0}."},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: Správa souborů s protokolem FFDC odebrala {0} z {1} souborů, které dosáhly nastaveného maximálního stáří."},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: Správě souborů s protokolem FFDC se nepodařilo odstranit soubor {0}."},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: Správě souborů s protokolem FFDC se nepodařilo získat seznam souborů výjimek."},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: Funkce FFDC zavřela soubor proudu události {0}."},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: Funkce FFDC otevřela soubor proudu události {0}."},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: Funkci FFDC se nepodařilo zavřít soubor proudu události {0}. Byla zachycena výjimka {1}."},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: Funkci FFDC se nepodařilo otevřít nebo vytvořit soubor proudu události {0}. Byla zachycena výjimka {1}."},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: Funkci FFDC se nepodařil zápis do souboru proudu události {0}. Byla zachycena výjimka {1}."}};

	public Object[][] getContents() {
		return resources;
	}
}