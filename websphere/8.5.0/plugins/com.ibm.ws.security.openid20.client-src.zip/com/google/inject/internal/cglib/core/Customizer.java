package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.Type;

public interface Customizer {
	void customize(CodeEmitter var1, Type var2);
}