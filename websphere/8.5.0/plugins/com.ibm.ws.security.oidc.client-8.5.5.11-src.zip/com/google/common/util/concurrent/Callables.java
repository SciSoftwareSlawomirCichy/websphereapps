package com.google.common.util.concurrent;

import com.google.common.util.concurrent.Callables.1;
import java.util.concurrent.Callable;
import javax.annotation.Nullable;

public final class Callables {
	public static <T> Callable<T> returning(@Nullable T value) {
      return new 1(value);
   }
}