package com.google.common.hash;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.primitives.Ints;
import java.security.MessageDigest;
import javax.annotation.Nullable;

@Beta
public abstract class HashCode {
	private static final char[] hexDigits = "0123456789abcdef".toCharArray();

	public abstract int asInt();

	public abstract long asLong();

	public abstract long padToLong();

	public abstract byte[] asBytes();

	public int writeBytesTo(byte[] dest, int offset, int maxLength) {
		byte[] hash = this.asBytes();
		maxLength = Ints.min(new int[]{maxLength, hash.length});
		Preconditions.checkPositionIndexes(offset, offset + maxLength, dest.length);
		System.arraycopy(hash, 0, dest, offset, maxLength);
		return maxLength;
	}

	public abstract int bits();

	public boolean equals(@Nullable Object object) {
		if (object instanceof HashCode) {
			HashCode that = (HashCode) object;
			return MessageDigest.isEqual(this.asBytes(), that.asBytes());
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.asInt();
	}

	public String toString() {
		byte[] bytes = this.asBytes();
		StringBuilder sb = new StringBuilder(2 * bytes.length);
		byte[] arr$ = bytes;
		int len$ = bytes.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			byte b = arr$[i$];
			sb.append(hexDigits[b >> 4 & 15]).append(hexDigits[b & 15]);
		}

		return sb.toString();
	}
}