package com.ibm.ejs.ras;

class ComponentManager {
	public static final String $sccsid = "@(#) 1.2 SERV1/ws/code/ras.lite/src/com/ibm/ejs/ras/ComponentManager.java, WAS.ras.lite, WAS855.SERV1, cf172003.01 06/11/10 02:39:06 [1/28/20 10:11:16]";
}