package com.ibm.ws.wim.security.authz.jacc;

import com.ibm.sec.auth.subjectx.SubjectAttributes;
import com.ibm.sec.authz.jaccx.condition.RequestContext;
import com.ibm.sec.authz.jaccx.resource.Resource;
import com.ibm.sec.authz.jaccx.resource.ResourceContext;
import java.util.HashSet;
import java.util.Set;
import javax.security.auth.Subject;
import javax.security.jacc.PolicyContextException;
import javax.security.jacc.PolicyContextHandler;

class PolicyContextHandlerImpl implements PolicyContextHandler {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private Set supportedKeys;
	private Subject subject;
	private Resource resource;
	private RequestContext requestContext;
	private SubjectAttributes subjectAttributes;
	private ResourceContext resourceContext;

	public PolicyContextHandlerImpl(Subject var1, Resource var2, RequestContext var3, SubjectAttributes var4,
			ResourceContext var5) {
		this.subject = var1;
		this.resource = var2;
		this.requestContext = var3;
		this.subjectAttributes = var4;
		this.resourceContext = var5;
		this.supportedKeys = new HashSet();
		this.supportedKeys.add("javax.security.auth.Subject.container");
		this.supportedKeys.add(Resource.JACC_RESOURCE_KEY);
		this.supportedKeys.add(RequestContext.JACC_REQUEST_CONTEXT_KEY);
		this.supportedKeys.add(SubjectAttributes.JACC_SUBJECT_ATTRIBUTES_KEY);
		this.supportedKeys.add(ResourceContext.JACC_RESOURCE_CONTEXT_KEY);
	}

	public String[] getKeys() throws PolicyContextException {
		return (String[]) ((String[]) this.supportedKeys.toArray(new String[this.supportedKeys.size()]));
	}

	public boolean supports(String var1) throws PolicyContextException {
		return this.supportedKeys.contains(var1);
	}

	public Object getContext(String var1, Object var2) throws PolicyContextException {
		if (var1.equals("javax.security.auth.Subject.container")) {
			return this.subject;
		} else if (var1.equals(Resource.JACC_RESOURCE_KEY)) {
			return this.resource;
		} else if (var1.equals(RequestContext.JACC_REQUEST_CONTEXT_KEY)) {
			return this.requestContext;
		} else if (var1.equals(SubjectAttributes.JACC_SUBJECT_ATTRIBUTES_KEY)) {
			return this.subjectAttributes;
		} else {
			return var1.equals(ResourceContext.JACC_RESOURCE_CONTEXT_KEY) ? this.resourceContext : null;
		}
	}
}