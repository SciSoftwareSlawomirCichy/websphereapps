package com.ibm.ejs.container.passivator;

import com.ibm.ejs.container.passivator.EJBObjectInfo.FieldInfo;
import com.ibm.ejs.util.Util;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

class EJBObjectInfo implements Serializable {
	private static final long serialVersionUID = 7712587930606979632L;
	private boolean ivSerializable = false;
	private Object ivSerializableObject = null;
	private String ivClassName = null;
	private Map<String, List<FieldInfo>> ivFieldInfoMap = null;

	String getClassName() {
		return this.ivClassName;
	}

	void setClassName(String className) {
		this.ivClassName = className;
	}

	Map<String, List<FieldInfo>> getFieldInfoMap() {
		return this.ivFieldInfoMap;
	}

	void addFieldInfo(String className, List<FieldInfo> fieldInfoList) {
		if (this.ivFieldInfoMap == null) {
			this.ivFieldInfoMap = new HashMap();
		}

		this.ivFieldInfoMap.put(className, fieldInfoList);
	}

	boolean isSerializable() {
		return this.ivSerializable;
	}

	void setSerializable(boolean serializable) {
		this.ivSerializable = serializable;
	}

	Object getSerializableObject() {
		return this.ivSerializableObject;
	}

	void setSerializableObject(Object serializableObject) {
		this.ivSerializableObject = serializableObject;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder(128);
		sb.append("EJBObjectInfo");
		sb.append("\tserializable=" + this.ivSerializable);
		if (this.ivSerializable) {
			if (this.ivSerializableObject != null) {
				sb.append(" className=" + this.ivSerializableObject.getClass().getName());
			}
		} else {
			if (this.ivClassName != null) {
				sb.append(" className=" + this.ivClassName);
			}

			if (this.ivFieldInfoMap != null) {
				sb.append("\n\tfieldInfoMap");
				Set<String> classNames = this.ivFieldInfoMap.keySet();
				Iterator i$ = classNames.iterator();

				while (true) {
					List fieldInfoList;
					do {
						if (!i$.hasNext()) {
							return sb.toString();
						}

						String className = (String) i$.next();
						sb.append("\n\t\tclassName=" + className);
						fieldInfoList = (List) this.ivFieldInfoMap.get(className);
					} while (fieldInfoList == null);

					Iterator i$ = fieldInfoList.iterator();

					while (i$.hasNext()) {
						FieldInfo fieldInfo = (FieldInfo) i$.next();
						sb.append("\n\t\t\tfieldInfo=" + fieldInfo.name + " - " + Util.identity(fieldInfo.value));
					}
				}
			}
		}

		return sb.toString();
	}
}