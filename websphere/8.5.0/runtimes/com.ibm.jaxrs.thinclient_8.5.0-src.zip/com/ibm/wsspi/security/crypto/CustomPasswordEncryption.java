package com.ibm.wsspi.security.crypto;

import java.util.HashMap;

public interface CustomPasswordEncryption {
	EncryptedInfo encrypt(byte[] var1) throws PasswordEncryptException;

	byte[] decrypt(EncryptedInfo var1) throws PasswordDecryptException;

	void initialize(HashMap var1);
}