package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_fr extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: Formateur FFDC ajouté {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Moteur d''analyse utilisant la base de données : {0}."},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: Echec de résolution du moteur d'analyse :"},
			{"FFDCDataCollectorAdded", "FFDC1011I: Collecteur de données FFDC ajouté {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: Collecteur de données FFDC retiré {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: Incident FFDC émis sur SystemErr : {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC en mode sécuritaire, rechercher les erreurs {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: Transmetteur d''incident FFDC ajouté {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: Transmetteur d''incident FFDC retiré {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Incident FFDC émis sur {0} {1} {2}"},
			{"FFDCProviderAborted", "FFDC1000I: Interruption du fournisseur FFDC {0}, exception ci-après"},
			{"FFDCProviderAbortedE", "FFDC1001I: Interruption du fournisseur FFDC avec l''exception {0}"},
			{"FFDCProviderException", "FFDC1008I: Exception de fournisseur FFDC :"},
			{"FFDCProviderInstalled", "FFDC1007I: Fournisseur FFDC installé : {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: Formateur FFDC retiré {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}