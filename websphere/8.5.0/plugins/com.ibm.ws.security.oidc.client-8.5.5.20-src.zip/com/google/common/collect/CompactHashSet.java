package com.google.common.collect;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractSet;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtIncompatible
class CompactHashSet<E> extends AbstractSet<E> implements Serializable {
	private static final int MAXIMUM_CAPACITY = 1073741824;
	private static final float DEFAULT_LOAD_FACTOR = 1.0F;
	private static final long NEXT_MASK = 4294967295L;
	private static final long HASH_MASK = -4294967296L;
	private static final int DEFAULT_SIZE = 3;
	static final int UNSET = -1;
	@MonotonicNonNullDecl
	private transient int[] table;
	@MonotonicNonNullDecl
	private transient long[] entries;
	@MonotonicNonNullDecl
	transient Object[] elements;
	transient float loadFactor;
	transient int modCount;
	private transient int threshold;
	private transient int size;

	public static <E> CompactHashSet<E> create() {
		return new CompactHashSet();
	}

	public static <E> CompactHashSet<E> create(Collection<? extends E> collection) {
		CompactHashSet<E> set = createWithExpectedSize(collection.size());
		set.addAll(collection);
		return set;
	}

	public static <E> CompactHashSet<E> create(E... elements) {
		CompactHashSet<E> set = createWithExpectedSize(elements.length);
		Collections.addAll(set, elements);
		return set;
	}

	public static <E> CompactHashSet<E> createWithExpectedSize(int expectedSize) {
		return new CompactHashSet(expectedSize);
	}

	CompactHashSet() {
		this.init(3, 1.0F);
	}

	CompactHashSet(int expectedSize) {
		this.init(expectedSize, 1.0F);
	}

	void init(int expectedSize, float loadFactor) {
		Preconditions.checkArgument(expectedSize >= 0, "Initial capacity must be non-negative");
		Preconditions.checkArgument(loadFactor > 0.0F, "Illegal load factor");
		int buckets = Hashing.closedTableSize(expectedSize, (double) loadFactor);
		this.table = newTable(buckets);
		this.loadFactor = loadFactor;
		this.elements = new Object[expectedSize];
		this.entries = newEntries(expectedSize);
		this.threshold = Math.max(1, (int) ((float) buckets * loadFactor));
	}

	private static int[] newTable(int size) {
		int[] array = new int[size];
		Arrays.fill(array, -1);
		return array;
	}

	private static long[] newEntries(int size) {
		long[] array = new long[size];
		Arrays.fill(array, -1L);
		return array;
	}

	private static int getHash(long entry) {
		return (int) (entry >>> 32);
	}

	private static int getNext(long entry) {
		return (int) entry;
	}

	private static long swapNext(long entry, int newNext) {
		return -4294967296L & entry | 4294967295L & (long) newNext;
	}

	private int hashTableMask() {
		return this.table.length - 1;
	}

	@CanIgnoreReturnValue
	public boolean add(@NullableDecl E object) {
		long[] entries = this.entries;
		Object[] elements = this.elements;
		int hash = Hashing.smearedHash(object);
		int tableIndex = hash & this.hashTableMask();
		int newEntryIndex = this.size;
		int next = this.table[tableIndex];
		int last;
		if (next == -1) {
			this.table[tableIndex] = newEntryIndex;
		} else {
			long entry;
			do {
				last = next;
				entry = entries[next];
				if (getHash(entry) == hash && Objects.equal(object, elements[next])) {
					return false;
				}

				next = getNext(entry);
			} while (next != -1);

			entries[last] = swapNext(entry, newEntryIndex);
		}

		if (newEntryIndex == Integer.MAX_VALUE) {
			throw new IllegalStateException("Cannot contain more than Integer.MAX_VALUE elements!");
		} else {
			last = newEntryIndex + 1;
			this.resizeMeMaybe(last);
			this.insertEntry(newEntryIndex, object, hash);
			this.size = last;
			if (newEntryIndex >= this.threshold) {
				this.resizeTable(2 * this.table.length);
			}

			++this.modCount;
			return true;
		}
	}

	void insertEntry(int entryIndex, E object, int hash) {
		this.entries[entryIndex] = (long) hash << 32 | 4294967295L;
		this.elements[entryIndex] = object;
	}

	private void resizeMeMaybe(int newSize) {
		int entriesSize = this.entries.length;
		if (newSize > entriesSize) {
			int newCapacity = entriesSize + Math.max(1, entriesSize >>> 1);
			if (newCapacity < 0) {
				newCapacity = Integer.MAX_VALUE;
			}

			if (newCapacity != entriesSize) {
				this.resizeEntries(newCapacity);
			}
		}

	}

	void resizeEntries(int newCapacity) {
		this.elements = Arrays.copyOf(this.elements, newCapacity);
		long[] entries = this.entries;
		int oldSize = entries.length;
		entries = Arrays.copyOf(entries, newCapacity);
		if (newCapacity > oldSize) {
			Arrays.fill(entries, oldSize, newCapacity, -1L);
		}

		this.entries = entries;
	}

	private void resizeTable(int newCapacity) {
		int[] oldTable = this.table;
		int oldCapacity = oldTable.length;
		if (oldCapacity >= 1073741824) {
			this.threshold = Integer.MAX_VALUE;
		} else {
			int newThreshold = 1 + (int) ((float) newCapacity * this.loadFactor);
			int[] newTable = newTable(newCapacity);
			long[] entries = this.entries;
			int mask = newTable.length - 1;

			for (int i = 0; i < this.size; ++i) {
				long oldEntry = entries[i];
				int hash = getHash(oldEntry);
				int tableIndex = hash & mask;
				int next = newTable[tableIndex];
				newTable[tableIndex] = i;
				entries[i] = (long) hash << 32 | 4294967295L & (long) next;
			}

			this.threshold = newThreshold;
			this.table = newTable;
		}
	}

	public boolean contains(@NullableDecl Object object) {
		int hash = Hashing.smearedHash(object);

		long entry;
		for (int next = this.table[hash & this.hashTableMask()]; next != -1; next = getNext(entry)) {
			entry = this.entries[next];
			if (getHash(entry) == hash && Objects.equal(object, this.elements[next])) {
				return true;
			}
		}

		return false;
	}

	@CanIgnoreReturnValue
	public boolean remove(@NullableDecl Object object) {
		return this.remove(object, Hashing.smearedHash(object));
	}

	@CanIgnoreReturnValue
	private boolean remove(Object object, int hash) {
		int tableIndex = hash & this.hashTableMask();
		int next = this.table[tableIndex];
		if (next == -1) {
			return false;
		} else {
			int last = -1;

			do {
				if (getHash(this.entries[next]) == hash && Objects.equal(object, this.elements[next])) {
					if (last == -1) {
						this.table[tableIndex] = getNext(this.entries[next]);
					} else {
						this.entries[last] = swapNext(this.entries[last], getNext(this.entries[next]));
					}

					this.moveEntry(next);
					--this.size;
					++this.modCount;
					return true;
				}

				last = next;
				next = getNext(this.entries[next]);
			} while (next != -1);

			return false;
		}
	}

	void moveEntry(int dstIndex) {
		int srcIndex = this.size() - 1;
		if (dstIndex < srcIndex) {
			this.elements[dstIndex] = this.elements[srcIndex];
			this.elements[srcIndex] = null;
			long lastEntry = this.entries[srcIndex];
			this.entries[dstIndex] = lastEntry;
			this.entries[srcIndex] = -1L;
			int tableIndex = getHash(lastEntry) & this.hashTableMask();
			int lastNext = this.table[tableIndex];
			if (lastNext == srcIndex) {
				this.table[tableIndex] = dstIndex;
			} else {
				int previous;
				long entry;
				do {
					previous = lastNext;
					lastNext = getNext(entry = this.entries[lastNext]);
				} while (lastNext != srcIndex);

				this.entries[previous] = swapNext(entry, dstIndex);
			}
		} else {
			this.elements[dstIndex] = null;
			this.entries[dstIndex] = -1L;
		}

	}

	int firstEntryIndex() {
		return this.isEmpty() ? -1 : 0;
	}

	int getSuccessor(int entryIndex) {
		return entryIndex + 1 < this.size ? entryIndex + 1 : -1;
	}

	int adjustAfterRemove(int indexBeforeRemove, int indexRemoved) {
		return indexBeforeRemove - 1;
	}

	public Iterator<E> iterator() {
		return new Iterator<E>() {
			int expectedModCount;
			int index;
			int indexToRemove;

			{
				this.expectedModCount = CompactHashSet.this.modCount;
				this.index = CompactHashSet.this.firstEntryIndex();
				this.indexToRemove = -1;
			}

			public boolean hasNext() {
				return this.index >= 0;
			}

			public E next() {
				this.checkForConcurrentModification();
				if (!this.hasNext()) {
					throw new NoSuchElementException();
				} else {
					this.indexToRemove = this.index;
					E result = CompactHashSet.this.elements[this.index];
					this.index = CompactHashSet.this.getSuccessor(this.index);
					return result;
				}
			}

			public void remove() {
				this.checkForConcurrentModification();
				CollectPreconditions.checkRemove(this.indexToRemove >= 0);
				++this.expectedModCount;
				CompactHashSet.this.remove(CompactHashSet.this.elements[this.indexToRemove],
						CompactHashSet.getHash(CompactHashSet.this.entries[this.indexToRemove]));
				this.index = CompactHashSet.this.adjustAfterRemove(this.index, this.indexToRemove);
				this.indexToRemove = -1;
			}

			private void checkForConcurrentModification() {
				if (CompactHashSet.this.modCount != this.expectedModCount) {
					throw new ConcurrentModificationException();
				}
			}
		};
	}

	public int size() {
		return this.size;
	}

	public boolean isEmpty() {
		return this.size == 0;
	}

	public Object[] toArray() {
		return Arrays.copyOf(this.elements, this.size);
	}

	@CanIgnoreReturnValue
	public <T> T[] toArray(T[] a) {
		return ObjectArrays.toArrayImpl(this.elements, 0, this.size, a);
	}

	public void trimToSize() {
		int size = this.size;
		if (size < this.entries.length) {
			this.resizeEntries(size);
		}

		int minimumTableSize = Math.max(1, Integer.highestOneBit((int) ((float) size / this.loadFactor)));
		if (minimumTableSize < 1073741824) {
			double load = (double) size / (double) minimumTableSize;
			if (load > (double) this.loadFactor) {
				minimumTableSize <<= 1;
			}
		}

		if (minimumTableSize < this.table.length) {
			this.resizeTable(minimumTableSize);
		}

	}

	public void clear() {
		++this.modCount;
		Arrays.fill(this.elements, 0, this.size, (Object) null);
		Arrays.fill(this.table, -1);
		Arrays.fill(this.entries, -1L);
		this.size = 0;
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		stream.writeInt(this.size);
		Iterator var2 = this.iterator();

		while (var2.hasNext()) {
			E e = var2.next();
			stream.writeObject(e);
		}

	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		this.init(3, 1.0F);
		int elementCount = stream.readInt();
		int i = elementCount;

		while (true) {
			--i;
			if (i < 0) {
				return;
			}

			E element = stream.readObject();
			this.add(element);
		}
	}
}