package com.ibm.ejs.container;

import javax.rmi.CORBA.Stub;

public abstract class SerializableStub extends Stub {
	private final Class ivClass;

	public SerializableStub(Class klass) {
		this.ivClass = klass;
	}

	protected Object writeReplace() {
		return new SerializedStub(this, this.ivClass);
	}
}