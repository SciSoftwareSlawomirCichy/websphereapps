package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.StaticModelType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EDataTypeEList;

public class StaticModelTypeImpl extends EDataObjectImpl implements StaticModelType {
	protected EList packageName = null;
	protected static final boolean USE_GLOBAL_SCHEMA_EDEFAULT = false;
	protected boolean useGlobalSchema = false;
	protected boolean useGlobalSchemaESet = false;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getStaticModelType();
	}

	public String[] getPackageNameAsArray() {
		List var1 = this.getPackageName();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getPackageName() {
		if (this.packageName == null) {
			this.packageName = new EDataTypeEList(String.class, this, 0);
		}

		return this.packageName;
	}

	public boolean isUseGlobalSchema() {
		return this.useGlobalSchema;
	}

	public void setUseGlobalSchema(boolean var1) {
		boolean var2 = this.useGlobalSchema;
		this.useGlobalSchema = var1;
		boolean var3 = this.useGlobalSchemaESet;
		this.useGlobalSchemaESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.useGlobalSchema, !var3));
		}

	}

	public void unsetUseGlobalSchema() {
		boolean var1 = this.useGlobalSchema;
		boolean var2 = this.useGlobalSchemaESet;
		this.useGlobalSchema = false;
		this.useGlobalSchemaESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 1, var1, false, var2));
		}

	}

	public boolean isSetUseGlobalSchema() {
		return this.useGlobalSchemaESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getPackageName();
			case 1 :
				return this.isUseGlobalSchema() ? Boolean.TRUE : Boolean.FALSE;
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getPackageName().clear();
				this.getPackageName().addAll((Collection) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getPackageName().clear();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.packageName != null && !this.packageName.isEmpty();
			case 1 :
				return this.isSetUseGlobalSchema();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (packageName: ");
			var1.append(this.packageName);
			var1.append(", useGlobalSchema: ");
			if (this.useGlobalSchemaESet) {
				var1.append(this.useGlobalSchema);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}