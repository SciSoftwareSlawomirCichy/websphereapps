package com.ibm.ws.security.oidc.client.filter;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.oidc.util.MessageHelper;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

public class CommonHTTPHeaderFilter {
	static final TraceComponent tc = Tr.register(CommonHTTPHeaderFilter.class, "OidcClient",
			"com.ibm.ws.security.oidc.client.resources.oidcmessages");
	protected boolean nonFilter = false;
	protected boolean processAll = false;
	protected static final String APPLICATION_NAMES = "applicationNames";
	protected static final String REFERRER = "Referer";
	protected List<ICondition> filterCondition = new LinkedList();

	public CommonHTTPHeaderFilter() {
	}

	public CommonHTTPHeaderFilter(String s1) {
		this.init(s1);
	}

	public boolean init(String s1) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, s1);
		}

		if (s1 == null) {
			this.nonFilter = true;
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Filter Not Defined");
			}

			return false;
		} else {
			StringTokenizer st1 = new StringTokenizer(s1, ";");
			StringTokenizer st2 = null;
			String s2 = null;

			while (st1.hasMoreTokens()) {
				s2 = st1.nextToken();
				st2 = new StringTokenizer(s2, "^=!<>%");
				String key = st2.nextToken();
				if (!st2.hasMoreTokens()) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, s2);
					}

					return false;
				}

				String valueString = st2.nextToken();
				String operand = s2.substring(key.length(), s2.length() - valueString.length()).trim();
				boolean ipAddress = false;
				if ("remote-address".equals(key)) {
					ipAddress = true;
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "isValid", "Adding " + key + " " + operand + " " + valueString);
				}

				try {
					ICondition condition = this.makeCondition(key, operand, valueString, ipAddress);
					this.filterCondition.add(condition);
				} catch (FilterException var10) {
					throw new RuntimeException(var10);
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "init", Boolean.toString(true));
			}

			return true;
		}
	}

	protected boolean isAccepted(IRequestInfo req) {
		String reason = "TAI will intercept request.";
		boolean isAccepted = false;
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isAccepted");
		}

		if (this.processAll) {
			reason = "processAll is true, therefore we always intercept.";
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "isAccepted", isAccepted + " " + reason);
			}

			return true;
		} else {
			String HTTPheader = null;
			Iterator iter = this.filterCondition.iterator();

			while (iter.hasNext()) {
				ICondition cond = (ICondition) iter.next();
				HTTPheader = req.getHeader(cond.getKey());
				boolean ipAddress = false;
				if (HTTPheader == null) {
					if (cond.getKey().equals("remote-address")) {
						HTTPheader = req.getRemoteAddr();
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "isAccepted", "HTTPheader obtained from 'remote-address' " + HTTPheader);
						}

						ipAddress = true;
					} else {
						String queryString;
						if (cond.getKey().equals("request-url")) {
							queryString = req.getQueryString();
							if (queryString != null) {
								HTTPheader = req.getRequestURL().toString() + "?" + queryString;
							} else {
								HTTPheader = req.getRequestURL().toString();
							}

							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "isAccepted", "HTTPheader obtained from 'request-url' " + HTTPheader);
							}
						} else if (cond.getKey().equals("request-uri")) {
							HTTPheader = req.getRequestURI();
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "isAccepted", "HTTPheader obtained from 'request-uri' " + HTTPheader);
							}
						} else if (cond.getKey().equals("Referer")) {
							HTTPheader = req.getReferer();
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "isAccepted", "HTTPheader obtained from 'Referer' " + HTTPheader);
							}
						} else {
							if (!cond.getKey().equals("applicationNames")) {
								if (cond instanceof NotContainsCondition) {
									continue;
								}

								reason = "No HTTPheader found, and no 'remote-address' or 'request-url' rule used - do not Intercept.";
								isAccepted = false;
								if (tc.isEntryEnabled()) {
									Tr.exit(tc, "isAccepted", isAccepted + " " + reason);
								}
								break;
							}

							queryString = req.getApplicationName();
							if (queryString != null) {
								HTTPheader = queryString;
							}

							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "isAccepted", "ApplicationName:" + HTTPheader);
							}
						}
					}
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "isAccepted", "Checking condition:" + cond);
				}

				try {
					Object compareValue;
					if (ipAddress) {
						compareValue = new ValueIPAddress(HTTPheader);
					} else {
						compareValue = new ValueString(HTTPheader);
					}

					boolean answer = cond.checkCondition((IValue) compareValue);
					if (!answer) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "isAccepted", "check failed, returning false. TAI will not intercept");
						}

						isAccepted = false;
						break;
					}

					isAccepted = true;
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "isAccepted", "check passed, continuing to next condition");
					}
				} catch (FilterException var10) {
					throw new RuntimeException(var10);
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "isAccepted", "TAI will intercept request");
				Tr.exit(tc, "isAccepted", isAccepted + " " + reason);
			}

			return isAccepted;
		}
	}

	private ICondition makeCondition(String key, String operand, String valueString, boolean ipAddress)
			throws FilterException {
		if (operand.equals("==")) {
			return new EqualCondition(key, this.makeValue(valueString, ipAddress));
		} else if (operand.equals("!=")) {
			return new NotContainsCondition(key, this.makeValue(valueString, ipAddress));
		} else if (!operand.equals("^=")) {
			if (operand.equals("%=")) {
				return new ContainsCondition(key, this.makeValue(valueString, ipAddress));
			} else if (operand.equals("<")) {
				return new LessCondition(key, this.makeValue(valueString, ipAddress));
			} else if (operand.equals(">")) {
				return new GreaterCondition(key, this.makeValue(valueString, ipAddress));
			} else {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "init", operand);
				}

				String msg = MessageHelper.getMessage("security.tai.malformed.filter.operator", new Object[]{operand});
				throw new FilterException(msg);
			}
		} else {
			OrCondition cond = new OrCondition(key);
			StringTokenizer tokens = new StringTokenizer(valueString, "|");

			while (tokens.hasMoreTokens()) {
				String token = tokens.nextToken();
				cond.addValue(this.makeValue(token, ipAddress));
			}

			return cond;
		}
	}

	private IValue makeValue(String value, boolean ipAddress) throws FilterException {
		return (IValue) (ipAddress ? new ValueAddressRange(value) : new ValueString(value));
	}

	public void setProcessAll(boolean b) {
		this.processAll = b;
	}

	public boolean noFilter() {
		return this.nonFilter;
	}
}