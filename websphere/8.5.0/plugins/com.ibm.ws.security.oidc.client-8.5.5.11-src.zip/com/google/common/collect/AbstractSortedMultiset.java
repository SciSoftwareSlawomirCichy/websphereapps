package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.AbstractSortedMultiset.1;
import com.google.common.collect.Multiset.Entry;
import com.google.common.collect.SortedMultisets.NavigableElementSet;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NavigableSet;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
abstract class AbstractSortedMultiset<E> extends AbstractMultiset<E> implements SortedMultiset<E> {
	@GwtTransient
	final Comparator<? super E> comparator;
	private transient SortedMultiset<E> descendingMultiset;

	AbstractSortedMultiset() {
		this(Ordering.natural());
	}

	AbstractSortedMultiset(Comparator<? super E> comparator) {
		this.comparator = (Comparator) Preconditions.checkNotNull(comparator);
	}

	public NavigableSet<E> elementSet() {
		return (NavigableSet) super.elementSet();
	}

	NavigableSet<E> createElementSet() {
		return new NavigableElementSet(this);
	}

	public Comparator<? super E> comparator() {
		return this.comparator;
	}

	public Entry<E> firstEntry() {
		Iterator<Entry<E>> entryIterator = this.entryIterator();
		return entryIterator.hasNext() ? (Entry) entryIterator.next() : null;
	}

	public Entry<E> lastEntry() {
		Iterator<Entry<E>> entryIterator = this.descendingEntryIterator();
		return entryIterator.hasNext() ? (Entry) entryIterator.next() : null;
	}

	public Entry<E> pollFirstEntry() {
		Iterator<Entry<E>> entryIterator = this.entryIterator();
		if (entryIterator.hasNext()) {
			Entry<E> result = (Entry) entryIterator.next();
			result = Multisets.immutableEntry(result.getElement(), result.getCount());
			entryIterator.remove();
			return result;
		} else {
			return null;
		}
	}

	public Entry<E> pollLastEntry() {
		Iterator<Entry<E>> entryIterator = this.descendingEntryIterator();
		if (entryIterator.hasNext()) {
			Entry<E> result = (Entry) entryIterator.next();
			result = Multisets.immutableEntry(result.getElement(), result.getCount());
			entryIterator.remove();
			return result;
		} else {
			return null;
		}
	}

	public SortedMultiset<E> subMultiset(@Nullable E fromElement, BoundType fromBoundType, @Nullable E toElement,
			BoundType toBoundType) {
		Preconditions.checkNotNull(fromBoundType);
		Preconditions.checkNotNull(toBoundType);
		return this.tailMultiset(fromElement, fromBoundType).headMultiset(toElement, toBoundType);
	}

	abstract Iterator<Entry<E>> descendingEntryIterator();

	Iterator<E> descendingIterator() {
		return Multisets.iteratorImpl(this.descendingMultiset());
	}

	public SortedMultiset<E> descendingMultiset() {
		SortedMultiset<E> result = this.descendingMultiset;
		return result == null ? (this.descendingMultiset = this.createDescendingMultiset()) : result;
	}

	SortedMultiset<E> createDescendingMultiset() {
      return new 1(this);
   }
}