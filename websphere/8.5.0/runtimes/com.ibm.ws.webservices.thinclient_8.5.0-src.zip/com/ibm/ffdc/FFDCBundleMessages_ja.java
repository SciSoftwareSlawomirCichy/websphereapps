package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_ja extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: FFDC フォーマッター {0} を追加しました"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: データベースを使用する分析エンジン: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: 分析エンジンを解決できませんでした:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: FFDC データ・コレクター {0} を追加しました"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: FFDC データ・コレクター {0} を削除しました"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: SystemErr についての FFDC 発生事象が送出されました: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC はフェイルセーフ・モードです。エラー {0} を確認してください"},
			{"FFDCForwarderAdded", "FFDC1013I: FFDC 発生事象フォワーダー {0} を追加しました"},
			{"FFDCForwarderRemoved", "FFDC1014I: FFDC 発生事象フォワーダー {0} を削除しました"},
			{"FFDCIncidentEmitted", "FFDC1003I: {0} {1} {2} についての FFDC 発生事象が送出されました"},
			{"FFDCProviderAborted", "FFDC1000I: FFDC プロバイダー {0} は異常終了しました。例外が続きます。"},
			{"FFDCProviderAbortedE", "FFDC1001I: FFDC プロバイダーは例外 {0} で異常終了しました"},
			{"FFDCProviderException", "FFDC1008I: FFDC プロバイダーの例外:"},
			{"FFDCProviderInstalled", "FFDC1007I: FFDC プロバイダーがインストールされました: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: FFDC フォーマッター {0} を削除しました"}};

	public Object[][] getContents() {
		return resources;
	}
}