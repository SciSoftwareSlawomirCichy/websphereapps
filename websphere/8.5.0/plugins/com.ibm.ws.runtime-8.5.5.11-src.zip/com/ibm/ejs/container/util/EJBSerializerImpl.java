package com.ibm.ejs.container.util;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSHome;
import com.ibm.ejs.container.EJSWrapperBase;
import com.ibm.ejs.container.EJSWrapperCommon;
import com.ibm.ejs.container.LocalBeanWrapper;
import com.ibm.ejs.container.LocalBeanWrapperProxy;
import com.ibm.ejs.container.WrapperId;
import com.ibm.ejs.container.WrapperInterface;
import com.ibm.ejs.container.WrapperManager;
import com.ibm.ejs.container.WrapperProxy;
import com.ibm.ejs.container.WrapperProxyState;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.util.EJBSerializer;
import com.ibm.ws.ejbcontainer.util.EJBSerializer.ObjectType;
import java.io.IOException;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.rmi.CORBA.Stub;

public class EJBSerializerImpl extends EJBSerializer {
	private static final String CLASS_NAME = EJBSerializerImpl.class.getName();
	private static final TraceComponent tc;

	public Object deserialize(byte[] idBytes) throws Exception {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "deserialize");
		}

		EJSContainer container = EJSContainer.getDefaultContainer();
		Object retObj = null;
		WrapperManager wm = container.getWrapperManager();
		if (idBytes[0] == -84) {
			ByteArray byteArray = new ByteArray(idBytes);
			BeanId beanId = BeanId.getBeanId(byteArray, container);
			retObj = wm.getWrapper(beanId).getLocalObject();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "deserialized a BeanId = " + beanId + ", component wrapper = " + retObj);
			}
		} else {
			if (idBytes[0] != -83) {
				throw new IOException("First byte of header not recognized");
			}

			WrapperId wrapperId = new WrapperId(idBytes);
			int index = wrapperId.ivInterfaceIndex;
			String interfaceName = wrapperId.ivInterfaceClassName;
			ByteArray byteArray = wrapperId.getBeanIdArray();
			BeanId beanId = BeanId.getBeanId(byteArray, container);
			BeanMetaData bmd = beanId.getBeanMetaData();
			Tr.debug(tc,
					"deserialized a WrapperId for BeanId = " + beanId + ", primary key = " + beanId.getPrimaryKey());
			if (index == -2) {
				EJSHome home = bmd.getHome();
				EJSWrapperCommon wc = home.internalCreateWrapper(beanId);
				retObj = wc.getAggregateLocalWrapper(home);
			} else {
				Class<?>[] bInterfaces = bmd.ivBusinessLocalInterfaceClasses;
				int numberOfLocalInterfaces = bInterfaces.length;
				String wrapperInterfaceName = null;
				if (index < numberOfLocalInterfaces) {
					wrapperInterfaceName = bInterfaces[index].getName();
				}

				if (wrapperInterfaceName == null || !wrapperInterfaceName.equals(interfaceName)) {
					index = bmd.getRequiredLocalBusinessInterfaceIndex(interfaceName);
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "deserialized a BusinessLocalWrapper, WrapperId = " + wrapperId);
				}

				EJSHome home = bmd.getHome();
				EJSWrapperCommon wc = home.internalCreateWrapper(beanId);
				retObj = wc.getLocalBusinessObject(index);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "deserialize returning: " + retObj);
		}

		return retObj;
	}

	public ObjectType getObjectType(Object theObject) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getObjectType: " + theObject.getClass());
		}

		ObjectType objectType = ObjectType.NOT_AN_EJB;
		if (theObject instanceof Stub) {
			if (theObject instanceof EJBObject) {
				objectType = ObjectType.EJB_OBJECT;
			} else if (theObject instanceof EJBHome) {
				objectType = ObjectType.EJB_HOME;
			} else {
				objectType = ObjectType.CORBA_STUB;
			}
		} else if (theObject instanceof WrapperProxy) {
			if (theObject instanceof LocalBeanWrapperProxy) {
				objectType = ObjectType.EJB_LOCAL_BEAN;
			} else {
				objectType = WrapperProxyState.getWrapperProxyState(theObject).getSerializerObjectType();
			}
		} else if (theObject instanceof EJSWrapperBase) {
			EJSWrapperBase wrapper = (EJSWrapperBase) theObject;
			WrapperInterface wInterface = wrapper.ivInterface;
			if (wInterface == WrapperInterface.BUSINESS_LOCAL) {
				objectType = ObjectType.EJB_BUSINESS_LOCAL;
			} else if (wInterface == WrapperInterface.LOCAL) {
				objectType = ObjectType.EJB_LOCAL_OBJECT;
			} else if (wInterface == WrapperInterface.LOCAL_HOME) {
				objectType = ObjectType.EJB_LOCAL_HOME;
			} else if (wInterface == WrapperInterface.BUSINESS_REMOTE) {
				objectType = ObjectType.EJB3_BUSINESS_REMOTE;
			} else if (wInterface == WrapperInterface.BUSINESS_RMI_REMOTE) {
				objectType = ObjectType.EJB3_BUSINESS_REMOTE;
			}
		} else if (theObject instanceof LocalBeanWrapper) {
			objectType = ObjectType.EJB_LOCAL_BEAN;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "ObjectType = " + objectType);
		}

		return objectType;
	}

	public byte[] serialize(Object theObject) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "serialize = " + theObject.getClass());
		}

		byte[] idBytes = null;
		WrapperProxyState state;
		byte[] idBytes;
		if (theObject instanceof WrapperProxy) {
			state = WrapperProxyState.getWrapperProxyState(theObject);
			idBytes = state.getSerializerBytes();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "serialized a WrapperProxy for " + state);
			}
		} else {
			state = null;
			EJSWrapperBase wrapper;
			if (theObject instanceof EJSWrapperBase) {
				wrapper = (EJSWrapperBase) theObject;
			} else {
				if (!(theObject instanceof LocalBeanWrapper)) {
					throw new IllegalArgumentException(
							" theObject parameter must be a EJB_LOCAL, EJB_LOCAL_HOME, EJB_BUSINESS_LOCAL, or EJB_BUSINESS_REMOTE ObjectType. Use the getObjectType to obtain the ObjectType.");
				}

				wrapper = EJSWrapperCommon.getLocalBeanWrapperBase(theObject);
			}

			BeanId beanId = wrapper.beanId;
			WrapperInterface wrapperInterface = wrapper.ivInterface;
			BeanMetaData bmd = wrapper.bmd;
			int interfaceIndex;
			if (wrapperInterface == WrapperInterface.BUSINESS_LOCAL) {
				interfaceIndex = wrapper.ivBusinessInterfaceIndex;
				String interfaceName;
				if (interfaceIndex == -2) {
					interfaceName = "AGGREGATE";
				} else {
					Class<?> biClass = bmd.ivBusinessLocalInterfaceClasses[interfaceIndex];
					interfaceName = biClass.getName();
				}

				WrapperId wrapperId = new WrapperId(beanId.getByteArrayBytes(), interfaceName, interfaceIndex);
				idBytes = wrapperId.getBytes();
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "serialized a WrapperId for BeanId = " + beanId + ", local business interface = "
							+ interfaceName);
				}
			} else {
				WrapperId wrapperId;
				Class biClass;
				String interfaceName;
				if (wrapperInterface == WrapperInterface.BUSINESS_REMOTE) {
					interfaceIndex = wrapper.ivBusinessInterfaceIndex;
					biClass = bmd.ivBusinessRemoteInterfaceClasses[interfaceIndex];
					interfaceName = biClass.getName();
					wrapperId = new WrapperId(beanId.getByteArrayBytes(), interfaceName, interfaceIndex);
					idBytes = wrapperId.getBytes();
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "serialized a WrapperId for BeanId = " + beanId + ", remote business interface = "
								+ interfaceName);
					}
				} else if (wrapperInterface == WrapperInterface.BUSINESS_RMI_REMOTE) {
					interfaceIndex = wrapper.ivBusinessInterfaceIndex;
					biClass = bmd.ivBusinessRemoteInterfaceClasses[interfaceIndex];
					interfaceName = biClass.getName();
					wrapperId = new WrapperId(beanId.getByteArrayBytes(), interfaceName, interfaceIndex);
					idBytes = wrapperId.getBytes();
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "serialized a WrapperId for BeanId = " + beanId
								+ ", RMI remote business interface = " + interfaceName);
					}
				} else {
					idBytes = beanId.getByteArrayBytes();
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "serialized a BeanId = " + beanId);
					}
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "serialize");
		}

		return idBytes;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}