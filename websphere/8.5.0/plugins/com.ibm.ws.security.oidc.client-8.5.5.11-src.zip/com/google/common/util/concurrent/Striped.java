package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.base.Functions;
import com.google.common.base.Preconditions;
import com.google.common.base.Supplier;
import com.google.common.collect.Iterables;
import com.google.common.collect.MapMaker;
import com.google.common.math.IntMath;
import com.google.common.util.concurrent.Striped.1;
import com.google.common.util.concurrent.Striped.2;
import com.google.common.util.concurrent.Striped.3;
import com.google.common.util.concurrent.Striped.4;
import com.google.common.util.concurrent.Striped.5;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;

@Beta
public abstract class Striped<L> {
	private static final Supplier<ReadWriteLock> READ_WRITE_LOCK_SUPPLIER = new 5();
	private static final int ALL_SET = -1;

	private Striped() {
	}

	public abstract L get(Object var1);

	public abstract L getAt(int var1);

	abstract int indexFor(Object var1);

	public abstract int size();

	public Iterable<L> bulkGet(Iterable<?> keys) {
		Object[] array = Iterables.toArray(keys, Object.class);
		int[] stripes = new int[array.length];

		int i;
		for (i = 0; i < array.length; ++i) {
			stripes[i] = this.indexFor(array[i]);
		}

		Arrays.sort(stripes);

		for (i = 0; i < array.length; ++i) {
			array[i] = this.getAt(stripes[i]);
		}

		List<L> asList = Arrays.asList(array);
		return Collections.unmodifiableList(asList);
	}

	public static Striped<Lock> lock(int stripes) {
      return new Striped.CompactStriped(stripes, new 1(), (1)null);
   }

	public static Striped<Lock> lazyWeakLock(int stripes) {
      return new Striped.LazyStriped(stripes, new 2());
   }

	public static Striped<Semaphore> semaphore(int stripes, int permits) {
      return new Striped.CompactStriped(stripes, new 3(permits), (1)null);
   }

	public static Striped<Semaphore> lazyWeakSemaphore(int stripes, int permits) {
      return new Striped.LazyStriped(stripes, new 4(permits));
   }

	public static Striped<ReadWriteLock> readWriteLock(int stripes) {
      return new Striped.CompactStriped(stripes, READ_WRITE_LOCK_SUPPLIER, (1)null);
   }

	public static Striped<ReadWriteLock> lazyWeakReadWriteLock(int stripes) {
		return new Striped.LazyStriped(stripes, READ_WRITE_LOCK_SUPPLIER);
	}

	private static int ceilToPowerOfTwo(int x) {
		return 1 << IntMath.log2(x, RoundingMode.CEILING);
	}

	private static int smear(int hashCode) {
		hashCode ^= hashCode >>> 20 ^ hashCode >>> 12;
		return hashCode ^ hashCode >>> 7 ^ hashCode >>> 4;
	}

	private static class LazyStriped<L> extends Striped.PowerOfTwoStriped<L> {
		final ConcurrentMap<Integer, L> cache;
		final int size;

		LazyStriped(int stripes, Supplier<L> supplier) {
			super(stripes);
			this.size = this.mask == -1 ? Integer.MAX_VALUE : this.mask + 1;
			this.cache = (new MapMaker()).weakValues().makeComputingMap(Functions.forSupplier(supplier));
		}

		public L getAt(int index) {
			Preconditions.checkElementIndex(index, this.size());
			return this.cache.get(index);
		}

		public int size() {
			return this.size;
		}
	}

	private static class CompactStriped<L> extends Striped.PowerOfTwoStriped<L> {
		private final Object[] array;

		private CompactStriped(int stripes, Supplier<L> supplier) {
			super(stripes);
			Preconditions.checkArgument(stripes <= 1073741824, "Stripes must be <= 2^30)");
			this.array = new Object[this.mask + 1];

			for (int i = 0; i < this.array.length; ++i) {
				this.array[i] = supplier.get();
			}

		}

		public L getAt(int index) {
			return this.array[index];
		}

		public int size() {
			return this.array.length;
		}
	}

	private abstract static class PowerOfTwoStriped<L> extends Striped<L> {
		final int mask;

		PowerOfTwoStriped(int stripes) {
         super((1)null);
         Preconditions.checkArgument(stripes > 0, "Stripes must be positive");
         this.mask = stripes > 1073741824 ? -1 : Striped.ceilToPowerOfTwo(stripes) - 1;
      }

		final int indexFor(Object key) {
			int hash = Striped.smear(key.hashCode());
			return hash & this.mask;
		}

		public final L get(Object key) {
			return this.getAt(this.indexFor(key));
		}
	}
}