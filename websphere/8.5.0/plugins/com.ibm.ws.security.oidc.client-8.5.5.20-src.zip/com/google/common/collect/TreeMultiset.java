package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.MoreObjects;
import com.google.common.base.Preconditions;
import com.google.common.primitives.Ints;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
public final class TreeMultiset<E> extends AbstractSortedMultiset<E> implements Serializable {
	private final transient Reference<AvlNode<E>> rootReference;
	private final transient GeneralRange<E> range;
	private final transient AvlNode<E> header;
	@GwtIncompatible
	private static final long serialVersionUID = 1L;

	public static <E extends Comparable> TreeMultiset<E> create() {
		return new TreeMultiset(Ordering.natural());
	}

	public static <E> TreeMultiset<E> create(@NullableDecl Comparator<? super E> comparator) {
		return comparator == null ? new TreeMultiset(Ordering.natural()) : new TreeMultiset(comparator);
	}

	public static <E extends Comparable> TreeMultiset<E> create(Iterable<? extends E> elements) {
		TreeMultiset<E> multiset = create();
		Iterables.addAll(multiset, elements);
		return multiset;
	}

	TreeMultiset(Reference<AvlNode<E>> rootReference, GeneralRange<E> range, AvlNode<E> endLink) {
		super(range.comparator());
		this.rootReference = rootReference;
		this.range = range;
		this.header = endLink;
	}

	TreeMultiset(Comparator<? super E> comparator) {
		super(comparator);
		this.range = GeneralRange.all(comparator);
		this.header = new AvlNode((Object) null, 1);
		successor(this.header, this.header);
		this.rootReference = new Reference();
	}

	private long aggregateForEntries(Aggregate aggr) {
		AvlNode<E> root = (AvlNode) this.rootReference.get();
		long total = aggr.treeAggregate(root);
		if (this.range.hasLowerBound()) {
			total -= this.aggregateBelowRange(aggr, root);
		}

		if (this.range.hasUpperBound()) {
			total -= this.aggregateAboveRange(aggr, root);
		}

		return total;
	}

	private long aggregateBelowRange(Aggregate aggr, @NullableDecl AvlNode<E> node) {
		if (node == null) {
			return 0L;
		} else {
			int cmp = this.comparator().compare(this.range.getLowerEndpoint(), node.elem);
			if (cmp < 0) {
				return this.aggregateBelowRange(aggr, node.left);
			} else if (cmp == 0) {
				switch (this.range.getLowerBoundType()) {
					case OPEN :
						return (long) aggr.nodeAggregate(node) + aggr.treeAggregate(node.left);
					case CLOSED :
						return aggr.treeAggregate(node.left);
					default :
						throw new AssertionError();
				}
			} else {
				return aggr.treeAggregate(node.left) + (long) aggr.nodeAggregate(node)
						+ this.aggregateBelowRange(aggr, node.right);
			}
		}
	}

	private long aggregateAboveRange(Aggregate aggr, @NullableDecl AvlNode<E> node) {
		if (node == null) {
			return 0L;
		} else {
			int cmp = this.comparator().compare(this.range.getUpperEndpoint(), node.elem);
			if (cmp > 0) {
				return this.aggregateAboveRange(aggr, node.right);
			} else if (cmp == 0) {
				switch (this.range.getUpperBoundType()) {
					case OPEN :
						return (long) aggr.nodeAggregate(node) + aggr.treeAggregate(node.right);
					case CLOSED :
						return aggr.treeAggregate(node.right);
					default :
						throw new AssertionError();
				}
			} else {
				return aggr.treeAggregate(node.right) + (long) aggr.nodeAggregate(node)
						+ this.aggregateAboveRange(aggr, node.left);
			}
		}
	}

	public int size() {
		return Ints.saturatedCast(this.aggregateForEntries(TreeMultiset.Aggregate.SIZE));
	}

	int distinctElements() {
		return Ints.saturatedCast(this.aggregateForEntries(TreeMultiset.Aggregate.DISTINCT));
	}

	static int distinctElements(@NullableDecl AvlNode<?> node) {
		return node == null ? 0 : node.distinctElements;
	}

	public int count(@NullableDecl Object element) {
		try {
			AvlNode<E> root = (AvlNode) this.rootReference.get();
			return this.range.contains(element) && root != null ? root.count(this.comparator(), element) : 0;
		} catch (NullPointerException | ClassCastException var4) {
			return 0;
		}
	}

	@CanIgnoreReturnValue
	public int add(@NullableDecl E element, int occurrences) {
		CollectPreconditions.checkNonnegative(occurrences, "occurrences");
		if (occurrences == 0) {
			return this.count(element);
		} else {
			Preconditions.checkArgument(this.range.contains(element));
			AvlNode<E> root = (AvlNode) this.rootReference.get();
			if (root == null) {
				this.comparator().compare(element, element);
				AvlNode<E> newRoot = new AvlNode(element, occurrences);
				successor(this.header, newRoot, this.header);
				this.rootReference.checkAndSet(root, newRoot);
				return 0;
			} else {
				int[] result = new int[1];
				AvlNode<E> newRoot = root.add(this.comparator(), element, occurrences, result);
				this.rootReference.checkAndSet(root, newRoot);
				return result[0];
			}
		}
	}

	@CanIgnoreReturnValue
	public int remove(@NullableDecl Object element, int occurrences) {
		CollectPreconditions.checkNonnegative(occurrences, "occurrences");
		if (occurrences == 0) {
			return this.count(element);
		} else {
			AvlNode<E> root = (AvlNode) this.rootReference.get();
			int[] result = new int[1];

			AvlNode newRoot;
			try {
				if (!this.range.contains(element) || root == null) {
					return 0;
				}

				newRoot = root.remove(this.comparator(), element, occurrences, result);
			} catch (NullPointerException | ClassCastException var7) {
				return 0;
			}

			this.rootReference.checkAndSet(root, newRoot);
			return result[0];
		}
	}

	@CanIgnoreReturnValue
	public int setCount(@NullableDecl E element, int count) {
		CollectPreconditions.checkNonnegative(count, "count");
		if (!this.range.contains(element)) {
			Preconditions.checkArgument(count == 0);
			return 0;
		} else {
			AvlNode<E> root = (AvlNode) this.rootReference.get();
			if (root == null) {
				if (count > 0) {
					this.add(element, count);
				}

				return 0;
			} else {
				int[] result = new int[1];
				AvlNode<E> newRoot = root.setCount(this.comparator(), element, count, result);
				this.rootReference.checkAndSet(root, newRoot);
				return result[0];
			}
		}
	}

	@CanIgnoreReturnValue
	public boolean setCount(@NullableDecl E element, int oldCount, int newCount) {
		CollectPreconditions.checkNonnegative(newCount, "newCount");
		CollectPreconditions.checkNonnegative(oldCount, "oldCount");
		Preconditions.checkArgument(this.range.contains(element));
		AvlNode<E> root = (AvlNode) this.rootReference.get();
		if (root == null) {
			if (oldCount == 0) {
				if (newCount > 0) {
					this.add(element, newCount);
				}

				return true;
			} else {
				return false;
			}
		} else {
			int[] result = new int[1];
			AvlNode<E> newRoot = root.setCount(this.comparator(), element, oldCount, newCount, result);
			this.rootReference.checkAndSet(root, newRoot);
			return result[0] == oldCount;
		}
	}

	public void clear() {
		if (!this.range.hasLowerBound() && !this.range.hasUpperBound()) {
			AvlNode next;
			for (AvlNode<E> current = this.header.succ; current != this.header; current = next) {
				next = current.succ;
				current.elemCount = 0;
				current.left = null;
				current.right = null;
				current.pred = null;
				current.succ = null;
			}

			successor(this.header, this.header);
			this.rootReference.clear();
		} else {
			Iterators.clear(this.entryIterator());
		}

	}

	private Multiset.Entry<E> wrapEntry(final AvlNode<E> baseEntry) {
		return new Multisets.AbstractEntry<E>() {
			public E getElement() {
				return baseEntry.getElement();
			}

			public int getCount() {
				int result = baseEntry.getCount();
				return result == 0 ? TreeMultiset.this.count(this.getElement()) : result;
			}
		};
	}

	@NullableDecl
	private AvlNode<E> firstNode() {
		AvlNode<E> root = (AvlNode) this.rootReference.get();
		if (root == null) {
			return null;
		} else {
			AvlNode node;
			if (this.range.hasLowerBound()) {
				E endpoint = this.range.getLowerEndpoint();
				node = ((AvlNode) this.rootReference.get()).ceiling(this.comparator(), endpoint);
				if (node == null) {
					return null;
				}

				if (this.range.getLowerBoundType() == BoundType.OPEN
						&& this.comparator().compare(endpoint, node.getElement()) == 0) {
					node = node.succ;
				}
			} else {
				node = this.header.succ;
			}

			return node != this.header && this.range.contains(node.getElement()) ? node : null;
		}
	}

	@NullableDecl
	private AvlNode<E> lastNode() {
		AvlNode<E> root = (AvlNode) this.rootReference.get();
		if (root == null) {
			return null;
		} else {
			AvlNode node;
			if (this.range.hasUpperBound()) {
				E endpoint = this.range.getUpperEndpoint();
				node = ((AvlNode) this.rootReference.get()).floor(this.comparator(), endpoint);
				if (node == null) {
					return null;
				}

				if (this.range.getUpperBoundType() == BoundType.OPEN
						&& this.comparator().compare(endpoint, node.getElement()) == 0) {
					node = node.pred;
				}
			} else {
				node = this.header.pred;
			}

			return node != this.header && this.range.contains(node.getElement()) ? node : null;
		}
	}

	Iterator<E> elementIterator() {
		return Multisets.elementIterator(this.entryIterator());
	}

	Iterator<Multiset.Entry<E>> entryIterator() {
		return new Iterator<Multiset.Entry<E>>() {
			AvlNode<E> current = TreeMultiset.this.firstNode();
			@NullableDecl
			Multiset.Entry<E> prevEntry;

			public boolean hasNext() {
				if (this.current == null) {
					return false;
				} else if (TreeMultiset.this.range.tooHigh(this.current.getElement())) {
					this.current = null;
					return false;
				} else {
					return true;
				}
			}

			public Multiset.Entry<E> next() {
				if (!this.hasNext()) {
					throw new NoSuchElementException();
				} else {
					Multiset.Entry<E> result = TreeMultiset.this.wrapEntry(this.current);
					this.prevEntry = result;
					if (this.current.succ == TreeMultiset.this.header) {
						this.current = null;
					} else {
						this.current = this.current.succ;
					}

					return result;
				}
			}

			public void remove() {
				CollectPreconditions.checkRemove(this.prevEntry != null);
				TreeMultiset.this.setCount(this.prevEntry.getElement(), 0);
				this.prevEntry = null;
			}
		};
	}

	Iterator<Multiset.Entry<E>> descendingEntryIterator() {
		return new Iterator<Multiset.Entry<E>>() {
			AvlNode<E> current = TreeMultiset.this.lastNode();
			Multiset.Entry<E> prevEntry = null;

			public boolean hasNext() {
				if (this.current == null) {
					return false;
				} else if (TreeMultiset.this.range.tooLow(this.current.getElement())) {
					this.current = null;
					return false;
				} else {
					return true;
				}
			}

			public Multiset.Entry<E> next() {
				if (!this.hasNext()) {
					throw new NoSuchElementException();
				} else {
					Multiset.Entry<E> result = TreeMultiset.this.wrapEntry(this.current);
					this.prevEntry = result;
					if (this.current.pred == TreeMultiset.this.header) {
						this.current = null;
					} else {
						this.current = this.current.pred;
					}

					return result;
				}
			}

			public void remove() {
				CollectPreconditions.checkRemove(this.prevEntry != null);
				TreeMultiset.this.setCount(this.prevEntry.getElement(), 0);
				this.prevEntry = null;
			}
		};
	}

	public Iterator<E> iterator() {
		return Multisets.iteratorImpl(this);
	}

	public SortedMultiset<E> headMultiset(@NullableDecl E upperBound, BoundType boundType) {
		return new TreeMultiset(this.rootReference,
				this.range.intersect(GeneralRange.upTo(this.comparator(), upperBound, boundType)), this.header);
	}

	public SortedMultiset<E> tailMultiset(@NullableDecl E lowerBound, BoundType boundType) {
		return new TreeMultiset(this.rootReference,
				this.range.intersect(GeneralRange.downTo(this.comparator(), lowerBound, boundType)), this.header);
	}

	private static <T> void successor(AvlNode<T> a, AvlNode<T> b) {
		a.succ = b;
		b.pred = a;
	}

	private static <T> void successor(AvlNode<T> a, AvlNode<T> b, AvlNode<T> c) {
		successor(a, b);
		successor(b, c);
	}

	@GwtIncompatible
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		stream.writeObject(this.elementSet().comparator());
		Serialization.writeMultiset(this, stream);
	}

	@GwtIncompatible
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		Comparator<? super E> comparator = (Comparator) stream.readObject();
		Serialization.getFieldSetter(AbstractSortedMultiset.class, "comparator").set(this, comparator);
		Serialization.getFieldSetter(TreeMultiset.class, "range").set(this, GeneralRange.all(comparator));
		Serialization.getFieldSetter(TreeMultiset.class, "rootReference").set(this, new Reference());
		AvlNode<E> header = new AvlNode((Object) null, 1);
		Serialization.getFieldSetter(TreeMultiset.class, "header").set(this, header);
		successor(header, header);
		Serialization.populateMultiset(this, stream);
	}

	private static final class AvlNode<E> {
		@NullableDecl
		private final E elem;
		private int elemCount;
		private int distinctElements;
		private long totalCount;
		private int height;
		@NullableDecl
		private AvlNode<E> left;
		@NullableDecl
		private AvlNode<E> right;
		@NullableDecl
		private AvlNode<E> pred;
		@NullableDecl
		private AvlNode<E> succ;

		AvlNode(@NullableDecl E elem, int elemCount) {
			Preconditions.checkArgument(elemCount > 0);
			this.elem = elem;
			this.elemCount = elemCount;
			this.totalCount = (long) elemCount;
			this.distinctElements = 1;
			this.height = 1;
			this.left = null;
			this.right = null;
		}

		public int count(Comparator<? super E> comparator, E e) {
			int cmp = comparator.compare(e, this.elem);
			if (cmp < 0) {
				return this.left == null ? 0 : this.left.count(comparator, e);
			} else if (cmp > 0) {
				return this.right == null ? 0 : this.right.count(comparator, e);
			} else {
				return this.elemCount;
			}
		}

		private AvlNode<E> addRightChild(E e, int count) {
			this.right = new AvlNode(e, count);
			TreeMultiset.successor(this, this.right, this.succ);
			this.height = Math.max(2, this.height);
			++this.distinctElements;
			this.totalCount += (long) count;
			return this;
		}

		private AvlNode<E> addLeftChild(E e, int count) {
			this.left = new AvlNode(e, count);
			TreeMultiset.successor(this.pred, this.left, this);
			this.height = Math.max(2, this.height);
			++this.distinctElements;
			this.totalCount += (long) count;
			return this;
		}

		AvlNode<E> add(Comparator<? super E> comparator, @NullableDecl E e, int count, int[] result) {
			int cmp = comparator.compare(e, this.elem);
			int initHeight;
			AvlNode initRight;
			if (cmp < 0) {
				initRight = this.left;
				if (initRight == null) {
					result[0] = 0;
					return this.addLeftChild(e, count);
				} else {
					initHeight = initRight.height;
					this.left = initRight.add(comparator, e, count, result);
					if (result[0] == 0) {
						++this.distinctElements;
					}

					this.totalCount += (long) count;
					return this.left.height == initHeight ? this : this.rebalance();
				}
			} else if (cmp > 0) {
				initRight = this.right;
				if (initRight == null) {
					result[0] = 0;
					return this.addRightChild(e, count);
				} else {
					initHeight = initRight.height;
					this.right = initRight.add(comparator, e, count, result);
					if (result[0] == 0) {
						++this.distinctElements;
					}

					this.totalCount += (long) count;
					return this.right.height == initHeight ? this : this.rebalance();
				}
			} else {
				result[0] = this.elemCount;
				long resultCount = (long) this.elemCount + (long) count;
				Preconditions.checkArgument(resultCount <= 2147483647L);
				this.elemCount += count;
				this.totalCount += (long) count;
				return this;
			}
		}

		AvlNode<E> remove(Comparator<? super E> comparator, @NullableDecl E e, int count, int[] result) {
			int cmp = comparator.compare(e, this.elem);
			AvlNode initRight;
			if (cmp < 0) {
				initRight = this.left;
				if (initRight == null) {
					result[0] = 0;
					return this;
				} else {
					this.left = initRight.remove(comparator, e, count, result);
					if (result[0] > 0) {
						if (count >= result[0]) {
							--this.distinctElements;
							this.totalCount -= (long) result[0];
						} else {
							this.totalCount -= (long) count;
						}
					}

					return result[0] == 0 ? this : this.rebalance();
				}
			} else if (cmp > 0) {
				initRight = this.right;
				if (initRight == null) {
					result[0] = 0;
					return this;
				} else {
					this.right = initRight.remove(comparator, e, count, result);
					if (result[0] > 0) {
						if (count >= result[0]) {
							--this.distinctElements;
							this.totalCount -= (long) result[0];
						} else {
							this.totalCount -= (long) count;
						}
					}

					return this.rebalance();
				}
			} else {
				result[0] = this.elemCount;
				if (count >= this.elemCount) {
					return this.deleteMe();
				} else {
					this.elemCount -= count;
					this.totalCount -= (long) count;
					return this;
				}
			}
		}

		AvlNode<E> setCount(Comparator<? super E> comparator, @NullableDecl E e, int count, int[] result) {
			int cmp = comparator.compare(e, this.elem);
			AvlNode initRight;
			if (cmp < 0) {
				initRight = this.left;
				if (initRight == null) {
					result[0] = 0;
					return count > 0 ? this.addLeftChild(e, count) : this;
				} else {
					this.left = initRight.setCount(comparator, e, count, result);
					if (count == 0 && result[0] != 0) {
						--this.distinctElements;
					} else if (count > 0 && result[0] == 0) {
						++this.distinctElements;
					}

					this.totalCount += (long) (count - result[0]);
					return this.rebalance();
				}
			} else if (cmp > 0) {
				initRight = this.right;
				if (initRight == null) {
					result[0] = 0;
					return count > 0 ? this.addRightChild(e, count) : this;
				} else {
					this.right = initRight.setCount(comparator, e, count, result);
					if (count == 0 && result[0] != 0) {
						--this.distinctElements;
					} else if (count > 0 && result[0] == 0) {
						++this.distinctElements;
					}

					this.totalCount += (long) (count - result[0]);
					return this.rebalance();
				}
			} else {
				result[0] = this.elemCount;
				if (count == 0) {
					return this.deleteMe();
				} else {
					this.totalCount += (long) (count - this.elemCount);
					this.elemCount = count;
					return this;
				}
			}
		}

		AvlNode<E> setCount(Comparator<? super E> comparator, @NullableDecl E e, int expectedCount, int newCount,
				int[] result) {
			int cmp = comparator.compare(e, this.elem);
			AvlNode initRight;
			if (cmp < 0) {
				initRight = this.left;
				if (initRight == null) {
					result[0] = 0;
					return expectedCount == 0 && newCount > 0 ? this.addLeftChild(e, newCount) : this;
				} else {
					this.left = initRight.setCount(comparator, e, expectedCount, newCount, result);
					if (result[0] == expectedCount) {
						if (newCount == 0 && result[0] != 0) {
							--this.distinctElements;
						} else if (newCount > 0 && result[0] == 0) {
							++this.distinctElements;
						}

						this.totalCount += (long) (newCount - result[0]);
					}

					return this.rebalance();
				}
			} else if (cmp > 0) {
				initRight = this.right;
				if (initRight == null) {
					result[0] = 0;
					return expectedCount == 0 && newCount > 0 ? this.addRightChild(e, newCount) : this;
				} else {
					this.right = initRight.setCount(comparator, e, expectedCount, newCount, result);
					if (result[0] == expectedCount) {
						if (newCount == 0 && result[0] != 0) {
							--this.distinctElements;
						} else if (newCount > 0 && result[0] == 0) {
							++this.distinctElements;
						}

						this.totalCount += (long) (newCount - result[0]);
					}

					return this.rebalance();
				}
			} else {
				result[0] = this.elemCount;
				if (expectedCount == this.elemCount) {
					if (newCount == 0) {
						return this.deleteMe();
					}

					this.totalCount += (long) (newCount - this.elemCount);
					this.elemCount = newCount;
				}

				return this;
			}
		}

		private AvlNode<E> deleteMe() {
			int oldElemCount = this.elemCount;
			this.elemCount = 0;
			TreeMultiset.successor(this.pred, this.succ);
			if (this.left == null) {
				return this.right;
			} else if (this.right == null) {
				return this.left;
			} else {
				AvlNode newTop;
				if (this.left.height >= this.right.height) {
					newTop = this.pred;
					newTop.left = this.left.removeMax(newTop);
					newTop.right = this.right;
					newTop.distinctElements = this.distinctElements - 1;
					newTop.totalCount = this.totalCount - (long) oldElemCount;
					return newTop.rebalance();
				} else {
					newTop = this.succ;
					newTop.right = this.right.removeMin(newTop);
					newTop.left = this.left;
					newTop.distinctElements = this.distinctElements - 1;
					newTop.totalCount = this.totalCount - (long) oldElemCount;
					return newTop.rebalance();
				}
			}
		}

		private AvlNode<E> removeMin(AvlNode<E> node) {
			if (this.left == null) {
				return this.right;
			} else {
				this.left = this.left.removeMin(node);
				--this.distinctElements;
				this.totalCount -= (long) node.elemCount;
				return this.rebalance();
			}
		}

		private AvlNode<E> removeMax(AvlNode<E> node) {
			if (this.right == null) {
				return this.left;
			} else {
				this.right = this.right.removeMax(node);
				--this.distinctElements;
				this.totalCount -= (long) node.elemCount;
				return this.rebalance();
			}
		}

		private void recomputeMultiset() {
			this.distinctElements = 1 + TreeMultiset.distinctElements(this.left)
					+ TreeMultiset.distinctElements(this.right);
			this.totalCount = (long) this.elemCount + totalCount(this.left) + totalCount(this.right);
		}

		private void recomputeHeight() {
			this.height = 1 + Math.max(height(this.left), height(this.right));
		}

		private void recompute() {
			this.recomputeMultiset();
			this.recomputeHeight();
		}

		private AvlNode<E> rebalance() {
			switch (this.balanceFactor()) {
				case -2 :
					if (this.right.balanceFactor() > 0) {
						this.right = this.right.rotateRight();
					}

					return this.rotateLeft();
				case 2 :
					if (this.left.balanceFactor() < 0) {
						this.left = this.left.rotateLeft();
					}

					return this.rotateRight();
				default :
					this.recomputeHeight();
					return this;
			}
		}

		private int balanceFactor() {
			return height(this.left) - height(this.right);
		}

		private AvlNode<E> rotateLeft() {
			Preconditions.checkState(this.right != null);
			AvlNode<E> newTop = this.right;
			this.right = newTop.left;
			newTop.left = this;
			newTop.totalCount = this.totalCount;
			newTop.distinctElements = this.distinctElements;
			this.recompute();
			newTop.recomputeHeight();
			return newTop;
		}

		private AvlNode<E> rotateRight() {
			Preconditions.checkState(this.left != null);
			AvlNode<E> newTop = this.left;
			this.left = newTop.right;
			newTop.right = this;
			newTop.totalCount = this.totalCount;
			newTop.distinctElements = this.distinctElements;
			this.recompute();
			newTop.recomputeHeight();
			return newTop;
		}

		private static long totalCount(@NullableDecl AvlNode<?> node) {
			return node == null ? 0L : node.totalCount;
		}

		private static int height(@NullableDecl AvlNode<?> node) {
			return node == null ? 0 : node.height;
		}

		@NullableDecl
		private AvlNode<E> ceiling(Comparator<? super E> comparator, E e) {
			int cmp = comparator.compare(e, this.elem);
			if (cmp < 0) {
				return this.left == null
						? this
						: (AvlNode) MoreObjects.firstNonNull(this.left.ceiling(comparator, e), this);
			} else if (cmp == 0) {
				return this;
			} else {
				return this.right == null ? null : this.right.ceiling(comparator, e);
			}
		}

		@NullableDecl
		private AvlNode<E> floor(Comparator<? super E> comparator, E e) {
			int cmp = comparator.compare(e, this.elem);
			if (cmp > 0) {
				return this.right == null
						? this
						: (AvlNode) MoreObjects.firstNonNull(this.right.floor(comparator, e), this);
			} else if (cmp == 0) {
				return this;
			} else {
				return this.left == null ? null : this.left.floor(comparator, e);
			}
		}

		E getElement() {
			return this.elem;
		}

		int getCount() {
			return this.elemCount;
		}

		public String toString() {
			return Multisets.immutableEntry(this.getElement(), this.getCount()).toString();
		}
	}

	private static final class Reference<T> {
		@NullableDecl
		private T value;

		private Reference() {
		}

		@NullableDecl
		public T get() {
			return this.value;
		}

		public void checkAndSet(@NullableDecl T expected, T newValue) {
			if (this.value != expected) {
				throw new ConcurrentModificationException();
			} else {
				this.value = newValue;
			}
		}

		void clear() {
			this.value = null;
		}
	}

	private static enum Aggregate {
		SIZE {
			int nodeAggregate(AvlNode<?> node) {
				return node.elemCount;
			}

			long treeAggregate(@NullableDecl AvlNode<?> root) {
				return root == null ? 0L : root.totalCount;
			}
		},
		DISTINCT {
			int nodeAggregate(AvlNode<?> node) {
				return 1;
			}

			long treeAggregate(@NullableDecl AvlNode<?> root) {
				return root == null ? 0L : (long) root.distinctElements;
			}
		};

		private Aggregate() {
		}

		abstract int nodeAggregate(AvlNode<?> var1);

		abstract long treeAggregate(@NullableDecl AvlNode<?> var1);
	}
}