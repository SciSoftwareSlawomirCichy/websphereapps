package com.ibm.ejs.container;

public class UnknownBeanAssociationException extends ContainerException {
	private static final long serialVersionUID = 7877119018214074490L;

	public UnknownBeanAssociationException(String s) {
		super(s);
	}
}