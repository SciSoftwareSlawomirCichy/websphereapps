package com.google.common.primitives;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.primitives.UnsignedBytes.LexicographicalComparatorHolder;
import com.google.common.primitives.UnsignedBytes.LexicographicalComparatorHolder.PureJavaComparator;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Arrays;
import java.util.Comparator;

@GwtIncompatible
public final class UnsignedBytes {
	public static final byte MAX_POWER_OF_TWO = -128;
	public static final byte MAX_VALUE = -1;
	private static final int UNSIGNED_MASK = 255;

	public static int toInt(byte value) {
		return value & 255;
	}

	@CanIgnoreReturnValue
	public static byte checkedCast(long value) {
		Preconditions.checkArgument(value >> 8 == 0L, "out of range: %s", value);
		return (byte) ((int) value);
	}

	public static byte saturatedCast(long value) {
		if (value > (long) toInt((byte) -1)) {
			return -1;
		} else {
			return value < 0L ? 0 : (byte) ((int) value);
		}
	}

	public static int compare(byte a, byte b) {
		return toInt(a) - toInt(b);
	}

	public static byte min(byte... array) {
		Preconditions.checkArgument(array.length > 0);
		int min = toInt(array[0]);

		for (int i = 1; i < array.length; ++i) {
			int next = toInt(array[i]);
			if (next < min) {
				min = next;
			}
		}

		return (byte) min;
	}

	public static byte max(byte... array) {
		Preconditions.checkArgument(array.length > 0);
		int max = toInt(array[0]);

		for (int i = 1; i < array.length; ++i) {
			int next = toInt(array[i]);
			if (next > max) {
				max = next;
			}
		}

		return (byte) max;
	}

	@Beta
	public static String toString(byte x) {
		return toString(x, 10);
	}

	@Beta
	public static String toString(byte x, int radix) {
		Preconditions.checkArgument(radix >= 2 && radix <= 36,
				"radix (%s) must be between Character.MIN_RADIX and Character.MAX_RADIX", radix);
		return Integer.toString(toInt(x), radix);
	}

	@Beta
	@CanIgnoreReturnValue
	public static byte parseUnsignedByte(String string) {
		return parseUnsignedByte(string, 10);
	}

	@Beta
	@CanIgnoreReturnValue
	public static byte parseUnsignedByte(String string, int radix) {
		int parse = Integer.parseInt((String) Preconditions.checkNotNull(string), radix);
		if (parse >> 8 == 0) {
			return (byte) parse;
		} else {
			throw new NumberFormatException("out of range: " + parse);
		}
	}

	public static String join(String separator, byte... array) {
		Preconditions.checkNotNull(separator);
		if (array.length == 0) {
			return "";
		} else {
			StringBuilder builder = new StringBuilder(array.length * (3 + separator.length()));
			builder.append(toInt(array[0]));

			for (int i = 1; i < array.length; ++i) {
				builder.append(separator).append(toString(array[i]));
			}

			return builder.toString();
		}
	}

	public static Comparator<byte[]> lexicographicalComparator() {
		return LexicographicalComparatorHolder.BEST_COMPARATOR;
	}

	@VisibleForTesting
	static Comparator<byte[]> lexicographicalComparatorJavaImpl() {
		return PureJavaComparator.INSTANCE;
	}

	private static byte flip(byte b) {
		return (byte) (b ^ 128);
	}

	public static void sort(byte[] array) {
		Preconditions.checkNotNull(array);
		sort(array, 0, array.length);
	}

	public static void sort(byte[] array, int fromIndex, int toIndex) {
		Preconditions.checkNotNull(array);
		Preconditions.checkPositionIndexes(fromIndex, toIndex, array.length);

		int i;
		for (i = fromIndex; i < toIndex; ++i) {
			array[i] = flip(array[i]);
		}

		Arrays.sort(array, fromIndex, toIndex);

		for (i = fromIndex; i < toIndex; ++i) {
			array[i] = flip(array[i]);
		}

	}

	public static void sortDescending(byte[] array) {
		Preconditions.checkNotNull(array);
		sortDescending(array, 0, array.length);
	}

	public static void sortDescending(byte[] array, int fromIndex, int toIndex) {
		Preconditions.checkNotNull(array);
		Preconditions.checkPositionIndexes(fromIndex, toIndex, array.length);

		int i;
		for (i = fromIndex; i < toIndex; ++i) {
			array[i] = (byte) (array[i] ^ 127);
		}

		Arrays.sort(array, fromIndex, toIndex);

		for (i = fromIndex; i < toIndex; ++i) {
			array[i] = (byte) (array[i] ^ 127);
		}

	}
}