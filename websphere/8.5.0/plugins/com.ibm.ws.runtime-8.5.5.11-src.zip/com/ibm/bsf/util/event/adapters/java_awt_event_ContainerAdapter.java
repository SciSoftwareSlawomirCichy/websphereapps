package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;

public class java_awt_event_ContainerAdapter extends EventAdapterImpl implements ContainerListener {
	public void componentAdded(ContainerEvent var1) {
		this.eventProcessor.processEvent("componentAdded", new Object[]{var1});
	}

	public void componentRemoved(ContainerEvent var1) {
		this.eventProcessor.processEvent("componentRemoved", new Object[]{var1});
	}
}