package com.google.common.io;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.io.GwtWorkarounds.1;
import com.google.common.io.GwtWorkarounds.2;
import com.google.common.io.GwtWorkarounds.3;
import com.google.common.io.GwtWorkarounds.4;
import com.google.common.io.GwtWorkarounds.5;
import com.google.common.io.GwtWorkarounds.6;
import com.google.common.io.GwtWorkarounds.ByteInput;
import com.google.common.io.GwtWorkarounds.ByteOutput;
import com.google.common.io.GwtWorkarounds.CharInput;
import com.google.common.io.GwtWorkarounds.CharOutput;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

@GwtCompatible(emulated = true)
final class GwtWorkarounds {
	@GwtIncompatible("Reader")
   static CharInput asCharInput(Reader reader) {
      Preconditions.checkNotNull(reader);
      return new 1(reader);
   }

	static CharInput asCharInput(CharSequence chars) {
      Preconditions.checkNotNull(chars);
      return new 2(chars);
   }

	@GwtIncompatible("InputStream")
   static InputStream asInputStream(ByteInput input) {
      Preconditions.checkNotNull(input);
      return new 3(input);
   }

	@GwtIncompatible("OutputStream")
   static OutputStream asOutputStream(ByteOutput output) {
      Preconditions.checkNotNull(output);
      return new 4(output);
   }

	@GwtIncompatible("Writer")
   static CharOutput asCharOutput(Writer writer) {
      Preconditions.checkNotNull(writer);
      return new 5(writer);
   }

	static CharOutput stringBuilderOutput(int initialSize) {
      StringBuilder builder = new StringBuilder(initialSize);
      return new 6(builder);
   }
}