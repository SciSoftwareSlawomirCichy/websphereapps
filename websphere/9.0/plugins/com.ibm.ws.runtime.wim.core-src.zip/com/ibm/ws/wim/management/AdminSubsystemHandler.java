package com.ibm.ws.wim.management;

import com.ibm.websphere.management.AdminContext;
import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.configservice.ConfigDataId;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.management.configservice.ConfigServiceFactory;
import com.ibm.websphere.management.configservice.ConfigServiceHelper;
import com.ibm.websphere.management.exception.AdminException;
import com.ibm.websphere.management.exception.ConfigServiceException;
import com.ibm.websphere.management.exception.ConnectorException;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.adapter.file.was.FileAdapter;
import com.ibm.ws.wim.config.DomainConfigHelper;
import com.ibm.ws.wim.config.WASURHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.wsspi.management.agent.AdminSubsystemExtensionHandler;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.ObjectName;
import javax.management.QueryExp;

public class AdminSubsystemHandler extends AdminSubsystemExtensionHandler {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static Map<String, FileAdapterMBeanImpl> mbeans;

	public void changeState(String var1) {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		String var4 = AdminContext.peek();
		String var5 = DomainManagerUtils.getDomainId();
		if (var3) {
			trcLogger.entering(CLASSNAME, "changeState",
					"state=" + var1 + ", contextUUID=" + var4 + ", Domain=" + var5);
		}

		if ("initialize".equals(var1)) {
			this.activateFileAdapterMBean(var4);
		} else if ("start".equals(var1)) {
			this.activateFileAdapterMBean(var4);
		} else if ("destroy".equals(var1)) {
			this.clearAllDomainsCacheInProfile(var5);
			this.deactivateFileAdapterMBean(var4);
			FileAdapter.clearCache(var4);
			WASURHelper.clearCache(var4);
		} else if ("stop".equals(var1)) {
			this.clearAllDomainsCacheInProfile(var5);
			this.deactivateFileAdapterMBean(var4);
			FileAdapter.clearCache(var4);
			WASURHelper.clearCache(var4);
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "changeState");
		}

	}

	private synchronized void clearAllDomainsCacheInProfile(String var1) {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "clearAllDomainsCacheInProfile", ", current Domain=" + var1);
		}

		HashMap var4 = new HashMap();
		DomainConfigHelper var5 = new DomainConfigHelper();
		if (var3) {
			trcLogger.logp(Level.FINER, CLASSNAME, "clearAllDomainsCacheInProfile",
					"Clearing cache of all domains configured in subsystem");
		}

		ObjectName var6 = ConfigServiceHelper.createObjectName((ConfigDataId) null, "SecurityDomain");
		ConfigService var7 = ConfigServiceFactory.getConfigService();
		if (var7 != null) {
			try {
				ObjectName[] var8 = var7.queryConfigObjects((Session) null, (ObjectName) null, var6, (QueryExp) null);

				for (int var9 = 0; var9 < var8.length; ++var9) {
					String var10 = (String) var7.getAttribute((Session) null, var8[var9], "name");
					if (var3) {
						trcLogger.logp(Level.FINER, CLASSNAME, "clearAllDomainsCacheInProfile",
								"Clearing cache of domain=" + var10);
					}

					var4.put("securityDomainName", var10);

					try {
						var5.deleteDomainCache(var4);
						if (var3) {
							trcLogger.logp(Level.FINER, CLASSNAME, "clearAllDomainsCacheInProfile",
									"Cleared cache of domain= " + var10);
						}
					} catch (Exception var13) {
						if (var3) {
							trcLogger.logp(Level.FINER, CLASSNAME, "clearAllDomainsCacheInProfile",
									"Failed to clear cache of domain= " + var10 + ", " + var13);
						}
					}
				}
			} catch (ConfigServiceException var14) {
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "clearAllDomainsCacheInProfile", var14.toString());
				}
			} catch (ConnectorException var15) {
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "clearAllDomainsCacheInProfile", var15.toString());
				}
			}
		}

		var4.clear();
		var4.put("securityDomainName", var1);
		if (var3) {
			trcLogger.logp(Level.FINER, CLASSNAME, "clearAllDomainsCacheInProfile",
					"Clearing cache of current domain = " + var1);
		}

		try {
			var5.deleteDomainCache(var4);
			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "clearAllDomainsCacheInProfile",
						"Cleared cache for current Domain = " + var1);
			}
		} catch (Exception var12) {
			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "clearAllDomainsCacheInProfile",
						"Failed to clear cache of current domain = " + var1 + ", " + var12);
			}
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "clearAllDomainsCacheInProfile");
		}

	}

	private synchronized void activateFileAdapterMBean(String var1) {
		try {
			if (!mbeans.containsKey(var1)) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "activateFileAdapterMBean",
							"Creating FileAdapterMBean for context " + var1);
				}

				FileAdapterMBeanImpl var3 = new FileAdapterMBeanImpl();
				var3.activate();
				mbeans.put(var1, var3);
				msgLogger.log(Level.INFO, "MBEAN_INIT_SUCCESS",
						WIMMessageHelper.generateMsgParms("FileAdapterMBean (" + var1 + ")"));
				trcLogger.logp(Level.FINE, CLASSNAME, "activateFileAdapterMBean",
						"MBean activated: FileAdapterMBean (" + var1 + ")");
			}
		} catch (AdminException var4) {
			trcLogger.logp(Level.FINE, CLASSNAME, "activateFileAdapterMBean", "MBean activate failed", var4);
			msgLogger.logp(Level.SEVERE, CLASSNAME, "activateFileAdapterMBean", "MBEAN_INIT_FAILURE",
					WIMMessageHelper.generateMsgParms("FileAdapterMBean (" + var1 + ")", var4.getMessage()));
		}

	}

	private synchronized void deactivateFileAdapterMBean(String var1) {
		try {
			FileAdapterMBeanImpl var3 = (FileAdapterMBeanImpl) mbeans.get(var1);
			if (var3 != null) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "deactivateFileAdapterMBean",
							"Removing FileAdapterMBean for context " + var1);
				}

				var3.deactivate();
				mbeans.remove(var1);
				msgLogger.log(Level.INFO, "MBEAN_DEACTIVATION_SUCCESS",
						WIMMessageHelper.generateMsgParms("FileAdapterMBean (" + var1 + ")"));
				trcLogger.logp(Level.FINE, CLASSNAME, "deactivateFileAdapterMBean",
						"MBean deactivated: FileAdapterMBean (" + var1 + ")");
			}
		} catch (AdminException var4) {
			trcLogger.logp(Level.FINE, CLASSNAME, "deactivateFileAdapterMBean",
					"MBean deactivate failed for context=" + var1, var4);
			msgLogger.logp(Level.SEVERE, CLASSNAME, "deactivateFileAdapterMBean", "GENERIC", WIMMessageHelper
					.generateMsgParms("deactivate MBean, FileAdapterMBean (" + var1 + "):", var4.getMessage()));
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2008_2010;
		CLASSNAME = AdminSubsystemHandler.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
		mbeans = new HashMap(1);
	}
}