package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.DynamicModelType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class DynamicModelTypeImpl extends EDataObjectImpl implements DynamicModelType {
	protected static final String XSD_FILE_NAME_EDEFAULT = "wimextension.xsd";
	protected String xsdFileName = "wimextension.xsd";
	protected boolean xsdFileNameESet = false;
	protected static final boolean USE_GLOBAL_SCHEMA_EDEFAULT = false;
	protected boolean useGlobalSchema = false;
	protected boolean useGlobalSchemaESet = false;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getDynamicModelType();
	}

	public String getXsdFileName() {
		return this.xsdFileName;
	}

	public void setXsdFileName(String var1) {
		String var2 = this.xsdFileName;
		this.xsdFileName = var1;
		boolean var3 = this.xsdFileNameESet;
		this.xsdFileNameESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.xsdFileName, !var3));
		}

	}

	public void unsetXsdFileName() {
		String var1 = this.xsdFileName;
		boolean var2 = this.xsdFileNameESet;
		this.xsdFileName = "wimextension.xsd";
		this.xsdFileNameESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 0, var1, "wimextension.xsd", var2));
		}

	}

	public boolean isSetXsdFileName() {
		return this.xsdFileNameESet;
	}

	public boolean isUseGlobalSchema() {
		return this.useGlobalSchema;
	}

	public void setUseGlobalSchema(boolean var1) {
		boolean var2 = this.useGlobalSchema;
		this.useGlobalSchema = var1;
		boolean var3 = this.useGlobalSchemaESet;
		this.useGlobalSchemaESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.useGlobalSchema, !var3));
		}

	}

	public void unsetUseGlobalSchema() {
		boolean var1 = this.useGlobalSchema;
		boolean var2 = this.useGlobalSchemaESet;
		this.useGlobalSchema = false;
		this.useGlobalSchemaESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 1, var1, false, var2));
		}

	}

	public boolean isSetUseGlobalSchema() {
		return this.useGlobalSchemaESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getXsdFileName();
			case 1 :
				return this.isUseGlobalSchema() ? Boolean.TRUE : Boolean.FALSE;
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setXsdFileName((String) var2);
				return;
			case 1 :
				this.setUseGlobalSchema((Boolean) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.unsetXsdFileName();
				return;
			case 1 :
				this.unsetUseGlobalSchema();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.isSetXsdFileName();
			case 1 :
				return this.isSetUseGlobalSchema();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (useGlobalSchema: ");
			if (this.useGlobalSchemaESet) {
				var1.append(this.useGlobalSchema);
			} else {
				var1.append("<unset>");
			}

			var1.append(", xsdFileName: ");
			if (this.xsdFileNameESet) {
				var1.append(this.xsdFileName);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}