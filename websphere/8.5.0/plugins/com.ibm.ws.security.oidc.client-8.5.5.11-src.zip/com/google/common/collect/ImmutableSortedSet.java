package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableSortedSet.Builder;
import com.google.common.collect.ImmutableSortedSet.SerializedForm;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.NavigableSet;
import java.util.SortedSet;
import javax.annotation.Nullable;

@GwtCompatible(serializable = true, emulated = true)
public abstract class ImmutableSortedSet<E> extends ImmutableSortedSetFauxverideShim<E>
		implements
			NavigableSet<E>,
			SortedIterable<E> {
	private static final Comparator<Comparable> NATURAL_ORDER = Ordering.natural();
	private static final ImmutableSortedSet<Comparable> NATURAL_EMPTY_SET;
	final transient Comparator<? super E> comparator;
	@GwtIncompatible("NavigableSet")
	transient ImmutableSortedSet<E> descendingSet;

	private static <E> ImmutableSortedSet<E> emptySet() {
		return NATURAL_EMPTY_SET;
	}

	static <E> ImmutableSortedSet<E> emptySet(Comparator<? super E> comparator) {
		return (ImmutableSortedSet) (NATURAL_ORDER.equals(comparator)
				? emptySet()
				: new EmptyImmutableSortedSet(comparator));
	}

	public static <E> ImmutableSortedSet<E> of() {
		return emptySet();
	}

	public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E element) {
		return new RegularImmutableSortedSet(ImmutableList.of(element), Ordering.natural());
	}

	public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2) {
		return copyOf(Ordering.natural(), (Collection) Arrays.asList(e1, e2));
	}

	public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3) {
		return copyOf(Ordering.natural(), (Collection) Arrays.asList(e1, e2, e3));
	}

	public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4) {
		return copyOf(Ordering.natural(), (Collection) Arrays.asList(e1, e2, e3, e4));
	}

	public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4, E e5) {
		return copyOf(Ordering.natural(), (Collection) Arrays.asList(e1, e2, e3, e4, e5));
	}

	public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4, E e5, E e6,
			E... remaining) {
		int size = remaining.length + 6;
		List<E> all = new ArrayList(size);
		Collections.addAll(all, new Comparable[]{e1, e2, e3, e4, e5, e6});
		Collections.addAll(all, remaining);
		return copyOf(Ordering.natural(), (Collection) all);
	}

	public static <E extends Comparable<? super E>> ImmutableSortedSet<E> copyOf(E[] elements) {
		return copyOf(Ordering.natural(), (Collection) Arrays.asList(elements));
	}

	public static <E> ImmutableSortedSet<E> copyOf(Iterable<? extends E> elements) {
		Ordering<E> naturalOrder = Ordering.natural();
		return copyOf(naturalOrder, (Iterable) elements);
	}

	public static <E> ImmutableSortedSet<E> copyOf(Collection<? extends E> elements) {
		Ordering<E> naturalOrder = Ordering.natural();
		return copyOf(naturalOrder, (Collection) elements);
	}

	public static <E> ImmutableSortedSet<E> copyOf(Iterator<? extends E> elements) {
		Ordering<E> naturalOrder = Ordering.natural();
		return copyOf(naturalOrder, (Iterator) elements);
	}

	public static <E> ImmutableSortedSet<E> copyOf(Comparator<? super E> comparator, Iterator<? extends E> elements) {
		return copyOf(comparator, (Collection) Lists.newArrayList(elements));
	}

	public static <E> ImmutableSortedSet<E> copyOf(Comparator<? super E> comparator, Iterable<? extends E> elements) {
		Preconditions.checkNotNull(comparator);
		boolean hasSameComparator = SortedIterables.hasSameComparator(comparator, elements);
		if (hasSameComparator && elements instanceof ImmutableSortedSet) {
			ImmutableSortedSet<E> original = (ImmutableSortedSet) elements;
			if (!original.isPartialView()) {
				return original;
			}
		}

		E[] array = (Object[]) Iterables.toArray(elements);
		return construct(comparator, array.length, array);
	}

	public static <E> ImmutableSortedSet<E> copyOf(Comparator<? super E> comparator, Collection<? extends E> elements) {
		return copyOf(comparator, (Iterable) elements);
	}

	public static <E> ImmutableSortedSet<E> copyOfSorted(SortedSet<E> sortedSet) {
		Comparator<? super E> comparator = SortedIterables.comparator(sortedSet);
		Object[] elements = sortedSet.toArray();
		return (ImmutableSortedSet) (elements.length == 0
				? emptySet(comparator)
				: new RegularImmutableSortedSet(ImmutableList.asImmutableList(elements), comparator));
	}

	static <E> int sortAndUnique(Comparator<? super E> comparator, int n, E... contents) {
		if (n == 0) {
			return 0;
		} else {
			int uniques;
			for (uniques = 0; uniques < n; ++uniques) {
				ObjectArrays.checkElementNotNull(contents[uniques], uniques);
			}

			Arrays.sort(contents, 0, n, comparator);
			uniques = 1;

			for (int i = 1; i < n; ++i) {
				E cur = contents[i];
				E prev = contents[uniques - 1];
				if (comparator.compare(cur, prev) != 0) {
					contents[uniques++] = cur;
				}
			}

			Arrays.fill(contents, uniques, n, (Object) null);
			return uniques;
		}
	}

	static <E> ImmutableSortedSet<E> construct(Comparator<? super E> comparator, int n, E... contents) {
		int uniques = sortAndUnique(comparator, n, contents);
		if (uniques == 0) {
			return emptySet(comparator);
		} else {
			if (uniques < contents.length) {
				contents = ObjectArrays.arraysCopyOf(contents, uniques);
			}

			return new RegularImmutableSortedSet(ImmutableList.asImmutableList(contents), comparator);
		}
	}

	public static <E> Builder<E> orderedBy(Comparator<E> comparator) {
		return new Builder(comparator);
	}

	public static <E extends Comparable<?>> Builder<E> reverseOrder() {
		return new Builder(Ordering.natural().reverse());
	}

	public static <E extends Comparable<?>> Builder<E> naturalOrder() {
		return new Builder(Ordering.natural());
	}

	int unsafeCompare(Object a, Object b) {
		return unsafeCompare(this.comparator, a, b);
	}

	static int unsafeCompare(Comparator<?> comparator, Object a, Object b) {
		return comparator.compare(a, b);
	}

	ImmutableSortedSet(Comparator<? super E> comparator) {
		this.comparator = comparator;
	}

	public Comparator<? super E> comparator() {
		return this.comparator;
	}

	public abstract UnmodifiableIterator<E> iterator();

	public ImmutableSortedSet<E> headSet(E toElement) {
		return this.headSet(toElement, false);
	}

	@GwtIncompatible("NavigableSet")
	public ImmutableSortedSet<E> headSet(E toElement, boolean inclusive) {
		return this.headSetImpl(Preconditions.checkNotNull(toElement), inclusive);
	}

	public ImmutableSortedSet<E> subSet(E fromElement, E toElement) {
		return this.subSet(fromElement, true, toElement, false);
	}

	@GwtIncompatible("NavigableSet")
	public ImmutableSortedSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive) {
		Preconditions.checkNotNull(fromElement);
		Preconditions.checkNotNull(toElement);
		Preconditions.checkArgument(this.comparator.compare(fromElement, toElement) <= 0);
		return this.subSetImpl(fromElement, fromInclusive, toElement, toInclusive);
	}

	public ImmutableSortedSet<E> tailSet(E fromElement) {
		return this.tailSet(fromElement, true);
	}

	@GwtIncompatible("NavigableSet")
	public ImmutableSortedSet<E> tailSet(E fromElement, boolean inclusive) {
		return this.tailSetImpl(Preconditions.checkNotNull(fromElement), inclusive);
	}

	abstract ImmutableSortedSet<E> headSetImpl(E var1, boolean var2);

	abstract ImmutableSortedSet<E> subSetImpl(E var1, boolean var2, E var3, boolean var4);

	abstract ImmutableSortedSet<E> tailSetImpl(E var1, boolean var2);

	@GwtIncompatible("NavigableSet")
	public E lower(E e) {
		return Iterators.getNext(this.headSet(e, false).descendingIterator(), (Object) null);
	}

	@GwtIncompatible("NavigableSet")
	public E floor(E e) {
		return Iterators.getNext(this.headSet(e, true).descendingIterator(), (Object) null);
	}

	@GwtIncompatible("NavigableSet")
	public E ceiling(E e) {
		return Iterables.getFirst(this.tailSet(e, true), (Object) null);
	}

	@GwtIncompatible("NavigableSet")
	public E higher(E e) {
		return Iterables.getFirst(this.tailSet(e, false), (Object) null);
	}

	public E first() {
		return this.iterator().next();
	}

	public E last() {
		return this.descendingIterator().next();
	}

	@Deprecated
	@GwtIncompatible("NavigableSet")
	public final E pollFirst() {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@GwtIncompatible("NavigableSet")
	public final E pollLast() {
		throw new UnsupportedOperationException();
	}

	@GwtIncompatible("NavigableSet")
	public ImmutableSortedSet<E> descendingSet() {
		ImmutableSortedSet<E> result = this.descendingSet;
		if (result == null) {
			result = this.descendingSet = this.createDescendingSet();
			result.descendingSet = this;
		}

		return result;
	}

	@GwtIncompatible("NavigableSet")
	ImmutableSortedSet<E> createDescendingSet() {
		return new DescendingImmutableSortedSet(this);
	}

	@GwtIncompatible("NavigableSet")
	public abstract UnmodifiableIterator<E> descendingIterator();

	abstract int indexOf(@Nullable Object var1);

	private void readObject(ObjectInputStream stream) throws InvalidObjectException {
		throw new InvalidObjectException("Use SerializedForm");
	}

	Object writeReplace() {
		return new SerializedForm(this.comparator, this.toArray());
	}

	static {
		NATURAL_EMPTY_SET = new EmptyImmutableSortedSet(NATURAL_ORDER);
	}
}