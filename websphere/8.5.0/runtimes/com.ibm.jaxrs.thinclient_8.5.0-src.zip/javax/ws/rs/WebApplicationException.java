package javax.ws.rs;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

public class WebApplicationException extends RuntimeException {
	private static final long serialVersionUID = 11660101L;
	private final Response response;

	public WebApplicationException() {
		this(Status.INTERNAL_SERVER_ERROR);
	}

	public WebApplicationException(int status) {
		this.response = Response.status(status).build();
	}

	public WebApplicationException(Status status) {
		this.response = Response.status(status).build();
	}

	public WebApplicationException(Response response) {
		this.response = response;
	}

	public WebApplicationException(Throwable cause) {
		this(cause, Status.INTERNAL_SERVER_ERROR);
	}

	public WebApplicationException(Throwable cause, int status) {
		super(cause);
		this.response = Response.status(status).build();
	}

	public WebApplicationException(Throwable cause, Status status) {
		super(cause);
		this.response = Response.status(status).build();
	}

	public WebApplicationException(Throwable cause, Response response) {
		super(cause);
		this.response = response;
	}

	public Response getResponse() {
		return this.response;
	}
}