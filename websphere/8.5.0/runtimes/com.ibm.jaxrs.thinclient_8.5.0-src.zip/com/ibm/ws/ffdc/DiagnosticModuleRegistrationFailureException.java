package com.ibm.ws.ffdc;

import com.ibm.ws.exception.WsException;

public class DiagnosticModuleRegistrationFailureException extends WsException {
	private static final long serialVersionUID = -272181404821808015L;

	public DiagnosticModuleRegistrationFailureException() {
	}

	public DiagnosticModuleRegistrationFailureException(String s) {
		super(s);
	}

	public DiagnosticModuleRegistrationFailureException(String s, Throwable cause) {
		super(s, cause);
	}
}