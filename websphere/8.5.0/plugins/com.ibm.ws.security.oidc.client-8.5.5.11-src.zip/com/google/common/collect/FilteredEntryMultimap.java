package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.collect.FilteredEntryMultimap.AsMap;
import com.google.common.collect.FilteredEntryMultimap.Keys;
import com.google.common.collect.FilteredEntryMultimap.ValuePredicate;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible
class FilteredEntryMultimap<K, V> extends FilteredMultimap<K, V> {
	final Predicate<? super Entry<K, V>> predicate;

	FilteredEntryMultimap(Multimap<K, V> unfiltered, Predicate<? super Entry<K, V>> predicate) {
		super(unfiltered);
		this.predicate = (Predicate) Preconditions.checkNotNull(predicate);
	}

	Predicate<? super Entry<K, V>> entryPredicate() {
		return this.predicate;
	}

	public int size() {
		return this.entries().size();
	}

	private boolean satisfies(K key, V value) {
		return this.predicate.apply(Maps.immutableEntry(key, value));
	}

	static <E> Collection<E> filterCollection(Collection<E> collection, Predicate<? super E> predicate) {
		return (Collection) (collection instanceof Set
				? Sets.filter((Set) collection, predicate)
				: Collections2.filter(collection, predicate));
	}

	public boolean containsKey(@Nullable Object key) {
		return this.asMap().get(key) != null;
	}

	public Collection<V> removeAll(@Nullable Object key) {
		return (Collection) Objects.firstNonNull(this.asMap().remove(key), this.unmodifiableEmptyCollection());
	}

	Collection<V> unmodifiableEmptyCollection() {
		return (Collection) (this.unfiltered instanceof SetMultimap ? Collections.emptySet() : Collections.emptyList());
	}

	public void clear() {
		this.entries().clear();
	}

	public Collection<V> get(K key) {
		return filterCollection(this.unfiltered.get(key), new ValuePredicate(this, key));
	}

	Collection<Entry<K, V>> createEntries() {
		return filterCollection(this.unfiltered.entries(), this.predicate);
	}

	Iterator<Entry<K, V>> entryIterator() {
		throw new AssertionError("should never be called");
	}

	Map<K, Collection<V>> createAsMap() {
		return new AsMap(this);
	}

	public Set<K> keySet() {
		return this.asMap().keySet();
	}

	boolean removeIf(Predicate<? super Entry<K, Collection<V>>> predicate) {
		Iterator<Entry<K, Collection<V>>> entryIterator = this.unfiltered.asMap().entrySet().iterator();
		boolean changed = false;

		while (entryIterator.hasNext()) {
			Entry<K, Collection<V>> entry = (Entry) entryIterator.next();
			K key = entry.getKey();
			Collection<V> collection = filterCollection((Collection) entry.getValue(), new ValuePredicate(this, key));
			if (!collection.isEmpty() && predicate.apply(Maps.immutableEntry(key, collection))) {
				if (collection.size() == ((Collection) entry.getValue()).size()) {
					entryIterator.remove();
				} else {
					collection.clear();
				}

				changed = true;
			}
		}

		return changed;
	}

	Multiset<K> createKeys() {
		return new Keys(this);
	}
}