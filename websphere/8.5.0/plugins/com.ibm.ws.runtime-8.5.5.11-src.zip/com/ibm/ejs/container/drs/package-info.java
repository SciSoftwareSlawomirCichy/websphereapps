package com.ibm.ejs.container.drs;

interface package-info {
}