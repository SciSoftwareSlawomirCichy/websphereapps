package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import commonj.sdo.DataObject;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FederationRepositoryConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public String setIdMgrFederationRepository(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setIdMgrFederationRepository",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var5 = (String) var2.get("dataSourceName");
		String var6 = (String) var2.get("databaseType");
		String var7 = (String) var2.get("dbURL");
		ConfigurationProviderType var8 = ConfigUtils.getConfigProvider(var1);
		EntryMappingRepositoryType var9 = var8.getEntryMappingRepository();
		if (var9 == null) {
			ValidationHelper.validateRequiredDBParameters(var2, CLASSNAME, "setIdMgrFederationRepository");
			ConfigValidator.validateDBParams("FED", var2);
			var9 = var8.createEntryMappingRepository();
			var9.setId("FED");
			var9.setAdapterClassName("com.ibm.ws.wim.federation.FederationAdapter");
		} else {
			HashMap var10 = new HashMap();
			ConfigUtils.buildMapFromOldAndNewValues(var10, ConfigValidator.DB_CONNECTION_PARAMS, (DataObject) var9,
					var2);
			ConfigValidator.validateDBParams("FED", var10);
		}

		if (var6 != null) {
			var9.setDatabaseType(var6);
		}

		if (var5 != null) {
			var9.setDataSourceName(var5);
		}

		if (var7 != null) {
			var9.setDbURL(var7);
		}

		if (var2.get("dbAdminId") != null) {
			var9.setDbAdminId((String) var2.get("dbAdminId"));
		}

		if (var2.get("dbAdminPassword") != null) {
			var9.setDbAdminPassword(ConfigUtils.encodePassword((String) var2.get("dbAdminPassword")));
		}

		if (var2.get("JDBCDriverClass") != null) {
			var9.setJDBCDriverClass((String) var2.get("JDBCDriverClass"));
		}

		if (var2.get("dbSchema") != null) {
			var9.setDbSchema((String) var2.get("dbSchema"));
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "setIdMgrFederationRepository");
		}

		return ConfigUtils.saveConfig(var1);
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = FederationRepositoryConfigHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}