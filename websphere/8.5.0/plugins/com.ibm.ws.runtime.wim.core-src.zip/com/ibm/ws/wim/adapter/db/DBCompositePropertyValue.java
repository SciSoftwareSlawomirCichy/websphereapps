package com.ibm.ws.wim.adapter.db;

public class DBCompositePropertyValue {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private long valueId;
	private int propertyId;
	private long entityId;
	private long compositeId;

	public long getCompositeId() {
		return this.compositeId;
	}

	public void setCompositeId(long var1) {
		this.compositeId = var1;
	}

	public int getPropertyId() {
		return this.propertyId;
	}

	public void setPropertyId(int var1) {
		this.propertyId = var1;
	}

	public long getValueId() {
		return this.valueId;
	}

	public void setValueId(long var1) {
		this.valueId = var1;
	}

	public long getEntityId() {
		return this.entityId;
	}

	public void setEntityId(long var1) {
		this.entityId = var1;
	}
}