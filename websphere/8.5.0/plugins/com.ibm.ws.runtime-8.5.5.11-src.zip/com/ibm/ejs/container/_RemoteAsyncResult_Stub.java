package com.ibm.ejs.container;

import java.rmi.RemoteException;
import java.rmi.UnexpectedException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import javax.rmi.CORBA.Stub;
import javax.rmi.CORBA.Util;
import org.omg.CORBA.SystemException;
import org.omg.CORBA.portable.ApplicationException;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.RemarshalException;
import org.omg.CORBA.portable.ServantObject;

public class _RemoteAsyncResult_Stub extends Stub implements RemoteAsyncResult {
	private static final String[] _type_ids = new String[]{
			"RMI:com.ibm.ejs.container.RemoteAsyncResult:0000000000000000"};

	public String[] _ids() {
		return (String[]) _type_ids.clone();
	}

	public boolean cancel(boolean var1) throws RemoteException {
		while (true) {
			boolean var3;
			if (!Util.isLocal(this)) {
				InputStream var26 = null;

				try {
					try {
						OutputStream var6 = this._request("cancel", true);
						var6.write_boolean(var1);
						var26 = this._invoke(var6);
						var3 = var26.read_boolean();
					} catch (ApplicationException var20) {
						var26 = var20.getInputStream();
						String var27 = var26.read_string();
						throw new UnexpectedException(var27);
					} catch (RemarshalException var21) {
						continue;
					}
				} catch (SystemException var22) {
					throw Util.mapSystemException(var22);
				} finally {
					this._releaseReply(var26);
				}

				return var3;
			} else {
				ServantObject var2 = this._servant_preinvoke("cancel",
						class$com$ibm$ejs$container$RemoteAsyncResult != null
								? class$com$ibm$ejs$container$RemoteAsyncResult
								: (class$com$ibm$ejs$container$RemoteAsyncResult = class$(
										"com.ibm.ejs.container.RemoteAsyncResult")));
				if (var2 != null) {
					try {
						var3 = ((RemoteAsyncResult) var2.servant).cancel(var1);
					} catch (Throwable var24) {
						Throwable var7 = (Throwable) Util.copyObject(var24, this._orb());
						throw Util.wrapException(var7);
					} finally {
						this._servant_postinvoke(var2);
					}

					return var3;
				}
			}
		}
	}

	public Object get() throws ExecutionException, InterruptedException, RemoteException {
		while (true) {
			Object var2;
			if (!Util.isLocal(this)) {
				org.omg.CORBA_2_3.portable.InputStream var25 = null;

				try {
					try {
						OutputStream var26 = this._request("get__", true);
						var25 = (org.omg.CORBA_2_3.portable.InputStream) this._invoke(var26);
						var2 = Util.readAny(var25);
					} catch (ApplicationException var21) {
						var25 = (org.omg.CORBA_2_3.portable.InputStream) var21.getInputStream();
						String var27 = var25.read_string();
						if (var27.equals("IDL:java/util/concurrent/ExecutionEx:1.0")) {
							throw (ExecutionException) var25
									.read_value(class$java$util$concurrent$ExecutionException != null
											? class$java$util$concurrent$ExecutionException
											: (class$java$util$concurrent$ExecutionException = class$(
													"java.util.concurrent.ExecutionException")));
						}

						if (var27.equals("IDL:java/lang/InterruptedEx:1.0")) {
							throw (InterruptedException) var25.read_value(class$java$lang$InterruptedException != null
									? class$java$lang$InterruptedException
									: (class$java$lang$InterruptedException = class$(
											"java.lang.InterruptedException")));
						}

						throw new UnexpectedException(var27);
					} catch (RemarshalException var22) {
						continue;
					}
				} catch (SystemException var23) {
					throw Util.mapSystemException(var23);
				} finally {
					this._releaseReply(var25);
				}

				return var2;
			} else {
				ServantObject var1 = this._servant_preinvoke("get__",
						class$com$ibm$ejs$container$RemoteAsyncResult != null
								? class$com$ibm$ejs$container$RemoteAsyncResult
								: (class$com$ibm$ejs$container$RemoteAsyncResult = class$(
										"com.ibm.ejs.container.RemoteAsyncResult")));
				if (var1 != null) {
					try {
						Object var5 = ((RemoteAsyncResult) var1.servant).get();
						var2 = Util.copyObject(var5, this._orb());
					} catch (Throwable var19) {
						Throwable var6 = (Throwable) Util.copyObject(var19, this._orb());
						if (var6 instanceof ExecutionException) {
							throw (ExecutionException) var6;
						}

						if (var6 instanceof InterruptedException) {
							throw (InterruptedException) var6;
						}

						throw Util.wrapException(var6);
					} finally {
						this._servant_postinvoke(var1);
					}

					return var2;
				}
			}
		}
	}

	public Object get(long var1, String var3)
			throws ExecutionException, InterruptedException, TimeoutException, RemoteException {
		while (true) {
			Object var5;
			if (!Util.isLocal(this)) {
				org.omg.CORBA_2_3.portable.InputStream var28 = null;

				try {
					try {
						org.omg.CORBA_2_3.portable.OutputStream var29 = (org.omg.CORBA_2_3.portable.OutputStream) this
								._request("get__long_long__CORBA_WStringValue", true);
						var29.write_longlong(var1);
						var29.write_value(var3,
								class$java$lang$String != null
										? class$java$lang$String
										: (class$java$lang$String = class$("java.lang.String")));
						var28 = (org.omg.CORBA_2_3.portable.InputStream) this._invoke(var29);
						var5 = Util.readAny(var28);
					} catch (ApplicationException var24) {
						var28 = (org.omg.CORBA_2_3.portable.InputStream) var24.getInputStream();
						String var30 = var28.read_string();
						if (var30.equals("IDL:java/util/concurrent/ExecutionEx:1.0")) {
							throw (ExecutionException) var28
									.read_value(class$java$util$concurrent$ExecutionException != null
											? class$java$util$concurrent$ExecutionException
											: (class$java$util$concurrent$ExecutionException = class$(
													"java.util.concurrent.ExecutionException")));
						}

						if (var30.equals("IDL:java/lang/InterruptedEx:1.0")) {
							throw (InterruptedException) var28.read_value(class$java$lang$InterruptedException != null
									? class$java$lang$InterruptedException
									: (class$java$lang$InterruptedException = class$(
											"java.lang.InterruptedException")));
						}

						if (var30.equals("IDL:java/util/concurrent/TimeoutEx:1.0")) {
							throw (TimeoutException) var28
									.read_value(class$java$util$concurrent$TimeoutException != null
											? class$java$util$concurrent$TimeoutException
											: (class$java$util$concurrent$TimeoutException = class$(
													"java.util.concurrent.TimeoutException")));
						}

						throw new UnexpectedException(var30);
					} catch (RemarshalException var25) {
						continue;
					}
				} catch (SystemException var26) {
					throw Util.mapSystemException(var26);
				} finally {
					this._releaseReply(var28);
				}

				return var5;
			} else {
				ServantObject var4 = this._servant_preinvoke("get__long_long__CORBA_WStringValue",
						class$com$ibm$ejs$container$RemoteAsyncResult != null
								? class$com$ibm$ejs$container$RemoteAsyncResult
								: (class$com$ibm$ejs$container$RemoteAsyncResult = class$(
										"com.ibm.ejs.container.RemoteAsyncResult")));
				if (var4 != null) {
					try {
						Object var8 = ((RemoteAsyncResult) var4.servant).get(var1, var3);
						var5 = Util.copyObject(var8, this._orb());
					} catch (Throwable var22) {
						Throwable var9 = (Throwable) Util.copyObject(var22, this._orb());
						if (var9 instanceof ExecutionException) {
							throw (ExecutionException) var9;
						}

						if (var9 instanceof InterruptedException) {
							throw (InterruptedException) var9;
						}

						if (var9 instanceof TimeoutException) {
							throw (TimeoutException) var9;
						}

						throw Util.wrapException(var9);
					} finally {
						this._servant_postinvoke(var4);
					}

					return var5;
				}
			}
		}
	}

	public boolean isCancelled() throws RemoteException {
		while (true) {
			boolean var2;
			if (!Util.isLocal(this)) {
				InputStream var25 = null;

				try {
					try {
						OutputStream var5 = this._request("_get_cancelled", true);
						var25 = this._invoke(var5);
						var2 = var25.read_boolean();
					} catch (ApplicationException var19) {
						var25 = var19.getInputStream();
						String var26 = var25.read_string();
						throw new UnexpectedException(var26);
					} catch (RemarshalException var20) {
						continue;
					}
				} catch (SystemException var21) {
					throw Util.mapSystemException(var21);
				} finally {
					this._releaseReply(var25);
				}

				return var2;
			} else {
				ServantObject var1 = this._servant_preinvoke("_get_cancelled",
						class$com$ibm$ejs$container$RemoteAsyncResult != null
								? class$com$ibm$ejs$container$RemoteAsyncResult
								: (class$com$ibm$ejs$container$RemoteAsyncResult = class$(
										"com.ibm.ejs.container.RemoteAsyncResult")));
				if (var1 != null) {
					try {
						var2 = ((RemoteAsyncResult) var1.servant).isCancelled();
					} catch (Throwable var23) {
						Throwable var6 = (Throwable) Util.copyObject(var23, this._orb());
						throw Util.wrapException(var6);
					} finally {
						this._servant_postinvoke(var1);
					}

					return var2;
				}
			}
		}
	}

	public boolean isDone() throws RemoteException {
		while (true) {
			boolean var2;
			if (!Util.isLocal(this)) {
				InputStream var25 = null;

				try {
					try {
						OutputStream var5 = this._request("_get_done", true);
						var25 = this._invoke(var5);
						var2 = var25.read_boolean();
					} catch (ApplicationException var19) {
						var25 = var19.getInputStream();
						String var26 = var25.read_string();
						throw new UnexpectedException(var26);
					} catch (RemarshalException var20) {
						continue;
					}
				} catch (SystemException var21) {
					throw Util.mapSystemException(var21);
				} finally {
					this._releaseReply(var25);
				}

				return var2;
			} else {
				ServantObject var1 = this._servant_preinvoke("_get_done",
						class$com$ibm$ejs$container$RemoteAsyncResult != null
								? class$com$ibm$ejs$container$RemoteAsyncResult
								: (class$com$ibm$ejs$container$RemoteAsyncResult = class$(
										"com.ibm.ejs.container.RemoteAsyncResult")));
				if (var1 != null) {
					try {
						var2 = ((RemoteAsyncResult) var1.servant).isDone();
					} catch (Throwable var23) {
						Throwable var6 = (Throwable) Util.copyObject(var23, this._orb());
						throw Util.wrapException(var6);
					} finally {
						this._servant_postinvoke(var1);
					}

					return var2;
				}
			}
		}
	}
}