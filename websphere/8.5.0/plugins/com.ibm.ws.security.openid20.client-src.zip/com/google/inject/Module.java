package com.google.inject;

public interface Module {
	void configure(Binder var1);
}