package com.ibm.ejs.container.util;

import com.ibm.ejs.container.EJBConfigurationException;
import com.ibm.ejs.container.util.DeploymentUtil.DeploymentTarget;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.jitdeploy.EJBWrapperType;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

public final class DeploymentUtil {
	private static final String CLASS_NAME = DeploymentUtil.class.getName();
	private static final TraceComponent tc;
	public static final String declaredUncheckedAreSystemExceptions = "com.ibm.websphere.ejbcontainer.declaredUncheckedAreSystemExceptions";
	public static final boolean DeclaredUncheckedAreSystemExceptions;
	public static final String declaredRemoteAreApplicationExceptions = "com.ibm.websphere.ejbcontainer.declaredRemoteAreApplicationExceptions";
	public static final boolean DeclaredRemoteAreApplicationExceptions;

	public static String methodKey(Method m) {
		StringBuffer result = new StringBuffer(m.getName());
		result.append("(");
		Class[] argTypes = m.getParameterTypes();

		for (int i = 0; i < argTypes.length; ++i) {
			result.append(argTypes[i].getName());
			result.append(",");
		}

		result.append(")");
		return result.toString();
	}

	public static Method[] getAllMethods(Class intf) {
		Method[] allMethods = intf.getMethods();
		ArrayList<Method> result = new ArrayList(allMethods.length);
		HashMap<String, Method> methodNameTable = new HashMap();

		for (int i = 0; i < allMethods.length; ++i) {
			Method m = allMethods[i];
			if (!Modifier.isStatic(m.getModifiers())) {
				String mKey = methodKey(m);
				String interfaceName = m.getDeclaringClass().getName();
				if (!interfaceName.equals("javax.ejb.EJBObject") && !interfaceName.equals("javax.ejb.EJBLocalObject")
						|| m.getName().equals("remove")) {
					Method synonym = (Method) methodNameTable.get(mKey);
					if (synonym == null) {
						methodNameTable.put(mKey, m);
						result.add(m);
					} else {
						Class<?> mClass = m.getDeclaringClass();
						Class<?> sClass = synonym.getDeclaringClass();
						if (sClass.isAssignableFrom(mClass)) {
							methodNameTable.put(mKey, m);
							result.set(result.indexOf(synonym), m);
						}
					}
				}
			}
		}

		return sortMethods(result);
	}

	public static Method[] getMethods(Class intf) {
		return getMethods(intf, (Class[]) null);
	}

	public static Method[] getMethods(Class componentInterface, Class[] businessInterfaces) {
		int numMethods = 0;
		Method[] methods = null;
		int numBusinessInterfaces = 0;
		HashMap<String, Method> methodNameTable = new HashMap();
		if (componentInterface != null) {
			methods = componentInterface.getMethods();
			numMethods = methods.length;
		}

		if (businessInterfaces != null) {
			numBusinessInterfaces = businessInterfaces.length;
		}

		ArrayList<Method> result = new ArrayList(numMethods + numBusinessInterfaces * 10);

		int i;
		Class mClass;
		for (i = 0; i < numMethods; ++i) {
			Method m = methods[i];
			if (!Modifier.isStatic(m.getModifiers())) {
				String mKey = methodKey(m);
				String interfaceName = m.getDeclaringClass().getName();
				if (!interfaceName.equals("javax.ejb.EJBObject") && !interfaceName.equals("javax.ejb.EJBLocalObject")) {
					Method synonym = (Method) methodNameTable.get(mKey);
					if (synonym == null) {
						methodNameTable.put(mKey, m);
						result.add(m);
					} else {
						Class<?> mClass = m.getDeclaringClass();
						mClass = synonym.getDeclaringClass();
						if (mClass.isAssignableFrom(mClass)) {
							methodNameTable.put(mKey, m);
							result.set(result.indexOf(synonym), m);
						}
					}
				}
			}
		}

		for (i = 0; i < numBusinessInterfaces; ++i) {
			methods = businessInterfaces[i].getMethods();
			numMethods = methods.length;
			result.ensureCapacity(result.size() + numMethods);

			for (int j = 0; j < numMethods; ++j) {
				Method m = methods[j];
				if (!Modifier.isStatic(m.getModifiers()) && !m.isBridge()) {
					Class<?> declaring = m.getDeclaringClass();
					if (declaring != Object.class) {
						String mKey = methodKey(m);
						if ((!mKey.equals("equals(java.lang.Object,)") || m.getReturnType() != Boolean.TYPE)
								&& (!mKey.equals("hashCode()") || m.getReturnType() != Integer.TYPE)) {
							Method synonym = (Method) methodNameTable.get(mKey);
							if (synonym == null) {
								methodNameTable.put(mKey, m);
								result.add(m);
							} else {
								mClass = m.getDeclaringClass();
								Class<?> sClass = synonym.getDeclaringClass();
								if (sClass.isAssignableFrom(mClass)) {
									methodNameTable.put(mKey, m);
									result.set(result.indexOf(synonym), m);
								}
							}
						}
					}
				}
			}
		}

		return sortMethods(result);
	}

	private static Method[] sortMethods(ArrayList<Method> methods) {
		int numMethods = methods.size();
		Method[] result = new Method[numMethods];

		for (int i = 0; i < numMethods; ++i) {
			Method currMethod = (Method) methods.get(i);
			String currMethodName = currMethod.toString();

			int insertIndex;
			for (insertIndex = 0; insertIndex < i
					&& currMethodName.compareTo(result[insertIndex].toString()) > 0; ++insertIndex) {
				;
			}

			for (int j = insertIndex; j <= i; ++j) {
				Method tmpMethod = result[j];
				result[j] = currMethod;
				currMethod = tmpMethod;
			}
		}

		return result;
	}

	public static ArrayList<Method> getNonPublicMethods(Class<?> ejbClass, Method[] publicMethods) {
		Class<?> thisClass = ejbClass;

		HashMap methodMap;
		for (methodMap = new HashMap(); thisClass != null
				&& thisClass != Object.class; thisClass = thisClass.getSuperclass()) {
			Method[] thisMethods = thisClass.getDeclaredMethods();
			Method[] arr$ = thisMethods;
			int len$ = thisMethods.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				Method thisMethod = arr$[i$];
				int modifiers = thisMethod.getModifiers();
				if (!Modifier.isStatic(modifiers) && !thisMethod.isBridge() && !Modifier.isPublic(modifiers)) {
					boolean found = false;
					String methodName = thisMethod.getName();
					ArrayList<Method> existingMethods = (ArrayList) methodMap.get(methodName);
					int i$;
					Method publicMethod;
					Method[] arr$;
					int len$;
					if (existingMethods == null) {
						arr$ = publicMethods;
						len$ = publicMethods.length;

						for (i$ = 0; i$ < len$; ++i$) {
							publicMethod = arr$[i$];
							if (methodsMatch(thisMethod, publicMethod)) {
								found = true;
								break;
							}
						}

						if (!found) {
							existingMethods = new ArrayList();
							existingMethods.add(thisMethod);
							methodMap.put(methodName, existingMethods);
						}
					} else {
						Iterator i$ = existingMethods.iterator();

						while (i$.hasNext()) {
							Method existingMethod = (Method) i$.next();
							if (methodsMatch(thisMethod, existingMethod)) {
								found = true;
								break;
							}
						}

						if (!found) {
							arr$ = publicMethods;
							len$ = publicMethods.length;

							for (i$ = 0; i$ < len$; ++i$) {
								publicMethod = arr$[i$];
								if (methodsMatch(thisMethod, publicMethod)) {
									found = true;
									break;
								}
							}
						}

						if (!found) {
							existingMethods.add(thisMethod);
						}
					}
				}
			}
		}

		ArrayList<Method> entireMethodList = new ArrayList();
		Iterator i$ = methodMap.values().iterator();

		while (i$.hasNext()) {
			ArrayList<Method> list = (ArrayList) i$.next();
			entireMethodList.addAll(list);
		}

		return entireMethodList;
	}

	public static boolean methodsMatch(Method m1, Method m2) {
		return m1 == m2
				|| m1.getName().equals(m2.getName()) && Arrays.equals(m1.getParameterTypes(), m2.getParameterTypes());
	}

	public static Class<?>[] getCheckedExceptions(Method method, boolean isRmiRemote, DeploymentTarget target)
			throws EJBConfigurationException {
		return getCheckedExceptions(method, isRmiRemote, target, (EJBWrapperType) null);
	}

	public static Class<?>[] getCheckedExceptions(Method method, boolean isRmiRemote, DeploymentTarget target,
			EJBWrapperType wrapperType) throws EJBConfigurationException {
		return getCheckedExceptions(method, isRmiRemote, target, wrapperType, DeclaredUncheckedAreSystemExceptions,
				DeclaredRemoteAreApplicationExceptions);
	}

	public static Class<?>[] getCheckedExceptions(Method method, boolean isRmiRemote, DeploymentTarget target,
			EJBWrapperType wrapperType, boolean declaredUncheckedAreSystemExceptions,
			boolean declaredRemoteAreApplicationExceptions) throws EJBConfigurationException {
		boolean throwsRemoteException = false;
		Class<?>[] exceptions = method.getExceptionTypes();
		int numExceptions = exceptions.length;
		ArrayList<Class<?>> checkedExceptions = new ArrayList(numExceptions);
		Class[] arr$ = exceptions;
		int len$ = exceptions.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Class<?> exception = arr$[i$];
			if (exception == RemoteException.class) {
				if (!isRmiRemote) {
					Tr.warning(tc, "JIT_INVALID_THROW_REMOTE_CNTR5101W",
							new Object[]{method.getName(), method.getDeclaringClass().getName()});
				}

				throwsRemoteException = true;
			} else {
				String className;
				if (RemoteException.class.isAssignableFrom(exception)) {
					if (target != DeploymentTarget.STUB && (!declaredRemoteAreApplicationExceptions
							|| wrapperType != null && wrapperType != EJBWrapperType.BUSINESS_REMOTE
									&& wrapperType != EJBWrapperType.BUSINESS_LOCAL)) {
						className = method.getDeclaringClass().getName();
						Tr.error(tc, "JIT_INVALID_SUBCLASS_REMOTE_EX_CNTR5102E",
								new Object[]{exception.getName(), method.getName(), className});
						throw new EJBConfigurationException("Application exception " + exception.getName()
								+ " defined on method " + method.getName() + " of interface " + className
								+ " must not subclass java.rmi.RemoteException.");
					}
				} else if (!RuntimeException.class.isAssignableFrom(exception)
						&& !Error.class.isAssignableFrom(exception)) {
					if (!Exception.class.isAssignableFrom(exception)) {
						className = method.getDeclaringClass().getName();
						Tr.error(tc, "JIT_INVALID_NOT_EXCEPTION_SUBCLASS_CNTR5107E",
								new Object[]{exception.getName(), method.getName(), className});
						throw new EJBConfigurationException("The " + exception.getName()
								+ " application exception defined on the " + method.getName() + " method of the "
								+ className + " class must be defined as a subclass of the java.lang.Exception class.");
					}
				} else if (target != DeploymentTarget.STUB
						&& (target != DeploymentTarget.WRAPPER || declaredUncheckedAreSystemExceptions)) {
					continue;
				}

				Class checkedEx;
				if (target == DeploymentTarget.WRAPPER) {
					boolean add = true;
					Iterator iter = checkedExceptions.iterator();

					while (iter.hasNext()) {
						checkedEx = (Class) iter.next();
						if (exception.isAssignableFrom(checkedEx)) {
							if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
								Tr.debug(tc, "getCheckedExceptions: ignoring " + checkedEx.getName() + ", subclass of "
										+ exception.getName());
							}

							iter.remove();
						} else if (checkedEx.isAssignableFrom(exception)) {
							if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
								Tr.debug(tc, "getCheckedExceptions: ignoring " + exception.getName() + ", subclass of "
										+ checkedEx.getName());
							}

							add = false;
							break;
						}
					}

					if (add) {
						checkedExceptions.add(exception);
					}
				} else {
					int numChecked = checkedExceptions.size();

					int j;
					for (j = 0; j < numChecked; ++j) {
						checkedEx = (Class) checkedExceptions.get(j);
						if (checkedEx.isAssignableFrom(exception)) {
							break;
						}
					}

					checkedExceptions.add(j, exception);
				}
			}
		}

		if (isRmiRemote && !throwsRemoteException) {
			String className = method.getDeclaringClass().getName();
			Tr.error(tc, "JIT_MISSING_REMOTE_EX_CNTR5104E", new Object[]{method.getName(), className});
			throw new EJBConfigurationException("Method " + method.getName() + " of interface " + className
					+ " must throw java.rmi.RemoteException");
		} else {
			return (Class[]) checkedExceptions.toArray(new Class[checkedExceptions.size()]);
		}
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		DeclaredUncheckedAreSystemExceptions = System
				.getProperty("com.ibm.websphere.ejbcontainer.declaredUncheckedAreSystemExceptions", "true")
				.equalsIgnoreCase("true");
		DeclaredRemoteAreApplicationExceptions = Boolean
				.getBoolean("com.ibm.websphere.ejbcontainer.declaredRemoteAreApplicationExceptions");
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "Property: DeclaredUncheckedAreSystemExceptions = " + DeclaredUncheckedAreSystemExceptions);
			Tr.debug(tc,
					"Property: DeclaredRemoteAreApplicationExceptions = " + DeclaredRemoteAreApplicationExceptions);
		}

	}
}