package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.CartesianList.1;
import com.google.common.collect.ImmutableList.Builder;
import com.google.common.math.IntMath;
import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
final class CartesianList<E> extends AbstractList<List<E>> implements RandomAccess {
	private final transient ImmutableList<List<E>> axes;
	private final transient int[] axesSizeProduct;

	static <E> List<List<E>> create(List<? extends List<? extends E>> lists) {
		Builder<List<E>> axesBuilder = new Builder(lists.size());
		Iterator var2 = lists.iterator();

		while (var2.hasNext()) {
			List<? extends E> list = (List) var2.next();
			List<E> copy = ImmutableList.copyOf(list);
			if (copy.isEmpty()) {
				return ImmutableList.of();
			}

			axesBuilder.add(copy);
		}

		return new CartesianList(axesBuilder.build());
	}

	CartesianList(ImmutableList<List<E>> axes) {
		this.axes = axes;
		int[] axesSizeProduct = new int[axes.size() + 1];
		axesSizeProduct[axes.size()] = 1;

		try {
			for (int i = axes.size() - 1; i >= 0; --i) {
				axesSizeProduct[i] = IntMath.checkedMultiply(axesSizeProduct[i + 1], ((List) axes.get(i)).size());
			}
		} catch (ArithmeticException var4) {
			throw new IllegalArgumentException("Cartesian product too large; must have size at most Integer.MAX_VALUE");
		}

		this.axesSizeProduct = axesSizeProduct;
	}

	private int getAxisIndexForProductIndex(int index, int axis) {
		return index / this.axesSizeProduct[axis + 1] % ((List) this.axes.get(axis)).size();
	}

	public int indexOf(Object o) {
		if (!(o instanceof List)) {
			return -1;
		} else {
			List<?> list = (List) o;
			if (list.size() != this.axes.size()) {
				return -1;
			} else {
				ListIterator<?> itr = list.listIterator();

				int computedIndex;
				int axisIndex;
				int elemIndex;
				for (computedIndex = 0; itr
						.hasNext(); computedIndex += elemIndex * this.axesSizeProduct[axisIndex + 1]) {
					axisIndex = itr.nextIndex();
					elemIndex = ((List) this.axes.get(axisIndex)).indexOf(itr.next());
					if (elemIndex == -1) {
						return -1;
					}
				}

				return computedIndex;
			}
		}
	}

	public ImmutableList<E> get(int index) {
      Preconditions.checkElementIndex(index, this.size());
      return new 1(this, index);
   }

	public int size() {
		return this.axesSizeProduct[0];
	}

	public boolean contains(@NullableDecl Object o) {
		return this.indexOf(o) != -1;
	}
}