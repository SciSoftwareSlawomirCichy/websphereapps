package com.google.inject.tools.jmx;

public interface ManagedBindingMBean {
	String getSource();

	String getProvider();

	String getKey();
}