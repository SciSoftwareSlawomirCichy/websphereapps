package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.managedobject.ManagedObject;
import java.rmi.RemoteException;

public class BMStatefulBeanO extends StatefulBeanO {
	private static final String CLASS_NAME = BMStatefulBeanO.class.getName();
	private static final TraceComponent tc;

	public BMStatefulBeanO(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		super(c, mo, b, h);
	}

	public final synchronized boolean enlist(ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "enlist: " + this.stateStrs[this.state], new Object[]{tx, this.currentTx});
		}

		boolean result = false;
		switch (this.state) {
			case 2 :
			case 9 :
			case 11 :
				if (this.currentTx != null) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist: unexpected non-null currentTx");
					}

					throw new InvalidBeanOStateException(this.stateStrs[this.state], "TX_METHOD_READY");
				}

				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "enlist: false - unexpected state!");
				}

				return false;
			case 3 :
				if (this.currentTx != null) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist: unexpected non-null currentTx");
					}

					throw new BeanNotReentrantException(
							this.stateStrs[this.state] + ": enlist: unexpected non-null currentTx");
				}

				if (tx != null) {
					result = tx.enlist(this);
					this.currentTx = tx;
					this.setState(5);
				}

				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "enlist: " + result + ": " + this.stateStrs[this.state]);
				}

				return result;
			case 4 :
				if (this.currentTx != null) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist: unexpected non-null currentTx");
					}

					throw new InvalidBeanOStateException(this.stateStrs[this.state], "TX_METHOD_READY");
				} else {
					if (tx == null) {
						if (isTraceOn && tc.isEntryEnabled()) {
							Tr.exit(tc, "enlist: reentrant call from different thread");
						}

						throw new BeanNotReentrantException(StateStrs[this.state] + ": wrong thread");
					}

					result = tx.enlist(this);
					this.currentTx = tx;
					this.setState(6);
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist: " + result + ": " + this.stateStrs[this.state]);
					}

					return result;
				}
			case 5 :
				if (tx != this.currentTx) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist: unexpected non-null currentTx");
					}

					String expected = "METHOD_READY";
					if (this.currentTx == null) {
						expected = "MAYBE_RESUME_DID_NOT_OCCUR";
					}

					throw new InvalidBeanOStateException(this.stateStrs[this.state], expected);
				}

				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "enlist: false");
				}

				return false;
			case 6 :
			case 7 :
			case 8 :
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "enlist: not re-entrant");
				}

				if (this.currentTx != tx) {
					throw new BeanNotReentrantException(StateStrs[this.state] + ": wrong transaction");
				}

				throw new BeanNotReentrantException(this.stateStrs[this.state]);
			case 10 :
			default :
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "enlist: invalid state: " + this.stateStrs[this.state]);
				}

				throw new InvalidBeanOStateException(this.stateStrs[this.state],
						"METHOD_READY | TX_METHOD_READY | IN_METHOD");
			case 12 :
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "enlist: cannot enter transaction");
				}

				throw new BeanNotReentrantException(StateStrs[this.state] + ": cannot enter transaction");
		}
	}

	public synchronized void postInvoke(int id, EJSDeployedSupport s) throws RemoteException {
		super.postInvoke(id, s);
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "postInvoke");
		}

		if (this.ivSfFailoverClient != null) {
			if (this.ivContainerTx == null) {
				this.ivContainerTx = this.container.getCurrentTx(false);
			}

			ContainerAS containerAS = this.ivContainerTx.getContainerAS();
			if (containerAS == null) {
				if (this.ivContainerTx.isBmtActive(s.methodInfo)) {
					this.ivSfFailoverClient.stickyUOW(this.beanId, true);
				} else {
					this.ivSfFailoverClient.stickyUOW(this.beanId, false);
				}
			} else if (containerAS.isBmasActive(s.methodInfo)) {
				this.ivSfFailoverClient.stickyUOW(this.beanId, true);
			} else {
				this.ivSfFailoverClient.stickyUOW(this.beanId, false);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "postInvoke");
		}

	}

	public final synchronized void commit(ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "commit: " + this.stateStrs[this.state], new Object[]{tx, this.currentTx});
		}

		if (this.removed) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "commit: removed");
			}

		} else {
			switch (this.state) {
				case 7 :
					this.setState(3);
					break;
				case 8 :
					this.setState(4);
					break;
				default :
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "invalid state: " + this.state);
					}

					throw new InvalidBeanOStateException(StateStrs[this.state],
							"COMMITTING_IN_METHOD | COMMITTING_OUTSIDE_METHOD");
			}

			if (tx.ivRemoveBeanO == this) {
				this.completeRemoveMethod(tx);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "commit: " + this.stateStrs[this.state]);
			}

		}
	}

	public final synchronized void rollback(ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "rollback: " + this.stateStrs[this.state], new Object[]{tx, this.currentTx});
		}

		if (this.removed) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "rollback: removed");
			}

		} else {
			switch (this.state) {
				case 5 :
				case 7 :
					this.setState(3);
					break;
				case 6 :
				case 8 :
				case 12 :
					this.setState(4);
					break;
				case 9 :
				case 10 :
				case 11 :
				default :
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "invalid state: " + this.state);
					}

					throw new InvalidBeanOStateException(StateStrs[this.state],
							"TX_METHOD_READY | COMMITTING_IN_METHOD | COMMITTING_OUTSIDE_METHOD");
			}

			if (tx.ivRemoveBeanO == this) {
				this.completeRemoveMethod(tx);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "rollback: " + this.stateStrs[this.state]);
			}

		}
	}

	public final synchronized void beforeCompletion() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "beforeCompletion: " + this.stateStrs[this.state], this.currentTx);
		}

		if (this.removed) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "beforeCompletion: removed");
			}

		} else {
			switch (this.state) {
				case 0 :
				case 3 :
				case 4 :
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "beforeCompletion: asynch rollback: " + this.stateStrs[this.state]);
					}

					return;
				case 1 :
				case 2 :
				default :
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "invalid state: " + this.state);
					}

					throw new InvalidBeanOStateException(StateStrs[this.state], "TX_IN_METHOD | TX_METHOD_READY");
				case 5 :
					this.setState(7);
					break;
				case 6 :
					this.setState(8);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "beforeCompletion: " + this.stateStrs[this.state]);
			}

		}
	}

	public void setRollbackOnly() {
		throw new IllegalStateException();
	}

	public boolean getRollbackOnly() {
		throw new IllegalStateException();
	}

	boolean eligibleForLock(EJSDeployedSupport methodContext, ContainerTx tx) {
		if (this.state == 5 && this.currentTx != null && this.currentTx.isTransactionGlobal()
				&& !tx.isTransactionGlobal()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "eligibleForLock : ignoring local tran : " + tx);
			}

			return super.eligibleForLock(methodContext, this.currentTx)
					? this.container.transitionToStickyGlobalTran(this.beanId, tx, this.currentTx)
					: false;
		} else {
			return super.eligibleForLock(methodContext, tx);
		}
	}

	protected boolean eligibleForUnlock() {
		return this.state == 3 || this.state == 5 || this.state == 0;
	}

	public final String toString() {
		return this.toString("BMStatefulBeanO");
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}