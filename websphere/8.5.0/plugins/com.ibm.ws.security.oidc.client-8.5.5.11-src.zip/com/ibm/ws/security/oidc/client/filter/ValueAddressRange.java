package com.ibm.ws.security.oidc.client.filter;

public class ValueAddressRange implements IValue {
	private IPAddressRange range;

	public ValueAddressRange(String ipRange) throws FilterException {
		this.range = new IPAddressRange(ipRange);
	}

	public boolean equals(IValue ip) throws FilterException {
		return this.range.inRange(((ValueIPAddress) ip).getIP());
	}

	public boolean greaterThan(IValue ip) throws FilterException {
		return this.range.aboveRange(((ValueIPAddress) ip).getIP());
	}

	public boolean lessThan(IValue ip) throws FilterException {
		return this.range.belowRange(((ValueIPAddress) ip).getIP());
	}

	public boolean containedBy(IValue ip) throws FilterException {
		return this.range.inRange(((ValueIPAddress) ip).getIP());
	}
}