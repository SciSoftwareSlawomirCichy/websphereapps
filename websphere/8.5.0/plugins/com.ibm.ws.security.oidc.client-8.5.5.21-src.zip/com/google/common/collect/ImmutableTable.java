package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.MoreObjects;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableTable.Builder;
import com.google.common.collect.ImmutableTable.SerializedForm;
import com.google.common.collect.Table.Cell;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public abstract class ImmutableTable<R, C, V> extends AbstractTable<R, C, V> implements Serializable {
	public static <R, C, V> ImmutableTable<R, C, V> of() {
		return SparseImmutableTable.EMPTY;
	}

	public static <R, C, V> ImmutableTable<R, C, V> of(R rowKey, C columnKey, V value) {
		return new SingletonImmutableTable(rowKey, columnKey, value);
	}

	public static <R, C, V> ImmutableTable<R, C, V> copyOf(Table<? extends R, ? extends C, ? extends V> table) {
		if (table instanceof ImmutableTable) {
			ImmutableTable<R, C, V> parameterizedTable = (ImmutableTable) table;
			return parameterizedTable;
		} else {
			return copyOf((Iterable) table.cellSet());
		}
	}

	private static <R, C, V> ImmutableTable<R, C, V> copyOf(
			Iterable<? extends Cell<? extends R, ? extends C, ? extends V>> cells) {
		Builder<R, C, V> builder = builder();
		Iterator var2 = cells.iterator();

		while (var2.hasNext()) {
			Cell<? extends R, ? extends C, ? extends V> cell = (Cell) var2.next();
			builder.put(cell);
		}

		return builder.build();
	}

	public static <R, C, V> Builder<R, C, V> builder() {
		return new Builder();
	}

	static <R, C, V> Cell<R, C, V> cellOf(R rowKey, C columnKey, V value) {
		return Tables.immutableCell(Preconditions.checkNotNull(rowKey, "rowKey"),
				Preconditions.checkNotNull(columnKey, "columnKey"), Preconditions.checkNotNull(value, "value"));
	}

	public ImmutableSet<Cell<R, C, V>> cellSet() {
		return (ImmutableSet) super.cellSet();
	}

	abstract ImmutableSet<Cell<R, C, V>> createCellSet();

	final UnmodifiableIterator<Cell<R, C, V>> cellIterator() {
		throw new AssertionError("should never be called");
	}

	public ImmutableCollection<V> values() {
		return (ImmutableCollection) super.values();
	}

	abstract ImmutableCollection<V> createValues();

	final Iterator<V> valuesIterator() {
		throw new AssertionError("should never be called");
	}

	public ImmutableMap<R, V> column(C columnKey) {
		Preconditions.checkNotNull(columnKey, "columnKey");
		return (ImmutableMap) MoreObjects.firstNonNull((ImmutableMap) this.columnMap().get(columnKey),
				ImmutableMap.of());
	}

	public ImmutableSet<C> columnKeySet() {
		return this.columnMap().keySet();
	}

	public abstract ImmutableMap<C, Map<R, V>> columnMap();

	public ImmutableMap<C, V> row(R rowKey) {
		Preconditions.checkNotNull(rowKey, "rowKey");
		return (ImmutableMap) MoreObjects.firstNonNull((ImmutableMap) this.rowMap().get(rowKey), ImmutableMap.of());
	}

	public ImmutableSet<R> rowKeySet() {
		return this.rowMap().keySet();
	}

	public abstract ImmutableMap<R, Map<C, V>> rowMap();

	public boolean contains(@NullableDecl Object rowKey, @NullableDecl Object columnKey) {
		return this.get(rowKey, columnKey) != null;
	}

	public boolean containsValue(@NullableDecl Object value) {
		return this.values().contains(value);
	}

	@Deprecated
	public final void clear() {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final V put(R rowKey, C columnKey, V value) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final void putAll(Table<? extends R, ? extends C, ? extends V> table) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final V remove(Object rowKey, Object columnKey) {
		throw new UnsupportedOperationException();
	}

	abstract SerializedForm createSerializedForm();

	final Object writeReplace() {
		return this.createSerializedForm();
	}
}