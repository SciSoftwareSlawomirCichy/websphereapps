package com.ibm.ws.ffdc;

import com.ibm.ws.exception.WsException;

public class NoSuchKeyException extends WsException {
	private static final long serialVersionUID = 5595336476404302007L;

	NoSuchKeyException() {
	}

	NoSuchKeyException(String message) {
		super(message);
	}
}