package com.ibm.ws.security.oidc.client.filter;

public class NotContainsCondition extends ContainsCondition {
	public NotContainsCondition(String key, IValue value) {
		super(key, value);
	}

	public boolean checkCondition(IValue test) throws FilterException {
		return !super.checkCondition(test);
	}

	public String getOperand() {
		return "!=";
	}
}