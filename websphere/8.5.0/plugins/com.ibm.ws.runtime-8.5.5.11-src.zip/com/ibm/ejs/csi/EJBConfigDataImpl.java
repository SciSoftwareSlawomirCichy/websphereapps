package com.ibm.ejs.csi;

import com.ibm.ejs.container.BeanMetaData;
import com.ibm.websphere.cpi.PersisterConfigData;
import com.ibm.websphere.csi.EJBComponentMetaData;
import com.ibm.websphere.csi.EJBConfigData;
import com.ibm.websphere.csi.J2EEName;
import java.util.Properties;
import javax.naming.Context;

public class EJBConfigDataImpl implements EJBConfigData {
	private Object ejbJar;
	private Object enterpriseBean;
	private Object extensions;
	private PersisterConfigData persisterConfigData;
	private J2EEName j2eeName;
	private Context javaNameSpaceContext;
	private Properties initialContextProperties;
	private ClassLoader classLoader;
	private transient BeanMetaData ivBMD;
	private static final long serialVersionUID = 8280336484044619683L;

	public EJBConfigDataImpl(BeanMetaData bmd, PersisterConfigData persisterConfigData, Context javaNameSpaceContext,
			Properties initialContextProperties) {
		this.ivBMD = bmd;
		this.ejbJar = bmd.wccm.ejbjar;
		this.enterpriseBean = bmd.wccm.enterpriseBean;
		this.extensions = bmd.wccm.getExtension();
		this.persisterConfigData = persisterConfigData;
		this.j2eeName = bmd.j2eeName;
		this.javaNameSpaceContext = javaNameSpaceContext;
		this.initialContextProperties = initialContextProperties;
		this.classLoader = bmd.classLoader;
	}

	public Object getEJBJarDeploymentData() {
		return this.ejbJar;
	}

	public Object getDeploymentData() {
		return this.enterpriseBean;
	}

	public Object getDeploymentExtn() {
		return this.extensions;
	}

	public PersisterConfigData getPersisterConfigData() {
		return this.persisterConfigData;
	}

	public J2EEName getJ2EEName() {
		return this.j2eeName;
	}

	public Context getJavaNameSpaceContext() {
		return this.javaNameSpaceContext;
	}

	public Properties getInitialContextProperties() {
		return this.initialContextProperties;
	}

	public ClassLoader getClassLoader() {
		return this.classLoader;
	}

	public final Properties getActivationConfigProperties() {
		return this.ivBMD.ivActivationConfig;
	}

	public final String getMessageListenerPortName() {
		return this.ivBMD.ivMessageListenerPortName;
	}

	public final String getMessageDestinationJndiName() {
		return this.ivBMD.ivMessageDestinationJndiName;
	}

	public EJBComponentMetaData getEJBComponentMetaData() {
		return (EJBComponentMetaData) this.ivBMD;
	}

	public void setContext(Context context) {
		this.javaNameSpaceContext = context;
	}
}