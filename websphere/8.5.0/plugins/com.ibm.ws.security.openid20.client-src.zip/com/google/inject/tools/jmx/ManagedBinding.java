package com.google.inject.tools.jmx;

import com.google.inject.Binding;

class ManagedBinding implements ManagedBindingMBean {
	final Binding binding;

	ManagedBinding(Binding binding) {
		this.binding = binding;
	}

	public String getSource() {
		return this.binding.getSource().toString();
	}

	public String getKey() {
		return this.binding.getKey().toString();
	}

	public String getProvider() {
		return this.binding.getProvider().toString();
	}
}