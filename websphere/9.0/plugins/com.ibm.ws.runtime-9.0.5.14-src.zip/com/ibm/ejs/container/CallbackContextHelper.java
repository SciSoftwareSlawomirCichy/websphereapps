package com.ibm.ejs.container;

import com.ibm.ejs.container.CallbackContextHelper.Contexts;
import com.ibm.ejs.container.CallbackContextHelper.Tx;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.tx.jta.embeddable.EmbeddableTransactionManagerFactory;
import com.ibm.websphere.csi.CSIException;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.LocalTransaction.LocalTransactionCurrent;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.tx.embeddable.EmbeddableWebSphereTransactionManager;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import com.ibm.ws.uow.embeddable.SystemException;
import com.ibm.ws.uow.embeddable.UOWToken;
import java.util.Map;
import javax.transaction.TransactionRolledbackException;

class CallbackContextHelper {
	private static final String CLASS_NAME = CallbackContextHelper.class.getName();
	private static final TraceComponent tc = Tr.register(CallbackContextHelper.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private final BeanO ivBeanO;
	private UOWToken ivUowToken;
	protected LocalTransactionCurrent ivLocalTransactionCurrent;
	protected EmbeddableWebSphereTransactionManager ivTransactionManager;
	private EJBThreadData ivThreadData;
	private Contexts ivPopContexts;
	private int ivSavedLifecycleMethodContextIndex;
	private Tx ivSavedLifecycleMethodBeginTx;
	private Map<String, Object> ivSavedLifecycleContextData;

	CallbackContextHelper(BeanO beanO) {
		this.ivBeanO = beanO;
	}

	public void begin(Tx beginTx, Contexts pushContexts) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "begin: tx=" + beginTx + ", contexts=" + pushContexts);
		}

		this.ivThreadData = EJSContainer.getThreadData();
		if (pushContexts == Contexts.All) {
			this.ivThreadData.pushContexts(this.ivBeanO);
		} else {
			this.ivThreadData.pushCallbackBeanO(this.ivBeanO);
		}

		this.ivPopContexts = pushContexts;
		this.ivSavedLifecycleContextData = this.ivThreadData.ivLifecycleContextData;
		this.ivThreadData.ivLifecycleContextData = null;
		this.ivSavedLifecycleMethodContextIndex = this.ivThreadData.ivLifecycleMethodContextIndex;
		this.ivThreadData.ivLifecycleMethodContextIndex = this.ivThreadData.getNumMethodContexts();
		if (beginTx == Tx.CompatLTC) {
			beginTx = this.ivBeanO.home.beanMetaData.ivModuleVersion >= 30 ? Tx.LTC : null;
		}

		this.ivSavedLifecycleMethodBeginTx = this.ivThreadData.ivLifecycleMethodBeginTx;
		this.ivThreadData.ivLifecycleMethodBeginTx = beginTx;
		if (beginTx != null) {
			if (this.ivUowToken != null) {
				throw new CSIException("Cannot begin until prior TX is resumed");
			}

			UOWCurrent uowCurrent = EmbeddableTransactionManagerFactory.getUOWCurrent();
			if (uowCurrent != null) {
				try {
					this.ivUowToken = this.ivBeanO.container.ivUOWManager.suspend();
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "Suspended TX/LTC cntxt: " + this.ivUowToken);
					}
				} catch (SystemException var7) {
					FFDCFilter.processException(var7, CLASS_NAME + ".begin", "140", this);
					throw new CSIException("Cannot begin due to failure in suspend.", var7);
				}
			}

			boolean ltc = beginTx == Tx.LTC;
			if (ltc) {
				this.ivLocalTransactionCurrent = EmbeddableTransactionManagerFactory.getLocalTransactionCurrent();
				this.ivLocalTransactionCurrent.begin();
				if (isTraceOn && tc.isEventEnabled()) {
					LocalTransactionCoordinator lCoord = this.ivLocalTransactionCurrent.getLocalTranCoord();
					if (lCoord != null) {
						Tr.event(tc, "Began LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
					} else {
						Tr.event(tc, "Began LTC cntxt: null Coordinator!");
					}
				}
			} else {
				try {
					this.ivTransactionManager = EmbeddableTransactionManagerFactory.getTransactionManager();
					this.ivTransactionManager.begin();
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "Began TX cntxt: " + this.ivTransactionManager.getTransaction());
					}
				} catch (Exception var8) {
					FFDCFilter.processException(var8, CLASS_NAME + ".begin", "214", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Begin global tx failed", var8);
					}

					throw new CSIException("Begin global tx failed", var8);
				}
			}

			this.ivBeanO.container.getCurrentTx((SynchronizationRegistryUOWScope) this.getUOWCoordinator(), ltc);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "begin");
		}

	}

	void complete(boolean commit) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "complete called with commit argument set to: " + commit);
		}

		if (this.ivPopContexts != null) {
			if (this.ivPopContexts == Contexts.All) {
				this.ivThreadData.popContexts();
			} else {
				this.ivThreadData.popCallbackBeanO();
			}

			this.ivThreadData.ivLifecycleContextData = this.ivSavedLifecycleContextData;
			this.ivThreadData.ivLifecycleMethodContextIndex = this.ivSavedLifecycleMethodContextIndex;
			this.ivThreadData.ivLifecycleMethodBeginTx = this.ivSavedLifecycleMethodBeginTx;
			this.ivThreadData = null;
		}

		boolean var13 = false;

		try {
			var13 = true;
			int status;
			if (this.ivTransactionManager != null) {
				if (commit) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Committing TX cntxt: " + this.ivTransactionManager.getTransaction());
					}

					status = this.ivTransactionManager.getStatus();
					if (status != 1 && status != 9 && status != 4) {
						this.ivTransactionManager.commit();
						var13 = false;
					} else {
						try {
							this.ivTransactionManager.completeTxTimeout();
						} catch (TransactionRolledbackException var16) {
							this.ivTransactionManager.rollback();
							throw var16;
						}

						this.ivTransactionManager.rollback();
						var13 = false;
					}
				} else {
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "Rolling back TX cntxt due to bean exception: "
								+ this.ivTransactionManager.getTransaction());
					}

					this.ivTransactionManager.rollback();
					var13 = false;
				}
			} else if (this.ivLocalTransactionCurrent != null) {
				status = commit ? 0 : 1;
				if (isTraceOn && tc.isEventEnabled()) {
					LocalTransactionCoordinator lCoord = this.ivLocalTransactionCurrent.getLocalTranCoord();
					if (lCoord != null) {
						Tr.event(tc, "Completing LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
					} else {
						Tr.event(tc, "Completing LTC cntxt: null Coordinator!");
					}
				}

				this.ivLocalTransactionCurrent.complete(status);
				var13 = false;
			} else {
				var13 = false;
			}
		} catch (Throwable var17) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "unspecified UOW completion failure: " + var17, var17);
			}

			throw new CSIException("unspecified UOW completion failure: " + var17, var17);
		} finally {
			if (var13) {
				if (this.ivUowToken != null) {
					if (isTraceOn) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "complete is resuming UOW with UOWToken = " + this.ivUowToken);
						}

						if (tc.isEventEnabled()) {
							Tr.event(tc, "Resuming TX/LTC cntxt: " + this.ivUowToken);
						}
					}

					UOWToken token = this.ivUowToken;
					this.ivUowToken = null;

					try {
						this.ivBeanO.container.ivUOWManager.resume(token);
					} catch (SystemException var14) {
						FFDCFilter.processException(var14, CLASS_NAME + ".complete", "216", this);
						throw new CSIException("Cannot complete due to failure in resume.", var14);
					}
				}

			}
		}

		if (this.ivUowToken != null) {
			if (isTraceOn) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "complete is resuming UOW with UOWToken = " + this.ivUowToken);
				}

				if (tc.isEventEnabled()) {
					Tr.event(tc, "Resuming TX/LTC cntxt: " + this.ivUowToken);
				}
			}

			UOWToken token = this.ivUowToken;
			this.ivUowToken = null;

			try {
				this.ivBeanO.container.ivUOWManager.resume(token);
			} catch (SystemException var15) {
				FFDCFilter.processException(var15, CLASS_NAME + ".complete", "216", this);
				throw new CSIException("Cannot complete due to failure in resume.", var15);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "complete");
		}

	}

	private UOWCoordinator getUOWCoordinator() {
		UOWCoordinator uowCoord = null;
		UOWCurrent uowCurrent = EmbeddableTransactionManagerFactory.getUOWCurrent();
		if (uowCurrent != null) {
			uowCoord = uowCurrent.getUOWCoord();
		}

		return uowCoord;
	}

	public void resetContextData() {
		this.ivThreadData.ivLifecycleContextData = null;
	}
}