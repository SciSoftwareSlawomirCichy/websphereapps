package com.ibm.ws.ssl.utils;

import com.ibm.ffdc.Ffdc;
import com.ibm.ffdc.Manager;
import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.config.IncidentStream;
import com.ibm.ws.ssl.config.SSLConfig;
import com.ibm.ws.ssl.config.SSLConfigManager;
import java.util.ConcurrentModificationException;
import java.util.Enumeration;

public class SSLConfigFormatter implements Formatter {
	protected static final String FAILED_TO_FORMAT_SEE_FFDC = "Failed to format see FFDC";
	protected static final String KEY = "key";
	protected static final String VALUE = "value";
	protected static final String NOTE = "Note";
	protected static final String MODIFIED_WHILE_PRINTING = "this object has been modified while printing";
	protected static final String MAP_DOES_NOT_SUPPORT_OP_ENTRY_SET = "this map does not support op: entrySet()";
	protected static final String SUPPORTED_CLASS = "com.ibm.ws.ssl.config.SSLConfig";

	public final void formatTo(Object o, IncidentStream is) {
		if (o == null) {
			is.write("Null collection", "Null collection sent for content collection");
		} else if (o instanceof SSLConfig) {
			this.formatTo(is, (SSLConfig) o);
		} else {
			is.write((String) null, o.toString());
		}

	}

	private void formatTo(IncidentStream is, SSLConfig config) {
		is.write((String) null, '{');

		String val;
		try {
			for (Enumeration e = config.propertyNames(); e.hasMoreElements(); is.write("value", val)) {
				String key = (String) e.nextElement();
				val = config.getProperty(key);
				is.write("key", key);
				if (key.toLowerCase().indexOf("password") != -1) {
					val = SSLConfigManager.mask(val);
				}
			}
		} catch (ConcurrentModificationException var6) {
			is.write("Note", "this object has been modified while printing");
		} catch (UnsupportedOperationException var7) {
			is.write("Note", "this map does not support op: entrySet()");
		} catch (Exception var8) {
			Ffdc ffdc = Manager.Ffdc.getFfdc(var8, this, this.getClass().getName(), "70");
			if (ffdc.isLoggable()) {
				ffdc.log(new Object[0]);
			}

			is.write("Failed to format see FFDC", ffdc.toString());
		}

		is.write((String) null, '}');
	}

	public String[] getSupportedTypeNames() {
		return new String[]{"com.ibm.ws.ssl.config.SSLConfig"};
	}

	public boolean isSupported(Class<?> klass) {
		return "com.ibm.ws.ssl.config.SSLConfig".equals(klass.getName());
	}
}