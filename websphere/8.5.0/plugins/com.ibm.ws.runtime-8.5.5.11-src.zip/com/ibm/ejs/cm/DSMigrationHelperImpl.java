package com.ibm.ejs.cm;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DSMigrationHelperImpl implements DSMigrationHelper {
	private static final TraceComponent tc = Tr.register(DSMigrationHelper.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public Properties migrateDataSourcesXML(String driverClass, Element dataSourceXML) {
		Properties props = new Properties();
		boolean isSybaseDriver = false;
		StringBuffer sybaseProps = null;
		if (driverClass.equals("com.sybase.jdbc2.jdbc.SybDriver") || driverClass.equals("com.sybase.jdbc.SybDriver")) {
			isSybaseDriver = true;
			sybaseProps = new StringBuffer();
		}

		NodeList attrs = dataSourceXML.getChildNodes();

		for (int j = 0; j < attrs.getLength(); ++j) {
			Node node = attrs.item(j);
			if (node.getNodeName().equals("attribute")) {
				Element attr = (Element) node;
				String name = attr.getAttribute("name");
				String value = attr.getAttribute("value");
				if (name != null && value != null) {
					if (isSybaseDriver && !name.equals("disableAutoConnectionCleanup")) {
						if (sybaseProps.length() > 0) {
							sybaseProps.append(";");
						}

						sybaseProps.append(name + "=" + value);
					} else {
						props.setProperty(name, value);
					}
				}
			}
		}

		if (isSybaseDriver) {
			props.setProperty("connectionProperties", sybaseProps.toString());
		}

		return props;
	}

	public Properties migrateDataSource(String driverClass, String urlPrefix, String databaseName,
			String jtaEnabledStr) {
		String methodName = "migrateDataSourceDriver";
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "migrateDataSourceDriver", new Object[]{driverClass, urlPrefix, databaseName, jtaEnabledStr});
		}

		boolean jtaEnabled = Boolean.valueOf(jtaEnabledStr);
		Properties props = null;
		if (driverClass.equals("com.ibm.db2.jdbc.app.DB2Driver") && !System.getProperty("os.name").equals("OS/400")) {
			driverClass = "COM.ibm.db2.jdbc.app.DB2Driver";
		}

		if (!driverClass.equals("COM.ibm.db2.jdbc.app.DB2Driver")
				&& !driverClass.equals("COM.ibm.db2.jdbc.net.DB2Driver")) {
			if (driverClass.equals("com.ibm.as400.access.AS400JDBCDriver")) {
				props = migrateDB2AS400ToolboxJDBCDriver(urlPrefix, databaseName, jtaEnabled);
			} else if (driverClass.equals("com.ibm.db2.jdbc.app.DB2Driver")) {
				props = migrateDB2AS400NativeJDBCDriver(urlPrefix, databaseName, jtaEnabled);
			} else if (driverClass.equals("com.merant.sequelink.jdbc.SequeLinkDriver")) {
				props = migrateMerantJDBCDriver(urlPrefix, databaseName, jtaEnabled);
			} else if (driverClass.equals("oracle.jdbc.driver.OracleDriver")) {
				props = migrateOracleJDBCDriver(urlPrefix, databaseName, jtaEnabled);
			} else if (!driverClass.equals("com.sybase.jdbc2.jdbc.SybDriver")
					&& !driverClass.equals("com.sybase.jdbc.SybDriver")) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Got unknown driverClass: " + driverClass);
				}

				props = new Properties();
				props.setProperty("dataSourceClassName", driverClass);
				props.setProperty("databaseName", databaseName);
			} else {
				props = migrateSybaseJDBCDriver(urlPrefix, databaseName, jtaEnabled);
			}
		} else {
			props = migrateDB2JDBCDriver(urlPrefix, databaseName, jtaEnabled);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "migrateDataSourceDriver", props);
		}

		return props;
	}

	public Properties migrateAdminDotConfig(String dbDriver, String dbUrl, String dbUser, String dbPassword,
			String connectionPoolSize) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "migrateAdminDotConfig", new Object[]{dbDriver, dbUrl, dbUser, connectionPoolSize});
		}

		Properties migratedProps = new Properties();
		String[] params = this.convertUrlToUrlPrefixAndDatabaseName(dbUrl, dbDriver);
		Properties dsProps = this.migrateDataSource(dbDriver, params[0], params[1], "false");
		Enumeration e = dsProps.propertyNames();

		while (e.hasMoreElements()) {
			String propName = (String) e.nextElement();
			migratedProps.setProperty("com.ibm.ejs.sm.adminServer.db" + propName, dsProps.getProperty(propName));
		}

		if (dbUser != null) {
			migratedProps.setProperty("com.ibm.ejs.sm.adminServer.dbuser", dbUser);
		}

		if (connectionPoolSize != null) {
			migratedProps.setProperty("com.ibm.ejs.sm.adminServer.dbmaximumPoolSize", connectionPoolSize);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "migrateAdminDotConfig", migratedProps);
		}

		if (dbPassword != null) {
			migratedProps.setProperty("com.ibm.ejs.sm.adminServer.dbpassword", dbPassword);
		}

		return migratedProps;
	}

	public String[] convertUrlToUrlPrefixAndDatabaseName(String url, String driverClassName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "convertUrlToUrlPrefixAndDatabaseName", new Object[]{url, driverClassName});
		}

		String[] params = new String[2];
		int separatorIndex = false;
		int separatorIndex;
		if (driverClassName.equals("com.merant.sequelink.jdbc.SequeLinkDriver")) {
			separatorIndex = url.indexOf(59);
			if (separatorIndex == -1) {
				params[0] = url;
				params[1] = null;
			} else {
				params[0] = url.substring(0, separatorIndex);
				String properties = url.substring(separatorIndex + 1);
				int dbNameIndex = properties.indexOf("databaseName");
				if (dbNameIndex == -1) {
					params[1] = properties;
				} else if (dbNameIndex == 0) {
					params[1] = properties.substring(13);
				} else {
					separatorIndex = properties.indexOf(59, dbNameIndex);
					if (separatorIndex == -1) {
						params[1] = properties.substring(dbNameIndex + 13) + ";"
								+ properties.substring(0, dbNameIndex - 1);
					} else {
						params[1] = properties.substring(dbNameIndex + 13, separatorIndex + 1)
								+ properties.substring(0, dbNameIndex - 1) + properties.substring(separatorIndex);
					}
				}
			}
		} else {
			if (!driverClassName.equals("com.sybase.jdbc2.jdbc.SybDriver")
					&& !driverClassName.equals("com.sybase.jdbc.SybDriver")) {
				separatorIndex = url.lastIndexOf(58);
			} else {
				separatorIndex = url.indexOf(47);
			}

			if (separatorIndex == -1) {
				params[0] = url;
				params[1] = null;
			} else {
				params[0] = url.substring(0, separatorIndex);
				params[1] = url.substring(separatorIndex + 1);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "convertUrlToUrlPrefixAndDatabaseName", params);
		}

		return params;
	}

	private static Properties migrateDB2JDBCDriver(String urlPrefix, String databaseName, boolean jtaEnabled) {
		Properties props = new Properties();
		if (jtaEnabled) {
			props.setProperty("dataSourceClassName", "COM.ibm.db2.jdbc.DB2XADataSource");
		} else {
			props.setProperty("dataSourceClassName", "COM.ibm.db2.jdbc.DB2ConnectionPoolDataSource");
		}

		props.setProperty("databaseName", databaseName);
		return props;
	}

	private static Properties migrateDB2AS400ToolboxJDBCDriver(String urlPrefix, String databaseName,
			boolean jtaEnabled) {
		Properties props = new Properties();
		if (jtaEnabled) {
			props.setProperty("dataSourceClassName", "com.ibm.as400.access.AS400JDBCXADataSource");
		} else {
			props.setProperty("dataSourceClassName", "com.ibm.as400.access.AS400JDBCConnectionPoolDataSource");
		}

		migrateDB2AS400JDBCDriver(urlPrefix, databaseName, jtaEnabled, props, "serverName");
		return props;
	}

	private static Properties migrateDB2AS400NativeJDBCDriver(String urlPrefix, String databaseName,
			boolean jtaEnabled) {
		Properties props = new Properties();
		if (jtaEnabled) {
			props.setProperty("dataSourceClassName", "com.ibm.db2.jdbc.app.DB2StdXADataSource");
		} else {
			props.setProperty("dataSourceClassName", "com.ibm.db2.jdbc.app.DB2StdConnectionPoolDataSource");
		}

		migrateDB2AS400JDBCDriver(urlPrefix, databaseName, jtaEnabled, props, "databaseName");
		return props;
	}

	private static void migrateDB2AS400JDBCDriver(String urlPrefix, String databaseName, boolean jtaEnabled,
			Properties props, String serverNameKey) {
		StringTokenizer urlStringT = new StringTokenizer(databaseName, ";");

		while (urlStringT.hasMoreTokens()) {
			String stringChunk = urlStringT.nextToken();
			if (stringChunk.charAt(0) == '/') {
				if (stringChunk.charAt(1) == '/') {
					parseServerName(stringChunk.substring(2), props, serverNameKey);
				} else {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "migrateDB2AS400JDBCDriver", "Invalid URL - ignoring leading slash.");
					}

					parseServerName(stringChunk.substring(1), props, serverNameKey);
				}
			} else if (stringChunk.indexOf(61) >= 0) {
				setAS400Property(stringChunk, props);
			} else {
				parseServerName(stringChunk, props, serverNameKey);
			}
		}

	}

	private static void parseServerName(String serverString, Properties props, String serverNameKey) {
		int slashIndex = serverString.indexOf(47);
		if (slashIndex >= 0) {
			props.setProperty(serverNameKey, serverString.substring(0, slashIndex));
			props.setProperty("libraries", serverString.substring(slashIndex + 1));
		} else {
			props.setProperty(serverNameKey, serverString);
		}

	}

	private static void setAS400Property(String propertyPair, Properties props) {
		int eqIndex = propertyPair.indexOf(61);
		if (eqIndex != -1) {
			String key = propertyPair.substring(0, eqIndex);
			String value = propertyPair.substring(eqIndex + 1);
			if (key.equals("bidirectional string type")) {
				key = "bidiStringType";
			} else if (key.equals("block enabled")) {
				if (!value.equals("false")) {
					return;
				}

				key = "blockSize";
				value = "0";
			} else if (key.equals("CURSORHOLD")) {
				key = "cursorHold";
			} else if (key.equals("errors")) {
				key = "errorsOption";
			} else if (key.equals("naming")) {
				key = "namingOption";
			} else if (key.equals("trace")) {
				key = "traceActive";
			} else if (key.equals("transaction isolation")) {
				key = "transactionIsolationLevel";
			}

			for (int spIndex = key.indexOf(" "); spIndex != -1; spIndex = key.indexOf(" ", spIndex)) {
				key = key.substring(0, spIndex) + Character.toUpperCase(key.charAt(spIndex + 1))
						+ key.substring(spIndex + 2);
			}

			props.setProperty(key, value);
		}
	}

	private static Properties migrateMerantJDBCDriver(String urlPrefix, String databaseName, boolean jtaEnabled) {
		Properties props = new Properties();
		props.setProperty("dataSourceClassName", "com.merant.sequelink.jdbcx.datasource.SequeLinkDataSource");
		int slashIndex = urlPrefix.lastIndexOf(47);
		int colonIndex = urlPrefix.indexOf(":", slashIndex);
		props.setProperty("serverName", urlPrefix.substring(slashIndex + 1, colonIndex));
		props.setProperty("portNumber", urlPrefix.substring(colonIndex + 1));
		if (databaseName != null) {
			int semiIndex = databaseName.indexOf(59);
			if (semiIndex == -1) {
				props.setProperty("databaseName", databaseName);
			} else {
				props.setProperty("databaseName", databaseName.substring(0, semiIndex));

				int semiIndexNext;
				for (boolean var7 = true; semiIndex != -1; semiIndex = semiIndexNext) {
					semiIndexNext = databaseName.indexOf(59, semiIndex + 1);
					int eqIndex = databaseName.indexOf(61, semiIndex + 1);
					String key = null;
					String value = null;
					key = databaseName.substring(semiIndex + 1, eqIndex);
					if (semiIndexNext == -1) {
						value = databaseName.substring(eqIndex + 1);
					} else {
						value = databaseName.substring(eqIndex + 1, semiIndexNext);
					}

					props.setProperty(key, value);
				}
			}
		}

		return props;
	}

	private static Properties migrateOracleJDBCDriver(String urlPrefix, String databaseName, boolean jtaEnabled) {
		Properties props = new Properties();
		if (jtaEnabled) {
			props.setProperty("dataSourceClassName", "oracle.jdbc.xa.client.OracleXADataSource");
		} else {
			props.setProperty("dataSourceClassName", "oracle.jdbc.pool.OracleConnectionPoolDataSource");
		}

		props.setProperty("URL", urlPrefix + ":" + databaseName);
		return props;
	}

	private static Properties migrateSybaseJDBCDriver(String urlPrefix, String databaseName, boolean jtaEnabled) {
		Properties props = new Properties();
		if (jtaEnabled) {
			props.setProperty("dataSourceClassName", "com.sybase.jdbc2.jdbc.SybXADataSource");
		} else {
			props.setProperty("dataSourceClassName", "com.sybase.jdbc2.jdbc.SybConnectionPoolDataSource");
		}

		int tdsIndex = urlPrefix.indexOf("Tds:");
		int lastColonIndex = urlPrefix.lastIndexOf(58);
		props.setProperty("serverName", urlPrefix.substring(tdsIndex + 4, lastColonIndex));
		props.setProperty("portNumber", urlPrefix.substring(lastColonIndex + 1));
		if (databaseName != null) {
			int questionIndex = databaseName.indexOf(63);
			if (questionIndex == -1) {
				props.setProperty("databaseName", databaseName);
			} else {
				props.setProperty("databaseName", databaseName.substring(0, questionIndex));
				String properties = databaseName.substring(questionIndex + 1);
				String ourProperties = properties.replace('&', ';');
				props.setProperty("connectionProperties", ourProperties);
			}
		}

		return props;
	}
}