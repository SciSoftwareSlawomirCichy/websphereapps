package com.ibm.ws.wim.configmodel;

public interface DynamicMemberAttributesType {
	String getName();

	void setName(String var1);

	String getObjectClass();

	void setObjectClass(String var1);
}