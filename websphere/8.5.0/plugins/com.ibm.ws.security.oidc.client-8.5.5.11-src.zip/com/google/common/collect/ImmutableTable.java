package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableSet.Builder;
import com.google.common.collect.Table.Cell;
import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nullable;

@GwtCompatible
public abstract class ImmutableTable<R, C, V> implements Table<R, C, V> {
	public static final <R, C, V> ImmutableTable<R, C, V> of() {
		return EmptyImmutableTable.INSTANCE;
	}

	public static final <R, C, V> ImmutableTable<R, C, V> of(R rowKey, C columnKey, V value) {
		return new SingletonImmutableTable(rowKey, columnKey, value);
	}

	public static final <R, C, V> ImmutableTable<R, C, V> copyOf(Table<? extends R, ? extends C, ? extends V> table) {
		if (table instanceof ImmutableTable) {
			ImmutableTable<R, C, V> parameterizedTable = (ImmutableTable) table;
			return parameterizedTable;
		} else {
			int size = table.size();
			switch (size) {
				case 0 :
					return of();
				case 1 :
					Cell<? extends R, ? extends C, ? extends V> onlyCell = (Cell) Iterables
							.getOnlyElement(table.cellSet());
					return of(onlyCell.getRowKey(), onlyCell.getColumnKey(), onlyCell.getValue());
				default :
					Builder<Cell<R, C, V>> cellSetBuilder = ImmutableSet.builder();
					Iterator i$ = table.cellSet().iterator();

					while (i$.hasNext()) {
						Cell<? extends R, ? extends C, ? extends V> cell = (Cell) i$.next();
						cellSetBuilder.add(cellOf(cell.getRowKey(), cell.getColumnKey(), cell.getValue()));
					}

					return RegularImmutableTable.forCells(cellSetBuilder.build());
			}
		}
	}

	public static final <R, C, V> com.google.common.collect.ImmutableTable.Builder<R, C, V> builder() {
		return new com.google.common.collect.ImmutableTable.Builder();
	}

	static <R, C, V> Cell<R, C, V> cellOf(R rowKey, C columnKey, V value) {
		return Tables.immutableCell(Preconditions.checkNotNull(rowKey), Preconditions.checkNotNull(columnKey),
				Preconditions.checkNotNull(value));
	}

	public abstract ImmutableSet<Cell<R, C, V>> cellSet();

	public abstract ImmutableMap<R, V> column(C var1);

	public abstract ImmutableSet<C> columnKeySet();

	public abstract ImmutableMap<C, Map<R, V>> columnMap();

	public abstract ImmutableMap<C, V> row(R var1);

	public abstract ImmutableSet<R> rowKeySet();

	public abstract ImmutableMap<R, Map<C, V>> rowMap();

	@Deprecated
	public final void clear() {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final V put(R rowKey, C columnKey, V value) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final void putAll(Table<? extends R, ? extends C, ? extends V> table) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final V remove(Object rowKey, Object columnKey) {
		throw new UnsupportedOperationException();
	}

	public boolean equals(@Nullable Object obj) {
		if (obj == this) {
			return true;
		} else if (obj instanceof Table) {
			Table<?, ?, ?> that = (Table) obj;
			return this.cellSet().equals(that.cellSet());
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.cellSet().hashCode();
	}

	public String toString() {
		return this.rowMap().toString();
	}
}