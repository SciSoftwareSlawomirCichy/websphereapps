package com.ibm.icu.impl.locale;

import com.ibm.icu.impl.locale.BaseLocale.Key;

public final class BaseLocale {
	private static final boolean JDKIMPL = false;
	private String _language = "";
	private String _script = "";
	private String _region = "";
	private String _variant = "";
	private transient volatile int _hash = 0;
	private static final LocaleObjectCache<Key, BaseLocale> BASELOCALE_CACHE = new LocaleObjectCache();
	public static final BaseLocale ROOT = getInstance("", "", "", "");

	private BaseLocale(String language, String script, String region, String variant) {
		if (language != null) {
			this._language = AsciiUtil.toLowerString(language).intern();
		}

		if (script != null) {
			this._script = AsciiUtil.toTitleString(script).intern();
		}

		if (region != null) {
			this._region = AsciiUtil.toUpperString(region).intern();
		}

		if (variant != null) {
			this._variant = AsciiUtil.toUpperString(variant).intern();
		}

	}

	public static BaseLocale getInstance(String language, String script, String region, String variant) {
		Key key = new Key(language, script, region, variant);
		BaseLocale baseLocale = (BaseLocale) BASELOCALE_CACHE.get(key);
		if (baseLocale == null) {
			baseLocale = new BaseLocale(language, script, region, variant);
			baseLocale = (BaseLocale) BASELOCALE_CACHE.put(baseLocale.createKey(), baseLocale);
		}

		return baseLocale;
	}

	public String getLanguage() {
		return this._language;
	}

	public String getScript() {
		return this._script;
	}

	public String getRegion() {
		return this._region;
	}

	public String getVariant() {
		return this._variant;
	}

	public String toString() {
		StringBuilder buf = new StringBuilder();
		if (this._language.length() > 0) {
			buf.append("language=");
			buf.append(this._language);
		}

		if (this._script.length() > 0) {
			if (buf.length() > 0) {
				buf.append(", ");
			}

			buf.append("script=");
			buf.append(this._script);
		}

		if (this._region.length() > 0) {
			if (buf.length() > 0) {
				buf.append(", ");
			}

			buf.append("region=");
			buf.append(this._region);
		}

		if (this._variant.length() > 0) {
			if (buf.length() > 0) {
				buf.append(", ");
			}

			buf.append("variant=");
			buf.append(this._variant);
		}

		return buf.toString();
	}

	public int hashCode() {
		int h = this._hash;
		if (h == 0) {
			int i;
			for (i = 0; i < this._language.length(); ++i) {
				h = 31 * h + this._language.charAt(i);
			}

			for (i = 0; i < this._script.length(); ++i) {
				h = 31 * h + this._script.charAt(i);
			}

			for (i = 0; i < this._region.length(); ++i) {
				h = 31 * h + this._region.charAt(i);
			}

			for (i = 0; i < this._variant.length(); ++i) {
				h = 31 * h + this._variant.charAt(i);
			}

			this._hash = h;
		}

		return h;
	}

	private Key createKey() {
		return new Key(this._language, this._script, this._region, this._variant);
	}
}