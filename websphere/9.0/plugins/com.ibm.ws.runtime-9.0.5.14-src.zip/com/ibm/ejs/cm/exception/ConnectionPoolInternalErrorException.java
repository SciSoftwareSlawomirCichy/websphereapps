package com.ibm.ejs.cm.exception;

import com.ibm.ejs.cm.portability.PortableSQLException;

public class ConnectionPoolInternalErrorException extends PortableSQLException {
	private static final long serialVersionUID = -7390524593133729338L;

	public ConnectionPoolInternalErrorException(String exceptionText) {
		super(exceptionText);
	}
}