package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.DiscreteDomain.BigIntegerDomain;
import com.google.common.collect.DiscreteDomain.IntegerDomain;
import com.google.common.collect.DiscreteDomain.LongDomain;
import java.math.BigInteger;
import java.util.NoSuchElementException;

@GwtCompatible
@Beta
public abstract class DiscreteDomain<C extends Comparable> {
	public static DiscreteDomain<Integer> integers() {
		return IntegerDomain.access$000();
	}

	public static DiscreteDomain<Long> longs() {
		return LongDomain.access$100();
	}

	static DiscreteDomain<BigInteger> bigIntegers() {
		return BigIntegerDomain.access$200();
	}

	public abstract C next(C var1);

	public abstract C previous(C var1);

	public abstract long distance(C var1, C var2);

	public C minValue() {
		throw new NoSuchElementException();
	}

	public C maxValue() {
		throw new NoSuchElementException();
	}
}