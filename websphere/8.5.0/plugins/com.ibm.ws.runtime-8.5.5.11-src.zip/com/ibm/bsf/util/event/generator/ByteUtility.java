package com.ibm.bsf.util.event.generator;

public class ByteUtility {
	public static byte[] addBytes(byte[] var0, byte[] var1) {
		if (null != var0) {
			byte[] var2 = new byte[var0.length + var1.length];
			System.arraycopy(var0, 0, var2, 0, var0.length);
			System.arraycopy(var1, 0, var2, var0.length, var1.length);
			var0 = var2;
		} else {
			var0 = var1;
		}

		return var0;
	}

	public static byte[] addBytes(byte[] var0, byte var1) {
		if (null != var0) {
			byte[] var2 = new byte[var0.length + 1];
			System.arraycopy(var0, 0, var2, 0, var0.length);
			var2[var2.length - 1] = var1;
			var0 = var2;
		} else {
			var0 = new byte[]{var1};
		}

		return var0;
	}

	public static byte[] addBytes(byte[] var0, int var1) {
		if (null != var0) {
			byte[] var2 = new byte[var0.length + 3];
			System.arraycopy(var0, 0, var2, 0, var0.length);
			var2[var2.length - 3] = (byte) (var1 >> 16 & 255);
			var2[var2.length - 2] = (byte) (var1 >> 8 & 255);
			var2[var2.length - 1] = (byte) (var1 & 255);
			var0 = var2;
		} else {
			var0 = new byte[]{(byte) (var1 >> 16 & 255), (byte) (var1 >> 8 & 255), (byte) (var1 & 255)};
		}

		return var0;
	}

	public static byte[] addBytes(byte[] var0, long var1) {
		if (null != var0) {
			byte[] var3 = new byte[var0.length + 4];
			System.arraycopy(var0, 0, var3, 0, var0.length);
			var3[var3.length - 4] = (byte) ((int) (var1 >> 24 & 255L));
			var3[var3.length - 3] = (byte) ((int) (var1 >> 16 & 255L));
			var3[var3.length - 2] = (byte) ((int) (var1 >> 8 & 255L));
			var3[var3.length - 1] = (byte) ((int) (var1 & 255L));
			var0 = var3;
		} else {
			var0 = new byte[]{(byte) ((int) (var1 >> 24 & 255L)), (byte) ((int) (var1 >> 16 & 255L)),
					(byte) ((int) (var1 >> 8 & 255L)), (byte) ((int) (var1 & 255L))};
		}

		return var0;
	}

	public static byte[] addBytes(byte[] var0, String var1) {
		if (null != var1) {
			if (null != var0) {
				byte[] var2 = new byte[var0.length + var1.length()];
				System.arraycopy(var0, 0, var2, 0, var0.length);
				System.arraycopy(var1.getBytes(), 0, var2, var0.length, var1.length());
				var0 = var2;
			} else {
				var0 = var1.getBytes();
			}
		}

		return var0;
	}

	public static byte[] addBytes(byte[] var0, short var1) {
		if (null != var0) {
			byte[] var2 = new byte[var0.length + 2];
			System.arraycopy(var0, 0, var2, 0, var0.length);
			var2[var2.length - 2] = (byte) (var1 >> 8 & 255);
			var2[var2.length - 1] = (byte) (var1 & 255);
			var0 = var2;
		} else {
			var0 = new byte[]{(byte) (var1 >> 8 & 255), (byte) (var1 & 255)};
		}

		return var0;
	}

	public static double byteArrayToDouble(byte[] var0, byte[] var1) {
		double var2 = 0.0D;
		var2 += (double) (((long) var0[0] & 255L) << 56);
		var2 += (double) (((long) var0[1] & 255L) << 48);
		var2 += (double) (((long) var0[2] & 255L) << 40);
		var2 += (double) (((long) var0[3] & 255L) << 32);
		var2 += (double) (((long) var1[0] & 255L) << 24);
		var2 += (double) (((long) var1[1] & 255L) << 16);
		var2 += (double) (((long) var1[2] & 255L) << 8);
		var2 += (double) ((long) var1[3] & 255L);
		return var2;
	}

	public static double byteArrayToDounle(byte[] var0) {
		byte[] var1 = new byte[4];
		byte[] var2 = new byte[4];
		var1[0] = var0[0];
		var1[1] = var0[1];
		var1[2] = var0[2];
		var1[3] = var0[3];
		var2[0] = var0[4];
		var2[1] = var0[5];
		var2[2] = var0[6];
		var2[3] = var0[7];
		return byteArrayToDouble(var1, var2);
	}

	public static float byteArrayToFloat(byte[] var0) {
		float var1 = 0.0F;
		var1 += (float) ((var0[0] & 255) << 24);
		var1 += (float) ((var0[1] & 255) << 16);
		var1 += (float) ((var0[2] & 255) << 8);
		var1 += (float) (var0[3] & 255);
		return var1;
	}

	public static int byteArrayToInt(byte[] var0) {
		byte var1 = 0;
		int var2 = var1 + ((var0[0] & 255) << 24);
		var2 += (var0[1] & 255) << 16;
		var2 += (var0[2] & 255) << 8;
		var2 += var0[3] & 255;
		return var2;
	}

	public static long byteArrayToLong(byte[] var0) {
		byte[] var1 = new byte[4];
		byte[] var2 = new byte[4];
		var1[0] = var0[0];
		var1[1] = var0[1];
		var1[2] = var0[2];
		var1[3] = var0[3];
		var2[0] = var0[4];
		var2[1] = var0[5];
		var2[2] = var0[6];
		var2[3] = var0[7];
		return byteArrayToLong(var1, var2);
	}

	public static long byteArrayToLong(byte[] var0, byte[] var1) {
		long var2 = 0L;
		var2 += ((long) var0[0] & 255L) << 56;
		var2 += ((long) var0[1] & 255L) << 48;
		var2 += ((long) var0[2] & 255L) << 40;
		var2 += ((long) var0[3] & 255L) << 32;
		var2 += ((long) var1[0] & 255L) << 24;
		var2 += ((long) var1[1] & 255L) << 16;
		var2 += ((long) var1[2] & 255L) << 8;
		var2 += (long) var1[3] & 255L;
		return var2;
	}

	public static short byteArrayToShort(byte[] var0) {
		byte var1 = 0;
		short var2 = (short) (var1 + ((var0[0] & 255) << 8));
		var2 = (short) (var2 + (var0[1] & 255));
		return var2;
	}

	public static String byteToHexString(byte var0) {
		String var1 = null;
		switch ((var0 & 240) >> 4) {
			case 0 :
				var1 = "0";
				break;
			case 1 :
				var1 = "1";
				break;
			case 2 :
				var1 = "2";
				break;
			case 3 :
				var1 = "3";
				break;
			case 4 :
				var1 = "4";
				break;
			case 5 :
				var1 = "5";
				break;
			case 6 :
				var1 = "6";
				break;
			case 7 :
				var1 = "7";
				break;
			case 8 :
				var1 = "8";
				break;
			case 9 :
				var1 = "9";
				break;
			case 10 :
				var1 = "A";
				break;
			case 11 :
				var1 = "B";
				break;
			case 12 :
				var1 = "C";
				break;
			case 13 :
				var1 = "D";
				break;
			case 14 :
				var1 = "E";
				break;
			case 15 :
				var1 = "F";
		}

		switch (var0 & 15) {
			case 0 :
				var1 = var1 + "0";
				break;
			case 1 :
				var1 = var1 + "1";
				break;
			case 2 :
				var1 = var1 + "2";
				break;
			case 3 :
				var1 = var1 + "3";
				break;
			case 4 :
				var1 = var1 + "4";
				break;
			case 5 :
				var1 = var1 + "5";
				break;
			case 6 :
				var1 = var1 + "6";
				break;
			case 7 :
				var1 = var1 + "7";
				break;
			case 8 :
				var1 = var1 + "8";
				break;
			case 9 :
				var1 = var1 + "9";
				break;
			case 10 :
				var1 = var1 + "A";
				break;
			case 11 :
				var1 = var1 + "B";
				break;
			case 12 :
				var1 = var1 + "C";
				break;
			case 13 :
				var1 = var1 + "D";
				break;
			case 14 :
				var1 = var1 + "E";
				break;
			case 15 :
				var1 = var1 + "F";
		}

		return var1;
	}
}