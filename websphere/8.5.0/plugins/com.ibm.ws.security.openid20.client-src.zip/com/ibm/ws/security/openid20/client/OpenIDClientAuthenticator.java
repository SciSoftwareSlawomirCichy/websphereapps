package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.security.WebTrustAssociationFailedException;
import com.ibm.websphere.ssl.JSSEHelper;
import com.ibm.websphere.ssl.SSLConfigChangeListener;
import com.ibm.websphere.ssl.SSLException;
import com.ibm.ws.security.openid20.client.OpenIDClientAuthenticator.1;
import com.ibm.ws.security.openid20.util.MessageHelper;
import com.ibm.ws.security.openid20.util.OidUtil;
import com.ibm.wsspi.security.tai.TAIResult;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLEncoder;
import java.security.AccessController;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.SSLContext;
import javax.security.auth.Subject;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.openid4java.consumer.ConsumerManager;
import org.openid4java.consumer.VerificationResult;
import org.openid4java.discovery.DiscoveryException;
import org.openid4java.discovery.DiscoveryInformation;
import org.openid4java.discovery.Identifier;
import org.openid4java.message.AuthRequest;
import org.openid4java.message.AuthSuccess;
import org.openid4java.message.MessageException;
import org.openid4java.message.MessageExtension;
import org.openid4java.message.ParameterList;
import org.openid4java.message.ax.FetchRequest;
import org.openid4java.message.ax.FetchResponse;

public class OpenIDClientAuthenticator {
	private static final TraceComponent tc = Tr.register(OpenIDClientAuthenticator.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private static SecureRandom srandom = new SecureRandom();
	private static ConsumerManagerFactory consumerManagerFactory = new ConsumerManagerFactory((ConsumerManager) null);
	private ConsumerManager consumerManager = null;
	private OpenIDClientConfig openidClientConfig = null;

	private OpenIDClientAuthenticator() {
	}

	public OpenIDClientAuthenticator(OpenIDClientConfig openidClientConfig) throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc,
					"OpenIDClientAuthenticator(openidClientConfig[" + OidUtil.getObjState(openidClientConfig) + "])");
		}

		this.openidClientConfig = openidClientConfig;
		RequestCache.CACHE.init(openidClientConfig);
		this.consumerManager = consumerManagerFactory.getConsumerManager(openidClientConfig,
				this.getDefaultSSLContext());
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "OpenIDClientAuthenticator");
		}

	}

	public TAIResult createAuthRequest(HttpServletRequest req, HttpServletResponse res)
			throws OpenIDRelyingPartyException, WebTrustAssociationFailedException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc,
					"createAuthRequest(req[" + OidUtil.getObjState(req) + "],res[" + OidUtil.getObjState(res) + "])");
		}

		String identifier = this.openidClientConfig.getProviderIdentifier();
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "openID identifier:" + identifier);
		}

		DiscoveryInformation discoveryInformation = this.discoverOpenID(this.consumerManager, identifier);
		String uniqueKey = MessageDigestUtil.getDigest();
		String return_to_url = this.createReturnToUrl(req, uniqueKey);
		String rpRealm = this.getRpRealm(req);
		AuthRequest authRequest = null;

		String msg;
		try {
			authRequest = this.consumerManager.authenticate(discoveryInformation, return_to_url, rpRealm);
		} catch (Exception var18) {
			msg = "Failed to create authRequest object " + var18.getMessage();
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, msg, var18);
			}

			throw new OpenIDRelyingPartyException(msg);
		}

		try {
			this.addUserInfoAttributes(authRequest);
		} catch (MessageException var17) {
			msg = "Failed to add attributes to auth request " + var17.getMessage();
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, msg, var17);
			}

			throw new OpenIDRelyingPartyException(msg);
		}

		String method = req.getMethod();
		Map<String, String[]> pMap = req.getParameterMap();
		RequestData rData = new RequestData(discoveryInformation, method, pMap);

		try {
			RequestCache.CACHE.put(uniqueKey, rData);
		} catch (OpenIDRelyingPartyException var15) {
			res.addHeader("WWW-Authenticate", "Bearer realm=\"" + this.openidClientConfig.getRealmName()
					+ "\", error=TAI internal cache capacity reached");
			return TAIResult.create(503);
		}

		String url = authRequest.getDestinationUrl(true);
		url = res.encodeRedirectURL(url);

		try {
			res.sendRedirect(url);
		} catch (IOException var16) {
			String msg = "Failed to set the redirect url - " + var16.getMessage();
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, msg, var16);
			}

			throw new OpenIDRelyingPartyException(msg);
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "OIDCRelyingParty sent redirect (302) request: [" + url + "]");
		}

		TAIResult taiResult = TAIResult.create(302);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createAuthRequest returns taiResult: [" + OidUtil.getObjState(taiResult) + "]");
		}

		return taiResult;
	}

	public TAIResult verifyResponse(HttpServletRequest req, HttpServletResponse res)
			throws OpenIDRelyingPartyException, WebTrustAssociationFailedException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "verifyResponse(req[" + OidUtil.getObjState(req) + "],res[" + OidUtil.getObjState(res) + "])");
		}

		String receivingUrl = this.getReceivingUrl(req);
		ParameterList response = new ParameterList(req.getParameterMap());
		String uniqueKey = this.getRPIdentifier(req);
		RequestData requestData = RequestCache.CACHE.get(uniqueKey);
		DiscoveryInformation discoveryInfo = requestData.getDiscoveryInformation();
		VerificationResult verificationResult = null;

		String identifier;
		try {
			verificationResult = this.consumerManager.verify(receivingUrl, response, discoveryInfo);
		} catch (Exception var38) {
			identifier = "Failed to verify the response for " + discoveryInfo.getClaimedIdentifier() + " exception "
					+ var38.getMessage();
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, identifier, var38);
			}

			throw new OpenIDRelyingPartyException(identifier);
		}

		if (verificationResult == null) {
			String msg = "Failed to get a valid response for " + discoveryInfo.getClaimedIdentifier();
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, msg);
			}

			throw new OpenIDRelyingPartyException(msg);
		} else {
			Identifier verifiedIdentifier = verificationResult.getVerifiedId();
			if (verifiedIdentifier == null) {
				identifier = verificationResult.getStatusMsg();
				res.addHeader("WWW-Authenticate",
						"Bearer realm=\"" + this.openidClientConfig.getRealmName() + "\", error=" + identifier);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Verification failed with the message: [" + identifier + "]");
				}

				return TAIResult.create(403);
			} else {
				identifier = verifiedIdentifier.getIdentifier();
				AuthSuccess authSuccess = (AuthSuccess) verificationResult.getAuthResponse();
				if (authSuccess == null) {
					String msg = "Failed to get AuthSuccess response object for identifier " + identifier;
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, msg);
					}

					throw new OpenIDRelyingPartyException(msg);
				} else {
					Map<String, Object> attributes = this.receiveUserInfoAttributes(authSuccess);
					String mapUserName = this.resolveMapUserName(authSuccess, attributes);
					Subject subject = this.getSubject(mapUserName, attributes);
					RequestCache.CACHE.update(uniqueKey, subject, mapUserName);
					Cookie sessionCookie = new Cookie("OIDRP_Identifier", uniqueKey);
					sessionCookie.setPath("/");
					sessionCookie.setHttpOnly(this.openidClientConfig.httpOnly());
					sessionCookie.setSecure(this.openidClientConfig.ishttpsRequired());
					res.addCookie(sessionCookie);
					String redirectUrl = req.getRequestURL().toString();
					Map<String, String[]> pMap = requestData.getParameterMap();
					String method = requestData.getMethod();
					Set keys;
					String msg;
					String[] values;
					String[] arr$;
					int len$;
					int i$;
					String value;
					String encValue;
					TAIResult taiR;
					Iterator i$;
					String key;
					if (!"POST".equals(method) && !"PUT".equals(method)) {
						String queryString = "";
						if (pMap != null) {
							keys = pMap.keySet();
							i$ = keys.iterator();

							while (i$.hasNext()) {
								key = (String) i$.next();
								values = (String[]) pMap.get(key);
								arr$ = values;
								len$ = values.length;

								for (i$ = 0; i$ < len$; ++i$) {
									value = arr$[i$];
									if (!queryString.equals("")) {
										queryString = queryString + "&";
									}

									try {
										encValue = URLEncoder.encode(value, "UTF-8");
										queryString = queryString + key + "=" + encValue;
									} catch (UnsupportedEncodingException var36) {
										String msg = "Failed to generate the redirect url string because of exception ["
												+ var36.getMessage() + "]";
										if (tc.isDebugEnabled()) {
											Tr.debug(tc, msg);
										}

										OpenIDRelyingPartyException newEx = new OpenIDRelyingPartyException(msg);
										newEx.initCause(var36);
										throw newEx;
									}
								}
							}
						}

						if (!queryString.equals("")) {
							redirectUrl = redirectUrl + "?" + queryString;
						}

						try {
							res.sendRedirect(redirectUrl);
						} catch (IOException var37) {
							msg = "Failed to set the redirect url " + var37.getMessage();
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, msg);
							}

							throw new OpenIDRelyingPartyException(msg);
						}

						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Sending a GET redirect to url " + redirectUrl);
						}

						taiR = TAIResult.create(302);
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "verifyResponse returns taiResult: [" + taiR.getStatus() + "]");
						}

						return taiR;
					} else {
						PrintWriter out = null;

						try {
							out = res.getWriter();
							out.println("<html><head></head>");
							out.println("<body onload='document.formoidcpost.submit()'>");
							out.println(
									"<form name='formoidcpost' action='" + redirectUrl + "' method='" + method + "'>");
							if (pMap != null) {
								keys = pMap.keySet();
								i$ = keys.iterator();

								while (i$.hasNext()) {
									key = (String) i$.next();
									values = (String[]) pMap.get(key);
									arr$ = values;
									len$ = values.length;

									for (i$ = 0; i$ < len$; ++i$) {
										value = arr$[i$];
										encValue = URLEncoder.encode(value, "UTF-8");
										out.println(
												"<input type='hidden' name='" + key + "' value='" + encValue + "'>");
									}
								}
							}

							out.println("</form></body></html>");
						} catch (Exception var39) {
							msg = "Failed to generate the form post html because of exception [" + var39.getMessage()
									+ "]";
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, msg);
							}

							OpenIDRelyingPartyException newEx = new OpenIDRelyingPartyException(msg);
							newEx.initCause(var39);
							throw newEx;
						} finally {
							if (out != null) {
								out.close();
							}

						}

						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Sending a POST redirect to url " + redirectUrl);
						}

						res.setContentType("application/x-www-form-urlencoded; charset=UTF-8");
						taiR = TAIResult.create(401);
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "verifyResponse returns taiResult: [" + taiR.getStatus() + "]");
						}

						return taiR;
					}
				}
			}
		}
	}

	private SSLContext getDefaultSSLContext() throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDefaultSSLContext()");
		}

		JSSEHelper jsseHelper = JSSEHelper.getInstance();
		SSLContext context = null;

		try {
			context = jsseHelper.getSSLContext((String) null, (Map) null, (SSLConfigChangeListener) null);
		} catch (SSLException var5) {
			String msg = MessageHelper.getMessage("security.openid20.client.defaultsslcontext", var5.getMessage());
			Tr.error(tc, msg, var5);
			throw new OpenIDRelyingPartyException(msg);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDefaultSSLContext returns [" + OidUtil.getObjState(context) + "]");
		}

		return context;
	}

	private String createReturnToUrl(HttpServletRequest req, String uniqueKey) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createReturnToUrl(req[" + OidUtil.getObjState(req) + "],uniqueKey[" + uniqueKey + "])");
		}

		StringBuffer builder = req.getRequestURL();
		builder.append("?");
		builder.append("rp_identifier");
		builder.append("=");
		builder.append(uniqueKey);
		if (req.getQueryString() != null) {
			builder.append("&");
			builder.append(req.getQueryString());
		}

		String result = builder.toString();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createReturnToUrl returns [" + result + "]");
		}

		return result;
	}

	private String getRpRealm(HttpServletRequest req) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getRpRealm(req[" + OidUtil.getObjState(req) + "])");
		}

		StringBuilder builder = new StringBuilder();
		builder.append(req.getScheme());
		builder.append("://");
		builder.append(req.getServerName());
		int port = req.getServerPort();
		if (port != 80 && port != 443) {
			builder.append(":");
			builder.append(req.getServerPort());
		}

		builder.append(req.getContextPath());
		String returnVal = builder.toString();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getRpRealm returns [" + returnVal + "]");
		}

		return returnVal;
	}

	public String getReceivingUrl(HttpServletRequest req) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getReceivingUrl(req[" + OidUtil.getObjState(req) + "])");
		}

		StringBuffer receivingURL = req.getRequestURL();
		String queryString = req.getQueryString();
		if (queryString != null && queryString.length() > 0) {
			receivingURL.append("?").append(req.getQueryString());
		}

		String returnVal = receivingURL.toString();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getReceivingUrl returns [" + returnVal + "]");
		}

		return returnVal;
	}

	private DiscoveryInformation discoverOpenID(ConsumerManager consumerManager, String identifier)
			throws OpenIDRelyingPartyException, WebTrustAssociationFailedException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "discoverOpenID(consumerManager[" + OidUtil.getObjState(consumerManager) + "],identifier["
					+ identifier + "])");
		}

		List<?> discoveries = null;
		int maxDiscoverRetry = this.openidClientConfig.getMaxDiscoverRetry();

		String msg;
		for (int retries = 0; retries < maxDiscoverRetry; ++retries) {
			try {
				discoveries = consumerManager.discover(identifier);
			} catch (DiscoveryException var9) {
				msg = MessageHelper.getMessage("security.openid20.client.discoveryfailed",
						new Object[]{identifier, var9.getMessage()});
				Tr.error(tc, msg, var9);
				throw new WebTrustAssociationFailedException(msg);
			}
		}

		if (discoveries == null) {
			String msg = "Failed to discover OpenID provider for identifier: " + identifier + " after "
					+ maxDiscoverRetry + " attempts";
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, msg);
			}

			throw new OpenIDRelyingPartyException(msg);
		} else {
			DiscoveryInformation discovered = consumerManager.associate(discoveries);
			String version;
			if (this.openidClientConfig.ishttpsRequired()) {
				version = discovered.getOPEndpoint().getProtocol();
				if (!"https".equals(version)) {
					msg = discovered.getOPEndpoint().toString();
					String msg = MessageHelper.getMessage("security.openid20.client.opendpointnothttps",
							new Object[]{msg, "httpsRequired"});
					Tr.error(tc, msg);
					throw new WebTrustAssociationFailedException(msg);
				}
			}

			version = discovered.getVersion();
			if (!discovered.isVersion2() && tc.isWarningEnabled()) {
				msg = MessageHelper.getMessage("security.openid20.client.opnotversion2warn");
				Tr.warning(tc, msg, version);
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "discoverOpenID returns [" + OidUtil.getObjState(discovered) + "]");
			}

			return discovered;
		}
	}

	private void addUserInfoAttributes(AuthRequest authReq) throws MessageException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "addUserInfoAttributes(authReq[" + OidUtil.getObjState(authReq) + "])");
		}

		FetchRequest fetch = FetchRequest.createFetchRequest();
		ArrayList<UserInfo> attributes = (ArrayList) this.openidClientConfig.getUserInfo();
		if (attributes != null && !attributes.isEmpty()) {
			Iterator i$ = attributes.iterator();

			while (i$.hasNext()) {
				UserInfo att = (UserInfo) i$.next();
				fetch.addAttribute(att.getAlias(), att.getType(), att.getRequired(), att.getCount());
			}

			authReq.addExtension(fetch);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addUserInfoAttributes returns");
		}

	}

	private Map<String, Object> receiveUserInfoAttributes(AuthSuccess authSuccess) throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "receiveUserInfoAttributes(authSuccess[" + OidUtil.getObjState(authSuccess) + "])");
		}

		Map<String, Object> result = new HashMap();
		if (authSuccess.hasExtension("http://openid.net/srv/ax/1.0")) {
			MessageExtension ext = null;

			try {
				ext = authSuccess.getExtension("http://openid.net/srv/ax/1.0");
			} catch (MessageException var6) {
				String msg = "Failed to get parameter of extension type http://openid.net/srv/ax/1.0 "
						+ var6.getMessage();
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, msg);
				}

				throw new OpenIDRelyingPartyException(msg);
			}

			if (ext instanceof FetchResponse) {
				FetchResponse axResponse = (FetchResponse) ext;
				result = axResponse.getAttributes();
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "receiveUserInfoAttributes returns [" + result + "])");
		}

		return (Map) result;
	}

	private String resolveMapUserName(AuthSuccess authSuccess, Map<String, Object> attributes) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "resolveMapUserName(authSuccess[" + OidUtil.getObjState(authSuccess) + "],attributes["
					+ OidUtil.getObjState(attributes) + "])");
		}

		if (this.openidClientConfig.isUseClientIdentity()) {
			String alias = this.getIdentityOrClaimedId(authSuccess);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "resolveMapUserName returns [" + alias + "])");
			}

			return alias;
		} else {
			String[] aliases = this.openidClientConfig.getMapAliasAsPrincipal();
			String alias = null;
			if (aliases != null) {
				String[] arr$ = aliases;
				int len$ = aliases.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					String key = arr$[i$];
					ArrayList<?> value = (ArrayList) attributes.get(key);
					if (value != null && value.size() > 0) {
						alias = (String) value.get(0);
						if (alias != null) {
							break;
						}
					}
				}
			}

			if (alias == null) {
				alias = this.getIdentityOrClaimedId(authSuccess);
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "resolveMapUserName returns [" + alias + "])");
			}

			return alias;
		}
	}

	private String getIdentityOrClaimedId(AuthSuccess authSuccess) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getIdentityOrClaimedId(authSuccess[" + OidUtil.getObjState(authSuccess) + "])");
		}

		String alias = authSuccess.getIdentity();
		if (alias == null) {
			alias = authSuccess.getClaimed();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getIdentityOrClaimedId returns [" + alias + "])");
		}

		return alias;
	}

	private String getRealm(Map<String, Object> attributes) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getRealm(attributes[" + OidUtil.getObjState(attributes) + "])");
		}

		String value = null;
		String rIdentifier = this.openidClientConfig.getRealmIdentifier();
		if (rIdentifier != null) {
			ArrayList<?> values = (ArrayList) attributes.get(rIdentifier);
			if (values != null && values.size() > 0) {
				value = (String) values.get(0);
			}
		}

		if (value == null) {
			value = this.openidClientConfig.getRealmName();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getRealm returns [" + value + "])");
		}

		return value;
	}

	private List<String> getGroupIds(Map<String, Object> attributes, String realmName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getGroupIds(attributes[" + OidUtil.getObjState(attributes) + "])");
		}

		ArrayList<String> groups = new ArrayList();
		String gIdentifier = this.openidClientConfig.getGroupIdentifier();
		if (gIdentifier != null) {
			ArrayList<?> values = (ArrayList) attributes.get(gIdentifier);
			if (realmName == null || realmName.isEmpty()) {
				return values;
			}

			if (values != null && values.size() > 0) {
				Iterator it = values.iterator();

				while (it.hasNext()) {
					String group = "group:" + realmName + "/" + it.next();
					groups.add(group);
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getGroupIds returns list of size [" + groups.size() + "])");
		}

		return groups;
	}

	private Subject getSubject(String mapUserName, Map<String, Object> attributes) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc,
					"getSubject(mapUserName[" + mapUserName + "],attributes[" + OidUtil.getObjState(attributes) + "])");
		}

		Subject jaasSubject = null;
		if (mapUserName != null && attributes != null) {
			jaasSubject = new Subject();
			Hashtable<String, Object> credentials = new Hashtable();
			credentials.put("com.ibm.wsspi.security.cred.securityName", mapUserName);
			if (!this.openidClientConfig.isMapIdentityToRegistryUser()) {
				String realmName = this.getRealm(attributes);
				List<String> groupIds = this.getGroupIds(attributes, realmName);
				String uniqueId = "user:" + realmName + "/" + mapUserName;
				credentials.put("com.ibm.wsspi.security.cred.uniqueId", uniqueId);
				credentials.put("com.ibm.wsspi.security.cred.groups", groupIds);
				credentials.put("com.ibm.wsspi.security.cred.realm", realmName);
				if (this.openidClientConfig.isIncludeCustomCacheKeyInSubject()) {
					credentials.put("com.ibm.wsspi.security.cred.cacheKey",
							mapUserName + (new BigInteger(130, srandom)).toString(32));
				}

				credentials.putAll(attributes);
			}

			addToSubjectAsPrivateCredentials(jaasSubject, credentials);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getSubject returns [" + jaasSubject + "]");
			}

			return jaasSubject;
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "One or more parameters passed to this method is null");
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getSubject returns [" + OidUtil.getObjState(jaasSubject) + "]");
			}

			return null;
		}
	}

	private static void addToSubjectAsPrivateCredentials(Subject subject, Object credentials) {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "addToSubjectAsPrivateCredentials");
      }

      if (subject != null) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Adding private credential");
         }

         AccessController.doPrivileged(new 1(subject, credentials));
      } else if (tc.isDebugEnabled()) {
         Tr.debug(tc, "Subject is null");
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "addToSubjectAsPrivateCredentials");
      }

   }

	public String getRPIdentifier(HttpServletRequest req) throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getRPIdentifier(req[" + OidUtil.getObjState(req) + "])");
		}

		String uniqueKey = req.getParameter("rp_identifier");
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Found request identifier in the request: " + uniqueKey);
		}

		if (uniqueKey != null && !uniqueKey.trim().isEmpty()) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getRPIdentifier returns: [" + uniqueKey + "]");
			}

			return uniqueKey;
		} else {
			throw new OpenIDRelyingPartyException(
					"Did not find rp_identifier in the incoming request, could not query the cache");
		}
	}
}