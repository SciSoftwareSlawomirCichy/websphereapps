package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.security.WebTrustAssociationException;
import com.ibm.websphere.security.WebTrustAssociationFailedException;
import com.ibm.ws.security.openid20.util.MessageHelper;
import com.ibm.ws.security.openid20.util.OidUtil;
import com.ibm.ws.security.web.CookieHelper;
import com.ibm.wsspi.security.tai.TAIResult;
import com.ibm.wsspi.security.tai.TrustAssociationInterceptor;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class OpenIDRelyingPartyTAI implements TrustAssociationInterceptor {
	private static final TraceComponent tc = Tr.register(OpenIDRelyingPartyTAI.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private OpenIDClientConfig openidClientConfig = null;
	private OpenIDClientAuthenticator openidAuthenticator = null;

	public void cleanup() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "cleanup");
			Tr.exit(tc, "cleanup");
		}

	}

	public String getType() {
		String type = "OpenId 2.0 TrustAssociationInterceptor";
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getType");
			Tr.exit(tc, "getType returns [" + type + "]");
		}

		return type;
	}

	public String getVersion() {
		String version = "1.0";
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getVersion");
			Tr.exit(tc, "getVersion returns [" + version + "]");
		}

		return version;
	}

	public int initialize(Properties props) throws WebTrustAssociationFailedException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initialize(props[" + OidUtil.getObjState(props) + "])");
		}

		try {
			this.openidClientConfig = new OpenIDClientConfig(props);
			this.openidAuthenticator = new OpenIDClientAuthenticator(this.openidClientConfig);
		} catch (OpenIDRelyingPartyException var4) {
			String msg = MessageHelper.getMessage("security.openid20.client.initializationfailed", var4.getMessage());
			Tr.error(tc, msg);
			throw new WebTrustAssociationFailedException(msg);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initialize");
		}

		return 0;
	}

	public boolean isTargetInterceptor(HttpServletRequest req) throws WebTrustAssociationException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isTargetInterceptor(req[" + OidUtil.getObjState(req) + "])");
		}

		if (req != null) {
			if (this.openidClientConfig.ishttpsRequired() && req.getScheme().equals("http")) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc,
							"isTargetInterceptor returns [false], HTTP request ignored as httpsRequired is set to true. Only HTTPS request will be intercepted");
				}

				return false;
			}

			boolean isIncluded = false;
			boolean isExcluded = false;
			String rUri = req.getRequestURI();
			if (rUri == null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "The url [" + rUri + "] is null");
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "isTargetInterceptor returns [false]");
				}

				return false;
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Evaluating for request uri: [" + rUri + "]");
			}

			Iterator i$ = this.openidClientConfig.getEffectiveUriList().iterator();

			while (i$.hasNext()) {
				String pattern = (String) i$.next();
				if (rUri.matches(pattern)) {
					isIncluded = true;
					break;
				}
			}

			ArrayList<String> excludedPathFilter = this.openidClientConfig.getExcludedUriList();
			if (excludedPathFilter != null) {
				Iterator i$ = excludedPathFilter.iterator();

				while (i$.hasNext()) {
					String pattern = (String) i$.next();
					if (rUri.matches(pattern)) {
						isExcluded = true;
						break;
					}
				}
			}

			if (isIncluded && !isExcluded) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "The url [" + rUri + "] is being intercepted by OpenID RelyingParty");
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "isTargetInterceptor returns [true]");
				}

				return true;
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "The URL: [" + rUri + "] ignored by OpenId RelyingParty");
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isTargetInterceptor returns [false]");
		}

		return false;
	}

	public TAIResult negotiateValidateandEstablishTrust(HttpServletRequest req, HttpServletResponse res)
			throws WebTrustAssociationFailedException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "negotiateValidateandEstablishTrust(req[" + OidUtil.getObjState(req) + ",res["
					+ OidUtil.getObjState(res) + "])");
		}

		if (req != null && res != null) {
			RequestCache.CACHE.cleanup();
			String defaultEncoding = this.openidClientConfig.getCharacterEncoding();

			try {
				if (req.getCharacterEncoding() == null) {
					req.setCharacterEncoding(defaultEncoding);
				}
			} catch (UnsupportedEncodingException var14) {
				if (tc.isWarningEnabled()) {
					Tr.warning(tc, "Failed to set the encoding of the incoming request to " + defaultEncoding, var14);
				}
			}

			String rUri = req.getRequestURI();
			TAIResult taiResult = null;
			String openidMode = req.getParameter("openid.mode");
			String key;
			if (openidMode != null) {
				if (openidMode.equals("id_res")) {
					try {
						taiResult = this.openidAuthenticator.verifyResponse(req, res);
					} catch (OpenIDRelyingPartyException var13) {
						key = MessageHelper.getMessage("security.openid20.client.verifyauthresponsefailed",
								var13.getMessage());
						Tr.error(tc, key);
						throw new WebTrustAssociationFailedException(key);
					}
				} else if (openidMode.equals("cancel")) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "received openid.mode = cancel, indicating that the authentication failed");
					}

					taiResult = TAIResult.create(403);
				} else {
					String error = req.getParameter("openid.error");
					if (error == null) {
						error = "The response either has missing parameters or has parameters with an error message";
					}

					key = MessageHelper.getMessage("security.openid20.client.invalidresponse", error);
					Tr.error(tc, key);
					res.addHeader("WWW-Authenticate",
							"Bearer realm=\"" + this.openidClientConfig.getRealmName() + "\", error=" + error);
					taiResult = TAIResult.create(400);
				}
			} else {
				ArrayList<String> basicAuthUriList = this.openidClientConfig.getBasicAuthUriList();
				String msg;
				if (basicAuthUriList != null) {
					Iterator i$ = basicAuthUriList.iterator();

					while (i$.hasNext()) {
						msg = (String) i$.next();
						if (rUri.matches(msg)) {
							taiResult = BasicAuthAuthenticator.authenticate(req, res, this.openidClientConfig);
							break;
						}
					}
				}

				if (taiResult == null) {
					key = CookieHelper.getCookieValue(req.getCookies(), "OIDRP_Identifier");
					if (key != null) {
						RequestData rData = RequestCache.CACHE.get(key);
						if (rData != null) {
							Subject subject = rData.getSubject();
							String username = rData.getUserName();
							RequestCache.CACHE.purge(key);
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Received rp_identifier cookie for this request for user: " + username
										+ " responding with success");
							}

							taiResult = TAIResult.create(200, username, subject);
						}
					}
				}

				if (taiResult == null) {
					try {
						taiResult = this.openidAuthenticator.createAuthRequest(req, res);
					} catch (OpenIDRelyingPartyException var12) {
						msg = MessageHelper.getMessage("security.openid20.client.authrequestfailed",
								var12.getMessage());
						Tr.error(tc, msg);
						throw new WebTrustAssociationFailedException(msg);
					}
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.debug(tc, "TAI Response: " + taiResult.getStatus());
				Tr.exit(tc, "negotiateValidateandEstablishTrust returns [" + OidUtil.getObjState(taiResult) + "]");
			}

			return taiResult;
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "One or more of the parameters passed to this method is null");
			}

			throw new WebTrustAssociationFailedException("One or more parameters passed to this method is null");
		}
	}
}