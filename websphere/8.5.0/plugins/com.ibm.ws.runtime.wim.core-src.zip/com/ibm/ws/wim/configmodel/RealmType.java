package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface RealmType {
	List getParticipatingBaseEntries();

	ParticipatingBaseEntriesType[] getParticipatingBaseEntriesAsArray();

	ParticipatingBaseEntriesType createParticipatingBaseEntries();

	List getDefaultParents();

	RealmDefaultParentType[] getDefaultParentsAsArray();

	RealmDefaultParentType createDefaultParents();

	UserRegistryInfoMappingType getUniqueUserIdMapping();

	void setUniqueUserIdMapping(UserRegistryInfoMappingType var1);

	UserRegistryInfoMappingType createUniqueUserIdMapping();

	UserRegistryInfoMappingType getUserSecurityNameMapping();

	void setUserSecurityNameMapping(UserRegistryInfoMappingType var1);

	UserRegistryInfoMappingType createUserSecurityNameMapping();

	UserRegistryInfoMappingType getUserDisplayNameMapping();

	void setUserDisplayNameMapping(UserRegistryInfoMappingType var1);

	UserRegistryInfoMappingType createUserDisplayNameMapping();

	UserRegistryInfoMappingType getUniqueGroupIdMapping();

	void setUniqueGroupIdMapping(UserRegistryInfoMappingType var1);

	UserRegistryInfoMappingType createUniqueGroupIdMapping();

	UserRegistryInfoMappingType getGroupSecurityNameMapping();

	void setGroupSecurityNameMapping(UserRegistryInfoMappingType var1);

	UserRegistryInfoMappingType createGroupSecurityNameMapping();

	UserRegistryInfoMappingType getGroupDisplayNameMapping();

	void setGroupDisplayNameMapping(UserRegistryInfoMappingType var1);

	UserRegistryInfoMappingType createGroupDisplayNameMapping();

	String getDelimiter();

	void setDelimiter(String var1);

	void unsetDelimiter();

	boolean isSetDelimiter();

	boolean isAllowOperationIfReposDown();

	void setAllowOperationIfReposDown(boolean var1);

	void unsetAllowOperationIfReposDown();

	boolean isSetAllowOperationIfReposDown();

	String getName();

	void setName(String var1);

	String getSecurityUse();

	void setSecurityUse(String var1);

	void unsetSecurityUse();

	boolean isSetSecurityUse();
}