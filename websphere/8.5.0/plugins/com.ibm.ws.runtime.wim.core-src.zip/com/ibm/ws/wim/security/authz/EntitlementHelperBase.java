package com.ibm.ws.wim.security.authz;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.security.authz.Entitlement;
import commonj.sdo.DataObject;

public class EntitlementHelperBase {
	static final String COPYRIGHT_NOTICE;

	public static Entitlement getEntitlementFromDataObject(DataObject var0) {
		return var0 == null
				? null
				: new Entitlement(var0.getString("method"), var0.getString("object"), var0.getString("attribute"));
	}

	public static void setEntitlementToDataObject(Entitlement var0, DataObject var1) {
		var1.setString("method", var0.getMethod());
		var1.setString("object", var0.getObject());
		if (var0.isAttributeEntitlement()) {
			var1.setString("attribute", var0.getAttribute());
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010;
	}
}