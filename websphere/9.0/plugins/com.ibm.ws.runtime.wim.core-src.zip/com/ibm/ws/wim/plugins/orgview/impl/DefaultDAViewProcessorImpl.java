package com.ibm.ws.wim.plugins.orgview.impl;

import com.ibm.websphere.wim.exception.EntityIdentifierNotSpecifiedException;
import com.ibm.websphere.wim.exception.InvalidArgumentException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.SubscriberException;
import com.ibm.websphere.wim.pluginmanager.context.SubscriberExecStatus;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.util.ControlsHelper;
import com.ibm.wsspi.wim.plugins.orgview.ViewProcessor;
import com.ibm.wsspi.wim.plugins.orgview.impl.BaseViewProcessorImpl;
import commonj.sdo.DataObject;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class DefaultDAViewProcessorImpl extends BaseViewProcessorImpl implements ViewProcessor {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = DefaultDAViewProcessorImpl.class.getName();
	private static final Logger trcLogger;
	public final String VIEW_PROCESSOR_NAME = "DefaultDAViewProcessor";
	public final String VIEW_NAME = "DefaultDAView";
	public final String DA_VIEW_CONCOCTED_UUID_PREFIX = "DefaultDAViewUUID_";
	public final String DA_VIEW_ROOT_ENTRY_NAME = "/root";
	public final String DA_VIEW_ENTRY_NAME_PREFIX = "/root/";
	public final String DA_VIEW_CONCOCTED_ENTRY_NAME = "Concocted";

	public String getViewName() {
		return "DefaultDAView";
	}

	public DataObject mapViewIdentifierToWIMIdentifier(DataObject var1, DataObject var2) {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "mapViewIdentifierToWIMIdentifier(entityDO, viewIdentifier)",
					WIMTraceHelper.printDataObject(var1));
		}

		String var5 = var2.getString("viewEntryUniqueId");
		DataObject var6 = null;
		if (!var5.startsWith("DefaultDAViewUUID_")) {
			var6 = var1.createDataObject("identifier");
			var6.setString("uniqueId", var2.getString("viewEntryUniqueId"));
			String var7 = var2.getString("uniqueName").substring("/root/".length());
			var6.setString("uniqueName", var7);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "mapViewIdentifierToWIMIdentifier(entityDO, viewIdentifier)",
					WIMTraceHelper.printDataObject(var1));
		}

		return null;
	}

	public DataObject mapWIMIdentifierToViewIdentifier(DataObject var1, DataObject var2) {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "mapWIMIdentifierToViewIdentifier(entityDO, wimIdentifier)",
					WIMTraceHelper.printDataObject(var1));
		}

		DataObject var5 = var1.createDataObject("viewIdentifiers");
		var5.setString("viewName", this.getViewName());
		if (var2.getString("uniqueName") != null) {
			var5.setString("viewEntryName", "/root/" + var2.getString("uniqueName"));
		}

		if (var2.getString("uniqueId") != null) {
			var5.setString("viewEntryUniqueId", var2.getString("uniqueId"));
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "mapWIMIdentifierToViewIdentifier(entityDO, wimIdentifier)",
					WIMTraceHelper.printDataObject(var1));
		}

		return var5;
	}

	public DataObject simulateEntityCreation(DataObject var1) {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "simulateEntityCreation(entityDO)", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var4 = var1.createDataObject("viewIdentifiers");
		var4.setString("viewName", "DefaultDAView");
		var4.setString("viewEntryName", "/root/Concocted");
		var4.setString("viewEntryUniqueId", "");
		if (var3) {
			trcLogger.exiting(CLASSNAME, "simulateEntityCreation(entityDO)", WIMTraceHelper.printDataObject(var1));
		}

		return var4;
	}

	public boolean addAncestorsToDataObject(DataObject var1, DataObject var2) {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addAncestorsToDataObject(entityDO)", WIMTraceHelper.printDataObject(var1));
		}

		if (var2 == null) {
			return false;
		} else {
			String var5 = var2.getString("viewEntryName");
			if (!var5.equals("/root")) {
				DataObject var6 = var1.createDataObject("parent", "http://www.ibm.com/websphere/wim", "OrgContainer");
				DataObject var7 = var6.createDataObject("viewIdentifiers");
				var7.setString("viewName", "DefaultDAView");
				var7.setString("viewEntryUniqueId", "DefaultDAViewUUID_/root");
				var7.setString("viewEntryName", "/root");
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "addAncestorsToDataObject(entityDO)",
						WIMTraceHelper.printDataObject(var1));
			}

			return true;
		}
	}

	public boolean getInViewExplicit(String var1, DataObject var2) throws SubscriberException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getInViewExplicit(rootDO)", WIMTraceHelper.printDataObject(var2));
		}

		List var5 = var2.getList("entities");
		if (var5 != null && var5.size() != 0) {
			Map var6 = ControlsHelper.getControlMap(var2.getDataGraph());
			DataObject var7 = (DataObject) var6.get("AncestorControl");
			int var8;
			if (var7 != null) {
				var8 = var7.getInt("level");
				if (var8 < 0) {
					throw new SubscriberException(SubscriberExecStatus.FAILURE_LITERAL, "INVALID_LEVEL_IN_CONTROL",
							CLASSNAME,
							new InvalidArgumentException("INVALID_LEVEL_IN_CONTROL",
									WIMMessageHelper.generateMsgParms(new Integer(var8), "AncestorControl"),
									Level.WARNING, CLASSNAME, "getInViewExplicit(rootDO)"));
				}
			} else {
				DataObject var12 = (DataObject) var6.get("DescendantControl");
				if (var12 != null) {
					throw new SubscriberException(SubscriberExecStatus.FAILURE_LITERAL, "OPERATION_NOT_SUPPORTED",
							CLASSNAME,
							new OperationNotSupportedException("OPERATION_NOT_SUPPORTED",
									WIMMessageHelper.generateMsgParms("DescendantControl"), Level.WARNING, CLASSNAME,
									"getInViewExplicit(rootDO)"));
				}
			}

			for (var8 = 0; var8 < var5.size(); ++var8) {
				DataObject var9 = (DataObject) var5.get(var8);
				DataObject var10 = this.getViewIdentifierForEntity(var9, this.getViewName());
				DataObject var11 = var9.getDataObject("identifier");
				if (var10 == null && var11 == null) {
					if (!var1.equalsIgnoreCase("com.ibm.ws.wim.authz.ProfileSecurityManager")) {
						throw new SubscriberException(SubscriberExecStatus.FAILURE_LITERAL,
								"ENTITY_IDENTIFIER_NOT_SPECIFIED", CLASSNAME,
								new OperationNotSupportedException("ENTITY_IDENTIFIER_NOT_SPECIFIED",
										WIMMessageHelper.generateMsgParms(var9), Level.WARNING, CLASSNAME,
										"getInViewExplicit(rootDO)"));
					}

					this.simulateEntityCreation(var9);
				} else {
					if (var10 != null && var11 != null) {
						continue;
					}

					if (var10 != null) {
						this.mapViewIdentifierToWIMIdentifier(var9, var10);
					} else if (var11 != null) {
						var10 = this.mapWIMIdentifierToViewIdentifier(var9, var11);
					}
				}

				if (var7 != null) {
					this.addAncestorsToDataObject(var9, var10);
				}
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "getInViewExplicit(rootDO)", WIMTraceHelper.printDataObject(var2));
			}

			return true;
		} else {
			return false;
		}
	}

	public boolean createInViewExplicit(String var1, DataObject var2) throws SubscriberException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "createInViewExplicit(rootDO)", WIMTraceHelper.printDataObject(var2));
		}

		List var5 = var2.getList("entities");
		if (var5 != null && var5.size() != 0) {
			DataObject var6 = (DataObject) var5.get(0);
			DataObject var7 = var6.getDataObject("identifier");
			if (var7 == null) {
				throw new SubscriberException(SubscriberExecStatus.FAILURE_LITERAL, "ENTITY_IDENTIFIER_NOT_SPECIFIED",
						CLASSNAME,
						new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED",
								WIMMessageHelper.generateMsgParms(var6), Level.WARNING, CLASSNAME,
								"createInViewExplicit(rootDO)"));
			} else {
				this.mapWIMIdentifierToViewIdentifier(var6, var7);
				if (var4) {
					trcLogger.exiting(CLASSNAME, "createInViewExplicit(rootDO)", WIMTraceHelper.printDataObject(var2));
				}

				return true;
			}
		} else {
			return false;
		}
	}

	public boolean deleteInViewExplicit(String var1, DataObject var2) {
		return true;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}