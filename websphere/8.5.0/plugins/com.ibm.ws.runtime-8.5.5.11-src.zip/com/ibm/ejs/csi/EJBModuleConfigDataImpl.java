package com.ibm.ejs.csi;

import com.ibm.websphere.csi.EJBModuleConfigData;

public class EJBModuleConfigDataImpl implements EJBModuleConfigData {
	private static final long serialVersionUID = -5249702119132194143L;
	private Object ivEJBJar;
	private Object ivBindings;
	private Object ivExtensions;

	public EJBModuleConfigDataImpl(Object ejbJar, Object bindings, Object extensions) {
		this.ivEJBJar = ejbJar;
		this.ivBindings = bindings;
		this.ivExtensions = extensions;
	}

	public Object getModule() {
		return this.ivEJBJar;
	}

	public Object getModuleBinding() {
		return this.ivBindings;
	}

	public Object getModuleExtension() {
		return this.ivExtensions;
	}
}