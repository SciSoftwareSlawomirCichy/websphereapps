package com.ibm.icu.text;

import com.ibm.icu.text.Normalizer.QuickCheckResult;
import com.ibm.icu.text.UnicodeSet.SpanCondition;
import java.io.IOException;

public class FilteredNormalizer2 extends Normalizer2 {
	private Normalizer2 norm2;
	private UnicodeSet set;

	public FilteredNormalizer2(Normalizer2 n2, UnicodeSet filterSet) {
		this.norm2 = n2;
		this.set = filterSet;
	}

	public StringBuilder normalize(CharSequence src, StringBuilder dest) {
		if (dest == src) {
			throw new IllegalArgumentException();
		} else {
			dest.setLength(0);
			this.normalize(src, dest, SpanCondition.SIMPLE);
			return dest;
		}
	}

	public Appendable normalize(CharSequence src, Appendable dest) {
		if (dest == src) {
			throw new IllegalArgumentException();
		} else {
			return this.normalize(src, dest, SpanCondition.SIMPLE);
		}
	}

	public StringBuilder normalizeSecondAndAppend(StringBuilder first, CharSequence second) {
		return this.normalizeSecondAndAppend(first, second, true);
	}

	public StringBuilder append(StringBuilder first, CharSequence second) {
		return this.normalizeSecondAndAppend(first, second, false);
	}

	public boolean isNormalized(CharSequence s) {
		SpanCondition spanCondition = SpanCondition.SIMPLE;

		int spanLimit;
		for (int prevSpanLimit = 0; prevSpanLimit < s.length(); prevSpanLimit = spanLimit) {
			spanLimit = this.set.span(s, prevSpanLimit, spanCondition);
			if (spanCondition == SpanCondition.NOT_CONTAINED) {
				spanCondition = SpanCondition.SIMPLE;
			} else {
				if (!this.norm2.isNormalized(s.subSequence(prevSpanLimit, spanLimit))) {
					return false;
				}

				spanCondition = SpanCondition.NOT_CONTAINED;
			}
		}

		return true;
	}

	public QuickCheckResult quickCheck(CharSequence s) {
		QuickCheckResult result = Normalizer.YES;
		SpanCondition spanCondition = SpanCondition.SIMPLE;

		int spanLimit;
		for (int prevSpanLimit = 0; prevSpanLimit < s.length(); prevSpanLimit = spanLimit) {
			spanLimit = this.set.span(s, prevSpanLimit, spanCondition);
			if (spanCondition == SpanCondition.NOT_CONTAINED) {
				spanCondition = SpanCondition.SIMPLE;
			} else {
				QuickCheckResult qcResult = this.norm2.quickCheck(s.subSequence(prevSpanLimit, spanLimit));
				if (qcResult == Normalizer.NO) {
					return qcResult;
				}

				if (qcResult == Normalizer.MAYBE) {
					result = qcResult;
				}

				spanCondition = SpanCondition.NOT_CONTAINED;
			}
		}

		return result;
	}

	public int spanQuickCheckYes(CharSequence s) {
		SpanCondition spanCondition = SpanCondition.SIMPLE;

		int spanLimit;
		for (int prevSpanLimit = 0; prevSpanLimit < s.length(); prevSpanLimit = spanLimit) {
			spanLimit = this.set.span(s, prevSpanLimit, spanCondition);
			if (spanCondition == SpanCondition.NOT_CONTAINED) {
				spanCondition = SpanCondition.SIMPLE;
			} else {
				int yesLimit = prevSpanLimit + this.norm2.spanQuickCheckYes(s.subSequence(prevSpanLimit, spanLimit));
				if (yesLimit < spanLimit) {
					return yesLimit;
				}

				spanCondition = SpanCondition.NOT_CONTAINED;
			}
		}

		return s.length();
	}

	public boolean hasBoundaryBefore(int c) {
		return !this.set.contains(c) || this.norm2.hasBoundaryBefore(c);
	}

	public boolean hasBoundaryAfter(int c) {
		return !this.set.contains(c) || this.norm2.hasBoundaryAfter(c);
	}

	public boolean isInert(int c) {
		return !this.set.contains(c) || this.norm2.isInert(c);
	}

	private Appendable normalize(CharSequence src, Appendable dest, SpanCondition spanCondition) {
		StringBuilder tempDest = new StringBuilder();

		try {
			int spanLimit;
			for (int prevSpanLimit = 0; prevSpanLimit < src.length(); prevSpanLimit = spanLimit) {
				spanLimit = this.set.span(src, prevSpanLimit, spanCondition);
				int spanLength = spanLimit - prevSpanLimit;
				if (spanCondition == SpanCondition.NOT_CONTAINED) {
					if (spanLength != 0) {
						dest.append(src, prevSpanLimit, spanLimit);
					}

					spanCondition = SpanCondition.SIMPLE;
				} else {
					if (spanLength != 0) {
						dest.append(this.norm2.normalize(src.subSequence(prevSpanLimit, spanLimit), tempDest));
					}

					spanCondition = SpanCondition.NOT_CONTAINED;
				}
			}

			return dest;
		} catch (IOException var8) {
			throw new RuntimeException(var8);
		}
	}

	private StringBuilder normalizeSecondAndAppend(StringBuilder first, CharSequence second, boolean doNormalize) {
		if (first == second) {
			throw new IllegalArgumentException();
		} else if (first.length() == 0) {
			return doNormalize ? this.normalize(second, first) : first.append(second);
		} else {
			int prefixLimit = this.set.span(second, 0, SpanCondition.SIMPLE);
			CharSequence rest;
			if (prefixLimit != 0) {
				rest = second.subSequence(0, prefixLimit);
				int suffixStart = this.set.spanBack(first, Integer.MAX_VALUE, SpanCondition.SIMPLE);
				if (suffixStart == 0) {
					if (doNormalize) {
						this.norm2.normalizeSecondAndAppend(first, rest);
					} else {
						this.norm2.append(first, rest);
					}
				} else {
					StringBuilder middle = new StringBuilder(first.subSequence(suffixStart, Integer.MAX_VALUE));
					if (doNormalize) {
						this.norm2.normalizeSecondAndAppend(middle, rest);
					} else {
						this.norm2.append(middle, rest);
					}

					first.delete(suffixStart, Integer.MAX_VALUE).append(middle);
				}
			}

			if (prefixLimit < second.length()) {
				rest = second.subSequence(prefixLimit, Integer.MAX_VALUE);
				if (doNormalize) {
					this.normalize(rest, first, SpanCondition.NOT_CONTAINED);
				} else {
					first.append(rest);
				}
			}

			return first;
		}
	}
}