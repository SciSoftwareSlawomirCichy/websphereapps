package com.ibm.ws.wim.util;

import com.ibm.websphere.wim.async.Ticket;
import com.ibm.websphere.wim.exception.InvalidTicketException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import commonj.sdo.DataObject;
import java.util.Map;

public class AsyncUtils {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = AsyncUtils.class.getName();

	public static DataObject getRequestControl(DataObject var0) {
		Map var1 = ControlsHelper.getControlMap(var0);
		return (DataObject) var1.get("RequestControl");
	}

	public static DataObject getResponseControl(DataObject var0) {
		Map var1 = ControlsHelper.getControlMap(var0);
		return (DataObject) var1.get("ResponseControl");
	}

	public static Ticket getTicket(DataObject var0) throws InvalidTicketException {
		Ticket var1 = null;
		DataObject var2 = getRequestControl(var0);
		if (var2 == null) {
			var2 = getResponseControl(var0);
		}

		if (var2 != null) {
			String var3 = var2.getString("ticket");
			if (var3 != null) {
				var1 = new Ticket(var3);
			}
		}

		return var1;
	}

	public static boolean isCheckAsyncOperationStatus(DataObject var0) {
		boolean var1 = false;
		DataObject var2 = getRequestControl(var0);
		if (var2 != null) {
			String var3 = var2.getString("ticket");
			if (var3 != null && var3.trim().length() > 0) {
				var1 = true;
			}
		}

		return var1;
	}

	public static boolean isOperationComplete(DataObject var0) {
		boolean var1 = true;
		DataObject var2 = getResponseControl(var0);
		if (var2 != null) {
			var1 = var2.getBoolean("complete");
		}

		return var1;
	}

	public static String getRepositoryId(DataObject var0) throws InvalidTicketException {
		String var1 = null;
		DataObject var2 = getRequestControl(var0);
		if (var2 == null) {
			var2 = getResponseControl(var0);
		}

		if (var2 != null) {
			String var3 = var2.getString("ticket");
			if (var3 != null && var3.trim().length() > 0) {
				Ticket var4 = new Ticket(var3);
				var1 = var4.getRepositoryId();
			}
		}

		return var1;
	}

	public static void asyncOperationNotSupported(DataObject var0, String var1, String var2, String var3)
			throws OperationNotSupportedException {
		DataObject var4 = getRequestControl(var0);
		if (var4 != null) {
			String var5 = var4.getString("requiredInteractionStyle");
			if (var5 != null && var5.equals("async")) {
				throw new OperationNotSupportedException("ASYNC_OPERATION_NOT_SUPPORTED_BY_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var1), var2, var3);
			}

			String var6 = var4.getString("ticket");
			if (var6 != null && var6.trim().length() > 0) {
				throw new OperationNotSupportedException("ASYNC_OPERATION_NOT_SUPPORTED_BY_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var1), var2, var3);
			}
		}

	}

	public static void setPostProcessing(DataObject var0, String var1) throws InvalidTicketException {
		Ticket var2 = getTicket(var0);
		if (var2 != null) {
			var2.setPostProcess(var1);
			DataObject var3 = getResponseControl(var0);
			var3.setString("ticket", var2.toString());
		}

	}

	public static void setPostProcessing(DataObject var0, DataObject var1) throws InvalidTicketException {
		Ticket var2 = getTicket(var1);
		if (var2 != null) {
			String var3 = var2.getPostProcess();
			setPostProcessing(var0, var3);
		}

	}

	public static String getPostProcessing(DataObject var0) throws InvalidTicketException {
		String var1 = null;
		Ticket var2 = getTicket(var0);
		if (var2 != null) {
			var1 = var2.getPostProcess();
		}

		return var1;
	}

	public static void setPagingSize(DataObject var0, int var1) throws InvalidTicketException {
		Ticket var2 = getTicket(var0);
		if (var2 != null) {
			var2.setPagingSize(var1);
			DataObject var3 = getResponseControl(var0);
			var3.setString("ticket", var2.toString());
		}

	}

	public static int getPagingSize(DataObject var0) throws InvalidTicketException {
		int var1 = 0;
		Ticket var2 = getTicket(var0);
		if (var2 != null) {
			var1 = var2.getPagingSize();
		}

		return var1;
	}

	public static void setCountLimit(DataObject var0, int var1) throws InvalidTicketException {
		Ticket var2 = getTicket(var0);
		if (var2 != null) {
			var2.setCountLimit(var1);
			DataObject var3 = getResponseControl(var0);
			var3.setString("ticket", var2.toString());
		}

	}

	public static int getCountLimit(DataObject var0) throws InvalidTicketException {
		int var1 = 0;
		Ticket var2 = getTicket(var0);
		if (var2 != null) {
			var1 = var2.getCountLimit();
		}

		return var1;
	}

	public static void setSearchLimit(DataObject var0, int var1) throws InvalidTicketException {
		Ticket var2 = getTicket(var0);
		if (var2 != null) {
			var2.setSearchLimit(var1);
			DataObject var3 = getResponseControl(var0);
			var3.setString("ticket", var2.toString());
		}

	}

	public static int getSearchLimit(DataObject var0) throws InvalidTicketException {
		int var1 = 0;
		Ticket var2 = getTicket(var0);
		if (var2 != null) {
			var1 = var2.getSearchLimit();
		}

		return var1;
	}
}