package com.ibm.ws.security.oidc.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.oidc.util.OidcUtil;
import java.util.ArrayList;
import java.util.Iterator;

public class IntrospectedAccessToken {
	private static final TraceComponent tc = Tr.register(IntrospectedAccessToken.class, "OidcClient",
			"com.ibm.ws.security.oidc.client.resources.oidcmessages");
	private String accessToken;
	private String subject;
	private long expiresIn;
	private long issuedAt;
	private String scope;
	private String audience;
	private String realmName;
	private String uniqueSecurityName;
	private String user;
	private ArrayList<String> groupIds;

	@Deprecated
	public IntrospectedAccessToken(String aToken, JsonObject jobj) throws RelyingPartyException {
		this(aToken, jobj, (RelyingPartyConfig) null);
	}

	public IntrospectedAccessToken(String aToken, JsonObject jobj, RelyingPartyConfig rpConfig)
			throws RelyingPartyException {
		this.accessToken = null;
		this.subject = null;
		this.expiresIn = 0L;
		this.issuedAt = 0L;
		this.scope = null;
		this.audience = null;
		this.realmName = null;
		this.uniqueSecurityName = null;
		this.user = null;
		this.groupIds = new ArrayList();
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "IntrospectedAccessToken(aToken[" + aToken + "], jobj[" + OidcUtil.getObjState(jobj)
					+ "], rpConfig[" + OidcUtil.getObjState(rpConfig) + "])");
		}

		if (rpConfig != null && aToken != null && jobj != null) {
			this.accessToken = aToken;
			this.subject = RelyingPartyUtils.getJsonValue(jobj, "sub").getAsString();
			this.expiresIn = RelyingPartyUtils.getJsonValue(jobj, "exp").getAsLong() * 1000L;
			this.issuedAt = RelyingPartyUtils.getJsonValue(jobj, "iat").getAsLong() * 1000L;
			this.scope = RelyingPartyUtils.getJsonValue(jobj, "scope").getAsString();
			this.realmName = RelyingPartyUtils.getJsonValue(jobj, rpConfig.getRealmIdentifier()).getAsString();
			if (this.realmName == null) {
				this.realmName = RelyingPartyUtils.getJsonValue(jobj, "iss").getAsString();
			}

			this.user = RelyingPartyUtils.getJsonValue(jobj, rpConfig.getUserIdentifier()).getAsString();
			this.uniqueSecurityName = RelyingPartyUtils.getJsonValue(jobj, rpConfig.getUniqueUserIdentifier())
					.getAsString();
			if (this.uniqueSecurityName == null) {
				this.uniqueSecurityName = this.user;
			}

			JsonElement gValue = jobj.get(rpConfig.getGroupIdentifier());
			if (gValue != null) {
				this.setGroupIds(gValue.getAsJsonArray());
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "IntrospectedAccessToken");
			}

		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "One or more of the parameters passed to this method is null");
			}

			throw new RelyingPartyException("one or more parameters passed to this method is null");
		}
	}

	private void setGroupIds(JsonArray groups) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setGroupIds(groups[" + OidcUtil.getObjState(groups) + "])");
		}

		String s1;
		for (Iterator i$ = groups.iterator(); i$.hasNext(); this.groupIds.add(s1)) {
			JsonElement g = (JsonElement) i$.next();
			s1 = "group:" + this.realmName + "/" + g.getAsString();
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Group IDs group: " + s1);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setGroupIds");
		}

	}

	public String getAccessToken() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getAccessToken returns [" + this.accessToken + "])");
		}

		return this.accessToken;
	}

	@Deprecated
	public String getSubject() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getSubject returns [" + this.subject + "])");
		}

		return this.subject;
	}

	public String getUser() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getUser returns [" + this.user + "])");
		}

		return this.user;
	}

	public String getScope() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getScope returns [" + this.scope + "])");
		}

		return this.scope;
	}

	public String getAudience() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getAudience returns [" + this.audience + "])");
		}

		return this.audience;
	}

	public String getRealmName() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getRealmName returns [" + this.realmName + "])");
		}

		return this.realmName;
	}

	public String getUniqueSecurityName() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getUniqueSecurityName returns [" + this.uniqueSecurityName + "])");
		}

		return this.uniqueSecurityName;
	}

	public long getExpiresIn() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getExpiresIn returns [" + this.expiresIn + "])");
		}

		return this.expiresIn;
	}

	public long getIssuedAt() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getIssuedAt returns [" + this.issuedAt + "])");
		}

		return this.issuedAt;
	}

	public ArrayList<String> getGroupIds() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getGroupIds returns [" + this.groupIds + "])");
		}

		return this.groupIds;
	}
}