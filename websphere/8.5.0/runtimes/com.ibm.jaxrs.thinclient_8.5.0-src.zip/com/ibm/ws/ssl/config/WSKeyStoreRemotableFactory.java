package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.websphere.models.config.ipc.ssl.KeyStore;
import com.ibm.ws.ssl.model.KeyStoreInfo;
import java.lang.reflect.Constructor;

public class WSKeyStoreRemotableFactory {
	private static final TraceComponent tc = Tr.register(WSKeyStoreRemotableFactory.class, "SSL",
			"com.ibm.ws.ssl.resources");
	private static WSKeyStoreRemotableInterface instance = null;
	private static final String className = "com.ibm.ws.ssl.config.WSKeyStoreRemotable";

	public static WSKeyStoreRemotableInterface getInstance() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance");
		}

		if ("com.ibm.ws.ssl.config.WSKeyStoreRemotable" != null
				&& !"com.ibm.ws.ssl.config.WSKeyStoreRemotable".equals("")) {
			try {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Using Pluggable SAF authorization manager",
							"com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}

				Class<?> myClass = Class.forName("com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				Constructor<?> cons = myClass.getConstructor();
				instance = (WSKeyStoreRemotableInterface) cons.newInstance();
			} catch (ClassNotFoundException var2) {
				Manager.Ffdc.log(var2, "com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory",
						"com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory.getInstance", "68");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not find class.", "com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}
			} catch (Exception var3) {
				Manager.Ffdc.log(var3, "com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory",
						"com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory.getInstance", "73");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not load class.", "com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance", instance);
		}

		return instance;
	}

	public static WSKeyStoreRemotableInterface getInstance(KeyStore keyStore) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance");
		}

		if ("com.ibm.ws.ssl.config.WSKeyStoreRemotable" != null
				&& !"com.ibm.ws.ssl.config.WSKeyStoreRemotable".equals("")) {
			try {
				Class<?> myClass = Class.forName("com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				Constructor<?> cons = myClass.getConstructor(KeyStore.class);
				instance = (WSKeyStoreRemotableInterface) cons.newInstance(keyStore);
			} catch (ClassNotFoundException var3) {
				Manager.Ffdc.log(var3, "com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory",
						"com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory.getInstance", "102");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not find class.", "com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}
			} catch (Exception var4) {
				Manager.Ffdc.log(var4, "com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory",
						"com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory.getInstance", "107");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not load class.", "com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance", instance);
		}

		return instance;
	}

	public static WSKeyStoreRemotableInterface getInstance(WSKeyStore wsks) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance");
		}

		if ("com.ibm.ws.ssl.config.WSKeyStoreRemotable" != null
				&& !"com.ibm.ws.ssl.config.WSKeyStoreRemotable".equals("")) {
			try {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Using Pluggable SAF authorization manager",
							"com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}

				Class<?> myClass = Class.forName("com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				Constructor<?> cons = myClass.getConstructor(WSKeyStore.class);
				instance = (WSKeyStoreRemotableInterface) cons.newInstance(wsks);
			} catch (ClassNotFoundException var3) {
				Manager.Ffdc.log(var3, "com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory",
						"com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory.getInstance", "138");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not find class.", "com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}
			} catch (Exception var4) {
				Manager.Ffdc.log(var4, "com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory",
						"com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory.getInstance", "143");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not load class.", "com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance", instance);
		}

		return instance;
	}

	public static WSKeyStoreRemotableInterface getInstance(KeyStoreInfo ksInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance");
		}

		if ("com.ibm.ws.ssl.config.WSKeyStoreRemotable" != null
				&& !"com.ibm.ws.ssl.config.WSKeyStoreRemotable".equals("")) {
			try {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Using Pluggable SAF authorization manager",
							"com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}

				Class<?> myClass = Class.forName("com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				Constructor<?> cons = myClass.getConstructor(KeyStoreInfo.class);
				instance = (WSKeyStoreRemotableInterface) cons.newInstance(ksInfo);
			} catch (ClassNotFoundException var3) {
				Manager.Ffdc.log(var3, "com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory",
						"com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory.getInstance", "174");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not find class.", "com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}
			} catch (Exception var4) {
				Manager.Ffdc.log(var4, "com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory",
						"com.ibm.ws.ssl.config.WSKeyStoreRemotableFactory.getInstance", "179");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not load class.", "com.ibm.ws.ssl.config.WSKeyStoreRemotable");
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance", instance);
		}

		return instance;
	}
}