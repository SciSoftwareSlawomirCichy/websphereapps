package com.ibm.icu.impl.data;

import java.util.ListResourceBundle;

public class BreakIteratorRules extends ListResourceBundle {
	static final Object[][] contents = new Object[][]{{"BreakIteratorClasses", new String[]{"RuleBasedBreakIterator",
			"RuleBasedBreakIterator", "RuleBasedBreakIterator", "RuleBasedBreakIterator", "RuleBasedBreakIterator"}}};

	public Object[][] getContents() {
		return contents;
	}
}