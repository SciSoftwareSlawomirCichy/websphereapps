package com.ibm.ejs.cm.pool;

import java.sql.SQLException;

public interface InvocationCollaborator {
	void preInvoke(boolean var1) throws SQLException;

	void postInvoke(SQLException var1) throws SQLException;
}