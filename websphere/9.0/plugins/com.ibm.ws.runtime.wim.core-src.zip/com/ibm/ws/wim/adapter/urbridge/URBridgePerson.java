package com.ibm.ws.wim.adapter.urbridge;

import com.ibm.websphere.security.EntryNotFoundException;
import com.ibm.websphere.security.NotImplementedException;
import com.ibm.websphere.security.UserRegistry;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.SchemaManager;
import commonj.sdo.DataObject;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class URBridgePerson extends URBridgeEntity {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	private static final Logger trcLogger;

	public URBridgePerson(DataObject var1, UserRegistry var2, Map var3, String var4, Map var5) {
		super(var1, var2, var3, var4, var5);
		this.securityNameProp = (String) var3.get("userSecurityNameProperty");
		this.uniqueIdProp = (String) var3.get("uniqueUserIdProperty");
		this.displayNameProp = (String) var3.get("userDisplayNameProperty");
		this.rdnProp = (String) var5.get(this.entity.getType().getName());
	}

	public String getUniqueIdForEntity(String var1) throws Exception {
		return this.reg.getUniqueUserId(var1);
	}

	public String getSecurityNameForEntity(String var1) throws Exception {
		return this.reg.getUserSecurityName(var1);
	}

	public String getDisplayNameForEntity(String var1) throws Exception {
		return this.reg.getUserDisplayName(var1);
	}

	public void getGroupsForUser(List var1, int var2) throws WIMException {
		String var3 = "getGroupsForUser";
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, var3, WIMTraceHelper.printDataObject(this.entity));
		}

		String var5 = null;

		try {
			var5 = this.getSecurityName(false);
			List var6 = this.reg.getGroupsForUser(var5);
			var2 = var2 == 0 ? var6.size() : var2;
			var2 = var2 < 0 ? 0 : var2;
			var2 = var6.size() > var2 ? var2 : var6.size();

			for (int var7 = 0; var7 < var2; ++var7) {
				DataObject var8 = SchemaManager.singleton().createRootDataObject();
				DataObject var9 = var8.createDataObject("entities", "http://www.ibm.com/websphere/wim",
						URBridgeHelper.getGroupAccountType());
				DataObject var10 = var9.createDataObject("identifier");
				URBridgeEntityFactory var11 = new URBridgeEntityFactory();
				URBridgeEntity var12 = var11.createObject(var9, this.reg, this.attrMap, this.baseEntryName,
						this.entityConfigMap);
				var12.setSecurityNameProp((String) var6.get(var7));
				var12.populateEntity(var1);
				var12.setRDNPropValue(this.stripRDN((String) var6.get(var7)));
				this.entity.getList("groups").add(var9);
			}
		} catch (EntryNotFoundException var13) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var5), Level.SEVERE,
					CLASSNAME, var3, var13);
		} catch (NotImplementedException var14) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var5), Level.SEVERE,
					CLASSNAME, var3, var14);
		} catch (Exception var15) {
			throw new WIMApplicationException("ENTITY_GET_FAILED",
					WIMMessageHelper.generateMsgParms(var5, var15.toString()), Level.SEVERE, CLASSNAME, var3, var15);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, var3, WIMTraceHelper.printDataObject(this.entity));
		}

	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}