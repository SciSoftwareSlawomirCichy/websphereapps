package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.J2EENameFactory;
import com.ibm.websphere.ejbcontainer.EJBFactory;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.util.ThreadContextAccessor;
import java.rmi.NoSuchObjectException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import javax.ejb.EJBException;
import javax.rmi.PortableRemoteObject;

public final class EJBFactoryImpl extends EJSRemoteWrapper implements EJBFactory {
	private static final String CLASS_NAME = EJBFactoryImpl.class.getName();
	private static final TraceComponent tc;
	private static final ThreadContextAccessor svThreadContextAccessor;
	private final HomeOfHomes ivHomeOfHomes;
	private J2EENameFactory ivJ2eeNameFactory;

	public EJBFactoryImpl(HomeOfHomes homeOfHomes, J2EENameFactory j2eeNameFactory) {
		this.ivHomeOfHomes = homeOfHomes;
		this.ivJ2eeNameFactory = j2eeNameFactory;
	}

	public Object create(String application, String beanName, String interfaceName)
			throws EJBException, RemoteException {
		if (application == null) {
			throw new IllegalArgumentException("Application name not specified");
		} else if (beanName == null) {
			throw new IllegalArgumentException("Bean name not specified");
		} else if (interfaceName == null) {
			throw new IllegalArgumentException("Interface name not specified");
		} else {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "create : application = " + application + ", beanName = " + beanName + ", interface = "
						+ interfaceName);
			}

			EJSHome home = null;

			try {
				HomeOfHomes homeOfHomes = EJSContainer.homeOfHomes;
				HomeRecord hr = homeOfHomes.resolveEJBLink(application, (String) null, beanName);
				home = hr.getHomeAndInitialize();
			} catch (Throwable var8) {
				FFDCFilter.processException(var8, CLASS_NAME + ".create", "186", this);
				EJBException ejbex = ExceptionUtil.EJBException("Failure locating " + beanName, var8);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "create: " + ejbex);
				}

				throw ejbex;
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "home = " + home.getJ2EEName());
			}

			Object retObj = this.create(home, interfaceName);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "create : " + retObj.getClass().getName());
			}

			return retObj;
		}
	}

	public Object create(String application, String module, String beanName, String interfaceName)
			throws EJBException, RemoteException {
		if (application == null) {
			throw new IllegalArgumentException("Application name not specified");
		} else if (module == null) {
			throw new IllegalArgumentException("Module name not specified");
		} else if (!module.endsWith(".jar") && !module.endsWith(".war")) {
			throw new IllegalArgumentException("Module must be a .jar or .war file");
		} else if (beanName == null) {
			throw new IllegalArgumentException("Bean name not specified");
		} else if (interfaceName == null) {
			throw new IllegalArgumentException("Interface name not specified");
		} else {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "create : application = " + application + ", module = " + module + ", bean = " + beanName
						+ ", interface = " + interfaceName);
			}

			Object retObj = null;
			EJSHome home = null;
			J2EEName j2eeName = null;

			try {
				j2eeName = this.ivJ2eeNameFactory.create(application, module, beanName);
				home = (EJSHome) this.ivHomeOfHomes.getHome(j2eeName);
				if (home == null) {
					throw new EJBNotFoundException("EJB named " + beanName + " not present in module " + module
							+ " of application " + application);
				}
			} catch (Throwable var11) {
				FFDCFilter.processException(var11, CLASS_NAME + ".create", "182", this);
				EJBException ejbex = ExceptionUtil.EJBException("Failure locating " + j2eeName, var11);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "create: " + ejbex);
				}

				throw ejbex;
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "home = " + home.getJ2EEName());
			}

			retObj = this.create(home, interfaceName);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "create : " + retObj.getClass().getName());
			}

			return retObj;
		}
	}

	private Object create(EJSHome home, String interfaceName) throws EJBException, RemoteException {
		BeanMetaData bmd = home.getBeanMetaData();
		if (interfaceName.equals(bmd.localHomeInterfaceClassName)) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "match on local home");
			}

			return home.getWrapper().getLocalObject();
		} else if (interfaceName.equals(bmd.homeInterfaceClassName)) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "match on remote home");
			}

			Remote wrapper = home.getWrapper().getRemoteWrapper();
			return toStub(wrapper, bmd.classLoader);
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "looking for match on business interface");
			}

			return this.createBusinessObject(home, bmd, interfaceName, true);
		}
	}

	public Object findByBeanName(String application, String beanName, String interfaceName)
			throws EJBException, RemoteException {
		if (application == null) {
			throw new IllegalArgumentException("Application name not specified");
		} else if (beanName == null) {
			throw new IllegalArgumentException("Bean name not specified");
		} else if (interfaceName == null) {
			throw new IllegalArgumentException("Interface name not specified");
		} else {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "findByBeanName : App = " + application + ", bean = " + beanName + ", interface = "
						+ interfaceName);
			}

			Object retObj = null;
			EJSHome home = null;

			try {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "looking for home in all app modules...");
				}

				home = this.ivHomeOfHomes.getHomeByName(application, beanName);
			} catch (Throwable var9) {
				FFDCFilter.processException(var9, CLASS_NAME + ".findByBeanName", "182", this);
				EJBException ejbex = ExceptionUtil
						.EJBException("Failure locating bean " + beanName + " in application " + application, var9);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "findByBeanName: " + ejbex);
				}

				throw ejbex;
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "home = " + home.getJ2EEName());
			}

			BeanMetaData bmd = home.getBeanMetaData();
			if (interfaceName.equals(bmd.localHomeInterfaceClassName)) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "match on local home");
				}

				retObj = home.getWrapper().getLocalObject();
			} else if (interfaceName.equals(bmd.homeInterfaceClassName)) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "match on remote home");
				}

				Remote wrapper = home.getWrapper().getRemoteWrapper();
				retObj = toStub(wrapper, bmd.classLoader);
			} else {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "looking for match on business interface");
				}

				retObj = this.createBusinessObject(home, bmd, interfaceName, true);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "findByBeanName : " + retObj.getClass().getName());
			}

			return retObj;
		}
	}

	public Object findByInterface(String application, String interfaceName) throws EJBException, RemoteException {
		if (application == null) {
			throw new IllegalArgumentException("Application name not specified");
		} else if (interfaceName == null) {
			throw new IllegalArgumentException("Interface name not specified");
		} else {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "findByInterface : App = " + application + ", interface = " + interfaceName);
			}

			Object retObj = null;
			EJSHome home = null;

			try {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "bean name not specified, auto-link on " + interfaceName);
				}

				home = this.ivHomeOfHomes.getHomeByInterface(application, (String) null, interfaceName);
			} catch (Throwable var8) {
				FFDCFilter.processException(var8, CLASS_NAME + ".findByInterface", "182", this);
				EJBException ejbex = ExceptionUtil.EJBException(
						"Failure locating interface " + interfaceName + " in application " + application, var8);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "findByInterface: " + ejbex);
				}

				throw ejbex;
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "home = " + home.getJ2EEName());
			}

			BeanMetaData bmd = home.getBeanMetaData();
			if (interfaceName.equals(bmd.localHomeInterfaceClassName)) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "match on local home");
				}

				retObj = home.getWrapper().getLocalObject();
			} else if (interfaceName.equals(bmd.homeInterfaceClassName)) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "match on remote home");
				}

				Remote wrapper = home.getWrapper().getRemoteWrapper();
				retObj = toStub(wrapper, bmd.classLoader);
			} else {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "looking for match on business interface");
				}

				retObj = this.createBusinessObject(home, bmd, interfaceName, false);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "findByInterface : " + retObj.getClass().getName());
			}

			return retObj;
		}
	}

	private Object createBusinessObject(EJSHome home, BeanMetaData bmd, String interfaceName, boolean ejblink)
			throws EJBException, NoSuchObjectException {
		Object retObj = null;

		try {
			retObj = home.createBusinessObject(interfaceName, ejblink);
		} catch (Throwable var8) {
			FFDCFilter.processException(var8, CLASS_NAME + ".createBusinessObject", "281", this);
			EJBException ejbex = ExceptionUtil.EJBException(
					"Failure creating instance of " + home.getJ2EEName() + " of type " + interfaceName, var8);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "createBusinessObject: " + ejbex);
			}

			throw ejbex;
		}

		if (retObj == null) {
			EJBException ejbex = new EJBException(
					"Unable to create instance of " + home.getJ2EEName() + " of type " + interfaceName);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "createBusinessObject: " + ejbex);
			}

			throw ejbex;
		} else {
			return retObj;
		}
	}

	private static Remote toStub(Remote wrapper, ClassLoader classLoader) throws NoSuchObjectException {
		Object origClassLoader = svThreadContextAccessor.pushContextClassLoaderForUnprivileged(classLoader);

		Remote var3;
		try {
			var3 = PortableRemoteObject.toStub(wrapper);
		} finally {
			svThreadContextAccessor.popContextClassLoaderForUnprivileged(origClassLoader);
		}

		return var3;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		svThreadContextAccessor = (ThreadContextAccessor) AccessController
				.doPrivileged(ThreadContextAccessor.getPrivilegedAction());
	}
}