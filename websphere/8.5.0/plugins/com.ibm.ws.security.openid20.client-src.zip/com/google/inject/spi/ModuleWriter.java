package com.google.inject.spi;

import com.google.inject.Binder;
import com.google.inject.Binding;
import com.google.inject.Key;
import com.google.inject.MembersInjector;
import com.google.inject.Module;
import com.google.inject.PrivateBinder;
import com.google.inject.Provider;
import com.google.inject.binder.ScopedBindingBuilder;
import com.google.inject.internal.Maps;
import com.google.inject.internal.Preconditions;
import com.google.inject.spi.ModuleWriter.1;
import com.google.inject.spi.ModuleWriter.2;
import com.google.inject.spi.ModuleWriter.3;
import com.google.inject.spi.ModuleWriter.4;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.aopalliance.intercept.MethodInterceptor;

public class ModuleWriter {
	private final Map<PrivateElements, PrivateBinder> environmentToBinder = Maps.newHashMap();

	public final Module create(Iterable<? extends Element> elements) {
      return new 1(this, elements);
   }

	public final void apply(Binder binder, Iterable<? extends Element> elements) {
      Preconditions.checkNotNull(binder, "binder");
      Preconditions.checkNotNull(elements, "elements");
      ElementVisitor<Void> visitor = new 2(this, binder);
      Iterator i$ = elements.iterator();

      while(i$.hasNext()) {
         Element element = (Element)i$.next();
         element.acceptVisitor(visitor);
      }

   }

	protected void writeMessage(Binder binder, Message element) {
		binder.addError(element);
	}

	protected void writeBindInterceptor(Binder binder, InterceptorBinding element) {
		List<MethodInterceptor> interceptors = element.getInterceptors();
		binder.withSource(element.getSource()).bindInterceptor(element.getClassMatcher(), element.getMethodMatcher(),
				(MethodInterceptor[]) interceptors.toArray(new MethodInterceptor[interceptors.size()]));
	}

	protected void writeBindListener(Binder binder, TypeListenerBinding element) {
		binder.withSource(element.getSource()).bindListener(element.getTypeMatcher(), element.getListener());
	}

	protected void writeBindScope(Binder binder, ScopeBinding element) {
		binder.withSource(element.getSource()).bindScope(element.getAnnotationType(), element.getScope());
	}

	protected void writeRequestInjection(Binder binder, InjectionRequest element) {
		binder.withSource(element.getSource()).requestInjection(element.getInstance());
	}

	protected void writeRequestStaticInjection(Binder binder, StaticInjectionRequest element) {
		Class<?> type = element.getType();
		binder.withSource(element.getSource()).requestStaticInjection(new Class[]{type});
	}

	protected void writeConvertToTypes(Binder binder, TypeConverterBinding element) {
		binder.withSource(element.getSource()).convertToTypes(element.getTypeMatcher(), element.getTypeConverter());
	}

	protected <T> void writeBind(Binder binder, Binding<T> element) {
		ScopedBindingBuilder sbb = this.bindKeyToTarget(element, binder.withSource(element.getSource()),
				element.getKey());
		this.applyScoping(element, sbb);
	}

	protected void writePrivateElements(Binder binder, PrivateElements element) {
		PrivateBinder privateBinder = binder.withSource(element.getSource()).newPrivateBinder();
		this.setPrivateBinder(element, privateBinder);
		this.apply(privateBinder, element.getElements());
	}

	protected <T> ScopedBindingBuilder bindKeyToTarget(Binding<T> binding, Binder binder, Key<T> key) {
      return (ScopedBindingBuilder)binding.acceptTargetVisitor(new 3(this, binder, key));
   }

	protected void setPrivateBinder(PrivateElements privateElements, PrivateBinder binder) {
		Preconditions.checkArgument(!this.environmentToBinder.containsKey(privateElements),
				"A private binder already exists for %s", new Object[]{privateElements});
		this.environmentToBinder.put(privateElements, binder);
	}

	protected PrivateBinder getPrivateBinder(PrivateElements privateElements) {
		PrivateBinder privateBinder = (PrivateBinder) this.environmentToBinder.get(privateElements);
		Preconditions.checkArgument(privateBinder != null, "No private binder for %s", new Object[]{privateElements});
		return privateBinder;
	}

	protected void applyScoping(Binding<?> binding, ScopedBindingBuilder scopedBindingBuilder) {
      binding.acceptScopingVisitor(new 4(this, scopedBindingBuilder));
   }

	protected <T> void writeGetProvider(Binder binder, ProviderLookup<T> element) {
		Provider<T> provider = binder.withSource(element.getSource()).getProvider(element.getKey());
		element.initializeDelegate(provider);
	}

	protected <T> void writeGetMembersInjector(Binder binder, MembersInjectorLookup<T> element) {
		MembersInjector<T> membersInjector = binder.withSource(element.getSource())
				.getMembersInjector(element.getType());
		element.initializeDelegate(membersInjector);
	}
}