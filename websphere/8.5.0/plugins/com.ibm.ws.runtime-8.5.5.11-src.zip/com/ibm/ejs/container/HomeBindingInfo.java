package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.HomeWrapperSet;
import java.rmi.Remote;

public class HomeBindingInfo implements HomeWrapperSet {
	private static final TraceComponent tc = Tr.register(HomeBindingInfo.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private Remote remoteHome;
	private Object localHome;

	public HomeBindingInfo(Remote rHome, Object lHome) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			if (rHome != null) {
				Tr.debug(tc, "HomeBinding Remote:" + rHome.getClass().getName());
			}

			if (lHome != null) {
				Tr.debug(tc, "HomeBinding Local:" + lHome.getClass().getName());
			}
		}

		this.remoteHome = rHome;
		this.localHome = lHome;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public Remote getRemote() {
		return this.remoteHome;
	}

	public Object getLocal() {
		return this.localHome;
	}
}