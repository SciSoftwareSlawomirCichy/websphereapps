package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.AbstractMultiset.ElementSet;
import com.google.common.collect.AbstractMultiset.EntrySet;
import com.google.common.collect.Multiset.Entry;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AbstractMultiset<E> extends AbstractCollection<E> implements Multiset<E> {
	@MonotonicNonNullDecl
	private transient Set<E> elementSet;
	@MonotonicNonNullDecl
	private transient Set<Entry<E>> entrySet;

	public boolean isEmpty() {
		return this.entrySet().isEmpty();
	}

	public boolean contains(@NullableDecl Object element) {
		return this.count(element) > 0;
	}

	@CanIgnoreReturnValue
	public final boolean add(@NullableDecl E element) {
		this.add(element, 1);
		return true;
	}

	@CanIgnoreReturnValue
	public int add(@NullableDecl E element, int occurrences) {
		throw new UnsupportedOperationException();
	}

	@CanIgnoreReturnValue
	public final boolean remove(@NullableDecl Object element) {
		return this.remove(element, 1) > 0;
	}

	@CanIgnoreReturnValue
	public int remove(@NullableDecl Object element, int occurrences) {
		throw new UnsupportedOperationException();
	}

	@CanIgnoreReturnValue
	public int setCount(@NullableDecl E element, int count) {
		return Multisets.setCountImpl(this, element, count);
	}

	@CanIgnoreReturnValue
	public boolean setCount(@NullableDecl E element, int oldCount, int newCount) {
		return Multisets.setCountImpl(this, element, oldCount, newCount);
	}

	@CanIgnoreReturnValue
	public final boolean addAll(Collection<? extends E> elementsToAdd) {
		return Multisets.addAllImpl(this, elementsToAdd);
	}

	@CanIgnoreReturnValue
	public final boolean removeAll(Collection<?> elementsToRemove) {
		return Multisets.removeAllImpl(this, elementsToRemove);
	}

	@CanIgnoreReturnValue
	public final boolean retainAll(Collection<?> elementsToRetain) {
		return Multisets.retainAllImpl(this, elementsToRetain);
	}

	public abstract void clear();

	public Set<E> elementSet() {
		Set<E> result = this.elementSet;
		if (result == null) {
			this.elementSet = result = this.createElementSet();
		}

		return result;
	}

	Set<E> createElementSet() {
		return new ElementSet(this);
	}

	abstract Iterator<E> elementIterator();

	public Set<Entry<E>> entrySet() {
		Set<Entry<E>> result = this.entrySet;
		if (result == null) {
			this.entrySet = result = this.createEntrySet();
		}

		return result;
	}

	Set<Entry<E>> createEntrySet() {
		return new EntrySet(this);
	}

	abstract Iterator<Entry<E>> entryIterator();

	abstract int distinctElements();

	public final boolean equals(@NullableDecl Object object) {
		return Multisets.equalsImpl(this, object);
	}

	public final int hashCode() {
		return this.entrySet().hashCode();
	}

	public final String toString() {
		return this.entrySet().toString();
	}
}