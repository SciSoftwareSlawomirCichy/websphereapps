package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.asynchbeans.TaskDetails;
import com.ibm.ws.csi.TimerTaskInfo;
import com.ibm.ws.ejb.portable.Constants;
import com.ibm.ws.ejbcontainer.util.ObjectUtil;
import com.ibm.ws.ejbcontainer.util.ParsedScheduleExpression;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.metadata.ejb.TimerMethodData.AutomaticTimer;
import com.ibm.ws.scheduler.AbstractTask;
import com.ibm.ws.scheduler.CustomCalendarTaskInfo;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;
import javax.ejb.ScheduleExpression;

public final class TimerTaskInfoImpl extends AbstractTask
		implements
			TaskDetails,
			TimerTaskInfo,
			CustomCalendarTaskInfo,
			Serializable {
	private static final TraceComponent tc = Tr.register(TimerTaskInfoImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.TimerTaskInfoImpl";
	private static final long serialVersionUID = -3085300434270658658L;
	private static final byte[] EYECATCHER;
	private static final short PLATFORM = 1;
	public static boolean svOnServer;
	private transient boolean ivDeserialized;
	private transient String ivApplication = null;
	private transient String ivModule = null;
	private transient String ivComponent = null;
	private transient String ivPrimaryKey = null;
	private transient String ivInfo = null;
	private transient ScheduleExpression ivScheduleExpression;
	private transient String ivAutomaticMethodName;

	public TimerTaskInfoImpl() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>: " + this.toString());
		}

	}

	TimerTaskInfoImpl(BeanId timedObjectId, AutomaticTimer autoTimer, Date startTime, long interval,
			ParsedScheduleExpression parsedSchedule, Serializable info, String taskName, boolean globalTx)
			throws IOException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			String infoClassName = info == null ? null : info.getClass().getName();
			Tr.entry(tc, "<init>: " + timedObjectId + ", " + startTime + ", " + interval + ", " + infoClassName + ", "
					+ taskName + ", " + globalTx);
		}

		if (!svOnServer) {
			throw new IllegalStateException("Method not supported on client.");
		} else {
			this.getTaskHolder()
					.setTargetRunnable(new TimerTaskHandler(timedObjectId, autoTimer, info, parsedSchedule));
			this.setName(taskName);
			this.setAutoPurge(true);
			this.setStartTime(startTime);
			if (parsedSchedule != null) {
				this.setNumberOfRepeats(-1);
				this.setRepeatInterval("ScheduleExpression");
			} else if (interval < 0L) {
				this.setNumberOfRepeats(1);
			} else {
				this.setNumberOfRepeats(-1);
				this.setRepeatInterval(Long.toString(interval) + "ms");
			}

			int qos = 2;
			if (globalTx) {
				qos = 1;
			}

			this.setQOS(qos);
			this.setTimeCalcMethod(1);
			this.setTaskExecutionOptions(1);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "<init>: " + this.toString());
			}

		}
	}

	public String getDescription() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getDescription: " + this.getTaskId());
		}

		TimerTaskHandler handler;
		J2EEName j2eeName;
		try {
			handler = this.getHandler();
			j2eeName = handler.getJ2EEName();
		} catch (Throwable var9) {
			Tr.exit(tc, "getDescription: ignoring exception", var9);
			return super.getDescription();
		}

		StringBuilder builder = new StringBuilder(this.getTaskId());
		builder.append(" (").append(j2eeName);
		String automaticMethodName = handler.getAutomaticMethodName();
		String result;
		if (automaticMethodName != null) {
			builder.append(' ');
			result = handler.getAutomaticClassName();
			if (result != null) {
				builder.append(result).append('.');
			}

			builder.append(automaticMethodName);

			String info;
			try {
				info = (String) handler.getInfo();
			} catch (Throwable var10) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "ignoring exception", var10);
				}

				info = "";
			}

			if (info != null) {
				builder.append(": ").append(info);
			}
		}

		result = builder.append(')').toString();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getDescription: " + result);
		}

		return result;
	}

	public boolean isDirty() {
		return false;
	}

	public Date applyDelta(Date startTime) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "applyDelta: " + startTime);
		}

		ParsedScheduleExpression parsedSchedule = this.getParsedSchedule();
		if (parsedSchedule == null) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "not a calendar-based timer");
			}

			throw new IllegalStateException();
		} else {
			long nextTimeout = parsedSchedule.getNextTimeout(startTime.getTime());
			if (nextTimeout == -1L) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "applyDelta: no more timeouts");
				}

				return null;
			} else {
				Date result = new Date(nextTimeout);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "applyDelta: " + result);
				}

				return result;
			}
		}
	}

	public boolean overrideUserCalendar() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "overrideUserCalendar");
		}

		boolean result = this.getParsedSchedule() != null;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "overrideUserCalendar: " + result);
		}

		return result;
	}

	public void setTimedObjectId(EJBKey beanId) {
		throw new IllegalStateException("TimedObjectId is read only");
	}

	public EJBKey getTimedObjectId() {
		if (!svOnServer) {
			throw new IllegalStateException("Method not supported on client.");
		} else {
			TimerTaskHandler taskHandler = this.getHandler();
			return taskHandler.getTimedObjectId();
		}
	}

	public void setInfo(Serializable info) {
		throw new IllegalStateException("Info is read only");
	}

	public Serializable getInfo() {
		if (!svOnServer) {
			throw new IllegalStateException("Method not supported on client.");
		} else {
			TimerTaskHandler taskHandler = this.getHandler();
			return taskHandler.getInfo();
		}
	}

	public String getApplication() {
		if (this.ivApplication == null) {
			this.getJ2EENameInfo();
		}

		return this.ivApplication;
	}

	public String getModule() {
		if (this.ivModule == null) {
			this.getJ2EENameInfo();
		}

		return this.ivModule;
	}

	public String getComponent() {
		if (this.ivComponent == null) {
			this.getJ2EENameInfo();
		}

		return this.ivComponent;
	}

	public String getPrimaryKeyString() {
		if (this.ivPrimaryKey == null && svOnServer) {
			try {
				TimerTaskHandler taskHandler = this.getHandler();
				Serializable pkey = taskHandler.getPrimaryKey();
				if (pkey != null) {
					this.ivPrimaryKey = pkey.toString();
				}
			} catch (Throwable var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.TimerTaskInfoImpl.getPrimaryKeyString", "419",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getPrimaryKeyString: " + var3);
				}

				this.ivPrimaryKey = "Not Available";
			}
		}

		return this.ivPrimaryKey;
	}

	public String getInfoString() {
		if (this.ivInfo == null && svOnServer) {
			try {
				TimerTaskHandler taskHandler = this.getHandler();
				Serializable info = taskHandler.getInfo();
				if (info != null) {
					this.ivInfo = info.toString();
				}
			} catch (Throwable var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.TimerTaskInfoImpl.getInfoString", "459", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getInfoString: " + var3);
				}

				this.ivInfo = "Not Available";
			}
		}

		return this.ivInfo;
	}

	public ScheduleExpression getScheduleExpression() {
		return this.ivScheduleExpression;
	}

	public String getAutomaticMethodName() {
		return this.ivAutomaticMethodName;
	}

	TimerTaskHandler getHandler() {
		return (TimerTaskHandler) this.getTaskHolder().getTargetRunnable();
	}

	public String getOwner() {
		return null;
	}

	public String getTaskName() {
		return this.TASKID + " " + this.getApplication() + ":" + this.getComponent() + " (EJB Timer)";
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "writeObject: " + this);
		}

		ScheduleExpression scheduleExpr = null;
		String automaticMethodName = null;
		if (this.ivDeserialized) {
			scheduleExpr = this.ivScheduleExpression;
			automaticMethodName = this.ivAutomaticMethodName;
		} else {
			ParsedScheduleExpression parsedSchedule = this.getParsedSchedule();
			if (parsedSchedule != null) {
				scheduleExpr = ObjectUtil.copyBase(parsedSchedule.getSchedule());
				automaticMethodName = this.getHandler().getAutomaticMethodName();
			}
		}

		int version = 1;
		if (scheduleExpr != null) {
			version = 2;
		}

		out.defaultWriteObject();
		out.write(EYECATCHER);
		out.writeShort(1);
		out.writeShort(version);
		out.writeObject(this.getApplication());
		out.writeObject(this.getModule());
		out.writeObject(this.getComponent());
		out.writeObject(this.getPrimaryKeyString());
		out.writeObject(this.getInfoString());
		if (version >= 2) {
			out.writeObject(scheduleExpr);
			out.writeObject(automaticMethodName);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "writeObject");
		}

	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "readObject");
		}

		in.defaultReadObject();
		byte[] eyeCatcher = new byte[EYECATCHER.length];
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < EYECATCHER.length; i += bytesRead) {
			bytesRead = in.read(eyeCatcher, i, EYECATCHER.length - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < EYECATCHER.length; ++i) {
			if (EYECATCHER[i] != eyeCatcher[i]) {
				String eyeCatcherString = new String(eyeCatcher);
				throw new IOException("Invalid eye catcher '" + eyeCatcherString + "' in TimerHandle input stream");
			}
		}

		short incoming_platform = in.readShort();
		short incoming_vid = in.readShort();
		if (incoming_vid != 1 && incoming_vid != 2) {
			throw new InvalidObjectException(
					"EJB TimerTaskHandler data stream is not of the correct version, this client should be updated.");
		} else {
			this.ivApplication = (String) in.readObject();
			this.ivModule = (String) in.readObject();
			this.ivComponent = (String) in.readObject();
			this.ivPrimaryKey = (String) in.readObject();
			this.ivInfo = (String) in.readObject();
			if (incoming_vid >= 2) {
				this.ivScheduleExpression = (ScheduleExpression) in.readObject();
				this.ivAutomaticMethodName = (String) in.readObject();
			}

			this.ivDeserialized = true;
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "readObject: " + this);
			}

		}
	}

	ParsedScheduleExpression getParsedSchedule() {
		TimerTaskHandler taskHandler = this.getHandler();
		return taskHandler.getParsedSchedule();
	}

	private void getJ2EENameInfo() {
		this.ivApplication = "Not Available";
		this.ivModule = "Not Available";
		this.ivComponent = "Not Available";
		if (svOnServer) {
			try {
				TimerTaskHandler taskHandler = this.getHandler();
				J2EEName j2eeName = taskHandler.getJ2EEName();
				this.ivApplication = j2eeName.getApplication();
				this.ivModule = j2eeName.getModule();
				this.ivComponent = j2eeName.getComponent();
			} catch (Throwable var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.TimerTaskInfoImpl.getJ2EENameInfo", "613",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getJ2EENameInfo: " + var3);
				}
			}
		}

	}

	public String toString() {
		if (!TraceComponent.isAnyTracingEnabled()
				|| !tc.isDebugEnabled() && !tc.isEntryEnabled() && !tc.isEventEnabled()) {
			return super.toString();
		} else if (svOnServer) {
			try {
				return "TimerTaskInfoImpl(" + this.getHandler() + ") : " + super.toString();
			} catch (Throwable var2) {
				FFDCFilter.processException(var2, "com.ibm.ejs.container.TimerTaskInfoImpl.toString", "650", this);
				return "TimerTaskInfoImpl(" + this.getApplication() + ", " + this.getModule() + ", "
						+ this.getComponent() + ", " + this.getPrimaryKeyString() + ", " + this.getInfoString() + ") : "
						+ super.toString();
			}
		} else {
			return "TimerTaskInfoImpl(" + this.ivApplication + ", " + this.ivModule + ", " + this.ivComponent + ", "
					+ this.ivPrimaryKey + ", " + this.ivInfo + ") : " + super.toString();
		}
	}

	static {
		EYECATCHER = Constants.TIMER_TASK_EYE_CATCHER;
		svOnServer = false;
	}
}