package com.ibm.ejs.container;

import com.ibm.ejs.ras.Untraceable;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;

public abstract class EJSWrapperBase implements Untraceable {
	public EJSContainer container;
	public BeanId beanId;
	public BeanMetaData bmd;
	protected EJBMethodInfoImpl[] methodInfos;
	protected int[] isolationAttrs;
	protected String[] methodNames;
	protected WrapperManager wrapperManager;
	public EJBPMICollaborator ivPmiBean = null;
	protected EJSWrapperCommon ivCommon;
	protected boolean isManagedWrapper = false;
	public WrapperInterface ivInterface;
	public static final int AGGREGATE_LOCAL_INDEX = -2;
	public static final String AGGREGATE_EYE_CATCHER = "AGGREGATE";
	public int ivBusinessInterfaceIndex;

	public String toString() {
		return super.toString() + "(" + this.beanId.toString() + ")";
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		} else if (!(other instanceof EJSWrapperBase)) {
			return false;
		} else {
			EJSWrapperBase otherWrapper = (EJSWrapperBase) other;
			return this.ivInterface == otherWrapper.ivInterface
					&& this.ivBusinessInterfaceIndex == otherWrapper.ivBusinessInterfaceIndex
					&& this.beanId.equals(otherWrapper.beanId);
		}
	}

	public int hashCode() {
		return this.beanId.hashCode() ^ this.ivInterface.ordinal() ^ this.ivBusinessInterfaceIndex;
	}
}