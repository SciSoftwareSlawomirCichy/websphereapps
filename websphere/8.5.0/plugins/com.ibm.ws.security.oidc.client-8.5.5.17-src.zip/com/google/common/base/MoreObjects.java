package com.google.common.base;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.MoreObjects.1;
import com.google.common.base.MoreObjects.ToStringHelper;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public final class MoreObjects {
	public static <T> T firstNonNull(@NullableDecl T first, @NullableDecl T second) {
		if (first != null) {
			return first;
		} else if (second != null) {
			return second;
		} else {
			throw new NullPointerException("Both parameters are null");
		}
	}

	public static ToStringHelper toStringHelper(Object self) {
      return new ToStringHelper(self.getClass().getSimpleName(), (1)null);
   }

	public static ToStringHelper toStringHelper(Class<?> clazz) {
      return new ToStringHelper(clazz.getSimpleName(), (1)null);
   }

	public static ToStringHelper toStringHelper(String className) {
      return new ToStringHelper(className, (1)null);
   }
}