package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface ProfileRepositoryType extends RepositoryType {
	List getBaseEntries();

	BaseEntriesType[] getBaseEntriesAsArray();

	BaseEntriesType createBaseEntries();

	List getEntityTypesNotAllowCreate();

	String[] getEntityTypesNotAllowCreateAsArray();

	List getEntityTypesNotAllowUpdate();

	String[] getEntityTypesNotAllowUpdateAsArray();

	List getEntityTypesNotAllowRead();

	String[] getEntityTypesNotAllowReadAsArray();

	List getEntityTypesNotAllowDelete();

	String[] getEntityTypesNotAllowDeleteAsArray();

	List getRepositoriesForGroups();

	String[] getRepositoriesForGroupsAsArray();

	List getLoginProperties();

	String[] getLoginPropertiesAsArray();

	List getCustomProperties();

	CustomPropertiesType[] getCustomPropertiesAsArray();

	CustomPropertiesType createCustomProperties();

	boolean isIsExtIdUnique();

	void setIsExtIdUnique(boolean var1);

	void unsetIsExtIdUnique();

	boolean isSetIsExtIdUnique();

	boolean isReadOnly();

	void setReadOnly(boolean var1);

	void unsetReadOnly();

	boolean isSetReadOnly();

	boolean isSupportAsyncMode();

	void setSupportAsyncMode(boolean var1);

	void unsetSupportAsyncMode();

	boolean isSetSupportAsyncMode();

	String getSupportChangeLog();

	void setSupportChangeLog(String var1);

	void unsetSupportChangeLog();

	boolean isSetSupportChangeLog();

	boolean isSupportExternalName();

	void setSupportExternalName(boolean var1);

	void unsetSupportExternalName();

	boolean isSetSupportExternalName();

	boolean isSupportPaging();

	void setSupportPaging(boolean var1);

	void unsetSupportPaging();

	boolean isSetSupportPaging();

	boolean isSupportSorting();

	void setSupportSorting(boolean var1);

	void unsetSupportSorting();

	boolean isSetSupportSorting();

	boolean isSupportTransactions();

	void setSupportTransactions(boolean var1);

	void unsetSupportTransactions();

	boolean isSetSupportTransactions();
}