package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.MoreObjects;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.collect.MapMaker;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.CycleDetectingLockFactory.1;
import com.google.common.util.concurrent.CycleDetectingLockFactory.CycleDetectingLock;
import com.google.common.util.concurrent.CycleDetectingLockFactory.CycleDetectingReentrantLock;
import com.google.common.util.concurrent.CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock;
import com.google.common.util.concurrent.CycleDetectingLockFactory.LockGraphNode;
import com.google.common.util.concurrent.CycleDetectingLockFactory.Policies;
import com.google.common.util.concurrent.CycleDetectingLockFactory.Policy;
import com.google.common.util.concurrent.CycleDetectingLockFactory.WithExplicitOrdering;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Logger;

@Beta
@CanIgnoreReturnValue
@GwtIncompatible
public class CycleDetectingLockFactory {
	private static final ConcurrentMap<Class<? extends Enum>, Map<? extends Enum, LockGraphNode>> lockGraphNodesPerType = (new MapMaker())
			.weakKeys().makeMap();
	private static final Logger logger = Logger.getLogger(CycleDetectingLockFactory.class.getName());
	final Policy policy;
	private static final ThreadLocal<ArrayList<LockGraphNode>> acquiredLocks = new 1();

	public static CycleDetectingLockFactory newInstance(Policy policy) {
		return new CycleDetectingLockFactory(policy);
	}

	public ReentrantLock newReentrantLock(String lockName) {
		return this.newReentrantLock(lockName, false);
	}

	public ReentrantLock newReentrantLock(String lockName, boolean fair) {
      return (ReentrantLock)(this.policy == Policies.DISABLED ? new ReentrantLock(fair) : new CycleDetectingReentrantLock(this, new LockGraphNode(lockName), fair, (1)null));
   }

	public ReentrantReadWriteLock newReentrantReadWriteLock(String lockName) {
		return this.newReentrantReadWriteLock(lockName, false);
	}

	public ReentrantReadWriteLock newReentrantReadWriteLock(String lockName, boolean fair) {
      return (ReentrantReadWriteLock)(this.policy == Policies.DISABLED ? new ReentrantReadWriteLock(fair) : new CycleDetectingReentrantReadWriteLock(this, new LockGraphNode(lockName), fair, (1)null));
   }

	public static <E extends Enum<E>> WithExplicitOrdering<E> newInstanceWithExplicitOrdering(Class<E> enumClass,
			Policy policy) {
		Preconditions.checkNotNull(enumClass);
		Preconditions.checkNotNull(policy);
		Map<E, LockGraphNode> lockGraphNodes = getOrCreateNodes(enumClass);
		return new WithExplicitOrdering(policy, lockGraphNodes);
	}

	private static Map<? extends Enum, LockGraphNode> getOrCreateNodes(Class<? extends Enum> clazz) {
		Map<? extends Enum, LockGraphNode> existing = (Map) lockGraphNodesPerType.get(clazz);
		if (existing != null) {
			return existing;
		} else {
			Map<? extends Enum, LockGraphNode> created = createNodes(clazz);
			existing = (Map) lockGraphNodesPerType.putIfAbsent(clazz, created);
			return (Map) MoreObjects.firstNonNull(existing, created);
		}
	}

	@VisibleForTesting
	static <E extends Enum<E>> Map<E, LockGraphNode> createNodes(Class<E> clazz) {
		EnumMap<E, LockGraphNode> map = Maps.newEnumMap(clazz);
		E[] keys = (Enum[]) clazz.getEnumConstants();
		int numKeys = keys.length;
		ArrayList<LockGraphNode> nodes = Lists.newArrayListWithCapacity(numKeys);
		Enum[] var5 = keys;
		int var6 = keys.length;

		for (int var7 = 0; var7 < var6; ++var7) {
			E key = var5[var7];
			LockGraphNode node = new LockGraphNode(getLockName(key));
			nodes.add(node);
			map.put(key, node);
		}

		int i;
		for (i = 1; i < numKeys; ++i) {
			((LockGraphNode) nodes.get(i)).checkAcquiredLocks(Policies.THROW, nodes.subList(0, i));
		}

		for (i = 0; i < numKeys - 1; ++i) {
			((LockGraphNode) nodes.get(i)).checkAcquiredLocks(Policies.DISABLED, nodes.subList(i + 1, numKeys));
		}

		return Collections.unmodifiableMap(map);
	}

	private static String getLockName(Enum<?> rank) {
		return rank.getDeclaringClass().getSimpleName() + "." + rank.name();
	}

	private CycleDetectingLockFactory(Policy policy) {
		this.policy = (Policy) Preconditions.checkNotNull(policy);
	}

	private void aboutToAcquire(CycleDetectingLock lock) {
		if (!lock.isAcquiredByCurrentThread()) {
			ArrayList<LockGraphNode> acquiredLockList = (ArrayList) acquiredLocks.get();
			LockGraphNode node = lock.getLockGraphNode();
			node.checkAcquiredLocks(this.policy, acquiredLockList);
			acquiredLockList.add(node);
		}

	}

	private static void lockStateChanged(CycleDetectingLock lock) {
		if (!lock.isAcquiredByCurrentThread()) {
			ArrayList<LockGraphNode> acquiredLockList = (ArrayList) acquiredLocks.get();
			LockGraphNode node = lock.getLockGraphNode();

			for (int i = acquiredLockList.size() - 1; i >= 0; --i) {
				if (acquiredLockList.get(i) == node) {
					acquiredLockList.remove(i);
					break;
				}
			}
		}

	}
}