package com.ibm.ws.wim.pluginmanager;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.SubscriberException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.util.Routines;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.wsspi.wim.pluginmanager.Subscriber;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PGSubscriptionManager {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static Logger trcLogger;
	private static Map<String, PGSubscriptionManager> singleton;
	private HashMap subscriberMap = new HashMap();
	private HashMap emitterRegistrations = new HashMap();
	private HashMap emptyTopicEmitterList = new HashMap();

	public void clearAllSubscriptions() {
		this.subscriberMap.clear();
		this.emitterRegistrations.clear();
		this.emptyTopicEmitterList.clear();
	}

	public void printSubscriptions() {
		String var1 = "printSubscriptions";
		StringBuffer var2 = new StringBuffer();
		if (trcLogger.isLoggable(Level.FINEST)) {
			var2.append("Subscribers List: BEGIN ---------->\n");
			Iterator var3 = this.subscriberMap.keySet().iterator();

			String var4;
			while (var3.hasNext()) {
				var4 = (String) var3.next();
				Subscriber var5 = (Subscriber) this.subscriberMap.get(var4);
				var2.append(" SubscriberName: " + var5.getSubscriberName());
				var2.append(" SubscriberType: " + var5.getSubscriberType().getName());
				var2.append(" SubscriberClass: " + var5.getClass().getName()).append("\n");
			}

			var2.append("Subscribers List: END ---------->\n");
			var2.append("EmitterRegistration List: BEGIN ---------------\n");
			var3 = this.emitterRegistrations.keySet().iterator();

			while (var3.hasNext()) {
				var4 = (String) var3.next();
				EmitterReference var6 = (EmitterReference) this.emitterRegistrations.get(var4);
				var2.append(var6.printEmitterReference());
			}

			var2.append("EmitterRegistration List: END --------------->\n");
			Routines.logMessage(trcLogger, CLASSNAME, var1, Level.FINEST, var2.toString());
		}

	}

	public static PGSubscriptionManager getSubscriptionManager() {
		String var0 = DomainManagerUtils.getDomainName();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new PGSubscriptionManager());
		}

		return (PGSubscriptionManager) singleton.get(var0);
	}

	public void setEmitter(EmitterReference var1) {
		String var2 = var1.getEmitterName();
		this.emitterRegistrations.put(var2, var1);
	}

	public EmitterReference getEmitter(String var1) {
		EmitterReference var2 = null;
		if (this.emitterRegistrations.containsKey(var1)) {
			var2 = (EmitterReference) this.emitterRegistrations.get(var1);
		}

		return var2;
	}

	public boolean isEmitterEmpty(String var1) {
		boolean var2 = true;
		if (this.emptyTopicEmitterList.containsKey(var1)) {
			Boolean var3 = (Boolean) this.emptyTopicEmitterList.get(var1);
			var2 = var3;
		} else {
			EmitterReference var8 = this.getEmitter(var1);
			int var4 = 0;
			Vector var5 = var8.getPreExitModificationList();
			if (var5 != null) {
				var4 += var5.size();
			}

			var5 = var8.getPreExitNotificationList();
			if (var5 != null) {
				var4 += var5.size();
			}

			var5 = var8.getPostExitModificationList();
			if (var5 != null) {
				var4 += var5.size();
			}

			var5 = var8.getPostExitNotificationList();
			if (var5 != null) {
				var4 += var5.size();
			}

			ExitPointExecList[] var6 = var8.getInlineExits();

			for (int var7 = 0; var6 != null && var7 < var6.length; ++var7) {
				var5 = var6[var7].getModificationList();
				if (var5 != null) {
					var4 += var5.size();
				}
			}

			if (var4 > 0) {
				var2 = false;
				this.emptyTopicEmitterList.put(var1, false);
			} else {
				this.emptyTopicEmitterList.put(var1, true);
			}
		}

		return var2;
	}

	public boolean isEmitterAvailable(String var1) {
		return this.emitterRegistrations.containsKey(var1);
	}

	public void registerSubscriber(String var1, Subscriber var2) {
		this.subscriberMap.put(var1, var2);
	}

	public boolean isSubscriberAvailable(String var1) {
		return this.subscriberMap.containsKey(var1);
	}

	public Subscriber getSubscriber(String var1) {
		return (Subscriber) this.subscriberMap.get(var1);
	}

	public void shutdownSubscribers() {
		String var1 = "shutdownSubscribers";
		Iterator var2 = this.subscriberMap.keySet().iterator();

		while (var2.hasNext()) {
			Subscriber var3 = (Subscriber) this.subscriberMap.get(var2.next());

			try {
				var3.shutdownSubscriber();
			} catch (SubscriberException var5) {
				Routines.logException(trcLogger, CLASSNAME, var1, Level.WARNING, var5.getReasonString(), var5);
			}
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = PGSubscriptionManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
	}
}