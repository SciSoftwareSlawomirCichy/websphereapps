package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.security.authz.Entitlement;
import com.ibm.websphere.wim.util.SDOUtils;
import com.ibm.ws.security.role.RoleBasedAuthorizer;
import com.ibm.ws.security.role.RoleBasedConfigurator;
import com.ibm.ws.security.role.RoleBasedConfiguratorFactory;
import com.ibm.ws.sm.workspace.RepositoryContext;
import com.ibm.ws.sm.workspace.WorkSpace;
import com.ibm.ws.sm.workspace.WorkSpaceException;
import com.ibm.ws.sm.workspace.WorkSpaceManagerFactory;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.EnvironmentManager;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.management.DynamicReloadManager;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.util.DataGraphHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;

public class ConfigSessionManager {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static Map<String, ConfigSessionManager> singleton;
	private ConfigManager configManager = null;
	private String wimConfigXMLFilePath = null;
	private String configPathInCell = null;
	private String configXMLFileRelativePath = "wim/config/wimconfig.xml";
	private Map configDOCache = Collections.synchronizedMap(new HashMap());
	private Map configContextCache = Collections.synchronizedMap(new HashMap());
	private Map configWorkspaceCache = Collections.synchronizedMap(new HashMap());
	private static final String sFileSep;

	private ConfigSessionManager() throws WIMException {
		this.configManager = ConfigManager.singleton();
		if (DomainManagerUtils.isAdminDomain()) {
			this.wimConfigXMLFilePath = this.configManager.getWIMConfigXMLFilePath();
		} else {
			this.wimConfigXMLFilePath = DomainManagerUtils.getDomainPath(DomainManagerUtils.getDomainName())
					+ this.configXMLFileRelativePath;
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "<init>", "wimConfigXMLFilePath=" + this.wimConfigXMLFilePath
					+ ", configXMLFileRelativePath=" + this.configXMLFileRelativePath);
		}

	}

	public static synchronized ConfigSessionManager singleton() throws WIMException {
		String var0 = DomainManagerUtils.getDomainName();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new ConfigSessionManager());
		}

		return (ConfigSessionManager) singleton.get(var0);
	}

	public static void clearCache(String var0) {
		singleton.put(var0, (Object) null);
	}

	public synchronized void resetConfig(String var1) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "resetConfig", "sessionId=" + var1);
		}

		this.clearCaches(var1);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "resetConfig");
		}

	}

	private DataGraph loadLatestConfigFromXML(String var1) throws WIMException {
		EDataGraph var3 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "loadLatestConfigFromXML", "xmlFilePath=" + var1);
		}

		long var4 = System.currentTimeMillis();

		try {
			FileInputStream var6 = new FileInputStream(var1);
			HashMap var7 = new HashMap();
			var3 = SDOUtil.loadDataGraph(var6, var7);
			if (trcLogger.isLoggable(Level.FINER)) {
				long var8 = System.currentTimeMillis();
				trcLogger.logp(Level.FINER, CLASSNAME, "loadLatestConfigFromXML",
						"Loaded from " + var1 + " (" + (var8 - var4) + " milliseconds)");
			}
		} catch (FileNotFoundException var10) {
			throw new InitializationException("WIM_CONFIG_XML_FILE_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
					CLASSNAME, "loadLatestConfigFromXML", var10);
		} catch (IOException var11) {
			throw new InitializationException("INVALID_WIM_CONFIG_XML_FILE",
					WIMMessageHelper.generateMsgParms(var1, var11.getMessage()), CLASSNAME, "loadLatestConfigFromXML",
					var11);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "loadLatestConfigFromXML");
		}

		return var3;
	}

	private void clearCaches(String var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "clearCaches", "sessionId=" + var1);
		}

		this.configDOCache.remove(var1);
		RepositoryContext var3 = (RepositoryContext) this.configContextCache.remove(var1);
		WorkSpace var4 = (WorkSpace) this.configWorkspaceCache.remove(var1);
		if (var4 != null) {
			try {
				var4.release(var3);
			} catch (WorkSpaceException var6) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "clearCaches",
							"exception releasing repository context from workspace for sessionId = " + var1);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "clearCaches");
		}

	}

	private void validateWorkspace(String var1, String var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateWorkspace", "sessionId=" + var2);
		}

		boolean var4 = true;
		WorkSpace var5 = (WorkSpace) this.configWorkspaceCache.get(var2);
		if (var5 != null) {
			try {
				var5.checkValid();
			} catch (Exception var7) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "validateWorkspace",
							"invalid workspace for sessionId=" + var2 + ", method=" + var1);
				}

				var4 = false;
				this.clearCaches(var2);
			}

			RepositoryContext var6 = (RepositoryContext) this.configContextCache.get(var2);
			if (var6 != null) {
				var6.getAllList(false);
				if (var6.isExtracted(this.configXMLFileRelativePath)) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "validateWorkspace",
								"Config is still extracted for sessionId=" + var2 + ", method=" + var1);
					}
				} else {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "validateWorkspace",
								"Config is NOT extracted for sessionId=" + var2 + ", method=" + var1);
					}

					var4 = false;
					this.clearCaches(var2);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "validateWorkspace", "valid=" + var4);
		}

	}

	public synchronized ConfigurationProviderType getConfig(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getConfig", "sessionId=" + var1);
		}

		boolean var3 = false;
		if (EnvironmentManager.singleton().isAminServiceAvailable()) {
			var3 = this.hasConfigAcccess();
		}

		if (!var3) {
			ProfileSecurityManager var4 = ProfileSecurityManager.singleton();
			var4.checkPermission_SuperUser(new Entitlement("GET", "CONFIGURATION"));
		}

		this.validateWorkspace("getConfig", var1);
		this.wimConfigXMLFilePath = DomainManagerUtils.getDomainPathFromTemp(DomainManagerUtils.getDomainName(), var1)
				+ this.configXMLFileRelativePath;
		ConfigurationProviderType var8 = (ConfigurationProviderType) this.configDOCache.get(var1);
		if (var8 == null) {
			if (!(new File(this.wimConfigXMLFilePath)).exists()) {
				if (DomainManagerUtils.isAdminDomain()) {
					this.wimConfigXMLFilePath = this.configManager.getWIMConfigXMLFilePath();
				} else {
					this.wimConfigXMLFilePath = DomainManagerUtils.getDomainPath(DomainManagerUtils.getDomainName())
							+ this.configXMLFileRelativePath;
				}
			}

			String var5 = this.wimConfigXMLFilePath;
			if (DynamicReloadManager.isRunningOnAdminAgent() || DynamicReloadManager.isRegisteredWithAdminAgentMode()) {
				try {
					if (DomainManagerUtils.isAdminDomain()) {
						if (!(new File(var5)).exists()) {
							var5 = this.configManager.getCurrentContextConfigDirectory() + sFileSep + "cells" + sFileSep
									+ DynamicReloadManager.getCellName() + sFileSep + "wim" + sFileSep + "config"
									+ sFileSep + "wimconfig.xml";
						}
					} else if (!(new File(var5)).exists()) {
						var5 = DomainManagerUtils.getDomainPath(DomainManagerUtils.getDomainName()) + "wim"
								+ File.separator + "config" + File.separator + "wimconfig.xml";
					}
				} catch (Exception var7) {
					msgLogger.logp(Level.WARNING, CLASSNAME, "getConfig", "WIM_CONFIG_XML_FILE_NOT_FOUND",
							WIMMessageHelper.generateMsgParms("wimconfig.xml"));
					msgLogger.logp(Level.WARNING, CLASSNAME, "getConfig", "GENERIC", var7);
				}
			}

			if (DomainManagerUtils.isAdminDomain()) {
				if (!(new File(var5)).exists()) {
					var5 = this.configManager.getWIMConfigXMLFilePath();
				}
			} else if (!(new File(var5)).exists()) {
				var5 = DomainManagerUtils.getDomainPath(DomainManagerUtils.getDomainName())
						+ this.configXMLFileRelativePath;
			}

			DataGraph var6 = this.loadLatestConfigFromXML(var5);
			if (var6 != null) {
				var8 = (ConfigurationProviderType) var6.getRootObject().getDataObject("configurationProvider");
				this.configDOCache.put(var1, var8);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getConfig", "new session, added to cache");
				}
			} else if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "getConfig", "Config XML could not be read.");
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getConfig");
		}

		return var8;
	}

	public synchronized String saveConfig(String var1, boolean var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "saveConfig(sessionId,validate)", "sessionId=" + var1 + ", validate=" + var2);
		}

		ProfileSecurityManager var5 = ProfileSecurityManager.singleton();
		var5.checkPermission_SuperUser(new Entitlement("UPDATE", "CONFIGURATION"));
		this.validateWorkspace("saveConfig(sessionId,validate)", var1);
		String var6 = "CONFIG_SAVED_IN_WORKSPACE";
		DataObject var7 = (DataObject) this.getConfig(var1);
		RepositoryContext var8 = (RepositoryContext) this.configContextCache.get(var1);
		this.configPathInCell = ConfigManager.getConfigPathInCell();
		if (var4) {
			trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig(sessionId,validate)",
					"configPathInCell=" + this.configPathInCell);
		}

		if (var8 == null) {
			if (var4) {
				trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig(sessionId,validate)",
						"context is null, load the file in workspace and get the context");
			}

			WorkSpace var9 = WorkSpaceManagerFactory.getManager().getWorkSpace(var1);
			var8 = var9.findContext(this.configPathInCell);
			if (var4) {
				trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig(sessionId,validate)",
						"contextPath=" + var8.getPath());
			}

			if (!var8.isAvailable(this.configXMLFileRelativePath)) {
				throw new WIMException("WIM_CONFIG_XML_FILE_NOT_FOUND",
						WIMMessageHelper.generateMsgParms(this.configXMLFileRelativePath), CLASSNAME,
						"saveConfig(sessionId,validate)");
			}

			if (var4) {
				trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig(sessionId,validate)",
						"config file " + this.configXMLFileRelativePath + " is available");
			}

			var8.extract(this.configXMLFileRelativePath, false);
			this.configContextCache.put(var1, var8);
			this.configWorkspaceCache.put(var1, var9);
		}

		if (var8 != null && var7 != null) {
			try {
				this.configManager.encodePasswords(var7);
				SDOUtils.validateDataObject(var7);
				var2 = true;
			} catch (WIMException var12) {
				if (var2) {
					throw var12;
				}

				var6 = "CONFIG_NOT_COMPLETE";
				if (var4) {
					trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig(sessionId,validate)",
							"config file is not valid: " + var12.getMessage());
				}
			}

			String var13 = var8.getPath() + File.separator + this.configXMLFileRelativePath;
			if (var4) {
				trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig(sessionId,validate)",
						"saving the config file " + var13);
			}

			DataGraphHelper.saveDataGraph(var7.getDataGraph(), var13);
			var8.notifyChanged(1, this.configXMLFileRelativePath);
			if (var4) {
				List var10 = var8.getModifiedList(true);
				if (var10.size() > 0) {
					Iterator var11 = var10.iterator();

					while (var11.hasNext()) {
						trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig(sessionId,validate)",
								"Status changed for file " + var11.next().toString());
					}
				} else {
					trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig(sessionId,validate)",
							"No Resources are modified.");
				}
			}
		}

		this.validateAndClearCaches();
		if (var4) {
			trcLogger.exiting(CLASSNAME, "saveConfig(sessionId,validate)",
					"retKey=" + var6 + ", updated=" + (var7 != null));
		}

		return var6;
	}

	private void validateAndClearCaches() {
		trcLogger.entering(CLASSNAME, "validateAndClearCaches");
		trcLogger.logp(Level.FINEST, CLASSNAME, "validateAndClearCaches",
				"configWorkspaceCache = " + this.configWorkspaceCache);
		trcLogger.logp(Level.FINEST, CLASSNAME, "validateAndClearCaches",
				"Number of active sessions = " + this.configWorkspaceCache.size());
		Iterator var2 = (new HashSet(this.configWorkspaceCache.keySet())).iterator();

		while (var2.hasNext()) {
			String var3 = (String) var2.next();
			this.validateWorkspace("validateAndClearCaches", var3);
		}

		trcLogger.exiting(CLASSNAME, "validateAndClearCaches");
	}

	private boolean hasConfigAcccess() {
		boolean var2 = false;

		try {
			RoleBasedConfigurator var3 = RoleBasedConfiguratorFactory.getConfigurator();
			RoleBasedAuthorizer var4 = var3.getRoleBasedAuthorizer("admin-authz", "domain");
			var2 = var4.isCallerInRole("administrator") || var4.isCallerInRole("configurator")
					|| var4.isCallerInRole("operator") || var4.isCallerInRole("monitor");
		} catch (Exception var5) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "hasConfigAcccess",
						"Exception while getting Role for current Subject", var5);
			}
		}

		return var2;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = ConfigSessionManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
		sFileSep = File.separator;
	}
}