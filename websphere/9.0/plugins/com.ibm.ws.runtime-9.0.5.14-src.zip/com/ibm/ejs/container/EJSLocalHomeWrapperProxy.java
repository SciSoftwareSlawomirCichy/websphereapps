package com.ibm.ejs.container;

import javax.ejb.EJBLocalHome;
import javax.ejb.RemoveException;

public class EJSLocalHomeWrapperProxy extends EJSLocalWrapperProxy implements EJBLocalHome {
	public EJSLocalHomeWrapperProxy(WrapperProxyState state) {
		super(state);
	}

	public void remove(Object primaryKey) throws RemoveException {
		((EJBLocalHome) EJSContainer.resolveWrapperProxy(this)).remove(primaryKey);
	}
}