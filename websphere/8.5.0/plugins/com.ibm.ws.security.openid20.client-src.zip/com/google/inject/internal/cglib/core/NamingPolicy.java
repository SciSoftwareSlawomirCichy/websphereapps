package com.google.inject.internal.cglib.core;

public interface NamingPolicy {
	String getClassName(String var1, String var2, Object var3, Predicate var4);

	boolean equals(Object var1);
}