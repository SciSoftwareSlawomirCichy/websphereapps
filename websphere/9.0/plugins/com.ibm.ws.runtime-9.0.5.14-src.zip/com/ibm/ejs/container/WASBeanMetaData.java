package com.ibm.ejs.container;

public class WASBeanMetaData extends SharedBeanMetaData {
	public WASBeanMetaData(int slotSize) {
		super(slotSize);
	}

	public EJBMethodInfoImpl createEJBMethodInfoImpl(int slotSize) {
		return new WASEJBMethodInfoImpl(slotSize);
	}
}