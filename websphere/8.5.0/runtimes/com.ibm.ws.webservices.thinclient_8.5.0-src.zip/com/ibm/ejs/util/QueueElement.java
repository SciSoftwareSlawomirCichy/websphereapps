package com.ibm.ejs.util;

public class QueueElement {
	protected QueueElement previous;
	protected QueueElement next;
	protected Queue queue;

	public void removeFromQueue() {
		if (this.queue == null) {
			throw new RuntimeException("Queue element is not member of a queue");
		} else {
			this.queue.remove(this);
		}
	}
}