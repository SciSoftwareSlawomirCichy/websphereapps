package com.ibm.ejs.container;

public class CreateFailureException extends ContainerException {
	private static final long serialVersionUID = 8258962263818787828L;

	public CreateFailureException(Throwable ex) {
		super(ex);
	}
}