package com.ibm.ws.wim.adapter.ldap;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchResult;

public class CachedNamingEnumeration implements NamingEnumeration, Serializable {
	static final long serialVersionUID = -7189810899949423195L;
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private List iList = null;
	private transient Iterator m_Enum = null;

	public void close() throws NamingException {
	}

	CachedNamingEnumeration() {
	}

	CachedNamingEnumeration(List var1) {
		this.iList = var1;
	}

	public Object clone() {
		Vector var1 = null;
		if (this.iList != null) {
			var1 = new Vector(this.iList.size());

			for (int var2 = 0; var2 < this.iList.size(); ++var2) {
				Object var3 = this.iList.get(var2);
				if (var3 instanceof SearchResult) {
					SearchResult var4 = (SearchResult) var3;
					Attributes var5 = (Attributes) var4.getAttributes().clone();
					SearchResult var6 = new SearchResult(var4.getName(), (String) null, (Object) null, var5);
					var1.add(var6);
				} else {
					var1.add(var3);
				}
			}
		}

		return new CachedNamingEnumeration(var1);
	}

	public boolean hasMore() throws NamingException {
		if (this.iList == null) {
			this.iList = new Vector(0);
		}

		if (this.m_Enum == null) {
			this.m_Enum = this.iList.iterator();
		}

		return this.m_Enum.hasNext();
	}

	public Object next() throws NamingException {
		if (this.iList == null) {
			this.iList = new Vector(0);
		}

		if (this.m_Enum == null) {
			this.m_Enum = this.iList.iterator();
		}

		return this.m_Enum.next();
	}

	public boolean hasMoreElements() {
		try {
			return this.hasMore();
		} catch (NamingException var2) {
			return false;
		}
	}

	public Object nextElement() {
		try {
			return this.next();
		} catch (NamingException var2) {
			return null;
		}
	}

	public void add(Object var1) {
		if (this.iList == null) {
			this.iList = new Vector(0);
		}

		this.iList.add(var1);
	}

	public String toString() {
		return this.iList != null ? this.iList.toString() : "";
	}
}