package com.ibm.ejs.container;

import com.ibm.ejs.container.passivator.PassivatorSerializable;
import com.ibm.ejs.container.passivator.PassivatorSerializableHandle;
import com.ibm.ejs.csi.EJBModuleMetaDataImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.asynchbeans.Alarm;
import com.ibm.websphere.asynchbeans.AsynchScope;
import com.ibm.websphere.asynchbeans.WorkManager;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.asynchbeans.WSAlarmManager;
import com.ibm.ws.ejbcontainer.util.ObjectUtil;
import com.ibm.ws.ejbcontainer.util.ParsedScheduleExpression;
import com.ibm.ws.ejbcontainer.util.ScheduleExpressionParser;
import com.ibm.ws.runtime.component.WASEJBRuntime;
import com.ibm.ws.runtime.component.EJBContainerImpl.TimerConfigData;
import com.ibm.ws.util.UUID;
import commonj.timers.Timer;
import commonj.timers.TimerManager;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import javax.ejb.EJBException;
import javax.ejb.NoMoreTimeoutsException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.ScheduleExpression;
import javax.ejb.TimerHandle;

public final class TimerNpImpl implements TimerNp, PassivatorSerializable {
	private static final TraceComponent tc = Tr.register(TimerNpImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static WSAlarmManager svAlarmManager = null;
	static TimerManager svTimerManager = null;
	protected String ivTaskId;
	private static long ivTaskSeqNo = 0L;
	EJSContainer ivContainer;
	private BeanId ivBeanId;
	private BeanMetaData ivBMD;
	int ivMethodId;
	protected Serializable ivInfo;
	protected static int svNpTimerServiceTimerRetryCount = -1;
	protected static int svNpTimerServiceTimerRetryInterval = 300000;
	private long ivExpiration;
	private long ivInterval;
	private ParsedScheduleExpression ivParsedScheduleExpression;
	private boolean ivDestroyed;
	boolean ivFiring;
	static boolean svIsAlarmBased = true;
	private long ivLastExpiration;
	private Alarm ivAlarm;
	private Timer ivTimer;
	private TimerNpListener ivListener;
	static Hashtable<String, TimerNpImpl> timerHash = new Hashtable();

	private TimerNpImpl(EJSContainer container, BeanMetaData bmd, BeanId beanId, Serializable info) {
		this.ivTaskId = "_NP";
		this.ivDestroyed = false;
		this.ivFiring = false;
		this.ivAlarm = null;
		this.ivTimer = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			String infoClassName = info == null ? null : info.getClass().getName();
			Tr.entry(tc, "TimerNpImpl: " + beanId + ", " + infoClassName);
		}

		this.ivContainer = container;
		this.ivBMD = bmd;
		this.ivBeanId = beanId;
		this.ivInfo = ObjectUtil.copy(info);
		this.ivTaskId = incrementTaskSeqNo();

		try {
			this.getTimerOrAlarmManager(this.ivBeanId.getIdString());
		} catch (Throwable var7) {
			TimerServiceException tse = new TimerServiceException(
					"EJB TimerService failed to obtain a TimerManager or an AlarmManager", var7);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "TimerNpImpl: " + tse);
			}

			throw tse;
		}
	}

	public TimerNpImpl(BeanId beanId, Date expiration, long interval, Serializable info) {
		this(((EJSHome) beanId.home).container, ((EJSHome) beanId.home).beanMetaData, beanId, info);
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		this.ivExpiration = expiration.getTime();
		this.ivInterval = interval;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, this.toString());
		}

	}

	TimerNpImpl(BeanId beanId, String taskId) {
		this.ivTaskId = "_NP";
		this.ivDestroyed = false;
		this.ivFiring = false;
		this.ivAlarm = null;
		this.ivTimer = null;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "TimerNpImpl : " + beanId + ", " + taskId);
		}

		this.ivContainer = ((EJSHome) beanId.home).container;
		this.ivTaskId = taskId;
		this.ivBMD = ((EJSHome) beanId.home).beanMetaData;
		this.ivBeanId = beanId;
		this.ivDestroyed = true;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, this.toString());
		}

	}

	public TimerNpImpl(EJSContainer container, BeanMetaData bmd, BeanId beanId, int methodId,
			ParsedScheduleExpression parsedExpr, Serializable info) {
		this(container, bmd, beanId, info);
		this.ivMethodId = methodId;
		this.ivExpiration = Math.max(0L, parsedExpr.getFirstTimeout());
		this.ivParsedScheduleExpression = parsedExpr;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, this.toString());
		}

	}

	public TimerNpImpl(BeanId beanId, ParsedScheduleExpression parsedExpr, Serializable info) {
		this(((EJSHome) beanId.home).container, ((EJSHome) beanId.home).beanMetaData, beanId, 0, parsedExpr, info);
	}

	public String getTaskId() {
		return this.ivTaskId;
	}

	public void destroy() {
		this.ivDestroyed = true;
	}

	private static synchronized String incrementTaskSeqNo() {
		++ivTaskSeqNo;
		String taskId = ivTaskSeqNo + "_NP_" + new UUID();
		return taskId;
	}

	public BeanId getIvBeanId() {
		return this.ivBeanId;
	}

	protected boolean isIvDestroyed() {
		return this.ivDestroyed;
	}

	public void start() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "start: " + this);
		}

		if ((this.ivInterval >= 0L || !this.ivDestroyed) && this.ivExpiration != 0L) {
			timerHash.put(this.ivTaskId, this);
			this.ivDestroyed = false;
			EJBModuleMetaDataImpl ejbModuleMetaData = this.ivBMD._moduleMetaData;
			ejbModuleMetaData.getEJBApplicationMetaData().queueOrStartNonPersistentTimerAlarm(this, ejbModuleMetaData);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "start");
			}
		} else if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "start: returning without creating another Timer or Alarm.");
		}

	}

	public void startAlarm() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "startAlarm: " + this);
		}

		this.ivListener = new TimerNpListener(this);
		Date expDate = new Date(this.ivExpiration);
		if (svIsAlarmBased) {
			this.ivAlarm = svAlarmManager.create(this.ivListener, this, expDate);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "startAlarm: created Alarm for " + expDate);
			}
		} else {
			this.ivTimer = svTimerManager.schedule(this.ivListener, expDate);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "startAlarm: created Timer for " + expDate);
			}
		}

	}

	long calculateNextExpiration() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "calculateNextExpiration: " + this);
		}

		this.ivLastExpiration = this.ivExpiration;
		if (this.ivParsedScheduleExpression != null) {
			this.ivExpiration = Math.max(0L, this.ivParsedScheduleExpression.getNextTimeout(this.ivExpiration));
		} else if (this.ivInterval > 0L) {
			this.ivExpiration += this.ivInterval;
		} else {
			this.ivExpiration = 0L;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "calculateNextExpiration: " + this.ivExpiration);
		}

		return this.ivExpiration;
	}

	public void cancel() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "cancel: " + this);
		}

		if (this.ivDestroyed) {
			String msg = "Timer with task ID " + this.ivTaskId + " had previously been canceled";
			throw new NoSuchObjectLocalException(msg);
		} else {
			this.checkTimerAccess();
			this.cancelPart2();
			ContainerTx tx = null;

			try {
				tx = this.ivContainer.getCurrentTx(false);
			} catch (CSITransactionRolledbackException var4) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.debug(tc, "cancel: caught CSITransactionRolledbackException");
				}
			}

			if (tx != null) {
				if (tx.timersCanceled == null) {
					tx.timersCanceled = new HashMap();
				}

				tx.timersCanceled.put(this.ivTaskId, this);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "cancel: successful");
			}

		}
	}

	private void cancelPart2() {
		timerHash.remove(this.ivTaskId);
		if (svIsAlarmBased) {
			if (this.ivAlarm != null) {
				this.ivAlarm.cancel();
			}
		} else if (this.ivTimer != null) {
			this.ivTimer.cancel();
		}

	}

	protected void remove() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "remove: " + this);
		}

		this.cancelPart2();
		this.ivDestroyed = true;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "remove: successful");
		}

	}

	public long getTimeRemaining() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		Date nextTime = this.getNextTimeout();
		long currentTime = System.currentTimeMillis();
		long remaining = nextTime.getTime() - currentTime;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getTimeRemaining: " + remaining);
		}

		return remaining;
	}

	public Date getNextTimeout()
			throws IllegalStateException, NoSuchObjectLocalException, EJBException, NoMoreTimeoutsException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getNextTimeout: " + this);
		}

		if (this.ivDestroyed) {
			throw new NoSuchObjectLocalException(this.toString());
		} else {
			this.checkTimerAccess();
			ContainerTx tx = null;

			try {
				tx = this.ivContainer.getCurrentTx(false);
			} catch (CSITransactionRolledbackException var4) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.debug(tc, "getNextTimeout: caught CSITransactionRolledbackException");
				}
			}

			if (tx != null && tx.timersCanceled != null && tx.timersCanceled.containsValue(this)) {
				throw new NoSuchObjectLocalException(this.toString());
			} else if (this.ivExpiration == 0L) {
				if (this.ivFiring) {
					if (this.ivParsedScheduleExpression != null) {
						throw new NoMoreTimeoutsException(this.toString());
					} else {
						return new Date(this.ivLastExpiration);
					}
				} else {
					throw new NoSuchObjectLocalException(this.toString());
				}
			} else {
				Date nextTime = new Date(this.ivExpiration);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "getNextTimeout: " + nextTime);
				}

				return nextTime;
			}
		}
	}

	public Serializable getInfo() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getInfo: " + this);
		}

		this.checkTimerAccess();
		ContainerTx tx = null;
		boolean onCanceledMap = false;

		try {
			tx = this.ivContainer.getCurrentTx(false);
			if (tx != null && tx.timersCanceled != null) {
				onCanceledMap = tx.timersCanceled.containsValue(this);
			}
		} catch (CSITransactionRolledbackException var5) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.debug(tc, "getInfo: caught CSITransactionRolledbackException");
			}
		}

		if (!this.ivDestroyed && !onCanceledMap) {
			Serializable info = ObjectUtil.copy(this.ivInfo);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getInfo: " + Util.identity(info));
			}

			return info;
		} else {
			String msg = "Timer with task ID " + this.ivTaskId + " had previously been canceled or expired.";
			throw new NoSuchObjectLocalException(msg);
		}
	}

	public TimerHandle getHandle() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getHandle: " + this);
		}

		IllegalStateException ise = new IllegalStateException("getHandle method not allowed on non-persistent timers.");
		throw ise;
	}

	public static Collection<javax.ejb.Timer> findTimersByBeanId(BeanId beanId, ContainerTx tx) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "findTimersByBeanId: " + beanId);
		}

		ArrayList<javax.ejb.Timer> timers = new ArrayList();
		long numFound = 0L;
		Hashtable var5 = timerHash;
		synchronized (timerHash) {
			Iterator i$ = timerHash.values().iterator();

			while (i$.hasNext()) {
				TimerNpImpl npTimer = (TimerNpImpl) i$.next();
				if (npTimer.ivBeanId.equals(beanId) && !npTimer.isIvDestroyed()) {
					timers.add(npTimer);
					++numFound;
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "findTimersByBeanId: " + timers.size() + "(of " + numFound + " found)");
		}

		return timers;
	}

	public static void removeTimersByJ2EEName(J2EEName j2eeName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "removeTimersByJ2EEName: " + j2eeName);
		}

		Hashtable var2 = timerHash;
		synchronized (timerHash) {
			Iterator i = timerHash.values().iterator();

			while (true) {
				if (!i.hasNext()) {
					break;
				}

				TimerNpImpl timer = (TimerNpImpl) i.next();
				J2EEName beanJ2EEName = timer.ivBeanId.j2eeName;
				if (j2eeName.getApplication().equals(beanJ2EEName.getApplication())
						&& (j2eeName.getModule() == null || j2eeName.getModule().equals(beanJ2EEName.getModule()))) {
					i.remove();
					timer.remove();
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "removeTimersByJ2EEName");
		}

	}

	protected void checkTimerAccess() throws IllegalStateException {
		BeanO beanO = EJSContainer.getCallbackBeanO();
		if (beanO != null) {
			beanO.checkTimerServiceAccess();
		} else {
			IllegalStateException ise = new IllegalStateException("Timer: Timer methods not allowed - no active EJB");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerAccess: " + ise);
			}

			throw ise;
		}
	}

	public PassivatorSerializableHandle getSerializableObject() {
		TimerNpHandleImpl timerHandle = new TimerNpHandleImpl(this.ivBeanId, this.ivTaskId);
		return timerHandle;
	}

	public boolean equals(Object obj) {
		if (obj instanceof TimerNpImpl) {
			TimerNpImpl timer = (TimerNpImpl) obj;
			return this.ivTaskId.equals(timer.ivTaskId);
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.ivTaskId.hashCode();
	}

	public String toString() {
		return "TimerNpImpl(" + this.ivTaskId + ", " + this.ivBeanId + ", " + this.ivExpiration + ", " + this.ivInterval
				+ ", " + this.ivDestroyed + ", " + Util.identity(this.ivInfo) + ")";
	}

	public boolean isCalendarTimer() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCalendarTimer: " + this);
		}

		this.checkTimerAccess();
		ContainerTx tx = null;

		try {
			tx = this.ivContainer.getCurrentTx(false);
		} catch (CSITransactionRolledbackException var4) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.debug(tc, "getNextTimeout: caught CSITransactionRolledbackException");
			}
		}

		if (tx != null && tx.timersCanceled != null && tx.timersCanceled.containsValue(this)) {
			throw new NoSuchObjectLocalException(this.toString());
		} else if (this.ivDestroyed) {
			String msg = "Timer with task ID " + this.ivTaskId + " had previously been canceled";
			throw new NoSuchObjectLocalException(msg);
		} else {
			boolean result = this.ivParsedScheduleExpression != null;
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "isCalendarTimer: " + result);
			}

			return result;
		}
	}

	public ScheduleExpression getSchedule() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getSchedule: " + this);
		}

		if (this.ivDestroyed) {
			throw new NoSuchObjectLocalException(this.toString());
		} else if (!this.isCalendarTimer()) {
			throw new IllegalStateException("Timer is not a calendar-based timer");
		} else {
			ScheduleExpression result = ObjectUtil.copy(this.ivParsedScheduleExpression.getSchedule());
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getSchedule: " + ScheduleExpressionParser.toString(result));
			}

			return result;
		}
	}

	public boolean isPersistent() {
		if (this.ivDestroyed) {
			throw new NoSuchObjectLocalException(this.toString());
		} else {
			return false;
		}
	}

	private void getTimerOrAlarmManager(String beanIdstring) {
		if (svAlarmManager == null && svTimerManager == null) {
			WASEJBRuntime ejbRuntime = (WASEJBRuntime) this.ivContainer.getEJBRuntime();
			TimerConfigData tmConfig = ejbRuntime.getTimerConfig();
			svTimerManager = tmConfig.getIvTimerManager();
			svIsAlarmBased = svTimerManager == null;
			svNpTimerServiceTimerRetryCount = tmConfig.getIvRetryCount();
			svNpTimerServiceTimerRetryInterval = tmConfig.getIvRetryInterval();
			if (svIsAlarmBased) {
				WorkManager wm = ejbRuntime.getTimerServiceWorkManager();
				AsynchScope as = wm.findOrCreateAsynchScope(beanIdstring);
				svAlarmManager = (WSAlarmManager) as.getAlarmManager();
			}
		}

	}
}