package com.ibm.ejs.container;

import com.ibm.ejs.container.interceptors.InterceptorMetaData;
import com.ibm.ejs.container.interceptors.InterceptorProxy;
import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.CallbackKind;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import com.ibm.wsspi.injectionengine.InjectionEngine;
import com.ibm.wsspi.injectionengine.InjectionTarget;
import com.ibm.wsspi.injectionengine.InjectionTargetContext;
import java.rmi.RemoteException;
import java.security.Identity;
import java.security.Principal;
import java.util.Map;
import java.util.Properties;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.EJBLocalHome;
import javax.ejb.EnterpriseBean;
import javax.ejb.RemoveException;
import javax.ejb.TimerService;
import javax.transaction.UserTransaction;

public final class ManagedBeanO extends ManagedBeanOBase {
	private static final String CLASS_NAME = ManagedBeanO.class.getName();
	private static final TraceComponent tc;
	public static final int DESTROYED = 0;
	public static final int PRE_CREATE = 1;
	public static final int CREATING = 2;
	public static final int ACTIVE = 3;
	public CallbackKind ivCallbackKind;

	public ManagedBeanO(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		super(c, mo, b, h);
		BeanMetaData bmd = this.home.beanMetaData;
		this.ivCallbackKind = bmd.ivCallbackKind;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "ManagedBeanO.<init> : " + bmd.j2eeName);
		}

	}

	void initialize() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "initialize");
		}

		this.state = 1;

		try {
			BeanMetaData bmd = this.home.beanMetaData;
			InterceptorMetaData imd = bmd.ivInterceptorMetaData;
			if (imd != null) {
				this.createInterceptors(imd);
			}

			if (bmd != null && bmd.ivBeanInjectionTargets != null) {
				try {
					InjectionEngine injectionEngine = this.getInjectionEngine();
					InjectionTarget[] targets = bmd.ivBeanInjectionTargets;
					if (targets != null) {
						InjectionTarget[] arr$ = targets;
						int len$ = targets.length;

						for (int i$ = 0; i$ < len$; ++i$) {
							InjectionTarget injectionTarget = arr$[i$];
							injectionEngine.inject(this.ivEjbInstance, injectionTarget, (InjectionTargetContext) null);
						}
					}
				} catch (Throwable var13) {
					FFDCFilter.processException(var13, CLASS_NAME + ".initialize", "167", this);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Injection failure", var13);
					}

					throw ExceptionUtil.EJBException("Injection failure", var13);
				}
			}

			this.setState(2);
			if (this.ivCallbackKind == CallbackKind.InvocationContext && imd != null) {
				InterceptorProxy[] proxies = imd.ivPostConstructInterceptors;
				if (proxies != null) {
					this.callLifecycleInterceptors(proxies, 0);
				}
			}

			this.setState(3);
		} finally {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "initialize : " + this);
			}

		}

	}

	public void destroy() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy : " + this);
		}

		if (this.state == 0) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "destroy : already destroyed");
			}

		} else {
			this.setState(0);
			InterceptorMetaData imd = this.home.beanMetaData.ivInterceptorMetaData;
			InterceptorProxy[] proxies = imd == null ? null : imd.ivPreDestroyInterceptors;
			if (proxies == null) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "destroy : no PreDestroy");
				}

			} else {
				UnspecifiedContextHelper contextHelper = new UnspecifiedContextHelper(this);

				try {
					BeanMetaData bmd = this.home.beanMetaData;
					contextHelper.begin(this.ivCallbackKind != CallbackKind.None);
					InvocationContextImpl inv = new InvocationContextImpl();
					inv.initialize(this.ivEjbInstance, this.ivInterceptors);
					inv.doLifeCycle(proxies, bmd._moduleMetaData);
				} catch (Exception var15) {
					FFDCFilter.processException(var15, CLASS_NAME + ".destroy", "262", this);
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "destroy caught exception:", new Object[]{this, var15});
					}
				} finally {
					try {
						contextHelper.complete(true);
					} catch (Throwable var14) {
						FFDCFilter.processException(var14, CLASS_NAME + ".destroy", "279", this);
						if (isTraceOn && tc.isEventEnabled()) {
							Tr.event(tc, "destroy caught exception: ", new Object[]{this, var14});
						}
					}

					this.releaseManagedObjectState();
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "destroy : completed PreDestroy");
					}

				}

			}
		}
	}

	protected void callLifecycleInterceptors(InterceptorProxy[] proxies, int methodId) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (TraceComponent.isAnyTracingEnabled()) {
			if (isTraceOn) {
				TEBeanLifeCycleInfo.traceEJBCallEntry(LifecycleInterceptorWrapper.TRACE_NAMES[methodId]);
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "callLifecycleInterceptors");
			}
		}

		try {
			InvocationContextImpl inv = new InvocationContextImpl();
			inv.initialize(this.ivEjbInstance, this.ivInterceptors);
			BeanMetaData bmd = this.home.beanMetaData;
			inv.doLifeCycle(proxies, bmd._moduleMetaData);
		} catch (Throwable var9) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "ManagedBean PostConstruct failure", var9);
			}

			throw ExceptionUtil.EJBException("managed bean lifecycle interceptor failure", var9);
		} finally {
			if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceEJBCallExit(LifecycleInterceptorWrapper.TRACE_NAMES[methodId]);
			}

		}

	}

	public Object getBeanInstance() {
		return this.ivEjbInstance;
	}

	public Object[] getInterceptors() {
		return this.ivInterceptors;
	}

	public boolean isDestroyed() {
		return this.state == 0;
	}

	public synchronized UserTransaction getUserTransaction() {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public Map<String, Object> getContextData() {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public Identity getCallerIdentity() {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public Principal getCallerPrincipal() {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public EJBHome getEJBHome() {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public EJBLocalHome getEJBLocalHome() {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public Properties getEnvironment() {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public boolean getRollbackOnly() {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public TimerService getTimerService() throws IllegalStateException {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public boolean isCallerInRole(Identity id) {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public boolean isCallerInRole(String roleName) {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public void setRollbackOnly() {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public Object lookup(String name) {
		throw new IllegalStateException("Method not supported for ManagedBean.");
	}

	public void activate(BeanId id, ContainerTx tx) throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public void beforeCompletion() throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public void checkTimerServiceAccess() throws IllegalStateException {
		throw new UnsupportedOperationException();
	}

	public void commit(ContainerTx tx) throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public void discard() {
	}

	public boolean enlist(ContainerTx tx) throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public void ensurePersistentState(ContainerTx tx) throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public EnterpriseBean getEnterpriseBean() throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public void invalidate() {
		throw new UnsupportedOperationException();
	}

	public boolean isDiscarded() {
		throw new UnsupportedOperationException();
	}

	public boolean isRemoved() {
		throw new UnsupportedOperationException();
	}

	public void passivate() throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public void postCreate(boolean supportEjbPostCreateChanges) throws CreateException, RemoteException {
		throw new UnsupportedOperationException();
	}

	public void postInvoke(int id, EJSDeployedSupport s) throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public Object preInvoke(EJSDeployedSupport s, ContainerTx tx) throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public void remove() throws RemoteException, RemoveException {
		throw new UnsupportedOperationException();
	}

	public void rollback(ContainerTx tx) throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public void store() throws RemoteException {
		throw new UnsupportedOperationException();
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}