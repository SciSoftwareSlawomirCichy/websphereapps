package com.ibm.ejs.container;

import com.ibm.ejs.container.passivator.PassivatorSerializableHandle;
import com.ibm.ejs.container.util.ByteArray;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejb.portable.Constants;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public final class TimerNpHandleImpl implements Serializable, PassivatorSerializableHandle {
	private static final TraceComponent tc = Tr.register(TimerNpHandleImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final long serialVersionUID = 1137182555465371492L;
	private static final byte[] EYECATCHER;
	private static final short PLATFORM = 1;
	private static final short VERSION_ID = 1;
	private transient String ivTaskId;
	private transient BeanId ivBeanId;

	TimerNpHandleImpl(BeanId beanId, String taskId) {
		this.ivBeanId = beanId;
		this.ivTaskId = taskId;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, this.toString());
		}

	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "writeObject: " + this);
		}

		out.defaultWriteObject();
		out.write(EYECATCHER);
		out.writeShort(1);
		out.writeShort(1);
		out.writeUTF(this.ivTaskId);
		out.writeObject(this.ivBeanId.getByteArrayBytes());
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "writeObject");
		}

	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "readObject");
		}

		in.defaultReadObject();
		byte[] eyeCatcher = new byte[EYECATCHER.length];
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < EYECATCHER.length; i += bytesRead) {
			bytesRead = in.read(eyeCatcher, i, EYECATCHER.length - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < EYECATCHER.length; ++i) {
			if (EYECATCHER[i] != eyeCatcher[i]) {
				String eyeCatcherString = new String(eyeCatcher);
				throw new IOException("Invalid eye catcher '" + eyeCatcherString + "' in TimerHandle input stream");
			}
		}

		short incoming_platform = in.readShort();
		short incoming_vid = in.readShort();
		if (incoming_vid != 1) {
			throw new InvalidObjectException(
					"EJB TimerHandle data stream is not of the correct version, this client should be updated.");
		} else {
			this.ivTaskId = in.readUTF();
			byte[] bytes = (byte[]) ((byte[]) in.readObject());
			ByteArray byteArray = new ByteArray(bytes);
			EJSContainer container = EJSContainer.getDefaultContainer();
			this.ivBeanId = BeanId.getBeanId(byteArray, container);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "readObject: " + this);
			}

		}
	}

	public Object getSerializedObject() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getSerializedObject : " + this.ivBeanId + ", " + this.ivTaskId);
		}

		Object timer = TimerNpImpl.getDeserializedTimer(this.ivBeanId, this.ivTaskId);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getSerializedObject : " + timer);
		}

		return timer;
	}

	static {
		EYECATCHER = Constants.TIMER_HANDLE_EYE_CATCHER;
	}
}