package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import javax.ejb.EJBException;

public class TimerServiceException extends EJBException {
	private static final long serialVersionUID = 517416094460234231L;

	public TimerServiceException(String message, Throwable cause) {
		super(message, ExceptionUtil.Exception(cause));
	}

	public TimerServiceException(String message) {
		super(message);
	}
}