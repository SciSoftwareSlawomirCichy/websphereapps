package com.ibm.ejs.cm.portability;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.sql.SQLException;
import java.util.Hashtable;

public class ErrorMap {
	private static final TraceComponent tc = Tr.register(ErrorMap.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");
	Hashtable customErrorMap;
	PortabilityLayer portabilityLayer;

	public static ErrorMap createErrorMap(PortabilityLayer pbl) {
		return new ErrorMap(pbl);
	}

	public static ErrorMap createErrorMap(PortabilityLayer pbl, Hashtable customMap) {
		return new ErrorMap(pbl, customMap);
	}

	private ErrorMap() {
		this.customErrorMap = null;
	}

	private ErrorMap(PortabilityLayer pbl) {
		this(pbl, (Hashtable) null);
	}

	private ErrorMap(PortabilityLayer pbl, Hashtable customMap) {
		this.customErrorMap = null;
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", new Object[]{pbl, customMap});
		}

		if (pbl == null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "<init> - Invalid PortabilityLayer");
			}

			throw new IllegalArgumentException();
		} else {
			this.portabilityLayer = pbl;
			if (customMap != null) {
				this.customErrorMap = (Hashtable) customMap.clone();
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "<init>");
			}

		}
	}

	public void addMap(String key, Class exceptionClass) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "addMap: " + key + ", " + exceptionClass.getName());
		}

		if (this.customErrorMap == null) {
			this.customErrorMap = new Hashtable();
		}

		this.customErrorMap.put(key, exceptionClass);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addMap");
		}

	}

	public void addMap(Hashtable map) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "addMap: ", map);
		}

		if (this.customErrorMap == null) {
			this.customErrorMap = (Hashtable) map.clone();
		} else {
			this.customErrorMap.putAll(map);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addMap");
		}

	}

	public void removeMap(String key) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "removeMap: " + key);
		}

		if (this.customErrorMap == null) {
			this.customErrorMap = new Hashtable();
		}

		this.customErrorMap.put(key, Void.class);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "removeMap");
		}

	}

	public final SQLException translateException(SQLException e) throws SQLException {
		return this.portabilityLayer.translateException(e, this.customErrorMap);
	}
}