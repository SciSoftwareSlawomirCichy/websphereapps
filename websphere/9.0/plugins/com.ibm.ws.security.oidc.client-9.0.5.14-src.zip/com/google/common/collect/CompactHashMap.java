package com.google.common.collect;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.collect.CompactHashMap.1;
import com.google.common.collect.CompactHashMap.2;
import com.google.common.collect.CompactHashMap.3;
import com.google.common.collect.CompactHashMap.EntrySetView;
import com.google.common.collect.CompactHashMap.KeySetView;
import com.google.common.collect.CompactHashMap.ValuesView;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtIncompatible
class CompactHashMap<K, V> extends AbstractMap<K, V> implements Serializable {
	private static final int MAXIMUM_CAPACITY = 1073741824;
	static final float DEFAULT_LOAD_FACTOR = 1.0F;
	private static final long NEXT_MASK = 4294967295L;
	private static final long HASH_MASK = -4294967296L;
	static final int DEFAULT_SIZE = 3;
	static final int UNSET = -1;
	@MonotonicNonNullDecl
	private transient int[] table;
	@MonotonicNonNullDecl
	@VisibleForTesting
	transient long[] entries;
	@MonotonicNonNullDecl
	@VisibleForTesting
	transient Object[] keys;
	@MonotonicNonNullDecl
	@VisibleForTesting
	transient Object[] values;
	transient float loadFactor;
	transient int modCount;
	private transient int threshold;
	private transient int size;
	@MonotonicNonNullDecl
	private transient Set<K> keySetView;
	@MonotonicNonNullDecl
	private transient Set<Entry<K, V>> entrySetView;
	@MonotonicNonNullDecl
	private transient Collection<V> valuesView;

	public static <K, V> CompactHashMap<K, V> create() {
		return new CompactHashMap();
	}

	public static <K, V> CompactHashMap<K, V> createWithExpectedSize(int expectedSize) {
		return new CompactHashMap(expectedSize);
	}

	CompactHashMap() {
		this.init(3, 1.0F);
	}

	CompactHashMap(int capacity) {
		this(capacity, 1.0F);
	}

	CompactHashMap(int expectedSize, float loadFactor) {
		this.init(expectedSize, loadFactor);
	}

	void init(int expectedSize, float loadFactor) {
		Preconditions.checkArgument(expectedSize >= 0, "Initial capacity must be non-negative");
		Preconditions.checkArgument(loadFactor > 0.0F, "Illegal load factor");
		int buckets = Hashing.closedTableSize(expectedSize, (double) loadFactor);
		this.table = newTable(buckets);
		this.loadFactor = loadFactor;
		this.keys = new Object[expectedSize];
		this.values = new Object[expectedSize];
		this.entries = newEntries(expectedSize);
		this.threshold = Math.max(1, (int) ((float) buckets * loadFactor));
	}

	private static int[] newTable(int size) {
		int[] array = new int[size];
		Arrays.fill(array, -1);
		return array;
	}

	private static long[] newEntries(int size) {
		long[] array = new long[size];
		Arrays.fill(array, -1L);
		return array;
	}

	private int hashTableMask() {
		return this.table.length - 1;
	}

	private static int getHash(long entry) {
		return (int) (entry >>> 32);
	}

	private static int getNext(long entry) {
		return (int) entry;
	}

	private static long swapNext(long entry, int newNext) {
		return -4294967296L & entry | 4294967295L & (long) newNext;
	}

	void accessEntry(int index) {
	}

	@NullableDecl
	@CanIgnoreReturnValue
	public V put(@NullableDecl K key, @NullableDecl V value) {
		long[] entries = this.entries;
		Object[] keys = this.keys;
		Object[] values = this.values;
		int hash = Hashing.smearedHash(key);
		int tableIndex = hash & this.hashTableMask();
		int newEntryIndex = this.size;
		int next = this.table[tableIndex];
		int last;
		if (next == -1) {
			this.table[tableIndex] = newEntryIndex;
		} else {
			long entry;
			do {
				last = next;
				entry = entries[next];
				if (getHash(entry) == hash && Objects.equal(key, keys[next])) {
					V oldValue = values[next];
					values[next] = value;
					this.accessEntry(next);
					return oldValue;
				}

				next = getNext(entry);
			} while (next != -1);

			entries[last] = swapNext(entry, newEntryIndex);
		}

		if (newEntryIndex == Integer.MAX_VALUE) {
			throw new IllegalStateException("Cannot contain more than Integer.MAX_VALUE elements!");
		} else {
			last = newEntryIndex + 1;
			this.resizeMeMaybe(last);
			this.insertEntry(newEntryIndex, key, value, hash);
			this.size = last;
			if (newEntryIndex >= this.threshold) {
				this.resizeTable(2 * this.table.length);
			}

			++this.modCount;
			return null;
		}
	}

	void insertEntry(int entryIndex, @NullableDecl K key, @NullableDecl V value, int hash) {
		this.entries[entryIndex] = (long) hash << 32 | 4294967295L;
		this.keys[entryIndex] = key;
		this.values[entryIndex] = value;
	}

	private void resizeMeMaybe(int newSize) {
		int entriesSize = this.entries.length;
		if (newSize > entriesSize) {
			int newCapacity = entriesSize + Math.max(1, entriesSize >>> 1);
			if (newCapacity < 0) {
				newCapacity = Integer.MAX_VALUE;
			}

			if (newCapacity != entriesSize) {
				this.resizeEntries(newCapacity);
			}
		}

	}

	void resizeEntries(int newCapacity) {
		this.keys = Arrays.copyOf(this.keys, newCapacity);
		this.values = Arrays.copyOf(this.values, newCapacity);
		long[] entries = this.entries;
		int oldCapacity = entries.length;
		entries = Arrays.copyOf(entries, newCapacity);
		if (newCapacity > oldCapacity) {
			Arrays.fill(entries, oldCapacity, newCapacity, -1L);
		}

		this.entries = entries;
	}

	private void resizeTable(int newCapacity) {
		int[] oldTable = this.table;
		int oldCapacity = oldTable.length;
		if (oldCapacity >= 1073741824) {
			this.threshold = Integer.MAX_VALUE;
		} else {
			int newThreshold = 1 + (int) ((float) newCapacity * this.loadFactor);
			int[] newTable = newTable(newCapacity);
			long[] entries = this.entries;
			int mask = newTable.length - 1;

			for (int i = 0; i < this.size; ++i) {
				long oldEntry = entries[i];
				int hash = getHash(oldEntry);
				int tableIndex = hash & mask;
				int next = newTable[tableIndex];
				newTable[tableIndex] = i;
				entries[i] = (long) hash << 32 | 4294967295L & (long) next;
			}

			this.threshold = newThreshold;
			this.table = newTable;
		}
	}

	private int indexOf(@NullableDecl Object key) {
		int hash = Hashing.smearedHash(key);

		long entry;
		for (int next = this.table[hash & this.hashTableMask()]; next != -1; next = getNext(entry)) {
			entry = this.entries[next];
			if (getHash(entry) == hash && Objects.equal(key, this.keys[next])) {
				return next;
			}
		}

		return -1;
	}

	public boolean containsKey(@NullableDecl Object key) {
		return this.indexOf(key) != -1;
	}

	public V get(@NullableDecl Object key) {
		int index = this.indexOf(key);
		this.accessEntry(index);
		return index == -1 ? null : this.values[index];
	}

	@NullableDecl
	@CanIgnoreReturnValue
	public V remove(@NullableDecl Object key) {
		return this.remove(key, Hashing.smearedHash(key));
	}

	@NullableDecl
	private V remove(@NullableDecl Object key, int hash) {
		int tableIndex = hash & this.hashTableMask();
		int next = this.table[tableIndex];
		if (next == -1) {
			return null;
		} else {
			int last = -1;

			do {
				if (getHash(this.entries[next]) == hash && Objects.equal(key, this.keys[next])) {
					V oldValue = this.values[next];
					if (last == -1) {
						this.table[tableIndex] = getNext(this.entries[next]);
					} else {
						this.entries[last] = swapNext(this.entries[last], getNext(this.entries[next]));
					}

					this.moveLastEntry(next);
					--this.size;
					++this.modCount;
					return oldValue;
				}

				last = next;
				next = getNext(this.entries[next]);
			} while (next != -1);

			return null;
		}
	}

	@CanIgnoreReturnValue
	private V removeEntry(int entryIndex) {
		return this.remove(this.keys[entryIndex], getHash(this.entries[entryIndex]));
	}

	void moveLastEntry(int dstIndex) {
		int srcIndex = this.size() - 1;
		if (dstIndex < srcIndex) {
			this.keys[dstIndex] = this.keys[srcIndex];
			this.values[dstIndex] = this.values[srcIndex];
			this.keys[srcIndex] = null;
			this.values[srcIndex] = null;
			long lastEntry = this.entries[srcIndex];
			this.entries[dstIndex] = lastEntry;
			this.entries[srcIndex] = -1L;
			int tableIndex = getHash(lastEntry) & this.hashTableMask();
			int lastNext = this.table[tableIndex];
			if (lastNext == srcIndex) {
				this.table[tableIndex] = dstIndex;
			} else {
				int previous;
				long entry;
				do {
					previous = lastNext;
					lastNext = getNext(entry = this.entries[lastNext]);
				} while (lastNext != srcIndex);

				this.entries[previous] = swapNext(entry, dstIndex);
			}
		} else {
			this.keys[dstIndex] = null;
			this.values[dstIndex] = null;
			this.entries[dstIndex] = -1L;
		}

	}

	int firstEntryIndex() {
		return this.isEmpty() ? -1 : 0;
	}

	int getSuccessor(int entryIndex) {
		return entryIndex + 1 < this.size ? entryIndex + 1 : -1;
	}

	int adjustAfterRemove(int indexBeforeRemove, int indexRemoved) {
		return indexBeforeRemove - 1;
	}

	public Set<K> keySet() {
		return this.keySetView == null ? (this.keySetView = this.createKeySet()) : this.keySetView;
	}

	Set<K> createKeySet() {
		return new KeySetView(this);
	}

	Iterator<K> keySetIterator() {
      return new 1(this);
   }

	public Set<Entry<K, V>> entrySet() {
		return this.entrySetView == null ? (this.entrySetView = this.createEntrySet()) : this.entrySetView;
	}

	Set<Entry<K, V>> createEntrySet() {
		return new EntrySetView(this);
	}

	Iterator<Entry<K, V>> entrySetIterator() {
      return new 2(this);
   }

	public int size() {
		return this.size;
	}

	public boolean isEmpty() {
		return this.size == 0;
	}

	public boolean containsValue(@NullableDecl Object value) {
		for (int i = 0; i < this.size; ++i) {
			if (Objects.equal(value, this.values[i])) {
				return true;
			}
		}

		return false;
	}

	public Collection<V> values() {
		return this.valuesView == null ? (this.valuesView = this.createValues()) : this.valuesView;
	}

	Collection<V> createValues() {
		return new ValuesView(this);
	}

	Iterator<V> valuesIterator() {
      return new 3(this);
   }

	public void trimToSize() {
		int size = this.size;
		if (size < this.entries.length) {
			this.resizeEntries(size);
		}

		int minimumTableSize = Math.max(1, Integer.highestOneBit((int) ((float) size / this.loadFactor)));
		if (minimumTableSize < 1073741824) {
			double load = (double) size / (double) minimumTableSize;
			if (load > (double) this.loadFactor) {
				minimumTableSize <<= 1;
			}
		}

		if (minimumTableSize < this.table.length) {
			this.resizeTable(minimumTableSize);
		}

	}

	public void clear() {
		++this.modCount;
		Arrays.fill(this.keys, 0, this.size, (Object) null);
		Arrays.fill(this.values, 0, this.size, (Object) null);
		Arrays.fill(this.table, -1);
		Arrays.fill(this.entries, -1L);
		this.size = 0;
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		stream.writeInt(this.size);

		for (int i = 0; i < this.size; ++i) {
			stream.writeObject(this.keys[i]);
			stream.writeObject(this.values[i]);
		}

	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		this.init(3, 1.0F);
		int elementCount = stream.readInt();
		int i = elementCount;

		while (true) {
			--i;
			if (i < 0) {
				return;
			}

			K key = stream.readObject();
			V value = stream.readObject();
			this.put(key, value);
		}
	}
}