package com.ibm.ws.wim.adapter.db;

import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.ProfileService;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.EntityHasDescendantsException;
import com.ibm.websphere.wim.exception.EntityIdentifierNotSpecifiedException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InvalidIdentifierException;
import com.ibm.websphere.wim.exception.InvalidInitPropertyException;
import com.ibm.websphere.wim.exception.InvalidPropertyDefinitionException;
import com.ibm.websphere.wim.exception.MissingMandatoryPropertyException;
import com.ibm.websphere.wim.exception.MissingSearchControlException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.PasswordCheckFailedException;
import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.UpdateOperationalPropertyException;
import com.ibm.websphere.wim.exception.UpdatePropertyException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.websphere.wim.util.UniqueIdGenerator;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.DataAccessObject;
import com.ibm.ws.wim.dao.QuerySet;
import com.ibm.ws.wim.dao.schema.DBDataType;
import com.ibm.ws.wim.dao.schema.DBRepositoryProperty;
import com.ibm.ws.wim.util.AsyncUtils;
import com.ibm.ws.wim.util.ControlsHelper;
import com.ibm.ws.wim.util.LoginHelper;
import com.ibm.ws.wim.util.PasswordEncryptionUtil;
import com.ibm.ws.wim.util.SearchParameter;
import com.ibm.ws.wim.util.UniqueNameHelper;
import com.ibm.ws.wim.xpath.ParseException;
import com.ibm.ws.wim.xpath.TokenMgrError;
import com.ibm.ws.wim.xpath.WIMXPathInterpreter;
import com.ibm.ws.wim.xpath.db.util.DBXPathTranslateHelper;
import com.ibm.ws.wim.xpath.mapping.datatype.PropertyNode;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;
import com.ibm.ws.wim.xpath.util.MetadataMapper;
import com.ibm.wsspi.wim.Repository;
import commonj.sdo.ChangeSummary;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Type;
import commonj.sdo.ChangeSummary.Setting;
import java.io.StringReader;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;

public class DBAdapter implements Repository, DynamicConfigService {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private DataAccessObject dao = null;
	private DBPropertyCache propertyManager = null;
	private ProfileService ps = null;
	private int entityRetrievalLimit = 200;
	private int saltLength = 12;
	private String encryptionKey = "rZ15ws0ely9yHk3zCs3sTMv/ho8fY17s";
	private String ENCRYPTION_KEY = "1234567890abcdef";
	private List loginProperties = null;
	private String reposId = null;
	private SchemaManager schemaMgr = null;
	private ConfigManager configMgr = null;
	private String namespace = "http://www.ibm.com/websphere/wim";
	private boolean isDbSharedAcrossMultipleServers = false;
	private String dbType;
	private String datasourceName;
	private String dbURL;
	private String dbSchema;
	private String dbUserId;
	private String dbPwd;
	private String dbDriver;
	private Boolean adapterNotInitialized = false;
	private Boolean allowStartupIfDBDown = false;
	private boolean ignoreDNBaseSearch = false;

	public void initialize(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI initialize (DataObject reposConfig)");
		}

		if (var1 == null) {
			throw new WIMSystemException("LOAD_DATAGRAPH_FAILED",
					WIMMessageHelper.generateMsgParms("Database repository configuration is not defined."), CLASSNAME,
					"initialize (DataObject reposConfig)");
		} else {
			this.schemaMgr = SchemaManager.singleton();
			this.configMgr = ConfigManager.singleton();
			this.reposId = var1.getString("id");
			this.dbType = var1.getString("databaseType");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize (DataObject reposConfig)",
						"dbType is " + this.dbType);
			}

			this.datasourceName = var1.getString("dataSourceName");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize (DataObject reposConfig)",
						"datasource name is " + this.datasourceName);
			}

			this.dbURL = var1.getString("dbURL");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize (DataObject reposConfig)", "dbURL is " + this.dbURL);
			}

			this.dbUserId = var1.getString("dbAdminId");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize (DataObject reposConfig)",
						"userId is " + this.dbUserId);
			}

			this.dbPwd = var1.getString("dbAdminPassword");
			this.dbDriver = var1.getString("JDBCDriverClass");
			this.dbSchema = var1.getString("dbSchema");
			if (var1.isSet("entityRetrievalLimit")) {
				this.entityRetrievalLimit = var1.getInt("entityRetrievalLimit");
			}

			if (var1.isSet("saltLength")) {
				this.saltLength = var1.getInt("saltLength");
			}

			PasswordEncryptionUtil.setSaltLength(this.saltLength);
			String var3 = var1.getString("encryptionKey");
			if (var3 != null) {
				this.encryptionKey = var3;

				try {
					this.ENCRYPTION_KEY = PasswordEncryptionUtil.decrypt(this.encryptionKey.trim(), (String) null)
							.trim();
				} catch (NullPointerException var12) {
					this.ENCRYPTION_KEY = this.encryptionKey;
					if (this.ENCRYPTION_KEY.length() != 16) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME, "initialize (DataObject reposConfig)",
									"The length of encryption key needs to be 16 characters", var12);
						}

						throw new InvalidInitPropertyException("INVALID_INIT_PROPERTY",
								WIMMessageHelper.generateMsgParms("encryptionKey"), CLASSNAME,
								"initialize (DataObject reposConfig)");
					}
				}
			}

			List var4 = var1.getList("loginProperties");
			List var5;
			int var6;
			if (var4 != null && var4.size() != 0) {
				this.loginProperties = new ArrayList();

				for (int var13 = 0; var13 < var4.size(); ++var13) {
					this.loginProperties.add(var4.get(var13));
				}
			} else {
				var5 = this.configMgr.getSupportedEntityTypes();

				for (var6 = 0; var6 < var5.size(); ++var6) {
					String var7 = (String) var5.get(var6);
					if (this.schemaMgr.isSuperType("PersonAccount", var7)) {
						this.loginProperties = this.configMgr.getRDNProperties(var7);
						break;
					}
				}
			}

			var5 = var1.getList("CustomProperties");

			for (var6 = 0; var6 < var5.size(); ++var6) {
				DataObject var14 = (DataObject) var5.get(var6);
				String var8 = var14.getString("name");
				if (var8 != null && "allowStartupIfDBDown".equals(var8)) {
					String var9 = var14.getString("value");
					this.allowStartupIfDBDown = Boolean.parseBoolean(var9);
					if (this.allowStartupIfDBDown) {
						this.adapterNotInitialized = true;
					}
					break;
				}
			}

			try {
				this.DBConnect(this.dbType, this.datasourceName, this.dbURL, this.dbSchema, this.dbUserId, this.dbPwd,
						this.dbDriver);
			} catch (WIMConfigurationException var10) {
				throw var10;
			} catch (WIMException var11) {
				if (!this.adapterNotInitialized) {
					throw var11;
				}
			}

			String var15 = System.getProperty("com.ibm.ws.wim.registry.DbSharedAcrossMultipleServers");
			if (var15 != null) {
				this.isDbSharedAcrossMultipleServers = Boolean.parseBoolean(var15);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.log(Level.FINER, "com.ibm.ws.wim.registry.DbSharedAcrossMultipleServers="
							+ this.isDbSharedAcrossMultipleServers);
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI initialize (DataObject reposConfig)",
						"isDbSharedAcrossMultipleServers=" + this.isDbSharedAcrossMultipleServers);
			}

		}
	}

	public DataObject create(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI create(DataObject inRoot)", WIMTraceHelper.printDataObject(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.reposId, CLASSNAME, "create(DataObject inRoot)");
		Boolean var3;
		if (this.adapterNotInitialized) {
			var3 = this.adapterNotInitialized;
			synchronized (this.adapterNotInitialized) {
				this.DBConnect(this.dbType, this.datasourceName, this.dbURL, this.dbSchema, this.dbUserId, this.dbPwd,
						this.dbDriver);
				this.adapterNotInitialized = false;
			}
		}

		var3 = null;
		DataObject var24 = this.schemaMgr.createRootDataObject();
		List var4 = var1.getList("entities");
		DataObject var5 = (DataObject) var4.get(0);
		String var6 = var5.getDataObject("identifier").getString("uniqueName");
		String var7 = this.schemaMgr.getQualifiedTypeName(var5.getType());
		if (this.schemaMgr.isSuperType("PersonAccount", var7)) {
			if (var5.isSet("principalName")) {
				throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms("principalName", this.reposId), CLASSNAME,
						"create(DataObject inRoot)");
			}

			if (var5.isSet("realm")) {
				throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms("realm", this.reposId), CLASSNAME,
						"create(DataObject inRoot)");
			}
		}

		if (var5.isSet("createTimestamp")) {
			throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE",
					WIMMessageHelper.generateMsgParms("createTimestamp", CLASSNAME, "create(DataObject inRoot)"));
		} else if (var5.isSet("modifyTimestamp")) {
			throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE",
					WIMMessageHelper.generateMsgParms("modifyTimestamp", CLASSNAME, "create(DataObject inRoot)"));
		} else {
			String var8 = UniqueIdGenerator.newUniqueId();
			var5.getDataObject("identifier").setString("uniqueId", var8);
			DBEntity var9 = new DBEntity();
			var9.setUniqueName(var6);
			var9.setEntityType(var7);
			var9.setUniqueId(var8);
			long var10 = this.dao.createDBEntity(var9);
			DataObject var12 = var5.getDataObject("parent");
			String var13 = var12.getDataObject("identifier").getString("uniqueName");
			String var14 = var12.getDataObject("identifier").getString("uniqueId");
			DBEntity var15 = new DBEntity();
			var15.setUniqueName(var13);
			var15.setUniqueId(var14);
			this.dao.createParentRelationship(var10, var15);
			long var16 = System.currentTimeMillis();
			Timestamp var18 = new Timestamp(var16);
			var5.set("createTimestamp", var18);
			var5.set("modifyTimestamp", var18);
			this.createProperties(var10, var5);
			List var19;
			ArrayList var20;
			int var21;
			DataObject var22;
			if (var5.isSet("groups")) {
				var19 = var5.getList("groups");
				if (var19.size() > 0) {
					var20 = new ArrayList();

					for (var21 = 0; var21 < var19.size(); ++var21) {
						var22 = ((DataObject) var19.get(var21)).getDataObject("identifier");
						var20.add(var22);
					}

					this.dao.createGroupRelationsForEntity(this.reposId, var8, var20);
				}
			}

			if (this.schemaMgr.isSuperType("Group", var7) && var5.isSet("members")) {
				var19 = var5.getList("members");
				if (var19.size() > 0) {
					var20 = new ArrayList();

					for (var21 = 0; var21 < var19.size(); ++var21) {
						var22 = ((DataObject) var19.get(var21)).getDataObject("identifier");
						var20.add(var22);
					}

					this.dao.createGroupRelationsForGroup(var10, var20, this.reposId);
				}
			}

			DataObject var25 = var24.createDataObject("entities", var5.getType().getURI(), var5.getType().getName());
			DataObject var26 = var25.createDataObject("identifier");
			var26.setString("uniqueName", var6);
			var26.setString("uniqueId", var8);
			var26.setString("externalName", var6);
			var26.setString("externalId", var8);
			var26.setString("repositoryId", this.reposId);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI create(DataObject inRoot)",
						WIMTraceHelper.printDataObject(var24));
			}

			return var24;
		}
	}

	public DataObject get(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI get(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.reposId, CLASSNAME, "get(DataObject)");
		if (this.adapterNotInitialized) {
			Boolean var3 = this.adapterNotInitialized;
			synchronized (this.adapterNotInitialized) {
				this.DBConnect(this.dbType, this.datasourceName, this.dbURL, this.dbSchema, this.dbUserId, this.dbPwd,
						this.dbDriver);
				this.adapterNotInitialized = false;
			}
		}

		DataObject var47 = this.schemaMgr.createRootDataObject();
		DataObject var4 = null;
		Map var5 = ControlsHelper.getControlMap(var1);
		DataObject var6 = (DataObject) var5.get("PropertyControl");
		DataObject var7 = (DataObject) var5.get("GroupMemberControl");
		DataObject var8 = (DataObject) var5.get("GroupMembershipControl");
		DataObject var9 = (DataObject) var5.get("AncestorControl");
		DataObject var10 = (DataObject) var5.get("DescendantControl");
		DataObject var11 = (DataObject) var5.get("CheckGroupMembershipControl");
		String[] var12 = new String[0];
		Object var13 = null;
		List var14 = null;
		if (var6 != null) {
			var13 = var6.getList("properties");
			var14 = var6.getList("contextProperties");

			for (int var15 = 0; var15 < var14.size(); ++var15) {
				DataObject var16 = (DataObject) var14.get(var15);
				((List) var13).add(var16.getString("value"));
			}
		} else {
			var13 = new ArrayList();
		}

		var12 = (String[]) ((String[]) ((List) var13).toArray(var12));
		List var48 = var1.getList("entities");

		for (int var49 = 0; var49 < var48.size(); ++var49) {
			DataObject var17 = (DataObject) var48.get(var49);
			String var18 = var17.getType().getName();
			Object var19 = null;
			String var20 = var17.getDataObject("identifier").getString("externalId");
			String var21 = var17.getDataObject("identifier").getString("uniqueName");
			String var22 = var17.getDataObject("identifier").getString("repositoryId");
			if (var22 != null && var22.trim().length() != 0) {
				var22 = var22.trim();
			} else {
				var22 = this.reposId;
			}

			DBEntity var23 = null;
			String var24;
			DataObject var25;
			List var54;
			if (!var22.equalsIgnoreCase(this.reposId)) {
				if (var8 != null) {
					var24 = this.schemaMgr.getQualifiedTypeName(var17.getType());
					var4 = var47.createDataObject("entities", this.schemaMgr.getTypeNsURI(var24), var24);
					var25 = var4.createDataObject("identifier");
					var25.setString("uniqueId", var17.getDataObject("identifier").getString("uniqueId"));
					var25.setString("externalId", var17.getDataObject("identifier").getString("externalId"));
					var25.setString("uniqueName", var17.getDataObject("identifier").getString("uniqueName"));
					var25.setString("externalName", var17.getDataObject("identifier").getString("externalName"));
					var25.setString("repositoryId", var17.getDataObject("identifier").getString("repositoryId"));
				}
			} else {
				if (var20 != null && var20.trim().length() != 0) {
					var23 = this.dao.findDBEntityByUniqueId(var20);
				} else if (var21 != null && var21.trim().length() != 0) {
					var23 = this.dao.findDBEntityByUniqueNameKey(var21);
				}

				if (var23 == null) {
					throw new EntityNotFoundException("ENTITY_NOT_FOUND",
							WIMMessageHelper.generateMsgParms("[" + var20 + "/" + var21 + "]"), CLASSNAME,
							"get(DataObject)");
				}

				var24 = var23.getEntityType();
				var4 = var47.createDataObject("entities", this.schemaMgr.getTypeNsURI(var24),
						this.schemaMgr.getTypeName(var24));
				var25 = var4.createDataObject("identifier");
				long var26 = var23.getEntityId();
				var25.setString("uniqueId", var23.getUniqueId());
				var25.setString("externalId", var23.getUniqueId());
				var25.setString("uniqueName", var23.getUniqueName());
				var25.setString("externalName", var23.getUniqueName());
				var25.setString("repositoryId", this.reposId);
				if (var20 == null) {
					var20 = var23.getUniqueId();
				}

				if (var12.length > 0) {
					this.getProperties(var4, var26, var12);
				}

				int var28;
				DataObject var39;
				if (var9 != null) {
					var28 = var9.getInt("level");
					if (var28 == 0) {
						var28 = var23.getUniqueName().length();
					}

					long var29 = var26;
					DataObject var31 = var4;

					for (int var32 = 0; var32 < var28; ++var32) {
						DBEntity var33 = this.dao.findParent(var29);
						if (var33 == null) {
							break;
						}

						long var34 = var33.getEntityId();
						String var36 = var33.getEntityType();
						String var37 = var33.getUniqueId();
						String var38 = var33.getUniqueName();
						var39 = var31.createDataObject("parent", this.schemaMgr.getTypeNsURI(var36), var36);
						DataObject var40 = var39.createDataObject("identifier");
						var40.setString("uniqueName", var38);
						var40.setString("uniqueId", var37);
						var40.setString("externalName", var38);
						var40.setString("externalId", var37);
						var40.setString("repositoryId", this.reposId);
						String[] var41 = ControlsHelper.getPropertyNames(var9);
						if (var41 != null && var41.length != 0) {
							this.getProperties(var39, var34, var41);
						}

						var29 = var34;
						var31 = var39;
					}
				}

				String var30;
				List var35;
				WIMXPathInterpreter var57;
				XPathNode var59;
				List var62;
				if (var10 != null) {
					var28 = var10.getInt("level");
					List var55 = null;
					var30 = var10.getString("expression");
					if (var30 != null) {
						var57 = new WIMXPathInterpreter(new StringReader(var30));

						try {
							var59 = var57.parse((MetadataMapper) null);
						} catch (ParseException var44) {
							throw new SearchControlException("MISSING_SEARCH_EXPRESSION", CLASSNAME, "get(DataObject)");
						} catch (TokenMgrError var45) {
							throw new SearchControlException("INVALID_SEARCH_EXPRESSION",
									WIMMessageHelper.generateMsgParms(var30), CLASSNAME, "get(DataObject)", var45);
						}

						var55 = var57.getEntityTypes();
					}

					boolean var58 = var10.getBoolean("treeView");
					String[] var61 = ControlsHelper.getPropertyNames(var10);
					if (var58 && var28 != 1) {
						throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
								WIMMessageHelper.generateMsgParms("treeView", this.reposId), CLASSNAME,
								"get(DataObject)");
					}

					if (var28 == 0) {
						var62 = this.dao.getAllDescendantsByUniqueNameKey(var23.getTruncUniqueName(), var55);
						this.getEntityInformationByEntityIds(var62, var61, var4, "children");
					} else {
						new ArrayList();
						if (var28 == 1) {
							var62 = this.dao.getChildrenByUniqueNameKey(var23.getTruncUniqueName(), var55);
						} else {
							var62 = this.dao.getChildrenByUniqueNameKey(var23.getTruncUniqueName(), var55);

							for (int var64 = 0; var64 < var28 - 1; ++var64) {
								var35 = this.dao.getChildrenByEntityIdList(var62, var55);
								if (var35 == null) {
									break;
								}

								var62.addAll(var35);
							}
						}

						if (var62 != null) {
							this.getEntityInformationByEntityIds(var62, var61, var4, "children");
						}
					}
				}

				if (this.schemaMgr.isSuperType("Group", var24) && var7 != null) {
					var54 = null;
					String[] var56 = ControlsHelper.getPropertyNames(var7);
					var30 = var7.getString("expression");
					if (var30 != null) {
						var57 = new WIMXPathInterpreter(new StringReader(var30));

						try {
							var59 = var57.parse((MetadataMapper) null);
						} catch (ParseException var42) {
							throw new SearchControlException("MISSING_SEARCH_EXPRESSION", CLASSNAME, "get(DataObject)");
						} catch (TokenMgrError var43) {
							throw new SearchControlException("INVALID_SEARCH_EXPRESSION",
									WIMMessageHelper.generateMsgParms(var30), CLASSNAME, "get(DataObject)", var43);
						}

						var54 = var57.getEntityTypes();
					}

					int var60 = var7.getInt("level");
					boolean var63 = var7.getBoolean("treeView");
					var62 = var7.getList("searchBases");
					Set[] var65 = null;
					if (var60 == 1) {
						var65 = this.dao.getImmediateGroupMembers(var26, var54, var62);
					} else {
						if (var60 != 0 || var63) {
							throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
									WIMMessageHelper.generateMsgParms("treeView", this.reposId), CLASSNAME,
									"get(DataObject)");
						}

						var65 = this.dao.getNestedGroupMembers(var26, var54, var62);
					}

					if (var65[0] != null && var65[0].size() != 0) {
						var35 = this.getEntityIdsFromDBEntityIdEntityTypeSet(var65[0]);
						this.getEntityInformationByEntityIds(var35, var56, var4, "members");

						label179 : for (int var66 = 0; var66 < var56.length; ++var66) {
							if (var56[var66].equalsIgnoreCase("principalName")) {
								List var67 = var4.getList("members");
								Iterator var68 = var67.iterator();

								while (true) {
									if (!var68.hasNext()) {
										break label179;
									}

									var39 = (DataObject) var68.next();
									String var69 = var39.getString((String) this.loginProperties.get(0));
									var39.set("principalName", var69);
								}
							}
						}
					}

					if (var65[1] != null && var65[1].size() != 0) {
						this.getOtherRepositoryGroupMembers(var65[1], var4);
					}
				}
			}

			if (var8 != null) {
				String[] var50 = ControlsHelper.getPropertyNames(var8);
				List var52 = var8.getList("searchBases");
				int var53 = var8.getInt("level");
				boolean var27 = var8.getBoolean("treeView");
				var54 = null;
				if (var53 == 1) {
					var54 = this.dao.getImmediateGroupsForEntity(var20, var22, var52);
				} else {
					if (var53 != 0 || var27) {
						throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
								WIMMessageHelper.generateMsgParms("treeView", this.reposId), CLASSNAME,
								"get(DataObject)");
					}

					var54 = this.dao.getNestedGroupsForEntity(var20, var22, this.reposId, new ArrayList(), var52);
				}

				this.getEntityInformationByEntityIds(var54, var50, var4, "groups");
			}

			if (var11 != null) {
				int var51 = var11.getInt("level");
				var25 = var47.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"CheckGroupMembershipControl");
				var25.setBoolean("inGroup", this.isMemberInGroup(var23, var17, var51));
			}
		}

		this.setPrincipleName(var47, (List) var13);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI get(DataObject)", WIMTraceHelper.printDataObject(var47));
		}

		return var47;
	}

	private boolean isMemberInGroup(DBEntity var1, DataObject var2, int var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isMemberInGroup");
		}

		boolean var5 = false;
		List var6 = var2.getList("groups");
		String var10;
		if (var6.size() > 0) {
			DataObject var12 = (DataObject) var6.get(0);
			DBEntity var13 = this.getDBEntityByIdentifier(var12.getDataObject("identifier"));
			if (var13 == null) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper
						.generateMsgParms(var12.getString("uniqueName|uniqueId"), CLASSNAME, "isMemberInGroup"));
			}

			if (var1 != null) {
				var5 = this.dao.isMemberInGroup(var13.getEntityId(), var1.getUniqueId(), this.reposId, this.reposId,
						var3);
			} else {
				String var14 = var2.getDataObject("identifier").getString("externalId");
				var10 = var2.getDataObject("identifier").getString("repositoryId");
				if (var14 == null || var14.trim().length() == 0 || var10 == null || var10.trim().length() == 0) {
					throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED", CLASSNAME,
							"isMemberInGroup");
				}

				var5 = this.dao.isMemberInGroup(var13.getEntityId(), var14, var10, this.reposId, var3);
			}
		} else if (var1 != null && this.schemaMgr.isSuperType("Group", var1.getEntityType())) {
			List var7 = var2.getList("members");
			if (var7.size() > 0) {
				DataObject var8 = (DataObject) var7.get(0);
				DBEntity var9 = this.getDBEntityByIdentifier(var8.getDataObject("identifier"));
				if (var9 != null) {
					var5 = this.dao.isMemberInGroup(var1.getEntityId(), var9.getUniqueId(), this.reposId, this.reposId,
							var3);
				} else {
					var10 = var8.getString("externalId");
					String var11 = var8.getString("repositoryId");
					if (var10 == null || var10.trim().length() == 0 || var11 == null || var11.trim().length() == 0) {
						throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED", CLASSNAME,
								"isMemberInGroup");
					}

					var5 = this.dao.isMemberInGroup(var1.getEntityId(), var10, var11, this.reposId, var3);
				}
			} else {
				var5 = false;
			}
		} else {
			var5 = false;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isMemberInGroup");
		}

		return var5;
	}

	private void getOtherRepositoryGroupMembers(Set var1, DataObject var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getOtherRepositoryGroupMembers(Set extIdReposId, DataObject entity)");
		}

		Iterator var4 = var1.iterator();

		while (var4.hasNext()) {
			EClass var5 = SchemaManager.singleton().getEClass("Entity");
			DataObject var6 = (DataObject) EcoreUtil.create(var5);
			DataObject var7 = var6.createDataObject("identifier");
			DBExtIdReposId var8 = (DBExtIdReposId) var4.next();
			var7.setString("externalId", var8.getExtId());
			var7.setString("repositoryId", var8.getReposId().trim());
			var2.getList("members").add(var6);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getOtherRepositoryGroupMembers(Set extIdReposId, DataObject entity)");
		}

	}

	private List getEntityIdsFromDBEntityIdEntityTypeSet(Set var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getEntityIdsFromDBEntityIdEntityTypeSet(Set entIdEntType)");
		}

		ArrayList var3 = new ArrayList();
		Iterator var4 = var1.iterator();

		while (var4.hasNext()) {
			DBEntityIdEntityType var5 = (DBEntityIdEntityType) var4.next();
			var3.add(var5.getEntId());
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getEntityIdsFromDBEntityIdEntityTypeSet(Set entIdEntType)");
		}

		return var3;
	}

	private void getEntityInformationByEntityIds(List var1, String[] var2, DataObject var3, String var4)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getEntityInformationByEntityIds(List entityIdList, String[] propNames, DataObject entity, String DO_PROPERTYNAME)");
		}

		if (var1 != null && var1.size() != 0) {
			int var6 = var1.size();
			int var7 = var6 >= 1000 ? 990 : 0;
			int var8 = var7;
			trcLogger.log(Level.FINE, "DBEntityRetrievalLimit : " + var7);
			if (var7 == 0) {
				var8 = var6;
			}

			int var9 = 0;

			do {
				int var10;
				if (var6 > var8) {
					var10 = var8;
				} else {
					var10 = var6;
				}

				StringBuffer var11 = null;
				if (var1 != null && var1.size() != 0) {
					var11 = new StringBuffer(256);
					var11.append(this.dao.getQuerySet().ENTITY_ID_IN);
				}

				for (; var9 < var10; ++var9) {
					var11.append(var1.get(var9));
					if (var9 != var10 - 1) {
						var11.append(this.dao.getQuerySet().COMMA);
					}
				}

				var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
				StringBuffer var12 = null;
				StringBuffer var13 = null;
				StringBuffer var14 = null;
				StringBuffer var15 = null;
				StringBuffer var16 = null;
				StringBuffer var17 = null;
				Object var18 = null;
				Object var19 = null;
				Object var20 = null;
				short var21 = 1;

				for (int var22 = 0; var22 < var2.length; ++var22) {
					DBRepositoryProperty var23 = this.propertyManager.getPropertyDefinition(var2[var22]);
					if (var23 == null && var2[var22].equals("principalName") && this.loginProperties != null
							&& this.loginProperties.size() > 0) {
						var23 = this.propertyManager.getPropertyDefinition((String) this.loginProperties.get(0));
					}

					if (var23 != null && !var23.isComposite()) {
						short var24 = DAOHelper.getDataTypeId(var23.getDataType());
						switch (var24) {
							case 0 :
								if (var12 == null) {
									var12 = new StringBuffer(256);
									++var21;
									var12.append(var23.getPropId());
								} else {
									var12.append(this.dao.getQuerySet().COMMA);
									var12.append(var23.getPropId());
								}
								break;
							case 1 :
								if (var15 == null) {
									var15 = new StringBuffer(256);
									++var21;
									var15.append(var23.getPropId());
								} else {
									var15.append(this.dao.getQuerySet().COMMA);
									var15.append(var23.getPropId());
								}
								break;
							case 2 :
								if (var14 == null) {
									var14 = new StringBuffer(256);
									++var21;
									var14.append(var23.getPropId());
								} else {
									var14.append(this.dao.getQuerySet().COMMA);
									var14.append(var23.getPropId());
								}
								break;
							case 3 :
								if (var13 == null) {
									var13 = new StringBuffer(256);
									++var21;
									var13.append(var23.getPropId());
								} else {
									var13.append(this.dao.getQuerySet().COMMA);
									var13.append(var23.getPropId());
								}
								break;
							case 4 :
								if (var16 == null) {
									var16 = new StringBuffer(256);
									++var21;
									var16.append(var23.getPropId());
								} else {
									var16.append(this.dao.getQuerySet().COMMA);
									var16.append(var23.getPropId());
								}
							case 5 :
								break;
							case 6 :
								if (var17 == null) {
									var17 = new StringBuffer(256);
									++var21;
									var17.append(var23.getPropId());
								} else {
									var17.append(this.dao.getQuerySet().COMMA);
									var17.append(var23.getPropId());
								}
								break;
							default :
								throw new WIMApplicationException("INVALID_PROPERTY_DATA_TYPE",
										WIMMessageHelper.generateMsgParms(var23.getDataType()), CLASSNAME,
										"getEntityInformationByEntityIds(List entityIdList, String[] propNames, DataObject entity, String DO_PROPERTYNAME)");
						}
					}
				}

				StringBuffer var25 = new StringBuffer((var11.length() + 512) * var21);
				var25.append(this.dao.getQuerySet().findDBEntityGeneral);
				var25.append(this.dao.getQuerySet().AND);
				var25.append(var11);
				if (var12 != null) {
					var25.append(this.dao.getQuerySet().UNION);
					var25.append(this.dao.getSpecificDatatypePropertyForEntitiesQuery((short) 0));
					var25.append(this.dao.getQuerySet().findDBPropertyIdIn);
					var25.append(var12);
					var25.append(this.dao.getQuerySet().RIGHT_BRACKET);
					var25.append(this.dao.getQuerySet().AND);
					var25.append(var11);
				}

				if (var13 != null) {
					var25.append(this.dao.getQuerySet().UNION);
					var25.append(this.dao.getSpecificDatatypePropertyForEntitiesQuery((short) 3));
					var25.append(this.dao.getQuerySet().findDBPropertyIdIn);
					var25.append(var13);
					var25.append(this.dao.getQuerySet().RIGHT_BRACKET);
					var25.append(this.dao.getQuerySet().AND);
					var25.append(var11);
				}

				if (var15 != null) {
					var25.append(this.dao.getQuerySet().UNION);
					var25.append(this.dao.getSpecificDatatypePropertyForEntitiesQuery((short) 1));
					var25.append(this.dao.getQuerySet().findDBPropertyIdIn);
					var25.append(var15);
					var25.append(this.dao.getQuerySet().RIGHT_BRACKET);
					var25.append(this.dao.getQuerySet().AND);
					var25.append(var11);
				}

				if (var14 != null) {
					var25.append(this.dao.getQuerySet().UNION);
					var25.append(this.dao.getSpecificDatatypePropertyForEntitiesQuery((short) 2));
					var25.append(this.dao.getQuerySet().findDBPropertyIdIn);
					var25.append(var14);
					var25.append(this.dao.getQuerySet().RIGHT_BRACKET);
					var25.append(this.dao.getQuerySet().AND);
					var25.append(var11);
				}

				if (var16 != null) {
					var25.append(this.dao.getQuerySet().UNION);
					var25.append(this.dao.getSpecificDatatypePropertyForEntitiesQuery((short) 4));
					var25.append(this.dao.getQuerySet().findDBPropertyIdIn);
					var25.append(var16);
					var25.append(this.dao.getQuerySet().RIGHT_BRACKET);
					var25.append(this.dao.getQuerySet().AND);
					var25.append(var11);
				}

				var25.append(this.dao.getQuerySet().findSpecificPropertyForEntitiesOrderBy);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.log(Level.FINER, var25.toString());
				}

				this.dao.getDBEntityInformation(var25.toString(), var3, var4, this.reposId);
				var8 += var7;
			} while (var6 > var9);

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"getEntityInformationByEntityIds(List entityIdList, String[] propNames, DataObject entity, String DO_PROPERTYNAME)");
			}

		}
	}

	private void getProperties(DataObject var1, long var2, String[] var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getProperties(DataObject entity, long entityId, String[] propNames, DataObject propCtrl)");
		}

		StringBuffer var6 = null;
		StringBuffer var7 = null;
		StringBuffer var8 = null;
		StringBuffer var9 = null;
		StringBuffer var10 = null;
		StringBuffer var11 = null;
		StringBuffer var12 = null;
		StringBuffer var13 = null;
		boolean var14 = false;
		boolean[] var15 = null;
		String var17;
		if (var4 != null) {
			for (int var16 = 0; var16 < var4.length; ++var16) {
				var17 = var4[var16];
				if (var17.equals("*")) {
					this.dao.readAllDBPropertiesForEntity(var2, var1);
				}

				DBRepositoryProperty var18 = this.propertyManager.getPropertyDefinition(var17);
				if (var18 == null && var17.equals("principalName") && this.loginProperties != null
						&& this.loginProperties.size() > 0) {
					var18 = this.propertyManager.getPropertyDefinition((String) this.loginProperties.get(0));
				}

				if (var18 != null) {
					if (!var18.isComposite()) {
						String var22 = var18.getDataType();
						short var20 = DAOHelper.getDataTypeId(var22);
						switch (var20) {
							case 0 :
								var6 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var6);
								break;
							case 1 :
								var9 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var9);
								break;
							case 2 :
								var8 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var8);
								break;
							case 3 :
								var7 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var7);
								break;
							case 4 :
								var10 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var10);
								break;
							case 5 :
								var11 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var11);
								break;
							case 6 :
								var12 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var12);
						}
					} else {
						if (!var14) {
							var15 = new boolean[DAOHelper.types.length];

							for (int var19 = 0; var19 < DAOHelper.types.length; ++var19) {
								var15[var19] = false;
							}

							var14 = true;
							var13 = new StringBuffer(256);
							var13.append(var18.getPropId());
						} else {
							var13.append(this.dao.getQuerySet().COMMA);
							var13.append(var18.getPropId());
						}

						this.appendCompositeProperty(var18, var13, var15);
					}
				}
			}

			if (var6 != null) {
				var6.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readDBProperties(var2, var6, (short) 0, var1);
			}

			if (var7 != null) {
				var7.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readDBProperties(var2, var7, (short) 3, var1);
			}

			if (var8 != null) {
				var8.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readDBProperties(var2, var8, (short) 2, var1);
			}

			if (var9 != null) {
				var9.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readDBProperties(var2, var9, (short) 1, var1);
			}

			if (var10 != null) {
				var10.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readDBProperties(var2, var10, (short) 4, var1);
			}

			if (var11 != null) {
				var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readDBProperties(var2, var11, (short) 5, var1);
			}

			if (var12 != null) {
				var12.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readDBProperties(var2, var12, (short) 6, var1);
			}
		}

		if (var14) {
			HashMap var21 = new HashMap();
			var21.put(new Long(var2), var1);
			var17 = DAOHelper.buildEntityIdSQL(var21);
			this.dao.getCompositeProperties(var21, var13.toString(), var15, var17, true);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"getProperties(DataObject entity, long entityId, String[] propNames, DataObject propCtrl)");
		}

	}

	private StringBuffer buildGetPropertyQuery(short var1, Integer var2, int var3, StringBuffer var4) {
		if (var4 == null) {
			var4 = new StringBuffer(256 + var3 * 8);
			var4.append(this.dao.getDBPropValuesByEntityQuery(var1));
			var4.append(var2);
		} else {
			var4.append(this.dao.getQuerySet().COMMA);
			var4.append(var2);
		}

		return var4;
	}

	public DataObject delete(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI delete(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.reposId, CLASSNAME, "delete(DataObject)");
		Map var3 = ControlsHelper.getControlMap(var1);
		DataObject var4 = (DataObject) var3.get("DeleteControl");
		DataObject var5 = (DataObject) var3.get("GroupMembershipControl");
		DataObject var6 = this.schemaMgr.createRootDataObject();
		List var7 = var1.getList("entities");
		DataObject var8 = (DataObject) var7.get(0);
		String var10;
		if (var5 != null) {
			String var9 = var8.getDataObject("identifier").getString("externalId");
			var10 = var8.getDataObject("identifier").getString("repositoryId");
			if (var9 != null && var10 != null) {
				DBExtIdReposId var11 = new DBExtIdReposId();
				var11.setExtId(var9);
				var11.setReposId(var10);
				this.dao.unassignMemberFromAllGroups(var11);
			}
		} else {
			boolean var17 = false;
			if (var4 != null) {
				var17 = var4.getBoolean("deleteDescendants");
			}

			var10 = null;
			HashSet var18 = new HashSet();
			String var19 = var8.getDataObject("identifier").getString("uniqueName");
			if (var19 != null) {
				this.delete(var19, var18, var17);
			}

			Iterator var12 = var18.iterator();

			while (var12.hasNext()) {
				DBEntity var13 = (DBEntity) var12.next();
				String var14 = var13.getEntityType();
				String var15 = this.schemaMgr.getTypeNsURI(var14);
				DataObject var16 = var6.createDataObject("entities", var15, this.schemaMgr.getTypeName(var14))
						.createDataObject("identifier");
				var16.setString("uniqueName", var13.getUniqueName());
				var16.setString("uniqueId", var13.getUniqueId());
				var16.setString("externalName", var13.getUniqueName());
				var16.setString("externalId", var13.getUniqueId());
				var16.setString("repositoryId", this.reposId);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI delete(DataObject)", WIMTraceHelper.printDataObject(var6));
		}

		return var6;
	}

	private void delete(String var1, Set var2, boolean var3) throws WIMException {
		if (!var3) {
			boolean var5 = this.dao.checkIfEntityHasDescendants(DAOHelper.getTruncatedUniqueName(var1));
			if (var5) {
				throw new EntityHasDescendantsException("ENTITY_HAS_DESCENDENTS",
						WIMMessageHelper.generateMsgParms(var1), CLASSNAME,
						"delete(String uniqueName, Set deletedSet, boolean deleteDescendant)");
			}
		}

		List var13 = null;
		ArrayList var6 = null;
		DBEntity var7 = this.dao.findDBEntityByUniqueNameKey(DAOHelper.getTruncatedUniqueName(var1));
		Object var8 = null;
		Object var9 = null;
		if (var7 == null) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1), CLASSNAME,
					"delete(String uniqueName, Set deletedSet, boolean deleteDescendant)");
		} else {
			var13 = this.dao.findDBEntitysByParentName(var1);
			if (var13 != null) {
				var6 = new ArrayList();

				for (int var10 = 0; var10 < var13.size(); ++var10) {
					DBEntity var11 = (DBEntity) var13.get(var10);
					var6.add(var11.getUniqueId());
					var2.add(var11);
				}
			}

			if (var6 != null && var6.size() != 0) {
				Hashtable var12 = new Hashtable();
				var12.put(this.reposId, var6);
				this.dao.deleteDBGroupRelation(var12);
			}

			this.dao.deleteEntityWithDescendants(var1);
			if (var9 != null) {
				this.dao.deleteEntityWithDescendants((String) var8);
			}

		}
	}

	public DataObject update(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI update", WIMTraceHelper.printDataGraph(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.reposId, CLASSNAME, "update");
		Boolean var3;
		if (this.adapterNotInitialized) {
			var3 = this.adapterNotInitialized;
			synchronized (this.adapterNotInitialized) {
				this.DBConnect(this.dbType, this.datasourceName, this.dbURL, this.dbSchema, this.dbUserId, this.dbPwd,
						this.dbDriver);
				this.adapterNotInitialized = false;
			}
		}

		var3 = null;
		ChangeSummary var4 = var1.getDataGraph().getChangeSummary();
		List var5 = var4.getChangedDataObjects();
		DataObject var7;
		if (var5.size() > 0) {
			var7 = this.updateByChangeSummary(var1, var4);
		} else {
			var7 = this.updateByDataGraph(var1);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI update", WIMTraceHelper.printDataGraph(var7));
		}

		return var7;
	}

	private DataObject updateByChangeSummary(DataObject var1, ChangeSummary var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateByChangeSummary(DataObject inRoot, ChangeSummary changeSummary )",
					WIMTraceHelper.printDataObject(var1));
		}

		DataObject var4 = null;
		DataObject var5 = this.schemaMgr.createRootDataObject();
		var4 = (DataObject) var1.getList("entities").get(0);
		DataObject var6 = var4.getDataObject("identifier");
		DBEntity var7 = this.getDBEntityByIdentifier(var6);
		long var8 = var7.getEntityId();
		String var10 = var7.getEntityType();
		byte[] var11 = null;
		Hashtable[] var12 = new Hashtable[7];
		Hashtable[] var13 = new Hashtable[7];
		Hashtable[] var14 = new Hashtable[7];
		boolean var15 = false;
		boolean var16 = false;
		boolean var17 = false;
		Iterator var18 = var2.getOldValues(var4).iterator();

		String var23;
		while (var18.hasNext()) {
			Setting var19 = (Setting) var18.next();
			Property var20 = var19.getProperty();
			PropertyToUpdate var21 = new PropertyToUpdate();
			String var22 = var20.getName();
			if ("ibmPrimaryEmail".equalsIgnoreCase(var22)) {
				var22 = "ibm-primaryEmail";
			} else if ("ibmJobTitle".equalsIgnoreCase(var22)) {
				var22 = "ibm-jobTitle";
			}

			if (this.schemaMgr.isSuperType("PersonAccount", var10) && var22.equals("principalName")
					|| this.schemaMgr.isSuperType("PersonAccount", var10) && var22.equals("createTimestamp")
					|| this.schemaMgr.isSuperType("PersonAccount", var10) && var22.equals("modifyTimestamp")) {
				throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var22, this.reposId), CLASSNAME,
						"updateByChangeSummary(DataObject inRoot, ChangeSummary changeSummary )");
			}

			if (var22.equals("password")) {
				var11 = var4.getBytes(var20);
			}

			var23 = this.propertyManager.getPropertyDefinition(var22).getDataType();
			Integer var24 = this.propertyManager.getPropertyDefinition(var22).getPropId();
			boolean var25 = this.propertyManager.getPropertyDefinition(var22).isMultipleValued();
			short var26 = DAOHelper.getDataTypeId(var23);
			var21.setName(var22);
			var21.setOldValue(var19.getValue());
			var21.setNewValue(var4.get(var20));
			if (var21.getNewValue() == null) {
				if (var13[var26] == null) {
					var13[var26] = new Hashtable();
				}

				var13[var26].put(var24, var21);
				var15 = true;
			} else if (!var25 && var21.getOldValue() != null) {
				if (var12[var26] == null) {
					var12[var26] = new Hashtable();
				}

				var12[var26].put(var24, var21);
				var17 = true;
			} else {
				if (var14[var26] == null) {
					var14[var26] = new Hashtable();
				}

				var14[var26].put(var24, var21.getNewValue());
				var16 = true;
			}
		}

		long var27 = System.currentTimeMillis();
		Timestamp var28 = new Timestamp(var27);
		Integer var29 = this.propertyManager.getPropertyDefinition("modifyTimestamp").getPropId();
		PropertyToUpdate var32 = new PropertyToUpdate();
		var32.setName("modifyTimestamp");
		var32.setNewValue(var28);
		if (var12[4] == null) {
			var12[4] = new Hashtable();
		}

		var12[4].put(var29, var32);
		if (var15) {
			this.dao.deleteProperties((short) 0, var8, var13, this.propertyManager.getMultiValuePropertyIds(),
					(String) null);
		}

		if (var16) {
			this.dao.replaceProperties((short) 0, var8, var14, this.propertyManager.getMultiValuePropertyIds(),
					this.reposId, this.isDbSharedAcrossMultipleServers);
		}

		if (var17) {
			this.dao.updateProperties((short) 0, var8, var12);
		}

		if (var11 != null) {
			var23 = PasswordEncryptionUtil.generateSalt(this.saltLength);
			byte[] var31 = this.encrypt(var11, var23);
			this.dao.updateAccount(var8, var31, var23, (String) null, (String) null);
			PasswordUtil.erasePassword(var11);
		}

		DataObject var30 = SDOHelper.createEntityDataObject(var5, this.schemaMgr.getTypeNsURI(var10),
				this.schemaMgr.getTypeName(var10));
		DataObject var33 = var30.createDataObject("identifier");
		var33.set("uniqueName", var4.getDataObject("identifier").getString("uniqueName"));
		var33.set("externalName", var4.getDataObject("identifier").getString("externalName"));
		var33.set("uniqueId", var4.getDataObject("identifier").getString("uniqueId"));
		var33.set("externalId", var4.getDataObject("identifier").getString("externalId"));
		var33.set("repositoryId", this.reposId);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"WIM_SPI updateByChangeSummary(DataObject inRoot, ChangeSummary changeSummary )");
		}

		return var5;
	}

	private DataObject updateByDataGraph(DataObject var1) throws WIMException {
		DataObject var3 = this.schemaMgr.createRootDataObject();
		ArrayList var4 = new ArrayList();
		List var5 = var1.getList("entities");
		DataObject var6 = (DataObject) var5.get(0);
		Map var7 = ControlsHelper.getControlMap(var1);
		DBExtIdReposId var8 = new DBExtIdReposId();
		long var9 = 0L;
		String var11 = var6.getDataObject("identifier").getString("repositoryId");
		if (var11 == null) {
			var11 = this.reposId;
		}

		var8.setReposId(var11);
		DataObject var13;
		if (!var11.equals(this.reposId)) {
			String var12 = var6.getDataObject("identifier").getString("externalId");
			var8.setExtId(var12);
			var13 = (DataObject) var7.get("GroupMembershipControl");
			int var14 = 1;
			if (var13 != null) {
				var14 = var13.getInt("modifyMode");
			}

			List var15 = var6.getList("groups");
			if (var15 != null && var15.size() != 0) {
				this.groupMembershipUpdate(var15, var8, var14);
			}
		} else {
			DBEntity var20 = null;
			var13 = null;
			String var22 = var6.getDataObject("identifier").getString("externalId");
			String var23 = null;
			if (var22 != null && var22.trim().length() != 0) {
				var20 = this.dao.findDBEntityByUniqueId(var22);
			} else {
				var23 = var6.getDataObject("identifier").getString("externalName");
				if (var23 == null || var23.trim().length() == 0) {
					var23 = var6.getDataObject("identifier").getString("uniqueName");
				}

				if (var23 != null && var23.trim().length() != 0) {
					var20 = this.dao.findDBEntityByUniqueNameKey(var23);
				}
			}

			if (var20 == null) {
				throw new InvalidIdentifierException("INVALID_IDENTIFIER",
						WIMMessageHelper.generateMsgParms("[" + var22 + "/" + var23 + "]"), CLASSNAME,
						"updateByDataGraph(DataObject inRoot)");
			}

			var8.setExtId(var20.getUniqueId());
			var9 = var20.getEntityId();
			String var21 = var20.getEntityType();
			if (this.schemaMgr.isSuperType("PersonAccount", this.schemaMgr.getQualifiedTypeName(var6.getType()))
					&& var6.isSet("principalName")) {
				throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms("principalName", this.reposId), CLASSNAME,
						"updateByDataGraph(DataObject inRoot)");
			}

			if (var6.isSet("createTimestamp")) {
				throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE",
						WIMMessageHelper.generateMsgParms("createTimestamp", CLASSNAME,
								"updateByDataGraph(DataObject inRoot)"));
			}

			if (var6.isSet("modifyTimestamp")) {
				throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE",
						WIMMessageHelper.generateMsgParms("modifyTimestamp", CLASSNAME,
								"updateByDataGraph(DataObject inRoot)"));
			}

			var23 = var20.getTruncUniqueName();
			List var16 = this.configMgr.getRDNProperties(var21);
			var6.getDataObject("identifier").set("uniqueName", var20.getUniqueName());
			var6.getDataObject("identifier").set("externalName", var20.getUniqueName());
			var6.getDataObject("identifier").set("uniqueId", var20.getUniqueId());
			var6.getDataObject("identifier").set("externalId", var20.getUniqueId());
			var6.getDataObject("identifier").set("repositoryId", this.reposId);
			this.updateProperties(var20.getEntityId(), var16, var6, false, var4);
			DataObject var17;
			int var18;
			List var19;
			if (var6.isSet("groups")) {
				var17 = (DataObject) var7.get("GroupMembershipControl");
				var18 = 1;
				if (var17 != null) {
					var18 = var17.getInt("modifyMode");
				}

				var19 = var6.getList("groups");
				this.groupMembershipUpdate(var19, var8, var18);
			}

			if (this.schemaMgr.isSuperType("Group", var21) && var6.isSet("members")) {
				var17 = (DataObject) var7.get("GroupMemberControl");
				var18 = 1;
				if (var17 != null) {
					var18 = var17.getInt("modifyMode");
				}

				var19 = var6.getList("members");
				this.groupMemberUpdate(var19, var9, var18);
			}

			var17 = SDOHelper.createEntityDataObject(var3, this.schemaMgr.getTypeNsURI(var21),
					this.schemaMgr.getTypeName(var21));
			DataObject var24 = var17.createDataObject("identifier");
			var24.set("uniqueName", var6.getDataObject("identifier").getString("uniqueName"));
			var24.set("externalName", var6.getDataObject("identifier").getString("externalName"));
			var24.set("uniqueId", var6.getDataObject("identifier").getString("uniqueId"));
			var24.set("externalId", var6.getDataObject("identifier").getString("externalId"));
			var24.set("repositoryId", this.reposId);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI updateByDataGraph(DataObject inRoot)",
					WIMTraceHelper.printDataGraph(var3));
		}

		return var3;
	}

	private void updateProperties(long var1, List var3, DataObject var4, boolean var5, List var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateProperties(long entId, List rdnProp, DataObject entity)");
		}

		Object var8 = null;
		Object var9 = null;
		long var10 = -1L;
		Hashtable[] var12 = new Hashtable[7];
		Hashtable[] var13 = new Hashtable[7];
		Hashtable[] var14 = new Hashtable[7];
		Hashtable var15 = null;
		byte[] var16 = null;
		boolean var17 = false;
		boolean var18 = false;
		EClass var19 = this.schemaMgr.getEClass(var4.getType());
		EList var20 = var19.getEAllStructuralFeatures();
		ArrayList var21 = new ArrayList(var3.size());

		int var22;
		for (var22 = 0; var22 < var3.size(); ++var22) {
			String var23 = ((String) var3.get(var22)).toLowerCase();
			var21.add(var22, var23);
		}

		for (var22 = 0; var22 < var20.size(); ++var22) {
			EStructuralFeature var32 = (EStructuralFeature) var20.get(var22);
			Property var24 = this.schemaMgr.getProperty(var32);
			String var25 = this.schemaMgr.getQualifiedPropertyName(var32);
			if (var4.isSet(var24) && this.isPersistentProperty(var25)) {
				if ("ibmPrimaryEmail".equals(var25)) {
					var25 = "ibm-primaryEmail";
				} else if ("ibmJobTitle".equals(var25)) {
					var25 = "ibm-jobTitle";
				}

				DBRepositoryProperty var26 = this.propertyManager.getPropertyDefinition(var25);
				if (var26 != null) {
					Integer var27 = var26.getPropId();
					String var28 = var26.getDataType();
					short var29 = DAOHelper.getDataTypeId(var28);
					if (this.propertyManager.isCompositeProperty(var25)) {
						if (var15 == null) {
							var15 = new Hashtable();
						}

						Object[] var42 = new Object[2];
						if (this.propertyManager.isMultivaluedProperty(var25)) {
							var42[0] = var25;
							var42[1] = var4.getList(var24);
						} else {
							var42[0] = var25;
							var42[1] = var4.get(var24);
						}

						var15.put(var27, var42);
					} else if (!this.propertyManager.isMultivaluedProperty(var25)) {
						if (var25.equalsIgnoreCase("password")) {
							var16 = var4.getBytes(var25);
						} else if (var21.contains(var25.toLowerCase())) {
							if (var12[var29] == null) {
								var12[var29] = new Hashtable();
							}

							PropertyToUpdate var41 = new PropertyToUpdate();
							var41.setName(var25);
							var41.setNewValue(var4.get(var24));
							var12[var29].put(var27, var41);
							var17 = true;
							String var43 = this.dao.renameEntity(var1, (String) var41.getNewValue());
							var4.getDataObject("identifier").setString("uniqueName", var43);
							var4.getDataObject("identifier").setString("externalName", var43);
							if (var10 > 0L) {
								this.dao.renameEntity(var10, (String) var41.getNewValue());
							}
						} else {
							if (var13[var29] == null) {
								var13[var29] = new Hashtable();
							}

							var13[var29].put(var27, var4.get(var24));
							var18 = true;
						}
					} else {
						if (var13[var29] == null) {
							var13[var29] = new Hashtable();
						}

						List var30 = var4.getList(var24);
						Iterator var31 = var30.iterator();

						while (var31.hasNext()) {
							if (var31.next() == null) {
								var31.remove();
							}
						}

						if (var30.size() != 0) {
							var13[var29].put(var27, var30);
							var18 = true;
						}
					}
				}
			}
		}

		if (var17) {
			this.dao.updateProperties((short) 0, var1, var12);
		}

		if (var18) {
			this.dao.replaceProperties((short) 0, var1, var13, this.propertyManager.getMultiValuePropertyIds(),
					this.reposId, this.isDbSharedAcrossMultipleServers);
		}

		if (var6 != null && var6.size() > 0) {
			for (var22 = 0; var22 < var6.size(); ++var22) {
				Property var33 = (Property) var6.get(var22);
				String var36 = var33.getName();
				if ("ibmPrimaryEmail".equals(var36)) {
					var36 = "ibm-primaryEmail";
				} else if ("ibmJobTitle".equals(var36)) {
					var36 = "ibm-jobTitle";
				}

				DBRepositoryProperty var37 = this.propertyManager.getPropertyDefinition(var36);
				String var38 = var37.getDataType();
				short var39 = DAOHelper.getDataTypeId(var38);
				Integer var40 = var37.getPropId();
				if (var14[var39] == null) {
					var14[var39] = new Hashtable();
				}

				var14[var39].put(var40, var33);
			}

			this.dao.deleteProperties((short) 0, var1, var14, this.propertyManager.getMultiValuePropertyIds(),
					(String) null);
		}

		if (var16 != null) {
			String var34 = PasswordEncryptionUtil.generateSalt(this.saltLength);
			byte[] var35 = this.encrypt(var16, var34);
			this.dao.updateAccount(var1, var35, var34, (String) null, (String) null);
			PasswordUtil.erasePassword(var16);
		}

		if (var15 != null) {
			this.replaceCompositeProperties(var1, var15);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updateProperties(long entId, List rdnProp, DataObject entity)");
		}

	}

	private void replaceCompositeProperties(long var1, Hashtable var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "replaceCompositeProperties(long entId, Hashtable compProps)");
		}

		this.dao.deleteCompositeProperties((short) 0, var1, var3);
		this.createCompositeProperties(var1, var3, this.propertyManager.getMultiValuePropertyIds());
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "replaceCompositeProperties(long entId, Hashtable compProps)");
		}

	}

	private boolean isPersistentProperty(String var1) {
		boolean var2 = true;
		return !"identifier".equals(var1) && !"partyRoles".equals(var1) && !"parent".equals(var1)
				&& !"children".equals(var1) && !"accounts".equals(var1) && !"groups".equals(var1)
				&& !"entitlementInfo".equals(var1) && !"groups".equals(var1) && !"children".equals(var1)
				&& !"members".equals(var1);
	}

	private void groupMembershipUpdate(List var1, DBExtIdReposId var2, int var3) throws WIMException {
		if (var1 != null && var1.size() > 0) {
			ArrayList var5 = new ArrayList();

			for (int var6 = 0; var6 < var1.size(); ++var6) {
				DataObject var7 = ((DataObject) var1.get(var6)).getDataObject("identifier");
				DBEntity var8 = this.getDBEntityByIdentifier(var7);
				var5.add(new Long(var8.getEntityId()));
			}

			if (var3 == 1) {
				this.dao.assignMemberToGroups(var2, var5);
			} else if (var3 == 2) {
				this.dao.unassignMemberFromAllGroups(var2);
				this.dao.assignMemberToGroups(var2, var5);
			} else if (var3 == 3) {
				this.dao.unassignMemberFromGroups(var2, var5);
			}
		}

	}

	private void groupMemberUpdate(List var1, long var2, int var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "groupMemberUpdate(List members, long grpEntId, int mode)");
		}

		if (var1 != null && var1.size() > 0) {
			ArrayList var6 = new ArrayList();
			int var7 = 0;

			while (true) {
				if (var7 >= var1.size()) {
					if (var4 == 1) {
						this.dao.assignMembersToGroup(var6, var2);
					} else if (var4 == 2) {
						this.dao.unassignAllMembersFromGroup(var2);
						this.dao.assignMembersToGroup(var6, var2);
					} else if (var4 == 3) {
						this.dao.unassignMembersFromGroup(var6, var2, this.reposId);
					}
					break;
				}

				DataObject var8 = ((DataObject) var1.get(var7)).getDataObject("identifier");
				DBExtIdReposId var9 = null;
				DBEntity var10 = null;

				try {
					var10 = this.getDBEntityByIdentifier(var8);
				} catch (EntityNotFoundException var13) {
					var10 = null;
				}

				if (var10 != null) {
					var9 = new DBExtIdReposId();
					var9.setExtId(var10.getUniqueId());
					var9.setReposId(this.reposId);
				} else {
					String var11 = var8.getString("externalId");
					String var12 = var8.getString("repositoryId");
					if (var11 == null || var12 == null) {
						throw new EntityNotFoundException("ENTITY_NOT_FOUND",
								WIMMessageHelper.generateMsgParms(
										var8.getString("uniqueName") + "/" + var8.getString("uniqueId")),
								CLASSNAME, "groupMemberUpdate(List members, long grpEntId, int mode)");
					}

					var9 = new DBExtIdReposId();
					var9.setExtId(var11);
					var9.setReposId(var12);
				}

				if (var9 != null) {
					var6.add(var9);
				}

				++var7;
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "groupMemberUpdate(List members, long grpEntId, int mode)");
		}

	}

	private DBEntity getDBEntityByIdentifier(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getDBEntityByIdentifier(DataObject identifier)");
		}

		String var3 = var1.getString("externalId");
		String var4 = null;
		DBEntity var5 = null;
		if (var3 == null || var3.length() == 0) {
			var3 = var1.getString("uniqueId");
		}

		if (var3 != null && var3.trim().length() != 0) {
			var5 = this.dao.findDBEntityByUniqueId(var3);
		} else {
			var4 = var1.getString("externalName");
			if (var4 == null || var4.trim().length() == 0) {
				var4 = var1.getString("uniqueName");
			}

			if (var4 != null && var4.trim().length() != 0) {
				var5 = this.dao.findDBEntityByUniqueNameKey(var4);
			}
		}

		if (var5 == null) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND",
					WIMMessageHelper.generateMsgParms("[" + var3 + "/" + var4 + "]"), CLASSNAME,
					"getDBEntityByIdentifier(DataObject identifier)");
		} else {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getDBEntityByIdentifier(DataObject identifier)");
			}

			return var5;
		}
	}

	public DataObject search(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI search(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.reposId, CLASSNAME, "search(DataObject)");
		Boolean var3;
		if (this.adapterNotInitialized) {
			var3 = this.adapterNotInitialized;
			synchronized (this.adapterNotInitialized) {
				this.DBConnect(this.dbType, this.datasourceName, this.dbURL, this.dbSchema, this.dbUserId, this.dbPwd,
						this.dbDriver);
				this.adapterNotInitialized = false;
			}
		}

		var3 = null;
		String var4 = null;
		Map var5 = null;

		DataObject var32;
		try {
			Map var6 = ControlsHelper.getControlMap(var1);
			DataObject var7 = (DataObject) var6.get("SearchControl");
			if (var7 == null) {
				throw new MissingSearchControlException("MISSING_SEARCH_CONTROL", CLASSNAME, "search(DataObject)");
			}

			List var8 = var7.getList("properties");
			var4 = var7.getString("expression");
			if (var4 == null || var4.length() == 0) {
				throw new SearchControlException("MISSING_SEARCH_EXPRESSION", CLASSNAME, "search(DataObject)");
			}

			List var9 = var7.getList("searchBases");
			boolean var10 = var7.getBoolean("returnSubType");
			WIMXPathInterpreter var11 = new WIMXPathInterpreter(new StringReader(var4));
			XPathNode var12 = var11.parse((MetadataMapper) null);
			HashMap var13 = new HashMap();
			List var14 = var11.getEntityTypes();
			HashSet var15 = new HashSet();
			if (var10) {
				for (int var16 = 0; var16 < var14.size(); ++var16) {
					Set var17 = this.schemaMgr.getSubEntityTypes((String) var14.get(var16));
					if (var17 != null) {
						var15.addAll(var17);
					}

					var15.add((String) var14.get(var16));
				}
			} else {
				var15.addAll(var14);
			}

			if (var8.size() == 1) {
				String var33 = (String) var8.get(0);
				if (var33.equals("*")) {
					var8.clear();
					Iterator var35 = var15.iterator();

					while (var35.hasNext()) {
						Set var18 = this.propertyManager.getSupportedAttributes((String) var35.next());
						if (var18 != null) {
							var8.addAll(var18);
						}
					}
				}
			}

			StringBuffer var34 = new StringBuffer(256);
			boolean[] var36 = new boolean[DAOHelper.types.length];
			StringBuffer var37 = new StringBuffer(256);
			ArrayList var19 = new ArrayList();

			for (int var20 = 0; var20 < var8.size(); ++var20) {
				String var21 = (String) var8.get(var20);
				DBRepositoryProperty var22 = this.propertyManager.getPropertyDefinition(var21);
				if (var22 != null) {
					var19.add(var22);
				} else if (var21.equals("principalName") && this.loginProperties != null
						&& this.loginProperties.size() > 0) {
					var22 = this.propertyManager.getPropertyDefinition((String) this.loginProperties.get(0));
					if (var22 != null) {
						var19.add(var22);
					}
				}
			}

			boolean var38 = false;
			if (var19 == null || var19.size() == 0) {
				var38 = true;
			}

			var32 = this.schemaMgr.createRootDataObject();
			Iterator var39 = null;
			boolean var40 = false;
			String var23 = null;
			String var24 = null;
			if (var12 != null) {
				var39 = var12.getPropertyNodes(var13);
			}

			String var26;
			if (var39 != null) {
				while (var39.hasNext()) {
					PropertyNode var25 = (PropertyNode) var39.next();
					var26 = var25.getName();
					if (var26.equals("principalName")) {
						if (var13.size() > 1) {
							throw new SearchControlException("CANNOT_SEARCH_PRINCIPAL_NAME_WITH_OTHER_PROPS", CLASSNAME,
									"search(DataObject)");
						}

						var40 = true;
						var23 = (String) var25.getValue();
						var24 = var25.getOperator();
					}
				}
			}

			if (var40) {
				String var41 = LoginHelper.getContextProperty(var1, "allowDNPrincipalNameAsLiteral");
				this.ignoreDNBaseSearch = var41.equalsIgnoreCase("true");
				var5 = this.searchByPrincipalName(var15, var23, var24, var9, var19, var32, var36, var34, var37);
			} else {
				ArrayList var42 = new ArrayList();
				var26 = this.buildSearchConditionWhereClause(var15, var12, var42, var9);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "search(DataObject)",
							"Search Condition WHERE: " + WIMTraceHelper.printObjectArray(new Object[]{var26}));
				}

				StringBuffer var27 = new StringBuffer();
				int var28 = this.searchString(var27, var26, var42, var19, var32, var36, var34, var37);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "search(DataObject)",
							"Search SQL " + WIMTraceHelper.printObjectArray(new Object[]{var27.toString()}));
				}

				var5 = this.dao.search(var27.toString(), var42, var38, var32, this.reposId, var28);
			}

			List var43 = var32.getList("entities");
			if ((var34 != null || var37 != null) && var43.size() > 0) {
				var26 = DAOHelper.buildEntityIdSQL(var5);
				if (var34.length() > 0) {
					this.dao.getCompositeProperties(var5, var34.toString(), var36, var26, true);
				}

				if (var37.length() > 0) {
					this.dao.getObjectProperties(var5, var37.toString(), var26, true);
				}
			}

			this.setPrincipleName(var32, var8);
		} catch (ParseException var30) {
			throw new SearchControlException("INVALID_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var4),
					CLASSNAME, "search(DataObject)", var30);
		} catch (TokenMgrError var31) {
			throw new SearchControlException("INVALID_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var4),
					CLASSNAME, "search(DataObject)", var31);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI search(DataObject)", WIMTraceHelper.printDataObject(var32));
		}

		return var32;
	}

	private void setPrincipleName(DataObject var1, List var2) {
		if (var2 != null && var2.contains("principalName")) {
			List var3 = var1.getList("entities");

			for (int var4 = 0; var4 < var3.size(); ++var4) {
				DataObject var5 = (DataObject) var3.get(var4);
				Type var6 = var5.getType();
				String var7 = this.schemaMgr.getQualifiedTypeName(var6);
				if (this.loginProperties != null && this.loginProperties.size() > 0) {
					String var8 = (String) this.loginProperties.get(0);
					Property var9 = this.schemaMgr.getProperty(var6, var8);
					if (var9 != null) {
						if (this.schemaMgr.isSuperType("LoginAccount", var7)) {
							String var10 = var5.getString(var9);
							if (var10 != null) {
								var5.setString("principalName", var10);
							}
						}

						if (!var2.contains(var8)) {
							var5.unset(var9);
						}
					}
				}
			}
		}

	}

	private String getRDNValue(String var1) {
		String var2 = null;
		if (var1 != null) {
			boolean var4 = false;
			int var5 = 0;
			boolean var6 = false;

			while (!var4) {
				var5 = var1.indexOf(",");
				int var8 = var1.indexOf("\\");
				if (var8 == var5 - 1) {
					var1.substring(var5);
				} else {
					var4 = true;
				}
			}

			String var3 = var1.substring(0, var5);
			int var7 = var3.indexOf("=");
			var2 = var3.substring(var7 + 1);
		}

		return var2;
	}

	private String buildUniqueIdSQL(List var1) {
		StringBuffer var2 = new StringBuffer(256);
		DataObject var3 = ((DataObject) var1.get(0)).getDataObject("identifier");
		String var4 = var3.getString("externalId");
		var2.append(this.dao.getQuerySet().SINGLE_QUOTE);
		var2.append(DAOHelper.formatValueForDB(var4));
		var2.append(this.dao.getQuerySet().SINGLE_QUOTE);

		for (int var5 = 1; var5 < var1.size(); ++var5) {
			var2.append(this.dao.getQuerySet().COMMA);
			var3 = ((DataObject) var1.get(var5)).getDataObject("identifier");
			var4 = var3.getString("externalId");
			var2.append(this.dao.getQuerySet().SINGLE_QUOTE);
			var2.append(DAOHelper.formatValueForDB(var4));
			var2.append(this.dao.getQuerySet().SINGLE_QUOTE);
		}

		return var2.toString();
	}

	private int searchString(StringBuffer var1, String var2, List var3, List var4, DataObject var5, boolean[] var6,
			StringBuffer var7, StringBuffer var8) throws WIMException {
		String var10 = "http://www.ibm.com/websphere/wim";
		int var11 = 1;
		int var12 = 1;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"searchString(StringBuffer sql, String conditionWhere, List parameters, List returnPropDefs, DataObject returnRT)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3, var4, var5, var7, var8}));
		}

		if (var4 != null && var4.size() != 0) {
			DBRepositoryProperty var13 = null;
			StringBuffer var14 = null;
			StringBuffer var15 = null;
			StringBuffer var16 = null;
			StringBuffer var17 = null;
			StringBuffer var18 = null;
			StringBuffer var19 = null;
			boolean var20 = false;

			for (int var21 = 0; var21 < var4.size(); ++var21) {
				var13 = (DBRepositoryProperty) var4.get(var21);
				if (var13.getParentCompositeName() != null && trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME,
							"searchString(StringBuffer sql, String conditionWhere, List parameters, List returnPropDefs, DataObject returnRT)",
							"A component property '" + var13.getName()
									+ "' that is part of a composite property was specified stand alone.");
				}

				if (!var13.isComposite()) {
					String var24 = var13.getDataType();
					short var23 = DAOHelper.getDataTypeId(var24);
					switch (var23) {
						case 0 :
							if (var14 == null) {
								var14 = new StringBuffer(256);
								++var11;
								var14.append(var13.getPropId());
							} else {
								var14.append(this.dao.getQuerySet().COMMA);
								var14.append(var13.getPropId());
							}
							break;
						case 1 :
							if (var17 == null) {
								var17 = new StringBuffer(256);
								++var11;
								var17.append(var13.getPropId());
							} else {
								var17.append(this.dao.getQuerySet().COMMA);
								var17.append(var13.getPropId());
							}
							break;
						case 2 :
							if (var16 == null) {
								var16 = new StringBuffer(256);
								++var11;
								var16.append(var13.getPropId());
							} else {
								var16.append(this.dao.getQuerySet().COMMA);
								var16.append(var13.getPropId());
							}
							break;
						case 3 :
							if (var15 == null) {
								var15 = new StringBuffer(256);
								++var11;
								var15.append(var13.getPropId());
							} else {
								var15.append(this.dao.getQuerySet().COMMA);
								var15.append(var13.getPropId());
							}
							break;
						case 4 :
							if (var18 == null) {
								var18 = new StringBuffer(256);
								++var11;
								var18.append(var13.getPropId());
							} else {
								var18.append(this.dao.getQuerySet().COMMA);
								var18.append(var13.getPropId());
							}
							break;
						case 5 :
							if (var19 == null) {
								var19 = new StringBuffer(256);
								++var11;
								var19.append(var13.getPropId());
							} else {
								var19.append(this.dao.getQuerySet().COMMA);
								var19.append(var13.getPropId());
							}
							break;
						case 6 :
							if (var8.length() == 0) {
								++var11;
								var8.append(var13.getPropId());
							} else {
								var8.append(this.dao.getQuerySet().COMMA);
								var8.append(var13.getPropId());
							}
							break;
						default :
							throw new WIMApplicationException("INVALID_PROPERTY_DATA_TYPE",
									WIMMessageHelper.generateMsgParms(var13.getDataType()), CLASSNAME,
									"searchString(StringBuffer sql, String conditionWhere, List parameters, List returnPropDefs, DataObject returnRT)");
					}
				} else {
					if (!var20) {
						for (int var22 = 0; var22 < DAOHelper.types.length; ++var22) {
							var6[var22] = false;
						}

						var20 = true;
						var7.append(var13.getPropId());
					} else {
						var7.append(this.dao.getQuerySet().COMMA_AND_SPACE);
						var7.append(var13.getPropId());
					}

					this.appendCompositeProperty(var13, var7, var6);
				}
			}

			var1.ensureCapacity((var2.length() + 512) * var11);
			var1.append(this.dao.getQuerySet().findDBEntityGeneral);
			var1.append(this.dao.getQuerySet().AND);
			var1.append(var2);
			if (var14 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findStringPropertyForEntities);
				var1.append(this.dao.getQuerySet().findDBPropertyIdIn);
				var1.append(var14);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var15 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findIntegerPropertyForEntities);
				var1.append(this.dao.getQuerySet().findDBPropertyIdIn);
				var1.append(var15);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var16 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findDoublePropertyForEntities);
				var1.append(this.dao.getQuerySet().findDBPropertyIdIn);
				var1.append(var16);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var17 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findLongPropertyForEntities);
				var1.append(this.dao.getQuerySet().findDBPropertyIdIn);
				var1.append(var17);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var18 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findTimestampPropertyForEntities);
				var1.append(this.dao.getQuerySet().findDBPropertyIdIn);
				var1.append(var18);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var19 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findReferencePropertyForEntities);
				var1.append(this.dao.getQuerySet().findDBPropertyIdIn);
				var1.append(var19);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			var1.append(this.dao.getQuerySet().findSpecificPropertyForEntitiesOrderBy);
		} else {
			var1.ensureCapacity(256 + var2.length());
			var1.append(this.dao.getQuerySet().searchDBNoResultPropertyWhere);
			var1.append(var2);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"searchString(StringBuffer sql, String conditionWhere, List parameters, List returnPropDefs, DataObject returnRT)",
					WIMTraceHelper.printObjectArray(new Object[]{new Integer(var12)}));
		}

		return var12;
	}

	private String buildSearchByPrincipalNameConditionWhereClause(Set var1, StringBuffer var2, StringBuffer var3,
			List var4) throws WIMApplicationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"buildSearchByPrincipalNameConditionWhereClause(Set entTypes, StringBuffer fromClause, StringBuffer whereClause, List parameters, List searchBases)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3, var4}));
		}

		StringBuffer var6 = new StringBuffer(var2.length() + var3.length() + 128);
		var6.append(this.dao.getQuerySet().searchDBEntitySubSelect);
		var6.append(var2);
		var6.append(var3);
		var6.append(this.dao.getQuerySet().AND);
		var6.append(this.dao.getQuerySet().LEFT_BRACKET);
		Iterator var7 = var1.iterator();
		String var8;
		if (var7.hasNext()) {
			var6.append(this.dao.getQuerySet().searchDBEntityTypeCondition);
			var8 = (String) var7.next();
			var6.append(var8);
			var6.append(this.dao.getQuerySet().SINGLE_QUOTE);
		}

		while (var7.hasNext()) {
			var6.append(this.dao.getQuerySet().OR);
			var6.append(this.dao.getQuerySet().searchDBEntityTypeCondition);
			var8 = (String) var7.next();
			var6.append(var8);
			var6.append(this.dao.getQuerySet().SINGLE_QUOTE);
		}

		var6.append(this.dao.getQuerySet().RIGHT_BRACKET);
		if (var4 != null && var4.size() > 0) {
			QuerySet var15 = this.dao.getQuerySet();
			StringBuffer var9 = new StringBuffer();
			boolean var10 = false;
			var9.append(var15.AND);
			var9.append(var15.LEFT_BRACKET);

			for (int var11 = 0; var11 < var4.size(); ++var11) {
				int var12 = var15.SEARCH_BASE_EXPRESSION.indexOf(63);
				if (var10) {
					var9.append(var15.OR);
				}

				StringBuffer var13 = new StringBuffer(var15.SEARCH_BASE_EXPRESSION);
				String var14 = (String) var4.get(var11);
				var13.replace(var12, var12 + 1, UniqueNameHelper.formatUniqueName(var14).toLowerCase());
				var9.append(var13);
				var10 = true;
			}

			var9.append(var15.RIGHT_BRACKET);
			var6.append(var9);
		}

		var6.append(this.dao.getQuerySet().RIGHT_BRACKET);
		var8 = var6.toString();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"buildSearchByPrincipalNameConditionWhereClause(Set entTypes, StringBuffer fromClause, StringBuffer whereClause, List parameters, List searchBases)",
					WIMTraceHelper.printObjectArray(new Object[]{var8}));
		}

		return var8;
	}

	private Map searchByPrincipalName(Set var1, String var2, String var3, List var4, List var5, DataObject var6,
			boolean[] var7, StringBuffer var8, StringBuffer var9) throws WIMException {
		StringBuffer var11 = new StringBuffer(256);
		StringBuffer var12 = new StringBuffer(256);
		ArrayList var13 = new ArrayList();
		Map var14 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"searchByPrincipalName(Set entTypes, String value, String operator, List searchBases, List props, DataObject returnRT, boolean[] compositeTypes, StringBuffer compositeQuery, StringBuffer objectQuery)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3, var4}));
		}

		if (!this.ignoreDNBaseSearch && UniqueNameHelper.getValidUniqueName(var2) != null) {
			var12.append(this.dao.getQuerySet().searchFromDBEntityAndDBTableStringValue);
			var11.append(this.dao.getQuerySet().WHERE);
			var11.append(this.dao.getQuerySet().UNIQUE_NAME_KEY);
			if (var3.equals("=") && var2 instanceof String && var2.indexOf(42) >= 0) {
				var3 = "LIKE";
				var2 = var2.replace('*', '%');
			}

			byte var25 = 0;
			var3 = this.dao.getOperator(var3, var25);
			var11.append(var3 + " ");
			var11.append("?");
			SearchParameter var27 = new SearchParameter(var25, (Integer) null, var2.toLowerCase());
			var13.add(var27);
		} else if (this.loginProperties != null && this.loginProperties.size() > 0) {
			var12.append(this.dao.getQuerySet().searchFromDBEntity);
			var11.append(this.dao.getQuerySet().searchWhere1Equals1);
			var11.append(this.dao.getQuerySet().AND);
			if (this.loginProperties != null && this.loginProperties.size() > 0) {
				var11.append(this.dao.getQuerySet().LEFT_BRACKET);
			}

			short var15 = 0;

			for (int var16 = 0; this.loginProperties != null && var16 < this.loginProperties.size(); ++var16) {
				StringBuffer var17 = new StringBuffer();
				StringBuffer var18 = new StringBuffer();
				++var15;
				var17.append("S" + var15);
				DBRepositoryProperty var19 = this.propertyManager
						.getPropertyDefinition((String) this.loginProperties.get(var16));
				if (var19 == null) {
					throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED",
							WIMMessageHelper.generateMsgParms(this.loginProperties.get(var16)), CLASSNAME,
							"searchByPrincipalName(Set entTypes, String value, String operator, List searchBases, List props, DataObject returnRT, boolean[] compositeTypes, StringBuffer compositeQuery, StringBuffer objectQuery)");
				}

				if (var19.isCaseSensitive()) {
					var18.append(var17 + this.dao.getQuerySet().dotColumnValue);
				} else {
					var18.append(var17 + this.dao.getQuerySet().dotColumnValueKey);
				}

				if (var12.toString().indexOf(" " + var17) == -1) {
					var12.append(this.dao.getQuerySet().COMMA);
					var12.append(this.dao.getQuerySet().dbTableStringValue);
					var12.append(var17);
				}

				String var20 = var19.getDataType();
				short var21 = DAOHelper.getDataTypeId(var20);
				Integer var22 = var19.getPropId();
				if (var16 > 0) {
					var11.append(this.dao.getQuerySet().OR);
				}

				var11.append(this.dao.getQuerySet().LEFT_BRACKET);
				var11.append(var17);
				var11.append(this.dao.getQuerySet().searchDBEntityJoinCondition);
				var11.append(var17);
				var11.append(this.dao.getQuerySet().searchPropertyIdCondition);
				SearchParameter var23 = new SearchParameter((short) 3, var22);
				if (var13 == null) {
					var13 = new ArrayList();
				}

				var13.add(var23);
				var11.append(this.dao.getQuerySet().LEFT_BRACKET);
				var11.append(var18 + " ");
				if (var3.equals("=") && var2 instanceof String && var2.indexOf(42) >= 0) {
					var3 = "LIKE";
					var2 = var2.replace('*', '%');
					var2 = var2.replace("\\%", "*");
				}

				var3 = this.dao.getOperator(var3, var21);
				var11.append(var3 + " ");
				var11.append("?");
				var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var23 = new SearchParameter(var21, var22, var2);
				if (!var19.isCaseSensitive()) {
					String var24 = (String) var23.paramValue;
					if (var24 != null) {
						var23.paramValue = var24.toLowerCase();
					}
				}

				var13.add(var23);
			}

			if (this.loginProperties != null && this.loginProperties.size() > 0) {
				var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
			}
		}

		if (var12.length() > 0 && var11.length() > 0) {
			String var26 = this.buildSearchByPrincipalNameConditionWhereClause(var1, var12, var11, var4);
			StringBuffer var28 = new StringBuffer();
			boolean var29 = false;
			if (var5 == null || var5.size() == 0) {
				var29 = true;
			}

			int var30 = this.searchString(var28, var26, var13, var5, var6, var7, var8, var9);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME,
						"searchByPrincipalName(Set entTypes, String value, String operator, List searchBases, List props, DataObject returnRT, boolean[] compositeTypes, StringBuffer compositeQuery, StringBuffer objectQuery)",
						"Search SQL " + WIMTraceHelper.printObjectArray(new Object[]{var28.toString()}));
			}

			var14 = this.dao.search(var28.toString(), var13, var29, var6, this.reposId, var30);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"searchByPrincipalName(Set entTypes, String value, String operator, List searchBases, List props, DataObject returnRT, boolean[] compositeTypes, StringBuffer compositeQuery, StringBuffer objectQuery)");
		}

		return var14;
	}

	private String buildSearchConditionWhereClause(Set var1, XPathNode var2, List var3, List var4) throws WIMException {
		StringBuffer var6 = null;
		StringBuffer var7 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "String buildSearchConditionWhereClause(Set, XPathNode, List, List)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3, var4}));
		}

		ArrayList var8 = new ArrayList();
		var8.addAll(var1);
		DBXPathTranslateHelper var9 = new DBXPathTranslateHelper(var8, var2, var3, this.propertyManager, this.dao);
		StringBuffer var10 = new StringBuffer();
		var9.genSearchString(var10, var2);
		var6 = var9.getWhereClause();
		var7 = var9.getFromClause();
		StringBuffer var11 = new StringBuffer(var7.length() + var6.length() + 128);
		var11.append(this.dao.getQuerySet().searchDBEntitySubSelect);
		var11.append(var7);
		var11.append(var6);
		var11.append(this.dao.getQuerySet().AND);
		var11.append(this.dao.getQuerySet().LEFT_BRACKET);
		Iterator var12 = var1.iterator();
		String var13;
		if (var12.hasNext()) {
			var11.append(this.dao.getQuerySet().searchDBEntityTypeCondition);
			var13 = (String) var12.next();
			var11.append(var13);
			var11.append(this.dao.getQuerySet().SINGLE_QUOTE);
		}

		while (var12.hasNext()) {
			var11.append(this.dao.getQuerySet().OR);
			var11.append(this.dao.getQuerySet().searchDBEntityTypeCondition);
			var13 = (String) var12.next();
			var11.append(var13);
			var11.append(this.dao.getQuerySet().SINGLE_QUOTE);
		}

		var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
		if (var4 != null && var4.size() > 0) {
			QuerySet var20 = this.dao.getQuerySet();
			StringBuffer var14 = new StringBuffer();
			boolean var15 = false;
			var14.append(var20.AND);
			var14.append(var20.LEFT_BRACKET);

			for (int var16 = 0; var16 < var4.size(); ++var16) {
				int var17 = var20.SEARCH_BASE_EXPRESSION.indexOf(63);
				if (var15) {
					var14.append(var20.OR);
				}

				StringBuffer var18 = new StringBuffer(var20.SEARCH_BASE_EXPRESSION);
				String var19 = (String) var4.get(var16);
				var18.replace(var17, var17 + 1, UniqueNameHelper.formatUniqueName(var19).toLowerCase());
				var14.append(var18);
				var15 = true;
			}

			var14.append(var20.RIGHT_BRACKET);
			var11.append(var14);
		}

		var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
		var13 = var11.toString();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "String buildSearchConditionWhereClause(Set, XPathNode, List, List)",
					WIMTraceHelper.printObjectArray(new Object[]{var13, var3}));
		}

		return var13;
	}

	public DataObject login(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI login(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.reposId, CLASSNAME, "login(DataObject)");
		DataObject var3 = this.schemaMgr.createRootDataObject();
		List var4 = var1.getList("entities");
		DataObject var5 = (DataObject) var4.get(0);
		Map var6 = ControlsHelper.getControlMap(var1);
		DataObject var7 = (DataObject) var6.get("LoginControl");
		String var8 = var5.getString("principalName");
		byte[] var9 = var5.getBytes("password");
		if (var8 != null && var8.trim().length() != 0) {
			if (var9 != null && var9.length != 0) {
				List var10 = null;
				if (var7 != null) {
					var10 = var7.getList("searchBases");
				}

				HashSet var11 = new HashSet();
				String var12 = this.schemaMgr.getQualifiedTypeName(var5.getType());
				var11.add(var12);
				var11.addAll(this.schemaMgr.getSubEntityTypes(var12));
				DataObject var13 = this.schemaMgr.createRootDataObject();
				String var14 = var8.replace("*", "\\*");
				var14 = var14.replace("''", "'");
				Map var15 = this.searchByPrincipalName(var11, var14, "=", var10, (List) null, var13, (boolean[]) null,
						(StringBuffer) null, (StringBuffer) null);
				if (var15 != null && var15.size() != 0) {
					if (var15.size() > 1) {
						throw new PasswordCheckFailedException("MULTIPLE_PRINCIPALS_FOUND",
								WIMMessageHelper.generateMsgParms(var8, this.reposId), CLASSNAME, "login(DataObject)");
					} else {
						DataObject var16 = var3.createDataObject("entities", "http://www.ibm.com/websphere/wim",
								"PersonAccount");
						Set var17 = var15.keySet();
						Iterator var18 = var17.iterator();
						long var19 = (Long) var18.next();
						DBAccount var21 = this.dao.getDBAccountByEntId(var19);
						boolean var22 = false;
						byte[] var23 = var21.getPassword();
						String var24 = var21.getSalt();
						String var25 = null;
						if (var24 != null && var24.trim().length() != 0) {
							var25 = PasswordEncryptionUtil
									.hash(PasswordEncryptionUtil.getSaltedTextBytes(var24.trim(), var9)).trim();
						} else {
							var25 = PasswordEncryptionUtil.hash(var9).trim();
						}

						Object var26 = null;
						String var27 = PasswordEncryptionUtil.decrypt(this.encryptionKey.trim(), (String) null).trim();
						byte[] var34 = PasswordEncryptionUtil
								.formatPassword(PasswordEncryptionUtil.encrypt(var25, var27).trim().getBytes());
						Object var28 = null;
						byte[] var35 = PasswordEncryptionUtil.formatPassword(var23);
						boolean var29;
						if (var35 != null && var34 != null && var35.length == var34.length) {
							var29 = false;

							int var36;
							for (var36 = 0; var36 < var35.length && var35[var36] == var34[var36]; ++var36) {
								;
							}

							if (var36 == var35.length) {
								var22 = true;
							}
						}

						if (!var22) {
							throw new PasswordCheckFailedException("PASSWORD_MATCH_FAILED_FOR_PRINCIPALNAME",
									WIMMessageHelper.generateMsgParms(var8), CLASSNAME, "login(DataObject)");
						} else {
							var29 = false;
							DataObject var30 = (DataObject) var15.get(new Long(var19));
							DataObject var31 = var30.getDataObject("identifier");
							var16.setDataObject("identifier", var31);
							if (var7 != null) {
								List var32 = var7.getList("properties");
								if (var32.contains("principalName")) {
									var32.remove("principalName");
									var29 = true;
								}

								String[] var33 = new String[0];
								var33 = (String[]) ((String[]) var32.toArray(var33));
								this.getProperties(var16, var19, var33);
							}

							if (var29) {
								var16.setString("principalName", var14);
							}

							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.exiting(CLASSNAME, "WIM_SPI login(DataObject)",
										WIMTraceHelper.printDataObject(var3));
							}

							return var3;
						}
					}
				} else {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "WIM_SPI login(DataObject)", WIMTraceHelper.printDataObject(var3));
					}

					return var3;
				}
			} else {
				throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PASSWORD", CLASSNAME, "login(DataObject)");
			}
		} else {
			throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PRINCIPAL_NAME", CLASSNAME, "login(DataObject)");
		}
	}

	private void createProperties(long var1, DataObject var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createProperties(long mbrId, DataObject entity)");
		}

		String var5 = this.schemaMgr.getQualifiedTypeName(var3.getType());
		Hashtable[] var6 = new Hashtable[7];
		Hashtable var7 = null;
		byte[] var8 = null;
		Object var9 = this.propertyManager.getMandatoryAttributes(var5);
		if (var9 == null) {
			var9 = new HashSet();
		}

		Iterator var10 = ((Set) var9).iterator();

		while (var10.hasNext()) {
			String var11 = (String) var10.next();
			Property var12 = this.schemaMgr.getProperty(var5, var11);
			if (!var3.isSet(var12)) {
				Object[] var23 = new Object[]{var11};
				throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY", var23, CLASSNAME,
						"createProperties(long mbrId, DataObject entity)");
			}

			DBRepositoryProperty var13 = this.propertyManager.getPropertyDefinition(var11);
			Integer var14 = var13.getPropId();
			String var15 = var13.getDataType();
			short var16 = DAOHelper.getDataTypeId(var15);
			if (this.propertyManager.isCompositeProperty(var11)) {
				if (var7 == null) {
					var7 = new Hashtable();
				}

				Object[] var17;
				if (this.propertyManager.isMultivaluedProperty(var11)) {
					var17 = new Object[]{var11, var3.getList(var12)};
					var7.put(var14, var17);
				} else {
					var17 = new Object[]{var11, var3.get(var12)};
					var7.put(var14, var17);
				}
			} else {
				if (var6[var16] == null) {
					var6[var16] = new Hashtable();
				}

				if (this.propertyManager.isMultivaluedProperty(var11)) {
					var6[var16].put(var14, var3.getList(var12));
				} else if (var11.equalsIgnoreCase("password")) {
					var8 = var3.getBytes(var11);
				} else {
					var6[var16].put(var14, var3.get(var12));
				}
			}
		}

		Set var21 = this.propertyManager.getSupportedAttributes(var5);
		Iterator var22 = var21.iterator();

		String var24;
		while (var22.hasNext()) {
			var24 = (String) var22.next();
			trcLogger.log(Level.FINEST, "Database property name is '" + var24 + "' Type is " + var5);
			Property var25 = this.schemaMgr.getProperty(var5, var24);
			trcLogger.log(Level.FINEST, "SchemaManager property is: " + var25);

			try {
				if (var25 != null && var3.isSet(var25) && !((Set) var9).contains(var25)) {
					DBRepositoryProperty var27 = this.propertyManager.getPropertyDefinition(var24);
					Integer var28 = var27.getPropId();
					String var29 = var27.getDataType();
					short var18 = DAOHelper.getDataTypeId(var29);
					if (this.propertyManager.isCompositeProperty(var24)) {
						if (var7 == null) {
							var7 = new Hashtable();
						}

						Object[] var19;
						if (this.propertyManager.isMultivaluedProperty(var24)) {
							var19 = new Object[]{var24, var3.getList(var25)};
							var7.put(var28, var19);
						} else {
							var19 = new Object[]{var24, var3.get(var25)};
							var7.put(var28, var19);
						}
					} else {
						if (var6[var18] == null) {
							var6[var18] = new Hashtable();
						}

						if (this.propertyManager.isMultivaluedProperty(var24)) {
							var6[var18].put(var28, var3.getList(var25));
						} else if (var24.equalsIgnoreCase("password")) {
							var8 = var3.getBytes(var24);
						} else {
							var6[var18].put(var28, var3.get(var25));
						}
					}
				}
			} catch (Exception var20) {
				throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var20.getMessage()),
						CLASSNAME, "createProperties(long mbrId, DataObject entity)", var20);
			}
		}

		if (!this.isDbSharedAcrossMultipleServers) {
			this.dao.createProperties((short) 0, var1, var6, (Long) null,
					this.propertyManager.getMultiValuePropertyIds(), this.reposId);
		} else {
			this.dao.createProperties1((short) 0, var1, var6, (Long) null,
					this.propertyManager.getMultiValuePropertyIds(), this.reposId);
		}

		if (var7 != null && var7.size() != 0) {
			this.createCompositeProperties(var1, var7, this.propertyManager.getMultiValuePropertyIds());
		}

		if (var8 != null && this.schemaMgr.isSuperType("PersonAccount", var5)) {
			var24 = PasswordEncryptionUtil.generateSalt(this.saltLength);
			byte[] var26 = this.encrypt(var8, var24);
			this.dao.createAccount(var1, var26, var24, (String) null, (String) null);
			PasswordUtil.erasePassword(var8);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createProperties(long mbrId, DataObject entity)");
		}

	}

	private void createCompositeProperties(long var1, Hashtable var3, Set var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createCompositeProperties(short schema, long mbrId, Hashtable compAttrs, Set multiValProps)");
		}

		Set var6 = var3.keySet();

		Integer var8;
		String var10;
		Object var11;
		for (Iterator var7 = var6.iterator(); var7.hasNext(); this.createOneCompositeProperty(var8, var10, var1,
				(List) var11, (Long) null)) {
			var8 = (Integer) var7.next();
			Object[] var9 = (Object[]) ((Object[]) var3.get(var8));
			var10 = (String) var9[0];
			var11 = null;
			if (var4.contains(var8)) {
				var11 = (List) var9[1];
			} else {
				var11 = new ArrayList();
				((List) var11).add(var9[1]);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"createCompositeProperties(short schema, long mbrId, Hashtable compAttrs, Set multiValProps)");
		}

	}

	private void createOneCompositeProperty(Integer var1, String var2, long var3, List var5, Long var6)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createOneCompositeProperty");
		}

		for (int var8 = 0; var8 < var5.size(); ++var8) {
			Hashtable[] var9 = new Hashtable[7];
			Long var10 = this.dao.createCompositePropValue((short) 0, var1, var3, (Long) null, (String) null);
			DataObject var11 = (DataObject) var5.get(var8);
			Set var12 = (Set) this.propertyManager.getCompositeProperties().get(var2);
			Set var13 = this.propertyManager.getRequiredComponentProperties(var2);
			Iterator var14 = var12.iterator();

			while (var14.hasNext()) {
				String var15 = (String) var14.next();
				String var16 = DAOHelper.resumeComponentName(var15, var2);
				if (var11.isSet(var16)) {
					DBRepositoryProperty var17 = this.propertyManager.getPropertyDefinition(var15);
					Integer var18 = var17.getPropId();
					String var19 = var17.getDataType();
					short var20 = DAOHelper.getDataTypeId(var19);
					if (this.propertyManager.isCompositeProperty(var15)) {
						Object var21 = null;
						if (this.propertyManager.isMultivaluedProperty(var15)) {
							var21 = var11.getList(var16);
						} else {
							var21 = new ArrayList();
							((List) var21).add(var11.get(var16));
						}

						this.createOneCompositeProperty(var18, var15, var3, (List) var21, var10);
					} else {
						if (var9[var20] == null) {
							var9[var20] = new Hashtable();
						}

						if (this.propertyManager.isMultivaluedProperty(var15)) {
							var9[var20].put(var18, var11.getList(var16));
						} else {
							var9[var20].put(var18, var11.get(var16));
						}
					}
				} else if (var13.contains(var15)) {
					Object[] var22 = new Object[]{var16};
					throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY", var22, CLASSNAME,
							"createOneCompositeProperty");
				}
			}

			if (!this.isDbSharedAcrossMultipleServers) {
				this.dao.createProperties((short) 0, var3, var9, var10, this.propertyManager.getMultiValuePropertyIds(),
						this.reposId);
			} else {
				this.dao.createProperties1((short) 0, var3, var9, var10,
						this.propertyManager.getMultiValuePropertyIds(), this.reposId);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createOneCompositeProperty");
		}

	}

	private byte[] encrypt(byte[] var1, String var2) throws WIMSystemException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "encrypt");
		}

		String var4 = null;
		if (var2 != null && var2.trim().length() != 0) {
			var4 = PasswordEncryptionUtil.hash(PasswordEncryptionUtil.getSaltedTextBytes(var2.trim(), var1)).trim();
		} else {
			var4 = PasswordEncryptionUtil.hash(var1).trim();
		}

		Object var5 = null;
		byte[] var6 = PasswordEncryptionUtil
				.formatPassword(PasswordEncryptionUtil.encrypt(var4, this.ENCRYPTION_KEY).trim().getBytes());
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "encrypt");
		}

		return var6;
	}

	public DataObject getSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI getSchema(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.reposId, CLASSNAME, "getSchema(DataObject)");
		DataObject var3 = this.schemaMgr.createRootDataObject();
		Map var4 = ControlsHelper.getControlMap(var1);
		if (this.adapterNotInitialized) {
			return var3;
		} else {
			DataObject var5 = (DataObject) var4.get("DataTypeControl");
			DataObject var6 = (DataObject) var4.get("PropertyDefinitionControl");
			DataObject var7 = (DataObject) var4.get("EntityTypeControl");
			DataObject var8;
			if (var5 != null) {
				var8 = var3.getDataObject("schema");
				if (var8 == null) {
					var8 = var3.createDataObject("schema");
				}

				this.schemaMgr.getSupportedDataTypes(var8);
			} else {
				List var10;
				String var13;
				int var18;
				DataObject var19;
				String var20;
				String var25;
				if (var7 != null) {
					List var16 = ConfigManager.singleton().getSupportedEntityTypes();
					DataObject var17 = var3.getDataObject("schema");
					if (var17 == null) {
						var17 = var3.createDataObject("schema");
					}

					var10 = var7.getList("entityTypeNames");
					String var24;
					if (var10 != null && var10.size() != 0) {
						for (var18 = 0; var18 < var10.size(); ++var18) {
							var20 = (String) var10.get(var18);
							if (var20.startsWith("wim:")) {
								var20 = this.schemaMgr.getTypeName(var20);
							}

							if (var16.contains(var20)) {
								DataObject var22 = var17.createDataObject("entitySchema");
								var24 = this.schemaMgr.getTypeNsURI(var20);
								var25 = this.schemaMgr.getNsPrefix(var24);
								var22.set("entityName", this.schemaMgr.getTypeName(var20));
								var22.set("nsURI", var24);
								var22.set("nsPrefix", var25);
							} else if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "getSchema(DataObject)",
										"The entity type " + var20 + " is not supported in repository " + this.reposId);
							}
						}
					} else if (var16 != null && var16.size() > 0) {
						for (var18 = 0; var18 < var16.size(); ++var18) {
							var19 = var17.createDataObject("entitySchema");
							var13 = (String) var16.get(var18);
							var24 = this.schemaMgr.getTypeNsURI(var13);
							var25 = this.schemaMgr.getNsPrefix(var24);
							var19.set("entityName", this.schemaMgr.getTypeName(var13));
							var19.set("nsURI", var24);
							var19.set("nsPrefix", var25);
						}
					}
				} else if (var6 != null) {
					var8 = var3.getDataObject("schema");
					if (var8 == null) {
						var8 = var3.createDataObject("schema");
					}

					String var9 = var6.getString("entityTypeName");
					if (var9.startsWith("wim:")) {
						var9 = this.schemaMgr.getTypeName(var9);
					}

					var10 = var6.getList("propertyNames");
					if (var10 != null && var10.size() > 0) {
						for (var18 = 0; var18 < var10.size(); ++var18) {
							var20 = (String) var10.get(var18);
							if (var20.startsWith("wim:")) {
								var20 = this.schemaMgr.getTypeName(var20);
							}

							DBRepositoryProperty var21 = this.propertyManager.getPropertyDefinition(var20);
							DataObject var23;
							if (var21 == null) {
								if (!var20.equals("principalName") || this.schemaMgr.getProperty(var9, var20) == null) {
									throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
											WIMMessageHelper.generateMsgParms(var20, var9), CLASSNAME,
											"getSchema(DataObject)");
								}

								var23 = var8.createDataObject("propertySchema");
								var25 = this.schemaMgr.getTypeNsURI(var20);
								var23.setString("propertyName", this.schemaMgr.getTypeName(var20));
								var23.set("nsURI", var25);
								var23.set("nsPrefix", this.schemaMgr.getNsPrefix(var25));
								if (trcLogger.isLoggable(Level.FINER)) {
									trcLogger.logp(Level.FINER, CLASSNAME, "getSchema(DataObject)",
											"The property " + var20 + " is not defined in repository " + this.reposId);
								}
							} else {
								var23 = var8.createDataObject("propertySchema");
								DAOHelper.setPropertySchema(var21, var20, var23, var9);
							}
						}
					} else {
						Set var11 = this.propertyManager.getSupportedAttributes(var9);
						if (var11 != null) {
							Iterator var12 = var11.iterator();

							while (var12.hasNext()) {
								var13 = (String) var12.next();
								DBRepositoryProperty var14 = this.propertyManager.getPropertyDefinition(var13);
								if (var14 == null) {
									if (trcLogger.isLoggable(Level.FINER)) {
										trcLogger.logp(Level.FINER, CLASSNAME, "getSchema(DataObject)", "The property "
												+ var13 + " is not defined in repository " + this.reposId);
									}
								} else {
									DataObject var15 = var8.createDataObject("propertySchema");
									DAOHelper.setPropertySchema(var14, var13, var15, var9);
								}
							}
						}

						if (this.schemaMgr.isSuperType("PersonAccount", var9)) {
							var19 = var8.createDataObject("propertySchema");
							var19.set("propertyName", this.schemaMgr.getTypeName("principalName"));
							var13 = this.schemaMgr.getTypeNsURI("principalName");
							var19.set("nsURI", var13);
							var19.set("nsPrefix", this.schemaMgr.getNsPrefix(var13));
						}
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI getSchema(DataObject)", WIMTraceHelper.printDataObject(var3));
			}

			return var3;
		}
	}

	public DataObject createSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI createSchema(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.reposId, CLASSNAME, "createSchema(DataObject)");
		DataObject var3 = this.schemaMgr.createRootDataObject();
		DataObject var4 = var1.getDataObject("schema");
		if (var4 != null) {
			List var5 = var4.getList("entitySchema");
			String var10;
			if (var5 != null && var5.size() > 0) {
				for (int var6 = 0; var6 < var5.size(); ++var6) {
					DataObject var7 = (DataObject) var5.get(var6);
					String var8 = var7.getString("nsURI");
					String var9 = var7.getString("entityName");
					if (!var8.equals("http://www.ibm.com/websphere/wim")) {
						var9 = this.schemaMgr.getQualifiedTypeName(var8, var9);
					}

					var10 = var7.getString("parentEntityName");
					this.dao.createNewPropertyEntityRelationInDB(var9, var10, this.propertyManager);
					this.propertyManager.updatePropertyEntityRelationCache(var9, var10);
				}
			}

			List var22 = var4.getList("propertySchema");
			if (var22 != null && var22.size() > 0) {
				for (int var23 = 0; var23 < var22.size(); ++var23) {
					DataObject var24 = (DataObject) var22.get(var23);
					DBRepositoryProperty var25 = new DBRepositoryProperty();
					var10 = var24.getString("nsURI");
					String var11 = var24.getString("propertyName");
					if (!var10.equals("http://www.ibm.com/websphere/wim")) {
						var11 = this.schemaMgr.getQualifiedTypeName(var10, var11);
					}

					var25.setName(var11);
					List var12 = var24.getList("metaData");
					String var13 = var24.getString("dataType");
					DBDataType var14 = DAOHelper.getDBDataTypeFromCommonDataType(var13);
					var25.setDataType(var14.getDatatype());
					if (var14.getClassname() != null && var14.getClassname().length() != 0) {
						var25.setClassName(var14.getClassname());
					}

					var25.setMultipleValued(var24.getBoolean("multiValued"));

					String var18;
					for (int var15 = 0; var15 < var12.size(); ++var15) {
						DataObject var16 = (DataObject) var12.get(var15);
						String var17 = var16.getString("name");
						var18 = (String) ((String) var16.getList("values").get(0));
						if (var17.equals("classname")) {
							var25.setClassName(var18);
						} else if (var17.equals("applicationId")) {
							var25.setApplicationId(var18);
						} else if (var17.equals("caseExactMatch")) {
							var25.setCaseSensitive(new Boolean(var18));
						} else if (var17.equals("description")) {
							var25.setDescription(var18);
						} else if (var17.equals("isComposite")) {
							boolean var19 = new Boolean(var18);
							if (var19) {
								throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
										WIMMessageHelper.generateMsgParms(this.reposId + "|" + "isComposite"),
										CLASSNAME, "createSchema(DataObject)");
							}

							var25.setComposite(var19);
						} else if (var17.equals("multiValued")) {
							var25.setMultipleValued(new Boolean(var18));
						} else if (var17.equals("readOnly")) {
							var25.setReadOnly(new Boolean(var18));
						} else if (var17.equals("valueLength")) {
							var25.setValueLength(new Integer(var18));
						} else if (var17.equals("metaName")) {
							var25.setMetadataName(var18);
						}
					}

					if (var14.getDatatype().equals("OBJECT")
							&& (var25.getClassName() == null || var25.getClassName().length() == 0)) {
						throw new InvalidPropertyDefinitionException("INVALID_PROPERTY_DATA_TYPE",
								WIMMessageHelper.generateMsgParms(var24.getString("propertyName")), CLASSNAME,
								"createSchema(DataObject)");
					}

					if (var13.equalsIgnoreCase("STRING") && var25.getValueLength() == 0) {
						var25.setValueLength(254);
					}

					if (var25.getMetadataName() == null) {
						var25.setMetadataName("DEFAULT");
					}

					if (var25.getApplicationId() == null) {
						var25.setApplicationId("com.ibm.websphere.wim");
					}

					List var26 = var24.getList("applicableEntityTypeNames");
					HashSet var27 = new HashSet();

					for (int var28 = 0; var28 < var26.size(); ++var28) {
						var18 = (String) var26.get(var28);
						var27.add(var18);
						Set var31 = this.schemaMgr.getSubEntityTypes(var18);
						if (var31.size() != 0) {
							var27.addAll(var31);
						}
					}

					List var29 = var24.getList("requiredEntityTypeNames");
					HashSet var30 = null;
					int var32;
					if (var29 != null) {
						var30 = new HashSet();

						for (var32 = 0; var32 < var29.size(); ++var32) {
							String var20 = (String) var29.get(var32);
							if (!var26.contains(var20)) {
								throw new InvalidPropertyDefinitionException(
										"INVALID_PROPERTY_DEFINITION", WIMMessageHelper
												.generateMsgParms("requiredEntityTypeNames", var20, var25.getName()),
										CLASSNAME, "createSchema(DataObject)");
							}

							var30.add(var20);
							Set var21 = this.schemaMgr.getSubEntityTypes(var20);
							if (var21.size() != 0) {
								var30.addAll(var21);
							}
						}
					}

					var25.setApplicableEntityTypes(var27);
					var25.setRequiredEntityTypes(var30);
					var32 = this.dao.createPropertyDefinition(var25);
					var25.setPropId(new Integer(var32));
					this.propertyManager.updatePropertyCache(var25);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI createSchema(DataObject)", WIMTraceHelper.printDataObject(var3));
		}

		return var3;
	}

	private void appendCompositeProperty(DBRepositoryProperty var1, StringBuffer var2, boolean[] var3) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"appendCompositeProperty(DBRepositoryProperty propDef, StringBuffer compositeQuery, boolean[] compositeTypes)");
		}

		Set var5 = var1.getComponentPropertyNames();
		if (var5 != null) {
			Iterator var6 = var5.iterator();

			while (var6.hasNext()) {
				DBRepositoryProperty var7 = this.propertyManager.getPropertyDefinition((String) var6.next());
				if (var7.isComposite()) {
					var2.append(this.dao.getQuerySet().COMMA_AND_SPACE);
					var2.append(var7.getPropId());
					this.appendCompositeProperty(var7, var2, var3);
				} else {
					String var8 = var7.getDataType();
					short var9 = DAOHelper.getDataTypeId(var8);
					var3[var9] = true;
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"appendCompositeProperty(DBRepositoryProperty propDef, StringBuffer compositeQuery, boolean[] compositeTypes)");
		}

	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
		}

		if (var1.equals("websphere.usermanager.serviceprovider.update.db.adminidpassword")) {
			byte[] var4 = (byte[]) ((byte[]) var2.get("DYNA_CONFIG_KEY_DB_ADMIN_PASSWORD"));

			try {
				String var5 = new String(var4, "UTF-8");
				this.dao.reload(var5);
			} catch (Exception var7) {
				Object var6;
				for (var6 = var7; ((Throwable) var6).getCause() != null; var6 = ((Throwable) var6).getCause()) {
					;
				}

				throw new DynamicUpdateConfigException("REPOSITORY_CONNECTION_FAILED",
						WIMMessageHelper.generateMsgParms(this.reposId, "DYNA_CONFIG_KEY_DB_ADMIN_PASSWORD",
								var6.getClass().getName()),
						CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
			}
		} else if (var1.equals("websphere.usermanager.serviceprovider.add.baseentry")) {
			String var8 = (String) var2.get("DYNA_CONFIG_KEY_BASE_ENTRY");
			DBEntity var9 = this.dao.findDBEntityByUniqueNameKey(DAOHelper.getTruncatedUniqueName(var8));
			if (var9 == null) {
				throw new DynamicUpdateConfigException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var8),
						CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
		}

	}

	public void DBConnect(String var1, String var2, String var3, String var4, String var5, String var6, String var7)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "DBConnect", var3);
		}

		try {
			this.dao = DAOHelper.getNewDAOClass(var1, var2, var3, var4, var5, var6, var7);
			this.propertyManager = new DBPropertyCache(this.dao);
		} catch (WIMException var15) {
			throw new WIMException("REPOSITORY_INITIALIZATION_FAILED",
					WIMMessageHelper.generateMsgParms(this.reposId, var15.getMessage()), CLASSNAME, "DBConnect", var15);
		}

		if (this.loginProperties != null && this.loginProperties.size() > 0) {
			for (int var9 = 0; var9 < this.loginProperties.size(); ++var9) {
				String var10 = (String) this.loginProperties.get(var9);
				if (this.propertyManager.getPropertyDefinition(var10) == null) {
					Set var11 = this.propertyManager.getSupportedAttributes("PersonAccount");
					String var12 = null;
					if (var11 != null) {
						var12 = "[";
						Iterator var13 = var11.iterator();

						for (boolean var14 = true; var13.hasNext(); var12 = var12 + (String) var13.next()) {
							if (var14) {
								var14 = false;
							} else {
								var12 = var12 + ", ";
							}
						}

						var12 = var12 + "]";
					}

					throw new WIMConfigurationException("CONFIG_VALUE_NOT_VALID",
							WIMMessageHelper.generateMsgParms(var10, "loginProperties", var12), CLASSNAME, "DBConnect");
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "DBConnect");
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = DBAdapter.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}