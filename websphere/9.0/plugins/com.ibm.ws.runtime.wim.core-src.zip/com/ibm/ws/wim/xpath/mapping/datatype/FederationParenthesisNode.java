package com.ibm.ws.wim.xpath.mapping.datatype;

public class FederationParenthesisNode extends ParenthesisNode {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";

	public short getNodeType() {
		return 8;
	}
}