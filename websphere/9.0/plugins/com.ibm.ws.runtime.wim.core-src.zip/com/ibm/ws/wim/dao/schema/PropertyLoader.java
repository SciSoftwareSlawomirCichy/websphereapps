package com.ibm.ws.wim.dao.schema;

import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PropertyLoader {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = PropertyLoader.class.getName();
	private static final Logger trcLogger;

	public static void main(String[] var0) throws WIMSystemException {
		int var2 = var0.length;
		boolean var3 = false;
		DBLoadManager var4;
		if (var2 == 4) {
			var4 = new DBLoadManager(var0[1], var0[2], var0[3], var3);
			var4.initialize(var0[0]);
		} else if (var2 == 5) {
			var3 = new Boolean(var0[4]);
			var4 = new DBLoadManager(var0[1], var0[2], var0[3], var3);
			var4.initialize(var0[0]);
		} else if (var2 == 6) {
			var4 = new DBLoadManager(var0[1], var0[2], var0[3], var0[4], var0[5], var3);
			var4.initialize(var0[0]);
		} else {
			if (var2 != 7) {
				if (trcLogger.isLoggable(Level.INFO)) {
					trcLogger.logp(Level.INFO, CLASSNAME, "main",
							"Parameters: <filename> <dbtype> <url> <driver> <user> <password> <trace>");
				}

				throw new WIMSystemException("SYSTEM_EXCEPTION",
						WIMMessageHelper.generateMsgParms("missing parameters"), CLASSNAME, "main");
			}

			var3 = new Boolean(var0[6]);
			var4 = new DBLoadManager(var0[1], var0[2], var0[3], var0[4], var0[5], var3);
			var4.initialize(var0[0]);
		}

		if (trcLogger.isLoggable(Level.INFO)) {
			trcLogger.logp(Level.INFO, CLASSNAME, "main", "property definition file is loaded!");
		}

	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}