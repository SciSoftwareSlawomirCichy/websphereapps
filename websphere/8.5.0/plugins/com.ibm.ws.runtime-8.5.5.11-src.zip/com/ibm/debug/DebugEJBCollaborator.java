package com.ibm.debug;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;
import com.ibm.ws.ejbcontainer.EJBRequestCollaborator;
import com.ibm.ws.ejbcontainer.EJBRequestData;

public class DebugEJBCollaborator implements EJBRequestCollaborator<Void> {
	private static final TraceComponent tc = Tr.register(DebugEJBCollaborator.class.getName(), "DebugComponent",
			(String) null);

	public Void preInvoke(EJBRequestData request) throws CSIException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "preInvoke", request);
		}

		EJBMethodMetaData info = request.getEJBMethodMetaData();
		String methodName = info.getMethodName();
		String className = info.getEJBComponentMetaData().getBeanClassName();
		String jdiSignature = info.getMethodDescriptor();
		if (!info.getEJBMethodInterface().isHome()) {
			DebugBreakpoints.debugEJBBreakpoint(className, methodName, jdiSignature);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "preInvoke");
		}

		return null;
	}

	public void postInvoke(EJBRequestData request, Void perRequestData) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "preInvoke");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "preInvoke");
		}

	}
}