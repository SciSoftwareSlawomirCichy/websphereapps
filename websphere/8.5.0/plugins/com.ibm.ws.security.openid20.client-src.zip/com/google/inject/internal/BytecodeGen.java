package com.google.inject.internal;

import com.google.inject.internal.BytecodeGen.1;
import com.google.inject.internal.BytecodeGen.2;
import com.google.inject.internal.BytecodeGen.BridgeClassLoader;
import com.google.inject.internal.BytecodeGen.Visibility;
import com.google.inject.internal.cglib.core.NamingPolicy;
import com.google.inject.internal.cglib.proxy.Enhancer;
import com.google.inject.internal.cglib.reflect.FastClass;
import com.google.inject.internal.cglib.reflect.FastClass.Generator;
import java.util.Map;
import java.util.logging.Logger;

public final class BytecodeGen {
	private static final Logger logger = Logger.getLogger(BytecodeGen.class.getName());
	static final ClassLoader GUICE_CLASS_LOADER = BytecodeGen.class.getClassLoader();
	private static final String GUICE_INTERNAL_PACKAGE = BytecodeGen.class.getName().replaceFirst("\\.internal\\..*$",
			".internal");
	private static final String CGLIB_PACKAGE = Enhancer.class.getName().replaceFirst("\\.cglib\\..*$", ".cglib");
	static final NamingPolicy NAMING_POLICY = new 1();
	static final boolean HOOK_ENABLED = "true".equals(System.getProperty("guice.custom.loader", "true"));
	private static final Map<ClassLoader, ClassLoader> CLASS_LOADER_CACHE = (new MapMaker()).weakKeys().weakValues().makeComputingMap(new 2());

	private static ClassLoader canonicalize(ClassLoader classLoader) {
		return classLoader != null
				? classLoader
				: (ClassLoader) Preconditions.checkNotNull(getSystemClassLoaderOrNull(), "Couldn't get a ClassLoader");
	}

	private static ClassLoader getSystemClassLoaderOrNull() {
		try {
			return ClassLoader.getSystemClassLoader();
		} catch (SecurityException var1) {
			return null;
		}
	}

	public static ClassLoader getClassLoader(Class<?> type) {
		return getClassLoader(type, type.getClassLoader());
	}

	private static ClassLoader getClassLoader(Class<?> type, ClassLoader delegate) {
		delegate = canonicalize(delegate);
		if (delegate == getSystemClassLoaderOrNull()) {
			return delegate;
		} else if (delegate instanceof BridgeClassLoader) {
			return delegate;
		} else {
			return HOOK_ENABLED && Visibility.forType(type) == Visibility.PUBLIC
					? (ClassLoader) CLASS_LOADER_CACHE.get(delegate)
					: delegate;
		}
	}

	public static FastClass newFastClass(Class<?> type, Visibility visibility) {
		Generator generator = new Generator();
		generator.setType(type);
		if (visibility == Visibility.PUBLIC) {
			generator.setClassLoader(getClassLoader(type));
		}

		generator.setNamingPolicy(NAMING_POLICY);
		logger.fine("Loading " + type + " FastClass with " + generator.getClassLoader());
		return generator.create();
	}

	public static Enhancer newEnhancer(Class<?> type, Visibility visibility) {
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(type);
		enhancer.setUseFactory(false);
		if (visibility == Visibility.PUBLIC) {
			enhancer.setClassLoader(getClassLoader(type));
		}

		enhancer.setNamingPolicy(NAMING_POLICY);
		logger.fine("Loading " + type + " Enhancer with " + enhancer.getClassLoader());
		return enhancer;
	}
}