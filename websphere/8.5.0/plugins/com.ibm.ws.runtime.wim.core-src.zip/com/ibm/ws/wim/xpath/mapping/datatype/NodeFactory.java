package com.ibm.ws.wim.xpath.mapping.datatype;

public class NodeFactory implements XPathNodeFactory {
	public XPathPropertyNode getPropertyNodeInstance(String var1, String var2, Object var3) {
		return null;
	}

	public XPathLogicalNode getLogicalNodeInstance(String var1, Object var2, Object var3) {
		return null;
	}

	public XPathParenthesisNode getParenNodeInstance(XPathNode var1) {
		return null;
	}
}