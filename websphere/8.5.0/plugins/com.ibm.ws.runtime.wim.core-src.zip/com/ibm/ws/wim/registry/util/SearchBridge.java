package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.Result;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InvalidUniqueNameException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.registry.dataobject.IDAndRealm;
import com.ibm.ws.wim.util.StringUtil;
import com.ibm.ws.wim.util.UniqueNameHelper;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SearchBridge {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private final String className = SearchBridge.class.getName();
	private Logger searchBridgeTrace;
	private TypeMappings propertyMap;
	private BridgeUtils mappingUtils;
	private String groupRDN;

	public SearchBridge() {
		this.searchBridgeTrace = WIMLogger.getTraceLogger(this.className);
		this.propertyMap = new TypeMappings();
		this.mappingUtils = BridgeUtils.singleton();
		this.groupRDN = "cn";
		String var1 = "SearchBridge";
		if (this.searchBridgeTrace.isLoggable(Level.FINER)) {
			this.searchBridgeTrace.entering(this.className, var1);
		}

		try {
			List var2 = ConfigManager.singleton().getRDNProperties("Group");
			if (var2 != null && var2.size() > 0) {
				this.groupRDN = (String) var2.get(0);
			}
		} catch (WIMException var3) {
			this.searchBridgeTrace.log(Level.FINE, var3.getMessage(), var3);
		}

		if (this.searchBridgeTrace.isLoggable(Level.FINER)) {
			this.searchBridgeTrace.exiting(this.className, var1);
		}

	}

	public Result getUsers(String var1, int var2) throws CustomRegistryException, RemoteException {
		String var3 = "getUsers";
		if (this.searchBridgeTrace.isLoggable(Level.FINER)) {
			this.searchBridgeTrace.entering(this.className, var3,
					"inputPattern = \"" + var1 + "\", inputLimit = \"" + Integer.toString(var2) + "\"");
		}

		Result var4 = new Result();

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var5 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var6 = this.mappingUtils.getWimService().createRootDataObject();
			if (var5.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var6, var5.getRealm());
			}

			String var7 = this.propertyMap.getInputUserSecurityName(var5.getRealm());
			boolean var8 = this.mappingUtils.isIdentifierTypeProperty(var7);
			if (var8) {
				var7 = "principalName";
			}

			DataObject var9 = var6.createDataObject("controls", "http://www.ibm.com/websphere/wim", "SearchControl");
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var5.getRealm()))) {
				var9.getList("properties").add(this.propertyMap.getOutputUserSecurityName(var5.getRealm()));
			}

			String var10 = "'";
			String var11 = var5.getId();
			if (var11.indexOf("'") != -1) {
				var10 = "\"";
			}

			var11 = StringUtil.escapeSearchExpression(var11);
			var9.setString("expression",
					"//entities[@xsi:type='LoginAccount' and " + var7 + "=" + var10 + var11 + var10 + "]");
			if (var2 > 0) {
				var9.setString("countLimit", Integer.toString(var2 + 1));
			} else {
				var9.setString("countLimit", Integer.toString(var2));
			}

			var6 = this.mappingUtils.getWimService().search(var6);
			List var12 = var6.getList("entities");
			if (var12.isEmpty()) {
				var4.setList(new ArrayList());
			} else {
				ArrayList var13 = new ArrayList();

				for (int var14 = 0; var14 < var12.size(); ++var14) {
					if (var2 > 0 && var14 == var2) {
						var4.setHasMore();
						break;
					}

					DataObject var15 = (DataObject) var12.get(var14);
					if (!this.mappingUtils
							.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var5.getRealm()))) {
						var13.add(var15.getString(this.propertyMap.getOutputUserSecurityName(var5.getRealm())));
					} else {
						var13.add(var15.getString(
								"identifier/" + this.propertyMap.getOutputUserSecurityName(var5.getRealm())));
					}
				}

				var4.setList(var13);
			}
		} catch (WIMException var16) {
			if (!(var16 instanceof EntityNotFoundException)) {
				this.mappingUtils.logException(var16, this.className);
				throw new CustomRegistryException(var16);
			}

			var4.setList(new ArrayList());
		}

		if (this.searchBridgeTrace.isLoggable(Level.FINER)) {
			this.searchBridgeTrace.exiting(this.className, var3, "returnValue = \"" + var4 + "\"");
		}

		return var4;
	}

	public Result getGroups(String var1, int var2) throws CustomRegistryException, RemoteException {
		String var3 = "getGroups";
		if (this.searchBridgeTrace.isLoggable(Level.FINER)) {
			this.searchBridgeTrace.entering(this.className, var3,
					"inputPattern = \"" + var1 + "\", inputLimit = \"" + Integer.toString(var2) + "\"");
		}

		Result var4 = new Result();

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var5 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var6 = this.mappingUtils.getWimService().createRootDataObject();
			if (var5.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var6, var5.getRealm());
			}

			String var7 = this.propertyMap.getInputGroupSecurityName(var5.getRealm());
			boolean var8 = this.mappingUtils.isIdentifierTypeProperty(var7);
			if (var8) {
				var7 = this.groupRDN;
			}

			String var9 = "'";
			String var10 = var5.getId();
			if (var10.indexOf("'") != -1) {
				var9 = "\"";
			}

			boolean var11 = false;
			String var12 = this.propertyMap.getInputGroupSecurityName(var5.getRealm());
			DataObject var13;
			if (UniqueNameHelper.isDN(var10) != null && var12.equals("uniqueName")) {
				this.searchBridgeTrace.logp(Level.FINE, this.className, var3,
						"Group Security name mapped to uniqueName. Invoking get instead of search");
				var11 = true;
				var13 = SDOHelper.createEntityDataObject(var6, (String) null, "Group");
				var13.createDataObject("identifier").setString("uniqueName", var10);
				DataObject var14 = SDOHelper.createControlDataObject(var6, (String) null, "PropertyControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputGroupSecurityName(var5.getRealm()))) {
					var14.getList("properties").add(this.propertyMap.getOutputGroupSecurityName(var5.getRealm()));
				}

				var6 = this.mappingUtils.getWimService().get(var6);
			} else {
				var13 = var6.createDataObject("controls", "http://www.ibm.com/websphere/wim", "SearchControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputGroupSecurityName(var5.getRealm()))) {
					var13.getList("properties").add(this.propertyMap.getOutputGroupSecurityName(var5.getRealm()));
				}

				var13.setString("expression",
						"//entities[@xsi:type='Group' and " + var7 + "=" + var9 + var10 + var9 + "]");
				if (var2 > 0) {
					var13.setString("countLimit", Integer.toString(var2 + 1));
				} else {
					var13.setString("countLimit", Integer.toString(var2));
				}

				var6 = this.mappingUtils.getWimService().search(var6);
			}

			List var19 = var6.getList("entities");
			if (!var19.isEmpty()) {
				ArrayList var20 = new ArrayList();

				for (int var15 = 0; var15 < var19.size(); ++var15) {
					if (var2 > 0 && var15 == var2) {
						var4.setHasMore();
						break;
					}

					DataObject var16 = (DataObject) var19.get(var15);
					boolean var17 = false;
					if (var11) {
						var17 = SchemaManager.singleton().isSuperType("Group",
								SchemaManager.singleton().getQualifiedTypeName(var16.getType()));
					} else {
						var17 = true;
					}

					this.searchBridgeTrace.logp(Level.FINE, this.className, var3, "Value of isEntityTypGrp :" + var17);
					if (var17) {
						if (!this.mappingUtils.isIdentifierTypeProperty(
								this.propertyMap.getOutputGroupSecurityName(var5.getRealm()))) {
							var20.add(var16.getString(this.propertyMap.getOutputGroupSecurityName(var5.getRealm())));
						} else {
							var20.add(var16.getString(
									"identifier/" + this.propertyMap.getOutputGroupSecurityName(var5.getRealm())));
						}
					} else {
						this.searchBridgeTrace.logp(Level.FINE, this.className, var3,
								"The Entity type was not compatible with Group. The entityType is : "
										+ SchemaManager.singleton().getQualifiedTypeName(var16.getType()));
					}
				}

				var4.setList(var20);
			} else {
				var4.setList(new ArrayList());
			}
		} catch (WIMException var18) {
			if (!(var18 instanceof EntityNotFoundException) && !(var18 instanceof InvalidUniqueNameException)) {
				this.mappingUtils.logException(var18, this.className);
				throw new CustomRegistryException(var18);
			}

			var4.setList(new ArrayList());
		}

		if (this.searchBridgeTrace.isLoggable(Level.FINER)) {
			this.searchBridgeTrace.exiting(this.className, var3, "returnValue = \"" + var4 + "\"");
		}

		return var4;
	}
}