package com.ibm.ws.ffdc.resources;

interface package-info {
}