package com.ibm.icu.text;

import com.ibm.icu.text.CharsetRecog_2022.CharsetRecog_2022CN;
import com.ibm.icu.text.CharsetRecog_2022.CharsetRecog_2022JP;
import com.ibm.icu.text.CharsetRecog_2022.CharsetRecog_2022KR;
import com.ibm.icu.text.CharsetRecog_Unicode.CharsetRecog_UTF_16_BE;
import com.ibm.icu.text.CharsetRecog_Unicode.CharsetRecog_UTF_16_LE;
import com.ibm.icu.text.CharsetRecog_Unicode.CharsetRecog_UTF_32_BE;
import com.ibm.icu.text.CharsetRecog_Unicode.CharsetRecog_UTF_32_LE;
import com.ibm.icu.text.CharsetRecog_mbcs.CharsetRecog_big5;
import com.ibm.icu.text.CharsetRecog_mbcs.CharsetRecog_gb_18030;
import com.ibm.icu.text.CharsetRecog_mbcs.CharsetRecog_sjis;
import com.ibm.icu.text.CharsetRecog_mbcs.CharsetRecog_euc.CharsetRecog_euc_jp;
import com.ibm.icu.text.CharsetRecog_mbcs.CharsetRecog_euc.CharsetRecog_euc_kr;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_da;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_de;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_en;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_es;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_fr;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_it;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_nl;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_no;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_pt;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_1_sv;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_2_cs;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_2_hu;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_2_pl;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_2_ro;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_5_ru;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_6_ar;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_7_el;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_8_I_he;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_8_he;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_8859_9_tr;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_IBM420_ar_ltr;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_IBM420_ar_rtl;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_IBM424_he_ltr;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_IBM424_he_rtl;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_KOI8_R;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_windows_1251;
import com.ibm.icu.text.CharsetRecog_sbcs.CharsetRecog_windows_1256;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class CharsetDetector {
	private static final int kBufSize = 8000;
	byte[] fInputBytes = new byte[8000];
	int fInputLen;
	short[] fByteStats = new short[256];
	boolean fC1Bytes = false;
	String fDeclaredEncoding;
	byte[] fRawInput;
	int fRawLength;
	InputStream fInputStream;
	boolean fStripTags = false;
	private static ArrayList<CharsetRecognizer> fCSRecognizers = createRecognizers();
	private static String[] fCharsetNames;

	public CharsetDetector setDeclaredEncoding(String encoding) {
		this.fDeclaredEncoding = encoding;
		return this;
	}

	public CharsetDetector setText(byte[] in) {
		this.fRawInput = in;
		this.fRawLength = in.length;
		this.MungeInput();
		return this;
	}

	public CharsetDetector setText(InputStream in) throws IOException {
		this.fInputStream = in;
		this.fInputStream.mark(8000);
		this.fRawInput = new byte[8000];
		this.fRawLength = 0;

		int bytesRead;
		for (int remainingLength = 8000; remainingLength > 0; remainingLength -= bytesRead) {
			bytesRead = this.fInputStream.read(this.fRawInput, this.fRawLength, remainingLength);
			if (bytesRead <= 0) {
				break;
			}

			this.fRawLength += bytesRead;
		}

		this.fInputStream.reset();
		this.MungeInput();
		return this;
	}

	public CharsetMatch detect() {
		CharsetMatch[] matches = this.detectAll();
		return matches != null && matches.length != 0 ? matches[0] : null;
	}

	public CharsetMatch[] detectAll() {
		ArrayList<CharsetMatch> matches = new ArrayList();

		for (int i = 0; i < fCSRecognizers.size(); ++i) {
			CharsetRecognizer csr = (CharsetRecognizer) fCSRecognizers.get(i);
			int detectResults = csr.match(this);
			int confidence = detectResults & 255;
			if (confidence > 0) {
				CharsetMatch m = new CharsetMatch(this, csr, confidence);
				matches.add(m);
			}
		}

		Collections.sort(matches);
		Collections.reverse(matches);
		CharsetMatch[] resultArray = new CharsetMatch[matches.size()];
		resultArray = (CharsetMatch[]) matches.toArray(resultArray);
		return resultArray;
	}

	public Reader getReader(InputStream in, String declaredEncoding) {
		this.fDeclaredEncoding = declaredEncoding;

		try {
			this.setText(in);
			CharsetMatch match = this.detect();
			return match == null ? null : match.getReader();
		} catch (IOException var4) {
			return null;
		}
	}

	public String getString(byte[] in, String declaredEncoding) {
		this.fDeclaredEncoding = declaredEncoding;

		try {
			this.setText(in);
			CharsetMatch match = this.detect();
			return match == null ? null : match.getString(-1);
		} catch (IOException var4) {
			return null;
		}
	}

	public static String[] getAllDetectableCharsets() {
		return fCharsetNames;
	}

	public boolean inputFilterEnabled() {
		return this.fStripTags;
	}

	public boolean enableInputFilter(boolean filter) {
		boolean previous = this.fStripTags;
		this.fStripTags = filter;
		return previous;
	}

	private void MungeInput() {
		int srci = false;
		int dsti = 0;
		boolean inMarkup = false;
		int openTags = 0;
		int badTags = 0;
		int srci;
		if (this.fStripTags) {
			for (srci = 0; srci < this.fRawLength && dsti < this.fInputBytes.length; ++srci) {
				byte b = this.fRawInput[srci];
				if (b == 60) {
					if (inMarkup) {
						++badTags;
					}

					inMarkup = true;
					++openTags;
				}

				if (!inMarkup) {
					this.fInputBytes[dsti++] = b;
				}

				if (b == 62) {
					inMarkup = false;
				}
			}

			this.fInputLen = dsti;
		}

		int i;
		if (openTags < 5 || openTags / 5 < badTags || this.fInputLen < 100 && this.fRawLength > 600) {
			i = this.fRawLength;
			if (i > 8000) {
				i = 8000;
			}

			for (srci = 0; srci < i; ++srci) {
				this.fInputBytes[srci] = this.fRawInput[srci];
			}

			this.fInputLen = srci;
		}

		Arrays.fill(this.fByteStats, (short) 0);

		for (srci = 0; srci < this.fInputLen; ++srci) {
			i = this.fInputBytes[srci] & 255;
			++this.fByteStats[i];
		}

		this.fC1Bytes = false;

		for (i = 128; i <= 159; ++i) {
			if (this.fByteStats[i] != 0) {
				this.fC1Bytes = true;
				break;
			}
		}

	}

	private static ArrayList<CharsetRecognizer> createRecognizers() {
		ArrayList<CharsetRecognizer> recognizers = new ArrayList();
		recognizers.add(new CharsetRecog_UTF8());
		recognizers.add(new CharsetRecog_UTF_16_BE());
		recognizers.add(new CharsetRecog_UTF_16_LE());
		recognizers.add(new CharsetRecog_UTF_32_BE());
		recognizers.add(new CharsetRecog_UTF_32_LE());
		recognizers.add(new CharsetRecog_sjis());
		recognizers.add(new CharsetRecog_2022JP());
		recognizers.add(new CharsetRecog_2022CN());
		recognizers.add(new CharsetRecog_2022KR());
		recognizers.add(new CharsetRecog_gb_18030());
		recognizers.add(new CharsetRecog_euc_jp());
		recognizers.add(new CharsetRecog_euc_kr());
		recognizers.add(new CharsetRecog_big5());
		recognizers.add(new CharsetRecog_8859_1_da());
		recognizers.add(new CharsetRecog_8859_1_de());
		recognizers.add(new CharsetRecog_8859_1_en());
		recognizers.add(new CharsetRecog_8859_1_es());
		recognizers.add(new CharsetRecog_8859_1_fr());
		recognizers.add(new CharsetRecog_8859_1_it());
		recognizers.add(new CharsetRecog_8859_1_nl());
		recognizers.add(new CharsetRecog_8859_1_no());
		recognizers.add(new CharsetRecog_8859_1_pt());
		recognizers.add(new CharsetRecog_8859_1_sv());
		recognizers.add(new CharsetRecog_8859_2_cs());
		recognizers.add(new CharsetRecog_8859_2_hu());
		recognizers.add(new CharsetRecog_8859_2_pl());
		recognizers.add(new CharsetRecog_8859_2_ro());
		recognizers.add(new CharsetRecog_8859_5_ru());
		recognizers.add(new CharsetRecog_8859_6_ar());
		recognizers.add(new CharsetRecog_8859_7_el());
		recognizers.add(new CharsetRecog_8859_8_I_he());
		recognizers.add(new CharsetRecog_8859_8_he());
		recognizers.add(new CharsetRecog_windows_1251());
		recognizers.add(new CharsetRecog_windows_1256());
		recognizers.add(new CharsetRecog_KOI8_R());
		recognizers.add(new CharsetRecog_8859_9_tr());
		recognizers.add(new CharsetRecog_IBM424_he_rtl());
		recognizers.add(new CharsetRecog_IBM424_he_ltr());
		recognizers.add(new CharsetRecog_IBM420_ar_rtl());
		recognizers.add(new CharsetRecog_IBM420_ar_ltr());
		String[] charsetNames = new String[recognizers.size()];
		int out = 0;

		for (int i = 0; i < recognizers.size(); ++i) {
			String name = ((CharsetRecognizer) recognizers.get(i)).getName();
			if (out == 0 || !name.equals(charsetNames[out - 1])) {
				charsetNames[out++] = name;
			}
		}

		fCharsetNames = new String[out];
		System.arraycopy(charsetNames, 0, fCharsetNames, 0, out);
		return recognizers;
	}
}