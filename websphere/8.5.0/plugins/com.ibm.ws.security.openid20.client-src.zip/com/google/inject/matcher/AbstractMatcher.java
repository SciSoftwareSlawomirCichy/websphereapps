package com.google.inject.matcher;

import com.google.inject.matcher.AbstractMatcher.AndMatcher;
import com.google.inject.matcher.AbstractMatcher.OrMatcher;

public abstract class AbstractMatcher<T> implements Matcher<T> {
	public Matcher<T> and(Matcher<? super T> other) {
		return new AndMatcher(this, other);
	}

	public Matcher<T> or(Matcher<? super T> other) {
		return new OrMatcher(this, other);
	}
}