package com.ibm.ejs.container;

import com.ibm.ws.csi.DispatchEventListenerCookie;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;

public class BeanOCallDispatchToken {
	private DispatchEventListenerCookie[] dispatchEventListenerCookies = null;
	private EJBMethodMetaData methodMetaData = null;
	private boolean doAfterDispatch = false;

	public void setDispatchEventListenerCookies(DispatchEventListenerCookie[] c) {
		this.dispatchEventListenerCookies = c;
	}

	public DispatchEventListenerCookie[] getDispatchEventListenerCookies() {
		return this.dispatchEventListenerCookies;
	}

	public void setMethodMetaData(EJBMethodMetaData m) {
		this.methodMetaData = m;
	}

	public EJBMethodMetaData getMethodMetaData() {
		return this.methodMetaData;
	}

	public void setDoAfterDispatch(boolean v) {
		this.doAfterDispatch = v;
	}

	public boolean getDoAfterDispatch() {
		return this.doAfterDispatch;
	}
}