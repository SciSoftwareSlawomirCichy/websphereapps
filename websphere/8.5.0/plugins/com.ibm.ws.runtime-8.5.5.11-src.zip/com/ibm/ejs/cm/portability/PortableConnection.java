package com.ibm.ejs.cm.portability;

import java.sql.Connection;
import java.sql.SQLException;

public interface PortableConnection extends Connection {
	PortabilityLayerExt getPortabilityLayer() throws SQLException;

	SQLException translateException(SQLException var1) throws SQLException;

	String getColumnTypeSpec(int var1) throws SQLException;

	String addRowLockHint(String var1) throws SQLException;
}