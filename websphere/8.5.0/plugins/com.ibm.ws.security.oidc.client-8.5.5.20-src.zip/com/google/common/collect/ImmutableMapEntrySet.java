package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.j2objc.annotations.Weak;
import java.io.Serializable;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
abstract class ImmutableMapEntrySet<K, V> extends ImmutableSet<Map.Entry<K, V>> {
	abstract ImmutableMap<K, V> map();

	public int size() {
		return this.map().size();
	}

	public boolean contains(@NullableDecl Object object) {
		if (!(object instanceof Map.Entry)) {
			return false;
		} else {
			Map.Entry<?, ?> entry = (Map.Entry) object;
			V value = this.map().get(entry.getKey());
			return value != null && value.equals(entry.getValue());
		}
	}

	boolean isPartialView() {
		return this.map().isPartialView();
	}

	@GwtIncompatible
	boolean isHashCodeFast() {
		return this.map().isHashCodeFast();
	}

	public int hashCode() {
		return this.map().hashCode();
	}

	@GwtIncompatible
	Object writeReplace() {
		return new EntrySetSerializedForm(this.map());
	}

	@GwtIncompatible
	private static class EntrySetSerializedForm<K, V> implements Serializable {
		final ImmutableMap<K, V> map;
		private static final long serialVersionUID = 0L;

		EntrySetSerializedForm(ImmutableMap<K, V> map) {
			this.map = map;
		}

		Object readResolve() {
			return this.map.entrySet();
		}
	}

	static final class RegularEntrySet<K, V> extends ImmutableMapEntrySet<K, V> {
		@Weak
		private final transient ImmutableMap<K, V> map;
		private final transient ImmutableList<Map.Entry<K, V>> entries;

		RegularEntrySet(ImmutableMap<K, V> map, Map.Entry<K, V>[] entries) {
			this(map, ImmutableList.asImmutableList(entries));
		}

		RegularEntrySet(ImmutableMap<K, V> map, ImmutableList<Map.Entry<K, V>> entries) {
			this.map = map;
			this.entries = entries;
		}

		ImmutableMap<K, V> map() {
			return this.map;
		}

		@GwtIncompatible("not used in GWT")
		int copyIntoArray(Object[] dst, int offset) {
			return this.entries.copyIntoArray(dst, offset);
		}

		public UnmodifiableIterator<Map.Entry<K, V>> iterator() {
			return this.entries.iterator();
		}

		ImmutableList<Map.Entry<K, V>> createAsList() {
			return this.entries;
		}
	}
}