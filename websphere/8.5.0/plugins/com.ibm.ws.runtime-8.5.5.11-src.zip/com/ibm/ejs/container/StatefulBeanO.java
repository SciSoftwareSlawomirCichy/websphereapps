package com.ibm.ejs.container;

import com.ibm.ejs.container.interceptors.InterceptorMetaData;
import com.ibm.ejs.container.interceptors.InterceptorProxy;
import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.container.passivator.StatefulPassivator;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.csi.UOWCookie;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CacheElement;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.websphere.csi.StatefulSessionKey;
import com.ibm.ws.ejbcontainer.CallbackKind;
import com.ibm.ws.ejbcontainer.failover.SfFailoverClient;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.managedobject.ManagedObjectState;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import com.ibm.wsspi.injectionengine.InjectionEngine;
import com.ibm.wsspi.injectionengine.InjectionTarget;
import java.rmi.RemoteException;
import java.security.Principal;
import javax.ejb.CreateException;
import javax.ejb.EnterpriseBean;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.TimerService;
import javax.xml.rpc.handler.MessageContext;

public abstract class StatefulBeanO extends SessionBeanO {
	private static final String CLASS_NAME = StatefulBeanO.class.getName();
	private static final TraceComponent tc;
	public Object ivCacheLock;
	public CacheElement ivCacheElement;
	EJSWrapperCommon ivWrapperCommon;
	protected boolean removed = false;
	protected boolean discarded = false;
	protected boolean uninstalling = false;
	protected ContainerTx currentTx;
	protected transient StatefulPassivator passivator;
	private boolean ivServantRoutingAffinity = false;
	TimeoutElement ivTimeoutElement;
	public transient SfFailoverClient ivSfFailoverClient;
	protected transient Object ivExPcContext;
	private transient Thread ivActiveOnThread = null;
	private transient boolean ivThreadsWaiting = false;
	public static final int METHOD_READY = 3;
	public static final int IN_METHOD = 4;
	public static final int TX_METHOD_READY = 5;
	public static final int TX_IN_METHOD = 6;
	public static final int COMMITTING_OUTSIDE_METHOD = 7;
	public static final int COMMITTING_IN_METHOD = 8;
	public static final int PASSIVATING = 9;
	public static final int PASSIVATED = 10;
	public static final int ACTIVATING = 11;
	public static final int REMOVING = 12;
	public static final int AFTER_BEGIN = 13;
	public static final int AFTER_COMPLETION = 14;
	protected static final String[] StateStrs;

	protected StatefulBeanO(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		super(c, mo, b, h);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "CTOR SFSB: " + this);
		}

	}

	protected void initialize() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "initialize");
		}

		this.passivator = this.container.passivator;
		this.stateStrs = StateStrs;
		this.state = 1;
		BeanMetaData bmd = this.home.beanMetaData;
		this.ivSfFailoverClient = bmd.ivSfFailoverClient;
		EJSDeployedSupport methodContext = null;
		if (this.ivEjbInstance == null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Initialize called for a passivated SFSB: " + this);
			}

			this.setState(11);
		} else {
			UnspecifiedContextHelper contextHelper = null;

			try {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Initialize called for a new SFSB: " + this);
				}

				if (bmd.ivHasCMExtendedPersistenceContext) {
					this.ivExPcContext = this.container.getEJBRuntime().getEJBJPAContainer()
							.onCreate(bmd.j2eeName.toString(), bmd.usesBeanManagedTx, bmd.ivExPcPuIds);
				}

				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Extended PC = " + this.ivExPcContext);
				}

				contextHelper = new UnspecifiedContextHelper(this);
				contextHelper.begin(true);
				if (this.sessionBean != null) {
					this.sessionBean.setSessionContext(this);
				}

				methodContext = EJSContainer.getMethodContext();
				if (methodContext != null) {
					methodContext.ivCreateBeanO = this;
				}

				InterceptorMetaData imd = bmd.ivInterceptorMetaData;
				if (imd != null) {
					this.createInterceptors(imd);
				}

				if (bmd.ivBeanInjectionTargets != null) {
					try {
						InjectionEngine injectionEngine = this.getInjectionEngine();
						InjectionTarget[] targets = bmd.ivBeanInjectionTargets;
						if (targets != null) {
							InjectionTarget[] arr$ = targets;
							int len$ = targets.length;

							for (int i$ = 0; i$ < len$; ++i$) {
								InjectionTarget injectionTarget = arr$[i$];
								injectionEngine.inject(this.ivEjbInstance, injectionTarget, this);
							}
						}
					} catch (Throwable var17) {
						FFDCFilter.processException(var17, CLASS_NAME + ".<init>", "282", this);
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Injection failure", var17);
						}

						throw ExceptionUtil.EJBException("Injection failure", var17);
					}
				}

				try {
					this.setId(new BeanId(this.home, EJSContainer.sessionKeyFactory.create(), false));
				} catch (CSIException var16) {
					FFDCFilter.processException(var16, CLASS_NAME + ".<init>", "344", this);
					throw ExceptionUtil.EJBException(var16);
				}

				this.ivTimeoutElement = new TimeoutElement(this.beanId, this.getSessionTimeoutInMilliSeconds());
				this.ivWrapperCommon = this.container.wrapperManager.createWrapper(this);
				this.setState(2);
				if (imd != null && this.ivCallbackKind == CallbackKind.InvocationContext) {
					InterceptorProxy[] proxies = imd.ivPostConstructInterceptors;
					if (proxies != null) {
						this.callLifecycleInterceptors(proxies, 0);
					}
				}
			} finally {
				if (methodContext != null) {
					methodContext.ivCreateBeanO = null;
				}

				if (contextHelper != null) {
					contextHelper.complete(true);
				}

			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "initialize");
		}

	}

	public void initializeTimeout(TimeoutElement elt) {
		if (elt == null) {
			elt = new TimeoutElement(this.beanId, this.getSessionTimeoutInMilliSeconds());
		}

		this.ivTimeoutElement = elt;
	}

	public final boolean isRemoved() {
		return this.state == 0;
	}

	public final boolean isDiscarded() {
		return this.discarded;
	}

	private void disconnectWrapper() {
		EJSWrapperCommon wc = this.ivWrapperCommon;
		if (wc != null) {
			wc.ivCachedBeanO = null;
			this.ivWrapperCommon = null;
		}

	}

	public final synchronized void destroy() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy - bean=" + this.toString());
		}

		if (this.state == 0) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "destroy");
			}

		} else {
			if (this.ivSfFailoverClient != null) {
				this.ivSfFailoverClient.removeEntry(this.beanId);
			}

			if (isZOS) {
				this.removeServantRoutingAffinity();
			}

			this.setState(0);
			if (this.pmiBean != null) {
				this.pmiBean.beanDestroyed();
			}

			String lifeCycle = null;
			UnspecifiedContextHelper contextHelper = null;

			try {
				if (!this.removed && this.ivEjbInstance != null) {
					BeanMetaData bmd = this.home.beanMetaData;
					contextHelper = new UnspecifiedContextHelper(this);
					contextHelper.begin(this.ivCallbackKind != CallbackKind.None);
					if (this.ivCallbackKind == CallbackKind.SessionBean) {
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							lifeCycle = "ejbRemove";
							TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
						}

						this.sessionBean.ejbRemove();
					} else if (this.ivCallbackKind == CallbackKind.InvocationContext) {
						InterceptorMetaData imd = this.home.beanMetaData.ivInterceptorMetaData;
						InterceptorProxy[] proxies = imd.ivPreDestroyInterceptors;
						if (proxies != null) {
							if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
								lifeCycle = "PreDestroy";
								TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
							}

							InvocationContextImpl inv = new InvocationContextImpl();
							inv.initialize(this.ivEjbInstance, this.ivInterceptors);
							inv.doLifeCycle(proxies, bmd._moduleMetaData);
						}
					}

					if (this.pmiBean != null) {
						this.pmiBean.beanRemoved();
					}
				} else if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "destroy : already removed or failed to activate");
				}
			} catch (Exception var16) {
				FFDCFilter.processException(var16, CLASS_NAME + ".destroy", "176", this);
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "destroy caught exception:", new Object[]{this, var16});
				}
			} finally {
				if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled() && lifeCycle != null) {
					TEBeanLifeCycleInfo.traceEJBCallExit(lifeCycle);
				}

				if (contextHelper != null) {
					try {
						contextHelper.complete(true);
					} catch (Throwable var15) {
						FFDCFilter.processException(var15, CLASS_NAME + ".destroy", "585", this);
						if (isTraceOn && tc.isEventEnabled()) {
							Tr.event(tc, "destroy caught exception: ", new Object[]{this, var15});
						}
					}
				}

				this.disconnectWrapper();
				this.destroyHandleList();
				this.releaseManagedObjectState();
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "destroy");
				}

			}

		}
	}

	public final synchronized void destroyNotRemove() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "destroyNotRemove : " + this);
		}

		if (this.state != 0) {
			if (this.ivExPcContext != null) {
				this.container.getEJBRuntime().getEJBJPAContainer().onRemoveOrDiscard(this.ivExPcContext);
			}

			if (isZOS) {
				this.removeServantRoutingAffinity();
			}

			this.setState(0);
			this.releaseManagedObjectState();
			if (this.pmiBean != null) {
				this.pmiBean.beanDestroyed();
			}

			this.disconnectWrapper();
			this.destroyHandleList();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "destroyNotRemove");
			}

		}
	}

	public final synchronized boolean isTimedOut() {
		return this.state == 3 && this.ivTimeoutElement.isTimedOut();
	}

	public final EnterpriseBean getEnterpriseBean() throws RemoteException {
		this.assertState(2);
		return this.sessionBean;
	}

	public final long getSessionTimeoutInMilliSeconds() {
		return this.home.beanMetaData.sessionTimeout;
	}

	public void setEnterpriseBean(Object sb, ManagedObjectState state) {
		this.ivEjbInstance = sb;
		this.ivManagedObjectState = state;
		if (sb instanceof SessionBean) {
			this.sessionBean = (SessionBean) sb;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.debug(tc, "setEnterpriseBean for EJB instance = " + sb + ", for SFSB: " + this);
		}

	}

	public void setInterceptors(Object[] interceptors, ManagedObjectState[] managedObjectStates) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.debug(tc, "setInterceptors interceptors = " + interceptors + ", for SFSB: " + this);
		}

		this.ivInterceptors = interceptors;
		this.ivInterceptorManagedObjectStates = managedObjectStates;
	}

	public void setCurrentTx(ContainerTx ctx) {
		this.currentTx = ctx;
	}

	public void setContainerTx(ContainerTx ctx) {
		this.setCurrentTx(ctx);
		super.setContainerTx(ctx);
	}

	private void createServantRoutingAffinity() throws BeanNotReentrantException {
		if (!this.ivServantRoutingAffinity && this.container.ivStatefulBeanEnqDeq != null) {
			StatefulSessionKey sskey = (StatefulSessionKey) this.beanId.getPrimaryKey();
			byte[] pKeyBytes = sskey.getBytes();
			int retcode = this.container.ivStatefulBeanEnqDeq.SSBeanEnq(pKeyBytes,
					!this.home.beanMetaData.sessionActivateTran, true);
			if (retcode != 0) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Could not ENQ session bean with key = " + sskey);
				}

				throw new BeanNotReentrantException("Could not ENQ session bean with key = " + sskey);
			}

			this.ivServantRoutingAffinity = true;
		}

	}

	private boolean removeServantRoutingAffinity() {
		if (this.ivServantRoutingAffinity) {
			StatefulSessionKey sskey = (StatefulSessionKey) this.beanId.getPrimaryKey();
			byte[] pKeyBytes = sskey.getBytes();
			int retcode = this.container.ivStatefulBeanEnqDeq.SSBeanDeq(pKeyBytes,
					!this.home.beanMetaData.sessionActivateTran, true);
			if (retcode != 0) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Could not DEQ session bean with key = " + sskey);
				}

				return false;
			}

			this.ivServantRoutingAffinity = false;
		}

		return true;
	}

	public final void postCreate(boolean supportEJBPostCreateChanges) throws CreateException, RemoteException {
		if (isZOS) {
			this.createServantRoutingAffinity();
		}

		this.setState(2, 3);
	}

	public final synchronized void activate(BeanId id, ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "activate: " + this);
		}

		long pmiCookie = -1L;
		this.assertState(11);
		if (this.pmiBean != null) {
			pmiCookie = this.pmiBean.activationTime();
		}

		String lifeCycle = null;
		BeanMetaData bmd = this.home.beanMetaData;
		UnspecifiedContextHelper contextHelper = new UnspecifiedContextHelper(this);

		try {
			contextHelper.begin(this.ivCallbackKind != CallbackKind.None);
			this.passivator.activate(this, bmd);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "extended persistence context bindID = " + this.ivExPcContext);
			}

			if (this.ivCallbackKind == CallbackKind.SessionBean) {
				if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
					lifeCycle = "ejbActivate";
					TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
				}

				this.sessionBean.ejbActivate();
			} else if (this.ivCallbackKind == CallbackKind.InvocationContext) {
				InterceptorMetaData imd = bmd.ivInterceptorMetaData;
				InterceptorProxy[] proxies = imd.ivPostActivateInterceptors;
				if (proxies != null) {
					if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
						lifeCycle = "PostActivate";
						TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
					}

					InvocationContextImpl inv = new InvocationContextImpl();
					inv.initialize(this.ivEjbInstance, this.ivInterceptors);
					inv.doLifeCycle(proxies, bmd._moduleMetaData);
				}
			}
		} finally {
			if (lifeCycle != null) {
				TEBeanLifeCycleInfo.traceEJBCallExit(lifeCycle);
			}

			if (this.pmiBean != null) {
				this.pmiBean.activationTime(pmiCookie);
			}

			contextHelper.complete(true);
		}

		if (isZOS) {
			this.createServantRoutingAffinity();
		}

		this.setState(11, 3);
		this.ivTimeoutElement.passivated = false;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "activate: " + this.stateStrs[this.state]);
		}

	}

	public final synchronized void passivate() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "passivate: " + this);
		}

		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "extended persistence context bindID = " + this.ivExPcContext);
		}

		long pmiCookie = -1L;
		if (this.state != 6 && this.state != 5) {
			this.setState(3, 9);
			String lifeCycle = null;
			UnspecifiedContextHelper contextHelper = null;

			try {
				if (this.pmiBean != null) {
					pmiCookie = this.pmiBean.passivationTime();
				}

				if (this.ivCallbackKind != CallbackKind.None) {
					contextHelper = new UnspecifiedContextHelper(this, true);
					contextHelper.begin(true);
					if (this.ivCallbackKind == CallbackKind.SessionBean) {
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							lifeCycle = "ejbPassivate";
							TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
						}

						this.sessionBean.ejbPassivate();
					} else if (this.ivCallbackKind == CallbackKind.InvocationContext) {
						BeanMetaData bmd = this.home.beanMetaData;
						InterceptorMetaData imd = bmd.ivInterceptorMetaData;
						InterceptorProxy[] proxies = imd.ivPrePassivateInterceptors;
						if (proxies != null) {
							if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
								lifeCycle = "PrePassivate";
								TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
							}

							InvocationContextImpl inv = new InvocationContextImpl();
							inv.initialize(this.ivEjbInstance, this.ivInterceptors);
							inv.doLifeCycle(proxies, bmd._moduleMetaData);
						}
					}
				}

				if (!this.uninstalling) {
					this.passivator.passivate(this, this.home.beanMetaData);
				}
			} catch (RemoteException var13) {
				FFDCFilter.processException(var13, CLASS_NAME + ".passivate", "425", this);
				pmiCookie = -1L;
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "passivate failed! ", new Object[]{this, var13});
				}

				throw var13;
			} finally {
				if (lifeCycle != null) {
					TEBeanLifeCycleInfo.traceEJBCallExit(lifeCycle);
				}

				if (contextHelper != null) {
					contextHelper.complete(true);
				}

				if (this.pmiBean != null) {
					this.pmiBean.passivationTime(pmiCookie);
				}

				this.setState(9, 10);
				this.ivTimeoutElement.passivated = true;
				this.destroyNotRemove();
			}

			if (isZOS && !this.removeServantRoutingAffinity()) {
				throw new InvalidBeanOStateException(
						"Could not DEQ session bean with key = " + this.beanId.getPrimaryKey());
			} else {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "passivate: " + this.stateStrs[this.state]);
				}

			}
		} else {
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "State: " + StateStrs[this.state] + " Bean cannot be passivated in a transaction");
			}

			throw new BeanOPassivationFailureException();
		}
	}

	public boolean enlist(ContainerTx tx, boolean txEnlist) throws RemoteException {
		return this.enlist(tx);
	}

	public final synchronized Object preInvoke(EJSDeployedSupport s, ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "preInvoke: " + this);
		}

		switch (this.state) {
			case 3 :
				this.setState(4);
				break;
			case 5 :
				this.setState(6);
				break;
			default :
				throw new InvalidBeanOStateException(StateStrs[this.state], "METHOD_READY | TX_METHOD_READY");
		}

		int tmp = this.currentIsolationLevel;
		this.currentIsolationLevel = s.currentIsolationLevel;
		s.currentIsolationLevel = tmp;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "preInvoke: " + this.stateStrs[this.state]);
		}

		return this.ivEjbInstance;
	}

	public synchronized void postInvoke(int id, EJSDeployedSupport s) throws RemoteException {
		this.currentIsolationLevel = s.oldIsolationLevel;
		if (!this.removed) {
			switch (this.state) {
				case 0 :
					return;
				case 4 :
					this.setState(3);
					break;
				case 6 :
					this.setState(5);
					break;
				default :
					throw new InvalidBeanOStateException(StateStrs[this.state], "IN_METHOD | TX_IN_METHOD | DESTROYED");
			}

			if (s.methodInfo.ivSFSBRemove
					&& (s.ivWrapper.ivInterface == WrapperInterface.BUSINESS_LOCAL
							|| s.ivWrapper.ivInterface == WrapperInterface.BUSINESS_REMOTE
							|| s.ivWrapper.ivInterface == WrapperInterface.BUSINESS_RMI_REMOTE)
					&& (s.getExceptionType() == ExceptionType.NO_EXCEPTION || !s.methodInfo.ivRetainIfException
							&& s.getExceptionType() == ExceptionType.CHECKED_EXCEPTION)) {
				s.currentTx.ivRemoveBeanO = this;
			}

		}
	}

	public final void store() throws RemoteException {
	}

	public final synchronized void discard() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "discard : " + this);
		}

		if (!this.removed && !this.discarded) {
			this.destroyNotRemove();
			if (this.pmiBean != null) {
				this.pmiBean.beanDiscarded();
				this.pmiBean.discardCount();
			}

			this.discarded = true;
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "discard");
			}

		}
	}

	protected void completeRemoveMethod(ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "completeRemoveMethod: " + this);
		}

		long pmiCookie = 0L;
		if (this.pmiBean != null) {
			pmiCookie = this.pmiBean.initalTime(15);
		}

		EJBThreadData threadData = EJSContainer.getThreadData();
		threadData.pushContexts(this);

		try {
			this.remove();
		} catch (RemoveException var10) {
			throw ExceptionUtil.EJBException("Remove Failed", var10);
		} finally {
			tx.ivRemoveBeanO = null;
			threadData.popContexts();
			if (this.pmiBean != null) {
				this.pmiBean.finalTime(15, pmiCookie);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "completeRemoveMethod");
			}

		}

	}

	public final synchronized void remove() throws RemoteException, RemoveException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "remove: " + this);
		}

		this.canBeRemoved();
		this.setState(12);
		String lifeCycle = null;
		UnspecifiedContextHelper contextHelper = null;

		try {
			BeanMetaData bmd = this.home.beanMetaData;
			if (this.ivExPcContext != null) {
				this.container.getEJBRuntime().getEJBJPAContainer().onRemoveOrDiscard(this.ivExPcContext);
			}

			contextHelper = new UnspecifiedContextHelper(this);
			contextHelper.begin(this.ivCallbackKind != CallbackKind.None);
			if (this.ivCallbackKind == CallbackKind.SessionBean) {
				if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
					lifeCycle = "ejbRemove";
					TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
				}

				this.sessionBean.ejbRemove();
			} else if (this.ivCallbackKind == CallbackKind.InvocationContext) {
				InterceptorMetaData imd = this.home.beanMetaData.ivInterceptorMetaData;
				InterceptorProxy[] proxies = imd.ivPreDestroyInterceptors;
				if (proxies != null) {
					if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
						lifeCycle = "PreDestroy";
						TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
					}

					InvocationContextImpl inv = new InvocationContextImpl();
					inv.initialize(this.ivEjbInstance, this.ivInterceptors);
					inv.doLifeCycle(proxies, bmd._moduleMetaData);
				}
			}

			if (this.pmiBean != null) {
				this.pmiBean.beanRemoved();
			}

			this.removed = true;
			this.destroy();
		} catch (RemoteException var12) {
			FFDCFilter.processException(var12, CLASS_NAME + ".remove", "611", this);
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "remove caught exception", new Object[]{this, var12});
			}

			this.discard();
			throw new RemoveException(var12.getMessage());
		} catch (Throwable var13) {
			FFDCFilter.processException(var13, CLASS_NAME + ".remove", "611", this);
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "remove caught exception:", new Object[]{this, var13});
			}

			this.discard();
		} finally {
			if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled() && lifeCycle != null) {
				TEBeanLifeCycleInfo.traceEJBCallExit(lifeCycle);
			}

			if (contextHelper != null) {
				contextHelper.complete(true);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "remove: " + this);
			}

		}

	}

	public final synchronized void uninstall() {
		try {
			this.uninstalling = true;
			this.passivate();
		} catch (RemoteException var2) {
			FFDCFilter.processException(var2, CLASS_NAME + ".uninstall", "654", this);
			Tr.warning(tc, "IGNORING_UNEXPECTED_EXCEPTION_CNTR0033E", var2);
		}

	}

	public void checkTimerServiceAccess() throws IllegalStateException {
		if (this.state != 6 && this.state != 13 && this.state != 7) {
			IllegalStateException ise = new IllegalStateException(
					"StatefulBean: Timer Service methods not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerServiceAccess: " + ise);
			}

			throw ise;
		}
	}

	public void setRollbackOnly() {
		synchronized (this) {
			if (this.state == 1 || this.state == 2 || this.state == 12 || this.state == 11 || this.state == 9
					|| this.state == 0 || this.state == 14) {
				IllegalStateException ise = new IllegalStateException(
						"StatefulBean: setRollbackOnly() not allowed from state = " + this.stateStrs[this.state]);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "setRollbackOnly: " + ise);
				}

				throw ise;
			}
		}

		super.setRollbackOnly();
	}

	public boolean getRollbackOnly() {
		synchronized (this) {
			if (this.state == 1 || this.state == 2 || this.state == 12 || this.state == 11 || this.state == 9
					|| this.state == 0 || this.state == 14) {
				IllegalStateException ise = new IllegalStateException(
						"StatefulBean: getRollbackOnly() not allowed from state = " + this.stateStrs[this.state]);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getRollbackOnly: " + ise);
				}

				throw ise;
			}
		}

		return super.getRollbackOnly();
	}

	public Class<?> getInvokedBusinessInterface() throws IllegalStateException {
		boolean validState = false;
		int stateCopy;
		synchronized (this) {
			stateCopy = this.state;
			validState = this.state == 3 || this.state == 4 || this.state == 5 || this.state == 6;
		}

		if (validState) {
			return super.getInvokedBusinessInterface();
		} else {
			String stateString = this.stateStrs[stateCopy];
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Incorrect state: " + stateString);
			}

			throw new IllegalStateException(stateString);
		}
	}

	public Principal getCallerPrincipal() {
		synchronized (this) {
			if (this.state == 1) {
				throw new IllegalStateException();
			}
		}

		return super.getCallerPrincipal();
	}

	public boolean isCallerInRole(String s) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCallerInRole, role = " + s + ", state = " + StateStrs[this.state]);
		}

		Object bean = null;
		synchronized (this) {
			if (this.state == 1) {
				throw new IllegalStateException();
			}

			if (this.state == 4 || this.state == 6) {
				bean = this.ivEjbInstance;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isCallerInRole");
		}

		return super.isCallerInRole(s, bean);
	}

	public TimerService getTimerService() throws IllegalStateException {
		IllegalStateException ise = new IllegalStateException(
				"StatefulBean: getTimerService not allowed from Stateful Session Bean");
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getTimerService: " + ise);
		}

		throw ise;
	}

	public MessageContext getMessageContext() throws IllegalStateException {
		IllegalStateException ise = new IllegalStateException(
				"StatefulBean: getMessageContext not allowed from Stateful Session Bean");
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getMessageContext: " + ise);
		}

		throw ise;
	}

	public void flushCache() {
		if (this.state != 1 && this.state != 2 && this.state != 12 && this.state != 11 && this.state != 9
				&& this.state != 0 && this.state != 14) {
			super.flushCache();
		} else {
			IllegalStateException ise = new IllegalStateException(
					"StatefulBean: flushCache not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "flushCache: " + ise);
			}

			throw ise;
		}
	}

	public String toString() {
		return this.toString("StatefulBeanO");
	}

	protected final String toString(String s) {
		return s + "(" + this.beanId + ", state = " + StateStrs[this.state] + ")";
	}

	public final long getLastAccessTime() {
		return this.ivTimeoutElement.lastAccessTime;
	}

	public final void setLastAccessTime(long lat) {
		this.ivTimeoutElement.lastAccessTime = lat;
	}

	public final boolean sfsbFailoverEnabled() {
		return this.ivSfFailoverClient != null;
	}

	public final void createFailoverEntry() throws RemoteException {
		this.ivSfFailoverClient.createEntry(this.beanId, this.getSessionTimeoutInMilliSeconds());
	}

	public void updateFailoverEntry(byte[] beanData, long lastAccessTime) throws RemoteException {
		try {
			this.ivSfFailoverClient.passivated(this.beanId, beanData, lastAccessTime);
		} catch (Exception var5) {
			FFDCFilter.processException(var5, CLASS_NAME + ".updateFailoverEntry", "1137", this);
			throw new RemoteException("Could not update SFSB Entry", var5);
		}
	}

	public void updateFailoverSetActiveProp() {
		try {
			if (this.ivSfFailoverClient != null) {
				this.ivSfFailoverClient.activated(this.beanId, this.ivTimeoutElement.lastAccessTime);
			}
		} catch (Throwable var2) {
			FFDCFilter.processException(var2, CLASS_NAME + ".updateFailoverProp", "1158", this);
		}

	}

	public Object getJPAExPcBindingContext() {
		return this.ivExPcContext;
	}

	public void setJPAExPcBindingContext(Object exPc) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.debug(tc, "setJPAExPcBindingContext: " + exPc);
		}

		this.ivExPcContext = exPc;
	}

	public boolean lock(EJSDeployedSupport methodContext, ContainerTx tx) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc,
					"lock(" + tx + ", thread=" + Thread.currentThread().getId() + ") : " + this + ", " + this.currentTx
							+ ", activeOnThread="
							+ (this.ivActiveOnThread == null ? "null" : this.ivActiveOnThread.getId()));
		}

		if (this.eligibleForLock(methodContext, tx)) {
			this.ivActiveOnThread = Thread.currentThread();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "lock : true");
			}

			return true;
		} else {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "lock : false");
			}

			return false;
		}
	}

	boolean eligibleForLock(EJSDeployedSupport methodContext, ContainerTx tx) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (this.ivActiveOnThread != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "eligibleForLock : ActiveOnThread : " + (this.ivActiveOnThread == Thread.currentThread()));
			}

			return this.ivActiveOnThread == Thread.currentThread();
		} else if (this.currentTx != null && this.currentTx != tx) {
			UOWCookie uowCookie = methodContext.uowCookie;
			if (uowCookie != null && this.currentTx.ivTxKey.equals(uowCookie.getSuspendedTransactionalUOW())) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "eligibleForLock : SuspendedTx : true");
				}

				return true;
			} else {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "eligibleForLock : false");
				}

				return false;
			}
		} else {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "eligibleForLock : CurrentTx : true");
			}

			return true;
		}
	}

	public void addLockWaiter() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "addLockWaiter : " + this + ", thread=" + Thread.currentThread().getId());
		}

		this.ivThreadsWaiting = true;
	}

	public final void unlock(Object lockObject) {
		if (this.eligibleForUnlock()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "unlock(" + lockObject + ") : " + this + ":waiters=" + this.ivThreadsWaiting
						+ ":ActiveOnThread=" + this.ivActiveOnThread);
			}

			if (this.ivThreadsWaiting) {
				lockObject.notifyAll();
				this.ivThreadsWaiting = false;
			}

			this.ivActiveOnThread = null;
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc,
					"unlock(" + lockObject + ") : " + this + " : nothing to do for state " + StateStrs[this.state]);
		}

	}

	protected abstract boolean eligibleForUnlock();

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		StateStrs = new String[]{"DESTROYED", "PRE_CREATE", "CREATING", "METHOD_READY", "IN_METHOD", "TX_METHOD_READY",
				"TX_IN_METHOD", "COMMITTING_OUTSIDE_METHOD", "COMMITTING_IN_METHOD", "PASSIVATING", "PASSIVATED",
				"ACTIVATING", "REMOVING", "AFTER_BEGIN", "AFTER_COMPLETION"};
	}
}