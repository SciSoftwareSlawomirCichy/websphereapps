package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_cs extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: Byla zjištěna nekonzistence úrovní sestavení instalovaných komponent klienta aplikačního serveru. Instalovaná úroveň sestavení komponenty klienta {0} ({1}) se liší od úrovně sestavení komponenty klienta {2} ({3})."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: Nekonzistence úrovní sestavení instalovaných komponent klienta aplikačního serveru brání dalšímu zpracování."},
			{"EXCP_CWSJE0003E", "CWSJE0003E: Nelze přistupovat k prostředku {1} z důvodu výjimky: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}