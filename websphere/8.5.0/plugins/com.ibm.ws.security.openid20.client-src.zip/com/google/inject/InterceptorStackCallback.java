package com.google.inject;

import com.google.inject.InterceptorStackCallback.InterceptedMethodInvocation;
import com.google.inject.internal.cglib.proxy.MethodInterceptor;
import com.google.inject.internal.cglib.proxy.MethodProxy;
import java.lang.reflect.Method;
import java.util.List;

class InterceptorStackCallback implements MethodInterceptor {
	final org.aopalliance.intercept.MethodInterceptor[] interceptors;
	final Method method;

	public InterceptorStackCallback(Method method, List<org.aopalliance.intercept.MethodInterceptor> interceptors) {
		this.method = method;
		this.interceptors = (org.aopalliance.intercept.MethodInterceptor[]) interceptors
				.toArray(new org.aopalliance.intercept.MethodInterceptor[interceptors.size()]);
	}

	public Object intercept(Object proxy, Method method, Object[] arguments, MethodProxy methodProxy) throws Throwable {
		return (new InterceptedMethodInvocation(this, proxy, methodProxy, arguments)).proceed();
	}
}