package com.ibm.ws.wim.pluginmanager;

import java.util.Iterator;
import java.util.Vector;

public class ExitPointExecList {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String emitterName;
	private String name;
	private Vector modificationSubList;
	private Vector notificationSubList;
	private static String newline = System.getProperty("line.separator");

	public ExitPointExecList(String var1) {
		this.emitterName = var1;
		this.modificationSubList = new Vector();
		this.notificationSubList = new Vector();
	}

	public void addModificationSubscriber(SubscriberRealmInfo var1) {
		this.modificationSubList.add(var1);
	}

	public void addNotificationSubscriber(SubscriberRealmInfo var1) {
		this.notificationSubList.add(var1);
	}

	public Vector getModificationList() {
		return this.modificationSubList;
	}

	public String getName() {
		return this.name;
	}

	public Vector getNotificationList() {
		return this.notificationSubList;
	}

	public void setName(String var1) {
		this.name = var1;
	}

	public String printExitPointExecList() {
		StringBuffer var1 = new StringBuffer();
		var1.append(" ExitPointName: ").append(this.name).append(newline);
		Iterator var2;
		SubscriberRealmInfo var3;
		if (this.notificationSubList.size() > 0) {
			var1.append("\tNotificationList --->" + newline);
			var2 = this.notificationSubList.iterator();

			while (var2.hasNext()) {
				var3 = (SubscriberRealmInfo) var2.next();
				var1.append("\t\t").append(var3.printSubscriberRealmInfo());
			}

			var1.append("\tNotificationList <---" + newline);
		} else {
			var1.append("\tNotificationList is empty." + newline);
		}

		if (this.modificationSubList.size() > 0) {
			var1.append("\tModificationList --->" + newline);
			var2 = this.modificationSubList.iterator();

			while (var2.hasNext()) {
				var3 = (SubscriberRealmInfo) var2.next();
				var1.append("\t\t").append(var3.printSubscriberRealmInfo());
			}

			var1.append("\tModificationList <---" + newline);
		} else {
			var1.append("\tModificationList is empty." + newline);
		}

		return var1.toString();
	}
}