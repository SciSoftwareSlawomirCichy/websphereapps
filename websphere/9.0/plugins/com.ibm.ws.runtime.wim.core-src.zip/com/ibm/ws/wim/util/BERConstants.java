package com.ibm.ws.wim.util;

interface BERConstants {
	int UNIVERSAL_TAG_CODE = 0;
	int APPLICATION_TAG_CODE = 64;
	int CONTEXT_TAG_CODE = 128;
	int PRIVATE_TAG_CODE = 192;
	int BER_TAG_CLASS_MASK = 192;
	boolean PRIMITIVE = false;
	boolean CONSTRUCTED = true;
	int CONSTRUCTED_BIT = 32;
	int BIGTAGCODE = 31;
	int TAGMASK = 31;
	int MAXSMALLTAG = 30;
	int INDEFINITE_LEN = 128;
}