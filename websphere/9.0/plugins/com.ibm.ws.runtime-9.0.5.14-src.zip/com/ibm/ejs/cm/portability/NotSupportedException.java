package com.ibm.ejs.cm.portability;

public class NotSupportedException extends PortableSQLException {
	private static final long serialVersionUID = 5011500184425467748L;

	NotSupportedException() {
		super("Operation not supported by this database");
	}
}