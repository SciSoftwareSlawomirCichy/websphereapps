package javax.ws.rs.core;

import java.util.Date;
import java.util.List;
import javax.ws.rs.core.Response.ResponseBuilder;

public interface Request {
	ResponseBuilder evaluatePreconditions();

	ResponseBuilder evaluatePreconditions(Date var1);

	ResponseBuilder evaluatePreconditions(Date var1, EntityTag var2);

	ResponseBuilder evaluatePreconditions(EntityTag var1);

	String getMethod();

	Variant selectVariant(List<Variant> var1);
}