package com.google.common.base;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Predicates.1;
import com.google.common.base.Predicates.AndPredicate;
import com.google.common.base.Predicates.CompositionPredicate;
import com.google.common.base.Predicates.ContainsPatternFromStringPredicate;
import com.google.common.base.Predicates.ContainsPatternPredicate;
import com.google.common.base.Predicates.InPredicate;
import com.google.common.base.Predicates.InstanceOfPredicate;
import com.google.common.base.Predicates.IsEqualToPredicate;
import com.google.common.base.Predicates.NotPredicate;
import com.google.common.base.Predicates.ObjectPredicate;
import com.google.common.base.Predicates.OrPredicate;
import com.google.common.base.Predicates.SubtypeOfPredicate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
public final class Predicates {
	@GwtCompatible(serializable = true)
	public static <T> Predicate<T> alwaysTrue() {
		return ObjectPredicate.ALWAYS_TRUE.withNarrowedType();
	}

	@GwtCompatible(serializable = true)
	public static <T> Predicate<T> alwaysFalse() {
		return ObjectPredicate.ALWAYS_FALSE.withNarrowedType();
	}

	@GwtCompatible(serializable = true)
	public static <T> Predicate<T> isNull() {
		return ObjectPredicate.IS_NULL.withNarrowedType();
	}

	@GwtCompatible(serializable = true)
	public static <T> Predicate<T> notNull() {
		return ObjectPredicate.NOT_NULL.withNarrowedType();
	}

	public static <T> Predicate<T> not(Predicate<T> predicate) {
		return new NotPredicate(predicate);
	}

	public static <T> Predicate<T> and(Iterable<? extends Predicate<? super T>> components) {
      return new AndPredicate(defensiveCopy(components), (1)null);
   }

	@SafeVarargs
   public static <T> Predicate<T> and(Predicate... components) {
      return new AndPredicate(defensiveCopy((Object[])components), (1)null);
   }

	public static <T> Predicate<T> and(Predicate<? super T> first, Predicate<? super T> second) {
      return new AndPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), (1)null);
   }

	public static <T> Predicate<T> or(Iterable<? extends Predicate<? super T>> components) {
      return new OrPredicate(defensiveCopy(components), (1)null);
   }

	@SafeVarargs
   public static <T> Predicate<T> or(Predicate... components) {
      return new OrPredicate(defensiveCopy((Object[])components), (1)null);
   }

	public static <T> Predicate<T> or(Predicate<? super T> first, Predicate<? super T> second) {
      return new OrPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), (1)null);
   }

	public static <T> Predicate<T> equalTo(@NullableDecl T target) {
      return (Predicate)(target == null ? isNull() : new IsEqualToPredicate(target, (1)null));
   }

	@GwtIncompatible
   public static Predicate<Object> instanceOf(Class<?> clazz) {
      return new InstanceOfPredicate(clazz, (1)null);
   }

	@GwtIncompatible
   @Beta
   public static Predicate<Class<?>> subtypeOf(Class<?> clazz) {
      return new SubtypeOfPredicate(clazz, (1)null);
   }

	public static <T> Predicate<T> in(Collection<? extends T> target) {
      return new InPredicate(target, (1)null);
   }

	public static <A, B> Predicate<A> compose(Predicate<B> predicate, Function<A, ? extends B> function) {
      return new CompositionPredicate(predicate, function, (1)null);
   }

	@GwtIncompatible
	public static Predicate<CharSequence> containsPattern(String pattern) {
		return new ContainsPatternFromStringPredicate(pattern);
	}

	@GwtIncompatible("java.util.regex.Pattern")
	public static Predicate<CharSequence> contains(Pattern pattern) {
		return new ContainsPatternPredicate(new JdkPattern(pattern));
	}

	private static String toStringHelper(String methodName, Iterable<?> components) {
		StringBuilder builder = (new StringBuilder("Predicates.")).append(methodName).append('(');
		boolean first = true;

		for (Iterator var4 = components.iterator(); var4.hasNext(); first = false) {
			Object o = var4.next();
			if (!first) {
				builder.append(',');
			}

			builder.append(o);
		}

		return builder.append(')').toString();
	}

	private static <T> List<Predicate<? super T>> asList(Predicate<? super T> first, Predicate<? super T> second) {
		return Arrays.asList(first, second);
	}

	private static <T> List<T> defensiveCopy(T... array) {
		return defensiveCopy((Iterable) Arrays.asList(array));
	}

	static <T> List<T> defensiveCopy(Iterable<T> iterable) {
		ArrayList<T> list = new ArrayList();
		Iterator var2 = iterable.iterator();

		while (var2.hasNext()) {
			T element = var2.next();
			list.add(Preconditions.checkNotNull(element));
		}

		return list;
	}
}