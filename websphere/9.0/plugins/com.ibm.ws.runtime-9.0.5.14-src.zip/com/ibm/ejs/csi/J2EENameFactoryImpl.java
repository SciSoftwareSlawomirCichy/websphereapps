package com.ibm.ejs.csi;

import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.J2EENameFactory;

public class J2EENameFactoryImpl implements J2EENameFactory {
	public J2EEName create(byte[] bytes) {
		return new J2EENameImpl(bytes);
	}

	public J2EEName create(String app, String module, String component) {
		return new J2EENameImpl(app, module, component);
	}
}