package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.util.formatting.DateFormatProvider;
import java.io.PrintStream;
import java.text.DateFormat;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public abstract class IncidentSummaryLogger<T extends FfdcProvider> extends FfdcProviderDependent<T> {
	private int logIdx = -1;

	protected IncidentSummaryLogger(T provider) {
		super(provider);
	}

	protected int getLogIdx() {
		return this.logIdx;
	}

	protected abstract void log(List<Incident> var1);

	protected void logIncidentSummary(PrintStream ps, List<Incident> incidents) {
		try {
			try {
				ps.println();
				ps.println(
						" Index  Count  Time of first Occurrence    Time of last Occurrence     Exception SourceId ProbeId");
				ps.println(
						"------+------+---------------------------+---------------------------+---------------------------");
				int i = -1;
				Iterator i$ = incidents.iterator();

				while (i$.hasNext()) {
					Incident incident = (Incident) i$.next();
					++i;
					ps.println(this.formatIncidentEntry(incident, i));
				}

				this.logIdx = i;
			} catch (ConcurrentModificationException var6) {
				ps.println("incomplete  dump, see next entry for full table");
				this.ffdcerror(var6);
			}

			ps.println(
					"------+------+---------------------------+---------------------------+---------------------------");
		} catch (Throwable var7) {
			this.ffdcerror(var7);
		}

	}

	private String formatIncidentEntry(Incident entry, int index) {
		DateFormat formatter = this.getDateFormatter();
		String dateString = "";
		String firstDateString = "";
		Date date = new Date(entry.getTimeStamp());

		try {
			dateString = formatter.format(date);
			firstDateString = formatter.format(entry.getDateOfFirstOccurrence());
		} catch (Throwable var13) {
			this.ffdcerror(var13);
		}

		StringBuffer outputBuffer = new StringBuffer();
		Character firstChar = Character.valueOf((char) (index > this.logIdx ? '+' : ' '));
		String temp = String.valueOf(index);
		outputBuffer.append(firstChar);
		int length = 5 - temp.length();

		int fill;
		for (fill = 0; fill < length; ++fill) {
			outputBuffer.append(' ');
		}

		outputBuffer.append(temp);
		outputBuffer.append(' ');
		temp = String.valueOf(entry.getCount());
		length = 6 - temp.length();

		for (fill = 0; fill < length; ++fill) {
			outputBuffer.append(' ');
		}

		outputBuffer.append(temp);
		outputBuffer.append(' ');
		length = 27 - firstDateString.length();

		for (fill = 0; fill < length; ++fill) {
			outputBuffer.append(' ');
		}

		outputBuffer.append(firstDateString);
		outputBuffer.append(' ');
		length = 27 - dateString.length();

		for (fill = 0; fill < length; ++fill) {
			outputBuffer.append(' ');
		}

		outputBuffer.append(dateString);
		outputBuffer.append(' ');
		outputBuffer.append(entry.getExceptionName());
		outputBuffer.append(' ');
		outputBuffer.append(entry.getSourceId());
		outputBuffer.append(' ');
		outputBuffer.append(entry.getProbeId());
		String label = entry.getLabel();
		if (label != null) {
			outputBuffer.append(' ');
			outputBuffer.append(label);
		}

		return outputBuffer.toString();
	}

	protected DateFormat getDateFormatter() {
		return DateFormatProvider.getDateFormat();
	}
}