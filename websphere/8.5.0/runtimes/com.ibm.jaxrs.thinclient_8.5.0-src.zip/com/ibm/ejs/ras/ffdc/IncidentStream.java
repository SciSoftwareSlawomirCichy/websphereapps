package com.ibm.ejs.ras.ffdc;

import com.ibm.ffdc.config.IncidentStream.Writer;
import com.ibm.ffdc.util.bulkdata.CapacityException;
import com.ibm.ffdc.util.bulkdata.FixedCapacityOutputStream;
import java.io.OutputStream;

final class IncidentStream extends com.ibm.ffdc.util.provider.IncidentStream<FfdcProvider> {
	private final FixedCapacityOutputStream os;

	public IncidentStream(FfdcProvider provider, FixedCapacityOutputStream os) {
		super(provider, os);
		this.os = os;
	}

	public void write(String label, Writer<OutputStream> isWriter) {
		label = label == null ? null : label + "(encoder: " + isWriter.toString() + ")";

		try {
			isWriter.writeTo(this.os);
			this.write(label, new String(this.os.getBytes()));
		} catch (CapacityException var4) {
			this.write(label, "* * * FFDC output truncated here * * * ");
		} catch (Exception var5) {
			this.ffdcerror(var5);
		}

	}
}