package org.apache.commons.codec;

public interface Decoder {
	Object decode(Object var1) throws DecoderException;
}