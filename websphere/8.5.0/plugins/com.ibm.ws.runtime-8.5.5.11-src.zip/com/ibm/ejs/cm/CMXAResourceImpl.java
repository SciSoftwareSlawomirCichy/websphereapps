package com.ibm.ejs.cm;

import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;

public class CMXAResourceImpl implements XAResource {
	private static final TraceComponent tc = Tr.register(CMXAResourceImpl.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");
	XAResource theXARes = null;
	ConnectO theConnectO = null;
	boolean oraTransLoose;

	public CMXAResourceImpl(XAResource XAR, ConnectO connectO) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", new Object[]{XAR, connectO});
		}

		this.oraTransLoose = connectO.oraTransLoose;
		this.theXARes = XAR;
		this.theConnectO = connectO;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void commit(Xid xid, boolean onePhase) throws XAException {
		try {
			this.theXARes.commit(xid, onePhase);
		} catch (XAException var4) {
			if (var4.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var4;
		}
	}

	public void end(Xid xid, int flags) throws XAException {
		try {
			this.theXARes.end(xid, flags);
		} catch (XAException var4) {
			if (var4.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var4;
		}
	}

	public void forget(Xid xid) throws XAException {
		try {
			this.theXARes.forget(xid);
		} catch (XAException var3) {
			if (var3.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var3;
		}
	}

	public int getTransactionTimeout() throws XAException {
		try {
			return this.theXARes.getTransactionTimeout();
		} catch (XAException var2) {
			if (var2.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var2;
		}
	}

	public boolean isSameRM(XAResource xares) throws XAException {
		try {
			return this.theXARes.isSameRM(xares);
		} catch (XAException var3) {
			if (var3.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var3;
		}
	}

	public int prepare(Xid xid) throws XAException {
		try {
			return this.theXARes.prepare(xid);
		} catch (XAException var3) {
			if (var3.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var3;
		}
	}

	public Xid[] recover(int flag) throws XAException {
		try {
			return this.theXARes.recover(flag);
		} catch (XAException var3) {
			if (var3.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var3;
		}
	}

	public void rollback(Xid xid) throws XAException {
		try {
			this.theXARes.rollback(xid);
		} catch (XAException var3) {
			if (var3.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var3;
		}
	}

	public boolean setTransactionTimeout(int seconds) throws XAException {
		try {
			return this.theXARes.setTransactionTimeout(seconds);
		} catch (XAException var3) {
			if (var3.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var3;
		}
	}

	public void start(Xid xid, int flags) throws XAException {
		try {
			int modifiedFlags = flags;
			if (this.oraTransLoose) {
				modifiedFlags = flags | 65536;
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "returning (xaflag | OracleXAResource.ORATRANSLOOSE): ", new Integer(modifiedFlags));
				}
			}

			this.theXARes.start(xid, modifiedFlags);
		} catch (XAException var4) {
			if (var4.errorCode == -7) {
				this.handleRMFAIL();
			}

			throw var4;
		}
	}

	private void handleRMFAIL() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "handleRMFAIL");
		}

		this.theConnectO.setMaybeStale(true);
		this.theConnectO.getPool().destroyAllFreeConnections();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "handleRMFAIL");
		}

	}

	public String toString() {
		return this.theXARes.toString();
	}
}