package com.ibm.ws.wim.util;

import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.ws.wim.config.ConfigUtils;
import com.ibm.xml.crypto.util.Base64;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class PasswordEncryptionUtil {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = "com.ibm.ws.wim.util.PasswordEncryptionUtil";
	private static final Logger trcLogger = WIMLogger.getTraceLogger("com.ibm.ws.wim.util.PasswordEncryptionUtil");
	private static final int MAXIMUM_DBPASSWORD_LENGTH = 128;
	private static final int DES_KEY_STRING_LEN = 16;
	private static final int DES_KEY_SIZE = 8;
	private static final int TRIPLE_DES_KEY_SIZE = 24;
	private static final int CODE_LENGTH = 16;
	static CipherObjectPool CIPHER_POOL = null;
	private static final byte[] code = new byte[]{48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102};
	private static int salt_length = 12;

	public static byte[] formatPassword(byte[] var0) {
		byte[] var1 = new byte[128];
		byte var2 = 32;

		int var3;
		for (var3 = 0; var3 < 128; ++var3) {
			var1[var3] = var2;
		}

		if (var0 != null) {
			for (var3 = 0; var3 < var0.length; ++var3) {
				var1[var3] = var0[var3];
			}
		}

		return var1;
	}

	public static synchronized String hash(byte[] var0) {
		return hash(var0, "SHA");
	}

	public static synchronized String hash(byte[] var0, String var1) {
		Object var3 = null;

		byte[] var8;
		try {
			MessageDigest var4 = MessageDigest.getInstance(var1);
			var8 = var4.digest(var0);
		} catch (Exception var6) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"hash(byte[] byteText, String MDAlgorithm)",
						"SHA1-CIPHERINIT: Exception caught while initializing the cipher object using algorithm "
								+ var1);
			}

			return null;
		}

		String var9 = null;

		try {
			BASE64Encoder var5 = new BASE64Encoder();
			var9 = var5.encodeBuffer(var8);
		} catch (Exception var7) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"hash(byte[] byteText, String MDAlgorithm)", "Exception caught while base64 encoding.");
			}
		}

		return var9;
	}

	public static synchronized String hash(byte[] var0, String var1, String var2) {
		byte[] var4 = null;

		try {
			MessageDigest var5 = MessageDigest.getInstance(var1);
			long var6 = new Long(var2);

			for (long var8 = 0L; var8 < var6; ++var8) {
				var4 = var5.digest(var0);
				var0 = var4;
			}
		} catch (Exception var11) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"hash(byte[] byteText, String MDAlgorithm, String iter)",
						"SHA1-CIPHERINIT: Exception caught while initializing the cipher object using algorithm "
								+ var1);
			}

			return null;
		}

		String var12 = null;

		try {
			BASE64Encoder var13 = new BASE64Encoder();
			var12 = var13.encodeBuffer(var4);
		} catch (Exception var10) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"hash(byte[] byteText, String MDAlgorithm, String iter)",
						"Exception caught while base64 encoding.");
			}
		}

		return var12;
	}

	static void memcpy(byte[] var0, int var1, byte[] var2, int var3, int var4) {
		for (int var5 = 0; var5 < var4; ++var5) {
			var0[var5 + var1] = var2[var5 + var3];
		}

	}

	static void memset(byte[] var0, int var1, int var2) {
		for (int var3 = 0; var3 < var2; ++var3) {
			var0[var3] = (byte) var1;
		}

	}

	static int nc_decode_key(byte[] var0, byte[] var1) {
		int var4 = 0;

		for (int var3 = 0; var3 < 16; ++var4) {
			int var2;
			for (var2 = 0; code[var2] != var0[var3] && var2 < 16; ++var2) {
				;
			}

			if (var2 >= 16) {
				return 0;
			}

			var1[var4] = (byte) (var2 << 4);
			var2 = 0;
			++var3;

			while (code[var2] != var0[var3] && var2 < 16) {
				++var2;
			}

			if (var2 >= 16) {
				return 0;
			}

			var1[var4] |= (byte) var2;
			++var3;
		}

		return 1;
	}

	static void gen1(byte[] var0) {
		var0[0] = code[8];
		var0[1] = code[13];
		var0[2] = code[7];
		var0[3] = code[2];
		var0[4] = code[15];
		var0[5] = code[6];
		var0[6] = code[1];
		var0[7] = code[11];
		var0[8] = code[0];
		var0[9] = code[3];
		var0[10] = code[9];
		var0[11] = code[15];
		var0[12] = code[1];
		var0[13] = code[10];
		var0[14] = code[10];
		var0[15] = code[12];
	}

	static void gen2(byte[] var0) {
		var0[0] = code[3];
		var0[1] = code[11];
		var0[2] = code[10];
		var0[3] = code[3];
		var0[4] = code[15];
		var0[5] = code[1];
		var0[6] = code[9];
		var0[7] = code[5];
		var0[8] = code[1];
		var0[9] = code[13];
		var0[10] = code[2];
		var0[11] = code[11];
		var0[12] = code[5];
		var0[13] = code[13];
		var0[14] = code[15];
		var0[15] = code[3];
	}

	static void gen3(byte[] var0) {
		var0[0] = code[11];
		var0[1] = code[1];
		var0[2] = code[4];
		var0[3] = code[8];
		var0[4] = code[6];
		var0[5] = code[15];
		var0[6] = code[2];
		var0[7] = code[11];
		var0[8] = code[0];
		var0[9] = code[13];
		var0[10] = code[2];
		var0[11] = code[11];
		var0[12] = code[15];
		var0[13] = code[10];
		var0[14] = code[12];
		var0[15] = code[0];
	}

	private static byte[] createKey(byte[] var0) {
		byte[] var1 = new byte[24];
		nc_decode_key(var0, var1);
		byte[] var2 = new byte[16];
		gen2(var2);
		byte[] var3 = new byte[16];
		nc_decode_key(var2, var3);
		memcpy(var1, 8, var3, 0, 8);
		memset(var2, 0, 8);
		byte[] var4 = new byte[16];
		gen3(var4);
		byte[] var5 = new byte[16];
		nc_decode_key(var4, var5);
		memcpy(var1, 16, var5, 0, 8);
		memset(var4, 0, 8);
		return var1;
	}

	public static String encrypt(String var0, String var1) throws WIMSystemException {
		Cipher var3 = null;
		IvParameterSpec var4 = null;
		Object var5 = null;
		Object var6 = null;
		byte[] var7 = new byte[]{-2, -36, -70, 33, -112, 67, -121, 101};
		byte[] var8 = new byte[16];
		if (var1 != null) {
			var8 = PasswordUtil.getByteArrayPassword(var1);
		} else {
			gen1(var8);
		}

		byte[] var16 = PasswordUtil.getByteArrayPassword(var0);
		SecretKey var9 = null;

		try {
			byte[] var10 = createKey(var8);
			DESedeKeySpec var11 = new DESedeKeySpec(var10);
			SecretKeyFactory var12 = SecretKeyFactory.getInstance("DESede");
			var9 = var12.generateSecret(var11);
			var3 = (Cipher) CIPHER_POOL.checkout();
			var4 = new IvParameterSpec(var7);
		} catch (Exception var14) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"encrypt( String text, String user_key )",
						"%3DES-F-CIPHERINIT; Exception caught while initializing the cipher object.");
			}

			return null;
		}

		byte[] var17;
		int var20;
		try {
			var3.init(1, var9, var4);
			var17 = new byte[var3.getOutputSize(var16.length)];
			int var18 = var3.update(var16, 0, var16.length, var17, 0);
			var20 = var3.doFinal(var17, var18);
			CIPHER_POOL.checkin(var3);
			int var10000 = var18 + var20;
		} catch (Exception var13) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"encrypt( String text, String user_key )",
						"%3DES-F-NCRYPT; Exception caught while encrypting.");
			}

			return null;
		}

		String var19 = null;

		try {
			BASE64Encoder var21 = new BASE64Encoder();
			var19 = var21.encodeBuffer(var17);
		} catch (Exception var15) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"encrypt( String text, String user_key )", "Exception caught while base64 encoding.");
			}
		}

		for (var20 = 0; var20 < var16.length; ++var20) {
			var16[var20] = 0;
		}

		for (var20 = 0; var20 < var17.length; ++var20) {
			var17[var20] = 0;
		}

		return var19.trim();
	}

	public static String decrypt(String var0, String var1) throws WIMSystemException {
		Cipher var3 = null;
		IvParameterSpec var4 = null;
		byte[] var5 = null;
		Object var6 = null;
		byte[] var7 = new byte[]{-2, -36, -70, 33, -112, 67, -121, 101};
		byte[] var8 = new byte[16];
		if (var1 != null) {
			var8 = PasswordUtil.getByteArrayPassword(var1);
		} else {
			gen1(var8);
		}

		BASE64Decoder var9;
		try {
			var9 = new BASE64Decoder();
			var5 = var9.decodeBuffer(var0);
		} catch (Exception var16) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"decrypt( String text, String user_key )", "Exception caught while base64 decoding.");
			}
		}

		var9 = null;

		SecretKey var18;
		try {
			byte[] var10 = createKey(var8);
			DESedeKeySpec var11 = new DESedeKeySpec(var10);
			SecretKeyFactory var12 = SecretKeyFactory.getInstance("DESede");
			var18 = var12.generateSecret(var11);
			var3 = (Cipher) CIPHER_POOL.checkout();
			var4 = new IvParameterSpec(var7);
		} catch (Exception var13) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"decrypt( String text, String user_key )",
						"%3DES-F-CIPHERINIT; Exception caught while initializing the cipher object.");
			}

			return null;
		}

		byte[] var17;
		int var19;
		int var20;
		try {
			var17 = new byte[var5.length];
			var3.init(2, var18, var4);
			var19 = var3.update(var5, 0, var5.length, var17, 0);
			var20 = var3.doFinal(var17, var19);
			CIPHER_POOL.checkin(var3);
			int var10000 = var19 + var20;
		} catch (Exception var14) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"decrypt( String text, String user_key )", "%3DES-F-DCRYPT; Exception caught while decrypting");
			}

			return null;
		}

		for (var19 = 0; var19 < var5.length; ++var19) {
			var5[var19] = 0;
		}

		String var21 = null;

		try {
			var21 = new String(var17, "UTF-8");
		} catch (UnsupportedEncodingException var15) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil",
						"decrypt( String text, String user_key )", "Unable to convert string to UTF-8 format");
			}
		}

		for (var20 = 0; var20 < var17.length; ++var20) {
			var17[var20] = 0;
		}

		return var21.trim();
	}

	public static void setSaltLength(int var0) {
		salt_length = var0;
	}

	public static String generateSalt(int var0) {
		String var1 = "abcdefghijklmnoprstuvxyz1234567890";
		int var2 = var1.length();
		StringBuffer var3 = new StringBuffer();
		Random var4 = new Random();
		boolean var5 = false;

		for (int var6 = 0; var6 < var0; ++var6) {
			int var7 = var4.nextInt() % var2;
			if (var7 < 0) {
				var7 = -var7;
			}

			var3.append(var1.charAt(var7));
		}

		return var3.toString();
	}

	public static byte[] getSaltedTextBytes(String var0, byte[] var1) throws WIMSystemException {
		byte[] var2 = PasswordUtil.getByteArrayPassword(var0);
		int var3 = var2.length;
		int var4 = var1.length;
		byte[] var5 = new byte[var3 + var4];

		int var6;
		for (var6 = 0; var6 < var3; ++var6) {
			var5[var6] = var2[var6];
		}

		for (var6 = 0; var6 < var4; ++var6) {
			var5[var3 + var6] = var1[var6];
		}

		return var5;
	}

	public static boolean isPbkdf2(String var0) {
		return "PBKDF2WithHmacSHA1".equalsIgnoreCase(var0);
	}

	public static List<String> getSupportedHashingAlgorithms() {
		return ConfigUtils.convertArrayToList(ConfigConstants.CONFIG_SUPPORTED_MDALGORITHMS);
	}

	public static byte[] generateSaltPbkdf2(int var0) {
		SecureRandom var1 = new SecureRandom();
		byte[] var2 = new byte[var0];
		var1.nextBytes(var2);
		return var2;
	}

	public static String hashPbkdf2(String var0, String var1, String var2, byte[] var3, char[] var4) {
		Object var6 = null;
		PBEKeySpec var7 = null;

		byte[] var14;
		try {
			int var8 = new Integer(var1);
			int var9 = new Integer(var2);
			var7 = new PBEKeySpec(var4, var3, var8, var9 * 8);
			var14 = SecretKeyFactory.getInstance(var0).generateSecret(var7).getEncoded();
		} catch (NoSuchAlgorithmException var10) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil", "hashPbkdf2",
						"Exception caught while initializing the SecretKeyFactory object using algorithm " + var0,
						var10);
			}

			return null;
		} catch (InvalidKeySpecException var11) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil", "hashPbkdf2",
						"Exception caught while generating the SecretKey object using PBEKeySpec " + var7, var11);
			}

			return null;
		} catch (NumberFormatException var12) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil", "hashPbkdf2",
						"Exception caught while converting hashing iterations (" + var1 + ") or hashing key size ("
								+ var2 + ") to an integer value",
						var12);
			}

			return null;
		}

		String var15 = null;

		try {
			var15 = (new BASE64Encoder()).encodeBuffer(var14);
		} catch (Exception var13) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, "com.ibm.ws.wim.util.PasswordEncryptionUtil", "hashPbkdf2",
						"Exception caught while base64 encoding.");
			}
		}

		return var15;
	}

	public static String hashPbkdf2(byte[] var0, String var1, String var2, String var3, String var4) {
		byte[] var5 = Base64.decode(var1);
		char[] var6 = null;

		try {
			var6 = (new String(var0, "UTF-8")).toCharArray();
		} catch (UnsupportedEncodingException var9) {
			;
		}

		String var7 = hashPbkdf2(var2, var3, var4, var5, var6);
		StringBuffer var8 = new StringBuffer(var2);
		var8.append(":");
		var8.append(var3);
		var8.append(":");
		var8.append(var1);
		var8.append(":");
		var8.append(var4);
		var8.append(":");
		var8.append(var7);
		return var8.toString();
	}

	static {
		int var0 = 120000;

		try {
			var0 = new Integer(System.getProperty("wcpool.timeout"));
			if (var0 < 10) {
				throw new Exception();
			}
		} catch (Exception var2) {
			var0 = 120000;
		}

		CIPHER_POOL = new CipherObjectPool("com.ibm.commerce.util.wrapper.nc_cryptx", (long) var0);
	}
}