package com.ibm.websphere.crypto;

public class UnsupportedCryptoAlgorithmException extends Exception {
	private static final long serialVersionUID = -3262361821411281060L;
}