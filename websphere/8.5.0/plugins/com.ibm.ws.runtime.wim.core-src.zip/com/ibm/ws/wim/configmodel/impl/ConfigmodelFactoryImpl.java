package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.AttributeConfigurationType;
import com.ibm.ws.wim.configmodel.AttributeGroupType;
import com.ibm.ws.wim.configmodel.AttributeType;
import com.ibm.ws.wim.configmodel.AttributesCacheType;
import com.ibm.ws.wim.configmodel.AuthorizationType;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.CacheConfigurationType;
import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.ContextPoolType;
import com.ibm.ws.wim.configmodel.CustomPropertiesType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.configmodel.DocumentRoot;
import com.ibm.ws.wim.configmodel.DynamicMemberAttributesType;
import com.ibm.ws.wim.configmodel.DynamicModelType;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import com.ibm.ws.wim.configmodel.EnvironmentPropertiesType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.GroupConfigurationType;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.LdapEntityTypesType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.MemberAttributesType;
import com.ibm.ws.wim.configmodel.MembershipAttributeType;
import com.ibm.ws.wim.configmodel.ModificationSubscriber;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import com.ibm.ws.wim.configmodel.NotificationSubscriber;
import com.ibm.ws.wim.configmodel.NotificationSubscriberList;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.PostExit;
import com.ibm.ws.wim.configmodel.PreExit;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.PropertiesNotSupportedType;
import com.ibm.ws.wim.configmodel.PropertyExtensionRepositoryType;
import com.ibm.ws.wim.configmodel.RdnAttributesType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmDefaultParentType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.configmodel.SPIBridgeRepositoryType;
import com.ibm.ws.wim.configmodel.SearchResultsCacheType;
import com.ibm.ws.wim.configmodel.StaticModelType;
import com.ibm.ws.wim.configmodel.SubscriberType;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import com.ibm.ws.wim.configmodel.TopicSubscriber;
import com.ibm.ws.wim.configmodel.TopicSubscriberList;
import com.ibm.ws.wim.configmodel.UserRegistryInfoMappingType;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

public class ConfigmodelFactoryImpl extends EFactoryImpl implements ConfigmodelFactory {
	public EObject create(EClass var1) {
		switch (var1.getClassifierID()) {
			case 0 :
				return (EObject) this.createAttributeConfigurationType();
			case 1 :
				return (EObject) this.createAttributeGroupType();
			case 2 :
				return (EObject) this.createAttributesCacheType();
			case 3 :
				return (EObject) this.createAttributeType();
			case 4 :
				return (EObject) this.createAuthorizationType();
			case 5 :
				return (EObject) this.createBaseEntriesType();
			case 6 :
				return (EObject) this.createCacheConfigurationType();
			case 7 :
				return (EObject) this.createConfigurationProviderType();
			case 8 :
				return (EObject) this.createConnectionsType();
			case 9 :
				return (EObject) this.createContextPoolType();
			case 10 :
				return (EObject) this.createCustomPropertiesType();
			case 11 :
				return (EObject) this.createDatabaseRepositoryType();
			case 12 :
				return (EObject) this.createDocumentRoot();
			case 13 :
				return (EObject) this.createDynamicMemberAttributesType();
			case 14 :
				return (EObject) this.createDynamicModelType();
			case 15 :
				return (EObject) this.createEntryMappingRepositoryType();
			case 16 :
				return (EObject) this.createEnvironmentPropertiesType();
			case 17 :
				return (EObject) this.createFileRepositoryType();
			case 18 :
				return (EObject) this.createGroupConfigurationType();
			case 19 :
				return (EObject) this.createInlineExit();
			case 20 :
				return (EObject) this.createLdapEntityTypesType();
			case 21 :
				return (EObject) this.createLdapRepositoryType();
			case 22 :
				return (EObject) this.createLdapServerConfigurationType();
			case 23 :
				return (EObject) this.createLdapServersType();
			case 24 :
				return (EObject) this.createMemberAttributesType();
			case 25 :
				return (EObject) this.createMembershipAttributeType();
			case 26 :
				return (EObject) this.createModificationSubscriber();
			case 27 :
				return (EObject) this.createModificationSubscriberList();
			case 28 :
				return (EObject) this.createNotificationSubscriber();
			case 29 :
				return (EObject) this.createNotificationSubscriberList();
			case 30 :
				return (EObject) this.createParticipatingBaseEntriesType();
			case 31 :
				return (EObject) this.createPluginManagerConfigurationType();
			case 32 :
				return (EObject) this.createPostExit();
			case 33 :
				return (EObject) this.createPreExit();
			case 34 :
				return (EObject) this.createProfileRepositoryType();
			case 35 :
				return (EObject) this.createPropertiesNotSupportedType();
			case 36 :
				return (EObject) this.createPropertyExtensionRepositoryType();
			case 37 :
				return (EObject) this.createRdnAttributesType();
			case 38 :
				return (EObject) this.createRealmConfigurationType();
			case 39 :
				return (EObject) this.createRealmDefaultParentType();
			case 40 :
				return (EObject) this.createRealmType();
			case 41 :
				return (EObject) this.createRepositoryType();
			case 42 :
				return (EObject) this.createSearchResultsCacheType();
			case 43 :
				return (EObject) this.createSPIBridgeRepositoryType();
			case 44 :
				return (EObject) this.createStaticModelType();
			case 45 :
				return (EObject) this.createSupportedEntityTypesType();
			case 46 :
				return (EObject) this.createTopicEmitter();
			case 47 :
				return (EObject) this.createTopicRegistrationList();
			case 48 :
				return (EObject) this.createTopicSubscriber();
			case 49 :
				return (EObject) this.createTopicSubscriberList();
			case 50 :
				return (EObject) this.createUserRegistryInfoMappingType();
			default :
				throw new IllegalArgumentException("The class '" + var1.getName() + "' is not a valid classifier");
		}
	}

	public Object createFromString(EDataType var1, String var2) {
		switch (var1.getClassifierID()) {
			case 51 :
				SubscriberType var3 = SubscriberType.get(var2);
				if (var3 == null) {
					throw new IllegalArgumentException(
							"The value '" + var2 + "' is not a valid enumerator of '" + var1.getName() + "'");
				}

				return var3;
			case 52 :
				return this.createCacheSizeLimitTypeFromString(var1, var2);
			case 53 :
				return this.createCacheSizeLimitTypeObjectFromString(var1, var2);
			case 54 :
				return this.createCacheSizeTypeFromString(var1, var2);
			case 55 :
				return this.createCacheSizeTypeObjectFromString(var1, var2);
			case 56 :
				return this.createCacheTimeOutTypeFromString(var1, var2);
			case 57 :
				return this.createCacheTimeOutTypeObjectFromString(var1, var2);
			case 58 :
				return this.createDNTypeFromString(var1, var2);
			case 59 :
				return this.createInitPoolSizeTypeFromString(var1, var2);
			case 60 :
				return this.createInitPoolSizeTypeObjectFromString(var1, var2);
			case 61 :
				return this.createMaxPoolSizeTypeFromString(var1, var2);
			case 62 :
				return this.createMaxPoolSizeTypeObjectFromString(var1, var2);
			case 63 :
				return this.createPoolTimeOutTypeFromString(var1, var2);
			case 64 :
				return this.createPoolTimeOutTypeObjectFromString(var1, var2);
			case 65 :
				return this.createPoolWaitTimeTypeFromString(var1, var2);
			case 66 :
				return this.createPoolWaitTimeTypeObjectFromString(var1, var2);
			case 67 :
				return this.createPrefPoolSizeTypeFromString(var1, var2);
			case 68 :
				return this.createPrefPoolSizeTypeObjectFromString(var1, var2);
			case 69 :
				return this.createRealmListTypeFromString(var1, var2);
			case 70 :
				return this.createRealmListType1FromString(var1, var2);
			case 71 :
				return this.createSubscriberTypeObjectFromString(var1, var2);
			default :
				throw new IllegalArgumentException("The datatype '" + var1.getName() + "' is not a valid classifier");
		}
	}

	public String convertToString(EDataType var1, Object var2) {
		switch (var1.getClassifierID()) {
			case 51 :
				return var2 == null ? null : var2.toString();
			case 52 :
				return this.convertCacheSizeLimitTypeToString(var1, var2);
			case 53 :
				return this.convertCacheSizeLimitTypeObjectToString(var1, var2);
			case 54 :
				return this.convertCacheSizeTypeToString(var1, var2);
			case 55 :
				return this.convertCacheSizeTypeObjectToString(var1, var2);
			case 56 :
				return this.convertCacheTimeOutTypeToString(var1, var2);
			case 57 :
				return this.convertCacheTimeOutTypeObjectToString(var1, var2);
			case 58 :
				return this.convertDNTypeToString(var1, var2);
			case 59 :
				return this.convertInitPoolSizeTypeToString(var1, var2);
			case 60 :
				return this.convertInitPoolSizeTypeObjectToString(var1, var2);
			case 61 :
				return this.convertMaxPoolSizeTypeToString(var1, var2);
			case 62 :
				return this.convertMaxPoolSizeTypeObjectToString(var1, var2);
			case 63 :
				return this.convertPoolTimeOutTypeToString(var1, var2);
			case 64 :
				return this.convertPoolTimeOutTypeObjectToString(var1, var2);
			case 65 :
				return this.convertPoolWaitTimeTypeToString(var1, var2);
			case 66 :
				return this.convertPoolWaitTimeTypeObjectToString(var1, var2);
			case 67 :
				return this.convertPrefPoolSizeTypeToString(var1, var2);
			case 68 :
				return this.convertPrefPoolSizeTypeObjectToString(var1, var2);
			case 69 :
				return this.convertRealmListTypeToString(var1, var2);
			case 70 :
				return this.convertRealmListType1ToString(var1, var2);
			case 71 :
				return this.convertSubscriberTypeObjectToString(var1, var2);
			default :
				throw new IllegalArgumentException("The datatype '" + var1.getName() + "' is not a valid classifier");
		}
	}

	public AttributeConfigurationType createAttributeConfigurationType() {
		AttributeConfigurationTypeImpl var1 = new AttributeConfigurationTypeImpl();
		return var1;
	}

	public AttributeGroupType createAttributeGroupType() {
		AttributeGroupTypeImpl var1 = new AttributeGroupTypeImpl();
		return var1;
	}

	public AttributesCacheType createAttributesCacheType() {
		AttributesCacheTypeImpl var1 = new AttributesCacheTypeImpl();
		return var1;
	}

	public AttributeType createAttributeType() {
		AttributeTypeImpl var1 = new AttributeTypeImpl();
		return var1;
	}

	public AuthorizationType createAuthorizationType() {
		AuthorizationTypeImpl var1 = new AuthorizationTypeImpl();
		return var1;
	}

	public BaseEntriesType createBaseEntriesType() {
		BaseEntriesTypeImpl var1 = new BaseEntriesTypeImpl();
		return var1;
	}

	public CacheConfigurationType createCacheConfigurationType() {
		CacheConfigurationTypeImpl var1 = new CacheConfigurationTypeImpl();
		return var1;
	}

	public ConfigurationProviderType createConfigurationProviderType() {
		ConfigurationProviderTypeImpl var1 = new ConfigurationProviderTypeImpl();
		return var1;
	}

	public ConnectionsType createConnectionsType() {
		ConnectionsTypeImpl var1 = new ConnectionsTypeImpl();
		return var1;
	}

	public ContextPoolType createContextPoolType() {
		ContextPoolTypeImpl var1 = new ContextPoolTypeImpl();
		return var1;
	}

	public CustomPropertiesType createCustomPropertiesType() {
		CustomPropertiesTypeImpl var1 = new CustomPropertiesTypeImpl();
		return var1;
	}

	public DatabaseRepositoryType createDatabaseRepositoryType() {
		DatabaseRepositoryTypeImpl var1 = new DatabaseRepositoryTypeImpl();
		return var1;
	}

	public DocumentRoot createDocumentRoot() {
		DocumentRootImpl var1 = new DocumentRootImpl();
		return var1;
	}

	public DynamicMemberAttributesType createDynamicMemberAttributesType() {
		DynamicMemberAttributesTypeImpl var1 = new DynamicMemberAttributesTypeImpl();
		return var1;
	}

	public DynamicModelType createDynamicModelType() {
		DynamicModelTypeImpl var1 = new DynamicModelTypeImpl();
		return var1;
	}

	public EntryMappingRepositoryType createEntryMappingRepositoryType() {
		EntryMappingRepositoryTypeImpl var1 = new EntryMappingRepositoryTypeImpl();
		return var1;
	}

	public EnvironmentPropertiesType createEnvironmentPropertiesType() {
		EnvironmentPropertiesTypeImpl var1 = new EnvironmentPropertiesTypeImpl();
		return var1;
	}

	public FileRepositoryType createFileRepositoryType() {
		FileRepositoryTypeImpl var1 = new FileRepositoryTypeImpl();
		return var1;
	}

	public GroupConfigurationType createGroupConfigurationType() {
		GroupConfigurationTypeImpl var1 = new GroupConfigurationTypeImpl();
		return var1;
	}

	public InlineExit createInlineExit() {
		InlineExitImpl var1 = new InlineExitImpl();
		return var1;
	}

	public LdapEntityTypesType createLdapEntityTypesType() {
		LdapEntityTypesTypeImpl var1 = new LdapEntityTypesTypeImpl();
		return var1;
	}

	public LdapRepositoryType createLdapRepositoryType() {
		LdapRepositoryTypeImpl var1 = new LdapRepositoryTypeImpl();
		return var1;
	}

	public LdapServerConfigurationType createLdapServerConfigurationType() {
		LdapServerConfigurationTypeImpl var1 = new LdapServerConfigurationTypeImpl();
		return var1;
	}

	public LdapServersType createLdapServersType() {
		LdapServersTypeImpl var1 = new LdapServersTypeImpl();
		return var1;
	}

	public MemberAttributesType createMemberAttributesType() {
		MemberAttributesTypeImpl var1 = new MemberAttributesTypeImpl();
		return var1;
	}

	public MembershipAttributeType createMembershipAttributeType() {
		MembershipAttributeTypeImpl var1 = new MembershipAttributeTypeImpl();
		return var1;
	}

	public ModificationSubscriber createModificationSubscriber() {
		ModificationSubscriberImpl var1 = new ModificationSubscriberImpl();
		return var1;
	}

	public ModificationSubscriberList createModificationSubscriberList() {
		ModificationSubscriberListImpl var1 = new ModificationSubscriberListImpl();
		return var1;
	}

	public NotificationSubscriber createNotificationSubscriber() {
		NotificationSubscriberImpl var1 = new NotificationSubscriberImpl();
		return var1;
	}

	public NotificationSubscriberList createNotificationSubscriberList() {
		NotificationSubscriberListImpl var1 = new NotificationSubscriberListImpl();
		return var1;
	}

	public ParticipatingBaseEntriesType createParticipatingBaseEntriesType() {
		ParticipatingBaseEntriesTypeImpl var1 = new ParticipatingBaseEntriesTypeImpl();
		return var1;
	}

	public PluginManagerConfigurationType createPluginManagerConfigurationType() {
		PluginManagerConfigurationTypeImpl var1 = new PluginManagerConfigurationTypeImpl();
		return var1;
	}

	public PostExit createPostExit() {
		PostExitImpl var1 = new PostExitImpl();
		return var1;
	}

	public PreExit createPreExit() {
		PreExitImpl var1 = new PreExitImpl();
		return var1;
	}

	public ProfileRepositoryType createProfileRepositoryType() {
		ProfileRepositoryTypeImpl var1 = new ProfileRepositoryTypeImpl();
		return var1;
	}

	public PropertiesNotSupportedType createPropertiesNotSupportedType() {
		PropertiesNotSupportedTypeImpl var1 = new PropertiesNotSupportedTypeImpl();
		return var1;
	}

	public PropertyExtensionRepositoryType createPropertyExtensionRepositoryType() {
		PropertyExtensionRepositoryTypeImpl var1 = new PropertyExtensionRepositoryTypeImpl();
		return var1;
	}

	public RdnAttributesType createRdnAttributesType() {
		RdnAttributesTypeImpl var1 = new RdnAttributesTypeImpl();
		return var1;
	}

	public RealmConfigurationType createRealmConfigurationType() {
		RealmConfigurationTypeImpl var1 = new RealmConfigurationTypeImpl();
		return var1;
	}

	public RealmDefaultParentType createRealmDefaultParentType() {
		RealmDefaultParentTypeImpl var1 = new RealmDefaultParentTypeImpl();
		return var1;
	}

	public RealmType createRealmType() {
		RealmTypeImpl var1 = new RealmTypeImpl();
		return var1;
	}

	public RepositoryType createRepositoryType() {
		RepositoryTypeImpl var1 = new RepositoryTypeImpl();
		return var1;
	}

	public SearchResultsCacheType createSearchResultsCacheType() {
		SearchResultsCacheTypeImpl var1 = new SearchResultsCacheTypeImpl();
		return var1;
	}

	public SPIBridgeRepositoryType createSPIBridgeRepositoryType() {
		SPIBridgeRepositoryTypeImpl var1 = new SPIBridgeRepositoryTypeImpl();
		return var1;
	}

	public StaticModelType createStaticModelType() {
		StaticModelTypeImpl var1 = new StaticModelTypeImpl();
		return var1;
	}

	public SupportedEntityTypesType createSupportedEntityTypesType() {
		SupportedEntityTypesTypeImpl var1 = new SupportedEntityTypesTypeImpl();
		return var1;
	}

	public TopicEmitter createTopicEmitter() {
		TopicEmitterImpl var1 = new TopicEmitterImpl();
		return var1;
	}

	public TopicRegistrationList createTopicRegistrationList() {
		TopicRegistrationListImpl var1 = new TopicRegistrationListImpl();
		return var1;
	}

	public TopicSubscriber createTopicSubscriber() {
		TopicSubscriberImpl var1 = new TopicSubscriberImpl();
		return var1;
	}

	public TopicSubscriberList createTopicSubscriberList() {
		TopicSubscriberListImpl var1 = new TopicSubscriberListImpl();
		return var1;
	}

	public UserRegistryInfoMappingType createUserRegistryInfoMappingType() {
		UserRegistryInfoMappingTypeImpl var1 = new UserRegistryInfoMappingTypeImpl();
		return var1;
	}

	public Integer createCacheSizeLimitTypeFromString(EDataType var1, String var2) {
		return (Integer) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public String convertCacheSizeLimitTypeToString(EDataType var1, Object var2) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public Integer createCacheSizeLimitTypeObjectFromString(EDataType var1, String var2) {
		return (Integer) ConfigmodelFactory.eINSTANCE
				.createFromString(ConfigmodelPackage.eINSTANCE.getCacheSizeLimitType(), var2);
	}

	public String convertCacheSizeLimitTypeObjectToString(EDataType var1, Object var2) {
		return ConfigmodelFactory.eINSTANCE.convertToString(ConfigmodelPackage.eINSTANCE.getCacheSizeLimitType(), var2);
	}

	public Integer createCacheSizeTypeFromString(EDataType var1, String var2) {
		return (Integer) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public String convertCacheSizeTypeToString(EDataType var1, Object var2) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public Integer createCacheSizeTypeObjectFromString(EDataType var1, String var2) {
		return (Integer) ConfigmodelFactory.eINSTANCE.createFromString(ConfigmodelPackage.eINSTANCE.getCacheSizeType(),
				var2);
	}

	public String convertCacheSizeTypeObjectToString(EDataType var1, Object var2) {
		return ConfigmodelFactory.eINSTANCE.convertToString(ConfigmodelPackage.eINSTANCE.getCacheSizeType(), var2);
	}

	public Integer createCacheTimeOutTypeFromString(EDataType var1, String var2) {
		return (Integer) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public String convertCacheTimeOutTypeToString(EDataType var1, Object var2) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public Integer createCacheTimeOutTypeObjectFromString(EDataType var1, String var2) {
		return (Integer) ConfigmodelFactory.eINSTANCE
				.createFromString(ConfigmodelPackage.eINSTANCE.getCacheTimeOutType(), var2);
	}

	public String convertCacheTimeOutTypeObjectToString(EDataType var1, Object var2) {
		return ConfigmodelFactory.eINSTANCE.convertToString(ConfigmodelPackage.eINSTANCE.getCacheTimeOutType(), var2);
	}

	public String createDNTypeFromString(EDataType var1, String var2) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getString(), var2);
	}

	public String convertDNTypeToString(EDataType var1, Object var2) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getString(), var2);
	}

	public Integer createInitPoolSizeTypeFromString(EDataType var1, String var2) {
		return (Integer) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public String convertInitPoolSizeTypeToString(EDataType var1, Object var2) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public Integer createInitPoolSizeTypeObjectFromString(EDataType var1, String var2) {
		return (Integer) ConfigmodelFactory.eINSTANCE
				.createFromString(ConfigmodelPackage.eINSTANCE.getInitPoolSizeType(), var2);
	}

	public String convertInitPoolSizeTypeObjectToString(EDataType var1, Object var2) {
		return ConfigmodelFactory.eINSTANCE.convertToString(ConfigmodelPackage.eINSTANCE.getInitPoolSizeType(), var2);
	}

	public Integer createMaxPoolSizeTypeFromString(EDataType var1, String var2) {
		return (Integer) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public String convertMaxPoolSizeTypeToString(EDataType var1, Object var2) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public Integer createMaxPoolSizeTypeObjectFromString(EDataType var1, String var2) {
		return (Integer) ConfigmodelFactory.eINSTANCE
				.createFromString(ConfigmodelPackage.eINSTANCE.getMaxPoolSizeType(), var2);
	}

	public String convertMaxPoolSizeTypeObjectToString(EDataType var1, Object var2) {
		return ConfigmodelFactory.eINSTANCE.convertToString(ConfigmodelPackage.eINSTANCE.getMaxPoolSizeType(), var2);
	}

	public Integer createPoolTimeOutTypeFromString(EDataType var1, String var2) {
		return (Integer) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public String convertPoolTimeOutTypeToString(EDataType var1, Object var2) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public Integer createPoolTimeOutTypeObjectFromString(EDataType var1, String var2) {
		return (Integer) ConfigmodelFactory.eINSTANCE
				.createFromString(ConfigmodelPackage.eINSTANCE.getPoolTimeOutType(), var2);
	}

	public String convertPoolTimeOutTypeObjectToString(EDataType var1, Object var2) {
		return ConfigmodelFactory.eINSTANCE.convertToString(ConfigmodelPackage.eINSTANCE.getPoolTimeOutType(), var2);
	}

	public Integer createPoolWaitTimeTypeFromString(EDataType var1, String var2) {
		return (Integer) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public String convertPoolWaitTimeTypeToString(EDataType var1, Object var2) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public Integer createPoolWaitTimeTypeObjectFromString(EDataType var1, String var2) {
		return (Integer) ConfigmodelFactory.eINSTANCE
				.createFromString(ConfigmodelPackage.eINSTANCE.getPoolWaitTimeType(), var2);
	}

	public String convertPoolWaitTimeTypeObjectToString(EDataType var1, Object var2) {
		return ConfigmodelFactory.eINSTANCE.convertToString(ConfigmodelPackage.eINSTANCE.getPoolWaitTimeType(), var2);
	}

	public Integer createPrefPoolSizeTypeFromString(EDataType var1, String var2) {
		return (Integer) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public String convertPrefPoolSizeTypeToString(EDataType var1, Object var2) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getInt(), var2);
	}

	public Integer createPrefPoolSizeTypeObjectFromString(EDataType var1, String var2) {
		return (Integer) ConfigmodelFactory.eINSTANCE
				.createFromString(ConfigmodelPackage.eINSTANCE.getPrefPoolSizeType(), var2);
	}

	public String convertPrefPoolSizeTypeObjectToString(EDataType var1, Object var2) {
		return ConfigmodelFactory.eINSTANCE.convertToString(ConfigmodelPackage.eINSTANCE.getPrefPoolSizeType(), var2);
	}

	public List createRealmListTypeFromString(EDataType var1, String var2) {
		if (var2 == null) {
			return null;
		} else {
			ArrayList var3 = new ArrayList();
			StringTokenizer var4 = new StringTokenizer(var2);

			while (var4.hasMoreTokens()) {
				String var5 = var4.nextToken();
				var3.add(XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getString(), var5));
			}

			return var3;
		}
	}

	public String convertRealmListTypeToString(EDataType var1, Object var2) {
		if (var2 == null) {
			return null;
		} else {
			List var3 = (List) var2;
			if (var3.isEmpty()) {
				return "";
			} else {
				StringBuffer var4 = new StringBuffer();
				Iterator var5 = var3.iterator();

				while (var5.hasNext()) {
					var4.append(XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getString(),
							var5.next()));
					var4.append(' ');
				}

				return var4.substring(0, var4.length() - 1);
			}
		}
	}

	public List createRealmListType1FromString(EDataType var1, String var2) {
		if (var2 == null) {
			return null;
		} else {
			ArrayList var3 = new ArrayList();
			StringTokenizer var4 = new StringTokenizer(var2);

			while (var4.hasMoreTokens()) {
				String var5 = var4.nextToken();
				var3.add(XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getString(), var5));
			}

			return var3;
		}
	}

	public String convertRealmListType1ToString(EDataType var1, Object var2) {
		if (var2 == null) {
			return null;
		} else {
			List var3 = (List) var2;
			if (var3.isEmpty()) {
				return "";
			} else {
				StringBuffer var4 = new StringBuffer();
				Iterator var5 = var3.iterator();

				while (var5.hasNext()) {
					var4.append(XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.eINSTANCE.getString(),
							var5.next()));
					var4.append(' ');
				}

				return var4.substring(0, var4.length() - 1);
			}
		}
	}

	public SubscriberType createSubscriberTypeObjectFromString(EDataType var1, String var2) {
		return (SubscriberType) ConfigmodelFactory.eINSTANCE
				.createFromString(ConfigmodelPackage.eINSTANCE.getSubscriberType(), var2);
	}

	public String convertSubscriberTypeObjectToString(EDataType var1, Object var2) {
		return ConfigmodelFactory.eINSTANCE.convertToString(ConfigmodelPackage.eINSTANCE.getSubscriberType(), var2);
	}

	public ConfigmodelPackage getConfigmodelPackage() {
		return (ConfigmodelPackage) this.getEPackage();
	}

	public static ConfigmodelPackage getPackage() {
		return ConfigmodelPackage.eINSTANCE;
	}
}