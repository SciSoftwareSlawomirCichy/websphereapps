package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;

@GwtCompatible(serializable = true, emulated = true)
public final class LinkedHashMultiset<E> extends AbstractMapBasedMultiset<E> {
	public static <E> LinkedHashMultiset<E> create() {
		return create(3);
	}

	public static <E> LinkedHashMultiset<E> create(int distinctElements) {
		return new LinkedHashMultiset(distinctElements);
	}

	public static <E> LinkedHashMultiset<E> create(Iterable<? extends E> elements) {
		LinkedHashMultiset<E> multiset = create(Multisets.inferDistinctElements(elements));
		Iterables.addAll(multiset, elements);
		return multiset;
	}

	LinkedHashMultiset(int distinctElements) {
		super(distinctElements);
	}

	void init(int distinctElements) {
		this.backingMap = new ObjectCountLinkedHashMap(distinctElements);
	}
}