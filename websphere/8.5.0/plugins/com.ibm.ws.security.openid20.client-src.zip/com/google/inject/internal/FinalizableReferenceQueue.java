package com.google.inject.internal;

import com.google.inject.internal.FinalizableReferenceQueue.DecoupledLoader;
import com.google.inject.internal.FinalizableReferenceQueue.DirectLoader;
import com.google.inject.internal.FinalizableReferenceQueue.FinalizerLoader;
import com.google.inject.internal.FinalizableReferenceQueue.SystemLoader;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FinalizableReferenceQueue {
	private static final Logger logger = Logger.getLogger(FinalizableReferenceQueue.class.getName());
	private static final String FINALIZER_CLASS_NAME = "com.google.inject.internal.Finalizer";
	private static final Method startFinalizer;
	final ReferenceQueue<Object> queue;
	final boolean threadStarted;

	public FinalizableReferenceQueue() {
		boolean threadStarted = false;

		ReferenceQueue queue;
		try {
			queue = (ReferenceQueue) startFinalizer.invoke((Object) null, FinalizableReference.class, this);
			threadStarted = true;
		} catch (IllegalAccessException var4) {
			throw new AssertionError(var4);
		} catch (Throwable var5) {
			logger.log(Level.INFO,
					"Failed to start reference finalizer thread. Reference cleanup will only occur when new references are created.",
					var5);
			queue = new ReferenceQueue();
		}

		this.queue = queue;
		this.threadStarted = threadStarted;
	}

	void cleanUp() {
		if (!this.threadStarted) {
			Reference reference;
			while ((reference = this.queue.poll()) != null) {
				reference.clear();

				try {
					((FinalizableReference) reference).finalizeReferent();
				} catch (Throwable var3) {
					logger.log(Level.SEVERE, "Error cleaning up after reference.", var3);
				}
			}

		}
	}

	private static Class<?> loadFinalizer(FinalizerLoader... loaders) {
		FinalizerLoader[] arr$ = loaders;
		int len$ = loaders.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			FinalizerLoader loader = arr$[i$];
			Class<?> finalizer = loader.loadFinalizer();
			if (finalizer != null) {
				return finalizer;
			}
		}

		throw new AssertionError();
	}

	static Method getStartFinalizer(Class<?> finalizer) {
		try {
			return finalizer.getMethod("startFinalizer", Class.class, Object.class);
		} catch (NoSuchMethodException var2) {
			throw new AssertionError(var2);
		}
	}

	static {
		Class<?> finalizer = loadFinalizer(new SystemLoader(), new DecoupledLoader(), new DirectLoader());
		startFinalizer = getStartFinalizer(finalizer);
	}
}