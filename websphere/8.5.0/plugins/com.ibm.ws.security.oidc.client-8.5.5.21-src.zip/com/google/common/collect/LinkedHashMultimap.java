package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.LinkedHashMultimap.1;
import com.google.common.collect.LinkedHashMultimap.ValueEntry;
import com.google.common.collect.LinkedHashMultimap.ValueSet;
import com.google.common.collect.LinkedHashMultimap.ValueSetLink;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
public final class LinkedHashMultimap<K, V> extends LinkedHashMultimapGwtSerializationDependencies<K, V> {
	private static final int DEFAULT_KEY_CAPACITY = 16;
	private static final int DEFAULT_VALUE_SET_CAPACITY = 2;
	@VisibleForTesting
	static final double VALUE_SET_LOAD_FACTOR = 1.0D;
	@VisibleForTesting
	transient int valueSetCapacity = 2;
	private transient ValueEntry<K, V> multimapHeaderEntry;
	@GwtIncompatible
	private static final long serialVersionUID = 1L;

	public static <K, V> LinkedHashMultimap<K, V> create() {
		return new LinkedHashMultimap(16, 2);
	}

	public static <K, V> LinkedHashMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey) {
		return new LinkedHashMultimap(Maps.capacity(expectedKeys), Maps.capacity(expectedValuesPerKey));
	}

	public static <K, V> LinkedHashMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap) {
		LinkedHashMultimap<K, V> result = create(multimap.keySet().size(), 2);
		result.putAll(multimap);
		return result;
	}

	private static <K, V> void succeedsInValueSet(ValueSetLink<K, V> pred, ValueSetLink<K, V> succ) {
		pred.setSuccessorInValueSet(succ);
		succ.setPredecessorInValueSet(pred);
	}

	private static <K, V> void succeedsInMultimap(ValueEntry<K, V> pred, ValueEntry<K, V> succ) {
		pred.setSuccessorInMultimap(succ);
		succ.setPredecessorInMultimap(pred);
	}

	private static <K, V> void deleteFromValueSet(ValueSetLink<K, V> entry) {
		succeedsInValueSet(entry.getPredecessorInValueSet(), entry.getSuccessorInValueSet());
	}

	private static <K, V> void deleteFromMultimap(ValueEntry<K, V> entry) {
		succeedsInMultimap(entry.getPredecessorInMultimap(), entry.getSuccessorInMultimap());
	}

	private LinkedHashMultimap(int keyCapacity, int valueSetCapacity) {
		super(Platform.newLinkedHashMapWithExpectedSize(keyCapacity));
		CollectPreconditions.checkNonnegative(valueSetCapacity, "expectedValuesPerKey");
		this.valueSetCapacity = valueSetCapacity;
		this.multimapHeaderEntry = new ValueEntry((Object) null, (Object) null, 0, (ValueEntry) null);
		succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
	}

	Set<V> createCollection() {
		return Platform.newLinkedHashSetWithExpectedSize(this.valueSetCapacity);
	}

	Collection<V> createCollection(K key) {
		return new ValueSet(this, key, this.valueSetCapacity);
	}

	@CanIgnoreReturnValue
	public Set<V> replaceValues(@NullableDecl K key, Iterable<? extends V> values) {
		return super.replaceValues(key, values);
	}

	public Set<Entry<K, V>> entries() {
		return super.entries();
	}

	public Set<K> keySet() {
		return super.keySet();
	}

	public Collection<V> values() {
		return super.values();
	}

	Iterator<Entry<K, V>> entryIterator() {
      return new 1(this);
   }

	Iterator<V> valueIterator() {
		return Maps.valueIterator(this.entryIterator());
	}

	public void clear() {
		super.clear();
		succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
	}

	@GwtIncompatible
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		stream.writeInt(this.keySet().size());
		Iterator var2 = this.keySet().iterator();

		while (var2.hasNext()) {
			K key = var2.next();
			stream.writeObject(key);
		}

		stream.writeInt(this.size());
		var2 = this.entries().iterator();

		while (var2.hasNext()) {
			Entry<K, V> entry = (Entry) var2.next();
			stream.writeObject(entry.getKey());
			stream.writeObject(entry.getValue());
		}

	}

	@GwtIncompatible
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		this.multimapHeaderEntry = new ValueEntry((Object) null, (Object) null, 0, (ValueEntry) null);
		succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
		this.valueSetCapacity = 2;
		int distinctKeys = stream.readInt();
		Map<K, Collection<V>> map = Platform.newLinkedHashMapWithExpectedSize(12);

		int entries;
		for (entries = 0; entries < distinctKeys; ++entries) {
			K key = stream.readObject();
			map.put(key, this.createCollection(key));
		}

		entries = stream.readInt();

		for (int i = 0; i < entries; ++i) {
			K key = stream.readObject();
			V value = stream.readObject();
			((Collection) map.get(key)).add(value);
		}

		this.setMap(map);
	}
}