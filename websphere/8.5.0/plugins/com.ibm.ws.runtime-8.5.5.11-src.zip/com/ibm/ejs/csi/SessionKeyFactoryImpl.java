package com.ibm.ejs.csi;

import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.StatefulSessionKey;
import com.ibm.websphere.csi.StatefulSessionKeyFactory;
import com.ibm.ws.util.UUID;

public class SessionKeyFactoryImpl implements StatefulSessionKeyFactory {
	public StatefulSessionKey create() throws CSIException {
		UUID uuid = new UUID();
		return new StatefulSessionKeyImpl(uuid);
	}

	public StatefulSessionKey create(byte[] bytes) throws CSIException {
		return new StatefulSessionKeyImpl(new UUID(bytes));
	}
}