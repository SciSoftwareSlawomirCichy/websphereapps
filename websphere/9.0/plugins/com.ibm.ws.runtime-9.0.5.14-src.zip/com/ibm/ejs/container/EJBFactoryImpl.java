package com.ibm.ejs.container;

import com.ibm.websphere.ejbcontainer.EJBFactory;
import java.rmi.RemoteException;
import javax.ejb.EJBException;

public class EJBFactoryImpl extends EJSRemoteWrapper implements EJBFactory {
	private final EJBLinkResolver ejbLinkResolver;

	public EJBFactoryImpl(EJBLinkResolver ejbLinkResolver) {
		this.ejbLinkResolver = ejbLinkResolver;
	}

	public Object create(String application, String beanName, String interfaceName)
			throws EJBException, RemoteException {
		return this.ejbLinkResolver.create(application, beanName, interfaceName);
	}

	public Object create(String application, String module, String beanName, String interfaceName)
			throws EJBException, RemoteException {
		return this.ejbLinkResolver.create(application, module, beanName, interfaceName);
	}

	public Object findByBeanName(String application, String beanName, String interfaceName)
			throws EJBException, RemoteException {
		return this.ejbLinkResolver.findByBeanName(application, beanName, interfaceName);
	}

	public Object findByInterface(String application, String interfaceName) throws EJBException, RemoteException {
		return this.ejbLinkResolver.findByInterface(application, interfaceName);
	}
}