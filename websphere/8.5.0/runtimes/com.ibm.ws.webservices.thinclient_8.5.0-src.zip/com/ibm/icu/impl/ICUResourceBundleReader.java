package com.ibm.icu.impl;

import com.ibm.icu.impl.ICUBinary.Authenticate;
import com.ibm.icu.impl.ICUResourceBundleReader.Array;
import com.ibm.icu.impl.ICUResourceBundleReader.Array16;
import com.ibm.icu.impl.ICUResourceBundleReader.ByteSequence;
import com.ibm.icu.impl.ICUResourceBundleReader.Container;
import com.ibm.icu.impl.ICUResourceBundleReader.Table;
import com.ibm.icu.impl.ICUResourceBundleReader.Table16;
import com.ibm.icu.impl.ICUResourceBundleReader.Table1632;
import com.ibm.icu.impl.ICUResourceBundleReader.Table32;
import com.ibm.icu.util.VersionInfo;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public final class ICUResourceBundleReader implements Authenticate {
	private static final byte[] DATA_FORMAT_ID = new byte[]{82, 101, 115, 66};
	private static final int URES_INDEX_LENGTH = 0;
	private static final int URES_INDEX_KEYS_TOP = 1;
	private static final int URES_INDEX_BUNDLE_TOP = 3;
	private static final int URES_INDEX_ATTRIBUTES = 5;
	private static final int URES_INDEX_16BIT_TOP = 6;
	private static final int URES_INDEX_POOL_CHECKSUM = 7;
	private static final int URES_ATT_NO_FALLBACK = 1;
	private static final int URES_ATT_IS_POOL_BUNDLE = 2;
	private static final int URES_ATT_USES_POOL_BUNDLE = 4;
	private static final boolean DEBUG = false;
	private byte[] dataVersion;
	private String s16BitUnits;
	private byte[] poolBundleKeys;
	private String poolBundleKeysAsString;
	private int rootRes;
	private int localKeyLimit;
	private boolean noFallback;
	private boolean isPoolBundle;
	private boolean usesPoolBundle;
	private int[] indexes;
	private byte[] keyStrings;
	private String keyStringsAsString;
	private byte[] resourceBytes;
	private int resourceBottom;
	private static byte[] emptyBytes = new byte[0];
	private static ByteBuffer emptyByteBuffer = ByteBuffer.allocate(0).asReadOnlyBuffer();
	private static char[] emptyChars = new char[0];
	private static int[] emptyInts = new int[0];
	private static String emptyString = "";

	private ICUResourceBundleReader(InputStream stream, String resolvedName) {
		BufferedInputStream bs = new BufferedInputStream(stream);

		try {
			this.dataVersion = ICUBinary.readHeader(bs, DATA_FORMAT_ID, this);
			this.readData(bs);
			stream.close();
		} catch (IOException var5) {
			throw new RuntimeException("Data file " + resolvedName + " is corrupt - " + var5.getMessage());
		}
	}

	static ICUResourceBundleReader getReader(String resolvedName, ClassLoader root) {
		InputStream stream = ICUData.getStream(root, resolvedName);
		if (stream == null) {
			return null;
		} else {
			ICUResourceBundleReader reader = new ICUResourceBundleReader(stream, resolvedName);
			return reader;
		}
	}

	void setPoolBundleKeys(ICUResourceBundleReader poolBundleReader) {
		if (!poolBundleReader.isPoolBundle) {
			throw new IllegalStateException("pool.res is not a pool bundle");
		} else if (poolBundleReader.indexes[7] != this.indexes[7]) {
			throw new IllegalStateException("pool.res has a different checksum than this bundle");
		} else {
			this.poolBundleKeys = poolBundleReader.keyStrings;
			this.poolBundleKeysAsString = poolBundleReader.keyStringsAsString;
		}
	}

	private void readData(InputStream stream) throws IOException {
		DataInputStream ds = new DataInputStream(stream);
		this.rootRes = ds.readInt();
		int indexes0 = ds.readInt();
		int indexLength = indexes0 & 255;
		this.indexes = new int[indexLength];
		this.indexes[0] = indexes0;

		int length;
		for (length = 1; length < indexLength; ++length) {
			this.indexes[length] = ds.readInt();
		}

		this.resourceBottom = 1 + indexLength << 2;
		if (indexLength > 5) {
			length = this.indexes[5];
			this.noFallback = (length & 1) != 0;
			this.isPoolBundle = (length & 2) != 0;
			this.usesPoolBundle = (length & 4) != 0;
		}

		length = this.indexes[3] * 4;
		int keysBottom;
		if (this.indexes[1] > 1 + indexLength) {
			keysBottom = 1 + indexLength << 2;
			int keysTop = this.indexes[1] << 2;
			this.resourceBottom = keysTop;
			if (this.isPoolBundle) {
				keysTop -= keysBottom;
				keysBottom = 0;
			} else {
				this.localKeyLimit = keysTop;
			}

			this.keyStrings = new byte[keysTop];
			ds.readFully(this.keyStrings, keysBottom, keysTop - keysBottom);
			if (this.isPoolBundle) {
				while (keysBottom < keysTop && this.keyStrings[keysTop - 1] == -86) {
					--keysTop;
					this.keyStrings[keysTop] = 0;
				}

				this.keyStringsAsString = new String(this.keyStrings, "US-ASCII");
			}
		}

		if (indexLength > 6 && this.indexes[6] > this.indexes[1]) {
			keysBottom = (this.indexes[6] - this.indexes[1]) * 2;
			char[] c16BitUnits = new char[keysBottom];

			for (int i = 0; i < keysBottom; ++i) {
				c16BitUnits[i] = ds.readChar();
			}

			this.s16BitUnits = new String(c16BitUnits);
			this.resourceBottom = this.indexes[6] << 2;
		} else {
			this.s16BitUnits = " ";
		}

		this.resourceBytes = new byte[length - this.resourceBottom];
		ds.readFully(this.resourceBytes);
	}

	VersionInfo getVersion() {
		return VersionInfo.getInstance(this.dataVersion[0], this.dataVersion[1], this.dataVersion[2],
				this.dataVersion[3]);
	}

	public boolean isDataVersionAcceptable(byte[] version) {
		return version[0] == 1 && version[1] >= 1 || version[0] == 2;
	}

	int getRootResource() {
		return this.rootRes;
	}

	boolean getNoFallback() {
		return this.noFallback;
	}

	boolean getUsesPoolBundle() {
		return this.usesPoolBundle;
	}

	static int RES_GET_TYPE(int res) {
		return res >>> 28;
	}

	private static int RES_GET_OFFSET(int res) {
		return res & 268435455;
	}

	private int getResourceByteOffset(int offset) {
		return (offset << 2) - this.resourceBottom;
	}

	static int RES_GET_INT(int res) {
		return res << 4 >> 4;
	}

	static int RES_GET_UINT(int res) {
		return res & 268435455;
	}

	static boolean URES_IS_TABLE(int type) {
		return type == 2 || type == 5 || type == 4;
	}

	private char getChar(int offset) {
		return (char) (this.resourceBytes[offset] << 8 | this.resourceBytes[offset + 1] & 255);
	}

	private char[] getChars(int offset, int count) {
		char[] chars = new char[count];

		for (int i = 0; i < count; ++i) {
			chars[i] = (char) (this.resourceBytes[offset] << 8 | this.resourceBytes[offset + 1] & 255);
			offset += 2;
		}

		return chars;
	}

	private int getInt(int offset) {
		return this.resourceBytes[offset] << 24 | (this.resourceBytes[offset + 1] & 255) << 16
				| (this.resourceBytes[offset + 2] & 255) << 8 | this.resourceBytes[offset + 3] & 255;
	}

	private int[] getInts(int offset, int count) {
		int[] ints = new int[count];

		for (int i = 0; i < count; ++i) {
			ints[i] = this.resourceBytes[offset] << 24 | (this.resourceBytes[offset + 1] & 255) << 16
					| (this.resourceBytes[offset + 2] & 255) << 8 | this.resourceBytes[offset + 3] & 255;
			offset += 4;
		}

		return ints;
	}

	private char[] getTable16KeyOffsets(int offset) {
		int length = this.s16BitUnits.charAt(offset++);
		return length > 0 ? this.s16BitUnits.substring(offset, offset + length).toCharArray() : emptyChars;
	}

	private char[] getTableKeyOffsets(int offset) {
		int length = this.getChar(offset);
		return length > 0 ? this.getChars(offset + 2, length) : emptyChars;
	}

	private int[] getTable32KeyOffsets(int offset) {
		int length = this.getInt(offset);
		return length > 0 ? this.getInts(offset + 4, length) : emptyInts;
	}

	private String makeKeyStringFromBytes(int keyOffset) {
		StringBuilder sb = new StringBuilder();

		byte b;
		while ((b = this.keyStrings[keyOffset++]) != 0) {
			sb.append((char) b);
		}

		return sb.toString();
	}

	private String makeKeyStringFromString(int keyOffset) {
		int endOffset;
		for (endOffset = keyOffset; this.poolBundleKeysAsString.charAt(endOffset) != 0; ++endOffset) {
			;
		}

		return this.poolBundleKeysAsString.substring(keyOffset, endOffset);
	}

	private ByteSequence RES_GET_KEY16(char keyOffset) {
		return keyOffset < this.localKeyLimit
				? new ByteSequence(this.keyStrings, keyOffset)
				: new ByteSequence(this.poolBundleKeys, keyOffset - this.localKeyLimit);
	}

	private String getKey16String(int keyOffset) {
		return keyOffset < this.localKeyLimit
				? this.makeKeyStringFromBytes(keyOffset)
				: this.makeKeyStringFromString(keyOffset - this.localKeyLimit);
	}

	private ByteSequence RES_GET_KEY32(int keyOffset) {
		return keyOffset >= 0
				? new ByteSequence(this.keyStrings, keyOffset)
				: new ByteSequence(this.poolBundleKeys, keyOffset & Integer.MAX_VALUE);
	}

	private String getKey32String(int keyOffset) {
		return keyOffset >= 0
				? this.makeKeyStringFromBytes(keyOffset)
				: this.makeKeyStringFromString(keyOffset & Integer.MAX_VALUE);
	}

	private static int compareKeys(CharSequence key, ByteSequence tableKey) {
		int i;
		for (i = 0; i < key.length(); ++i) {
			int c2 = tableKey.charAt(i);
			if (c2 == 0) {
				return 1;
			}

			int diff = key.charAt(i) - c2;
			if (diff != 0) {
				return diff;
			}
		}

		return -tableKey.charAt(i);
	}

	private int compareKeys(CharSequence key, char keyOffset) {
		return compareKeys(key, this.RES_GET_KEY16(keyOffset));
	}

	private int compareKeys32(CharSequence key, int keyOffset) {
		return compareKeys(key, this.RES_GET_KEY32(keyOffset));
	}

	String getString(int res) {
		int offset = RES_GET_OFFSET(res);
		int length;
		if (RES_GET_TYPE(res) != 6) {
			if (res == offset) {
				if (res == 0) {
					return emptyString;
				} else {
					offset = this.getResourceByteOffset(offset);
					length = this.getInt(offset);
					return new String(this.getChars(offset + 4, length));
				}
			} else {
				return null;
			}
		} else {
			int first = this.s16BitUnits.charAt(offset);
			if ((first & -1024) == 56320) {
				if (first < '?') {
					length = first & 1023;
					++offset;
				} else if (first < '?') {
					length = first - '?' << 16 | this.s16BitUnits.charAt(offset + 1);
					offset += 2;
				} else {
					length = this.s16BitUnits.charAt(offset + 1) << 16 | this.s16BitUnits.charAt(offset + 2);
					offset += 3;
				}

				return this.s16BitUnits.substring(offset, offset + length);
			} else if (first == 0) {
				return emptyString;
			} else {
				int endOffset;
				for (endOffset = offset + 1; this.s16BitUnits.charAt(endOffset) != 0; ++endOffset) {
					;
				}

				return this.s16BitUnits.substring(offset, endOffset);
			}
		}
	}

	String getAlias(int res) {
		int offset = RES_GET_OFFSET(res);
		if (RES_GET_TYPE(res) == 3) {
			if (offset == 0) {
				return emptyString;
			} else {
				offset = this.getResourceByteOffset(offset);
				int length = this.getInt(offset);
				return new String(this.getChars(offset + 4, length));
			}
		} else {
			return null;
		}
	}

	byte[] getBinary(int res, byte[] ba) {
		int offset = RES_GET_OFFSET(res);
		if (RES_GET_TYPE(res) == 1) {
			if (offset == 0) {
				return emptyBytes;
			} else {
				offset = this.getResourceByteOffset(offset);
				int length = this.getInt(offset);
				if (ba == null || ba.length != length) {
					ba = new byte[length];
				}

				System.arraycopy(this.resourceBytes, offset + 4, ba, 0, length);
				return ba;
			}
		} else {
			return null;
		}
	}

	ByteBuffer getBinary(int res) {
		int offset = RES_GET_OFFSET(res);
		if (RES_GET_TYPE(res) == 1) {
			if (offset == 0) {
				return emptyByteBuffer.duplicate();
			} else {
				offset = this.getResourceByteOffset(offset);
				int length = this.getInt(offset);
				return ByteBuffer.wrap(this.resourceBytes, offset + 4, length).slice().asReadOnlyBuffer();
			}
		} else {
			return null;
		}
	}

	int[] getIntVector(int res) {
		int offset = RES_GET_OFFSET(res);
		if (RES_GET_TYPE(res) == 14) {
			if (offset == 0) {
				return emptyInts;
			} else {
				offset = this.getResourceByteOffset(offset);
				int length = this.getInt(offset);
				return this.getInts(offset + 4, length);
			}
		} else {
			return null;
		}
	}

	Container getArray(int res) {
		int type = RES_GET_TYPE(res);
		int offset = RES_GET_OFFSET(res);
		switch (type) {
			case 8 :
			case 9 :
				if (offset == 0) {
					return new Container(this);
				} else {
					switch (type) {
						case 8 :
							return new Array(this, offset);
						case 9 :
							return new Array16(this, offset);
						default :
							return null;
					}
				}
			default :
				return null;
		}
	}

	Table getTable(int res) {
		int type = RES_GET_TYPE(res);
		int offset = RES_GET_OFFSET(res);
		switch (type) {
			case 2 :
			case 4 :
			case 5 :
				if (offset == 0) {
					return new Table(this);
				} else {
					switch (type) {
						case 2 :
							return new Table1632(this, offset);
						case 3 :
						default :
							return null;
						case 4 :
							return new Table32(this, offset);
						case 5 :
							return new Table16(this, offset);
					}
				}
			case 3 :
			default :
				return null;
		}
	}
}