package com.ibm.ejs.cm;

import com.ibm.ws.Transaction.XAResourceInfo;

public class CMXAResourceInfo implements XAResourceInfo {
	private static final long serialVersionUID = 7652776456356859276L;
	private DataSourceProperties dsProps;

	public CMXAResourceInfo(DataSourceProperties dsProps) {
		this.dsProps = null;
		this.dsProps = dsProps;
	}

	public CMXAResourceInfo(CMProperties cmProps) {
		this(((CMPropertiesImpl) cmProps).getDataSourceProperties());
	}

	public DataSourceProperties getDataSourceProperties() {
		return this.dsProps;
	}

	public String toString() {
		return "CMXAResourceInfo: " + this.dsProps;
	}

	public String getRMName() {
		String rmName = null;
		if (this.dsProps != null) {
			rmName = this.dsProps.getProperty("databaseName");
		}

		return rmName;
	}

	public boolean equals(Object o) {
		if (this == o) {
			return true;
		} else {
			try {
				CMXAResourceInfo other = (CMXAResourceInfo) o;
				return this.dsProps.equals(other.dsProps);
			} catch (ClassCastException var3) {
				return false;
			}
		}
	}

	public boolean commitInLastPhase() {
		return false;
	}
}