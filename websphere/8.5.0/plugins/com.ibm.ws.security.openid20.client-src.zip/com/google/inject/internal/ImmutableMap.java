package com.google.inject.internal;

import com.google.inject.internal.ImmutableMap.1;
import com.google.inject.internal.ImmutableMap.Builder;
import com.google.inject.internal.ImmutableMap.SerializedForm;
import com.google.inject.internal.ImmutableMap.RegularImmutableMap.EntrySet;
import com.google.inject.internal.ImmutableMap.RegularImmutableMap.KeySet;
import com.google.inject.internal.ImmutableMap.RegularImmutableMap.Values;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentMap;

public abstract class ImmutableMap<K, V> implements ConcurrentMap<K, V>, Serializable {
	private static final ImmutableMap<?, ?> EMPTY_IMMUTABLE_MAP = new ImmutableMap.EmptyImmutableMap((1)null);

	public static <K, V> ImmutableMap<K, V> of() {
		return EMPTY_IMMUTABLE_MAP;
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1) {
      return new ImmutableMap.SingletonImmutableMap(Preconditions.checkNotNull(k1), Preconditions.checkNotNull(v1), (1)null);
   }

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2) {
      return new ImmutableMap.RegularImmutableMap(new Entry[]{entryOf(k1, v1), entryOf(k2, v2)}, (1)null);
   }

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
      return new ImmutableMap.RegularImmutableMap(new Entry[]{entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3)}, (1)null);
   }

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
      return new ImmutableMap.RegularImmutableMap(new Entry[]{entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4)}, (1)null);
   }

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
      return new ImmutableMap.RegularImmutableMap(new Entry[]{entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5)}, (1)null);
   }

	public static <K, V> Builder<K, V> builder() {
		return new Builder();
	}

	private static <K, V> Entry<K, V> entryOf(K key, V value) {
		return Maps.immutableEntry(Preconditions.checkNotNull(key), Preconditions.checkNotNull(value));
	}

	public static <K, V> ImmutableMap<K, V> copyOf(Map<? extends K, ? extends V> map) {
      if (map instanceof ImmutableMap) {
         ImmutableMap<K, V> kvMap = (ImmutableMap)map;
         return kvMap;
      } else {
         int size = map.size();
         switch(size) {
         case 0:
            return of();
         case 1:
            Entry<? extends K, ? extends V> loneEntry = (Entry)Iterables.getOnlyElement(map.entrySet());
            return of(loneEntry.getKey(), loneEntry.getValue());
         default:
            Entry<?, ?>[] array = new Entry[size];
            int i = 0;

            Entry entry;
            for(Iterator i$ = map.entrySet().iterator(); i$.hasNext(); array[i++] = entryOf(entry.getKey(), entry.getValue())) {
               entry = (Entry)i$.next();
            }

            return new ImmutableMap.RegularImmutableMap(array, (1)null);
         }
      }
   }

	public final V put(K k, V v) {
		throw new UnsupportedOperationException();
	}

	public final V remove(Object o) {
		throw new UnsupportedOperationException();
	}

	public final V putIfAbsent(K key, V value) {
		throw new UnsupportedOperationException();
	}

	public final boolean remove(Object key, Object value) {
		throw new UnsupportedOperationException();
	}

	public final boolean replace(K key, V oldValue, V newValue) {
		throw new UnsupportedOperationException();
	}

	public final V replace(K key, V value) {
		throw new UnsupportedOperationException();
	}

	public final void putAll(Map<? extends K, ? extends V> map) {
		throw new UnsupportedOperationException();
	}

	public final void clear() {
		throw new UnsupportedOperationException();
	}

	public abstract boolean containsKey(@Nullable Object var1);

	public abstract boolean containsValue(@Nullable Object var1);

	public abstract V get(@Nullable Object var1);

	public abstract ImmutableSet<Entry<K, V>> entrySet();

	public abstract ImmutableSet<K> keySet();

	public abstract ImmutableCollection<V> values();

	public boolean equals(@Nullable Object object) {
		if (object == this) {
			return true;
		} else if (object instanceof Map) {
			Map<?, ?> that = (Map) object;
			return this.entrySet().equals(that.entrySet());
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.entrySet().hashCode();
	}

	public String toString() {
		StringBuilder result = (new StringBuilder(this.size() * 16)).append('{');
		Iterator<Entry<K, V>> entries = this.entrySet().iterator();
		result.append(entries.next());

		while (entries.hasNext()) {
			result.append(", ").append(entries.next());
		}

		return result.append('}').toString();
	}

	Object writeReplace() {
		return new SerializedForm(this);
	}

	private static final class RegularImmutableMap<K, V> extends ImmutableMap<K, V> {
		private final transient Entry<K, V>[] entries;
		private final transient Object[] table;
		private final transient int mask;
		private final transient int keySetHashCode;
		private transient ImmutableSet<Entry<K, V>> entrySet;
		private transient ImmutableSet<K> keySet;
		private transient ImmutableCollection<V> values;

		private RegularImmutableMap(Entry... entries) {
			Entry<K, V>[] tmp = (Entry[]) entries;
			this.entries = tmp;
			int tableSize = Hashing.chooseTableSize(entries.length);
			this.table = new Object[tableSize * 2];
			this.mask = tableSize - 1;
			int keySetHashCodeMutable = 0;
			Entry<K, V>[] arr$ = this.entries;
			int len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				Entry<K, V> entry = arr$[i$];
				K key = entry.getKey();
				int keyHashCode = key.hashCode();
				int i = Hashing.smear(keyHashCode);

				while (true) {
					int index = (i & this.mask) * 2;
					Object existing = this.table[index];
					if (existing == null) {
						V value = entry.getValue();
						this.table[index] = key;
						this.table[index + 1] = value;
						keySetHashCodeMutable += keyHashCode;
						break;
					}

					if (existing.equals(key)) {
						throw new IllegalArgumentException("duplicate key: " + key);
					}

					++i;
				}
			}

			this.keySetHashCode = keySetHashCodeMutable;
		}

		public V get(Object key) {
			if (key == null) {
				return null;
			} else {
				int i = Hashing.smear(key.hashCode());

				while (true) {
					int index = (i & this.mask) * 2;
					Object candidate = this.table[index];
					if (candidate == null) {
						return null;
					}

					if (candidate.equals(key)) {
						V value = this.table[index + 1];
						return value;
					}

					++i;
				}
			}
		}

		public int size() {
			return this.entries.length;
		}

		public boolean isEmpty() {
			return false;
		}

		public boolean containsKey(Object key) {
			return this.get(key) != null;
		}

		public boolean containsValue(Object value) {
			if (value == null) {
				return false;
			} else {
				Entry<K, V>[] arr$ = this.entries;
				int len$ = arr$.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					Entry<K, V> entry = arr$[i$];
					if (entry.getValue().equals(value)) {
						return true;
					}
				}

				return false;
			}
		}

		public ImmutableSet<Entry<K, V>> entrySet() {
			ImmutableSet<Entry<K, V>> es = this.entrySet;
			return es == null ? (this.entrySet = new EntrySet(this)) : es;
		}

		public ImmutableSet<K> keySet() {
			ImmutableSet<K> ks = this.keySet;
			return ks == null ? (this.keySet = new KeySet(this)) : ks;
		}

		public ImmutableCollection<V> values() {
			ImmutableCollection<V> v = this.values;
			return v == null ? (this.values = new Values(this)) : v;
		}

		public String toString() {
			StringBuilder result = (new StringBuilder(this.size() * 16)).append('{').append(this.entries[0]);

			for (int e = 1; e < this.entries.length; ++e) {
				result.append(", ").append(this.entries[e].toString());
			}

			return result.append('}').toString();
		}
	}

	private static final class SingletonImmutableMap<K, V> extends ImmutableMap<K, V> {
		private final transient K singleKey;
		private final transient V singleValue;
		private transient Entry<K, V> entry;
		private transient ImmutableSet<Entry<K, V>> entrySet;
		private transient ImmutableSet<K> keySet;
		private transient ImmutableCollection<V> values;

		private SingletonImmutableMap(K singleKey, V singleValue) {
			this.singleKey = singleKey;
			this.singleValue = singleValue;
		}

		private SingletonImmutableMap(Entry<K, V> entry) {
			this.entry = entry;
			this.singleKey = entry.getKey();
			this.singleValue = entry.getValue();
		}

		private Entry<K, V> entry() {
			Entry<K, V> e = this.entry;
			return e == null ? (this.entry = Maps.immutableEntry(this.singleKey, this.singleValue)) : e;
		}

		public V get(Object key) {
			return this.singleKey.equals(key) ? this.singleValue : null;
		}

		public int size() {
			return 1;
		}

		public boolean isEmpty() {
			return false;
		}

		public boolean containsKey(Object key) {
			return this.singleKey.equals(key);
		}

		public boolean containsValue(Object value) {
			return this.singleValue.equals(value);
		}

		public ImmutableSet<Entry<K, V>> entrySet() {
			ImmutableSet<Entry<K, V>> es = this.entrySet;
			return es == null ? (this.entrySet = ImmutableSet.of(this.entry())) : es;
		}

		public ImmutableSet<K> keySet() {
			ImmutableSet<K> ks = this.keySet;
			return ks == null ? (this.keySet = ImmutableSet.of(this.singleKey)) : ks;
		}

		public ImmutableCollection<V> values() {
			ImmutableCollection<V> v = this.values;
			return v == null
					? (this.values = new com.google.inject.internal.ImmutableMap.SingletonImmutableMap.Values(
							this.singleValue))
					: v;
		}

		public boolean equals(@Nullable Object object) {
			if (object == this) {
				return true;
			} else if (object instanceof Map) {
				Map<?, ?> that = (Map) object;
				if (that.size() != 1) {
					return false;
				} else {
					Entry<?, ?> entry = (Entry) that.entrySet().iterator().next();
					return this.singleKey.equals(entry.getKey()) && this.singleValue.equals(entry.getValue());
				}
			} else {
				return false;
			}
		}

		public int hashCode() {
			return this.singleKey.hashCode() ^ this.singleValue.hashCode();
		}

		public String toString() {
			return '{' + this.singleKey.toString() + '=' + this.singleValue.toString() + '}';
		}
	}

	private static final class EmptyImmutableMap extends ImmutableMap<Object, Object> {
		private EmptyImmutableMap() {
		}

		public Object get(Object key) {
			return null;
		}

		public int size() {
			return 0;
		}

		public boolean isEmpty() {
			return true;
		}

		public boolean containsKey(Object key) {
			return false;
		}

		public boolean containsValue(Object value) {
			return false;
		}

		public ImmutableSet<Entry<Object, Object>> entrySet() {
			return ImmutableSet.of();
		}

		public ImmutableSet<Object> keySet() {
			return ImmutableSet.of();
		}

		public ImmutableCollection<Object> values() {
			return ImmutableCollection.EMPTY_IMMUTABLE_COLLECTION;
		}

		public boolean equals(@Nullable Object object) {
			if (object instanceof Map) {
				Map<?, ?> that = (Map) object;
				return that.isEmpty();
			} else {
				return false;
			}
		}

		public int hashCode() {
			return 0;
		}

		public String toString() {
			return "{}";
		}
	}
}