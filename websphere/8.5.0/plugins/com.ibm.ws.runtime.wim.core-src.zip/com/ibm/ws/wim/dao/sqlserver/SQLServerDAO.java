package com.ibm.ws.wim.dao.sqlserver;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.EntityAlreadyExistsException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.adapter.db.DBEntity;
import com.ibm.ws.wim.dao.AbstractDAO;
import com.ibm.ws.wim.dao.DAOHelper;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;

public class SQLServerDAO extends AbstractDAO {
	static final String COPYRIGHT_NOTICE;
	private static final Logger trcLogger;

	public SQLServerDAO(String var1, String var2, String var3, String var4, String var5) throws WIMException {
		super("sqlserver", var1, var2, var3, var4, var5, new SQLServerQuerySet());
	}

	public SQLServerDAO(String var1, String var2, String var3, String var4, String var5, String var6)
			throws WIMException {
		super("sqlserver", var1, var2, var3, var4, var5, var6, new SQLServerQuerySet(var3));
	}

	public Object getBlobValue(ResultSet var1, int var2) throws SQLException, IOException, ClassNotFoundException {
		byte[] var3 = var1.getBytes(var2);
		ByteArrayInputStream var4 = new ByteArrayInputStream(var3);
		ObjectInputStream var5 = new ObjectInputStream(var4);
		return var5.readObject();
	}

	public long createDBEntity(DBEntity var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createDBEntity");
		}

		String var3 = var1.getEntityType();
		String var4 = var1.getUniqueId();
		String var5 = var1.getUniqueName();
		String var6 = DAOHelper.getTruncatedUniqueName(var5);
		Connection var7 = null;
		PreparedStatement var8 = null;
		long var9 = -1L;
		boolean var21 = false;

		try {
			var21 = true;
			var7 = this.getConnection();
			var9 = this.getKeyManager().getDBKeyForTable(var7, "DBENTITY");
			String var11 = this.getQuerySet().createDBEntity;
			var8 = var7.prepareStatement(var11);
			var8.setLong(1, var9);
			var8.setString(2, var3);
			var8.setString(3, var4);
			var8.setString(4, var5);
			var8.setString(5, var6);
			var8.executeUpdate();
			var21 = false;
		} catch (NamingException var23) {
			throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME, "createDBEntity", var23);
		} catch (SQLException var24) {
			DBEntity var12 = this.findDBEntityByUniqueNameKey(var6);
			if (var12 != null) {
				throw new EntityAlreadyExistsException("ENTITY_ALREADY_EXIST", WIMMessageHelper.generateMsgParms(var5),
						CLASSNAME, "createDBEntity");
			}

			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var24.getMessage()),
					CLASSNAME, "createDBEntity", var24);
		} finally {
			if (var21) {
				try {
					if (var8 != null) {
						var8.close();
					}

					this.closeConnection(var7);
				} catch (Exception var22) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var15 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var15.append(var22.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "createDBEntity", var15.toString(),
								WIMMessageHelper.generateMsgParms(var22));
					}
				}

			}
		}

		try {
			if (var8 != null) {
				var8.close();
			}

			this.closeConnection(var7);
		} catch (Exception var26) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var27 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var27.append(var26.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "createDBEntity", var27.toString(),
						WIMMessageHelper.generateMsgParms(var26));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createDBEntity");
		}

		return var9;
	}

	public void createProperties1(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException {
		super.createProperties(var1, var2, var4, var5, var6, var7);
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}