package com.ibm.websphere.ssl;

interface package-info {
}