package org.apache.http.auth.params;

import org.apache.http.annotation.Immutable;
import org.apache.http.params.HttpParams;

@Immutable
public final class AuthParams {
	public static String getCredentialCharset(HttpParams params) {
		if (params == null) {
			throw new IllegalArgumentException("HTTP parameters may not be null");
		} else {
			String charset = (String) params.getParameter("http.auth.credential-charset");
			if (charset == null) {
				charset = "US-ASCII";
			}

			return charset;
		}
	}

	public static void setCredentialCharset(HttpParams params, String charset) {
		if (params == null) {
			throw new IllegalArgumentException("HTTP parameters may not be null");
		} else {
			params.setParameter("http.auth.credential-charset", charset);
		}
	}
}