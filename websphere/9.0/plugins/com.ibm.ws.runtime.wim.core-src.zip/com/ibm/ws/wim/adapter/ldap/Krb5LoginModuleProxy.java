package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.security.auth.SubjectHelper;
import com.ibm.ws.security.auth.kerberos.Krb5Utils;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;
import org.ietf.jgss.GSSCredential;

public class Krb5LoginModuleProxy implements LoginModule {
	private static final String CLASSNAME = Krb5LoginModuleProxy.class.getName();
	private static final Logger trcLogger;
	public static final String COM_IBM_SECURITY_AUTH_MODULE_KRB5LOGINMODULE = "com.ibm.security.auth.module.Krb5LoginModule";
	public CallbackHandler callbackHandler;
	public Subject subject;
	public Map<String, Object> sharedState;
	public Map<String, Object> options;
	private final Class<? extends LoginModule> krb5LoginModuleClass;
	private final LoginModule krb5loginModule;
	private boolean login_called = false;

	public Krb5LoginModuleProxy() {
		String var1 = "com.ibm.security.auth.module.Krb5LoginModule";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "Krb5LoginModuleProxy", "Using target class: " + var1);
		}

		this.krb5LoginModuleClass = getClassForName(var1);

		try {
			this.krb5loginModule = (LoginModule) this.krb5LoginModuleClass.newInstance();
		} catch (Exception var3) {
			throw new IllegalStateException(var3);
		}
	}

	public void initialize(Subject var1, CallbackHandler var2, Map<String, ?> var3, Map<String, ?> var4) {
		this.callbackHandler = var2;
		this.subject = var1;
		this.sharedState = var3;
		this.options = new HashMap(var4);
		if (trcLogger.isLoggable(Level.FINEST)) {
			this.options.put("debug", "true");
			trcLogger.logp(Level.FINEST, CLASSNAME, "initialize", "Kerberos options are: " + this.options);
		}

		this.krb5loginModule.initialize(var1, var2, var3, this.options);
	}

	public boolean login() throws LoginException {
		this.krb5loginModule.login();
		this.login_called = true;
		return true;
	}

	public boolean commit() throws LoginException {
		if (this.login_called) {
			this.krb5loginModule.commit();
			GSSCredential var1 = Krb5Utils.createGSSCredential(this.subject);
			SubjectHelper.putGSSCredentialInSubject(var1, this.subject);
		}

		return true;
	}

	public boolean abort() throws LoginException {
		if (this.login_called) {
			this.krb5loginModule.abort();
		}

		return true;
	}

	public boolean logout() throws LoginException {
		if (this.login_called) {
			this.krb5loginModule.logout();
		}

		return true;
	}

	private static Class<? extends LoginModule> getClassForName(String var0) {
		try {
			return Class.forName(var0);
		} catch (ClassNotFoundException var2) {
			trcLogger.logp(Level.SEVERE, CLASSNAME, "getClassForName", "SYSTEM_EXCEPTION", WIMMessageHelper
					.generateMsgParms("Exception performing class for name.", var2.getLocalizedMessage(), var2));
			throw new IllegalStateException(var2);
		}
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}