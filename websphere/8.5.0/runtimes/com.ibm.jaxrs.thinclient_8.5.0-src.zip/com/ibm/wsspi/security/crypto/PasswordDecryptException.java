package com.ibm.wsspi.security.crypto;

public class PasswordDecryptException extends Exception {
	public PasswordDecryptException() {
	}

	public PasswordDecryptException(String message) {
		super(message);
	}

	public PasswordDecryptException(Exception e) {
		super(e);
	}

	public PasswordDecryptException(String message, Exception e) {
		super(message, e);
	}
}