package com.google.common.base;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Predicates.1;
import com.google.common.base.Predicates.AndPredicate;
import com.google.common.base.Predicates.AssignableFromPredicate;
import com.google.common.base.Predicates.CompositionPredicate;
import com.google.common.base.Predicates.ContainsPatternPredicate;
import com.google.common.base.Predicates.InPredicate;
import com.google.common.base.Predicates.InstanceOfPredicate;
import com.google.common.base.Predicates.IsEqualToPredicate;
import com.google.common.base.Predicates.NotPredicate;
import com.google.common.base.Predicates.ObjectPredicate;
import com.google.common.base.Predicates.OrPredicate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
public final class Predicates {
	private static final Joiner COMMA_JOINER = Joiner.on(",");

	@GwtCompatible(serializable = true)
	public static <T> Predicate<T> alwaysTrue() {
		return ObjectPredicate.ALWAYS_TRUE.withNarrowedType();
	}

	@GwtCompatible(serializable = true)
	public static <T> Predicate<T> alwaysFalse() {
		return ObjectPredicate.ALWAYS_FALSE.withNarrowedType();
	}

	@GwtCompatible(serializable = true)
	public static <T> Predicate<T> isNull() {
		return ObjectPredicate.IS_NULL.withNarrowedType();
	}

	@GwtCompatible(serializable = true)
	public static <T> Predicate<T> notNull() {
		return ObjectPredicate.NOT_NULL.withNarrowedType();
	}

	public static <T> Predicate<T> not(Predicate<T> predicate) {
		return new NotPredicate(predicate);
	}

	public static <T> Predicate<T> and(Iterable<? extends Predicate<? super T>> components) {
      return new AndPredicate(defensiveCopy(components), (1)null);
   }

	public static <T> Predicate<T> and(Predicate... components) {
      return new AndPredicate(defensiveCopy((Object[])components), (1)null);
   }

	public static <T> Predicate<T> and(Predicate<? super T> first, Predicate<? super T> second) {
      return new AndPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), (1)null);
   }

	public static <T> Predicate<T> or(Iterable<? extends Predicate<? super T>> components) {
      return new OrPredicate(defensiveCopy(components), (1)null);
   }

	public static <T> Predicate<T> or(Predicate... components) {
      return new OrPredicate(defensiveCopy((Object[])components), (1)null);
   }

	public static <T> Predicate<T> or(Predicate<? super T> first, Predicate<? super T> second) {
      return new OrPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), (1)null);
   }

	public static <T> Predicate<T> equalTo(@Nullable T target) {
      return (Predicate)(target == null ? isNull() : new IsEqualToPredicate(target, (1)null));
   }

	@GwtIncompatible("Class.isInstance")
   public static Predicate<Object> instanceOf(Class<?> clazz) {
      return new InstanceOfPredicate(clazz, (1)null);
   }

	@GwtIncompatible("Class.isAssignableFrom")
   @Beta
   public static Predicate<Class<?>> assignableFrom(Class<?> clazz) {
      return new AssignableFromPredicate(clazz, (1)null);
   }

	public static <T> Predicate<T> in(Collection<? extends T> target) {
      return new InPredicate(target, (1)null);
   }

	public static <A, B> Predicate<A> compose(Predicate<B> predicate, Function<A, ? extends B> function) {
      return new CompositionPredicate(predicate, function, (1)null);
   }

	@GwtIncompatible("java.util.regex.Pattern")
	public static Predicate<CharSequence> containsPattern(String pattern) {
		return new ContainsPatternPredicate(pattern);
	}

	@GwtIncompatible("java.util.regex.Pattern")
	public static Predicate<CharSequence> contains(Pattern pattern) {
		return new ContainsPatternPredicate(pattern);
	}

	private static <T> List<Predicate<? super T>> asList(Predicate<? super T> first, Predicate<? super T> second) {
		return Arrays.asList(first, second);
	}

	private static <T> List<T> defensiveCopy(T... array) {
		return defensiveCopy((Iterable) Arrays.asList(array));
	}

	static <T> List<T> defensiveCopy(Iterable<T> iterable) {
		ArrayList<T> list = new ArrayList();
		Iterator i$ = iterable.iterator();

		while (i$.hasNext()) {
			T element = i$.next();
			list.add(Preconditions.checkNotNull(element));
		}

		return list;
	}
}