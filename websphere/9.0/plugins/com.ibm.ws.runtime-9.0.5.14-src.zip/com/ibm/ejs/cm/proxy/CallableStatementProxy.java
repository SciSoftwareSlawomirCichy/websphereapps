package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;

public class CallableStatementProxy extends PreparedStatementProxy implements CallableStatement {
	private static final TraceNLS NLS = TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages");
	private static final TraceComponent tc = Tr.register(CallableStatementProxy.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public Reader getCharacterStream(int parameterIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getCharacterStream(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Reader getCharacterStream(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getCharacterStream(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Reader getNCharacterStream(int parameterIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNCharacterStream(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Reader getNCharacterStream(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNCharacterStream(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public NClob getNClob(int parameterIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNClob(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public NClob getNClob(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNClob(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public String getNString(int parameterIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNString(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public String getNString(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNString(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public RowId getRowId(int parameterIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getRowId(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public RowId getRowId(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getRowId(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public SQLXML getSQLXML(int parameterIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getSQLXML(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public SQLXML getSQLXML(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getSQLXML(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setAsciiStream(String parameterName, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setAsciiStream(String, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setAsciiStream(String parameterName, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setAsciiStream(String, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBinaryStream(String parameterName, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBinaryStream(String, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBinaryStream(String parameterName, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBinaryStream(String, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBlob(String parameterName, Blob x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBlob(String, Blob)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBlob(String parameterName, InputStream inputStream) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBlob(String, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBlob(String parameterName, InputStream inputStream, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBlob(String, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setCharacterStream(String parameterName, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setCharacterStream(String, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setCharacterStream(String, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setClob(String parameterName, Clob x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setClob(String, Clob)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setClob(String parameterName, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setClob(String, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setClob(String parameterName, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setClob(String, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNCharacterStream(String parameterName, Reader value) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNCharacterStream(String, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNCharacterStream(String parameterName, Reader value, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNCharacterStream(String, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNClob(String parameterName, NClob value) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNClob(String, NClob)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNClob(String parameterName, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNClob(String, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNClob(String parameterName, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNClob(String, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNString(String parameterName, String value) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNString(String, String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setRowId(String parameterName, RowId x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setRowId(String, RowId)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setSQLXML(String parameterName, SQLXML xmlObject) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setSQLXML(String, SQLXML)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void registerOutParameter(String s, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "registerOutParameter(String, int)");
		throw new SQLException("This method is not supported.");
	}

	public void registerOutParameter(String s, int i1, int i2) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "registerOutParameter(String, int, int)");
		throw new SQLException("This method is not supported.");
	}

	public void registerOutParameter(String s, int i, String s2) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "registerOutParameter(String, int, String)");
		throw new SQLException("This method is not supported.");
	}

	public void setURL(String s, URL url) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setURL(String, java.net.URL)");
		throw new SQLException("This method is not supported.");
	}

	public void setNull(String s, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setNull(String, int)");
		throw new SQLException("This method is not supported.");
	}

	public void setBoolean(String s, boolean b) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setBoolean(String, boolean)");
		throw new SQLException("This method is not supported.");
	}

	public void setByte(String s, byte b) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setByte(String, byte)");
		throw new SQLException("This method is not supported.");
	}

	public void setShort(String s, short sh) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setShort(String, short)");
		throw new SQLException("This method is not supported.");
	}

	public void setInt(String s, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setInt(String, int)");
		throw new SQLException("This method is not supported.");
	}

	public void setLong(String s, long l) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setLong(String, long)");
		throw new SQLException("This method is not supported.");
	}

	public void setFloat(String s, float f) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setFloat(String, float)");
		throw new SQLException("This method is not supported.");
	}

	public void setDouble(String s, double d) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setDouble(String, double)");
		throw new SQLException("This method is not supported.");
	}

	public void setBigDecimal(String s, BigDecimal bd) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setBigDecimal(String, BigDecimal)");
		throw new SQLException("This method is not supported.");
	}

	public void setString(String s, String s2) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setString(String, String)");
		throw new SQLException("This method is not supported.");
	}

	public void setBytes(String s, byte[] b) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setBytes(String, byte[])");
		throw new SQLException("This method is not supported.");
	}

	public void setDate(String s, Date d) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setDate(String, Date)");
		throw new SQLException("This method is not supported.");
	}

	public void setTime(String s, Time t) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setTime(String, Time)");
		throw new SQLException("This method is not supported.");
	}

	public void setTimestamp(String s, Timestamp ts) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setTimestamp(String, Timestamp)");
		throw new SQLException("This method is not supported.");
	}

	public void setAsciiStream(String s, InputStream is, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setAsciiStream(String, java.io.InputStream, int)");
		throw new SQLException("This method is not supported.");
	}

	public void setBinaryStream(String s, InputStream is, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setBinaryStream(String, java.io.InputStream, int)");
		throw new SQLException("This method is not supported.");
	}

	public void setObject(String s, Object o, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setObject(String, Object, int)");
		throw new SQLException("This method is not supported.");
	}

	public void setObject(String s, Object o, int i, int i2) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setObject(String, Object, int, int)");
		throw new SQLException("This method is not supported.");
	}

	public void setObject(String s, Object o) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setObject(String, Object)");
		throw new SQLException("This method is not supported.");
	}

	public void setCharacterStream(String s, Reader r, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setCharacterStream(String, java.io.Reader, int)");
		throw new SQLException("This method is not supported.");
	}

	public void setDate(String s, Date d, Calendar c) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setDate(String, Date, Calendar)");
		throw new SQLException("This method is not supported.");
	}

	public void setTime(String s, Time t, Calendar c) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setTime(String, Time, Calendar)");
		throw new SQLException("This method is not supported.");
	}

	public void setTimestamp(String s, Timestamp t, Calendar c) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setTimestamp(String, Timestamp, Calendar)");
		throw new SQLException("This method is not supported.");
	}

	public void setNull(String s1, String s2) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setNull(String, String)");
		throw new SQLException("This method is not supported.");
	}

	public void setNull(String s1, int i, String s2) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setNull(String, int, String)");
		throw new SQLException("This method is not supported.");
	}

	public Array getArray(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getArray(String)");
		throw new SQLException("This method is not supported.");
	}

	public BigDecimal getBigDecimal(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getBigDecimal(String)");
		throw new SQLException("This method is not supported.");
	}

	public Blob getBlob(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getBlob(String)");
		throw new SQLException("This method is not supported.");
	}

	public boolean getBoolean(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getBoolean(String)");
		throw new SQLException("This method is not supported.");
	}

	public byte getByte(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getBytes(String)");
		throw new SQLException("This method is not supported.");
	}

	public byte[] getBytes(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getBytes(String)");
		throw new SQLException("This method is not supported.");
	}

	public Clob getClob(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getClob(String)");
		throw new SQLException("This method is not supported.");
	}

	public Date getDate(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getDate(String)");
		throw new SQLException("This method is not supported.");
	}

	public Date getDate(String parameterName, Calendar cal) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getDate(String, Calendar)");
		throw new SQLException("This method is not supported.");
	}

	public double getDouble(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getDouble(String)");
		throw new SQLException("This method is not supported.");
	}

	public float getFloat(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getFloat(String)");
		throw new SQLException("This method is not supported.");
	}

	public int getInt(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getInt(String)");
		throw new SQLException("This method is not supported.");
	}

	public long getLong(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getLong(String)");
		throw new SQLException("This method is not supported.");
	}

	public Object getObject(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getObject(String)");
		throw new SQLException("This method is not supported.");
	}

	public Object getObject(String parameterName, Map<String, Class<?>> map) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getObject(String, java.util.Map)");
		throw new SQLException("This method is not supported.");
	}

	public Ref getRef(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getRef(String)");
		throw new SQLException("This method is not supported.");
	}

	public short getShort(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getShort(String)");
		throw new SQLException("This method is not supported.");
	}

	public String getString(String s) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getString(String)");
		throw new SQLException("This method is not supported.");
	}

	public Time getTime(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getTime(String)");
		throw new SQLException("This method is not supported.");
	}

	public Time getTime(String parameterName, Calendar cal) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getTime(String, Calendar)");
		throw new SQLException("This method is not supported.");
	}

	public Timestamp getTimestamp(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getTimestamp(String)");
		throw new SQLException("This method is not supported.");
	}

	public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getTimestamp(String, Calendar)");
		throw new SQLException("This method is not supported.");
	}

	public URL getURL(int parameterIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getUrL(int)");
		throw new SQLException("This method is not supported.");
	}

	public URL getURL(String parameterName) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getURL(String)");
		throw new SQLException("This method is not supported.");
	}

	CallableStatementProxy(ConnectionProxy parent, CallableStatement statement) {
		super(parent, statement);
	}

	public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getBigDecimal(parameterIndex);
	}

	public Object getObject(int i, Map<String, Class<?>> map) throws SQLException {
		return ((CallableStatement) this.getStatement()).getObject(i, map);
	}

	public Ref getRef(int i) throws SQLException {
		return ((CallableStatement) this.getStatement()).getRef(i);
	}

	public Blob getBlob(int i) throws SQLException {
		return ((CallableStatement) this.getStatement()).getBlob(i);
	}

	public Clob getClob(int i) throws SQLException {
		return ((CallableStatement) this.getStatement()).getClob(i);
	}

	public Array getArray(int i) throws SQLException {
		return ((CallableStatement) this.getStatement()).getArray(i);
	}

	public Date getDate(int parameterIndex, Calendar cal) throws SQLException {
		return ((CallableStatement) this.getStatement()).getDate(parameterIndex, cal);
	}

	public Time getTime(int parameterIndex, Calendar cal) throws SQLException {
		return ((CallableStatement) this.getStatement()).getTime(parameterIndex, cal);
	}

	public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException {
		return ((CallableStatement) this.getStatement()).getTimestamp(parameterIndex, cal);
	}

	public void registerOutParameter(int paramIndex, int sqlType, String typeName) throws SQLException {
		((CallableStatement) this.getStatement()).registerOutParameter(paramIndex, sqlType, typeName);
	}

	public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {
		((CallableStatement) this.getStatement()).registerOutParameter(parameterIndex, sqlType);
	}

	public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException {
		((CallableStatement) this.getStatement()).registerOutParameter(parameterIndex, sqlType, scale);
	}

	public boolean wasNull() throws SQLException {
		return ((CallableStatement) this.getStatement()).wasNull();
	}

	public String getString(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getString(parameterIndex);
	}

	public boolean getBoolean(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getBoolean(parameterIndex);
	}

	public byte getByte(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getByte(parameterIndex);
	}

	public short getShort(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getShort(parameterIndex);
	}

	public int getInt(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getInt(parameterIndex);
	}

	public long getLong(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getLong(parameterIndex);
	}

	public float getFloat(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getFloat(parameterIndex);
	}

	public double getDouble(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getDouble(parameterIndex);
	}

	public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
		return ((CallableStatement) this.getStatement()).getBigDecimal(parameterIndex, scale);
	}

	public byte[] getBytes(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getBytes(parameterIndex);
	}

	public Date getDate(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getDate(parameterIndex);
	}

	public Time getTime(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getTime(parameterIndex);
	}

	public Timestamp getTimestamp(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getTimestamp(parameterIndex);
	}

	public Object getObject(int parameterIndex) throws SQLException {
		return ((CallableStatement) this.getStatement()).getObject(parameterIndex);
	}

	public <T> T getObject(int parameterIndex, Class<T> type) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public <T> T getObject(String parameterName, Class<T> type) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public void closeOnCompletion() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public boolean isCloseOnCompletion() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}
}