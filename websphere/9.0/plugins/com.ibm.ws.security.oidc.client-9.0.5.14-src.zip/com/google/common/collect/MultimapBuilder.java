package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.MultimapBuilder.1;
import com.google.common.collect.MultimapBuilder.2;
import com.google.common.collect.MultimapBuilder.3;
import com.google.common.collect.MultimapBuilder.4;
import com.google.common.collect.MultimapBuilder.MultimapBuilderWithKeys;
import java.util.Comparator;

@Beta
@GwtCompatible
public abstract class MultimapBuilder<K0, V0> {
	private static final int DEFAULT_EXPECTED_KEYS = 8;

	private MultimapBuilder() {
	}

	public static MultimapBuilderWithKeys<Object> hashKeys() {
		return hashKeys(8);
	}

	public static MultimapBuilderWithKeys<Object> hashKeys(int expectedKeys) {
      CollectPreconditions.checkNonnegative(expectedKeys, "expectedKeys");
      return new 1(expectedKeys);
   }

	public static MultimapBuilderWithKeys<Object> linkedHashKeys() {
		return linkedHashKeys(8);
	}

	public static MultimapBuilderWithKeys<Object> linkedHashKeys(int expectedKeys) {
      CollectPreconditions.checkNonnegative(expectedKeys, "expectedKeys");
      return new 2(expectedKeys);
   }

	public static MultimapBuilderWithKeys<Comparable> treeKeys() {
		return treeKeys(Ordering.natural());
	}

	public static <K0> MultimapBuilderWithKeys<K0> treeKeys(Comparator<K0> comparator) {
      Preconditions.checkNotNull(comparator);
      return new 3(comparator);
   }

	public static <K0 extends Enum<K0>> MultimapBuilderWithKeys<K0> enumKeys(Class<K0> keyClass) {
      Preconditions.checkNotNull(keyClass);
      return new 4(keyClass);
   }

	public abstract <K extends K0, V extends V0> Multimap<K, V> build();

	public <K extends K0, V extends V0> Multimap<K, V> build(Multimap<? extends K, ? extends V> multimap) {
		Multimap<K, V> result = this.build();
		result.putAll(multimap);
		return result;
	}

	public abstract static class SortedSetMultimapBuilder<K0, V0> extends MultimapBuilder.SetMultimapBuilder<K0, V0> {
		public abstract <K extends K0, V extends V0> SortedSetMultimap<K, V> build();

		public <K extends K0, V extends V0> SortedSetMultimap<K, V> build(Multimap<? extends K, ? extends V> multimap) {
			return (SortedSetMultimap) super.build(multimap);
		}
	}

	public abstract static class SetMultimapBuilder<K0, V0> extends MultimapBuilder<K0, V0> {
		SetMultimapBuilder() {
         super((1)null);
      }

		public abstract <K extends K0, V extends V0> SetMultimap<K, V> build();

		public <K extends K0, V extends V0> SetMultimap<K, V> build(Multimap<? extends K, ? extends V> multimap) {
			return (SetMultimap) super.build(multimap);
		}
	}

	public abstract static class ListMultimapBuilder<K0, V0> extends MultimapBuilder<K0, V0> {
		ListMultimapBuilder() {
         super((1)null);
      }

		public abstract <K extends K0, V extends V0> ListMultimap<K, V> build();

		public <K extends K0, V extends V0> ListMultimap<K, V> build(Multimap<? extends K, ? extends V> multimap) {
			return (ListMultimap) super.build(multimap);
		}
	}
}