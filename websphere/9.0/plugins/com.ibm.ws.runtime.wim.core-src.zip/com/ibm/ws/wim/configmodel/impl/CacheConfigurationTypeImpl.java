package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.AttributesCacheType;
import com.ibm.ws.wim.configmodel.CacheConfigurationType;
import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.SearchResultsCacheType;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class CacheConfigurationTypeImpl extends EDataObjectImpl implements CacheConfigurationType {
	protected AttributesCacheType attributesCache = null;
	protected SearchResultsCacheType searchResultsCache = null;
	protected static final boolean CACHES_DISK_OFF_LOAD_EDEFAULT = false;
	protected boolean cachesDiskOffLoad = false;
	protected boolean cachesDiskOffLoadESet = false;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getCacheConfigurationType();
	}

	public AttributesCacheType getAttributesCache() {
		return this.attributesCache;
	}

	public NotificationChain basicSetAttributesCache(AttributesCacheType var1, NotificationChain var2) {
		AttributesCacheType var3 = this.attributesCache;
		this.attributesCache = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 0, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setAttributesCache(AttributesCacheType var1) {
		if (var1 != this.attributesCache) {
			NotificationChain var2 = null;
			if (this.attributesCache != null) {
				var2 = ((InternalEObject) this.attributesCache).eInverseRemove(this, -1, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -1, (Class) null, var2);
			}

			var2 = this.basicSetAttributesCache(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var1, var1));
		}

	}

	public AttributesCacheType createAttributesCache() {
		AttributesCacheType var1 = ConfigmodelFactory.eINSTANCE.createAttributesCacheType();
		this.setAttributesCache(var1);
		return var1;
	}

	public SearchResultsCacheType getSearchResultsCache() {
		return this.searchResultsCache;
	}

	public NotificationChain basicSetSearchResultsCache(SearchResultsCacheType var1, NotificationChain var2) {
		SearchResultsCacheType var3 = this.searchResultsCache;
		this.searchResultsCache = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 1, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setSearchResultsCache(SearchResultsCacheType var1) {
		if (var1 != this.searchResultsCache) {
			NotificationChain var2 = null;
			if (this.searchResultsCache != null) {
				var2 = ((InternalEObject) this.searchResultsCache).eInverseRemove(this, -2, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -2, (Class) null, var2);
			}

			var2 = this.basicSetSearchResultsCache(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var1, var1));
		}

	}

	public SearchResultsCacheType createSearchResultsCache() {
		SearchResultsCacheType var1 = ConfigmodelFactory.eINSTANCE.createSearchResultsCacheType();
		this.setSearchResultsCache(var1);
		return var1;
	}

	public boolean isCachesDiskOffLoad() {
		return this.cachesDiskOffLoad;
	}

	public void setCachesDiskOffLoad(boolean var1) {
		boolean var2 = this.cachesDiskOffLoad;
		this.cachesDiskOffLoad = var1;
		boolean var3 = this.cachesDiskOffLoadESet;
		this.cachesDiskOffLoadESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.cachesDiskOffLoad, !var3));
		}

	}

	public void unsetCachesDiskOffLoad() {
		boolean var1 = this.cachesDiskOffLoad;
		boolean var2 = this.cachesDiskOffLoadESet;
		this.cachesDiskOffLoad = false;
		this.cachesDiskOffLoadESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 2, var1, false, var2));
		}

	}

	public boolean isSetCachesDiskOffLoad() {
		return this.cachesDiskOffLoadESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return this.basicSetAttributesCache((AttributesCacheType) null, var4);
				case 1 :
					return this.basicSetSearchResultsCache((SearchResultsCacheType) null, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getAttributesCache();
			case 1 :
				return this.getSearchResultsCache();
			case 2 :
				return this.isCachesDiskOffLoad() ? Boolean.TRUE : Boolean.FALSE;
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAttributesCache((AttributesCacheType) var2);
				return;
			case 1 :
				this.setSearchResultsCache((SearchResultsCacheType) var2);
				return;
			case 2 :
				this.setCachesDiskOffLoad((Boolean) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAttributesCache((AttributesCacheType) null);
				return;
			case 1 :
				this.setSearchResultsCache((SearchResultsCacheType) null);
				return;
			case 2 :
				this.unsetCachesDiskOffLoad();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.attributesCache != null;
			case 1 :
				return this.searchResultsCache != null;
			case 2 :
				return this.isSetCachesDiskOffLoad();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (cachesDiskOffLoad: ");
			if (this.cachesDiskOffLoadESet) {
				var1.append(this.cachesDiskOffLoad);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}