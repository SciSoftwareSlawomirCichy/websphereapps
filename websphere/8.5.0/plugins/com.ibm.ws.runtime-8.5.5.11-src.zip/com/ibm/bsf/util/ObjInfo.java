package com.ibm.bsf.util;

public class ObjInfo {
	private static String QUOTE_CHARS = "'\"";
	private static String EXEC_CHARS = "(=";
	public String objName;
	public Class objClass;

	public ObjInfo(Class var1, String var2) {
		this.objClass = var1;
		this.objName = var2;
	}

	public boolean isExecutable() {
		char[] var1 = this.objName.toCharArray();
		char var2 = ' ';
		boolean var3 = false;
		boolean var4 = false;

		for (int var5 = 0; var5 < var1.length; ++var5) {
			if (var4) {
				var4 = false;
			} else if (QUOTE_CHARS.indexOf(var1[var5]) != -1) {
				if (!var3) {
					var2 = var1[var5];
					var3 = true;
				} else if (var1[var5] == var2) {
					var3 = false;
				}
			} else if (EXEC_CHARS.indexOf(var1[var5]) != -1) {
				if (!var3) {
					return true;
				}
			} else if (var3 && var1[var5] == '\\') {
				var4 = true;
			}
		}

		return false;
	}

	public boolean isValueReturning() {
		return this.objClass != Void.TYPE && this.objClass != (class$java$lang$Void == null
				? (class$java$lang$Void = class$("java.lang.Void"))
				: class$java$lang$Void);
	}

	public String toString() {
		return StringUtils.getClassName(this.objClass) + " " + this.objName;
	}
}