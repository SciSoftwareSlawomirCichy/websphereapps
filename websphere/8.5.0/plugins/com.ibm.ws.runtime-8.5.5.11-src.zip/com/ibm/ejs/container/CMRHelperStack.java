package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.cpmi.association.CMRHelper;

public class CMRHelperStack {
	private static final TraceComponent tc = Tr.register(CMRHelperStack.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private CMRHelper[] ivElements;
	private int ivCapacity;
	private int ivTopOfStack = 0;

	public CMRHelperStack(int capacity) {
		this.ivElements = new CMRHelper[capacity];
		this.ivCapacity = capacity;

		for (int i = 0; i < this.ivCapacity; ++i) {
			this.ivElements[i] = new CMRHelperImpl();
		}

	}

	public CMRHelper get() {
		Object helper;
		if (this.ivTopOfStack < this.ivCapacity) {
			helper = this.ivElements[this.ivTopOfStack];
		} else {
			helper = new CMRHelperImpl();
		}

		++this.ivTopOfStack;
		return (CMRHelper) helper;
	}

	public final void done(CMRHelper helper) {
		if (this.ivTopOfStack > 0) {
			--this.ivTopOfStack;
			if (this.ivTopOfStack < this.ivCapacity && helper != this.ivElements[this.ivTopOfStack]) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "CMRHelperStack.done: disabled: improper use of get/release");
					Tr.debug(tc, "                     top    = " + this.ivTopOfStack);
					Tr.debug(tc, "                     helper = " + helper);

					for (int i = 0; i < this.ivCapacity; ++i) {
						Tr.debug(tc, "                     element[" + i + "] = " + this.ivElements[i]);
					}
				}

				this.ivCapacity = 0;
				this.ivElements = null;
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "CMRHelperStack.done: call made with top = " + this.ivTopOfStack
					+ ", likely due to problem with java.lang.ThreadLocal");
		}

	}
}