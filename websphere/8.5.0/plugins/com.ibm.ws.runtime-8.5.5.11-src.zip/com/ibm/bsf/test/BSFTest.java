package com.ibm.bsf.test;

import com.ibm.bsf.BSFManager;
import junit.framework.Test;
import junit.framework.TestResult;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

public class BSFTest extends BSFEngineTestTmpl {
	public static String[] testNames;

	public BSFTest(String var1) {
		super(var1);
	}

	public static void main(String[] var0) {
		TestRunner var1 = new TestRunner();
		TestSuite var2 = (TestSuite) suite();

		for (int var4 = 0; var4 < var2.testCount(); ++var4) {
			System.out.print(testNames[var4]);
			TestResult var3 = var1.doRun(var2.testAt(var4), false);
			System.out.println("Results: " + var3.runCount() + " tests run, " + var3.failureCount() + " failures, "
					+ var3.errorCount() + " errors.");
			System.out.print("\n----------------------------------------\n");
		}

	}

	public static Test suite() {
		TestSuite var0 = new TestSuite();
		testNames = new String[4];
		var0.addTestSuite(class$com$ibm$bsf$test$BSFTest == null
				? (class$com$ibm$bsf$test$BSFTest = class$("com.ibm.bsf.test.BSFTest"))
				: class$com$ibm$bsf$test$BSFTest);
		testNames[0] = "BSFManager Base Tests";
		var0.addTestSuite(class$com$ibm$bsf$test$engineTests$jaclTest == null
				? (class$com$ibm$bsf$test$engineTests$jaclTest = class$("com.ibm.bsf.test.engineTests.jaclTest"))
				: class$com$ibm$bsf$test$engineTests$jaclTest);
		testNames[1] = "Jacl Engine Tests";
		var0.addTestSuite(class$com$ibm$bsf$test$engineTests$javascriptTest == null
				? (class$com$ibm$bsf$test$engineTests$javascriptTest = class$(
						"com.ibm.bsf.test.engineTests.javascriptTest"))
				: class$com$ibm$bsf$test$engineTests$javascriptTest);
		testNames[2] = "Rhino Engine Tests";
		var0.addTestSuite(class$com$ibm$bsf$test$engineTests$jythonTest == null
				? (class$com$ibm$bsf$test$engineTests$jythonTest = class$("com.ibm.bsf.test.engineTests.jythonTest"))
				: class$com$ibm$bsf$test$engineTests$jythonTest);
		testNames[3] = "Jython Engine Tests";
		return var0;
	}

	public void setUp() {
		super.setUp();
		BSFManager.registerScriptingEngine("fakeEngine",
				(class$com$ibm$bsf$test$fakeEngine == null
						? (class$com$ibm$bsf$test$fakeEngine = class$("com.ibm.bsf.test.fakeEngine"))
						: class$com$ibm$bsf$test$fakeEngine).getName(),
				new String[]{"fakeEng", "fE"});
	}

	public void testRegisterEngine() {
		BSFManager var10000 = this.bsfManager;
		assertTrue(BSFManager.isLanguageRegistered("fakeEngine"));
	}

	public void testGetLangFromFileName() {
		try {
			assertEquals("fakeEngine", BSFManager.getLangFromFilename("Test.fE"));
		} catch (Exception var2) {
			fail(this.failMessage("getLangFromFilename() test failed", var2));
		}

	}

	public void testExec() {
		try {
			this.bsfManager.exec("fakeEngine", "Test.fE", 0, 0, "Fake syntax");
		} catch (Exception var2) {
			fail(this.failMessage("exec() test failed", var2));
		}

		assertEquals("PASSED", this.getTmpOutStr());
	}

	public void testEval() {
		Boolean var1 = Boolean.FALSE;

		try {
			var1 = (Boolean) this.bsfManager.eval("fakeEngine", "Test.fE", 0, 0, "Fake Syntax");
		} catch (Exception var3) {
			fail(this.failMessage("eval() test failed", var3));
		}

		assertTrue(var1);
	}

	public void testIexec() {
		try {
			this.bsfManager.iexec("fakeEngine", "Test.fE", 0, 0, "Fake syntax");
		} catch (Exception var2) {
			fail(this.failMessage("iexec() test failed", var2));
		}

		assertEquals("PASSED", this.getTmpOutStr());
	}

	public void testDeclareBean() {
		try {
			this.bsfManager.declareBean("foo", new Integer(1),
					class$java$lang$Integer == null
							? (class$java$lang$Integer = class$("java.lang.Integer"))
							: class$java$lang$Integer);
		} catch (Exception var2) {
			fail(this.failMessage("declareBean() test failed", var2));
		}

		assertEquals(new Integer(1), (Integer) this.bsfManager.lookupBean("foo"));
	}

	public void testUndeclareBean() {
		try {
			this.bsfManager.declareBean("foo", new Integer(1),
					class$java$lang$Integer == null
							? (class$java$lang$Integer = class$("java.lang.Integer"))
							: class$java$lang$Integer);
			this.bsfManager.undeclareBean("foo");
		} catch (Exception var2) {
			fail(this.failMessage("undeclareBean() test failed", var2));
		}

		assertNull(this.bsfManager.lookupBean("foo"));
	}

	public void testTerminate() throws Exception {
		try {
			this.bsfManager.loadScriptingEngine("fakeEngine");
			this.bsfManager.terminate();
		} catch (Exception var2) {
			fail(this.failMessage("terminate() test failed", var2));
		}

		assertEquals("PASSED", this.getTmpOutStr());
	}
}