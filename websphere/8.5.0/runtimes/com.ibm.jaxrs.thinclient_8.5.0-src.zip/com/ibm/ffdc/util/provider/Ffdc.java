package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.util.provider.Ffdc.1;
import com.ibm.ffdc.util.provider.IncidentEntry.Key;
import java.lang.ref.WeakReference;
import java.security.AccessController;

public class Ffdc extends FfdcProviderDependent<FfdcProvider> implements com.ibm.ffdc.Ffdc {
	private static final String emptyString = "";
	private static final String thisClass = Ffdc.class.getName();
	private final WeakReference<Object> reporterRef;
	private final WeakReference<Throwable> thRef;
	private final IncidentEntry incident;

	public Ffdc(Throwable th, Object reporter, String sourceId, String probeId, FfdcProvider provider) {
		super(provider);
		this.thRef = new WeakReference(th);
		String exceptionname = th == null ? String.valueOf((Object) null) : th.getClass().getName();
		Key key = new Key(sourceId, probeId == null ? "" : probeId, exceptionname);
		this.incident = provider.getIncident(key, getClassLoader(reporter));
		this.reporterRef = new WeakReference(reporter);
	}

	private static ClassLoader getClassLoader(Object o) {
      ClassLoader result = null;
      if (o != null) {
         result = (ClassLoader)AccessController.doPrivileged(new 1(o));
      }

      return result;
   }

	public final void log(Object... capturedDataElements) {
		if (!this.isRecursiveFfdc((Throwable) this.thRef.get())) {
			this.incident.log(this.provider, this.reporterRef.get(), (Throwable) this.thRef.get(),
					capturedDataElements);
		}

	}

	public final boolean isLoggable() {
		return this.provider.isLoggable(this.incident);
	}

	public Incident getIncident() {
		return this.incident;
	}

	public String toString() {
		String label = this.incident.getLabel();
		if (label == null) {
			label = "";
		}

		return "Ffdc{" + this.incident.getExceptionName() + " count:" + this.incident.getCount() + " SourceID:"
				+ this.incident.getSourceId() + " ProbeID:" + this.incident.getProbeId() + "} " + label;
	}

	private final boolean isRecursiveFfdc(Throwable throwable) {
		if (throwable == null) {
			return false;
		} else {
			StackTraceElement[] traceList = throwable.getStackTrace();

			for (int i = 4; i < traceList.length; ++i) {
				if (thisClass.equals(traceList[i].getClassName())
						&& "log".equalsIgnoreCase(traceList[i].getMethodName())) {
					System.err.println(
							"In processing an FFDC incident, a recursive FFDC call was made. No incident created: "
									+ throwable);
					return true;
				}
			}

			return false;
		}
	}
}