package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Synchronized.1;
import com.google.common.collect.Synchronized.SynchronizedBiMap;
import com.google.common.collect.Synchronized.SynchronizedCollection;
import com.google.common.collect.Synchronized.SynchronizedDeque;
import com.google.common.collect.Synchronized.SynchronizedEntry;
import com.google.common.collect.Synchronized.SynchronizedList;
import com.google.common.collect.Synchronized.SynchronizedListMultimap;
import com.google.common.collect.Synchronized.SynchronizedMap;
import com.google.common.collect.Synchronized.SynchronizedMultimap;
import com.google.common.collect.Synchronized.SynchronizedMultiset;
import com.google.common.collect.Synchronized.SynchronizedNavigableMap;
import com.google.common.collect.Synchronized.SynchronizedNavigableSet;
import com.google.common.collect.Synchronized.SynchronizedQueue;
import com.google.common.collect.Synchronized.SynchronizedRandomAccessList;
import com.google.common.collect.Synchronized.SynchronizedSet;
import com.google.common.collect.Synchronized.SynchronizedSetMultimap;
import com.google.common.collect.Synchronized.SynchronizedSortedMap;
import com.google.common.collect.Synchronized.SynchronizedSortedSet;
import com.google.common.collect.Synchronized.SynchronizedSortedSetMultimap;
import com.google.common.collect.Synchronized.SynchronizedTable;
import java.util.Collection;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Queue;
import java.util.RandomAccess;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
final class Synchronized {
	private static <E> Collection<E> collection(Collection<E> collection, @NullableDecl Object mutex) {
      return new SynchronizedCollection(collection, mutex, (1)null);
   }

	@VisibleForTesting
	static <E> Set<E> set(Set<E> set, @NullableDecl Object mutex) {
		return new SynchronizedSet(set, mutex);
	}

	private static <E> SortedSet<E> sortedSet(SortedSet<E> set, @NullableDecl Object mutex) {
		return new SynchronizedSortedSet(set, mutex);
	}

	private static <E> List<E> list(List<E> list, @NullableDecl Object mutex) {
		return (List) (list instanceof RandomAccess
				? new SynchronizedRandomAccessList(list, mutex)
				: new SynchronizedList(list, mutex));
	}

	static <E> Multiset<E> multiset(Multiset<E> multiset, @NullableDecl Object mutex) {
		return (Multiset) (!(multiset instanceof SynchronizedMultiset) && !(multiset instanceof ImmutableMultiset)
				? new SynchronizedMultiset(multiset, mutex)
				: multiset);
	}

	static <K, V> Multimap<K, V> multimap(Multimap<K, V> multimap, @NullableDecl Object mutex) {
		return (Multimap) (!(multimap instanceof SynchronizedMultimap) && !(multimap instanceof BaseImmutableMultimap)
				? new SynchronizedMultimap(multimap, mutex)
				: multimap);
	}

	static <K, V> ListMultimap<K, V> listMultimap(ListMultimap<K, V> multimap, @NullableDecl Object mutex) {
		return (ListMultimap) (!(multimap instanceof SynchronizedListMultimap)
				&& !(multimap instanceof BaseImmutableMultimap)
						? new SynchronizedListMultimap(multimap, mutex)
						: multimap);
	}

	static <K, V> SetMultimap<K, V> setMultimap(SetMultimap<K, V> multimap, @NullableDecl Object mutex) {
		return (SetMultimap) (!(multimap instanceof SynchronizedSetMultimap)
				&& !(multimap instanceof BaseImmutableMultimap)
						? new SynchronizedSetMultimap(multimap, mutex)
						: multimap);
	}

	static <K, V> SortedSetMultimap<K, V> sortedSetMultimap(SortedSetMultimap<K, V> multimap,
			@NullableDecl Object mutex) {
		return (SortedSetMultimap) (multimap instanceof SynchronizedSortedSetMultimap
				? multimap
				: new SynchronizedSortedSetMultimap(multimap, mutex));
	}

	private static <E> Collection<E> typePreservingCollection(Collection<E> collection, @NullableDecl Object mutex) {
		if (collection instanceof SortedSet) {
			return sortedSet((SortedSet) collection, mutex);
		} else if (collection instanceof Set) {
			return set((Set) collection, mutex);
		} else {
			return (Collection) (collection instanceof List
					? list((List) collection, mutex)
					: collection(collection, mutex));
		}
	}

	private static <E> Set<E> typePreservingSet(Set<E> set, @NullableDecl Object mutex) {
		return (Set) (set instanceof SortedSet ? sortedSet((SortedSet) set, mutex) : set(set, mutex));
	}

	@VisibleForTesting
	static <K, V> Map<K, V> map(Map<K, V> map, @NullableDecl Object mutex) {
		return new SynchronizedMap(map, mutex);
	}

	static <K, V> SortedMap<K, V> sortedMap(SortedMap<K, V> sortedMap, @NullableDecl Object mutex) {
		return new SynchronizedSortedMap(sortedMap, mutex);
	}

	static <K, V> BiMap<K, V> biMap(BiMap<K, V> bimap, @NullableDecl Object mutex) {
      return (BiMap)(!(bimap instanceof SynchronizedBiMap) && !(bimap instanceof ImmutableBiMap) ? new SynchronizedBiMap(bimap, mutex, (BiMap)null, (1)null) : bimap);
   }

	@GwtIncompatible
	static <E> NavigableSet<E> navigableSet(NavigableSet<E> navigableSet, @NullableDecl Object mutex) {
		return new SynchronizedNavigableSet(navigableSet, mutex);
	}

	@GwtIncompatible
	static <E> NavigableSet<E> navigableSet(NavigableSet<E> navigableSet) {
		return navigableSet(navigableSet, (Object) null);
	}

	@GwtIncompatible
	static <K, V> NavigableMap<K, V> navigableMap(NavigableMap<K, V> navigableMap) {
		return navigableMap(navigableMap, (Object) null);
	}

	@GwtIncompatible
	static <K, V> NavigableMap<K, V> navigableMap(NavigableMap<K, V> navigableMap, @NullableDecl Object mutex) {
		return new SynchronizedNavigableMap(navigableMap, mutex);
	}

	@GwtIncompatible
	private static <K, V> Entry<K, V> nullableSynchronizedEntry(@NullableDecl Entry<K, V> entry,
			@NullableDecl Object mutex) {
		return entry == null ? null : new SynchronizedEntry(entry, mutex);
	}

	static <E> Queue<E> queue(Queue<E> queue, @NullableDecl Object mutex) {
		return (Queue) (queue instanceof SynchronizedQueue ? queue : new SynchronizedQueue(queue, mutex));
	}

	static <E> Deque<E> deque(Deque<E> deque, @NullableDecl Object mutex) {
		return new SynchronizedDeque(deque, mutex);
	}

	static <R, C, V> Table<R, C, V> table(Table<R, C, V> table, Object mutex) {
		return new SynchronizedTable(table, mutex);
	}
}