package com.ibm.ejs.container.interceptors;

interface package-info {
}