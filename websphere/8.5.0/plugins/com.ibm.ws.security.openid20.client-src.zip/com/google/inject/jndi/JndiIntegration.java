package com.google.inject.jndi;

import com.google.inject.Provider;
import com.google.inject.jndi.JndiIntegration.JndiProvider;

public class JndiIntegration {
	public static <T> Provider<T> fromJndi(Class<T> type, String name) {
		return new JndiProvider(type, name);
	}
}