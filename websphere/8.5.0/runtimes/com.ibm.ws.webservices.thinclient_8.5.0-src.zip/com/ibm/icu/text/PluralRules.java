package com.ibm.icu.text;

import com.ibm.icu.impl.PluralRulesLoader;
import com.ibm.icu.impl.Utility;
import com.ibm.icu.text.PluralRules.1;
import com.ibm.icu.text.PluralRules.2;
import com.ibm.icu.text.PluralRules.AndConstraint;
import com.ibm.icu.text.PluralRules.ConstrainedRule;
import com.ibm.icu.text.PluralRules.Constraint;
import com.ibm.icu.text.PluralRules.OrConstraint;
import com.ibm.icu.text.PluralRules.RangeConstraint;
import com.ibm.icu.text.PluralRules.Rule;
import com.ibm.icu.text.PluralRules.RuleChain;
import com.ibm.icu.text.PluralRules.RuleList;
import com.ibm.icu.util.ULocale;
import java.io.Serializable;
import java.text.ParseException;
import java.util.Collections;
import java.util.Locale;
import java.util.Set;

public class PluralRules implements Serializable {
	private static final long serialVersionUID = 1L;
	private final RuleList rules;
	private final Set<String> keywords;
	private int repeatLimit;
	public static final String KEYWORD_ZERO = "zero";
	public static final String KEYWORD_ONE = "one";
	public static final String KEYWORD_TWO = "two";
	public static final String KEYWORD_FEW = "few";
	public static final String KEYWORD_MANY = "many";
	public static final String KEYWORD_OTHER = "other";
	private static final UnicodeSet START_CHARS = new UnicodeSet("[[:ID_Start:][_]]");
	private static final UnicodeSet CONT_CHARS = new UnicodeSet("[:ID_Continue:]");
	private static final Constraint NO_CONSTRAINT = new 1();
	private static final Rule DEFAULT_RULE = new 2();
	public static final PluralRules DEFAULT;

	public static PluralRules parseDescription(String description) throws ParseException {
		description = description.trim();
		return description.length() == 0 ? DEFAULT : new PluralRules(parseRuleChain(description));
	}

	public static PluralRules createRules(String description) {
		try {
			return parseDescription(description);
		} catch (ParseException var2) {
			return null;
		}
	}

	private static Constraint parseConstraint(String description) throws ParseException {
		description = description.trim().toLowerCase(Locale.ENGLISH);
		Constraint result = null;
		String[] or_together = Utility.splitString(description, "or");

		for (int i = 0; i < or_together.length; ++i) {
			Constraint andConstraint = null;
			String[] and_together = Utility.splitString(or_together[i], "and");

			for (int j = 0; j < and_together.length; ++j) {
				Constraint newConstraint = NO_CONSTRAINT;
				String condition = and_together[j].trim();
				String[] tokens = Utility.splitWhitespace(condition);
				int mod = 0;
				boolean inRange = true;
				boolean integersOnly = true;
				long lowBound = -1L;
				long highBound = -1L;
				boolean isRange = false;
				int x = 0;
				int x = x + 1;
				String t = tokens[x];
				if (!"n".equals(t)) {
					throw unexpected(t, condition);
				}

				if (x < tokens.length) {
					t = tokens[x++];
					if ("mod".equals(t)) {
						mod = Integer.parseInt(tokens[x++]);
						t = nextToken(tokens, x++, condition);
					}

					if ("is".equals(t)) {
						t = nextToken(tokens, x++, condition);
						if ("not".equals(t)) {
							inRange = false;
							t = nextToken(tokens, x++, condition);
						}
					} else {
						isRange = true;
						if ("not".equals(t)) {
							inRange = false;
							t = nextToken(tokens, x++, condition);
						}

						if ("in".equals(t)) {
							t = nextToken(tokens, x++, condition);
						} else {
							if (!"within".equals(t)) {
								throw unexpected(t, condition);
							}

							integersOnly = false;
							t = nextToken(tokens, x++, condition);
						}
					}

					if (isRange) {
						String[] pair = Utility.splitString(t, "..");
						if (pair.length != 2) {
							throw unexpected(t, condition);
						}

						lowBound = Long.parseLong(pair[0]);
						highBound = Long.parseLong(pair[1]);
					} else {
						lowBound = highBound = Long.parseLong(t);
					}

					if (x != tokens.length) {
						throw unexpected(tokens[x], condition);
					}

					newConstraint = new RangeConstraint(mod, inRange, integersOnly, lowBound, highBound);
				}

				if (andConstraint == null) {
					andConstraint = newConstraint;
				} else {
					andConstraint = new AndConstraint((Constraint) andConstraint, (Constraint) newConstraint);
				}
			}

			if (result == null) {
				result = andConstraint;
			} else {
				result = new OrConstraint((Constraint) result, (Constraint) andConstraint);
			}
		}

		return (Constraint) result;
	}

	private static ParseException unexpected(String token, String context) {
		return new ParseException("unexpected token '" + token + "' in '" + context + "'", -1);
	}

	private static String nextToken(String[] tokens, int x, String context) throws ParseException {
		if (x < tokens.length) {
			return tokens[x];
		} else {
			throw new ParseException("missing token at end of '" + context + "'", -1);
		}
	}

	private static Rule parseRule(String description) throws ParseException {
		int x = description.indexOf(58);
		if (x == -1) {
			throw new ParseException("missing ':' in rule description '" + description + "'", 0);
		} else {
			String keyword = description.substring(0, x).trim();
			if (!isValidKeyword(keyword)) {
				throw new ParseException("keyword '" + keyword + " is not valid", 0);
			} else {
				description = description.substring(x + 1).trim();
				if (description.length() == 0) {
					throw new ParseException("missing constraint in '" + description + "'", x + 1);
				} else {
					Constraint constraint = parseConstraint(description);
					Rule rule = new ConstrainedRule(keyword, constraint);
					return rule;
				}
			}
		}
	}

	private static RuleChain parseRuleChain(String description) throws ParseException {
		RuleChain rc = null;
		String[] rules = Utility.split(description, ';');

		for (int i = 0; i < rules.length; ++i) {
			Rule r = parseRule(rules[i].trim());
			if (rc == null) {
				rc = new RuleChain(r);
			} else {
				rc = rc.addRule(r);
			}
		}

		return rc;
	}

	public static PluralRules forLocale(ULocale locale) {
		return PluralRulesLoader.loader.forLocale(locale);
	}

	private static boolean isValidKeyword(String token) {
		if (token.length() > 0 && START_CHARS.contains(token.charAt(0))) {
			for (int i = 1; i < token.length(); ++i) {
				if (!CONT_CHARS.contains(token.charAt(i))) {
					return false;
				}
			}

			return true;
		} else {
			return false;
		}
	}

	private PluralRules(RuleList rules) {
		this.rules = rules;
		this.keywords = Collections.unmodifiableSet(rules.getKeywords());
	}

	public String select(double number) {
		return this.rules.select(number);
	}

	public Set<String> getKeywords() {
		return this.keywords;
	}

	public static ULocale[] getAvailableULocales() {
		return PluralRulesLoader.loader.getAvailableULocales();
	}

	public static ULocale getFunctionalEquivalent(ULocale locale, boolean[] isAvailable) {
		return PluralRulesLoader.loader.getFunctionalEquivalent(locale, isAvailable);
	}

	public String toString() {
		return "keywords: " + this.keywords + " rules: " + this.rules.toString() + " limit: " + this.getRepeatLimit();
	}

	public int hashCode() {
		return this.keywords.hashCode();
	}

	public boolean equals(Object rhs) {
		return rhs instanceof PluralRules && this.equals((PluralRules) rhs);
	}

	public boolean equals(PluralRules rhs) {
		if (rhs == null) {
			return false;
		} else if (rhs == this) {
			return true;
		} else if (!rhs.getKeywords().equals(this.keywords)) {
			return false;
		} else {
			int limit = Math.max(this.getRepeatLimit(), rhs.getRepeatLimit());

			for (int i = 0; i < limit; ++i) {
				if (!this.select((double) i).equals(rhs.select((double) i))) {
					return false;
				}
			}

			return true;
		}
	}

	private int getRepeatLimit() {
		if (this.repeatLimit == 0) {
			this.repeatLimit = this.rules.getRepeatLimit() + 1;
		}

		return this.repeatLimit;
	}

	static {
		DEFAULT = new PluralRules(new RuleChain(DEFAULT_RULE));
	}
}