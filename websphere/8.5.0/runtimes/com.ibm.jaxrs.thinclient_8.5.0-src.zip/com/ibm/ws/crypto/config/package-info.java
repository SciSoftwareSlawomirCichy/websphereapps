package com.ibm.ws.crypto.config;

interface package-info {
}