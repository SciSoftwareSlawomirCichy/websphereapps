package com.ibm.ws.wim.adapter.urbridge;

import com.ibm.websphere.security.EntryNotFoundException;
import com.ibm.websphere.security.NotImplementedException;
import com.ibm.websphere.security.Result;
import com.ibm.websphere.security.UserRegistry;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.SchemaManager;
import commonj.sdo.DataObject;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class URBridgeGroup extends URBridgeEntity {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	private static final Logger trcLogger;

	public URBridgeGroup(DataObject var1, UserRegistry var2, Map var3, String var4, Map var5) {
		super(var1, var2, var3, var4, var5);
		this.securityNameProp = (String) var3.get("groupSecurityNameProperty");
		this.uniqueIdProp = (String) var3.get("uniqueGroupIdProperty");
		this.displayNameProp = (String) var3.get("groupDisplayNameProperty");
		this.rdnProp = (String) var5.get(this.entity.getType().getName());
	}

	public String getUniqueIdForEntity(String var1) throws Exception {
		return this.reg.getUniqueGroupId(var1);
	}

	public String getSecurityNameForEntity(String var1) throws Exception {
		return this.reg.getGroupSecurityName(var1);
	}

	public String getDisplayNameForEntity(String var1) throws Exception {
		return this.reg.getGroupDisplayName(var1);
	}

	public void getUsersForGroup(List var1, int var2) throws WIMException {
		String var3 = "getUsersForGroup";
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, var3, WIMTraceHelper.printDataObject(this.entity));
		}

		String var5 = null;

		try {
			var5 = this.getSecurityName(false);
			Result var6 = this.reg.getUsersForGroup(var5, var2);
			List var7 = var6.getList();

			for (int var8 = 0; var8 < var7.size(); ++var8) {
				DataObject var9 = SchemaManager.singleton().createRootDataObject();
				DataObject var10 = var9.createDataObject("entities", "http://www.ibm.com/websphere/wim",
						URBridgeHelper.getPersonAccountType());
				DataObject var11 = var10.createDataObject("identifier");
				URBridgeEntityFactory var12 = new URBridgeEntityFactory();
				URBridgeEntity var13 = var12.createObject(var10, this.reg, this.attrMap, this.baseEntryName,
						this.entityConfigMap);
				var13.setSecurityNameProp((String) var7.get(var8));
				var13.populateEntity(var1);
				var13.setRDNPropValue(this.stripRDN((String) var7.get(var8)));
				this.entity.getList("members").add(var10);
			}
		} catch (EntryNotFoundException var14) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var5), Level.SEVERE,
					CLASSNAME, var3, var14);
		} catch (NotImplementedException var15) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var5), Level.SEVERE,
					CLASSNAME, var3, var15);
		} catch (Exception var16) {
			throw new WIMApplicationException("ENTITY_GET_FAILED",
					WIMMessageHelper.generateMsgParms(var5, var16.toString()), Level.SEVERE, CLASSNAME, var3, var16);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, var3, WIMTraceHelper.printDataObject(this.entity));
		}

	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}