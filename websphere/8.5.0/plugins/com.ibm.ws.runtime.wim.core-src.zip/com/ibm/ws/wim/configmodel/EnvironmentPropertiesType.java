package com.ibm.ws.wim.configmodel;

public interface EnvironmentPropertiesType {
	String getName();

	void setName(String var1);

	String getValue();

	void setValue(String var1);
}