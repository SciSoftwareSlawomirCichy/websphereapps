package com.ibm.ejs.cm.portability;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.sql.Connection;
import java.sql.SQLException;

public final class DB2390LocalPortabilityLayer extends DB2ConnectPortabilityLayer {
	private static DB2390LocalPortabilityLayer instance;
	private static final TraceComponent tc = Tr.register(DB2390LocalPortabilityLayer.class);

	static PortabilityLayer getPortabilityLayer(Connection conn) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPortabilityLayer", conn);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getPortabilityLayer", "DB2390LocalPortabilityLayer");
		}

		return getInstance();
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new DB2390LocalPortabilityLayer();
			instance.setIs390(1);
		}

		return instance;
	}
}