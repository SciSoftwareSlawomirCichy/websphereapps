package com.ibm.ejs.container;

public class ContainerRemoveException extends ContainerException {
	private static final long serialVersionUID = 5955342514152542284L;

	public ContainerRemoveException(String s) {
		super(s);
	}

	public ContainerRemoveException(String s, Throwable ex) {
		super(s, ex);
	}

	public ContainerRemoveException(Throwable ex) {
		super(ex);
	}
}