package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableRangeSet.1;
import com.google.common.collect.ImmutableRangeSet.AsSet;
import com.google.common.collect.ImmutableRangeSet.Builder;
import com.google.common.collect.ImmutableRangeSet.ComplementRanges;
import com.google.common.collect.ImmutableRangeSet.SerializedForm;
import com.google.common.collect.SortedLists.KeyAbsentBehavior;
import com.google.common.collect.SortedLists.KeyPresentBehavior;
import java.io.Serializable;
import java.util.NoSuchElementException;

@Beta
public final class ImmutableRangeSet<C extends Comparable> extends AbstractRangeSet<C> implements Serializable {
	private static final ImmutableRangeSet EMPTY = new ImmutableRangeSet(ImmutableList.of());
	private static final ImmutableRangeSet ALL = new ImmutableRangeSet(ImmutableList.of(Range.all()));
	private final transient ImmutableList<Range<C>> ranges;
	private transient ImmutableRangeSet<C> complement;

	public static <C extends Comparable> ImmutableRangeSet<C> of() {
		return EMPTY;
	}

	static <C extends Comparable> ImmutableRangeSet<C> all() {
		return ALL;
	}

	public static <C extends Comparable> ImmutableRangeSet<C> of(Range<C> range) {
		Preconditions.checkNotNull(range);
		if (range.isEmpty()) {
			return of();
		} else {
			return range.equals(Range.all()) ? all() : new ImmutableRangeSet(ImmutableList.of(range));
		}
	}

	public static <C extends Comparable> ImmutableRangeSet<C> copyOf(RangeSet<C> rangeSet) {
		Preconditions.checkNotNull(rangeSet);
		if (rangeSet.isEmpty()) {
			return of();
		} else if (rangeSet.encloses(Range.all())) {
			return all();
		} else {
			if (rangeSet instanceof ImmutableRangeSet) {
				ImmutableRangeSet<C> immutableRangeSet = (ImmutableRangeSet) rangeSet;
				if (!immutableRangeSet.isPartialView()) {
					return immutableRangeSet;
				}
			}

			return new ImmutableRangeSet(ImmutableList.copyOf(rangeSet.asRanges()));
		}
	}

	ImmutableRangeSet(ImmutableList<Range<C>> ranges) {
		this.ranges = ranges;
	}

	private ImmutableRangeSet(ImmutableList<Range<C>> ranges, ImmutableRangeSet<C> complement) {
		this.ranges = ranges;
		this.complement = complement;
	}

	public boolean encloses(Range<C> otherRange) {
		int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), otherRange.lowerBound,
				Ordering.natural(), KeyPresentBehavior.ANY_PRESENT, KeyAbsentBehavior.NEXT_LOWER);
		return index != -1 && ((Range) this.ranges.get(index)).encloses(otherRange);
	}

	public Range<C> rangeContaining(C value) {
		int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), Cut.belowValue(value),
				Ordering.natural(), KeyPresentBehavior.ANY_PRESENT, KeyAbsentBehavior.NEXT_LOWER);
		if (index != -1) {
			Range<C> range = (Range) this.ranges.get(index);
			return range.contains(value) ? range : null;
		} else {
			return null;
		}
	}

	public Range<C> span() {
		if (this.ranges.isEmpty()) {
			throw new NoSuchElementException();
		} else {
			return Range.create(((Range) this.ranges.get(0)).lowerBound,
					((Range) this.ranges.get(this.ranges.size() - 1)).upperBound);
		}
	}

	public boolean isEmpty() {
		return this.ranges.isEmpty();
	}

	public void add(Range<C> range) {
		throw new UnsupportedOperationException();
	}

	public void addAll(RangeSet<C> other) {
		throw new UnsupportedOperationException();
	}

	public void remove(Range<C> range) {
		throw new UnsupportedOperationException();
	}

	public void removeAll(RangeSet<C> other) {
		throw new UnsupportedOperationException();
	}

	public ImmutableSet<Range<C>> asRanges() {
		return (ImmutableSet) (this.ranges.isEmpty()
				? ImmutableSet.of()
				: new RegularImmutableSortedSet(this.ranges, Range.RANGE_LEX_ORDERING));
	}

	public ImmutableRangeSet<C> complement() {
		ImmutableRangeSet<C> result = this.complement;
		if (result != null) {
			return result;
		} else if (this.ranges.isEmpty()) {
			return this.complement = all();
		} else if (this.ranges.size() == 1 && ((Range) this.ranges.get(0)).equals(Range.all())) {
			return this.complement = of();
		} else {
			ImmutableList<Range<C>> complementRanges = new ComplementRanges(this);
			result = this.complement = new ImmutableRangeSet(complementRanges, this);
			return result;
		}
	}

	private ImmutableList<Range<C>> intersectRanges(Range<C> range) {
      if (!this.ranges.isEmpty() && !range.isEmpty()) {
         if (range.encloses(this.span())) {
            return this.ranges;
         } else {
            int fromIndex;
            if (range.hasLowerBound()) {
               fromIndex = SortedLists.binarySearch(this.ranges, Range.upperBoundFn(), range.lowerBound, KeyPresentBehavior.FIRST_AFTER, KeyAbsentBehavior.NEXT_HIGHER);
            } else {
               fromIndex = 0;
            }

            int toIndex;
            if (range.hasUpperBound()) {
               toIndex = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), range.upperBound, KeyPresentBehavior.FIRST_PRESENT, KeyAbsentBehavior.NEXT_HIGHER);
            } else {
               toIndex = this.ranges.size();
            }

            int length = toIndex - fromIndex;
            return (ImmutableList)(length == 0 ? ImmutableList.of() : new 1(this, length, fromIndex, range));
         }
      } else {
         return ImmutableList.of();
      }
   }

	public ImmutableRangeSet<C> subRangeSet(Range<C> range) {
		if (!this.isEmpty()) {
			Range<C> span = this.span();
			if (range.encloses(span)) {
				return this;
			}

			if (range.isConnected(span)) {
				return new ImmutableRangeSet(this.intersectRanges(range));
			}
		}

		return of();
	}

	public ImmutableSortedSet<C> asSet(DiscreteDomain<C> domain) {
		Preconditions.checkNotNull(domain);
		if (this.isEmpty()) {
			return ImmutableSortedSet.of();
		} else {
			Range<C> span = this.span().canonical(domain);
			if (!span.hasLowerBound()) {
				throw new IllegalArgumentException("Neither the DiscreteDomain nor this range set are bounded below");
			} else {
				if (!span.hasUpperBound()) {
					try {
						domain.maxValue();
					} catch (NoSuchElementException var4) {
						throw new IllegalArgumentException(
								"Neither the DiscreteDomain nor this range set are bounded above");
					}
				}

				return new AsSet(this, domain);
			}
		}
	}

	boolean isPartialView() {
		return this.ranges.isPartialView();
	}

	public static <C extends Comparable<?>> Builder<C> builder() {
		return new Builder();
	}

	Object writeReplace() {
		return new SerializedForm(this.ranges);
	}
}