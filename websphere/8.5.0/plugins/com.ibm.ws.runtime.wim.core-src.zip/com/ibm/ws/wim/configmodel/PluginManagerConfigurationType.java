package com.ibm.ws.wim.configmodel;

public interface PluginManagerConfigurationType {
	TopicSubscriberList getTopicSubscriberList();

	void setTopicSubscriberList(TopicSubscriberList var1);

	TopicSubscriberList createTopicSubscriberList();

	TopicRegistrationList getTopicRegistrationList();

	void setTopicRegistrationList(TopicRegistrationList var1);

	TopicRegistrationList createTopicRegistrationList();
}