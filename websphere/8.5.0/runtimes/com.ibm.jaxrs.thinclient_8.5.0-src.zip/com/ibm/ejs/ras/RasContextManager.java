package com.ibm.ejs.ras;

public class RasContextManager {
	private static ThreadLocal contextInfo = new ThreadLocal();

	static void setUnitOfWork(String unitOfWork) {
		contextInfo.set(unitOfWork);
	}

	public static String getUnitOfWork() {
		return (String) contextInfo.get();
	}
}