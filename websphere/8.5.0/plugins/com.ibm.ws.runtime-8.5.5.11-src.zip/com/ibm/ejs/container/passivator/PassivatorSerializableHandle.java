package com.ibm.ejs.container.passivator;

public interface PassivatorSerializableHandle {
	Object getSerializedObject();
}