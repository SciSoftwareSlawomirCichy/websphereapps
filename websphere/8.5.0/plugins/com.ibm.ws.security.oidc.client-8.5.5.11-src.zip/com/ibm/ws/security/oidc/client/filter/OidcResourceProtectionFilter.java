package com.ibm.ws.security.oidc.client.filter;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import javax.servlet.http.HttpServletRequest;

public class OidcResourceProtectionFilter extends CommonHTTPHeaderFilter implements HTTPHeaderFilter {
	private static final TraceComponent tc = Tr.register(OidcResourceProtectionFilter.class, "OidcClient",
			"com.ibm.ws.security.oidc.client.resources.oidcmessages");

	public OidcResourceProtectionFilter(boolean processAll) {
		super.setProcessAll(processAll);
	}

	public OidcResourceProtectionFilter(String p, boolean processAll) {
		super(p);
		super.setProcessAll(processAll);
	}

	public boolean init(String s1) {
		super.init(s1);
		boolean initialized = false;
		if (s1 == null) {
			this.nonFilter = true;
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Filter Not Defined");
			}
		} else {
			initialized = true;
		}

		return initialized;
	}

	public boolean isAccepted(HttpServletRequest req) {
		return this.isAccepted(new RealRequestInfo(req));
	}
}