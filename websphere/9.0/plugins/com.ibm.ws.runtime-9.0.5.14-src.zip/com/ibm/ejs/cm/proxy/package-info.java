package com.ibm.ejs.cm.proxy;

interface package-info {
}