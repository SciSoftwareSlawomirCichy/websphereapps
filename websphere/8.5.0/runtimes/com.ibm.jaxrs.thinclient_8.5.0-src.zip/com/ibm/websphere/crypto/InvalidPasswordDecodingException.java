package com.ibm.websphere.crypto;

public class InvalidPasswordDecodingException extends Exception {
	private static final long serialVersionUID = 177186094921802234L;
}