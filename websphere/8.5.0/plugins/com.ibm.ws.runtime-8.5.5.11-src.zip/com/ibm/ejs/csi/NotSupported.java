package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.ws.ffdc.FFDCFilter;
import javax.transaction.Transaction;

final class NotSupported extends TranStrategy {
	private static final TraceComponent tc = Tr.register(NotSupported.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	NotSupported(TransactionControlImpl txCtrl) {
		super(txCtrl);
	}

	TxCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		Transaction suspended = null;
		if (this.globalTxExists(false)) {
			suspended = this.suspendGlobalTx(2);
		}

		TxCookieImpl cookie = null;

		try {
			cookie = this.beginLocalTx(key, methodInfo, suspended);
		} catch (CSIException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.csi.NotSupported.preInvoke", "88", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Begin of local tx failed", var9);
			}

			try {
				if (suspended != null) {
					this.resumeGlobalTx(suspended, 2);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Resumed suspended global tran after start of new local tran failed");
					}
				}
			} catch (Throwable var8) {
				FFDCFilter.processException(var8, "com.ibm.ejs.csi.NotSupported.preInvoke", "98", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Saved global tx resume failed", var8);
				}
			}

			throw var9;
		}

		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		return cookie;
	}

	void postInvoke(EJBKey key, TxCookieImpl txCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		super.postInvoke(key, txCookie, methodInfo);
		if (entryEnabled) {
			Tr.exit(tc, "postInvoke");
		}

	}
}