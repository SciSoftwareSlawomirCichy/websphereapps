package com.ibm.ws.wim.util;

import java.util.Enumeration;
import java.util.Hashtable;

public class WIMObjectPool {
	protected long lObjectExpiration;
	protected Hashtable hshLocked;
	protected Hashtable hshUnLocked;
	protected String strPoolObjectClassName;

	protected WIMObjectPool() {
		this.hshLocked = new Hashtable();
		this.hshUnLocked = new Hashtable();
	}

	protected WIMObjectPool(long var1) {
		this();
		this.lObjectExpiration = var1;
	}

	public WIMObjectPool(String var1, long var2) {
		this(var2);
		this.strPoolObjectClassName = var1;
	}

	public synchronized Object checkout() {
		long var1 = System.currentTimeMillis();
		Object var3 = null;
		if (this.hshUnLocked.size() > 0) {
			Enumeration var4 = this.hshUnLocked.keys();

			while (var4.hasMoreElements()) {
				var3 = var4.nextElement();
				if (var1 - (Long) this.hshUnLocked.get(var3) > this.lObjectExpiration) {
					this.hshUnLocked.remove(var3);
					this.expire(var3);
				} else {
					if (this.validate(var3)) {
						this.hshUnLocked.remove(var3);
						this.hshLocked.put(var3, new Long(var1));
						return var3;
					}

					this.hshUnLocked.remove(var3);
					this.expire(var3);
				}
			}
		}

		var3 = this.create();
		this.hshLocked.put(var3, new Long(var1));
		return var3;
	}

	public synchronized void checkin(Object var1) {
		this.hshLocked.remove(var1);
		this.hshUnLocked.put(var1, new Long(System.currentTimeMillis()));
	}

	protected Object create() {
		Object var1 = null;

		try {
			var1 = Class.forName(this.strPoolObjectClassName).newInstance();
		} catch (Exception var3) {
			var3.printStackTrace();
		}

		return var1;
	}

	protected void expire(Object var1) {
		var1 = null;
	}

	protected boolean validate(Object var1) {
		return true;
	}
}