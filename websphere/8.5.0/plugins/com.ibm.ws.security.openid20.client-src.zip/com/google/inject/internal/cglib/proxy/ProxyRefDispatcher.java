package com.google.inject.internal.cglib.proxy;

public interface ProxyRefDispatcher extends Callback {
	Object loadObject(Object var1) throws Exception;
}