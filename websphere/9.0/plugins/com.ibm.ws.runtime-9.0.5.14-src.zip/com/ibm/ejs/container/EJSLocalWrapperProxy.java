package com.ibm.ejs.container;

import com.ibm.ejs.util.Util;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBLocalObject;
import javax.ejb.RemoveException;

public class EJSLocalWrapperProxy extends EJSLocalWrapper implements WrapperProxy {
	volatile WrapperProxyState ivState;

	public EJSLocalWrapperProxy(WrapperProxyState state) {
		this.ivState = state;
	}

	public String toString() {
		return Util.identity(this) + '(' + this.ivState + ')';
	}

	public int hashCode() {
		return this.ivState.hashCode();
	}

	public boolean equals(Object o) {
		return o instanceof EJSLocalWrapperProxy && this.ivState.equals(((EJSLocalWrapperProxy) o).ivState);
	}

	public EJBLocalHome getEJBLocalHome() {
		return ((EJBLocalObject) EJSContainer.resolveWrapperProxy(this)).getEJBLocalHome();
	}

	public Object getPrimaryKey() {
		return ((EJBLocalObject) EJSContainer.resolveWrapperProxy(this)).getPrimaryKey();
	}

	public void remove() throws RemoveException {
		((EJBLocalObject) EJSContainer.resolveWrapperProxy(this)).remove();
	}

	public boolean isIdentical(EJBLocalObject o) {
		return this.equals(o);
	}
}