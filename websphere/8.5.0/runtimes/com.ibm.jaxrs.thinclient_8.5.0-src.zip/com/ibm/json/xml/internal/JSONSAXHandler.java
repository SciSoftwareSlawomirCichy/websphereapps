package com.ibm.json.xml.internal;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Properties;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class JSONSAXHandler extends DefaultHandler {
	private static String className = "com.ibm.json.xml.transform.impl.JSONSAXHandler";
	private static Logger logger;
	private OutputStreamWriter osWriter = null;
	private JSONObject current = null;
	private Stack previousObjects = new Stack();
	private JSONObject head = null;
	private boolean compact = false;

	public JSONSAXHandler(OutputStream var1) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "JSONHander(OutputStream) <constructor>");
		}

		this.osWriter = new OutputStreamWriter(var1, "UTF-8");
		this.compact = true;
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "JSONHander(OutputStream) <constructor>");
		}

	}

	public JSONSAXHandler(OutputStream var1, boolean var2) throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "JSONHander(OutputStream, boolean) <constructor>");
		}

		this.osWriter = new OutputStreamWriter(var1, "UTF-8");
		this.compact = !var2;
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "JSONHander(OutputStream, boolean) <constructor>");
		}

	}

	public void startElement(String var1, String var2, String var3, Attributes var4) throws SAXException {
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "startElement(String,String,String,org.xml.sax.Attributes)");
		}

		Properties var5 = new Properties();
		int var6 = var4.getLength();

		for (int var7 = 0; var7 < var6; ++var7) {
			var5.put(var4.getQName(var7), var4.getValue(var7));
		}

		JSONObject var8 = new JSONObject(var2, var5);
		if (this.head == null) {
			this.head = var8;
			this.current = this.head;
		} else {
			if (this.current != null) {
				this.previousObjects.push(this.current);
				this.current.addJSONObject(var8);
			}

			this.current = var8;
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "startElement(String,String,String,org.xml.sax.Attributes)");
		}

	}

	public void endElement(String var1, String var2, String var3) throws SAXException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "endElement(String,String,String)");
		}

		if (!this.previousObjects.isEmpty()) {
			this.current = (JSONObject) this.previousObjects.pop();
		} else {
			this.current = null;
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "endElement(String,String,String)");
		}

	}

	public void characters(char[] var1, int var2, int var3) throws SAXException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "characters(char[], int, int)");
		}

		String var4 = new String(var1, var2, var3);
		if (this.current.getTagText() != null) {
			var4 = this.current.getTagText() + var4;
		}

		this.current.setTagText(var4);
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "characters(char[], int, int)");
		}

	}

	public void startDocument() throws SAXException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "startDocument()");
		}

		this.startJSON();
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "startDocument()");
		}

	}

	public void endDocument() throws SAXException {
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "endDocument()");
		}

		this.endJSON();
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "endDocument()");
		}

	}

	public void flushBuffer() throws IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "flushBuffer()");
		}

		if (this.osWriter != null) {
			this.osWriter.flush();
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "flushBuffer()");
		}

	}

	private void startJSON() throws SAXException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "startJSON()");
		}

		this.head = new JSONObject("", (Properties) null);
		this.current = this.head;
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "startJSON()");
		}

	}

	private void endJSON() throws SAXException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "endJSON()");
		}

		try {
			this.head.writeObject(this.osWriter, 0, true, this.compact);
			this.head = null;
			this.current = null;
			this.previousObjects.clear();
		} catch (Exception var3) {
			SAXException var2 = new SAXException(var3);
			var2.initCause(var3);
			throw var2;
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "endJSON()");
		}

	}

	static {
		logger = Logger.getLogger(className, (String) null);
	}
}