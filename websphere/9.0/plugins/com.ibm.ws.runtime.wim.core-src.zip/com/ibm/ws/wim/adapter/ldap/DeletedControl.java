package com.ibm.ws.wim.adapter.ldap;

import javax.naming.ldap.Control;

public class DeletedControl implements Control {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2009";
	private static final long serialVersionUID = 9068021048637697132L;

	public byte[] getEncodedValue() {
		return new byte[0];
	}

	public String getID() {
		return "1.2.840.113556.1.4.417";
	}

	public boolean isCritical() {
		return true;
	}
}