package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.Multiset.Entry;
import java.util.NoSuchElementException;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
final class SortedMultisets {
	private static <E> E getElementOrThrow(Entry<E> entry) {
		if (entry == null) {
			throw new NoSuchElementException();
		} else {
			return entry.getElement();
		}
	}

	private static <E> E getElementOrNull(@Nullable Entry<E> entry) {
		return entry == null ? null : entry.getElement();
	}
}