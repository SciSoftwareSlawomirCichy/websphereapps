package com.ibm.ejs.csi;

import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.ContainerException;
import com.ibm.ejs.container.activator.ActivationStrategy;
import com.ibm.ejs.container.activator.Activator;
import com.ibm.ejs.container.activator.EntitySessionalTranActivationStrategy;
import com.ibm.ejs.container.activator.StatefulASActivationStrategy;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.ContainerExtensionFactory;
import com.ibm.websphere.csi.PassivationPolicy;
import com.ibm.ws.ActivitySession.ActivitySessionManager;
import com.ibm.ws.ActivitySession.UserActivitySessionFactory;
import com.ibm.ws.ActivitySession.WebSphereUserActivitySession;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.metadata.ejb.WASEJBMDOrchestrator;
import java.util.Hashtable;
import java.util.List;
import javax.naming.InitialContext;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;
import javax.transaction.UserTransaction;

public class ContainerExtensionFactoryPMEImpl implements ContainerExtensionFactory {
	private static final TraceComponent tc = Tr.register(ContainerExtensionFactoryPMEImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.csi.ContainerExtensionFactoryPMEImpl";
	private static WebSphereUserActivitySession wsuas = null;
	private WASEJBMDOrchestrator ivEJBMDOrchestrator;

	public ContainerExtensionFactoryPMEImpl(WASEJBMDOrchestrator ejbMDOrchestrator) {
		try {
			this.ivEJBMDOrchestrator = ejbMDOrchestrator;
			wsuas = (WebSphereUserActivitySession) UserActivitySessionFactory.createUserActivitySession();
		} catch (Exception var3) {
			FFDCFilter.processException(var3,
					"com.ibm.ejs.csi.ContainerExtensionFactoryPMEImpl.ContainerExtensionFactoryPMEImpl", "93", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Failed to get ActivitySession");
			}
		}

	}

	public UOWControl getUOWControl(UserTransaction userTx) {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "getUOWControl for PME");
		}

		UOWControl uowCtrl = new TransactionControlImpl(userTx);
		ActivitySessionManager asm = null;

		try {
			Hashtable<String, String> env = new Hashtable();
			env.put("java.naming.factory.initial", "com.ibm.websphere.naming.genericURLInitialContextFactory");
			env.put("com.ibm.websphere.naming.generic.url.schemeid", "services");
			env.put("com.ibm.websphere.naming.generic.url.package", "com.ibm.ws.runtime");
			InitialContext context = new InitialContext(env);
			asm = (ActivitySessionManager) context.lookup("services:websphere/ActivitySessionManager");
		} catch (NameNotFoundException var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.csi.ContainerExtensionFactoryPMEImpl.getUOWControl", "123",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "the ActivitySessionManager was not found - default to Transactional UOWControl");
			}
		} catch (NamingException var8) {
			FFDCFilter.processException(var8, "com.ibm.ejs.csi.ContainerExtensionFactoryPMEImpl.getUOWControl", "128",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Naming failure looking up the ActivitySessionManager");
			}
		}

		if (asm != null) {
			uowCtrl = new UOWControlImpl((TransactionControlImpl) uowCtrl, asm);
		}

		if (entryEnabled) {
			Tr.exit(tc, "getUOWControl for PME");
		}

		return (UOWControl) uowCtrl;
	}

	public ActivationStrategy getActivationStrategy(int type, Activator activator, PassivationPolicy passivationPolicy,
			SfFailoverCache failoverCache) {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "getActivationStrategy");
		}

		ActivationStrategy as = null;
		if (type == 7) {
			as = new EntitySessionalTranActivationStrategy(activator);
		} else if (type == 3) {
			as = new StatefulASActivationStrategy(activator, passivationPolicy, failoverCache);
		}

		if (entryEnabled) {
			Tr.exit(tc, "getActivationStrategy");
		}

		return (ActivationStrategy) as;
	}

	public boolean isActivitySessionBeanManaged(boolean usesBeanManagedTx) throws ContainerException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "isActivitySessionBeanManaged");
		}

		if (entryEnabled) {
			Tr.exit(tc, "isActivitySessionBeanManaged " + usesBeanManagedTx);
		}

		return usesBeanManagedTx;
	}

	public List<ActivitySessionMethod> getActivitySessionAttributes(BeanMetaData bmd) throws Exception {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getActivitySessionAttributes");
		}

		List<ActivitySessionMethod> asMethods = this.ivEJBMDOrchestrator.getActivitySessionAttributesFromXML(bmd,
				wsuas);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getActivitySessionAttributes");
		}

		return asMethods;
	}
}