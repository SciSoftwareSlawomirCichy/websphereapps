package com.ibm.debug;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.exception.ComponentDisabledException;
import com.ibm.ws.exception.ConfigurationError;
import com.ibm.ws.exception.ConfigurationWarning;
import com.ibm.ws.runtime.component.ComponentImpl;
import com.ibm.ws.runtime.service.EJBContainer;
import com.ibm.ws.webcontainer.WebContainerService;
import com.ibm.wsspi.runtime.config.ConfigObject;
import java.util.ArrayList;
import java.util.List;

public class DebugComponentImpl extends ComponentImpl {
	EJBContainer ejbcontainer = null;
	WebContainerService webContainerService = null;
	private static final TraceComponent tc = Tr.register(DebugComponentImpl.class.getName(), "DebugComponent");
	private String debugMode;
	public static int jvmDebugPort = 7777;
	public static int bsfDebugPort = 4444;
	public static int bsfLoggingLevel = 3;
	public static DebugAgent fDebugAgent;
	public static List debugFilterClasses;

	public void initialize(Object config) throws ComponentDisabledException, ConfigurationWarning, ConfigurationError {
		ConfigObject debugConfig = (ConfigObject) config;
		if (!debugConfig.getBoolean("enable", false)) {
			throw new ComponentDisabledException();
		} else {
			jvmDebugPort = debugConfig.getInt("jvmDebugPort", 7777);
			bsfDebugPort = debugConfig.getInt("BSFDebugPort", 4444);
			bsfLoggingLevel = debugConfig.getInt("BSFLoggingLevel", 0);
			List filterClasses = debugConfig.getStringList("debugClassFilters");
			Tr.debug(tc, "filterclasses ");
			debugFilterClasses = new ArrayList();

			int i;
			for (i = 0; i < filterClasses.size(); ++i) {
				String filter = (String) filterClasses.get(i);
				debugFilterClasses.add(filter);
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "jvmDebugPort: " + jvmDebugPort);
				Tr.debug(tc, "bsfDebugPort: " + bsfDebugPort);
				Tr.debug(tc, "bsfLoggingLevel: " + bsfLoggingLevel);

				for (i = 0; i < debugFilterClasses.size(); ++i) {
					Tr.debug(tc, "filterclass: " + debugFilterClasses.get(i));
				}
			}

			this.addService(DebugComponentImpl.class, this);
		}
	}

	public void start() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "start");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "start");
		}

	}

	public void stop() {
	}

	public void destroy() {
	}

	public String getName() {
		return "com.ibm.debug.DebugComponentImpl";
	}

	public String getState() {
		return "working";
	}

	public List getDebugFilterClasses() {
		return debugFilterClasses;
	}

	public int getJvmDebugPort() {
		return jvmDebugPort;
	}

	public int getBSFDebugPort() {
		return bsfDebugPort;
	}

	public int getBSFLoggingLevel() {
		return bsfLoggingLevel;
	}
}