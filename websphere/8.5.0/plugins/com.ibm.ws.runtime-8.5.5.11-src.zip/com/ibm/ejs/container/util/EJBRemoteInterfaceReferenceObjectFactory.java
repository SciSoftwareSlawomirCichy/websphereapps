package com.ibm.ejs.container.util;

import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSHome;
import com.ibm.ejs.container.HomeRecord;
import com.ibm.ejs.csi.J2EENameImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.naming.util.ReferenceData;
import com.ibm.ws.naming.util.ReferenceObjectFactory;
import java.rmi.NoSuchObjectException;
import java.util.Properties;
import javax.naming.NamingException;

public class EJBRemoteInterfaceReferenceObjectFactory implements ReferenceObjectFactory {
	private static final String CLASS_NAME = EJBRemoteInterfaceReferenceObjectFactory.class.getName();
	private static final TraceComponent tc;
	private static final String APP_NAME_PROP = "appName";
	private static final String MODULE_NAME_PROP = "moduleName";
	private static final String COMPONENT_NAME_PROP = "componentName";
	private static final String INTERFACE_NAME_PROP = "interfaceName";
	private Class<?> ivBusinessClass;

	public static ReferenceData createReferenceData(HomeRecord hr, String interfaceName) throws NamingException {
		J2EEName j2eeName = hr.getJ2EEName();
		Properties props = new Properties();
		props.setProperty("appName", j2eeName.getApplication());
		props.setProperty("moduleName", j2eeName.getModule());
		props.setProperty("componentName", j2eeName.getComponent());
		props.setProperty("interfaceName", interfaceName);
		ReferenceData referenceData = new ReferenceData(CLASS_NAME, interfaceName, false, props);
		referenceData.setFactoryIsExecutedInSR(true);
		int beanType = hr.getBeanType();
		referenceData.setClientCachingAllowed(beanType == 3 || beanType == 2);
		return referenceData;
	}

	public Object getObject(ReferenceData referenceData) throws Exception {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getObject");
		}

		String appName = referenceData.getProperty("appName");
		String moduleName = referenceData.getProperty("moduleName");
		String componentName = referenceData.getProperty("componentName");
		J2EEName j2eeName = new J2EENameImpl(appName, moduleName, componentName);
		EJSHome home = (EJSHome) EJSContainer.homeOfHomes.getHome(j2eeName);
		if (home == null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "getObject could not find home for EJB with J2EEName = " + j2eeName);
			}

			throw ExceptionUtil.EJBException("Unable to find EJB component: " + j2eeName, (Throwable) null);
		} else {
			String businessInterfaceName = referenceData.getProperty("interfaceName");
			Class businessClass;
			synchronized (this) {
				businessClass = this.ivBusinessClass;
			}

			try {
				ClassLoader classLoader = home.getBeanMetaData().classLoader;
				if (businessClass == null) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "getObject using ClassLoader to load remote business interface: "
								+ businessInterfaceName + ", J2EEName: " + j2eeName);
					}

					businessClass = classLoader.loadClass(businessInterfaceName);
					synchronized (this) {
						this.ivBusinessClass = businessClass;
					}
				}

				Object retObj = home.createRemoteBusinessObject(businessInterfaceName, false);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "getObject returning: " + retObj);
				}

				return retObj;
			} catch (NoSuchObjectException var15) {
				FFDCFilter.processException(var15, CLASS_NAME + ".getObject", "147", this);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "Unexpected PortableRemoteObject.toStub() failure!", var15);
				}

				throw var15;
			} catch (ClassNotFoundException var16) {
				FFDCFilter.processException(var16, CLASS_NAME + ".getObject", "156", this);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "Unexpected ClassLoader.loadClass failure, remote business interface class: "
							+ businessInterfaceName);
				}

				throw ExceptionUtil.EJBException(
						"Unable to load remote business interface class: " + j2eeName + "/" + businessInterfaceName,
						(Throwable) null);
			}
		}
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}