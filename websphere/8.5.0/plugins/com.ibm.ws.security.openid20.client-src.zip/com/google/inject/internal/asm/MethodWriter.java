package com.google.inject.internal.asm;

class MethodWriter implements MethodVisitor {
	MethodWriter a;
	final ClassWriter b;
	private int c;
	private final int d;
	private final int e;
	private final String f;
	String g;
	int h;
	int i;
	int j;
	int[] k;
	private ByteVector l;
	private AnnotationWriter m;
	private AnnotationWriter n;
	private AnnotationWriter[] o;
	private AnnotationWriter[] p;
	private int S;
	private Attribute q;
	private ByteVector r = new ByteVector();
	private int s;
	private int t;
	private int u;
	private ByteVector v;
	private int w;
	private int[] x;
	private int y;
	private int[] z;
	private int A;
	private Handler B;
	private Handler C;
	private int D;
	private ByteVector E;
	private int F;
	private ByteVector G;
	private int H;
	private ByteVector I;
	private Attribute J;
	private boolean K;
	private int L;
	private final int M;
	private Label N;
	private Label O;
	private Label P;
	private int Q;
	private int R;

	MethodWriter(ClassWriter var1, int var2, String var3, String var4, String var5, String[] var6, boolean var7,
			boolean var8) {
		if (var1.A == null) {
			var1.A = this;
		} else {
			var1.B.a = this;
		}

		var1.B = this;
		this.b = var1;
		this.c = var2;
		this.d = var1.newUTF8(var3);
		this.e = var1.newUTF8(var4);
		this.f = var4;
		this.g = var5;
		int var9;
		if (var6 != null && var6.length > 0) {
			this.j = var6.length;
			this.k = new int[this.j];

			for (var9 = 0; var9 < this.j; ++var9) {
				this.k[var9] = var1.newClass(var6[var9]);
			}
		}

		this.M = var8 ? 0 : (var7 ? 1 : 2);
		if (var7 || var8) {
			if (var8 && "<init>".equals(var3)) {
				this.c |= 262144;
			}

			var9 = a(this.f) >> 2;
			if ((var2 & 8) != 0) {
				--var9;
			}

			this.t = var9;
			this.N = new Label();
			this.N.a |= 8;
			this.visitLabel(this.N);
		}

	}

	public AnnotationVisitor visitAnnotationDefault() {
		this.l = new ByteVector();
		return new AnnotationWriter(this.b, false, this.l, (ByteVector) null, 0);
	}

	public AnnotationVisitor visitAnnotation(String var1, boolean var2) {
		ByteVector var3 = new ByteVector();
		var3.putShort(this.b.newUTF8(var1)).putShort(0);
		AnnotationWriter var4 = new AnnotationWriter(this.b, true, var3, var3, 2);
		if (var2) {
			var4.g = this.m;
			this.m = var4;
		} else {
			var4.g = this.n;
			this.n = var4;
		}

		return var4;
	}

	public AnnotationVisitor visitParameterAnnotation(int var1, String var2, boolean var3) {
		ByteVector var4 = new ByteVector();
		if ("Ljava/lang/Synthetic;".equals(var2)) {
			this.S = Math.max(this.S, var1 + 1);
			return new AnnotationWriter(this.b, false, var4, (ByteVector) null, 0);
		} else {
			var4.putShort(this.b.newUTF8(var2)).putShort(0);
			AnnotationWriter var5 = new AnnotationWriter(this.b, true, var4, var4, 2);
			if (var3) {
				if (this.o == null) {
					this.o = new AnnotationWriter[Type.getArgumentTypes(this.f).length];
				}

				var5.g = this.o[var1];
				this.o[var1] = var5;
			} else {
				if (this.p == null) {
					this.p = new AnnotationWriter[Type.getArgumentTypes(this.f).length];
				}

				var5.g = this.p[var1];
				this.p[var1] = var5;
			}

			return var5;
		}
	}

	public void visitAttribute(Attribute var1) {
		if (var1.isCodeAttribute()) {
			var1.a = this.J;
			this.J = var1;
		} else {
			var1.a = this.q;
			this.q = var1;
		}

	}

	public void visitCode() {
	}

	public void visitFrame(int var1, int var2, Object[] var3, int var4, Object[] var5) {
		if (this.M != 0) {
			int var6;
			if (var1 == -1) {
				this.a(this.r.b, var2, var4);

				for (var6 = 0; var6 < var2; ++var6) {
					if (var3[var6] instanceof String) {
						this.z[this.y++] = 24117248 | this.b.c((String) var3[var6]);
					} else if (var3[var6] instanceof Integer) {
						this.z[this.y++] = (Integer) var3[var6];
					} else {
						this.z[this.y++] = 25165824 | this.b.a("", ((Label) var3[var6]).c);
					}
				}

				for (var6 = 0; var6 < var4; ++var6) {
					if (var5[var6] instanceof String) {
						this.z[this.y++] = 24117248 | this.b.c((String) var5[var6]);
					} else if (var5[var6] instanceof Integer) {
						this.z[this.y++] = (Integer) var5[var6];
					} else {
						this.z[this.y++] = 25165824 | this.b.a("", ((Label) var5[var6]).c);
					}
				}

				this.b();
			} else {
				if (this.v == null) {
					this.v = new ByteVector();
					var6 = this.r.b;
				} else {
					var6 = this.r.b - this.w - 1;
				}

				int var7;
				label69 : switch (var1) {
					case 0 :
						this.v.putByte(255).putShort(var6).putShort(var2);

						for (var7 = 0; var7 < var2; ++var7) {
							this.a(var3[var7]);
						}

						this.v.putShort(var4);

						for (var7 = 0; var7 < var4; ++var7) {
							this.a(var5[var7]);
						}
						break;
					case 1 :
						this.v.putByte(251 + var2).putShort(var6);
						var7 = 0;

						while (true) {
							if (var7 >= var2) {
								break label69;
							}

							this.a(var3[var7]);
							++var7;
						}
					case 2 :
						this.v.putByte(251 - var2).putShort(var6);
						break;
					case 3 :
						if (var6 < 64) {
							this.v.putByte(var6);
						} else {
							this.v.putByte(251).putShort(var6);
						}
						break;
					case 4 :
						if (var6 < 64) {
							this.v.putByte(64 + var6);
						} else {
							this.v.putByte(247).putShort(var6);
						}

						this.a(var5[0]);
				}

				this.w = this.r.b;
				++this.u;
			}

		}
	}

	public void visitInsn(int var1) {
		this.r.putByte(var1);
		if (this.P != null) {
			if (this.M == 0) {
				this.P.h.a(var1, 0, (ClassWriter) null, (Item) null);
			} else {
				int var2 = this.Q + Frame.a[var1];
				if (var2 > this.R) {
					this.R = var2;
				}

				this.Q = var2;
			}

			if (var1 >= 172 && var1 <= 177 || var1 == 191) {
				this.e();
			}
		}

	}

	public void visitIntInsn(int var1, int var2) {
		if (this.P != null) {
			if (this.M == 0) {
				this.P.h.a(var1, var2, (ClassWriter) null, (Item) null);
			} else if (var1 != 188) {
				int var3 = this.Q + 1;
				if (var3 > this.R) {
					this.R = var3;
				}

				this.Q = var3;
			}
		}

		if (var1 == 17) {
			this.r.b(var1, var2);
		} else {
			this.r.a(var1, var2);
		}

	}

	public void visitVarInsn(int var1, int var2) {
		int var3;
		if (this.P != null) {
			if (this.M == 0) {
				this.P.h.a(var1, var2, (ClassWriter) null, (Item) null);
			} else if (var1 == 169) {
				this.P.a |= 256;
				this.P.f = this.Q;
				this.e();
			} else {
				var3 = this.Q + Frame.a[var1];
				if (var3 > this.R) {
					this.R = var3;
				}

				this.Q = var3;
			}
		}

		if (this.M != 2) {
			if (var1 != 22 && var1 != 24 && var1 != 55 && var1 != 57) {
				var3 = var2 + 1;
			} else {
				var3 = var2 + 2;
			}

			if (var3 > this.t) {
				this.t = var3;
			}
		}

		if (var2 < 4 && var1 != 169) {
			if (var1 < 54) {
				var3 = 26 + (var1 - 21 << 2) + var2;
			} else {
				var3 = 59 + (var1 - 54 << 2) + var2;
			}

			this.r.putByte(var3);
		} else if (var2 >= 256) {
			this.r.putByte(196).b(var1, var2);
		} else {
			this.r.a(var1, var2);
		}

		if (var1 >= 54 && this.M == 0 && this.A > 0) {
			this.visitLabel(new Label());
		}

	}

	public void visitTypeInsn(int var1, String var2) {
		Item var3 = this.b.a(var2);
		if (this.P != null) {
			if (this.M == 0) {
				this.P.h.a(var1, this.r.b, this.b, var3);
			} else if (var1 == 187) {
				int var4 = this.Q + 1;
				if (var4 > this.R) {
					this.R = var4;
				}

				this.Q = var4;
			}
		}

		this.r.b(var1, var3.a);
	}

	public void visitFieldInsn(int var1, String var2, String var3, String var4) {
		Item var5 = this.b.a(var2, var3, var4);
		if (this.P != null) {
			if (this.M == 0) {
				this.P.h.a(var1, 0, this.b, var5);
			} else {
				int var7;
				label73 : {
					char var6 = var4.charAt(0);
					switch (var1) {
						case 178 :
							var7 = this.Q + (var6 != 'D' && var6 != 'J' ? 1 : 2);
							break label73;
						case 179 :
							var7 = this.Q + (var6 != 'D' && var6 != 'J' ? -1 : -2);
							break label73;
						case 180 :
							var7 = this.Q + (var6 != 'D' && var6 != 'J' ? 0 : 1);
							break label73;
					}

					var7 = this.Q + (var6 != 'D' && var6 != 'J' ? -2 : -3);
				}

				if (var7 > this.R) {
					this.R = var7;
				}

				this.Q = var7;
			}
		}

		this.r.b(var1, var5.a);
	}

	public void visitMethodInsn(int var1, String var2, String var3, String var4) {
		boolean var5 = var1 == 185;
		Item var6 = this.b.a(var2, var3, var4, var5);
		int var7 = var6.c;
		if (this.P != null) {
			if (this.M == 0) {
				this.P.h.a(var1, 0, this.b, var6);
			} else {
				if (var7 == 0) {
					var7 = a(var4);
					var6.c = var7;
				}

				int var8;
				if (var1 == 184) {
					var8 = this.Q - (var7 >> 2) + (var7 & 3) + 1;
				} else {
					var8 = this.Q - (var7 >> 2) + (var7 & 3);
				}

				if (var8 > this.R) {
					this.R = var8;
				}

				this.Q = var8;
			}
		}

		if (var5) {
			if (var7 == 0) {
				var7 = a(var4);
				var6.c = var7;
			}

			this.r.b(185, var6.a).a(var7 >> 2, 0);
		} else {
			this.r.b(var1, var6.a);
		}

	}

	public void visitJumpInsn(int var1, Label var2) {
		Label var3 = null;
		if (this.P != null) {
			if (this.M == 0) {
				this.P.h.a(var1, 0, (ClassWriter) null, (Item) null);
				Label var10000 = var2.a();
				var10000.a |= 16;
				this.a(0, var2);
				if (var1 != 167) {
					var3 = new Label();
				}
			} else if (var1 == 168) {
				if ((var2.a & 512) == 0) {
					var2.a |= 512;
					++this.L;
				}

				this.P.a |= 128;
				this.a(this.Q + 1, var2);
				var3 = new Label();
			} else {
				this.Q += Frame.a[var1];
				this.a(this.Q, var2);
			}
		}

		if ((var2.a & 2) != 0 && var2.c - this.r.b < -32768) {
			if (var1 == 167) {
				this.r.putByte(200);
			} else if (var1 == 168) {
				this.r.putByte(201);
			} else {
				if (var3 != null) {
					var3.a |= 16;
				}

				this.r.putByte(var1 <= 166 ? (var1 + 1 ^ 1) - 1 : var1 ^ 1);
				this.r.putShort(8);
				this.r.putByte(200);
			}

			var2.a(this, this.r, this.r.b - 1, true);
		} else {
			this.r.putByte(var1);
			var2.a(this, this.r, this.r.b - 1, false);
		}

		if (this.P != null) {
			if (var3 != null) {
				this.visitLabel(var3);
			}

			if (var1 == 167) {
				this.e();
			}
		}

	}

	public void visitLabel(Label var1) {
		this.K |= var1.a(this, this.r.b, this.r.a);
		if ((var1.a & 1) == 0) {
			if (this.M == 0) {
				if (this.P != null) {
					if (var1.c == this.P.c) {
						this.P.a |= var1.a & 16;
						var1.h = this.P.h;
						return;
					}

					this.a(0, var1);
				}

				this.P = var1;
				if (var1.h == null) {
					var1.h = new Frame();
					var1.h.b = var1;
				}

				if (this.O != null) {
					if (var1.c == this.O.c) {
						this.O.a |= var1.a & 16;
						var1.h = this.O.h;
						this.P = this.O;
						return;
					}

					this.O.i = var1;
				}

				this.O = var1;
			} else if (this.M == 1) {
				if (this.P != null) {
					this.P.g = this.R;
					this.a(this.Q, var1);
				}

				this.P = var1;
				this.Q = 0;
				this.R = 0;
				if (this.O != null) {
					this.O.i = var1;
				}

				this.O = var1;
			}

		}
	}

	public void visitLdcInsn(Object var1) {
		Item var2 = this.b.a(var1);
		int var3;
		if (this.P != null) {
			if (this.M == 0) {
				this.P.h.a(18, 0, this.b, var2);
			} else {
				if (var2.b != 5 && var2.b != 6) {
					var3 = this.Q + 1;
				} else {
					var3 = this.Q + 2;
				}

				if (var3 > this.R) {
					this.R = var3;
				}

				this.Q = var3;
			}
		}

		var3 = var2.a;
		if (var2.b != 5 && var2.b != 6) {
			if (var3 >= 256) {
				this.r.b(19, var3);
			} else {
				this.r.a(18, var3);
			}
		} else {
			this.r.b(20, var3);
		}

	}

	public void visitIincInsn(int var1, int var2) {
		if (this.P != null && this.M == 0) {
			this.P.h.a(132, var1, (ClassWriter) null, (Item) null);
		}

		if (this.M != 2) {
			int var3 = var1 + 1;
			if (var3 > this.t) {
				this.t = var3;
			}
		}

		if (var1 <= 255 && var2 <= 127 && var2 >= -128) {
			this.r.putByte(132).a(var1, var2);
		} else {
			this.r.putByte(196).b(132, var1).putShort(var2);
		}

	}

	public void visitTableSwitchInsn(int var1, int var2, Label var3, Label[] var4) {
		int var5 = this.r.b;
		this.r.putByte(170);
		this.r.b += (4 - this.r.b % 4) % 4;
		var3.a(this, this.r, var5, true);
		this.r.putInt(var1).putInt(var2);

		for (int var6 = 0; var6 < var4.length; ++var6) {
			var4[var6].a(this, this.r, var5, true);
		}

		this.a(var3, var4);
	}

	public void visitLookupSwitchInsn(Label var1, int[] var2, Label[] var3) {
		int var4 = this.r.b;
		this.r.putByte(171);
		this.r.b += (4 - this.r.b % 4) % 4;
		var1.a(this, this.r, var4, true);
		this.r.putInt(var3.length);

		for (int var5 = 0; var5 < var3.length; ++var5) {
			this.r.putInt(var2[var5]);
			var3[var5].a(this, this.r, var4, true);
		}

		this.a(var1, var3);
	}

	private void a(Label var1, Label[] var2) {
		if (this.P != null) {
			int var3;
			if (this.M == 0) {
				this.P.h.a(171, 0, (ClassWriter) null, (Item) null);
				this.a(0, var1);
				Label var10000 = var1.a();
				var10000.a |= 16;

				for (var3 = 0; var3 < var2.length; ++var3) {
					this.a(0, var2[var3]);
					var10000 = var2[var3].a();
					var10000.a |= 16;
				}
			} else {
				--this.Q;
				this.a(this.Q, var1);

				for (var3 = 0; var3 < var2.length; ++var3) {
					this.a(this.Q, var2[var3]);
				}
			}

			this.e();
		}

	}

	public void visitMultiANewArrayInsn(String var1, int var2) {
		Item var3 = this.b.a(var1);
		if (this.P != null) {
			if (this.M == 0) {
				this.P.h.a(197, var2, this.b, var3);
			} else {
				this.Q += 1 - var2;
			}
		}

		this.r.b(197, var3.a).putByte(var2);
	}

	public void visitTryCatchBlock(Label var1, Label var2, Label var3, String var4) {
		++this.A;
		Handler var5 = new Handler();
		var5.a = var1;
		var5.b = var2;
		var5.c = var3;
		var5.d = var4;
		var5.e = var4 != null ? this.b.newClass(var4) : 0;
		if (this.C == null) {
			this.B = var5;
		} else {
			this.C.f = var5;
		}

		this.C = var5;
	}

	public void visitLocalVariable(String var1, String var2, String var3, Label var4, Label var5, int var6) {
		if (var3 != null) {
			if (this.G == null) {
				this.G = new ByteVector();
			}

			++this.F;
			this.G.putShort(var4.c).putShort(var5.c - var4.c).putShort(this.b.newUTF8(var1))
					.putShort(this.b.newUTF8(var3)).putShort(var6);
		}

		if (this.E == null) {
			this.E = new ByteVector();
		}

		++this.D;
		this.E.putShort(var4.c).putShort(var5.c - var4.c).putShort(this.b.newUTF8(var1)).putShort(this.b.newUTF8(var2))
				.putShort(var6);
		if (this.M != 2) {
			char var7 = var2.charAt(0);
			int var8 = var6 + (var7 != 'J' && var7 != 'D' ? 1 : 2);
			if (var8 > this.t) {
				this.t = var8;
			}
		}

	}

	public void visitLineNumber(int var1, Label var2) {
		if (this.I == null) {
			this.I = new ByteVector();
		}

		++this.H;
		this.I.putShort(var2.c);
		this.I.putShort(var1);
	}

	public void visitMaxs(int var1, int var2) {
		Handler var3;
		Label var4;
		Label var5;
		Label var6;
		int var8;
		Edge var9;
		Label var17;
		if (this.M == 0) {
			for (var3 = this.B; var3 != null; var3 = var3.f) {
				var4 = var3.a.a();
				var5 = var3.c.a();
				var6 = var3.b.a();
				String var7 = var3.d == null ? "java/lang/Throwable" : var3.d;
				var8 = 24117248 | this.b.c(var7);

				for (var5.a |= 16; var4 != var6; var4 = var4.i) {
					var9 = new Edge();
					var9.a = var8;
					var9.b = var5;
					var9.c = var4.j;
					var4.j = var9;
				}
			}

			Frame var13 = this.N.h;
			Type[] var14 = Type.getArgumentTypes(this.f);
			var13.a(this.b, this.c, var14, this.t);
			this.b(var13);
			int var15 = 0;
			var17 = this.N;

			Label var18;
			while (var17 != null) {
				var18 = var17;
				var17 = var17.k;
				var18.k = null;
				var13 = var18.h;
				if ((var18.a & 16) != 0) {
					var18.a |= 32;
				}

				var18.a |= 64;
				int var21 = var13.d.length + var18.g;
				if (var21 > var15) {
					var15 = var21;
				}

				for (Edge var10 = var18.j; var10 != null; var10 = var10.c) {
					Label var11 = var10.b.a();
					boolean var12 = var13.a(this.b, var11.h, var10.a);
					if (var12 && var11.k == null) {
						var11.k = var17;
						var17 = var11;
					}
				}
			}

			this.s = var15;

			for (var18 = this.N; var18 != null; var18 = var18.i) {
				var13 = var18.h;
				if ((var18.a & 32) != 0) {
					this.b(var13);
				}

				if ((var18.a & 64) == 0) {
					Label var22 = var18.i;
					int var23 = var18.c;
					int var24 = (var22 == null ? this.r.b : var22.c) - 1;
					if (var24 >= var23) {
						for (int var25 = var23; var25 < var24; ++var25) {
							this.r.a[var25] = 0;
						}

						this.r.a[var24] = -65;
						this.a(var23, 0, 1);
						this.z[this.y++] = 24117248 | this.b.c("java/lang/Throwable");
						this.b();
					}
				}
			}
		} else if (this.M == 1) {
			for (var3 = this.B; var3 != null; var3 = var3.f) {
				var4 = var3.a;
				var5 = var3.c;

				for (var6 = var3.b; var4 != var6; var4 = var4.i) {
					Edge var19 = new Edge();
					var19.a = Integer.MAX_VALUE;
					var19.b = var5;
					if ((var4.a & 128) == 0) {
						var19.c = var4.j;
						var4.j = var19;
					} else {
						var19.c = var4.j.c.c;
						var4.j.c.c = var19;
					}
				}
			}

			int var16;
			if (this.L > 0) {
				var16 = 0;
				this.N.b((Label) null, 1L, this.L);

				for (var5 = this.N; var5 != null; var5 = var5.i) {
					if ((var5.a & 128) != 0) {
						var6 = var5.j.c.b;
						if ((var6.a & 1024) == 0) {
							++var16;
							var6.b((Label) null, (long) var16 / 32L << 32 | 1L << var16 % 32, this.L);
						}
					}
				}

				for (var5 = this.N; var5 != null; var5 = var5.i) {
					if ((var5.a & 128) != 0) {
						for (var6 = this.N; var6 != null; var6 = var6.i) {
							var6.a &= -1025;
						}

						var17 = var5.j.c.b;
						var17.b(var5, 0L, this.L);
					}
				}
			}

			var16 = 0;
			var5 = this.N;

			while (var5 != null) {
				var6 = var5;
				var5 = var5.k;
				int var20 = var6.f;
				var8 = var20 + var6.g;
				if (var8 > var16) {
					var16 = var8;
				}

				var9 = var6.j;
				if ((var6.a & 128) != 0) {
					var9 = var9.c;
				}

				for (; var9 != null; var9 = var9.c) {
					var6 = var9.b;
					if ((var6.a & 8) == 0) {
						var6.f = var9.a == Integer.MAX_VALUE ? 1 : var20 + var9.a;
						var6.a |= 8;
						var6.k = var5;
						var5 = var6;
					}
				}
			}

			this.s = var16;
		} else {
			this.s = var1;
			this.t = var2;
		}

	}

	public void visitEnd() {
	}

	static int a(String var0) {
		int var1 = 1;
		int var2 = 1;

		while (true) {
			while (true) {
				char var3 = var0.charAt(var2++);
				if (var3 == ')') {
					var3 = var0.charAt(var2);
					return var1 << 2 | (var3 == 'V' ? 0 : (var3 != 'D' && var3 != 'J' ? 1 : 2));
				}

				if (var3 == 'L') {
					while (var0.charAt(var2++) != ';') {
						;
					}

					++var1;
				} else if (var3 != '[') {
					if (var3 != 'D' && var3 != 'J') {
						++var1;
					} else {
						var1 += 2;
					}
				} else {
					while ((var3 = var0.charAt(var2)) == '[') {
						++var2;
					}

					if (var3 == 'D' || var3 == 'J') {
						--var1;
					}
				}
			}
		}
	}

	private void a(int var1, Label var2) {
		Edge var3 = new Edge();
		var3.a = var1;
		var3.b = var2;
		var3.c = this.P.j;
		this.P.j = var3;
	}

	private void e() {
		if (this.M == 0) {
			Label var1 = new Label();
			var1.h = new Frame();
			var1.h.b = var1;
			var1.a(this, this.r.b, this.r.a);
			this.O.i = var1;
			this.O = var1;
		} else {
			this.P.g = this.R;
		}

		this.P = null;
	}

	private void b(Frame var1) {
		int var2 = 0;
		int var3 = 0;
		int var4 = 0;
		int[] var5 = var1.c;
		int[] var6 = var1.d;

		int var7;
		int var8;
		for (var7 = 0; var7 < var5.length; ++var7) {
			var8 = var5[var7];
			if (var8 == 16777216) {
				++var2;
			} else {
				var3 += var2 + 1;
				var2 = 0;
			}

			if (var8 == 16777220 || var8 == 16777219) {
				++var7;
			}
		}

		for (var7 = 0; var7 < var6.length; ++var7) {
			var8 = var6[var7];
			++var4;
			if (var8 == 16777220 || var8 == 16777219) {
				++var7;
			}
		}

		this.a(var1.b.c, var3, var4);

		for (var7 = 0; var3 > 0; --var3) {
			var8 = var5[var7];
			this.z[this.y++] = var8;
			if (var8 == 16777220 || var8 == 16777219) {
				++var7;
			}

			++var7;
		}

		for (var7 = 0; var7 < var6.length; ++var7) {
			var8 = var6[var7];
			this.z[this.y++] = var8;
			if (var8 == 16777220 || var8 == 16777219) {
				++var7;
			}
		}

		this.b();
	}

	private void a(int var1, int var2, int var3) {
		int var4 = 3 + var2 + var3;
		if (this.z == null || this.z.length < var4) {
			this.z = new int[var4];
		}

		this.z[0] = var1;
		this.z[1] = var2;
		this.z[2] = var3;
		this.y = 3;
	}

	private void b() {
		if (this.x != null) {
			if (this.v == null) {
				this.v = new ByteVector();
			}

			this.c();
			++this.u;
		}

		this.x = this.z;
		this.z = null;
	}

	private void c() {
		int var1 = this.z[1];
		int var2 = this.z[2];
		if ((this.b.b & '￿') < 50) {
			this.v.putShort(this.z[0]).putShort(var1);
			this.a(3, 3 + var1);
			this.v.putShort(var2);
			this.a(3 + var1, 3 + var1 + var2);
		} else {
			int var3 = this.x[1];
			int var4 = 255;
			int var5 = 0;
			int var6;
			if (this.u == 0) {
				var6 = this.z[0];
			} else {
				var6 = this.z[0] - this.x[0] - 1;
			}

			if (var2 == 0) {
				var5 = var1 - var3;
				switch (var5) {
					case -3 :
					case -2 :
					case -1 :
						var4 = 248;
						var3 = var1;
						break;
					case 0 :
						var4 = var6 < 64 ? 0 : 251;
						break;
					case 1 :
					case 2 :
					case 3 :
						var4 = 252;
				}
			} else if (var1 == var3 && var2 == 1) {
				var4 = var6 < 63 ? 64 : 247;
			}

			if (var4 != 255) {
				int var7 = 3;

				for (int var8 = 0; var8 < var3; ++var8) {
					if (this.z[var7] != this.x[var7]) {
						var4 = 255;
						break;
					}

					++var7;
				}
			}

			switch (var4) {
				case 0 :
					this.v.putByte(var6);
					break;
				case 64 :
					this.v.putByte(64 + var6);
					this.a(3 + var1, 4 + var1);
					break;
				case 247 :
					this.v.putByte(247).putShort(var6);
					this.a(3 + var1, 4 + var1);
					break;
				case 248 :
					this.v.putByte(251 + var5).putShort(var6);
					break;
				case 251 :
					this.v.putByte(251).putShort(var6);
					break;
				case 252 :
					this.v.putByte(251 + var5).putShort(var6);
					this.a(3 + var3, 3 + var1);
					break;
				default :
					this.v.putByte(255).putShort(var6).putShort(var1);
					this.a(3, 3 + var1);
					this.v.putShort(var2);
					this.a(3 + var1, 3 + var1 + var2);
			}

		}
	}

	private void a(int var1, int var2) {
		for (int var3 = var1; var3 < var2; ++var3) {
			int var4 = this.z[var3];
			int var5 = var4 & -268435456;
			if (var5 == 0) {
				int var7 = var4 & 1048575;
				switch (var4 & 267386880) {
					case 24117248 :
						this.v.putByte(7).putShort(this.b.newClass(this.b.E[var7].g));
						break;
					case 25165824 :
						this.v.putByte(8).putShort(this.b.E[var7].c);
						break;
					default :
						this.v.putByte(var7);
				}
			} else {
				StringBuffer var6 = new StringBuffer();
				var5 >>= 28;

				while (var5-- > 0) {
					var6.append('[');
				}

				if ((var4 & 267386880) == 24117248) {
					var6.append('L');
					var6.append(this.b.E[var4 & 1048575].g);
					var6.append(';');
				} else {
					switch (var4 & 15) {
						case 1 :
							var6.append('I');
							break;
						case 2 :
							var6.append('F');
							break;
						case 3 :
							var6.append('D');
							break;
						case 4 :
						case 5 :
						case 6 :
						case 7 :
						case 8 :
						default :
							var6.append('J');
							break;
						case 9 :
							var6.append('Z');
							break;
						case 10 :
							var6.append('B');
							break;
						case 11 :
							var6.append('C');
							break;
						case 12 :
							var6.append('S');
					}
				}

				this.v.putByte(7).putShort(this.b.newClass(var6.toString()));
			}
		}

	}

	private void a(Object var1) {
		if (var1 instanceof String) {
			this.v.putByte(7).putShort(this.b.newClass((String) var1));
		} else if (var1 instanceof Integer) {
			this.v.putByte((Integer) var1);
		} else {
			this.v.putByte(8).putShort(((Label) var1).c);
		}

	}

	final int a() {
		if (this.h != 0) {
			return 6 + this.i;
		} else {
			if (this.K) {
				this.d();
			}

			int var1 = 8;
			if (this.r.b > 0) {
				this.b.newUTF8("Code");
				var1 += 18 + this.r.b + 8 * this.A;
				if (this.E != null) {
					this.b.newUTF8("LocalVariableTable");
					var1 += 8 + this.E.b;
				}

				if (this.G != null) {
					this.b.newUTF8("LocalVariableTypeTable");
					var1 += 8 + this.G.b;
				}

				if (this.I != null) {
					this.b.newUTF8("LineNumberTable");
					var1 += 8 + this.I.b;
				}

				if (this.v != null) {
					boolean var2 = (this.b.b & '￿') >= 50;
					this.b.newUTF8(var2 ? "StackMapTable" : "StackMap");
					var1 += 8 + this.v.b;
				}

				if (this.J != null) {
					var1 += this.J.a(this.b, this.r.a, this.r.b, this.s, this.t);
				}
			}

			if (this.j > 0) {
				this.b.newUTF8("Exceptions");
				var1 += 8 + 2 * this.j;
			}

			if ((this.c & 4096) != 0 && (this.b.b & '￿') < 49) {
				this.b.newUTF8("Synthetic");
				var1 += 6;
			}

			if ((this.c & 131072) != 0) {
				this.b.newUTF8("Deprecated");
				var1 += 6;
			}

			if (this.g != null) {
				this.b.newUTF8("Signature");
				this.b.newUTF8(this.g);
				var1 += 8;
			}

			if (this.l != null) {
				this.b.newUTF8("AnnotationDefault");
				var1 += 6 + this.l.b;
			}

			if (this.m != null) {
				this.b.newUTF8("RuntimeVisibleAnnotations");
				var1 += 8 + this.m.a();
			}

			if (this.n != null) {
				this.b.newUTF8("RuntimeInvisibleAnnotations");
				var1 += 8 + this.n.a();
			}

			int var3;
			if (this.o != null) {
				this.b.newUTF8("RuntimeVisibleParameterAnnotations");
				var1 += 7 + 2 * (this.o.length - this.S);

				for (var3 = this.o.length - 1; var3 >= this.S; --var3) {
					var1 += this.o[var3] == null ? 0 : this.o[var3].a();
				}
			}

			if (this.p != null) {
				this.b.newUTF8("RuntimeInvisibleParameterAnnotations");
				var1 += 7 + 2 * (this.p.length - this.S);

				for (var3 = this.p.length - 1; var3 >= this.S; --var3) {
					var1 += this.p[var3] == null ? 0 : this.p[var3].a();
				}
			}

			if (this.q != null) {
				var1 += this.q.a(this.b, (byte[]) null, 0, -1, -1);
			}

			return var1;
		}
	}

	final void a(ByteVector var1) {
		var1.putShort(this.c).putShort(this.d).putShort(this.e);
		if (this.h != 0) {
			var1.putByteArray(this.b.J.b, this.h, this.i);
		} else {
			int var2 = 0;
			if (this.r.b > 0) {
				++var2;
			}

			if (this.j > 0) {
				++var2;
			}

			if ((this.c & 4096) != 0 && (this.b.b & '￿') < 49) {
				++var2;
			}

			if ((this.c & 131072) != 0) {
				++var2;
			}

			if (this.g != null) {
				++var2;
			}

			if (this.l != null) {
				++var2;
			}

			if (this.m != null) {
				++var2;
			}

			if (this.n != null) {
				++var2;
			}

			if (this.o != null) {
				++var2;
			}

			if (this.p != null) {
				++var2;
			}

			if (this.q != null) {
				var2 += this.q.a();
			}

			var1.putShort(var2);
			int var3;
			if (this.r.b > 0) {
				var3 = 12 + this.r.b + 8 * this.A;
				if (this.E != null) {
					var3 += 8 + this.E.b;
				}

				if (this.G != null) {
					var3 += 8 + this.G.b;
				}

				if (this.I != null) {
					var3 += 8 + this.I.b;
				}

				if (this.v != null) {
					var3 += 8 + this.v.b;
				}

				if (this.J != null) {
					var3 += this.J.a(this.b, this.r.a, this.r.b, this.s, this.t);
				}

				var1.putShort(this.b.newUTF8("Code")).putInt(var3);
				var1.putShort(this.s).putShort(this.t);
				var1.putInt(this.r.b).putByteArray(this.r.a, 0, this.r.b);
				var1.putShort(this.A);
				if (this.A > 0) {
					for (Handler var4 = this.B; var4 != null; var4 = var4.f) {
						var1.putShort(var4.a.c).putShort(var4.b.c).putShort(var4.c.c).putShort(var4.e);
					}
				}

				var2 = 0;
				if (this.E != null) {
					++var2;
				}

				if (this.G != null) {
					++var2;
				}

				if (this.I != null) {
					++var2;
				}

				if (this.v != null) {
					++var2;
				}

				if (this.J != null) {
					var2 += this.J.a();
				}

				var1.putShort(var2);
				if (this.E != null) {
					var1.putShort(this.b.newUTF8("LocalVariableTable"));
					var1.putInt(this.E.b + 2).putShort(this.D);
					var1.putByteArray(this.E.a, 0, this.E.b);
				}

				if (this.G != null) {
					var1.putShort(this.b.newUTF8("LocalVariableTypeTable"));
					var1.putInt(this.G.b + 2).putShort(this.F);
					var1.putByteArray(this.G.a, 0, this.G.b);
				}

				if (this.I != null) {
					var1.putShort(this.b.newUTF8("LineNumberTable"));
					var1.putInt(this.I.b + 2).putShort(this.H);
					var1.putByteArray(this.I.a, 0, this.I.b);
				}

				if (this.v != null) {
					boolean var5 = (this.b.b & '￿') >= 50;
					var1.putShort(this.b.newUTF8(var5 ? "StackMapTable" : "StackMap"));
					var1.putInt(this.v.b + 2).putShort(this.u);
					var1.putByteArray(this.v.a, 0, this.v.b);
				}

				if (this.J != null) {
					this.J.a(this.b, this.r.a, this.r.b, this.t, this.s, var1);
				}
			}

			if (this.j > 0) {
				var1.putShort(this.b.newUTF8("Exceptions")).putInt(2 * this.j + 2);
				var1.putShort(this.j);

				for (var3 = 0; var3 < this.j; ++var3) {
					var1.putShort(this.k[var3]);
				}
			}

			if ((this.c & 4096) != 0 && (this.b.b & '￿') < 49) {
				var1.putShort(this.b.newUTF8("Synthetic")).putInt(0);
			}

			if ((this.c & 131072) != 0) {
				var1.putShort(this.b.newUTF8("Deprecated")).putInt(0);
			}

			if (this.g != null) {
				var1.putShort(this.b.newUTF8("Signature")).putInt(2).putShort(this.b.newUTF8(this.g));
			}

			if (this.l != null) {
				var1.putShort(this.b.newUTF8("AnnotationDefault"));
				var1.putInt(this.l.b);
				var1.putByteArray(this.l.a, 0, this.l.b);
			}

			if (this.m != null) {
				var1.putShort(this.b.newUTF8("RuntimeVisibleAnnotations"));
				this.m.a(var1);
			}

			if (this.n != null) {
				var1.putShort(this.b.newUTF8("RuntimeInvisibleAnnotations"));
				this.n.a(var1);
			}

			if (this.o != null) {
				var1.putShort(this.b.newUTF8("RuntimeVisibleParameterAnnotations"));
				AnnotationWriter.a(this.o, this.S, var1);
			}

			if (this.p != null) {
				var1.putShort(this.b.newUTF8("RuntimeInvisibleParameterAnnotations"));
				AnnotationWriter.a(this.p, this.S, var1);
			}

			if (this.q != null) {
				this.q.a(this.b, (byte[]) null, 0, -1, -1, var1);
			}

		}
	}

	private void d() {
		byte[] var1 = this.r.a;
		int[] var2 = new int[0];
		int[] var3 = new int[0];
		boolean[] var4 = new boolean[this.r.b];
		int var5 = 3;

		int var6;
		int var8;
		int var9;
		int var10;
		do {
			if (var5 == 3) {
				var5 = 2;
			}

			var6 = 0;

			while (var6 < var1.length) {
				int var7 = var1[var6] & 255;
				var8 = 0;
				switch (ClassWriter.a[var7]) {
					case 0 :
					case 4 :
						++var6;
						break;
					case 1 :
					case 3 :
					case 10 :
						var6 += 2;
						break;
					case 2 :
					case 5 :
					case 6 :
					case 11 :
					case 12 :
						var6 += 3;
						break;
					case 7 :
						var6 += 5;
						break;
					case 8 :
						if (var7 > 201) {
							var7 = var7 < 218 ? var7 - 49 : var7 - 20;
							var9 = var6 + c(var1, var6 + 1);
						} else {
							var9 = var6 + b(var1, var6 + 1);
						}

						var10 = a(var2, var3, var6, var9);
						if ((var10 < -32768 || var10 > 32767) && !var4[var6]) {
							if (var7 != 167 && var7 != 168) {
								var8 = 5;
							} else {
								var8 = 2;
							}

							var4[var6] = true;
						}

						var6 += 3;
						break;
					case 9 :
						var6 += 5;
						break;
					case 13 :
						if (var5 == 1) {
							var10 = a(var2, var3, 0, var6);
							var8 = -(var10 & 3);
						} else if (!var4[var6]) {
							var8 = var6 & 3;
							var4[var6] = true;
						}

						var6 = var6 + 4 - (var6 & 3);
						var6 += 4 * (a(var1, var6 + 8) - a(var1, var6 + 4) + 1) + 12;
						break;
					case 14 :
						if (var5 == 1) {
							var10 = a(var2, var3, 0, var6);
							var8 = -(var10 & 3);
						} else if (!var4[var6]) {
							var8 = var6 & 3;
							var4[var6] = true;
						}

						var6 = var6 + 4 - (var6 & 3);
						var6 += 8 * a(var1, var6 + 4) + 8;
						break;
					case 15 :
					default :
						var6 += 4;
						break;
					case 16 :
						var7 = var1[var6 + 1] & 255;
						if (var7 == 132) {
							var6 += 6;
						} else {
							var6 += 4;
						}
				}

				if (var8 != 0) {
					int[] var11 = new int[var2.length + 1];
					int[] var12 = new int[var3.length + 1];
					System.arraycopy(var2, 0, var11, 0, var2.length);
					System.arraycopy(var3, 0, var12, 0, var3.length);
					var11[var2.length] = var6;
					var12[var3.length] = var8;
					var2 = var11;
					var3 = var12;
					if (var8 > 0) {
						var5 = 3;
					}
				}
			}

			if (var5 < 3) {
				--var5;
			}
		} while (var5 != 0);

		ByteVector var16 = new ByteVector(this.r.b);
		var6 = 0;

		while (true) {
			label220 : while (var6 < this.r.b) {
				var8 = var1[var6] & 255;
				int var13;
				int var14;
				switch (ClassWriter.a[var8]) {
					case 0 :
					case 4 :
						var16.putByte(var8);
						++var6;
						break;
					case 1 :
					case 3 :
					case 10 :
						var16.putByteArray(var1, var6, 2);
						var6 += 2;
						break;
					case 2 :
					case 5 :
					case 6 :
					case 11 :
					case 12 :
						var16.putByteArray(var1, var6, 3);
						var6 += 3;
						break;
					case 7 :
						var16.putByteArray(var1, var6, 5);
						var6 += 5;
						break;
					case 8 :
						if (var8 > 201) {
							var8 = var8 < 218 ? var8 - 49 : var8 - 20;
							var9 = var6 + c(var1, var6 + 1);
						} else {
							var9 = var6 + b(var1, var6 + 1);
						}

						var10 = a(var2, var3, var6, var9);
						if (var4[var6]) {
							if (var8 == 167) {
								var16.putByte(200);
							} else if (var8 == 168) {
								var16.putByte(201);
							} else {
								var16.putByte(var8 <= 166 ? (var8 + 1 ^ 1) - 1 : var8 ^ 1);
								var16.putShort(8);
								var16.putByte(200);
								var10 -= 3;
							}

							var16.putInt(var10);
						} else {
							var16.putByte(var8);
							var16.putShort(var10);
						}

						var6 += 3;
						break;
					case 9 :
						var9 = var6 + a(var1, var6 + 1);
						var10 = a(var2, var3, var6, var9);
						var16.putByte(var8);
						var16.putInt(var10);
						var6 += 5;
						break;
					case 13 :
						var13 = var6;
						var6 = var6 + 4 - (var6 & 3);
						var16.putByte(170);
						var16.b += (4 - var16.b % 4) % 4;
						var9 = var13 + a(var1, var6);
						var6 += 4;
						var10 = a(var2, var3, var13, var9);
						var16.putInt(var10);
						var14 = a(var1, var6);
						var6 += 4;
						var16.putInt(var14);
						var14 = a(var1, var6) - var14 + 1;
						var6 += 4;
						var16.putInt(a(var1, var6 - 4));

						while (true) {
							if (var14 <= 0) {
								continue label220;
							}

							var9 = var13 + a(var1, var6);
							var6 += 4;
							var10 = a(var2, var3, var13, var9);
							var16.putInt(var10);
							--var14;
						}
					case 14 :
						var13 = var6;
						var6 = var6 + 4 - (var6 & 3);
						var16.putByte(171);
						var16.b += (4 - var16.b % 4) % 4;
						var9 = var13 + a(var1, var6);
						var6 += 4;
						var10 = a(var2, var3, var13, var9);
						var16.putInt(var10);
						var14 = a(var1, var6);
						var6 += 4;
						var16.putInt(var14);

						while (true) {
							if (var14 <= 0) {
								continue label220;
							}

							var16.putInt(a(var1, var6));
							var6 += 4;
							var9 = var13 + a(var1, var6);
							var6 += 4;
							var10 = a(var2, var3, var13, var9);
							var16.putInt(var10);
							--var14;
						}
					case 15 :
					default :
						var16.putByteArray(var1, var6, 4);
						var6 += 4;
						break;
					case 16 :
						var8 = var1[var6 + 1] & 255;
						if (var8 == 132) {
							var16.putByteArray(var1, var6, 6);
							var6 += 6;
						} else {
							var16.putByteArray(var1, var6, 4);
							var6 += 4;
						}
				}
			}

			if (this.u > 0) {
				if (this.M == 0) {
					this.u = 0;
					this.v = null;
					this.x = null;
					this.z = null;
					Frame var20 = new Frame();
					var20.b = this.N;
					Type[] var17 = Type.getArgumentTypes(this.f);
					var20.a(this.b, this.c, var17, this.t);
					this.b(var20);

					for (Label var21 = this.N; var21 != null; var21 = var21.i) {
						var6 = var21.c - 3;
						if ((var21.a & 32) != 0 || var6 >= 0 && var4[var6]) {
							a(var2, var3, var21);
							this.b(var21.h);
						}
					}
				} else {
					this.b.I = true;
				}
			}

			for (Handler var22 = this.B; var22 != null; var22 = var22.f) {
				a(var2, var3, var22.a);
				a(var2, var3, var22.b);
				a(var2, var3, var22.c);
			}

			int var15;
			for (var15 = 0; var15 < 2; ++var15) {
				ByteVector var18 = var15 == 0 ? this.E : this.G;
				if (var18 != null) {
					var1 = var18.a;

					for (var6 = 0; var6 < var18.b; var6 += 10) {
						var9 = c(var1, var6);
						var10 = a(var2, var3, 0, var9);
						a(var1, var6, var10);
						var9 += c(var1, var6 + 2);
						var10 = a(var2, var3, 0, var9) - var10;
						a(var1, var6 + 2, var10);
					}
				}
			}

			if (this.I != null) {
				var1 = this.I.a;

				for (var6 = 0; var6 < this.I.b; var6 += 4) {
					a(var1, var6, a(var2, var3, 0, c(var1, var6)));
				}
			}

			for (Attribute var19 = this.J; var19 != null; var19 = var19.a) {
				Label[] var23 = var19.getLabels();
				if (var23 != null) {
					for (var15 = var23.length - 1; var15 >= 0; --var15) {
						a(var2, var3, var23[var15]);
					}
				}
			}

			this.r = var16;
			return;
		}
	}

	static int c(byte[] var0, int var1) {
		return (var0[var1] & 255) << 8 | var0[var1 + 1] & 255;
	}

	static short b(byte[] var0, int var1) {
		return (short) ((var0[var1] & 255) << 8 | var0[var1 + 1] & 255);
	}

	static int a(byte[] var0, int var1) {
		return (var0[var1] & 255) << 24 | (var0[var1 + 1] & 255) << 16 | (var0[var1 + 2] & 255) << 8
				| var0[var1 + 3] & 255;
	}

	static void a(byte[] var0, int var1, int var2) {
		var0[var1] = (byte) (var2 >>> 8);
		var0[var1 + 1] = (byte) var2;
	}

	static int a(int[] var0, int[] var1, int var2, int var3) {
		int var4 = var3 - var2;

		for (int var5 = 0; var5 < var0.length; ++var5) {
			if (var2 < var0[var5] && var0[var5] <= var3) {
				var4 += var1[var5];
			} else if (var3 < var0[var5] && var0[var5] <= var2) {
				var4 -= var1[var5];
			}
		}

		return var4;
	}

	static void a(int[] var0, int[] var1, Label var2) {
		if ((var2.a & 4) == 0) {
			var2.c = a(var0, var1, 0, var2.c);
			var2.a |= 4;
		}

	}
}