package com.google.common.escape;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.escape.Escapers.1;
import com.google.common.escape.Escapers.2;
import com.google.common.escape.Escapers.Builder;

@Beta
@GwtCompatible
public final class Escapers {
	private static final Escaper NULL_ESCAPER = new 1();

	public static Escaper nullEscaper() {
		return NULL_ESCAPER;
	}

	public static Builder builder() {
      return new Builder((1)null);
   }

	static UnicodeEscaper asUnicodeEscaper(Escaper escaper) {
		Preconditions.checkNotNull(escaper);
		if (escaper instanceof UnicodeEscaper) {
			return (UnicodeEscaper) escaper;
		} else if (escaper instanceof CharEscaper) {
			return wrap((CharEscaper) escaper);
		} else {
			throw new IllegalArgumentException("Cannot create a UnicodeEscaper from: " + escaper.getClass().getName());
		}
	}

	public static String computeReplacement(CharEscaper escaper, char c) {
		return stringOrNull(escaper.escape(c));
	}

	public static String computeReplacement(UnicodeEscaper escaper, int cp) {
		return stringOrNull(escaper.escape(cp));
	}

	private static String stringOrNull(char[] in) {
		return in == null ? null : new String(in);
	}

	private static UnicodeEscaper wrap(CharEscaper escaper) {
      return new 2(escaper);
   }
}