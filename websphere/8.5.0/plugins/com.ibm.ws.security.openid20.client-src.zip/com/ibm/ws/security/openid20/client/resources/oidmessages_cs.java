package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_cs extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: Závislé straně OpenID (RP) se nezdařilo přesměrovat uživatele k poskytovateli OpenID (OP) pro ověření, kvůli výjimce [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: Závislou stranu OpenID (RP) se nezdařilo inicializovat, protože se jí nezdařilo získat výchozí SSLContext pro server WebSphere. Jde o výjimku [{0}]."},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: Závislé straně OpenID (RP) se nezdařilo připojit k poskytovateli OpenID (OP) určenému identifikátorem [{0}], kvůli výjimce [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: Závislou stranu OpenID (RP) se nezdařilo inicializovat kvůli výjimce [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: Závislá strana OpenID (RP) se inicializovala, protože hodnota vlastnosti [{0}] není správně naformátovaná."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: Závislé straně OpenID (RP) se nezdařilo ověřit požadavek používající token základního ověření, protože je hodnota tokenu neplatná."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: Závislou stranu OpenID (RP) se nezdařilo inicializovat, protože není správně zadaná vlastnost [{0}]. Má se jednat o platnou adresu URL."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: Závislá strana OpenID (RP) obdržela od poskytovatele OpenID (OP) nesprávnou odpověď. Příčinou této chyby je [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: Závislé straně OpenID (RP) se nezdařilo provést ověření, protože dosáhla maximální kapacity interní mezipaměti."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: Závislou stranu OpenID (RP) se nezdařilo inicializovat kvůli chybějící povinné vlastnosti axRequiredAttribute[n]. Alespoň jedna vlastnost musí být definována."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: Nezdařilo se inicializovat závislou stranu OpenID (RP), protože chybí nebo je prázdná hodnota povinné vlastnosti [{0}]."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: Závislá strana OpenID (RP) vyžaduje SSL (HTTPS), ale adresa URL poskytovatele OpenID (OP) využívá HTTP: [{0}]. Atribut [{1}] by měl odpovídat schématu cílové adresy URL. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: Závislá strana OpenID (RP) obdržela odpověď od poskytovatele OpenID (OP), který nepodporuje specifikaci OpenID verze 2."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: Závislá strana OpenID (RP) se nezdařila při ověřování odezvy získané od poskytovatele OpenID (OP). Došlo k výjimce [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}