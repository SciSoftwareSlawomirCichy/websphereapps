package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.ffdc.FFDCFilter;
import javax.transaction.Transaction;

final class Required extends TranStrategy {
	private static final TraceComponent tc = Tr.register(Required.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	Required(TransactionControlImpl txCtrl) {
		super(txCtrl);
	}

	TxCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		LocalTransactionCoordinator savedLocalTx = this.suspendLocalTx();
		boolean begun = false;

		try {
			if (!this.globalTxExists(true)) {
				this.beginGlobalTx(key, methodInfo);
				begun = true;
			}
		} catch (CSIException var9) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Begin of global tx failed", var9);
			}

			if (savedLocalTx != null) {
				try {
					this.resumeLocalTx(savedLocalTx);
				} catch (Throwable var8) {
					FFDCFilter.processException(var8, "com.ibm.ejs.csi.Required.preInvoke", "95", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Saved local tx resume failed", var8);
					}
				}
			}

			throw var9;
		}

		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		TxCookieImpl cookie = new TxCookieImpl(begun, false, this, (Transaction) null);
		cookie.suspendedLocalTx = savedLocalTx;
		return cookie;
	}
}