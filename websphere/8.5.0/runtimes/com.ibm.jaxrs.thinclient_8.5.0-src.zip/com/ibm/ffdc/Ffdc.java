package com.ibm.ffdc;

import com.ibm.ffdc.util.provider.Incident;

public interface Ffdc {
	boolean isLoggable();

	void log(Object... var1);

	Incident getIncident();
}