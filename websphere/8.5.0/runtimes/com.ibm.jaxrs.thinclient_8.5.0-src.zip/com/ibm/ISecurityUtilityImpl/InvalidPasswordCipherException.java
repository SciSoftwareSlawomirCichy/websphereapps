package com.ibm.ISecurityUtilityImpl;

import org.omg.CORBA.UserException;

public class InvalidPasswordCipherException extends UserException {
	private static final long serialVersionUID = -4137060197629244051L;
}