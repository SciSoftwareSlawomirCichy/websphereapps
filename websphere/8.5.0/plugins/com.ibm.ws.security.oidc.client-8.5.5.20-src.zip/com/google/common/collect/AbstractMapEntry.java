package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Objects;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AbstractMapEntry<K, V> implements Map.Entry<K, V> {
	public abstract K getKey();

	public abstract V getValue();

	public V setValue(V value) {
		throw new UnsupportedOperationException();
	}

	public boolean equals(@NullableDecl Object object) {
		if (!(object instanceof Map.Entry)) {
			return false;
		} else {
			Map.Entry<?, ?> that = (Map.Entry) object;
			return Objects.equal(this.getKey(), that.getKey()) && Objects.equal(this.getValue(), that.getValue());
		}
	}

	public int hashCode() {
		K k = this.getKey();
		V v = this.getValue();
		return (k == null ? 0 : k.hashCode()) ^ (v == null ? 0 : v.hashCode());
	}

	public String toString() {
		return this.getKey() + "=" + this.getValue();
	}
}