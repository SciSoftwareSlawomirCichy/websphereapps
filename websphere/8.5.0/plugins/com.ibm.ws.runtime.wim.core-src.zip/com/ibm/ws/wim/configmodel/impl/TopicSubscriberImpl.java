package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.SubscriberType;
import com.ibm.ws.wim.configmodel.TopicSubscriber;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class TopicSubscriberImpl extends EDataObjectImpl implements TopicSubscriber {
	protected static final String CLASS_NAME_EDEFAULT = null;
	protected String className;
	protected static final String TOPIC_SUBSCRIBER_NAME_EDEFAULT = null;
	protected String topicSubscriberName;
	protected static final SubscriberType TOPIC_SUBSCRIBER_TYPE_EDEFAULT;
	protected SubscriberType topicSubscriberType;
	protected boolean topicSubscriberTypeESet;

	protected TopicSubscriberImpl() {
		this.className = CLASS_NAME_EDEFAULT;
		this.topicSubscriberName = TOPIC_SUBSCRIBER_NAME_EDEFAULT;
		this.topicSubscriberType = TOPIC_SUBSCRIBER_TYPE_EDEFAULT;
		this.topicSubscriberTypeESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getTopicSubscriber();
	}

	public String getClassName() {
		return this.className;
	}

	public void setClassName(String var1) {
		String var2 = this.className;
		this.className = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.className));
		}

	}

	public String getTopicSubscriberName() {
		return this.topicSubscriberName;
	}

	public void setTopicSubscriberName(String var1) {
		String var2 = this.topicSubscriberName;
		this.topicSubscriberName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.topicSubscriberName));
		}

	}

	public SubscriberType getTopicSubscriberType() {
		return this.topicSubscriberType;
	}

	public void setTopicSubscriberType(SubscriberType var1) {
		SubscriberType var2 = this.topicSubscriberType;
		this.topicSubscriberType = var1 == null ? TOPIC_SUBSCRIBER_TYPE_EDEFAULT : var1;
		boolean var3 = this.topicSubscriberTypeESet;
		this.topicSubscriberTypeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.topicSubscriberType, !var3));
		}

	}

	public void unsetTopicSubscriberType() {
		SubscriberType var1 = this.topicSubscriberType;
		boolean var2 = this.topicSubscriberTypeESet;
		this.topicSubscriberType = TOPIC_SUBSCRIBER_TYPE_EDEFAULT;
		this.topicSubscriberTypeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 2, var1, TOPIC_SUBSCRIBER_TYPE_EDEFAULT, var2));
		}

	}

	public boolean isSetTopicSubscriberType() {
		return this.topicSubscriberTypeESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getClassName();
			case 1 :
				return this.getTopicSubscriberName();
			case 2 :
				return this.getTopicSubscriberType();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setClassName((String) var2);
				return;
			case 1 :
				this.setTopicSubscriberName((String) var2);
				return;
			case 2 :
				this.setTopicSubscriberType((SubscriberType) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setClassName(CLASS_NAME_EDEFAULT);
				return;
			case 1 :
				this.setTopicSubscriberName(TOPIC_SUBSCRIBER_NAME_EDEFAULT);
				return;
			case 2 :
				this.unsetTopicSubscriberType();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return CLASS_NAME_EDEFAULT == null
						? this.className != null
						: !CLASS_NAME_EDEFAULT.equals(this.className);
			case 1 :
				return TOPIC_SUBSCRIBER_NAME_EDEFAULT == null
						? this.topicSubscriberName != null
						: !TOPIC_SUBSCRIBER_NAME_EDEFAULT.equals(this.topicSubscriberName);
			case 2 :
				return this.isSetTopicSubscriberType();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (className: ");
			var1.append(this.className);
			var1.append(", topicSubscriberName: ");
			var1.append(this.topicSubscriberName);
			var1.append(", topicSubscriberType: ");
			if (this.topicSubscriberTypeESet) {
				var1.append(this.topicSubscriberType);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}

	static {
		TOPIC_SUBSCRIBER_TYPE_EDEFAULT = SubscriberType.NOTIFICATION_SUBSCRIBER_LITERAL;
	}
}