package com.google.inject;

import com.google.inject.ProxyFactory.1;
import com.google.inject.ProxyFactory.IndicesCallbackFilter;
import com.google.inject.ProxyFactory.MethodInterceptorsPair;
import com.google.inject.ProxyFactory.ProxyConstructor;
import com.google.inject.internal.BytecodeGen;
import com.google.inject.internal.ImmutableList;
import com.google.inject.internal.ImmutableMap;
import com.google.inject.internal.Lists;
import com.google.inject.internal.BytecodeGen.Visibility;
import com.google.inject.internal.ImmutableMap.Builder;
import com.google.inject.internal.cglib.proxy.Callback;
import com.google.inject.internal.cglib.proxy.Enhancer;
import com.google.inject.internal.cglib.proxy.MethodInterceptor;
import com.google.inject.spi.InjectionPoint;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

class ProxyFactory<T> implements ConstructionProxyFactory<T> {
	private static final MethodInterceptor NO_OP_METHOD_INTERCEPTOR = new 1();
	private final InjectionPoint injectionPoint;
	private final ImmutableMap<Method, List<org.aopalliance.intercept.MethodInterceptor>> interceptors;
	private final Class<T> declaringClass;
	private final List<Method> methods;
	private final Callback[] callbacks;
	private Visibility visibility;

	ProxyFactory(InjectionPoint injectionPoint, Iterable<MethodAspect> methodAspects) {
		this.visibility = Visibility.PUBLIC;
		this.injectionPoint = injectionPoint;
		Constructor<T> constructor = (Constructor) injectionPoint.getMember();
		this.declaringClass = constructor.getDeclaringClass();
		List<MethodAspect> applicableAspects = Lists.newArrayList();
		Iterator i$ = methodAspects.iterator();

		while (i$.hasNext()) {
			MethodAspect methodAspect = (MethodAspect) i$.next();
			if (methodAspect.matches(this.declaringClass)) {
				applicableAspects.add(methodAspect);
			}
		}

		if (applicableAspects.isEmpty()) {
			this.interceptors = ImmutableMap.of();
			this.methods = ImmutableList.of();
			this.callbacks = null;
		} else {
			this.methods = Lists.newArrayList();
			Enhancer.getMethods(this.declaringClass, (Class[]) null, this.methods);
			List<MethodInterceptorsPair> methodInterceptorsPairs = Lists.newArrayList();
			Iterator i$ = this.methods.iterator();

			while (i$.hasNext()) {
				Method method = (Method) i$.next();
				methodInterceptorsPairs.add(new MethodInterceptorsPair(method));
			}

			boolean anyMatched = false;
			Iterator i$ = applicableAspects.iterator();

			while (i$.hasNext()) {
				MethodAspect methodAspect = (MethodAspect) i$.next();
				Iterator i$ = methodInterceptorsPairs.iterator();

				while (i$.hasNext()) {
					MethodInterceptorsPair pair = (MethodInterceptorsPair) i$.next();
					if (methodAspect.matches(pair.method)) {
						this.visibility = this.visibility.and(Visibility.forMember(pair.method));
						pair.addAll(methodAspect.interceptors());
						anyMatched = true;
					}
				}
			}

			if (!anyMatched) {
				this.interceptors = ImmutableMap.of();
				this.callbacks = null;
			} else {
				Builder<Method, List<org.aopalliance.intercept.MethodInterceptor>> interceptorsMapBuilder = null;
				this.callbacks = new Callback[this.methods.size()];

				for (int i = 0; i < this.methods.size(); ++i) {
					MethodInterceptorsPair pair = (MethodInterceptorsPair) methodInterceptorsPairs.get(i);
					if (!pair.hasInterceptors()) {
						this.callbacks[i] = NO_OP_METHOD_INTERCEPTOR;
					} else {
						if (interceptorsMapBuilder == null) {
							interceptorsMapBuilder = ImmutableMap.builder();
						}

						interceptorsMapBuilder.put(pair.method, ImmutableList.copyOf(pair.interceptors));
						this.callbacks[i] = new InterceptorStackCallback(pair.method, pair.interceptors);
					}
				}

				this.interceptors = interceptorsMapBuilder != null ? interceptorsMapBuilder.build() : ImmutableMap.of();
			}
		}
	}

	public ImmutableMap<Method, List<org.aopalliance.intercept.MethodInterceptor>> getInterceptors() {
		return this.interceptors;
	}

	public ConstructionProxy<T> create() {
		if (this.interceptors.isEmpty()) {
			return (new DefaultConstructionProxyFactory(this.injectionPoint)).create();
		} else {
			Class<? extends Callback>[] callbackTypes = new Class[this.methods.size()];
			Arrays.fill(callbackTypes, MethodInterceptor.class);
			Enhancer enhancer = BytecodeGen.newEnhancer(this.declaringClass, this.visibility);
			enhancer.setCallbackFilter(new IndicesCallbackFilter(this.declaringClass, this.methods));
			enhancer.setCallbackTypes(callbackTypes);
			return new ProxyConstructor(enhancer, this.injectionPoint, this.callbacks, this.interceptors);
		}
	}
}