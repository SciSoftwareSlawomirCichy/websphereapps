package com.ibm.ejs.container;

public class ContainerLocalException extends ContainerEJBException {
	private static final long serialVersionUID = -6645328035635864281L;

	public ContainerLocalException() {
	}

	public ContainerLocalException(String s) {
		super(s);
	}

	public ContainerLocalException(Exception ex) {
		super(ex.toString(), ex);
	}

	public ContainerLocalException(String s, Exception ex) {
		super(s, ex);
	}

	public ContainerLocalException(Throwable ex) {
		super(ex);
	}

	public ContainerLocalException(String s, Throwable ex) {
		super(s, ex);
	}
}