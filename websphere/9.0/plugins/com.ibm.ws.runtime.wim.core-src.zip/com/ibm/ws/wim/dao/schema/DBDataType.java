package com.ibm.ws.wim.dao.schema;

public class DBDataType {
	private String datatype = null;
	private String classname = null;

	public String getClassname() {
		return this.classname;
	}

	public void setClassname(String var1) {
		this.classname = var1;
	}

	public String getDatatype() {
		return this.datatype;
	}

	public void setDatatype(String var1) {
		this.datatype = var1;
	}
}