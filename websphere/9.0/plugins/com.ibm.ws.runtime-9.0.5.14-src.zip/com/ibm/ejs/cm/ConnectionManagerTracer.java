package com.ibm.ejs.cm;

import java.util.Date;

public class ConnectionManagerTracer extends Throwable {
	private static final long serialVersionUID = 2066300117717994127L;
	private long lCreateTime;

	public ConnectionManagerTracer() {
		this("Connection Manager Diagnostic Tracer - ");
	}

	public ConnectionManagerTracer(String szMessage) {
		super(szMessage);
		this.lCreateTime = 0L;
		this.lCreateTime = System.currentTimeMillis();
	}

	public long getCreateTime() {
		return this.lCreateTime;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer(this.getMessage());
		sb.append("Connection creation time: ");
		sb.append(new Date(this.lCreateTime));
		return sb.toString();
	}
}