package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;

@Deprecated
@GwtCompatible
public final class DiscreteDomains {
	public static DiscreteDomain<Integer> integers() {
		return DiscreteDomain.integers();
	}

	public static DiscreteDomain<Long> longs() {
		return DiscreteDomain.longs();
	}
}