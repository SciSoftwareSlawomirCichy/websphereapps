package com.ibm.ws.wim.pluginmanager;

import java.util.HashSet;

public class RuntimeEmitterContext {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private EmitterReference emitterReference;
	private HashSet executedSubscriberList;

	public RuntimeEmitterContext(EmitterReference var1) {
		this.emitterReference = var1;
		this.executedSubscriberList = new HashSet();
	}

	public HashSet getExecutedSubscriberList() {
		return this.executedSubscriberList;
	}

	public EmitterReference getEmitterReference() {
		return this.emitterReference;
	}
}