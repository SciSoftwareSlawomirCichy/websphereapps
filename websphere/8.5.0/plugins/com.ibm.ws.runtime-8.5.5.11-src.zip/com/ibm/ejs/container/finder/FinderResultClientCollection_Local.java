package com.ibm.ejs.container.finder;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import java.util.AbstractCollection;
import java.util.Iterator;
import java.util.Set;

public class FinderResultClientCollection_Local extends AbstractCollection implements Set {
	private static final TraceComponent tc = Tr.register(FinderResultClientCollection_Local.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private FinderResultServerImpl serverImpl;

	public FinderResultClientCollection_Local(FinderResultServerImpl s) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "FinderResultClientCollection_Local CTOR");
		}

		this.serverImpl = s;
		this.serverImpl.saveLocalCollectionContexts();
	}

	public int size() {
		if (!this.serverImpl.validLocalAccessScope()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Throwing CollectionCannotBeFurtherAccessedException");
			}

			throw new CollectionCannotBeFurtherAccessedException();
		} else {
			return this.serverImpl.size();
		}
	}

	public Iterator iterator() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "iterator");
		}

		if (!this.serverImpl.validLocalAccessScope()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Throwing CollectionCannotBeFurtherAccessedException");
			}

			throw new CollectionCannotBeFurtherAccessedException();
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "iterator");
			}

			return new FinderResultClientIterator_Local(this.serverImpl);
		}
	}

	public String toString() {
		return this.getClass().getName();
	}

	public int getServerWrapperSize() {
		return this.serverImpl.getWrappers().size();
	}

	public AccessIntent getCollectionAccessIntent() {
		return this.serverImpl.getCollectionAccessIntent();
	}
}