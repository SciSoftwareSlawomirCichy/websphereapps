package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.TreeTraverser.1;
import com.google.common.collect.TreeTraverser.2;
import com.google.common.collect.TreeTraverser.3;
import com.google.common.collect.TreeTraverser.4;
import com.google.common.collect.TreeTraverser.PostOrderIterator;
import com.google.common.collect.TreeTraverser.PreOrderIterator;

@Deprecated
@Beta
@GwtCompatible
public abstract class TreeTraverser<T> {

	@Deprecated
   public static <T> TreeTraverser<T> using(Function<T, ? extends Iterable<T>> nodeToChildrenFunction) {
      Preconditions.checkNotNull(nodeToChildrenFunction);
      return new 1(nodeToChildrenFunction);
   }

	public abstract Iterable<T> children(T var1);

	@Deprecated
   public final FluentIterable<T> preOrderTraversal(T root) {
      Preconditions.checkNotNull(root);
      return new 2(this, root);
   }

	UnmodifiableIterator<T> preOrderIterator(T root) {
		return new PreOrderIterator(this, root);
	}

	@Deprecated
   public final FluentIterable<T> postOrderTraversal(T root) {
      Preconditions.checkNotNull(root);
      return new 3(this, root);
   }

	UnmodifiableIterator<T> postOrderIterator(T root) {
		return new PostOrderIterator(this, root);
	}

	@Deprecated
   public final FluentIterable<T> breadthFirstTraversal(T root) {
      Preconditions.checkNotNull(root);
      return new 4(this, root);
   }
}