package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.EnvironmentPropertiesType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class LdapServersTypeImpl extends EDataObjectImpl implements LdapServersType {
	protected EList connections = null;
	protected EList environmentProperties = null;
	protected static final String AUTHENTICATION_EDEFAULT = "simple";
	protected String authentication = "simple";
	protected boolean authenticationESet = false;
	protected static final String BIND_DN_EDEFAULT = null;
	protected String bindDN;
	protected static final String BIND_PASSWORD_EDEFAULT = null;
	protected String bindPassword;
	protected static final boolean CONNECTION_POOL_EDEFAULT = false;
	protected boolean connectionPool;
	protected boolean connectionPoolESet;
	protected static final int CONNECT_TIMEOUT_EDEFAULT = 0;
	protected int connectTimeout;
	protected boolean connectTimeoutESet;
	protected static final String DEREF_ALIASES_EDEFAULT = "always";
	protected String derefAliases;
	protected boolean derefAliasesESet;
	protected static final String REFERAL_EDEFAULT = "ignore";
	protected String referal;
	protected boolean referalESet;
	protected static final boolean SSL_ENABLED_EDEFAULT = false;
	protected boolean sslEnabled;
	protected boolean sslEnabledESet;

	protected LdapServersTypeImpl() {
		this.bindDN = BIND_DN_EDEFAULT;
		this.bindPassword = BIND_PASSWORD_EDEFAULT;
		this.connectionPool = false;
		this.connectionPoolESet = false;
		this.connectTimeout = 0;
		this.connectTimeoutESet = false;
		this.derefAliases = "always";
		this.derefAliasesESet = false;
		this.referal = "ignore";
		this.referalESet = false;
		this.sslEnabled = false;
		this.sslEnabledESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getLdapServersType();
	}

	public ConnectionsType[] getConnectionsAsArray() {
		List var1 = this.getConnections();
		return (ConnectionsType[]) ((ConnectionsType[]) var1.toArray(new ConnectionsType[var1.size()]));
	}

	public List getConnections() {
		if (this.connections == null) {
			this.connections = new EObjectContainmentEList(ConnectionsType.class, this, 0);
		}

		return this.connections;
	}

	public ConnectionsType createConnections() {
		ConnectionsType var1 = ConfigmodelFactory.eINSTANCE.createConnectionsType();
		this.getConnections().add(var1);
		return var1;
	}

	public EnvironmentPropertiesType[] getEnvironmentPropertiesAsArray() {
		List var1 = this.getEnvironmentProperties();
		return (EnvironmentPropertiesType[]) ((EnvironmentPropertiesType[]) var1
				.toArray(new EnvironmentPropertiesType[var1.size()]));
	}

	public List getEnvironmentProperties() {
		if (this.environmentProperties == null) {
			this.environmentProperties = new EObjectContainmentEList(EnvironmentPropertiesType.class, this, 1);
		}

		return this.environmentProperties;
	}

	public EnvironmentPropertiesType createEnvironmentProperties() {
		EnvironmentPropertiesType var1 = ConfigmodelFactory.eINSTANCE.createEnvironmentPropertiesType();
		this.getEnvironmentProperties().add(var1);
		return var1;
	}

	public String getAuthentication() {
		return this.authentication;
	}

	public void setAuthentication(String var1) {
		String var2 = this.authentication;
		this.authentication = var1;
		boolean var3 = this.authenticationESet;
		this.authenticationESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.authentication, !var3));
		}

	}

	public void unsetAuthentication() {
		String var1 = this.authentication;
		boolean var2 = this.authenticationESet;
		this.authentication = "simple";
		this.authenticationESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 2, var1, "simple", var2));
		}

	}

	public boolean isSetAuthentication() {
		return this.authenticationESet;
	}

	public String getBindDN() {
		return this.bindDN;
	}

	public void setBindDN(String var1) {
		String var2 = this.bindDN;
		this.bindDN = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.bindDN));
		}

	}

	public String getBindPassword() {
		return this.bindPassword;
	}

	public void setBindPassword(String var1) {
		String var2 = this.bindPassword;
		this.bindPassword = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var2, this.bindPassword));
		}

	}

	public boolean isConnectionPool() {
		return this.connectionPool;
	}

	public void setConnectionPool(boolean var1) {
		boolean var2 = this.connectionPool;
		this.connectionPool = var1;
		boolean var3 = this.connectionPoolESet;
		this.connectionPoolESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 5, var2, this.connectionPool, !var3));
		}

	}

	public void unsetConnectionPool() {
		boolean var1 = this.connectionPool;
		boolean var2 = this.connectionPoolESet;
		this.connectionPool = false;
		this.connectionPoolESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 5, var1, false, var2));
		}

	}

	public boolean isSetConnectionPool() {
		return this.connectionPoolESet;
	}

	public int getConnectTimeout() {
		return this.connectTimeout;
	}

	public void setConnectTimeout(int var1) {
		int var2 = this.connectTimeout;
		this.connectTimeout = var1;
		boolean var3 = this.connectTimeoutESet;
		this.connectTimeoutESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 6, var2, this.connectTimeout, !var3));
		}

	}

	public void unsetConnectTimeout() {
		int var1 = this.connectTimeout;
		boolean var2 = this.connectTimeoutESet;
		this.connectTimeout = 0;
		this.connectTimeoutESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 6, var1, 0, var2));
		}

	}

	public boolean isSetConnectTimeout() {
		return this.connectTimeoutESet;
	}

	public String getDerefAliases() {
		return this.derefAliases;
	}

	public void setDerefAliases(String var1) {
		String var2 = this.derefAliases;
		this.derefAliases = var1;
		boolean var3 = this.derefAliasesESet;
		this.derefAliasesESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 7, var2, this.derefAliases, !var3));
		}

	}

	public void unsetDerefAliases() {
		String var1 = this.derefAliases;
		boolean var2 = this.derefAliasesESet;
		this.derefAliases = "always";
		this.derefAliasesESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 7, var1, "always", var2));
		}

	}

	public boolean isSetDerefAliases() {
		return this.derefAliasesESet;
	}

	public String getReferal() {
		return this.referal;
	}

	public void setReferal(String var1) {
		String var2 = this.referal;
		this.referal = var1;
		boolean var3 = this.referalESet;
		this.referalESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 8, var2, this.referal, !var3));
		}

	}

	public void unsetReferal() {
		String var1 = this.referal;
		boolean var2 = this.referalESet;
		this.referal = "ignore";
		this.referalESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 8, var1, "ignore", var2));
		}

	}

	public boolean isSetReferal() {
		return this.referalESet;
	}

	public boolean isSslEnabled() {
		return this.sslEnabled;
	}

	public void setSslEnabled(boolean var1) {
		boolean var2 = this.sslEnabled;
		this.sslEnabled = var1;
		boolean var3 = this.sslEnabledESet;
		this.sslEnabledESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 9, var2, this.sslEnabled, !var3));
		}

	}

	public void unsetSslEnabled() {
		boolean var1 = this.sslEnabled;
		boolean var2 = this.sslEnabledESet;
		this.sslEnabled = false;
		this.sslEnabledESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 9, var1, false, var2));
		}

	}

	public boolean isSetSslEnabled() {
		return this.sslEnabledESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getConnections()).basicRemove(var1, var4);
				case 1 :
					return ((InternalEList) this.getEnvironmentProperties()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getConnections();
			case 1 :
				return this.getEnvironmentProperties();
			case 2 :
				return this.getAuthentication();
			case 3 :
				return this.getBindDN();
			case 4 :
				return this.getBindPassword();
			case 5 :
				return this.isConnectionPool() ? Boolean.TRUE : Boolean.FALSE;
			case 6 :
				return new Integer(this.getConnectTimeout());
			case 7 :
				return this.getDerefAliases();
			case 8 :
				return this.getReferal();
			case 9 :
				return this.isSslEnabled() ? Boolean.TRUE : Boolean.FALSE;
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getConnections().clear();
				this.getConnections().addAll((Collection) var2);
				return;
			case 1 :
				this.getEnvironmentProperties().clear();
				this.getEnvironmentProperties().addAll((Collection) var2);
				return;
			case 2 :
				this.setAuthentication((String) var2);
				return;
			case 3 :
				this.setBindDN((String) var2);
				return;
			case 4 :
				this.setBindPassword((String) var2);
				return;
			case 5 :
				this.setConnectionPool((Boolean) var2);
				return;
			case 6 :
				this.setConnectTimeout((Integer) var2);
				return;
			case 7 :
				this.setDerefAliases((String) var2);
				return;
			case 8 :
				this.setReferal((String) var2);
				return;
			case 9 :
				this.setSslEnabled((Boolean) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getConnections().clear();
				return;
			case 1 :
				this.getEnvironmentProperties().clear();
				return;
			case 2 :
				this.unsetAuthentication();
				return;
			case 3 :
				this.setBindDN(BIND_DN_EDEFAULT);
				return;
			case 4 :
				this.setBindPassword(BIND_PASSWORD_EDEFAULT);
				return;
			case 5 :
				this.unsetConnectionPool();
				return;
			case 6 :
				this.unsetConnectTimeout();
				return;
			case 7 :
				this.unsetDerefAliases();
				return;
			case 8 :
				this.unsetReferal();
				return;
			case 9 :
				this.unsetSslEnabled();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.connections != null && !this.connections.isEmpty();
			case 1 :
				return this.environmentProperties != null && !this.environmentProperties.isEmpty();
			case 2 :
				return this.isSetAuthentication();
			case 3 :
				return BIND_DN_EDEFAULT == null ? this.bindDN != null : !BIND_DN_EDEFAULT.equals(this.bindDN);
			case 4 :
				return BIND_PASSWORD_EDEFAULT == null
						? this.bindPassword != null
						: !BIND_PASSWORD_EDEFAULT.equals(this.bindPassword);
			case 5 :
				return this.isSetConnectionPool();
			case 6 :
				return this.isSetConnectTimeout();
			case 7 :
				return this.isSetDerefAliases();
			case 8 :
				return this.isSetReferal();
			case 9 :
				return this.isSetSslEnabled();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (authentication: ");
			if (this.authenticationESet) {
				var1.append(this.authentication);
			} else {
				var1.append("<unset>");
			}

			var1.append(", bindDN: ");
			var1.append(this.bindDN);
			var1.append(", bindPassword: ");
			var1.append(this.bindPassword);
			var1.append(", connectionPool: ");
			if (this.connectionPoolESet) {
				var1.append(this.connectionPool);
			} else {
				var1.append("<unset>");
			}

			var1.append(", connectTimeout: ");
			if (this.connectTimeoutESet) {
				var1.append(this.connectTimeout);
			} else {
				var1.append("<unset>");
			}

			var1.append(", derefAliases: ");
			if (this.derefAliasesESet) {
				var1.append(this.derefAliases);
			} else {
				var1.append("<unset>");
			}

			var1.append(", referal: ");
			if (this.referalESet) {
				var1.append(this.referal);
			} else {
				var1.append("<unset>");
			}

			var1.append(", sslEnabled: ");
			if (this.sslEnabledESet) {
				var1.append(this.sslEnabled);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}