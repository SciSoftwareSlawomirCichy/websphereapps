package com.ibm.ejs.container;

import javax.ejb.Timer;

public interface TimerNp extends Timer {
	String getTaskId();

	void start();

	void startAlarm();

	void destroy();
}