package org.apache.commons.lang.text;

import org.apache.commons.lang.text.StrMatcher.CharMatcher;
import org.apache.commons.lang.text.StrMatcher.CharSetMatcher;
import org.apache.commons.lang.text.StrMatcher.NoMatcher;
import org.apache.commons.lang.text.StrMatcher.StringMatcher;
import org.apache.commons.lang.text.StrMatcher.TrimMatcher;

public abstract class StrMatcher {
	private static final StrMatcher COMMA_MATCHER = new CharMatcher(',');
	private static final StrMatcher TAB_MATCHER = new CharMatcher('\t');
	private static final StrMatcher SPACE_MATCHER = new CharMatcher(' ');
	private static final StrMatcher SPLIT_MATCHER = new CharSetMatcher(" \t\n\r\f".toCharArray());
	private static final StrMatcher TRIM_MATCHER = new TrimMatcher();
	private static final StrMatcher SINGLE_QUOTE_MATCHER = new CharMatcher('\'');
	private static final StrMatcher DOUBLE_QUOTE_MATCHER = new CharMatcher('"');
	private static final StrMatcher QUOTE_MATCHER = new CharSetMatcher("'\"".toCharArray());
	private static final StrMatcher NONE_MATCHER = new NoMatcher();

	public static StrMatcher commaMatcher() {
		return COMMA_MATCHER;
	}

	public static StrMatcher tabMatcher() {
		return TAB_MATCHER;
	}

	public static StrMatcher spaceMatcher() {
		return SPACE_MATCHER;
	}

	public static StrMatcher splitMatcher() {
		return SPLIT_MATCHER;
	}

	public static StrMatcher trimMatcher() {
		return TRIM_MATCHER;
	}

	public static StrMatcher singleQuoteMatcher() {
		return SINGLE_QUOTE_MATCHER;
	}

	public static StrMatcher doubleQuoteMatcher() {
		return DOUBLE_QUOTE_MATCHER;
	}

	public static StrMatcher quoteMatcher() {
		return QUOTE_MATCHER;
	}

	public static StrMatcher noneMatcher() {
		return NONE_MATCHER;
	}

	public static StrMatcher charMatcher(char ch) {
		return new CharMatcher(ch);
	}

	public static StrMatcher charSetMatcher(char[] chars) {
		if (chars != null && chars.length != 0) {
			return (StrMatcher) (chars.length == 1 ? new CharMatcher(chars[0]) : new CharSetMatcher(chars));
		} else {
			return NONE_MATCHER;
		}
	}

	public static StrMatcher charSetMatcher(String chars) {
		if (chars != null && chars.length() != 0) {
			return (StrMatcher) (chars.length() == 1
					? new CharMatcher(chars.charAt(0))
					: new CharSetMatcher(chars.toCharArray()));
		} else {
			return NONE_MATCHER;
		}
	}

	public static StrMatcher stringMatcher(String str) {
		return (StrMatcher) (str != null && str.length() != 0 ? new StringMatcher(str) : NONE_MATCHER);
	}

	public abstract int isMatch(char[] var1, int var2, int var3, int var4);

	public int isMatch(char[] buffer, int pos) {
		return this.isMatch(buffer, pos, 0, buffer.length);
	}
}