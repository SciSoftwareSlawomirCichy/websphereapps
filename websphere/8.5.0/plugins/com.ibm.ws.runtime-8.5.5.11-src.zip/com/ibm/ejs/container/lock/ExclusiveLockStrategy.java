package com.ibm.ejs.container.lock;

import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;

class ExclusiveLockStrategy extends LockStrategy {
	private static final TraceComponent tc = Tr.register(ExclusiveLockStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.lock.ExclusiveLockStrategy";

	public boolean lock(EJSContainer c, ContainerTx tx, Object lockName, int mode) throws LockException {
		try {
			return c.getLockManager().lock(lockName, tx, mode);
		} catch (InterruptedException var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.container.lock.ExclusiveLockStrategy.lock", "75", this);
			Tr.fatal(tc, "ATTEMPT_TO_ACQUIRE_LOCK_INTERRUPTED_CNTR0004E", new Object[]{var6});
			return false;
		}
	}

	public void unlock(EJSContainer c, Object lockName, Locker locker) {
		c.getLockManager().unlock(lockName, locker);
	}
}