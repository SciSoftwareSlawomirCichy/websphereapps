package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;

public final class UncachedActivationStrategy extends ActivationStrategy {
	private static final TraceComponent tc = Tr.register(UncachedActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.activator.UncachedActivationStrategy";

	public UncachedActivationStrategy(Activator activator) {
		super(activator);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> complete");
		}

	}

	BeanO atActivate(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atActivate (" + beanId + ")", tx);
		}

		BeanO bean = null;
		boolean popCallbackBeanO = false;

		try {
			bean = beanId.getHome().createBeanO(threadData, tx, beanId);
			popCallbackBeanO = true;
			bean.activate(beanId, tx);
			bean.enlist(tx);
			popCallbackBeanO = false;
		} catch (RemoteException var10) {
			FFDCFilter.processException(var10, "com.ibm.ejs.container.activator.UncachedActivationStrategy.atActivate",
					"78", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "bean activation failed", var10);
			}

			if (bean != null) {
				bean.destroy();
			}

			throw var10;
		} finally {
			if (popCallbackBeanO && bean.getHome() != null) {
				threadData.popCallbackBeanO();
			}

		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atActivate", bean);
		}

		return bean;
	}

	void atPostInvoke(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atPostInvoke", new Object[]{tx, bean});
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atPostInvoke");
		}

	}

	BeanO atCreate(ContainerTx tx, BeanO bean) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCreate", new Object[]{tx, bean});
		}

		bean.enlist(tx);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCreate");
		}

		return null;
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit", new Object[]{tx, bean});
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCommit");
		}

	}

	void atRollback(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRollback", new Object[]{tx, bean});
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRollback");
		}

	}

	void atEnlist(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atEnlist", new Object[]{tx, bean});
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atEnlist");
		}

	}

	void atRemove(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRemove", new Object[]{tx, bean});
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRemove");
		}

	}

	void atDiscard(BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atDiscard", bean);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atDiscard");
		}

	}

	BeanO atGet(ContainerTx tx, BeanId id) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atGet", new Object[]{tx, id});
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atGet", (Object) null);
		}

		return null;
	}
}