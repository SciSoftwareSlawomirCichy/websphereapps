package com.google.inject.internal;

import com.google.inject.internal.FailableCache.1;
import java.util.Map;

public abstract class FailableCache<K, V> {
	private final Map<K, Object> delegate = (new MapMaker()).makeComputingMap(new 1(this));

	protected abstract V create(K var1, Errors var2) throws ErrorsException;

	public V get(K key, Errors errors) throws ErrorsException {
		Object resultOrError = this.delegate.get(key);
		if (resultOrError instanceof Errors) {
			errors.merge((Errors) resultOrError);
			throw errors.toException();
		} else {
			return resultOrError;
		}
	}
}