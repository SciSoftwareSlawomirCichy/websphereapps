package com.ibm.icu.lang;

import com.ibm.icu.impl.IllegalIcuArgumentException;
import com.ibm.icu.impl.Norm2AllModes;
import com.ibm.icu.impl.Normalizer2Impl;
import com.ibm.icu.impl.UBiDiProps;
import com.ibm.icu.impl.UCaseProps;
import com.ibm.icu.impl.UCharacterName;
import com.ibm.icu.impl.UCharacterProperty;
import com.ibm.icu.impl.UCharacterUtility;
import com.ibm.icu.impl.UPropertyAliases;
import com.ibm.icu.lang.UCharacter.StringContextIterator;
import com.ibm.icu.lang.UCharacter.UnicodeBlock;
import com.ibm.icu.lang.UCharacterEnums.ECharacterCategory;
import com.ibm.icu.lang.UCharacterEnums.ECharacterDirection;
import com.ibm.icu.text.BreakIterator;
import com.ibm.icu.text.UTF16;
import com.ibm.icu.util.RangeValueIterator;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.ValueIterator;
import com.ibm.icu.util.VersionInfo;
import java.util.Locale;

public final class UCharacter implements ECharacterCategory, ECharacterDirection {
	public static final int MIN_VALUE = 0;
	public static final int MAX_VALUE = 1114111;
	public static final int SUPPLEMENTARY_MIN_VALUE = 65536;
	public static final int REPLACEMENT_CHAR = 65533;
	public static final double NO_NUMERIC_VALUE = -1.23456789E8D;
	public static final int MIN_RADIX = 2;
	public static final int MAX_RADIX = 36;
	public static final int TITLECASE_NO_LOWERCASE = 256;
	public static final int TITLECASE_NO_BREAK_ADJUSTMENT = 512;
	public static final int FOLD_CASE_DEFAULT = 0;
	public static final int FOLD_CASE_EXCLUDE_SPECIAL_I = 1;
	private static final int[] gcbToHst = new int[]{0, 0, 0, 0, 1, 0, 4, 5, 3, 2};
	public static final char MIN_HIGH_SURROGATE = '?';
	public static final char MAX_HIGH_SURROGATE = '?';
	public static final char MIN_LOW_SURROGATE = '?';
	public static final char MAX_LOW_SURROGATE = '?';
	public static final char MIN_SURROGATE = '?';
	public static final char MAX_SURROGATE = '?';
	public static final int MIN_SUPPLEMENTARY_CODE_POINT = 65536;
	public static final int MAX_CODE_POINT = 1114111;
	public static final int MIN_CODE_POINT = 0;
	private static final int LAST_CHAR_MASK_ = 65535;
	private static final int NO_BREAK_SPACE_ = 160;
	private static final int FIGURE_SPACE_ = 8199;
	private static final int NARROW_NO_BREAK_SPACE_ = 8239;
	private static final int IDEOGRAPHIC_NUMBER_ZERO_ = 12295;
	private static final int CJK_IDEOGRAPH_FIRST_ = 19968;
	private static final int CJK_IDEOGRAPH_SECOND_ = 20108;
	private static final int CJK_IDEOGRAPH_THIRD_ = 19977;
	private static final int CJK_IDEOGRAPH_FOURTH_ = 22232;
	private static final int CJK_IDEOGRAPH_FIFTH_ = 20116;
	private static final int CJK_IDEOGRAPH_SIXTH_ = 20845;
	private static final int CJK_IDEOGRAPH_SEVENTH_ = 19971;
	private static final int CJK_IDEOGRAPH_EIGHTH_ = 20843;
	private static final int CJK_IDEOGRAPH_NINETH_ = 20061;
	private static final int APPLICATION_PROGRAM_COMMAND_ = 159;
	private static final int UNIT_SEPARATOR_ = 31;
	private static final int DELETE_ = 127;
	private static final int NUMERIC_TYPE_VALUE_SHIFT_ = 6;
	private static final int NTV_NONE_ = 0;
	private static final int NTV_DECIMAL_START_ = 1;
	private static final int NTV_DIGIT_START_ = 11;
	private static final int NTV_NUMERIC_START_ = 21;
	private static final int NTV_FRACTION_START_ = 176;
	private static final int NTV_LARGE_START_ = 480;
	private static final int NTV_RESERVED_START_ = 768;
	private static final int CJK_IDEOGRAPH_COMPLEX_ZERO_ = 38646;
	private static final int CJK_IDEOGRAPH_COMPLEX_ONE_ = 22777;
	private static final int CJK_IDEOGRAPH_COMPLEX_TWO_ = 36019;
	private static final int CJK_IDEOGRAPH_COMPLEX_THREE_ = 21443;
	private static final int CJK_IDEOGRAPH_COMPLEX_FOUR_ = 32902;
	private static final int CJK_IDEOGRAPH_COMPLEX_FIVE_ = 20237;
	private static final int CJK_IDEOGRAPH_COMPLEX_SIX_ = 38520;
	private static final int CJK_IDEOGRAPH_COMPLEX_SEVEN_ = 26578;
	private static final int CJK_IDEOGRAPH_COMPLEX_EIGHT_ = 25420;
	private static final int CJK_IDEOGRAPH_COMPLEX_NINE_ = 29590;
	private static final int CJK_IDEOGRAPH_TEN_ = 21313;
	private static final int CJK_IDEOGRAPH_COMPLEX_TEN_ = 25342;
	private static final int CJK_IDEOGRAPH_HUNDRED_ = 30334;
	private static final int CJK_IDEOGRAPH_COMPLEX_HUNDRED_ = 20336;
	private static final int CJK_IDEOGRAPH_THOUSAND_ = 21315;
	private static final int CJK_IDEOGRAPH_COMPLEX_THOUSAND_ = 20191;
	private static final int CJK_IDEOGRAPH_TEN_THOUSAND_ = 33356;
	private static final int CJK_IDEOGRAPH_HUNDRED_MILLION_ = 20740;
	private static final int LB_MASK = 66060288;
	private static final int LB_SHIFT = 20;
	private static final int LB_VWORD = 2;
	private static final int SB_MASK = 1015808;
	private static final int SB_SHIFT = 15;
	private static final int WB_MASK = 31744;
	private static final int WB_SHIFT = 10;
	private static final int GCB_MASK = 992;
	private static final int GCB_SHIFT = 5;
	private static final int DECOMPOSITION_TYPE_MASK_ = 31;
	private static final int EAST_ASIAN_MASK_ = 917504;
	private static final int EAST_ASIAN_SHIFT_ = 17;
	private static final int BLOCK_MASK_ = 130816;
	private static final int BLOCK_SHIFT_ = 8;
	static final int SCRIPT_MASK_ = 255;

	public static int digit(int ch, int radix) {
		if (2 <= radix && radix <= 36) {
			int value = digit(ch);
			if (value < 0) {
				value = getEuropeanDigit(ch);
			}

			return value < radix ? value : -1;
		} else {
			return -1;
		}
	}

	public static int digit(int ch) {
		int props = getProperty(ch);
		int value = getNumericTypeValue(props) - 1;
		return value <= 9 ? value : -1;
	}

	public static int getNumericValue(int ch) {
		int props = UCharacterProperty.INSTANCE.getProperty(ch);
		int ntv = getNumericTypeValue(props);
		if (ntv == 0) {
			return getEuropeanDigit(ch);
		} else if (ntv < 11) {
			return ntv - 1;
		} else if (ntv < 21) {
			return ntv - 11;
		} else if (ntv < 176) {
			return ntv - 21;
		} else if (ntv < 480) {
			return -2;
		} else if (ntv >= 768) {
			return -2;
		} else {
			int mant = (ntv >> 5) - 14;
			int exp = (ntv & 31) + 2;
			if (exp < 9 || exp == 9 && mant <= 2) {
				int numValue = mant;

				do {
					numValue *= 10;
					--exp;
				} while (exp > 0);

				return numValue;
			} else {
				return -2;
			}
		}
	}

	public static double getUnicodeNumericValue(int ch) {
		int props = UCharacterProperty.INSTANCE.getProperty(ch);
		int ntv = getNumericTypeValue(props);
		if (ntv == 0) {
			return -1.23456789E8D;
		} else if (ntv < 11) {
			return (double) (ntv - 1);
		} else if (ntv < 21) {
			return (double) (ntv - 11);
		} else if (ntv < 176) {
			return (double) (ntv - 21);
		} else if (ntv < 480) {
			int numerator = (ntv >> 4) - 12;
			int denominator = (ntv & 15) + 1;
			return (double) numerator / (double) denominator;
		} else if (ntv >= 768) {
			return -1.23456789E8D;
		} else {
			int mant = (ntv >> 5) - 14;
			int exp = (ntv & 31) + 2;

			double numValue;
			for (numValue = (double) mant; exp >= 4; exp -= 4) {
				numValue *= 10000.0D;
			}

			switch (exp) {
				case 0 :
				default :
					break;
				case 1 :
					numValue *= 10.0D;
					break;
				case 2 :
					numValue *= 100.0D;
					break;
				case 3 :
					numValue *= 1000.0D;
			}

			return numValue;
		}
	}

	public static boolean isSpace(int ch) {
		return ch <= 32 && (ch == 32 || ch == 9 || ch == 10 || ch == 12 || ch == 13);
	}

	public static int getType(int ch) {
		return getProperty(ch) & 31;
	}

	public static boolean isDefined(int ch) {
		return getType(ch) != 0;
	}

	public static boolean isDigit(int ch) {
		return getType(ch) == 9;
	}

	public static boolean isISOControl(int ch) {
		return ch >= 0 && ch <= 159 && (ch <= 31 || ch >= 127);
	}

	public static boolean isLetter(int ch) {
		return (1 << getType(ch) & 62) != 0;
	}

	public static boolean isLetterOrDigit(int ch) {
		return (1 << getType(ch) & 574) != 0;
	}

	public static boolean isJavaLetter(int cp) {
		return isJavaIdentifierStart(cp);
	}

	public static boolean isJavaLetterOrDigit(int cp) {
		return isJavaIdentifierPart(cp);
	}

	public static boolean isJavaIdentifierStart(int cp) {
		return Character.isJavaIdentifierStart((char) cp);
	}

	public static boolean isJavaIdentifierPart(int cp) {
		return Character.isJavaIdentifierPart((char) cp);
	}

	public static boolean isLowerCase(int ch) {
		return getType(ch) == 2;
	}

	public static boolean isWhitespace(int ch) {
		return (1 << getType(ch) & 28672) != 0 && ch != 160 && ch != 8199 && ch != 8239 || ch >= 9 && ch <= 13
				|| ch >= 28 && ch <= 31;
	}

	public static boolean isSpaceChar(int ch) {
		return (1 << getType(ch) & 28672) != 0;
	}

	public static boolean isTitleCase(int ch) {
		return getType(ch) == 3;
	}

	public static boolean isUnicodeIdentifierPart(int ch) {
		return (1 << getType(ch) & 4196222) != 0 || isIdentifierIgnorable(ch);
	}

	public static boolean isUnicodeIdentifierStart(int ch) {
		return (1 << getType(ch) & 1086) != 0;
	}

	public static boolean isIdentifierIgnorable(int ch) {
		if (ch > 159) {
			return getType(ch) == 16;
		} else {
			return isISOControl(ch) && (ch < 9 || ch > 13) && (ch < 28 || ch > 31);
		}
	}

	public static boolean isUpperCase(int ch) {
		return getType(ch) == 1;
	}

	public static int toLowerCase(int ch) {
		return UCaseProps.INSTANCE.tolower(ch);
	}

	public static String toString(int ch) {
		if (ch >= 0 && ch <= 1114111) {
			if (ch < 65536) {
				return String.valueOf((char) ch);
			} else {
				StringBuilder result = new StringBuilder();
				result.append(UTF16.getLeadSurrogate(ch));
				result.append(UTF16.getTrailSurrogate(ch));
				return result.toString();
			}
		} else {
			return null;
		}
	}

	public static int toTitleCase(int ch) {
		return UCaseProps.INSTANCE.totitle(ch);
	}

	public static int toUpperCase(int ch) {
		return UCaseProps.INSTANCE.toupper(ch);
	}

	public static boolean isSupplementary(int ch) {
		return ch >= 65536 && ch <= 1114111;
	}

	public static boolean isBMP(int ch) {
		return ch >= 0 && ch <= 65535;
	}

	public static boolean isPrintable(int ch) {
		int cat = getType(ch);
		return cat != 0 && cat != 15 && cat != 16 && cat != 17 && cat != 18 && cat != 0;
	}

	public static boolean isBaseForm(int ch) {
		int cat = getType(ch);
		return cat == 9 || cat == 11 || cat == 10 || cat == 1 || cat == 2 || cat == 3 || cat == 4 || cat == 5
				|| cat == 6 || cat == 7 || cat == 8;
	}

	public static int getDirection(int ch) {
		return UBiDiProps.INSTANCE.getClass(ch);
	}

	public static boolean isMirrored(int ch) {
		return UBiDiProps.INSTANCE.isMirrored(ch);
	}

	public static int getMirror(int ch) {
		return UBiDiProps.INSTANCE.getMirror(ch);
	}

	public static int getCombiningClass(int ch) {
		if (ch >= 0 && ch <= 1114111) {
			Normalizer2Impl impl = Norm2AllModes.getNFCInstance().impl;
			return impl.getCC(impl.getNorm16(ch));
		} else {
			throw new IllegalArgumentException("Codepoint out of bounds");
		}
	}

	public static boolean isLegal(int ch) {
		if (ch < 0) {
			return false;
		} else if (ch < 55296) {
			return true;
		} else if (ch <= 57343) {
			return false;
		} else if (UCharacterUtility.isNonCharacter(ch)) {
			return false;
		} else {
			return ch <= 1114111;
		}
	}

	public static boolean isLegal(String str) {
		int size = str.length();

		for (int i = 0; i < size; ++i) {
			int codepoint = UTF16.charAt(str, i);
			if (!isLegal(codepoint)) {
				return false;
			}

			if (isSupplementary(codepoint)) {
				++i;
			}
		}

		return true;
	}

	public static VersionInfo getUnicodeVersion() {
		return UCharacterProperty.INSTANCE.m_unicodeVersion_;
	}

	public static String getName(int ch) {
		return UCharacterName.INSTANCE.getName(ch, 0);
	}

	public static String getName(String s, String separator) {
		if (s.length() == 1) {
			return getName(s.charAt(0));
		} else {
			StringBuilder sb = new StringBuilder();

			int cp;
			for (int i = 0; i < s.length(); i += UTF16.getCharCount(cp)) {
				cp = UTF16.charAt(s, i);
				if (i != 0) {
					sb.append(separator);
				}

				sb.append(getName(cp));
			}

			return sb.toString();
		}
	}

	public static String getName1_0(int ch) {
		return UCharacterName.INSTANCE.getName(ch, 1);
	}

	public static String getExtendedName(int ch) {
		return UCharacterName.INSTANCE.getName(ch, 2);
	}

	public static String getNameAlias(int ch) {
		return UCharacterName.INSTANCE.getName(ch, 3);
	}

	public static String getISOComment(int ch) {
		if (ch >= 0 && ch <= 1114111) {
			String result = UCharacterName.INSTANCE.getGroupName(ch, 4);
			return result;
		} else {
			return null;
		}
	}

	public static int getCharFromName(String name) {
		return UCharacterName.INSTANCE.getCharFromName(0, name);
	}

	public static int getCharFromName1_0(String name) {
		return UCharacterName.INSTANCE.getCharFromName(1, name);
	}

	public static int getCharFromExtendedName(String name) {
		return UCharacterName.INSTANCE.getCharFromName(2, name);
	}

	public static int getCharFromNameAlias(String name) {
		return UCharacterName.INSTANCE.getCharFromName(3, name);
	}

	public static String getPropertyName(int property, int nameChoice) {
		return UPropertyAliases.INSTANCE.getPropertyName(property, nameChoice);
	}

	public static int getPropertyEnum(String propertyAlias) {
		int propEnum = UPropertyAliases.INSTANCE.getPropertyEnum(propertyAlias);
		if (propEnum == -1) {
			throw new IllegalIcuArgumentException("Invalid name: " + propertyAlias);
		} else {
			return propEnum;
		}
	}

	public static String getPropertyValueName(int property, int value, int nameChoice) {
		if ((property == 4098 || property == 4112 || property == 4113) && value >= getIntPropertyMinValue(4098)
				&& value <= getIntPropertyMaxValue(4098) && nameChoice >= 0 && nameChoice < 2) {
			try {
				return UPropertyAliases.INSTANCE.getPropertyValueName(property, value, nameChoice);
			} catch (IllegalArgumentException var4) {
				return null;
			}
		} else {
			return UPropertyAliases.INSTANCE.getPropertyValueName(property, value, nameChoice);
		}
	}

	public static int getPropertyValueEnum(int property, String valueAlias) {
		int propEnum = UPropertyAliases.INSTANCE.getPropertyValueEnum(property, valueAlias);
		if (propEnum == -1) {
			throw new IllegalIcuArgumentException("Invalid name: " + valueAlias);
		} else {
			return propEnum;
		}
	}

	public static int getCodePoint(char lead, char trail) {
		if (UTF16.isLeadSurrogate(lead) && UTF16.isTrailSurrogate(trail)) {
			return UCharacterProperty.getRawSupplementary(lead, trail);
		} else {
			throw new IllegalArgumentException("Illegal surrogate characters");
		}
	}

	public static int getCodePoint(char char16) {
		if (isLegal(char16)) {
			return char16;
		} else {
			throw new IllegalArgumentException("Illegal codepoint");
		}
	}

	public static String toUpperCase(String str) {
		return toUpperCase(ULocale.getDefault(), str);
	}

	public static String toLowerCase(String str) {
		return toLowerCase(ULocale.getDefault(), str);
	}

	public static String toTitleCase(String str, BreakIterator breakiter) {
		return toTitleCase(ULocale.getDefault(), str, breakiter);
	}

	public static String toUpperCase(Locale locale, String str) {
		return toUpperCase(ULocale.forLocale(locale), str);
	}

	public static String toUpperCase(ULocale locale, String str) {
		StringContextIterator iter = new StringContextIterator(str);
		StringBuffer result = new StringBuffer(str.length());
		int[] locCache = new int[1];
		if (locale == null) {
			locale = ULocale.getDefault();
		}

		locCache[0] = 0;

		while (true) {
			int c;
			do {
				if ((c = iter.nextCaseMapCP()) < 0) {
					return result.toString();
				}

				c = UCaseProps.INSTANCE.toFullUpper(c, iter, result, locale, locCache);
				if (c < 0) {
					c = ~c;
					break;
				}
			} while (c <= 31);

			if (c <= 65535) {
				result.append((char) c);
			} else {
				UTF16.append(result, c);
			}
		}
	}

	public static String toLowerCase(Locale locale, String str) {
		return toLowerCase(ULocale.forLocale(locale), str);
	}

	public static String toLowerCase(ULocale locale, String str) {
		StringContextIterator iter = new StringContextIterator(str);
		StringBuffer result = new StringBuffer(str.length());
		int[] locCache = new int[1];
		if (locale == null) {
			locale = ULocale.getDefault();
		}

		locCache[0] = 0;

		while (true) {
			int c;
			do {
				if ((c = iter.nextCaseMapCP()) < 0) {
					return result.toString();
				}

				c = UCaseProps.INSTANCE.toFullLower(c, iter, result, locale, locCache);
				if (c < 0) {
					c = ~c;
					break;
				}
			} while (c <= 31);

			if (c <= 65535) {
				result.append((char) c);
			} else {
				UTF16.append(result, c);
			}
		}
	}

	public static String toTitleCase(Locale locale, String str, BreakIterator breakiter) {
		return toTitleCase(ULocale.forLocale(locale), str, breakiter);
	}

	public static String toTitleCase(ULocale locale, String str, BreakIterator titleIter) {
		return toTitleCase(locale, str, titleIter, 0);
	}

	public static String toTitleCase(ULocale locale, String str, BreakIterator titleIter, int options) {
		StringContextIterator iter = new StringContextIterator(str);
		StringBuffer result = new StringBuffer(str.length());
		int[] locCache = new int[1];
		int srcLength = str.length();
		if (locale == null) {
			locale = ULocale.getDefault();
		}

		locCache[0] = 0;
		if (titleIter == null) {
			titleIter = BreakIterator.getWordInstance(locale);
		}

		titleIter.setText(str);
		boolean isDutch = locale.getLanguage().equals("nl");
		boolean FirstIJ = true;
		int prev = 0;

		int index;
		label113 : for (boolean isFirstIndex = true; prev < srcLength; prev = index) {
			if (isFirstIndex) {
				isFirstIndex = false;
				index = titleIter.first();
			} else {
				index = titleIter.next();
			}

			if (index == -1 || index > srcLength) {
				index = srcLength;
			}

			if (prev < index) {
				iter.setLimit(index);
				int c = iter.nextCaseMapCP();
				int titleStart;
				if ((options & 512) == 0 && 0 == UCaseProps.INSTANCE.getType(c)) {
					while ((c = iter.nextCaseMapCP()) >= 0 && 0 == UCaseProps.INSTANCE.getType(c)) {
						;
					}

					titleStart = iter.getCPStart();
					if (prev < titleStart) {
						result.append(str, prev, titleStart);
					}
				} else {
					titleStart = prev;
				}

				if (titleStart < index) {
					FirstIJ = true;
					c = UCaseProps.INSTANCE.toFullTitle(c, iter, result, locale, locCache);

					while (true) {
						while (true) {
							if (c < 0) {
								c = ~c;
								if (c <= 65535) {
									result.append((char) c);
								} else {
									UTF16.append(result, c);
								}
							} else if (c > 31) {
								if (c <= 65535) {
									result.append((char) c);
								} else {
									UTF16.append(result, c);
								}
							}

							if ((options & 256) != 0) {
								int titleLimit = iter.getCPLimit();
								if (titleLimit < index) {
									String appendStr = str.substring(titleLimit, index);
									if (isDutch && c == 73 && appendStr.startsWith("j")) {
										appendStr = "J" + appendStr.substring(1);
									}

									result.append(appendStr);
								}

								iter.moveToLimit();
								continue label113;
							}

							int nc;
							if ((nc = iter.nextCaseMapCP()) < 0) {
								continue label113;
							}

							if (isDutch && (nc == 74 || nc == 106) && c == 73 && FirstIJ) {
								c = 74;
								FirstIJ = false;
							} else {
								c = UCaseProps.INSTANCE.toFullLower(nc, iter, result, locale, locCache);
							}
						}
					}
				}
			}
		}

		return result.toString();
	}

	public static int foldCase(int ch, boolean defaultmapping) {
		return foldCase(ch, defaultmapping ? 0 : 1);
	}

	public static String foldCase(String str, boolean defaultmapping) {
		return foldCase(str, defaultmapping ? 0 : 1);
	}

	public static int foldCase(int ch, int options) {
		return UCaseProps.INSTANCE.fold(ch, options);
	}

	public static final String foldCase(String str, int options) {
		StringBuffer result = new StringBuffer(str.length());
		int length = str.length();
		int i = 0;

		while (true) {
			int c;
			do {
				if (i >= length) {
					return result.toString();
				}

				c = UTF16.charAt(str, i);
				i += UTF16.getCharCount(c);
				c = UCaseProps.INSTANCE.toFullFolding(c, result, options);
				if (c < 0) {
					c = ~c;
					break;
				}
			} while (c <= 31);

			if (c <= 65535) {
				result.append((char) c);
			} else {
				UTF16.append(result, c);
			}
		}
	}

	public static int getHanNumericValue(int ch) {
		switch (ch) {
			case 12295 :
			case 38646 :
				return 0;
			case 19968 :
			case 22777 :
				return 1;
			case 19971 :
			case 26578 :
				return 7;
			case 19977 :
			case 21443 :
				return 3;
			case 20061 :
			case 29590 :
				return 9;
			case 20108 :
			case 36019 :
				return 2;
			case 20116 :
			case 20237 :
				return 5;
			case 20191 :
			case 21315 :
				return 1000;
			case 20336 :
			case 30334 :
				return 100;
			case 20740 :
				return 100000000;
			case 20843 :
			case 25420 :
				return 8;
			case 20845 :
			case 38520 :
				return 6;
			case 21313 :
			case 25342 :
				return 10;
			case 22232 :
			case 32902 :
				return 4;
			case 33356 :
				return 10000;
			default :
				return -1;
		}
	}

	public static RangeValueIterator getTypeIterator() {
		return new UCharacterTypeIterator(UCharacterProperty.INSTANCE);
	}

	public static ValueIterator getNameIterator() {
		return new UCharacterNameIterator(UCharacterName.INSTANCE, 0);
	}

	public static ValueIterator getName1_0Iterator() {
		return new UCharacterNameIterator(UCharacterName.INSTANCE, 1);
	}

	public static ValueIterator getExtendedNameIterator() {
		return new UCharacterNameIterator(UCharacterName.INSTANCE, 2);
	}

	public static VersionInfo getAge(int ch) {
		if (ch >= 0 && ch <= 1114111) {
			return UCharacterProperty.INSTANCE.getAge(ch);
		} else {
			throw new IllegalArgumentException("Codepoint out of bounds");
		}
	}

	public static boolean hasBinaryProperty(int ch, int property) {
		if (ch >= 0 && ch <= 1114111) {
			return UCharacterProperty.INSTANCE.hasBinaryProperty(ch, property);
		} else {
			throw new IllegalArgumentException("Codepoint out of bounds");
		}
	}

	public static boolean isUAlphabetic(int ch) {
		return hasBinaryProperty(ch, 0);
	}

	public static boolean isULowercase(int ch) {
		return hasBinaryProperty(ch, 22);
	}

	public static boolean isUUppercase(int ch) {
		return hasBinaryProperty(ch, 30);
	}

	public static boolean isUWhiteSpace(int ch) {
		return hasBinaryProperty(ch, 31);
	}

	public static int getIntPropertyValue(int ch, int type) {
		if (type < 0) {
			return 0;
		} else if (type < 57) {
			return hasBinaryProperty(ch, type) ? 1 : 0;
		} else if (type < 4096) {
			return 0;
		} else if (type < 4117) {
			switch (type) {
				case 4096 :
					return getDirection(ch);
				case 4097 :
					return UnicodeBlock.idOf(ch);
				case 4098 :
					return getCombiningClass(ch);
				case 4099 :
					return UCharacterProperty.INSTANCE.getAdditional(ch, 2) & 31;
				case 4100 :
					return (UCharacterProperty.INSTANCE.getAdditional(ch, 0) & 917504) >> 17;
				case 4101 :
					return getType(ch);
				case 4102 :
					return UBiDiProps.INSTANCE.getJoiningGroup(ch);
				case 4103 :
					return UBiDiProps.INSTANCE.getJoiningType(ch);
				case 4104 :
					return (UCharacterProperty.INSTANCE.getAdditional(ch, 2) & 66060288) >> 20;
				case 4105 :
					return ntvGetType(getNumericTypeValue(UCharacterProperty.INSTANCE.getProperty(ch)));
				case 4106 :
					return UScript.getScript(ch);
				case 4107 :
					int gcb = (UCharacterProperty.INSTANCE.getAdditional(ch, 2) & 992) >> 5;
					if (gcb < gcbToHst.length) {
						return gcbToHst[gcb];
					}

					return 0;
				case 4108 :
				case 4109 :
				case 4110 :
				case 4111 :
					return Norm2AllModes.getN2WithImpl(type - 4108).getQuickCheck(ch);
				case 4112 :
					return Norm2AllModes.getNFCInstance().impl.getFCDTrie().get(ch) >> 8;
				case 4113 :
					return Norm2AllModes.getNFCInstance().impl.getFCDTrie().get(ch) & 255;
				case 4114 :
					return (UCharacterProperty.INSTANCE.getAdditional(ch, 2) & 992) >> 5;
				case 4115 :
					return (UCharacterProperty.INSTANCE.getAdditional(ch, 2) & 1015808) >> 15;
				case 4116 :
					return (UCharacterProperty.INSTANCE.getAdditional(ch, 2) & 31744) >> 10;
				default :
					return 0;
			}
		} else {
			return type == 8192 ? UCharacterProperty.getMask(getType(ch)) : 0;
		}
	}

	public static String getStringPropertyValue(int propertyEnum, int codepoint, int nameChoice) {
		if ((propertyEnum < 0 || propertyEnum >= 57) && (propertyEnum < 4096 || propertyEnum >= 4117)) {
			if (propertyEnum == 12288) {
				return String.valueOf(getUnicodeNumericValue(codepoint));
			} else {
				switch (propertyEnum) {
					case 16384 :
						return getAge(codepoint).toString();
					case 16385 :
						return UTF16.valueOf(getMirror(codepoint));
					case 16386 :
						return foldCase(UTF16.valueOf(codepoint), true);
					case 16387 :
						return getISOComment(codepoint);
					case 16388 :
						return toLowerCase(UTF16.valueOf(codepoint));
					case 16389 :
						return getName(codepoint);
					case 16390 :
						return UTF16.valueOf(foldCase(codepoint, true));
					case 16391 :
						return UTF16.valueOf(toLowerCase(codepoint));
					case 16392 :
						return UTF16.valueOf(toTitleCase(codepoint));
					case 16393 :
						return UTF16.valueOf(toUpperCase(codepoint));
					case 16394 :
						return toTitleCase(UTF16.valueOf(codepoint), (BreakIterator) null);
					case 16395 :
						return getName1_0(codepoint);
					case 16396 :
						return toUpperCase(UTF16.valueOf(codepoint));
					default :
						throw new IllegalArgumentException("Illegal Property Enum");
				}
			}
		} else {
			return getPropertyValueName(propertyEnum, getIntPropertyValue(codepoint, propertyEnum), nameChoice);
		}
	}

	public static int getIntPropertyMinValue(int type) {
		return 0;
	}

	public static int getIntPropertyMaxValue(int type) {
		if (type < 0) {
			return -1;
		} else if (type < 57) {
			return 1;
		} else if (type < 4096) {
			return -1;
		} else if (type < 4117) {
			switch (type) {
				case 4096 :
				case 4102 :
				case 4103 :
					return UBiDiProps.INSTANCE.getMaxValue(type);
				case 4097 :
					return (UCharacterProperty.INSTANCE.getMaxValues(0) & 130816) >> 8;
				case 4098 :
				case 4112 :
				case 4113 :
					return 255;
				case 4099 :
					return UCharacterProperty.INSTANCE.getMaxValues(2) & 31;
				case 4100 :
					return (UCharacterProperty.INSTANCE.getMaxValues(0) & 917504) >> 17;
				case 4101 :
					return 29;
				case 4104 :
					return (UCharacterProperty.INSTANCE.getMaxValues(2) & 66060288) >> 20;
				case 4105 :
					return 3;
				case 4106 :
					return UCharacterProperty.INSTANCE.getMaxValues(0) & 255;
				case 4107 :
					return 5;
				case 4108 :
				case 4109 :
					return 1;
				case 4110 :
				case 4111 :
					return 2;
				case 4114 :
					return (UCharacterProperty.INSTANCE.getMaxValues(2) & 992) >> 5;
				case 4115 :
					return (UCharacterProperty.INSTANCE.getMaxValues(2) & 1015808) >> 15;
				case 4116 :
					return (UCharacterProperty.INSTANCE.getMaxValues(2) & 31744) >> 10;
				default :
					return -1;
			}
		} else {
			return -1;
		}
	}

	public static char forDigit(int digit, int radix) {
		return Character.forDigit(digit, radix);
	}

	public static final boolean isValidCodePoint(int cp) {
		return cp >= 0 && cp <= 1114111;
	}

	public static final boolean isSupplementaryCodePoint(int cp) {
		return cp >= 65536 && cp <= 1114111;
	}

	public static boolean isHighSurrogate(char ch) {
		return ch >= '?' && ch <= '?';
	}

	public static boolean isLowSurrogate(char ch) {
		return ch >= '?' && ch <= '?';
	}

	public static final boolean isSurrogatePair(char high, char low) {
		return isHighSurrogate(high) && isLowSurrogate(low);
	}

	public static int charCount(int cp) {
		return UTF16.getCharCount(cp);
	}

	public static final int toCodePoint(char high, char low) {
		return UCharacterProperty.getRawSupplementary(high, low);
	}

	public static final int codePointAt(CharSequence seq, int index) {
		char c1 = seq.charAt(index++);
		if (isHighSurrogate(c1) && index < seq.length()) {
			char c2 = seq.charAt(index);
			if (isLowSurrogate(c2)) {
				return toCodePoint(c1, c2);
			}
		}

		return c1;
	}

	public static final int codePointAt(char[] text, int index) {
		char c1 = text[index++];
		if (isHighSurrogate(c1) && index < text.length) {
			char c2 = text[index];
			if (isLowSurrogate(c2)) {
				return toCodePoint(c1, c2);
			}
		}

		return c1;
	}

	public static final int codePointAt(char[] text, int index, int limit) {
		if (index < limit && limit <= text.length) {
			char c1 = text[index++];
			if (isHighSurrogate(c1) && index < limit) {
				char c2 = text[index];
				if (isLowSurrogate(c2)) {
					return toCodePoint(c1, c2);
				}
			}

			return c1;
		} else {
			throw new IndexOutOfBoundsException();
		}
	}

	public static final int codePointBefore(CharSequence seq, int index) {
		--index;
		char c2 = seq.charAt(index);
		if (isLowSurrogate(c2) && index > 0) {
			--index;
			char c1 = seq.charAt(index);
			if (isHighSurrogate(c1)) {
				return toCodePoint(c1, c2);
			}
		}

		return c2;
	}

	public static final int codePointBefore(char[] text, int index) {
		--index;
		char c2 = text[index];
		if (isLowSurrogate(c2) && index > 0) {
			--index;
			char c1 = text[index];
			if (isHighSurrogate(c1)) {
				return toCodePoint(c1, c2);
			}
		}

		return c2;
	}

	public static final int codePointBefore(char[] text, int index, int limit) {
		if (index > limit && limit >= 0) {
			--index;
			char c2 = text[index];
			if (isLowSurrogate(c2) && index > limit) {
				--index;
				char c1 = text[index];
				if (isHighSurrogate(c1)) {
					return toCodePoint(c1, c2);
				}
			}

			return c2;
		} else {
			throw new IndexOutOfBoundsException();
		}
	}

	public static final int toChars(int cp, char[] dst, int dstIndex) {
		if (cp >= 0) {
			if (cp < 65536) {
				dst[dstIndex] = (char) cp;
				return 1;
			}

			if (cp <= 1114111) {
				dst[dstIndex] = UTF16.getLeadSurrogate(cp);
				dst[dstIndex + 1] = UTF16.getTrailSurrogate(cp);
				return 2;
			}
		}

		throw new IllegalArgumentException();
	}

	public static final char[] toChars(int cp) {
		if (cp >= 0) {
			if (cp < 65536) {
				return new char[]{(char) cp};
			}

			if (cp <= 1114111) {
				return new char[]{UTF16.getLeadSurrogate(cp), UTF16.getTrailSurrogate(cp)};
			}
		}

		throw new IllegalArgumentException();
	}

	public static byte getDirectionality(int cp) {
		return (byte) getDirection(cp);
	}

	public static int codePointCount(CharSequence text, int start, int limit) {
		if (start >= 0 && limit >= start && limit <= text.length()) {
			int len = limit - start;

			while (true) {
				while (limit > start) {
					--limit;
					char ch = text.charAt(limit);

					while (ch >= '?' && ch <= '?' && limit > start) {
						--limit;
						ch = text.charAt(limit);
						if (ch >= '?' && ch <= '?') {
							--len;
							break;
						}
					}
				}

				return len;
			}
		} else {
			throw new IndexOutOfBoundsException(
					"start (" + start + ") or limit (" + limit + ") invalid or out of range 0, " + text.length());
		}
	}

	public static int codePointCount(char[] text, int start, int limit) {
		if (start >= 0 && limit >= start && limit <= text.length) {
			int len = limit - start;

			while (true) {
				while (limit > start) {
					--limit;
					char ch = text[limit];

					while (ch >= '?' && ch <= '?' && limit > start) {
						--limit;
						ch = text[limit];
						if (ch >= '?' && ch <= '?') {
							--len;
							break;
						}
					}
				}

				return len;
			}
		} else {
			throw new IndexOutOfBoundsException(
					"start (" + start + ") or limit (" + limit + ") invalid or out of range 0, " + text.length);
		}
	}

	public static int offsetByCodePoints(CharSequence text, int index, int codePointOffset) {
		if (index >= 0 && index <= text.length()) {
			if (codePointOffset >= 0) {
				int limit = text.length();

				label50 : while (true) {
					--codePointOffset;
					if (codePointOffset < 0) {
						break;
					}

					char ch = text.charAt(index++);

					do {
						do {
							if (ch < '?' || ch > '?' || index >= limit) {
								continue label50;
							}

							ch = text.charAt(index++);
						} while (ch >= '?' && ch <= '?');

						--codePointOffset;
					} while (codePointOffset >= 0);

					return index - 1;
				}
			} else {
				label71 : while (true) {
					++codePointOffset;
					if (codePointOffset > 0) {
						break;
					}

					--index;
					char ch = text.charAt(index);

					do {
						do {
							if (ch < '?' || ch > '?' || index <= 0) {
								continue label71;
							}

							--index;
							ch = text.charAt(index);
						} while (ch >= '?' && ch <= '?');

						++codePointOffset;
					} while (codePointOffset <= 0);

					return index + 1;
				}
			}

			return index;
		} else {
			throw new IndexOutOfBoundsException("index ( " + index + ") out of range 0, " + text.length());
		}
	}

	public static int offsetByCodePoints(char[] text, int start, int count, int index, int codePointOffset) {
		int limit = start + count;
		if (start >= 0 && limit >= start && limit <= text.length && index >= start && index <= limit) {
			char ch;
			if (codePointOffset < 0) {
				label58 : while (true) {
					++codePointOffset;
					if (codePointOffset > 0) {
						break;
					}

					--index;
					ch = text[index];
					if (index < start) {
						throw new IndexOutOfBoundsException("index ( " + index + ") < start (" + start + ")");
					}

					do {
						do {
							if (ch < '?' || ch > '?' || index <= start) {
								continue label58;
							}

							--index;
							ch = text[index];
						} while (ch >= '?' && ch <= '?');

						++codePointOffset;
					} while (codePointOffset <= 0);

					return index + 1;
				}
			} else {
				label75 : while (true) {
					--codePointOffset;
					if (codePointOffset < 0) {
						break;
					}

					ch = text[index++];
					if (index > limit) {
						throw new IndexOutOfBoundsException("index ( " + index + ") > limit (" + limit + ")");
					}

					do {
						do {
							if (ch < '?' || ch > '?' || index >= limit) {
								continue label75;
							}

							ch = text[index++];
						} while (ch >= '?' && ch <= '?');

						--codePointOffset;
					} while (codePointOffset >= 0);

					return index - 1;
				}
			}

			return index;
		} else {
			throw new IndexOutOfBoundsException(
					"index ( " + index + ") out of range " + start + ", " + limit + " in array 0, " + text.length);
		}
	}

	private static final int getNumericTypeValue(int props) {
		return props >> 6;
	}

	private static final int ntvGetType(int ntv) {
		return ntv == 0 ? 0 : (ntv < 11 ? 1 : (ntv < 21 ? 2 : 3));
	}

	private static int getEuropeanDigit(int ch) {
		if ((ch <= 122 || ch >= 65313) && ch >= 65 && (ch <= 90 || ch >= 97) && ch <= 65370
				&& (ch <= 65338 || ch >= 65345)) {
			if (ch <= 122) {
				return ch + 10 - (ch <= 90 ? 65 : 97);
			} else {
				return ch <= 65338 ? ch + 10 - 'Ａ' : ch + 10 - 'ａ';
			}
		} else {
			return -1;
		}
	}

	private static final int getProperty(int ch) {
		if (ch < 55296 || ch > 56319 && ch < 65536) {
			try {
				return UCharacterProperty.INSTANCE.m_trieData_[(UCharacterProperty.INSTANCE.m_trieIndex_[ch >> 5] << 2)
						+ (ch & 31)];
			} catch (ArrayIndexOutOfBoundsException var2) {
				return UCharacterProperty.INSTANCE.m_trieInitialValue_;
			}
		} else if (ch <= 56319) {
			return UCharacterProperty.INSTANCE.m_trieData_[(UCharacterProperty.INSTANCE.m_trieIndex_[320
					+ (ch >> 5)] << 2) + (ch & 31)];
		} else {
			return ch <= 1114111
					? UCharacterProperty.INSTANCE.m_trie_.getSurrogateValue(UTF16.getLeadSurrogate(ch),
							(char) (ch & 1023))
					: UCharacterProperty.INSTANCE.m_trieInitialValue_;
		}
	}
}