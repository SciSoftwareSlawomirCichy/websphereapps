package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.asynchbeans.Alarm;
import com.ibm.websphere.asynchbeans.AlarmListener;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.asynchbeans.TaskDetails;
import com.ibm.ws.asynchbeans.WSAlarm;
import com.ibm.ws.ffdc.FFDCFilter;
import commonj.timers.Timer;
import commonj.timers.TimerListener;
import java.util.Date;

public class TimerNpListener implements AlarmListener, TimerListener, TaskDetails {
	private static final String CLASS_NAME = TimerNpListener.class.getName();
	private static final TraceComponent tc;
	public static boolean svOnServer;
	private long ivCreateTime;
	private BeanId ivBeanId;
	private int ivMethodId;
	private long ivRetries = 0L;
	private int ivRetryLimit;
	private int ivRetryInterval;
	private long ivNextExpiration;
	protected TimerNpImpl ivTimer;

	public TimerNpListener(TimerNpImpl timerNpImpl) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>: " + timerNpImpl);
		}

		if (!svOnServer) {
			throw new IllegalStateException("Method not supported on client.");
		} else {
			this.ivBeanId = timerNpImpl.getIvBeanId();
			this.ivMethodId = timerNpImpl.ivMethodId;
			this.ivTimer = timerNpImpl;
			this.ivRetryLimit = TimerNpImpl.svNpTimerServiceTimerRetryCount;
			this.ivRetryInterval = TimerNpImpl.svNpTimerServiceTimerRetryInterval;
			this.ivCreateTime = System.currentTimeMillis();
		}
	}

	public String toString() {
		return !TraceComponent.isAnyTracingEnabled()
				|| !tc.isDebugEnabled() && !tc.isEntryEnabled() && !tc.isEventEnabled()
						? super.toString()
						: "TimerNpListener(" + this.ivTimer + ", " + this.ivCreateTime + ") : " + super.toString();
	}

	public void fired(Alarm alarm) {
		this.doWorkWithRetries((WSAlarm) alarm);
	}

	private void doWorkWithRetries(WSAlarm alarm) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		String additionalInfo = null;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "doWorkWithRetries: " + this.ivTimer.ivTaskId);
		}

		if (this.ivRetries == 0L) {
			this.ivNextExpiration = this.ivTimer.calculateNextExpiration();
		}

		try {
			this.doWork(this.ivTimer);
			this.ivRetries = 0L;
			if (!this.ivTimer.isIvDestroyed()) {
				if (this.ivNextExpiration != 0L) {
					if (alarm != null) {
						alarm.reset(new Date(this.ivNextExpiration));
					} else {
						TimerNpImpl.svTimerManager.schedule(this, new Date(this.ivNextExpiration));
					}

					if (isTraceOn && tc.isDebugEnabled()) {
						additionalInfo = "re-scheduled timer " + this.ivTimer.ivTaskId + " for "
								+ this.ivNextExpiration;
					}
				} else {
					this.ivTimer.remove();
				}
			}
		} catch (Throwable var5) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "NP Timer failed : " + var5.getClass().getName() + ":" + var5.getMessage(), var5);
			}

			if (this.ivRetryLimit != -1 && this.ivRetries >= (long) this.ivRetryLimit) {
				Tr.warning(tc, "NP_TIMER_RETRY_LIMIT_REACHED_CNTR0179W", this.ivRetryLimit);
				return;
			}

			++this.ivRetries;
			if (this.ivRetries == 1L) {
				this.doWorkWithRetries(alarm);
			} else if (!this.ivTimer.isIvDestroyed()) {
				if (alarm != null) {
					alarm.reset(this.ivRetryInterval);
				} else {
					TimerNpImpl.svTimerManager.schedule(this, (long) this.ivRetryInterval);
				}

				if (isTraceOn && tc.isDebugEnabled()) {
					additionalInfo = "re-scheduled failed timer " + this.ivTimer.ivTaskId + " for retry interval "
							+ this.ivRetryInterval;
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "doWorkWithRetries: " + additionalInfo);
		}

	}

	private void doWork(TimerNpImpl inputTimer) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "doWork: " + this.ivBeanId);
		}

		try {
			this.ivBeanId = this.ivBeanId.getInitializedBeanId();
		} catch (Exception var8) {
			FFDCFilter.processException(var8, CLASS_NAME + ".doWork", "247", this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "doWork: " + var8);
			}

			throw ExceptionUtil.EJBException(var8);
		}

		EJSHome home = (EJSHome) this.ivBeanId.home;
		TimedObjectWrapper timedObject = home.getTimedObjectWrapper(this.ivBeanId);

		try {
			inputTimer.ivFiring = true;
			timedObject.invokeCallback(inputTimer, this.ivMethodId);
		} finally {
			inputTimer.ivFiring = false;
			home.putTimedObjectWrapper(timedObject);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "doWork: " + this.ivBeanId);
			}

		}

	}

	public void timerExpired(Timer timer) {
		this.doWorkWithRetries((WSAlarm) null);
	}

	public String getOwner() {
		return null;
	}

	public String getTaskName() {
		J2EEName j2eeName = this.ivBeanId.getJ2EEName();
		return this.ivTimer.ivTaskId + " " + j2eeName.getApplication() + ":" + j2eeName.getComponent() + " (EJB Timer)";
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		svOnServer = false;
	}
}