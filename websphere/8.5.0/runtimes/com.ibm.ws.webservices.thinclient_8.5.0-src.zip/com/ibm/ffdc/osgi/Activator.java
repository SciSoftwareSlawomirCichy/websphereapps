package com.ibm.ffdc.osgi;

import com.ibm.ffdc.impl.Ffdc;
import com.ibm.ffdc.provider.FfdcProvider;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator implements BundleActivator {
	private ProviderTracker providerTracker;
	private static Logger tracer = Logger.getLogger(Activator.class.getName());
	private static BundleContext bundleContext = null;

	public void start(BundleContext context) throws Exception {
		context.registerService(FfdcProvider.class.getName(), Ffdc.makeDefaultProvider(), new Hashtable());
		this.providerTracker = new ProviderTracker(context);
		this.providerTracker.open();
		bundleContext = context;
		if (tracer.isLoggable(Level.FINE)) {
			tracer.log(Level.FINE, "FfdcFacade started");
		}

	}

	public void stop(BundleContext context) throws Exception {
		this.providerTracker.close();
		this.providerTracker = null;
		if (tracer.isLoggable(Level.FINE)) {
			tracer.log(Level.FINE, "FfdcFacade stopped");
		}

	}

	public static BundleContext getBundleContext() {
		return bundleContext;
	}
}