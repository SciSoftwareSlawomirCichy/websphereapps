package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.ByteArray;
import com.ibm.wsspi.cluster.Identity;
import java.io.IOException;

public class EJSWrapperAccess {
	private static final String CLASS_NAME = EJSWrapperAccess.class.getName();
	private static final TraceComponent tc;
	private static final ClassLoader svClassLoader;

	public static ClassLoader getClassLoader(EJSRemoteWrapper wrapper) {
		ClassLoader classLoader = null;
		if (wrapper.bmd != null) {
			classLoader = wrapper.bmd.classLoader;
		} else {
			classLoader = svClassLoader;
		}

		return classLoader;
	}

	public static Identity getClusterIdentity(EJSRemoteWrapper wrapper) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getClusterIdentity", wrapper);
		}

		Object retVal = null;
		if (wrapper != null) {
			retVal = wrapper.ivCluster;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getClusterIdentity", retVal);
		}

		return (Identity) retVal;
	}

	public static ByteArray getServantKey(EJSRemoteWrapper wrapper) {
		ByteArray key = null;
		if (wrapper instanceof BusinessRemoteWrapper) {
			int remoteIndex = 0;
			Class thisClass = wrapper.getClass();
			Class[] remoteClasses = wrapper.bmd.ivBusinessRemoteImplClasses;
			Class[] arr$ = remoteClasses;
			int len$ = remoteClasses.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				Class remoteClass = arr$[i$];
				if (thisClass == remoteClass) {
					break;
				}

				++remoteIndex;
			}

			key = new WrapperId(wrapper.beanId.getByteArrayBytes(),
					wrapper.bmd.ivBusinessRemoteInterfaceClasses[remoteIndex].getName(), remoteIndex);
		} else {
			key = wrapper.beanId.getByteArray();
		}

		return (ByteArray) key;
	}

	public static boolean isServantKeyForHome(byte[] servantKey) throws IOException, ClassNotFoundException {
		com.ibm.ejs.container.util.ByteArray beanIdArray = null;
		if (servantKey[0] == -83) {
			WrapperId wrapperId = new WrapperId(servantKey);
			beanIdArray = wrapperId.getBeanIdArray();
		} else {
			beanIdArray = new com.ibm.ejs.container.util.ByteArray(servantKey);
		}

		BeanId beanId = BeanId.getBeanId(beanIdArray, EJSContainer.defaultContainer);
		return beanId.isHome();
	}

	public static boolean isSessionActivateTran(EJSRemoteWrapper wrapper) {
		return wrapper.ivInterface == WrapperInterface.HOME ? false : wrapper.bmd.sessionActivateTran;
	}

	public static boolean isStatefulSessionBean(EJSRemoteWrapper wrapper) {
		return wrapper.ivInterface == WrapperInterface.HOME ? false : wrapper.bmd.isStatefulSessionBean();
	}

	static {
		tc = Tr.register(CLASS_NAME, "ORB", "com.ibm.ejs.container.container");
		svClassLoader = EJSWrapperAccess.class.getClassLoader();
	}
}