package com.ibm.ejs.cm.pool;

import com.ibm.ejs.cm.portability.PortableSQLException;

public class IllegalIsolationLevelChangeException extends PortableSQLException {
	private static final long serialVersionUID = -5360334485606312547L;

	IllegalIsolationLevelChangeException() {
		super("Cannot change the isolation level of a connection enlisted in a JTS transaction");
	}
}