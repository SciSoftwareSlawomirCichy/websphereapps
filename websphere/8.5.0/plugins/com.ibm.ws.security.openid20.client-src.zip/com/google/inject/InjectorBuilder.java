package com.google.inject;

import com.google.inject.InjectorBuilder.1;
import com.google.inject.InjectorBuilder.ToolStageInjector;
import com.google.inject.InjectorShell.Builder;
import com.google.inject.internal.BindingImpl;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.ImmutableSet;
import com.google.inject.internal.Iterables;
import com.google.inject.internal.Stopwatch;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

class InjectorBuilder {
	private final Stopwatch stopwatch = new Stopwatch();
	private final Errors errors = new Errors();
	private Stage stage;
	private final Initializer initializer = new Initializer();
	private final BindingProcessor bindingProcesor;
	private final InjectionRequestProcessor injectionRequestProcessor;
	private final Builder shellBuilder = new Builder();
	private List<InjectorShell> shells;

	InjectorBuilder() {
		this.injectionRequestProcessor = new InjectionRequestProcessor(this.errors, this.initializer);
		this.bindingProcesor = new BindingProcessor(this.errors, this.initializer);
	}

	InjectorBuilder stage(Stage stage) {
		this.shellBuilder.stage(stage);
		this.stage = stage;
		return this;
	}

	InjectorBuilder parentInjector(InjectorImpl parent) {
		this.shellBuilder.parent(parent);
		return this.stage((Stage) parent.getInstance(Stage.class));
	}

	InjectorBuilder addModules(Iterable<? extends Module> modules) {
		this.shellBuilder.addModules(modules);
		return this;
	}

	Injector build() {
		if (this.shellBuilder == null) {
			throw new AssertionError("Already built, builders are not reusable.");
		} else {
			synchronized (this.shellBuilder.lock()) {
				this.shells = this.shellBuilder.build(this.initializer, this.bindingProcesor, this.stopwatch,
						this.errors);
				this.stopwatch.resetAndLog("Injector construction");
				this.initializeStatically();
			}

			if (this.stage == Stage.TOOL) {
				return new ToolStageInjector(this.primaryInjector());
			} else {
				this.injectDynamically();
				return this.primaryInjector();
			}
		}
	}

	private void initializeStatically() {
		this.bindingProcesor.initializeBindings();
		this.stopwatch.resetAndLog("Binding initialization");
		Iterator i$ = this.shells.iterator();

		InjectorShell shell;
		while (i$.hasNext()) {
			shell = (InjectorShell) i$.next();
			shell.getInjector().index();
		}

		this.stopwatch.resetAndLog("Binding indexing");
		this.injectionRequestProcessor.process(this.shells);
		this.stopwatch.resetAndLog("Collecting injection requests");
		this.bindingProcesor.runCreationListeners();
		this.stopwatch.resetAndLog("Binding validation");
		this.injectionRequestProcessor.validate();
		this.stopwatch.resetAndLog("Static validation");
		this.initializer.validateOustandingInjections(this.errors);
		this.stopwatch.resetAndLog("Instance member validation");
		(new LookupProcessor(this.errors)).process(this.shells);
		i$ = this.shells.iterator();

		while (i$.hasNext()) {
			shell = (InjectorShell) i$.next();
			((DeferredLookups) shell.getInjector().lookups).initialize(this.errors);
		}

		this.stopwatch.resetAndLog("Provider verification");
		i$ = this.shells.iterator();

		do {
			if (!i$.hasNext()) {
				this.errors.throwCreationExceptionIfErrorsExist();
				return;
			}

			shell = (InjectorShell) i$.next();
		} while (shell.getElements().isEmpty());

		throw new AssertionError("Failed to execute " + shell.getElements());
	}

	private Injector primaryInjector() {
		return ((InjectorShell) this.shells.get(0)).getInjector();
	}

	private void injectDynamically() {
		this.injectionRequestProcessor.injectMembers();
		this.stopwatch.resetAndLog("Static member injection");
		this.initializer.injectAll(this.errors);
		this.stopwatch.resetAndLog("Instance injection");
		this.errors.throwCreationExceptionIfErrorsExist();
		Iterator i$ = this.shells.iterator();

		while (i$.hasNext()) {
			InjectorShell shell = (InjectorShell) i$.next();
			this.loadEagerSingletons(shell.getInjector(), this.stage, this.errors);
		}

		this.stopwatch.resetAndLog("Preloading singletons");
		this.errors.throwCreationExceptionIfErrorsExist();
	}

	public void loadEagerSingletons(InjectorImpl injector, Stage stage, Errors errors) {
      Set<BindingImpl<?>> candidateBindings = ImmutableSet.copyOf(Iterables.concat(injector.state.getExplicitBindingsThisLevel().values(), injector.jitBindings.values()));
      Iterator i$ = candidateBindings.iterator();

      while(i$.hasNext()) {
         BindingImpl<?> binding = (BindingImpl)i$.next();
         if (binding.getScoping().isEagerSingleton(stage)) {
            try {
               injector.callInContext(new 1(this, binding, errors));
            } catch (ErrorsException var8) {
               throw new AssertionError();
            }
         }
      }

   }
}