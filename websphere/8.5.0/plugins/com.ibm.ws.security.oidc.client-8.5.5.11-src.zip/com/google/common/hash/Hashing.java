package com.google.common.hash;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.hash.Hashing.ChecksumType;
import com.google.common.hash.Hashing.ConcatenatedHashFunction;
import com.google.common.hash.Hashing.LinearCongruentialGenerator;
import java.util.Iterator;

@Beta
public final class Hashing {
	private static final int GOOD_FAST_HASH_SEED = (int) System.currentTimeMillis();
	private static final HashFunction GOOD_FAST_HASH_FUNCTION_32;
	private static final HashFunction GOOD_FAST_HASH_FUNCTION_128;
	private static final HashFunction MURMUR3_32;
	private static final HashFunction MURMUR3_128;
	private static final HashFunction MD5;
	private static final HashFunction SHA_1;
	private static final HashFunction SHA_256;
	private static final HashFunction SHA_512;
	private static final HashFunction CRC_32;
	private static final HashFunction ADLER_32;

	public static HashFunction goodFastHash(int minimumBits) {
		int bits = checkPositiveAndMakeMultipleOf32(minimumBits);
		if (bits == 32) {
			return GOOD_FAST_HASH_FUNCTION_32;
		} else if (bits <= 128) {
			return GOOD_FAST_HASH_FUNCTION_128;
		} else {
			int hashFunctionsNeeded = (bits + 127) / 128;
			HashFunction[] hashFunctions = new HashFunction[hashFunctionsNeeded];
			hashFunctions[0] = GOOD_FAST_HASH_FUNCTION_128;
			int seed = GOOD_FAST_HASH_SEED;

			for (int i = 1; i < hashFunctionsNeeded; ++i) {
				seed += 1500450271;
				hashFunctions[i] = murmur3_128(seed);
			}

			return new ConcatenatedHashFunction(hashFunctions);
		}
	}

	public static HashFunction murmur3_32(int seed) {
		return new Murmur3_32HashFunction(seed);
	}

	public static HashFunction murmur3_32() {
		return MURMUR3_32;
	}

	public static HashFunction murmur3_128(int seed) {
		return new Murmur3_128HashFunction(seed);
	}

	public static HashFunction murmur3_128() {
		return MURMUR3_128;
	}

	public static HashFunction md5() {
		return MD5;
	}

	public static HashFunction sha1() {
		return SHA_1;
	}

	public static HashFunction sha256() {
		return SHA_256;
	}

	public static HashFunction sha512() {
		return SHA_512;
	}

	public static HashFunction crc32() {
		return CRC_32;
	}

	public static HashFunction adler32() {
		return ADLER_32;
	}

	private static HashFunction checksumHashFunction(ChecksumType type, String toString) {
		return new ChecksumHashFunction(type, ChecksumType.access$000(type), toString);
	}

	@Deprecated
	public static long padToLong(HashCode hashCode) {
		return hashCode.padToLong();
	}

	public static int consistentHash(HashCode hashCode, int buckets) {
		return consistentHash(hashCode.padToLong(), buckets);
	}

	public static int consistentHash(long input, int buckets) {
		Preconditions.checkArgument(buckets > 0, "buckets must be positive: %s", new Object[]{buckets});
		LinearCongruentialGenerator generator = new LinearCongruentialGenerator(input);
		int candidate = 0;

		while (true) {
			int next = (int) ((double) (candidate + 1) / generator.nextDouble());
			if (next < 0 || next >= buckets) {
				return candidate;
			}

			candidate = next;
		}
	}

	public static HashCode combineOrdered(Iterable<HashCode> hashCodes) {
		Iterator<HashCode> iterator = hashCodes.iterator();
		Preconditions.checkArgument(iterator.hasNext(), "Must be at least 1 hash code to combine.");
		int bits = ((HashCode) iterator.next()).bits();
		byte[] resultBytes = new byte[bits / 8];
		Iterator i$ = hashCodes.iterator();

		while (i$.hasNext()) {
			HashCode hashCode = (HashCode) i$.next();
			byte[] nextBytes = hashCode.asBytes();
			Preconditions.checkArgument(nextBytes.length == resultBytes.length,
					"All hashcodes must have the same bit length.");

			for (int i = 0; i < nextBytes.length; ++i) {
				resultBytes[i] = (byte) (resultBytes[i] * 37 ^ nextBytes[i]);
			}
		}

		return HashCodes.fromBytesNoCopy(resultBytes);
	}

	public static HashCode combineUnordered(Iterable<HashCode> hashCodes) {
		Iterator<HashCode> iterator = hashCodes.iterator();
		Preconditions.checkArgument(iterator.hasNext(), "Must be at least 1 hash code to combine.");
		byte[] resultBytes = new byte[((HashCode) iterator.next()).bits() / 8];
		Iterator i$ = hashCodes.iterator();

		while (i$.hasNext()) {
			HashCode hashCode = (HashCode) i$.next();
			byte[] nextBytes = hashCode.asBytes();
			Preconditions.checkArgument(nextBytes.length == resultBytes.length,
					"All hashcodes must have the same bit length.");

			for (int i = 0; i < nextBytes.length; ++i) {
				resultBytes[i] += nextBytes[i];
			}
		}

		return HashCodes.fromBytesNoCopy(resultBytes);
	}

	static int checkPositiveAndMakeMultipleOf32(int bits) {
		Preconditions.checkArgument(bits > 0, "Number of bits must be positive");
		return bits + 31 & -32;
	}

	static {
		GOOD_FAST_HASH_FUNCTION_32 = murmur3_32(GOOD_FAST_HASH_SEED);
		GOOD_FAST_HASH_FUNCTION_128 = murmur3_128(GOOD_FAST_HASH_SEED);
		MURMUR3_32 = new Murmur3_32HashFunction(0);
		MURMUR3_128 = new Murmur3_128HashFunction(0);
		MD5 = new MessageDigestHashFunction("MD5", "Hashing.md5()");
		SHA_1 = new MessageDigestHashFunction("SHA-1", "Hashing.sha1()");
		SHA_256 = new MessageDigestHashFunction("SHA-256", "Hashing.sha256()");
		SHA_512 = new MessageDigestHashFunction("SHA-512", "Hashing.sha512()");
		CRC_32 = checksumHashFunction(ChecksumType.CRC_32, "Hashing.crc32()");
		ADLER_32 = checksumHashFunction(ChecksumType.ADLER_32, "Hashing.adler32()");
	}
}