package com.ibm.ws.wim.util;

import com.ibm.websphere.management.repository.ConfigRepository;
import com.ibm.websphere.management.repository.DocumentContentSource;
import com.ibm.websphere.management.repository.client.ConfigRepositoryClientFactory;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.federation.FederationEntity;
import com.ibm.ws.wim.management.DynamicReloadManager;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eclipse.emf.ecore.util.EcoreEList;

public class DataGraphHelper {
	static final String COPYRIGHT_NOTICE;
	static final String XML_COPYRIGHT;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static Map<String, List> allCtxProps;
	private static Map<String, List> allReferences;
	public static final List EMPTY_LIST;
	public static final List WILDCARD_LIST;
	public static final String WILDCARD = "*";
	public static final List IDENTIFIER_REF;
	private static final String FILE_NAME = "fileRegistry.xml";

	public static String getPersonUniqueNameFromAccountUniqueName(String var0) {
		String var1 = null;
		int var2 = var0.indexOf(44);
		var1 = var0.substring(var2 + 1, var0.length());
		return var1;
	}

	public static String getPersonUniqueIdFromAccountUniqueId(String var0) {
		String var1 = null;
		var1 = var0.substring(0, var0.length() - 4);
		return var1;
	}

	public static DataObject cloneDataObject(DataObject var0) {
		return SDOHelper.cloneDataObject(var0);
	}

	public static DataObject cloneRootDataObject(DataObject var0) {
		return SDOHelper.cloneRootDataObject(var0);
	}

	public static DataObject deepCloneRootDataObject(DataObject var0) {
		return SDOHelper.deepCloneRootDataObject(var0);
	}

	public static EObject cloneEObject(EObject var0) {
		return SDOHelper.cloneEObject(var0);
	}

	public static List cloneList(List var0) {
		EList var1 = null;
		if (var0 != null) {
			var1 = (EList) ((EcoreEList) var0).clone();
		}

		return var1;
	}

	public static byte[] insertCopyright(ByteArrayOutputStream var0) throws Exception {
		String var1 = new String(var0.toByteArray(), "UTF-8");
		StringBuffer var2 = new StringBuffer(var1);
		int var3 = var2.indexOf("<?");
		int var4 = var2.indexOf("?>");
		if (var3 == 0 && var4 > 0) {
			var2.insert(var4 + 2, XML_COPYRIGHT);
			return var2.toString().getBytes("UTF-8");
		} else {
			return var0.toByteArray();
		}
	}

	public static void saveDataGraph(DataGraph var0, String var1) throws WIMSystemException {
		try {
			ByteArrayOutputStream var3 = new ByteArrayOutputStream();
			((EDataGraph) ((EDataGraph) var0)).getDataGraphResource().save(var3, (Map) null);
			byte[] var4 = insertCopyright(var3);
			FileOutputStream var5 = new FileOutputStream(var1);
			var5.write(var4);
			var5.close();
		} catch (Exception var6) {
			throw new WIMSystemException("ERROR_WRITING_FILE",
					WIMMessageHelper.generateMsgParms(var1, var6.getMessage()), CLASSNAME,
					"saveDataGraph(DataGraph,String)", var6);
		}
	}

	public static void saveDataGraphWithoutCopyright(DataGraph var0, String var1) throws WIMSystemException {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.entering(CLASSNAME, "saveDataGraphWithoutCopyright(DataGraph,String)", var1);
		}

		ConfigRepository var4 = null;
		String var5 = null;

		try {
			FileOutputStream var6 = new FileOutputStream(var1);
			((EDataGraph) var0).getDataGraphResource().save(var6, (Map) null);
			var6.close();
			String var7 = var1.replace("\\", "/");
			String var8 = "/config/cells/" + DynamicReloadManager.getCellName();
			if (var3) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "saveDataGraphWithoutCopyright(DataGraph,String)",
						"checking if " + var7 + " contains " + var8);
			}

			if (var7.contains(var8)) {
				Properties var9 = new Properties();
				var9.setProperty("location", "local");

				try {
					var4 = ConfigRepositoryClientFactory.getConfigRepositoryClient(var9);
					var4.initialize(var9);
				} catch (Exception var13) {
					throw new WIMSystemException("Unable to create repository client while trying to save " + var1,
							CLASSNAME, "saveDataGraphWithoutCopyright(DataGraph,String)", var13);
				}

				String var10 = "waspolicies/default/securitydomains/";
				if (var1.contains(var10)) {
					var5 = var7.substring(var7.indexOf(var10));
				} else {
					var5 = "cells" + File.separator + DynamicReloadManager.getCellName() + File.separator
							+ "fileRegistry.xml";
				}

				if (var3) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "saveDataGraphWithoutCopyright(DataGraph,String)",
							"doing copy of " + var5);
				}

				DocumentContentSource var11 = var4.extract(var5);
				ByteArrayOutputStream var12 = new ByteArrayOutputStream();
				((EDataGraph) var0).getDataGraphResource().save(var12, (Map) null);
				var11.setSource(new ByteArrayInputStream(var12.toByteArray()));
				var4.modify(var11);
				var12.close();
			}
		} catch (Exception var14) {
			throw new WIMSystemException("ERROR_WRITING_FILE",
					WIMMessageHelper.generateMsgParms(var1 + ", uri=" + var5, var14.getMessage()), CLASSNAME,
					"saveDataGraphWithoutCopyright(DataGraph,String)", var14);
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "saveDataGraphWithoutCopyright(DataGraph,String)", var5);
		}

	}

	public static void copyDataObject(DataObject var0, DataObject var1, List var2, List var3, List var4)
			throws Exception {
		boolean var6 = trcLogger.isLoggable(Level.FINEST);
		EClass var7 = ((EDataObject) var1).eClass();
		if (var6) {
			String var8 = "srcType=" + var1.getType().getName() + ", destType=" + var0.getType().getName() + ", props="
					+ var2 + ", ctxProps=" + var3 + ", refs=" + var4;
			trcLogger.entering(CLASSNAME, "copyDataObject", var8);
		}

		EList var9;
		int var10;
		EAttribute var11;
		String var12;
		String var13;
		boolean var20;
		if (var2 != null && var2.size() > 0) {
			var20 = false;
			if (var2.contains("*")) {
				var20 = true;
				if (var6) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "copyDataObject", "copy all props=true");
				}
			}

			var9 = var7.getEAllAttributes();

			for (var10 = 0; var10 < var9.size(); ++var10) {
				var11 = (EAttribute) var9.get(var10);
				var12 = var11.getName();
				if (!isOperationalProps(var12) || var2.contains(var12)) {
					if (!var12.equals("ibmPrimaryEmail") && !var12.equals("ibmJobTitle")) {
						if (var1.isSet(var12) && (var20 || var2.contains(var12))) {
							if (var6) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "copyDataObject", "copying prop " + var12);
							}

							if (var0.isSet(var12)) {
								var0.unset(var12);
							}

							var0.set(var12, var1.get(var12));
						}
					} else if (var12.equals("ibmPrimaryEmail")) {
						if (var1.isSet(var12)) {
							var13 = "ibm-primaryEmail";
							if (var20 || var2.contains(var13)) {
								if (var6) {
									trcLogger.logp(Level.FINEST, CLASSNAME, "copyDataObject", "copying prop " + var13);
								}

								if (var0.isSet(var13)) {
									var0.unset(var13);
								}

								var0.set(var13, var1.get("ibmPrimaryEmail"));
							}
						}
					} else if (var1.isSet(var12)) {
						var13 = "ibm-jobTitle";
						if (var20 || var2.contains(var13)) {
							if (var6) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "copyDataObject", "copying prop " + var13);
							}

							if (var0.isSet(var13)) {
								var0.unset(var13);
							}

							var0.set(var13, var1.get("ibmJobTitle"));
						}
					}
				}
			}
		}

		DataObject var16;
		DataObject var28;
		if (var3 != null && var3.size() > 0) {
			var20 = false;
			var9 = null;
			ArrayList var21 = new ArrayList();

			for (var10 = 0; var10 < var3.size(); ++var10) {
				var11 = null;
				Object var24 = var3.get(var10);
				String var23;
				if (var24 instanceof String) {
					var23 = (String) var24;
				} else {
					var28 = (DataObject) var3.get(var10);
					var23 = var28.getString("value");
				}

				if ("*".equals(var23)) {
					var20 = true;
					if (var6) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "copyDataObject", "copy all ctxprops=true");
					}
				} else {
					var21.add(var23);
				}
			}

			EList var22 = var7.getEAllReferences();

			for (int var25 = 0; var25 < var22.size(); ++var25) {
				EReference var26 = (EReference) var22.get(var25);
				var13 = var26.getName();
				if (var1.isSet(var13) && isContextProperty(var1, var26)) {
					ArrayList var14 = new ArrayList();
					String var18;
					if (!var20 && var21.contains(var13)) {
						for (int var15 = 0; var15 < var3.size(); ++var15) {
							var16 = (DataObject) var3.get(var15);
							String var17 = var16.getString("value");
							if (var17.equals(var13)) {
								var18 = var16.getString("lang");
								if (var18 != null && !var18.equals("") && !var18.equals("*")) {
									var14.add(var18);
								}
							}
						}
					}

					if (var6) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "copyDataObject",
								"copying context prop=" + var13 + " for langs=" + var14);
					}

					List var32 = var1.getList(var13);
					if (var0.isSet(var13)) {
						var0.unset(var13);
					}

					for (int var34 = 0; var34 < var32.size(); ++var34) {
						DataObject var35 = (DataObject) var32.get(var34);
						var18 = var35.getString("lang");
						if (var14.size() == 0 || var14.contains(var18)) {
							DataObject var19 = var0.createDataObject(var13);
							var19.setString("value", var35.getString("value"));
							var19.setString("lang", var18);
						}
					}
				}
			}
		}

		if (var4 != null && var4.size() > 0) {
			var20 = false;
			if (var4.contains("*")) {
				var20 = true;
				if (var6) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "copyDataObject", "copy all refs=true");
				}
			}

			var9 = var7.getEAllReferences();

			for (var10 = 0; var10 < var9.size(); ++var10) {
				EReference var27 = (EReference) var9.get(var10);
				var12 = var27.getName();
				if (var1.isSet(var12) && !isContextProperty(var1, var27) && (var20 || var4.contains(var12))) {
					if (var6) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "copyDataObject", "copying reference=" + var12);
					}

					if (var0.isSet(var12)) {
						var0.unset(var12);
					}

					if (var27.isMany()) {
						List var30 = var1.getList(var12);

						for (int var31 = 0; var31 < var30.size(); ++var31) {
							DataObject var33 = (DataObject) var30.get(var31);
							var16 = var0.createDataObject(var12);
							copyDataObject(var16, var33, WILDCARD_LIST, WILDCARD_LIST, (List) null);
						}
					} else {
						var28 = var1.getDataObject(var12);
						DataObject var29 = var0.createDataObject(var12);
						copyDataObject(var29, var28, WILDCARD_LIST, WILDCARD_LIST, (List) null);
					}
				}
			}
		}

		if (var6) {
			trcLogger.exiting(CLASSNAME, "copyDataObject", var7.getName());
		}

	}

	private static boolean isOperationalProps(String var0) {
		return "createTimestamp".equals(var0) || "modifyTimestamp".equals(var0);
	}

	public static boolean isContextProperty(DataObject var0, EReference var1) throws Exception {
		boolean var2 = false;
		String var3 = var1.getName();
		String var4 = DomainManagerUtils.getDomainName();
		if (allCtxProps.get(var4) == null) {
			allCtxProps.put(var4, new ArrayList());
		}

		if (allReferences.get(var4) == null) {
			allReferences.put(var4, new ArrayList());
		}

		if (((List) allCtxProps.get(var4)).contains(var3)) {
			var2 = true;
		} else if (!((List) allReferences.get(var4)).contains(var3)) {
			DataObject var5 = null;
			if (var1.isMany()) {
				var5 = var0.getDataObject(var1.getName() + ".0");
			} else {
				var5 = var0.getDataObject(var1.getName());
			}

			EClass var6 = SchemaManager.singleton().getEClass(var5.getType().getName());
			if (var6.getEReferences().size() == 0) {
				EList var7 = var6.getEAttributes();

				for (int var8 = 0; var8 < var7.size(); ++var8) {
					EAttribute var9 = (EAttribute) var7.get(var8);
					if ("lang".equals(var9.getName())) {
						var2 = true;
					}
				}
			}

			if (var2) {
				((List) allCtxProps.get(var4)).add(var3);
			} else {
				((List) allReferences.get(var4)).add(var3);
			}

			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "isContextProperty",
						"all context propeties=" + allCtxProps.get(var4));
				trcLogger.logp(Level.FINEST, CLASSNAME, "isContextProperty",
						"all references=" + allReferences.get(var4));
			}
		}

		return var2;
	}

	public static void prepareIdentifierFromFedRepository(DataObject var0) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "prepareIdentifier(id)");
		}

		String var2 = var0.getString("uniqueId");
		String var3 = var0.getString("uniqueName");
		RepositoryManager var4 = RepositoryManager.singleton();
		String var5 = null;
		String var6 = null;
		FederationEntity var7;
		if (var2 != null && var2.trim().length() != 0) {
			if (var4.isEntryJoin()) {
				var7 = var4.getFederationRepository().lookupByUniqueId(var2);
				var3 = var7.getUniqueName();
				var5 = var7.getRepositoryId();
				var6 = var7.getExternalId();
			}
		} else if (var3 != null && var3.trim().length() != 0 && var4.isEntryJoin()) {
			var7 = var4.getFederationRepository().lookupByUniqueName(var3);
			var2 = var7.getUniqueId();
			var5 = var7.getRepositoryId();
			var6 = var7.getExternalId();
		}

		var0.setString("uniqueId", var2);
		var0.setString("uniqueName", var3);
		var0.setString("repositoryId", var5);
		var0.setString("externalId", var6);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "prepareIdentifier(id)");
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		XML_COPYRIGHT = IBMCopyright.RUNTIME_COPYRIGHT_NOTICE_FOR_XML_2005_2010;
		CLASSNAME = DataGraphHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		allCtxProps = Collections.synchronizedMap(new HashMap());
		allReferences = Collections.synchronizedMap(new HashMap());
		EMPTY_LIST = new ArrayList();
		WILDCARD_LIST = new ArrayList();
		IDENTIFIER_REF = new ArrayList();
		IDENTIFIER_REF.add("identifier");
		WILDCARD_LIST.add("*");
	}
}