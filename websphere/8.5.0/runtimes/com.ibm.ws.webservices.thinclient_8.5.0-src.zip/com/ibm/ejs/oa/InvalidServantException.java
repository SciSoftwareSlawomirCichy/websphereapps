package com.ibm.ejs.oa;

import com.ibm.ejs.EJSException;

public class InvalidServantException extends EJSException {
	private static final long serialVersionUID = 6525241634708540660L;

	public InvalidServantException() {
	}

	public InvalidServantException(String s) {
		super(s);
	}

	public InvalidServantException(String s, Throwable ex) {
		super(s, ex);
	}
}