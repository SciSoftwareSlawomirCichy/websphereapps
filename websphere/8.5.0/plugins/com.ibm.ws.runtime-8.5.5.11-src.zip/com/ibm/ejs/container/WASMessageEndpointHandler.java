package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.tx.jta.embeddable.EmbeddableTransactionManagerFactory;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.csi.MessageEndpointInvocationHandler;
import com.ibm.ws.csi.MessageEndpointTestResults;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import com.ibm.ws.ejbcontainer.mdb.BaseMessageEndpointFactory;
import com.ibm.ws.ejbcontainer.mdb.MessageEndpointHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.jms.Message;
import javax.jms.MessageListener;

public final class WASMessageEndpointHandler extends MessageEndpointHandler
		implements
			MessageEndpointInvocationHandler {
	private static final String CLASS_NAME = WASMessageEndpointHandler.class.getName();
	private static final TraceComponent tc;
	private MessageEndpointTestResults ivMessageEndpointTestResults = null;

	public WASMessageEndpointHandler(BaseMessageEndpointFactory factory, int recoveryId, EJSContainer container,
			BeanMetaData beanMetaData, EJBPMICollaborator pmiBean, WrapperManager wrapperManager, boolean jmsFlag) {
		super(factory, recoveryId, container, beanMetaData, wrapperManager, jmsFlag, false);
		this.ivPmiBean = pmiBean;
	}

	protected void notifyMessageDelivered() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "notifyMessageDelivered: results = " + this.ivMessageEndpointTestResults);
		}

		if (this.ivMessageEndpointTestResults != null) {
			UOWCurrent uowCurrent = EmbeddableTransactionManagerFactory.getUOWCurrent();
			UOWCoordinator uowCoord = uowCurrent.getUOWCoord();
			if (uowCoord.isGlobal()) {
				this.ivMessageEndpointTestResults.setRunningInGlobalTransactionContext();
			} else {
				this.ivMessageEndpointTestResults.setRunningInLocalTransactionContext();
			}
		}

		if (this.ivPmiBean != null) {
			this.ivPmiBean.messageDelivered();
		}

	}

	protected void invokeJMSMethod(Method methodToInvoke, Object mdb, Object[] args)
			throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		Message msg = (Message) args[0];
		MessageListener ml = (MessageListener) mdb;
		ml.onMessage(msg);
	}

	public void setTestResults(MessageEndpointTestResults results) {
		this.ivMessageEndpointTestResults = results;
	}

	public void unsetTestResults() {
		this.ivMessageEndpointTestResults = null;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}