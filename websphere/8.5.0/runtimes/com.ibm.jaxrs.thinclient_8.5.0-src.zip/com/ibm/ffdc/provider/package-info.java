package com.ibm.ffdc.provider;

interface package-info {
}