package com.ibm.ws.wim.config;

import com.ibm.websphere.management.repository.ConfigRepositoryEvent;
import com.ibm.websphere.management.repository.ConfigRepositoryListener;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.ws.wim.RealmManager;

public class DynamicRealmConfig implements ConfigRepositoryListener {
	private RealmManager realmManager = null;

	public DynamicRealmConfig() throws WIMException {
		this.realmManager = RealmManager.singleton();
	}

	public void onChangeCompletion(ConfigRepositoryEvent var1) {
		if (this.realmManager.isRealmConfigChange()) {
			try {
				this.realmManager.reInitialize();
			} catch (WIMException var3) {
				var3.printStackTrace();
			}
		}

		this.realmManager.setRealmConfigChange(false);
	}

	public void onChangeStart(ConfigRepositoryEvent var1) {
	}

	public void onRepositoryEpochRefresh() {
	}

	public void onRepositoryLock() {
	}

	public void onRepositoryUnlock() {
	}
}