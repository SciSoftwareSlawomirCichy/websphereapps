package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_zh_TW extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: 「FFDC 格式製作程式」已新增 {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: 分析引擎使用資料庫：{0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: 無法解析「分析引擎」："},
			{"FFDCDataCollectorAdded", "FFDC1011I: 「FFDC 資料收集器」已新增 {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: 「FFDC 資料收集器」已移除 {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: 「FFDC 發生事件」產生在 SystemErr：{0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC 處於失敗安全模式，請檢查錯誤 {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: 「FFDC 發生事件轉遞器」已新增 {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: 「FFDC 發生事件轉遞器」已移除 {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: {0} {1} {2} 上產生了「FFDC 發生事件」"},
			{"FFDCProviderAborted", "FFDC1000I: 「FFDC 提供者」{0} 已中斷，接著發生異常狀況"},
			{"FFDCProviderAbortedE", "FFDC1001I: 「FFDC 提供者」已中斷，異常狀況是 {0}"},
			{"FFDCProviderException", "FFDC1008I: 「FFDC 提供者」異常狀況："},
			{"FFDCProviderInstalled", "FFDC1007I: 「FFDC 提供者」已安裝：{0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: 「FFDC 格式製作程式」已移除 {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}