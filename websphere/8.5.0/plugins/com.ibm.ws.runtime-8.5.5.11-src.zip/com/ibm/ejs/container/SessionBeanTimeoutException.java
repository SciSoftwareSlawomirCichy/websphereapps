package com.ibm.ejs.container;

import java.rmi.NoSuchObjectException;

public class SessionBeanTimeoutException extends NoSuchObjectException {
	private static final long serialVersionUID = 2591380441572291126L;

	public SessionBeanTimeoutException(String s) {
		super(s);
	}
}