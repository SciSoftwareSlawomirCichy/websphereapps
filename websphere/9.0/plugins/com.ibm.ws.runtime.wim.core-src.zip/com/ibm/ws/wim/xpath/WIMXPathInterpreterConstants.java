package com.ibm.ws.wim.xpath;

public interface WIMXPathInterpreterConstants {
	int EOF = 0;
	int ENTITIES = 12;
	int COMPOSITENAME = 13;
	int NAME = 14;
	int PREFIX = 15;
	int NCNAME = 16;
	int NCNAMECHAR = 17;
	int CONTAINS = 18;
	int STARTSWITH = 19;
	int ENDSWITH = 20;
	int AT = 21;
	int COMPOP = 22;
	int LITERAL = 23;
	int INTEGERLITERAL = 24;
	int DECIMALLITERAL = 25;
	int DIGITS = 26;
	int LETTER = 27;
	int DIGIT = 28;
	int SPACE = 29;
	int SLASH = 30;
	int SLASH_SLASH = 31;
	int Nmchar = 32;
	int AllLetter = 33;
	int VALUENAME = 34;
	int BaseChar = 35;
	int Ideographic = 36;
	int CombiningChar = 37;
	int Extender = 38;
	int Digit = 39;
	int DEFAULT = 0;
	String[] tokenImage = new String[]{"<EOF>", "\"and\"", "\"(\"", "\")\"", "\"[\"", "\"]\"", "\"or\"",
			"\"@xsi:type\"", "\" \"", "\"\\t\"", "\"\\n\"", "\"\\r\"", "\"entities\"", "<COMPOSITENAME>", "<NAME>",
			"<PREFIX>", "<NCNAME>", "<NCNAMECHAR>", "<CONTAINS>", "<STARTSWITH>", "<ENDSWITH>", "\"@\"", "<COMPOP>",
			"<LITERAL>", "<INTEGERLITERAL>", "<DECIMALLITERAL>", "<DIGITS>", "<LETTER>", "<DIGIT>", "<SPACE>", "\"/\"",
			"\"//\"", "<Nmchar>", "<AllLetter>", "<VALUENAME>", "<BaseChar>", "<Ideographic>", "<CombiningChar>",
			"<Extender>", "<Digit>"};
}