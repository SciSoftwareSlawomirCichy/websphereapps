package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.collect.Queues;
import com.google.common.util.concurrent.AbstractService.1;
import com.google.common.util.concurrent.AbstractService.2;
import com.google.common.util.concurrent.AbstractService.3;
import com.google.common.util.concurrent.AbstractService.4;
import com.google.common.util.concurrent.AbstractService.5;
import com.google.common.util.concurrent.AbstractService.6;
import com.google.common.util.concurrent.AbstractService.7;
import com.google.common.util.concurrent.AbstractService.ListenerExecutorPair;
import com.google.common.util.concurrent.AbstractService.StateSnapshot;
import com.google.common.util.concurrent.AbstractService.Transition;
import com.google.common.util.concurrent.Service.Listener;
import com.google.common.util.concurrent.Service.State;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;
import javax.annotation.concurrent.GuardedBy;

@Beta
public abstract class AbstractService implements Service {
	private static final Logger logger = Logger.getLogger(AbstractService.class.getName());
	private final ReentrantLock lock = new ReentrantLock();
	private final Transition startup = new Transition(this, (1)null);
	private final Transition shutdown = new Transition(this, (1)null);
	@GuardedBy("lock")
	private final List<ListenerExecutorPair> listeners = Lists.newArrayList();
	@GuardedBy("queuedListeners")
	private final Queue<Runnable> queuedListeners = Queues.newConcurrentLinkedQueue();
	@GuardedBy("lock")
	private volatile StateSnapshot snapshot;

	protected AbstractService() {
      this.snapshot = new StateSnapshot(State.NEW);
      this.addListener(new 1(this), MoreExecutors.sameThreadExecutor());
   }

	protected abstract void doStart();

	protected abstract void doStop();

	public final ListenableFuture<State> start() {
		this.lock.lock();

		try {
			if (this.snapshot.state == State.NEW) {
				this.snapshot = new StateSnapshot(State.STARTING);
				this.starting();
				this.doStart();
			}
		} catch (Throwable var5) {
			this.notifyFailed(var5);
		} finally {
			this.lock.unlock();
			this.executeListeners();
		}

		return this.startup;
	}

	public final ListenableFuture<State> stop() {
      this.lock.lock();

      try {
         switch(7.$SwitchMap$com$google$common$util$concurrent$Service$State[this.snapshot.state.ordinal()]) {
         case 1:
            this.snapshot = new StateSnapshot(State.STARTING, true, (Throwable)null);
            this.stopping(State.STARTING);
            break;
         case 2:
            this.snapshot = new StateSnapshot(State.STOPPING);
            this.stopping(State.RUNNING);
            this.doStop();
         case 3:
         case 4:
         case 5:
            break;
         case 6:
            this.snapshot = new StateSnapshot(State.TERMINATED);
            this.terminated(State.NEW);
            break;
         default:
            throw new AssertionError("Unexpected state: " + this.snapshot.state);
         }
      } catch (Throwable var5) {
         this.notifyFailed(var5);
      } finally {
         this.lock.unlock();
         this.executeListeners();
      }

      return this.shutdown;
   }

	public State startAndWait() {
		return (State) Futures.getUnchecked(this.start());
	}

	public State stopAndWait() {
		return (State) Futures.getUnchecked(this.stop());
	}

	protected final void notifyStarted() {
		this.lock.lock();

		try {
			if (this.snapshot.state != State.STARTING) {
				IllegalStateException failure = new IllegalStateException(
						"Cannot notifyStarted() when the service is " + this.snapshot.state);
				this.notifyFailed(failure);
				throw failure;
			}

			if (this.snapshot.shutdownWhenStartupFinishes) {
				this.snapshot = new StateSnapshot(State.STOPPING);
				this.doStop();
			} else {
				this.snapshot = new StateSnapshot(State.RUNNING);
				this.running();
			}
		} finally {
			this.lock.unlock();
			this.executeListeners();
		}

	}

	protected final void notifyStopped() {
		this.lock.lock();

		try {
			if (this.snapshot.state != State.STOPPING && this.snapshot.state != State.RUNNING) {
				IllegalStateException failure = new IllegalStateException(
						"Cannot notifyStopped() when the service is " + this.snapshot.state);
				this.notifyFailed(failure);
				throw failure;
			}

			State previous = this.snapshot.state;
			this.snapshot = new StateSnapshot(State.TERMINATED);
			this.terminated(previous);
		} finally {
			this.lock.unlock();
			this.executeListeners();
		}

	}

	protected final void notifyFailed(Throwable cause) {
      Preconditions.checkNotNull(cause);
      this.lock.lock();

      try {
         switch(7.$SwitchMap$com$google$common$util$concurrent$Service$State[this.snapshot.state.ordinal()]) {
         case 1:
         case 2:
         case 3:
            State previous = this.snapshot.state;
            this.snapshot = new StateSnapshot(State.FAILED, false, cause);
            this.failed(previous, cause);
            break;
         case 4:
         case 6:
            throw new IllegalStateException("Failed while in state:" + this.snapshot.state, cause);
         case 5:
            break;
         default:
            throw new AssertionError("Unexpected state: " + this.snapshot.state);
         }
      } finally {
         this.lock.unlock();
         this.executeListeners();
      }

   }

	public final boolean isRunning() {
		return this.state() == State.RUNNING;
	}

	public final State state() {
		return this.snapshot.externalState();
	}

	public final Throwable failureCause() {
		return this.snapshot.failureCause();
	}

	public final void addListener(Listener listener, Executor executor) {
		Preconditions.checkNotNull(listener, "listener");
		Preconditions.checkNotNull(executor, "executor");
		this.lock.lock();

		try {
			if (this.snapshot.state != State.TERMINATED && this.snapshot.state != State.FAILED) {
				this.listeners.add(new ListenerExecutorPair(listener, executor));
			}
		} finally {
			this.lock.unlock();
		}

	}

	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.state() + "]";
	}

	private void executeListeners() {
		if (!this.lock.isHeldByCurrentThread()) {
			Queue var1 = this.queuedListeners;
			Runnable listener;
			synchronized (this.queuedListeners) {
				while ((listener = (Runnable) this.queuedListeners.poll()) != null) {
					listener.run();
				}
			}
		}

	}

	@GuardedBy("lock")
   private void starting() {
      Iterator i$ = this.listeners.iterator();

      while(i$.hasNext()) {
         ListenerExecutorPair pair = (ListenerExecutorPair)i$.next();
         this.queuedListeners.add(new 2(this, pair));
      }

   }

	@GuardedBy("lock")
   private void running() {
      Iterator i$ = this.listeners.iterator();

      while(i$.hasNext()) {
         ListenerExecutorPair pair = (ListenerExecutorPair)i$.next();
         this.queuedListeners.add(new 3(this, pair));
      }

   }

	@GuardedBy("lock")
   private void stopping(State from) {
      Iterator i$ = this.listeners.iterator();

      while(i$.hasNext()) {
         ListenerExecutorPair pair = (ListenerExecutorPair)i$.next();
         this.queuedListeners.add(new 4(this, pair, from));
      }

   }

	@GuardedBy("lock")
   private void terminated(State from) {
      Iterator i$ = this.listeners.iterator();

      while(i$.hasNext()) {
         ListenerExecutorPair pair = (ListenerExecutorPair)i$.next();
         this.queuedListeners.add(new 5(this, pair, from));
      }

      this.listeners.clear();
   }

	@GuardedBy("lock")
   private void failed(State from, Throwable cause) {
      Iterator i$ = this.listeners.iterator();

      while(i$.hasNext()) {
         ListenerExecutorPair pair = (ListenerExecutorPair)i$.next();
         this.queuedListeners.add(new 6(this, pair, from, cause));
      }

      this.listeners.clear();
   }
}