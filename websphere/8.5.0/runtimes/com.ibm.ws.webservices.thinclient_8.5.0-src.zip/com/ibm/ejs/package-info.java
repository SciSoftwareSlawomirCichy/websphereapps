package com.ibm.ejs;

interface package-info {
}