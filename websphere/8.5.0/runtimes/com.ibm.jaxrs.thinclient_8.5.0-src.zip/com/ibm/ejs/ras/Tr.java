package com.ibm.ejs.ras;

import com.ibm.ejs.ras.Tr.1;
import com.ibm.ejs.ras.Tr.10;
import com.ibm.ejs.ras.Tr.11;
import com.ibm.ejs.ras.Tr.2;
import com.ibm.ejs.ras.Tr.3;
import com.ibm.ejs.ras.Tr.4;
import com.ibm.ejs.ras.Tr.5;
import com.ibm.ejs.ras.Tr.6;
import com.ibm.ejs.ras.Tr.7;
import com.ibm.ejs.ras.Tr.8;
import com.ibm.ejs.ras.Tr.9;
import com.ibm.ejs.ras.ffdc.FfdcProvider;
import com.ibm.ffdc.impl.Ffdc;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.net.URL;
import java.security.AccessController;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class Tr {
	public static final String $sccsid = "@(#) 1.44 SERV1/ws/code/ras.lite/src/com/ibm/ejs/ras/Tr.java, WAS.ras.lite, WAS855.SERV1, cf051506.04 13/09/23 10:10:52 [2/19/15 14:14:30]";
	private static final String FFDC_IGNORE_PREFIX = "ffdc.ignore";
	private static final String FILE_SEPARATOR = System.getProperty("file.separator");
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");
	private static final String TRACE_SETTINGS_FILE = "traceSettingsFile";
	private static final String TRACE_FILE_NAME = "traceFileName";
	private static final String TRACE_MAX_FILE_SIZE = "maxFileSize";
	private static final String TRACE_MAX_FILES = "maxFiles";
	private static final String TRACE_FORMAT = "traceFormat";
	private static final String TRACE_JAVA_UTIL = "javaUtilLoggingSpec";
	private static final String ALT_TRACE_FILE_NAME = "com.ibm.ejs.ras.lite.traceFileName";
	private static final String ALT_TRACE_SPECIFICATION = "com.ibm.ejs.ras.lite.traceSpecification";
	private static final String ALT_TRACE_MAX_FILE_SIZE = "com.ibm.ejs.ras.lite.maxFileSize";
	private static final String ALT_TRACE_MAX_FILES = "com.ibm.ejs.ras.lite.maxFiles";
	private static final String ALT_TRACE_FORMAT = "com.ibm.ejs.ras.lite.traceFormat";
	private static final String ALT_TRACE_JAVA_UTIL = "com.ibm.ejs.ras.lite.javaUtilLoggingSpec";
	private static final String CMVC_RELEASE = "CMVC_RELEASE";
	private static final String CMVC_LEVEL = "CMVC_LEVEL";
	private static final String className = Tr.class.getName();
	private static final TraceNLS nls = TraceNLS.getTraceNLS("com.ibm.ejs.ras.Messages");
	private static ComponentManager cm = new ComponentManager();
	private static Set<TraceComponent> allTraceComponents = Collections.newSetFromMap(new ConcurrentHashMap());
	private static Properties traceProperties = new Properties();
	private static PrintStream traceFile;
	private static FileOutputStream traceFileOutputStream;
	static Logger logger;
	private static final String BUILD_PROPERTIES = "com/ibm/ejs/ras/lite/build.properties";
	private static final String USER_PROPERTIES = "com/ibm/ejs/ras/lite/user.properties";
	private static final String USER2_PROPERTIES = "com/ibm/ejs/ras/lite/user2.properties";
	private static String traceFileName;
	private static String traceSpec;
	private static int maxFileSize;
	private static int maxFiles;
	private static String traceFormat;
	private static String javaUtilLoggingSpec;
	private static String defaultJavaUtilLoggingSpec;
	private static List<String> ffdcIgnore;
	static final String nl;
	private static int nnn;

	private static void handleUserProperties(Set<Properties> s) {
		Iterator i = s.iterator();

		while (i.hasNext()) {
			Properties props = (Properties) i.next();
			Properties temp = new Properties();
			String cmvcRelease = props.getProperty("CMVC_RELEASE");
			String cmvcLevel = props.getProperty("CMVC_LEVEL");
			if (cmvcRelease != null) {
				temp.put("CMVC_RELEASE", cmvcRelease);
			}

			if (cmvcLevel != null) {
				temp.put("CMVC_LEVEL", cmvcLevel);
			}

			if (temp.size() != 0) {
				traceRecord("Using build " + temp);
			}

			Set<Entry<Object, Object>> entries = props.entrySet();
			Iterator i$ = entries.iterator();

			while (i$.hasNext()) {
				Entry<Object, Object> entry = (Entry) i$.next();
				String key = (String) entry.getKey();
				if (key.startsWith("ffdc.ignore")) {
					ffdcIgnore.add((String) entry.getValue());
				}
			}
		}

	}

	private static String safelyGetSystemProperty(String key) {
      String rc = null;

      try {
         rc = (String)AccessController.doPrivileged(new 7(key));
      } catch (Exception var3) {
         System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var3, key}, ""));
      }

      return rc;
   }

	private static String[] safelyGetFiles(String dir) {
      String[] rc = null;

      try {
         rc = (String[])AccessController.doPrivileged(new 8(dir));
      } catch (Exception var3) {
         System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var3, dir}, ""));
      }

      return rc;
   }

	private static Set<Properties> getUserProperties(String fn) {
      Set<Properties> rc = new HashSet();
      ClassLoader cl = Thread.currentThread().getContextClassLoader();

      try {
         Enumeration e = (Enumeration)AccessController.doPrivileged(new 9(cl, fn));

         while(e != null && e.hasMoreElements()) {
            URL url = (URL)e.nextElement();
            InputStream is = (InputStream)AccessController.doPrivileged(new 10(url));
            Properties ps = new Properties();
            ps.load(is);
            rc.add(ps);
         }
      } catch (Exception var7) {
         System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var7, fn}, ""));
      }

      return rc;
   }

	public static void init() {
	}

	public static Logger getLogger(String name, String group, String resourceBundleName) {
		return resourceBundleName == null ? Logger.getLogger(name) : Logger.getLogger(name, resourceBundleName);
	}

	public static TraceComponent register(Class aClass) {
		return register(aClass.getName());
	}

	public static TraceComponent register(String name) {
		return register((String) name, (String) null, (String) null);
	}

	public static TraceComponent register(Class aClass, String group) {
		return register((String) aClass.getName(), group, (String) null);
	}

	public static TraceComponent register(String name, String group) {
		return register((String) name, group, (String) null);
	}

	public static TraceComponent register(Class aClass, String group, String bundle) {
		return register(aClass.getName(), group, bundle);
	}

	public static TraceComponent register(String name, String group, String bundle) {
		TraceComponent tc = new TraceComponent(name, group, bundle);
		if (logger != null) {
			tc.setLogger(Logger.getLogger(name));
		}

		tc.setTraceSpec(traceSpec);
		allTraceComponents.add(tc);
		return tc;
	}

	public static void registerDumpable(TraceComponent tc, Dumpable d) {
	}

	static ComponentManager getComponentManager() {
		return cm;
	}

	public static final void audit(TraceComponent tc, String msgKey) {
		audit(tc, msgKey, "");
	}

	public static final void audit(TraceComponent tc, String msgKey, Object objs) {
		if (tc.isAuditEnabled()) {
			trace(tc, Level.INFO, "A", "A  ", formatMsg(tc, msgKey, objs));
		}

	}

	public static final void debug(TraceComponent tc, String msg) {
		debug(tc, msg, (Object) null);
	}

	public static final void debug(TraceComponent tc, String msg, Object objs) {
		if (tc.isDebugEnabled()) {
			trace(tc, Level.FINEST, "3", "3  ", formatObj(msg, objs));
		}

	}

	public static final void dump(TraceComponent tc, String msg) {
		dump(tc, msg, (Object) null);
	}

	public static final void dump(TraceComponent tc, String msg, Object objs) {
		if (tc.isDumpEnabled()) {
			trace(tc, Level.FINEST, " ", " ", formatObj(msg, objs));
		}

	}

	public static final void error(TraceComponent tc, String msgKey) {
		error(tc, msgKey, "");
	}

	public static final void error(TraceComponent tc, String msgKey, Object objs) {
		String msg = formatMsg(tc, msgKey, objs);
		if (tc.isErrorEnabled()) {
			trace(tc, Level.INFO, "E", "E  ", msg);
		}

		System.err.println(msg);
	}

	public static final void event(TraceComponent tc, String msg) {
		event(tc, msg, (Object) null);
	}

	public static final void event(TraceComponent tc, String msg, Object objs) {
		if (tc.isEventEnabled()) {
			trace(tc, Level.INFO, " ", " ", formatObj(msg, objs));
		}

	}

	public static final void entry(TraceComponent tc, String methodName) {
		entry(tc, methodName, (Object) null);
	}

	public static final void entry(TraceComponent tc, String methodName, Object objs) {
		if (tc.isEntryEnabled()) {
			trace(tc, Level.FINER, ">", "> ", methodName, formatObj("Entry", objs));
		}

	}

	public static final void exit(TraceComponent tc, String methodName) {
		exit(tc, methodName, (Object) null);
	}

	public static final void exit(TraceComponent tc, String methodName, Object objs) {
		if (tc.isEntryEnabled()) {
			trace(tc, Level.FINER, "<", "< ", methodName, formatObj("Exit", objs));
		}

	}

	public static final void fatal(TraceComponent tc, String msgKey) {
		fatal(tc, msgKey, "");
	}

	public static final void fatal(TraceComponent tc, String msgKey, Object objs) {
		String msg = formatMsg(tc, msgKey, objs);
		if (tc.isFatalEnabled()) {
			trace(tc, Level.SEVERE, "F", "F  ", msg);
		}

		System.err.println(msg);
	}

	public static final void info(TraceComponent tc, String msgKey) {
		info(tc, msgKey, "");
	}

	public static final void info(TraceComponent tc, String msgKey, Object objs) {
		if (tc.isInfoEnabled()) {
			trace(tc, Level.INFO, "I", "I  ", formatMsg(tc, msgKey, objs));
		}

	}

	public static final void service(TraceComponent tc, String msgKey) {
		service(tc, msgKey, (Object) null);
	}

	public static final void service(TraceComponent tc, String msgKey, Object objs) {
		if (tc.isServiceEnabled()) {
			trace(tc, Level.INFO, " ", " ", formatObj("Service: " + msgKey, objs));
		}

	}

	public static final void uncondEvent(TraceComponent tc, String msg) {
		uncondEvent(tc, msg, (Object) null);
	}

	public static final void uncondEvent(TraceComponent tc, String msg, Object objs) {
		trace(tc, Level.INFO, " ", " ", formatObj("uncondEvent: " + msg, objs));
	}

	public static final void uncondFormattedEvent(TraceComponent tc, String msgKey) {
		uncondFormattedEvent(tc, msgKey, "");
	}

	public static final void uncondFormattedEvent(TraceComponent tc, String msgKey, Object objs) {
		trace(tc, Level.INFO, " ", " ", "uncondFormattedEvent: " + formatMsg(tc, msgKey, objs));
	}

	public static final void warning(TraceComponent tc, String msgKey) {
		warning(tc, msgKey, "");
	}

	public static final void warning(TraceComponent tc, String msgKey, Object objs) {
		if (tc.isWarningEnabled()) {
			trace(tc, Level.WARNING, "W", "W  ", formatMsg(tc, msgKey, objs));
		}

	}

	public static void setTraceSpec(String ts) {
		traceSpec = ts;
		Iterator it = allTraceComponents.iterator();

		while (it.hasNext()) {
			TraceComponent t = (TraceComponent) it.next();
			t.setTraceSpec(traceSpec);
		}

	}

	public static void updateTraceSpec(TraceComponent tc) {
		tc.setTraceSpec(traceSpec);
	}

	public static List<String> getFfdcIgnoreList() {
		return ffdcIgnore;
	}

	private static void trace(TraceComponent tc, Level level, String sym, String basicSym, String txt) {
		trace(tc, level, sym, basicSym, (String) null, txt);
	}

	private static void trace(TraceComponent tc, Level level, String sym, String basicSym, String method, String txt) {
		String record = formatTraceRecord(tc.getName(), sym, basicSym, method, txt);
		if (tc.getLogger() == null) {
			traceToFile(record);
		} else {
			tc.getLogger().log(level, record);
		}

	}

	static String formatTraceRecord(String name, String sym, String basicSym, String method, String txt) {
		String timestamp = (new SimpleDateFormat("[dd/MM/yyyy HH:mm:ss:SSS z]")).format(new Date());
		String threadid = RasHelper.getThreadId();
		String record = timestamp + " " + threadid + " ";
		if (traceFormat.equalsIgnoreCase("basic")) {
			record = record + format(name, 48) + " " + basicSym + " " + (method == null ? "" : method + " ") + txt;
		} else {
			record = record + sym + " UOW=" + " " + "source=" + name + " "
					+ (method == null ? "" : "method=" + method + " ") + nl + "          " + txt;
		}

		return record;
	}

	private static String format(String s, int l) {
		if (s.length() > l) {
			return s.substring(s.length() - l, s.length());
		} else {
			StringBuffer sb = (new StringBuffer(256)).append(s);

			for (int i = sb.length(); i < l; ++i) {
				sb.append(" ");
			}

			return sb.toString();
		}
	}

	private static String formatMsg(TraceComponent tc, String msgKey, Object objs) {
		String ans = "";
		Object[] args = new Object[0];
		TraceNLS traceNLS = TraceNLS.getTraceNLS(tc.getResourceBundleName());
		if (objs != null) {
			if (objs.getClass().isArray()) {
				args = (Object[]) ((Object[]) objs);
			} else {
				args = new Object[]{objs};
			}
		}

		return traceNLS.getFormattedMessage(msgKey, args,
				"Message Key:" + msgKey + " not found in resource bundle:" + tc.getResourceBundleName());
	}

	static String formatObj(String msg, Object objs) {
		if (objs == null) {
			return msg;
		} else {
			String pad = "                                 ";
			StringBuilder sb = (new StringBuilder(msg)).append(' ');
			if (objs instanceof Object[]) {
				Object[] arr$ = (Object[]) ((Object[]) objs);
				int len$ = arr$.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					Object obj = arr$[i$];
					sb.append(nl).append("                                 ");
					formatSingleObj(sb, obj);
				}
			} else {
				sb.append(nl).append("                                 ");
				formatSingleObj(sb, objs);
			}

			return sb.toString();
		}
	}

	private static void formatThrowable(StringBuilder sb, Throwable t) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		t.printStackTrace(pw);
		sb.append(sw.getBuffer().toString());
	}

	private static void formatToString(StringBuilder sb, Object o, Traceable t) {
		try {
			sb.append(t != null ? t.toTraceString() : o.toString());
		} catch (Exception var4) {
			sb.append("<Exception caught while calling ").append(t != null ? "toTraceString" : "toString")
					.append("() on ").append(o.getClass().getName()).append('@')
					.append(Integer.toHexString(System.identityHashCode(o))).append(": ");
			formatThrowable(sb, var4);
			sb.append('>');
		}

	}

	private static void formatSingleObj(StringBuilder sb, Object o) {
		if (o == null) {
			sb.append("null");
		} else if (o instanceof byte[]) {
			sb.append('[');
			byte[] arr = (byte[]) ((byte[]) o);

			for (int i = 0; i < arr.length; ++i) {
				if (i > 0) {
					sb.append(",");
				}

				sb.append(arr[i]);
				if (i > 4096) {
					sb.append("...Remaining entries suppressed");
					break;
				}
			}

			sb.append(']');
		} else if (o instanceof Untraceable) {
			sb.append(o.getClass().getName());
		} else if (o instanceof Traceable) {
			formatToString(sb, (Object) null, (Traceable) o);
		} else if (o instanceof Throwable) {
			formatThrowable(sb, (Throwable) o);
		} else {
			formatToString(sb, o, (Traceable) null);
		}

	}

	private static void traceRecord(String record) {
		if (traceSpec != null) {
			if (logger == null) {
				traceToFile(record);
			} else if (logger.isLoggable(Level.CONFIG)) {
				logger.config(record);
			}
		}

	}

	static void traceToFile(String record) {
		if (maxFileSize > 0) {
			long currentSize = 0L;
			long maxFileSizeBytes = (long) maxFileSize * 1024L * 1024L;

			do {
				try {
					currentSize = traceFileOutputStream.getChannel().size();
					if (currentSize > 0L) {
						currentSize += (long) (record.length() + LINE_SEPARATOR.length());
					}
				} catch (IOException var6) {
					;
				}

				if (currentSize > maxFileSizeBytes) {
					traceFile.close();
					openNewTraceFile();
				}
			} while (currentSize > maxFileSizeBytes);
		}

		traceFile.println(record);
	}

	private static boolean openNewTraceFile() {
      String fn = traceFileName;
      int lio = traceFileName.lastIndexOf(FILE_SEPARATOR);
      String dirName;
      String fileName;
      if (lio > 0) {
         dirName = traceFileName.substring(0, lio + 1);
         fileName = traceFileName.substring(lio + 1);
      } else {
         dirName = ".";
         fileName = traceFileName;
      }

      if (maxFileSize > 0) {
         if (nnn == 0) {
            String[] files = safelyGetFiles(dirName);
            if (files != null) {
               for(int i = 0; i < files.length; ++i) {
                  if (files[i].startsWith(fileName + ".")) {
                     int lio2 = files[i].lastIndexOf(".");
                     String number = files[i].substring(lio2 + 1);
                     int numberInt = new Integer(number);
                     if (numberInt > nnn) {
                        nnn = numberInt;
                     }
                  }
               }
            }
         }

         fn = fn + "." + Integer.toString(nnn++);
      }

      String fnf = fn;
      String dirNamef = dirName;
      String fileNamef = fileName;
      Boolean traceFileExists = false;

      try {
         traceFileExists = (Boolean)AccessController.doPrivileged(new 11(fnf, dirNamef, fileNamef));
      } catch (Exception var9) {
         System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var9, dirName + FILE_SEPARATOR}, ""));
      }

      return traceFileExists;
   }

	static {
      traceFile = System.out;
      traceFileOutputStream = null;
      logger = null;
      maxFileSize = 0;
      maxFiles = 0;
      defaultJavaUtilLoggingSpec = "com.ibm";
      ffdcIgnore = new ArrayList();
      Object o = LogManager.getLogManager();
      if (o.getClass().getName().equals("com.ibm.ws.bootstrap.WsLogManager")) {
         Method initialiseForRasLite = null;

         try {
            initialiseForRasLite = o.getClass().getMethod("initialiseForRasLite");
         } catch (NoSuchMethodException var19) {
            ;
         }

         if (initialiseForRasLite != null) {
            try {
               initialiseForRasLite.invoke((Object)null);
            } catch (Exception var18) {
               System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var18, "Initilizing WebSphere Log Manager"}, ""));
            }
         } else {
            try {
               AccessController.doPrivileged(new 1(o));
            } catch (Exception var17) {
               System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var17, "Initializing WebSphere Log Manager"}, ""));
            }
         }

         defaultJavaUtilLoggingSpec = "";
      }

      traceFileName = safelyGetSystemProperty("com.ibm.ejs.ras.lite.traceFileName");
      traceSpec = safelyGetSystemProperty("com.ibm.ejs.ras.lite.traceSpecification");
      boolean foundMaxFileSize = safelyGetSystemProperty("com.ibm.ejs.ras.lite.maxFileSize") != null;
      if (foundMaxFileSize) {
         maxFileSize = new Integer(safelyGetSystemProperty("com.ibm.ejs.ras.lite.maxFileSize"));
      }

      boolean foundMaxFiles = safelyGetSystemProperty("com.ibm.ejs.ras.lite.maxFiles") != null;
      if (foundMaxFiles) {
         maxFiles = new Integer(safelyGetSystemProperty("com.ibm.ejs.ras.lite.maxFiles"));
      }

      traceFormat = safelyGetSystemProperty("com.ibm.ejs.ras.lite.traceFormat");
      javaUtilLoggingSpec = safelyGetSystemProperty("com.ibm.ejs.ras.lite.javaUtilLoggingSpec");
      String tracePropertiesFile = safelyGetSystemProperty("traceSettingsFile");
      if (tracePropertiesFile != null) {
         try {
            AccessController.doPrivileged(new 2(tracePropertiesFile));
         } catch (Exception var16) {
            System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var16, tracePropertiesFile}, ""));
         }
      }

      if (traceFileName == null) {
         traceFileName = traceProperties.getProperty("traceFileName");
      }

      if (traceSpec == null) {
         StringBuffer sb = new StringBuffer(256);
         Enumeration e = traceProperties.propertyNames();

         while(e.hasMoreElements()) {
            String element = (String)e.nextElement();
            if (!element.equals("traceFileName") && !element.equals("maxFileSize") && !element.equals("maxFiles") && !element.equals("traceFormat")) {
               if (sb.length() > 0 && sb.charAt(sb.length() - 1) != ':') {
                  sb.append(":");
               }

               sb.append(element + "=" + traceProperties.getProperty(element));
            }
         }

         if (sb.toString().trim().length() > 0) {
            traceSpec = sb.toString();
         }
      }

      String mf;
      if (!foundMaxFileSize) {
         mf = traceProperties.getProperty("maxFileSize");
         if (mf != null) {
            maxFileSize = new Integer(mf);
         }
      }

      if (!foundMaxFiles) {
         mf = traceProperties.getProperty("maxFiles");
         if (mf != null) {
            maxFiles = new Integer(mf);
         }
      }

      if (traceFormat == null) {
         traceFormat = traceProperties.getProperty("traceFormat");
         if (traceFormat == null) {
            traceFormat = "basic";
         }
      }

      if (traceFileName == null) {
         traceFileName = "";
      }

      if (javaUtilLoggingSpec == null) {
         javaUtilLoggingSpec = traceProperties.getProperty("javaUtilLoggingSpec");
         if (javaUtilLoggingSpec == null) {
            javaUtilLoggingSpec = defaultJavaUtilLoggingSpec;
         }
      }

      try {
         AccessController.doPrivileged(new 3());
      } catch (Exception var15) {
         System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var15, "Initilizing WebSphere Log Manager"}, ""));
      }

      if (!traceFileName.equals("") && !traceFileName.equalsIgnoreCase("stdout")) {
         if (traceFileName.equalsIgnoreCase("stderr")) {
            traceFile = System.err;
            maxFileSize = 0;
            maxFiles = 0;
         } else if (traceFileName.equalsIgnoreCase("java.util.logging")) {
            logger = Logger.getLogger(className);
            maxFileSize = 0;
            maxFiles = 0;
         } else if (openNewTraceFile()) {
            traceRecord("--------------------------------------------------------------------------------------------------------------------------------------------");
         }
      } else {
         traceFile = System.out;
         maxFileSize = 0;
         maxFiles = 0;
      }

      traceRecord("************ Start Display Current Environment ************");

      Properties firstProperties;
      try {
         firstProperties = (Properties)AccessController.doPrivileged(new 4());
         TreeMap<String, String> tm = new TreeMap(firstProperties);
         Set<String> s = tm.keySet();
         Iterator i = s.iterator();

         while(i.hasNext()) {
            String key = (String)i.next();
            if (key.toLowerCase().indexOf("password", 0) == -1) {
               traceRecord(key + "=" + safelyGetSystemProperty(key));
            } else {
               traceRecord(key + "=" + "********");
            }
         }
      } catch (Exception var21) {
         traceRecord(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var21, "All System Properties"}, ""));
         traceRecord("com.ibm.ejs.ras.lite.traceFileName=" + safelyGetSystemProperty("com.ibm.ejs.ras.lite.traceFileName"));
         traceRecord("com.ibm.ejs.ras.lite.traceSpecification=" + safelyGetSystemProperty("com.ibm.ejs.ras.lite.traceSpecification"));
         traceRecord("com.ibm.ejs.ras.lite.maxFileSize=" + safelyGetSystemProperty("com.ibm.ejs.ras.lite.maxFileSize"));
         traceRecord("com.ibm.ejs.ras.lite.maxFiles=" + safelyGetSystemProperty("com.ibm.ejs.ras.lite.maxFiles"));
         traceRecord("com.ibm.ejs.ras.lite.traceFormat=" + safelyGetSystemProperty("com.ibm.ejs.ras.lite.traceFormat"));
         traceRecord("com.ibm.ejs.ras.lite.javaUtilLoggingSpec=" + safelyGetSystemProperty("com.ibm.ejs.ras.lite.javaUtilLoggingSpec"));
         traceRecord("traceSettingsFile=" + safelyGetSystemProperty("traceSettingsFile"));
      }

      traceRecord(" ");
      traceRecord("Using trace specification \"" + traceSpec + "\"");
      firstProperties = null;
      ClassLoader cl = Thread.currentThread().getContextClassLoader();
      Enumeration e = null;

      try {
         e = (Enumeration)AccessController.doPrivileged(new 5(cl));
      } catch (Exception var14) {
         System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var14, "com/ibm/ejs/ras/lite/build.properties"}, ""));
      }

      URL firstURL = null;
      boolean passed = true;

      try {
         while(e != null && e.hasMoreElements()) {
            URL url = (URL)e.nextElement();
            InputStream is = null;

            try {
               is = (InputStream)AccessController.doPrivileged(new 6(url));
            } catch (Exception var13) {
               System.err.println(nls.getFormattedMessage("EXCP_CWSJE0003E", new Object[]{var13, url}, ""));
            }

            Properties ps = new Properties();
            ps.load(is);
            if (firstURL == null) {
               firstURL = url;
               firstProperties = ps;
            } else if (!ps.equals(firstProperties)) {
               String msg = nls.getFormattedMessage("BUILDLEVELS_NOT_SAME_CWSJE0001E", new Object[]{firstURL, firstProperties, url, ps}, "");
               System.err.println(msg);
               traceRecord(msg);
               passed = false;
            }
         }
      } catch (IOException var20) {
         ;
      }

      if (passed) {
         traceRecord("Using build " + firstProperties);
         handleUserProperties(getUserProperties("com/ibm/ejs/ras/lite/user.properties"));
         handleUserProperties(getUserProperties("com/ibm/ejs/ras/lite/user2.properties"));
         traceRecord("************* End Display Current Environment *************");
         ffdcIgnore = Collections.unmodifiableList(ffdcIgnore);
         Ffdc.set(new FfdcProvider());
         nl = System.getProperty("line.separator");
         nnn = 0;
      } else {
         String msg = nls.getString("BUILDLEVELS_NOT_SAME_CWSJE0002E");
         traceRecord(msg);
         throw new RuntimeException(msg);
      }
   }
}