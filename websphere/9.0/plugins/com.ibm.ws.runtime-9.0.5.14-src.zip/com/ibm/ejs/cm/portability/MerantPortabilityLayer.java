package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.CMProperties;
import com.ibm.ejs.cm.CMPropertiesImpl;
import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.cm.cache.CachedStatement;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Properties;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;
import javax.sql.XAConnection;
import javax.sql.XADataSource;

public class MerantPortabilityLayer extends PortabilityLayerImpl {
	private static final int NUM_SUPPORTED_MERANT_BACKENDS = 3;
	private static final int GENERIC_BACKEND = 0;
	private static final int SQLSERVER_BACKEND = 1;
	private static final int ORACLE_BACKEND = 2;
	private static MerantPortabilityLayer[] instanceArray = new MerantPortabilityLayer[3];
	protected PortabilityLayer backendPortabilityLayer = null;
	private static final TraceComponent tc = Tr.register(MerantPortabilityLayer.class);

	protected MerantPortabilityLayer(PortabilityLayer pbl) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", pbl);
		}

		this.backendPortabilityLayer = pbl;
		this.errorMap.put(new Integer(2251), StaleConnectionException.class);
		this.errorMap.put(new Integer(2306), StaleConnectionException.class);
		this.errorMap.put(new Integer(2310), StaleConnectionException.class);
		this.errorMap.put(new Integer(2311), StaleConnectionException.class);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public SQLException translateException(SQLException e, Hashtable customMap) {
		String errorMessage = e.getMessage();
		int index = errorMessage.indexOf("]");
		if (index != -1 && errorMessage.charAt(index + 1) == '[') {
			index = errorMessage.indexOf("]", index + 2);
			if (errorMessage.charAt(index + 1) == '[') {
				return this.backendPortabilityLayer.translateException(e, customMap);
			}
		}

		return super.translateException(e, customMap);
	}

	public void createTable(Connection connection, String schema, String name, String sql) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTable", new Object[]{connection, schema, name, sql});
		}

		this.backendPortabilityLayer.createTable(connection, schema, name, sql);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTable");
		}

	}

	public void createTable(Connection connection, String schema, String sql) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTable", new Object[]{connection, schema, sql});
		}

		this.backendPortabilityLayer.createTable(connection, schema, sql);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTable");
		}

	}

	public void createTableForPersister(Connection connection, String schema, String name, String sql)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTableForPersister", new Object[]{connection, schema, sql});
		}

		this.backendPortabilityLayer.createTableForPersister(connection, schema, name, sql);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTableForPersister");
		}

	}

	public String addRowLockHint(String sql) {
		return this.backendPortabilityLayer.addRowLockHint(sql);
	}

	public boolean supportsRowLockHint() {
		return this.backendPortabilityLayer.supportsRowLockHint();
	}

	public void setDate(PreparedStatement ps, int parameterIndex, Date date, Calendar cal) throws SQLException {
		this.backendPortabilityLayer.setDate(ps, parameterIndex, date, cal);
	}

	public void setDate(PreparedStatement ps, int parameterIndex, Date date) throws SQLException {
		this.backendPortabilityLayer.setDate(ps, parameterIndex, date);
	}

	public void setTime(PreparedStatement ps, int parameterIndex, Time time, Calendar cal) throws SQLException {
		this.backendPortabilityLayer.setTime(ps, parameterIndex, time, cal);
	}

	public void setTime(PreparedStatement ps, int parameterIndex, Time time) throws SQLException {
		this.backendPortabilityLayer.setTime(ps, parameterIndex, time);
	}

	public Date getDate(ResultSet rs, int columnIndex, Calendar cal) throws SQLException {
		return this.backendPortabilityLayer.getDate(rs, columnIndex, cal);
	}

	public Date getDate(ResultSet rs, String columnName, Calendar cal) throws SQLException {
		return this.backendPortabilityLayer.getDate(rs, columnName, cal);
	}

	public Date getDate(ResultSet rs, int columnIndex) throws SQLException {
		return this.backendPortabilityLayer.getDate(rs, columnIndex);
	}

	public Date getDate(ResultSet rs, String columnName) throws SQLException {
		return this.backendPortabilityLayer.getDate(rs, columnName);
	}

	public Time getTime(ResultSet rs, int columnIndex, Calendar cal) throws SQLException {
		return this.backendPortabilityLayer.getTime(rs, columnIndex, cal);
	}

	public Time getTime(ResultSet rs, String columnName, Calendar cal) throws SQLException {
		return this.backendPortabilityLayer.getTime(rs, columnName, cal);
	}

	public Time getTime(ResultSet rs, int columnIndex) throws SQLException {
		return this.backendPortabilityLayer.getTime(rs, columnIndex);
	}

	public Time getTime(ResultSet rs, String columnName) throws SQLException {
		return this.backendPortabilityLayer.getTime(rs, columnName);
	}

	public String scanSQL(String sql) {
		return this.backendPortabilityLayer.scanSQL(sql);
	}

	public String processSQL(String sqlString, int isolevel, boolean addForUpdate, boolean addextendedforUpdateSyntax) {
		return this.backendPortabilityLayer.processSQL(sqlString, isolevel, addForUpdate, addextendedforUpdateSyntax);
	}

	public String getColumnTypeSpec(int type) {
		return this.backendPortabilityLayer.getColumnTypeSpec(type);
	}

	public String getNamedColumnSpec(int id) {
		return this.backendPortabilityLayer.getNamedColumnSpec(id);
	}

	public void setTransactionIsolation(Connection connection, int isolationLevel) throws SQLException {
		this.backendPortabilityLayer.setTransactionIsolation(connection, isolationLevel);
	}

	public ConnectionPoolDataSource getDataSource(DataSourceProperties dsProps) throws SQLException {
		return this.backendPortabilityLayer.getDataSource(dsProps);
	}

	public XADataSource getXADataSource(DataSourceProperties dsProps) throws SQLException {
		return this.backendPortabilityLayer.getXADataSource(dsProps);
	}

	public Properties getDefaultDataSourceProps() {
		return this.backendPortabilityLayer.getDefaultDataSourceProps();
	}

	public boolean supportsSchema() {
		return this.backendPortabilityLayer.supportsSchema();
	}

	public void setHugeStringForPreparedStatement(HugeString bigstr, PreparedStatement ps, int index)
			throws SQLException {
		this.backendPortabilityLayer.setHugeStringForPreparedStatement(bigstr, ps, index);
	}

	public boolean checkCMPStoreOperation(String beanId, Connection c, boolean loadedForUpdate) throws SQLException {
		return this.backendPortabilityLayer.checkCMPStoreOperation(beanId, c, loadedForUpdate);
	}

	public void configureConnection(Connection conn, CMPropertiesImpl props) throws SQLException {
		unlockJDBCDriver(conn, props.getDataSourceClassName());
		this.backendPortabilityLayer.configureConnection(conn, props);
	}

	public void configurePooledConnection(PooledConnection conn, CMProperties props) throws SQLException {
		this.backendPortabilityLayer.configurePooledConnection(conn, props);
	}

	public void configureXAConnection(XAConnection conn, CMProperties props) throws SQLException {
		this.backendPortabilityLayer.configureXAConnection(conn, props);
	}

	public static void unlockJDBCDriver(Connection con, String dsClassName) throws SQLException {
	}

	public PortabilityLayer getBackendPortabilityLayer() {
		return this.backendPortabilityLayer;
	}

	static PortabilityLayer getPortabilityLayer(Connection conn) throws SQLException {
		DatabaseMetaData metaData = conn.getMetaData();
		if (metaData != null) {
			String productName = metaData.getDatabaseProductName();
			if (productName == null) {
				return getInstance(0);
			}

			if (productName.equals("Oracle")) {
				return getInstance(2);
			}

			if (productName.equals("Microsoft SQL Server")) {
				return getInstance(1);
			}
		}

		return getInstance(0);
	}

	private static PortabilityLayer getInstance(int backend) throws SQLException {
		if (instanceArray[backend] == null) {
			switch (backend) {
				case 1 :
					instanceArray[backend] = new MerantPortabilityLayer(MSSQLPortabilityLayer.getInstance());
					break;
				case 2 :
					instanceArray[backend] = new MerantPortabilityLayer(OraclePortabilityLayer.getInstance());
					break;
				default :
					instanceArray[backend] = new MerantPortabilityLayer(GenericPortabilityLayer.getInstance());
			}
		}

		return instanceArray[backend];
	}

	public void resetStatement(CachedStatement statement) throws SQLException {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "resetStatement no-op");
		}

	}
}