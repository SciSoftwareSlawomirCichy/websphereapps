package com.ibm.ejs.container.drs.ws390;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.wsspi.drs.DRSBootstrap;
import com.ibm.wsspi.drs.DRSBootstrapMsg;

public class SfDRSControllerBootstrapImpl implements DRSBootstrap {
	private static TraceComponent tc = Tr.register(SfDRSControllerBootstrapImpl.class, "EJBDRSCache",
			"com.ibm.ejs.container.container");
	private SfDRSControllerInstanceImpl xddci = null;

	public SfDRSControllerBootstrapImpl(SfDRSControllerInstanceImpl ddci) {
		String methodName = "SfDRSControllerBootstrapImpl: - constructor";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerBootstrapImpl: - constructor");
		}

		this.xddci = ddci;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerBootstrapImpl: - constructor");
		}

	}

	public void bootstrapRequest(DRSBootstrapMsg dbm) {
		String methodName = "SfDRSControllerBootstrapImpl.bootstrapRequest: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerBootstrapImpl.bootstrapRequest: Entry");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerBootstrapImpl.bootstrapRequest: Exit");
		}

	}

	public void handleBootstrapRequest(DRSBootstrapMsg dbm) {
		String methodName = "SfDRSControllerBootstrapImpl.handleBootstrapRequest: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerBootstrapImpl.handleBootstrapRequest: Entry");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerBootstrapImpl.handleBootstrapRequest: Exit");
		}

	}

	public void bootstrapResponse(DRSBootstrapMsg dbm) {
		String methodName = "SfDRSControllerBootstrapImpl.handleBootstrapResponse: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerBootstrapImpl.handleBootstrapResponse: Entry");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerBootstrapImpl.handleBootstrapResponse: Exit");
		}

	}
}