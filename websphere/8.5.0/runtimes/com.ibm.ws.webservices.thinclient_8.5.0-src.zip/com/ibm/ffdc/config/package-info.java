package com.ibm.ffdc.config;

interface package-info {
}