package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.math.IntMath;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public final class Collections2 {
	private Collections2() {
	}

	public static <E> Collection<E> filter(Collection<E> unfiltered, Predicate<? super E> predicate) {
		return unfiltered instanceof FilteredCollection
				? ((FilteredCollection) unfiltered).createCombined(predicate)
				: new FilteredCollection((Collection) Preconditions.checkNotNull(unfiltered),
						(Predicate) Preconditions.checkNotNull(predicate));
	}

	static boolean safeContains(Collection<?> collection, @NullableDecl Object object) {
		Preconditions.checkNotNull(collection);

		try {
			return collection.contains(object);
		} catch (NullPointerException | ClassCastException var3) {
			return false;
		}
	}

	static boolean safeRemove(Collection<?> collection, @NullableDecl Object object) {
		Preconditions.checkNotNull(collection);

		try {
			return collection.remove(object);
		} catch (NullPointerException | ClassCastException var3) {
			return false;
		}
	}

	public static <F, T> Collection<T> transform(Collection<F> fromCollection, Function<? super F, T> function) {
		return new TransformedCollection(fromCollection, function);
	}

	static boolean containsAllImpl(Collection<?> self, Collection<?> c) {
		Iterator var2 = c.iterator();

		Object o;
		do {
			if (!var2.hasNext()) {
				return true;
			}

			o = var2.next();
		} while (self.contains(o));

		return false;
	}

	static String toStringImpl(Collection<?> collection) {
		StringBuilder sb = newStringBuilderForCollection(collection.size()).append('[');
		boolean first = true;
		Iterator var3 = collection.iterator();

		while (var3.hasNext()) {
			Object o = var3.next();
			if (!first) {
				sb.append(", ");
			}

			first = false;
			if (o == collection) {
				sb.append("(this Collection)");
			} else {
				sb.append(o);
			}
		}

		return sb.append(']').toString();
	}

	static StringBuilder newStringBuilderForCollection(int size) {
		CollectPreconditions.checkNonnegative(size, "size");
		return new StringBuilder((int) Math.min((long) size * 8L, 1073741824L));
	}

	static <T> Collection<T> cast(Iterable<T> iterable) {
		return (Collection) iterable;
	}

	@Beta
	public static <E extends Comparable<? super E>> Collection<List<E>> orderedPermutations(Iterable<E> elements) {
		return orderedPermutations(elements, Ordering.natural());
	}

	@Beta
	public static <E> Collection<List<E>> orderedPermutations(Iterable<E> elements, Comparator<? super E> comparator) {
		return new OrderedPermutationCollection(elements, comparator);
	}

	@Beta
	public static <E> Collection<List<E>> permutations(Collection<E> elements) {
		return new PermutationCollection(ImmutableList.copyOf(elements));
	}

	private static boolean isPermutation(List<?> first, List<?> second) {
		if (first.size() != second.size()) {
			return false;
		} else {
			ObjectCountHashMap<?> firstCounts = counts(first);
			ObjectCountHashMap<?> secondCounts = counts(second);
			if (first.size() != second.size()) {
				return false;
			} else {
				for (int i = 0; i < first.size(); ++i) {
					if (firstCounts.getValue(i) != secondCounts.get(firstCounts.getKey(i))) {
						return false;
					}
				}

				return true;
			}
		}
	}

	private static <E> ObjectCountHashMap<E> counts(Collection<E> collection) {
		ObjectCountHashMap<E> map = new ObjectCountHashMap();
		Iterator var2 = collection.iterator();

		while (var2.hasNext()) {
			E e = var2.next();
			map.put(e, map.get(e) + 1);
		}

		return map;
	}

	private static class PermutationIterator<E> extends AbstractIterator<List<E>> {
		final List<E> list;
		final int[] c;
		final int[] o;
		int j;

		PermutationIterator(List<E> list) {
			this.list = new ArrayList(list);
			int n = list.size();
			this.c = new int[n];
			this.o = new int[n];
			Arrays.fill(this.c, 0);
			Arrays.fill(this.o, 1);
			this.j = Integer.MAX_VALUE;
		}

		protected List<E> computeNext() {
			if (this.j <= 0) {
				return (List) this.endOfData();
			} else {
				ImmutableList<E> next = ImmutableList.copyOf(this.list);
				this.calculateNextPermutation();
				return next;
			}
		}

		void calculateNextPermutation() {
			this.j = this.list.size() - 1;
			int s = 0;
			if (this.j != -1) {
				while (true) {
					while (true) {
						int q = this.c[this.j] + this.o[this.j];
						if (q >= 0) {
							if (q != this.j + 1) {
								Collections.swap(this.list, this.j - this.c[this.j] + s, this.j - q + s);
								this.c[this.j] = q;
								return;
							}

							if (this.j == 0) {
								return;
							}

							++s;
							this.switchDirection();
						} else {
							this.switchDirection();
						}
					}
				}
			}
		}

		void switchDirection() {
			this.o[this.j] = -this.o[this.j];
			--this.j;
		}
	}

	private static final class PermutationCollection<E> extends AbstractCollection<List<E>> {
		final ImmutableList<E> inputList;

		PermutationCollection(ImmutableList<E> input) {
			this.inputList = input;
		}

		public int size() {
			return IntMath.factorial(this.inputList.size());
		}

		public boolean isEmpty() {
			return false;
		}

		public Iterator<List<E>> iterator() {
			return new PermutationIterator(this.inputList);
		}

		public boolean contains(@NullableDecl Object obj) {
			if (obj instanceof List) {
				List<?> list = (List) obj;
				return Collections2.isPermutation(this.inputList, list);
			} else {
				return false;
			}
		}

		public String toString() {
			return "permutations(" + this.inputList + ")";
		}
	}

	private static final class OrderedPermutationIterator<E> extends AbstractIterator<List<E>> {
		@NullableDecl
		List<E> nextPermutation;
		final Comparator<? super E> comparator;

		OrderedPermutationIterator(List<E> list, Comparator<? super E> comparator) {
			this.nextPermutation = Lists.newArrayList(list);
			this.comparator = comparator;
		}

		protected List<E> computeNext() {
			if (this.nextPermutation == null) {
				return (List) this.endOfData();
			} else {
				ImmutableList<E> next = ImmutableList.copyOf(this.nextPermutation);
				this.calculateNextPermutation();
				return next;
			}
		}

		void calculateNextPermutation() {
			int j = this.findNextJ();
			if (j == -1) {
				this.nextPermutation = null;
			} else {
				int l = this.findNextL(j);
				Collections.swap(this.nextPermutation, j, l);
				int n = this.nextPermutation.size();
				Collections.reverse(this.nextPermutation.subList(j + 1, n));
			}
		}

		int findNextJ() {
			for (int k = this.nextPermutation.size() - 2; k >= 0; --k) {
				if (this.comparator.compare(this.nextPermutation.get(k), this.nextPermutation.get(k + 1)) < 0) {
					return k;
				}
			}

			return -1;
		}

		int findNextL(int j) {
			E ak = this.nextPermutation.get(j);

			for (int l = this.nextPermutation.size() - 1; l > j; --l) {
				if (this.comparator.compare(ak, this.nextPermutation.get(l)) < 0) {
					return l;
				}
			}

			throw new AssertionError("this statement should be unreachable");
		}
	}

	private static final class OrderedPermutationCollection<E> extends AbstractCollection<List<E>> {
		final ImmutableList<E> inputList;
		final Comparator<? super E> comparator;
		final int size;

		OrderedPermutationCollection(Iterable<E> input, Comparator<? super E> comparator) {
			this.inputList = ImmutableList.sortedCopyOf(comparator, input);
			this.comparator = comparator;
			this.size = calculateSize(this.inputList, comparator);
		}

		private static <E> int calculateSize(List<E> sortedInputList, Comparator<? super E> comparator) {
			int permutations = 1;
			int n = 1;

			int r;
			for (r = 1; n < sortedInputList.size(); ++r) {
				int comparison = comparator.compare(sortedInputList.get(n - 1), sortedInputList.get(n));
				if (comparison < 0) {
					permutations = IntMath.saturatedMultiply(permutations, IntMath.binomial(n, r));
					r = 0;
					if (permutations == Integer.MAX_VALUE) {
						return Integer.MAX_VALUE;
					}
				}

				++n;
			}

			return IntMath.saturatedMultiply(permutations, IntMath.binomial(n, r));
		}

		public int size() {
			return this.size;
		}

		public boolean isEmpty() {
			return false;
		}

		public Iterator<List<E>> iterator() {
			return new OrderedPermutationIterator(this.inputList, this.comparator);
		}

		public boolean contains(@NullableDecl Object obj) {
			if (obj instanceof List) {
				List<?> list = (List) obj;
				return Collections2.isPermutation(this.inputList, list);
			} else {
				return false;
			}
		}

		public String toString() {
			return "orderedPermutationCollection(" + this.inputList + ")";
		}
	}

	static class TransformedCollection<F, T> extends AbstractCollection<T> {
		final Collection<F> fromCollection;
		final Function<? super F, ? extends T> function;

		TransformedCollection(Collection<F> fromCollection, Function<? super F, ? extends T> function) {
			this.fromCollection = (Collection) Preconditions.checkNotNull(fromCollection);
			this.function = (Function) Preconditions.checkNotNull(function);
		}

		public void clear() {
			this.fromCollection.clear();
		}

		public boolean isEmpty() {
			return this.fromCollection.isEmpty();
		}

		public Iterator<T> iterator() {
			return Iterators.transform(this.fromCollection.iterator(), this.function);
		}

		public int size() {
			return this.fromCollection.size();
		}
	}

	static class FilteredCollection<E> extends AbstractCollection<E> {
		final Collection<E> unfiltered;
		final Predicate<? super E> predicate;

		FilteredCollection(Collection<E> unfiltered, Predicate<? super E> predicate) {
			this.unfiltered = unfiltered;
			this.predicate = predicate;
		}

		FilteredCollection<E> createCombined(Predicate<? super E> newPredicate) {
			return new FilteredCollection(this.unfiltered, Predicates.and(this.predicate, newPredicate));
		}

		public boolean add(E element) {
			Preconditions.checkArgument(this.predicate.apply(element));
			return this.unfiltered.add(element);
		}

		public boolean addAll(Collection<? extends E> collection) {
			Iterator var2 = collection.iterator();

			while (var2.hasNext()) {
				E element = var2.next();
				Preconditions.checkArgument(this.predicate.apply(element));
			}

			return this.unfiltered.addAll(collection);
		}

		public void clear() {
			Iterables.removeIf(this.unfiltered, this.predicate);
		}

		public boolean contains(@NullableDecl Object element) {
			return Collections2.safeContains(this.unfiltered, element) ? this.predicate.apply(element) : false;
		}

		public boolean containsAll(Collection<?> collection) {
			return Collections2.containsAllImpl(this, collection);
		}

		public boolean isEmpty() {
			return !Iterables.any(this.unfiltered, this.predicate);
		}

		public Iterator<E> iterator() {
			return Iterators.filter(this.unfiltered.iterator(), this.predicate);
		}

		public boolean remove(Object element) {
			return this.contains(element) && this.unfiltered.remove(element);
		}

		public boolean removeAll(Collection<?> collection) {
			boolean changed = false;
			Iterator<E> itr = this.unfiltered.iterator();

			while (itr.hasNext()) {
				E e = itr.next();
				if (this.predicate.apply(e) && collection.contains(e)) {
					itr.remove();
					changed = true;
				}
			}

			return changed;
		}

		public boolean retainAll(Collection<?> collection) {
			boolean changed = false;
			Iterator<E> itr = this.unfiltered.iterator();

			while (itr.hasNext()) {
				E e = itr.next();
				if (this.predicate.apply(e) && !collection.contains(e)) {
					itr.remove();
					changed = true;
				}
			}

			return changed;
		}

		public int size() {
			int size = 0;
			Iterator var2 = this.unfiltered.iterator();

			while (var2.hasNext()) {
				E e = var2.next();
				if (this.predicate.apply(e)) {
					++size;
				}
			}

			return size;
		}

		public Object[] toArray() {
			return Lists.newArrayList(this.iterator()).toArray();
		}

		public <T> T[] toArray(T[] array) {
			return Lists.newArrayList(this.iterator()).toArray(array);
		}
	}
}