package com.ibm.icu.text;

import com.ibm.icu.impl.UCharacterName;
import com.ibm.icu.impl.UCharacterProperty;
import com.ibm.icu.impl.Utility;
import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.NameUnicodeTransliterator.1;
import com.ibm.icu.text.Transliterator.Position;

class NameUnicodeTransliterator extends Transliterator {
	char openDelimiter;
	char closeDelimiter;
	static final String _ID = "Name-Any";
	static final String OPEN_PAT = "\\N~{~";
	static final char OPEN_DELIM = '\\';
	static final char CLOSE_DELIM = '}';
	static final char SPACE = ' ';

	static void register() {
      Transliterator.registerFactory("Name-Any", new 1());
   }

	public NameUnicodeTransliterator(UnicodeFilter filter) {
		super("Name-Any", filter);
	}

	protected void handleTransliterate(Replaceable text, Position offsets, boolean isIncremental) {
		int maxLen = UCharacterName.INSTANCE.getMaxCharNameLength() + 1;
		StringBuffer name = new StringBuffer(maxLen);
		UnicodeSet legal = new UnicodeSet();
		UCharacterName.INSTANCE.getCharNameCharacters(legal);
		int cursor = offsets.start;
		int limit = offsets.limit;
		int mode = 0;
		int openPos = -1;

		while (true) {
			while (cursor < limit) {
				int c = text.char32At(cursor);
				int len;
				switch (mode) {
					case 0 :
						if (c == 92) {
							openPos = cursor;
							len = Utility.parsePattern("\\N~{~", text, cursor, limit);
							if (len >= 0 && len < limit) {
								mode = 1;
								name.setLength(0);
								cursor = len;
								continue;
							}
						}
						break;
					case 1 :
						if (UCharacterProperty.isRuleWhiteSpace(c)) {
							if (name.length() > 0 && name.charAt(name.length() - 1) != ' ') {
								name.append(' ');
								if (name.length() > maxLen) {
									mode = 0;
								}
							}
						} else {
							if (c == 125) {
								len = name.length();
								if (len > 0 && name.charAt(len - 1) == ' ') {
									--len;
									name.setLength(len);
								}

								c = UCharacter.getCharFromExtendedName(name.toString());
								if (c != -1) {
									++cursor;
									String str = UTF16.valueOf(c);
									text.replace(openPos, cursor, str);
									int delta = cursor - openPos - str.length();
									cursor -= delta;
									limit -= delta;
								}

								mode = 0;
								openPos = -1;
								continue;
							}

							if (legal.contains(c)) {
								UTF16.append(name, c);
								if (name.length() >= maxLen) {
									mode = 0;
								}
							} else {
								--cursor;
								mode = 0;
							}
						}
				}

				cursor += UTF16.getCharCount(c);
			}

			offsets.contextLimit += limit - offsets.limit;
			offsets.limit = limit;
			offsets.start = isIncremental && openPos >= 0 ? openPos : cursor;
			return;
		}
	}
}