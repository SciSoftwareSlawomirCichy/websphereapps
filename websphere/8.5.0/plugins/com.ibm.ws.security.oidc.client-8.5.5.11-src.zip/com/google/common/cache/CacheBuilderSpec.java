package com.google.common.cache;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.base.Splitter;
import com.google.common.cache.CacheBuilderSpec.1;
import com.google.common.cache.CacheBuilderSpec.AccessDurationParser;
import com.google.common.cache.CacheBuilderSpec.ConcurrencyLevelParser;
import com.google.common.cache.CacheBuilderSpec.InitialCapacityParser;
import com.google.common.cache.CacheBuilderSpec.KeyStrengthParser;
import com.google.common.cache.CacheBuilderSpec.MaximumSizeParser;
import com.google.common.cache.CacheBuilderSpec.MaximumWeightParser;
import com.google.common.cache.CacheBuilderSpec.RefreshDurationParser;
import com.google.common.cache.CacheBuilderSpec.ValueParser;
import com.google.common.cache.CacheBuilderSpec.ValueStrengthParser;
import com.google.common.cache.CacheBuilderSpec.WriteDurationParser;
import com.google.common.cache.LocalCache.Strength;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

@Beta
public final class CacheBuilderSpec {
	private static final Splitter KEYS_SPLITTER = Splitter.on(',').trimResults();
	private static final Splitter KEY_VALUE_SPLITTER = Splitter.on('=').trimResults();
	private static final ImmutableMap<String, ValueParser> VALUE_PARSERS;
	@VisibleForTesting
	Integer initialCapacity;
	@VisibleForTesting
	Long maximumSize;
	@VisibleForTesting
	Long maximumWeight;
	@VisibleForTesting
	Integer concurrencyLevel;
	@VisibleForTesting
	Strength keyStrength;
	@VisibleForTesting
	Strength valueStrength;
	@VisibleForTesting
	long writeExpirationDuration;
	@VisibleForTesting
	TimeUnit writeExpirationTimeUnit;
	@VisibleForTesting
	long accessExpirationDuration;
	@VisibleForTesting
	TimeUnit accessExpirationTimeUnit;
	@VisibleForTesting
	long refreshDuration;
	@VisibleForTesting
	TimeUnit refreshTimeUnit;
	private final String specification;

	private CacheBuilderSpec(String specification) {
		this.specification = specification;
	}

	public static CacheBuilderSpec parse(String cacheBuilderSpecification) {
		CacheBuilderSpec spec = new CacheBuilderSpec(cacheBuilderSpecification);
		if (!cacheBuilderSpecification.isEmpty()) {
			Iterator i$ = KEYS_SPLITTER.split(cacheBuilderSpecification).iterator();

			while (i$.hasNext()) {
				String keyValuePair = (String) i$.next();
				List<String> keyAndValue = ImmutableList.copyOf(KEY_VALUE_SPLITTER.split(keyValuePair));
				Preconditions.checkArgument(!keyAndValue.isEmpty(), "blank key-value pair");
				Preconditions.checkArgument(keyAndValue.size() <= 2, "key-value pair %s with more than one equals sign",
						new Object[]{keyValuePair});
				String key = (String) keyAndValue.get(0);
				ValueParser valueParser = (ValueParser) VALUE_PARSERS.get(key);
				Preconditions.checkArgument(valueParser != null, "unknown key %s", new Object[]{key});
				String value = keyAndValue.size() == 1 ? null : (String) keyAndValue.get(1);
				valueParser.parse(spec, key, value);
			}
		}

		return spec;
	}

	public static CacheBuilderSpec disableCaching() {
		return parse("maximumSize=0");
	}

	CacheBuilder<Object, Object> toCacheBuilder() {
      CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder();
      if (this.initialCapacity != null) {
         builder.initialCapacity(this.initialCapacity);
      }

      if (this.maximumSize != null) {
         builder.maximumSize(this.maximumSize);
      }

      if (this.maximumWeight != null) {
         builder.maximumWeight(this.maximumWeight);
      }

      if (this.concurrencyLevel != null) {
         builder.concurrencyLevel(this.concurrencyLevel);
      }

      if (this.keyStrength != null) {
         switch(1.$SwitchMap$com$google$common$cache$LocalCache$Strength[this.keyStrength.ordinal()]) {
         case 1:
            builder.weakKeys();
            break;
         default:
            throw new AssertionError();
         }
      }

      if (this.valueStrength != null) {
         switch(1.$SwitchMap$com$google$common$cache$LocalCache$Strength[this.valueStrength.ordinal()]) {
         case 1:
            builder.weakValues();
            break;
         case 2:
            builder.softValues();
            break;
         default:
            throw new AssertionError();
         }
      }

      if (this.writeExpirationTimeUnit != null) {
         builder.expireAfterWrite(this.writeExpirationDuration, this.writeExpirationTimeUnit);
      }

      if (this.accessExpirationTimeUnit != null) {
         builder.expireAfterAccess(this.accessExpirationDuration, this.accessExpirationTimeUnit);
      }

      if (this.refreshTimeUnit != null) {
         builder.refreshAfterWrite(this.refreshDuration, this.refreshTimeUnit);
      }

      return builder;
   }

	public String toParsableString() {
		return this.specification;
	}

	public String toString() {
		return Objects.toStringHelper(this).addValue(this.toParsableString()).toString();
	}

	public int hashCode() {
		return Objects.hashCode(new Object[]{this.initialCapacity, this.maximumSize, this.maximumWeight,
				this.concurrencyLevel, this.keyStrength, this.valueStrength,
				durationInNanos(this.writeExpirationDuration, this.writeExpirationTimeUnit),
				durationInNanos(this.accessExpirationDuration, this.accessExpirationTimeUnit),
				durationInNanos(this.refreshDuration, this.refreshTimeUnit)});
	}

	public boolean equals(@Nullable Object obj) {
		if (this == obj) {
			return true;
		} else if (!(obj instanceof CacheBuilderSpec)) {
			return false;
		} else {
			CacheBuilderSpec that = (CacheBuilderSpec) obj;
			return Objects.equal(this.initialCapacity, that.initialCapacity)
					&& Objects.equal(this.maximumSize, that.maximumSize)
					&& Objects.equal(this.maximumWeight, that.maximumWeight)
					&& Objects.equal(this.concurrencyLevel, that.concurrencyLevel)
					&& Objects.equal(this.keyStrength, that.keyStrength)
					&& Objects.equal(this.valueStrength, that.valueStrength)
					&& Objects.equal(durationInNanos(this.writeExpirationDuration, this.writeExpirationTimeUnit),
							durationInNanos(that.writeExpirationDuration, that.writeExpirationTimeUnit))
					&& Objects.equal(durationInNanos(this.accessExpirationDuration, this.accessExpirationTimeUnit),
							durationInNanos(that.accessExpirationDuration, that.accessExpirationTimeUnit))
					&& Objects.equal(durationInNanos(this.refreshDuration, this.refreshTimeUnit),
							durationInNanos(that.refreshDuration, that.refreshTimeUnit));
		}
	}

	@Nullable
	private static Long durationInNanos(long duration, @Nullable TimeUnit unit) {
		return unit == null ? null : unit.toNanos(duration);
	}

	static {
		VALUE_PARSERS = ImmutableMap.builder().put("initialCapacity", new InitialCapacityParser())
				.put("maximumSize", new MaximumSizeParser()).put("maximumWeight", new MaximumWeightParser())
				.put("concurrencyLevel", new ConcurrencyLevelParser())
				.put("weakKeys", new KeyStrengthParser(Strength.WEAK))
				.put("softValues", new ValueStrengthParser(Strength.SOFT))
				.put("weakValues", new ValueStrengthParser(Strength.WEAK))
				.put("expireAfterAccess", new AccessDurationParser()).put("expireAfterWrite", new WriteDurationParser())
				.put("refreshAfterWrite", new RefreshDurationParser())
				.put("refreshInterval", new RefreshDurationParser()).build();
	}
}