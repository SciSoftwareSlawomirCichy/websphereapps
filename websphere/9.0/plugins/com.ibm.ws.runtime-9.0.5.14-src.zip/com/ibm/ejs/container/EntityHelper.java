package com.ibm.ejs.container;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Enumeration;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;

public interface EntityHelper {
	EJBObject getBean(EJSHome var1, Object var2) throws RemoteException;

	EJBObject getBean(EJSHome var1, String var2, Object var3, Object var4) throws FinderException, RemoteException;

	EJBLocalObject getBean_Local(EJSHome var1, Object var2) throws RemoteException;

	Enumeration getCMP20Enumeration(EJSHome var1, Enumeration var2) throws FinderException, RemoteException;

	Enumeration getCMP20Enumeration_Local(EJSHome var1, Enumeration var2) throws FinderException, RemoteException;

	Collection getCMP20Collection(EJSHome var1, Collection var2) throws FinderException, RemoteException;

	Collection getCMP20Collection_Local(EJSHome var1, Collection var2) throws FinderException, RemoteException;

	EJSWrapperCommon activateBean_Common(EJSHome var1, Object var2, boolean var3)
			throws FinderException, RemoteException;

	EntityBeanO getFindByPrimaryKeyEntityBeanO(EJSHome var1) throws RemoteException;

	EntityBeanO getFinderEntityBeanO(EJSHome var1) throws RemoteException;

	void discardFinderEntityBeanO(EJSHome var1, EntityBeanO var2) throws RemoteException;

	void releaseFinderEntityBeanO(EJSHome var1, EntityBeanO var2) throws RemoteException;

	BeanManagedBeanO getFinderBeanO(EJSHome var1) throws RemoteException;

	void releaseFinderBeanO(EJSHome var1, BeanManagedBeanO var2) throws RemoteException;

	EntityBeanO getHomeMethodEntityBeanO(EJSHome var1) throws RemoteException;

	void releaseHomeMethodEntityBeanO(EJSHome var1, EntityBeanO var2) throws RemoteException;

	BeanId remove(EJSHome var1, Object var2) throws RemoteException, RemoveException, FinderException;

	EJBMethodInfoImpl getPMMethodInfo(EJSDeployedSupport var1, EJSWrapperBase var2, int var3, String var4);

	boolean hasMethodLevelAccessIntentSet(EJSHome var1);
}