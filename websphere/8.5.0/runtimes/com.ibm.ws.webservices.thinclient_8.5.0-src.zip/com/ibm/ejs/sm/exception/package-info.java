package com.ibm.ejs.sm.exception;

interface package-info {
}