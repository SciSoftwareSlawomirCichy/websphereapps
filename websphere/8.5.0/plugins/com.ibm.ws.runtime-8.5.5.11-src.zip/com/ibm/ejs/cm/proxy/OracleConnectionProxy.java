package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public final class OracleConnectionProxy extends ConnectionProxy {
	private static final TraceComponent tc = Tr.register(OracleConnectionProxy.class);

	public OracleConnectionProxy(ConnectO connection) {
		super(connection);
	}

	public final Statement createStatement(int type, int concurrency) throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				OracleStatementProxy var6;
				try {
					this.__preInvoke();
					Statement cs = this.getConnection().createStatement(type, concurrency);
					if (cs == null) {
						var6 = null;
						return var6;
					}

					var6 = new OracleStatementProxy(this, cs);
				} catch (SQLException var12) {
					x = var12;
					throw this.translateException(var12);
				} finally {
					this.__postInvoke(x);
				}

				return var6;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public final PreparedStatement prepareStatement(String sql, int type, int concurrency) throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				OraclePreparedStatementProxy var7;
				try {
					this.__preInvoke();
					PreparedStatement ps = this.getConnection().prepareStatement(sql, type, concurrency);
					if (ps == null) {
						var7 = null;
						return var7;
					}

					var7 = new OraclePreparedStatementProxy(this, ps);
				} catch (SQLException var13) {
					x = var13;
					throw this.translateException(var13);
				} finally {
					this.__postInvoke(x);
				}

				return var7;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public final CallableStatement prepareCall(String sql, int type, int concurrency) throws SQLException {
		SQLException x = null;
		if (this.isClosed()) {
			throw new StaleConnectionException(this.getClass() + " is closed");
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Preparing call for " + sql);
			}

			synchronized (this.getLockObject()) {
				OracleCallableStatementProxy var7;
				try {
					this.__preInvoke();
					CallableStatement cs = this.getConnection().prepareCall(sql, type, concurrency);
					if (cs != null) {
						var7 = new OracleCallableStatementProxy(this, cs);
						return var7;
					}

					var7 = null;
				} catch (SQLException var13) {
					x = var13;
					throw this.translateException(var13);
				} finally {
					this.__postInvoke(x);
				}

				return var7;
			}
		}
	}

	public final Statement createStatement() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				OracleStatementProxy var4;
				try {
					this.__preInvoke();
					Statement cs = this.getConnection().createStatement();
					if (cs == null) {
						var4 = null;
						return var4;
					}

					var4 = new OracleStatementProxy(this, cs);
				} catch (SQLException var10) {
					x = var10;
					throw this.translateException(var10);
				} finally {
					this.__postInvoke(x);
				}

				return var4;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public final PreparedStatement prepareStatement(String sql) throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				OraclePreparedStatementProxy var5;
				try {
					this.__preInvoke();
					PreparedStatement ps = this.getConnection().prepareStatement(sql);
					if (ps == null) {
						var5 = null;
						return var5;
					}

					var5 = new OraclePreparedStatementProxy(this, ps);
				} catch (SQLException var11) {
					x = var11;
					throw this.translateException(var11);
				} finally {
					this.__postInvoke(x);
				}

				return var5;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public final CallableStatement prepareCall(String sql) throws SQLException {
		SQLException x = null;
		if (this.isClosed()) {
			throw new StaleConnectionException(this.getClass() + " is closed");
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Preparing call for " + sql);
			}

			synchronized (this.getLockObject()) {
				OracleCallableStatementProxy var5;
				try {
					this.__preInvoke();
					CallableStatement pc = this.getConnection().prepareCall(sql);
					if (pc != null) {
						var5 = new OracleCallableStatementProxy(this, pc);
						return var5;
					}

					var5 = null;
				} catch (SQLException var11) {
					x = var11;
					throw this.translateException(var11);
				} finally {
					this.__postInvoke(x);
				}

				return var5;
			}
		}
	}
}