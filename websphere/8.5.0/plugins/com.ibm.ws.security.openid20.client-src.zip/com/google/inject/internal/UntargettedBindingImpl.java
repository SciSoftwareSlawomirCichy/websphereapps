package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.internal.UntargettedBindingImpl.1;
import com.google.inject.spi.BindingTargetVisitor;
import com.google.inject.spi.UntargettedBinding;

public class UntargettedBindingImpl<T> extends BindingImpl<T> implements UntargettedBinding<T> {
	public UntargettedBindingImpl(Injector injector, Key<T> key, Object source) {
      super(injector, key, source, new 1(), Scoping.UNSCOPED);
   }

	public UntargettedBindingImpl(Object source, Key<T> key, Scoping scoping) {
		super(source, key, scoping);
	}

	public <V> V acceptTargetVisitor(BindingTargetVisitor<? super T, V> visitor) {
		return visitor.visit(this);
	}

	public BindingImpl<T> withScoping(Scoping scoping) {
		return new UntargettedBindingImpl(this.getSource(), this.getKey(), scoping);
	}

	public BindingImpl<T> withKey(Key<T> key) {
		return new UntargettedBindingImpl(this.getSource(), key, this.getScoping());
	}

	public void applyTo(Binder binder) {
		this.getScoping().applyTo(binder.withSource(this.getSource()).bind(this.getKey()));
	}

	public String toString() {
		return (new ToStringBuilder(UntargettedBinding.class)).add("key", this.getKey()).add("source", this.getSource())
				.toString();
	}
}