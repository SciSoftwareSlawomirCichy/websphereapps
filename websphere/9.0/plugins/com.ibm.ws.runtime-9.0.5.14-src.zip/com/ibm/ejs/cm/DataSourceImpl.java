package com.ibm.ejs.cm;

import com.ibm.ejs.cm.DataSourceImpl.1;
import com.ibm.ejs.cm.DataSourceImpl.2;
import com.ibm.ejs.cm.DataSourceImpl.3;
import com.ibm.ejs.cm.DataSourceImpl.PrivExAction;
import com.ibm.ejs.cm.pool.ConnectionFactory;
import com.ibm.ejs.cm.pool.ConnectionPool;
import com.ibm.ejs.cm.portability.PortabilityLayerExt;
import com.ibm.ejs.cm.portability.PortableDataSource;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.management.collaborator.DefaultRuntimeCollaborator;
import java.io.PrintWriter;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Set;
import java.util.logging.Logger;
import javax.management.ObjectName;
import javax.management.QueryExp;

public abstract class DataSourceImpl implements PortableDataSource {
	private static final TraceNLS NLS = TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages");
	private DefaultRuntimeCollaborator collab;
	protected transient ConnectionPool source;
	protected final CMPropertiesImpl attrs;
	private static final TraceComponent tc = Tr.register(DataSourceImpl.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");
	private static final TraceComponent tc2 = Tr.register("com.ibm.ejs.cm.MBeans", (String) null,
			"com.ibm.ws.runtime.runtime");

	protected DataSourceImpl(CMProperties _attrs) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", _attrs);
		}

		this.attrs = (CMPropertiesImpl) _attrs;
		this.registerMBean(this.attrs.getMBeanFactoryId(), this.attrs.getMBeanProviderId());
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public String toString() {
		return "WebSphere DataSource:" + this.attrs;
	}

	public final PortabilityLayerExt getPortabilityLayer() throws SQLException {
		return this.getSource().getPortabilityLayer();
	}

	public CMProperties getAttributes() {
		return this.attrs;
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "unwrap(Class<T>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isWrapperFor(Class<?>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Connection getConnection() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getConnection");
		}

		Connection conn = null;
		conn = this.getConnection((String) null, (String) null);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getConnection", conn);
		}

		return conn;
	}

	public Connection getConnection(String user, String password) throws SQLException {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "getConnection", user);
      }

      String userName = user;
      String passWord = password;
      Connection conn = null;

      try {
         boolean tempSet = false;
         if (this.source == null && this.attrs.getUser() == null) {
            this.attrs.setTmpUser(userName);
            this.attrs.setTmpPassword(passWord);
            tempSet = true;
         }

         conn = (Connection)AccessController.doPrivileged(new 1(this, userName, passWord));
         if (tempSet) {
            if (this.attrs.getTmpUser() != null) {
               this.attrs.setTmpUser((String)null);
            }

            if (this.attrs.getTmpPassword() != null) {
               this.attrs.setTmpPassword((String)null);
            }
         }
      } catch (PrivilegedActionException var7) {
         throw (SQLException)var7.getException();
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "getConnection", conn);
      }

      return conn;
   }

	public int getLoginTimeout() throws SQLException {
		return this.getSource().getLoginTimeout();
	}

	public void setLoginTimeout(int seconds) throws SQLException {
		this.getSource().setLoginTimeout(seconds);
	}

	public PrintWriter getLogWriter() throws SQLException {
		return this.getSource().getLogWriter();
	}

	public void setLogWriter(PrintWriter out) throws SQLException {
      PrintWriter localOut = out;

      try {
         AccessController.doPrivileged(new 2(this, localOut));
      } catch (PrivilegedActionException var4) {
         throw (SQLException)var4.getException();
      }
   }

	protected abstract ConnectionFactory createConnectionFactory() throws SQLException;

	public synchronized ConnectionPool getSource() throws SQLException {
      if (this.source == null) {
         ConnectionFactory cf = null;

         try {
            cf = (ConnectionFactory)AccessController.doPrivileged(new 3(this));
         } catch (PrivilegedActionException var3) {
            throw (SQLException)var3.getException();
         }

         this.source = new ConnectionPool(cf, this.attrs, this.attrs.getPassword());
      }

      return this.source;
   }

	protected final synchronized void destroy() {
		if (this.source != null) {
			this.source.destroy();
		}

		this.source = null;
	}

	private Boolean registerMBean(String factoryId, String providerId) {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "registerMBean");
      }

      PrivExAction pae = new PrivExAction(this, (1)null);
      pae.setMBeanID(factoryId);
      pae.setMBeanName(this.attrs.getName());
      String parentName = null;
      String serverName = null;
      if (providerId != null && !providerId.equals("")) {
         try {
            AdminService adminService = AdminServiceFactory.getAdminService();
            if (adminService != null) {
               ObjectName name = new ObjectName("WebSphere:mbeanIdentifier=" + providerId + ",*");
               Set s = adminService.queryNames(name, (QueryExp)null);
               ObjectName providerName = (ObjectName)s.iterator().next();
               parentName = providerName.getKeyProperty("name");
               serverName = providerName.getKeyProperty("Server");
            } else if (tc.isDebugEnabled()) {
               Tr.debug(tc, "No Admin Service available in this process.  If this is a client process, this is expected. The MBean may still be registered, but will be missing the server= and [JDBCProvider]= properties.");
            }
         } catch (Exception var12) {
            FFDCFilter.processException(var12, "com.ibm.ejs.j2c.DataSourceImpl.registerMBean", "%c", this);
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "An exception occurred when trying to obtain the parent MBean for this connection factory");
               Tr.debug(tc, "This is not a terminal failure, however the MBean that will be created for this connection factory will be missing the server= and [JDBCProvider]= properties.");
               Tr.debug(tc, "The parent MBean's identifier is " + providerId);
               Tr.debug(tc, "The exception is ", var12);
            }
         }

         if (parentName != null && !parentName.equals("")) {
            pae.setMBeanParentName(parentName);
         }

         if (serverName != null && !serverName.equals("")) {
            pae.setServer(serverName);
         }
      }

      Boolean success;
      if (factoryId != null && !factoryId.equals("") && providerId != null && !providerId.equals("")) {
         this.collab = new DefaultRuntimeCollaborator(this, factoryId);
         pae.setCollaborator(this.collab);

         try {
            success = (Boolean)AccessController.doPrivileged(pae);
         } catch (PrivilegedActionException var10) {
            FFDCFilter.processException(var10, "com.ibm.ejs.cm.DataSourceImpl.registerMBean", "%c", this);
            success = new Boolean(false);
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Error registering MBean with Id " + factoryId);
               Tr.debug(tc, "Processing continues - registering an MBean should not effect the server.");
            }
         } catch (ClassCastException var11) {
            FFDCFilter.processException(var11, "com.ibm.ejs.cm.DataSourceImpl.registerMBean", "%c", this);
            success = new Boolean(false);
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Class cast exception on rVal of registerMBean.");
               Tr.debug(tc, "Processing continues");
            }
         }
      } else {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Unable to create WAS40DataSource MBean with the following data");
            Tr.debug(tc, "factoryID = " + factoryId);
            Tr.debug(tc, "providerId = " + providerId);
         }

         success = new Boolean(false);
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "registerMBean returning ", success);
      }

      return success;
   }

	public Logger getParentLogger() throws SQLFeatureNotSupportedException {
		throw new SQLFeatureNotSupportedException();
	}
}