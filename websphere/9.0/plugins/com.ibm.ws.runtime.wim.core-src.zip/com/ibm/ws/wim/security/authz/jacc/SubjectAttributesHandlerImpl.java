package com.ibm.ws.wim.security.authz.jacc;

import com.ibm.sec.auth.subjectx.SubjectAttributesHandler;
import com.ibm.ws.wim.security.authz.AccessHandler;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import javax.security.auth.Subject;

class SubjectAttributesHandlerImpl implements SubjectAttributesHandler {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String KEY_PREFIX = "com.ibm.websphere.wim.Subject.";
	private Set supportedKeys;
	private Set referencedAttrs = new HashSet();
	private AccessHandler accessHandler;

	public SubjectAttributesHandlerImpl(Set var1, AccessHandler var2) {
		this.supportedKeys = var1;
		this.accessHandler = var2;
		Iterator var4 = var1.iterator();

		while (var4.hasNext()) {
			String var3;
			if ((var3 = (String) var4.next()).startsWith("com.ibm.websphere.wim.Subject.")) {
				this.referencedAttrs.add(var3.substring("com.ibm.websphere.wim.Subject.".length()));
			}
		}

	}

	public String[] getAttributeNames() {
		return (String[]) ((String[]) this.supportedKeys.toArray(new String[this.supportedKeys.size()]));
	}

	public boolean supports(String var1) {
		return this.supportedKeys.contains(var1);
	}

	public Object getAttribute(Subject var1, String var2) {
		Object var3 = null;
		if (var2.equals("user")) {
			return this.accessHandler.getSubjectPrincipal(var1);
		} else if (var2.equals("group")) {
			return this.accessHandler.getSubjectGroups(var1);
		} else {
			if (var2.startsWith("com.ibm.websphere.wim.Subject.")) {
				var3 = this.accessHandler.getSubjectAttribute(var1,
						var2.substring("com.ibm.websphere.wim.Subject.".length()), this.referencedAttrs);
			}

			return var3;
		}
	}
}