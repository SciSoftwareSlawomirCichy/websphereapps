package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.collect.HashBiMap.EntrySet;
import com.google.common.collect.HashBiMap.Inverse;
import com.google.common.collect.HashBiMap.KeySet;
import com.google.common.collect.HashBiMap.ValueSet;
import com.google.common.collect.ImmutableCollection.Builder;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.j2objc.annotations.RetainedWith;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public final class HashBiMap<K, V> extends AbstractMap<K, V> implements BiMap<K, V>, Serializable {
	private static final int ABSENT = -1;
	private static final int ENDPOINT = -2;
	transient K[] keys;
	transient V[] values;
	transient int size;
	transient int modCount;
	private transient int[] hashTableKToV;
	private transient int[] hashTableVToK;
	private transient int[] nextInBucketKToV;
	private transient int[] nextInBucketVToK;
	@NullableDecl
	private transient int firstInInsertionOrder;
	@NullableDecl
	private transient int lastInInsertionOrder;
	private transient int[] prevInInsertionOrder;
	private transient int[] nextInInsertionOrder;
	private transient Set<K> keySet;
	private transient Set<V> valueSet;
	private transient Set<Entry<K, V>> entrySet;
	@MonotonicNonNullDecl
	@RetainedWith
	private transient BiMap<V, K> inverse;

	public static <K, V> HashBiMap<K, V> create() {
		return create(16);
	}

	public static <K, V> HashBiMap<K, V> create(int expectedSize) {
		return new HashBiMap(expectedSize);
	}

	public static <K, V> HashBiMap<K, V> create(Map<? extends K, ? extends V> map) {
		HashBiMap<K, V> bimap = create(map.size());
		bimap.putAll(map);
		return bimap;
	}

	private HashBiMap(int expectedSize) {
		this.init(expectedSize);
	}

	void init(int expectedSize) {
		CollectPreconditions.checkNonnegative(expectedSize, "expectedSize");
		int tableSize = Hashing.closedTableSize(expectedSize, 1.0D);
		this.size = 0;
		this.keys = (Object[]) (new Object[expectedSize]);
		this.values = (Object[]) (new Object[expectedSize]);
		this.hashTableKToV = createFilledWithAbsent(tableSize);
		this.hashTableVToK = createFilledWithAbsent(tableSize);
		this.nextInBucketKToV = createFilledWithAbsent(expectedSize);
		this.nextInBucketVToK = createFilledWithAbsent(expectedSize);
		this.firstInInsertionOrder = -2;
		this.lastInInsertionOrder = -2;
		this.prevInInsertionOrder = createFilledWithAbsent(expectedSize);
		this.nextInInsertionOrder = createFilledWithAbsent(expectedSize);
	}

	private static int[] createFilledWithAbsent(int size) {
		int[] array = new int[size];
		Arrays.fill(array, -1);
		return array;
	}

	private static int[] expandAndFillWithAbsent(int[] array, int newSize) {
		int oldSize = array.length;
		int[] result = Arrays.copyOf(array, newSize);
		Arrays.fill(result, oldSize, newSize, -1);
		return result;
	}

	public int size() {
		return this.size;
	}

	private void ensureCapacity(int minCapacity) {
		int newTableSize;
		int entryToRehash;
		if (this.nextInBucketKToV.length < minCapacity) {
			newTableSize = this.nextInBucketKToV.length;
			entryToRehash = Builder.expandedCapacity(newTableSize, minCapacity);
			this.keys = Arrays.copyOf(this.keys, entryToRehash);
			this.values = Arrays.copyOf(this.values, entryToRehash);
			this.nextInBucketKToV = expandAndFillWithAbsent(this.nextInBucketKToV, entryToRehash);
			this.nextInBucketVToK = expandAndFillWithAbsent(this.nextInBucketVToK, entryToRehash);
			this.prevInInsertionOrder = expandAndFillWithAbsent(this.prevInInsertionOrder, entryToRehash);
			this.nextInInsertionOrder = expandAndFillWithAbsent(this.nextInInsertionOrder, entryToRehash);
		}

		if (this.hashTableKToV.length < minCapacity) {
			newTableSize = Hashing.closedTableSize(minCapacity, 1.0D);
			this.hashTableKToV = createFilledWithAbsent(newTableSize);
			this.hashTableVToK = createFilledWithAbsent(newTableSize);

			int valueBucket;
			for (entryToRehash = 0; entryToRehash < this.size; this.hashTableVToK[valueBucket] = entryToRehash++) {
				int keyHash = Hashing.smearedHash(this.keys[entryToRehash]);
				int keyBucket = this.bucket(keyHash);
				this.nextInBucketKToV[entryToRehash] = this.hashTableKToV[keyBucket];
				this.hashTableKToV[keyBucket] = entryToRehash;
				int valueHash = Hashing.smearedHash(this.values[entryToRehash]);
				valueBucket = this.bucket(valueHash);
				this.nextInBucketVToK[entryToRehash] = this.hashTableVToK[valueBucket];
			}
		}

	}

	private int bucket(int hash) {
		return hash & this.hashTableKToV.length - 1;
	}

	int findEntryByKey(@NullableDecl Object key) {
		return this.findEntryByKey(key, Hashing.smearedHash(key));
	}

	int findEntryByKey(@NullableDecl Object key, int keyHash) {
		return this.findEntry(key, keyHash, this.hashTableKToV, this.nextInBucketKToV, this.keys);
	}

	int findEntryByValue(@NullableDecl Object value) {
		return this.findEntryByValue(value, Hashing.smearedHash(value));
	}

	int findEntryByValue(@NullableDecl Object value, int valueHash) {
		return this.findEntry(value, valueHash, this.hashTableVToK, this.nextInBucketVToK, this.values);
	}

	int findEntry(@NullableDecl Object o, int oHash, int[] hashTable, int[] nextInBucket, Object[] array) {
		for (int entry = hashTable[this.bucket(oHash)]; entry != -1; entry = nextInBucket[entry]) {
			if (Objects.equal(array[entry], o)) {
				return entry;
			}
		}

		return -1;
	}

	public boolean containsKey(@NullableDecl Object key) {
		return this.findEntryByKey(key) != -1;
	}

	public boolean containsValue(@NullableDecl Object value) {
		return this.findEntryByValue(value) != -1;
	}

	@NullableDecl
	public V get(@NullableDecl Object key) {
		int entry = this.findEntryByKey(key);
		return entry == -1 ? null : this.values[entry];
	}

	@NullableDecl
	K getInverse(@NullableDecl Object value) {
		int entry = this.findEntryByValue(value);
		return entry == -1 ? null : this.keys[entry];
	}

	@CanIgnoreReturnValue
	public V put(@NullableDecl K key, @NullableDecl V value) {
		return this.put(key, value, false);
	}

	@NullableDecl
	V put(@NullableDecl K key, @NullableDecl V value, boolean force) {
		int keyHash = Hashing.smearedHash(key);
		int entryForKey = this.findEntryByKey(key, keyHash);
		if (entryForKey != -1) {
			V oldValue = this.values[entryForKey];
			if (Objects.equal(oldValue, value)) {
				return value;
			} else {
				this.replaceValueInEntry(entryForKey, value, force);
				return oldValue;
			}
		} else {
			int valueHash = Hashing.smearedHash(value);
			int valueEntry = this.findEntryByValue(value, valueHash);
			if (force) {
				if (valueEntry != -1) {
					this.removeEntryValueHashKnown(valueEntry, valueHash);
				}
			} else {
				Preconditions.checkArgument(valueEntry == -1, "Value already present: %s", value);
			}

			this.ensureCapacity(this.size + 1);
			this.keys[this.size] = key;
			this.values[this.size] = value;
			this.insertIntoTableKToV(this.size, keyHash);
			this.insertIntoTableVToK(this.size, valueHash);
			this.setSucceeds(this.lastInInsertionOrder, this.size);
			this.setSucceeds(this.size, -2);
			++this.size;
			++this.modCount;
			return null;
		}
	}

	@NullableDecl
	@CanIgnoreReturnValue
	public V forcePut(@NullableDecl K key, @NullableDecl V value) {
		return this.put(key, value, true);
	}

	@NullableDecl
	K putInverse(@NullableDecl V value, @NullableDecl K key, boolean force) {
		int valueHash = Hashing.smearedHash(value);
		int entryForValue = this.findEntryByValue(value, valueHash);
		if (entryForValue != -1) {
			K oldKey = this.keys[entryForValue];
			if (Objects.equal(oldKey, key)) {
				return key;
			} else {
				this.replaceKeyInEntry(entryForValue, key, force);
				return oldKey;
			}
		} else {
			int predecessor = this.lastInInsertionOrder;
			int keyHash = Hashing.smearedHash(key);
			int keyEntry = this.findEntryByKey(key, keyHash);
			if (force) {
				if (keyEntry != -1) {
					predecessor = this.prevInInsertionOrder[keyEntry];
					this.removeEntryKeyHashKnown(keyEntry, keyHash);
				}
			} else {
				Preconditions.checkArgument(keyEntry == -1, "Key already present: %s", key);
			}

			this.ensureCapacity(this.size + 1);
			this.keys[this.size] = key;
			this.values[this.size] = value;
			this.insertIntoTableKToV(this.size, keyHash);
			this.insertIntoTableVToK(this.size, valueHash);
			int successor = predecessor == -2 ? this.firstInInsertionOrder : this.nextInInsertionOrder[predecessor];
			this.setSucceeds(predecessor, this.size);
			this.setSucceeds(this.size, successor);
			++this.size;
			++this.modCount;
			return null;
		}
	}

	private void setSucceeds(int prev, int next) {
		if (prev == -2) {
			this.firstInInsertionOrder = next;
		} else {
			this.nextInInsertionOrder[prev] = next;
		}

		if (next == -2) {
			this.lastInInsertionOrder = prev;
		} else {
			this.prevInInsertionOrder[next] = prev;
		}

	}

	private void insertIntoTableKToV(int entry, int keyHash) {
		Preconditions.checkArgument(entry != -1);
		int keyBucket = this.bucket(keyHash);
		this.nextInBucketKToV[entry] = this.hashTableKToV[keyBucket];
		this.hashTableKToV[keyBucket] = entry;
	}

	private void insertIntoTableVToK(int entry, int valueHash) {
		Preconditions.checkArgument(entry != -1);
		int valueBucket = this.bucket(valueHash);
		this.nextInBucketVToK[entry] = this.hashTableVToK[valueBucket];
		this.hashTableVToK[valueBucket] = entry;
	}

	private void deleteFromTableKToV(int entry, int keyHash) {
		Preconditions.checkArgument(entry != -1);
		int keyBucket = this.bucket(keyHash);
		if (this.hashTableKToV[keyBucket] == entry) {
			this.hashTableKToV[keyBucket] = this.nextInBucketKToV[entry];
			this.nextInBucketKToV[entry] = -1;
		} else {
			int prevInBucket = this.hashTableKToV[keyBucket];

			for (int entryInBucket = this.nextInBucketKToV[prevInBucket]; entryInBucket != -1; entryInBucket = this.nextInBucketKToV[entryInBucket]) {
				if (entryInBucket == entry) {
					this.nextInBucketKToV[prevInBucket] = this.nextInBucketKToV[entry];
					this.nextInBucketKToV[entry] = -1;
					return;
				}

				prevInBucket = entryInBucket;
			}

			throw new AssertionError("Expected to find entry with key " + this.keys[entry]);
		}
	}

	private void deleteFromTableVToK(int entry, int valueHash) {
		Preconditions.checkArgument(entry != -1);
		int valueBucket = this.bucket(valueHash);
		if (this.hashTableVToK[valueBucket] == entry) {
			this.hashTableVToK[valueBucket] = this.nextInBucketVToK[entry];
			this.nextInBucketVToK[entry] = -1;
		} else {
			int prevInBucket = this.hashTableVToK[valueBucket];

			for (int entryInBucket = this.nextInBucketVToK[prevInBucket]; entryInBucket != -1; entryInBucket = this.nextInBucketVToK[entryInBucket]) {
				if (entryInBucket == entry) {
					this.nextInBucketVToK[prevInBucket] = this.nextInBucketVToK[entry];
					this.nextInBucketVToK[entry] = -1;
					return;
				}

				prevInBucket = entryInBucket;
			}

			throw new AssertionError("Expected to find entry with value " + this.values[entry]);
		}
	}

	private void replaceValueInEntry(int entry, @NullableDecl V newValue, boolean force) {
		Preconditions.checkArgument(entry != -1);
		int newValueHash = Hashing.smearedHash(newValue);
		int newValueIndex = this.findEntryByValue(newValue, newValueHash);
		if (newValueIndex != -1) {
			if (!force) {
				throw new IllegalArgumentException("Value already present in map: " + newValue);
			}

			this.removeEntryValueHashKnown(newValueIndex, newValueHash);
			if (entry == this.size) {
				entry = newValueIndex;
			}
		}

		this.deleteFromTableVToK(entry, Hashing.smearedHash(this.values[entry]));
		this.values[entry] = newValue;
		this.insertIntoTableVToK(entry, newValueHash);
	}

	private void replaceKeyInEntry(int entry, @NullableDecl K newKey, boolean force) {
		Preconditions.checkArgument(entry != -1);
		int newKeyHash = Hashing.smearedHash(newKey);
		int newKeyIndex = this.findEntryByKey(newKey, newKeyHash);
		int newPredecessor = this.lastInInsertionOrder;
		int newSuccessor = -2;
		if (newKeyIndex != -1) {
			if (!force) {
				throw new IllegalArgumentException("Key already present in map: " + newKey);
			}

			newPredecessor = this.prevInInsertionOrder[newKeyIndex];
			newSuccessor = this.nextInInsertionOrder[newKeyIndex];
			this.removeEntryKeyHashKnown(newKeyIndex, newKeyHash);
			if (entry == this.size) {
				entry = newKeyIndex;
			}
		}

		if (newPredecessor == entry) {
			newPredecessor = this.prevInInsertionOrder[entry];
		} else if (newPredecessor == this.size) {
			newPredecessor = newKeyIndex;
		}

		if (newSuccessor == entry) {
			newSuccessor = this.nextInInsertionOrder[entry];
		} else if (newSuccessor == this.size) {
			newSuccessor = newKeyIndex;
		}

		int oldPredecessor = this.prevInInsertionOrder[entry];
		int oldSuccessor = this.nextInInsertionOrder[entry];
		this.setSucceeds(oldPredecessor, oldSuccessor);
		this.deleteFromTableKToV(entry, Hashing.smearedHash(this.keys[entry]));
		this.keys[entry] = newKey;
		this.insertIntoTableKToV(entry, Hashing.smearedHash(newKey));
		this.setSucceeds(newPredecessor, entry);
		this.setSucceeds(entry, newSuccessor);
	}

	@NullableDecl
	@CanIgnoreReturnValue
	public V remove(@NullableDecl Object key) {
		int keyHash = Hashing.smearedHash(key);
		int entry = this.findEntryByKey(key, keyHash);
		if (entry == -1) {
			return null;
		} else {
			V value = this.values[entry];
			this.removeEntryKeyHashKnown(entry, keyHash);
			return value;
		}
	}

	@NullableDecl
	K removeInverse(@NullableDecl Object value) {
		int valueHash = Hashing.smearedHash(value);
		int entry = this.findEntryByValue(value, valueHash);
		if (entry == -1) {
			return null;
		} else {
			K key = this.keys[entry];
			this.removeEntryValueHashKnown(entry, valueHash);
			return key;
		}
	}

	void removeEntry(int entry) {
		this.removeEntryKeyHashKnown(entry, Hashing.smearedHash(this.keys[entry]));
	}

	private void removeEntry(int entry, int keyHash, int valueHash) {
		Preconditions.checkArgument(entry != -1);
		this.deleteFromTableKToV(entry, keyHash);
		this.deleteFromTableVToK(entry, valueHash);
		int oldPredecessor = this.prevInInsertionOrder[entry];
		int oldSuccessor = this.nextInInsertionOrder[entry];
		this.setSucceeds(oldPredecessor, oldSuccessor);
		this.moveEntryToIndex(this.size - 1, entry);
		this.keys[this.size - 1] = null;
		this.values[this.size - 1] = null;
		--this.size;
		++this.modCount;
	}

	void removeEntryKeyHashKnown(int entry, int keyHash) {
		this.removeEntry(entry, keyHash, Hashing.smearedHash(this.values[entry]));
	}

	void removeEntryValueHashKnown(int entry, int valueHash) {
		this.removeEntry(entry, Hashing.smearedHash(this.keys[entry]), valueHash);
	}

	private void moveEntryToIndex(int src, int dest) {
		if (src != dest) {
			int predecessor = this.prevInInsertionOrder[src];
			int successor = this.nextInInsertionOrder[src];
			this.setSucceeds(predecessor, dest);
			this.setSucceeds(dest, successor);
			K key = this.keys[src];
			V value = this.values[src];
			this.keys[dest] = key;
			this.values[dest] = value;
			int keyHash = Hashing.smearedHash(key);
			int keyBucket = this.bucket(keyHash);
			int prevInBucket;
			int entryInBucket;
			if (this.hashTableKToV[keyBucket] == src) {
				this.hashTableKToV[keyBucket] = dest;
			} else {
				prevInBucket = this.hashTableKToV[keyBucket];

				for (entryInBucket = this.nextInBucketKToV[prevInBucket]; entryInBucket != src; entryInBucket = this.nextInBucketKToV[entryInBucket]) {
					prevInBucket = entryInBucket;
				}

				this.nextInBucketKToV[prevInBucket] = dest;
			}

			this.nextInBucketKToV[dest] = this.nextInBucketKToV[src];
			this.nextInBucketKToV[src] = -1;
			prevInBucket = Hashing.smearedHash(value);
			entryInBucket = this.bucket(prevInBucket);
			if (this.hashTableVToK[entryInBucket] == src) {
				this.hashTableVToK[entryInBucket] = dest;
			} else {
				int prevInBucket = this.hashTableVToK[entryInBucket];

				for (int entryInBucket = this.nextInBucketVToK[prevInBucket]; entryInBucket != src; entryInBucket = this.nextInBucketVToK[entryInBucket]) {
					prevInBucket = entryInBucket;
				}

				this.nextInBucketVToK[prevInBucket] = dest;
			}

			this.nextInBucketVToK[dest] = this.nextInBucketVToK[src];
			this.nextInBucketVToK[src] = -1;
		}
	}

	public void clear() {
		Arrays.fill(this.keys, 0, this.size, (Object) null);
		Arrays.fill(this.values, 0, this.size, (Object) null);
		Arrays.fill(this.hashTableKToV, -1);
		Arrays.fill(this.hashTableVToK, -1);
		Arrays.fill(this.nextInBucketKToV, 0, this.size, -1);
		Arrays.fill(this.nextInBucketVToK, 0, this.size, -1);
		Arrays.fill(this.prevInInsertionOrder, 0, this.size, -1);
		Arrays.fill(this.nextInInsertionOrder, 0, this.size, -1);
		this.size = 0;
		this.firstInInsertionOrder = -2;
		this.lastInInsertionOrder = -2;
		++this.modCount;
	}

	public Set<K> keySet() {
		Set<K> result = this.keySet;
		return result == null ? (this.keySet = new KeySet(this)) : result;
	}

	public Set<V> values() {
		Set<V> result = this.valueSet;
		return result == null ? (this.valueSet = new ValueSet(this)) : result;
	}

	public Set<Entry<K, V>> entrySet() {
		Set<Entry<K, V>> result = this.entrySet;
		return result == null ? (this.entrySet = new EntrySet(this)) : result;
	}

	public BiMap<V, K> inverse() {
		BiMap<V, K> result = this.inverse;
		return result == null ? (this.inverse = new Inverse(this)) : result;
	}

	@GwtIncompatible
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		Serialization.writeMap(this, stream);
	}

	@GwtIncompatible
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		int size = Serialization.readCount(stream);
		this.init(16);
		Serialization.populateMap(this, stream, size);
	}
}