package com.ibm.icu.text;

import com.ibm.icu.impl.Assert;
import com.ibm.icu.impl.ICUData;
import com.ibm.icu.impl.ICULocaleService;
import com.ibm.icu.impl.ICUResourceBundle;
import com.ibm.icu.impl.ICUService.Factory;
import com.ibm.icu.text.BreakIterator.BreakIteratorServiceShim;
import com.ibm.icu.text.BreakIteratorFactory.BFService;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;
import java.io.IOException;
import java.io.InputStream;
import java.text.StringCharacterIterator;
import java.util.Locale;
import java.util.MissingResourceException;

final class BreakIteratorFactory extends BreakIteratorServiceShim {
	static final ICULocaleService service = new BFService();
	private static final String[] KIND_NAMES = new String[]{"grapheme", "word", "line", "sentence", "title"};
	private static final boolean[] DICTIONARY_POSSIBLE = new boolean[]{false, true, true, false, false};

	public Object registerInstance(BreakIterator iter, ULocale locale, int kind) {
		iter.setText(new StringCharacterIterator(""));
		return service.registerObject(iter, locale, kind);
	}

	public boolean unregister(Object key) {
		return service.isDefault() ? false : service.unregisterFactory((Factory) key);
	}

	public Locale[] getAvailableLocales() {
		return service == null ? ICUResourceBundle.getAvailableLocales() : service.getAvailableLocales();
	}

	public ULocale[] getAvailableULocales() {
		return service == null ? ICUResourceBundle.getAvailableULocales() : service.getAvailableULocales();
	}

	public BreakIterator createBreakIterator(ULocale locale, int kind) {
		if (service.isDefault()) {
			return createBreakInstance(locale, kind);
		} else {
			ULocale[] actualLoc = new ULocale[1];
			BreakIterator iter = (BreakIterator) service.get(locale, kind, actualLoc);
			iter.setLocale(actualLoc[0], actualLoc[0]);
			return iter;
		}
	}

	private static BreakIterator createBreakInstance(ULocale locale, int kind) {
		BreakIterator iter = null;
		ICUResourceBundle rb = (ICUResourceBundle) UResourceBundle
				.getBundleInstance("com/ibm/icu/impl/data/icudt44b/brkitr", locale);
		InputStream ruleStream = null;

		String dictType;
		String dictFileName;
		try {
			dictType = KIND_NAMES[kind];
			dictFileName = rb.getStringWithFallback("boundaries/" + dictType);
			String rulesFileName = "data/icudt44b/brkitr/" + dictFileName;
			ruleStream = ICUData.getStream(rulesFileName);
		} catch (Exception var11) {
			throw new MissingResourceException(var11.toString(), "", "");
		}

		if (DICTIONARY_POSSIBLE[kind]) {
			try {
				if (locale.getLanguage().equals("th")) {
					dictType = "Thai";
					dictFileName = rb.getStringWithFallback("dictionaries/" + dictType);
					dictFileName = "data/icudt44b/brkitr/" + dictFileName;
					InputStream is = ICUData.getStream(dictFileName);
					iter = new ThaiBreakIterator(ruleStream, is);
				}
			} catch (MissingResourceException var9) {
				;
			} catch (IOException var10) {
				Assert.fail(var10);
			}
		}

		if (iter == null) {
			try {
				iter = RuleBasedBreakIterator.getInstanceFromCompiledRules(ruleStream);
			} catch (IOException var8) {
				Assert.fail(var8);
			}
		}

		ULocale uloc = ULocale.forLocale(rb.getLocale());
		((BreakIterator) iter).setLocale(uloc, uloc);
		return (BreakIterator) iter;
	}
}