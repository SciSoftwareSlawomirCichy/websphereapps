package com.ibm.ws.wim.adapter.urbridge;

import com.ibm.websphere.security.CertificateMapFailedException;
import com.ibm.websphere.security.CertificateMapNotSupportedException;
import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.EntryNotFoundException;
import com.ibm.websphere.security.Result;
import com.ibm.websphere.security.UserRegistry;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.PasswordCheckFailedException;
import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.runtime.service.VariableMap;
import com.ibm.ws.runtime.service.VariableMapFactory;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.env.ICacheUtil;
import com.ibm.ws.wim.util.ControlsHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.wsspi.wim.Repository;
import com.ibm.wsspi.wim.RepositoryImpl;
import commonj.sdo.DataObject;
import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class URBridge extends RepositoryImpl implements Repository {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;
	private UserRegistry reg = null;
	private Map attrMap = null;
	private Map propsMap = null;
	private String baseEntryName = null;
	private Map entityConfigMap = null;
	private String reposId = null;
	private SchemaManager schemaMgr = null;
	private Properties customPropertyMap = null;
	private String personAccountType = null;
	private String groupAccountType = null;
	private VariableMap variableMap = null;
	static final String registryPropsFile = "/com/ibm/ws/security/registry/wsregistries.properties";
	private static final String SAFRegistryImplClass = "com.ibm.ws.security.registry.zOS.SAFRegistryImpl";
	private int sharedPushPolicy = FactoryManager.getCacheUtil().getSharedPushInt();
	private boolean userSearchCacheEnabled = true;
	private boolean groupSearchCacheEnabled = true;
	private boolean userSecurityNameCacheEnabled = true;
	private boolean groupSecurityNameCacheEnabled = true;
	private ICacheUtil userSecurityNameCache = null;
	private ICacheUtil groupSecurityNameCache = null;
	private ICacheUtil userSearchCache = null;
	private ICacheUtil groupSearchCache = null;
	private String userSecurityNameCacheName = "UserSecurityNameSearchCache";
	private String groupSecurityNameCacheName = "GroupSecurityNameSearchCache";
	private String userSearchCacheName = "UserSearchCache";
	private String groupSearchCacheName = "GroupSearchCache";
	private boolean enableCache = false;
	private int cacheTimeout = 600;
	private int cacheSize = 4000;

	public URBridge() {
		try {
			this.variableMap = VariableMapFactory.getVariableMap();
		} catch (Exception var2) {
			this.variableMap = null;
			trcLogger.logp(Level.SEVERE, CLASSNAME, "<init>",
					"Variables cannot be expanded since variableMap is not initialized.Either start the Websphere Application Server or Replace variables with respective Values.");
		}

	}

	private void initializeCaches() {
		String var1 = "initializeCaches";
		String var2 = DomainManagerUtils.getDomainId();
		if (var2 != null && !"admin".equalsIgnoreCase(var2)) {
			var2 = var2 + "/";
		} else {
			var2 = "";
		}

		this.userSecurityNameCacheName = var2 + this.reposId + "/" + this.userSecurityNameCacheName;
		this.groupSecurityNameCacheName = var2 + this.reposId + "/" + this.groupSecurityNameCacheName;
		this.userSearchCacheName = var2 + this.reposId + "/" + this.userSearchCacheName;
		this.groupSearchCacheName = var2 + this.reposId + "/" + this.groupSearchCacheName;
		this.createUserSearchCache();
		if (this.userSearchCache == null && trcLogger.isLoggable(Level.CONFIG)) {
			trcLogger.logp(Level.CONFIG, CLASSNAME, var1,
					"userSearchCache Cache is not available because DynaCache is not available yet.");
		}

		this.createGroupSearchCache();
		if (this.groupSearchCache == null && trcLogger.isLoggable(Level.CONFIG)) {
			trcLogger.logp(Level.CONFIG, CLASSNAME, var1,
					"groupSearchCache Cache is not available because DynaCache is not available yet.");
		}

		this.createUserSecurityNameSearchCache();
		if (this.userSecurityNameCache == null && trcLogger.isLoggable(Level.CONFIG)) {
			trcLogger.logp(Level.CONFIG, CLASSNAME, var1,
					"userSecurityNameCache Cache is not available because DynaCache is not available yet.");
		}

		this.createGroupSecurityNameSearchCache();
		if (this.groupSecurityNameCache == null && trcLogger.isLoggable(Level.CONFIG)) {
			trcLogger.logp(Level.CONFIG, CLASSNAME, var1,
					"groupSecurityNameCache Cache is not available because DynaCache is not available yet.");
		}

	}

	private void setMapping() {
		this.attrMap = new HashMap(6);
		this.attrMap.put("groupSecurityNameProperty",
				this.customPropertyMap.get("groupSecurityNameProperty") == null
						? "uniqueName"
						: this.customPropertyMap.get("groupSecurityNameProperty"));
		this.attrMap.put("groupDisplayNameProperty",
				this.customPropertyMap.get("groupDisplayNameProperty") == null
						? "displayName"
						: this.customPropertyMap.get("groupDisplayNameProperty"));
		this.attrMap.put("uniqueGroupIdProperty",
				this.customPropertyMap.get("uniqueGroupIdProperty") == null
						? "uniqueId"
						: this.customPropertyMap.get("uniqueGroupIdProperty"));
		this.attrMap.put("userDisplayNameProperty",
				this.customPropertyMap.get("userDisplayNameProperty") == null
						? "displayName"
						: this.customPropertyMap.get("userDisplayNameProperty"));
		this.attrMap.put("userSecurityNameProperty",
				this.customPropertyMap.get("userSecurityNameProperty") == null
						? "uniqueName"
						: this.customPropertyMap.get("userSecurityNameProperty"));
		this.attrMap.put("uniqueUserIdProperty",
				this.customPropertyMap.get("uniqueUserIdProperty") == null
						? "uniqueId"
						: this.customPropertyMap.get("uniqueUserIdProperty"));
	}

	public void setBaseEntry(DataObject var1) throws WIMException {
		List var3 = var1.getList("baseEntries");
		if (var3 != null && var3.size() >= 1) {
			DataObject var4 = (DataObject) var3.get(0);
			this.baseEntryName = var4.getString("name");
		} else {
			throw new WIMApplicationException("MISSING_BASE_ENTRY", WIMMessageHelper.generateMsgParms(this.reposId),
					Level.SEVERE, CLASSNAME, "setBaseEntry");
		}
	}

	public void setReposId(DataObject var1) {
		this.reposId = var1.getString("id");
	}

	public void initialize(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI initialize", "reposConfig:" + var1);
		}

		try {
			this.schemaMgr = SchemaManager.singleton();
			this.setCustomProperties(var1.getList("CustomProperties"));
			this.setMapping();
			this.setBaseEntry(var1);
			this.setConfigEntityMapping(var1);
			this.propsMap = new HashMap();
			this.propsMap.putAll(this.attrMap);
			this.propsMap.putAll(this.customPropertyMap);
			URBridgeHelper.mapSupportedEntityTypeList();
			this.personAccountType = URBridgeHelper.getPersonAccountType();
			this.groupAccountType = URBridgeHelper.getGroupAccountType();
			this.setReposId(var1);
			Properties var4 = new Properties();
			String var5 = this.customPropertyMap.get("registryImplClass") == null
					? null
					: (String) this.customPropertyMap.get("registryImplClass");
			if (var5 == null) {
				String var6 = System.getProperty("os.name");
				if (var6.startsWith("Windows")) {
					var6 = "Windows";
				}

				var4.load(this.getClass().getResourceAsStream("/com/ibm/ws/security/registry/wsregistries.properties"));
				var5 = var4.getProperty(var6);
			}

			if (var5 == null) {
				throw new WIMApplicationException("MISSING_OR_INVALID_CUSTOM_REGISTRY_CLASS_NAME",
						WIMMessageHelper.generateMsgParms(var5), Level.SEVERE, CLASSNAME, "initialize");
			}

			ClassLoader var10 = Thread.currentThread().getContextClassLoader();
			if (var10 == null) {
				var10 = this.getClass().getClassLoader();
			}

			Class var7 = Class.forName(var5, true, var10);
			Object var8 = var7.newInstance();
			if (!(var8 instanceof UserRegistry)) {
				throw new WIMApplicationException("MISSING_OR_INVALID_CUSTOM_REGISTRY_CLASS_NAME",
						WIMMessageHelper.generateMsgParms(var5), Level.SEVERE, CLASSNAME, "initialize");
			}

			this.reg = (UserRegistry) var8;
			this.reg.initialize(this.customPropertyMap);
			if (this.enableCache) {
				this.initializeCaches();
			}
		} catch (Throwable var9) {
			throw new InitializationException("REPOSITORY_INITIALIZATION_FAILED",
					WIMMessageHelper.generateMsgParms(this.reposId, var9.toString()), Level.SEVERE, CLASSNAME,
					"initialize", var9);
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI initialize", "reposConfig:" + var1);
		}

	}

	private void setConfigEntityMapping(DataObject var1) throws WIMException {
		List var2 = this.getSupportedEntityTypes();
		ConfigManager var3 = ConfigManager.singleton();
		String var5 = null;
		this.entityConfigMap = new HashMap(6);

		for (int var6 = 0; var6 < var2.size(); ++var6) {
			var5 = (String) var2.get(var6);
			String var4 = var3.getRDNProperties(var5) == null ? null : (String) var3.getRDNProperties(var5).get(0);
			this.entityConfigMap.put(var5, var4);
		}

		if (this.entityConfigMap.get("LoginAccount") == null
				&& this.entityConfigMap.get(this.personAccountType) != null) {
			this.entityConfigMap.put("LoginAccount", this.entityConfigMap.get(this.personAccountType));
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "setConfigEntityMapping", "entityConfigMap:" + this.entityConfigMap);
		}

	}

	private void setCustomProperties(List var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "setCustomProperties", "propList:" + var1);
		}

		this.customPropertyMap = new Properties();
		if (var1 != null) {
			Iterator var3 = var1.iterator();

			while (var3.hasNext()) {
				DataObject var4 = (DataObject) var3.next();
				String var5 = var4.getString("name");
				String var6 = this.expandVar(var4.getString("value"));
				this.customPropertyMap.put(var5, var6);
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "setCustomProperties",
							"custom properties " + this.customPropertyMap);
				}
			}

			if (!this.customPropertyMap.isEmpty()) {
				String var7;
				if (this.customPropertyMap.containsKey("com.ibm.ws.wim.adapter.urbridge.enablecache")) {
					var7 = (String) this.customPropertyMap.get("com.ibm.ws.wim.adapter.urbridge.enablecache");
					this.enableCache = Boolean.parseBoolean(var7);
				}

				if (this.customPropertyMap.containsKey("com.ibm.ws.wim.adapter.urbridge.cache.timeout")) {
					var7 = (String) this.customPropertyMap.get("com.ibm.ws.wim.adapter.urbridge.cache.timeout");
					this.cacheTimeout = Integer.parseInt(var7);
				}

				if (this.customPropertyMap.containsKey("com.ibm.ws.wim.adapter.urbridge.cache.size")) {
					var7 = (String) this.customPropertyMap.get("com.ibm.ws.wim.adapter.urbridge.cache.size");
					this.cacheSize = Integer.parseInt(var7);
				}
			}

		}
	}

	private String expandVar(String var1) throws WIMException {
		String var3 = null;
		if (this.variableMap != null) {
			try {
				var3 = this.variableMap.expand(var1);
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "expandVar", "Variable " + var1 + " expanded as " + var3);
				}
			} catch (Exception var5) {
				var3 = var1;
			}
		} else {
			var3 = var1;
		}

		return var3;
	}

	public DataObject create(DataObject var1) throws WIMException {
		throw new WIMApplicationException("CANNOT_WRITE_TO_READ_ONLY_REPOSITORY",
				WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, "create");
	}

	public DataObject delete(DataObject var1) throws WIMException {
		throw new WIMApplicationException("CANNOT_WRITE_TO_READ_ONLY_REPOSITORY",
				WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, "delete");
	}

	public DataObject update(DataObject var1) throws WIMException {
		throw new WIMApplicationException("CANNOT_WRITE_TO_READ_ONLY_REPOSITORY",
				WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, "update");
	}

	public DataObject get(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI get", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var4 = null;
		DataObject var5 = null;
		String var6 = null;

		try {
			List var7 = null;
			List var8 = null;
			List var9 = null;
			Map var11 = ControlsHelper.getControlMap(var1);
			DataObject var12 = (DataObject) var11.get("PropertyControl");
			DataObject var13 = (DataObject) var11.get("GroupMemberControl");
			DataObject var14 = (DataObject) var11.get("GroupMembershipControl");
			if (var13 != null) {
				var8 = this.getAttributes(var13, this.personAccountType);
			}

			if (var14 != null) {
				var9 = this.getAttributes(var14, this.groupAccountType);
			}

			List var15 = var1.getList("entities");

			for (int var16 = 0; var16 < var15.size(); ++var16) {
				DataObject var17 = (DataObject) var15.get(var16);
				String var18 = this.validateEntity(var17);
				var6 = var17.getDataObject("identifier").getString("uniqueName");
				var5 = this.schemaMgr.createRootDataObject();
				var4 = var5.createDataObject("entities", "http://www.ibm.com/websphere/wim", var18);
				DataObject var19 = var4.createDataObject("identifier");
				var19.setString("repositoryId", this.reposId);
				URBridgeEntityFactory var20 = new URBridgeEntityFactory();
				URBridgeEntity var21 = var20.createObject(var4, this.reg, this.propsMap, this.baseEntryName,
						this.entityConfigMap);
				var21.setSecurityNameProp(var6);
				var7 = this.getAttributes(var12, var18);
				if (var7 != null) {
					var21.populateEntity(var7);
				}

				int var22;
				if (URBridgeHelper.isSuperType("Group", var18) && var13 != null && var8 != null) {
					var22 = 0;
					if (var13.isSet("countLimit")) {
						var22 = var13.getInt("countLimit");
					}

					var21.getUsersForGroup(var8, var22);
				} else if (URBridgeHelper.isSuperType("LoginAccount", var18) && var14 != null && var9 != null) {
					var22 = 0;
					if (var14.isSet("countLimit")) {
						var22 = var14.getInt("countLimit");
					}

					var21.getGroupsForUser(var9, var22);
				}
			}
		} catch (EntityNotFoundException var23) {
			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "get",
						"The entity  " + var6 + " is not a valid Entity in " + this.reposId);
			}
		} catch (Exception var24) {
			throw new WIMApplicationException("ENTITY_GET_FAILED",
					WIMMessageHelper.generateMsgParms(var6, var24.toString()), Level.SEVERE, CLASSNAME, "get", var24);
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI get", WIMTraceHelper.printDataObject(var5));
		}

		return var5;
	}

	public DataObject search(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI search", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var4 = this.schemaMgr.createRootDataObject();

		try {
			int var5 = 0;
			Map var6 = ControlsHelper.getControlMap(var1);
			DataObject var7 = (DataObject) var6.get("SearchControl");
			if (var7.isSet("countLimit")) {
				var5 = var7.getInt("countLimit");
			}

			String var8 = var7.getString("expression");
			if (var8 == null || var8.length() == 0) {
				throw new SearchControlException("MISSING_SEARCH_EXPRESSION", Level.SEVERE, CLASSNAME, "search");
			}

			URBridgeXPathHelper var9 = new URBridgeXPathHelper(var8);
			var8 = var9.getExpression();
			Result var10 = null;
			boolean var11 = var7.getBoolean("returnSubType");
			List var12 = var9.getEntityTypes();
			HashSet var13 = new HashSet();
			ArrayList var14 = null;
			if (var11) {
				for (int var15 = 0; var15 < var12.size(); ++var15) {
					String var16 = (String) var12.get(var15);
					Set var17 = this.schemaMgr.getSubEntityTypes(var16);
					var13.add(var16);
					if (var17 != null) {
						var13.addAll(var17);
					}
				}
			} else {
				var13.addAll(var12);
			}

			var14 = new ArrayList(var13);
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "search", "entityType List: " + var14);
			}

			int var31 = 0;

			label126 : while (true) {
				Object var18;
				String var19;
				int var20;
				DataObject var21;
				DataObject var22;
				URBridgeEntity var23;
				String var30;
				List var32;
				URBridgeEntityFactory var33;
				if (var31 < var14.size()) {
					var30 = (String) var14.get(var31);
					if (!URBridgeHelper.isSuperType("Group", var30)) {
						++var31;
						continue;
					}

					var32 = this.getAttributes(var7, var30);
					var18 = new ArrayList();
					if ("com.ibm.ws.security.registry.zOS.SAFRegistryImpl"
							.equalsIgnoreCase(this.reg.getClass().getName()) && !var8.endsWith("*")) {
						try {
							var19 = this.getGroupSecurityName(var8);
							((List) var18).add(var19);
						} catch (EntryNotFoundException var26) {
							;
						} catch (CustomRegistryException var27) {
							;
						}
					} else {
						if (!var8.contains("*")) {
							var5 = 1;
						}

						var10 = this.searchGroups(var8, var5);
						if (var10 != null) {
							var18 = var10.getList();
						}
					}

					if (((List) var18).size() > 0) {
						var33 = new URBridgeEntityFactory();

						for (var20 = 0; var20 < ((List) var18).size(); ++var20) {
							var21 = var4.createDataObject("entities", "http://www.ibm.com/websphere/wim", var30);
							var22 = var21.createDataObject("identifier");
							var23 = var33.createObject(var21, this.reg, this.propsMap, this.baseEntryName,
									this.entityConfigMap);
							var23.setSecurityNameProp((String) ((List) var18).get(var20));
							var23.populateEntity(var32);
							var22.setString("repositoryId", this.reposId);
						}
					}
				}

				var31 = 0;

				while (true) {
					if (var31 >= var14.size()) {
						break label126;
					}

					var30 = (String) var14.get(var31);
					if (URBridgeHelper.isSuperType("LoginAccount", var30)) {
						var32 = this.getAttributes(var7, var30);
						var18 = new ArrayList();
						if ("com.ibm.ws.security.registry.zOS.SAFRegistryImpl"
								.equalsIgnoreCase(this.reg.getClass().getName()) && !var8.endsWith("*")) {
							try {
								var19 = this.getUserSecurityName(var8);
								((List) var18).add(var19);
							} catch (EntryNotFoundException var24) {
								;
							} catch (CustomRegistryException var25) {
								;
							}
						} else {
							if (!var8.contains("*")) {
								var5 = 1;
							}

							var10 = this.searchUsers(var8, var5);
							if (var10 != null) {
								var18 = var10.getList();
							}
						}

						if (((List) var18).size() > 0) {
							var33 = new URBridgeEntityFactory();
							if (var30.equalsIgnoreCase("LoginAccount")) {
								var30 = URBridgeHelper.getPersonAccountType();
							}

							for (var20 = 0; var20 < ((List) var18).size(); ++var20) {
								var21 = var4.createDataObject("entities", "http://www.ibm.com/websphere/wim", var30);
								var22 = var21.createDataObject("identifier");
								var23 = var33.createObject(var21, this.reg, this.propsMap, this.baseEntryName,
										this.entityConfigMap);
								var23.setSecurityNameProp((String) ((List) var18).get(var20));
								var23.populateEntity(var32);
								var22.setString("repositoryId", this.reposId);
							}
						}
						break label126;
					}

					++var31;
				}
			}
		} catch (WIMException var28) {
			throw var28;
		} catch (Exception var29) {
			throw new WIMApplicationException("ENTITY_SEARCH_FAILED",
					WIMMessageHelper.generateMsgParms(var29.toString()), Level.SEVERE, CLASSNAME, "search", var29);
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI search", WIMTraceHelper.printDataObject(var4));
		}

		return var4;
	}

	private String stripRDN(String var1) {
		if (var1 == null) {
			return var1;
		} else {
			int var2 = var1.indexOf(61);
			int var3 = var1.indexOf(",");
			if (var2 >= 0 && var3 >= 0 && var2 <= var3) {
				String var4 = var1.substring(var2 + 1, var3);
				return var4;
			} else {
				return var1;
			}
		}
	}

	public DataObject login(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI login", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var4 = this.schemaMgr.createRootDataObject();
		URBridgeEntityFactory var5 = new URBridgeEntityFactory();
		List var6 = null;
		Map var8 = ControlsHelper.getControlMap(var1);
		DataObject var9 = (DataObject) var8.get("LoginControl");
		if (var9 != null) {
			var6 = this.getAttributes(var9, "LoginAccount");
		}

		List var10 = var1.getList("entities");
		if (var10.size() > 0) {
			DataObject var11 = (DataObject) var10.get(0);
			String var12 = var11.getType().getName();
			String var13 = null;
			if (!URBridgeHelper.isSuperType("LoginAccount", var12)) {
				throw new WIMApplicationException("ENTITY_TYPE_NOT_SUPPORTED", WIMMessageHelper.generateMsgParms(var12),
						Level.WARNING, CLASSNAME, "login");
			}

			if (var11.isSet("principalName")) {
				String var14 = var11.getString("principalName");
				byte[] var15 = var11.getBytes("password");
				if (var14 == null || var14.trim().length() == 0) {
					throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PRINCIPAL_NAME", CLASSNAME, "login");
				}

				if (var15 == null || var15.length == 0) {
					throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PASSWORD", CLASSNAME, "login");
				}

				String var16;
				try {
					var16 = new String(var15, "UTF-8");
				} catch (UnsupportedEncodingException var26) {
					throw new WIMApplicationException("CUSTOM_REGISTRY_EXCEPTION",
							WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, "login", var26);
				}

				try {
					boolean var17 = false;
					if ("com.ibm.ws.security.registry.zOS.SAFRegistryImpl"
							.equalsIgnoreCase(this.reg.getClass().getName())) {
						var17 = this.reg.isValidUser(var14);
					} else {
						Result var18 = null;

						try {
							var18 = this.searchUsers(var14, 1);
						} catch (CustomRegistryException var27) {
							if (var3) {
								trcLogger.logp(Level.FINER, CLASSNAME, "WIM_SPI login",
										"principal, " + var14 + ", not found in " + this.reposId);
							}
						}

						var17 = var18 != null && var18.getList().size() > 0;
					}

					if (var17) {
						try {
							var13 = this.reg.checkPassword(var14, var16);
						} catch (com.ibm.websphere.security.PasswordCheckFailedException var24) {
							throw new PasswordCheckFailedException("PASSWORD_MATCH_FAILED_FOR_PRINCIPALNAME",
									WIMMessageHelper.generateMsgParms(var14), Level.WARNING, CLASSNAME, "login", var24);
						} catch (Exception var25) {
							throw new WIMApplicationException("CUSTOM_REGISTRY_EXCEPTION",
									WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, "login",
									var25);
						}
					} else if (var3) {
						trcLogger.logp(Level.FINER, CLASSNAME, "WIM_SPI login",
								"principal, " + var14 + ", not found in " + this.reposId);
					}
				} catch (CustomRegistryException var28) {
					throw new WIMApplicationException("CUSTOM_REGISTRY_EXCEPTION",
							WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, "login", var28);
				} catch (RemoteException var29) {
					throw new WIMApplicationException("CUSTOM_REGISTRY_EXCEPTION",
							WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, "login", var29);
				}
			} else {
				if (!var11.isSet("certificate")) {
					throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PRINCIPAL_NAME", CLASSNAME, "login");
				}

				List var30 = var11.getList("certificate");
				int var32 = var30.size();
				if (var32 > 0) {
					X509Certificate[] var34 = new X509Certificate[var32];

					for (int var36 = 0; var36 < var34.length; ++var36) {
						ByteArrayInputStream var37 = new ByteArrayInputStream((byte[]) ((byte[]) var30.get(var36)));

						try {
							CertificateFactory var19 = CertificateFactory.getInstance("X.509");
							var34[var36] = (X509Certificate) var19.generateCertificate(var37);
							var37.close();
						} catch (Exception var23) {
							throw new WIMApplicationException("CERTIFICATE_GENERATE_FAILED", (Object[]) null,
									Level.WARNING, CLASSNAME, "login", var23);
						}
					}

					try {
						var13 = this.reg.mapCertificate(var34);
					} catch (CertificateMapFailedException var20) {
						throw new com.ibm.websphere.wim.exception.CertificateMapFailedException(
								"CERTIFICATE_MAP_FAILED", Level.WARNING, CLASSNAME, "login", var20);
					} catch (CertificateMapNotSupportedException var21) {
						throw new com.ibm.websphere.wim.exception.CertificateMapNotSupportedException(
								"AUTHENTICATION_WITH_CERT_NOT_SUPPORTED",
								WIMMessageHelper.generateMsgParms(this.reposId), CLASSNAME, "login", var21);
					} catch (Exception var22) {
						throw new WIMApplicationException("CUSTOM_REGISTRY_EXCEPTION",
								WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, "login",
								var22);
					}
				}
			}

			if (var13 != null) {
				DataObject var31 = var4.createDataObject("entities", "http://www.ibm.com/websphere/wim",
						URBridgeHelper.getPersonAccountType());
				DataObject var33 = var31.createDataObject("identifier");
				var31.setString("principalName", var13);
				URBridgeEntity var35 = var5.createObject(var31, this.reg, this.attrMap, this.baseEntryName,
						this.entityConfigMap);
				var35.setSecurityNameProp(var13);
				if (var6 != null) {
					var35.populateEntity(var6);
				}

				var33.setString("repositoryId", this.reposId);
			}
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI login", WIMTraceHelper.printDataObject(var4));
		}

		return var4;
	}

	public String getUserSecurityName(String var1)
			throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = null;
		if (this.enableCache && this.getUserSecurityNameCache() != null
				&& this.getUserSecurityNameCache().containsKey(var1)) {
			var2 = (String) this.getUserSecurityNameCache().get(var1);
		} else {
			var2 = this.reg.getUserSecurityName(var1);
			if (this.enableCache && this.getUserSecurityNameCache() != null) {
				this.getUserSecurityNameCache().put(var1, var2, 1, this.cacheTimeout, this.sharedPushPolicy,
						(Object[]) null);
			}
		}

		return var2;
	}

	public String getGroupSecurityName(String var1)
			throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = null;
		if (this.enableCache && this.getGroupSecurityNameCache() != null
				&& this.getGroupSecurityNameCache().containsKey(var1)) {
			var2 = (String) this.getGroupSecurityNameCache().get(var1);
		} else {
			var2 = this.reg.getGroupSecurityName(var1);
			if (this.enableCache && this.getGroupSecurityNameCache() != null) {
				this.getGroupSecurityNameCache().put(var1, var2, 1, this.cacheTimeout, this.sharedPushPolicy,
						(Object[]) null);
			}
		}

		return var2;
	}

	private Result searchUsers(String var1, int var2) throws CustomRegistryException, RemoteException {
		String var3 = this.getKey(var1, var2);
		if (this.enableCache && this.getUserSearchCache() != null && this.getUserSearchCache().containsKey(var3)) {
			return this.cloneResults((Result) this.getUserSearchCache().get(var3));
		} else {
			Result var4 = this.reg.getUsers(var1, var2);
			if (this.enableCache && this.getUserSearchCache() != null) {
				this.getUserSearchCache().put(var3, var4, 1, this.cacheTimeout, this.sharedPushPolicy, (Object[]) null);
			}

			return this.cloneResults(var4);
		}
	}

	private Result searchGroups(String var1, int var2) throws CustomRegistryException, RemoteException {
		String var3 = this.getKey(var1, var2);
		if (this.enableCache && this.getGroupSearchCache() != null && this.getGroupSearchCache().containsKey(var3)) {
			return this.cloneResults((Result) this.getGroupSearchCache().get(var3));
		} else {
			Result var4 = this.reg.getGroups(var1, var2);
			if (this.enableCache && this.getGroupSearchCache() != null) {
				this.getGroupSearchCache().put(var3, var4, 1, this.cacheTimeout, this.sharedPushPolicy,
						(Object[]) null);
			}

			return this.cloneResults(var4);
		}
	}

	private Result cloneResults(Result var1) {
		if (this.enableCache && var1 != null) {
			Result var2 = new Result();
			var2.setList(var1.getList());
			if (var1.hasMore()) {
				var2.setHasMore();
			}

			return var2;
		} else {
			return var1;
		}
	}

	private String getKey(String var1, int var2) {
		return var1.toLowerCase() + "|" + var2;
	}

	private List getAttributes(DataObject var1, String var2) throws WIMException {
		Object var3 = new ArrayList(10);
		if (var1 != null && var1.isSet("properties")) {
			var3 = var1.getList("properties");
		}

		if (((List) var3).size() > 0 && "*".equals((String) ((List) var3).get(0))) {
			var3 = this.getAttributes(var2);
		}

		((List) var3).addAll(this.getIdentifierAttributes(var2));
		return (List) var3;
	}

	private List getAttributes(String var1) throws WIMException {
		ArrayList var3 = new ArrayList(5);
		if (URBridgeHelper.isSuperType("Group", var1)) {
			var3.add((String) this.entityConfigMap.get(var1));
			var3.add(this.attrMap.get("groupDisplayNameProperty"));
		} else if (URBridgeHelper.isSuperType("LoginAccount", var1)) {
			var3.add((String) this.entityConfigMap.get(var1));
			var3.add("principalName");
			var3.add(this.attrMap.get("userDisplayNameProperty"));
		} else if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "getAttributes(entityType)",
					"Entity type " + var1 + " is invalid and is ignored.");
		}

		return var3;
	}

	private List getIdentifierAttributes(String var1) throws WIMException {
		ArrayList var3 = new ArrayList(4);
		if (URBridgeHelper.isSuperType("Group", var1)) {
			var3.add(this.attrMap.get("uniqueGroupIdProperty"));
			var3.add(this.attrMap.get("groupSecurityNameProperty"));
		} else if (URBridgeHelper.isSuperType("LoginAccount", var1)) {
			var3.add(this.attrMap.get("uniqueUserIdProperty"));
			var3.add(this.attrMap.get("userSecurityNameProperty"));
		} else if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "getIdentifierAttributes",
					"Entity type " + var1 + " is invalid and is ignored.");
		}

		return var3;
	}

	private String validateEntity(DataObject var1) throws WIMException {
		String var2 = "validateEntity";
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		String var4 = null;
		String var5 = null;
		String var6 = null;
		String var7 = null;
		if (var1.getDataObject("identifier").isSet("uniqueName")) {
			var7 = var1.getDataObject("identifier").getString("uniqueName");
		} else if (var1.getDataObject("identifier").isSet("externalName")) {
			var7 = var1.getDataObject("identifier").getString("externalName");
		} else if (var1.getDataObject("identifier").isSet("uniqueId")) {
			var6 = var1.getDataObject("identifier").getString("uniqueId");
		} else if (var1.getDataObject("identifier").isSet("externalId")) {
			var6 = var1.getDataObject("identifier").getString("externalId");
		}

		if (var7 != null) {
			var5 = this.stripRDN(var7);
		}

		if (var6 != null && var6.trim().length() > 0) {
			var5 = this.getSecNameFromUniqueID(var6);
			var7 = var5;
		}

		if (var5 != null && var5.trim().length() > 0) {
			String var8 = this.getRDN(var1.getDataObject("identifier").getString("uniqueName"));
			Set var9 = this.entityConfigMap.keySet();
			ArrayList var10 = new ArrayList();
			Iterator var11 = var9.iterator();

			label50 : while (true) {
				String var12;
				do {
					if (!var11.hasNext()) {
						var12 = var1.getType().getName();
						var4 = this.getEntityTypeFromUniqueName(var5, var10, var12);
						var1.getDataObject("identifier").setString("uniqueName", var7);
						break label50;
					}

					var12 = (String) var11.next();
				} while (var8 != null && !var8.equalsIgnoreCase((String) this.entityConfigMap.get(var12)));

				var10.add(var12);
			}
		}

		if (var3) {
			trcLogger.logp(Level.FINER, CLASSNAME, var2, "The entity type for " + var5 + " is " + var4);
		}

		if (var4 == null) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var5), Level.SEVERE,
					CLASSNAME, var2);
		} else {
			return var4;
		}
	}

	private String getEntityTypeFromUniqueName(String var1, List var2, String var3) throws WIMException {
		String var4 = "getEntityTypeFromUniqueName";
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		String var6 = null;
		ArrayList var7 = new ArrayList();
		Result var8 = null;

		try {
			boolean var9 = false;
			if (var2.size() == 0 || var2.size() > 1) {
				var9 = true;
			}

			boolean var10;
			if ("com.ibm.ws.security.registry.zOS.SAFRegistryImpl".equalsIgnoreCase(this.reg.getClass().getName())) {
				if ((var2.contains(this.personAccountType) || var9) && this.reg.isValidUser(var1)) {
					var7.add(this.personAccountType);
				}

				var10 = var7.isEmpty() || this.groupAccountType.equals(var3);
				if (var10 && (var2.contains(this.groupAccountType) || var9) && this.reg.isValidGroup(var1)) {
					var7.add(this.groupAccountType);
				}
			} else {
				if (var2.contains(this.personAccountType) || var9) {
					var8 = this.searchUsers(var1, 1);
					if (var8 != null && var8.getList().size() > 0) {
						var7.add(this.personAccountType);
					}
				}

				var10 = var7.isEmpty() || this.groupAccountType.equals(var3);
				if (var10 && (var2.contains(this.groupAccountType) || var9)) {
					var8 = this.searchGroups(var1, 1);
					if (var8 != null && var8.getList().size() > 0) {
						var7.add(this.groupAccountType);
					}
				}
			}

			if (var7.size() > 1) {
				for (int var13 = 0; var13 < var7.size(); ++var13) {
					if (((String) var7.get(var13)).equals(var3)) {
						var6 = (String) var7.get(var13);
						break;
					}
				}
			}

			if (var6 == null && var7.size() > 0) {
				var6 = (String) var7.get(0);
			}
		} catch (CustomRegistryException var11) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1), Level.SEVERE,
					CLASSNAME, var4, var11);
		} catch (RemoteException var12) {
			throw new WIMApplicationException("CUSTOM_REGISTRY_EXCEPTION",
					WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, var4, var12);
		}

		if (var5) {
			trcLogger.logp(Level.FINER, CLASSNAME, var4, "The entity type for " + var1 + " is " + var6);
		}

		return var6;
	}

	private String getSecNameFromUniqueID(String var1) throws WIMException {
		String var2 = "getSecNameFromUniqueID";
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		String var4 = null;

		try {
			var4 = this.getUserSecurityName(var1);
		} catch (EntryNotFoundException var10) {
			try {
				var4 = this.getGroupSecurityName(var1);
			} catch (EntryNotFoundException var7) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						Level.SEVERE, CLASSNAME, var2, var10);
			} catch (CustomRegistryException var8) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						Level.SEVERE, CLASSNAME, var2, var10);
			} catch (RemoteException var9) {
				throw new WIMApplicationException("CUSTOM_REGISTRY_EXCEPTION",
						WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, var2, var9);
			}
		} catch (CustomRegistryException var11) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1), Level.SEVERE,
					CLASSNAME, var2, var11);
		} catch (RemoteException var12) {
			throw new WIMApplicationException("CUSTOM_REGISTRY_EXCEPTION",
					WIMMessageHelper.generateMsgParms(this.reposId), Level.WARNING, CLASSNAME, var2, var12);
		}

		if (var3) {
			trcLogger.logp(Level.FINER, CLASSNAME, var2, "The Security Name for " + var1 + " is " + var4);
		}

		return var4;
	}

	public DataObject getSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI getSchema", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var3 = this.schemaMgr.createRootDataObject();
		DataObject var4 = var3.getDataObject("schema");
		if (var4 == null) {
			var4 = var3.createDataObject("schema");
		}

		Map var5 = ControlsHelper.getControlMap(var1);
		DataObject var6 = (DataObject) var5.get("DataTypeControl");
		DataObject var7 = (DataObject) var5.get("PropertyDefinitionControl");
		DataObject var8 = (DataObject) var5.get("EntityTypeControl");
		List var9 = this.getRepoSupportedEntityTypes();
		if (var6 != null) {
			this.schemaMgr.getSupportedDataTypes(var4);
		} else {
			String var15;
			if (var8 != null) {
				List var10 = var8.getList("entityTypeNames");
				int var11;
				String var14;
				if (var10 != null && var10.size() != 0) {
					for (var11 = 0; var11 < var10.size(); ++var11) {
						String var22 = (String) var10.get(var11);
						if (var22.startsWith("wim:")) {
							var22 = this.schemaMgr.getTypeName(var22);
						}

						if (var9.contains(var22)) {
							DataObject var25 = var4.createDataObject("entitySchema");
							var14 = this.schemaMgr.getTypeNsURI(var22);
							var15 = this.schemaMgr.getNsPrefix(var14);
							var25.set("entityName", this.schemaMgr.getTypeName(var22));
							var25.set("nsURI", var14);
							var25.set("nsPrefix", var15);
						} else if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "getSchema",
									"The entity type " + var22 + " is not supported in repository " + this.reposId);
						}
					}
				} else if (var9 != null && var9.size() > 0) {
					for (var11 = 0; var11 < var9.size(); ++var11) {
						DataObject var12 = var4.createDataObject("entitySchema");
						String var13 = (String) var9.get(var11);
						var14 = this.schemaMgr.getTypeNsURI(var13);
						var15 = this.schemaMgr.getNsPrefix(var14);
						var12.set("entityName", this.schemaMgr.getTypeName(var13));
						var12.set("nsURI", var14);
						var12.set("nsPrefix", var15);
					}
				}
			} else if (var7 != null) {
				String var21 = var7.getString("entityTypeName");
				if (var21.startsWith("wim:")) {
					var21 = this.schemaMgr.getTypeName(var21);
				}

				if (var9.contains(var21)) {
					String var23 = null;
					List var24 = this.getAttributes(var21);
					List var26 = var7.getList("propertyNames");
					int var27;
					if (var26 != null && var26.size() > 0) {
						if (var24 != null) {
							for (var27 = 0; var27 < var26.size(); ++var27) {
								boolean var28 = false;
								var23 = (String) var26.get(var27);
								if (var23.startsWith("wim:")) {
									var23 = this.schemaMgr.getTypeName(var23);
								}

								for (int var29 = 0; var29 < var24.size(); ++var29) {
									String var30 = (String) var24.get(var29);
									if (var30.equals(var23)) {
										var28 = true;
										String var18 = this.schemaMgr.getTypeNsURI(var23);
										String var19 = this.schemaMgr.getNsPrefix(var18);
										DataObject var20 = var4.createDataObject("propertySchema");
										var20.setString("propertyName", this.schemaMgr.getTypeName(var23));
										var20.setString("nsURI", var18);
										var20.setString("nsPrefix", var19);
										break;
									}
								}

								if (!var28) {
									throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
											WIMMessageHelper.generateMsgParms(var23, var21), CLASSNAME, "getSchema");
								}
							}
						}
					} else {
						for (var27 = 0; var24 != null && !var24.isEmpty() && var27 < var24.size(); ++var27) {
							var23 = (String) var24.get(var27);
							if (var23 != null) {
								var15 = this.schemaMgr.getTypeNsURI(var23);
								String var16 = this.schemaMgr.getNsPrefix(var15);
								DataObject var17 = var4.createDataObject("propertySchema");
								var17.setString("propertyName", this.schemaMgr.getTypeName(var23));
								var17.setString("nsURI", var15);
								var17.setString("nsPrefix", var16);
							}
						}
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI getSchema", WIMTraceHelper.printDataObject(var3));
		}

		return var3;
	}

	public DataObject createSchema(DataObject var1) throws WIMException {
		throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
				WIMMessageHelper.generateMsgParms("createSchema", this.reposId), CLASSNAME, "createSchema");
	}

	public List getSupportedEntityTypes() throws WIMException {
		ConfigManager var1 = ConfigManager.singleton();
		return var1.getSupportedEntityTypes();
	}

	public UserRegistry getRegistry() {
		return this.reg;
	}

	private String getRDN(String var1) {
		if (var1 == null) {
			return var1;
		} else {
			int var2 = var1.indexOf(61);
			if (var2 < 0) {
				return var1;
			} else {
				String var3 = var1.substring(0, var2);
				return var3;
			}
		}
	}

	private List getRepoSupportedEntityTypes() throws WIMException {
		ArrayList var1 = new ArrayList(this.getSupportedEntityTypes());
		Iterator var2 = var1.iterator();

		while (var2.hasNext()) {
			String var3 = (String) var2.next();
			if (!URBridgeHelper.isSuperType("Group", var3) && !URBridgeHelper.isSuperType("PersonAccount", var3)) {
				var2.remove();
			}
		}

		return var1;
	}

	private ICacheUtil getUserSearchCache() {
		if (this.userSearchCache == null) {
			this.createUserSearchCache();
		}

		return this.userSearchCache;
	}

	private void createUserSearchCache() {
		if (this.userSearchCacheEnabled) {
			if (FactoryManager.getCacheUtil().isCacheAvailable()) {
				this.userSearchCache = FactoryManager.getCacheUtil().initialize(this.userSearchCacheName,
						this.cacheSize, false);
				if (this.userSearchCache != null && trcLogger.isLoggable(Level.FINE)) {
					StringBuffer var1 = new StringBuffer();
					var1.append("\tUser Search Results Cache: ").append(this.userSearchCacheName)
							.append(" is enabled:\n");
					var1.append("\tCacheSize: ").append(this.cacheSize).append("\n");
					var1.append("\tCacheTimeOut: ").append(this.cacheTimeout).append("\n");
					var1.append("\tCacheDistPolicy: ").append(this.sharedPushPolicy);
					trcLogger.logp(Level.FINER, CLASSNAME, "createUserSearchCache", var1.toString());
				}
			} else {
				this.userSearchCacheEnabled = false;
			}
		}

	}

	private ICacheUtil getGroupSearchCache() {
		if (this.groupSearchCache == null) {
			this.createGroupSearchCache();
		}

		return this.groupSearchCache;
	}

	private void createGroupSearchCache() {
		if (this.groupSearchCacheEnabled) {
			if (FactoryManager.getCacheUtil().isCacheAvailable()) {
				this.groupSearchCache = FactoryManager.getCacheUtil().initialize(this.groupSearchCacheName,
						this.cacheSize, false);
				if (this.groupSearchCache != null && trcLogger.isLoggable(Level.FINE)) {
					StringBuffer var1 = new StringBuffer();
					var1.append("\tGroup Search Results Cache: ").append(this.groupSearchCacheName)
							.append(" is enabled:\n");
					var1.append("\tCacheSize: ").append(this.cacheSize).append("\n");
					var1.append("\tCacheTimeOut: ").append(this.cacheTimeout).append("\n");
					var1.append("\tCacheDistPolicy: ").append(this.sharedPushPolicy);
					trcLogger.logp(Level.FINER, CLASSNAME, "createGroupSearchCache", var1.toString());
				}
			} else {
				this.groupSearchCacheEnabled = false;
			}
		}

	}

	private ICacheUtil getUserSecurityNameCache() {
		if (this.userSecurityNameCache == null) {
			this.createUserSecurityNameSearchCache();
		}

		return this.userSecurityNameCache;
	}

	private void createUserSecurityNameSearchCache() {
		if (this.userSecurityNameCacheEnabled) {
			if (FactoryManager.getCacheUtil().isCacheAvailable()) {
				this.userSecurityNameCache = FactoryManager.getCacheUtil().initialize(this.userSecurityNameCacheName,
						this.cacheSize, false);
				if (this.userSecurityNameCache != null && trcLogger.isLoggable(Level.FINE)) {
					StringBuffer var1 = new StringBuffer();
					var1.append("\tUser SecurityName Results Cache: ").append(this.userSecurityNameCacheName)
							.append(" is enabled:\n");
					var1.append("\tCacheSize: ").append(this.cacheSize).append("\n");
					var1.append("\tCacheTimeOut: ").append(this.cacheTimeout).append("\n");
					var1.append("\tCacheDistPolicy: ").append(this.sharedPushPolicy);
					trcLogger.logp(Level.FINER, CLASSNAME, "createUserSecurityNameSearchCache", var1.toString());
				}
			} else {
				this.userSecurityNameCacheEnabled = false;
			}
		}

	}

	private ICacheUtil getGroupSecurityNameCache() {
		if (this.groupSecurityNameCache == null) {
			this.createGroupSecurityNameSearchCache();
		}

		return this.groupSecurityNameCache;
	}

	private void createGroupSecurityNameSearchCache() {
		if (this.groupSecurityNameCacheEnabled) {
			if (FactoryManager.getCacheUtil().isCacheAvailable()) {
				this.groupSecurityNameCache = FactoryManager.getCacheUtil().initialize(this.groupSecurityNameCacheName,
						this.cacheSize, false);
				if (this.groupSecurityNameCache != null && trcLogger.isLoggable(Level.FINE)) {
					StringBuffer var1 = new StringBuffer();
					var1.append("\tGroup SecurityName Results Cache: ").append(this.groupSecurityNameCacheName)
							.append(" is enabled:\n");
					var1.append("\tCacheSize: ").append(this.cacheSize).append("\n");
					var1.append("\tCacheTimeOut: ").append(this.cacheTimeout).append("\n");
					var1.append("\tCacheDistPolicy: ").append(this.sharedPushPolicy);
					trcLogger.logp(Level.FINER, CLASSNAME, "createGroupSecurityNameSearchCache", var1.toString());
				}
			} else {
				this.groupSecurityNameCacheEnabled = false;
			}
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = URBridge.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}