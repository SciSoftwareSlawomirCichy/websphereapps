package com.ibm.bsf.test;

import com.ibm.bsf.BSFManager;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import junit.framework.TestCase;

public abstract class BSFEngineTestTmpl extends TestCase {
	protected BSFManager bsfManager;
	protected PrintStream sysOut;
	private PrintStream tmpOut;
	private ByteArrayOutputStream tmpBaos;

	public BSFEngineTestTmpl(String var1) {
		super(var1);
		this.sysOut = System.out;
		this.tmpBaos = new ByteArrayOutputStream();
		this.tmpOut = new PrintStream(this.tmpBaos);
	}

	public void setUp() {
		this.bsfManager = new BSFManager();
		System.setOut(this.tmpOut);
	}

	public void tearDown() {
		System.setOut(this.sysOut);
		this.resetTmpOut();
	}

	protected String getTmpOutStr() {
		return this.tmpBaos.toString();
	}

	protected void resetTmpOut() {
		this.tmpBaos.reset();
	}

	protected String failMessage(String var1, Exception var2) {
		String var3 = var1 + "\nReason:\n";
		var3 = var3 + var2.getMessage();
		var3 = var3 + "\n";
		return var3;
	}
}