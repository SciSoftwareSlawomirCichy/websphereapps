package com.google.common.graph;

import com.google.common.base.Preconditions;
import com.google.common.collect.AbstractIterator;
import com.google.common.collect.ImmutableSet;
import com.google.common.graph.EndpointPairIterator.1;
import com.google.common.graph.EndpointPairIterator.Directed;
import com.google.common.graph.EndpointPairIterator.Undirected;
import java.util.Iterator;

abstract class EndpointPairIterator<N> extends AbstractIterator<EndpointPair<N>> {
	private final BaseGraph<N> graph;
	private final Iterator<N> nodeIterator;
	protected N node;
	protected Iterator<N> successorIterator;

	static <N> EndpointPairIterator<N> of(BaseGraph<N> graph) {
      return (EndpointPairIterator)(graph.isDirected() ? new Directed(graph, (1)null) : new Undirected(graph, (1)null));
   }

	private EndpointPairIterator(BaseGraph<N> graph) {
		this.node = null;
		this.successorIterator = ImmutableSet.of().iterator();
		this.graph = graph;
		this.nodeIterator = graph.nodes().iterator();
	}

	protected final boolean advance() {
		Preconditions.checkState(!this.successorIterator.hasNext());
		if (!this.nodeIterator.hasNext()) {
			return false;
		} else {
			this.node = this.nodeIterator.next();
			this.successorIterator = this.graph.successors(this.node).iterator();
			return true;
		}
	}
}