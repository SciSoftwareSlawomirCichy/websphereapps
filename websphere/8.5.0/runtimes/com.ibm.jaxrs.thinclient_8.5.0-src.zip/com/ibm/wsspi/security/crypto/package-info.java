package com.ibm.wsspi.security.crypto;

interface package-info {
}