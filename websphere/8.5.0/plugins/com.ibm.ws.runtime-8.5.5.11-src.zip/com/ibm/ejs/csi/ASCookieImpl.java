package com.ibm.ejs.csi;

import com.ibm.ws.ActivitySession.ActivitySession;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import javax.transaction.Transaction;

final class ASCookieImpl implements UOWCookie {
	protected TxCookieImpl TxCookie;
	protected ActivitySessionStrategy asStrategy;
	protected ActivitySession suspendedAS;
	protected Transaction suspendedGlobalTx;
	protected boolean beginner;

	ASCookieImpl(boolean beginner, ActivitySessionStrategy asStrategy, ActivitySession suspendedAS,
			Transaction suspendedGlobalTx) {
		this.beginner = beginner;
		this.asStrategy = asStrategy;
		this.suspendedAS = suspendedAS;
		this.suspendedGlobalTx = suspendedGlobalTx;
		this.TxCookie = null;
	}

	public boolean beganTx() {
		return this.TxCookie != null ? this.TxCookie.beginner : false;
	}

	public boolean beganAS() {
		return this.beginner;
	}

	public boolean isLocalTx() {
		return this.TxCookie != null ? this.TxCookie.isLocal : false;
	}

	public SynchronizationRegistryUOWScope getTransactionalUOW() {
		return this.TxCookie != null ? this.TxCookie.getTransactionalUOW() : null;
	}

	public void setTransactionalUOW(SynchronizationRegistryUOWScope uowCoordinator) {
		this.TxCookie.setTransactionalUOW(uowCoordinator);
	}

	public SynchronizationRegistryUOWScope getSuspendedTransactionalUOW() {
		return this.TxCookie != null ? this.TxCookie.getSuspendedTransactionalUOW() : null;
	}
}