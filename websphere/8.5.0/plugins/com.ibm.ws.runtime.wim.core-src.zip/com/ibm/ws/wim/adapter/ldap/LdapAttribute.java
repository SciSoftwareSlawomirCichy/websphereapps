package com.ibm.ws.wim.adapter.ldap;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

public class LdapAttribute {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String iAttrName = null;
	private String iSyntax = "string";
	private Map iDefaultValueMap = null;
	private Map iDefaultAttrMap = null;
	private boolean iWIMGenerate = false;
	private Set iEntityTypes = null;

	public LdapAttribute(String var1) {
		this.iAttrName = var1;
		this.iEntityTypes = new HashSet();
	}

	public String getName() {
		return this.iAttrName;
	}

	public void setSyntax(String var1) {
		this.iSyntax = var1;
	}

	public String getSyntax() {
		return this.iSyntax;
	}

	public void setDefaultValue(String var1, String var2) {
		if (this.iDefaultValueMap == null) {
			this.iDefaultValueMap = new Hashtable();
		}

		this.iDefaultValueMap.put(var1, var2);
	}

	public Object getDefaultValue(String var1) {
		return this.iDefaultValueMap != null && this.iDefaultValueMap.size() > 0
				? this.iDefaultValueMap.get(var1)
				: null;
	}

	public void setDefaultAttribute(String var1, String var2) {
		if (this.iDefaultAttrMap == null) {
			this.iDefaultAttrMap = new Hashtable();
		}

		this.iDefaultAttrMap.put(var1, var2);
	}

	public String getDefaultAttribute(String var1) {
		return this.iDefaultAttrMap != null && this.iDefaultAttrMap.size() > 0
				? (String) this.iDefaultAttrMap.get(var1)
				: null;
	}

	public void setWIMGenerate(boolean var1) {
		this.iWIMGenerate = var1;
	}

	public boolean isWIMGenerate() {
		return this.iWIMGenerate;
	}

	public Set getEntityTypes() {
		return this.iEntityTypes;
	}

	public void addEntityType(String var1) {
		this.iEntityTypes.add(var1);
	}
}