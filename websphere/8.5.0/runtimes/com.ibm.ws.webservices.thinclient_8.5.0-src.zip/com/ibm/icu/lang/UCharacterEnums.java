package com.ibm.icu.lang;

public class UCharacterEnums {
}