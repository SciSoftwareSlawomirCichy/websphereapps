package com.google.inject;

import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.InternalContext;
import com.google.inject.internal.InternalFactory;
import com.google.inject.spi.Dependency;

class SingleParameterInjector<T> {
	private static final Object[] NO_ARGUMENTS = new Object[0];
	private final Dependency<T> dependency;
	private final InternalFactory<? extends T> factory;

	SingleParameterInjector(Dependency<T> dependency, InternalFactory<? extends T> factory) {
		this.dependency = dependency;
		this.factory = factory;
	}

	private T inject(Errors errors, InternalContext context) throws ErrorsException {
		context.setDependency(this.dependency);

		Object var3;
		try {
			var3 = this.factory.get(errors.withSource(this.dependency), context, this.dependency);
		} finally {
			context.setDependency((Dependency) null);
		}

		return var3;
	}

	static Object[] getAll(Errors errors, InternalContext context, SingleParameterInjector<?>[] parameterInjectors)
			throws ErrorsException {
		if (parameterInjectors == null) {
			return NO_ARGUMENTS;
		} else {
			int numErrorsBefore = errors.size();
			int size = parameterInjectors.length;
			Object[] parameters = new Object[size];

			for (int i = 0; i < size; ++i) {
				SingleParameterInjector parameterInjector = parameterInjectors[i];

				try {
					parameters[i] = parameterInjector.inject(errors, context);
				} catch (ErrorsException var9) {
					errors.merge(var9.getErrors());
				}
			}

			errors.throwIfNewErrors(numErrorsBefore);
			return parameters;
		}
	}
}