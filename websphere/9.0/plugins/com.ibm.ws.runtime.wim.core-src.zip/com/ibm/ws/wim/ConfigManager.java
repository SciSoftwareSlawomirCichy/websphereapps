package com.ibm.ws.wim;

import com.ibm.websphere.management.AdminContext;
import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.websphere.wim.DomainConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.management.profileregistry.ProfileRegistry;
import com.ibm.ws.management.profileregistry.ProfileRegistryFactory;
import com.ibm.ws.wim.management.DynamicReloadManager;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.WasVariableResolver;
import commonj.sdo.DataObject;
import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConfigManager extends ConfigManagerBase {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static Map<String, ConfigManager> singleton;

	private ConfigManager() throws WIMException {
	}

	public static synchronized ConfigManager singleton() throws WIMException {
		String var0 = DomainManagerUtils.getDomainId();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new ConfigManager());
		}

		return (ConfigManager) singleton.get(var0);
	}

	public static void clearCache(String var0) {
		singleton.put(var0, (Object) null);
	}

	public String getGlobalWIMHomePath() {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getGlobalWIMHomePath");
		}

		String var2 = "profileTemplates" + sFileSep + "default" + sFileSep + "documents" + sFileSep + "config"
				+ sFileSep + "cells" + sFileSep + "BaseApplicationServerCell" + sFileSep + "wim" + sFileSep;
		String var3 = System.getProperty("was.install.root");
		var2 = var3 + sFileSep + var2;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getGlobalWIMHomePath", "globalHomePath" + var2);
		}

		return var2;
	}

	public static String getConfigPathInCell() {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getConfigPathInCell");
		}

		String var1 = null;
		String var2 = DomainManagerUtils.getDomainName();
		if (var2.equals("admin")) {
			var1 = "cells" + sFileSep + DynamicReloadManager.getCellName() + sFileSep + "wim" + sFileSep + "config";
		} else {
			var1 = DomainConstants.RELATIVE_WIM_CONFIG_DOMAIN_PATH + sFileSep + DomainManagerUtils.getDomainName()
					+ sFileSep + "wim" + sFileSep + "config";
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getConfigPathInCell", "sConfigPath : " + var1);
		}

		return var1;
	}

	public void createSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createSchema");
		}

		if (!DynamicReloadManager.isConnectionTypeNone() && !DynamicReloadManager.isRunningOnDeploymentManager()
				&& !DynamicReloadManager.isRunningOnSingleServer() && !DynamicReloadManager.isRunningOnAdminAgent()
				&& !DynamicReloadManager.isRunningOnJobManager()) {
			throw new DynamicUpdateConfigException("DYNAMIC_RELOAD_INVALID_UPDATE_AT_MANAGED_NODE", CLASSNAME,
					"createSchema");
		} else {
			super.createSchema(var1);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "createSchema");
			}

		}
	}

	public String getCellName() {
		AdminService var2 = AdminServiceFactory.getAdminService();
		String var1;
		if (var2 != null) {
			var1 = var2.getCellName();
		} else {
			var1 = System.getProperty("local.cell");
		}

		return var1;
	}

	public String getCurrentContextCellDirectory() throws WIMException {
		String var1 = this.getCurrentContextConfigDirectory();
		return var1 + File.separator + "cells" + File.separator + this.getCellName();
	}

	public String getCurrentContextConfigDirectory() throws WIMException {
		String var2 = AdminContext.peek();
		if (var2 != null) {
			try {
				ProfileRegistry var3 = ProfileRegistryFactory.getRegistry();
				Map var4 = var3.lookupProfile(var2);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "getCurrentContextConfigDirectory", "ProfileData=" + var4);
				}

				return (String) var4.get("profile.registry.profile.root") + File.separator + "config";
			} catch (Exception var5) {
				throw new InitializationException("WAS_VARIABLE_NOT_RESOLVED",
						WIMMessageHelper.generateMsgParms("context config dir"), Level.SEVERE, CLASSNAME,
						"getCurrentContextConfigDirectory");
			}
		} else {
			return System.getProperty("was.repository.root");
		}
	}

	public String getNodeNameAARegisteredServer() throws WIMException {
		String var2 = AdminContext.peek();
		if (var2 != null) {
			try {
				ProfileRegistry var3 = ProfileRegistryFactory.getRegistry();
				Map var4 = var3.lookupProfile(var2);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "getNodeNameAARegisteredServer", "ProfileData=" + var4);
				}

				return (String) var4.get("profile.registry.node.name");
			} catch (Exception var5) {
				throw new InitializationException("WAS_VARIABLE_NOT_RESOLVED",
						WIMMessageHelper.generateMsgParms("node name"), Level.SEVERE, CLASSNAME,
						"getNodeNameAARegisteredServer");
			}
		} else {
			return null;
		}
	}

	public String getAdminAgentWASConfigDirectory() throws Exception {
		String var2 = null;
		boolean var3 = false;

		try {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "getAdminAgentWASConfigDirectory");
			}

			if (AdminContext.peek() != null) {
				var3 = AdminContext.push((String) null);
			}

			var2 = this.getWASConfigDirectory();
		} finally {
			if (var3) {
				AdminContext.pop();
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getAdminAgentWASConfigDirectory", "adminAgentConfigDir=" + var2);
		}

		return var2;
	}

	public String getWASConfigDirectory() throws Exception {
		boolean var2 = trcLogger.isLoggable(Level.FINE);
		String var3 = null;
		String var4 = this.getCellName();
		String var5 = System.getProperty("user.install.root");
		String var6 = this.getCurrentContextConfigDirectory();
		if (var2) {
			trcLogger.logp(Level.FINE, CLASSNAME, "getWASConfigDirectory",
					"cell=" + var4 + ", userInstallRoot=" + var5 + ", configRoot=" + var6);
		}

		if (var4 == null || var4.trim().length() == 0) {
			WasVariableResolver var7 = new WasVariableResolver();
			String var8 = var7.getVariableValue("WAS_INSTALL_ROOT");
			if (var2) {
				trcLogger.logp(Level.FINE, CLASSNAME, "getWASConfigDirectory", "WAS vars: WAS_INSTALL_ROOT=" + var8);
			}

			var4 = var7.getCellName();
			boolean var9 = false;

			try {
				if (AdminContext.peek() != null && var4 == null) {
					var9 = AdminContext.push((String) null);
					var4 = this.getCellName();
				}
			} finally {
				if (var9) {
					AdminContext.pop();
				}

			}

			if (var4 == null || var4.trim().length() == 0) {
				throw new InitializationException("WAS_VARIABLE_NOT_RESOLVED",
						WIMMessageHelper.generateMsgParms("local.cell"), Level.SEVERE, CLASSNAME,
						"getWASConfigDirectory");
			}
		}

		if (var6 != null) {
			var3 = var6 + File.separator + "cells" + File.separator + var4;
		} else {
			if (var5 == null) {
				throw new InitializationException("WAS_VARIABLE_NOT_RESOLVED",
						WIMMessageHelper.generateMsgParms("user.install.root"), Level.SEVERE, CLASSNAME,
						"getWASConfigDirectory");
			}

			var3 = var5 + File.separator + "config" + File.separator + "cells" + File.separator + var4;
		}

		if (var2) {
			trcLogger.logp(Level.FINER, CLASSNAME, "getWASConfigDirectory", "WAS Config Directory=" + var3);
		}

		return var3;
	}

	public String buildHomeDirectory() throws Exception {
		return this.getWASConfigDirectory() + File.separator + "wim" + File.separator;
	}

	String buildSchemaHomeDirectory() throws Exception {
		String var2 = System.getProperty("was.install.root");
		if (var2 == null) {
			throw new InitializationException("WAS_VARIABLE_NOT_RESOLVED",
					WIMMessageHelper.generateMsgParms("was.install.root"), Level.SEVERE, CLASSNAME,
					"buildSchemaHomeDirectory");
		} else {
			String var3 = var2 + File.separator + "etc" + File.separator + "wim" + File.separator + "schema"
					+ File.separator;
			File var4 = new File(var3);
			if (var4.isDirectory()) {
				return var3;
			} else {
				throw new InitializationException("DIRECTORY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var3),
						Level.SEVERE, CLASSNAME, "buildSchemaHomeDirectory");
			}
		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = ConfigManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
	}
}