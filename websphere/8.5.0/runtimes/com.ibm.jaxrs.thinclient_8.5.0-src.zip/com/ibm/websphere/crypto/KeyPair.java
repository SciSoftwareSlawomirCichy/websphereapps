package com.ibm.websphere.crypto;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.Serializable;
import java.security.Key;
import java.security.cert.Certificate;

public class KeyPair implements Serializable {
	private static final TraceComponent tc = Tr.register(KeyPair.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private Key privKey = null;
	private Key pubKey = null;
	private Certificate[] chain = null;

	public KeyPair(Certificate[] certChain, Key privateKey) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "KeyPair (cert)");
		}

		this.privKey = privateKey;
		this.chain = certChain;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "KeyPair");
		}

	}

	public KeyPair(Key publicKey, Key privateKey) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "KeyPair (no cert)");
		}

		this.privKey = privateKey;
		this.pubKey = publicKey;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "KeyPair");
		}

	}

	public Certificate[] getCertificateChain() {
		return this.chain;
	}

	public Certificate getCertificate() {
		return this.chain != null && this.chain[0] != null ? this.chain[0] : null;
	}

	public Key getPrivateKey() {
		return this.privKey;
	}

	public Key getPublicKey() {
		return (Key) (this.chain != null && this.chain[0] != null ? this.chain[0].getPublicKey() : this.pubKey);
	}
}