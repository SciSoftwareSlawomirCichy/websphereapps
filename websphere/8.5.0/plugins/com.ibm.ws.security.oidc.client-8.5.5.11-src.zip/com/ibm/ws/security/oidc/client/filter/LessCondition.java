package com.ibm.ws.security.oidc.client.filter;

public class LessCondition extends SimpleCondition {
	public LessCondition(String key, IValue value) {
		super(key, value);
	}

	public boolean checkCondition(IValue test) throws FilterException {
		return this.getValue().lessThan(test);
	}

	public String getOperand() {
		return "<";
	}
}