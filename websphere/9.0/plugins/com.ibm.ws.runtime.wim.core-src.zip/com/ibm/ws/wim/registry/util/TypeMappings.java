package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.RealmManager;
import com.ibm.ws.wim.registry.WIMUserRegistryDefines;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TypeMappings implements WIMUserRegistryDefines {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private final String className = TypeMappings.class.getName();
	private RealmManager realmManager = null;
	private BridgeUtils mappingUtils = BridgeUtils.singleton();
	private Logger wimUserRegistryMappingsTrace;

	public TypeMappings() {
		this.wimUserRegistryMappingsTrace = WIMLogger.getTraceLogger(this.className);
		String var1 = "TypeMappings";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var1);
		}

		try {
			this.realmManager = RealmManager.singleton();
		} catch (WIMException var3) {
			this.mappingUtils.logException(var3, this.className);
		}

		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var1);
		}

	}

	public String getInputUniqueUserId(String var1) {
		String var2 = "getInputUniqueUserId";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getInputMapping(var1, "uniqueUserIdMapping", "uniqueName");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getOutputUniqueUserId(String var1) {
		String var2 = "getOutputUniqueUserId";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getOutputMapping(var1, "uniqueUserIdMapping", "uniqueName");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getInputUserSecurityName(String var1) {
		String var2 = "getInputUserSecurityName";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getInputMapping(var1, "userSecurityNameMapping", "principalName");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getOutputUserSecurityName(String var1) {
		String var2 = "getOutputUserSecurityName";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getOutputMapping(var1, "userSecurityNameMapping", "principalName");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getInputUserDisplayName(String var1) {
		String var2 = "getInputUserDisplayName";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getInputMapping(var1, "userDisplayNameMapping", "principalName");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getOutputUserDisplayName(String var1) {
		String var2 = "getOutputUserDisplayName";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getOutputMapping(var1, "userDisplayNameMapping", "principalName");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getInputUniqueGroupId(String var1) {
		String var2 = "getInputUniqueGroupId";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getInputMapping(var1, "uniqueGroupIdMapping", "uniqueName");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getOutputUniqueGroupId(String var1) {
		String var2 = "getOutputUniqueGroupId";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getOutputMapping(var1, "uniqueGroupIdMapping", "uniqueName");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getInputGroupSecurityName(String var1) {
		String var2 = "getInputGroupSecurityName";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getInputMapping(var1, "groupSecurityNameMapping", "cn");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getOutputGroupSecurityName(String var1) {
		String var2 = "getOutputGroupSecurityName";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getOutputMapping(var1, "groupSecurityNameMapping", "cn");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getInputGroupDisplayName(String var1) {
		String var2 = "getInputGroupDisplayName";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getInputMapping(var1, "groupDisplayNameMapping", "cn");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getOutputGroupDisplayName(String var1) {
		String var2 = "getOutputGroupDisplayName";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var2, "inputVirtualRealm = \"" + var1 + "\"");
		}

		String var3 = this.getOutputMapping(var1, "groupDisplayNameMapping", "cn");
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	private String getInputMapping(String var1, String var2, String var3) {
		String var4 = "getInputMapping";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var4, "inputRealm = \"" + var1
					+ "\", inputProperty = \"" + var2 + "\", inputDefaultProperty = \"" + var3 + "\"");
		}

		String var5 = null;
		if (this.realmManager != null) {
			try {
				var5 = this.realmManager.getURMapInputPropertyInRealm(var1, var2);
				if (var5 == null || var5.equals("")) {
					var5 = var3;
				}
			} catch (WIMException var7) {
				var5 = var3;
				this.mappingUtils.logException(var7, this.className);
			}
		} else {
			var5 = var3;
		}

		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var4, "returnValue = \"" + var5 + "\"");
		}

		return var5;
	}

	private String getOutputMapping(String var1, String var2, String var3) {
		String var4 = "getOutputMapping";
		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.entering(this.className, var4, "inputRealm = \"" + var1
					+ "\", inputProperty = \"" + var2 + "\", inputDefaultProperty = \"" + var3 + "\"");
		}

		String var5 = null;
		if (this.realmManager != null) {
			try {
				var5 = this.realmManager.getURMapOutputPropertyInRealm(var1, var2);
				if (var5 == null || var5.equals("")) {
					var5 = var3;
				}
			} catch (WIMException var7) {
				var5 = var3;
				this.mappingUtils.logException(var7, this.className);
			}
		} else {
			var5 = var3;
		}

		if (this.wimUserRegistryMappingsTrace.isLoggable(Level.FINEST)) {
			this.wimUserRegistryMappingsTrace.exiting(this.className, var4, "returnValue = \"" + var5 + "\"");
		}

		return var5;
	}
}