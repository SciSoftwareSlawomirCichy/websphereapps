package com.ibm.ws.wim.security.authz.jacc;

import com.ibm.sec.authz.jaccx.condition.RequestContextHandler;
import java.util.Map;
import java.util.Set;

class RequestContextHandlerImpl implements RequestContextHandler {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String KEY_PREFIX = "com.ibm.websphere.wim.Context.";
	private Set supportedKeys;

	public RequestContextHandlerImpl(Set var1) {
		this.supportedKeys = var1;
	}

	public String[] getAttributeNames() {
		return (String[]) ((String[]) this.supportedKeys.toArray(new String[this.supportedKeys.size()]));
	}

	public boolean supports(String var1) {
		return this.supportedKeys.contains(var1);
	}

	public Object getAttribute(Object var1, String var2) {
		Map var3 = (Map) var1;
		Object var4 = null;
		if (var2.startsWith("com.ibm.websphere.wim.Context.")) {
			var4 = var3.get(var2.substring("com.ibm.websphere.wim.Context.".length()));
		}

		return var4 == null ? "$NON-APPLICABLE$" : var4;
	}
}