package com.ibm.ws.wim.env;

public interface IVariableResolver {
	String getVariableValue(String var1) throws Exception;
}