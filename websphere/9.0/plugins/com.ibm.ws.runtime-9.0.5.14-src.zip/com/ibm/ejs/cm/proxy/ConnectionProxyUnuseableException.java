package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.portability.PortableSQLException;

class ConnectionProxyUnuseableException extends PortableSQLException {
	private static final long serialVersionUID = 536622593017286613L;

	ConnectionProxyUnuseableException() {
		super("ConnectionProxy is unuseable");
	}
}