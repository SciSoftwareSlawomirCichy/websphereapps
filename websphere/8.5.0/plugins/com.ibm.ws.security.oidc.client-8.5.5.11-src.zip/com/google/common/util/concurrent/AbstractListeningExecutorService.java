package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.annotation.Nullable;

@Beta
public abstract class AbstractListeningExecutorService implements ListeningExecutorService {
	public ListenableFuture<?> submit(Runnable task) {
		ListenableFutureTask<Void> ftask = ListenableFutureTask.create(task, (Object) null);
		this.execute(ftask);
		return ftask;
	}

	public <T> ListenableFuture<T> submit(Runnable task, @Nullable T result) {
		ListenableFutureTask<T> ftask = ListenableFutureTask.create(task, result);
		this.execute(ftask);
		return ftask;
	}

	public <T> ListenableFuture<T> submit(Callable<T> task) {
		ListenableFutureTask<T> ftask = ListenableFutureTask.create(task);
		this.execute(ftask);
		return ftask;
	}

	public <T> T invokeAny(Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
		try {
			return MoreExecutors.invokeAnyImpl(this, tasks, false, 0L);
		} catch (TimeoutException var3) {
			throw new AssertionError();
		}
	}

	public <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
			throws InterruptedException, ExecutionException, TimeoutException {
		return MoreExecutors.invokeAnyImpl(this, tasks, true, unit.toNanos(timeout));
	}

	public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks) throws InterruptedException {
		if (tasks == null) {
			throw new NullPointerException();
		} else {
			List<Future<T>> futures = new ArrayList(tasks.size());
			boolean done = false;
			boolean var13 = false;

			ArrayList var17;
			try {
				var13 = true;
				Iterator i$ = tasks.iterator();

				while (i$.hasNext()) {
					Callable<T> t = (Callable) i$.next();
					ListenableFutureTask<T> f = ListenableFutureTask.create(t);
					futures.add(f);
					this.execute(f);
				}

				i$ = futures.iterator();

				while (true) {
					if (!i$.hasNext()) {
						done = true;
						var17 = futures;
						var13 = false;
						break;
					}

					Future<T> f = (Future) i$.next();
					if (!f.isDone()) {
						try {
							f.get();
						} catch (CancellationException var14) {
							;
						} catch (ExecutionException var15) {
							;
						}
					}
				}
			} finally {
				if (var13) {
					if (!done) {
						Iterator i$ = futures.iterator();

						while (i$.hasNext()) {
							Future<T> f = (Future) i$.next();
							f.cancel(true);
						}
					}

				}
			}

			if (!done) {
				Iterator i$ = futures.iterator();

				while (i$.hasNext()) {
					Future<T> f = (Future) i$.next();
					f.cancel(true);
				}
			}

			return var17;
		}
	}

	public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
			throws InterruptedException {
		if (tasks != null && unit != null) {
			long nanos = unit.toNanos(timeout);
			List<Future<T>> futures = new ArrayList(tasks.size());
			boolean done = false;
			boolean var25 = false;

			ArrayList var32;
			label268 : {
				ArrayList var15;
				label269 : {
					ArrayList var14;
					Iterator i$;
					Future f;
					label270 : {
						try {
							var25 = true;
							Iterator i$ = tasks.iterator();

							while (i$.hasNext()) {
								Callable<T> t = (Callable) i$.next();
								futures.add(ListenableFutureTask.create(t));
							}

							long lastTime = System.nanoTime();
							Iterator it = futures.iterator();

							while (it.hasNext()) {
								this.execute((Runnable) ((Runnable) it.next()));
								long now = System.nanoTime();
								nanos -= now - lastTime;
								lastTime = now;
								if (nanos <= 0L) {
									var14 = futures;
									var25 = false;
									break label270;
								}
							}

							Iterator i$ = futures.iterator();

							while (true) {
								if (!i$.hasNext()) {
									done = true;
									var32 = futures;
									var25 = false;
									break label268;
								}

								Future<T> f = (Future) i$.next();
								if (!f.isDone()) {
									if (nanos <= 0L) {
										var14 = futures;
										var25 = false;
										break;
									}

									try {
										f.get(nanos, TimeUnit.NANOSECONDS);
									} catch (CancellationException var26) {
										;
									} catch (ExecutionException var27) {
										;
									} catch (TimeoutException var28) {
										var15 = futures;
										var25 = false;
										break label269;
									}

									long now = System.nanoTime();
									nanos -= now - lastTime;
									lastTime = now;
								}
							}
						} finally {
							if (var25) {
								if (!done) {
									Iterator i$ = futures.iterator();

									while (i$.hasNext()) {
										Future<T> f = (Future) i$.next();
										f.cancel(true);
									}
								}

							}
						}

						if (!done) {
							i$ = futures.iterator();

							while (i$.hasNext()) {
								f = (Future) i$.next();
								f.cancel(true);
							}
						}

						return var14;
					}

					if (!done) {
						i$ = futures.iterator();

						while (i$.hasNext()) {
							f = (Future) i$.next();
							f.cancel(true);
						}
					}

					return var14;
				}

				if (!done) {
					Iterator i$ = futures.iterator();

					while (i$.hasNext()) {
						Future<T> f = (Future) i$.next();
						f.cancel(true);
					}
				}

				return var15;
			}

			if (!done) {
				Iterator i$ = futures.iterator();

				while (i$.hasNext()) {
					Future<T> f = (Future) i$.next();
					f.cancel(true);
				}
			}

			return var32;
		} else {
			throw new NullPointerException();
		}
	}
}