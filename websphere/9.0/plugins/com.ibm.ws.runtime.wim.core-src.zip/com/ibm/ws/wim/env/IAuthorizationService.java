package com.ibm.ws.wim.env;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.security.authz.Entitlement;
import com.ibm.ws.wim.security.authz.EntitlementRequest;
import com.ibm.ws.wim.security.authz.EntityResource;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.security.PrivilegedExceptionAction;
import java.util.Set;
import javax.security.auth.Subject;

public interface IAuthorizationService {
	void initialize(DataGraph var1) throws WIMException;

	void initialize(DataGraph var1, Object var2) throws WIMException;

	void refresh();

	void checkPermission_SuperUser(Entitlement var1) throws WIMException;

	boolean isCallerSuperUser() throws WIMException;

	void checkPermission_CREATE(EntityResource var1) throws WIMException;

	void checkPermission_DELETE(EntityResource var1, boolean var2) throws WIMException;

	void checkPermission_UPDATE(EntityResource var1) throws WIMException;

	DataObject checkPermission_GET(EntityResource var1) throws WIMException;

	DataObject checkPermission_LOGIN(EntityResource var1) throws WIMException;

	DataObject checkPermission_SEARCH(EntityResource var1, Entitlement var2) throws WIMException;

	Set getRoles(EntityResource var1) throws WIMException;

	boolean doesEntitlementExist(EntityResource var1, Entitlement var2) throws WIMException;

	Set getEntitlements(EntityResource var1, EntitlementRequest var2) throws WIMException;

	DataObject setEntitlements(DataObject var1, DataObject var2, EntitlementRequest var3) throws WIMException;

	void setRunAsSubject(Subject var1);

	Object runAsSuperUser(PrivilegedExceptionAction var1) throws WIMException;

	Object getAuthzPolicy();
}