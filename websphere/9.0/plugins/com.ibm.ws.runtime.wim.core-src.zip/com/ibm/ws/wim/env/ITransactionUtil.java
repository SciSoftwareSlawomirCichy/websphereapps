package com.ibm.ws.wim.env;

import com.ibm.ws.wim.EnvironmentManager;

public interface ITransactionUtil {
	Object getTransactionControl(Object var1, EnvironmentManager var2);

	boolean useTransaction(Object var1, EnvironmentManager var2);

	void closeTransaction(String var1, Object var2, Object var3, boolean var4);

	Object preinvoke(Object var1, boolean var2, boolean var3) throws Exception;
}