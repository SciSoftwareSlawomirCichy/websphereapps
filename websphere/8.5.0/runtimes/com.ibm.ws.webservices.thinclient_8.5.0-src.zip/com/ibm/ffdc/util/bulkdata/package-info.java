package com.ibm.ffdc.util.bulkdata;

interface package-info {
}