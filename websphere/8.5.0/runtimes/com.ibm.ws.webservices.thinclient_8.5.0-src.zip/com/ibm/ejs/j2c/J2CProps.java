package com.ibm.ejs.j2c;

import com.ibm.ejs.models.base.resources.J2EEResourceProperty;
import com.ibm.ejs.models.base.resources.ResourcesFactory;
import com.ibm.ejs.models.base.resources.ResourcesPackage;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.eclipse.emf.ecore.EPackage.Registry;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.jst.j2ee.jca.ConfigProperty;
import org.eclipse.jst.j2ee.jca.RequiredConfigPropertyType;
import org.eclipse.jst.j2ee.jca.internal.util.JCADescriptionHelper;

public class J2CProps {
	private static final TraceComponent TC = Tr.register(J2CProps.class, "WAS.j2c",
			"com.ibm.ws.j2c.resources.J2CAMessages");
	public static final String nl = System.getProperty("line.separator");
	public static boolean overrideRAProps = Boolean
			.valueOf(System.getProperty("com.ibm.ejs.j2c.overrideRAconfigProps"));

	J2CProps() {
		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			Tr.entry(TC, "<init>");
		}

	}

	public static List mergeRAProperties(List tier0, List tier1, List tier3, int versionId) {
		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			StringBuffer sb = new StringBuffer("mergeRAProperties");
			sb.append(nl);
			sb.append("  tier0     = <");
			sb.append(tier0 == null ? null : dumpList(tier0));
			sb.append("  >");
			sb.append(nl);
			sb.append("  tier1     = <");
			sb.append(tier1 == null ? null : dumpList(tier1));
			sb.append("  >");
			sb.append(nl);
			sb.append("  tier3     = <");
			sb.append(tier3 == null ? null : dumpList(tier3));
			sb.append("  >");
			sb.append(nl);
			sb.append("  versionId = <");
			sb.append(versionId);
			sb.append("  >");
			sb.append(nl);
			Tr.entry(TC, sb.toString());
		}

		List tier2 = null;
		if (tier0 != null) {
			List RAtier1 = convertCfgToJ2EE(tier1, versionId);
			tier2 = mergeProperty(tier0, RAtier1, tier3);
		}

		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			Tr.exit(TC, "mergeRAProperties returning tier2 = <" + tier2 + ">");
		}

		return tier2;
	}

	public static List mergeCFProperties(List tier0, List tier1, List RAtier2, int versionId) {
		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			StringBuffer sb = new StringBuffer("mergeCFProperties");
			sb.append(nl);
			sb.append("  tier0     = <");
			sb.append(tier0 == null ? null : dumpJ2EEResourcePropertyList(tier0));
			sb.append("  >");
			sb.append(nl);
			sb.append("  tier1     = <");
			sb.append(tier1 == null ? null : dumpList(tier1));
			sb.append("  >");
			sb.append(nl);
			sb.append("  RAtier2     = <");
			sb.append(RAtier2 == null ? null : dumpList(RAtier2));
			sb.append("  >");
			sb.append(nl);
			sb.append("  versionId = <");
			sb.append(versionId);
			sb.append("  >");
			sb.append(nl);
			Tr.entry(TC, sb.toString());
		}

		List tier2 = null;
		List RAtier1 = convertCfgToJ2EE(tier1, versionId);
		if (tier0 != null) {
			tier2 = mergeProperty(tier0, RAtier1, RAtier2);
		}

		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			Tr.exit(TC, "mergeCFProperties returning tier2 = <" + dumpJ2EEResourcePropertyList(tier2) + ">");
		}

		return tier2;
	}

	public static List mergeACProperties(List tier0, List reqprops, List RAtier2) {
		return mergeACProperties(tier0, reqprops, RAtier2, (List) null, 10);
	}

	public static List<J2EEResourceProperty> mergeACProperties(List<J2EEResourceProperty> introspectedProps,
			List<RequiredConfigPropertyType> requiredProps, List<J2EEResourceProperty> raProps,
			List<ConfigProperty> configProps, int versionId) {
		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			Tr.entry(TC, "mergeACProperties", versionId);
		}

		if (TraceComponent.isAnyTracingEnabled() && TC.isDebugEnabled()) {
			Tr.debug(TC, "introspectedProps = <" + dumpJ2EEResourcePropertyList(introspectedProps) + ">");
			Tr.debug(TC, "requiredProps = <" + dumpList(requiredProps) + ">");
			Tr.debug(TC, "raProps = <" + dumpJ2EEResourcePropertyList(raProps) + ">");
			Tr.debug(TC, "configProps = <" + configProps + ">");
		}

		List<J2EEResourceProperty> activationSpecProps = null;
		List<J2EEResourceProperty> xmlProps = null;
		if (versionId > 15 && configProps != null && configProps.size() > 0) {
			xmlProps = convertCfgToJ2EE(configProps, versionId);
		}

		activationSpecProps = mergeProperty(introspectedProps, raProps, xmlProps);
		Iterator i$ = requiredProps.iterator();

		while (i$.hasNext()) {
			RequiredConfigPropertyType requiredProp = (RequiredConfigPropertyType) i$.next();
			String name = requiredProp.getName();
			Iterator i$ = activationSpecProps.iterator();

			while (i$.hasNext()) {
				J2EEResourceProperty activationSpecProp = (J2EEResourceProperty) i$.next();
				if (equalsIgnoreFirst(name, activationSpecProp.getName())) {
					activationSpecProp.setRequired(true);
					String description = JCADescriptionHelper.getDescription(requiredProp, versionId);
					if (description != null) {
						activationSpecProp.setDescription(description);
					}
				}
			}

			Tr.warning(TC, "REQUIRED_PROPERTY_MISSING_J2CA0282", name);
		}

		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			Tr.exit(TC, "mergeACProperties returning activationSpecProps = <"
					+ dumpJ2EEResourcePropertyList(activationSpecProps) + ">");
		}

		return activationSpecProps;
	}

	public static List mergeAOProperties(List tier0, List tier1cfg, int versionId) {
		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			Tr.entry(TC, "mergeAOProperties");
			Tr.entry(TC, "  tier0    = <" + tier0 + ">");
			Tr.entry(TC, "  tier1cfg = <" + tier1cfg + ">");
			Tr.entry(TC, "  versionId = <" + versionId + ">");
		}

		List tier2 = null;
		List tier1 = convertCfgToJ2EE(tier1cfg, versionId);
		if (tier0 != null) {
			tier2 = mergeProperty(tier0, tier1, (List) null);
		}

		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			Tr.exit(TC, "mergeAOProperties returning tier2 = <" + tier2 + ">");
		}

		return tier2;
	}

	private static List mergeProperty(List inTier0, List xmlTier1, List raTier2) {
		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			StringBuffer sb = new StringBuffer("mergeProperty");
			sb.append(nl);
			sb.append("  inTier0     = <");
			sb.append(inTier0 == null ? null : dumpJ2EEResourcePropertyList(inTier0));
			sb.append("  >");
			sb.append(nl);
			sb.append("  xmlTier1     = <");
			sb.append(xmlTier1 == null ? null : dumpJ2EEResourcePropertyList(xmlTier1));
			sb.append("  >");
			sb.append(nl);
			sb.append("  raTier2     = <");
			sb.append(raTier2 == null ? null : dumpJ2EEResourcePropertyList(raTier2));
			sb.append("  >");
			sb.append(nl);
			Tr.entry(TC, sb.toString());
		}

		List outTier2 = new ArrayList(inTier0.size());
		outTier2.addAll(inTier0);
		int t2Size;
		int i;
		J2EEResourceProperty prop;
		String pname;
		int t0Size;
		String ptype;
		String type;
		if (xmlTier1 != null) {
			t2Size = xmlTier1.size();

			for (i = 0; i < t2Size; ++i) {
				prop = (J2EEResourceProperty) xmlTier1.get(i);
				if (prop != null) {
					pname = prop.getName();
					t0Size = inTier0.size();
					boolean foundMatch = false;

					for (int j = 0; j < t0Size && !foundMatch; ++j) {
						J2EEResourceProperty t0Prop = (J2EEResourceProperty) inTier0.get(j);
						ptype = t0Prop.getName();
						if (equalsIgnoreFirst(ptype, pname)) {
							foundMatch = true;
							type = prop.getValue();
							String pdescr;
							if (type != null && !type.equals("")) {
								pdescr = prop.getType();
								String type = ((J2EEResourceProperty) inTier0.get(j)).getType();
								if (type.equals(pdescr)) {
									prop.setName(pname);
									String pdescr = prop.getDescription();
									if (pdescr != null && !pdescr.equals("")) {
										t0Prop.setDescription(pdescr);
									}

									outTier2.set(j, prop);
								} else {
									Object[] parms = new Object[]{ptype, pdescr, type};
									Tr.warning(TC, "PROPERTY_TYPE_MISMATCH_J2CA0280", parms);
									outTier2.set(j, (J2EEResourceProperty) inTier0.get(j));
								}
							} else {
								t0Prop.setName(pname);
								pdescr = prop.getDescription();
								if (pdescr != null && !pdescr.equals("")) {
									t0Prop.setDescription(pdescr);
								}

								outTier2.set(j, t0Prop);
							}
						}
					}

					if (!foundMatch) {
						Tr.warning(TC, "PROPERTY_NOT_FOUND_J2CA0284", pname);
					}
				}
			}
		}

		if (raTier2 != null) {
			t2Size = raTier2.size();

			for (i = 0; i < t2Size; ++i) {
				prop = (J2EEResourceProperty) raTier2.get(i);
				if (prop != null) {
					pname = prop.getName();
					t0Size = inTier0.size();

					for (int j = 0; j < t0Size; ++j) {
						String name = ((J2EEResourceProperty) outTier2.get(j)).getName();
						if (equalsIgnoreFirst(name, pname)) {
							String pvalue = prop.getValue();
							if (pvalue != null && !pvalue.equals("")) {
								ptype = prop.getType();
								type = ((J2EEResourceProperty) inTier0.get(j)).getType();
								if (type.equals(ptype)) {
									if (overrideRAProps) {
										J2EEResourceProperty prop1 = (J2EEResourceProperty) EcoreUtil.copy(prop);
										outTier2.set(j, prop1);
									} else {
										outTier2.set(j, prop);
									}
								} else {
									Object[] parms = new Object[]{name, ptype, type};
									Tr.warning(TC, "PROPERTY_TYPE_MISMATCH_J2CA0281", parms);
									outTier2.set(j, (J2EEResourceProperty) inTier0.get(j));
								}
							}
						}
					}
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && TC.isEntryEnabled()) {
			Tr.exit(TC, "mergeProperty() returned:" + outTier2);
		}

		return outTier2;
	}

	private static List convertCfgToJ2EE(List configs, int versionId) {
		List j2eeList = new ArrayList(configs.size());
		int cSize = configs.size();

		for (int i = 0; i < cSize; ++i) {
			ConfigProperty prop = (ConfigProperty) configs.get(i);
			String ttype = prop.getType();
			if (!ttype.startsWith("java.lang")) {
				Tr.warning(TC, "MSG001 %1 is ignored because type is not java.lang.*", prop.getName());
			} else {
				ResourcesPackage respkg = (ResourcesPackage) Registry.INSTANCE
						.getEPackage("http://www.ibm.com/websphere/appserver/schemas/5.0/resources.xmi");
				ResourcesFactory resFact = respkg.getResourcesFactory();
				J2EEResourceProperty property = resFact.createJ2EEResourceProperty();
				String desc = JCADescriptionHelper.getDescription(prop, versionId);
				property.setDescription(desc);
				property.setName(prop.getName());
				property.setType(ttype);
				property.setValue(prop.getValue());
				j2eeList.add(property);
			}
		}

		return j2eeList;
	}

	public static boolean equalsIgnoreFirst(String s1, String s2) {
		int s1Len = s1.length();
		if (s1Len != s2.length()) {
			return false;
		} else {
			return s1.regionMatches(true, 0, s2, 0, 1) && s1.regionMatches(false, 1, s2, 1, s1Len - 1);
		}
	}

	private static String dumpList(List l) {
		StringBuffer sb = new StringBuffer();
		Iterator iter = l.iterator();

		while (iter.hasNext()) {
			sb.append(iter.next());
			sb.append(nl);
			sb.append("               ");
		}

		return sb.toString();
	}

	private static String dumpJ2EEResourcePropertyList(List l) {
		StringBuffer sb = new StringBuffer();
		if (l != null) {
			Iterator iter = l.iterator();

			while (iter.hasNext()) {
				J2EEResourceProperty j2eeRP = (J2EEResourceProperty) iter.next();
				sb.append(j2eeRP);
				String rpName = j2eeRP.getName();
				String rpType = j2eeRP.getType();
				String rpValue = j2eeRP.getValue();
				String rpDescription = j2eeRP.getDescription();
				sb.append(", name: ").append(rpName);
				sb.append(", description: ").append(rpDescription);
				sb.append(", type: ").append(rpType);
				sb.append(", value: ").append(rpValue);
				sb.append(nl);
			}
		} else {
			sb.append(l);
		}

		return sb.toString();
	}
}