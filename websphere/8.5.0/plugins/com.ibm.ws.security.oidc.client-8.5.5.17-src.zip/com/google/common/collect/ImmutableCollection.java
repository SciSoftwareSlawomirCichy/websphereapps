package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList.SerializedForm;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.Collection;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
public abstract class ImmutableCollection<E> extends AbstractCollection<E> implements Serializable {
	private static final Object[] EMPTY_ARRAY = new Object[0];

	public abstract UnmodifiableIterator<E> iterator();

	public final Object[] toArray() {
		return this.toArray(EMPTY_ARRAY);
	}

	@CanIgnoreReturnValue
	public final <T> T[] toArray(T[] other) {
		Preconditions.checkNotNull(other);
		int size = this.size();
		if (other.length < size) {
			Object[] internal = this.internalArray();
			if (internal != null) {
				return Platform.copy(internal, this.internalArrayStart(), this.internalArrayEnd(), other);
			}

			other = ObjectArrays.newArray(other, size);
		} else if (other.length > size) {
			other[size] = null;
		}

		this.copyIntoArray(other, 0);
		return other;
	}

	Object[] internalArray() {
		return null;
	}

	int internalArrayStart() {
		throw new UnsupportedOperationException();
	}

	int internalArrayEnd() {
		throw new UnsupportedOperationException();
	}

	public abstract boolean contains(@NullableDecl Object var1);

	@Deprecated
	@CanIgnoreReturnValue
	public final boolean add(E e) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final boolean remove(Object object) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final boolean addAll(Collection<? extends E> newElements) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final boolean removeAll(Collection<?> oldElements) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final boolean retainAll(Collection<?> elementsToKeep) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final void clear() {
		throw new UnsupportedOperationException();
	}

	public ImmutableList<E> asList() {
		return this.isEmpty() ? ImmutableList.of() : ImmutableList.asImmutableList(this.toArray());
	}

	abstract boolean isPartialView();

	@CanIgnoreReturnValue
	int copyIntoArray(Object[] dst, int offset) {
		Object e;
		for (UnmodifiableIterator var3 = this.iterator(); var3.hasNext(); dst[offset++] = e) {
			e = var3.next();
		}

		return offset;
	}

	Object writeReplace() {
		return new SerializedForm(this.toArray());
	}
}