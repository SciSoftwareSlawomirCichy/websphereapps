package com.ibm.icu.impl;

import com.ibm.icu.impl.SoftCache.1;
import com.ibm.icu.impl.SoftCache.SettableSoftReference;
import java.lang.ref.SoftReference;
import java.util.concurrent.ConcurrentHashMap;

public abstract class SoftCache<K, V, D> extends CacheBase<K, V, D> {
	private ConcurrentHashMap<K, SettableSoftReference<V>> map = new ConcurrentHashMap();

	public final V getInstance(K key, D data) {
      SettableSoftReference<V> valueRef = (SettableSoftReference)this.map.get(key);
      Object value;
      if (valueRef != null) {
         synchronized(valueRef) {
            value = SettableSoftReference.access$000(valueRef).get();
            if (value != null) {
               return value;
            } else {
               SettableSoftReference.access$002(valueRef, new SoftReference(value = this.createInstance(key, data)));
               return value;
            }
         }
      } else {
         value = this.createInstance(key, data);
         valueRef = (SettableSoftReference)this.map.putIfAbsent(key, new SettableSoftReference(value, (1)null));
         return valueRef == null ? value : SettableSoftReference.access$200(valueRef, value);
      }
   }
}