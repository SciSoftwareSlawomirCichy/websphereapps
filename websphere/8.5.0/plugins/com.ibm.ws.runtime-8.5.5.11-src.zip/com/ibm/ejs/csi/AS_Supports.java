package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.ws.ActivitySession.ActivitySession;
import javax.transaction.Transaction;

final class AS_Supports extends ActivitySessionStrategy {
	private static final TraceComponent tc = Tr.register(AS_Supports.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	AS_Supports(UOWControlImpl UOWCtrl) {
		super(UOWCtrl);
	}

	ASCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		return new ASCookieImpl(false, this, (ActivitySession) null, (Transaction) null);
	}

	void postInvoke(EJBKey key, ASCookieImpl ASCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		if (entryEnabled) {
			Tr.exit(tc, "postInvoke");
		}

	}
}