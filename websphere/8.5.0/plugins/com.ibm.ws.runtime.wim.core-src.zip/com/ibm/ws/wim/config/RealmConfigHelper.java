package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmDefaultParentType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.UserRegistryInfoMappingType;
import com.ibm.ws.wim.util.StringUtil;
import com.ibm.ws.wim.util.UniqueNameHelper;
import commonj.sdo.DataObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RealmConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public String setIdMgrDefaultRealm(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setIdMgrDefaultRealm", "name=" + var2);
		}

		RealmConfigurationType var5 = ConfigUtils.getRealmConfig(var1);
		String var6 = var5.getDefaultRealm();
		if (var4) {
			trcLogger.logp(Level.FINER, CLASSNAME, "setIdMgrDefaultRealm", "current realm name=" + var6);
		}

		ConfigUtils.getRealm(var2, var5);
		var5.setDefaultRealm(var2);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "setIdMgrDefaultRealm");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public String getIdMgrDefaultRealm(String var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getIdMgrDefaultRealm");
		}

		String var4 = null;
		RealmConfigurationType var5 = ConfigUtils.getRealmConfig(var1);
		var4 = var5.getDefaultRealm();
		if (var3) {
			trcLogger.exiting(CLASSNAME, "getIdMgrDefaultRealm", "name=" + var4);
		}

		return var4;
	}

	public String createIdMgrRealm(String var1, Map var2) throws Exception {
		String var4 = (String) var2.get("name");
		String var5 = (String) var2.get("securityUse");
		String var6 = (String) var2.get("delimiter");
		boolean var7 = (Boolean) var2.get("allowOperationIfReposDown");
		boolean var8 = trcLogger.isLoggable(Level.FINER);
		if (var8) {
			trcLogger.entering(CLASSNAME, "createIdMgrRealm", "name=" + var4 + " securityUse=" + var5 + " delimiter="
					+ var6 + " allowOperationIfReposDown=" + var7);
		}

		if (var5 != null) {
			ValidationHelper.validateParam("securityUse", var5, CONFIG_REALM_SECURITY_USE_VALUES);
		}

		RealmConfigurationType var9 = ConfigUtils.getOrCreateRealmConfig(var1);
		RealmType var10 = ConfigUtils.getRealm(var4, var9, false);
		if (var10 != null) {
			throw new WIMConfigurationException("REALM_ALREADY_EXISTS", WIMMessageHelper.generateMsgParms(var4),
					Level.SEVERE, CLASSNAME, "createIdMgrRealm");
		} else {
			var10 = var9.createRealms();
			var10.setName(var4);
			if (var6 != null) {
				var10.setDelimiter(var6);
			}

			if (var5 != null) {
				var10.setSecurityUse(var5);
			}

			this.setDefaultUserRegistryMapping(var10);
			var10.setAllowOperationIfReposDown(var7);
			if (var8) {
				trcLogger.exiting(CLASSNAME, "createIdMgrRealm");
			}

			ConfigUtils.saveConfig(var1);
			return "MUST_ADD_BASE_ENTRY_TO_REALM";
		}
	}

	private void setDefaultUserRegistryMapping(RealmType var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "setDefaultUserRegistryMapping");
		}

		UserRegistryInfoMappingType var4 = var1.createUniqueUserIdMapping();
		var4.setPropertyForInput("uniqueName");
		var4.setPropertyForOutput("uniqueName");
		var4 = var1.createUserSecurityNameMapping();
		var4.setPropertyForInput("principalName");
		var4.setPropertyForOutput("externalName");
		var4 = var1.createUserDisplayNameMapping();
		var4.setPropertyForInput("principalName");
		var4.setPropertyForOutput("principalName");
		var4 = var1.createUniqueGroupIdMapping();
		var4.setPropertyForInput("uniqueName");
		var4.setPropertyForOutput("uniqueName");
		var4 = var1.createGroupSecurityNameMapping();
		var4.setPropertyForInput("cn");
		var4.setPropertyForOutput("externalName");
		var4 = var1.createGroupDisplayNameMapping();
		var4.setPropertyForInput("cn");
		var4.setPropertyForOutput("cn");
		if (var3) {
			trcLogger.exiting(CLASSNAME, "setDefaultUserRegistryMapping");
		}

	}

	public String updateIdMgrRealm(String var1, Map var2) throws Exception {
		String var4 = (String) var2.get("name");
		String var5 = (String) var2.get("securityUse");
		String var6 = (String) var2.get("delimiter");
		Boolean var7 = (Boolean) var2.get("allowOperationIfReposDown");
		boolean var8 = trcLogger.isLoggable(Level.FINER);
		if (var8) {
			trcLogger.entering(CLASSNAME, "updateIdMgrRealm", "name=" + var4 + ", securityUse=" + var5 + ", delimiter="
					+ var6 + ", allowOperationIfReposDown=" + var7);
		}

		RealmConfigurationType var9 = ConfigUtils.getRealmConfig(var1);
		RealmType var10 = ConfigUtils.getRealm(var4, var9);
		if (var5 != null) {
			ValidationHelper.validateParam("securityUse", var5, CONFIG_REALM_SECURITY_USE_VALUES);
			var10.setSecurityUse(var5);
		}

		if (var6 != null) {
			var10.setDelimiter(var6);
		}

		if (var7 != null) {
			var10.setAllowOperationIfReposDown(var7);
		}

		if (var8) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrRealm");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public String deleteIdMgrRealm(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrRealm", "name=" + var2);
		}

		RealmConfigurationType var5 = ConfigUtils.getRealmConfig(var1);
		RealmType var6 = ConfigUtils.getRealm(var2, var5);
		ConfigValidator.validateDeleteIdMgrRealm(ConfigUtils.getConfigProvider(var1), var2);
		((DataObject) var6).delete();
		String var7 = var5.getDefaultRealm();
		if (var2.equals(var7)) {
			if (var4) {
				trcLogger.logp(Level.FINER, CLASSNAME, "deleteIdMgrRealm", "resetting the default realm name.");
			}

			var5.setDefaultRealm((String) null);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrRealm");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public String renameIdMgrRealm(String var1, String var2, String var3) throws Exception {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "renameIdMgrRealm", "name=" + var2 + " newName=" + var3);
		}

		RealmConfigurationType var6 = ConfigUtils.getRealmConfig(var1);
		RealmType var7 = ConfigUtils.getRealm(var2, var6);
		RealmType var8 = ConfigUtils.getRealm(var3, var6, false);
		if (var8 != null) {
			throw new WIMConfigurationException("REALM_ALREADY_EXISTS", WIMMessageHelper.generateMsgParms(var3),
					Level.SEVERE, CLASSNAME, "renameIdMgrRealm");
		} else {
			var7.setName(var3);
			String var9 = this.getIdMgrDefaultRealm(var1);
			if (var2.equals(var9)) {
				this.setIdMgrDefaultRealm(var1, var3);
			}

			if (var5) {
				trcLogger.exiting(CLASSNAME, "renameIdMgrRealm");
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public List listIdMgrRealms(String var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "listIdMgrRealms");
		}

		RealmConfigurationType var4 = ConfigUtils.getRealmConfig(var1);
		Vector var5 = new Vector();
		List var6 = var4.getRealms();

		for (int var7 = 0; var7 < var6.size(); ++var7) {
			RealmType var8 = (RealmType) var6.get(var7);
			var5.add(var8.getName());
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "listIdMgrRealms", "realms=" + var5);
		}

		return var5;
	}

	public Map getIdMgrRealm(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrRealm", "realmName=" + var2);
		}

		RealmConfigurationType var5 = ConfigUtils.getRealmConfig(var1);
		RealmType var6 = ConfigUtils.getRealm(var2, var5);
		HashMap var7 = new HashMap();
		var7.put("name", var6.getName());
		if (var6.getSecurityUse() != null) {
			var7.put("securityUse", var6.getSecurityUse());
		}

		if (var6.getDelimiter() != null) {
			var7.put("delimiter", var6.getDelimiter());
		}

		var7.put("allowOperationIfReposDown", var6.isAllowOperationIfReposDown());
		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrRealm", "realms=" + var7);
		}

		return var7;
	}

	public String addIdMgrRealmBaseEntry(String var1, String var2, String var3) throws Exception {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "addIdMgrRealmBaseEntry", "name=" + var2 + " baseEntry=" + var3);
		}

		if (var3.equalsIgnoreCase("root")) {
			var3 = "";
		}

		String var6 = UniqueNameHelper.getValidUniqueName(var3);
		RealmConfigurationType var7 = ConfigUtils.getRealmConfig(var1);
		RealmType var8 = ConfigUtils.getRealm(var2, var7);
		ConfigValidator.validateAddIdMgrRealmBaseEntry(ConfigUtils.getConfigProvider(var1), var2, var6);
		ParticipatingBaseEntriesType var9 = var8.createParticipatingBaseEntries();
		var9.setName(var6);
		if (var5) {
			trcLogger.exiting(CLASSNAME, "addIdMgrRealmBaseEntry");
		}

		return ConfigUtils.saveConfig(var1);
	}

	private boolean baseEntryInRealm(RealmType var1, String var2) {
		boolean var3 = false;
		List var4 = var1.getParticipatingBaseEntries();

		for (int var5 = 0; var5 < var4.size(); ++var5) {
			ParticipatingBaseEntriesType var6 = (ParticipatingBaseEntriesType) var4.get(var5);
			if (var2.equals(var6.getName())) {
				var3 = true;
				break;
			}
		}

		return var3;
	}

	public String deleteIdMgrRealmBaseEntry(String var1, String var2, String var3) throws Exception {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrRealmBaseEntry", "name=" + var2 + " baseEntry=" + var3);
		}

		if (var3.equalsIgnoreCase("root")) {
			var3 = "";
		}

		String var6 = UniqueNameHelper.getValidUniqueName(var3);
		RealmConfigurationType var7 = ConfigUtils.getRealmConfig(var1);
		RealmType var8 = ConfigUtils.getRealm(var2, var7);
		ParticipatingBaseEntriesType var9 = ConfigUtils.getBaseEntryInRealm(var6, var8);
		ConfigValidator.validateDeleteIdMgrRealmBaseEntry(ConfigUtils.getConfigProvider(var1), var2, var6);
		((DataObject) var9).delete();
		if (var5) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrRealmBaseEntry");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List listIdMgrRealmBaseEntries(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrRealmBaseEntries", "name=" + var2);
		}

		RealmConfigurationType var5 = ConfigUtils.getRealmConfig(var1);
		RealmType var6 = ConfigUtils.getRealm(var2, var5);
		Vector var7 = new Vector();
		List var8 = var6.getParticipatingBaseEntries();

		for (int var9 = 0; var9 < var8.size(); ++var9) {
			ParticipatingBaseEntriesType var10 = (ParticipatingBaseEntriesType) var8.get(var9);
			String var11 = var10.getName();
			if (var11.equals("")) {
				var11 = "root";
			}

			var7.add(var11);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "listIdMgrRealmBaseEntries", "returning: " + var7);
		}

		return var7;
	}

	public List getIdMgrRepositoriesForRealm(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrRepositoriesForRealm", "realmName=" + var2);
		}

		ArrayList var5 = new ArrayList();
		List var6 = this.listIdMgrRealmBaseEntries(var1, var2);

		for (int var7 = 0; var7 < var6.size(); ++var7) {
			String var8 = (String) var6.get(var7);
			Map var9 = this.getInformationForBaseEntry(var1, var8);
			var5.add(var9);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrRepositoriesForRealm", "repositoriesForRealm=" + var5);
		}

		return var5;
	}

	public Map listIdMgrRealmURAttrMappings(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrRealmURAttrMappings", "realmName = " + var2);
		}

		RealmConfigurationType var5 = ConfigUtils.getRealmConfig(var1);
		String var6 = var2;
		if (var2 == null) {
			var6 = var5.getDefaultRealm();
			if (var4) {
				trcLogger.logp(Level.FINER, CLASSNAME, "listIdMgrRealmURAttrMappings", "The default realm = " + var6);
			}
		}

		RealmType var7 = ConfigUtils.getRealm(var6, var5);
		HashMap var8 = new HashMap();
		HashMap var9 = new HashMap();
		var9.put("propertyForInput", var7.getUniqueGroupIdMapping().getPropertyForInput());
		var9.put("propertyForOutput", var7.getUniqueGroupIdMapping().getPropertyForOutput());
		var8.put("uniqueGroupId", var9);
		var9 = new HashMap();
		var9.put("propertyForInput", var7.getGroupDisplayNameMapping().getPropertyForInput());
		var9.put("propertyForOutput", var7.getGroupDisplayNameMapping().getPropertyForOutput());
		var8.put("groupDisplayName", var9);
		var9 = new HashMap();
		var9.put("propertyForInput", var7.getGroupSecurityNameMapping().getPropertyForInput());
		var9.put("propertyForOutput", var7.getGroupSecurityNameMapping().getPropertyForOutput());
		var8.put("groupSecurityName", var9);
		var9 = new HashMap();
		var9.put("propertyForInput", var7.getUniqueUserIdMapping().getPropertyForInput());
		var9.put("propertyForOutput", var7.getUniqueUserIdMapping().getPropertyForOutput());
		var8.put("uniqueUserId", var9);
		var9 = new HashMap();
		var9.put("propertyForInput", var7.getUserDisplayNameMapping().getPropertyForInput());
		var9.put("propertyForOutput", var7.getUserDisplayNameMapping().getPropertyForOutput());
		var8.put("userDisplayName", var9);
		var9 = new HashMap();
		var9.put("propertyForInput", var7.getUserSecurityNameMapping().getPropertyForInput());
		var9.put("propertyForOutput", var7.getUserSecurityNameMapping().getPropertyForOutput());
		var8.put("userSecurityName", var9);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "listIdMgrRealmURAttrMappings", "returnMap = " + var8);
		}

		return var8;
	}

	public String setIdMgrRealmURAttrMapping(String var1, String var2, String var3, String var4, String var5)
			throws Exception {
		boolean var7 = trcLogger.isLoggable(Level.FINER);
		if (var7) {
			trcLogger.entering(CLASSNAME, "setIdMgrRealmURAttrMapping", "realmName = " + var2 + ", URAttrName = " + var3
					+ ", propertyForInput = " + var4 + ", propertyForOutput = " + var5);
		}

		RealmConfigurationType var8 = ConfigUtils.getRealmConfig(var1);
		String var9 = var2;
		if (var2 == null) {
			var9 = var8.getDefaultRealm();
			if (var7) {
				trcLogger.logp(Level.FINER, CLASSNAME, "setIdMgrRealmURAttrMapping", "The default realm = " + var9);
			}
		}

		this.validateInputParams(var3, var4, var5);
		RealmType var10 = ConfigUtils.getRealm(var9, var8);
		UserRegistryInfoMappingType var11 = null;
		if ("uniqueUserId".equals(var3)) {
			var11 = var10.createUniqueUserIdMapping();
		} else if ("userDisplayName".equals(var3)) {
			var11 = var10.createUserDisplayNameMapping();
		} else if ("userSecurityName".equals(var3)) {
			var11 = var10.createUserSecurityNameMapping();
		} else if ("uniqueGroupId".equals(var3)) {
			var11 = var10.createUniqueGroupIdMapping();
		} else if ("groupDisplayName".equals(var3)) {
			var11 = var10.createGroupDisplayNameMapping();
		} else if ("groupSecurityName".equals(var3)) {
			var11 = var10.createGroupSecurityNameMapping();
		}

		var11.setPropertyForInput(var4);
		var11.setPropertyForOutput(var5);
		if (var7) {
			trcLogger.exiting(CLASSNAME, "setIdMgrRealmURAttrMapping");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public static String deleteIdMgrRealmDefaultParent(String var0, String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrRealmDefaultParent", "name=" + var1 + ",entityTypeName=" + var2);
		}

		RealmConfigurationType var5 = ConfigUtils.getRealmConfig(var0);
		String var6 = var1;
		if (var1 == null) {
			var6 = var5.getDefaultRealm();
			if (var4) {
				trcLogger.logp(Level.FINER, CLASSNAME, "deleteIdMgrRealmDefaultParent", "The default realm = " + var6);
			}
		}

		RealmType var7 = ConfigUtils.getRealm(var6, var5);
		List var8 = var7.getDefaultParents();
		if ("*".equals(var2)) {
			var8.clear();
			if (var4) {
				trcLogger.logp(Level.FINER, CLASSNAME, "deleteIdMgrRealmDefaultParent",
						"Realm Default parent deleted for all the entity types");
			}
		} else {
			boolean var9 = false;
			String var10 = null;
			RealmDefaultParentType var11 = null;
			Iterator var12 = var8.iterator();

			while (var12.hasNext()) {
				var11 = (RealmDefaultParentType) var12.next();
				var10 = var11.getEntityTypeName();
				if (var2.equals(var10)) {
					var12.remove();
					var9 = true;
					if (var4) {
						trcLogger.logp(Level.FINER, CLASSNAME, "deleteIdMgrRealmDefaultParent",
								"Realm Default parent deleted for entity type, " + var10);
					}
					break;
				}
			}

			if (!var9) {
				throw new WIMConfigurationException("NO_PARENT_FOR_ENTITY_TYPE_IN_REALM",
						WIMMessageHelper.generateMsgParms(var2, var6), Level.SEVERE, CLASSNAME,
						"deleteIdMgrRealmDefaultParent");
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrRealmDefaultParent");
		}

		return ConfigUtils.saveConfig(var0);
	}

	public static Map<String, String> listIdMgrRealmDefaultParents(String var0, String var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "listIdMgrRealmDefaultParents", "name=" + var1);
		}

		RealmConfigurationType var4 = ConfigUtils.getRealmConfig(var0);
		String var5 = var1;
		if (var1 == null) {
			var5 = var4.getDefaultRealm();
			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "listIdMgrRealmDefaultParents", "The default realm = " + var5);
			}
		}

		RealmType var6 = ConfigUtils.getRealm(var5, var4);
		List var7 = var6.getDefaultParents();
		HashMap var8 = new HashMap();

		for (int var9 = 0; var9 < var7.size(); ++var9) {
			RealmDefaultParentType var10 = (RealmDefaultParentType) var7.get(var9);
			String var11 = var10.getEntityTypeName();
			String var12 = var10.getParentUniqueName();
			var8.put(var11, var12);
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "listIdMgrRealmDefaultParents", "returning: " + var8);
		}

		return var8;
	}

	public static String setIdMgrRealmDefaultParent(String var0, String var1, String var2, String var3)
			throws WIMException {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		ConfigurationProviderType var6 = ConfigUtils.getConfigProvider(var0);
		List var7 = var6.getSupportedEntityTypes();
		if (SupportedEntityTypeConfigHelper.getSupportEntityTypeByName(var7, var2) == null) {
			throw new WIMConfigurationException("INVALID_ENTITY_TYPE", WIMMessageHelper.generateMsgParms(var2),
					Level.SEVERE, CLASSNAME, "setIdMgrRealmDefaultParent");
		} else {
			RealmConfigurationType var8 = ConfigValidator.getRealmConfig(var6);
			String var9 = var1;
			if (var1 == null) {
				var9 = var8.getDefaultRealm();
				if (var5) {
					trcLogger.logp(Level.FINER, CLASSNAME, "setIdMgrRealmDefaultParent", "The default realm = " + var9);
				}
			}

			RealmType var10 = ConfigUtils.getRealm(var9, var8);
			boolean var11 = false;
			List var12;
			String var14;
			if (var3 != null) {
				var3 = UniqueNameHelper.getValidUniqueName(var3);
				var12 = var10.getParticipatingBaseEntries();
				if (var12 != null) {
					for (int var13 = 0; var13 < var12.size() && !var11; ++var13) {
						var14 = ((ParticipatingBaseEntriesType) var12.get(var13)).getName();
						if (StringUtil.endsWithIgnoreCase(var3, var14)) {
							var11 = true;
						}
					}
				}
			}

			if (!var11) {
				throw new WIMConfigurationException("DEFAULT_PARENT_NOT_IN_SCOPE",
						WIMMessageHelper.generateMsgParms(var3, var9), CLASSNAME, "setIdMgrRealmDefaultParent");
			} else {
				var12 = var10.getDefaultParents();
				boolean var17 = false;
				var14 = null;

				for (int var15 = 0; var15 < var12.size() && !var17; ++var15) {
					RealmDefaultParentType var16 = (RealmDefaultParentType) var12.get(var15);
					var14 = var16.getEntityTypeName();
					if (var14.equals(var2)) {
						var16.setParentUniqueName(var3);
						if (var5) {
							trcLogger.logp(Level.FINER, CLASSNAME, "setIdMgrRealmDefaultParent",
									"Updated default parent as " + var3 + " for entity type " + var14);
						}

						var17 = true;
					}
				}

				if (!var17) {
					RealmDefaultParentType var18 = var10.createDefaultParents();
					var18.setEntityTypeName(var2);
					var18.setParentUniqueName(var3);
					if (var5) {
						trcLogger.logp(Level.FINER, CLASSNAME, "setIdMgrRealmDefaultParent",
								"Set default parent as " + var3 + " for entity type " + var2);
					}
				}

				if (var5) {
					trcLogger.exiting(CLASSNAME, "setIdMgrRealmDefaultParent");
				}

				return ConfigUtils.saveConfig(var0);
			}
		}
	}

	private Map getInformationForBaseEntry(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getInformationForBaseEntry", "baseEntyName=" + var2);
		}

		List var5 = ConfigUtils.getProfileRepositories(var1);
		HashMap var6 = new HashMap();

		for (int var7 = 0; var7 < var5.size(); ++var7) {
			ProfileRepositoryType var8 = (ProfileRepositoryType) var5.get(var7);
			List var9 = var8.getBaseEntries();

			for (int var10 = 0; var10 < var9.size(); ++var10) {
				BaseEntriesType var11 = (BaseEntriesType) var9.get(var10);
				String var12 = var11.getName();
				if (var12.toLowerCase().equals(var2.toLowerCase()) || var2.equalsIgnoreCase("root")) {
					String var13 = var11.getNameInRepository();
					var6.put("id", var8.getId());
					var6.put("name", var12.equalsIgnoreCase("") ? "root" : var12);
					var6.put("nameInRepository", var13);
					if (var8 instanceof FileRepositoryType) {
						var6.put("repositoryType", "File");
						var6.put("host", "LocalHost");
					} else if (var8 instanceof LdapRepositoryType) {
						var6.put("repositoryType", "LDAP");
						LdapRepositoryType var14 = (LdapRepositoryType) var8;
						var6.put("specificRepositoryType", var14.getLdapServerType());
						List var15 = var14.getLdapServerConfiguration().getLdapServers();
						LdapServersType var16 = (LdapServersType) var15.get(0);
						List var17 = var16.getConnections();
						ConnectionsType var18 = (ConnectionsType) var17.get(0);
						var6.put("host", var18.getHost());
						var6.put("port", "" + var18.getPort());
					} else if (var8 instanceof DatabaseRepositoryType) {
						var6.put("repositoryType", "DB");
						DatabaseRepositoryType var19 = (DatabaseRepositoryType) var8;
						var6.put("specificRepositoryType", var19.getDatabaseType());
						var6.put("host", var19.getDataSourceName());
					} else {
						var6.put("repositoryType", "Custom");
					}
					break;
				}
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getInformationForBaseEntry", "result=" + var6);
		}

		return var6;
	}

	private void validateInputParams(String var1, String var2, String var3)
			throws WIMConfigurationException, WIMException {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "validateInputParams",
					"sURAttrname = " + var1 + ", propertyForInput = " + var2 + ", propertyForOutput = " + var3);
		}

		boolean var6 = "uniqueUserId".equals(var1);
		boolean var7 = "userDisplayName".equals(var1);
		boolean var8 = "userSecurityName".equals(var1);
		boolean var9 = "uniqueGroupId".equals(var1);
		boolean var10 = "groupDisplayName".equals(var1);
		boolean var11 = "groupSecurityName".equals(var1);
		if (!var6 && !var7 && !var8 && !var9 && !var10 && !var11) {
			throw new WIMConfigurationException("INVALID_USER_REGISTRY_ATTRIBUTE_NAME",
					WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, CLASSNAME, "validateInputParams");
		} else {
			this.validateProperties(var1, var2);
			this.validateProperties(var1, var3);
			if (var5) {
				trcLogger.exiting(CLASSNAME, "validateInputParams");
			}

		}
	}

	private void validateProperties(String var1, String var2) throws WIMConfigurationException, WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "validateProperties", " sURAttrName = " + var1 + ", prop = " + var2);
		}

		boolean var5 = "uniqueId".equals(var2);
		boolean var6 = "uniqueName".equals(var2);
		boolean var7 = "externalId".equals(var2);
		boolean var8 = "externalName".equals(var2);
		if (!var5 && !var6 && !var7 && !var8) {
			String var9 = "user";
			if (var1.toLowerCase().contains(var9)) {
				if (SchemaManager.singleton().getProperty("PersonAccount", var2) == null) {
					throw new WIMConfigurationException("PROPERTY_NOT_DEFINED", WIMMessageHelper.generateMsgParms(var2),
							Level.SEVERE, CLASSNAME, "validateProperties");
				}
			} else if (SchemaManager.singleton().getProperty("Group", var2) == null) {
				throw new WIMConfigurationException("PROPERTY_NOT_DEFINED", WIMMessageHelper.generateMsgParms(var2),
						Level.SEVERE, CLASSNAME, "validateProperties");
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "validateProperties");
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = RealmConfigHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}