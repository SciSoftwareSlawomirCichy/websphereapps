package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.TopicSubscriber;
import com.ibm.ws.wim.configmodel.TopicSubscriberList;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class TopicSubscriberListImpl extends EDataObjectImpl implements TopicSubscriberList {
	protected EList topicSubscriber = null;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getTopicSubscriberList();
	}

	public TopicSubscriber[] getTopicSubscriberAsArray() {
		List var1 = this.getTopicSubscriber();
		return (TopicSubscriber[]) ((TopicSubscriber[]) var1.toArray(new TopicSubscriber[var1.size()]));
	}

	public List getTopicSubscriber() {
		if (this.topicSubscriber == null) {
			this.topicSubscriber = new EObjectContainmentEList(TopicSubscriber.class, this, 0);
		}

		return this.topicSubscriber;
	}

	public TopicSubscriber createTopicSubscriber() {
		TopicSubscriber var1 = ConfigmodelFactory.eINSTANCE.createTopicSubscriber();
		this.getTopicSubscriber().add(var1);
		return var1;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getTopicSubscriber()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getTopicSubscriber();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getTopicSubscriber().clear();
				this.getTopicSubscriber().addAll((Collection) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getTopicSubscriber().clear();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.topicSubscriber != null && !this.topicSubscriber.isEmpty();
			default :
				return this.eDynamicIsSet(var1);
		}
	}
}