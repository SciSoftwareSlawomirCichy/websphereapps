package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.AbstractMapBasedMultimap.1;
import com.google.common.collect.AbstractMapBasedMultimap.2;
import com.google.common.collect.AbstractMapBasedMultimap.AsMap;
import com.google.common.collect.AbstractMapBasedMultimap.KeySet;
import com.google.common.collect.AbstractMapBasedMultimap.NavigableAsMap;
import com.google.common.collect.AbstractMapBasedMultimap.NavigableKeySet;
import com.google.common.collect.AbstractMapBasedMultimap.RandomAccessWrappedList;
import com.google.common.collect.AbstractMapBasedMultimap.SortedAsMap;
import com.google.common.collect.AbstractMapBasedMultimap.SortedKeySet;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedCollection;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedList;
import com.google.common.collect.AbstractMultimap.Entries;
import com.google.common.collect.AbstractMultimap.EntrySet;
import com.google.common.collect.AbstractMultimap.Values;
import com.google.common.collect.Multimaps.Keys;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.RandomAccess;
import java.util.Set;
import java.util.SortedMap;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AbstractMapBasedMultimap<K, V> extends AbstractMultimap<K, V> implements Serializable {
	private transient Map<K, Collection<V>> map;
	private transient int totalSize;
	private static final long serialVersionUID = 2447537837011683357L;

	protected AbstractMapBasedMultimap(Map<K, Collection<V>> map) {
		Preconditions.checkArgument(map.isEmpty());
		this.map = map;
	}

	final void setMap(Map<K, Collection<V>> map) {
		this.map = map;
		this.totalSize = 0;

		Collection values;
		for (Iterator var2 = map.values().iterator(); var2.hasNext(); this.totalSize += values.size()) {
			values = (Collection) var2.next();
			Preconditions.checkArgument(!values.isEmpty());
		}

	}

	Collection<V> createUnmodifiableEmptyCollection() {
		return this.unmodifiableCollectionSubclass(this.createCollection());
	}

	abstract Collection<V> createCollection();

	Collection<V> createCollection(@NullableDecl K key) {
		return this.createCollection();
	}

	Map<K, Collection<V>> backingMap() {
		return this.map;
	}

	public int size() {
		return this.totalSize;
	}

	public boolean containsKey(@NullableDecl Object key) {
		return this.map.containsKey(key);
	}

	public boolean put(@NullableDecl K key, @NullableDecl V value) {
		Collection<V> collection = (Collection) this.map.get(key);
		if (collection == null) {
			collection = this.createCollection(key);
			if (collection.add(value)) {
				++this.totalSize;
				this.map.put(key, collection);
				return true;
			} else {
				throw new AssertionError("New Collection violated the Collection spec");
			}
		} else if (collection.add(value)) {
			++this.totalSize;
			return true;
		} else {
			return false;
		}
	}

	private Collection<V> getOrCreateCollection(@NullableDecl K key) {
		Collection<V> collection = (Collection) this.map.get(key);
		if (collection == null) {
			collection = this.createCollection(key);
			this.map.put(key, collection);
		}

		return collection;
	}

	public Collection<V> replaceValues(@NullableDecl K key, Iterable<? extends V> values) {
		Iterator<? extends V> iterator = values.iterator();
		if (!iterator.hasNext()) {
			return this.removeAll(key);
		} else {
			Collection<V> collection = this.getOrCreateCollection(key);
			Collection<V> oldValues = this.createCollection();
			oldValues.addAll(collection);
			this.totalSize -= collection.size();
			collection.clear();

			while (iterator.hasNext()) {
				if (collection.add(iterator.next())) {
					++this.totalSize;
				}
			}

			return this.unmodifiableCollectionSubclass(oldValues);
		}
	}

	public Collection<V> removeAll(@NullableDecl Object key) {
		Collection<V> collection = (Collection) this.map.remove(key);
		if (collection == null) {
			return this.createUnmodifiableEmptyCollection();
		} else {
			Collection<V> output = this.createCollection();
			output.addAll(collection);
			this.totalSize -= collection.size();
			collection.clear();
			return this.unmodifiableCollectionSubclass(output);
		}
	}

	<E> Collection<E> unmodifiableCollectionSubclass(Collection<E> collection) {
		return Collections.unmodifiableCollection(collection);
	}

	public void clear() {
		Iterator var1 = this.map.values().iterator();

		while (var1.hasNext()) {
			Collection<V> collection = (Collection) var1.next();
			collection.clear();
		}

		this.map.clear();
		this.totalSize = 0;
	}

	public Collection<V> get(@NullableDecl K key) {
		Collection<V> collection = (Collection) this.map.get(key);
		if (collection == null) {
			collection = this.createCollection(key);
		}

		return this.wrapCollection(key, collection);
	}

	Collection<V> wrapCollection(@NullableDecl K key, Collection<V> collection) {
		return new WrappedCollection(this, key, collection, (WrappedCollection) null);
	}

	final List<V> wrapList(@NullableDecl K key, List<V> list,
			@NullableDecl AbstractMapBasedMultimap<K, V>.WrappedCollection ancestor) {
		return (List) (list instanceof RandomAccess
				? new RandomAccessWrappedList(this, key, list, ancestor)
				: new WrappedList(this, key, list, ancestor));
	}

	private static <E> Iterator<E> iteratorOrListIterator(Collection<E> collection) {
		return (Iterator) (collection instanceof List ? ((List) collection).listIterator() : collection.iterator());
	}

	Set<K> createKeySet() {
		return new KeySet(this, this.map);
	}

	final Set<K> createMaybeNavigableKeySet() {
		if (this.map instanceof NavigableMap) {
			return new NavigableKeySet(this, (NavigableMap) this.map);
		} else {
			return (Set) (this.map instanceof SortedMap
					? new SortedKeySet(this, (SortedMap) this.map)
					: new KeySet(this, this.map));
		}
	}

	private void removeValuesForKey(Object key) {
		Collection<V> collection = (Collection) Maps.safeRemove(this.map, key);
		if (collection != null) {
			int count = collection.size();
			collection.clear();
			this.totalSize -= count;
		}

	}

	public Collection<V> values() {
		return super.values();
	}

	Collection<V> createValues() {
		return new Values(this);
	}

	Iterator<V> valueIterator() {
      return new 1(this);
   }

	Multiset<K> createKeys() {
		return new Keys(this);
	}

	public Collection<Entry<K, V>> entries() {
		return super.entries();
	}

	Collection<Entry<K, V>> createEntries() {
		return (Collection) (this instanceof SetMultimap ? new EntrySet(this) : new Entries(this));
	}

	Iterator<Entry<K, V>> entryIterator() {
      return new 2(this);
   }

	Map<K, Collection<V>> createAsMap() {
		return new AsMap(this, this.map);
	}

	final Map<K, Collection<V>> createMaybeNavigableAsMap() {
		if (this.map instanceof NavigableMap) {
			return new NavigableAsMap(this, (NavigableMap) this.map);
		} else {
			return (Map) (this.map instanceof SortedMap
					? new SortedAsMap(this, (SortedMap) this.map)
					: new AsMap(this, this.map));
		}
	}
}