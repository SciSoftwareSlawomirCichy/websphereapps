package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.base.Supplier;
import com.google.common.collect.ImmutableListMultimap.Builder;
import com.google.common.collect.Maps.EntryTransformer;
import com.google.common.collect.Maps.UnmodifiableEntries;
import com.google.common.collect.Multimaps.1;
import com.google.common.collect.Multimaps.2;
import com.google.common.collect.Multimaps.3;
import com.google.common.collect.Multimaps.CustomListMultimap;
import com.google.common.collect.Multimaps.CustomMultimap;
import com.google.common.collect.Multimaps.CustomSetMultimap;
import com.google.common.collect.Multimaps.CustomSortedSetMultimap;
import com.google.common.collect.Multimaps.MapMultimap;
import com.google.common.collect.Multimaps.TransformedEntriesListMultimap;
import com.google.common.collect.Multimaps.TransformedEntriesMultimap;
import com.google.common.collect.Multimaps.UnmodifiableAsMapEntries;
import com.google.common.collect.Multimaps.UnmodifiableListMultimap;
import com.google.common.collect.Multimaps.UnmodifiableMultimap;
import com.google.common.collect.Multimaps.UnmodifiableSetMultimap;
import com.google.common.collect.Multimaps.UnmodifiableSortedSetMultimap;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.Map.Entry;

@GwtCompatible(emulated = true)
public final class Multimaps {
	public static <K, V> Multimap<K, V> newMultimap(Map<K, Collection<V>> map,
			Supplier<? extends Collection<V>> factory) {
		return new CustomMultimap(map, factory);
	}

	public static <K, V> ListMultimap<K, V> newListMultimap(Map<K, Collection<V>> map,
			Supplier<? extends List<V>> factory) {
		return new CustomListMultimap(map, factory);
	}

	public static <K, V> SetMultimap<K, V> newSetMultimap(Map<K, Collection<V>> map,
			Supplier<? extends Set<V>> factory) {
		return new CustomSetMultimap(map, factory);
	}

	public static <K, V> SortedSetMultimap<K, V> newSortedSetMultimap(Map<K, Collection<V>> map,
			Supplier<? extends SortedSet<V>> factory) {
		return new CustomSortedSetMultimap(map, factory);
	}

	public static <K, V, M extends Multimap<K, V>> M invertFrom(Multimap<? extends V, ? extends K> source, M dest) {
		Preconditions.checkNotNull(dest);
		Iterator i$ = source.entries().iterator();

		while (i$.hasNext()) {
			Entry<? extends V, ? extends K> entry = (Entry) i$.next();
			dest.put(entry.getValue(), entry.getKey());
		}

		return dest;
	}

	public static <K, V> Multimap<K, V> synchronizedMultimap(Multimap<K, V> multimap) {
		return Synchronized.multimap(multimap, (Object) null);
	}

	public static <K, V> Multimap<K, V> unmodifiableMultimap(Multimap<K, V> delegate) {
		return (Multimap) (!(delegate instanceof UnmodifiableMultimap) && !(delegate instanceof ImmutableMultimap)
				? new UnmodifiableMultimap(delegate)
				: delegate);
	}

	@Deprecated
	public static <K, V> Multimap<K, V> unmodifiableMultimap(ImmutableMultimap<K, V> delegate) {
		return (Multimap) Preconditions.checkNotNull(delegate);
	}

	public static <K, V> SetMultimap<K, V> synchronizedSetMultimap(SetMultimap<K, V> multimap) {
		return Synchronized.setMultimap(multimap, (Object) null);
	}

	public static <K, V> SetMultimap<K, V> unmodifiableSetMultimap(SetMultimap<K, V> delegate) {
		return (SetMultimap) (!(delegate instanceof UnmodifiableSetMultimap)
				&& !(delegate instanceof ImmutableSetMultimap) ? new UnmodifiableSetMultimap(delegate) : delegate);
	}

	@Deprecated
	public static <K, V> SetMultimap<K, V> unmodifiableSetMultimap(ImmutableSetMultimap<K, V> delegate) {
		return (SetMultimap) Preconditions.checkNotNull(delegate);
	}

	public static <K, V> SortedSetMultimap<K, V> synchronizedSortedSetMultimap(SortedSetMultimap<K, V> multimap) {
		return Synchronized.sortedSetMultimap(multimap, (Object) null);
	}

	public static <K, V> SortedSetMultimap<K, V> unmodifiableSortedSetMultimap(SortedSetMultimap<K, V> delegate) {
		return (SortedSetMultimap) (delegate instanceof UnmodifiableSortedSetMultimap
				? delegate
				: new UnmodifiableSortedSetMultimap(delegate));
	}

	public static <K, V> ListMultimap<K, V> synchronizedListMultimap(ListMultimap<K, V> multimap) {
		return Synchronized.listMultimap(multimap, (Object) null);
	}

	public static <K, V> ListMultimap<K, V> unmodifiableListMultimap(ListMultimap<K, V> delegate) {
		return (ListMultimap) (!(delegate instanceof UnmodifiableListMultimap)
				&& !(delegate instanceof ImmutableListMultimap) ? new UnmodifiableListMultimap(delegate) : delegate);
	}

	@Deprecated
	public static <K, V> ListMultimap<K, V> unmodifiableListMultimap(ImmutableListMultimap<K, V> delegate) {
		return (ListMultimap) Preconditions.checkNotNull(delegate);
	}

	private static <V> Collection<V> unmodifiableValueCollection(Collection<V> collection) {
		if (collection instanceof SortedSet) {
			return Collections.unmodifiableSortedSet((SortedSet) collection);
		} else if (collection instanceof Set) {
			return Collections.unmodifiableSet((Set) collection);
		} else {
			return (Collection) (collection instanceof List
					? Collections.unmodifiableList((List) collection)
					: Collections.unmodifiableCollection(collection));
		}
	}

	private static <K, V> Entry<K, Collection<V>> unmodifiableAsMapEntry(Entry<K, Collection<V>> entry) {
      Preconditions.checkNotNull(entry);
      return new 1(entry);
   }

	private static <K, V> Collection<Entry<K, V>> unmodifiableEntries(Collection<Entry<K, V>> entries) {
		return (Collection) (entries instanceof Set
				? Maps.unmodifiableEntrySet((Set) entries)
				: new UnmodifiableEntries(Collections.unmodifiableCollection(entries)));
	}

	private static <K, V> Set<Entry<K, Collection<V>>> unmodifiableAsMapEntries(
			Set<Entry<K, Collection<V>>> asMapEntries) {
		return new UnmodifiableAsMapEntries(Collections.unmodifiableSet(asMapEntries));
	}

	public static <K, V> SetMultimap<K, V> forMap(Map<K, V> map) {
		return new MapMultimap(map);
	}

	public static <K, V1, V2> Multimap<K, V2> transformValues(Multimap<K, V1> fromMultimap, Function<? super V1, V2> function) {
      Preconditions.checkNotNull(function);
      EntryTransformer<K, V1, V2> transformer = new 2(function);
      return transformEntries((Multimap)fromMultimap, transformer);
   }

	public static <K, V1, V2> Multimap<K, V2> transformEntries(Multimap<K, V1> fromMap,
			EntryTransformer<? super K, ? super V1, V2> transformer) {
		return new TransformedEntriesMultimap(fromMap, transformer);
	}

	public static <K, V1, V2> ListMultimap<K, V2> transformValues(ListMultimap<K, V1> fromMultimap, Function<? super V1, V2> function) {
      Preconditions.checkNotNull(function);
      EntryTransformer<K, V1, V2> transformer = new 3(function);
      return transformEntries((ListMultimap)fromMultimap, transformer);
   }

	public static <K, V1, V2> ListMultimap<K, V2> transformEntries(ListMultimap<K, V1> fromMap,
			EntryTransformer<? super K, ? super V1, V2> transformer) {
		return new TransformedEntriesListMultimap(fromMap, transformer);
	}

	public static <K, V> ImmutableListMultimap<K, V> index(Iterable<V> values, Function<? super V, K> keyFunction) {
		return index(values.iterator(), keyFunction);
	}

	public static <K, V> ImmutableListMultimap<K, V> index(Iterator<V> values, Function<? super V, K> keyFunction) {
		Preconditions.checkNotNull(keyFunction);
		Builder builder = ImmutableListMultimap.builder();

		while (values.hasNext()) {
			V value = values.next();
			Preconditions.checkNotNull(value, values);
			builder.put(keyFunction.apply(value), value);
		}

		return builder.build();
	}

	@GwtIncompatible("untested")
	public static <K, V> Multimap<K, V> filterKeys(Multimap<K, V> unfiltered, Predicate<? super K> keyPredicate) {
		if (unfiltered instanceof FilteredKeyMultimap) {
			FilteredKeyMultimap<K, V> prev = (FilteredKeyMultimap) unfiltered;
			return new FilteredKeyMultimap(prev.unfiltered, Predicates.and(prev.keyPredicate, keyPredicate));
		} else if (unfiltered instanceof FilteredMultimap) {
			FilteredMultimap<K, V> prev = (FilteredMultimap) unfiltered;
			return new FilteredEntryMultimap(prev.unfiltered,
					Predicates.and(prev.entryPredicate(), Predicates.compose(keyPredicate, Maps.keyFunction())));
		} else {
			return new FilteredKeyMultimap(unfiltered, keyPredicate);
		}
	}

	@GwtIncompatible("untested")
	public static <K, V> Multimap<K, V> filterValues(Multimap<K, V> unfiltered, Predicate<? super V> valuePredicate) {
		return filterEntries(unfiltered, Predicates.compose(valuePredicate, Maps.valueFunction()));
	}

	@GwtIncompatible("untested")
	public static <K, V> Multimap<K, V> filterEntries(Multimap<K, V> unfiltered,
			Predicate<? super Entry<K, V>> entryPredicate) {
		Preconditions.checkNotNull(entryPredicate);
		return (Multimap) (unfiltered instanceof FilteredMultimap
				? filterFiltered((FilteredMultimap) unfiltered, entryPredicate)
				: new FilteredEntryMultimap((Multimap) Preconditions.checkNotNull(unfiltered), entryPredicate));
	}

	private static <K, V> Multimap<K, V> filterFiltered(FilteredMultimap<K, V> multimap,
			Predicate<? super Entry<K, V>> entryPredicate) {
		Predicate<Entry<K, V>> predicate = Predicates.and(multimap.entryPredicate(), entryPredicate);
		return new FilteredEntryMultimap(multimap.unfiltered, predicate);
	}
}