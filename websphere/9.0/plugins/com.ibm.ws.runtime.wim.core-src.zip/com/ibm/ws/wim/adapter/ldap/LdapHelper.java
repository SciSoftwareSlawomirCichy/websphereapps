package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.CertificateMapperException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.util.Base64Coder;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.StringUtil;
import com.sun.jndi.ldap.LdapName;
import commonj.sdo.DataObject;
import java.io.UnsupportedEncodingException;
import java.lang.ref.SoftReference;
import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InvalidNameException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.SearchControls;

public class LdapHelper {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static SoftReference<Map> softDnCache;

	public static String getValidDN(String var0) {
		Map var1 = null;
		if (var0 == null) {
			return null;
		} else {
			if (softDnCache.get() == null) {
				softDnCache = new SoftReference(new ConcurrentHashMap());
			}

			var1 = (Map) softDnCache.get();
			String var2 = DomainManagerUtils.getDomainName();
			if (var1.get(var2) == null) {
				var1.put(var2, new ConcurrentHashMap(256));
			}

			String var3 = (String) ((Map) var1.get(var2)).get(var0);
			if (var3 == null) {
				try {
					LdapName var4 = new LdapName(var0);
					var3 = var4.getPrefix(var4.size()).toString();
					((Map) var1.get(var2)).put(var0, var3);
				} catch (InvalidNameException var5) {
					var3 = null;
				}
			}

			return var3;
		}
	}

	public static String getRDN(String var0) {
		if (var0 != null && var0.trim().length() != 0) {
			String var1 = null;

			try {
				LdapName var2 = new LdapName(var0);
				if (var2.size() == 0) {
					return var0;
				}

				var1 = var2.get(var2.size() - 1);
			} catch (InvalidNameException var4) {
				var0 = var0.trim();

				int var3;
				for (var3 = var0.indexOf(44); var0.charAt(var3 - 1) == '\\'; var3 = var0.indexOf(44, var3 + 1)) {
					;
				}

				if (var3 > -1) {
					var1 = var0.substring(0, var3).trim();
				} else {
					var1 = var0;
				}
			}

			return var1;
		} else {
			return var0;
		}
	}

	public static String getEntityType(String var0, Attribute var1) {
		if (var0.startsWith("uid=")) {
			return "Person";
		} else if (var0.startsWith("cn=")) {
			return "Group";
		} else if (var0.startsWith("o=")) {
			return "OrgContainer";
		} else {
			return var0.startsWith("ou=") ? "OrgContainer" : null;
		}
	}

	public static String[] getRDNs(String var0) {
		StringTokenizer var1 = new StringTokenizer(var0.toLowerCase(), "+");
		ArrayList var2 = new ArrayList();

		while (var1.hasMoreTokens()) {
			String var3 = var1.nextToken();
			var2.add(var3);
		}

		return (String[]) var2.toArray(new String[0]);
	}

	public static String[] getRDNValues(String var0) {
		StringTokenizer var1 = new StringTokenizer(var0.toLowerCase(), "+");
		ArrayList var2 = new ArrayList();

		while (var1.hasMoreTokens()) {
			String var3 = var1.nextToken();
			int var4 = var3.indexOf(61);
			if (var4 > -1) {
				var2.add(var3.substring(var4 + 1));
			}
		}

		return (String[]) var2.toArray(new String[0]);
	}

	public static Attribute getIngoreCaseAttribute(Attributes var0, String var1) {
		if (var0 != null && var1 != null) {
			NamingEnumeration var2 = var0.getIDs();

			String var3;
			boolean var4;
			do {
				if (!var2.hasMoreElements()) {
					return null;
				}

				var3 = (String) var2.nextElement();
				var4 = false;
				if (var1.equalsIgnoreCase(var3)) {
					var4 = true;
				} else {
					int var5 = var3.indexOf(";");
					if (var5 > 0 && var1.equalsIgnoreCase(var3.substring(0, var5))) {
						var4 = true;
					}
				}
			} while (!var4);

			return var0.get(var3);
		} else {
			return null;
		}
	}

	public static short getMembershipScope(String var0) {
		if (var0 != null) {
			var0 = var0.trim();
			if ("direct".equalsIgnoreCase(var0)) {
				return 0;
			} else if ("nested".equalsIgnoreCase(var0)) {
				return 1;
			} else {
				return (short) ("all".equalsIgnoreCase(var0) ? 2 : 0);
			}
		} else {
			return 0;
		}
	}

	public static byte[] encodePassword(String var0) throws WIMSystemException {
		try {
			return ("\"" + var0 + "\"").getBytes("UTF-16LE");
		} catch (Exception var3) {
			throw new WIMSystemException(CLASSNAME, "byte[] encodePassword(String)", var3);
		}
	}

	public static byte[] getOctetString(String var0) {
		byte[] var1 = new byte[var0.length() / 2];
		int var2 = 0;

		for (int var3 = 0; var3 < var0.length() - 1; var3 += 2) {
			String var4 = var0.substring(var3, var3 + 2);
			int var5 = Integer.parseInt(var4, 16);
			var1[var2] = (byte) var5;
			++var2;
		}

		return var1;
	}

	public static String getDateString(String var0) {
		return var0;
	}

	public static String getLDAPGeneralTime(Date var0) {
		return (new SimpleDateFormat("yyyyMMddHHmmss'Z'")).format(var0);
	}

	public static String getOctetString(byte[] var0) {
		StringBuffer var1 = new StringBuffer();
		String var2 = "";

		for (int var3 = 0; var3 < var0.length; ++var3) {
			var2 = Integer.toHexString(var0[var3] & 255);
			if (var2.length() == 1) {
				var2 = "0" + var2;
			}

			var1.append(var2);
		}

		return var1.toString();
	}

	public static String prepareDN(String var0, String var1) {
		return prepareDN(var0, var1, (String) null);
	}

	public static String prepareDN(String var0, String var1, String var2) {
		if (var0 != null && var0.trim().length() != 0) {
			var0 = unescapeDoubleBackslash(var0);
			var0 = unescapeSingleQuote(var0);
			var0 = unescapeSpaces(var0);
			int var4 = var0.length();
			if (var0.charAt(0) == '"' && var0.charAt(var4 - 1) == '"') {
				var0 = var0.substring(1, var4 - 1);
			}

			int var6;
			if (var0.startsWith("/")) {
				int var5 = var0.indexOf(58);
				if (var5 > -1) {
					var6 = var0.indexOf(47, var5);
					if (var6 > 0) {
						var0 = var0.substring(var6 + 1);
					}
				}
			} else {
				int var7;
				boolean var14;
				LdapURL var15;
				if (var0.toLowerCase().startsWith("ldap://")) {
					var14 = false;

					try {
						var15 = new LdapURL(var0);
						if (var15.parsedOK()) {
							var0 = var15.get_dn();
							var14 = true;
						}
					} catch (Exception var13) {
						;
					}

					if (!var14) {
						var6 = var0.indexOf(58, "ldap://".length());
						if (var6 > 0) {
							var7 = var0.indexOf("/", var6);
							if (var7 > 0) {
								var0 = var0.substring(var7 + 1);
							}
						}
					}
				} else if (var0.toLowerCase().startsWith("ldaps://")) {
					var14 = false;

					try {
						var15 = new LdapURL(var0);
						if (var15.parsedOK()) {
							var0 = var15.get_dn();
							var14 = true;
						}
					} catch (Exception var12) {
						;
					}

					if (!var14) {
						var6 = var0.indexOf(58, "ldaps://".length());
						if (var6 > 0) {
							var7 = var0.indexOf("/", var6);
							if (var7 > 0) {
								var0 = var0.substring(var7 + 1);
							}
						}
					}
				}
			}

			if (var1 != null && var1.trim().length() != 0) {
				StringTokenizer var16 = new StringTokenizer(var0, ",");
				StringTokenizer var17 = new StringTokenizer(var1, ",");
				String var18 = null;

				String var8;
				for (var8 = null; var16.hasMoreTokens(); var18 = var16.nextToken()) {
					;
				}

				while (var17.hasMoreTokens()) {
					var8 = var17.nextToken();
				}

				if (var18 != null) {
					var18 = var18.trim();
				} else {
					var18 = "";
				}

				if (var8 != null) {
					var8 = var8.trim();
				} else {
					var8 = "";
				}

				boolean var9 = false;
				if (!var18.equalsIgnoreCase(var8)) {
					if (var0.length() > 0) {
						var0 = var0 + "," + var1;
					} else {
						var0 = var1;
					}

					var9 = true;
				}

				if (var2 != null) {
					StringTokenizer var10 = new StringTokenizer(var2, ",");

					String var11;
					for (var11 = null; var10.hasMoreTokens(); var11 = var10.nextToken()) {
						;
					}

					if (var9) {
						if (!var8.equalsIgnoreCase(var11)) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "prepareDN",
										"adding " + var2 + " after searchbase to " + var0);
							}

							var0 = var0 + "," + var2;
						}
					} else if (!var18.equalsIgnoreCase(var11)) {
						if (var0.length() > 0) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "prepareDN", "adding " + var2 + " to " + var0);
							}

							var0 = var0 + "," + var2;
						} else {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "prepareDN", "setting DN to " + var2);
							}

							var0 = var2;
						}
					}
				}

				return var0;
			} else {
				if (var2 != null && !var0.toLowerCase().endsWith(var2.toLowerCase())) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "prepareDN",
								"No searchbase, adding " + var2 + " to " + var0);
					}

					var0 = var0 + "," + var2;
				}

				return var0;
			}
		} else {
			return var1;
		}
	}

	private static String unescapeSpaces(String var0) {
		char[] var1 = var0.toCharArray();
		int var2 = var1.length;
		StringBuffer var3 = new StringBuffer(var0.length());

		for (int var4 = 0; var4 < var2; ++var4) {
			boolean var5 = var1[var4] == '\\' && var4 + 1 < var2 && var1[var4 + 1] == ' ';
			if (var5) {
				boolean var6 = var4 > 0 && var1[var4 - 1] == '=';
				boolean var7 = var4 + 2 >= var2 || var4 + 2 < var2 && var1[var4 + 2] == ',';
				if (!var6 && !var7) {
					++var4;
				}
			}

			var3.append(var1[var4]);
		}

		return new String(var3);
	}

	public static String unescapeDoubleBackslash(String var0) {
		char[] var1 = var0.toCharArray();
		int var2 = var1.length;
		StringBuffer var3 = new StringBuffer(var0.length());

		for (int var4 = 0; var4 < var2; ++var4) {
			if (var1[var4] == '\\' && var4 + 1 < var2 && var1[var4 + 1] == '\\') {
				++var4;
			}

			var3.append(var1[var4]);
		}

		return new String(var3);
	}

	public static String unescapeSingleQuote(String var0) {
		char[] var1 = var0.toCharArray();
		int var2 = var1.length;
		StringBuffer var3 = new StringBuffer(var0.length());

		for (int var4 = 0; var4 < var2; ++var4) {
			if (var1[var4] == '\\' && var4 + 1 < var2 && var1[var4 + 1] == '\'') {
				++var4;
			}

			var3.append(var1[var4]);
		}

		return new String(var3);
	}

	public static String getDNFromAttributes(Attributes var0) throws WIMSystemException {
		try {
			Attribute var2 = var0.remove("distinguishedName");
			return var2 != null ? (String) var2.get() : null;
		} catch (NamingException var3) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var3.toString(true)),
					CLASSNAME, "getDNFromAttributes(Attributes)");
		}
	}

	public static String[] getRDNAttributes(String var0) {
		String var1 = getRDN(var0);
		StringTokenizer var2 = new StringTokenizer(var1.toLowerCase(), "+");
		ArrayList var3 = new ArrayList();

		while (var2.hasMoreTokens()) {
			String var4 = var2.nextToken();
			int var5 = var4.indexOf(61);
			if (var5 > -1) {
				var3.add(var4.substring(0, var5));
			}
		}

		return (String[]) ((String[]) var3.toArray(new String[0]));
	}

	public static String replaceRDN(String var0, String[] var1, String[] var2) {
		String var3 = getParentDN(var0);
		if (var1 != null && var2 != null && var1.length == var2.length && var1.length != 0) {
			StringBuffer var4 = new StringBuffer();
			String[] var5 = getRDNValues(var0);

			for (int var6 = 0; var6 < var1.length; ++var6) {
				if (var6 != 0) {
					var4.append("+");
				}

				String var7 = var2[var6];
				if (var7 == null) {
					var7 = var5[var6];
				}

				var4.append(var1[var6] + "=" + LdapName.escapeAttributeValue(var7));
			}

			if (var3.length() == 0) {
				var0 = var4.toString();
			} else {
				var0 = var4.append("," + var3).toString();
			}

			return var0;
		} else {
			return var0;
		}
	}

	public static String replaceRDN(String var0, String var1, String var2) {
		String[] var3 = new String[]{var1};
		String[] var4 = new String[]{var2};
		return replaceRDN(var0, var3, var4);
	}

	public static String getParentDN(String var0) {
		String var1 = null;
		if (var0 == null || var0.trim().length() == 0) {
			var1 = "";
		}

		try {
			LdapName var2 = new LdapName(var0);
			if (var2.size() == 0) {
				var1 = "";
			}

			var2.remove(var2.size() - 1);
			var1 = var2.toString();
		} catch (InvalidNameException var4) {
			var0 = var0.trim();
			int var3 = var0.indexOf(44);
			if (var0.charAt(var3 - 1) == '\\') {
				var3 = var0.indexOf(var3, 44);
			}

			if (var3 > -1) {
				var1 = var0.substring(var3 + 1).trim();
			} else {
				var1 = "";
			}
		}

		return var1;
	}

	public static boolean isUnderBases(String var0, String var1) {
		var0 = getValidDN(var0);
		if (var0 != null) {
			var0 = var0.toLowerCase();
			if (var0.endsWith(var1.toLowerCase())) {
				return true;
			}
		}

		return false;
	}

	public static boolean isEntityTypeInList(String var0, List<?> var1) throws WIMException {
		if (var1 != null && var1.size() > 0) {
			for (int var2 = 0; var2 < var1.size(); ++var2) {
				String var3 = (String) var1.get(var2);
				if (var3.equals(var0) || SchemaManager.singleton().isSuperType(var3, var0)) {
					return true;
				}
			}
		}

		return false;
	}

	public static boolean isUnderBases(String var0, String[] var1) {
		var0 = getValidDN(var0);
		if (var0 != null) {
			var0 = var0.toLowerCase();

			for (int var2 = 0; var2 < var1.length; ++var2) {
				if (var1[var2].trim().length() == 0 || var0.endsWith(var1[var2].toLowerCase())) {
					return true;
				}
			}
		}

		return false;
	}

	public static String getAccountUniqueName(String var0, String var1) {
		String[] var2 = new String[]{"principalName"};
		String[] var3 = new String[]{var1};
		return replaceRDN(var0, var2, var3);
	}

	public static String getAccountExtId(String var0) {
		return "account" + var0;
	}

	public static Object getStringLdapValue(Object var0, LdapAttribute var1, String var2) throws WIMSystemException {
		Object var4 = null;
		String var5 = (String) var0;
		String var6 = "string";
		if (var1 != null) {
			var6 = var1.getSyntax();
		}

		if ("unicodePwd".equalsIgnoreCase(var6)) {
			var4 = encodePassword(var5);
		} else if ("octetString".equalsIgnoreCase(var6)) {
			try {
				var4 = getOctetString(var5);
			} catch (NumberFormatException var9) {
				throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var9.toString()),
						CLASSNAME, "getStringLdapValue(Object, LdapAttribute, String)");
			}
		} else if ("GUID".equalsIgnoreCase(var6)) {
			try {
				var4 = convertDashedStringToByte(var5);
			} catch (NumberFormatException var8) {
				throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var8.toString()),
						CLASSNAME, "getStringLdapValue(Object, LdapAttribute, String)");
			}
		} else {
			var4 = var5;
		}

		return var4;
	}

	private static Date convertDatetoGMT(Date var0) {
		TimeZone var1 = TimeZone.getDefault();
		Date var2 = new Date(var0.getTime() - (long) var1.getRawOffset());
		if (var1.inDaylightTime(var2)) {
			Date var3 = new Date(var2.getTime() - (long) var1.getDSTSavings());
			if (var1.inDaylightTime(var3)) {
				var2 = var3;
			}
		}

		return var2;
	}

	public static Object getDateLdapValue(Object var0, LdapAttribute var1, String var2) throws WIMSystemException {
		try {
			String var4 = var0.toString();
			Date var5 = null;
			boolean var6 = var4.indexOf("Z") != -1;
			boolean var7 = var4.indexOf(".") != -1;
			String var8 = null;
			if (var6) {
				if (var7) {
					var5 = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")).parse(var4);
				} else {
					var5 = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")).parse(var4);
				}
			} else {
				SimpleDateFormat var9 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
				var5 = var9.parse(var4);
				var5 = convertDatetoGMT(var5);
				var6 = true;
			}

			if (var2.startsWith("IDS")) {
				if (var6) {
					var8 = (new SimpleDateFormat("yyyyMMddHHmmss.SSSSSS'Z'")).format(var5);
				} else {
					var8 = (new SimpleDateFormat("yyyyMMddHHmmss.SSSSSSZ")).format(var5);
				}
			} else {
				if (!var2.startsWith("SUNONE") && !var2.startsWith("DOMINO") && !var2.startsWith("NDS")) {
					if (var6) {
						return (new SimpleDateFormat("yyyyMMddHHmmss.S'Z'")).format(var5);
					}

					return (new SimpleDateFormat("yyyyMMddHHmmss.SZ")).format(var5);
				}

				if (var6) {
					var8 = (new SimpleDateFormat("yyyyMMddHHmmss'Z'")).format(var5);
				} else {
					var8 = (new SimpleDateFormat("yyyyMMddHHmmssZ")).format(var5);
				}
			}

			return var8;
		} catch (ParseException var10) {
			throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var10.toString()),
					Level.SEVERE, CLASSNAME, "getDateLdapValue(Object, LdapAttribute, String)");
		}
	}

	public static Object getIntLdapValue(Object var0, LdapAttribute var1, String var2) {
		String var3 = null;
		if (var0 instanceof Integer) {
			var3 = var0.toString();
		}

		var3 = var0.toString();
		return var3;
	}

	public static String printSearchControls(SearchControls var0) {
		StringBuffer var1 = new StringBuffer();
		var1.append("[searchScope: ").append(var0.getSearchScope());
		var1.append(", timeLimit: ").append(var0.getTimeLimit());
		var1.append(", countLimit: ").append(var0.getCountLimit());
		var1.append(", returningObjFlag: ").append(var0.getReturningObjFlag());
		var1.append(", returningAttributes: ").append(WIMTraceHelper.printObjectArray(var0.getReturningAttributes()))
				.append("]");
		return var1.toString();
	}

	public static boolean inAttributes(String var0, Attributes var1) {
		NamingEnumeration var2 = var1.getIDs();

		String var3;
		do {
			if (!var2.hasMoreElements()) {
				return false;
			}

			var3 = (String) var2.nextElement();
		} while (!var3.equalsIgnoreCase(var0));

		return true;
	}

	public static Attribute cloneAttribute(String var0, Attribute var1) throws WIMSystemException {
		BasicAttribute var3 = new BasicAttribute(var0);

		try {
			NamingEnumeration var4 = var1.getAll();

			while (var4.hasMoreElements()) {
				var3.add(var4.nextElement());
			}

			return var3;
		} catch (NamingException var5) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var5.toString(true)),
					Level.SEVERE, CLASSNAME, "cloneAttribute");
		}
	}

	public static LdapURL[] getLdapURLs(Attribute var0) throws WIMException {
		LdapURL[] var2 = new LdapURL[0];
		if (var0 != null) {
			ArrayList var3 = new ArrayList(var0.size());

			try {
				NamingEnumeration var4 = var0.getAll();

				while (var4.hasMoreElements()) {
					LdapURL var5 = new LdapURL((String) ((String) var4.nextElement()));
					if (var5.parsedOK()) {
						var3.add(var5);
					} else if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "getLdapURLs",
								"Member URL query: " + var5.get_url() + " is invalid and ingored.");
					}
				}
			} catch (NamingException var6) {
				throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.toString(true)),
						Level.SEVERE, CLASSNAME, "getLdapURLs");
			}

			var2 = (LdapURL[]) ((LdapURL[]) var3.toArray(var2));
		}

		return var2;
	}

	public static boolean containIngorecaseValue(Attribute var0, String var1) throws WIMSystemException {
		if (var0 != null && var1 != null) {
			try {
				NamingEnumeration var3 = var0.getAll();

				String var4;
				do {
					if (!var3.hasMoreElements()) {
						return false;
					}

					var4 = (String) var3.nextElement();
				} while (!var1.equalsIgnoreCase(var4));

				return true;
			} catch (NamingException var5) {
				throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var5.toString(true)),
						Level.SEVERE, CLASSNAME, "containIngorecaseValue");
			}
		} else {
			return false;
		}
	}

	public static String getUniqueKey(X509Certificate var0) {
		StringBuffer var1 = new StringBuffer("subjectDN:");
		var1.append(var0.getSubjectX500Principal().getName()).append("issuerDN:")
				.append(var0.getIssuerX500Principal().getName());
		return Base64Coder.base64Encode(getDigest(var1.toString()));
	}

	private static String getDigest(String var0) {
		MessageDigest var2;
		try {
			var2 = MessageDigest.getInstance("MD5");
		} catch (Exception var4) {
			trcLogger.logp(Level.FINE, CLASSNAME, "getDigest", var4.toString());
			return null;
		}

		var2.update(StringUtil.getBytes(var0));
		return StringUtil.toString(var2.digest());
	}

	static String getDNSubField(String var0, String var1) throws CertificateMapperException {
		if (var0.equals("DN")) {
			return var1;
		} else {
			StringTokenizer var3 = new StringTokenizer(var1);

			String var4;
			String var5;
			do {
				try {
					var4 = var3.nextToken(",= ");
					var5 = var3.nextToken(",");
					if (var5 != null) {
						var5 = var5.substring(1);
					}
				} catch (NoSuchElementException var7) {
					trcLogger.logp(Level.FINE, CLASSNAME, "getDNSubField", var7.toString());
					throw new CertificateMapperException("UNKOWN_DN_FIELD", WIMMessageHelper.generateMsgParms(var0),
							CLASSNAME, "getDNSubField");
				}
			} while (!var4.equals(var0));

			return var5;
		}
	}

	public static String[] parseFilterDescriptor(String var0) throws CertificateMapperException {
		Vector var5 = new Vector();
		int var3 = 0;
		int var2 = 0;

		for (int var4 = var0.length(); var3 < var4; var2 = var3) {
			var3 = var0.indexOf("${", var2);
			if (var3 == -1) {
				if (var2 < var4) {
					var5.addElement(var0.substring(var2));
				}
				break;
			}

			if (var2 < var3) {
				var5.addElement(var0.substring(var2, var3));
			}

			var2 = var3;
			var3 = var0.indexOf("}", var3);
			if (var3 == -1) {
				throw new CertificateMapperException("INVALID_CERTIFICATE_FILTER",
						WIMMessageHelper.generateMsgParms(var0), CLASSNAME, "parseFilterDescriptor");
			}

			++var3;
			var5.addElement(var0.substring(var2, var3));
		}

		String[] var6 = new String[var5.size()];

		for (int var7 = 0; var7 < var5.size(); ++var7) {
			var6[var7] = (String) var5.elementAt(var7);
		}

		return var6;
	}

	public static String toUpperCase(String var0) {
		if (var0 == null) {
			return null;
		} else {
			String var1 = null;
			if (var0.indexOf(223) != -1) {
				char[] var2 = new char[var0.length()];

				for (int var3 = 0; var3 < var0.length(); ++var3) {
					char var4 = var0.charAt(var3);
					if (var4 == 223) {
						var2[var3] = var4;
					} else {
						var2[var3] = Character.toUpperCase(var4);
					}
				}

				var1 = new String(var2);
			} else {
				var1 = var0.toUpperCase();
			}

			return var1;
		}
	}

	public static int getCacheDistPolicyInt(String var0) {
		int var1 = FactoryManager.getCacheUtil().getSharingPolicyInt(var0);
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "getCacheDistPolicyInt", "CacheDistPolicy:" + var0 + "=>" + var1);
		}

		return var1;
	}

	public static String getLdapServerType(DataObject var0) {
		String var1 = var0.getString("ldapServerType");
		if (var1 == null) {
			var1 = "IDS52";
		} else {
			var1 = var1.toUpperCase();
		}

		return var1;
	}

	public static String encodeAttribute(String var0, String var1) {
		int var2 = 0;
		char[] var3 = var0.toCharArray();
		int var4 = var3.length;

		StringBuilder var5;
		for (var5 = new StringBuilder(); var2 < var4; ++var2) {
			char var6 = var3[var2];
			if (Character.toLowerCase(var6) != Character.toLowerCase(Character.toUpperCase(var6))) {
				byte[] var7 = null;

				try {
					var7 = (new String("" + var6)).getBytes(var1);
				} catch (UnsupportedEncodingException var11) {
					;
				}

				for (int var8 = 0; var8 < var7.length; ++var8) {
					byte var9 = var7[var8];
					var5.append("\\");
					String var10 = Integer.toHexString(var9);
					var5.append(var10.substring(var10.length() - 2));
				}
			} else {
				var5.append(var6);
			}
		}

		return var5.toString();
	}

	private static String prefixZeros(int var0) {
		if (var0 <= 15) {
			StringBuilder var1 = new StringBuilder("0");
			var1.append(Integer.toHexString(var0));
			return var1.toString();
		} else {
			return Integer.toHexString(var0);
		}
	}

	public static String convertToDashedString(byte[] var0) {
		StringBuilder var1 = new StringBuilder();
		var1.append(prefixZeros(var0[3] & 255));
		var1.append(prefixZeros(var0[2] & 255));
		var1.append(prefixZeros(var0[1] & 255));
		var1.append(prefixZeros(var0[0] & 255));
		var1.append("-");
		var1.append(prefixZeros(var0[5] & 255));
		var1.append(prefixZeros(var0[4] & 255));
		var1.append("-");
		var1.append(prefixZeros(var0[7] & 255));
		var1.append(prefixZeros(var0[6] & 255));
		var1.append("-");
		var1.append(prefixZeros(var0[8] & 255));
		var1.append(prefixZeros(var0[9] & 255));
		var1.append("-");
		var1.append(prefixZeros(var0[10] & 255));
		var1.append(prefixZeros(var0[11] & 255));
		var1.append(prefixZeros(var0[12] & 255));
		var1.append(prefixZeros(var0[13] & 255));
		var1.append(prefixZeros(var0[14] & 255));
		var1.append(prefixZeros(var0[15] & 255));
		return var1.toString();
	}

	public static byte[] convertDashedStringToByte(String var0) {
		byte[] var1 = new byte[16];
		char[] var2 = var0.toCharArray();
		var1[3] = (byte) Integer.parseInt(var2[0] + "" + var2[1], 16);
		var1[2] = (byte) Integer.parseInt(var2[2] + "" + var2[3], 16);
		var1[1] = (byte) Integer.parseInt(var2[4] + "" + var2[5], 16);
		var1[0] = (byte) Integer.parseInt(var2[6] + "" + var2[7], 16);
		var1[5] = (byte) Integer.parseInt(var2[9] + "" + var2[10], 16);
		var1[4] = (byte) Integer.parseInt(var2[11] + "" + var2[12], 16);
		var1[7] = (byte) Integer.parseInt(var2[14] + "" + var2[15], 16);
		var1[6] = (byte) Integer.parseInt(var2[16] + "" + var2[17], 16);
		var1[8] = (byte) Integer.parseInt(var2[19] + "" + var2[20], 16);
		var1[9] = (byte) Integer.parseInt(var2[21] + "" + var2[22], 16);
		var1[10] = (byte) Integer.parseInt(var2[24] + "" + var2[25], 16);
		var1[11] = (byte) Integer.parseInt(var2[26] + "" + var2[27], 16);
		var1[12] = (byte) Integer.parseInt(var2[28] + "" + var2[29], 16);
		var1[13] = (byte) Integer.parseInt(var2[30] + "" + var2[31], 16);
		var1[14] = (byte) Integer.parseInt(var2[32] + "" + var2[33], 16);
		var1[15] = (byte) Integer.parseInt(var2[34] + "" + var2[35], 16);
		return var1;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = LdapHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		softDnCache = new SoftReference(new ConcurrentHashMap());
	}
}