package com.ibm.ws.wim.dao;

import com.ibm.websphere.ce.cm.DuplicateKeyException;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.EntityAlreadyExistsException;
import com.ibm.websphere.wim.exception.EntityHasDescendantsException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InvalidIdentifierException;
import com.ibm.websphere.wim.exception.InvalidPropertyDefinitionException;
import com.ibm.websphere.wim.exception.InvalidPropertyValueException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.EnvironmentManager;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.db.DBAccount;
import com.ibm.ws.wim.adapter.db.DBEntity;
import com.ibm.ws.wim.adapter.db.DBEntityIdEntityType;
import com.ibm.ws.wim.adapter.db.DBExtIdReposId;
import com.ibm.ws.wim.adapter.db.DBPropertyCache;
import com.ibm.ws.wim.adapter.db.PropertyToUpdate;
import com.ibm.ws.wim.dao.schema.DBRepositoryProperty;
import com.ibm.ws.wim.env.IEncryptionUtil;
import com.ibm.ws.wim.lookaside.LAEntity;
import com.ibm.ws.wim.lookaside.LAPropertyCache;
import com.ibm.ws.wim.util.DataGraphHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.SearchParameter;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Type;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Method;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EcoreUtil;

public class AbstractDAO implements DataAccessObject {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;
	protected String datasourceName;
	private DataSource ds;
	private QuerySet qs;
	private String dbDriver;
	private String dbURL;
	private String dbSchema;
	private Hashtable needCommit;
	private String dbUserId;
	private String dbPassword;
	private KeyManager keyMgr;
	private String databaseType;
	private SchemaManager schemaMgr;
	private boolean isUseTriggerForIdInLARepo;

	public AbstractDAO() {
		this.datasourceName = null;
		this.ds = null;
		this.qs = null;
		this.dbDriver = null;
		this.dbURL = null;
		this.dbSchema = null;
		this.needCommit = new Hashtable();
		this.dbUserId = null;
		this.dbPassword = null;
		this.keyMgr = null;
		this.databaseType = null;
		this.schemaMgr = null;
		this.isUseTriggerForIdInLARepo = false;
	}

	public AbstractDAO(String var1, String var2, String var3, String var4, String var5, String var6, QuerySet var7)
			throws WIMException {
		this(var1, var2, var3, (String) null, var4, var5, var6, var7);
	}

	public AbstractDAO(String var1, String var2, String var3, String var4, String var5, String var6, String var7,
			QuerySet var8) throws WIMException {
		this.datasourceName = null;
		this.ds = null;
		this.qs = null;
		this.dbDriver = null;
		this.dbURL = null;
		this.dbSchema = null;
		this.needCommit = new Hashtable();
		this.dbUserId = null;
		this.dbPassword = null;
		this.keyMgr = null;
		this.databaseType = null;
		this.schemaMgr = null;
		this.isUseTriggerForIdInLARepo = false;
		this.datasourceName = var2;
		this.databaseType = var1;
		if (var7 != null && var7.length() != 0) {
			this.dbDriver = var7;
		} else {
			this.dbDriver = DAOHelper.getDefaultDBDriver(var1);
		}

		this.dbURL = var3;
		this.dbSchema = var4;
		IEncryptionUtil var10 = FactoryManager.getEncryptionUtil();
		if (var5 != null && var5.length() != 0) {
			this.dbUserId = var5;
			if (var6 == null || var6.length() == 0) {
				throw new WIMConfigurationException("INVALID_INIT_PROPERTY",
						WIMMessageHelper.generateMsgParms("dbAdminPassword"), CLASSNAME, "AbstractDAO Constructor");
			}

			this.dbPassword = var6;
			this.dbPassword = var10.decode(this.dbPassword);
		}

		this.schemaMgr = SchemaManager.singleton();
		this.qs = var8;
		this.keyMgr = new KeyManager(this);
		this.keyMgr.setSchema(var4);
		if (!EnvironmentManager.singleton().isDirectAccessMode()) {
			this.dsLookup();
		}

	}

	public void reload(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "reload(String dbAdminPwd)");
		}

		if (this.dbPassword != null && this.dbPassword.trim().length() != 0) {
			IEncryptionUtil var3 = FactoryManager.getEncryptionUtil();
			String var4 = var3.decode(var1);
			if (!this.checkDirectConnection(var4)) {
				throw new WIMSystemException("SYSTEM_EXCEPTION",
						WIMMessageHelper.generateMsgParms("reload(String dbAdminPwd)"), CLASSNAME,
						"reload(String dbAdminPwd)");
			}

			this.dbPassword = var4;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "reload(String dbAdminPwd)");
		}

	}

	public DataSource dsLookup() {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "dsLookup");
		}

		try {
			Hashtable var2 = DomainManagerUtils.getProviderURL();
			InitialContext var3 = new InitialContext(var2);
			this.ds = (DataSource) var3.lookup(this.datasourceName);
		} catch (NamingException var4) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "dsLookup", "Naming exception when looking up the datasource.",
						WIMMessageHelper.generateMsgParms(var4.getMessage()));
			}
		} catch (Exception var5) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "dsLookup", "Exception in getProviderURL()",
						WIMMessageHelper.generateMsgParms(var5.getMessage()));
			}

			var5.printStackTrace();
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "dsLookup");
		}

		return this.ds;
	}

	public Connection getConnection() throws WIMSystemException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getConnection()");
		}

		if (EnvironmentManager.singleton().isDirectAccessMode()) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "getConnection()",
						"direct access mode, getting direct access connection");
			}

			return this.getDirectAccessConnection();
		} else {
			if (this.ds == null) {
				this.dsLookup();
				if (this.ds == null) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "getConnection()",
								"no datasource, getting direct access connection");
					}

					return this.getDirectAccessConnection();
				}
			}

			try {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "getConnection()", "getting datasource connection");
				}

				Connection var2 = this.ds.getConnection();
				if (!this.isDB2JCCDriver()) {
					var2.setTransactionIsolation(2);
				}

				return var2;
			} catch (SQLException var3) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var3.getMessage()),
						CLASSNAME, "getConnection()", var3);
			}
		}
	}

	private boolean isDB2JCCDriver() {
		return this.dbDriver.equals("com.ibm.db2.jcc.DB2Driver");
	}

	private Class loadJDBCClass() throws WIMSystemException {
		Class var2;
		if (EnvironmentManager.singleton().isZOSControlRegion() && this.databaseType.equals("db2zos")) {
			trcLogger.logp(Level.FINE, CLASSNAME, "loadJDBCClass()", "loading JDBC driver for the z/OS control region");
			var2 = DAOHelper.loadJDBCClass(DAOHelper.getDB2Type4JDBCDriver());
		} else {
			trcLogger.logp(Level.FINE, CLASSNAME, "loadJDBCClass()",
					"loading JDBC driver for database type " + this.databaseType);
			var2 = DAOHelper.loadJDBCClass(this.dbDriver);
		}

		return var2;
	}

	public Connection getDirectAccessConnection() throws WIMSystemException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getDirectAccessConnection");
		}

		Connection var2 = null;

		try {
			Class var3 = this.loadJDBCClass();
			Object var4;
			Method var5;
			if (this.dbUserId != null && this.dbUserId.length() != 0) {
				trcLogger.logp(Level.FINE, CLASSNAME, "getDirectAccessConnection", "dbURL is " + this.dbURL);
				trcLogger.logp(Level.FINE, CLASSNAME, "getDirectAccessConnection", "dbUserId is " + this.dbUserId);
				var4 = var3.newInstance();
				var5 = var3.getMethod("connect", String.class, Properties.class);
				Properties var6 = new Properties();
				var6.put("user", this.dbUserId);
				var6.put("password", this.dbPassword);
				var2 = (Connection) var5.invoke(var4, this.dbURL, var6);
				var2.setTransactionIsolation(2);
			} else {
				trcLogger.logp(Level.INFO, CLASSNAME, "getDirectAccessConnection", "no db userId.");
				var4 = var3.newInstance();
				var5 = var3.getMethod("connect", String.class, Properties.class);
				var2 = (Connection) var5.invoke(var4, this.dbURL, new Properties());
				var2.setTransactionIsolation(2);
			}

			if (var2 == null) {
				throw new WIMSystemException("DATABASE_CONNECTION", WIMMessageHelper.generateMsgParms(this.dbURL),
						CLASSNAME, "getDirectAccessConnection");
			}

			this.needCommit.put(var2, new Boolean(true));
		} catch (Exception var7) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var7.getCause().getMessage()),
					CLASSNAME, "getDirectAccessConnection", var7);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getDirectAccessConnection");
		}

		return var2;
	}

	private boolean checkDirectConnection(String var1) throws WIMSystemException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "checkDirectConnection");
		}

		Class var3 = this.loadJDBCClass();
		Connection var4 = null;

		try {
			Object var5 = var3.newInstance();
			Method var6 = var3.getMethod("connect", String.class, Properties.class);
			Properties var7 = new Properties();
			var7.put("user", this.dbUserId);
			var7.put("password", var1);
			var4 = (Connection) var6.invoke(var5, this.dbURL, var7);
		} catch (Exception var8) {
			trcLogger.logp(Level.FINE, CLASSNAME, "checkDirectConnection",
					"Can't get connection with exception: " + var8.getMessage());
			return false;
		}

		if (var4 == null) {
			trcLogger.logp(Level.FINE, CLASSNAME, "checkDirectConnection", "Can't get connection without exception.");
			return false;
		} else {
			trcLogger.logp(Level.FINE, CLASSNAME, "checkDirectConnection", "Can get connection with new password");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "checkDirectConnection");
			}

			return true;
		}
	}

	public QuerySet getQuerySet() {
		return this.qs;
	}

	public long createDBEntity(DBEntity var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createDBEntity");
		}

		String var3 = var1.getEntityType();
		String var4 = var1.getUniqueId();
		String var5 = var1.getUniqueName();
		String var6 = DAOHelper.getTruncatedUniqueName(var5);
		int var7 = 0;
		Connection var8 = null;
		PreparedStatement var9 = null;
		long var10 = -1L;
		boolean var12 = false;

		while (!var12 && var7 < 25) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createDBEntity", "Attempt if not exception : " + var7);
			boolean var25 = false;

			StringBuffer var14;
			label204 : {
				try {
					var25 = true;
					var8 = this.getConnection();
					var10 = this.keyMgr.getDBKeyForTable(var8, "DBENTITY");
					String var13 = this.qs.createDBEntity;
					var9 = var8.prepareStatement(var13);
					var9.setLong(1, var10);
					var9.setString(2, var3);
					var9.setString(3, var4);
					var9.setString(4, var5);
					var9.setString(5, var6);
					var9.executeUpdate();
					var12 = true;
					var25 = false;
					break label204;
				} catch (NamingException var29) {
					var12 = true;
					throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME, "createDBEntity", var29);
				} catch (DuplicateKeyException var30) {
					var12 = false;
					if (!var30.getMessage().contains("WIMI") && !var30.getMessage().contains("WIMF")) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createDBEntity",
								"Throw exception if no contraint violation from VMM");
						throw new WIMSystemException("SQL_EXCEPTION",
								WIMMessageHelper.generateMsgParms(var30.getMessage()), CLASSNAME, "createDBEntity",
								var30);
					}

					++var7;
					trcLogger.logp(Level.FINE, CLASSNAME, "createDBEntity", "Attempt : " + var7);
					if (var7 >= 25) {
						var12 = true;
						throw new WIMSystemException("SQL_EXCEPTION",
								WIMMessageHelper.generateMsgParms(var30.getMessage()), CLASSNAME, "createDBEntity",
								var30);
					}

					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createDBEntity", "Reattempting " + var7 + " times");
						var25 = false;
					} else {
						var25 = false;
					}
				} catch (SQLException var31) {
					var12 = true;
					throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var31.getMessage()),
							CLASSNAME, "createDBEntity", var31);
				} finally {
					if (var25) {
						try {
							if (var9 != null) {
								var9.close();
							}

							this.closeConnection(var8);
						} catch (Exception var26) {
							if (trcLogger.isLoggable(Level.FINE)) {
								StringBuffer var17 = new StringBuffer(
										"Unexpected error when closing the prepared statement or the connection : ");
								var17.append(var26.toString());
								trcLogger.logp(Level.FINE, CLASSNAME, "createDBEntity", var17.toString(),
										WIMMessageHelper.generateMsgParms(var26));
							}
						}

						var9 = null;
						var8 = null;
					}
				}

				try {
					if (var9 != null) {
						var9.close();
					}

					this.closeConnection(var8);
				} catch (Exception var27) {
					if (trcLogger.isLoggable(Level.FINE)) {
						var14 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var14.append(var27.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "createDBEntity", var14.toString(),
								WIMMessageHelper.generateMsgParms(var27));
					}
				}

				var9 = null;
				var8 = null;
				continue;
			}

			try {
				if (var9 != null) {
					var9.close();
				}

				this.closeConnection(var8);
			} catch (Exception var28) {
				if (trcLogger.isLoggable(Level.FINE)) {
					var14 = new StringBuffer(
							"Unexpected error when closing the prepared statement or the connection : ");
					var14.append(var28.toString());
					trcLogger.logp(Level.FINE, CLASSNAME, "createDBEntity", var14.toString(),
							WIMMessageHelper.generateMsgParms(var28));
				}
			}

			var9 = null;
			var8 = null;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createDBEntity");
		}

		return var10;
	}

	public void createParentRelationship(long var1, DBEntity var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createParentRelationship");
		}

		String var5 = var3.getUniqueId();
		String var6 = DAOHelper.getTruncatedUniqueName(var3.getUniqueName());
		Connection var7 = null;
		PreparedStatement var8 = null;
		PreparedStatement var9 = null;
		ResultSet var10 = null;

		try {
			var7 = this.getConnection();
			if (var5 != null && var5.length() != 0) {
				var8 = var7.prepareStatement(this.qs.findDBEntityIdByUniqueId);
				var8.setString(1, var5);
			} else if (var6 != null && var6.length() != 0) {
				var8 = var7.prepareStatement(this.qs.findDBEntityIdByTruncUniqueName);
				var8.setString(1, var6);
			}

			var10 = var8.executeQuery();

			long var11;
			for (var11 = -1L; var10.next(); var11 = var10.getLong(1)) {
				;
			}

			if (var11 == -1L) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND",
						WIMMessageHelper.generateMsgParms(var6 + "/" + var5), CLASSNAME, "createParentRelationship");
			}

			var9 = var7.prepareStatement(this.qs.createEntityRelation);
			var9.setLong(1, var1);
			var9.setLong(2, var11);
			var9.executeUpdate();
		} catch (SQLException var29) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var29.getMessage()),
					CLASSNAME, "createParentRelationship", var29);
		} finally {
			try {
				if (var8 != null) {
					var8.close();
				}
			} catch (Exception var28) {
				;
			}

			try {
				if (var10 != null) {
					var10.close();
				}
			} catch (Exception var27) {
				;
			}

			try {
				if (var9 != null) {
					var9.close();
				}
			} catch (Exception var26) {
				;
			}

			try {
				if (var7 != null) {
					this.closeConnection(var7);
				}
			} catch (Exception var25) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createParentRelationship");
		}

	}

	public void closeConnection(Connection var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "closeConnection");
		}

		try {
			if (this.needCommit.get(var1) != null) {
				if (!this.isDB2JCCDriver()) {
					var1.commit();
				}

				this.needCommit.remove(var1);
			}

			var1.close();
		} catch (SQLException var5) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var4 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var4.append(var5.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "closeConnection", var4.toString(),
						WIMMessageHelper.generateMsgParms(var5));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "closeConnection");
		}

	}

	public boolean checkIfEntityHasDescendants(String var1) throws WIMSystemException {
		String var2 = "checkIfEntityHasDescendant(String uniqueName)";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2);
		}

		boolean var3 = false;
		Connection var4 = null;
		PreparedStatement var5 = null;
		ResultSet var6 = null;
		boolean var16 = false;

		try {
			var16 = true;
			var4 = this.getConnection();
			var5 = var4.prepareStatement(this.qs.findDescendantsByUniqueNames);
			var5.setString(1, var1);
			var6 = var5.executeQuery();
			if (var6.next()) {
				var3 = true;
				var16 = false;
			} else {
				var16 = false;
			}
		} catch (SQLException var17) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var17.getMessage()),
					CLASSNAME, var2, var17);
		} finally {
			if (var16) {
				try {
					if (var6 != null) {
						var6.close();
					}

					if (var5 != null) {
						var5.close();
					}

					if (var4 != null) {
						this.closeConnection(var4);
					}
				} catch (Exception var18) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var11 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var11.append(var18.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, var2, var11.toString(),
								WIMMessageHelper.generateMsgParms(var18));
					}
				}

			}
		}

		try {
			if (var6 != null) {
				var6.close();
			}

			if (var5 != null) {
				var5.close();
			}

			if (var4 != null) {
				this.closeConnection(var4);
			}
		} catch (Exception var20) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var8 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var8.append(var20.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, var2, var8.toString(), WIMMessageHelper.generateMsgParms(var20));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var2);
		}

		return var3;
	}

	public Long createCompositePropValue(short var1, Integer var2, long var3, Long var5, String var6)
			throws WIMSystemException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createCompositePropValue");
		}

		Long var8 = null;
		Connection var9 = null;
		PreparedStatement var10 = null;
		String var11 = null;
		String var12 = null;
		if (var1 == 0) {
			var11 = "DBCOMPPROP";
			var12 = this.qs.createDBCompositePropertyValue;
		} else if (var1 == 1) {
			var11 = "LACOMPPROP";
			var12 = this.qs.createLACompositePropertyValue;
		}

		boolean var13 = false;

		while (!var13) {
			try {
				var9 = this.getConnection();
				long var14 = -1L;
				if (var1 == 0) {
					var14 = this.keyMgr.getDBKeyForTable(var9, var11);
				} else {
					var14 = this.keyMgr.getLAKeyForTable(var9, var11);
				}

				var10 = var9.prepareStatement(var12);
				var10.setLong(1, var14);
				var10.setInt(2, var2);
				var10.setLong(3, var3);
				if (var5 != null && var5 != 0L) {
					var10.setLong(4, var5);
				} else {
					var10.setNull(4, -5);
				}

				if (var6 == null) {
					var10.setNull(5, 12);
				} else {
					var10.setString(5, var6);
				}

				var10.executeUpdate();
				var13 = true;
				if (var14 != -1L) {
					var8 = new Long(var14);
				}
			} catch (NamingException var26) {
				var13 = true;
				throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME, "createCompositePropValue", var26);
			} catch (DuplicateKeyException var27) {
				var13 = false;
				if (var27.getMessage().contains("WIMI") || var27.getMessage().contains("WIMF")) {
					var13 = true;
					throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var27.getMessage()),
							CLASSNAME, "createCompositePropValue", var27);
				}

				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "createCompositePropValue", "Reattempting");
				}
			} catch (SQLException var28) {
				var13 = true;
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var28.getMessage()),
						CLASSNAME, "createCompositePropValue", var28);
			} finally {
				try {
					this.closeConnection(var9);
					var10.close();
				} catch (Exception var25) {
					;
				}

				var10 = null;
				var9 = null;
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createCompositePropValue");
		}

		return var8;
	}

	public void createProperties(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
		}

		if (var4 != null) {
			Connection var9 = null;
			PreparedStatement var10 = null;

			try {
				for (short var11 = 0; var11 < var4.length; ++var11) {
					if (var4[var11] != null) {
						String var12 = this.getInsertStmtForPropertyValue(var1, var11);
						int var13 = var4[var11].size();
						Set var14 = var4[var11].keySet();
						Iterator var15 = var14.iterator();
						if (var9 == null) {
							var9 = this.getConnection();
						}

						var10 = var9.prepareStatement(var12);
						String var16 = DAOHelper.getValueTableName(var1, var11);

						while (var15.hasNext()) {
							Integer var17 = (Integer) var15.next();
							Object var18;
							if (var6.contains(var17)) {
								var18 = (List) var4[var11].get(var17);
							} else {
								var18 = new ArrayList();
								((List) var18).add(var4[var11].get(var17));
							}

							if (((List) var18).size() != 0) {
								for (int var19 = 0; var19 < ((List) var18).size(); ++var19) {
									long var20 = -1L;
									if (var1 == 0) {
										var20 = this.keyMgr.getDBKeyForTable(var9, var16);
									} else {
										var20 = this.keyMgr.getLAKeyForTable(var9, var16);
									}

									var10.setLong(1, var20);
									var10.setInt(2, var17);
									var10.setString(3, DAOHelper.getDataType(var11));
									var10.setLong(4, var2);
									if (var5 != null) {
										var10.setLong(5, var5);
									} else {
										var10.setNull(5, -5);
									}

									var10.setString(6, "");

									try {
										DataObject var28;
										switch (var11) {
											case 0 :
												var10.setString(7, (String) ((List) var18).get(var19));
												var10.setString(8, ((String) ((List) var18).get(var19)).toLowerCase());
												break;
											case 1 :
												long var58 = 0L;

												try {
													var58 = (Long) ((List) var18).get(var19);
												} catch (ClassCastException var52) {
													var58 = Long.parseLong((String) ((List) var18).get(var19));
												}

												var10.setLong(7, var58);
												break;
											case 2 :
												double var60 = 0.0D;

												try {
													var60 = (Double) ((List) var18).get(var19);
												} catch (ClassCastException var51) {
													var60 = Double.parseDouble((String) ((List) var18).get(var19));
												}

												var10.setDouble(7, var60);
												break;
											case 3 :
												boolean var61 = false;

												int var62;
												try {
													var62 = (Integer) ((List) var18).get(var19);
												} catch (ClassCastException var50) {
													var62 = new Integer(((List) var18).get(var19).toString());
												}

												var10.setInt(7, var62);
												break;
											case 4 :
												var28 = null;

												Timestamp var63;
												try {
													var63 = (Timestamp) ((List) var18).get(var19);
												} catch (ClassCastException var49) {
													String var66 = ((List) var18).get(var19).toString();
													SimpleDateFormat var67 = new SimpleDateFormat(
															"yyyy-MM-dd'T'HH:mm:ss.SSS");
													var67.setTimeZone(TimeZone.getTimeZone("GMT"));
													Date var68 = var67.parse(var66);
													var63 = new Timestamp(var68.getTime());
												}

												var10.setTimestamp(7, var63);
												break;
											case 5 :
												DataObject var22 = (DataObject) ((List) var18).get(var19);
												if (RepositoryManager.singleton().isEntryJoin()) {
													DataGraphHelper.prepareIdentifierFromFedRepository(var22);
												} else {
													String var23;
													if (var1 == 0 && var7 != null) {
														var23 = var22.getString("uniqueName");
														DBEntity var59 = this.findDBEntityByUniqueNameKey(
																DAOHelper.getTruncatedUniqueName(var23));
														var22.setString("externalId", var59.getUniqueId());
														var22.setString("repositoryId", var7);
													} else if (var1 == 1) {
														var23 = var22.getString("uniqueName");
														String var24 = var22.getString("externalId");
														String var25 = var22.getString("repositoryId");
														if (var23 == null || var24 == null || var25 == null) {
															DataObject var26 = SchemaManager.singleton()
																	.createRootDataObject();
															DataObject var27 = var26.createDataObject("entities",
																	"http://www.ibm.com/websphere/wim", "Entity");
															var28 = var27.createDataObject("identifier");
															var28.setString("uniqueName", var23);
															var28.setString("externalId", var24);
															var28.setString("repositoryId", var25);
															DataObject var64 = RepositoryManager.singleton()
																	.getRepositories()[0].get(var26);
															List var65 = var64.getList("entities");
															DataObject var31 = (DataObject) var65.get(0);
															DataObject var32 = var31.getDataObject("identifier");
															var23 = var32.getString("uniqueName");
															var24 = var32.getString("externalId");
															var25 = RepositoryManager.singleton().getRepositoryIds()[0];
															var22.setString("uniqueName", var23);
															var22.setString("externalId", var24);
															var22.setString("repositoryId", var7);
														}
													}
												}

												var10.setString(7, DAOHelper
														.getTruncatedUniqueName(var22.getString("uniqueName")));
												var10.setString(8, var22.getString("uniqueName"));
												var10.setString(9, DAOHelper
														.getTruncatedExternalId(var22.getString("externalId")));
												var10.setString(10, var22.getString("externalId"));
												var10.setString(11, var22.getString("repositoryId"));
												break;
											case 6 :
												ByteArrayOutputStream var29 = new ByteArrayOutputStream();
												ObjectOutputStream var30 = new ObjectOutputStream(var29);
												var30.writeObject(((List) var18).get(var19));
												var30.close();
												var10.setBytes(7, var29.toByteArray());
										}
									} catch (Exception var53) {
										throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
												WIMMessageHelper.generateMsgParms(var17), CLASSNAME,
												"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
												var53);
									}

									var10.addBatch();
								}
							}
						}

						int[] var57 = var10.executeBatch();
					}
				}
			} catch (NamingException var54) {
				throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
						var54);
			} catch (SQLException var55) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var55.getMessage()),
						CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
						var55);
			} finally {
				try {
					this.closeConnection(var9);
				} catch (Exception var48) {
					;
				}

				try {
					var10.close();
				} catch (Exception var47) {
					;
				}

			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
			}

		}
	}

	public void createProperties1(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
		}

		if (var4 != null) {
			Connection var9 = null;
			PreparedStatement var10 = null;

			try {
				label613 : for (short var11 = 0; var11 < var4.length; ++var11) {
					if (var4[var11] != null) {
						String var12 = this.getInsertStmtForPropertyValueWithoutKey(var1, var11);
						DAOHelper.getValueTableName(var1, var11);
						int var14 = var4[var11].size();
						Set var15 = var4[var11].keySet();
						Iterator var16 = var15.iterator();
						if (var9 == null) {
							var9 = this.getConnection();
						}

						while (true) {
							Integer var17;
							Object var18;
							do {
								if (!var16.hasNext()) {
									continue label613;
								}

								var17 = (Integer) var16.next();
								if (var6.contains(var17)) {
									var18 = (List) var4[var11].get(var17);
								} else {
									var18 = new ArrayList();
									((List) var18).add(var4[var11].get(var17));
								}
							} while (((List) var18).size() == 0);

							for (int var19 = 0; var19 < ((List) var18).size(); ++var19) {
								boolean var20 = false;

								while (!var20) {
									try {
										var10 = var9.prepareStatement(var12);
										var10.setInt(1, var17);
										var10.setString(2, DAOHelper.getDataType(var11));
										var10.setLong(3, var2);
										if (var5 != null) {
											var10.setLong(4, var5);
										} else {
											var10.setNull(4, -5);
										}

										var10.setString(5, "");

										try {
											DataObject var27;
											switch (var11) {
												case 0 :
													var10.setString(6, (String) ((List) var18).get(var19));
													var10.setString(7,
															((String) ((List) var18).get(var19)).toLowerCase());
													break;
												case 1 :
													long var78 = 0L;

													try {
														var78 = (Long) ((List) var18).get(var19);
													} catch (ClassCastException var72) {
														var78 = Long.parseLong((String) ((List) var18).get(var19));
													}

													var10.setLong(6, var78);
													break;
												case 2 :
													double var80 = 0.0D;

													try {
														var80 = (Double) ((List) var18).get(var19);
													} catch (ClassCastException var71) {
														var80 = Double.parseDouble((String) ((List) var18).get(var19));
													}

													var10.setDouble(6, var80);
													break;
												case 3 :
													boolean var81 = false;

													int var82;
													try {
														var82 = (Integer) ((List) var18).get(var19);
													} catch (ClassCastException var70) {
														var82 = new Integer(((List) var18).get(var19).toString());
													}

													var10.setInt(6, var82);
													break;
												case 4 :
													var27 = null;

													Timestamp var83;
													try {
														var83 = (Timestamp) ((List) var18).get(var19);
													} catch (ClassCastException var69) {
														String var86 = ((List) var18).get(var19).toString();
														SimpleDateFormat var87 = new SimpleDateFormat(
																"yyyy-MM-dd'T'HH:mm:ss.SSS");
														var87.setTimeZone(TimeZone.getTimeZone("GMT"));
														Date var88 = var87.parse(var86);
														var83 = new Timestamp(var88.getTime());
													}

													var10.setTimestamp(6, var83);
													break;
												case 5 :
													DataObject var21 = (DataObject) ((List) var18).get(var19);
													if (RepositoryManager.singleton().isEntryJoin()) {
														DataGraphHelper.prepareIdentifierFromFedRepository(var21);
													} else {
														String var22;
														if (var1 == 0 && var7 != null) {
															var22 = var21.getString("uniqueName");
															DBEntity var79 = this.findDBEntityByUniqueNameKey(
																	DAOHelper.getTruncatedUniqueName(var22));
															var21.setString("externalId", var79.getUniqueId());
															var21.setString("repositoryId", var7);
														} else if (var1 == 1) {
															var22 = var21.getString("uniqueName");
															String var23 = var21.getString("externalId");
															String var24 = var21.getString("repositoryId");
															if (var22 == null || var23 == null || var24 == null) {
																DataObject var25 = SchemaManager.singleton()
																		.createRootDataObject();
																DataObject var26 = var25.createDataObject("entities",
																		"http://www.ibm.com/websphere/wim", "Entity");
																var27 = var26.createDataObject("identifier");
																var27.setString("uniqueName", var22);
																var27.setString("externalId", var23);
																var27.setString("repositoryId", var24);
																DataObject var84 = RepositoryManager.singleton()
																		.getRepositories()[0].get(var25);
																List var85 = var84.getList("entities");
																DataObject var30 = (DataObject) var85.get(0);
																DataObject var31 = var30.getDataObject("identifier");
																var22 = var31.getString("uniqueName");
																var23 = var31.getString("externalId");
																var24 = RepositoryManager.singleton()
																		.getRepositoryIds()[0];
																var21.setString("uniqueName", var22);
																var21.setString("externalId", var23);
																var21.setString("repositoryId", var7);
															}
														}
													}

													var10.setString(6, DAOHelper
															.getTruncatedUniqueName(var21.getString("uniqueName")));
													var10.setString(7, var21.getString("uniqueName"));
													var10.setString(8, DAOHelper
															.getTruncatedExternalId(var21.getString("externalId")));
													var10.setString(9, var21.getString("externalId"));
													var10.setString(10, var21.getString("repositoryId"));
													break;
												case 6 :
													ByteArrayOutputStream var28 = new ByteArrayOutputStream();
													ObjectOutputStream var29 = new ObjectOutputStream(var28);
													var29.writeObject(((List) var18).get(var19));
													var29.close();
													var10.setBytes(6, var28.toByteArray());
											}
										} catch (Exception var73) {
											throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
													WIMMessageHelper.generateMsgParms(var17), CLASSNAME,
													"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													var73);
										}

										var10.executeUpdate();
										var20 = true;
									} catch (DuplicateKeyException var74) {
										var20 = false;
										if (var74.getMessage().contains("WIMI")
												|| var74.getMessage().contains("WIMF")) {
											var20 = true;
											throw new WIMSystemException("SQL_EXCEPTION",
													WIMMessageHelper.generateMsgParms(var74.getMessage()), CLASSNAME,
													"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													var74);
										}

										if (trcLogger.isLoggable(Level.FINE)) {
											trcLogger.logp(Level.FINE, CLASSNAME,
													"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													"Reattempting");
										}
									} catch (SQLException var75) {
										var20 = true;
										throw new WIMSystemException("SQL_EXCEPTION",
												WIMMessageHelper.generateMsgParms(var75.getMessage()), CLASSNAME,
												"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
												var75);
									} finally {
										try {
											var10.close();
										} catch (Exception var68) {
											;
										}

										var10 = null;
									}
								}
							}
						}
					}
				}
			} finally {
				try {
					this.closeConnection(var9);
				} catch (Exception var67) {
					;
				}

				try {
					var10.close();
				} catch (Exception var66) {
					;
				}

				var9 = null;
				var10 = null;
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
			}

		}
	}

	public void createGroupRelationsForEntity(String var1, String var2, List var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createGroupRelationsForEntity(String reposId, String uuid, List groupIds)");
		}

		ArrayList var5 = null;
		ArrayList var6 = null;

		String var9;
		for (int var7 = 0; var7 < var3.size(); ++var7) {
			String var8 = ((DataObject) var3.get(var7)).getString("uniqueName");
			if (var8 != null && var8.trim().length() != 0) {
				if (var5 == null) {
					var5 = new ArrayList();
				}

				var5.add(var8.trim().toLowerCase());
			} else {
				var9 = ((DataObject) var3.get(var7)).getString("uniqueId");
				if (var9 == null || var9.trim().length() == 0) {
					throw new EntityNotFoundException("ENTITY_NOT_FOUND", CLASSNAME,
							"createGroupRelationsForEntity(String reposId, String uuid, List groupIds)");
				}

				if (var6 == null) {
					var6 = new ArrayList();
				}

				var6.add(var9.trim());
			}
		}

		Connection var72 = null;
		PreparedStatement var73 = null;
		var9 = null;
		ResultSet var10 = null;
		long[] var11 = new long[var3.size()];
		boolean var12 = false;
		String var13;
		int var14;
		if (var5 != null) {
			var9 = this.qs.selectGEntIdwithGNames;
			var13 = null;

			try {
				var72 = this.getConnection();

				for (var14 = 0; var14 < var5.size(); ++var14) {
					var73 = var72.prepareStatement(var9);
					var13 = (String) var5.get(var14);
					var73.setString(1, var13);

					for (var10 = var73.executeQuery(); var10.next(); var11[var14] = var10.getLong(1)) {
						;
					}

					try {
						var10.close();
					} catch (Exception var65) {
						;
					}
				}
			} catch (SQLException var70) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND",
						WIMMessageHelper.generateMsgParms("[" + null + "/" + var13 + "]"), CLASSNAME,
						"createGroupRelationsForEntity(String reposId, String uuid, List groupIds)");
			} finally {
				try {
					var73.close();
					var10.close();
					var9 = null;
				} catch (Exception var61) {
					;
				}

			}
		}

		if (var6 != null) {
			var9 = this.qs.selectGEntIdwithGUIDs;
			var13 = null;

			try {
				if (var72 == null) {
					var72 = this.getConnection();
				}

				for (var14 = 0; var14 < var6.size(); ++var14) {
					var73 = var72.prepareStatement(var9);
					var13 = (String) var6.get(var14);
					var73.setString(1, var13);

					for (var10 = var73.executeQuery(); var10.next(); var11[var14] = var10.getLong(1)) {
						;
					}

					try {
						var10.close();
					} catch (Exception var64) {
						;
					}
				}
			} catch (SQLException var68) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND",
						WIMMessageHelper.generateMsgParms("[" + var13 + "/" + null + "]"), CLASSNAME,
						"createGroupRelationsForEntity(String reposId, String uuid, List groupIds)");
			} finally {
				try {
					var73.close();
					var10.close();
				} catch (Exception var63) {
					;
				}

			}
		}

		var13 = this.qs.createDBGrpRelation;

		try {
			if (var72 == null) {
				var72 = this.getConnection();
			}

			var73 = var72.prepareStatement(var13);
			var14 = 0;

			while (true) {
				if (var14 >= var11.length) {
					int[] var74 = var73.executeBatch();
					break;
				}

				var73.setLong(1, var11[var14]);
				var73.setString(2, var1);
				var73.setString(3, DAOHelper.getTruncatedExternalId(var2));
				var73.setString(4, var2);
				var73.addBatch();
				++var14;
			}
		} catch (Exception var66) {
			throw new WIMSystemException();
		} finally {
			try {
				this.closeConnection(var72);
				var73.close();
			} catch (Exception var62) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createGroupRelationsForEntity(String reposId, String uuid, List groupIds)");
		}

	}

	public void createGroupRelationsForGroup(long var1, List var3, String var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createGroupRelationsForGroup(long newEntId, List memberIds)");
		}

		Connection var6 = null;
		PreparedStatement var7 = null;
		String var8 = null;

		try {
			if (var3.size() > 0) {
				var8 = this.qs.createDBGrpRelation;
				var6 = this.getConnection();
				var7 = var6.prepareStatement(var8);
				int var9 = 0;

				while (true) {
					if (var9 >= var3.size()) {
						int[] var27 = var7.executeBatch();
						break;
					}

					String var10 = ((DataObject) var3.get(var9)).getString("repositoryId");
					String var11 = ((DataObject) var3.get(var9)).getString("externalId");
					String var12 = ((DataObject) var3.get(var9)).getString("uniqueName");
					String var13 = ((DataObject) var3.get(var9)).getString("uniqueId");
					if (var10 != null && var10.trim().length() != 0 && var11 != null && var11.trim().length() != 0) {
						var7.setLong(1, var1);
						var7.setString(2, var10);
						var7.setString(3, DAOHelper.getTruncatedExternalId(var11));
						var7.setString(4, var11);
						var7.addBatch();
					} else if (var13 != null && var13.trim().length() != 0) {
						var7.setLong(1, var1);
						var7.setString(2, var4);
						var7.setString(3, DAOHelper.getTruncatedExternalId(var13));
						var7.setString(4, var13);
						var7.addBatch();
					} else {
						if (var12 == null || var12.trim().length() == 0) {
							throw new InvalidIdentifierException("INVALID_IDENTIFIER",
									WIMMessageHelper.generateMsgParms("[" + var13 + "/" + var12 + "]"), CLASSNAME,
									"createGroupRelationsForGroup(long newEntId, List memberIds)");
						}

						String var14 = null;

						try {
							var14 = this.findUniqueIdByUniqueName(var12);
						} catch (Exception var24) {
							throw new EntityNotFoundException("ENTITY_NOT_FOUND",
									WIMMessageHelper.generateMsgParms("[" + null + "/" + var12 + "]"), CLASSNAME,
									"createGroupRelationsForGroup(long newEntId, List memberIds)");
						}

						if (var14 == null) {
							throw new EntityNotFoundException("ENTITY_NOT_FOUND",
									WIMMessageHelper.generateMsgParms("[" + null + "/" + var12 + "]"), CLASSNAME,
									"createGroupRelationsForGroup(long newEntId, List memberIds)");
						}

						var7.setLong(1, var1);
						var7.setString(2, var4);
						var7.setString(3, DAOHelper.getTruncatedExternalId(var14));
						var7.setString(4, var14);
						var7.addBatch();
					}

					++var9;
				}
			}
		} catch (SQLException var25) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var25.getMessage()),
					CLASSNAME, "createGroupRelationsForGroup(long newEntId, List memberIds)", var25);
		} finally {
			try {
				this.closeConnection(var6);
				var7.close();
			} catch (Exception var23) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createGroupRelationsForGroup(long newEntId, List memberIds)");
		}

	}

	protected String getInsertStmtForPropertyValue(short var1, short var2) {
		String var3 = null;
		if (var1 == 0) {
			if (var2 == 0) {
				var3 = this.qs.createDBStringValue;
			} else if (var2 == 1) {
				var3 = this.qs.createDBLongValue;
			} else if (var2 == 2) {
				var3 = this.qs.createDBDoubleValue;
			} else if (var2 == 3) {
				var3 = this.qs.createDBIntegerValue;
			} else if (var2 == 4) {
				var3 = this.qs.createDBTimestampValue;
			} else if (var2 == 5) {
				var3 = this.qs.createDBReferenceValue;
			} else if (var2 == 6) {
				var3 = this.qs.createDBBlobValue;
			}
		} else if (var1 == 1) {
			if (var2 == 0) {
				var3 = this.qs.createLAStringValue;
			} else if (var2 == 1) {
				var3 = this.qs.createLALongValue;
			} else if (var2 == 2) {
				var3 = this.qs.createLADoubleValue;
			} else if (var2 == 3) {
				var3 = this.qs.createLAIntegerValue;
			} else if (var2 == 4) {
				var3 = this.qs.createLATimestampValue;
			} else if (var2 == 5) {
				var3 = this.qs.createLAReferenceValue;
			} else if (var2 == 6) {
				var3 = this.qs.createLABlobValue;
			}
		}

		return var3;
	}

	protected String getInsertStmtForPropertyValueWithoutKey(short var1, short var2) {
		String var3 = null;
		if (var1 == 0) {
			if (var2 == 0) {
				var3 = this.qs.createDBStringValueWithoutKey;
			} else if (var2 == 1) {
				var3 = this.qs.createDBLongValueWithoutKey;
			} else if (var2 == 2) {
				var3 = this.qs.createDBDoubleValueWithoutKey;
			} else if (var2 == 3) {
				var3 = this.qs.createDBIntegerValueWithoutKey;
			} else if (var2 == 4) {
				var3 = this.qs.createDBTimestampValueWithoutKey;
			} else if (var2 == 5) {
				var3 = this.qs.createDBReferenceValueWithoutKey;
			} else if (var2 == 6) {
				var3 = this.qs.createDBBlobValueWithoutKey;
			}
		} else if (var1 == 1 && this.isUseTriggerForIdInLARepo) {
			if (var2 == 0) {
				var3 = this.qs.createLAStringValueWithoutValueId;
			} else if (var2 == 1) {
				var3 = this.qs.createLALongValueWithoutValueId;
			} else if (var2 == 2) {
				var3 = this.qs.createLADoubleValueWithoutValueId;
			} else if (var2 == 3) {
				var3 = this.qs.createLAIntegerValueWithoutValueId;
			} else if (var2 == 4) {
				var3 = this.qs.createLATimestampValueWithoutValueId;
			} else if (var2 == 5) {
				var3 = this.qs.createLAReferenceValueWithoutValueId;
			} else if (var2 == 6) {
				var3 = this.qs.createLABlobValueWithoutValueId;
			}
		} else if (var1 == 1) {
			if (var2 == 0) {
				var3 = this.qs.createLAStringValueWithoutKey;
			} else if (var2 == 1) {
				var3 = this.qs.createLALongValueWithoutKey;
			} else if (var2 == 2) {
				var3 = this.qs.createLADoubleValueWithoutKey;
			} else if (var2 == 3) {
				var3 = this.qs.createLAIntegerValueWithoutKey;
			} else if (var2 == 4) {
				var3 = this.qs.createLATimestampValueWithoutKey;
			} else if (var2 == 5) {
				var3 = this.qs.createLAReferenceValueWithoutKey;
			} else if (var2 == 6) {
				var3 = this.qs.createLABlobValueWithoutKey;
			}
		}

		return var3;
	}

	private String getUpdateStmtForPropertyValue(short var1, short var2) {
		String var3 = null;
		if (var1 == 0) {
			if (var2 == 0) {
				var3 = this.qs.updateDBStringValue;
			} else if (var2 == 1) {
				var3 = this.qs.updateDBLongValue;
			} else if (var2 == 2) {
				var3 = this.qs.updateDBDoubleValue;
			} else if (var2 == 3) {
				var3 = this.qs.updateDBIntegerValue;
			} else if (var2 == 4) {
				var3 = this.qs.updateDBTimestampValue;
			} else if (var2 == 5) {
				var3 = this.qs.updateDBReferenceValue;
			} else if (var2 == 6) {
				var3 = this.qs.updateDBBlobValue;
			}
		} else if (var1 == 1) {
			if (var2 == 0) {
				var3 = this.qs.updateLAStringValue;
			} else if (var2 == 1) {
				var3 = this.qs.updateLALongValue;
			} else if (var2 == 2) {
				var3 = this.qs.updateLADoubleValue;
			} else if (var2 == 3) {
				var3 = this.qs.updateLAIntegerValue;
			} else if (var2 == 4) {
				var3 = this.qs.updateLATimestampValue;
			} else if (var2 == 5) {
				var3 = this.qs.updateLAReferenceValue;
			} else if (var2 == 6) {
				var3 = this.qs.updateLABlobValue;
			}
		}

		return var3;
	}

	private String getUpdateStmtForPropertyValueWithOldValue(short var1, short var2) {
		String var3 = null;
		if (var1 == 0) {
			if (var2 == 0) {
				var3 = this.qs.updateDBStringValueWithOldValue;
			} else if (var2 == 1) {
				var3 = this.qs.updateDBLongValueWithOldValue;
			} else if (var2 == 2) {
				var3 = this.qs.updateDBDoubleValueWithOldValue;
			} else if (var2 == 3) {
				var3 = this.qs.updateDBIntegerValueWithOldValue;
			} else if (var2 == 4) {
				var3 = this.qs.updateDBTimestampValueWithOldValue;
			} else if (var2 == 5) {
				var3 = this.qs.updateDBReferenceValueWithOldValue;
			} else if (var2 == 6) {
				var3 = this.qs.updateDBBlobValueWithOldValue;
			}
		} else if (var1 == 1) {
			if (var2 == 0) {
				var3 = this.qs.updateLAStringValueWithOldValue;
			} else if (var2 == 1) {
				var3 = this.qs.updateLALongValueWithOldValue;
			} else if (var2 == 2) {
				var3 = this.qs.updateLADoubleValueWithOldValue;
			} else if (var2 == 3) {
				var3 = this.qs.updateLAIntegerValueWithOldValue;
			} else if (var2 == 4) {
				var3 = this.qs.updateLATimestampValueWithOldValue;
			} else if (var2 == 5) {
				var3 = this.qs.updateLAReferenceValueWithOldValue;
			} else if (var2 == 6) {
				var3 = this.qs.updateLABlobValueWithOldValue;
			}
		}

		return var3;
	}

	public void deleteDBGroupRelation(Hashtable var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteDBGroupRelation(Hashtable grpMbrs)", "grpMbrs=" + var1);
		}

		Connection var3 = null;
		PreparedStatement var4 = null;
		String var5 = null;
		int var6 = 0;
		ArrayList var7 = null;
		Enumeration var8 = var1.keys();

		while (var8.hasMoreElements()) {
			String var9 = (String) var8.nextElement();
			if (var9 != null) {
				List var10 = (List) var1.get(var9);
				if (var10 != null) {
					if (var7 == null) {
						var7 = new ArrayList();
					}

					var7.add(var9);
					var6 += var10.size();
				}
			}
		}

		if (var6 > 0) {
			var5 = this.qs.removeDBGroupRelationMain;

			int var26;
			for (var26 = 0; var26 < var6 - 1; ++var26) {
				var5 = var5.concat(this.qs.orRemoveDBGroupRelationByExtIdAndReposId);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "deleteDBGroupRelation(Hashtable grpMbrs)",
						"sql statement is " + var5);
			}

			boolean var21 = false;

			try {
				var21 = true;
				var3 = this.getConnection();
				var4 = var3.prepareStatement(var5);
				var26 = 1;
				int var27 = 0;

				while (true) {
					if (var27 >= var7.size()) {
						var4.executeUpdate();
						var21 = false;
						break;
					}

					String var11 = (String) var7.get(var27);
					List var12 = (List) var1.get(var11);

					for (int var13 = 0; var13 < var12.size(); ++var13) {
						var4.setString(var26++, (String) var12.get(var13));
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "deleteDBGroupRelation(Hashtable grpMbrs)",
									"param " + var26 + " to set is " + var12.get(var13));
						}

						var4.setString(var26++, var11);
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "deleteDBGroupRelation(Hashtable grpMbrs)",
									"param " + var26 + " to set is " + var11);
						}
					}

					++var27;
				}
			} catch (SQLException var24) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var24.getMessage()),
						CLASSNAME, "deleteDBGroupRelation(Hashtable grpMbrs)", var24);
			} finally {
				if (var21) {
					try {
						if (var4 != null) {
							var4.close();
						}

						if (var3 != null) {
							this.closeConnection(var3);
						}
					} catch (SQLException var22) {
						if (trcLogger.isLoggable(Level.FINE)) {
							StringBuffer var16 = new StringBuffer(
									"Unexpected error when closing the prepared statement or the connection : ");
							var16.append(var22.toString());
							trcLogger.logp(Level.FINE, CLASSNAME, "deleteDBGroupRelation(Hashtable grpMbrs)",
									var16.toString(), WIMMessageHelper.generateMsgParms(var22));
						}
					}

				}
			}

			try {
				if (var4 != null) {
					var4.close();
				}

				if (var3 != null) {
					this.closeConnection(var3);
				}
			} catch (SQLException var23) {
				if (trcLogger.isLoggable(Level.FINE)) {
					StringBuffer var28 = new StringBuffer(
							"Unexpected error when closing the prepared statement or the connection : ");
					var28.append(var23.toString());
					trcLogger.logp(Level.FINE, CLASSNAME, "deleteDBGroupRelation(Hashtable grpMbrs)", var28.toString(),
							WIMMessageHelper.generateMsgParms(var23));
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "deleteDBGroupRelation(Hashtable grpMbrs)");
		}

	}

	public void deleteEntityWithDescendants(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteEntityWithDescendants(String uniqueName)");
		}

		Connection var3 = null;
		PreparedStatement var4 = null;
		boolean var14 = false;

		try {
			var14 = true;
			var3 = this.getConnection();
			var4 = var3.prepareStatement(this.qs.deleteDBEntityWithDescendants);
			var4.setString(1, "%" + var1.trim().toLowerCase());
			int var5 = var4.executeUpdate();
			if (var5 == 0) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						CLASSNAME, "deleteEntityWithDescendants(String uniqueName)");
			}

			var14 = false;
		} catch (SQLException var17) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var17.getMessage()),
					CLASSNAME, "deleteEntityWithDescendants(String uniqueName)", var17);
		} finally {
			if (var14) {
				try {
					if (var4 != null) {
						var4.close();
					}

					if (var3 != null) {
						this.closeConnection(var3);
					}
				} catch (SQLException var15) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var9 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var9.append(var15.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "deleteEntityWithDescendants(String uniqueName)",
								var9.toString(), WIMMessageHelper.generateMsgParms(var15));
					}
				}

			}
		}

		try {
			if (var4 != null) {
				var4.close();
			}

			if (var3 != null) {
				this.closeConnection(var3);
			}
		} catch (SQLException var16) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var6 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var6.append(var16.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "deleteEntityWithDescendants(String uniqueName)", var6.toString(),
						WIMMessageHelper.generateMsgParms(var16));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "deleteEntityWithDescendants(String uniqueName)");
		}

	}

	public void deleteCompositeProperties(short var1, long var2, Hashtable var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteCompositeProperties(short schema, long entId, Hashtable compProps)");
		}

		Connection var6 = null;
		PreparedStatement var7 = null;

		try {
			String var8 = null;
			if (var1 == 0) {
				var8 = this.qs.deleteDBCompositeProperties;
			} else {
				var8 = this.qs.deleteLACompositeProperties;
			}

			for (short var9 = 0; var9 < var4.size(); ++var9) {
				var8 = var8 + this.qs.PARAM_MARKER;
				if (var9 != var4.size() - 1) {
					var8 = var8 + this.qs.COMMA;
				}
			}

			var8 = var8 + this.qs.RIGHT_BRACKET;
			var6 = this.getConnection();
			int var24 = 2;
			var7 = var6.prepareStatement(var8);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME,
						"deleteCompositeProperties(short schema, long entId, Hashtable compProps)",
						"The delete sql is " + var8);
			}

			var7.setLong(1, var2);
			Enumeration var10 = var4.keys();

			while (true) {
				if (!var10.hasMoreElements()) {
					var7.executeUpdate();
					break;
				}

				Integer var11 = (Integer) var10.nextElement();
				var7.setInt(var24++, var11);
			}
		} catch (SQLException var22) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var22.getMessage()),
					CLASSNAME, "deleteCompositeProperties(short schema, long entId, Hashtable compProps)", var22);
		} finally {
			try {
				this.closeConnection(var6);
			} catch (Exception var21) {
				;
			}

			try {
				var7.close();
			} catch (Exception var20) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "deleteCompositeProperties(short schema, long entId, Hashtable compProps)");
		}

	}

	public String findUniqueIdByUniqueName(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "findUniqueIdsByUniqueName(String uniqueName)");
		}

		String var3 = null;
		Connection var4 = null;
		PreparedStatement var5 = null;
		String var6 = null;
		ResultSet var7 = null;
		boolean var17 = false;

		try {
			var17 = true;
			var6 = this.qs.findUniqueIdByUniqueNameKey;
			var4 = this.getConnection();
			var5 = var4.prepareStatement(var6);
			var5.setString(1, DAOHelper.getTruncatedUniqueName(var1));

			for (var7 = var5.executeQuery(); var7.next(); var3 = var7.getString(1)) {
				;
			}

			var17 = false;
		} catch (SQLException var20) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var20.getMessage()),
					CLASSNAME, "findUniqueIdsByUniqueName(String uniqueName)", var20);
		} finally {
			if (var17) {
				try {
					if (var5 != null) {
						var5.close();
					}

					if (var4 != null) {
						this.closeConnection(var4);
					}
				} catch (SQLException var18) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var12 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var12.append(var18.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "findUniqueIdsByUniqueName(String uniqueName)",
								var12.toString(), WIMMessageHelper.generateMsgParms(var18));
					}
				}

			}
		}

		try {
			if (var5 != null) {
				var5.close();
			}

			if (var4 != null) {
				this.closeConnection(var4);
			}
		} catch (SQLException var19) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var9 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var9.append(var19.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "findUniqueIdsByUniqueName(String uniqueName)", var9.toString(),
						WIMMessageHelper.generateMsgParms(var19));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "findUniqueIdsByUniqueName(String uniqueName)");
		}

		return var3;
	}

	public List findDBEntitysByParentName(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "findDBEntitysByParentName(String uniqueName)");
		}

		ArrayList var3 = null;
		Connection var4 = null;
		PreparedStatement var5 = null;
		String var6 = null;
		ResultSet var7 = null;
		boolean var17 = false;

		try {
			var17 = true;
			var6 = this.qs.findDBEntitysByUniqueNameKeyLike;
			var4 = this.getConnection();
			var5 = var4.prepareStatement(var6);
			var5.setString(1, "%" + var1.toLowerCase());
			var7 = var5.executeQuery();

			while (true) {
				if (!var7.next()) {
					var17 = false;
					break;
				}

				if (var3 == null) {
					var3 = new ArrayList();
				}

				DBEntity var8 = new DBEntity();
				var8.setEntityId(var7.getLong(1));
				var8.setEntityType(var7.getString(2));
				var8.setUniqueId(var7.getString(3));
				var8.setUniqueName(var7.getString(4));
				var3.add(var8);
			}
		} catch (SQLException var20) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var20.getMessage()),
					CLASSNAME, "findDBEntitysByParentName(String uniqueName)", var20);
		} finally {
			if (var17) {
				try {
					if (var5 != null) {
						var5.close();
					}

					if (var4 != null) {
						this.closeConnection(var4);
					}
				} catch (SQLException var18) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var12 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var12.append(var18.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "findDBEntitysByParentName(String uniqueName)",
								var12.toString(), WIMMessageHelper.generateMsgParms(var18));
					}
				}

			}
		}

		try {
			if (var5 != null) {
				var5.close();
			}

			if (var4 != null) {
				this.closeConnection(var4);
			}
		} catch (SQLException var19) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var9 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var9.append(var19.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "findDBEntitysByParentName(String uniqueName)", var9.toString(),
						WIMMessageHelper.generateMsgParms(var19));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "findDBEntitysByParentName(String uniqueName)");
		}

		return var3;
	}

	private DBEntity findDBEntityByEntityId(long var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "findDBEntityByEntityId", var1);
		}

		DBEntity var4 = null;
		Connection var5 = null;
		PreparedStatement var6 = null;
		String var7 = null;
		ResultSet var8 = null;
		boolean var18 = false;

		try {
			var18 = true;
			var7 = this.qs.findDBEntityByEntityId;
			var5 = this.getConnection();
			var6 = var5.prepareStatement(var7);
			var6.setLong(1, var1);
			var8 = var6.executeQuery();

			while (true) {
				if (!var8.next()) {
					var18 = false;
					break;
				}

				var4 = new DBEntity();
				var4.setEntityId(var8.getLong("ENTITY_ID"));
				var4.setEntityType(var8.getString("ENTITY_TYPE"));
				var4.setUniqueId(var8.getString("UNIQUE_ID").trim());
				var4.setUniqueName(var8.getString("UNIQUE_NAME"));
				var4.setTruncUniqueName(var8.getString("UNIQUE_NAME_KEY"));
			}
		} catch (SQLException var21) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var21.getMessage()),
					CLASSNAME, "findDBEntityByEntityId", var21);
		} finally {
			if (var18) {
				try {
					if (var6 != null) {
						var6.close();
					}

					if (var8 != null) {
						var8.close();
					}

					if (var5 != null) {
						this.closeConnection(var5);
					}
				} catch (SQLException var19) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var13 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var13.append(var19.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "findDBEntityByEntityId", var13.toString(),
								WIMMessageHelper.generateMsgParms(var19));
					}
				}

			}
		}

		try {
			if (var6 != null) {
				var6.close();
			}

			if (var8 != null) {
				var8.close();
			}

			if (var5 != null) {
				this.closeConnection(var5);
			}
		} catch (SQLException var20) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var10 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var10.append(var20.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "findDBEntityByEntityId", var10.toString(),
						WIMMessageHelper.generateMsgParms(var20));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "findDBEntityByEntityId");
		}

		return var4;
	}

	public DBEntity findDBEntityByUniqueId(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "findDBEntityByUniqueId(String uniqueId)", var1);
		}

		DBEntity var3 = null;
		Connection var4 = null;
		PreparedStatement var5 = null;
		String var6 = null;
		ResultSet var7 = null;
		boolean var17 = false;

		try {
			var17 = true;
			var6 = this.qs.findDBEntityByUniqueId;
			var4 = this.getConnection();
			var5 = var4.prepareStatement(var6);
			if (var1 != null && var1.length() > 36) {
				var1 = var1.substring(0, 36);
			}

			var5.setString(1, var1);
			var7 = var5.executeQuery();

			while (true) {
				if (!var7.next()) {
					var17 = false;
					break;
				}

				var3 = new DBEntity();
				var3.setEntityId(var7.getLong("ENTITY_ID"));
				var3.setEntityType(var7.getString("ENTITY_TYPE"));
				var3.setUniqueId(var7.getString("UNIQUE_ID").trim());
				var3.setUniqueName(var7.getString("UNIQUE_NAME"));
				var3.setTruncUniqueName(var7.getString("UNIQUE_NAME_KEY"));
			}
		} catch (SQLException var20) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var20.getMessage()),
					CLASSNAME, "findDBEntityByUniqueId(String uniqueId)", var20);
		} finally {
			if (var17) {
				try {
					if (var5 != null) {
						var5.close();
					}

					if (var7 != null) {
						var7.close();
					}

					if (var4 != null) {
						this.closeConnection(var4);
					}
				} catch (SQLException var18) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var12 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var12.append(var18.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "findDBEntityByUniqueId(String uniqueId)",
								var12.toString(), WIMMessageHelper.generateMsgParms(var18));
					}
				}

			}
		}

		try {
			if (var5 != null) {
				var5.close();
			}

			if (var7 != null) {
				var7.close();
			}

			if (var4 != null) {
				this.closeConnection(var4);
			}
		} catch (SQLException var19) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var9 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var9.append(var19.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "findDBEntityByUniqueId(String uniqueId)", var9.toString(),
						WIMMessageHelper.generateMsgParms(var19));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "findDBEntityByUniqueId(String uniqueId)");
		}

		return var3;
	}

	public DBEntity findDBEntityByUniqueNameKey(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "findDBEntityByUniqueNameKey(String uniqueNameKey)");
		}

		DBEntity var3 = null;
		Connection var4 = null;
		PreparedStatement var5 = null;
		String var6 = null;
		ResultSet var7 = null;
		var1 = DAOHelper.getTruncatedUniqueName(var1);
		if (var1.length() > 236) {
			var1 = var1.substring(0, 236);
		}

		boolean var17 = false;

		try {
			var17 = true;
			var6 = this.qs.findDBEntityByUniqueNameKey;
			var4 = this.getConnection();
			var5 = var4.prepareStatement(var6);
			var5.setString(1, var1);
			var7 = var5.executeQuery();

			while (true) {
				if (!var7.next()) {
					var17 = false;
					break;
				}

				var3 = new DBEntity();
				var3.setEntityId(var7.getLong("ENTITY_ID"));
				var3.setEntityType(var7.getString("ENTITY_TYPE"));
				var3.setUniqueId(var7.getString("UNIQUE_ID").trim());
				var3.setUniqueName(var7.getString("UNIQUE_NAME"));
				var3.setTruncUniqueName(var7.getString("UNIQUE_NAME_KEY"));
			}
		} catch (SQLException var20) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var20.getMessage()),
					CLASSNAME, "findDBEntityByUniqueNameKey(String uniqueNameKey)", var20);
		} finally {
			if (var17) {
				try {
					if (var5 != null) {
						var5.close();
					}

					if (var7 != null) {
						var7.close();
					}

					if (var4 != null) {
						this.closeConnection(var4);
					}
				} catch (SQLException var18) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var12 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var12.append(var18.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "findDBEntityByUniqueNameKey(String uniqueNameKey)",
								var12.toString(), WIMMessageHelper.generateMsgParms(var18));
					}
				}

			}
		}

		try {
			if (var5 != null) {
				var5.close();
			}

			if (var7 != null) {
				var7.close();
			}

			if (var4 != null) {
				this.closeConnection(var4);
			}
		} catch (SQLException var19) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var9 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var9.append(var19.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "findDBEntityByUniqueNameKey(String uniqueNameKey)",
						var9.toString(), WIMMessageHelper.generateMsgParms(var19));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "findDBEntityByUniqueNameKey(String uniqueNameKey)");
		}

		return var3;
	}

	public String getDBPropValuesByEntityQuery(short var1) {
		switch (var1) {
			case 0 :
				return this.qs.getDBStringPropValuesByEntityId;
			case 1 :
				return this.qs.getDBLongPropValuesByEntityId;
			case 2 :
				return this.qs.getDBDoublePropValuesByEntityId;
			case 3 :
				return this.qs.getDBIntegerPropValuesByEntityId;
			case 4 :
				return this.qs.getDBTimestampPropValuesByEntityId;
			case 5 :
				return this.qs.getDBReferencePropValuesByEntityId;
			case 6 :
				return this.qs.getDBObjectPropValuesByEntityId;
			default :
				return null;
		}
	}

	public String getLAPropValuesByEntityQuery(short var1) {
		switch (var1) {
			case 0 :
				return this.qs.getLAStringPropValuesByEntityId;
			case 1 :
				return this.qs.getLALongPropValuesByEntityId;
			case 2 :
				return this.qs.getLADoublePropValuesByEntityId;
			case 3 :
				return this.qs.getLAIntegerPropValuesByEntityId;
			case 4 :
				return this.qs.getLATimestampPropValuesByEntityId;
			case 5 :
				return this.qs.getLAReferencePropValuesByEntityId;
			case 6 :
				return this.qs.getLAObjectPropValuesByEntityId;
			default :
				return null;
		}
	}

	public void readDBProperties(long var1, StringBuffer var3, short var4, DataObject var5) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"readDBProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)");
		}

		Connection var7 = null;
		PreparedStatement var8 = null;
		ResultSet var9 = null;

		try {
			var3.append(this.qs.orderByPropertyNameInGetProperties);
			var7 = this.getConnection();
			var8 = var7.prepareStatement(var3.toString(), 1003, 1007);
			var8.setLong(1, var1);
			var9 = var8.executeQuery();

			while (var9.next()) {
				String var10 = var9.getString(1);
				int var11 = var9.getInt(2);
				String var12 = null;
				var12 = SchemaManager.singleton().getQualifiedTypeName(var5.getType());
				if (var12.equals("Entity")) {
					DBEntity var13 = this.findDBEntityByEntityId(var1);
					var12 = var13.getEntityType();
				}

				Property var31 = SchemaManager.singleton().getProperty(var12, var10);
				if (var4 != 5) {
					if (var11 == 1) {
						var5.getList(var31).add(DAOHelper.getRightTypeValue(var9, var4, 3));
					} else {
						var5.set(var31, DAOHelper.getRightTypeValue(var9, var4, 3));
					}
				} else {
					String[] var14 = DAOHelper.getRightReferenceTypeValue(var9, 3, 4, 5);
					EClass var15 = SchemaManager.singleton().getEClass("IdentifierType");
					DataObject var16 = (DataObject) EcoreUtil.create(var15);
					var16.setString("externalId", var14[1]);
					var16.setString("repositoryId", var14[2]);
					DBEntity var17 = this.findDBEntityByUniqueId(var14[1]);
					if (var17 != null) {
						var16.setString("uniqueName", var17.getUniqueName());
						var16.setString("uniqueId", var14[1]);
						var16.setString("externalName", var17.getUniqueName());
					}

					if (var11 == 1) {
						var5.getList(var31).add(var16);
					} else {
						var5.set(var31, var16);
					}
				}
			}
		} catch (SQLException var27) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var27.getMessage()),
					CLASSNAME,
					"readDBProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)", var27);
		} catch (IOException var28) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"readDBProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)", var28);
		} catch (ClassNotFoundException var29) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"readDBProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)", var29);
		} finally {
			try {
				if (var8 != null) {
					var8.close();
				}

				if (var9 != null) {
					var9.close();
				}

				if (var7 != null) {
					this.closeConnection(var7);
				}
			} catch (Exception var26) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"readDBProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)");
		}

	}

	public void readAllDBPropertiesForEntity(long var1, DataObject var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "readAllDBProperties(long entityId, DataObject entity)");
		}

		String var5 = SchemaManager.singleton().getQualifiedTypeName(var3.getType());
		Connection var6 = null;
		Object var7 = null;
		PreparedStatement var8 = null;
		Object var9 = null;
		ResultSet var10 = null;
		Object var11 = null;
		String var12 = this.qs.findAllPropertiesForEntity;
		String var13 = this.qs.findAllBlobPropertiesForEntity;

		try {
			var6 = this.getConnection();
			var8 = var6.prepareStatement(var12, 1003, 1007);
			trcLogger.logp(Level.FINER, CLASSNAME, "readAllDBProperties(long entityId, DataObject entity)",
					"read all DB properties sql is:  " + var12);
			var8.setLong(1, var1);
			var8.setLong(2, var1);
			var8.setLong(3, var1);
			var8.setLong(4, var1);
			var8.setLong(5, var1);
			var8.setLong(6, var1);
			var10 = var8.executeQuery();

			while (var10.next()) {
				int var14 = var10.getInt(1);
				String var15 = var10.getString(7);
				Property var16 = SchemaManager.singleton().getProperty(var5, var15);
				if (!this.isOperationalProperty(var15)) {
					int var17 = var10.getInt(8);
					short var18 = var10.getShort(2);
					if (var18 != 5) {
						try {
							if (var17 == 1) {
								var3.getList(var16).add(DAOHelper.getRightTypeValue(var10, var18, var14));
							} else {
								var3.set(var16, DAOHelper.getRightTypeValue(var10, var18, var14));
							}
						} catch (NullPointerException var32) {
							;
						}
					} else {
						String[] var19 = DAOHelper.getRightReferenceTypeValue(var10, 3, 4, 5);
						EClass var20 = SchemaManager.singleton().getEClass("IdentifierType");
						DataObject var21 = (DataObject) EcoreUtil.create(var20);
						var21.setString("externalId", var19[1]);
						var21.setString("repositoryId", var19[2]);
						if (var17 == 1) {
							var3.getList(var16).add(var21);
						} else {
							var3.set(var16, var21);
						}
					}
				}
			}

			var8 = var6.prepareStatement(var13, 1003, 1007);
			trcLogger.logp(Level.FINER, CLASSNAME, "readAllDBProperties(long entityId, DataObject entity)",
					"read all DB blob properties sql is:  " + var13);
			var8.setLong(1, var1);
			var10 = var8.executeQuery();

			while (var10.next()) {
				String var37 = var10.getString(2);
				Property var38 = SchemaManager.singleton().getProperty(var5, var37);
				int var39 = var10.getInt(3);
				if (var39 == 1) {
					var3.getList(var38).add(this.getBlobValue(var10, 4));
				} else {
					var3.set(var38, this.getBlobValue(var10, 4));
				}
			}
		} catch (SQLException var33) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var33.getMessage()),
					CLASSNAME, "readAllDBProperties(long entityId, DataObject entity)", var33);
		} catch (IOException var34) {
			throw new WIMSystemException("GENERIC", CLASSNAME, "readAllDBProperties(long entityId, DataObject entity)",
					var34);
		} catch (ClassNotFoundException var35) {
			throw new WIMSystemException("GENERIC", CLASSNAME, "readAllDBProperties(long entityId, DataObject entity)",
					var35);
		} finally {
			try {
				if (var8 != null) {
					var8.close();
				}

				if (var10 != null) {
					var10.close();
				}

				if (var6 != null) {
					this.closeConnection(var6);
				}

				if (var9 != null) {
					((PreparedStatement) var9).close();
				}

				if (var11 != null) {
					((ResultSet) var11).close();
				}

				if (var7 != null) {
					this.closeConnection((Connection) var7);
				}
			} catch (Exception var31) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "readAllDBProperties(long entityId, DataObject entity)");
		}

	}

	public void readAllLAPropertiesForEntity(long var1, DataObject var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "readAllLAProperties(long entityId, DataObject entity)");
		}

		String var5 = SchemaManager.singleton().getQualifiedTypeName(var3.getType());
		Connection var6 = null;
		Object var7 = null;
		PreparedStatement var8 = null;
		Object var9 = null;
		ResultSet var10 = null;
		Object var11 = null;
		String var12 = this.qs.findAllPropertiesForLAEntity;
		String var13 = this.qs.findAllBlobPropertiesForLAEntity;

		try {
			var6 = this.getConnection();
			var8 = var6.prepareStatement(var12, 1003, 1007);
			trcLogger.logp(Level.FINER, CLASSNAME, "readAllLAProperties(long entityId, DataObject entity)",
					"read all LA properties sql is:  " + var12);
			var8.setLong(1, var1);
			var8.setLong(2, var1);
			var8.setLong(3, var1);
			var8.setLong(4, var1);
			var8.setLong(5, var1);
			var8.setLong(6, var1);
			var10 = var8.executeQuery();

			while (var10.next()) {
				int var14 = var10.getInt(1);
				String var15 = var10.getString(7);
				Property var16 = SchemaManager.singleton().getProperty(var5, var15);
				if (!this.isOperationalProperty(var15)) {
					int var17 = var10.getInt(8);
					short var18 = var10.getShort(2);
					if (var18 != 5) {
						if (var17 == 1) {
							var3.getList(var16).add(DAOHelper.getRightTypeValue(var10, var18, var14));
						} else {
							var3.set(var16, DAOHelper.getRightTypeValue(var10, var18, var14));
						}
					} else {
						String[] var19 = DAOHelper.getRightReferenceTypeValue(var10, 3, 4, 5);
						EClass var20 = SchemaManager.singleton().getEClass("IdentifierType");
						DataObject var21 = (DataObject) EcoreUtil.create(var20);
						var21.setString("uniqueName", var19[0]);
						var21.setString("externalId", var19[1]);
						var21.setString("repositoryId", var19[2]);
						if (var17 == 1) {
							var3.getList(var16).add(var21);
						} else {
							var3.set(var16, var21);
						}
					}
				}
			}

			var8 = var6.prepareStatement(var13, 1003, 1007);
			trcLogger.logp(Level.FINER, CLASSNAME, "readAllLAProperties(long entityId, DataObject entity)",
					"read all LA blob properties sql is:  " + var13);
			var8.setLong(1, var1);
			var10 = var8.executeQuery();

			while (var10.next()) {
				String var35 = var10.getString(2);
				Property var36 = SchemaManager.singleton().getProperty(var5, var35);
				int var37 = var10.getInt(3);
				if (var37 == 1) {
					var3.getList(var36).add(this.getBlobValue(var10, 4));
				} else {
					var3.set(var36, this.getBlobValue(var10, 4));
				}
			}
		} catch (SQLException var31) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var31.getMessage()),
					CLASSNAME, "readAllLAProperties(long entityId, DataObject entity)", var31);
		} catch (IOException var32) {
			throw new WIMSystemException("GENERIC", CLASSNAME, "readAllLAProperties(long entityId, DataObject entity)",
					var32);
		} catch (ClassNotFoundException var33) {
			throw new WIMSystemException("GENERIC", CLASSNAME, "readAllLAProperties(long entityId, DataObject entity)",
					var33);
		} finally {
			try {
				if (var8 != null) {
					var8.close();
				}

				if (var10 != null) {
					var10.close();
				}

				if (var6 != null) {
					this.closeConnection(var6);
				}

				if (var9 != null) {
					((PreparedStatement) var9).close();
				}

				if (var11 != null) {
					((ResultSet) var11).close();
				}

				if (var7 != null) {
					this.closeConnection((Connection) var7);
				}
			} catch (Exception var30) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "readAllLAProperties(long entityId, DataObject entity)");
		}

	}

	private boolean isOperationalProperty(String var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isOperationalProperty(String propName)");
		}

		boolean var3 = false;
		if (var1.equals("createTimestamp")) {
			var3 = true;
		}

		if (var1.equals("modifyTimestamp")) {
			var3 = true;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "isOperationalProperty(String propName)",
					"Property " + var1 + " is an operational propery: " + var3);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isOperationalProperty(String propName)");
		}

		return var3;
	}

	public Object getBlobValue(ResultSet var1, int var2) throws SQLException, IOException, ClassNotFoundException {
		Blob var3 = var1.getBlob(var2);
		InputStream var4 = var3.getBinaryStream();
		ObjectInputStream var5 = new ObjectInputStream(var4);
		return var5.readObject();
	}

	public void readLAProperties(long var1, StringBuffer var3, short var4, DataObject var5) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"readLAProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)");
		}

		Connection var7 = null;
		PreparedStatement var8 = null;
		ResultSet var9 = null;

		try {
			var3.append(this.qs.orderByPropertyNameInGetProperties);
			var7 = this.getConnection();
			var8 = var7.prepareStatement(var3.toString(), 1003, 1007);
			var8.setLong(1, var1);
			var9 = var8.executeQuery();

			while (var9.next()) {
				String var10 = var9.getString(1);
				int var11 = var9.getInt(2);
				String var12 = SchemaManager.singleton().getQualifiedTypeName(var5.getType());
				Property var13 = SchemaManager.singleton().getProperty(var12, var10);
				if (var4 != 5) {
					if (var11 == 1) {
						var5.getList(var13).add(DAOHelper.getRightTypeValue(var9, var4, 3));
					} else {
						var5.set(var13, DAOHelper.getRightTypeValue(var9, var4, 3));
					}
				} else {
					String[] var14 = DAOHelper.getRightReferenceTypeValue(var9, 3, 4, 5);
					EClass var15 = SchemaManager.singleton().getEClass("IdentifierType");
					DataObject var16 = (DataObject) EcoreUtil.create(var15);
					var16.setString("uniqueName", var14[0]);
					var16.setString("externalId", var14[1]);
					var16.setString("repositoryId", var14[2]);
					if (var11 == 1) {
						var5.getList(var13).add(var16);
					} else {
						var5.set(var13, var16);
					}
				}
			}
		} catch (SQLException var26) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var26.getMessage()),
					CLASSNAME,
					"readLAProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)", var26);
		} catch (IOException var27) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"readLAProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)", var27);
		} catch (ClassNotFoundException var28) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"readLAProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)", var28);
		} finally {
			try {
				if (var8 != null) {
					var8.close();
				}

				if (var9 != null) {
					var9.close();
				}

				if (var7 != null) {
					this.closeConnection(var7);
				}
			} catch (Exception var25) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"readLAProperties(long entityId, StringBuffer buff, short datatypeId, DataObject entity)");
		}

	}

	public DBEntity findParent(long var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "DBEntity findParent(long entityId)");
		}

		DBEntity var4 = null;
		Connection var5 = null;
		PreparedStatement var6 = null;
		ResultSet var7 = null;

		try {
			String var8 = this.qs.findParentByEntityId;
			var5 = this.getConnection();
			var6 = var5.prepareStatement(var8);
			var6.setLong(1, var1);
			var7 = var6.executeQuery();

			while (var7.next()) {
				var4 = new DBEntity();
				var4.setEntityId(var7.getLong(1));
				var4.setUniqueId(var7.getString(2).trim());
				var4.setUniqueName(var7.getString(3));
				var4.setEntityType(var7.getString(4));
			}
		} catch (SQLException var16) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var16.getMessage()),
					CLASSNAME, "DBEntity findParent(long entityId)", var16);
		} finally {
			try {
				if (var6 != null) {
					var6.close();
				}

				if (var7 != null) {
					var7.close();
				}

				if (var5 != null) {
					this.closeConnection(var5);
				}
			} catch (Exception var15) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "DBEntity findParent(long entityId)");
		}

		return var4;
	}

	public String getSpecificDatatypePropertyForEntitiesQuery(short var1) {
		StringBuffer var2 = new StringBuffer(512);
		switch (var1) {
			case 0 :
				var2.append(this.qs.findStringPropertyForEntities);
				break;
			case 1 :
				var2.append(this.qs.findLongPropertyForEntities);
				break;
			case 2 :
				var2.append(this.qs.findDoublePropertyForEntities);
				break;
			case 3 :
				var2.append(this.qs.findIntegerPropertyForEntities);
				break;
			case 4 :
				var2.append(this.qs.findTimestampPropertyForEntities);
				break;
			case 5 :
				var2.append(this.qs.findReferencePropertyForEntities);
		}

		return var2.toString();
	}

	public void getDBEntityInformation(String var1, DataObject var2, String var3, String var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getDBEntityInformation(String query, DataObject entity, String DOPropName, String reposId)");
		}

		Connection var6 = null;
		PreparedStatement var7 = null;
		ResultSet var8 = null;

		try {
			var6 = this.getConnection();
			var7 = var6.prepareStatement(var1);
			var8 = var7.executeQuery();
			long var9 = -1L;
			long var11 = -1L;
			boolean var13 = true;

			for (DataObject var14 = null; var8.next(); var9 = var11) {
				int var32 = var8.getInt(1);
				var11 = var8.getLong(3);
				if (var11 != var9) {
					EClass var15 = SchemaManager.singleton().getEClass(var8.getString(6));
					var14 = (DataObject) EcoreUtil.create(var15);
					DataObject var16 = var14.createDataObject("identifier");
					String var17 = var8.getString(4);
					String var18 = var8.getString(5);
					var16.setString("uniqueName", var17);
					var16.setString("externalName", var17);
					var16.setString("uniqueId", var18);
					var16.setString("externalId", var18);
					var16.setString("repositoryId", var4);
					var2.getList(var3).add(var14);
				}

				String var33 = var8.getString(8);
				int var34 = var8.getInt(9);
				short var35 = var8.getShort(2);
				if (var32 != -100 && var35 != 5) {
					if (var34 == 1) {
						var14.getList(var33).add(DAOHelper.getRightTypeValue(var8, var35, var32));
					} else {
						var14.set(var33, DAOHelper.getRightTypeValue(var8, var35, var32));
					}
				}
			}
		} catch (SQLException var28) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var28.getMessage()),
					CLASSNAME,
					"getDBEntityInformation(String query, DataObject entity, String DOPropName, String reposId)",
					var28);
		} catch (IOException var29) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"getDBEntityInformation(String query, DataObject entity, String DOPropName, String reposId)",
					var29);
		} catch (ClassNotFoundException var30) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"getDBEntityInformation(String query, DataObject entity, String DOPropName, String reposId)",
					var30);
		} finally {
			try {
				if (var7 != null) {
					var7.close();
				}

				if (var8 != null) {
					var8.close();
				}

				if (var6 != null) {
					this.closeConnection(var6);
				}
			} catch (Exception var27) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"getDBEntityInformation(String query, DataObject entity, String DOPropName, String reposId)");
		}

	}

	public List getAllDescendantsByUniqueNameKey(String var1, List var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getAllDescendantsByUniqueNameKey(String uniqueNameKey)");
		}

		ArrayList var4 = null;
		Connection var5 = null;
		PreparedStatement var6 = null;
		ResultSet var7 = null;

		try {
			String var8 = this.qs.findAllDescendantsByUniqueNameKey;
			if (var2 != null && var2.size() != 0) {
				var8 = var8.concat(this.qs.entityTypesIn);

				for (int var9 = 0; var9 < var2.size(); ++var9) {
					var8 = var8.concat(this.qs.SINGLE_QUOTE);
					var8 = var8.concat((String) var2.get(var9));
					var8 = var8.concat(this.qs.SINGLE_QUOTE);
					if (var9 != var2.size() - 1) {
						var8 = var8.concat(this.qs.COMMA_AND_SPACE);
					}
				}

				var8 = var8.concat(this.qs.RIGHT_BRACKET);
			}

			var5 = this.getConnection();
			var6 = var5.prepareStatement(var8);
			var6.setString(1, "%," + var1);

			for (var7 = var6.executeQuery(); var7.next(); var4.add(new Long(var7.getLong(1)))) {
				if (var4 == null) {
					var4 = new ArrayList();
				}
			}
		} catch (SQLException var17) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var17.getMessage()),
					CLASSNAME, "getAllDescendantsByUniqueNameKey(String uniqueNameKey)", var17);
		} finally {
			try {
				if (var6 != null) {
					var6.close();
				}

				if (var7 != null) {
					var7.close();
				}

				if (var5 != null) {
					this.closeConnection(var5);
				}
			} catch (Exception var16) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getAllDescendantsByUniqueNameKey(String uniqueNameKey)");
		}

		return var4;
	}

	public List getChildrenByUniqueNameKey(String var1, List var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getChildrenByUniqueNameKey(String uniqueNameKey)");
		}

		ArrayList var4 = null;
		Connection var5 = null;
		PreparedStatement var6 = null;
		ResultSet var7 = null;

		try {
			String var8 = this.qs.findChildrenByUniqueNameKey;
			if (var2 != null && var2.size() != 0) {
				var8 = var8.concat(this.qs.childrenEntityTypesIn);

				for (int var9 = 0; var9 < var2.size(); ++var9) {
					var8 = var8.concat(this.qs.SINGLE_QUOTE);
					var8 = var8.concat((String) var2.get(var9));
					var8 = var8.concat(this.qs.SINGLE_QUOTE);
					if (var9 != var2.size() - 1) {
						var8 = var8.concat(this.qs.COMMA_AND_SPACE);
					}
				}

				var8 = var8.concat(this.qs.RIGHT_BRACKET);
			}

			var5 = this.getConnection();
			var6 = var5.prepareStatement(var8);
			var6.setString(1, var1);

			for (var7 = var6.executeQuery(); var7.next(); var4.add(new Long(var7.getLong(1)))) {
				if (var4 == null) {
					var4 = new ArrayList();
				}
			}
		} catch (SQLException var17) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var17.getMessage()),
					CLASSNAME, "getChildrenByUniqueNameKey(String uniqueNameKey)", var17);
		} finally {
			try {
				if (var6 != null) {
					var6.close();
				}

				if (var7 != null) {
					var7.close();
				}

				if (var5 != null) {
					this.closeConnection(var5);
				}
			} catch (Exception var16) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getChildrenByUniqueNameKey(String uniqueNameKey)");
		}

		return var4;
	}

	public List getChildrenByEntityIdList(List var1, List var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getChildrenByEntityIdList");
		}

		ArrayList var4 = null;
		Connection var5 = null;
		PreparedStatement var6 = null;
		ResultSet var7 = null;

		try {
			String var8 = this.qs.findChildrenByAncestorIdIn;
			int var9;
			if (var1 != null && var1.size() != 0) {
				for (var9 = 0; var9 < var1.size(); ++var9) {
					var8 = var8.concat(var1.get(var9).toString());
					if (var9 != var1.size() - 1) {
						var8 = var8.concat(this.qs.COMMA_AND_SPACE);
					}
				}

				var8 = var8.concat(this.qs.RIGHT_BRACKET);
			}

			if (var2 != null && var2.size() != 0) {
				var8 = var8.concat(this.qs.childrenEntityTypesIn);

				for (var9 = 0; var9 < var2.size(); ++var9) {
					var8 = var8.concat(this.qs.SINGLE_QUOTE);
					var8 = var8.concat((String) var2.get(var9));
					var8 = var8.concat(this.qs.SINGLE_QUOTE);
					if (var9 != var2.size() - 1) {
						var8 = var8.concat(this.qs.COMMA_AND_SPACE);
					}
				}

				var8 = var8.concat(this.qs.RIGHT_BRACKET);
			}

			var5 = this.getConnection();
			var6 = var5.prepareStatement(var8);

			for (var7 = var6.executeQuery(); var7.next(); var4.add(new Long(var7.getLong(1)))) {
				if (var4 == null) {
					var4 = new ArrayList();
				}
			}
		} catch (SQLException var17) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var17.getMessage()),
					CLASSNAME, "getChildrenByEntityIdList", var17);
		} finally {
			try {
				if (var6 != null) {
					var6.close();
				}

				if (var7 != null) {
					var7.close();
				}

				if (var5 != null) {
					this.closeConnection(var5);
				}
			} catch (Exception var16) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getChildrenByEntityIdList");
		}

		return var4;
	}

	public List getImmediateGroupsForEntity(String var1, String var2, List var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getImmediateGroupsForEntity(long entityId, String extReposId)");
		}

		ArrayList var5 = null;
		Connection var6 = null;
		PreparedStatement var7 = null;
		ResultSet var8 = null;

		try {
			String var9 = null;
			if (var3 != null && var3.size() != 0) {
				var9 = this.qs.findImmediateGroupIdsByExtIdAndReposIdUnderSearchBases;
				ArrayList var10 = new ArrayList();

				int var11;
				String var12;
				for (var11 = 0; var11 < var3.size(); ++var11) {
					var12 = (String) var3.get(var11);
					DBEntity var13 = this.findDBEntityByUniqueNameKey(DAOHelper.getTruncatedUniqueName(var12));
					if (var13 != null) {
						var10.add(var13.getUniqueName());
						if (var11 > 0) {
							var9 = var9 + this.qs.OR;
						}

						var9 = var9 + this.qs.uniqueNameEndWith;
					}
				}

				var9 = var9 + this.qs.RIGHT_BRACKET;
				var6 = this.getConnection();
				var7 = var6.prepareStatement(var9);
				var7.setString(1, DAOHelper.getTruncatedExternalId(var1));
				var7.setString(2, var2);

				for (var11 = 0; var11 < var10.size(); ++var11) {
					var12 = (String) var10.get(var11);
					var7.setString(var11 + 3, "%" + var12.toLowerCase());
				}
			} else {
				var9 = this.qs.findImmediateGroupIdsByExtIdAndReposId;
				var6 = this.getConnection();
				var7 = var6.prepareStatement(var9);
				var7.setString(1, DAOHelper.getTruncatedExternalId(var1));
				var7.setString(2, var2);
			}

			for (var8 = var7.executeQuery(); var8.next(); var5.add(new Long(var8.getLong(1)))) {
				if (var5 == null) {
					var5 = new ArrayList();
				}
			}
		} catch (SQLException var21) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var21.getMessage()),
					CLASSNAME, "getImmediateGroupsForEntity(long entityId, String extReposId)", var21);
		} finally {
			try {
				if (var7 != null) {
					var7.close();
				}

				if (var8 != null) {
					var8.close();
				}

				if (var6 != null) {
					this.closeConnection(var6);
				}
			} catch (Exception var20) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getImmediateGroupsForEntity(long entityId, String extReposId)");
		}

		return var5;
	}

	public List getNestedGroupsForEntity(String var1, String var2, String var3, List var4, List var5)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getNestedGroupsForEntity(String entityId, String extReposId, String currentReposId)");
		}

		ArrayList var7 = new ArrayList();
		Connection var8 = null;
		PreparedStatement var9 = null;
		ResultSet var10 = null;
		HashMap var11 = new HashMap();

		try {
			String var12 = null;
			var12 = this.qs.findNestedGroupIdsByExtIdAndReposId;
			var8 = this.getConnection();
			var9 = var8.prepareStatement(var12);
			var9.setString(1, DAOHelper.getTruncatedExternalId(var1));
			var9.setString(2, var2);

			Long var13;
			String var14;
			for (var10 = var9.executeQuery(); var10.next(); var11.put(var14, var13)) {
				var13 = new Long(var10.getLong(1));
				var14 = var10.getString(2);
				if (var5 != null && var5.size() != 0) {
					if (this.isEntityUnderSearchBases(var13, var5)) {
						var7.add(var13);
					}
				} else {
					var7.add(var13);
				}
			}
		} catch (SQLException var22) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var22.getMessage()),
					CLASSNAME, "getNestedGroupsForEntity(String entityId, String extReposId, String currentReposId)",
					var22);
		} finally {
			try {
				if (var9 != null) {
					var9.close();
				}

				if (var10 != null) {
					var10.close();
				}

				if (var8 != null) {
					this.closeConnection(var8);
				}
			} catch (Exception var21) {
				;
			}

		}

		ArrayList var24 = new ArrayList();
		if (var11.size() != 0) {
			Set var25 = var11.keySet();
			Iterator var26 = var25.iterator();

			while (var26.hasNext()) {
				String var15 = (String) var26.next();
				Long var16 = (Long) var11.get(var15);
				if (var4 != null && !var4.contains(var16) && !var24.contains(var16)) {
					var4.add(var16);
					var24.addAll(this.getNestedGroupsForEntity(var15, var3, var3, var4, var5));
				}
			}
		}

		var7.addAll(var24);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"getNestedGroupsForEntity(String entityId, String extReposId, String currentReposId)");
		}

		return var7;
	}

	private boolean isEntityUnderSearchBases(long var1, List var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isEntityUnderSearchBases");
		}

		DBEntity var5 = this.findDBEntityByEntityId(var1);
		String var6 = var5.getUniqueName();

		for (int var7 = 0; var7 < var3.size(); ++var7) {
			if (var6.toLowerCase().endsWith(var3.get(var7).toString().toLowerCase())) {
				return true;
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isEntityUnderSearchBases");
		}

		return false;
	}

	public Set[] getImmediateGroupMembers(long var1, List var3, List var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getImmediateGroupMembers(long grpEntId, String returnEntType, List searchBases)");
		}

		Set[] var6 = new Set[]{new HashSet(), new HashSet()};
		String var7 = null;
		if (var3 != null && var3.size() != 0) {
			var7 = this.qs.findImmediateGroupMemberIdsByGroupEntIdForEntityType;

			for (int var8 = 0; var8 < var3.size(); ++var8) {
				var7 = var7.concat(this.qs.SINGLE_QUOTE);
				var7 = var7.concat((String) var3.get(var8));
				var7 = var7.concat(this.qs.SINGLE_QUOTE);
				if (var8 != var3.size() - 1) {
					var7 = var7.concat(this.qs.COMMA_AND_SPACE);
				} else {
					var7 = var7.concat(this.qs.RIGHT_BRACKET);
				}
			}

			var7 = var7.concat(this.qs.findImmediateGroupMemberIdsByGroupEntIdForEntityTypeWhere);
		} else {
			var7 = this.qs.findImmediateGroupMemberIdsByGroupEntId;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.log(Level.FINER, "SQL to execute: " + var7);
		}

		Connection var24 = null;
		PreparedStatement var9 = null;
		ResultSet var10 = null;

		try {
			var24 = this.getConnection();
			var9 = var24.prepareStatement(var7);
			var9.setLong(1, var1);
			var10 = var9.executeQuery();

			label181 : while (true) {
				while (true) {
					while (true) {
						if (!var10.next()) {
							break label181;
						}

						DBExtIdReposId var11 = new DBExtIdReposId();
						var11.setExtId(var10.getString(1));
						var11.setReposId(var10.getString(2));
						DBEntityIdEntityType var12 = new DBEntityIdEntityType();
						long var13 = var10.getLong(3);
						if (var13 != 0L) {
							var12.setEntId(new Long(var13));
							var12.setEntType(var10.getString(4));
							if (var4 != null && var4.size() != 0) {
								if (this.isEntityUnderSearchBases(var13, var4)) {
									var6[0].add(var12);
								}
							} else {
								var6[0].add(var12);
							}
						} else {
							var6[1].add(var11);
						}
					}
				}
			}
		} catch (SQLException var22) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var22.getMessage()),
					CLASSNAME, "getImmediateGroupMembers(long grpEntId, String returnEntType, List searchBases)",
					var22);
		} finally {
			try {
				if (var9 != null) {
					var9.close();
				}

				if (var10 != null) {
					var10.close();
				}

				if (var24 != null) {
					this.closeConnection(var24);
				}
			} catch (Exception var21) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"getImmediateGroupMembers(long grpEntId, String returnEntType, List searchBases)");
		}

		return var6;
	}

	public Set[] getNestedGroupMembers(long var1, List var3, List var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getImmediateGroupMembers(long grpEntId, String returnEntType, List searchBases)");
		}

		Set[] var6 = new Set[]{new HashSet(), new HashSet()};
		this.getNestedGroupMembers(var1, var3, var4, new ArrayList(), var6);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"getImmediateGroupMembers(long grpEntId, String returnEntType, List searchBases)");
		}

		return var6;
	}

	private void getNestedGroupMembers(long var1, List var3, List var4, List var5, Set[] var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getImmediateGroupMembers(long grpEntId, List returnEntTypes, List checkedGroups, Set[] result)");
		}

		Set[] var8 = this.getImmediateGroupMembers(var1, (List) null, (List) null);
		if (var8[1] != null && var8[1].size() != 0) {
			var6[1].addAll(var8[1]);
		}

		if (var8[0] != null && var8[0].size() != 0) {
			Iterator var9 = var8[0].iterator();

			while (var9.hasNext()) {
				DBEntityIdEntityType var10 = (DBEntityIdEntityType) var9.next();
				String var11 = var10.getEntType();
				long var12 = var10.getEntId();
				if (var3 != null) {
					if (var3.contains(var11)) {
						if (var4 != null && var4.size() != 0) {
							if (this.isEntityUnderSearchBases(var12, var4)) {
								var6[0].add(var10);
							}
						} else {
							var6[0].add(var10);
						}
					} else if (this.schemaMgr.isSuperType("LoginAccount", var11) && var3.contains("LoginAccount")
							|| this.schemaMgr.isSuperType("PersonAccount", var11) && var3.contains("PersonAccount")
							|| this.schemaMgr.isSuperType("Group", var11) && var3.contains("Group")) {
						var6[0].add(var10);
					}
				} else if (var4 != null && var4.size() != 0) {
					if (this.isEntityUnderSearchBases(var12, var4)) {
						var6[0].add(var10);
					}
				} else {
					var6[0].add(var10);
				}

				if (var11.equals("Group")) {
					Long var14 = var10.getEntId();
					if (!var5.contains(var14)) {
						var5.add(var14);
						this.getNestedGroupMembers(var14, var3, var4, var5, var6);
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"getImmediateGroupMembers(long grpEntId, List returnEntTypes, List checkedGroups, Set[] result)");
		}

	}

	public String renameEntity(long var1, String var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "renameEntity(long entId, String newRdnValue)");
		}

		String var5 = null;
		String var6 = null;
		Connection var7 = null;
		PreparedStatement var8 = null;
		ResultSet var9 = null;

		String var10;
		try {
			var10 = this.qs.findLeafEntityUniqueName;
			var7 = this.getConnection();
			var8 = var7.prepareStatement(var10);
			var8.setLong(1, var1);

			for (var9 = var8.executeQuery(); var9.next(); var5 = var9.getString(1)) {
				;
			}
		} catch (SQLException var57) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var57.getMessage()),
					CLASSNAME, "renameEntity(long entId, String newRdnValue)", var57);
		} finally {
			try {
				if (var8 != null) {
					var8.close();
				}

				if (var9 != null) {
					var9.close();
				}

				if (var7 != null) {
					this.closeConnection(var7);
				}
			} catch (Exception var52) {
				;
			}

		}

		if (var5 != null) {
			Object[] var60 = new Object[]{var5};
			throw new EntityHasDescendantsException("ENTITY_HAS_DESCENDENTS", CLASSNAME,
					"renameEntity(long entId, String newRdnValue)");
		} else {
			try {
				var10 = this.qs.findDBEntityByEntityId;
				var7 = this.getConnection();
				var8 = var7.prepareStatement(var10);
				var8.setLong(1, var1);

				for (var9 = var8.executeQuery(); var9.next(); var5 = var9.getString(4)) {
					;
				}
			} catch (SQLException var55) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var55.getMessage()),
						CLASSNAME, "renameEntity(long entId, String newRdnValue)", var55);
			} finally {
				try {
					if (var8 != null) {
						var8.close();
					}

					if (var9 != null) {
						var9.close();
					}

					if (var7 != null) {
						this.closeConnection(var7);
					}
				} catch (Exception var51) {
					;
				}

			}

			int var59 = var5.indexOf(61);
			int var11 = var5.indexOf(44);
			String var12 = null;
			String var13 = null;
			if (var59 != -1) {
				var12 = var5.substring(0, var59 + 1);
				if (var11 != -1) {
					var13 = var5.substring(var11);
				}
			}

			if (var12 != null) {
				var6 = var12 + var3;
			}

			if (var13 != null) {
				var6 = var6 + var13;
			}

			try {
				String var14 = this.qs.updateEntityUniqueName;
				var7 = this.getConnection();
				var8 = var7.prepareStatement(var14);
				var8.setString(1, var6);
				var8.setString(2, DAOHelper.getTruncatedUniqueName(var6));
				var8.setLong(3, var1);
				var8.executeUpdate();
			} catch (SQLException var53) {
				if (var53.getClass().getName().equals(FactoryManager.getDuplicateKeyExceptionName())) {
					throw new EntityAlreadyExistsException("ENTITY_ALREADY_EXIST",
							WIMMessageHelper.generateMsgParms(var6), CLASSNAME,
							"renameEntity(long entId, String newRdnValue)");
				}

				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var53.getMessage()),
						CLASSNAME, "renameEntity(long entId, String newRdnValue)", var53);
			} finally {
				try {
					if (var8 != null) {
						var8.close();
					}

					if (var9 != null) {
						var9.close();
					}

					if (var7 != null) {
						this.closeConnection(var7);
					}
				} catch (Exception var50) {
					;
				}

			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "renameEntity(long entId, String newRdnValue)");
			}

			return var6;
		}
	}

	public void updateAccount(long var1, byte[] var3, String var4, String var5, String var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"updateAccount(Long entId, String loginId, String pwd, String pExtId, String reposId)");
		}

		Connection var8 = null;
		PreparedStatement var9 = null;

		try {
			String var10 = null;
			var8 = this.getConnection();
			var10 = this.qs.updateDBAcct;
			var9 = var8.prepareStatement(var10);
			if (var3 != null) {
				var9.setBytes(1, var3);
				var9.setString(2, var4);
			} else {
				var9.setNull(1, -3);
				var9.setNull(2, 12);
			}

			if (var5 != null) {
				var9.setString(3, DAOHelper.getTruncatedExternalId(var5));
				var9.setString(4, var5);
				var9.setString(5, var6);
			} else {
				var9.setNull(3, 12);
				var9.setNull(4, 12);
				var9.setNull(5, 12);
			}

			var9.setLong(6, var1);
			var9.executeUpdate();
		} catch (SQLException var18) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var18.getMessage()),
					CLASSNAME, "updateAccount(Long entId, String loginId, String pwd, String pExtId, String reposId)",
					var18);
		} finally {
			try {
				if (var9 != null) {
					var9.close();
				}

				if (var8 != null) {
					this.closeConnection(var8);
				}
			} catch (Exception var17) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"updateAccount(Long entId, String loginId, String pwd, String pExtId, String reposId)");
		}

	}

	public void updateProperties(short var1, long var2, Hashtable[] var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateProperties(long entId, Hashtable[] propertyToUpdate)");
		}

		Connection var6 = null;
		Connection var7 = null;
		Connection var8 = null;
		PreparedStatement var9 = null;
		PreparedStatement var10 = null;
		PreparedStatement var11 = null;

		for (short var12 = 0; var12 < var4.length; ++var12) {
			try {
				if (var4[var12] != null && var4[var12].size() != 0) {
					String var13 = null;
					String var14 = null;
					String var15 = null;
					Enumeration var16 = var4[var12].keys();

					label565 : while (true) {
						while (true) {
							if (!var16.hasMoreElements()) {
								break label565;
							}

							Integer var17 = (Integer) var16.nextElement();
							PropertyToUpdate var18 = (PropertyToUpdate) var4[var12].get(var17);
							Object var19 = var18.getOldValue();
							Object var20 = var18.getNewValue();
							DataObject var21;
							if (var19 != null) {
								if (var13 == null) {
									if (var12 != 6) {
										var13 = this.getUpdateStmtForPropertyValueWithOldValue(var1, var12);
									} else {
										if (var1 == 0) {
											var13 = this.qs.deletePropertiesFromDBBlobProp;
										} else {
											var13 = this.qs.deletePropertiesFromLABlobProp;
										}

										var13 = var13 + this.qs.PARAM_MARKER + this.qs.RIGHT_BRACKET + this.qs.AND
												+ this.qs.entityIDEquals;
										if (trcLogger.isLoggable(Level.FINE)) {
											trcLogger.logp(Level.FINE, CLASSNAME,
													"updateProperties(long entId, Hashtable[] propertyToUpdate)",
													"update sql is " + var13);
										}

										if (var15 == null) {
											if (var1 == 0) {
												var15 = this.qs.createDBBlobValueWithoutKey;
											} else {
												var15 = this.qs.createLABlobValueWithoutKey;
											}
										}

										if (var8 == null || var8.isClosed()) {
											var8 = this.getConnection();
										}

										var11 = var8.prepareStatement(var15);
									}

									if (var6 == null || var6.isClosed()) {
										var6 = this.getConnection();
									}

									var9 = var6.prepareStatement(var13);
								}

								try {
									switch (var12) {
										case 0 :
											var9.setString(1, (String) var20);
											var9.setString(2, ((String) var20).toLowerCase());
											var9.setInt(3, var17);
											var9.setLong(4, var2);
											var9.setString(5, ((String) var19).toLowerCase());
											break;
										case 1 :
											long var23 = 0L;

											try {
												var23 = (Long) var20;
											} catch (ClassCastException var73) {
												var23 = Long.parseLong((String) var20);
											}

											var9.setLong(1, var23);
											var9.setInt(2, var17);
											var9.setLong(3, var2);
											long var25 = 0L;

											try {
												var25 = (Long) var19;
											} catch (ClassCastException var72) {
												var25 = Long.parseLong((String) var19);
											}

											var9.setLong(4, var25);
											break;
										case 2 :
											double var79 = 0.0D;

											try {
												var79 = (Double) var20;
											} catch (ClassCastException var71) {
												var79 = Double.parseDouble((String) var20);
											}

											var9.setDouble(1, var79);
											var9.setInt(2, var17);
											var9.setLong(3, var2);
											double var80 = 0.0D;

											try {
												var80 = (Double) var19;
											} catch (ClassCastException var70) {
												var80 = Double.parseDouble((String) var19);
											}

											var9.setDouble(4, var80);
											break;
										case 3 :
											boolean var31 = false;

											int var81;
											try {
												var81 = (Integer) var20;
											} catch (ClassCastException var69) {
												var81 = Integer.parseInt((String) var20);
											}

											var9.setInt(1, var81);
											var9.setInt(2, var17);
											var9.setLong(3, var2);
											boolean var32 = false;

											int var82;
											try {
												var82 = (Integer) var19;
											} catch (ClassCastException var68) {
												var82 = Integer.parseInt((String) var19);
											}

											var9.setInt(4, var82);
											break;
										case 4 :
											Timestamp var33;
											try {
												var33 = (Timestamp) var20;
											} catch (ClassCastException var67) {
												var33 = Timestamp.valueOf((String) var20);
											}

											var9.setTimestamp(1, var33);
											var9.setInt(2, var17);
											var9.setLong(3, var2);

											Timestamp var34;
											try {
												var34 = (Timestamp) var19;
											} catch (ClassCastException var66) {
												var34 = Timestamp.valueOf((String) var19);
											}

											var9.setTimestamp(4, var34);
											break;
										case 5 :
											var21 = (DataObject) var20;
											var9.setString(1,
													DAOHelper.getTruncatedUniqueName(var21.getString("uniqueName")));
											var9.setString(2, var21.getString("uniqueName"));
											var9.setString(3,
													DAOHelper.getTruncatedExternalId(var21.getString("externalId")));
											var9.setString(4, var21.getString("externalId"));
											var9.setString(5, var21.getString("repositoryId"));
											var9.setInt(6, var17);
											var9.setLong(7, var2);
											DataObject var77 = (DataObject) var19;
											var9.setString(8,
													DAOHelper.getTruncatedExternalId(var77.getString("externalId")));
											var9.setString(9, var77.getString("repositoryId"));
											break;
										case 6 :
											var9.setInt(1, var17);
											var9.setLong(2, var2);
											var11.setInt(1, var17);
											var11.setString(2, DAOHelper.getDataType(var12));
											var11.setLong(3, var2);
											var11.setNull(4, -5);
											var11.setString(5, "");
											ByteArrayOutputStream var35 = new ByteArrayOutputStream();
											ObjectOutputStream var36 = new ObjectOutputStream(var35);
											var36.writeObject(var20);
											var36.close();
											var11.setBytes(6, var35.toByteArray());
									}

									var9.addBatch();
								} catch (Exception var74) {
									throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
											WIMMessageHelper.generateMsgParms(var17), CLASSNAME,
											"updateProperties(long entId, Hashtable[] propertyToUpdate)", var74);
								}
							} else {
								if (var14 == null) {
									if (var12 != 6) {
										var14 = this.getUpdateStmtForPropertyValue(var1, var12);
									} else {
										if (var1 == 0) {
											var14 = this.qs.deletePropertiesFromDBBlobProp;
										} else {
											var14 = this.qs.deletePropertiesFromLABlobProp;
										}

										var14 = var14 + this.qs.PARAM_MARKER + this.qs.RIGHT_BRACKET + this.qs.AND
												+ this.qs.entityIDEquals;
										if (trcLogger.isLoggable(Level.FINE)) {
											trcLogger.logp(Level.FINE, CLASSNAME,
													"updateProperties(long entId, Hashtable[] propertyToUpdate)",
													"update sql is " + var14);
										}

										if (var15 == null) {
											if (var1 == 0) {
												var15 = this.qs.createDBBlobValueWithoutKey;
											} else {
												var15 = this.qs.createLABlobValueWithoutKey;
											}
										}

										if (var8 == null || var8.isClosed()) {
											var8 = this.getConnection();
										}

										if (trcLogger.isLoggable(Level.FINE)) {
											trcLogger.logp(Level.FINE, CLASSNAME,
													"updateProperties(long entId, Hashtable[] propertyToUpdate)",
													"insert sql for Object type  is " + var15);
										}

										var11 = var8.prepareStatement(var15);
									}

									if (var7 == null || var7.isClosed()) {
										var7 = this.getConnection();
									}

									var10 = var7.prepareStatement(var14);
								}

								try {
									switch (var12) {
										case 0 :
											var10.setString(1, (String) var20);
											var10.setString(2, ((String) var20).toLowerCase());
											var10.setInt(3, var17);
											var10.setLong(4, var2);
											break;
										case 1 :
											long var22 = 0L;

											try {
												var22 = (Long) var20;
											} catch (ClassCastException var64) {
												var22 = Long.parseLong((String) var20);
											}

											var10.setLong(1, var22);
											var10.setInt(2, var17);
											var10.setLong(3, var2);
											break;
										case 2 :
											double var24 = 0.0D;

											try {
												var24 = (Double) var20;
											} catch (ClassCastException var63) {
												var24 = Double.parseDouble((String) var20);
											}

											var10.setDouble(1, var24);
											var10.setInt(2, var17);
											var10.setLong(3, var2);
											break;
										case 3 :
											boolean var26 = false;

											int var78;
											try {
												var78 = (Integer) var20;
											} catch (ClassCastException var62) {
												var78 = Integer.parseInt((String) var20);
											}

											var10.setInt(1, var78);
											var10.setInt(2, var17);
											var10.setLong(3, var2);
											break;
										case 4 :
											Timestamp var27;
											try {
												var27 = (Timestamp) var20;
											} catch (ClassCastException var61) {
												var27 = Timestamp.valueOf((String) var20);
											}

											var10.setTimestamp(1, var27);
											var10.setInt(2, var17);
											var10.setLong(3, var2);
											break;
										case 5 :
											var21 = (DataObject) var20;
											var9.setString(1,
													DAOHelper.getTruncatedUniqueName(var21.getString("uniqueName")));
											var9.setString(2, var21.getString("uniqueName"));
											var9.setString(3,
													DAOHelper.getTruncatedExternalId(var21.getString("externalId")));
											var9.setString(4, var21.getString("externalId"));
											var9.setString(5, var21.getString("repositoryId"));
											var9.setInt(6, var17);
											var9.setLong(7, var2);
											break;
										case 6 :
											var10.setInt(1, var17);
											var10.setLong(2, var2);
											var11.setInt(1, var17);
											var11.setString(2, DAOHelper.getDataType(var12));
											var11.setLong(3, var2);
											var11.setNull(4, -5);
											var11.setString(5, "");
											ByteArrayOutputStream var28 = new ByteArrayOutputStream();
											ObjectOutputStream var29 = new ObjectOutputStream(var28);
											var29.writeObject(var20);
											var29.close();
											var11.setBytes(6, var28.toByteArray());
									}

									var10.addBatch();
									if (var11 != null) {
										var11.addBatch();
									}
								} catch (Exception var65) {
									throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
											WIMMessageHelper.generateMsgParms(var17), CLASSNAME,
											"updateProperties(long entId, Hashtable[] propertyToUpdate)", var65);
								}
							}
						}
					}
				}

				if (var9 != null) {
					var9.executeBatch();
					this.closeConnection(var6);
					var6 = null;
					var9.close();
					var9 = null;
				}

				if (var10 != null) {
					var10.executeBatch();
					this.closeConnection(var7);
					var7 = null;
					var10.close();
					var10 = null;
				}

				if (var11 != null) {
					var11.executeBatch();
					this.closeConnection(var8);
					var8 = null;
					var11.close();
					var11 = null;
				}
			} catch (SQLException var75) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var75.getMessage()),
						CLASSNAME, "updateProperties(long entId, Hashtable[] propertyToUpdate)", var75);
			} finally {
				try {
					this.closeConnection(var6);
					this.closeConnection(var7);
					this.closeConnection(var8);
				} catch (Exception var60) {
					;
				}

				try {
					var9.close();
					var10.close();
					var11.close();
				} catch (Exception var59) {
					;
				}

			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updateProperties(long entId, Hashtable[] propertyToUpdate)");
		}

	}

	public void replaceProperties(short var1, long var2, Hashtable[] var4, Set var5, String var6, boolean var7)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"replaceProperties(short schema, long entId, Hashtable[] propertyToReplace, Set multiValProps, String reposId)");
		}

		Connection var9 = null;
		PreparedStatement var10 = null;

		try {
			short var11 = 0;

			while (true) {
				if (var11 >= var4.length) {
					if (!var7) {
						this.createProperties(var1, var2, var4, (Long) null, var5, var6);
					} else {
						this.createProperties1(var1, var2, var4, (Long) null, var5, var6);
					}
					break;
				}

				if (var4[var11] != null && var4[var11].size() != 0) {
					String var12 = null;
					switch (var11) {
						case 0 :
							if (var1 == 0) {
								var12 = this.qs.deletePropertiesFromDBStringProp;
							} else {
								var12 = this.qs.deletePropertiesFromLAStringProp;
							}
							break;
						case 1 :
							if (var1 == 0) {
								var12 = this.qs.deletePropertiesFromDBLongProp;
							} else {
								var12 = this.qs.deletePropertiesFromLALongProp;
							}
							break;
						case 2 :
							if (var1 == 0) {
								var12 = this.qs.deletePropertiesFromDBDoubleProp;
							} else {
								var12 = this.qs.deletePropertiesFromLADoubleProp;
							}
							break;
						case 3 :
							if (var1 == 0) {
								var12 = this.qs.deletePropertiesFromDBIntegerProp;
							} else {
								var12 = this.qs.deletePropertiesFromLAIntegerProp;
							}
							break;
						case 4 :
							if (var1 == 0) {
								var12 = this.qs.deletePropertiesFromDBTimestampProp;
							} else {
								var12 = this.qs.deletePropertiesFromLATimestampProp;
							}
							break;
						case 5 :
							if (var1 == 0) {
								var12 = this.qs.deletePropertiesFromDBReferenceProp;
							} else {
								var12 = this.qs.deletePropertiesFromLAReferenceProp;
							}
							break;
						case 6 :
							if (var1 == 0) {
								var12 = this.qs.deletePropertiesFromDBBlobProp;
							} else {
								var12 = this.qs.deletePropertiesFromLABlobProp;
							}
					}

					for (short var13 = 0; var13 < var4[var11].size(); ++var13) {
						var12 = var12 + this.qs.PARAM_MARKER;
						if (var13 != var4[var11].size() - 1) {
							var12 = var12 + this.qs.COMMA;
						}
					}

					var12 = var12 + this.qs.RIGHT_BRACKET;
					var12 = var12 + this.qs.AND + this.qs.entityIDEquals;
					if (var9 == null) {
						var9 = this.getConnection();
					}

					int var28 = 1;
					var10 = var9.prepareStatement(var12);
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME,
								"replaceProperties(short schema, long entId, Hashtable[] propertyToReplace, Set multiValProps, String reposId)",
								"The delete sql is " + var12);
					}

					Enumeration var14 = var4[var11].keys();

					while (var14.hasMoreElements()) {
						Integer var15 = (Integer) var14.nextElement();
						var10.setInt(var28++, var15);
					}

					var10.setLong(var28++, var2);
					var10.executeUpdate();
				}

				++var11;
			}
		} catch (SQLException var26) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var26.getMessage()),
					CLASSNAME,
					"replaceProperties(short schema, long entId, Hashtable[] propertyToReplace, Set multiValProps, String reposId)",
					var26);
		} finally {
			try {
				this.closeConnection(var9);
			} catch (Exception var25) {
				;
			}

			try {
				var10.close();
			} catch (Exception var24) {
				;
			}

			var9 = null;
			var10 = null;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"replaceProperties(short schema, long entId, Hashtable[] propertyToReplace, Set multiValProps, String reposId)");
		}

	}

	public void assignMemberToGroups(DBExtIdReposId var1, List var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "assignMemberToGroups(DBExtIdReposId extReposId, List groupEntIds)");
		}

		Connection var4 = null;
		PreparedStatement var5 = null;
		String var6 = this.qs.createDBGrpRelation;

		try {
			var4 = this.getConnection();
			var5 = var4.prepareStatement(var6);
			int var7 = 0;

			while (true) {
				if (var7 >= var2.size()) {
					int[] var20 = var5.executeBatch();
					break;
				}

				var5.setLong(1, (Long) var2.get(var7));
				var5.setString(2, var1.getReposId());
				var5.setString(3, DAOHelper.getTruncatedExternalId(var1.getExtId()));
				var5.setString(4, var1.getExtId());
				var5.addBatch();
				++var7;
			}
		} catch (SQLException var18) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var18.getMessage()),
					CLASSNAME, "assignMemberToGroups(DBExtIdReposId extReposId, List groupEntIds)", var18);
		} finally {
			try {
				this.closeConnection(var4);
			} catch (Exception var17) {
				;
			}

			try {
				var5.close();
			} catch (Exception var16) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "assignMemberToGroups(DBExtIdReposId extReposId, List groupEntIds)");
		}

	}

	public void assignMembersToGroup(List var1, long var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "assignMembersToGroup(List members, long grpEntId)");
		}

		Connection var5 = null;
		PreparedStatement var6 = null;
		String var7 = this.qs.createDBGrpRelation;

		try {
			var5 = this.getConnection();
			var6 = var5.prepareStatement(var7);

			for (int var8 = 0; var8 < var1.size(); ++var8) {
				var6.setLong(1, var2);
				var6.setString(2, ((DBExtIdReposId) var1.get(var8)).getReposId());
				var6.setString(3, DAOHelper.getTruncatedExternalId(((DBExtIdReposId) var1.get(var8)).getExtId()));
				var6.setString(4, ((DBExtIdReposId) var1.get(var8)).getExtId());

				try {
					var6.executeUpdate();
				} catch (SQLException var21) {
					if (!var21.getClass().getName().equals(FactoryManager.getDuplicateKeyExceptionName())) {
						throw var21;
					}
				}
			}
		} catch (SQLException var22) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var22.getMessage()),
					CLASSNAME, "assignMembersToGroup(List members, long grpEntId)", var22);
		} finally {
			try {
				this.closeConnection(var5);
			} catch (Exception var20) {
				;
			}

			try {
				var6.close();
			} catch (Exception var19) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "assignMembersToGroup(List members, long grpEntId)");
		}

	}

	public void unassignMemberFromAllGroups(DBExtIdReposId var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "unassignMemberFromAllGroups(DBExtIdReposId extReposId)");
		}

		Connection var3 = null;
		PreparedStatement var4 = null;
		String var5 = this.qs.deleteAllDBGrpRelationForMember;

		try {
			var3 = this.getConnection();
			var4 = var3.prepareStatement(var5);
			var4.setString(1, var1.getReposId());
			var4.setString(2, DAOHelper.getTruncatedExternalId(var1.getExtId()));
			var4.executeUpdate();
		} catch (SQLException var17) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var17.getMessage()),
					CLASSNAME, "unassignMemberFromAllGroups(DBExtIdReposId extReposId)", var17);
		} finally {
			try {
				this.closeConnection(var3);
			} catch (Exception var16) {
				;
			}

			try {
				var4.close();
			} catch (Exception var15) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "unassignMemberFromAllGroups(DBExtIdReposId extReposId)");
		}

	}

	public void unassignAllMembersFromGroup(long var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "unassignAllMembersFromGroup(long grpEntId)");
		}

		Connection var4 = null;
		PreparedStatement var5 = null;
		String var6 = this.qs.deleteAllDBGrpRelationForGroup;

		try {
			var4 = this.getConnection();
			var5 = var4.prepareStatement(var6);
			var5.setLong(1, var1);
			var5.executeUpdate();
		} catch (SQLException var18) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var18.getMessage()),
					CLASSNAME, "unassignAllMembersFromGroup(long grpEntId)", var18);
		} finally {
			try {
				this.closeConnection(var4);
			} catch (Exception var17) {
				;
			}

			try {
				var5.close();
			} catch (Exception var16) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "unassignAllMembersFromGroup(long grpEntId)");
		}

	}

	public void unassignMemberFromGroups(DBExtIdReposId var1, List var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "unassignMemberFromGroups(DBExtIdReposId extReposId, List groupEntIds)");
		}

		Connection var4 = null;
		PreparedStatement var5 = null;
		String var6 = this.qs.unassignGrpRelation;

		try {
			var4 = this.getConnection();
			var5 = var4.prepareStatement(var6);
			int var7 = 0;

			while (true) {
				if (var7 >= var2.size()) {
					int[] var20 = var5.executeBatch();
					break;
				}

				var5.setLong(1, (Long) var2.get(var7));
				var5.setString(2, var1.getReposId());
				var5.setString(3, DAOHelper.getTruncatedExternalId(var1.getExtId()));
				var5.addBatch();
				++var7;
			}
		} catch (SQLException var18) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var18.getMessage()),
					CLASSNAME, "unassignMemberFromGroups(DBExtIdReposId extReposId, List groupEntIds)", var18);
		} finally {
			try {
				this.closeConnection(var4);
			} catch (Exception var17) {
				;
			}

			try {
				var5.close();
			} catch (Exception var16) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "unassignMemberFromGroups(DBExtIdReposId extReposId, List groupEntIds)");
		}

	}

	public void unassignMembersFromGroup(List var1, long var2, String var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "unassignMembersFromGroup(List members, long grpEntId)");
		}

		Connection var6 = null;
		PreparedStatement var7 = null;
		String var8 = this.qs.unassignGrpRelation;

		try {
			var6 = this.getConnection();
			var7 = var6.prepareStatement(var8);
			int var9 = 0;

			while (true) {
				if (var9 >= var1.size()) {
					int[] var22 = var7.executeBatch();
					break;
				}

				var7.setLong(1, var2);
				var7.setString(2, ((DBExtIdReposId) var1.get(var9)).getReposId());
				var7.setString(3, DAOHelper.getTruncatedExternalId(((DBExtIdReposId) var1.get(var9)).getExtId()));
				var7.addBatch();
				++var9;
			}
		} catch (SQLException var20) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var20.getMessage()),
					CLASSNAME, "unassignMembersFromGroup(List members, long grpEntId)", var20);
		} finally {
			try {
				this.closeConnection(var6);
			} catch (Exception var19) {
				;
			}

			try {
				var7.close();
			} catch (Exception var18) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "unassignMembersFromGroup(List members, long grpEntId)");
		}

	}

	public int createLookAsidePropertyDefinition(DBRepositoryProperty var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createLookAsidePropertyDefinition(DBRepositoryProperty prop)");
		}

		Connection var3 = null;
		PreparedStatement var4 = null;
		int var5 = -1;
		boolean var6 = false;

		while (!var6) {
			try {
				var3 = this.getConnection();
				var5 = (new Long(this.keyMgr.getLAKeyForTable(var3, "LAPROP"))).intValue();
				var4 = var3.prepareStatement(this.qs.createLAPropertyDefintion);
				var4.setInt(1, var5);
				var4.setString(2, var1.getName());
				var4.setString(3, var1.getDataType());
				var4.setString(4, var1.getMetadataName());
				var4.setInt(5, var1.isComposite() ? 1 : 0);
				var4.setInt(6, var1.getValueLength());
				var4.setInt(7, var1.isReadOnly() ? 1 : 0);
				var4.setInt(8, var1.isMultipleValued() ? 1 : 0);
				var4.setInt(9, var1.isCaseSensitive() ? 1 : 0);
				if (var1.getDataType().equalsIgnoreCase("OBJECT")) {
					var4.setString(10, var1.getClassName());
				} else {
					var4.setNull(10, 12);
				}

				if (var1.getDescription() != null) {
					var4.setString(11, var1.getDescription());
				} else {
					var4.setNull(11, 12);
				}

				var4.setString(12, var1.getApplicationId());
				var4.executeUpdate();

				try {
					var4.close();
				} catch (Exception var26) {
					;
				}

				Set var7 = var1.getApplicableEntityTypes();
				Set var8 = var1.getRequiredEntityTypes();
				Iterator var9 = var7.iterator();

				while (var9.hasNext()) {
					PreparedStatement var10 = var3.prepareStatement(this.qs.createLAPropertyEntity);
					String var11 = (String) var9.next();
					var10.setLong(1, (long) var5);
					var10.setString(2, var11);
					if (var8 != null) {
						var10.setInt(3, var8.contains(var11) ? 1 : 0);
					} else {
						var10.setInt(3, 0);
					}

					var10.executeUpdate();

					try {
						var10.close();
					} catch (Exception var25) {
						;
					}
				}

				var6 = true;
			} catch (NamingException var27) {
				var6 = true;
				throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME,
						"createLookAsidePropertyDefinition(DBRepositoryProperty prop)", var27);
			} catch (DuplicateKeyException var28) {
				var6 = false;
				if (var28.getMessage().contains("WIMI") || var28.getMessage().contains("WIMF")) {
					var6 = true;
					throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var28.getMessage()),
							CLASSNAME, "createLookAsidePropertyDefinition(DBRepositoryProperty prop)", var28);
				}

				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME,
							"createLookAsidePropertyDefinition(DBRepositoryProperty prop)", "Reattempting");
				}
			} catch (SQLException var29) {
				var6 = true;
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var29.getMessage()),
						CLASSNAME, "createLookAsidePropertyDefinition(DBRepositoryProperty prop)", var29);
			} finally {
				try {
					this.closeConnection(var3);
				} catch (Exception var24) {
					;
				}

				var3 = null;
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createLookAsidePropertyDefinition(DBRepositoryProperty prop)");
		}

		return var5;
	}

	public int createPropertyDefinition(DBRepositoryProperty var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createPropertyDefinition(DBRepositoryProperty prop)");
		}

		Connection var3 = null;
		PreparedStatement var4 = null;
		int var5 = -1;
		boolean var6 = false;

		while (!var6) {
			try {
				var3 = this.getConnection();
				var5 = (new Long(this.keyMgr.getDBKeyForTable(var3, "DBPROP"))).intValue();
				var4 = var3.prepareStatement(this.qs.createPropertyDefintion);
				var4.setInt(1, var5);
				var4.setString(2, var1.getName());
				var4.setString(3, var1.getDataType());
				var4.setString(4, var1.getMetadataName());
				var4.setInt(5, var1.isComposite() ? 1 : 0);
				var4.setInt(6, var1.getValueLength());
				var4.setInt(7, var1.isReadOnly() ? 1 : 0);
				var4.setInt(8, var1.isMultipleValued() ? 1 : 0);
				var4.setInt(9, var1.isCaseSensitive() ? 1 : 0);
				if (var1.getDataType().equalsIgnoreCase("OBJECT")) {
					var4.setString(10, var1.getClassName());
				} else {
					var4.setNull(10, 12);
				}

				if (var1.getDescription() != null) {
					var4.setString(11, var1.getDescription());
				} else {
					var4.setNull(11, 12);
				}

				var4.setString(12, var1.getApplicationId());
				var4.executeUpdate();

				try {
					var4.close();
				} catch (Exception var26) {
					;
				}

				Set var7 = var1.getApplicableEntityTypes();
				Set var8 = var1.getRequiredEntityTypes();
				Iterator var9 = var7.iterator();

				while (var9.hasNext()) {
					PreparedStatement var10 = var3.prepareStatement(this.qs.createPropertyEntity);
					String var11 = (String) var9.next();
					var10.setLong(1, (long) var5);
					var10.setString(2, var11);
					if (var8 != null) {
						var10.setInt(3, var8.contains(var11) ? 1 : 0);
					} else {
						var10.setInt(3, 0);
					}

					var10.executeUpdate();

					try {
						var10.close();
					} catch (Exception var25) {
						;
					}
				}

				var6 = true;
			} catch (NamingException var27) {
				var6 = true;
				throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME,
						"createPropertyDefinition(DBRepositoryProperty prop)", var27);
			} catch (DuplicateKeyException var28) {
				var6 = false;
				if (var28.getMessage().contains("WIMI") || var28.getMessage().contains("WIMF")) {
					var6 = true;
					throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var28.getMessage()),
							CLASSNAME, "createPropertyDefinition(DBRepositoryProperty prop)", var28);
				}

				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "createPropertyDefinition(DBRepositoryProperty prop)",
							"Reattempting");
				}
			} catch (SQLException var29) {
				var6 = true;
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var29.getMessage()),
						CLASSNAME, "createPropertyDefinition(DBRepositoryProperty prop)", var29);
			} finally {
				try {
					this.closeConnection(var3);
				} catch (Exception var24) {
					;
				}

				var3 = null;
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createPropertyDefinition(DBRepositoryProperty prop)");
		}

		return var5;
	}

	public boolean isValidSchema(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isValidSchema(String dbSchema)", "dbSchema= " + var1);
		}

		boolean var3 = false;
		Connection var4 = null;
		PreparedStatement var5 = null;
		ResultSet var6 = null;
		String var7 = null;
		boolean var17 = false;

		try {
			var17 = true;
			var4 = this.getConnection();
			var7 = this.qs.selectSchema;
			var5 = var4.prepareStatement(var7);
			var5.setString(1, var1.trim().toUpperCase());
			var6 = var5.executeQuery();
			if (var6.next()) {
				var3 = true;
				var17 = false;
			} else {
				var17 = false;
			}
		} catch (SQLException var18) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var18.getMessage()),
					CLASSNAME, "isValidSchema(String dbSchema)", var18);
		} finally {
			if (var17) {
				try {
					if (var5 != null) {
						var5.close();
					}

					if (var6 != null) {
						var6.close();
					}

					if (var4 != null) {
						this.closeConnection(var4);
					}
				} catch (SQLException var19) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var12 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var12.append(var19.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "isValidSchema(String dbSchema)", var12.toString(),
								WIMMessageHelper.generateMsgParms(var19));
					}
				}

			}
		}

		try {
			if (var5 != null) {
				var5.close();
			}

			if (var6 != null) {
				var6.close();
			}

			if (var4 != null) {
				this.closeConnection(var4);
			}
		} catch (SQLException var21) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var9 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var9.append(var21.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "isValidSchema(String dbSchema)", var9.toString(),
						WIMMessageHelper.generateMsgParms(var21));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isValidSchema(String dbSchema)", var3);
		}

		return var3;
	}

	public Map search(String var1, List var2, boolean var3, DataObject var4, String var5, int var6)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"search(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT)");
		}

		SchemaManager var8 = SchemaManager.singleton();
		Connection var9 = null;
		PreparedStatement var10 = null;
		HashMap var11 = new HashMap();

		try {
			var9 = this.getConnection();
			var10 = var9.prepareStatement(var1, 1003, 1007);
			int var12 = 1;

			for (int var13 = 0; var13 < var6; ++var13) {
				for (Iterator var14 = var2.iterator(); var14.hasNext(); ++var12) {
					SearchParameter var15 = (SearchParameter) var14.next();
					switch (var15.dataType) {
						case 0 :
							var10.setString(var12, (String) var15.paramValue);
							break;
						case 1 :
							var10.setLong(var12, (Long) var15.paramValue);
							break;
						case 2 :
							var10.setDouble(var12, (Double) var15.paramValue);
							break;
						case 3 :
							if (var15.paramValue == null) {
								var10.setInt(var12, var15.propId);
							} else {
								var10.setInt(var12, (Integer) var15.paramValue);
							}
							break;
						case 4 :
							var10.setTimestamp(var12, (Timestamp) var15.paramValue);
							break;
						case 5 :
							var10.setString(var12, (String) var15.paramValue);
					}
				}
			}

			ResultSet var45 = var10.executeQuery();
			boolean var46 = true;
			long var47 = -1L;
			long var17 = -1L;
			boolean var19 = true;
			EClass var20 = null;
			List var21 = var4.getList("entities");
			DataObject var22;
			String var23;
			String var25;
			if (var3) {
				var22 = null;

				while (var45.next()) {
					var23 = var45.getString(4).trim();
					var20 = SchemaManager.singleton().getEClass(var23);
					var22 = (DataObject) EcoreUtil.create(var20);
					DataObject var24 = var22.createDataObject("identifier");
					var17 = var45.getLong(1);
					var25 = var45.getString(2);
					var24.setString("uniqueName", var25);
					var24.setString("externalName", var25);
					var24.setString("externalId", var45.getString(3));
					var24.setString("repositoryId", var5);
					var21.add(var22);
					var11.put(new Long(var17), var22);
				}

				if (var22 != null) {
					var21.add(var22);
					var11.put(new Long(var17), var22);
				}
			} else {
				var22 = null;

				for (var23 = null; var45.next(); var47 = var17) {
					int var48 = var45.getInt(1);
					var17 = var45.getLong(3);
					if (var17 != var47) {
						if (var22 != null) {
							var21.add(var22);
							var11.put(new Long(var17), var22);
						}

						var23 = var45.getString(6).trim();
						var20 = SchemaManager.singleton().getEClass(var23);
						var22 = (DataObject) EcoreUtil.create(var20);
						DataObject var49 = var22.createDataObject("identifier");
						String var26 = var45.getString(4);
						String var27 = var45.getString(5);
						var49.setString("uniqueName", var26);
						var49.setString("externalName", var26);
						var49.setString("uniqueId", var27);
						var49.setString("externalId", var27);
						var49.setString("repositoryId", var5);
					}

					var25 = var45.getString(8);
					int var50 = var45.getInt(9);
					short var51 = var45.getShort(2);
					Property var28 = null;
					if (var25 != null && var23 != null) {
						var28 = var8.getProperty(var23, var25);
						if (var48 != -100) {
							if (var51 != 5) {
								if (var50 == 1) {
									var22.getList(var28).add(DAOHelper.getRightTypeValue(var45, var51, var48));
								} else {
									var22.set(var28, DAOHelper.getRightTypeValue(var45, var51, var48));
								}
							} else {
								String[] var29 = (String[]) DAOHelper.getRightReferenceTypeValue(var45, 10, var48,
										var48 + 1);
								EClass var30 = SchemaManager.singleton().getEClass("IdentifierType");
								DataObject var31 = (DataObject) EcoreUtil.create(var30);
								var31.setString("uniqueName", var29[0]);
								var31.setString("externalId", var29[1]);
								var31.setString("repositoryId", var29[2]);
								if (var50 == 1) {
									var22.getList(var28).add(var31);
								} else {
									var22.set(var28, var31);
								}
							}
						}
					}
				}

				if (var22 != null) {
					var21.add(var22);
					var11.put(new Long(var17), var22);
				}

				var45.close();
			}
		} catch (SQLException var41) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var41.getMessage()),
					CLASSNAME, "search(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT)",
					var41);
		} catch (IOException var42) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"search(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT)", var42);
		} catch (ClassNotFoundException var43) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"search(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT)", var43);
		} finally {
			try {
				if (var10 != null) {
					var10.close();
				}

				if (var9 != null) {
					this.closeConnection(var9);
				}
			} catch (Exception var40) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"search(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT)");
		}

		return var11;
	}

	public Map searchLA(String var1, List var2, boolean var3, DataObject var4, String var5, int var6)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"searchLA(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT, String reposId, int unionCount)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3, var5, new Integer(var6)}));
		}

		SchemaManager var8 = SchemaManager.singleton();
		Connection var9 = null;
		PreparedStatement var10 = null;
		HashMap var11 = new HashMap();

		try {
			var9 = this.getConnection();
			var10 = var9.prepareStatement(var1, 1003, 1007);
			int var12 = 1;

			for (int var13 = 0; var13 < var6; ++var13) {
				for (Iterator var14 = var2.iterator(); var14.hasNext(); ++var12) {
					SearchParameter var15 = (SearchParameter) var14.next();
					switch (var15.dataType) {
						case 0 :
							var10.setString(var12, (String) var15.paramValue);
							break;
						case 1 :
							var10.setLong(var12, (Long) var15.paramValue);
							break;
						case 2 :
							var10.setDouble(var12, (Double) var15.paramValue);
							break;
						case 3 :
							if (var15.paramValue == null) {
								var10.setInt(var12, var15.propId);
							} else {
								var10.setInt(var12, (Integer) var15.paramValue);
							}
							break;
						case 4 :
							var10.setTimestamp(var12, (Timestamp) var15.paramValue);
							break;
						case 5 :
							var10.setString(var12, (String) var15.paramValue);
					}
				}
			}

			ResultSet var45 = var10.executeQuery();
			boolean var46 = true;
			long var47 = -1L;
			long var17 = -1L;
			boolean var19 = true;
			EClass var20 = null;
			List var21 = var4.getList("entities");
			DataObject var22;
			String var23;
			if (var3) {
				var22 = null;

				while (var45.next()) {
					var23 = var45.getString(1).trim();
					var20 = SchemaManager.singleton().getEClass(var23);
					var22 = (DataObject) EcoreUtil.create(var20);
					DataObject var24 = var22.createDataObject("identifier");
					var24.setString("externalId", var45.getString(2));
					var24.setString("repositoryId", var45.getString(3).trim());
					var21.add(var22);
				}
			} else {
				var22 = null;

				for (var23 = null; var45.next(); var47 = var17) {
					int var48 = var45.getInt(1);
					var17 = var45.getLong(3);
					if (var17 != var47) {
						if (var22 != null) {
							var21.add(var22);
							var11.put(new Long(var17), var22);
						}

						var23 = var45.getString(4).trim();
						var20 = SchemaManager.singleton().getEClass(var23);
						var22 = (DataObject) EcoreUtil.create(var20);
						DataObject var25 = var22.createDataObject("identifier");
						var25.setString("externalId", var45.getString(5));
						var25.setString("repositoryId", var45.getString(6).trim());
					}

					String var49 = var45.getString(8);
					int var26 = var45.getInt(9);
					short var27 = var45.getShort(2);
					Property var28 = var8.getProperty(var23, var49);
					if (var48 != -100) {
						if (var27 != 5) {
							if (var26 == 1) {
								var22.getList(var28).add(DAOHelper.getRightTypeValue(var45, var27, var48));
							} else {
								var22.set(var28, DAOHelper.getRightTypeValue(var45, var27, var48));
							}
						} else {
							String[] var29 = (String[]) DAOHelper.getRightReferenceTypeValue(var45, 15, 17, 16);
							EClass var30 = SchemaManager.singleton().getEClass("IdentifierType");
							DataObject var31 = (DataObject) EcoreUtil.create(var30);
							var31.setString("uniqueName", var29[0]);
							var31.setString("externalId", var29[1]);
							var31.setString("repositoryId", var29[2]);
							if (var26 == 1) {
								var22.getList(var28).add(var31);
							} else {
								var22.set(var28, var31);
							}
						}
					}
				}

				if (var22 != null) {
					var21.add(var22);
					var11.put(new Long(var17), var22);
				}

				var45.close();
			}
		} catch (SQLException var41) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var41.getMessage()),
					CLASSNAME,
					"searchLA(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT, String reposId, int unionCount)",
					var41);
		} catch (IOException var42) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"searchLA(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT, String reposId, int unionCount)",
					var42);
		} catch (ClassNotFoundException var43) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"searchLA(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT, String reposId, int unionCount)",
					var43);
		} finally {
			try {
				if (var10 != null) {
					var10.close();
				}

				if (var9 != null) {
					this.closeConnection(var9);
				}
			} catch (Exception var40) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"searchLA(String searchQuery, List parameters, boolean needIdsOnly, DataObject returnRT, String reposId, int unionCount)",
					WIMMessageHelper.generateMsgParms(var11));
		}

		return var11;
	}

	public void getObjectProperties(Map var1, String var2, String var3, boolean var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getObjectProperties(Map entities, String objectQuery, String entityIdsSQL, boolean dbRepos)",
					WIMMessageHelper.generateMsgParms(var1, var2, var3, var4));
		}

		Connection var6 = null;
		PreparedStatement var7 = null;
		ResultSet var8 = null;

		try {
			if (var1 != null && var2 != null && var3 != null) {
				StringBuffer var9 = new StringBuffer(256 + var2.length() + var3.length());
				if (var4) {
					var9.append(this.qs.getDBObjectPropertyValuesByEntityIds);
					var9.append(var3);
					var9.append(this.qs.RIGHT_BRACKET);
					var9.append(this.qs.andDBObjectPropertyIdInWithLeftBracket);
					var9.append(var2);
					var9.append(this.qs.RIGHT_BRACKET);
				} else {
					var9.append(this.qs.getLAObjectPropertyValuesByEntityIds);
					var9.append(var3);
					var9.append(this.qs.RIGHT_BRACKET);
					var9.append(this.qs.andLAObjectPropertyIdInWithLeftBracket);
					var9.append(var2);
					var9.append(this.qs.RIGHT_BRACKET);
				}

				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME,
							"getObjectProperties(Map entities, String objectQuery, String entityIdsSQL, boolean dbRepos)",
							var9.toString());
				}

				var6 = this.getConnection();
				var7 = var6.prepareStatement(var9.toString(), 1003, 1007);
				var8 = var7.executeQuery();

				while (var8.next()) {
					Long var10 = new Long(var8.getLong(1));
					String var11 = var8.getString(2);
					int var12 = var8.getInt(3);
					DataObject var13 = (DataObject) var1.get(var10);
					Type var14 = var13.getType();
					Property var15 = SchemaManager.singleton().getProperty(var14, var11);
					if (var12 == 1) {
						var13.getList(var15).add(DAOHelper.getRightTypeValue(var8, (short) 6, 4));
					} else {
						var13.set(var15, DAOHelper.getRightTypeValue(var8, (short) 6, 4));
					}
				}
			}
		} catch (SQLException var25) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var25.getMessage()),
					CLASSNAME,
					"getObjectProperties(Map entities, String objectQuery, String entityIdsSQL, boolean dbRepos)",
					var25);
		} catch (IOException var26) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"getObjectProperties(Map entities, String objectQuery, String entityIdsSQL, boolean dbRepos)",
					var26);
		} catch (ClassNotFoundException var27) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"getObjectProperties(Map entities, String objectQuery, String entityIdsSQL, boolean dbRepos)",
					var27);
		} finally {
			try {
				if (var7 != null) {
					var7.close();
				}

				if (var8 != null) {
					var8.close();
				}

				if (var6 != null) {
					this.closeConnection(var6);
				}
			} catch (Exception var24) {
				;
			}

		}

	}

	public String getOperator(String var1, short var2) {
		return var1 != null && var1.equals("!=") ? this.getQuerySet().NOT_EQUAL : var1;
	}

	public void getCompositeProperties(Map var1, String var2, boolean[] var3, String var4, boolean var5)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getCompositeProperties(Map entities, String compositeQuery, boolean[] compositeTypes, String entityIdsSQL, boolean dbRepos)",
					WIMMessageHelper.generateMsgParms(var1, var2, var4, var5));
		}

		Connection var7 = null;
		PreparedStatement var8 = null;
		ResultSet var9 = null;

		try {
			if (var1 != null && var2 != null && var4 != null) {
				StringBuffer var10 = new StringBuffer(256 + var2.length() + var4.length());
				StringBuffer var11 = new StringBuffer(1024);
				if (var5) {
					var10.append(this.qs.andDBCompositePropertyIdInWithLeftBracket);
					var10.append(var2);
					var10.append(this.qs.RIGHT_BRACKET);
					var10.append(this.qs.andDBCompositeEntityIdInWithLeftBracket);
					var10.append(var4);
					var10.append(this.qs.RIGHT_BRACKET);
					var11.append(this.qs.findCompositePropertiesForDBEntities);
					var11.append(var10.toString());
					if (var3[0]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findStringCompositePropertiessForDBEntities);
						var11.append(var10.toString());
					}

					if (var3[1]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findLongCompositePropertiessForDBEntities);
						var11.append(var10.toString());
					}

					if (var3[2]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findDoubleCompositePropertiessForDBEntities);
						var11.append(var10.toString());
					}

					if (var3[3]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findIntegerCompositePropertiessForDBEntities);
						var11.append(var10.toString());
					}

					if (var3[4]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findTimestampCompositePropertiessForDBEntities);
						var11.append(var10.toString());
					}

					if (var3[5]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findReferenceCompositePropertiessForDBEntities);
						var11.append(var10.toString());
					}
				} else {
					var10.append(this.qs.andLACompositePropertyIdInWithLeftBracket);
					var10.append(var2);
					var10.append(this.qs.RIGHT_BRACKET);
					var10.append(this.qs.andLACompositeEntityIdInWithLeftBracket);
					var10.append(var4);
					var10.append(this.qs.RIGHT_BRACKET);
					var11.append(this.qs.findCompositePropertiesForLAEntities);
					var11.append(var10.toString());
					if (var3[0]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findStringCompositePropertiessForLAEntities);
						var11.append(var10.toString());
					}

					if (var3[1]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findLongCompositePropertiessForLAEntities);
						var11.append(var10.toString());
					}

					if (var3[2]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findDoubleCompositePropertiessForLAEntities);
						var11.append(var10.toString());
					}

					if (var3[3]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findIntegerCompositePropertiessForLAEntities);
						var11.append(var10.toString());
					}

					if (var3[4]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findTimestampCompositePropertiessForLAEntities);
						var11.append(var10.toString());
					}

					if (var3[5]) {
						var11.append(this.qs.UNION);
						var11.append(this.qs.findReferenceCompositePropertiessForLAEntities);
						var11.append(var10.toString());
					}
				}

				if (var11.length() > 0) {
					var11.append(this.qs.findCompositePropertiesOrderBy);
				}

				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME,
							"getCompositeProperties(Map entities, String compositeQuery, boolean[] compositeTypes, String entityIdsSQL, boolean dbRepos)",
							var11.toString());
				}

				var7 = this.getConnection();
				var8 = var7.prepareStatement(var11.toString(), 1003, 1007);
				var9 = var8.executeQuery();
				long var12 = -1L;
				long var14 = -1L;
				DataObject var16 = null;
				DataObject var17 = null;
				Type var18 = null;

				while (var9.next()) {
					int var19 = var9.getInt(1);
					var14 = var9.getLong(3);
					if (var14 != var12) {
						var16 = (DataObject) var1.get(new Long(var14));
					}

					Type var20 = var16.getType();
					String var21 = var9.getString(5);
					String var22 = var9.getString(8);
					if (var19 == -100) {
						Property var23 = SchemaManager.singleton().getProperty(var20, var21);
						var17 = var16.createDataObject(var23);
						var18 = var17.getType();
					} else {
						short var42 = var9.getShort(2);
						int var24 = var9.getInt(9);
						var22 = var9.getString(8).substring(var21.length() + 1);
						Property var25 = SchemaManager.singleton().getProperty(var18, var22);
						if (var42 != 5) {
							if (var24 == 1) {
								var17.getList(var25).add(DAOHelper.getRightTypeValue(var9, var42, var19));
							} else {
								var17.set(var25, DAOHelper.getRightTypeValue(var9, var42, var19));
							}
						} else {
							String[] var26 = (String[]) ((String[]) DAOHelper.getRightTypeValue(var9, var42, var19));
							EClass var27 = SchemaManager.singleton().getEClass("IdentifierType");
							DataObject var28 = (DataObject) EcoreUtil.create(var27);
							var28.setString("externalId", var26[0]);
							var28.setString("repositoryId", var26[1]);
							if (var24 == 1) {
								var17.getList(var25).add(var28);
							} else {
								var17.set(var25, var28);
							}
						}
					}
				}
			}
		} catch (SQLException var38) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var38.getMessage()),
					CLASSNAME,
					"getCompositeProperties(Map entities, String compositeQuery, boolean[] compositeTypes, String entityIdsSQL, boolean dbRepos)",
					var38);
		} catch (IOException var39) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"getCompositeProperties(Map entities, String compositeQuery, boolean[] compositeTypes, String entityIdsSQL, boolean dbRepos)",
					var39);
		} catch (ClassNotFoundException var40) {
			throw new WIMSystemException("GENERIC", CLASSNAME,
					"getCompositeProperties(Map entities, String compositeQuery, boolean[] compositeTypes, String entityIdsSQL, boolean dbRepos)",
					var40);
		} finally {
			try {
				if (var8 != null) {
					var8.close();
				}

				if (var9 != null) {
					var9.close();
				}

				if (var7 != null) {
					this.closeConnection(var7);
				}
			} catch (Exception var37) {
				;
			}

		}

	}

	public DBAccount getDBAccountByEntId(long var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getDBAccountByDBEntity(long entId)");
		}

		DBAccount var4 = null;
		Connection var5 = null;
		PreparedStatement var6 = null;
		ResultSet var7 = null;
		String var8 = null;
		boolean var18 = false;

		try {
			var18 = true;
			var5 = this.getConnection();
			var8 = this.qs.findDBAccountByEntId;
			var6 = var5.prepareStatement(var8);
			var6.setLong(1, var1);
			var7 = var6.executeQuery();
			if (var7.next()) {
				var4 = new DBAccount();
				var4.setEntityId(var7.getLong(1));
				var4.setPassword(var7.getBytes(2));
				var4.setSalt(var7.getString(3));
				var4.setExternalId(var7.getString(4));
				var4.setRepositoryId(var7.getString(5));
				var18 = false;
			} else {
				var18 = false;
			}
		} catch (SQLException var19) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var19.getMessage()),
					CLASSNAME, "getDBAccountByDBEntity(long entId)", var19);
		} finally {
			if (var18) {
				try {
					if (var6 != null) {
						var6.close();
					}

					if (var7 != null) {
						var7.close();
					}

					if (var5 != null) {
						this.closeConnection(var5);
					}
				} catch (SQLException var20) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var13 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var13.append(var20.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "getDBAccountByDBEntity(long entId)", var13.toString(),
								WIMMessageHelper.generateMsgParms(var20));
					}
				}

			}
		}

		try {
			if (var6 != null) {
				var6.close();
			}

			if (var7 != null) {
				var7.close();
			}

			if (var5 != null) {
				this.closeConnection(var5);
			}
		} catch (SQLException var22) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var10 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var10.append(var22.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "getDBAccountByDBEntity(long entId)", var10.toString(),
						WIMMessageHelper.generateMsgParms(var22));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getDBAccountByDBEntity(long entId)");
		}

		return var4;
	}

	public void createAccount(long var1, byte[] var3, String var4, String var5, String var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createAccount(long entId, byte[]bytepwd, String salt, String extId, String reposId)");
		}

		Connection var8 = null;
		PreparedStatement var9 = null;

		try {
			var8 = this.getConnection();
			String var10 = this.qs.createAccount;
			var9 = var8.prepareStatement(var10);
			var9.setLong(1, var1);
			var9.setBytes(2, var3);
			var9.setString(3, var4);
			if (var5 == null) {
				var9.setNull(4, 12);
				var9.setNull(5, 12);
				var9.setNull(6, 12);
			} else {
				var9.setString(4, DAOHelper.getTruncatedExternalId(var5));
				var9.setString(5, var5);
				var9.setString(6, var6);
			}

			var9.executeUpdate();
		} catch (SQLException var18) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var18.getMessage()),
					CLASSNAME, "createAccount(long entId, byte[]bytepwd, String salt, String extId, String reposId)",
					var18);
		} finally {
			try {
				if (var9 != null) {
					var9.close();
				}

				this.closeConnection(var8);
			} catch (Exception var17) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"createAccount(long entId, byte[]bytepwd, String salt, String extId, String reposId)");
		}

	}

	public long createLAEntity(LAEntity var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createLAEntity(LAEntity newEnt)");
		}

		String var3 = var1.getEntityType();
		String var4 = var1.getExternalId();
		String var5 = var1.getRepositoryId();
		int var6 = 0;
		Connection var7 = null;
		PreparedStatement var8 = null;
		long var9 = -1L;
		boolean var11 = false;

		while (!var11 && var6 < 25) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createLAEntity(LAEntity newEnt)",
					"Attempt if not exception : " + var6);
			boolean var24 = false;

			StringBuffer var13;
			label204 : {
				try {
					var24 = true;
					var7 = this.getConnection();
					var9 = this.keyMgr.getLAKeyForTable(var7, "LAENTITY");
					String var12 = this.qs.createLAEntity;
					var8 = var7.prepareStatement(var12);
					var8.setLong(1, var9);
					var8.setString(2, var3);
					var8.setString(3, DAOHelper.getTruncatedExternalId(var4));
					var8.setString(4, var4);
					var8.setString(5, var5);
					var8.executeUpdate();
					var11 = true;
					var24 = false;
					break label204;
				} catch (NamingException var28) {
					var11 = true;
					throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME, "createLAEntity(LAEntity newEnt)",
							var28);
				} catch (DuplicateKeyException var29) {
					var11 = false;
					if (!var29.getMessage().contains("WIMI") && !var29.getMessage().contains("WIMF")) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createLAEntity(LAEntity newEnt)",
								"Throw exception if no contraint violation from VMM");
						throw new WIMSystemException("SQL_EXCEPTION",
								WIMMessageHelper.generateMsgParms(var29.getMessage()), CLASSNAME,
								"createLAEntity(LAEntity newEnt)", var29);
					}

					++var6;
					if (var6 >= 25) {
						var11 = true;
						throw new WIMSystemException("SQL_EXCEPTION",
								WIMMessageHelper.generateMsgParms(var29.getMessage()), CLASSNAME,
								"createLAEntity(LAEntity newEnt)", var29);
					}

					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createLAEntity(LAEntity newEnt)",
								"Reattempting " + var6 + " times");
						var24 = false;
					} else {
						var24 = false;
					}
				} catch (SQLException var30) {
					var11 = true;
					throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var30.getMessage()),
							CLASSNAME, "createLAEntity(LAEntity newEnt)", var30);
				} finally {
					if (var24) {
						try {
							if (var8 != null) {
								var8.close();
							}

							this.closeConnection(var7);
						} catch (Exception var25) {
							if (trcLogger.isLoggable(Level.FINE)) {
								StringBuffer var16 = new StringBuffer(
										"Unexpected error when closing the prepared statement or the connection : ");
								var16.append(var25.toString());
								trcLogger.logp(Level.FINE, CLASSNAME, "createLAEntity(LAEntity newEnt)",
										var16.toString(), WIMMessageHelper.generateMsgParms(var25));
							}
						}

						var8 = null;
						var7 = null;
					}
				}

				try {
					if (var8 != null) {
						var8.close();
					}

					this.closeConnection(var7);
				} catch (Exception var26) {
					if (trcLogger.isLoggable(Level.FINE)) {
						var13 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var13.append(var26.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "createLAEntity(LAEntity newEnt)", var13.toString(),
								WIMMessageHelper.generateMsgParms(var26));
					}
				}

				var8 = null;
				var7 = null;
				continue;
			}

			try {
				if (var8 != null) {
					var8.close();
				}

				this.closeConnection(var7);
			} catch (Exception var27) {
				if (trcLogger.isLoggable(Level.FINE)) {
					var13 = new StringBuffer(
							"Unexpected error when closing the prepared statement or the connection : ");
					var13.append(var27.toString());
					trcLogger.logp(Level.FINE, CLASSNAME, "createLAEntity(LAEntity newEnt)", var13.toString(),
							WIMMessageHelper.generateMsgParms(var27));
				}
			}

			var8 = null;
			var7 = null;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createLAEntity(LAEntity newEnt)");
		}

		return var9;
	}

	public LAEntity findLAEntityByExtIdReposId(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "findLAEntityByExtIdReposId", "extId=" + var1 + ", reposId=" + var2);
		}

		LAEntity var4 = null;
		Connection var5 = null;
		PreparedStatement var6 = null;
		String var7 = null;
		ResultSet var8 = null;
		boolean var18 = false;

		try {
			var18 = true;
			var7 = this.qs.findLAEntityByExtIdReposId;
			var5 = this.getConnection();
			var6 = var5.prepareStatement(var7);
			var6.setString(1, DAOHelper.getTruncatedExternalId(var1));
			var6.setString(2, var2.trim());
			var8 = var6.executeQuery();

			while (true) {
				if (!var8.next()) {
					var18 = false;
					break;
				}

				var4 = new LAEntity();
				var4.setEntityId(var8.getLong("ENTITY_ID"));
				var4.setEntityType(var8.getString("ENTITY_TYPE"));
				var4.setExternalId(var8.getString("EXT_ID").trim());
				var4.setRepositoryId(var8.getString("REPOS_ID").trim());
			}
		} catch (SQLException var21) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var21.getMessage()),
					CLASSNAME, "findLAEntityByExtIdReposId", var21);
		} finally {
			if (var18) {
				try {
					if (var6 != null) {
						var6.close();
					}

					if (var8 != null) {
						var8.close();
					}

					if (var5 != null) {
						this.closeConnection(var5);
					}
				} catch (SQLException var19) {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var13 = new StringBuffer(
								"Unexpected error when closing the prepared statement or the connection : ");
						var13.append(var19.toString());
						trcLogger.logp(Level.FINE, CLASSNAME, "findLAEntityByExtIdReposId", var13.toString(),
								WIMMessageHelper.generateMsgParms(var19));
					}
				}

			}
		}

		try {
			if (var6 != null) {
				var6.close();
			}

			if (var8 != null) {
				var8.close();
			}

			if (var5 != null) {
				this.closeConnection(var5);
			}
		} catch (SQLException var20) {
			if (trcLogger.isLoggable(Level.FINE)) {
				StringBuffer var10 = new StringBuffer(
						"Unexpected error when closing the prepared statement or the connection : ");
				var10.append(var20.toString());
				trcLogger.logp(Level.FINE, CLASSNAME, "findLAEntityByExtIdReposId", var10.toString(),
						WIMMessageHelper.generateMsgParms(var20));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "findLAEntityByExtIdReposId", "anEnt=" + var4);
		}

		return var4;
	}

	private List getLAEntityTypesListOfExistingEntities(List var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getLAEntityTypesListOfExistingEntities", "inEntTypeList=" + var1);
		}

		Connection var3 = null;
		PreparedStatement var4 = null;
		String var5 = null;
		ResultSet var6 = null;
		var3 = this.getConnection();
		ArrayList var7 = null;

		try {
			var5 = this.qs.getLAEntitypesForExisting;
			var4 = var3.prepareStatement(var5);
			var6 = var4.executeQuery();
			var7 = new ArrayList();

			while (var6.next()) {
				String var8 = var6.getString("ENTITY_TYPE");
				var7.add(var8);
			}

			if (var1 != null && var1.size() > 0 && var7.size() > 0) {
				var7.retainAll(var1);
			}
		} catch (SQLException var16) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var16.getMessage()),
					CLASSNAME, "getLAEntityTypesListOfExistingEntities", var16);
		} finally {
			try {
				if (var4 != null) {
					var4.close();
				}

				if (var6 != null) {
					var6.close();
				}

				if (var3 != null) {
					this.closeConnection(var3);
				}
			} catch (SQLException var15) {
				if (trcLogger.isLoggable(Level.FINE) && trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "getLAEntityTypesListOfExistingEntities",
							"Unexpected error when closing the prepared statement or the connection : ", var15);
				}
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getLAEntityTypesListOfExistingEntities", "laEntTypeList=" + var7);
		}

		return var7;
	}

	private Map getLAPropertyAttributes(String var1, List var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getLAPropertyAttributes", "inPropName=" + var1 + ", laEntTypeList=" + var2);
		}

		PreparedStatement var4 = null;
		ResultSet var5 = null;
		Integer var6 = null;
		String var7 = null;
		String var8 = null;
		HashMap var9 = null;
		StringBuffer var10 = new StringBuffer(this.qs.getLAPropAttributeForEntitype);

		for (int var11 = 0; var11 < var2.size(); ++var11) {
			var10.append(this.qs.PARAM_MARKER);
			if (var11 != var2.size() - 1) {
				var10.append(this.qs.COMMA);
			}
		}

		var10.append(this.qs.RIGHT_BRACKET);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "getLAPropertyAttributes", "queryStmt=" + var10);
		}

		Connection var24 = this.getConnection();

		try {
			byte var12 = 1;
			var4 = var24.prepareStatement(var10.toString());
			int var25 = var12 + 1;
			var4.setString(var12, var1);

			for (int var13 = 0; var13 < var2.size(); ++var13) {
				String var14 = (String) var2.get(var13);
				var4.setString(var25++, var14);
			}

			var5 = var4.executeQuery();
			if (!var5.next()) {
				throw new InvalidPropertyDefinitionException("EXTENDED_PROPERTY_NOT_DEFINED_FOR_ENTITY_TYPES",
						WIMMessageHelper.generateMsgParms(var1, var2.toString()), CLASSNAME, "getLAPropertyAttributes");
			}

			var6 = var5.getInt("PROP_ID");
			var7 = var5.getString("TYPE_ID").trim();
			var8 = DAOHelper.getValueTableName((short) 1, DAOHelper.getDataTypeId(var7));
			if (this.dbSchema != null && !this.dbSchema.trim().equals("")) {
				var8 = this.dbSchema.trim() + "." + var8;
			}

			var9 = new HashMap();
			var9.put("name", var1);
			var9.put("PROP_ID", var6);
			var9.put("TYPE_ID", var7);
			var9.put("TABLE_NAME", var8);
		} catch (SQLException var22) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var22.getMessage()),
					CLASSNAME, "getLAPropertyAttributes", var22);
		} finally {
			try {
				if (var4 != null) {
					var4.close();
				}

				if (var5 != null) {
					var5.close();
				}

				if (var24 != null) {
					this.closeConnection(var24);
				}
			} catch (SQLException var21) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "getLAPropertyAttributes",
							"Unexpected error when closing the prepared statement or the connection : ", var21);
				}
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getLAPropertyAttributes", "laPropertyAttributes=" + var9);
		}

		return var9;
	}

	private void deleteLAPropertiesDataForEntTypes(Map var1, List var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteLAPropertiesDataForEntTypes",
					"laPropertyAttributes=" + var1 + ", laEntTypeList=" + var2);
		}

		PreparedStatement var4 = null;
		boolean var5 = false;
		ResultSet var6 = null;
		Integer var7 = (Integer) var1.get("PROP_ID");
		String var8 = (String) var1.get("TABLE_NAME");
		String var9 = (String) var1.get("name");
		ArrayList var10 = new ArrayList();
		ArrayList var11 = new ArrayList();
		ArrayList var12 = new ArrayList();
		StringBuffer var13 = new StringBuffer(this.qs.getLAEntIdsByPropIdAndEntTypes + var8);
		var13.append(this.qs.getLAEntIdsWhereClause);

		for (int var14 = 0; var14 < var2.size(); ++var14) {
			var13.append(this.qs.PARAM_MARKER);
			if (var14 != var2.size() - 1) {
				var13.append(this.qs.COMMA);
			}
		}

		var13.append(this.qs.RIGHT_BRACKET);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "deleteLAPropertiesDataForEntTypes", "queryStmt=" + var13);
		}

		Connection var45 = this.getConnection();

		int var46;
		try {
			byte var15 = 1;
			var4 = var45.prepareStatement(var13.toString());
			var46 = var15 + 1;
			var4.setInt(var15, var7);

			String var17;
			for (int var16 = 0; var16 < var2.size(); ++var16) {
				var17 = (String) var2.get(var16);
				var4.setString(var46++, var17);
			}

			var6 = var4.executeQuery();

			while (true) {
				if (!var6.next()) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "deleteLAPropertiesDataForEntTypes",
								"delLAEidList=" + var10);
						trcLogger.logp(Level.FINER, CLASSNAME, "deleteLAPropertiesDataForEntTypes",
								"delrepoEidList=" + var11);
						trcLogger.logp(Level.FINER, CLASSNAME, "deleteLAPropertiesDataForEntTypes",
								"delrepoIdList=" + var12);
					}
					break;
				}

				Long var47 = var6.getLong("ENTITY_ID");
				var17 = var6.getString("FULL_EXT_ID");
				String var18 = var6.getString("REPOS_ID");
				var10.add(var47);
				var11.add(var17);
				var12.add(var18);
			}
		} catch (SQLException var42) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var42.getMessage()),
					CLASSNAME, "deleteLAPropertiesDataForEntTypes", var42);
		} finally {
			try {
				if (var4 != null) {
					var4.close();
				}

				if (var45 != null) {
					this.closeConnection(var45);
					var45 = null;
				}

				if (var6 != null) {
					var6.close();
					var6 = null;
				}
			} catch (SQLException var39) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "deleteLAPropertiesDataForEntTypes",
							"Unexpected error when closing the prepared statement or the connection : ", var39);
				}
			}

		}

		if (var10.size() > 0) {
			if (var45 == null) {
				var45 = this.getConnection();
			}

			try {
				var46 = 1;
				StringBuffer var48 = new StringBuffer(
						this.qs.deleteEntityDataFromLAPropValueTable + var8 + this.qs.whereINEIdsClause);

				int var50;
				for (var50 = 0; var50 < var10.size(); ++var50) {
					var48.append(this.qs.PARAM_MARKER);
					if (var50 != var10.size() - 1) {
						var48.append(this.qs.COMMA);
					}
				}

				var48.append(this.qs.RIGHT_BRACKET);
				var48.append(this.qs.andPropIDEqualTo);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "deleteLAPropertiesDataForEntTypes", "deleteStmt=" + var48);
				}

				var4 = var45.prepareStatement(var48.toString());

				for (var50 = 0; var50 < var10.size(); ++var50) {
					Long var51 = (Long) var10.get(var50);
					var4.setLong(var46++, var51);
				}

				var4.setInt(var46++, var7);
				int var44 = var4.executeUpdate();
				if (var44 > 0 && trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "deleteLAPropertiesDataForEntTypes",
							"Deleted extended property " + var9 + " data for entities with LA entity ids as : " + var10
									+ " repository entity unique ids as : " + var11 + " and Repository ids as : "
									+ var12);
				}
			} catch (SQLException var40) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var40.getMessage()),
						CLASSNAME, "deleteLAPropertiesDataForEntTypes", var40);
			} finally {
				try {
					if (var4 != null) {
						var4.close();
					}

					if (var45 != null) {
						this.closeConnection(var45);
					}
				} catch (SQLException var38) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "deleteLAPropertiesDataForEntTypes",
								"Unexpected error when closing the prepared statement or the connection : ", var38);
					}
				}

			}
		} else if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "deleteLAPropertiesDataForEntTypes",
					"No data found in LA for property : " + var9 + " with applicable any entity types as : " + var2);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "deleteLAPropertiesDataForEntTypes");
		}

	}

	private void deleteEntIdsFromLAIfNoEntityPropDataExists() throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists");
		}

		Connection var2 = null;
		PreparedStatement var3 = null;
		String var4 = null;
		String var5 = null;
		var2 = this.getConnection();
		boolean var6 = false;
		ResultSet var7 = null;
		ArrayList var8 = new ArrayList();
		ArrayList var9 = new ArrayList();
		ArrayList var10 = new ArrayList();

		try {
			var4 = this.qs.getEidsForLACleanup;
			var3 = var2.prepareStatement(var4);
			var7 = var3.executeQuery();

			while (var7.next()) {
				Long var11 = var7.getLong("ENTITY_ID");
				String var12 = var7.getString("FULL_EXT_ID");
				String var13 = var7.getString("REPOS_ID");
				var8.add(var11);
				var9.add(var12);
				var10.add(var13.trim());
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists",
						"delLAEidList=" + var8);
				trcLogger.logp(Level.FINER, CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists",
						"delrepoEidList=" + var9);
				trcLogger.logp(Level.FINER, CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists",
						"delrepoIdList=" + var10);
			}
		} catch (SQLException var40) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists",
						"Unexpected error when deleting the entities from LA as a part of extended property data cleanup operation : ",
						var40);
			}
		} finally {
			try {
				if (var3 != null) {
					var3.close();
					var3 = null;
				}

				if (var2 != null) {
					this.closeConnection(var2);
					var2 = null;
				}
			} catch (SQLException var37) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists",
							"Unexpected error when closing the prepared statement or the connection : ", var37);
				}
			}

		}

		if (var8.size() > 0) {
			trcLogger.logp(Level.FINE, CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists",
					"No more extended property data associated with LA entities " + var8
							+ " with repository entity id as " + var9 + " and repository id as " + var10);
			var2 = this.getConnection();

			try {
				var5 = this.qs.deleteEntityFromLAIfNoPropValueIsAssociateWith;
				var3 = var2.prepareStatement(var5);
				int var42 = var3.executeUpdate();
				if (var42 > 0) {
					trcLogger.logp(Level.FINE, CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists",
							"Successfully deleted the entities " + var9 + " located in LA with ids " + var10);
				}
			} catch (SQLException var38) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists",
							"Unexpected error when deleting the entities from LA as a part of extended property data cleanup operation : ",
							var38);
				}
			} finally {
				try {
					if (var3 != null) {
						var3.close();
					}

					if (var2 != null) {
						this.closeConnection(var2);
					}
				} catch (SQLException var36) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists",
								"Unexpected error when closing the prepared statement or the connection : ", var36);
					}
				}

			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "deleteEntIdsFromLAIfNoEntityPropDataExists");
		}

	}

	public void deleteLAPropertyDataForEntityTypes(String var1, List var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteLAPropertyDataForEntityTypes",
					"input property name = " + var1 + ", input applicable entity type list = " + var2);
		}

		if (!this.databaseType.equals("derby") && this.dsLookup() == null && (this.dbUserId == null
				|| this.dbUserId.length() == 0 || this.dbPassword == null || this.dbPassword.length() == 0)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "deleteLAPropertyDataForEntityTypes",
					"Invalid db user id or password. Empty or null user id and password are not supported for DB of type "
							+ this.databaseType);
			throw new WIMConfigurationException("INVALID_DB_CREDENTIALS", CLASSNAME,
					"deleteLAPropertyDataForEntityTypes");
		} else {
			List var4 = null;
			var4 = this.getLAEntityTypesListOfExistingEntities(var2);
			if (var4 != null && var4.size() > 0) {
				Map var5 = this.getLAPropertyAttributes(var1, var4);
				this.deleteLAPropertiesDataForEntTypes(var5, var4);
				this.deleteEntIdsFromLAIfNoEntityPropDataExists();
			} else if (trcLogger.isLoggable(Level.FINER)) {
				if (var2.size() == 0) {
					trcLogger.logp(Level.FINER, CLASSNAME, "deleteLAPropertyDataForEntityTypes",
							"No property extension(LA) entity found for any supported entity types ");
				} else {
					trcLogger.logp(Level.FINER, CLASSNAME, "deleteLAPropertyDataForEntityTypes",
							"No property extension(LA) entity found for entity types " + var2);
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "deleteLAPropertyDataForEntityTypes");
			}

		}
	}

	public void deleteLAEntity(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteLAEntity", "extId=" + var1 + ", reposId=" + var2);
		}

		Connection var4 = null;
		PreparedStatement var5 = null;

		try {
			var4 = this.getConnection();
			var5 = var4.prepareStatement(this.qs.deleteLAEntity);
			var5.setString(1, var1);
			var5.setString(2, var2);
			int var6 = var5.executeUpdate();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "deleteLAEntity", "deleted=" + var6);
			}
		} catch (SQLException var14) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var14.getMessage()),
					CLASSNAME, "deleteLAEntity", var14);
		} finally {
			try {
				if (var5 != null) {
					var5.close();
				}

				if (var4 != null) {
					this.closeConnection(var4);
				}
			} catch (SQLException var13) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "deleteLAEntity",
							"Unexpected error when closing the prepared statement or the connection : ", var13);
				}
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "deleteLAEntity");
		}

	}

	public void createNewPropertyEntityRelationInDB(String var1, String var2, DBPropertyCache var3)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createNewPropertyEntityRelationInDB(String newEntName, String parentEntName, DBPropertyCache cache)");
		}

		Set var5 = var3.getSupportedAttributes(var2);
		if (var5 != null) {
			Iterator var6 = var5.iterator();
			String var7 = this.qs.createDBPropertyEntity;
			Connection var8 = null;
			PreparedStatement var9 = null;

			try {
				var8 = this.getConnection();

				for (var9 = var8.prepareStatement(var7); var6.hasNext(); var9.addBatch()) {
					String var10 = (String) var6.next();
					DBRepositoryProperty var11 = var3.getPropertyDefinition(var10);
					var9.setInt(1, var11.getPropId());
					var9.setString(2, var1);
					if (var11.getRequiredEntityTypes().contains(var2)) {
						var9.setInt(3, 1);
					} else {
						var9.setInt(3, 0);
					}
				}

				var9.executeBatch();
			} catch (SQLException var19) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var19.getMessage()),
						CLASSNAME,
						"createNewPropertyEntityRelationInDB(String newEntName, String parentEntName, DBPropertyCache cache)",
						var19);
			} finally {
				try {
					this.closeConnection(var8);
					var9.close();
				} catch (Exception var18) {
					;
				}

			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"createNewPropertyEntityRelationInDB(String newEntName, String parentEntName, DBPropertyCache cache)");
		}

	}

	public void createNewPropertyEntityRelationInLA(String var1, String var2, LAPropertyCache var3)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createNewPropertyEntityRelationInLA(String newEntName, String parentEntName, LAPropertyCache cache)");
		}

		Set var5 = var3.getSupportedAttributes(var2);
		if (var5 != null) {
			Iterator var6 = var5.iterator();
			String var7 = this.qs.createLAPropertyEntity;
			Connection var8 = null;
			PreparedStatement var9 = null;

			try {
				var8 = this.getConnection();

				for (var9 = var8.prepareStatement(var7); var6.hasNext(); var9.addBatch()) {
					String var10 = (String) var6.next();
					DBRepositoryProperty var11 = var3.getPropertyDefinition(var10);
					var9.setInt(1, var11.getPropId());
					var9.setString(2, var1);
					if (var11.getRequiredEntityTypes().contains(var2)) {
						var9.setInt(3, 1);
					} else {
						var9.setInt(3, 0);
					}
				}

				var9.executeBatch();
			} catch (SQLException var19) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var19.getMessage()),
						CLASSNAME,
						"createNewPropertyEntityRelationInLA(String newEntName, String parentEntName, LAPropertyCache cache)",
						var19);
			} finally {
				try {
					this.closeConnection(var8);
					var9.close();
				} catch (Exception var18) {
					;
				}

			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"createNewPropertyEntityRelationInLA(String newEntName, String parentEntName, LAPropertyCache cache)");
		}

	}

	protected KeyManager getKeyManager() {
		return this.keyMgr;
	}

	public boolean isMemberInGroup(long var1, String var3, String var4, String var5, int var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"isMemberInGroup(long grpId, String mbrExtId, String reposId, String dbReposId, int level)");
		}

		boolean var8 = false;
		Connection var9 = null;
		PreparedStatement var10 = null;
		String var11 = null;
		ResultSet var12 = null;

		try {
			if (var6 == 1) {
				var11 = this.qs.isMemberinImmediateGroup;
				var9 = this.getConnection();
				var10 = var9.prepareStatement(var11);
				var10.setLong(1, var1);
				var10.setString(2, DAOHelper.getTruncatedExternalId(var3));
				var10.setString(3, var4);
				var12 = var10.executeQuery();
				if (var12.next()) {
					var8 = true;
				}
			} else {
				List var13 = this.getNestedGroupsForEntity(var3, var4, var5, new ArrayList(), (List) null);
				if (var13.contains(new Long(var1))) {
					var8 = true;
				}
			}
		} catch (SQLException var21) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var21.getMessage()),
					CLASSNAME,
					"isMemberInGroup(long grpId, String mbrExtId, String reposId, String dbReposId, int level)", var21);
		} finally {
			try {
				if (var10 != null) {
					var10.close();
				}

				if (var12 != null) {
					var12.close();
				}

				if (var9 != null) {
					this.closeConnection(var9);
				}
			} catch (Exception var20) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"isMemberInGroup(long grpId, String mbrExtId, String reposId, String dbReposId, int level)");
		}

		return var8;
	}

	public void deleteProperties(short var1, long var2, Hashtable[] var4, Set var5, String var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"deleteProperties(short schema, long entId, Hashtable[] propertyToDelete, Set multiValProps, String reposId)");
		}

		Connection var8 = null;
		PreparedStatement var9 = null;

		try {
			for (short var10 = 0; var10 < var4.length; ++var10) {
				if (var4[var10] != null && var4[var10].size() != 0) {
					String var11 = null;
					switch (var10) {
						case 0 :
							if (var1 == 0) {
								var11 = this.qs.deletePropertiesFromDBStringProp;
							} else {
								var11 = this.qs.deletePropertiesFromLAStringProp;
							}
							break;
						case 1 :
							if (var1 == 0) {
								var11 = this.qs.deletePropertiesFromDBLongProp;
							} else {
								var11 = this.qs.deletePropertiesFromLALongProp;
							}
							break;
						case 2 :
							if (var1 == 0) {
								var11 = this.qs.deletePropertiesFromDBDoubleProp;
							} else {
								var11 = this.qs.deletePropertiesFromLADoubleProp;
							}
							break;
						case 3 :
							if (var1 == 0) {
								var11 = this.qs.deletePropertiesFromDBIntegerProp;
							} else {
								var11 = this.qs.deletePropertiesFromLAIntegerProp;
							}
							break;
						case 4 :
							if (var1 == 0) {
								var11 = this.qs.deletePropertiesFromDBTimestampProp;
							} else {
								var11 = this.qs.deletePropertiesFromLATimestampProp;
							}
							break;
						case 5 :
							if (var1 == 0) {
								var11 = this.qs.deletePropertiesFromDBReferenceProp;
							} else {
								var11 = this.qs.deletePropertiesFromLAReferenceProp;
							}
							break;
						case 6 :
							if (var1 == 0) {
								var11 = this.qs.deletePropertiesFromDBBlobProp;
							} else {
								var11 = this.qs.deletePropertiesFromLABlobProp;
							}
					}

					for (short var12 = 0; var12 < var4[var10].size(); ++var12) {
						var11 = var11 + this.qs.PARAM_MARKER;
						if (var12 != var4[var10].size() - 1) {
							var11 = var11 + this.qs.COMMA;
						}
					}

					var11 = var11 + this.qs.RIGHT_BRACKET;
					var11 = var11 + this.qs.AND + this.qs.entityIDEquals;
					if (var8 == null) {
						var8 = this.getConnection();
					}

					int var27 = 1;
					var9 = var8.prepareStatement(var11);
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME,
								"deleteProperties(short schema, long entId, Hashtable[] propertyToDelete, Set multiValProps, String reposId)",
								"The delete sql is " + var11);
					}

					Enumeration var13 = var4[var10].keys();

					while (var13.hasMoreElements()) {
						Integer var14 = (Integer) var13.nextElement();
						var9.setInt(var27++, var14);
					}

					var9.setLong(var27++, var2);
					var9.executeUpdate();
				}
			}
		} catch (SQLException var25) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var25.getMessage()),
					CLASSNAME,
					"deleteProperties(short schema, long entId, Hashtable[] propertyToDelete, Set multiValProps, String reposId)",
					var25);
		} finally {
			try {
				this.closeConnection(var8);
			} catch (Exception var24) {
				;
			}

			try {
				var9.close();
			} catch (Exception var23) {
				;
			}

		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"deleteProperties(short schema, long entId, Hashtable[] propertyToDelete, Set multiValProps, String reposId)");
		}

	}

	public void setUseTriggerForIdInLARepo(boolean var1) throws WIMException {
		this.isUseTriggerForIdInLARepo = var1;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = AbstractDAO.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}