package com.ibm.icu.impl;

import com.ibm.icu.impl.ZoneMeta.OlsonToMetaMappingEntry;
import com.ibm.icu.impl.ZoneStringFormat.1;
import com.ibm.icu.impl.ZoneStringFormat.ZoneStringInfo;
import com.ibm.icu.impl.ZoneStringFormat.ZoneStringSearchResultHandler;
import com.ibm.icu.impl.ZoneStringFormat.ZoneStrings;
import com.ibm.icu.text.MessageFormat;
import com.ibm.icu.util.BasicTimeZone;
import com.ibm.icu.util.Calendar;
import com.ibm.icu.util.TimeZone;
import com.ibm.icu.util.TimeZoneTransition;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.Set;

public class ZoneStringFormat {
	private static final int LOCATION = 1;
	private static final int GENERIC_LONG = 2;
	private static final int GENERIC_SHORT = 4;
	private static final int STANDARD_LONG = 8;
	private static final int STANDARD_SHORT = 16;
	private static final int DAYLIGHT_LONG = 32;
	private static final int DAYLIGHT_SHORT = 64;
	private static final int ZSIDX_LOCATION = 0;
	private static final int ZSIDX_LONG_STANDARD = 1;
	private static final int ZSIDX_SHORT_STANDARD = 2;
	private static final int ZSIDX_LONG_DAYLIGHT = 3;
	private static final int ZSIDX_SHORT_DAYLIGHT = 4;
	private static final int ZSIDX_LONG_GENERIC = 5;
	private static final int ZSIDX_SHORT_GENERIC = 6;
	private static final int ZSIDX_MAX = 7;
	private static ICUCache<ULocale, ZoneStringFormat> TZFORMAT_CACHE = new SimpleCache();
	private static final String RESKEY_SHORT_GENERIC = "sg";
	private static final String RESKEY_SHORT_STANDARD = "ss";
	private static final String RESKEY_SHORT_DAYLIGHT = "sd";
	private static final String RESKEY_LONG_GENERIC = "lg";
	private static final String RESKEY_LONG_STANDARD = "ls";
	private static final String RESKEY_LONG_DAYLIGHT = "ld";
	private static final String RESKEY_EXEMPLAR_CITY = "ec";
	private static final String RESKEY_COMMONLY_USED = "cu";
	private static final long DST_CHECK_RANGE = 15897600000L;
	private Map<String, ZoneStrings> tzidToStrings;
	private Map<String, ZoneStrings> mzidToStrings;
	private TextTrieMap<ZoneStringInfo> zoneStringsTrie;
	private ULocale locale;
	private transient String region;
	private boolean isFullyLoaded = false;
	private static final int[] INDEXMAP = new int[]{-1, 1, 2, 3, 4, 0, 5, 6};
	private static final int[] NAMETYPEMAP = new int[]{1, 8, 16, 32, 64, 2, 4};

	public ZoneStringFormat(String[][] zoneStrings) {
      this.tzidToStrings = new HashMap();
      this.zoneStringsTrie = new TextTrieMap(true);

      for(int i = 0; i < zoneStrings.length; ++i) {
         String tzid = zoneStrings[i][0];
         String[] names = new String[7];

         for(int j = 1; j < zoneStrings[i].length; ++j) {
            if (zoneStrings[i][j] != null) {
               int typeIdx = getNameTypeIndex(j);
               if (typeIdx != -1) {
                  names[typeIdx] = zoneStrings[i][j];
                  int type = getNameType(typeIdx);
                  ZoneStringInfo zsinfo = new ZoneStringInfo(tzid, zoneStrings[i][j], type, (1)null);
                  this.zoneStringsTrie.put(zoneStrings[i][j], zsinfo);
               }
            }
         }

         ZoneStrings zstrings = new ZoneStrings(names, true, (String[][])null, (1)null);
         this.tzidToStrings.put(tzid, zstrings);
      }

      this.isFullyLoaded = true;
   }

	public static ZoneStringFormat getInstance(ULocale locale) {
		ZoneStringFormat tzf = (ZoneStringFormat) TZFORMAT_CACHE.get(locale);
		if (tzf == null) {
			tzf = new ZoneStringFormat(locale);
			TZFORMAT_CACHE.put(locale, tzf);
		}

		return tzf;
	}

	public String[][] getZoneStrings() {
		return this.getZoneStrings(System.currentTimeMillis());
	}

	public String getSpecificLongString(Calendar cal) {
		return cal.get(16) == 0
				? this.getString(cal.getTimeZone().getID(), 1, cal.getTimeInMillis(), false)
				: this.getString(cal.getTimeZone().getID(), 3, cal.getTimeInMillis(), false);
	}

	public String getSpecificShortString(Calendar cal, boolean commonlyUsedOnly) {
		return cal.get(16) == 0
				? this.getString(cal.getTimeZone().getID(), 2, cal.getTimeInMillis(), commonlyUsedOnly)
				: this.getString(cal.getTimeZone().getID(), 4, cal.getTimeInMillis(), commonlyUsedOnly);
	}

	public String getGenericLongString(Calendar cal) {
		return this.getGenericString(cal, false, false);
	}

	public String getGenericShortString(Calendar cal, boolean commonlyUsedOnly) {
		return this.getGenericString(cal, true, commonlyUsedOnly);
	}

	public String getGenericLocationString(Calendar cal) {
		return this.getString(cal.getTimeZone().getID(), 0, cal.getTimeInMillis(), false);
	}

	public ZoneStringInfo findSpecificLong(String text, int start) {
		return this.find(text, start, 40);
	}

	public ZoneStringInfo findSpecificShort(String text, int start) {
		return this.find(text, start, 80);
	}

	public ZoneStringInfo findGenericLong(String text, int start) {
		return this.find(text, start, 11);
	}

	public ZoneStringInfo findGenericShort(String text, int start) {
		return this.find(text, start, 21);
	}

	public ZoneStringInfo findGenericLocation(String text, int start) {
		return this.find(text, start, 1);
	}

	public String getLongStandard(String tzid, long date) {
		return this.getString(tzid, 1, date, false);
	}

	public String getLongDaylight(String tzid, long date) {
		return this.getString(tzid, 3, date, false);
	}

	public String getLongGenericNonLocation(String tzid, long date) {
		return this.getString(tzid, 5, date, false);
	}

	public String getLongGenericPartialLocation(String tzid, long date) {
		return this.getGenericPartialLocationString(tzid, false, date, false);
	}

	public String getShortStandard(String tzid, long date, boolean commonlyUsedOnly) {
		return this.getString(tzid, 2, date, commonlyUsedOnly);
	}

	public String getShortDaylight(String tzid, long date, boolean commonlyUsedOnly) {
		return this.getString(tzid, 4, date, commonlyUsedOnly);
	}

	public String getShortGenericNonLocation(String tzid, long date, boolean commonlyUsedOnly) {
		return this.getString(tzid, 6, date, commonlyUsedOnly);
	}

	public String getShortGenericPartialLocation(String tzid, long date, boolean commonlyUsedOnly) {
		return this.getGenericPartialLocationString(tzid, true, date, commonlyUsedOnly);
	}

	public String getGenericLocation(String tzid) {
		return this.getString(tzid, 0, 0L, false);
	}

	protected ZoneStringFormat(ULocale locale) {
		this.locale = locale;
		this.tzidToStrings = new HashMap();
		this.mzidToStrings = new HashMap();
		this.zoneStringsTrie = new TextTrieMap(true);
	}

	private synchronized void loadZone(String id) {
		if (!this.isFullyLoaded) {
			String tzid = ZoneMeta.getCanonicalSystemID(id);
			if (tzid != null && !this.tzidToStrings.containsKey(tzid)) {
				ICUResourceBundle zoneStringsBundle = null;

				try {
					ICUResourceBundle bundle = (ICUResourceBundle) UResourceBundle
							.getBundleInstance("com/ibm/icu/impl/data/icudt44b/zone", this.locale);
					zoneStringsBundle = bundle.getWithFallback("zoneStrings");
				} catch (MissingResourceException var7) {
					;
				}

				String[] zstrarray = new String[7];
				String[] mzstrarray = new String[7];
				String[][] mzPartialLoc = new String[10][4];
				this.addSingleZone(tzid, zoneStringsBundle, getFallbackFormat(this.locale),
						getRegionFormat(this.locale), zstrarray, mzstrarray, mzPartialLoc);
			}
		}
	}

	private synchronized void loadFull() {
		if (!this.isFullyLoaded) {
			ICUResourceBundle zoneStringsBundle = null;

			try {
				ICUResourceBundle bundle = (ICUResourceBundle) UResourceBundle
						.getBundleInstance("com/ibm/icu/impl/data/icudt44b/zone", this.locale);
				zoneStringsBundle = bundle.getWithFallback("zoneStrings");
			} catch (MissingResourceException var8) {
				;
			}

			String[] zoneIDs = TimeZone.getAvailableIDs();
			String[] zstrarray = new String[7];
			String[] mzstrarray = new String[7];
			String[][] mzPartialLoc = new String[10][4];

			for (int i = 0; i < zoneIDs.length; ++i) {
				String tzid = ZoneMeta.getCanonicalSystemID(zoneIDs[i]);
				if (tzid != null && zoneIDs[i].equals(tzid) && !this.tzidToStrings.containsKey(tzid)) {
					this.addSingleZone(tzid, zoneStringsBundle, getFallbackFormat(this.locale),
							getRegionFormat(this.locale), zstrarray, mzstrarray, mzPartialLoc);
				}
			}

			this.isFullyLoaded = true;
		}
	}

	private void addSingleZone(String tzid, ICUResourceBundle zoneStringsBundle, MessageFormat fallbackFmt, MessageFormat regionFmt, String[] zstrarray, String[] mzstrarray, String[][] mzPartialLoc) {
      if (!this.tzidToStrings.containsKey(tzid)) {
         String zoneKey = tzid.replace('/', ':');
         zstrarray[1] = getZoneStringFromBundle(zoneStringsBundle, zoneKey, "ls");
         zstrarray[2] = getZoneStringFromBundle(zoneStringsBundle, zoneKey, "ss");
         zstrarray[3] = getZoneStringFromBundle(zoneStringsBundle, zoneKey, "ld");
         zstrarray[4] = getZoneStringFromBundle(zoneStringsBundle, zoneKey, "sd");
         zstrarray[5] = getZoneStringFromBundle(zoneStringsBundle, zoneKey, "lg");
         zstrarray[6] = getZoneStringFromBundle(zoneStringsBundle, zoneKey, "sg");
         String countryCode = ZoneMeta.getCanonicalCountry(tzid);
         String country = null;
         String city = null;
         int mzPartialLocIdx;
         if (countryCode != null) {
            city = getZoneStringFromBundle(zoneStringsBundle, zoneKey, "ec");
            if (city == null) {
               city = tzid.substring(tzid.lastIndexOf(47) + 1).replace('_', ' ');
            }

            country = getLocalizedCountry(countryCode, this.locale);
            if (ZoneMeta.getSingleCountry(tzid) != null) {
               zstrarray[0] = regionFmt.format(new Object[]{country});
            } else {
               zstrarray[0] = fallbackFmt.format(new Object[]{city, country});
            }
         } else if (tzid.startsWith("Etc/")) {
            zstrarray[0] = null;
         } else {
            mzPartialLocIdx = tzid.lastIndexOf(47);
            if (mzPartialLocIdx == -1) {
               zstrarray[0] = null;
            } else {
               String location = tzid.substring(mzPartialLocIdx + 1);
               zstrarray[0] = regionFmt.format(new Object[]{location});
            }
         }

         boolean commonlyUsed = isCommonlyUsed(zoneStringsBundle, zoneKey);
         mzPartialLocIdx = 0;
         List<OlsonToMetaMappingEntry> metazoneMappings = ZoneMeta.getOlsonToMatazones(tzid);
         if (metazoneMappings != null) {
            Iterator it = metazoneMappings.iterator();

            label133:
            while(true) {
               OlsonToMetaMappingEntry mzmap;
               ZoneStrings mzStrings;
               String lg;
               int j;
               String sg;
               do {
                  if (!it.hasNext()) {
                     break label133;
                  }

                  mzmap = (OlsonToMetaMappingEntry)it.next();
                  mzStrings = (ZoneStrings)this.mzidToStrings.get(mzmap.mzid);
                  if (mzStrings == null) {
                     lg = "meta:" + mzmap.mzid;
                     boolean mzCommonlyUsed = isCommonlyUsed(zoneStringsBundle, lg);
                     mzstrarray[1] = getZoneStringFromBundle(zoneStringsBundle, lg, "ls");
                     mzstrarray[2] = getZoneStringFromBundle(zoneStringsBundle, lg, "ss");
                     mzstrarray[3] = getZoneStringFromBundle(zoneStringsBundle, lg, "ld");
                     mzstrarray[4] = getZoneStringFromBundle(zoneStringsBundle, lg, "sd");
                     mzstrarray[5] = getZoneStringFromBundle(zoneStringsBundle, lg, "lg");
                     mzstrarray[6] = getZoneStringFromBundle(zoneStringsBundle, lg, "sg");
                     mzstrarray[0] = null;
                     mzStrings = new ZoneStrings(mzstrarray, mzCommonlyUsed, (String[][])null, (1)null);
                     this.mzidToStrings.put(mzmap.mzid, mzStrings);
                     String preferredIdForLocale = ZoneMeta.getZoneIdByMetazone(mzmap.mzid, this.getRegion());

                     for(j = 0; j < mzstrarray.length; ++j) {
                        if (mzstrarray[j] != null) {
                           int type = getNameType(j);
                           ZoneStringInfo zsinfo = new ZoneStringInfo(preferredIdForLocale, mzstrarray[j], type, (1)null);
                           this.zoneStringsTrie.put(mzstrarray[j], zsinfo);
                        }
                     }
                  }

                  lg = ZoneStrings.access$200(mzStrings, 5);
                  sg = ZoneStrings.access$200(mzStrings, 6);
               } while(lg == null && sg == null);

               boolean addMzPartialLocationNames = true;

               for(j = 0; j < mzPartialLocIdx; ++j) {
                  if (mzPartialLoc[j][0].equals(mzmap.mzid)) {
                     addMzPartialLocationNames = false;
                     break;
                  }
               }

               if (addMzPartialLocationNames) {
                  String locationPart = null;
                  String preferredID = ZoneMeta.getZoneIdByMetazone(mzmap.mzid, countryCode);
                  if (tzid.equals(preferredID)) {
                     locationPart = country;
                  } else {
                     locationPart = city;
                  }

                  mzPartialLoc[mzPartialLocIdx][0] = mzmap.mzid;
                  mzPartialLoc[mzPartialLocIdx][1] = null;
                  mzPartialLoc[mzPartialLocIdx][2] = null;
                  mzPartialLoc[mzPartialLocIdx][3] = null;
                  if (locationPart != null) {
                     if (lg != null) {
                        mzPartialLoc[mzPartialLocIdx][1] = fallbackFmt.format(new Object[]{locationPart, lg});
                     }

                     if (sg != null) {
                        mzPartialLoc[mzPartialLocIdx][2] = fallbackFmt.format(new Object[]{locationPart, sg});
                        boolean shortMzCommonlyUsed = ZoneStrings.access$300(mzStrings);
                        if (shortMzCommonlyUsed) {
                           mzPartialLoc[mzPartialLocIdx][3] = "1";
                        }
                     }
                  }

                  ++mzPartialLocIdx;
               }
            }
         }

         String[][] genericPartialLocationNames = (String[][])null;
         if (mzPartialLocIdx != 0) {
            genericPartialLocationNames = new String[mzPartialLocIdx][];

            for(int mzi = 0; mzi < mzPartialLocIdx; ++mzi) {
               genericPartialLocationNames[mzi] = (String[])mzPartialLoc[mzi].clone();
            }
         }

         ZoneStrings zstrings = new ZoneStrings(zstrarray, commonlyUsed, genericPartialLocationNames, (1)null);
         this.tzidToStrings.put(tzid, zstrings);
         int j;
         if (zstrarray != null) {
            for(j = 0; j < zstrarray.length; ++j) {
               if (zstrarray[j] != null) {
                  int type = getNameType(j);
                  ZoneStringInfo zsinfo = new ZoneStringInfo(tzid, zstrarray[j], type, (1)null);
                  this.zoneStringsTrie.put(zstrarray[j], zsinfo);
               }
            }
         }

         if (genericPartialLocationNames != null) {
            for(j = 0; j < genericPartialLocationNames.length; ++j) {
               ZoneStringInfo zsinfo;
               if (genericPartialLocationNames[j][1] != null) {
                  zsinfo = new ZoneStringInfo(tzid, genericPartialLocationNames[j][1], 2, (1)null);
                  this.zoneStringsTrie.put(genericPartialLocationNames[j][1], zsinfo);
               }

               if (genericPartialLocationNames[j][2] != null) {
                  zsinfo = new ZoneStringInfo(tzid, genericPartialLocationNames[j][1], 4, (1)null);
                  this.zoneStringsTrie.put(genericPartialLocationNames[j][2], zsinfo);
               }
            }
         }

      }
   }

	private String getString(String tzid, int typeIdx, long date, boolean commonlyUsedOnly) {
		if (!this.isFullyLoaded) {
			this.loadZone(tzid);
		}

		String result = null;
		ZoneStrings zstrings = (ZoneStrings) this.tzidToStrings.get(tzid);
		String mzid;
		if (zstrings == null) {
			mzid = ZoneMeta.getCanonicalSystemID(tzid);
			if (mzid != null && !mzid.equals(tzid)) {
				tzid = mzid;
				zstrings = (ZoneStrings) this.tzidToStrings.get(mzid);
			}
		}

		if (zstrings != null) {
			switch (typeIdx) {
				case 0 :
				case 1 :
				case 3 :
				case 5 :
					result = ZoneStrings.access$200(zstrings, typeIdx);
					break;
				case 2 :
				case 4 :
				case 6 :
					if (!commonlyUsedOnly || ZoneStrings.access$300(zstrings)) {
						result = ZoneStrings.access$200(zstrings, typeIdx);
					}
			}
		}

		if (result == null && this.mzidToStrings != null && typeIdx != 0) {
			mzid = ZoneMeta.getMetazoneID(tzid, date);
			if (mzid != null) {
				ZoneStrings mzstrings = (ZoneStrings) this.mzidToStrings.get(mzid);
				if (mzstrings != null) {
					switch (typeIdx) {
						case 1 :
						case 3 :
						case 5 :
							result = ZoneStrings.access$200(mzstrings, typeIdx);
							break;
						case 2 :
						case 4 :
						case 6 :
							if (!commonlyUsedOnly || ZoneStrings.access$300(mzstrings)) {
								result = ZoneStrings.access$200(mzstrings, typeIdx);
							}
					}
				}
			}
		}

		return result;
	}

	private String getGenericString(Calendar cal, boolean isShort, boolean commonlyUsedOnly) {
		String result = null;
		TimeZone tz = cal.getTimeZone();
		String tzid = tz.getID();
		if (!this.isFullyLoaded) {
			this.loadZone(tzid);
		}

		ZoneStrings zstrings = (ZoneStrings) this.tzidToStrings.get(tzid);
		if (zstrings == null) {
			String canonicalID = ZoneMeta.getCanonicalSystemID(tzid);
			if (canonicalID != null && !canonicalID.equals(tzid)) {
				tzid = canonicalID;
				zstrings = (ZoneStrings) this.tzidToStrings.get(canonicalID);
			}
		}

		if (zstrings != null) {
			if (isShort) {
				if (!commonlyUsedOnly || ZoneStrings.access$300(zstrings)) {
					result = ZoneStrings.access$200(zstrings, 6);
				}
			} else {
				result = ZoneStrings.access$200(zstrings, 5);
			}
		}

		if (result == null && this.mzidToStrings != null) {
			long time = cal.getTimeInMillis();
			String mzid = ZoneMeta.getMetazoneID(tzid, time);
			if (mzid != null) {
				boolean useStandard = false;
				if (cal.get(16) == 0) {
					useStandard = true;
					if (tz instanceof BasicTimeZone) {
						BasicTimeZone btz = (BasicTimeZone) tz;
						TimeZoneTransition before = btz.getPreviousTransition(time, true);
						if (before != null && time - before.getTime() < 15897600000L
								&& before.getFrom().getDSTSavings() != 0) {
							useStandard = false;
						} else {
							TimeZoneTransition after = btz.getNextTransition(time, false);
							if (after != null && after.getTime() - time < 15897600000L
									&& after.getTo().getDSTSavings() != 0) {
								useStandard = false;
							}
						}
					} else {
						int[] offsets = new int[2];
						tz.getOffset(time - 15897600000L, false, offsets);
						if (offsets[1] != 0) {
							useStandard = false;
						} else {
							tz.getOffset(time + 15897600000L, false, offsets);
							if (offsets[1] != 0) {
								useStandard = false;
							}
						}
					}
				}

				if (useStandard) {
					result = this.getString(tzid, isShort ? 2 : 1, time, commonlyUsedOnly);
					if (result != null) {
						String genericNonLocation = this.getString(tzid, isShort ? 6 : 5, time, commonlyUsedOnly);
						if (genericNonLocation != null && result.equalsIgnoreCase(genericNonLocation)) {
							result = null;
						}
					}
				}

				if (result == null) {
					ZoneStrings mzstrings = (ZoneStrings) this.mzidToStrings.get(mzid);
					if (mzstrings != null) {
						if (isShort) {
							if (!commonlyUsedOnly || ZoneStrings.access$300(mzstrings)) {
								result = ZoneStrings.access$200(mzstrings, 6);
							}
						} else {
							result = ZoneStrings.access$200(mzstrings, 5);
						}
					}

					if (result != null) {
						String preferredId = ZoneMeta.getZoneIdByMetazone(mzid, this.getRegion());
						if (!tzid.equals(preferredId)) {
							int raw = cal.get(15);
							int sav = cal.get(16);
							TimeZone preferredZone = TimeZone.getTimeZone(preferredId);
							int[] preferredOffsets = new int[2];
							preferredZone.getOffset(time + (long) raw + (long) sav, true, preferredOffsets);
							if (raw != preferredOffsets[0] || sav != preferredOffsets[1]) {
								result = ZoneStrings.access$400(zstrings, mzid, isShort, commonlyUsedOnly);
							}
						}
					}
				}
			}
		}

		if (result == null) {
			result = this.getString(tzid, 0, cal.getTimeInMillis(), false);
		}

		return result;
	}

	private String getGenericPartialLocationString(String tzid, boolean isShort, long date, boolean commonlyUsedOnly) {
		if (!this.isFullyLoaded) {
			this.loadZone(tzid);
		}

		String result = null;
		String mzid = ZoneMeta.getMetazoneID(tzid, date);
		if (mzid != null) {
			ZoneStrings zstrings = (ZoneStrings) this.tzidToStrings.get(tzid);
			if (zstrings != null) {
				result = ZoneStrings.access$400(zstrings, mzid, isShort, commonlyUsedOnly);
			}
		}

		return result;
	}

	private String[][] getZoneStrings(long date) {
		this.loadFull();
		Set<String> tzids = this.tzidToStrings.keySet();
		String[][] zoneStrings = new String[tzids.size()][8];
		int idx = 0;

		for (Iterator i$ = tzids.iterator(); i$.hasNext(); ++idx) {
			String tzid = (String) i$.next();
			zoneStrings[idx][0] = tzid;
			zoneStrings[idx][1] = this.getLongStandard(tzid, date);
			zoneStrings[idx][2] = this.getShortStandard(tzid, date, false);
			zoneStrings[idx][3] = this.getLongDaylight(tzid, date);
			zoneStrings[idx][4] = this.getShortDaylight(tzid, date, false);
			zoneStrings[idx][5] = this.getGenericLocation(tzid);
			zoneStrings[idx][6] = this.getLongGenericNonLocation(tzid, date);
			zoneStrings[idx][7] = this.getShortGenericNonLocation(tzid, date, false);
		}

		return zoneStrings;
	}

	private static String getZoneStringFromBundle(ICUResourceBundle bundle, String key, String type) {
		String zstring = null;
		if (bundle != null) {
			try {
				zstring = bundle.getStringWithFallback(key + "/" + type);
			} catch (MissingResourceException var5) {
				;
			}
		}

		return zstring;
	}

	private static boolean isCommonlyUsed(ICUResourceBundle bundle, String key) {
		boolean commonlyUsed = false;
		if (bundle != null) {
			try {
				UResourceBundle cuRes = bundle.getWithFallback(key + "/" + "cu");
				int cuValue = cuRes.getInt();
				commonlyUsed = cuValue != 0;
			} catch (MissingResourceException var5) {
				;
			}
		}

		return commonlyUsed;
	}

	private static String getLocalizedCountry(String countryCode, ULocale locale) {
		String countryStr = null;
		if (countryCode != null) {
			ICUResourceBundle rb = (ICUResourceBundle) UResourceBundle
					.getBundleInstance("com/ibm/icu/impl/data/icudt44b/region", locale);
			ULocale rbloc = rb.getULocale();
			if (!rbloc.equals(ULocale.ROOT) && rbloc.getLanguage().equals(locale.getLanguage())) {
				countryStr = ULocale.getDisplayCountry("xx_" + countryCode, locale);
			}

			if (countryStr == null || countryStr.length() == 0) {
				countryStr = countryCode;
			}
		}

		return countryStr;
	}

	private static MessageFormat getFallbackFormat(ULocale locale) {
		String fallbackPattern = ZoneMeta.getTZLocalizationInfo(locale, "fallbackFormat");
		if (fallbackPattern == null) {
			fallbackPattern = "{1} ({0})";
		}

		return new MessageFormat(fallbackPattern, locale);
	}

	private static MessageFormat getRegionFormat(ULocale locale) {
		String regionPattern = ZoneMeta.getTZLocalizationInfo(locale, "regionFormat");
		if (regionPattern == null) {
			regionPattern = "{0}";
		}

		return new MessageFormat(regionPattern, locale);
	}

	private static int getNameTypeIndex(int i) {
		int idx = -1;
		if (i >= 1 && i < INDEXMAP.length) {
			idx = INDEXMAP[i];
		}

		return idx;
	}

	private static int getNameType(int typeIdx) {
		int type = -1;
		if (typeIdx >= 0 && typeIdx < NAMETYPEMAP.length) {
			type = NAMETYPEMAP[typeIdx];
		}

		return type;
	}

	private String getRegion() {
		if (this.region == null) {
			if (this.locale != null) {
				this.region = this.locale.getCountry();
				if (this.region.length() == 0) {
					ULocale tmp = ULocale.addLikelySubtags(this.locale);
					this.region = tmp.getCountry();
				}
			} else {
				this.region = "";
			}
		}

		return this.region;
	}

	private ZoneStringInfo find(String text, int start, int types) {
		ZoneStringInfo result = this.subFind(text, start, types);
		if (this.isFullyLoaded) {
			return result;
		} else {
			if (result != null) {
				int matchLen = result.getString().length();
				if (text.length() - start == matchLen) {
					return result;
				}
			}

			this.loadFull();
			return this.subFind(text, start, types);
		}
	}

	private ZoneStringInfo subFind(String text, int start, int types) {
      ZoneStringInfo result = null;
      ZoneStringSearchResultHandler handler = new ZoneStringSearchResultHandler((1)null);
      this.zoneStringsTrie.find(text, start, handler);
      List<ZoneStringInfo> list = handler.getMatchedZoneStrings();
      ZoneStringInfo fallback = null;
      if (list != null && list.size() > 0) {
         Iterator it = list.iterator();

         label57:
         while(true) {
            while(true) {
               while(true) {
                  if (!it.hasNext()) {
                     break label57;
                  }

                  ZoneStringInfo tmp = (ZoneStringInfo)it.next();
                  if ((types & ZoneStringInfo.access$600(tmp)) != 0) {
                     if (result != null && result.getString().length() >= tmp.getString().length()) {
                        if (result.getString().length() == tmp.getString().length() && tmp.isGeneric() && !result.isGeneric()) {
                           result = tmp;
                        }
                     } else {
                        result = tmp;
                     }
                  } else if (result == null) {
                     if (fallback != null && fallback.getString().length() >= tmp.getString().length()) {
                        if (fallback.getString().length() == tmp.getString().length() && tmp.isGeneric() && !fallback.isGeneric()) {
                           fallback = tmp;
                        }
                     } else {
                        fallback = tmp;
                     }
                  }
               }
            }
         }
      }

      if (result == null && fallback != null) {
         result = fallback;
      }

      return result;
   }
}