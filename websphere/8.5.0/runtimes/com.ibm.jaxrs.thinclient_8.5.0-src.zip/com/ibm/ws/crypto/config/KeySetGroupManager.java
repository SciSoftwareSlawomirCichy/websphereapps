package com.ibm.ws.crypto.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.websphere.crypto.KeyException;
import com.ibm.websphere.models.config.ipc.ssl.KeySetGroup;
import com.ibm.websphere.models.config.security.Security;
import com.ibm.ws.security.config.SecurityConfigObject;
import com.ibm.ws.security.config.SecurityConfigObjectList;
import com.ibm.ws.ssl.config.AdminContextHelper;
import com.ibm.ws.ssl.config.ManagementScopeManager;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class KeySetGroupManager {
	private static final TraceComponent tc = Tr.register(KeySetGroupManager.class, "SSL",
			"com.ibm.ws.ssl.resources.ssl");
	private static ConcurrentHashMap<String, KeySetGroupManager> instanceCache = new ConcurrentHashMap();
	private static Object lockObject = new Object();
	private HashMap keySetGroupMap = null;
	private boolean isInitialized = false;

	private KeySetGroupManager() {
		this.keySetGroupMap = new HashMap();
	}

	public static KeySetGroupManager getInstance() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance");
		}

		String uuid = AdminContextHelper.peekAdminContext();
		if (uuid == null) {
			uuid = "admin";
		}

		KeySetGroupManager instance = (KeySetGroupManager) instanceCache.get(uuid);
		if (instance == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "getInstance did not find KeySetGroupManager in the cache");
			}

			Object var2 = lockObject;
			synchronized (lockObject) {
				instance = (KeySetGroupManager) instanceCache.get(uuid);
				if (instance == null) {
					instance = new KeySetGroupManager();
					if (instance != null) {
						instanceCache.put(uuid, instance);
					}
				}
			}
		} else if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getInstance found KeySetGroupManager in the cache");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance", instance);
		}

		return instance;
	}

	public static void releaseInstance() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "releaseInstance");
		}

		String uuid = AdminContextHelper.peekAdminContext();
		if (uuid == null) {
			uuid = "admin";
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "releaseInstance using uuid " + uuid);
		}

		instanceCache.remove(uuid);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "releaseInstance");
		}

	}

	public void initializeKeySetGroups(Security security, boolean reinitialize) throws KeyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeKeySetGroups");
		}

		try {
			if (reinitialize) {
				this.keySetGroupMap.clear();
			}

			KeySetManager.getInstance().initializeKeySets(security, reinitialize);
			List keySetGroupList = security.getKeySetGroups();
			if (keySetGroupList != null && keySetGroupList.size() > 0) {
				for (int i = 0; i < keySetGroupList.size(); ++i) {
					KeySetGroup ksg = (KeySetGroup) keySetGroupList.get(i);
					if (ksg != null) {
						String scope = ksg.getManagementScope().getScopeName();
						if (scope != null && !ManagementScopeManager.getInstance().currentScopeContained(scope)) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Skipping keyset group name \"" + ksg.getName() + "\" having scope \""
										+ scope + "\".");
							}
						} else {
							WSKeySetGroup ksetgroup = new WSKeySetGroup(ksg);
							if (ksetgroup != null) {
								this.keySetGroupMap.put(ksg.getName(), ksetgroup);
							}
						}
					}
				}
			}
		} catch (Exception var8) {
			Tr.debug(tc, "Exception initializing KeySetGroups.", new Object[]{var8});
			Manager.Ffdc.log(var8, this, "com.ibm.ws.crypto.config.KeySetGroupManager.initializeKeySetGroups", "111",
					new Object[]{this});
			throw new KeyException(var8);
		}

		this.isInitialized = true;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initializeKeySetGroups");
		}

	}

	public void initializeKeySetGroups(SecurityConfigObject security, boolean reinitialize) throws KeyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeKeySetGroups " + reinitialize);
		}

		try {
			if (reinitialize) {
				this.keySetGroupMap.clear();
			}

			KeySetManager.getInstance().initializeKeySets(security, reinitialize);
			SecurityConfigObjectList keySetGroupList = security.getObjectList("keySetGroups");
			if (keySetGroupList != null && keySetGroupList.size() > 0) {
				for (int i = 0; i < keySetGroupList.size(); ++i) {
					SecurityConfigObject ksg = keySetGroupList.get(i);
					if (ksg != null) {
						String scope = ksg.getObject("managementScope").getString("scopeName");
						if (scope != null && !ManagementScopeManager.getInstance().currentScopeContained(scope)) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Skipping keyset group name \"" + ksg.getString("name")
										+ "\" having scope \"" + scope + "\".");
							}
						} else {
							WSKeySetGroup ksetgroup = new WSKeySetGroup(ksg);
							if (ksetgroup != null) {
								this.keySetGroupMap.put(ksg.getString("name"), ksetgroup);
							}
						}
					}
				}
			}
		} catch (Exception var8) {
			Tr.debug(tc, "Exception initializing KeySetGroups.", new Object[]{var8});
			Manager.Ffdc.log(var8, this, "com.ibm.ws.crypto.config.KeySetGroupManager.initializeKeySetGroups", "168",
					new Object[]{this});
			throw new KeyException(var8);
		}

		this.isInitialized = true;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initializeKeySetGroups");
		}

	}

	public WSKeySetGroup getKeySetGroup(String name) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getKeySetGroup -> " + name);
		}

		boolean found = false;
		WSKeySetGroup wsksgroup = (WSKeySetGroup) this.keySetGroupMap.get(name);
		if (wsksgroup != null) {
			found = true;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getKeySetGroup -> " + found);
		}

		return wsksgroup;
	}

	public boolean isInitialized() {
		return this.isInitialized;
	}
}