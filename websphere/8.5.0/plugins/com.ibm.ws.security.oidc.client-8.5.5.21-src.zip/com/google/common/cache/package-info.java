package com.google.common.cache;

import javax.annotation.ParametersAreNonnullByDefault;

// $FF: synthetic class
@ParametersAreNonnullByDefault
interface package-info {
}