package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerAS;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;
import javax.ejb.DuplicateKeyException;
import javax.transaction.InvalidTransactionException;
import javax.transaction.TransactionRolledbackException;

public class EntitySessionalTranActivationStrategy extends ActivationStrategy {
	private ActivationStrategy noneSessionalActivationStrategy = null;
	private static final TraceComponent tc = Tr.register(EntitySessionalTranActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.activator.EntitySessionalTransactionalActivationStrategy";

	public EntitySessionalTranActivationStrategy(Activator activator) {
		super(activator);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.noneSessionalActivationStrategy = activator.getActivationStrategy(6);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	BeanO atActivate(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atActivate (" + beanId + ")", tx);
		}

		BeanO beanO = null;
		ContainerAS as = tx.getContainerAS();
		if (as == null) {
			beanO = this.noneSessionalActivationStrategy.atActivate(threadData, tx, beanId);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atActivate");
			}

			return beanO;
		} else {
			boolean exception = false;
			boolean activate = false;
			boolean enlist = false;
			boolean enlistIntoAS = false;
			SessionKey skey = null;
			boolean pushedCallbackBeanO = false;

			try {
				skey = new SessionKey(as, beanId);
				synchronized (this.locks.getLock(skey)) {
					if ((beanO = (BeanO) this.cache.find(skey)) == null) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "Bean not found in cache with activity session key");
						}

						beanO = beanId.getHome().createBeanO(threadData, tx, beanId);
						pushedCallbackBeanO = true;
						this.cache.insert(skey, beanO);
						beanO.ivCacheKey = skey;
						enlistIntoAS = true;
						activate = true;
						enlist = true;
					} else {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "Bean found in cache with activity session key");
						}

						this.cache.unpin(skey);
						threadData.pushCallbackBeanO(beanO);
						pushedCallbackBeanO = true;
						ContainerTx prevTx = beanO.getContainerTx();
						if (prevTx == null) {
							enlist = true;
						} else if (prevTx != tx) {
							String name = threadData.getMethodContext().getEJBMethodInfoImpl().getName();
							if (!name.startsWith("find")) {
								Tr.error(tc, "SESSIONAL_CONCURRENT_TRANSACTION_ERROR_CNTR0064E",
										beanId.getJ2EEName().toString());
								throw new InvalidTransactionException(
										"EJB attempted to become involved with concurrent transactions within an activity session");
							}
						}
					}
				}

				if (activate) {
					beanO.activate(beanId, tx);
				}

				if (enlist) {
					beanO.enlist(tx);
				}

				if (enlistIntoAS) {
					as.enlist(beanO);
				}
			} catch (RemoteException var22) {
				FFDCFilter.processException(var22,
						"com.ibm.ejs.container.activator.EntitySessionalTransactionalActivationStrategy.atActivate",
						"148", this);
				Tr.debug(tc, "Exception while activating bean", var22);
				exception = true;
				throw var22;
			} catch (RuntimeException var23) {
				FFDCFilter.processException(var23,
						"com.ibm.ejs.container.activator.EntitySessionalTransactionalActivationStrategy.atActivate",
						"155", this);
				Tr.debug(tc, "Exception while activating bean", var23);
				exception = true;
				throw var23;
			} finally {
				if (exception && beanO != null) {
					if (pushedCallbackBeanO) {
						threadData.popCallbackBeanO();
					}

					beanO.destroy();
					if (activate) {
						this.cache.remove(skey, true);
						beanO.ivCacheKey = null;
					}

					if (enlistIntoAS) {
						as.delist(beanO);
					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "atActivate");
				}

			}

			return beanO;
		}
	}

	void atPostInvoke(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atPostInvoke", new Object[]{tx, bean});
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as == null) {
			this.noneSessionalActivationStrategy.atPostInvoke(tx, bean);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atPostInvoke");
			}

		} else {
			BeanO beanO = null;
			Object skey = bean.ivCacheKey;
			if (skey == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "atPostInvoke : bean not in cache");
				}

			} else {
				synchronized (this.locks.getLock(skey)) {
					beanO = (BeanO) this.cache.find(skey);
					if (beanO != null) {
						this.cache.unpin(skey);
						if (beanO.isRemoved() || beanO.isDiscarded()) {
							if (tx != null) {
								try {
									tx.delist(beanO);
								} catch (TransactionRolledbackException var10) {
									FFDCFilter.processException(var10,
											"com.ibm.ejs.container.activator.EntitySessionalTransactionalActivationStrategy.atPostInvoke",
											"188", this);
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										Tr.debug(tc, "Transaction has rolled back");
									}
								}
							}

							beanO = (BeanO) this.cache.remove(skey, true);
							beanO.ivCacheKey = null;
							as.delist(beanO);
							if (!beanO.isDiscarded()) {
								try {
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										Tr.debug(tc, "Passivating Bean after Remove");
									}

									beanO.passivate();
								} catch (RemoteException var9) {
									FFDCFilter.processException(var9,
											"com.ibm.ejs.container.activator.EntitySessionalTransactionalActivationStrategy.atPostInvoke",
											"210", this);
									Tr.event(tc, "Exception while passivating bean", var9);
									beanO.destroy();
								}
							} else {
								if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
									Tr.debug(tc, "Destroying Bean after Discard");
								}

								beanO.destroy();
							}
						}
					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "atPostInvoke");
				}

			}
		}
	}

	BeanO atCreate(ContainerTx tx, BeanO beanO) throws DuplicateKeyException, RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCreate", new Object[]{tx, beanO});
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as == null) {
			this.noneSessionalActivationStrategy.atCreate(tx, beanO);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atCreate");
			}

			return null;
		} else {
			SessionKey skey = new SessionKey(as, beanO.getId());
			boolean inserted = false;
			boolean exception = false;

			try {
				synchronized (this.locks.getLock(skey)) {
					if (this.cache.contains(skey)) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
							Tr.exit(tc, "atCreate: Duplicate key", skey);
						}

						throw new DuplicateKeyException();
					}

					this.cache.insert(skey, beanO);
					beanO.ivCacheKey = skey;
					as.enlist(beanO);
					inserted = true;
					beanO.setContainerTx(tx);
				}

				if (!beanO.enlist(tx)) {
					this.cache.unpin(skey);
				}
			} catch (RemoteException var15) {
				FFDCFilter.processException(var15,
						"com.ibm.ejs.container.activator.EntitySessionalTransactionalActivationStrategy.atCreate",
						"302", this);
				Tr.event(tc, "Error creating bean", var15);
				exception = true;
				throw var15;
			} catch (RuntimeException var16) {
				FFDCFilter.processException(var16,
						"com.ibm.ejs.container.activator.EntitySessionalTransactionalActivationStrategy.atCreate",
						"309", this);
				Tr.event(tc, "atCreate", var16);
				exception = true;
				throw var16;
			} finally {
				if (exception) {
					beanO.destroy();
					if (inserted) {
						this.cache.remove(skey, true);
						beanO.ivCacheKey = null;
						as.delist(beanO);
					}
				}

			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atCreate", (Object) null);
			}

			return null;
		}
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit", new Object[]{tx, bean});
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as == null) {
			this.noneSessionalActivationStrategy.atCommit(tx, bean);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atCommit");
			}

		} else {
			this.resetBeanOContainerTx(bean);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atCommit");
			}

		}
	}

	void atRollback(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRollback", new Object[]{tx, bean});
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as == null) {
			this.noneSessionalActivationStrategy.atRollback(tx, bean);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atRollback");
			}

		} else {
			this.resetBeanOContainerTx(bean);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atRollback");
			}

		}
	}

	void atUnitOfWorkEnd(ContainerAS as, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atUnitOfWorkEnd", new Object[]{as, bean});
		}

		if (as == null) {
			this.noneSessionalActivationStrategy.atUnitOfWorkEnd((ContainerAS) null, bean);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUnitOfWorkEnd");
			}

		} else {
			Object skey = bean.ivCacheKey;
			BeanO beanO;
			synchronized (this.locks.getLock(skey)) {
				beanO = (BeanO) this.cache.remove(skey, true);
				beanO.ivCacheKey = null;
			}

			try {
				beanO.setContainerTx((ContainerTx) null);
				beanO.passivate();
			} catch (RemoteException var7) {
				FFDCFilter.processException(var7,
						"com.ibm.ejs.container.activator.EntitySessionalTransactionalActivationStrategy.atUnitOfWorkEnd",
						"381", this);
				Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{beanO, this, var7});
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUnitOfWorkEnd");
			}

		}
	}

	void atEnlist(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atEnlist", new Object[]{tx, bean});
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as == null) {
			this.noneSessionalActivationStrategy.atEnlist(tx, bean);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atEnlist");
			}

		} else {
			this.cache.pin(bean.ivCacheKey);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atEnlist");
			}

		}
	}

	void atRemove(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRemove", new Object[]{tx, bean});
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as == null) {
			this.noneSessionalActivationStrategy.atRemove(tx, bean);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atRemove");
			}

		} else {
			Object skey = bean.ivCacheKey;
			synchronized (this.locks.getLock(skey)) {
				BeanO beanO = (BeanO) this.cache.remove(skey, true);
				beanO.ivCacheKey = null;
				beanO.setContainerTx((ContainerTx) null);
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atRemove");
			}

		}
	}

	BeanO atGet(ContainerTx tx, BeanId id) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atGet", new Object[]{tx, id});
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as == null) {
			BeanO beanO = this.noneSessionalActivationStrategy.atGet(tx, id);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atGet");
			}

			return beanO;
		} else {
			SessionKey skey = new SessionKey(as, id);
			BeanO result;
			synchronized (this.locks.getLock(skey)) {
				result = (BeanO) this.cache.find(skey);
				if (result != null) {
					this.cache.unpin(skey);
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atGet", result);
			}

			return result;
		}
	}

	void atDiscard(BeanO bean) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atDiscard", bean);
		}

		ContainerAS as = ContainerAS.getContainerAS((ContainerTx) null);
		if (as == null) {
			this.noneSessionalActivationStrategy.atDiscard(bean);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atEnlist");
			}

		} else {
			as.delist(bean);
			bean.setContainerTx((ContainerTx) null);
			bean.ivCacheKey = null;
			bean.passivate();
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atDiscard");
			}

		}
	}

	void atUninstall(BeanId id, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atUninstall (" + bean + ")");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atUninstall");
		}

	}

	private void resetBeanOContainerTx(BeanO bean) {
		Object skey = bean.ivCacheKey;
		synchronized (this.locks.getLock(skey)) {
			BeanO beanO = (BeanO) this.cache.find(skey);
			if (beanO != null) {
				this.cache.unpin(skey);
				beanO.setContainerTx((ContainerTx) null);
			}

		}
	}
}