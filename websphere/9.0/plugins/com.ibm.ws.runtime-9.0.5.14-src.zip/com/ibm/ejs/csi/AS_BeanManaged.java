package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.ws.ActivitySession.ActivitySession;
import com.ibm.ws.Transaction.NativeJDBCDriverHelper;
import com.ibm.ws.ffdc.FFDCFilter;
import java.util.Hashtable;
import javax.transaction.Transaction;

final class AS_BeanManaged extends ActivitySessionStrategy {
	private static final TraceComponent tc = Tr.register(AS_BeanManaged.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.csi.AS_BeanManaged";
	private Hashtable<EJBKey, ActivitySession> suspendedBeans = new Hashtable();

	AS_BeanManaged(UOWControlImpl UOWCtrl) {
		super(UOWCtrl);
	}

	ASCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		ActivitySession suspendedAS = null;
		if (this.ASExists()) {
			suspendedAS = this.suspendAS();
		}

		ActivitySession stickyAS = null;
		stickyAS = (ActivitySession) this.suspendedBeans.remove(key);
		if (stickyAS != null) {
			this.resumeAS(stickyAS);
		}

		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		return new ASCookieImpl(false, this, suspendedAS, (Transaction) null);
	}

	void postInvoke(EJBKey key, ASCookieImpl ASCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		if (this.ASExists()) {
			if (!ASCookie.TxCookie.methodInfo.isStatefulSessionBean()) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc,
							"Illegal Bean Managed ActivitySession: Only Stateful Session bean initiated activitySessions may span multiple methods.");
				}

				try {
					this.UOWCtrl.asService.endSession(1);
				} catch (Exception var6) {
					FFDCFilter.processException(var6, "com.ibm.ejs.csi.AS_BeanManaged.postInvoke", "142", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Unexpected exception during postInvoke: " + var6);
					}
				}

				throw new CSIException("Illegal Bean Managed ActivitySession");
			}

			ActivitySession stickyAS = this.suspendAS();
			this.suspendedBeans.put(key, stickyAS);
			if (EJSPlatformHelper.isZOS()) {
				NativeJDBCDriverHelper.threadSwitch();
			}
		}

		if (ASCookie.suspendedAS != null) {
			this.resumeAS(ASCookie.suspendedAS);
		}

		if (entryEnabled) {
			Tr.exit(tc, "postInvoke");
		}

	}

	public void handleException(EJBKey key, ASCookieImpl ASCookie, ExceptionType exType, EJBMethodInfoImpl methodInfo)
			throws CSIException {
		if (exType == ExceptionType.UNCHECKED_EXCEPTION && this.ASExists()) {
			if (ASCookie.TxCookie.methodInfo.isStatefulSessionBean()) {
				ActivitySession suspendedAS = this.suspendAS();
				this.suspendedBeans.put(key, suspendedAS);
			} else {
				try {
					this.UOWCtrl.asService.endSession(1);
				} catch (Exception var6) {
					FFDCFilter.processException(var6, "com.ibm.ejs.csi.AS_BeanManaged.handleException", "222", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Unexpected exception during handleException: " + var6);
					}
				}
			}

		} else {
			super.handleException(key, ASCookie, exType, methodInfo);
		}
	}

	public boolean isBmasActive() {
		return this.ASExists();
	}
}