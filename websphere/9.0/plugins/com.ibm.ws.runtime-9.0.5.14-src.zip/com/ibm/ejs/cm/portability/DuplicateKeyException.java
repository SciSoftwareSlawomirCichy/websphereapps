package com.ibm.ejs.cm.portability;

import java.sql.SQLException;

public final class DuplicateKeyException extends PortableSQLException {
	private static final long serialVersionUID = -34836589190428996L;

	DuplicateKeyException(SQLException nativeException) {
		super(nativeException);
	}

	DuplicateKeyException() {
	}
}