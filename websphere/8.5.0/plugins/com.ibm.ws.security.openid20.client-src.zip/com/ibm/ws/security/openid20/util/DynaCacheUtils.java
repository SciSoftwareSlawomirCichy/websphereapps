package com.ibm.ws.security.openid20.util;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.cache.DistributedMap;
import com.ibm.websphere.cache.DynamicCacheAccessor;
import com.ibm.ws.security.openid20.client.RequestData;
import com.ibm.wsspi.cache.DistributedObjectCacheFactory;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import javax.naming.InitialContext;

public class DynaCacheUtils {
	private static final TraceComponent tc = Tr.register(DynaCacheUtils.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	public static final String DYNACACHE_NAME = "OpenID20RPDistributedCacheMap";
	public static final String JNDI_NAME = "services/cache/OpenID20RPRequestCache";
	private static ConcurrentHashMap<String, RequestData> localMap = null;
	private static DistributedMap distMap = null;
	private static Map cacheMap = null;
	private static boolean dynamicCacheEnabled = false;
	private static boolean _initialized = false;

	public static Map init(int maxCacheSize, String jndiCacheName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "init(maxCacheSize[" + maxCacheSize + "], jndiCacheName[" + jndiCacheName + "])");
		}

		if (cacheMap == null) {
			distMap = initDynamicCache(jndiCacheName);
			if (distMap != null) {
				cacheMap = distMap;
			} else {
				localMap = initLocalCache(maxCacheSize);
				cacheMap = localMap;
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "init returns [" + OidUtil.getObjState(cacheMap) + "]");
		}

		return cacheMap;
	}

	public static ConcurrentHashMap<String, RequestData> initLocalCache(int maxCacheSize) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initLocalCache(maxCacheSize[" + maxCacheSize + "])");
		}

		ConcurrentHashMap<String, RequestData> localCache = new ConcurrentHashMap(maxCacheSize / 4);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initLocalCache returns [" + OidUtil.getObjState(localCache) + "]");
		}

		return localCache;
	}

	public static DistributedMap initDynamicCache(String jndiCacheName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initDynamicCache(jndiCacheName[" + jndiCacheName + "])");
		}

		distMap = null;
		if (!DynamicCacheAccessor.isObjectCachingEnabled()) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc,
						"DynaCache Object caching is not enabled.  Will not attempt to get distributed cache object.");
				Tr.debug(tc, "Local cache will be used.");
			}
		} else {
			try {
				if (OidUtil.hasValue(jndiCacheName)) {
					InitialContext ic = new InitialContext();
					distMap = (DistributedMap) ic.lookup(jndiCacheName);
				} else {
					Properties props = new Properties();
					props.setProperty("com.ibm.ws.cache.CacheConfig.enableCacheReplication", "true");
					props.setProperty("com.ibm.ws.cache.CacheConfig.replicationDomain", "DynaCacheCluster");
					distMap = DistributedObjectCacheFactory.getMap("OpenID20RPDistributedCacheMap", props);
				}

				if (distMap != null) {
					dynamicCacheEnabled = true;
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Dynamic cache initialized successfully.");
						Tr.debug(tc,
								"Cache will be managed by DynaCache.  Cache customizing properties will be ignored.");
					}
				}
			} catch (Exception var2) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Fail to initialize distributed cache. [" + var2 + "]");
					Tr.debug(tc, "Local cache will be used.");
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initDynamicCache returns [" + OidUtil.getObjState(distMap) + "]");
		}

		return distMap;
	}

	public static boolean isDynamicCacheEnabled() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "isDynamicCacheEnabled returns [" + dynamicCacheEnabled + "]");
		}

		return dynamicCacheEnabled;
	}

	public static Map getCache() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getCache() returns [" + OidUtil.getObjState(cacheMap) + "]");
		}

		return cacheMap;
	}
}