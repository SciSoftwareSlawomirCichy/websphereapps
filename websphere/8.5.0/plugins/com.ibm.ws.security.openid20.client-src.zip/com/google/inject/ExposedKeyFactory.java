package com.google.inject;

import com.google.inject.BindingProcessor.CreationListener;
import com.google.inject.internal.BindingImpl;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.InternalContext;
import com.google.inject.internal.InternalFactory;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.PrivateElements;

class ExposedKeyFactory<T> implements InternalFactory<T>, CreationListener {
	private final Key<T> key;
	private final PrivateElements privateElements;
	private BindingImpl<T> delegate;

	public ExposedKeyFactory(Key<T> key, PrivateElements privateElements) {
		this.key = key;
		this.privateElements = privateElements;
	}

	public void notify(Errors errors) {
		InjectorImpl privateInjector = (InjectorImpl) this.privateElements.getInjector();
		BindingImpl<T> explicitBinding = privateInjector.state.getExplicitBinding(this.key);
		if (explicitBinding.getInternalFactory() == this) {
			errors.withSource(explicitBinding.getSource()).exposedButNotBound(this.key);
		} else {
			this.delegate = explicitBinding;
		}
	}

	public T get(Errors errors, InternalContext context, Dependency<?> dependency) throws ErrorsException {
		return this.delegate.getInternalFactory().get(errors, context, dependency);
	}
}