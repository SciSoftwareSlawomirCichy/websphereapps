package com.ibm.ws.wim.lookaside;

import com.ibm.websphere.wim.exception.WIMException;
import commonj.sdo.DataObject;

public interface LookasideRepository {
	void initialize(DataObject var1) throws WIMException;

	DataObject create(DataObject var1) throws WIMException;

	DataObject get(DataObject var1) throws WIMException;

	DataObject update(DataObject var1) throws WIMException;

	DataObject delete(DataObject var1) throws WIMException;

	DataObject search(DataObject var1) throws WIMException;

	DataObject createSchema(DataObject var1) throws WIMException;

	DataObject getSchema(DataObject var1) throws WIMException;
}