package com.ibm.ws.wim;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.ws.wim.env.IAuthorizationService;
import com.ibm.ws.wim.env.ICacheUtil;
import com.ibm.ws.wim.env.IEncryptionUtil;
import com.ibm.ws.wim.env.ISSLUtil;
import com.ibm.ws.wim.env.ITransactionUtil;
import com.ibm.ws.wim.env.IVariableResolver;
import com.ibm.ws.wim.env.was.CacheUtilImpl;
import com.ibm.ws.wim.env.was.EncryptionUtilImpl;
import com.ibm.ws.wim.env.was.JACCAuthorizationService;
import com.ibm.ws.wim.env.was.SSLUtilImpl;
import com.ibm.ws.wim.tx.JTAHelper;
import com.ibm.ws.wim.util.WasVariableResolver;
import com.ibm.ws.xml.ParserFactory;
import javax.xml.parsers.DocumentBuilderFactory;

public class FactoryManager implements FactoryConstants {
	static final String COPYRIGHT_NOTICE;

	public static IEncryptionUtil getEncryptionUtil() {
		return new EncryptionUtilImpl();
	}

	public static ICacheUtil getCacheUtil() {
		return new CacheUtilImpl();
	}

	public static ISSLUtil getSSLUtil() {
		return new SSLUtilImpl();
	}

	public static ITransactionUtil getTransactionUtil() {
		return new JTAHelper();
	}

	public static IVariableResolver getVariableResolver() throws Exception {
		return new WasVariableResolver();
	}

	public static IAuthorizationService getAuthorizationService() {
		return new JACCAuthorizationService();
	}

	public static DocumentBuilderFactory getDocumentBuilderFactory() {
		return ParserFactory.newDocumentBuilderFactory();
	}

	public static String getDuplicateKeyExceptionName() {
		return "com.ibm.websphere.ce.cm.DuplicateKeyException";
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010;
	}
}