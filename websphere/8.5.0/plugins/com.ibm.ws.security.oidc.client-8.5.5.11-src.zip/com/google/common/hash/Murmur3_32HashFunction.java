package com.google.common.hash;

import com.google.common.hash.Murmur3_32HashFunction.Murmur3_32Hasher;
import java.io.Serializable;

final class Murmur3_32HashFunction extends AbstractStreamingHashFunction implements Serializable {
	private static final int C1 = -862048943;
	private static final int C2 = 461845907;
	private final int seed;
	private static final long serialVersionUID = 0L;

	Murmur3_32HashFunction(int seed) {
		this.seed = seed;
	}

	public int bits() {
		return 32;
	}

	public Hasher newHasher() {
		return new Murmur3_32Hasher(this.seed);
	}

	public String toString() {
		return "Hashing.murmur3_32(" + this.seed + ")";
	}

	public HashCode hashInt(int input) {
		int k1 = mixK1(input);
		int h1 = mixH1(this.seed, k1);
		return fmix(h1, 4);
	}

	public HashCode hashLong(long input) {
		int low = (int) input;
		int high = (int) (input >>> 32);
		int k1 = mixK1(low);
		int h1 = mixH1(this.seed, k1);
		k1 = mixK1(high);
		h1 = mixH1(h1, k1);
		return fmix(h1, 8);
	}

	public HashCode hashString(CharSequence input) {
		int h1 = this.seed;

		int k1;
		for (k1 = 1; k1 < input.length(); k1 += 2) {
			int k1 = input.charAt(k1 - 1) | input.charAt(k1) << 16;
			k1 = mixK1(k1);
			h1 = mixH1(h1, k1);
		}

		if ((input.length() & 1) == 1) {
			int k1 = input.charAt(input.length() - 1);
			k1 = mixK1(k1);
			h1 ^= k1;
		}

		return fmix(h1, 2 * input.length());
	}

	private static int mixK1(int k1) {
		k1 *= -862048943;
		k1 = Integer.rotateLeft(k1, 15);
		k1 *= 461845907;
		return k1;
	}

	private static int mixH1(int h1, int k1) {
		h1 ^= k1;
		h1 = Integer.rotateLeft(h1, 13);
		h1 = h1 * 5 + -430675100;
		return h1;
	}

	private static HashCode fmix(int h1, int length) {
		h1 ^= length;
		h1 ^= h1 >>> 16;
		h1 *= -2048144789;
		h1 ^= h1 >>> 13;
		h1 *= -1028477387;
		h1 ^= h1 >>> 16;
		return HashCodes.fromInt(h1);
	}
}