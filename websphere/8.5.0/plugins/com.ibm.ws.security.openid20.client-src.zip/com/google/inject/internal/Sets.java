package com.google.inject.internal;

import com.google.inject.internal.Sets.SetFromMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public final class Sets {
	public static <E> HashSet<E> newHashSet() {
		return new HashSet();
	}

	public static <E> LinkedHashSet<E> newLinkedHashSet() {
		return new LinkedHashSet();
	}

	public static <E> Set<E> newSetFromMap(Map<E, Boolean> map) {
		return new SetFromMap(map);
	}

	static int hashCodeImpl(Set<?> s) {
		int hashCode = 0;

		Object o;
		for (Iterator i$ = s.iterator(); i$.hasNext(); hashCode += o != null ? o.hashCode() : 0) {
			o = i$.next();
		}

		return hashCode;
	}
}