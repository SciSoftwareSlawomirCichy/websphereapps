package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.IllegalOperationException;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.DuplicateKeyException;
import javax.transaction.TransactionRolledbackException;

public class OptBEntityActivationStrategy extends ActivationStrategy {
	private static final TraceComponent tc = Tr.register(OptBEntityActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.activator.OptBEntityActivationStrategy";

	public OptBEntityActivationStrategy(Activator activator) {
		super(activator);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> complete");
		}

	}

	BeanO atActivate(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atActivate (" + beanId + ")", tx);
		}

		boolean exception = false;
		boolean activate = false;
		boolean pushedCallbackBeanO = false;
		BeanO bean = tx.find(beanId);
		if (bean != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Found bean in Tran Cache");
			}

			threadData.pushCallbackBeanO(bean);
			pushedCallbackBeanO = true;
			if (bean.getState() == 8) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "OptB Committing - re-enlist");
				}

				bean.enlist(tx);
			}

			bean.ensurePersistentState(tx);
		} else {
			TransactionKey key = null;
			MasterKey masterKey = new MasterKey(beanId);

			try {
				synchronized (this.locks.getLock(masterKey)) {
					if ((bean = (BeanO) this.cache.find(masterKey)) == null) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "Bean not in cache");
						}

						key = new TransactionKey(tx, beanId);
						bean = beanId.getHome().createBeanO(threadData, tx, beanId);
						pushedCallbackBeanO = true;
						this.cache.insert(key, bean);
						bean.ivCacheKey = key;
						activate = true;
					} else {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "Found bean in EJB Cache");
						}

						key = new TransactionKey(tx, bean.getId());
						bean = (BeanO) this.cache.remove(masterKey, true);
						this.cache.insert(key, bean);
						bean.ivCacheKey = key;
					}
				}

				boolean pin = false;
				if (activate) {
					bean.activate(beanId, tx);
					pin = bean.enlist(tx);
				} else {
					threadData.pushCallbackBeanO(bean);
					pushedCallbackBeanO = true;
					pin = bean.enlist(tx);
				}

				if (!pin) {
					this.cache.unpin(key);
				}
			} catch (NoSuchObjectException var19) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception while activating bean", var19);
				}

				exception = true;
				throw var19;
			} catch (RemoteException var20) {
				FFDCFilter.processException(var20,
						"com.ibm.ejs.container.activator.OptBEntityActivationStrategy.atActivate", "143", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception while activating bean", var20);
				}

				exception = true;
				throw var20;
			} catch (RuntimeException var21) {
				FFDCFilter.processException(var21,
						"com.ibm.ejs.container.activator.OptBEntityActivationStrategy.atActivate", "150", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception while activating bean", var21);
				}

				exception = true;
				throw var21;
			} finally {
				if (exception && bean != null) {
					if (pushedCallbackBeanO) {
						threadData.popCallbackBeanO();
					}

					bean.destroy();
					if (activate) {
						this.cache.remove(key, true);
						bean.ivCacheKey = null;
					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "atActivate");
				}

			}
		}

		return bean;
	}

	void atPostInvoke(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atPostInvoke", new Object[]{tx, bean});
		}

		Object key = bean.ivCacheKey;
		if (key == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atPostInvoke : bean not in cache");
			}

		} else {
			synchronized (this.locks.getLock(key)) {
				BeanO beanO = (BeanO) this.cache.find(key);
				if (beanO != null) {
					this.cache.unpin(key);
					if (beanO.isRemoved() || beanO.isDiscarded()) {
						if (tx != null) {
							try {
								tx.delist(beanO);
							} catch (TransactionRolledbackException var8) {
								FFDCFilter.processException(var8,
										"com.ibm.ejs.container.activator.OptBEntityActivationStrategy.atPostInvoke",
										"200", this);
								if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
									Tr.debug(tc, "Transaction has rolled back");
								}
							}
						}

						bean = (BeanO) this.cache.remove(key, true);
						bean.ivCacheKey = null;
						bean.destroy();
					}
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atPostInvoke");
			}

		}
	}

	BeanO atCreate(ContainerTx tx, BeanO bean) throws DuplicateKeyException, RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCreate", new Object[]{tx, bean});
		}

		TransactionKey key = new TransactionKey(tx, bean.getId());
		boolean inserted = false;
		boolean exception = false;

		try {
			synchronized (this.locks.getLock(key)) {
				if (this.cache.contains(key)) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "atCreate: Duplicate key", key);
					}

					throw new DuplicateKeyException();
				}

				this.cache.insert(key, bean);
				bean.ivCacheKey = key;
				inserted = true;
			}

			if (!bean.enlist(tx)) {
				this.cache.unpin(key);
			}
		} catch (RemoteException var14) {
			FFDCFilter.processException(var14, "com.ibm.ejs.container.activator.OptBEntityActivationStrategy.atCreate",
					"254", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Error creating bean", var14);
			}

			exception = true;
			throw var14;
		} catch (RuntimeException var15) {
			FFDCFilter.processException(var15, "com.ibm.ejs.container.activator.OptBEntityActivationStrategy.atCreate",
					"261", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "atCreate", var15);
			}

			exception = true;
			throw var15;
		} finally {
			if (exception) {
				bean.destroy();
				if (inserted) {
					this.cache.remove(key, true);
					bean.ivCacheKey = null;
				}
			}

		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCreate", (Object) null);
		}

		return null;
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit", new Object[]{tx, bean});
		}

		BeanId id = bean.getId();
		Object key = bean.ivCacheKey;
		MasterKey masterKey = new MasterKey(id);
		BeanO beanO;
		synchronized (this.locks.getLock(key)) {
			beanO = (BeanO) this.cache.remove(key, true);
			beanO.ivCacheKey = null;
		}

		synchronized (this.locks.getLock(masterKey)) {
			this.cache.insert(masterKey, beanO);
			beanO.ivCacheKey = masterKey;
			this.cache.unpin(masterKey);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCommit");
		}

	}

	void atRollback(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRollback", new Object[]{tx, bean});
		}

		Object key = bean.ivCacheKey;
		BeanO beanO;
		synchronized (this.locks.getLock(key)) {
			beanO = (BeanO) this.cache.remove(key, true);
			beanO.ivCacheKey = null;
		}

		try {
			beanO.passivate();
		} catch (RemoteException var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.container.activator.OptBEntityActivationStrategy.atRollback",
					"349", this);
			Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{beanO, this, var7});
			beanO.destroy();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRollback");
		}

	}

	void atEnlist(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atEnlist", new Object[]{tx, bean});
		}

		this.cache.pin(bean.ivCacheKey);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atEnlist");
		}

	}

	void atRemove(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRemove", new Object[]{tx, bean});
		}

		Object key = bean.ivCacheKey;
		synchronized (this.locks.getLock(key)) {
			this.cache.remove(key, true);
			bean.ivCacheKey = null;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRemove");
		}

	}

	BeanO atGet(ContainerTx tx, BeanId id) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atGet", new Object[]{tx, id});
		}

		TransactionKey key = new TransactionKey(tx, id);
		BeanO result;
		synchronized (this.locks.getLock(key)) {
			result = (BeanO) this.cache.find(key);
			if (result != null) {
				this.cache.unpin(key);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atGet", result);
		}

		return result;
	}

	void atDiscard(BeanO bean) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atDiscard", bean);
		}

		try {
			bean.ivCacheKey = null;
			bean.passivate();
		} catch (RemoteException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.activator.OptBEntityActivationStrategy.atDiscard",
					"416", this);
			Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{bean, this, var3});
			throw var3;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atDiscard");
		}

	}

	void atUninstall(BeanId id, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atUninstall (" + bean + ")");
		}

		Object key = bean.ivCacheKey;
		if (key == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUninstall: bean already removed");
			}

		} else {
			synchronized (this.locks.getLock(key)) {
				try {
					bean = (BeanO) this.cache.remove(key, false);
					bean.ivCacheKey = null;
					bean.destroy();
				} catch (IllegalOperationException var7) {
					FFDCFilter.processException(var7,
							"com.ibm.ejs.container.activator.OptBEntityActivationStrategy.atUninstall", "452", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Unable to remove uninstalled bean instance", var7);
					}
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUninstall");
			}

		}
	}
}