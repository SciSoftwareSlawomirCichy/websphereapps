package com.ibm.ejs.container;

import com.ibm.ejs.container.BeanOFactory.BeanOFactoryType;
import com.ibm.ejs.container.HomeOfHomes.AppLinkData;
import com.ibm.ejs.container.activator.ActivationStrategy;
import com.ibm.ejs.container.activator.Activator;
import com.ibm.ejs.csi.EJBModuleMetaDataImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.FastHashtable;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.J2EENameFactory;
import com.ibm.websphere.ejbcontainer.AmbiguousEJBReferenceException;
import com.ibm.websphere.ejbcontainer.EJBStoppedException;
import com.ibm.ws.ejbcontainer.diagnostics.IncidentStreamWriter;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.ws.ejbcontainer.runtime.EJBRuntime;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.ffdc.IncidentStream;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import javax.ejb.CreateException;
import javax.ejb.Handle;

public final class HomeOfHomes implements HomeInternal {
	private static final String CLASS_NAME = "com.ibm.ejs.container.HomeOfHomes";
	public static final String HOME_OF_HOMES = "__homeOfHomes";
	private static final String EJB_FACTORY = "__EJBFactory";
	private final J2EENameFactory j2eeNameFactory;
	private final EJSContainer container;
	private final Activator activator;
	private final J2EEName homeOfHomesJ2EEName;
	EJBFactoryHome ivEJBFactoryHome;
	private static int fastHashTableSize = 2053;
	private final FastHashtable<J2EEName, HomeRecord> homesByName;
	private final Map<String, AppLinkData> ivAppLinkData;
	private final BeanOFactory beanOFactory;
	private static final TraceComponent tc = Tr.register(HomeOfHomes.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private ActivationStrategy activationStrategy;
	private final Map<J2EEName, J2EEName> ivVersionedModuleNames;

	public HomeOfHomes(EJSContainer container, Activator activator) {
		this.homesByName = new FastHashtable(fastHashTableSize);
		this.ivAppLinkData = new HashMap();
		this.ivVersionedModuleNames = new ConcurrentHashMap();
		this.container = container;
		this.activator = activator;
		this.beanOFactory = container.getEJBRuntime().getBeanOFactory(BeanOFactoryType.CM_STATELESS_BEANO_FACTORY,
				(BeanMetaData) null);
		this.j2eeNameFactory = container.getJ2EENameFactory();
		this.homeOfHomesJ2EEName = this.j2eeNameFactory.create("__homeOfHomes", "__homeOfHomes", "__homeOfHomes");
		J2EEName ejbFactoryJ2EEName = this.j2eeNameFactory.create("__homeOfHomes", "__homeOfHomes", "__EJBFactory");
		this.ivEJBFactoryHome = new EJBFactoryHome(container, this, ejbFactoryJ2EEName, this.j2eeNameFactory);
	}

	public EJSHome create(BeanMetaData beanMetaData) throws RemoteException {
		J2EEName name = beanMetaData.j2eeName;
		HomeRecord hr = beanMetaData.homeRecord;
		StatelessBeanO homeBeanO = null;
		EJSHome result = null;

		try {
			result = (EJSHome) beanMetaData.homeBeanClass.newInstance();
			homeBeanO = (StatelessBeanO) this.beanOFactory.create(this.container, (EJSHome) null, false);
			homeBeanO.setEnterpriseBean(result);
		} catch (Exception var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.container.HomeOfHomes.create", "90", this);
			throw new InvalidEJBClassNameException("", var7);
		}

		homeBeanO.reentrant = true;
		hr.beanO = homeBeanO;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "created new home bean", name);
		}

		return result;
	}

	public void addHome(BeanMetaData bmd) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "addHome : " + bmd.j2eeName);
		}

		if (this.homesByName.get(bmd.j2eeName) != null) {
			throw new DuplicateHomeNameException(bmd.j2eeName.toString());
		} else {
			this.homesByName.put(bmd.j2eeName, bmd.homeRecord);
			J2EEName j2eeName = bmd.j2eeName;
			String application = j2eeName.getApplication();
			Map var6 = this.ivAppLinkData;
			AppLinkData linkData;
			synchronized (this.ivAppLinkData) {
				linkData = (AppLinkData) this.ivAppLinkData.get(application);
				if (linkData == null) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.debug(tc, "adding application link data for " + application);
					}

					linkData = new AppLinkData();
					this.ivAppLinkData.put(application, linkData);
				}
			}

			this.updateAppLinkData(linkData, true, j2eeName, bmd);
			if (bmd._moduleMetaData.isVersionedModule()) {
				EJBModuleMetaDataImpl mmd = bmd._moduleMetaData;
				bmd.ivUnversionedJ2eeName = this.j2eeNameFactory.create(mmd.ivVersionedAppBaseName,
						mmd.ivVersionedModuleBaseName, j2eeName.getComponent());
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Versioned Mapping Added : " + bmd.ivUnversionedJ2eeName + " -> " + j2eeName);
				}

				J2EEName dupBaseName = (J2EEName) this.ivVersionedModuleNames.put(bmd.ivUnversionedJ2eeName, j2eeName);
				if (dupBaseName != null) {
					this.ivVersionedModuleNames.put(bmd.ivUnversionedJ2eeName, dupBaseName);
					throw new DuplicateHomeNameException("Base Name : " + bmd.ivUnversionedJ2eeName);
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "addHome");
			}

		}
	}

	void setActivationStrategy(EJSHome result, BeanMetaData beanMetaData) throws RemoteException {
		EJBRuntime runtime = this.container.getEJBRuntime();
		byte strategy;
		switch (beanMetaData.type) {
			case 2 :
				result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.SINGLETON_BEANO_FACTORY, beanMetaData);
				strategy = 0;
				break;
			case 3 :
				if (beanMetaData.usesBeanManagedTx) {
					result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.BM_STATELESS_BEANO_FACTORY,
							beanMetaData);
				} else {
					result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.CM_STATELESS_BEANO_FACTORY,
							beanMetaData);
				}

				strategy = 0;
				break;
			case 4 :
				if (beanMetaData.usesBeanManagedTx) {
					result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.BM_STATEFUL_BEANO_FACTORY,
							beanMetaData);
				} else {
					result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.CM_STATEFUL_BEANO_FACTORY,
							beanMetaData);
				}

				if (beanMetaData.sessionActivateTran) {
					strategy = 2;
				} else if (beanMetaData.sessionActivateSession) {
					strategy = 3;
				} else {
					strategy = 1;
				}
				break;
			case 5 :
				result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.BEAN_MANAGED_BEANO_FACTORY,
						beanMetaData);
				if (beanMetaData.optionACommitOption) {
					strategy = 4;
				} else if (beanMetaData.optionBCommitOption) {
					strategy = 5;
				} else if (beanMetaData.entitySessionalTranOption) {
					strategy = 7;
				} else {
					strategy = 6;
				}
				break;
			case 6 :
				if (beanMetaData.cmpVersion == 2) {
					result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.CONTAINER_MANAGED_2_0_BEANO_FACTORY,
							beanMetaData);
				} else {
					result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.CONTAINER_MANAGED_BEANO_FACTORY,
							beanMetaData);
				}

				if (beanMetaData.optionACommitOption) {
					strategy = 4;
				} else if (beanMetaData.optionBCommitOption) {
					strategy = 5;
				} else if (beanMetaData.entitySessionalTranOption) {
					strategy = 7;
				} else if (beanMetaData.ivReadOnlyCommitOption) {
					strategy = 8;
				} else {
					strategy = 6;
				}
				break;
			case 7 :
				if (beanMetaData.usesBeanManagedTx) {
					result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.BM_MESSAGEDRIVEN_BEANO_FACTORY,
							beanMetaData);
				} else {
					result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.CM_MESSAGEDRIVEN_BEANO_FACTORY,
							beanMetaData);
				}

				strategy = 0;
				break;
			case 8 :
				result.beanOFactory = runtime.getBeanOFactory(BeanOFactoryType.MANAGED_BEANO_FACTORY, beanMetaData);
				strategy = 0;
				break;
			default :
				throw new ContainerInternalError();
		}

		result.activationStrategy = this.activator.getActivationStrategy(result, strategy);
	}

	public EJSHome removeHome(BeanMetaData bmd) {
		J2EEName name = bmd.getJ2EEName();
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "removeHome : " + name);
		}

		if (bmd._moduleMetaData.isVersionedModule()) {
			this.ivVersionedModuleNames.remove(bmd.ivUnversionedJ2eeName);
		}

		boolean added = this.homesByName.remove(name) != null;
		if (added) {
			Map var5 = this.ivAppLinkData;
			synchronized (this.ivAppLinkData) {
				String application = name.getApplication();
				AppLinkData linkData = (AppLinkData) this.ivAppLinkData.get(application);
				this.updateAppLinkData(linkData, false, name, bmd);
				if (linkData.ivNumBeans == 0) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "removing application link data for " + application);
					}

					this.ivAppLinkData.remove(application);
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "removeHome");
		}

		return (EJSHome) bmd.homeRecord.homeInternal;
	}

	public HomeInternal getHome(J2EEName name) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getHome : " + name);
		}

		HomeInternal result = null;
		if (name.equals(this.homeOfHomesJ2EEName)) {
			result = this;
		} else if (name.equals(this.ivEJBFactoryHome.ivJ2eeName)) {
			result = this.ivEJBFactoryHome;
		} else {
			HomeRecord hr = (HomeRecord) this.homesByName.get(name);
			if (hr != null) {
				result = hr.homeInternal;
				if (result == null) {
					if (hr.bmd.ivDeferEJBInitialization) {
						result = hr.getHomeAndInitialize();
					} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Non-deferred EJB not yet available : " + name);
					}
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getHome : " + result);
		}

		return (HomeInternal) result;
	}

	private J2EEName findApplicationBean(AppLinkData linkData, String application, String beanName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "findApplicationBean : " + application + ", " + beanName);
		}

		Set<J2EEName> beans = (Set) linkData.ivBeansByName.get(beanName);
		J2EEName j2eeName;
		if (beans != null && !beans.isEmpty()) {
			if (beans.size() != 1) {
				AmbiguousEJBReferenceException ex = new AmbiguousEJBReferenceException(
						"The reference to bean " + beanName + " is ambiguous. Application " + application
								+ " contains multiple beans with same name.");
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "findApplicationBean : " + ex);
				}

				throw ex;
			}

			j2eeName = (J2EEName) beans.iterator().next();
		} else {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.debug(tc, "No beans found");
			}

			j2eeName = null;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "findApplicationBean : " + j2eeName);
		}

		return j2eeName;
	}

	public EJSHome getHomeByName(String application, String beanName) throws EJBNotFoundException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getHomeByName : " + application + ", " + beanName);
		}

		AppLinkData linkData = this.getAppLinkData(application);
		if (linkData == null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "application " + application + " not found");
			}
		} else {
			J2EEName j2eeName;
			synchronized (linkData) {
				j2eeName = this.findApplicationBean(linkData, application, beanName);
			}

			if (j2eeName != null) {
				EJSHome retHome = (EJSHome) this.getHome(j2eeName);
				if (retHome != null) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "getHomeByName : " + retHome.getJ2EEName());
					}

					return retHome;
				}
			} else if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "EJB " + beanName + " not found");
			}
		}

		EJBNotFoundException ex = new EJBNotFoundException(
				"EJB named " + beanName + " not present in application " + application + ".");
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getHomeByName : " + ex);
		}

		throw ex;
	}

	public HomeRecord resolveEJBLink(String application, String module, String link) throws EJBNotFoundException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "resolveEJBLink: " + application + "#" + module + ", " + link);
		}

		AppLinkData linkData = null;
		String origModule = module;
		int bidx = link.indexOf(35);
		String bean;
		int midx;
		if (bidx > -1) {
			midx = link.lastIndexOf(47);
			if (midx > -1 && midx < bidx) {
				module = link.substring(midx + 1, bidx);
			} else {
				module = link.substring(0, bidx);
			}

			bean = link.substring(bidx + 1);
			if (!module.endsWith(".jar") && !module.endsWith(".war") && !module.equals(origModule)) {
				throw new EJBNotFoundException(
						"Incorrect usage of beanName/ejb-link syntax. The syntax used requires the physical module file to be specified, and the module must end in .jar or .war to be a valid location for a bean. The beanName/ejb-link data specified bean "
								+ bean + " and module " + module + ".");
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Used ejb-link style 2 to get module name " + module + " and beanName " + bean);
			}
		} else {
			midx = link.lastIndexOf(47);
			if (midx > -1) {
				String logicalModule = link.substring(0, midx);
				bean = link.substring(midx + 1);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Used ejb-link style 3 to get module name " + logicalModule + " and beanName " + bean);
				}

				linkData = this.getAppLinkData(application);
				module = null;
				if (linkData != null) {
					synchronized (linkData) {
						Set<String> modules = (Set) linkData.ivModulesByLogicalName.get(logicalModule);
						if (modules != null) {
							if (modules.size() == 1) {
								module = (String) modules.iterator().next();
							} else if (!modules.isEmpty()) {
								throw new AmbiguousEJBReferenceException("The reference to bean " + bean + " in the "
										+ logicalModule + " logical module is ambiguous. Application " + application
										+ " contains multiple modules with same logical name.");
							}
						}
					}
				}

				if (module == null) {
					throw new EJBNotFoundException(
							"The reference to the " + bean + " bean in the " + logicalModule + " logical module in the "
									+ application + " application did not map to any bean component.");
				}
			} else {
				bean = link;
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Used ejb-link style 1 to get module name " + module + " and beanName " + link);
				}
			}
		}

		J2EEName j2eeName = null;
		HomeRecord hr = null;
		if (module != null) {
			j2eeName = this.j2eeNameFactory.create(application, module, bean);
			hr = this.getHomeRecord(j2eeName);
		}

		if (hr == null) {
			if (module == origModule) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "looking for home in other modules...");
				}

				if (linkData == null) {
					linkData = this.getAppLinkData(application);
				}

				if (linkData != null) {
					synchronized (linkData) {
						j2eeName = this.findApplicationBean(linkData, application, bean);
					}
				}

				if (j2eeName != null) {
					hr = this.getHomeRecord(j2eeName);
				} else if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "EJB " + bean + " not found");
				}
			}

			if (hr == null) {
				EJBNotFoundException ex = new EJBNotFoundException(
						"EJB named " + bean + " not present in application " + application + ".");
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "resolveEJBLink: " + ex);
				}

				throw ex;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "resolveEJBLink: " + hr);
		}

		return hr;
	}

	public EJSHome getHomeByInterface(String application, String module, String beanInterface)
			throws EJBNotFoundException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getHomeByInterface : " + application + ", " + module + ", " + beanInterface);
		}

		J2EEName j2eeName = null;
		AppLinkData linkData = this.getAppLinkData(application);
		if (linkData != null) {
			EJSHome retHome;
			if (module != null) {
				synchronized (linkData) {
					Map<String, Set<J2EEName>> moduleTable = (Map) linkData.ivBeansByModuleByType.get(module);
					if (moduleTable != null) {
						Set<J2EEName> beans = (Set) moduleTable.get(beanInterface);
						if (beans != null && !beans.isEmpty()) {
							if (beans.size() != 1) {
								AmbiguousEJBReferenceException ex = new AmbiguousEJBReferenceException(
										"The reference to bean interface " + beanInterface + " is ambiguous. Module "
												+ application + "/" + module
												+ " contains multiple beans with the same interface.");
								if (isTraceOn && tc.isEntryEnabled()) {
									Tr.exit(tc, "getHomeByInterface : " + ex);
								}

								throw ex;
							}

							j2eeName = (J2EEName) beans.iterator().next();
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "Mapped beanInterface " + beanInterface + " to j2eeName " + j2eeName
										+ " in current module.");
							}
						} else if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "EJB with interface " + beanInterface + " not found in module " + module);
						}
					}
				}

				if (j2eeName != null) {
					retHome = (EJSHome) this.getHome(j2eeName);
					if (retHome != null) {
						if (isTraceOn && tc.isEntryEnabled()) {
							Tr.exit(tc, "getHomeByInterface : " + retHome.getJ2EEName());
						}

						return retHome;
					}

					j2eeName = null;
				}
			}

			synchronized (linkData) {
				Set<J2EEName> beans = (Set) linkData.ivBeansByType.get(beanInterface);
				if (beans != null && !beans.isEmpty()) {
					if (beans.size() != 1) {
						AmbiguousEJBReferenceException ex = new AmbiguousEJBReferenceException(
								"The reference to bean interface " + beanInterface + " is ambiguous. Application "
										+ application + " contains multiple beans with the same interface.");
						if (isTraceOn && tc.isEntryEnabled()) {
							Tr.exit(tc, "getHomeByInterface : " + ex);
						}

						throw ex;
					}

					j2eeName = (J2EEName) beans.iterator().next();
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Mapped beanInterface " + beanInterface + " to j2eeName " + j2eeName
								+ " in another module in the app.");
					}
				} else if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "EJB with interface " + beanInterface + " not found");
				}
			}

			if (j2eeName != null) {
				retHome = (EJSHome) this.getHome(j2eeName);
				if (retHome != null) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "getHomeByInterface : " + retHome.getJ2EEName());
					}

					return retHome;
				}
			}
		} else if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "Applicaton " + application + " not found");
		}

		EJBNotFoundException ex = new EJBNotFoundException(
				"EJB with interface " + beanInterface + " not present in application " + application + ".");
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getHomeByInterface : " + ex);
		}

		throw ex;
	}

	private void updateAppLinkData(AppLinkData linkData, boolean add, J2EEName j2eeName, BeanMetaData bmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "updateAppLinkData: " + j2eeName + ", add=" + add);
		}

		int numBeans;
		synchronized (linkData) {
			linkData.ivNumBeans += add ? 1 : -1;
			numBeans = linkData.ivNumBeans;
			updateAppLinkDataTable(linkData.ivBeansByName, add, j2eeName.getComponent(), j2eeName, "ivBeansByName");
			this.updateAutoLink(linkData, add, j2eeName, bmd);
			updateAppLinkDataTable(linkData.ivModulesByLogicalName, add, bmd._moduleMetaData.ivLogicalName,
					j2eeName.getModule(), "ivModulesByLogicalName");
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "updateAppLinkData: " + j2eeName + ", add=" + add + ", numBeans=" + numBeans);
		}

	}

	private AppLinkData getAppLinkData(String application) {
		Map var2 = this.ivAppLinkData;
		synchronized (this.ivAppLinkData) {
			return (AppLinkData) this.ivAppLinkData.get(application);
		}
	}

	private static <T> void updateAppLinkDataTable(Map<String, Set<T>> table, boolean add, String key, T value,
			String tracePrefix) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		Set<T> values = (Set) table.get(key);
		if (add) {
			if (isTraceOn && tc.isDebugEnabled() && tracePrefix != null) {
				Tr.debug(tc, tracePrefix + ": adding " + key + " = " + value);
			}

			if (values == null) {
				values = new LinkedHashSet();
				table.put(key, values);
			}

			((Set) values).add(value);
		} else {
			if (isTraceOn && tc.isDebugEnabled() && tracePrefix != null) {
				Tr.debug(tc, tracePrefix + ": removing " + key + " = " + value);
			}

			if (values != null) {
				((Set) values).remove(value);
				if (((Set) values).size() == 0) {
					if (isTraceOn && tc.isDebugEnabled() && tracePrefix != null) {
						Tr.debug(tc, tracePrefix + ": removing " + key);
					}

					table.remove(key);
				}
			} else if (isTraceOn && tc.isDebugEnabled() && tracePrefix != null) {
				Tr.debug(tc, tracePrefix + ": key not found: " + key);
			}
		}

	}

	private void updateAutoLink(AppLinkData linkData, boolean add, J2EEName j2eeName, BeanMetaData bmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "updateAutoLink");
		}

		String module = j2eeName.getModule();
		String beanInterface = null;
		Map<String, Set<J2EEName>> appTable = linkData.ivBeansByType;
		Map<String, Set<J2EEName>> moduleTable = (Map) linkData.ivBeansByModuleByType.get(module);
		if (moduleTable == null) {
			moduleTable = new HashMap(7);
			linkData.ivBeansByModuleByType.put(module, moduleTable);
		}

		beanInterface = bmd.homeInterfaceClassName;
		if (beanInterface != null) {
			updateAppLinkDataTable(appTable, add, beanInterface, j2eeName, "ivBeansByType");
			updateAppLinkDataTable((Map) moduleTable, add, beanInterface, j2eeName, (String) null);
		}

		beanInterface = bmd.localHomeInterfaceClassName;
		if (beanInterface != null) {
			updateAppLinkDataTable(appTable, add, beanInterface, j2eeName, "ivBeansByType");
			updateAppLinkDataTable((Map) moduleTable, add, beanInterface, j2eeName, (String) null);
		}

		String[] businessRemoteInterfaceName = bmd.ivBusinessRemoteInterfaceClassNames;
		String[] arr$;
		int len$;
		if (businessRemoteInterfaceName != null) {
			arr$ = businessRemoteInterfaceName;
			int len$ = businessRemoteInterfaceName.length;

			for (len$ = 0; len$ < len$; ++len$) {
				String remoteInterface = arr$[len$];
				updateAppLinkDataTable(appTable, add, remoteInterface, j2eeName, "ivBeansByType");
				updateAppLinkDataTable((Map) moduleTable, add, remoteInterface, j2eeName, (String) null);
			}
		}

		arr$ = bmd.ivBusinessLocalInterfaceClassNames;
		if (arr$ != null) {
			String[] arr$ = arr$;
			len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				String localInterface = arr$[i$];
				updateAppLinkDataTable(appTable, add, localInterface, j2eeName, "ivBeansByType");
				updateAppLinkDataTable((Map) moduleTable, add, localInterface, j2eeName, (String) null);
			}
		}

		if (bmd.ivLocalBean) {
			beanInterface = bmd.enterpriseBeanClassName;
			updateAppLinkDataTable(appTable, add, beanInterface, j2eeName, "ivBeansByType");
			updateAppLinkDataTable((Map) moduleTable, add, beanInterface, j2eeName, (String) null);
		}

		if (((Map) moduleTable).isEmpty()) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "ivBeansByModuleByType: removing " + module);
			}

			linkData.ivBeansByModuleByType.remove(module);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "updateAutoLink");
		}

	}

	public J2EEName getEJBFactoryJ2EEName() {
		return this.ivEJBFactoryHome.ivJ2eeName;
	}

	J2EEName getVersionedJ2EEName(J2EEName unversionedName) {
		J2EEName versionedName = (J2EEName) this.ivVersionedModuleNames.get(unversionedName);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "Versioned J2EEName : " + unversionedName + " -> " + versionedName);
		}

		return versionedName != null ? versionedName : unversionedName;
	}

	public String getJNDIName(Object homeKey) {
		HomeRecord hr = (HomeRecord) this.homesByName.get(homeKey);
		return hr.homeInternal.getJNDIName(homeKey);
	}

	public J2EEName getJ2EEName() {
		return this.homeOfHomesJ2EEName;
	}

	public BeanId getId() {
		Tr.error(tc, "UNEXPECTED_METHOD_CALL_CNTR0074E", "HomeOfHomes.getId()");
		return null;
	}

	public final EJSWrapperCommon getWrapper() {
		Tr.error(tc, "UNEXPECTED_METHOD_CALL_CNTR0074E", "HomeOfHomes.getWrapper()");
		return null;
	}

	public final EJSWrapperCommon getWrapper(BeanId id) throws CSIException, RemoteException {
		return this.container.getWrapper(id);
	}

	public BeanO createBeanO(EJBThreadData threadData, ContainerTx tx, BeanId id) throws RemoteException {
		J2EEName homeKey = id.getJ2EEName();
		HomeRecord hr = (HomeRecord) this.homesByName.get(homeKey);
		BeanO result = null;
		if (hr != null) {
			result = hr.beanO;
		}

		if (result == null) {
			String msgTxt = "The referenced version of the " + homeKey.getComponent() + " bean in the "
					+ homeKey.getApplication() + " application has been stopped and may no longer be used. " + "If the "
					+ homeKey.getApplication() + " application has been started again, a new reference for "
					+ "the new image of the " + homeKey.getComponent()
					+ " bean must be obtained. Local references to a bean or home "
					+ "are no longer valid once the application has been stopped.";
			throw new EJBStoppedException(msgTxt);
		} else {
			return result;
		}
	}

	public EJSWrapperCommon internalCreateWrapper(BeanId id) throws CreateException, RemoteException, CSIException {
		J2EEName homeKey = (J2EEName) id.getPrimaryKey();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "Retrieving home record : " + homeKey);
		}

		EJSHome home = (EJSHome) this.getHome(homeKey);
		if (home == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Unknown home", id);
			}

			Tr.warning(tc, "HOME_NOT_FOUND_CNTR0092W", homeKey.toString());
			Exception ex = new EJBNotFoundException(homeKey.toString() + ".");
			throw new InvalidBeanIdException(ex);
		} else {
			EJSWrapperCommon wrappers;
			if (home.ivHomeWrappers != null) {
				wrappers = home.ivHomeWrappers;
			} else {
				BeanMetaData bmd = home.beanMetaData;
				wrappers = new EJSWrapperCommon(bmd.homeRemoteImplClass, bmd.homeLocalImplClass, id, bmd, home.pmiBean,
						this.container, this.container.getWrapperManager(), true);
			}

			return wrappers;
		}
	}

	public boolean isSingletonSessionHome() {
		return false;
	}

	public final boolean isStatelessSessionHome() {
		return true;
	}

	public final boolean isMessageDrivenHome() {
		return false;
	}

	public final boolean isStatefulSessionHome() {
		return false;
	}

	public BeanMetaData getBeanMetaData(Object homeKey) {
		HomeRecord hr = (HomeRecord) this.homesByName.get(homeKey);
		return hr.bmd;
	}

	public ClassLoader getClassLoader() {
		throw new UnsupportedOperationException();
	}

	public final ActivationStrategy getActivationStrategy() {
		return this.activationStrategy;
	}

	public final String getMethodName(Object homeKey, int id, boolean isHome) {
		HomeRecord hr = (HomeRecord) this.homesByName.get(homeKey);
		return hr.homeInternal.getMethodName(homeKey, id, true);
	}

	public String getEnterpriseBeanClassName(Object homeKey) {
		HomeRecord hr = (HomeRecord) this.homesByName.get(homeKey);
		return hr.homeInternal.getEnterpriseBeanClassName(homeKey);
	}

	public final Handle createHandle(BeanId id) {
		throw new UnsupportedOperationException();
	}

	public void setActivationStrategy(ActivationStrategy a) {
		if (this.activationStrategy != null) {
			throw new IllegalStateException();
		} else {
			this.activationStrategy = a;
		}
	}

	public HomeRecord getHomeRecord(J2EEName name) {
		HomeRecord hr = (HomeRecord) this.homesByName.get(name);
		return hr;
	}

	public List<HomeRecord> getAllHomeRecords() {
		return Collections.list(this.homesByName.elements());
	}

	public void ffdcDump(IncidentStream is) {
		this.introspect(new IncidentStreamWriter(is));
	}

	public void introspect(IntrospectionWriter writer) {
		writer.begin("HomeOfHomes Dump ---> " + this.toString());
		writer.begin("homesByName keys : ");
		List<String> j2eeNameStrings = new ArrayList();
		Enumeration en = this.homesByName.elements();

		while (en.hasMoreElements()) {
			HomeRecord hr = (HomeRecord) en.nextElement();
			j2eeNameStrings.add(hr.getJ2EEName().toString());
		}

		Collections.sort(j2eeNameStrings);
		Iterator i$ = j2eeNameStrings.iterator();

		while (i$.hasNext()) {
			String j2eeNameString = (String) i$.next();
			writer.println(j2eeNameString);
		}

		writer.end();
		if (this.ivVersionedModuleNames.size() > 0) {
			writer.begin("versioned module names : ");
			i$ = this.ivVersionedModuleNames.entrySet().iterator();

			while (i$.hasNext()) {
				Entry<J2EEName, J2EEName> entry = (Entry) i$.next();
				writer.println(entry.getKey() + " --> " + entry.getValue());
			}

			writer.end();
		}

	}
}