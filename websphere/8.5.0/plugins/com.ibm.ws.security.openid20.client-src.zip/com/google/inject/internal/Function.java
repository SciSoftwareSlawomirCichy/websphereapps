package com.google.inject.internal;

public interface Function<F, T> {
	T apply(@Nullable F var1);

	boolean equals(@Nullable Object var1);
}