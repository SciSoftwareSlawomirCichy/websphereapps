package com.ibm.ejs.csi;

public interface UOWHandle {
}