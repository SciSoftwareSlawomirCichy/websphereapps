package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.collect.ImmutableMapKeySet.1;
import com.google.common.collect.ImmutableMapKeySet.KeySetSerializedForm;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
final class ImmutableMapKeySet<K, V> extends ImmutableSet<K> {
	private final ImmutableMap<K, V> map;

	ImmutableMapKeySet(ImmutableMap<K, V> map) {
		this.map = map;
	}

	public int size() {
		return this.map.size();
	}

	public UnmodifiableIterator<K> iterator() {
		return this.asList().iterator();
	}

	public boolean contains(@Nullable Object object) {
		return this.map.containsKey(object);
	}

	ImmutableList<K> createAsList() {
      ImmutableList<Entry<K, V>> entryList = this.map.entrySet().asList();
      return new 1(this, entryList);
   }

	boolean isPartialView() {
		return true;
	}

	@GwtIncompatible("serialization")
	Object writeReplace() {
		return new KeySetSerializedForm(this.map);
	}
}