package com.ibm.icu.impl.locale;

import com.ibm.icu.impl.locale.LanguageTag.ParseStatus;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;

public class LocaleExtensions {
	private SortedMap<Character, Extension> _map;
	private String _id;
	private static final SortedMap<Character, Extension> EMPTY_MAP = Collections.unmodifiableSortedMap(new TreeMap());
	private static final LocaleObjectCache<String, LocaleExtensions> LOCALEEXTENSIONS_CACHE = new LocaleObjectCache();
	public static LocaleExtensions EMPTY_EXTENSIONS = new LocaleExtensions();
	public static final LocaleExtensions CALENDAR_JAPANESE = new LocaleExtensions();
	public static final LocaleExtensions NUMBER_THAI;

	private LocaleExtensions() {
		this._map = EMPTY_MAP;
		this._id = "";
	}

	public static LocaleExtensions getInstance(String str) throws LocaleSyntaxException {
		if (str != null && str.length() != 0) {
			LocaleExtensions exts = (LocaleExtensions) LOCALEEXTENSIONS_CACHE.get(str);
			if (exts == null) {
				StringTokenIterator itr = new StringTokenIterator(str, "-");
				ParseStatus sts = new ParseStatus();
				TreeMap map = new TreeMap();

				while (!itr.isDone()) {
					int startOffset = itr.currentEnd();
					Extension ext = Extension.create(itr, sts);
					if (sts.isError()) {
						throw new LocaleSyntaxException(sts.errorMsg, sts.errorIndex);
					}

					if (ext == null) {
						throw new LocaleSyntaxException("Invalid extension subtag: " + itr.current(), startOffset);
					}

					Character keyChar = ext.getKey();
					if (map.containsKey(keyChar)) {
						throw new LocaleSyntaxException("Duplicated extension: " + keyChar, startOffset);
					}

					map.put(keyChar, ext);
				}

				String id = toID(map);
				exts = (LocaleExtensions) LOCALEEXTENSIONS_CACHE.get(id);
				if (exts == null) {
					exts = new LocaleExtensions();
					exts._map = map;
					exts._id = id;
					exts = (LocaleExtensions) LOCALEEXTENSIONS_CACHE.put(id, exts);
				}
			}

			return exts;
		} else {
			return EMPTY_EXTENSIONS;
		}
	}

	static LocaleExtensions getInstance(SortedMap<Character, Extension> map) {
		if (map != null && !map.isEmpty()) {
			String id = toID(map);
			LocaleExtensions exts = (LocaleExtensions) LOCALEEXTENSIONS_CACHE.get(id);
			if (exts == null) {
				exts = new LocaleExtensions();
				exts._map = new TreeMap(map);
				exts._id = id;
				exts = (LocaleExtensions) LOCALEEXTENSIONS_CACHE.put(id, exts);
			}

			return exts;
		} else {
			return EMPTY_EXTENSIONS;
		}
	}

	private static String toID(SortedMap<Character, Extension> map) {
		StringBuilder buf = new StringBuilder();
		Extension privuse = null;
		if (map != null && !map.isEmpty()) {
			Set<Entry<Character, Extension>> entries = map.entrySet();
			Iterator i$ = entries.iterator();

			while (i$.hasNext()) {
				Entry<Character, Extension> entry = (Entry) i$.next();
				Character key = (Character) entry.getKey();
				if (key == "x".charAt(0)) {
					privuse = (Extension) entry.getValue();
				} else {
					if (buf.length() > 0) {
						buf.append("-");
					}

					buf.append(entry.getKey());
					buf.append("-");
					buf.append(((Extension) entry.getValue()).getValue());
				}
			}
		}

		if (privuse != null) {
			if (buf.length() > 0) {
				buf.append("-");
			}

			buf.append("x");
			buf.append("-");
			buf.append(privuse.getValue());
		}

		return buf.toString();
	}

	public Set<Character> getKeys() {
		return Collections.unmodifiableSet(this._map.keySet());
	}

	public Extension getExtension(Character key) {
		return (Extension) this._map.get(key);
	}

	public String getExtensionValue(Character key) {
		Extension ext = (Extension) this._map.get(key);
		return ext == null ? "" : ext.getValue();
	}

	public Set<String> getUnicodeLocaleKeys() {
		Extension ext = (Extension) this._map.get('u');
		if (ext == null) {
			return Collections.emptySet();
		} else {
			assert ext instanceof UnicodeLocaleExtension;

			return ((UnicodeLocaleExtension) ext).getKeys();
		}
	}

	public String getUnicodeLocaleType(String unicodeLocaleKey) {
		Extension ext = (Extension) this._map.get('u');
		if (ext == null) {
			return "";
		} else {
			assert ext instanceof UnicodeLocaleExtension;

			return ((UnicodeLocaleExtension) ext).getType(unicodeLocaleKey);
		}
	}

	public String toString() {
		return this._id;
	}

	public String getID() {
		return this._id;
	}

	public int hashCode() {
		return this._id.hashCode();
	}

	public static boolean isValidKey(String key) {
		return LanguageTag.isExtensionSingleton(key) || LanguageTag.isPrivateuseSingleton(key);
	}

	static {
		CALENDAR_JAPANESE._id = UnicodeLocaleExtension.CA_JAPANESE.getID();
		CALENDAR_JAPANESE._map = new TreeMap();
		CALENDAR_JAPANESE._map.put(UnicodeLocaleExtension.CA_JAPANESE.getKey(), UnicodeLocaleExtension.CA_JAPANESE);
		LOCALEEXTENSIONS_CACHE.put(CALENDAR_JAPANESE._id, CALENDAR_JAPANESE);
		NUMBER_THAI = new LocaleExtensions();
		NUMBER_THAI._id = UnicodeLocaleExtension.NU_THAI.getID();
		NUMBER_THAI._map = new TreeMap();
		NUMBER_THAI._map.put(UnicodeLocaleExtension.NU_THAI.getKey(), UnicodeLocaleExtension.NU_THAI);
		LOCALEEXTENSIONS_CACHE.put(NUMBER_THAI._id, NUMBER_THAI);
	}
}