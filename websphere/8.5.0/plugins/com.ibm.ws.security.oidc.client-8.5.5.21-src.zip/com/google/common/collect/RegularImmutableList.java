package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;

@GwtCompatible(serializable = true, emulated = true)
class RegularImmutableList<E> extends ImmutableList<E> {
	static final ImmutableList<Object> EMPTY = new RegularImmutableList(new Object[0], 0);
	@VisibleForTesting
	final transient Object[] array;
	private final transient int size;

	RegularImmutableList(Object[] array, int size) {
		this.array = array;
		this.size = size;
	}

	public int size() {
		return this.size;
	}

	boolean isPartialView() {
		return false;
	}

	Object[] internalArray() {
		return this.array;
	}

	int internalArrayStart() {
		return 0;
	}

	int internalArrayEnd() {
		return this.size;
	}

	int copyIntoArray(Object[] dst, int dstOff) {
		System.arraycopy(this.array, 0, dst, dstOff, this.size);
		return dstOff + this.size;
	}

	public E get(int index) {
		Preconditions.checkElementIndex(index, this.size);
		return this.array[index];
	}
}