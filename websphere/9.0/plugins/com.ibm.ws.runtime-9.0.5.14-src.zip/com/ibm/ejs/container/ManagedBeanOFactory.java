package com.ibm.ejs.container;

public class ManagedBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, EJSHome h) {
		return new ManagedBeanO(c, h);
	}
}