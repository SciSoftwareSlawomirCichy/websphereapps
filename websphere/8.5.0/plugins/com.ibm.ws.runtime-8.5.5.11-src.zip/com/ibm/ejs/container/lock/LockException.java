package com.ibm.ejs.container.lock;

import com.ibm.ejs.container.ContainerException;

public class LockException extends ContainerException {
	private static final long serialVersionUID = 932849371367133006L;

	public LockException() {
	}

	public LockException(String s, Throwable ex) {
		super(s, ex);
	}
}