package com.google.inject.internal;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;
import java.util.Map.Entry;

public final class Maps {
	public static <K, V> HashMap<K, V> newHashMap() {
		return new HashMap();
	}

	public static <K, V> LinkedHashMap<K, V> newLinkedHashMap() {
		return new LinkedHashMap();
	}

	public static <K extends Comparable, V> TreeMap<K, V> newTreeMap() {
		return new TreeMap();
	}

	public static <K, V> IdentityHashMap<K, V> newIdentityHashMap() {
		return new IdentityHashMap();
	}

	public static <K, V> Entry<K, V> immutableEntry(@Nullable K key, @Nullable V value) {
		return new ImmutableEntry(key, value);
	}
}