package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.VisibleForTesting;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
final class RegularImmutableSet<E> extends ImmutableSet<E> {
	static final RegularImmutableSet<Object> EMPTY = new RegularImmutableSet(new Object[0], 0, (Object[]) null, 0, 0);
	@VisibleForTesting
	final transient Object[] elements;
	@VisibleForTesting
	final transient Object[] table;
	private final transient int mask;
	private final transient int hashCode;
	private final transient int size;

	RegularImmutableSet(Object[] elements, int hashCode, Object[] table, int mask, int size) {
		this.elements = elements;
		this.table = table;
		this.mask = mask;
		this.hashCode = hashCode;
		this.size = size;
	}

	public boolean contains(@NullableDecl Object target) {
		Object[] table = this.table;
		if (target != null && table != null) {
			int i = Hashing.smearedHash(target);

			while (true) {
				i &= this.mask;
				Object candidate = table[i];
				if (candidate == null) {
					return false;
				}

				if (candidate.equals(target)) {
					return true;
				}

				++i;
			}
		} else {
			return false;
		}
	}

	public int size() {
		return this.size;
	}

	public UnmodifiableIterator<E> iterator() {
		return this.asList().iterator();
	}

	Object[] internalArray() {
		return this.elements;
	}

	int internalArrayStart() {
		return 0;
	}

	int internalArrayEnd() {
		return this.size;
	}

	int copyIntoArray(Object[] dst, int offset) {
		System.arraycopy(this.elements, 0, dst, offset, this.size);
		return offset + this.size;
	}

	ImmutableList<E> createAsList() {
		return ImmutableList.asImmutableList(this.elements, this.size);
	}

	boolean isPartialView() {
		return false;
	}

	public int hashCode() {
		return this.hashCode;
	}

	boolean isHashCodeFast() {
		return true;
	}
}