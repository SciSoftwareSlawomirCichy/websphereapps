package com.ibm.ejs.container;

import com.ibm.ejs.container.activator.Activator;
import com.ibm.ejs.container.interceptors.InterceptorMetaData;
import com.ibm.ejs.csi.EJBModuleMetaDataImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.cpi.Persister;
import com.ibm.websphere.csi.ActivitySessionAttribute;
import com.ibm.websphere.csi.EJBConfigData;
import com.ibm.websphere.csi.GlobalTranConfigData;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.LocalTranConfigData;
import com.ibm.websphere.csi.TransactionAttribute;
import com.ibm.websphere.ejbcontainer.LightweightLocal;
import com.ibm.ws.ejbcontainer.CallbackKind;
import com.ibm.ws.ejbcontainer.EJBComponentMetaData;
import com.ibm.ws.ejbcontainer.EJBMethodInterface;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;
import com.ibm.ws.ejbcontainer.EJBType;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.ws.ejbcontainer.diagnostics.TrDumpWriter;
import com.ibm.ws.ejbcontainer.failover.SfFailoverClient;
import com.ibm.ws.managedobject.ManagedObjectFactory;
import com.ibm.ws.metadata.ejb.BeanInitData;
import com.ibm.ws.metadata.ejb.WCCMMetaData;
import com.ibm.ws.resource.ResourceRefConfigList;
import com.ibm.ws.runtime.metadata.MetaDataImpl;
import com.ibm.ws.runtime.metadata.ModuleMetaData;
import com.ibm.wsspi.injectionengine.InjectionBinding;
import com.ibm.wsspi.injectionengine.InjectionTarget;
import com.ibm.wsspi.injectionengine.ReferenceContext;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import javax.ejb.TimedObject;
import javax.naming.Context;

public class BeanMetaData extends MetaDataImpl implements EJBComponentMetaData {
	private static final TraceComponent tc = Tr.register(BeanMetaData.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	public static final Class<TimedObject> svTimedObjectClass = TimedObject.class;
	public static final Method svTimedObjectMethod;
	public static final int ACCESS_INTENT_READ = 0;
	public static final int ACCESS_INTENT_UPDATE = 1;
	public static final int ACTIVATION_POLICY_ONCE = 0;
	public static final int ACTIVATION_POLICY_ACTIVITY_SESSION = 1;
	public static final int ACTIVATION_POLICY_TRANSACTION = 2;
	public static final int CONCURRENCY_CONTROL_PESSIMISTIC = 0;
	public static final int CONCURRENCY_CONTROL_OPTIMISTIC = 1;
	public static final int J2EE_EJB_VERSION_UNKNOWN = 0;
	public static final int J2EE_EJB_VERSION_1_0 = 10;
	public static final int J2EE_EJB_VERSION_1_1 = 11;
	public static final int J2EE_EJB_VERSION_2_0 = 20;
	public static final int J2EE_EJB_VERSION_2_1 = 21;
	public static final int J2EE_EJB_VERSION_3_0 = 30;
	public static final int J2EE_EJB_VERSION_3_1 = 31;
	private static final int JAVAEE_VERSION_5 = 50;
	public static final int LOAD_POLICY_ACTIVATION = 0;
	public static final int LOAD_POLICY_TRANSACTION = 1;
	public static final int LOAD_POLICY_INTERVAL = 2;
	public static final int LOAD_POLICY_DAILY = 3;
	public static final int LOAD_POLICY_WEEKLY = 4;
	public static final int LOCAL_TX_UNRESOLVED_ACTION_ROLLBACK = 0;
	public static final int LOCAL_TX_UNRESOLVED_ACTION_COMMIT = 1;
	public static final int METHOD_TYPE_UNSPECIFIED = 0;
	public static final int METHOD_TYPE_REMOTE = 1;
	public static final int METHOD_TYPE_REMOTE_HOME = 2;
	public static final int METHOD_TYPE_LOCAL = 3;
	public static final int METHOD_TYPE_LOCAL_HOME = 4;
	public static final int METHOD_TYPE_SERVICE_ENDPOINT = 5;
	public static final int PERSISTENCE_BEAN_MANAGED = 0;
	public static final int PERSISTENCE_CONTAINER_MANAGED = 1;
	public static final int PIN_POLICY_ACTIVATION_PERIOD = 0;
	public static final int PIN_POLICY_ACTIVITY_SESSION = 1;
	public static final int PIN_POLICY_TRANSACTION = 2;
	public static final int PIN_POLICY_BUSINESS_METHOD = 3;
	public static final int TX_ATTRIBUTE_TYPE_NOT_SUPPORTED = 0;
	public static final int TX_ATTRIBUTE_TYPE_SUPPORTS = 1;
	public static final int TX_ATTRIBUTE_TYPE_REQUIRED = 2;
	public static final int TX_ATTRIBUTE_TYPE_REQUIRES_NEW = 3;
	public static final int TX_ATTRIBUTE_TYPE_MANDATORY = 4;
	public static final int TX_ATTRIBUTE_TYPE_NEVER = 5;
	public static final int TX_ATTRIBUTE_TYPE_BEAN_MANAGED = 6;
	public static final int TX_BEAN_MANAGED = 0;
	public static final int TX_CONTAINER_MANAGED = 1;
	public static final int TX_ISOLATION_LEVEL_REPEATABLE_READ = 0;
	public static final int TX_ISOLATION_LEVEL_READ_COMMITTED = 1;
	public static final int TX_ISOLATION_LEVEL_READ_UNCOMMITTED = 2;
	public static final int TX_ISOLATION_LEVEL_SERIALIZABLE = 3;
	public BeanInitData ivInitData;
	public Context _javaNameSpaceContext;
	public EJBModuleMetaDataImpl _moduleMetaData;
	public ResourceRefConfigList _resourceRefList;
	public LocalTranConfigData _localTran;
	public GlobalTranConfigData _globalTran;
	public J2EEName j2eeName;
	public J2EEName ivUnversionedJ2eeName;
	public int type;
	public List<J2EEName> ivDependsOn;
	public static final String[] entityRemoteNoTxAttrMethods;
	public static final String[] entityRemoteNoTxAttrMethodSignatures;
	public static final String[] entityLocalNoTxAttrMethods;
	public static final String[] entityLocalNoTxAttrMethodSignatures;
	public static final String[] entityRemoteHomeNoTxAttrMethods;
	public static final String[] entityRemoteHomeNoTxAttrMethodSignatures;
	public static final String[] entityLocalHomeNoTxAttrMethods;
	public static final String[] entityLocalHomeNoTxAttrMethodSignatures;
	public static final String[] sessionLocalHomeNoTxAttrMethods;
	public static final String[] sessionLocalHomeNoTxAttrMethodSignatures;
	public static final String[] sessionRemoteHomeNoTxAttrMethods;
	public static final String[] sessionRemoteHomeNoTxAttrMethodSignatures;
	public int ivModuleVersion;
	public String enterpriseBeanClassName;
	public Class<?> enterpriseBeanClass;
	public Class<?> enterpriseBeanAbstractClass;
	public Class<?> homeBeanClass;
	public ManagedObjectFactory ivEnterpriseBeanFactory;
	public boolean fullyInitialized = false;
	public Class<?> pKeyClass;
	public boolean m_syncToOSThreadValue;
	public Set<String> ivPersistenceRefNames;
	public Object[] ivExPcPuIds;
	public String homeInterfaceClassName;
	public Class<?> homeInterfaceClass;
	public Class<?> remoteInterfaceClass;
	public Class<?> remoteImplClass;
	public Class<?> remoteTieClass;
	public Class<?> homeRemoteImplClass;
	public Class<?> homeRemoteTieClass;
	public String localHomeInterfaceClassName;
	public Class<?> localHomeInterfaceClass;
	public Class<?> localInterfaceClass;
	public Class<?> localImplClass;
	public Constructor<?> localImplProxyConstructor;
	public Class<?> homeLocalImplClass;
	public Constructor<?> homeLocalImplProxyConstructor;
	public boolean ivHasWebServiceEndpoint;
	public Class<?> webserviceEndpointInterfaceClass;
	public String ivWebServiceEndpointProxyName;
	public Class<?> ivWebServiceEndpointProxyClass;
	public boolean ivWebServiceEndpointCreated;
	public String[] ivBusinessLocalInterfaceClassNames;
	public Class<?>[] ivBusinessLocalInterfaceClasses;
	public String[] ivBusinessRemoteInterfaceClassNames;
	public Class<?>[] ivBusinessRemoteInterfaceClasses;
	public Class<?>[] ivBusinessLocalImplClasses;
	public Constructor<?>[] ivBusinessLocalImplProxyConstructors;
	public Class<?>[] ivBusinessRemoteImplClasses;
	public Class<?>[] ivBusinessRemoteTieClasses;
	public Class<?> ivAggregateLocalImplClass;
	public boolean ivLocalBean = false;
	public Field ivLocalBeanContainerField;
	public Field ivLocalBeanWrapperField;
	public Field ivManagedBeanBeanOField;
	public boolean ivIndirectLocalProxies;
	public Field[] cmpResetFields;
	public String connFactoryName;
	public Properties envProps;
	public String simpleJndiBindingName = null;
	public String localHomeJndiBindingName = null;
	public String remoteHomeJndiBindingName = null;
	public String ivRemoteHomeJndiName = null;
	public String ivLocalHomeJndiName = null;
	public Map<String, String> businessInterfaceJndiBindingNames = null;
	public String enterpriseBeanName;
	public boolean reentrant;
	public long sessionTimeout;
	public boolean ivSFSBFailover = false;
	public SfFailoverClient ivSfFailoverClient = null;
	public boolean sessionActivateTran = false;
	public boolean sessionActivateSession = false;
	public boolean optionACommitOption = false;
	public boolean optionBCommitOption = false;
	public boolean optionCCommitOption = false;
	public boolean ivReadOnlyCommitOption = false;
	public boolean entitySessionalTranOption = false;
	public boolean optimisticConcurrencyControl = false;
	public static final int CACHE_RELOAD_NONE = 0;
	public static final int CACHE_RELOAD_INTERVAL = 1;
	public static final int CACHE_RELOAD_DAILY = 2;
	public static final int CACHE_RELOAD_WEEKLY = 3;
	public int ivCacheReloadType = 0;
	public long ivCacheReloadInterval = -1L;
	public int activationPolicy;
	public String[] methodNames;
	public String[] localMethodNames;
	public String[] timedMethodNames;
	public String[] wsEndpointMethodNames;
	public String[] lifecycleInterceptorMethodNames;
	public EJBMethodInfoImpl[] methodInfos;
	public EJBMethodInfoImpl[] localMethodInfos;
	public EJBMethodInfoImpl[] timedMethodInfos;
	public EJBMethodInfoImpl[] wsEndpointMethodInfos;
	public EJBMethodInfoImpl[] lifecycleInterceptorMethodInfos;
	public int[] isolationAttrs;
	public boolean[] readOnlyAttrs;
	public String[] homeMethodNames;
	public String[] localHomeMethodNames;
	public EJBMethodInfoImpl[] homeMethodInfos;
	public EJBMethodInfoImpl[] localHomeMethodInfos;
	public int[] homeIsolationAttrs;
	public boolean[] homeReadOnlyAttrs;
	public boolean commitDanglingWork = false;
	protected boolean ivHasInheritance = false;
	public boolean ivHasAppManagedPersistenceContext = false;
	public boolean ivHasCMExtendedPersistenceContext = false;
	public boolean usesBeanManagedTx;
	public boolean usesBeanManagedAS = false;
	public int cmpVersion;
	public Persister persister;
	public ClassLoader classLoader;
	public ClassLoader ivContextClassLoader;
	public EJBConfigData ejbConfigData;
	public int minPoolSize;
	public int maxPoolSize;
	public int allowCachedTimerDataForMethods = 0;
	public int ivInitialPoolSize = 0;
	public int ivMaxCreation = 0;
	public long ivMaxCreationTimeout = 300000L;
	public boolean isPreFindFlushEnabled = true;
	public boolean isCleanEJBStoreEnabled = true;
	public static boolean fbpkReadOnlyOverrideAllBeans;
	public static boolean allowCustomFinderSQLForUpdateALLBeans;
	public boolean allowCustomFinderSQLForUpdateThisBean = false;
	public boolean allowCustomFinderSQLForUpdateMethodLevel = false;
	public boolean allowWAS390CustomFinderAtBeanLevel = false;
	public static final int CF_METHOD_NAME_OFFSET = 0;
	public static final int CF_METHOD_SIG_OFFSET = 1;
	public boolean isTimedObject = false;
	public Method ivTimeoutMethod = null;
	public boolean isLightweight = false;
	public String ivActivationSpecJndiName = null;
	public String ivActivationSpecAuthAlias = null;
	public String ivMessageDestinationJndiName = null;
	public String ivMessageListenerPortName;
	public String ivMessagingTypeClassName = null;
	public int ivApplicationVersionId = 50;
	public Properties ivActivationConfig;
	public boolean ivDeferEJBInitialization = true;
	public Object ivCluster = null;
	public InjectionTarget[] ivBeanInjectionTargets;
	public Map<String, InjectionBinding<?>> ivJavaColonCompEnvMap;
	public WCCMMetaData wccm;
	public String ivComponent_Id = null;
	public int removeTxAttr;
	public EJSContainer container;
	public HomeRecord homeRecord;
	public List<?> accessIntentList;
	public List<?> isoLevelList;
	public CallbackKind ivCallbackKind;
	public InterceptorMetaData ivInterceptorMetaData;
	public HashMap<String, String> ivInitMethodMap;
	public HashMap<String, String> ivRoleLinkMap;
	public boolean metadataComplete;
	public boolean ivUseCallerIdentity;
	public String ivRunAs;
	public Method ivEjbCreateMethod;
	public boolean ivMetaDataDestroyRequired;
	public boolean supportsFluffOnFind;
	public boolean ivSingletonUsesBeanManagedConcurrency;
	public boolean ivHasAsynchMethod;
	public Method ivAfterBegin;
	public Method ivBeforeCompletion;
	public Method ivAfterCompletion;
	public Method[] methodsExposedOnLocalInterface;
	public Method[] methodsExposedOnRemoteInterface;
	public Method[] methodsExposedOnLocalHomeInterface;
	public Method[] methodsExposedOnRemoteHomeInterface;
	public Method[] allPublicMethodsOnBean;
	public Map<Method, ArrayList<EJBMethodInfoImpl>> methodsToMethodInfos;
	public ReferenceContext ivReferenceContext;
	public volatile Map<String, Map<String, Field>> ivPassivatorFields;

	public boolean hasRemoteHome() {
		return this.homeInterfaceClass != null;
	}

	public boolean hasLocalHome() {
		return this.localHomeInterfaceClass != null;
	}

	public int getActivationPolicy() {
		return this.activationPolicy;
	}

	public BeanMetaData(int slotSize) {
		super(slotSize);
		this.ivCallbackKind = CallbackKind.None;
		this.ivInterceptorMetaData = null;
		this.ivInitMethodMap = null;
		this.ivRoleLinkMap = null;
		this.metadataComplete = false;
		this.ivUseCallerIdentity = false;
		this.ivRunAs = null;
		this.ivMetaDataDestroyRequired = false;
		this.supportsFluffOnFind = false;
		this.ivSingletonUsesBeanManagedConcurrency = false;
		this.ivHasAsynchMethod = false;
		this.ivAfterBegin = null;
		this.ivBeforeCompletion = null;
		this.ivAfterCompletion = null;
		this.methodsExposedOnLocalInterface = null;
		this.methodsExposedOnRemoteInterface = null;
		this.methodsExposedOnLocalHomeInterface = null;
		this.methodsExposedOnRemoteHomeInterface = null;
		this.allPublicMethodsOnBean = null;
		this.methodsToMethodInfos = null;
	}

	public boolean isEntityBean() {
		return this.type == 6 || this.type == 5;
	}

	public boolean isSessionBean() {
		return this.type == 2 || this.type == 3 || this.type == 4;
	}

	public boolean isSingletonSessionBean() {
		return this.type == 2;
	}

	public boolean isStatelessSessionBean() {
		return this.type == 3;
	}

	public boolean isStatefulSessionBean() {
		return this.type == 4;
	}

	public boolean isMessageDrivenBean() {
		return this.type == 7;
	}

	public boolean isManagedBean() {
		return this.type == 8;
	}

	public Class<?> getLocalHomeInterface() {
		return this.localHomeInterfaceClass;
	}

	public Class<?> getRemoteHomeImpl() {
		return this.homeRemoteImplClass;
	}

	public int getEJBTransactionPolicy() {
		return this.usesBeanManagedTx ? 1 : 2;
	}

	public int getLocalBusinessInterfaceIndex(String interfaceName) {
		if (this.ivBusinessLocalInterfaceClasses != null) {
			for (int i = 0; i < this.ivBusinessLocalInterfaceClasses.length; ++i) {
				String bInterfaceName = this.ivBusinessLocalInterfaceClasses[i].getName();
				if (bInterfaceName.equals(interfaceName)) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "getLocalBusinessInterfaceIndex : " + bInterfaceName + " at index " + i);
					}

					return i;
				}
			}
		}

		return -1;
	}

	public int getAssignableLocalBusinessInterfaceIndex(Class<?> target) {
		if (this.ivBusinessLocalInterfaceClasses != null) {
			for (int i = 0; i < this.ivBusinessLocalInterfaceClasses.length; ++i) {
				Class<?> bInterface = this.ivBusinessLocalInterfaceClasses[i];
				if (target.isAssignableFrom(bInterface)) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "getAssignableLocalBusinessInterfaceIndex : " + bInterface.getName() + " at index "
								+ i);
					}

					return i;
				}
			}
		}

		return -1;
	}

	public int getRequiredLocalBusinessInterfaceIndex(String interfaceName) throws IllegalStateException {
		int interfaceIndex = this.getLocalBusinessInterfaceIndex(interfaceName);
		if (interfaceIndex == -1) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"getRequiredLocalBusinessInterfaceIndex : IllegalStateException : Requested business interface not found : "
								+ interfaceName);
			}

			throw new IllegalStateException("Requested business interface not found : " + interfaceName);
		} else {
			return interfaceIndex;
		}
	}

	public int getSupportingLocalBusinessInterfaceIndex(String interfaceName)
			throws ClassNotFoundException, EJBConfigurationException {
		int interfaceIndex = this.getLocalBusinessInterfaceIndex(interfaceName);
		if (interfaceIndex == -1) {
			Class<?> target = this.classLoader.loadClass(interfaceName);
			interfaceIndex = this.getAssignableLocalBusinessInterfaceIndex(target);
			if (interfaceIndex == -1) {
				Tr.error(tc, "ATTEMPT_TO_REFERENCE_MISSING_INTERFACE_CNTR0154E",
						new Object[]{this.enterpriseBeanName, this._moduleMetaData.ivName, interfaceName});
				EJBConfigurationException ejbex = new EJBConfigurationException(
						"Another component is attempting to reference local interface: " + interfaceName
								+ " which is not implemented by bean: " + this.j2eeName);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getSupportingLocalBusinessInterfaceIndex : " + ejbex);
				}

				throw ejbex;
			}
		}

		return interfaceIndex;
	}

	public int getRemoteBusinessInterfaceIndex(String interfaceName) {
		if (this.ivBusinessRemoteInterfaceClasses != null) {
			for (int i = 0; i < this.ivBusinessRemoteInterfaceClasses.length; ++i) {
				String bInterface = this.ivBusinessRemoteInterfaceClasses[i].getName();
				if (bInterface.equals(interfaceName)) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "getRemoteBusinessInterfaceIndex : " + bInterface + " at index " + i);
					}

					return i;
				}
			}
		}

		return -1;
	}

	public int getAssignableRemoteBusinessInterfaceIndex(Class<?> target) {
		if (this.ivBusinessRemoteInterfaceClasses != null) {
			for (int i = 0; i < this.ivBusinessRemoteInterfaceClasses.length; ++i) {
				Class<?> bInterface = this.ivBusinessRemoteInterfaceClasses[i];
				if (target.isAssignableFrom(bInterface)) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "getAssignableRemoteBusinessInterfaceIndex : " + bInterface.getName()
								+ " at index " + i);
					}

					return i;
				}
			}
		}

		return -1;
	}

	public int getRequiredRemoteBusinessInterfaceIndex(String interfaceName) throws IllegalStateException {
		int interfaceIndex = this.getRemoteBusinessInterfaceIndex(interfaceName);
		if (interfaceIndex == -1) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"getRequiredRemoteBusinessInterfaceIndex : IllegalStateException : Requested business interface not found : "
								+ interfaceName);
			}

			throw new IllegalStateException("Requested business interface not found : " + interfaceName);
		} else {
			return interfaceIndex;
		}
	}

	public int getSupportingRemoteBusinessInterfaceIndex(String interfaceName)
			throws ClassNotFoundException, EJBConfigurationException {
		int interfaceIndex = this.getRemoteBusinessInterfaceIndex(interfaceName);
		if (interfaceIndex == -1) {
			Class<?> target = this.classLoader.loadClass(interfaceName);
			interfaceIndex = this.getAssignableRemoteBusinessInterfaceIndex(target);
			if (interfaceIndex == -1) {
				Tr.error(tc, "ATTEMPT_TO_REFERENCE_MISSING_INTERFACE_CNTR0154E",
						new Object[]{this.enterpriseBeanName, this._moduleMetaData.ivName, interfaceName});
				EJBConfigurationException ejbex = new EJBConfigurationException(
						"Another component is attempting to reference local interface: " + interfaceName
								+ " which is not implemented by bean: " + this.j2eeName);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getSupportingRemoteBusinessInterfaceIndex : " + ejbex);
				}

				throw ejbex;
			}
		}

		return interfaceIndex;
	}

	public void dump() {
		if (TraceComponent.isAnyTracingEnabled() && (tc.isDumpEnabled() || tc.isDebugEnabled())) {
			this.introspect(new TrDumpWriter(tc));
		}
	}

	public void introspect(IntrospectionWriter writer) {
		if (this.fullyInitialized) {
			String singletonConcurrency = "not applicable";
			if (this.isSingletonSessionBean()) {
				if (this.ivSingletonUsesBeanManagedConcurrency) {
					singletonConcurrency = "bean managed";
				} else {
					singletonConcurrency = "container managed";
				}
			}

			String[] allData = new String[]{this.toIntrospectString(),
					"Application version         = " + this.ivApplicationVersionId,
					"CMP version                 = " + this.cmpVersion,
					"SupportsFluffOnFind         = " + this.supportsFluffOnFind,
					"SimpleBindingName           = " + this.simpleJndiBindingName,
					"LocalHomeBindingName        = " + this.localHomeJndiBindingName,
					"RemoteHomeBindingName       = " + this.remoteHomeJndiBindingName,
					"BusinessIntfBindingNames    = " + this.businessInterfaceJndiBindingNames,
					"HomeInterfaceClassName      = " + this.homeInterfaceClassName,
					"HomeInterfaceClass          = " + this.homeInterfaceClass,
					"RemoteInterfaceClass        = " + this.remoteInterfaceClass,
					"RemoteImplClass             = " + this.remoteImplClass,
					"HomeRemoteImplClass         = " + this.homeRemoteImplClass,
					"LocalHomeInterfaceClass     = " + this.localHomeInterfaceClass,
					"LocalInterfaceClass         = " + this.localInterfaceClass,
					"LocalImplClass              = " + this.localImplClass,
					"HomeLocalImplClass          = " + this.homeLocalImplClass,
					"HasWebServiceEndpoint       = " + this.ivHasWebServiceEndpoint,
					"WebService Endpoint Class   = " + this.webserviceEndpointInterfaceClass,
					"WebService Endpoint Proxy   = " + this.ivWebServiceEndpointProxyClass,
					"BusinessRemoteInterfaceClass= " + Arrays.toString(this.ivBusinessRemoteInterfaceClasses),
					"BusinessRemoteImplClass     = " + Arrays.toString(this.ivBusinessRemoteImplClasses),
					"No-Interface View           = " + this.ivLocalBean,
					"BusinessLocalInterfaceClass = " + Arrays.toString(this.ivBusinessLocalInterfaceClasses),
					"BusinessLocalImplClass      = " + Arrays.toString(this.ivBusinessLocalImplClasses),
					"EnterpriseBeanClass         = " + this.enterpriseBeanClass,
					"EnterpriseBeanAbstractClass = " + this.enterpriseBeanAbstractClass,
					"pKeyClass                   = " + this.pKeyClass, "J2EE Name                   = " + this.j2eeName,
					"Unversioned J2EE Name       = " + this.ivUnversionedJ2eeName,
					"Cluster Identity            = " + this.ivCluster,
					"ActivationSpecJndiName      = " + this.ivActivationSpecJndiName,
					"MessageDestinationJndiName  = " + this.ivMessageDestinationJndiName,
					"Connection factory name     = " + this.connFactoryName,
					"Pool Size (min,max)         = (" + this.minPoolSize + "," + this.maxPoolSize + ")",
					"Initial Pool Size           = " + this.ivInitialPoolSize,
					"Max Beans Created           = " + this.ivMaxCreation,
					"Max Beans Created Timeout   = " + this.ivMaxCreationTimeout,
					"TimedObject                 = " + this.isTimedObject,
					"Reentrant                   = " + this.reentrant,
					"Session Timeout             = " + this.sessionTimeout,
					"PreFindFlush                = " + this.isPreFindFlushEnabled,
					"Commit Option               = " + this.getCommitOptionString(),
					"Cache Reload Interval       = " + this.getCacheReloadIntervalString(),
					"LightweightLocal            = " + this.isLightweight,
					"AllowCachedTimerDataFor     = " + this.allowCachedTimerDataForMethods,
					"DeferredInit                = " + this.ivDeferEJBInitialization,
					"Security RunAs              = " + this.ivRunAs,
					"Interceptor CallbackKind    = " + this.ivCallbackKind,
					"InjectionTargets            = " + Arrays.toString(this.ivBeanInjectionTargets),
					"Component Id                = " + this.ivComponent_Id,
					"Metadata Complete           = " + this.metadataComplete,
					"Has Ext CM Persist. Cntx.   = " + this.ivHasCMExtendedPersistenceContext,
					"Has App Man Persit. Cntx.   = " + this.ivHasAppManagedPersistenceContext,
					"Persistence Ref Names       = " + this.ivPersistenceRefNames,
					"ExPC Ids                    = " + Arrays.toString(this.ivExPcPuIds),
					"WebService Endpoint Created = " + this.ivWebServiceEndpointCreated,
					"Component NameSpace :  nsid = " + this.getJavaNameSpaceID(),
					"Has aysnchronous method(s)  = " + this.ivHasAsynchMethod,
					"Singleton Concurrency Type  = " + singletonConcurrency,
					"Synch AfterBegin            = " + this.ivAfterBegin,
					"Synch BeforeCompletion      = " + this.ivBeforeCompletion,
					"Synch AfterCompletion       = " + this.ivAfterCompletion,
					"Application Classloader     = " + this.classLoader, "Context class loader        = "
							+ (this.classLoader == this.ivContextClassLoader ? "(same)" : this.ivContextClassLoader)};
			writer.printHeader("BeanMetaData Dump");
			writer.dump((String) null, allData);
			int i;
			if (this.methodInfos != null) {
				writer.println();
				writer.printHeading(1, "Remote Methods : " + this.methodInfos.length);
				writer.indent();

				for (i = 0; i < this.methodInfos.length; ++i) {
					writer.println();
					this.methodInfos[i].introspect(writer, "Remote", i, true);
				}

				writer.outdent();
			}

			if (this.homeMethodInfos != null) {
				writer.println();
				writer.printHeading(1, "Home Methods : " + this.homeMethodInfos.length);
				writer.indent();

				for (i = 0; i < this.homeMethodInfos.length; ++i) {
					writer.println();
					this.homeMethodInfos[i].introspect(writer, "Remote Home", i, true);
				}

				writer.outdent();
			}

			if (this.localMethodInfos != null) {
				writer.println();
				writer.printHeading(1, "Local Methods : " + this.localMethodInfos.length);
				writer.indent();

				for (i = 0; i < this.localMethodInfos.length; ++i) {
					writer.println();
					this.localMethodInfos[i].introspect(writer, "Local", i, true);
				}

				writer.outdent();
			}

			if (this.localHomeMethodInfos != null) {
				writer.println();
				writer.printHeading(1, "Local Home Methods : " + this.localHomeMethodInfos.length);
				writer.indent();

				for (i = 0; i < this.localHomeMethodInfos.length; ++i) {
					writer.println();
					this.localHomeMethodInfos[i].introspect(writer, "Local Home", i, true);
				}

				writer.outdent();
			}

			if (this.wsEndpointMethodInfos != null
					&& (this.webserviceEndpointInterfaceClass != null || this.ivWebServiceEndpointCreated)) {
				writer.println();
				writer.printHeading(1, "WebService Endpoint Methods : " + this.wsEndpointMethodInfos.length);
				writer.indent();

				for (i = 0; i < this.wsEndpointMethodInfos.length; ++i) {
					writer.println();
					this.wsEndpointMethodInfos[i].introspect(writer, "Service Endpoint", i, true);
				}

				writer.outdent();
			}

			if (this.timedMethodInfos != null) {
				writer.println();
				writer.printHeading(1, "Timer Methods : " + this.timedMethodInfos.length);
				writer.indent();

				for (i = 0; i < this.timedMethodInfos.length; ++i) {
					writer.println();
					this.timedMethodInfos[i].introspect(writer, "Timer", i, true);
				}

				writer.outdent();
			}

			if (this.lifecycleInterceptorMethodInfos != null) {
				writer.println();
				writer.printHeading(1,
						"Lifecycle Interceptor Methods : " + this.lifecycleInterceptorMethodInfos.length);
				writer.indent();

				for (i = 0; i < this.lifecycleInterceptorMethodInfos.length; ++i) {
					writer.println();
					this.lifecycleInterceptorMethodInfos[i].introspect(writer, "Lifecycle", i, true);
				}

				writer.outdent();
			}

			writer.printFooter();
		} else {
			String[] partialData = new String[]{this.toIntrospectString(),
					"Application version         = " + this.ivApplicationVersionId,
					"CMP version                 = " + this.cmpVersion,
					"SimpleBindingName           = " + this.simpleJndiBindingName,
					"LocalHomeBindingName        = " + this.localHomeJndiBindingName,
					"RemoteHomeBindingName       = " + this.remoteHomeJndiBindingName,
					"BusinessIntfBindingNames    = " + this.businessInterfaceJndiBindingNames,
					"HomeInterfaceClassName      = " + this.homeInterfaceClassName,
					"HasWebServiceEndpoint       = " + this.ivHasWebServiceEndpoint,
					"No-Interface View           = " + this.ivLocalBean,
					"J2EE Name                   = " + this.j2eeName,
					"Unversioned J2EE Name       = " + this.ivUnversionedJ2eeName,
					"Connection factory name     = " + this.connFactoryName,
					"DeferredInit                = " + this.ivDeferEJBInitialization,
					"Metadata Complete           = " + this.metadataComplete,
					"Component Id                = " + this.ivComponent_Id,
					"Application Classloader     = " + this.classLoader};
			writer.printHeader("Partial BeanMetaData Dump");
			writer.dump((String) null, partialData);
			writer.printFooter();
		}

	}

	private String getCommitOptionString() {
		byte strategy;
		switch (this.type) {
			case 2 :
			case 3 :
			case 7 :
				strategy = 0;
				break;
			case 4 :
				if (this.sessionActivateTran) {
					strategy = 2;
				} else if (this.sessionActivateSession) {
					strategy = 3;
				} else {
					strategy = 1;
				}
				break;
			case 5 :
			case 6 :
				if (this.optionACommitOption) {
					strategy = 4;
				} else if (this.optionBCommitOption) {
					strategy = 5;
				} else if (this.entitySessionalTranOption) {
					strategy = 7;
				} else if (this.ivReadOnlyCommitOption) {
					strategy = 8;
				} else {
					strategy = 6;
				}
				break;
			default :
				strategy = -1;
		}

		return Activator.getActivationStrategyString(strategy);
	}

	private String getCacheReloadIntervalString() {
		String reload;
		switch (this.ivCacheReloadType) {
			case 0 :
				reload = "N/A";
				break;
			case 1 :
				reload = "INTERVAL (" + this.ivCacheReloadInterval + ")";
				break;
			case 2 :
				reload = "DAILY (" + this.ivCacheReloadInterval + ")";
				break;
			case 3 :
				reload = "WEEKLY (" + this.ivCacheReloadInterval + ")";
				break;
			default :
				reload = "UNKNOWN (" + this.ivCacheReloadInterval + ")";
		}

		return reload;
	}

	public static long convertDDAbsoluteReloadToMillis(int ddInterval, int reloadType) {
		long millis = 0L;
		if (ddInterval >= 0) {
			switch (reloadType) {
				case 3 :
					if (ddInterval >= 10000) {
						millis += (long) ((ddInterval / 10000 - 1) * 24 * 60 * 60 * 1000);
						ddInterval %= 10000;
					}
				case 2 :
					if (ddInterval <= 2359) {
						millis += (long) ((ddInterval / 100 * 60 + ddInterval % 100) * 60 * 1000);
					}
					break;
				default :
					throw new IllegalArgumentException();
			}
		}

		return millis;
	}

	public final SfFailoverClient getSfFailoverClient() {
		return this.ivSfFailoverClient;
	}

	public EJSHome getHome() {
		return this.homeRecord.getHome();
	}

	public J2EEName getJ2EEName() {
		return this.j2eeName;
	}

	public ModuleMetaData getModuleMetaData() {
		return this._moduleMetaData;
	}

	public String getName() {
		return this.j2eeName.getComponent();
	}

	public void release() {
	}

	public Context getJavaNameSpaceContext() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc,
					"getJavaNameSpaceContext: nsID=" + this.getJavaNameSpaceID() + "  :  J2EEName = " + this.j2eeName);
		}

		return this._javaNameSpaceContext;
	}

	public void setJavaNameSpace(Object jns) {
	}

	protected int getJavaNameSpaceID() {
		return -1;
	}

	public LocalTranConfigData getLocalTran() {
		return this._localTran;
	}

	public LocalTranConfigData getLocalTranConfigData() {
		return this._localTran;
	}

	public GlobalTranConfigData getGlobalTranConfigData() {
		return this._globalTran;
	}

	public String getBeanClassName() {
		return this.enterpriseBeanClassName;
	}

	public String getJndiName() {
		String returnValue = this.simpleJndiBindingName;
		if (returnValue == null || returnValue.equals("")) {
			returnValue = this.ivRemoteHomeJndiName;
			if (returnValue == null || returnValue.equals("")) {
				returnValue = this.ivLocalHomeJndiName;
			}
		}

		return returnValue;
	}

	public int getEJBComponentType() {
		return this.type;
	}

	public EJBType getEJBType() {
		return EJBType.forValue(this.type);
	}

	public EJBMethodInfoImpl createEJBMethodInfoImpl(int slotSize) {
		return new EJBMethodInfoImpl(slotSize);
	}

	public List<EJBMethodMetaData> getEJBMethodMetaData(EJBMethodInterface methodInterface) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBMethodMetaData: " + methodInterface);
		}

		EJBMethodMetaData[] methodMetaDatas = null;
		if (methodInterface == EJBMethodInterface.REMOTE) {
			methodMetaDatas = this.methodInfos;
		} else if (methodInterface == EJBMethodInterface.HOME) {
			methodMetaDatas = this.homeMethodInfos;
		} else if (methodInterface == EJBMethodInterface.LOCAL) {
			if (this.type == 7) {
				methodMetaDatas = null;
			} else {
				methodMetaDatas = this.localMethodInfos;
			}
		} else if (methodInterface == EJBMethodInterface.LOCAL_HOME) {
			methodMetaDatas = this.localHomeMethodInfos;
		} else if (methodInterface == EJBMethodInterface.SERVICE_ENDPOINT) {
			methodMetaDatas = this.wsEndpointMethodInfos;
		} else if (methodInterface == EJBMethodInterface.MESSAGE_ENDPOINT) {
			if (this.type == 7) {
				methodMetaDatas = this.localMethodInfos;
			} else {
				methodMetaDatas = null;
			}
		} else if (methodInterface == EJBMethodInterface.TIMER) {
			methodMetaDatas = this.timedMethodInfos;
		} else {
			if (methodInterface != EJBMethodInterface.LIFECYCLE_INTERCEPTOR) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBMethodMetaData: Invalid MethodInterface");
				}

				throw new IllegalArgumentException("Invalid MethodInterface");
			}

			methodMetaDatas = this.lifecycleInterceptorMethodInfos;
		}

		List<EJBMethodMetaData> result = methodMetaDatas == null ? null : Arrays.asList(methodMetaDatas);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEJBMethodMetaData: " + result);
		}

		return result;
	}

	public boolean isReentrant() {
		return this.reentrant;
	}

	public int getCMPVersion() {
		return this.cmpVersion;
	}

	public int getEJBModuleVersion() {
		return this.ivModuleVersion;
	}

	public int getApplicationVersionId() {
		return this.ivApplicationVersionId;
	}

	public void validate() throws EJBConfigurationException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "validate " + this.j2eeName);
		}

		boolean asAttributesDefined = false;
		if (this.ivModuleVersion <= 11) {
			if (1 == this.activationPolicy) {
				Tr.error(tc, "INVALID_ACTIVITY_SESSION_POLICY_CNTR0069E", this.enterpriseBeanClassName);
				throw new EJBConfigurationException(
						"ACTIVITY_SESSION_ACTIVATION_POLICY_INVALID_WITH_EJB_MODULE_LEVEL_1_1 for "
								+ this.enterpriseBeanClassName);
			}

			if (1 == this._localTran.getValueBoundary()) {
				Tr.error(tc, "INVALID_ACTIVITY_SESSION_POLICY_CNTR0070E", this.enterpriseBeanClassName);
				throw new EJBConfigurationException(
						"LOCAL_TRANSACTION_BOUNDARY_ACTIVITY_SESSION_INVALID_WITH_EJB_MODULE_LEVEL_1_1 for "
								+ this.enterpriseBeanClassName);
			}

			if (1 == this._localTran.getValueResolver() && this.type != 6) {
				Tr.error(tc, "INVALID_LOCAL_TRANSACTION_RESOLVER_CNTR0071E", this.enterpriseBeanClassName);
				throw new EJBConfigurationException(
						"LOCAL_TRANSACTION_RESOLVER_CONTAINER_AT_BOUNDARY_INVALID_WITH_EJB_MODULE_LEVEL_1_1  for = "
								+ this.enterpriseBeanClassName);
			}
		}

		int len$;
		if (this.ivModuleVersion >= 20) {
			if ((this.isEntityBean() || this.isStatefulSessionBean()) && !this.usesBeanManagedTx) {
				String temp_method_name = null;
				EJBMethodInterface[] mtypes = EJBMethodInterface.values();

				for (len$ = 0; len$ < mtypes.length && !asAttributesDefined; ++len$) {
					List<EJBMethodMetaData> emi = this.getEJBMethodMetaData(mtypes[len$]);
					int length = false;
					if (emi != null) {
						int length = emi.size() - 1;
						int i = 0;

						while (i < length && !asAttributesDefined) {
							ActivitySessionAttribute asa = ((EJBMethodInfoImpl) emi.get(i))
									.getActivitySessionAttribute();
							switch (asa.getValue()) {
								case 1 :
								case 2 :
								case 3 :
								case 4 :
								case 5 :
									temp_method_name = ((EJBMethodMetaData) emi.get(i)).getMethodName();
									asAttributesDefined = true;
								default :
									asAttributesDefined = false;
									++i;
							}
						}
					}
				}

				if (asAttributesDefined && 1 != this.activationPolicy && !this.ivReadOnlyCommitOption) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception thrown for method " + temp_method_name);
					}

					Tr.error(tc, "INVALID_ACTIVITY_SESSION_POLICY_CNTR0072E", this.enterpriseBeanClassName);
					throw new EJBConfigurationException(
							"Invalid activateAt policy with Container Managed Activity Session for = "
									+ this.enterpriseBeanClassName);
				}
			}

			if (this.usesBeanManagedTx && this._localTran.getValueResolver() == 1) {
				Tr.error(tc, "INVALID_LOCAL_TRANSACTION_RESOLVER_CNTR0073E", this.j2eeName);
				throw new EJBConfigurationException(
						"Unsupported Local Transaction resolution control for BeanManaged .");
			}
		}

		if (this.type == 6) {
			if (this._localTran.getValueResolver() == 0) {
				Tr.error(tc, "INVALID_CONFIGURATION_CMP_RESOLVER_APPLICATION_CNTR0065E", this.j2eeName);
				throw new EJBConfigurationException("Unsupported Local Transaction resolution control for CMP Beans.");
			}
		} else if (this.type == 7 && this._localTran.getValueBoundary() == 1) {
			Tr.error(tc, "LOCAL_TRAN_BOUNDARY_ACTIVITY_INVALID_CNTR0066E", this.j2eeName);
			throw new EJBConfigurationException(
					"Local Transaction Boundary of activity session is invalid for Message Driven Beans.");
		}

		TransactionAttribute txAttr;
		int i;
		String method;
		if (this.type == 7) {
			for (i = 0; i < this.localMethodInfos.length; ++i) {
				txAttr = this.localMethodInfos[i].getTransactionAttribute();
				if (txAttr != TransactionAttribute.TX_REQUIRED && txAttr != TransactionAttribute.TX_NOT_SUPPORTED
						&& txAttr != TransactionAttribute.TX_BEAN_MANAGED) {
					method = this.localMethodInfos[i].getMethodName();
					Tr.error(tc, "INVALID_TX_ATTR_CNTR0089E", new Object[]{txAttr.toString(), method, this.j2eeName});
					throw new EJBConfigurationException("Transaction attribute " + txAttr.toString()
							+ " is not allowed " + "for method " + method + " on EJB " + this.j2eeName);
				}
			}
		}

		if (this.timedMethodInfos != null) {
			if (this.ivModuleVersion < 20 || this.cmpVersion == 1 || this.type == 4 || this.type == 8) {
				Tr.error(tc, "INVALID_TIMEDOBJECT_IMPL_CNTR0088E", this.j2eeName);
				throw new EJBConfigurationException(
						"EJB 1.x, 2.0, and Stateful Session beans may not implement the javax.ejb.TimedObject interface : "
								+ this.j2eeName);
			}

			for (i = 0; i < this.timedMethodInfos.length; ++i) {
				txAttr = this.timedMethodInfos[i].getTransactionAttribute();
				if (txAttr != TransactionAttribute.TX_REQUIRED && txAttr != TransactionAttribute.TX_REQUIRES_NEW
						&& txAttr != TransactionAttribute.TX_NOT_SUPPORTED
						&& txAttr != TransactionAttribute.TX_BEAN_MANAGED) {
					method = this.timedMethodInfos[i].getMethodName();
					Tr.error(tc, "INVALID_TX_ATTR_CNTR0089E", new Object[]{txAttr.toString(), method, this.j2eeName});
					throw new EJBConfigurationException("Transaction attribute " + txAttr.toString()
							+ " is not allowed " + "for method " + method + " on EJB " + this.j2eeName);
				}
			}
		}

		if (this.lifecycleInterceptorMethodInfos != null) {
			EJBMethodInfoImpl[] arr$ = this.lifecycleInterceptorMethodInfos;
			len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				EJBMethodInfoImpl methodInfo = arr$[i$];
				txAttr = methodInfo.getTransactionAttribute();
				if (txAttr != TransactionAttribute.TX_REQUIRES_NEW && txAttr != TransactionAttribute.TX_NOT_SUPPORTED
						&& txAttr != TransactionAttribute.TX_BEAN_MANAGED) {
					String method = methodInfo.getMethodName();
					Tr.error(tc, "INVALID_TX_ATTR_CNTR0089E", new Object[]{txAttr.toString(), method, this.j2eeName});
					throw new EJBConfigurationException("Transaction attribute " + txAttr.toString()
							+ " is not allowed " + "for method " + method + " on EJB " + this.j2eeName);
				}
			}
		}

		if (this.ivCacheReloadType != 0 && this.cmpVersion < 2) {
			Tr.error(tc, "INVALID_CACHE_RELOAD_POLICY_CNTR0094E", this.enterpriseBeanClassName);
			StringBuffer exText = new StringBuffer();
			exText.append("Bean ").append(this.j2eeName).append(" with LoadPolicy ");
			exText.append(this.getCacheReloadIntervalString());
			exText.append(" must be CMP Version 2.x or later.");
			throw new EJBConfigurationException(exText.toString());
		} else {
			if (this.isLightweight) {
				if (this.type == 3 && LightweightLocal.class.isAssignableFrom(this.enterpriseBeanAbstractClass)) {
					Tr.error(tc, "INVALID_LIGHTWEIGHT_IMPL_CNTR0119E", new Object[]{this.j2eeName, "1"});
					throw new EJBConfigurationException(
							"Only Entity EJBs may implement the LightweightLocal interface : " + this.j2eeName);
				}

				if (this.type != 6 && this.type != 5 && this.type != 3) {
					Tr.error(tc, "INVALID_LIGHTWEIGHT_IMPL_CNTR0119E", new Object[]{this.j2eeName, "1"});
					throw new EJBConfigurationException(
							"Only Entity EJBs may implement the LightweightLocal interface : " + this.j2eeName);
				}

				if (this.ivModuleVersion < 20 || this.cmpVersion == 1) {
					Tr.error(tc, "INVALID_LIGHTWEIGHT_IMPL_CNTR0119E", new Object[]{this.j2eeName, "2"});
					throw new EJBConfigurationException(
							"EJB 1.x and CMP 1.x beans may not implement the LightweightLocal interface : "
									+ this.j2eeName);
				}

				if (this.localHomeInterfaceClassName == null) {
					Tr.error(tc, "INVALID_LIGHTWEIGHT_IMPL_CNTR0119E", new Object[]{this.j2eeName, "3"});
					throw new EJBConfigurationException(
							"EJBs that implement the LightweightLocal interface must define a local interface : "
									+ this.j2eeName);
				}
			}

			if (this.ivInitialPoolSize > 0 && (this.type != 3 || this.ivModuleVersion <= 11)) {
				Tr.warning(tc, "INVALID_MIN_POOLSIZE_CNTR0057W",
						new Object[]{this.j2eeName.toString(), "H" + Integer.toString(this.minPoolSize)});
				throw new EJBConfigurationException(
						"A hard (H) minimum pool size may only be specified for EJB 2.x Stateless Session EJBs : "
								+ this.j2eeName);
			} else if (this.ivMaxCreation <= 0 || this.type == 3 && this.ivModuleVersion > 11) {
				if (this.optionACommitOption && this.optimisticConcurrencyControl) {
					Tr.warning(tc, "COMMIT_OPTION_A_AND_OPTIMISTIC_CONCURRENCY_CONTROL_NOT_SUPPORTED_CNTR0049E");
					throw new EJBConfigurationException(
							"Using Commit Option A with Optimistic Concurrency is not supported.  EJB = "
									+ this.enterpriseBeanClassName);
				} else if (this.ivHasAsynchMethod && !this.isSessionBean()) {
					Tr.error(tc, "INVALID_BEAN_TYPE_FOR_ASYNCH_METHOD_CNTR0185E", new Object[]{
							this.j2eeName.getComponent(), this.j2eeName.getModule(), this.j2eeName.getApplication()});
					throw new EJBConfigurationException("The " + this.j2eeName.getComponent() + " bean in the "
							+ this.j2eeName.getModule() + " module of the " + this.j2eeName.getApplication()
							+ " application has one or more asynchronous methods configured, but is not a session bean.  "
							+ "Asynchronous methods can only be configured on session beans.");
				} else {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "validate");
					}

				}
			} else {
				Tr.warning(tc, "INVALID_MAX_POOLSIZE_CNTR0058W",
						new Object[]{this.j2eeName.toString(), "H" + Integer.toString(this.maxPoolSize)});
				throw new EJBConfigurationException(
						"A hard (H) maximum pool size may only be specified for EJB 2.x Stateless Session EJBs : "
								+ this.j2eeName);
			}
		}
	}

	protected EJBConfigData getEjbConfigData() {
		if (null == this.ejbConfigData) {
			throw new IllegalStateException("Invalid EJBConfigData");
		} else {
			return this.ejbConfigData;
		}
	}

	private String toIntrospectString() {
		String separator = ContainerProperties.LineSeparator;
		StringBuilder sb = new StringBuilder(this.toString());
		String sep = "                                 ";
		sb.append(separator + sep + "*** START ComponentMetaData fields ***");
		if (this.ivUnversionedJ2eeName != null) {
			sb.append(separator + sep + "Unversioned    = " + this.ivUnversionedJ2eeName);
		}

		if (this.type == 2) {
			sb.append(separator + sep + "EJB Type       = SINGLETON_SESSION");
		} else if (this.type == 3) {
			sb.append(separator + sep + "EJB Type       = STATELESS_SESSION");
		} else if (this.type == 4) {
			sb.append(separator + sep + "EJB Type       = STATEFUL_SESSION");
		} else if (this.type == 5) {
			sb.append(separator + sep + "EJB Type       = BEAN_MANAGED_ENTITY");
		} else if (this.type == 6) {
			sb.append(separator + sep + "EJB Type       = CONTAINER_MANAGED_ENTITY");
		} else if (this.type == 7) {
			sb.append(separator + sep + "EJB Type       = MESSAGE_DRIVEN");
		} else if (this.type == 8) {
			sb.append(separator + sep + "EJB Type       = MANAGED_BEAN");
		} else {
			sb.append(separator + sep + "EJB Type       = UNKNOWN");
		}

		if (this.usesBeanManagedTx) {
			sb.append(separator + sep + "TX Type        = BEAN_MANAGED_TX");
		} else {
			sb.append(separator + sep + "TX Type        = CONTAINER_MANAGED_TX");
		}

		sb.append(separator + sep + "Module Version = " + this.ivModuleVersion);
		if (this.type == 6) {
			if (this.cmpVersion == 1) {
				sb.append(separator + sep + "CMP Version    = 1.x");
			} else if (this.cmpVersion == 2) {
				sb.append(separator + sep + "CMP Version    = 2.x");
			} else {
				sb.append(separator + sep + "CMP Version    = UNKNOWN");
			}
		}

		if (null != this._resourceRefList) {
			sb.append(this._resourceRefList);
		}

		if (null != this._localTran) {
			sb.append(this._localTran);
		}

		sb.append(separator + sep + "*** END ComponentMetaData fields  ***");
		return sb.toString();
	}

	public String[][] getMethodLevelCustomFinderMethodSignatures(String cfprocessstring) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getMethodLevelCustomFinderMethodSignatures:" + cfprocessstring);
		}

		StringTokenizer st = new StringTokenizer(cfprocessstring, ":");
		String[][] cfMethodSignatureArray = new String[st.countTokens()][2];

		for (int methodCounter = 0; st.hasMoreTokens(); ++methodCounter) {
			String methodSignature = st.nextToken();
			StringTokenizer methodSignaturest = new StringTokenizer(methodSignature, "()");

			try {
				cfMethodSignatureArray[methodCounter][0] = methodSignaturest.nextToken();
				if (methodSignature.equals("()")) {
					cfMethodSignatureArray[methodCounter][1] = null;
				} else {
					cfMethodSignatureArray[methodCounter][1] = methodSignaturest.nextToken();
				}
			} catch (NoSuchElementException var8) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled() && methodSignature != null) {
					Tr.debug(tc, "Processing offset [" + methodCounter + "] " + methodSignature
							+ " failed, incorrect format");
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getMethodLevelCustomFinderMethodSignatures: " + cfMethodSignatureArray);
		}

		return cfMethodSignatureArray;
	}

	public boolean cfMethodSignatureEqual(String homeMethodName, String homeMethodSignature,
			String[][] cfMethodSignatures) {
		for (int lcv = 0; lcv < cfMethodSignatures.length; ++lcv) {
			if (cfMethodSignatures[lcv][0] != null && homeMethodName.equals(cfMethodSignatures[lcv][0])) {
				if (homeMethodSignature == null && cfMethodSignatures[lcv][1] == null) {
					return true;
				}

				if (homeMethodSignature == null || cfMethodSignatures[lcv][1] == null) {
					return false;
				}

				if (homeMethodSignature.equals(cfMethodSignatures[lcv][1])) {
					return true;
				}
			}
		}

		return false;
	}

	public boolean isApplicationSyncToOSThreadEnabled() {
		return this.m_syncToOSThreadValue;
	}

	public boolean isCheckConfig() {
		return this._moduleMetaData.getEJBApplicationMetaData().isCheckConfig();
	}

	static {
		svTimedObjectMethod = svTimedObjectClass.getMethods()[0];
		entityRemoteNoTxAttrMethods = new String[]{"getEJBHome", "getHandle", "getPrimaryKey", "isIdentical"};
		entityRemoteNoTxAttrMethodSignatures = new String[]{"", "", "", "javax.ejb.EJBObject"};
		entityLocalNoTxAttrMethods = new String[]{"getEJBHome", "getPrimaryKey", "isIdentical"};
		entityLocalNoTxAttrMethodSignatures = new String[]{"", "", "javax.ejb.EJBObject"};
		entityRemoteHomeNoTxAttrMethods = new String[]{"getEJBMetaData", "getHomeHandle"};
		entityRemoteHomeNoTxAttrMethodSignatures = new String[]{"", ""};
		entityLocalHomeNoTxAttrMethods = new String[]{""};
		entityLocalHomeNoTxAttrMethodSignatures = new String[]{""};
		sessionLocalHomeNoTxAttrMethods = new String[]{"*"};
		sessionLocalHomeNoTxAttrMethodSignatures = new String[]{""};
		sessionRemoteHomeNoTxAttrMethods = new String[]{"*"};
		sessionRemoteHomeNoTxAttrMethodSignatures = new String[]{""};
		fbpkReadOnlyOverrideAllBeans = false;
		allowCustomFinderSQLForUpdateALLBeans = false;
	}
}