package com.google.common.hash;

import com.google.common.hash.BloomFilter.Strategy;

enum BloomFilterStrategies implements Strategy {
	MURMUR128_MITZ_32;

	private BloomFilterStrategies() {
	}
}