package com.ibm.ejs.oa;

interface package-info {
}