package com.ibm.ws.wim;

import com.ibm.websphere.wim.ConfigService;
import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.security.authz.Entitlement;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.websphere.wim.util.SDOUtils;
import com.ibm.ws.wim.configmodel.AttributeGroupType;
import com.ibm.ws.wim.configmodel.AuthorizationType;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.ModificationSubscriber;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import com.ibm.ws.wim.configmodel.NotificationSubscriber;
import com.ibm.ws.wim.configmodel.NotificationSubscriberList;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.PostExit;
import com.ibm.ws.wim.configmodel.PreExit;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.StaticModelType;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import com.ibm.ws.wim.configmodel.TopicSubscriber;
import com.ibm.ws.wim.configmodel.TopicSubscriberList;
import com.ibm.ws.wim.env.IEncryptionUtil;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.util.DataGraphHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import commonj.sdo.Type;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.Resource.Factory.Registry;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;

public class ConfigManagerBase implements ConfigService, DynamicConfigService {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	static EPackage configSchema;
	DataGraph configDG = null;
	private DataGraph savedConfigDG = null;
	String wimHomePath = null;
	String wimSchemaHomePath = null;
	String wimConfigXMLFilePath = null;
	static Map uriToSchema;
	static Map classNameToURI;
	String entityTypeXPath = null;
	List entityTypes = null;
	String reposXPath = null;
	List reposIds = null;
	String propXPath = null;
	static final String sFileSep;

	ConfigManagerBase() throws WIMException {
		this.initialize();
	}

	EPackage loadConfigSchemaFromPackage(String var1) throws WIMException {
		EPackage var2 = this.loadSchemaFromPackage(var1);
		uriToSchema.put(var2.getNsURI(), var2);
		this.readPackage(var2);
		return var2;
	}

	EPackage loadSchemaFromPackage(String var1) throws WIMException {
		try {
			Class var3 = Class.forName(var1);
			EPackage var4 = (EPackage) var3.getField("eINSTANCE").get(var3);
			String var5 = var4.getNsURI();
			DomainManagerUtils.putPackageInEMFRegistry(var5, var4);
			return var4;
		} catch (ClassNotFoundException var6) {
			throw new InitializationException("CLASS_OR_INTERFACE_NOT_FOUND",
					WIMMessageHelper.generateMsgParms(var1, "packageName"), CLASSNAME, "loadConfigSchemaFromPackage",
					var6);
		} catch (NoSuchFieldException var7) {
			throw new InitializationException("INVALID_PACKAGE_NAME",
					WIMMessageHelper.generateMsgParms(var1, "packageName"), CLASSNAME, "loadConfigSchemaFromPackage",
					var7);
		} catch (IllegalAccessException var8) {
			throw new InitializationException("INVALID_PACKAGE_NAME",
					WIMMessageHelper.generateMsgParms(var1, "packageName"), CLASSNAME, "loadConfigSchemaFromPackage",
					var8);
		}
	}

	public DataGraph loadConfigFromXML(String var1) throws WIMException {
		EDataGraph var3 = null;
		long var4 = System.currentTimeMillis();

		try {
			FileInputStream var6 = new FileInputStream(var1);
			HashMap var7 = new HashMap();
			var3 = SDOUtil.loadDataGraph(var6, var7);
			if (trcLogger.isLoggable(Level.FINE)) {
				long var8 = System.currentTimeMillis();
				trcLogger.logp(Level.FINE, CLASSNAME, "loadConfigFromXML",
						"Loaded from " + var1 + " (" + (var8 - var4) + " milliseconds)");
			}

			return var3;
		} catch (FileNotFoundException var10) {
			throw new InitializationException("WIM_CONFIG_XML_FILE_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
					CLASSNAME, "loadConfigFromXML", var10);
		} catch (IOException var11) {
			throw new InitializationException("INVALID_WIM_CONFIG_XML_FILE",
					WIMMessageHelper.generateMsgParms(var1, var11.getMessage()), CLASSNAME, "loadConfigFromXML", var11);
		}
	}

	private void trimStringList(List var1) {
		try {
			if (var1 != null) {
				for (int var2 = 0; var2 < var1.size(); ++var2) {
					var1.set(var2, ((String) var1.get(var2)).trim());
				}
			}
		} catch (Exception var3) {
			trcLogger.logp(Level.FINE, CLASSNAME, "trimStringList", var3.getMessage(), var3);
		}

	}

	private void trimModificationSubscriberList(ModificationSubscriberList var1) {
		if (var1 != null) {
			List var2 = var1.getModificationSubscriber();

			for (int var3 = 0; var3 < var2.size(); ++var3) {
				ModificationSubscriber var4 = (ModificationSubscriber) var2.get(var3);
				if (var4.getModificationSubscriberReference() != null) {
					var4.setModificationSubscriberReference(var4.getModificationSubscriberReference().trim());
				}

				this.trimStringList(var4.getRealmList());
			}
		}

	}

	private void trimNotificationSubscriberList(NotificationSubscriberList var1) {
		if (var1 != null) {
			List var2 = var1.getNotificationSubscriber();

			for (int var3 = 0; var3 < var2.size(); ++var3) {
				NotificationSubscriber var4 = (NotificationSubscriber) var2.get(var3);
				if (var4.getNotificationSubscriberReference() != null) {
					var4.setNotificationSubscriberReference(var4.getNotificationSubscriberReference().trim());
					this.trimStringList(var4.getRealmList());
				}
			}
		}

	}

	private void trimConfigStringData() {
		try {
			ConfigurationProviderType var1 = (ConfigurationProviderType) this.configDG.getRootObject()
					.get("configurationProvider");
			StaticModelType var2 = var1.getStaticModel();
			if (var2 != null) {
				this.trimStringList(var2.getPackageName());
			}

			List var3 = var1.getSupportedEntityTypes();

			for (int var4 = 0; var4 < var3.size(); ++var4) {
				SupportedEntityTypesType var5 = (SupportedEntityTypesType) var3.get(var4);
				this.trimStringList(var5.getRdnProperties());
			}

			List var16 = var1.getRepositories();

			for (int var17 = 0; var17 < var16.size(); ++var17) {
				if (var16.get(var17) instanceof ProfileRepositoryType) {
					ProfileRepositoryType var6 = (ProfileRepositoryType) var16.get(var17);
					this.trimStringList(var6.getLoginProperties());
					this.trimStringList(var6.getRepositoriesForGroups());
				}
			}

			PluginManagerConfigurationType var18 = var1.getPluginManagerConfiguration();
			List var7;
			int var8;
			if (var18 != null) {
				TopicSubscriberList var19 = var18.getTopicSubscriberList();
				if (var19 != null) {
					var7 = var19.getTopicSubscriber();

					for (var8 = 0; var8 < var7.size(); ++var8) {
						TopicSubscriber var9 = (TopicSubscriber) var7.get(var8);
						if (var9.getClassName() != null) {
							var9.setClassName(var9.getClassName().trim());
						}
					}
				}

				TopicRegistrationList var21 = var18.getTopicRegistrationList();
				if (var21 != null) {
					List var22 = var21.getTopicEmitter();

					for (int var23 = 0; var23 < var22.size(); ++var23) {
						TopicEmitter var10 = (TopicEmitter) var22.get(var23);
						PreExit var11 = var10.getPreExit();
						this.trimModificationSubscriberList(var11.getModificationSubscriberList());
						this.trimNotificationSubscriberList(var11.getNotificationSubscriberList());
						List var12 = var10.getInlineExit();

						for (int var13 = 0; var13 < var12.size(); ++var13) {
							InlineExit var14 = (InlineExit) var12.get(var13);
							this.trimModificationSubscriberList(var14.getModificationSubscriberList());
						}

						PostExit var25 = var10.getPostExit();
						this.trimModificationSubscriberList(var25.getModificationSubscriberList());
						this.trimNotificationSubscriberList(var25.getNotificationSubscriberList());
					}
				}
			}

			AuthorizationType var20 = var1.getAuthorization();
			if (var20 != null) {
				var7 = var20.getAttributeGroups();

				for (var8 = 0; var8 < var7.size(); ++var8) {
					AttributeGroupType var24 = (AttributeGroupType) var7.get(var8);
					this.trimStringList(var24.getAttributeNames());
					if (var24.getGroupName() != null) {
						var24.setGroupName(var24.getGroupName().trim());
					}
				}
			}
		} catch (Exception var15) {
			trcLogger.logp(Level.FINE, CLASSNAME, "trimConfigStringData", var15.getMessage(), var15);
		}

	}

	public synchronized void initialize() throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize");
		}

		String var2 = File.separator;

		try {
			this.wimHomePath = System.getProperty("wim.home");
			if (this.wimHomePath == null) {
				this.wimHomePath = this.buildHomeDirectory();
			} else if (!this.wimHomePath.endsWith(var2)) {
				this.wimHomePath = this.wimHomePath + var2;
			}

			if (trcLogger.isLoggable(Level.CONFIG)) {
				trcLogger.logp(Level.CONFIG, CLASSNAME, "initialize", "WIM Home Path is " + this.wimHomePath);
			}

			this.wimSchemaHomePath = System.getProperty("wim.schema.home");
			if (this.wimSchemaHomePath == null) {
				this.wimSchemaHomePath = this.buildSchemaHomeDirectory();
			} else if (!this.wimSchemaHomePath.endsWith(var2)) {
				this.wimSchemaHomePath = this.wimSchemaHomePath + var2;
			}

			if (trcLogger.isLoggable(Level.CONFIG)) {
				trcLogger.logp(Level.CONFIG, CLASSNAME, "initialize",
						"WIM Schema Home Path is " + this.wimSchemaHomePath);
			}

			Class var3 = ConfigManagerBase.class;
			synchronized (ConfigManagerBase.class) {
				if (configSchema == null) {
					configSchema = this.loadConfigSchemaFromPackage("com.ibm.ws.wim.configmodel.ConfigmodelPackage");
					String var4 = configSchema.getNsURI();
					DomainManagerUtils.putPackageInEMFGlobalRegistryFromVMM(var4, configSchema);
				}
			}

			if ("admin".equals(DomainManagerUtils.getDomainName())) {
				this.wimConfigXMLFilePath = this.wimHomePath + "config" + var2 + "wimconfig.xml";
			} else {
				this.wimConfigXMLFilePath = DomainManagerUtils.getDomainPath(DomainManagerUtils.getDomainName()) + "wim"
						+ var2 + "config" + var2 + "wimconfig.xml";
				if (!(new File(this.wimConfigXMLFilePath)).isFile()) {
					this.wimConfigXMLFilePath = this.wimHomePath + "config" + var2 + "wimconfig.xml";
				}
			}

			this.configDG = this.loadConfigFromXML(this.wimConfigXMLFilePath);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize", WIMTraceHelper.printDataGraph(this.configDG));
			}

			this.trimConfigStringData();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize", "Config data after trimming:");
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize", WIMTraceHelper.printDataGraph(this.configDG));
			}

			this.entityTypeXPath = "configurationProvider/supportedEntityTypes[name=\"{0}\"]";
			this.reposXPath = "configurationProvider/repositories[id=\"{0}\"]";
			this.propXPath = "attributes[propertyName=\"{0}\"]";
			this.refreshConfigCache();
		} catch (Exception var7) {
			throw new WIMApplicationException("COMPONENT_INITIALIZATION_FAILED",
					WIMMessageHelper.generateMsgParms("ConfigManager", var7.toString()), CLASSNAME, "initialize", var7);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

	}

	public EPackage getConfigSchema() {
		return configSchema;
	}

	public byte[] getConfigEPackage() throws WIMException {
		try {
			Registry.INSTANCE.getExtensionToFactoryMap().put("ecore", new EcoreResourceFactoryImpl());
			ResourceSetImpl var1 = new ResourceSetImpl();
			Resource var2 = var1.createResource(URI.createURI(".ecore"));
			var2.getContents().add(EcoreUtil.copy(configSchema));
			ByteArrayOutputStream var3 = new ByteArrayOutputStream(2064);
			var2.save(var3, Collections.EMPTY_MAP);
			return var3.toByteArray();
		} catch (IOException var4) {
			throw new WIMApplicationException(var4.toString());
		}
	}

	public DataObject getConfig() throws WIMException {
		ProfileSecurityManager var1 = ProfileSecurityManager.singleton();
		var1.checkPermission_SuperUser(new Entitlement("GET", "CONFIGURATION"));
		DataGraph var2 = SDOHelper.createDataGraph("http://www.ibm.com/websphere/wim/config");
		DataObject var3 = DataGraphHelper
				.cloneDataObject(this.configDG.getRootObject().getDataObject("configurationProvider"));
		var2.getRootObject().setDataObject("configurationProvider", var3);
		return var3;
	}

	void encodeDBAdminPassword(IEncryptionUtil var1, DataObject var2) {
		if (var2 != null) {
			String var3 = var2.getString("dbAdminPassword");
			if (var3 != null) {
				var2.setString("dbAdminPassword", this.encode(var1, var3));
			}
		}

	}

	void encodeLDAPAdapterPassword(IEncryptionUtil var1, DataObject var2) {
		if (var2 != null) {
			DataObject var3 = var2.getDataObject("ldapServerConfiguration");
			if (var3 != null) {
				List var4 = var3.getList("ldapServers");

				for (int var5 = 0; var5 < var4.size(); ++var5) {
					DataObject var6 = (DataObject) var4.get(var5);
					String var7 = var6.getString("bindPassword");
					if (var7 != null) {
						var6.setString("bindPassword", this.encode(var1, var7));
					}
				}

				String var8 = var3.getString("sslKeyStorePassword");
				if (var8 != null) {
					var3.setString("sslKeyStorePassword", this.encode(var1, var8));
				}

				var8 = var3.getString("sslTrustStorePassword");
				if (var8 != null) {
					var3.setString("sslTrustStorePassword", this.encode(var1, var8));
				}
			}
		}

	}

	public void encodePasswords(DataObject var1) {
		IEncryptionUtil var2 = FactoryManager.getEncryptionUtil();
		this.encodeDBAdminPassword(var2, var1.getDataObject("entryMappingRepository"));
		this.encodeDBAdminPassword(var2, var1.getDataObject("propertyExtensionRepository"));
		List var3 = var1.getList("repositories");

		for (int var4 = 0; var4 < var3.size(); ++var4) {
			DataObject var5 = (DataObject) var3.get(var4);
			String var6 = var5.getType().getName();
			if ("DatabaseRepositoryType".equals(var6)) {
				this.encodeDBAdminPassword(var2, var5);
			} else if ("LdapRepositoryType".equals(var6)) {
				this.encodeLDAPAdapterPassword(var2, var5);
			}
		}

	}

	String encode(IEncryptionUtil var1, String var2) {
		return var2 != null && !var2.equals("") ? var1.encode(var2) : var2;
	}

	public void updateConfig(DataObject var1) throws WIMException, RemoteException {
		ProfileSecurityManager var2 = ProfileSecurityManager.singleton();
		var2.checkPermission_SuperUser(new Entitlement("UPDATE", "CONFIGURATION"));
		if (EnvironmentManager.singleton().isConfigUpdateNotAllowed()) {
			throw new DynamicUpdateConfigException("DYNAMIC_RELOAD_INVALID_UPDATE_AT_MANAGED_NODE", CLASSNAME,
					"updateConfig");
		} else {
			SDOUtils.validateDataObject(var1);
			this.encodePasswords(var1);
			this.configDG = var1.getDataGraph();
			DataGraphHelper.saveDataGraph(this.configDG, this.wimConfigXMLFilePath);
			this.refreshConfigCache();
		}
	}

	public String getWIMHomePath() {
		return this.wimHomePath;
	}

	public String getWIMHomePath(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getWIMHomePath", "dname : " + var1);
		}

		String var3 = DomainManagerUtils.getDomainPath(var1) + sFileSep + "wim" + sFileSep;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getWIMHomePath", "WIMHomePath : " + var3);
		}

		return var3;
	}

	public String getGlobalWIMHomePath() {
		return this.getWIMHomePath();
	}

	public static String getConfigPathInCell() {
		return "wimHomePath";
	}

	public String getWIMSchemaHomePath() {
		return this.wimSchemaHomePath;
	}

	public String getWIMConfigXMLFilePath() {
		return this.wimConfigXMLFilePath;
	}

	public void createSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createSchema");
		}

		DataObject var3 = var1.getDataObject("schema");
		if (var3 == null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "createSchema", "dymaSchema=null");
			}

		} else {
			DataObject var4 = this.configDG.getRootObject().getDataObject("configurationProvider");
			List var5 = var3.getList("entitySchema");
			List var6 = var3.getList("propertySchema");
			List var7 = var3.getList("extensionPropertySchema");
			DataObject var8;
			String var9;
			String var10;
			if (var5.size() > 0) {
				var8 = (DataObject) var5.get(0);
				var9 = var8.getString("entityName");
				var10 = var8.getString("nsURI");
				String var11 = SchemaManager.singleton().getQualifiedTypeName(var10, var9);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "createSchema", "qualified entity type:" + var11);
				}

				DataObject var12 = var8.getDataObject("entityConfiguration");
				String var13 = var12.getString("defaultParent");
				String var14 = var12.getString("rdnProperty");
				DataObject var15 = var4.getDataObject("supportedEntityTypes[name='" + var11 + "']");
				if (var15 == null) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "createSchema", "new supported entity type");
					}

					var15 = var4.createDataObject("supportedEntityTypes");
					var15.setString("name", var11);
				} else if (var14 != null) {
					List var16 = var15.getList("rdnProperties");
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "createSchema", "clear current RDN properties:" + var16);
					}

					var16.clear();
				}

				if (var13 != null) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "createSchema", "set default parent:" + var13);
					}

					var15.setString("defaultParent", var13);
				}

				if (var14 != null) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "createSchema", "set RDN property:" + var14);
					}

					var15.getList("rdnProperties").add(var14);
				}

				this.createEntityConfiguration(var8, var11, var4);
			} else if (var6.size() > 0) {
				var8 = (DataObject) var6.get(0);
				var9 = var8.getString("propertyName");
				var10 = SchemaManager.singleton().getQualifiedTypeName(var8.getString("nsURI"), var9);
				this.createPropertyConfiguration(var8.getList("repositoryIds"), var10, var8.getList("metaData"), var4);
			} else if (var7.size() > 0) {
				var8 = (DataObject) var7.get(0);
				var9 = var8.getString("propertyName");
				var10 = SchemaManager.singleton().getQualifiedTypeName(var8.getString("nsURI"), var9);
				this.createPropertyExtensionConfiguration(var8.getList("repositoryIds"), var10, var4);
			}

			DataGraphHelper.saveDataGraph(this.configDG, this.wimConfigXMLFilePath);
			this.refreshConfigCache();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "createSchema");
			}

		}
	}

	void createPropertyConfiguration(List var1, String var2, List var3, DataObject var4) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createPropertyConfiguration", "qPropName=" + var2);
		}

		List var6 = var4.getList("repositories");

		for (int var7 = 0; var7 < var6.size(); ++var7) {
			DataObject var8 = (DataObject) var6.get(var7);
			if ((var1.size() <= 0 || var1.contains(var8.getString("id")))
					&& "LdapRepositoryType".equals(var8.getType().getName())) {
				DataObject var9 = var8.getDataObject("attributeConfiguration");

				for (int var10 = 0; var10 < var3.size(); ++var10) {
					DataObject var11 = (DataObject) var3.get(var10);
					String var12 = var11.getString("name");
					List var13 = var11.getList("values");
					String var14 = var11.getString("repositoryId");
					if ((var14 == null || var14.equals(var8.getString("id")))
							&& "repositoryPropertyName".equals(var12)) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "createPropertyConfiguration",
									"creating prop for repository " + var14);
						}

						if (var9 == null) {
							var9 = var8.createDataObject("attributeConfiguration");
						}

						DataObject var15 = var9.createDataObject("attributes");
						List var16 = var9.getList("attributes");

						for (int var17 = 0; var17 < var16.size(); ++var17) {
							DataObject var18 = (DataObject) var16.get(var17);
							if (var2.equals(var18.getString("propertyName"))) {
								var18.delete();
							}
						}

						var15.setString("propertyName", var2);
						var15.setString("name", (String) var13.get(0));
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createPropertyConfiguration");
		}

	}

	void createPropertyExtensionConfiguration(List var1, String var2, DataObject var3) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createPropertyExtensionConfiguration", "qPropName=" + var2);
		}

		List var5 = var3.getList("repositories");

		for (int var6 = 0; var6 < var5.size(); ++var6) {
			DataObject var7 = (DataObject) var5.get(var6);
			if ((var1.size() <= 0 || var1.contains(var7.getString("id")))
					&& "LdapRepositoryType".equals(var7.getType().getName())) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "createPropertyExtensionConfiguration",
							"creating prop for repository " + var7.getString("id"));
				}

				DataObject var8 = var7.getDataObject("attributeConfiguration");
				if (var8 == null) {
					var8 = var7.createDataObject("attributeConfiguration");
				}

				DataObject var9 = var8.createDataObject("propertiesNotSupported");
				List var10 = var8.getList("propertiesNotSupported");

				for (int var11 = 0; var11 < var10.size(); ++var11) {
					DataObject var12 = (DataObject) var10.get(var11);
					if (var2.equals(var12.getString("name"))) {
						var12.delete();
					}
				}

				var9.setString("name", var2);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createPropertyExtensionConfiguration");
		}

	}

	void createEntityConfiguration(DataObject var1, String var2, DataObject var3) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createEntityConfiguration", "entityName=" + var2);
		}

		List var5 = var3.getList("repositories");
		List var6 = var1.getList("repositoryIds");
		DataObject var7 = var1.getDataObject("entityConfiguration");

		for (int var8 = 0; var8 < var5.size(); ++var8) {
			DataObject var9 = (DataObject) var5.get(var8);
			String var10 = var9.getString("id");
			if (var6.size() <= 0 || var6.contains(var10)) {
				List var11 = var7.getList("actionNotAllow");

				for (int var12 = 0; var12 < var11.size(); ++var12) {
					DataObject var13 = (DataObject) var11.get(var12);
					String var14 = var13.getString("actionName");
					if ("CREATE".equalsIgnoreCase(var14)) {
						if (!var9.getList("EntityTypesNotAllowCreate").contains(var2)) {
							var9.getList("EntityTypesNotAllowCreate").add(var2);
						}
					} else if ("UPDATE".equalsIgnoreCase(var14)) {
						if (!var9.getList("EntityTypesNotAllowUpdate").contains(var2)) {
							var9.getList("EntityTypesNotAllowUpdate").add(var2);
						}
					} else if ("READ".equalsIgnoreCase(var14)) {
						if (!var9.getList("EntityTypesNotAllowRead").contains(var2)) {
							var9.getList("EntityTypesNotAllowRead").add(var2);
						}
					} else if ("DELETE".equalsIgnoreCase(var14)
							&& !var9.getList("EntityTypesNotAllowDelete").contains(var2)) {
						var9.getList("EntityTypesNotAllowDelete").add(var2);
					}
				}

				if ("LdapRepositoryType".equals(var9.getType().getName())) {
					DataObject var21 = var9.getDataObject("ldapEntityTypes[name='" + var2 + "']");
					if (var21 == null) {
						var21 = var9.createDataObject("ldapEntityTypes");
						var21.setString("name", var2);
					}

					List var22 = var7.getList("metaData");

					for (int var23 = 0; var23 < var22.size(); ++var23) {
						DataObject var15 = (DataObject) var22.get(var23);
						String var16 = var15.getString("name");
						List var17 = var15.getList("values");
						String var18 = var15.getString("repositoryId");
						if (var18 == null || var18.equals(var9.getString("id"))) {
							List var19;
							if ("rdnAttributes".equalsIgnoreCase(var16)) {
								var19 = var21.getList("rdnAttributes");
								var19.clear();
								DataObject var20 = var21.createDataObject("rdnAttributes");
								var20.setString("name", (String) var17.get(0));
								var19.add(var20);
							} else if ("objectClasses".equalsIgnoreCase(var16)) {
								var19 = var21.getList("objectClasses");
								var19.clear();
								var19.addAll(var17);
							} else if ("objectClassesForCreate".equalsIgnoreCase(var16)) {
								var19 = var21.getList("objectClassesForCreate");
								var19.clear();
								var19.addAll(var17);
							}
						}
					}

					List var24 = var1.getList("properties");

					for (int var25 = 0; var25 < var24.size(); ++var25) {
						DataObject var26 = (DataObject) var24.get(var25);
						String var27 = var26.getString("name");
						List var28 = var26.getList("metaData");
						ArrayList var29 = new ArrayList(1);
						var29.add(var10);
						this.createPropertyConfiguration(var29, var27, var28, var3);
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createEntityConfiguration");
		}

	}

	public DataObject getRepositoryDataObject(String var1) {
		return this.configDG.getRootObject().getDataObject(this.getRepositoryXPath(var1));
	}

	public String getDefaultParent(String var1) {
		DataObject var2 = this.getSupportedEntityTypeDataObject(var1);
		return var2 != null ? var2.getString("defaultParent") : null;
	}

	public String getDefaultParent(Type var1) throws WIMException {
		return this.getDefaultParent(var1.getName(), var1.getURI());
	}

	public String getDefaultParent(String var1, String var2) throws WIMException {
		String var3 = SchemaManager.singleton().getQualifiedTypeName(var1, var2);
		DataObject var4 = this.getSupportedEntityTypeDataObject(var3);
		return var4 != null ? var4.getString("defaultParent") : null;
	}

	String getEntityTypeXPath(String var1) {
		Object[] var2 = new Object[]{var1};
		String var3 = (new MessageFormat(this.entityTypeXPath)).format(var2);
		return var3;
	}

	public DataObject getSupportedEntityTypeDataObject(String var1) {
		return this.configDG.getRootObject().getDataObject(this.getEntityTypeXPath(var1));
	}

	String getWIMPropertyXPath(String var1) {
		Object[] var2 = new Object[]{var1};
		return (new MessageFormat(this.propXPath)).format(var2);
	}

	String getRepositoryXPath(String var1) {
		Object[] var2 = new Object[]{var1};
		return (new MessageFormat(this.reposXPath)).format(var2);
	}

	public List getRDNProperties(String var1) {
		DataObject var2 = this.getSupportedEntityTypeDataObject(var1);
		return var2 != null ? var2.getList("rdnProperties") : null;
	}

	public List getRDNProperties(Type var1) throws WIMException {
		return this.getRDNProperties(var1.getName(), var1.getURI());
	}

	public List getRDNProperties(String var1, String var2) throws WIMException {
		String var3 = SchemaManager.singleton().getQualifiedTypeName(var1, var2);
		DataObject var4 = this.getSupportedEntityTypeDataObject(var3);
		return var4 != null ? var4.getList("rdnProperties") : null;
	}

	public List getSupportedEntityTypes() {
		return this.entityTypes;
	}

	public List getRepsoitoryIds() {
		return this.reposIds;
	}

	void retrieveSupportedEntityTypes() {
		List var1 = this.configDG.getRootObject().getDataObject("configurationProvider")
				.getList("supportedEntityTypes");
		this.entityTypes = new ArrayList(var1.size());

		for (int var2 = 0; var2 < var1.size(); ++var2) {
			DataObject var3 = (DataObject) var1.get(var2);
			this.entityTypes.add(var3.getString("name"));
		}

	}

	void retrieveRepositoryIds() {
		List var1 = this.configDG.getRootObject().getDataObject("configurationProvider").getList("repositories");
		this.reposIds = new ArrayList(var1.size());

		for (int var2 = 0; var2 < var1.size(); ++var2) {
			DataObject var3 = (DataObject) var1.get(var2);
			this.reposIds.add(var3.getString("id"));
		}

	}

	private void refreshConfigCache() {
		this.retrieveSupportedEntityTypes();
		this.retrieveRepositoryIds();
	}

	public EClass getConfigEClass(String var1) {
		String var2 = (String) classNameToURI.get(var1);
		if (var2 != null) {
			EPackage var3 = (EPackage) uriToSchema.get(var2);
			if (var3 != null) {
				return (EClass) var3.getEClassifier(var1);
			}
		}

		return null;
	}

	void readPackage(EPackage var1) throws WIMApplicationException {
		String var3 = var1.getNsURI();
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "readPackage",
					"Package Name: " + var1.getName() + "\tPackage NSURI:" + var3);
		}

		EList var4 = var1.getEClassifiers();

		for (int var5 = 0; var5 < var4.size(); ++var5) {
			Object var6 = var4.get(var5);
			if (var6 instanceof EClass) {
				EClass var7 = (EClass) var6;
				String var8 = var7.getName();
				if (classNameToURI.get(var8) != null) {
					throw new WIMApplicationException("The entity type " + var8 + " is aleady defined.");
				}

				classNameToURI.put(var8, var3);
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "readPackage", "\tClass Name: " + var8);
				}
			}
		}

	}

	public String getCellName() {
		return System.getProperty("local.cell");
	}

	public String getCurrentContextCellDirectory() throws WIMException {
		return this.getWIMHomePath();
	}

	public String getCurrentContextConfigDirectory() throws WIMException {
		return this.getWIMHomePath();
	}

	public String getAdminAgentWASConfigDirectory() throws Exception {
		return null;
	}

	public String buildHomeDirectory() throws Exception {
		return this.getWIMHomePath() + File.separator + "wim" + File.separator;
	}

	String buildSchemaHomeDirectory() throws Exception {
		String var2 = this.getWIMHomePath() + File.separator + "etc" + File.separator + "wim" + File.separator
				+ "schema" + File.separator;
		File var3 = new File(var2);
		if (var3.isDirectory()) {
			return var2;
		} else {
			throw new InitializationException("DIRECTORY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var2),
					Level.SEVERE, CLASSNAME, "buildSchemaHomeDirectory");
		}
	}

	void addEntityConfig(Map var1, DataObject var2) throws WIMException {
		String var4 = (String) var1.get("DYNA_CONFIG_KEY_ENTITY_TYPE");
		if (var4 == null) {
			throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_MISSING_VALUE",
					WIMMessageHelper.generateMsgParms("DYNA_CONFIG_KEY_ENTITY_TYPE"), CLASSNAME, "addEntityConfig");
		} else if (SchemaManager.singleton().getEClass(var4) == null) {
			throw new DynamicUpdateConfigException("ENTITY_TYPE_NOT_SUPPORTED", WIMMessageHelper.generateMsgParms(var4),
					CLASSNAME, "addEntityConfig");
		} else {
			List var5 = (List) var1.get("DYNA_CONFIG_KEY_RDNS");
			if (var5 != null && var5.size() != 0) {
				for (int var6 = 0; var6 < var5.size(); ++var6) {
					String var7 = (String) var5.get(var6);
					if (SchemaManager.singleton().getProperty(var4, var7) == null) {
						throw new DynamicUpdateConfigException("INVALID_RDN_ATTR",
								WIMMessageHelper.generateMsgParms(var7), CLASSNAME, "addEntityConfig");
					}
				}

				String var9 = (String) var1.get("DYNA_CONFIG_KEY_DEFAULT_PARENT");
				if (var9 == null) {
					throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_MISSING_VALUE",
							WIMMessageHelper.generateMsgParms("DYNA_CONFIG_KEY_DEFAULT_PARENT"), CLASSNAME,
							"addEntityConfig");
				} else {
					DataObject var10 = var2.getDataObject("supportedEntityTypes[name='" + var4 + "']");
					if (var10 != null) {
						if (!var10.getString("defaultParent").equalsIgnoreCase(var9)
								|| !var10.getList("rdnProperties").equals(var5)) {
							throw new DynamicUpdateConfigException("ENTITY_ALREADY_EXIST",
									WIMMessageHelper.generateMsgParms(var4), CLASSNAME, "addEntityConfig");
						}
					} else {
						DataObject var8 = var2.createDataObject("supportedEntityTypes");
						var8.setString("name", var4);
						var8.setString("defaultParent", var9);
						var8.getList("rdnProperties").addAll(var5);
						ProfileManager.singleton().initializePropertyCache();
					}

				}
			} else {
				throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_MISSING_VALUE",
						WIMMessageHelper.generateMsgParms("DYNA_CONFIG_KEY_RDNS"), CLASSNAME, "addEntityConfig");
			}
		}
	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "dynamicUpdateConfig", WIMMessageHelper.generateMsgParms(var1, var2));
		}

		DataObject var4 = this.configDG.getRootObject().getDataObject("configurationProvider");
		DataObject var11;
		if ("websphere.usermanager.serviceprovider.add.repository".equals(var1)) {
			if (var4 != null && var2 != null) {
				var11 = (DataObject) var2.get("DYNA_CONFIG_KEY_REPOS_CONFIG");
				if (var11 != null) {
					this.checkDataObjectType(var1, var11);
					List var13 = var4.getList("repositories");
					var13.add(var11);
				}
			}
		} else if ("websphere.usermanager.serviceprovider.add.propertyextensionrepository".equals(var1)) {
			if (var4 != null && var2 != null) {
				var11 = (DataObject) var2.get("DYNA_CONFIG_KEY_PROP_EXT_REPOS_CONFIG");
				this.checkDataObjectType(var1, var11);
				if (var11 != null) {
					var4.setDataObject("propertyExtensionRepository", var11);
				}
			}
		} else if ("websphere.usermanager.serviceprovider.add.realm".equals(var1)) {
			if (var4 != null && var2 != null) {
				var11 = (DataObject) var2.get("DYNA_CONFIG_KEY_REALM_CONFIG");
				this.checkDataObjectType(var1, var11);
				DataObject var12 = var4.getDataObject("realmConfiguration");
				if (var12 == null) {
					throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_ADD_REALM_WITHOUT_REALM_CONFIG",
							CLASSNAME, "dynamicUpdateConfig");
				}

				if (var11 != null) {
					List var14 = var12.getList("realms");
					var14.add(var11);
				}
			}
		} else if ("websphere.usermanager.serviceprovider.add.baseentry".equals(var1)) {
			if (var4 != null && var2 != null) {
				String var5 = (String) var2.get("DYNA_CONFIG_KEY_REPOS_ID");
				if (var5 == null || var5.trim().length() == 0) {
					throw new DynamicUpdateConfigException("INVALID_REPOSITORY_ID",
							WIMMessageHelper.generateMsgParms(var5), Level.SEVERE, CLASSNAME, "dynamicUpdateConfig");
				}

				String var6 = (String) var2.get("DYNA_CONFIG_KEY_BASE_ENTRY");
				if (var6 == null || var6.trim().length() == 0) {
					throw new DynamicUpdateConfigException("INVALID_BASE_ENTRY_NAME",
							WIMMessageHelper.generateMsgParms(var6, var5), Level.SEVERE, CLASSNAME,
							"dynamicUpdateConfig");
				}

				String var7 = (String) var2.get("DYNA_CONFIG_KEY_BASE_ENTRY_IN_REPOS");
				DataObject var8 = this.getRepositoryDataObject(var5);
				Iterator var9 = var8.getList("baseEntries").iterator();

				while (var9.hasNext()) {
					if (var6.equalsIgnoreCase(((DataObject) var9.next()).getString("name"))) {
						throw new DynamicUpdateConfigException("BASE_ENTRY_ALREADY_IN_REPOSITORY",
								WIMMessageHelper.generateMsgParms(var6, var5), Level.SEVERE, CLASSNAME,
								"dynamicUpdateConfig");
					}
				}

				DataObject var10 = SDOHelper.createConfigDataObject(var8, "http://www.ibm.com/websphere/wim/config",
						"baseEntries");
				var10.setString("name", var6);
				var10.setString("nameInRepository", var7);
				var8.getList("baseEntries").add(var10);
			}
		} else if ("websphere.usermanager.serviceprovider.add.entityconfig".equals(var1)) {
			this.addEntityConfig(var2, var4);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "dynamicUpdateConfig");
		}

	}

	void checkDataObjectType(String var1, DataObject var2) throws WIMException {
		if (var2 != null) {
			String var3 = var2.getType().getName();
			if ("websphere.usermanager.serviceprovider.add.repository".equals(var1)
					&& !"LdapRepositoryType".equals(var3) && !"ProfileRepositoryType".equals(var3)
					|| "websphere.usermanager.serviceprovider.add.propertyextensionrepository".equals(var1)
							&& !"PropertyExtensionRepositoryType".equals(var3)
					|| "websphere.usermanager.serviceprovider.add.realm".equals(var1) && !"RealmType".equals(var3)) {
				throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_WRONG_DATA_OBJECT_TYPE",
						WIMMessageHelper.generateMsgParms(var3, var1), CLASSNAME, "checkDataObjectType");
			}
		}

	}

	void saveConfig() {
		this.savedConfigDG = SDOHelper.createDataGraph("http://www.ibm.com/websphere/wim/config");
		DataObject var2 = DataGraphHelper
				.cloneDataObject(this.configDG.getRootObject().getDataObject("configurationProvider"));
		this.savedConfigDG.getRootObject().setDataObject("configurationProvider", var2);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig", "Saved Config Data (For the purpose of Rollback):");
			trcLogger.logp(Level.FINER, CLASSNAME, "saveConfig", WIMTraceHelper.printDataGraph(this.savedConfigDG));
		}

	}

	void rollbackToSavedConfig() throws WIMSystemException {
		if (this.savedConfigDG != null) {
			this.configDG = this.savedConfigDG;
			DataGraphHelper.saveDataGraph(this.configDG, this.wimConfigXMLFilePath);
			this.refreshConfigCache();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "rollbackToSavedConfig", "Config Data after Rollback:");
				trcLogger.logp(Level.FINER, CLASSNAME, "rollbackToSavedConfig",
						WIMTraceHelper.printDataGraph(this.configDG));
			}
		} else if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "rollbackToSavedConfig",
					"Configuration was not saved Hence Rollback failed.");
		}

	}

	public boolean isRDNProperty(String var1, String var2) {
		DataObject var3 = this.getSupportedEntityTypeDataObject(var1);
		if (var3 != null) {
			List var4 = var3.getList("rdnProperties");
			if (var4.contains(var2)) {
				return true;
			}
		}

		return false;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = ConfigManagerBase.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		configSchema = null;
		uriToSchema = Collections.synchronizedMap(new HashMap(1));
		classNameToURI = Collections.synchronizedMap(new HashMap());
		sFileSep = File.separator;
	}
}