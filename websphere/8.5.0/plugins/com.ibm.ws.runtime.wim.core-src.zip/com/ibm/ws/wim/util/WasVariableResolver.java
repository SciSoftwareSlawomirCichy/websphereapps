package com.ibm.ws.wim.util;

import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.management.configservice.ConfigServiceHelper;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.security.core.ContextManagerFactory;
import com.ibm.ws.wim.env.IVariableResolver;
import com.ibm.ws.wim.util.WasVariableResolver.1;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.ObjectName;

public class WasVariableResolver implements IVariableResolver {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public static final String CLASSNAME = "com.ibm.ws.wim.util.WasVariableResolver";
	private static final Logger trcLogger = WIMLogger.getTraceLogger("com.ibm.ws.wim.util.WasVariableResolver");
	private boolean debug = false;
	ConfigService configService;
	AdminService adminService;
	Session session;
	ObjectName[] variables;
	Properties otherVariables;
	String nodeName = null;
	String serverName = null;
	String cellName = null;

	public WasVariableResolver() throws Exception {
      String var1 = System.getProperty("com.ibm.ws.wim");
      if (var1 != null) {
         this.debug = Boolean.valueOf(var1);
      }

      this.printDebug("<init>");

      try {
         1 var2 = new 1(this);
         ContextManagerFactory.getInstance().runAsSystem(var2);
      } catch (Exception var3) {
         this.printDebug("<init> failed");
         var3.printStackTrace();
      }

      this.printDebug("<init> successful");
   }

	public String getVariableValue(String var1) throws Exception {
		return this.getVariableValue(var1, (Set) null);
	}

	private String getVariableValue(String var1, Set var2) throws Exception {
		if (this.configService == null) {
			return null;
		} else {
			String var3 = null;
			if (var2 == null) {
				var2 = new HashSet();
			}

			if (((Set) var2).contains(var1)) {
				return null;
			} else {
				if (this.otherVariables != null) {
					var3 = this.otherVariables.getProperty(var1);
				}

				int var6;
				if (var3 == null) {
					ObjectName var4 = null;
					byte var5 = 0;

					for (var6 = 0; var6 < this.variables.length; ++var6) {
						if (this.configService.getAttribute(this.session, this.variables[var6], "symbolicName")
								.equals(var1)) {
							Properties var7 = ConfigServiceHelper.getObjectLocation(this.variables[var6]);
							if (this.cellName == null) {
								this.cellName = var7.getProperty("cell");
							}

							String var8 = var7.getProperty("node");
							if (var8 == null || this.nodeName == null || var8.equals(this.nodeName)) {
								String var9 = var7.getProperty("server");
								if (var9 == null || this.serverName == null || var9.equals(this.serverName)) {
									if (var9 != null) {
										var4 = this.variables[var6];
										break;
									}

									if (var5 < 2) {
										if (var8 != null) {
											var5 = 2;
											var4 = this.variables[var6];
										}

										if (var5 < 1) {
											var5 = 1;
											var4 = this.variables[var6];
										}
									}
								}
							}
						}
					}

					if (var4 != null) {
						var3 = (String) this.configService.getAttribute(this.session, var4, "value");
					}
				}

				if (var3 != null) {
					int var10 = 0;
					((Set) var2).add(var1);

					int var11;
					while ((var11 = var3.indexOf("${", var10)) >= 0) {
						var6 = var3.indexOf("}", var11 + 2);
						if (var6 < var11) {
							break;
						}

						String var12 = this.getVariableValue(var3.substring(var11 + 2, var6), (Set) var2);
						if (var12 != null) {
							char[] var13 = var3.toCharArray();
							StringBuffer var14 = new StringBuffer();
							if (var11 > 0) {
								var14.append(var13, 0, var11);
							}

							var14.append(var12);
							if (var6 < var13.length - 1) {
								var14.append(var13, var6 + 1, var13.length - 1 - var6);
							}

							var3 = var14.toString();
							var10 = var11;
						} else {
							var10 = var6;
						}
					}

					((Set) var2).remove(var1);
				}

				return var3;
			}
		}
	}

	public String getCellName() {
		return this.cellName;
	}

	public String getNodeName() {
		return this.nodeName;
	}

	public String getServerName() {
		return this.serverName;
	}

	private void printDebug(String var1) {
		if (this.debug) {
			trcLogger.log(Level.FINER, "com.ibm.ws.wim.util.WasVariableResolver:" + var1);
		}

	}
}