package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_zh_TW extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"security.openid20.client.authrequestfailed",
					"CWTAI3002E: OpenID 信賴方 (RP) 無法將使用者重新導向 OpenID 提供者 (OP) 來鑑別，因為發生異常狀況 [{0}]。"},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: OpenID 信賴方 (RP) 無法起始設定，因為無法取得 WebSphere 伺服器的預設 SSLContext。異常狀況是 [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: OpenID 信賴方 (RP) 無法連接至 ID [{0}] 所指定的 OpenID 提供者 (OP)，因為發生異常狀況 [{1}]。"},
			{"security.openid20.client.initializationfailed", "CWTAI3005E: OpenID 信賴方 (RP) 無法起始設定，因為發生異常狀況 [{0}]。"},
			{"security.openid20.client.invalidaxrequired", "CWTAI3009E: OpenID 信賴方 (RP) 未起始設定，因為 [{0}] 內容的值格式不正確。"},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: OpenID 信賴方 (RP) 無法使用「基本鑑別」記號來鑑別要求，因為記號值無效。"},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: OpenID 信賴方 (RP) 無法起始設定，因為未正確指定 [{0}] 內容。必須是有效的 URL。"},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: OpenID 信賴方 (RP) 收到來自 OpenID 提供者 (OP) 的不正確回應。此錯誤的原因為 [{0}]。"},
			{"security.openid20.client.maxcachesizereached", "CWTAI3012E: OpenID 信賴方 (RP) 無法執行鑑別，因為已達到內部快取的容量上限。"},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: OpenID 信賴方 (RP) 無法起始設定，因為遺漏必要內容 axRequiredAttribute[n]。至少需要定義一個內容。"},
			{"security.openid20.client.missingproperty", "CWTAI3001E: OpenID 信賴方 (RP) 無法起始設定，因為必要內容 [{0}] 的值遺漏或空白。"},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: OpenID 信賴方 (RP) 需要 SSL (HTTPS)，但 OpenID 提供者 (OP) URL 是 HTTP：[{0}]。[{1}] 屬性應該符合目標 URL 架構。"},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: OpenID 信賴方 (RP) 收到來自 OpenID 提供者 (OP) 的回應不支援 OpenID 規格第 2 版。"},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: OpenID 信賴方 (RP) 在驗證來自 OpenID 提供者 (OP) 的回應時失敗。異常狀況為 [{0}]。"}};

	public Object[][] getContents() {
		return resources;
	}
}