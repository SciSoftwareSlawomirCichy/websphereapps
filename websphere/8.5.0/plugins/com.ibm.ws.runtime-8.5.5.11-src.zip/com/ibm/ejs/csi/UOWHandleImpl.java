package com.ibm.ejs.csi;

import com.ibm.ws.ActivitySession.ActivitySession;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import javax.transaction.Transaction;

public class UOWHandleImpl implements UOWHandle {
	protected final Transaction suspendedGlobalTx;
	protected final LocalTransactionCoordinator suspendedLocalTx;
	protected final ActivitySession suspendedActivitySession;

	UOWHandleImpl(Transaction suspendedGlobalTx) {
		this.suspendedActivitySession = null;
		this.suspendedLocalTx = null;
		this.suspendedGlobalTx = suspendedGlobalTx;
	}

	UOWHandleImpl(LocalTransactionCoordinator ltc) {
		this.suspendedActivitySession = null;
		this.suspendedLocalTx = ltc;
		this.suspendedGlobalTx = null;
	}

	UOWHandleImpl(ActivitySession as) {
		this.suspendedActivitySession = as;
		this.suspendedLocalTx = null;
		this.suspendedGlobalTx = null;
	}
}