package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.portability.MSSQLPortabilityLayer.1;
import com.ibm.ejs.cm.portability.MSSQLPortabilityLayer.2;
import com.ibm.ejs.cm.portability.MSSQLPortabilityLayer.3;
import com.ibm.ejs.cm.portability.MSSQLPortabilityLayer.4;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import com.ibm.ws.security.util.AccessController;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.StringTokenizer;

class MSSQLPortabilityLayer extends PortabilityLayerImpl {
	private static MSSQLPortabilityLayer instance;
	protected static final String FOR_UPDATE = "FOR UPDATE";
	protected static final String HOLDLOCK = "(UPDLOCK)";
	protected static final String WHERE = "WHERE";
	protected static final int CHAR_COUNT = 10;
	private static final TraceComponent tc = Tr.register(MSSQLPortabilityLayer.class);

	protected MSSQLPortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.errorMap.put(new Integer(2714), TableAlreadyExistsException.class);
		this.errorMap.put(new Integer(2627), DuplicateKeyException.class);
		this.errorMap.put(new Integer(4), ResourceAllocationException.class);
		this.errorMap.put("08S01", StaleConnectionException.class);
		this.errorMap.put(new Integer(230), StaleConnectionException.class);
		this.errorMap.put(new Integer(1779), PrimarykeyAlreadyDefinedException.class);
		this.errorMap.put(new Integer(3701), TableDoesNotExistException.class);
		this.errorMap.put(new Integer(208), TableDoesNotExistException.class);
		this.errorMap.put(new Integer(4902), TableDoesNotExistException.class);
		this.typeMap.setElementAt(" TEXT NOT NULL ", 7);
		this.typeMap.setElementAt(" TEXT ", 8);
		this.typeMap.setElementAt(" IMAGE ", 9);
		this.typeMap.setElementAt(" VARBINARY(2048) ", 10);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void createTable(Connection connection, String schema, String sql) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTable", new Object[]{connection, schema, sql});
		}

		String doctoredSql = replaceString(sql, "BLOB(1M)", "IMAGE");
		super.createTable(connection, schema, doctoredSql);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTable");
		}

	}

	public void createTableForPersister(Connection connection, String schema, String name, String sql)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTableForPersister", new Object[]{connection, schema, sql});
		}

		String doctoredSql = replaceString(sql, "BLOB(1M)", "IMAGE");
		if (doctoredSql.indexOf(" DOUBLE") > 0) {
			doctoredSql = replaceString(doctoredSql, " DOUBLE ", " FLOAT ");
			doctoredSql = replaceString(doctoredSql, " DOUBLE,", " FLOAT,");
			doctoredSql = replaceString(doctoredSql, " DOUBLE(", " FLOAT(");
			doctoredSql = replaceString(doctoredSql, " DOUBLE)", " FLOAT)");
		}

		if (doctoredSql.indexOf(" DATE") > 0) {
			doctoredSql = replaceString(doctoredSql, " DATE ", " DATETIME ");
			doctoredSql = replaceString(doctoredSql, " DATE,", " DATETIME,");
			doctoredSql = replaceString(doctoredSql, " DATE)", " DATETIME)");
		}

		if (doctoredSql.indexOf(" TIME") > 0) {
			doctoredSql = replaceString(doctoredSql, " TIME ", " DATETIME ");
			doctoredSql = replaceString(doctoredSql, " TIME,", " DATETIME,");
			doctoredSql = replaceString(doctoredSql, " TIME)", " DATETIME)");
		}

		super.createTableForPersister(connection, schema, name, doctoredSql);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTableForPersister");
		}

	}

	public String addRowLockHint(String sql) {
		return sql + "FOR UPDATE";
	}

	public boolean supportsRowLockHint() {
		return true;
	}

	public void setDate(PreparedStatement ps, int parameterIndex, Date date, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setDate", new Object[]{ps, new Integer(parameterIndex), date, cal});
		}

		Timestamp ts = this.DateToTimestamp(date);
		if (ts == null) {
			ps.setNull(parameterIndex, 93);
		} else {
			ps.setTimestamp(parameterIndex, ts, cal);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setDate");
		}

	}

	public void setDate(PreparedStatement ps, int parameterIndex, Date date) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setDate", new Object[]{ps, new Integer(parameterIndex), date});
		}

		Timestamp ts = this.DateToTimestamp(date);
		if (ts == null) {
			ps.setNull(parameterIndex, 93);
		} else {
			ps.setTimestamp(parameterIndex, ts);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setDate");
		}

	}

	public void setTime(PreparedStatement ps, int parameterIndex, Time time, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setTime", new Object[]{ps, new Integer(parameterIndex), time, cal});
		}

		Timestamp ts = this.TimeToTimestamp(time);
		if (ts == null) {
			ps.setNull(parameterIndex, 93);
		} else {
			ps.setTimestamp(parameterIndex, ts, cal);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setTime");
		}

	}

	public void setTime(PreparedStatement ps, int parameterIndex, Time time) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setTime", new Object[]{ps, new Integer(parameterIndex), time});
		}

		Timestamp ts = this.TimeToTimestamp(time);
		if (ts == null) {
			ps.setNull(parameterIndex, 93);
		} else {
			ps.setTimestamp(parameterIndex, ts);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setTime");
		}

	}

	public Date getDate(ResultSet rs, int columnIndex, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDate", new Object[]{rs, new Integer(columnIndex), cal});
		}

		Timestamp ts = rs.getTimestamp(columnIndex, cal);
		Date d = this.TimestampToDate(ts);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDate");
		}

		return d;
	}

	public Date getDate(ResultSet rs, String columnName, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDate", new Object[]{rs, columnName, cal});
		}

		Timestamp ts = rs.getTimestamp(columnName, cal);
		Date d = this.TimestampToDate(ts);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDate");
		}

		return d;
	}

	public Date getDate(ResultSet rs, int columnIndex) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDate", new Object[]{rs, new Integer(columnIndex)});
		}

		Timestamp ts = rs.getTimestamp(columnIndex);
		Date d = this.TimestampToDate(ts);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDate");
		}

		return d;
	}

	public Date getDate(ResultSet rs, String columnName) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDate", new Object[]{rs, columnName});
		}

		Timestamp ts = rs.getTimestamp(columnName);
		Date d = this.TimestampToDate(ts);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDate");
		}

		return d;
	}

	public Time getTime(ResultSet rs, int columnIndex, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTime", new Object[]{rs, new Integer(columnIndex), cal});
		}

		Timestamp ts = rs.getTimestamp(columnIndex, cal);
		Time t = this.TimestampToTime(ts);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTime");
		}

		return t;
	}

	public Time getTime(ResultSet rs, String columnName, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTime", new Object[]{rs, columnName, cal});
		}

		Timestamp ts = rs.getTimestamp(columnName, cal);
		Time t = this.TimestampToTime(ts);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTime");
		}

		return t;
	}

	public Time getTime(ResultSet rs, int columnIndex) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTime", new Object[]{rs, new Integer(columnIndex)});
		}

		Timestamp ts = rs.getTimestamp(columnIndex);
		Time t = this.TimestampToTime(ts);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTime");
		}

		return t;
	}

	public Time getTime(ResultSet rs, String columnName) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTime", new Object[]{rs, columnName});
		}

		Timestamp ts = rs.getTimestamp(columnName);
		Time t = this.TimestampToTime(ts);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTime");
		}

		return t;
	}

	public String scanSQL(String sql) {
		if (sql == null) {
			return null;
		} else {
			StringBuffer sb = new StringBuffer(sql);
			sql = sql.toUpperCase();
			int last = 0;

			int f;
			for (int numReplaced = 0; (f = sql.indexOf("FOR UPDATE", last)) > 0; ++numReplaced) {
				int w = sql.indexOf("WHERE", last);
				if (w < 0 || w > f) {
					w = f;
				}

				last = f + 10;
				sb.delete(f + 14 * numReplaced, last + 14 * numReplaced);
				sb.insert(w + 14 * numReplaced, "WITH (UPDLOCK, ROWLOCK) ");
			}

			return sb.toString();
		}
	}

	public String processSQL(String sqlString, int isolevel, boolean addForUpdate, boolean addextendedforUpdateSyntax) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "processSQL - sqlString, isolevel, addForUpdate, addextendedforupdate: ",
					new Object[]{sqlString, new Integer(isolevel), new Boolean(addForUpdate),
							new Boolean(addextendedforUpdateSyntax)});
		}

		if (addForUpdate && sqlString != null) {
			StringBuffer stmt = new StringBuffer(sqlString.length() + 24);
			stmt.append(sqlString);
			sqlString = sqlString.toUpperCase();
			int w = sqlString.indexOf("WHERE", 0);
			if (w == -1) {
				stmt.append(" WITH (UPDLOCK, ROWLOCK)");
			} else {
				stmt.insert(w, "WITH (UPDLOCK, ROWLOCK) ");
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "processSQL - The modified sqlString is: ", stmt);
			}

			return new String(stmt);
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "processSQL - no change");
			}

			return sqlString;
		}
	}

	private Timestamp DateToTimestamp(Date d) {
      if (d == null) {
         return null;
      } else {
         Timestamp ts = (Timestamp)AccessController.doPrivileged(new 1(this, d));
         return ts;
      }
   }

	private Timestamp TimeToTimestamp(Time t) {
      if (t == null) {
         return null;
      } else {
         Date d = new Date(System.currentTimeMillis());
         Timestamp ts = (Timestamp)AccessController.doPrivileged(new 2(this, d, t));
         return ts;
      }
   }

	private Date TimestampToDate(Timestamp ts) {
      if (ts == null) {
         return null;
      } else {
         StringTokenizer strTok = new StringTokenizer(ts.toString());
         String token = null;
         if (strTok.hasMoreTokens()) {
            token = strTok.nextToken();
         }

         return (Date)AccessController.doPrivileged(new 3(this, token));
      }
   }

	private Time TimestampToTime(Timestamp ts) {
      if (ts == null) {
         return null;
      } else {
         StringTokenizer strTok = new StringTokenizer(ts.toString());

         String token;
         for(token = null; strTok.hasMoreTokens(); token = strTok.nextToken()) {
            ;
         }

         int index = token.indexOf(46);
         String time = token.substring(0, index);
         return (Time)AccessController.doPrivileged(new 4(this, time));
      }
   }

	public static PortabilityLayer getInstance() {
		if (instance == null) {
			instance = new MSSQLPortabilityLayer();
		}

		return instance;
	}
}