package com.ibm.ws.wim.config;

import com.ibm.websphere.management.Session;
import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.security.util.WSEncoderDecoder;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.CustomPropertiesType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.PropertyExtensionRepositoryType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.util.UniqueNameHelper;
import commonj.sdo.DataObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GenericRepositoryConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	private static final String CLASSNAME = GenericRepositoryConfigHelper.class.getName();
	private static final Logger trcLogger;

	public String updateIdMgrRepository(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "updateIdMgrRepository", "params = " + var2);
		}

		String var5 = (String) var2.get("id");
		RepositoryType var6 = ConfigUtils.getRepositoryById(var1, var5);
		if (!(var6 instanceof ProfileRepositoryType)) {
			String var15 = ConfigUtils.getRepositoryType(var6);
			throw new WIMConfigurationException("CONFIG_NON_PROFILE_REPO_CANNOT_BE_UPDATED",
					WIMMessageHelper.generateMsgParms(var15), Level.SEVERE, CLASSNAME, "updateIdMgrRepository");
		} else {
			List var7 = (List) var2.get("loginProperties");
			ValidationHelper.validateStringInputInList("loginProperties", CLASSNAME, "updateIdMgrRepository", var7,
					true);
			ConfigValidator.validateRepositoryParams(var5, ConfigUtils.getRepositoryType(var6), var2);
			List var8 = (List) var2.get("repositoriesForGroups");
			ConfigValidator.validateRepositoriesForGroup(ConfigUtils.getConfigProvider(var1), var8);
			ProfileRepositoryType var9 = (ProfileRepositoryType) var6;
			String var10 = (String) var2.get("adapterClassName");
			if (var10 != null) {
				var9.setAdapterClassName(var10);
			}

			Boolean var11 = (Boolean) var2.get("supportPaging");
			if (var11 != null) {
				var9.setSupportPaging(var11);
			}

			var11 = (Boolean) var2.get("supportSorting");
			if (var11 != null) {
				var9.setSupportSorting(var11);
			}

			var11 = (Boolean) var2.get("supportTransactions");
			if (var11 != null) {
				var9.setSupportTransactions(var11);
			}

			var11 = (Boolean) var2.get("isExtIdUnique");
			if (var11 != null) {
				var9.setIsExtIdUnique(var11);
			}

			var11 = (Boolean) var2.get("supportExternalName");
			if (var11 != null) {
				var9.setSupportExternalName(var11);
			}

			var11 = (Boolean) var2.get("supportAsyncMode");
			if (var11 != null) {
				var9.setSupportAsyncMode(var11);
			}

			var11 = (Boolean) var2.get("readOnly");
			if (var11 != null) {
				var9.setReadOnly(var11);
			}

			String var12 = (String) var2.get("supportChangeLog");
			ConfigValidator.validateSupportChangeLogParameter(var12);
			if (var12 != null) {
				var9.setSupportChangeLog(var12.toLowerCase());
			}

			List var13 = (List) var2.get("EntityTypesNotAllowCreate");
			List var14 = var9.getEntityTypesNotAllowCreate();
			if (var13 != null) {
				ConfigUtils.addOrRemovePresentList("EntityTypesNotAllowCreate", var13, var14);
			}

			var13 = (List) var2.get("EntityTypesNotAllowUpdate");
			var14 = var9.getEntityTypesNotAllowUpdate();
			if (var13 != null) {
				ConfigUtils.addOrRemovePresentList("EntityTypesNotAllowUpdate", var13, var14);
			}

			var13 = (List) var2.get("EntityTypesNotAllowRead");
			var14 = var9.getEntityTypesNotAllowRead();
			if (var13 != null) {
				ConfigUtils.addOrRemovePresentList("EntityTypesNotAllowRead", var13, var14);
			}

			var13 = (List) var2.get("EntityTypesNotAllowDelete");
			var14 = var9.getEntityTypesNotAllowDelete();
			if (var13 != null) {
				ConfigUtils.addOrRemovePresentList("EntityTypesNotAllowDelete", var13, var14);
			}

			var14 = var9.getRepositoriesForGroups();
			if (var8 != null) {
				ConfigUtils.addOrRemovePresentList("repositoriesForGroups", var8, var14);
			}

			var14 = var9.getLoginProperties();
			if (var7 != null) {
				ConfigUtils.addOrRemovePresentList("loginProperties", var7, var14);
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "updateIdMgrRepository");
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public String deleteIdMgrRepository(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrRepository", "id = " + var2);
		}

		RepositoryType var5 = null;
		if (!"FED".equals(var2) && !"LA".equals(var2)) {
			var5 = ConfigUtils.getRepositoryById(var1, var2);
			ConfigValidator.validateDeleteIdMgrRepository(ConfigUtils.getConfigProvider(var1), var2);
		} else {
			var5 = ConfigUtils.getRepositoryByIdIncludeLAandFED(var1, var2);
		}

		((DataObject) var5).delete();
		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrRepository");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public Map listIdMgrRepositories(String var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "listIdMgrRepositories", "sessionId=" + var1);
		}

		HashMap var4 = new HashMap();
		List var5 = ConfigUtils.getProfileRepositories(var1);

		for (int var6 = 0; var6 < var5.size(); ++var6) {
			Object var7 = var5.get(var6);
			HashMap var8 = new HashMap();
			String var9 = ((RepositoryType) var7).getId();
			if (var7 instanceof FileRepositoryType) {
				var8.put("repositoryType", "File");
				var8.put("host", "LocalHost");
			} else if (var7 instanceof LdapRepositoryType) {
				var8.put("repositoryType", "LDAP");
				LdapRepositoryType var10 = (LdapRepositoryType) var7;
				var8.put("specificRepositoryType", var10.getLdapServerType());
				if (var10.getLdapServerConfiguration() != null) {
					List var11 = var10.getLdapServerConfiguration().getLdapServers();
					if (var11.size() > 0) {
						LdapServersType var12 = (LdapServersType) var11.get(0);
						List var13 = var12.getConnections();
						if (var13.size() > 0) {
							ConnectionsType var14 = (ConnectionsType) var13.get(0);
							var8.put("host", var14.getHost());
						}
					}
				}
			} else if (var7 instanceof DatabaseRepositoryType) {
				var8.put("repositoryType", "DB");
				DatabaseRepositoryType var15 = (DatabaseRepositoryType) var7;
				var8.put("specificRepositoryType", var15.getDatabaseType());
				var8.put("host", var15.getDataSourceName());
			} else {
				var8.put("repositoryType", "Custom");
			}

			var4.put(var9, var8);
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "listIdMgrRepositories", "returnMap=" + var4);
		}

		return var4;
	}

	public Map getIdMgrRepository(String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrRepository", "id = " + var2);
		}

		HashMap var5 = new HashMap();
		RepositoryType var6 = ConfigUtils.getRepositoryByIdIncludeLAandFED(var1, var2);
		if (var6 == null) {
			throw new WIMConfigurationException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateMsgParms(var2),
					Level.SEVERE, CLASSNAME, "getIdMgrRepository");
		} else {
			var5.put("id", var2);
			if (var6 instanceof EntryMappingRepositoryType) {
				this.getFederationRepositoryInfo((EntryMappingRepositoryType) var6, var5);
			}

			if (var6 instanceof PropertyExtensionRepositoryType) {
				this.getLookAsideRepositoryInfo((PropertyExtensionRepositoryType) var6, var5);
			}

			if (var6 instanceof LdapRepositoryType) {
				this.getLDAPRepositoryInfo((LdapRepositoryType) var6, var5);
			}

			if (var6 instanceof FileRepositoryType) {
				this.getFileRepositoryInfo((FileRepositoryType) var6, var5);
			}

			if (var6 instanceof DatabaseRepositoryType) {
				this.getDatabaseRepositoryInfo((DatabaseRepositoryType) var6, var5);
			}

			if (var6 instanceof ProfileRepositoryType) {
				this.getProfileRepositoryTypeInfo((ProfileRepositoryType) var6, var5);
			}

			return var5;
		}
	}

	public String getLDAPType(String var1, String var2) {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getLDAPType", "id = " + var2);
		}

		String var5 = null;
		RepositoryType var6 = null;

		try {
			var6 = ConfigUtils.getRepositoryByIdIncludeLAandFED(var1, var2);
		} catch (Exception var8) {
			if (var4) {
				trcLogger.log(Level.FINE, "on getLDAPType, repoId information could not be retrieved for " + var2,
						var8);
			}
		}

		if (var6 == null) {
			if (var4) {
				trcLogger.fine("on getLDAPType, repoId was not found " + var2);
			}

			return var5;
		} else {
			if (var6 instanceof LdapRepositoryType) {
				var5 = ((LdapRepositoryType) var6).getLdapServerType();
			}

			return var5;
		}
	}

	private void getProfileRepositoryTypeInfo(ProfileRepositoryType var1, Map var2) throws WIMException {
		if (var1.getAdapterClassName() != null) {
			var2.put("adapterClassName", var1.getAdapterClassName());
		}

		if (var1.isSetSupportPaging()) {
			var2.put("supportPaging", var1.isSupportPaging());
		}

		if (var1.isSetSupportSorting()) {
			var2.put("supportSorting", var1.isSupportSorting());
		}

		if (var1.isSetSupportTransactions()) {
			var2.put("supportTransactions", var1.isSupportTransactions());
		}

		if (var1.isSetIsExtIdUnique()) {
			var2.put("isExtIdUnique", var1.isIsExtIdUnique());
		}

		if (var1.isSetSupportExternalName()) {
			var2.put("supportExternalName", var1.isSupportExternalName());
		}

		if (var1.isSetSupportAsyncMode()) {
			var2.put("supportAsyncMode", var1.isSupportAsyncMode());
		}

		if (var1.isSetReadOnly()) {
			var2.put("readOnly", var1.isReadOnly());
		}

		if (var1.isSetSupportChangeLog()) {
			var2.put("supportChangeLog", String.valueOf(var1.getSupportChangeLog()));
		}

		this.addBaseEntryMapInfo(var1, var2);
		if (var1.getEntityTypesNotAllowCreateAsArray() != null && var1.getEntityTypesNotAllowCreate().size() != 0) {
			var2.put("EntityTypesNotAllowCreate", ConfigUtils.convertEList(var1.getEntityTypesNotAllowCreate()));
		}

		if (var1.getEntityTypesNotAllowUpdate() != null && var1.getEntityTypesNotAllowUpdate().size() != 0) {
			var2.put("EntityTypesNotAllowUpdate", ConfigUtils.convertEList(var1.getEntityTypesNotAllowUpdate()));
		}

		if (var1.getEntityTypesNotAllowRead() != null && var1.getEntityTypesNotAllowRead().size() != 0) {
			var2.put("EntityTypesNotAllowRead", ConfigUtils.convertEList(var1.getEntityTypesNotAllowRead()));
		}

		if (var1.getEntityTypesNotAllowDelete() != null && var1.getEntityTypesNotAllowDelete().size() != 0) {
			var2.put("EntityTypesNotAllowDelete", ConfigUtils.convertEList(var1.getEntityTypesNotAllowDelete()));
		}

		if (var1.getRepositoriesForGroups() != null && var1.getRepositoriesForGroups().size() != 0) {
			var2.put("repositoriesForGroups", ConfigUtils.convertEList(var1.getRepositoriesForGroups()));
		}

		if (var1.getLoginProperties() != null && var1.getLoginProperties().size() != 0) {
			var2.put("loginProperties", ConfigUtils.convertEList(var1.getLoginProperties()));
		}

		this.addCustomPropertiesInfo(var1, var2);
	}

	private void getFederationRepositoryInfo(EntryMappingRepositoryType var1, Map var2) {
		String var3 = var1.getDataSourceName();
		String var4 = var1.getDatabaseType();
		String var5 = var1.getAdapterClassName();
		String var6 = var1.getDbAdminId();
		String var7 = var1.getDbAdminPassword();
		String var8 = var1.getDbURL();
		String var9 = var1.getJDBCDriverClass();
		if (var3 != null) {
			var2.put("dataSourceName", var3);
		}

		if (var4 != null) {
			var2.put("databaseType", var4);
		}

		if (var5 != null) {
			var2.put("adapterClassName", var5);
		}

		if (var6 != null) {
			var2.put("dbAdminId", var6);
		}

		if (var7 != null) {
			var2.put("dbAdminPassword", var7);
		}

		if (var8 != null) {
			var2.put("dbURL", var8);
		}

		if (var9 != null) {
			var2.put("JDBCDriverClass", var9);
		}

	}

	private void getLookAsideRepositoryInfo(PropertyExtensionRepositoryType var1, Map var2) {
		String var3 = var1.getDataSourceName();
		String var4 = var1.getDatabaseType();
		String var5 = var1.getAdapterClassName();
		Integer var6 = new Integer(var1.getEntityRetrievalLimit());
		String var7 = var1.getDbAdminId();
		String var8 = var1.getDbAdminPassword();
		String var9 = var1.getDbURL();
		String var10 = var1.getJDBCDriverClass();
		if (var3 != null) {
			var2.put("dataSourceName", var3);
		}

		if (var4 != null) {
			var2.put("databaseType", var4);
		}

		if (var5 != null) {
			var2.put("adapterClassName", var5);
		}

		if (var6 != null) {
			var2.put("entityRetrievalLimit", var6);
		}

		if (var7 != null) {
			var2.put("dbAdminId", var7);
		}

		if (var8 != null) {
			var2.put("dbAdminPassword", var8);
		}

		if (var9 != null) {
			var2.put("dbURL", var9);
		}

		if (var10 != null) {
			var2.put("JDBCDriverClass", var10);
		}

	}

	private void getFileRepositoryInfo(FileRepositoryType var1, Map var2) {
		String var3 = var1.getBaseDirectory();
		if (var3 != null) {
			var2.put("baseDirectory", var3);
		}

		var3 = var1.getFileName();
		if (var3 != null) {
			var2.put("fileName", var3);
		}

		var3 = var1.getMessageDigestAlgorithm();
		if (var3 != null) {
			var2.put("messageDigestAlgorithm", var3);
		}

		Integer var4 = new Integer(var1.getSaltLength());
		if (var4 != null) {
			var2.put("saltLength", var4);
		}

		Integer var5 = new Integer(var1.getKeyLength());
		if (var5 != null) {
			var2.put("keyLength", var5);
		}

		Integer var6 = new Integer(var1.getHashIterations());
		if (var6 != null) {
			var2.put("hashIterations", var6);
		}

		Integer var7;
		if (var1.isSetAccountLockoutDuration()) {
			var7 = new Integer(var1.getAccountLockoutDuration());
			if (var7 != null) {
				var2.put("accountLockoutDuration", var7);
			}
		}

		if (var1.isSetAccountLockoutThreshold()) {
			var7 = new Integer(var1.getAccountLockoutThreshold());
			if (var7 != null) {
				var2.put("accountLockoutThreshold", var7);
			}
		}

		if (var1.isSetIgnoreFailedLoginAfter()) {
			var7 = new Integer(var1.getIgnoreFailedLoginAfter());
			if (var7 != null) {
				var2.put("ignoreFailedLoginAfter", var7);
			}
		}

	}

	private void getLDAPRepositoryInfo(LdapRepositoryType var1, Map var2) {
		String var3 = var1.getLdapServerType();
		var2.put("ldapServerType", var3);
		var2.put("translateRDN", var1.isTranslateRDN());
		if (var1.getCertificateMapMode() != null) {
			var2.put("certificateMapMode", var1.getCertificateMapMode());
		}

		if (var1.getCertificateFilter() != null) {
			var2.put("certificateFilter", var1.getCertificateFilter());
		}

		if (var1.getLoginProperties().size() > 0) {
			var2.put("loginProperties", ConfigUtils.convertEList(var1.getLoginProperties()));
		}

		LdapServerConfigurationType var4 = var1.getLdapServerConfiguration();
		if (var4.isSetSearchTimeLimit()) {
			var2.put("searchTimeLimit", new Integer(var4.getSearchTimeLimit()));
		}

		if (var4.isSetSearchCountLimit()) {
			var2.put("searchCountLimit", new Integer(var4.getSearchCountLimit()));
		}

		if (var4.isSetSearchPageSize()) {
			var2.put("searchPageSize", new Integer(var4.getSearchPageSize()));
		}

		var3 = var4.getSslConfiguration();
		if (var3 != null) {
			var2.put("sslConfiguration", var3);
		}

		if (var4.isSetReturnToPrimaryServer()) {
			var2.put("returnToPrimaryServer", var4.isReturnToPrimaryServer());
		}

		if (var4.isSetPrimaryServerQueryTimeInterval()) {
			var2.put("primaryServerQueryTimeInterval", new Integer(var4.getPrimaryServerQueryTimeInterval()));
		}

	}

	private void getDatabaseRepositoryInfo(DatabaseRepositoryType var1, Map var2) {
		var2.put("databaseType", var1.getDatabaseType());
		if (var1.getDataSourceName() != null) {
			var2.put("dataSourceName", var1.getDataSourceName());
		}

		if (var1.getDbURL() != null) {
			var2.put("dbURL", var1.getDbURL());
		}

		if (var1.getDbAdminId() != null) {
			var2.put("dbAdminId", var1.getDbAdminId());
		}

		if (var1.getDbAdminPassword() != null) {
			var2.put("dbAdminPassword", var1.getDbAdminPassword());
		}

		if (var1.getJDBCDriverClass() != null) {
			var2.put("JDBCDriverClass", var1.getJDBCDriverClass());
		}

		if (var1.isSetEntityRetrievalLimit()) {
			var2.put("entityRetrievalLimit", new Integer(var1.getEntityRetrievalLimit()));
		}

		if (var1.isSetSaltLength()) {
			var2.put("saltLength", new Integer(var1.getSaltLength()));
		}

		if (var1.getEncryptionKey() != null) {
			var2.put("encryptionKey", var1.getEncryptionKey());
		}

		if (var1.isSetHashAlgorithm()) {
			var2.put("hashAlgorithm", var1.getHashAlgorithm());
		}

		if (var1.isSetHashIterations()) {
			var2.put("hashIterations", var1.getHashIterations());
		}

		if (var1.isSetHashKeyLength()) {
			var2.put("hashKeyLength", var1.getHashKeyLength());
		}

		if (var1.isSetHashSaltLength()) {
			var2.put("hashSaltLength", var1.getHashSaltLength());
		}

	}

	private void addBaseEntryMapInfo(ProfileRepositoryType var1, Map var2) {
		HashMap var3 = new HashMap();
		List var4 = var1.getBaseEntries();
		if (var4 != null && var4.size() != 0) {
			for (int var5 = 0; var5 < var4.size(); ++var5) {
				BaseEntriesType var6 = (BaseEntriesType) var4.get(var5);
				var3.put(var6.getName(), var6.getNameInRepository());
			}

			var2.put("baseEntries", var3);
		}
	}

	private void addCustomPropertiesInfo(ProfileRepositoryType var1, Map var2) {
		HashMap var3 = new HashMap();
		List var4 = var1.getCustomProperties();
		if (var4 != null && var4.size() != 0) {
			for (int var5 = 0; var5 < var4.size(); ++var5) {
				CustomPropertiesType var6 = (CustomPropertiesType) var4.get(var5);
				var3.put(var6.getName(), var6.getValue());
			}

			var2.put("CustomProperties", var3);
		}
	}

	@Deprecated
	public String addIdMgrRepositoryBaseEntry(String var1, Map var2) throws Exception {
		return this.addIdMgrRepositoryBaseEntry((Map) var2, (Session) null);
	}

	public String addIdMgrRepositoryBaseEntry(Map var1, Session var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrRepositoryBaseEntry", "params = " + var1);
		}

		String var5 = var2.toString();
		String var6 = (String) var1.get("id");
		String var7 = (String) var1.get("name");
		this.checkForRootValue(var7, var6, var5);
		if (var7.equalsIgnoreCase("root")) {
			var7 = "";
		}

		var7 = UniqueNameHelper.getValidUniqueName(var7);
		String var8 = UniqueNameHelper.getValidUniqueName((String) var1.get("nameInRepository"));
		ConfigValidator.validateAddIdMgrRepositoryBaseEntry(ConfigUtils.getConfigProvider(var5), var6, var7);
		ProfileRepositoryType var9 = (ProfileRepositoryType) ConfigUtils.getRepositoryById(var5, var6);
		this.validateNameInRepository(var6, var9, var7, var8, var2);
		if (this.getBaseEntryInRepository(var7, var9) == null) {
			BaseEntriesType var10 = var9.createBaseEntries();
			var10.setName(var7);
			var10.setNameInRepository(var8);
			if (var4) {
				trcLogger.exiting(CLASSNAME, "addIdMgrRepositoryBaseEntry");
			}

			return ConfigUtils.saveConfig(var5);
		} else {
			throw new WIMConfigurationException("BASE_ENTRY_ALREADY_IN_REPOSITORY",
					WIMMessageHelper.generateMsgParms(var7, var6), Level.SEVERE, CLASSNAME,
					"addIdMgrRepositoryBaseEntry");
		}
	}

	private BaseEntriesType getBaseEntryInRepository(String var1, ProfileRepositoryType var2) {
		List var3 = var2.getBaseEntries();
		BaseEntriesType var4 = null;

		for (int var5 = 0; var5 < var3.size(); ++var5) {
			BaseEntriesType var6 = (BaseEntriesType) var3.get(var5);
			String var7 = var6.getName();
			if (var1.equals(var7)) {
				var4 = var6;
				break;
			}
		}

		return var4;
	}

	@Deprecated
	public String updateIdMgrRepositoryBaseEntry(String var1, Map var2) throws Exception {
		return this.updateIdMgrRepositoryBaseEntry((Map) var2, (Session) null);
	}

	public String updateIdMgrRepositoryBaseEntry(Map var1, Session var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "updateIdMgrRepositoryBaseEntry", "params = " + var1);
		}

		String var5 = var2.toString();
		String var6 = (String) var1.get("id");
		String var7 = (String) var1.get("name");
		this.checkForRootValue(var7, var6, var5);
		if (var7.equalsIgnoreCase("root")) {
			var7 = "";
		}

		var7 = UniqueNameHelper.getValidUniqueName(var7);
		String var8 = UniqueNameHelper.getValidUniqueName((String) var1.get("nameInRepository"));
		ProfileRepositoryType var9 = (ProfileRepositoryType) ConfigUtils.getRepositoryById(var5, var6);
		BaseEntriesType var10 = this.getBaseEntryInRepository(var7, var9);
		if (var10 == null) {
			throw new WIMConfigurationException("BASE_ENTRY_NOT_FOUND_IN_REPOSITORY",
					WIMMessageHelper.generateMsgParms(var7, var6), Level.SEVERE, CLASSNAME,
					"updateIdMgrRepositoryBaseEntry");
		} else {
			this.validateNameInRepository(var6, var9, var7, var8, var2);
			var10.setNameInRepository(var8);
			if (var4) {
				trcLogger.exiting(CLASSNAME, "updateIdMgrRepositoryBaseEntry");
			}

			return ConfigUtils.saveConfig(var5);
		}
	}

	private void checkForRootValue(String var1, String var2, String var3) throws WIMConfigurationException {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.finer("base entry name is " + var1);
		}

		if (var1.equalsIgnoreCase("root")) {
			String var7 = this.getLDAPType(var3, var2);
			if (var5) {
				trcLogger.finer("LDAP type is " + var7);
			}

			if (var7 != null && (var7.equals("AD") || var7.equals("ADAM"))) {
				throw new WIMConfigurationException("LDAP_TYPE_WITH_ROOT_NOT_SUPPORTED",
						WIMMessageHelper.generateMsgParms(var7), Level.SEVERE, CLASSNAME, "checkForRootValue");
			}
		}

	}

	private void validateNameInRepository(String var1, ProfileRepositoryType var2, String var3, String var4,
			Session var5) throws WIMConfigurationException {
		String var6 = var4;
		if (var4 == null) {
			var6 = var3;
		}

		if (var6 != null) {
			ArrayList var7 = new ArrayList();
			var7.add(var6);
			if (var2 instanceof LdapRepositoryType) {
				Map var8 = (new LDAPRepositoryConfigHelper()).getLDAPConnectionData((LdapRepositoryType) var2, var5);
				var8.put("nameInRepository", var7);
				ConfigValidator.validateRepositoryParams(var1, ConfigUtils.getRepositoryType(var2), var8);
			}
		}

	}

	public String deleteIdMgrRepositoryBaseEntry(String var1, Map var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrRepositoryBaseEntry", "params = " + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("name");
		if (var6.equalsIgnoreCase("root")) {
			var6 = "";
		}

		var6 = UniqueNameHelper.getValidUniqueName(var6);
		ProfileRepositoryType var7 = (ProfileRepositoryType) ConfigUtils.getRepositoryById(var1, var5);
		BaseEntriesType var8 = this.getBaseEntryInRepository(var6, var7);
		ConfigValidator.validateDeleteIdMgrRepositoryBaseEntry(ConfigUtils.getConfigProvider(var1), var5, var6);
		if (var8 == null) {
			throw new WIMConfigurationException("BASE_ENTRY_NOT_FOUND_IN_REPOSITORY",
					WIMMessageHelper.generateMsgParms(var6, var5), Level.SEVERE, CLASSNAME,
					"deleteIdMgrRepositoryBaseEntry");
		} else {
			((DataObject) var8).delete();
			if (var4) {
				trcLogger.exiting(CLASSNAME, "deleteIdMgrRepositoryBaseEntry");
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public Map listIdMgrRepositoryBaseEntries(String var1, Map var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrRepositoryBaseEntries", "params = " + var2);
		}

		HashMap var5 = new HashMap();
		String var6 = (String) var2.get("id");
		ProfileRepositoryType var7 = (ProfileRepositoryType) ConfigUtils.getRepositoryById(var1, var6);
		List var8 = var7.getBaseEntries();

		for (int var9 = 0; var9 < var8.size(); ++var9) {
			BaseEntriesType var10 = (BaseEntriesType) var8.get(var9);
			String var11 = var10.getName();
			if (var11.equals("")) {
				var11 = "root";
			}

			String var12 = var10.getNameInRepository();
			var5.put(var11, var12);
		}

		return var5;
	}

	public String setIdMgrCustomProperty(String var1, Map var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setIdMgrCustomProperty",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var5 = (String) var2.get("name");
		String var6 = (String) var2.get("value");
		if ("java.naming.security.credentials".equals(var5)) {
			WSEncoderDecoder var7 = new WSEncoderDecoder();
			var6 = var7.encode(var6);
		}

		String var15 = (String) var2.get("id");
		ProfileRepositoryType var8 = (ProfileRepositoryType) ConfigUtils.getRepositoryById(var1, var15);
		List var9 = var8.getCustomProperties();
		String var10;
		if ("ldapTimestampFormat".equals(var5) && var6 != null) {
			var10 = ConfigUtils.getRepositoryType(var8);
			if (!"LdapRepositoryType".equals(var10)) {
				throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms("ldapTimestampFormat", var15), CLASSNAME,
						"setIdMgrCustomProperty");
			}

			try {
				new SimpleDateFormat(var6);
			} catch (IllegalArgumentException var14) {
				throw new WIMConfigurationException("INVALID_TIMESTAMP_FORMAT", Level.SEVERE, CLASSNAME,
						"setIdMgrCustomProperty");
			}
		}

		if ("allowStartupIfDBDown".equals(var5) && var6 != null) {
			var10 = ConfigUtils.getRepositoryType(var8);
			if (!"DatabaseRepositoryType".equals(var10)) {
				throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms("allowStartupIfDBDown", var15), CLASSNAME,
						"setIdMgrCustomProperty");
			}
		}

		if ("preFetchData".equals(var5) && var6 != null) {
			this.populatePreFetchDataMap(var6);
		}

		if (var5.equals("*")) {
			var9.clear();
		} else {
			boolean var16 = false;
			if (var6 == null) {
				var6 = "";
			}

			for (int var11 = 0; var11 < var9.size(); ++var11) {
				CustomPropertiesType var12 = (CustomPropertiesType) var9.get(var11);
				String var13 = var12.getName();
				if (var13.equals(var5)) {
					var16 = true;
					if (var6.equals("")) {
						((DataObject) var12).delete();
					} else {
						var12.setValue(var6);
					}
					break;
				}
			}

			if (!var16 && !var6.equals("")) {
				CustomPropertiesType var17 = var8.createCustomProperties();
				var17.setName(var5);
				var17.setValue(var6);
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "setIdMgrCustomProperty");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public Map listIdMgrCustomProperties(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrCustomProperties", "id=" + var2);
		}

		ProfileRepositoryType var5 = (ProfileRepositoryType) ConfigUtils.getRepositoryById(var1, var2);
		List var6 = var5.getCustomProperties();
		HashMap var7 = new HashMap();

		for (int var8 = 0; var8 < var6.size(); ++var8) {
			CustomPropertiesType var9 = (CustomPropertiesType) var6.get(var8);
			var7.put(var9.getName(), var9.getValue());
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "listIdMgrCustomProperties", "returning=" + var7);
		}

		return var7;
	}

	private void populatePreFetchDataMap(String var1) throws WIMConfigurationException {
		String var2 = "populatePreFetchDataMap()";
		HashMap var3 = new HashMap();
		SchemaManager var4 = null;

		try {
			var4 = SchemaManager.singleton();
		} catch (WIMException var14) {
			throw new WIMConfigurationException(var14.getMessageKey(), var14.getMessageParams(), CLASSNAME, var2);
		}

		if (var1 != null) {
			StringTokenizer var5 = new StringTokenizer(var1, ";");

			while (var5.hasMoreTokens()) {
				try {
					String var6 = var5.nextToken();
					StringTokenizer var7 = new StringTokenizer(var6, ":");
					String var8 = var7.nextToken();
					if (var4.getEClass(var8) == null) {
						throw new WIMConfigurationException("INVALID_ENTITY_TYPE",
								WIMMessageHelper.generateMsgParms(var8), CLASSNAME, var2);
					}

					String var9 = var7.nextToken();
					StringTokenizer var10 = new StringTokenizer(var9, ",");
					List var11 = var4.getPropertyNames(var8);
					ArrayList var12 = new ArrayList();

					while (var10.hasMoreTokens()) {
						String var13 = var10.nextToken();
						if (!var11.contains(var13)) {
							throw new WIMConfigurationException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
									WIMMessageHelper.generateMsgParms(var13, var8), CLASSNAME, var2);
						}

						var12.add(var13);
					}

					if (!var12.isEmpty()) {
						var3.put(var8, var12);
					}
				} catch (NoSuchElementException var15) {
					throw new WIMConfigurationException("INVALID_PRE_FETCH_DATA_FORMAT",
							WIMMessageHelper.generateMsgParms("preFetchData"), Level.SEVERE, CLASSNAME, var2);
				}
			}
		}

	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}