package com.ibm.ws.wim.configmodel;

public interface PreExit {
	NotificationSubscriberList getNotificationSubscriberList();

	void setNotificationSubscriberList(NotificationSubscriberList var1);

	NotificationSubscriberList createNotificationSubscriberList();

	ModificationSubscriberList getModificationSubscriberList();

	void setModificationSubscriberList(ModificationSubscriberList var1);

	ModificationSubscriberList createModificationSubscriberList();
}