package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import javax.transaction.Transaction;

final class TxCookieImpl implements UOWCookie {
	protected final boolean beginner;
	protected final boolean isLocal;
	protected final TranStrategy txStrategy;
	protected final Transaction suspendedTx;
	protected LocalTransactionCoordinator suspendedLocalTx;
	protected EJBMethodInfoImpl methodInfo;
	protected SynchronizationRegistryUOWScope ivCoordinator;

	TxCookieImpl(boolean beginner, boolean isLocal, TranStrategy txStrategy, Transaction suspendedGlobalTx) {
		this.beginner = beginner;
		this.isLocal = isLocal;
		this.txStrategy = txStrategy;
		this.suspendedTx = suspendedGlobalTx;
		this.suspendedLocalTx = null;
		this.methodInfo = null;
		this.ivCoordinator = null;
	}

	public boolean beganTx() {
		return this.beginner;
	}

	public boolean isLocalTx() {
		return this.isLocal;
	}

	public SynchronizationRegistryUOWScope getTransactionalUOW() {
		return this.ivCoordinator;
	}

	public void setTransactionalUOW(SynchronizationRegistryUOWScope uowCoordinator) {
		this.ivCoordinator = uowCoordinator;
	}

	public SynchronizationRegistryUOWScope getSuspendedTransactionalUOW() {
		return this.suspendedTx != null
				? (SynchronizationRegistryUOWScope) this.suspendedTx
				: (SynchronizationRegistryUOWScope) this.suspendedLocalTx;
	}
}