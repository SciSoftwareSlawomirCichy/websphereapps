package com.ibm.ws.wim.configmodel;

public interface Krb5AuthenticationType {
	String getKrb5Principal();

	void setKrb5Principal(String var1);

	String getKrb5TicketCache();

	void setKrb5TicketCache(String var1);

	boolean isSetKrb5Principal();

	boolean isSetKrb5TicketCache();

	void unsetKrb5Principal();

	void unsetKrb5TicketCache();
}