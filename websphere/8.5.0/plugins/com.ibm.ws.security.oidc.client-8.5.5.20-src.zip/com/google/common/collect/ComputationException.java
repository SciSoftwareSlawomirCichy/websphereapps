package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public class ComputationException extends RuntimeException {
	private static final long serialVersionUID = 0L;

	public ComputationException(@NullableDecl Throwable cause) {
		super(cause);
	}
}