package com.ibm.icu.impl;

import com.ibm.icu.impl.Norm2AllModes.1;
import com.ibm.icu.impl.Norm2AllModes.ComposeNormalizer2;
import com.ibm.icu.impl.Norm2AllModes.DecomposeNormalizer2;
import com.ibm.icu.impl.Norm2AllModes.FCDNormalizer2;
import com.ibm.icu.impl.Norm2AllModes.NFCSingleton;
import com.ibm.icu.impl.Norm2AllModes.NFKCSingleton;
import com.ibm.icu.impl.Norm2AllModes.NFKC_CFSingleton;
import com.ibm.icu.impl.Norm2AllModes.NoopNormalizer2;
import com.ibm.icu.impl.Norm2AllModes.Norm2AllModesSingleton;
import com.ibm.icu.impl.Norm2AllModes.Normalizer2WithImpl;
import com.ibm.icu.text.Normalizer2;
import java.io.InputStream;

public final class Norm2AllModes {
	public final Normalizer2Impl impl;
	public final ComposeNormalizer2 comp;
	public final DecomposeNormalizer2 decomp;
	public final FCDNormalizer2 fcd;
	public final ComposeNormalizer2 fcc;
	private static CacheBase<String, Norm2AllModes, InputStream> cache = new 1();
	public static final NoopNormalizer2 NOOP_NORMALIZER2 = new NoopNormalizer2();

	private Norm2AllModes(Normalizer2Impl ni) {
		this.impl = ni;
		this.comp = new ComposeNormalizer2(ni, false);
		this.decomp = new DecomposeNormalizer2(ni);
		this.fcd = new FCDNormalizer2(ni);
		this.fcc = new ComposeNormalizer2(ni, true);
	}

	private static Norm2AllModes getInstanceFromSingleton(Norm2AllModesSingleton singleton) {
		if (Norm2AllModesSingleton.access$000(singleton) != null) {
			throw Norm2AllModesSingleton.access$000(singleton);
		} else {
			return Norm2AllModesSingleton.access$100(singleton);
		}
	}

	public static Norm2AllModes getNFCInstance() {
		return getInstanceFromSingleton(NFCSingleton.access$200());
	}

	public static Norm2AllModes getNFKCInstance() {
		return getInstanceFromSingleton(NFKCSingleton.access$300());
	}

	public static Norm2AllModes getNFKC_CFInstance() {
		return getInstanceFromSingleton(NFKC_CFSingleton.access$400());
	}

	public static Normalizer2WithImpl getN2WithImpl(int index) {
		switch (index) {
			case 0 :
				return getNFCInstance().decomp;
			case 1 :
				return getNFKCInstance().decomp;
			case 2 :
				return getNFCInstance().comp;
			case 3 :
				return getNFKCInstance().comp;
			default :
				return null;
		}
	}

	public static Norm2AllModes getInstance(InputStream data, String name) {
		if (data == null) {
			Norm2AllModesSingleton singleton;
			if (name.equals("nfc")) {
				singleton = NFCSingleton.access$200();
			} else if (name.equals("nfkc")) {
				singleton = NFKCSingleton.access$300();
			} else if (name.equals("nfkc_cf")) {
				singleton = NFKC_CFSingleton.access$400();
			} else {
				singleton = null;
			}

			if (singleton != null) {
				if (Norm2AllModesSingleton.access$000(singleton) != null) {
					throw Norm2AllModesSingleton.access$000(singleton);
				}

				return Norm2AllModesSingleton.access$100(singleton);
			}
		}

		return (Norm2AllModes) cache.getInstance(name, data);
	}

	public static Normalizer2 getFCDNormalizer2() {
		Norm2AllModes allModes = getNFCInstance();
		allModes.impl.getFCDTrie();
		return allModes.fcd;
	}
}