package com.ibm.bsf.util;

import com.ibm.bsf.BSFDeclaredBean;
import com.ibm.bsf.BSFEngine;
import com.ibm.bsf.BSFException;
import com.ibm.bsf.BSFManager;
import java.beans.PropertyChangeEvent;
import java.util.Vector;

public abstract class BSFEngineImpl implements BSFEngine {
	protected BSFManager mgr;
	protected String lang;
	protected Vector declaredBeans;
	protected String classPath;
	protected String tempDir;
	protected ClassLoader classLoader;

	public Object getSpecificDebuggingInterface() {
		return null;
	}

	public void disconnectedDebuggerNotify() {
	}

	public void placeBreakpointAtLine(int var1, String var2, int var3) throws BSFException {
		throw new BSFException(BSFException.REASON_UNSUPPORTED_FEATURE,
				"BSF:" + this.lang + "engine does not yet support debugging.");
	}

	public void placeBreakpointAtOffset(int var1, String var2, int var3) throws BSFException {
		throw new BSFException(BSFException.REASON_UNSUPPORTED_FEATURE,
				"BSF:" + this.lang + "engine does not yet support debugging.");
	}

	public void removeBreakpoint(String var1, int var2) throws BSFException {
		throw new BSFException(BSFException.REASON_UNSUPPORTED_FEATURE,
				"BSF:" + this.lang + "engine does not yet support debugging.");
	}

	public void setEntryExit(String var1, boolean var2) throws BSFException {
		throw new BSFException(BSFException.REASON_UNSUPPORTED_FEATURE,
				"BSF:" + this.lang + "engine does not yet support debugging.");
	}

	public Object apply(String var1, int var2, int var3, Object var4, Vector var5, Vector var6) throws BSFException {
		return this.eval(var1, var2, var3, var4);
	}

	public void compileApply(String var1, int var2, int var3, Object var4, Vector var5, Vector var6, CodeBuffer var7)
			throws BSFException {
		this.compileExpr(var1, var2, var3, var4, var7);
	}

	public void compileExpr(String var1, int var2, int var3, Object var4, CodeBuffer var5) throws BSFException {
		ObjInfo var6 = var5.getSymbol("bsf");
		if (var6 == null) {
			var6 = new ObjInfo(class$com$ibm$bsf$BSFManager == null
					? (class$com$ibm$bsf$BSFManager = class$("com.ibm.bsf.BSFManager"))
					: class$com$ibm$bsf$BSFManager, "bsf");
			var5.addFieldDeclaration("com.ibm.bsf.BSFManager bsf = new com.ibm.bsf.BSFManager();");
			var5.putSymbol("bsf", var6);
		}

		String var7 = var6.objName + ".eval(\"" + this.lang + "\", ";
		var7 = var7 + "request.getRequestURI(), " + var2 + ", " + var3;
		var7 = var7 + "," + StringUtils.lineSeparator;
		var7 = var7 + StringUtils.getSafeString(var4.toString()) + ")";
		ObjInfo var8 = var5.getFinalServiceMethodStatement();
		if (var8 != null && var8.isExecutable()) {
			var5.addServiceMethodStatement(var8.objName + ";");
		}

		var5.setFinalServiceMethodStatement(new ObjInfo(class$java$lang$Object == null
				? (class$java$lang$Object = class$("java.lang.Object"))
				: class$java$lang$Object, var7));
		var5.addServiceMethodException("com.ibm.bsf.BSFException");
	}

	public void compileScript(String var1, int var2, int var3, Object var4, CodeBuffer var5) throws BSFException {
		ObjInfo var6 = var5.getSymbol("bsf");
		if (var6 == null) {
			var6 = new ObjInfo(class$com$ibm$bsf$BSFManager == null
					? (class$com$ibm$bsf$BSFManager = class$("com.ibm.bsf.BSFManager"))
					: class$com$ibm$bsf$BSFManager, "bsf");
			var5.addFieldDeclaration("com.ibm.bsf.BSFManager bsf = new com.ibm.bsf.BSFManager();");
			var5.putSymbol("bsf", var6);
		}

		String var7 = var6.objName + ".exec(\"" + this.lang + "\", ";
		var7 = var7 + "request.getRequestURI(), " + var2 + ", " + var3;
		var7 = var7 + "," + StringUtils.lineSeparator;
		var7 = var7 + StringUtils.getSafeString(var4.toString()) + ")";
		ObjInfo var8 = var5.getFinalServiceMethodStatement();
		if (var8 != null && var8.isExecutable()) {
			var5.addServiceMethodStatement(var8.objName + ";");
		}

		var5.setFinalServiceMethodStatement(new ObjInfo(Void.TYPE, var7));
		var5.addServiceMethodException("com.ibm.bsf.BSFException");
	}

	public void declareBean(BSFDeclaredBean var1) throws BSFException {
		throw new BSFException(BSFException.REASON_UNSUPPORTED_FEATURE,
				"language " + this.lang + " does not support declareBean(...).");
	}

	public void exec(String var1, int var2, int var3, Object var4) throws BSFException {
		this.eval(var1, var2, var3, var4);
	}

	public void iexec(String var1, int var2, int var3, Object var4) throws BSFException {
		this.eval(var1, var2, var3, var4);
	}

	public void initialize(BSFManager var1, String var2, Vector var3) throws BSFException {
		this.mgr = var1;
		this.lang = var2;
		this.declaredBeans = var3;
		this.classPath = var1.getClassPath();
		this.tempDir = var1.getTempDir();
		this.classLoader = var1.getClassLoader();
	}

	public void propertyChange(PropertyChangeEvent var1) {
		String var2 = var1.getPropertyName();
		Object var3 = var1.getNewValue();
		if (var2.equals("classPath")) {
			this.classPath = (String) var3;
		} else if (var2.equals("tempDir")) {
			this.tempDir = (String) var3;
		} else if (var2.equals("classLoader")) {
			this.classLoader = (ClassLoader) var3;
		}

	}

	public void terminate() {
		this.mgr = null;
		this.declaredBeans = null;
		this.classLoader = null;
	}

	public void undeclareBean(BSFDeclaredBean var1) throws BSFException {
		throw new BSFException(BSFException.REASON_UNSUPPORTED_FEATURE,
				"language " + this.lang + " does not support undeclareBean(...).");
	}
}