package com.ibm.ws.wim.util;

public class SearchParameter {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public short dataType = -1;
	public Integer propId = new Integer(-1);
	public Object paramValue = null;

	public SearchParameter() {
	}

	public SearchParameter(short var1, Integer var2) {
		this.dataType = var1;
		this.propId = var2;
		this.paramValue = null;
	}

	public SearchParameter(short var1, Integer var2, Object var3) {
		this.dataType = var1;
		this.propId = var2;
		this.paramValue = var3;
	}
}