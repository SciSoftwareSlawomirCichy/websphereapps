package com.ibm.bsf.util;

public class Bean {
	public Class type;
	public Object value;

	public Bean(Class var1, Object var2) {
		this.type = var1;
		this.value = var2;
	}
}