package com.ibm.ws.ffdc;

import com.ibm.ffdc.Ffdc;
import com.ibm.ffdc.Manager;
import com.ibm.ws.ffdc.impl.DMAdapter;

public class FFDCFilter {
	public static void processException(Throwable th, String sourceId, String probeId) {
		Ffdc ffdc = Manager.Ffdc.getFfdc(th, (Object) null, sourceId, probeId);
		if (ffdc.isLoggable()) {
			ffdc.log(new Object[]{new DMAdapter(sourceId, (Object) null, th, (Object[]) null)});
		}

	}

	public static void processException(Throwable th, String sourceId, String probeId, Object callerThis) {
		Ffdc ffdc = Manager.Ffdc.getFfdc(th, callerThis, sourceId, probeId);
		if (ffdc.isLoggable()) {
			ffdc.log(new Object[]{new DMAdapter(sourceId, callerThis, th, (Object[]) null)});
		}

	}

	public static void processException(Throwable th, String sourceId, String probeId, Object[] objectArray) {
		Ffdc ffdc = Manager.Ffdc.getFfdc(th, (Object) null, sourceId, probeId);
		if (ffdc.isLoggable()) {
			ffdc.log(new Object[]{new DMAdapter(sourceId, (Object) null, th, objectArray)});
		}

	}

	public static void processException(Throwable th, String sourceId, String probeId, Object callerThis,
			Object[] objectArray) {
		Ffdc ffdc = Manager.Ffdc.getFfdc(th, callerThis, sourceId, probeId);
		if (ffdc.isLoggable()) {
			ffdc.log(new Object[]{new DMAdapter(sourceId, callerThis, th, objectArray)});
		}

	}
}