package com.ibm.bsf.util;

import com.ibm.bsf.BSFEngine;
import com.ibm.bsf.BSFException;
import com.ibm.bsf.BSFManager;
import com.ibm.bsf.util.event.EventProcessor;

public class BSFEventProcessor implements EventProcessor {
	BSFEngine engine;
	BSFManager manager;
	String filter;
	String source;
	int lineNo;
	int columnNo;
	Object script;

	BSFEventProcessor(BSFEngine var1, BSFManager var2, String var3, String var4, int var5, int var6, Object var7)
			throws BSFException {
		this.engine = var1;
		this.manager = var2;
		this.filter = var3;
		this.source = var4;
		this.lineNo = var5;
		this.columnNo = var6;
		this.script = var7;
	}

	public void processEvent(String var1, Object[] var2) {
		try {
			this.processExceptionableEvent(var1, var2);
		} catch (RuntimeException var4) {
			throw var4;
		} catch (Exception var5) {
			System.err.println("BSFError: non-exceptionable event delivery threw exception (that's not nice): " + var5);
			var5.printStackTrace();
		}

	}

	public void processExceptionableEvent(String var1, Object[] var2) throws Exception {
		if (this.filter == null || this.filter.equals(var1)) {
			this.engine.exec(this.source, this.lineNo, this.columnNo, this.script);
		}
	}
}