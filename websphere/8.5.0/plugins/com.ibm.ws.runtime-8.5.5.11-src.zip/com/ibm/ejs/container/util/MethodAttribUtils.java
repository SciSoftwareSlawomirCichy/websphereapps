package com.ibm.ejs.container.util;

import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.EJBConfigurationException;
import com.ibm.ejs.csi.ActivitySessionMethod;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.ActivitySessionAttribute;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.MethodInterface;
import com.ibm.websphere.csi.TransactionAttribute;
import com.ibm.ws.javaee.dd.ejb.AsyncMethod;
import com.ibm.ws.javaee.dd.ejb.ConcurrentMethod;
import com.ibm.ws.javaee.dd.ejb.ContainerTransaction;
import com.ibm.ws.javaee.dd.ejb.EnterpriseBean;
import com.ibm.ws.javaee.dd.ejb.ExcludeList;
import com.ibm.ws.javaee.dd.ejb.MethodPermission;
import com.ibm.ws.javaee.dd.ejb.NamedMethod;
import com.ibm.ws.javaee.dd.ejb.Session;
import com.ibm.ws.javaee.util.DDUtil;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.AccessTimeout;
import javax.ejb.Asynchronous;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.TransactionAttributeType;

public class MethodAttribUtils {
	private static final String CLASS_NAME = MethodAttribUtils.class.getName();
	private static TraceComponent tc;
	private static TraceComponent tcDebug;
	public static final String METHOD_ARGLIST_SEP = ":";
	public static final String[] TX_ATTR_STR;
	private static String[] ISOLATION_STR;
	private static TransactionAttribute[] txMOFMap;
	private static TransactionAttribute[] txAttrFromJEE15Map;
	private static final MethodInterface[] methodInterfaceTypeMap;

	public static final void getAnnotationCMTransactions(TransactionAttribute[] tranAttrs, Method[] beanMethods,
			BeanMetaData bmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAnnotationCMTransactions");
		}

		javax.ejb.TransactionAttribute methTranAttr = null;

		for (int i = 0; i < beanMethods.length; ++i) {
			if (tranAttrs[i] == null) {
				methTranAttr = null;
				if (!bmd.metadataComplete) {
					methTranAttr = (javax.ejb.TransactionAttribute) beanMethods[i]
							.getAnnotation(javax.ejb.TransactionAttribute.class);
					if (methTranAttr == null) {
						methTranAttr = (javax.ejb.TransactionAttribute) beanMethods[i].getDeclaringClass()
								.getAnnotation(javax.ejb.TransactionAttribute.class);
						if (isTraceOn && tc.isDebugEnabled() && methTranAttr != null) {
							Tr.debug(tc, beanMethods[i].getName() + " from class "
									+ beanMethods[i].getDeclaringClass().getName());
						}
					}

					if (methTranAttr != null) {
						int tranType = methTranAttr.value().ordinal();
						tranAttrs[i] = txAttrFromJEE15Map[tranType];
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, beanMethods[i].getName() + " = " + methTranAttr.value());
						}
					}
				}

				if (methTranAttr == null) {
					tranAttrs[i] = TransactionAttribute.TX_REQUIRED;
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, beanMethods[i].getName() + " = REQUIRED (defaulted)");
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getAnnotationsCMTransactions", Arrays.toString(tranAttrs));
		}

	}

	public static boolean getXMLAsynchronousMethods(boolean[] asynchMethodFlags, MethodInterface methodInterface,
			String[] methodNames, Class<?>[][] methodParamTypes, EnterpriseBean wccmEnterpriseBean)
			throws EJBConfigurationException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		boolean asynchMethodFound = false;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getXMLAsynchronousMethods",
					new Object[]{asynchMethodFlags, wccmEnterpriseBean, methodInterface});
		}

		if (wccmEnterpriseBean.getKindValue() == 0 && methodInterface != MethodInterface.SERVICE_ENDPOINT) {
			Session sb = (Session) wccmEnterpriseBean;
			List<AsyncMethod> asynchMethods = sb.getAsyncMethods();
			Iterator i$ = asynchMethods.iterator();

			while (true) {
				if (!i$.hasNext()) {
					if (isTraceOn && tc.isDebugEnabled()) {
						for (int i = 0; i < methodNames.length; ++i) {
							Tr.debug(tc, methodNames[i] + Arrays.toString(methodParamTypes[i]) + " == "
									+ (asynchMethodFlags[i] ? "Asynchronous" : "Synchronous"));
						}
					}
					break;
				}

				AsyncMethod am = (AsyncMethod) i$.next();
				String methodName = am.getMethodName();
				if (methodName == null || "".equals(methodName.trim())) {
					Tr.error(tc, "INVALID_ASYNC_METHOD_ELEMENT_MISSING_METHOD_NAME_CNTR0203E", sb.getName());
					throw new EJBConfigurationException("Async method declared without a required method-name");
				}

				List<String> parms = am.getMethodParamList();
				if ("*".equals(methodName) && parms != null) {
					Tr.error(tc, "INVALID_ASYNC_METHOD_ELEMENT_SPECIFIED_PARMS_WITH_WILDCARD_METHOD_CNTR0204E",
							sb.getName());
					throw new EJBConfigurationException(
							"Cannot specify parameters when specifying a wildcard method-name for async methods");
				}

				int i;
				if ("*".equals(methodName)) {
					for (i = 0; i < asynchMethodFlags.length; ++i) {
						asynchMethodFlags[i] = true;
					}

					asynchMethodFound = true;
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "getXMLAsynchronousMethods - all methods are marked async");
					}

					return asynchMethodFound;
				}

				for (i = 0; i < methodNames.length; ++i) {
					if (methodNames[i] != null && methodNames[i].equals(methodName)
							&& (parms == null || DDUtil.methodParamsMatch(parms, methodParamTypes[i]))) {
						asynchMethodFlags[i] = true;
						asynchMethodFound = true;
					}
				}
			}
		} else if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "Not a session bean");
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getXMLAsynchronousMethods");
		}

		return asynchMethodFound;
	}

	public static boolean getAsynchronousMethods(Method[] beanMethods, boolean[] asynchMethodFlags,
			MethodInterface methodInterface) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAsynchronousMethods");
		}

		Asynchronous asynchAnnotation = null;
		boolean asynchMethodFound = false;
		if (methodInterface != MethodInterface.SERVICE_ENDPOINT) {
			for (int i = 0; i < beanMethods.length; ++i) {
				if (beanMethods[i] != null && !asynchMethodFlags[i]) {
					asynchAnnotation = null;
					asynchAnnotation = (Asynchronous) beanMethods[i].getAnnotation(Asynchronous.class);
					if (asynchAnnotation == null) {
						asynchAnnotation = (Asynchronous) beanMethods[i].getDeclaringClass()
								.getAnnotation(Asynchronous.class);
						if (isTraceOn && tc.isDebugEnabled() && asynchAnnotation != null) {
							Tr.debug(tc,
									"The " + beanMethods[i].getName() + " method on the "
											+ beanMethods[i].getDeclaringClass().getName()
											+ " bean is configured asynchronous at the class level");
						}
					} else if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc,
								"The " + beanMethods[i].getName() + " method on the "
										+ beanMethods[i].getDeclaringClass().getName()
										+ " bean is configured asynchronous at the method level");
					}

					if (asynchAnnotation != null) {
						asynchMethodFlags[i] = true;
						asynchMethodFound = true;
					} else {
						asynchMethodFlags[i] = false;
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getAsynchonousMethods");
		}

		return asynchMethodFound;
	}

	public static final void getAnnotationsForSecurity(Method[] beanMethods, ArrayList<String>[] rolesAllowed,
			boolean[] denyAll, boolean[] permitAll) throws EJBConfigurationException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAnnotationsForSecurity");
		}

		for (int i = 0; i < beanMethods.length; ++i) {
			RolesAllowed classRolesAllowed = null;
			RolesAllowed methRolesAllowed = null;
			DenyAll classDenyAll = null;
			DenyAll methDenyAll = null;
			PermitAll classPermitAll = null;
			PermitAll methPermitAll = null;
			Method beanMethod = beanMethods[i];
			String conflict1;
			if (beanMethod != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Processing method: " + beanMethod.getName());
				}

				if (denyAll[i] || permitAll[i] || rolesAllowed[i] != null) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "DenyAll, PermitAll, or Roles already set in XML.");
					}
					continue;
				}

				methDenyAll = (DenyAll) beanMethod.getAnnotation(DenyAll.class);
				if (methDenyAll != null) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "DenyAll annotation set: " + methDenyAll.toString());
					}

					denyAll[i] = true;
				}

				methPermitAll = (PermitAll) beanMethod.getAnnotation(PermitAll.class);
				if (methPermitAll != null) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "PermitAll annotation set: " + methPermitAll.toString());
					}

					if (methDenyAll != null) {
						Tr.error(tc, "CONFLICTING_ANNOTATIONS_CONFIGURED_ON_METHOD_CNTR0150E",
								new Object[]{"@PermitAll", "@DenyAll", beanMethod.getName(),
										beanMethod.getDeclaringClass().getName()});
						throw new EJBConfigurationException(
								"@DenyAll and @PermitAll annotations are both set on class:  "
										+ beanMethod.getDeclaringClass().getName() + " method: "
										+ beanMethod.getName());
					}

					permitAll[i] = true;
				}

				methRolesAllowed = (RolesAllowed) beanMethod.getAnnotation(RolesAllowed.class);
				if (methRolesAllowed != null) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Method-level RolsAllowed annotation set. ");
					}

					if (methDenyAll != null) {
						Tr.error(tc, "CONFLICTING_ANNOTATIONS_CONFIGURED_ON_METHOD_CNTR0150E",
								new Object[]{"@RolesAllowed", "@DenyAll", beanMethod.getName(),
										beanMethod.getDeclaringClass().getName()});
						throw new EJBConfigurationException(
								"@RolesAllowed and @DenyAll annotations are both set on class:  "
										+ beanMethod.getDeclaringClass().getName() + " method: "
										+ beanMethod.getName());
					}

					if (methPermitAll != null) {
						Tr.error(tc, "CONFLICTING_ANNOTATIONS_CONFIGURED_ON_METHOD_CNTR0150E",
								new Object[]{"RolesAllowed", "@PermitAll", beanMethod.getName(),
										beanMethod.getDeclaringClass().getName()});
						throw new EJBConfigurationException(
								"@RolesAllowed and @PermitAll annotations are both set on class:  "
										+ beanMethod.getDeclaringClass().getName() + " method: "
										+ beanMethod.getName());
					}

					rolesAllowed[i] = new ArrayList();
					String[] arr$ = methRolesAllowed.value();
					int len$ = arr$.length;

					for (int i$ = 0; i$ < len$; ++i$) {
						String role = arr$[i$];
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Adding role: " + role);
						}

						boolean roleAdded = rolesAllowed[i].add(role);
						if (!roleAdded) {
							Tr.error(tc, "DUPLICATE_ROLES_SPECIFIED_IN_METHOD_ANNOTATION_CNTR0151E",
									new Object[]{role, beanMethod.getName(), beanMethod.getDeclaringClass().getName()});
							throw new EJBConfigurationException("Role: " + role
									+ " is defined multiple times on the @RolesAllowed annotation for class: "
									+ beanMethod.getDeclaringClass().getName() + " method: " + beanMethod.getName());
						}
					}
				}

				if (methRolesAllowed == null && methDenyAll == null && methPermitAll == null) {
					classRolesAllowed = (RolesAllowed) beanMethod.getDeclaringClass().getAnnotation(RolesAllowed.class);
					classPermitAll = (PermitAll) beanMethod.getDeclaringClass().getAnnotation(PermitAll.class);
					classDenyAll = (DenyAll) beanMethod.getDeclaringClass().getAnnotation(DenyAll.class);
					conflict1 = null;
					String conflict2 = null;
					if (classRolesAllowed != null) {
						if (classPermitAll != null) {
							conflict1 = "@RolesAllowed";
							conflict2 = "@PermitAll";
						} else if (classDenyAll != null) {
							conflict1 = "@RolesAllowed";
							conflict2 = "@DenyAll";
						}
					} else if (classPermitAll != null && classDenyAll != null) {
						conflict1 = "@PermitAll";
						conflict2 = "@DenyAll";
					}

					if (conflict1 != null) {
						Tr.error(tc, "CONFLICTING_ANNOTATIONS_CONFIGURED_ON_CLASS_CNTR0152E",
								new Object[]{conflict1, conflict2, beanMethod.getDeclaringClass().getName()});
						throw new EJBConfigurationException(
								conflict1 + " and " + conflict2 + " must not both be set on class level annotation"
										+ " of class: " + beanMethod.getDeclaringClass().getName());
					}

					if (classRolesAllowed != null) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Class RolesAllowed annotation set: ");
						}

						rolesAllowed[i] = new ArrayList();
						String[] arr$ = classRolesAllowed.value();
						int len$ = arr$.length;

						for (int i$ = 0; i$ < len$; ++i$) {
							String role = arr$[i$];
							boolean roleAdded = rolesAllowed[i].add(role);
							if (!roleAdded) {
								Tr.error(tc, "DUPLICATE_ROLES_SPECIFIED_IN_CLASS_ANNOTATION_CNTR0153E",
										new Object[]{role, beanMethod.getDeclaringClass().getName()});
								throw new EJBConfigurationException("Role: " + role
										+ " is defined multiple times on the @RolesAllowed class level annotation of class: "
										+ beanMethod.getDeclaringClass().getName());
							}
						}
					}

					if (classPermitAll != null) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Class PermitAll annotation set: ");
						}

						permitAll[i] = true;
					} else if (classDenyAll != null) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Class DenyAll annotation set");
						}

						denyAll[i] = true;
					}
				}
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				conflict1 = "Unknown";
				if (beanMethods[i] != null) {
					conflict1 = beanMethods[i].getName();
				}

				Tr.debug(tc, conflict1 + " denyAll:  " + denyAll[i]);
				Tr.debug(tc, conflict1 + " permitAll:  " + permitAll[i]);
				if (rolesAllowed[i] == null) {
					Tr.debug(tc, conflict1 + " roles:  null");
				} else {
					Tr.debug(tc, conflict1 + " roles:  " + Arrays.toString(rolesAllowed[i].toArray()));
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getAnnotationsForSecurity");
		}

	}

	public static final void getXMLCMTransactions(TransactionAttribute[] tranAttrs, int type, String[] methodNames,
			Class<?>[][] methodParamTypes, List<ContainerTransaction> tranAttrList, BeanMetaData bmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getXMLCMTransactions", Arrays.toString(tranAttrs));
		}

		if (tranAttrList != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "*** TX list has " + tranAttrList.size() + " TX attribute(s) to process ***");
			}

			int[] highestStyleOnMethod = new int[methodNames.length];

			for (int i = 0; i < tranAttrList.size(); ++i) {
				ContainerTransaction methodTransaction = (ContainerTransaction) tranAttrList.get(i);
				int tranType = methodTransaction.getTransAttributeTypeValue();
				List<com.ibm.ws.javaee.dd.ejb.Method> methodElements = methodTransaction.getMethodElements();

				for (int j = 0; j < methodElements.size(); ++j) {
					com.ibm.ws.javaee.dd.ejb.Method me = (com.ibm.ws.javaee.dd.ejb.Method) methodElements.get(j);
					String ejbNameFromMethodElement = me.getEnterpriseBeanName();
					int meType = me.getInterfaceTypeValue();
					if (ejbNameFromMethodElement == null) {
						Tr.warning(tc, "INVALID_CONTAINER_TRANSACTION_XML_CNTR0121W",
								new Object[]{bmd.getJ2EEName().getModule(), txMOFMap[tranType]});
					}

					if (isTraceOn && tc.isDebugEnabled() && j == 0) {
						Tr.debug(tc, "#" + i + " Method transaction type: " + txMOFMap[tranType]);
					}

					if (ejbNameFromMethodElement != null && ejbNameFromMethodElement.equals(bmd.enterpriseBeanName)) {
						String meName = me.getMethodName().trim();
						int k;
						if (meName.equals("*")) {
							if (meType == 0) {
								for (k = 0; k < methodNames.length; ++k) {
									if (highestStyleOnMethod[k] <= 1) {
										if (isTraceOn && tc.isDebugEnabled()) {
											trace(me, "Style 1 - replacing TX attribute " + tranAttrs[k] + " with "
													+ txMOFMap[tranType]);
										}

										tranAttrs[k] = txMOFMap[tranType];
										highestStyleOnMethod[k] = 1;
									}
								}
							} else if (meType == type) {
								for (k = 0; k < methodNames.length; ++k) {
									if (highestStyleOnMethod[k] <= 2) {
										if (isTraceOn && tc.isDebugEnabled()) {
											trace(me, "Style 2 - replacing " + tranAttrs[k] + " with "
													+ txMOFMap[tranType]);
										}

										tranAttrs[k] = txMOFMap[tranType];
										highestStyleOnMethod[k] = 2;
									}
								}
							}
						} else if (meType == 0 || meType == type) {
							for (k = 0; k < methodNames.length; ++k) {
								if (meName.equals(methodNames[k])) {
									List<String> meParms = me.getMethodParamList();
									if (meParms == null) {
										if (highestStyleOnMethod[k] <= 3) {
											if (isTraceOn && tc.isDebugEnabled()) {
												trace(me, "Style 3 - replacing " + tranAttrs[k] + " with "
														+ txMOFMap[tranType]);
											}

											tranAttrs[k] = txMOFMap[tranType];
											highestStyleOnMethod[k] = 3;
										}
									} else if (DDUtil.methodParamsMatch(meParms, methodParamTypes[k])) {
										if (isTraceOn && tc.isDebugEnabled()) {
											trace(me, "Style 4 - replacing " + tranAttrs[k] + " with "
													+ txMOFMap[tranType]);
										}

										tranAttrs[k] = txMOFMap[tranType];
										highestStyleOnMethod[k] = 4;
									}
								}
							}
						}
					}
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getXMLCMTransactions", Arrays.toString(tranAttrs));
		}

	}

	private static void trace(com.ibm.ws.javaee.dd.ejb.Method m, String message) {
		Tr.debug(tc, message,
				new Object[]{"ejb-name:      " + m.getEnterpriseBeanName(),
						"method-intf:   " + methodInterfaceTypeMap[m.getInterfaceTypeValue()],
						"method-name:   " + m.getMethodName(), "method-params: " + m.getMethodParamList()});
	}

	private static void trace(Method m, String beanName, String message) {
		Tr.debug(tc, message, new Object[]{"Enterprise Bean Name: " + beanName, "Method name: " + m.toString()});
	}

	public static final void getXMLMethodsDenied(boolean[] denyAll, int type, String[] methodNames,
			Class<?>[][] methodParamTypes, ExcludeList excludeList, BeanMetaData bmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getXMLMethodsDenied", Arrays.toString(denyAll));
		}

		if (excludeList != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"*** Exclude List has " + excludeList.getMethodElements().size() + " entries to process ***");
			}

			int[] highestStyleOnMethod = new int[methodNames.length];
			List<com.ibm.ws.javaee.dd.ejb.Method> methodElements = excludeList.getMethodElements();

			for (int j = 0; j < methodElements.size(); ++j) {
				com.ibm.ws.javaee.dd.ejb.Method me = (com.ibm.ws.javaee.dd.ejb.Method) methodElements.get(j);
				String ejbNameFromMethodElement = me.getEnterpriseBeanName();
				int meType = me.getInterfaceTypeValue();
				if (ejbNameFromMethodElement == null) {
					Tr.warning(tc, "INVALID_EXCLUDE_LIST_XML_CNTR0124W",
							new Object[]{bmd.getJ2EEName().getModule(), bmd.enterpriseBeanName});
				}

				if (ejbNameFromMethodElement != null && ejbNameFromMethodElement.equals(bmd.enterpriseBeanName)) {
					String meName = me.getMethodName().trim();
					int k;
					if (meName.equals("*")) {
						if (meType == 0) {
							for (k = 0; k < methodNames.length; ++k) {
								if (highestStyleOnMethod[k] <= 1) {
									if (isTraceOn && tc.isDebugEnabled()) {
										trace(me, "Style 1 - assigning denyAll true");
									}

									denyAll[k] = true;
									highestStyleOnMethod[k] = 1;
								}
							}
						} else if (meType == type) {
							for (k = 0; k < methodNames.length; ++k) {
								if (highestStyleOnMethod[k] <= 2) {
									if (isTraceOn && tc.isDebugEnabled()) {
										trace(me, "Style 2 - assigning denyAll true");
									}

									denyAll[k] = true;
									highestStyleOnMethod[k] = 2;
								}
							}
						}
					} else if (meType == 0 || meType == type) {
						for (k = 0; k < methodNames.length; ++k) {
							if (meName.equals(methodNames[k])) {
								List<String> meParms = me.getMethodParamList();
								if (meParms == null) {
									if (highestStyleOnMethod[k] <= 3) {
										if (isTraceOn && tc.isDebugEnabled()) {
											trace(me, "Style 3 - assigning denyAll true");
										}

										denyAll[k] = true;
										highestStyleOnMethod[k] = 3;
									}
								} else if (DDUtil.methodParamsMatch(meParms, methodParamTypes[k])) {
									if (isTraceOn && tc.isDebugEnabled()) {
										trace(me, "Style 4 - assigning denyAll true");
									}

									denyAll[k] = true;
									highestStyleOnMethod[k] = 4;
								}
							}
						}
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getXMLMethodsDenied", Arrays.toString(denyAll));
		}

	}

	public static final void getXMLPermissions(ArrayList[] securityRoles, boolean[] permitAll, boolean[] denyAll,
			int type, String[] methodNames, Class<?>[][] methodParamTypes, List permissionsList, BeanMetaData bmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getXMLPermissions", Arrays.toString(securityRoles));
		}

		if (permissionsList != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "*** Method Permissions list has " + permissionsList.size()
						+ " Security Permission(s) to process ***");
			}

			for (int i = 0; i < permissionsList.size(); ++i) {
				MethodPermission methodPermission = (MethodPermission) permissionsList.get(i);
				boolean isUnchecked = methodPermission.isUnchecked();
				List<String> roleNames = methodPermission.getRoleNames();
				List<com.ibm.ws.javaee.dd.ejb.Method> methodElements = methodPermission.getMethodElements();

				for (int j = 0; j < methodElements.size(); ++j) {
					com.ibm.ws.javaee.dd.ejb.Method me = (com.ibm.ws.javaee.dd.ejb.Method) methodElements.get(j);
					String ejbNameFromMethodElement = me.getEnterpriseBeanName();
					int meType = me.getInterfaceTypeValue();
					if (ejbNameFromMethodElement == null) {
						Tr.warning(tc, "INVALID_METHOD_PERMISSION_XML_CNTR0123W",
								new Object[]{bmd.getJ2EEName().getModule(), bmd.enterpriseBeanName});
					}

					if (isTraceOn && tc.isDebugEnabled()) {
						if (j == 0) {
							Tr.debug(tc, "#" + i + " Method Permission  has " + methodElements.size()
									+ " Method Element(s).");
						}

						Tr.debug(tc, "Process element " + me.getMethodName() + " Method Element type = " + meType);
					}

					if (ejbNameFromMethodElement != null && ejbNameFromMethodElement.equals(bmd.enterpriseBeanName)) {
						String meName = me.getMethodName().trim();
						int k;
						if (meName.equals("*")) {
							if (meType == 0) {
								for (k = 0; k < methodNames.length; ++k) {
									if (isUnchecked) {
										if (isTraceOn && tc.isDebugEnabled()) {
											trace(me, "Style 1 - Permit all roles.");
										}

										permitAll[k] = true;
									} else {
										if (isTraceOn && tc.isDebugEnabled()) {
											trace(me, "Style 1 - assigning roles " + roleNames);
										}

										if (securityRoles[k] == null) {
											securityRoles[k] = new ArrayList();
										}

										securityRoles[k].addAll(roleNames);
									}
								}
							} else if (meType == type) {
								for (k = 0; k < methodNames.length; ++k) {
									if (isUnchecked) {
										if (isTraceOn && tc.isDebugEnabled()) {
											trace(me, "Style 2 - Permit all roles.");
										}

										permitAll[k] = true;
									} else {
										if (isTraceOn && tc.isDebugEnabled()) {
											trace(me, "Style 2 - assigning roles " + roleNames);
										}

										if (securityRoles[k] == null) {
											securityRoles[k] = new ArrayList();
										}

										securityRoles[k].addAll(roleNames);
									}
								}
							}
						} else if (meType == 0 || meType == type) {
							for (k = 0; k < methodNames.length; ++k) {
								if (meName.equals(methodNames[k])) {
									List<String> meParms = me.getMethodParamList();
									if (meParms == null) {
										if (isUnchecked) {
											if (isTraceOn && tc.isDebugEnabled()) {
												trace(me, "Style 3 - Permit all roles.");
											}

											permitAll[k] = true;
										} else {
											if (isTraceOn && tc.isDebugEnabled()) {
												trace(me, "Style 3 - assigning roles " + roleNames);
											}

											if (securityRoles[k] == null) {
												securityRoles[k] = new ArrayList();
											}

											securityRoles[k].addAll(roleNames);
										}
									} else if (DDUtil.methodParamsMatch(meParms, methodParamTypes[k])) {
										if (isUnchecked) {
											if (isTraceOn && tc.isDebugEnabled()) {
												trace(me, "Style 4 - Permit all roles.");
											}

											permitAll[k] = true;
										} else {
											if (isTraceOn && tc.isDebugEnabled()) {
												trace(me, "Style 4 - assigning roles " + roleNames);
											}

											if (securityRoles[k] == null) {
												securityRoles[k] = new ArrayList();
											}

											securityRoles[k].addAll(roleNames);
										}
									}
								}
							}
						}
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getXMLPermissions " + Arrays.toString(securityRoles) + " PermitAll = "
					+ Arrays.toString(permitAll));
		}

	}

	public static final void getActivitySessions(ActivitySessionAttribute[] asAttrs, int type, String[] methodNames,
			Class<?>[][] methodParamTypes, List<ActivitySessionMethod> asAttrList, String ejbName,
			boolean usesBeanManagedAS) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getActivitySessions", asAttrs);
		}

		if (!usesBeanManagedAS) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Bean is CMAS");
			}

			if (asAttrList != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "asAttrList non-null");
				}

				int[] highestStyleOnMethod = new int[methodNames.length];

				for (int i = 0; i < asAttrList.size(); ++i) {
					ActivitySessionMethod asMethod = (ActivitySessionMethod) asAttrList.get(i);
					ActivitySessionAttribute asAttr = asMethod.getActivitySessionAttribute();
					List<com.ibm.ws.javaee.dd.ejb.Method> methodElements = asMethod.getMethodElements();

					for (int j = 0; j < methodElements.size(); ++j) {
						com.ibm.ws.javaee.dd.ejb.Method me = (com.ibm.ws.javaee.dd.ejb.Method) methodElements.get(j);
						if (isTraceOn && tc.isDebugEnabled()) {
							trace(me,
									me.getInterfaceTypeValue() == 0
											? "Interface type unspecified"
											: "Interface type: " + me.getInterfaceTypeValue());
						}

						if (me.getEnterpriseBeanName().equals(ejbName)) {
							String meName = me.getMethodName().trim();
							int meType = me.getInterfaceTypeValue();
							int k;
							if (meName.equals("*")) {
								if (meType == 0) {
									if (isTraceOn && tc.isDebugEnabled()) {
										Tr.debug(tc, "Style type 1 - all bean methods:", asAttr);
									}

									for (k = 0; k < methodNames.length; ++k) {
										if (highestStyleOnMethod[k] <= 1) {
											asAttrs[k] = asAttr;
											highestStyleOnMethod[k] = 1;
										}
									}
								} else if (meType == type) {
									if (isTraceOn && tc.isDebugEnabled()) {
										Tr.debug(tc, "Style type 2 - home/remote methods only:", asAttr);
									}

									for (k = 0; k < methodNames.length; ++k) {
										if (highestStyleOnMethod[k] <= 2) {
											asAttrs[k] = asAttr;
											highestStyleOnMethod[k] = 2;
										}
									}
								}
							} else if (meType == 0 || meType == type) {
								for (k = 0; k < methodNames.length; ++k) {
									if (meName.equals(methodNames[k])) {
										List<String> meParms = me.getMethodParamList();
										if (meParms == null) {
											if (isTraceOn && tc.isDebugEnabled()) {
												Tr.debug(tc, "Style type 3 - method name only:", asAttr);
											}

											if (highestStyleOnMethod[k] <= 3) {
												asAttrs[k] = asAttr;
												highestStyleOnMethod[k] = 3;
											}
										} else if (DDUtil.methodParamsMatch(meParms, methodParamTypes[k])) {
											if (isTraceOn && tc.isDebugEnabled()) {
												Tr.debug(tc, "Style type 4 - method name and signature:", asAttr);
											}

											asAttrs[k] = asAttr;
											highestStyleOnMethod[k] = 4;
										}
									}
								}
							}
						}
					}
				}
			}
		} else if (usesBeanManagedAS) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Bean is BMAS -- all methods will be set to AS_BEAN_MANAGED");
			}

			for (int i = 0; i < asAttrs.length; ++i) {
				asAttrs[i] = ActivitySessionAttribute.AS_BEAN_MANAGED;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getActivitySessions");
		}

	}

	public static final void checkTxAttrs(TransactionAttribute[] txAttrs, String[] methodNames,
			String[] methodSignatures, String[] checkedNames, String[] checkedSignatures,
			TransactionAttribute prescribedAttr) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "checkTxAttrs");
		}

		for (int i = 0; i < methodNames.length; ++i) {
			for (int j = 0; j < checkedNames.length; ++j) {
				if ((methodNames[i].equals(checkedNames[j]) && methodSignatures[i].equals(checkedSignatures[j]))
						| checkedNames[j].equals("*")) {
					txAttrs[i] = prescribedAttr;
					break;
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "checkTxAttrs");
		}

	}

	public static final void chkBMTFromXML(List<ContainerTransaction> tranAttrList, EnterpriseBean enterpriseBean,
			J2EEName j2eeName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "chkBMTFromXML");
		}

		if (tranAttrList != null && enterpriseBean != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "tranAttrList non-null");
			}

			for (int i = 0; i < tranAttrList.size(); ++i) {
				ContainerTransaction methodTransaction = (ContainerTransaction) tranAttrList.get(i);
				List<com.ibm.ws.javaee.dd.ejb.Method> methodElements = methodTransaction.getMethodElements();

				for (int j = 0; j < methodElements.size(); ++j) {
					com.ibm.ws.javaee.dd.ejb.Method me = (com.ibm.ws.javaee.dd.ejb.Method) methodElements.get(j);
					if (isTraceOn && tc.isDebugEnabled()) {
						trace(me,
								me.getInterfaceTypeValue() == 0
										? "Interface type unspecified"
										: "Interface type: " + me.getInterfaceTypeValue());
					}

					if (enterpriseBean.getName().equals(me.getEnterpriseBeanName())) {
						Tr.warning(tc, "BMT_DEFINES_CMT_ATTRIBUTES_CNTR0067W", new Object[]{j2eeName});
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "chkBMTFromXML");
		}

	}

	public static final void chkBMTFromAnnotations(Method[] beanMethods, J2EEName j2eeName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "chkBMTFromAnnotations");
		}

		javax.ejb.TransactionAttribute methTranAttr = null;

		for (int i = 0; i < beanMethods.length; ++i) {
			if (beanMethods[i] != null) {
				methTranAttr = (javax.ejb.TransactionAttribute) beanMethods[i]
						.getAnnotation(javax.ejb.TransactionAttribute.class);
				if (methTranAttr == null) {
					methTranAttr = (javax.ejb.TransactionAttribute) beanMethods[i].getDeclaringClass()
							.getAnnotation(javax.ejb.TransactionAttribute.class);
				}

				if (methTranAttr != null) {
					Tr.warning(tc, "BMT_DEFINES_CMT_ATTRIBUTES_CNTR0067W", new Object[]{j2eeName});
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "chkBMTFromAnnotations");
		}

	}

	public static final void chkBMASFromXML(List<ActivitySessionMethod> asAttrList, EnterpriseBean enterpriseBean,
			J2EEName j2eeName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "chkBMAS");
		}

		if (enterpriseBean != null && asAttrList != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "asAttrList non-null");
			}

			for (int i = 0; i < asAttrList.size(); ++i) {
				ActivitySessionMethod asMethod = (ActivitySessionMethod) asAttrList.get(i);
				List<com.ibm.ws.javaee.dd.ejb.Method> methodElements = asMethod.getMethodElements();

				for (int j = 0; j < methodElements.size(); ++j) {
					com.ibm.ws.javaee.dd.ejb.Method me = (com.ibm.ws.javaee.dd.ejb.Method) methodElements.get(j);
					if (isTraceOn && tc.isDebugEnabled()) {
						trace(me,
								me.getInterfaceTypeValue() == 0
										? "Interface type unspecified"
										: "Interface type: " + me.getInterfaceTypeValue());
					}

					if (enterpriseBean.getName().equals(me.getEnterpriseBeanName())) {
						Tr.warning(tc, "BMAS_DEFINES_CMAS_ATTRIBUTES_CNTR0068W", new Object[]{j2eeName});
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "chkBMAS");
		}

	}

	public static final String normalizeSignature(String deplDescriptorSignature) {
		StringBuffer theSignature = new StringBuffer(deplDescriptorSignature);
		int scanIndex = 0;

		while (scanIndex < theSignature.length()) {
			if (theSignature.charAt(scanIndex) == ' ') {
				char next = theSignature.charAt(scanIndex + 1);
				if (next == ' ' | next == '[' | next == ']') {
					theSignature.deleteCharAt(scanIndex);
				} else {
					++scanIndex;
				}
			} else {
				++scanIndex;
			}
		}

		return theSignature.toString();
	}

	public static final String methodSignature(Method method) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "methodSignature", method.getName());
		}

		StringBuffer sb = new StringBuffer();
		sb.append(method.getName());
		sb.append(":");
		Class<?>[] methodParams = method.getParameterTypes();

		for (int j = 0; j < methodParams.length; ++j) {
			if (j != 0) {
				sb.append(",");
			}

			if (methodParams[j].isArray()) {
				sb.append(convertArraySignature(methodParams[j].getName()));
			} else {
				sb.append(methodParams[j].getName());
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "methodSignature", sb.toString());
		}

		return sb.toString();
	}

	public static final String convertArraySignature(String theJavaSignature) {
		StringBuffer sb = new StringBuffer();

		int dimensionCount;
		for (dimensionCount = 0; theJavaSignature.charAt(dimensionCount) == '['; ++dimensionCount) {
			;
		}

		switch (theJavaSignature.charAt(dimensionCount)) {
			case 'B' :
				sb.append("byte[]");
				break;
			case 'C' :
				sb.append("char[]");
				break;
			case 'D' :
				sb.append("double[]");
			case 'E' :
			case 'G' :
			case 'H' :
			case 'K' :
			case 'M' :
			case 'N' :
			case 'O' :
			case 'P' :
			case 'Q' :
			case 'R' :
			case 'T' :
			case 'U' :
			case 'V' :
			case 'W' :
			case 'X' :
			case 'Y' :
			default :
				break;
			case 'F' :
				sb.append("float[]");
				break;
			case 'I' :
				sb.append("int[]");
				break;
			case 'J' :
				sb.append("long[]");
				break;
			case 'L' :
				sb.append(theJavaSignature.substring(dimensionCount + 1, theJavaSignature.length() - 1));
				sb.append("[]");
				break;
			case 'S' :
				sb.append("short[]");
				break;
			case 'Z' :
				sb.append("boolean[]");
		}

		while (true) {
			--dimensionCount;
			if (dimensionCount <= 0) {
				return sb.toString();
			}

			sb.append("[]");
		}
	}

	public static final String methodSignatureOnly(Method method) {
		StringBuffer sb = new StringBuffer();
		Class<?>[] methodParams = method.getParameterTypes();

		for (int j = 0; j < methodParams.length; ++j) {
			if (j != 0) {
				sb.append(" ");
			}

			if (methodParams[j].isArray()) {
				sb.append(convertArraySignature(methodParams[j].getName()));
			} else {
				sb.append(methodParams[j].getName());
			}
		}

		return sb.toString();
	}

	public static final String mapTypeToJDIEncoding(Class<?> type) {
		String typeName = type.getName();
		String returnValue;
		if (type.isArray()) {
			returnValue = typeName.replace('.', '/');
		} else if (typeName.indexOf(46) > 0) {
			returnValue = "L" + typeName.replace('.', '/') + ";";
		} else if (typeName.equals("void")) {
			returnValue = "V";
		} else if (typeName.equals("boolean")) {
			returnValue = "Z";
		} else if (typeName.equals("int")) {
			returnValue = "I";
		} else if (typeName.equals("long")) {
			returnValue = "J";
		} else if (typeName.equals("double")) {
			returnValue = "D";
		} else if (typeName.equals("float")) {
			returnValue = "F";
		} else if (typeName.equals("char")) {
			returnValue = "C";
		} else if (typeName.equals("byte")) {
			returnValue = "B";
		} else if (typeName.equals("short")) {
			returnValue = "S";
		} else {
			returnValue = "L" + typeName + ";";
		}

		return returnValue;
	}

	public static final String jdiMethodSignature(Method method) {
		StringBuffer sb = new StringBuffer();
		Class<?>[] methodParams = method.getParameterTypes();
		sb.append("(");

		for (int j = 0; j < methodParams.length; ++j) {
			sb.append(mapTypeToJDIEncoding(methodParams[j]));
		}

		sb.append(")");
		sb.append(mapTypeToJDIEncoding(method.getReturnType()));
		return sb.toString();
	}

	public static final boolean methodsEqual(Method remoteMethod, Method beanMethod) {
		if (remoteMethod != null && beanMethod != null) {
			if (!remoteMethod.getName().equals(beanMethod.getName())) {
				return false;
			} else {
				Class<?>[] remoteMethodParamTypes = remoteMethod.getParameterTypes();
				Class<?>[] beanMethodParamTypes = beanMethod.getParameterTypes();
				if (remoteMethodParamTypes.length != beanMethodParamTypes.length) {
					return false;
				} else {
					for (int i = 0; i < remoteMethodParamTypes.length; ++i) {
						if (!remoteMethodParamTypes[i].equals(beanMethodParamTypes[i])) {
							return false;
						}
					}

					return true;
				}
			}
		} else {
			return false;
		}
	}

	public static final boolean homeMethodEquals(Method homeMethod, Properties beanMethodProps) {
		if (homeMethod != null && beanMethodProps != null) {
			String homeMethodName = homeMethod.getName();
			String beanMethodName = (String) beanMethodProps.get("Name");
			if (!homeMethodName.equals(beanMethodName)) {
				return false;
			} else {
				Class<?>[] homeMethodParamTypes = homeMethod.getParameterTypes();
				String[] beanMethodParamTypes = (String[]) ((String[]) beanMethodProps.get("ArgumentTypes"));
				if (homeMethodParamTypes.length != beanMethodParamTypes.length) {
					return false;
				} else {
					for (int i = 0; i < homeMethodParamTypes.length; ++i) {
						if (!homeMethodParamTypes[i].getName().equals(beanMethodParamTypes[i])) {
							return false;
						}
					}

					return true;
				}
			}
		} else {
			return false;
		}
	}

	public static final String getIsolationLevelString(int isolationLevel) {
		return isolationLevel >= 0 && isolationLevel < ISOLATION_STR.length
				? ISOLATION_STR[isolationLevel]
				: "-- ILLEGAL ISOLATION LEVEL --";
	}

	private static final void populateIsoStringMap() {
		ISOLATION_STR = new String[9];

		for (int i = 0; i < ISOLATION_STR.length; ++i) {
			ISOLATION_STR[i] = "-- ILLEGAL ISOLATION LEVEL --";
		}

		ISOLATION_STR[1] = "TRANSACTION_READ_UNCOMMITTED";
		ISOLATION_STR[2] = "TRANSACTION_READ_COMMITTED";
		ISOLATION_STR[4] = "TRANSACTION_REPEATABLE_READ";
		ISOLATION_STR[8] = "TRANSACTION_SERIALIZABLE";
		ISOLATION_STR[0] = "TRANSACTION_NONE";
	}

	private static final void populateTxMofMap() {
		txMOFMap = new TransactionAttribute[7];
		txMOFMap[0] = TransactionAttribute.TX_NOT_SUPPORTED;
		txMOFMap[1] = TransactionAttribute.TX_SUPPORTS;
		txMOFMap[2] = TransactionAttribute.TX_REQUIRED;
		txMOFMap[3] = TransactionAttribute.TX_REQUIRES_NEW;
		txMOFMap[4] = TransactionAttribute.TX_MANDATORY;
		txMOFMap[5] = TransactionAttribute.TX_NEVER;
	}

	private static final void populateTxAttrFromJEE15Map() {
		txAttrFromJEE15Map = new TransactionAttribute[6];
		txAttrFromJEE15Map[TransactionAttributeType.NOT_SUPPORTED.ordinal()] = TransactionAttribute.TX_NOT_SUPPORTED;
		txAttrFromJEE15Map[TransactionAttributeType.SUPPORTS.ordinal()] = TransactionAttribute.TX_SUPPORTS;
		txAttrFromJEE15Map[TransactionAttributeType.REQUIRED.ordinal()] = TransactionAttribute.TX_REQUIRED;
		txAttrFromJEE15Map[TransactionAttributeType.REQUIRES_NEW.ordinal()] = TransactionAttribute.TX_REQUIRES_NEW;
		txAttrFromJEE15Map[TransactionAttributeType.MANDATORY.ordinal()] = TransactionAttribute.TX_MANDATORY;
		txAttrFromJEE15Map[TransactionAttributeType.NEVER.ordinal()] = TransactionAttribute.TX_NEVER;
	}

	public static void getAnnotationCMCLockAccessTimeout(long[] timeouts, Method[] ejbMethods, long defaultTimeout,
			boolean metadataComplete) throws EJBConfigurationException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAnnotationCMCLockAccessTimeout:  methods = " + Arrays.toString(ejbMethods));
		}

		for (int i = 0; i < ejbMethods.length; ++i) {
			Method beanMethod = ejbMethods[i];
			if (timeouts[i] == -2L) {
				if (!metadataComplete && beanMethod != null) {
					AccessTimeout annotation = (AccessTimeout) beanMethod.getAnnotation(AccessTimeout.class);
					if (annotation == null) {
						Class<?> c = beanMethod.getDeclaringClass();
						annotation = (AccessTimeout) c.getAnnotation(AccessTimeout.class);
						if (isTraceOn && tc.isDebugEnabled() && annotation != null) {
							Tr.debug(tc, beanMethod.getName() + " from class " + c.getName());
						}
					}

					if (annotation != null) {
						long value = annotation.value();
						TimeUnit unit = annotation.unit();
						if (value < -1L || value == Long.MAX_VALUE) {
							Tr.error(tc, "SINGLETON_INVALID_ACCESS_TIMEOUT_CNTR0192E", new Object[]{value,
									beanMethod.getName(), beanMethod.getDeclaringClass().getName()});
							throw new EJBConfigurationException("CNTR0192E: @AccessTimeout annotation value " + value
									+ " is not valid for the enterprise bean " + beanMethod.getName()
									+ " method of the " + beanMethod.getDeclaringClass().getName()
									+ " class. The value must be -1 or greater and less than"
									+ " java.lang.Long.MAX_VALUE (9223372036854775807).");
						}

						if (value > 0L) {
							if (unit == TimeUnit.MILLISECONDS) {
								timeouts[i] = value;
							} else {
								timeouts[i] = TimeUnit.MILLISECONDS.convert(value, unit);
								if (timeouts[i] == Long.MAX_VALUE || timeouts[i] == Long.MIN_VALUE) {
									Tr.error(tc, "SINGLETON_ACCESS_TIMEOUT_OVERFLOW_CNTR0196E",
											new Object[]{value, unit});
									if (isTraceOn && tc.isEntryEnabled()) {
										Tr.exit(tc, "convertToMilliSeconds: " + value + unit + " overflow");
									}

									throw new EJBConfigurationException("Conversion of access timeout value of " + value
											+ " " + unit + " to milliseconds resulted in overflow.");
								}
							}
						} else {
							timeouts[i] = value;
						}
					} else {
						timeouts[i] = defaultTimeout;
					}
				} else {
					timeouts[i] = defaultTimeout;
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getAnnotationCMCLockAccessTimeout", Arrays.toString(timeouts));
		}

	}

	public static void getAnnotationCMCLockType(LockType[] lockType, Method[] ejbMethods, BeanMetaData bmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAnnotationCMCLockType:  methods = " + Arrays.toString(ejbMethods));
		}

		LockType methodLockType = null;
		boolean metadataComplete = bmd.metadataComplete;

		for (int i = 0; i < ejbMethods.length; ++i) {
			Method beanMethod = ejbMethods[i];
			methodLockType = lockType[i];
			if (methodLockType == null) {
				if (metadataComplete) {
					methodLockType = LockType.WRITE;
				} else {
					Lock annotation = (Lock) beanMethod.getAnnotation(Lock.class);
					if (annotation == null) {
						Class<?> c = beanMethod.getDeclaringClass();
						annotation = (Lock) c.getAnnotation(Lock.class);
						if (isTraceOn && tc.isDebugEnabled() && annotation != null) {
							Tr.debug(tc, beanMethod.getName() + " from class " + c.getName());
						}
					}

					if (annotation == null) {
						methodLockType = LockType.WRITE;
					} else {
						methodLockType = annotation.value();
					}
				}

				lockType[i] = methodLockType;
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, beanMethod.getName() + " = " + methodLockType);
				}
			} else {
				boolean traceEnabled = isTraceOn && (tcDebug.isDebugEnabled() || tc.isDebugEnabled());
				if (traceEnabled) {
					Lock annotation = (Lock) beanMethod.getAnnotation(Lock.class);
					if (annotation == null) {
						Class<?> c = beanMethod.getDeclaringClass();
						annotation = (Lock) c.getAnnotation(Lock.class);
					}

					if (annotation != null && !annotation.value().equals(methodLockType)) {
						String msg;
						if (methodLockType == LockType.WRITE) {
							msg = "ejb-jar.xml is overriding a @Lock(READ) with a write lock. This may cause a deadlock to occur.";
						} else {
							msg = "ejb-jar.xml is overriding a @Lock(WRITE) with a read lock. This may cause data integrity problems.";
						}

						StringBuilder sb = new StringBuilder();
						sb.append("warning, for the ").append(beanMethod.toString()).append(" method, the ")
								.append(msg);
						if (tcDebug.isDebugEnabled()) {
							Tr.debug(tcDebug, sb.toString());
						} else {
							Tr.debug(tc, sb.toString());
						}
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getAnnotationCMCLockType", Arrays.toString(lockType));
		}

	}

	public static void getXMLCMCLockType(LockType[] lockType, Method[] ejbMethods, Session sessionBean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getXMLCMCLockType: " + sessionBean.getEjbClassName() + " methods = "
					+ Arrays.toString(ejbMethods));
		}

		int numberOfEjbMethods = ejbMethods.length;
		int[] highestStyleOnMethod = new int[numberOfEjbMethods];
		String enterpriseBeanName = sessionBean.getName();
		List<ConcurrentMethod> cmcMethodList = sessionBean.getConcurrentMethods();
		int numberOfCmcMethods = cmcMethodList.size();

		for (int i = 0; i < numberOfCmcMethods; ++i) {
			ConcurrentMethod cmcMethod = (ConcurrentMethod) cmcMethodList.get(i);
			int cmcLockType = cmcMethod.getLockTypeValue();
			if (cmcLockType != -1) {
				NamedMethod namedMethod = cmcMethod.getMethod();
				List<String> parms = namedMethod.getMethodParamList();
				LockType methodLockType = null;
				if (cmcLockType == 0) {
					methodLockType = LockType.READ;
				} else if (cmcLockType == 1) {
					methodLockType = LockType.WRITE;
				}

				String cmcMethodName = namedMethod.getMethodName().trim();
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, cmcMethodName + " LockType = " + methodLockType);
				}

				int j;
				Method m;
				if (cmcMethodName.equals("*")) {
					for (j = 0; j < numberOfEjbMethods; ++j) {
						m = ejbMethods[j];
						if (highestStyleOnMethod[j] <= 1) {
							if (isTraceOn && tc.isDebugEnabled()) {
								trace(m, enterpriseBeanName,
										"Style 1 - replacing " + lockType[j] + " lock type with " + methodLockType);
							}

							lockType[j] = methodLockType;
							highestStyleOnMethod[j] = 1;
						}
					}
				} else if (parms == null) {
					for (j = 0; j < numberOfEjbMethods; ++j) {
						if (highestStyleOnMethod[j] <= 2) {
							m = ejbMethods[j];
							String methodName = m.getName();
							if (cmcMethodName.equals(methodName)) {
								if (isTraceOn && tc.isDebugEnabled()) {
									trace(m, enterpriseBeanName,
											"Style 2 - replacing " + lockType[j] + " lock type with " + methodLockType);
								}

								lockType[j] = methodLockType;
								highestStyleOnMethod[j] = 2;
							}
						}
					}
				} else {
					Method style3Method = DDUtil.findMethod(namedMethod, ejbMethods);
					if (style3Method != null) {
						for (int j = 0; j < numberOfEjbMethods; ++j) {
							Method m = ejbMethods[j];
							if (style3Method.equals(m)) {
								if (isTraceOn && tc.isDebugEnabled()) {
									trace(m, enterpriseBeanName,
											"Style 3 - replacing " + lockType[j] + " lock type with " + methodLockType);
								}

								lockType[j] = methodLockType;
								highestStyleOnMethod[j] = 3;
								break;
							}
						}
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getXMLCMCLockType: " + sessionBean.getEjbClassName(), Arrays.toString(lockType));
		}

	}

	public static void getXMLCMCLockAccessTimeout(long[] accessTimeouts, Method[] ejbMethods, Session sessionBean)
			throws EJBConfigurationException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getXMLCMCLockAccessTimeout: " + sessionBean.getEjbClassName() + " methods = "
					+ Arrays.toString(ejbMethods));
		}

		int numberOfEjbMethods = ejbMethods.length;
		int[] highestStyleOnMethod = new int[numberOfEjbMethods];
		String enterpriseBeanName = sessionBean.getName();
		List<ConcurrentMethod> cmcMethodList = sessionBean.getConcurrentMethods();
		int numberOfCmcMethods = cmcMethodList.size();

		for (int i = 0; i < numberOfCmcMethods; ++i) {
			ConcurrentMethod cmcMethod = (ConcurrentMethod) cmcMethodList.get(i);
			com.ibm.ws.javaee.dd.ejb.AccessTimeout accessTimeout = cmcMethod.getAccessTimeout();
			NamedMethod namedMethod = cmcMethod.getMethod();
			List<String> parms = namedMethod.getMethodParamList();
			if (accessTimeout != null) {
				long value = accessTimeout.getTimeout();
				String cmcMethodName = namedMethod.getMethodName().trim();
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, cmcMethodName + " AccessTimeout value = " + value);
				}

				if (value < -1L || value == Long.MAX_VALUE) {
					String className = sessionBean.getEjbClassName();
					Tr.error(tc, "SINGLETON_INVALID_ACCESS_TIMEOUT_CNTR0192E",
							new Object[]{value, cmcMethodName, className});
					throw new EJBConfigurationException("CNTR0192E: The access timeout value " + value
							+ " is not valid for the enterprise bean " + cmcMethodName + " method of the " + className
							+ " class. The value must be -1 or greater and less"
							+ " than java.lang.Long.MAX_VALUE (9223372036854775807).");
				}

				long timeout;
				if (value > 0L) {
					TimeUnit tu = accessTimeout.getUnitValue();
					timeout = TimeUnit.MILLISECONDS.convert(value, tu);
					if (timeout == Long.MAX_VALUE || timeout == Long.MIN_VALUE) {
						Tr.error(tc, "SINGLETON_ACCESS_TIMEOUT_OVERFLOW_CNTR0196E", new Object[]{value, tu});
						if (isTraceOn && tc.isEntryEnabled()) {
							Tr.exit(tc, "convertToMilliSeconds: " + value + tu + " overflow");
						}

						throw new EJBConfigurationException("Conversion of access timeout value of " + value + " " + tu
								+ " to milliseconds resulted in overflow.");
					}
				} else {
					timeout = value;
				}

				Method m;
				int j;
				if (cmcMethodName.equals("*")) {
					for (j = 0; j < numberOfEjbMethods; ++j) {
						m = ejbMethods[j];
						if (highestStyleOnMethod[j] <= 1) {
							if (isTraceOn && tc.isDebugEnabled()) {
								trace(m, enterpriseBeanName, "Style 1 - replacing access timeout value of "
										+ accessTimeouts[j] + " with " + timeout);
							}

							accessTimeouts[j] = timeout;
							highestStyleOnMethod[j] = 1;
						}
					}
				} else if (parms == null) {
					for (j = 0; j < numberOfEjbMethods; ++j) {
						if (highestStyleOnMethod[j] <= 2) {
							m = ejbMethods[j];
							String methodName = m.getName();
							if (cmcMethodName.equals(methodName)) {
								if (isTraceOn && tc.isDebugEnabled()) {
									trace(m, enterpriseBeanName, "Style 2 - replacing access timeout value of "
											+ accessTimeouts[j] + " with " + timeout);
								}

								accessTimeouts[j] = timeout;
								highestStyleOnMethod[j] = 2;
							}
						}
					}
				} else {
					Method style3Method = DDUtil.findMethod(namedMethod, ejbMethods);
					if (style3Method != null) {
						for (int j = 0; j < numberOfEjbMethods; ++j) {
							Method m = ejbMethods[j];
							if (style3Method.equals(m)) {
								if (isTraceOn && tc.isDebugEnabled()) {
									trace(m, enterpriseBeanName, "Style 3 - replacing access timeout value of "
											+ accessTimeouts[j] + " with " + timeout);
								}

								accessTimeouts[j] = timeout;
								highestStyleOnMethod[j] = 3;
								break;
							}
						}
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getXMLCMCLockAccessTimeout: " + sessionBean.getEjbClassName(),
					Arrays.toString(accessTimeouts));
		}

	}

	public static long timeUnitToMillis(long value, TimeUnit unit, boolean annotation, BeanMetaData bmd)
			throws EJBConfigurationException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "timeUnitToMillis: " + value + unit);
		}

		long timeout;
		if (value > 0L) {
			timeout = TimeUnit.MILLISECONDS.convert(value, unit);
			if (timeout == Long.MAX_VALUE || timeout == Long.MIN_VALUE) {
				Tr.error(tc, "STATEFUL_TIMEOUT_OVERFLOW_CNTR0309E",
						new Object[]{bmd.getName(), bmd.getModuleMetaData().getName(),
								bmd.getModuleMetaData().getApplicationMetaData().getName(), value, unit});
				throw new EJBConfigurationException("Conversion of stateful session timeout value of " + value + " "
						+ unit + " to milliseconds resulted in overflow.");
			}
		} else if (value == 0L) {
			timeout = 1L;
		} else {
			if (value != -1L) {
				Object[] parms = new Object[]{bmd.getName(), bmd.getModuleMetaData().getName(),
						bmd.getModuleMetaData().getApplicationMetaData().getName(), value};
				if (annotation) {
					Tr.error(tc, "NEGATIVE_STATEFUL_TIMEOUT_ANN_CNTR0311E", parms);
				} else {
					Tr.error(tc, "NEGATIVE_STATEFUL_TIMEOUT_XML_CNTR0312E", parms);
				}

				throw new EJBConfigurationException(
						"Stateful session timeout value of " + value + " " + unit + " is negative.");
			}

			timeout = 0L;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "timeUnitToMillis: " + timeout);
		}

		return timeout;
	}

	static {
		tc = Tr.register(CLASS_NAME, "MetaData", "com.ibm.ejs.container.container");
		tcDebug = Tr.register(CLASS_NAME + "_Validation ", "MetaDataValidation", "com.ibm.ejs.container.container");
		populateTxMofMap();
		populateTxAttrFromJEE15Map();
		populateIsoStringMap();
		TX_ATTR_STR = new String[]{"TX_NOT_SUPPORTED", "TX_BEAN_MANAGED", "TX_REQUIRED", "TX_SUPPORTS",
				"TX_REQUIRES_NEW", "TX_MANDATORY", "TX_NEVER"};
		methodInterfaceTypeMap = MethodInterface.getAllValues();
	}
}