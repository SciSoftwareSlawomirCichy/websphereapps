package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import java.util.Comparator;
import java.util.Iterator;

@Beta
@GwtCompatible
public final class Comparators {
	public static <T, S extends T> Comparator<Iterable<S>> lexicographical(Comparator<T> comparator) {
		return new LexicographicalOrdering((Comparator) Preconditions.checkNotNull(comparator));
	}

	public static <T> boolean isInOrder(Iterable<? extends T> iterable, Comparator<T> comparator) {
		Preconditions.checkNotNull(comparator);
		Iterator<? extends T> it = iterable.iterator();
		Object next;
		if (it.hasNext()) {
			for (Object prev = it.next(); it.hasNext(); prev = next) {
				next = it.next();
				if (comparator.compare(prev, next) > 0) {
					return false;
				}
			}
		}

		return true;
	}

	public static <T> boolean isInStrictOrder(Iterable<? extends T> iterable, Comparator<T> comparator) {
		Preconditions.checkNotNull(comparator);
		Iterator<? extends T> it = iterable.iterator();
		Object next;
		if (it.hasNext()) {
			for (Object prev = it.next(); it.hasNext(); prev = next) {
				next = it.next();
				if (comparator.compare(prev, next) >= 0) {
					return false;
				}
			}
		}

		return true;
	}
}