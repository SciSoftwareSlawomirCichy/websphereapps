package javax.ws.rs.ext;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.ReflectPermission;
import java.util.Properties;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Variant.VariantListBuilder;
import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;

public abstract class RuntimeDelegate {
	public static final String JAXRS_RUNTIME_DELEGATE_PROPERTY = "javax.ws.rs.ext.RuntimeDelegate";
	private static volatile RuntimeDelegate delegate;

	public abstract <T> T createEndpoint(Application var1, Class<T> var2);

	public abstract <T> HeaderDelegate<T> createHeaderDelegate(Class<T> var1);

	public abstract ResponseBuilder createResponseBuilder();

	public abstract UriBuilder createUriBuilder();

	public abstract VariantListBuilder createVariantListBuilder();

	public static void setInstance(RuntimeDelegate delegate) throws SecurityException {
		SecurityManager secManager = System.getSecurityManager();
		if (secManager != null) {
			secManager.checkPermission(new ReflectPermission("suppressAccessChecks"));
		}

		delegate = delegate;
	}

	public static RuntimeDelegate getInstance() {
		if (delegate != null) {
			return delegate;
		} else {
			Class var0 = RuntimeDelegate.class;
			synchronized (RuntimeDelegate.class) {
				if (delegate != null) {
					return delegate;
				} else {
					String className = null;
					Object is = null;

					Class delegateClass;
					RuntimeDelegate var5;
					RuntimeDelegate var6;
					try {
						is = Thread.currentThread().getContextClassLoader()
								.getResourceAsStream("META-INF/services/javax.ws.rs.ext.RuntimeDelegate");
						if (is != null) {
							BufferedReader br = new BufferedReader(new InputStreamReader((InputStream) is, "UTF-8"));

							try {
								className = br.readLine();
								if (className != null && !"".equals(className)) {
									delegateClass = null;

									try {
										delegateClass = Class.forName(className, true,
												Thread.currentThread().getContextClassLoader());
										delegate = (RuntimeDelegate) delegateClass.newInstance();
										var5 = delegate;
										return var5;
									} catch (ClassNotFoundException var95) {
										try {
											delegateClass = Class.forName(className);
											delegate = (RuntimeDelegate) delegateClass.newInstance();
											var6 = delegate;
											return var6;
										} catch (ClassNotFoundException var94) {
											;
										}
									}
								}
							} catch (IOException var96) {
								;
							} catch (InstantiationException var97) {
								;
							} catch (IllegalAccessException var98) {
								;
							}
						}
					} catch (SecurityException var99) {
						;
					} catch (UnsupportedEncodingException var100) {
						;
					} finally {
						if (is != null) {
							try {
								((InputStream) is).close();
							} catch (IOException var78) {
								;
							}

							is = null;
						}

					}

					try {
						is = new FileInputStream(System.getProperty("java.home") + "/lib/jaxrs.properties");
						if (is != null) {
							Properties props = new Properties();

							try {
								props.load((InputStream) is);
								className = props.getProperty("javax.ws.rs.ext.RuntimeDelegate");
								if (className != null && !"".equals(className)) {
									try {
										delegateClass = Class.forName(className, true,
												Thread.currentThread().getContextClassLoader());
										delegate = (RuntimeDelegate) delegateClass.newInstance();
										var5 = delegate;
										return var5;
									} catch (ClassNotFoundException var87) {
										try {
											delegateClass = Class.forName(className);
											delegate = (RuntimeDelegate) delegateClass.newInstance();
											var6 = delegate;
											return var6;
										} catch (ClassNotFoundException var86) {
											;
										}
									}
								}
							} catch (IOException var88) {
								;
							} catch (InstantiationException var89) {
								;
							} catch (IllegalAccessException var90) {
								;
							}
						}
					} catch (SecurityException var91) {
						;
					} catch (FileNotFoundException var92) {
						;
					} finally {
						if (is != null) {
							try {
								((InputStream) is).close();
							} catch (IOException var79) {
								;
							}

							is = null;
						}

					}

					try {
						className = System.getProperty("javax.ws.rs.ext.RuntimeDelegate");
					} catch (SecurityException var80) {
						;
					}

					if (className == null || "".equals(className)) {
						className = "org.apache.wink.common.internal.runtime.RuntimeDelegateImpl";
					}

					try {
						RuntimeDelegate var10000;
						Class delegateClass;
						try {
							delegateClass = Class.forName(className, true,
									Thread.currentThread().getContextClassLoader());
							delegate = (RuntimeDelegate) delegateClass.newInstance();
							var10000 = delegate;
							return var10000;
						} catch (ClassNotFoundException var81) {
							;
						}

						try {
							delegateClass = Class.forName(className);
							delegate = (RuntimeDelegate) delegateClass.newInstance();
							var10000 = delegate;
							return var10000;
						} catch (ClassNotFoundException var82) {
							;
						}
					} catch (SecurityException var83) {
						;
					} catch (InstantiationException var84) {
						;
					} catch (IllegalAccessException var85) {
						;
					}

					return delegate;
				}
			}
		}
	}
}