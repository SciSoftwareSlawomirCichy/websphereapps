package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;

public class java_awt_event_TextAdapter extends EventAdapterImpl implements TextListener {
	public void textValueChanged(TextEvent var1) {
		this.eventProcessor.processEvent("textValueChanged", new Object[]{var1});
	}
}