package com.ibm.json.java.internal;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.json.java.OrderedJSONObject;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Serializer {
	private Writer writer;

	public Serializer(Writer var1) {
		this.writer = var1;
	}

	public void flush() throws IOException {
		this.writer.flush();
	}

	public void close() throws IOException {
		this.writer.close();
	}

	public Serializer writeRawString(String var1) throws IOException {
		this.writer.write(var1);
		return this;
	}

	public Serializer writeNull() throws IOException {
		this.writeRawString("null");
		return this;
	}

	public Serializer writeNumber(Number var1) throws IOException {
		if (null == var1) {
			return this.writeNull();
		} else {
			if (var1 instanceof Float) {
				if (((Float) var1).isNaN()) {
					return this.writeNull();
				}

				if (Float.NEGATIVE_INFINITY == var1.floatValue()) {
					return this.writeNull();
				}

				if (Float.POSITIVE_INFINITY == var1.floatValue()) {
					return this.writeNull();
				}
			}

			if (var1 instanceof Double) {
				if (((Double) var1).isNaN()) {
					return this.writeNull();
				}

				if (Double.NEGATIVE_INFINITY == var1.doubleValue()) {
					return this.writeNull();
				}

				if (Double.POSITIVE_INFINITY == var1.doubleValue()) {
					return this.writeNull();
				}
			}

			this.writeRawString(var1.toString());
			return this;
		}
	}

	public Serializer writeBoolean(Boolean var1) throws IOException {
		if (null == var1) {
			return this.writeNull();
		} else {
			this.writeRawString(var1.toString());
			return this;
		}
	}

	private String rightAlignedZero(String var1, int var2) {
		if (var2 == var1.length()) {
			return var1;
		} else {
			StringBuffer var3 = new StringBuffer(var1);

			while (var3.length() < var2) {
				var3.insert(0, '0');
			}

			return var3.toString();
		}
	}

	public Serializer writeString(String var1) throws IOException {
		if (null == var1) {
			return this.writeNull();
		} else {
			this.writer.write(34);
			char[] var2 = var1.toCharArray();

			for (int var3 = 0; var3 < var2.length; ++var3) {
				char var4 = var2[var3];
				switch (var4) {
					case ' ' :
						this.writer.write("\\0");
						break;
					case '\b' :
						this.writer.write("\\b");
						break;
					case '\t' :
						this.writer.write("\\t");
						break;
					case '\n' :
						this.writer.write("\\n");
						break;
					case '\f' :
						this.writer.write("\\f");
						break;
					case '\r' :
						this.writer.write("\\r");
						break;
					case '"' :
						this.writer.write("\\\"");
						break;
					case '/' :
						this.writer.write("\\/");
						break;
					case '\\' :
						this.writer.write("\\\\");
						break;
					default :
						if (var4 >= ' ' && var4 <= '~') {
							this.writer.write(var4);
						} else {
							this.writer.write("\\u");
							this.writer.write(this.rightAlignedZero(Integer.toHexString(var4), 4));
						}
				}
			}

			this.writer.write(34);
			return this;
		}
	}

	private Serializer write(Object var1) throws IOException {
		if (null == var1) {
			return this.writeNull();
		} else if (var1 instanceof Number) {
			return this.writeNumber((Number) var1);
		} else if (var1 instanceof String) {
			return this.writeString((String) var1);
		} else if (var1 instanceof Boolean) {
			return this.writeBoolean((Boolean) var1);
		} else if (var1 instanceof JSONObject) {
			return this.writeObject((JSONObject) var1);
		} else if (var1 instanceof JSONArray) {
			return this.writeArray((JSONArray) var1);
		} else {
			throw new IOException("Attempting to serialize unserializable object: '" + var1 + "'");
		}
	}

	public Serializer writeObject(JSONObject var1) throws IOException {
		if (null == var1) {
			return this.writeNull();
		} else {
			this.writeRawString("{");
			this.indentPush();
			Iterator var2 = null;
			if (var1 instanceof OrderedJSONObject) {
				var2 = ((OrderedJSONObject) var1).getOrder();
			} else {
				List var3 = this.getPropertyNames(var1);
				var2 = var3.iterator();
			}

			while (var2.hasNext()) {
				Object var5 = var2.next();
				if (!(var5 instanceof String)) {
					throw new IOException(
							"attempting to serialize object with an invalid property name: '" + var5 + "'");
				}

				Object var4 = var1.get(var5);
				if (!JSONObject.isValidObject(var4)) {
					throw new IOException(
							"attempting to serialize object with an invalid property value: '" + var4 + "'");
				}

				this.newLine();
				this.indent();
				this.writeString((String) var5);
				this.writeRawString(":");
				this.space();
				this.write(var4);
				if (var2.hasNext()) {
					this.writeRawString(",");
				}
			}

			this.indentPop();
			this.newLine();
			this.indent();
			this.writeRawString("}");
			return this;
		}
	}

	public Serializer writeArray(JSONArray var1) throws IOException {
		if (null == var1) {
			return this.writeNull();
		} else {
			this.writeRawString("[");
			this.indentPush();
			Iterator var2 = var1.iterator();

			while (var2.hasNext()) {
				Object var3 = var2.next();
				if (!JSONObject.isValidObject(var3)) {
					throw new IOException("attempting to serialize array with an invalid element: '" + var1 + "'");
				}

				this.newLine();
				this.indent();
				this.write(var3);
				if (var2.hasNext()) {
					this.writeRawString(",");
				}
			}

			this.indentPop();
			this.newLine();
			this.indent();
			this.writeRawString("]");
			return this;
		}
	}

	public void space() throws IOException {
	}

	public void newLine() throws IOException {
	}

	public void indent() throws IOException {
	}

	public void indentPush() {
	}

	public void indentPop() {
	}

	public List getPropertyNames(Map var1) {
		return new ArrayList(var1.keySet());
	}
}