@ParametersAreNonnullByDefault
@CheckReturnValue
package com.google.common.primitives;

import com.google.errorprone.annotations.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;