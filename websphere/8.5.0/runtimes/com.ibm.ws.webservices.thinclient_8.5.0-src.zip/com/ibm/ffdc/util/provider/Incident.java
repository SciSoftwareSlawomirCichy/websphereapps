package com.ibm.ffdc.util.provider;

import java.util.Date;

public interface Incident {
	String getSourceId();

	String getProbeId();

	String getExceptionName();

	int getCount();

	long getTimeStamp();

	Date getDateOfFirstOccurrence();

	String getLabel();
}