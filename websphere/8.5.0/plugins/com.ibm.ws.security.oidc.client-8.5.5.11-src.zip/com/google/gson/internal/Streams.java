package com.google.gson.internal;

import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.internal.Streams.1;
import com.google.gson.internal.Streams.AppendableWriter;
import com.google.gson.internal.bind.TypeAdapters;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.google.gson.stream.MalformedJsonException;
import java.io.EOFException;
import java.io.IOException;
import java.io.Writer;

public final class Streams {
	public static JsonElement parse(JsonReader reader) throws JsonParseException {
		boolean isEmpty = true;

		try {
			reader.peek();
			isEmpty = false;
			return (JsonElement) TypeAdapters.JSON_ELEMENT.read(reader);
		} catch (EOFException var3) {
			if (isEmpty) {
				return JsonNull.INSTANCE;
			} else {
				throw new JsonSyntaxException(var3);
			}
		} catch (MalformedJsonException var4) {
			throw new JsonSyntaxException(var4);
		} catch (IOException var5) {
			throw new JsonIOException(var5);
		} catch (NumberFormatException var6) {
			throw new JsonSyntaxException(var6);
		}
	}

	public static void write(JsonElement element, JsonWriter writer) throws IOException {
		TypeAdapters.JSON_ELEMENT.write(writer, element);
	}

	public static Writer writerForAppendable(Appendable appendable) {
      return (Writer)(appendable instanceof Writer ? (Writer)appendable : new AppendableWriter(appendable, (1)null));
   }
}