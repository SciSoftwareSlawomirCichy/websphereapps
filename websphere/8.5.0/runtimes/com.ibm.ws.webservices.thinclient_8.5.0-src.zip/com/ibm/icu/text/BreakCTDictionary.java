package com.ibm.icu.text;

import com.ibm.icu.impl.ICUBinary;
import com.ibm.icu.impl.ICUBinary.Authenticate;
import com.ibm.icu.text.BreakCTDictionary.CompactTrieHeader;
import com.ibm.icu.text.BreakCTDictionary.CompactTrieHorizontalNode;
import com.ibm.icu.text.BreakCTDictionary.CompactTrieNodes;
import com.ibm.icu.text.BreakCTDictionary.CompactTrieVerticalNode;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.CharacterIterator;

class BreakCTDictionary {
	private CompactTrieHeader fData;
	private CompactTrieNodes[] nodes;
	private static final byte[] DATA_FORMAT_ID = new byte[]{84, 114, 68, 99};

	private CompactTrieNodes getCompactTrieNode(int node) {
		return this.nodes[node];
	}

	public BreakCTDictionary(InputStream is) throws IOException {
		ICUBinary.readHeader(is, DATA_FORMAT_ID, (Authenticate) null);
		DataInputStream in = new DataInputStream(is);
		this.fData = new CompactTrieHeader();
		this.fData.size = in.readInt();
		this.fData.magic = in.readInt();
		this.fData.nodeCount = in.readShort();
		this.fData.root = in.readShort();
		this.loadBreakCTDictionary(in);
	}

	private void loadBreakCTDictionary(DataInputStream in) throws IOException {
		int j;
		for (j = 0; j < this.fData.nodeCount; ++j) {
			in.readInt();
		}

		this.nodes = new CompactTrieNodes[this.fData.nodeCount];
		this.nodes[0] = new CompactTrieNodes();

		for (j = 1; j < this.fData.nodeCount; ++j) {
			this.nodes[j] = new CompactTrieNodes();
			this.nodes[j].flagscount = in.readShort();
			int count = this.nodes[j].flagscount & 4095;
			if (count != 0) {
				boolean isVerticalNode = (this.nodes[j].flagscount & 4096) != 0;
				int n;
				if (isVerticalNode) {
					this.nodes[j].vnode = new CompactTrieVerticalNode();
					this.nodes[j].vnode.equal = in.readShort();
					this.nodes[j].vnode.chars = new char[count];

					for (n = 0; n < count; ++n) {
						this.nodes[j].vnode.chars[n] = in.readChar();
					}
				} else {
					this.nodes[j].hnode = new CompactTrieHorizontalNode[count];

					for (n = 0; n < count; ++n) {
						this.nodes[j].hnode[n] = new CompactTrieHorizontalNode(in.readChar(), in.readShort());
					}
				}
			}
		}

	}

	public int matches(CharacterIterator text, int maxLength, int[] lengths, int[] count, int limit) {
		CompactTrieNodes node = this.getCompactTrieNode(this.fData.root);
		int mycount = 0;
		char uc = text.current();
		int i = 0;
		boolean exitFlag = false;

		while (node != null) {
			if (limit > 0 && (node.flagscount & 8192) != 0) {
				lengths[mycount++] = i;
				--limit;
			}

			if (i >= maxLength) {
				break;
			}

			int nodeCount = node.flagscount & 4095;
			if (nodeCount == 0) {
				break;
			}

			int j;
			if ((node.flagscount & 4096) == 0) {
				CompactTrieHorizontalNode[] hnode = node.hnode;
				j = 0;
				int high = nodeCount - 1;
				node = null;

				while (high >= j) {
					int middle = (high + j) / 2;
					if (uc == hnode[middle].ch) {
						node = this.getCompactTrieNode(hnode[middle].equal);
						text.next();
						uc = text.current();
						++i;
						break;
					}

					if (uc < hnode[middle].ch) {
						high = middle - 1;
					} else {
						j = middle + 1;
					}
				}
			} else {
				CompactTrieVerticalNode vnode = node.vnode;

				for (j = 0; j < nodeCount && i < maxLength; ++j) {
					if (uc != vnode.chars[j]) {
						exitFlag = true;
						break;
					}

					text.next();
					uc = text.current();
					++i;
				}

				if (exitFlag) {
					break;
				}

				node = this.getCompactTrieNode(vnode.equal);
			}
		}

		count[0] = mycount;
		return i;
	}
}