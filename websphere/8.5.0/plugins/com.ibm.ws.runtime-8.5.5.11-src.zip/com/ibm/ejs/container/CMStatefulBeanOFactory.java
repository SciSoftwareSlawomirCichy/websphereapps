package com.ibm.ejs.container;

import com.ibm.ws.managedobject.ManagedObject;

public class CMStatefulBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		return new CMStatefulBeanO(c, mo, b, h);
	}
}