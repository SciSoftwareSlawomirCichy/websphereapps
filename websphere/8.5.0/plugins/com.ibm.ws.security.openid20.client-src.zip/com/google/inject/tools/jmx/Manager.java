package com.google.inject.tools.jmx;

import com.google.inject.Binding;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.Module;
import java.lang.annotation.Annotation;
import java.lang.management.ManagementFactory;
import java.util.Iterator;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

public class Manager {
	public static void manage(String domain, Injector injector) {
		manage(ManagementFactory.getPlatformMBeanServer(), domain, injector);
	}

	public static void manage(MBeanServer server, String domain, Injector injector) {
		Iterator i$ = injector.getBindings().values().iterator();

		while (i$.hasNext()) {
			Binding<?> binding = (Binding) i$.next();
			StringBuilder name = new StringBuilder();
			name.append(domain).append(":");
			Key<?> key = binding.getKey();
			name.append("type=").append(quote(key.getTypeLiteral().toString()));
			Annotation annotation = key.getAnnotation();
			if (annotation != null) {
				name.append(",annotation=").append(quote(annotation.toString()));
			} else {
				Class<? extends Annotation> annotationType = key.getAnnotationType();
				if (annotationType != null) {
					name.append(",annotation=").append(quote("@" + annotationType.getName()));
				}
			}

			try {
				server.registerMBean(new ManagedBinding(binding), new ObjectName(name.toString()));
			} catch (MalformedObjectNameException var9) {
				throw new RuntimeException("Bad object name: " + name.toString(), var9);
			} catch (Exception var10) {
				throw new RuntimeException(var10);
			}
		}

	}

	static String quote(String value) {
		return ObjectName.quote(value).replace(',', ';');
	}

	public static void main(String[] args) throws Exception {
		if (args.length != 1) {
			System.err.println(
					"Usage: java -Dcom.sun.management.jmxremote " + Manager.class.getName() + " [module class name]");
			System.err.println("Then run 'jconsole' to connect.");
			System.exit(1);
		}

		Module module = (Module) Class.forName(args[0]).newInstance();
		Injector injector = Guice.createInjector(new Module[]{module});
		manage(args[0], injector);
		System.out.println("Press Ctrl+C to exit...");
		Thread.sleep(Long.MAX_VALUE);
	}
}