package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Objects;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public abstract class ForwardingMapEntry<K, V> extends ForwardingObject implements Map.Entry<K, V> {
	protected ForwardingMapEntry() {
	}

	protected abstract Map.Entry<K, V> delegate();

	public K getKey() {
		return this.delegate().getKey();
	}

	public V getValue() {
		return this.delegate().getValue();
	}

	public V setValue(V value) {
		return this.delegate().setValue(value);
	}

	public boolean equals(@NullableDecl Object object) {
		return this.delegate().equals(object);
	}

	public int hashCode() {
		return this.delegate().hashCode();
	}

	protected boolean standardEquals(@NullableDecl Object object) {
		if (!(object instanceof Map.Entry)) {
			return false;
		} else {
			Map.Entry<?, ?> that = (Map.Entry) object;
			return Objects.equal(this.getKey(), that.getKey()) && Objects.equal(this.getValue(), that.getValue());
		}
	}

	protected int standardHashCode() {
		K k = this.getKey();
		V v = this.getValue();
		return (k == null ? 0 : k.hashCode()) ^ (v == null ? 0 : v.hashCode());
	}

	@Beta
	protected String standardToString() {
		return this.getKey() + "=" + this.getValue();
	}
}