package com.ibm.bsf.util.event.generator;

import com.ibm.bsf.debug.util.DebugLog;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;

public class EventAdapterGenerator {
	public static AdapterClassLoader ldr = new AdapterClassLoader();
	static Class EVENTLISTENER = null;
	static String CLASSPACKAGE = "com/ibm/bsf/util/event/adapters/";
	static String WRITEDIRECTORY = null;
	static byte[] CLASSHEADER;
	static short BASECPCOUNT;
	static byte[] BASECP;
	static byte[] FIXEDCLASSBYTES;
	static byte[] INITMETHOD;

	public static Class makeEventAdapterClass(Class var0, boolean var1) {
		DebugLog.stdoutPrintln("EventAdapterGenerator", 3);
		if (EVENTLISTENER.isAssignableFrom(var0)) {
			boolean var2 = false;
			boolean var3 = false;
			Object var4 = null;
			byte var6 = 0;
			String var10 = var0.getName();
			DebugLog.stdoutPrintln("  ListenerTypeName: " + var10, 3);
			String var11 = CLASSPACKAGE
					+ (var10.endsWith("Listener") ? var10.substring(0, var10.length() - 8) : var10).replace('.', '_')
					+ "Adapter";
			String var12 = var11;
			Class var13 = null;
			int var14 = 0;

			do {
				if (null != (var13 = ldr.getLoadedClass(var12))) {
					DebugLog.stdoutPrintln("cached:  " + var13, 3);

					try {
						if (var0.isAssignableFrom(var13)) {
							return var13;
						}

						var12 = var11 + "_" + var14++;
					} catch (VerifyError var26) {
						System.err.println(var26.getMessage());
						var26.printStackTrace();
						return var13;
					}
				}
			} while (var13 != null);

			String var15 = var10.replace('.', '/');
			Method[] var16 = var0.getMethods();
			short var30 = (short) (var6 + 4);
			byte[] var29 = Bytecode.addUtf8((byte[]) var4, var15);
			var29 = Bytecode.addUtf8(var29, var12);
			var29 = Bytecode.addClass(var29, (short) 17);
			var29 = Bytecode.addClass(var29, (short) 18);

			int var17;
			for (var17 = 0; var17 < var16.length; ++var17) {
				Class[] var18 = var16[var17].getExceptionTypes();
				if (0 < var18.length) {
					var2 = true;
				} else {
					var3 = true;
				}
			}

			boolean var9 = false;
			if (var3) {
				byte var32 = 3;
				var30 = (short) (var30 + var32);
				var29 = Bytecode.addUtf8(var29, "processEvent");
				var29 = Bytecode.addNameAndType(var29, (short) 21, (short) 8);
				var29 = Bytecode.addInterfaceMethodRef(var29, (short) 12, (short) 22);
			}

			boolean var8 = false;
			int var19;
			int var33;
			if (var2) {
				var17 = BASECPCOUNT + var30 + 1;
				var33 = BASECPCOUNT + var30 + 0;
				var19 = BASECPCOUNT + var30 + 3;
				byte var31 = 5;
				var30 = (short) (var30 + var31);
				var29 = Bytecode.addUtf8(var29, "processExceptionableEvent");
				var29 = Bytecode.addUtf8(var29, "java/lang/Exception");
				var29 = Bytecode.addClass(var29, (short) var17);
				var29 = Bytecode.addNameAndType(var29, (short) var33, (short) 8);
				var29 = Bytecode.addInterfaceMethodRef(var29, (short) 12, (short) var19);
			}

			short var5 = (short) (BASECPCOUNT + var30);
			DebugLog.stderrPrintln("cpBaseIndex: " + var5, 3);

			for (var17 = 0; var17 < var16.length; ++var17) {
				String var35 = var16[var17].getName();
				String var36 = var16[var17].getParameterTypes()[0].getName().replace('.', '/');
				var30 = (short) (var30 + 3);
				var29 = Bytecode.addUtf8(var29, var35);
				var29 = Bytecode.addUtf8(var29, "(L" + var36 + ";)V");
				var29 = Bytecode.addString(var29, (short) (BASECPCOUNT + var30 - 3));
			}

			boolean[] var34 = new boolean[var16.length];
			var33 = 0;

			for (var19 = 0; var19 < var16.length; ++var19) {
				String var20 = var16[var19].getParameterTypes()[0].getName().replace('.', '/');
				if (var20.equalsIgnoreCase("java/beans/PropertyChangeEvent")) {
					var34[var19] = true;
					if (0 == var33) {
						var29 = Bytecode.addUtf8(var29, var20);
						var29 = Bytecode.addUtf8(var29, "getPropertyName");
						var29 = Bytecode.addUtf8(var29, "()Ljava/lang/String;");
						var29 = Bytecode.addClass(var29, (short) (BASECPCOUNT + var30));
						var29 = Bytecode.addNameAndType(var29, (short) (BASECPCOUNT + var30 + 1),
								(short) (BASECPCOUNT + var30 + 2));
						var29 = Bytecode.addMethodRef(var29, (short) (BASECPCOUNT + var30 + 3),
								(short) (BASECPCOUNT + var30 + 4));
						var30 = (short) (var30 + 6);
						var33 = BASECPCOUNT + var30 - 1;
					}
				} else {
					var34[var19] = false;
				}
			}

			short var7 = (short) (BASECPCOUNT + var30);
			DebugLog.stderrPrintln("cpExceptionBaseIndex: " + var7, 3);
			int[][] var37 = new int[var16.length][];

			int var22;
			for (int var38 = 0; var38 < var16.length; ++var38) {
				Class[] var21 = var16[var38].getExceptionTypes();
				var37[var38] = new int[var21.length];

				for (var22 = 0; var22 < var21.length; ++var22) {
					var29 = Bytecode.addUtf8(var29, var21[var22].getName().replace('.', '/'));
					var29 = Bytecode.addClass(var29, (short) (BASECPCOUNT + var30));
					var37[var38][var22] = BASECPCOUNT + var30 + 1;
					var30 = (short) (var30 + 2);
				}
			}

			byte[] var39 = CLASSHEADER;
			short var40 = (short) (BASECPCOUNT + var30);
			var39 = ByteUtility.addBytes(var39, var40);
			var39 = ByteUtility.addBytes(var39, BASECP);
			var39 = ByteUtility.addBytes(var39, var29);
			var39 = ByteUtility.addBytes(var39, FIXEDCLASSBYTES);
			var39 = ByteUtility.addBytes(var39, (short) (var16.length + 1));
			var39 = ByteUtility.addBytes(var39, INITMETHOD);

			for (var22 = 0; var22 < var16.length; ++var22) {
				var39 = ByteUtility.addBytes(var39, (short) 1);
				var39 = ByteUtility.addBytes(var39, (short) (var5 + 3 * var22 + 0));
				var39 = ByteUtility.addBytes(var39, (short) (var5 + 3 * var22 + 1));
				var39 = ByteUtility.addBytes(var39, (short) 1);
				var39 = ByteUtility.addBytes(var39, (short) 3);
				int var23 = 32;
				if (0 < var37[var22].length) {
					var23 += 5 + 8 * (1 + var37[var22].length);
				}

				if (var34[var22]) {
					var23 += 2;
				}

				var39 = ByteUtility.addBytes(var39, (long) var23);
				var39 = ByteUtility.addBytes(var39, (short) 6);
				var39 = ByteUtility.addBytes(var39, (short) 3);
				var23 = 20;
				if (var2 && 0 < var37[var22].length) {
					var23 += 5;
				}

				if (var34[var22]) {
					var23 += 2;
				}

				var39 = ByteUtility.addBytes(var39, (long) var23);
				var39 = ByteUtility.addBytes(var39, (byte) 42);
				var39 = ByteUtility.addBytes(var39, (byte) -76);
				var39 = ByteUtility.addBytes(var39, (short) 15);
				if (var34[var22]) {
					var39 = ByteUtility.addBytes(var39, (byte) 43);
					var39 = ByteUtility.addBytes(var39, (byte) -74);
					var39 = ByteUtility.addBytes(var39, (short) var33);
				} else {
					var39 = ByteUtility.addBytes(var39, (byte) 18);
					var39 = ByteUtility.addBytes(var39, (byte) (var5 + 3 * var22 + 2));
				}

				var39 = ByteUtility.addBytes(var39, (byte) 4);
				var39 = ByteUtility.addBytes(var39, (byte) -67);
				var39 = ByteUtility.addBytes(var39, (short) 10);
				var39 = ByteUtility.addBytes(var39, (byte) 89);
				var39 = ByteUtility.addBytes(var39, (byte) 3);
				var39 = ByteUtility.addBytes(var39, (byte) 43);
				var39 = ByteUtility.addBytes(var39, (byte) 83);
				var39 = ByteUtility.addBytes(var39, (byte) -71);
				var23 = 23;
				if (var2 && var3) {
					if (0 < var16[var22].getExceptionTypes().length) {
						var23 += 5;
					}
				} else if (var2) {
					var23 += 2;
				}

				var39 = ByteUtility.addBytes(var39, (short) var23);
				var39 = ByteUtility.addBytes(var39, (byte) 3);
				var39 = ByteUtility.addBytes(var39, (byte) 0);
				var39 = ByteUtility.addBytes(var39, (byte) -79);
				if (var2 && 0 < var37[var22].length) {
					var39 = ByteUtility.addBytes(var39, (byte) 77);
					var39 = ByteUtility.addBytes(var39, (byte) 44);
					var39 = ByteUtility.addBytes(var39, (byte) -65);
					var39 = ByteUtility.addBytes(var39, (byte) 87);
					var39 = ByteUtility.addBytes(var39, (byte) -79);
					var23 = var37[var22].length;
					var39 = ByteUtility.addBytes(var39, (short) (1 + var23));

					for (int var24 = 0; var24 < var23; ++var24) {
						var39 = ByteUtility.addBytes(var39, (short) 0);
						if (var34[var22]) {
							var39 = ByteUtility.addBytes(var39, (short) 21);
							var39 = ByteUtility.addBytes(var39, (short) 22);
						} else {
							var39 = ByteUtility.addBytes(var39, (short) 19);
							var39 = ByteUtility.addBytes(var39, (short) 20);
						}

						var39 = ByteUtility.addBytes(var39, (short) var37[var22][var24]);
					}

					var39 = ByteUtility.addBytes(var39, (short) 0);
					if (var34[var22]) {
						var39 = ByteUtility.addBytes(var39, (short) 21);
						var39 = ByteUtility.addBytes(var39, (short) 25);
					} else {
						var39 = ByteUtility.addBytes(var39, (short) 19);
						var39 = ByteUtility.addBytes(var39, (short) 23);
					}

					if (var3) {
						var39 = ByteUtility.addBytes(var39, (short) 26);
					} else {
						var39 = ByteUtility.addBytes(var39, (short) 23);
					}
				} else {
					var39 = ByteUtility.addBytes(var39, (short) 0);
				}

				var39 = ByteUtility.addBytes(var39, (short) 0);
			}

			var39 = ByteUtility.addBytes(var39, (short) 0);
			DebugLog.stdoutPrintln("adapterName: " + var12, 3);
			DebugLog.stdoutPrintln("cpCount: " + var40 + " = " + BASECPCOUNT + " + " + var30, 3);
			DebugLog.stdoutPrintln("methodCount: " + (var16.length + 1), 3);
			Class var42;
			if (var1) {
				try {
					FileOutputStream var41 = new FileOutputStream(WRITEDIRECTORY + var12 + ".class");
					var41.write(var39);
					var41.close();
				} catch (IOException var25) {
					System.err.println(var25.getMessage());
					var25.printStackTrace();
				}

				try {
					var42 = ldr.loadClass(var12);
					DebugLog.stdoutPrintln("EventAdapterGenerator: " + var42.getName() + " dynamically generated", 3);
					return var42;
				} catch (ClassNotFoundException var28) {
					System.err.println(var28.getMessage());
					var28.printStackTrace();
				}
			}

			try {
				var42 = ldr.defineClass(var12, var39);
				DebugLog.stdoutPrintln("EventAdapterGenerator: " + var42.getName() + " dynamically generated", 3);
				return var42;
			} catch (Exception var27) {
				System.err.println(var27.getMessage());
				var27.printStackTrace();
			}
		} else {
			System.err.println("EventAdapterGenerator ListenerType invalid: listenerType = " + var0);
		}

		return null;
	}

	static {
		String var0 = System.getProperty("DynamicEventClassPackage", "");
		if (!var0.equals("")) {
			CLASSPACKAGE = var0;
		}

		if (CLASSPACKAGE.length() > 0) {
			CLASSPACKAGE = CLASSPACKAGE.replace('\\', '/');
			if (!CLASSPACKAGE.endsWith("/")) {
				CLASSPACKAGE = CLASSPACKAGE + "/";
			}
		}

		WRITEDIRECTORY = System.getProperty("DynamicEventClassWriteDirectory", CLASSPACKAGE);
		if (WRITEDIRECTORY.length() > 0) {
			WRITEDIRECTORY = WRITEDIRECTORY.replace('\\', '/');
			if (!WRITEDIRECTORY.endsWith("/")) {
				WRITEDIRECTORY = WRITEDIRECTORY + "/";
			}
		}

		try {
			EVENTLISTENER = Class.forName("java.util.EventListener");
		} catch (ClassNotFoundException var2) {
			System.err.println(var2.getMessage());
			var2.printStackTrace();
		}

		CLASSHEADER = ByteUtility.addBytes(CLASSHEADER, (byte) -54);
		CLASSHEADER = ByteUtility.addBytes(CLASSHEADER, (byte) -2);
		CLASSHEADER = ByteUtility.addBytes(CLASSHEADER, (byte) -70);
		CLASSHEADER = ByteUtility.addBytes(CLASSHEADER, (byte) -66);
		CLASSHEADER = ByteUtility.addBytes(CLASSHEADER, (short) 3);
		CLASSHEADER = ByteUtility.addBytes(CLASSHEADER, (short) 45);
		BASECPCOUNT = 17;
		BASECP = Bytecode.addUtf8(BASECP, "()V");
		BASECP = Bytecode.addUtf8(BASECP, "<init>");
		BASECP = Bytecode.addUtf8(BASECP, "Code");
		BASECP = Bytecode.addUtf8(BASECP, "eventProcessor");
		BASECP = Bytecode.addUtf8(BASECP, "java/lang/Object");
		BASECP = Bytecode.addUtf8(BASECP, "com/ibm/bsf/util/event/EventAdapterImpl");
		BASECP = Bytecode.addUtf8(BASECP, "com/ibm/bsf/util/event/EventProcessor");
		BASECP = Bytecode.addUtf8(BASECP, "(Ljava/lang/String;[Ljava/lang/Object;)V");
		BASECP = Bytecode.addUtf8(BASECP, "Lcom/ibm/bsf/util/event/EventProcessor;");
		BASECP = Bytecode.addClass(BASECP, (short) 5);
		BASECP = Bytecode.addClass(BASECP, (short) 6);
		BASECP = Bytecode.addClass(BASECP, (short) 7);
		BASECP = Bytecode.addNameAndType(BASECP, (short) 2, (short) 1);
		BASECP = Bytecode.addNameAndType(BASECP, (short) 4, (short) 9);
		BASECP = Bytecode.addFieldRef(BASECP, (short) 11, (short) 14);
		BASECP = Bytecode.addMethodRef(BASECP, (short) 11, (short) 13);
		FIXEDCLASSBYTES = ByteUtility.addBytes(FIXEDCLASSBYTES, (short) 33);
		FIXEDCLASSBYTES = ByteUtility.addBytes(FIXEDCLASSBYTES, (short) 20);
		FIXEDCLASSBYTES = ByteUtility.addBytes(FIXEDCLASSBYTES, (short) 11);
		FIXEDCLASSBYTES = ByteUtility.addBytes(FIXEDCLASSBYTES, (short) 1);
		FIXEDCLASSBYTES = ByteUtility.addBytes(FIXEDCLASSBYTES, (short) 19);
		FIXEDCLASSBYTES = ByteUtility.addBytes(FIXEDCLASSBYTES, (short) 0);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 1);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 2);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 1);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 1);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 3);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, 17L);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 1);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 1);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, 5L);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (byte) 42);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (byte) -73);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 16);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (byte) -79);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 0);
		INITMETHOD = ByteUtility.addBytes(INITMETHOD, (short) 0);
	}
}