package com.ibm.wsspi.security.crypto;

public class EncryptedInfo {
	private byte[] bytes;
	private String alias;

	public EncryptedInfo(byte[] encryptedBytes, String keyAlias) {
		this.bytes = encryptedBytes;
		this.alias = keyAlias;
	}

	public byte[] getEncryptedBytes() {
		return this.bytes;
	}

	public String getKeyAlias() {
		return this.alias;
	}
}