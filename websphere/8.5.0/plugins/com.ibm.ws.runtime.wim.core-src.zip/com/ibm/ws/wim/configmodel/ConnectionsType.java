package com.ibm.ws.wim.configmodel;

public interface ConnectionsType {
	String getHost();

	void setHost(String var1);

	int getPort();

	void setPort(int var1);

	void unsetPort();

	boolean isSetPort();
}