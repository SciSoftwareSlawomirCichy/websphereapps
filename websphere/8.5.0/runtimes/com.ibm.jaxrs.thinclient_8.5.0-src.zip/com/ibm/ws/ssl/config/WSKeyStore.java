package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.security.keystoreutil.KeyStoreUtil;
import com.ibm.websphere.crypto.KeyException;
import com.ibm.websphere.models.config.properties.DescriptiveProperty;
import com.ibm.websphere.ssl.JSSEHelper;
import com.ibm.websphere.ssl.SSLConfigChangeListener;
import com.ibm.websphere.ssl.SSLException;
import com.ibm.ws.security.config.SecurityConfigObject;
import com.ibm.ws.security.config.SecurityConfigObjectList;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.security.util.KeyStoreTypeHelper;
import com.ibm.ws.ssl.JSSEProvider;
import com.ibm.ws.ssl.JSSEProviderFactory;
import com.ibm.ws.ssl.config.WSKeyStore.1;
import com.ibm.ws.ssl.core.WSPKCSInKeyStoreList;
import com.ibm.ws.ssl.model.KeyStoreInfo;
import com.ibm.ws.util.PlatformHelper;
import com.ibm.ws.util.PlatformHelperFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivilegedActionException;
import java.security.Provider;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class WSKeyStore extends Properties {
	private static final long serialVersionUID = -2397938369447451595L;
	private static final TraceComponent tc = Tr.register(WSKeyStore.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private static final WSPKCSInKeyStoreList pkcsStoreList = new WSPKCSInKeyStoreList();
	private KeyStore ks = null;
	public static boolean defaultKeyStoreWarningIssued = false;
	public static boolean callFFDC = false;
	public static final List<String> METHODS_REQUIRE_PASSWORD = Arrays.asList("getKey", "setKeyEntry",
			"setKeyEntryOverwrite", "getCertificateChainFromUnManagedKeyStore", "getKeyFromUnManagedKeyStore",
			"containsAliasFromUnManagedKeyStore", "setKeyEntryFromUnManagedKeyStore", "load", "store");

	public WSKeyStore(com.ibm.websphere.models.config.ipc.ssl.KeyStore keyStore) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "KeyStore <init>");
		}

		this.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
		this.setProperty("com.ibm.ssl.keyStoreProvider", "IBMJCE");
		this.setProperty("com.ibm.ssl.keyStoreType", "PKCS12");
		this.setProperty("com.ibm.ssl.keyStoreReadOnly", "false");
		this.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "false");
		this.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "true");
		if (SSLConfigManager.getInstance().isServerProcess()) {
			this.setProperty("com.ibm.ssl.keyStoreScope", ManagementScopeManager.getInstance().getCellScopeName());
		}

		boolean tokenEnabled = false;
		if (keyStore != null && keyStore.getLocation() != null) {
			String keyStoreProvider = keyStore.getProvider();
			if (keyStoreProvider != null) {
				if (keyStoreProvider.equals("IBMPKCS11Impl")) {
					tokenEnabled = true;
					this.setProperty("com.ibm.ssl.tokenEnabled", "true");
				}

				this.setProperty("com.ibm.ssl.keyStoreProvider", keyStoreProvider);
			}

			String keyStoreName = keyStore.getName();
			if (keyStoreName != null) {
				this.setProperty("com.ibm.ssl.keyStoreName", keyStoreName);
			}

			String keyStorePassword = keyStore.getPassword();
			if (keyStorePassword != null) {
				if (!defaultKeyStoreWarningIssued && keyStorePassword.equals("WebAS")) {
					Tr.warning(tc, "ssl.default.password.in.use.CWPKI0041W");
					defaultKeyStoreWarningIssued = true;
				}

				this.setProperty("com.ibm.ssl.keyStorePassword", keyStorePassword);
			}

			String keyStoreLocation = keyStore.getLocation();
			if (keyStoreLocation != null) {
				this.setProperty("com.ibm.ssl.keyStore", KeyStoreManager.getInstance().expand(keyStoreLocation));
			}

			String keyStoreType = keyStore.getType();
			if (keyStoreType != null) {
				this.setProperty("com.ibm.ssl.keyStoreType", keyStoreType);
				if (!keyStoreType.equals("JKS") && !keyStoreType.equals("JCEKS") && !keyStoreType.equals("PKCS12")) {
					this.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
				}

				if (keyStoreType.equals("PKCS11")) {
					tokenEnabled = true;
					this.setProperty("com.ibm.ssl.tokenEnabled", "true");
				}
			}

			String hostList;
			if (tokenEnabled) {
				hostList = Integer.toString(keyStore.getSlot());
				this.setProperty("com.ibm.ssl.keyStoreSlot", hostList);
			}

			hostList = keyStore.getHostList();
			if (hostList != null && !hostList.equals("")) {
				this.setProperty("com.ibm.ssl.keyStoreHostList", hostList);
			}

			if (keyStore.getManagementScope() != null) {
				this.setProperty("com.ibm.ssl.keyStoreScope", keyStore.getManagementScope().getScopeName());
			} else {
				this.setProperty("com.ibm.ssl.keyStoreScope", ManagementScopeManager.getInstance().getCellScopeName());
			}

			String customClass = keyStore.getCustomProviderClass();
			if (customClass != null && !customClass.equals("")) {
				this.setProperty("com.ibm.ssl.keyStoreCustomClass", customClass);
			}

			this.setProperty("com.ibm.ssl.keyStoreFileBased", keyStore.isFileBased() ? "true" : "false");
			this.setProperty("com.ibm.ssl.keyStoreReadOnly", keyStore.isReadOnly() ? "true" : "false");
			if (keyStoreType != null && (keyStoreType.equals("JCERACFKS") || keyStoreType.equals("JCECCARACFKS"))
					&& keyStoreLocation != null && keyStoreLocation.startsWith("safkeyring:///")) {
				this.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
			}

			this.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup",
					keyStore.isInitializeAtStartup() ? "true" : "false");
			this.setProperty("com.ibm.ssl.keyStoreCreateCMSStash",
					keyStore.isCreateStashFileForCMS() ? "true" : "false");
			this.setProperty("com.ibm.ssl.keyStoreUseForAcceleration",
					keyStore.isUseForAcceleration() ? "true" : "false");
			List<?> otherProps = keyStore.getAdditionalKeyStoreAttrs();
			if (otherProps != null) {
				Iterator listIterator = otherProps.iterator();

				while (listIterator.hasNext()) {
					DescriptiveProperty prop = (DescriptiveProperty) listIterator.next();
					if (prop != null) {
						this.setProperty(prop.getName(), prop.getValue());
					}
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public WSKeyStore(SecurityConfigObject keyStore) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "KeyStore <init>");
		}

		this.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
		this.setProperty("com.ibm.ssl.keyStoreProvider", "IBMJCE");
		this.setProperty("com.ibm.ssl.keyStoreType", "PKCS12");
		this.setProperty("com.ibm.ssl.keyStoreReadOnly", "false");
		this.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "false");
		this.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "true");
		if (SSLConfigManager.getInstance().isServerProcess()) {
			this.setProperty("com.ibm.ssl.keyStoreScope", ManagementScopeManager.getInstance().getCellScopeName());
		}

		boolean tokenEnabled = false;
		if (keyStore != null && keyStore.getUnexpandedString("location") != null) {
			String keyStoreProvider = keyStore.getString("provider");
			if (keyStoreProvider != null) {
				if (keyStoreProvider.equals("PKCS11")) {
					tokenEnabled = true;
					this.setProperty("com.ibm.ssl.tokenEnabled", "true");
				}

				this.setProperty("com.ibm.ssl.keyStoreProvider", keyStoreProvider);
			}

			String keyStoreName = keyStore.getString("name");
			if (keyStoreName != null) {
				this.setProperty("com.ibm.ssl.keyStoreName", keyStoreName);
			}

			String keyStorePassword = keyStore.getDecodedString("password");
			if (keyStorePassword != null) {
				if (!defaultKeyStoreWarningIssued && keyStorePassword.equals("WebAS")) {
					Tr.warning(tc, "ssl.default.password.in.use.CWPKI0041W");
					defaultKeyStoreWarningIssued = true;
				}

				this.setProperty("com.ibm.ssl.keyStorePassword", keyStorePassword);
			}

			String keyStoreLocation = keyStore.getUnexpandedString("location");
			if (keyStoreLocation != null) {
				this.setProperty("com.ibm.ssl.keyStore", KeyStoreManager.getInstance().expand(keyStoreLocation));
			}

			String keyStoreType = keyStore.getString("type");
			if (keyStoreType != null) {
				this.setProperty("com.ibm.ssl.keyStoreType", keyStoreType);
				if (!keyStoreType.equals("JKS") && !keyStoreType.equals("JCEKS") && !keyStoreType.equals("PKCS12")) {
					this.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
				}
			}

			String hostList;
			if (tokenEnabled) {
				hostList = keyStore.getInteger("slot").toString();
				this.setProperty("com.ibm.ssl.keyStoreSlot", hostList);
			}

			hostList = keyStore.getString("hostList");
			if (hostList != null && !hostList.equals("")) {
				this.setProperty("com.ibm.ssl.keyStoreHostList", hostList);
			}

			SecurityConfigObject mgmtScope = keyStore.getObject("managementScope");
			if (mgmtScope != null) {
				this.setProperty("com.ibm.ssl.keyStoreScope", mgmtScope.getString("scopeName"));
			} else {
				this.setProperty("com.ibm.ssl.keyStoreScope", ManagementScopeManager.getInstance().getCellScopeName());
			}

			String customClass = keyStore.getString("customProviderClass");
			if (customClass != null && !customClass.equals("")) {
				this.setProperty("com.ibm.ssl.keyStoreCustomClass", customClass);
			}

			this.setProperty("com.ibm.ssl.keyStoreFileBased", keyStore.getBoolean("fileBased") ? "true" : "false");
			this.setProperty("com.ibm.ssl.keyStoreReadOnly", keyStore.getBoolean("readOnly") ? "true" : "false");
			if (keyStoreType != null && (keyStoreType.equals("JCERACFKS") || keyStoreType.equals("JCECCARACFKS"))
					&& keyStoreLocation != null && keyStoreLocation.startsWith("safkeyring:///")) {
				this.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
			}

			this.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup",
					keyStore.getBoolean("initializeAtStartup") ? "true" : "false");
			this.setProperty("com.ibm.ssl.keyStoreCreateCMSStash",
					keyStore.getBoolean("createStashFileForCMS") ? "true" : "false");
			this.setProperty("com.ibm.ssl.keyStoreUseForAcceleration",
					keyStore.getBoolean("useForAcceleration") ? "true" : "false");
			SecurityConfigObjectList otherProps = keyStore.getObjectList("additionalKeyStoreAttrs");
			if (otherProps != null) {
				for (int i = 0; i < otherProps.size(); ++i) {
					SecurityConfigObject prop = otherProps.get(i);
					if (prop != null) {
						this.setProperty(prop.getString("name"), prop.getString("value"));
					}
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public WSKeyStore(KeyStoreInfo keyStore) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "KeyStoreInfo <init>");
		}

		boolean tokenEnabled = false;
		if (keyStore != null && keyStore.getLocation() != null) {
			String keyStoreProvider = keyStore.getProvider();
			if (keyStoreProvider != null) {
				if (keyStoreProvider.equals("IBMPKCS11Impl")) {
					tokenEnabled = true;
					this.setProperty("com.ibm.ssl.tokenEnabled", "true");
				}

				this.setProperty("com.ibm.ssl.keyStoreProvider", keyStoreProvider);
			}

			String keyStoreName = keyStore.getName();
			if (keyStoreName != null) {
				this.setProperty("com.ibm.ssl.keyStoreName", keyStoreName);
			}

			String keyStorePassword = keyStore.getPassword();
			if (keyStorePassword != null) {
				if (!defaultKeyStoreWarningIssued && keyStorePassword.equals("WebAS")) {
					Tr.warning(tc, "ssl.default.password.in.use.CWPKI0041W");
					defaultKeyStoreWarningIssued = true;
				}

				this.setProperty("com.ibm.ssl.keyStorePassword", keyStorePassword);
			}

			String keyStoreLocation = keyStore.getLocation();
			if (keyStoreLocation != null) {
				this.setProperty("com.ibm.ssl.keyStore", KeyStoreManager.getInstance().expand(keyStoreLocation));
			}

			String keyStoreType = keyStore.getType();
			if (keyStoreType != null) {
				this.setProperty("com.ibm.ssl.keyStoreType", keyStoreType);
				if (!keyStoreType.equals("JKS") && !keyStoreType.equals("JCEKS") && !keyStoreType.equals("PKCS12")) {
					this.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
				}

				if (keyStoreType.equals("PKCS11")) {
					tokenEnabled = true;
					this.setProperty("com.ibm.ssl.tokenEnabled", "true");
				}
			}

			String hostList;
			if (tokenEnabled) {
				hostList = keyStore.getSlot().toString();
				this.setProperty("com.ibm.ssl.keyStoreSlot", hostList);
			}

			hostList = keyStore.getHostList();
			if (hostList != null && !hostList.equals("")) {
				this.setProperty("com.ibm.ssl.keyStoreHostList", hostList);
			}

			if (keyStore.getScopeNameString() != null) {
				this.setProperty("com.ibm.ssl.keyStoreScope", keyStore.getScopeNameString());
			}

			String customClass = keyStore.getCustomProvider();
			if (customClass != null && !customClass.equals("")) {
				this.setProperty("com.ibm.ssl.keyStoreCustomClass", customClass);
			}

			if (keyStore.getFileBased() != null) {
				this.setProperty("com.ibm.ssl.keyStoreFileBased", keyStore.getFileBased() ? "true" : "false");
			}

			if (keyStore.getReadOnly() != null) {
				this.setProperty("com.ibm.ssl.keyStoreReadOnly", keyStore.getReadOnly() ? "true" : "false");
			}

			if (keyStoreType != null && (keyStoreType.equals("JCERACFKS") || keyStoreType.equals("JCECCARACFKS"))
					&& keyStoreLocation != null && keyStoreLocation.startsWith("safkeyring:///")) {
				this.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
			}

			if (keyStore.getInitializeAtStartup() != null) {
				this.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup",
						keyStore.getInitializeAtStartup() ? "true" : "false");
			}

			if (keyStore.getStashFile() != null) {
				this.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", keyStore.getStashFile() ? "true" : "false");
			}

			if (keyStore.getAccelerator() != null) {
				this.setProperty("com.ibm.ssl.keyStoreUseForAcceleration",
						keyStore.getAccelerator() ? "true" : "false");
			}

			List<?> otherProps = keyStore.getCustomProps();
			if (otherProps != null) {
				Iterator listIterator = otherProps.iterator();

				while (listIterator.hasNext()) {
					DescriptiveProperty prop = (DescriptiveProperty) listIterator.next();
					if (prop != null) {
						this.setProperty(prop.getName(), prop.getValue());
					}
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public WSKeyStore() {
		this.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
		this.setProperty("com.ibm.ssl.keyStoreProvider", "IBMJCE");
		this.setProperty("com.ibm.ssl.keyStoreType", "PKCS12");
		this.setProperty("com.ibm.ssl.keyStoreReadOnly", "false");
		this.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "false");
		this.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "true");
		if (SSLConfigManager.getInstance().isServerProcess()) {
			this.setProperty("com.ibm.ssl.keyStoreScope", ManagementScopeManager.getInstance().getCellScopeName());
		}

	}

	public String getLocation() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getLocation");
		}

		String location = this.getProperty("com.ibm.ssl.keyStore");
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getLocation -> " + location);
		}

		return location;
	}

	public String getManagementScope() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getManagementScope");
		}

		String managementScope = this.getProperty("com.ibm.ssl.keyStoreScope");
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getManagementScope -> " + managementScope);
		}

		return managementScope;
	}

	public synchronized KeyStore do_getKeyStore(boolean reinitialize, boolean createIfNotPresent) throws Exception {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "do_getKeyStore", new Object[]{reinitialize, createIfNotPresent});
      }

      String SSLKeyFile = this.getProperty("com.ibm.ssl.keyStore");
      boolean create = createIfNotPresent;

      try {
         this.ks = (KeyStore)AccessController.doPrivileged(new 1(this, create));
      } catch (PrivilegedActionException var9) {
         Exception ex = var9.getException();
         String ksType = this.getProperty("com.ibm.ssl.keyStoreType");
         boolean ksReadOnly = this.getPropertyBool("com.ibm.ssl.keyStoreReadOnly");
         if (ksType.equals("JCERACFKS") || ksType.equals("JCECCARACFKS") || ksType.equals("JCEHYBRIDRACFKS") && ksReadOnly) {
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Cannot open keystore URL and since this is a RACFKS, we will return null: ", new Object[]{ex});
            }

            return null;
         }

         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Cannot open keystore URL: " + SSLKeyFile, new Object[]{ex});
         }

         Manager.Ffdc.log(ex, this, "com.ibm.ws.ssl.config.WSKeyStore.getKeyStore", "844", new Object[]{this});
         Tr.error(tc, "ssl.keystore.load.error.CWPKI0033E", new Object[]{SSLKeyFile, ex.getMessage()});
         throw ex;
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "do_getKeyStore (from cache)");
      }

      return this.ks;
   }

	public boolean getPropertyBool(String name) {
		return Boolean.valueOf(this.getProperty(name));
	}

	public KeyStore getKeyStore(boolean reinitialize, boolean createIfNotPresent) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getKeyStore", new Object[]{reinitialize, createIfNotPresent});
		}

		if (this.ks == null || reinitialize) {
			this.ks = this.do_getKeyStore(reinitialize, createIfNotPresent);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getKeyStore (from cache)");
		}

		return this.ks;
	}

	protected KeyStore getNonExistingKeyStore(boolean create, String name, String SSLKeyPassword,
			String SSLKeyStoreType, String SSLKeyStoreProvider, String SSLKeyStoreStash, String keyStoreLocation)
			throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException,
			InstantiationException, KeyStoreException, NoSuchProviderException, IOException, NoSuchAlgorithmException,
			CertificateException, SSLException {
		KeyStore ks;
		if (create && KeyStoreTypeHelper.isCMSKeyStore(SSLKeyStoreType)) {
			ks = this.loadKeyStoreWithCMSKeyStoreUtility(SSLKeyPassword, SSLKeyStoreType, SSLKeyStoreProvider,
					SSLKeyStoreStash, keyStoreLocation);
		} else {
			if (!create && !this.isSpecialCaseKeyStore(name)) {
				throw new SSLException("KeyStore \"" + keyStoreLocation + "\" does not exist.");
			}

			ks = this.loadKeyStoreWithJSSEProvider(SSLKeyPassword, SSLKeyStoreType, SSLKeyStoreProvider);
		}

		return ks;
	}

	boolean isSpecialCaseKeyStore(String name) {
		return name != null && (name.endsWith("DefaultKeyStore") || name.endsWith("DefaultTrustStore")
				|| name.endsWith("DefaultRootStore") || name.endsWith("DefaultDeletedStore")
				|| name.endsWith("DefaultSignersStore") || name.endsWith("LTPAKeys"));
	}

	KeyStore loadKeyStoreWithJSSEProvider(String SSLKeyPassword, String SSLKeyStoreType, String SSLKeyStoreProvider)
			throws KeyStoreException, NoSuchProviderException, IOException, NoSuchAlgorithmException,
			CertificateException {
		JSSEProvider jsseProvider = JSSEProviderFactory.getInstance();
		KeyStore ks = jsseProvider.getKeyStoreInstance(SSLKeyStoreType, SSLKeyStoreProvider);
		ks.load((InputStream) null, SSLKeyPassword.toCharArray());
		return ks;
	}

	KeyStore loadKeyStoreWithCMSKeyStoreUtility(String SSLKeyPassword, String SSLKeyStoreType,
			String SSLKeyStoreProvider, String SSLKeyStoreStash, String keyStoreLocation) throws ClassNotFoundException,
			NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
		Class<?> cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
		Method theMethod1 = cl1.getMethod("loadCMSKeyStore", File.class, String.class, String.class, String.class,
				String.class, String.class);
		KeyStore ks = (KeyStore) theMethod1.invoke(cl1.newInstance(), null, keyStoreLocation, SSLKeyPassword,
				SSLKeyStoreType, SSLKeyStoreProvider, SSLKeyStoreStash);
		this.removeCMSKeystoreSigners(ks);
		return ks;
	}

	public void store(String password) throws Exception {
		if (password != null) {
			this.setProperty("com.ibm.ssl.keyStorePassword", password);
		}

		this.store();
	}

	public void store() throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "store");
		}

		try {
			String name = this.getProperty("com.ibm.ssl.keyStoreName");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Storing KeyStore " + name);
			}

			String SSLKeyFile = this.getProperty("com.ibm.ssl.keyStore");
			String SSLKeyPassword = this.getProperty("com.ibm.ssl.keyStorePassword");
			String SSLKeyStoreType = this.getProperty("com.ibm.ssl.keyStoreType");
			String SSLKeyStoreReadOnly = this.getProperty("com.ibm.ssl.keyStoreReadOnly");
			boolean readOnly = SSLKeyStoreReadOnly != null && SSLKeyStoreReadOnly.equals("true");
			String SSLKeyStoreFileBased = this.getProperty("com.ibm.ssl.keyStoreFileBased");
			boolean fileBased = SSLKeyStoreFileBased != null && SSLKeyStoreFileBased.equals("true");
			String SSLKeyStoreStash = this.getProperty("com.ibm.ssl.keyStoreCreateCMSStash");
			KeyStore ks = this.getKeyStore(false, false);
			if (ks != null && !readOnly) {
				if (fileBased && KeyStoreTypeHelper.isCMSKeyStore(SSLKeyStoreType)) {
					Tr.debug(tc, "Storing filebased keystore type " + SSLKeyStoreType);
					Class<?> cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
					Method theMethod1 = cl1.getMethod("storeCMSKeyStore", KeyStore.class, String.class, String.class,
							String.class, String.class);
					theMethod1.invoke(cl1.newInstance(), ks, SSLKeyFile, SSLKeyPassword, SSLKeyStoreType,
							SSLKeyStoreStash);
				} else {
					String keyStoreLocation;
					String keyStorePassword;
					if (fileBased) {
						Tr.debug(tc, "Storing filebased keystore type " + SSLKeyStoreType);
						keyStoreLocation = this.getProperty("com.ibm.ssl.keyStore");
						keyStorePassword = this.getProperty("com.ibm.ssl.keyStorePassword");
						FileOutputStream fos = new FileOutputStream(keyStoreLocation);
						ks.store(fos, keyStorePassword.toCharArray());
						if (fos != null) {
							fos.close();
						}
					} else {
						Tr.debug(tc, "Storing non-filebased keystore type " + SSLKeyStoreType);
						keyStoreLocation = this.getProperty("com.ibm.ssl.keyStore");
						keyStorePassword = this.getProperty("com.ibm.ssl.keyStorePassword");
						URL ring = new URL(keyStoreLocation);
						URLConnection ringConnect = ring.openConnection();
						OutputStream fos = ringConnect.getOutputStream();
						ks.store(fos, keyStorePassword.toCharArray());
						if (fos != null) {
							fos.close();
						}
					}
				}
			}

			PlatformHelper ph = PlatformHelperFactory.getPlatformHelper();
			if (ph.isOS400()) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "OS400 changing file authority for " + SSLKeyFile);
				}

				try {
					String[] command = new String[]{"system", "CHGAUT", "OBJ('" + SSLKeyFile + "')", "USER(*PUBLIC)",
							"DTAAUT(*RX)", "OBJAUT(*NONE)"};
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Command to execute on OS400 " + command);
					}

					Runtime.getRuntime().exec(command);
				} catch (Exception var16) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception during file authority setting on OS400", new Object[]{var16});
					}
				}
			}
		} catch (Exception var17) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception storing KeyStore.", new Object[]{var17});
			}

			Manager.Ffdc.log(var17, this, "com.ibm.ws.ssl.config.WSKeyStore.store", "968", new Object[]{this});
			throw var17;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "store");
		}

	}

	public void initializeKeyStore(boolean reinitialize) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeKeyStore");
		}

		try {
			String initAtStartup = this.getProperty("com.ibm.ssl.keyStoreInitializeAtStartup");
			if (initAtStartup != null && initAtStartup.equals("true")) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Initializing keystore at startup.");
				}

				this.getKeyStore(reinitialize, false);
			}
		} catch (Exception var3) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception initializing KeyStore.", new Object[]{var3});
			}

			Manager.Ffdc.log(var3, this, "com.ibm.ws.ssl.config.WSKeyStore.initializeKeyStore", "992",
					new Object[]{this});
			throw var3;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initializeKeyStore");
		}

	}

	public void provideExpirationWarnings(int daysBeforeExpireWarning, String keyStoreName) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "provideExpirationWarnings", new Integer(daysBeforeExpireWarning));
		}

		KeyStore keystore = this.getKeyStore(false, false);
		if (keystore != null) {
			try {
				Enumeration<String> e = keystore.aliases();
				if (e != null) {
					label48 : while (true) {
						String alias;
						Certificate[] cert_chain;
						do {
							do {
								if (!e.hasMoreElements()) {
									break label48;
								}

								alias = (String) e.nextElement();
							} while (alias == null);

							cert_chain = (Certificate[]) keystore.getCertificateChain(alias);
						} while (cert_chain == null);

						for (int i = 0; i < cert_chain.length; ++i) {
							this.printWarning(daysBeforeExpireWarning, keyStoreName, alias,
									(X509Certificate) cert_chain[i]);
						}
					}
				}
			} catch (Exception var8) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception validating KeyStore expirations.", new Object[]{var8});
				}

				Manager.Ffdc.log(var8, this, "com.ibm.ws.ssl.config.WSKeyStore.provideExpirationWarnings", "1036",
						new Object[]{this});
				throw var8;
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "provideExpirationWarnings");
		}

	}

	public void printWarning(int daysBeforeExpireWarning, String keyStoreName, String alias, X509Certificate cert) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "printWarning", new Object[]{new Integer(daysBeforeExpireWarning), keyStoreName, alias});
		}

		try {
			long millisDelta = (long) daysBeforeExpireWarning * 24L * 60L * 60L * 1000L;
			long millisBeforeExpiration = cert.getNotAfter().getTime() - System.currentTimeMillis();
			long daysLeft = millisBeforeExpiration / 1000L / 60L / 60L / 24L;
			if (cert != null && millisBeforeExpiration < 0L) {
				Tr.error(tc, "ssl.expiration.expired.CWPKI0017E", new Object[]{alias, keyStoreName});
			} else if (cert != null && millisBeforeExpiration < millisDelta) {
				Tr.warning(tc, "ssl.expiration.warning.CWPKI0016E",
						new Object[]{alias, keyStoreName, new Long(daysLeft)});
			} else if (tc.isDebugEnabled()) {
				Tr.debug(tc, "The certificate with alias " + alias + " from keyStore " + keyStoreName + " has "
						+ daysLeft + " days left before expiring.");
			}
		} catch (Exception var11) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception reading KeyStore certificates during expiration check.", new Object[]{var11});
			}

			Manager.Ffdc.log(var11, this, "com.ibm.ws.ssl.config.WSKeyStore.printWarning", "1073", new Object[]{this});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "printWarning");
		}

	}

	public static InputStream openKeyStore(String fileName) throws MalformedURLException, IOException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "openKeyStore", fileName);
		}

		InputStream fis = null;
		URL urlFile = null;
		File kfile = new File(fileName);
		if (kfile.exists() && kfile.length() == 0L) {
			throw new IOException("Keystore file exists, but is empty: " + fileName);
		} else {
			if (!kfile.exists()) {
				urlFile = new URL(fileName);
			} else {
				urlFile = new URL("file:" + kfile.getCanonicalPath());
			}

			fis = urlFile.openStream();
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "openKeyStore");
			}

			return fis;
		}
	}

	public static ArrayList<String> getKeyStoreTypes() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getKeyStoreTypes");
		}

		ArrayList<String> keyStoreTypes = new ArrayList(Security.getAlgorithms("KeyStore"));
		int e = keyStoreTypes.indexOf("IBMCMSKS");
		if (e >= 0) {
			keyStoreTypes.set(e, "CMSKS");
		}

		e = keyStoreTypes.indexOf("CASEEXACTJKS");
		if (e != -1) {
			keyStoreTypes.remove(e);
		}

		e = keyStoreTypes.indexOf("PKCS12S2");
		if (e != -1) {
			keyStoreTypes.remove(e);
		}

		e = keyStoreTypes.indexOf("PKCS12JARSIGNER");
		if (e != -1) {
			keyStoreTypes.remove(e);
		}

		e = keyStoreTypes.indexOf("PKCS12JarSigner");
		if (e != -1) {
			keyStoreTypes.remove(e);
		}

		e = keyStoreTypes.indexOf("JCA4758KS");
		if (e != -1) {
			keyStoreTypes.remove(e);
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "keyStoreTypes: " + keyStoreTypes);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getKeyStoreTypes");
		}

		return keyStoreTypes;
	}

	public String toString() {
		Enumeration<?> e = this.propertyNames();
		StringBuffer buf = new StringBuffer();
		buf.append("WSKeyStore.toString() {");

		while (e.hasMoreElements()) {
			String name = (String) e.nextElement();
			String value = this.getProperty(name);
			if (name.toLowerCase().indexOf("password") != -1) {
				buf.append(name);
				buf.append(" = ");
				buf.append(SSLConfigManager.mask(value));
				buf.append("\n");
			} else {
				buf.append(name);
				buf.append(" = ");
				buf.append(value);
				buf.append("\n");
			}
		}

		buf.append("}");
		return buf.toString();
	}

	public Object[] invokeKeyStoreCommand(String method, Object[] parms) throws KeyException {
		return this.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
	}

	public Object[] invokeKeyStoreCommand(String method, Object[] parms, Boolean createIfNotPresent)
			throws KeyException {
		if (tc.isEntryEnabled()) {
			if (!this.includePassword(method, parms)) {
				Tr.entry(tc, "invokeKeyStoreCommand", new Object[]{method, this.printParms(parms)});
			} else if (parms != null) {
				Tr.entry(tc, "invokeKeyStoreCommand", new Object[]{method, "Number of parameters:" + parms.length});
			} else {
				Tr.entry(tc, "invokeKeyStoreCommand", new Object[]{method, "No parameters"});
			}
		}

		try {
			String keyStoreLocation = this.getProperty("com.ibm.ssl.keyStore");
			boolean ksReadOnly = this.getPropertyBool("com.ibm.ssl.keyStoreReadOnly");
			String ksType = this.getProperty("com.ibm.ssl.keyStoreType");
			KeyStore jKeyStore = null;
			if ((ksType.equals("JCERACFKS") || ksType.equals("JCECCARACFKS") || ksType.equals("JCEHYBRIDRACFKS"))
					&& !ksReadOnly) {
				jKeyStore = this.getKeyStore(true, createIfNotPresent);
			} else {
				jKeyStore = this.getKeyStore(false, createIfNotPresent);
			}

			if (jKeyStore == null) {
				if ((ksType.equals("JCERACFKS") || ksType.equals("JCECCARACFKS") || ksType.equals("JCEHYBRIDRACFKS"))
						&& ksReadOnly) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Suppressing Exception since KS type is RACF. Trying another CR/SR."
								+ keyStoreLocation);
					}

					return method.equals("isKeyEntry") | method.equals("isCertificateEntry")
							| method.equals("containsAlias") ? new Object[]{new Boolean(Boolean.FALSE)} : null;
				} else {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Cannot load the Java keystore at location \"" + keyStoreLocation
								+ "\" on the local node.");
					}

					throw new KeyException("Cannot load the Java keystore at location \"" + keyStoreLocation
							+ "\" on the local node.");
				}
			} else {
				Enumeration aliases;
				if (method.equals("aliases")) {
					List<String> aliasList = new ArrayList();
					aliases = jKeyStore.aliases();

					while (aliases.hasMoreElements()) {
						aliasList.add(aliases.nextElement());
					}

					String[] aliasArray = (String[]) aliasList.toArray(new String[aliasList.size()]);
					return (Object[]) aliasArray;
				} else {
					String host;
					boolean exists;
					if (method.equals("containsAlias")) {
						if (parms != null && parms.length == 1) {
							host = (String) parms[0];
							exists = jKeyStore.containsAlias(host);
							return new Object[]{new Boolean(exists)};
						} else {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Invalid parameters for the KeyStore method.",
										new Object[]{this.printParms(parms)});
							}

							throw new KeyException(
									"Invalid parameters for the KeyStore method: " + this.printParms(parms));
						}
					} else if (method.equals("deleteEntry")) {
						if (parms != null && parms.length == 1) {
							host = (String) parms[0];
							jKeyStore.deleteEntry(host);
							this.store();
							return null;
						} else {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Invalid parameters for the KeyStore method.",
										new Object[]{this.printParms(parms)});
							}

							throw new KeyException(
									"Invalid parameters for the KeyStore method: " + this.printParms(parms));
						}
					} else {
						Certificate cert;
						if (method.equals("getCertificate")) {
							if (parms != null && parms.length == 1) {
								host = (String) parms[0];
								cert = jKeyStore.getCertificate(host);
								return new Object[]{cert};
							} else {
								if (tc.isDebugEnabled()) {
									Tr.debug(tc, "Invalid parameters for the KeyStore method.",
											new Object[]{this.printParms(parms)});
								}

								throw new KeyException(
										"Invalid parameters for the KeyStore method: " + this.printParms(parms));
							}
						} else {
							Certificate cert;
							String type;
							if (method.equals("getCertificateAlias")) {
								if (parms != null && parms.length == 1) {
									cert = (Certificate) parms[0];
									type = jKeyStore.getCertificateAlias(cert);
									return new Object[]{type};
								} else {
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Invalid parameters for the KeyStore method.",
												new Object[]{this.printParms(parms)});
									}

									throw new KeyException(
											"Invalid parameters for the KeyStore method: " + this.printParms(parms));
								}
							} else if (method.equals("getCertificateChain")) {
								if (parms != null && parms.length == 1) {
									host = (String) parms[0];
									Certificate[] certChain = jKeyStore.getCertificateChain(host);
									return new Object[]{certChain};
								} else {
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Invalid parameters for the KeyStore method.",
												new Object[]{this.printParms(parms)});
									}

									throw new KeyException(
											"Invalid parameters for the KeyStore method: " + this.printParms(parms));
								}
							} else if (method.equals("getCreationDate")) {
								if (parms != null && parms.length == 1) {
									host = (String) parms[0];
									Date creationDate = jKeyStore.getCreationDate(host);
									return new Object[]{creationDate};
								} else {
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Invalid parameters for the KeyStore method.",
												new Object[]{this.printParms(parms)});
									}

									throw new KeyException(
											"Invalid parameters for the KeyStore method: " + this.printParms(parms));
								}
							} else if (method.equals("getDefaultType")) {
								host = KeyStore.getDefaultType();
								return new Object[]{host};
							} else if (method.equals("getKey")) {
								if (parms != null && parms.length == 2) {
									host = (String) parms[0];
									char[] password = (char[]) ((char[]) parms[1]);
									Key key = jKeyStore.getKey(host, password);
									return new Object[]{key};
								} else {
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Invalid parameters for the KeyStore method. Number of parms:",
												parms.length);
									}

									throw new KeyException(
											"Invalid parameters for the KeyStore method. Number of parms: "
													+ parms.length);
								}
							} else if (method.equals("getProvider")) {
								Provider provider = jKeyStore.getProvider();
								return new Object[]{provider};
							} else if (method.equals("getType")) {
								host = jKeyStore.getType();
								return new Object[]{host};
							} else if (method.equals("isCertificateEntry")) {
								if (parms != null && parms.length == 1) {
									host = (String) parms[0];
									exists = jKeyStore.isCertificateEntry(host);
									return new Object[]{new Boolean(exists)};
								} else {
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Invalid parameters for the KeyStore method.",
												new Object[]{this.printParms(parms)});
									}

									throw new KeyException(
											"Invalid parameters for the KeyStore method: " + this.printParms(parms));
								}
							} else if (method.equals("isKeyEntry")) {
								if (parms != null && parms.length == 1) {
									host = (String) parms[0];
									exists = jKeyStore.isKeyEntry(host);
									return new Object[]{new Boolean(exists)};
								} else {
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Invalid parameters for the KeyStore method.",
												new Object[]{this.printParms(parms)});
									}

									throw new KeyException(
											"Invalid parameters for the KeyStore method: " + this.printParms(parms));
								}
							} else {
								String alias;
								String alias;
								KeyStore ks;
								boolean exists;
								if (method.equals("setCertificateEntry")) {
									if (parms != null && parms.length == 2) {
										host = (String) parms[0];
										cert = (Certificate) parms[1];
										alias = host;
										exists = KeyStoreManager.getInstance().checkIfSignerAlreadyExistsInTrustStore(
												(X509Certificate) cert, jKeyStore);
										if (exists) {
											alias = jKeyStore.getCertificateAlias(cert);
										}

										if (!exists && !jKeyStore.containsAlias(host)) {
											if (tc.isDebugEnabled()) {
												Tr.debug(tc, "Adding alias \"" + host + "\" to keystore.");
											}

											jKeyStore.setCertificateEntry(host, cert);
										} else if (!exists) {
											alias = CertificateManager.getInstance().incrementAlias(jKeyStore, host);
											if (tc.isDebugEnabled()) {
												Tr.debug(tc, "Adding alias \"" + alias + "\" to keystore.");
											}

											if (!jKeyStore.containsAlias(alias)) {
												jKeyStore.setCertificateEntry(alias, cert);
												alias = alias;
											}
										}

										try {
											this.store();
										} catch (IOException var32) {
											if (!this.getProperty("com.ibm.ssl.keyStoreType").equals("JCERACFKS")
													&& !this.getProperty("com.ibm.ssl.keyStoreType")
															.equals("JCECCARACFKS")
													&& !this.getProperty("com.ibm.ssl.keyStoreType")
															.equals("JCEHYBRIDRACFKS")) {
												throw var32;
											}

											ks = this.getKeyStore(true, false);
											if (KeyStoreManager.getInstance().checkIfSignerAlreadyExistsInTrustStore(
													(X509Certificate) cert, ks)) {
												Tr.debug(tc,
														"Certificate already exists in RACF: " + var32.getMessage());
												return new Object[]{ks.getCertificateAlias(cert)};
											}

											throw var32;
										}

										return new Object[]{alias};
									} else {
										if (tc.isDebugEnabled()) {
											Tr.debug(tc, "Invalid parameters for the KeyStore method.",
													new Object[]{this.printParms(parms)});
										}

										throw new KeyException("Invalid parameters for the KeyStore method: "
												+ this.printParms(parms));
									}
								} else if (method.equals("setCertificateEntryOverwrite")) {
									if (parms != null && parms.length == 2) {
										host = (String) parms[0];
										cert = (Certificate) parms[1];
										alias = host;
										exists = KeyStoreManager.getInstance().checkIfSignerAlreadyExistsInTrustStore(
												(X509Certificate) cert, jKeyStore);
										if (exists) {
											alias = jKeyStore.getCertificateAlias(cert);
										}

										if (!exists) {
											if (tc.isDebugEnabled()) {
												Tr.debug(tc, "Adding alias \"" + host + "\" to keystore.");
											}

											jKeyStore.setCertificateEntry(host, cert);
										}

										try {
											this.store();
										} catch (IOException var36) {
											if (!this.getProperty("com.ibm.ssl.keyStoreType").equals("JCERACFKS")
													&& !this.getProperty("com.ibm.ssl.keyStoreType")
															.equals("JCECCARACFKS")
													&& !this.getProperty("com.ibm.ssl.keyStoreType")
															.equals("JCEHYBRIDRACFKS")) {
												throw var36;
											}

											ks = this.getKeyStore(true, false);
											if (KeyStoreManager.getInstance().checkIfSignerAlreadyExistsInTrustStore(
													(X509Certificate) cert, ks)) {
												Tr.debug(tc,
														"Certificate already exists in RACF: " + var36.getMessage());
												return new Object[]{ks.getCertificateAlias(cert)};
											}

											throw var36;
										}

										return new Object[]{alias};
									} else {
										if (tc.isDebugEnabled()) {
											Tr.debug(tc, "Invalid parameters for the KeyStore method.",
													new Object[]{this.printParms(parms)});
										}

										throw new KeyException("Invalid parameters for the KeyStore method: "
												+ this.printParms(parms));
									}
								} else {
									String alias;
									byte[] key;
									Certificate[] certChain;
									if (method.equals("setKeyEntry") && parms != null && parms.length == 3) {
										if (parms != null && parms.length == 3) {
											host = (String) parms[0];
											key = (byte[]) ((byte[]) parms[1]);
											certChain = (Certificate[]) ((Certificate[]) parms[2]);
											alias = null;
											if (!jKeyStore.containsAlias(host)) {
												if (tc.isDebugEnabled()) {
													Tr.debug(tc, "Adding alias \"" + host + "\" to keystore.");
												}

												jKeyStore.setKeyEntry(host, key, certChain);
												alias = host;
											} else {
												alias = CertificateManager.getInstance().incrementAlias(jKeyStore,
														host);
												if (tc.isDebugEnabled()) {
													Tr.debug(tc, "Adding alias \"" + alias + "\" to keystore.");
												}

												if (!jKeyStore.containsAlias(alias)) {
													jKeyStore.setKeyEntry(alias, key, certChain);
													alias = alias;
												}
											}

											try {
												this.store();
											} catch (IOException var33) {
												if (!this.getProperty("com.ibm.ssl.keyStoreType").equals("JCERACFKS")
														&& !this.getProperty("com.ibm.ssl.keyStoreType")
																.equals("JCECCARACFKS")) {
													throw var33;
												}

												ks = this.getKeyStore(true, false);
												if (KeyStoreManager.getInstance()
														.checkIfSignerAlreadyExistsInTrustStore(
																(X509Certificate) certChain[0], ks)) {
													Tr.debug(tc, "Certificate already exists in RACF: "
															+ var33.getMessage());
													return new Object[]{ks.getCertificateAlias(certChain[0])};
												}

												throw var33;
											}

											return new Object[]{alias};
										} else {
											if (tc.isDebugEnabled()) {
												Tr.debug(tc, "Invalid parameters for the KeyStore method.",
														new Object[]{this.printParms(parms)});
											}

											throw new KeyException("Invalid parameters for the KeyStore method: "
													+ this.printParms(parms));
										}
									} else {
										char[] password;
										Certificate[] cert;
										Key key;
										if (method.equals("setKeyEntry") && parms != null && parms.length == 4) {
											if (parms != null && parms.length == 4) {
												host = (String) parms[0];
												key = (Key) parms[1];
												password = (char[]) ((char[]) parms[2]);
												cert = (Certificate[]) ((Certificate[]) parms[3]);
												alias = null;
												if (!jKeyStore.containsAlias(host)) {
													if (tc.isDebugEnabled()) {
														Tr.debug(tc, "Adding alias \"" + host + "\" to keystore.");
													}

													jKeyStore.setKeyEntry(host, key, password, cert);
													alias = host;
												} else {
													String newAlias = CertificateManager.getInstance()
															.incrementAlias(jKeyStore, host);
													if (tc.isDebugEnabled()) {
														Tr.debug(tc, "Adding alias \"" + newAlias + "\" to keystore.");
													}

													if (!jKeyStore.containsAlias(newAlias)) {
														jKeyStore.setKeyEntry(newAlias, key, password, cert);
														alias = newAlias;
													}
												}

												try {
													this.store();
												} catch (IOException var37) {
													if (!this.getProperty("com.ibm.ssl.keyStoreType")
															.equals("JCERACFKS")
															&& !this.getProperty("com.ibm.ssl.keyStoreType")
																	.equals("JCECCARACFKS")) {
														throw var37;
													}

													this.getKeyStore(true, false);
													if (KeyStoreManager.getInstance()
															.checkIfSignerAlreadyExistsInTrustStore(
																	(X509Certificate) cert[0], this.ks)) {
														Tr.debug(tc, "Certificate already exists in SAF: "
																+ var37.getMessage());
														return new Object[]{this.ks.getCertificateAlias(cert[0])};
													}

													throw var37;
												}

												return new Object[]{alias};
											} else {
												if (tc.isDebugEnabled()) {
													Tr.debug(tc,
															"Invalid parameters for the KeyStore method. Number of parms:",
															parms.length);
												}

												throw new KeyException(
														"Invalid parameters for the KeyStore method. Number of parms: "
																+ parms.length);
											}
										} else {
											Certificate cert;
											if (method.equals("setKeyEntryOverwrite") && parms != null
													&& parms.length == 3) {
												if (parms != null && parms.length == 3) {
													host = (String) parms[0];
													key = (byte[]) ((byte[]) parms[1]);
													certChain = (Certificate[]) ((Certificate[]) parms[2]);
													cert = null;
													if (tc.isDebugEnabled()) {
														Tr.debug(tc, "Adding alias \"" + host + "\" to keystore.");
													}

													jKeyStore.setKeyEntry(host, key, certChain);

													try {
														this.store();
													} catch (IOException var35) {
														if (!this.getProperty("com.ibm.ssl.keyStoreType")
																.equals("JCERACFKS")
																&& !this.getProperty("com.ibm.ssl.keyStoreType")
																		.equals("JCECCARACFKS")) {
															throw var35;
														}

														ks = this.getKeyStore(true, false);
														if (KeyStoreManager.getInstance()
																.checkIfSignerAlreadyExistsInTrustStore(
																		(X509Certificate) certChain[0], ks)) {
															Tr.debug(tc, "Certificate already exists in SAF: "
																	+ var35.getMessage());
															return new Object[]{ks.getCertificateAlias(certChain[0])};
														}

														throw var35;
													}

													return new Object[]{host};
												} else {
													if (tc.isDebugEnabled()) {
														Tr.debug(tc, "Invalid parameters for the KeyStore method.",
																new Object[]{this.printParms(parms)});
													}

													throw new KeyException(
															"Invalid parameters for the KeyStore method: "
																	+ this.printParms(parms));
												}
											} else {
												SSLContext context;
												KeyStore ks;
												if (method.equals("setKeyEntryOverwrite") && parms != null
														&& parms.length == 4) {
													if (parms != null && parms.length == 4) {
														host = (String) parms[0];
														key = (Key) parms[1];
														password = (char[]) ((char[]) parms[2]);
														cert = (Certificate[]) ((Certificate[]) parms[3]);
														context = null;
														if (tc.isDebugEnabled()) {
															Tr.debug(tc, "Adding alias \"" + host + "\" to keystore.");
														}

														jKeyStore.setKeyEntry(host, key, password, cert);

														try {
															this.store();
														} catch (IOException var31) {
															if (!this.getProperty("com.ibm.ssl.keyStoreType")
																	.equals("JCERACFKS")
																	&& !this.getProperty("com.ibm.ssl.keyStoreType")
																			.equals("JCECCARACFKS")) {
																throw var31;
															}

															ks = this.getKeyStore(true, false);
															if (KeyStoreManager.getInstance()
																	.checkIfSignerAlreadyExistsInTrustStore(
																			(X509Certificate) cert[0], ks)) {
																Tr.debug(tc, "Certificate already exists in SAF: "
																		+ var31.getMessage());
																return new Object[]{ks.getCertificateAlias(cert[0])};
															}

															throw var31;
														}

														return new Object[]{host};
													} else {
														if (tc.isDebugEnabled()) {
															Tr.debug(tc,
																	"Invalid parameters for the KeyStore method. Number of parms:",
																	parms.length);
														}

														throw new KeyException(
																"Invalid parameters for the KeyStore method. Number of parms: "
																		+ parms.length);
													}
												} else if (method.equals("size")) {
													int size = jKeyStore.size();
													return new Object[]{new Integer(size)};
												} else {
													KeyStoreInfo ksInfo;
													if ((method.equals("personalCertificateExtract")
															|| method.equals("signerCertificateExtract"))
															&& parms != null && parms.length == 4) {
														if (parms != null && parms.length == 4) {
															ksInfo = (KeyStoreInfo) parms[0];
															type = (String) parms[1];
															alias = (String) parms[2];
															Boolean ascii = (Boolean) parms[3];
															WSKeyStore wsks = new WSKeyStore(ksInfo);
															ks = wsks.getKeyStore(false, false);
															FileOutputStream fos = new FileOutputStream(type);
															KeyStoreUtil.exportCertificate(fos, ks, alias, ascii);
															if (fos != null) {
																fos.close();
															}

															return null;
														} else {
															if (tc.isDebugEnabled()) {
																Tr.debug(tc,
																		"Invalid parameters for the KeyStore method.",
																		new Object[]{this.printParms(parms)});
															}

															throw new KeyException(
																	"Invalid parameters for the KeyStore method: "
																			+ this.printParms(parms));
														}
													} else {
														KeyStore ks;
														if (method.equals("receiveCertificate") && parms != null
																&& parms.length == 3) {
															if (parms != null && parms.length == 3) {
																ksInfo = (KeyStoreInfo) parms[0];
																type = (String) parms[1];
																alias = (String) parms[2];
																WSKeyStore wsks = new WSKeyStore(ksInfo);
																ks = wsks.getKeyStore(false, false);
																FileInputStream fis = new FileInputStream(type);
																X509Certificate certificate = null;
																if (this.getProperty("com.ibm.ssl.keyStoreType")
																		.equals("JCERACFKS")
																		|| this.getProperty("com.ibm.ssl.keyStoreType")
																				.equals("JCECCARACFKS")) {
																	CertificateFactory certificatefactory = CertificateFactory
																			.getInstance("X509");
																	certificate = (X509Certificate) certificatefactory
																			.generateCertificate(fis);
																}

																if (fis != null) {
																	fis.close();
																}

																fis = new FileInputStream(type);
																KeyStoreUtil.importCertificate(fis, ks, alias);
																if (fis != null) {
																	fis.close();
																}

																try {
																	wsks.store();
																} catch (IOException var34) {
																	if (!this.getProperty("com.ibm.ssl.keyStoreType")
																			.equals("JCERACFKS")
																			&& !this.getProperty(
																					"com.ibm.ssl.keyStoreType")
																					.equals("JCECCARACFKS")) {
																		throw var34;
																	}

																	ks = wsks.getKeyStore(true, false);
																	if (KeyStoreManager.getInstance()
																			.checkIfSignerAlreadyExistsInTrustStore(
																					certificate, ks)) {
																		Tr.debug(tc,
																				"Certificate already exists in SAF: "
																						+ var34.getMessage());
																		return new Object[]{
																				ks.getCertificateAlias(certificate)};
																	}

																	throw var34;
																}

																return new Object[]{alias};
															} else {
																if (tc.isDebugEnabled()) {
																	Tr.debug(tc,
																			"Invalid parameters for the KeyStore method.",
																			new Object[]{this.printParms(parms)});
																}

																throw new KeyException(
																		"Invalid parameters for the KeyStore method: "
																				+ this.printParms(parms));
															}
														} else if (method
																.equals("getCertificateChainFromUnManagedKeyStore")
																&& parms != null && parms.length == 4) {
															if (parms != null && parms.length == 4) {
																host = (String) parms[0];
																type = (String) parms[1];
																password = (char[]) ((char[]) parms[2]);
																alias = (String) parms[3];
																ks = loadKeyStore(host, type, new String(password));
																Certificate[] certChain = ks.getCertificateChain(alias);
																if (tc.isEntryEnabled()) {
																	Tr.exit(tc, "invokeKeyStoreCommand (success)");
																}

																return new Object[]{certChain};
															} else {
																if (tc.isDebugEnabled()) {
																	Tr.debug(tc,
																			"Invalid parameters for the KeyStore method. Number of parms:",
																			parms.length);
																}

																throw new KeyException(
																		"Invalid parameters for the KeyStore method. Number of parms: "
																				+ parms.length);
															}
														} else {
															Key privateKey;
															if (method.equals("getKeyFromUnManagedKeyStore")
																	&& parms != null && parms.length == 4) {
																if (parms != null && parms.length == 4) {
																	host = (String) parms[0];
																	type = (String) parms[1];
																	password = (char[]) ((char[]) parms[2]);
																	alias = (String) parms[3];
																	ks = loadKeyStore(host, type, new String(password));
																	privateKey = ks.getKey(alias, password);
																	if (tc.isEntryEnabled()) {
																		Tr.exit(tc, "invokeKeyStoreCommand (success)");
																	}

																	return new Object[]{privateKey};
																} else {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Invalid parameters for the KeyStore method. Number of parms:",
																				parms.length);
																	}

																	throw new KeyException(
																			"Invalid parameters for the KeyStore method. Number of parms: "
																					+ parms.length);
																}
															} else if (method
																	.equals("containsAliasFromUnManagedKeyStore")
																	&& parms != null && parms.length == 4) {
																KeyStore ks = null;
																if (parms != null && parms.length == 4) {
																	type = (String) parms[0];
																	alias = (String) parms[1];
																	char[] password = (char[]) ((char[]) parms[2]);
																	alias = (String) parms[3];

																	try {
																		ks = loadKeyStore(type, alias,
																				new String(password));
																	} catch (Exception var38) {
																		Throwable cause;
																		for (cause = new Throwable(
																				var38.getCause()); cause
																						.getCause() != null; cause = cause
																								.getCause()) {
																			;
																		}

																		if (cause.toString().indexOf(
																				"FileNotFoundException") == -1) {
																			throw var38;
																		}

																		if (createIfNotPresent
																				&& alias.equals("CMSKS")) {
																			String SSLKeyStoreStash = this.getProperty(
																					"com.ibm.ssl.keyStoreCreateCMSStash");
																			String SSLKeyStoreProvider = "IBMCMSProvider";
																			ks = this
																					.loadKeyStoreWithCMSKeyStoreUtility(
																							new String(password), alias,
																							SSLKeyStoreProvider,
																							SSLKeyStoreStash, type);
																			this.storeKeyStoreWithCMSKeyStoreUtility(ks,
																					new String(password), alias,
																					SSLKeyStoreProvider,
																					SSLKeyStoreStash, type);
																		}
																	}

																	boolean exists = ks.containsAlias(alias);
																	if (tc.isEntryEnabled()) {
																		Tr.exit(tc, "invokeKeyStoreCommand (exists -> "
																				+ exists + ")");
																	}

																	return new Object[]{new Boolean(exists)};
																} else {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Invalid parameters for the KeyStore method. Number of parms:",
																				parms.length);
																	}

																	throw new KeyException(
																			"Invalid parameters for the KeyStore method. Number of parms: "
																					+ parms.length);
																}
															} else if (method.equals("setKeyEntryFromUnManagedKeyStore")
																	&& parms != null && parms.length == 6) {
																if (parms != null && parms.length == 6) {
																	host = (String) parms[0];
																	type = (String) parms[1];
																	password = (char[]) ((char[]) parms[2]);
																	alias = (String) parms[3];
																	Certificate[] certChain = (Certificate[]) ((Certificate[]) parms[4]);
																	privateKey = (Key) parms[5];
																	ks = loadKeyStore(host, type, new String(password));
																	ks.setKeyEntry(alias, privateKey, password,
																			certChain);
																	OutputStream os = new FileOutputStream(host);
																	ks.store(os, password);
																	if (os != null) {
																		os.close();
																	}

																	if (tc.isEntryEnabled()) {
																		Tr.exit(tc, "invokeKeyStoreCommand (success)");
																	}

																	return null;
																} else {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Invalid parameters for the KeyStore method. Number of parms:",
																				parms.length);
																	}

																	throw new KeyException(
																			"Invalid parameters for the KeyStore method. Number of parms: "
																					+ parms.length);
																}
															} else if (method.equals("store")) {
																if (parms != null && parms.length == 1) {
																	host = (String) parms[0];
																	this.store(host);
																	return null;
																} else {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Invalid parameters for the KeyStore method. Number of parms:",
																				parms.length);
																	}

																	throw new KeyException(
																			"Invalid parameters for the KeyStore method. Number of parms: "
																					+ parms.length);
																}
															} else if (method.equals("checkIfSignerAlreadyExists")) {
																if (parms != null && parms.length == 1) {
																	cert = (Certificate) parms[0];
																	exists = KeyStoreManager.getInstance()
																			.checkIfSignerAlreadyExistsInTrustStore(
																					(X509Certificate) cert, jKeyStore);
																	return new Object[]{new Boolean(exists)};
																} else {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Invalid parameters for the KeyStore method.",
																				new Object[]{this.printParms(parms)});
																	}

																	throw new KeyException(
																			"Invalid parameters for the KeyStore method: "
																					+ this.printParms(parms));
																}
															} else if (method.equals("load")) {
																if (parms != null && parms.length == 3) {
																	host = (String) parms[0];
																	type = (String) parms[1];
																	alias = (String) parms[2];
																	loadKeyStore(host, type, new String(alias));
																	if (tc.isEntryEnabled()) {
																		Tr.exit(tc, "invokeKeyStoreCommand (success)");
																	}

																	return null;
																} else {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Invalid parameters for the KeyStore method. Number of parms:",
																				parms.length);
																	}

																	throw new KeyException(
																			"Invalid parameters for the KeyStore method. Number of parms: "
																					+ parms.length);
																}
															} else if (method.equals("reinitializeKeyStore")) {
																if (parms != null) {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Invalid parameters for the KeyStore method.  Method expects no arguments.",
																				new Object[]{this.printParms(parms)});
																	}

																	throw new KeyException(
																			"Invalid parameters for the KeyStore method. Method expects no arguments, arguments supplied: "
																					+ this.printParms(parms));
																} else {
																	this.getKeyStore(true, false);
																	if (tc.isEntryEnabled()) {
																		Tr.exit(tc,
																				"invokeKeyStoreCommand[reinitializeKeyStore] (success)");
																	}

																	return null;
																}
															} else if (method.equals("retrieveSignerFromPort")) {
																if (parms != null && parms.length == 3) {
																	host = (String) parms[0];
																	Integer port = (Integer) parms[1];
																	alias = (String) parms[2];
																	Certificate[] certChain = null;
																	context = JSSEHelper.getInstance().getSSLContext(
																			alias, (Map) null,
																			(SSLConfigChangeListener) null);
																	SSLSocketFactory factory = context
																			.getSocketFactory();

																	try {
																		ThreadManager.getInstance()
																				.setSetSignerOnThread(true);
																		SSLSocket ssl_sock = (SSLSocket) factory
																				.createSocket(host, port);
																		ssl_sock.startHandshake();
																	} catch (Exception var29) {
																		certChain = ThreadManager.getInstance()
																				.getSignerChain();
																		ThreadManager.getInstance().setSignerChain(
																				(X509Certificate[]) null);
																	} finally {
																		ThreadManager.getInstance()
																				.setSetSignerOnThread(false);
																	}

																	if (tc.isEntryEnabled()) {
																		Tr.exit(tc,
																				"invokeKeyStoreCommand[retrieveSigner] (success)");
																	}

																	return certChain;
																} else {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Invalid parameters for the KeyStore method.",
																				new Object[]{this.printParms(parms)});
																	}

																	throw new KeyException(
																			"Invalid parameters for the KeyStore method: "
																					+ this.printParms(parms));
																}
															} else {
																HashMap certList;
																if (method.equals("listPersonalCertificates")) {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Calling listPersonalCertificates");
																	}

																	certList = new HashMap();
																	aliases = jKeyStore.aliases();

																	while (aliases.hasMoreElements()) {
																		alias = (String) aliases.nextElement();
																		if (jKeyStore.isKeyEntry(alias)) {
																			if (tc.isDebugEnabled()) {
																				Tr.debug(tc, "Putting " + alias
																						+ " in the personal certs list");
																			}

																			cert = jKeyStore.getCertificateChain(alias);
																			certList.put(alias, cert);
																		}
																	}

																	return new Object[]{certList};
																} else if (method.equals("listSignerCertificates")) {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc, "Calling listSignerCertificates");
																	}

																	certList = new HashMap();
																	aliases = jKeyStore.aliases();

																	while (aliases.hasMoreElements()) {
																		alias = (String) aliases.nextElement();
																		if (jKeyStore.isCertificateEntry(alias)) {
																			if (tc.isDebugEnabled()) {
																				Tr.debug(tc, "Putting " + alias
																						+ " in the signers list");
																			}

																			cert = jKeyStore.getCertificate(alias);
																			certList.put(alias, cert);
																		}
																	}

																	return new Object[]{certList};
																} else {
																	if (tc.isDebugEnabled()) {
																		Tr.debug(tc,
																				"Invalid or unknown method: " + method);
																	}

																	throw new KeyException(
																			"Invalid or unknown method: " + method);
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception var39) {
			Exception e = var39;
			if (var39.getMessage() == null) {
				e = (Exception) var39.getCause();
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception executing KeyStore method.", new Object[]{e});
			}

			if (!this.iszOSandServant()) {
				callFFDC = true;
				Manager.Ffdc.log(e, this, "com.ibm.ws.ssl.config.WSKeyStore.invokeKeyStoreCommand", "2086",
						new Object[]{this});
			}

			if (e instanceof KeyException) {
				throw (KeyException) e;
			} else {
				throw new KeyException(e.getMessage(), e);
			}
		}
	}

	public boolean iszOSandServant() {
		return PlatformHelperFactory.getPlatformHelper().isZOS()
				&& "Servant".equals(ManagementScopeManager.getInstance().getJvmType());
	}

	public static KeyStore loadKeyStore(String keyStoreLocation, String keyStoreType, String keyStorePassword)
			throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadKeyStore");
		}

		KeyStore ks = null;
		InputStream is = null;

		try {
			File fileLocation;
			if (KeyStoreTypeHelper.isCMSKeyStore(keyStoreType)) {
				String provider = null;
				provider = "IBMCMSProvider";
				fileLocation = new File(keyStoreLocation);
				Class<?> cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
				Method theMethod1 = cl1.getMethod("loadCMSKeyStore", File.class, String.class, String.class,
						String.class, String.class, String.class);
				ks = (KeyStore) theMethod1.invoke(cl1.newInstance(), fileLocation, keyStoreLocation, keyStorePassword,
						keyStoreType, provider, "true");
			} else {
				JSSEProvider jsseProvider = JSSEProviderFactory.getInstance();
				ks = jsseProvider.getKeyStoreInstance(keyStoreType, jsseProvider.getKeyStoreProvider());
				if (!keyStoreType.equals("JCERACFKS") && !keyStoreType.equals("JCECCARACFKS")
						&& !keyStoreType.equals("JCEHYBRIDRACFKS")) {
					fileLocation = new File(keyStoreLocation);
					if (fileLocation.exists()) {
						is = openKeyStore(keyStoreLocation);
					}
				} else {
					is = openKeyStore(keyStoreLocation);
				}

				ks.load(is, keyStorePassword.toCharArray());
				if (is != null) {
					is.close();
				}
			}
		} catch (Exception var9) {
			throw var9;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadKeyStore");
		}

		return ks;
	}

	protected void clearJavaKeyStore() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "clearJavaKeyStore");
		}

		this.ks = null;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "clearJavaKeyStore");
		}

	}

	void storeKeyStoreWithCMSKeyStoreUtility(KeyStore ks, String SSLKeyPassword, String SSLKeyStoreType,
			String SSLKeyStoreProvider, String SSLKeyStoreStash, String keyStoreLocation)
			throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException,
			InstantiationException, Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "storeKeyStoreWithCMSKeyStoreUtility");
		}

		try {
			Class<?> cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
			Method theMethod1 = cl1.getMethod("storeCMSKeyStore", KeyStore.class, String.class, String.class,
					String.class, String.class);
			theMethod1.invoke(cl1.newInstance(), ks, keyStoreLocation, SSLKeyPassword, SSLKeyStoreType,
					SSLKeyStoreStash);
			PlatformHelper ph = PlatformHelperFactory.getPlatformHelper();
			if (ph.isOS400()) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "OS400 changing file authority for " + keyStoreLocation);
				}

				try {
					String[] command = new String[]{"system", "CHGAUT", "OBJ('" + keyStoreLocation + "')",
							"USER(*PUBLIC)", "DTAAUT(*RX)", "OBJAUT(*NONE)"};
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Command to execute on OS400 " + command);
					}

					Runtime.getRuntime().exec(command);
				} catch (Exception var11) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception during file authority setting on OS400", new Object[]{var11});
					}
				}
			}
		} catch (Exception var12) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception storing KeyStore.", new Object[]{var12});
			}

			Manager.Ffdc.log(var12, this, "com.ibm.ws.ssl.config.WSKeyStore.store", "2348", new Object[]{this});
			throw var12;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "storeKeyStoreWithCMSKeyStoreUtility");
		}

	}

	protected void removeCMSKeystoreSigners(KeyStore cmsKs) {
		try {
			Enumeration aliases = cmsKs.aliases();

			while (aliases.hasMoreElements()) {
				String alias = (String) aliases.nextElement();
				if (cmsKs.isCertificateEntry(alias)) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "removing " + alias + " from cms keystore");
					}

					cmsKs.deleteEntry(alias);
				}
			}
		} catch (Exception var4) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception while deleting default signers: " + var4.getMessage());
			}
		}

	}

	private String printParms(Object[] parms) {
		StringBuffer sb = new StringBuffer();
		if (parms != null && parms.length != 0) {
			for (int i = 0; i < parms.length; ++i) {
				if (parms[i] == null || !(parms[i] instanceof byte[]) && !(parms[i] instanceof char[])
						&& !(parms[i] instanceof Key)) {
					sb.append("parm ");
					sb.append(i);
					sb.append(": ");
					sb.append(parms[i]);
					sb.append(", ");
				}
			}

			String parmString = sb.toString();
			if (parmString.endsWith(", ")) {
				parmString = parmString.substring(0, parmString.length() - 2);
			}

			return parmString;
		} else {
			sb.append("null or empty parms");
			return sb.toString();
		}
	}

	public boolean includePassword(String method, Object[] parms) {
		boolean ret = false;
		if (parms == null) {
			return ret;
		} else {
			if (METHODS_REQUIRE_PASSWORD.contains(method)) {
				ret = true;
				if ((method.equals("setKeyEntry") || method.equals("setKeyEntryOverwrite")) && parms.length != 4) {
					ret = false;
				}
			}

			return ret;
		}
	}
}