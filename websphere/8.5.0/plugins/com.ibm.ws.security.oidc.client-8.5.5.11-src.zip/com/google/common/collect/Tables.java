package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.base.Supplier;
import com.google.common.collect.Table.Cell;
import com.google.common.collect.Tables.1;
import com.google.common.collect.Tables.ImmutableCell;
import com.google.common.collect.Tables.TransformedTable;
import com.google.common.collect.Tables.TransposeTable;
import com.google.common.collect.Tables.UnmodifiableRowSortedMap;
import com.google.common.collect.Tables.UnmodifiableTable;
import java.util.Map;
import javax.annotation.Nullable;

@GwtCompatible
public final class Tables {
	private static final Function<? extends Map<?, ?>, ? extends Map<?, ?>> UNMODIFIABLE_WRAPPER = new 1();

	public static <R, C, V> Cell<R, C, V> immutableCell(@Nullable R rowKey, @Nullable C columnKey, @Nullable V value) {
		return new ImmutableCell(rowKey, columnKey, value);
	}

	public static <R, C, V> Table<C, R, V> transpose(Table<R, C, V> table) {
		return (Table) (table instanceof TransposeTable
				? ((TransposeTable) table).original
				: new TransposeTable(table));
	}

	@Beta
	public static <R, C, V> Table<R, C, V> newCustomTable(Map<R, Map<C, V>> backingMap,
			Supplier<? extends Map<C, V>> factory) {
		Preconditions.checkArgument(backingMap.isEmpty());
		Preconditions.checkNotNull(factory);
		return new StandardTable(backingMap, factory);
	}

	@Beta
	public static <R, C, V1, V2> Table<R, C, V2> transformValues(Table<R, C, V1> fromTable,
			Function<? super V1, V2> function) {
		return new TransformedTable(fromTable, function);
	}

	public static <R, C, V> Table<R, C, V> unmodifiableTable(Table<? extends R, ? extends C, ? extends V> table) {
		return new UnmodifiableTable(table);
	}

	@Beta
	public static <R, C, V> RowSortedTable<R, C, V> unmodifiableRowSortedTable(
			RowSortedTable<R, ? extends C, ? extends V> table) {
		return new UnmodifiableRowSortedMap(table);
	}

	private static <K, V> Function<Map<K, V>, Map<K, V>> unmodifiableWrapper() {
		return UNMODIFIABLE_WRAPPER;
	}
}