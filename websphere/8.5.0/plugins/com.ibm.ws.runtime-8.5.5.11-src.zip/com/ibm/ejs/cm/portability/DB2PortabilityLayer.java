package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.cm.proxy.ConnectionProxy;
import com.ibm.ejs.cm.proxy.DB2ConnectionProxy;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

class DB2PortabilityLayer extends PortabilityLayerImpl {
	private static DB2PortabilityLayer instance;
	private static final TraceComponent tc = Tr.register(DB2PortabilityLayer.class);

	protected DB2PortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.errorMap.put(new Integer(-803), DuplicateKeyException.class);
		this.errorMap.put(new Integer(-601), TableAlreadyExistsException.class);
		this.errorMap.put(new Integer(-954), ResourceAllocationException.class);
		this.errorMap.put(new Integer(-1040), ResourceAllocationException.class);
		this.errorMap.put(new Integer(-624), PrimarykeyAlreadyDefinedException.class);
		this.errorMap.put(new Integer(-204), TableDoesNotExistException.class);
		this.errorMap.put(new Integer(-1015), StaleConnectionException.class);
		this.errorMap.put(new Integer(-1034), StaleConnectionException.class);
		this.errorMap.put(new Integer(-1035), StaleConnectionException.class);
		this.errorMap.put(new Integer(-6036), StaleConnectionException.class);
		this.errorMap.put(new Integer(-30081), StaleConnectionException.class);
		this.errorMap.put(new Integer(-1224), StaleConnectionException.class);
		this.errorMap.put(new Integer(-1229), StaleConnectionException.class);
		this.errorMap.put("08506", StaleConnectionException.class);
		this.errorMap.put("58004", StaleConnectionException.class);
		this.errorMap.put("08S01", StaleConnectionException.class);
		this.typeMap.setElementAt(" BLOB(1M) ", 9);
		this.typeMap.setElementAt(" BLOB(2K) ", 10);
		if (!System.getProperty("os.name").equals("OS/400")) {
			this.defaultDataSourceProps.setProperty("connectionAttribute", "cursorhold=0");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	static PortabilityLayer getPortabilityLayer(Connection conn) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPortabilityLayer", conn);
		}

		DatabaseMetaData metaData = conn.getMetaData();
		if (metaData != null) {
			String productName = metaData.getDatabaseProductName();
			if (productName != null) {
				PortabilityLayer pbl;
				if (productName.equalsIgnoreCase("DB2")) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getPortabilityLayer", "DB2ConnectPortabilityLayer - 390");
					}

					pbl = DB2ConnectPortabilityLayer.getInstance();
					((DB2ConnectPortabilityLayer) pbl).setIs390(1);
					return pbl;
				}

				if (productName.equalsIgnoreCase("AS")) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getPortabilityLayer", "DB2ConnectPortabilityLayer - AS");
					}

					pbl = DB2ConnectPortabilityLayer.getInstance();
					((DB2ConnectPortabilityLayer) pbl).setIs390(-1);
					return pbl;
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getPortabilityLayer", "DB2PortabilityLayer");
		}

		return getInstance();
	}

	public static PortabilityLayer getInstance(DataSourceProperties dsProps) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance", dsProps);
		}

		PortabilityLayer pl = null;
		String dsClassName = dsProps.getDataSourceClassName();
		if (dsClassName.equals("com.ibm.db2.jcc.DB2ConnectionPoolDataSource")) {
			String driverType = dsProps.getProperty("driverType");
			if (driverType == null) {
				pl = DB2390LocalPortabilityLayer.getInstance();
			} else {
				pl = PortabilityLayerImpl.getInstance(dsProps);
			}
		} else {
			pl = PortabilityLayerImpl.getInstance(dsProps);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance", pl);
		}

		return pl;
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new DB2PortabilityLayer();
		}

		return instance;
	}

	public ConnectionProxy createConnectionProxy(ConnectO connection) {
		return new DB2ConnectionProxy(connection);
	}
}