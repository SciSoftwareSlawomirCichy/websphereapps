package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import javax.ejb.EJBException;

public class ContainerEJBException extends EJBException {
	private static final long serialVersionUID = -8150478492856479226L;

	public ContainerEJBException() {
	}

	public ContainerEJBException(String message) {
		super(message);
	}

	public ContainerEJBException(String message, Throwable cause) {
		super(message, ExceptionUtil.Exception(cause));
	}

	public ContainerEJBException(Throwable cause) {
		super(ExceptionUtil.Exception(cause));
	}
}