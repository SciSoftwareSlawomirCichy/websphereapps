package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.MathUtil;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import java.io.Serializable;

final class BeanIdCache {
	private volatile BeanId[] ivBuckets;
	private int ivCacheFinds = 0;
	private int ivCacheHits = 0;
	private static final TraceComponent tc = Tr.register(BeanIdCache.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public BeanIdCache(int numBuckets) {
		numBuckets = MathUtil.findNextPrime(numBuckets);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> (" + numBuckets + ")");
		}

		this.ivBuckets = new BeanId[numBuckets];
	}

	public BeanId find(BeanId beanId) {
		BeanId[] buckets = this.ivBuckets;
		BeanId element = buckets[(beanId.hashValue & Integer.MAX_VALUE) % buckets.length];
		if (element != null && element.equals(beanId)) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				++this.ivCacheFinds;
				++this.ivCacheHits;
				Tr.debug(tc, "BeanId found in BeanId Cache : " + this.ivCacheHits + " / " + this.ivCacheFinds);
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				++this.ivCacheFinds;
				Tr.debug(tc, "BeanId not found in BeanId Cache : " + this.ivCacheHits + " / " + this.ivCacheFinds);
			}

			element = beanId;
		}

		return element;
	}

	public BeanId find(EJSHome home, Serializable pkey, boolean isHome) {
		int hashValue = BeanId.computeHashValue(home.j2eeName, pkey, isHome);
		BeanId[] buckets = this.ivBuckets;
		BeanId element = buckets[(hashValue & Integer.MAX_VALUE) % buckets.length];
		if (element != null && element.equals(home, pkey, isHome)) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				++this.ivCacheFinds;
				++this.ivCacheHits;
				Tr.debug(tc, "BeanId found in BeanId Cache : " + this.ivCacheHits + " / " + this.ivCacheFinds);
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				++this.ivCacheFinds;
				Tr.debug(tc, "BeanId not found in BeanId Cache : " + this.ivCacheHits + " / " + this.ivCacheFinds);
			}

			element = new BeanId(home, pkey, isHome);
		}

		return element;
	}

	public void add(BeanId beanId) {
		BeanId[] buckets = this.ivBuckets;
		buckets[(beanId.hashValue & Integer.MAX_VALUE) % buckets.length] = beanId;
	}

	public void removeAll(EJSHome home) {
		BeanId[] buckets = this.ivBuckets;

		for (int i = 0; i < buckets.length; ++i) {
			BeanId element = buckets[i];
			if (element != null && element.home == home) {
				buckets[i] = null;
			}
		}

	}

	public void setSize(int cacheSize) {
		if (this.ivBuckets.length != cacheSize) {
			this.ivBuckets = new BeanId[cacheSize];
		}

	}

	public void introspect(IntrospectionWriter writer) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			writer.println("BeanIdCache : size = " + this.ivBuckets.length + ", hits/find = " + this.ivCacheHits + "/"
					+ this.ivCacheFinds);
		} else {
			writer.println("BeanIdCache : size = " + this.ivBuckets.length);
		}

	}
}