package com.ibm.ejs.util.am;

public interface AlarmListener {
	void alarm(Object var1);
}