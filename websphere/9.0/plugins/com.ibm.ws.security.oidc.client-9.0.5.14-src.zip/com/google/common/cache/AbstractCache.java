package com.google.common.cache;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;

@GwtCompatible
public abstract class AbstractCache<K, V> implements Cache<K, V> {
	public V get(K key, Callable<? extends V> valueLoader) throws ExecutionException {
		throw new UnsupportedOperationException();
	}

	public ImmutableMap<K, V> getAllPresent(Iterable<?> keys) {
		Map<K, V> result = Maps.newLinkedHashMap();
		Iterator var3 = keys.iterator();

		while (var3.hasNext()) {
			Object key = var3.next();
			if (!result.containsKey(key)) {
				V value = this.getIfPresent(key);
				if (value != null) {
					result.put(key, value);
				}
			}
		}

		return ImmutableMap.copyOf(result);
	}

	public void put(K key, V value) {
		throw new UnsupportedOperationException();
	}

	public void putAll(Map<? extends K, ? extends V> m) {
		Iterator var2 = m.entrySet().iterator();

		while (var2.hasNext()) {
			Entry<? extends K, ? extends V> entry = (Entry) var2.next();
			this.put(entry.getKey(), entry.getValue());
		}

	}

	public void cleanUp() {
	}

	public long size() {
		throw new UnsupportedOperationException();
	}

	public void invalidate(Object key) {
		throw new UnsupportedOperationException();
	}

	public void invalidateAll(Iterable<?> keys) {
		Iterator var2 = keys.iterator();

		while (var2.hasNext()) {
			Object key = var2.next();
			this.invalidate(key);
		}

	}

	public void invalidateAll() {
		throw new UnsupportedOperationException();
	}

	public CacheStats stats() {
		throw new UnsupportedOperationException();
	}

	public ConcurrentMap<K, V> asMap() {
		throw new UnsupportedOperationException();
	}
}