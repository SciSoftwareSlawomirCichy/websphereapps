package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.util.concurrent.Service.Listener;
import com.google.common.util.concurrent.Service.State;
import java.util.concurrent.Executor;

@Beta
public interface Service {
	ListenableFuture<State> start();

	State startAndWait();

	boolean isRunning();

	State state();

	ListenableFuture<State> stop();

	State stopAndWait();

	Throwable failureCause();

	void addListener(Listener var1, Executor var2);
}