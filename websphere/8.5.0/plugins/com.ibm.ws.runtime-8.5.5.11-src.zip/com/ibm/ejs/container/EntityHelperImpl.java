package com.ibm.ejs.container;

import com.ibm.ejs.container.finder.FinderResultFactory;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.cpmi.PMHomeInfo;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.EJBMethodInfo;
import com.ibm.websphere.csi.InconsistentAccessIntentException;
import com.ibm.websphere.csi.MethodInterface;
import com.ibm.websphere.csi.TransactionAttribute;
import com.ibm.ws.appprofile.accessintent.AIEJBMethodInfo;
import com.ibm.ws.appprofile.accessintent.AccessIntentFactory;
import com.ibm.ws.appprofile.accessintent.EJBAccessIntent;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import com.ibm.ws.ejbcontainer.util.ObjectUtil;
import com.ibm.ws.exception.WsNestedException;
import com.ibm.ws.ffdc.FFDCFilter;
import java.io.Serializable;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Enumeration;
import javax.ejb.DuplicateKeyException;
import javax.ejb.EJBException;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;
import javax.ejb.ObjectNotFoundException;
import javax.ejb.RemoveException;

public class EntityHelperImpl implements EntityHelper {
	private static final TraceComponent tc = Tr.register(EntityHelperImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = EntityHelperImpl.class.getName();
	protected static EJBAccessIntent ivAIService;

	public EntityHelperImpl(EJBAccessIntent aiService) {
		ivAIService = aiService;
	}

	public EJBObject getBean(EJSHome home, Object primaryKey) throws RemoteException {
		EJBObject result = null;
		EJSWrapperCommon wrappers = null;
		home.homeEnabled();
		EntityContainerTx currentTx = getCurrentTx(home.container);
		wrappers = getBean_Common(home, currentTx, primaryKey);
		if (wrappers != null) {
			result = wrappers.getRemoteWrapper();
		}

		return result;
	}

	public EJBObject getBean(EJSHome home, String type, Object primaryKey, Object data)
			throws FinderException, RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getBean(" + type + ")");
		}

		home.homeEnabled();
		EJSHome targetHome = home.homeRecord.getTargetHome(type);
		if (home.beanMetaData.supportsFluffOnFind) {
			return getBean(targetHome, primaryKey, data);
		} else {
			if (home.noLocalCopies && home.allowPrimaryKeyMutation && !home.statefulSessionHome) {
				try {
					primaryKey = ObjectUtil.copy((Serializable) primaryKey);
				} catch (Throwable var8) {
					FFDCFilter.processException(var8, CLASS_NAME + ".getBean", "1309", this);
					ContainerEJBException ex = new ContainerEJBException(
							"getBean failed attempting to process PrimaryKey", var8);
					Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E",
							new Object[]{var8, ex.toString()});
					throw ex;
				}
			}

			BeanId id = new BeanId(targetHome, (Serializable) primaryKey, false);
			return home.getWrapper(id).getRemoteWrapper();
		}
	}

	public EJBLocalObject getBean_Local(EJSHome home, Object primaryKey) throws RemoteException {
		EJBLocalObject result = null;
		EJSWrapperCommon wrappers = null;
		home.homeEnabled();
		EntityContainerTx currentTx = getCurrentTx(home.container);
		wrappers = getBean_Common(home, currentTx, primaryKey);
		if (wrappers != null) {
			result = wrappers.getLocalObject();
		}

		return result;
	}

	public static EJSWrapperCommon getBean_Common(EJSHome home, EntityContainerTx currentTx, Object primaryKey)
			throws RemoteException {
		EJSWrapperCommon result = null;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getBean_Common (" + primaryKey + ") : " + home.j2eeName);
		}

		ContainerTx tx = toContainerTx(currentTx);
		BeanId beanId = new BeanId(home, (Serializable) primaryKey, false);
		BeanO beanO = home.container.activator.getBean(tx, beanId);
		if (beanO != null) {
			result = home.wrapperManager.getWrapper(beanId);
		}

		HomeRecord homeRecord = home.homeRecord;
		if (result == null && homeRecord.childBeans != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "getBean_Common : not found - checking subclasses");
			}

			result = getBean_Common(homeRecord, currentTx, primaryKey);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getBean_Common", result);
		}

		return result;
	}

	private static EJSWrapperCommon getBean_Common(HomeRecord homeRecord, EntityContainerTx currentTx,
			Object primaryKey) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "getBean_Common : child beans of : " + homeRecord.j2eeName);
		}

		EJSWrapperCommon result = null;
		Enumeration children = homeRecord.childBeans.elements();

		while (result == null && children.hasMoreElements()) {
			HomeRecord childHomeRecord = (HomeRecord) children.nextElement();
			if (childHomeRecord.homeInternal != null) {
				EJSHome childHome = (EJSHome) childHomeRecord.homeInternal;
				result = getBean_Common(childHome, currentTx, primaryKey);
			} else if (childHomeRecord.childBeans != null) {
				result = getBean_Common(childHomeRecord, currentTx, primaryKey);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getBean_Common", result);
		}

		return result;
	}

	public static EJBObject getBean(EJSHome home, Object primaryKey, Object data)
			throws FinderException, RemoteException {
		home.homeEnabled();
		ContainerTx currentTx = home.container.getCurrentTx(false);
		if (home.noLocalCopies && home.allowPrimaryKeyMutation && !home.statefulSessionHome) {
			try {
				primaryKey = ObjectUtil.copy((Serializable) primaryKey);
			} catch (Throwable var16) {
				FFDCFilter.processException(var16, CLASS_NAME + ".getBean", "1297", home);
				ContainerEJBException ex = new ContainerEJBException("getBean failed attempting to process PrimaryKey",
						var16);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var16, ex.toString()});
				throw ex;
			}
		}

		WrapperManager wrapperManager = home.wrapperManager;
		BeanId id = wrapperManager.beanIdCache.find(home, (Serializable) primaryKey, false);
		EJSContainer container = home.container;
		EJBObject result = container.getBean(currentTx, id);
		if (result == null) {
			EJBThreadData threadData = EJSContainer.getThreadData();
			ContainerManagedBeanO beanO = (ContainerManagedBeanO) home.createBeanO(threadData, currentTx, id);
			BeanO existingBeanO = null;
			beanO.setCMP11LoadedForUpdate(threadData.getMethodContext(), currentTx);
			beanO.hydrate(home.persister, data, primaryKey, id);

			try {
				EJBObject result = container.getBean(currentTx, id);
				if (result == null) {
					existingBeanO = container.addBean(beanO, currentTx);
				}
			} catch (DuplicateKeyException var17) {
				FFDCFilter.processException(var17, CLASS_NAME + ".getBean", "1209", home);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "getBean failed", var17);
				}

				beanO.destroy();
				throw new ContainerInternalError(var17);
			} finally {
				if (beanO != null) {
					threadData.popCallbackBeanO();
				}

			}

			if (existingBeanO != null) {
				result = wrapperManager.getWrapper(existingBeanO.getId()).getRemoteWrapper();
				beanO.destroy();
			} else {
				result = wrapperManager.getWrapper(id).getRemoteWrapper();
			}
		}

		return (EJBObject) result;
	}

	public Enumeration getCMP20Enumeration(EJSHome home, Enumeration keys) throws FinderException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getCMP20Enumeration");
		}

		home.homeEnabled();
		EntityContainerTx txInfo = getCurrentTx(home.container);
		if (txInfo.isFlushRequired()) {
			IllegalStateException isex = new IllegalStateException(
					"Persistence Manager failed to perform synchronization of Entity beans prior to find<METHOD>");
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getCMP20Enumeration", isex);
			}

			throw isex;
		} else {
			Enumeration rtnEnum = FinderResultFactory.getCMP20FinderResultEnumeration(keys, home, txInfo, this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getCMP20Enumeration");
			}

			return rtnEnum;
		}
	}

	public Enumeration getCMP20Enumeration_Local(EJSHome home, Enumeration keys)
			throws FinderException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getCMP20Enumeration_Local");
		}

		home.homeEnabled();
		EntityContainerTx txInfo = getCurrentTx(home.container);
		if (txInfo.isFlushRequired()) {
			IllegalStateException isex = new IllegalStateException(
					"Persistence Manager failed to perform synchronization of Entity beans prior to find<METHOD>");
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getCMP20Enumeration_Local", isex);
			}

			throw isex;
		} else {
			Enumeration rtnEnum = FinderResultFactory.getCMP20FinderResultEnumeration_Local(keys, home, txInfo, this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getCMP20Enumeration_Local");
			}

			return rtnEnum;
		}
	}

	public Collection getCMP20Collection(EJSHome home, Collection keys) throws FinderException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getCMP20Collection");
		}

		home.homeEnabled();
		EntityContainerTx txInfo = getCurrentTx(home.container);
		if (txInfo.isFlushRequired()) {
			IllegalStateException isex = new IllegalStateException(
					"Persistence Manager failed to perform synchronization of Entity beans prior to find<METHOD>");
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getCMP20Collection", isex);
			}

			throw isex;
		} else {
			Collection rtnCol = FinderResultFactory.getCMP20FinderResultCollection(keys, home, txInfo, this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getCMP20Collection");
			}

			return rtnCol;
		}
	}

	public Collection getCMP20Collection_Local(EJSHome home, Collection keys) throws FinderException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getCMP20Collection_Local");
		}

		home.homeEnabled();
		EntityContainerTx txInfo = getCurrentTx(home.container);
		if (txInfo.isFlushRequired()) {
			IllegalStateException isex = new IllegalStateException(
					"Persistence Manager failed to perform synchronization of Entity beans prior to find<METHOD>");
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getCMP20Collection_Local", isex);
			}

			throw isex;
		} else {
			Collection rtnCol = FinderResultFactory.getCMP20FinderResultCollection_Local(keys, home, txInfo, this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getCMP20Collection_Local");
			}

			return rtnCol;
		}
	}

	public EJSWrapperCommon activateBean_Common(EJSHome home, Object primaryKey, boolean pkeyCopyRequired)
			throws FinderException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "activateBean_Common (" + primaryKey + ")");
		}

		home.homeEnabled();
		EJSContainer container = home.container;
		WrapperManager wrapperManager = home.wrapperManager;
		EntityHomeRecord homeRecord = toEntityHomeRecord(home.homeRecord);
		EJBAccessIntent aiService = null;
		if (home.ivAIServiceEnabled) {
			aiService = ivAIService;
		}

		EJSWrapperCommon result = null;

		Exception chained;
		try {
			BeanId beanId = null;
			chained = null;
			EJSDeployedSupport s = EJSContainer.getMethodContext();
			EntityContainerTx currentTx = toEntityContainerTx(s.currentTx);
			if (currentTx.isFlushRequired()) {
				IllegalStateException isex = new IllegalStateException(
						"Persistence Manager failed to perform synchronization of Entity beans prior to find<METHOD>");
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "ActivateBean_Common", isex);
				}

				throw isex;
			}

			if (homeRecord.getPMBeanInfo() != null && homeRecord.hasInheritance()) {
				beanId = this.getBeanIdForCMPInheritance(home, currentTx, primaryKey);
			} else {
				beanId = wrapperManager.beanIdCache.find(home, (Serializable) primaryKey, false);
			}

			if (aiService != null && home.hasMethodLevelAccessIntentSet()) {
				AccessIntent accessIntent = this.getFinderMethodAccessIntent(home);
				currentTx.cacheAccessIntent(beanId, accessIntent);
			}

			ContainerTx tx = toContainerTx(currentTx);
			BeanO beanO = container.activator.activateBean(s.ivThreadData, tx, beanId);
			beanId = beanO.beanId;
			if (pkeyCopyRequired && beanId.pkey == primaryKey) {
				beanId.pkey = ObjectUtil.copy((Serializable) primaryKey);
			} else if (isTraceOn && tc.isDebugEnabled() && pkeyCopyRequired) {
				Tr.debug(tc, "copyObject of primary key not needed");
			}

			result = wrapperManager.getWrapper(beanId);
		} catch (EJBException var15) {
			if (var15 instanceof WsNestedException) {
				FFDCFilter.processException(var15, CLASS_NAME + ".activateBean_Common", "325", home);
				chained = var15.getCausedByException();
				if (chained instanceof FinderException) {
					throw (FinderException) chained;
				}
			}

			throw var15;
		} catch (NoSuchObjectException var16) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "activateBean_Common():NoSuchObjectException", var16);
			}

			throw new ObjectNotFoundException(primaryKey.toString());
		} catch (InconsistentAccessIntentException var17) {
			FFDCFilter.processException(var17, CLASS_NAME + ".activateBean_Common", "1128", home);
			throw new RemoteException(var17.getMessage(), var17);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "activateBean_Common", result);
		}

		return result;
	}

	public static void preFind(EJSHome home) throws RemoteException {
		home.homeEnabled();
		BeanMetaData beanMetaData = home.beanMetaData;
		if (beanMetaData.isPreFindFlushEnabled) {
			ContainerTx currentTx = home.container.getCurrentTx(false);
			if (beanMetaData.cmpVersion == 2) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "preFind(): setting flush required by PM");
				}

				currentTx.ivFlushRequired = true;
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "preFind(): flushing all dirty beans...");
				}

				currentTx.ivCMP11FlushActive = true;
				currentTx.flush();
				currentTx.ivCMP11FlushActive = false;
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "preFind(): flush NOT required");
		}

	}

	public EntityBeanO getFindByPrimaryKeyEntityBeanO(EJSHome home) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getFindByPrimaryKeyEntityBeanO");
		}

		EntityBeanOImpl result = (EntityBeanOImpl) home.createBeanO();
		result.preFind();
		if (home.ivAIServiceEnabled) {
			result.ivAccessIntent = this.getFinderMethodAccessIntent(home);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getFindByPrimaryKeyEntityBeanO " + result);
		}

		return result;
	}

	public EntityBeanO getFinderEntityBeanO(EJSHome home) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getFinderEntityBeanO");
		}

		preFind(home);
		EntityBeanOImpl result = (EntityBeanOImpl) home.createBeanO();
		result.preFind();
		if (home.ivAIServiceEnabled) {
			result.ivAccessIntent = this.getFinderMethodAccessIntent(home);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getFinderEntityBeanO " + result);
		}

		return result;
	}

	public void discardFinderEntityBeanO(EJSHome home, EntityBeanO beanO) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "discardFinderEntityBeanO " + beanO);
		}

		home.homeEnabled();
		if (beanO != null) {
			EJSContainer.getThreadData().popCallbackBeanO();
			beanO.discard();
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "discardFinderEntityBeanO");
		}

	}

	public void releaseFinderEntityBeanO(EJSHome home, EntityBeanO beanO) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "releaseFinderEntityBeanO " + beanO);
		}

		home.homeEnabled();
		if (beanO != null) {
			EJSContainer.getThreadData().popCallbackBeanO();
			beanO.postFind();
			home.beanPool.put(beanO);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "releaseFinderEntityBeanO");
		}

	}

	public BeanManagedBeanO getFinderBeanO(EJSHome home) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getFinderBeanO");
		}

		home.homeEnabled();
		preFind(home);
		EntityBeanOImpl result = (EntityBeanOImpl) home.createBeanO();
		result.preFind();
		if (home.ivAIServiceEnabled) {
			result.ivAccessIntent = this.getFinderMethodAccessIntent(home);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getFinderBeanO " + result);
		}

		return new BeanManagedBeanO(result);
	}

	public void releaseFinderBeanO(EJSHome home, BeanManagedBeanO beanO) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "releaseFinderBeanO " + beanO);
		}

		home.homeEnabled();
		if (beanO != null) {
			EJSContainer.getThreadData().popCallbackBeanO();
			EntityBeanO entityBeanO = beanO.ivDelegate;
			entityBeanO.postFind();
			home.beanPool.put(entityBeanO);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "releaseFinderBeanO");
		}

	}

	public EntityBeanO getHomeMethodEntityBeanO(EJSHome home) throws RemoteException {
		home.homeEnabled();
		EntityBeanOImpl result = (EntityBeanOImpl) home.createBeanO();
		result.preHomeMethodCall();
		if (home.ivAIServiceEnabled) {
			result.ivAccessIntent = this.getHomeMethodAccessIntent(home);
		}

		return result;
	}

	public void releaseHomeMethodEntityBeanO(EJSHome home, EntityBeanO beanO) throws RemoteException {
		home.homeEnabled();
		if (beanO != null) {
			EJSContainer.getThreadData().popCallbackBeanO();
			beanO.postHomeMethodCall();
			home.beanPool.put(beanO);
		}

	}

	private AccessIntent getFinderMethodAccessIntent(EJSHome home) {
		EJSDeployedSupport s = EJSContainer.getMethodContext();
		EJBMethodInfo methodInfo = getEJBMethodInfo();
		AccessIntent accessIntent = methodInfo.getAccessIntent(ivAIService);
		if (s.methodId >= 0) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getFinderMethodAccessIntent: " + methodInfo.getMethodSignature());
				Tr.debug(tc, getAccessIntentString(accessIntent));
			}

			if (!s.getCurrentTx().isTransactionGlobal() || s.beganAndEndInThisScope()) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getFinderMethodAccessIntent: tran begins/ends with method");
				}

				if (accessIntent.getAccessType() == 2) {
					return accessIntent;
				}

				if (accessIntent.getConcurrencyControl() == 2) {
					return accessIntent;
				}

				if (accessIntent.getPessimisticUpdateLockHint() == 1) {
					return accessIntent;
				}

				if (accessIntent.getPessimisticUpdateLockHint() == 4) {
					return accessIntent;
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getFinderMethodAccessIntent overriding wsPessimisticUpdate with wsPessimisticRead");
				}

				accessIntent = AccessIntentFactory.wsPessimisticRead;
			}
		}

		return accessIntent;
	}

	private AccessIntent getHomeMethodAccessIntent(EJSHome home) {
		EJBMethodInfo methodInfo = getEJBMethodInfo();
		AccessIntent accessIntent = methodInfo.getAccessIntent(ivAIService);
		return accessIntent;
	}

	public BeanId remove(EJSHome home, Object primaryKey) throws RemoteException, RemoveException, FinderException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		BeanMetaData beanMetaData = home.beanMetaData;
		EntityHomeRecord homeRecord = toEntityHomeRecord(home.homeRecord);
		EJBPMICollaborator pmiBean = home.pmiBean;
		EJSContainer container = home.container;
		WrapperManager wrapperManager = home.wrapperManager;
		BeanO beanO = null;
		BeanId beanId = null;
		EntityContainerTx currentTx = null;
		if (beanMetaData.ivCacheReloadType != 0) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "RemoveException: Read only EJB may not be removed.");
			}

			throw new RemoveException("Read only EJB may not be removed.");
		} else {
			EJSDeployedSupport s = EJSContainer.getMethodContext();
			EJBThreadData threadData = s.ivThreadData;
			ContainerTx tx = s.currentTx;
			currentTx = toEntityContainerTx(tx);
			long pmiCookie = 0L;
			if (pmiBean != null) {
				pmiCookie = pmiBean.initalTime(15);
			}

			try {
				if (homeRecord.getPMBeanInfo() != null && homeRecord.hasInheritance()) {
					beanId = this.getBeanIdForCMPInheritance(home, currentTx, primaryKey);
				} else {
					beanId = wrapperManager.beanIdCache.find(home, (Serializable) primaryKey, false);
				}

				beanO = container.activator.preInvokeActivateBean(threadData, tx, beanId);
				beanO.preInvoke(s, tx);
			} catch (Throwable var66) {
				FFDCFilter.processException(var66, CLASS_NAME + ".remove(pk)", "2239", home);

				try {
					if (beanO != null) {
						beanO.discard();
						beanO.postInvoke(s.methodId, s);
						container.activator.postInvoke(tx, beanO);
					}
				} finally {
					if (pmiBean != null) {
						pmiBean.finalTime(15, pmiCookie);
					}

					if (beanO != null) {
						threadData.popCallbackBeanO();
					}

					s.preInvokeException = true;
					s.setUncheckedException(var66);
				}
			}

			if (beanO != null) {
				try {
					beanO.remove();
				} catch (RemoveException var62) {
					FFDCFilter.processException(var62, CLASS_NAME + ".remove(pk)", "2253", home);
					throw var62;
				} catch (Throwable var63) {
					FFDCFilter.processException(var63, CLASS_NAME + ".remove(pk)", "2258", home);
					beanO.discard();
					s.setUncheckedException(var63);
				} finally {
					if (pmiBean != null) {
						pmiBean.finalTime(15, pmiCookie);
					}

					try {
						beanO.postInvoke(s.methodId, s);
						container.activator.postInvoke(tx, beanO);
					} finally {
						threadData.popCallbackBeanO();
					}
				}
			}

			return beanId;
		}
	}

	private BeanId getBeanIdForCMPInheritance(EJSHome home, EntityContainerTx currentTx, Object primaryKey)
			throws FinderException, RemoteException {
		BeanId beanId = null;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getBeanIdforCMPInheritance (" + primaryKey + ")");
		}

		EJSWrapperCommon wrappers = getBean_Common(home, currentTx, primaryKey);
		if (wrappers != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Found in cache - returning BeanId from there");
			}

			beanId = wrappers.getBeanId();
		} else {
			ContainerManaged2_0BeanO beanO = null;
			EJSHome targetHome = null;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Not found in EJB cache - obtaining Home from PM");
			}

			EntityHomeRecord homeRecord = toEntityHomeRecord(home.homeRecord);
			HomeRecord targetHomeRecord = (HomeRecord) homeRecord.getPMBeanInfo().getHomeForKey(primaryKey, currentTx);
			if (targetHomeRecord == null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Not found in PM cache - performing findBPK");
				}

				try {
					beanO = (ContainerManaged2_0BeanO) this.getFindByPrimaryKeyEntityBeanO(home);
					primaryKey = beanO.ivPMBeanInfo.ejbFindByPrimaryKey(primaryKey);
					this.releaseFinderEntityBeanO(home, beanO);
					beanO = null;
				} catch (FinderException var15) {
					this.releaseFinderEntityBeanO(home, beanO);
					beanO = null;
					throw var15;
				} finally {
					if (beanO != null) {
						this.discardFinderEntityBeanO(home, beanO);
					}

				}

				targetHomeRecord = (HomeRecord) homeRecord.getPMBeanInfo().getHomeForKey(primaryKey, currentTx);
			}

			targetHome = targetHomeRecord.getHomeAndInitialize();
			beanId = home.wrapperManager.beanIdCache.find(targetHome, (Serializable) primaryKey, false);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getBeanIdforCMPInheritance : " + beanId);
		}

		return beanId;
	}

	public static EJBMethodInfoImpl mapPMMethodInfo(EJSDeployedSupport s, EJSWrapperBase wrapper, int methodId,
			String methodSignature, AccessIntent pmAI) {
		EJBMethodInfoImpl rtnInfo = null;
		switch (methodId) {
			case -5 :
				if (methodSignature == null) {
					methodSignature = "Mandatory:java.lang.Object";
				}

				rtnInfo = s.ivThreadData.getEJBMethodInfoStack().get(methodSignature, (String) null, wrapper,
						MethodInterface.HOME, TransactionAttribute.TX_MANDATORY);
				break;
			case -4 :
				if (methodSignature == null) {
					methodSignature = "Mandatory:java.lang.Object";
				}

				rtnInfo = s.ivThreadData.getEJBMethodInfoStack().get(methodSignature, (String) null, wrapper,
						MethodInterface.LOCAL_HOME, TransactionAttribute.TX_MANDATORY);
				break;
			case -3 :
				if (methodSignature == null) {
					methodSignature = "PMInternalFinder:java.lang.Object";
				}

				rtnInfo = s.ivThreadData.getEJBMethodInfoStack().get(methodSignature, (String) null, wrapper,
						MethodInterface.HOME, TransactionAttribute.TX_SUPPORTS);
				break;
			case -2 :
				if (methodSignature == null) {
					methodSignature = "PMInternalFinder_Local:java.lang.Object";
				}

				rtnInfo = s.ivThreadData.getEJBMethodInfoStack().get(methodSignature, (String) null, wrapper,
						MethodInterface.LOCAL_HOME, TransactionAttribute.TX_SUPPORTS);
				break;
			case -1 :
				if (methodSignature == null) {
					methodSignature = "getLink:java.lang.String";
				}

				rtnInfo = s.ivThreadData.getEJBMethodInfoStack().get(methodSignature, (String) null, wrapper,
						MethodInterface.LOCAL, TransactionAttribute.TX_SUPPORTS);
		}

		AccessIntent ai = pmAI;
		if (pmAI == null) {
			EJSDeployedSupport methodContext = s.ivThreadData.getMethodContext();
			if (methodContext != null && methodContext.methodInfo != null) {
				EJBMethodInfo methodInfo = (EJBMethodInfo) methodContext.methodInfo;
				ai = methodInfo.getMethodAccessIntent(ivAIService);
			}
		}

		((EJBMethodInfo) rtnInfo).setPMInternalAccessIntent(ai);
		return rtnInfo;
	}

	public EJBMethodInfoImpl getPMMethodInfo(EJSDeployedSupport s, EJSWrapperBase wrapper, int methodId,
			String methodSignature) {
		return mapPMMethodInfo(s, wrapper, methodId, methodSignature, (AccessIntent) null);
	}

	public final EJBAccessIntent getEJBAccessIntent() {
		return ivAIService;
	}

	public final boolean hasMethodLevelAccessIntentSet(EJSHome ejsHome) {
		if (ejsHome.cachedHasMethodLevelAI == 0) {
			EJBAccessIntent aiService = ivAIService;
			if (aiService != null) {
				ejsHome.cachedHasMethodLevelAI = aiService.hasMethodLevelAccessIntent(ejsHome.beanMetaData) ? 1 : -1;
				if (ejsHome.cachedHasMethodLevelAI == -1) {
					ejsHome.ivCachedBeanLevelAccessIntent = aiService
							.getAccessIntent((AIEJBMethodInfo) ejsHome.defaultAIMethodInfo, (AccessIntent) null);
				}
			} else {
				ejsHome.cachedHasMethodLevelAI = -1;
			}
		}

		return ejsHome.cachedHasMethodLevelAI == 1;
	}

	public static final AccessIntent getBeanLevelAccessIntent(EJSHome ejsHome) {
		AccessIntent returnAI = null;
		if (ejsHome.hasMethodLevelAccessIntentSet()) {
			EJBAccessIntent aiService = ivAIService;
			returnAI = aiService.getAccessIntent((AIEJBMethodInfo) ejsHome.defaultAIMethodInfo, (AccessIntent) null);
		} else {
			returnAI = (AccessIntent) ejsHome.ivCachedBeanLevelAccessIntent;
		}

		return returnAI;
	}

	static String getAccessIntentString(AccessIntent ai) {
		if (ai == null) {
			return "<null>";
		} else {
			StringBuffer result = new StringBuffer("AccessIntent(");
			int control = ai.getConcurrencyControl();
			switch (control) {
				case 1 :
					result.append("Pessimistic-");
					break;
				case 2 :
					result.append("Optimistic-");
					break;
				default :
					result.append("Unknown-");
			}

			int type = ai.getAccessType();
			switch (type) {
				case 1 :
					result.append("Update, ");
					break;
				case 2 :
					result.append("Read, ");
					break;
				default :
					result.append("Unknown, ");
			}

			int scope;
			if (control == 1 && type == 1) {
				scope = ai.getPessimisticUpdateLockHint();
				switch (scope) {
					case 1 :
						result.append("NoCollision, ");
						break;
					case 2 :
						result.append("Weakest, ");
						break;
					case 3 :
						result.append("NoHint, ");
						break;
					case 4 :
						result.append("Exclusive, ");
						break;
					default :
						result.append("Hint Unknown, ");
				}
			}

			scope = ai.getCollectionScope();
			switch (scope) {
				case 1 :
					result.append("Transaction, ");
					break;
				case 2 :
					result.append("ActivitySession, ");
					break;
				default :
					result.append("Scope Unknown, ");
			}

			result.append("Inc = " + ai.getCollectionIncrement() + ", ");
			result.append("PreFetch = " + ai.getResourceManagerPreFetchIncrement() + ", ");
			boolean readAhead = ai.getReadAheadHint() != null;
			result.append("ReadAhead = " + readAhead);
			result.append(")");
			return result.toString();
		}
	}

	public static EJBMethodInfo getEJBMethodInfo(EJSDeployedSupport s) {
		return (EJBMethodInfo) s.getEJBMethodInfoImpl();
	}

	public static EJBMethodInfo getEJBMethodInfo() {
		return getEJBMethodInfo(EJSContainer.getMethodContext());
	}

	public static EntityContainerTx getCurrentTx(EJSContainer container) throws CSITransactionRolledbackException {
		return toEntityContainerTx(container.getCurrentTx(false));
	}

	public static EntityContainerTx toEntityContainerTx(ContainerTx tx) {
		return (EntityContainerTx) tx;
	}

	public static EntityHomeRecord toEntityHomeRecord(HomeRecord homeRecord) {
		return (EntityHomeRecord) homeRecord;
	}

	public static ContainerTx toContainerTx(EntityContainerTx tx) {
		return (ContainerTx) tx;
	}

	public static PMHomeInfo getPMHomeInfo(EJSHome home) {
		return (PMHomeInfo) home.getHomeRecord();
	}
}