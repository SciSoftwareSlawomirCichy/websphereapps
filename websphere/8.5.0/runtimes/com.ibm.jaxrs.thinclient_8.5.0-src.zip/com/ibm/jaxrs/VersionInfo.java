package com.ibm.jaxrs;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.jar.Attributes;
import java.util.jar.JarFile;

public class VersionInfo {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		String className = VersionInfo.class.getName();
		className = "/" + className.replaceAll("\\.", "/") + ".class";
		URL url = VersionInfo.class.getResource(className);
		String fileName = url.toString().substring(9, url.toString().indexOf(33));
		JarFile jarfile = new JarFile(fileName);
		Attributes atts = jarfile.getManifest().getMainAttributes();
		System.out.println("IBM JAX-RS JAR Information:");
		System.out.println("Version: " + atts.getValue("Implementation-Version"));
		System.out.println("Build:   " + atts.getValue("Implementation-Build"));
	}
}