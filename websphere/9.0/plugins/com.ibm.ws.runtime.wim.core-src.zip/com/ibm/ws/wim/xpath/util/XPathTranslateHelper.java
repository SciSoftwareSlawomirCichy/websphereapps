package com.ibm.ws.wim.xpath.util;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;

public interface XPathTranslateHelper {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";

	void genSearchString(StringBuffer var1, XPathNode var2) throws WIMException;
}