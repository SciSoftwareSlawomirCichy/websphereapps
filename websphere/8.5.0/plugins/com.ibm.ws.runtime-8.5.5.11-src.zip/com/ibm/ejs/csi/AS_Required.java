package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.ws.ActivitySession.ActivitySession;
import com.ibm.ws.ffdc.FFDCFilter;
import javax.transaction.Transaction;

final class AS_Required extends ActivitySessionStrategy {
	private static final TraceComponent tc = Tr.register(AS_Required.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.csi.AS_Required";

	AS_Required(UOWControlImpl UOWCtrl) {
		super(UOWCtrl);
	}

	ASCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		boolean begun = false;
		Transaction suspendedGlobalTx = null;
		if (!this.ASExists()) {
			if (this.globalTxExists()) {
				suspendedGlobalTx = this.UOWCtrl.txCtrl.suspendGlobalTx(2);
			}

			this.beginAS();
			begun = true;
		}

		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		return new ASCookieImpl(begun, this, (ActivitySession) null, suspendedGlobalTx);
	}

	void postInvoke(EJBKey key, ASCookieImpl ASCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		CSIException saveCSIE = null;
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		try {
			if (ASCookie.beganAS()) {
				this.endAS();
			}
		} catch (CSIException var7) {
			saveCSIE = var7;
		}

		if (ASCookie.suspendedGlobalTx != null) {
			try {
				this.UOWCtrl.txCtrl.resumeGlobalTx(ASCookie.suspendedGlobalTx, 0);
			} catch (Exception var8) {
				FFDCFilter.processException(var8, "com.ibm.ejs.csi.AS_Required.postInvoke", "117", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Unexpected exception during postInvoke: ", var8);
				}
			}
		}

		if (saveCSIE != null) {
			if (entryEnabled) {
				Tr.exit(tc, "postInvoke. Exiting with exception.");
			}

			throw saveCSIE;
		} else {
			if (entryEnabled) {
				Tr.exit(tc, "postInvoke");
			}

		}
	}
}