package javax.ws.rs.core;

import java.net.URI;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Response.StatusType;
import javax.ws.rs.ext.RuntimeDelegate;

public abstract class Response {
	private static final RuntimeDelegate delegate = RuntimeDelegate.getInstance();

	public static ResponseBuilder created(URI location) {
		if (location == null) {
			throw new IllegalArgumentException();
		} else {
			return status(Status.CREATED).location(location);
		}
	}

	public static ResponseBuilder fromResponse(Response response) {
		ResponseBuilder builder = delegate.createResponseBuilder();
		builder.status(response.getStatus());
		builder.entity(response.getEntity());
		MultivaluedMap<String, Object> metadata = response.getMetadata();
		Iterator i$ = metadata.keySet().iterator();

		while (i$.hasNext()) {
			String key = (String) i$.next();
			List<Object> values = (List) metadata.get(key);
			Iterator i$ = values.iterator();

			while (i$.hasNext()) {
				Object value = i$.next();
				builder.header(key, value);
			}
		}

		return builder;
	}

	public abstract Object getEntity();

	public abstract MultivaluedMap<String, Object> getMetadata();

	public abstract int getStatus();

	public static ResponseBuilder noContent() {
		return status(Status.NO_CONTENT);
	}

	public static ResponseBuilder notAcceptable(List<Variant> variants) {
		ResponseBuilder builder = status(Status.NOT_ACCEPTABLE);
		return variants == null ? builder.variants(Collections.EMPTY_LIST) : builder.variants(variants);
	}

	public static ResponseBuilder notModified() {
		return status(Status.NOT_MODIFIED);
	}

	public static ResponseBuilder notModified(EntityTag tag) {
		if (tag == null) {
			throw new IllegalArgumentException();
		} else {
			return status(Status.NOT_MODIFIED).tag(tag);
		}
	}

	public static ResponseBuilder notModified(String tag) {
		if (tag == null) {
			throw new IllegalArgumentException();
		} else {
			return status(Status.NOT_MODIFIED).tag(tag);
		}
	}

	public static ResponseBuilder ok() {
		return status(Status.OK);
	}

	public static ResponseBuilder ok(Object entity) {
		return status(Status.OK).entity(entity);
	}

	public static ResponseBuilder ok(Object entity, MediaType type) {
		return status(Status.OK).entity(entity).type(type);
	}

	public static ResponseBuilder ok(Object entity, String type) {
		return status(Status.OK).entity(entity).type(type);
	}

	public static ResponseBuilder ok(Object entity, Variant variant) {
		return status(Status.OK).entity(entity).variant(variant);
	}

	public static ResponseBuilder seeOther(URI location) {
		if (location == null) {
			throw new IllegalArgumentException();
		} else {
			return status(Status.SEE_OTHER).location(location);
		}
	}

	public static ResponseBuilder serverError() {
		return status(Status.INTERNAL_SERVER_ERROR);
	}

	public static ResponseBuilder status(int status) {
		if (status >= 100 && status <= 599) {
			return ResponseBuilder.newInstance().status(status);
		} else {
			throw new IllegalArgumentException();
		}
	}

	public static ResponseBuilder status(Status status) {
		if (status == null) {
			throw new IllegalArgumentException();
		} else {
			return ResponseBuilder.newInstance().status(status);
		}
	}

	public static ResponseBuilder status(StatusType status) {
		if (status == null) {
			throw new IllegalArgumentException();
		} else {
			return ResponseBuilder.newInstance().status(status);
		}
	}

	public static ResponseBuilder temporaryRedirect(URI location) {
		return status(Status.TEMPORARY_REDIRECT).location(location);
	}
}