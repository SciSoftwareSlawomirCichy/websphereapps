package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_ro extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: Formater FFDC adăugat {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Motorul de analiză utilizând baza de date: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: A eşuat rezolvarea Motorului analiză:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: Colectorul de date FFDC adăugat {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: Colectorul de date FFDC înlăturat {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: Incident FFDC emis pe SystemErr: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC în modul de siguranţă, verificaţi pentru erorile {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: Forwarder incident FFDC adăugat {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: Forwarder incident FFDC înlăturat {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Incident FFDC emis pe {0} {1} {2}"},
			{"FFDCProviderAborted", "FFDC1000I: Furnizorul FFDC {0} a renunţat, urmează excepţia"},
			{"FFDCProviderAbortedE", "FFDC1001I: Furnizorul FFDC a renunţat cu excepţia {0}"},
			{"FFDCProviderException", "FFDC1008I: Furnizorul FFDC excepţie:"},
			{"FFDCProviderInstalled", "FFDC1007I: Furnizorul FFDC instalat: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: Formater FFDC înlăturat {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}