package com.ibm.ws.wim;

import commonj.sdo.DataObject;
import java.io.Serializable;

public class PageCacheEntry implements Serializable {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private int totalSize;
	private DataObject rootDO = null;
	private DataObject propControl = null;

	public PageCacheEntry() {
	}

	public PageCacheEntry(int var1, DataObject var2) {
		this.totalSize = var1;
		this.rootDO = var2;
	}

	public int getTotalSize() {
		return this.totalSize;
	}

	public DataObject getDataObject() {
		return this.rootDO;
	}

	public void setTotalSize(int var1) {
		this.totalSize = var1;
	}

	public void setDataObject(DataObject var1) {
		this.rootDO = var1;
	}
}