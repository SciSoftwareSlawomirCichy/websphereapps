package com.ibm.ejs.container.finder;

import java.util.Iterator;

public class FinderResultClientIterator_Local extends FinderResultClientBase_Local implements Iterator {
	public FinderResultClientIterator_Local(FinderResultServerImpl serverImpl) {
		super(serverImpl);
	}

	public boolean hasNext() {
		return this.hasMoreElements();
	}

	public Object next() {
		return this.nextElement();
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}
}