package com.ibm.ejs.cm.pool;

import com.ibm.ejs.cm.portability.PortableSQLException;

public class ConnectionWaitTimeoutException extends PortableSQLException {
	private static final long serialVersionUID = 3577285680276438863L;

	public ConnectionWaitTimeoutException(String message) {
		super(message);
	}

	public ConnectionWaitTimeoutException() {
		super("Timeout waiting for free connection");
	}
}