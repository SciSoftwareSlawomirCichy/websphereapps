package javax.ws.rs;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface HttpMethod {
	String DELETE = "DELETE";
	String GET = "GET";
	String HEAD = "HEAD";
	String POST = "POST";
	String PUT = "PUT";
	String OPTIONS = "OPTIONS";

	String value();
}