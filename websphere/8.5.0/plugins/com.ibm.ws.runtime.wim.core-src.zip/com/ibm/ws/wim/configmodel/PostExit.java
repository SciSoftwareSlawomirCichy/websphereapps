package com.ibm.ws.wim.configmodel;

public interface PostExit {
	ModificationSubscriberList getModificationSubscriberList();

	void setModificationSubscriberList(ModificationSubscriberList var1);

	ModificationSubscriberList createModificationSubscriberList();

	NotificationSubscriberList getNotificationSubscriberList();

	void setNotificationSubscriberList(NotificationSubscriberList var1);

	NotificationSubscriberList createNotificationSubscriberList();
}