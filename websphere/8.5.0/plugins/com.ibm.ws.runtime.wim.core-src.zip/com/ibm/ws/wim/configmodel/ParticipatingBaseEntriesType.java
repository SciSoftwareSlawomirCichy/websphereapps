package com.ibm.ws.wim.configmodel;

public interface ParticipatingBaseEntriesType {
	String getName();

	void setName(String var1);
}