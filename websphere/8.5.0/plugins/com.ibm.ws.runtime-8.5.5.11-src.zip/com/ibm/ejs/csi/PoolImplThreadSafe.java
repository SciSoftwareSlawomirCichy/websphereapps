package com.ibm.ejs.csi;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.PoolDiscardStrategy;
import com.ibm.websphere.csi.PooledObject;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import com.ibm.ws.util.LockFreeIndexedStack;
import com.ibm.ws.util.LockFreeIndexedStack.StackNode;

public final class PoolImplThreadSafe extends PoolImplBase {
	private static final String CLASS_NAME = PoolImplThreadSafe.class.getName();
	private static final TraceComponent tc;
	private final LockFreeIndexedStack<Object> buffer = new LockFreeIndexedStack();
	private final PoolDiscardStrategy discardStrategy;
	private int maxDrainAmount;
	private int ivInactiveNoDrainCount;
	private boolean ivManaged;
	private final EJBPMICollaborator beanPerf;

	PoolImplThreadSafe(int min, int max, int drainAggressivenessPercentage, EJBPMICollaborator pmiBean,
			PoolDiscardStrategy d, PoolManagerImpl poolManager) {
		this.minSize = min;
		this.maxSize = max;
		this.discardStrategy = d;
		this.poolMgr = poolManager;
		this.beanPerf = pmiBean;
		int drainOpportunity = this.maxSize - this.minSize;
		if (drainOpportunity <= 0) {
			this.maxDrainAmount = 0;
		} else if (drainOpportunity <= 100 / drainAggressivenessPercentage) {
			this.maxDrainAmount = drainOpportunity;
		} else {
			this.maxDrainAmount = drainOpportunity * drainAggressivenessPercentage / 100;
		}

		if (this.beanPerf != null) {
			this.beanPerf.poolCreated(0);
		}

	}

	public final Object get() {
		Object o = this.buffer.pop();
		if (this.beanPerf != null) {
			this.beanPerf.objectRetrieve(this.buffer.size(), o != null);
		}

		return o;
	}

	public final void put(Object o) {
		boolean discarded = false;
		if (o instanceof PooledObject) {
			((PooledObject) o).reset();
		}

		if (this.inactive) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "setting active: " + this);
			}

			this.inactive = false;
			synchronized (this) {
				if (!this.ivManaged) {
					this.poolMgr.add(this);
					this.ivManaged = true;
				}
			}
		}

		discarded = !this.buffer.pushWithLimit(o, this.maxSize);
		if (discarded) {
			if (o instanceof PooledObject) {
				((PooledObject) o).discard();
			} else if (this.discardStrategy != null) {
				this.discardStrategy.discard(o);
			}
		}

		if (this.beanPerf != null) {
			this.beanPerf.objectReturn(this.buffer.size(), discarded);
		}

	}

	final void periodicDrain() {
		int numDiscarded = 0;
		Object o = null;

		while (numDiscarded < this.maxDrainAmount) {
			o = this.buffer.popWithLimit(this.minSize);
			if (o == null) {
				break;
			}

			++numDiscarded;
			if (o instanceof PooledObject) {
				((PooledObject) o).discard();
			} else if (this.discardStrategy != null) {
				this.discardStrategy.discard(o);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "periodicDrain: numDiscarded=" + numDiscarded + ", inactive=" + this.ivInactiveNoDrainCount
					+ ", " + this);
		}

		if (numDiscarded == 0) {
			++this.ivInactiveNoDrainCount;
			if (this.ivInactiveNoDrainCount > 4) {
				synchronized (this) {
					this.poolMgr.remove(this);
					this.ivManaged = false;
				}

				this.ivInactiveNoDrainCount = 0;
			}
		} else {
			this.ivInactiveNoDrainCount = 0;
		}

		if (this.beanPerf != null) {
			this.beanPerf.poolDrained(this.buffer.size(), numDiscarded);
		}

	}

	final void completeDrain() {
		Object o = null;
		int numDiscarded = this.buffer.size();

		for (StackNode oldTop = this.buffer.clean(); oldTop != null; oldTop = oldTop.getNext()) {
			o = oldTop.getValue();
			if (o instanceof PooledObject) {
				((PooledObject) o).discard();
			} else if (this.discardStrategy != null) {
				this.discardStrategy.discard(o);
			}
		}

		if (this.beanPerf != null) {
			this.beanPerf.poolDrained(0, numDiscarded);
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", (String) null);
	}
}