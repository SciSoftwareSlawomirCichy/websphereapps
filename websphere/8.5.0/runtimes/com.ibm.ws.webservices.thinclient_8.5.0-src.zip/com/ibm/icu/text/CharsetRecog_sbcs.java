package com.ibm.icu.text;

import com.ibm.icu.text.CharsetRecog_sbcs.NGramParser;

abstract class CharsetRecog_sbcs extends CharsetRecognizer {
	protected boolean haveC1Bytes = false;

	abstract String getName();

	abstract int match(CharsetDetector var1);

	int match(CharsetDetector det, int[] ngrams, byte[] byteMap) {
		return this.match(det, ngrams, byteMap, (byte) 32);
	}

	int match(CharsetDetector det, int[] ngrams, byte[] byteMap, byte spaceChar) {
		NGramParser parser = new NGramParser(ngrams, byteMap);
		this.haveC1Bytes = det.fC1Bytes;
		return parser.parse(det, spaceChar);
	}
}