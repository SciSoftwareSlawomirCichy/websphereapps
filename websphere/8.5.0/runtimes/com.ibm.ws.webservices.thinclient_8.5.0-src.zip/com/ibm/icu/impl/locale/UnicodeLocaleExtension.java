package com.ibm.icu.impl.locale;

import com.ibm.icu.impl.locale.LanguageTag.ParseStatus;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;

public class UnicodeLocaleExtension extends Extension {
	public static final char SINGLETON = 'u';
	public static final UnicodeLocaleExtension CA_JAPANESE = (new UnicodeLocaleExtension()).put("ca", "japanese");
	public static final UnicodeLocaleExtension NU_THAI = (new UnicodeLocaleExtension()).put("nu", "thai");
	private SortedMap<String, String> _keyTypeMap;

	protected UnicodeLocaleExtension() {
		super('u');
	}

	UnicodeLocaleExtension(SortedMap<String, String> keyTypeMap) {
		super('u');
		this._keyTypeMap = keyTypeMap;
		this.updateStringValue();
	}

	protected void setExtensionValue(StringTokenIterator itr, ParseStatus sts) {
		if (!sts.isError() && !itr.isDone()) {
			SortedMap<String, String> keyTypeMap = new TreeMap();
			String ukey = null;
			StringBuilder buf = new StringBuilder();

			for (int typeEnd = -1; !itr.isDone(); itr.next()) {
				String s = itr.current();
				if (isTypeSubtag(s)) {
					if (ukey == null) {
						sts.errorIndex = itr.currentStart();
						sts.errorMsg = "Invalid Unicode locale extension key: " + s;
						break;
					}

					if (buf.length() > 0) {
						buf.append("-");
					}

					buf.append(canonicalizeTypeSubtag(s));
					typeEnd = itr.currentEnd();
					if (!itr.hasNext()) {
						keyTypeMap.put(ukey, buf.toString());
						sts.parseLength = typeEnd;
						itr.next();
						break;
					}
				} else {
					if (ukey != null) {
						if (buf.length() <= 0) {
							sts.errorIndex = itr.currentStart();
							sts.errorMsg = "Invalid Unicode locale extension type: " + s;
							break;
						}

						keyTypeMap.put(ukey, buf.toString());
						sts.parseLength = typeEnd;
					}

					if (!isKey(s)) {
						if (keyTypeMap.size() == 0) {
							sts.errorIndex = itr.currentStart();
							sts.errorMsg = "Invalid Unicode locale extension key: " + s;
						}
						break;
					}

					if (!itr.hasNext()) {
						sts.errorIndex = itr.currentStart();
						sts.errorMsg = "Missing subtag for Unicode locale extension: " + s;
						itr.next();
						break;
					}

					ukey = canonicalizeKey(s);
					if (keyTypeMap.containsKey(ukey)) {
						sts.errorIndex = itr.currentStart();
						sts.errorMsg = "Duplicate Unicode locale extension key: " + s;
						break;
					}

					buf.setLength(0);
					typeEnd = -1;
				}
			}

			if (keyTypeMap.size() == 0) {
				this._value = null;
			} else {
				this._keyTypeMap = keyTypeMap;
				this.updateStringValue();
			}
		} else {
			this._value = null;
		}
	}

	public Set<String> getKeys() {
		return this._keyTypeMap == null
				? Collections.emptySet()
				: Collections.unmodifiableSet(this._keyTypeMap.keySet());
	}

	public String getType(String key) {
		String type = null;
		if (this._keyTypeMap != null) {
			type = (String) this._keyTypeMap.get(canonicalizeKey(key));
		}

		return type == null ? "" : type;
	}

	public static boolean isKey(String s) {
		return s.length() == 2 && AsciiUtil.isAlphaNumericString(s);
	}

	public static boolean isTypeSubtag(String s) {
		return s.length() >= 3 && s.length() <= 8 && AsciiUtil.isAlphaNumericString(s);
	}

	public static String canonicalizeKey(String s) {
		return LanguageTag.canonicalizeExtensionSubtag(s);
	}

	public static String canonicalizeTypeSubtag(String s) {
		return LanguageTag.canonicalizeExtensionSubtag(s);
	}

	UnicodeLocaleExtension remove(String key) {
		if (this._keyTypeMap != null) {
			this._keyTypeMap.remove(key);
			this.updateStringValue();
		}

		return this;
	}

	UnicodeLocaleExtension put(String key, String type) {
		if (this._keyTypeMap == null) {
			this._keyTypeMap = new TreeMap();
		}

		this._keyTypeMap.put(key, type);
		this.updateStringValue();
		return this;
	}

	boolean isEmpty() {
		return this._keyTypeMap.size() == 0;
	}

	private void updateStringValue() {
		this._value = null;
		if (this._keyTypeMap != null) {
			StringBuilder valBuf = new StringBuilder();
			Set<Entry<String, String>> entries = this._keyTypeMap.entrySet();
			boolean isFirst = true;
			Iterator i$ = entries.iterator();

			while (i$.hasNext()) {
				Entry<String, String> e = (Entry) i$.next();
				if (isFirst) {
					isFirst = false;
				} else {
					valBuf.append("-");
				}

				valBuf.append((String) e.getKey());
				valBuf.append("-");
				valBuf.append((String) e.getValue());
			}

			if (valBuf.length() > 0) {
				this._value = valBuf.toString();
			}
		}

	}
}