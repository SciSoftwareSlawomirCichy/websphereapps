package com.ibm.ws.bootstrap;

import com.ibm.ws.bootstrap.WsLogManager.1;
import com.ibm.ws.logging.WsLogger;
import java.security.AccessController;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class WsLogManager extends LogManager {
	private static final String CHECK_CALLING_METHOD_FOR_GETLOGGER = "com.ibm.ws.bootstrap.logmanager.createNewLogger";
	private static boolean checkCallingMethodForGetLogger = "false"
			.equalsIgnoreCase(safelyGetSystemProperty("com.ibm.ws.bootstrap.logmanager.createNewLogger"));

	public static final void initialiseForRasLite() {
	}

	public synchronized Logger getLogger(String name) {
		Logger logger = super.getLogger(name);
		if (logger == null) {
			boolean createNewLogger = true;
			if (checkCallingMethodForGetLogger) {
				createNewLogger = false;
				boolean foundThisMethod = false;
				Exception ex = new Exception();
				StackTraceElement[] ste = ex.getStackTrace();

				for (int i = 0; i < ste.length; ++i) {
					if (foundThisMethod) {
						if (ste[i].getClassName().equals("java.util.logging.Logger")
								&& ste[i].getMethodName().startsWith("getLogger")) {
							createNewLogger = true;
						}
						break;
					}

					if (ste[i].getClassName().equals("com.ibm.ws.bootstrap.WsLogManager")
							&& ste[i].getMethodName().equals("getLogger")) {
						foundThisMethod = true;
					}
				}
			}

			if (createNewLogger) {
				logger = new WsLogger(name, (String) null);
				if (logger != null) {
					this.addLogger((Logger) logger);
				}
			}
		}

		return (Logger) logger;
	}

	private static String safelyGetSystemProperty(String key) {
      String rc = null;

      try {
         rc = (String)AccessController.doPrivileged(new 1(key));
      } catch (Exception var3) {
         ;
      }

      return rc;
   }
}