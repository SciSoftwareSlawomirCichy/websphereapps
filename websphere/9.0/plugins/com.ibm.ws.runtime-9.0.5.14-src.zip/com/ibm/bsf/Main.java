package com.ibm.bsf;

import com.ibm.bsf.Main.1;
import com.ibm.bsf.util.CodeBuffer;
import com.ibm.bsf.util.IOUtils;
import java.awt.Component;
import java.awt.Frame;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.Hashtable;

public class Main {
	private static String ARG_IN = "-in";
	private static String ARG_LANG = "-lang";
	private static String ARG_MODE = "-mode";
	private static String ARG_OUT = "-out";
	private static String ARG_VAL_EVAL = "eval";
	private static String ARG_VAL_EXEC = "exec";
	private static String ARG_VAL_COMPILE = "compile";
	private static String DEFAULT_IN_FILE_NAME = "<STDIN>";
	private static String DEFAULT_MODE;
	private static String DEFAULT_CLASS_NAME;

	public static void main(String[] var0) throws IOException {
      try {
         if (var0.length == 0 || var0.length % 2 != 0) {
            printHelp();
            System.exit(1);
         }

         Hashtable var1 = new Hashtable();
         var1.put(ARG_OUT, DEFAULT_CLASS_NAME);
         var1.put(ARG_MODE, DEFAULT_MODE);

         for(int var2 = 0; var2 < var0.length; var2 += 2) {
            var1.put(var0[var2], var0[var2 + 1]);
         }

         String var12 = (String)var1.get(ARG_IN);
         String var3 = (String)var1.get(ARG_LANG);
         if (var3 == null) {
            if (var12 == null) {
               throw new BSFException(BSFException.REASON_OTHER_ERROR, "unable to determine language");
            }

            var3 = BSFManager.getLangFromFilename(var12);
         }

         Object var4;
         if (var12 != null) {
            var4 = new FileReader(var12);
         } else {
            var4 = new InputStreamReader(System.in);
            var12 = "<STDIN>";
         }

         BSFManager var5 = new BSFManager();
         String var6 = (String)var1.get(ARG_MODE);
         if (var6.equals(ARG_VAL_COMPILE)) {
            String var7 = (String)var1.get(ARG_OUT);
            FileWriter var8 = new FileWriter(var7 + ".java");
            PrintWriter var9 = new PrintWriter(var8);
            CodeBuffer var10 = new CodeBuffer();
            var10.setClassName(var7);
            var5.compileScript(var3, var12, 0, 0, IOUtils.getStringFromReader((Reader)var4), var10);
            var10.print(var9, true);
            var8.close();
         } else if (var6.equals(ARG_VAL_EXEC)) {
            var5.exec(var3, var12, 0, 0, IOUtils.getStringFromReader((Reader)var4));
         } else {
            Object var13 = var5.eval(var3, var12, 0, 0, IOUtils.getStringFromReader((Reader)var4));
            if (var13 instanceof Component) {
               Frame var14;
               if (var13 instanceof Frame) {
                  var14 = (Frame)var13;
               } else {
                  var14 = new Frame("BSF Result: " + var12);
                  var14.add((Component)var13);
               }

               var14.addWindowListener(new 1());
               var14.pack();
               var14.show();
            } else {
               System.err.println("Result: " + var13);
            }

            System.err.println("Result: " + var13);
         }
      } catch (BSFException var11) {
         var11.printStackTrace();
      }

   }

	private static void printHelp() {
		System.err.println("Usage:");
		System.err.println();
		System.err.println("  java " + (class$com$ibm$bsf$Main == null
				? (class$com$ibm$bsf$Main = class$("com.ibm.bsf.Main"))
				: class$com$ibm$bsf$Main).getName() + " [args]");
		System.err.println();
		System.err.println("    args:");
		System.err.println();
		System.err.println("      [-in                fileName]   default: " + DEFAULT_IN_FILE_NAME);
		System.err.println("      [-lang          languageName]   default: <If -in is specified and -lang");
		System.err.println("                                                is not, attempt to determine");
		System.err.println("                                                language from file extension;");
		System.err.println("                                                otherwise, -lang is required.>");
		System.err.println("      [-mode   (eval|exec|compile)]   default: " + DEFAULT_MODE);
		System.err.println();
		System.err.println("    Additional args used only if -mode is set to \"compile\":");
		System.err.println();
		System.err.println("      [-out              className]   default: " + DEFAULT_CLASS_NAME);
	}

	static {
		DEFAULT_MODE = ARG_VAL_EVAL;
		DEFAULT_CLASS_NAME = "Test";
	}
}