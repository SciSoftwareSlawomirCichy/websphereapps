package com.ibm.ejs.cm.portability;

import java.sql.SQLException;

public final class TableAlreadyExistsException extends PortableSQLException {
	private static final long serialVersionUID = -624506883471442403L;

	TableAlreadyExistsException(SQLException nativeException) {
		super(nativeException);
	}

	TableAlreadyExistsException() {
	}
}