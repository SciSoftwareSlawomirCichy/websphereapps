package com.ibm.ejs.container.passivator;

import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.websphere.csi.SessionBeanStore;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ejbcontainer.runtime.JCDIHelper;
import com.ibm.ws.managedobject.ManagedObjectState;
import com.ibm.ws.metadata.ejb.JCDIManagedObjectImpl;
import com.ibm.ws.runtime.component.WASJCDIHelper;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class WASStatefulPassivator extends SharedStatefulPassivator {
	public WASStatefulPassivator(SessionBeanStore beanStore, EJSContainer container, SfFailoverCache failoverCache) {
		super(beanStore, container, failoverCache);
	}

	protected void writeManagedObjectState(ObjectOutputStream oos, ManagedObjectState state) {
	}

	protected ManagedObjectState readManagedObjectState(ObjectInputStream ois, BeanMetaData bmd, Object instance) {
		JCDIHelper jcdiHelper = bmd._moduleMetaData.ivJCDIHelper;
		return jcdiHelper == null ? null : new JCDIManagedObjectImpl((WASJCDIHelper) jcdiHelper, instance);
	}
}