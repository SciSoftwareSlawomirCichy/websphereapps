package com.ibm.ejs.container.drs;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.FastHashtable;
import com.ibm.ws.ejbcontainer.failover.SfFailoverClient;
import com.ibm.ws.ejbcontainer.failover.SfFailoverKey;
import com.ibm.wsspi.cluster.Identity;
import com.ibm.wsspi.drs.DRSDataXfer;
import com.ibm.wsspi.drs.DRSEventObject;
import java.util.Enumeration;

public final class SfDRSClient implements SfFailoverClient {
	private static final String CLASS_NAME = "com.ibm.ejs.container.drs.SfDRSClient";
	private static final TraceComponent tc = Tr.register("com.ibm.ejs.container.drs.SfDRSClient", "EJBDRSCache",
			"com.ibm.ejs.container.container");
	private DRSDataXfer ivBaseDataXfer = null;
	private String ivInstanceId;
	private FastHashtable<BeanId, SfDRSCacheEntry> ivCache = new FastHashtable(97);
	SfDRSCacheMsgListener ivSfDRSCacheMsgListener;

	public SfDRSClient(DRSDataXfer baseDRSDataXfer, String id, SfDRSCacheMsgListener ml) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSClient CTOR for ID = " + id);
		}

		this.ivInstanceId = id;
		this.ivBaseDataXfer = baseDRSDataXfer;
		this.ivSfDRSCacheMsgListener = ml;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSClient CTOR for ID = " + id);
		}

	}

	public void activated(BeanId beanId, long lastAccessTime) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "activated, beanId is: " + beanId);
		}

		SfDRSCacheEntry cacheEntry = (SfDRSCacheEntry) this.ivCache.get(beanId);
		if (cacheEntry != null) {
			beanId.getByteArray();
			synchronized (cacheEntry) {
				++cacheEntry.ivSequenceNumber;
				cacheEntry.ivPassivated = false;
				cacheEntry.ivLastAccessTime = lastAccessTime;
				cacheEntry.replicate(this.ivBaseDataXfer);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "activated, beanId is: " + beanId);
		}

	}

	public void passivated(BeanId beanId, byte[] data, long lastAccessTime) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "passivated, beanId is: " + beanId);
		}

		SfDRSCacheEntry cacheEntry = (SfDRSCacheEntry) this.ivCache.get(beanId);
		if (cacheEntry != null) {
			beanId.getByteArray();
			synchronized (cacheEntry) {
				++cacheEntry.ivSequenceNumber;
				cacheEntry.ivPassivated = true;
				cacheEntry.ivLastAccessTime = lastAccessTime;
				cacheEntry.ivData = data;
				cacheEntry.replicate(this.ivBaseDataXfer);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "passivated, beanId is: " + beanId);
		}

	}

	public void createEntry(BeanId beanId, long timeout) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "createEntry beanId is: " + beanId);
		}

		SfDRSCacheEntry cacheEntry = new SfDRSCacheEntry(beanId, timeout);
		FastHashtable var5 = this.ivCache;
		synchronized (this.ivCache) {
			this.ivCache.put(beanId, cacheEntry);
		}

		synchronized (cacheEntry) {
			++cacheEntry.ivSequenceNumber;
			cacheEntry.replicate(this.ivBaseDataXfer);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "createEntry ");
		}

	}

	void createEntry(BeanId beanId, SfDRSCacheEntry cacheEntry) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "createEntry bean ID is: " + beanId);
		}

		FastHashtable var3 = this.ivCache;
		synchronized (this.ivCache) {
			this.ivCache.put(beanId, cacheEntry);
		}

		synchronized (cacheEntry) {
			cacheEntry.replicate(this.ivBaseDataXfer);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "createEntry ");
		}

	}

	public void event(DRSEventObject eventObject) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "eventObject = " + eventObject);
		}

		int event = eventObject.getEvent();
		switch (event) {
			case 1 :
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "received event REPLICATION_UP.");
				}

				this.retryReplication();
				break;
			case 2 :
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "received event REPLICATION_DOWN.");
				}
				break;
			case 3 :
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "received event IS_CONGESTED.");
				}
				break;
			case 4 :
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "received event NOT_CONGESTED.");
				}

				this.retryReplication();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "eventObject = " + eventObject);
		}

	}

	public SfDRSCacheEntry getEntry(BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEntry beanId is: " + beanId);
		}

		SfDRSCacheEntry entry = null;

		try {
			SfFailoverKey key = beanId.getFailoverKey();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getEntry key: " + key);
			}

			entry = (SfDRSCacheEntry) this.ivBaseDataXfer.getEntry(key);
		} catch (Throwable var4) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getEntry failed for entryKey = " + beanId);
				Tr.debug(tc, "caught Throwable: ", var4);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEntry ");
		}

		return entry;
	}

	public void removeEntry(BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "removeEntry beanId is: " + beanId);
		}

		SfDRSCacheEntry cacheEntry = null;
		FastHashtable var3 = this.ivCache;
		synchronized (this.ivCache) {
			cacheEntry = (SfDRSCacheEntry) this.ivCache.remove(beanId);
		}

		try {
			if (cacheEntry != null) {
				++cacheEntry.ivSequenceNumber;
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "removing DRS entry, " + cacheEntry);
				}

				this.ivBaseDataXfer.removeEntry(cacheEntry.ivKey);
			}
		} catch (Throwable var6) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "removeEntry(BeanId) failure, using removeLocalEntry to recover from failure", var6);
			}

			this.removeLocalEntry(cacheEntry.ivKey);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "removeEntry ");
		}

	}

	private void retryReplication() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "retryReplication", this);
		}

		FastHashtable var1 = this.ivCache;
		synchronized (this.ivCache) {
			Enumeration e = this.ivCache.elements();

			while (e.hasMoreElements()) {
				SfDRSCacheEntry cacheEntry = (SfDRSCacheEntry) e.nextElement();
				if (cacheEntry != null) {
					synchronized (cacheEntry) {
						if (cacheEntry.ivDRSState != 0L) {
							cacheEntry.replicate(this.ivBaseDataXfer);
						}
					}
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "retryReplication");
		}

	}

	public boolean entryIDExists(BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "entryIDExists beanId is: " + beanId);
		}

		boolean entry = false;

		try {
			SfFailoverKey key = beanId.getFailoverKey();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "entryIDExists key: " + key);
			}

			entry = this.ivBaseDataXfer.entryIDExists(key);
		} catch (Throwable var4) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "entryIDExists failed for entryKey = " + beanId);
				Tr.debug(tc, "caught Throwable: ", var4);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "entryIDExists returning " + entry);
		}

		return entry;
	}

	public Identity getWLMIdentity(BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getWLMIdentity, beanId is: " + beanId);
		}

		SfFailoverKey key = beanId.getFailoverKey();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getWLMIdentity key: " + key);
		}

		Identity clusterId = this.ivBaseDataXfer.getWLMIdentity(key, true);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getWLMIdentity returning WLM Identity: " + clusterId);
		}

		return clusterId;
	}

	public String toString() {
		return "SfDRSClient for ID: " + this.ivInstanceId;
	}

	public void stickyUOW(BeanId beanId, boolean isActive) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "stickyUOW, state is " + isActive);
		}

		SfDRSCacheEntry cacheEntry = (SfDRSCacheEntry) this.ivCache.get(beanId);
		if (cacheEntry != null) {
			beanId.getByteArray();
			synchronized (cacheEntry) {
				++cacheEntry.ivSequenceNumber;
				cacheEntry.ivStickyUOW = isActive;
				cacheEntry.replicate(this.ivBaseDataXfer);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "stickyUOW");
		}

	}

	Identity getWLMIdentity(SfFailoverKey key) {
		return this.ivBaseDataXfer.getWLMIdentity(key, false);
	}

	void removeEntry(SfFailoverKey key) {
		try {
			this.ivBaseDataXfer.removeEntry(key);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "removeEntry( SfFailoverKey ) removed DRS entry key = " + key);
			}
		} catch (Throwable var3) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "removeEntry(SfFailoverKey) failure, using removeLocalEntry to recover from failure",
						var3);
			}

			this.removeLocalEntry(key);
		}

	}

	public void removeLocalEntry(SfFailoverKey key) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "removeLocalEntry for key = " + key);
		}

		this.ivBaseDataXfer.removeLocalEntry(key);
	}
}