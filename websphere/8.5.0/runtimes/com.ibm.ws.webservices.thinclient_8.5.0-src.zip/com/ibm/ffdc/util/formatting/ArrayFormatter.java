package com.ibm.ffdc.util.formatting;

import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.config.IncidentStream;
import com.ibm.ffdc.config.IncidentStream.Writer;
import com.ibm.ffdc.util.Klass;
import com.ibm.ffdc.util.formatting.ArrayFormatter.1;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Array;

public class ArrayFormatter implements Formatter {
	public final void formatTo(Object o, IncidentStream is) {
      Class<?> cl = o.getClass();
      Class<?> componentType = cl.getComponentType();
      if (componentType == null) {
         throw new IllegalArgumentException();
      } else if (Klass.isPrimitive(componentType)) {
         Writer<OutputStream> writer = new 1(this, o);
         is.write(writer);
      } else {
         this.formatTo(is, o);
      }
   }

	private void formatTo(PrintWriter pw, Object objectToFormat) {
		int alength = Array.getLength(objectToFormat);
		pw.print('[');

		for (int i = 0; i < alength; ++i) {
			Object o = Array.get(objectToFormat, i);
			pw.print(o);
			pw.print((char) (alength - i == 1 ? ']' : ' '));
		}

		pw.println();
	}

	private void formatTo(IncidentStream is, Object objectToFormat) {
		int alength = Array.getLength(objectToFormat);
		is.write((String) null, '[');

		for (int i = 0; i < alength; ++i) {
			Object o = Array.get(objectToFormat, i);
			is.write((String) null, o);
		}

		is.write((String) null, ']');
	}

	public String[] getSupportedTypeNames() {
		return new String[]{"[.*"};
	}

	public boolean isSupported(Class<?> klass) {
		return klass.isArray();
	}
}