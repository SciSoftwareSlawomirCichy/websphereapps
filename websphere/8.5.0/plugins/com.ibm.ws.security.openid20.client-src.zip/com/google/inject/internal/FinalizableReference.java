package com.google.inject.internal;

public interface FinalizableReference {
	void finalizeReferent();
}