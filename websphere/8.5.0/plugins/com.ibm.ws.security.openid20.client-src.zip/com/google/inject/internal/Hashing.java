package com.google.inject.internal;

final class Hashing {
	private static final int MAX_TABLE_SIZE = 1073741824;
	private static final int CUTOFF = 536870912;

	static int smear(int hashCode) {
		hashCode ^= hashCode >>> 20 ^ hashCode >>> 12;
		return hashCode ^ hashCode >>> 7 ^ hashCode >>> 4;
	}

	static int chooseTableSize(int setSize) {
		if (setSize < 536870912) {
			return Integer.highestOneBit(setSize) << 2;
		} else {
			Preconditions.checkArgument(setSize < 1073741824, "collection too large");
			return 1073741824;
		}
	}
}