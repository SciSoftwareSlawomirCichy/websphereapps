package com.ibm.ejs.container;

public class InvalidJarFileNameException extends ContainerException {
	private static final long serialVersionUID = -8291283892884860366L;

	public InvalidJarFileNameException(String s) {
		super(s);
	}
}