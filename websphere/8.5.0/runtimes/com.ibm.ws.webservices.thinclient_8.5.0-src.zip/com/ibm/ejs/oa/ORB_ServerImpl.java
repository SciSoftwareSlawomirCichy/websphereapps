package com.ibm.ejs.oa;

import com.ibm.CORBA.iiop.ORB;
import com.ibm.ws.orb.services.lsd._ORB_ServerImplBase;

public class ORB_ServerImpl extends _ORB_ServerImplBase {
	private static final long serialVersionUID = -5812437449401265271L;
	protected static final ORB_ServerImpl orbServer = new ORB_ServerImpl();
	protected ORB factory = null;
	protected LocationService locationService = null;

	public void init(ORB orb, LocationService ls) {
		this.factory = orb;
		this.locationService = ls;
	}

	public static ORB_ServerImpl getORBServer() {
		return orbServer;
	}

	public boolean ping() {
		return true;
	}

	public boolean reregistration_required(com.ibm.ws.orb.services.lsd.LocationService ls, byte[] lsdPrototype) {
		try {
			this.locationService.register(this.factory);
		} catch (Exception var4) {
			;
		}

		return false;
	}

	public boolean activate_object_adapter(byte[] adapter_name) {
		LocationService var10000 = this.locationService;
		LocationService.registerObjectAdapter(this.factory, new String(adapter_name));
		return true;
	}
}