package com.google.common.util.concurrent;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.AggregateFutureState.1;
import com.google.common.util.concurrent.AggregateFutureState.AtomicHelper;
import com.google.common.util.concurrent.AggregateFutureState.SafeAtomicHelper;
import com.google.common.util.concurrent.AggregateFutureState.SynchronizedAtomicHelper;
import com.google.j2objc.annotations.ReflectionSupport;
import com.google.j2objc.annotations.ReflectionSupport.Level;
import java.util.Set;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.logging.Logger;

@GwtCompatible(emulated = true)
@ReflectionSupport(Level.FULL)
abstract class AggregateFutureState {
	private volatile Set<Throwable> seenExceptions = null;
	private volatile int remaining;
	private static final AtomicHelper ATOMIC_HELPER;
	private static final Logger log = Logger.getLogger(AggregateFutureState.class.getName());

	AggregateFutureState(int remainingFutures) {
		this.remaining = remainingFutures;
	}

	final Set<Throwable> getOrInitSeenExceptions() {
		Set<Throwable> seenExceptionsLocal = this.seenExceptions;
		if (seenExceptionsLocal == null) {
			seenExceptionsLocal = Sets.newConcurrentHashSet();
			this.addInitialException(seenExceptionsLocal);
			ATOMIC_HELPER.compareAndSetSeenExceptions(this, (Set) null, seenExceptionsLocal);
			seenExceptionsLocal = this.seenExceptions;
		}

		return seenExceptionsLocal;
	}

	abstract void addInitialException(Set<Throwable> var1);

	final int decrementRemainingAndGet() {
		return ATOMIC_HELPER.decrementAndGetRemainingCount(this);
	}

	static {
      Throwable thrownReflectionFailure = null;

      Object helper;
      try {
         helper = new SafeAtomicHelper(AtomicReferenceFieldUpdater.newUpdater(AggregateFutureState.class, Set.class, "seenExceptions"), AtomicIntegerFieldUpdater.newUpdater(AggregateFutureState.class, "remaining"));
      } catch (Throwable var3) {
         thrownReflectionFailure = var3;
         helper = new SynchronizedAtomicHelper((1)null);
      }

      ATOMIC_HELPER = (AtomicHelper)helper;
      if (thrownReflectionFailure != null) {
         log.log(java.util.logging.Level.SEVERE, "SafeAtomicHelper is broken!", thrownReflectionFailure);
      }

   }
}