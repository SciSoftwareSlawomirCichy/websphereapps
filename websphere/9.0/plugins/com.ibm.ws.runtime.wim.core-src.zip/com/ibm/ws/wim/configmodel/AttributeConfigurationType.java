package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface AttributeConfigurationType {
	List getExternalIdAttributes();

	AttributeType[] getExternalIdAttributesAsArray();

	AttributeType createExternalIdAttributes();

	List getAttributes();

	AttributeType[] getAttributesAsArray();

	AttributeType createAttributes();

	List getPropertiesNotSupported();

	PropertiesNotSupportedType[] getPropertiesNotSupportedAsArray();

	PropertiesNotSupportedType createPropertiesNotSupported();
}