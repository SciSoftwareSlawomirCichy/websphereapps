package com.ibm.ws.wim.dao.schema;

import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.dao.DAOHelper;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JDBCConnection {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = JDBCConnection.class.getName();
	private static final Logger trcLogger;
	private static final String JDBC_USER_PARAMETER = "user";
	private static final String JDBC_USER_PASSWORD_PARAMETER = "password";
	private String jdbcURL = null;
	private String jdbcDriver = null;
	private Properties jdbcProperties = new Properties();
	private int jdbcIsolationLevel = 2;

	private Class loadJDBCClass() throws WIMSystemException {
		return DAOHelper.loadJDBCClass(this.jdbcDriver);
	}

	public Connection getConnection() throws WIMSystemException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getConnection");
		}

		Connection var2 = null;

		try {
			trcLogger.logp(Level.FINEST, CLASSNAME, "getConnection", "Loading JDBC driver with external class loader");
			Class var3 = this.loadJDBCClass();
			trcLogger.logp(Level.FINEST, CLASSNAME, "getConnection", "Creating driver instance");
			Object var10 = var3.newInstance();
			Method var5 = var3.getMethod("connect", String.class, Properties.class);
			trcLogger.logp(Level.FINEST, CLASSNAME, "getConnection", "Invoking connect() method on driver");
			var2 = (Connection) var5.invoke(var10, this.jdbcURL, this.jdbcProperties);
		} catch (Exception var9) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "getConnection", "Caught exception", var9);
			if (var9 instanceof InvocationTargetException && var9.getCause() instanceof SQLException) {
				SQLException var4 = (SQLException) var9.getCause();
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var4.getMessage()),
						CLASSNAME, "getConnection", var4);
			}

			try {
				if (this.jdbcDriver != null) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "getConnection",
							"Loading JDBC driver with default class loader " + this.jdbcDriver);
					Class.forName(this.jdbcDriver);
				}

				trcLogger.logp(Level.FINEST, CLASSNAME, "getConnection",
						"Calling DriverManager() to get JDBC connection");
				var2 = DriverManager.getConnection(this.jdbcURL, this.jdbcProperties);
			} catch (ClassNotFoundException var6) {
				throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var6.getMessage()), CLASSNAME,
						"getConnection", var6);
			} catch (SQLException var7) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var7.getMessage()),
						CLASSNAME, "getConnection", var7);
			} catch (Exception var8) {
				throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var9.getMessage()), CLASSNAME,
						"getConnection", var9);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getConnection");
		}

		return var2;
	}

	public String getJdbcDriver() {
		return this.jdbcDriver;
	}

	public String getJdbcURL() {
		return this.jdbcURL;
	}

	public String getJdbcUser() {
		return this.jdbcProperties.getProperty("user");
	}

	public String getJdbcUserPassword() {
		return this.jdbcProperties.getProperty("password");
	}

	public void setJdbcDriver(String var1) {
		this.jdbcDriver = var1;
	}

	public void setJdbcURL(String var1) {
		this.jdbcURL = var1;
	}

	public void setJdbcUser(String var1) {
		this.jdbcProperties.put("user", var1);
	}

	public void setJdbcUserPassword(String var1) {
		this.jdbcProperties.put("password", var1);
	}

	public void setJdbcIsolationLevel(int var1) {
		this.jdbcIsolationLevel = var1;
	}

	public String getJdbcProperty(String var1) {
		return this.jdbcProperties.getProperty(var1);
	}

	public void setJdbcProperty(String var1, String var2) {
		this.jdbcProperties.put(var1, var2);
	}

	public Enumeration getJdbcPropertyNames() {
		return this.jdbcProperties.keys();
	}

	public void removeJdbcProperty(String var1) {
		this.jdbcProperties.remove(var1);
	}

	public void removeAllJdbcProperties() {
		this.jdbcProperties.clear();
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}