package com.ibm.wsspi.security.crypto;

public class PasswordEncryptException extends Exception {
	public PasswordEncryptException() {
	}

	public PasswordEncryptException(String message) {
		super(message);
	}

	public PasswordEncryptException(Exception e) {
		super(e);
	}

	public PasswordEncryptException(String message, Exception e) {
		super(message, e);
	}
}