package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ActivitySession.SystemException;
import com.ibm.websphere.csi.ActivitySessionAttribute;
import com.ibm.websphere.csi.CSIActivitySessionResetException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.websphere.csi.TxContextChange;
import com.ibm.ws.ActivitySession.ActivitySession;
import com.ibm.ws.ActivitySession.ActivitySessionManager;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import javax.transaction.Synchronization;
import javax.transaction.UserTransaction;

public class UOWControlImpl implements UOWControl {
	private static final TraceComponent tc = Tr.register(UOWControlImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.csi.UOWControlImpl";
	public static final int DEFAULT_AS_TIMEOUT = 600;
	protected ActivitySessionManager asService;
	private ActivitySessionStrategy[] asStrategies;
	protected TransactionControlImpl txCtrl;

	public UOWControlImpl(TransactionControlImpl txCtrl, ActivitySessionManager asService) {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "<init>", new Object[]{txCtrl, asService});
		}

		this.txCtrl = txCtrl;
		this.asService = asService;
		this.asStrategies = new ActivitySessionStrategy[ActivitySessionAttribute.getNumAttrs()];
		this.asStrategies[ActivitySessionAttribute.AS_NOT_SUPPORTED.getValue()] = new AS_NotSupported(this);
		this.asStrategies[ActivitySessionAttribute.AS_BEAN_MANAGED.getValue()] = new AS_BeanManaged(this);
		this.asStrategies[ActivitySessionAttribute.AS_REQUIRED.getValue()] = new AS_Required(this);
		this.asStrategies[ActivitySessionAttribute.AS_SUPPORTS.getValue()] = new AS_Supports(this);
		this.asStrategies[ActivitySessionAttribute.AS_REQUIRES_NEW.getValue()] = new AS_RequiresNew(this);
		this.asStrategies[ActivitySessionAttribute.AS_MANDATORY.getValue()] = new AS_Mandatory(this);
		this.asStrategies[ActivitySessionAttribute.AS_NEVER.getValue()] = new AS_Never(this);
		this.asStrategies[ActivitySessionAttribute.AS_UNKNOWN.getValue()] = new AS_Unknown(this);
		if (entryEnabled) {
			Tr.exit(tc, "<init>");
		}

	}

	public UOWCookie preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		ActivitySessionStrategy asStrategy = this.asStrategies[methodInfo.getActivitySessionAttribute().getValue()];
		ASCookieImpl asCookie = asStrategy.preInvoke(key, methodInfo);
		TxCookieImpl txCookie = null;

		try {
			txCookie = (TxCookieImpl) this.txCtrl.preInvoke(key, methodInfo);
		} catch (CSIException var10) {
			FFDCFilter.processException(var10, "com.ibm.ejs.csi.UOWControlImpl.preInvoke", "224", this);

			try {
				asStrategy.postInvoke(key, asCookie, methodInfo);
			} catch (Throwable var9) {
				FFDCFilter.processException(var9, "com.ibm.ejs.csi.UOWControlImpl.preInvoke", "236", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Suppressing exception during preInvoke: " + var10);
				}
			}

			throw var10;
		}

		asCookie.TxCookie = txCookie;
		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		return asCookie;
	}

	public void postInvoke(EJBKey key, UOWCookie uowCookie, ExceptionType exType, EJBMethodInfoImpl methodInfo)
			throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		ASCookieImpl asCookieImpl = (ASCookieImpl) uowCookie;
		if (asCookieImpl != null && asCookieImpl.TxCookie != null) {
			ActivitySessionStrategy asStrategy = asCookieImpl.asStrategy;

			try {
				this.txCtrl.postInvoke(key, asCookieImpl.TxCookie, exType, methodInfo);
			} catch (CSIException var11) {
				FFDCFilter.processException(var11, "com.ibm.ejs.csi.UOWControlImpl.postInvoke", "356", this);

				try {
					if (exType == ExceptionType.NO_EXCEPTION) {
						asStrategy.postInvoke(key, asCookieImpl, methodInfo);
					} else {
						asStrategy.handleException(key, asCookieImpl, exType, methodInfo);
					}
				} catch (Throwable var10) {
					FFDCFilter.processException(var10, "com.ibm.ejs.csi.UOWControlImpl.postInvoke", "372", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Suppressing exception during postInvoke: " + var11);
					}
				}

				throw var11;
			}

			if (exType == ExceptionType.NO_EXCEPTION) {
				asStrategy.postInvoke(key, asCookieImpl, methodInfo);
			} else {
				asStrategy.handleException(key, asCookieImpl, exType, methodInfo);
			}
		} else {
			try {
				int asStatus = 3;

				try {
					asStatus = this.asService.getStatus();
				} catch (SystemException var12) {
					FFDCFilter.processException(var12, "com.ibm.ejs.csi.UOWControlImpl.postInvoke", "310", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Unexpected exception during postInvoke: ", var12);
					}
				}

				if (asStatus != 3) {
					this.asService.setResetOnly();
				}
			} catch (Throwable var13) {
				FFDCFilter.processException(var13, "com.ibm.ejs.csi.UOWControlImpl.postInvoke", "322", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Suppressing exception during postInvoke: ", var13);
				}
			}

			this.txCtrl.postInvoke(key, (UOWCookie) null, exType, methodInfo);
		}

		if (entryEnabled) {
			Tr.exit(tc, "postInvoke");
		}

	}

	public Object getCurrentSessionalUOW(boolean checkMarkedReset) throws CSIActivitySessionResetException {
		ActivitySession as = this.getActivitySession();
		if (as != null && checkMarkedReset) {
			boolean resetOnly = false;

			try {
				resetOnly = this.asService.getResetOnly();
			} catch (SystemException var5) {
				FFDCFilter.processException(var5, "com.ibm.ejs.csi.UOWControlImpl.getCurrentSessionalUOW", "432", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Unexpected exception during getCurrentSessionalUOW method: " + var5);
				}
			}

			if (resetOnly) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "ActivitySession is marked resetOnly");
				}

				throw new CSIActivitySessionResetException("ActivitySession is marked resetOnly");
			}
		}

		return as;
	}

	public SynchronizationRegistryUOWScope getCurrentTransactionalUOW(boolean checkMarkedRollback)
			throws CSITransactionRolledbackException {
		return this.txCtrl.getCurrentTransactionalUOW(checkMarkedRollback);
	}

	public UserTransaction getUserTransaction() {
		return this.txCtrl.getUserTransaction();
	}

	public void setRollbackOnly() {
		this.txCtrl.setRollbackOnly();
	}

	public boolean getRollbackOnly() {
		return this.txCtrl.getRollbackOnly();
	}

	public void enlistWithSession(Synchronization interestedParty) throws CSIException {
		ActivitySession as = this.getActivitySession();
		if (as == null) {
			throw new CSIException("ActivitySession does not exist");
		} else {
			try {
				as.enlistSynchronization(interestedParty);
			} catch (SystemException var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.csi.UOWControlImpl.enlistWithSession", "534", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Unexpected exception during ActivitySession enlistment for sync callbacks", var4);
				}

				throw new CSIException("Failed to enlist with the Activity Session", var4);
			}
		}
	}

	public void sessionEnded(EJBKey[] EjbKeyArray) throws CSIException {
		int max = EjbKeyArray.length;

		for (int i = 0; i < max; ++i) {
			this.txCtrl.stickyLocalTxTable.remove(EjbKeyArray[i]);
		}

	}

	public void enlistWithTransaction(Synchronization interestedParty) throws CSIException {
		this.txCtrl.enlistWithTransaction(interestedParty);
	}

	public void enlistWithTransaction(SynchronizationRegistryUOWScope uowCoord, Synchronization interestedParty)
			throws CSIException {
		this.txCtrl.enlistWithTransaction(uowCoord, interestedParty);
	}

	public TxContextChange setupLocalTxContext(EJBKey key) throws CSIException {
		return this.txCtrl.setupLocalTxContext(key);
	}

	public void teardownLocalTxContext(TxContextChange changedContext) {
		this.txCtrl.teardownLocalTxContext(changedContext);
	}

	private ActivitySession getActivitySession() {
		ActivitySession as = null;

		try {
			as = this.asService.getActivitySession();
		} catch (SystemException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.csi.UOWControlImpl.getActivitySession", "573", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Unexpected exception during getActivitySession: " + var3);
			}
		}

		return as;
	}

	public void completeTxTimeout() throws CSITransactionRolledbackException {
		this.txCtrl.completeTxTimeout();
	}

	public boolean isBmtActive(EJBMethodInfoImpl methodInfo) {
		return this.txCtrl.isBmtActive(methodInfo);
	}

	public boolean isBmasActive(EJBMethodInfoImpl methodInfo) {
		ActivitySessionStrategy asStrategy = this.asStrategies[methodInfo.getActivitySessionAttribute().getValue()];
		return asStrategy.isBmasActive();
	}

	public UOWHandle suspend() throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "suspend");
		}

		UOWHandle toReturn = null;
		if (this.ASExists()) {
			ActivitySession as = this.suspendAS();
			toReturn = new UOWHandleImpl(as);
		} else {
			toReturn = this.txCtrl.suspend();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "suspend : " + toReturn);
		}

		return (UOWHandle) toReturn;
	}

	public void resume(UOWHandle handle) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "resume : " + handle);
		}

		if (handle != null) {
			UOWHandleImpl handleImpl = (UOWHandleImpl) handle;
			if (handleImpl.suspendedActivitySession != null) {
				this.resumeAS(handleImpl.suspendedActivitySession);
			} else {
				this.txCtrl.resume(handle);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "resume");
		}

	}

	final boolean ASExists() {
		int asStatus = 3;

		try {
			asStatus = this.asService.getStatus();
		} catch (SystemException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.csi.UOWControlImpl.ASExists", "805", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Unexpected exception during ASExists method: ", var3);
			}
		}

		return asStatus != 3;
	}

	final ActivitySession suspendAS() throws CSIException {
		ActivitySession result = null;

		try {
			if (this.ASExists()) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Suspending AS cntxt: " + this.asService.getSessionName());
				}

				result = this.asService.suspend();
			}

			return result;
		} catch (SystemException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.csi.UOWControlImpl.suspendAS", "783", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Unexpected exception during suspendAS method: ", var3);
			}

			throw new CSIException("Suspend activitySession failed ", var3);
		}
	}

	final void resumeAS(ActivitySession suspendedAS) throws CSIException {
		try {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Resuming AS cntxt: " + suspendedAS.getSessionName());
			}

			this.asService.resume(suspendedAS);
		} catch (Exception var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.csi.UOWControlImpl.resumeAS", "816", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Unexpected exception during resumeAS method: ", var3);
			}

			throw new CSIException("resume activitySession failed ", var3);
		}
	}
}