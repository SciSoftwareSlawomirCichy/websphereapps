package com.ibm.ejs.sm.util;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Vector;

public class ObjectCollection implements Enumeration, Serializable {
	Vector objList = new Vector();
	int cursor = 0;
	private static final long serialVersionUID = -6307562056675291970L;

	public void addElement(Object obj) {
		this.objList.addElement(obj);
	}

	public Object[] getArray() throws RemoteException {
		Object[] result = new Object[this.objList.size()];
		this.objList.copyInto(result);
		return result;
	}

	public boolean hasMoreElements() {
		return this.cursor < this.objList.size();
	}

	public Object nextElement() throws NoSuchElementException {
		if (this.cursor >= this.objList.size()) {
			throw new NoSuchElementException();
		} else {
			return this.objList.elementAt(this.cursor++);
		}
	}

	public int size() {
		return this.objList.size();
	}

	public int cursor() {
		return this.cursor;
	}
}