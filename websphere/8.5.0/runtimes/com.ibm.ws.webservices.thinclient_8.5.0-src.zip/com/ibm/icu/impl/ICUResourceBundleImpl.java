package com.ibm.icu.impl;

import com.ibm.icu.impl.ICUResourceBundleImpl.ResourceArray;
import com.ibm.icu.impl.ICUResourceBundleImpl.ResourceBinary;
import com.ibm.icu.impl.ICUResourceBundleImpl.ResourceInt;
import com.ibm.icu.impl.ICUResourceBundleImpl.ResourceIntVector;
import com.ibm.icu.impl.ICUResourceBundleImpl.ResourceString;
import com.ibm.icu.impl.ICUResourceBundleImpl.ResourceTable;
import com.ibm.icu.util.UResourceBundle;
import java.util.HashMap;

class ICUResourceBundleImpl extends ICUResourceBundle {
	protected ICUResourceBundleImpl(ICUResourceBundleReader reader, String key, String resPath, int resource,
			ICUResourceBundleImpl container) {
		super(reader, key, resPath, resource, container);
	}

	protected final ICUResourceBundle createBundleObject(String _key, int _resource, HashMap<String, String> table,
			UResourceBundle requested, boolean[] isAlias) {
		if (isAlias != null) {
			isAlias[0] = false;
		}

		String _resPath = this.resPath + "/" + _key;
		switch (ICUResourceBundleReader.RES_GET_TYPE(_resource)) {
			case 0 :
			case 6 :
				return new ResourceString(this.reader, _key, _resPath, _resource, this);
			case 1 :
				return new ResourceBinary(this.reader, _key, _resPath, _resource, this);
			case 2 :
			case 4 :
			case 5 :
				return new ResourceTable(this.reader, _key, _resPath, _resource, this);
			case 3 :
				if (isAlias != null) {
					isAlias[0] = true;
				}

				return this.findResource(_key, _resource, table, requested);
			case 7 :
				return new ResourceInt(this.reader, _key, _resPath, _resource, this);
			case 8 :
			case 9 :
				return new ResourceArray(this.reader, _key, _resPath, _resource, this);
			case 10 :
			case 11 :
			case 12 :
			case 13 :
			default :
				throw new IllegalStateException("The resource type is unknown");
			case 14 :
				return new ResourceIntVector(this.reader, _key, _resPath, _resource, this);
		}
	}
}