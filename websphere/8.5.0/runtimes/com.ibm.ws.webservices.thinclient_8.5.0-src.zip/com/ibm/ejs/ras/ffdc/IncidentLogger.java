package com.ibm.ejs.ras.ffdc;

import com.ibm.ejs.ras.ffdc.IncidentLogger.1;
import com.ibm.ffdc.config.IncidentStream.Writer;
import com.ibm.ffdc.util.bulkdata.CapacityException;
import com.ibm.ffdc.util.bulkdata.FixedCapacityOutputStream;
import com.ibm.ffdc.util.formatting.IncidentReportHeader;
import com.ibm.ffdc.util.provider.Incident;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

final class IncidentLogger<T extends FfdcProvider> extends com.ibm.ffdc.util.provider.IncidentLogger<T> {
	private static final int MAXINCIDENTSIZE = 4194304;

	protected IncidentLogger(T provider) {
		super(provider);
	}

	protected final String log(Incident incident, Object reporter, Throwable th, Object[] capturedDataElements) {
      FixedCapacityOutputStream os = new FixedCapacityOutputStream(4194304);
      Writer<FixedCapacityOutputStream> isWriter = new 1(this, incident, reporter, th, capturedDataElements);
      boolean capacityException = false;

      try {
         isWriter.writeTo(os);
      } catch (IOException var11) {
         this.ffdcerror(var11);
      } catch (CapacityException var12) {
         capacityException = true;
      }

      PrintStream ffdcFile = FfdcProvider.getFFDCFilePrintStream();
      if (ffdcFile != null) {
         try {
            os.writeTo(ffdcFile);
            if (capacityException) {
               ffdcFile.println("* * * FFDC output truncated here * * * ");
            }
         } catch (IOException var10) {
            this.ffdcerror(var10);
         }
      }

      return null;
   }

	private void writeIncidentTo(FixedCapacityOutputStream os, Incident incident, Object reporter, Throwable th,
			Object... capturedDataElements) {
		Writer incidentReportHeader = this.getReportHeader(incident, th, reporter);

		try {
			incidentReportHeader.writeTo(os);
		} catch (IOException var10) {
			this.ffdcerror(var10);
		} catch (CapacityException var11) {
			;
		}

		if (capturedDataElements != null) {
			IncidentStream is = new IncidentStream((FfdcProvider) this.provider, os);

			for (int i = 0; i < capturedDataElements.length; ++i) {
				String label = "arg" + (capturedDataElements.length == 1 ? "" : i);
				is.write(label, capturedDataElements[i]);
			}
		}

	}

	private Writer<OutputStream> getReportHeader(Incident incident, Throwable th, Object reporter) {
		return new IncidentReportHeader(incident, th, reporter);
	}
}