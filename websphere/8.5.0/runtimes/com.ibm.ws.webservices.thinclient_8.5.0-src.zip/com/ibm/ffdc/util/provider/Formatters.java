package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.config.Formattable;
import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.util.provider.Formatters.1;
import com.ibm.ffdc.util.provider.Formatters.2;
import com.ibm.ffdc.util.provider.Formatters.PartialIntrospector;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Formatters<T extends FfdcProvider> extends FfdcProviderDependent<T> {
	private final Map<Class<?>, Formatter> formatterCache = new HashMap();
	static final Formatter FormattableMarker = new 1();

	public Formatters(T provider) {
		super(provider);
	}

	public Formatter getFormatter(Object object) throws PrivilegedActionException {
		assert !(object instanceof Class);

		Class<?> cl = object.getClass();
		Formatter f = (Formatter) this.formatterCache.get(cl);
		if (f == null) {
			f = this.getRegisteredFormatter(cl);
			if (f == null) {
				f = this.makeFormatter(cl);
			}

			this.formatterCache.put(cl, f);
		}

		return f;
	}

	public Formatter findFormatter(Class<?> cl) {
		Formatter f = (Formatter) this.formatterCache.get(cl);
		if (f == null) {
			f = this.getRegisteredFormatter(cl);
			if (f != null) {
				this.formatterCache.put(cl, f);
			}
		}

		return f;
	}

	private Formatter getRegisteredFormatter(Class<?> cl) {
		return this.getRegisteredFormatter(cl, this.provider.getFormatters());
	}

	private Formatter getRegisteredFormatter(Class<?> cl, List<Formatter> formatters) {
		Formatter choice = null;
		Package pkg = cl.getPackage();
		String pname;
		if (pkg == null) {
			if (!cl.isArray()) {
				return null;
			}

			pname = "[.*";
		} else {
			pname = pkg.getName() + ".*";
		}

		String cname = cl.getName();
		Iterator i$ = formatters.iterator();

		while (true) {
			Formatter formatter;
			do {
				if (!i$.hasNext()) {
					return choice;
				}

				formatter = (Formatter) i$.next();
			} while (formatter == null);

			String[] arr$ = this.getSupportedTypeNames(formatter);
			int len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				String stn = arr$[i$];
				if (cname.equals(stn) && this.isSupported(formatter, cl)) {
					return formatter;
				}

				if (choice == null && pname.equals(stn) && this.isSupported(formatter, cl)) {
					choice = formatter;
				}
			}
		}
	}

	private boolean isSupported(Formatter formatter, Class<?> cl) {
		try {
			return formatter.isSupported(cl);
		} catch (Exception var4) {
			this.deregister(formatter, var4);
			return false;
		}
	}

	private String[] getSupportedTypeNames(Formatter formatter) {
		try {
			String[] supportedTypes = formatter.getSupportedTypeNames();
			if (supportedTypes == null) {
				supportedTypes = new String[0];
			}

			if (supportedTypes.length == 0) {
				this.deregister(formatter, new IllegalStateException("no type names supported"));
			}

			return supportedTypes;
		} catch (Exception var3) {
			this.deregister(formatter, var3);
			return new String[0];
		}
	}

	private void deregister(Formatter formatter, Throwable th) {
		this.provider.deregister(formatter);
	}

	protected <T> Formatter makeFormatter(Class<T> bottom) throws PrivilegedActionException {
		Class upperLimit;
		Formatter baseFormatter;
		if (Formattable.class.isAssignableFrom(bottom)) {
			upperLimit = this.getDeclarerOfFormatToMethod(bottom);
			if (bottom.equals(upperLimit)) {
				return FormattableMarker;
			}

			baseFormatter = FormattableMarker;
		} else {
			baseFormatter = null;
			upperLimit = Object.class;
		}

		Class<? super T> top = bottom;

		for (Class c = bottom.getSuperclass(); !upperLimit.equals(c); c = c.getSuperclass()) {
			Formatter f = this.findFormatter(c);
			if (f != null && !f.getClass().equals(PartialIntrospector.class)) {
				return new PartialIntrospector(bottom, top, f);
			}

			top = c;
		}

		assert top.getSuperclass().equals(upperLimit);

		return new PartialIntrospector(bottom, top, baseFormatter);
	}

	protected boolean isIntrospector(Formatter f) {
		assert f != null;

		return PartialIntrospector.class.equals(f.getClass());
	}

	final <T extends Formattable> Class<? super T> getDeclarerOfFormatToMethod(Class<T> cl) throws PrivilegedActionException {
      return (Class)AccessController.doPrivileged(new 2(this, cl));
   }

	void clear() {
		this.formatterCache.clear();
	}
}