package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.config.Formattable;
import com.ibm.ffdc.util.bulkdata.CapacityException;
import com.ibm.ffdc.util.bulkdata.FixedCapacityOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FfdcOnPrintStreamProvider extends FfdcProvider implements com.ibm.ffdc.provider.FfdcProvider {
	private final PrintStream ps;
	private final String psName;
	private static final int MAXSUMMARYSIZE = 1048576;
	private static final int MAXINCIDENTSIZE = 4194304;
	private static final String thisClass = FfdcOnPrintStreamProvider.class.getName();
	private static Logger LOGGER;

	public FfdcOnPrintStreamProvider(PrintStream ps, String psName) {
		this.ps = ps;
		this.psName = psName;
	}

	protected synchronized void logIncident(IncidentEntry incident, Object reporter, Throwable th,
			List<Formattable> data) {
		FixedCapacityOutputStream os = new FixedCapacityOutputStream();
		IncidentLogger<FfdcOnPrintStreamProvider> incidentLogger = new IncidentLogger(this);
		this.logIncident(incidentLogger, os, incident, reporter, th, data);
		this.logSummary(incidentLogger, os, this.getIncidents());
	}

	protected void logIncident(IncidentLogger<FfdcOnPrintStreamProvider> incidentLogger, FixedCapacityOutputStream os,
			IncidentEntry incident, Object reporter, Throwable th, List<Formattable> data) {
		os.reset(this.getMaxIncidentSize());

		boolean isTruncated;
		try {
			IncidentStream<FfdcProvider> is = new IncidentStream(this, os);
			incidentLogger.writeIncidentTo(is, incident, reporter, th, data);
			is.release();
			isTruncated = false;
		} catch (CapacityException var10) {
			isTruncated = true;
		} catch (IOException var11) {
			this.abort(var11);
			return;
		}

		this.ps.flush();

		try {
			os.writeTo(this.ps);
		} catch (IOException var9) {
			this.abort(var9);
			return;
		}

		if (isTruncated) {
			this.ps.println("FFDC report truncated");
		}

		LOGGER.logp(Level.INFO, FfdcOnPrintStreamProvider.class.getName(), "logIncident", "FFDCIncidentEmitted",
				new Object[]{this.psName, incident.getSourceId(), incident.getProbeId()});
	}

	protected void logSummary(IncidentLogger<FfdcOnPrintStreamProvider> incidentLogger, FixedCapacityOutputStream os,
			List<Incident> incidents) {
		os.reset(this.getmaxSummarySize());

		boolean isTruncated;
		try {
			incidentLogger.logIncidentSummary(os, incidents);
			isTruncated = false;
		} catch (CapacityException var7) {
			isTruncated = true;
		}

		this.ps.flush();

		try {
			os.writeTo(this.ps);
		} catch (IOException var6) {
			this.abort(var6);
			return;
		}

		if (isTruncated) {
			this.ps.println("FFDC summary report truncated");
		}

	}

	protected int getMaxIncidentSize() {
		return 4194304;
	}

	protected int getmaxSummarySize() {
		return 4194304;
	}

	static {
		try {
			LOGGER = Logger.getLogger(thisClass, "com.ibm.ffdc.FFDCBundleMessages");
		} catch (Throwable var1) {
			LOGGER = Logger.getLogger(thisClass);
		}

	}
}