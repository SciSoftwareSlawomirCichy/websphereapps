package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.Multiset.Entry;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NavigableSet;

@Beta
@GwtCompatible(emulated = true)
public abstract class ForwardingSortedMultiset<E> extends ForwardingMultiset<E> implements SortedMultiset<E> {
	protected abstract SortedMultiset<E> delegate();

	public NavigableSet<E> elementSet() {
		return this.delegate().elementSet();
	}

	public Comparator<? super E> comparator() {
		return this.delegate().comparator();
	}

	public SortedMultiset<E> descendingMultiset() {
		return this.delegate().descendingMultiset();
	}

	public Entry<E> firstEntry() {
		return this.delegate().firstEntry();
	}

	protected Entry<E> standardFirstEntry() {
		Iterator<Entry<E>> entryIterator = this.entrySet().iterator();
		if (!entryIterator.hasNext()) {
			return null;
		} else {
			Entry<E> entry = (Entry) entryIterator.next();
			return Multisets.immutableEntry(entry.getElement(), entry.getCount());
		}
	}

	public Entry<E> lastEntry() {
		return this.delegate().lastEntry();
	}

	protected Entry<E> standardLastEntry() {
		Iterator<Entry<E>> entryIterator = this.descendingMultiset().entrySet().iterator();
		if (!entryIterator.hasNext()) {
			return null;
		} else {
			Entry<E> entry = (Entry) entryIterator.next();
			return Multisets.immutableEntry(entry.getElement(), entry.getCount());
		}
	}

	public Entry<E> pollFirstEntry() {
		return this.delegate().pollFirstEntry();
	}

	protected Entry<E> standardPollFirstEntry() {
		Iterator<Entry<E>> entryIterator = this.entrySet().iterator();
		if (!entryIterator.hasNext()) {
			return null;
		} else {
			Entry<E> entry = (Entry) entryIterator.next();
			entry = Multisets.immutableEntry(entry.getElement(), entry.getCount());
			entryIterator.remove();
			return entry;
		}
	}

	public Entry<E> pollLastEntry() {
		return this.delegate().pollLastEntry();
	}

	protected Entry<E> standardPollLastEntry() {
		Iterator<Entry<E>> entryIterator = this.descendingMultiset().entrySet().iterator();
		if (!entryIterator.hasNext()) {
			return null;
		} else {
			Entry<E> entry = (Entry) entryIterator.next();
			entry = Multisets.immutableEntry(entry.getElement(), entry.getCount());
			entryIterator.remove();
			return entry;
		}
	}

	public SortedMultiset<E> headMultiset(E upperBound, BoundType boundType) {
		return this.delegate().headMultiset(upperBound, boundType);
	}

	public SortedMultiset<E> subMultiset(E lowerBound, BoundType lowerBoundType, E upperBound,
			BoundType upperBoundType) {
		return this.delegate().subMultiset(lowerBound, lowerBoundType, upperBound, upperBoundType);
	}

	protected SortedMultiset<E> standardSubMultiset(E lowerBound, BoundType lowerBoundType, E upperBound,
			BoundType upperBoundType) {
		return this.tailMultiset(lowerBound, lowerBoundType).headMultiset(upperBound, upperBoundType);
	}

	public SortedMultiset<E> tailMultiset(E lowerBound, BoundType boundType) {
		return this.delegate().tailMultiset(lowerBound, boundType);
	}
}