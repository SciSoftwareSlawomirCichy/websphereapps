package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.collect.ImmutableMultiset.1;
import com.google.common.collect.ImmutableMultiset.Builder;
import com.google.common.collect.ImmutableMultiset.EntrySet;
import com.google.common.collect.Multiset.Entry;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.concurrent.LazyInit;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
public abstract class ImmutableMultiset<E> extends ImmutableMultisetGwtSerializationDependencies<E>
		implements
			Multiset<E> {
	@LazyInit
	private transient ImmutableList<E> asList;
	@LazyInit
	private transient ImmutableSet<Entry<E>> entrySet;

	public static <E> ImmutableMultiset<E> of() {
		return RegularImmutableMultiset.EMPTY;
	}

	public static <E> ImmutableMultiset<E> of(E element) {
		return copyFromElements(element);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2) {
		return copyFromElements(e1, e2);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3) {
		return copyFromElements(e1, e2, e3);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4) {
		return copyFromElements(e1, e2, e3, e4);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5) {
		return copyFromElements(e1, e2, e3, e4, e5);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... others) {
		return (new Builder()).add(e1).add(e2).add(e3).add(e4).add(e5).add(e6).add(others).build();
	}

	public static <E> ImmutableMultiset<E> copyOf(E[] elements) {
		return copyFromElements(elements);
	}

	public static <E> ImmutableMultiset<E> copyOf(Iterable<? extends E> elements) {
		if (elements instanceof ImmutableMultiset) {
			ImmutableMultiset<E> result = (ImmutableMultiset) elements;
			if (!result.isPartialView()) {
				return result;
			}
		}

		Builder<E> builder = new Builder(Multisets.inferDistinctElements(elements));
		builder.addAll(elements);
		return builder.build();
	}

	public static <E> ImmutableMultiset<E> copyOf(Iterator<? extends E> elements) {
		return (new Builder()).addAll(elements).build();
	}

	private static <E> ImmutableMultiset<E> copyFromElements(E... elements) {
		return (new Builder()).add(elements).build();
	}

	static <E> ImmutableMultiset<E> copyFromEntries(Collection<? extends Entry<? extends E>> entries) {
		Builder<E> builder = new Builder(entries.size());
		Iterator var2 = entries.iterator();

		while (var2.hasNext()) {
			Entry<? extends E> entry = (Entry) var2.next();
			builder.addCopies(entry.getElement(), entry.getCount());
		}

		return builder.build();
	}

	public UnmodifiableIterator<E> iterator() {
      Iterator<Entry<E>> entryIterator = this.entrySet().iterator();
      return new 1(this, entryIterator);
   }

	public ImmutableList<E> asList() {
		ImmutableList<E> result = this.asList;
		return result == null ? (this.asList = super.asList()) : result;
	}

	public boolean contains(@NullableDecl Object object) {
		return this.count(object) > 0;
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final int add(E element, int occurrences) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final int remove(Object element, int occurrences) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final int setCount(E element, int count) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final boolean setCount(E element, int oldCount, int newCount) {
		throw new UnsupportedOperationException();
	}

	@GwtIncompatible
	int copyIntoArray(Object[] dst, int offset) {
		Entry entry;
		for (UnmodifiableIterator var3 = this.entrySet().iterator(); var3.hasNext(); offset += entry.getCount()) {
			entry = (Entry) var3.next();
			Arrays.fill(dst, offset, offset + entry.getCount(), entry.getElement());
		}

		return offset;
	}

	public boolean equals(@NullableDecl Object object) {
		return Multisets.equalsImpl(this, object);
	}

	public int hashCode() {
		return Sets.hashCodeImpl(this.entrySet());
	}

	public String toString() {
		return this.entrySet().toString();
	}

	public abstract ImmutableSet<E> elementSet();

	public ImmutableSet<Entry<E>> entrySet() {
		ImmutableSet<Entry<E>> es = this.entrySet;
		return es == null ? (this.entrySet = this.createEntrySet()) : es;
	}

	private ImmutableSet<Entry<E>> createEntrySet() {
      return (ImmutableSet)(this.isEmpty() ? ImmutableSet.of() : new EntrySet(this, (1)null));
   }

	abstract Entry<E> getEntry(int var1);

	@GwtIncompatible
	abstract Object writeReplace();

	public static <E> Builder<E> builder() {
		return new Builder();
	}
}