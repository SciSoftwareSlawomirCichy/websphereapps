package com.ibm.ejs.util;

import com.ibm.ejs.util.FastHashtable.KeyEnumerator;
import com.ibm.ejs.util.FastHashtable.ObjectEnumerator;
import java.util.Dictionary;
import java.util.Enumeration;

public class FastHashtable<K, V> extends Dictionary<K, V> {
	protected final Bucket<K, V>[] buckets;
	protected int size = 0;

	public FastHashtable(int expectedEntries) {
		Bucket<K, V>[] uncheckedBuckets = new Bucket[expectedEntries];
		this.buckets = uncheckedBuckets;
	}

	public int size() {
		return this.size;
	}

	public boolean isEmpty() {
		return this.size == 0;
	}

	public Object getLock(K key) {
		return this.getBucketForKey(key);
	}

	public boolean contains(K key) {
		Bucket<K, V> bucket = this.getBucketForKey(key);
		synchronized (bucket) {
			Element<K, V> element = bucket.findByKey(key);
			return element != null;
		}
	}

	public V get(Object key) {
		K k = key;
		Bucket<K, V> bucket = this.getBucketForKey(key);
		synchronized (bucket) {
			Element<K, V> element = bucket.findByKey(k);
			return element != null ? element.ivObject : null;
		}
	}

	public V remove(Object key) {
		K k = key;
		Bucket<K, V> bucket = this.getBucketForKey(key);
		Element<K, V> element = null;
		synchronized (bucket) {
			element = bucket.removeByKey(k);
		}

		if (element != null) {
			synchronized (this) {
				--this.size;
			}

			return element.ivObject;
		} else {
			return null;
		}
	}

	public V put(K key, V object) {
		synchronized (this) {
			++this.size;
		}

		Bucket<K, V> bucket = this.getBucketForKey(key);
		synchronized (bucket) {
			Element<K, V> e = bucket.replaceByKey(key, object);
			return e != null ? e.ivObject : null;
		}
	}

	public final Enumeration<V> elements() {
		return new ObjectEnumerator(this);
	}

	public final Enumeration<K> keys() {
		return new KeyEnumerator(this);
	}

	public synchronized void clear() {
		this.size = 0;
		Bucket[] arr$ = this.buckets;
		int len$ = arr$.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Bucket<K, V> bucket = arr$[i$];
			if (bucket != null) {
				synchronized (bucket) {
					bucket.clear();
				}
			}
		}

	}

	protected final Bucket<K, V> getBucketForKey(K key) {
		int bucket_index = (key.hashCode() & Integer.MAX_VALUE) % this.buckets.length;
		Bucket<K, V> thebucket = this.buckets[bucket_index];
		if (thebucket == null) {
			synchronized (this) {
				thebucket = this.buckets[bucket_index];
				if (thebucket == null) {
					thebucket = new Bucket();
					this.buckets[bucket_index] = thebucket;
				}
			}
		}

		return thebucket;
	}
}