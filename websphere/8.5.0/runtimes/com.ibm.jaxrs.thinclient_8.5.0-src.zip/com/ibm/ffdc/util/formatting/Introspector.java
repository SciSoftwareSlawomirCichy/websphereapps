package com.ibm.ffdc.util.formatting;

import com.ibm.ffdc.FFDC_OMIT;
import com.ibm.ffdc.Manager;
import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.config.IncidentStream;
import com.ibm.ffdc.util.formatting.Introspector.1;
import com.ibm.ffdc.util.formatting.Introspector.2;
import java.lang.reflect.Field;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Introspector implements Formatter {
	private final Formatter formatter;
	private final List<Class<?>> topDownHierarchyTail;

	public Introspector(Class<?> bottom, Class<?> top, Formatter formatter) {
		this.formatter = formatter;
		this.topDownHierarchyTail = this.getTopDownHierarchyTail(bottom, top);
	}

	private List<Class<?>> getTopDownHierarchyTail(Class<?> bottom, Class<?> top) {
		List<Class<?>> ht = this.getBottomUpHierarchyTail(bottom, top);
		Collections.reverse(ht);
		return ht;
	}

	private List<Class<?>> getBottomUpHierarchyTail(Class<?> bottom, Class<?> top) {
		ArrayList hierarchy = new ArrayList();

		do {
			hierarchy.add(bottom);
			bottom = bottom.equals(top) ? null : bottom.getSuperclass();
		} while (bottom != null);

		return hierarchy;
	}

	public void formatTo(Object objectToFormat, IncidentStream is) throws IllegalArgumentException {
		if (this.formatter != null) {
			this.formatter.formatTo(objectToFormat, is);
		}

		Iterator i$ = this.topDownHierarchyTail.iterator();

		while (i$.hasNext()) {
			Class cl = (Class) i$.next();

			Field[] fields;
			try {
				fields = this.getDeclaredFields(cl);
			} catch (PrivilegedActionException var13) {
				Manager.Ffdc.log(var13, this, this.getClass().getName(), "95");
				return;
			}

			Field[] arr$ = fields;
			int len$ = fields.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				Field field = arr$[i$];
				String name = cl.getName() + "::" + field.getName();

				try {
					Object value;
					if (field.getAnnotation(FFDC_OMIT.class) != null) {
						value = "OMITTED BY FFDC";
					} else {
						value = this.getValue(field, objectToFormat);
					}

					is.write(name, value);
				} catch (PrivilegedActionException var12) {
					Manager.Ffdc.log(var12, this, this.getClass().getName(), "104");
				}
			}
		}

	}

	public String[] getSupportedTypeNames() {
		return new String[]{this.getSupportedClass().getName()};
	}

	public boolean isSupported(Class<?> clazz) {
		return this.getSupportedClass().equals(clazz);
	}

	public Class<?> getSupportedClass() {
		return (Class) this.topDownHierarchyTail.get(this.topDownHierarchyTail.size() - 1);
	}

	private Field[] getDeclaredFields(Class<?> cl) throws PrivilegedActionException {
      return (Field[])AccessController.doPrivileged(new 1(this, cl));
   }

	private Object getValue(Field field, Object objectToFormat) throws PrivilegedActionException {
      return AccessController.doPrivileged(new 2(this, field, objectToFormat));
   }
}