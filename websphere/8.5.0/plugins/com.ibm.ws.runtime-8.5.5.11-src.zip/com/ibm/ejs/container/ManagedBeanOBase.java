package com.ibm.ejs.container;

import com.ibm.ejs.container.interceptors.InterceptorMetaData;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.managedobject.ManagedObjectState;

public abstract class ManagedBeanOBase extends BeanO {
	private static final String CLASS_NAME = ManagedBeanOBase.class.getName();
	private static final TraceComponent tc = Tr.register(ManagedBeanOBase.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	public Object ivEjbInstance;
	public ManagedObjectState ivManagedObjectState;
	public Object[] ivInterceptors = null;
	public ManagedObjectState[] ivInterceptorManagedObjectStates;

	public ManagedBeanOBase(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		super(c, h);
		this.ivManagedObjectState = mo;
		this.ivEjbInstance = b;
	}

	protected void createInterceptors(InterceptorMetaData imd) {
		this.ivInterceptors = new Object[imd.ivInterceptorClasses.length];
		this.ivInterceptorManagedObjectStates = imd.ivInterceptorFactories == null
				? null
				: new ManagedObject[imd.ivInterceptorFactories.length];
		ManagedObject managedObject = (ManagedObject) this.ivManagedObjectState;

		try {
			imd.createInterceptorInstances(this.getInjectionEngine(), this.ivInterceptors,
					this.ivInterceptorManagedObjectStates, managedObject, this);
		} catch (Throwable var4) {
			FFDCFilter.processException(var4, CLASS_NAME + ".ModernBeanO", "177", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "interceptor creation failure", var4);
			}

			throw ExceptionUtil.EJBException("Interceptor creation failure", var4);
		}
	}

	public <T> T getInjectionTargetContextData(Class<T> type) {
		if (this.ivManagedObjectState != null) {
			ManagedObject managedObject = (ManagedObject) this.ivManagedObjectState;
			T data = managedObject.getContextData(type);
			if (data != null) {
				return data;
			}
		}

		return super.getInjectionTargetContextData(type);
	}

	protected void releaseManagedObjectState() {
		if (this.ivManagedObjectState != null) {
			this.ivManagedObjectState.release();
		}

		if (this.ivInterceptorManagedObjectStates != null) {
			ManagedObjectState[] arr$ = this.ivInterceptorManagedObjectStates;
			int len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				ManagedObjectState managedObjectState = arr$[i$];
				if (managedObjectState != null) {
					managedObjectState.release();
				}
			}
		}

	}
}