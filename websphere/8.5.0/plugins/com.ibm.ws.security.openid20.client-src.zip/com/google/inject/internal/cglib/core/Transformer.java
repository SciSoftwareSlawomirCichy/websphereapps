package com.google.inject.internal.cglib.core;

public interface Transformer {
	Object transform(Object var1);
}