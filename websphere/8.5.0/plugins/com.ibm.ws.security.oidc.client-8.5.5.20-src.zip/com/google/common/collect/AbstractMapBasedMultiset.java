package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.primitives.Ints;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
abstract class AbstractMapBasedMultiset<E> extends AbstractMultiset<E> implements Serializable {
	transient ObjectCountHashMap<E> backingMap;
	transient long size;
	@GwtIncompatible
	private static final long serialVersionUID = 0L;

	AbstractMapBasedMultiset(int distinctElements) {
		this.init(distinctElements);
	}

	abstract void init(int var1);

	public final int count(@NullableDecl Object element) {
		return this.backingMap.get(element);
	}

	@CanIgnoreReturnValue
	public final int add(@NullableDecl E element, int occurrences) {
		if (occurrences == 0) {
			return this.count(element);
		} else {
			Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s", occurrences);
			int entryIndex = this.backingMap.indexOf(element);
			if (entryIndex == -1) {
				this.backingMap.put(element, occurrences);
				this.size += (long) occurrences;
				return 0;
			} else {
				int oldCount = this.backingMap.getValue(entryIndex);
				long newCount = (long) oldCount + (long) occurrences;
				Preconditions.checkArgument(newCount <= 2147483647L, "too many occurrences: %s", newCount);
				this.backingMap.setValue(entryIndex, (int) newCount);
				this.size += (long) occurrences;
				return oldCount;
			}
		}
	}

	@CanIgnoreReturnValue
	public final int remove(@NullableDecl Object element, int occurrences) {
		if (occurrences == 0) {
			return this.count(element);
		} else {
			Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s", occurrences);
			int entryIndex = this.backingMap.indexOf(element);
			if (entryIndex == -1) {
				return 0;
			} else {
				int oldCount = this.backingMap.getValue(entryIndex);
				int numberRemoved;
				if (oldCount > occurrences) {
					numberRemoved = occurrences;
					this.backingMap.setValue(entryIndex, oldCount - occurrences);
				} else {
					numberRemoved = oldCount;
					this.backingMap.removeEntry(entryIndex);
				}

				this.size -= (long) numberRemoved;
				return oldCount;
			}
		}
	}

	@CanIgnoreReturnValue
	public final int setCount(@NullableDecl E element, int count) {
		CollectPreconditions.checkNonnegative(count, "count");
		int oldCount = count == 0 ? this.backingMap.remove(element) : this.backingMap.put(element, count);
		this.size += (long) (count - oldCount);
		return oldCount;
	}

	public final boolean setCount(@NullableDecl E element, int oldCount, int newCount) {
		CollectPreconditions.checkNonnegative(oldCount, "oldCount");
		CollectPreconditions.checkNonnegative(newCount, "newCount");
		int entryIndex = this.backingMap.indexOf(element);
		if (entryIndex == -1) {
			if (oldCount != 0) {
				return false;
			} else {
				if (newCount > 0) {
					this.backingMap.put(element, newCount);
					this.size += (long) newCount;
				}

				return true;
			}
		} else {
			int actualOldCount = this.backingMap.getValue(entryIndex);
			if (actualOldCount != oldCount) {
				return false;
			} else {
				if (newCount == 0) {
					this.backingMap.removeEntry(entryIndex);
					this.size -= (long) oldCount;
				} else {
					this.backingMap.setValue(entryIndex, newCount);
					this.size += (long) (newCount - oldCount);
				}

				return true;
			}
		}
	}

	public final void clear() {
		this.backingMap.clear();
		this.size = 0L;
	}

	final Iterator<E> elementIterator() {
		return new AbstractMapBasedMultiset<E>.Itr<E>() {
			E result(int entryIndex) {
				return AbstractMapBasedMultiset.this.backingMap.getKey(entryIndex);
			}
		};
	}

	final Iterator<Multiset.Entry<E>> entryIterator() {
		return new AbstractMapBasedMultiset<E>.Itr<Multiset.Entry<E>>() {
			Multiset.Entry<E> result(int entryIndex) {
				return AbstractMapBasedMultiset.this.backingMap.getEntry(entryIndex);
			}
		};
	}

	void addTo(Multiset<? super E> target) {
		Preconditions.checkNotNull(target);

		for (int i = this.backingMap.firstIndex(); i >= 0; i = this.backingMap.nextIndex(i)) {
			target.add(this.backingMap.getKey(i), this.backingMap.getValue(i));
		}

	}

	final int distinctElements() {
		return this.backingMap.size();
	}

	public final Iterator<E> iterator() {
		return Multisets.iteratorImpl(this);
	}

	public final int size() {
		return Ints.saturatedCast(this.size);
	}

	@GwtIncompatible
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		Serialization.writeMultiset(this, stream);
	}

	@GwtIncompatible
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		int distinctElements = Serialization.readCount(stream);
		this.init(3);
		Serialization.populateMultiset(this, stream, distinctElements);
	}

	abstract class Itr<T> implements Iterator<T> {
		int entryIndex;
		int toRemove;
		int expectedModCount;

		Itr() {
			this.entryIndex = AbstractMapBasedMultiset.this.backingMap.firstIndex();
			this.toRemove = -1;
			this.expectedModCount = AbstractMapBasedMultiset.this.backingMap.modCount;
		}

		abstract T result(int var1);

		private void checkForConcurrentModification() {
			if (AbstractMapBasedMultiset.this.backingMap.modCount != this.expectedModCount) {
				throw new ConcurrentModificationException();
			}
		}

		public boolean hasNext() {
			this.checkForConcurrentModification();
			return this.entryIndex >= 0;
		}

		public T next() {
			if (!this.hasNext()) {
				throw new NoSuchElementException();
			} else {
				T result = this.result(this.entryIndex);
				this.toRemove = this.entryIndex;
				this.entryIndex = AbstractMapBasedMultiset.this.backingMap.nextIndex(this.entryIndex);
				return result;
			}
		}

		public void remove() {
			this.checkForConcurrentModification();
			CollectPreconditions.checkRemove(this.toRemove != -1);
			AbstractMapBasedMultiset var10000 = AbstractMapBasedMultiset.this;
			var10000.size -= (long) AbstractMapBasedMultiset.this.backingMap.removeEntry(this.toRemove);
			this.entryIndex = AbstractMapBasedMultiset.this.backingMap.nextIndexAfterRemove(this.entryIndex,
					this.toRemove);
			this.toRemove = -1;
			this.expectedModCount = AbstractMapBasedMultiset.this.backingMap.modCount;
		}
	}
}