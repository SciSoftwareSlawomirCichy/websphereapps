package com.ibm.icu.text;

import com.ibm.icu.impl.Utility;
import com.ibm.icu.text.EscapeTransliterator.1;
import com.ibm.icu.text.EscapeTransliterator.2;
import com.ibm.icu.text.EscapeTransliterator.3;
import com.ibm.icu.text.EscapeTransliterator.4;
import com.ibm.icu.text.EscapeTransliterator.5;
import com.ibm.icu.text.EscapeTransliterator.6;
import com.ibm.icu.text.EscapeTransliterator.7;
import com.ibm.icu.text.Transliterator.Position;

class EscapeTransliterator extends Transliterator {
	private String prefix;
	private String suffix;
	private int radix;
	private int minDigits;
	private boolean grokSupplementals;
	private EscapeTransliterator supplementalHandler;

	static void register() {
      Transliterator.registerFactory("Any-Hex/Unicode", new 1());
      Transliterator.registerFactory("Any-Hex/Java", new 2());
      Transliterator.registerFactory("Any-Hex/C", new 3());
      Transliterator.registerFactory("Any-Hex/XML", new 4());
      Transliterator.registerFactory("Any-Hex/XML10", new 5());
      Transliterator.registerFactory("Any-Hex/Perl", new 6());
      Transliterator.registerFactory("Any-Hex", new 7());
   }

	EscapeTransliterator(String ID, String prefix, String suffix, int radix, int minDigits, boolean grokSupplementals,
			EscapeTransliterator supplementalHandler) {
		super(ID, (UnicodeFilter) null);
		this.prefix = prefix;
		this.suffix = suffix;
		this.radix = radix;
		this.minDigits = minDigits;
		this.grokSupplementals = grokSupplementals;
		this.supplementalHandler = supplementalHandler;
	}

	protected void handleTransliterate(Replaceable text, Position pos, boolean incremental) {
		int start = pos.start;
		int limit = pos.limit;
		StringBuilder buf = new StringBuilder(this.prefix);
		int prefixLen = this.prefix.length();

		int charLen;
		for (boolean redoPrefix = false; start < limit; limit += buf.length() - charLen) {
			int c = this.grokSupplementals ? text.char32At(start) : text.charAt(start);
			charLen = this.grokSupplementals ? UTF16.getCharCount(c) : 1;
			if ((c & -65536) != 0 && this.supplementalHandler != null) {
				buf.setLength(0);
				buf.append(this.supplementalHandler.prefix);
				Utility.appendNumber(buf, c, this.supplementalHandler.radix, this.supplementalHandler.minDigits);
				buf.append(this.supplementalHandler.suffix);
				redoPrefix = true;
			} else {
				if (redoPrefix) {
					buf.setLength(0);
					buf.append(this.prefix);
					redoPrefix = false;
				} else {
					buf.setLength(prefixLen);
				}

				Utility.appendNumber(buf, c, this.radix, this.minDigits);
				buf.append(this.suffix);
			}

			text.replace(start, start + charLen, buf.toString());
			start += buf.length();
		}

		pos.contextLimit += limit - pos.limit;
		pos.limit = limit;
		pos.start = start;
	}
}