package com.ibm.ejs.container;

public class MultipleEnlistmentException extends ContainerInternalError {
	private static final long serialVersionUID = 7592848777683128945L;
}