package com.google.inject.internal;

import com.google.inject.Scope;
import com.google.inject.Scopes;
import com.google.inject.Singleton;
import com.google.inject.Stage;
import com.google.inject.binder.ScopedBindingBuilder;
import com.google.inject.internal.Scoping.1;
import com.google.inject.internal.Scoping.2;
import com.google.inject.internal.Scoping.3;
import com.google.inject.internal.Scoping.4;
import com.google.inject.internal.Scoping.5;
import com.google.inject.internal.Scoping.6;
import com.google.inject.spi.BindingScopingVisitor;
import java.lang.annotation.Annotation;

public abstract class Scoping {
	public static final Scoping UNSCOPED = new 1();
	public static final Scoping SINGLETON_ANNOTATION = new 2();
	public static final Scoping SINGLETON_INSTANCE = new 3();
	public static final Scoping EAGER_SINGLETON = new 4();

	public static Scoping forAnnotation(Class<? extends Annotation> scopingAnnotation) {
      return (Scoping)(scopingAnnotation == Singleton.class ? SINGLETON_ANNOTATION : new 5(scopingAnnotation));
   }

	public static Scoping forInstance(Scope scope) {
      return (Scoping)(scope == Scopes.SINGLETON ? SINGLETON_INSTANCE : new 6(scope));
   }

	public boolean isExplicitlyScoped() {
		return this != UNSCOPED;
	}

	public boolean isNoScope() {
		return this.getScopeInstance() == Scopes.NO_SCOPE;
	}

	public boolean isEagerSingleton(Stage stage) {
		if (this == EAGER_SINGLETON) {
			return true;
		} else if (stage != Stage.PRODUCTION) {
			return false;
		} else {
			return this == SINGLETON_ANNOTATION || this == SINGLETON_INSTANCE;
		}
	}

	public Scope getScopeInstance() {
		return null;
	}

	public Class<? extends Annotation> getScopeAnnotation() {
		return null;
	}

	public abstract <V> V acceptVisitor(BindingScopingVisitor<V> var1);

	public abstract void applyTo(ScopedBindingBuilder var1);

	private Scoping() {
	}
}