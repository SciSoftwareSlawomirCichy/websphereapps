package com.ibm.ws.wim.adapter.db;

public class PropertyToUpdate {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String name = null;
	private Object oldValue = null;
	private Object newValue = null;

	public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		this.name = var1;
	}

	public Object getNewValue() {
		return this.newValue;
	}

	public void setNewValue(Object var1) {
		this.newValue = var1;
	}

	public Object getOldValue() {
		return this.oldValue;
	}

	public void setOldValue(Object var1) {
		this.oldValue = var1;
	}
}