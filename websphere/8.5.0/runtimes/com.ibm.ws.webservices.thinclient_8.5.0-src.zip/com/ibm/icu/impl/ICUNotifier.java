package com.ibm.icu.impl;

import com.ibm.icu.impl.ICUNotifier.NotifyThread;
import java.util.ArrayList;
import java.util.EventListener;
import java.util.Iterator;
import java.util.List;

public abstract class ICUNotifier {
	private final Object notifyLock = new Object();
	private NotifyThread notifyThread;
	private List<EventListener> listeners;

	public void addListener(EventListener l) {
		if (l == null) {
			throw new NullPointerException();
		} else if (this.acceptsListener(l)) {
			Object var2 = this.notifyLock;
			synchronized (this.notifyLock) {
				if (this.listeners == null) {
					this.listeners = new ArrayList();
				} else {
					Iterator i$ = this.listeners.iterator();

					while (i$.hasNext()) {
						EventListener ll = (EventListener) i$.next();
						if (ll == l) {
							return;
						}
					}
				}

				this.listeners.add(l);
			}
		} else {
			throw new IllegalStateException("Listener invalid for this notifier.");
		}
	}

	public void removeListener(EventListener l) {
		if (l == null) {
			throw new NullPointerException();
		} else {
			Object var2 = this.notifyLock;
			synchronized (this.notifyLock) {
				if (this.listeners != null) {
					Iterator iter = this.listeners.iterator();

					while (iter.hasNext()) {
						if (iter.next() == l) {
							iter.remove();
							if (this.listeners.size() == 0) {
								this.listeners = null;
							}

							return;
						}
					}
				}

			}
		}
	}

	public void notifyChanged() {
		if (this.listeners != null) {
			Object var1 = this.notifyLock;
			synchronized (this.notifyLock) {
				if (this.listeners != null) {
					if (this.notifyThread == null) {
						this.notifyThread = new NotifyThread(this);
						this.notifyThread.setDaemon(true);
						this.notifyThread.start();
					}

					this.notifyThread
							.queue((EventListener[]) this.listeners.toArray(new EventListener[this.listeners.size()]));
				}
			}
		}

	}

	protected abstract boolean acceptsListener(EventListener var1);

	protected abstract void notifyListener(EventListener var1);
}