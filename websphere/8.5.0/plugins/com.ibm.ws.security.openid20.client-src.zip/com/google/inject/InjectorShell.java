package com.google.inject;

import com.google.inject.InjectorShell.1;
import com.google.inject.InjectorShell.Builder;
import com.google.inject.InjectorShell.InjectorFactory;
import com.google.inject.InjectorShell.LoggerFactory;
import com.google.inject.internal.ImmutableSet;
import com.google.inject.internal.ProviderInstanceBindingImpl;
import com.google.inject.internal.Scoping;
import com.google.inject.internal.SourceProvider;
import com.google.inject.spi.Element;
import com.google.inject.spi.PrivateElements;
import java.util.List;
import java.util.logging.Logger;

class InjectorShell {
	private final List<Element> elements;
	private final InjectorImpl injector;
	private final PrivateElements privateElements;

	private InjectorShell(Builder builder, List<Element> elements, InjectorImpl injector) {
		this.privateElements = Builder.access$000(builder);
		this.elements = elements;
		this.injector = injector;
	}

	PrivateElements getPrivateElements() {
		return this.privateElements;
	}

	InjectorImpl getInjector() {
		return this.injector;
	}

	List<Element> getElements() {
		return this.elements;
	}

	private static void bindInjector(InjectorImpl injector) {
      Key<Injector> key = Key.get(Injector.class);
      InjectorFactory injectorFactory = new InjectorFactory(injector, (1)null);
      injector.state.putBinding(key, new ProviderInstanceBindingImpl(injector, key, SourceProvider.UNKNOWN_SOURCE, injectorFactory, Scoping.UNSCOPED, injectorFactory, ImmutableSet.of()));
   }

	private static void bindLogger(InjectorImpl injector) {
      Key<Logger> key = Key.get(Logger.class);
      LoggerFactory loggerFactory = new LoggerFactory((1)null);
      injector.state.putBinding(key, new ProviderInstanceBindingImpl(injector, key, SourceProvider.UNKNOWN_SOURCE, loggerFactory, Scoping.UNSCOPED, loggerFactory, ImmutableSet.of()));
   }
}