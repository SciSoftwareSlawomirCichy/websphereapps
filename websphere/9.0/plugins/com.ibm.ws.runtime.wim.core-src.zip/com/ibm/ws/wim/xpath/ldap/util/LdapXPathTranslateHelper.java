package com.ibm.ws.wim.xpath.ldap.util;

import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.ldap.LdapConfigManager;
import com.ibm.ws.wim.adapter.ldap.LdapEntity;
import com.ibm.ws.wim.xpath.mapping.datatype.LogicalNode;
import com.ibm.ws.wim.xpath.mapping.datatype.ParenthesisNode;
import com.ibm.ws.wim.xpath.mapping.datatype.PropertyNode;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;
import com.ibm.ws.wim.xpath.util.XPathTranslateHelper;
import commonj.sdo.Property;
import java.util.Iterator;
import java.util.Set;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LdapXPathTranslateHelper implements XPathTranslateHelper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public static final String CLASSNAME = LdapXPathTranslateHelper.class.getName();
	private static final Logger trcLogger;
	private LdapConfigManager ldapConfigMgr = null;
	private Set entityTypes = null;
	private Stack logOps = null;

	public LdapXPathTranslateHelper(Set var1, LdapConfigManager var2) {
		this.logOps = new Stack();
		this.entityTypes = var1;
		this.ldapConfigMgr = var2;
	}

	public void genSearchString(StringBuffer var1, XPathNode var2) throws WIMException {
		switch (var2.getNodeType()) {
			case 0 :
				this.genSearchString(var1, (PropertyNode) var2);
				break;
			case 1 :
				this.genSearchString(var1, (LogicalNode) var2);
				break;
			case 2 :
				this.genSearchString(var1, (ParenthesisNode) var2);
		}

	}

	private void genSearchString(StringBuffer var1, PropertyNode var2) throws WIMException {
		SchemaManager var4 = SchemaManager.singleton();
		String var5 = var2.getName();
		String var6 = null;
		String var7 = null;
		Set var8 = this.ldapConfigMgr.getAttributeNames(this.entityTypes, var5);
		if (var8 == null) {
			throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
					WIMMessageHelper.generateMsgParms(var5, this.entityTypes), CLASSNAME,
					"genSearchString(StringBuffer searchExpBuffer,PropertyNode propNode)");
		} else {
			String var12;
			if (var8.size() == 1) {
				var6 = (String) var8.toArray()[0];
				Object var9 = null;
				Property var10 = null;

				for (Iterator var11 = this.entityTypes.iterator(); var11.hasNext()
						&& var10 == null; var10 = var4.getProperty(var12, var5)) {
					var12 = (String) var11.next();
				}

				if (var10 == null) {
					throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
							WIMMessageHelper.generateMsgParms(var5, this.entityTypes), CLASSNAME,
							"genSearchString(StringBuffer searchExpBuffer,PropertyNode propNode)");
				}

				var7 = var10.getType().getName();
				var9 = this.ldapConfigMgr.getLdapValue(var2.getValue(), var7, var6);
				short var20 = this.ldapConfigMgr.getOperator(var2.getOperator());
				String var17 = this.ldapConfigMgr.escapeSpecialCharacters((String) var9);
				Object[] var22 = new Object[]{var6, var17};
				String var13 = this.ldapConfigMgr.CONDITION_FORMATS[var20].format(var22);
				var1.append(var13);
			} else if (var8.size() > 1) {
				var1.append("|");
				Iterator var18 = this.entityTypes.iterator();

				while (var18.hasNext()) {
					String var19 = (String) var18.next();
					LdapEntity var21 = this.ldapConfigMgr.getLdapEntity(var19);
					var6 = this.ldapConfigMgr.getAttributeName(var21, var5);
					if (var6 == null) {
						throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
								WIMMessageHelper.generateMsgParms(var5, var19), CLASSNAME,
								"genSearchString(StringBuffer searchExpBuffer,PropertyNode propNode)");
					}

					var12 = null;
					Property var24 = var4.getProperty(var19, var5);
					var7 = var24.getType().getName();
					Object var23 = this.ldapConfigMgr.getLdapValue(var2.getValue(), var7,
							this.ldapConfigMgr.getSyntax(var6));
					short var14 = this.ldapConfigMgr.getOperator(var2.getOperator());
					var12 = this.ldapConfigMgr.escapeSpecialCharacters((String) var23);
					Object[] var15 = new Object[]{var6, var12};
					String var16 = this.ldapConfigMgr.CONDITION_FORMATS[var14].format(var15);
					var1.append("(");
					var1.append(var16);
					var1.append(")");
				}
			}

		}
	}

	private void genSearchString(StringBuffer var1, LogicalNode var2) throws WIMException {
		boolean var3 = false;
		if (this.logOps.isEmpty()) {
			var3 = true;
			this.logOps.push(var2.getOperator());
		} else if ((String) this.logOps.peek() != var2.getOperator()) {
			var3 = true;
			this.logOps.push(var2.getOperator());
		}

		if (var3) {
			if (var2.getOperator().equals("and")) {
				var1.append("(&");
			} else {
				var1.append("(|");
			}
		}

		this.genStringChild(var1, (XPathNode) var2.getLeftChild());
		this.genStringChild(var1, (XPathNode) var2.getRightChild());
		if (var3) {
			var1.append(')');
			this.logOps.pop();
		}

	}

	private void genSearchString(StringBuffer var1, ParenthesisNode var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "genSearchString(StringBuffer, ParenthesisNode)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2}));
		}

		XPathNode var4 = (XPathNode) var2.getChild();
		this.genStringChild(var1, var4);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "genSearchString(StringBuffer, ParenthesisNode)");
		}

	}

	private void genStringChild(StringBuffer var1, XPathNode var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "genStringChild(StringBuffer, XPathNode)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2}));
		}

		switch (var2.getNodeType()) {
			case 0 :
				var1.append('(');
				this.genSearchString(var1, (PropertyNode) var2);
				var1.append(')');
				break;
			case 1 :
				this.genSearchString(var1, (LogicalNode) var2);
				break;
			case 2 :
				this.genSearchString(var1, (ParenthesisNode) var2);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "genStringChild(StringBuffer, XPathNode)");
		}

	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}