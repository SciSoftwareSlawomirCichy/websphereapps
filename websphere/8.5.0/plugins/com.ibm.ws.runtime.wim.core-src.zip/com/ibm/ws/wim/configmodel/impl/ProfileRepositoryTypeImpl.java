package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.CustomPropertiesType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EDataTypeEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class ProfileRepositoryTypeImpl extends RepositoryTypeImpl implements ProfileRepositoryType {
	protected EList baseEntries = null;
	protected EList entityTypesNotAllowCreate = null;
	protected EList entityTypesNotAllowUpdate = null;
	protected EList entityTypesNotAllowRead = null;
	protected EList entityTypesNotAllowDelete = null;
	protected EList repositoriesForGroups = null;
	protected EList loginProperties = null;
	protected EList customProperties = null;
	protected static final boolean IS_EXT_ID_UNIQUE_EDEFAULT = true;
	protected boolean isExtIdUnique = true;
	protected boolean isExtIdUniqueESet = false;
	protected static final boolean READ_ONLY_EDEFAULT = false;
	protected boolean readOnly = false;
	protected boolean readOnlyESet = false;
	protected static final boolean SUPPORT_ASYNC_MODE_EDEFAULT = false;
	protected boolean supportAsyncMode = false;
	protected boolean supportAsyncModeESet = false;
	protected static final boolean SUPPORT_EXTERNAL_NAME_EDEFAULT = false;
	protected boolean supportExternalName = false;
	protected boolean supportExternalNameESet = false;
	protected static final boolean SUPPORT_PAGING_EDEFAULT = false;
	protected boolean supportPaging = false;
	protected boolean supportPagingESet = false;
	protected static final boolean SUPPORT_SORTING_EDEFAULT = false;
	protected boolean supportSorting = false;
	protected boolean supportSortingESet = false;
	protected static final boolean SUPPORT_TRANSACTIONS_EDEFAULT = false;
	protected boolean supportTransactions = false;
	protected boolean supportTransactionsESet = false;
	protected static final String SUPPORT_CHANGE_LOG_EDEFAULT = "none";
	protected String supportChangeLog = "none";
	protected boolean supportChangeLogESet = false;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getProfileRepositoryType();
	}

	public BaseEntriesType[] getBaseEntriesAsArray() {
		List var1 = this.getBaseEntries();
		return (BaseEntriesType[]) ((BaseEntriesType[]) var1.toArray(new BaseEntriesType[var1.size()]));
	}

	public List getBaseEntries() {
		if (this.baseEntries == null) {
			this.baseEntries = new EObjectContainmentEList(BaseEntriesType.class, this, 2);
		}

		return this.baseEntries;
	}

	public BaseEntriesType createBaseEntries() {
		BaseEntriesType var1 = ConfigmodelFactory.eINSTANCE.createBaseEntriesType();
		this.getBaseEntries().add(var1);
		return var1;
	}

	public String[] getEntityTypesNotAllowCreateAsArray() {
		List var1 = this.getEntityTypesNotAllowCreate();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getEntityTypesNotAllowCreate() {
		if (this.entityTypesNotAllowCreate == null) {
			this.entityTypesNotAllowCreate = new EDataTypeEList(String.class, this, 3);
		}

		return this.entityTypesNotAllowCreate;
	}

	public String[] getEntityTypesNotAllowUpdateAsArray() {
		List var1 = this.getEntityTypesNotAllowUpdate();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getEntityTypesNotAllowUpdate() {
		if (this.entityTypesNotAllowUpdate == null) {
			this.entityTypesNotAllowUpdate = new EDataTypeEList(String.class, this, 4);
		}

		return this.entityTypesNotAllowUpdate;
	}

	public String[] getEntityTypesNotAllowReadAsArray() {
		List var1 = this.getEntityTypesNotAllowRead();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getEntityTypesNotAllowRead() {
		if (this.entityTypesNotAllowRead == null) {
			this.entityTypesNotAllowRead = new EDataTypeEList(String.class, this, 5);
		}

		return this.entityTypesNotAllowRead;
	}

	public String[] getEntityTypesNotAllowDeleteAsArray() {
		List var1 = this.getEntityTypesNotAllowDelete();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getEntityTypesNotAllowDelete() {
		if (this.entityTypesNotAllowDelete == null) {
			this.entityTypesNotAllowDelete = new EDataTypeEList(String.class, this, 6);
		}

		return this.entityTypesNotAllowDelete;
	}

	public String[] getRepositoriesForGroupsAsArray() {
		List var1 = this.getRepositoriesForGroups();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getRepositoriesForGroups() {
		if (this.repositoriesForGroups == null) {
			this.repositoriesForGroups = new EDataTypeEList(String.class, this, 7);
		}

		return this.repositoriesForGroups;
	}

	public String[] getLoginPropertiesAsArray() {
		List var1 = this.getLoginProperties();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getLoginProperties() {
		if (this.loginProperties == null) {
			this.loginProperties = new EDataTypeEList(String.class, this, 8);
		}

		return this.loginProperties;
	}

	public CustomPropertiesType[] getCustomPropertiesAsArray() {
		List var1 = this.getCustomProperties();
		return (CustomPropertiesType[]) ((CustomPropertiesType[]) var1.toArray(new CustomPropertiesType[var1.size()]));
	}

	public List getCustomProperties() {
		if (this.customProperties == null) {
			this.customProperties = new EObjectContainmentEList(CustomPropertiesType.class, this, 9);
		}

		return this.customProperties;
	}

	public CustomPropertiesType createCustomProperties() {
		CustomPropertiesType var1 = ConfigmodelFactory.eINSTANCE.createCustomPropertiesType();
		this.getCustomProperties().add(var1);
		return var1;
	}

	public boolean isIsExtIdUnique() {
		return this.isExtIdUnique;
	}

	public void setIsExtIdUnique(boolean var1) {
		boolean var2 = this.isExtIdUnique;
		this.isExtIdUnique = var1;
		boolean var3 = this.isExtIdUniqueESet;
		this.isExtIdUniqueESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 10, var2, this.isExtIdUnique, !var3));
		}

	}

	public void unsetIsExtIdUnique() {
		boolean var1 = this.isExtIdUnique;
		boolean var2 = this.isExtIdUniqueESet;
		this.isExtIdUnique = true;
		this.isExtIdUniqueESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 10, var1, true, var2));
		}

	}

	public boolean isSetIsExtIdUnique() {
		return this.isExtIdUniqueESet;
	}

	public boolean isReadOnly() {
		return this.readOnly;
	}

	public void setReadOnly(boolean var1) {
		boolean var2 = this.readOnly;
		this.readOnly = var1;
		boolean var3 = this.readOnlyESet;
		this.readOnlyESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 11, var2, this.readOnly, !var3));
		}

	}

	public void unsetReadOnly() {
		boolean var1 = this.readOnly;
		boolean var2 = this.readOnlyESet;
		this.readOnly = false;
		this.readOnlyESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 11, var1, false, var2));
		}

	}

	public boolean isSetReadOnly() {
		return this.readOnlyESet;
	}

	public boolean isSupportAsyncMode() {
		return this.supportAsyncMode;
	}

	public void setSupportAsyncMode(boolean var1) {
		boolean var2 = this.supportAsyncMode;
		this.supportAsyncMode = var1;
		boolean var3 = this.supportAsyncModeESet;
		this.supportAsyncModeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 12, var2, this.supportAsyncMode, !var3));
		}

	}

	public void unsetSupportAsyncMode() {
		boolean var1 = this.supportAsyncMode;
		boolean var2 = this.supportAsyncModeESet;
		this.supportAsyncMode = false;
		this.supportAsyncModeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 12, var1, false, var2));
		}

	}

	public boolean isSetSupportAsyncMode() {
		return this.supportAsyncModeESet;
	}

	public boolean isSupportExternalName() {
		return this.supportExternalName;
	}

	public void setSupportExternalName(boolean var1) {
		boolean var2 = this.supportExternalName;
		this.supportExternalName = var1;
		boolean var3 = this.supportExternalNameESet;
		this.supportExternalNameESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 13, var2, this.supportExternalName, !var3));
		}

	}

	public void unsetSupportExternalName() {
		boolean var1 = this.supportExternalName;
		boolean var2 = this.supportExternalNameESet;
		this.supportExternalName = false;
		this.supportExternalNameESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 13, var1, false, var2));
		}

	}

	public boolean isSetSupportExternalName() {
		return this.supportExternalNameESet;
	}

	public boolean isSupportPaging() {
		return this.supportPaging;
	}

	public void setSupportPaging(boolean var1) {
		boolean var2 = this.supportPaging;
		this.supportPaging = var1;
		boolean var3 = this.supportPagingESet;
		this.supportPagingESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 14, var2, this.supportPaging, !var3));
		}

	}

	public void unsetSupportPaging() {
		boolean var1 = this.supportPaging;
		boolean var2 = this.supportPagingESet;
		this.supportPaging = false;
		this.supportPagingESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 14, var1, false, var2));
		}

	}

	public boolean isSetSupportPaging() {
		return this.supportPagingESet;
	}

	public boolean isSupportSorting() {
		return this.supportSorting;
	}

	public void setSupportSorting(boolean var1) {
		boolean var2 = this.supportSorting;
		this.supportSorting = var1;
		boolean var3 = this.supportSortingESet;
		this.supportSortingESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 15, var2, this.supportSorting, !var3));
		}

	}

	public void unsetSupportSorting() {
		boolean var1 = this.supportSorting;
		boolean var2 = this.supportSortingESet;
		this.supportSorting = false;
		this.supportSortingESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 15, var1, false, var2));
		}

	}

	public boolean isSetSupportSorting() {
		return this.supportSortingESet;
	}

	public boolean isSupportTransactions() {
		return this.supportTransactions;
	}

	public void setSupportTransactions(boolean var1) {
		boolean var2 = this.supportTransactions;
		this.supportTransactions = var1;
		boolean var3 = this.supportTransactionsESet;
		this.supportTransactionsESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 16, var2, this.supportTransactions, !var3));
		}

	}

	public void unsetSupportTransactions() {
		boolean var1 = this.supportTransactions;
		boolean var2 = this.supportTransactionsESet;
		this.supportTransactions = false;
		this.supportTransactionsESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 16, var1, false, var2));
		}

	}

	public boolean isSetSupportTransactions() {
		return this.supportTransactionsESet;
	}

	public String getSupportChangeLog() {
		return this.supportChangeLog;
	}

	public void setSupportChangeLog(String var1) {
		String var2 = this.supportChangeLog;
		this.supportChangeLog = var1;
		boolean var3 = this.supportChangeLogESet;
		this.supportChangeLogESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 17, var2, this.supportChangeLog, !var3));
		}

	}

	public void unsetSupportChangeLog() {
		String var1 = this.supportChangeLog;
		boolean var2 = this.supportChangeLogESet;
		this.supportChangeLog = "none";
		this.supportChangeLogESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 17, var1, "none", var2));
		}

	}

	public boolean isSetSupportChangeLog() {
		return this.supportChangeLogESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 2 :
					return ((InternalEList) this.getBaseEntries()).basicRemove(var1, var4);
				case 9 :
					return ((InternalEList) this.getCustomProperties()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getAdapterClassName();
			case 1 :
				return this.getId();
			case 2 :
				return this.getBaseEntries();
			case 3 :
				return this.getEntityTypesNotAllowCreate();
			case 4 :
				return this.getEntityTypesNotAllowUpdate();
			case 5 :
				return this.getEntityTypesNotAllowRead();
			case 6 :
				return this.getEntityTypesNotAllowDelete();
			case 7 :
				return this.getRepositoriesForGroups();
			case 8 :
				return this.getLoginProperties();
			case 9 :
				return this.getCustomProperties();
			case 10 :
				return this.isIsExtIdUnique() ? Boolean.TRUE : Boolean.FALSE;
			case 11 :
				return this.isReadOnly() ? Boolean.TRUE : Boolean.FALSE;
			case 12 :
				return this.isSupportAsyncMode() ? Boolean.TRUE : Boolean.FALSE;
			case 13 :
				return this.isSupportExternalName() ? Boolean.TRUE : Boolean.FALSE;
			case 14 :
				return this.isSupportPaging() ? Boolean.TRUE : Boolean.FALSE;
			case 15 :
				return this.isSupportSorting() ? Boolean.TRUE : Boolean.FALSE;
			case 16 :
				return this.isSupportTransactions() ? Boolean.TRUE : Boolean.FALSE;
			case 17 :
				return this.getSupportChangeLog();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName((String) var2);
				return;
			case 1 :
				this.setId((String) var2);
				return;
			case 2 :
				this.getBaseEntries().clear();
				this.getBaseEntries().addAll((Collection) var2);
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				this.getEntityTypesNotAllowCreate().addAll((Collection) var2);
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				this.getEntityTypesNotAllowUpdate().addAll((Collection) var2);
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				this.getEntityTypesNotAllowRead().addAll((Collection) var2);
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				this.getEntityTypesNotAllowDelete().addAll((Collection) var2);
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				this.getRepositoriesForGroups().addAll((Collection) var2);
				return;
			case 8 :
				this.getLoginProperties().clear();
				this.getLoginProperties().addAll((Collection) var2);
				return;
			case 9 :
				this.getCustomProperties().clear();
				this.getCustomProperties().addAll((Collection) var2);
				return;
			case 10 :
				this.setIsExtIdUnique((Boolean) var2);
				return;
			case 11 :
				this.setReadOnly((Boolean) var2);
				return;
			case 12 :
				this.setSupportAsyncMode((Boolean) var2);
				return;
			case 13 :
				this.setSupportExternalName((Boolean) var2);
				return;
			case 14 :
				this.setSupportPaging((Boolean) var2);
				return;
			case 15 :
				this.setSupportSorting((Boolean) var2);
				return;
			case 16 :
				this.setSupportTransactions((Boolean) var2);
				return;
			case 17 :
				this.setSupportChangeLog((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName(ADAPTER_CLASS_NAME_EDEFAULT);
				return;
			case 1 :
				this.setId(ID_EDEFAULT);
				return;
			case 2 :
				this.getBaseEntries().clear();
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				return;
			case 8 :
				this.getLoginProperties().clear();
				return;
			case 9 :
				this.getCustomProperties().clear();
				return;
			case 10 :
				this.unsetIsExtIdUnique();
				return;
			case 11 :
				this.unsetReadOnly();
				return;
			case 12 :
				this.unsetSupportAsyncMode();
				return;
			case 13 :
				this.unsetSupportExternalName();
				return;
			case 14 :
				this.unsetSupportPaging();
				return;
			case 15 :
				this.unsetSupportSorting();
				return;
			case 16 :
				this.unsetSupportTransactions();
				return;
			case 17 :
				this.unsetSupportChangeLog();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return ADAPTER_CLASS_NAME_EDEFAULT == null
						? this.adapterClassName != null
						: !ADAPTER_CLASS_NAME_EDEFAULT.equals(this.adapterClassName);
			case 1 :
				return ID_EDEFAULT == null ? this.id != null : !ID_EDEFAULT.equals(this.id);
			case 2 :
				return this.baseEntries != null && !this.baseEntries.isEmpty();
			case 3 :
				return this.entityTypesNotAllowCreate != null && !this.entityTypesNotAllowCreate.isEmpty();
			case 4 :
				return this.entityTypesNotAllowUpdate != null && !this.entityTypesNotAllowUpdate.isEmpty();
			case 5 :
				return this.entityTypesNotAllowRead != null && !this.entityTypesNotAllowRead.isEmpty();
			case 6 :
				return this.entityTypesNotAllowDelete != null && !this.entityTypesNotAllowDelete.isEmpty();
			case 7 :
				return this.repositoriesForGroups != null && !this.repositoriesForGroups.isEmpty();
			case 8 :
				return this.loginProperties != null && !this.loginProperties.isEmpty();
			case 9 :
				return this.customProperties != null && !this.customProperties.isEmpty();
			case 10 :
				return this.isSetIsExtIdUnique();
			case 11 :
				return this.isSetReadOnly();
			case 12 :
				return this.isSetSupportAsyncMode();
			case 13 :
				return this.isSetSupportExternalName();
			case 14 :
				return this.isSetSupportPaging();
			case 15 :
				return this.isSetSupportSorting();
			case 16 :
				return this.isSetSupportTransactions();
			case 17 :
				return this.isSetSupportChangeLog();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (entityTypesNotAllowCreate: ");
			var1.append(this.entityTypesNotAllowCreate);
			var1.append(", entityTypesNotAllowUpdate: ");
			var1.append(this.entityTypesNotAllowUpdate);
			var1.append(", entityTypesNotAllowRead: ");
			var1.append(this.entityTypesNotAllowRead);
			var1.append(", entityTypesNotAllowDelete: ");
			var1.append(this.entityTypesNotAllowDelete);
			var1.append(", repositoriesForGroups: ");
			var1.append(this.repositoriesForGroups);
			var1.append(", loginProperties: ");
			var1.append(this.loginProperties);
			var1.append(", isExtIdUnique: ");
			if (this.isExtIdUniqueESet) {
				var1.append(this.isExtIdUnique);
			} else {
				var1.append("<unset>");
			}

			var1.append(", readOnly: ");
			if (this.readOnlyESet) {
				var1.append(this.readOnly);
			} else {
				var1.append("<unset>");
			}

			var1.append(", supportAsyncMode: ");
			if (this.supportAsyncModeESet) {
				var1.append(this.supportAsyncMode);
			} else {
				var1.append("<unset>");
			}

			var1.append(", supportExternalName: ");
			if (this.supportExternalNameESet) {
				var1.append(this.supportExternalName);
			} else {
				var1.append("<unset>");
			}

			var1.append(", supportPaging: ");
			if (this.supportPagingESet) {
				var1.append(this.supportPaging);
			} else {
				var1.append("<unset>");
			}

			var1.append(", supportSorting: ");
			if (this.supportSortingESet) {
				var1.append(this.supportSorting);
			} else {
				var1.append("<unset>");
			}

			var1.append(", supportTransactions: ");
			if (this.supportTransactionsESet) {
				var1.append(this.supportTransactions);
			} else {
				var1.append("<unset>");
			}

			var1.append(", supportChangeLog: ");
			if (this.supportChangeLogESet) {
				var1.append(this.supportChangeLog);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}