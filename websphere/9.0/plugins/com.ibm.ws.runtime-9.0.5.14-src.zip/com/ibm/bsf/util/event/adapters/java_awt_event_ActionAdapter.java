package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class java_awt_event_ActionAdapter extends EventAdapterImpl implements ActionListener {
	public void actionPerformed(ActionEvent var1) {
		this.eventProcessor.processEvent("actionPerformed", new Object[]{var1});
	}
}