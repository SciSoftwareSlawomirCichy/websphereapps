package com.ibm.CSIv2Security;

public interface RSAPropMechOID {
	String value = "oid:1.3.18.0.2.30.6";
}