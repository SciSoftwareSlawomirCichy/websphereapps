package com.ibm.ejs.container;

import com.ibm.ws.csi.DispatchEventListenerCookie;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;

public interface DispatchEventListenerManager {
	boolean dispatchEventListenersAreActive();

	DispatchEventListenerCookie[] getNewDispatchEventListenerCookieArray();

	void callDispatchEventListeners(int var1, DispatchEventListenerCookie[] var2, EJBMethodMetaData var3);
}