package com.ibm.bsf;

import com.ibm.bsf.BSFManager.1;
import com.ibm.bsf.BSFManager.2;
import com.ibm.bsf.BSFManager.3;
import com.ibm.bsf.BSFManager.4;
import com.ibm.bsf.BSFManager.5;
import com.ibm.bsf.BSFManager.6;
import com.ibm.bsf.BSFManager.7;
import com.ibm.bsf.BSFManager.8;
import com.ibm.bsf.BSFManager.BSFDebugManager;
import com.ibm.bsf.util.CodeBuffer;
import com.ibm.bsf.util.ObjectRegistry;
import java.beans.PropertyChangeSupport;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.MissingResourceException;
import java.util.NoSuchElementException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Vector;

public class BSFManager {
	protected static Hashtable registeredEngines = new Hashtable();
	protected static Hashtable extn2Lang = new Hashtable();
	protected Hashtable loadedEngines = new Hashtable();
	protected ObjectRegistry objectRegistry = new ObjectRegistry();
	protected PropertyChangeSupport pcs = new PropertyChangeSupport(this);
	protected ClassLoader classLoader = this.getClass().getClassLoader();
	protected String tempDir = ".";
	protected String classPath;
	protected Vector declaredBeans = new Vector();

	public Object apply(String var1, String var2, int var3, int var4, Object var5, Vector var6, Vector var7) throws BSFException {
      BSFEngine var8 = this.loadScriptingEngine(var1);
      String var9 = var2;
      int var10 = var3;
      int var11 = var4;
      Object var12 = var5;
      Vector var13 = var6;
      Vector var14 = var7;
      Object var15 = null;

      try {
         Object var16 = AccessController.doPrivileged(new 1(this, var8, var9, var10, var11, var12, var13, var14));
         return var16;
      } catch (PrivilegedActionException var17) {
         throw (BSFException)var17.getException();
      }
   }

	public void compileApply(String var1, String var2, int var3, int var4, Object var5, Vector var6, Vector var7, CodeBuffer var8) throws BSFException {
      BSFEngine var9 = this.loadScriptingEngine(var1);
      String var10 = var2;
      int var11 = var3;
      int var12 = var4;
      Object var13 = var5;
      Vector var14 = var6;
      Vector var15 = var7;
      CodeBuffer var16 = var8;

      try {
         AccessController.doPrivileged(new 2(this, var9, var10, var11, var12, var13, var14, var15, var16));
      } catch (PrivilegedActionException var18) {
         throw (BSFException)var18.getException();
      }
   }

	public void compileExpr(String var1, String var2, int var3, int var4, Object var5, CodeBuffer var6) throws BSFException {
      BSFEngine var7 = this.loadScriptingEngine(var1);
      String var8 = var2;
      int var9 = var3;
      int var10 = var4;
      Object var11 = var5;
      CodeBuffer var12 = var6;

      try {
         AccessController.doPrivileged(new 3(this, var7, var8, var9, var10, var11, var12));
      } catch (PrivilegedActionException var14) {
         throw (BSFException)var14.getException();
      }
   }

	public void compileScript(String var1, String var2, int var3, int var4, Object var5, CodeBuffer var6) throws BSFException {
      BSFEngine var7 = this.loadScriptingEngine(var1);
      String var8 = var2;
      int var9 = var3;
      int var10 = var4;
      Object var11 = var5;
      CodeBuffer var12 = var6;

      try {
         AccessController.doPrivileged(new 4(this, var7, var8, var9, var10, var11, var12));
      } catch (PrivilegedActionException var14) {
         throw (BSFException)var14.getException();
      }
   }

	public void declareBean(String var1, Object var2, Class var3) throws BSFException {
		this.registerBean(var1, var2);
		BSFDeclaredBean var4 = new BSFDeclaredBean(var1, var2, var3);
		this.declaredBeans.addElement(var4);
		Enumeration var5 = this.loadedEngines.elements();

		while (var5.hasMoreElements()) {
			BSFEngine var6 = (BSFEngine) var5.nextElement();
			var6.declareBean(var4);
		}

	}

	public Object eval(String var1, String var2, int var3, int var4, Object var5) throws BSFException {
      BSFEngine var6 = this.loadScriptingEngine(var1);
      String var7 = var2;
      int var8 = var3;
      int var9 = var4;
      Object var10 = var5;
      Object var11 = null;

      try {
         Object var12 = AccessController.doPrivileged(new 5(this, var6, var7, var8, var9, var10));
         return var12;
      } catch (PrivilegedActionException var13) {
         throw (BSFException)var13.getException();
      }
   }

	public void exec(String var1, String var2, int var3, int var4, Object var5) throws BSFException {
      BSFEngine var6 = this.loadScriptingEngine(var1);
      String var7 = var2;
      int var8 = var3;
      int var9 = var4;
      Object var10 = var5;

      try {
         AccessController.doPrivileged(new 6(this, var6, var7, var8, var9, var10));
      } catch (PrivilegedActionException var12) {
         throw (BSFException)var12.getException();
      }
   }

	public void iexec(String var1, String var2, int var3, int var4, Object var5) throws BSFException {
      BSFEngine var6 = this.loadScriptingEngine(var1);
      String var7 = var2;
      int var8 = var3;
      int var9 = var4;
      Object var10 = var5;

      try {
         AccessController.doPrivileged(new 7(this, var6, var7, var8, var9, var10));
      } catch (PrivilegedActionException var12) {
         throw (BSFException)var12.getException();
      }
   }

	public ClassLoader getClassLoader() {
		return this.classLoader;
	}

	public String getClassPath() {
		if (this.classPath == null) {
			try {
				this.classPath = System.getProperty("java.class.path");
			} catch (Throwable var2) {
				;
			}
		}

		return this.classPath;
	}

	public static BSFDebugManager getDebugManager() {
		return null;
	}

	public static String getLangFromFilename(String var0) throws BSFException {
		int var1 = var0.lastIndexOf(".");
		if (var1 != -1) {
			String var2 = var0.substring(var1 + 1);
			String var3 = (String) extn2Lang.get(var2);
			String var4 = null;
			boolean var5 = false;
			int var6 = 0;
			if (var3 != null) {
				int var9;
				while ((var9 = var3.indexOf(":", 0)) != -1) {
					var4 = var3.substring(0, var9);
					var3 = var3.substring(var9 + 1);
					++var6;

					try {
						String var7 = (String) registeredEngines.get(var4);
						Class.forName(var7, true, Thread.currentThread().getContextClassLoader());
						break;
					} catch (ClassNotFoundException var8) {
						var4 = var3;
					}
				}

				if (var6 == 0) {
					var4 = var3;
				}
			}

			if (var4 != null && var4 != "") {
				return var4;
			}
		}

		throw new BSFException(BSFException.REASON_OTHER_ERROR,
				"file extension missing or unknown: unable to determine language for '" + var0 + "'");
	}

	public ObjectRegistry getObjectRegistry() {
		return this.objectRegistry;
	}

	public String getTempDir() {
		return this.tempDir;
	}

	public static boolean isLanguageRegistered(String var0) {
		return registeredEngines.get(var0) != null;
	}

	public BSFEngine loadScriptingEngine(String var1) throws BSFException {
      BSFEngine var2 = (BSFEngine)this.loadedEngines.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         String var3 = (String)registeredEngines.get(var1);
         if (var3 == null) {
            throw new BSFException(BSFException.REASON_UNKNOWN_LANGUAGE, "unsupported language: " + var1);
         } else {
            try {
               Class var4 = this.classLoader == null ? Class.forName(var3, true, Thread.currentThread().getContextClassLoader()) : this.classLoader.loadClass(var3);
               BSFEngine var5 = (BSFEngine)var4.newInstance();
               Vector var8 = this.declaredBeans;
               AccessController.doPrivileged(new 8(this, var5, this, var1, var8));
               this.loadedEngines.put(var1, var5);
               this.pcs.addPropertyChangeListener(var5);
               return var5;
            } catch (PrivilegedActionException var9) {
               throw (BSFException)var9.getException();
            } catch (Throwable var10) {
               throw new BSFException(BSFException.REASON_OTHER_ERROR, "unable to load language: " + var1, var10);
            }
         }
      }
   }

	public static void initBSFDebugManager() {
	}

	public Object lookupBean(String var1) {
		try {
			return this.objectRegistry.lookup(var1);
		} catch (IllegalArgumentException var3) {
			return null;
		}
	}

	public void registerBean(String var1, Object var2) {
		this.objectRegistry.register(var1, var2);
	}

	public static void registerScriptingEngine(String var0, String var1, String[] var2) {
		registeredEngines.put(var0, var1);
		if (var2 != null) {
			for (int var3 = 0; var3 < var2.length; ++var3) {
				String var4 = (String) extn2Lang.get(var2[var3]);
				var4 = var4 == null ? var0 : var0 + ":" + var4;
				extn2Lang.put(var2[var3], var4);
			}
		}

	}

	public void setClassLoader(ClassLoader var1) {
		this.pcs.firePropertyChange("classLoader", this.classLoader, var1);
		this.classLoader = var1;
	}

	public void setClassPath(String var1) {
		this.pcs.firePropertyChange("classPath", this.classPath, var1);
		this.classPath = var1;
	}

	public void setObjectRegistry(ObjectRegistry var1) {
		this.objectRegistry = var1;
	}

	public void setTempDir(String var1) {
		this.pcs.firePropertyChange("tempDir", this.tempDir, var1);
		this.tempDir = var1;
	}

	public void terminate() {
		Enumeration var1 = this.loadedEngines.elements();

		while (var1.hasMoreElements()) {
			BSFEngine var2 = (BSFEngine) var1.nextElement();
			var2.terminate();
		}

		this.loadedEngines = new Hashtable();
	}

	public void undeclareBean(String var1) throws BSFException {
		this.unregisterBean(var1);
		BSFDeclaredBean var2 = null;

		for (int var3 = 0; var3 < this.declaredBeans.size(); ++var3) {
			var2 = (BSFDeclaredBean) this.declaredBeans.elementAt(var3);
			if (var2.name.equals(var1)) {
				break;
			}
		}

		if (var2 != null) {
			this.declaredBeans.removeElement(var2);
			Enumeration var5 = this.loadedEngines.elements();

			while (var5.hasMoreElements()) {
				BSFEngine var4 = (BSFEngine) var5.nextElement();
				var4.undeclareBean(var2);
			}
		}

	}

	public void unregisterBean(String var1) {
		this.objectRegistry.unregister(var1);
	}

	static {
		try {
			ResourceBundle var0 = ResourceBundle.getBundle("com.ibm.bsf.Languages");
			Enumeration var1 = var0.getKeys();

			while (var1.hasMoreElements()) {
				String var2 = (String) var1.nextElement();
				String var3 = var0.getString(var2);
				StringTokenizer var4 = new StringTokenizer(var3, ",");
				String var5 = var4.nextToken();
				String var6 = var4.nextToken();
				StringTokenizer var7 = new StringTokenizer(var6, "|");
				String[] var8 = new String[var7.countTokens()];

				for (int var9 = 0; var7.hasMoreTokens(); ++var9) {
					var8[var9] = var7.nextToken().trim();
				}

				registerScriptingEngine(var2, var5, var8);
			}
		} catch (NoSuchElementException var10) {
			var10.printStackTrace();
			System.err.println("Syntax error in Languages resource bundle");
		} catch (MissingResourceException var11) {
			var11.printStackTrace();
			System.err.println("Initialization error: " + var11.toString());
		}

	}
}