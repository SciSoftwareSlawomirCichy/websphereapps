package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.collect.MinMaxPriorityQueue.1;
import com.google.common.collect.MinMaxPriorityQueue.Builder;
import com.google.common.collect.MinMaxPriorityQueue.Heap;
import com.google.common.collect.MinMaxPriorityQueue.MoveDesc;
import com.google.common.collect.MinMaxPriorityQueue.QueueIterator;
import com.google.common.math.IntMath;
import java.util.AbstractQueue;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

@Beta
public final class MinMaxPriorityQueue<E> extends AbstractQueue<E> {
	private final MinMaxPriorityQueue<E>.Heap minHeap;
	private final MinMaxPriorityQueue<E>.Heap maxHeap;
	@VisibleForTesting
	final int maximumSize;
	private Object[] queue;
	private int size;
	private int modCount;
	private static final int EVEN_POWERS_OF_TWO = 1431655765;
	private static final int ODD_POWERS_OF_TWO = -1431655766;
	private static final int DEFAULT_CAPACITY = 11;

	public static <E extends Comparable<E>> MinMaxPriorityQueue<E> create() {
      return (new Builder(Ordering.natural(), (1)null)).create();
   }

	public static <E extends Comparable<E>> MinMaxPriorityQueue<E> create(Iterable<? extends E> initialContents) {
      return (new Builder(Ordering.natural(), (1)null)).create(initialContents);
   }

	public static <B> Builder<B> orderedBy(Comparator<B> comparator) {
      return new Builder(comparator, (1)null);
   }

	public static Builder<Comparable> expectedSize(int expectedSize) {
      return (new Builder(Ordering.natural(), (1)null)).expectedSize(expectedSize);
   }

	public static Builder<Comparable> maximumSize(int maximumSize) {
      return (new Builder(Ordering.natural(), (1)null)).maximumSize(maximumSize);
   }

	private MinMaxPriorityQueue(Builder<? super E> builder, int queueSize) {
		Ordering<E> ordering = Builder.access$200(builder);
		this.minHeap = new Heap(this, ordering);
		this.maxHeap = new Heap(this, ordering.reverse());
		this.minHeap.otherHeap = this.maxHeap;
		this.maxHeap.otherHeap = this.minHeap;
		this.maximumSize = Builder.access$300(builder);
		this.queue = new Object[queueSize];
	}

	public int size() {
		return this.size;
	}

	public boolean add(E element) {
		this.offer(element);
		return true;
	}

	public boolean addAll(Collection<? extends E> newElements) {
		boolean modified = false;

		for (Iterator i$ = newElements.iterator(); i$.hasNext(); modified = true) {
			E element = i$.next();
			this.offer(element);
		}

		return modified;
	}

	public boolean offer(E element) {
		Preconditions.checkNotNull(element);
		++this.modCount;
		int insertIndex = this.size++;
		this.growIfNeeded();
		this.heapForIndex(insertIndex).bubbleUp(insertIndex, element);
		return this.size <= this.maximumSize || this.pollLast() != element;
	}

	public E poll() {
		return this.isEmpty() ? null : this.removeAndGet(0);
	}

	E elementData(int index) {
		return this.queue[index];
	}

	public E peek() {
		return this.isEmpty() ? null : this.elementData(0);
	}

	private int getMaxElementIndex() {
		switch (this.size) {
			case 1 :
				return 0;
			case 2 :
				return 1;
			default :
				return this.maxHeap.compareElements(1, 2) <= 0 ? 1 : 2;
		}
	}

	public E pollFirst() {
		return this.poll();
	}

	public E removeFirst() {
		return this.remove();
	}

	public E peekFirst() {
		return this.peek();
	}

	public E pollLast() {
		return this.isEmpty() ? null : this.removeAndGet(this.getMaxElementIndex());
	}

	public E removeLast() {
		if (this.isEmpty()) {
			throw new NoSuchElementException();
		} else {
			return this.removeAndGet(this.getMaxElementIndex());
		}
	}

	public E peekLast() {
		return this.isEmpty() ? null : this.elementData(this.getMaxElementIndex());
	}

	@VisibleForTesting
	MoveDesc<E> removeAt(int index) {
		Preconditions.checkPositionIndex(index, this.size);
		++this.modCount;
		--this.size;
		if (this.size == index) {
			this.queue[this.size] = null;
			return null;
		} else {
			E actualLastElement = this.elementData(this.size);
			int lastElementAt = this.heapForIndex(this.size).getCorrectLastElement(actualLastElement);
			E toTrickle = this.elementData(this.size);
			this.queue[this.size] = null;
			MoveDesc<E> changes = this.fillHole(index, toTrickle);
			if (lastElementAt < index) {
				return changes == null
						? new MoveDesc(actualLastElement, toTrickle)
						: new MoveDesc(actualLastElement, changes.replaced);
			} else {
				return changes;
			}
		}
	}

	private MoveDesc<E> fillHole(int index, E toTrickle) {
		MinMaxPriorityQueue<E>.Heap heap = this.heapForIndex(index);
		int vacated = heap.fillHoleAt(index);
		int bubbledTo = heap.bubbleUpAlternatingLevels(vacated, toTrickle);
		if (bubbledTo == vacated) {
			return heap.tryCrossOverAndBubbleUp(index, vacated, toTrickle);
		} else {
			return bubbledTo < index ? new MoveDesc(toTrickle, this.elementData(index)) : null;
		}
	}

	private E removeAndGet(int index) {
		E value = this.elementData(index);
		this.removeAt(index);
		return value;
	}

	private MinMaxPriorityQueue<E>.Heap heapForIndex(int i) {
		return isEvenLevel(i) ? this.minHeap : this.maxHeap;
	}

	@VisibleForTesting
	static boolean isEvenLevel(int index) {
		int oneBased = index + 1;
		Preconditions.checkState(oneBased > 0, "negative index");
		return (oneBased & 1431655765) > (oneBased & -1431655766);
	}

	@VisibleForTesting
	boolean isIntact() {
		for (int i = 1; i < this.size; ++i) {
			if (!Heap.access$400(this.heapForIndex(i), i)) {
				return false;
			}
		}

		return true;
	}

	public Iterator<E> iterator() {
      return new QueueIterator(this, (1)null);
   }

	public void clear() {
		for (int i = 0; i < this.size; ++i) {
			this.queue[i] = null;
		}

		this.size = 0;
	}

	public Object[] toArray() {
		Object[] copyTo = new Object[this.size];
		System.arraycopy(this.queue, 0, copyTo, 0, this.size);
		return copyTo;
	}

	public Comparator<? super E> comparator() {
		return this.minHeap.ordering;
	}

	@VisibleForTesting
	int capacity() {
		return this.queue.length;
	}

	@VisibleForTesting
	static int initialQueueSize(int configuredExpectedSize, int maximumSize, Iterable<?> initialContents) {
		int result = configuredExpectedSize == -1 ? 11 : configuredExpectedSize;
		if (initialContents instanceof Collection) {
			int initialSize = ((Collection) initialContents).size();
			result = Math.max(result, initialSize);
		}

		return capAtMaximumSize(result, maximumSize);
	}

	private void growIfNeeded() {
		if (this.size > this.queue.length) {
			int newCapacity = this.calculateNewCapacity();
			Object[] newQueue = new Object[newCapacity];
			System.arraycopy(this.queue, 0, newQueue, 0, this.queue.length);
			this.queue = newQueue;
		}

	}

	private int calculateNewCapacity() {
		int oldCapacity = this.queue.length;
		int newCapacity = oldCapacity < 64 ? (oldCapacity + 1) * 2 : IntMath.checkedMultiply(oldCapacity / 2, 3);
		return capAtMaximumSize(newCapacity, this.maximumSize);
	}

	private static int capAtMaximumSize(int queueSize, int maximumSize) {
		return Math.min(queueSize - 1, maximumSize) + 1;
	}
}