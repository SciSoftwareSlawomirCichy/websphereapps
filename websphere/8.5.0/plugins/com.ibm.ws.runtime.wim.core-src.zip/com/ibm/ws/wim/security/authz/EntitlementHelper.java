package com.ibm.ws.wim.security.authz;

import com.ibm.sec.authz.provider.MethodPermission;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.security.authz.Entitlement;

public class EntitlementHelper extends EntitlementHelperBase {
	static final String COPYRIGHT_NOTICE;

	public static Entitlement getEntitlement(MethodPermission var0) {
		return new Entitlement(var0.getActions(), var0.getResourceType(), var0.getAttribute());
	}

	public static MethodPermission getMethodPermission(Entitlement var0) {
		return var0.isAttributeEntitlement()
				? new MethodPermission(var0.getObject(), var0.getAttribute(), var0.getMethod())
				: new MethodPermission(var0.getObject(), var0.getMethod());
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
	}
}