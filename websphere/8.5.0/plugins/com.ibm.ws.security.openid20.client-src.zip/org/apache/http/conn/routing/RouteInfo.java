package org.apache.http.conn.routing;

import java.net.InetAddress;
import org.apache.http.HttpHost;
import org.apache.http.conn.routing.RouteInfo.LayerType;
import org.apache.http.conn.routing.RouteInfo.TunnelType;

public interface RouteInfo {
	HttpHost getTargetHost();

	InetAddress getLocalAddress();

	int getHopCount();

	HttpHost getHopTarget(int var1);

	HttpHost getProxyHost();

	TunnelType getTunnelType();

	boolean isTunnelled();

	LayerType getLayerType();

	boolean isLayered();

	boolean isSecure();
}