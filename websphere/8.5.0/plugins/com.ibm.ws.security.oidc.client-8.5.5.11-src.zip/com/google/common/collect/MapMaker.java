package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Ascii;
import com.google.common.base.Equivalence;
import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.base.Ticker;
import com.google.common.base.Objects.ToStringHelper;
import com.google.common.collect.MapMaker.ComputingMapAdapter;
import com.google.common.collect.MapMaker.NullComputingConcurrentMap;
import com.google.common.collect.MapMaker.NullConcurrentMap;
import com.google.common.collect.MapMaker.RemovalCause;
import com.google.common.collect.MapMaker.RemovalListener;
import com.google.common.collect.MapMakerInternalMap.Strength;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

@GwtCompatible(emulated = true)
public final class MapMaker extends GenericMapMaker<Object, Object> {
	private static final int DEFAULT_INITIAL_CAPACITY = 16;
	private static final int DEFAULT_CONCURRENCY_LEVEL = 4;
	private static final int DEFAULT_EXPIRATION_NANOS = 0;
	static final int UNSET_INT = -1;
	boolean useCustomMap;
	int initialCapacity = -1;
	int concurrencyLevel = -1;
	int maximumSize = -1;
	Strength keyStrength;
	Strength valueStrength;
	long expireAfterWriteNanos = -1L;
	long expireAfterAccessNanos = -1L;
	RemovalCause nullRemovalCause;
	Equivalence<Object> keyEquivalence;
	Ticker ticker;

	@GwtIncompatible("To be supported")
	MapMaker keyEquivalence(Equivalence<Object> equivalence) {
		Preconditions.checkState(this.keyEquivalence == null, "key equivalence was already set to %s",
				new Object[]{this.keyEquivalence});
		this.keyEquivalence = (Equivalence) Preconditions.checkNotNull(equivalence);
		this.useCustomMap = true;
		return this;
	}

	Equivalence<Object> getKeyEquivalence() {
		return (Equivalence) Objects.firstNonNull(this.keyEquivalence, this.getKeyStrength().defaultEquivalence());
	}

	public MapMaker initialCapacity(int initialCapacity) {
		Preconditions.checkState(this.initialCapacity == -1, "initial capacity was already set to %s",
				new Object[]{this.initialCapacity});
		Preconditions.checkArgument(initialCapacity >= 0);
		this.initialCapacity = initialCapacity;
		return this;
	}

	int getInitialCapacity() {
		return this.initialCapacity == -1 ? 16 : this.initialCapacity;
	}

	@Deprecated
	MapMaker maximumSize(int size) {
		Preconditions.checkState(this.maximumSize == -1, "maximum size was already set to %s",
				new Object[]{this.maximumSize});
		Preconditions.checkArgument(size >= 0, "maximum size must not be negative");
		this.maximumSize = size;
		this.useCustomMap = true;
		if (this.maximumSize == 0) {
			this.nullRemovalCause = RemovalCause.SIZE;
		}

		return this;
	}

	public MapMaker concurrencyLevel(int concurrencyLevel) {
		Preconditions.checkState(this.concurrencyLevel == -1, "concurrency level was already set to %s",
				new Object[]{this.concurrencyLevel});
		Preconditions.checkArgument(concurrencyLevel > 0);
		this.concurrencyLevel = concurrencyLevel;
		return this;
	}

	int getConcurrencyLevel() {
		return this.concurrencyLevel == -1 ? 4 : this.concurrencyLevel;
	}

	@GwtIncompatible("java.lang.ref.WeakReference")
	public MapMaker weakKeys() {
		return this.setKeyStrength(Strength.WEAK);
	}

	MapMaker setKeyStrength(Strength strength) {
		Preconditions.checkState(this.keyStrength == null, "Key strength was already set to %s",
				new Object[]{this.keyStrength});
		this.keyStrength = (Strength) Preconditions.checkNotNull(strength);
		Preconditions.checkArgument(this.keyStrength != Strength.SOFT, "Soft keys are not supported");
		if (strength != Strength.STRONG) {
			this.useCustomMap = true;
		}

		return this;
	}

	Strength getKeyStrength() {
		return (Strength) Objects.firstNonNull(this.keyStrength, Strength.STRONG);
	}

	@GwtIncompatible("java.lang.ref.WeakReference")
	public MapMaker weakValues() {
		return this.setValueStrength(Strength.WEAK);
	}

	@GwtIncompatible("java.lang.ref.SoftReference")
	public MapMaker softValues() {
		return this.setValueStrength(Strength.SOFT);
	}

	MapMaker setValueStrength(Strength strength) {
		Preconditions.checkState(this.valueStrength == null, "Value strength was already set to %s",
				new Object[]{this.valueStrength});
		this.valueStrength = (Strength) Preconditions.checkNotNull(strength);
		if (strength != Strength.STRONG) {
			this.useCustomMap = true;
		}

		return this;
	}

	Strength getValueStrength() {
		return (Strength) Objects.firstNonNull(this.valueStrength, Strength.STRONG);
	}

	@Deprecated
	MapMaker expireAfterWrite(long duration, TimeUnit unit) {
		this.checkExpiration(duration, unit);
		this.expireAfterWriteNanos = unit.toNanos(duration);
		if (duration == 0L && this.nullRemovalCause == null) {
			this.nullRemovalCause = RemovalCause.EXPIRED;
		}

		this.useCustomMap = true;
		return this;
	}

	private void checkExpiration(long duration, TimeUnit unit) {
		Preconditions.checkState(this.expireAfterWriteNanos == -1L, "expireAfterWrite was already set to %s ns",
				new Object[]{this.expireAfterWriteNanos});
		Preconditions.checkState(this.expireAfterAccessNanos == -1L, "expireAfterAccess was already set to %s ns",
				new Object[]{this.expireAfterAccessNanos});
		Preconditions.checkArgument(duration >= 0L, "duration cannot be negative: %s %s", new Object[]{duration, unit});
	}

	long getExpireAfterWriteNanos() {
		return this.expireAfterWriteNanos == -1L ? 0L : this.expireAfterWriteNanos;
	}

	@Deprecated
	@GwtIncompatible("To be supported")
	MapMaker expireAfterAccess(long duration, TimeUnit unit) {
		this.checkExpiration(duration, unit);
		this.expireAfterAccessNanos = unit.toNanos(duration);
		if (duration == 0L && this.nullRemovalCause == null) {
			this.nullRemovalCause = RemovalCause.EXPIRED;
		}

		this.useCustomMap = true;
		return this;
	}

	long getExpireAfterAccessNanos() {
		return this.expireAfterAccessNanos == -1L ? 0L : this.expireAfterAccessNanos;
	}

	Ticker getTicker() {
		return (Ticker) Objects.firstNonNull(this.ticker, Ticker.systemTicker());
	}

	@Deprecated
	@GwtIncompatible("To be supported")
	<K, V> GenericMapMaker<K, V> removalListener(RemovalListener<K, V> listener) {
		Preconditions.checkState(this.removalListener == null);
		super.removalListener = (RemovalListener) Preconditions.checkNotNull(listener);
		this.useCustomMap = true;
		return this;
	}

	public <K, V> ConcurrentMap<K, V> makeMap() {
		return (ConcurrentMap) (!this.useCustomMap
				? new ConcurrentHashMap(this.getInitialCapacity(), 0.75F, this.getConcurrencyLevel())
				: (ConcurrentMap) (this.nullRemovalCause == null
						? new MapMakerInternalMap(this)
						: new NullConcurrentMap(this)));
	}

	@GwtIncompatible("MapMakerInternalMap")
	<K, V> MapMakerInternalMap<K, V> makeCustomMap() {
		return new MapMakerInternalMap(this);
	}

	@Deprecated
	public <K, V> ConcurrentMap<K, V> makeComputingMap(Function<? super K, ? extends V> computingFunction) {
		return (ConcurrentMap) (this.nullRemovalCause == null
				? new ComputingMapAdapter(this, computingFunction)
				: new NullComputingConcurrentMap(this, computingFunction));
	}

	public String toString() {
		ToStringHelper s = Objects.toStringHelper(this);
		if (this.initialCapacity != -1) {
			s.add("initialCapacity", this.initialCapacity);
		}

		if (this.concurrencyLevel != -1) {
			s.add("concurrencyLevel", this.concurrencyLevel);
		}

		if (this.maximumSize != -1) {
			s.add("maximumSize", this.maximumSize);
		}

		if (this.expireAfterWriteNanos != -1L) {
			s.add("expireAfterWrite", this.expireAfterWriteNanos + "ns");
		}

		if (this.expireAfterAccessNanos != -1L) {
			s.add("expireAfterAccess", this.expireAfterAccessNanos + "ns");
		}

		if (this.keyStrength != null) {
			s.add("keyStrength", Ascii.toLowerCase(this.keyStrength.toString()));
		}

		if (this.valueStrength != null) {
			s.add("valueStrength", Ascii.toLowerCase(this.valueStrength.toString()));
		}

		if (this.keyEquivalence != null) {
			s.addValue("keyEquivalence");
		}

		if (this.removalListener != null) {
			s.addValue("removalListener");
		}

		return s.toString();
	}
}