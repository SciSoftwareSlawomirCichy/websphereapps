package com.ibm.icu.impl;

import com.ibm.icu.impl.ICUBinary.Authenticate;
import com.ibm.icu.impl.UPropertyAliases.Builder;
import com.ibm.icu.impl.UPropertyAliases.NameToEnum;
import com.ibm.icu.impl.UPropertyAliases.NonContiguousEnumToShort;
import com.ibm.icu.impl.UPropertyAliases.ValueMap;
import com.ibm.icu.lang.UCharacter;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.MissingResourceException;

public final class UPropertyAliases implements Authenticate {
	private NonContiguousEnumToShort enumToName;
	private NameToEnum nameToEnum;
	private NonContiguousEnumToShort enumToValue;
	private ValueMap[] valueMapArray;
	private short[] nameGroupPool;
	private String[] stringPool;
	private static boolean DEBUG = ICUDebug.enabled("pnames");
	private static final byte[] DATA_FORMAT_ID = new byte[]{112, 110, 97, 109};
	private static final byte DATA_FORMAT_VERSION = 1;
	private static final String DATA_FILE_NAME = "data/icudt44b/pnames.icu";
	private static final int DATA_BUFFER_SIZE = 8192;
	public static final UPropertyAliases INSTANCE;

	private UPropertyAliases() throws IOException {
		InputStream is = ICUData.getRequiredStream("data/icudt44b/pnames.icu");
		BufferedInputStream b = new BufferedInputStream(is, 8192);
		ICUBinary.readHeader(b, DATA_FORMAT_ID, this);
		DataInputStream d = new DataInputStream(b);
		d.mark(256);
		short enumToName_offset = d.readShort();
		short nameToEnum_offset = d.readShort();
		short enumToValue_offset = d.readShort();
		short total_size = d.readShort();
		short valueMap_offset = d.readShort();
		short valueMap_count = d.readShort();
		short nameGroupPool_offset = d.readShort();
		short nameGroupPool_count = d.readShort();
		short stringPool_offset = d.readShort();
		short stringPool_count = d.readShort();
		if (DEBUG) {
			System.out.println("enumToName_offset=" + enumToName_offset + "\n" + "nameToEnum_offset="
					+ nameToEnum_offset + "\n" + "enumToValue_offset=" + enumToValue_offset + "\n" + "total_size="
					+ total_size + "\n" + "valueMap_offset=" + valueMap_offset + "\n" + "valueMap_count="
					+ valueMap_count + "\n" + "nameGroupPool_offset=" + nameGroupPool_offset + "\n"
					+ "nameGroupPool_count=" + nameGroupPool_count + "\n" + "stringPool_offset=" + stringPool_offset
					+ "\n" + "stringPool_count=" + stringPool_count);
		}

		byte[] raw = new byte[total_size];
		d.reset();
		d.readFully(raw);
		d.close();
		Builder builder = new Builder(raw);
		this.stringPool = builder.readStringPool(stringPool_offset, stringPool_count);
		this.nameGroupPool = builder.readNameGroupPool(nameGroupPool_offset, nameGroupPool_count);
		builder.setupValueMap_map(valueMap_offset, valueMap_count);
		builder.seek(enumToName_offset);
		this.enumToName = new NonContiguousEnumToShort(builder);
		Builder.access$000(builder, this.enumToName.offsetArray);
		builder.seek(nameToEnum_offset);
		this.nameToEnum = new NameToEnum(this, builder);
		builder.seek(enumToValue_offset);
		this.enumToValue = new NonContiguousEnumToShort(builder);
		Builder.access$100(builder, this.enumToValue.offsetArray);
		this.valueMapArray = new ValueMap[valueMap_count];

		for (int i = 0; i < valueMap_count; ++i) {
			builder.seek(Builder.access$200(builder)[i]);
			this.valueMapArray[i] = new ValueMap(this, builder);
		}

		builder.close();
	}

	public String getPropertyName(int property, int nameChoice) {
		short nameGroupIndex = this.enumToName.getShort(property);
		return this.chooseNameInGroup(nameGroupIndex, nameChoice);
	}

	public int getPropertyEnum(String propertyAlias) {
		return this.nameToEnum.getEnum(propertyAlias);
	}

	public String getPropertyValueName(int property, int value, int nameChoice) {
		ValueMap vm = this.getValueMap(property);
		short nameGroupIndex = vm.enumToName.getShort(value);
		return this.chooseNameInGroup(nameGroupIndex, nameChoice);
	}

	public int getPropertyValueEnum(int property, String valueAlias) {
		ValueMap vm = this.getValueMap(property);
		return vm.nameToEnum.getEnum(valueAlias);
	}

	public static int compare(String stra, String strb) {
		int istra = 0;
		int istrb = 0;
		int cstra = 0;
		char cstrb = 0;

		while (true) {
			while (true) {
				if (istra < stra.length()) {
					cstra = stra.charAt(istra);
					switch (cstra) {
						case '\t' :
						case '\n' :
						case '' :
						case '\f' :
						case '\r' :
						case ' ' :
						case '-' :
						case '_' :
							++istra;
							continue;
					}
				}

				label52 : while (istrb < strb.length()) {
					cstrb = strb.charAt(istrb);
					switch (cstrb) {
						case '\t' :
						case '\n' :
						case '' :
						case '\f' :
						case '\r' :
						case ' ' :
						case '-' :
						case '_' :
							++istrb;
							break;
						default :
							break label52;
					}
				}

				boolean endstra = istra == stra.length();
				boolean endstrb = istrb == strb.length();
				if (endstra) {
					if (endstrb) {
						return 0;
					}

					cstra = 0;
				} else if (endstrb) {
					cstrb = 0;
				}

				int rc = UCharacter.toLowerCase(cstra) - UCharacter.toLowerCase(cstrb);
				if (rc != 0) {
					return rc;
				}

				++istra;
				++istrb;
			}
		}
	}

	private String chooseNameInGroup(short nameGroupIndex, int nameChoice) {
		if (nameChoice < 0) {
			throw new IllegalIcuArgumentException("Invalid name choice");
		} else {
			do {
				if (nameChoice-- <= 0) {
					short a = this.nameGroupPool[nameGroupIndex];
					return this.stringPool[a < 0 ? -a : a];
				}
			} while (this.nameGroupPool[nameGroupIndex++] >= 0);

			throw new IllegalIcuArgumentException("Invalid name choice");
		}
	}

	private ValueMap getValueMap(int property) {
		int valueMapIndex = this.enumToValue.getShort(property);
		return this.valueMapArray[valueMapIndex];
	}

	public boolean isDataVersionAcceptable(byte[] version) {
		return version[0] == 1;
	}

	static {
		try {
			INSTANCE = new UPropertyAliases();
		} catch (IOException var1) {
			throw new MissingResourceException("Could not construct UPropertyAliases. Missing pnames.icu", "", "");
		}
	}
}