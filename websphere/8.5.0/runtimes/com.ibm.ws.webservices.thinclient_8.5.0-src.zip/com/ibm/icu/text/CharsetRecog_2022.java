package com.ibm.icu.text;

abstract class CharsetRecog_2022 extends CharsetRecognizer {
	int match(byte[] text, int textLen, byte[][] escapeSequences) {
		int hits = 0;
		int misses = 0;
		int shifts = 0;

		label61 : for (int i = 0; i < textLen; ++i) {
			if (text[i] == 27) {
				label54 : for (int escN = 0; escN < escapeSequences.length; ++escN) {
					byte[] seq = escapeSequences[escN];
					if (textLen - i >= seq.length) {
						for (int j = 1; j < seq.length; ++j) {
							if (seq[j] != text[i + j]) {
								continue label54;
							}
						}

						++hits;
						i += seq.length - 1;
						continue label61;
					}
				}

				++misses;
			}

			if (text[i] == 14 || text[i] == 15) {
				++shifts;
			}
		}

		if (hits == 0) {
			return 0;
		} else {
			int quality = (100 * hits - 100 * misses) / (hits + misses);
			if (hits + shifts < 5) {
				quality -= (5 - (hits + shifts)) * 10;
			}

			if (quality < 0) {
				quality = 0;
			}

			return quality;
		}
	}
}