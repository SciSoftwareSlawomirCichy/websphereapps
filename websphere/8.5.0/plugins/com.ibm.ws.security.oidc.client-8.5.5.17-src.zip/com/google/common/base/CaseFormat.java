package com.google.common.base;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.CaseFormat.StringConverter;

@GwtCompatible
public enum CaseFormat {
	LOWER_HYPHEN(CharMatcher.is('-'), "-"), LOWER_UNDERSCORE(CharMatcher.is('_'), "_"), LOWER_CAMEL(
			CharMatcher.inRange('A', 'Z'),
			""), UPPER_CAMEL(CharMatcher.inRange('A', 'Z'), ""), UPPER_UNDERSCORE(CharMatcher.is('_'), "_");

	private final CharMatcher wordBoundary;
	private final String wordSeparator;

	private CaseFormat(CharMatcher wordBoundary, String wordSeparator) {
		this.wordBoundary = wordBoundary;
		this.wordSeparator = wordSeparator;
	}

	public final String to(CaseFormat format, String str) {
		Preconditions.checkNotNull(format);
		Preconditions.checkNotNull(str);
		return format == this ? str : this.convert(format, str);
	}

	String convert(CaseFormat format, String s) {
		StringBuilder out = null;
		int i = 0;
		int j = -1;

		while (true) {
			++j;
			if ((j = this.wordBoundary.indexIn(s, j)) == -1) {
				return i == 0
						? format.normalizeFirstWord(s)
						: out.append(format.normalizeWord(s.substring(i))).toString();
			}

			if (i == 0) {
				out = new StringBuilder(s.length() + 4 * this.wordSeparator.length());
				out.append(format.normalizeFirstWord(s.substring(i, j)));
			} else {
				out.append(format.normalizeWord(s.substring(i, j)));
			}

			out.append(format.wordSeparator);
			i = j + this.wordSeparator.length();
		}
	}

	public Converter<String, String> converterTo(CaseFormat targetFormat) {
		return new StringConverter(this, targetFormat);
	}

	abstract String normalizeWord(String var1);

	private String normalizeFirstWord(String word) {
		return this == LOWER_CAMEL ? Ascii.toLowerCase(word) : this.normalizeWord(word);
	}

	private static String firstCharOnlyToUpper(String word) {
		return word.isEmpty() ? word : Ascii.toUpperCase(word.charAt(0)) + Ascii.toLowerCase(word.substring(1));
	}
}