package com.ibm.ws.wim.registry;

public interface WIMUserRegistryDefines {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	char BACKSLASH = '\\';
	String GROUP_LEVEL = "com.ibm.ws.wim.registry.grouplevel";
	String USE_GLOBAL_TRANS = "com.ibm.ws.wim.registry.useGlobalTransaction";
	String RETURN_REALM_QUALIFIED_ID = "com.ibm.ws.wim.registry.returnRealmQualifiedId";
	String UNIQUE_USER_ID_DEFAULT = "uniqueName";
	String USER_SECURITY_NAME_DEFAULT = "principalName";
	String USER_DISPLAY_NAME_DEFAULT = "principalName";
	String UNIQUE_GROUP_ID_DEFAULT = "uniqueName";
	String GROUP_SECURITY_NAME_DEFAULT = "cn";
	String GROUP_DISPLAY_NAME_DEFAULT = "cn";
}