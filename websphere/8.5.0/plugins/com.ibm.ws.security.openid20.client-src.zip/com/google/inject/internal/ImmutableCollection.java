package com.google.inject.internal;

import com.google.inject.internal.ImmutableCollection.1;
import com.google.inject.internal.ImmutableCollection.SerializedForm;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;

public abstract class ImmutableCollection<E> implements Collection<E>, Serializable {
	static final ImmutableCollection<Object> EMPTY_IMMUTABLE_COLLECTION = new ImmutableCollection.EmptyImmutableCollection((1)null);
	private static final Object[] EMPTY_ARRAY = new Object[0];
	private static final UnmodifiableIterator<Object> EMPTY_ITERATOR = new 1();

	public abstract UnmodifiableIterator<E> iterator();

	public Object[] toArray() {
		Object[] newArray = new Object[this.size()];
		return this.toArray(newArray);
	}

	public <T> T[] toArray(T[] other) {
		int size = this.size();
		if (other.length < size) {
			other = ObjectArrays.newArray(other, size);
		} else if (other.length > size) {
			other[size] = null;
		}

		int index = 0;

		Object element;
		for (Iterator i$ = this.iterator(); i$.hasNext(); other[index++] = element) {
			element = i$.next();
		}

		return other;
	}

	public boolean contains(@Nullable Object object) {
		if (object == null) {
			return false;
		} else {
			Iterator i$ = this.iterator();

			Object element;
			do {
				if (!i$.hasNext()) {
					return false;
				}

				element = i$.next();
			} while (!element.equals(object));

			return true;
		}
	}

	public boolean containsAll(Collection<?> targets) {
		Iterator i$ = targets.iterator();

		Object target;
		do {
			if (!i$.hasNext()) {
				return true;
			}

			target = i$.next();
		} while (this.contains(target));

		return false;
	}

	public boolean isEmpty() {
		return this.size() == 0;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder(this.size() * 16);
		sb.append('[');
		Iterator<E> i = this.iterator();
		if (i.hasNext()) {
			sb.append(i.next());
		}

		while (i.hasNext()) {
			sb.append(", ");
			sb.append(i.next());
		}

		return sb.append(']').toString();
	}

	public final boolean add(E e) {
		throw new UnsupportedOperationException();
	}

	public final boolean remove(Object object) {
		throw new UnsupportedOperationException();
	}

	public final boolean addAll(Collection<? extends E> newElements) {
		throw new UnsupportedOperationException();
	}

	public final boolean removeAll(Collection<?> oldElements) {
		throw new UnsupportedOperationException();
	}

	public final boolean retainAll(Collection<?> elementsToKeep) {
		throw new UnsupportedOperationException();
	}

	public final void clear() {
		throw new UnsupportedOperationException();
	}

	Object writeReplace() {
		return new SerializedForm(this.toArray());
	}

	private static class ArrayImmutableCollection<E> extends ImmutableCollection<E> {
		private final E[] elements;

		ArrayImmutableCollection(E[] elements) {
			this.elements = elements;
		}

		public int size() {
			return this.elements.length;
		}

		public boolean isEmpty() {
			return false;
		}

		public UnmodifiableIterator<E> iterator() {
         return new com.google.inject.internal.ImmutableCollection.ArrayImmutableCollection.1(this);
      }
	}

	private static class EmptyImmutableCollection extends ImmutableCollection<Object> {
		private EmptyImmutableCollection() {
		}

		public int size() {
			return 0;
		}

		public boolean isEmpty() {
			return true;
		}

		public boolean contains(@Nullable Object object) {
			return false;
		}

		public UnmodifiableIterator<Object> iterator() {
			return ImmutableCollection.EMPTY_ITERATOR;
		}

		public Object[] toArray() {
			return ImmutableCollection.EMPTY_ARRAY;
		}

		public <T> T[] toArray(T[] array) {
			if (array.length > 0) {
				array[0] = null;
			}

			return array;
		}
	}
}