package com.ibm.ejs.container;

public class CMStatelessBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, EJSHome h) {
		return new CMStatelessBeanO(c, h);
	}
}