package com.ibm.ws.wim.lookaside;

public class LAPropertyValue {
	private long attributeValueId;
	private int attributeId;
	private String datatypeId;
	private long entityId;
	private long composite;
	private Object value;
	private String ReferenceExternalId;
	private String ReferenceRId;

	public long getComposite() {
		return this.composite;
	}

	public Object getValue() {
		return this.value;
	}

	public void setComposite(long var1) {
		this.composite = var1;
	}

	public void setValue(Object var1) {
		this.value = var1;
	}

	public int getAttributeId() {
		return this.attributeId;
	}

	public void setAttributeId(int var1) {
		this.attributeId = var1;
	}

	public long getAttributeValueId() {
		return this.attributeValueId;
	}

	public void setAttributeValueId(long var1) {
		this.attributeValueId = var1;
	}

	public String getDatatypeId() {
		return this.datatypeId;
	}

	public void setDatatypeId(String var1) {
		this.datatypeId = var1;
	}

	public long getEntityId() {
		return this.entityId;
	}

	public void setEntityId(long var1) {
		this.entityId = var1;
	}

	public String getReferenceExternalId() {
		return this.ReferenceExternalId;
	}

	public void setReferenceExternalId(String var1) {
		this.ReferenceExternalId = var1;
	}

	public String getReferenceRId() {
		return this.ReferenceRId;
	}

	public void setReferenceRId(String var1) {
		this.ReferenceRId = var1;
	}
}