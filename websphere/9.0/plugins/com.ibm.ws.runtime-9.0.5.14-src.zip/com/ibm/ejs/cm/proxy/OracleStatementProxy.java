package com.ibm.ejs.cm.proxy;

import java.sql.Statement;

public final class OracleStatementProxy extends StatementProxy {
	OracleStatementProxy(OracleConnectionProxy parent, Statement statement) {
		super(parent, statement);
	}
}