package com.ibm.ws.wim.adapter.ldap;

import java.util.Hashtable;
import javax.naming.NamingException;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;

public class TimedDirContext extends InitialLdapContext {
	private long iCreateTimestamp;
	private long iPoolTimestamp;

	public TimedDirContext() throws NamingException {
	}

	public TimedDirContext(Hashtable var1, Control[] var2) throws NamingException {
		super(var1, var2);
		this.iCreateTimestamp = System.currentTimeMillis() / 1000L;
		this.iPoolTimestamp = this.iCreateTimestamp;
	}

	public TimedDirContext(Hashtable var1, Control[] var2, long var3) throws NamingException {
		super(var1, var2);
		this.iCreateTimestamp = var3;
		this.iPoolTimestamp = var3;
	}

	public long getCreateTimestamp() {
		return this.iCreateTimestamp;
	}

	public long getPoolTimestamp() {
		return this.iPoolTimestamp;
	}

	public void setPoolTimeStamp(long var1) {
		this.iPoolTimestamp = var1;
	}

	public void setCreateTimestamp(long var1) {
		this.iCreateTimestamp = var1;
	}
}