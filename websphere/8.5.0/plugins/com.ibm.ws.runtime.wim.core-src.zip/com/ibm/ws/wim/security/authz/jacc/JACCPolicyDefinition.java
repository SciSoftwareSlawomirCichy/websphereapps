package com.ibm.ws.wim.security.authz.jacc;

import com.ibm.sec.auth.subjectx.VirtualPrincipal;
import com.ibm.sec.authz.jaccx.condition.ConditionalPermission;
import com.ibm.sec.authz.jaccx.condition.OwnerCondition;
import com.ibm.sec.authz.jaccx.resource.TreeBasedResource;
import com.ibm.sec.authz.jaccx.resource.TreeBasedResourceScope;
import com.ibm.sec.authz.jaccx.role.NonScopedRoleAssignmentCondition;
import com.ibm.sec.authz.jaccx.role.RoleCondition;
import com.ibm.sec.authz.jaccx.role.RoleMappingConfiguration;
import com.ibm.sec.authz.jaccx.role.ScopedRoleAssignmentCondition;
import com.ibm.sec.authz.jaccx.xml.XMLSerializable;
import com.ibm.sec.authz.provider.MethodPermission;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.security.authz.AuthSystemException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.Permission;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.jacc.PolicyConfiguration;

public class JACCPolicyDefinition extends JACCSecurityManager {
	static final String COPYRIGHT_NOTICE;
	public static final boolean POLICY_EXISTS = true;
	public static final boolean POLICY_NOT_EXIST = false;
	public static final String POLICY_ID = "WIM Policy";
	public static final String ROLEMAPPING_ID = "WIM Policy";
	public static final String POLICY_SUBDIR;
	public static final String RESOURCE_ROOT = "/root";
	public static final String OBJECT_ACCOUNT = "Entity/RolePlayer/Party/LoginAccount/*";
	public static final String ATTRGROUP_SENSITIVE = "sensitive";
	public static final String ATTRGROUP_UNCHECKED = "unchecked";
	public static final String ROLE_ACCOUNT_OWNER = "Account-Owner-Role";
	private static final int SOURCE_INTERNAL = 1;
	private static final int SOURCE_FILE = 2;
	private static final String CLASSNAME;
	private static final Logger msgLogger;
	private static final Logger trcLogger;
	static String WILD_CHAR_STRING;

	public JACCPolicyDefinition() {
		trcLogger.entering(CLASSNAME, "JACCPolicyDefinition()");
		trcLogger.exiting(CLASSNAME, "JACCPolicyDefinition()");
	}

	public JACCPolicyDefinition(String var1, String var2, String var3, String var4, String var5)
			throws AuthSystemException {
		super(var1, var2, var3, var4, var5);
		trcLogger.entering(CLASSNAME, "JACCPolicyDefinition(...");
		trcLogger.exiting(CLASSNAME, "JACCPolicyDefinition(...)");
	}

	public void createPolicy(String var1, String var2, String var3, String var4) throws AuthSystemException {
		trcLogger.entering(CLASSNAME, "createPolicy()");

		try {
			this.createRoletoPermissionPolicy(var1, var3, 1);
			this.createPrincipalToRolePolicy(var1, var4, 1);
		} catch (Exception var6) {
			throw new AuthSystemException("AUTH_INIT_FAILURE", var6, Level.SEVERE);
		}

		trcLogger.exiting(CLASSNAME, "createPolicy()");
	}

	public void loadPolicy(String var1, String var2, String var3, String var4) throws AuthSystemException {
		trcLogger.entering(CLASSNAME, "loadPolicy()");

		try {
			this.createRoletoPermissionPolicy(var1, var3, 2);
			this.createPrincipalToRolePolicy(var1, var4, 2);
		} catch (Exception var6) {
			throw new AuthSystemException("AUTH_INIT_FAILURE", var6, Level.SEVERE);
		}

		trcLogger.exiting(CLASSNAME, "loadPolicy()");
	}

	private void createRoletoPermissionPolicy(String var1, String var2, int var3) throws Exception {
		trcLogger.entering(CLASSNAME, "createRoleToPermissionPolicy()");
		HashSet var5 = new HashSet();
		String[] var6 = new String[]{"Entity/RolePlayer/Party/LoginAccount/*"};
		PolicyConfiguration var4 = this.getPolicyConfigFactory().getPolicyConfiguration(var1, true);
		if (var3 == 1) {
			for (int var7 = 0; var7 < var6.length; ++var7) {
				var5.add(new MethodPermission(var6[var7], "SEARCH"));
				var5.add(new MethodPermission(var6[var7], "UPDATE"));
				var5.add(new MethodPermission(var6[var7], "sensitive", "WRITE"));
				var5.add(new MethodPermission(var6[var7], "unchecked", "READ"));
				var5.add(new MethodPermission(var6[var7], "unchecked", "WRITE"));
			}

			Iterator var8 = var5.iterator();

			while (var8.hasNext()) {
				var4.addToRole("Account-Owner-Role",
						new ConditionalPermission((Permission) var8.next(), OwnerCondition.OWNER_CONDITION));
			}
		} else {
			((XMLSerializable) var4).readXML(new FileInputStream(var2));
		}

		var4.commit();
		this.getPolicy().refresh();
		if (var3 == 1 && var2 != null) {
			((XMLSerializable) var4).writeXML(new FileOutputStream(var2));
			System.out.println("Successfully exported role-to-permission policy to file " + var2);
		}

		trcLogger.exiting(CLASSNAME, "createRoleToPermissionPolicy()");
	}

	private void createPrincipalToRolePolicy(String var1, String var2, int var3) throws Exception {
		trcLogger.entering(CLASSNAME, "createPrincipalToRolePolicy()");
		String var4 = this.getRoleMappingContext(var1).getContextID();
		RoleMappingConfiguration var5 = this.getRoleMappingConfigFactory().getRoleMappingConfiguration(var4, true);
		if (var3 == 1) {
			var5.setCombiningAlgorithm("most-specific-block-overrides");
			TreeBasedResource var6 = new TreeBasedResource("", "/root");
			TreeBasedResourceScope var7 = new TreeBasedResourceScope(var6, 4);
			var5.addToPrincipal(VirtualPrincipal.AllAuthenticatedUsers,
					new ScopedRoleAssignmentCondition("Account-Owner-Role", var7));
		} else {
			((XMLSerializable) var5).readXML(new FileInputStream(var2));
		}

		var5.commit();
		this.getRoleMapping().refresh();
		if (var3 == 1 && var2 != null) {
			((XMLSerializable) var5).writeXML(new FileOutputStream(var2));
			System.out.println("Successfully exported principal-to-role policy to file " + var2);
		}

		trcLogger.exiting(CLASSNAME, "createPrincipalToRolePolicy()");
	}

	public static void main(String[] var0) throws Exception {
		if (var0.length < 2) {
			System.out.println("Syntax: <output policy filename> <output rolemapping filename>\n");
			System.exit(1);
		}

		JACCPolicyDefinition var1 = new JACCPolicyDefinition("com.ibm.sec.authz.provider.CommonAuthzPolicy",
				"com.ibm.sec.authz.provider.CommonAuthzRoleMapping",
				"com.ibm.sec.authz.provider.CommonAuthzPolicyConfigurationFactory",
				"com.ibm.sec.authz.provider.CommonAuthzRoleMappingConfigurationFactory", (String) null);
		var1.createPolicy("WIM Policy", "WIM Policy", var0[0], var0[1]);
	}

	public void mapPrincipalToRole(String var1, String var2, String var3, boolean var4) throws Exception {
		String var5 = "mapPrincipalsToRole";
		trcLogger.entering(CLASSNAME, var5);
		Object var8 = null;
		String var6 = this.getRoleMappingContext("WIM Policy").getContextID();
		RoleMappingConfiguration var7 = this.getRoleMappingConfigFactory().getRoleMappingConfiguration(var6, true);
		((XMLSerializable) var7).readXML(new FileInputStream(var3));
		var7.setCombiningAlgorithm("most-specific-block-overrides");
		if (var4) {
			var8 = new UserPrincipal(var2);
		} else {
			var8 = new GroupPrincipal(var2);
		}

		if (var2.equals("AllAuthenticatedUsers")) {
			var8 = VirtualPrincipal.AllAuthenticatedUsers;
		} else {
			Iterator var9 = var7.getRoleConditions((Principal) var8);
			if (var9.hasNext()) {
				throw new WIMException("USER_OR_GROUP_ALREADY_MAPPED",
						WIMMessageHelper.generateMsgParms(var2, ((RoleCondition) var9.next()).getRole()), Level.SEVERE,
						CLASSNAME, var5);
			}
		}

		var7.addToPrincipal((Principal) var8, new NonScopedRoleAssignmentCondition(var1));
		var7.commit();
		this.getRoleMapping().refresh();
		((XMLSerializable) var7).writeXML(new FileOutputStream(var3));
		trcLogger.exiting(CLASSNAME, var5);
	}

	public void removePrincipalFromRole(String var1, String var2, String var3, boolean var4) throws Exception {
		String var5 = "removePrincipalFromRole";
		trcLogger.entering(CLASSNAME, var5);
		String var6 = this.getRoleMappingContext("WIM Policy").getContextID();
		RoleMappingConfiguration var7 = this.getRoleMappingConfigFactory().getRoleMappingConfiguration(var6, true);
		((XMLSerializable) var7).readXML(new FileInputStream(var3));
		Principal var8 = null;
		if (var2.equals(WILD_CHAR_STRING)) {
			Iterator var9 = var7.getPrincipals();

			label31 : while (true) {
				while (true) {
					if (!var9.hasNext()) {
						break label31;
					}

					var8 = (Principal) var9.next();
					if (var4) {
						if (var8 instanceof GroupPrincipal) {
							continue;
						}
					} else if (var8 instanceof UserPrincipal) {
						continue;
					}
					break;
				}

				this.removeFromRole(var7, var8, var1);
			}
		} else {
			Object var10;
			if (var4) {
				var10 = new UserPrincipal(var2);
			} else {
				var10 = new GroupPrincipal(var2);
			}

			this.removeFromRole(var7, (Principal) var10, var1);
		}

		var7.commit();
		this.getRoleMapping().refresh();
		((XMLSerializable) var7).writeXML(new FileOutputStream(var3));
		trcLogger.exiting(CLASSNAME, var5);
	}

	public Map listPrincipalsForRole(String var1, List<String> var2, boolean var3) throws Exception {
		String var4 = "listPrincipalsForRole";
		trcLogger.entering(CLASSNAME, var4);
		String var5 = this.getRoleMappingContext("WIM Policy").getContextID();
		RoleMappingConfiguration var6 = this.getRoleMappingConfigFactory().getRoleMappingConfiguration(var5, true);
		((XMLSerializable) var6).readXML(new FileInputStream(var1));
		HashMap var7 = new HashMap(3);
		Iterator var8 = var2.iterator();

		label36 : while (var8.hasNext()) {
			String var9 = (String) var8.next();
			Iterator var10 = var6.getPrincipals();
			ArrayList var11 = new ArrayList(10);

			while (true) {
				Principal var12;
				do {
					if (!var10.hasNext()) {
						continue label36;
					}

					var12 = (Principal) var10.next();
				} while ((!var3 || !(var12 instanceof UserPrincipal))
						&& (var3 || !(var12 instanceof GroupPrincipal) && !(var12 instanceof VirtualPrincipal)));

				if (this.doesPrincipalHasRole(var6, var12, var9)) {
					var11.add(var12.getName());
					var7.put(var9, var11);
				}
			}
		}

		trcLogger.exiting(CLASSNAME, var4, var7);
		return var7;
	}

	private void removeFromRole(RoleMappingConfiguration var1, Principal var2, String var3) throws Exception {
		Iterator var4 = var1.getRoleConditions(var2);

		while (var4.hasNext()) {
			RoleCondition var5 = (RoleCondition) var4.next();
			if (var5.getRole().equals(var3)) {
				var1.removeFromPrincipal(var2, var5);
			}
		}

	}

	private boolean doesPrincipalHasRole(RoleMappingConfiguration var1, Principal var2, String var3) throws Exception {
		Iterator var4 = var1.getRoleConditions(var2);

		RoleCondition var5;
		do {
			if (!var4.hasNext()) {
				return false;
			}

			var5 = (RoleCondition) var4.next();
		} while (!var5.getRole().equals(var3));

		return true;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		POLICY_SUBDIR = "config" + File.separator + "authz";
		CLASSNAME = JACCPolicyDefinition.class.getName();
		msgLogger = WIMLogger.getMessageLogger("com.ibm.ws.wim.security.authz");
		trcLogger = WIMLogger.getTraceLogger("com.ibm.ws.wim.security.authz");
		WILD_CHAR_STRING = "*";
	}
}