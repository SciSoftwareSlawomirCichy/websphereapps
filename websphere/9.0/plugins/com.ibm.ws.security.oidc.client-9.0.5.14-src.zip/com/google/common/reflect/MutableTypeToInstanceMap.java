package com.google.common.reflect;

import com.google.common.annotations.Beta;
import com.google.common.collect.ForwardingMap;
import com.google.common.collect.Maps;
import com.google.common.reflect.MutableTypeToInstanceMap.UnmodifiableEntry;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Beta
public final class MutableTypeToInstanceMap<B> extends ForwardingMap<TypeToken<? extends B>, B>
		implements
			TypeToInstanceMap<B> {
	private final Map<TypeToken<? extends B>, B> backingMap = Maps.newHashMap();

	@NullableDecl
	public <T extends B> T getInstance(Class<T> type) {
		return this.trustedGet(TypeToken.of(type));
	}

	@NullableDecl
	public <T extends B> T getInstance(TypeToken<T> type) {
		return this.trustedGet(type.rejectTypeVariables());
	}

	@NullableDecl
	@CanIgnoreReturnValue
	public <T extends B> T putInstance(Class<T> type, @NullableDecl T value) {
		return this.trustedPut(TypeToken.of(type), value);
	}

	@NullableDecl
	@CanIgnoreReturnValue
	public <T extends B> T putInstance(TypeToken<T> type, @NullableDecl T value) {
		return this.trustedPut(type.rejectTypeVariables(), value);
	}

	@Deprecated
	@CanIgnoreReturnValue
	public B put(TypeToken<? extends B> key, B value) {
		throw new UnsupportedOperationException("Please use putInstance() instead.");
	}

	@Deprecated
	public void putAll(Map<? extends TypeToken<? extends B>, ? extends B> map) {
		throw new UnsupportedOperationException("Please use putInstance() instead.");
	}

	public Set<Entry<TypeToken<? extends B>, B>> entrySet() {
		return UnmodifiableEntry.transformEntries(super.entrySet());
	}

	protected Map<TypeToken<? extends B>, B> delegate() {
		return this.backingMap;
	}

	@NullableDecl
	private <T extends B> T trustedPut(TypeToken<T> type, @NullableDecl T value) {
		return this.backingMap.put(type, value);
	}

	@NullableDecl
	private <T extends B> T trustedGet(TypeToken<T> type) {
		return this.backingMap.get(type);
	}
}