package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.DocumentRoot;
import commonj.sdo.Sequence;
import java.util.Collection;
import java.util.Map;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EMap;
import org.eclipse.emf.common.util.EMap.InternalMapView;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.EStringToStringMapEntryImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.sdo.util.BasicESequence;
import org.eclipse.emf.ecore.sdo.util.ESequence;
import org.eclipse.emf.ecore.util.BasicFeatureMap;
import org.eclipse.emf.ecore.util.EcoreEMap;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.emf.ecore.util.FeatureMap.Internal;

public class DocumentRootImpl extends EDataObjectImpl implements DocumentRoot {
	protected ESequence mixed = null;
	protected EMap xMLNSPrefixMap = null;
	protected EMap xSISchemaLocation = null;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getDocumentRoot();
	}

	public Sequence getMixed() {
		if (this.mixed == null) {
			this.mixed = new BasicESequence(new BasicFeatureMap(this, 0));
		}

		return this.mixed;
	}

	public Map getXMLNSPrefixMap() {
		if (this.xMLNSPrefixMap == null) {
			this.xMLNSPrefixMap = new EcoreEMap(EcorePackage.eINSTANCE.getEStringToStringMapEntry(),
					EStringToStringMapEntryImpl.class, this, 1);
		}

		return this.xMLNSPrefixMap.map();
	}

	public Map getXSISchemaLocation() {
		if (this.xSISchemaLocation == null) {
			this.xSISchemaLocation = new EcoreEMap(EcorePackage.eINSTANCE.getEStringToStringMapEntry(),
					EStringToStringMapEntryImpl.class, this, 2);
		}

		return this.xSISchemaLocation.map();
	}

	public ConfigurationProviderType getConfigurationProvider() {
		return (ConfigurationProviderType) ((ESequence) this.getMixed()).featureMap()
				.get(ConfigmodelPackage.eINSTANCE.getDocumentRoot_ConfigurationProvider(), true);
	}

	public NotificationChain basicSetConfigurationProvider(ConfigurationProviderType var1, NotificationChain var2) {
		return ((Internal) ((ESequence) this.getMixed()).featureMap()).basicAdd(
				ConfigmodelPackage.eINSTANCE.getDocumentRoot_ConfigurationProvider(), var1, (NotificationChain) null);
	}

	public void setConfigurationProvider(ConfigurationProviderType var1) {
		((Internal) ((ESequence) this.getMixed()).featureMap())
				.set(ConfigmodelPackage.eINSTANCE.getDocumentRoot_ConfigurationProvider(), var1);
	}

	public ConfigurationProviderType createConfigurationProvider() {
		ConfigurationProviderType var1 = ConfigmodelFactory.eINSTANCE.createConfigurationProviderType();
		this.setConfigurationProvider(var1);
		return var1;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) ((ESequence) this.getMixed()).featureMap()).basicRemove(var1, var4);
				case 1 :
					return ((InternalEList) ((InternalMapView) this.getXMLNSPrefixMap()).eMap()).basicRemove(var1,
							var4);
				case 2 :
					return ((InternalEList) ((InternalMapView) this.getXSISchemaLocation()).eMap()).basicRemove(var1,
							var4);
				case 3 :
					return this.basicSetConfigurationProvider((ConfigurationProviderType) null, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return ((ESequence) this.getMixed()).featureMap();
			case 1 :
				return ((InternalMapView) this.getXMLNSPrefixMap()).eMap();
			case 2 :
				return ((InternalMapView) this.getXSISchemaLocation()).eMap();
			case 3 :
				return this.getConfigurationProvider();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				((ESequence) this.getMixed()).featureMap().clear();
				((ESequence) this.getMixed()).featureMap().addAll((Collection) var2);
				return;
			case 1 :
				this.getXMLNSPrefixMap().clear();
				((InternalMapView) this.getXMLNSPrefixMap()).eMap().addAll((Collection) var2);
				return;
			case 2 :
				this.getXSISchemaLocation().clear();
				((InternalMapView) this.getXSISchemaLocation()).eMap().addAll((Collection) var2);
				return;
			case 3 :
				this.setConfigurationProvider((ConfigurationProviderType) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				((ESequence) this.getMixed()).featureMap().clear();
				return;
			case 1 :
				this.getXMLNSPrefixMap().clear();
				return;
			case 2 :
				this.getXSISchemaLocation().clear();
				return;
			case 3 :
				this.setConfigurationProvider((ConfigurationProviderType) null);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.mixed != null && !this.mixed.featureMap().isEmpty();
			case 1 :
				return this.xMLNSPrefixMap != null && !this.xMLNSPrefixMap.isEmpty();
			case 2 :
				return this.xSISchemaLocation != null && !this.xSISchemaLocation.isEmpty();
			case 3 :
				return this.getConfigurationProvider() != null;
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (mixed: ");
			var1.append(this.mixed);
			var1.append(')');
			return var1.toString();
		}
	}
}