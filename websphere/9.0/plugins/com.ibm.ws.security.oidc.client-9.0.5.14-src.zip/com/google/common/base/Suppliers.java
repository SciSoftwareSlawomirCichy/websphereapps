package com.google.common.base;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Suppliers.ExpiringMemoizingSupplier;
import com.google.common.base.Suppliers.MemoizingSupplier;
import com.google.common.base.Suppliers.NonSerializableMemoizingSupplier;
import com.google.common.base.Suppliers.SupplierComposition;
import com.google.common.base.Suppliers.SupplierFunction;
import com.google.common.base.Suppliers.SupplierFunctionImpl;
import com.google.common.base.Suppliers.SupplierOfInstance;
import com.google.common.base.Suppliers.ThreadSafeSupplier;
import java.io.Serializable;
import java.util.concurrent.TimeUnit;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public final class Suppliers {
	public static <F, T> Supplier<T> compose(Function<? super F, T> function, Supplier<F> supplier) {
		return new SupplierComposition(function, supplier);
	}

	public static <T> Supplier<T> memoize(Supplier<T> delegate) {
		if (!(delegate instanceof NonSerializableMemoizingSupplier) && !(delegate instanceof MemoizingSupplier)) {
			return (Supplier) (delegate instanceof Serializable
					? new MemoizingSupplier(delegate)
					: new NonSerializableMemoizingSupplier(delegate));
		} else {
			return delegate;
		}
	}

	public static <T> Supplier<T> memoizeWithExpiration(Supplier<T> delegate, long duration, TimeUnit unit) {
		return new ExpiringMemoizingSupplier(delegate, duration, unit);
	}

	public static <T> Supplier<T> ofInstance(@NullableDecl T instance) {
		return new SupplierOfInstance(instance);
	}

	public static <T> Supplier<T> synchronizedSupplier(Supplier<T> delegate) {
		return new ThreadSafeSupplier(delegate);
	}

	public static <T> Function<Supplier<T>, T> supplierFunction() {
		SupplierFunction<T> sf = SupplierFunctionImpl.INSTANCE;
		return sf;
	}
}