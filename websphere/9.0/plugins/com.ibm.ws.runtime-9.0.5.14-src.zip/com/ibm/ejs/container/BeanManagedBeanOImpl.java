package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.InconsistentAccessIntentException;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EnterpriseBean;
import javax.ejb.NoSuchEntityException;

public class BeanManagedBeanOImpl extends EntityBeanOImpl {
	private static final TraceComponent tc = Tr.register(BeanManagedBeanO.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final TraceComponent tcClntInfo = Tr.register("WAS.clientinfopluslogging",
			"WAS.clientinfopluslogging", (String) null);
	private static final String CLASS_NAME = "com.ibm.ejs.container.BeanManagedBeanOImpl";

	public BeanManagedBeanOImpl(EJSContainer c, EJSHome h) {
		super(c, h);
	}

	public EnterpriseBean getEnterpriseBean() throws RemoteException {
		if (this.state != 1 && this.state != 13) {
			throw new InvalidBeanOStateException(this.getStateName(this.state),
					this.getStateName(1) + " | " + this.getStateName(13));
		} else {
			return this.entityBean;
		}
	}

	public synchronized void postCreate(boolean supportEJBPostCreateChanges) throws CreateException, RemoteException {
		this.dirty = true;
		this.setState(1, 2);
	}

	public final void store() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "store : " + this);
		}

		if (this.dirty && !this.inCreate && !this.inStore && this.state != 8) {
			long pmiCookie = -1L;
			BeanOCallDispatchToken smfDispatchToken = null;
			int savedState = this.state;
			switch (this.state) {
				case 6 :
				case 7 :
					this.setState(10);
					this.inStore = true;

					try {
						if (this.pmiBean != null) {
							pmiCookie = this.pmiBean.storeTime();
						}

						if (isTraceOn) {
							if (tcClntInfo.isDebugEnabled()) {
								Tr.debug(tcClntInfo, "ejbStore");
							}

							if (TEBeanLifeCycleInfo.isTraceEnabled()) {
								TEBeanLifeCycleInfo.traceEJBCallEntry("ejbStore");
							}
						}

						if (isZOS) {
							smfDispatchToken = this.callDispatchEventListeners(8, (BeanOCallDispatchToken) null);
						}

						this.entityBean.ejbStore();
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallExit("ejbStore");
						}
					} catch (RemoteException var14) {
						FFDCFilter.processException(var14, "com.ibm.ejs.container.BeanManagedBeanOImpl.store", "161",
								this);
						this.destroy();
						pmiCookie = -1L;
						throw var14;
					} catch (NoSuchEntityException var15) {
						FFDCFilter.processException(var15, "com.ibm.ejs.container.BeanManagedBeanOImpl.store", "166",
								this);
						this.destroy();
						NoSuchObjectException nsoe = new NoSuchObjectException("Exception from ejbStore()");
						nsoe.detail = var15;
						throw nsoe;
					} catch (EJBException var16) {
						FFDCFilter.processException(var16, "com.ibm.ejs.container.BeanManagedBeanOImpl.store", "170",
								this);
						this.destroy();
						pmiCookie = -1L;
						throw var16;
					} catch (RuntimeException var17) {
						FFDCFilter.processException(var17, "com.ibm.ejs.container.BeanManagedBeanOImpl.store", "261",
								this);
						this.discard();
						pmiCookie = -1L;
						throw new CSIException("Exception from ejbStore()", var17);
					} finally {
						if (smfDispatchToken != null) {
							this.callDispatchEventListeners(9, smfDispatchToken);
						}

						if (pmiCookie != -1L) {
							this.pmiBean.storeTime(pmiCookie);
						}

						this.inStore = false;
					}

					if (savedState == 6) {
						this.dirty = false;
					}

					this.setState(savedState);
					break;
				default :
					throw new InvalidBeanOStateException(this.getStateName(this.state), "ACTIVE | IN_METHOD");
			}
		} else if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "Not Storing: dirty = " + this.dirty + ", inCreate = " + this.inCreate + ", inStore = "
					+ this.inStore, this);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "store : " + this);
		}

	}

	protected final void loadForEnlist(ContainerTx ctx) throws RemoteException {
		if (this.aiService != null) {
			EntityContainerTx entityContainerTx = EntityHelperImpl.toEntityContainerTx(ctx);
			this.ivAccessIntent = entityContainerTx.getCachedAccessIntent(this.beanId);
			if (this.ivAccessIntent == null) {
				try {
					this.setAccessIntent();
				} catch (InconsistentAccessIntentException var11) {
					FFDCFilter.processException(var11, "com.ibm.ejs.container.BeanManagedBeanOImpl.BeanManagedBeanO",
							"265", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "BeanManagedBeanO.loadForEnlist: " + var11);
					}

					throw new RemoteException(var11.getMessage(), var11);
				}
			}
		}

		long pmiCookie = -1L;
		int savedState = this.state;

		try {
			if (this.pmiBean != null) {
				pmiCookie = this.pmiBean.loadTime();
			}

			this.setState(3);
			if (TraceComponent.isAnyTracingEnabled()) {
				if (tcClntInfo.isDebugEnabled()) {
					Tr.debug(tcClntInfo, "ejbLoad");
				}

				if (TEBeanLifeCycleInfo.isTraceEnabled()) {
					TEBeanLifeCycleInfo.traceEJBCallEntry("ejbLoad");
				}
			}

			this.entityBean.ejbLoad();
			if (TraceComponent.isAnyTracingEnabled() && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceEJBCallExit("ejbLoad");
			}
		} catch (NoSuchEntityException var12) {
			this.destroy();
			pmiCookie = -1L;
			throw new NoSuchObjectException(var12.toString());
		} catch (EJBException var13) {
			FFDCFilter.processException(var13, "com.ibm.ejs.container.BeanManagedBeanOImpl.load", "221", this);
			this.destroy();
			pmiCookie = -1L;
			throw var13;
		} finally {
			if (this.state != 0) {
				this.setState(savedState);
			}

			if (pmiCookie != -1L) {
				this.pmiBean.loadTime(pmiCookie);
			}

		}

	}

	protected final void load(ContainerTx tx, boolean forUpdate) throws RemoteException {
		this.loadForEnlist(tx);
	}

	public final AccessIntent getAccessIntent() {
		return this.ivAccessIntent;
	}
}