package com.ibm.ejs.ras;

import java.util.Arrays;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

class WsHandler extends Handler {
	public void publish(LogRecord logRecord) {
		if (Tr.logger == null) {
			String methodName = logRecord.getSourceMethodName() != null ? logRecord.getSourceMethodName() : "";
			String message = logRecord.getMessage();
			Object[] params = logRecord.getParameters();
			if (logRecord.getThrown() != null) {
				if (params == null) {
					params = new Object[]{logRecord.getThrown()};
				} else {
					params = Arrays.copyOf(params, params.length + 1);
					params[params.length - 1] = logRecord.getThrown();
				}
			}

			String txt = params != null && params.length > 0 ? Tr.formatObj(message, params) : message;
			String sym = "3";
			String basicSym = "3  ";
			if (message != null) {
				if (!message.contains("ENTRY") && !message.contains("Entry")) {
					if (message.contains("RETURN") || message.contains("Exit")) {
						sym = "<";
						basicSym = "< ";
					}
				} else {
					sym = ">";
					basicSym = "> ";
				}
			}

			Tr.traceToFile(Tr.formatTraceRecord(logRecord.getLoggerName(), sym, basicSym, methodName, txt));
		}

	}

	public void flush() {
	}

	public void close() throws SecurityException {
	}
}