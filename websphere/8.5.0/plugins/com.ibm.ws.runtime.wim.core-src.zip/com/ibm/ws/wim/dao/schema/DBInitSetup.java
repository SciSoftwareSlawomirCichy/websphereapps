package com.ibm.ws.wim.dao.schema;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.MissingInitPropertyException;
import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.util.UniqueIdGenerator;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.LocalKeyManager;
import com.ibm.ws.wim.dao.QuerySet;
import com.ibm.ws.wim.util.PasswordEncryptionUtil;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBInitSetup {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private String defaultOrgDN = null;
	private String adminId = null;
	private String adminPwd = null;
	private String dbURL = null;
	private String dbDriver = null;
	private String dbUserId = null;
	private String dbUserPwd = null;
	private String dbSchema = null;
	private QuerySet querySet = null;
	private boolean changeDN = false;
	private boolean setAdmin = false;
	private String encryptionKey = "1234567890abcdef";
	private int saltLength = 12;

	public static void main(String[] var0) throws WIMSystemException {
		DBInitSetup var1 = new DBInitSetup(var0[0], var0[1], var0[2], var0[3], var0[4], var0[5], var0[6], var0[7],
				var0[8], var0[9], var0[10]);
		var1.setup();
	}

	public DBInitSetup(String var1, String var2, String var3, String var4, String var5, String var6, String var7,
			String var8, String var9, String var10, String var11) throws WIMSystemException {
		this.defaultOrgDN = var1;
		this.adminId = var2;
		this.adminPwd = var3;
		if (var4 != null && var4.trim().length() != 0) {
			try {
				this.encryptionKey = PasswordEncryptionUtil.decrypt(var4.trim(), (String) null).trim();
			} catch (NullPointerException var14) {
				this.encryptionKey = var4;
			}
		}

		if (var5 != null && var5.trim().length() != 0) {
			this.saltLength = new Integer(var5);
		}

		this.dbURL = var7;
		this.dbDriver = var8;
		this.dbUserId = var9;
		this.dbUserPwd = var10;
		this.dbSchema = var11;
		this.querySet = DAOHelper.getQuerySet(var6, var11);
	}

	private Class loadJDBCClass() throws WIMSystemException {
		return DAOHelper.loadJDBCClass(this.dbDriver);
	}

	private Connection getConnection() throws WIMSystemException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getConnection");
		}

		Connection var2 = null;
		Properties var3 = new Properties();
		if (this.dbUserId != null && this.dbUserPwd != null) {
			var3.put("user", this.dbUserId);
			var3.put("password", this.dbUserPwd);
		}

		try {
			Class var4 = this.loadJDBCClass();
			Object var5 = var4.newInstance();
			Method var6 = var4.getMethod("connect", String.class, Properties.class);
			var2 = (Connection) var6.invoke(var5, this.dbURL, var3);
		} catch (Exception var9) {
			try {
				if (this.dbDriver != null) {
					Class.forName(this.dbDriver);
				}

				var2 = DriverManager.getConnection(this.dbURL, var3);
			} catch (ClassNotFoundException var7) {
				throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var7.getMessage()), CLASSNAME,
						"getConnection", var7);
			} catch (SQLException var8) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var8.getMessage()),
						CLASSNAME, "getConnection", var8);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getConnection");
		}

		return var2;
	}

	public void setup() throws WIMSystemException {
		Connection var2 = null;

		try {
			if (this.defaultOrgDN != null && this.defaultOrgDN.trim().length() != 0) {
				this.changeDN = true;
				if (trcLogger.isLoggable(Level.INFO)) {
					trcLogger.logp(Level.INFO, CLASSNAME, "setup", "DefaultOrg is change to " + this.defaultOrgDN);
				}
			}

			if (this.adminId != null && this.adminId.trim().length() != 0) {
				if (this.adminPwd == null || this.adminPwd.trim().length() == 0) {
					throw new MissingInitPropertyException("MISSING_OR_EMPTY_PASSWORD", CLASSNAME, "setup");
				}

				this.setAdmin = true;
				if (trcLogger.isLoggable(Level.INFO)) {
					trcLogger.logp(Level.INFO, CLASSNAME, "setup", "new admin to create is " + this.adminId);
				}
			}

			if (!this.changeDN && !this.setAdmin) {
				if (trcLogger.isLoggable(Level.INFO)) {
					trcLogger.logp(Level.INFO, CLASSNAME, "setup", "No change to default database");
				}
			} else {
				var2 = this.getConnection();
				var2.setAutoCommit(false);
				if (this.changeDN) {
					this.changeDefaultOrg(var2);
					if (trcLogger.isLoggable(Level.INFO)) {
						trcLogger.logp(Level.INFO, CLASSNAME, "setup", "DefaultOrg is changed.");
					}
				}

				if (this.setAdmin) {
					this.setAdminData(var2);
					if (trcLogger.isLoggable(Level.INFO)) {
						trcLogger.logp(Level.INFO, CLASSNAME, "setup", "New admin is created.");
					}
				}
			}
		} catch (Exception var7) {
			try {
				var2.rollback();
			} catch (SQLException var5) {
				;
			}

			throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var7.getMessage()),
					CLASSNAME, "setup", var7);
		}

		try {
			if (var2 != null) {
				var2.commit();
				var2.close();
			}
		} catch (Exception var6) {
			;
		}

	}

	private void changeDefaultOrg(Connection var1) throws WIMSystemException {
		PreparedStatement var3 = null;

		try {
			String var4 = this.querySet.updateDefaultOrg;
			var3 = var1.prepareStatement(var4);
			var3.setString(1, this.defaultOrgDN);
			var3.setString(2, DAOHelper.getTruncatedUniqueName(this.defaultOrgDN));
			var3.executeUpdate();
		} catch (Exception var12) {
			throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var12.getMessage()),
					CLASSNAME, "changeDefaultOrg", var12);
		} finally {
			try {
				var3.close();
			} catch (Exception var11) {
				;
			}

		}

	}

	private void setAdminData(Connection var1) throws WIMSystemException {
		PreparedStatement var3 = null;
		PreparedStatement var4 = null;
		PreparedStatement var5 = null;
		PreparedStatement var6 = null;
		PreparedStatement var7 = null;
		ResultSet var8 = null;

		try {
			String var9 = this.querySet.createDBEntity;
			var3 = var1.prepareStatement(var9);
			var3.setLong(1, -1000L);
			var3.setString(2, "PersonAccount");
			var3.setString(3, UniqueIdGenerator.newUniqueId());
			String var10 = "uid=" + this.adminId + ",o=Default Organization";
			if (this.defaultOrgDN != null) {
				var10 = "uid=" + this.adminId + "," + this.defaultOrgDN;
			}

			var3.setString(4, var10);
			var3.setString(5, DAOHelper.getTruncatedUniqueName(var10));
			var3.executeUpdate();
			String var11 = this.querySet.createEntityRelation;
			var4 = var1.prepareStatement(var11);
			var4.setLong(1, -1000L);
			var4.setLong(2, -2000L);
			var4.executeUpdate();
			String var12 = this.querySet.findDBPropId;
			var5 = var1.prepareStatement(var12);
			var5.setString(1, "uid");
			var8 = var5.executeQuery();
			boolean var13 = true;
			if (!var8.next()) {
				throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED", WIMMessageHelper.generateMsgParms("uid"),
						CLASSNAME, "setAdminData");
			}

			int var30 = var8.getInt(1);
			String var14 = this.querySet.createDBStringValue;
			var6 = var1.prepareStatement(var14);
			LocalKeyManager var15 = new LocalKeyManager();
			var15.setSchema(this.dbSchema);
			var15.setQuerySet(this.querySet);
			long var16 = new Long(var15.getDBKeyForTable(var1, "DBSTRPROP"));
			var6.setLong(1, var16);
			var6.setInt(2, var30);
			var6.setString(3, "STRING");
			var6.setLong(4, -1000L);
			var6.setNull(5, -5);
			var6.setString(6, "");
			var6.setString(7, this.adminId);
			var6.setString(8, this.adminId.toLowerCase());
			var6.executeUpdate();
			String var18 = PasswordEncryptionUtil.generateSalt(this.saltLength);
			byte[] var19 = this.encrypt(this.adminPwd.getBytes("UTF-8"), var18);
			String var20 = this.querySet.createAccount;
			var7 = var1.prepareStatement(var20);
			var7.setLong(1, -1000L);
			var7.setBytes(2, var19);
			var7.setString(3, var18);
			var7.setNull(4, 12);
			var7.setNull(5, 12);
			var7.setNull(6, 12);
			var7.executeUpdate();
		} catch (Exception var28) {
			throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var28.getMessage()),
					CLASSNAME, "setAdminData", var28);
		} finally {
			try {
				var3.close();
			} catch (Exception var27) {
				;
			}

		}

	}

	private byte[] encrypt(byte[] var1, String var2) throws WIMSystemException {
		String var4 = null;
		if (var2 != null && var2.trim().length() != 0) {
			var4 = PasswordEncryptionUtil.hash(PasswordEncryptionUtil.getSaltedTextBytes(var2.trim(), var1)).trim();
		} else {
			var4 = PasswordEncryptionUtil.hash(var1).trim();
		}

		Object var5 = null;
		byte[] var6 = PasswordEncryptionUtil
				.formatPassword(PasswordEncryptionUtil.encrypt(var4, this.encryptionKey).trim().getBytes());
		return var6;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = DBInitSetup.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}