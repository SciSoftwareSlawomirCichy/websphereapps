package com.google.inject;

import com.google.inject.ConstructorInjectorStore.1;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.FailableCache;
import com.google.inject.internal.ImmutableList;
import com.google.inject.internal.Iterables;
import com.google.inject.spi.InjectionPoint;

class ConstructorInjectorStore {
	private final InjectorImpl injector;
	private final FailableCache<TypeLiteral<?>, ConstructorInjector<?>> cache = new 1(this);

	ConstructorInjectorStore(InjectorImpl injector) {
		this.injector = injector;
	}

	public <T> ConstructorInjector<T> get(TypeLiteral<T> key, Errors errors) throws ErrorsException {
		return (ConstructorInjector) this.cache.get(key, errors);
	}

	private <T> ConstructorInjector<T> createConstructor(TypeLiteral<T> type, Errors errors) throws ErrorsException {
		int numErrorsBefore = errors.size();

		InjectionPoint injectionPoint;
		try {
			injectionPoint = InjectionPoint.forConstructorOf(type);
		} catch (ConfigurationException var10) {
			errors.merge(var10.getErrorMessages());
			throw errors.toException();
		}

		SingleParameterInjector<?>[] constructorParameterInjectors = this.injector
				.getParametersInjectors(injectionPoint.getDependencies(), errors);
		MembersInjectorImpl<T> membersInjector = this.injector.membersInjectorStore.get(type, errors);
		ImmutableList<MethodAspect> injectorAspects = this.injector.state.getMethodAspects();
		ImmutableList<MethodAspect> methodAspects = membersInjector.getAddedAspects().isEmpty()
				? injectorAspects
				: ImmutableList.copyOf(Iterables.concat(injectorAspects, membersInjector.getAddedAspects()));
		ConstructionProxyFactory<T> factory = new ProxyFactory(injectionPoint, methodAspects);
		errors.throwIfNewErrors(numErrorsBefore);
		return new ConstructorInjector(membersInjector.getInjectionPoints(), factory.create(),
				constructorParameterInjectors, membersInjector);
	}
}