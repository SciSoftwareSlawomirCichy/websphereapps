package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.Cut.AboveAll;
import com.google.common.collect.Cut.AboveValue;
import com.google.common.collect.Cut.BelowAll;
import com.google.common.collect.Cut.BelowValue;
import com.google.common.primitives.Booleans;
import java.io.Serializable;
import javax.annotation.Nullable;

@GwtCompatible
abstract class Cut<C extends Comparable> implements Comparable<Cut<C>>, Serializable {
	final C endpoint;
	private static final long serialVersionUID = 0L;

	Cut(@Nullable C endpoint) {
		this.endpoint = endpoint;
	}

	abstract boolean isLessThan(C var1);

	abstract BoundType typeAsLowerBound();

	abstract BoundType typeAsUpperBound();

	abstract Cut<C> withLowerBoundType(BoundType var1, DiscreteDomain<C> var2);

	abstract Cut<C> withUpperBoundType(BoundType var1, DiscreteDomain<C> var2);

	abstract void describeAsLowerBound(StringBuilder var1);

	abstract void describeAsUpperBound(StringBuilder var1);

	abstract C leastValueAbove(DiscreteDomain<C> var1);

	abstract C greatestValueBelow(DiscreteDomain<C> var1);

	Cut<C> canonical(DiscreteDomain<C> domain) {
		return this;
	}

	public int compareTo(Cut<C> that) {
		if (that == belowAll()) {
			return 1;
		} else if (that == aboveAll()) {
			return -1;
		} else {
			int result = Range.compareOrThrow(this.endpoint, that.endpoint);
			return result != 0 ? result : Booleans.compare(this instanceof AboveValue, that instanceof AboveValue);
		}
	}

	C endpoint() {
		return this.endpoint;
	}

	public boolean equals(Object obj) {
		if (obj instanceof Cut) {
			Cut that = (Cut) obj;

			try {
				int compareResult = this.compareTo(that);
				return compareResult == 0;
			} catch (ClassCastException var4) {
				;
			}
		}

		return false;
	}

	static <C extends Comparable> Cut<C> belowAll() {
		return BelowAll.access$000();
	}

	static <C extends Comparable> Cut<C> aboveAll() {
		return AboveAll.access$100();
	}

	static <C extends Comparable> Cut<C> belowValue(C endpoint) {
		return new BelowValue(endpoint);
	}

	static <C extends Comparable> Cut<C> aboveValue(C endpoint) {
		return new AboveValue(endpoint);
	}
}