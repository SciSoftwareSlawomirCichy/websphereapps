package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.WellBehavedMap.1;
import com.google.common.collect.WellBehavedMap.EntrySet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;

@GwtCompatible
final class WellBehavedMap<K, V> extends ForwardingMap<K, V> {
	private final Map<K, V> delegate;
	@MonotonicNonNullDecl
	private Set<Entry<K, V>> entrySet;

	private WellBehavedMap(Map<K, V> delegate) {
		this.delegate = delegate;
	}

	static <K, V> WellBehavedMap<K, V> wrap(Map<K, V> delegate) {
		return new WellBehavedMap(delegate);
	}

	protected Map<K, V> delegate() {
		return this.delegate;
	}

	public Set<Entry<K, V>> entrySet() {
      Set<Entry<K, V>> es = this.entrySet;
      return es != null ? es : (this.entrySet = new EntrySet(this, (1)null));
   }
}