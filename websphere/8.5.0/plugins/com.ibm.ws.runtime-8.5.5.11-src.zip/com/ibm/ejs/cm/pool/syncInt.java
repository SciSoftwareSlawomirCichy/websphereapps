package com.ibm.ejs.cm.pool;

class syncInt {
	private int myInt = 0;

	public int getInt() {
		return this.myInt;
	}

	public void incInt() {
		++this.myInt;
	}

	public void decInt() {
		--this.myInt;
	}
}