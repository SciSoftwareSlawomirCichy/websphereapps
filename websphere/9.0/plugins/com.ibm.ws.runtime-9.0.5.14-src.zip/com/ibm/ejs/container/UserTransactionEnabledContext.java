package com.ibm.ejs.container;

import java.rmi.RemoteException;

public interface UserTransactionEnabledContext {
	int getIsolationLevel();

	boolean enlist(ContainerTx var1) throws RemoteException;

	BeanId getId();

	int getModuleVersion();
}