package com.ibm.ejs.container;

import com.ibm.ejs.container.activator.ActivationStrategy;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.J2EENameFactory;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.Handle;

public final class EJBFactoryHome implements HomeInternal {
	private static final TraceComponent tc = Tr.register(EJBFactoryHome.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private final EJSContainer ivContainer;
	private final EJBLinkResolver ivEJBLinkResolver;
	protected final J2EEName ivJ2eeName;

	EJBFactoryHome(EJSContainer container, HomeOfHomes homeOfHomes, J2EEName j2eeName,
			J2EENameFactory j2eeNameFactory) {
		this.ivContainer = container;
		this.ivJ2eeName = j2eeName;
		this.ivEJBLinkResolver = (new EJBLinkResolver()).initialize(homeOfHomes, j2eeNameFactory);
	}

	public String getJNDIName(Object homeKey) {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public J2EEName getJ2EEName() {
		return this.ivJ2eeName;
	}

	public BeanId getId() {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public EJSWrapperCommon getWrapper() throws CSIException, RemoteException {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public EJSWrapperCommon getWrapper(BeanId id) throws CSIException, RemoteException {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public BeanO createBeanO(EJBThreadData threadData, ContainerTx tx, BeanId id) throws RemoteException {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public EJSWrapperCommon internalCreateWrapper(BeanId beanId) throws CreateException, RemoteException, CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "internalCreateWrapper : " + beanId);
		}

		EJBFactoryImpl ejbFactory = new EJBFactoryImpl(this.ivEJBLinkResolver);
		J2EEName factoryKey = (J2EEName) beanId.getPrimaryKey();
		Object cluster = this.ivContainer.getEJBRuntime().getClusterIdentity(factoryKey);
		EJSWrapperCommon wrappers = new EJSWrapperCommon(ejbFactory, beanId, cluster, this.ivContainer);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "internalCreateWrapper : " + wrappers);
		}

		return wrappers;
	}

	public boolean isStatelessSessionHome() {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public boolean isStatefulSessionHome() {
		return false;
	}

	public boolean isMessageDrivenHome() {
		return false;
	}

	public BeanMetaData getBeanMetaData(Object homeKey) {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public ActivationStrategy getActivationStrategy() {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public String getMethodName(Object homeKey, int id, boolean isHome) {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public String getEnterpriseBeanClassName(Object homeKey) {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public Handle createHandle(BeanId id) throws RemoteException {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public ClassLoader getClassLoader() {
		throw new ContainerEJBException("EJBContainer internal error");
	}

	public final boolean isSingletonSessionHome() {
		return false;
	}
}