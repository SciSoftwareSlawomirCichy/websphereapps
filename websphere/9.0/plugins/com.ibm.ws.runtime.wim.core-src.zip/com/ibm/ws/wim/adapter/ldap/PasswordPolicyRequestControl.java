package com.ibm.ws.wim.adapter.ldap;

import javax.naming.ldap.Control;

public class PasswordPolicyRequestControl implements Control {
	private static final long serialVersionUID = -5214676539612663676L;
	public static final String OID = "1.3.6.1.4.1.42.2.27.8.5.1";
	private boolean critical;

	public PasswordPolicyRequestControl() {
		this(false);
	}

	public PasswordPolicyRequestControl(boolean var1) {
		this.setCritical(var1);
	}

	public String getID() {
		return "1.3.6.1.4.1.42.2.27.8.5.1";
	}

	public boolean isCritical() {
		return this.critical;
	}

	public void setCritical(boolean var1) {
		this.critical = var1;
	}

	public byte[] getEncodedValue() {
		return null;
	}
}