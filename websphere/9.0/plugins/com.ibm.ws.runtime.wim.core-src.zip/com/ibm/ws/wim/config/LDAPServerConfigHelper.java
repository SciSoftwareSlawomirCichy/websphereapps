package com.ibm.ws.wim.config;

import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.management.configservice.ConfigServiceFactory;
import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.config.ConfigUtils.GlobalKrb5Config;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.Krb5AuthenticationType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import commonj.sdo.DataObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.ObjectName;

public class LDAPServerConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = LDAPServerConfigHelper.class.getName();
	private static final Logger trcLogger;

	@Deprecated
	public String addIdMgrLDAPServer(String var1, Map var2) throws WIMException {
		return this.addIdMgrLDAPServer((Map) var2, (Session) null);
	}

	public String addIdMgrLDAPServer(Map var1, Session var2) throws WIMException {
		String var3 = "addIdMgrLDAPServer";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "params: " + WIMTraceHelper.printMapWithoutPassword(var1));
		}

		String var4 = var2.toString();
		String var5 = (String) var1.get("id");
		String var6 = (String) var1.get("host");
		Integer var7 = (Integer) var1.get("port");
		ValidationHelper.validateIntegerInput("port", CLASSNAME, var3, var7);
		LdapRepositoryType var8 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var4, var5,
				"LdapRepositoryType");
		LdapServerConfigurationType var9 = var8.getLdapServerConfiguration();
		if (var9 == null) {
			var9 = var8.createLdapServerConfiguration();
		}

		LdapServersType var10 = this.getServerBasedOnPrimaryHost(var4, var5, var6, false);
		if (var10 != null) {
			throw new WIMConfigurationException("PRIMARY_HOST_ALREADY_EXISTS", WIMMessageHelper.generateMsgParms(var6),
					Level.SEVERE, CLASSNAME, var3);
		} else {
			HashMap var11 = new HashMap();
			var11.put("ldapServerType", var8.getLdapServerType());
			var11.put("certificateMapMode", var8.getCertificateMapMode());
			var11.put("certificateFilter", var8.getCertificateFilter());
			var11.put("sslConfiguration", var9.getSslConfiguration());
			var11.putAll(var1);
			ConfigValidator.validateLDAPParams(var5, var11);
			String var12 = (String) var1.get("ldapServerType");
			if (var12 != null) {
				var8.setLdapServerType(var12);
			}

			var12 = (String) var1.get("certificateMapMode");
			if (var12 != null) {
				var8.setCertificateMapMode(var12);
			}

			var12 = (String) var1.get("certificateFilter");
			if (var12 != null) {
				var8.setCertificateFilter(var12);
			}

			var12 = (String) var1.get("sslConfiguration");
			if (var12 != null) {
				var9.setSslConfiguration(var12);
			}

			var10 = var9.createLdapServers();
			this.setServerParams(var10, var1, var2);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, var3);
			}

			return ConfigUtils.saveConfig(var4);
		}
	}

	@Deprecated
	public String updateIdMgrLDAPServer(String var1, Map var2) throws WIMException {
		return this.updateIdMgrLDAPServer((Map) var2, (Session) null);
	}

	public String updateIdMgrLDAPServer(Map var1, Session var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateIdMgrLDAPServer",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var1));
		}

		String var4 = var2.toString();
		Integer var5 = (Integer) var1.get("port");
		ValidationHelper.validateIntegerInput("port", CLASSNAME, "updateIdMgrLDAPServer", var5);
		String var6 = (String) var1.get("id");
		String var7 = (String) var1.get("host");
		LdapRepositoryType var8 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var4, var6,
				"LdapRepositoryType");
		LdapServersType var9 = this.getServerBasedOnPrimaryHost(var4, var6, var7, true);
		LdapServerConfigurationType var10 = var8.getLdapServerConfiguration();
		if (var10 == null) {
			var10 = var8.createLdapServerConfiguration();
		}

		HashMap var11 = new HashMap();
		LDAPRepositoryConfigHelper.copyLDAPConnectionData(var11, var9, var8, var2);
		if (var1.containsKey("primary_host")) {
			var1.put("host", var1.get("primary_host"));
		}

		var11.putAll(var1);
		ConfigValidator.validateLDAPParams(var6, var11);
		String var12 = (String) var1.get("ldapServerType");
		if (var12 != null) {
			var8.setLdapServerType(var12);
		}

		var12 = (String) var1.get("certificateMapMode");
		if (var12 != null) {
			var8.setCertificateMapMode(var12);
		}

		var12 = (String) var1.get("certificateFilter");
		if (var12 != null) {
			var8.setCertificateFilter(var12);
		}

		var12 = (String) var1.get("sslConfiguration");
		if (var12 != null) {
			var10.setSslConfiguration(var12);
		}

		this.setServerParams(var9, var1, var2);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrLDAPServer");
		}

		return ConfigUtils.saveConfig(var4);
	}

	@Deprecated
	void setServerParams(LdapServersType var1, Map var2) throws WIMException {
		this.setServerParams(var1, var2, (Session) null);
	}

	void setServerParams(LdapServersType var1, Map var2, Session var3) throws WIMException {
		String var4 = "setServerParams";
		String var5 = (String) var2.get("host");
		Integer var6 = (Integer) var2.get("port");
		String var7 = (String) var2.get("bindDN");
		String var8 = (String) var2.get("bindPassword");
		String var9 = (String) var2.get("authentication");
		String var10 = (String) var2.get("referal");
		String var11 = (String) var2.get("derefAliases");
		Boolean var12 = (Boolean) var2.get("sslEnabled");
		Boolean var13 = (Boolean) var2.get("connectionPool");
		Integer var14 = (Integer) var2.get("connectTimeout");
		String var15 = (String) var2.get("bindAuthMechanism");
		String var16 = (String) var2.get("krb5Principal");
		String var17 = (String) var2.get("krb5TicketCache");
		String var18 = (String) var2.get("krb5Config");
		String var19 = (String) var2.get("krb5Keytab");
		if (var5 != null || var6 != null) {
			ConnectionsType var20 = null;
			List var21 = var1.getConnections();
			if (var21 != null && var21.size() != 0) {
				var20 = (ConnectionsType) var21.get(0);
			} else {
				var20 = var1.createConnections();
			}

			if (var5 != null) {
				var20.setHost(var5);
			}

			if (var6 != null) {
				var20.setPort(var6);
			}
		}

		if (var7 != null) {
			var1.setBindDN(var7);
		}

		if (var8 != null) {
			var1.setBindPassword(ConfigUtils.encodePassword(var8));
		}

		if (var9 != null) {
			var1.setAuthentication(var9);
		}

		if (var10 != null) {
			var1.setReferal(var10);
		}

		if (var11 != null) {
			var1.setDerefAliases(var11);
		}

		if (var12 != null) {
			var1.setSslEnabled(var12);
		}

		if (var13 != null) {
			var1.setConnectionPool(var13);
		}

		if (var14 != null) {
			var1.setConnectTimeout(var14);
		}

		if (var15 != null) {
			if (var15.trim().isEmpty()) {
				var1.unsetBindAuthMechanism();
			} else {
				var1.setBindAuthMechanism(var15);
			}
		}

		Krb5AuthenticationType var40 = var1.getKrb5Authentication();
		boolean var39 = false;
		if (var40 == null) {
			var40 = var1.createKrb5Authentication();
		}

		if (var16 != null) {
			if (var16.trim().isEmpty()) {
				var40.unsetKrb5Principal();
			} else {
				var40.setKrb5Principal(var16);
			}

			var39 = true;
		}

		if (var17 != null) {
			if (var17.trim().isEmpty()) {
				var40.unsetKrb5TicketCache();
			} else {
				var40.setKrb5TicketCache(var17);
			}

			var39 = true;
		}

		if (var39) {
			if (!var40.isSetKrb5Principal() && !var40.isSetKrb5TicketCache()) {
				var1.setKrb5Authentication((Krb5AuthenticationType) null);
			} else {
				var1.setKrb5Authentication(var40);
			}
		}

		if (var18 != null || var19 != null) {
			Session var22 = null;
			boolean var23 = false;
			if (var3 == null) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.finest(var4
							+ ": Session was not provided, saving the Kerberos config could cause workarea conflict in the admin console if the command originated from there.");
				}

				var23 = true;
				var22 = new Session();
			} else {
				var22 = var3;
			}

			ConfigService var24 = null;

			try {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.finest(var4
							+ ": Checking for keytab and config file in security config, incoming values are: keytab ["
							+ var19 + "] and config [" + var18 + "]");
				}

				var24 = ConfigServiceFactory.getConfigService();
				GlobalKrb5Config var25 = ConfigUtils.getSecurityKrb5Config((String) var2.get("id"), var22, var24);
				AttributeList var26 = new AttributeList();
				ObjectName var27 = null;
				GlobalKrb5Config var28 = new GlobalKrb5Config();
				if (var25 == null) {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.finest(var4 + ": Create new KRB5 Security config");
					}

					var27 = var24.createConfigData(var22, var25.securityName, "authMechanisms", "KRB5", var26);
					var26.add(new Attribute("krb5Keytab", var19));
					var26.add(new Attribute("krb5Config", var18));
					var28.keytab = var19;
					var28.config = var18;
				} else {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.finest(var4 + ": Existing KRB5 Security config contains keytab [" + var25.keytab
								+ "] and config file [" + var25.config + "]");
					}

					if (var19 != null) {
						if (var19.trim().isEmpty()) {
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.finest(var4 + ": Keytab file is cleared");
							}

							var26.add(new Attribute("krb5Keytab", var19));
							var28.keytab = var19;
							var27 = var25.krb5AuthMechObj;
						} else if (var25.keytab == null || var25.keytab.isEmpty()
								|| !var25.keytab.equalsIgnoreCase(var19)) {
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.finest(var4 + ": Keytab file changed from " + var25.keytab + " to " + var19);
							}

							var26.add(new Attribute("krb5Keytab", var19));
							var28.keytab = var19;
							var27 = var25.krb5AuthMechObj;
						}
					}

					if (var18 != null) {
						if (var18.trim().isEmpty()) {
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.finest(var4 + ": Config file is cleared");
							}

							var26.add(new Attribute("krb5Config", var18));
							var28.config = var18;
							var27 = var25.krb5AuthMechObj;
						} else if (var25.config == null || var25.config.isEmpty()
								|| !var25.config.equalsIgnoreCase(var18)) {
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.finest(var4 + ": Config file changed from " + var25.config + " to " + var18);
							}

							var26.add(new Attribute("krb5Config", var18));
							var28.config = var18;
							var27 = var25.krb5AuthMechObj;
						}
					}
				}

				if (var27 != null) {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.finest(var4 + ": Updating the krb5 security config with these attributes: " + var26);
					}

					var24.setAttributes(var22, var25.krb5AuthMechObj, var26);
					if (var23) {
						Map var29 = var24.getConflictDocuments(var22);
						if (!var29.isEmpty()) {
							trcLogger.logp(Level.SEVERE, CLASSNAME, var4, "DOC_CONFLICT_KRB5_SAVE",
									WIMMessageHelper.generateMsgParms((String) var2.get("id"), var29));
						}

						var24.save(var22, true);
					} else {
						ConfigUtils.tempSaveSecurityKRB5Config(var22.toString(), var28);
					}
				}
			} catch (Exception var37) {
				throw new WIMConfigurationException("FAILED_SET_KRB5_SECURITY_CONFIG",
						WIMMessageHelper.generateMsgParms((String) var2.get("id"), var37), Level.SEVERE, CLASSNAME,
						var4, var37);
			} finally {
				if (var23 && var24 != null) {
					try {
						var24.discard(var22);
					} catch (Exception var36) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINER, CLASSNAME, var4, ": Exception while discarding the session",
									var36);
						}
					}
				}

			}
		}

	}

	public String deleteIdMgrLDAPServer(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPServer", "params: " + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("host");
		LdapServersType var7 = this.getServerBasedOnPrimaryHost(var1, var5, var6, true);
		((DataObject) var7).delete();
		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPServer");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List listIdMgrLDAPServers(String var1, Map var2) throws WIMException {
		String var3 = "listIdMgrLDAPServers";
		Vector var4 = new Vector();
		String var5 = (String) var2.get("id");
		LdapRepositoryType var6 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		LdapServerConfigurationType var7 = var6.getLdapServerConfiguration();
		if (var7 == null) {
			throw new WIMConfigurationException("MISSING_LDAP_SERVER_CONFIGURATION",
					WIMMessageHelper.generateMsgParms(var5), Level.SEVERE, CLASSNAME, var3);
		} else {
			List var8 = var7.getLdapServers();
			Object var9 = null;
			Iterator var10 = var8.iterator();

			while (var10.hasNext()) {
				LdapServersType var11 = (LdapServersType) var10.next();
				List var12 = var11.getConnections();
				if (var12 != null && var12.size() != 0) {
					ConnectionsType var13 = (ConnectionsType) var12.get(0);
					var4.add(var13.getHost());
				}
			}

			return var4;
		}
	}

	@Deprecated
	public Map getIdMgrLDAPServer(String var1, Map var2) throws WIMException {
		return this.getIdMgrLDAPServer((Map) var2, (Session) null);
	}

	public Map getIdMgrLDAPServer(Map var1, Session var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPServer", "params: " + var1);
		}

		String var5 = var2.toString();
		HashMap var6 = new HashMap();
		Boolean var7 = true;
		String var8 = System.getProperty("hideBindPassword");
		if (var8 != null) {
			var7 = Boolean.parseBoolean(var8);
		}

		String var9 = (String) var1.get("id");
		String var10 = (String) var1.get("host");
		LdapServersType var11 = this.getServerBasedOnPrimaryHost(var5, var9, var10, true);
		var6.put("id", var9);
		var6.put("host", var10);
		ConnectionsType var12 = (ConnectionsType) var11.getConnections().get(0);
		if (var12.isSetPort()) {
			var6.put("port", new Integer(var12.getPort()));
		}

		if (var11.getBindDN() != null) {
			var6.put("bindDN", var11.getBindDN());
		}

		if (var11.getBindPassword() != null) {
			if (var7) {
				var6.put("bindPassword", "*******");
			} else {
				var6.put("bindPassword", var11.getBindPassword());
			}
		}

		if (var11.isSetAuthentication()) {
			var6.put("authentication", var11.getAuthentication());
		}

		if (var11.isSetReferal()) {
			var6.put("referal", var11.getReferal());
		}

		if (var11.getDerefAliases() != null) {
			var6.put("derefAliases", var11.getDerefAliases());
		}

		if (var11.isSetSslEnabled()) {
			var6.put("sslEnabled", var11.isSslEnabled());
		}

		if (var11.isSetConnectionPool()) {
			var6.put("connectionPool", var11.isConnectionPool());
		}

		if (var11.isSetConnectTimeout()) {
			var6.put("connectTimeout", new Integer(var11.getConnectTimeout()));
		}

		LdapRepositoryType var13 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var5, var9,
				"LdapRepositoryType");
		if (var13.getLdapServerType() != null) {
			var6.put("ldapServerType", var13.getLdapServerType());
		}

		if (var13.getCertificateMapMode() != null) {
			var6.put("certificateMapMode", var13.getCertificateMapMode());
		}

		if (var13.getCertificateFilter() != null) {
			var6.put("certificateFilter", var13.getCertificateFilter());
		}

		LdapServerConfigurationType var14 = var13.getLdapServerConfiguration();
		if (var14 != null && var14.getSslConfiguration() != null) {
			var6.put("sslConfiguration", var14.getSslConfiguration());
		}

		if (var11.isSetBindAuthMechanism()) {
			var6.put("bindAuthMechanism", var11.getBindAuthMechanism());
		}

		Krb5AuthenticationType var15 = var11.getKrb5Authentication();
		if (var15 != null) {
			if (var15.isSetKrb5Principal()) {
				var6.put("krb5Principal", var15.getKrb5Principal());
			}

			if (var15.isSetKrb5TicketCache()) {
				var6.put("krb5TicketCache", var15.getKrb5TicketCache());
			}
		}

		GlobalKrb5Config var16 = ConfigUtils.getTempSecurityKRB5Config(var5);
		if (var16 != null) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "getIdMgrLDAPServer",
						": Using the session for unsaved config for keytab or config");
			}

			if (var16.keytab != null && !var16.keytab.isEmpty()) {
				var6.put("krb5Keytab", var16.keytab);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getIdMgrLDAPServer", ": Using keytab from unsaved config");
				}
			}

			if (var16.config != null && !var16.config.isEmpty()) {
				var6.put("krb5Config", var16.config);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getIdMgrLDAPServer", ": Using config unsaved temp config");
				}
			}
		} else {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "getIdMgrLDAPServer",
						": Using the saved config for keytab or config");
			}

			GlobalKrb5Config var17 = ConfigUtils.getSecurityKrb5Config(var9, var2, (ConfigService) null);
			if (var17 != null) {
				if (var17.keytab != null && !var17.keytab.isEmpty()) {
					var6.put("krb5Keytab", var17.keytab);
				}

				if (var17.config != null && !var17.config.isEmpty()) {
					var6.put("krb5Config", var17.config);
				}
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPServer",
					"result: " + WIMTraceHelper.printMapWithoutPassword(var6));
		}

		return var6;
	}

	@Deprecated
	public String addIdMgrLDAPBackupServer(String var1, Map var2) throws WIMException {
		return this.addIdMgrLDAPBackupServer((Map) var2, (Session) null);
	}

	public String addIdMgrLDAPBackupServer(Map var1, Session var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrLDAPBackupServer", "params: " + var1);
		}

		String var5 = var2.toString();
		String var6 = (String) var1.get("id");
		String var7 = (String) var1.get("primary_host");
		String var8 = (String) var1.get("host");
		Integer var9 = (Integer) var1.get("port");
		ValidationHelper.validateIntegerInput("port", CLASSNAME, "addIdMgrLDAPBackupServer", var9);
		LdapRepositoryType var10 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var5, var6,
				"LdapRepositoryType");
		LdapServersType var11 = this.getServerBasedOnPrimaryHost(var5, var6, var7, true);
		List var12 = var11.getConnections();

		ConnectionsType var14;
		for (int var13 = 0; var13 < var12.size(); ++var13) {
			var14 = (ConnectionsType) var12.get(var13);
			if (var14.getHost().equalsIgnoreCase(var8)) {
				boolean var15 = true;
				if (var9 != null || var14.isSetPort()) {
					if (var9 != null && var14.isSetPort()) {
						if (var9 != var14.getPort()) {
							var15 = false;
						}
					} else {
						var15 = false;
					}
				}

				if (var15) {
					throw new WIMConfigurationException("BACKUP_HOST_PORT_ALREADY_EXISTS",
							WIMMessageHelper.generateMsgParms(var8, var9), CLASSNAME, "addIdMgrLDAPBackupServer");
				}
			}
		}

		HashMap var16 = new HashMap();
		LDAPRepositoryConfigHelper.copyLDAPConnectionData(var16, var11, var10, var2);
		var16.put("host", var8);
		if (var9 != null) {
			var16.put("port", var9);
		} else {
			var16.remove("port");
		}

		ConfigValidator.validateLDAPParams(var6, var16);
		var14 = var11.createConnections();
		var14.setHost(var8);
		if (var9 != null) {
			var14.setPort(var9);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "addIdMgrLDAPBackupServer");
		}

		return ConfigUtils.saveConfig(var5);
	}

	public String removeIdMgrLDAPBackupServer(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "removeIdMgrLDAPBackupServer", "params: " + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("primary_host");
		String var7 = (String) var2.get("host");
		Integer var8 = (Integer) var2.get("port");
		ValidationHelper.validateIntegerInput("port", CLASSNAME, "removeIdMgrLDAPBackupServer", var8);
		LdapServersType var9 = this.getServerBasedOnPrimaryHost(var1, var5, var6, true);
		boolean var10 = false;
		List var11 = var9.getConnections();

		for (int var12 = 1; var12 < var11.size(); ++var12) {
			ConnectionsType var13 = (ConnectionsType) var11.get(var12);
			if ("*".equals(var7)) {
				var11.remove(var12);
				var10 = true;
				--var12;
			} else if (var13.getHost().equals(var7)) {
				if (var8 != null) {
					if (var13.isSetPort() && var8 == var13.getPort()) {
						var10 = true;
						var11.remove(var12);
						break;
					}
				} else if (!var13.isSetPort()) {
					var10 = true;
					var11.remove(var12);
					--var12;
				}
			}
		}

		if (!var10) {
			throw new WIMConfigurationException("INVALID_BACKUP_HOST_PORT",
					WIMMessageHelper.generateMsgParms(var7, var8), Level.SEVERE, CLASSNAME,
					"removeIdMgrLDAPBackupServer");
		} else {
			if (var4) {
				trcLogger.exiting(CLASSNAME, "removeIdMgrLDAPBackupServer");
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public List listIdMgrLDAPBackupServers(String var1, Map var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrLDAPBackupServers", "params: " + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("primary_host");
		LdapServersType var7 = this.getServerBasedOnPrimaryHost(var1, var5, var6, true);
		List var8 = var7.getConnections();
		if (var8 == null) {
			throw new WIMConfigurationException("INVALID_PRIMARY_HOST", WIMMessageHelper.generateMsgParms(var6),
					Level.SEVERE, CLASSNAME, "listIdMgrLDAPBackupServers");
		} else {
			ArrayList var9 = new ArrayList();

			for (int var10 = 1; var10 < var8.size(); ++var10) {
				HashMap var11 = new HashMap();
				ConnectionsType var12 = (ConnectionsType) var8.get(var10);
				if (var12.isSetPort()) {
					var11.put(var12.getHost(), new Integer(var12.getPort()));
				} else {
					var11.put(var12.getHost(), (Object) null);
				}

				var9.add(var11);
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "listIdMgrLDAPBackupServers", "result: " + var9);
			}

			return var9;
		}
	}

	private LdapServersType getServerBasedOnPrimaryHost(String var1, String var2, String var3, boolean var4)
			throws WIMException {
		String var5 = "getServerBasedOnPrimaryHost";
		LdapRepositoryType var6 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		LdapServerConfigurationType var7 = var6.getLdapServerConfiguration();
		if (var7 == null) {
			throw new WIMConfigurationException("MISSING_LDAP_SERVER_CONFIGURATION",
					WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, var5);
		} else {
			List var8 = var7.getLdapServers();
			LdapServersType var9 = null;
			Iterator var10 = var8.iterator();

			while (var10.hasNext()) {
				LdapServersType var11 = (LdapServersType) var10.next();
				List var12 = var11.getConnections();
				if (var12.size() != 0) {
					ConnectionsType var13 = (ConnectionsType) var12.get(0);
					if (var13.getHost().equals(var3)) {
						var9 = var11;
						break;
					}
				}
			}

			if (var4 && var9 == null) {
				throw new WIMConfigurationException("INVALID_PRIMARY_HOST", WIMMessageHelper.generateMsgParms(var3),
						Level.SEVERE, CLASSNAME, var5);
			} else {
				return var9;
			}
		}
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}