package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.config.Formattable;
import com.ibm.ffdc.config.IncidentStream;
import com.ibm.ffdc.config.IncidentStream.Writer;
import com.ibm.ffdc.util.formatting.DateFormatProvider;
import com.ibm.ffdc.util.formatting.IncidentReportHeader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class IncidentLogger<T extends FfdcProvider> extends FfdcProviderDependent<T> {
	public IncidentLogger(T provider) {
		super(provider);
	}

	protected String log(Incident incident, Object reporter, Throwable th, Object[] capturedDataElements)
			throws Exception {
		throw new UnsupportedOperationException();
	}

	public void writeIncidentTo(IncidentStream is, Incident incident, Object reporter, Throwable th,
			List<Formattable> data) throws IOException {
		assert data != null;

		this.writeHeader(is, incident, th, reporter);
		Iterator i$ = data.iterator();

		while (i$.hasNext()) {
			Formattable formattable = (Formattable) i$.next();
			formattable.formatTo(is);
		}

	}

	protected void writeHeader(IncidentStream is, Incident incident, Throwable th, Object reporter) throws IOException {
		Writer<OutputStream> incidentReportHeader = new IncidentReportHeader(incident, th, reporter);
		is.write(incidentReportHeader);
	}

	public void logIncidentSummary(OutputStream os, List<Incident> incidents) {
		PrintStream ps = new PrintStream(os);

		try {
			ps.println();
			ps.println(
					" Index  Count  Time of first Occurrence    Time of last Occurrence     Exception SourceId ProbeId");
			ps.println(
					"------+------+---------------------------+---------------------------+---------------------------");
			int i = -1;
			Iterator i$ = incidents.iterator();

			while (i$.hasNext()) {
				Incident incident = (Incident) i$.next();
				++i;
				ps.println(this.formatIncidentEntry(incident, i));
			}

			ps.println(
					"------+------+---------------------------+---------------------------+---------------------------");
		} finally {
			ps.flush();
		}
	}

	private String formatIncidentEntry(Incident entry, int index) {
		int count;
		long timeStamp;
		synchronized (entry) {
			timeStamp = entry.getTimeStamp();
			count = entry.getCount();
		}

		Date dateOfFirstOccurrence = entry.getDateOfFirstOccurrence();
		String exceptionName = entry.getExceptionName();
		String sourceId = entry.getSourceId();
		String probeId = entry.getProbeId();
		String label = entry.getLabel();
		DateFormat formatter = this.getDateFormatter();
		String dateString = "";
		String firstDateString = "";
		Date date = new Date(timeStamp);

		try {
			dateString = formatter.format(date);
			firstDateString = formatter.format(dateOfFirstOccurrence);
		} catch (Throwable var19) {
			this.ffdcerror(var19);
		}

		StringBuffer outputBuffer = new StringBuffer();
		String temp = String.valueOf(index);
		int length = 6 - temp.length();

		int fill;
		for (fill = 0; fill < length; ++fill) {
			outputBuffer.append(' ');
		}

		outputBuffer.append(temp);
		outputBuffer.append(' ');
		temp = String.valueOf(count);
		length = 6 - temp.length();

		for (fill = 0; fill < length; ++fill) {
			outputBuffer.append(' ');
		}

		outputBuffer.append(temp);
		outputBuffer.append(' ');
		length = 27 - firstDateString.length();

		for (fill = 0; fill < length; ++fill) {
			outputBuffer.append(' ');
		}

		outputBuffer.append(firstDateString);
		outputBuffer.append(' ');
		length = 27 - dateString.length();

		for (fill = 0; fill < length; ++fill) {
			outputBuffer.append(' ');
		}

		outputBuffer.append(dateString);
		outputBuffer.append(' ');
		outputBuffer.append(exceptionName);
		outputBuffer.append(' ');
		outputBuffer.append(sourceId);
		outputBuffer.append(' ');
		outputBuffer.append(probeId);
		if (label != null) {
			outputBuffer.append(' ');
			outputBuffer.append(label);
		}

		return outputBuffer.toString();
	}

	protected DateFormat getDateFormatter() {
		return DateFormatProvider.getDateFormat();
	}
}