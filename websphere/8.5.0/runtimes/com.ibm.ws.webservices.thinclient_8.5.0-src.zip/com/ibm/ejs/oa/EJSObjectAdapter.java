package com.ibm.ejs.oa;

import com.ibm.websphere.csi.ObjectAdapter;
import com.ibm.wsspi.cluster.Identity;
import java.rmi.Remote;
import org.omg.CORBA.Object;

public interface EJSObjectAdapter extends ObjectAdapter {
	void registerServant(Remote var1, byte[] var2, boolean var3, boolean var4) throws InvalidServantException;

	void registerServant(Object var1);

	void registerServant(Object var1, byte[] var2, boolean var3) throws InvalidServantException;

	void registerServant(Object var1, byte[] var2, Identity var3) throws InvalidServantException;

	void registerServant(Object var1, byte[] var2) throws InvalidServantException;

	void unregisterServant(Object var1);
}