package com.ibm.bsf.util.type;

import com.ibm.bsf.util.type.TypeConvertorRegistry.1;
import com.ibm.bsf.util.type.TypeConvertorRegistry.2;
import com.ibm.bsf.util.type.TypeConvertorRegistry.3;
import com.ibm.bsf.util.type.TypeConvertorRegistry.4;
import com.ibm.bsf.util.type.TypeConvertorRegistry.5;
import java.util.Hashtable;

public class TypeConvertorRegistry {
	Hashtable reg = new Hashtable();
	Hashtable keyedReg = new Hashtable();

	public TypeConvertorRegistry() {
      1 var1 = new 1(this);
      this.register(class$java$lang$Boolean == null ? (class$java$lang$Boolean = class$("java.lang.Boolean")) : class$java$lang$Boolean, Boolean.TYPE, var1);
      this.register(Boolean.TYPE, class$java$lang$Boolean == null ? (class$java$lang$Boolean = class$("java.lang.Boolean")) : class$java$lang$Boolean, var1);
      this.register(class$java$lang$Byte == null ? (class$java$lang$Byte = class$("java.lang.Byte")) : class$java$lang$Byte, Byte.TYPE, var1);
      this.register(Byte.TYPE, class$java$lang$Byte == null ? (class$java$lang$Byte = class$("java.lang.Byte")) : class$java$lang$Byte, var1);
      this.register(class$java$lang$Character == null ? (class$java$lang$Character = class$("java.lang.Character")) : class$java$lang$Character, Character.TYPE, var1);
      this.register(Character.TYPE, class$java$lang$Character == null ? (class$java$lang$Character = class$("java.lang.Character")) : class$java$lang$Character, var1);
      this.register(class$java$lang$Short == null ? (class$java$lang$Short = class$("java.lang.Short")) : class$java$lang$Short, Short.TYPE, var1);
      this.register(Short.TYPE, class$java$lang$Short == null ? (class$java$lang$Short = class$("java.lang.Short")) : class$java$lang$Short, var1);
      this.register(class$java$lang$Integer == null ? (class$java$lang$Integer = class$("java.lang.Integer")) : class$java$lang$Integer, Integer.TYPE, var1);
      this.register(Integer.TYPE, class$java$lang$Integer == null ? (class$java$lang$Integer = class$("java.lang.Integer")) : class$java$lang$Integer, var1);
      this.register(class$java$lang$Long == null ? (class$java$lang$Long = class$("java.lang.Long")) : class$java$lang$Long, Long.TYPE, var1);
      this.register(Long.TYPE, class$java$lang$Long == null ? (class$java$lang$Long = class$("java.lang.Long")) : class$java$lang$Long, var1);
      this.register(class$java$lang$Float == null ? (class$java$lang$Float = class$("java.lang.Float")) : class$java$lang$Float, Float.TYPE, var1);
      this.register(Float.TYPE, class$java$lang$Float == null ? (class$java$lang$Float = class$("java.lang.Float")) : class$java$lang$Float, var1);
      this.register(class$java$lang$Double == null ? (class$java$lang$Double = class$("java.lang.Double")) : class$java$lang$Double, Double.TYPE, var1);
      this.register(Double.TYPE, class$java$lang$Double == null ? (class$java$lang$Double = class$("java.lang.Double")) : class$java$lang$Double, var1);
      2 var2 = new 2(this);
      this.register(class$java$lang$Object == null ? (class$java$lang$Object = class$("java.lang.Object")) : class$java$lang$Object, class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, var2);
      3 var3 = new 3(this);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, Boolean.TYPE, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$lang$Boolean == null ? (class$java$lang$Boolean = class$("java.lang.Boolean")) : class$java$lang$Boolean, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, Byte.TYPE, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$lang$Byte == null ? (class$java$lang$Byte = class$("java.lang.Byte")) : class$java$lang$Byte, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, Character.TYPE, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$lang$Character == null ? (class$java$lang$Character = class$("java.lang.Character")) : class$java$lang$Character, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, Short.TYPE, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$lang$Short == null ? (class$java$lang$Short = class$("java.lang.Short")) : class$java$lang$Short, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, Integer.TYPE, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$lang$Integer == null ? (class$java$lang$Integer = class$("java.lang.Integer")) : class$java$lang$Integer, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, Long.TYPE, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$lang$Long == null ? (class$java$lang$Long = class$("java.lang.Long")) : class$java$lang$Long, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, Float.TYPE, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$lang$Float == null ? (class$java$lang$Float = class$("java.lang.Float")) : class$java$lang$Float, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, Double.TYPE, var3);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$lang$Double == null ? (class$java$lang$Double = class$("java.lang.Double")) : class$java$lang$Double, var3);
      4 var4 = new 4(this);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$awt$Font == null ? (class$java$awt$Font = class$("java.awt.Font")) : class$java$awt$Font, var4);
      5 var5 = new 5(this);
      this.register(class$java$lang$String == null ? (class$java$lang$String = class$("java.lang.String")) : class$java$lang$String, class$java$awt$Color == null ? (class$java$awt$Color = class$("java.awt.Color")) : class$java$awt$Color, var5);
   }

	public TypeConvertor lookup(Class var1, Class var2) {
		String var3 = var1.getName() + " -> " + var2.getName();
		TypeConvertor var4 = (TypeConvertor) this.reg.get(var3);
		if (var4 == null) {
			if (class$java$lang$Object == null) {
				class$java$lang$Object = class$("java.lang.Object");
			} else {
				Class var10000 = class$java$lang$Object;
			}

			if (var1 != Void.TYPE
					&& var1 != (class$java$lang$Void == null
							? (class$java$lang$Void = class$("java.lang.Void"))
							: class$java$lang$Void)
					&& var2 == (class$java$lang$String == null
							? (class$java$lang$String = class$("java.lang.String"))
							: class$java$lang$String)) {
				return this.lookup(
						class$java$lang$Object == null
								? (class$java$lang$Object = class$("java.lang.Object"))
								: class$java$lang$Object,
						class$java$lang$String == null
								? (class$java$lang$String = class$("java.lang.String"))
								: class$java$lang$String);
			}
		}

		return var4;
	}

	public TypeConvertor lookupByKey(Object var1) {
		return (TypeConvertor) this.keyedReg.get(var1);
	}

	public void register(Class var1, Class var2, TypeConvertor var3) {
		String var4 = var1.getName() + " -> " + var2.getName();
		this.reg.put(var4, var3);
	}

	public void registerByKey(Object var1, TypeConvertor var2) {
		this.keyedReg.put(var1, var2);
	}
}