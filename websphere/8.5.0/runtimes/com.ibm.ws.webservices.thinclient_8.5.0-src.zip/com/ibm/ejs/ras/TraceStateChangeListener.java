package com.ibm.ejs.ras;

public interface TraceStateChangeListener {
	void traceStateChanged();
}