package com.ibm.ws.wim.config;

public class SystemConfigHelper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
}