package com.ibm.ws.ffdc.impl;

import java.io.ByteArrayOutputStream;

public class FixedCapacityStream extends ByteArrayOutputStream {
	private int capacity;
	public boolean isTruncated;

	public FixedCapacityStream() {
		this(0);
	}

	public FixedCapacityStream(int capacity) {
		this.isTruncated = false;
		this.capacity = capacity;
	}

	public synchronized void write(int b) {
		int newcount = this.count + 1;
		if (this.checkCapacity(newcount)) {
			super.write(b);
		}
	}

	public synchronized void write(byte[] b, int off, int len) {
		int newcount = this.count + len;
		if (this.checkCapacity(newcount)) {
			super.write(b, off, len);
		}
	}

	public synchronized void reset(int capacity) {
		super.reset();
		this.capacity = capacity;
	}

	private boolean checkCapacity(int newcount) {
		if (newcount > this.capacity) {
			this.isTruncated = true;
			return false;
		} else {
			return true;
		}
	}

	public byte[] getBytes() {
		byte[] bytes = new byte[this.count];
		System.arraycopy(this.buf, 0, bytes, 0, this.count);
		return bytes;
	}
}