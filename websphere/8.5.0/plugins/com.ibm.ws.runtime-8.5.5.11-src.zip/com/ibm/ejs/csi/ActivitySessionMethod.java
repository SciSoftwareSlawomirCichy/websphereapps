package com.ibm.ejs.csi;

import com.ibm.websphere.csi.ActivitySessionAttribute;
import java.util.List;

public class ActivitySessionMethod {
	private ActivitySessionAttribute asAttr;
	private List methodElements;

	public ActivitySessionMethod(ActivitySessionAttribute asAttr, List methodElements) {
		this.asAttr = asAttr;
		this.methodElements = methodElements;
	}

	public ActivitySessionAttribute getActivitySessionAttribute() {
		return this.asAttr;
	}

	public List getMethodElements() {
		return this.methodElements;
	}
}