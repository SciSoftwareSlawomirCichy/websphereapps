package com.ibm.ws.wim.xpath.mapping.datatype;

import java.util.HashMap;
import java.util.Iterator;

public interface XPathNode {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	short NODE_PROPERTY = 0;
	short NODE_LOGICAL = 1;
	short NODE_PARENTHESIS = 2;
	short NODE_FED_LOGICAL = 4;
	short NODE_FED_PARENTHESIS = 8;

	Iterator getPropertyNodes(HashMap var1);

	short getNodeType();
}