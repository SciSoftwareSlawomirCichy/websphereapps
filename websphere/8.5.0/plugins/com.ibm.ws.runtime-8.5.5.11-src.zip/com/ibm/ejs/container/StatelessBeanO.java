package com.ibm.ejs.container;

import com.ibm.ejs.container.interceptors.InterceptorMetaData;
import com.ibm.ejs.container.interceptors.InterceptorProxy;
import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.CallbackKind;
import com.ibm.ws.ejbcontainer.util.Pool;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import com.ibm.wsspi.injectionengine.InjectionEngine;
import com.ibm.wsspi.injectionengine.InjectionTarget;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.security.Principal;
import javax.ejb.CreateException;
import javax.ejb.EnterpriseBean;
import javax.ejb.RemoveException;
import javax.ejb.TimerService;

public class StatelessBeanO extends SessionBeanO {
	private static final String CLASS_NAME = StatelessBeanO.class.getName();
	private static final TraceComponent tc;
	protected boolean reentrant = false;
	protected boolean allowRollbackOnly = false;
	protected boolean discarded = false;
	protected transient boolean ivNumberOfBeansLimited;
	public static final int POOLED = 3;
	public static final int IN_METHOD = 4;
	protected static final String[] StateStrs;

	StatelessBeanO() {
		super((EJSContainer) null, (ManagedObject) null, (Object) null, (EJSHome) null);
	}

	public StatelessBeanO(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		super(c, mo, b, h);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "CTOR SLSB: " + this);
		}

	}

	protected void initialize() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "initialize");
		}

		this.stateStrs = StateStrs;
		this.state = 1;
		this.allowRollbackOnly = false;
		this.ivNumberOfBeansLimited = false;
		UnspecifiedContextHelper contextHelper = null;

		try {
			BeanMetaData bmd = null;
			InterceptorMetaData imd = null;
			if (this.home != null) {
				bmd = this.home.beanMetaData;
				contextHelper = new UnspecifiedContextHelper(this);
				contextHelper.begin(true);
				this.setId(this.home.ivStatelessId);
				if (this.home.beanMetaData.ivMaxCreation > 0) {
					this.ivNumberOfBeansLimited = true;
				}

				imd = bmd.ivInterceptorMetaData;
				if (imd != null) {
					this.createInterceptors(imd);
				}
			}

			if (this.sessionBean != null) {
				this.sessionBean.setSessionContext(this);
			}

			if (bmd != null && bmd.ivBeanInjectionTargets != null) {
				try {
					InjectionEngine injectionEngine = this.getInjectionEngine();
					InjectionTarget[] targets = bmd.ivBeanInjectionTargets;
					if (targets != null) {
						InjectionTarget[] arr$ = targets;
						int len$ = targets.length;

						for (int i$ = 0; i$ < len$; ++i$) {
							InjectionTarget injectionTarget = arr$[i$];
							injectionEngine.inject(this.ivEjbInstance, injectionTarget, this);
						}
					}
				} catch (Throwable var26) {
					FFDCFilter.processException(var26, CLASS_NAME + ".<init>", "282", this);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Injection failure", var26);
					}

					throw ExceptionUtil.EJBException("Injection failure", var26);
				}
			}

			this.setState(2);
			if (this.ivCallbackKind == CallbackKind.SessionBean) {
				Method m = bmd.ivEjbCreateMethod;
				if (m != null) {
					try {
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallEntry("ejbCreate");
						}

						m.invoke(this.ivEjbInstance);
					} catch (InvocationTargetException var23) {
						FFDCFilter.processException(var23, CLASS_NAME + ".StatelessBeanO", "110", this);
						Throwable targetEx = var23.getCause();
						if (targetEx == null) {
							targetEx = var23;
						}

						throw new CreateFailureException((Throwable) targetEx);
					} catch (Throwable var24) {
						FFDCFilter.processException(var24, CLASS_NAME + ".StatelessBeanO", "401", this);
						throw new CreateFailureException(var24);
					} finally {
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallExit("ejbCreate");
						}

					}
				}
			} else if (this.ivCallbackKind == CallbackKind.InvocationContext && imd != null) {
				InterceptorProxy[] proxies = imd.ivPostConstructInterceptors;
				if (proxies != null) {
					this.callLifecycleInterceptors(proxies, 0);
				}
			}

			this.allowRollbackOnly = true;
			this.setState(3);
		} finally {
			if (contextHelper != null) {
				contextHelper.complete(true);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "initialize : " + this);
			}

		}

	}

	public boolean isRemoved() {
		return false;
	}

	public boolean isDiscarded() {
		return this.discarded;
	}

	public final synchronized void destroy() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy");
		}

		if (this.state != 0) {
			long removeStartTime = -1L;
			if (this.pmiBean != null) {
				removeStartTime = this.pmiBean.initalTime(15);
			}

			this.allowRollbackOnly = false;
			String lifeCycle = null;
			UnspecifiedContextHelper contextHelper = new UnspecifiedContextHelper(this);
			BeanMetaData bmd = this.home.beanMetaData;
			ComponentMetaDataAccessorImpl cmdAccessor = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor();

			try {
				cmdAccessor.beginContext(bmd);
				contextHelper.begin(this.ivCallbackKind != CallbackKind.None);
				if (this.ivCallbackKind == CallbackKind.SessionBean) {
					if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
						lifeCycle = "ejbRemove";
						TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
					}

					this.sessionBean.ejbRemove();
				} else if (this.ivCallbackKind == CallbackKind.InvocationContext) {
					if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
						lifeCycle = "preDestroy";
						TEBeanLifeCycleInfo.traceEJBCallEntry(lifeCycle);
					}

					InterceptorMetaData imd = this.home.beanMetaData.ivInterceptorMetaData;
					InterceptorProxy[] proxies = imd.ivPreDestroyInterceptors;
					if (proxies != null) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "invoking PreDestroy interceptors");
						}

						InvocationContextImpl inv = new InvocationContextImpl();
						inv.initialize(this.ivEjbInstance, this.ivInterceptors);
						inv.doLifeCycle(proxies, bmd._moduleMetaData);
					}
				}
			} catch (Exception var22) {
				FFDCFilter.processException(var22, CLASS_NAME + ".destroy", "164", this);
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "destroy caught exception: ", new Object[]{this, var22});
				}
			} finally {
				if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled() && lifeCycle != null) {
					TEBeanLifeCycleInfo.traceEJBCallExit(lifeCycle);
				}

				cmdAccessor.endContext();

				try {
					contextHelper.complete(true);
				} catch (Throwable var21) {
					FFDCFilter.processException(var21, CLASS_NAME + ".destroy", "505", this);
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "destroy caught exception: ", new Object[]{this, var21});
					}
				}

			}

			this.setState(0);
			this.destroyHandleList();
			this.releaseManagedObjectState();
			if (this.pmiBean != null) {
				this.pmiBean.beanRemoved();
				this.pmiBean.beanDestroyed();
				this.pmiBean.finalTime(15, removeStartTime);
			}

			if (this.ivNumberOfBeansLimited) {
				Pool var24 = this.beanPool;
				synchronized (this.beanPool) {
					--this.home.ivNumberBeansCreated;
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "destroy: BeanPool(" + this.home.ivNumberBeansCreated + "/"
								+ this.home.beanMetaData.ivMaxCreation + ")");
					}

					this.beanPool.notify();
				}
			}

			this.allowRollbackOnly = true;
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "destroy");
			}

		}
	}

	public final EnterpriseBean getEnterpriseBean() throws RemoteException {
		throw new NotImplementedException();
	}

	public Class<?> getInvokedBusinessInterface() throws IllegalStateException {
		boolean validState = false;
		int stateCopy;
		synchronized (this) {
			stateCopy = this.state;
			validState = this.state == 3 || this.state == 4;
		}

		if (validState) {
			return super.getInvokedBusinessInterface();
		} else {
			String stateString = this.stateStrs[stateCopy];
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Incorrect state: " + stateString);
			}

			throw new IllegalStateException(stateString);
		}
	}

	public final void postCreate(boolean supportEJBPostCreateChanges) throws CreateException, RemoteException {
		throw new NotImplementedException();
	}

	public final void activate(BeanId id, ContainerTx tx) throws RemoteException {
	}

	public final boolean enlist(ContainerTx tx) throws RemoteException {
		if (!this.reentrant) {
			this.ivContainerTx = tx;
		}

		return false;
	}

	public final Object preInvoke(EJSDeployedSupport s, ContainerTx tx) throws RemoteException {
		if (!this.reentrant) {
			this.setState(3, 4);
		}

		int tmp = this.currentIsolationLevel;
		this.currentIsolationLevel = s.currentIsolationLevel;
		s.currentIsolationLevel = tmp;
		return this.ivEjbInstance;
	}

	public void postInvoke(int id, EJSDeployedSupport s) throws RemoteException {
		this.ivContainerTx = null;
	}

	public void returnToPool() throws RemoteException {
		if (this.isDestroyed()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "returnToPool: skipped: " + this);
			}
		} else {
			this.setState(4, 3);
			if (this.ivNumberOfBeansLimited) {
				Pool var1 = this.beanPool;
				synchronized (this.beanPool) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "returnToPool: " + this + ": " + this.home.ivNumberBeansCreated + "/"
								+ this.home.beanMetaData.ivMaxCreation);
					}

					this.beanPool.put(this);
					this.beanPool.notify();
				}
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "returnToPool: " + this);
				}

				this.beanPool.put(this);
			}
		}

	}

	public final void commit(ContainerTx tx) throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Stateless commit not allowed");
	}

	public final void rollback(ContainerTx tx) throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Stateless rollback not allowed");
	}

	public final void store() throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Stateless store not allowed");
	}

	public final void passivate() throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Stateless passivate not allowed");
	}

	public final void remove() throws RemoteException, RemoveException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "remove");
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "remove");
		}

	}

	public void discard() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "discard : " + this);
		}

		if (this.home == null) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "discard : Home beans are never discarded");
			}

		} else {
			this.discarded = true;
			if (this.state == 0) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "discard : Bean already destroyed");
				}

			} else {
				this.setState(0);
				this.destroyHandleList();
				this.releaseManagedObjectState();
				if (this.pmiBean != null) {
					this.pmiBean.discardCount();
					this.pmiBean.beanDestroyed();
				}

				if (this.ivNumberOfBeansLimited) {
					Pool var2 = this.beanPool;
					synchronized (this.beanPool) {
						--this.home.ivNumberBeansCreated;
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "discard: BeanPool(" + this.home.ivNumberBeansCreated + "/"
									+ this.home.beanMetaData.ivMaxCreation + ")");
						}

						this.beanPool.notify();
					}
				}

				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "discard");
				}

			}
		}
	}

	public final void beforeCompletion() throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Stateless beforeCompletion not allowed");
	}

	public void checkTimerServiceAccess() throws IllegalStateException {
		if (this.state != 4) {
			IllegalStateException ise = new IllegalStateException(
					"StatelessBean: Timer Service methods not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerServiceAccess: " + ise);
			}

			throw ise;
		}
	}

	public void setRollbackOnly() {
		synchronized (this) {
			if (!this.allowRollbackOnly) {
				throw new IllegalStateException();
			}
		}

		super.setRollbackOnly();
	}

	public boolean getRollbackOnly() {
		synchronized (this) {
			if (!this.allowRollbackOnly) {
				throw new IllegalStateException();
			}
		}

		return super.getRollbackOnly();
	}

	public Principal getCallerPrincipal() {
		synchronized (this) {
			if (this.state == 1 || this.state == 2 || !this.allowRollbackOnly) {
				throw new IllegalStateException();
			}
		}

		return super.getCallerPrincipal();
	}

	public boolean isCallerInRole(String roleName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCallerInRole, role = " + roleName + ", state = " + StateStrs[this.state]);
		}

		Object bean = null;
		synchronized (this) {
			if (this.state == 1 || this.state == 2 || !this.allowRollbackOnly) {
				throw new IllegalStateException();
			}

			if (this.state == 4) {
				bean = this.ivEjbInstance;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isCallerInRole");
		}

		return super.isCallerInRole(roleName, bean);
	}

	public TimerService getTimerService() throws IllegalStateException {
		if (this.state == 1) {
			IllegalStateException ise = new IllegalStateException(
					"StatelessBean: getTimerService not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getTimerService: " + ise);
			}

			throw ise;
		} else {
			return super.getTimerService();
		}
	}

	public void flushCache() {
		if (this.state != 1 && this.state != 2) {
			super.flushCache();
		} else {
			IllegalStateException ise = new IllegalStateException(
					"StatelessBean: flushCache not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "flushCache: " + ise);
			}

			throw ise;
		}
	}

	public final String toString() {
		return "StatelessBeanO(" + this.beanId + ", state = " + StateStrs[this.state] + ")";
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		StateStrs = new String[]{"DESTROYED", "PRE_CREATE", "CREATING", "POOLED", "IN_METHOD"};
	}
}