package com.ibm.ws.wim.adapter.db;

public class DBProperty {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private int propId;
	private String metadataName = "DEFAULT";
	private String typeId;
	private int isComposite = 0;
	private int valueLength;
	private int readOnly = 0;
	private int multiValued = 1;
	private String className;
	private String name;
	private int caseExactMatch = 1;
	private String description;
	private String applicationId = "com.ibm.websphere.wim";

	public int getCaseExactMatch() {
		return this.caseExactMatch;
	}

	public String getClassName() {
		return this.className;
	}

	public int getIsComposite() {
		return this.isComposite;
	}

	public int getMultiValued() {
		return this.multiValued;
	}

	public String getName() {
		return this.name;
	}

	public int getReadOnly() {
		return this.readOnly;
	}

	public int getValueLength() {
		return this.valueLength;
	}

	public void setClassName(String var1) {
		this.className = var1;
	}

	public void setIsComposite(int var1) {
		this.isComposite = var1;
	}

	public void setMultiValued(int var1) {
		this.multiValued = var1;
	}

	public void setName(String var1) {
		this.name = var1;
	}

	public void setReadOnly(int var1) {
		this.readOnly = var1;
	}

	public void setValueLength(int var1) {
		this.valueLength = var1;
	}

	public String getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(String var1) {
		this.applicationId = var1;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String var1) {
		this.description = var1;
	}

	public String getTypeId() {
		return this.typeId;
	}

	public void setTypeId(String var1) {
		this.typeId = var1;
	}

	public int getPropId() {
		return this.propId;
	}

	public void setPropId(int var1) {
		this.propId = var1;
	}

	public String getMetadataName() {
		return this.metadataName;
	}

	public void setMetadataName(String var1) {
		this.metadataName = var1;
	}

	public void setCaseExactMatch(int var1) {
		this.caseExactMatch = var1;
	}
}