@ParametersAreNonnullByDefault
@CheckReturnValue
package com.google.common.math;

import com.google.errorprone.annotations.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;