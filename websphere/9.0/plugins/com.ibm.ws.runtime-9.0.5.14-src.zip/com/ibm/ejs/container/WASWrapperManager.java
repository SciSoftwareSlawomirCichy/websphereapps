package com.ibm.ejs.container;

import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBServantManager;
import com.ibm.ws.ejbcontainer.EJBOAKeyImpl;

public class WASWrapperManager extends WrapperManager implements EJBServantManager {
	public WASWrapperManager(EJSContainer container) {
		super(container);
	}

	public byte[] getJ2EENameBytes(byte[] servantKey) throws CSIException {
		EJBOAKeyImpl key = new EJBOAKeyImpl(servantKey);
		return key.getJ2EENameBytes();
	}
}