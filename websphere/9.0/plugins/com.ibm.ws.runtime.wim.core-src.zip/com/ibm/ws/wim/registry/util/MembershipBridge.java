package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.EntryNotFoundException;
import com.ibm.websphere.security.NotImplementedException;
import com.ibm.websphere.security.Result;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InvalidIdentifierException;
import com.ibm.websphere.wim.exception.InvalidUniqueNameException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.RealmManager;
import com.ibm.ws.wim.registry.dataobject.IDAndRealm;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MembershipBridge {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private final String className = MembershipBridge.class.getName();
	private Logger membershipBridgeTrace;
	private TypeMappings propertyMap;
	private BridgeUtils mappingUtils;

	public MembershipBridge() {
		this.membershipBridgeTrace = WIMLogger.getTraceLogger(this.className);
		this.propertyMap = new TypeMappings();
		this.mappingUtils = BridgeUtils.singleton();
		String var1 = "MembershipBridge";
		if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
			this.membershipBridgeTrace.entering(this.className, var1);
		}

		if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
			this.membershipBridgeTrace.exiting(this.className, var1);
		}

	}

	public List getGroupsForUser(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = "getGroupsForUser";
		if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
			this.membershipBridgeTrace.entering(this.className, var2, "inputUserSecurityName = \"" + var1 + "\"");
		}

		ArrayList var3 = new ArrayList();

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
			}

			String var6 = "'";
			String var7 = var4.getId();
			if (var7.indexOf("'") != -1) {
				var6 = "\"";
			}

			String var8 = this.propertyMap.getInputUserSecurityName(var4.getRealm());
			var8 = this.mappingUtils.getRealInputAttrName(var8, var7, true);
			String var9 = this.propertyMap.getOutputGroupSecurityName(var4.getRealm());
			BridgeUtils var10000 = this.mappingUtils;
			boolean var10 = BridgeUtils.allowDNAsPrincipalName;
			DataObject var11;
			if (var10) {
				var11 = var5.createDataObject("contexts");
				var11.set("key", "allowDNPrincipalNameAsLiteral");
				var11.set("value", var10);
			}

			var11 = null;

			try {
				var11 = this.mappingUtils.getEntityByIdentifier(var5, var8, var7, var9, this.mappingUtils);
			} catch (WIMException var22) {
				if (!var10) {
					throw var22;
				}
			}

			if (var11 != null) {
				var5 = var11;
			} else {
				if (var10) {
					var8 = "principalName";
				}

				DataObject var12 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"SearchControl");
				var12.setString("expression",
						"//entities[@xsi:type='LoginAccount' and " + var8 + "=" + var6 + var7 + var6 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
			}

			List var24 = var5.getList("entities");
			if (var24.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var2);
			}

			if (var24.size() != 1) {
				boolean var25 = false;
				int var27 = var24.size();
				StringBuilder var28 = new StringBuilder();
				HashSet var29 = new HashSet();

				for (int var26 = 0; var26 < var27; ++var26) {
					DataObject var30 = (DataObject) var24.get(var26);
					if (var30.get("identifier") != null) {
						DataObject var31 = (DataObject) var30.get("identifier");
						if (var31.get("repositoryId") != null) {
							String var32 = String.valueOf(var31.get("repositoryId"));
							if (!var29.contains(var32)) {
								var29.add(var32);
							}
						}
					}
				}

				if (var29.size() == 0) {
					var28.append("repositories");
				} else {
					var28.append(var29);
				}

				throw new EntityNotFoundException("MULTIPLE_PRINCIPALS_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var28), this.className, var2);
			}

			DataObject var13 = (DataObject) var24.get(0);
			var4.setId(var13.getString("identifier/uniqueName"));
			var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
			}

			var13 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim", "GroupMembershipControl");
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputGroupSecurityName(var4.getRealm()))) {
				var13.getList("properties").add(this.propertyMap.getOutputGroupSecurityName(var4.getRealm()));
			}

			var13.setString("level", Short.toString(this.mappingUtils.getGroupDepth()));
			var13.setString("expression", "@xsi:type='Group'");
			DataObject var14 = var5.createDataObject("entities", "http://www.ibm.com/websphere/wim", "LoginAccount");
			var14.createDataObject("identifier").setString("uniqueName", var4.getId());
			var5 = this.mappingUtils.getWimService().get(var5);
			List var15 = var5.getList("entities");
			if (var15.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var2);
			}

			DataObject var16 = (DataObject) var15.get(0);
			List var17 = var16.getList("groups");
			if (!var17.isEmpty()) {
				String var18 = this.propertyMap.getOutputGroupSecurityName(var4.getRealm());
				boolean var19 = this.mappingUtils.isIdentifierTypeProperty(var18);
				if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
					this.membershipBridgeTrace.logp(Level.FINER, this.className, var2,
							"grpAttrName=" + var18 + ", isIdentifier=" + var19);
				}

				for (int var20 = 0; var20 < var17.size(); ++var20) {
					DataObject var21 = (DataObject) var17.get(var20);
					if (!var19) {
						var3.add(var21.getString(var18));
					} else {
						var3.add(var21.getString("identifier/" + var18));
					}
				}
			}
		} catch (WIMException var23) {
			this.mappingUtils.logException(var23, this.className);
			if (!(var23 instanceof EntityNotFoundException) && !(var23 instanceof InvalidIdentifierException)) {
				throw new CustomRegistryException(var23);
			}

			throw new EntryNotFoundException(var23);
		}

		if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
			this.membershipBridgeTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public Result getUsersForGroup(String var1, int var2)
			throws NotImplementedException, EntryNotFoundException, CustomRegistryException, RemoteException {
		String var3 = "getUsersForGroup";
		if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
			this.membershipBridgeTrace.entering(this.className, var3,
					"inputGroupSecurityName = \"" + var1 + "\", inputLimit = \"" + Integer.toString(var2) + "\"");
		}

		Result var4 = new Result();

		try {
			this.mappingUtils.validateId(var1);
			this.mappingUtils.validateLimit(var2);
			IDAndRealm var5 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var6 = this.mappingUtils.getWimService().createRootDataObject();
			if (var5.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var6, var5.getRealm());
			}

			String var7 = "'";
			String var8 = var5.getId();
			if (var8.indexOf("'") != -1) {
				var7 = "\"";
			}

			String var9 = this.propertyMap.getInputGroupSecurityName(var5.getRealm());
			var9 = this.mappingUtils.getRealInputAttrName(var9, var8, false);
			String var10 = "uniqueName";
			DataObject var11 = this.mappingUtils.getEntityByIdentifier(var6, var9, var8, var10, this.mappingUtils);
			if (var11 != null) {
				var6 = var11;
			} else {
				DataObject var12 = var6.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"SearchControl");
				var12.setString("expression",
						"//entities[@xsi:type='Group' and " + var9 + "=" + var7 + var8 + var7 + "]");
				var6 = this.mappingUtils.getWimService().search(var6);
			}

			List var24 = var6.getList("entities");
			if (var24.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var3);
			}

			if (var24.size() != 1) {
				boolean var25 = false;
				int var27 = var24.size();
				StringBuilder var28 = new StringBuilder();
				HashSet var29 = new HashSet();

				for (int var26 = 0; var26 < var27; ++var26) {
					DataObject var30 = (DataObject) var24.get(var26);
					if (var30.get("identifier") != null) {
						DataObject var31 = (DataObject) var30.get("identifier");
						if (var31.get("repositoryId") != null) {
							String var32 = String.valueOf(var31.get("repositoryId"));
							if (!var29.contains(var32)) {
								var29.add(var32);
							}
						}
					}
				}

				if (var29.size() == 0) {
					var28.append("repositories");
				} else {
					var28.append(var29);
				}

				throw new EntityNotFoundException("MULTIPLE_PRINCIPALS_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var28), this.className, var3);
			}

			DataObject var13 = (DataObject) var24.get(0);
			var5.setId(var13.getString("identifier/uniqueName"));
			var6 = this.mappingUtils.getWimService().createRootDataObject();
			if (var5.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var6, var5.getRealm());
			}

			var13 = var6.createDataObject("controls", "http://www.ibm.com/websphere/wim", "GroupMemberControl");
			var13.setString("level", Short.toString(this.mappingUtils.getGroupDepth()));
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var5.getRealm()))) {
				var13.getList("properties").add(this.propertyMap.getOutputUserSecurityName(var5.getRealm()));
			}

			if (var2 != 0) {
				var13.setString("countLimit", Integer.toString(var2 + 1));
			} else {
				var13.setString("countLimit", Integer.toString(var2));
			}

			var13.setString("expression", "@xsi:type='LoginAccount'");
			DataObject var14 = var6.createDataObject("entities", "http://www.ibm.com/websphere/wim", "Group");
			var14.createDataObject("identifier").setString("uniqueName", var5.getId());
			var6 = this.mappingUtils.getWimService().get(var6);
			List var15 = var6.getList("entities");
			if (var15.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var3);
			}

			DataObject var16 = (DataObject) var15.get(0);
			List var17 = var16.getList("members");
			if (!var17.isEmpty()) {
				String var18 = this.propertyMap.getOutputUserSecurityName(var5.getRealm());
				boolean var19 = this.mappingUtils.isIdentifierTypeProperty(var18);
				if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
					this.membershipBridgeTrace.logp(Level.FINER, this.className, var3,
							"userAttrName=" + var18 + ", isIdentifier=" + var19);
				}

				ArrayList var20 = new ArrayList();

				for (int var21 = 0; var21 < var17.size(); ++var21) {
					if (var2 != 0 && var21 == var2) {
						var4.setHasMore();
						break;
					}

					DataObject var22 = (DataObject) var17.get(var21);
					if (!var19) {
						var20.add(var22.getString(var18));
					} else {
						var20.add(var22.getString("identifier/" + var18));
					}
				}

				var4.setList(var20);
			} else {
				var4.setList(new ArrayList());
			}
		} catch (WIMException var23) {
			this.mappingUtils.logException(var23, this.className);
			if (!(var23 instanceof EntityNotFoundException) && !(var23 instanceof InvalidIdentifierException)) {
				throw new CustomRegistryException(var23);
			}

			throw new EntryNotFoundException(var23);
		}

		if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
			this.membershipBridgeTrace.exiting(this.className, var3, "returnValue = \"" + var4 + "\"");
		}

		return var4;
	}

	public List getUniqueGroupIds(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = "getUniqueGroupIds";
		if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
			this.membershipBridgeTrace.entering(this.className, var2, "inputUniqueUserId = \"" + var1 + "\"");
		}

		ArrayList var3 = new ArrayList();

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
				DataObject var6 = var5.createDataObject("contexts");
				var6.set("key", "allowOperationIfReposDown");
				var6.set("value", RealmManager.singleton().getAllowOperationIfReposDown(var4.getRealm()));
			}

			String var24 = "'";
			String var7 = var4.getId();
			if (var7.indexOf("'") != -1) {
				var24 = "\"";
			}

			String var8 = this.propertyMap.getInputUniqueUserId(var4.getRealm());
			var8 = this.mappingUtils.getRealInputAttrName(var8, var7, true);
			String var9 = this.propertyMap.getOutputUniqueGroupId(var4.getRealm());
			BridgeUtils var10000 = this.mappingUtils;
			boolean var10 = BridgeUtils.allowDNAsPrincipalName;
			DataObject var11;
			if (var10) {
				var11 = var5.createDataObject("contexts");
				var11.set("key", "allowDNPrincipalNameAsLiteral");
				var11.set("value", var10);
			}

			var11 = null;

			try {
				var11 = this.mappingUtils.getEntityByIdentifier(var5, var8, var7, var9, this.mappingUtils);
			} catch (WIMException var22) {
				if (!var10) {
					throw var22;
				}
			}

			DataObject var12;
			DataObject var13;
			if (var11 == null) {
				var12 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim", "SearchControl");
				var13 = var5.createDataObject("contexts");
				var13.set("key", "allowOperationIfReposDown");
				var13.set("value", RealmManager.singleton().getAllowOperationIfReposDown(var4.getRealm()));
				if (var10) {
					var8 = "principalName";
				}

				var12.setString("expression",
						"//entities[@xsi:type='LoginAccount' and " + var8 + "=" + var24 + var7 + var24 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
				List var14 = var5.getList("entities");
				if (var14.isEmpty()) {
					throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
							this.className, var2);
				}

				if (var14.size() != 1) {
					boolean var27 = false;
					int var29 = var14.size();
					StringBuilder var30 = new StringBuilder();
					HashSet var31 = new HashSet();

					for (int var28 = 0; var28 < var29; ++var28) {
						DataObject var32 = (DataObject) var14.get(var28);
						if (var32.get("identifier") != null) {
							DataObject var33 = (DataObject) var32.get("identifier");
							if (var33.get("repositoryId") != null) {
								String var34 = String.valueOf(var33.get("repositoryId"));
								if (!var31.contains(var34)) {
									var31.add(var34);
								}
							}
						}
					}

					if (var31.size() == 0) {
						var30.append("repositories");
					} else {
						var30.append(var31);
					}

					throw new EntityNotFoundException("MULTIPLE_PRINCIPALS_FOUND",
							WIMMessageHelper.generateMsgParms(var1, var30), this.className, var2);
				}

				DataObject var15 = (DataObject) var14.get(0);
				var4.setId(var15.getString("identifier/uniqueName"));
			}

			var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
				var12 = var5.createDataObject("contexts");
				var12.set("key", "allowOperationIfReposDown");
				var12.set("value", RealmManager.singleton().getAllowOperationIfReposDown(var4.getRealm()));
			}

			var12 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim", "GroupMembershipControl");
			if (!this.mappingUtils.isIdentifierTypeProperty(this.propertyMap.getOutputUniqueGroupId(var4.getRealm()))) {
				var12.getList("properties").add(this.propertyMap.getOutputUniqueGroupId(var4.getRealm()));
			}

			var12.setString("level", Short.toString(this.mappingUtils.getGroupDepth()));
			var13 = var12.createDataObject("contextProperties");
			var13.set("value", "ldapLoginGroupFilter");
			var12.setString("expression", "@xsi:type='Group'");
			DataObject var25 = var5.createDataObject("entities", "http://www.ibm.com/websphere/wim", "LoginAccount");
			if (!this.mappingUtils.isIdentifierTypeProperty(this.propertyMap.getInputUniqueUserId(var4.getRealm()))) {
				var25.createDataObject("identifier").setString("uniqueName", var4.getId());
			} else {
				var25.createDataObject("identifier").setString(this.propertyMap.getInputUniqueUserId(var4.getRealm()),
						var4.getId());
				if (this.propertyMap.getInputUniqueUserId(var4.getRealm()).equals("externalName")) {
					var5.createDataObject("controls", "http://www.ibm.com/websphere/wim", "ExternalNameControl");
				}
			}

			var5 = this.mappingUtils.getWimService().get(var5);
			List var26 = var5.getList("entities");
			if (var26.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var2);
			}

			DataObject var16 = (DataObject) var26.get(0);
			List var17 = var16.getList("groups");
			if (!var17.isEmpty()) {
				String var18 = this.propertyMap.getOutputUniqueGroupId(var4.getRealm());
				boolean var19 = this.mappingUtils.isIdentifierTypeProperty(var18);
				if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
					this.membershipBridgeTrace.logp(Level.FINER, this.className, var2,
							"grpAttrName=" + var18 + ", isIdentifier=" + var19);
				}

				for (int var20 = 0; var20 < var17.size(); ++var20) {
					DataObject var21 = (DataObject) var17.get(var20);
					if (!var19) {
						var3.add(var21.getString(var18));
					} else {
						var3.add(var21.getString("identifier/" + var18));
					}
				}
			}
		} catch (WIMException var23) {
			this.mappingUtils.logException(var23, this.className);
			if (var23 instanceof EntityNotFoundException) {
				throw new EntryNotFoundException(var23);
			}

			if (var23 instanceof InvalidUniqueNameException) {
				throw new EntryNotFoundException(var23);
			}

			if (var23 instanceof InvalidIdentifierException) {
				throw new EntryNotFoundException(var23);
			}

			throw new CustomRegistryException(var23);
		}

		if (this.membershipBridgeTrace.isLoggable(Level.FINER)) {
			this.membershipBridgeTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}
}