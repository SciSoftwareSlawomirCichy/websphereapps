package com.google.inject.internal;

import java.util.Map.Entry;

class SimpleEntry<K, V> implements Entry<K, V> {
	final K key;
	V value;

	SimpleEntry(K key, V value) {
		this.key = key;
		this.value = value;
	}

	public K getKey() {
		return this.key;
	}

	public V getValue() {
		return this.value;
	}

	public V setValue(V v) {
		V old = this.value;
		this.value = v;
		return old;
	}

	public int hashCode() {
		return (this.getKey() == null ? 0 : this.getKey().hashCode())
				^ (this.getValue() == null ? 0 : this.getValue().hashCode());
	}

	public boolean equals(Object o) {
		if (!(o instanceof Entry)) {
			return false;
		} else {
			boolean var10000;
			label38 : {
				label27 : {
					Entry e = (Entry) o;
					if (this.getKey() == null) {
						if (e.getKey() != null) {
							break label27;
						}
					} else if (!this.getKey().equals(e.getKey())) {
						break label27;
					}

					if (this.getValue() == null) {
						if (e.getValue() == null) {
							break label38;
						}
					} else if (this.getValue().equals(e.getValue())) {
						break label38;
					}
				}

				var10000 = false;
				return var10000;
			}

			var10000 = true;
			return var10000;
		}
	}
}