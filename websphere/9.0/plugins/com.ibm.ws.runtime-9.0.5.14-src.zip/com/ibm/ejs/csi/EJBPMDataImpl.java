package com.ibm.ejs.csi;

import com.ibm.websphere.csi.EJBPMData;

public class EJBPMDataImpl implements EJBPMData {
	private boolean lazyInitializationFlag;
	private String connFactoryName;
	private Object enterpriseBean;
	private Object extensions;
	private ClassLoader classLoader;
	private static final long serialVersionUID = -5870164202908414662L;

	public EJBPMDataImpl(Object enterpriseBean, Object extensions, ClassLoader classLoader,
			String connectionFactoryName, boolean lazy) {
		this.lazyInitializationFlag = lazy;
		this.enterpriseBean = enterpriseBean;
		this.extensions = extensions;
		this.classLoader = classLoader;
		this.connFactoryName = connectionFactoryName;
	}

	public boolean islazyInitialization() {
		return this.lazyInitializationFlag;
	}

	public Object getDeploymentData() {
		return this.enterpriseBean;
	}

	public Object getDeploymentExtn() {
		return this.extensions;
	}

	public ClassLoader getClassLoader() {
		return this.classLoader;
	}

	public String getCMPConnectionFactoryLookupName() {
		return "java:comp/PM/WebSphereCMPConnectionFactory";
	}

	public String getConnectionFactoryName() {
		return this.connFactoryName;
	}
}