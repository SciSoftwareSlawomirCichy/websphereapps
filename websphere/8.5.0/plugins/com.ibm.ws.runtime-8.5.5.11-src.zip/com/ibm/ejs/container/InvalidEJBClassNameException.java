package com.ibm.ejs.container;

public class InvalidEJBClassNameException extends ContainerException {
	private static final long serialVersionUID = 3765545543954619613L;

	public InvalidEJBClassNameException(String s, Throwable ex) {
		super(s, ex);
	}
}