package com.google.common.base;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Equivalence.1;
import com.google.common.base.Equivalence.Equals;
import com.google.common.base.Equivalence.EquivalentToPredicate;
import com.google.common.base.Equivalence.Identity;
import com.google.common.base.Equivalence.Wrapper;
import javax.annotation.Nullable;

@GwtCompatible
public abstract class Equivalence<T> {
	public final boolean equivalent(@Nullable T a, @Nullable T b) {
		if (a == b) {
			return true;
		} else {
			return a != null && b != null ? this.doEquivalent(a, b) : false;
		}
	}

	protected abstract boolean doEquivalent(T var1, T var2);

	public final int hash(@Nullable T t) {
		return t == null ? 0 : this.doHash(t);
	}

	protected abstract int doHash(T var1);

	public final <F> Equivalence<F> onResultOf(Function<F, ? extends T> function) {
		return new FunctionalEquivalence(function, this);
	}

	public final <S extends T> Wrapper<S> wrap(@Nullable S reference) {
      return new Wrapper(this, reference, (1)null);
   }

	@GwtCompatible(serializable = true)
	public final <S extends T> Equivalence<Iterable<S>> pairwise() {
		return new PairwiseEquivalence(this);
	}

	@Beta
	public final Predicate<T> equivalentTo(@Nullable T target) {
		return new EquivalentToPredicate(this, target);
	}

	public static Equivalence<Object> equals() {
		return Equals.INSTANCE;
	}

	public static Equivalence<Object> identity() {
		return Identity.INSTANCE;
	}
}