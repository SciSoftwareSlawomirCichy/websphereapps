package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.primitives.Ints;
import com.google.errorprone.annotations.concurrent.LazyInit;
import java.io.Serializable;
import java.util.Iterator;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true, serializable = true)
class RegularImmutableMultiset<E> extends ImmutableMultiset<E> {
	static final RegularImmutableMultiset<Object> EMPTY = new RegularImmutableMultiset(ObjectCountHashMap.create());
	final transient ObjectCountHashMap<E> contents;
	private final transient int size;
	@LazyInit
	private transient ImmutableSet<E> elementSet;

	RegularImmutableMultiset(ObjectCountHashMap<E> contents) {
		this.contents = contents;
		long size = 0L;

		for (int i = 0; i < contents.size(); ++i) {
			size += (long) contents.getValue(i);
		}

		this.size = Ints.saturatedCast(size);
	}

	boolean isPartialView() {
		return false;
	}

	public int count(@NullableDecl Object element) {
		return this.contents.get(element);
	}

	public int size() {
		return this.size;
	}

	public ImmutableSet<E> elementSet() {
		ImmutableSet<E> result = this.elementSet;
		return result == null ? (this.elementSet = new ElementSet()) : result;
	}

	Multiset.Entry<E> getEntry(int index) {
		return this.contents.getEntry(index);
	}

	@GwtIncompatible
	Object writeReplace() {
		return new SerializedForm(this);
	}

	@GwtIncompatible
	private static class SerializedForm implements Serializable {
		final Object[] elements;
		final int[] counts;
		private static final long serialVersionUID = 0L;

		SerializedForm(Multiset<?> multiset) {
			int distinct = multiset.entrySet().size();
			this.elements = new Object[distinct];
			this.counts = new int[distinct];
			int i = 0;

			for (Iterator var4 = multiset.entrySet().iterator(); var4.hasNext(); ++i) {
				Multiset.Entry<?> entry = (Multiset.Entry) var4.next();
				this.elements[i] = entry.getElement();
				this.counts[i] = entry.getCount();
			}

		}

		Object readResolve() {
			ImmutableMultiset.Builder<Object> builder = new ImmutableMultiset.Builder(this.elements.length);

			for (int i = 0; i < this.elements.length; ++i) {
				builder.addCopies(this.elements[i], this.counts[i]);
			}

			return builder.build();
		}
	}

	private final class ElementSet extends IndexedImmutableSet<E> {
		private ElementSet() {
		}

		E get(int index) {
			return RegularImmutableMultiset.this.contents.getKey(index);
		}

		public boolean contains(@NullableDecl Object object) {
			return RegularImmutableMultiset.this.contains(object);
		}

		boolean isPartialView() {
			return true;
		}

		public int size() {
			return RegularImmutableMultiset.this.contents.size();
		}
	}
}