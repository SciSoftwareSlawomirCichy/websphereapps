package com.google.inject.internal;

import com.google.inject.internal.Finalizer.1;
import com.google.inject.internal.Finalizer.ShutDown;
import java.lang.ref.PhantomReference;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Finalizer extends Thread {
	private static final Logger logger = Logger.getLogger(Finalizer.class.getName());
	private static final String FINALIZABLE_REFERENCE = "com.google.inject.internal.FinalizableReference";
	private final WeakReference<Class<?>> finalizableReferenceClassReference;
	private final PhantomReference<Object> frqReference;
	private final ReferenceQueue<Object> queue = new ReferenceQueue();

	public static ReferenceQueue<Object> startFinalizer(Class<?> finalizableReferenceClass, Object frq) {
		if (!finalizableReferenceClass.getName().equals("com.google.inject.internal.FinalizableReference")) {
			throw new IllegalArgumentException("Expected com.google.inject.internal.FinalizableReference.");
		} else {
			Finalizer finalizer = new Finalizer(finalizableReferenceClass, frq);
			finalizer.start();
			return finalizer.queue;
		}
	}

	private Finalizer(Class<?> finalizableReferenceClass, Object frq) {
		super(Finalizer.class.getName());
		this.finalizableReferenceClassReference = new WeakReference(finalizableReferenceClass);
		this.frqReference = new PhantomReference(frq, this.queue);
		this.setDaemon(true);
	}

	public void run() {
		try {
			while (true) {
				try {
					this.cleanUp(this.queue.remove());
				} catch (InterruptedException var2) {
					;
				}
			}
		} catch (ShutDown var3) {
			;
		}
	}

	private void cleanUp(Reference<?> reference) throws ShutDown {
      Method finalizeReferentMethod = this.getFinalizeReferentMethod();

      do {
         reference.clear();
         if (reference == this.frqReference) {
            throw new ShutDown((1)null);
         }

         try {
            finalizeReferentMethod.invoke(reference);
         } catch (Throwable var4) {
            logger.log(Level.SEVERE, "Error cleaning up after reference.", var4);
         }
      } while((reference = this.queue.poll()) != null);

   }

	private Method getFinalizeReferentMethod() throws ShutDown {
      Class<?> finalizableReferenceClass = (Class)this.finalizableReferenceClassReference.get();
      if (finalizableReferenceClass == null) {
         throw new ShutDown((1)null);
      } else {
         try {
            return finalizableReferenceClass.getMethod("finalizeReferent");
         } catch (NoSuchMethodException var3) {
            throw new AssertionError(var3);
         }
      }
   }
}