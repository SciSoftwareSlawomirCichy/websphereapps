package com.ibm.ejs.cm.cache;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import com.ibm.ejs.util.LRUCacheElement;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.BitSet;
import java.util.Calendar;

public final class CachedStatement extends LRUCacheElement implements PreparedStatement {
	private static final TraceNLS NLS = TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages");
	private StatementCache cache;
	private BitSet currentBitSet;
	private BitSet priorBitSet;
	private PreparedStatement statement;
	private boolean bitSetError = false;
	private static final TraceComponent tc = Tr.register(CachedStatement.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setAsciiStream(int, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setAsciiStream(int, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBinaryStream(int, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBinaryStream(int, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBlob(int, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBlob(int, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setCharacterStream(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setCharacterStream(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setClob(int parameterIndex, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setClob(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setClob(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNCharacterStream(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNCharacterStream(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNClob(int parameterIndex, NClob value) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNClob(int, NClob)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNClob(int parameterIndex, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNClob(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNClob(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNString(int parameterIndex, String value) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNString(int, String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setRowId(int parameterIndex, RowId x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setRowId(int, RowId)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setSQLXML(int, SQLXML)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public boolean isClosed() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isClosed()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public boolean isPoolable() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isPoolable()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setPoolable(boolean poolable) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setPoolable(boolean)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isWrapperFor(Class<?>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "unwrap(Class<T>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setURL(int i, URL url) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setURL(int, java.net.URL)");
		throw new SQLException("This method is not supported.");
	}

	public ParameterMetaData getParameterMetaData() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getParameterMetaData()");
		throw new SQLException("This method is not supported.");
	}

	public boolean execute(String s, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "execute(String, int)");
		throw new SQLException("This method is not supported.");
	}

	public boolean execute(String s, int[] i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "execute(String, int[])");
		throw new SQLException("This method is not supported.");
	}

	public int executeUpdate(String s, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "executeUpdate(String, int)");
		throw new SQLException("This method is not supported.");
	}

	public int executeUpdate(String s, int[] i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "executeUpdate(String, int[])");
		throw new SQLException("This method is not supported.");
	}

	public boolean execute(String s, String[] ss) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "execute(String, String[])");
		throw new SQLException("This method is not supported.");
	}

	public int executeUpdate(String s, String[] ss) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "executeUpdate(String, String[])");
		throw new SQLException("This method is not supported.");
	}

	public ResultSet getGeneratedKeys() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getGeneratedKeys()");
		throw new SQLException("This method is not supported.");
	}

	public boolean getMoreResults(int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getMoreResults(int)");
		throw new SQLException("This method is not supported.");
	}

	public int getResultSetHoldability() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getResultSetHoldability()");
		throw new SQLException("This method is not supported.");
	}

	CachedStatement(StatementCache cache, String statementString, PreparedStatement statement) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", new Object[]{cache, statement});
		}

		this.cache = cache;
		this.statement = statement;
		this.key = statementString;
		this.currentBitSet = new BitSet();
		this.priorBitSet = null;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void close() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "close");
		}

		if (this.cache != null) {
			this.cache.releaseStatement(this);
		}

		if (this.currentBitSet != null) {
			if (this.bitSetError) {
				this.currentBitSet = new BitSet();
			} else {
				for (int u = this.currentBitSet.length() - 1; u > -1; --u) {
					this.currentBitSet.clear(u);
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "close");
		}

	}

	void destroy() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy");
		}

		try {
			this.statement.close();
		} catch (SQLException var5) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Exception closing statement", var5);
			}
		} finally {
			this.statement = null;
			this.cache = null;
			this.currentBitSet = null;
			this.priorBitSet = null;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "destroy");
		}

	}

	public String getStatementString() {
		return (String) this.key;
	}

	public final void setFetchDirection(int dir) throws SQLException {
		this.statement.setFetchDirection(dir);
	}

	public final int getFetchDirection() throws SQLException {
		return this.statement.getFetchDirection();
	}

	public final void setFetchSize(int count) throws SQLException {
		this.statement.setFetchSize(count);
	}

	public final int getFetchSize() throws SQLException {
		return this.statement.getFetchSize();
	}

	public final int getResultSetType() throws SQLException {
		return this.statement.getResultSetType();
	}

	public final int getResultSetConcurrency() throws SQLException {
		return this.statement.getResultSetConcurrency();
	}

	public final void addBatch(String sql) throws SQLException {
		this.statement.addBatch(sql);
	}

	public final void clearBatch() throws SQLException {
		this.statement.clearBatch();
	}

	public final int[] executeBatch() throws SQLException {
		return this.statement.executeBatch();
	}

	public final Connection getConnection() throws SQLException {
		return this.statement.getConnection();
	}

	public void cancel() throws SQLException {
		this.statement.cancel();
	}

	public void clearWarnings() throws SQLException {
		this.statement.clearWarnings();
	}

	public boolean execute(String sql) throws SQLException {
		return this.statement.execute(sql);
	}

	public ResultSet executeQuery(String sql) throws SQLException {
		return this.statement.executeQuery(sql);
	}

	public int executeUpdate(String sql) throws SQLException {
		return this.statement.executeUpdate(sql);
	}

	public int getMaxFieldSize() throws SQLException {
		return this.statement.getMaxFieldSize();
	}

	public int getMaxRows() throws SQLException {
		return this.statement.getMaxRows();
	}

	public boolean getMoreResults() throws SQLException {
		return this.statement.getMoreResults();
	}

	public int getQueryTimeout() throws SQLException {
		return this.statement.getQueryTimeout();
	}

	public ResultSet getResultSet() throws SQLException {
		return this.statement.getResultSet();
	}

	public int getUpdateCount() throws SQLException {
		return this.statement.getUpdateCount();
	}

	public SQLWarning getWarnings() throws SQLException {
		return this.statement.getWarnings();
	}

	public void setCursorName(String name) throws SQLException {
		this.statement.setCursorName(name);
	}

	public void setEscapeProcessing(boolean enable) throws SQLException {
		this.statement.setEscapeProcessing(enable);
	}

	public void setMaxFieldSize(int max) throws SQLException {
		this.statement.setMaxFieldSize(max);
	}

	public void setMaxRows(int max) throws SQLException {
		this.statement.setMaxRows(max);
	}

	public void setQueryTimeout(int timeout) throws SQLException {
		this.statement.setQueryTimeout(timeout);
	}

	public void addBatch() throws SQLException {
		this.statement.addBatch();
	}

	public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
		this.statement.setCharacterStream(parameterIndex, reader, length);
		this.currentBitSet.set(parameterIndex);
	}

	public void setRef(int i, Ref x) throws SQLException {
		this.statement.setRef(i, x);
		this.currentBitSet.set(i);
	}

	public void setBlob(int i, Blob x) throws SQLException {
		this.statement.setBlob(i, x);
		this.currentBitSet.set(i);
	}

	public void setClob(int i, Clob x) throws SQLException {
		this.statement.setClob(i, x);
		this.currentBitSet.set(i);
	}

	public void setArray(int i, Array x) throws SQLException {
		this.statement.setArray(i, x);
		this.currentBitSet.set(i);
	}

	public ResultSetMetaData getMetaData() throws SQLException {
		return this.statement.getMetaData();
	}

	public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
		this.statement.setDate(parameterIndex, x, cal);
		this.currentBitSet.set(parameterIndex);
	}

	public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
		this.statement.setTime(parameterIndex, x, cal);
		this.currentBitSet.set(parameterIndex);
	}

	public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
		this.statement.setTimestamp(parameterIndex, x, cal);
		this.currentBitSet.set(parameterIndex);
	}

	public void setNull(int paramIndex, int sqlType, String typeName) throws SQLException {
		this.statement.setNull(paramIndex, sqlType, typeName);
		this.currentBitSet.set(paramIndex);
	}

	public ResultSet executeQuery() throws SQLException {
		if (this.priorBitSet == null) {
			ResultSet returnVal = null;

			try {
				returnVal = this.statement.executeQuery();
				this.bitSetError = false;
			} catch (SQLException var3) {
				this.bitSetError = true;
				throw var3;
			}

			this.priorBitSet = (BitSet) this.currentBitSet.clone();
			return returnVal;
		} else if (!this.currentBitSet.equals(this.priorBitSet)) {
			throw new SQLException("Insufficient number of parameter were set before execution "
					+ this.currentBitSet.toString() + " of " + this.priorBitSet.toString());
		} else {
			return this.statement.executeQuery();
		}
	}

	public int executeUpdate() throws SQLException {
		if (this.priorBitSet == null) {
			boolean var1 = false;

			int returnVal;
			try {
				returnVal = this.statement.executeUpdate();
				this.bitSetError = false;
			} catch (SQLException var3) {
				this.bitSetError = true;
				throw var3;
			}

			this.priorBitSet = (BitSet) this.currentBitSet.clone();
			return returnVal;
		} else if (!this.currentBitSet.equals(this.priorBitSet)) {
			throw new SQLException("Insufficient number of parameter were set before execution "
					+ this.currentBitSet.toString() + " of " + this.priorBitSet.toString());
		} else {
			return this.statement.executeUpdate();
		}
	}

	public void setNull(int parameterIndex, int sqlType) throws SQLException {
		this.statement.setNull(parameterIndex, sqlType);
		this.currentBitSet.set(parameterIndex);
	}

	public void setBoolean(int parameterIndex, boolean x) throws SQLException {
		this.statement.setBoolean(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setByte(int parameterIndex, byte x) throws SQLException {
		this.statement.setByte(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setShort(int parameterIndex, short x) throws SQLException {
		this.statement.setShort(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setInt(int parameterIndex, int x) throws SQLException {
		this.statement.setInt(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setLong(int parameterIndex, long x) throws SQLException {
		this.statement.setLong(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setFloat(int parameterIndex, float x) throws SQLException {
		this.statement.setFloat(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setDouble(int parameterIndex, double x) throws SQLException {
		this.statement.setDouble(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
		this.statement.setBigDecimal(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setString(int parameterIndex, String x) throws SQLException {
		this.statement.setString(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setBytes(int parameterIndex, byte[] x) throws SQLException {
		this.statement.setBytes(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setDate(int parameterIndex, Date x) throws SQLException {
		this.statement.setDate(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setTime(int parameterIndex, Time x) throws SQLException {
		this.statement.setTime(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
		this.statement.setTimestamp(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
		this.statement.setAsciiStream(parameterIndex, x, length);
		this.currentBitSet.set(parameterIndex);
	}

	public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
		this.statement.setUnicodeStream(parameterIndex, x, length);
		this.currentBitSet.set(parameterIndex);
	}

	public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
		this.statement.setBinaryStream(parameterIndex, x, length);
		this.currentBitSet.set(parameterIndex);
	}

	public void clearParameters() throws SQLException {
		if (this.priorBitSet == null) {
			this.statement.clearParameters();
			if (this.bitSetError) {
				this.currentBitSet = new BitSet();
			}
		}

		for (int u = this.currentBitSet.length() - 1; u > -1; --u) {
			this.currentBitSet.clear(u);
		}

	}

	public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
		this.statement.setObject(parameterIndex, x, targetSqlType, scale);
		this.currentBitSet.set(parameterIndex);
	}

	public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
		this.statement.setObject(parameterIndex, x, targetSqlType);
		this.currentBitSet.set(parameterIndex);
	}

	public void setObject(int parameterIndex, Object x) throws SQLException {
		this.statement.setObject(parameterIndex, x);
		this.currentBitSet.set(parameterIndex);
	}

	public boolean execute() throws SQLException {
		if (this.priorBitSet == null) {
			boolean returnVal = false;

			try {
				returnVal = this.statement.execute();
				this.bitSetError = false;
			} catch (SQLException var3) {
				this.bitSetError = true;
				throw var3;
			}

			this.priorBitSet = (BitSet) this.currentBitSet.clone();
			return returnVal;
		} else if (!this.currentBitSet.equals(this.priorBitSet)) {
			throw new SQLException("Insufficient number of parameter were set before execution "
					+ this.currentBitSet.toString() + " of " + this.priorBitSet.toString());
		} else {
			return this.statement.execute();
		}
	}

	public PreparedStatement getPreparedStatement() {
		return this.statement;
	}

	public void closeOnCompletion() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public boolean isCloseOnCompletion() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}
}