package com.ibm.ejs.util.locking;

interface package-info {
}