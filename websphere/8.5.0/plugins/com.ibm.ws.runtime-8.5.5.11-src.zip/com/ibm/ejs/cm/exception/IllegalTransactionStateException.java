package com.ibm.ejs.cm.exception;

import com.ibm.ejs.cm.portability.PortableSQLException;
import org.omg.CosTransactions.Status;

public class IllegalTransactionStateException extends PortableSQLException {
	private static final long serialVersionUID = 8580831543552768033L;

	public IllegalTransactionStateException(Status s) {
		super("Operation illegal with transaction state " + s.getClass());
	}

	public IllegalTransactionStateException(int state) {
		super("Operation illegal with transaction state " + new Integer(state));
	}

	public IllegalTransactionStateException() {
	}
}