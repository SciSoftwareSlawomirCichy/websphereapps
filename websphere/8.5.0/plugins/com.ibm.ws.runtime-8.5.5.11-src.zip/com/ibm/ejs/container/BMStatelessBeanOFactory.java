package com.ibm.ejs.container;

import com.ibm.ws.managedobject.ManagedObject;

public class BMStatelessBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		return new BMStatelessBeanO(c, mo, b, h);
	}
}