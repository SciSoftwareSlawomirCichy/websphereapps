package com.google.inject.internal;

import java.lang.annotation.Annotation;

public class Nullability {
	public static boolean allowsNull(Annotation[] annotations) {
		Annotation[] arr$ = annotations;
		int len$ = annotations.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Annotation a = arr$[i$];
			if ("Nullable".equals(a.annotationType().getSimpleName())) {
				return true;
			}
		}

		return false;
	}
}