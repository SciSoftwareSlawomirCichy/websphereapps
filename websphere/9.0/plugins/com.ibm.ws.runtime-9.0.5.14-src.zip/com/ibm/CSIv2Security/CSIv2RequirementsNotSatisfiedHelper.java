package com.ibm.CSIv2Security;

import org.omg.CORBA.Any;
import org.omg.CORBA.BAD_OPERATION;
import org.omg.CORBA.IDLType;
import org.omg.CORBA.ORB;
import org.omg.CORBA.StructMember;
import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;

public abstract class CSIv2RequirementsNotSatisfiedHelper {
	private static String _id = "IDL:ibm.com/CSIv2Security/CSIv2RequirementsNotSatisfied:1.0";
	private static volatile TypeCode __typeCode = null;
	private static boolean __active = false;

	public static void insert(Any var0, CSIv2RequirementsNotSatisfied var1) {
		OutputStream var2 = var0.create_output_stream();
		var0.type(type());
		write(var2, var1);
		var0.read_value(var2.create_input_stream(), type());
	}

	public static CSIv2RequirementsNotSatisfied extract(Any var0) {
		if (!var0.type().equal(type())) {
			throw new BAD_OPERATION(
					"extract() failed.Expected a com.ibm.CSIv2Security.CSIv2RequirementsNotSatisfied .");
		} else {
			return read(var0.create_input_stream());
		}
	}

	public static TypeCode type() {
		TypeCode var0 = __typeCode;
		if (var0 == null) {
			synchronized (TypeCode.class) {
				var0 = __typeCode;
				if (var0 == null) {
					if (__active) {
						return ORB.init().create_recursive_tc(_id);
					}

					__active = true;
					StructMember[] var2 = new StructMember[2];
					TypeCode var3 = null;
					var3 = CSIv2RequirementsNotSatisfiedReasonHelper.type();
					var2[0] = new StructMember("reason", var3, (IDLType) null);
					var3 = ORB.init().create_string_tc(0);
					var2[1] = new StructMember("debugMessage", var3, (IDLType) null);
					var0 = ORB.init().create_exception_tc(id(), "CSIv2RequirementsNotSatisfied", var2);
					__active = false;
					__typeCode = var0;
				}
			}
		}

		return var0;
	}

	public static String id() {
		return _id;
	}

	public static CSIv2RequirementsNotSatisfied read(InputStream var0) {
		CSIv2RequirementsNotSatisfied var1 = new CSIv2RequirementsNotSatisfied();
		var0.read_string();
		var1.reason = CSIv2RequirementsNotSatisfiedReasonHelper.read(var0);
		var1.debugMessage = var0.read_string();
		return var1;
	}

	public static void write(OutputStream var0, CSIv2RequirementsNotSatisfied var1) {
		var0.write_string(id());
		CSIv2RequirementsNotSatisfiedReasonHelper.write(var0, var1.reason);
		var0.write_string(var1.debugMessage);
	}
}