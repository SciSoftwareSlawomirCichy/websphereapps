package com.ibm.ejs.oa;

import com.ibm.ejs.EJSException;

public class AdapterAlreadyExistsException extends EJSException {
	private static final long serialVersionUID = -2309357105599561084L;
}