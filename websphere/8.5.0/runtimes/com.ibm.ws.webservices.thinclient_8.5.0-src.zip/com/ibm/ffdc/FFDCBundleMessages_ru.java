package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_ru extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: Добавлен FFDC Formatter {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Механизм анализа использует базу данных {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: Не удалось преобразовать Analysis Engine:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: Добавлен FFDC Data Collector {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: Удален FFDC Data Collector {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: Инцидент FFDC отправлен в SystemErr: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC в режиме защиты от сбоев, проверьте ошибки {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: Добавлен FFDC Incident Forwarder {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: Удален FFDC Incident Forwarder {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Инцидент FFDC отправлен для {0} {1} {2}"},
			{"FFDCProviderAborted",
					"FFDC1000I: FFDC Provider {0} отменен, сведения об исключительной ситуации приведены ниже"},
			{"FFDCProviderAbortedE", "FFDC1001I: FFDC Provider отменен с исключительной ситуацией {0}"},
			{"FFDCProviderException", "FFDC1008I: Исключительная ситуация FFDC Provider:"},
			{"FFDCProviderInstalled", "FFDC1007I: Установлен FFDC Provider: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: Удален FFDC Formatter {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}