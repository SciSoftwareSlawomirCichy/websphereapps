package com.ibm.ejs.container;

public class DuplicateHomeNameException extends ContainerException {
	private static final long serialVersionUID = 4878512837435795367L;

	public DuplicateHomeNameException(String s) {
		super(s);
	}
}