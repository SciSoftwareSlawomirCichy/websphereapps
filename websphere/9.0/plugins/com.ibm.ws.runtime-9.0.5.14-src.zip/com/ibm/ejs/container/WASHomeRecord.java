package com.ibm.ejs.container;

import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.cpmi.CPMIException;
import com.ibm.websphere.cpmi.PMBeanInfo;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;

public class WASHomeRecord extends HomeRecord implements EntityHomeRecord {
	private static final String CLASS_NAME = "com.ibm.ejs.container.WASHomeRecord";
	protected PMBeanInfo ivPMBeanInfo;

	public WASHomeRecord(BeanMetaData bmd, HomeOfHomes homeOfHomes) {
		super(bmd, homeOfHomes);
	}

	public Object getPMInternalHome() throws CPMIException {
		try {
			return this.getHomeAndInitialize().getWrapper().getRemoteWrapper();
		} catch (RemoteException var2) {
			FFDCFilter.processException(var2, "com.ibm.ejs.container.WASHomeRecord.getPMInternalHome", "2500", this);
			throw new CPMIException("getPMInternalHome", var2);
		}
	}

	public Object getPMInternalLocalHome() throws CPMIException {
		try {
			return this.getHomeAndInitialize().getWrapper().getLocalWrapper();
		} catch (RemoteException var2) {
			FFDCFilter.processException(var2, "com.ibm.ejs.container.WASHomeRecord.getPMInternalLocalHome", "2515",
					this);
			throw new CPMIException("getPMInternalLocalHome", var2);
		}
	}

	public void setPMBeanInfo(PMBeanInfo pmBeanInfo) {
		this.ivPMBeanInfo = pmBeanInfo;
	}

	public PMBeanInfo getPMBeanInfo() {
		return this.ivPMBeanInfo;
	}

	public boolean isReadOnly() {
		this.getHomeAndInitialize();
		return this.bmd.ivCacheReloadType != 0;
	}

	public final boolean hasMethodLevelAccessIntentSet() {
		if (this.homeInternal == null) {
			throw new ContainerEJBException("hasMethodLevelAccessIntentSet() invoke prior to EJB initialization.");
		} else {
			return ((EJSHome) this.homeInternal).hasMethodLevelAccessIntentSet();
		}
	}

	public final AccessIntent getBeanLevelAccessIntent() {
		return this.homeInternal != null
				? EntityHelperImpl.getBeanLevelAccessIntent((EJSHome) this.homeInternal)
				: null;
	}
}