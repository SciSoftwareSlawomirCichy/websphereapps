package com.ibm.ejs.container;

public class IllegalSessionMethodException extends ContainerException {
	private static final long serialVersionUID = 3020565125536306536L;
}