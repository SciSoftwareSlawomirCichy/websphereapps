package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_pt_BR extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: Foi detectada uma inconsistência nos níveis de construção dos componentes do cliente de servidor de aplicativos instalados. O nível de construção instalado do componente do cliente {0} que é {1} é diferente do nível de construção do componente do cliente {2} que é {3}."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: Uma inconsistência nos níveis de construção dos componentes do cliente de servidor de aplicativos instalados evita execução posterior."},
			{"EXCP_CWSJE0003E", "CWSJE0003E: Impossível acessar o recurso {1} por causa da exceção: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}