package com.ibm.ws.wim.util;

import com.ibm.websphere.management.AdminContext;
import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.cmdframework.provider.AbstractAdminCommand;
import com.ibm.websphere.management.configservice.ConfigDataId;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.management.configservice.ConfigServiceFactory;
import com.ibm.websphere.management.configservice.ConfigServiceHelper;
import com.ibm.websphere.wim.DomainConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InvalidDomainNameException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.bootstrap.ExtClassLoader;
import com.ibm.ws.management.profileregistry.ProfileRegistryFactory;
import com.ibm.ws.security.config.SecurityConfig;
import com.ibm.ws.security.config.SecurityConfigManager;
import com.ibm.ws.security.config.SecurityObjectLocator;
import com.ibm.ws.security.config.UserRegistryConfig;
import com.ibm.ws.wim.management.DynamicReloadManager;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.AttributeList;
import javax.management.ObjectName;
import javax.management.QueryExp;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EPackage.Registry;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DomainManagerUtils implements DomainConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final ThreadLocal<Map<String, Object>> vmmDomainMap;
	private static final ThreadLocal<Map<String, Object>> vmmCLSwitchMap;
	private static final String sFileSep;
	private static final Logger trcLogger;

	private static String getLocalDomainName() {
		String var0 = "getLocalDomainName";
		String var1 = null;
		Map var2 = (Map) vmmDomainMap.get();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var0, var2);
		}

		if (var2 != null) {
			var1 = (String) var2.get("vmmDomainName");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var0, "Obtained domain name= " + var1 + " from VMM thread local");
		}

		return var1;
	}

	private static ClassLoader getContextClassLoader() {
		String var0 = "getContextClassLoader";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var0);
		}

		ClassLoader var1 = null;
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, var0,
					"Getting thread context class loader when security is enabled");
		}

		if (System.getSecurityManager() != null) {
			var1 = (new ContextClassLoaderGetter()).getContextClassLoader();
		} else {
			var1 = Thread.currentThread().getContextClassLoader();
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var0,
						"Getting thread context class loader when security is disabled");
			}
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var0, "RETURN thread context class loader :" + var1);
		}

		return var1;
	}

	private static ClassLoader setContextClassLoader(ClassLoader var0) {
		String var1 = "setContextClassLoader";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var1);
		}

		ClassLoader var2 = var0;
		if (System.getSecurityManager() != null) {
			var2 = (new ContextClassLoaderSetter()).setContextClassLoader(var0);
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var1,
						"Setting thread context class loader when security is enabled");
			}
		} else {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var1,
						"Setting thread context class loader when security is disabled");
			}

			Thread.currentThread().setContextClassLoader(var0);
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var1, "RETURN  set thread context class loader :" + var2);
		}

		return var2;
	}

	public static void validateDomainName(String var0) throws WIMException {
		String var1 = "validateDomainName";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var1, "domain Name " + var0);
		}

		if (var0 != null && !"admin".equals(var0)) {
			String var2 = getDomainPath(var0);
			File var3 = new File(var2);
			if (!var3.isDirectory()) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, var1, "Invalid domain=" + var0 + ", validation failed");
				}

				throw new InvalidDomainNameException("DIRECTORY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var2),
						Level.SEVERE, CLASSNAME, var1);
			} else {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.exiting(CLASSNAME, var1, "Domain, " + var0 + " is valid");
				}

			}
		} else {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var1,
						"No validation required for null domain name or admin domain name");
			}

		}
	}

	public static String getActiveDomainName() {
		String var0 = "getActiveDomainName";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var0);
		}

		String var1 = null;
		SecurityConfigManager var2 = SecurityObjectLocator.getSecurityConfigManager();
		if (var2 != null) {
			var1 = var2.getActiveDomainName();
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var0, "RETURN active domain name=" + var1);
		}

		return var1;
	}

	public static String getDomainName() {
		String var0 = "getDomainName";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var0);
		}

		String var1 = getLocalDomainName();
		if (var1 == null) {
			var1 = getActiveDomainName();
			if (var1 == null) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, var0,
							"Setting the domain name to admin as no domain informaton available in VMM Thread Local or WAS SecurityConfigManager");
				}

				var1 = "admin";
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var0, "RETURN domain name=" + var1);
		}

		return var1;
	}

	public static String getDomainId() {
		String var0 = "getDomainId";
		String var1 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var0);
		}

		SecurityConfigManager var2 = SecurityObjectLocator.getSecurityConfigManager();
		var1 = getLocalDomainName();
		if (var1 != null && var2 != null && "admin".equals(var1) && isAdminAgent()) {
			var1 = var2.getDomainId();
		}

		if (var1 == null) {
			if (var2 == null) {
				var1 = "admin";
			} else {
				var1 = var2.getActiveDomainName();
				if (var1 == null) {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, var0,
								"Setting the domain name to admin as no domain informaton available in VMM Thread Local or WAS SecurityConfigManager");
					}

					var1 = "admin";
				}

				if (isAdminAgent()) {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, var0,
								"Admin agent, returning domain id as actual domain id");
					}

					if ("admin".equals(var1) || isSetUseGlobalFedRepos(var1) || isSetUseGlobalSecuritySettings(var1)) {
						var1 = var2.getDomainId();
					}
				} else {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, var0,
								"Not a admin agent, returning domain name as domain id");
					}

					if (!"admin".equalsIgnoreCase(var1)
							&& (isSetUseGlobalSecuritySettings(var1) || isSetUseGlobalFedRepos(var1))) {
						var1 = "admin";
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var0, "RETURN domain ID=" + var1);
		}

		return var1;
	}

	public static String getDomainPath(String var0) {
		String var1 = "getDomainPath";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var1);
		}

		String var2 = null;
		if ("admin".equals(var0)) {
			var0 = "null";
		}

		if (!isWASServerProcess()) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var1, "Obtained domain path in local mode as " + var2);
			}

			var2 = getDomainPathInLocalMode(var0);
		} else {
			SecurityConfigManager var3 = SecurityObjectLocator.getSecurityConfigManager();
			var2 = var3.getDomainPath(var0);
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var1, "Obtained domain path in server mode as " + var2);
			}
		}

		if (!var2.endsWith(sFileSep) && !var2.endsWith("/") && !var2.endsWith("\\")) {
			var2 = var2 + sFileSep;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var1, "RETURN domain path as " + var2);
		}

		return var2;
	}

	public static String getDomainPathInLocalMode(String var0) {
		String var1 = "getDomainPathInLocalMode";
		SecurityConfigManager var2 = SecurityObjectLocator.getSecurityConfigManager();
		String var3 = var2.getDomainPathInLocalMode(isAdminAgent(), var0);
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, var1,
					"Obtained domain path as " + var3 + "in local mode using Security Config Manager");
		}

		return var3;
	}

	public static String getDomainPathFromTemp(String var0, String var1) {
		String var2 = "getDomainPathFromTemp";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2, " Get domain path from temp for domain Name " + var0);
		}

		String var3 = null;
		String var4 = null;
		String var5 = System.getProperty("websphere.workspace.root");
		String var6 = var1 + sFileSep + "workspace" + sFileSep + RELATIVE_WIM_CONFIG_DOMAIN_PATH + sFileSep + var0
				+ sFileSep;
		var4 = var5 == null ? System.getProperty("user.install.root") : var5;
		if (isAdminAgent()) {
			String var7 = AdminContext.peek();
			var3 = var4 + sFileSep + "wstemp" + sFileSep + var7 + sFileSep + var6;
		} else if ("admin".equals(var0)) {
			var3 = var4 + sFileSep + "wstemp" + sFileSep + var1 + sFileSep + "workspace" + sFileSep + "cells" + sFileSep
					+ DynamicReloadManager.getCellName() + sFileSep;
		} else {
			var3 = var4 + sFileSep + "wstemp" + sFileSep + var6;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var2, "RETURN domain path from temp  " + var3);
		}

		return var3;
	}

	public static boolean isAdminAgent() {
		String var0 = "isAdminAgent";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var0);
		}

		boolean var1 = false;
		SecurityConfigManager var2 = SecurityObjectLocator.getSecurityConfigManager();
		if (var2 != null) {
			var1 = var2.isAdminAgent();
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var0, "Returning isAdminAgent, " + var1);
		}

		return var1;
	}

	public static boolean isInVMMDomainThreadContext() {
		String var0 = "isInVMMDomainThreadContext";
		Map var1 = (Map) vmmDomainMap.get();
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, var0, "domainMap=" + var1);
		}

		if (var1 != null && ((String) var1.get("COMPONENT_THREAD_CONTEXT_NAME")).equals("vmm")) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var0,
						"Current thread=" + Thread.currentThread().getName() + " is in VMM context");
			}

			return true;
		} else {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var0,
						"Current thread=" + Thread.currentThread().getName() + " is not in VMM context");
			}

			return false;
		}
	}

	public static boolean isWASServerProcess() {
		SecurityConfigManager var0 = SecurityObjectLocator.getSecurityConfigManager();
		return var0.isWASServer();
	}

	private static synchronized int incrementThreadContextCount(Map var0) {
		String var1 = "incrementThreadContextCount";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var1, "Incrementing thread Context Count");
		}

		Integer var2 = (Integer) var0.get("DOMAIN_CONTEXT_REF_COUNT");
		int var3 = var2;
		++var3;
		var2 = new Integer(var3);
		var0.put("DOMAIN_CONTEXT_REF_COUNT", var2);
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var1, "Returning Incremented Thread Context Count, " + var3);
		}

		return var3;
	}

	private static synchronized int decrementThreadContextCount(Map var0) {
		String var1 = "decrementThreadContextCount";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var1, "Decrementing thread Context Count");
		}

		Integer var2 = (Integer) var0.get("DOMAIN_CONTEXT_REF_COUNT");
		int var3 = var2;
		--var3;
		var2 = new Integer(var3);
		var0.put("DOMAIN_CONTEXT_REF_COUNT", var2);
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var1, "Returning Decremented Thread Context Count as " + var3);
		}

		return var3;
	}

	public static void cleanUpVMMThreadDomainContext() {
		String var0 = "cleanUpVMMThreadDomainContext";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var0, vmmDomainMap.get());
		}

		EMFDomainUtils.cleanUpVMMThreadDomainContext();
		int var1 = 0;
		if (vmmDomainMap.get() != null) {
			var1 = decrementThreadContextCount((Map) vmmDomainMap.get());
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var0, "Cleanup VMM context in thread="
						+ Thread.currentThread().getName() + " with context reference count=" + var1);
			}

			if (var1 > 0) {
				return;
			}
		}

		vmmDomainMap.remove();
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var0, "Cleaned VMM context from thread=" + Thread.currentThread().getName()
					+ " with context reference count=" + var1);
		}

	}

	private static void setVMMThreadDomainContextWithClassLoader(String var0, ClassLoader var1) {
		String var2 = "setVMMThreadDomainContextWithClassLoader";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var2, new Object[]{var0, var1, vmmDomainMap.get()});
		}

		EMFDomainUtils.setVMMThreadDomainContextWithClassLoader(var0, var1);
		if (vmmDomainMap.get() != null) {
			int var4 = incrementThreadContextCount((Map) vmmDomainMap.get());
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var2, "Setup VMM context in thread="
						+ Thread.currentThread().getName() + " with context reference count=" + var4);
			}

		} else {
			HashMap var3 = new HashMap();
			if (var0 == null) {
				var3.put("vmmDomainName", "admin");
			} else {
				var3.put("vmmDomainName", var0);
			}

			var3.put("vmmDomainName", var0);
			var3.put("COMPONENT_THREAD_CONTEXT_NAME", "vmm");
			var3.put("vmm_loaded_classloader", var1);
			var3.put("DOMAIN_CONTEXT_REF_COUNT", new Integer(1));
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var2, "Setup VMM context in thread="
						+ Thread.currentThread().getName() + " with context reference count=1 for domain:" + var0);
			}

			vmmDomainMap.set(var3);
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.exiting(CLASSNAME, var2, var3);
			}

		}
	}

	public static void setVMMThreadDomainContext() {
		setVMMThreadDomainContextWithClassLoader(getDomainName(), getWASExtClassLoader());
	}

	public static void setVMMThreadDomainContext(String var0) {
		setVMMThreadDomainContextWithClassLoader(var0, getWASExtClassLoader());
	}

	public static void setVMMThreadDomainContextForCLI(String var0) throws Exception {
		Object var1 = null;
		validateDomainName(var0);
		setVMMThreadDomainContext(var0);
	}

	public static void setVMMThreadDomainContextForCLI(AbstractAdminCommand var0) throws Exception {
		String var1 = "setVMMThreadDomainContextForCLI(AbstractAdminCommand)";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var1);
		}

		String var2 = null;
		var2 = (String) var0.getParameter("securityDomainName");
		if (isAdminAgentProfile()) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var1, "Invalid domain name=" + var2 + " at Admin Agent Node");
			}

			if (!"admin".equals(var2)) {
				throw new InvalidDomainNameException("DIRECTORY_NOT_FOUND",
						WIMMessageHelper.generateMsgParms("The domain configuration for " + var2), Level.SEVERE,
						CLASSNAME, var1);
			}
		}

		if (!isAdminAgentProfile()) {
			String var3 = var0.getConfigSession().toString();
			String var4 = getDomainPath(var2);
			if (!(new File(var4)).isDirectory()) {
				var4 = getDomainPathFromTemp(var2, var3);
				if (!(new File(var4)).isDirectory()) {
					validateDomainName(var2);
				}
			}

			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var1,
						"Calling setVMMThreadDomainContext to set the Domain Context");
			}

			setVMMThreadDomainContext(var2);
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var1);
		}

	}

	public static ClassLoader getVMMThreadDomainContextClassLoader() {
		String var0 = "getVMMThreadDomainContextClassLoader";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var0, vmmDomainMap.get());
		}

		ClassLoader var1 = null;
		if (isInVMMDomainThreadContext()) {
			Map var2 = (Map) vmmDomainMap.get();
			if (var2 != null) {
				var1 = (ClassLoader) var2.get("vmm_loaded_classloader");
			}
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var0, "Return context ClassLoader, " + var1);
		}

		return var1;
	}

	public static ClassLoader getWASExtClassLoader() {
		String var0 = "getWASExtClassLoader";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var0);
		}

		Object var1 = null;
		ExtClassLoader var2 = ExtClassLoader.getInstance();
		ClassLoader var3 = getContextClassLoader();
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, var0,
					"Current context CL:" + var3 + " : parent: " + var3.getParent());
		}

		var1 = var2;
		if (var2 == null) {
			var1 = var3;
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var0,
						"Context ClassLoader will be returned since WAS extension class loader is not available");
			}
		}

		if (var2 != null && !var3.equals(var2) && !isParentExtCL(var3, var2)) {
			var1 = ClassLoader.getSystemClassLoader();
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var0,
						"Returning System ClassLoader since context Classloader in not in hierarchy of ExtClassloader");
			}
		} else if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, var0, "Returning WAS extension class loader");
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var0, "Returning classLoader, " + var1);
		}

		return (ClassLoader) var1;
	}

	public static void switchThreadContextCLToWASExtCL(ClassLoader var0) {
		String var1 = "switchThreadContextCLToWASExtCL";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var1, new Object[]{var0, vmmCLSwitchMap.get()});
		}

		if (vmmCLSwitchMap.get() == null && var0 != getWASExtClassLoader()) {
			HashMap var2 = new HashMap();
			var2.put("callerThreadContextCl", var0);
			vmmCLSwitchMap.set(var2);
			Thread.currentThread().setContextClassLoader(getWASExtClassLoader());
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var1,
						"Thread context class loader switches to WAS extension class loader");
			}

			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.exiting(CLASSNAME, var1);
			}

		} else {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var1,
						"Thread context class loader already set to WAS extension class loader");
			}

		}
	}

	public static void switchBackToThreadContextCLFromWASExtCL() {
		String var0 = "switchBackToThreadContextCLFromWASExtCL";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var0, vmmCLSwitchMap.get());
		}

		Map var1 = (Map) vmmCLSwitchMap.get();
		if (var1 != null) {
			ClassLoader var2 = (ClassLoader) var1.get("callerThreadContextCl");
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var0,
						"Thread context class loader switches to original class loader from WAS extension class loader");
			}

			setContextClassLoader(var2);
			vmmCLSwitchMap.remove();
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.exiting(CLASSNAME, var0);
			}

		}
	}

	public static Object putPackageInEMFDomainRegistryFromVMM(String var0, EPackage var1) {
		String var2 = "putPackageInEMFDomainRegistryFromVMM";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var2);
		}

		Object var3 = null;

		try {
			setVMMThreadDomainContext();
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var2, "Switched to VMM context before EMF put operation");
			}

			var3 = putPackageInEMFRegistry(var0, var1);
		} finally {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var2, "Cleaned up VMM context after EMF put operation");
			}

			cleanUpVMMThreadDomainContext();
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var2);
		}

		return var3;
	}

	public static Object putPackageInEMFGlobalRegistryFromVMM(String var0, EPackage var1) {
		String var2 = "putPackageInEMFGlobalRegistryFromVMM(String,EPackage)";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var2, new Object[]{var0, var1, vmmDomainMap.get()});
		}

		Object var3 = null;
		String var4 = null;

		try {
			if (vmmDomainMap.get() != null) {
				Map var5 = (Map) vmmDomainMap.get();
				if (var5 != null) {
					var4 = (String) var5.get("vmmDomainName");
				}

				cleanUpVMMThreadDomainContext();
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, var2,
							"Cleaned up domain context before EMF global put operation");
				}
			}

			var3 = putPackageInEMFRegistry(var0, var1);
		} finally {
			if (var4 != null) {
				setVMMThreadDomainContext(var4);
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, var2,
							"Switched back to domain context " + var4 + " after EMF global put operation");
				}
			}

		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var2);
		}

		return var3;
	}

	public static Object putPackageInEMFRegistry(String var0, EPackage var1) {
		Object var2 = null;
		String var3 = "putPackageInEMFRegistry(String,EPackage)";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var3);
		}

		try {
			switchThreadContextCLToWASExtCL(getContextClassLoader());
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var3,
						"Thread context class loader switched to WAS extension class loader before EMF put operation");
			}

			var2 = Registry.INSTANCE.put(var0, var1);
		} finally {
			switchBackToThreadContextCLFromWASExtCL();
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var3,
						"Thread context class loader switched to original thread context class loader after EMF put operation");
			}

		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var3);
		}

		return var2;
	}

	public static boolean isAdminDomain() {
		String var0 = "isAdminDomain()";
		String var1 = getLocalDomainName();
		if (var1 != null) {
			return "admin".equals(var1);
		} else {
			SecurityConfigManager var2 = null;
			var2 = SecurityObjectLocator.getSecurityConfigManager();
			if (var2 != null) {
				var1 = var2.getActiveDomainName();
			}

			if (var1 == null) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, var0,
							"Setting the domain name to admin as no domain informaton available in VMM Thread Local or WAS SecurityConfigManager");
				}

				var1 = "admin";
			}

			return "admin".equals(var1) || isSetUseGlobalFedRepos(var1) || isSetUseGlobalSecuritySettings(var1);
		}
	}

	public static boolean isAdminAgentProfile() {
		return isAdminAgent() && AdminContext.peek() == null;
	}

	public static String getFileID(String var0) {
		String var1 = null;
		var1 = AdminContext.peek() + getDomainName() + var0;
		return var1;
	}

	public static Hashtable getProviderURL() throws Exception {
		String var0 = "getProviderURL";
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, var0);
		}

		Hashtable var1 = null;
		if (isAdminAgent() && AdminContext.peek() != null || DynamicReloadManager.isRunningOnJobManager()) {
			String var2 = AdminContext.peek();
			String var3 = null;
			String var4 = null;
			String var5 = null;
			var1 = new Hashtable();
			Map var6 = ProfileRegistryFactory.getRegistry().lookupProfile(var2);
			String var7 = (String) var6.get("profile.registry.cell.name");
			String var8 = (String) var6.get("profile.registry.node.name");
			String var9 = (String) var6.get("profile.registry.profile.root");
			String var10 = var9 + sFileSep + "config" + sFileSep + "cells" + sFileSep + var7 + sFileSep + "nodes"
					+ sFileSep + var8 + sFileSep + "serverindex.xml";
			File var11 = new File(var10);
			DocumentBuilderFactory var12 = DocumentBuilderFactory.newInstance();
			DocumentBuilder var13 = var12.newDocumentBuilder();
			Document var14 = var13.parse(var11);
			NodeList var15 = var14.getElementsByTagName("specialEndpoints");

			for (int var16 = 0; var16 < var15.getLength(); ++var16) {
				Node var17 = var15.item(var16);
				Element var18 = (Element) var17;
				String var19 = var18.getAttribute("endPointName").toString();
				if ("BOOTSTRAP_ADDRESS".equals(var19)) {
					Element var20 = (Element) var17;
					NodeList var21 = var20.getElementsByTagName("endPoint");
					Node var22 = var21.item(0);
					Element var23 = (Element) var22;
					var3 = var23.getAttribute("port").toString();
					var4 = var23.getAttribute("host");
					break;
				}
			}

			var5 = "corbaloc:iiop:" + var4 + ":" + var3;
			var1.put("java.naming.provider.url", var5);
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, var0, "Returning environment, " + var1);
		}

		return var1;
	}

	public static boolean isSetUseGlobalFedRepos(String var0) {
		String var1 = "isSetUseGlobalFedRepos(String sDomainName)";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var1, "domain name: " + var0);
		}

		if ("admin".equals(var0)) {
			return true;
		} else {
			if (isAdminAgent()) {
				Session var2 = new Session();
				ConfigService var3 = ConfigServiceFactory.getConfigService();
				if (var3 == null) {
					try {
						Properties var4 = new Properties();
						var4.setProperty("location", "local");
						var3 = ConfigServiceFactory.createConfigService(true, var4);
					} catch (Exception var13) {
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, var1,
									"Error in creating configService: " + var13.getMessage());
						}
					}
				}

				if (var3 != null) {
					try {
						ObjectName var16 = getActiveUserRegistryInAdminAgent(var0, var3, var2);
						if (var16 != null) {
							AttributeList var5 = var3.getAttributes(var2, var16, (String[]) null, false);
							List var6 = (List) ConfigServiceHelper.getAttributeValue(var5, "properties");
							if (var6.size() > 0) {
								new ArrayList(var6.size());
								Iterator var8 = var6.iterator();

								while (var8.hasNext()) {
									ObjectName var9 = (ObjectName) var8.next();
									String var10 = (String) var3.getAttribute(var2, var9, "name");
									if (var10 != null && var10.equalsIgnoreCase("useGlobalFederatedRepository")) {
										String var11 = (String) var3.getAttribute(var2, var9, "value");
										if (var11 != null && var11.equalsIgnoreCase("true")) {
											if (trcLogger.isLoggable(Level.FINER)) {
												trcLogger.exiting(CLASSNAME, var1,
														"Admin Agent: Global federated repository option is set for this domain");
											}

											return true;
										}
									}
								}
							}
						} else if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, var1,
									"activeUserRegistry is not set for this domain");
						}
					} catch (Exception var12) {
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, var1,
									"Failed to get domain registry attributes: " + var12.getMessage());
						}
					}
				}
			} else {
				boolean var14 = SecurityObjectLocator.getThreadLocal().pushResource(var0, "domain");
				UserRegistryConfig var15 = getActiveUserRegistryInStandAloneProf();
				if (var15 != null) {
					String var17 = var15.getProperty("useGlobalFederatedRepository");
					if (var14) {
						var14 = false;
						SecurityObjectLocator.getThreadLocal().popResource();
					}

					if (var17 != null && var17.equalsIgnoreCase("true")) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.exiting(CLASSNAME, var1,
									"Global federated repository option is set for this domain");
						}

						return true;
					}
				} else if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, var1, "UserRegistryConfig object is null");
				}

				if (var14) {
					SecurityObjectLocator.getThreadLocal().popResource();
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, var1, "Global federated repository option is not set for this domain");
			}

			return false;
		}
	}

	public static boolean isSetUseGlobalSecuritySettings(String var0) {
		String var1 = "isSetUseGlobalSecuritySettings(String sDomainName)";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var1, "domain name: " + var0);
		}

		if ("admin".equals(var0)) {
			return true;
		} else {
			if (isAdminAgent()) {
				Session var2 = new Session();
				ConfigService var3 = ConfigServiceFactory.getConfigService();
				if (var3 == null) {
					try {
						Properties var4 = new Properties();
						var4.setProperty("location", "local");
						var3 = ConfigServiceFactory.createConfigService(true, var4);
					} catch (Exception var5) {
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, var1,
									"Error in creating configService: " + var5.getMessage());
						}
					}
				}

				ObjectName var7 = getActiveUserRegistryInAdminAgent(var0, var3, var2);
				if (var7 == null) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, var1,
								"Adming agent - activeUserRegistry is not defined for this domain...It has Use global security settings option enabled");
					}

					return true;
				}
			} else {
				UserRegistryConfig var6 = getActiveUserRegistryInStandAloneProf();
				if (var6 == null) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, var1,
								"activeUserRegistry is not defined for this domain...It has Use global security settings option enabled");
					}

					return true;
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, var1, "Use global security settings option is not set for this domain");
			}

			return false;
		}
	}

	public static ObjectName getActiveUserRegistryInAdminAgent(String var0, ConfigService var1, Session var2) {
		String var3 = "getActiveUserRegistryInAdminAgent(String sDomainName, ConfigService configService, Session session)";

		try {
			ObjectName var4 = null;
			ObjectName[] var5 = var1.resolve(var2, "Policy=:SecurityDomain=");

			for (int var6 = 0; var6 < var5.length; ++var6) {
				ObjectName var7 = var5[var6];
				String var8 = (String) var1.getAttribute(var2, var7, "name");
				if (var8.equals(var0)) {
					ObjectName var9 = ConfigServiceHelper.createObjectName((ConfigDataId) null, "AppSecurity");
					var4 = var1.queryConfigObjects(var2, var7, var9, (QueryExp) null)[0];
				}
			}

			if (var4 != null) {
				ObjectName var11 = (ObjectName) var1.getAttribute(var2, var4, "activeUserRegistry");
				return var11;
			}

			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var3, "security object is null");
			}
		} catch (Exception var10) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var3,
						"Failed to get domain registry attributes: " + var10.getMessage());
			}
		}

		return null;
	}

	public static UserRegistryConfig getActiveUserRegistryInStandAloneProf() {
		String var0 = "getActiveUserRegistryInStandAloneProf(String sDomainName)";
		SecurityConfig var1 = SecurityObjectLocator.getSecurityConfig("AppSecurity");
		if (var1 != null) {
			UserRegistryConfig var2 = var1.getActiveUserRegistry(false);
			return var2;
		} else {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, var0, "appSecurity object is null");
			}

			return null;
		}
	}

	private static boolean isParentExtCL(ClassLoader var0, ClassLoader var1) {
		boolean var2 = false;

		for (ClassLoader var3 = null; var0.getParent() != null; var0 = var3) {
			var3 = var0.getParent();
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "isParentExtCL", "parentCL::" + var3);
			}

			if (var3.equals(var1)) {
				var2 = true;
			}
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "isParentExtCL", "isParentExtCL = " + var2);
		}

		return var2;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010_2011;
		CLASSNAME = DomainManagerUtils.class.getName();
		vmmDomainMap = new ThreadLocal();
		vmmCLSwitchMap = new ThreadLocal();
		sFileSep = File.separator;
		trcLogger = WIMLogger.getTraceLogger("SecurityDomain");
	}
}