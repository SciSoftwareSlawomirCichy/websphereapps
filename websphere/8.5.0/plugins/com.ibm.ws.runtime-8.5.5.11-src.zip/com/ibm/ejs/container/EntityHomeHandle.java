package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.J2EEName;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.util.Properties;
import javax.ejb.EJBHome;
import javax.ejb.HomeHandle;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.naming.NoInitialContextException;
import javax.rmi.PortableRemoteObject;

public class EntityHomeHandle implements HomeHandle, Serializable {
	private static final TraceComponent tc = Tr.register(EntityHomeHandle.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	String homeJNDIName;
	String homeInterface;
	transient EJBHome home;
	transient ClassLoader classLoader;
	final J2EEName j2eeName;
	final Properties initialContextProperties;
	private static final long serialVersionUID = -9080113035042415332L;

	EntityHomeHandle(BeanId id, String homeInterface, BeanMetaData bmd, Properties props) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EntityHomeHandle", new Object[]{id, homeInterface});
		}

		this.homeJNDIName = id.getJNDIName();
		this.homeInterface = homeInterface;
		this.j2eeName = id.getJ2EEName();
		this.initialContextProperties = props;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EntityHomeHandle");
		}

	}

	public EJBHome getEJBHome() throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBHome");
		}

		if (this.home == null) {
			NoSuchObjectException re;
			try {
				Class homeClass = null;

				try {
					ClassLoader cl = Thread.currentThread().getContextClassLoader();
					if (cl == null) {
						throw new ClassNotFoundException();
					}

					homeClass = cl.loadClass(this.homeInterface);
				} catch (ClassNotFoundException var8) {
					try {
						homeClass = Class.forName(this.homeInterface);
					} catch (ClassNotFoundException var7) {
						throw new ClassNotFoundException(this.homeInterface);
					}
				}

				re = null;

				InitialContext ctx;
				try {
					if (this.initialContextProperties == null) {
						ctx = new InitialContext();
					} else {
						try {
							ctx = new InitialContext(this.initialContextProperties);
							if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
								Tr.debug(tc,
										"Created an initial context with the initialContextProperties, providerURL = "
												+ (String) this.initialContextProperties.get("java.naming.provider.url")
												+ " INITIAL_CONTEXT_FACTORY = " + (String) this.initialContextProperties
														.get("java.naming.factory.initial"));
							}
						} catch (NamingException var5) {
							ctx = new InitialContext();
						}
					}

					this.home = (EJBHome) PortableRemoteObject.narrow(ctx.lookup(this.homeJNDIName), homeClass);
				} catch (NoInitialContextException var6) {
					Properties p = new Properties();
					p.put("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
					ctx = new InitialContext(p);
					this.home = (EJBHome) PortableRemoteObject.narrow(ctx.lookup(this.homeJNDIName), homeClass);
				}
			} catch (NamingException var9) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBHome", var9);
				}

				re = new NoSuchObjectException("Could not find home in JNDI");
				re.detail = var9;
				throw re;
			} catch (ClassNotFoundException var10) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBHome", var10);
				}

				throw new RemoteException("Could not load home interface", var10);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEJBHome");
		}

		return this.home;
	}

	private Method findFindByPrimaryKey(Class c) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "findFindByPrimaryKey", c);
		}

		Method[] methods = c.getMethods();

		for (int i = 0; i < methods.length; ++i) {
			if (methods[i].getName().equals("findByPrimaryKey")) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "findFindByPrimaryKey");
				}

				return methods[i];
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "findFindByPrimaryKey: method findByPrimaryKey not found!");
		}

		return null;
	}
}