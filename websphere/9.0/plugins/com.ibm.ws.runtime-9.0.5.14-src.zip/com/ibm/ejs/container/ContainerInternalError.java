package com.ibm.ejs.container;

public class ContainerInternalError extends ContainerException {
	private static final long serialVersionUID = -1736348221294252132L;

	public ContainerInternalError(Throwable ex) {
		super("", ex);
	}

	public ContainerInternalError() {
		super("");
	}
}