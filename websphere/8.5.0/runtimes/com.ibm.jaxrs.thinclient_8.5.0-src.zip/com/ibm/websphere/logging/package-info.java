package com.ibm.websphere.logging;

interface package-info {
}