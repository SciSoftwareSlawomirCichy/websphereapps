package com.ibm.ejs.container.finder;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJSHome;
import com.ibm.ejs.container.EJSWrapper;
import com.ibm.ejs.container.EJSWrapperCommon;
import com.ibm.ejs.container.EntityContainerTx;
import com.ibm.ejs.container.EntityHelperImpl;
import com.ibm.ejs.container.HomeRecord;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.cpi.CPIException;
import com.ibm.websphere.cpmi.PMBeanInfo;
import com.ibm.websphere.cpmi.PMFinderResults;
import com.ibm.websphere.csi.InconsistentAccessIntentException;
import com.ibm.ws.LocalTransaction.ContainerSynchronization;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.metadata.ComponentMetaData;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import com.ibm.ws.util.ThreadContextAccessor;
import java.io.Serializable;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.rmi.PortableRemoteObject;
import javax.transaction.Synchronization;

public final class FinderResultServerImpl implements FinderResultServer, Synchronization, ContainerSynchronization {
	private static final TraceComponent tc = Tr.register(FinderResultServerImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.finder.FinderResultServerImpl";
	private boolean ivIsRemote;
	private Vector<EJSWrapperCommon> ivWrappers;
	private int ivWrappersSize;
	private boolean wrappersHasAll;
	private transient PMBeanInfo beanInfo;
	private transient EntityContainerTx ivTxInfo;
	private transient EJSHome ivHome;
	private boolean isIterator;
	private Object ivPKeys;
	private Collection pKeysCollection;
	private boolean resourcesReleased;
	private int ivScope;
	private static final int Def_Collection_Scope = 1;
	private boolean ivIsCompleting = true;
	private boolean ivHasInheritance;
	private boolean ivHasMethodLevelAI;
	private AccessIntent ivAccessIntent = null;
	private int ivLoadIntent;
	private PMFinderResults ivPMFinderResults;
	private ClassLoader ivContextClassLoader = null;
	private ComponentMetaDataAccessorImpl ivCmdAccessor = null;
	private ComponentMetaData ivComponentMetaData = null;
	private static final ThreadContextAccessor svThreadContextAccessor = (ThreadContextAccessor) AccessController
			.doPrivileged(ThreadContextAccessor.getPrivilegedAction());
	private static final String[] LoadIntentStrings = new String[]{"LOAD_IMMEDIATE", "LOAD_DEFERRED", "LOAD_NEVER"};

	public FinderResultServerImpl(Collection pKeys, EJSHome home, EntityContainerTx txInfo, boolean isRemote,
			AccessIntent accessIntent) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init(Collection,..)>", new Object[]{home, txInfo, isRemote});
		}

		this.pKeysCollection = pKeys;
		this.init(home, txInfo, isRemote);
		this.isIterator = true;
		this.ivPKeys = pKeys.iterator();
		this.ivAccessIntent = accessIntent;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init(Collection,..)>");
		}

	}

	public FinderResultServerImpl(Enumeration pKeys, EJSHome home, EntityContainerTx txInfo, boolean isRemote,
			AccessIntent accessIntent) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init(Enumeration,..)>", new Object[]{home, txInfo, isRemote});
		}

		this.init(home, txInfo, isRemote);
		this.isIterator = false;
		this.ivPKeys = pKeys;
		this.ivAccessIntent = accessIntent;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init(Enumeration,..)>");
		}

	}

	private void init(EJSHome home, EntityContainerTx txInfo, boolean isRemote) {
		this.ivIsRemote = isRemote;
		this.ivWrappers = new Vector(10, 10);
		this.ivWrappersSize = 0;
		this.ivHome = home;
		this.beanInfo = EntityHelperImpl.getPMHomeInfo(home).getPMBeanInfo();
		this.ivHasInheritance = home.hasInheritance();
		this.ivHasMethodLevelAI = home.hasMethodLevelAccessIntentSet();
		this.ivTxInfo = txInfo;
		this.ivScope = 1;
		this.resourcesReleased = false;
		this.wrappersHasAll = false;
		if (this.beanInfo != null && this.pKeysCollection != null && this.pKeysCollection instanceof PMFinderResults) {
			this.ivPMFinderResults = (PMFinderResults) this.pKeysCollection;
		}

		if (txInfo.beganInThisScope()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "LoadIntent : beganInThisScope = true");
			}

			if (this.beanInfo != null && this.ivHasInheritance) {
				this.ivLoadIntent = 1;
			} else {
				this.ivLoadIntent = 2;
			}
		} else if (this.beanInfo != null && this.ivPMFinderResults != null && this.ivScope == 1
				&& txInfo.isTransactionGlobal()) {
			this.ivLoadIntent = 0;
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "beanInfo = " + this.beanInfo);
				Tr.debug(tc, "pKeysCollection = " + this.pKeysCollection);
				Tr.debug(tc, "ivPMFinderResults = " + this.ivPMFinderResults);
				Tr.debug(tc, "scope = " + this.ivScope);
				Tr.debug(tc, "global = " + txInfo.isTransactionGlobal());
			}

			this.ivLoadIntent = 1;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
		}

	}

	private void addWrapper(Object pKey) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "addWrapper (" + pKey + ")");
		}

		EJSWrapperCommon wCommon = null;
		if (pKey != null) {
			EJSHome targetHome = this.ivHome;
			HomeRecord targetHomeRecord = null;

			try {
				if (this.beanInfo != null && this.ivHasInheritance) {
					targetHomeRecord = (HomeRecord) this.beanInfo.getHomeForKey(pKey, this.ivTxInfo);
					targetHome = targetHomeRecord.getHomeAndInitialize();
				}

				BeanId beanId = new BeanId(targetHome, (Serializable) pKey);
				if (this.ivLoadIntent != 2 && this.ivAccessIntent != null && this.ivHasMethodLevelAI) {
					this.ivTxInfo.cacheAccessIntent(beanId, this.ivAccessIntent);
				}

				if (this.ivLoadIntent == 0) {
					try {
						ContainerTx tx = EntityHelperImpl.toContainerTx(this.ivTxInfo);
						wCommon = targetHome.activateBean(beanId, tx);
					} catch (Throwable var8) {
						FFDCFilter.processException(var8,
								"com.ibm.ejs.container.finder.FinderResultServerImpl.addWrapper", "193", this);
						Tr.warning(tc, "IGNORING_UNEXPECTED_EXCEPTION_CNTR0033E", var8);
						this.ivLoadIntent = 1;
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Activate Failure :  LoadIntent = " + LoadIntentStrings[this.ivLoadIntent],
									var8);
						}

						wCommon = targetHome.getWrapper(beanId);
					}
				} else {
					wCommon = targetHome.getWrapper(beanId);
				}
			} catch (RemoteException var9) {
				FFDCFilter.processException(var9, "com.ibm.ejs.container.finder.FinderResultServerImpl.addWrapper",
						"193", this);
				Tr.error(tc, "FAILED_TO_GET_WRAPPER_CNTR0056W", new Object[]{var9});
				throw new EJBException(var9.getMessage());
			} catch (InconsistentAccessIntentException var10) {
				FFDCFilter.processException(var10, "com.ibm.ejs.container.finder.FinderResultServerImpl.addWrapper",
						"242", this);
				Tr.error(tc, "FAILED_TO_GET_WRAPPER_CNTR0056W", new Object[]{var10});
				throw new EJBException(var10.getMessage());
			}
		}

		this.ivWrappers.addElement(wCommon);
		++this.ivWrappersSize;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "addWrapper : " + wCommon);
		}

	}

	public int size() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "size");
		}

		int rtnSize;
		if (this.wrappersHasAll) {
			rtnSize = this.ivWrappersSize;
		} else {
			if (this.ivLoadIntent != 2) {
				this.ivLoadIntent = 1;
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Size() Greedy Collection : LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
			}

			if (this.ivPMFinderResults != null) {
				this.ivPMFinderResults.beginResultsProcessing(this.ivLoadIntent);
			}

			rtnSize = this.isIterator ? this.pKeysCollection.size() : -1;
			if (this.ivPMFinderResults != null) {
				this.ivPMFinderResults.endResultsProcessing();
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "size : " + rtnSize);
		}

		return rtnSize;
	}

	Vector getWrappers() {
		return this.ivWrappers;
	}

	private Object getWrapperBase(int index) {
		while (true) {
			if (index >= this.ivWrappersSize) {
				Object pKey = null;
				if (!this.hasMorePrimaryKey()) {
					this.pKeysCollection = null;
					this.ivPKeys = null;
					this.wrappersHasAll = true;
					if (this.ivPMFinderResults != null) {
						this.ivPMFinderResults.endResultsProcessing();
						this.ivPMFinderResults = null;
					}

					return null;
				}

				try {
					pKey = this.nextPrimaryKey();
				} catch (NoSuchElementException var6) {
					this.pKeysCollection = null;
					this.ivPKeys = null;
					this.wrappersHasAll = true;
					if (this.ivPMFinderResults != null) {
						this.ivPMFinderResults.endResultsProcessing();
						this.ivPMFinderResults = null;
					}

					return null;
				}

				this.addWrapper(pKey);
				if (this.ivWrappersSize != Integer.MAX_VALUE) {
					continue;
				}

				Tr.warning(tc, "FINDER_RESULT_EXCEEDED_LIMITS_CNTR0041W");
			}

			EJSWrapperCommon wCommon = (EJSWrapperCommon) this.ivWrappers.elementAt(index);
			Object wrapper = null;
			if (wCommon != null) {
				if (this.ivIsRemote) {
					EJSWrapper r = wCommon.getRemoteWrapper();

					try {
						wrapper = PortableRemoteObject.toStub(r);
					} catch (NoSuchObjectException var7) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "PortableRemoteObject.toStub() call failed. Not excepting such a failure!");
						}

						wrapper = r;
						FFDCFilter.processException(var7,
								"com.ibm.ejs.container.finder.FinderResultServerImpl.getWrapperBase", "589", this);
					}
				} else {
					wrapper = wCommon.getLocalObject();
				}
			}

			return wrapper;
		}
	}

	protected Object getNextWrapper(int index) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getNextWrapper (" + index + ")");
		}

		Object wrapper = null;
		Object oldClassLoader = null;
		boolean popContextsRequired = false;
		if (this.ivTxInfo == null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Tx is null. 'noLocalCopies' is likely to be set.");
			}

			throw new CollectionCannotBeFurtherAccessedException();
		} else {
			if (this.ivPMFinderResults != null) {
				if (this.ivComponentMetaData != null) {
					this.checkCurrentTxn();
				}

				if (this.ivLoadIntent == 0) {
					if (this.ivComponentMetaData == null) {
						this.saveContexts();
					} else {
						oldClassLoader = this.pushContexts();
						popContextsRequired = true;
					}
				}

				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
				}

				this.ivPMFinderResults.beginResultsProcessing(this.ivLoadIntent);
			}

			try {
				wrapper = this.getWrapperBase(index);
			} finally {
				if (this.ivPMFinderResults != null) {
					this.ivPMFinderResults.endResultsProcessing();
				}

				if (popContextsRequired) {
					this.popContexts(oldClassLoader);
				}

			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getNextWrapper", wrapper);
			}

			return wrapper;
		}
	}

	public Vector getNextWrapperCollection(int start, int count) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getNextWrapperCollection (" + start + ", " + count + ")");
		}

		Vector<Object> result = null;
		Object oldClassLoader = null;
		boolean popContextsRequired = false;
		if (this.ivTxInfo == null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Tx is null. 'noLocalCopies' is likely to be set.");
			}

			throw new RemoteException("CollectionCannotBeFurtherAccessedException");
		} else {
			if (this.ivPMFinderResults != null) {
				if (this.ivComponentMetaData != null) {
					this.checkCurrentTxn();
				}

				if (this.ivLoadIntent == 0) {
					if (this.ivComponentMetaData == null) {
						this.saveContexts();
					} else {
						oldClassLoader = this.pushContexts();
						popContextsRequired = true;
					}
				}

				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
				}

				this.ivPMFinderResults.beginResultsProcessing(this.ivLoadIntent);
			}

			try {
				result = new Vector(count);
				long endNext = (long) start + (long) count;

				for (int lastIndex = start; (long) lastIndex < endNext; ++lastIndex) {
					Object o = this.getWrapperBase(lastIndex);
					if (this.wrappersHasAll) {
						break;
					}

					result.add(o);
				}
			} finally {
				if (this.ivPMFinderResults != null) {
					this.ivPMFinderResults.endResultsProcessing();
				}

				if (popContextsRequired) {
					this.popContexts(oldClassLoader);
				}

			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getNextWrapperCollection : " + result.size());
			}

			return result;
		}
	}

	Vector getAllWrapperCollection() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAllWrapperCollection");
		}

		if (this.ivLoadIntent != 2) {
			this.ivLoadIntent = 1;
		}

		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "Greedy Collection : LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
		}

		if (this.ivPMFinderResults != null) {
			this.ivPMFinderResults.beginResultsProcessing(this.ivLoadIntent);
		}

		Vector<Object> result = new Vector(10, 10);
		int i = 0;

		for (Object nextWrapper = null; (nextWrapper = this.getWrapperBase(i)) != null || !this.wrappersHasAll; ++i) {
			result.addElement(nextWrapper);
		}

		if (this.ivPMFinderResults != null) {
			this.ivPMFinderResults.endResultsProcessing();
		}

		this.resourcesReleased = true;
		if (this.ivIsRemote) {
			this.ivWrappers = null;
			this.ivWrappersSize = 0;
		}

		this.wrappersHasAll = true;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getAllWrapperCollection : " + result.size());
		}

		return result;
	}

	protected boolean setScope(int scope) {
		this.ivScope = scope;
		boolean rc = false;
		if (scope != 1) {
			if (this.ivLoadIntent != 2) {
				this.ivLoadIntent = 1;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Non-Tx Scope Collection : LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
			}

			if (scope == 2 && this.ivTxInfo.getContainerAS() != null) {
				try {
					this.ivTxInfo.getContainerAS().registerSynchronization(this);
					rc = true;
				} catch (CPIException var4) {
					FFDCFilter.processException(var4, "com.ibm.ejs.container.finder.FinderResultServerImpl.setScope",
							"456", this);
				}
			}
		}

		return rc;
	}

	public boolean hasResourcesReleased() {
		return this.resourcesReleased;
	}

	private boolean hasMorePrimaryKey() {
		if (this.ivPKeys == null) {
			return false;
		} else {
			return this.ivWrappersSize < Integer.MAX_VALUE && this.isIterator
					? ((Iterator) this.ivPKeys).hasNext()
					: ((Enumeration) this.ivPKeys).hasMoreElements();
		}
	}

	private Object nextPrimaryKey() {
		if (this.ivPKeys == null) {
			throw new NoSuchElementException();
		} else {
			return this.isIterator ? ((Iterator) this.ivPKeys).next() : ((Enumeration) this.ivPKeys).nextElement();
		}
	}

	void exportFinderResultServerImpleResources() throws FinderException, RemoteException {
		if (this.ivIsRemote) {
			try {
				PortableRemoteObject.exportObject(this);
			} catch (NoSuchObjectException var2) {
				FFDCFilter.processException(var2,
						"com.ibm.ejs.container.finder.FinderResultServerImpl.exportFinderResultServerImpleResources",
						"486");
				throw new FinderException(var2.toString());
			}
		}

	}

	void releaseFinderResultServerImplResources() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "releaseFinderResultServerImplResources");
		}

		if (!this.resourcesReleased) {
			try {
				if (this.ivIsRemote) {
					PortableRemoteObject.unexportObject(this);
				}
			} catch (NoSuchObjectException var3) {
				FFDCFilter.processException(var3,
						"com.ibm.ejs.container.finder.FinderResultServerImpl.releaseFinderResultServerImplResources",
						"478", this);
			}

			this.resourcesReleased = true;
		} else if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "resources already released");
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "releaseFinderResultServerImplResources");
		}

	}

	public boolean exhaustedCollection() {
		return this.wrappersHasAll;
	}

	boolean validLocalAccessScope() {
		return this.wrappersHasAll || !this.resourcesReleased;
	}

	public void beforeCompletion() {
		if (this.ivLoadIntent != 2) {
			this.ivLoadIntent = 1;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "beforeCompletion : Remote = " + this.ivIsRemote + ", Scope = " + this.ivScope
					+ ", LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
		}

	}

	public void afterCompletion(int status) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc,
					"afterCompletion (" + status + ") : Remote = " + this.ivIsRemote + ", Scope = " + this.ivScope);
		}

		switch (this.ivScope) {
			case 1 :
				if (this.ivIsCompleting) {
					this.releaseFinderResultServerImplResources();
				}
			case 2 :
			default :
				this.destroyContexts();
				this.ivTxInfo = null;
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "afterCompletion");
				}

		}
	}

	public void setCompleting(boolean isCompleting) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isCompleting= " + isCompleting);
		}

		this.ivIsCompleting = isCompleting;
	}

	public AccessIntent getCollectionAccessIntent() {
		return this.ivAccessIntent;
	}

	public void saveLocalCollectionContexts() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn) {
			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "saveLocalCollectionContexts");
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
			}
		}

		if (this.ivPMFinderResults != null && this.ivLoadIntent == 0) {
			this.saveContexts();
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "saveLocalCollectionContexts");
		}

	}

	private void saveContexts() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "saveContexts : saving contexts");
		}

		this.ivContextClassLoader = svThreadContextAccessor
				.getContextClassLoaderForUnprivileged(Thread.currentThread());
		this.ivCmdAccessor = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor();
		this.ivComponentMetaData = this.ivCmdAccessor.getComponentMetaData();
	}

	private void destroyContexts() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "destroyContexts : resetting contexts");
		}

		this.ivContextClassLoader = null;
		this.ivCmdAccessor = null;
		this.ivComponentMetaData = null;
	}

	private Object pushContexts() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "pushContexts : pushing contexts");
		}

		Object oldClassLoader = svThreadContextAccessor
				.pushContextClassLoaderForUnprivileged(this.ivContextClassLoader);
		this.ivCmdAccessor.beginContext(this.ivComponentMetaData);
		return oldClassLoader;
	}

	private void popContexts(Object oldClassLoader) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "popContexts : popping contexts");
		}

		this.ivCmdAccessor.endContext();
		svThreadContextAccessor.popContextClassLoaderForUnprivileged(oldClassLoader);
	}

	private void checkCurrentTxn() {
		try {
			if (this.ivTxInfo != this.ivTxInfo.getCurrentTx()) {
				if (this.ivLoadIntent != 2) {
					this.ivLoadIntent = 1;
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Wrong Tx Context : LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
				}
			}
		} catch (Throwable var2) {
			FFDCFilter.processException(var2, "com.ibm.ejs.container.finder.FinderResultServerImpl.checkCurrentTxn",
					"1293", this);
			if (this.ivLoadIntent != 2) {
				this.ivLoadIntent = 1;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Tx Not Active : LoadIntent = " + LoadIntentStrings[this.ivLoadIntent]);
			}
		}

	}
}