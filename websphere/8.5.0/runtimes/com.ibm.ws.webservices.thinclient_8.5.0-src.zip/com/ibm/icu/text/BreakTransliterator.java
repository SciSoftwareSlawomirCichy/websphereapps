package com.ibm.icu.text;

import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.BreakTransliterator.ReplaceableCharacterIterator;
import com.ibm.icu.text.Transliterator.Position;
import com.ibm.icu.util.ULocale;

final class BreakTransliterator extends Transliterator {
	private BreakIterator bi;
	private String insertion;
	private int[] boundaries;
	private int boundaryCount;
	static final int LETTER_OR_MARK_MASK = 510;

	public BreakTransliterator(String ID, UnicodeFilter filter, BreakIterator bi, String insertion) {
		super(ID, filter);
		this.boundaries = new int[50];
		this.boundaryCount = 0;
		this.bi = bi;
		this.insertion = insertion;
	}

	public BreakTransliterator(String ID, UnicodeFilter filter) {
		this(ID, filter, (BreakIterator) null, " ");
	}

	public String getInsertion() {
		return this.insertion;
	}

	public void setInsertion(String insertion) {
		this.insertion = insertion;
	}

	public BreakIterator getBreakIterator() {
		if (this.bi == null) {
			this.bi = BreakIterator.getWordInstance(new ULocale("th_TH"));
		}

		return this.bi;
	}

	public void setBreakIterator(BreakIterator bi) {
		this.bi = bi;
	}

	protected void handleTransliterate(Replaceable text, Position pos, boolean incremental) {
		this.boundaryCount = 0;
		int boundary = false;
		this.getBreakIterator();
		this.bi.setText(new ReplaceableCharacterIterator(text, pos.start, pos.limit, pos.start));

		int cp;
		int type;
		int boundary;
		for (boundary = this.bi.first(); boundary != -1 && boundary < pos.limit; boundary = this.bi.next()) {
			if (boundary != 0) {
				cp = UTF16.charAt(text, boundary - 1);
				type = UCharacter.getType(cp);
				if ((1 << type & 510) != 0) {
					cp = UTF16.charAt(text, boundary);
					type = UCharacter.getType(cp);
					if ((1 << type & 510) != 0) {
						if (this.boundaryCount >= this.boundaries.length) {
							int[] temp = new int[this.boundaries.length * 2];
							System.arraycopy(this.boundaries, 0, temp, 0, this.boundaries.length);
							this.boundaries = temp;
						}

						this.boundaries[this.boundaryCount++] = boundary;
					}
				}
			}
		}

		cp = 0;
		type = 0;
		if (this.boundaryCount != 0) {
			cp = this.boundaryCount * this.insertion.length();
			type = this.boundaries[this.boundaryCount - 1];

			while (this.boundaryCount > 0) {
				boundary = this.boundaries[--this.boundaryCount];
				text.replace(boundary, boundary, this.insertion);
			}
		}

		pos.contextLimit += cp;
		pos.limit += cp;
		pos.start = incremental ? type + cp : pos.limit;
	}

	static void register() {
		Transliterator trans = new BreakTransliterator("Any-BreakInternal", (UnicodeFilter) null);
		Transliterator.registerInstance(trans, false);
	}
}