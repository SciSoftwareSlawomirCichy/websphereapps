package com.ibm.ws.wim.configmodel.util;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceFactoryImpl;

public class ConfigmodelResourceFactoryImpl extends XMLResourceFactoryImpl {
	protected ExtendedMetaData extendedMetaData;

	public ConfigmodelResourceFactoryImpl() {
		this.extendedMetaData = ExtendedMetaData.INSTANCE;
	}

	public Resource createResource(URI var1) {
		ConfigmodelResourceImpl var2 = new ConfigmodelResourceImpl(var1);
		var2.getDefaultSaveOptions().put("EXTENDED_META_DATA", this.extendedMetaData);
		var2.getDefaultLoadOptions().put("EXTENDED_META_DATA", this.extendedMetaData);
		var2.getDefaultSaveOptions().put("SCHEMA_LOCATION", Boolean.TRUE);
		var2.getDefaultSaveOptions().put("USE_ENCODED_ATTRIBUTE_STYLE", Boolean.TRUE);
		var2.getDefaultLoadOptions().put("USE_LEXICAL_HANDLER", Boolean.TRUE);
		return var2;
	}
}