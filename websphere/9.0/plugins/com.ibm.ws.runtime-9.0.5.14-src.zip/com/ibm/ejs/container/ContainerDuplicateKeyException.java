package com.ibm.ejs.container;

public class ContainerDuplicateKeyException extends ContainerException {
	private static final long serialVersionUID = 2461664244955831159L;

	public ContainerDuplicateKeyException(String s) {
		super(s);
	}

	public ContainerDuplicateKeyException() {
	}
}