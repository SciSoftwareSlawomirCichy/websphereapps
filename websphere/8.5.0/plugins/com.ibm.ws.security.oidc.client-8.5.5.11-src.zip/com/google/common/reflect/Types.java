package com.google.common.reflect;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicates;
import com.google.common.collect.Iterables;
import com.google.common.reflect.Types.1;
import com.google.common.reflect.Types.ClassOwnership;
import com.google.common.reflect.Types.JavaVersion;
import com.google.common.reflect.Types.ParameterizedTypeImpl;
import com.google.common.reflect.Types.TypeVariableImpl;
import com.google.common.reflect.Types.WildcardTypeImpl;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Collection;
import javax.annotation.Nullable;

final class Types {
	private static final Function<Type, String> TYPE_TO_STRING = new 1();
	private static final Joiner COMMA_JOINER = Joiner.on(", ").useForNull("null");

	static Type newArrayType(Type componentType) {
		if (componentType instanceof WildcardType) {
			WildcardType wildcard = (WildcardType) componentType;
			Type[] lowerBounds = wildcard.getLowerBounds();
			Preconditions.checkArgument(lowerBounds.length <= 1, "Wildcard cannot have more than one lower bounds.");
			if (lowerBounds.length == 1) {
				return supertypeOf(newArrayType(lowerBounds[0]));
			} else {
				Type[] upperBounds = wildcard.getUpperBounds();
				Preconditions.checkArgument(upperBounds.length == 1, "Wildcard should have only one upper bound.");
				return subtypeOf(newArrayType(upperBounds[0]));
			}
		} else {
			return JavaVersion.CURRENT.newArrayType(componentType);
		}
	}

	static ParameterizedType newParameterizedTypeWithOwner(@Nullable Type ownerType, Class<?> rawType,
			Type... arguments) {
		if (ownerType == null) {
			return newParameterizedType(rawType, arguments);
		} else {
			Preconditions.checkNotNull(arguments);
			Preconditions.checkArgument(rawType.getEnclosingClass() != null, "Owner type for unenclosed %s",
					new Object[]{rawType});
			return new ParameterizedTypeImpl(ownerType, rawType, arguments);
		}
	}

	static ParameterizedType newParameterizedType(Class<?> rawType, Type... arguments) {
		return new ParameterizedTypeImpl(ClassOwnership.JVM_BEHAVIOR.getOwnerType(rawType), rawType, arguments);
	}

	static <D extends GenericDeclaration> TypeVariable<D> newTypeVariable(D declaration, String name, Type... bounds) {
		return new TypeVariableImpl(declaration, name, bounds.length == 0 ? new Type[]{Object.class} : bounds);
	}

	@VisibleForTesting
	static WildcardType subtypeOf(Type upperBound) {
		return new WildcardTypeImpl(new Type[0], new Type[]{upperBound});
	}

	@VisibleForTesting
	static WildcardType supertypeOf(Type lowerBound) {
		return new WildcardTypeImpl(new Type[]{lowerBound}, new Type[]{Object.class});
	}

	static String toString(Type type) {
		return type instanceof Class ? ((Class) type).getName() : type.toString();
	}

	@Nullable
	static Type getComponentType(Type type) {
		Preconditions.checkNotNull(type);
		if (type instanceof Class) {
			return ((Class) type).getComponentType();
		} else if (type instanceof GenericArrayType) {
			return ((GenericArrayType) type).getGenericComponentType();
		} else if (type instanceof WildcardType) {
			return subtypeOfComponentType(((WildcardType) type).getUpperBounds());
		} else {
			return type instanceof TypeVariable ? subtypeOfComponentType(((TypeVariable) type).getBounds()) : null;
		}
	}

	@Nullable
	private static Type subtypeOfComponentType(Type[] bounds) {
		Type[] arr$ = bounds;
		int len$ = bounds.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Type bound = arr$[i$];
			Type componentType = getComponentType(bound);
			if (componentType != null) {
				if (componentType instanceof Class) {
					Class<?> componentClass = (Class) componentType;
					if (componentClass.isPrimitive()) {
						return componentClass;
					}
				}

				return subtypeOf(componentType);
			}
		}

		return null;
	}

	static boolean containsTypeVariable(@Nullable Type type) {
		if (type instanceof TypeVariable) {
			return true;
		} else if (type instanceof GenericArrayType) {
			return containsTypeVariable(((GenericArrayType) type).getGenericComponentType());
		} else if (type instanceof ParameterizedType) {
			return containsTypeVariable(((ParameterizedType) type).getActualTypeArguments());
		} else if (!(type instanceof WildcardType)) {
			return false;
		} else {
			WildcardType wildcard = (WildcardType) type;
			return containsTypeVariable(wildcard.getUpperBounds()) || containsTypeVariable(wildcard.getLowerBounds());
		}
	}

	private static boolean containsTypeVariable(Type[] types) {
		Type[] arr$ = types;
		int len$ = types.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Type paramType = arr$[i$];
			if (containsTypeVariable(paramType)) {
				return true;
			}
		}

		return false;
	}

	private static Type[] toArray(Collection<Type> types) {
		return (Type[]) types.toArray(new Type[types.size()]);
	}

	private static Iterable<Type> filterUpperBounds(Iterable<Type> bounds) {
		return Iterables.filter(bounds, Predicates.not(Predicates.equalTo(Object.class)));
	}

	private static void disallowPrimitiveType(Type[] types, String usedAs) {
		Type[] arr$ = types;
		int len$ = types.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Type type = arr$[i$];
			if (type instanceof Class) {
				Class<?> cls = (Class) type;
				Preconditions.checkArgument(!cls.isPrimitive(), "Primitive type '%s' used as %s",
						new Object[]{cls, usedAs});
			}
		}

	}

	static Class<?> getArrayClass(Class<?> componentType) {
		return Array.newInstance(componentType, 0).getClass();
	}
}