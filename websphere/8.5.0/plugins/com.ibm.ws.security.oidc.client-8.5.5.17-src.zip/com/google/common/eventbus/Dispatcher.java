package com.google.common.eventbus;

import com.google.common.base.Preconditions;
import com.google.common.collect.Queues;
import com.google.common.eventbus.Dispatcher.1;
import com.google.common.eventbus.Dispatcher.LegacyAsyncDispatcher.EventWithSubscriber;
import com.google.common.eventbus.Dispatcher.PerThreadQueuedDispatcher.2;
import com.google.common.eventbus.Dispatcher.PerThreadQueuedDispatcher.Event;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

abstract class Dispatcher {
	static Dispatcher perThreadDispatchQueue() {
      return new Dispatcher.PerThreadQueuedDispatcher((1)null);
   }

	static Dispatcher legacyAsync() {
      return new Dispatcher.LegacyAsyncDispatcher((1)null);
   }

	static Dispatcher immediate() {
		return Dispatcher.ImmediateDispatcher.INSTANCE;
	}

	abstract void dispatch(Object var1, Iterator<Subscriber> var2);

	private static final class ImmediateDispatcher extends Dispatcher {
		private static final Dispatcher.ImmediateDispatcher INSTANCE = new Dispatcher.ImmediateDispatcher();

		void dispatch(Object event, Iterator<Subscriber> subscribers) {
			Preconditions.checkNotNull(event);

			while (subscribers.hasNext()) {
				((Subscriber) subscribers.next()).dispatchEvent(event);
			}

		}
	}

	private static final class LegacyAsyncDispatcher extends Dispatcher {
		private final ConcurrentLinkedQueue<EventWithSubscriber> queue;

		private LegacyAsyncDispatcher() {
			this.queue = Queues.newConcurrentLinkedQueue();
		}

		void dispatch(Object event, Iterator<Subscriber> subscribers) {
         Preconditions.checkNotNull(event);

         while(subscribers.hasNext()) {
            this.queue.add(new EventWithSubscriber(event, (Subscriber)subscribers.next(), (1)null));
         }

         EventWithSubscriber e;
         while((e = (EventWithSubscriber)this.queue.poll()) != null) {
            EventWithSubscriber.access$800(e).dispatchEvent(EventWithSubscriber.access$700(e));
         }

      }
	}

	private static final class PerThreadQueuedDispatcher extends Dispatcher {
		private final ThreadLocal<Queue<Event>> queue;
		private final ThreadLocal<Boolean> dispatching;

		private PerThreadQueuedDispatcher() {
         this.queue = new com.google.common.eventbus.Dispatcher.PerThreadQueuedDispatcher.1(this);
         this.dispatching = new 2(this);
      }

		void dispatch(Object event, Iterator<Subscriber> subscribers) {
         Preconditions.checkNotNull(event);
         Preconditions.checkNotNull(subscribers);
         Queue<Event> queueForThread = (Queue)this.queue.get();
         queueForThread.offer(new Event(event, subscribers, (1)null));
         if (!(Boolean)this.dispatching.get()) {
            this.dispatching.set(true);

            Event nextEvent;
            try {
               while((nextEvent = (Event)queueForThread.poll()) != null) {
                  while(Event.access$400(nextEvent).hasNext()) {
                     ((Subscriber)Event.access$400(nextEvent).next()).dispatchEvent(Event.access$500(nextEvent));
                  }
               }
            } finally {
               this.dispatching.remove();
               this.queue.remove();
            }
         }

      }
	}
}