package com.ibm.ejs.container.util;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import javax.naming.RefAddr;

public class EJBInterfaceInfoRefAddr extends RefAddr {
	private static final long serialVersionUID = -1172693812040793208L;
	private static final String CLASS_NAME = EJBInterfaceInfoRefAddr.class.getName();
	private static final TraceComponent tc;
	static final String ADDR_TYPE = "EJBInterfaceInfo";
	private final EJBInterfaceInfo ivInfo;

	public EJBInterfaceInfoRefAddr(EJBInterfaceInfo info) {
		super("EJBInterfaceInfo");
		this.ivInfo = info;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "EJBInterfaceInfoRefAddr.<init> called: ",
					new String[]{"Home J2EE Name      = " + this.ivInfo.getJ2eeName(),
							"Interface Name      = " + this.ivInfo.getInterfaceName(),
							"Home?               = " + this.ivInfo.isHomeInterfaceName(),
							"Local?              = " + this.ivInfo.isLocalInterfaceName()});
		}

	}

	public Object getContent() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "EJBInterfaceInfoRefAddr.getContent() is returning: ",
					new String[]{"Home J2EE Name      = " + this.ivInfo.getJ2eeName(),
							"Interface Name      = " + this.ivInfo.getInterfaceName(),
							"Home?               = " + this.ivInfo.isHomeInterfaceName(),
							"Local?              = " + this.ivInfo.isLocalInterfaceName()});
		}

		return this.ivInfo;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}