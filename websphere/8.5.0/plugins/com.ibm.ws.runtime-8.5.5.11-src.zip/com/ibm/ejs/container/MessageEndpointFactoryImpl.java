package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.mdb.BaseMessageEndpointFactory;
import com.ibm.ws.ejbcontainer.mdb.MessageEndpointHandler;
import com.ibm.ws.j2c.MessageEndpointFactory;
import com.ibm.ws.j2c.RALifeCycleManager;
import com.ibm.ws.j2c.RALifeCycleManagerFactory;
import com.ibm.ws.j2c.MessageEndpointFactory.JCAVersion;
import java.lang.reflect.Constructor;
import java.rmi.RemoteException;
import javax.resource.ResourceException;

public class MessageEndpointFactoryImpl extends BaseMessageEndpointFactory implements MessageEndpointFactory {
	private static final long serialVersionUID = 6055819285757596987L;
	private static final String CLASS_NAME = MessageEndpointFactoryImpl.class.getName();
	private static final TraceComponent tc;
	private String ivDeactivationKey = null;

	public MessageEndpointFactoryImpl() throws RemoteException {
	}

	public void activateEndpoint() throws ResourceException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "MEF.activateEndpoint for enterprise class " + this.beanMetaData.enterpriseBeanName);
		}

		ResourceException ex = null;
		RALifeCycleManager r = RALifeCycleManagerFactory.getInstance();
		String deactivationKey = null;
		Thread currentThread = Thread.currentThread();

		Constructor var6;
		try {
			Constructor var5 = this.ivProxyCTOR;
			synchronized (this.ivProxyCTOR) {
				if (this.ivState == 0) {
					this.ivState = 1;
					this.ivActivatingThread = currentThread;
				} else if (this.ivState == 2) {
					r = null;
				} else {
					r = null;
					ex = new ResourceException("can not activate until deactivate completes");
				}
			}

			if (r != null) {
				deactivationKey = r.activateEndpoint(this.beanMetaData.ivActivationSpecJndiName, this,
						this.beanMetaData.ivActivationConfig, this.beanMetaData.j2eeName,
						this.beanMetaData.ivActivationSpecAuthAlias, this.beanMetaData.ivMessageDestinationJndiName);
				var5 = this.ivProxyCTOR;
				synchronized (this.ivProxyCTOR) {
					this.ivDeactivationKey = deactivationKey;
				}
			}
		} catch (ResourceException var14) {
			var6 = this.ivProxyCTOR;
			synchronized (this.ivProxyCTOR) {
				this.ivState = 0;
			}

			ex = var14;
		} catch (Throwable var15) {
			var6 = this.ivProxyCTOR;
			synchronized (this.ivProxyCTOR) {
				this.ivState = 0;
			}

			ex = new ResourceException(var15);
		}

		this.beanMetaData.ivActivationConfig = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "MEF.activateEndpoint for enterprise class " + this.beanMetaData.enterpriseBeanName);
		}

		if (ex != null) {
			throw ex;
		}
	}

	public void deactivateEndpoint() throws ResourceException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "MEF.deactivateEndpoint for enterprise class " + this.beanMetaData.enterpriseBeanName);
		}

		RALifeCycleManager r = RALifeCycleManagerFactory.getInstance();
		String deactivationKey = null;
		Constructor var3 = this.ivProxyCTOR;
		synchronized (this.ivProxyCTOR) {
			if (this.ivState != 2 && this.ivState != 4) {
				if (this.ivState != 0) {
					throw new ResourceException("illegal state for deactivate");
				}
			} else {
				this.ivState = 3;
				deactivationKey = this.ivDeactivationKey;
				if (deactivationKey == null) {
					this.ivState = 0;
				}
			}
		}

		if (deactivationKey != null) {
			boolean var13 = false;

			try {
				var13 = true;
				r.deactivateEndPoint(deactivationKey);
				var13 = false;
			} finally {
				if (var13) {
					Constructor var7 = this.ivProxyCTOR;
					synchronized (this.ivProxyCTOR) {
						this.ivState = 0;
						this.ivDeactivationKey = null;
					}
				}
			}

			var3 = this.ivProxyCTOR;
			synchronized (this.ivProxyCTOR) {
				this.ivState = 0;
				this.ivDeactivationKey = null;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "MEF.deactivateEndpoint for enterprise class " + this.beanMetaData.enterpriseBeanName);
		}

	}

	protected MessageEndpointHandler createEndpointHandler() {
		return new WASMessageEndpointHandler(this, this.ivRecoveryId, this.container, this.beanMetaData, this.pmiBean,
				this.wrapperManager, this.ivJMS);
	}

	public void messageEndpointForcefullyDeactivated() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "MEF.messageEndpointForcefullyDeactivated called for enterprise class "
					+ this.beanMetaData.enterpriseBeanName);
		}

		Constructor var1 = this.ivProxyCTOR;
		synchronized (this.ivProxyCTOR) {
			this.ivDeactivationKey = null;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "MEF.messageEndpointForcefullyDeactivated exit for enterprise class "
					+ this.beanMetaData.enterpriseBeanName);
		}

	}

	protected boolean isEndpointActive() {
		Constructor var1 = this.ivProxyCTOR;
		synchronized (this.ivProxyCTOR) {
			return this.ivDeactivationKey != null;
		}
	}

	public int getMaxPoolSize() {
		return this.ivMaxCreation;
	}

	public void setJCAVersion(JCAVersion version) {
		if (version == JCAVersion.JCA_VERSION_16) {
			this.ivJCAVersion = com.ibm.ws.ejbcontainer.mdb.BaseMessageEndpointFactory.JCAVersion.JCA_VERSION_16;
		} else {
			if (version != JCAVersion.JCA_VERSION_15) {
				throw new IllegalArgumentException("JCA Version " + version + " is not supported");
			}

			this.ivJCAVersion = com.ibm.ws.ejbcontainer.mdb.BaseMessageEndpointFactory.JCAVersion.JCA_VERSION_15;
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}