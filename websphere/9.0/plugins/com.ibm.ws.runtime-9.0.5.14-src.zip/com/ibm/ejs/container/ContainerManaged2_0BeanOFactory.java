package com.ibm.ejs.container;

public class ContainerManaged2_0BeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, EJSHome h) {
		return new ContainerManaged2_0BeanO(c, h);
	}
}