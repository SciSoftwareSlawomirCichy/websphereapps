package com.google.common.escape;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.escape.Escaper.1;

@GwtCompatible
public abstract class Escaper {
	private final Function<String, String> asFunction = new 1(this);

	public abstract String escape(String var1);

	public final Function<String, String> asFunction() {
		return this.asFunction;
	}
}