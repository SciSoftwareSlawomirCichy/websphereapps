package com.ibm.ffdc.util;

interface package-info {
}