package com.ibm.ejs.csi;

import javax.naming.Context;

public class SharedEJBModuleMetaDataImpl extends EJBModuleMetaDataImpl {
	public Context ivJavaGlobalContext;
	public Context ivJavaAppContext;

	public SharedEJBModuleMetaDataImpl(int slotSize, EJBApplicationMetaData ejbAMD) {
		super(slotSize, ejbAMD);
	}
}