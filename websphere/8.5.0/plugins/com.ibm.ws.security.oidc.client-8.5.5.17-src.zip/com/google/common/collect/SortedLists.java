package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.SortedLists.KeyAbsentBehavior;
import com.google.common.collect.SortedLists.KeyPresentBehavior;
import java.util.Comparator;
import java.util.List;
import java.util.RandomAccess;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
@Beta
final class SortedLists {
	public static <E extends Comparable> int binarySearch(List<? extends E> list, E e,
			KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior) {
		Preconditions.checkNotNull(e);
		return binarySearch(list, (Object) e, (Comparator) Ordering.natural(), presentBehavior, absentBehavior);
	}

	public static <E, K extends Comparable> int binarySearch(List<E> list, Function<? super E, K> keyFunction,
			@NullableDecl K key, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior) {
		return binarySearch(list, keyFunction, key, Ordering.natural(), presentBehavior, absentBehavior);
	}

	public static <E, K> int binarySearch(List<E> list, Function<? super E, K> keyFunction, @NullableDecl K key,
			Comparator<? super K> keyComparator, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior) {
		return binarySearch(Lists.transform(list, keyFunction), key, keyComparator, presentBehavior, absentBehavior);
	}

	public static <E> int binarySearch(List<? extends E> list, @NullableDecl E key, Comparator<? super E> comparator,
			KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior) {
		Preconditions.checkNotNull(comparator);
		Preconditions.checkNotNull(list);
		Preconditions.checkNotNull(presentBehavior);
		Preconditions.checkNotNull(absentBehavior);
		if (!(list instanceof RandomAccess)) {
			list = Lists.newArrayList((Iterable) list);
		}

		int lower = 0;
		int upper = ((List) list).size() - 1;

		while (lower <= upper) {
			int middle = lower + upper >>> 1;
			int c = comparator.compare(key, ((List) list).get(middle));
			if (c < 0) {
				upper = middle - 1;
			} else {
				if (c <= 0) {
					return lower + presentBehavior.resultIndex(comparator, key, ((List) list).subList(lower, upper + 1),
							middle - lower);
				}

				lower = middle + 1;
			}
		}

		return absentBehavior.resultIndex(lower);
	}
}