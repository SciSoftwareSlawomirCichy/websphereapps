package com.ibm.icu.impl;

import com.ibm.icu.impl.CurrencyData.CurrencyDisplayInfo;
import com.ibm.icu.impl.CurrencyData.CurrencyDisplayInfoProvider;
import com.ibm.icu.impl.CurrencyData.DefaultInfo;
import com.ibm.icu.impl.ICUCurrencyDisplayInfoProvider.ICUCurrencyDisplayInfo;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;

public class ICUCurrencyDisplayInfoProvider implements CurrencyDisplayInfoProvider {
	public CurrencyDisplayInfo getInstance(ULocale locale, boolean withFallback) {
		ICUResourceBundle rb = (ICUResourceBundle) UResourceBundle
				.getBundleInstance("com/ibm/icu/impl/data/icudt44b/curr", locale);
		if (!withFallback) {
			int status = rb.getLoadingStatus();
			if (status == 3 || status == 2) {
				return DefaultInfo.getWithFallback(false);
			}
		}

		return new ICUCurrencyDisplayInfo(rb, withFallback);
	}

	public boolean hasData() {
		return true;
	}
}