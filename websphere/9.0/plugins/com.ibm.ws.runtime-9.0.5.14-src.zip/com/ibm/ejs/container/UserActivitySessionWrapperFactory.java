package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ActivitySession.UserActivitySession;
import com.ibm.ws.ActivitySession.UserActivitySessionFactory;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.metadata.ComponentMetaData;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.spi.ObjectFactory;

public class UserActivitySessionWrapperFactory implements ObjectFactory {
	private static final TraceComponent tc = Tr.register(UserActivitySessionWrapperFactory.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.UserActivitySessionWrapperFactory";

	public Object getObjectInstance(Object obj, Name name, Context context, Hashtable<?, ?> env) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getObjectInstance");
		}

		EJSContainer container = EJSContainer.getDefaultContainer();
		ComponentMetaData cmd = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor().getComponentMetaData();
		if (EJSContainer.getCallbackBeanO() != null && cmd instanceof BeanMetaData) {
			BeanMetaData bmd = (BeanMetaData) cmd;
			RuntimeException runtime;
			if (bmd.usesBeanManagedTx && bmd.usesBeanManagedAS) {
				runtime = null;

				UserActivitySession userAS;
				try {
					userAS = UserActivitySessionFactory.createUserActivitySession();
				} catch (Exception var11) {
					FFDCFilter.processException(var11,
							"com.ibm.ejs.container.UserActivitySessionWrapperFactory.getObjectInstance", "78", this);
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "Exception creating UserActivitySessionImpl", var11);
					}

					throw new RuntimeException(var11.toString());
				}

				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "getObjectInstance");
				}

				return new UserActivitySessionWrapper(userAS, container);
			} else {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Bean " + bmd.j2eeName + " is not allowed to have "
							+ "UserActivitySession injected because its transaction flag is " + bmd.usesBeanManagedTx
							+ " and its activitySession flag is " + bmd.usesBeanManagedAS);
				}

				runtime = new RuntimeException(
						"UserActivitySession may only be looked up by or injected into an EJB that is configured to allow UserActivitySessions.  Bean "
								+ bmd.j2eeName + " " + "is not configured to allow UserActivitySessions.");
				Tr.exit(tc, "getObjectInstance", runtime);
				throw runtime;
			}
		} else {
			RuntimeException runtime = new RuntimeException(
					"UserActivitySession may only be looked up by or injected into an EJB");
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getObjectInstance : ", runtime);
			}

			throw runtime;
		}
	}
}