package com.ibm.ws.wim;

import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.InvalidRepositoryIdException;
import com.ibm.websphere.wim.exception.InvalidUniqueNameException;
import com.ibm.websphere.wim.exception.MissingInitPropertyException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.ws.wim.federation.FederationRepository;
import com.ibm.ws.wim.lookaside.LookasideRepository;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.StringUtil;
import com.ibm.ws.wim.util.UniqueNameHelper;
import com.ibm.wsspi.wim.Repository;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RepositoryManager implements DynamicConfigService, ConfigConstants {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static Map<String, RepositoryManager> singleton;
	private FederationRepository fedRepos = null;
	private Set dbReposIds = null;
	private LookasideRepository laRepos = null;
	private Repository[] repositories = null;
	private HashMap repositoryStatusMap = new HashMap(5);
	private DataObject[] reposConfigs = null;
	private String[] reposIds = null;
	private String[] reposTypes = null;
	private List[] reposNodes = null;
	private boolean entryJoin = false;
	private boolean propertyJoin = false;
	private int numOfRepos;
	private Map[] actionNotSupport = null;
	private boolean[] isGenerateUniqueId = null;
	private boolean[] isSortingSupported = null;
	private boolean[] isAsyncModeSupported = null;
	private boolean[] readOnlyFlags = null;
	private Map repositoriesForGroupMembers = null;
	private Set[] repositoriesForGroup = null;
	public static final String ACTION_READ = "READ";
	public static final String ACTION_CREATE = "CREATE";
	public static final String ACTION_UPDATE = "UPDATE";
	public static final String ACTION_DELETE = "DELETE";
	public static final String DB_ADAPTER_CLASS = "com.ibm.ws.wim.adapter.db.DBAdapter";
	public static final String FILE_ADAPTER_CLASS = "com.ibm.ws.wim.adapter.file.was.FileAdapter";
	public static final String LDAP_ADAPTER_CLASS = "com.ibm.ws.wim.adapter.ldap.LdapAdapter";
	public static final String LA_ADAPTER_CLASS = "com.ibm.ws.wim.lookaside.LookasideAdapter";
	public static final String FED_ADAPTER_CLASS = "com.ibm.ws.wim.federation.FederationAdapter";
	private static final String FED_ID = "FED";
	private static final String LA_ID = "LA";
	private DataObject fedDO = null;
	private DataObject laDO = null;

	private RepositoryManager(boolean var1) throws WIMException {
		this.initialize(var1);
	}

	public static synchronized RepositoryManager singleton() throws WIMException {
		return singleton(true);
	}

	public static synchronized RepositoryManager singleton(boolean var0) throws WIMException {
		String var1 = DomainManagerUtils.getDomainId();
		if (singleton.get(var1) == null) {
			singleton.put(var1, new RepositoryManager(var0));
		}

		return (RepositoryManager) singleton.get(var1);
	}

	public static void clearCache(String var0) {
		singleton.put(var0, (Object) null);
	}

	public LookasideRepository getLookasideRepository() throws WIMException {
		String var1 = "getLookasideRepository";
		boolean var2 = this.repositoryStatusMap.get("LA") != null
				? (Boolean) this.repositoryStatusMap.get("LA")
				: false;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, var1, "Repository LA initialized = " + var2);
		}

		if (this.laRepos != null && this.laDO != null && !var2) {
			this.laRepos.initialize(this.laDO);
			this.repositoryStatusMap.put("LA", true);
		}

		return this.laRepos;
	}

	public FederationRepository getFederationRepository() throws WIMException {
		String var1 = "getFederationRepository";
		boolean var2 = this.repositoryStatusMap.get("FED") != null
				? (Boolean) this.repositoryStatusMap.get("FED")
				: false;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, var1, "Repository FED initialized = " + var2);
		}

		if (this.fedRepos != null && this.fedDO != null & !var2) {
			this.fedRepos.initialize(this.fedDO);
			this.repositoryStatusMap.put("FED", true);
		}

		return this.fedRepos;
	}

	public Repository[] getRepositories() {
		return this.repositories;
	}

	public Repository getRepository(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getRepository", "reposId=" + var1);
		}

		int var3 = this.getRepositoryIndexByRepositoryID(var1);
		Repository var4 = null;
		if (var3 != -1) {
			var4 = this.repositories[var3];
		}

		boolean var5 = this.repositoryStatusMap.get(var1) != null
				? (Boolean) this.repositoryStatusMap.get(var1)
				: false;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "getRepository", "Repository " + var1 + " initialized = " + var5);
		}

		if (var4 != null && !var5) {
			var4.initialize(this.getRepositoryConfig(var1));
			this.repositoryStatusMap.put(var1, true);
		}

		if (var4 == null) {
			throw new InvalidRepositoryIdException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateMsgParms(var1),
					CLASSNAME, "getRepository");
		} else {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getRepository");
			}

			return var4;
		}
	}

	public Repository getTargetRepository(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getTargetRepository", "uniqueName=" + var1);
		}

		int var3 = this.getRepositoryIndexByUniqueName(var1);
		Repository var4 = null;
		if (var3 != -1) {
			var4 = this.repositories[var3];
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getTargetRepository");
		}

		return var4;
	}

	public String getLookasideRepositoryID() {
		return "LA";
	}

	public String getFederationRepositoryID() {
		return "FED";
	}

	public String getRepositoryID(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getRepositoryID", "uniqueName=" + var1);
		}

		int var3 = this.getRepositoryIndexByUniqueName(var1);
		String var4 = null;
		if (var3 != -1) {
			var4 = this.reposIds[var3];
		}

		if (var4 == null) {
			throw new InvalidUniqueNameException("ENTITY_NOT_IN_REALM_SCOPE",
					WIMMessageHelper.generateMsgParms(var1, "defined in WIM"), CLASSNAME, "getRepositoryID");
		} else {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getRepositoryID");
			}

			return var4;
		}
	}

	protected int getRepositoryIndexByUniqueName(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, "getRepositoryIndexByUniqueName", "uniqueName=" + var1);
		}

		int var3 = -1;
		var1 = UniqueNameHelper.getValidUniqueName(var1).trim();
		int var4 = var1.length();

		label46 : for (int var5 = 0; var5 < this.reposNodes.length; ++var5) {
			List var6 = this.reposNodes[var5];

			for (int var7 = 0; var7 < var6.size(); ++var7) {
				String var8 = (String) var6.get(var7);
				int var9 = var8.length();
				if (var9 == 0) {
					var3 = var5;
					break label46;
				}

				if (var4 == var9 && var1.equalsIgnoreCase(var8)) {
					var3 = var5;
					break label46;
				}

				if (var4 > var9 && StringUtil.endsWithIgnoreCase(var1, "," + var8)) {
					var3 = var5;
					break label46;
				}
			}
		}

		if (var3 == -1) {
			throw new InvalidUniqueNameException("ENTITY_NOT_IN_REALM_SCOPE",
					WIMMessageHelper.generateMsgParms(var1, "defined"), CLASSNAME, "getRepositoryIndexByUniqueName");
		} else {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.exiting(CLASSNAME, "getRepositoryIndexByUniqueName", "reposIndex=" + var3);
			}

			return var3;
		}
	}

	public List[] getRepositoriesBaseEntries() {
		return this.reposNodes;
	}

	public List getRepositoryBaseEntries(String var1) throws WIMException {
		int var2 = this.getRepositoryIndexByRepositoryID(var1);
		List var3 = null;
		if (var2 != -1) {
			var3 = this.reposNodes[var2];
		}

		return var3;
	}

	public DataObject getRepositoryConfig(String var1) throws WIMException {
		int var2 = this.getRepositoryIndexByRepositoryID(var1);
		DataObject var3 = null;
		if (var2 != -1) {
			var3 = this.reposConfigs[var2];
		}

		return var3;
	}

	public String[] getRepositoryIds() {
		return this.reposIds;
	}

	protected int getRepositoryIndexByRepositoryID(String var1) throws WIMException {
		if (var1 == null) {
			throw new InvalidRepositoryIdException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateNullMsgParms(),
					CLASSNAME, "getRepositoryIndexByRepositoryID");
		} else {
			int var3 = -1;

			for (int var4 = 0; var4 < this.reposIds.length; ++var4) {
				if (var1.equalsIgnoreCase(this.reposIds[var4])) {
					var3 = var4;
					break;
				}
			}

			if (var3 == -1) {
				throw new InvalidRepositoryIdException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateMsgParms(var1),
						CLASSNAME, "getRepositoryIndexByRepositoryID");
			} else {
				return var3;
			}
		}
	}

	public int getNumberOfRepositories() {
		return this.numOfRepos;
	}

	public boolean isEntryJoin() {
		return this.entryJoin;
	}

	public boolean isPropertyJoin() {
		return this.propertyJoin;
	}

	private Class loadAdapterClass(String var1) throws ClassNotFoundException {
		trcLogger.entering(CLASSNAME, "loadAdapterClass");

		Class var2;
		try {
			var2 = Class.forName(var1);
			trcLogger.log(Level.FINEST, "Successfully loaded class " + var1 + " with default class loader");
		} catch (ClassNotFoundException var5) {
			ClassLoader var4 = Thread.currentThread().getContextClassLoader();
			if (var4 == null) {
				var4 = this.getClass().getClassLoader();
			}

			var2 = Class.forName(var1, true, var4);
			trcLogger.log(Level.FINEST, "Successfully loaded class " + var1 + " with context class loader");
		}

		trcLogger.exiting(CLASSNAME, "loadAdapterClass");
		return var2;
	}

	private void initialize(boolean var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize", "initAdapters:: " + var1);
		}

		DataObject var3 = ConfigManager.singleton().getConfig();
		this.fedDO = var3.getDataObject("entryMappingRepository");
		String var4;
		Class var5;
		if (this.fedDO != null) {
			this.entryJoin = true;
			var4 = this.fedDO.getString("adapterClassName");
			if (var4 == null || var4.length() == 0) {
				var4 = "com.ibm.ws.wim.federation.FederationAdapter";
			}

			try {
				var5 = this.loadAdapterClass(var4);
				this.fedRepos = (FederationRepository) var5.newInstance();
				if (var1) {
					this.fedRepos.initialize(this.fedDO);
				}

				this.repositoryStatusMap.put("FED", var1);
			} catch (ClassNotFoundException var18) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms("FED", var18.getMessage()), CLASSNAME, "initialize", var18);
			} catch (InstantiationException var19) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms("FED", var19.getMessage()), CLASSNAME, "initialize", var19);
			} catch (IllegalAccessException var20) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms("FED", var20.getMessage()), CLASSNAME, "initialize", var20);
			}
		}

		this.laDO = var3.getDataObject("propertyExtensionRepository");
		if (this.laDO != null) {
			this.propertyJoin = true;
			var4 = this.laDO.getString("adapterClassName");
			if (var4 == null || var4.length() == 0) {
				var4 = "com.ibm.ws.wim.lookaside.LookasideAdapter";
			}

			try {
				var5 = this.loadAdapterClass(var4);
				this.laRepos = (LookasideRepository) var5.newInstance();
				if (var1) {
					this.laRepos.initialize(this.laDO);
				}

				this.repositoryStatusMap.put("LA", var1);
			} catch (ClassNotFoundException var15) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms("LA", var15.getMessage()), CLASSNAME, "initialize", var15);
			} catch (InstantiationException var16) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms("LA", var16.getMessage()), CLASSNAME, "initialize", var16);
			} catch (IllegalAccessException var17) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms("LA", var17.getMessage()), CLASSNAME, "initialize", var17);
			}
		}

		List var25 = var3.getList("repositories");
		this.numOfRepos = var25.size();
		this.reposNodes = new List[this.numOfRepos];
		this.repositories = new Repository[this.numOfRepos];
		this.reposConfigs = new DataObject[this.numOfRepos];
		this.reposIds = new String[this.numOfRepos];
		this.reposTypes = new String[this.numOfRepos];
		this.actionNotSupport = new HashMap[this.numOfRepos];
		this.isGenerateUniqueId = new boolean[this.numOfRepos];
		this.isSortingSupported = new boolean[this.numOfRepos];
		this.isAsyncModeSupported = new boolean[this.numOfRepos];
		this.repositoriesForGroup = new Set[this.numOfRepos];
		this.readOnlyFlags = new boolean[this.numOfRepos];

		for (int var24 = 0; var24 < var25.size(); ++var24) {
			DataObject var6 = (DataObject) var25.get(var24);
			this.reposConfigs[var24] = var6;
			this.reposIds[var24] = var6.getString("id");
			List var7 = var6.getList("baseEntries");
			this.reposNodes[var24] = new ArrayList(var7.size());

			String var10;
			for (int var8 = 0; var8 < var7.size(); ++var8) {
				DataObject var9 = (DataObject) var7.get(var8);
				var10 = var9.getString("name");
				var10 = UniqueNameHelper.getValidUniqueName(var10);
				this.reposNodes[var24].add(var10.trim());
			}

			List var26 = var6.getList("repositoriesForGroups");
			this.repositoriesForGroup[var24] = new HashSet();
			if (var26 != null && var26.size() > 0) {
				if (this.repositoriesForGroupMembers == null) {
					this.repositoriesForGroupMembers = new HashMap();
				}

				for (int var27 = 0; var27 < var26.size(); ++var27) {
					var10 = ((String) var26.get(var27)).trim();
					this.repositoriesForGroup[var24].add(var10);
					Object var11 = (Set) this.repositoriesForGroupMembers.get(var10);
					if (var11 == null) {
						var11 = new HashSet();
					}

					((Set) var11).add(this.reposIds[var24]);
					this.repositoriesForGroupMembers.put(var10, var11);
				}
			}

			String var28 = var6.getType().getName();
			this.reposTypes[var24] = var28;
			var10 = var6.getString("adapterClassName");
			if (var10 == null) {
				if (var28.equals("DatabaseRepositoryType")) {
					var10 = "com.ibm.ws.wim.adapter.db.DBAdapter";
				} else if (var28.equals("FileRepositoryType")) {
					var10 = "com.ibm.ws.wim.adapter.file.was.FileAdapter";
				} else {
					if (!var28.equals("LdapRepositoryType")) {
						throw new MissingInitPropertyException("MISSING_INI_PROPERTY",
								WIMMessageHelper.generateMsgParms("adapterClassName"), CLASSNAME, "initialize");
					}

					var10 = "com.ibm.ws.wim.adapter.ldap.LdapAdapter";
				}
			}

			try {
				Class var29 = this.loadAdapterClass(var10);
				this.repositories[var24] = (Repository) var29.newInstance();
				if (var1) {
					this.repositories[var24].initialize(var6);
				}

				this.repositoryStatusMap.put(this.reposIds[var24], var1);
			} catch (ClassNotFoundException var21) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms(this.reposIds[var24], var21.getMessage()), CLASSNAME,
						"initialize", var21);
			} catch (InstantiationException var22) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms(this.reposIds[var24], var22.getMessage()), CLASSNAME,
						"initialize", var22);
			} catch (IllegalAccessException var23) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms(this.reposIds[var24], var23.getMessage()), CLASSNAME,
						"initialize", var23);
			}

			if (var28.equals("DatabaseRepositoryType") || var28.equals("ProfileRepositoryType")) {
				if (this.dbReposIds == null) {
					this.dbReposIds = new HashSet();
				}

				this.dbReposIds.add(var6.getString("id"));
			}

			this.actionNotSupport[var24] = new HashMap();
			List var30 = var6.getList("EntityTypesNotAllowCreate");
			if (var30 != null && var30.size() != 0) {
				this.actionNotSupport[var24].put("CREATE", var30);
			}

			List var12 = var6.getList("EntityTypesNotAllowRead");
			if (var12 != null && var12.size() != 0) {
				this.actionNotSupport[var24].put("READ", var12);
			}

			List var13 = var6.getList("EntityTypesNotAllowUpdate");
			if (var13 != null && var13.size() != 0) {
				this.actionNotSupport[var24].put("UPDATE", var13);
			}

			List var14 = var6.getList("EntityTypesNotAllowDelete");
			if (var14 != null && var14.size() != 0) {
				this.actionNotSupport[var24].put("DELETE", var14);
			}

			this.isGenerateUniqueId[var24] = !var6.getBoolean("isExtIdUnique");
			this.isSortingSupported[var24] = var6.getBoolean("supportSorting");
			this.isAsyncModeSupported[var24] = var6.getBoolean("supportAsyncMode");
			this.readOnlyFlags[var24] = var6.getBoolean("readOnly");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

	}

	public boolean isDeleteNonExistingMemebersFromGroup(String var1, String var2) throws WIMException {
		boolean var3 = false;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isDeleteNonExistingMemebersFromGroup",
					"GroupId = " + var1 + "MemberId = " + var2);
		}

		boolean var5 = false;
		if (this.repositoriesForGroup != null) {
			for (int var6 = 0; var6 < this.repositoriesForGroup.length; ++var6) {
				Set var7 = this.repositoriesForGroup[var6];
				if (var7.contains(var1)) {
					var5 = true;
					break;
				}
			}

			if (var5) {
				DataObject var17 = ConfigManager.singleton().getConfig();
				List var18 = var17.getList("repositories");

				label74 : for (int var8 = 0; var8 < var18.size(); ++var8) {
					DataObject var9 = (DataObject) var18.get(var8);
					if (var9.getString("id").equalsIgnoreCase(var1)) {
						List var10 = var9.getList("CustomProperties");
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "isDeleteNonExistingMemebersFromGroup",
									"propList:" + var10);
						}

						if (var10 == null) {
							var3 = false;
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.exiting(CLASSNAME, "isDeleteNonExistingMemebersFromGroup", var3);
							}

							return var3;
						}

						Iterator var11 = var10.iterator();

						while (var11.hasNext()) {
							DataObject var12 = (DataObject) var11.next();
							String var13 = var12.getString("name");
							String var14 = var12.getString("value");
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "isDeleteNonExistingMemebersFromGroup",
										"custom properties name= " + var13 + "value = " + var14);
							}

							if (var13 != null && var14 != null
									&& "repositoriesForMemberDeletion".equalsIgnoreCase(var13)) {
								if ("*".equalsIgnoreCase(var14.trim())) {
									var3 = true;
									break;
								}

								StringTokenizer var15 = new StringTokenizer(var14, ";");

								while (true) {
									if (!var15.hasMoreTokens()) {
										continue label74;
									}

									String var16 = var15.nextToken();
									if (var2.equalsIgnoreCase(var16.trim())) {
										var3 = true;
									}
								}
							}
						}
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isDeleteNonExistingMemebersFromGroup", var3);
		}

		return var3;
	}

	public boolean isAsyncModeSupported(String var1) throws WIMException {
		return this.isAsyncModeSupported(this.getRepositoryIndexByRepositoryID(var1));
	}

	public boolean isAsyncModeSupported(int var1) {
		return this.isAsyncModeSupported[var1];
	}

	public boolean isEntityTypeActionSupported(String var1, String var2, String var3) throws WIMException {
		int var4 = this.getRepositoryIndexByRepositoryID(var3);
		return this.isEntityTypeActionSupported(var1, var2, var4);
	}

	public boolean isEntityTypeActionSupported(String var1, String var2, int var3) {
		Map var4 = this.actionNotSupport[var3];
		if (var4 != null && var4.size() != 0) {
			List var5 = (List) var4.get(var1);
			if (var5 != null && var5.size() != 0) {
				return !var5.contains(var2);
			} else {
				return true;
			}
		} else {
			return true;
		}
	}

	public boolean isGenerateUniqueId(String var1) throws WIMException {
		int var2 = this.getRepositoryIndexByRepositoryID(var1);
		return this.isGenerateUniqueId[var2];
	}

	public boolean isReadOnly(int var1) {
		return this.readOnlyFlags[var1];
	}

	public boolean isReadOnly(String var1) throws WIMException {
		return this.readOnlyFlags[this.getRepositoryIndexByRepositoryID(var1)];
	}

	public boolean isSortingSupported(int var1) {
		return this.isSortingSupported[var1];
	}

	public String getRepositoryIDByRepositoryIndex(int var1) {
		return this.reposIds[var1];
	}

	public String getRepositoryTypeByRepositoryIndex(int var1) {
		return this.reposTypes[var1];
	}

	public boolean isAccessEnabled(String var1, String var2) throws WIMException {
		int var3 = this.getRepositoryIndexByRepositoryID(var2);
		Map var4 = this.actionNotSupport[var3];
		return var4 != null && var4.size() != 0 ? var4.containsKey(var1) : false;
	}

	public boolean isDBRepository(String var1) {
		return this.dbReposIds != null ? this.dbReposIds.contains(var1) : false;
	}

	public boolean isEntityInDBRepository(String var1) throws WIMException {
		return this.dbReposIds != null ? this.dbReposIds.contains(this.getRepositoryID(var1)) : false;
	}

	public boolean isCrossRepositoryGroupMembership(String var1) throws WIMException {
		int var2 = this.getRepositoryIndexByRepositoryID(var1);
		int var3 = this.repositoriesForGroup[var2].size();
		if (var3 > 1) {
			return true;
		} else {
			if (var3 == 1) {
				String var4 = (String) this.repositoriesForGroup[var2].iterator().next();
				if (!var1.equals(var4)) {
					return true;
				}
			}

			return false;
		}
	}

	public Set getRepositoriesForGroupMembership(String var1) throws WIMException {
		int var2 = this.getRepositoryIndexByRepositoryID(var1);
		return this.repositoriesForGroup[var2];
	}

	public boolean canGroupAcceptMember(String var1, String var2) {
		if (this.repositoriesForGroupMembers != null) {
			Set var3 = (Set) this.repositoriesForGroupMembers.get(var1);
			if (var3 != null) {
				return var3.contains(var2);
			}
		}

		return false;
	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "dynamicUpdateConfig", "updateEvent=" + var1);
		}

		String var5;
		DataObject var9;
		String var22;
		if ("websphere.usermanager.serviceprovider.update.ldap.bindinfo".equalsIgnoreCase(var1)) {
			var22 = (String) var2.get("DYNA_CONFIG_KEY_REPOS_ID");
			if (var22 == null) {
				throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_MISSING_VALUE",
						WIMMessageHelper.generateMsgParms("DYNA_CONFIG_KEY_REPOS_ID",
								"websphere.usermanager.serviceprovider.update.ldap.bindinfo"),
						CLASSNAME, "dynamicUpdateConfig");
			}

			var5 = (String) var2.get("DYNA_CONFIG_KEY_LDAP_BIND_DN");
			byte[] var27 = (byte[]) ((byte[]) var2.get("DYNA_CONFIG_KEY_LDAP_BIND_PASSWORD"));
			if (var5 != null && var27 == null) {
				throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_MISSING_VALUE",
						WIMMessageHelper.generateMsgParms("DYNA_CONFIG_KEY_LDAP_BIND_PASSWORD",
								"websphere.usermanager.serviceprovider.update.ldap.bindinfo"),
						CLASSNAME, "dynamicUpdateConfig");
			}

			DataGraph var30 = ConfigManager.singleton()
					.loadConfigFromXML(ConfigManager.singleton().getWIMConfigXMLFilePath());
			DataObject var32 = var30.getRootObject().getDataObject("configurationProvider");
			var9 = var32.getDataObject("repositories[id=" + var22 + "]");
			if (var9 == null) {
				throw new InvalidRepositoryIdException("INVALID_REPOSITORY_ID",
						WIMMessageHelper.generateMsgParms(var22), CLASSNAME, "dynamicUpdateConfig");
			}

			var2.put("DYNA_CONFIG_KEY_REPOS_CONFIG", var9);
			int var33 = this.getRepositoryIndexByRepositoryID(var22);
			DataObject var11 = this.reposConfigs[var33];
			if (!"LdapRepositoryType".equals(var11.getType().getName())) {
				throw new DynamicUpdateConfigException("NOT_LDAP_REPOSITORY", WIMMessageHelper.generateMsgParms(var22),
						CLASSNAME, "dynamicUpdateConfig");
			}

			Repository var12 = this.repositories[var33];

			try {
				((DynamicConfigService) var12).dynamicUpdateConfig(var1, var2);
			} catch (RemoteException var21) {
				throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var21.getMessage()),
						CLASSNAME, "dynamicUpdateConfig", var21);
			}
		} else if ("websphere.usermanager.serviceprovider.add.entityconfig".equalsIgnoreCase(var1)) {
			Hashtable var23 = (Hashtable) var2.get("DYNA_CONFIG_KEY_ENTITY_CONFIGS");
			if (var23 != null) {
				Set var28 = var23.keySet();
				Iterator var26 = var28.iterator();

				while (var26.hasNext()) {
					String var29 = (String) var26.next();
					int var31 = this.getRepositoryIndexByRepositoryID(var29);
					var9 = this.reposConfigs[var31];
					if (!"LdapRepositoryType".equals(var9.getType().getName())) {
						throw new DynamicUpdateConfigException("NOT_LDAP_REPOSITORY",
								WIMMessageHelper.generateMsgParms(var29), CLASSNAME, "dynamicUpdateConfig");
					}

					Repository var10 = this.repositories[var31];

					try {
						((DynamicConfigService) var10).dynamicUpdateConfig(var1, var2);
					} catch (RemoteException var20) {
						throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var20.getMessage()),
								CLASSNAME, "dynamicUpdateConfig", var20);
					}
				}
			}
		} else {
			int var24;
			if ("websphere.usermanager.serviceprovider.add.propertyconfig".equalsIgnoreCase(var1)) {
				var22 = (String) var2.get("DYNA_CONFIG_KEY_REPOS_ID");
				var24 = this.getRepositoryIndexByRepositoryID(var22);

				try {
					((DynamicConfigService) this.repositories[var24]).dynamicUpdateConfig(var1, var2);
				} catch (RemoteException var19) {
					throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var19.getMessage()),
							CLASSNAME, "dynamicUpdateConfig", var19);
				}
			} else if (var1.equals("websphere.usermanager.serviceprovider.add.baseentry")) {
				label160 : {
					var22 = (String) var2.get("DYNA_CONFIG_KEY_REPOS_ID");
					if (var22 != null && var22.trim().length() != 0) {
						var5 = (String) var2.get("DYNA_CONFIG_KEY_BASE_ENTRY");
						if (var5 != null && var5.trim().length() != 0) {
							int var25 = this.getRepositoryIndexByRepositoryID(var22);
							List var7 = this.reposNodes[var25];
							boolean var8 = matchBaseEntryIgnoreCase(var7, var5);
							if (var8) {
								throw new DynamicUpdateConfigException("BASE_ENTRY_ALREADY_IN_REPOSITORY",
										WIMMessageHelper.generateMsgParms(var5, var22), Level.SEVERE, CLASSNAME,
										"dynamicUpdateConfig");
							}

							try {
								((DynamicConfigService) this.repositories[var25]).dynamicUpdateConfig(var1, var2);
							} catch (RemoteException var18) {
								throw new WIMSystemException("GENERIC",
										WIMMessageHelper.generateMsgParms(var18.getMessage()), CLASSNAME,
										"dynamicUpdateConfig", var18);
							}

							var7.add(var5);
							this.reposNodes[var25] = var7;
							break label160;
						}

						throw new DynamicUpdateConfigException("INVALID_BASE_ENTRY_NAME",
								WIMMessageHelper.generateMsgParms(var5, var22), Level.SEVERE, CLASSNAME,
								"dynamicUpdateConfig");
					}

					throw new DynamicUpdateConfigException("INVALID_REPOSITORY_ID",
							WIMMessageHelper.generateMsgParms(var22), Level.SEVERE, CLASSNAME, "dynamicUpdateConfig");
				}
			} else {
				DataObject var4;
				if (var1.equals("websphere.usermanager.serviceprovider.add.repository")) {
					var4 = (DataObject) var2.get("DYNA_CONFIG_KEY_REPOS_CONFIG");
					this.addNewRepository(var4);
				} else if (var1.equals("websphere.usermanager.serviceprovider.add.propertyextensionrepository")) {
					if (this.propertyJoin) {
						throw new DynamicUpdateConfigException("PROPERTY_EXTENSION_REPOSITORY_ALREADY_DEFINED",
								CLASSNAME, "dynamicUpdateConfig");
					}

					var4 = (DataObject) var2.get("DYNA_CONFIG_KEY_PROP_EXT_REPOS_CONFIG");
					if (var4 != null) {
						var5 = var4.getString("adapterClassName");
						if (var5 == null || var5.length() == 0) {
							var5 = "com.ibm.ws.wim.lookaside.LookasideAdapter";
						}

						try {
							Class var6 = this.loadAdapterClass(var5);
							this.laRepos = (LookasideRepository) var6.newInstance();
							this.laRepos.initialize(var4);
						} catch (Exception var17) {
							throw new WIMSystemException(
									"REPOSITORY_INITIALIZATION_FAILED", WIMMessageHelper
											.generateMsgParms("propertyExtensionRepository", var17.getMessage()),
									CLASSNAME, "dynamicUpdateConfig");
						}

						this.propertyJoin = true;
					}
				} else if (var1.equals("websphere.usermanager.serviceprovider.update.db.adminidpassword")) {
					var22 = (String) var2.get("DYNA_CONFIG_KEY_REPOS_ID");
					if (var22 != null && var22.trim().length() != 0) {
						var24 = this.getRepositoryIndexByRepositoryID(var22);

						try {
							((DynamicConfigService) this.repositories[var24]).dynamicUpdateConfig(var1, var2);
						} catch (RemoteException var16) {
							throw new WIMSystemException("GENERIC",
									WIMMessageHelper.generateMsgParms(var16.getMessage()), CLASSNAME,
									"dynamicUpdateConfig", var16);
						}
					}
				} else if (var1.equals("websphere.usermanager.serviceprovider.update.entrymapping.adminidpassword")) {
					if (!this.entryJoin) {
						throw new DynamicUpdateConfigException("ENTRY_MAPPING_REPOSITORY_NOT_DEFINED", CLASSNAME,
								"dynamicUpdateConfig");
					}

					try {
						((DynamicConfigService) this.fedRepos).dynamicUpdateConfig(var1, var2);
					} catch (RemoteException var15) {
						throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var15.getMessage()),
								CLASSNAME, "dynamicUpdateConfig", var15);
					}
				} else if (var1
						.equals("websphere.usermanager.serviceprovider.update.propertyextension.adminidpassword")) {
					if (!this.propertyJoin) {
						throw new DynamicUpdateConfigException("PROPERTY_EXTENSION_REPOSITORY_NOT_DEFINED", CLASSNAME,
								"dynamicUpdateConfig");
					}

					try {
						((DynamicConfigService) this.laRepos).dynamicUpdateConfig(var1, var2);
					} catch (RemoteException var14) {
						throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var14.getMessage()),
								CLASSNAME, "dynamicUpdateConfig", var14);
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "dynamicUpdateConfig");
		}

	}

	private void addNewRepository(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "addNewRepository");
		}

		int var3 = this.reposConfigs.length;
		DataObject[] var4 = new DataObject[var3 + 1];

		for (int var5 = 0; var5 < var3; ++var5) {
			var4[var5] = SDOHelper.cloneDataObject(this.reposConfigs[var5]);
		}

		var4[var3] = var1;
		this.reposConfigs = var4;
		String[] var26 = new String[var3 + 1];
		String[] var6 = new String[var3 + 1];

		for (int var7 = 0; var7 < var3; ++var7) {
			var26[var7] = this.reposIds[var7];
			var6[var7] = this.reposTypes[var7];
		}

		var26[var3] = var1.getString("id");
		this.reposIds = var26;
		List var27 = var1.getList("baseEntries");
		List[] var8 = new List[var3 + 1];
		List[] var9 = new List[var3 + 1];

		int var10;
		for (var10 = 0; var10 < var3; ++var10) {
			var8[var10] = this.reposNodes[var10];
		}

		var8[var3] = new ArrayList(var27.size());
		var9[var3] = new ArrayList(var27.size());

		String var12;
		for (var10 = 0; var10 < var27.size(); ++var10) {
			DataObject var11 = (DataObject) var27.get(var10);
			var12 = var11.getString("name");
			var8[var3].add(var11.getString("name").trim());
		}

		this.reposNodes = var8;
		List var28 = var1.getList("repositoriesForGroups");
		Set[] var29 = new Set[var3 + 1];

		int var30;
		for (var30 = 0; var30 < var3; ++var30) {
			var29[var30] = this.repositoriesForGroup[var30];
		}

		var29[var3] = new HashSet();
		if (var28 != null && var28.size() > 0) {
			if (this.repositoriesForGroupMembers == null) {
				this.repositoriesForGroupMembers = new HashMap();
			}

			var30 = var28.size();

			for (int var13 = 0; var13 < var28.size(); ++var13) {
				String var14 = ((String) var28.get(var13)).trim();
				var29[var3].add(var14);
				Object var15 = (Set) this.repositoriesForGroupMembers.get(var14);
				if (var15 == null) {
					var15 = new HashSet();
				}

				((Set) var15).add(this.reposIds[var3]);
				this.repositoriesForGroupMembers.put(var14, var15);
			}
		}

		this.repositoriesForGroup = var29;
		var12 = var1.getType().getName();
		var6[var3] = var12;
		this.reposTypes = var6;
		String var31 = var1.getString("adapterClassName");
		if (var31 == null) {
			if (var12.equals("DatabaseRepositoryType")) {
				var31 = "com.ibm.ws.wim.adapter.db.DBAdapter";
			} else if (var12.equals("FileRepositoryType")) {
				var31 = "com.ibm.ws.wim.adapter.file.was.FileAdapter";
			} else {
				if (!var12.equals("LdapRepositoryType")) {
					throw new MissingInitPropertyException("MISSING_INI_PROPERTY",
							WIMMessageHelper.generateMsgParms("adapterClassName"), CLASSNAME, "addNewRepository");
				}

				var31 = "com.ibm.ws.wim.adapter.ldap.LdapAdapter";
			}
		}

		Repository[] var32 = new Repository[var3 + 1];

		for (int var33 = 0; var33 < var3; ++var33) {
			var32[var33] = this.repositories[var33];
		}

		try {
			Class var34 = this.loadAdapterClass(var31);
			var32[var3] = (Repository) var34.newInstance();
			this.repositories = var32;
			this.repositories[var3].initialize(var1);
		} catch (Exception var25) {
			throw new DynamicUpdateConfigException("CLASS_OR_INTERFACE_NOT_FOUND",
					WIMMessageHelper.generateMsgParms(var31, "adapterClassName"), CLASSNAME, "addNewRepository");
		}

		if (var12.equals("DatabaseRepositoryType") || var12.equals("ProfileRepositoryType")) {
			if (this.dbReposIds == null) {
				this.dbReposIds = new HashSet();
			}

			this.dbReposIds.add(var1.getString("id"));
		}

		Map[] var36 = new Map[var3 + 1];

		for (int var16 = 0; var16 < var3; ++var16) {
			var36[var16] = this.actionNotSupport[var16];
		}

		var36[var3] = new HashMap();
		List var35 = var1.getList("EntityTypesNotAllowCreate");
		if (var35 != null && var35.size() != 0) {
			var36[var3].put("CREATE", var35);
		}

		List var17 = var1.getList("EntityTypesNotAllowRead");
		if (var17 != null && var17.size() != 0) {
			var36[var3].put("READ", var17);
		}

		List var18 = var1.getList("EntityTypesNotAllowUpdate");
		if (var18 != null && var18.size() != 0) {
			var36[var3].put("UPDATE", var18);
		}

		List var19 = var1.getList("EntityTypesNotAllowDelete");
		if (var19 != null && var19.size() != 0) {
			var36[var3].put("DELETE", var19);
		}

		this.actionNotSupport = var36;
		boolean[] var20 = new boolean[var3 + 1];

		for (int var21 = 0; var21 < var3; ++var21) {
			var20[var21] = this.isGenerateUniqueId[var21];
		}

		var20[var3] = !var1.getBoolean("isExtIdUnique");
		this.isGenerateUniqueId = var20;
		boolean[] var37 = new boolean[var3 + 1];

		for (int var22 = 0; var22 < var3; ++var22) {
			var37[var22] = var37[var22];
		}

		var37[var3] = var1.getBoolean("supportSorting");
		this.isSortingSupported = var37;
		boolean[] var38 = new boolean[var3 + 1];

		for (int var23 = 0; var23 < var3; ++var23) {
			var38[var23] = this.isAsyncModeSupported[var23];
		}

		var38[var3] = var1.getBoolean("supportAsyncMode");
		this.isAsyncModeSupported = var38;
		boolean[] var39 = new boolean[var3 + 1];

		for (int var24 = 0; var24 < var3; ++var24) {
			var39[var24] = this.readOnlyFlags[var24];
		}

		var39[var3] = var1.getBoolean("readOnly");
		this.readOnlyFlags = var39;
		++this.numOfRepos;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "addNewRepository");
		}

	}

	public static boolean matchBaseEntryIgnoreCase(List var0, String var1) {
		boolean var3 = false;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "matchBaseEntryIgnoreCase",
					"Locale=" + Locale.getDefault() + ", baseEntry=" + var1 + ",  baseEntries=" + var0);
		}

		if (var0 != null && var1 != null) {
			for (int var4 = 0; var4 < var0.size(); ++var4) {
				if (var1.equalsIgnoreCase((String) var0.get(var4))) {
					var3 = true;
					break;
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "matchBaseEntryIgnoreCase", "result=" + var3);
		}

		return var3;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = RepositoryManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
	}
}