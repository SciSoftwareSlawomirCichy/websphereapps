package com.google.common.util.concurrent;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.ImmutableCollection;
import com.google.common.collect.UnmodifiableIterator;
import com.google.common.util.concurrent.AbstractFuture.TrustedFuture;
import com.google.common.util.concurrent.AggregateFuture.RunningState;
import java.util.Set;
import java.util.logging.Logger;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AggregateFuture<InputT, OutputT> extends TrustedFuture<OutputT> {
	private static final Logger logger = Logger.getLogger(AggregateFuture.class.getName());
	@NullableDecl
	private AggregateFuture<InputT, OutputT>.RunningState runningState;

	protected final void afterDone() {
		super.afterDone();
		AggregateFuture<InputT, OutputT>.RunningState localRunningState = this.runningState;
		if (localRunningState != null) {
			this.runningState = null;
			ImmutableCollection<? extends ListenableFuture<? extends InputT>> futures = RunningState
					.access$000(localRunningState);
			boolean wasInterrupted = this.wasInterrupted();
			if (wasInterrupted) {
				localRunningState.interruptTask();
			}

			if (this.isCancelled() & futures != null) {
				UnmodifiableIterator var4 = futures.iterator();

				while (var4.hasNext()) {
					ListenableFuture<?> future = (ListenableFuture) var4.next();
					future.cancel(wasInterrupted);
				}
			}
		}

	}

	protected String pendingToString() {
		AggregateFuture<InputT, OutputT>.RunningState localRunningState = this.runningState;
		if (localRunningState == null) {
			return null;
		} else {
			ImmutableCollection<? extends ListenableFuture<? extends InputT>> localFutures = RunningState
					.access$000(localRunningState);
			return localFutures != null ? "futures=[" + localFutures + "]" : null;
		}
	}

	final void init(AggregateFuture<InputT, OutputT>.RunningState runningState) {
		this.runningState = runningState;
		RunningState.access$100(runningState);
	}

	private static boolean addCausalChain(Set<Throwable> seen, Throwable t) {
		while (t != null) {
			boolean firstTimeSeen = seen.add(t);
			if (!firstTimeSeen) {
				return false;
			}

			t = t.getCause();
		}

		return true;
	}
}