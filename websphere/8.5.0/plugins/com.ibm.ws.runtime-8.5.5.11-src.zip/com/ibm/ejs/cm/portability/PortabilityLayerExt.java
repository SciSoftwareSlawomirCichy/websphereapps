package com.ibm.ejs.cm.portability;

import java.sql.Connection;
import java.sql.SQLException;

public interface PortabilityLayerExt {
	SQLException translateException(SQLException var1);

	boolean supportsRowLockHint();

	boolean supportsSchema();

	boolean checkCMPStoreOperation(String var1, Connection var2, boolean var3) throws SQLException;

	int getPreferredIsolationLevel();

	boolean supportsExtendedForUpdate(Connection var1) throws SQLException;

	String processSQL(String var1, int var2, boolean var3, boolean var4);
}