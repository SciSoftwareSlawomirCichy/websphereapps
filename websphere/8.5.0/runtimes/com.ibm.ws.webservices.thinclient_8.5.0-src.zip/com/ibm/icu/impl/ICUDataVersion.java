package com.ibm.icu.impl;

import com.ibm.icu.util.UResourceBundle;
import com.ibm.icu.util.VersionInfo;
import java.util.MissingResourceException;

public final class ICUDataVersion {
	private static final String U_ICU_VERSION_BUNDLE = "icuver";
	private static final String U_ICU_STD_BUNDLE = "icustd";
	private static final String U_ICU_DATA_KEY = "DataVersion";

	public static boolean isDataOlder(VersionInfo dataVersionFillin) {
		boolean result = true;
		VersionInfo dataVersion = getDataVersion();
		if (dataVersion != null) {
			if (dataVersion.compareTo(VersionInfo.ICU_DATA_VERSION) != -1) {
				result = false;
			}

			if (dataVersionFillin != null) {
				dataVersionFillin = VersionInfo.getInstance(dataVersion.toString());
			}
		}

		return result;
	}

	public static boolean isDataModified() {
		return !hasICUSTDBundle();
	}

	public static VersionInfo getDataVersion() {
		UResourceBundle icudatares = null;

		try {
			icudatares = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b", "icuver",
					ICUResourceBundle.ICU_DATA_CLASS_LOADER);
			icudatares = icudatares.get("DataVersion");
		} catch (MissingResourceException var2) {
			return null;
		}

		return VersionInfo.getInstance(icudatares.getString());
	}

	private static boolean hasICUSTDBundle() {
		try {
			UResourceBundle.getBundleInstance("icustd");
			return true;
		} catch (MissingResourceException var1) {
			return false;
		}
	}
}