package com.ibm.bsf.util;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;

public class IndentWriter extends PrintWriter {
	public IndentWriter(OutputStream var1) {
		super(var1);
	}

	public IndentWriter(OutputStream var1, boolean var2) {
		super(var1, var2);
	}

	public IndentWriter(Writer var1) {
		super(var1);
	}

	public IndentWriter(Writer var1, boolean var2) {
		super(var1, var2);
	}

	public void print(int var1, String var2) {
		super.print(StringUtils.getChars(var1, ' ') + var2);
	}

	public void println(int var1, String var2) {
		super.println(StringUtils.getChars(var1, ' ') + var2);
	}
}