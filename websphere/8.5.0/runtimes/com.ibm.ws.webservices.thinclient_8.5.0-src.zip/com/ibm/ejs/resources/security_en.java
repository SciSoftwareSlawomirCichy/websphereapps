package com.ibm.ejs.resources;

import java.util.ListResourceBundle;

public class security_en extends ListResourceBundle {
	private static final Object[][] resources = new Object[0][];

	public Object[][] getContents() {
		return resources;
	}
}