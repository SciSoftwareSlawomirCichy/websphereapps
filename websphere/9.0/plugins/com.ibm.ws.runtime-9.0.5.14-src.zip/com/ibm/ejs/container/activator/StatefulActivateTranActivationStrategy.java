package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.StatefulBeanO;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.IllegalOperationException;
import com.ibm.websphere.csi.PassivationPolicy;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;

public class StatefulActivateTranActivationStrategy extends StatefulSessionActivationStrategy {
	private static final TraceComponent tc = Tr.register(StatefulActivateTranActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.activator.StatefulActivateTranActivationStrategy";

	public StatefulActivateTranActivationStrategy(Activator activator, PassivationPolicy policy) {
		super(activator, policy, (SfFailoverCache) null);
	}

	public StatefulActivateTranActivationStrategy(Activator activator, PassivationPolicy policy,
			SfFailoverCache failoverCache) {
		super(activator, policy, failoverCache);
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit: " + bean, tx);
		}

		StatefulBeanO sfbean = (StatefulBeanO) bean;
		Object lock = sfbean.ivCacheLock;
		synchronized (lock) {
			try {
				this.cache.removeElement(sfbean.ivCacheElement, true);
				sfbean.ivCacheKey = null;
				sfbean.setCurrentTx((ContainerTx) null);
				if (!sfbean.isRemoved()) {
					sfbean.passivate();
				} else {
					this.reaper.remove(bean.getId());
				}
			} catch (IllegalOperationException var14) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Ignoring IllegalOperationException. OK for BMT/BMAS case.");
				}

				this.cache.unpinElement(sfbean.ivCacheElement);
				sfbean.setCurrentTx((ContainerTx) null);
			} catch (RemoteException var15) {
				FFDCFilter.processException(var15,
						"com.ibm.ejs.container.activator.StatefulActivateTranActivationStrategy.atCommit", "82", this);
				Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{sfbean, this, var15});
			} finally {
				sfbean.unlock(lock);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCommit: " + bean, tx);
		}

	}

	void atRollback(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRollback: " + bean, tx);
		}

		StatefulBeanO sfbean = (StatefulBeanO) bean;
		Object lock = sfbean.ivCacheLock;
		synchronized (lock) {
			try {
				this.cache.removeElement(sfbean.ivCacheElement, true);
				sfbean.ivCacheKey = null;
				sfbean.setCurrentTx((ContainerTx) null);
				if (!sfbean.isRemoved()) {
					sfbean.passivate();
				} else {
					this.reaper.remove(bean.getId());
				}
			} catch (IllegalOperationException var14) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Ignoring IllegalOperationException. OK for BMT/BMAS case.");
				}

				this.cache.unpinElement(sfbean.ivCacheElement);
				sfbean.setCurrentTx((ContainerTx) null);
			} catch (RemoteException var15) {
				FFDCFilter.processException(var15,
						"com.ibm.ejs.container.activator.StatefulActivateTranActivationStrategy.atRollback", "137",
						this);
				Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{sfbean, this, var15});
			} finally {
				sfbean.unlock(lock);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRollback: " + bean, tx);
		}

	}
}