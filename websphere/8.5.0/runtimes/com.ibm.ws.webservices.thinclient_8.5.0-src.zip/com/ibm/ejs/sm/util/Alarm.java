package com.ibm.ejs.sm.util;

import com.ibm.ejs.util.am.AlarmListener;

public class Alarm implements AlarmListener {
	private long id;

	public Alarm(long id) {
		this.id = id;
	}

	public long getId() {
		return this.id;
	}

	public void alarm(Object alarmContext) {
	}
}