package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.portability.PortableSQLException;
import org.omg.CosTransactions.Status;

class IllegalTransactionStateException extends PortableSQLException {
	private static final long serialVersionUID = 278509287985274262L;

	IllegalTransactionStateException(Status s) {
		super("Operation illegal with transaction state " + s.getClass());
	}

	IllegalTransactionStateException() {
		super("Transaction has been rolledback");
	}
}