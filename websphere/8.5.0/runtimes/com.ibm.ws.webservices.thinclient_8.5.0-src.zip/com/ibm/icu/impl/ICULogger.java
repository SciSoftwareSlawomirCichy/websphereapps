package com.ibm.icu.impl;

import com.ibm.icu.impl.ICULogger.LOGGER_STATUS;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ICULogger extends Logger {
	private static final String GLOBAL_FLAG_TURN_ON_LOGGING = "all";
	private static final String SYSTEM_PROP_LOGGER = "icu4j.debug.logging";
	private LOGGER_STATUS currentStatus;

	private ICULogger(String name, String resourceBundleName) {
		super(name, resourceBundleName);
	}

	private void setStatus(LOGGER_STATUS newStatus) {
		if (this.currentStatus != newStatus) {
			if (this.currentStatus == LOGGER_STATUS.OFF && newStatus == LOGGER_STATUS.ON) {
				this.setLevel(Level.INFO);
			}

			this.currentStatus = newStatus;
			if (this.currentStatus == LOGGER_STATUS.OFF) {
				this.setLevel(Level.OFF);
			}
		}

	}

	private static LOGGER_STATUS checkGlobalLoggingFlag() {
		try {
			String prop = System.getProperty("icu4j.debug.logging");
			if (prop != null) {
				if (prop.equals("all")) {
					return LOGGER_STATUS.ON;
				}

				return LOGGER_STATUS.OFF;
			}
		} catch (SecurityException var1) {
			;
		}

		return LOGGER_STATUS.NULL;
	}

	public static ICULogger getICULogger(String name) {
		return getICULogger(name, (String) null);
	}

	public static ICULogger getICULogger(String name, String resourceBundleName) {
		LOGGER_STATUS flag = checkGlobalLoggingFlag();
		if (flag != LOGGER_STATUS.NULL) {
			ICULogger logger = new ICULogger(name, resourceBundleName);
			logger.addHandler(new ConsoleHandler());
			if (flag == LOGGER_STATUS.ON) {
				logger.turnOnLogging();
			} else {
				logger.turnOffLogging();
			}

			return logger;
		} else {
			return null;
		}
	}

	public boolean isLoggingOn() {
		return this.currentStatus == LOGGER_STATUS.ON;
	}

	public void turnOnLogging() {
		this.setStatus(LOGGER_STATUS.ON);
	}

	public void turnOffLogging() {
		this.setStatus(LOGGER_STATUS.OFF);
	}
}