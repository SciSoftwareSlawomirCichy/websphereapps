package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.websphere.csi.CSIActivitySessionResetException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.websphere.csi.TxContextChange;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import java.rmi.RemoteException;
import javax.transaction.Synchronization;
import javax.transaction.UserTransaction;

public interface UOWControl {
	UOWCookie preInvoke(EJBKey var1, EJBMethodInfoImpl var2) throws RemoteException;

	void postInvoke(EJBKey var1, UOWCookie var2, ExceptionType var3, EJBMethodInfoImpl var4) throws RemoteException;

	boolean getRollbackOnly();

	void setRollbackOnly();

	SynchronizationRegistryUOWScope getCurrentTransactionalUOW(boolean var1) throws CSITransactionRolledbackException;

	Object getCurrentSessionalUOW(boolean var1) throws CSIActivitySessionResetException;

	UserTransaction getUserTransaction();

	void enlistWithTransaction(Synchronization var1) throws CSIException;

	void enlistWithTransaction(SynchronizationRegistryUOWScope var1, Synchronization var2) throws CSIException;

	void enlistWithSession(Synchronization var1) throws CSIException;

	void sessionEnded(EJBKey[] var1) throws CSIException;

	TxContextChange setupLocalTxContext(EJBKey var1) throws CSIException;

	void teardownLocalTxContext(TxContextChange var1);

	boolean isBmtActive(EJBMethodInfoImpl var1);

	boolean isBmasActive(EJBMethodInfoImpl var1);

	UOWHandle suspend() throws CSIException;

	void resume(UOWHandle var1) throws CSIException;

	void completeTxTimeout() throws CSITransactionRolledbackException;
}