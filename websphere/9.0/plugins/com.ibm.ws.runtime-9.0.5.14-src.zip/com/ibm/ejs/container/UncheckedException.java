package com.ibm.ejs.container;

import java.rmi.RemoteException;

public class UncheckedException extends RemoteException {
	private static final long serialVersionUID = 4008328554878328030L;

	public UncheckedException(String s, Throwable ex) {
		super(s, ex);
	}
}