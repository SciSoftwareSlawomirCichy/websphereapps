package javax.ws.rs.core;

public interface PathSegment {
	MultivaluedMap<String, String> getMatrixParameters();

	String getPath();
}