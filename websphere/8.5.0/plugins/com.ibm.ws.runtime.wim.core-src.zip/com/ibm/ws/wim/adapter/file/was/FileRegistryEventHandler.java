package com.ibm.ws.wim.adapter.file.was;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.util.ByteArray;
import com.ibm.websphere.wim.util.Routines;
import com.ibm.ws.wim.management.EventDataWrapper;
import com.ibm.ws.wim.management.EventHandler;
import commonj.sdo.DataObject;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileRegistryEventHandler implements EventHandler {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = FileRegistryEventHandler.class.getName();
	private static final Logger trcLogger;
	private static final String[] EVENT_SUBSCRIPTIONS;
	private Map fdRef = new HashMap();

	public FileRegistryEventHandler(String var1, String var2, FileData var3) {
		this.fdRef.put(var2, var3);
	}

	public void addFileId(String var1, FileData var2) {
		this.fdRef.put(var1, var2);
	}

	private FileData getFileData(String var1) {
		return (FileData) ((FileData) this.fdRef.get(var1));
	}

	public void processEvent(String var1, EventDataWrapper var2) {
		Routines.enterMethod(trcLogger, CLASSNAME, "processEvent", Level.FINE);
		String var4 = (String) var2.get(0);
		FileData var5 = this.getFileData(var4);
		if (var5 != null) {
			try {
				if (this.isListeningToEvent(var1) && var1.equals("websphere.usermanager.fileregistry.change")) {
					if (var2.get(1) instanceof DataObject) {
						var5.load((DataObject) var2.get(1));
					} else if (var2.get(1) instanceof ByteArray) {
						ByteArray var6 = (ByteArray) var2.get(1);
						Routines.logMessage(trcLogger, CLASSNAME, "processEvent", Level.INFO,
								"Size of the byte array: " + var6.size());
						DataObject var7 = (DataObject) Routines.toObject(var6.getByteArray());
						var5.load(var7);
					} else {
						Object[] var13 = var2.getObjects();

						for (int var14 = 0; var14 < var13.length; ++var14) {
							String var8 = var13[var14].getClass().getName();
							StringBuffer var9 = new StringBuffer();
							var9.append("FileRegistry change is reported without a DataObject is unacceptable. <<");
							var9.append("Object Classname: ").append(var8).append(" Object Value: ");
							var9.append(var13[var14].toString()).append(" >>");
							Routines.logMessage(trcLogger, CLASSNAME, "processEvent", Level.WARNING, var9.toString());
						}
					}
				}
			} catch (WIMException var10) {
				Routines.logException(trcLogger, CLASSNAME, "processEvent", Level.WARNING, var10.getMessage(), var10);
			} catch (IOException var11) {
				Routines.logException(trcLogger, CLASSNAME, "processEvent", Level.WARNING, var11.getMessage(), var11);
			} catch (Exception var12) {
				Routines.logException(trcLogger, CLASSNAME, "processEvent", Level.WARNING, var12.getMessage(), var12);
			}
		} else {
			Routines.logMessage(trcLogger, CLASSNAME, "processEvent", Level.INFO,
					"FileRegistryEventHandler got either a null filedata object or a null event change object.");
		}

		Routines.exitMethod(trcLogger, CLASSNAME, "processEvent", Level.FINE);
	}

	public boolean isListeningToEvent(String var1) {
		boolean var2 = false;

		for (int var3 = 0; var3 < EVENT_SUBSCRIPTIONS.length; ++var3) {
			if (EVENT_SUBSCRIPTIONS[var3].equalsIgnoreCase(var1)) {
				var2 = true;
				break;
			}
		}

		return var2;
	}

	public String[] getEventProcessList() {
		return Routines.stringArrayCopy(EVENT_SUBSCRIPTIONS);
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		EVENT_SUBSCRIPTIONS = new String[]{"websphere.usermanager.fileregistry.change"};
	}
}