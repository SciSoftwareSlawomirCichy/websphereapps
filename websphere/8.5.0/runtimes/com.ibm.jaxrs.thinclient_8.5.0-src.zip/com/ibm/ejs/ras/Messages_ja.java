package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_ja extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: インストール済みアプリケーション・サーバー・クライアント・コンポーネントのビルド・レベルで不整合が検出されました。 クライアント・コンポーネント {0} のインストール済みビルド・レベル {1} は、クライアント・コンポーネント {2} のビルド・レベル {3} と異なっています。"},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: インストール済みアプリケーション・サーバー・クライアント・コンポーネントのビルド・レベルの不整合のために、これ以上の実行はできません。"},
			{"EXCP_CWSJE0003E", "CWSJE0003E: 例外 {0} のために、リソース {1} にアクセスできません。"}};

	public Object[][] getContents() {
		return resources;
	}
}