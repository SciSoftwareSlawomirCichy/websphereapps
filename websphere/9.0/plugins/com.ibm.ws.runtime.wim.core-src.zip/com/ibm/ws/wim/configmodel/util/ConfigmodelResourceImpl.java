package com.ibm.ws.wim.configmodel.util;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceImpl;

public class ConfigmodelResourceImpl extends XMLResourceImpl {
	public ConfigmodelResourceImpl(URI var1) {
		super(var1);
	}
}