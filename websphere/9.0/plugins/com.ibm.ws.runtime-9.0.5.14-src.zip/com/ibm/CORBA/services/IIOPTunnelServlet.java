package com.ibm.CORBA.services;

import com.ibm.CORBA.iiop.ORB;
import com.ibm.CORBA.ras.ORBRas;
import com.ibm.CORBA.services.redirector.Redirector;
import com.ibm.CORBA.services.redirector.RedirectorController;
import com.ibm.ffdc.Manager;
import com.ibm.ws.orb.GlobalORBFactory;
import com.ibm.ws.orbimpl.MessageUtility;
import java.io.IOException;
import java.util.Properties;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class IIOPTunnelServlet extends HttpServlet {
	private static final long serialVersionUID = 750467456658215023L;
	protected boolean debug = false;
	protected RedirectorController controller;
	private static final int DEFAULT_MAX_OPEN_SOCKETS = 3;
	private static final String MAX_OPEN_SOCKETS_PROPERTY = "com.ibm.ws.orb.services.redirector.MaxOpenSocketsPerEndpoint";
	private static final String TIMEOUT_PROPERTY = "com.ibm.ws.orb.services.redirector.RequestTimeout";
	private static final String thisClassName = IIOPTunnelServlet.class.getName();

	public void init(ServletConfig config) throws ServletException {
		if (ORBRas.isTrcLogging) {
			ORBRas.orbTrcLogger.entry(2064L, thisClassName, "init()");
		}

		super.init(config);
		this.controller = new RedirectorController();
		ORB orb = getOrb();
		this.getTunnelProperties(orb);
		if (ORBRas.isTrcLogging) {
			ORBRas.orbTrcLogger.exit(2064L, thisClassName, "init()");
		}

	}

	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException {
		if (ORBRas.isTrcLogging) {
			ORBRas.orbTrcLogger.entry(2064L, thisClassName, "service() queryString=" + req.getQueryString());
		}

		String host = "";
		int port = false;
		int begin_idx = false;
		int end_idx = false;
		res.setContentType("ijavaorb/iiop");

		Redirector redirector;
		try {
			String query = req.getQueryString();
			int begin_idx = query.indexOf("debug=true");
			if (begin_idx != -1 || this.debug) {
				this.debug = true;
				this.log("service(): entered...");
			}

			begin_idx = query.indexOf("debug=false");
			if (begin_idx != -1) {
				this.debug = false;
			}

			begin_idx = query.indexOf("host=");
			if (begin_idx == -1) {
				this.log(MessageUtility.getMessage("IIOPTunnelServlet.parsingHost", query));
				return;
			}

			begin_idx += 5;
			int end_idx = query.indexOf(38, begin_idx);
			if (end_idx == -1) {
				end_idx = query.length();
			}

			host = query.substring(begin_idx, end_idx);
			begin_idx = query.indexOf("port=");
			if (begin_idx == -1) {
				this.log(MessageUtility.getMessage("IIOPTunnelServlet.parsingPort", query));
				return;
			}

			begin_idx += 5;
			end_idx = query.indexOf(38, begin_idx);
			if (end_idx == -1) {
				end_idx = query.length();
			}

			int port = Integer.parseInt(query.substring(begin_idx, end_idx));
			if (this.debug) {
				this.log("service(): target host = " + host + " target port = " + port);
			}

			redirector = this.controller.getRedirector(host, port);
		} catch (IOException var11) {
			Manager.Ffdc.log(var11, this, "com.ibm.CORBA.services.IIOPTunnelServlet.service", "188",
					new Object[]{this});
			this.log(MessageUtility.getMessage("IIOPTunnelServlet.IOException", var11.toString()));
			return;
		} catch (Exception var12) {
			Manager.Ffdc.log(var12, this, "com.ibm.CORBA.services.IIOPTunnelServlet.service", "194",
					new Object[]{this});
			String[] args = new String[]{"service()", var12.toString()};
			this.log(MessageUtility.getMessage("IIOPTunnelServlet.Exception", args));
			return;
		}

		if (req.getMethod().equals("POST")) {
			if (this.debug) {
				this.log("service(): About to call redirector.handle() method");
			}

			try {
				redirector.handle(req, res);
			} catch (IOException var10) {
				Manager.Ffdc.log(var10, this, "com.ibm.CORBA.services.IIOPTunnelServlet.service", "217",
						new Object[]{this});
				this.controller.removeRedirector(redirector.getID());
				redirector = null;
				this.log(MessageUtility.getMessage("IIOPTunnelServlet.IOException", var10.toString()));
				return;
			}

			this.controller.checkConnectionTable();
			if (this.debug) {
				this.log("end of service method");
			}

			if (ORBRas.isTrcLogging) {
				ORBRas.orbTrcLogger.exit(2064L, thisClassName, "service()");
			}

		} else {
			this.log(MessageUtility.getMessage("IIOPTunnelServlet.unsupported", req.getMethod()));
		}
	}

	public String getServletInfo() {
		return MessageUtility.getMessage("IIOPTunnelServlet.servletInfo");
	}

	public static ORB getOrb() {
		if (ORBRas.isTrcLogging) {
			ORBRas.orbTrcLogger.entry(2064L, thisClassName, "getOrb()");
		}

		String[] emptyStrArr = null;
		Properties emptyProps = null;
		ORB orb = null;
		orb = GlobalORBFactory.globalORB();
		if (ORBRas.isTrcLogging) {
			ORBRas.orbTrcLogger.exit(2064L, thisClassName, "getOrb()");
		}

		return orb;
	}

	private void getTunnelProperties(ORB orb) {
		String thisMethodName = "getTunnelProperties()";
		if (ORBRas.isTrcLogging) {
			ORBRas.orbTrcLogger.entry(2064L, thisClassName, "getTunnelProperties()");
		}

		int maxOpenSockets = false;
		int requestTimeout = false;
		String timeoutString = orb.getProperty("com.ibm.ws.orb.services.redirector.MaxOpenSocketsPerEndpoint");
		int maxOpenSockets;
		if (timeoutString != null && timeoutString.length() != 0) {
			if (ORBRas.isTrcLogging) {
				ORBRas.orbTrcLogger.trace(4112L, this, "getTunnelProperties()",
						"com.ibm.ws.orb.services.redirector.MaxOpenSocketsPerEndpoint = " + timeoutString);
			}

			try {
				maxOpenSockets = Integer.parseInt(timeoutString);
				if (maxOpenSockets < 0) {
					throw new Exception();
				}
			} catch (Exception var8) {
				if (ORBRas.isTrcLogging) {
					ORBRas.orbTrcLogger.trace(4112L, this, "getTunnelProperties()",
							"The property com.ibm.ws.orb.services.redirector.MaxOpenSocketsPerEndpoint has a value of "
									+ timeoutString + ".  This is not a valid value.  "
									+ "com.ibm.ws.orb.services.redirector.MaxOpenSocketsPerEndpoint"
									+ " has been reset to the default value of " + 3);
				}

				maxOpenSockets = 3;
			}
		} else {
			maxOpenSockets = 3;
			ORBRas.orbTrcLogger.trace(4112L, this, "getTunnelProperties()",
					"com.ibm.ws.orb.services.redirector.MaxOpenSocketsPerEndpoint is defaulting to 3");
		}

		this.controller.setMaxOpenSockets(maxOpenSockets);
		timeoutString = orb.getProperty("com.ibm.ws.orb.services.redirector.RequestTimeout");
		int requestTimeout;
		if (timeoutString != null && timeoutString.length() != 0) {
			if (ORBRas.isTrcLogging) {
				ORBRas.orbTrcLogger.trace(4112L, this, "getTunnelProperties()",
						"com.ibm.ws.orb.services.redirector.RequestTimeout = " + timeoutString + " seconds.");
			}

			try {
				requestTimeout = Integer.parseInt(timeoutString);
				if (requestTimeout < 0) {
					throw new Exception();
				}

				requestTimeout *= 1000;
			} catch (Exception var7) {
				requestTimeout = orb.getRequestTimeout();
				if (ORBRas.isTrcLogging) {
					ORBRas.orbTrcLogger.trace(4112L, this, "getTunnelProperties()",
							"The property com.ibm.ws.orb.services.redirector.RequestTimeout has a value of "
									+ timeoutString + ".  This is not a valid value.  "
									+ "com.ibm.ws.orb.services.redirector.RequestTimeout"
									+ " has been reset to be the same as the value for com.ibm.CORBA.RequestTimeout: "
									+ requestTimeout / 1000 + " seconds.");
				}
			}
		} else {
			requestTimeout = orb.getRequestTimeout();
			ORBRas.orbTrcLogger.trace(4112L, this, "getTunnelProperties()",
					"com.ibm.ws.orb.services.redirector.RequestTimeout is defaulting to the value for com.ibm.CORBA.RequestTimeout: "
							+ requestTimeout / 1000 + " seconds.");
		}

		this.controller.setRequestTimeout(requestTimeout);
		if (ORBRas.isTrcLogging) {
			ORBRas.orbTrcLogger.exit(2064L, thisClassName, "getTunnelProperties()");
		}

	}
}