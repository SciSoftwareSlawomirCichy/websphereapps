package com.google.inject.internal.asm;

class Handler {
	Label a;
	Label b;
	Label c;
	String d;
	int e;
	Handler f;
}