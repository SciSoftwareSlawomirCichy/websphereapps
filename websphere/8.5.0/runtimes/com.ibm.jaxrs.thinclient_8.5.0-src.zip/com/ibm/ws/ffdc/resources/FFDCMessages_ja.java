package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_ja extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: データベースを使用する分析エンジン: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: {0} {1} {2} についての FFDC 発生事象が送出されました。"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE", "FFDC0002I: FFDC ログ・ファイル管理機能がファイル {0} を削除しようとしています。"},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: FFDC ログ・ファイル管理機能がファイルの構成最大経過時間に達した {1} ファイルのうちの {0} ファイルを削除しました。"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE", "FFDC0003I: FFDC ログ・ファイル管理機能がファイル {0} を削除できませんでした。"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST", "FFDC0001W: FFDC ログ・ファイル管理機能が例外ファイルのリストを取得できませんでした。"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC が発生事象ストリーム・ファイル {0} をクローズしました。"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC が発生事象ストリーム・ファイル {0} をオープンしました。"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: FFDC が発生事象ストリーム・ファイル {0} のクローズに失敗しました。例外 {1} をキャッチしました。"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: FFDC が発生事象ストリーム・ファイル {0} のオープンまたは作成に失敗しました。例外 {1} をキャッチしました。"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: FFDC が発生事象ストリーム・ファイル {0} への書き込みに失敗しました。例外 {1} をキャッチしました。"}};

	public Object[][] getContents() {
		return resources;
	}
}