package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import javax.transaction.UserTransaction;

public class CMStatelessBeanO extends StatelessBeanO implements Serializable {
	private static final long serialVersionUID = 6553421454354990950L;
	private static final TraceComponent tc = Tr.register(CMStatelessBeanO.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public CMStatelessBeanO(EJSContainer c, EJSHome h) {
		super(c, h);
	}

	public synchronized UserTransaction getUserTransaction() {
		throw new IllegalStateException(
				"UserTransaction not allowed for Stateless with container managed transactions.");
	}

	private void writeObject(ObjectOutputStream oos) throws IOException {
		String msg = "javax.ejb.SessionContext is not serializable.";
		if (this.home != null) {
			msg = "A javax.ejb.SessionContext object associated with an instance of the "
					+ this.home.j2eeName.getComponent() + " bean in the " + this.home.j2eeName.getModule()
					+ " module in the " + this.home.j2eeName.getApplication() + " application cannot be serialized."
					+ " An EJBContext object is not serializable and cannot be passed as a parameter on a remote method."
					+ " If an instance of the " + this.home.j2eeName.getComponent()
					+ " bean has an instance variable of the SessionContext or EJBContext type, then the bean is also not serializable.";
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "writeObject: throw NotSerializableException : " + msg);
		}

		throw new NotSerializableException(msg);
	}

	private void readObject(ObjectInputStream ois) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "readObject: no-op");
		}

	}
}