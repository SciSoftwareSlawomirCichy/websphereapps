package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.csi.DispatchEventListener;
import com.ibm.ws.csi.DispatchEventListenerCookie;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;
import com.ibm.ws390.sm.smf.SmfContainerInfo;
import com.ibm.ws390.sm.smf.SmfJActivity;

public class DispatchEventListenerManagerImpl implements DispatchEventListenerManager {
	private static final TraceComponent tc = Tr.register(DispatchEventListenerManagerImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private final boolean ivNonSubtype9Recording;
	private DispatchEventListener[] m_dispatchEventListeners;

	public DispatchEventListenerManagerImpl() {
		int recordingStatus = SmfJActivity.smfState();
		this.ivNonSubtype9Recording = (recordingStatus & Integer.MIN_VALUE) == 0
				&& ((recordingStatus & 268435456) == 268435456 || (recordingStatus & 134217728) == 134217728);

		try {
			Class<?> SmfRecorderClass = Class.forName("com.ibm.ws390.sm.smf.SmfDispatchEventRecorder");
			DispatchEventListener SmfRecorder = (DispatchEventListener) SmfRecorderClass.newInstance();
			SmfRecorder.initialize();
			this.m_dispatchEventListeners = new DispatchEventListener[1];
			this.m_dispatchEventListeners[0] = SmfRecorder;
		} catch (Throwable var4) {
			var4.printStackTrace();
		}

	}

	public boolean dispatchEventListenersAreActive() {
		return this.ivNonSubtype9Recording || SmfContainerInfo.isSmf120St9AndCpuUsageEnabled();
	}

	public void callDispatchEventListeners(int dispatchEventCode, DispatchEventListenerCookie[] cookies,
			EJBMethodMetaData methodMetaData) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "callDispatchEventListeners", new Integer(dispatchEventCode));
		}

		int i = 0;
		if (this.m_dispatchEventListeners != null) {
			try {
				for (int i = 0; i < this.m_dispatchEventListeners.length; ++i) {
					switch (dispatchEventCode) {
						case 1 :
							cookies[i] = this.m_dispatchEventListeners[i].beginDispatch(methodMetaData);
							break;
						case 2 :
							this.m_dispatchEventListeners[i].beforeEjbActivate(methodMetaData, cookies[i]);
							break;
						case 3 :
							this.m_dispatchEventListeners[i].afterEjbActivate(methodMetaData, cookies[i]);
							break;
						case 4 :
							this.m_dispatchEventListeners[i].beforeEjbLoad(methodMetaData, cookies[i]);
							break;
						case 5 :
							this.m_dispatchEventListeners[i].afterEjbLoad(methodMetaData, cookies[i]);
							break;
						case 6 :
							this.m_dispatchEventListeners[i].beforeEjbMethod(methodMetaData, cookies[i]);
							break;
						case 7 :
							this.m_dispatchEventListeners[i].afterEjbMethod(methodMetaData, cookies[i]);
							break;
						case 8 :
							this.m_dispatchEventListeners[i].beforeEjbStore(methodMetaData, cookies[i]);
							break;
						case 9 :
							this.m_dispatchEventListeners[i].afterEjbStore(methodMetaData, cookies[i]);
							break;
						case 10 :
							this.m_dispatchEventListeners[i].beforeEjbPassivate(methodMetaData, cookies[i]);
							break;
						case 11 :
							this.m_dispatchEventListeners[i].afterEjbPassivate(methodMetaData, cookies[i]);
							break;
						case 12 :
							this.m_dispatchEventListeners[i].endDispatch(methodMetaData, cookies[i]);
					}
				}
			} catch (Exception var9) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Caught exception " + var9 + " during method " + DispatchEventListener.METHOD_NAME[i]
							+ " on object " + this.m_dispatchEventListeners[i]);
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					var9.printStackTrace();
				}
			} finally {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "callDispatchEventListeners");
				}

			}

		}
	}

	public boolean dispatchEventListenersActive() {
		return this.m_dispatchEventListeners != null;
	}

	public DispatchEventListenerCookie[] getNewDispatchEventListenerCookieArray() {
		return new DispatchEventListenerCookie[this.m_dispatchEventListeners.length];
	}
}