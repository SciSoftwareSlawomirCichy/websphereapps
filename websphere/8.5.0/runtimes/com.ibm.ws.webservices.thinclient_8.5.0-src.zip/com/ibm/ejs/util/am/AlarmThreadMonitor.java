package com.ibm.ejs.util.am;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.am.AlarmThreadMonitor.AlarmThreadCheckDetector;
import com.ibm.ejs.util.am.AlarmThreadMonitor.HungAlarmThreadInfo;
import com.ibm.ffdc.Manager;
import com.ibm.ws.process.Process;
import com.ibm.ws.process.ProcessFactory;
import com.ibm.ws.process.exception.ProcessOpException;
import com.ibm.ws.util.ThreadPool;
import com.ibm.ws.util.ThreadPool.MonitorPlugin;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.HashMap;
import java.util.Map;
import java.util.TooManyListenersException;

public class AlarmThreadMonitor implements MonitorPlugin {
	private static TraceComponent tc = Tr.register(AlarmThreadMonitor.class, "RuntimeUtils",
			"com.ibm.ws.utils.resources.nls.UtilsMessages");
	private static final String svClassName = AlarmThreadMonitor.class.getName();
	private static boolean svCustomPropertyPreviouslyLogged = false;
	private static final String CHECK_INTERVAL_CUSTOM_PROPERTY_NAME = "com.ibm.websphere.alarmthreadmonitor.checkinterval.millis";
	private static final String CHECK_INTERVAL_DEFAULT_VALUE = "10000";
	private static final String GENERATE_JAVA_CORE = "com.ibm.websphere.alarmthreadmonitor.generate.javacore";
	private long ivThresholdMillis = 0L;
	private AlarmThreadCheckDetector ivAlarmThreadCheckDetector;
	private Process proc = null;
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");
	private static final String svGenerateJavaCore = System
			.getProperty("com.ibm.websphere.alarmthreadmonitor.generate.javacore");
	private static final String svThresholdProperty = System
			.getProperty("com.ibm.websphere.alarmthreadmonitor.checkinterval.millis");
	private static final String HUNG_ALARM_THROTTLE_CUSTOM_PROPERTY_NAME = "com.ibm.websphere.alarmthreadmonitor.hung_alarm_mute";
	private static final int HUNG_ALARM_THROTTLE_DEFAULT = 0;
	protected int ivHungThreadThrottle = Integer.getInteger("com.ibm.websphere.alarmthreadmonitor.hung_alarm_mute", 0);
	protected Map<String, HungAlarmThreadInfo> ivHungThreadThrottleTable = new HashMap();

	public AlarmThreadMonitor(ThreadPool threadPool, long threshold) {
		try {
			threadPool.setMonitorPlugin(this);
			this.ivThresholdMillis = threshold;
			this.ivAlarmThreadCheckDetector = new AlarmThreadCheckDetector(this, threadPool);
			Thread threadCheckSchedulerThread = new Thread(this.ivAlarmThreadCheckDetector);
			threadCheckSchedulerThread.setDaemon(true);
			threadCheckSchedulerThread.setName("HungThreadDetectorFor" + threadPool.getName());
			threadCheckSchedulerThread.start();
		} catch (TooManyListenersException var5) {
			Manager.Ffdc.log(var5, this, svClassName, "72", new Object[]{this});
		} catch (Throwable var6) {
			Tr.debug(tc, "Alarm threadPool hungthread monitoring disabled", var6);
		}

	}

	public boolean checkThread(Thread thread, String threadId, long timeActiveInMillis) {
		if (this.isThreadHung(thread.getName(), threadId, timeActiveInMillis)) {
			this.threadIsHung(thread.getName(), threadId, timeActiveInMillis);
			return true;
		} else {
			return false;
		}
	}

	public void trackThread(Thread thread, String threadId, long timeActiveInMillis) {
	}

	public void clearThread(Thread thread, String threadId, long timeActiveInMillis) {
		Tr.warning(tc, "UTLS0009", new Object[]{thread.getName(), threadId, new Long(timeActiveInMillis)});
		this.ivHungThreadThrottleTable.put(thread.getName(), (Object) null);
	}

	public void stopMonitoring() {
		this.ivAlarmThreadCheckDetector.stop();
	}

	public String dumpThread(Thread thread, String threadId, long timeActiveInMillis) {
		return "";
	}

	private boolean isThreadHung(String threadName, String threadNumber, long timeActiveInMills) {
		return timeActiveInMills > this.ivThresholdMillis;
	}

	private void threadIsHung(String threadName, String threadNumber, long timeActiveInMillis) {
		String stack = " ";

		try {
			ThreadMXBean mxbean = ManagementFactory.getThreadMXBean();
			ThreadInfo[] threadInfo = mxbean.getThreadInfo(mxbean.getAllThreadIds());
			long threadId = -1L;

			for (int i = 0; i < threadInfo.length; ++i) {
				if (threadInfo[i] != null && threadInfo[i].getThreadName().equals(threadName)) {
					threadId = threadInfo[i].getThreadId();
					break;
				}
			}

			if (threadId != -1L) {
				ThreadInfo ti = mxbean.getThreadInfo(threadId, Integer.MAX_VALUE);
				if (ti != null) {
					StackTraceElement[] st = ti.getStackTrace();
					stack = getThrottledStackTraceString(threadName, threadId, st, this.ivHungThreadThrottle,
							this.ivHungThreadThrottleTable);
				}
			}
		} catch (Exception var12) {
			Manager.Ffdc.log(var12, this, svClassName, "149", new Object[]{this});
		}

		Tr.warning(tc, "UTLS0008", new Object[]{threadName, threadNumber, new Long(timeActiveInMillis), stack});
		if (svGenerateJavaCore != null) {
			this.dumpThreads();
		}

	}

	public static final String getThrottledStackTraceString(String threadName, long threadId, StackTraceElement[] st,
			int hungThreadThrottle, Map<String, HungAlarmThreadInfo> hungThreadThrottleTable) {
		StringBuilder sb = new StringBuilder();
		String previousSteString = null;

		for (int i = 0; i < st.length; ++i) {
			StackTraceElement ste = st[i];
			String steString = ste.toString();
			sb.append(LINE_SEPARATOR).append("\tat ").append(steString);
			if (hungThreadThrottle > 0) {
				Class refclass;
				try {
					refclass = Class.forName(ste.getClassName());
				} catch (ClassNotFoundException var16) {
					Tr.debug(tc, "getThrottledStackTraceString: Failed class lookup for possible handler "
							+ ste.getClassName());
					refclass = Object.class;
				}

				if (ste.getMethodName().equals("run") && _Alarm.class.isAssignableFrom(refclass)) {
					synchronized (hungThreadThrottleTable) {
						HungAlarmThreadInfo instanceCounter = (HungAlarmThreadInfo) hungThreadThrottleTable
								.get(threadName);
						if (instanceCounter == null) {
							hungThreadThrottleTable.put(threadName, new HungAlarmThreadInfo(previousSteString));
						} else {
							int count = instanceCounter.timesSeen();
							if (count < 0) {
								instanceCounter.set(count = hungThreadThrottle + 1);
							}

							if (count > hungThreadThrottle) {
								sb.setLength(0);
								sb.append(LINE_SEPARATOR).append("\t[...] at ").append(previousSteString)
										.append(" [...]");
								break;
							}
						}
					}
				}

				previousSteString = steString;
			}
		}

		return sb.toString();
	}

	public void dumpThreads() {
		Tr.entry(tc, "dumpThreads");
		if (this.proc == null) {
			try {
				this.proc = ProcessFactory.createSelf();
			} catch (ProcessOpException var3) {
				Manager.Ffdc.log(var3, this, svClassName, "177", new Object[]{this});
			}
		}

		try {
			this.proc.generateJVMDump();
		} catch (ProcessOpException var2) {
			Manager.Ffdc.log(var2, this, svClassName, "188", new Object[]{this});
		}

		Tr.exit(tc, "dumpThreads");
	}
}