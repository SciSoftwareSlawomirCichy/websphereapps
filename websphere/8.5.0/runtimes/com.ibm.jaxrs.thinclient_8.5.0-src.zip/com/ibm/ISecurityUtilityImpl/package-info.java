package com.ibm.ISecurityUtilityImpl;

interface package-info {
}