package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.security.cmskeystore.CMSLoadStoreParameterFactory;
import com.ibm.websphere.ssl.SSLException;
import com.ibm.ws.ssl.JSSEProvider;
import com.ibm.ws.ssl.JSSEProviderFactory;
import com.ibm.ws.util.PlatformHelperFactory;
import java.io.File;
import java.lang.reflect.Constructor;
import java.security.KeyStore;
import java.security.KeyStore.LoadStoreParameter;
import java.security.KeyStore.PasswordProtection;

public class CMSKeyStoreUtility {
	private static final TraceComponent tc = Tr.register(CMSKeyStoreUtility.class, "SSL",
			"com.ibm.ws.ssl.resources.ssl");

	public void storeCMSKeyStore(KeyStore ks, String SSLKeyFile, String SSLKeyPassword, String SSLKeyStoreType,
			String SSLKeyStoreStash) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "storeCMSKeyStore");
		}

		LoadStoreParameter loadParm = null;
		File sslKeyFile = new File(SSLKeyFile);
		if (PlatformHelperFactory.getPlatformHelper().isOS400()
				&& System.getProperty("java.vm.name").equals("Classic VM")) {
			try {
				ClassLoader cl = Thread.currentThread().getContextClassLoader();
				Class permClass = null;
				if (cl != null) {
					permClass = cl.loadClass("com.ibm.i5os.keystore.i5OSLoadStoreParameter");
				} else {
					permClass = Class.forName("com.ibm.i5os.keystore.i5OSLoadStoreParameter");
				}

				PasswordProtection protection = new PasswordProtection(SSLKeyPassword.toCharArray());
				Constructor constructor = permClass.getConstructor(File.class, PasswordProtection.class);
				loadParm = (LoadStoreParameter) constructor.newInstance(sslKeyFile, protection);
			} catch (Exception var13) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not load iSeries LoadStoreParameter to store the CMS keystore.",
							new Object[]{var13});
				}

				throw new SSLException(var13.getMessage(), var13);
			}
		} else if (SSLKeyStoreType.equals("CMSKS") && SSLKeyStoreStash != null && SSLKeyStoreStash.equals("true")) {
			loadParm = CMSLoadStoreParameterFactory.newCMSStoreParameter(sslKeyFile,
					new PasswordProtection(SSLKeyPassword.toCharArray()), true);
		} else if (SSLKeyStoreType.equals("CMSKS")) {
			loadParm = CMSLoadStoreParameterFactory.newCMSStoreParameter(sslKeyFile,
					new PasswordProtection(SSLKeyPassword.toCharArray()), false);
		}

		if (loadParm != null) {
			try {
				ks.store(loadParm);
			} catch (Exception var12) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Could not store the keystore.", new Object[]{var12});
				}

				throw new SSLException(var12.getMessage(), var12);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "storeCMSKeyStore");
		}

	}

	public KeyStore loadCMSKeyStore(File kFile, String keyStoreLocation, String SSLKeyPassword, String SSLKeyStoreType,
			String SSLKeyStoreProvider, String SSLKeyStoreStash) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadCMSKeyStore");
		}

		KeyStore ks1 = null;

		try {
			LoadStoreParameter loadParm = null;
			if (PlatformHelperFactory.getPlatformHelper().isOS400()
					&& System.getProperty("java.vm.name").equals("Classic VM")) {
				ClassLoader cl = Thread.currentThread().getContextClassLoader();
				Class permClass = null;
				if (cl != null) {
					permClass = cl.loadClass("com.ibm.i5os.keystore.i5OSLoadStoreParameter");
				} else {
					permClass = Class.forName("com.ibm.i5os.keystore.i5OSLoadStoreParameter");
				}

				PasswordProtection protection = new PasswordProtection(SSLKeyPassword.toCharArray());
				Constructor constructor = permClass.getConstructor(File.class, PasswordProtection.class);
				loadParm = (LoadStoreParameter) constructor.newInstance(kFile, protection);
			} else if (SSLKeyStoreType.equals("CMSKS") && SSLKeyStoreStash != null && SSLKeyStoreStash.equals("true")) {
				loadParm = CMSLoadStoreParameterFactory.newCMSLoadParameter(kFile,
						new PasswordProtection(SSLKeyPassword.toCharArray()));
			} else if (SSLKeyStoreType.equals("CMSKS")) {
				loadParm = CMSLoadStoreParameterFactory.newCMSLoadParameter(kFile,
						new PasswordProtection(SSLKeyPassword.toCharArray()));
			}

			if (loadParm != null) {
				JSSEProvider jsseProvider = JSSEProviderFactory.getInstance(SSLKeyStoreProvider);
				ks1 = jsseProvider.getKeyStoreInstance(SSLKeyStoreType, SSLKeyStoreProvider);
				ks1.load(loadParm);
			}
		} catch (Exception var13) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception loading the CMS keystore.", new Object[]{var13});
			}

			throw new SSLException(var13.getMessage(), var13);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadCMSKeyStore");
		}

		return ks1;
	}
}