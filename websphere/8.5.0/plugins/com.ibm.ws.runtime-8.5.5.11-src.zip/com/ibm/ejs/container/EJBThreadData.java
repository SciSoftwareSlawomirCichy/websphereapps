package com.ibm.ejs.container;

import com.ibm.ejs.j2c.HandleListInterface;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.FastStack;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.csi.CSIException;
import com.ibm.ws.runtime.metadata.ComponentMetaData;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import com.ibm.ws.threadContext.ConnectionHandleAccessorImpl;
import com.ibm.ws.threadContext.EJSDeployedSupportAccessorImpl;
import com.ibm.ws.threadContext.ThreadContext;
import com.ibm.ws.threadContext.ThreadContextImpl;
import com.ibm.ws.util.ThreadContextAccessor;
import java.util.HashMap;
import java.util.Map;

public class EJBThreadData {
	private static final String CLASS_NAME = EJBThreadData.class.getName();
	private static final TraceComponent tc;
	static ThreadContextAccessor svThreadContextAccessor;
	private final FastStack<Object> ivClassLoaderStack = new FastStack();
	final ThreadContext<HandleListInterface> ivHandleListContext = getCurrentThreadContext(
			ConnectionHandleAccessorImpl.getConnectionHandleAccessor().getThreadContext());
	final ThreadContext<EJSDeployedSupport> ivEJSDeployedSupportContext = getCurrentThreadContext(
			EJSDeployedSupportAccessorImpl.getEJSDeployedSupportAccessor().getThreadContext());
	final ThreadContext<ComponentMetaData> ivComponentMetaDataContext = getCurrentThreadContext(
			ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor().getThreadContext());
	private EJBMethodInfoStack ivEJBMethodInfoStack;
	CMP11CustomFinderAccIntentState ivCMP11CustomFinderAccIntentState;
	private FastStack<BeanO> ivCallbackBeanOStack = new FastStack();
	int ivLifecycleMethodContextIndex = -1;
	Map<String, Object> ivLifecycleContextData;

	private static <T> ThreadContext<T> getCurrentThreadContext(ThreadContext<T> threadContext) {
		return (ThreadContext) ((ThreadContextImpl) threadContext).get();
	}

	public EJSDeployedSupport getMethodContext() {
		return (EJSDeployedSupport) this.ivEJSDeployedSupportContext.getContext();
	}

	EJBMethodInfoStack getEJBMethodInfoStack() {
		if (this.ivEJBMethodInfoStack == null) {
			this.ivEJBMethodInfoStack = new EJBMethodInfoStack(8);
		}

		return this.ivEJBMethodInfoStack;
	}

	public BeanO getCallbackBeanO() {
		BeanO result = (BeanO) this.ivCallbackBeanOStack.peek();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getCallbackBeanO: " + result);
		}

		return result;
	}

	public void pushCallbackBeanO(BeanO bean) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "pushCallbackBeanO: " + bean);
		}

		HandleListInterface hl = bean.reAssociateHandleList();
		this.ivHandleListContext.beginContext(hl);
		this.ivCallbackBeanOStack.push(bean);
	}

	public void popCallbackBeanO() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "popCallbackBeanO: " + this.ivCallbackBeanOStack.peek());
		}

		this.ivHandleListContext.endContext();
		BeanO beanO = (BeanO) this.ivCallbackBeanOStack.pop();
		beanO.parkHandleList();
	}

	void pushClassLoader(BeanMetaData bmd) {
		ClassLoader classLoader = bmd.ivContextClassLoader;
		Object origCL = svThreadContextAccessor.pushContextClassLoaderForUnprivileged(classLoader);
		this.ivClassLoaderStack.push(origCL);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc,
					"pushClassLoader: " + (origCL == ThreadContextAccessor.UNCHANGED
							? "already " + Util.identity(classLoader)
							: Util.identity(origCL) + " -> " + Util.identity(classLoader)));
		}

	}

	private void popClassLoader(String method) {
		Object origCL;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			origCL = this.ivClassLoaderStack.peek();
			ClassLoader currentCL = svThreadContextAccessor
					.getContextClassLoaderForUnprivileged(Thread.currentThread());
			Tr.debug(tc,
					method + ": "
							+ (origCL == ThreadContextAccessor.UNCHANGED
									? "leaving " + Util.identity(currentCL)
									: Util.identity(currentCL) + " -> " + Util.identity(origCL)));
		}

		origCL = this.ivClassLoaderStack.pop();
		svThreadContextAccessor.popContextClassLoaderForUnprivileged(origCL);
	}

	void popClassLoader() {
		this.popClassLoader("popClassLoader");
	}

	void popORBWrapperClassLoader() {
		this.popClassLoader("popORBWrapperClassLoader");
		this.ivClassLoaderStack.push(ThreadContextAccessor.UNCHANGED);
	}

	public void pushContexts(BeanO beanO) throws CSIException {
		this.pushCallbackBeanO(beanO);
		BeanMetaData bmd = beanO.home.beanMetaData;
		this.ivComponentMetaDataContext.beginContext(bmd);
		this.pushClassLoader(bmd);
	}

	public void popContexts() {
		this.popClassLoader();
		this.ivComponentMetaDataContext.endContext();
		this.popCallbackBeanO();
	}

	public boolean isLifecycleMethodActive() {
		return this.ivLifecycleMethodContextIndex == this.ivEJSDeployedSupportContext.getContextIndex();
	}

	public Map<String, Object> getContextData() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		Map contextData;
		if (this.isLifecycleMethodActive()) {
			if (this.ivLifecycleContextData == null) {
				this.ivLifecycleContextData = new HashMap();
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "getContextData: created empty");
				}
			} else if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "getContextData: lifecycle");
			}

			contextData = this.ivLifecycleContextData;
		} else {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "getContextData: method");
			}

			EJSDeployedSupport s = this.getMethodContext();
			if (s == null) {
				IllegalStateException ex = new IllegalStateException(
						"Context data not available outside the scope of an EJB or lifecycle callback method");
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "getContextData: " + ex);
				}

				throw ex;
			}

			contextData = s.getContextData();
		}

		return contextData;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		svThreadContextAccessor = (ThreadContextAccessor) AccessController
				.doPrivileged(ThreadContextAccessor.getPrivilegedAction());
	}
}