package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.Type;

public interface ProcessArrayCallback {
	void processElement(Type var1);
}