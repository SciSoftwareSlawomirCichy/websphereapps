package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Synchronized.1;
import com.google.common.collect.Synchronized.SynchronizedBiMap;
import com.google.common.collect.Synchronized.SynchronizedCollection;
import com.google.common.collect.Synchronized.SynchronizedEntry;
import com.google.common.collect.Synchronized.SynchronizedList;
import com.google.common.collect.Synchronized.SynchronizedListMultimap;
import com.google.common.collect.Synchronized.SynchronizedMap;
import com.google.common.collect.Synchronized.SynchronizedMultimap;
import com.google.common.collect.Synchronized.SynchronizedMultiset;
import com.google.common.collect.Synchronized.SynchronizedNavigableMap;
import com.google.common.collect.Synchronized.SynchronizedNavigableSet;
import com.google.common.collect.Synchronized.SynchronizedQueue;
import com.google.common.collect.Synchronized.SynchronizedRandomAccessList;
import com.google.common.collect.Synchronized.SynchronizedSet;
import com.google.common.collect.Synchronized.SynchronizedSetMultimap;
import com.google.common.collect.Synchronized.SynchronizedSortedMap;
import com.google.common.collect.Synchronized.SynchronizedSortedSet;
import com.google.common.collect.Synchronized.SynchronizedSortedSetMultimap;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Queue;
import java.util.RandomAccess;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
final class Synchronized {
	private static <E> Collection<E> collection(Collection<E> collection, @Nullable Object mutex) {
      return new SynchronizedCollection(collection, mutex, (1)null);
   }

	@VisibleForTesting
	static <E> Set<E> set(Set<E> set, @Nullable Object mutex) {
		return new SynchronizedSet(set, mutex);
	}

	private static <E> SortedSet<E> sortedSet(SortedSet<E> set, @Nullable Object mutex) {
		return new SynchronizedSortedSet(set, mutex);
	}

	private static <E> List<E> list(List<E> list, @Nullable Object mutex) {
		return (List) (list instanceof RandomAccess
				? new SynchronizedRandomAccessList(list, mutex)
				: new SynchronizedList(list, mutex));
	}

	static <E> Multiset<E> multiset(Multiset<E> multiset, @Nullable Object mutex) {
		return (Multiset) (!(multiset instanceof SynchronizedMultiset) && !(multiset instanceof ImmutableMultiset)
				? new SynchronizedMultiset(multiset, mutex)
				: multiset);
	}

	static <K, V> Multimap<K, V> multimap(Multimap<K, V> multimap, @Nullable Object mutex) {
		return (Multimap) (!(multimap instanceof SynchronizedMultimap) && !(multimap instanceof ImmutableMultimap)
				? new SynchronizedMultimap(multimap, mutex)
				: multimap);
	}

	static <K, V> ListMultimap<K, V> listMultimap(ListMultimap<K, V> multimap, @Nullable Object mutex) {
		return (ListMultimap) (!(multimap instanceof SynchronizedListMultimap)
				&& !(multimap instanceof ImmutableListMultimap)
						? new SynchronizedListMultimap(multimap, mutex)
						: multimap);
	}

	static <K, V> SetMultimap<K, V> setMultimap(SetMultimap<K, V> multimap, @Nullable Object mutex) {
		return (SetMultimap) (!(multimap instanceof SynchronizedSetMultimap)
				&& !(multimap instanceof ImmutableSetMultimap)
						? new SynchronizedSetMultimap(multimap, mutex)
						: multimap);
	}

	static <K, V> SortedSetMultimap<K, V> sortedSetMultimap(SortedSetMultimap<K, V> multimap, @Nullable Object mutex) {
		return (SortedSetMultimap) (multimap instanceof SynchronizedSortedSetMultimap
				? multimap
				: new SynchronizedSortedSetMultimap(multimap, mutex));
	}

	private static <E> Collection<E> typePreservingCollection(Collection<E> collection, @Nullable Object mutex) {
		if (collection instanceof SortedSet) {
			return sortedSet((SortedSet) collection, mutex);
		} else if (collection instanceof Set) {
			return set((Set) collection, mutex);
		} else {
			return (Collection) (collection instanceof List
					? list((List) collection, mutex)
					: collection(collection, mutex));
		}
	}

	private static <E> Set<E> typePreservingSet(Set<E> set, @Nullable Object mutex) {
		return (Set) (set instanceof SortedSet ? sortedSet((SortedSet) set, mutex) : set(set, mutex));
	}

	@VisibleForTesting
	static <K, V> Map<K, V> map(Map<K, V> map, @Nullable Object mutex) {
		return new SynchronizedMap(map, mutex);
	}

	static <K, V> SortedMap<K, V> sortedMap(SortedMap<K, V> sortedMap, @Nullable Object mutex) {
		return new SynchronizedSortedMap(sortedMap, mutex);
	}

	static <K, V> BiMap<K, V> biMap(BiMap<K, V> bimap, @Nullable Object mutex) {
      return (BiMap)(!(bimap instanceof SynchronizedBiMap) && !(bimap instanceof ImmutableBiMap) ? new SynchronizedBiMap(bimap, mutex, (BiMap)null, (1)null) : bimap);
   }

	@GwtIncompatible("NavigableSet")
	static <E> NavigableSet<E> navigableSet(NavigableSet<E> navigableSet, @Nullable Object mutex) {
		return new SynchronizedNavigableSet(navigableSet, mutex);
	}

	@GwtIncompatible("NavigableSet")
	static <E> NavigableSet<E> navigableSet(NavigableSet<E> navigableSet) {
		return navigableSet(navigableSet, (Object) null);
	}

	@GwtIncompatible("NavigableMap")
	static <K, V> NavigableMap<K, V> navigableMap(NavigableMap<K, V> navigableMap) {
		return navigableMap(navigableMap, (Object) null);
	}

	@GwtIncompatible("NavigableMap")
	static <K, V> NavigableMap<K, V> navigableMap(NavigableMap<K, V> navigableMap, @Nullable Object mutex) {
		return new SynchronizedNavigableMap(navigableMap, mutex);
	}

	@GwtIncompatible("works but is needed only for NavigableMap")
	private static <K, V> Entry<K, V> nullableSynchronizedEntry(@Nullable Entry<K, V> entry, @Nullable Object mutex) {
		return entry == null ? null : new SynchronizedEntry(entry, mutex);
	}

	static <E> Queue<E> queue(Queue<E> queue, @Nullable Object mutex) {
		return (Queue) (queue instanceof SynchronizedQueue ? queue : new SynchronizedQueue(queue, mutex));
	}
}