package com.ibm.ws.security.oidc.client.filter;

public class EqualCondition extends SimpleCondition {
	public EqualCondition(String key, IValue value) {
		super(key, value);
	}

	public boolean checkCondition(IValue test) throws FilterException {
		return this.getValue().equals(test);
	}

	public String getOperand() {
		return "==";
	}
}