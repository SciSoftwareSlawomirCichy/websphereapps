package com.ibm.ejs.cm.pool;

import java.util.EventListener;

public interface ConnectOEventListener extends EventListener {
	void connectionEnlisted(ConnectO var1, Object var2);

	void connectionDestroyed(ConnectO var1);

	boolean connectionIdleTimeout(ConnectO var1);

	boolean connectionAgedTimeout(ConnectO var1);

	void connectionTxComplete(ConnectO var1, int var2, Object var3);

	void connectionOrphaned(ConnectO var1);

	void setDestroyed(ConnectO var1);
}