package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: An inconsistency in the build levels of installed application server client components was detected. The installed build level of client component {0} which is {1} is different to the build level of client component {2} which is {3}."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: An inconsistency in the build levels of installed application server client components prevents further execution."},
			{"EXCP_CWSJE0003E", "CWSJE0003E: Unable to access resource {1} because of exception: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}