package com.ibm.ejs.container;

interface package-info {
}