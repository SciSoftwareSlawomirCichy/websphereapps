package com.ibm.ejs.container;

public class EJBNotFoundException extends ClassNotFoundException {
	private static final long serialVersionUID = -7732975938299597918L;

	public EJBNotFoundException(String j2eeName) {
		super(j2eeName);
	}

	public EJBNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
}