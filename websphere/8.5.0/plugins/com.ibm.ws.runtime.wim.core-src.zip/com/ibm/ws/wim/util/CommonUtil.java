package com.ibm.ws.wim.util;

import com.ibm.websphere.cache.DistributedObjectCache;
import com.ibm.websphere.cache.DynamicCacheAccessor;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.wsspi.cache.DistributedObjectCacheFactory;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CommonUtil {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static Map<String, Boolean> isDynaCacheServiceStarted;

	public static DistributedObjectCache initDistributedCache(String var0, int var1, boolean var2) {
		return initDistributedCache(var0, var1, var2, 2);
	}

	public static DistributedObjectCache initDistributedCache(String var0, int var1, boolean var2, int var3) {
		if (DynamicCacheAccessor.isCachingEnabled()) {
			Properties var4 = new Properties();
			var4.put("com.ibm.ws.cache.CacheConfig.cacheSize", String.valueOf(var1));
			var4.put("com.ibm.ws.cache.CacheConfig.enableDiskOffload", String.valueOf(var2));
			DistributedObjectCache var5 = DistributedObjectCacheFactory.getMap(var0, var4);
			if (var5 != null) {
				var5.setSharingPolicy(var3);
				trcLogger.logp(Level.FINE, CLASSNAME, "initDistributedCache", "DistributedObjectCache found");
				return var5;
			} else {
				trcLogger.logp(Level.FINE, CLASSNAME, "initDistributedCache", "DistributedObjectCache NOT found");
				return null;
			}
		} else {
			return null;
		}
	}

	public static boolean isDistributedCacheAvailable() {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isDistributedCacheAvailable");
		}

		String var1 = DomainManagerUtils.getDomainId();
		if (isDynaCacheServiceStarted.get(var1) == null) {
			isDynaCacheServiceStarted.put(var1, new Boolean(false));
		}

		if ((Boolean) isDynaCacheServiceStarted.get(var1)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "isDistributedCacheAvailable", "DynaCache service started");
			return true;
		} else {
			try {
				Class.forName("com.ibm.websphere.cache.DynamicCacheAccessor");

				try {
					initDistributedCache("WIMInitCache", 1, false, 2);
					isDynaCacheServiceStarted.put(var1, new Boolean(true));
				} catch (NullPointerException var3) {
					trcLogger.logp(Level.FINE, CLASSNAME, "isDistributedCacheAvailable", "DynaCache not enabled");
				}
			} catch (ClassNotFoundException var4) {
				trcLogger.logp(Level.FINE, CLASSNAME, "isDistributedCacheAvailable", "DynaCache service not running");
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "isDistributedCacheAvailable", isDynaCacheServiceStarted);
			}

			return (Boolean) isDynaCacheServiceStarted.get(var1);
		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = CommonUtil.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		isDynaCacheServiceStarted = Collections.synchronizedMap(new HashMap());
	}
}