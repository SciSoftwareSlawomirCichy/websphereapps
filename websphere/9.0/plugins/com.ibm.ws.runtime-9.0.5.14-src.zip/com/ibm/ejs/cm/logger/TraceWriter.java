package com.ibm.ejs.cm.logger;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.StringWriter;

public class TraceWriter extends StringWriter {
	private final TraceComponent destination;
	private static final TraceComponent tc = Tr.register(TraceWriter.class);

	public TraceWriter(TraceComponent dest) {
		this.destination = dest;
	}

	public TraceWriter(String componentName) {
		this.destination = Tr.register(componentName);
	}

	public void flush() {
		Object var1 = this.lock;
		synchronized (this.lock) {
			super.flush();
			this.formatTrace();
		}
	}

	public void write(char[] cbuf, int off, int len) {
		Object var4 = this.lock;
		synchronized (this.lock) {
			super.write(cbuf, off, len);
			this.formatTrace();
		}
	}

	public void write(int b) {
		Object var2 = this.lock;
		synchronized (this.lock) {
			super.write(b);
			if (b == 10) {
				this.formatTrace();
			}

		}
	}

	public void write(String str) {
		Object var2 = this.lock;
		synchronized (this.lock) {
			super.write(str);
			this.formatTrace();
		}
	}

	public void write(String str, int off, int len) {
		Object var4 = this.lock;
		synchronized (this.lock) {
			super.write(str, off, len);
			this.formatTrace();
		}
	}

	public boolean isTraceEnabled() {
		return this.destination.isDebugEnabled();
	}

	private void formatTrace() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "formatTrace");
		}

		String str = this.toString();
		int start = 0;

		for (int end = str.indexOf(10); end >= 0; end = str.indexOf(10, start)) {
			Tr.debug(this.destination, str.substring(start, end));
			start = end + 1;
		}

		this.getBuffer().delete(0, start);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "formatTrace");
		}

	}
}