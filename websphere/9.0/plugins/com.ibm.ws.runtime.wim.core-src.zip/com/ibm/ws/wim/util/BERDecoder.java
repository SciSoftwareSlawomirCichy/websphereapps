package com.ibm.ws.wim.util;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public class BERDecoder implements BERConstants {
	static final String COPYRIGHT_NOTICE;
	protected InputStream input;
	protected DecStack currStack;
	protected int stackIndex;
	protected int stackPos;
	protected int readOctets;
	protected boolean pushedBack;
	protected int implicitTag;
	protected int actualTag;
	protected int tag;
	protected boolean constructed;
	protected int valueLength;
	protected int tlbIndex;
	protected byte[] tagLenBuf;

	protected void throwException(String var1) throws Exception {
		throw new Exception(var1 + " (offset " + this.readOctets + ")");
	}

	protected int getOctet() throws Exception {
		try {
			int var1 = this.input.read();
			if (var1 < 0) {
				throw new Exception(new EOFException("Unexpected end of input data"));
			} else {
				++this.readOctets;
				return var1;
			}
		} catch (IOException var2) {
			throw new Exception(var2);
		}
	}

	public int getActualTag() {
		return this.actualTag;
	}

	protected final void pushBack() {
		this.pushedBack = true;
	}

	protected boolean decodeTagAndLength() throws Exception {
		if (this.pushedBack) {
			this.pushedBack = false;
			return true;
		} else {
			int var1 = this.currStack.stack[this.stackIndex];
			if ((var1 < 0 || this.readOctets < var1) && this.tag != 0) {
				byte var2 = 0;
				int var3 = this.getOctet();
				this.constructed = (var3 & 32) != 0;
				this.tlbIndex = 1;
				this.tagLenBuf[0] = (byte) var3;
				this.actualTag = var3;
				switch (var3 & 192) {
					case 0 :
						var2 = 0;
						break;
					case 64 :
						var2 = 1;
						break;
					case 128 :
						var2 = 2;
						break;
					case 192 :
						var2 = 3;
				}

				this.tag = var3 & 31;
				long var4;
				if (this.tag == 31) {
					var4 = 0L;

					do {
						this.tagLenBuf[this.tlbIndex++] = (byte) (var3 = this.getOctet());
						var4 = (var4 << 7) + (long) (var3 & 127);
						if (var4 > 1073741823L) {
							this.throwException("Tag number too big");
						}
					} while ((var3 & 128) != 0);

					this.tag = (int) var4;
				}

				this.tag = ASN1Tag.makeTag(var2, this.tag);
				this.tagLenBuf[this.tlbIndex++] = (byte) (this.valueLength = this.getOctet());
				if (this.valueLength >= 128) {
					if (this.valueLength == 128) {
						this.valueLength = -1;
						return true;
					}

					var4 = 0L;

					for (int var6 = this.valueLength & 127; var6 > 0; --var6) {
						this.tagLenBuf[this.tlbIndex++] = (byte) (var3 = this.getOctet());
						var4 = var4 << 8 | (long) var3;
						if (var4 >= 2147483648L) {
							this.throwException("Length value too big");
						}
					}

					this.valueLength = (int) var4;
				}

				return this.tag != 0;
			} else {
				return false;
			}
		}
	}

	protected void push(int var1) {
		if ((this.stackIndex += 2) >= this.currStack.stack.length) {
			if (this.currStack.next == null) {
				DecStack var2 = this.currStack.next = new DecStack();
				var2.prev = this.currStack;
				var2.next = null;
				var2.stack = new int[this.currStack.stack.length];
			}

			this.currStack = this.currStack.next;
			this.stackIndex = 0;
		}

		this.currStack.stack[this.stackIndex] = this.valueLength >= 0 ? this.readOctets + this.valueLength : -1;
		this.currStack.stack[this.stackIndex + 1] = var1;
		++this.stackPos;
	}

	protected void pop() throws Exception {
		int var1 = this.currStack.stack[this.stackIndex];
		if (var1 >= 0 && var1 != this.readOctets || var1 < 0 && this.tag != 0) {
			this.throwException("Contents octets not consumed");
		}

		if ((this.stackIndex -= 2) < 0) {
			this.currStack = this.currStack.prev;
			this.stackIndex = this.currStack.stack.length - 2;
		}

		this.tag = -1;
		--this.stackPos;
	}

	public InputStream setInputStream(InputStream var1) {
		InputStream var2 = this.input;
		this.input = var1;
		this.pushedBack = false;

		for (this.readOctets = 0; this.currStack.prev != null; this.currStack = this.currStack.prev) {
			;
		}

		this.currStack.stack[0] = -1;
		this.currStack.stack[1] = 16;
		this.stackIndex = this.stackPos = 0;
		this.tag = 16;
		this.implicitTag = 0;
		return var2;
	}

	public BERDecoder(byte[] var1, int var2, int var3) {
		this((InputStream) (new ByteArrayInputStream(var1, var2, var3)));
	}

	public BERDecoder(byte[] var1) {
		this((InputStream) (new ByteArrayInputStream(var1)));
	}

	public BERDecoder(InputStream var1) {
		this(var1, 32);
	}

	public BERDecoder(InputStream var1, int var2) {
		this.currStack = new DecStack();
		this.currStack.prev = this.currStack.next = null;
		this.currStack.stack = new int[2 * var2];
		this.tagLenBuf = new byte[32];
		this.setInputStream(var1);
	}

	protected void checkNextTag(int var1) throws Exception {
		if (!this.decodeTagAndLength()) {
			this.throwException("Expected one more tag in constructed encoding");
		}

		if (this.implicitTag != 0) {
			if (this.implicitTag != this.tag) {
				this.throwException("Read tag " + ASN1Tag.tagToString(this.tag) + " but expected (implicit) "
						+ ASN1Tag.tagToString(this.implicitTag) + " / original data tag " + ASN1Tag.tagToString(var1));
			}
		} else if (this.tag != var1) {
			this.throwException(
					"Read tag " + ASN1Tag.tagToString(this.tag) + " but expected " + ASN1Tag.tagToString(var1));
		}

		if (!this.constructed || ASN1Tag.getTagClass(var1) == 0 && !ASN1Tag.isUniversalStringTag(var1)) {
			this.implicitTag = 0;
		}

		if (this.constructed) {
			this.push(var1);
		}

	}

	public int peekNextTag() throws Exception {
		if (!this.decodeTagAndLength()) {
			return 0;
		} else {
			this.pushBack();
			return this.tag;
		}
	}

	public int decodeExplicit(int var1) throws Exception {
		this.checkNextTag(var1);
		return this.stackPos;
	}

	public int decodeExplicitAsInt(int var1) throws Exception {
		this.checkNextTag(var1);
		int var2 = this.valueLength;
		int var3 = (4 - var2) * 8;

		int var4;
		for (var4 = 0; var2-- > 0; var4 = (var4 << 8) + this.getOctet()) {
			;
		}

		if (var3 < 0) {
			var3 = 0;
		}

		return var4 << var3 >> var3;
	}

	private int decodeInt(int var1) throws Exception {
		this.checkNextTag(var1);
		int var2 = this.valueLength;
		int var3 = (4 - var2) * 8;

		int var4;
		for (var4 = 0; var2-- > 0; var4 = (var4 << 8) + this.getOctet()) {
			;
		}

		if (var3 < 0) {
			var3 = 0;
		}

		return var4 << var3 >> var3;
	}

	public int decodeIntegerAsInt() throws Exception {
		return this.decodeInt(2);
	}

	public int decodeEnumeration() throws Exception {
		return this.decodeInt(10);
	}

	public int decodeSequence() throws Exception {
		this.checkNextTag(16);
		return this.stackPos;
	}

	public int decodeSequenceOf() throws Exception {
		this.checkNextTag(16);
		return this.stackPos;
	}

	public int decodeChoice(int[] var1) throws Exception {
		return this.peekNextTag();
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2014;
	}
}