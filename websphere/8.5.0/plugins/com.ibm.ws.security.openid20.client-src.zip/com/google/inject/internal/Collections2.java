package com.google.inject.internal;

import java.util.Collection;
import java.util.Set;

public final class Collections2 {
	static <E> Collection<E> toCollection(Iterable<E> iterable) {
		return (Collection) (iterable instanceof Collection ? (Collection) iterable : Lists.newArrayList(iterable));
	}

	static boolean setEquals(Set<?> thisSet, @Nullable Object object) {
		if (object == thisSet) {
			return true;
		} else if (!(object instanceof Set)) {
			return false;
		} else {
			Set<?> thatSet = (Set) object;
			return thisSet.size() == thatSet.size() && thisSet.containsAll(thatSet);
		}
	}
}