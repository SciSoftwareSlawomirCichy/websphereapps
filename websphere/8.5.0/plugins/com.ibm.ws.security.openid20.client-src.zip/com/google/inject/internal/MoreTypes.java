package com.google.inject.internal;

import com.google.inject.ConfigurationException;
import com.google.inject.TypeLiteral;
import com.google.inject.internal.ImmutableMap.Builder;
import com.google.inject.internal.MoreTypes.1;
import com.google.inject.internal.MoreTypes.CompositeType;
import com.google.inject.internal.MoreTypes.GenericArrayTypeImpl;
import com.google.inject.internal.MoreTypes.MemberImpl;
import com.google.inject.internal.MoreTypes.ParameterizedTypeImpl;
import com.google.inject.internal.MoreTypes.WildcardTypeImpl;
import com.google.inject.spi.Message;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Map;
import java.util.NoSuchElementException;

public class MoreTypes {
	public static final Type[] EMPTY_TYPE_ARRAY = new Type[0];
	private static final Map<TypeLiteral<?>, TypeLiteral<?>> PRIMITIVE_TO_WRAPPER;

	public static <T> TypeLiteral<T> makeKeySafe(TypeLiteral<T> type) {
		if (!isFullySpecified(type.getType())) {
			String message = type + " cannot be used as a key; It is not fully specified.";
			throw new ConfigurationException(ImmutableSet.of(new Message(message)));
		} else {
			TypeLiteral<T> wrappedPrimitives = (TypeLiteral) PRIMITIVE_TO_WRAPPER.get(type);
			return wrappedPrimitives != null ? wrappedPrimitives : type;
		}
	}

	private static boolean isFullySpecified(Type type) {
		if (type instanceof Class) {
			return true;
		} else if (type instanceof CompositeType) {
			return ((CompositeType) type).isFullySpecified();
		} else {
			return type instanceof TypeVariable ? false : ((CompositeType) canonicalize(type)).isFullySpecified();
		}
	}

	public static Type canonicalize(Type type) {
		if (!(type instanceof ParameterizedTypeImpl) && !(type instanceof GenericArrayTypeImpl)
				&& !(type instanceof WildcardTypeImpl)) {
			if (type instanceof ParameterizedType) {
				ParameterizedType p = (ParameterizedType) type;
				return new ParameterizedTypeImpl(p.getOwnerType(), p.getRawType(), p.getActualTypeArguments());
			} else if (type instanceof GenericArrayType) {
				GenericArrayType g = (GenericArrayType) type;
				return new GenericArrayTypeImpl(g.getGenericComponentType());
			} else if (type instanceof Class && ((Class) type).isArray()) {
				Class<?> c = (Class) type;
				return new GenericArrayTypeImpl(c.getComponentType());
			} else if (type instanceof WildcardType) {
				WildcardType w = (WildcardType) type;
				return new WildcardTypeImpl(w.getUpperBounds(), w.getLowerBounds());
			} else {
				return type;
			}
		} else {
			return type;
		}
	}

	public static Member serializableCopy(Member member) {
      return (Member)(member instanceof MemberImpl ? member : new MemberImpl(member, (1)null));
   }

	public static Class<?> getRawType(Type type) {
		if (type instanceof Class) {
			return (Class) type;
		} else if (type instanceof ParameterizedType) {
			ParameterizedType parameterizedType = (ParameterizedType) type;
			Type rawType = parameterizedType.getRawType();
			Preconditions.checkArgument(rawType instanceof Class, "Expected a Class, but <%s> is of type %s",
					new Object[]{type, type.getClass().getName()});
			return (Class) rawType;
		} else if (type instanceof GenericArrayType) {
			return Object[].class;
		} else if (type instanceof TypeVariable) {
			return Object.class;
		} else {
			throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type
					+ "> is of type " + type.getClass().getName());
		}
	}

	public static boolean equals(Type a, Type b) {
		if (a == b) {
			return true;
		} else if (a instanceof Class) {
			return a.equals(b);
		} else if (a instanceof ParameterizedType) {
			if (!(b instanceof ParameterizedType)) {
				return false;
			} else {
				ParameterizedType pa = (ParameterizedType) a;
				ParameterizedType pb = (ParameterizedType) b;
				return Objects.equal(pa.getOwnerType(), pb.getOwnerType()) && pa.getRawType().equals(pb.getRawType())
						&& Arrays.equals(pa.getActualTypeArguments(), pb.getActualTypeArguments());
			}
		} else if (a instanceof GenericArrayType) {
			if (!(b instanceof GenericArrayType)) {
				return false;
			} else {
				GenericArrayType ga = (GenericArrayType) a;
				GenericArrayType gb = (GenericArrayType) b;
				return equals(ga.getGenericComponentType(), gb.getGenericComponentType());
			}
		} else if (a instanceof WildcardType) {
			if (!(b instanceof WildcardType)) {
				return false;
			} else {
				WildcardType wa = (WildcardType) a;
				WildcardType wb = (WildcardType) b;
				return Arrays.equals(wa.getUpperBounds(), wb.getUpperBounds())
						&& Arrays.equals(wa.getLowerBounds(), wb.getLowerBounds());
			}
		} else if (a instanceof TypeVariable) {
			if (!(b instanceof TypeVariable)) {
				return false;
			} else {
				TypeVariable<?> va = (TypeVariable) a;
				TypeVariable<?> vb = (TypeVariable) b;
				return va.getGenericDeclaration() == vb.getGenericDeclaration() && va.getName().equals(vb.getName());
			}
		} else {
			return false;
		}
	}

	public static int hashCode(Type type) {
		if (type instanceof Class) {
			return type.hashCode();
		} else if (type instanceof ParameterizedType) {
			ParameterizedType p = (ParameterizedType) type;
			return Arrays.hashCode(p.getActualTypeArguments()) ^ p.getRawType().hashCode()
					^ hashCodeOrZero(p.getOwnerType());
		} else if (type instanceof GenericArrayType) {
			return hashCode(((GenericArrayType) type).getGenericComponentType());
		} else if (type instanceof WildcardType) {
			WildcardType w = (WildcardType) type;
			return Arrays.hashCode(w.getLowerBounds()) ^ Arrays.hashCode(w.getUpperBounds());
		} else {
			return hashCodeOrZero(type);
		}
	}

	private static int hashCodeOrZero(Object o) {
		return o != null ? o.hashCode() : 0;
	}

	public static String toString(Type type) {
		if (type instanceof Class) {
			return ((Class) type).getName();
		} else {
			Type[] lowerBounds;
			if (type instanceof ParameterizedType) {
				ParameterizedType parameterizedType = (ParameterizedType) type;
				lowerBounds = parameterizedType.getActualTypeArguments();
				Type ownerType = parameterizedType.getOwnerType();
				StringBuilder stringBuilder = new StringBuilder();
				if (ownerType != null) {
					stringBuilder.append(toString(ownerType)).append(".");
				}

				stringBuilder.append(toString(parameterizedType.getRawType()));
				if (lowerBounds.length > 0) {
					stringBuilder.append("<").append(toString(lowerBounds[0]));

					for (int i = 1; i < lowerBounds.length; ++i) {
						stringBuilder.append(", ").append(toString(lowerBounds[i]));
					}
				}

				return stringBuilder.append(">").toString();
			} else if (type instanceof GenericArrayType) {
				return toString(((GenericArrayType) type).getGenericComponentType()) + "[]";
			} else if (type instanceof WildcardType) {
				WildcardType wildcardType = (WildcardType) type;
				lowerBounds = wildcardType.getLowerBounds();
				Type[] upperBounds = wildcardType.getUpperBounds();
				if (upperBounds.length == 1 && lowerBounds.length <= 1) {
					if (lowerBounds.length == 1) {
						if (upperBounds[0] != Object.class) {
							throw new UnsupportedOperationException("Unsupported wildcard type " + type);
						} else {
							return "? super " + toString(lowerBounds[0]);
						}
					} else {
						return upperBounds[0] == Object.class ? "?" : "? extends " + toString(upperBounds[0]);
					}
				} else {
					throw new UnsupportedOperationException("Unsupported wildcard type " + type);
				}
			} else {
				return type.toString();
			}
		}
	}

	public static Class<? extends Member> memberType(Member member) {
		Preconditions.checkNotNull(member, "member");
		if (member instanceof MemberImpl) {
			return MemberImpl.access$100((MemberImpl) member);
		} else if (member instanceof Field) {
			return Field.class;
		} else if (member instanceof Method) {
			return Method.class;
		} else if (member instanceof Constructor) {
			return Constructor.class;
		} else {
			throw new IllegalArgumentException("Unsupported implementation class for Member, " + member.getClass());
		}
	}

	public static String toString(Member member) {
		Class<? extends Member> memberType = memberType(member);
		if (memberType == Method.class) {
			return member.getDeclaringClass().getName() + "." + member.getName() + "()";
		} else if (memberType == Field.class) {
			return member.getDeclaringClass().getName() + "." + member.getName();
		} else if (memberType == Constructor.class) {
			return member.getDeclaringClass().getName() + ".<init>()";
		} else {
			throw new AssertionError();
		}
	}

	public static String memberKey(Member member) {
		Preconditions.checkNotNull(member, "member");
		if (member instanceof MemberImpl) {
			return MemberImpl.access$200((MemberImpl) member);
		} else if (member instanceof Field) {
			return member.getName();
		} else if (member instanceof Method) {
			return member.getName() + com.google.inject.internal.asm.Type.getMethodDescriptor((Method) member);
		} else if (!(member instanceof Constructor)) {
			throw new IllegalArgumentException("Unsupported implementation class for Member, " + member.getClass());
		} else {
			StringBuilder sb = (new StringBuilder()).append("<init>(");
			Class[] arr$ = ((Constructor) member).getParameterTypes();
			int len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				Class param = arr$[i$];
				sb.append(com.google.inject.internal.asm.Type.getDescriptor(param));
			}

			return sb.append(")V").toString();
		}
	}

	public static Type getGenericSupertype(Type type, Class<?> rawType, Class<?> toResolve) {
		if (toResolve == rawType) {
			return type;
		} else {
			if (toResolve.isInterface()) {
				Class[] interfaces = rawType.getInterfaces();
				int i = 0;

				for (int length = interfaces.length; i < length; ++i) {
					if (interfaces[i] == toResolve) {
						return rawType.getGenericInterfaces()[i];
					}

					if (toResolve.isAssignableFrom(interfaces[i])) {
						return getGenericSupertype(rawType.getGenericInterfaces()[i], interfaces[i], toResolve);
					}
				}
			}

			if (!rawType.isInterface()) {
				while (rawType != Object.class) {
					Class<?> rawSupertype = rawType.getSuperclass();
					if (rawSupertype == toResolve) {
						return rawType.getGenericSuperclass();
					}

					if (toResolve.isAssignableFrom(rawSupertype)) {
						return getGenericSupertype(rawType.getGenericSuperclass(), rawSupertype, toResolve);
					}

					rawType = rawSupertype;
				}
			}

			return toResolve;
		}
	}

	public static Type resolveTypeVariable(Type type, Class<?> rawType, TypeVariable unknown) {
		Class<?> declaredByRaw = declaringClassOf(unknown);
		if (declaredByRaw == null) {
			return unknown;
		} else {
			Type declaredBy = getGenericSupertype(type, rawType, declaredByRaw);
			if (declaredBy instanceof ParameterizedType) {
				int index = indexOf(declaredByRaw.getTypeParameters(), unknown);
				return ((ParameterizedType) declaredBy).getActualTypeArguments()[index];
			} else {
				return unknown;
			}
		}
	}

	private static int indexOf(Object[] array, Object toFind) {
		for (int i = 0; i < array.length; ++i) {
			if (toFind.equals(array[i])) {
				return i;
			}
		}

		throw new NoSuchElementException();
	}

	private static Class<?> declaringClassOf(TypeVariable typeVariable) {
		GenericDeclaration genericDeclaration = typeVariable.getGenericDeclaration();
		return genericDeclaration instanceof Class ? (Class) genericDeclaration : null;
	}

	private static void checkNotPrimitive(Type type, String use) {
		Preconditions.checkArgument(!(type instanceof Class) || !((Class) type).isPrimitive(),
				"Primitive types are not allowed in %s: %s", new Object[]{use, type});
	}

	static {
		PRIMITIVE_TO_WRAPPER = (new Builder()).put(TypeLiteral.get(Boolean.TYPE), TypeLiteral.get(Boolean.class))
				.put(TypeLiteral.get(Byte.TYPE), TypeLiteral.get(Byte.class))
				.put(TypeLiteral.get(Short.TYPE), TypeLiteral.get(Short.class))
				.put(TypeLiteral.get(Integer.TYPE), TypeLiteral.get(Integer.class))
				.put(TypeLiteral.get(Long.TYPE), TypeLiteral.get(Long.class))
				.put(TypeLiteral.get(Float.TYPE), TypeLiteral.get(Float.class))
				.put(TypeLiteral.get(Double.TYPE), TypeLiteral.get(Double.class))
				.put(TypeLiteral.get(Character.TYPE), TypeLiteral.get(Character.class))
				.put(TypeLiteral.get(Void.TYPE), TypeLiteral.get(Void.class)).build();
	}
}