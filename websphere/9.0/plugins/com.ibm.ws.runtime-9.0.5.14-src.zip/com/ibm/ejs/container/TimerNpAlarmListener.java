package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.asynchbeans.Alarm;
import com.ibm.websphere.asynchbeans.AlarmListener;
import com.ibm.ws.asynchbeans.WSAlarm;
import com.ibm.ws.asynchbeans.WSAlarmManager;
import java.util.Date;

public class TimerNpAlarmListener extends TimerNpRunnable implements AlarmListener {
	private static final String CLASS_NAME = TimerNpAlarmListener.class.getName();
	private static TraceComponent tc;
	public static WSAlarmManager svAlarmManager;
	private volatile WSAlarm ivTask;

	public TimerNpAlarmListener(TimerNpImpl timerNpImpl, int retryLimit, int retryInterval) {
		super(timerNpImpl, retryLimit, (long) retryInterval);
	}

	protected void schedule(long expiration) {
		this.ivTask = (WSAlarm) svAlarmManager.create(this, this.ivTimer, new Date(expiration));
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "schedule : created " + this.ivTask);
		}

	}

	protected void scheduleNext(long nextExpiration) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "scheduleNext : " + nextExpiration);
		}

		this.ivTask.reset(new Date(nextExpiration));
	}

	protected void scheduleRetry(long retryInterval) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "scheduleRetry : " + retryInterval);
		}

		this.ivTask.reset((int) retryInterval);
	}

	protected void cancel() {
		WSAlarm task = this.ivTask;
		if (task != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "cancel : " + task);
			}

			this.ivTask = null;
			task.cancel();
		}

	}

	public void fired(Alarm alarm) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "fired : " + alarm);
		}

		this.run();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "fired : " + this.ivTask);
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		svAlarmManager = null;
	}
}