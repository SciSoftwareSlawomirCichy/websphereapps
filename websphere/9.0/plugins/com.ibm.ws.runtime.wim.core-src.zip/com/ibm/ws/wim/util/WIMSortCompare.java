package com.ibm.ws.wim.util;

import commonj.sdo.DataObject;
import java.io.Serializable;
import java.util.Comparator;

public class WIMSortCompare implements Serializable, Comparator {
	DataObject sortControl = null;

	public WIMSortCompare(DataObject var1) {
		this.sortControl = var1;
	}

	public int compare(Object var1, Object var2) {
		SortHandler var3 = new SortHandler(this.sortControl);
		return var3.compareEntitysWithRespectToProperties((DataObject) var1, (DataObject) var2);
	}
}