package com.ibm.ejs.container;

public class EJBConfigurationException extends Exception {
	private static final long serialVersionUID = 3204992112732695704L;

	public EJBConfigurationException() {
	}

	public EJBConfigurationException(String detailMessage) {
		super(detailMessage);
	}

	public EJBConfigurationException(Throwable throwable) {
		super(throwable);
	}

	public EJBConfigurationException(String detailMessage, Throwable throwable) {
		super(detailMessage, throwable);
	}
}