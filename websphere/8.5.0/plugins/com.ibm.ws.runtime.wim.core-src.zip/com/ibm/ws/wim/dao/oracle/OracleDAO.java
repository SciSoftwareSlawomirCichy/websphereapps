package com.ibm.ws.wim.dao.oracle;

import com.ibm.websphere.ce.cm.DuplicateKeyException;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InvalidPropertyValueException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.db.DBEntity;
import com.ibm.ws.wim.dao.AbstractDAO;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.util.DataGraphHelper;
import commonj.sdo.DataObject;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;

public class OracleDAO extends AbstractDAO {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;

	public OracleDAO(String var1, String var2, String var3, String var4, String var5, String var6) throws WIMException {
		super("oracle", var1, var2, var3, var4, var5, var6, new OracleQuerySet(var3));
	}

	public OracleDAO(String var1, String var2, String var3, String var4, String var5) throws WIMException {
		super("oracle", var1, var2, var3, var4, var5, new OracleQuerySet());
	}

	public void createProperties(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
		}

		if (var4 != null) {
			Connection var9 = null;
			PreparedStatement var10 = null;

			try {
				label402 : for (short var11 = 0; var11 < var4.length; ++var11) {
					if (var4[var11] != null) {
						String var12 = this.getInsertStmtForPropertyValue(var1, var11);
						int var13 = var4[var11].size();
						Set var14 = var4[var11].keySet();
						Iterator var15 = var14.iterator();
						if (var9 == null) {
							var9 = this.getConnection();
						}

						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME,
									"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
									"insert statement is " + var12);
						}

						var10 = var9.prepareStatement(var12);
						String var16 = DAOHelper.getValueTableName(var1, var11);

						while (true) {
							Integer var17;
							Object var18;
							do {
								if (!var15.hasNext()) {
									continue label402;
								}

								var17 = (Integer) var15.next();
								if (var6.contains(var17)) {
									var18 = (List) var4[var11].get(var17);
								} else {
									var18 = new ArrayList();
									((List) var18).add(var4[var11].get(var17));
								}
							} while (((List) var18).size() == 0);

							for (int var19 = 0; var19 < ((List) var18).size(); ++var19) {
								long var20 = -1L;
								if (var1 == 0) {
									var20 = this.getKeyManager().getDBKeyForTable(var9, var16);
								} else {
									var20 = this.getKeyManager().getLAKeyForTable(var9, var16);
								}

								var10.setLong(1, var20);
								var10.setInt(2, var17);
								var10.setString(3, DAOHelper.getDataType(var11));
								var10.setLong(4, var2);
								if (var5 != null) {
									var10.setLong(5, var5);
								} else {
									var10.setNull(5, -5);
								}

								var10.setString(6, "");

								try {
									DataObject var28;
									switch (var11) {
										case 0 :
											var10.setString(7, (String) ((List) var18).get(var19));
											var10.setString(8, ((String) ((List) var18).get(var19)).toLowerCase());
											break;
										case 1 :
											long var63 = 0L;

											try {
												var63 = (Long) ((List) var18).get(var19);
											} catch (ClassCastException var56) {
												var63 = Long.parseLong((String) ((List) var18).get(var19));
											}

											var10.setLong(7, var63);
											break;
										case 2 :
											double var65 = 0.0D;

											try {
												var65 = (Double) ((List) var18).get(var19);
											} catch (ClassCastException var55) {
												var65 = Double.parseDouble((String) ((List) var18).get(var19));
											}

											var10.setDouble(7, var65);
											break;
										case 3 :
											boolean var66 = false;

											int var67;
											try {
												var67 = (Integer) ((List) var18).get(var19);
											} catch (ClassCastException var54) {
												var67 = new Integer(((List) var18).get(var19).toString());
											}

											var10.setInt(7, var67);
											break;
										case 4 :
											if (trcLogger.isLoggable(Level.FINE)) {
												trcLogger.logp(Level.FINE, CLASSNAME,
														"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
														"parsing timestamp: " + ((List) var18).get(var19));
											}

											var28 = null;

											Timestamp var68;
											try {
												var68 = (Timestamp) ((List) var18).get(var19);
											} catch (ClassCastException var58) {
												if (trcLogger.isLoggable(Level.FINE)) {
													trcLogger.logp(Level.FINE, CLASSNAME,
															"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
															"Error converting timestamp: " + var58.getMessage());
												}

												try {
													var68 = Timestamp.valueOf((String) ((List) var18).get(var19));
												} catch (Exception var57) {
													if (trcLogger.isLoggable(Level.FINE)) {
														trcLogger.logp(Level.FINE, CLASSNAME,
																"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																"Error converting timestamp: " + var57.getMessage());
													}

													String var71 = ((List) var18).get(var19).toString();
													SimpleDateFormat var72 = new SimpleDateFormat(
															"yyyy-MM-dd'T'HH:mm:ss.SSS");

													try {
														var72.setTimeZone(TimeZone.getTimeZone("GMT"));
														Date var33 = var72.parse(var71);
														var68 = new Timestamp(var33.getTime());
													} catch (ParseException var53) {
														var72 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
														var72.setTimeZone(TimeZone.getTimeZone("GMT"));
														Date var34 = var72.parse(var71);
														var68 = new Timestamp(var34.getTime());
													}
												}
											}

											if (trcLogger.isLoggable(Level.FINE)) {
												trcLogger.logp(Level.FINE, CLASSNAME,
														"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
														"writing timestamp: " + var68);
											}

											var10.setTimestamp(7, var68);
											break;
										case 5 :
											DataObject var22 = (DataObject) ((List) var18).get(var19);
											if (RepositoryManager.singleton().isEntryJoin()) {
												DataGraphHelper.prepareIdentifierFromFedRepository(var22);
											} else {
												String var23;
												if (var1 == 0 && var7 != null) {
													var23 = var22.getString("uniqueName");
													DBEntity var64 = this.findDBEntityByUniqueNameKey(
															DAOHelper.getTruncatedUniqueName(var23));
													var22.setString("externalId", var64.getUniqueId());
													var22.setString("repositoryId", var7);
												} else if (var1 == 1) {
													var23 = var22.getString("uniqueName");
													String var24 = var22.getString("externalId");
													String var25 = var22.getString("repositoryId");
													if (var23 == null || var24 == null || var25 == null) {
														DataObject var26 = SchemaManager.singleton()
																.createRootDataObject();
														DataObject var27 = var26.createDataObject("entities",
																"http://www.ibm.com/websphere/wim", "Entity");
														var28 = var27.createDataObject("identifier");
														var28.setString("uniqueName", var23);
														var28.setString("externalId", var24);
														var28.setString("repositoryId", var25);
														DataObject var69 = RepositoryManager.singleton()
																.getRepositories()[0].get(var26);
														List var70 = var69.getList("entities");
														DataObject var31 = (DataObject) var70.get(0);
														DataObject var32 = var31.getDataObject("identifier");
														var23 = var32.getString("uniqueName");
														var24 = var32.getString("externalId");
														var25 = RepositoryManager.singleton().getRepositoryIds()[0];
														var22.setString("uniqueName", var23);
														var22.setString("externalId", var24);
														var22.setString("repositoryId", var7);
													}
												}
											}

											var10.setString(7,
													DAOHelper.getTruncatedUniqueName(var22.getString("uniqueName")));
											var10.setString(8, var22.getString("uniqueName"));
											var10.setString(9,
													DAOHelper.getTruncatedExternalId(var22.getString("externalId")));
											var10.setString(10, var22.getString("externalId"));
											var10.setString(11, var22.getString("repositoryId"));
											break;
										case 6 :
											ByteArrayOutputStream var29 = new ByteArrayOutputStream();
											ObjectOutputStream var30 = new ObjectOutputStream(var29);
											var30.writeObject(((List) var18).get(var19));
											var30.close();
											var10.setBytes(7, var29.toByteArray());
									}
								} catch (Exception var59) {
									throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
											WIMMessageHelper.generateMsgParms(var17), CLASSNAME,
											"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
											var59);
								}

								var10.executeUpdate();
							}
						}
					}
				}
			} catch (NamingException var60) {
				throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
						var60);
			} catch (SQLException var61) {
				throw new WIMSystemException("SQL_EXCEPTION", CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
						var61);
			} finally {
				try {
					this.closeConnection(var9);
				} catch (Exception var52) {
					;
				}

				try {
					var10.close();
				} catch (Exception var51) {
					;
				}

			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
			}

		}
	}

	public void createProperties1(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
		}

		if (var4 != null) {
			Connection var9 = null;
			PreparedStatement var10 = null;

			try {
				label694 : for (short var11 = 0; var11 < var4.length; ++var11) {
					if (var4[var11] != null) {
						String var12 = this.getInsertStmtForPropertyValueWithoutKey(var1, var11);
						DAOHelper.getValueTableName(var1, var11);
						int var14 = var4[var11].size();
						Set var15 = var4[var11].keySet();
						Iterator var16 = var15.iterator();
						if (var9 == null) {
							var9 = this.getConnection();
						}

						while (true) {
							Integer var17;
							Object var18;
							do {
								if (!var16.hasNext()) {
									continue label694;
								}

								var17 = (Integer) var16.next();
								if (var6.contains(var17)) {
									var18 = (List) var4[var11].get(var17);
								} else {
									var18 = new ArrayList();
									((List) var18).add(var4[var11].get(var17));
								}
							} while (((List) var18).size() == 0);

							for (int var19 = 0; var19 < ((List) var18).size(); ++var19) {
								boolean var20 = false;

								while (!var20) {
									try {
										var10 = var9.prepareStatement(var12);
										var10.setInt(1, var17);
										var10.setString(2, DAOHelper.getDataType(var11));
										var10.setLong(3, var2);
										if (var5 != null) {
											var10.setLong(4, var5);
										} else {
											var10.setNull(4, -5);
										}

										var10.setString(5, "");

										try {
											DataObject var27;
											switch (var11) {
												case 0 :
													var10.setString(6, (String) ((List) var18).get(var19));
													var10.setString(7,
															((String) ((List) var18).get(var19)).toLowerCase());
													break;
												case 1 :
													long var86 = 0L;

													try {
														var86 = (Long) ((List) var18).get(var19);
													} catch (ClassCastException var78) {
														var86 = Long.parseLong((String) ((List) var18).get(var19));
													}

													var10.setLong(6, var86);
													break;
												case 2 :
													double var88 = 0.0D;

													try {
														var88 = (Double) ((List) var18).get(var19);
													} catch (ClassCastException var77) {
														var88 = Double.parseDouble((String) ((List) var18).get(var19));
													}

													var10.setDouble(6, var88);
													break;
												case 3 :
													boolean var89 = false;

													int var90;
													try {
														var90 = (Integer) ((List) var18).get(var19);
													} catch (ClassCastException var76) {
														var90 = new Integer(((List) var18).get(var19).toString());
													}

													var10.setInt(6, var90);
													break;
												case 4 :
													if (trcLogger.isLoggable(Level.FINE)) {
														trcLogger.logp(Level.FINE, CLASSNAME,
																"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																"parsing timestamp: " + ((List) var18).get(var19));
													}

													var27 = null;

													Timestamp var91;
													try {
														var91 = (Timestamp) ((List) var18).get(var19);
													} catch (ClassCastException var80) {
														if (trcLogger.isLoggable(Level.FINE)) {
															trcLogger.logp(Level.FINE, CLASSNAME,
																	"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																	"Error converting timestamp: "
																			+ var80.getMessage());
														}

														try {
															var91 = Timestamp
																	.valueOf((String) ((List) var18).get(var19));
														} catch (Exception var79) {
															if (trcLogger.isLoggable(Level.FINE)) {
																trcLogger.logp(Level.FINE, CLASSNAME,
																		"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																		"Error converting timestamp: "
																				+ var79.getMessage());
															}

															String var94 = ((List) var18).get(var19).toString();
															SimpleDateFormat var95 = new SimpleDateFormat(
																	"yyyy-MM-dd'T'HH:mm:ss.SSS");

															try {
																var95.setTimeZone(TimeZone.getTimeZone("GMT"));
																Date var32 = var95.parse(var94);
																var91 = new Timestamp(var32.getTime());
															} catch (ParseException var75) {
																var95 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
																var95.setTimeZone(TimeZone.getTimeZone("GMT"));
																Date var33 = var95.parse(var94);
																var91 = new Timestamp(var33.getTime());
															}
														}
													}

													if (trcLogger.isLoggable(Level.FINE)) {
														trcLogger.logp(Level.FINE, CLASSNAME,
																"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																"writing timestamp: " + var91);
													}

													var10.setTimestamp(6, var91);
													break;
												case 5 :
													DataObject var21 = (DataObject) ((List) var18).get(var19);
													if (RepositoryManager.singleton().isEntryJoin()) {
														DataGraphHelper.prepareIdentifierFromFedRepository(var21);
													} else {
														String var22;
														if (var1 == 0 && var7 != null) {
															var22 = var21.getString("uniqueName");
															DBEntity var87 = this.findDBEntityByUniqueNameKey(
																	DAOHelper.getTruncatedUniqueName(var22));
															var21.setString("externalId", var87.getUniqueId());
															var21.setString("repositoryId", var7);
														} else if (var1 == 1) {
															var22 = var21.getString("uniqueName");
															String var23 = var21.getString("externalId");
															String var24 = var21.getString("repositoryId");
															if (var22 == null || var23 == null || var24 == null) {
																DataObject var25 = SchemaManager.singleton()
																		.createRootDataObject();
																DataObject var26 = var25.createDataObject("entities",
																		"http://www.ibm.com/websphere/wim", "Entity");
																var27 = var26.createDataObject("identifier");
																var27.setString("uniqueName", var22);
																var27.setString("externalId", var23);
																var27.setString("repositoryId", var24);
																DataObject var92 = RepositoryManager.singleton()
																		.getRepositories()[0].get(var25);
																List var93 = var92.getList("entities");
																DataObject var30 = (DataObject) var93.get(0);
																DataObject var31 = var30.getDataObject("identifier");
																var22 = var31.getString("uniqueName");
																var23 = var31.getString("externalId");
																var24 = RepositoryManager.singleton()
																		.getRepositoryIds()[0];
																var21.setString("uniqueName", var22);
																var21.setString("externalId", var23);
																var21.setString("repositoryId", var7);
															}
														}
													}

													var10.setString(6, DAOHelper
															.getTruncatedUniqueName(var21.getString("uniqueName")));
													var10.setString(7, var21.getString("uniqueName"));
													var10.setString(8, DAOHelper
															.getTruncatedExternalId(var21.getString("externalId")));
													var10.setString(9, var21.getString("externalId"));
													var10.setString(10, var21.getString("repositoryId"));
													break;
												case 6 :
													ByteArrayOutputStream var28 = new ByteArrayOutputStream();
													ObjectOutputStream var29 = new ObjectOutputStream(var28);
													var29.writeObject(((List) var18).get(var19));
													var29.close();
													var10.setBytes(6, var28.toByteArray());
											}
										} catch (Exception var81) {
											throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
													WIMMessageHelper.generateMsgParms(var17), CLASSNAME,
													"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													var81);
										}

										var10.executeUpdate();
										var20 = true;
									} catch (DuplicateKeyException var82) {
										var20 = false;
										if (var82.getMessage().contains("WIMI")
												|| var82.getMessage().contains("WIMF")) {
											var20 = true;
											throw new WIMSystemException("SQL_EXCEPTION",
													WIMMessageHelper.generateMsgParms(var82.getMessage()), CLASSNAME,
													"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													var82);
										}

										if (trcLogger.isLoggable(Level.FINE)) {
											trcLogger.logp(Level.FINE, CLASSNAME,
													"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													"Reattempting");
										}
									} catch (SQLException var83) {
										var20 = true;
										throw new WIMSystemException("SQL_EXCEPTION",
												WIMMessageHelper.generateMsgParms(var83.getMessage()), CLASSNAME,
												"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
												var83);
									} finally {
										try {
											var10.close();
										} catch (Exception var74) {
											;
										}

										var10 = null;
									}
								}
							}
						}
					}
				}
			} finally {
				try {
					this.closeConnection(var9);
				} catch (Exception var73) {
					;
				}

				try {
					var10.close();
				} catch (Exception var72) {
					;
				}

				var9 = null;
				var10 = null;
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
			}

		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = OracleDAO.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}