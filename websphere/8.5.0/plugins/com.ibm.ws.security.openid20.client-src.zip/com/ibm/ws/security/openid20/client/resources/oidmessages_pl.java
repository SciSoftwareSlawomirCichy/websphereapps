package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_pl extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E:  Strona zależna OpenID (relying party - RP) nie mogła przekierować użytkownika do dostawcy OpenID (OpenID provider - OP) w celu uwierzytelnienia z powodu następującego wyjątku: [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: Inicjowanie strony zależnej OpenID (relying party - RP) nie powiodło się z powodu niepowodzenia uzyskania domyślnego kontekstu SSLContext dla serwera WebSphere. Wyjątek: [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E:  Strona zależna OpenID (relying party - RP) nie mogła nawiązać połączenia z dostawcą OpenID (OpenID provider - OP) określonym identyfikatorem [{0}] z powodu następującego wyjątku: [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: Inicjowanie strony zależnej OpenID (relying party - RP) nie powiodło się z powodu następującego wyjątku: [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: Strona zależna OpenID (relying party - RP) nie została zainicjowana, ponieważ wartość właściwości [{0}] nie jest poprawnie sformatowana."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: Strona zależna OpenID (relying party - RP) nie mogła uwierzytelnić żądania z użyciem znacznika podstawowego uwierzytelniania, ponieważ wartość znacznika jest niepoprawna."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: Inicjowanie strony zależnej OpenID (relying party - RP) nie powiodło się, ponieważ podano poprawnej wartości właściwości [{0}]. Powinien to być poprawny adres URL."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: Strona zależna OpenID (relying party - RP) otrzymała niepoprawną odpowiedź od dostawcy OpenID (OpenID provider - OP). Przyczyna tego błędu jest następująca: [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: Strona zależna OpenID (relying party - RP) nie mogła przeprowadzić uwierzytelniania, ponieważ osiągnęła maksymalną wielkość wewnętrznej pamięci podręcznej."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: Inicjowanie strony zależnej OpenID (relying party - RP) nie powiodło się z powodu braku wymaganej właściwości axRequiredAttribute[n]. Należy zdefiniować co najmniej jedną właściwość."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E:  Inicjowanie strony zależnej OpenID (relying party - RP) nie powiodło się, ponieważ wartość obowiązkowej właściwości [{0}] nie istnieje lub jest pusta."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E:  Strona zależna OpenID (relying party - RP) wymaga protokołu SSL (HTTPS), ale adres URL dostawcy OpenID (OpenID provider - OP) to HTTP: [{0}]. Atrybut [{1}] powinien być zgodny ze schematem docelowego adresu URL. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: Strona zależna OpenID (relying party - RP) otrzymała odpowiedź od dostawcy OpenID (OpenID provider - OP), który nie obsługuje specyfikacji OpenID w wersji 2."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E:  Strona zależna OpenID (relying party - RP) nie mogła przeprowadzić weryfikacji odpowiedzi otrzymanej od dostawcy OpenID (OpenID provider - OP). Wyjątek: [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}