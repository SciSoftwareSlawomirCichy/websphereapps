package com.ibm.json.java;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;

public interface JSONArtifact {
	void serialize(OutputStream var1) throws IOException;

	void serialize(OutputStream var1, boolean var2) throws IOException;

	void serialize(Writer var1) throws IOException;

	void serialize(Writer var1, boolean var2) throws IOException;

	String serialize(boolean var1) throws IOException;

	String serialize() throws IOException;
}