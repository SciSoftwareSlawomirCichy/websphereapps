package com.ibm.ejs.container;

import java.rmi.RemoteException;

public class BeanNotReentrantException extends RemoteException {
	private static final long serialVersionUID = -4139033422889883913L;
	private transient boolean ivTimeout;

	public BeanNotReentrantException() {
	}

	public BeanNotReentrantException(String message) {
		super(message);
	}

	public BeanNotReentrantException(String message, boolean timeout) {
		this(message);
		this.ivTimeout = timeout;
	}

	public boolean isTimeout() {
		return this.ivTimeout;
	}
}