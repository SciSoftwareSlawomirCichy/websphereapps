package com.ibm.ws.wim.dao.derby;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InvalidPropertyValueException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.db.DBEntity;
import com.ibm.ws.wim.dao.AbstractDAO;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.util.DataGraphHelper;
import commonj.sdo.DataObject;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;

public class DerbyDAO extends AbstractDAO {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;

	public DerbyDAO(String var1, String var2, String var3, String var4, String var5) throws WIMException {
		super("derby", var1, var2, var3, var4, var5, new DerbyQuerySet());
	}

	public DerbyDAO(String var1, String var2, String var3, String var4, String var5, String var6) throws WIMException {
		super("derby", var1, var2, var3, var4, var5, var6, new DerbyQuerySet(var3));
	}

	public void createProperties(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps)");
		}

		if (var4 != null) {
			for (short var9 = 0; var9 < var4.length; ++var9) {
				if (var4[var9] != null) {
					Connection var10 = null;
					PreparedStatement var11 = null;
					String var12 = this.getInsertStmtForPropertyValue(var1, var9);
					int var13 = var4[var9].size();
					Set var14 = var4[var9].keySet();
					Iterator var15 = var14.iterator();

					try {
						var10 = this.getConnection();
						var11 = var10.prepareStatement(var12);
						String var16 = DAOHelper.getValueTableName(var1, var9);

						while (var15.hasNext()) {
							Integer var17 = (Integer) var15.next();
							Object var18;
							if (var6.contains(var17)) {
								var18 = (List) var4[var9].get(var17);
							} else {
								var18 = new ArrayList();
								((List) var18).add(var4[var9].get(var17));
							}

							if (((List) var18).size() != 0) {
								for (int var19 = 0; var19 < ((List) var18).size(); ++var19) {
									long var20 = -1L;
									if (var1 == 0) {
										var20 = this.getKeyManager().getDBKeyForTable(var10, var16);
									} else {
										var20 = this.getKeyManager().getLAKeyForTable(var10, var16);
									}

									var11.setLong(1, var20);
									var11.setInt(2, var17);
									var11.setString(3, DAOHelper.getDataType(var9));
									var11.setLong(4, var2);
									if (var5 != null) {
										var11.setLong(5, var5);
									} else {
										var11.setNull(5, -5);
									}

									var11.setString(6, "");

									try {
										switch (var9) {
											case 0 :
												var11.setString(7, (String) ((List) var18).get(var19));
												var11.setString(8, ((String) ((List) var18).get(var19)).toLowerCase());
												break;
											case 1 :
												long var60 = 0L;

												try {
													var60 = (Long) ((List) var18).get(var19);
												} catch (ClassCastException var54) {
													var60 = Long.parseLong((String) ((List) var18).get(var19));
												}

												var11.setLong(7, var60);
												break;
											case 2 :
												double var62 = 0.0D;

												try {
													var62 = (Double) ((List) var18).get(var19);
												} catch (ClassCastException var53) {
													var62 = Double.parseDouble((String) ((List) var18).get(var19));
												}

												var11.setDouble(7, var62);
												break;
											case 3 :
												boolean var63 = false;

												int var64;
												try {
													var64 = (Integer) ((List) var18).get(var19);
												} catch (ClassCastException var52) {
													var64 = new Integer(((List) var18).get(var19).toString());
												}

												var11.setInt(7, var64);
												break;
											case 4 :
												Timestamp var65 = null;

												try {
													var65 = (Timestamp) ((List) var18).get(var19);
												} catch (ClassCastException var51) {
													try {
														var65 = Timestamp.valueOf((String) ((List) var18).get(var19));
													} catch (Exception var50) {
														;
													}
												}

												var11.setTimestamp(7, var65);
												break;
											case 5 :
												DataObject var22 = (DataObject) ((List) var18).get(var19);
												if (RepositoryManager.singleton().isEntryJoin()) {
													DataGraphHelper.prepareIdentifierFromFedRepository(var22);
												} else {
													String var23;
													if (var1 == 0 && var7 != null) {
														var23 = var22.getString("uniqueName");
														DBEntity var61 = this.findDBEntityByUniqueNameKey(
																DAOHelper.getTruncatedUniqueName(var23));
														var22.setString("externalId", var61.getUniqueId());
														var22.setString("repositoryId", var7);
													} else if (var1 == 1) {
														var23 = var22.getString("uniqueName");
														String var24 = var22.getString("externalId");
														String var25 = var22.getString("repositoryId");
														if (var23 == null || var24 == null || var25 == null) {
															DataObject var26 = SchemaManager.singleton()
																	.createRootDataObject();
															DataObject var27 = var26.createDataObject("entities",
																	"http://www.ibm.com/websphere/wim", "Entity");
															DataObject var28 = var27.createDataObject("identifier");
															var28.setString("uniqueName", var23);
															var28.setString("externalId", var24);
															var28.setString("repositoryId", var25);
															DataObject var66 = RepositoryManager.singleton()
																	.getRepositories()[0].get(var26);
															List var67 = var66.getList("entities");
															DataObject var31 = (DataObject) var67.get(0);
															DataObject var32 = var31.getDataObject("identifier");
															var23 = var32.getString("uniqueName");
															var24 = var32.getString("externalId");
															var25 = RepositoryManager.singleton().getRepositoryIds()[0];
															var22.setString("uniqueName", var23);
															var22.setString("externalId", var24);
															var22.setString("repositoryId", var7);
														}
													}
												}

												var11.setString(7, DAOHelper
														.getTruncatedUniqueName(var22.getString("uniqueName")));
												var11.setString(8, var22.getString("uniqueName"));
												var11.setString(9, DAOHelper
														.getTruncatedExternalId(var22.getString("externalId")));
												var11.setString(10, var22.getString("externalId"));
												var11.setString(11, var22.getString("repositoryId"));
												break;
											case 6 :
												ByteArrayOutputStream var29 = new ByteArrayOutputStream();
												ObjectOutputStream var30 = new ObjectOutputStream(var29);
												var30.writeObject(((List) var18).get(var19));
												var30.close();
												var11.setBytes(7, var29.toByteArray());
												var11.executeUpdate();
										}
									} catch (Exception var55) {
										throw new InvalidPropertyValueException();
									}

									if (var9 != 6) {
										var11.addBatch();
									}
								}
							}
						}

						if (var9 != 6) {
							int[] var59 = var11.executeBatch();
						}
					} catch (NamingException var56) {
						throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME,
								"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps)",
								var56);
					} catch (SQLException var57) {
						throw new WIMSystemException("SQL_EXCEPTION", CLASSNAME,
								"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps)",
								var57);
					} finally {
						try {
							this.closeConnection(var10);
						} catch (Exception var49) {
							;
						}

						try {
							var11.close();
						} catch (Exception var48) {
							;
						}

					}
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps)");
			}

		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = DerbyDAO.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}