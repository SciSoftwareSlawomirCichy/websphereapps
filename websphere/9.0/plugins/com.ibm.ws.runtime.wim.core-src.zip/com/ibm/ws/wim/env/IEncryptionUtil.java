package com.ibm.ws.wim.env;

public interface IEncryptionUtil {
	String encode(String var1);

	String decode(String var1);
}