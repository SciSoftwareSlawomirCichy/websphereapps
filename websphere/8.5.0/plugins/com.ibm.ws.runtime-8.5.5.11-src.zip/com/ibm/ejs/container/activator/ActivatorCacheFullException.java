package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.ContainerException;

public class ActivatorCacheFullException extends ContainerException {
	private static final long serialVersionUID = 2189488833806946479L;
}