package com.google.inject.internal;

import com.google.inject.internal.LineNumbers.1;
import com.google.inject.internal.LineNumbers.LineNumberReader;
import com.google.inject.internal.asm.ClassReader;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Member;
import java.util.Map;

public class LineNumbers {
	private final Class type;
	private final Map<String, Integer> lines = Maps.newHashMap();
	private String source;
	private int firstLine = Integer.MAX_VALUE;

	public LineNumbers(Class type) throws IOException {
      this.type = type;
      if (!type.isArray()) {
         InputStream in = type.getResourceAsStream("/" + type.getName().replace('.', '/') + ".class");
         Preconditions.checkArgument(in != null, "Cannot find bytecode for %s", new Object[]{type});
         (new ClassReader(in)).accept(new LineNumberReader(this, (1)null), 4);
      }

   }

	public String getSource() {
		return this.source;
	}

	public Integer getLineNumber(Member member) {
		Preconditions.checkArgument(this.type == member.getDeclaringClass(), "Member %s belongs to %s, not %s",
				new Object[]{member, member.getDeclaringClass(), this.type});
		return (Integer) this.lines.get(MoreTypes.memberKey(member));
	}

	public int getFirstLine() {
		return this.firstLine == Integer.MAX_VALUE ? 1 : this.firstLine;
	}
}