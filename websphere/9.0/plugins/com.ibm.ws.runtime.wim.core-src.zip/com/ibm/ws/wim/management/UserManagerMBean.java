package com.ibm.ws.wim.management;

import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.websphere.management.RuntimeCollaborator;
import com.ibm.websphere.management.exception.AdminException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.util.Routines;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserManagerMBean extends RuntimeCollaborator {
	private static final String CLASSNAME = UserManagerMBean.class.getName();
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static final String MBEAN_TYPE = "UserManagerMBean";
	private static UserManagerMBean mBeanInst;

	private UserManagerMBean() {
		Routines.enterMethod(trcLogger, CLASSNAME, "UserManagerMBean", Level.FINEST);
		Routines.exitMethod(trcLogger, CLASSNAME, "UserManagerMBean", Level.FINEST);
	}

	public static synchronized UserManagerMBean getInstance() {
		Routines.enterMethod(trcLogger, CLASSNAME, "getInstance", Level.FINEST);
		if (mBeanInst == null) {
			mBeanInst = new UserManagerMBean();
		}

		Routines.exitMethod(trcLogger, CLASSNAME, "getInstance", Level.FINEST);
		return mBeanInst;
	}

	public String getDescription() {
		Routines.enterMethod(trcLogger, CLASSNAME, "getDescription", Level.FINEST);
		Routines.exitMethod(trcLogger, CLASSNAME, "getDescription", Level.FINEST);
		return "virtual member manager MBean";
	}

	public Boolean processEvent(String var1, String var2, Object var3) {
		Routines.enterMethod(trcLogger, CLASSNAME, "processEvent", Level.FINEST);
		DynamicReloadManager var5 = DynamicReloadManager.singleton();
		if (DynamicReloadManager.isRegisteredWithAdminAgentMode()) {
			msgLogger.logp(Level.INFO, CLASSNAME, "processEvent", "DYNAMIC_RELOAD_REGISTERED_PROFILE_RECEIVED_EVENT",
					new Object[]{var1});
		} else {
			msgLogger.logp(Level.INFO, CLASSNAME, "processEvent", "DYNAMIC_RELOAD_MANAGED_NODE_RECEIVED_EVENT",
					new Object[]{var1});
		}

		var5.logEventDetails(var1, var2, (EventDataWrapper) var3, trcLogger);
		var5.broadcastEventAtNode(var1, (EventDataWrapper) var3);
		Routines.exitMethod(trcLogger, CLASSNAME, "processEvent", Level.FINEST);
		return Boolean.TRUE;
	}

	public void deActivate() throws AdminException {
		Routines.enterMethod(trcLogger, CLASSNAME, "deActivate", Level.FINEST);
		if (this.getObjectName() != null) {
			AdminServiceFactory.getMBeanFactory().deactivateMBean(this.getObjectName());
		}

		Routines.exitMethod(trcLogger, CLASSNAME, "deActivate", Level.FINEST);
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
	}
}