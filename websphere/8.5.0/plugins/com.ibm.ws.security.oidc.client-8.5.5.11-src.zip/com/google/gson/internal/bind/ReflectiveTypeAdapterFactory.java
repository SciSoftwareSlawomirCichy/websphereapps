package com.google.gson.internal.bind;

import com.google.gson.FieldNamingStrategy;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.internal.Primitives;import com.google.gson.internal..Gson.Types;
import com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.1;
import com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter;
import com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.BoundField;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ReflectiveTypeAdapterFactory implements TypeAdapterFactory {
	private final ConstructorConstructor constructorConstructor;
	private final FieldNamingStrategy fieldNamingPolicy;
	private final Excluder excluder;

	public ReflectiveTypeAdapterFactory(ConstructorConstructor constructorConstructor,
			FieldNamingStrategy fieldNamingPolicy, Excluder excluder) {
		this.constructorConstructor = constructorConstructor;
		this.fieldNamingPolicy = fieldNamingPolicy;
		this.excluder = excluder;
	}

	public boolean excludeField(Field f, boolean serialize) {
		return !this.excluder.excludeClass(f.getType(), serialize) && !this.excluder.excludeField(f, serialize);
	}

	private String getFieldName(Field f) {
		SerializedName serializedName = (SerializedName) f.getAnnotation(SerializedName.class);
		return serializedName == null ? this.fieldNamingPolicy.translateName(f) : serializedName.value();
	}

	public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      Class<? super T> raw = type.getRawType();
      if (!Object.class.isAssignableFrom(raw)) {
         return null;
      } else {
         ObjectConstructor<T> constructor = this.constructorConstructor.get(type);
         return new Adapter(constructor, this.getBoundFields(gson, type, raw), (1)null);
      }
   }

	private BoundField createBoundField(Gson context, Field field, String name, TypeToken<?> fieldType, boolean serialize, boolean deserialize) {
      boolean isPrimitive = Primitives.isPrimitive(fieldType.getRawType());
      return new 1(this, name, serialize, deserialize, context, fieldType, field, isPrimitive);
   }

	private Map<String, BoundField> getBoundFields(Gson context, TypeToken<?> type, Class<?> raw) {
		Map<String, BoundField> result = new LinkedHashMap();
		if (raw.isInterface()) {
			return result;
		} else {
			for (Type declaredType = type.getType(); raw != Object.class; raw = type.getRawType()) {
				Field[] fields = raw.getDeclaredFields();
				Field[] arr$ = fields;
				int len$ = fields.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					Field field = arr$[i$];
					boolean serialize = this.excludeField(field, true);
					boolean deserialize = this.excludeField(field, false);
					if (serialize || deserialize) {
						field.setAccessible(true);
						Type fieldType = Types.resolve(type.getType(), raw, field.getGenericType());
						BoundField boundField = this.createBoundField(context, field, this.getFieldName(field),
								TypeToken.get(fieldType), serialize, deserialize);
						BoundField previous = (BoundField) result.put(boundField.name, boundField);
						if (previous != null) {
							throw new IllegalArgumentException(
									declaredType + " declares multiple JSON fields named " + previous.name);
						}
					}
				}

				type = TypeToken.get(Types.resolve(type.getType(), raw, raw.getGenericSuperclass()));
			}

			return result;
		}
	}
}