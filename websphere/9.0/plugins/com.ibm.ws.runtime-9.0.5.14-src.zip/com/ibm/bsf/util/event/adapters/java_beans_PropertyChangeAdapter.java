package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class java_beans_PropertyChangeAdapter extends EventAdapterImpl implements PropertyChangeListener {
	public void propertyChange(PropertyChangeEvent var1) {
		this.eventProcessor.processEvent(var1.getPropertyName(), new Object[]{var1});
	}
}