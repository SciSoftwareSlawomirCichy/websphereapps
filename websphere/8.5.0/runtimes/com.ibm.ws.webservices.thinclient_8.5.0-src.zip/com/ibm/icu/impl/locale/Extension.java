package com.ibm.icu.impl.locale;

import com.ibm.icu.impl.locale.LanguageTag.ParseStatus;

public class Extension {
	private char _key;
	protected String _value;

	protected Extension(char key) {
		this._key = key;
	}

	public char getKey() {
		return this._key;
	}

	public String getValue() {
		return this._value;
	}

	public String getID() {
		return this._key + "-" + this._value;
	}

	public String toString() {
		return this.getID();
	}

	public static Extension create(StringTokenIterator itr, ParseStatus sts) {
		if (!sts.isError() && !itr.isDone()) {
			Extension ext = null;
			String key = itr.current();
			if (LanguageTag.isExtensionSingleton(key) || LanguageTag.isPrivateuseSingleton(key)) {
				itr.next();
				ext = create(key.charAt(0), itr, sts);
			}

			return ext;
		} else {
			return null;
		}
	}

	public static Extension create(char key, StringTokenIterator val, ParseStatus sts) {
		if (sts.isError()) {
			return null;
		} else if (val.isDone()) {
			sts.errorIndex = val.currentStart();
			sts.errorMsg = "Missing extension subtag for extension :" + key;
			return null;
		} else {
			Extension ext = null;
			key = AsciiUtil.toLower(key);
			switch (key) {
				case 'u' :
					ext = new UnicodeLocaleExtension();
					break;
				case 'x' :
					ext = new PrivateuseExtension();
					break;
				default :
					ext = new Extension(key);
			}

			((Extension) ext).setExtensionValue(val, sts);
			return (Extension) (((Extension) ext).getValue() == null ? null : ext);
		}
	}

	protected void setExtensionValue(StringTokenIterator itr, ParseStatus sts) {
		if (!sts.isError() && !itr.isDone()) {
			StringBuilder buf = new StringBuilder();

			while (!itr.isDone()) {
				String s = itr.current();
				if (!LanguageTag.isExtensionSubtag(s)) {
					break;
				}

				s = LanguageTag.canonicalizeExtensionSubtag(s);
				if (buf.length() != 0) {
					buf.append("-");
				}

				buf.append(s);
				sts.parseLength = itr.currentEnd();
				itr.next();
			}

			if (buf.length() == 0) {
				sts.errorIndex = itr.currentStart();
				sts.errorMsg = "Invalid extension subtag: " + itr.current();
				this._value = null;
			} else {
				this._value = buf.toString();
			}

		} else {
			this._value = null;
		}
	}
}