package com.ibm.ejs.container;

public class BusinessRemoteWrapper extends EJSRemoteWrapper {
}