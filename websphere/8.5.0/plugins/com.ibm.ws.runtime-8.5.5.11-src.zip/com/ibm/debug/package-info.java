package com.ibm.debug;

interface package-info {
}