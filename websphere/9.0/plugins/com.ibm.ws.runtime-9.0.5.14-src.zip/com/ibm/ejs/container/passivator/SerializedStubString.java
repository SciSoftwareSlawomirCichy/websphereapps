package com.ibm.ejs.container.passivator;

import com.ibm.ejs.container.SerializedStub;
import com.ibm.ejs.oa.EJSORB;
import java.io.Serializable;
import javax.rmi.PortableRemoteObject;
import org.omg.CORBA.Object;

public class SerializedStubString implements Serializable {
	private static final long serialVersionUID = 221516676682695674L;
	private final String ivStub;
	private final Class<?> ivClass;

	SerializedStubString(SerializedStub serializedStub) {
		this.ivStub = EJSORB.init().object_to_string((Object) serializedStub.getStub());
		this.ivClass = serializedStub.getInterfaceClass();
	}

	private java.lang.Object readResolve() {
		java.lang.Object stub = EJSORB.init().string_to_object(this.ivStub);
		return PortableRemoteObject.narrow(stub, this.ivClass);
	}
}