package com.ibm.ejs.container;

public class InvalidBeanIdException extends ContainerException {
	private static final long serialVersionUID = -9118212346389086271L;

	public InvalidBeanIdException() {
	}

	public InvalidBeanIdException(Throwable exception) {
		super(exception);
	}
}