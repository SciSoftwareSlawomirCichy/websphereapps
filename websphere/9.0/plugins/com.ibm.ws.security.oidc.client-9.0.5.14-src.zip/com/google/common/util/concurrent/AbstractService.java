package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.AbstractService.1;
import com.google.common.util.concurrent.AbstractService.2;
import com.google.common.util.concurrent.AbstractService.3;
import com.google.common.util.concurrent.AbstractService.4;
import com.google.common.util.concurrent.AbstractService.5;
import com.google.common.util.concurrent.AbstractService.6;
import com.google.common.util.concurrent.AbstractService.HasReachedRunningGuard;
import com.google.common.util.concurrent.AbstractService.IsStartableGuard;
import com.google.common.util.concurrent.AbstractService.IsStoppableGuard;
import com.google.common.util.concurrent.AbstractService.IsStoppedGuard;
import com.google.common.util.concurrent.AbstractService.StateSnapshot;
import com.google.common.util.concurrent.ListenerCallQueue.Event;
import com.google.common.util.concurrent.Monitor.Guard;
import com.google.common.util.concurrent.Service.Listener;
import com.google.common.util.concurrent.Service.State;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.ForOverride;
import com.google.errorprone.annotations.concurrent.GuardedBy;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Beta
@GwtIncompatible
public abstract class AbstractService implements Service {
	private static final Event<Listener> STARTING_EVENT = new 1();
	private static final Event<Listener> RUNNING_EVENT = new 2();
	private static final Event<Listener> STOPPING_FROM_STARTING_EVENT;
	private static final Event<Listener> STOPPING_FROM_RUNNING_EVENT;
	private static final Event<Listener> TERMINATED_FROM_NEW_EVENT;
	private static final Event<Listener> TERMINATED_FROM_STARTING_EVENT;
	private static final Event<Listener> TERMINATED_FROM_RUNNING_EVENT;
	private static final Event<Listener> TERMINATED_FROM_STOPPING_EVENT;
	private final Monitor monitor = new Monitor();
	private final Guard isStartable = new IsStartableGuard(this);
	private final Guard isStoppable = new IsStoppableGuard(this);
	private final Guard hasReachedRunning = new HasReachedRunningGuard(this);
	private final Guard isStopped = new IsStoppedGuard(this);
	private final ListenerCallQueue<Listener> listeners = new ListenerCallQueue();
	private volatile StateSnapshot snapshot;

	private static Event<Listener> terminatedEvent(State from) {
      return new 3(from);
   }

	private static Event<Listener> stoppingEvent(State from) {
      return new 4(from);
   }

	protected AbstractService() {
		this.snapshot = new StateSnapshot(State.NEW);
	}

	@ForOverride
	protected abstract void doStart();

	@ForOverride
	protected abstract void doStop();

	@ForOverride
	protected void doCancelStart() {
	}

	@CanIgnoreReturnValue
	public final Service startAsync() {
		if (this.monitor.enterIf(this.isStartable)) {
			try {
				this.snapshot = new StateSnapshot(State.STARTING);
				this.enqueueStartingEvent();
				this.doStart();
			} catch (Throwable var5) {
				this.notifyFailed(var5);
			} finally {
				this.monitor.leave();
				this.dispatchListenerEvents();
			}

			return this;
		} else {
			throw new IllegalStateException("Service " + this + " has already been started");
		}
	}

	@CanIgnoreReturnValue
   public final Service stopAsync() {
      if (this.monitor.enterIf(this.isStoppable)) {
         try {
            State previous = this.state();
            switch(6.$SwitchMap$com$google$common$util$concurrent$Service$State[previous.ordinal()]) {
            case 1:
               this.snapshot = new StateSnapshot(State.TERMINATED);
               this.enqueueTerminatedEvent(State.NEW);
               break;
            case 2:
               this.snapshot = new StateSnapshot(State.STARTING, true, (Throwable)null);
               this.enqueueStoppingEvent(State.STARTING);
               this.doCancelStart();
               break;
            case 3:
               this.snapshot = new StateSnapshot(State.STOPPING);
               this.enqueueStoppingEvent(State.RUNNING);
               this.doStop();
               break;
            case 4:
            case 5:
            case 6:
               throw new AssertionError("isStoppable is incorrectly implemented, saw: " + previous);
            }
         } catch (Throwable var5) {
            this.notifyFailed(var5);
         } finally {
            this.monitor.leave();
            this.dispatchListenerEvents();
         }
      }

      return this;
   }

	public final void awaitRunning() {
		this.monitor.enterWhenUninterruptibly(this.hasReachedRunning);

		try {
			this.checkCurrentState(State.RUNNING);
		} finally {
			this.monitor.leave();
		}

	}

	public final void awaitRunning(long timeout, TimeUnit unit) throws TimeoutException {
		if (this.monitor.enterWhenUninterruptibly(this.hasReachedRunning, timeout, unit)) {
			try {
				this.checkCurrentState(State.RUNNING);
			} finally {
				this.monitor.leave();
			}

		} else {
			throw new TimeoutException("Timed out waiting for " + this + " to reach the RUNNING state.");
		}
	}

	public final void awaitTerminated() {
		this.monitor.enterWhenUninterruptibly(this.isStopped);

		try {
			this.checkCurrentState(State.TERMINATED);
		} finally {
			this.monitor.leave();
		}

	}

	public final void awaitTerminated(long timeout, TimeUnit unit) throws TimeoutException {
		if (this.monitor.enterWhenUninterruptibly(this.isStopped, timeout, unit)) {
			try {
				this.checkCurrentState(State.TERMINATED);
			} finally {
				this.monitor.leave();
			}

		} else {
			throw new TimeoutException(
					"Timed out waiting for " + this + " to reach a terminal state. Current state: " + this.state());
		}
	}

	@GuardedBy("monitor")
	private void checkCurrentState(State expected) {
		State actual = this.state();
		if (actual != expected) {
			if (actual == State.FAILED) {
				throw new IllegalStateException(
						"Expected the service " + this + " to be " + expected + ", but the service has FAILED",
						this.failureCause());
			} else {
				throw new IllegalStateException(
						"Expected the service " + this + " to be " + expected + ", but was " + actual);
			}
		}
	}

	protected final void notifyStarted() {
		this.monitor.enter();

		try {
			if (this.snapshot.state != State.STARTING) {
				IllegalStateException failure = new IllegalStateException(
						"Cannot notifyStarted() when the service is " + this.snapshot.state);
				this.notifyFailed(failure);
				throw failure;
			}

			if (this.snapshot.shutdownWhenStartupFinishes) {
				this.snapshot = new StateSnapshot(State.STOPPING);
				this.doStop();
			} else {
				this.snapshot = new StateSnapshot(State.RUNNING);
				this.enqueueRunningEvent();
			}
		} finally {
			this.monitor.leave();
			this.dispatchListenerEvents();
		}

	}

	protected final void notifyStopped() {
      this.monitor.enter();

      try {
         State previous = this.state();
         switch(6.$SwitchMap$com$google$common$util$concurrent$Service$State[previous.ordinal()]) {
         case 1:
         case 5:
         case 6:
            throw new IllegalStateException("Cannot notifyStopped() when the service is " + previous);
         case 2:
         case 3:
         case 4:
            this.snapshot = new StateSnapshot(State.TERMINATED);
            this.enqueueTerminatedEvent(previous);
         }
      } finally {
         this.monitor.leave();
         this.dispatchListenerEvents();
      }

   }

	protected final void notifyFailed(Throwable cause) {
      Preconditions.checkNotNull(cause);
      this.monitor.enter();

      try {
         State previous = this.state();
         switch(6.$SwitchMap$com$google$common$util$concurrent$Service$State[previous.ordinal()]) {
         case 1:
         case 5:
            throw new IllegalStateException("Failed while in state:" + previous, cause);
         case 2:
         case 3:
         case 4:
            this.snapshot = new StateSnapshot(State.FAILED, false, cause);
            this.enqueueFailedEvent(previous, cause);
         case 6:
         }
      } finally {
         this.monitor.leave();
         this.dispatchListenerEvents();
      }

   }

	public final boolean isRunning() {
		return this.state() == State.RUNNING;
	}

	public final State state() {
		return this.snapshot.externalState();
	}

	public final Throwable failureCause() {
		return this.snapshot.failureCause();
	}

	public final void addListener(Listener listener, Executor executor) {
		this.listeners.addListener(listener, executor);
	}

	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.state() + "]";
	}

	private void dispatchListenerEvents() {
		if (!this.monitor.isOccupiedByCurrentThread()) {
			this.listeners.dispatch();
		}

	}

	private void enqueueStartingEvent() {
		this.listeners.enqueue(STARTING_EVENT);
	}

	private void enqueueRunningEvent() {
		this.listeners.enqueue(RUNNING_EVENT);
	}

	private void enqueueStoppingEvent(State from) {
		if (from == State.STARTING) {
			this.listeners.enqueue(STOPPING_FROM_STARTING_EVENT);
		} else {
			if (from != State.RUNNING) {
				throw new AssertionError();
			}

			this.listeners.enqueue(STOPPING_FROM_RUNNING_EVENT);
		}

	}

	private void enqueueTerminatedEvent(State from) {
      switch(6.$SwitchMap$com$google$common$util$concurrent$Service$State[from.ordinal()]) {
      case 1:
         this.listeners.enqueue(TERMINATED_FROM_NEW_EVENT);
         break;
      case 2:
         this.listeners.enqueue(TERMINATED_FROM_STARTING_EVENT);
         break;
      case 3:
         this.listeners.enqueue(TERMINATED_FROM_RUNNING_EVENT);
         break;
      case 4:
         this.listeners.enqueue(TERMINATED_FROM_STOPPING_EVENT);
         break;
      case 5:
      case 6:
         throw new AssertionError();
      }

   }

	private void enqueueFailedEvent(State from, Throwable cause) {
      this.listeners.enqueue(new 5(this, from, cause));
   }

	static {
		STOPPING_FROM_STARTING_EVENT = stoppingEvent(State.STARTING);
		STOPPING_FROM_RUNNING_EVENT = stoppingEvent(State.RUNNING);
		TERMINATED_FROM_NEW_EVENT = terminatedEvent(State.NEW);
		TERMINATED_FROM_STARTING_EVENT = terminatedEvent(State.STARTING);
		TERMINATED_FROM_RUNNING_EVENT = terminatedEvent(State.RUNNING);
		TERMINATED_FROM_STOPPING_EVENT = terminatedEvent(State.STOPPING);
	}
}