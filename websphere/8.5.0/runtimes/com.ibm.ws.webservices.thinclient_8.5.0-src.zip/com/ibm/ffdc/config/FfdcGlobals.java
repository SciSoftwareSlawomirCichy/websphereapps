package com.ibm.ffdc.config;

import com.ibm.ffdc.osgi.Activator;
import org.osgi.framework.BundleContext;

public class FfdcGlobals {
	private static BundleContext bundleContext = null;

	public static BundleContext getBundleContext() {
		if (bundleContext == null) {
			bundleContext = Activator.getBundleContext();
		}

		return bundleContext;
	}
}