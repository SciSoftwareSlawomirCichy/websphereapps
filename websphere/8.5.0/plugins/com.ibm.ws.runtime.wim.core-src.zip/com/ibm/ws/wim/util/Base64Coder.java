package com.ibm.ws.wim.util;

public class Base64Coder {
	private static byte[] Base64EncMap;
	private static byte[] Base64DecMap;

	public static final byte[] base64Decode(byte[] var0) {
		if (var0 == null) {
			return null;
		} else {
			int var1;
			for (var1 = var0.length; var0[var1 - 1] == 61; --var1) {
				;
			}

			byte[] var2 = new byte[var1 - var0.length / 4];

			int var3;
			for (var3 = 0; var3 < var0.length; ++var3) {
				var0[var3] = Base64DecMap[var0[var3]];
			}

			var3 = 0;

			int var4;
			for (var4 = 0; var4 < var2.length - 2; var4 += 3) {
				var2[var4] = (byte) (var0[var3] << 2 & 255 | var0[var3 + 1] >>> 4 & 3);
				var2[var4 + 1] = (byte) (var0[var3 + 1] << 4 & 255 | var0[var3 + 2] >>> 2 & 15);
				var2[var4 + 2] = (byte) (var0[var3 + 2] << 6 & 255 | var0[var3 + 3] & 63);
				var3 += 4;
			}

			if (var4 < var2.length) {
				var2[var4] = (byte) (var0[var3] << 2 & 255 | var0[var3 + 1] >>> 4 & 3);
			}

			++var4;
			if (var4 < var2.length) {
				var2[var4] = (byte) (var0[var3 + 1] << 4 & 255 | var0[var3 + 2] >>> 2 & 15);
			}

			return var2;
		}
	}

	public static final String base64DecodeNew(String var0) {
		if (var0 == null) {
			return null;
		} else {
			byte[] var1 = var0.getBytes();
			return new String(base64Decode(var1));
		}
	}

	public static final String base64Decode(String var0) {
		if (var0 == null) {
			return null;
		} else {
			byte[] var1 = var0.getBytes();
			return StringUtil.toString(base64Decode(var1));
		}
	}

	public static final byte[] base64Encode(byte[] var0) {
		if (var0 == null) {
			return null;
		} else {
			byte[] var1 = new byte[(var0.length + 2) / 3 * 4];
			int var2 = 0;

			int var3;
			for (var3 = 0; var2 < var0.length - 2; var2 += 3) {
				var1[var3++] = Base64EncMap[var0[var2] >>> 2 & 63];
				var1[var3++] = Base64EncMap[var0[var2 + 1] >>> 4 & 15 | var0[var2] << 4 & 63];
				var1[var3++] = Base64EncMap[var0[var2 + 2] >>> 6 & 3 | var0[var2 + 1] << 2 & 63];
				var1[var3++] = Base64EncMap[var0[var2 + 2] & 63];
			}

			if (var2 < var0.length) {
				var1[var3++] = Base64EncMap[var0[var2] >>> 2 & 63];
				if (var2 < var0.length - 1) {
					var1[var3++] = Base64EncMap[var0[var2 + 1] >>> 4 & 15 | var0[var2] << 4 & 63];
					var1[var3++] = Base64EncMap[var0[var2 + 1] << 2 & 63];
				} else {
					var1[var3++] = Base64EncMap[var0[var2] << 4 & 63];
				}
			}

			while (var3 < var1.length) {
				var1[var3] = 61;
				++var3;
			}

			return var1;
		}
	}

	public static final String base64Encode(String var0) {
		if (var0 == null) {
			return null;
		} else {
			byte[] var1 = StringUtil.getBytes(var0);
			return new String(base64Encode(var1));
		}
	}

	static {
		byte[] var0 = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86,
				87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114,
				115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47};
		Base64EncMap = var0;
		Base64DecMap = new byte[128];

		for (int var1 = 0; var1 < Base64EncMap.length; ++var1) {
			Base64DecMap[Base64EncMap[var1]] = (byte) var1;
		}

	}
}