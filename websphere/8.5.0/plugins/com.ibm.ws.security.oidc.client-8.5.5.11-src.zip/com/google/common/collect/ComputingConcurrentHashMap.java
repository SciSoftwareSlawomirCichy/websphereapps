package com.google.common.collect;

import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.ComputingConcurrentHashMap.ComputingSegment;
import com.google.common.collect.ComputingConcurrentHashMap.ComputingSerializationProxy;
import com.google.common.collect.MapMakerInternalMap.Segment;
import java.util.concurrent.ExecutionException;

class ComputingConcurrentHashMap<K, V> extends MapMakerInternalMap<K, V> {
	final Function<? super K, ? extends V> computingFunction;
	private static final long serialVersionUID = 4L;

	ComputingConcurrentHashMap(MapMaker builder, Function<? super K, ? extends V> computingFunction) {
		super(builder);
		this.computingFunction = (Function) Preconditions.checkNotNull(computingFunction);
	}

	Segment<K, V> createSegment(int initialCapacity, int maxSegmentSize) {
		return new ComputingSegment(this, initialCapacity, maxSegmentSize);
	}

	ComputingSegment<K, V> segmentFor(int hash) {
		return (ComputingSegment) super.segmentFor(hash);
	}

	V getOrCompute(K key) throws ExecutionException {
		int hash = this.hash(Preconditions.checkNotNull(key));
		return this.segmentFor(hash).getOrCompute(key, hash, this.computingFunction);
	}

	Object writeReplace() {
		return new ComputingSerializationProxy(this.keyStrength, this.valueStrength, this.keyEquivalence,
				this.valueEquivalence, this.expireAfterWriteNanos, this.expireAfterAccessNanos, this.maximumSize,
				this.concurrencyLevel, this.removalListener, this, this.computingFunction);
	}
}