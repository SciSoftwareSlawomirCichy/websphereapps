package com.ibm.ws.wim;

import com.ibm.websphere.wim.Service;
import com.ibm.websphere.wim.ServiceProvider;
import com.ibm.websphere.wim.exception.CertificateMapFailedException;
import com.ibm.websphere.wim.exception.CertificateMapNotSupportedException;
import com.ibm.websphere.wim.exception.DuplicateLogonIdException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InvalidUniqueNameException;
import com.ibm.websphere.wim.exception.MissingInitPropertyException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.PasswordCheckFailedException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.ws.wim.SPIServiceProvider.1;
import com.ibm.ws.wim.adapter.file.was.FileAdapter;
import com.ibm.ws.wim.config.ConfigUtils;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.util.ControlsHelper;
import com.ibm.ws.wim.util.DataGraphHelper;
import com.ibm.ws.wim.util.UniqueNameHelper;
import com.ibm.wsspi.wim.Repository;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SPIServiceProvider implements Service {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = SPIServiceProvider.class.getName();
	private static final Logger trcLogger;
	private Service service = null;
	private String sessionId = null;
	private ConfigurationProviderType configDO = null;
	private RealmConfigurationType realmConfig = null;
	private String defaultRealmName = null;
	private Map realmParticipatingBaseEntries = new HashMap();
	private Map realm2ReposSearchBases = new HashMap();
	private Repository[] repositories = null;
	private List reposDOs = null;
	private String[] reposIds = null;
	private int numOfRepos = 0;
	private List[] reposNodes = null;
	private List[] reposNodesLowerCase = null;

	public SPIServiceProvider(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "<init>", "inputSessionId=" + var1);
		}

		this.sessionId = var1;
		this.service = ServiceProvider.singleton();
		this.initialize();
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "<init>");
		}

	}

	public void initialize() throws WIMException {
      if (trcLogger.isLoggable(Level.FINE)) {
         trcLogger.entering(CLASSNAME, "initialize");
      }

      if (trcLogger.isLoggable(Level.FINE)) {
         trcLogger.logp(Level.FINE, CLASSNAME, "initialize", "getting the config for sessionId=" + this.sessionId);
      }

      this.configDO = (ConfigurationProviderType)ProfileSecurityManager.singleton().runAsSuperUser(new 1(this));
      if (trcLogger.isLoggable(Level.FINE)) {
         trcLogger.logp(Level.FINE, CLASSNAME, "initialize", "current config=" + WIMTraceHelper.printDataGraph((DataObject)this.configDO));
      }

      this.processRepositories();
      this.processRealms();
      if (trcLogger.isLoggable(Level.FINE)) {
         trcLogger.exiting(CLASSNAME, "initialize");
      }

   }

	private void processRepositories() throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "processRepositories");
		}

		List var2 = ConfigUtils.getProfileRepositories(this.configDO);
		this.numOfRepos = var2.size();
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "processRepositories", "number of repos=" + this.numOfRepos);
		}

		this.repositories = new Repository[this.numOfRepos];
		this.reposDOs = new ArrayList();
		this.reposNodes = new List[this.numOfRepos];
		this.reposNodesLowerCase = new List[this.numOfRepos];
		this.reposIds = new String[this.numOfRepos];
		String var3 = null;

		for (int var4 = 0; var4 < this.numOfRepos; ++var4) {
			this.repositories[var4] = null;
			DataObject var5 = (DataObject) var2.get(var4);
			this.reposDOs.add(var5);
			var3 = var5.getString("id");
			this.reposIds[var4] = var3;
			List var6 = var5.getList("baseEntries");
			this.reposNodes[var4] = new ArrayList(var6.size());
			this.reposNodesLowerCase[var4] = new ArrayList(var6.size());

			for (int var7 = 0; var7 < var6.size(); ++var7) {
				DataObject var8 = (DataObject) var6.get(var7);
				String var9 = var8.getString("name");
				var9 = UniqueNameHelper.getValidUniqueName(var9);
				this.reposNodes[var4].add(var9.trim());
				this.reposNodesLowerCase[var4].add(var9.trim().toLowerCase());
			}
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "processRepositories");
		}

	}

	private void processRealms() throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "processRealms");
		}

		this.realmConfig = this.configDO.getRealmConfiguration();
		this.defaultRealmName = this.realmConfig.getDefaultRealm();
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "processRealms", "defaultRealmName=" + this.defaultRealmName);
		}

		List var2 = this.realmConfig.getRealms();

		for (int var3 = 0; var3 < var2.size(); ++var3) {
			RealmType var4 = (RealmType) var2.get(var3);
			String var5 = var4.getName();
			List var6 = var4.getParticipatingBaseEntries();
			ArrayList var7 = new ArrayList();

			for (int var8 = 0; var8 < var6.size(); ++var8) {
				var7.add(((ParticipatingBaseEntriesType) var6.get(var8)).getName());
			}

			this.realmParticipatingBaseEntries.put(var5, var7);
			Map var9 = this.seperateParticipatingBaseEntriesByReposIndex(var7);
			if (var9 != null) {
				this.realm2ReposSearchBases.put(var5, var9);
			}
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "processRealms", "realmParticipatingBaseEntries="
					+ this.realmParticipatingBaseEntries + ", realm2ReposSearchBases=" + this.realm2ReposSearchBases);
		}

	}

	private Map seperateParticipatingBaseEntriesByReposIndex(List var1) throws WIMException {
		HashMap var2 = null;
		if (var1 != null) {
			var2 = new HashMap();

			for (int var3 = 0; var3 < var1.size(); ++var3) {
				String var4 = (String) var1.get(var3);
				int var5 = this.getRepositoryIndexByUniqueName(var4);
				Object var6 = (List) var2.get(new Integer(var5));
				if (var6 == null) {
					var6 = new ArrayList();
				}

				((List) var6).add(var4);
				var2.put(new Integer(var5), var6);
			}
		}

		return var2;
	}

	private int getRepositoryIndexByUniqueName(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "getRepositoryIndexByUniqueName", "uniqueName=" + var1);
		}

		int var3 = -1;
		int var4 = -1;
		String var5 = var1.trim().toLowerCase();

		label52 : for (int var6 = 0; var6 < this.reposNodesLowerCase.length; ++var6) {
			List var7 = this.reposNodesLowerCase[var6];

			for (int var8 = 0; var8 < var7.size(); ++var8) {
				String var9 = (String) var7.get(var8);
				int var10 = var9.length();
				if (var10 == 0 && var4 < var10) {
					var3 = var6;
					var4 = var10;
				}

				if (var5.length() == var10 && var5.equals(var9)) {
					var3 = var6;
					break label52;
				}

				if (var5.length() > var10 && var5.endsWith("," + var9) && var4 < var10) {
					var3 = var6;
					var4 = var10;
				}
			}
		}

		if (var3 == -1) {
			throw new InvalidUniqueNameException("ENTITY_NOT_IN_REALM_SCOPE",
					WIMMessageHelper.generateMsgParms(var1, "defined"), CLASSNAME, "getRepositoryIndexByUniqueName");
		} else {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.exiting(CLASSNAME, "getRepositoryIndexByUniqueName", "reposIndex=" + var3);
			}

			return var3;
		}
	}

	private Map initializeRepositories(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "initializeRepositories", "realm=" + var1);
		}

		Map var3 = (Map) this.realm2ReposSearchBases.get(var1);
		Iterator var4 = var3.keySet().iterator();

		while (true) {
			int var5;
			DataObject var6;
			do {
				if (!var4.hasNext()) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.exiting(CLASSNAME, "initializeRepositories");
					}

					return var3;
				}

				var5 = (Integer) var4.next();
				var6 = (DataObject) this.reposDOs.get(var5);
			} while (var6 == null);

			this.reposDOs.set(var5, (Object) null);
			String var7 = var6.getString("id");
			String var8 = var6.getType().getName();
			String var9 = var6.getString("adapterClassName");
			if (var9 == null) {
				if (var8.equals("DatabaseRepositoryType")) {
					var9 = "com.ibm.ws.wim.adapter.db.DBAdapter";
				} else if (var8.equals("FileRepositoryType")) {
					var9 = "com.ibm.ws.wim.adapter.file.was.FileAdapter";
				} else {
					if (!var8.equals("LdapRepositoryType")) {
						throw new MissingInitPropertyException("MISSING_INI_PROPERTY",
								WIMMessageHelper.generateMsgParms("adapterClassName"), CLASSNAME,
								"initializeRepositories");
					}

					var9 = "com.ibm.ws.wim.adapter.ldap.LdapAdapter";
				}
			}

			try {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "initializeRepositories", "initializing repository: " + var7);
				}

				if (var8.equals("FileRepositoryType") && var9.equals("com.ibm.ws.wim.adapter.file.was.FileAdapter")) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "initializeRepositories",
								"initializing file repository with sessionId: " + this.sessionId);
					}

					FileAdapter var17 = new FileAdapter(this.sessionId, (DataObject) this.configDO, var6);
					this.repositories[var5] = var17;
				} else {
					Class var10;
					try {
						var10 = Class.forName(var9);
					} catch (ClassNotFoundException var13) {
						ClassLoader var12 = Thread.currentThread().getContextClassLoader();
						if (var12 == null) {
							var12 = this.getClass().getClassLoader();
						}

						var10 = Class.forName(var9, true, var12);
					}

					this.repositories[var5] = (Repository) var10.newInstance();
					this.repositories[var5].initialize(var6);
				}
			} catch (ClassNotFoundException var14) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms(var7, var14.getMessage()), CLASSNAME,
						"initializeRepositories", var14);
			} catch (InstantiationException var15) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms(var7, var15.getMessage()), CLASSNAME,
						"initializeRepositories", var15);
			} catch (IllegalAccessException var16) {
				throw new WIMSystemException("REPOSITORY_INITIALIZATION_FAILED",
						WIMMessageHelper.generateMsgParms(var7, var16.getMessage()), CLASSNAME,
						"initializeRepositories", var16);
			}
		}
	}

	public DataObject getConfig() throws WIMException, RemoteException {
		return (DataObject) this.configDO;
	}

	public DataObject login(DataObject var1) throws WIMException, RemoteException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "login");
		}

		if (var1 == null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "login");
			}

			return null;
		} else {
			DataObject var3 = null;
			HashMap var4 = new HashMap();
			Object var5 = null;
			Object var6 = null;
			String var7 = null;
			Object var8 = null;
			List var9 = var1.getList("entities");
			if (var9.size() == 0) {
				throw new EntityNotFoundException("MISSING_ENTITY_DATA_OBJECT",
						WIMMessageHelper.generateMsgParms("login"), CLASSNAME, "login");
			} else if (var9.size() > 1) {
				throw new OperationNotSupportedException("ACTION_MULTIPLE_ENTITIES_SPECIFIED",
						WIMMessageHelper.generateMsgParms("login"), CLASSNAME, "login");
			} else {
				DataObject var10 = (DataObject) var9.get(0);
				var7 = var10.getString("principalName");
				byte[] var31 = var10.getBytes("password");
				Map var11 = ControlsHelper.getControlMap(var1.getDataGraph());
				if (var11.get("LoginControl") == null) {
					var1.createDataObject("controls", "http://www.ibm.com/websphere/wim", "LoginControl");
				}

				String var12 = this.getRealmName(var1);
				Map var13 = this.initializeRepositories(var12);

				try {
					Iterator var14 = var13.keySet().iterator();

					while (var14.hasNext()) {
						Integer var15 = (Integer) var14.next();
						List var16 = (List) var13.get(var15);
						int var17 = var15;
						if (var16 != null && var16.size() > 0) {
							try {
								DataObject var18 = DataGraphHelper.cloneRootDataObject(var1);
								Map var33 = ControlsHelper.getControlMap(var18.getDataGraph());
								DataObject var20 = (DataObject) var33.get("LoginControl");
								var20.setList("searchBases", var16);
								DataObject var21 = this.repositories[var17].login(var18);
								if (trcLogger.isLoggable(Level.FINER)) {
									trcLogger.logp(Level.FINER, CLASSNAME, "login",
											"after calling adapter [" + this.reposIds[var17] + "]");
								}

								if (var3 == null) {
									if (var21.getList("entities").size() > 0) {
										var3 = var21;
										String var10000 = this.reposIds[var17];
									}
								} else if (var21.getList("entities").size() > 0) {
									throw new DuplicateLogonIdException("MULTIPLE_PRINCIPALS_FOUND",
											WIMMessageHelper.generateMsgParms(var7), CLASSNAME, "login");
								}
							} catch (PasswordCheckFailedException var27) {
								String var19 = var27.getMessageKey();
								if (!"PRINCIPAL_NOT_FOUND".equals(var19)) {
									if ("MISSING_OR_EMPTY_PRINCIPAL_NAME".equals(var19)) {
										throw var27;
									}

									if ("MULTIPLE_PRINCIPALS_FOUND".equals(var19)) {
										throw var27;
									}

									var5 = var27;
									this.recordLoginException(var27, var4);
								}
							} catch (CertificateMapFailedException var28) {
								var5 = var28;
								this.recordLoginException(var28, var4);
							} catch (CertificateMapNotSupportedException var29) {
								var5 = var29;
								this.recordLoginException(var29, var4);
							}
						}
					}
				} finally {
					PasswordUtil.erasePassword(var31);
				}

				int var32 = var4.size();
				if (var3 == null) {
					if (var32 == 0) {
						if (var4.containsKey(CertificateMapNotSupportedException.class.getName())) {
							throw new CertificateMapNotSupportedException("AUTHENTICATE_NOT_SUPPORTED",
									WIMMessageHelper.generateMsgParms("the specified certificate"), CLASSNAME, "login");
						}

						throw new PasswordCheckFailedException("PRINCIPAL_NOT_FOUND",
								WIMMessageHelper.generateMsgParms(var7), CLASSNAME, "login");
					}

					if (var32 == 1) {
						throw var5;
					}

					if (var32 > 1) {
						trcLogger.logp(Level.FINER, CLASSNAME, "login", "countedException > 1 [" + var32 + "]");
						throw new DuplicateLogonIdException("MULTIPLE_PRINCIPALS_FOUND",
								WIMMessageHelper.generateMsgParms(var7), CLASSNAME, "login");
					}
				} else if (var32 == 0) {
					trcLogger.logp(Level.FINER, CLASSNAME, "login", "login successful.");
				} else if (var32 >= 1) {
					trcLogger.logp(Level.FINER, CLASSNAME, "login", "result != null && countedException >= 1");
					throw new DuplicateLogonIdException("MULTIPLE_PRINCIPALS_FOUND",
							WIMMessageHelper.generateMsgParms(var7), CLASSNAME, "login");
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "login");
				}

				return var3;
			}
		}
	}

	public DataObject search(DataObject var1) throws WIMException, RemoteException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_API search", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var3 = null;

		try {
			DataObject var4 = DataGraphHelper.cloneRootDataObject(var1);
			Map var5 = ControlsHelper.getControlMap(var4);
			DataObject var6 = (DataObject) var5.get("SearchControl");
			int var7 = var6.getInt("countLimit");
			if (var7 < 0) {
				throw new SearchControlException("INCORRECT_COUNT_LIMIT",
						WIMMessageHelper.generateMsgParms(new Integer(var7)), CLASSNAME, "search");
			}

			var6.setInt("countLimit", var7);
			String var8 = this.getRealmName(var4);
			Map var9 = this.initializeRepositories(var8);
			var3 = SDOHelper.createRootDataObject();
			int var10 = 0;
			Iterator var11 = var9.keySet().iterator();

			while (var11.hasNext()) {
				int var12 = (Integer) var11.next();
				List var13 = this.searchRepository(var12, var4);
				if (var13 != null && var13.size() > 0) {
					var10 += var13.size();
					if (var13 != null) {
						var3.getList("entities").addAll(var13);
					}
				}
			}

			if (var7 > 0 && var7 < var10) {
				DataObject var15 = var3.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"SearchResponseControl");
				var15.setBoolean("hasMoreResults", true);
			}
		} catch (Exception var14) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "WIM_API search", var14.getMessage(), var14);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_API search", WIMTraceHelper.printDataGraph(var3));
		}

		return var3;
	}

	private String getRealmName(DataObject var1) throws WIMApplicationException {
		String var2 = null;
		List var3 = var1.getList("contexts");
		if (var3 != null && var3.size() != 0) {
			for (int var4 = 0; var4 < var3.size() && (var2 == null || var2.length() == 0); ++var4) {
				DataObject var5 = (DataObject) var3.get(var4);
				String var6 = var5.getString("key");
				if (var6 != null && "realm".equals(var6)) {
					var2 = (String) var5.get("value");
				}
			}

			if (var2 == null) {
				var2 = this.defaultRealmName;
			}
		} else {
			var2 = this.defaultRealmName;
		}

		return var2;
	}

	private List searchRepository(int var1, DataObject var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "searchRepository");
		}

		DataObject var4 = null;
		List var5 = null;
		var4 = this.repositories[var1].search(var2);
		if (var4 != null) {
			var5 = var4.getList("entities");
		}

		if (var4 != null) {
			var5 = var4.getList("entities");
			if (var5 != null && var5.size() > 0) {
				for (int var6 = 0; var6 < var5.size(); ++var6) {
					DataObject var7 = ((DataObject) var5.get(var6)).getDataObject("identifier");
					String var8 = var7.getString("externalId");
					var7.setString("repositoryId", this.reposIds[var1]);
					var7.setString("uniqueId", var8);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "searchRepository", WIMTraceHelper.printObjectArray(new Object[]{var5}));
		}

		return var5;
	}

	private void recordLoginException(WIMException var1, Map var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "recordLoginException");
		}

		String var4 = var1.getMessageKey();
		if (var2.containsKey(var4)) {
			int var5 = (Integer) var2.get(var4) + 1;
			var2.put(var4, new Integer(var5));
		} else {
			var2.put(var4, new Integer(1));
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "recordLoginException", "record exception [" + var4 + "]");
			trcLogger.exiting(CLASSNAME, "recordLoginException");
		}

	}

	public DataObject create(DataObject var1) throws WIMException, RemoteException {
		throw new WIMException("API not implemented: create");
	}

	public DataObject createDataObject(String var1, String var2) throws WIMException, RemoteException {
		return this.service.createDataObject(var1, var2);
	}

	public DataObject createRootDataObject() throws WIMException, RemoteException {
		return this.service.createRootDataObject();
	}

	public DataObject createSchema(DataObject var1) throws WIMException, RemoteException {
		throw new WIMException("API not implemented: createSchema");
	}

	public DataObject delete(DataObject var1) throws WIMException, RemoteException {
		throw new WIMException("API not implemented: delete");
	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException, RemoteException {
		throw new WIMException("API not implemented: dynamicUpdateConfig");
	}

	public DataObject get(DataObject var1) throws WIMException, RemoteException {
		throw new WIMException("API not implemented: get");
	}

	public byte[] getConfigEPackage() throws WIMException, RemoteException {
		throw new WIMException("API not implemented: getConfigEPackage");
	}

	public byte[] getEPackages(String var1) throws WIMException, RemoteException {
		return this.service.getEPackages(var1);
	}

	public DataObject getSchema(DataObject var1) throws WIMException, RemoteException {
		return this.service.getSchema(var1);
	}

	public DataObject update(DataObject var1) throws WIMException, RemoteException {
		throw new WIMException("API not implemented: update");
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}