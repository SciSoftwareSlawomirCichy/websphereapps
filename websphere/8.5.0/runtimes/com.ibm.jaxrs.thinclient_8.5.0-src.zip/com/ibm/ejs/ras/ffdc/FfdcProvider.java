package com.ibm.ejs.ras.ffdc;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.ffdc.FfdcProvider.1;
import com.ibm.ejs.ras.ffdc.FfdcProvider.2;
import com.ibm.ejs.ras.ffdc.FfdcProvider.3;
import com.ibm.ejs.ras.ffdc.FfdcProvider.Source;
import com.ibm.ffdc.Ffdc;
import com.ibm.ffdc.config.Formattable;
import com.ibm.ffdc.util.provider.IncidentEntry;
import com.ibm.ws.ffdc.FFDCFilter;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class FfdcProvider extends com.ibm.ffdc.util.provider.FfdcProvider
		implements
			com.ibm.ffdc.provider.FfdcProvider {
	private IncidentLogger<FfdcProvider> incidentLogger;
	private IncidentSummaryLogger incidentSummaryLogger;
	private static final String className = FfdcProvider.class.getName();
	private static final TraceComponent tc;
	private static final String ALT_FFDC_LOG_FILE = "com.ibm.ejs.ras.lite.ffdcLogFile";
	private static String ffdcFileName;
	private static final String COMMA_PATTERN = ",";
	private static Set<Source> _ignoredSources;
	private static final int internalErrorsLimit = 10;
	private int internalErrors = 0;
	static boolean reportedError;

	private static void ignoreSource(String sourceid, String probeid) {
		Tr.debug(tc, "Ignoring FFDCs from sourceid=" + sourceid + " and probeid=" + probeid);
		_ignoredSources.add(new Source(sourceid, probeid));
	}

	public IncidentSummaryLogger getIncidentSummaryLogger() {
		if (this.incidentSummaryLogger == null) {
			this.incidentSummaryLogger = new IncidentSummaryLogger(this);
		}

		return this.incidentSummaryLogger;
	}

	public synchronized IncidentLogger<FfdcProvider> getIncidentLogger() {
		if (this.incidentLogger == null) {
			this.incidentLogger = new IncidentLogger(this);
		}

		return this.incidentLogger;
	}

	public Ffdc getFfdc(Throwable th, Object reporter, String sourceId, String probeId) {
		return new com.ibm.ffdc.util.provider.Ffdc(th, reporter, sourceId, probeId, this);
	}

	public Ffdc getFfdc(Throwable th, Object reporter, String sourceId) {
		return this.getFfdc(th, reporter, sourceId, (String) null);
	}

	public void log(Throwable th, Object reporter, String sourceId, String probeId, Object... args) {
		Ffdc ffdc = this.getFfdc(th, reporter, sourceId, probeId);
		if (ffdc.isLoggable() && !_ignoredSources.contains(new Source(sourceId, probeId))) {
			ffdc.log(args);
		}

	}

	public void log(Throwable th, Object reporter, String sourceId, String probeId) {
		Ffdc ffdc = this.getFfdc(th, reporter, sourceId, probeId);
		if (ffdc.isLoggable() && !_ignoredSources.contains(new Source(sourceId, probeId))) {
			ffdc.log(new Object[0]);
		}

	}

	public void logIncident(IncidentEntry incident, Object reporter, Throwable th, List<Formattable> data)
			throws Exception {
		FFDCFilter.processException(th, incident.getSourceId(), incident.getProbeId(), data.toArray());
	}

	public void ffdcerror(Throwable th) {
		if (++this.internalErrors < 10) {
			try {
				th.printStackTrace(System.err);
			} catch (Throwable var3) {
				;
			}
		}

	}

	static PrintStream getFFDCFilePrintStream() {
      PrintStream ps = null;
      if (ffdcFileName != null) {
         try {
            FileOutputStream fos = (FileOutputStream)AccessController.doPrivileged(new 3());
            ps = new PrintStream(fos, true);
         } catch (PrivilegedActionException var2) {
            if (!reportedError) {
               reportedError = true;
               var2.printStackTrace(System.err);
            }

            ps = System.err;
         }
      }

      return ps;
   }

	static {
      tc = Tr.register(className);
      _ignoredSources = Collections.newSetFromMap(new ConcurrentHashMap());

      try {
         ffdcFileName = (String)AccessController.doPrivileged(new 1());
         if (ffdcFileName == null) {
            ffdcFileName = (String)AccessController.doPrivileged(new 2());
         }
      } catch (PrivilegedActionException var4) {
         var4.printStackTrace(System.err);
      }

      List<String> ignoreList = Tr.getFfdcIgnoreList();
      Iterator i$ = ignoreList.iterator();

      while(i$.hasNext()) {
         String ignore = (String)i$.next();
         String[] fields = ignore.split(",");
         if (fields.length > 1 && fields[0] != null && fields[1] != null) {
            ignoreSource(fields[0], fields[1]);
         }
      }

      reportedError = false;
   }
}