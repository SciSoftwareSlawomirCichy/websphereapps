package com.ibm.ws.logging;

import com.ibm.websphere.logging.WsLevel;

public class LevelConstants {
	public static final String[] NAMES = new String[]{"dump", "all", "finest", "debug", "finer", "entryexit", "fine",
			"event", "detail", "config", "info", "audit", "warning", "severe", "error", "fatal", "off"};
	public static final int NAMES_COUNT = 17;
	public static final int[] DISTINCT_LEVELS = new int[]{1, 0, 1, 1, 2, 2, 3, 3, 4, 5, 6, 7, 8, 9, 9, 10, 11};
	public static final int LEVEL_DUMP = 0;
	public static final int LEVEL_ALL = 1;
	public static final int LEVEL_FINEST = 2;
	public static final int LEVEL_DEBUG = 3;
	public static final int LEVEL_FINER = 4;
	public static final int LEVEL_ENTRYEXIT = 5;
	public static final int LEVEL_FINE = 6;
	public static final int LEVEL_EVENT = 7;
	public static final int LEVEL_DETAIL = 8;
	public static final int LEVEL_CONFIG = 9;
	public static final int LEVEL_INFO = 10;
	public static final int LEVEL_AUDIT = 11;
	public static final int LEVEL_WARNING = 12;
	public static final int LEVEL_SEVERE = 13;
	public static final int LEVEL_ERROR = 14;
	public static final int LEVEL_FATAL = 15;
	public static final int LEVEL_OFF = 16;
	public static final int LOWEST_MESSAGE_LEVEL = 8;
	public static final int HIGHEST_TRACE_LEVEL = 7;
	public static final int LOWEST_MESSAGE_LEVEL_INTVALUE;

	static {
		LOWEST_MESSAGE_LEVEL_INTVALUE = WsLevel.DETAIL.intValue();
	}
}