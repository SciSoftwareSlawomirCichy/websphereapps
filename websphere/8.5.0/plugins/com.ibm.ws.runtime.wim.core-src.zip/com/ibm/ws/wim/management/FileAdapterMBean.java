package com.ibm.ws.wim.management;

import com.ibm.websphere.wim.exception.WIMException;
import commonj.sdo.DataObject;

public interface FileAdapterMBean {
	String MBeanName = "FileAdapterMBean";
	String MBeanXML = "com/ibm/ws/wim/management/FileAdapterMBean.xml";

	DataObject create(DataObject var1, String var2) throws WIMException;

	DataObject update(DataObject var1, String var2) throws WIMException;

	DataObject delete(DataObject var1, String var2) throws WIMException;
}