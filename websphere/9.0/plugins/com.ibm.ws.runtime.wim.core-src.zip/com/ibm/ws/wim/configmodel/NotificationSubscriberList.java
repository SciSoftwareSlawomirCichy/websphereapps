package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface NotificationSubscriberList {
	List getNotificationSubscriber();

	NotificationSubscriber[] getNotificationSubscriberAsArray();

	NotificationSubscriber createNotificationSubscriber();
}