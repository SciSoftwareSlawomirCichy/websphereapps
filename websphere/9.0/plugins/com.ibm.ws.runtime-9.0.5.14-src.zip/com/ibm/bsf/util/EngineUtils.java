package com.ibm.bsf.util;

import com.ibm.bsf.BSFEngine;
import com.ibm.bsf.BSFException;
import com.ibm.bsf.BSFManager;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class EngineUtils {
	static BSFClassLoader bsfCL;

	public static void addEventListener(Object var0, String var1, String var2, BSFEngine var3, BSFManager var4,
			String var5, int var6, int var7, Object var8) throws BSFException {
		BSFEventProcessor var9 = new BSFEventProcessor(var3, var4, var2, var5, var6, var7, var8);

		try {
			ReflectionUtils.addEventListener(var0, var1, var9);
		} catch (Exception var11) {
			var11.printStackTrace();
			throw new BSFException(BSFException.REASON_OTHER_ERROR, "ouch while adding event listener: " + var11,
					var11);
		}
	}

	public static Object callBeanMethod(Object var0, String var1, Object[] var2) throws BSFException {
		Class[] var3 = null;
		if (var2 != null) {
			var3 = new Class[var2.length];

			for (int var4 = 0; var4 < var2.length; ++var4) {
				var3[var4] = var2[var4] == null ? null : var2[var4].getClass();
			}
		}

		boolean var12 = false;
		Class var5 = var0 instanceof Class ? (Class) var0 : var0.getClass();

		try {
			Method var6;
			try {
				var6 = MethodUtils.getMethod(var5, var1, var3, var12);
			} catch (NoSuchMethodException var10) {
				try {
					for (int var8 = 0; var8 < var2.length; ++var8) {
						if (var2[var8] instanceof Number) {
							var3[var8] = Byte.TYPE;
							if (var2[var8] instanceof Float) {
								var3[var8] = Float.TYPE;
							} else if (var2[var8] instanceof Double) {
								var3[var8] = Double.TYPE;
							}
						} else if (var2[var8] instanceof Boolean) {
							var3[var8] = Boolean.TYPE;
						}
					}

					var6 = MethodUtils.getMethod(var5, var1, var3, var12);
				} catch (Exception var9) {
					throw var10;
				}
			}

			return var6.invoke(var0, var2);
		} catch (Exception var11) {
			Throwable var7 = var11 instanceof InvocationTargetException
					? ((InvocationTargetException) var11).getTargetException()
					: null;
			throw new BSFException(BSFException.REASON_OTHER_ERROR,
					"method invocation failed: " + var11 + (var7 == null ? "" : " target exception: " + var7), var7);
		}
	}

	public static Object createBean(String var0, Object[] var1) throws BSFException {
		Class[] var3 = null;
		if (var1 != null) {
			var3 = new Class[var1.length];

			for (int var4 = 0; var4 < var1.length; ++var4) {
				var3[var4] = var1[var4] != null ? var1[var4].getClass() : null;
			}
		}

		try {
			Bean var2;
			try {
				var2 = ReflectionUtils.createBean((ClassLoader) null, var0, var3, var1);
				return var2.value;
			} catch (NoSuchMethodException var7) {
				try {
					for (int var5 = 0; var5 < var1.length; ++var5) {
						if (var1[var5] instanceof Number) {
							var3[var5] = Byte.TYPE;
						} else if (var1[var5] instanceof Boolean) {
							var3[var5] = Boolean.TYPE;
						}
					}

					var2 = ReflectionUtils.createBean((ClassLoader) null, var0, var3, var1);
					return var2.value;
				} catch (Exception var6) {
					throw var7;
				}
			}
		} catch (Exception var8) {
			throw new BSFException(BSFException.REASON_OTHER_ERROR, var8.getMessage(), var8);
		}
	}

	public static String getTypeSignatureString(Class var0) {
		if (var0.isPrimitive()) {
			if (var0 == Boolean.TYPE) {
				return "Z";
			} else if (var0 == Byte.TYPE) {
				return "B";
			} else if (var0 == Character.TYPE) {
				return "C";
			} else if (var0 == Short.TYPE) {
				return "S";
			} else if (var0 == Integer.TYPE) {
				return "I";
			} else if (var0 == Long.TYPE) {
				return "J";
			} else if (var0 == Float.TYPE) {
				return "F";
			} else {
				return var0 == Double.TYPE ? "D" : "V";
			}
		} else {
			StringBuffer var1 = new StringBuffer("L");
			var1.append(var0.getName());
			var1.append(";");
			return var1.toString().replace('.', '/');
		}
	}

	public static Class loadClass(BSFManager var0, String var1) throws BSFException {
		ClassLoader var2 = var0.getClassLoader();

		try {
			return var2 == null ? Class.forName(var1) : var2.loadClass(var1);
		} catch (ClassNotFoundException var6) {
			try {
				if (bsfCL == null) {
					bsfCL = new BSFClassLoader();
				}

				bsfCL.setTempDir(var0.getTempDir());
				return bsfCL.loadClass(var1);
			} catch (ClassNotFoundException var5) {
				throw new BSFException(BSFException.REASON_OTHER_ERROR, "unable to load class '" + var1 + "':" + var6,
						var6);
			}
		}
	}
}