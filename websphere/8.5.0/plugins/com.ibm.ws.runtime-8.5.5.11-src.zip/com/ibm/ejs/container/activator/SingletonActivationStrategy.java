package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;

public abstract class SingletonActivationStrategy extends ActivationStrategy {
	private static final TraceComponent tc = Tr.register(SingletonActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.activator.SingletonActivationStrategy";

	SingletonActivationStrategy(Activator activator) {
		super(activator);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> complete");
		}

	}

	protected BeanO doActivation(EJBThreadData threadData, ContainerTx tx, BeanId beanId, boolean takeInvocationRef)
			throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "doActivation", new Object[]{tx, beanId, new Boolean(takeInvocationRef)});
		}

		BeanO bean = null;
		Throwable exception = null;
		MasterKey key = new MasterKey(beanId);
		boolean activate = false;
		boolean pushedCallbackBeanO = false;
		boolean var22 = false;

		try {
			var22 = true;
			synchronized (this.locks.getLock(key)) {
				if ((bean = (BeanO) this.cache.find(key)) == null) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Bean not in cache");
					}

					bean = beanId.getHome().createBeanO(threadData, tx, beanId);
					pushedCallbackBeanO = true;
					this.cache.insert(key, bean);
					bean.ivCacheKey = key;
					activate = true;
				} else {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Found bean in cache");
					}

					threadData.pushCallbackBeanO(bean);
					pushedCallbackBeanO = true;
				}
			}

			boolean pin = false;
			if (activate) {
				bean.activate(beanId, tx);
			}

			pin = bean.enlist(tx);
			if (takeInvocationRef && pin) {
				this.cache.pin(key);
				var22 = false;
			} else if (!takeInvocationRef) {
				if (!pin) {
					this.cache.unpin(key);
					var22 = false;
				} else {
					var22 = false;
				}
			} else {
				var22 = false;
			}
		} catch (RemoteException var26) {
			FFDCFilter.processException(var26,
					"com.ibm.ejs.container.activator.SingletonActivationStrategy.doActivation", "123", this);
			exception = var26;
			throw var26;
		} catch (RuntimeException var27) {
			FFDCFilter.processException(var27,
					"com.ibm.ejs.container.activator.SingletonActivationStrategy.doActivation", "129", this);
			exception = var27;
			throw var27;
		} finally {
			if (var22) {
				if (exception != null && TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "doActivation: exception raised", exception);
				}

				if (exception != null && bean != null) {
					if (pushedCallbackBeanO) {
						threadData.popCallbackBeanO();
					}

					bean.destroy();
					if (activate) {
						synchronized (this.locks.getLock(key)) {
							this.cache.remove(key, true);
							bean.ivCacheKey = null;
						}
					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "doActivation", bean);
				}

			}
		}

		if (exception != null && TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			Tr.event(tc, "doActivation: exception raised", exception);
		}

		if (exception != null && bean != null) {
			if (pushedCallbackBeanO) {
				threadData.popCallbackBeanO();
			}

			bean.destroy();
			if (activate) {
				synchronized (this.locks.getLock(key)) {
					this.cache.remove(key, true);
					bean.ivCacheKey = null;
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "doActivation", bean);
		}

		return bean;
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit", new Object[]{tx, bean});
		}

		Object key = bean.ivCacheKey;
		synchronized (this.locks.getLock(key)) {
			bean = (BeanO) this.cache.find(key);
			this.cache.unpin(key);
			if (!bean.isRemoved()) {
				this.cache.unpin(key);
			} else {
				((BeanO) this.cache.remove(key, true)).destroy();
				bean.ivCacheKey = null;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCommit");
		}

	}

	void atEnlist(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atEnlist", new Object[]{tx, bean});
		}

		this.cache.pin(bean.ivCacheKey);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atEnlist");
		}

	}

	void atRemove(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRemove", new Object[]{tx, bean});
		}

		Object key = bean.ivCacheKey;
		synchronized (this.locks.getLock(key)) {
			this.cache.remove(key, true);
			bean.ivCacheKey = null;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRemove");
		}

	}

	BeanO atGet(ContainerTx tx, BeanId id) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atGet", new Object[]{tx, id});
		}

		MasterKey key = new MasterKey(id);
		BeanO result;
		synchronized (this.locks.getLock(key)) {
			result = (BeanO) this.cache.find(key);
			if (result != null) {
				this.cache.unpin(key);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atGet", result);
		}

		return result;
	}
}