package com.ibm.ws.wim.federation;

import com.ibm.websphere.wim.exception.WIMException;
import commonj.sdo.DataObject;
import java.util.Map;
import java.util.Set;

public interface FederationRepository {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	String ATTRIBUTE_UNIQUE_ID = "UNIQUE_ID";
	String ATTRIBUTE_UNIQUE_NAME = "UNIQUE_NAME";
	String ATTRIBUTE_ENTITY_TYPE = "ENTITY_TYPE";
	String ATTRIBUTE_REPOSITORY_ID = "REPOS_ID";
	String ATTRIBUTE_EXTERNAL_ID = "EXT_ID";

	String create(String var1, String var2, String var3, String var4) throws WIMException;

	FederationEntity get(String var1, String var2) throws WIMException;

	FederationEntity get(String var1) throws WIMException;

	FederationEntity lookupByUniqueId(String var1) throws WIMException;

	FederationEntity lookupByUniqueName(String var1) throws WIMException;

	Map lookup(String var1, Set var2) throws WIMException;

	void remove(FederationEntity var1) throws WIMException;

	boolean initialize(DataObject var1) throws WIMException;

	void updateExtId(String var1, String var2) throws WIMException;

	void updateUniqueName(String var1, String var2) throws WIMException;
}