package com.ibm.ws.logging;

interface package-info {
}