package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIAccessException;
import com.ibm.websphere.csi.CSIActivityCompletedException;
import com.ibm.websphere.csi.CSIActivityRequiredException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSIInvalidActivityException;
import com.ibm.websphere.csi.CSIInvalidTransactionException;
import com.ibm.websphere.csi.CSINoSuchObjectException;
import com.ibm.websphere.csi.CSITransactionRequiredException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.websphere.ejbcontainer.EJBStoppedException;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.javax.activity.ActivityCompletedException;
import com.ibm.ws.javax.activity.ActivityRequiredException;
import com.ibm.ws.javax.activity.InvalidActivityException;
import com.ibm.ws.javax.ejb.ActivityCompletedLocalException;
import com.ibm.ws.javax.ejb.ActivityRequiredLocalException;
import com.ibm.ws.javax.ejb.InvalidActivityLocalException;
import java.rmi.AccessException;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.ConcurrentAccessException;
import javax.ejb.ConcurrentAccessTimeoutException;
import javax.ejb.EJBAccessException;
import javax.ejb.EJBException;
import javax.ejb.EJBTransactionRequiredException;
import javax.ejb.EJBTransactionRolledbackException;
import javax.ejb.NoSuchEJBException;
import javax.transaction.InvalidTransactionException;
import javax.transaction.TransactionRequiredException;
import javax.transaction.TransactionRolledbackException;

public class BusinessExceptionMappingStrategy extends ExceptionMappingStrategy {
	private static final String CLASS_NAME = BusinessExceptionMappingStrategy.class.getName();
	private static final TraceComponent tc = Tr.register(BusinessExceptionMappingStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	static final ExceptionMappingStrategy INSTANCE = new BusinessExceptionMappingStrategy();

	private EJBException mapCSIException(CSIException ex, Exception causeEx, Throwable cause) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "mapCSIException: " + ex + ", cause = " + cause);
		}

		boolean createdEx = true;
		String message = ExceptionUtil.getBaseMessage(ex);
		Object ejbex;
		if (ex instanceof CSITransactionRolledbackException) {
			ejbex = new EJBTransactionRolledbackException(message, causeEx);
		} else if (ex instanceof CSIAccessException) {
			ejbex = new EJBAccessException(message);
		} else if (ex instanceof CSIInvalidTransactionException) {
			ejbex = new InvalidTransactionLocalException(message, causeEx);
		} else if (ex instanceof CSINoSuchObjectException) {
			ejbex = new NoSuchEJBException(message, causeEx);
		} else if (ex instanceof CSITransactionRequiredException) {
			ejbex = new EJBTransactionRequiredException(message);
		} else if (ex instanceof CSIInvalidActivityException) {
			ejbex = new InvalidActivityLocalException(message, causeEx);
		} else if (ex instanceof CSIActivityRequiredException) {
			ejbex = new ActivityRequiredLocalException(message, causeEx);
		} else if (ex instanceof CSIActivityCompletedException) {
			ejbex = new ActivityCompletedLocalException(message, causeEx);
		} else {
			ejbex = ExceptionUtil.EJBException(message, causeEx);
			if (causeEx != null) {
				createdEx = false;
			}
		}

		if (createdEx) {
			if (causeEx == null) {
				((EJBException) ejbex).setStackTrace(ex.getStackTrace());
			} else if (((EJBException) ejbex).getCause() == null) {
				((EJBException) ejbex).initCause(cause);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "mapCSIException returning: " + ejbex);
		}

		return (EJBException) ejbex;
	}

	private EJBException mapException(Throwable ex) {
		boolean createdEx = true;
		Exception causeEx = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "mapException: " + ex);
		}

		String message = ExceptionUtil.getBaseMessage(ex);
		Throwable cause = ExceptionUtil.findCause(ex);
		if (cause != null) {
			if (cause instanceof Exception) {
				causeEx = (Exception) cause;
			} else {
				causeEx = new Exception("See nested Throwable", cause);
			}
		}

		Object ejbex;
		if (ex instanceof CSIException) {
			ejbex = this.mapCSIException((CSIException) ex, causeEx, cause);
			createdEx = false;
		} else if (ex instanceof NoSuchObjectException) {
			ejbex = new NoSuchEJBException(message, causeEx);
		} else if (ex instanceof EJBStoppedException) {
			cause = ex;
			causeEx = (Exception) ex;
			ejbex = new NoSuchEJBException((String) null, causeEx);
		} else if (ex instanceof TransactionRequiredException) {
			ejbex = new EJBTransactionRequiredException(message);
		} else if (ex instanceof TransactionRolledbackException) {
			ejbex = new EJBTransactionRolledbackException(message, causeEx);
		} else if (ex instanceof InvalidTransactionException) {
			ejbex = new InvalidTransactionLocalException(message, causeEx);
		} else if (ex instanceof AccessException) {
			ejbex = new EJBAccessException(message);
		} else if (ex instanceof ActivityRequiredException) {
			ejbex = new ActivityRequiredLocalException(message, causeEx);
		} else if (ex instanceof InvalidActivityException) {
			ejbex = new InvalidActivityLocalException(message, causeEx);
		} else if (ex instanceof ActivityCompletedException) {
			ejbex = new ActivityCompletedLocalException(message, causeEx);
		} else if (ex instanceof BeanNotReentrantException) {
			BeanNotReentrantException bnre = (BeanNotReentrantException) ex;
			if (bnre.isTimeout()) {
				ejbex = new ConcurrentAccessTimeoutException(message);
			} else {
				ejbex = new ConcurrentAccessException(message, causeEx);
			}
		} else {
			ejbex = ExceptionUtil.EJBException(ex);
			createdEx = false;
		}

		if (createdEx) {
			if (causeEx != null) {
				if (((EJBException) ejbex).getCause() == null) {
					((EJBException) ejbex).initCause(cause);
				}
			} else {
				((EJBException) ejbex).setStackTrace(ex.getStackTrace());
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "mapException returning: " + ejbex);
		}

		return (EJBException) ejbex;
	}

	public final Throwable setUncheckedException(EJSDeployedSupport s, Throwable ex) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "setUncheckedException:" + ex);
		}

		if (s.ivException != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "setting unchecked exception again", ex);
				Tr.event(tc, "original exception", s.ivException);
			}

			return s.ivException;
		} else {
			Boolean applicationExceptionRollback = null;
			if (ex instanceof Exception && !(ex instanceof RemoteException)) {
				applicationExceptionRollback = s.getApplicationExceptionRollback((Throwable) ex);
			}

			if (applicationExceptionRollback != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "ApplicationException with rollback set to true, changing to a checked exception", ex);
				}

				s.exType = ExceptionType.CHECKED_EXCEPTION;
				s.ivException = (Throwable) ex;
				s.rootEx = (Throwable) ex;
				if (applicationExceptionRollback == Boolean.TRUE) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "ApplicationException with rollback set to true, setting rollback only", ex);
					}

					s.currentTx.setRollbackOnly();
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "setUncheckedException returning: " + s.ivException);
				}

				return s.ivException;
			} else {
				if (s.preInvokeException && (ex instanceof NoSuchObjectException || ex instanceof NoSuchEJBException
						|| ex instanceof EJBStoppedException || ex instanceof CSIAccessException
						|| ex instanceof BeanNotReentrantException)) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception should not cause rollback, changing to checked exception");
					}

					if (ex instanceof BeanNotReentrantException) {
						s.beanO = null;
					}

					s.exType = ExceptionType.CHECKED_EXCEPTION;
				} else if (EJSContainer.defaultContainer == null) {
					s.exType = ExceptionType.UNCHECKED_EXCEPTION;
					ex = new EJBException(
							"The Enterprise JavaBeans (EJB) features have been deactivated. No further EJB processing is allowed");
					ExceptionUtil.logException(tc, (Throwable) ex, s.getEJBMethodMetaData(), s.getBeanO());
				} else {
					s.exType = ExceptionType.UNCHECKED_EXCEPTION;
					ExceptionUtil.logException(tc, (Throwable) ex, s.getEJBMethodMetaData(), s.getBeanO());
					FFDCFilter.processException((Throwable) ex, CLASS_NAME + ".setUncheckedException", "506", this);
				}

				s.rootEx = this.findRootCause((Throwable) ex);
				s.ivException = this.mapException((Throwable) ex);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "setUncheckedException returning: " + s.ivException);
				}

				return s.ivException;
			}
		}
	}

	public Exception mapCSITransactionRolledBackException(EJSDeployedSupport s, CSITransactionRolledbackException ex)
			throws CSIException {
		Throwable cause = null;
		Exception causeEx = null;
		if (s.exType == ExceptionType.UNCHECKED_EXCEPTION) {
			cause = s.ivException;
		} else {
			cause = ExceptionUtil.findCause(ex);
			if (cause == null) {
				cause = s.ivException;
			}
		}

		if (cause != null) {
			if (cause instanceof Exception) {
				causeEx = (Exception) cause;
			} else {
				causeEx = new Exception("See nested Throwable", cause);
			}
		}

		Exception mappedEx = this.mapCSIException(ex, causeEx, cause);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "mapped exception = " + mappedEx);
		}

		return mappedEx;
	}
}