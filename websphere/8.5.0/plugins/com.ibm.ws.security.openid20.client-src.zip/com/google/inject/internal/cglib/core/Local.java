package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.Type;

public class Local {
	private Type type;
	private int index;

	public Local(int index, Type type) {
		this.type = type;
		this.index = index;
	}

	public int getIndex() {
		return this.index;
	}

	public Type getType() {
		return this.type;
	}
}