package com.ibm.ejs.csi;

import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.activator.ActivationStrategy;
import com.ibm.ejs.container.activator.Activator;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.ContainerExtensionFactory;
import com.ibm.websphere.csi.PassivationPolicy;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import java.util.List;
import javax.transaction.UserTransaction;

public class ContainerExtensionFactoryBaseImpl implements ContainerExtensionFactory {
	private static final TraceComponent tc = Tr.register(ContainerExtensionFactoryBaseImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public UOWControl getUOWControl(UserTransaction userTx) {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "getUOWControl");
		}

		UOWControl uowCtrl = new TransactionControlImpl(userTx);
		if (entryEnabled) {
			Tr.exit(tc, "getUOWControl");
		}

		return uowCtrl;
	}

	public ActivationStrategy getActivationStrategy(int type, Activator activator, PassivationPolicy passivationPolicy,
			SfFailoverCache failoverCache) {
		ActivationStrategy as = null;
		if (type == 7) {
			as = activator.getActivationStrategy(6);
		} else if (type == 3) {
			as = activator.getActivationStrategy(2);
		}

		return as;
	}

	public boolean isActivitySessionBeanManaged(boolean usesBeanManagedTx) {
		return false;
	}

	public List<ActivitySessionMethod> getActivitySessionAttributes(BeanMetaData bmd) throws Exception {
		return null;
	}
}