package com.google.common.base;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Splitter.1;
import com.google.common.base.Splitter.2;
import com.google.common.base.Splitter.3;
import com.google.common.base.Splitter.4;
import com.google.common.base.Splitter.5;
import com.google.common.base.Splitter.Strategy;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.CheckReturnValue;

@GwtCompatible(emulated = true)
public final class Splitter {
	private final CharMatcher trimmer;
	private final boolean omitEmptyStrings;
	private final Strategy strategy;
	private final int limit;

	private Splitter(Strategy strategy) {
		this(strategy, false, CharMatcher.NONE, Integer.MAX_VALUE);
	}

	private Splitter(Strategy strategy, boolean omitEmptyStrings, CharMatcher trimmer, int limit) {
		this.strategy = strategy;
		this.omitEmptyStrings = omitEmptyStrings;
		this.trimmer = trimmer;
		this.limit = limit;
	}

	public static Splitter on(char separator) {
		return on(CharMatcher.is(separator));
	}

	public static Splitter on(CharMatcher separatorMatcher) {
      Preconditions.checkNotNull(separatorMatcher);
      return new Splitter(new 1(separatorMatcher));
   }

	public static Splitter on(String separator) {
      Preconditions.checkArgument(separator.length() != 0, "The separator may not be the empty string.");
      return new Splitter(new 2(separator));
   }

	@GwtIncompatible("java.util.regex")
   public static Splitter on(Pattern separatorPattern) {
      Preconditions.checkNotNull(separatorPattern);
      Preconditions.checkArgument(!separatorPattern.matcher("").matches(), "The pattern may not match the empty string: %s", new Object[]{separatorPattern});
      return new Splitter(new 3(separatorPattern));
   }

	@GwtIncompatible("java.util.regex")
	public static Splitter onPattern(String separatorPattern) {
		return on(Pattern.compile(separatorPattern));
	}

	public static Splitter fixedLength(int length) {
      Preconditions.checkArgument(length > 0, "The length may not be less than 1");
      return new Splitter(new 4(length));
   }

	@CheckReturnValue
	public Splitter omitEmptyStrings() {
		return new Splitter(this.strategy, true, this.trimmer, this.limit);
	}

	@CheckReturnValue
	public Splitter limit(int limit) {
		Preconditions.checkArgument(limit > 0, "must be greater than zero: %s", new Object[]{limit});
		return new Splitter(this.strategy, this.omitEmptyStrings, this.trimmer, limit);
	}

	@CheckReturnValue
	public Splitter trimResults() {
		return this.trimResults(CharMatcher.WHITESPACE);
	}

	@CheckReturnValue
	public Splitter trimResults(CharMatcher trimmer) {
		Preconditions.checkNotNull(trimmer);
		return new Splitter(this.strategy, this.omitEmptyStrings, trimmer, this.limit);
	}

	public Iterable<String> split(CharSequence sequence) {
      Preconditions.checkNotNull(sequence);
      return new 5(this, sequence);
   }

	private Iterator<String> spliterator(CharSequence sequence) {
		return this.strategy.iterator(this, sequence);
	}

	@CheckReturnValue
	@Beta
	public Splitter.MapSplitter withKeyValueSeparator(String separator) {
		return this.withKeyValueSeparator(on(separator));
	}

	@CheckReturnValue
	@Beta
	public Splitter.MapSplitter withKeyValueSeparator(char separator) {
		return this.withKeyValueSeparator(on(separator));
	}

	@CheckReturnValue
   @Beta
   public Splitter.MapSplitter withKeyValueSeparator(Splitter keyValueSplitter) {
      return new Splitter.MapSplitter(this, keyValueSplitter, (1)null);
   }

	@Beta
	public static final class MapSplitter {
		private static final String INVALID_ENTRY_MESSAGE = "Chunk [%s] is not a valid entry";
		private final Splitter outerSplitter;
		private final Splitter entrySplitter;

		private MapSplitter(Splitter outerSplitter, Splitter entrySplitter) {
			this.outerSplitter = outerSplitter;
			this.entrySplitter = (Splitter) Preconditions.checkNotNull(entrySplitter);
		}

		public Map<String, String> split(CharSequence sequence) {
			Map<String, String> map = new LinkedHashMap();
			Iterator i$ = this.outerSplitter.split(sequence).iterator();

			while (i$.hasNext()) {
				String entry = (String) i$.next();
				Iterator<String> entryFields = this.entrySplitter.spliterator(entry);
				Preconditions.checkArgument(entryFields.hasNext(), "Chunk [%s] is not a valid entry",
						new Object[]{entry});
				String key = (String) entryFields.next();
				Preconditions.checkArgument(!map.containsKey(key), "Duplicate key [%s] found.", new Object[]{key});
				Preconditions.checkArgument(entryFields.hasNext(), "Chunk [%s] is not a valid entry",
						new Object[]{entry});
				String value = (String) entryFields.next();
				map.put(key, value);
				Preconditions.checkArgument(!entryFields.hasNext(), "Chunk [%s] is not a valid entry",
						new Object[]{entry});
			}

			return Collections.unmodifiableMap(map);
		}
	}
}