package com.google.common.base;

import com.google.common.base.FinalizableReferenceQueue.DecoupledLoader;
import com.google.common.base.FinalizableReferenceQueue.DirectLoader;
import com.google.common.base.FinalizableReferenceQueue.FinalizerLoader;
import com.google.common.base.FinalizableReferenceQueue.SystemLoader;
import java.io.Closeable;
import java.lang.ref.PhantomReference;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FinalizableReferenceQueue implements Closeable {
	private static final Logger logger = Logger.getLogger(FinalizableReferenceQueue.class.getName());
	private static final String FINALIZER_CLASS_NAME = "com.google.common.base.internal.Finalizer";
	private static final Method startFinalizer;
	final ReferenceQueue<Object> queue = new ReferenceQueue();
	final PhantomReference<Object> frqRef;
	final boolean threadStarted;

	public FinalizableReferenceQueue() {
		this.frqRef = new PhantomReference(this, this.queue);
		boolean threadStarted = false;

		try {
			startFinalizer.invoke((Object) null, FinalizableReference.class, this.queue, this.frqRef);
			threadStarted = true;
		} catch (IllegalAccessException var3) {
			throw new AssertionError(var3);
		} catch (Throwable var4) {
			logger.log(Level.INFO,
					"Failed to start reference finalizer thread. Reference cleanup will only occur when new references are created.",
					var4);
		}

		this.threadStarted = threadStarted;
	}

	public void close() {
		this.frqRef.enqueue();
		this.cleanUp();
	}

	void cleanUp() {
		if (!this.threadStarted) {
			Reference reference;
			while ((reference = this.queue.poll()) != null) {
				reference.clear();

				try {
					((FinalizableReference) reference).finalizeReferent();
				} catch (Throwable var3) {
					logger.log(Level.SEVERE, "Error cleaning up after reference.", var3);
				}
			}

		}
	}

	private static Class<?> loadFinalizer(FinalizerLoader... loaders) {
		FinalizerLoader[] arr$ = loaders;
		int len$ = loaders.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			FinalizerLoader loader = arr$[i$];
			Class<?> finalizer = loader.loadFinalizer();
			if (finalizer != null) {
				return finalizer;
			}
		}

		throw new AssertionError();
	}

	static Method getStartFinalizer(Class<?> finalizer) {
		try {
			return finalizer.getMethod("startFinalizer", Class.class, ReferenceQueue.class, PhantomReference.class);
		} catch (NoSuchMethodException var2) {
			throw new AssertionError(var2);
		}
	}

	static {
		Class<?> finalizer = loadFinalizer(new SystemLoader(), new DecoupledLoader(), new DirectLoader());
		startFinalizer = getStartFinalizer(finalizer);
	}
}