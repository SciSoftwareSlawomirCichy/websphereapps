package com.google.inject.internal.asm;

class Edge {
	int a;
	Label b;
	Edge c;
}