package com.ibm.ffdc.util.formatting;

import com.ibm.ffdc.Ffdc;
import com.ibm.ffdc.Manager;
import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.config.IncidentStream;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class JavaUtilFormatter implements Formatter {
	protected static final String FAILED_TO_FORMAT_SEE_FFDC = "Failed to format see FFDC";
	protected static final String KEY = "key";
	protected static final String VALUE = "value";
	protected static final String NOTE = "Note";
	protected static final String MODIFIED_WHILE_PRINTING = "this object has been modified while printing";
	protected static final String MAP_DOES_NOT_SUPPORT_OP_ENTRY_SET = "this map does not support op: entrySet()";

	public final void formatTo(Object o, IncidentStream is) {
		if (o == null) {
			is.write("Null collection", "Null collection sent for content collection");
		} else if (o instanceof Map) {
			this.formatTo(is, (Map) o);
		} else if (o instanceof Collection) {
			this.formatTo(is, (Collection) o);
		} else {
			is.write((String) null, o.toString());
		}

	}

	private void formatTo(IncidentStream is, Map<?, ?> map) {
		is.write((String) null, '{');

		try {
			Iterator i$ = map.entrySet().iterator();

			while (i$.hasNext()) {
				Entry<?, ?> e = (Entry) i$.next();
				is.write("key", e.getKey());
				is.write("value", e.getValue());
			}
		} catch (ConcurrentModificationException var5) {
			is.write("Note", "this object has been modified while printing");
		} catch (UnsupportedOperationException var6) {
			is.write("Note", "this map does not support op: entrySet()");
		} catch (Exception var7) {
			Ffdc ffdc = Manager.Ffdc.getFfdc(var7, this, this.getClass().getName(), "61");
			if (ffdc.isLoggable()) {
				ffdc.log(new Object[0]);
			}

			is.write("Failed to format see FFDC", ffdc.toString());
		}

		is.write((String) null, '}');
	}

	private void formatTo(IncidentStream is, Collection<?> collection) {
		is.write((String) null, '{');

		try {
			Iterator<?> it = collection.iterator();
			if (it == null) {
				is.write("Null collection iterator", "Collection sent for content collection has a null iterator");
			} else {
				while (it.hasNext()) {
					is.write((String) null, it.next());
				}
			}
		} catch (ConcurrentModificationException var5) {
			is.write("Note", "this object has been modified while printing");
		} catch (Exception var6) {
			Ffdc ffdc = Manager.Ffdc.getFfdc(var6, this, this.getClass().getName(), "77");
			if (ffdc.isLoggable()) {
				ffdc.log(new Object[0]);
			}

			is.write("Failed to format see FFDC", ffdc.toString());
		}

		is.write((String) null, '}');
	}

	public String[] getSupportedTypeNames() {
		return new String[]{"java.util.*"};
	}

	public boolean isSupported(Class<?> klass) {
		return Collection.class.getPackage().equals(klass.getPackage());
	}
}