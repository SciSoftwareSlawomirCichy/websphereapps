package com.google.inject.spi;

import com.google.inject.Binder;
import com.google.inject.Key;
import com.google.inject.Provider;
import com.google.inject.internal.Preconditions;
import com.google.inject.spi.ProviderLookup.1;

public final class ProviderLookup<T> implements Element {
	private final Object source;
	private final Key<T> key;
	private Provider<T> delegate;

	public ProviderLookup(Object source, Key<T> key) {
		this.source = Preconditions.checkNotNull(source, "source");
		this.key = (Key) Preconditions.checkNotNull(key, "key");
	}

	public Object getSource() {
		return this.source;
	}

	public Key<T> getKey() {
		return this.key;
	}

	public <T> T acceptVisitor(ElementVisitor<T> visitor) {
		return visitor.visit(this);
	}

	public void initializeDelegate(Provider<T> delegate) {
		Preconditions.checkState(this.delegate == null, "delegate already initialized");
		this.delegate = (Provider) Preconditions.checkNotNull(delegate, "delegate");
	}

	public void applyTo(Binder binder) {
		this.initializeDelegate(binder.withSource(this.getSource()).getProvider(this.key));
	}

	public Provider<T> getDelegate() {
		return this.delegate;
	}

	public Provider<T> getProvider() {
      return new 1(this);
   }
}