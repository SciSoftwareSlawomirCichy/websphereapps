@ParametersAreNonnullByDefault
package com.google.common.net;

import javax.annotation.ParametersAreNonnullByDefault;