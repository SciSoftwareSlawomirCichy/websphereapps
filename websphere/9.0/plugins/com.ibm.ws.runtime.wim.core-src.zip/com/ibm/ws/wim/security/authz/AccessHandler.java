package com.ibm.ws.wim.security.authz;

import com.ibm.sec.authz.jaccx.resource.Resource;
import java.security.Principal;
import java.util.Map;
import java.util.Set;
import javax.security.auth.Subject;

public interface AccessHandler {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	String RELATIONSHIP_OWNER = "Owner";

	void clearThreadCache();

	Map getContextParameters(Resource var1);

	Set getResourceAttributeNames(Resource var1);

	Object getResourceAttribute(Resource var1, String var2, Set var3);

	Set getSubjectAttributeNames(Subject var1);

	Object getSubjectAttribute(Subject var1, String var2, Set var3);

	Principal getSubjectPrincipal(Subject var1);

	Set getSubjectGroups(Subject var1);

	Set getSubjectRelationships(Subject var1, Resource var2);
}