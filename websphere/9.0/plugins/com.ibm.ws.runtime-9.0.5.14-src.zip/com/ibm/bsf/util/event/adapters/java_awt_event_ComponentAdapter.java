package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

public class java_awt_event_ComponentAdapter extends EventAdapterImpl implements ComponentListener {
	public void componentHidden(ComponentEvent var1) {
		this.eventProcessor.processEvent("componentHidden", new Object[]{var1});
	}

	public void componentMoved(ComponentEvent var1) {
		this.eventProcessor.processEvent("componentMoved", new Object[]{var1});
	}

	public void componentResized(ComponentEvent var1) {
		this.eventProcessor.processEvent("componentResized", new Object[]{var1});
	}

	public void componentShown(ComponentEvent var1) {
		this.eventProcessor.processEvent("componentShown", new Object[]{var1});
	}
}