package com.ibm.ejs.container;

import com.ibm.ejs.container.interceptors.InterceptorProxy;
import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.MethodInterface;
import com.ibm.websphere.ejbcontainer.SessionContextExtension;
import com.ibm.ws.ejbcontainer.CallbackKind;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.Map;
import javax.ejb.EJBException;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.transaction.UserTransaction;
import javax.xml.rpc.handler.MessageContext;

public abstract class SessionBeanO extends ManagedBeanOBase
		implements
			SessionContextExtension,
			UserTransactionEnabledContext {
	private static final TraceComponent tc = Tr.register(SessionBeanO.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.SessionBeanO";
	public static final int DESTROYED = 0;
	public static final int PRE_CREATE = 1;
	public static final int CREATING = 2;
	private static Method messageContextMethod;
	public SessionBean sessionBean;
	protected int currentIsolationLevel = 0;
	public CallbackKind ivCallbackKind;

	public SessionBeanO(EJSContainer c, EJSHome h) {
		super(c, h);
		if (this.home == null) {
			this.ivCallbackKind = CallbackKind.None;
		} else {
			BeanMetaData bmd = this.home.beanMetaData;
			this.ivCallbackKind = bmd.ivCallbackKind;
		}

	}

	public void setEnterpriseBean(Object bean) {
		super.setEnterpriseBean(bean);
		if (bean instanceof SessionBean) {
			this.sessionBean = (SessionBean) bean;
		}

	}

	protected void callLifecycleInterceptors(InterceptorProxy[] proxies, int methodId) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();

		try {
			if (isTraceOn) {
				if (TEBeanLifeCycleInfo.isTraceEnabled()) {
					TEBeanLifeCycleInfo.traceEJBCallEntry(LifecycleInterceptorWrapper.TRACE_NAMES[methodId]);
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "callLifecycleInterceptors");
				}
			}

			InvocationContextImpl<?> inv = this.getInvocationContext();
			BeanMetaData bmd = this.home.beanMetaData;
			inv.doLifeCycle(proxies, bmd._moduleMetaData);
		} catch (Throwable var9) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "SessionBean PostConstruct failure", var9);
			}

			throw ExceptionUtil.EJBException("session bean lifecycle interceptor failure", var9);
		} finally {
			if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceEJBCallExit(LifecycleInterceptorWrapper.TRACE_NAMES[methodId]);
			}

		}

	}

	public final void invalidate() {
	}

	public synchronized UserTransaction getUserTransaction() {
		if (this.state == 1) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Incorrect state: " + this.getStateName(this.state));
			}

			throw new IllegalStateException(this.getStateName(this.state));
		} else {
			return UserTransactionWrapper.INSTANCE;
		}
	}

	public Map<String, Object> getContextData() {
		if (this.state != 1 && this.state != 0) {
			return super.getContextData();
		} else {
			IllegalStateException ise = new IllegalStateException(
					"SessionBean: getContextData not allowed from state = " + this.getStateName(this.state));
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getContextData: " + ise);
			}

			throw ise;
		}
	}

	protected void canBeRemoved() throws RemoveException {
		ContainerTx tx = this.container.getCurrentContainerTx();
		if (tx != null) {
			if (tx.isTransactionGlobal() && tx.ivRemoveBeanO != this) {
				throw new RemoveException("Cannot remove session bean within a transaction.");
			}
		}
	}

	public EJBObject getEJBObject() {
		EJBObject result = null;
		if (this.state != 1 && this.state != 0) {
			try {
				EJSWrapper wrapper = this.container.wrapperManager.getWrapper(this.beanId).getRemoteWrapper();
				result = (EJBObject) this.container.getEJBRuntime().getRemoteReference(wrapper,
						this.home.beanMetaData.remoteInterfaceClass);
				return result;
			} catch (IllegalStateException var3) {
				throw var3;
			} catch (Exception var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.container.SessionBeanO.getEJBObject", "204", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getEJBObject() failed", var4);
				}

				throw new IllegalStateException("Failed to obtain EJBObject", var4);
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Incorrect state: " + this.getStateName(this.state));
			}

			throw new IllegalStateException(this.getStateName(this.state));
		}
	}

	public EJBLocalObject getEJBLocalObject() throws IllegalStateException {
		EJBLocalObject result = null;
		if (this.state != 1 && this.state != 0) {
			try {
				result = this.container.wrapperManager.getWrapper(this.beanId).getLocalObject();
				return result;
			} catch (IllegalStateException var4) {
				throw var4;
			} catch (Throwable var5) {
				FFDCFilter.processException(var5, "com.ibm.ejs.container.SessionBeanO.getEJBLocalObject", "236", this);
				ContainerEJBException cex = new ContainerEJBException("getEJBLocalObject() failed", var5);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var5, cex.toString()});
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getEJBLocalObject() failed", var5);
				}

				throw cex;
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Incorrect state: " + this.getStateName(this.state));
			}

			throw new IllegalStateException(this.getStateName(this.state));
		}
	}

	public Object getBeanInstance() {
		return this.ivEjbInstance;
	}

	public Object[] getInterceptors() {
		return this.ivInterceptors;
	}

	public MessageContext getMessageContext() throws IllegalStateException {
		boolean isEndpointMethod = false;
		Object context = EJSContainer.getMethodContext();
		if (context instanceof EJSDeployedSupport) {
			EJSDeployedSupport s = (EJSDeployedSupport) context;
			if (s.methodInfo.ivInterface == MethodInterface.SERVICE_ENDPOINT) {
				isEndpointMethod = true;
			}
		}

		if (!isEndpointMethod) {
			IllegalStateException ise = new IllegalStateException(
					"SessionBean: getMessageContext not allowed from Non-WebService Endpoint method");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getMessageContext: " + ise);
			}

			throw ise;
		} else {
			if (messageContextMethod == null) {
				try {
					messageContextMethod = Class.forName("com.ibm.ws.webservices.engine.MessageContext")
							.getMethod("getCurrentThreadsContext", (Class[]) null);
				} catch (SecurityException var8) {
					FFDCFilter.processException(var8, "com.ibm.ejs.container.SessionBeanO.getMessageContext", "348",
							this);
				} catch (NoSuchMethodException var9) {
					FFDCFilter.processException(var9, "com.ibm.ejs.container.SessionBeanO.getMessageContext", "354",
							this);
				} catch (ClassNotFoundException var10) {
					FFDCFilter.processException(var10, "com.ibm.ejs.container.SessionBeanO.getMessageContext", "360",
							this);
				}
			}

			MessageContext theMessageContext = null;

			try {
				theMessageContext = (MessageContext) messageContextMethod.invoke((Object) null, (Object[]) null);
			} catch (IllegalArgumentException var5) {
				FFDCFilter.processException(var5, "com.ibm.ejs.container.SessionBeanO.getMessageContext", "372", this);
			} catch (IllegalAccessException var6) {
				FFDCFilter.processException(var6, "com.ibm.ejs.container.SessionBeanO.getMessageContext", "378", this);
			} catch (InvocationTargetException var7) {
				FFDCFilter.processException(var7, "com.ibm.ejs.container.SessionBeanO.getMessageContext", "384", this);
			}

			return theMessageContext;
		}
	}

	public <T> T getBusinessObject(Class<T> businessInterface) throws IllegalStateException {
		Object result = null;
		if (this.state != 1 && this.state != 0) {
			if (businessInterface == null) {
				throw new IllegalStateException("Requested business interface not found : null");
			} else {
				try {
					EJSWrapperCommon common = this.container.wrapperManager.getWrapper(this.beanId);
					result = common.getBusinessObject(businessInterface.getName());
				} catch (IllegalStateException var5) {
					throw var5;
				} catch (Throwable var6) {
					FFDCFilter.processException(var6, "com.ibm.ejs.container.SessionBeanO.getBusinessObject", "516",
							this);
					EJBException ejbex = ExceptionUtil.EJBException("getBusinessObject() failed", var6);
					Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E",
							new Object[]{var6, ejbex.toString()});
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "getBusinessObject() failed", var6);
					}

					throw ejbex;
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getBusinessObject : " + result.getClass().getName());
				}

				return result;
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getBusinessObject: Incorrect state: " + this.getStateName(this.state));
			}

			throw new IllegalStateException(this.getStateName(this.state));
		}
	}

	public Class<?> getInvokedBusinessInterface() throws IllegalStateException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		synchronized (this) {
			if (this.state == 1 || this.state == 2 || this.state == 0) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Incorrect state: " + this.getStateName(this.state));
				}

				throw new IllegalStateException(this.getStateName(this.state));
			}
		}

		Class<?> bInterface = null;
		EJSWrapperBase wrapper = null;
		EJSDeployedSupport methodContext = EJSContainer.getMethodContext();
		if (methodContext != null) {
			wrapper = methodContext.ivWrapper;
			if (wrapper != null) {
				if (wrapper.ivBusinessInterfaceIndex == -2) {
					Method method = methodContext.methodInfo.ivMethod;
					String methodName = method.getName();
					Class<?>[] methodParams = method.getParameterTypes();
					Class[] arr$ = wrapper.bmd.ivBusinessLocalInterfaceClasses;
					int len$ = arr$.length;

					for (int i$ = 0; i$ < len$; ++i$) {
						Class curInterface = arr$[i$];

						try {
							curInterface.getMethod(methodName, methodParams);
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "Method " + methodName + " found on interface " + curInterface);
							}

							if (bInterface != null) {
								throw new IllegalStateException("Ambiguous invoked business interface.");
							}

							bInterface = curInterface;
						} catch (SecurityException var13) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "Method " + methodName + " not found on interface " + curInterface);
							}
						} catch (NoSuchMethodException var14) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "Method " + methodName + " not found on interface " + curInterface);
							}
						}
					}
				} else if (wrapper.ivInterface == WrapperInterface.BUSINESS_LOCAL) {
					bInterface = wrapper.bmd.ivBusinessLocalInterfaceClasses[wrapper.ivBusinessInterfaceIndex];
				} else if (wrapper.ivInterface == WrapperInterface.BUSINESS_REMOTE
						|| wrapper.ivInterface == WrapperInterface.BUSINESS_RMI_REMOTE) {
					bInterface = wrapper.bmd.ivBusinessRemoteInterfaceClasses[wrapper.ivBusinessInterfaceIndex];
				}
			}
		}

		if (bInterface == null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"getInvokedBusinessInterface : IllegalStateException : Not invoked through business interface");
			}

			throw new IllegalStateException("Not invoked through business interface");
		} else {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "getInvokedBusinessInterface : " + bInterface);
			}

			return bInterface;
		}
	}

	public boolean wasCancelCalled() {
		EJSDeployedSupport methodContext = EJSContainer.getMethodContext();
		ServerAsyncResult asyncResult = methodContext == null ? null : methodContext.ivAsyncResult;
		if (asyncResult == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"wasCancelCalled : IllegalStateException : Not invoked from an asynchronous method with results");
			}

			throw new IllegalStateException("Not invoked from an asynchronous method with results");
		} else {
			boolean result = asyncResult.wasCancelCalled();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "wasCancelCalled : " + result);
			}

			return result;
		}
	}

	public int getIsolationLevel() {
		return this.currentIsolationLevel;
	}

	public boolean isDestroyed() {
		return this.state == 0;
	}

	public void ensurePersistentState(ContainerTx tx) throws RemoteException {
	}

	public int getModuleVersion() {
		return this.home.beanMetaData.ivModuleVersion;
	}
}