package com.ibm.icu.text;

import com.ibm.icu.impl.ICUCache;
import com.ibm.icu.impl.ICUResourceBundle;
import com.ibm.icu.impl.SimpleCache;
import com.ibm.icu.text.DateTimePatternGenerator.1;
import com.ibm.icu.text.DateTimePatternGenerator.DateTimeMatcher;
import com.ibm.icu.text.DateTimePatternGenerator.DistanceInfo;
import com.ibm.icu.text.DateTimePatternGenerator.FormatParser;
import com.ibm.icu.text.DateTimePatternGenerator.PatternInfo;
import com.ibm.icu.text.DateTimePatternGenerator.PatternWithMatcher;
import com.ibm.icu.text.DateTimePatternGenerator.PatternWithSkeletonFlag;
import com.ibm.icu.text.DateTimePatternGenerator.VariableField;
import com.ibm.icu.util.Calendar;
import com.ibm.icu.util.Freezable;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class DateTimePatternGenerator implements Freezable<DateTimePatternGenerator>, Cloneable {
	public static final int ERA = 0;
	public static final int YEAR = 1;
	public static final int QUARTER = 2;
	public static final int MONTH = 3;
	public static final int WEEK_OF_YEAR = 4;
	public static final int WEEK_OF_MONTH = 5;
	public static final int WEEKDAY = 6;
	public static final int DAY = 7;
	public static final int DAY_OF_YEAR = 8;
	public static final int DAY_OF_WEEK_IN_MONTH = 9;
	public static final int DAYPERIOD = 10;
	public static final int HOUR = 11;
	public static final int MINUTE = 12;
	public static final int SECOND = 13;
	public static final int FRACTIONAL_SECOND = 14;
	public static final int ZONE = 15;
	public static final int TYPE_LIMIT = 16;
	public static final int MATCH_NO_OPTIONS = 0;
	public static final int MATCH_HOUR_FIELD_LENGTH = 2048;
	public static final int MATCH_MINUTE_FIELD_LENGTH = 4096;
	public static final int MATCH_SECOND_FIELD_LENGTH = 8192;
	public static final int MATCH_ALL_FIELDS_LENGTH = 65535;
	private TreeMap<DateTimeMatcher, PatternWithSkeletonFlag> skeleton2pattern = new TreeMap();
	private TreeMap<String, PatternWithSkeletonFlag> basePattern_pattern = new TreeMap();
	private String decimal = "?";
	private String dateTimeFormat = "{1} {0}";
	private String[] appendItemFormats = new String[16];
	private String[] appendItemNames = new String[16];
	private char defaultHourFormatChar;
	private boolean frozen;
	private transient DateTimeMatcher current;
	private transient FormatParser fp;
	private transient DistanceInfo _distanceInfo;
	private static final int FRACTIONAL_MASK = 16384;
	private static final int SECOND_AND_FRACTIONAL_MASK = 24576;
	private static ICUCache<String, DateTimePatternGenerator> DTPNG_CACHE = new SimpleCache();
	private static String[] CLDR_FIELD_APPEND = new String[]{"Era", "Year", "Quarter", "Month", "Week", "*",
			"Day-Of-Week", "Day", "*", "*", "*", "Hour", "Minute", "Second", "*", "Timezone"};
	private static String[] CLDR_FIELD_NAME = new String[]{"era", "year", "*", "month", "week", "*", "weekday", "day",
			"*", "*", "dayperiod", "hour", "minute", "second", "*", "zone"};
	private static String[] FIELD_NAME = new String[]{"Era", "Year", "Quarter", "Month", "Week_in_Year",
			"Week_in_Month", "Weekday", "Day", "Day_Of_Year", "Day_of_Week_in_Month", "Dayperiod", "Hour", "Minute",
			"Second", "Fractional_Second", "Zone"};
	private static String[] CANONICAL_ITEMS = new String[]{"G", "y", "Q", "M", "w", "W", "e", "d", "D", "F", "H", "m",
			"s", "S", "v"};
	private static Set<String> CANONICAL_SET;
	private Set<String> cldrAvailableFormatKeys;
	private static final int DATE_MASK = 1023;
	private static final int TIME_MASK = 64512;
	private static final int DELTA = 16;
	private static final int NUMERIC = 256;
	private static final int NONE = 0;
	private static final int NARROW = -257;
	private static final int SHORT = -258;
	private static final int LONG = -259;
	private static final int EXTRA_FIELD = 65536;
	private static final int MISSING_FIELD = 4096;
	private static int[][] types;

	public static DateTimePatternGenerator getEmptyInstance() {
		return new DateTimePatternGenerator();
	}

	protected DateTimePatternGenerator() {
      for(int i = 0; i < 16; ++i) {
         this.appendItemFormats[i] = "{0} ├{2}: {1}┤";
         this.appendItemNames[i] = "F" + i;
      }

      this.defaultHourFormatChar = 'H';
      this.frozen = false;
      this.current = new DateTimeMatcher((1)null);
      this.fp = new FormatParser();
      this._distanceInfo = new DistanceInfo((1)null);
      this.complete();
      this.cldrAvailableFormatKeys = new HashSet(20);
   }

	public static DateTimePatternGenerator getInstance() {
		return getInstance(ULocale.getDefault());
	}

	public static DateTimePatternGenerator getInstance(ULocale uLocale) {
		return getFrozenInstance(uLocale).cloneAsThawed();
	}

	public static DateTimePatternGenerator getFrozenInstance(ULocale uLocale) {
		String localeKey = uLocale.toString();
		DateTimePatternGenerator result = (DateTimePatternGenerator) DTPNG_CACHE.get(localeKey);
		if (result != null) {
			return result;
		} else {
			result = new DateTimePatternGenerator();
			PatternInfo returnInfo = new PatternInfo();
			String shortTimePattern = null;

			for (int i = 0; i <= 3; ++i) {
				SimpleDateFormat df = (SimpleDateFormat) DateFormat.getDateInstance(i, uLocale);
				result.addPattern(df.toPattern(), false, returnInfo);
				df = (SimpleDateFormat) DateFormat.getTimeInstance(i, uLocale);
				result.addPattern(df.toPattern(), false, returnInfo);
				if (i == 3) {
					shortTimePattern = df.toPattern();
					FormatParser fp = new FormatParser();
					fp.set(shortTimePattern);
					List<Object> items = fp.getItems();

					for (int idx = 0; idx < items.size(); ++idx) {
						Object item = items.get(idx);
						if (item instanceof VariableField) {
							VariableField fld = (VariableField) item;
							if (fld.getType() == 11) {
								result.defaultHourFormatChar = fld.toString().charAt(0);
								break;
							}
						}
					}
				}
			}

			ICUResourceBundle rb = (ICUResourceBundle) UResourceBundle
					.getBundleInstance("com/ibm/icu/impl/data/icudt44b", uLocale);
			ULocale parentLocale = rb.getULocale();
			String calendarTypeToUse = uLocale.getKeywordValue("calendar");
			if (calendarTypeToUse == null) {
				String[] preferredCalendarTypes = Calendar.getKeywordValuesForLocale("calendar", uLocale, true);
				calendarTypeToUse = preferredCalendarTypes[0];
			}

			if (calendarTypeToUse == null) {
				calendarTypeToUse = "gregorian";
			}

			rb = rb.getWithFallback("calendar");
			ICUResourceBundle calTypeBundle = rb.getWithFallback(calendarTypeToUse);

			String formatValue;
			String formatKey;
			ICUResourceBundle formatBundle;
			int i;
			ICUResourceBundle formatBundle;
			try {
				formatBundle = calTypeBundle.getWithFallback("appendItems");

				for (i = 0; i < formatBundle.getSize(); ++i) {
					formatBundle = (ICUResourceBundle) formatBundle.get(i);
					formatValue = formatBundle.get(i).getKey();
					formatKey = formatBundle.getString();
					result.setAppendItemFormat(getAppendFormatNumber(formatValue), formatKey);
				}
			} catch (Exception var18) {
				;
			}

			ICUResourceBundle pCalTypeBundle;
			int i;
			try {
				formatBundle = calTypeBundle.getWithFallback("fields");

				for (i = 0; i < 16; ++i) {
					if (isCLDRFieldName(i)) {
						pCalTypeBundle = formatBundle.getWithFallback(CLDR_FIELD_NAME[i]);
						formatBundle = pCalTypeBundle.getWithFallback("dn");
						formatKey = formatBundle.getString();
						result.setAppendItemName(i, formatKey);
					}
				}
			} catch (Exception var17) {
				;
			}

			try {
				formatBundle = calTypeBundle.getWithFallback("availableFormats");

				for (i = 0; i < formatBundle.getSize(); ++i) {
					String formatKey = formatBundle.get(i).getKey();
					formatValue = formatBundle.get(i).getString();
					result.setAvailableFormat(formatKey);
					result.addPatternWithSkeleton(formatValue, formatKey, false, returnInfo);
				}
			} catch (Exception var16) {
				;
			}

			while ((parentLocale = parentLocale.getFallback()) != null) {
				formatBundle = (ICUResourceBundle) UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b",
						parentLocale);
				formatBundle = formatBundle.getWithFallback("calendar");
				pCalTypeBundle = formatBundle.getWithFallback(calendarTypeToUse);

				try {
					formatBundle = pCalTypeBundle.getWithFallback("availableFormats");

					for (i = 0; i < formatBundle.getSize(); ++i) {
						formatKey = formatBundle.get(i).getKey();
						String formatValue = formatBundle.get(i).getString();
						if (!result.isAvailableFormatSet(formatKey)) {
							result.setAvailableFormat(formatKey);
							result.addPatternWithSkeleton(formatValue, formatKey, false, returnInfo);
						}
					}
				} catch (Exception var15) {
					;
				}
			}

			if (shortTimePattern != null) {
				hackTimes(result, returnInfo, shortTimePattern);
			}

			result.setDateTimeFormat(Calendar.getDateTimePattern(Calendar.getInstance(uLocale), uLocale, 2));
			DecimalFormatSymbols dfs = new DecimalFormatSymbols(uLocale);
			result.setDecimal(String.valueOf(dfs.getDecimalSeparator()));
			result.freeze();
			DTPNG_CACHE.put(localeKey, result);
			return result;
		}
	}

	private static void hackTimes(DateTimePatternGenerator result, PatternInfo returnInfo, String hackPattern) {
		result.fp.set(hackPattern);
		StringBuilder mmss = new StringBuilder();
		boolean gotMm = false;

		for (int i = 0; i < FormatParser.access$000(result.fp).size(); ++i) {
			Object item = FormatParser.access$000(result.fp).get(i);
			if (item instanceof String) {
				if (gotMm) {
					mmss.append(result.fp.quoteLiteral(item.toString()));
				}
			} else {
				char ch = item.toString().charAt(0);
				if (ch == 'm') {
					gotMm = true;
					mmss.append(item);
				} else {
					if (ch == 's') {
						if (gotMm) {
							mmss.append(item);
							result.addPattern(mmss.toString(), false, returnInfo);
						}
						break;
					}

					if (gotMm || ch == 'z' || ch == 'Z' || ch == 'v' || ch == 'V') {
						break;
					}
				}
			}
		}

		BitSet variables = new BitSet();
		BitSet nuke = new BitSet();

		for (int i = 0; i < FormatParser.access$000(result.fp).size(); ++i) {
			Object item = FormatParser.access$000(result.fp).get(i);
			if (item instanceof VariableField) {
				variables.set(i);
				char ch = item.toString().charAt(0);
				if (ch == 's' || ch == 'S') {
					nuke.set(i);

					for (int j = i - 1; j >= 0 && !variables.get(j); ++j) {
						nuke.set(i);
					}
				}
			}
		}

		String hhmm = getFilteredPattern(result.fp, nuke);
		result.addPattern(hhmm, false, returnInfo);
	}

	private static String getFilteredPattern(FormatParser fp, BitSet nuke) {
		StringBuilder result = new StringBuilder();

		for (int i = 0; i < FormatParser.access$000(fp).size(); ++i) {
			if (!nuke.get(i)) {
				Object item = FormatParser.access$000(fp).get(i);
				if (item instanceof String) {
					result.append(fp.quoteLiteral(item.toString()));
				} else {
					result.append(item.toString());
				}
			}
		}

		return result.toString();
	}

	private static int getAppendFormatNumber(String string) {
		for (int i = 0; i < CLDR_FIELD_APPEND.length; ++i) {
			if (CLDR_FIELD_APPEND[i].equals(string)) {
				return i;
			}
		}

		return -1;
	}

	private static boolean isCLDRFieldName(int index) {
		if (index < 0 && index >= 16) {
			return false;
		} else {
			return CLDR_FIELD_NAME[index].charAt(0) != '*';
		}
	}

	public String getBestPattern(String skeleton) {
		return this.getBestPattern(skeleton, (DateTimeMatcher) null, 0);
	}

	public String getBestPattern(String skeleton, int options) {
		return this.getBestPattern(skeleton, (DateTimeMatcher) null, options);
	}

	private String getBestPattern(String skeleton, DateTimeMatcher skipMatcher, int options) {
		skeleton = skeleton.replaceAll("j", String.valueOf(this.defaultHourFormatChar));
		String datePattern;
		String timePattern;
		synchronized (this) {
			this.current.set(skeleton, this.fp);
			PatternWithMatcher bestWithMatcher = this.getBestRaw(this.current, -1, this._distanceInfo, skipMatcher);
			if (this._distanceInfo.missingFieldMask == 0 && this._distanceInfo.extraFieldMask == 0) {
				return this.adjustFieldTypes(bestWithMatcher, this.current, false, options);
			}

			int neededFields = this.current.getFieldMask();
			datePattern = this.getBestAppending(this.current, neededFields & 1023, this._distanceInfo, skipMatcher,
					options);
			timePattern = this.getBestAppending(this.current, neededFields & 'ﰀ', this._distanceInfo, skipMatcher,
					options);
		}

		if (datePattern == null) {
			return timePattern == null ? "" : timePattern;
		} else {
			return timePattern == null
					? datePattern
					: MessageFormat.format(this.getDateTimeFormat(), new Object[]{timePattern, datePattern});
		}
	}

	public DateTimePatternGenerator addPattern(String pattern, boolean override, PatternInfo returnInfo) {
		return this.addPatternWithSkeleton(pattern, (String) null, override, returnInfo);
	}

	private DateTimePatternGenerator addPatternWithSkeleton(String pattern, String skeletonToUse, boolean override, PatternInfo returnInfo) {
      this.checkFrozen();
      DateTimeMatcher matcher;
      if (skeletonToUse == null) {
         matcher = (new DateTimeMatcher((1)null)).set(pattern, this.fp);
      } else {
         matcher = (new DateTimeMatcher((1)null)).set(skeletonToUse, this.fp);
      }

      String basePattern = matcher.getBasePattern();
      PatternWithSkeletonFlag previousPatternWithSameBase = (PatternWithSkeletonFlag)this.basePattern_pattern.get(basePattern);
      if (previousPatternWithSameBase != null) {
         returnInfo.status = 1;
         returnInfo.conflictingPattern = previousPatternWithSameBase.pattern;
         if (!override || skeletonToUse != null && previousPatternWithSameBase.skeletonWasSpecified) {
            return this;
         }
      }

      PatternWithSkeletonFlag previousValue = (PatternWithSkeletonFlag)this.skeleton2pattern.get(matcher);
      if (previousValue != null) {
         returnInfo.status = 2;
         returnInfo.conflictingPattern = previousValue.pattern;
         if (!override || skeletonToUse != null && previousValue.skeletonWasSpecified) {
            return this;
         }
      }

      returnInfo.status = 0;
      returnInfo.conflictingPattern = "";
      PatternWithSkeletonFlag patWithSkelFlag = new PatternWithSkeletonFlag(pattern, skeletonToUse != null);
      this.skeleton2pattern.put(matcher, patWithSkelFlag);
      this.basePattern_pattern.put(basePattern, patWithSkelFlag);
      return this;
   }

	public String getSkeleton(String pattern) {
		synchronized (this) {
			this.current.set(pattern, this.fp);
			return this.current.toString();
		}
	}

	public String getBaseSkeleton(String pattern) {
		synchronized (this) {
			this.current.set(pattern, this.fp);
			return this.current.getBasePattern();
		}
	}

	public Map<String, String> getSkeletons(Map<String, String> result) {
		if (result == null) {
			result = new LinkedHashMap();
		}

		Iterator i$ = this.skeleton2pattern.keySet().iterator();

		while (i$.hasNext()) {
			DateTimeMatcher item = (DateTimeMatcher) i$.next();
			PatternWithSkeletonFlag patternWithSkelFlag = (PatternWithSkeletonFlag) this.skeleton2pattern.get(item);
			String pattern = patternWithSkelFlag.pattern;
			if (!CANONICAL_SET.contains(pattern)) {
				((Map) result).put(item.toString(), pattern);
			}
		}

		return (Map) result;
	}

	public Set<String> getBaseSkeletons(Set<String> result) {
		if (result == null) {
			result = new HashSet();
		}

		((Set) result).addAll(this.basePattern_pattern.keySet());
		return (Set) result;
	}

	public String replaceFieldTypes(String pattern, String skeleton) {
		return this.replaceFieldTypes(pattern, skeleton, 0);
	}

	public String replaceFieldTypes(String pattern, String skeleton, int options) {
		synchronized (this) {
			PatternWithMatcher patternNoMatcher = new PatternWithMatcher(pattern, (DateTimeMatcher) null);
			return this.adjustFieldTypes(patternNoMatcher, this.current.set(skeleton, this.fp), false, options);
		}
	}

	public void setDateTimeFormat(String dateTimeFormat) {
		this.checkFrozen();
		this.dateTimeFormat = dateTimeFormat;
	}

	public String getDateTimeFormat() {
		return this.dateTimeFormat;
	}

	public void setDecimal(String decimal) {
		this.checkFrozen();
		this.decimal = decimal;
	}

	public String getDecimal() {
		return this.decimal;
	}

	public Collection<String> getRedundants(Collection<String> output) {
		synchronized (this) {
			if (output == null) {
				output = new LinkedHashSet();
			}

			Iterator i$ = this.skeleton2pattern.keySet().iterator();

			while (i$.hasNext()) {
				DateTimeMatcher cur = (DateTimeMatcher) i$.next();
				PatternWithSkeletonFlag patternWithSkelFlag = (PatternWithSkeletonFlag) this.skeleton2pattern.get(cur);
				String pattern = patternWithSkelFlag.pattern;
				if (!CANONICAL_SET.contains(pattern)) {
					String trial = this.getBestPattern(cur.toString(), cur, 0);
					if (trial.equals(pattern)) {
						((Collection) output).add(pattern);
					}
				}
			}

			return (Collection) output;
		}
	}

	public void setAppendItemFormat(int field, String value) {
		this.checkFrozen();
		this.appendItemFormats[field] = value;
	}

	public String getAppendItemFormat(int field) {
		return this.appendItemFormats[field];
	}

	public void setAppendItemName(int field, String value) {
		this.checkFrozen();
		this.appendItemNames[field] = value;
	}

	public String getAppendItemName(int field) {
		return this.appendItemNames[field];
	}

	public static boolean isSingleField(String skeleton) {
		char first = skeleton.charAt(0);

		for (int i = 1; i < skeleton.length(); ++i) {
			if (skeleton.charAt(i) != first) {
				return false;
			}
		}

		return true;
	}

	private void setAvailableFormat(String key) {
		this.checkFrozen();
		this.cldrAvailableFormatKeys.add(key);
	}

	private boolean isAvailableFormatSet(String key) {
		return this.cldrAvailableFormatKeys.contains(key);
	}

	public boolean isFrozen() {
		return this.frozen;
	}

	public DateTimePatternGenerator freeze() {
		this.frozen = true;
		return this;
	}

	public DateTimePatternGenerator cloneAsThawed() {
		DateTimePatternGenerator result = (DateTimePatternGenerator) ((DateTimePatternGenerator) this.clone());
		this.frozen = false;
		return result;
	}

	public Object clone() {
      try {
         DateTimePatternGenerator result = (DateTimePatternGenerator)((DateTimePatternGenerator)super.clone());
         result.skeleton2pattern = (TreeMap)this.skeleton2pattern.clone();
         result.basePattern_pattern = (TreeMap)this.basePattern_pattern.clone();
         result.appendItemFormats = (String[])this.appendItemFormats.clone();
         result.appendItemNames = (String[])this.appendItemNames.clone();
         result.current = new DateTimeMatcher((1)null);
         result.fp = new FormatParser();
         result._distanceInfo = new DistanceInfo((1)null);
         result.frozen = false;
         return result;
      } catch (CloneNotSupportedException var2) {
         throw new IllegalArgumentException("Internal Error");
      }
   }

	public boolean skeletonsAreSimilar(String id, String skeleton) {
		if (id.equals(skeleton)) {
			return true;
		} else {
			List<Object> parser1 = this.fp.set(id).getItems();
			List<Object> parser2 = this.fp.set(skeleton).getItems();
			if (parser1.size() != parser2.size()) {
				return false;
			} else {
				for (int i = 0; i < parser1.size(); ++i) {
					int index1 = getCanonicalIndex(parser1.get(i).toString(), false);
					int index2 = getCanonicalIndex(parser2.get(i).toString(), false);
					if (types[index1][1] != types[index2][1]) {
						return false;
					}
				}

				return true;
			}
		}
	}

	private void checkFrozen() {
		if (this.isFrozen()) {
			throw new UnsupportedOperationException("Attempt to modify frozen object");
		}
	}

	private String getBestAppending(DateTimeMatcher source, int missingFields, DistanceInfo distInfo,
			DateTimeMatcher skipMatcher, int options) {
		String resultPattern = null;
		if (missingFields != 0) {
			PatternWithMatcher resultPatternWithMatcher = this.getBestRaw(source, missingFields, distInfo, skipMatcher);
			resultPattern = this.adjustFieldTypes(resultPatternWithMatcher, source, false, options);

			while (true) {
				while (distInfo.missingFieldMask != 0) {
					if ((distInfo.missingFieldMask & 24576) == 16384 && (missingFields & 24576) == 24576) {
						resultPatternWithMatcher.pattern = resultPattern;
						resultPattern = this.adjustFieldTypes(resultPatternWithMatcher, source, true, options);
						distInfo.missingFieldMask &= -16385;
					} else {
						int startingMask = distInfo.missingFieldMask;
						PatternWithMatcher tempWithMatcher = this.getBestRaw(source, distInfo.missingFieldMask,
								distInfo, skipMatcher);
						String temp = this.adjustFieldTypes(tempWithMatcher, source, false, options);
						int foundMask = startingMask & ~distInfo.missingFieldMask;
						int topField = this.getTopBitNumber(foundMask);
						resultPattern = MessageFormat.format(this.getAppendFormat(topField),
								new Object[]{resultPattern, temp, this.getAppendName(topField)});
					}
				}

				return resultPattern;
			}
		} else {
			return resultPattern;
		}
	}

	private String getAppendName(int foundMask) {
		return "'" + this.appendItemNames[foundMask] + "'";
	}

	private String getAppendFormat(int foundMask) {
		return this.appendItemFormats[foundMask];
	}

	private int getTopBitNumber(int foundMask) {
		int i;
		for (i = 0; foundMask != 0; ++i) {
			foundMask >>>= 1;
		}

		return i - 1;
	}

	private void complete() {
		PatternInfo patternInfo = new PatternInfo();

		for (int i = 0; i < CANONICAL_ITEMS.length; ++i) {
			this.addPattern(String.valueOf(CANONICAL_ITEMS[i]), false, patternInfo);
		}

	}

	private PatternWithMatcher getBestRaw(DateTimeMatcher source, int includeMask, DistanceInfo missingFields, DateTimeMatcher skipMatcher) {
      int bestDistance = Integer.MAX_VALUE;
      PatternWithMatcher bestPatternWithMatcher = new PatternWithMatcher("", (DateTimeMatcher)null);
      DistanceInfo tempInfo = new DistanceInfo((1)null);
      Iterator i$ = this.skeleton2pattern.keySet().iterator();

      while(i$.hasNext()) {
         DateTimeMatcher trial = (DateTimeMatcher)i$.next();
         if (!trial.equals(skipMatcher)) {
            int distance = source.getDistance(trial, includeMask, tempInfo);
            if (distance < bestDistance) {
               bestDistance = distance;
               PatternWithSkeletonFlag patternWithSkelFlag = (PatternWithSkeletonFlag)this.skeleton2pattern.get(trial);
               bestPatternWithMatcher.pattern = patternWithSkelFlag.pattern;
               if (patternWithSkelFlag.skeletonWasSpecified) {
                  bestPatternWithMatcher.matcherWithSkeleton = trial;
               } else {
                  bestPatternWithMatcher.matcherWithSkeleton = null;
               }

               missingFields.setTo(tempInfo);
               if (distance == 0) {
                  break;
               }
            }
         }
      }

      return bestPatternWithMatcher;
   }

	private String adjustFieldTypes(PatternWithMatcher patternWithMatcher, DateTimeMatcher inputRequest,
			boolean fixFractionalSeconds, int options) {
		this.fp.set(patternWithMatcher.pattern);
		StringBuilder newPattern = new StringBuilder();
		Iterator i$ = this.fp.getItems().iterator();

		while (true) {
			while (i$.hasNext()) {
				Object item = i$.next();
				if (item instanceof String) {
					newPattern.append(this.fp.quoteLiteral((String) item));
				} else {
					VariableField variableField = (VariableField) item;
					String field = variableField.toString();
					int type = variableField.getType();
					String reqField;
					if (fixFractionalSeconds && type == 13) {
						reqField = DateTimeMatcher.access$500(inputRequest)[14];
						field = field + this.decimal + reqField;
					} else if (DateTimeMatcher.access$600(inputRequest)[type] != 0) {
						reqField = DateTimeMatcher.access$500(inputRequest)[type];
						int reqFieldLen = reqField.length();
						int adjFieldLen = reqFieldLen;
						DateTimeMatcher matcherWithSkeleton = patternWithMatcher.matcherWithSkeleton;
						int skelFieldLen;
						if (type == 11 && (options & 2048) == 0 || type == 12 && (options & 4096) == 0
								|| type == 13 && (options & 8192) == 0) {
							adjFieldLen = field.length();
						} else if (matcherWithSkeleton != null) {
							String skelField = matcherWithSkeleton.origStringForField(type);
							skelFieldLen = skelField.length();
							boolean patFieldIsNumeric = variableField.isNumeric();
							boolean skelFieldIsNumeric = matcherWithSkeleton.fieldIsNumeric(type);
							if (skelFieldLen == reqFieldLen || patFieldIsNumeric && !skelFieldIsNumeric
									|| skelFieldIsNumeric && !patFieldIsNumeric) {
								adjFieldLen = field.length();
							}
						}

						char c = type != 11 && type != 3 ? reqField.charAt(0) : field.charAt(0);
						field = "";

						for (skelFieldLen = adjFieldLen; skelFieldLen > 0; --skelFieldLen) {
							field = field + c;
						}
					}

					newPattern.append(field);
				}
			}

			return newPattern.toString();
		}
	}

	public String getFields(String pattern) {
		this.fp.set(pattern);
		StringBuilder newPattern = new StringBuilder();
		Iterator i$ = this.fp.getItems().iterator();

		while (i$.hasNext()) {
			Object item = i$.next();
			if (item instanceof String) {
				newPattern.append(this.fp.quoteLiteral((String) item));
			} else {
				newPattern.append("{" + getName(item.toString()) + "}");
			}
		}

		return newPattern.toString();
	}

	private static String showMask(int mask) {
		String result = "";

		for (int i = 0; i < 16; ++i) {
			if ((mask & 1 << i) != 0) {
				if (result.length() != 0) {
					result = result + " | ";
				}

				result = result + FIELD_NAME[i] + " ";
			}
		}

		return result;
	}

	private static String getName(String s) {
		int i = getCanonicalIndex(s, true);
		String name = FIELD_NAME[types[i][1]];
		int subtype = types[i][2];
		boolean string = subtype < 0;
		if (string) {
			subtype = -subtype;
		}

		if (subtype < 0) {
			name = name + ":S";
		} else {
			name = name + ":N";
		}

		return name;
	}

	private static int getCanonicalIndex(String s, boolean strict) {
		int len = s.length();
		if (len == 0) {
			return -1;
		} else {
			int ch = s.charAt(0);

			int bestRow;
			for (bestRow = 1; bestRow < len; ++bestRow) {
				if (s.charAt(bestRow) != ch) {
					return -1;
				}
			}

			bestRow = -1;

			for (int i = 0; i < types.length; ++i) {
				int[] row = types[i];
				if (row[0] == ch) {
					bestRow = i;
					if (row[3] <= len && row[row.length - 1] >= len) {
						return i;
					}
				}
			}

			return strict ? -1 : bestRow;
		}
	}

	static {
		CANONICAL_SET = new HashSet(Arrays.asList(CANONICAL_ITEMS));
		types = new int[][]{{71, 0, -258, 1, 3}, {71, 0, -259, 4}, {121, 1, 256, 1, 20}, {89, 1, 272, 1, 20},
				{117, 1, 288, 1, 20}, {81, 2, 256, 1, 2}, {81, 2, -258, 3}, {81, 2, -259, 4}, {113, 2, 272, 1, 2},
				{113, 2, -242, 3}, {113, 2, -243, 4}, {77, 3, 256, 1, 2}, {77, 3, -258, 3}, {77, 3, -259, 4},
				{77, 3, -257, 5}, {76, 3, 272, 1, 2}, {76, 3, -274, 3}, {76, 3, -275, 4}, {76, 3, -273, 5},
				{119, 4, 256, 1, 2}, {87, 5, 272, 1}, {101, 6, 272, 1, 2}, {101, 6, -274, 3}, {101, 6, -275, 4},
				{101, 6, -273, 5}, {69, 6, -258, 1, 3}, {69, 6, -259, 4}, {69, 6, -257, 5}, {99, 6, 288, 1, 2},
				{99, 6, -290, 3}, {99, 6, -291, 4}, {99, 6, -289, 5}, {100, 7, 256, 1, 2}, {68, 8, 272, 1, 3},
				{70, 9, 288, 1}, {103, 7, 304, 1, 20}, {97, 10, -258, 1}, {72, 11, 416, 1, 2}, {107, 11, 432, 1, 2},
				{104, 11, 256, 1, 2}, {75, 11, 272, 1, 2}, {109, 12, 256, 1, 2}, {115, 13, 256, 1, 2},
				{83, 14, 272, 1, 1000}, {65, 13, 288, 1, 1000}, {118, 15, -290, 1}, {118, 15, -291, 4},
				{122, 15, -258, 1, 3}, {122, 15, -259, 4}, {90, 15, -274, 1, 3}, {90, 15, -275, 4},
				{86, 15, -274, 1, 3}, {86, 15, -275, 4}};
	}
}