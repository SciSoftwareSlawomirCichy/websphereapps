package com.ibm.ejs.container.finder;

public class CollectionCannotBeFurtherAccessedException extends RuntimeException {
	private static final long serialVersionUID = -2238613038201337470L;

	public CollectionCannotBeFurtherAccessedException() {
	}

	public CollectionCannotBeFurtherAccessedException(String s) {
		super(s);
	}
}