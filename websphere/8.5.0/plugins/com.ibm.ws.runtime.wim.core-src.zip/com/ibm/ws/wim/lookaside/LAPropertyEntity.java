package com.ibm.ws.wim.lookaside;

public class LAPropertyEntity {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private int propertyId;
	private String applicableEntityType;
	private int requiredEntityType = 0;

	public String getApplicableEntityType() {
		return this.applicableEntityType;
	}

	public void setApplicableEntityType(String var1) {
		this.applicableEntityType = var1;
	}

	public int getPropertyId() {
		return this.propertyId;
	}

	public void setPropertyId(int var1) {
		this.propertyId = var1;
	}

	public int getRequiredEntityType() {
		return this.requiredEntityType;
	}

	public void setRequiredEntityType(int var1) {
		this.requiredEntityType = var1;
	}
}