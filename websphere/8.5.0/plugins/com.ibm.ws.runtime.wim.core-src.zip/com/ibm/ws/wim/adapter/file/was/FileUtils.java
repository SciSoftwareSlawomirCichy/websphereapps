package com.ibm.ws.wim.adapter.file.was;

import com.ibm.websphere.wim.ras.WIMLogger;
import commonj.sdo.DataGraph;
import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;
import org.eclipse.emf.ecore.util.ExtendedMetaData;

public class FileUtils {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = FileUtils.class.getName();
	private static final Logger trcLogger;

	public static boolean fileExists(String var0) {
		try {
			if (var0 != null) {
				File var1 = new File(var0);
				if (var1.exists()) {
					return true;
				}
			}
		} catch (Exception var2) {
			trcLogger.logp(Level.FINER, CLASSNAME, "fileExists", "checking for file: " + var0, var2);
		}

		return false;
	}

	public static DataGraph loadFileAsDataGraph(String var0) throws Exception {
		EDataGraph var2 = null;
		long var3 = System.currentTimeMillis();
		trcLogger.logp(Level.FINER, CLASSNAME, "loadFileAsDataGraph", "Loading from " + var0);
		HashMap var5 = new HashMap();
		var5.put("EXTENDED_META_DATA", ExtendedMetaData.INSTANCE);
		FileInputStream var6 = new FileInputStream(var0);
		var2 = SDOUtil.loadDataGraph(var6, var5);
		var6.close();
		if (trcLogger.isLoggable(Level.FINER)) {
			long var7 = System.currentTimeMillis();
			trcLogger.logp(Level.FINER, CLASSNAME, "loadFileAsDataGraph",
					"Loaded from " + var0 + " (" + (var7 - var3) + " milliseconds)");
		}

		trcLogger.logp(Level.FINEST, CLASSNAME, "loadFileAsDataGraph", "Loaded Data:" + var2);
		return var2;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}