package com.ibm.ejs.csi;

import java.lang.annotation.Annotation;
import javax.ejb.ApplicationException;

public class ApplicationExceptionImpl implements ApplicationException {
	private final boolean ivRollback;
	private final boolean ivInherited;

	public ApplicationExceptionImpl(boolean rollback, boolean inherited) {
		this.ivRollback = rollback;
		this.ivInherited = inherited;
	}

	public Class<? extends Annotation> annotationType() {
		return ApplicationException.class;
	}

	public boolean rollback() {
		return this.ivRollback;
	}

	public boolean inherited() {
		return this.ivInherited;
	}
}