package com.google.gson.internal;

import com.google.gson.InstanceCreator;
import com.google.gson.internal.ConstructorConstructor.1;
import com.google.gson.internal.ConstructorConstructor.10;
import com.google.gson.internal.ConstructorConstructor.11;
import com.google.gson.internal.ConstructorConstructor.12;
import com.google.gson.internal.ConstructorConstructor.2;
import com.google.gson.internal.ConstructorConstructor.3;
import com.google.gson.internal.ConstructorConstructor.4;
import com.google.gson.internal.ConstructorConstructor.5;
import com.google.gson.internal.ConstructorConstructor.6;
import com.google.gson.internal.ConstructorConstructor.7;
import com.google.gson.internal.ConstructorConstructor.8;
import com.google.gson.internal.ConstructorConstructor.9;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Constructor;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;

public final class ConstructorConstructor {
	private final Map<Type, InstanceCreator<?>> instanceCreators;

	public ConstructorConstructor(Map<Type, InstanceCreator<?>> instanceCreators) {
		this.instanceCreators = instanceCreators;
	}

	public <T> ObjectConstructor<T> get(TypeToken<T> typeToken) {
      Type type = typeToken.getType();
      Class<? super T> rawType = typeToken.getRawType();
      InstanceCreator<T> typeCreator = (InstanceCreator)this.instanceCreators.get(type);
      if (typeCreator != null) {
         return new 1(this, typeCreator, type);
      } else {
         InstanceCreator<T> rawTypeCreator = (InstanceCreator)this.instanceCreators.get(rawType);
         if (rawTypeCreator != null) {
            return new 2(this, rawTypeCreator, type);
         } else {
            ObjectConstructor<T> defaultConstructor = this.newDefaultConstructor(rawType);
            if (defaultConstructor != null) {
               return defaultConstructor;
            } else {
               ObjectConstructor<T> defaultImplementation = this.newDefaultImplementationConstructor(type, rawType);
               return defaultImplementation != null ? defaultImplementation : this.newUnsafeAllocator(type, rawType);
            }
         }
      }
   }

	private <T> ObjectConstructor<T> newDefaultConstructor(Class<? super T> rawType) {
      try {
         Constructor<? super T> constructor = rawType.getDeclaredConstructor();
         if (!constructor.isAccessible()) {
            constructor.setAccessible(true);
         }

         return new 3(this, constructor);
      } catch (NoSuchMethodException var3) {
         return null;
      }
   }

	private <T> ObjectConstructor<T> newDefaultImplementationConstructor(Type type, Class<? super T> rawType) {
      if (Collection.class.isAssignableFrom(rawType)) {
         if (SortedSet.class.isAssignableFrom(rawType)) {
            return new 4(this);
         } else if (EnumSet.class.isAssignableFrom(rawType)) {
            return new 5(this, type);
         } else if (Set.class.isAssignableFrom(rawType)) {
            return new 6(this);
         } else {
            return (ObjectConstructor)(Queue.class.isAssignableFrom(rawType) ? new 7(this) : new 8(this));
         }
      } else if (Map.class.isAssignableFrom(rawType)) {
         if (SortedMap.class.isAssignableFrom(rawType)) {
            return new 9(this);
         } else {
            return (ObjectConstructor)(type instanceof ParameterizedType && !String.class.isAssignableFrom(TypeToken.get(((ParameterizedType)type).getActualTypeArguments()[0]).getRawType()) ? new 10(this) : new 11(this));
         }
      } else {
         return null;
      }
   }

	private <T> ObjectConstructor<T> newUnsafeAllocator(Type type, Class<? super T> rawType) {
      return new 12(this, rawType, type);
   }

	public String toString() {
		return this.instanceCreators.toString();
	}
}