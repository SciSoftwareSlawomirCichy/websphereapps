package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.base.Throwables;
import com.google.common.collect.Lists;
import com.google.common.util.concurrent.Monitor.Guard;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import javax.annotation.Nullable;
import javax.annotation.concurrent.GuardedBy;

@Beta
public final class Monitor {
	private final boolean fair;
	private final ReentrantLock lock;
	@GuardedBy("lock")
	private final ArrayList<Guard> activeGuards;

	public Monitor() {
		this(false);
	}

	public Monitor(boolean fair) {
		this.activeGuards = Lists.newArrayListWithCapacity(1);
		this.fair = fair;
		this.lock = new ReentrantLock(fair);
	}

	public void enter() {
		this.lock.lock();
	}

	public void enterInterruptibly() throws InterruptedException {
		this.lock.lockInterruptibly();
	}

	public boolean enter(long time, TimeUnit unit) {
		ReentrantLock lock = this.lock;
		if (!this.fair && lock.tryLock()) {
			return true;
		} else {
			long startNanos = System.nanoTime();
			long timeoutNanos = unit.toNanos(time);
			long remainingNanos = timeoutNanos;
			boolean interruptIgnored = false;

			try {
				while (true) {
					try {
						boolean var12 = lock.tryLock(remainingNanos, TimeUnit.NANOSECONDS);
						return var12;
					} catch (InterruptedException var16) {
						interruptIgnored = true;
						remainingNanos = timeoutNanos - (System.nanoTime() - startNanos);
					}
				}
			} finally {
				if (interruptIgnored) {
					Thread.currentThread().interrupt();
				}

			}
		}
	}

	public boolean enterInterruptibly(long time, TimeUnit unit) throws InterruptedException {
		return this.lock.tryLock(time, unit);
	}

	public boolean tryEnter() {
		return this.lock.tryLock();
	}

	public void enterWhen(Guard guard) throws InterruptedException {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			ReentrantLock lock = this.lock;
			boolean reentrant = lock.isHeldByCurrentThread();
			boolean success = false;
			lock.lockInterruptibly();

			try {
				this.waitInterruptibly(guard, reentrant);
				success = true;
			} finally {
				if (!success) {
					lock.unlock();
				}

			}

		}
	}

	public void enterWhenUninterruptibly(Guard guard) {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			ReentrantLock lock = this.lock;
			boolean reentrant = lock.isHeldByCurrentThread();
			boolean success = false;
			lock.lock();

			try {
				this.waitUninterruptibly(guard, reentrant);
				success = true;
			} finally {
				if (!success) {
					lock.unlock();
				}

			}

		}
	}

	public boolean enterWhen(Guard guard, long time, TimeUnit unit) throws InterruptedException {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			ReentrantLock lock = this.lock;
			boolean reentrant = lock.isHeldByCurrentThread();
			long remainingNanos;
			if (!this.fair && lock.tryLock()) {
				remainingNanos = unit.toNanos(time);
			} else {
				long startNanos = System.nanoTime();
				if (!lock.tryLock(time, unit)) {
					return false;
				}

				remainingNanos = unit.toNanos(time) - (System.nanoTime() - startNanos);
			}

			boolean satisfied = false;

			try {
				satisfied = this.waitInterruptibly(guard, remainingNanos, reentrant);
			} finally {
				if (!satisfied) {
					lock.unlock();
				}

			}

			return satisfied;
		}
	}

	public boolean enterWhenUninterruptibly(Guard guard, long time, TimeUnit unit) {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			ReentrantLock lock = this.lock;
			boolean reentrant = lock.isHeldByCurrentThread();
			boolean interruptIgnored = false;

			boolean var11;
			try {
				long remainingNanos;
				if (!this.fair && lock.tryLock()) {
					remainingNanos = unit.toNanos(time);
				} else {
					long startNanos = System.nanoTime();
					long timeoutNanos = unit.toNanos(time);
					remainingNanos = timeoutNanos;

					while (true) {
						try {
							if (!lock.tryLock(remainingNanos, TimeUnit.NANOSECONDS)) {
								boolean var14 = false;
								return var14;
							}
							break;
						} catch (InterruptedException var31) {
							interruptIgnored = true;
						} finally {
							remainingNanos = timeoutNanos - (System.nanoTime() - startNanos);
						}
					}
				}

				boolean satisfied = false;

				try {
					satisfied = this.waitUninterruptibly(guard, remainingNanos, reentrant);
				} finally {
					if (!satisfied) {
						lock.unlock();
					}

				}

				var11 = satisfied;
			} finally {
				if (interruptIgnored) {
					Thread.currentThread().interrupt();
				}

			}

			return var11;
		}
	}

	public boolean enterIf(Guard guard) {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			ReentrantLock lock = this.lock;
			lock.lock();
			boolean satisfied = false;

			try {
				satisfied = guard.isSatisfied();
			} finally {
				if (!satisfied) {
					lock.unlock();
				}

			}

			return satisfied;
		}
	}

	public boolean enterIfInterruptibly(Guard guard) throws InterruptedException {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			ReentrantLock lock = this.lock;
			lock.lockInterruptibly();
			boolean satisfied = false;

			try {
				satisfied = guard.isSatisfied();
			} finally {
				if (!satisfied) {
					lock.unlock();
				}

			}

			return satisfied;
		}
	}

	public boolean enterIf(Guard guard, long time, TimeUnit unit) {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			ReentrantLock lock = this.lock;
			if (!this.enter(time, unit)) {
				return false;
			} else {
				boolean satisfied = false;

				try {
					satisfied = guard.isSatisfied();
				} finally {
					if (!satisfied) {
						lock.unlock();
					}

				}

				return satisfied;
			}
		}
	}

	public boolean enterIfInterruptibly(Guard guard, long time, TimeUnit unit) throws InterruptedException {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			ReentrantLock lock = this.lock;
			if (!lock.tryLock(time, unit)) {
				return false;
			} else {
				boolean satisfied = false;

				try {
					satisfied = guard.isSatisfied();
				} finally {
					if (!satisfied) {
						lock.unlock();
					}

				}

				return satisfied;
			}
		}
	}

	public boolean tryEnterIf(Guard guard) {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			ReentrantLock lock = this.lock;
			if (!lock.tryLock()) {
				return false;
			} else {
				boolean satisfied = false;

				try {
					satisfied = guard.isSatisfied();
				} finally {
					if (!satisfied) {
						lock.unlock();
					}

				}

				return satisfied;
			}
		}
	}

	public void waitFor(Guard guard) throws InterruptedException {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else if (!this.lock.isHeldByCurrentThread()) {
			throw new IllegalMonitorStateException();
		} else {
			this.waitInterruptibly(guard, true);
		}
	}

	public void waitForUninterruptibly(Guard guard) {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else if (!this.lock.isHeldByCurrentThread()) {
			throw new IllegalMonitorStateException();
		} else {
			this.waitUninterruptibly(guard, true);
		}
	}

	public boolean waitFor(Guard guard, long time, TimeUnit unit) throws InterruptedException {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else if (!this.lock.isHeldByCurrentThread()) {
			throw new IllegalMonitorStateException();
		} else {
			return this.waitInterruptibly(guard, unit.toNanos(time), true);
		}
	}

	public boolean waitForUninterruptibly(Guard guard, long time, TimeUnit unit) {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else if (!this.lock.isHeldByCurrentThread()) {
			throw new IllegalMonitorStateException();
		} else {
			return this.waitUninterruptibly(guard, unit.toNanos(time), true);
		}
	}

	public void leave() {
		ReentrantLock lock = this.lock;
		if (!lock.isHeldByCurrentThread()) {
			throw new IllegalMonitorStateException();
		} else {
			try {
				this.signalConditionsOfSatisfiedGuards((Guard) null);
			} finally {
				lock.unlock();
			}

		}
	}

	public boolean isFair() {
		return this.lock.isFair();
	}

	public boolean isOccupied() {
		return this.lock.isLocked();
	}

	public boolean isOccupiedByCurrentThread() {
		return this.lock.isHeldByCurrentThread();
	}

	public int getOccupiedDepth() {
		return this.lock.getHoldCount();
	}

	public int getQueueLength() {
		return this.lock.getQueueLength();
	}

	public boolean hasQueuedThreads() {
		return this.lock.hasQueuedThreads();
	}

	public boolean hasQueuedThread(Thread thread) {
		return this.lock.hasQueuedThread(thread);
	}

	public boolean hasWaiters(Guard guard) {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			this.lock.lock();

			boolean var2;
			try {
				var2 = guard.waiterCount > 0;
			} finally {
				this.lock.unlock();
			}

			return var2;
		}
	}

	public int getWaitQueueLength(Guard guard) {
		if (guard.monitor != this) {
			throw new IllegalMonitorStateException();
		} else {
			this.lock.lock();

			int var2;
			try {
				var2 = guard.waiterCount;
			} finally {
				this.lock.unlock();
			}

			return var2;
		}
	}

	@GuardedBy("lock")
	private void signalConditionsOfSatisfiedGuards(@Nullable Guard interruptedGuard) {
		ArrayList<Guard> guards = this.activeGuards;
		int guardCount = guards.size();

		try {
			for (int i = 0; i < guardCount; ++i) {
				Guard guard = (Guard) guards.get(i);
				if ((guard != interruptedGuard || guard.waiterCount != 1) && guard.isSatisfied()) {
					guard.condition.signal();
					return;
				}
			}

		} catch (Throwable var7) {
			for (int i = 0; i < guardCount; ++i) {
				Guard guard = (Guard) guards.get(i);
				guard.condition.signalAll();
			}

			throw Throwables.propagate(var7);
		}
	}

	@GuardedBy("lock")
	private void incrementWaiters(Guard guard) {
		int waiters = guard.waiterCount++;
		if (waiters == 0) {
			this.activeGuards.add(guard);
		}

	}

	@GuardedBy("lock")
	private void decrementWaiters(Guard guard) {
		int waiters = --guard.waiterCount;
		if (waiters == 0) {
			this.activeGuards.remove(guard);
		}

	}

	@GuardedBy("lock")
	private void waitInterruptibly(Guard guard, boolean signalBeforeWaiting) throws InterruptedException {
		if (!guard.isSatisfied()) {
			if (signalBeforeWaiting) {
				this.signalConditionsOfSatisfiedGuards((Guard) null);
			}

			this.incrementWaiters(guard);

			try {
				Condition condition = guard.condition;

				do {
					try {
						condition.await();
					} catch (InterruptedException var11) {
						try {
							this.signalConditionsOfSatisfiedGuards(guard);
						} catch (Throwable var10) {
							Thread.currentThread().interrupt();
							throw Throwables.propagate(var10);
						}

						throw var11;
					}
				} while (!guard.isSatisfied());
			} finally {
				this.decrementWaiters(guard);
			}
		}

	}

	@GuardedBy("lock")
	private void waitUninterruptibly(Guard guard, boolean signalBeforeWaiting) {
		if (!guard.isSatisfied()) {
			if (signalBeforeWaiting) {
				this.signalConditionsOfSatisfiedGuards((Guard) null);
			}

			this.incrementWaiters(guard);

			try {
				Condition condition = guard.condition;

				do {
					condition.awaitUninterruptibly();
				} while (!guard.isSatisfied());
			} finally {
				this.decrementWaiters(guard);
			}
		}

	}

	@GuardedBy("lock")
	private boolean waitInterruptibly(Guard guard, long remainingNanos, boolean signalBeforeWaiting)
			throws InterruptedException {
		if (!guard.isSatisfied()) {
			if (signalBeforeWaiting) {
				this.signalConditionsOfSatisfiedGuards((Guard) null);
			}

			this.incrementWaiters(guard);

			boolean var6;
			try {
				Condition condition = guard.condition;

				while (remainingNanos > 0L) {
					try {
						remainingNanos = condition.awaitNanos(remainingNanos);
					} catch (InterruptedException var13) {
						try {
							this.signalConditionsOfSatisfiedGuards(guard);
						} catch (Throwable var12) {
							Thread.currentThread().interrupt();
							throw Throwables.propagate(var12);
						}

						throw var13;
					}

					if (guard.isSatisfied()) {
						return true;
					}
				}

				var6 = false;
			} finally {
				this.decrementWaiters(guard);
			}

			return var6;
		} else {
			return true;
		}
	}

	@GuardedBy("lock")
	private boolean waitUninterruptibly(Guard guard, long timeoutNanos, boolean signalBeforeWaiting) {
		if (!guard.isSatisfied()) {
			long startNanos = System.nanoTime();
			if (signalBeforeWaiting) {
				this.signalConditionsOfSatisfiedGuards((Guard) null);
			}

			boolean interruptIgnored = false;

			InterruptedException var11;
			try {
				this.incrementWaiters(guard);

				try {
					Condition condition = guard.condition;
					long remainingNanos = timeoutNanos;

					while (remainingNanos > 0L) {
						try {
							remainingNanos = condition.awaitNanos(remainingNanos);
						} catch (InterruptedException var24) {
							var11 = var24;

							try {
								this.signalConditionsOfSatisfiedGuards(guard);
							} catch (Throwable var23) {
								Thread.currentThread().interrupt();
								throw Throwables.propagate(var23);
							}

							interruptIgnored = true;
							remainingNanos = timeoutNanos - (System.nanoTime() - startNanos);
						}

						if (guard.isSatisfied()) {
							return true;
						}
					}

					var11 = false;
				} finally {
					this.decrementWaiters(guard);
				}
			} finally {
				if (interruptIgnored) {
					Thread.currentThread().interrupt();
				}

			}

			return (boolean) var11;
		} else {
			return true;
		}
	}
}