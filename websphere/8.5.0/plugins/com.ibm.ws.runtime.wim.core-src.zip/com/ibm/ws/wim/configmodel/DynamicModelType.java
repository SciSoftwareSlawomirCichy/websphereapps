package com.ibm.ws.wim.configmodel;

public interface DynamicModelType {
	String getXsdFileName();

	void setXsdFileName(String var1);

	void unsetXsdFileName();

	boolean isSetXsdFileName();

	boolean isUseGlobalSchema();

	void setUseGlobalSchema(boolean var1);

	void unsetUseGlobalSchema();

	boolean isSetUseGlobalSchema();
}