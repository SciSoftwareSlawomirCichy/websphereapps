package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_ru extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: Зависимой стороне OpenID не удалось перенаправить пользователя провайдеру OpenID для идентификации из-за исключительной ситуации [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: Сбой инициализации зависимой стороны OpenID: не удалось получить SSLContext по умолчанию для сервера WebSphere. Исключительная ситуация: [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: Зависимой стороне OpenID не удалось подключиться к провайдеру OpenID, указанному идентификатором [{0}], из-за исключительной ситуации [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: Сбой инициализации зависимой стороны OpenID из-за исключительной ситуации [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: Зависимая сторона OpenID не инициализировалась, поскольку значение свойства [{0}] имеет неверный формат."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: Зависимой стороне OpenID не удалось идентифицировать запрос с помощью ключа простой идентификации, поскольку значение ключа недопустимое."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: Сбой инициализации зависимой стороны OpenID: свойство [{0}] указано неверно. Это должен быть правильный URL."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: Зависимая сторона OpenID получила неверный ответ от провайдера OpenID. Причина ошибки: [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: Не удалось выполнить идентификацию зависимой стороны OpenID из-за переполнения внутреннего кэша."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: Сбой инициализации зависимой стороны OpenID: отсутствует обязательное свойство axRequiredAttribute[n]. Должно быть указано хотя бы одно свойство."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: Не удалось инициализировать зависимую сторону OpenID, так как значение обязательного свойства [{0}] пустое или отсутствует."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: Зависимая сторона OpenID требует SSL (HTTPS), но в URL провайдера OpenID указана схема HTTP: [{0}]. Атрибут [{1}] должен совпадать со схемой целевого URL. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: Зависимая сторона OpenID получила ответ от провайдера OpenID, который не поддерживает спецификацию OpenID версии 2."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: Зависимой стороне OpenID не удалось проверить ответ, полученный от провайдера OpenID. Исключительная ситуация: [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}