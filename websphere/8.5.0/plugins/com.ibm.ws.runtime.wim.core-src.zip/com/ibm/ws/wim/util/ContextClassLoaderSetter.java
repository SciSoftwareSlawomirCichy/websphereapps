package com.ibm.ws.wim.util;

import java.security.AccessController;
import java.security.PrivilegedAction;

public class ContextClassLoaderSetter implements PrivilegedAction {
	private ClassLoader newThreadCL;

	public Object run() {
		Thread.currentThread().setContextClassLoader(this.newThreadCL);
		return this.newThreadCL;
	}

	public ClassLoader setContextClassLoader(ClassLoader var1) {
		this.newThreadCL = var1;
		return (ClassLoader) AccessController.doPrivileged(this);
	}
}