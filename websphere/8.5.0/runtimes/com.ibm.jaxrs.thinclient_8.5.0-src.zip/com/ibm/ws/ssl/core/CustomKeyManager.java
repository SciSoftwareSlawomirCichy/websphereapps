package com.ibm.ws.ssl.core;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.wsspi.ssl.KeyManagerExtendedInfo;
import java.net.Socket;
import java.security.KeyStore;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Properties;
import javax.net.ssl.X509KeyManager;

public final class CustomKeyManager implements X509KeyManager, KeyManagerExtendedInfo {
	private static final TraceComponent tc = Tr.register(CustomKeyManager.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private Properties props = null;
	private KeyManagerHelper helper;
	private KeyStore ks = null;
	private X509KeyManager km = null;
	private Properties sslConfig = null;
	private String clientAlias = null;
	private String serverAlias = null;
	private int clientslotnum = 0;
	private int serverslotnum = 0;

	public void setCustomProperties(Properties customProps) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setCustomProperties", new Object[]{customProps});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setCustomProperties");
		}

		this.props = customProps;
	}

	public void setSSLConfig(Properties config) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setSSLConfig");
		}

		this.sslConfig = config;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setSSLConfig");
		}

	}

	public void setDefaultX509KeyManager(X509KeyManager defaultX509KeyManager) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setDefaultX509KeyManager", new Object[]{defaultX509KeyManager});
		}

		this.km = defaultX509KeyManager;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setDefaultX509KeyManager");
		}

	}

	public void setKeyStore(KeyStore keyStore) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setKeyStore");
		}

		this.ks = keyStore;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setKeyStore");
		}

	}

	public void setKeyStoreServerAlias(String alias) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setKeyStoreServerAlias", new Object[]{alias});
		}

		this.serverAlias = alias;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setKeyStoreServerAlias");
		}

	}

	public void setKeyStoreClientAlias(String alias) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setKeyStoreClientAlias", new Object[]{alias});
		}

		this.clientAlias = alias;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setKeyStoreClientAlias");
		}

	}

	public void setClientAlias(String alias, int slotnum) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setClientAlias", new Object[]{alias, new Integer(slotnum)});
		}

		if (!this.ks.containsAlias(alias)) {
			throw new IllegalArgumentException("Client alias " + alias + " not found in keystore.");
		} else {
			this.clientAlias = alias;
			this.clientslotnum = slotnum;
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setClientAlias");
			}

		}
	}

	public void setServerAlias(String alias, int slotnum) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setServerAlias", new Object[]{alias, new Integer(slotnum)});
		}

		if (!this.ks.containsAlias(alias)) {
			throw new IllegalArgumentException("Server alias " + alias + " not found in keystore.");
		} else {
			this.serverAlias = alias;
			this.serverslotnum = slotnum;
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setServerAlias");
			}

		}
	}

	public String chooseClientAlias(String[] keyType, Principal[] issuers, Socket socket) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseClientAlias", new Object[]{keyType, issuers, socket});
		}

		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseClientAlias");
		}

		return this.chooseClientAlias(keyType[0], issuers);
	}

	public String chooseServerAlias(String keyType, Principal[] issuers, Socket socket) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseServerAlias", new Object[]{keyType, issuers, socket});
		}

		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseServerAlias");
		}

		return this.chooseServerAlias(keyType, issuers);
	}

	public String chooseClientAlias(String keyType, Principal[] issuers) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseClientAlias", new Object[]{keyType, issuers});
		}

		String[] keyArray;
		String matchedAlias;
		String newAlias;
		if (this.clientAlias != null && !this.clientAlias.equals("")) {
			keyArray = this.km.getClientAliases(keyType, issuers);
			matchedAlias = this.helper.getAlias(this.clientAlias, keyArray);
			if (matchedAlias != null && !matchedAlias.equals("")) {
				newAlias = this.helper.normalizeAliasName(matchedAlias, this.ks);
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseClientAlias  (alias name match)", new Object[]{newAlias});
				}

				return newAlias;
			} else {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseClientAlias (default)", new Object[]{this.clientAlias});
				}

				return this.clientAlias;
			}
		} else {
			keyArray = new String[]{keyType};
			matchedAlias = this.km.chooseClientAlias(keyArray, issuers, (Socket) null);
			newAlias = this.helper.normalizeAliasName(matchedAlias, this.ks);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "chooseClientAlias (from JSSE)", new Object[]{newAlias});
			}

			return newAlias;
		}
	}

	public String chooseServerAlias(String keyType, Principal[] issuers) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseServerAlias", new Object[]{keyType, issuers});
		}

		String newAlias;
		if (this.serverAlias != null && !this.serverAlias.equals("")) {
			String[] list = this.km.getServerAliases(keyType, issuers);
			newAlias = this.helper.getAlias(this.serverAlias, list);
			if (newAlias != null && !newAlias.equals("")) {
				String newAlias = this.helper.normalizeAliasName(newAlias, this.ks);
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseServerAlias  (alias name match)", new Object[]{newAlias});
				}

				return newAlias;
			} else {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseServerAlias (default)", new Object[]{this.serverAlias});
				}

				return this.serverAlias;
			}
		} else {
			String alias = this.km.chooseServerAlias(keyType, issuers, (Socket) null);
			newAlias = this.helper.normalizeAliasName(alias, this.ks);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "chooseServerAlias (from JSSE)", new Object[]{newAlias});
			}

			return newAlias;
		}
	}

	public String[] getClientAliases(String keyType, Principal[] issuers) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getClientAliases", new Object[]{keyType, issuers});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getClientAliases");
		}

		return this.km.getClientAliases(keyType, issuers);
	}

	public String[] getServerAliases(String keyType, Principal[] issuers) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getServerAliases", new Object[]{keyType, issuers});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getServerAliases");
		}

		return this.km.getServerAliases(keyType, issuers);
	}

	public PrivateKey getPrivateKey(String s) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPrivateKey", new Object[]{s});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getPrivateKey");
		}

		return this.km.getPrivateKey(s);
	}

	public X509Certificate[] getCertificateChain(String s) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getCertificateChain", new Object[]{s});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getCertificateChain");
		}

		return this.km.getCertificateChain(s);
	}

	public X509KeyManager getX509KeyManager() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getX509KeyManager");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getX509KeyManager");
		}

		return this.km;
	}

	public CustomKeyManager() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "CustomKeyManager");
		}

		this.helper = new KeyManagerHelper();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "CustomKeyManager");
		}

	}
}