package com.ibm.bsf.debug.util;

import com.ibm.bsf.debug.util.DebugLog.1;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.Hashtable;

public class DebugLog {
	public static final int BSF_LOG_L0 = 0;
	public static final int BSF_LOG_L1 = 1;
	public static final int BSF_LOG_L2 = 2;
	public static final int BSF_LOG_L3 = 3;
	public static Hashtable logLevels;
	private static int loglevel = 0;
	private static PrintStream debugStream;

	public static void stdoutPrint(Object var0, int var1) {
		streamPrint(var0, System.out, var1);
	}

	public static void stdoutPrintln(Object var0, int var1) {
		streamPrintln(var0, System.out, var1);
	}

	public static void stderrPrint(Object var0, int var1) {
		streamPrint(var0, System.err, var1);
	}

	public static void stderrPrintln(Object var0, int var1) {
		streamPrintln(var0, System.err, var1);
	}

	public static void debugPrint(Object var0, int var1) {
		streamPrint(var0, debugStream, var1);
	}

	public static void debugPrintln(Object var0, int var1) {
		streamPrintln(var0, debugStream, var1);
	}

	public static void setDebugStream(PrintStream var0) {
		debugStream = var0;
	}

	public static PrintStream getDebugStream() {
		return debugStream;
	}

	public static void setLogLevel(int var0) {
      if (var0 != loglevel && var0 >= 0) {
         try {
            AccessController.doPrivileged(new 1(var0));
            loglevel = var0;
         } catch (PrivilegedActionException var3) {
            Exception var2 = var3.getException();
            System.err.println("Unable to set loglevel: " + var2.getMessage());
            var2.printStackTrace();
         }
      }

   }

	public static int getLogLevel() {
		return loglevel;
	}

	public static void streamPrint(Object var0, OutputStream var1, int var2) {
		if (loglevel >= var2) {
			PrintStream var3 = var1 instanceof PrintStream ? (PrintStream) var1 : new PrintStream(var1, true);
			var3.print(var0);
		}

	}

	public static void streamPrintln(Object var0, OutputStream var1, int var2) {
		if (loglevel >= var2) {
			PrintStream var3 = var1 instanceof PrintStream ? (PrintStream) var1 : new PrintStream(var1, true);
			var3.println(var0);
		}

	}

	static {
		debugStream = System.err;
		Integer var0 = Integer.getInteger("com.ibm.bsf.debug.logLevel", 0);
		setLogLevel(var0);
		logLevels = new Hashtable();
		logLevels.put("BSF_LOG_L0", new Integer(0));
		logLevels.put("BSF_LOG_L1", new Integer(1));
		logLevels.put("BSF_LOG_L2", new Integer(2));
		logLevels.put("BSF_LOG_L3", new Integer(3));
	}
}