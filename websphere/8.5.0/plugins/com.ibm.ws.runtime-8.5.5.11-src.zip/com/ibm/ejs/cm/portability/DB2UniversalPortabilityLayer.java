package com.ibm.ejs.cm.portability;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

class DB2UniversalPortabilityLayer extends DB2PortabilityLayer {
	private static DB2UniversalPortabilityLayer instance;
	private static final TraceComponent tc = Tr.register(DB2UniversalPortabilityLayer.class);

	protected DB2UniversalPortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.errorMap.remove(new Integer(-30081));
		this.errorMap.put(new Integer(-4499), StaleConnectionException.class);
		this.defaultDataSourceProps.remove("connectionAttribute");
		this.defaultDataSourceProps.setProperty("resultSetHoldability", "2");
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	static PortabilityLayer getPortabilityLayer(Connection conn) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPortabilityLayer", conn);
		}

		PortabilityLayer pbl = null;
		DatabaseMetaData metaData = conn.getMetaData();
		String productName = metaData.getDatabaseProductName();
		if (tc.isEventEnabled()) {
			Tr.event(tc, "getPortabilityLayer", productName);
		}

		if (productName != null) {
			productName = productName.toUpperCase();
			if (productName.equals("DB2") || productName.startsWith("DSN")) {
				pbl = DB2UniversalConnectPortabilityLayer.getInstance();
				((DB2ConnectPortabilityLayer) pbl).setIs390(1);
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getPortabilityLayer", "DB2UniversalConnectPortabilityLayer - 390");
				}

				return pbl;
			}

			if (productName.startsWith("AS") || productName.startsWith("QSQ")) {
				pbl = DB2UniversalConnectPortabilityLayer.getInstance();
				((DB2ConnectPortabilityLayer) pbl).setIs390(-1);
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getPortabilityLayer", "DB2UniversalConnectPortabilityLayer - AS");
				}

				return pbl;
			}
		}

		pbl = getInstance();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getPortabilityLayer - DB2UniversalPortabilityLayer");
		}

		return pbl;
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new DB2UniversalPortabilityLayer();
		}

		return instance;
	}
}