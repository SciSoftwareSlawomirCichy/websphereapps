package com.ibm.bsf;

public class BSFDeclaredBean {
	public String name;
	public Object bean;
	public Class type;

	BSFDeclaredBean(String var1, Object var2, Class var3) {
		this.name = var1;
		this.bean = var2;
		this.type = var3;
	}
}