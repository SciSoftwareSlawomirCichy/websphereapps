package com.ibm.ejs.util;

import com.ibm.ejs.util.Uuid.1;
import com.ibm.ffdc.Manager;
import com.ibm.ws.security.util.AccessController;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.PrivilegedActionException;
import java.util.Random;

public class Uuid implements Serializable {
	protected long low64Bits;
	protected static long logicalTime = 0L;
	protected int timeLow;
	protected short timeMid;
	protected short timeHigh;
	protected short clockSeq;
	protected byte[] node = new byte[6];
	protected static byte[] thisIpAddress = null;
	protected String uuidString = null;
	protected static byte[] badadd = new byte[]{11, 10, 13, 10, 13, 13};
	static char[] hexChars = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
	private static final long serialVersionUID = -3465601508791529063L;

	public Uuid() {
		Class var1 = Uuid.class;
		synchronized (Uuid.class) {
			this.low64Bits = System.currentTimeMillis();
			if (logicalTime >= this.low64Bits) {
				this.low64Bits = ++logicalTime;
			} else {
				logicalTime = this.low64Bits;
			}
		}

		this.clockSeq = (short) this.hashCode();
		byte[] tmpnode = this.getIpAddress();

		int i;
		for (i = 0; i < tmpnode.length && i < 4; ++i) {
			this.node[i] = tmpnode[i];
		}

		while (i < 4) {
			this.node[i++] = 0;
		}

		this.node[4] = -86;
		this.node[5] = 119;
		this.timeLow = (int) this.low64Bits & -1;
		this.timeMid = (short) ((int) (this.low64Bits >> 32 & 65535L));
		this.timeHigh = (short) ((int) (this.low64Bits >> 48 & 65535L));
		if (this.timeHigh == 0) {
			Random r = new Random((long) this.timeLow);
			int rint = r.nextInt();
			this.timeHigh = (short) (this.timeHigh | rint | '');
		}

		this.uuidString = Integer.toHexString(this.timeLow) + "-" + toHexString(this.timeMid) + "-"
				+ toHexString(this.timeHigh) + "-" + toHexString(this.clockSeq) + "-";

		for (i = 0; i < 6; ++i) {
			this.uuidString = this.uuidString + toHexString(this.node[i]);
		}

	}

	public String toString() {
		return this.uuidString;
	}

	public boolean isEqual(Uuid uuid) {
		return uuid.toString().equals(this.uuidString);
	}

	private static String toHexString(short v) {
		char[] c = new char[]{hexChars[v >> 12 & 15], hexChars[v >> 8 & 15], hexChars[v >> 4 & 15], hexChars[v & 15]};
		return new String(c, 0, 4);
	}

	private static String toHexString(byte v) {
		char[] c = new char[]{hexChars[v >> 4 & 15], hexChars[v & 15]};
		return new String(c, 0, 2);
	}

	private byte[] getIpAddress() {
      if (thisIpAddress == null) {
         InetAddress localHostAddress = null;

         try {
            try {
               localHostAddress = (InetAddress)AccessController.doPrivileged(new 1(this));
            } catch (PrivilegedActionException var3) {
               Manager.Ffdc.log(var3, this, "com.ibm.ejs.util.Uuid.getIpAddress", "291", new Object[]{this});
               throw (UnknownHostException)var3.getException();
            }

            thisIpAddress = localHostAddress.getAddress();
         } catch (UnknownHostException var4) {
            Manager.Ffdc.log(var4, this, "com.ibm.ejs.util.Uuid.getIpAddress", "298", new Object[]{this});
            return badadd;
         }
      }

      return thisIpAddress;
   }

	public static void main(String[] args) {
		Uuid uuid = new Uuid();
		if (args.length > 0) {
			int howMany = Integer.parseInt(args[0]);
			Uuid[] uuids = new Uuid[howMany];

			for (int i = 0; i < howMany; ++i) {
				uuids[i] = new Uuid();
				System.out.println("Uuid #" + (i + 1) + ": " + uuids[i].toString());
			}

			ASSERT.isTrue(uuid.isEqual(uuid));
			ASSERT.isFalse(uuid.isEqual(uuids[howMany - 1]));
		} else {
			System.out.println(uuid.toString());
		}

	}
}