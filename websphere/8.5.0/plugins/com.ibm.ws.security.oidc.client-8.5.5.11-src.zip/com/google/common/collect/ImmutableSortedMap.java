package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList.Builder;
import com.google.common.collect.ImmutableSortedMap.1;
import com.google.common.collect.ImmutableSortedMap.SerializedForm;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.SortedMap;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(serializable = true, emulated = true)
public abstract class ImmutableSortedMap<K, V> extends ImmutableSortedMapFauxverideShim<K, V>
		implements
			NavigableMap<K, V> {
	private static final Comparator<Comparable> NATURAL_ORDER = Ordering.natural();
	private static final ImmutableSortedMap<Comparable, Object> NATURAL_EMPTY_MAP;
	private transient ImmutableSortedMap<K, V> descendingMap;
	private static final long serialVersionUID = 0L;

	static <K, V> ImmutableSortedMap<K, V> emptyMap(Comparator<? super K> comparator) {
		return (ImmutableSortedMap) (Ordering.natural().equals(comparator)
				? of()
				: new EmptyImmutableSortedMap(comparator));
	}

	static <K, V> ImmutableSortedMap<K, V> fromSortedEntries(Comparator<? super K> comparator,
			Collection<? extends Entry<? extends K, ? extends V>> entries) {
		if (entries.isEmpty()) {
			return emptyMap(comparator);
		} else {
			Builder<K> keyBuilder = ImmutableList.builder();
			Builder<V> valueBuilder = ImmutableList.builder();
			Iterator i$ = entries.iterator();

			while (i$.hasNext()) {
				Entry<? extends K, ? extends V> entry = (Entry) i$.next();
				keyBuilder.add(entry.getKey());
				valueBuilder.add(entry.getValue());
			}

			return new RegularImmutableSortedMap(new RegularImmutableSortedSet(keyBuilder.build(), comparator),
					valueBuilder.build());
		}
	}

	static <K, V> ImmutableSortedMap<K, V> from(ImmutableSortedSet<K> keySet, ImmutableList<V> valueList) {
		return (ImmutableSortedMap) (keySet.isEmpty()
				? emptyMap(keySet.comparator())
				: new RegularImmutableSortedMap((RegularImmutableSortedSet) keySet, valueList));
	}

	public static <K, V> ImmutableSortedMap<K, V> of() {
		return NATURAL_EMPTY_MAP;
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1) {
		return from(ImmutableSortedSet.of(k1), ImmutableList.of(v1));
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2) {
		return (new com.google.common.collect.ImmutableSortedMap.Builder(Ordering.natural())).put(k1, v1).put(k2, v2)
				.build();
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		return (new com.google.common.collect.ImmutableSortedMap.Builder(Ordering.natural())).put(k1, v1).put(k2, v2)
				.put(k3, v3).build();
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3,
			K k4, V v4) {
		return (new com.google.common.collect.ImmutableSortedMap.Builder(Ordering.natural())).put(k1, v1).put(k2, v2)
				.put(k3, v3).put(k4, v4).build();
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3,
			K k4, V v4, K k5, V v5) {
		return (new com.google.common.collect.ImmutableSortedMap.Builder(Ordering.natural())).put(k1, v1).put(k2, v2)
				.put(k3, v3).put(k4, v4).put(k5, v5).build();
	}

	public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map) {
		Ordering<K> naturalOrder = Ordering.natural();
		return copyOfInternal(map, naturalOrder);
	}

	public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map,
			Comparator<? super K> comparator) {
		return copyOfInternal(map, (Comparator) Preconditions.checkNotNull(comparator));
	}

	public static <K, V> ImmutableSortedMap<K, V> copyOfSorted(SortedMap<K, ? extends V> map) {
		Comparator<? super K> comparator = map.comparator();
		if (comparator == null) {
			comparator = NATURAL_ORDER;
		}

		return copyOfInternal(map, comparator);
	}

	private static <K, V> ImmutableSortedMap<K, V> copyOfInternal(Map<? extends K, ? extends V> map,
			Comparator<? super K> comparator) {
		boolean sameComparator = false;
		if (map instanceof SortedMap) {
			SortedMap<?, ?> sortedMap = (SortedMap) map;
			Comparator<?> comparator2 = sortedMap.comparator();
			sameComparator = comparator2 == null ? comparator == NATURAL_ORDER : comparator.equals(comparator2);
		}

		if (sameComparator && map instanceof ImmutableSortedMap) {
			ImmutableSortedMap<K, V> kvMap = (ImmutableSortedMap) map;
			if (!kvMap.isPartialView()) {
				return kvMap;
			}
		}

		Entry<K, V>[] entries = (Entry[]) map.entrySet().toArray(new Entry[0]);

		for (int i = 0; i < entries.length; ++i) {
			Entry<K, V> entry = entries[i];
			entries[i] = entryOf(entry.getKey(), entry.getValue());
		}

		List<Entry<K, V>> list = Arrays.asList(entries);
		if (!sameComparator) {
			sortEntries(list, comparator);
			validateEntries(list, comparator);
		}

		return fromSortedEntries(comparator, list);
	}

	private static <K, V> void sortEntries(List<Entry<K, V>> entries, Comparator<? super K> comparator) {
      Comparator<Entry<K, V>> entryComparator = new 1(comparator);
      Collections.sort(entries, entryComparator);
   }

	private static <K, V> void validateEntries(List<Entry<K, V>> entries, Comparator<? super K> comparator) {
		for (int i = 1; i < entries.size(); ++i) {
			if (comparator.compare(((Entry) entries.get(i - 1)).getKey(), ((Entry) entries.get(i)).getKey()) == 0) {
				throw new IllegalArgumentException(
						"Duplicate keys in mappings " + entries.get(i - 1) + " and " + entries.get(i));
			}
		}

	}

	public static <K extends Comparable<?>, V> com.google.common.collect.ImmutableSortedMap.Builder<K, V> naturalOrder() {
		return new com.google.common.collect.ImmutableSortedMap.Builder(Ordering.natural());
	}

	public static <K, V> com.google.common.collect.ImmutableSortedMap.Builder<K, V> orderedBy(
			Comparator<K> comparator) {
		return new com.google.common.collect.ImmutableSortedMap.Builder(comparator);
	}

	public static <K extends Comparable<?>, V> com.google.common.collect.ImmutableSortedMap.Builder<K, V> reverseOrder() {
		return new com.google.common.collect.ImmutableSortedMap.Builder(Ordering.natural().reverse());
	}

	ImmutableSortedMap() {
	}

	ImmutableSortedMap(ImmutableSortedMap<K, V> descendingMap) {
		this.descendingMap = descendingMap;
	}

	public int size() {
		return this.values().size();
	}

	public boolean containsValue(@Nullable Object value) {
		return this.values().contains(value);
	}

	boolean isPartialView() {
		return this.keySet().isPartialView() || this.values().isPartialView();
	}

	public ImmutableSet<Entry<K, V>> entrySet() {
		return super.entrySet();
	}

	public abstract ImmutableSortedSet<K> keySet();

	public abstract ImmutableCollection<V> values();

	public Comparator<? super K> comparator() {
		return this.keySet().comparator();
	}

	public K firstKey() {
		return this.keySet().first();
	}

	public K lastKey() {
		return this.keySet().last();
	}

	public ImmutableSortedMap<K, V> headMap(K toKey) {
		return this.headMap(toKey, false);
	}

	public abstract ImmutableSortedMap<K, V> headMap(K var1, boolean var2);

	public ImmutableSortedMap<K, V> subMap(K fromKey, K toKey) {
		return this.subMap(fromKey, true, toKey, false);
	}

	public ImmutableSortedMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive) {
		Preconditions.checkNotNull(fromKey);
		Preconditions.checkNotNull(toKey);
		Preconditions.checkArgument(this.comparator().compare(fromKey, toKey) <= 0,
				"expected fromKey <= toKey but %s > %s", new Object[]{fromKey, toKey});
		return this.headMap(toKey, toInclusive).tailMap(fromKey, fromInclusive);
	}

	public ImmutableSortedMap<K, V> tailMap(K fromKey) {
		return this.tailMap(fromKey, true);
	}

	public abstract ImmutableSortedMap<K, V> tailMap(K var1, boolean var2);

	public Entry<K, V> lowerEntry(K key) {
		return this.headMap(key, false).lastEntry();
	}

	public K lowerKey(K key) {
		return Maps.keyOrNull(this.lowerEntry(key));
	}

	public Entry<K, V> floorEntry(K key) {
		return this.headMap(key, true).lastEntry();
	}

	public K floorKey(K key) {
		return Maps.keyOrNull(this.floorEntry(key));
	}

	public Entry<K, V> ceilingEntry(K key) {
		return this.tailMap(key, true).firstEntry();
	}

	public K ceilingKey(K key) {
		return Maps.keyOrNull(this.ceilingEntry(key));
	}

	public Entry<K, V> higherEntry(K key) {
		return this.tailMap(key, false).firstEntry();
	}

	public K higherKey(K key) {
		return Maps.keyOrNull(this.higherEntry(key));
	}

	public Entry<K, V> firstEntry() {
		return this.isEmpty() ? null : (Entry) this.entrySet().asList().get(0);
	}

	public Entry<K, V> lastEntry() {
		return this.isEmpty() ? null : (Entry) this.entrySet().asList().get(this.size() - 1);
	}

	@Deprecated
	public final Entry<K, V> pollFirstEntry() {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final Entry<K, V> pollLastEntry() {
		throw new UnsupportedOperationException();
	}

	public ImmutableSortedMap<K, V> descendingMap() {
		ImmutableSortedMap<K, V> result = this.descendingMap;
		if (result == null) {
			result = this.descendingMap = this.createDescendingMap();
		}

		return result;
	}

	abstract ImmutableSortedMap<K, V> createDescendingMap();

	public ImmutableSortedSet<K> navigableKeySet() {
		return this.keySet();
	}

	public ImmutableSortedSet<K> descendingKeySet() {
		return this.keySet().descendingSet();
	}

	Object writeReplace() {
		return new SerializedForm(this);
	}

	static {
		NATURAL_EMPTY_MAP = new EmptyImmutableSortedMap(NATURAL_ORDER);
	}
}