package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Objects;
import com.google.common.collect.AbstractMultiset.ElementSet;
import com.google.common.collect.AbstractMultiset.EntrySet;
import com.google.common.collect.Multiset.Entry;
import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import javax.annotation.Nullable;

@GwtCompatible
abstract class AbstractMultiset<E> extends AbstractCollection<E> implements Multiset<E> {
	private transient Set<E> elementSet;
	private transient Set<Entry<E>> entrySet;

	public int size() {
		return Multisets.sizeImpl(this);
	}

	public boolean isEmpty() {
		return this.entrySet().isEmpty();
	}

	public boolean contains(@Nullable Object element) {
		return this.count(element) > 0;
	}

	public Iterator<E> iterator() {
		return Multisets.iteratorImpl(this);
	}

	public int count(@Nullable Object element) {
		Iterator i$ = this.entrySet().iterator();

		Entry entry;
		do {
			if (!i$.hasNext()) {
				return 0;
			}

			entry = (Entry) i$.next();
		} while (!Objects.equal(entry.getElement(), element));

		return entry.getCount();
	}

	public boolean add(@Nullable E element) {
		this.add(element, 1);
		return true;
	}

	public int add(@Nullable E element, int occurrences) {
		throw new UnsupportedOperationException();
	}

	public boolean remove(@Nullable Object element) {
		return this.remove(element, 1) > 0;
	}

	public int remove(@Nullable Object element, int occurrences) {
		throw new UnsupportedOperationException();
	}

	public int setCount(@Nullable E element, int count) {
		return Multisets.setCountImpl(this, element, count);
	}

	public boolean setCount(@Nullable E element, int oldCount, int newCount) {
		return Multisets.setCountImpl(this, element, oldCount, newCount);
	}

	public boolean addAll(Collection<? extends E> elementsToAdd) {
		return Multisets.addAllImpl(this, elementsToAdd);
	}

	public boolean removeAll(Collection<?> elementsToRemove) {
		return Multisets.removeAllImpl(this, elementsToRemove);
	}

	public boolean retainAll(Collection<?> elementsToRetain) {
		return Multisets.retainAllImpl(this, elementsToRetain);
	}

	public void clear() {
		Iterators.clear(this.entryIterator());
	}

	public Set<E> elementSet() {
		Set<E> result = this.elementSet;
		if (result == null) {
			this.elementSet = result = this.createElementSet();
		}

		return result;
	}

	Set<E> createElementSet() {
		return new ElementSet(this);
	}

	abstract Iterator<Entry<E>> entryIterator();

	abstract int distinctElements();

	public Set<Entry<E>> entrySet() {
		Set<Entry<E>> result = this.entrySet;
		return result == null ? (this.entrySet = this.createEntrySet()) : result;
	}

	Set<Entry<E>> createEntrySet() {
		return new EntrySet(this);
	}

	public boolean equals(@Nullable Object object) {
		return Multisets.equalsImpl(this, object);
	}

	public int hashCode() {
		return this.entrySet().hashCode();
	}

	public String toString() {
		return this.entrySet().toString();
	}
}