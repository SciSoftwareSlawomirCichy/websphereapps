package com.ibm.ws.security.oidc.client.filter;

public interface IValue {
	boolean equals(IValue var1) throws FilterException;

	boolean greaterThan(IValue var1) throws FilterException;

	boolean lessThan(IValue var1) throws FilterException;

	boolean containedBy(IValue var1) throws FilterException;
}