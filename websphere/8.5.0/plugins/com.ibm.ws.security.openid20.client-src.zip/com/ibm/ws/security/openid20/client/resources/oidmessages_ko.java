package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_ko extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"security.openid20.client.authrequestfailed",
					"CWTAI3002E: [{0}] 예외로 인해 OpenID 신뢰성 있는 파티(RP)가 인증을 위해 사용자를 OpenID 제공자(OP)로 경로 재지정하는 데 실패했습니다."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: OpenID 신뢰성 있는 파티(RP)가 WebSphere 서버의 기본 SSLContext를 가져오지 못해 초기화에 실패했습니다. 예외는 [{0}]입니다."},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: [{1}] 예외로 인해 OpenID 신뢰성 있는 파티(RP)가 [{0}] ID로 지정된 OpenID 제공자(OP)에 연결하는 데 실패했습니다."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: [{0}] 예외로 인해 OpenID 신뢰성 있는 파티(RP)를 초기화하는 데 실패했습니다."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: [{0}] 특성의 값이 올바르게 형식화되지 않아 OpenID 신뢰성 있는 파티(RP)가 초기화되지 않았습니다."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: 기본 인증 토큰 값이 유효하지 않아 OpenID 신뢰성 있는 파티(RP)가 기본 인증 토큰을 사용하여 요청을 인증하는 데 실패했습니다."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: [{0}] 특성을 올바르게 지정하지 않아 OpenID 신뢰성 있는 파티(RP)를 초기화하는 데 실패했습니다. 유효한 URL이어야 합니다."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: OpenID 신뢰성 있는 파티(RP)가 OpenID 제공자(OP)에서 올바르지 않은 응답을 수신했습니다. 이 오류의 원인은 [{0}]입니다. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: OpenID 신뢰성 있는 파티(RP)가 해당 내부 캐시의 최대 용량에 도달하여 인증을 수행하는 데 실패했습니다."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: 필수 특성 axRequiredAttribute[n]가 누락되어 OpenID 신뢰성 있는 파티(RP)를 초기화하는 데 실패했습니다. 하나 이상의 특성을 정의해야 합니다."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: 필수 특성 [{0}]의 값이 누락되거나 비어 있어서 OpenID 신뢰성 있는 파티(RP)를 초기화하는 데 실패했습니다."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: OpenID 신뢰성 있는 파티(RP)에 SSL(HTTPS)이 필요하지만 OpenID 제공자(OP) URL이 HTTP입니다. [{0}]. [{1}] 속성이 대상 URL 스킴과 일치해야 합니다. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: OpenID 신뢰성 있는 파티(RP)가 OpenID 스펙 버전 2를 지원하지 않는 OpenID 제공자(OP)에서 응답을 수신했습니다."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: OpenID 신뢰성 있는 파티(RP)가 OpenID 제공자(OP)에서 수신된 응답을 검증하는 중에 실패했습니다. 예외는 [{0}]입니다."}};

	public Object[][] getContents() {
		return resources;
	}
}