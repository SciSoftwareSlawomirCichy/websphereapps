package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.ExceptionType;

public abstract class ExceptionMappingStrategy {
	private static final TraceComponent tc = Tr.register(ExceptionMappingStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public abstract Throwable setUncheckedException(EJSDeployedSupport var1, Throwable var2);

	public abstract Exception mapCSITransactionRolledBackException(EJSDeployedSupport var1,
			CSITransactionRolledbackException var2) throws CSIException;

	public Throwable findRootCause(Throwable throwable) {
		return ExceptionUtil.findRootCause(throwable);
	}

	public final void setCheckedException(EJSDeployedSupport s, Exception ex) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			Tr.event(tc, "setting checked exception", ex);
		}

		s.exType = ExceptionType.CHECKED_EXCEPTION;
		s.ivException = ex;
		s.rootEx = this.findRootCause(ex);
		Boolean applicationExceptionRollback = s.getApplicationExceptionRollback(ex);
		if (applicationExceptionRollback == Boolean.TRUE) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "ApplicationException with rollback set to true, setting rollback only", ex);
			}

			s.currentTx.setRollbackOnly();
		}

	}
}