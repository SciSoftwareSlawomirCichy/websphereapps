package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface PropertiesNotSupportedType {
	List getEntityTypes();

	String[] getEntityTypesAsArray();

	String getName();

	void setName(String var1);
}