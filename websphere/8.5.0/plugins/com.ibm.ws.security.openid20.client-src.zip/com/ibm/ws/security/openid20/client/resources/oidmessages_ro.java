package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_ro extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: Partea intermediară de încredere OpenID Connect (RP) nu a reuşit să redirecteze utilizatorul către OP (OpenID provider - furnizor OpenID) pentru autentificare din cauza excepţiei [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: Partea intermediară de încredere OpenID Connect (RP) nu a reuşit să se iniţializeze deoarece nu a reuşit să obţină SSLContext implicit pentru serverul WebSphere. Excepţia este [{0}]."},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: Partea intermediară de încredere OpenID Connect (RP) nu a reuşit să se conecteze la OP-ul (OpenID provider - furnizor OpenID) specificat de identificator [{0}] din cauza excepţiei [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: Partea intermediară de încredere OpenID Connect (RP) nu a reuşit să se iniţializez din cauza excepţiei [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: Partea intermediară de încredere OpenID Connect (RP) s-a iniţializat deoarece valoarea pentru proprietatea [{0}] nu este formatată corect."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: Partea intermediară de încredere OpenID Connect (RP) nu a reuşit să autentifice o cerere folosind token-ul Basic Auth deoarece valoarea token-ului nu este validă."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: Partea intermediară de încredere OpenID Connect (RP) s-a iniţializat deoarece proprietatea [{0}] nu este specificată corect. Ar trebui să fie o adresă URL validă."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: Partea intermediară de încredere OpenID Connect (RP) an primit un răspuns incorect de la OP (OpenID provider - furnizor OpenID). Cauza acestei erori este [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: Partea intermediară de încredere OpenID Connect (RP) nu a reuşit să realizeze autentificarea deoarece acesta a ajuns la capacitatea maximă a memoriei sale inerne cache."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: Partea intermediară de încredere OpenID Connect (RP) s-a iniţializat din cauza lipsei proprietăţii necesare  axRequiredAttribute[n]. Cel puţin o proprietate trebuie să fie definită."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: Partea intermediară de încredere OpenID Connect (RP) nu a reuşit să se iniţializeze deoarece valoarea pentru proprietatea obligatorie [{0}] lipseşte sau este goală."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: Partea intermediară de încredere OpenID Connect (RP) are nevoie de SSL (HTTPS), dar URL-ul OP-ului (OpenID provider - furnizor OpenID) este HTTP: [{0}].  Atributul [{1}] ar trebui să se potrivească cu schema URL-ului ţintă. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: Partea intermediară de încredere OpenID Connect (RP) a primit un răspuns de la OP-ul (OpenID provider - furnizor OpenID) care nu suportă specificarea OpenID versiunea 2."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: Partea intermediară de încredere OpenID Connect (RP) nu a eşuat în timpul verificării răspunsului primit de la OP (OpenID provider - furnizor OpenID). Excepţia a fost [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}