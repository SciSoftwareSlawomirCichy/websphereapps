package com.google.common.graph;

import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import com.google.common.graph.AbstractDirectedNetworkConnections.1;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

abstract class AbstractDirectedNetworkConnections<N, E> implements NetworkConnections<N, E> {
	protected final Map<E, N> inEdgeMap;
	protected final Map<E, N> outEdgeMap;
	private int selfLoopCount;

	protected AbstractDirectedNetworkConnections(Map<E, N> inEdgeMap, Map<E, N> outEdgeMap, int selfLoopCount) {
		this.inEdgeMap = (Map) Preconditions.checkNotNull(inEdgeMap);
		this.outEdgeMap = (Map) Preconditions.checkNotNull(outEdgeMap);
		this.selfLoopCount = Graphs.checkNonNegative(selfLoopCount);
		Preconditions.checkState(selfLoopCount <= inEdgeMap.size() && selfLoopCount <= outEdgeMap.size());
	}

	public Set<N> adjacentNodes() {
		return Sets.union(this.predecessors(), this.successors());
	}

	public Set<E> incidentEdges() {
      return new 1(this);
   }

	public Set<E> inEdges() {
		return Collections.unmodifiableSet(this.inEdgeMap.keySet());
	}

	public Set<E> outEdges() {
		return Collections.unmodifiableSet(this.outEdgeMap.keySet());
	}

	public N adjacentNode(E edge) {
		return Preconditions.checkNotNull(this.outEdgeMap.get(edge));
	}

	public N removeInEdge(E edge, boolean isSelfLoop) {
		if (isSelfLoop) {
			Graphs.checkNonNegative(--this.selfLoopCount);
		}

		N previousNode = this.inEdgeMap.remove(edge);
		return Preconditions.checkNotNull(previousNode);
	}

	public N removeOutEdge(E edge) {
		N previousNode = this.outEdgeMap.remove(edge);
		return Preconditions.checkNotNull(previousNode);
	}

	public void addInEdge(E edge, N node, boolean isSelfLoop) {
		if (isSelfLoop) {
			Graphs.checkPositive(++this.selfLoopCount);
		}

		N previousNode = this.inEdgeMap.put(edge, node);
		Preconditions.checkState(previousNode == null);
	}

	public void addOutEdge(E edge, N node) {
		N previousNode = this.outEdgeMap.put(edge, node);
		Preconditions.checkState(previousNode == null);
	}
}