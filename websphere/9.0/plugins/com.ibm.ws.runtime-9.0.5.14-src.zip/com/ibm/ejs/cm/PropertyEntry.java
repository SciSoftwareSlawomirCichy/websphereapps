package com.ibm.ejs.cm;

import java.io.Serializable;

public class PropertyEntry implements Serializable, Comparable {
	private static final long serialVersionUID = -8098002519020207249L;
	private String propertyName;
	private boolean required;

	public PropertyEntry(String name, boolean isRequired) {
		this.propertyName = name;
		this.required = isRequired;
	}

	public int compareTo(Object o) {
		return this.propertyName.compareTo(((PropertyEntry) o).getPropertyName());
	}

	public String getPropertyName() {
		return this.propertyName;
	}

	public boolean isRequired() {
		return this.required;
	}

	public void setPropertyName(String name) {
		this.propertyName = name;
	}

	public void setRequired(boolean isRequired) {
		this.required = isRequired;
	}

	public String toString() {
		return "PropertyName: " + this.propertyName;
	}
}