package com.ibm.ISecurityUtilityImpl;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.wsspi.security.crypto.EncryptedInfo;
import com.ibm.wsspi.security.crypto.PasswordEncryptException;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

public class PasswordUtil {
	private static final TraceComponent tc = Tr.register(PasswordUtil.class, "SASRas",
			"com.ibm.ejs.resources.security");
	public static final String STRING_CONVERSION_CODE = "UTF8";
	public static final String DEFAULT_CRYPTO_ALGORITHM;
	private static final String CRYPTO_ALGORITHM_STARTED = "{";
	private static final String CRYPTO_ALGORITHM_STOPPED = "}";
	private static final String EMPTY_STRING = new String("");
	private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
	private static final String[] SUPPORTED_CRYPTO_ALGORITHMS = PasswordCipherUtil.getSupportedCryptoAlgorithms();
	private static final byte[] BASE64_ENCODE_MAP;
	private static final byte[] BASE64_DECODE_MAP;
	private static final Class<?> thisClass = PasswordUtil.class;
	private static String passwordEncoderDebug = null;

	public static String decode(String encoded_string)
			throws InvalidPasswordDecodingException, UnsupportedCryptoAlgorithmException {
		if (encoded_string == null) {
			throw new InvalidPasswordDecodingException();
		} else {
			String crypto_algorithm = getCryptoAlgorithm(encoded_string);
			if (crypto_algorithm == null) {
				throw new InvalidPasswordDecodingException();
			} else if (!isValidCryptoAlgorithm(crypto_algorithm)) {
				throw new UnsupportedCryptoAlgorithmException();
			} else {
				String decoded_string = decode_password(removeCryptoAlgorithmTag(encoded_string), crypto_algorithm);
				if (decoded_string == null) {
					throw new InvalidPasswordDecodingException();
				} else {
					return decoded_string;
				}
			}
		}
	}

	public static String encode(String decoded_string)
			throws InvalidPasswordEncodingException, UnsupportedCryptoAlgorithmException {
		return encode(decoded_string, DEFAULT_CRYPTO_ALGORITHM);
	}

	public static String encode(String decoded_string, String crypto_algorithm)
			throws InvalidPasswordEncodingException, UnsupportedCryptoAlgorithmException {
		if (!isValidCryptoAlgorithm(crypto_algorithm)) {
			throw new UnsupportedCryptoAlgorithmException();
		} else if (decoded_string == null) {
			throw new InvalidPasswordEncodingException();
		} else {
			String current_crypto_algorithm = getCryptoAlgorithm(decoded_string);
			if (current_crypto_algorithm != null && current_crypto_algorithm.startsWith(crypto_algorithm)) {
				throw new InvalidPasswordEncodingException();
			} else {
				if (current_crypto_algorithm != null) {
					decoded_string = passwordDecode(decoded_string);
				}

				String encoded_string = encode_password(decoded_string.trim(), crypto_algorithm.trim());
				if (encoded_string == null) {
					throw new InvalidPasswordEncodingException();
				} else {
					return encoded_string;
				}
			}
		}
	}

	public static String getCryptoAlgorithm(String encoded_string) {
		String crypto_algorithm = null;
		debugMessage("encoded_string = " + encoded_string);
		if (encoded_string != null) {
			encoded_string = encoded_string.trim();
			if (encoded_string.length() >= 2) {
				int algorithm_started = encoded_string.indexOf("{");
				debugMessage("algorithm_started  = " + algorithm_started);
				if (algorithm_started == 0) {
					++algorithm_started;
					int algorithm_stopped = encoded_string.indexOf("}", algorithm_started);
					debugMessage("algorithm stopped = " + algorithm_stopped);
					if (algorithm_stopped > 0) {
						if (algorithm_started < algorithm_stopped) {
							crypto_algorithm = encoded_string.substring(algorithm_started, algorithm_stopped).trim();
							debugMessage("crypto_algorithm = " + crypto_algorithm);
						} else {
							crypto_algorithm = EMPTY_STRING;
						}
					}
				}
			}
		}

		return crypto_algorithm;
	}

	public static String getCryptoAlgorithmTag(String encoded_string) {
		String crypto_algorithm_tag = null;
		String crypto_algorithm = getCryptoAlgorithm(encoded_string);
		if (crypto_algorithm != null) {
			StringBuffer buffer = new StringBuffer("{");
			if (crypto_algorithm.length() > 0) {
				buffer.append(crypto_algorithm);
			}

			buffer.append("}");
			crypto_algorithm_tag = buffer.toString();
		}

		return crypto_algorithm_tag;
	}

	public static boolean isEncrypted(String encoded_string) {
		String crypto_algorithm = getCryptoAlgorithm(encoded_string);
		return crypto_algorithm != null && isValidCryptoAlgorithm(crypto_algorithm);
	}

	public static boolean isValidCryptoAlgorithm(String crypto_algorithm) {
		if (crypto_algorithm != null) {
			crypto_algorithm = crypto_algorithm.trim();
			if (crypto_algorithm.length() == 0) {
				return true;
			}

			for (int i = 0; i < SUPPORTED_CRYPTO_ALGORITHMS.length; ++i) {
				if (crypto_algorithm.startsWith(SUPPORTED_CRYPTO_ALGORITHMS[i])) {
					return true;
				}
			}
		}

		return false;
	}

	public static boolean isValidCryptoAlgorithmTag(String crypto_algorithm_tag) {
		return isValidCryptoAlgorithm(getCryptoAlgorithm(crypto_algorithm_tag));
	}

	public static String passwordDecode(String encoded_string) {
		if (encoded_string == null) {
			return null;
		} else {
			String crypto_algorithm = getCryptoAlgorithm(encoded_string);
			if (crypto_algorithm == null) {
				return encoded_string;
			} else if (!isValidCryptoAlgorithm(crypto_algorithm)) {
				debugMessage("not a valid crypto algorith, returning null");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Unsupported crypto algorithm:" + crypto_algorithm + " found. Returning null.");
				}

				return null;
			} else {
				return decode_password(removeCryptoAlgorithmTag(encoded_string), crypto_algorithm);
			}
		}
	}

	public static String passwordEncode(String decoded_string) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "passwordEncode");
		}

		String isCustomPasswordEnabled = System
				.getProperty("com.ibm.wsspi.security.crypto.customPasswordEncryptionEnabled");
		if (isCustomPasswordEnabled != null && isCustomPasswordEnabled.equalsIgnoreCase("true")) {
			debugMessage("calling passwordEncode with custom algorithm");
			return passwordEncode(decoded_string, "custom");
		} else {
			debugMessage("calling passwordEncode with defaultlt algorithm");
			return passwordEncode(decoded_string, DEFAULT_CRYPTO_ALGORITHM);
		}
	}

	public static String passwordEncode(String decoded_string, String crypto_algorithm) {
		debugMessage("passwordEncode entry -  crypto_algorithm " + crypto_algorithm);
		if (!isValidCryptoAlgorithm(crypto_algorithm)) {
			debugMessage("crypto_algorithm is not valid. Returning null");
			return null;
		} else if (decoded_string == null) {
			debugMessage("input string for encoding is null. Returning null");
			return null;
		} else {
			String current_crypto_algorithm = getCryptoAlgorithm(decoded_string);
			debugMessage("current_crypto_algorithm=" + current_crypto_algorithm);
			if (current_crypto_algorithm != null && current_crypto_algorithm.equals(crypto_algorithm)) {
				debugMessage("current algorithm matches the string's algorithm. Just returning the input string");
				return isValidCryptoAlgorithm(current_crypto_algorithm) ? decoded_string.trim() : null;
			} else {
				if (current_crypto_algorithm != null) {
					debugMessage(
							"current algorithm is specified but not matching the specified algorithm. Trying to decode first....");
					decoded_string = passwordDecode(decoded_string);
				}

				debugMessage("decoded_string = " + decoded_string);
				if (decoded_string == null) {
					return null;
				} else {
					debugMessage("calling encode with crypto_algorithm " + crypto_algorithm);
					return encode_password(decoded_string.trim(), crypto_algorithm.trim());
				}
			}
		}
	}

	public static String removeCryptoAlgorithmTag(String encoded_string) {
		String encoded_password = null;
		if (encoded_string != null) {
			encoded_string = encoded_string.trim();
			if (encoded_string.length() >= 2) {
				int algorithm_started = encoded_string.indexOf("{");
				if (algorithm_started == 0) {
					++algorithm_started;
					int algorithm_stopped = encoded_string.indexOf("}", algorithm_started);
					if (algorithm_stopped > 0) {
						++algorithm_stopped;
						if (algorithm_stopped < encoded_string.length()) {
							encoded_password = encoded_string.substring(algorithm_stopped).trim();
						} else {
							encoded_password = EMPTY_STRING;
						}
					}
				}
			}
		}

		return encoded_password;
	}

	private static byte[] convert_to_bytes(String string) {
		byte[] bytes = null;
		if (string != null) {
			if (string.length() == 0) {
				bytes = EMPTY_BYTE_ARRAY;
			} else {
				try {
					bytes = string.getBytes("UTF8");
				} catch (UnsupportedEncodingException var3) {
					Manager.Ffdc.log(var3, thisClass, "com.ibm.ISecurityUtilityImpl.PasswordUtil.convert_to_bytes",
							"547");
					bytes = null;
				}
			}
		}

		return bytes;
	}

	private static String convert_to_string(byte[] bytes) {
		String string = null;
		if (bytes != null) {
			if (bytes.length == 0) {
				string = EMPTY_STRING;
			} else {
				try {
					string = new String(bytes, "UTF8");
				} catch (UnsupportedEncodingException var3) {
					Manager.Ffdc.log(var3, thisClass, "com.ibm.ISecurityUtilityImpl.PasswordUtil.convert_to_string",
							"578");
					string = null;
				}
			}
		}

		return string;
	}

	private static byte[] convert_viewable_to_bytes(String string) {
		byte[] bytes = null;
		if (string != null) {
			if (string.length() == 0) {
				bytes = EMPTY_BYTE_ARRAY;
			} else {
				try {
					bytes = base64Decode(convert_to_bytes(string));
				} catch (Exception var3) {
					Manager.Ffdc.log(var3, thisClass,
							"com.ibm.ISecurityUtilityImpl.PasswordUtil.convert_viewable_to_bytes", "610");
					bytes = null;
				}
			}
		}

		return bytes;
	}

	private static byte[] base64Decode(byte[] bytes) {
		int tail = bytes.length;

		do {
			--tail;
		} while (bytes[tail] == 61);

		byte[] dest = new byte[tail + 1 - bytes.length / 4];

		int destx;
		for (destx = 0; destx < bytes.length; ++destx) {
			bytes[destx] = BASE64_DECODE_MAP[bytes[destx]];
		}

		destx = dest.length - 2;
		int didx = 0;

		int sidx;
		for (sidx = 0; didx < destx; sidx += 4) {
			dest[didx] = (byte) (bytes[sidx] << 2 & 255 | bytes[sidx + 1] >>> 4 & 3);
			dest[didx + 1] = (byte) (bytes[sidx + 1] << 4 & 255 | bytes[sidx + 2] >>> 2 & 15);
			dest[didx + 2] = (byte) (bytes[sidx + 2] << 6 & 255 | bytes[sidx + 3] & 63);
			didx += 3;
		}

		if (didx < dest.length) {
			dest[didx++] = (byte) (bytes[sidx] << 2 & 255 | bytes[sidx + 1] >>> 4 & 3);
			if (didx < dest.length) {
				dest[didx] = (byte) (bytes[sidx + 1] << 4 & 255 | bytes[sidx + 2] >>> 2 & 15);
			}
		}

		return dest;
	}

	private static String convert_viewable_to_string(byte[] bytes) {
		String string = null;
		if (bytes != null) {
			if (bytes.length == 0) {
				string = EMPTY_STRING;
			} else {
				try {
					string = convert_to_string(base64Encode(bytes));
				} catch (Exception var3) {
					Manager.Ffdc.log(var3, thisClass,
							"com.ibm.ISecurityUtilityImpl.PasswordUtil.convert_viewable_to_string", "686");
					string = null;
				}
			}
		}

		return string;
	}

	private static byte[] base64Encode(byte[] bytes) {
		byte[] dest = new byte[(bytes.length + 2) / 3 * 4];
		int sidx = 0;

		int didx;
		for (didx = 0; sidx < bytes.length - 2; sidx += 3) {
			dest[didx++] = BASE64_ENCODE_MAP[bytes[sidx] >>> 2 & 63];
			dest[didx++] = BASE64_ENCODE_MAP[bytes[sidx + 1] >>> 4 & 15 | bytes[sidx] << 4 & 63];
			dest[didx++] = BASE64_ENCODE_MAP[bytes[sidx + 2] >>> 6 & 3 | bytes[sidx + 1] << 2 & 63];
			dest[didx++] = BASE64_ENCODE_MAP[bytes[sidx + 2] & 63];
		}

		if (sidx < bytes.length) {
			dest[didx++] = BASE64_ENCODE_MAP[bytes[sidx] >>> 2 & 63];
			if (sidx < bytes.length - 1) {
				dest[didx++] = BASE64_ENCODE_MAP[bytes[sidx + 1] >>> 4 & 15 | bytes[sidx] << 4 & 63];
				dest[didx++] = BASE64_ENCODE_MAP[bytes[sidx + 1] << 2 & 63];
			} else {
				dest[didx++] = BASE64_ENCODE_MAP[bytes[sidx] << 4 & 63];
			}
		}

		while (didx < dest.length) {
			dest[didx] = 61;
			++didx;
		}

		return dest;
	}

	private static String decode_password(String encoded_string, String crypto_algorithm) {
		debugMessage(
				"in decode_password, encoded_string = " + encoded_string + " crypto_algorithm = " + crypto_algorithm);
		StringBuffer buffer = new StringBuffer();
		if (crypto_algorithm.length() == 0) {
			buffer.append(encoded_string);
		} else {
			String decoded_string = null;
			if (encoded_string.length() > 0) {
				debugMessage("before convert_viewable_to_bytes");
				byte[] encrypted_bytes = convert_viewable_to_bytes(encoded_string);
				debugMessage("after convert_viewable_to_bytes, encrypted_bytes = " + encrypted_bytes);
				if (encrypted_bytes == null) {
					return null;
				}

				if (encrypted_bytes.length > 0) {
					Object var5 = null;

					byte[] decrypted_bytes;
					try {
						decrypted_bytes = PasswordCipherUtil.decipher(encrypted_bytes, crypto_algorithm);
					} catch (InvalidPasswordCipherException var7) {
						Manager.Ffdc.log(var7, thisClass, "com.ibm.ISecurityUtilityImpl.PasswordUtil.decode_password",
								"792");
						return null;
					} catch (UnsupportedCryptoAlgorithmException var8) {
						Manager.Ffdc.log(var8, thisClass, "com.ibm.ISecurityUtilityImpl.PasswordUtil.decode_password",
								"797");
						return null;
					}

					if (decrypted_bytes != null && decrypted_bytes.length > 0) {
						decoded_string = convert_to_string(decrypted_bytes);
					}
				}
			}

			if (decoded_string != null && decoded_string.length() > 0) {
				buffer.append(decoded_string);
			}
		}

		return buffer.toString();
	}

	private static String encode_password(String decoded_string, String crypto_algorithm) {
		debugMessage("Entering encode_password.  crypto_algorithm=" + crypto_algorithm);
		StringBuffer buffer = new StringBuffer("{");
		if (crypto_algorithm.length() == 0) {
			buffer.append("}").append(decoded_string);
		} else {
			String encoded_string = null;
			EncryptedInfo info = null;
			if (decoded_string.length() > 0) {
				byte[] decrypted_bytes = convert_to_bytes(decoded_string);
				debugMessage("decrypted_bytes:" + decrypted_bytes);
				if (decrypted_bytes.length > 0) {
					byte[] encrypted_bytes = null;
					boolean done = false;

					while (true) {
						if (done) {
							if (encrypted_bytes != null && encrypted_bytes.length > 0) {
								encoded_string = convert_viewable_to_string(encrypted_bytes);
								if (encoded_string == null) {
									return null;
								}
							}
							break;
						}

						try {
							try {
								info = PasswordCipherUtil.encipher_internal(decrypted_bytes, crypto_algorithm);
								if (info != null) {
									encrypted_bytes = info.getEncryptedBytes();
									debugMessage("encrypted_bytes:" + encrypted_bytes);
								}

								done = true;
							} catch (PasswordEncryptException var10) {
								debugMessage("PasswordEncryptException: " + var10.getMessage());
								Manager.Ffdc.log(var10, thisClass,
										"com.ibm.ISecurityUtilityImpl.PasswordUtil.encode_password", "884");
								throw new InvalidPasswordCipherException();
							}
						} catch (InvalidPasswordCipherException var11) {
							if (!System.getProperty("os.name").equals("OS/400")) {
								debugMessage("InvalidPasswordCipherException: " + var11.getMessage());
								Manager.Ffdc.log(var11, thisClass,
										"com.ibm.ISecurityUtilityImpl.PasswordUtil.encode_password", "907");
								return null;
							}

							String FailSafeCryptoAlgorithm = PasswordCipherUtil.getFailSafeCryptoAlgorithm();
							if (crypto_algorithm.equalsIgnoreCase(FailSafeCryptoAlgorithm)) {
								debugMessage("InvalidPasswordCipherException with IBM i: " + var11.getMessage());
								Manager.Ffdc.log(var11, thisClass,
										"com.ibm.ISecurityUtilityImpl.PasswordUtil.encode_password", "896");
								return null;
							}

							crypto_algorithm = FailSafeCryptoAlgorithm;
						} catch (UnsupportedCryptoAlgorithmException var12) {
							Manager.Ffdc.log(var12, thisClass,
									"com.ibm.ISecurityUtilityImpl.PasswordUtil.encode_password", "913");
							return null;
						}
					}
				}
			}

			if (info != null && info.getKeyAlias() != null && !info.getKeyAlias().equals("")) {
				buffer.append(crypto_algorithm).append(":").append(info.getKeyAlias()).append("}");
			} else {
				buffer.append(crypto_algorithm).append("}");
			}

			if (encoded_string != null && encoded_string.length() > 0) {
				buffer.append(encoded_string);
			}
		}

		return buffer.toString();
	}

	static void debugMessage(String message) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, message);
		}

		if (passwordEncoderDebug == null) {
			passwordEncoderDebug = System.getProperty("com.ibm.websphere.security.passwordEncoderDebug");
			if (passwordEncoderDebug != null && !passwordEncoderDebug.equalsIgnoreCase("true")) {
				passwordEncoderDebug = "false";
			}
		}

		if (passwordEncoderDebug != null && passwordEncoderDebug.equalsIgnoreCase("true")) {
			System.out.println("DEBUG:" + message);
		}

	}

	static void debugMessage(Exception e) {
		if (e != null) {
			StringBuffer sb = new StringBuffer("---DEBUG: Exception stacktrace---");
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			e.printStackTrace(new PrintStream(baos));
			sb.append("\n");
			sb.append(baos);
			sb.append("---End of stacktrace----");
			debugMessage(sb.toString());
		} else {
			debugMessage("Exception is null");
		}

	}

	public static boolean isInitializedWithoutError() {
		return PasswordCipherUtil.isInitializedWithoutError();
	}

	static {
		DEFAULT_CRYPTO_ALGORITHM = SUPPORTED_CRYPTO_ALGORITHMS[0];
		byte[] map = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86,
				87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114,
				115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47};
		BASE64_ENCODE_MAP = map;
		BASE64_DECODE_MAP = new byte[128];

		int idx;
		for (idx = 0; idx < BASE64_DECODE_MAP.length; ++idx) {
			BASE64_DECODE_MAP[idx] = -1;
		}

		for (idx = 0; idx < BASE64_ENCODE_MAP.length; ++idx) {
			BASE64_DECODE_MAP[BASE64_ENCODE_MAP[idx]] = (byte) idx;
		}

	}
}