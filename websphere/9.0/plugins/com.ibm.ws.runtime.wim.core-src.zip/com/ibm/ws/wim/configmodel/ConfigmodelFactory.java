package com.ibm.ws.wim.configmodel;

import com.ibm.ws.wim.configmodel.impl.ConfigmodelFactoryImpl;
import org.eclipse.emf.ecore.EFactory;

public interface ConfigmodelFactory extends EFactory {
	ConfigmodelFactory eINSTANCE = new ConfigmodelFactoryImpl();

	AttributeConfigurationType createAttributeConfigurationType();

	AttributeGroupType createAttributeGroupType();

	AttributesCacheType createAttributesCacheType();

	AttributeType createAttributeType();

	AuthorizationType createAuthorizationType();

	BaseEntriesType createBaseEntriesType();

	CacheConfigurationType createCacheConfigurationType();

	ConfigurationProviderType createConfigurationProviderType();

	ConnectionsType createConnectionsType();

	ContextPoolType createContextPoolType();

	CustomPropertiesType createCustomPropertiesType();

	DatabaseRepositoryType createDatabaseRepositoryType();

	DocumentRoot createDocumentRoot();

	DynamicMemberAttributesType createDynamicMemberAttributesType();

	DynamicModelType createDynamicModelType();

	EntryMappingRepositoryType createEntryMappingRepositoryType();

	EnvironmentPropertiesType createEnvironmentPropertiesType();

	Krb5AuthenticationType createKrb5AuthenticationType();

	FileRepositoryType createFileRepositoryType();

	GroupConfigurationType createGroupConfigurationType();

	InlineExit createInlineExit();

	LdapEntityTypesType createLdapEntityTypesType();

	LdapRepositoryType createLdapRepositoryType();

	LdapServerConfigurationType createLdapServerConfigurationType();

	LdapServersType createLdapServersType();

	MemberAttributesType createMemberAttributesType();

	MembershipAttributeType createMembershipAttributeType();

	ModificationSubscriber createModificationSubscriber();

	ModificationSubscriberList createModificationSubscriberList();

	NotificationSubscriber createNotificationSubscriber();

	NotificationSubscriberList createNotificationSubscriberList();

	ParticipatingBaseEntriesType createParticipatingBaseEntriesType();

	PluginManagerConfigurationType createPluginManagerConfigurationType();

	PostExit createPostExit();

	PreExit createPreExit();

	ProfileRepositoryType createProfileRepositoryType();

	PropertiesNotSupportedType createPropertiesNotSupportedType();

	PropertyExtensionRepositoryType createPropertyExtensionRepositoryType();

	RdnAttributesType createRdnAttributesType();

	RealmConfigurationType createRealmConfigurationType();

	RealmDefaultParentType createRealmDefaultParentType();

	RealmType createRealmType();

	RepositoryType createRepositoryType();

	SearchResultsCacheType createSearchResultsCacheType();

	SPIBridgeRepositoryType createSPIBridgeRepositoryType();

	StaticModelType createStaticModelType();

	SupportedEntityTypesType createSupportedEntityTypesType();

	TopicEmitter createTopicEmitter();

	TopicRegistrationList createTopicRegistrationList();

	TopicSubscriber createTopicSubscriber();

	TopicSubscriberList createTopicSubscriberList();

	UserRegistryInfoMappingType createUserRegistryInfoMappingType();

	ConfigmodelPackage getConfigmodelPackage();
}