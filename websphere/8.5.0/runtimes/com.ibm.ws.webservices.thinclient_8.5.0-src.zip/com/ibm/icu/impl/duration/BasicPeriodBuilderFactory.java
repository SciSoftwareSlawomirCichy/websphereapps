package com.ibm.icu.impl.duration;

import com.ibm.icu.impl.duration.BasicPeriodBuilderFactory.Settings;
import com.ibm.icu.impl.duration.impl.PeriodFormatterDataService;
import java.util.TimeZone;

class BasicPeriodBuilderFactory implements PeriodBuilderFactory {
	private PeriodFormatterDataService ds;
	private Settings settings;
	private static final short allBits = 255;

	BasicPeriodBuilderFactory(PeriodFormatterDataService ds) {
		this.ds = ds;
		this.settings = new Settings(this);
	}

	static long approximateDurationOf(TimeUnit unit) {
		return TimeUnit.approxDurations[unit.ordinal];
	}

	public PeriodBuilderFactory setAvailableUnitRange(TimeUnit minUnit, TimeUnit maxUnit) {
		int uset = 0;

		for (int i = maxUnit.ordinal; i <= minUnit.ordinal; ++i) {
			uset |= 1 << i;
		}

		if (uset == 0) {
			throw new IllegalArgumentException("range " + minUnit + " to " + maxUnit + " is empty");
		} else {
			this.settings = this.settings.setUnits(uset);
			return this;
		}
	}

	public PeriodBuilderFactory setUnitIsAvailable(TimeUnit unit, boolean available) {
		int uset = this.settings.uset;
		int uset;
		if (available) {
			uset = uset | 1 << unit.ordinal;
		} else {
			uset = uset & ~(1 << unit.ordinal);
		}

		this.settings = this.settings.setUnits(uset);
		return this;
	}

	public PeriodBuilderFactory setMaxLimit(float maxLimit) {
		this.settings = this.settings.setMaxLimit(maxLimit);
		return this;
	}

	public PeriodBuilderFactory setMinLimit(float minLimit) {
		this.settings = this.settings.setMinLimit(minLimit);
		return this;
	}

	public PeriodBuilderFactory setAllowZero(boolean allow) {
		this.settings = this.settings.setAllowZero(allow);
		return this;
	}

	public PeriodBuilderFactory setWeeksAloneOnly(boolean aloneOnly) {
		this.settings = this.settings.setWeeksAloneOnly(aloneOnly);
		return this;
	}

	public PeriodBuilderFactory setAllowMilliseconds(boolean allow) {
		this.settings = this.settings.setAllowMilliseconds(allow);
		return this;
	}

	public PeriodBuilderFactory setLocale(String localeName) {
		this.settings = this.settings.setLocale(localeName);
		return this;
	}

	public PeriodBuilderFactory setTimeZone(TimeZone timeZone) {
		return this;
	}

	private Settings getSettings() {
		return this.settings.effectiveSet() == 0 ? null : this.settings.setInUse();
	}

	public PeriodBuilder getFixedUnitBuilder(TimeUnit unit) {
		return FixedUnitBuilder.get(unit, this.getSettings());
	}

	public PeriodBuilder getSingleUnitBuilder() {
		return SingleUnitBuilder.get(this.getSettings());
	}

	public PeriodBuilder getOneOrTwoUnitBuilder() {
		return OneOrTwoUnitBuilder.get(this.getSettings());
	}

	public PeriodBuilder getMultiUnitBuilder(int periodCount) {
		return MultiUnitBuilder.get(periodCount, this.getSettings());
	}
}