package com.ibm.ejs.cm.portability;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.sql.Connection;
import java.sql.SQLException;

class Sybase11PortabilityLayer extends SybasePortabilityLayer {
	private static Sybase11PortabilityLayer instance;
	private static final TraceComponent tc = Tr.register(Sybase11PortabilityLayer.class);

	public void setTransactionIsolation(Connection connection, int isolationLevel) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setTransactionIsolation", new Object[]{connection, new Integer(isolationLevel)});
		}

		switch (isolationLevel) {
			case 1 :
				isolationLevel = 2;
				break;
			case 4 :
				isolationLevel = 8;
		}

		super.setTransactionIsolation(connection, isolationLevel);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setTransactionIsolation");
		}

	}

	public int getPreferredIsolationLevel() {
		return 2;
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new Sybase11PortabilityLayer();
		}

		return instance;
	}
}