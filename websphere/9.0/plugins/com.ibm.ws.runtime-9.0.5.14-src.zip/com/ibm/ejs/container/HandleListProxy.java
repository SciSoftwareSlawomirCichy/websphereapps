package com.ibm.ejs.container;

import com.ibm.ejs.j2c.HCMDetails;
import com.ibm.ejs.j2c.HandleList;
import com.ibm.ejs.j2c.HandleListInterface;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;

class HandleListProxy implements HandleListInterface {
	private static final String CLASS_NAME = HandleListProxy.class.getName();
	private static final TraceComponent tc;
	static final HandleListInterface INSTANCE;

	public String toString() {
		BeanO beanO = EJSContainer.getCallbackBeanO();
		return super.toString() + '[' + beanO.getHandleList(false) + ", " + beanO + ']';
	}

	private HandleList getHandleList(boolean create) {
		BeanO beanO = EJSContainer.getCallbackBeanO();
		return beanO.getHandleList(create);
	}

	public HandleList add(HCMDetails a) {
		HandleList hl = this.getHandleList(true);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "add: " + hl + ", " + Util.identity(a._handle));
		}

		hl.add(a);
		return hl;
	}

	public void remove(Object r) {
		HandleList hl = this.getHandleList(false);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "remove: " + hl + ", " + Util.identity(r));
		}

		if (hl != null) {
			hl.remove(r);
		}

	}

	public void reAssociate() throws Exception {
		HandleList hl = this.getHandleList(false);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "reAssociate: " + hl);
		}

		if (hl != null) {
			hl.reAssociate();
		}

	}

	public void parkHandle() throws Exception {
		HandleList hl = this.getHandleList(false);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "parkHandle: " + hl);
		}

		if (hl != null) {
			hl.parkHandle();
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		INSTANCE = new HandleListProxy();
	}
}