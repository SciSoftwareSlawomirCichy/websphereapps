package com.ibm.icu.text;

import com.ibm.icu.impl.ICUDebug;
import com.ibm.icu.impl.ICUResourceBundle;
import com.ibm.icu.text.Collator.CollatorFactory;
import com.ibm.icu.text.Collator.ServiceShim;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;
import com.ibm.icu.util.VersionInfo;
import com.ibm.icu.util.ULocale.Type;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Locale;
import java.util.MissingResourceException;

public abstract class Collator implements Comparator<Object>, Cloneable {
	public static final int PRIMARY = 0;
	public static final int SECONDARY = 1;
	public static final int TERTIARY = 2;
	public static final int QUATERNARY = 3;
	public static final int IDENTICAL = 15;
	public static final int FULL_DECOMPOSITION = 15;
	public static final int NO_DECOMPOSITION = 16;
	public static final int CANONICAL_DECOMPOSITION = 17;
	private static ServiceShim shim;
	private static final String[] KEYWORDS = new String[]{"collation"};
	private static final String RESOURCE = "collations";
	private static final String BASE = "com/ibm/icu/impl/data/icudt44b/coll";
	private int m_strength_ = 2;
	private int m_decomposition_ = 17;
	private static final boolean DEBUG = ICUDebug.enabled("collator");
	private ULocale validLocale;
	private ULocale actualLocale;

	public void setStrength(int newStrength) {
		if (newStrength != 0 && newStrength != 1 && newStrength != 2 && newStrength != 3 && newStrength != 15) {
			throw new IllegalArgumentException("Incorrect comparison level.");
		} else {
			this.m_strength_ = newStrength;
		}
	}

	public Collator setStrength2(int newStrength) {
		this.setStrength(newStrength);
		return this;
	}

	public void setDecomposition(int decomposition) {
		if (decomposition != 16 && decomposition != 17) {
			throw new IllegalArgumentException("Wrong decomposition mode.");
		} else {
			this.m_decomposition_ = decomposition;
		}
	}

	public static final Collator getInstance() {
		return getInstance(ULocale.getDefault());
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	private static ServiceShim getShim() {
		if (shim == null) {
			try {
				Class<?> cls = Class.forName("com.ibm.icu.text.CollatorServiceShim");
				shim = (ServiceShim) cls.newInstance();
			} catch (MissingResourceException var1) {
				throw var1;
			} catch (Exception var2) {
				if (DEBUG) {
					var2.printStackTrace();
				}

				throw new RuntimeException(var2.getMessage());
			}
		}

		return shim;
	}

	public static final Collator getInstance(ULocale locale) {
		return getShim().getInstance(locale);
	}

	public static final Collator getInstance(Locale locale) {
		return getInstance(ULocale.forLocale(locale));
	}

	public static final Object registerInstance(Collator collator, ULocale locale) {
		return getShim().registerInstance(collator, locale);
	}

	public static final Object registerFactory(CollatorFactory factory) {
		return getShim().registerFactory(factory);
	}

	public static final boolean unregister(Object registryKey) {
		return shim == null ? false : shim.unregister(registryKey);
	}

	public static Locale[] getAvailableLocales() {
		if (shim == null) {
			ClassLoader cl = Collator.class.getClassLoader();
			return ICUResourceBundle.getAvailableLocales("com/ibm/icu/impl/data/icudt44b/coll", cl);
		} else {
			return shim.getAvailableLocales();
		}
	}

	public static final ULocale[] getAvailableULocales() {
		if (shim == null) {
			ClassLoader cl = Collator.class.getClassLoader();
			return ICUResourceBundle.getAvailableULocales("com/ibm/icu/impl/data/icudt44b/coll", cl);
		} else {
			return shim.getAvailableULocales();
		}
	}

	public static final String[] getKeywords() {
		return KEYWORDS;
	}

	public static final String[] getKeywordValues(String keyword) {
		if (!keyword.equals(KEYWORDS[0])) {
			throw new IllegalArgumentException("Invalid keyword: " + keyword);
		} else {
			return ICUResourceBundle.getKeywordValues("com/ibm/icu/impl/data/icudt44b/coll", "collations");
		}
	}

	public static final String[] getKeywordValuesForLocale(String key, ULocale locale, boolean commonlyUsed) {
		String baseLoc = locale.getBaseName();
		LinkedList<String> values = new LinkedList();
		UResourceBundle bundle = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b/coll", baseLoc);

		String defcoll;
		for (defcoll = null; bundle != null; bundle = ((ICUResourceBundle) bundle).getParent()) {
			UResourceBundle collations = bundle.get("collations");
			Enumeration collEnum = collations.getKeys();

			while (collEnum.hasMoreElements()) {
				String collkey = (String) collEnum.nextElement();
				if (collkey.equals("default")) {
					if (defcoll == null) {
						defcoll = collations.getString("default");
					}
				} else if (!values.contains(collkey)) {
					values.add(collkey);
				}
			}
		}

		Iterator<String> itr = values.iterator();
		String[] result = new String[values.size()];
		result[0] = defcoll;
		int var13 = 1;

		while (itr.hasNext()) {
			String collKey = (String) itr.next();
			if (!collKey.equals(defcoll)) {
				result[var13++] = collKey;
			}
		}

		return result;
	}

	public static final ULocale getFunctionalEquivalent(String keyword, ULocale locID, boolean[] isAvailable) {
		ClassLoader cl = Collator.class.getClassLoader();
		return ICUResourceBundle.getFunctionalEquivalent("com/ibm/icu/impl/data/icudt44b/coll", cl, "collations",
				keyword, locID, isAvailable, true);
	}

	public static final ULocale getFunctionalEquivalent(String keyword, ULocale locID) {
		return getFunctionalEquivalent(keyword, locID, (boolean[]) null);
	}

	public static String getDisplayName(Locale objectLocale, Locale displayLocale) {
		return getShim().getDisplayName(ULocale.forLocale(objectLocale), ULocale.forLocale(displayLocale));
	}

	public static String getDisplayName(ULocale objectLocale, ULocale displayLocale) {
		return getShim().getDisplayName(objectLocale, displayLocale);
	}

	public static String getDisplayName(Locale objectLocale) {
		return getShim().getDisplayName(ULocale.forLocale(objectLocale), ULocale.getDefault());
	}

	public static String getDisplayName(ULocale objectLocale) {
		return getShim().getDisplayName(objectLocale, ULocale.getDefault());
	}

	public int getStrength() {
		return this.m_strength_;
	}

	public int getDecomposition() {
		return this.m_decomposition_;
	}

	public boolean equals(String source, String target) {
		return this.compare(source, target) == 0;
	}

	public UnicodeSet getTailoredSet() {
		return new UnicodeSet(0, 1114111);
	}

	public abstract int compare(String var1, String var2);

	public int compare(Object source, Object target) {
		return this.compare((String) source, (String) target);
	}

	public abstract CollationKey getCollationKey(String var1);

	public abstract RawCollationKey getRawCollationKey(String var1, RawCollationKey var2);

	public abstract int setVariableTop(String var1);

	public abstract int getVariableTop();

	public abstract void setVariableTop(int var1);

	public abstract VersionInfo getVersion();

	public abstract VersionInfo getUCAVersion();

	public final ULocale getLocale(Type type) {
		return type == ULocale.ACTUAL_LOCALE ? this.actualLocale : this.validLocale;
	}

	final void setLocale(ULocale valid, ULocale actual) {
		if (valid == null != (actual == null)) {
			throw new IllegalArgumentException();
		} else {
			this.validLocale = valid;
			this.actualLocale = actual;
		}
	}
}