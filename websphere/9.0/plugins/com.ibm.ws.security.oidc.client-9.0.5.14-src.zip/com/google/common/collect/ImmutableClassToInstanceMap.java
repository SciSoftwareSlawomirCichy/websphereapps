package com.google.common.collect;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableClassToInstanceMap.Builder;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.Serializable;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtIncompatible
public final class ImmutableClassToInstanceMap<B> extends ForwardingMap<Class<? extends B>, B>
		implements
			ClassToInstanceMap<B>,
			Serializable {
	private static final ImmutableClassToInstanceMap<Object> EMPTY = new ImmutableClassToInstanceMap(ImmutableMap.of());
	private final ImmutableMap<Class<? extends B>, B> delegate;

	public static <B> ImmutableClassToInstanceMap<B> of() {
		return EMPTY;
	}

	public static <B, T extends B> ImmutableClassToInstanceMap<B> of(Class<T> type, T value) {
		ImmutableMap<Class<? extends B>, B> map = ImmutableMap.of(type, value);
		return new ImmutableClassToInstanceMap(map);
	}

	public static <B> Builder<B> builder() {
		return new Builder();
	}

	public static <B, S extends B> ImmutableClassToInstanceMap<B> copyOf(
			Map<? extends Class<? extends S>, ? extends S> map) {
		if (map instanceof ImmutableClassToInstanceMap) {
			ImmutableClassToInstanceMap<B> cast = (ImmutableClassToInstanceMap) map;
			return cast;
		} else {
			return (new Builder()).putAll(map).build();
		}
	}

	private ImmutableClassToInstanceMap(ImmutableMap<Class<? extends B>, B> delegate) {
		this.delegate = delegate;
	}

	protected Map<Class<? extends B>, B> delegate() {
		return this.delegate;
	}

	@NullableDecl
	public <T extends B> T getInstance(Class<T> type) {
		return this.delegate.get(Preconditions.checkNotNull(type));
	}

	@Deprecated
	@CanIgnoreReturnValue
	public <T extends B> T putInstance(Class<T> type, T value) {
		throw new UnsupportedOperationException();
	}

	Object readResolve() {
		return this.isEmpty() ? of() : this;
	}
}