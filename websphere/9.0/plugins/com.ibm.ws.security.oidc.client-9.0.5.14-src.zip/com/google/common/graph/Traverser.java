package com.google.common.graph;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.google.common.graph.Traverser.1;
import com.google.common.graph.Traverser.TreeTraverser.2;
import com.google.common.graph.Traverser.TreeTraverser.3;
import java.util.Iterator;

@Beta
public abstract class Traverser<N> {
	public static <N> Traverser<N> forGraph(SuccessorsFunction<N> graph) {
		Preconditions.checkNotNull(graph);
		return new Traverser.GraphTraverser(graph);
	}

	public static <N> Traverser<N> forTree(SuccessorsFunction<N> tree) {
		Preconditions.checkNotNull(tree);
		if (tree instanceof BaseGraph) {
			Preconditions.checkArgument(((BaseGraph) tree).isDirected(), "Undirected graphs can never be trees.");
		}

		if (tree instanceof Network) {
			Preconditions.checkArgument(((Network) tree).isDirected(), "Undirected networks can never be trees.");
		}

		return new Traverser.TreeTraverser(tree);
	}

	public abstract Iterable<N> breadthFirst(N var1);

	public abstract Iterable<N> breadthFirst(Iterable<? extends N> var1);

	public abstract Iterable<N> depthFirstPreOrder(N var1);

	public abstract Iterable<N> depthFirstPreOrder(Iterable<? extends N> var1);

	public abstract Iterable<N> depthFirstPostOrder(N var1);

	public abstract Iterable<N> depthFirstPostOrder(Iterable<? extends N> var1);

	private Traverser() {
	}

	private static final class TreeTraverser<N> extends Traverser<N> {
		private final SuccessorsFunction<N> tree;

		TreeTraverser(SuccessorsFunction<N> tree) {
         super((1)null);
         this.tree = (SuccessorsFunction)Preconditions.checkNotNull(tree);
      }

		public Iterable<N> breadthFirst(N startNode) {
			Preconditions.checkNotNull(startNode);
			return this.breadthFirst((Iterable) ImmutableSet.of(startNode));
		}

		public Iterable<N> breadthFirst(Iterable<? extends N> startNodes) {
         Preconditions.checkNotNull(startNodes);
         if (Iterables.isEmpty(startNodes)) {
            return ImmutableSet.of();
         } else {
            Iterator var2 = startNodes.iterator();

            while(var2.hasNext()) {
               N startNode = var2.next();
               this.checkThatNodeIsInTree(startNode);
            }

            return new com.google.common.graph.Traverser.TreeTraverser.1(this, startNodes);
         }
      }

		public Iterable<N> depthFirstPreOrder(N startNode) {
			Preconditions.checkNotNull(startNode);
			return this.depthFirstPreOrder((Iterable) ImmutableSet.of(startNode));
		}

		public Iterable<N> depthFirstPreOrder(Iterable<? extends N> startNodes) {
         Preconditions.checkNotNull(startNodes);
         if (Iterables.isEmpty(startNodes)) {
            return ImmutableSet.of();
         } else {
            Iterator var2 = startNodes.iterator();

            while(var2.hasNext()) {
               N node = var2.next();
               this.checkThatNodeIsInTree(node);
            }

            return new 2(this, startNodes);
         }
      }

		public Iterable<N> depthFirstPostOrder(N startNode) {
			Preconditions.checkNotNull(startNode);
			return this.depthFirstPostOrder((Iterable) ImmutableSet.of(startNode));
		}

		public Iterable<N> depthFirstPostOrder(Iterable<? extends N> startNodes) {
         Preconditions.checkNotNull(startNodes);
         if (Iterables.isEmpty(startNodes)) {
            return ImmutableSet.of();
         } else {
            Iterator var2 = startNodes.iterator();

            while(var2.hasNext()) {
               N startNode = var2.next();
               this.checkThatNodeIsInTree(startNode);
            }

            return new 3(this, startNodes);
         }
      }

		private void checkThatNodeIsInTree(N startNode) {
			this.tree.successors(startNode);
		}
	}

	private static final class GraphTraverser<N> extends Traverser<N> {
		private final SuccessorsFunction<N> graph;

		GraphTraverser(SuccessorsFunction<N> graph) {
         super((1)null);
         this.graph = (SuccessorsFunction)Preconditions.checkNotNull(graph);
      }

		public Iterable<N> breadthFirst(N startNode) {
			Preconditions.checkNotNull(startNode);
			return this.breadthFirst((Iterable) ImmutableSet.of(startNode));
		}

		public Iterable<N> breadthFirst(Iterable<? extends N> startNodes) {
         Preconditions.checkNotNull(startNodes);
         if (Iterables.isEmpty(startNodes)) {
            return ImmutableSet.of();
         } else {
            Iterator var2 = startNodes.iterator();

            while(var2.hasNext()) {
               N startNode = var2.next();
               this.checkThatNodeIsInGraph(startNode);
            }

            return new com.google.common.graph.Traverser.GraphTraverser.1(this, startNodes);
         }
      }

		public Iterable<N> depthFirstPreOrder(N startNode) {
			Preconditions.checkNotNull(startNode);
			return this.depthFirstPreOrder((Iterable) ImmutableSet.of(startNode));
		}

		public Iterable<N> depthFirstPreOrder(Iterable<? extends N> startNodes) {
         Preconditions.checkNotNull(startNodes);
         if (Iterables.isEmpty(startNodes)) {
            return ImmutableSet.of();
         } else {
            Iterator var2 = startNodes.iterator();

            while(var2.hasNext()) {
               N startNode = var2.next();
               this.checkThatNodeIsInGraph(startNode);
            }

            return new com.google.common.graph.Traverser.GraphTraverser.2(this, startNodes);
         }
      }

		public Iterable<N> depthFirstPostOrder(N startNode) {
			Preconditions.checkNotNull(startNode);
			return this.depthFirstPostOrder((Iterable) ImmutableSet.of(startNode));
		}

		public Iterable<N> depthFirstPostOrder(Iterable<? extends N> startNodes) {
         Preconditions.checkNotNull(startNodes);
         if (Iterables.isEmpty(startNodes)) {
            return ImmutableSet.of();
         } else {
            Iterator var2 = startNodes.iterator();

            while(var2.hasNext()) {
               N startNode = var2.next();
               this.checkThatNodeIsInGraph(startNode);
            }

            return new com.google.common.graph.Traverser.GraphTraverser.3(this, startNodes);
         }
      }

		private void checkThatNodeIsInGraph(N startNode) {
			this.graph.successors(startNode);
		}
	}
}