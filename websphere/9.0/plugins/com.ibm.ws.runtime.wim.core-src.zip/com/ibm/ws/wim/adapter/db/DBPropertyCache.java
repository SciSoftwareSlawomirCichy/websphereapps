package com.ibm.ws.wim.adapter.db;

import com.ibm.websphere.wim.exception.InvalidPropertyDefinitionException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.adapter.db.DBPropertyCache.1CompositeProperty;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.DataAccessObject;
import com.ibm.ws.wim.dao.QuerySet;
import com.ibm.ws.wim.dao.schema.DBRepositoryProperty;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBPropertyCache {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = DBPropertyCache.class.getName();
	private static final Logger trcLogger;
	protected Hashtable cache = null;
	private Set memberRefPropertyNames = new HashSet();
	private Set supportedPropertyTypes = new HashSet();
	private Hashtable supportedPropertiesForEntity = null;
	private Hashtable mandatoryPropertiesForEntity = new Hashtable();
	private Set multivaluePropertyIds = new HashSet();
	private Map compositeProperties = new HashMap();
	private Map requiredComponentProperties = new HashMap();
	private Set supportedEntityTypes = new HashSet();
	private Set multivaluedProperty = new HashSet();
	private DataAccessObject dao;
	private int bufferSize = 254;

	public DBPropertyCache(DataAccessObject var1) throws WIMException {
		this.init(var1);
	}

	private synchronized void init(DataAccessObject var1) throws WIMException {
      if (trcLogger.isLoggable(Level.FINER)) {
         trcLogger.entering(CLASSNAME, "init");
      }

      PreparedStatement var3 = null;
      PreparedStatement var4 = null;
      PreparedStatement var5 = null;
      Object var6 = null;
      ResultSet var7 = null;
      Connection var8 = null;
      this.dao = var1;
      this.cache = new Hashtable();
      this.mandatoryPropertiesForEntity = new Hashtable();
      this.supportedPropertiesForEntity = new Hashtable();
      HashSet var9 = null;
      HashSet var10 = null;
      HashSet var11 = null;
      this.memberRefPropertyNames = new HashSet();

      try {
         var8 = this.dao.getConnection();
         QuerySet var12 = this.dao.getQuerySet();
         var3 = var8.prepareStatement(var12.findDBAllProperties);
         var7 = var3.executeQuery();
         DBRepositoryProperty var13 = null;
         String var14 = null;
         String var15 = var12.findDBAllCompositeProperties;
         boolean var16 = true;
         boolean var17 = true;
         int var18 = -1;

         label492:
         while(true) {
            String var20;
            HashSet var21;
            int var65;
            int var67;
            if (!var7.next()) {
               if (var13 != null) {
                  var13.setApplicableEntityTypes(var9);
                  var13.setRequiredEntityTypes(var10);
                  if (DAOHelper.isPropInCommonSchema(var14, var9)) {
                     this.cache.put(var14, var13);
                  }
               }

               Iterator var55;
               String var63;
               if (var11 != null && var11.size() > 0) {
                  var15 = var15 + " ) ";
                  var15 = var15 + var12.findDBAllCompositePropertiesOrderBy;
                  var7.close();
                  var4 = var8.prepareStatement(var15, 1003, 1007);
                  var7 = var4.executeQuery();
                  var55 = var11.iterator();
                  var20 = null;
                  var21 = null;

                  while(var7.next()) {
                     long var59 = var7.getLong(1);
                     var63 = var7.getString(2);
                     var65 = var7.getInt(3);
                     var67 = var7.getInt(4);
                     String var69 = var7.getString(5);
                     String var70 = var7.getString(6);
                     Set var71 = (Set)this.compositeProperties.get(var70);
                     var71.add(var69);
                     this.compositeProperties.put(var70, var71);
                     DBRepositoryProperty var73 = (DBRepositoryProperty)this.cache.get(var70);
                     var73.setComponentPropertyNames(var71);
                     this.cache.put(var70, var73);
                     if (var65 == 1) {
                        Set var74 = (Set)this.requiredComponentProperties.get(var70);
                        var74.add(var69);
                        this.requiredComponentProperties.put(var70, var74);
                     }
                  }
               }

               var55 = this.supportedEntityTypes.iterator();

               while(var55.hasNext()) {
                  Set var56 = (Set)this.supportedPropertiesForEntity.get(var55.next());
                  Map var60 = this.getCompositeProperties();
                  if (var60 != null) {
                     Set var61 = var60.keySet();
                     Iterator var64 = var61.iterator();

                     while(var64.hasNext()) {
                        var63 = (String)var64.next();
                        if (var56 != null && var56.contains(var63)) {
                           Set var66 = (Set)this.compositeProperties.get(var63);
                           var56.removeAll(var66);
                        }
                     }
                  }
               }

               try {
                  var7.close();
               } catch (Exception var49) {
                  ;
               }

               var5 = var8.prepareStatement(var12.getAllSupportedPropertyTypes);
               var7 = var5.executeQuery();

               while(true) {
                  if (!var7.next()) {
                     break label492;
                  }

                  this.supportedPropertyTypes.add(var7.getString(1).trim());
               }
            }

            int var19 = var7.getInt(1);
            var20 = var7.getString(13);
            if (var17 || var18 != var19) {
               if (!var17) {
                  if (var10 != null) {
                     var13.setRequiredEntityTypes(var10);
                  }

                  if (var9 != null) {
                     var13.setApplicableEntityTypes(var9);
                     if (DAOHelper.isPropInCommonSchema(var14, var9)) {
                        this.cache.put(var14, var13);
                        if (trcLogger.isLoggable(Level.FINER)) {
                           trcLogger.logp(Level.FINER, CLASSNAME, "init", "Property: " + var14 + " has been added into DB cache");
                        }
                     }
                  }
               } else {
                  var17 = false;
               }

               var14 = var7.getString(2);
               var21 = new HashSet();
               var21.add(var20);
               if (!DAOHelper.isPropInCommonSchema(var14, var21)) {
                  continue;
               }

               var13 = new DBRepositoryProperty();
               var13.setPropId(new Integer(var19));
               var13.setName(var14);
               String var22 = var7.getString(3).trim();
               var13.setDataType(var22);
               if (var22.equals("IDENTIFIER")) {
                  this.memberRefPropertyNames.add(var14);
               }

               String var23 = var7.getString(4);
               var13.setMetadataName(var23);
               int var24 = var7.getInt(5);
               var13.setComposite(var24 != 0);
               if (var13.isComposite()) {
                  HashSet var25 = new HashSet();
                  HashSet var26 = new HashSet();
                  this.compositeProperties.put(var14, var25);
                  this.requiredComponentProperties.put(var14, var26);
                  1CompositeProperty var27 = new 1CompositeProperty(this);
                  var27.compositePropertyId = var19;
                  var27.compositePropertyName = var14;
                  if (var11 == null) {
                     var11 = new HashSet();
                  }

                  var11.add(var27);
                  if (var16) {
                     var16 = false;
                  } else {
                     var15 = var15.concat(",");
                  }

                  var15 = var15.concat((new Integer(var19)).toString());
               }

               var65 = var7.getInt(6);
               var13.setValueLength(var65);
               var67 = var7.getInt(7);
               var13.setReadOnly(var67 != 0);
               int var68 = var7.getInt(8);
               var13.setMultipleValued(var68 != 0);
               if (var68 == 1) {
                  this.multivaluedProperty.add(var14);
                  this.multivaluePropertyIds.add(new Integer(var19));
               }

               int var28 = var7.getInt(9);
               var13.setCaseSensitive(var28 != 0);
               String var29;
               if (var22.equalsIgnoreCase("OBJECT")) {
                  if (var24 == 0) {
                     var29 = var7.getString(10);
                     var13.setClassName(var29);

                     Object[] var31;
                     try {
                        Class var30 = Class.forName(var29);
                        if (!Serializable.class.isAssignableFrom(var30)) {
                           var31 = new Object[]{var14};
                           throw new InvalidPropertyDefinitionException("INVALID_PROPERTY_DATA_TYPE", var31, CLASSNAME, "init");
                        }

                        var13.setClassName(var29);
                     } catch (ClassCastException var50) {
                        var31 = new Object[]{var14};
                        throw new InvalidPropertyDefinitionException("INVALID_PROPERTY_DATA_TYPE", var31, CLASSNAME, "init", var50);
                     } catch (ClassNotFoundException var51) {
                        var31 = new Object[]{var14};
                        throw new InvalidPropertyDefinitionException("INVALID_PROPERTY_DATA_TYPE", var31, CLASSNAME, "init", var51);
                     }

                     this.supportedPropertyTypes.add(var29);
                  }
               } else {
                  this.supportedPropertyTypes.add(var22);
               }

               var29 = var7.getString(11);
               var13.setDescription(var29);
               String var72 = var7.getString(12);
               var13.setApplicationId(var72);
               var18 = var19;
               var9 = new HashSet();
               var10 = new HashSet();
            }

            var9.add(var20);
            this.supportedEntityTypes.add(var20);
            Object var57 = (Set)this.supportedPropertiesForEntity.get(var20);
            if (var57 == null) {
               var57 = new HashSet();
            }

            ((Set)var57).add(var14);
            this.supportedPropertiesForEntity.put(var20, var57);
            int var58 = var7.getInt(14);
            if (var58 != 0) {
               var10.add(var20);
               Object var62 = (Set)this.mandatoryPropertiesForEntity.get(var20);
               if (var62 == null) {
                  var62 = new HashSet();
               }

               ((Set)var62).add(var14);
               this.mandatoryPropertiesForEntity.put(var20, var62);
            }
         }
      } catch (SQLException var52) {
         throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var52.getMessage()), CLASSNAME, "init", var52);
      } catch (Exception var53) {
         throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var53.getMessage()), CLASSNAME, "init", var53);
      } finally {
         try {
            if (var7 != null) {
               var7.close();
            }
         } catch (Exception var48) {
            ;
         }

         try {
            if (var3 != null) {
               var3.close();
            }

            if (var4 != null) {
               var4.close();
            }

            if (var5 != null) {
               var5.close();
            }

            if (var6 != null) {
               ((PreparedStatement)var6).close();
            }
         } catch (Exception var47) {
            ;
         }

         try {
            if (var8 != null) {
               this.dao.closeConnection(var8);
            }
         } catch (Exception var46) {
            ;
         }

      }

      if (trcLogger.isLoggable(Level.FINER)) {
         trcLogger.exiting(CLASSNAME, "init");
      }

   }

	public Set getMandatoryAttributes(String var1) {
		return (Set) this.mandatoryPropertiesForEntity.get(var1);
	}

	public Set getSupportedAttributes(String var1) {
		return (Set) this.supportedPropertiesForEntity.get(var1);
	}

	public DBRepositoryProperty getPropertyDefinition(String var1) {
		return (DBRepositoryProperty) this.cache.get(var1);
	}

	public boolean isCompositeProperty(String var1) {
		return this.compositeProperties.containsKey(var1);
	}

	public boolean isMultivaluedProperty(String var1) {
		return this.multivaluedProperty.contains(var1);
	}

	public Set getMultiValuePropertyIds() {
		return this.multivaluePropertyIds;
	}

	public Map getCompositeProperties() {
		return this.compositeProperties;
	}

	public Set getRequiredComponentProperties(String var1) {
		return (Set) this.requiredComponentProperties.get(var1);
	}

	public Set getSupportedPropertyTypes() {
		return this.supportedPropertyTypes;
	}

	public void updatePropertyCache(DBRepositoryProperty var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updatePropertyCache(DBRepositoryProperty prop)");
		}

		this.cache.put(var1.getName(), var1);
		Set var3 = var1.getRequiredEntityTypes();
		if (var3 != null && var3.size() > 0) {
			Iterator var4 = var3.iterator();

			while (var4.hasNext()) {
				String var5 = (String) var4.next();
				Object var6 = (Set) this.mandatoryPropertiesForEntity.get(var5);
				if (var6 == null) {
					var6 = new HashSet();
				}

				((Set) var6).add(var1.getName());
				this.mandatoryPropertiesForEntity.put(var5, var6);
			}
		}

		if (var1.getDataType().equals("IDENTIFIER")) {
			this.memberRefPropertyNames.add(var1.getName());
		}

		if (var1.isMultipleValued()) {
			this.multivaluedProperty.add(var1.getName());
			this.multivaluePropertyIds.add(var1.getPropId());
		}

		Set var8 = var1.getApplicableEntityTypes();
		Iterator var9 = var8.iterator();

		String var10;
		while (var9.hasNext()) {
			var10 = (String) var9.next();
			this.supportedEntityTypes.add(var10);
			Object var7 = (Set) this.supportedPropertiesForEntity.get(var10);
			if (var7 == null) {
				var7 = new HashSet();
			}

			((Set) var7).add(var1.getName());
			this.supportedPropertiesForEntity.put(var10, var7);
		}

		if (var1.getDataType().equals("OBJECT")) {
			var10 = var1.getClassName();
			this.supportedPropertyTypes.add(var10);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updatePropertyCache(DBRepositoryProperty prop)");
		}

	}

	public void updatePropertyEntityRelationCache(String var1, String var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updatePropertyEntityRelationCache(String newEntName, String parentEntName)");
		}

		this.supportedEntityTypes.add(var1);
		Set var4 = (Set) this.supportedPropertiesForEntity.get(var2);
		HashSet var5 = null;
		if (var4 != null) {
			var5 = new HashSet();
			Iterator var6 = var4.iterator();

			while (var6.hasNext()) {
				var5.add(var6.next());
			}
		}

		this.supportedPropertiesForEntity.put(var1, var5);
		Set var14 = (Set) this.mandatoryPropertiesForEntity.get(var2);
		HashSet var7 = new HashSet();
		Iterator var8;
		if (var14 != null) {
			var8 = var14.iterator();

			while (var8.hasNext()) {
				var7.add(var8.next());
			}
		}

		this.mandatoryPropertiesForEntity.put(var1, var7);
		var8 = var4.iterator();

		while (var8.hasNext()) {
			String var9 = (String) var8.next();
			DBRepositoryProperty var10 = this.getPropertyDefinition(var9);
			Set var11 = var10.getApplicableEntityTypes();
			var11.add(var1);
			var10.setApplicableEntityTypes(var11);
			Set var12 = (Set) this.mandatoryPropertiesForEntity.get(var1);
			if (var12 != null && var12.contains(var9)) {
				Object var13 = var10.getRequiredEntityTypes();
				if (var13 == null) {
					var13 = new HashSet();
				}

				((Set) var13).add(var1);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updatePropertyEntityRelationCache(String newEntName, String parentEntName)");
		}

	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}