package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.am.Alarm;
import com.ibm.ejs.util.am.AlarmListener;
import com.ibm.ejs.util.am.AlarmManager;
import java.util.Iterator;
import java.util.LinkedHashSet;

public final class RemoteAsyncResultReaper implements AlarmListener {
	private static final String CLASS_NAME = RemoteAsyncResultReaper.class.getName();
	private static final TraceComponent tc;
	private static final int NEAR_MAX_RESULTS_THRESHOLD;
	private static final int SAFE_THRESHOLD;
	private LinkedHashSet<RemoteAsyncResultImpl> ivAllRemoteAsyncResults;
	private long ivFutureObjectTimeout;
	private boolean ivWarnedNearMax;
	private boolean ivWarnedExceededMax;
	private static final long MINIMUM_ALARM_INTERVAL = 30000L;
	private long ivAlarmInterval;
	private boolean ivIsCanceled = false;
	private Alarm ivAlarm;

	public RemoteAsyncResultReaper(long timeout) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.ivAllRemoteAsyncResults = new LinkedHashSet();
		this.ivFutureObjectTimeout = timeout;
		this.ivAlarmInterval = Math.max(30000L, this.ivFutureObjectTimeout);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init> : timeout = " + this.ivFutureObjectTimeout + " ms");
		}

	}

	public synchronized void alarm(Object alarmContext) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "alarm: size=" + this.ivAllRemoteAsyncResults.size());
		}

		if (!this.ivIsCanceled) {
			this.ivAlarm = null;
			int numRemoved = 0;
			if (!this.ivAllRemoteAsyncResults.isEmpty()) {
				long currentTime = System.currentTimeMillis();

				for (Iterator iterator = this.ivAllRemoteAsyncResults.iterator(); iterator.hasNext(); ++numRemoved) {
					RemoteAsyncResultImpl asyncResult = (RemoteAsyncResultImpl) iterator.next();
					long staleDuration = currentTime - asyncResult.getTimeoutStartTime();
					if (staleDuration < this.ivFutureObjectTimeout) {
						long alarmTime = Math.max(this.ivFutureObjectTimeout - staleDuration, 30000L);
						this.ivAlarm = AlarmManager.createDeferrable(alarmTime, this, (Object) null);
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "next " + asyncResult + "; alarm=" + alarmTime);
						}
						break;
					}

					this.releaseResources(asyncResult);
					iterator.remove();
				}

				if (this.ivWarnedNearMax) {
					int size = this.ivAllRemoteAsyncResults.size();
					this.ivWarnedNearMax &= size >= SAFE_THRESHOLD;
					this.ivWarnedExceededMax &= size >= NEAR_MAX_RESULTS_THRESHOLD;
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "alarm: size=" + this.ivAllRemoteAsyncResults.size() + ", removed=" + numRemoved);
			}

		}
	}

	public synchronized void finalReap() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "finalReap : Remote Async Results = " + this.ivAllRemoteAsyncResults.size());
		}

		if (this.ivAlarm != null) {
			this.ivIsCanceled = true;
			this.ivAlarm.cancel();
			this.ivAlarm = null;
		}

		Iterator iterator = this.ivAllRemoteAsyncResults.iterator();

		while (iterator.hasNext()) {
			RemoteAsyncResultImpl asyncResult = (RemoteAsyncResultImpl) iterator.next();
			this.releaseResources(asyncResult);
			iterator.remove();
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "finalReap : Remote Async Results = " + this.ivAllRemoteAsyncResults.size());
		}

	}

	public synchronized void add(RemoteAsyncResultImpl asyncResult) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		this.ivAllRemoteAsyncResults.add(asyncResult);
		if (asyncResult.ivPmiBean != null) {
			asyncResult.ivPmiBean.asyncFutureObjectIncrement();
		}

		int size = this.ivAllRemoteAsyncResults.size();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.debug(tc, "add " + asyncResult + "; size=" + size);
		}

		if (size == 1) {
			this.ivAlarm = AlarmManager.createDeferrable(this.ivAlarmInterval, this, (Object) null);
		} else if (size >= NEAR_MAX_RESULTS_THRESHOLD) {
			boolean warn = false;
			if (size > ContainerProperties.MaxUnclaimedAsyncResults) {
				if (!this.ivWarnedExceededMax) {
					warn = this.ivWarnedExceededMax = true;
				}

				Iterator<RemoteAsyncResultImpl> iterator = this.ivAllRemoteAsyncResults.iterator();
				RemoteAsyncResultImpl oldest = (RemoteAsyncResultImpl) iterator.next();
				this.releaseResources(oldest);
				iterator.remove();
			} else if (!this.ivWarnedNearMax) {
				warn = this.ivWarnedNearMax = true;
			}

			if (warn) {
				Tr.warning(tc, "MAXIMUM_UNCLAIMED_ASYNC_RESULTS_CNTR0328W",
						new Object[]{size, ContainerProperties.MaxUnclaimedAsyncResults});
			}
		}

	}

	public synchronized void remove(RemoteAsyncResultImpl asyncResult) {
		this.ivAllRemoteAsyncResults.remove(asyncResult);
		this.releaseResources(asyncResult);
		if (this.ivAllRemoteAsyncResults.isEmpty() && this.ivAlarm != null) {
			this.ivAlarm.cancel();
			this.ivAlarm = null;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.debug(tc, "remove " + asyncResult + "; size=" + this.ivAllRemoteAsyncResults.size());
		}

	}

	private void releaseResources(RemoteAsyncResultImpl asyncResult) {
		asyncResult.unexportResources();
		if (asyncResult.ivPmiBean != null) {
			asyncResult.ivPmiBean.asyncFutureObjectDecrement();
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		NEAR_MAX_RESULTS_THRESHOLD = ContainerProperties.MaxUnclaimedAsyncResults <= 0
				? Integer.MAX_VALUE
				: ContainerProperties.MaxUnclaimedAsyncResults / 2 + ContainerProperties.MaxUnclaimedAsyncResults / 4;
		SAFE_THRESHOLD = ContainerProperties.MaxUnclaimedAsyncResults / 2;
	}
}