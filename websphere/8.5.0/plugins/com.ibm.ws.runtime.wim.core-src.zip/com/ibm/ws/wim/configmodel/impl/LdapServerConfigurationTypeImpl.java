package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class LdapServerConfigurationTypeImpl extends EDataObjectImpl implements LdapServerConfigurationType {
	protected EList ldapServers = null;
	protected static final boolean ALLOW_WRITE_TO_SECONDARY_SERVERS_EDEFAULT = false;
	protected boolean allowWriteToSecondaryServers = false;
	protected boolean allowWriteToSecondaryServersESet = false;
	protected static final int ATTRIBUTE_RANGE_STEP_EDEFAULT = 0;
	protected int attributeRangeStep = 0;
	protected boolean attributeRangeStepESet = false;
	protected static final int PRIMARY_SERVER_QUERY_TIME_INTERVAL_EDEFAULT = 15;
	protected int primaryServerQueryTimeInterval = 15;
	protected boolean primaryServerQueryTimeIntervalESet = false;
	protected static final boolean RETURN_TO_PRIMARY_SERVER_EDEFAULT = true;
	protected boolean returnToPrimaryServer = true;
	protected boolean returnToPrimaryServerESet = false;
	protected static final int SEARCH_COUNT_LIMIT_EDEFAULT = 0;
	protected int searchCountLimit = 0;
	protected boolean searchCountLimitESet = false;
	protected static final int SEARCH_PAGE_SIZE_EDEFAULT = 0;
	protected int searchPageSize = 0;
	protected boolean searchPageSizeESet = false;
	protected static final int SEARCH_TIME_LIMIT_EDEFAULT = 0;
	protected int searchTimeLimit = 0;
	protected boolean searchTimeLimitESet = false;
	protected static final String SSL_CONFIGURATION_EDEFAULT = null;
	protected String sslConfiguration;
	protected static final String SSL_KEY_STORE_EDEFAULT = null;
	protected String sslKeyStore;
	protected static final String SSL_KEY_STORE_PASSWORD_EDEFAULT = null;
	protected String sslKeyStorePassword;
	protected static final String SSL_KEY_STORE_TYPE_EDEFAULT = null;
	protected String sslKeyStoreType;
	protected static final String SSL_TRUST_STORE_EDEFAULT = null;
	protected String sslTrustStore;
	protected static final String SSL_TRUST_STORE_PASSWORD_EDEFAULT = null;
	protected String sslTrustStorePassword;
	protected static final String SSL_TRUST_STORE_TYPE_EDEFAULT = null;
	protected String sslTrustStoreType;

	protected LdapServerConfigurationTypeImpl() {
		this.sslConfiguration = SSL_CONFIGURATION_EDEFAULT;
		this.sslKeyStore = SSL_KEY_STORE_EDEFAULT;
		this.sslKeyStorePassword = SSL_KEY_STORE_PASSWORD_EDEFAULT;
		this.sslKeyStoreType = SSL_KEY_STORE_TYPE_EDEFAULT;
		this.sslTrustStore = SSL_TRUST_STORE_EDEFAULT;
		this.sslTrustStorePassword = SSL_TRUST_STORE_PASSWORD_EDEFAULT;
		this.sslTrustStoreType = SSL_TRUST_STORE_TYPE_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getLdapServerConfigurationType();
	}

	public LdapServersType[] getLdapServersAsArray() {
		List var1 = this.getLdapServers();
		return (LdapServersType[]) ((LdapServersType[]) var1.toArray(new LdapServersType[var1.size()]));
	}

	public List getLdapServers() {
		if (this.ldapServers == null) {
			this.ldapServers = new EObjectContainmentEList(LdapServersType.class, this, 0);
		}

		return this.ldapServers;
	}

	public LdapServersType createLdapServers() {
		LdapServersType var1 = ConfigmodelFactory.eINSTANCE.createLdapServersType();
		this.getLdapServers().add(var1);
		return var1;
	}

	public boolean isAllowWriteToSecondaryServers() {
		return this.allowWriteToSecondaryServers;
	}

	public void setAllowWriteToSecondaryServers(boolean var1) {
		boolean var2 = this.allowWriteToSecondaryServers;
		this.allowWriteToSecondaryServers = var1;
		boolean var3 = this.allowWriteToSecondaryServersESet;
		this.allowWriteToSecondaryServersESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.allowWriteToSecondaryServers, !var3));
		}

	}

	public void unsetAllowWriteToSecondaryServers() {
		boolean var1 = this.allowWriteToSecondaryServers;
		boolean var2 = this.allowWriteToSecondaryServersESet;
		this.allowWriteToSecondaryServers = false;
		this.allowWriteToSecondaryServersESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 1, var1, false, var2));
		}

	}

	public boolean isSetAllowWriteToSecondaryServers() {
		return this.allowWriteToSecondaryServersESet;
	}

	public int getAttributeRangeStep() {
		return this.attributeRangeStep;
	}

	public void setAttributeRangeStep(int var1) {
		int var2 = this.attributeRangeStep;
		this.attributeRangeStep = var1;
		boolean var3 = this.attributeRangeStepESet;
		this.attributeRangeStepESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.attributeRangeStep, !var3));
		}

	}

	public void unsetAttributeRangeStep() {
		int var1 = this.attributeRangeStep;
		boolean var2 = this.attributeRangeStepESet;
		this.attributeRangeStep = 0;
		this.attributeRangeStepESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 2, var1, 0, var2));
		}

	}

	public boolean isSetAttributeRangeStep() {
		return this.attributeRangeStepESet;
	}

	public int getPrimaryServerQueryTimeInterval() {
		return this.primaryServerQueryTimeInterval;
	}

	public void setPrimaryServerQueryTimeInterval(int var1) {
		int var2 = this.primaryServerQueryTimeInterval;
		this.primaryServerQueryTimeInterval = var1;
		boolean var3 = this.primaryServerQueryTimeIntervalESet;
		this.primaryServerQueryTimeIntervalESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.primaryServerQueryTimeInterval, !var3));
		}

	}

	public void unsetPrimaryServerQueryTimeInterval() {
		int var1 = this.primaryServerQueryTimeInterval;
		boolean var2 = this.primaryServerQueryTimeIntervalESet;
		this.primaryServerQueryTimeInterval = 15;
		this.primaryServerQueryTimeIntervalESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 3, var1, 15, var2));
		}

	}

	public boolean isSetPrimaryServerQueryTimeInterval() {
		return this.primaryServerQueryTimeIntervalESet;
	}

	public boolean isReturnToPrimaryServer() {
		return this.returnToPrimaryServer;
	}

	public void setReturnToPrimaryServer(boolean var1) {
		boolean var2 = this.returnToPrimaryServer;
		this.returnToPrimaryServer = var1;
		boolean var3 = this.returnToPrimaryServerESet;
		this.returnToPrimaryServerESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var2, this.returnToPrimaryServer, !var3));
		}

	}

	public void unsetReturnToPrimaryServer() {
		boolean var1 = this.returnToPrimaryServer;
		boolean var2 = this.returnToPrimaryServerESet;
		this.returnToPrimaryServer = true;
		this.returnToPrimaryServerESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 4, var1, true, var2));
		}

	}

	public boolean isSetReturnToPrimaryServer() {
		return this.returnToPrimaryServerESet;
	}

	public int getSearchCountLimit() {
		return this.searchCountLimit;
	}

	public void setSearchCountLimit(int var1) {
		int var2 = this.searchCountLimit;
		this.searchCountLimit = var1;
		boolean var3 = this.searchCountLimitESet;
		this.searchCountLimitESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 5, var2, this.searchCountLimit, !var3));
		}

	}

	public void unsetSearchCountLimit() {
		int var1 = this.searchCountLimit;
		boolean var2 = this.searchCountLimitESet;
		this.searchCountLimit = 0;
		this.searchCountLimitESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 5, var1, 0, var2));
		}

	}

	public boolean isSetSearchCountLimit() {
		return this.searchCountLimitESet;
	}

	public int getSearchPageSize() {
		return this.searchPageSize;
	}

	public void setSearchPageSize(int var1) {
		int var2 = this.searchPageSize;
		this.searchPageSize = var1;
		boolean var3 = this.searchPageSizeESet;
		this.searchPageSizeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 6, var2, this.searchPageSize, !var3));
		}

	}

	public void unsetSearchPageSize() {
		int var1 = this.searchPageSize;
		boolean var2 = this.searchPageSizeESet;
		this.searchPageSize = 0;
		this.searchPageSizeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 6, var1, 0, var2));
		}

	}

	public boolean isSetSearchPageSize() {
		return this.searchPageSizeESet;
	}

	public int getSearchTimeLimit() {
		return this.searchTimeLimit;
	}

	public void setSearchTimeLimit(int var1) {
		int var2 = this.searchTimeLimit;
		this.searchTimeLimit = var1;
		boolean var3 = this.searchTimeLimitESet;
		this.searchTimeLimitESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 7, var2, this.searchTimeLimit, !var3));
		}

	}

	public void unsetSearchTimeLimit() {
		int var1 = this.searchTimeLimit;
		boolean var2 = this.searchTimeLimitESet;
		this.searchTimeLimit = 0;
		this.searchTimeLimitESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 7, var1, 0, var2));
		}

	}

	public boolean isSetSearchTimeLimit() {
		return this.searchTimeLimitESet;
	}

	public String getSslConfiguration() {
		return this.sslConfiguration;
	}

	public void setSslConfiguration(String var1) {
		String var2 = this.sslConfiguration;
		this.sslConfiguration = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 8, var2, this.sslConfiguration));
		}

	}

	public String getSslKeyStore() {
		return this.sslKeyStore;
	}

	public void setSslKeyStore(String var1) {
		String var2 = this.sslKeyStore;
		this.sslKeyStore = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 9, var2, this.sslKeyStore));
		}

	}

	public String getSslKeyStorePassword() {
		return this.sslKeyStorePassword;
	}

	public void setSslKeyStorePassword(String var1) {
		String var2 = this.sslKeyStorePassword;
		this.sslKeyStorePassword = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 10, var2, this.sslKeyStorePassword));
		}

	}

	public String getSslKeyStoreType() {
		return this.sslKeyStoreType;
	}

	public void setSslKeyStoreType(String var1) {
		String var2 = this.sslKeyStoreType;
		this.sslKeyStoreType = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 11, var2, this.sslKeyStoreType));
		}

	}

	public String getSslTrustStore() {
		return this.sslTrustStore;
	}

	public void setSslTrustStore(String var1) {
		String var2 = this.sslTrustStore;
		this.sslTrustStore = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 12, var2, this.sslTrustStore));
		}

	}

	public String getSslTrustStorePassword() {
		return this.sslTrustStorePassword;
	}

	public void setSslTrustStorePassword(String var1) {
		String var2 = this.sslTrustStorePassword;
		this.sslTrustStorePassword = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 13, var2, this.sslTrustStorePassword));
		}

	}

	public String getSslTrustStoreType() {
		return this.sslTrustStoreType;
	}

	public void setSslTrustStoreType(String var1) {
		String var2 = this.sslTrustStoreType;
		this.sslTrustStoreType = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 14, var2, this.sslTrustStoreType));
		}

	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getLdapServers()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getLdapServers();
			case 1 :
				return this.isAllowWriteToSecondaryServers() ? Boolean.TRUE : Boolean.FALSE;
			case 2 :
				return new Integer(this.getAttributeRangeStep());
			case 3 :
				return new Integer(this.getPrimaryServerQueryTimeInterval());
			case 4 :
				return this.isReturnToPrimaryServer() ? Boolean.TRUE : Boolean.FALSE;
			case 5 :
				return new Integer(this.getSearchCountLimit());
			case 6 :
				return new Integer(this.getSearchPageSize());
			case 7 :
				return new Integer(this.getSearchTimeLimit());
			case 8 :
				return this.getSslConfiguration();
			case 9 :
				return this.getSslKeyStore();
			case 10 :
				return this.getSslKeyStorePassword();
			case 11 :
				return this.getSslKeyStoreType();
			case 12 :
				return this.getSslTrustStore();
			case 13 :
				return this.getSslTrustStorePassword();
			case 14 :
				return this.getSslTrustStoreType();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getLdapServers().clear();
				this.getLdapServers().addAll((Collection) var2);
				return;
			case 1 :
				this.setAllowWriteToSecondaryServers((Boolean) var2);
				return;
			case 2 :
				this.setAttributeRangeStep((Integer) var2);
				return;
			case 3 :
				this.setPrimaryServerQueryTimeInterval((Integer) var2);
				return;
			case 4 :
				this.setReturnToPrimaryServer((Boolean) var2);
				return;
			case 5 :
				this.setSearchCountLimit((Integer) var2);
				return;
			case 6 :
				this.setSearchPageSize((Integer) var2);
				return;
			case 7 :
				this.setSearchTimeLimit((Integer) var2);
				return;
			case 8 :
				this.setSslConfiguration((String) var2);
				return;
			case 9 :
				this.setSslKeyStore((String) var2);
				return;
			case 10 :
				this.setSslKeyStorePassword((String) var2);
				return;
			case 11 :
				this.setSslKeyStoreType((String) var2);
				return;
			case 12 :
				this.setSslTrustStore((String) var2);
				return;
			case 13 :
				this.setSslTrustStorePassword((String) var2);
				return;
			case 14 :
				this.setSslTrustStoreType((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getLdapServers().clear();
				return;
			case 1 :
				this.unsetAllowWriteToSecondaryServers();
				return;
			case 2 :
				this.unsetAttributeRangeStep();
				return;
			case 3 :
				this.unsetPrimaryServerQueryTimeInterval();
				return;
			case 4 :
				this.unsetReturnToPrimaryServer();
				return;
			case 5 :
				this.unsetSearchCountLimit();
				return;
			case 6 :
				this.unsetSearchPageSize();
				return;
			case 7 :
				this.unsetSearchTimeLimit();
				return;
			case 8 :
				this.setSslConfiguration(SSL_CONFIGURATION_EDEFAULT);
				return;
			case 9 :
				this.setSslKeyStore(SSL_KEY_STORE_EDEFAULT);
				return;
			case 10 :
				this.setSslKeyStorePassword(SSL_KEY_STORE_PASSWORD_EDEFAULT);
				return;
			case 11 :
				this.setSslKeyStoreType(SSL_KEY_STORE_TYPE_EDEFAULT);
				return;
			case 12 :
				this.setSslTrustStore(SSL_TRUST_STORE_EDEFAULT);
				return;
			case 13 :
				this.setSslTrustStorePassword(SSL_TRUST_STORE_PASSWORD_EDEFAULT);
				return;
			case 14 :
				this.setSslTrustStoreType(SSL_TRUST_STORE_TYPE_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.ldapServers != null && !this.ldapServers.isEmpty();
			case 1 :
				return this.isSetAllowWriteToSecondaryServers();
			case 2 :
				return this.isSetAttributeRangeStep();
			case 3 :
				return this.isSetPrimaryServerQueryTimeInterval();
			case 4 :
				return this.isSetReturnToPrimaryServer();
			case 5 :
				return this.isSetSearchCountLimit();
			case 6 :
				return this.isSetSearchPageSize();
			case 7 :
				return this.isSetSearchTimeLimit();
			case 8 :
				return SSL_CONFIGURATION_EDEFAULT == null
						? this.sslConfiguration != null
						: !SSL_CONFIGURATION_EDEFAULT.equals(this.sslConfiguration);
			case 9 :
				return SSL_KEY_STORE_EDEFAULT == null
						? this.sslKeyStore != null
						: !SSL_KEY_STORE_EDEFAULT.equals(this.sslKeyStore);
			case 10 :
				return SSL_KEY_STORE_PASSWORD_EDEFAULT == null
						? this.sslKeyStorePassword != null
						: !SSL_KEY_STORE_PASSWORD_EDEFAULT.equals(this.sslKeyStorePassword);
			case 11 :
				return SSL_KEY_STORE_TYPE_EDEFAULT == null
						? this.sslKeyStoreType != null
						: !SSL_KEY_STORE_TYPE_EDEFAULT.equals(this.sslKeyStoreType);
			case 12 :
				return SSL_TRUST_STORE_EDEFAULT == null
						? this.sslTrustStore != null
						: !SSL_TRUST_STORE_EDEFAULT.equals(this.sslTrustStore);
			case 13 :
				return SSL_TRUST_STORE_PASSWORD_EDEFAULT == null
						? this.sslTrustStorePassword != null
						: !SSL_TRUST_STORE_PASSWORD_EDEFAULT.equals(this.sslTrustStorePassword);
			case 14 :
				return SSL_TRUST_STORE_TYPE_EDEFAULT == null
						? this.sslTrustStoreType != null
						: !SSL_TRUST_STORE_TYPE_EDEFAULT.equals(this.sslTrustStoreType);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (allowWriteToSecondaryServers: ");
			if (this.allowWriteToSecondaryServersESet) {
				var1.append(this.allowWriteToSecondaryServers);
			} else {
				var1.append("<unset>");
			}

			var1.append(", attributeRangeStep: ");
			if (this.attributeRangeStepESet) {
				var1.append(this.attributeRangeStep);
			} else {
				var1.append("<unset>");
			}

			var1.append(", primaryServerQueryTimeInterval: ");
			if (this.primaryServerQueryTimeIntervalESet) {
				var1.append(this.primaryServerQueryTimeInterval);
			} else {
				var1.append("<unset>");
			}

			var1.append(", returnToPrimaryServer: ");
			if (this.returnToPrimaryServerESet) {
				var1.append(this.returnToPrimaryServer);
			} else {
				var1.append("<unset>");
			}

			var1.append(", searchCountLimit: ");
			if (this.searchCountLimitESet) {
				var1.append(this.searchCountLimit);
			} else {
				var1.append("<unset>");
			}

			var1.append(", searchPageSize: ");
			if (this.searchPageSizeESet) {
				var1.append(this.searchPageSize);
			} else {
				var1.append("<unset>");
			}

			var1.append(", searchTimeLimit: ");
			if (this.searchTimeLimitESet) {
				var1.append(this.searchTimeLimit);
			} else {
				var1.append("<unset>");
			}

			var1.append(", sslConfiguration: ");
			var1.append(this.sslConfiguration);
			var1.append(", sslKeyStore: ");
			var1.append(this.sslKeyStore);
			var1.append(", sslKeyStorePassword: ");
			var1.append(this.sslKeyStorePassword);
			var1.append(", sslKeyStoreType: ");
			var1.append(this.sslKeyStoreType);
			var1.append(", sslTrustStore: ");
			var1.append(this.sslTrustStore);
			var1.append(", sslTrustStorePassword: ");
			var1.append(this.sslTrustStorePassword);
			var1.append(", sslTrustStoreType: ");
			var1.append(this.sslTrustStoreType);
			var1.append(')');
			return var1.toString();
		}
	}
}