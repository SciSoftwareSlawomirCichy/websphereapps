package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.DiscreteDomain.BigIntegerDomain;
import com.google.common.collect.DiscreteDomain.IntegerDomain;
import com.google.common.collect.DiscreteDomain.LongDomain;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.math.BigInteger;
import java.util.NoSuchElementException;

@GwtCompatible
public abstract class DiscreteDomain<C extends Comparable> {
	final boolean supportsFastOffset;

	public static DiscreteDomain<Integer> integers() {
		return IntegerDomain.access$000();
	}

	public static DiscreteDomain<Long> longs() {
		return LongDomain.access$200();
	}

	public static DiscreteDomain<BigInteger> bigIntegers() {
		return BigIntegerDomain.access$300();
	}

	protected DiscreteDomain() {
		this(false);
	}

	private DiscreteDomain(boolean supportsFastOffset) {
		this.supportsFastOffset = supportsFastOffset;
	}

	C offset(C origin, long distance) {
		CollectPreconditions.checkNonnegative(distance, "distance");

		for (long i = 0L; i < distance; ++i) {
			origin = this.next(origin);
		}

		return origin;
	}

	public abstract C next(C var1);

	public abstract C previous(C var1);

	public abstract long distance(C var1, C var2);

	@CanIgnoreReturnValue
	public C minValue() {
		throw new NoSuchElementException();
	}

	@CanIgnoreReturnValue
	public C maxValue() {
		throw new NoSuchElementException();
	}
}