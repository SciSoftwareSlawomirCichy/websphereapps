package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface TopicRegistrationList {
	List getTopicEmitter();

	TopicEmitter[] getTopicEmitterAsArray();

	TopicEmitter createTopicEmitter();
}