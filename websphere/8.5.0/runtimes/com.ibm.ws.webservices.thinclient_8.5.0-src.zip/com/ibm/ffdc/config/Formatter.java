package com.ibm.ffdc.config;

public interface Formatter {
	void formatTo(Object var1, IncidentStream var2) throws IllegalArgumentException;

	String[] getSupportedTypeNames();

	boolean isSupported(Class<?> var1);
}