package com.google.common.graph;

import com.google.common.annotations.Beta;
import com.google.common.base.Function;
import com.google.common.collect.Maps;
import com.google.common.graph.AbstractValueGraph.1;
import com.google.common.graph.AbstractValueGraph.2;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Beta
public abstract class AbstractValueGraph<N, V> extends AbstractBaseGraph<N> implements ValueGraph<N, V> {
	public Graph<N> asGraph() {
      return new 1(this);
   }

	public final boolean equals(@NullableDecl Object obj) {
		if (obj == this) {
			return true;
		} else if (!(obj instanceof ValueGraph)) {
			return false;
		} else {
			ValueGraph<?, ?> other = (ValueGraph) obj;
			return this.isDirected() == other.isDirected() && this.nodes().equals(other.nodes())
					&& edgeValueMap(this).equals(edgeValueMap(other));
		}
	}

	public final int hashCode() {
		return edgeValueMap(this).hashCode();
	}

	public String toString() {
		return "isDirected: " + this.isDirected() + ", allowsSelfLoops: " + this.allowsSelfLoops() + ", nodes: "
				+ this.nodes() + ", edges: " + edgeValueMap(this);
	}

	private static <N, V> Map<EndpointPair<N>, V> edgeValueMap(ValueGraph<N, V> graph) {
      Function<EndpointPair<N>, V> edgeToValueFn = new 2(graph);
      return Maps.asMap(graph.edges(), edgeToValueFn);
   }
}