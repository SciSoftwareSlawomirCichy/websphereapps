package com.ibm.icu.text;

import com.ibm.icu.impl.Norm2AllModes;
import com.ibm.icu.text.Normalizer.QuickCheckResult;
import com.ibm.icu.text.Normalizer2.1;
import com.ibm.icu.text.Normalizer2.Mode;
import java.io.InputStream;

public abstract class Normalizer2 {
	public static Normalizer2 getInstance(InputStream data, String name, Mode mode) {
      Norm2AllModes all2Modes = Norm2AllModes.getInstance(data, name);
      switch(1.$SwitchMap$com$ibm$icu$text$Normalizer2$Mode[mode.ordinal()]) {
      case 1:
         return all2Modes.comp;
      case 2:
         return all2Modes.decomp;
      case 3:
         return all2Modes.fcd;
      case 4:
         return all2Modes.fcc;
      default:
         return null;
      }
   }

	public String normalize(CharSequence src) {
		return this.normalize(src, new StringBuilder()).toString();
	}

	public abstract StringBuilder normalize(CharSequence var1, StringBuilder var2);

	public abstract Appendable normalize(CharSequence var1, Appendable var2);

	public abstract StringBuilder normalizeSecondAndAppend(StringBuilder var1, CharSequence var2);

	public abstract StringBuilder append(StringBuilder var1, CharSequence var2);

	public abstract boolean isNormalized(CharSequence var1);

	public abstract QuickCheckResult quickCheck(CharSequence var1);

	public abstract int spanQuickCheckYes(CharSequence var1);

	public abstract boolean hasBoundaryBefore(int var1);

	public abstract boolean hasBoundaryAfter(int var1);

	public abstract boolean isInert(int var1);
}