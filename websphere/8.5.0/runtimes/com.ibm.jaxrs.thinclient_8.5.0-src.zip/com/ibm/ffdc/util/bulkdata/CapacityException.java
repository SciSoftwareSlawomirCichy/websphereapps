package com.ibm.ffdc.util.bulkdata;

public class CapacityException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}