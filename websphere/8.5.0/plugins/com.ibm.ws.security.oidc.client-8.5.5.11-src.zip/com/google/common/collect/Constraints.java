package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.Constraints.ConstrainedCollection;
import com.google.common.collect.Constraints.ConstrainedList;
import com.google.common.collect.Constraints.ConstrainedListIterator;
import com.google.common.collect.Constraints.ConstrainedMultiset;
import com.google.common.collect.Constraints.ConstrainedRandomAccessList;
import com.google.common.collect.Constraints.ConstrainedSet;
import com.google.common.collect.Constraints.ConstrainedSortedSet;
import com.google.common.collect.Constraints.NotNullConstraint;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import java.util.Set;
import java.util.SortedSet;

@Beta
@GwtCompatible
public final class Constraints {
	public static <E> Constraint<E> notNull() {
		return NotNullConstraint.INSTANCE;
	}

	public static <E> Collection<E> constrainedCollection(Collection<E> collection, Constraint<? super E> constraint) {
		return new ConstrainedCollection(collection, constraint);
	}

	public static <E> Set<E> constrainedSet(Set<E> set, Constraint<? super E> constraint) {
		return new ConstrainedSet(set, constraint);
	}

	public static <E> SortedSet<E> constrainedSortedSet(SortedSet<E> sortedSet, Constraint<? super E> constraint) {
		return new ConstrainedSortedSet(sortedSet, constraint);
	}

	public static <E> List<E> constrainedList(List<E> list, Constraint<? super E> constraint) {
		return (List) (list instanceof RandomAccess
				? new ConstrainedRandomAccessList(list, constraint)
				: new ConstrainedList(list, constraint));
	}

	private static <E> ListIterator<E> constrainedListIterator(ListIterator<E> listIterator,
			Constraint<? super E> constraint) {
		return new ConstrainedListIterator(listIterator, constraint);
	}

	static <E> Collection<E> constrainedTypePreservingCollection(Collection<E> collection, Constraint<E> constraint) {
		if (collection instanceof SortedSet) {
			return constrainedSortedSet((SortedSet) collection, constraint);
		} else if (collection instanceof Set) {
			return constrainedSet((Set) collection, constraint);
		} else {
			return (Collection) (collection instanceof List
					? constrainedList((List) collection, constraint)
					: constrainedCollection(collection, constraint));
		}
	}

	public static <E> Multiset<E> constrainedMultiset(Multiset<E> multiset, Constraint<? super E> constraint) {
		return new ConstrainedMultiset(multiset, constraint);
	}

	private static <E> Collection<E> checkElements(Collection<E> elements, Constraint<? super E> constraint) {
		Collection<E> copy = Lists.newArrayList(elements);
		Iterator i$ = copy.iterator();

		while (i$.hasNext()) {
			E element = i$.next();
			constraint.checkElement(element);
		}

		return copy;
	}
}