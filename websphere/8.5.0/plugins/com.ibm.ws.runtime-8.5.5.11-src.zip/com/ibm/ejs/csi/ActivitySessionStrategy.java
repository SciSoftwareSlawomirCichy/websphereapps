package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIActivityCompletedException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.ws.ActivitySession.ActivitySession;
import com.ibm.ws.Transaction.TransactionManagerFactory;
import com.ibm.ws.ffdc.FFDCFilter;

abstract class ActivitySessionStrategy {
	protected static TraceComponent tc = Tr.register(ActivitySessionStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.csi.ActivitySessionStrategy";
	protected UOWControlImpl UOWCtrl;

	protected ActivitySessionStrategy(UOWControlImpl UOWCtrl) {
		this.UOWCtrl = UOWCtrl;
	}

	abstract ASCookieImpl preInvoke(EJBKey var1, EJBMethodInfoImpl var2) throws CSIException;

	abstract void postInvoke(EJBKey var1, ASCookieImpl var2, EJBMethodInfoImpl var3) throws CSIException;

	void handleException(EJBKey key, ASCookieImpl asCookie, ExceptionType type, EJBMethodInfoImpl methodInfo)
			throws CSIException {
		if (type == ExceptionType.CHECKED_EXCEPTION) {
			this.postInvoke(key, asCookie, methodInfo);
		} else {
			try {
				try {
					if (this.ASExists()) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
							Tr.event(tc, "handleException:  marking activitySession resetOnly due to bean exception");
						}

						this.UOWCtrl.asService.setResetOnly();
					}
				} catch (Exception var10) {
					FFDCFilter.processException(var10, "com.ibm.ejs.csi.ActivitySessionStrategy.handleException", "136",
							this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Suppressing exception during handleException method: ", var10);
					}
				}

				if (!asCookie.beginner) {
					throw new CSIActivityCompletedException("ActivitySession marked resetOnly due to bean exception");
				}

				try {
					if (this.ASExists()) {
						this.endAS();
					}
				} catch (CSIException var11) {
					throw var11;
				}
			} finally {
				if (asCookie.suspendedAS != null) {
					this.resumeAS(asCookie.suspendedAS);
				}

			}

		}
	}

	final boolean ASExists() {
		return this.UOWCtrl.ASExists();
	}

	final void beginAS() throws CSIException {
		try {
			this.UOWCtrl.asService.beginSession();
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Began AS cntxt: " + this.UOWCtrl.asService.getSessionName());
			}

		} catch (Exception var2) {
			FFDCFilter.processException(var2, "com.ibm.ejs.csi.ActivitySessionStrategy.beginAS", "174", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Begin activitySession failed ", var2);
			}

			throw new CSIException("Begin activitySession failed ", var2);
		}
	}

	final void endAS() throws CSIException {
		try {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Ending AS cntxt: " + this.UOWCtrl.asService.getSessionName());
			}

			this.UOWCtrl.asService.endSession(0);
		} catch (Exception var2) {
			FFDCFilter.processException(var2, "com.ibm.ejs.csi.ActivitySessionStrategy.endAS", "202", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "End activitySession failed ", var2);
			}

			throw new CSIException("End activitySession failed ", var2);
		}
	}

	final ActivitySession suspendAS() throws CSIException {
		return this.UOWCtrl.suspendAS();
	}

	final void resumeAS(ActivitySession suspendedAS) throws CSIException {
		this.UOWCtrl.resumeAS(suspendedAS);
	}

	final boolean globalTxExists() {
		boolean retval = false;

		try {
			int tranState = TransactionManagerFactory.getTransactionManager().getStatus();
			if (tranState != 6) {
				retval = true;
			}
		} catch (Exception var3) {
			;
		}

		return retval;
	}

	public boolean isBmasActive() {
		return false;
	}
}