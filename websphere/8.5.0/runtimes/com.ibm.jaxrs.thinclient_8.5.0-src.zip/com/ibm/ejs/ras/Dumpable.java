package com.ibm.ejs.ras;

public interface Dumpable {
	void dump();

	void resetDump();
}