package com.ibm.websphere.ssl;

public interface SSLConfigChangeListener {
	void stateChanged(SSLConfigChangeEvent var1);
}