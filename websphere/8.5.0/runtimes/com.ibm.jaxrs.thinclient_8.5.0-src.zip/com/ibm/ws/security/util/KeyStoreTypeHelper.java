package com.ibm.ws.security.util;

public class KeyStoreTypeHelper {
	public static boolean isCMSKeyStore(String SSLKeyStoreType) {
		return SSLKeyStoreType != null && SSLKeyStoreType.equals("CMSKS");
	}
}