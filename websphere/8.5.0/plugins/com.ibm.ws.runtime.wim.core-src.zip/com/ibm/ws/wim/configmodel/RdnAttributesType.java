package com.ibm.ws.wim.configmodel;

public interface RdnAttributesType {
	String getName();

	void setName(String var1);

	String getObjectClass();

	void setObjectClass(String var1);
}