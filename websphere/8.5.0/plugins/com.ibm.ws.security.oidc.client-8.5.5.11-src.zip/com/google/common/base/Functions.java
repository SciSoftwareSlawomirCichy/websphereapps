package com.google.common.base;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Functions.1;
import com.google.common.base.Functions.ConstantFunction;
import com.google.common.base.Functions.ForMapWithDefault;
import com.google.common.base.Functions.FunctionComposition;
import com.google.common.base.Functions.FunctionForMapNoDefault;
import com.google.common.base.Functions.IdentityFunction;
import com.google.common.base.Functions.PredicateFunction;
import com.google.common.base.Functions.SupplierFunction;
import com.google.common.base.Functions.ToStringFunction;
import java.util.Map;
import javax.annotation.Nullable;

@GwtCompatible
public final class Functions {
	public static Function<Object, String> toStringFunction() {
		return ToStringFunction.INSTANCE;
	}

	public static <E> Function<E, E> identity() {
		return IdentityFunction.INSTANCE;
	}

	public static <K, V> Function<K, V> forMap(Map<K, V> map) {
		return new FunctionForMapNoDefault(map);
	}

	public static <K, V> Function<K, V> forMap(Map<K, ? extends V> map, @Nullable V defaultValue) {
		return new ForMapWithDefault(map, defaultValue);
	}

	public static <A, B, C> Function<A, C> compose(Function<B, C> g, Function<A, ? extends B> f) {
		return new FunctionComposition(g, f);
	}

	public static <T> Function<T, Boolean> forPredicate(Predicate<T> predicate) {
      return new PredicateFunction(predicate, (1)null);
   }

	public static <E> Function<Object, E> constant(@Nullable E value) {
		return new ConstantFunction(value);
	}

	@Beta
   public static <T> Function<Object, T> forSupplier(Supplier<T> supplier) {
      return new SupplierFunction(supplier, (1)null);
   }
}