package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.cache.CachedStatement;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import com.ibm.ws.ffdc.FFDCFilter;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Vector;

public class WSJdbcUtil {
	private static final TraceComponent tc = Tr.register(WSJdbcUtil.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");
	private static Hashtable vendorMethods = new Hashtable();
	private static Vector<String> forbiddenMethods = new Vector(Arrays.asList(
			"setAttribute,class java.lang.String,class java.lang.Object",
			"setClientAccountingInfo,class java.lang.String", "setClientApplicationName,class java.lang.String",
			"setClientHostName,class java.lang.String", "setClientUser,class java.lang.String",
			"setCurrentUser,class java.lang.String", "setCurrentUser,class java.lang.String,class java.util.Properties",
			"setCurrentUser,class javax.security.auth.Subject",
			"setCurrentUser,class javax.security.auth.Subject,class java.util.Properties", "setNetworkTimeout,int",
			"setLongDataCacheSize,int", "setResponseBuffering,class java.lang.String"));
	public static final int CONNECTION = 1;
	public static final int STATEMENT = 2;
	public static final int PREPARED_STATEMENT = 3;
	public static final int CALLABLE_STATEMENT = 4;
	public static final int RESULT_SET = 5;
	public static final int IGNORE = -1;
	public static final String CONSTRUCTOR = "<init>";

	public static final Object jdbcCall(Class underlyingObjectType, Object caller, String methodName, Object[] args,
			Class[] types) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "jdbcCall: underlyingObjectType, caller, methodName, args, types",
					new Object[]{underlyingObjectType, caller, methodName, args, types});
		}

		Object newCaller = null;
		if (caller == null) {
			throw new SQLException("Caller cannot be null");
		} else if (caller instanceof Proxy && ((Proxy) caller).isClosed()) {
			throw new StaleConnectionException(caller.getClass() + " is closed");
		} else {
			if (caller instanceof ResultSetProxy) {
				newCaller = ((ResultSetProxy) caller).getResultSet();
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Caller is ResultSetProxy, newCaller is " + newCaller.getClass().getName());
				}
			} else if (caller instanceof StatementProxy) {
				newCaller = ((StatementProxy) caller).getStatement();
				if (newCaller instanceof CachedStatement) {
					newCaller = ((CachedStatement) newCaller).getPreparedStatement();
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Caller is Statement, newCaller is " + newCaller.getClass().getName());
				}
			} else {
				if (!(caller instanceof ConnectionProxy)) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "jdbcCall, throwing SQLException: Invalid Caller Type!");
					}

					throw new SQLException("Invalid Caller Type: " + caller.getClass().getName());
				}

				newCaller = ((ConnectionProxy) caller).getPhysicalConnection();
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Caller is ConnectionProxy, newCaller is " + newCaller.getClass().getName());
				}
			}

			if (newCaller != null) {
				SQLException x = null;
				synchronized (((Proxy) caller).getLockObject()) {
					Object var9;
					try {
						((Proxy) caller).__preInvoke();
						Object retVal = invokeMethod(newCaller, newCaller.getClass(), methodName, args, types);
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "jdbcCall, returned Object:", retVal);
						}

						var9 = retVal;
					} catch (SQLException var15) {
						FFDCFilter.processException(var15, "com.ibm.ejs.cm.proxy.WSJdbcUtil.jdbcCall", "183");
						x = var15;
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "jdbcCall, SQLException during invokeMethod:", var15);
						}

						throw ((Proxy) caller).translateException(var15);
					} finally {
						((Proxy) caller).__postInvoke(x);
					}

					return var9;
				}
			} else {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "jdbcCall, throwing SQLException: Invalid Caller Type, newCaller is null");
				}

				throw new SQLException("Invalid Caller Type, newCaller is null");
			}
		}
	}

	public static final Object jdbcPass(Object callOn, String methodName, Object[] args, Class[] types, int[] replace)
			throws SQLException {
		return jdbcPass(callOn, callOn.getClass(), methodName, args, types, replace);
	}

	public static final Object jdbcPass(Class ofCaller, String methodName, Object[] args, Class[] types, int[] replace)
			throws SQLException {
		return jdbcPass((Object) null, ofCaller, methodName, args, types, replace);
	}

	private static final Object jdbcPass(Object callOn, Class ofCaller, String methodName, Object[] args, Class[] types,
			int[] replace) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "jdbcPass: callOn, ofCaller, methodName, args, types, replace",
					new Object[]{callOn, ofCaller, methodName, args, types, replace});
		}

		Proxy p = null;
		Object[] tempArgs = (Object[]) ((Object[]) args.clone());

		for (int i = 0; i < replace.length; ++i) {
			switch (replace[i]) {
				case 1 :
					p = (Proxy) tempArgs[i];
					tempArgs[i] = ((ConnectionProxy) tempArgs[i]).getPhysicalConnection();
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Replacing ConnectionProxy with Connection " + (Connection) tempArgs[i]);
					}
					break;
				case 2 :
				case 3 :
				case 4 :
					p = (Proxy) tempArgs[i];
					tempArgs[i] = ((StatementProxy) tempArgs[i]).getStatement();
					if (tempArgs[i] instanceof CachedStatement) {
						tempArgs[i] = ((CachedStatement) tempArgs[i]).getPreparedStatement();
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Replacing StatementProxy with Statement " + (Statement) tempArgs[i]);
					}
					break;
				case 5 :
					p = (Proxy) tempArgs[i];
					tempArgs[i] = ((ResultSetProxy) tempArgs[i]).getResultSet();
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Replacing ResultSetProxy with ResultSet " + (ResultSet) tempArgs[i]);
					}
			}

			if (p != null && p.isClosed()) {
				throw new StaleConnectionException(p.getClass() + " is closed");
			}
		}

		if (p != null) {
			SQLException x = null;
			synchronized (p.getLockObject()) {
				Object var11;
				try {
					p.__preInvoke();
					Object retVal = invokeMethod(callOn, ofCaller, methodName, tempArgs, types);
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "jdbcPass returning", retVal);
					}

					var11 = retVal;
				} catch (SQLException var17) {
					FFDCFilter.processException(var17, "com.ibm.ejs.cm.proxy.WSJdbcUtil.jdbcPass", "387");
					x = var17;
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "jdbcPass, caught and translating SQLException:", var17);
					}

					throw p.translateException(var17);
				} finally {
					p.__postInvoke(x);
				}

				return var11;
			}
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "jdbcPass, throwing SQLException, Proxied object not found!");
			}

			throw new SQLException("Proxied object not found!");
		}
	}

	private static Object invokeMethod(Object caller, Class ofCaller, String methodName, Object[] args, Class[] types)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "invokeMethod: caller, ofCaller, methodName, args, types",
					new Object[]{caller, ofCaller, methodName, args, types});
		}

		try {
			AccessibleObject m = null;
			StringBuffer key = new StringBuffer(100);
			key.append(ofCaller.getName());
			key.append(".");
			key.append(methodName);

			for (int i = 0; i < types.length; ++i) {
				key.append(",");
				key.append(types[i]);
			}

			String keyString = key.toString();
			m = (AccessibleObject) vendorMethods.get(keyString);
			if (m == null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Method " + keyString + " is not in the vendorMethods cache");
				}

				if (!canCallMethod(keyString, ofCaller, methodName, types)) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Method " + keyString + " is a forbidden method");
					}

					throw new SQLException(keyString
							+ " call not allowed.  WSCallHelper methods should only be used for proprietary, non-JDBC methods.");
				}

				if (methodName.equals("<init>")) {
					m = ofCaller.getConstructor(types);
				} else {
					m = ofCaller.getMethod(methodName, types);
				}

				vendorMethods.put(keyString, m);
			} else if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Method " + keyString + " is in the vendorMethods cache");
			}

			if (m != null) {
				Object retVal = null;
				if (m instanceof Method) {
					retVal = ((Method) m).invoke(caller, args);
				} else {
					if (!(m instanceof Constructor)) {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "invokeMethod, not a Method or constructor: ", m);
						}

						throw new SQLException(keyString
								+ " call not allowed.  WSCallHelper methods should only be used for proprietary, non-JDBC methods or constructors.");
					}

					retVal = ((Constructor) m).newInstance(args);
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "invokeMethod, returning ", retVal);
				}

				return retVal;
			} else {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Null method trying to invoke " + keyString);
				}

				throw new SQLException(keyString + " method not found.");
			}
		} catch (InstantiationException var9) {
			var9.printStackTrace();
			Tr.audit(tc, "MSG_CONM_6014I",
					new Object[]{"InstantiationException", "invokeMethod", "SQLException", var9});
			throw new SQLException("Method " + methodName + " does not exist on class " + caller.getClass().getName());
		} catch (NoSuchMethodException var10) {
			FFDCFilter.processException(var10, "com.ibm.ejs.cm.proxy.WSJdbcUtil.invokeMethod", "459");
			var10.printStackTrace();
			Tr.audit(tc, "MSG_CONM_6014I",
					new Object[]{"NoSuchMethodException", "invokeMethod", "SQLException", var10});
			throw new SQLException("Method " + methodName + " does not exist on class " + caller.getClass().getName());
		} catch (IllegalAccessException var11) {
			FFDCFilter.processException(var11, "com.ibm.ejs.cm.proxy.WSJdbcUtil.invokeMethod", "472");
			var11.printStackTrace();
			Tr.audit(tc, "MSG_CONM_6014I",
					new Object[]{"IllegalAccessException", "invokeMethod", "SQLException", var11});
			throw new SQLException(
					"Illegal Access to method " + methodName + " on class " + caller.getClass().getName());
		} catch (InvocationTargetException var12) {
			FFDCFilter.processException(var12, "com.ibm.ejs.cm.proxy.WSJdbcUtil.invokeMethod", "485");
			var12.printStackTrace();
			Tr.audit(tc, "MSG_CONM_6014I",
					new Object[]{"InvocationTargetException", "invokeMethod", "SQLException", var12});
			Throwable target = var12.getTargetException();
			if (target instanceof SQLException) {
				throw (SQLException) target;
			} else {
				throw new SQLException("Invocation Target Exception on method " + methodName + " on class "
						+ caller.getClass().getName() + " exception: " + target.toString());
			}
		}
	}

	private static boolean canCallMethod(String key, Class ofCaller, String methodName, Class[] types) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "canCallMethod: key, ofCaller, methodName, types",
					new Object[]{key, ofCaller, methodName, types});
		}

		boolean canCall = true;
		String shortKey = key.substring(ofCaller.getName().length() + 1);
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Short key: " + shortKey);
		}

		if (forbiddenMethods.contains(key)) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Method " + key + " is already on the list of forbidden methods");
			}

			canCall = false;
		} else if (forbiddenMethods.contains(shortKey)) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Method " + shortKey + " is already on the list of forbidden methods");
			}

			canCall = false;
		} else {
			if (Connection.class.isAssignableFrom(ofCaller)) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "ofCaller isAssignableFrom Connection");
				}

				canCall = !methodExists(ConnectionProxy.class, methodName, types);
			}

			if (canCall && CallableStatement.class.isAssignableFrom(ofCaller)) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "ofCaller isAssignableFrom CallableStatement");
				}

				canCall = !methodExists(CallableStatementProxy.class, methodName, types);
			}

			if (canCall && PreparedStatement.class.isAssignableFrom(ofCaller)) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "ofCaller isAssignableFrom PreparedStatement");
				}

				canCall = !methodExists(PreparedStatementProxy.class, methodName, types);
			}

			if (canCall && Statement.class.isAssignableFrom(ofCaller)) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "ofCaller isAssignableFrom Statement");
				}

				canCall = !methodExists(StatementProxy.class, methodName, types);
			}

			if (canCall && ResultSet.class.isAssignableFrom(ofCaller)) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "ofCaller isAssignableFrom ResultSet");
				}

				canCall = !methodExists(ResultSetProxy.class, methodName, types);
			}

			if (!canCall) {
				forbiddenMethods.add(key);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "canCallMethod", new Boolean(canCall));
		}

		return canCall;
	}

	private static int getInterfaces(Class ofClass) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInterfaces", ofClass);
		}

		int returnValue = -1;
		Class[] interfaces = ofClass.getInterfaces();
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, interfaces.length + " interfaces for class");
		}

		for (int i = 0; i < interfaces.length; ++i) {
			if (returnValue == -1) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Checking interface " + interfaces[i]);
				}

				if (interfaces[i].getName().equals("java.sql.ResultSet")) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Found ResultSet");
					}

					return 5;
				}

				if (interfaces[i].getName().equals("java.sql.CallableStatement")) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Found CallableStatement");
					}

					return 4;
				}

				if (interfaces[i].getName().equals("java.sql.PreparedStatement")) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Found PreparedStatement");
					}

					return 3;
				}

				if (interfaces[i].getName().equals("java.sql.Statement")) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Found Statement");
					}

					return 2;
				}

				if (interfaces[i].getName().equals("java.sql.Connection")) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Found Connection");
					}

					return 1;
				}

				returnValue = getInterfaces(interfaces[i]);
			}
		}

		if (returnValue == -1) {
			Class sc = ofClass.getSuperclass();
			if (sc != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Checking interfaces on superclass " + sc);
				}

				returnValue = getInterfaces(sc);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInterfaces", new Integer(returnValue));
		}

		return returnValue;
	}

	private static boolean methodExists(Class ofCaller, String methodName, Class[] types) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "methodExists: caller, methodName, types", new Object[]{ofCaller, methodName, types});
		}

		if (methodName.equals("<init>")) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "methodExists: (constructor) true");
			}

			return true;
		} else {
			try {
				ofCaller.getMethod(methodName, types);
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "methodExists: true");
				}

				return true;
			} catch (NoSuchMethodException var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.cm.proxy.WSJdbcUtil.methodExists", "623");
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "methodExists: false");
				}

				return false;
			}
		}
	}
}