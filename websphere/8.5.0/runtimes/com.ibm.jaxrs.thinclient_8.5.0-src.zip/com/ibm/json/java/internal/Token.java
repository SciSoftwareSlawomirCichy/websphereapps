package com.ibm.json.java.internal;

public class Token {
	public static final Token TokenEOF = new Token();
	public static final Token TokenBraceL = new Token();
	public static final Token TokenBraceR = new Token();
	public static final Token TokenBrackL = new Token();
	public static final Token TokenBrackR = new Token();
	public static final Token TokenColon = new Token();
	public static final Token TokenComma = new Token();
	public static final Token TokenTrue = new Token();
	public static final Token TokenFalse = new Token();
	public static final Token TokenNull = new Token();
	private String valueString;
	private Number valueNumber;

	public Token() {
	}

	public Token(String var1) {
		this.valueString = var1;
	}

	public Token(Number var1) {
		this.valueNumber = var1;
	}

	public String getString() {
		return this.valueString;
	}

	public Number getNumber() {
		return this.valueNumber;
	}

	public boolean isString() {
		return null != this.valueString;
	}

	public boolean isNumber() {
		return null != this.valueNumber;
	}

	public String toString() {
		if (this == TokenEOF) {
			return "Token: EOF";
		} else if (this == TokenBraceL) {
			return "Token: {";
		} else if (this == TokenBraceR) {
			return "Token: }";
		} else if (this == TokenBrackL) {
			return "Token: [";
		} else if (this == TokenBrackR) {
			return "Token: ]";
		} else if (this == TokenColon) {
			return "Token: :";
		} else if (this == TokenComma) {
			return "Token: ,";
		} else if (this == TokenTrue) {
			return "Token: true";
		} else if (this == TokenFalse) {
			return "Token: false";
		} else if (this == TokenNull) {
			return "Token: null";
		} else if (this.isNumber()) {
			return "Token: Number - " + this.getNumber();
		} else {
			return this.isString() ? "Token: String - '" + this.getString() + "'" : "Token: unknown.";
		}
	}
}