package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_it extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: L''RP (relying party-parte affidabile) OpenID non è riuscito a reindirizzare l''utente al provider OpenID (OP) per l''autenticazione a causa dell''eccezione [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: L''inizializzazione dell''RP (relying party-parte affidabile) OpenID ha avuto esito negativo perché non è riuscito a richiamare il contesto SSL predefinito per il server WebSphere. L''eccezione è [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: L''RP (relying party-parte affidabile) OpenID non è riuscito a connettersi al provider OpenID (OP) specificato dall''identificativo [{0}] a causa dell''eccezione [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: L''inizializzazione dell''RP (relying party-parte affidabile) OpenID ha avuto esito negativo a causa dell''eccezione [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: L''RP (relying party-parte affidabile) OpenID non è stato inizializzato  poiché il valore per la proprietà [{0}] non è nel formato corretto."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: L'RP (relying party-parte affidabile) OpenID non è riuscito ad  autenticare una richiesta con il token di autenticazione di base poiché il valore token non è valido."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: L''RP (relying party-parte affidabile) OpenID non è stato inizializzato  poiché la proprietà [{0}] non è specificata correttamente. Deve essere un URL valido."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: L''RP (relying party-parte affidabile) OpenID ha ricevuto una risposta non corretta dal provider OpenID (OP). La causa di questo errore è [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: L'RP (relying party-parte affidabile) OpenID non è stato in grado di eseguire l'autenticazione poiché ha raggiunto la capacità massima della cache interna."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: L'inizializzazione dell'RP (relying party-parte affidabile) OpenID ha avuto esito negativo a causa della proprietà obbligatoria axRequiredAttribute[n] mancante. È necessario definire almeno una proprietà."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: L''inizializzazione dell''RP (relying party-parte affidabile) OpenID ha avuto esito negativo poiché il valore per la proprietà obbligatoria [{0}] manca o è vuoto."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: L''RP (relying party-parte affidabile) OpenID richiede l''SSL (HTTPS) ma l''URL OP è HTTP: [{0}].  L''attributo [{1}] deve corrispondere allo schema URL di destinazione. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: L'RP (relying party-parte affidabile) OpenID ha ricevuto una risposta dal provider OpenID (OP) che non supporta la specifica OpenID versione 2."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: L''RP (relying party-parte affidabile) OpenID ha riportato errore durante la verifica della risposta ricevuta dal provider OpenID (OP). L''eccezione era [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}