package com.ibm.ejs.container.passivator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.StatefulBeanO;
import com.ibm.ejs.container.passivator.EJBObjectInfo.FieldInfo;
import com.ibm.ejs.container.passivator.StatefulPassivator.1;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.SessionBeanStore;
import com.ibm.websphere.csi.StreamUnavailableException;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObjectContext;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.security.AccessController;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public abstract class StatefulPassivator {
	private static final TraceComponent tc = Tr.register(StatefulPassivator.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.passivator.StatefulPassivator";
	private final SessionBeanStore ivBeanStore;
	protected final EJSContainer ivContainer;
	private boolean ivTerminating = false;
	private final Object ivActivateLock;
	private final Object ivPassivateLock;
	private final Object ivRemoveLock;
	private final SfFailoverCache ivStatefulFailoverCache;

	public StatefulPassivator(SessionBeanStore beanStore, EJSContainer container, SfFailoverCache failoverCache) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "StatefulPassivator");
		}

		this.ivBeanStore = beanStore;
		this.ivContainer = container;
		this.ivStatefulFailoverCache = failoverCache;
		this.ivActivateLock = new Object();
		this.ivPassivateLock = new Object();
		this.ivRemoveLock = new Object();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "StatefulPassivator");
		}

	}

	public void passivate(StatefulBeanO beanO, BeanMetaData bmd) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "passivate: " + beanO);
		}

		if (!beanO.isRemoved() && !this.isTerminating()) {
			BeanId bid = beanO.getId();
			Object sb = beanO.ivEjbInstance;
			boolean exceptionCaught = false;
			ObjectOutputStream beanStream = null;
			Object credToken = this.ivContainer.getEJBRuntime().pushServerIdentity();
			ObjectOutputStream beanStream2 = null;
			Object exPC = beanO.getJPAExPcBindingContext();
			boolean var36 = false;

			label433 : {
				try {
					var36 = true;
					ByteArrayOutputStream baos = null;
					long lastAccessTime = beanO.getLastAccessTime();
					Object var14 = this.ivPassivateLock;
					synchronized (this.ivPassivateLock) {
						if (beanO.sfsbFailoverEnabled()) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "failover is enabled");
							}

							if (this.getEJBModuleVersion(beanO) < 30) {
								if (isTraceOn && tc.isDebugEnabled()) {
									Tr.debug(tc, "processing EJB 2.1 module or prior");
								}

								byte[] bytes = this.getCompressedBytes(sb, lastAccessTime, exPC);
								OutputStream ostream = this.ivBeanStore.getOutputStream(bid);
								beanStream = this.createPassivationOutputStream(ostream);
								beanStream.writeInt(bytes.length);
								if (isTraceOn && tc.isDebugEnabled()) {
									Tr.debug(tc, "length of compressed bytes is: " + bytes.length);
								}

								beanStream.write(bytes);
								beanStream.close();
								beanO.updateFailoverEntry(bytes, lastAccessTime);
								var36 = false;
								break label433;
							}

							baos = new ByteArrayOutputStream(1024);
							beanStream = this.createPassivationOutputStream(new GZIPOutputStream(baos));
						} else {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "failover is NOT enabled");
							}

							beanStream = this.createPassivationOutputStream(this.ivBeanStore.getGZIPOutputStream(bid));
						}

						EJBObjectInfo objectInfo = null;
						Map<String, Map<String, Field>> passivatorFields = this.getPassivatorFields(bmd);
						if (sb instanceof Serializable) {
							objectInfo = this.createSerializableObjectInfo(sb);
						} else {
							objectInfo = this.createNonSerializableObjectInfo(sb, passivatorFields);
						}

						beanStream.writeLong(lastAccessTime);
						beanStream.writeObject(exPC);
						beanStream.writeObject(objectInfo);
						this.writeManagedObjectContext(beanStream, beanO.ivEjbManagedObjectContext);
						Object[] interceptors = beanO.ivInterceptors;
						if (interceptors == null) {
							beanStream.writeInt(-1);
						} else {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "Processing " + interceptors.length + " interceptors");
							}

							beanStream.writeInt(interceptors.length);

							for (int i = 0; i < interceptors.length; ++i) {
								Object interceptor = interceptors[i];
								EJBObjectInfo interceptorObjectInfo = null;
								if (interceptor instanceof Serializable) {
									interceptorObjectInfo = this.createSerializableObjectInfo(interceptor);
								} else {
									interceptorObjectInfo = this.createNonSerializableObjectInfo(interceptor,
											passivatorFields);
								}

								beanStream.writeObject(interceptorObjectInfo);
							}
						}

						beanStream.close();
						if (beanO.sfsbFailoverEnabled() && baos != null) {
							byte[] bytes = baos.toByteArray();
							beanStream2 = this.createPassivationOutputStream(this.ivBeanStore.getOutputStream(bid));
							beanStream2.writeInt(bytes.length);
							beanStream2.write(bytes);
							beanStream2.close();
							beanO.updateFailoverEntry(bytes, lastAccessTime);
						}

						var36 = false;
					}
				} catch (CSIException var44) {
					exceptionCaught = true;
					FFDCFilter.processException(var44, "com.ibm.ejs.container.passivator.StatefulPassivator.passivate",
							"113", this);
					throw new RemoteException("passivation failed", var44);
				} catch (Throwable var45) {
					exceptionCaught = true;
					FFDCFilter.processException(var45, "com.ibm.ejs.container.passivator.StatefulPassivator.passivate",
							"107", this);
					Tr.warning(tc, "CANNOT_PASSIVATE_STATEFUL_BEAN_CNTR0001W",
							new Object[]{beanO.toString(), this, var45});
					throw new RemoteException("passivation failed", var45);
				} finally {
					if (var36) {
						if (credToken != null) {
							this.ivContainer.getEJBRuntime().popServerIdentity(credToken);
						}

						if (exceptionCaught) {
							try {
								if (beanStream != null) {
									beanStream.close();
									Object var24 = this.ivRemoveLock;
									synchronized (this.ivRemoveLock) {
										this.ivBeanStore.remove(bid);
									}
								}

								if (beanStream2 != null) {
									beanStream2.close();
								}
							} catch (Exception var40) {
								if (isTraceOn && tc.isDebugEnabled()) {
									Tr.debug(tc, "exception closing stream", var40);
								}
							}
						}

					}
				}

				if (credToken != null) {
					this.ivContainer.getEJBRuntime().popServerIdentity(credToken);
				}

				if (exceptionCaught) {
					try {
						if (beanStream != null) {
							beanStream.close();
							Object var47 = this.ivRemoveLock;
							synchronized (this.ivRemoveLock) {
								this.ivBeanStore.remove(bid);
							}
						}

						if (beanStream2 != null) {
							beanStream2.close();
						}
					} catch (Exception var42) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "exception closing stream", var42);
						}
					}
				}

				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "passivate");
				}

				return;
			}

			if (credToken != null) {
				this.ivContainer.getEJBRuntime().popServerIdentity(credToken);
			}

			if (exceptionCaught) {
				try {
					if (beanStream != null) {
						beanStream.close();
						Object var50 = this.ivRemoveLock;
						synchronized (this.ivRemoveLock) {
							this.ivBeanStore.remove(bid);
						}
					}

					if (beanStream2 != null) {
						beanStream2.close();
					}
				} catch (Exception var41) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "exception closing stream", var41);
					}
				}
			}

		} else {
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Bean removed!");
			}

		}
	}

	public void activate(StatefulBeanO beanO, BeanMetaData bmd) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "activate: " + beanO);
		}

		Object sb = null;
		ManagedObjectContext ejbState = null;
		BeanId bid = beanO.getId();
		ClassLoader classLoader = bmd.classLoader;
		Object credToken = this.ivContainer.getEJBRuntime().pushServerIdentity();
		ObjectInputStream beanStream = null;
		GZIPInputStream istream = null;

		try {
			Object var11 = this.ivActivateLock;
			synchronized (this.ivActivateLock) {
				if (!beanO.sfsbFailoverEnabled()) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Failover is NOT enabled");
					}

					istream = this.ivBeanStore.getGZIPInputStream(bid);
					beanStream = this.createActivationInputStream(istream, beanO, classLoader);
				} else {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Failover is enabled");
					}

					byte[] data = null;
					byte[] data;
					if (this.ivStatefulFailoverCache.beanExists(bid)) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Retrieving data from failover cache");
						}

						boolean isSticky = this.ivStatefulFailoverCache.inStickyUOW(bid);
						data = this.ivStatefulFailoverCache.getAndRemoveData(bid, beanO.ivSfFailoverClient);
						if (isSticky) {
							throw new NoSuchObjectException(
									"Bean Managed Transaction is active, SFSB failover not supported");
						}

						if (data == null) {
							throw new NoSuchObjectException("SFSB replication failed.");
						}
					} else {
						InputStream fis = this.ivBeanStore.getInputStream(bid);
						ObjectInputStream beanStream2 = this.createActivationInputStream(fis, beanO, classLoader);
						int n = beanStream2.readInt();
						data = new byte[n];
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "length of compressed bytes is: " + n);
						}

						int bytesRead = false;

						int bytesRead;
						for (int offset = 0; offset < n; offset += bytesRead) {
							bytesRead = beanStream2.read(data, offset, n - offset);
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "bytes read from input stream is: " + bytesRead);
							}

							if (bytesRead == -1) {
								throw new IOException("end of input stream while reading compressed bytes");
							}
						}

						beanStream2.close();
					}

					ByteArrayInputStream bais = new ByteArrayInputStream(data);
					istream = new GZIPInputStream(bais);
					beanStream = this.createActivationInputStream(istream, beanO, classLoader);
				}

				boolean oldFormat = beanO.sfsbFailoverEnabled() && this.getEJBModuleVersion(beanO) < 30;
				long lastAccessTime = beanStream.readLong();
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "read from data last access time: " + lastAccessTime);
				}

				beanO.setLastAccessTime(lastAccessTime);
				Object exPC = beanStream.readObject();
				beanO.setJPAExPcBindingContext(exPC);
				Map<String, Map<String, Field>> passivatorFields = null;
				if (oldFormat) {
					sb = beanStream.readObject();
					ejbState = null;
				} else {
					EJBObjectInfo sbObjectInfo = (EJBObjectInfo) beanStream.readObject();
					passivatorFields = this.getPassivatorFields(bmd);
					if (sbObjectInfo.isSerializable()) {
						sb = sbObjectInfo.getSerializableObject();
					} else {
						sb = this.activateObjectFromInfo(sbObjectInfo, bmd.enterpriseBeanClass, passivatorFields);
					}

					ejbState = this.readManagedObjectContext(beanStream, bmd, sb);
					int expectedNumInterceptors = 0;
					if (bmd.ivInterceptorMetaData != null && bmd.ivInterceptorMetaData.ivInterceptorClasses != null) {
						expectedNumInterceptors = bmd.ivInterceptorMetaData.ivInterceptorClasses.length;
					}

					int n = beanStream.readInt();
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "number of interceptors is " + n);
					}

					if (n == -1) {
						n = 0;
					}

					if (n != expectedNumInterceptors) {
						throw new RemoteException("interceptor count " + n
								+ " in serialization data does not match actual count " + expectedNumInterceptors);
					}

					if (n != 0) {
						Class<?>[] interceptorClasses = bmd.ivInterceptorMetaData.ivInterceptorClasses;
						Object[] interceptors = new Object[n];

						for (int i = 0; i < n; ++i) {
							EJBObjectInfo interceptorObjectInfo = (EJBObjectInfo) beanStream.readObject();
							if (interceptorObjectInfo.isSerializable()) {
								interceptors[i] = interceptorObjectInfo.getSerializableObject();
							} else {
								interceptors[i] = this.activateObjectFromInfo(interceptorObjectInfo,
										interceptorClasses[i], passivatorFields);
							}
						}

						beanO.setInterceptors(interceptors);
					}

					beanO.setLastAccessTime(lastAccessTime);
				}

				beanStream.close();
			}

			beanO.setEnterpriseBean(sb, ejbState);
			var11 = this.ivRemoveLock;
			synchronized (this.ivRemoveLock) {
				this.ivBeanStore.remove(bid);
			}
		} catch (StreamUnavailableException var37) {
			FFDCFilter.processException(var37, "com.ibm.ejs.container.passivator.StatefulPassivator.activate", "146",
					this);
			throw new NoSuchObjectException("");
		} catch (CSIException var38) {
			FFDCFilter.processException(var38, "com.ibm.ejs.container.passivator.StatefulPassivator.activate", "149",
					this);
			throw new RemoteException("activation failed", var38);
		} catch (ClassNotFoundException var39) {
			FFDCFilter.processException(var39, "com.ibm.ejs.container.passivator.StatefulPassivator.activate", "152",
					this);
			Tr.warning(tc, "CANNOT_ACTIVATE_STATEFUL_BEAN_CNTR0003W", new Object[]{beanO.toString(), this, var39});
			throw new RemoteException("", var39);
		} catch (RemoteException var40) {
			FFDCFilter.processException(var40, "com.ibm.ejs.container.passivator.StatefulPassivator.activate", "576",
					this);
			Tr.warning(tc, "CANNOT_ACTIVATE_STATEFUL_BEAN_CNTR0003W", new Object[]{beanO.toString(), this, var40});
			throw var40;
		} catch (IOException var41) {
			FFDCFilter.processException(var41, "com.ibm.ejs.container.passivator.StatefulPassivator.activate", "157",
					this);
			Tr.warning(tc, "CANNOT_ACTIVATE_STATEFUL_BEAN_CNTR0003W", new Object[]{beanO.toString(), this, var41});
			throw new RemoteException("", var41);
		} finally {
			if (credToken != null) {
				this.ivContainer.getEJBRuntime().popServerIdentity(credToken);
			}

		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "activate");
		}

	}

	public void remove(BeanId beanId, boolean removeFromFailoverCache) throws RemoteException {
		if (this.ivStatefulFailoverCache != null && this.ivStatefulFailoverCache.beanExists(beanId)) {
			if (removeFromFailoverCache) {
				this.ivStatefulFailoverCache.removeCacheEntry(beanId);
			}
		} else {
			Object var3 = this.ivRemoveLock;
			synchronized (this.ivRemoveLock) {
				this.ivBeanStore.remove(beanId);
			}
		}

	}

	public synchronized void terminate() {
		this.ivTerminating = true;
	}

	private synchronized boolean isTerminating() {
		return this.ivTerminating;
	}

	protected abstract ObjectOutputStream createPassivationOutputStream(OutputStream var1) throws IOException;

	protected abstract ObjectInputStream createActivationInputStream(InputStream var1, StatefulBeanO var2,
			ClassLoader var3) throws IOException;

	protected abstract void writeManagedObjectContext(ObjectOutputStream var1, ManagedObjectContext var2)
			throws IOException;

	protected abstract ManagedObjectContext readManagedObjectContext(ObjectInputStream var1, BeanMetaData var2,
			Object var3) throws IOException, ClassNotFoundException;

	private byte[] getCompressedBytes(Object sb, long lastAccessTime, Object exPC) throws IOException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getCompressedBytes", sb);
		}

		ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
		GZIPOutputStream gout = new GZIPOutputStream(baos);
		ObjectOutputStream beanStream2 = this.createPassivationOutputStream(gout);
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "writing failover data with last access time set to: " + lastAccessTime);
		}

		beanStream2.writeLong(lastAccessTime);
		beanStream2.writeObject(exPC);
		beanStream2.writeObject(sb);
		gout.finish();
		gout.close();
		beanStream2.close();
		byte[] bytes = baos.toByteArray();
		baos.close();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getCompressedBytes");
		}

		return bytes;
	}

	private static void collectPassivatorFields(Class<?> klass, Map<String, Map<String, Field>> allFields) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "collectPassivatorFields: " + klass.getName());
		}

		if (Serializable.class.isAssignableFrom(klass)) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "collectPassivatorFields: serializable");
			}

		} else {
			for (Class classIter = klass; classIter != Object.class; classIter = classIter.getSuperclass()) {
				String className = classIter.getName();
				Map<String, Field> classPassivatorFields = (Map) allFields.get(className);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, classIter + ", cached = " + (classPassivatorFields != null));
				}

				if (classPassivatorFields == null) {
					Map<String, Field> classPassivatorFields = new LinkedHashMap();
					allFields.put(className, classPassivatorFields);
					Field[] fields = classIter.getDeclaredFields();
					AccessibleObject.setAccessible(fields, true);
					Field[] arr$ = fields;
					int len$ = fields.length;

					for (int i$ = 0; i$ < len$; ++i$) {
						Field field = arr$[i$];
						int modifiers = field.getModifiers();
						if (!Modifier.isStatic(modifiers) && !Modifier.isTransient(modifiers)) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "adding " + field);
							}

							classPassivatorFields.put(field.getName(), field);
						} else if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "ignoring " + field);
						}
					}
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "collectPassivatorFields");
			}

		}
	}

	public Map<String, Map<String, Field>> getPassivatorFields(BeanMetaData bmd) {
      Map<String, Map<String, Field>> result = bmd.ivPassivatorFields;
      if (result == null) {
         result = (Map)AccessController.doPrivileged(new 1(this, bmd));
         bmd.ivPassivatorFields = result;
      }

      return result;
   }

	private EJBObjectInfo createNonSerializableObjectInfo(Object obj, Map<String, Map<String, Field>> passivatorFields)
			throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createNonSerializableObjectInfo", obj);
		}

		EJBObjectInfo ejbObjectInfo = new EJBObjectInfo();
		ejbObjectInfo.setSerializable(false);
		Class<?> clazz = obj.getClass();
		ejbObjectInfo.setClassName(clazz.getName());

		for (Class classIter = clazz; classIter != Object.class; classIter = classIter.getSuperclass()) {
			String className = classIter.getName();
			Map<String, Field> classPassivatorFields = (Map) passivatorFields.get(className);
			List<FieldInfo> fieldInfoList = new ArrayList(classPassivatorFields.size());
			Iterator i$ = classPassivatorFields.values().iterator();

			while (i$.hasNext()) {
				Field field = (Field) i$.next();
				FieldInfo fieldInfo = this.generateFieldInfo(obj, field);
				fieldInfoList.add(fieldInfo);
			}

			ejbObjectInfo.addFieldInfo(className, fieldInfoList);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createNonSerializableObjectInfo", ejbObjectInfo);
		}

		return ejbObjectInfo;
	}

	private EJBObjectInfo createSerializableObjectInfo(Object parentObj) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createSerializableObjectInfo", parentObj);
		}

		EJBObjectInfo objectInfo = new EJBObjectInfo();
		objectInfo.setSerializable(true);
		objectInfo.setSerializableObject(parentObj);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createSerializableObjectInfo", objectInfo);
		}

		return objectInfo;
	}

	private FieldInfo generateFieldInfo(Object obj, Field field) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "generateFieldInfo", field);
		}

		FieldInfo fieldInfo = new FieldInfo();
		String fieldName = field.getName();
		Object fieldObj = null;

		try {
			fieldObj = field.get(obj);
		} catch (IllegalArgumentException var8) {
			FFDCFilter.processException(var8, "com.ibm.ejs.container.passivator.StatefulPassivator.generateFieldInfo",
					"851", this);
			throw new RemoteException("passivation failed", var8);
		} catch (IllegalAccessException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.container.passivator.StatefulPassivator.generateFieldInfo",
					"857", this);
			throw new RemoteException("passivation failed", var9);
		}

		fieldInfo.name = fieldName;
		fieldInfo.value = fieldObj;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "generateFieldInfo", fieldInfo);
		}

		return fieldInfo;
	}

	private Object activateObjectFromInfo(EJBObjectInfo ejbObjectInfo, Class<?> objClass,
			Map<String, Map<String, Field>> passivatorFields) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "activateObjectFromInfo", new Object[]{ejbObjectInfo, objClass});
		}

		Object obj = null;

		try {
			if (!objClass.getName().equals(ejbObjectInfo.getClassName())) {
				throw new RemoteException("serialization data for class " + ejbObjectInfo.getClassName()
						+ " does not match actual class name " + objClass.getName());
			}

			obj = objClass.newInstance();
			Map<String, List<FieldInfo>> fieldInfoMap = ejbObjectInfo.getFieldInfoMap();

			for (Class classIter = objClass; classIter != Object.class; classIter = classIter.getSuperclass()) {
				String className = classIter.getName();
				Map<String, Field> classPassivatorFields = (Map) passivatorFields.get(className);
				List<FieldInfo> fieldInfoList = (List) fieldInfoMap.get(className);
				Iterator i$ = fieldInfoList.iterator();

				while (i$.hasNext()) {
					FieldInfo fieldInfo = (FieldInfo) i$.next();
					Field field = (Field) classPassivatorFields.get(fieldInfo.name);
					field.set(obj, fieldInfo.value);
				}
			}
		} catch (Throwable var14) {
			FFDCFilter.processException(var14,
					"com.ibm.ejs.container.passivator.StatefulPassivator.activateObjectFromInfo", "843", this);
			throw new RemoteException("activation failed", var14);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "activateObjectFromInfo", obj);
		}

		return obj;
	}

	private int getEJBModuleVersion(StatefulBeanO beanO) {
		BeanId beanId = beanO.getId();
		BeanMetaData beanMetaData = beanId.getBeanMetaData();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "EJB module version is " + beanMetaData.ivModuleVersion);
		}

		return beanMetaData.ivModuleVersion;
	}
}