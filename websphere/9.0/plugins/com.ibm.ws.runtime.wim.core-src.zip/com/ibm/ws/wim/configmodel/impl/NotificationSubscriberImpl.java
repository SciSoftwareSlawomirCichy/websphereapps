package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.NotificationSubscriber;
import java.util.List;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class NotificationSubscriberImpl extends EDataObjectImpl implements NotificationSubscriber {
	protected static final String NOTIFICATION_SUBSCRIBER_REFERENCE_EDEFAULT = null;
	protected String notificationSubscriberReference;
	protected static final List REALM_LIST_EDEFAULT;
	protected List realmList;
	protected boolean realmListESet;

	protected NotificationSubscriberImpl() {
		this.notificationSubscriberReference = NOTIFICATION_SUBSCRIBER_REFERENCE_EDEFAULT;
		this.realmList = REALM_LIST_EDEFAULT;
		this.realmListESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getNotificationSubscriber();
	}

	public String getNotificationSubscriberReference() {
		return this.notificationSubscriberReference;
	}

	public void setNotificationSubscriberReference(String var1) {
		String var2 = this.notificationSubscriberReference;
		this.notificationSubscriberReference = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.notificationSubscriberReference));
		}

	}

	public List getRealmList() {
		return this.realmList;
	}

	public void setRealmList(List var1) {
		List var2 = this.realmList;
		this.realmList = var1;
		boolean var3 = this.realmListESet;
		this.realmListESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.realmList, !var3));
		}

	}

	public void unsetRealmList() {
		List var1 = this.realmList;
		boolean var2 = this.realmListESet;
		this.realmList = REALM_LIST_EDEFAULT;
		this.realmListESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 1, var1, REALM_LIST_EDEFAULT, var2));
		}

	}

	public boolean isSetRealmList() {
		return this.realmListESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getNotificationSubscriberReference();
			case 1 :
				return this.getRealmList();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setNotificationSubscriberReference((String) var2);
				return;
			case 1 :
				this.setRealmList((List) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setNotificationSubscriberReference(NOTIFICATION_SUBSCRIBER_REFERENCE_EDEFAULT);
				return;
			case 1 :
				this.unsetRealmList();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return NOTIFICATION_SUBSCRIBER_REFERENCE_EDEFAULT == null
						? this.notificationSubscriberReference != null
						: !NOTIFICATION_SUBSCRIBER_REFERENCE_EDEFAULT.equals(this.notificationSubscriberReference);
			case 1 :
				return this.isSetRealmList();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (notificationSubscriberReference: ");
			var1.append(this.notificationSubscriberReference);
			var1.append(", realmList: ");
			if (this.realmListESet) {
				var1.append(this.realmList);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}

	static {
		REALM_LIST_EDEFAULT = (List) ConfigmodelFactory.eINSTANCE
				.createFromString(ConfigmodelPackage.eINSTANCE.getRealmListType1(), "All");
	}
}