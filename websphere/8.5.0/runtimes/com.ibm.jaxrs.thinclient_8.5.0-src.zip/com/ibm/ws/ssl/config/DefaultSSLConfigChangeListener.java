package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ssl.SSLConfigChangeEvent;
import com.ibm.websphere.ssl.SSLConfigChangeListener;
import java.util.ArrayList;
import java.util.List;

public class DefaultSSLConfigChangeListener implements SSLConfigChangeListener {
	private ArrayList defaultEventList = new ArrayList();
	private SSLConfigChangeEvent lastEvent = null;
	private static final TraceComponent tc = Tr.register(DefaultSSLConfigChangeListener.class, "SSL",
			"com.ibm.ws.ssl.resources.ssl");

	public void stateChanged(SSLConfigChangeEvent e) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "stateChanged", new Object[]{e});
		}

		this.lastEvent = e;
		this.defaultEventList.add(e);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "stateChanged");
		}

	}

	public SSLConfigChangeEvent getLastEvent() {
		return this.lastEvent;
	}

	public List getEventList() {
		return this.defaultEventList;
	}
}