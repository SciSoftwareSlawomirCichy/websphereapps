package com.ibm.ejs.container;

import javax.ejb.EnterpriseBean;

public class BeanManagedBeanO {
	final EntityBeanO ivDelegate;

	BeanManagedBeanO(EntityBeanO delegate) {
		this.ivDelegate = delegate;
	}

	public EnterpriseBean getEnterpriseBean() {
		return (EnterpriseBean) this.ivDelegate.getBeanInstance();
	}
}