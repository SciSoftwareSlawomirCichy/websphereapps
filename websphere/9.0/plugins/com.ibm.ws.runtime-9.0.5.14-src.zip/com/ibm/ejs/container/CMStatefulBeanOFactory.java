package com.ibm.ejs.container;

public class CMStatefulBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, EJSHome h) {
		return new CMStatefulBeanO(c, h);
	}
}