package com.ibm.ws.wim.util;

import java.text.StringCharacterIterator;

public class StringUtil {
	private static final int xorB = 24415;

	public static String toString(byte[] var0) {
		StringBuffer var1 = new StringBuffer();
		int var2 = 0;

		for (int var3 = var0.length; var2 < var3; ++var2) {
			var1.append((char) (var0[var2] & 255));
		}

		String var4 = var1.toString();
		return var4;
	}

	public static byte[] getBytes(String var0) {
		StringBuffer var1 = new StringBuffer(var0);
		byte[] var2 = new byte[var1.length()];
		int var3 = 0;

		for (int var4 = var1.length(); var3 < var4; ++var3) {
			var2[var3] = (byte) var1.charAt(var3);
		}

		return var2;
	}

	public static String encrypt(String var0) {
		StringBuffer var1 = new StringBuffer(var0);
		char[] var2 = var0.toCharArray();
		int var3 = 0;

		for (int var4 = var0.length(); var3 < var4; ++var3) {
			var1.setCharAt(var3, (char) (var2[var3] ^ 24415));
		}

		return "X" + var1.toString();
	}

	public static String decrypt(String var0) {
		String var1 = var0.substring(1);
		StringBuffer var2 = new StringBuffer(var1);
		char[] var3 = var1.toCharArray();
		int var4 = 0;

		for (int var5 = var1.length(); var4 < var5; ++var4) {
			var2.setCharAt(var4, (char) (var3[var4] ^ 24415));
		}

		return var2.toString();
	}

	public static boolean endsWithIgnoreCase(String var0, String var1) {
		if (var0 != null && var1 != null) {
			int var2 = var0.length();
			int var3 = var1.length();
			if (var2 < var3) {
				return false;
			} else {
				return var0.regionMatches(true, var2 - var3, var1, 0, var3);
			}
		} else {
			return false;
		}
	}

	public static boolean startsWithIgnoreCase(String var0, String var1) {
		if (var0 != null && var1 != null) {
			int var2 = var0.length();
			int var3 = var1.length();
			if (var2 < var3) {
				return false;
			} else {
				return var0.regionMatches(true, 0, var1, 0, var3);
			}
		} else {
			return false;
		}
	}

	public static int containsIgnoreCase(String var0, String var1) {
		if (var0 != null && var1 != null) {
			int var2 = var0.length();
			int var3 = var1.length();
			if (var2 < var3) {
				return -1;
			} else {
				for (int var4 = 0; var4 <= var2 - var3; ++var4) {
					if (var0.regionMatches(true, var4, var1, 0, var3)) {
						return var4;
					}
				}

				return -1;
			}
		} else {
			return -1;
		}
	}

	public static String escapeSearchExpression(String var0) {
		StringBuffer var1 = new StringBuffer();
		StringCharacterIterator var2 = new StringCharacterIterator(var0);

		for (char var3 = var2.current(); var3 != '￿'; var3 = var2.next()) {
			if (var3 == '\'') {
				var1.append("''");
			} else if (var3 == '"') {
				var1.append("\"\"");
			} else {
				var1.append(var3);
			}
		}

		return var1.toString();
	}
}