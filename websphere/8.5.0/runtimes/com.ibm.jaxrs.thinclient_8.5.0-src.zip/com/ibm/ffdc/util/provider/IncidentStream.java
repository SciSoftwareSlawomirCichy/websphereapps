package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.Manager;
import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.config.IncidentStream.Writer;
import com.ibm.ffdc.util.Klass;
import com.ibm.ffdc.util.provider.IncidentStream.1;
import com.ibm.ffdc.util.provider.IncidentStream.2;
import com.ibm.ffdc.util.provider.IncidentStream.IOEx;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.PrivilegedActionException;
import java.util.IdentityHashMap;
import java.util.logging.Logger;

public class IncidentStream<T extends FfdcProvider> extends FfdcProviderDependent<T>
		implements
			com.ibm.ffdc.config.IncidentStream,
			Cloneable {
	private final IdentityHashMap<Object, Object> history;
	private PrintStream pw;
	private final Formatters formatters;
	private final OutputStream os;
	private int introspectDepth;
	private int depth;
	private static int MAX_INTROSPECT_DEPTH = 4;

	public IncidentStream(T provider, OutputStream os) {
		this(provider, os, new Formatters(provider));
	}

	public IncidentStream(T provider, OutputStream os, Formatters formatters) {
		this(provider, os, formatters, MAX_INTROSPECT_DEPTH);
	}

	public IncidentStream(T provider, OutputStream os, Formatters formatters, int introspectDepth) {
		super(provider);
		this.history = new IdentityHashMap();
		this.introspectDepth = 4;
		this.formatters = formatters;
		this.os = os;
		this.introspectDepth = introspectDepth;
		this.pw = new PrintStream(os);
	}

	public void writeSimple(String label, Object o, boolean addNewLine) {
		int indent = this.depth - 1;
		if (label != null && label.endsWith("BEGIN")) {
			--indent;
		}

		for (int i = 0; i < indent; ++i) {
			this.pw.print(' ');
		}

		if (label != null && label.length() > 0) {
			this.pw.print(label);
			this.pw.print(":");
		}

		this.pw.print(o);
		if (addNewLine) {
			this.pw.println();
		}

	}

	public void write(String label, Object value, int depth) {
		if (depth > 0 && depth <= 10) {
			int oldDepth = this.introspectDepth;
			this.introspectDepth += depth;

			try {
				this.writeSimple((String) null, "IntrospectDepth set from:" + oldDepth + " to: " + this.introspectDepth,
						true);
				this.write(label, value);
			} finally {
				this.introspectDepth = oldDepth;
				this.writeSimple((String) null, "IntrospectDepth reset to:" + this.introspectDepth, true);
			}

		} else {
			Manager.Ffdc.log(new IllegalArgumentException(), this, this.getClass().getName(), "86");
		}
	}

	public final void write(String label, Object object) {
		if (this.isSimple(object)) {
			this.writeSimple(label, object, true);
		} else {
			String tag = o2tag(object);
			if (this.hasWritten(object)) {
				this.writeSimple(label, tag, true);
			} else {
				try {
					if (this.introspectDepth < 0 || ++this.depth <= this.introspectDepth) {
						this.writeSimple((label == null ? "" : label + " ") + "BEGIN", tag, true);
						this.write(object);
						this.writeSimple("END", tag, true);
						this.pw.println();
						return;
					}

					this.writeSimple(label, tag + " depth limit reached", true);
				} catch (IOEx var16) {
					this.recover(tag, var16);
					return;
				} catch (IOException var17) {
					this.recover(tag, var17);
					return;
				} catch (PrivilegedActionException var18) {
					this.report(tag, var18);
					return;
				} catch (RuntimeException var19) {
					this.report(tag, var19);
					return;
				} catch (NoClassDefFoundError var20) {
					this.report(tag, var20);
					return;
				} catch (StackOverflowError var21) {
					try {
						this.pw.println(" ... truncated ...");
					} catch (StackOverflowError var15) {
						;
					}

					return;
				} finally {
					if (this.introspectDepth > 0) {
						--this.depth;
					}

				}

			}
		}
	}

	static String o2tag(Object o) {
		String tag = o.getClass().getName() + "@";

		try {
			int hashcode = System.identityHashCode(o);
			return tag + Integer.toHexString(hashcode);
		} catch (Throwable var3) {
			return tag + "null";
		}
	}

	private void recover(String tag, Exception e) {
		this.pw.println();
		boolean trouble = this.pw.checkError();
		if (trouble) {
			this.provider.abort(e);
			throw new IllegalStateException(e);
		} else {
			this.report(tag, e);
		}
	}

	private void report(String tag, Throwable e) {
		Manager.Ffdc.log(e, this, this.getClass().getName(), "report");
		this.writeSimple("FAILED", tag, true);
		this.pw.println();
	}

	private void write(Object object) throws IOException, PrivilegedActionException {
      Formatter f = this.formatters.getFormatter(object);
      Object isWriter;
      if (f == Formatters.FormattableMarker) {
         isWriter = new 1(this, object);
      } else {
         isWriter = new 2(this, f, object);
      }

      ((Writer)isWriter).writeTo(this.os);
   }

	public void write(Writer<OutputStream> isWriter) {
		try {
			isWriter.writeTo(this.os);
		} catch (IOException var3) {
			throw new IOEx(var3);
		}
	}

	public void release() {
		this.pw = null;
		this.formatters.clear();
	}

	protected boolean hasWritten(Object object) {
		try {
			Object old = this.history.put(object, object);
			return object == old;
		} catch (Throwable var3) {
			Manager.Ffdc.log(var3, this, this.getClass().getName(), "212", new Object[]{object.getClass().getName()});
			return true;
		}
	}

	private boolean isSimple(Object o) {
		return o == null || o instanceof Class || o instanceof String || o instanceof Logger
				|| Klass.isPrimitive(o.getClass()) || Object.class.equals(o.getClass());
	}
}