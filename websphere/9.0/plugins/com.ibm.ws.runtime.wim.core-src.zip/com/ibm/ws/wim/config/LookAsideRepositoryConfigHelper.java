package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.PropertyExtensionRepositoryType;
import commonj.sdo.DataObject;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LookAsideRepositoryConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public String setIdMgrLookAsideRepository(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setIdMgrLookAsideRepository",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var5 = (String) var2.get("dataSourceName");
		String var6 = (String) var2.get("databaseType");
		String var7 = (String) var2.get("dbURL");
		Integer var8 = (Integer) var2.get("entityRetrievalLimit");
		ValidationHelper.validateIntegerInput("entityRetrievalLimit", CLASSNAME, "setIdMgrLookAsideRepository", var8);
		ConfigurationProviderType var9 = ConfigUtils.getConfigProvider(var1);
		PropertyExtensionRepositoryType var10 = var9.getPropertyExtensionRepository();
		if (var10 == null) {
			ValidationHelper.validateRequiredDBParameters(var2, CLASSNAME, "setIdMgrLookAsideRepository");
			ConfigValidator.validateDBParams("LA", var2);
			var10 = var9.createPropertyExtensionRepository();
			var10.setId("LA");
			var10.setAdapterClassName("com.ibm.ws.wim.lookaside.LookasideAdapter");
			var10.setEntityRetrievalLimit(new Integer("12"));
		} else {
			HashMap var11 = new HashMap();
			boolean var12 = ConfigUtils.buildMapFromOldAndNewValues(var11, ConfigValidator.DB_CONNECTION_PARAMS,
					(DataObject) var10, var2);
			if (var12) {
				ConfigValidator.validateDBParams("LA", var11);
			}
		}

		if (var6 != null) {
			var10.setDatabaseType(var6);
		}

		if (var5 != null) {
			var10.setDataSourceName(var5);
		}

		if (var7 != null) {
			var10.setDbURL(var7);
		}

		if (var2.get("dbAdminId") != null) {
			var10.setDbAdminId((String) var2.get("dbAdminId"));
		}

		if (var2.get("dbAdminPassword") != null) {
			var10.setDbAdminPassword(ConfigUtils.encodePassword((String) var2.get("dbAdminPassword")));
		}

		if (var2.get("JDBCDriverClass") != null) {
			var10.setJDBCDriverClass((String) var2.get("JDBCDriverClass"));
		}

		if (var8 != null) {
			var10.setEntityRetrievalLimit(var8);
		}

		if (var2.get("dbSchema") != null) {
			var10.setDbSchema((String) var2.get("dbSchema"));
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "setIdMgrLookAsideRepository");
		}

		return ConfigUtils.saveConfig(var1);
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = LookAsideRepositoryConfigHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}