package com.ibm.ws.ffdc;

interface package-info {
}