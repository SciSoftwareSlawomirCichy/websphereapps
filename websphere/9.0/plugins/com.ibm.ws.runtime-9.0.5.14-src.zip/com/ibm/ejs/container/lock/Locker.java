package com.ibm.ejs.container.lock;

public interface Locker extends LockProxy {
	int getLockMode(Object var1);
}