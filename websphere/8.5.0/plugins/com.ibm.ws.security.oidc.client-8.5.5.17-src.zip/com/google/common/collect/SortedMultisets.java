package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.Multiset.Entry;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
final class SortedMultisets {
	private static <E> E getElementOrThrow(Entry<E> entry) {
		if (entry == null) {
			throw new NoSuchElementException();
		} else {
			return entry.getElement();
		}
	}

	private static <E> E getElementOrNull(@NullableDecl Entry<E> entry) {
		return entry == null ? null : entry.getElement();
	}
}