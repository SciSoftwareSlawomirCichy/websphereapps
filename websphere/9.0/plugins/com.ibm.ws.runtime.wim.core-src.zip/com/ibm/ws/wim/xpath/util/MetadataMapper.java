package com.ibm.ws.wim.xpath.util;

public interface MetadataMapper {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";

	boolean isPropertyInRepository(String var1, String var2);

	boolean isPropertyInLookAside(String var1, String var2);

	boolean isValidEntityType(String var1);
}