package com.ibm.icu.impl;

import com.ibm.icu.impl.TextTrieMap.1;
import com.ibm.icu.impl.TextTrieMap.CharacterNode;
import com.ibm.icu.impl.TextTrieMap.LongestMatchHandler;
import com.ibm.icu.impl.TextTrieMap.ResultHandler;
import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.UTF16;
import java.util.Iterator;
import java.util.List;

public class TextTrieMap<V> {
	private TextTrieMap<V>.CharacterNode root = new CharacterNode(this, 0);
	boolean ignoreCase;

	public TextTrieMap(boolean ignoreCase) {
		this.ignoreCase = ignoreCase;
	}

	public synchronized void put(String text, V o) {
		TextTrieMap<V>.CharacterNode node = this.root;

		for (int i = 0; i < text.length(); ++i) {
			int ch = UTF16.charAt(text, i);
			node = node.addChildNode(ch);
			if (UTF16.getCharCount(ch) == 2) {
				++i;
			}
		}

		node.addObject(o);
	}

	public Iterator<V> get(String text) {
		return this.get(text, 0);
	}

	public Iterator<V> get(String text, int start) {
      LongestMatchHandler<V> handler = new LongestMatchHandler((1)null);
      this.find(text, start, handler);
      return handler.getMatches();
   }

	public void find(String text, ResultHandler<V> handler) {
		this.find(text, 0, handler);
	}

	public void find(String text, int start, ResultHandler<V> handler) {
		this.find(this.root, text, start, start, handler);
	}

	private synchronized void find(TextTrieMap<V>.CharacterNode node, String text, int start, int index,
			ResultHandler<V> handler) {
		Iterator<V> itr = node.iterator();
		if (itr == null || handler.handlePrefixMatch(index - start, itr)) {
			if (index < text.length()) {
				List<TextTrieMap<V>.CharacterNode> childNodes = node.getChildNodes();
				if (childNodes == null) {
					return;
				}

				int ch = UTF16.charAt(text, index);
				int chLen = UTF16.getCharCount(ch);

				for (int i = 0; i < childNodes.size(); ++i) {
					TextTrieMap<V>.CharacterNode child = (CharacterNode) childNodes.get(i);
					if (this.compare(ch, child.getCharacter())) {
						this.find(child, text, start, index + chLen, handler);
						break;
					}
				}
			}

		}
	}

	private boolean compare(int ch1, int ch2) {
		if (ch1 == ch2) {
			return true;
		} else {
			if (this.ignoreCase) {
				if (UCharacter.toLowerCase(ch1) == UCharacter.toLowerCase(ch2)) {
					return true;
				}

				if (UCharacter.toUpperCase(ch1) == UCharacter.toUpperCase(ch2)) {
					return true;
				}
			}

			return false;
		}
	}
}