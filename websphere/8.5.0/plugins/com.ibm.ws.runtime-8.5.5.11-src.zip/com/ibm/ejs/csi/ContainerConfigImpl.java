package com.ibm.ejs.csi;

import com.ibm.ejs.container.DispatchEventListenerManager;
import com.ibm.ejs.container.EntityHelper;
import com.ibm.ejs.container.passivator.StatefulPassivator;
import com.ibm.websphere.cpi.PersisterFactory;
import com.ibm.websphere.csi.ContainerConfig;
import com.ibm.websphere.csi.ContainerExtensionFactory;
import com.ibm.websphere.csi.EJBCache;
import com.ibm.websphere.csi.J2EENameFactory;
import com.ibm.websphere.csi.OrbUtils;
import com.ibm.websphere.csi.PassivationPolicy;
import com.ibm.websphere.csi.StatefulSessionHandleFactory;
import com.ibm.websphere.csi.StatefulSessionKeyFactory;
import com.ibm.ws.ejbcontainer.EJBPMICollaboratorFactory;
import com.ibm.ws.ejbcontainer.EJBRequestCollaborator;
import com.ibm.ws.ejbcontainer.EJBSecurityCollaborator;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ejbcontainer.runtime.EJBRuntime;
import com.ibm.ws.ejbcontainer.util.PoolManager;
import com.ibm.ws.util.StatefulBeanEnqDeq;

public class ContainerConfigImpl implements ContainerConfig {
	private EJBRuntime ivEJBRuntime;
	private ClassLoader classLoader;
	private String containerName;
	private EJBCache ejbCache;
	private EJBCache wrapperCache;
	private PassivationPolicy passivationPolicy;
	private PersisterFactory persisterFactory;
	private EntityHelper ivEntityHelper;
	private EJBPMICollaboratorFactory pmiBeanFactory;
	private EJBSecurityCollaborator<?> securityCollaborator;
	private StatefulPassivator ivStatefulPassivator;
	private StatefulSessionKeyFactory statefulSessionKeyFactory;
	private StatefulSessionHandleFactory statefulSessionHandleFactory;
	private PoolManager poolManager;
	private J2EENameFactory j2eeNameFactory;
	private OrbUtils orbUtils;
	private EJBRequestCollaborator<?>[] afterActivationCollaborators;
	private EJBRequestCollaborator<?>[] beforeActivationCollaborators;
	private EJBRequestCollaborator<?>[] beforeActivationAfterCompletionCollaborators;
	private UOWControl uowControl;
	private ContainerExtensionFactory containerExtFactory;
	private final StatefulBeanEnqDeq ivStatefulBeanEnqDeq;
	private final DispatchEventListenerManager ivDispatchEventListenerManager;
	private SfFailoverCache ivStatefulFailoverCache;
	private boolean ivSFSBFailoverEnabled;

	public ContainerConfigImpl(EJBRuntime ejbRuntime, ClassLoader classLoader, String containerName, EJBCache ejbCache,
			EJBCache wrapperCache, PassivationPolicy passivationPolicy, PersisterFactory persisterFactory,
			EntityHelper entityHelper, EJBPMICollaboratorFactory pmiBeanFactory,
			EJBSecurityCollaborator<?> securityCollaborator, StatefulPassivator statefulPassivator,
			StatefulSessionKeyFactory statefulSessionKeyFactory,
			StatefulSessionHandleFactory statefulSessionHandleFactory, PoolManager poolManager,
			J2EENameFactory j2eeNameFactory, OrbUtils orbUtils, UOWControl uowControl,
			EJBRequestCollaborator<?>[] afterActivationCollaborators,
			EJBRequestCollaborator<?>[] beforeActivationCollaborators,
			EJBRequestCollaborator<?>[] beforeActivationAfterCompletionCollaborators,
			ContainerExtensionFactory containerExtFactory, StatefulBeanEnqDeq statefulBeanEnqDeq,
			DispatchEventListenerManager dispatchEventListenerManager, SfFailoverCache failoverCache,
			boolean sfsbFailoverEnabled) {
		this.ivEJBRuntime = ejbRuntime;
		this.classLoader = classLoader;
		this.containerName = containerName;
		this.ejbCache = ejbCache;
		this.wrapperCache = wrapperCache;
		this.passivationPolicy = passivationPolicy;
		this.persisterFactory = persisterFactory;
		this.ivEntityHelper = entityHelper;
		this.pmiBeanFactory = pmiBeanFactory;
		this.securityCollaborator = securityCollaborator;
		this.ivStatefulPassivator = statefulPassivator;
		this.statefulSessionKeyFactory = statefulSessionKeyFactory;
		this.statefulSessionHandleFactory = statefulSessionHandleFactory;
		this.poolManager = poolManager;
		this.j2eeNameFactory = j2eeNameFactory;
		this.orbUtils = orbUtils;
		this.uowControl = uowControl;
		this.afterActivationCollaborators = afterActivationCollaborators;
		this.beforeActivationCollaborators = beforeActivationCollaborators;
		this.beforeActivationAfterCompletionCollaborators = beforeActivationAfterCompletionCollaborators;
		this.containerExtFactory = containerExtFactory;
		this.ivStatefulBeanEnqDeq = statefulBeanEnqDeq;
		this.ivDispatchEventListenerManager = dispatchEventListenerManager;
		this.ivStatefulFailoverCache = failoverCache;
		this.ivSFSBFailoverEnabled = sfsbFailoverEnabled;
	}

	public EJBRuntime getEJBRuntime() {
		return this.ivEJBRuntime;
	}

	public ClassLoader getClassLoader() {
		return this.classLoader;
	}

	public EJBCache getEJBCache() {
		return this.ejbCache;
	}

	public EJBCache getWrapperCache() {
		return this.wrapperCache;
	}

	public PoolManager getPoolManager() {
		return this.poolManager;
	}

	public J2EENameFactory getJ2EENameFactory() {
		return this.j2eeNameFactory;
	}

	public String getContainerName() {
		return this.containerName;
	}

	public EJBRequestCollaborator<?>[] getAfterActivationCollaborators() {
		return this.afterActivationCollaborators;
	}

	public EJBRequestCollaborator<?>[] getBeforeActivationCollaborators() {
		return this.beforeActivationCollaborators;
	}

	public EJBRequestCollaborator<?>[] getBeforeActivationAfterCompletionCollaborators() {
		return this.beforeActivationAfterCompletionCollaborators;
	}

	public PassivationPolicy getPassivationPolicy() {
		return this.passivationPolicy;
	}

	public PersisterFactory getPersisterFactory() {
		return this.persisterFactory;
	}

	public EntityHelper getEntityHelper() {
		return this.ivEntityHelper;
	}

	public EJBPMICollaboratorFactory getPmiBeanFactory() {
		return this.pmiBeanFactory;
	}

	public EJBSecurityCollaborator<?> getSecurityCollaborator() {
		return this.securityCollaborator;
	}

	public StatefulPassivator getStatefulPassivator() {
		return this.ivStatefulPassivator;
	}

	public StatefulSessionKeyFactory getSessionKeyFactory() {
		return this.statefulSessionKeyFactory;
	}

	public StatefulSessionHandleFactory getStatefulSessionHandleFactory() {
		return this.statefulSessionHandleFactory;
	}

	public OrbUtils getOrbUtils() {
		return this.orbUtils;
	}

	public UOWControl getUOWControl() {
		return this.uowControl;
	}

	public ContainerExtensionFactory getContainerExtensionFactory() {
		return this.containerExtFactory;
	}

	public StatefulBeanEnqDeq getStatefulBeanEnqDeq() {
		return this.ivStatefulBeanEnqDeq;
	}

	public DispatchEventListenerManager getDispatchEventListenerManager() {
		return this.ivDispatchEventListenerManager;
	}

	public SfFailoverCache getStatefulFailoverCache() {
		return this.ivStatefulFailoverCache;
	}

	public boolean isEnabledSFSBFailover() {
		return this.ivSFSBFailoverEnabled;
	}
}