package com.ibm.ws.ffdc;

public interface FFDCSelfIntrospectable {
	String[] introspectSelf();
}