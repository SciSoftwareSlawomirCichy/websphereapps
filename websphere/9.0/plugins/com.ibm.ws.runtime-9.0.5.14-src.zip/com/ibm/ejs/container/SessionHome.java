package com.ibm.ejs.container;

import java.rmi.RemoteException;

public final class SessionHome extends EJSHome {
	private static final long serialVersionUID = -5599958674558718699L;

	public SessionHome() throws RemoteException {
	}
}