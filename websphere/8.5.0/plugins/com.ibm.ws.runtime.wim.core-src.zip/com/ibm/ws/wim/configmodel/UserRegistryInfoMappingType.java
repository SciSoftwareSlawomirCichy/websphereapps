package com.ibm.ws.wim.configmodel;

public interface UserRegistryInfoMappingType {
	String getPropertyForInput();

	void setPropertyForInput(String var1);

	String getPropertyForOutput();

	void setPropertyForOutput(String var1);
}