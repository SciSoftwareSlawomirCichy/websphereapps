package com.ibm.icu.impl;

import com.ibm.icu.impl.ICUCurrencyMetaInfo.1;
import com.ibm.icu.impl.ICUCurrencyMetaInfo.Collector;
import com.ibm.icu.impl.ICUCurrencyMetaInfo.CurrencyCollector;
import com.ibm.icu.impl.ICUCurrencyMetaInfo.InfoCollector;
import com.ibm.icu.impl.ICUCurrencyMetaInfo.RegionCollector;
import com.ibm.icu.text.CurrencyMetaInfo;
import com.ibm.icu.text.CurrencyMetaInfo.CurrencyDigits;
import com.ibm.icu.text.CurrencyMetaInfo.CurrencyFilter;
import com.ibm.icu.text.CurrencyMetaInfo.CurrencyInfo;
import java.util.List;

public class ICUCurrencyMetaInfo extends CurrencyMetaInfo {
	private ICUResourceBundle regionInfo;
	private ICUResourceBundle digitInfo;
	private static final long MASK = 4294967295L;
	private static final int Region = 1;
	private static final int Currency = 2;
	private static final int Date = 4;
	private static final int nonRegion = 6;

	public ICUCurrencyMetaInfo() {
		ICUResourceBundle bundle = (ICUResourceBundle) ICUResourceBundle.getBundleInstance(
				"com/ibm/icu/impl/data/icudt44b/curr", "supplementalData", ICUResourceBundle.ICU_DATA_CLASS_LOADER);
		this.regionInfo = bundle.findTopLevel("CurrencyMap");
		this.digitInfo = bundle.findTopLevel("CurrencyMeta");
	}

	public List<CurrencyInfo> currencyInfo(CurrencyFilter filter) {
      return this.collect(new InfoCollector((1)null), filter);
   }

	public List<String> currencies(CurrencyFilter filter) {
      return this.collect(new CurrencyCollector((1)null), filter);
   }

	public List<String> regions(CurrencyFilter filter) {
      return this.collect(new RegionCollector((1)null), filter);
   }

	public CurrencyDigits currencyDigits(String isoCode) {
		ICUResourceBundle b = this.digitInfo.findWithFallback(isoCode);
		if (b == null) {
			b = this.digitInfo.findWithFallback("DEFAULT");
		}

		int[] data = b.getIntVector();
		return new CurrencyDigits(data[0], data[1]);
	}

	private <T> List<T> collect(Collector<T> collector, CurrencyFilter filter) {
		if (filter == null) {
			filter = CurrencyFilter.all();
		}

		int needed = collector.collects();
		if (filter.region != null) {
			needed |= 1;
		}

		if (filter.currency != null) {
			needed |= 2;
		}

		if (filter.from != Long.MIN_VALUE || filter.to != Long.MAX_VALUE) {
			needed |= 4;
		}

		if (needed != 0) {
			if (filter.region != null) {
				ICUResourceBundle b = this.regionInfo.findWithFallback(filter.region);
				if (b != null) {
					this.collectRegion(collector, filter, needed, b);
				}
			} else {
				for (int i = 0; i < this.regionInfo.getSize(); ++i) {
					this.collectRegion(collector, filter, needed, this.regionInfo.at(i));
				}
			}
		}

		return collector.getList();
	}

	private <T> void collectRegion(Collector<T> collector, CurrencyFilter filter, int needed, ICUResourceBundle b) {
		String region = b.getKey();
		if ((needed & 6) == 0) {
			collector.collect(b.getKey(), (String) null, 0L, 0L, -1);
		} else {
			for (int i = 0; i < b.getSize(); ++i) {
				ICUResourceBundle r = b.at(i);
				if (r.getSize() != 0) {
					String currency = null;
					long from = Long.MIN_VALUE;
					long to = Long.MAX_VALUE;
					if ((needed & 2) != 0) {
						ICUResourceBundle currBundle = r.at("id");
						currency = currBundle.getString();
						if (filter.currency != null && !filter.currency.equals(currency)) {
							continue;
						}
					}

					if ((needed & 4) != 0) {
						from = this.getDate(r.at("from"), Long.MIN_VALUE);
						to = this.getDate(r.at("to"), Long.MAX_VALUE);
						if (filter.from >= to || filter.to <= from) {
							continue;
						}
					}

					collector.collect(region, currency, from, to, i);
				}
			}

		}
	}

	private long getDate(ICUResourceBundle b, long defaultValue) {
		if (b == null) {
			return defaultValue;
		} else {
			int[] values = b.getIntVector();
			return (long) values[0] << 32 | (long) values[1] & 4294967295L;
		}
	}
}