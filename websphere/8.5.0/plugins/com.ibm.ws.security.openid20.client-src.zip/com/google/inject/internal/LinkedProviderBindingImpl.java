package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.Provider;
import com.google.inject.spi.BindingTargetVisitor;
import com.google.inject.spi.ProviderKeyBinding;

public final class LinkedProviderBindingImpl<T> extends BindingImpl<T> implements ProviderKeyBinding<T> {
	final Key<? extends Provider<? extends T>> providerKey;

	public LinkedProviderBindingImpl(Injector injector, Key<T> key, Object source,
			InternalFactory<? extends T> internalFactory, Scoping scoping,
			Key<? extends Provider<? extends T>> providerKey) {
		super(injector, key, source, internalFactory, scoping);
		this.providerKey = providerKey;
	}

	LinkedProviderBindingImpl(Object source, Key<T> key, Scoping scoping,
			Key<? extends Provider<? extends T>> providerKey) {
		super(source, key, scoping);
		this.providerKey = providerKey;
	}

	public <V> V acceptTargetVisitor(BindingTargetVisitor<? super T, V> visitor) {
		return visitor.visit(this);
	}

	public Key<? extends Provider<? extends T>> getProviderKey() {
		return this.providerKey;
	}

	public BindingImpl<T> withScoping(Scoping scoping) {
		return new LinkedProviderBindingImpl(this.getSource(), this.getKey(), scoping, this.providerKey);
	}

	public BindingImpl<T> withKey(Key<T> key) {
		return new LinkedProviderBindingImpl(this.getSource(), key, this.getScoping(), this.providerKey);
	}

	public void applyTo(Binder binder) {
		this.getScoping()
				.applyTo(binder.withSource(this.getSource()).bind(this.getKey()).toProvider(this.getProviderKey()));
	}

	public String toString() {
		return (new ToStringBuilder(ProviderKeyBinding.class)).add("key", this.getKey()).add("source", this.getSource())
				.add("scope", this.getScoping()).add("provider", this.providerKey).toString();
	}
}