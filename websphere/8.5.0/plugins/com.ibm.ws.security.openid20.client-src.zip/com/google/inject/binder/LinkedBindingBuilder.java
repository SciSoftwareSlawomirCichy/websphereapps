package com.google.inject.binder;

import com.google.inject.Key;
import com.google.inject.Provider;
import com.google.inject.TypeLiteral;

public interface LinkedBindingBuilder<T> extends ScopedBindingBuilder {
	ScopedBindingBuilder to(Class<? extends T> var1);

	ScopedBindingBuilder to(TypeLiteral<? extends T> var1);

	ScopedBindingBuilder to(Key<? extends T> var1);

	void toInstance(T var1);

	ScopedBindingBuilder toProvider(Provider<? extends T> var1);

	ScopedBindingBuilder toProvider(Class<? extends Provider<? extends T>> var1);

	ScopedBindingBuilder toProvider(Key<? extends Provider<? extends T>> var1);
}