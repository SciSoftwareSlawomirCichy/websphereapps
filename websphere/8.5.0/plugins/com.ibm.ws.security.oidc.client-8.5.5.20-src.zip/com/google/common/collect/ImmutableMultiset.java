package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.concurrent.LazyInit;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
public abstract class ImmutableMultiset<E> extends ImmutableMultisetGwtSerializationDependencies<E>
		implements
			Multiset<E> {
	@LazyInit
	private transient ImmutableList<E> asList;
	@LazyInit
	private transient ImmutableSet<Multiset.Entry<E>> entrySet;

	public static <E> ImmutableMultiset<E> of() {
		return RegularImmutableMultiset.EMPTY;
	}

	public static <E> ImmutableMultiset<E> of(E element) {
		return copyFromElements(element);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2) {
		return copyFromElements(e1, e2);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3) {
		return copyFromElements(e1, e2, e3);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4) {
		return copyFromElements(e1, e2, e3, e4);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5) {
		return copyFromElements(e1, e2, e3, e4, e5);
	}

	public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... others) {
		return (new Builder()).add(e1).add(e2).add(e3).add(e4).add(e5).add(e6).add(others).build();
	}

	public static <E> ImmutableMultiset<E> copyOf(E[] elements) {
		return copyFromElements(elements);
	}

	public static <E> ImmutableMultiset<E> copyOf(Iterable<? extends E> elements) {
		if (elements instanceof ImmutableMultiset) {
			ImmutableMultiset<E> result = (ImmutableMultiset) elements;
			if (!result.isPartialView()) {
				return result;
			}
		}

		Builder<E> builder = new Builder(Multisets.inferDistinctElements(elements));
		builder.addAll(elements);
		return builder.build();
	}

	public static <E> ImmutableMultiset<E> copyOf(Iterator<? extends E> elements) {
		return (new Builder()).addAll(elements).build();
	}

	private static <E> ImmutableMultiset<E> copyFromElements(E... elements) {
		return (new Builder()).add(elements).build();
	}

	static <E> ImmutableMultiset<E> copyFromEntries(Collection<? extends Multiset.Entry<? extends E>> entries) {
		Builder<E> builder = new Builder(entries.size());
		Iterator var2 = entries.iterator();

		while (var2.hasNext()) {
			Multiset.Entry<? extends E> entry = (Multiset.Entry) var2.next();
			builder.addCopies(entry.getElement(), entry.getCount());
		}

		return builder.build();
	}

	ImmutableMultiset() {
	}

	public UnmodifiableIterator<E> iterator() {
		final Iterator<Multiset.Entry<E>> entryIterator = this.entrySet().iterator();
		return new UnmodifiableIterator<E>() {
			int remaining;
			@MonotonicNonNullDecl
			E element;

			public boolean hasNext() {
				return this.remaining > 0 || entryIterator.hasNext();
			}

			public E next() {
				if (this.remaining <= 0) {
					Multiset.Entry<E> entry = (Multiset.Entry) entryIterator.next();
					this.element = entry.getElement();
					this.remaining = entry.getCount();
				}

				--this.remaining;
				return this.element;
			}
		};
	}

	public ImmutableList<E> asList() {
		ImmutableList<E> result = this.asList;
		return result == null ? (this.asList = super.asList()) : result;
	}

	public boolean contains(@NullableDecl Object object) {
		return this.count(object) > 0;
	}

	/** @deprecated */
	@Deprecated
	@CanIgnoreReturnValue
	public final int add(E element, int occurrences) {
		throw new UnsupportedOperationException();
	}

	/** @deprecated */
	@Deprecated
	@CanIgnoreReturnValue
	public final int remove(Object element, int occurrences) {
		throw new UnsupportedOperationException();
	}

	/** @deprecated */
	@Deprecated
	@CanIgnoreReturnValue
	public final int setCount(E element, int count) {
		throw new UnsupportedOperationException();
	}

	/** @deprecated */
	@Deprecated
	@CanIgnoreReturnValue
	public final boolean setCount(E element, int oldCount, int newCount) {
		throw new UnsupportedOperationException();
	}

	@GwtIncompatible
	int copyIntoArray(Object[] dst, int offset) {
		Multiset.Entry entry;
		for (UnmodifiableIterator var3 = this.entrySet().iterator(); var3.hasNext(); offset += entry.getCount()) {
			entry = (Multiset.Entry) var3.next();
			Arrays.fill(dst, offset, offset + entry.getCount(), entry.getElement());
		}

		return offset;
	}

	public boolean equals(@NullableDecl Object object) {
		return Multisets.equalsImpl(this, object);
	}

	public int hashCode() {
		return Sets.hashCodeImpl(this.entrySet());
	}

	public String toString() {
		return this.entrySet().toString();
	}

	public abstract ImmutableSet<E> elementSet();

	public ImmutableSet<Multiset.Entry<E>> entrySet() {
		ImmutableSet<Multiset.Entry<E>> es = this.entrySet;
		return es == null ? (this.entrySet = this.createEntrySet()) : es;
	}

	private ImmutableSet<Multiset.Entry<E>> createEntrySet() {
		return (ImmutableSet) (this.isEmpty() ? ImmutableSet.of() : new EntrySet());
	}

	abstract Multiset.Entry<E> getEntry(int var1);

	@GwtIncompatible
	abstract Object writeReplace();

	public static <E> Builder<E> builder() {
		return new Builder();
	}

	public static class Builder<E> extends ImmutableCollection.Builder<E> {
		ObjectCountHashMap<E> contents;
		boolean buildInvoked;
		boolean isLinkedHash;

		public Builder() {
			this(4);
		}

		Builder(int estimatedDistinct) {
			this.buildInvoked = false;
			this.isLinkedHash = false;
			this.contents = ObjectCountHashMap.createWithExpectedSize(estimatedDistinct);
		}

		Builder(boolean forSubtype) {
			this.buildInvoked = false;
			this.isLinkedHash = false;
			this.contents = null;
		}

		@CanIgnoreReturnValue
		public Builder<E> add(E element) {
			return this.addCopies(element, 1);
		}

		@CanIgnoreReturnValue
		public Builder<E> add(E... elements) {
			super.add(elements);
			return this;
		}

		@CanIgnoreReturnValue
		public Builder<E> addCopies(E element, int occurrences) {
			if (occurrences == 0) {
				return this;
			} else {
				if (this.buildInvoked) {
					this.contents = new ObjectCountHashMap(this.contents);
					this.isLinkedHash = false;
				}

				this.buildInvoked = false;
				Preconditions.checkNotNull(element);
				this.contents.put(element, occurrences + this.contents.get(element));
				return this;
			}
		}

		@CanIgnoreReturnValue
		public Builder<E> setCount(E element, int count) {
			if (count == 0 && !this.isLinkedHash) {
				this.contents = new ObjectCountLinkedHashMap(this.contents);
				this.isLinkedHash = true;
			} else if (this.buildInvoked) {
				this.contents = new ObjectCountHashMap(this.contents);
				this.isLinkedHash = false;
			}

			this.buildInvoked = false;
			Preconditions.checkNotNull(element);
			if (count == 0) {
				this.contents.remove(element);
			} else {
				this.contents.put(Preconditions.checkNotNull(element), count);
			}

			return this;
		}

		@CanIgnoreReturnValue
		public Builder<E> addAll(Iterable<? extends E> elements) {
			if (elements instanceof Multiset) {
				Multiset<? extends E> multiset = Multisets.cast(elements);
				ObjectCountHashMap<? extends E> backingMap = tryGetMap(multiset);
				if (backingMap != null) {
					this.contents.ensureCapacity(Math.max(this.contents.size(), backingMap.size()));

					for (int i = backingMap.firstIndex(); i >= 0; i = backingMap.nextIndex(i)) {
						this.addCopies(backingMap.getKey(i), backingMap.getValue(i));
					}
				} else {
					Set<? extends Multiset.Entry<? extends E>> entries = multiset.entrySet();
					this.contents.ensureCapacity(Math.max(this.contents.size(), entries.size()));
					Iterator var5 = multiset.entrySet().iterator();

					while (var5.hasNext()) {
						Multiset.Entry<? extends E> entry = (Multiset.Entry) var5.next();
						this.addCopies(entry.getElement(), entry.getCount());
					}
				}
			} else {
				super.addAll(elements);
			}

			return this;
		}

		@CanIgnoreReturnValue
		public Builder<E> addAll(Iterator<? extends E> elements) {
			super.addAll(elements);
			return this;
		}

		@NullableDecl
		static <T> ObjectCountHashMap<T> tryGetMap(Iterable<T> multiset) {
			if (multiset instanceof RegularImmutableMultiset) {
				return ((RegularImmutableMultiset) multiset).contents;
			} else {
				return multiset instanceof AbstractMapBasedMultiset
						? ((AbstractMapBasedMultiset) multiset).backingMap
						: null;
			}
		}

		public ImmutableMultiset<E> build() {
			if (this.contents.size() == 0) {
				return ImmutableMultiset.of();
			} else {
				if (this.isLinkedHash) {
					this.contents = new ObjectCountHashMap(this.contents);
					this.isLinkedHash = false;
				}

				this.buildInvoked = true;
				return new RegularImmutableMultiset(this.contents);
			}
		}
	}

	@GwtIncompatible
	static class EntrySetSerializedForm<E> implements Serializable {
		final ImmutableMultiset<E> multiset;

		EntrySetSerializedForm(ImmutableMultiset<E> multiset) {
			this.multiset = multiset;
		}

		Object readResolve() {
			return this.multiset.entrySet();
		}
	}

	private final class EntrySet extends IndexedImmutableSet<Multiset.Entry<E>> {
		private static final long serialVersionUID = 0L;

		private EntrySet() {
		}

		boolean isPartialView() {
			return ImmutableMultiset.this.isPartialView();
		}

		Multiset.Entry<E> get(int index) {
			return ImmutableMultiset.this.getEntry(index);
		}

		public int size() {
			return ImmutableMultiset.this.elementSet().size();
		}

		public boolean contains(Object o) {
			if (o instanceof Multiset.Entry) {
				Multiset.Entry<?> entry = (Multiset.Entry) o;
				if (entry.getCount() <= 0) {
					return false;
				} else {
					int count = ImmutableMultiset.this.count(entry.getElement());
					return count == entry.getCount();
				}
			} else {
				return false;
			}
		}

		public int hashCode() {
			return ImmutableMultiset.this.hashCode();
		}

		@GwtIncompatible
		Object writeReplace() {
			return new EntrySetSerializedForm(ImmutableMultiset.this);
		}
	}
}