package com.ibm.ejs.cm.pool;

import java.io.PrintWriter;
import java.sql.SQLException;
import javax.sql.XADataSource;

public final class JTAConnectionFactory implements ConnectionFactory {
	private XADataSource xaDataSource;

	public JTAConnectionFactory(XADataSource xaDataSource) {
		this.xaDataSource = xaDataSource;
	}

	public ConnectO createConnection(ConnectionPool pool) throws SQLException {
		return new ConnectO(this.xaDataSource.getXAConnection(), pool, (String) null, (String) null);
	}

	public ConnectO createConnection(ConnectionPool pool, String username, String password) throws SQLException {
		return new ConnectO(this.xaDataSource.getXAConnection(username, password), pool, username, password);
	}

	public PrintWriter getLogWriter() throws SQLException {
		return this.xaDataSource.getLogWriter();
	}

	public void setLogWriter(PrintWriter out) throws SQLException {
		this.xaDataSource.setLogWriter(out);
	}

	public int getLoginTimeout(int seconds) throws SQLException {
		return this.xaDataSource.getLoginTimeout();
	}

	public void setLoginTimeout(int seconds) throws SQLException {
		this.xaDataSource.setLoginTimeout(seconds);
	}
}