package com.ibm.ws.wim.management;

public class UserManagerNotificationConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public static final String TYPE_USERMANAGER = "websphere.usermanager";
	public static final String TYPE_USERMANAGER_FILEREGISTRY = "websphere.usermanager.fileregistry";
	public static final String TYPE_USERMANAGER_FILEREGISTRY_CHANGE = "websphere.usermanager.fileregistry.change";
	public static final String TYPE_USERMANAGER_FILEREGISTRY_USERCREATE = "websphere.usermanager.fileregistry.usercreate";
	public static final String TYPE_USERMANAGER_FILEREGISTRY_USERMOD = "websphere.usermanager.fileregistry.usermod";
	public static final String TYPE_USERMANAGER_FILEREGISTRY_USERDEL = "websphere.usermanager.fileregistry.userdel";
	public static final String TYPE_USERMANAGER_CONFIGMANAGER = "websphere.usermanager.configmanager";
	public static final String TYPE_USERMANAGER_CONFIGMANAGER_CHANGE = "websphere.usermanager.configmanager.change";
	public static final String TYPE_USERMANAGER_SCHEMAMANAGER = "websphere.usermanager.schemamanager";
	public static final String TYPE_USERMANAGER_SCHEMAMANAGER_CHANGE = "websphere.usermanager.schemamanager.change";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_ADD_REPOSITORY = "websphere.usermanager.serviceprovider.add.repository";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_ADD_BASE_ENTRY = "websphere.usermanager.serviceprovider.add.baseentry";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_ADD_ENTITY_CONFIG = "websphere.usermanager.serviceprovider.add.entityconfig";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_ADD_PROPERTY_CONFIG = "websphere.usermanager.serviceprovider.add.propertyconfig";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_ADD_REALM = "websphere.usermanager.serviceprovider.add.realm";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_ADD_PARTICIPATING_BASE_ENTRY = "websphere.usermanager.serviceprovider.add.participatingbaseentry";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_ADD_DEFAULT_PARENT_TO_REALM = "websphere.usermanager.serviceprovider.add.defaultparenttorealm";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_ADD_PROPERTY_EXTENSION_REPOSITORY = "websphere.usermanager.serviceprovider.add.propertyextensionrepository";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_UPDATE_LDAP_BIND_INFO = "websphere.usermanager.serviceprovider.update.ldap.bindinfo";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_UPDATE_DB_ADMIN_ID_PASSWORD = "websphere.usermanager.serviceprovider.update.db.adminidpassword";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_UPDATE_ENTRY_MAPPING_ADMIN_ID_PASSWORD = "websphere.usermanager.serviceprovider.update.entrymapping.adminidpassword";
	public static final String TYPE_USERMANAGER_DYNA_CONFIG_EVENT_UPDATE_PROPERTY_EXTENSION_ADMIN_ID_PASSWORD = "websphere.usermanager.serviceprovider.update.propertyextension.adminidpassword";
}