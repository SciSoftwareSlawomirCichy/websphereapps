package com.ibm.icu.text;

import com.ibm.icu.text.RbnfScannerProviderImpl.1;
import com.ibm.icu.text.RbnfScannerProviderImpl.RbnfLenientScannerImpl;
import com.ibm.icu.util.ULocale;
import java.util.HashMap;
import java.util.Map;

public class RbnfScannerProviderImpl implements RbnfLenientScannerProvider {
	private Map<String, RbnfLenientScanner> cache = new HashMap();

	public RbnfLenientScanner get(ULocale locale, String extras) {
		RbnfLenientScanner result = null;
		String key = locale.toString() + "/" + extras;
		Map var5 = this.cache;
		synchronized (this.cache) {
			result = (RbnfLenientScanner) this.cache.get(key);
			if (result != null) {
				return result;
			}
		}

		result = this.createScanner(locale, extras);
		var5 = this.cache;
		synchronized (this.cache) {
			this.cache.put(key, result);
			return result;
		}
	}

	protected RbnfLenientScanner createScanner(ULocale locale, String extras) {
      RuleBasedCollator collator = null;

      try {
         collator = (RuleBasedCollator)Collator.getInstance(locale.toLocale());
         if (extras != null) {
            String rules = collator.getRules() + extras;
            collator = new RuleBasedCollator(rules);
         }

         collator.setDecomposition(17);
      } catch (Exception var5) {
         var5.printStackTrace();
         System.out.println("++++");
         collator = null;
      }

      return new RbnfLenientScannerImpl(collator, (1)null);
   }
}