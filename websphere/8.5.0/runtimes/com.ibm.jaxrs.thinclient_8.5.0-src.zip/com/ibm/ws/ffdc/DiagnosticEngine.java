package com.ibm.ws.ffdc;

import com.ibm.ws.ffdc.impl.CallStack;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class DiagnosticEngine {
	private static final Hashtable<Integer, DiagnosticModule> globalHashTableOfDM = new Hashtable();

	public static List<DiagnosticModule> getDiagnosticModules(int processLevel, Object callerThis, String sourceId,
			CallStack cs) {
		switch (processLevel) {
			case 0 :
			case 1 :
			case 2 :
			case 3 :
				return null;
			case 4 :
				DiagnosticModule dm = getCurrentLevelDiagnosticModules(callerThis, cs, sourceId);
				return dm == null ? null : Collections.singletonList(dm);
			case 5 :
			case 6 :
			case 7 :
				return getFullStackDMIterator(callerThis, cs, sourceId);
			default :
				return null;
		}
	}

	private static DiagnosticModule getCurrentLevelDiagnosticModules(Object callerThis, CallStack cs, String sourceId) {
		String clname = getReporterClassName(callerThis, cs);
		DiagnosticModule dm = findDM(clname);
		if (dm == null) {
			dm = findDM(sourceId);
		}

		return dm;
	}

	private static List<DiagnosticModule> getFullStackDMIterator(Object callerThis, CallStack cs, String sourceId) {
		Set<DiagnosticModule> foundDMs = new HashSet();
		DiagnosticModule dm = getCurrentLevelDiagnosticModules(callerThis, cs, sourceId);
		List<String> cnames = cs.getClassNames();
		ArrayList<DiagnosticModule> dml = new ArrayList(cnames.size() + (dm == null ? 0 : 1));
		Iterator i$ = cnames.iterator();

		while (i$.hasNext()) {
			String clname = (String) i$.next();
			dm = findDM(clname);
			if (dm != null && foundDMs.add(dm)) {
				dml.add(dm);
			}
		}

		return dml;
	}

	private static String getReporterClassName(Object callerThis, CallStack cs) {
		String clname;
		if (callerThis != null) {
			if (callerThis instanceof Class) {
				clname = ((Class) callerThis).getName();
			} else {
				clname = callerThis.getClass().getName();
			}
		} else {
			clname = cs.getReporterClassName();
		}

		return clname;
	}

	private static DiagnosticModule findDM(String path) {
		for (String trimName = path; trimName != null; trimName = trim(trimName)) {
			int pkgKey = trimName.hashCode();
			DiagnosticModule dm = (DiagnosticModule) globalHashTableOfDM.get(pkgKey);
			if (dm != null) {
				return dm;
			}
		}

		return null;
	}

	private static String trim(String pkgName) {
		int lastDot = pkgName.lastIndexOf(46);
		return lastDot == -1 ? null : pkgName.substring(0, lastDot);
	}

	static boolean registerDM(DiagnosticModule dm, String packageName) {
		Hashtable var2 = globalHashTableOfDM;
		synchronized (globalHashTableOfDM) {
			int DMKey = packageName.hashCode();
			if (globalHashTableOfDM.containsKey(DMKey)) {
				return false;
			} else {
				globalHashTableOfDM.put(DMKey, dm);
				return true;
			}
		}
	}

	static boolean deregisterDM(String packageName) {
		int DMKey = packageName.hashCode();
		return null != globalHashTableOfDM.remove(DMKey);
	}
}