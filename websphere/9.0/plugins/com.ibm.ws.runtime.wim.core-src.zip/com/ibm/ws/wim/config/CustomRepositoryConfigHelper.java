package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import commonj.sdo.DataObject;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EcoreUtil;

public class CustomRepositoryConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	private static final String CLASSNAME = CustomRepositoryConfigHelper.class.getName();
	private static final Logger trcLogger;

	public String createIdMgrCustomRepository(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "createIdMgrCustomRepository", "params = " + var2);
		}

		String var5 = (String) var2.get("id");
		ConfigurationProviderType var6 = ConfigUtils.getConfigProvider(var1);
		RepositoryType var7 = ConfigUtils.getRepositoryById(var1, var5, false);
		if (var7 != null) {
			throw new WIMConfigurationException("REPOSITORY_ID_ALREADY_EXISTS", WIMMessageHelper.generateMsgParms(var5),
					Level.SEVERE, CLASSNAME, "createIdMgrCustomRepository");
		} else {
			String var8 = (String) var2.get("adapterClassName");
			if (var8 != null) {
				try {
					Class.forName(var8);
				} catch (ClassNotFoundException var13) {
					ClassLoader var10 = Thread.currentThread().getContextClassLoader();
					if (var10 == null) {
						var10 = this.getClass().getClassLoader();
					}

					try {
						Class.forName(var8, true, var10);
					} catch (ClassNotFoundException var12) {
						throw new WIMConfigurationException("MISSING_OR_INVALID_ADAPTER_CLASS_NAME",
								WIMMessageHelper.generateMsgParms(var8), CLASSNAME, "createIdMgrCustomRepository",
								var13);
					}
				}
			}

			EClass var9 = ConfigManager.singleton().getConfigEClass("ProfileRepositoryType");
			DataObject var14 = (DataObject) EcoreUtil.create(var9);
			var14.setString("id", var5);
			var6.getRepositories().add(var14);
			ProfileRepositoryType var11 = (ProfileRepositoryType) ConfigUtils.getRepositoryById(var6, var5);
			var11.setAdapterClassName(var8);
			var11.setSupportPaging(false);
			if (var4) {
				trcLogger.exiting(CLASSNAME, "createIdMgrCustomRepository");
			}

			ConfigUtils.saveConfig(var1);
			return "MUST_ADD_BASE_ENTRY_TO_REPOSITORY";
		}
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}