package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.TreeRangeMap.1;
import com.google.common.collect.TreeRangeMap.AsMapOfRanges;
import com.google.common.collect.TreeRangeMap.RangeMapEntry;
import com.google.common.collect.TreeRangeMap.SubRangeMap;
import java.util.Iterator;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NoSuchElementException;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@Beta
@GwtIncompatible("NavigableMap")
public final class TreeRangeMap<K extends Comparable, V> implements RangeMap<K, V> {
	private final NavigableMap<Cut<K>, RangeMapEntry<K, V>> entriesByLowerBound = Maps.newTreeMap();
	private static final RangeMap EMPTY_SUB_RANGE_MAP = new 1();

	public static <K extends Comparable, V> TreeRangeMap<K, V> create() {
		return new TreeRangeMap();
	}

	@Nullable
	public V get(K key) {
		Entry<Range<K>, V> entry = this.getEntry(key);
		return entry == null ? null : entry.getValue();
	}

	@Nullable
	public Entry<Range<K>, V> getEntry(K key) {
		Entry<Cut<K>, RangeMapEntry<K, V>> mapEntry = this.entriesByLowerBound.floorEntry(Cut.belowValue(key));
		return mapEntry != null && ((RangeMapEntry) mapEntry.getValue()).contains(key)
				? (Entry) mapEntry.getValue()
				: null;
	}

	public void put(Range<K> range, V value) {
		if (!range.isEmpty()) {
			Preconditions.checkNotNull(value);
			this.remove(range);
			this.entriesByLowerBound.put(range.lowerBound, new RangeMapEntry(range, value));
		}

	}

	public void putAll(RangeMap<K, V> rangeMap) {
		Iterator i$ = rangeMap.asMapOfRanges().entrySet().iterator();

		while (i$.hasNext()) {
			Entry<Range<K>, V> entry = (Entry) i$.next();
			this.put((Range) entry.getKey(), entry.getValue());
		}

	}

	public void clear() {
		this.entriesByLowerBound.clear();
	}

	public Range<K> span() {
		Entry<Cut<K>, RangeMapEntry<K, V>> firstEntry = this.entriesByLowerBound.firstEntry();
		Entry<Cut<K>, RangeMapEntry<K, V>> lastEntry = this.entriesByLowerBound.lastEntry();
		if (firstEntry == null) {
			throw new NoSuchElementException();
		} else {
			return Range.create(((RangeMapEntry) firstEntry.getValue()).getKey().lowerBound,
					((RangeMapEntry) lastEntry.getValue()).getKey().upperBound);
		}
	}

	private void putRangeMapEntry(Cut<K> lowerBound, Cut<K> upperBound, V value) {
		this.entriesByLowerBound.put(lowerBound, new RangeMapEntry(lowerBound, upperBound, value));
	}

	public void remove(Range<K> rangeToRemove) {
		if (!rangeToRemove.isEmpty()) {
			Entry<Cut<K>, RangeMapEntry<K, V>> mapEntryBelowToTruncate = this.entriesByLowerBound
					.lowerEntry(rangeToRemove.lowerBound);
			if (mapEntryBelowToTruncate != null) {
				RangeMapEntry<K, V> rangeMapEntry = (RangeMapEntry) mapEntryBelowToTruncate.getValue();
				if (rangeMapEntry.getUpperBound().compareTo(rangeToRemove.lowerBound) > 0) {
					if (rangeMapEntry.getUpperBound().compareTo(rangeToRemove.upperBound) > 0) {
						this.putRangeMapEntry(rangeToRemove.upperBound, rangeMapEntry.getUpperBound(),
								((RangeMapEntry) mapEntryBelowToTruncate.getValue()).getValue());
					}

					this.putRangeMapEntry(rangeMapEntry.getLowerBound(), rangeToRemove.lowerBound,
							((RangeMapEntry) mapEntryBelowToTruncate.getValue()).getValue());
				}
			}

			Entry<Cut<K>, RangeMapEntry<K, V>> mapEntryAboveToTruncate = this.entriesByLowerBound
					.lowerEntry(rangeToRemove.upperBound);
			if (mapEntryAboveToTruncate != null) {
				RangeMapEntry<K, V> rangeMapEntry = (RangeMapEntry) mapEntryAboveToTruncate.getValue();
				if (rangeMapEntry.getUpperBound().compareTo(rangeToRemove.upperBound) > 0) {
					this.putRangeMapEntry(rangeToRemove.upperBound, rangeMapEntry.getUpperBound(),
							((RangeMapEntry) mapEntryAboveToTruncate.getValue()).getValue());
					this.entriesByLowerBound.remove(rangeToRemove.lowerBound);
				}
			}

			this.entriesByLowerBound.subMap(rangeToRemove.lowerBound, rangeToRemove.upperBound).clear();
		}
	}

	public Map<Range<K>, V> asMapOfRanges() {
      return new AsMapOfRanges(this, (1)null);
   }

	public RangeMap<K, V> subRangeMap(Range<K> subRange) {
		return (RangeMap) (subRange.equals(Range.all()) ? this : new SubRangeMap(this, subRange));
	}

	private RangeMap<K, V> emptySubRangeMap() {
		return EMPTY_SUB_RANGE_MAP;
	}

	public boolean equals(@Nullable Object o) {
		if (o instanceof RangeMap) {
			RangeMap<?, ?> rangeMap = (RangeMap) o;
			return this.asMapOfRanges().equals(rangeMap.asMapOfRanges());
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.asMapOfRanges().hashCode();
	}

	public String toString() {
		return this.entriesByLowerBound.values().toString();
	}
}