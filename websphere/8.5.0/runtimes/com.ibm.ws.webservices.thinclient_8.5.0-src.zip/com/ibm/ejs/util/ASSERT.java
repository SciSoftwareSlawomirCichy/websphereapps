package com.ibm.ejs.util;

public class ASSERT {
	public static void notFalse(boolean b) throws IllegalArgumentException {
		if (!b) {
			throw new IllegalArgumentException("boolean expression false");
		}
	}

	public static void isTrue(boolean b) {
		notFalse(b);
	}

	public static void isFalse(boolean b) {
		if (b) {
			throw new IllegalArgumentException("boolean expression true");
		}
	}

	public static void notNull(Object obj) throws IllegalArgumentException {
		if (obj == null) {
			throw new IllegalArgumentException("null argument");
		}
	}

	public static void notFalse(boolean b, String s) throws IllegalArgumentException {
		if (!b) {
			throw new IllegalArgumentException(s);
		}
	}

	public static void isTrue(boolean b, String msg) {
		notFalse(b, msg);
	}

	public static void isFalse(boolean b, String s) {
		if (b) {
			throw new IllegalArgumentException(s);
		}
	}

	public static void notNull(Object obj, String s) throws IllegalArgumentException {
		if (obj == null) {
			throw new IllegalArgumentException(s);
		}
	}
}