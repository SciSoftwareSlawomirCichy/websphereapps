package com.ibm.icu.text;

abstract class CharsetRecog_Unicode extends CharsetRecognizer {
	abstract String getName();

	abstract int match(CharsetDetector var1);
}