package com.ibm.ejs.util.dopriv;

import java.security.PrivilegedAction;

public class SystemGetPropertyPrivileged implements PrivilegedAction {
	private String propertyName;
	private String propertyValue;
	private String propertyDefault = null;

	public SystemGetPropertyPrivileged(String propName) {
		this.propertyName = propName;
	}

	public SystemGetPropertyPrivileged(String propName, String propDefault) {
		this.propertyName = propName;
		this.propertyDefault = propDefault;
	}

	public Object run() {
		this.propertyValue = System.getProperty(this.propertyName, this.propertyDefault);
		return this.propertyValue;
	}

	public String getValue() {
		return this.propertyValue;
	}
}