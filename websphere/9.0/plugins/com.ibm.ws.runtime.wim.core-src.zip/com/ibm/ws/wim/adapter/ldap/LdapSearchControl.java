package com.ibm.ws.wim.adapter.ldap;

import java.util.List;

public class LdapSearchControl {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String[] iBases = null;
	private String iFilter = null;
	private int iCountLimit = 0;
	private int iTimeLimit = 0;
	private List iPropNames = null;
	private List iEntityTypes = null;
	private int iScope = 2;

	public LdapSearchControl(String[] var1, List var2, String var3, List var4, int var5, int var6) {
		this.iBases = var1;
		this.iEntityTypes = var2;
		this.iFilter = var3;
		this.iPropNames = var4;
		this.iCountLimit = var5;
		this.iTimeLimit = var6;
	}

	public String[] getBases() {
		return this.iBases;
	}

	public void setBases(String[] var1) {
		this.iBases = var1;
	}

	public int getCountLimit() {
		return this.iCountLimit;
	}

	public void setCountLimit(int var1) {
		this.iCountLimit = var1;
	}

	public List getEntityTypes() {
		return this.iEntityTypes;
	}

	public void setEntityTypes(List var1) {
		this.iEntityTypes = var1;
	}

	public String getFilter() {
		return this.iFilter;
	}

	public int getScope() {
		return this.iScope;
	}

	public void setFilter(String var1) {
		this.iFilter = var1;
	}

	public List getPropertyNmaes() {
		return this.iPropNames;
	}

	public void setPropertiyNmaes(List var1) {
		this.iPropNames = var1;
	}

	public int getTimeLimit() {
		return this.iTimeLimit;
	}

	public void setTimeLimit(int var1) {
		this.iTimeLimit = var1;
	}

	public void setScope(int var1) {
		this.iScope = var1;
	}
}