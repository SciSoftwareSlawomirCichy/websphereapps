package com.ibm.ws.wim;

import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.InvalidArgumentException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.config.ConfigValidator;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.StringUtil;
import com.ibm.ws.wim.util.UniqueNameHelper;
import commonj.sdo.DataObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RealmManager implements ConfigConstants, DynamicConfigService {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public static final String CLASSNAME = RealmManager.class.getName();
	private static final Logger trcLogger;
	private static Map<String, RealmManager> singleton;
	private DataObject configProvider = null;
	private String defaultRealmName = null;
	private Map realmReposIndexWithBaseEntries = null;
	private List securityUseActiveRealms = null;
	private Map defaultParentsInRealms = null;
	private Map realmDelimiters = null;
	private Map realmUserRegistryMapping = null;
	private List baseEntries = new ArrayList();
	private Map allowOperationIfReposDownMap = null;
	private Map realmParticipatingBaseEntries = null;

	private RealmManager() throws WIMException {
		this.initialize();
	}

	public static synchronized RealmManager singleton() throws WIMException {
		String var0 = DomainManagerUtils.getDomainId();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new RealmManager());
		}

		return (RealmManager) singleton.get(var0);
	}

	public static void clearCache(String var0) {
		singleton.put(var0, (Object) null);
	}

	private void initialize() throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize");
		}

		this.configProvider = ConfigManager.singleton().getConfig();
		DataObject var2 = this.configProvider.getDataObject("realmConfiguration");
		if (var2 != null) {
			this.defaultRealmName = var2.getString("defaultRealm");
			List[] var3 = RepositoryManager.singleton().getRepositoriesBaseEntries();

			for (int var4 = 0; var4 < var3.length; ++var4) {
				this.baseEntries.addAll(var3[var4]);
			}

			List var7 = var2.getList("realms");
			this.securityUseActiveRealms = new ArrayList();
			this.allowOperationIfReposDownMap = new HashMap();
			this.realmDelimiters = new HashMap();
			this.defaultParentsInRealms = new HashMap();
			this.realmReposIndexWithBaseEntries = new HashMap();
			this.realmUserRegistryMapping = new HashMap();
			this.realmParticipatingBaseEntries = new HashMap();

			for (int var5 = 0; var5 < var7.size(); ++var5) {
				DataObject var6 = (DataObject) var7.get(var5);
				this.processRealm(var6, false);
			}
		} else if (trcLogger.isLoggable(Level.INFO)) {
			trcLogger.logp(Level.INFO, CLASSNAME, "initialize", "MISSING_REALM_CONFIGURATION");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

	}

	public String getDefaultRealmName() {
		return this.defaultRealmName;
	}

	public Set getRealmNames() {
		return this.realmDelimiters.keySet();
	}

	public String getDelimiter(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, "getDelimiter", "realmName=" + var1);
		}

		String var3 = (String) this.realmDelimiters.get(var1);
		if (var3 == null) {
			throw new InvalidArgumentException("INVALID_REALM_NAME", WIMMessageHelper.generateMsgParms(var1), CLASSNAME,
					"getDelimiter");
		} else {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.exiting(CLASSNAME, "getDelimiter", "delimiter=" + var3);
			}

			return var3;
		}
	}

	public boolean getAllowOperationIfReposDown(String var1) throws WIMException {
		boolean var3 = (Boolean) this.allowOperationIfReposDownMap.get(var1);
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, "getAllowOperationIfReposDown", "allowOperationIfReposDown=" + var3);
		}

		return var3;
	}

	public List getRealmBaseEntries(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, "getRealmBaseEntries");
		}

		if (var1 == null) {
			return new ArrayList();
		} else {
			List var3 = (List) this.realmParticipatingBaseEntries.get(var1);
			if (var3 == null) {
				throw new InvalidArgumentException("INVALID_REALM_NAME", WIMMessageHelper.generateMsgParms(var1),
						CLASSNAME, "getRealmBaseEntries");
			} else {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.exiting(CLASSNAME, "getRealmBaseEntries");
				}

				return var3;
			}
		}
	}

	public String getDefaultParentForEntityInRealm(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, "getDefaultParentForEntityInRealm",
					"entType=" + var1 + ", realmName=" + var2);
		}

		String var4 = ConfigManager.singleton().getDefaultParent(var1);
		if (var2 != null) {
			this.validateRealmName(var2);
			String var5 = null;
			if (this.defaultParentsInRealms != null) {
				Map var6 = (Map) this.defaultParentsInRealms.get(var2);
				if (var6 != null) {
					var5 = (String) var6.get(var1);
					if (var5 != null) {
						var4 = var5;
					}
				}
			}

			if (var5 == null && !this.isUniqueNameInRealm(var4, var2)) {
				var4 = null;
			}
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, "getDefaultParentForEntityInRealm", "defaultParent=" + var4);
		}

		return var4;
	}

	public boolean isUniqueNameInRealm(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, "isUniqueNameInRealm", "uniqueName=" + var1 + ", realmName=" + var2);
		}

		boolean var4 = false;
		if (var2 == null) {
			var4 = true;
		} else if (this.realmParticipatingBaseEntries != null) {
			this.validateRealmName(var2);
			if (var1 != null) {
				var1 = UniqueNameHelper.getValidUniqueName(var1);
				List var5 = (List) this.realmParticipatingBaseEntries.get(var2);
				if (var5 != null) {
					for (int var6 = 0; var6 < var5.size() && !var4; ++var6) {
						String var7 = (String) var5.get(var6);
						if (StringUtil.endsWithIgnoreCase(var1, var7)) {
							var4 = true;
						}
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, "isUniqueNameInRealm", "inRealm=" + var4);
		}

		return var4;
	}

	public List getSecurityUseActiveRealms() {
		return this.securityUseActiveRealms;
	}

	public String parseIdDelimiterVirtualRealmName(String var1, String var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "parseIdDelimiterVirtualRealmName");
		}

		String var4 = (String) this.realmDelimiters.get(var2);
		String var5 = var1;
		char var6 = '\\';
		int var7 = var1.lastIndexOf(var4);
		if (var7 != -1) {
			if (var1.charAt(var7 - 1) != var6) {
				String var8 = var1.substring(var7 + 1, var1.length());
				if (var8.equals(var2)) {
					var5 = this.removeEscapeChar(var1.substring(0, var7), var4, var6);
				}
			} else {
				var5 = this.removeEscapeChar(var1, var4, var6);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "parseIdDelimiterVirtualRealmName");
		}

		return var5;
	}

	public String getURMapInputPropertyInRealm(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getURMapInputPropertyInRealm", "realmName=" + var1 + ", urMapInfo" + var2);
		}

		String var4 = null;
		if (this.realmUserRegistryMapping != null) {
			Map var5 = (Map) this.realmUserRegistryMapping.get(var1);
			if (var5 == null || var5.size() == 0) {
				throw new InvalidArgumentException("INVALID_REALM_NAME", WIMMessageHelper.generateMsgParms(var1),
						CLASSNAME, "getURMapInputPropertyInRealm");
			}

			String[] var6 = (String[]) ((String[]) var5.get(var2));
			if (var6 != null) {
				var4 = var6[0];
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getURMapInputPropertyInRealm", "result=" + var4);
		}

		return var4;
	}

	public String getURMapOutputPropertyInRealm(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getURMapOutputPropertyInRealm", "realmName=" + var1 + ", urMapInfo" + var2);
		}

		String var4 = null;
		if (this.realmUserRegistryMapping != null) {
			Map var5 = (Map) this.realmUserRegistryMapping.get(var1);
			if (var5 == null || var5.size() == 0) {
				throw new InvalidArgumentException("INVALID_REALM_NAME", WIMMessageHelper.generateMsgParms(var1),
						CLASSNAME, "getURMapOutputPropertyInRealm");
			}

			String[] var6 = (String[]) ((String[]) var5.get(var2));
			if (var6 != null) {
				var4 = var6[1];
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getURMapOutputPropertyInRealm", "result=" + var4);
		}

		return var4;
	}

	private String removeEscapeChar(String var1, String var2, char var3) {
		StringBuffer var4 = new StringBuffer();
		int var5 = this.stringCount(var1, var2);
		if (var5 == 0) {
			return var1;
		} else {
			for (int var6 = 0; var6 < var5; ++var6) {
				int var7 = var1.indexOf(var2);
				if (var1.charAt(var7 - 1) != var3) {
					var4.append(var1.substring(0, var7 + 1));
					var1 = var1.substring(var7 + 1);
				} else {
					var4.append(var1.substring(0, var7 - 1));
					var4.append(var1.substring(var7, var7 + 1));
					var1 = var1.substring(var7 + 1);
				}
			}

			var4.append(var1);
			return var4.toString();
		}
	}

	private int stringCount(String var1, String var2) {
		int var3 = 0;
		if (var1 != null) {
			for (int var4 = var1.indexOf(var2); var4 >= 0; var4 = var1.indexOf(var2, var4 + 1)) {
				++var3;
			}
		}

		return var3;
	}

	protected Map getRepositoryIndexWithBaseEntriesByRealmName(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, "getRepositoryIndexWithBaseEntriesByRealmName", "realmName=" + var1);
		}

		Map var3 = null;
		if (this.realmReposIndexWithBaseEntries != null) {
			var3 = (Map) this.realmReposIndexWithBaseEntries.get(var1);
			if (var3 == null) {
				throw new InvalidArgumentException("INVALID_REALM_NAME", WIMMessageHelper.generateMsgParms(var1),
						CLASSNAME, "getRepositoryIndexWithBaseEntriesByRealmName");
			}
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, "getRepositoryIndexWithBaseEntriesByRealmName", "result=" + var3);
		}

		return var3;
	}

	private Map seperateParticipatingBaseEntriesByReposIndex(List var1) throws WIMException {
		HashMap var2 = null;
		if (var1 != null) {
			var2 = new HashMap();

			for (int var3 = 0; var3 < var1.size(); ++var3) {
				String var4 = (String) var1.get(var3);
				int var5 = RepositoryManager.singleton().getRepositoryIndexByUniqueName(var4);
				Object var6 = (List) var2.get(new Integer(var5));
				if (var6 == null) {
					var6 = new ArrayList();
				}

				((List) var6).add(var4);
				var2.put(new Integer(var5), var6);
			}
		}

		return var2;
	}

	private String[] getUserRegistryMappingInfo(DataObject var1) {
		String[] var2 = new String[]{var1.getString("propertyForInput"), var1.getString("propertyForOutput")};
		return var2;
	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "dynamicUpdateConfig", "eventType=" + var1);
		}

		if ("websphere.usermanager.serviceprovider.add.realm".equals(var1)) {
			DataObject var4 = (DataObject) var2.get("DYNA_CONFIG_KEY_REALM_CONFIG");
			if (var4 != null) {
				this.processRealm(var4, true);
			}
		} else if (("websphere.usermanager.serviceprovider.add.participatingbaseentry".equals(var1)
				|| "websphere.usermanager.serviceprovider.add.defaultparenttorealm".equals(var1)) && var2 != null) {
			String var8 = (String) var2.get("DYNA_CONFIG_KEY_REALM_NAME");
			if (var8 == null) {
				throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_MISSING_VALUE",
						WIMMessageHelper.generateMsgParms("DYNA_CONFIG_KEY_REALM_NAME", var1), CLASSNAME,
						"dynamicUpdateConfig");
			}

			this.validateRealmName(var8);
			String var5;
			Object var6;
			if ("websphere.usermanager.serviceprovider.add.participatingbaseentry".equals(var1)) {
				var5 = (String) var2.get("DYNA_CONFIG_KEY_BASE_ENTRY");
				if (var5 == null) {
					throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_MISSING_VALUE",
							WIMMessageHelper.generateMsgParms("DYNA_CONFIG_KEY_REALM_NAME", var1), CLASSNAME,
							"dynamicUpdateConfig");
				}

				if (!ConfigValidator.isBaseEntryInRepository(
						(ConfigurationProviderType) ConfigManager.singleton().getConfig(), var5)) {
					throw new DynamicUpdateConfigException("BASE_ENTRY_CANNOT_BE_ADDED_TO_REALM",
							WIMMessageHelper.generateMsgParms(var5, var8), CLASSNAME, "dynamicUpdateConfig");
				}

				var6 = (List) this.realmParticipatingBaseEntries.get(var8);
				if (var6 == null) {
					var6 = new ArrayList();
				}

				((List) var6).add(var5);
				this.realmParticipatingBaseEntries.put(var8, var6);
				Map var7 = this.seperateParticipatingBaseEntriesByReposIndex((List) var6);
				if (var7 != null) {
					this.realmReposIndexWithBaseEntries.put(var8, var7);
				}
			} else if ("websphere.usermanager.serviceprovider.add.defaultparenttorealm".equals(var1)) {
				var5 = (String) var2.get("DYNA_CONFIG_KEY_ENTITY_TYPE");
				if (var5 == null) {
					throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_MISSING_VALUE",
							WIMMessageHelper.generateMsgParms("DYNA_CONFIG_KEY_ENTITY_TYPE", var1), CLASSNAME,
							"dynamicUpdateConfig");
				}

				List var9 = ConfigManager.singleton().getSupportedEntityTypes();
				if (!var9.contains(var5)) {
					throw new DynamicUpdateConfigException("ENTITY_TYPE_NOT_SUPPORTED",
							WIMMessageHelper.generateMsgParms(var5), CLASSNAME, "dynamicUpdateConfig");
				}

				var6 = (Map) this.defaultParentsInRealms.get(var8);
				if (var6 != null) {
					if (((Map) var6).get(var5) != null) {
						throw new DynamicUpdateConfigException("DEFAULT_PARENT_ALREADY_DEFINED",
								WIMMessageHelper.generateMsgParms(var5, var8), CLASSNAME, "dynamicUpdateConfig");
					}
				} else {
					var6 = new HashMap();
				}

				String var10 = (String) var2.get("DYNA_CONFIG_KEY_DEFAULT_PARENT");
				if (var10 == null) {
					throw new DynamicUpdateConfigException("DYNA_UPDATE_CONFIG_MISSING_VALUE",
							WIMMessageHelper.generateMsgParms("DYNA_CONFIG_KEY_DEFAULT_PARENT", var1), CLASSNAME,
							"dynamicUpdateConfig");
				}

				if (!this.isUniqueNameInRealm(var10, var8)) {
					throw new DynamicUpdateConfigException("ENTITY_NOT_IN_REALM_SCOPE",
							WIMMessageHelper.generateMsgParms(var10, var8), CLASSNAME, "dynamicUpdateConfig");
				}

				((Map) var6).put(var5, var10);
				this.defaultParentsInRealms.put(var8, var6);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "dynamicUpdateConfig");
		}

	}

	private void validateRealmName(String var1) throws WIMException {
		Set var3 = this.getRealmNames();
		if (var1 != null && var3 != null && !var3.contains(var1)) {
			throw new InvalidArgumentException("INVALID_REALM_NAME", WIMMessageHelper.generateMsgParms(var1), CLASSNAME,
					"validateRealmName");
		}
	}

	private void processRealm(DataObject var1, boolean var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "processRealm", "dynaUpdate=" + var2);
		}

		String var4 = var1.getString("name");
		String var5 = var1.getString("securityUse");
		if (var5.equalsIgnoreCase("active")) {
			this.securityUseActiveRealms.add(var4);
		}

		String var6 = var1.getString("delimiter");
		this.realmDelimiters.put(var4, var6);
		Boolean var7 = var1.getBoolean("allowOperationIfReposDown");
		this.allowOperationIfReposDownMap.put(var4, var7);
		List var8 = var1.getList("participatingBaseEntries");
		if (var8.size() == 0) {
			if (var2) {
				throw new DynamicUpdateConfigException("MISSING_REALM_RELATED_PARAMETER",
						WIMMessageHelper.generateMsgParms("participatingBaseEntries", var4), CLASSNAME, "processRealm");
			} else {
				throw new InitializationException("MISSING_REALM_RELATED_PARAMETER",
						WIMMessageHelper.generateMsgParms("participatingBaseEntries", var4), CLASSNAME, "processRealm");
			}
		} else {
			ArrayList var9 = new ArrayList();

			for (int var10 = 0; var10 < var8.size(); ++var10) {
				DataObject var11 = (DataObject) var8.get(var10);
				String var12 = var11.getString("name");
				if (var12 != null && !RepositoryManager.matchBaseEntryIgnoreCase(this.baseEntries, var12)) {
					if (var2) {
						throw new DynamicUpdateConfigException("INVALID_BASE_ENTRY_NAME",
								WIMMessageHelper.generateMsgParms(var12, "participatingBaseEntries"), CLASSNAME,
								"processRealm");
					}

					throw new InitializationException("INVALID_BASE_ENTRY_NAME",
							WIMMessageHelper.generateMsgParms(var12, "participatingBaseEntries"), CLASSNAME,
							"processRealm");
				}

				if (var12 != null) {
					var12 = UniqueNameHelper.getValidUniqueName(var12);
					var9.add(var12);
				}
			}

			this.realmParticipatingBaseEntries.put(var4, var9);
			Map var26 = this.seperateParticipatingBaseEntriesByReposIndex(var9);
			if (var26 != null) {
				this.realmReposIndexWithBaseEntries.put(var4, var26);
			}

			HashMap var27 = new HashMap();
			List var28 = var1.getList("defaultParents");

			DataObject var14;
			for (int var13 = 0; var13 < var28.size(); ++var13) {
				var14 = (DataObject) var28.get(var13);
				String var15 = var14.getString("entityTypeName");
				String var16 = var14.getString("parentUniqueName");
				var27.put(var15, var16);
			}

			this.defaultParentsInRealms.put(var4, var27);
			HashMap var29 = new HashMap();
			var14 = var1.getDataObject("uniqueUserIdMapping");
			this.checkRealmMapping(var14, var4, "uniqueUserIdMapping", var2);
			String[] var30 = this.getUserRegistryMappingInfo(var14);
			var29.put("uniqueUserIdMapping", var30);
			DataObject var31 = var1.getDataObject("userSecurityNameMapping");
			String[] var17 = this.getUserRegistryMappingInfo(var31);
			var29.put("userSecurityNameMapping", var17);
			DataObject var18 = var1.getDataObject("userDisplayNameMapping");
			String[] var19 = this.getUserRegistryMappingInfo(var18);
			var29.put("userDisplayNameMapping", var19);
			DataObject var20 = var1.getDataObject("uniqueGroupIdMapping");
			String[] var21 = this.getUserRegistryMappingInfo(var20);
			var29.put("uniqueGroupIdMapping", var21);
			DataObject var22 = var1.getDataObject("groupSecurityNameMapping");
			String[] var23 = this.getUserRegistryMappingInfo(var22);
			var29.put("groupSecurityNameMapping", var23);
			DataObject var24 = var1.getDataObject("groupDisplayNameMapping");
			String[] var25 = this.getUserRegistryMappingInfo(var24);
			var29.put("groupDisplayNameMapping", var25);
			this.realmUserRegistryMapping.put(var4, var29);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "processRealm");
			}

		}
	}

	private void checkRealmMapping(DataObject var1, String var2, String var3, boolean var4) throws WIMException {
		if (var1 == null) {
			if (var4) {
				throw new DynamicUpdateConfigException("MISSING_REALM_RELATED_PARAMETER",
						WIMMessageHelper.generateMsgParms(var3, var2), CLASSNAME, "checkRealmMapping");
			} else {
				throw new InitializationException("MISSING_REALM_RELATED_PARAMETER",
						WIMMessageHelper.generateMsgParms(var3, var2), CLASSNAME, "checkRealmMapping");
			}
		}
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
	}
}