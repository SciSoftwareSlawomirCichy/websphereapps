package com.ibm.ejs.container;

import com.ibm.CORBA.iiop.IOR;
import com.ibm.CORBA.iiop.ObjectKey;
import com.ibm.CORBA.iiop.Profile;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.oa.EJSORB;
import com.ibm.ejs.oa.UserKey;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.ByteArray;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ejbcontainer.BasicEJBInfo;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.wlm.ClusterIdentityHelper;
import com.ibm.wsspi.cluster.Identity;
import java.io.Serializable;
import java.rmi.Remote;
import javax.ejb.EJBException;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;

public class EJBInfoImpl implements BasicEJBInfo {
	private static final String CLASS_NAME = "com.ibm.ejs.container.EJBInfoImpl";
	private boolean isEJBHome;
	private boolean isEJBObject;
	private IOR ivIOR = null;
	private Identity ivIORClusterIdentity = null;
	private String ivIORTypeid = null;
	private int ivIORVersion;
	private short ivIORExtVersion;
	private String ivIORClass = null;
	private String ivIORCodebase = null;
	private Profile ivProfile = null;
	private String ivProfileHost = null;
	private String ivProfileCodeBase = null;
	private String ivProfileHostIP = null;
	private int ivProfilePort;
	private byte ivProfileMajor;
	private byte ivProfileMinor;
	private ObjectKey ivObjectKey = null;
	private String ivObjectKeyMagic = null;
	private String ivObjectKeySCID = null;
	private String ivObjectKeyServerID = null;
	private String ivObjectKeyServerUUID = null;
	private UserKey ivUserKey = null;
	private J2EEName ivUserKeyJ2EEName = null;
	private Serializable ivUserKeyPrimaryKey = null;
	private String ivUserKeyMagic = null;
	private byte ivUserKeyVersion;
	private boolean ivUserKeyWLMEnabled;
	private Identity ivUserKeyClusterIdentity = null;
	private String ivUserKeyObjectAdapter = null;
	private String ivUserKeyHashValue = null;
	private String ivUserKeyServerName = null;
	private String ivUserKeyObjectAdapterName = null;
	private boolean ivClusterIdentitySet = false;
	private boolean ivHostSet = false;
	private boolean ivHostIPSet = false;
	private boolean ivPortSet = false;
	private boolean ivJ2eeNameSet = false;
	private boolean ivPrimaryKeySet = false;
	private boolean ivServerNameSet = false;
	private boolean ivInitComplete = false;
	private static final TraceComponent tc = Tr.register(EJBInfoImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public EJBInfoImpl(Object ejbObject) {
		String inputClassName = ejbObject.getClass().getName();
		this.isEJBHome = ejbObject instanceof EJBHome;
		this.isEJBObject = ejbObject instanceof EJBObject;
		EJBException ejbex;
		if (ejbObject instanceof org.omg.CORBA.Object) {
			try {
				this.ivIOR = EJSORB.init().objectToIOR((org.omg.CORBA.Object) ejbObject);
				this.ivIORClusterIdentity = ClusterIdentityHelper.getClusterIdentity((Remote) ejbObject,
						EJSORB.getORBInstance());
				this.ivClusterIdentitySet = true;
				this.ivIORTypeid = this.ivIOR.getTypeId();
				this.ivIORVersion = this.ivIOR.getPartnerVersion();
				this.ivIORExtVersion = this.ivIOR.getPartnerExtended();
				this.ivIORClass = this.ivIOR.getClass().getName();
				this.ivIORCodebase = this.ivIOR.getCodebase();
			} catch (Throwable var12) {
				FFDCFilter.processException(var12, "com.ibm.ejs.container.EJBInfoImpl.initialize", "134", this);
				ejbex = ExceptionUtil.EJBException(
						"Exception thrown processing IOR for EJBInfo object for class: " + inputClassName, var12);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "\n " + ejbex.getMessage());
				}

				throw ejbex;
			}

			if (this.ivIOR != null) {
				try {
					this.ivProfile = this.ivIOR.getProfile();
					this.ivProfileHost = this.ivProfile.getHost();
					this.ivHostSet = true;
					this.ivProfileCodeBase = this.ivProfile.getCodebase();
					this.ivProfileHostIP = this.ivProfile.getHostIPAddress();
					this.ivHostIPSet = true;
					this.ivProfilePort = this.ivProfile.getPort();
					this.ivPortSet = true;
					this.ivProfileMajor = this.ivProfile.getMajor();
					this.ivProfileMinor = this.ivProfile.getMinor();
				} catch (Throwable var11) {
					FFDCFilter.processException(var11, "com.ibm.ejs.container.EJBInfoImpl.initialize", "152", this);
					ejbex = ExceptionUtil.EJBException(
							"Exception thrown processing IOR for EJBInfo object for class: " + inputClassName, var11);
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "\n " + ejbex.getMessage());
					}

					throw ejbex;
				}

				if (this.ivProfile != null) {
					try {
						this.ivObjectKey = this.ivProfile.getObjectKeyObject();
						int magic = this.ivObjectKey.getMagic();
						byte[] b_magic = new byte[]{(byte) (magic >> 24), (byte) (magic >> 16), (byte) (magic >> 8),
								(byte) magic};
						this.ivObjectKeyMagic = new String(b_magic) + " 0x" + Integer.toHexString(magic);
						this.ivObjectKeySCID = "0x" + Integer.toHexString(this.ivObjectKey.getSCID());
						this.ivObjectKeyServerID = this.ivObjectKey.getServerId() + " (0x"
								+ Integer.toHexString(this.ivObjectKey.getServerId()) + ")";
						this.ivObjectKeyServerUUID = "0x" + new ByteArray(this.ivObjectKey.getServerUUID());
					} catch (Throwable var10) {
						FFDCFilter.processException(var10, "com.ibm.ejs.container.EJBInfoImpl.initialize", "170", this);
						ejbex = ExceptionUtil.EJBException(
								"Exception thrown processing IOR for EJBInfo object for class: " + inputClassName,
								var10);
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "\n " + ejbex.getMessage());
						}

						throw ejbex;
					}

					if (this.ivObjectKey != null) {
						try {
							com.ibm.CORBA.iiop.UserKey cuKey = this.ivObjectKey.getUserKeyObject();
							this.ivUserKey = new UserKey(cuKey.getBytes());
							int magic = this.ivUserKey.getMagicNumber();
							byte[] servantKeyBytes = this.ivUserKey.getServantKey();
							byte[] b_magic;
							if (servantKeyBytes[0] == -84 && servantKeyBytes[1] == -84) {
								b_magic = BeanId.getJ2EENameBytes(servantKeyBytes);
								this.ivUserKeyJ2EEName = EJSContainer.getDefaultContainer().getJ2EENameFactory()
										.create(b_magic);
								this.ivJ2eeNameSet = true;
								if (this.isEJBObject) {
									this.ivUserKeyPrimaryKey = BeanId.getPrimaryKey(servantKeyBytes);
								}
							} else {
								if (servantKeyBytes[0] != -83 || servantKeyBytes[1] != -84) {
									String msg = "Creation of EJBInfoImpl object failed because the input object is invalid. The ejbObject parameter must be a CORBA stub for a remote EJBHome, EJBObject, or EJB business interface wrapper.";
									EJBException ex = new EJBException(msg);
									FFDCFilter.processException(ex, "com.ibm.ejs.container.EJBInfoImpl.initialize",
											"234", this);
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										byte[] header = new byte[]{servantKeyBytes[0], servantKeyBytes[1]};
										Tr.debug(tc,
												"\nEJBInfo object requested for a CORBA object that does not have the servant key header for an EJB: "
														+ (new ByteArray(header)).toString() + ", input Class name: "
														+ inputClassName);
									}

									throw ex;
								}

								WrapperId wrapperId = new WrapperId(servantKeyBytes);
								com.ibm.ejs.container.util.ByteArray byteArray = wrapperId.getBeanIdArray();
								EJSContainer container = EJSContainer.getDefaultContainer();
								BeanId beanId = BeanId.getBeanId(byteArray, container);
								this.ivUserKeyJ2EEName = beanId.getJ2EEName();
								this.ivJ2eeNameSet = true;
								this.isEJBObject = true;
								this.ivUserKeyPrimaryKey = beanId.getPrimaryKey();
							}

							this.ivPrimaryKeySet = true;
							b_magic = new byte[]{(byte) (magic >> 24), (byte) (magic >> 16), (byte) (magic >> 8),
									(byte) magic};
							this.ivUserKeyMagic = new String(b_magic) + " 0x" + Integer.toHexString(magic);
							this.ivUserKeyVersion = this.ivUserKey.getVersionNumber();
							this.ivUserKeyWLMEnabled = this.ivUserKey.getWLMObjectRefType() == 1;
							this.ivUserKeyObjectAdapter = new String(this.ivUserKey.getOAKey());
							this.ivUserKeyHashValue = "0x" + Integer.toHexString(this.ivUserKey.getHashValue());
							if (this.ivIORClusterIdentity == null) {
								this.ivUserKeyServerName = this.ivUserKey.getName();
							}

							this.ivServerNameSet = true;
							this.ivUserKeyObjectAdapterName = this.ivUserKey.getOAName();
							this.ivInitComplete = true;
						} catch (Throwable var13) {
							FFDCFilter.processException(var13, "com.ibm.ejs.container.EJBInfoImpl.initialize", "203",
									this);
							ejbex = ExceptionUtil
									.EJBException("Exception thrown processing UserKey for EJBInfo object for class: "
											+ inputClassName, var13);
							if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
								Tr.debug(tc, "\n " + ejbex.getMessage());
							}

							throw ejbex;
						}
					}
				}
			}

		} else {
			String msg = "Creation of EJBInfoImpl object failed because the input object is invalid. The ejbObject parameter must be a CORBA stub for a remote EJBHome, EJBObject, or EJB business interface wrapper.";
			ejbex = new EJBException(msg);
			FFDCFilter.processException(ejbex, "com.ibm.ejs.container.EJBInfoImpl.initialize", "217", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "\nEJBInfo object requested for an object that is NOT a CORBA object: " + inputClassName);
			}

			throw ejbex;
		}
	}

	public J2EEName getJ2EEName() {
		if (!this.ivJ2eeNameSet) {
			EJBException ex = new EJBException("The J2EEName field has not been set in EJBInfoImpl object.");
			FFDCFilter.processException(ex, "com.ibm.ejs.container.EJBInfoImpl.getJ2EEName", "231", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"\nThe J2EEName field was not set because an exception occurred during initializationof the EJBInfoImpl object. ");
			}

			throw ex;
		} else {
			return this.ivUserKeyJ2EEName;
		}
	}

	public int getPort() {
		if (!this.ivPortSet) {
			EJBException ex = new EJBException("The Port field has not been set in EJBInfoImpl object.");
			FFDCFilter.processException(ex, "com.ibm.ejs.container.EJBInfoImpl.getPort", "246", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"\nThe Port field was not set because an exception occurred during initializationof the EJBInfoImpl object.");
			}

			throw ex;
		} else {
			return this.ivProfilePort;
		}
	}

	public String getHost() {
		if (!this.ivHostSet) {
			EJBException ex = new EJBException("The Host field has not been set in EJBInfoImpl object.");
			FFDCFilter.processException(ex, "com.ibm.ejs.container.EJBInfoImpl.getHost", "262", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"\nThe Host field was not set because an exception occurred during initializationof the EJBInfoImpl object.");
			}

			throw ex;
		} else {
			return this.ivProfileHost;
		}
	}

	public String getHostIP() {
		if (!this.ivHostIPSet) {
			EJBException ex = new EJBException("The HostIP field has not been set in EJBInfoImpl object.");
			FFDCFilter.processException(ex, "com.ibm.ejs.container.EJBInfoImpl.getHostIP", "278", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"\nThe HostIP field was not set because an exception occurred during initializationof the EJBInfoImpl object.");
			}

			throw ex;
		} else {
			return this.ivProfileHostIP;
		}
	}

	public Serializable getPrimaryKey() {
		if (!this.ivPrimaryKeySet) {
			EJBException ex = new EJBException("The Primary key field has not been set in EJBInfoImpl object.");
			FFDCFilter.processException(ex, "com.ibm.ejs.container.EJBInfoImpl.getPrimaryKey", "294", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"\nThe Primary key field was not set because an exception occurred during initializationof the EJBInfoImpl object.");
			}

			throw ex;
		} else {
			return this.ivUserKeyPrimaryKey;
		}
	}

	public Identity getClusterIdentity() {
		if (!this.ivClusterIdentitySet) {
			EJBException ex = new EJBException("The Cluster Identity field has not been set in EJBInfoImpl object.");
			FFDCFilter.processException(ex, "com.ibm.ejs.container.EJBInfoImpl.getClusterIdentity", "310", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"\nThe ClusterIdentity field was not set because an exception occurred during initializationof the EJBInfoImpl object.");
			}

			throw ex;
		} else {
			return this.ivUserKeyClusterIdentity;
		}
	}

	public String getServerName() {
		if (!this.ivServerNameSet) {
			EJBException ex = new EJBException("The ServerName field has not been set in EJBInfoImpl object.");
			FFDCFilter.processException(ex, "com.ibm.ejs.container.EJBInfoImpl.getServerName", "325", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"\nThe ServerName field was not set because an exception occurred during initializationof the EJBInfoImpl object.");
			}

			throw ex;
		} else {
			return this.ivUserKeyServerName;
		}
	}

	public String toString() {
		String separator = ContainerProperties.LineSeparator;
		StringBuffer sb = new StringBuffer();
		String sep = "                                 ";
		String sep2 = "                                     ";
		if (!this.ivInitComplete) {
			sb.append(separator + sep + "!!!! Warning, an exception was thrown during "
					+ "the creation of this object so the output may be incomplete.  "
					+ "See FFDC logs for details. !!!!");
		}

		sb.append(separator + sep + "**************    EJBInfo Dump    **************");
		sb.append(separator + sep + "*** IOR Fields ***");
		sb.append(separator + sep2 + "Type ID = ");
		sb.append(this.ivIORTypeid);
		sb.append(separator + sep2 + "Version = ");
		sb.append(this.ivIORVersion);
		sb.append(separator + sep2 + "External Version = ");
		sb.append(this.ivIORExtVersion);
		sb.append(separator + sep2 + "Class = ");
		sb.append(this.ivIORClass);
		sb.append(separator + sep2 + "Code Base = ");
		sb.append(this.ivIORCodebase);
		sb.append(separator + sep2 + "Cluster Identity = ");
		sb.append(this.ivIORClusterIdentity);
		sb.append(separator + separator + sep + "*** Profile Fields ***");
		sb.append(separator + sep2 + "Host = ");
		sb.append(this.ivProfileHost);
		sb.append(separator + sep2 + "Code Base = ");
		sb.append(this.ivProfileCodeBase);
		sb.append(separator + sep2 + "Host IP = ");
		sb.append(this.ivProfileHostIP);
		sb.append(separator + sep2 + "Port = ");
		sb.append(this.ivProfilePort);
		sb.append(separator + sep2 + "Major Version = ");
		sb.append(this.ivProfileMajor);
		sb.append(separator + sep2 + "Minor Version = ");
		sb.append(this.ivProfileMinor);
		sb.append(separator + separator + sep + "*** Object Key Fields ***");
		sb.append(separator + sep2 + "Magic = ");
		sb.append(this.ivObjectKeyMagic);
		sb.append(separator + sep2 + "SCID = ");
		sb.append(this.ivObjectKeySCID);
		sb.append(separator + sep2 + "Servid ID = ");
		sb.append(this.ivObjectKeyServerID);
		sb.append(separator + sep2 + "Server UUID = ");
		sb.append(this.ivObjectKeyServerUUID);
		sb.append(separator + separator + sep + "*** User Key Fields ***");
		sb.append(separator + sep2 + "J2EE Name = ");
		sb.append(this.ivUserKeyJ2EEName);
		sb.append(separator + sep2 + "Primary Key = ");
		if (this.isEJBHome) {
			sb.append("[Not Applicable]");
		} else {
			sb.append(this.ivUserKeyPrimaryKey);
		}

		sb.append(separator + sep2 + "Magic = ");
		sb.append(this.ivUserKeyMagic);
		sb.append(separator + sep2 + "Version = ");
		sb.append(this.ivUserKeyVersion);
		sb.append(separator + sep2 + "Hash Value = ");
		sb.append(this.ivUserKeyHashValue);
		sb.append(separator + sep2 + "Server Name = ");
		if (this.ivIORClusterIdentity == null) {
			sb.append(this.ivUserKeyServerName);
		} else {
			sb.append("See Cluster Identity");
		}

		sb.append(separator + sep2 + "Object Adapter = ");
		sb.append(this.ivUserKeyObjectAdapterName);
		return sb.toString();
	}
}