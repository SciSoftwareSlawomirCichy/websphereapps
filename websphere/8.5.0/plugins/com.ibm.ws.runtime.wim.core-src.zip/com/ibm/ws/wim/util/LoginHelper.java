package com.ibm.ws.wim.util;

import com.ibm.websphere.wim.exception.CertificateMapFailedException;
import com.ibm.websphere.wim.exception.CertificateMapNotSupportedException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.federation.FederationEntity;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.security.cert.X509Certificate;

public class LoginHelper {
	private static final String CLASSNAME = "LoginHelper";
	private static final String USER_SECURITY_NAME_PROPERTY = "userSecurityNameProperty";
	private static final String CONTEXT_KEY_REALM = "realm";

	public static String getRepositoryIdByUniqueId(String var0) throws WIMException {
		String var1 = null;
		if (RepositoryManager.singleton().isEntryJoin()) {
			FederationEntity var2 = RepositoryManager.singleton().getFederationRepository().get(var0);
			if (var2 != null) {
				String var3 = var2.getRepositoryId();
				var1 = var3;
			}
		} else {
			var1 = RepositoryManager.singleton().getRepositoryIds()[0];
		}

		return var1;
	}

	public static Set getSpecifiedRealms(DataObject var0) {
		HashSet var1 = new HashSet();
		List var2 = var0.getList("contexts");

		for (int var3 = 0; var3 < var2.size(); ++var3) {
			DataObject var4 = (DataObject) var2.get(var3);
			String var5 = var4.getString("key");
			if (var5 != null && var5.equals("realm")) {
				String var6 = var4.getString("value");
				var1.add(var6);
			}
		}

		return var1;
	}

	public static Set getWimNodes(Set var0) throws WIMException {
		HashSet var1 = new HashSet();
		if (var0 != null) {
			Iterator var2 = var0.iterator();

			while (var2.hasNext()) {
				String var3 = (String) var2.next();
				String var4 = getWimNode(var3);
				if (var4 != null) {
					var1.add(var4);
				}
			}
		}

		return var1;
	}

	public static String getWimNode(String var0) throws WIMException {
		Object var1 = null;
		return (String) var1;
	}

	private static DataObject getUserRegistryConfigNode() throws WIMException {
		DataObject var0 = ConfigManager.singleton().getConfig();
		DataObject var1 = var0.getDataObject("UserRegistry");
		return var1;
	}

	public static String getUserSecurityName() throws WIMException {
		String var0 = null;
		DataObject var1 = getUserRegistryConfigNode();
		var0 = var1.getString("userSecurityNameProperty");
		if (var0 != null) {
			var0 = var0.trim();
		}

		return var0;
	}

	public static String mapCertificate(X509Certificate var0) throws WIMException {
		String var1 = null;

		try {
			var1 = var0.getSubjectDN().getName();
		} catch (Exception var3) {
			throw new WIMSystemException(new CertificateMapNotSupportedException(var3.getMessage()));
		}

		if (!isValidUser(var1)) {
			throw new WIMSystemException(new CertificateMapFailedException(var1));
		} else {
			return null;
		}
	}

	public static boolean isValidUser(String var0) {
		return true;
	}

	public static String getRealmFromDataGraph(DataGraph var0) {
		return null;
	}

	public static String[] parseFilter(String var0) throws WIMException {
		Vector var5 = new Vector();
		int var3 = 0;
		int var2 = 0;

		for (int var4 = var0.length(); var3 < var4; var2 = var3) {
			var3 = var0.indexOf("${", var2);
			if (var3 == -1) {
				if (var2 < var4) {
					var5.addElement(var0.substring(var2));
				}
				break;
			}

			if (var2 < var3) {
				var5.addElement(var0.substring(var2, var3 - 1));
			}

			var2 = var3;
			var3 = var0.indexOf("}", var3);
			if (var3 == -1) {
				throw new WIMSystemException(
						"new CertificateMapFailedException (\"_ERR_CERTIFICATE_FILTER_SYNTAX\", CLASSNAME, METHODNAME, \"\")");
			}

			++var3;
			var5.addElement(var0.substring(var2, var3));
		}

		String[] var6 = new String[var5.size()];

		for (int var7 = 0; var7 < var5.size(); ++var7) {
			var6[var7] = (String) var5.elementAt(var7);
		}

		return var6;
	}

	public static Object getFilterValue(X509Certificate var0, String var1) throws CertificateMapFailedException {
		if (var1.equals("${UniqueKey}")) {
			return getUniqueKey(var0);
		} else if (var1.equals("${PublicKey}")) {
			return var0.getPublicKey().getEncoded();
		} else {
			if (!var1.equals("${BasicConstraints}")) {
				if (var1.startsWith("${Issuer")) {
					return getDnSubField(var1.substring(8, var1.length() - 1), var0.getIssuerDN().getName());
				}

				if (!var1.equals("${IssuerUniqueID}") && !var1.equals("${KeyUsage}")) {
					if (var1.equals("${NotAfter}")) {
						return var0.getNotAfter().toString();
					}

					if (var1.equals("${NotBefore}")) {
						return var0.getNotBefore().toString();
					}

					if (var1.equals("${SerialNumber}")) {
						return var0.getSerialNumber();
					}

					if (var1.equals("${SigAlgName}")) {
						return var0.getSigAlgName();
					}

					if (var1.equals("${SigAlgOID}")) {
						return var0.getSigAlgOID();
					}

					if (var1.equals("${SigAlgParams}")) {
						return var0.getSigAlgParams();
					}

					if (!var1.equals("${Signature}")) {
						if (var1.startsWith("${Subject")) {
							return getDnSubField(var1.substring(9, var1.length() - 1), var0.getSubjectDN().getName());
						}

						if (!var1.equals("${SubjectUniqueID}")) {
							if (var1.equals("${TBSCertificate}")) {
								throw new CertificateMapFailedException(
										"WMMMessageKey._ERR_CERTIFICATE_FILTER_NOT_SUPPORTED, CLASSNAME, METHODNAME, WMMMessageHelper.generateMsgParms(\"getTBSCertificate()\")");
							}

							if (var1.equals("${Version}")) {
								return new Integer(var0.getVersion());
							}

							throw new CertificateMapFailedException(
									"WMMMessageKey._ERR_CERTIFICATE_FILTER_UNKNOWN_FIELD, CLASSNAME, METHODNAME, WMMMessageHelper.generateMsgParms(filterElement)");
						}
					}
				}
			}

			return null;
		}
	}

	public static String getDnSubField(String var0, String var1) throws CertificateMapFailedException {
		if (var0.equals("DN")) {
			return var1;
		} else {
			StringTokenizer var3 = new StringTokenizer(var1);

			String var4;
			String var5;
			do {
				try {
					var4 = var3.nextToken(",= ");
					var5 = var3.nextToken(",");
					if (var5 != null) {
						var5 = var5.substring(1);
					}
				} catch (NoSuchElementException var7) {
					throw new CertificateMapFailedException(
							"WMMMessageKey._ERR_CERTIFICATE_FILTER_UNKNOWN_FIELD, CLASSNAME, METHODNAME, WMMMessageHelper.generateMsgParms(\"DN: \" + varName)");
				}
			} while (!var4.equals(var0));

			return var5;
		}
	}

	public static String getUniqueKey(X509Certificate var0) {
		StringBuffer var1 = new StringBuffer("subjectDN:");
		var1.append(var0.getSubjectDN().getName()).append("issuerDN:").append(var0.getIssuerDN().getName());
		return Base64Coder.base64Encode(getDigest(var1.toString()));
	}

	public static String getDigest(String var0) {
		MessageDigest var1;
		try {
			var1 = MessageDigest.getInstance("MD5");
		} catch (Exception var3) {
			return null;
		}

		var1.update(StringUtil.getBytes(var0));
		return StringUtil.toString(var1.digest());
	}

	public static String getContextProperty(DataObject var0, String var1) {
		String var2 = "";
		List var3 = var0.getList("contexts");

		for (int var4 = 0; var4 < var3.size(); ++var4) {
			DataObject var5 = (DataObject) var3.get(var4);
			String var6 = var5.getString("key");
			if (var6 != null && var6.equals(var1)) {
				var2 = var5.getString("value");
				break;
			}
		}

		return var2;
	}
}