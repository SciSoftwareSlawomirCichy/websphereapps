package com.google.inject.internal;

import java.lang.reflect.Array;

public final class ObjectArrays {
	public static <T> T[] newArray(T[] reference, int length) {
		Class<?> type = reference.getClass().getComponentType();
		T[] result = (Object[]) ((Object[]) Array.newInstance(type, length));
		return result;
	}
}