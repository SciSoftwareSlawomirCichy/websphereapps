package com.ibm.ws.wim.configmodel;

public interface RealmDefaultParentType {
	String getEntityTypeName();

	void setEntityTypeName(String var1);

	String getParentUniqueName();

	void setParentUniqueName(String var1);
}