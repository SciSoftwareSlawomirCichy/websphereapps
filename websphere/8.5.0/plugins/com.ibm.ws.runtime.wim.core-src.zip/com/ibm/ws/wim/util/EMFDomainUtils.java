package com.ibm.ws.wim.util;

import com.ibm.websphere.wim.DomainConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.ws.bootstrap.ExtClassLoader;
import java.util.HashMap;
import java.util.Map;
import org.eclipse.emf.ecore.impl.DebugStreamInstance;
import org.eclipse.emf.ecore.impl.EPackageRegistryImpl;

public class EMFDomainUtils implements DomainConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final ThreadLocal<Map<String, Object>> vmmDomainMap;
	private static boolean debugEnabled;

	private static ClassLoader getContextClassLoader() {
		String var0 = "getContextClassLoader";
		ClassLoader var1 = null;
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var0, "Getting thread context class loader when security is enabled");
		}

		if (System.getSecurityManager() != null) {
			var1 = (new ContextClassLoaderGetter()).getContextClassLoader();
		} else {
			var1 = Thread.currentThread().getContextClassLoader();
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var0,
						"Getting thread context class loader when security is disabled");
			}
		}

		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var0, "RETURN thread context class loader :" + var1);
		}

		return var1;
	}

	public static String getDomainId() {
		String var0 = "getDomainId";
		String var1 = null;
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var0, "Entering");
		}

		var1 = DomainManagerUtils.getDomainId();
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var0, "RETURN domain ID=" + var1);
		}

		return var1;
	}

	public static ClassLoader getWASExtClassLoader() {
		String var0 = "getWASExtClassLoader";
		Object var1 = ExtClassLoader.getInstance();
		ClassLoader var2 = getContextClassLoader();
		DebugStreamInstance.debug(CLASSNAME, var0, "Current context CL:" + var2 + ": parent: " + var2.getParent());
		if (var1 == null) {
			var1 = var2;
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var0,
						"Returning Context ClassLoader as WAS extension class loader is not available");
			}
		} else if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var0, "Returning WAS extension class loader");
		}

		return (ClassLoader) var1;
	}

	public static boolean isInVMMDomainThreadContext() {
		String var0 = "isInVMMDomainThreadContext";
		Map var1 = (Map) vmmDomainMap.get();
		if (var1 != null && ((String) var1.get("COMPONENT_THREAD_CONTEXT_NAME")).equals("vmm")) {
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var0,
						"Current thread=" + Thread.currentThread().getName() + " is in VMM context");
			}

			return true;
		} else {
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var0,
						"Current thread=" + Thread.currentThread().getName() + " is not in VMM context");
			}

			return false;
		}
	}

	public static void setVMMThreadDomainContextWithClassLoader(String var0, ClassLoader var1) {
		String var2 = "setVMMThreadDomainContextWithClassLoader";
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var2, "Entering");
		}

		if (vmmDomainMap.get() != null) {
			int var4 = incrementThreadContextCount((Map) vmmDomainMap.get());
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2, "Setup VMM context in thread="
						+ Thread.currentThread().getName() + " with context reference count=" + var4);
			}

		} else {
			HashMap var3 = new HashMap();
			if (var0 == null) {
				var3.put("vmmDomainName", "admin");
			} else {
				var3.put("vmmDomainName", var0);
			}

			var3.put("vmmDomainName", var0);
			var3.put("COMPONENT_THREAD_CONTEXT_NAME", "vmm");
			var3.put("vmm_loaded_classloader", var1);
			var3.put("DOMAIN_CONTEXT_REF_COUNT", new Integer(1));
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2, "Setup VMM context in thread="
						+ Thread.currentThread().getName() + " with context reference count=1 for domain:" + var0);
			}

			vmmDomainMap.set(var3);
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2, "Exiting");
			}

		}
	}

	private static synchronized int incrementThreadContextCount(Map var0) {
		String var1 = "incrementThreadContextCount";
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var1, "Incrementing thread Context Count");
		}

		Integer var2 = (Integer) var0.get("DOMAIN_CONTEXT_REF_COUNT");
		int var3 = var2;
		++var3;
		var2 = new Integer(var3);
		var0.put("DOMAIN_CONTEXT_REF_COUNT", var2);
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var1, "Returning Incremented Thread Context Count, " + var3);
		}

		return var3;
	}

	private static synchronized int decrementThreadContextCount(Map var0) {
		String var1 = "decrementThreadContextCount";
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var1, "Decrementing thread Context Count");
		}

		Integer var2 = (Integer) var0.get("DOMAIN_CONTEXT_REF_COUNT");
		int var3 = var2;
		--var3;
		var2 = new Integer(var3);
		var0.put("DOMAIN_CONTEXT_REF_COUNT", var2);
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var1, "Returning Decremented Thread Context Count as " + var3);
		}

		return var3;
	}

	public static void cleanUpVMMThreadDomainContext() {
		String var0 = "cleanUpVMMThreadDomainContext";
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var0, "Starting cleaning up VMM context in thread");
		}

		int var1 = 0;
		if (vmmDomainMap.get() != null) {
			var1 = decrementThreadContextCount((Map) vmmDomainMap.get());
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var0, "Cleanup VMM context in thread="
						+ Thread.currentThread().getName() + " with context reference count=" + var1);
			}

			if (var1 > 0) {
				return;
			}
		}

		vmmDomainMap.remove();
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var0, "Cleaned VMM context from thread="
					+ Thread.currentThread().getName() + " with context reference count=" + var1);
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010;
		CLASSNAME = EMFDomainUtils.class.getName();
		vmmDomainMap = new ThreadLocal();
		debugEnabled = EPackageRegistryImpl.debugEnabled();
	}
}