package com.google.inject.internal;

public class AsynchronousComputationException extends ComputationException {
	public AsynchronousComputationException(Throwable cause) {
		super(cause);
	}
}