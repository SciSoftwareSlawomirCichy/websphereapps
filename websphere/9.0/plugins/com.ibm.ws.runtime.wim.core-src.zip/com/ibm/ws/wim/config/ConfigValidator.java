package com.ibm.ws.wim.config;

import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.cmdframework.AdminCommand;
import com.ibm.websphere.management.cmdframework.CommandMgr;
import com.ibm.websphere.management.cmdframework.CommandResult;
import com.ibm.websphere.management.cmdframework.CommandValidationException;
import com.ibm.websphere.management.configservice.ConfigDataId;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.management.configservice.ConfigServiceFactory;
import com.ibm.websphere.management.configservice.ConfigServiceHelper;
import com.ibm.websphere.management.exception.AdminException;
import com.ibm.websphere.management.exception.ConfigServiceException;
import com.ibm.websphere.management.exception.ConnectorException;
import com.ibm.websphere.management.exception.MetadataNotAvailableException;
import com.ibm.websphere.management.metadata.ManagedObjectMetadataAccessor;
import com.ibm.websphere.management.metadata.ManagedObjectMetadataAccessorFactory;
import com.ibm.websphere.management.metadata.ManagedObjectMetadataHelper;
import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InvalidPropertyValueException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.ws.management.util.Utils;
import com.ibm.ws.security.auth.SubjectHelper;
import com.ibm.ws.security.util.ConfigUtils;
import com.ibm.ws.wim.EnvironmentManager;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.ldap.KerberosService;
import com.ibm.ws.wim.adapter.ldap.LdapConnectionBase;
import com.ibm.ws.wim.config.ConfigValidator.1;
import com.ibm.ws.wim.config.ConfigValidator.InterOpFeatures;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.DataAccessObject;
import com.ibm.ws.wim.env.IEncryptionUtil;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.PasswordEncryptionUtil;
import com.sun.jndi.ldap.LdapName;
import commonj.sdo.Property;
import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.SecretKeyFactory;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.ObjectName;
import javax.management.QueryExp;
import javax.naming.AuthenticationException;
import javax.naming.InvalidNameException;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InvalidSearchFilterException;
import javax.naming.directory.SearchControls;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.security.auth.Subject;
import javax.security.sasl.SaslException;

public class ConfigValidator implements ConfigConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final String WIM_USER_REGISTRY = "WIMUserRegistry";
	private static final String WIM_CONFIG_VALIDATION = "wim.config.validation";
	protected static final String[] DB_CONNECTION_PARAMS;
	protected static final String[] LDAP_CONNECTION_PARAMS;

	public static void validateRepositoryParams(String var0, String var1, Map var2) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateRepositoryParams",
					"id=" + var0 + ", type=" + var1 + ", params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		if (validateConfig()) {
			if (!var0.contains("<") && !var0.contains("&") && !var0.contains(">") && !var0.contains("\"")
					&& !var0.contains("'")) {
				validateLoginProperties((List) var2.get("loginProperties"));
				String var4 = (String) var2.get("adapterClassName");
				if (var4 != null) {
					try {
						Class.forName(var4);
					} catch (ClassNotFoundException var9) {
						ClassLoader var6 = Thread.currentThread().getContextClassLoader();
						if (var6 == null) {
							var6 = ConfigValidator.class.getClassLoader();
						}

						try {
							Class.forName(var4, true, var6);
						} catch (ClassNotFoundException var8) {
							throw new WIMConfigurationException("MISSING_OR_INVALID_ADAPTER_CLASS_NAME",
									WIMMessageHelper.generateMsgParms(var4), CLASSNAME, "validateRepositoryParams",
									var9);
						}
					}
				}

				if (!"DatabaseRepositoryType".equals(var1) && !"propertyExtensionRepository".equals(var1)
						&& !"entryMappingRepository".equals(var1)) {
					if ("FileRepositoryType".equals(var1)) {
						validateFileParams(var0, var2);
					} else if ("LdapRepositoryType".equals(var1)) {
						validateLDAPParams(var0, var2);
					} else if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateRepositoryParams",
								"No Validation performed for repository type=" + var1);
					}
				} else {
					validateDBParams(var0, var2);
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "validateRepositoryParams");
				}

			} else {
				throw new WIMConfigurationException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateMsgParms(var0),
						CLASSNAME, "validateRepositoryParams");
			}
		}
	}

	public static void validateDBParams(String var0, Map var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateDBParams",
					"id=" + var0 + ", params=" + WIMTraceHelper.printMapWithoutPassword(var1));
		}

		if (validateConfig()) {
			boolean var3 = false;
			boolean var4 = false;
			String var5 = (String) var1.get("databaseType");
			validateSupportedDBType(var5);
			String var6 = (String) var1.get("dataSourceName");
			String var7 = (String) var1.get("dbURL");
			String var8 = (String) var1.get("dbAdminId");
			String var9 = (String) var1.get("dbAdminPassword");
			String var10 = (String) var1.get("JDBCDriverClass");
			String var11 = (String) var1.get("dbSchema");
			if (var5 != null && var6 != null && var7 != null) {
				try {
					if (var9 != null) {
						IEncryptionUtil var12 = FactoryManager.getEncryptionUtil();
						var9 = var12.decode(var9);
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateDBParams", "connecting to DB.");
					}

					DataAccessObject var17 = DAOHelper.getNewDAOClass(var5, var6, var7, var11, var8, var9, var10);
					if (var17.dsLookup() != null) {
						var3 = true;
						trcLogger.logp(Level.FINER, CLASSNAME, "validateDBParams", "the datasource was found: " + var6);
					} else {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateDBParams",
								"the datasource was NOT found: " + var6);
					}

					Connection var19 = var17.getDirectAccessConnection();
					trcLogger.logp(Level.FINER, CLASSNAME, "validateDBParams",
							"connected to DB using direct connection.");
					if (!"db2zos".equals(var5) && !"db2iseries".equals(var5)) {
						if (var11 != null && !var11.trim().equals("")) {
							var4 = var17.isValidSchema(var11);
						}
					} else {
						var4 = true;
					}

					try {
						var17.closeConnection(var19);
					} catch (Exception var15) {
						trcLogger.logp(Level.FINE, CLASSNAME, "validateDBParams",
								"Error closing the DB direct connection:" + var15.getMessage(), var15);
					}
				} catch (WIMException var16) {
					Object var13;
					for (var13 = var16; ((Throwable) var13).getCause() != null; var13 = ((Throwable) var13)
							.getCause()) {
						;
					}

					throw new WIMConfigurationException(
							"REPOSITORY_CONNECTION_FAILED", WIMMessageHelper.generateMsgParms(var7,
									WIMTraceHelper.printMapWithoutPassword(var1), var13.getClass().getName()),
							CLASSNAME, "validateDBParams", var16);
				}

				if (var11 != null && !var11.trim().equals("") && !var4) {
					throw new WIMConfigurationException("DBSCHEMA_NOT_AVAILABLE",
							WIMMessageHelper.generateMsgParms(var11), CLASSNAME, "validateDBParams");
				}

				if (!var3 && EnvironmentManager.singleton().isAminServiceAvailable()) {
					InvalidPropertyValueException var18 = new InvalidPropertyValueException("INVALID_PARAMETER_VALUE",
							WIMMessageHelper.generateMsgParms("dataSourceName"), Level.SEVERE, CLASSNAME,
							"validateDBParams");
					trcLogger.logp(Level.FINE, CLASSNAME, "validateDBParams", "DataSource is not found in server mode");
					throw new WIMConfigurationException(
							"REPOSITORY_CONNECTION_FAILED", WIMMessageHelper.generateMsgParms(var7,
									WIMTraceHelper.printMapWithoutPassword(var1), var18.getClass().getName()),
							CLASSNAME, "validateDBParams");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateDBParams");
			}

		}
	}

	public static void validateSupportedDBType(String var0) throws WIMConfigurationException {
		if (validateConfig()) {
			if (var0 != null) {
				ValidationHelper.validateParam("databaseType", var0, CONFIG_DB_SUPPORTED_TYPES);
			}

		}
	}

	public static void validateFileParams(String var0, Map var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateFileParams", "id=" + var0 + ", params=" + var1);
		}

		if (validateConfig()) {
			String var3 = (String) var1.get("messageDigestAlgorithm");
			if (var3 != null) {
				if (PasswordEncryptionUtil.isPbkdf2(var3)) {
					checkNodeVersions(InterOpFeatures.HASH);

					try {
						SecretKeyFactory.getInstance(var3);
					} catch (NoSuchAlgorithmException var6) {
						throw new WIMConfigurationException("CONFIG_VALUE_NOT_VALID",
								WIMMessageHelper.generateMsgParms(var3, "messageDigestAlgorithm",
										WIMTraceHelper.printObjectArray(
												PasswordEncryptionUtil.getSupportedHashingAlgorithms().toArray())),
								Level.SEVERE, CLASSNAME, "validateFileParams");
					}
				} else {
					try {
						MessageDigest.getInstance(var3);
					} catch (NoSuchAlgorithmException var5) {
						throw new WIMConfigurationException("CONFIG_VALUE_NOT_VALID",
								WIMMessageHelper.generateMsgParms(var3, "messageDigestAlgorithm",
										WIMTraceHelper.printObjectArray(
												PasswordEncryptionUtil.getSupportedHashingAlgorithms().toArray())),
								Level.SEVERE, CLASSNAME, "validateFileParams");
					}
				}
			}

			validateAccountLockoutParams(var0, var1);
			String var4 = (String) var1.get("baseDirectory");
			if (var4 != null && var4.trim().length() > 0 && !fileExists(var4)) {
				throw new WIMConfigurationException("DIRECTORY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var4),
						Level.SEVERE, CLASSNAME, "validateFileParams");
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "validateFileParams");
				}

			}
		}
	}

	public static void validateAccountLockoutParams(String var0, Map var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateAccountLockoutParams", "id=" + var0 + ", params=" + var1);
		}

		Integer var3 = (Integer) var1.get("accountLockoutThreshold");
		if (var3 != null && var3 > 0) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.finest("validateAccountLockoutParams: accountLockoutThreshold is set to " + var3);
			}

			Integer var4 = (Integer) var1.get("accountLockoutDuration");
			ValidationHelper.validateIntegerInput("accountLockoutDuration", CLASSNAME, "validateAccountLockoutParams",
					var4);
			Integer var5 = (Integer) var1.get("ignoreFailedLoginAfter");
			ValidationHelper.validateIntegerInput("ignoreFailedLoginAfter", CLASSNAME, "validateAccountLockoutParams",
					var5);
		} else if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.finest("validateAccountLockoutParams: accountLockoutThreshold is not configured");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "validateAccountLockoutParams");
		}

	}

	public static void validateLDAPParams(String var0, Map var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateLDAPParams",
					"id=" + var0 + ", params=" + WIMTraceHelper.printMapWithoutPassword(var1));
		}

		if (validateConfig()) {
			String var3 = (String) var1.get("ldapServerType");
			if (var3 != null) {
				if (var3.equals("IDS4") || var3.equals("IDS51") || var3.equals("IDS52") || var3.equals("IDS6")
						|| var3.equals("SECUREWAY")) {
					var3 = "IDS";
				}

				if (var3.equals("DOMINO5") || var3.equals("DOMINO6") || var3.equals("DOMINO65")) {
					var3 = "DOMINO";
				}

				if (var3.equals("AD2000") || var3.equals("AD2003")) {
					var3 = "AD";
				}
			}

			validateLDAPServerType(var3);
			if (var3 != null) {
				ValidationHelper.validateParam("ldapServerType", var3, CONFIG_LDAP_SUPPORTED_TYPES);
			}

			var1.put("ldapServerType", var3);
			String var4 = (String) var1.get("bindAuthMechanism");
			if (var4 != null) {
				validateBindAuthMechanism(var4);
			}

			if ("GSSAPI".equals(var4)) {
				checkNodeVersions(InterOpFeatures.GSSAPI);
				validateKrb5Principal(var0, var1);
				validateKerberosFiles(var0, var1);
			}

			InitialLdapContext var5 = null;
			String var6 = null;
			String var8;
			String var11;
			if (isParamSet(var1, LDAP_CONNECTION_PARAMS)) {
				Hashtable var7 = new Hashtable();
				var7.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
				var8 = (String) var1.get("host");
				if ((!var8.startsWith("[") || !var8.endsWith("]")) && ConfigUtils.isIPv6Addr(var8)) {
					var8 = ConfigUtils.formatIPv6Addr(var8);
					var1.put("host", var8);
				}

				Integer var9 = (Integer) var1.get("port");
				boolean var10 = false;
				if (var1.get("sslEnabled") != null) {
					var10 = (Boolean) var1.get("sslEnabled");
				}

				var11 = null;
				if (var10) {
					var11 = "ldaps://";
				} else {
					var11 = "ldap://";
				}

				if (var9 != null) {
					var6 = var11 + var8 + ":" + var9;
				} else {
					var6 = var11 + var8;
				}

				var7.put("java.naming.provider.url", var6);
				String var12;
				if (var10) {
					var12 = (String) var1.get("sslConfiguration");
					if (var12 != null) {
						trcLogger.logp(Level.FINE, CLASSNAME, "validateLDAPParams",
								"Use WAS SSL Configuration. sslAlias=" + var12);
						LdapConnectionBase.setWASSSLAlias(var12, var7);
						var7.put("java.naming.ldap.factory.socket", "com.ibm.websphere.ssl.protocol.SSLSocketFactory");
					}

					var7.put("java.naming.security.protocol", "ssl");
				}

				try {
					String var14;
					try {
						var12 = (String) var1.get("authentication");
						if (var4 != null && !var4.trim().isEmpty()) {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "validateLDAPParams",
										"Using bindAuthMechanism: " + var4);
							}

							var7.put("java.naming.security.authentication", var4);
						} else if (var12 != null) {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "validateLDAPParams",
										"Using authentication: " + var12);
							}

							var7.put("java.naming.security.authentication", var12);
						}

						String var26;
						if ("GSSAPI".equals(var7.get("java.naming.security.authentication"))) {
							var26 = (String) var1.get("krb5Principal");
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "validateLDAPParams",
										"Connecting with GSSAPI/Kerberos for " + var26);
							}

							KerberosService var29 = KerberosService.getInstance();
							Subject var15 = var29.createTempSubject(var26, (String) var1.get("krb5Config"),
									(String) var1.get("krb5TicketCache"), (String) var1.get("krb5Keytab"));
							var7.put("javax.security.sasl.credentials",
									SubjectHelper.getGSSCredentialFromSubject(var15));
						} else {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "validateLDAPParams",
										"Connecting with " + var7.get("java.naming.security.authentication"));
							}

							var26 = (String) var1.get("bindDN");
							if (var26 != null && var26.trim().length() > 0) {
								var7.put("java.naming.security.principal", var26);
								var14 = (String) var1.get("bindPassword");
								if (var14 != null) {
									if (var14 != null) {
										IEncryptionUtil var28 = FactoryManager.getEncryptionUtil();
										var14 = var28.decode(var14);
									}

									var7.put("java.naming.security.credentials",
											PasswordUtil.getByteArrayPassword(var14));
								}
							}
						}

						int var27 = 20;
						if (var1.get("connectTimeout") != null) {
							int var30 = (Integer) var1.get("connectTimeout");
							if (var30 > 0) {
								var27 = var30;
							}
						}

						var7.put("com.sun.jndi.ldap.connect.timeout", Integer.toString(var27 * 1000));
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "validateLDAPParams",
									"connecting to LDAP with:" + var7);
						}

						var5 = new InitialLdapContext(var7, (Control[]) null);
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "validateLDAPParams", "connected to LDAP.");
						}
					} catch (Exception var21) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME, "validateLDAPParams",
									"Authentication failure using the following environment: " + var7, var21);
						}

						Object var13 = var21;

						for (var14 = null; ((Throwable) var13).getCause() != null; var13 = ((Throwable) var13)
								.getCause()) {
							if (var13 instanceof SaslException) {
								var14 = ((SaslException) var13).toString();
								break;
							}
						}

						if (var14 == null) {
							var14 = var13.getClass().getName() + (((Throwable) var13).getMessage() != null
									? ": " + ((Throwable) var13).getMessage()
									: "");
						}

						if (var21 instanceof AuthenticationException) {
							throw new WIMConfigurationException("REPOSITORY_CONNECTION_FAILED",
									WIMMessageHelper.generateMsgParms(var6,
											WIMTraceHelper.printMapWithoutPassword(var1), var14),
									CLASSNAME, "validateLDAPParams");
						}

						throw new WIMConfigurationException(
								"REPOSITORY_CONNECTION_FAILED", WIMMessageHelper.generateMsgParms(var6,
										WIMTraceHelper.printMapWithoutPassword(var1), var14),
								CLASSNAME, "validateLDAPParams", var21);
					}
				} finally {
					LdapConnectionBase.resetWASSSLAlias();
				}
			}

			List var23 = (List) var1.get("searchBases");
			validateSearchBases(var5, var0, var6, var23);
			var8 = (String) var1.get("searchFilter");
			validateSearchFilter(var5, var0, var6, var8);
			List var24 = (List) var1.get("objectClasses");
			validateObjectClasses(var5, var0, var6, var24);
			List var25 = (List) var1.get("nameInRepository");
			validateBaseEntryNameInRepository(var5, var0, var6, var25);
			var11 = (String) var1.get("supportChangeLog");
			validateSupportChangeLogParameter(var11);

			try {
				if (var5 != null) {
					var5.close();
				}
			} catch (Exception var20) {
				trcLogger.logp(Level.FINE, CLASSNAME, "validateLDAPParams",
						"Error closing the LDAP connection:" + var20.getMessage(), var20);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateLDAPParams");
			}

		}
	}

	public static void validateLDAPServerType(String var0) throws WIMConfigurationException {
		if (validateConfig()) {
			if (var0 != null) {
				ValidationHelper.validateParam("ldapServerType", var0, CONFIG_LDAP_SUPPORTED_TYPES);
			}

		}
	}

	public static void validateLoginProperties(List var0) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateLoginProperties", "loginProps=" + var0);
		}

		if (validateConfig()) {
			if (var0 != null && var0.size() > 0) {
				SchemaManager var2 = null;

				try {
					var2 = SchemaManager.singleton();
				} catch (WIMException var11) {
					throw new WIMConfigurationException(var11.getMessageKey(), var11.getMessageParams(), CLASSNAME,
							"validateLoginProperties");
				}

				Set var3 = var2.getSubEntityTypes("LoginAccount");
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "validateLoginProperties", "LoginAccount subtypes: " + var3);
				}

				boolean var4 = false;
				Iterator var5 = var3.iterator();

				while (var5.hasNext()) {
					String var6 = (String) var5.next();
					List var7 = var2.getProperties(var6);
					ArrayList var8 = new ArrayList();

					for (int var9 = 0; var9 < var7.size(); ++var9) {
						var8.add(((Property) var7.get(var9)).getName());
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateLoginProperties",
								"props of " + var6 + ":" + var8);
					}

					if (var8.contains("ibmPrimaryEmail")) {
						var8.add("ibm-primaryEmail");
					} else if (var8.contains("ibmJobTitle")) {
						var8.add("ibm-jobTitle");
					}

					boolean var12 = true;

					for (int var10 = 0; var10 < var0.size(); ++var10) {
						if (!var8.contains(var0.get(var10))) {
							var12 = false;
							break;
						}
					}

					if (var12) {
						var4 = true;
						break;
					}
				}

				if (!var4) {
					throw new WIMConfigurationException("INVALID_LOGIN_PROPERTIES",
							WIMMessageHelper.generateMsgParms(var0.toString()), CLASSNAME, "validateLoginProperties");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateLoginProperties");
			}

		}
	}

	public static void validateDeleteIdMgrRealm(ConfigurationProviderType var0, String var1) throws WIMException {
		String var2 = "validateDeleteIdMgrRealm";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2, "realmName=" + var1);
		}

		if (validateConfig()) {
			RealmConfigurationType var3 = getRealmConfig(var0);
			String var4 = var3.getDefaultRealm();
			if (var1.equals(var4)) {
				throw new WIMConfigurationException("CANNOT_DELETE_DEFAULT_REALM",
						WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, CLASSNAME, var2);
			} else {
				com.ibm.ws.wim.config.ConfigUtils.getRealm(var1, var3);
				List var5 = var3.getRealms();
				if (var5.size() == 1) {
					throw new WIMConfigurationException("CANNOT_DELETE_ONLY_REALM",
							WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, CLASSNAME, var2);
				} else {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, var2);
					}

				}
			}
		}
	}

	public static void validateAddIdMgrRealmBaseEntry(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		String var3 = "validateAddIdMgrRealmBaseEntry";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "realmName=" + var1 + ", baseEntryName=" + var2);
		}

		if (validateConfig()) {
			if (!isDN(var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_MUST_BE_DN", WIMMessageHelper.generateMsgParms(var2),
						Level.SEVERE, CLASSNAME, var3);
			} else if (!isBaseEntryInRepository(var0, var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_CANNOT_BE_ADDED_TO_REALM",
						WIMMessageHelper.generateMsgParms(var2, var1), Level.SEVERE, CLASSNAME, var3);
			} else {
				List var4 = com.ibm.ws.wim.config.ConfigUtils.getProfileRepositories(var0);
				Iterator var5 = var4.iterator();

				while (true) {
					while (var5.hasNext()) {
						ProfileRepositoryType var6 = (ProfileRepositoryType) var5.next();
						String var12;
						if (var6 instanceof FileRepositoryType) {
							FileRepositoryType var11 = (FileRepositoryType) var6;
							var12 = var11.getMessageDigestAlgorithm();
							if (PasswordEncryptionUtil.isPbkdf2(var12)) {
								checkNodeVersions(InterOpFeatures.HASH);
							}
						} else if (var6 instanceof DatabaseRepositoryType) {
							DatabaseRepositoryType var10 = (DatabaseRepositoryType) var6;
							var12 = var10.getHashAlgorithm();
							if (var12 != null) {
								checkNodeVersions(InterOpFeatures.HASH);
							}
						} else if (var6 instanceof LdapRepositoryType) {
							LdapRepositoryType var7 = (LdapRepositoryType) var6;
							Iterator var8 = var7.getLdapServerConfiguration().getLdapServers().iterator();

							while (var8.hasNext()) {
								LdapServersType var9 = (LdapServersType) var8.next();
								if ("GSSAPI".equals(var9.getBindAuthMechanism())) {
									checkNodeVersions(InterOpFeatures.GSSAPI);
								}
							}
						}
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, var3);
					}

					return;
				}
			}
		}
	}

	public static void validateDeleteIdMgrRealmBaseEntry(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		String var3 = "validateDeleteIdMgrRealmBaseEntry";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "realmName=" + var1 + ", baseEntryName=" + var2);
		}

		if (validateConfig()) {
			RealmConfigurationType var4 = getRealmConfig(var0);
			String var5 = var4.getDefaultRealm();
			if (var1.equals(var5) && isLastBaseEntryInRealm(var0, var1, var2)) {
				throw new WIMConfigurationException("CANNOT_DELETE_ONLY_BASE_ENTRY_IN_REALM",
						WIMMessageHelper.generateMsgParms(var2, var1), Level.SEVERE, CLASSNAME, var3);
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, var3);
				}

			}
		}
	}

	public static void validateAddIdMgrRepositoryBaseEntry(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		String var3 = "validateAddIdMgrRepositoryBaseEntry";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "repoId=" + var1 + ", baseEntryName=" + var2);
		}

		if (validateConfig()) {
			if (!isDN(var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_MUST_BE_DN", WIMMessageHelper.generateMsgParms(var2),
						Level.SEVERE, CLASSNAME, var3);
			} else if (isBaseEntryInRepository(var0, var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_ALREADY_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var2, var1), Level.SEVERE, CLASSNAME, var3);
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, var3);
				}

			}
		}
	}

	public static void validateDeleteIdMgrRepositoryBaseEntry(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		String var3 = "validateDeleteIdMgrRepositoryBaseEntry";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "repoId=" + var1 + ", baseEntryName=" + var2);
		}

		if (validateConfig()) {
			if (isLastBaseEntryInRepository(var0, var1, var2)) {
				throw new WIMConfigurationException("CANNOT_DELETE_ONLY_BASE_ENTRY_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var2, var1), Level.SEVERE, CLASSNAME, var3);
			} else if (isBaseEntryInRealms(var0, var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_STILL_REFERENCED_BY_REALM",
						WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, var3);
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, var3);
				}

			}
		}
	}

	public static void validateDeleteIdMgrRepository(ConfigurationProviderType var0, String var1) throws WIMException {
		String var2 = "validateDeleteIdMgrRepository";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2, "repoId=" + var1);
		}

		if (validateConfig()) {
			ProfileRepositoryType var3 = (ProfileRepositoryType) com.ibm.ws.wim.config.ConfigUtils
					.getRepositoryById(var0, var1);
			List var4 = var3.getBaseEntries();

			for (int var5 = 0; var5 < var4.size(); ++var5) {
				BaseEntriesType var6 = (BaseEntriesType) var4.get(var5);
				String var7 = var6.getName();
				if (isBaseEntryInRealms(var0, var7)) {
					throw new WIMConfigurationException("DELETE_REPOSITORY_PREREQUISITE_ERROR",
							WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, CLASSNAME, var2);
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, var2);
			}

		}
	}

	public static void validateRepositoriesForGroup(ConfigurationProviderType var0, List var1) throws WIMException {
		String var2 = "validateRepositoriesForGroup";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2, "reposForGroups=" + var1);
		}

		if (var1 != null && var1.size() > 0) {
			List var3 = com.ibm.ws.wim.config.ConfigUtils.getProfileRepositories(var0);
			ArrayList var4 = new ArrayList();

			int var5;
			for (var5 = 0; var5 < var3.size(); ++var5) {
				var4.add(((RepositoryType) var3.get(var5)).getId());
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, var2, "currentRepoIds=" + var4);
			}

			for (var5 = 0; var5 < var1.size(); ++var5) {
				String var6 = (String) var1.get(var5);
				if (!var4.contains(var6)) {
					throw new WIMConfigurationException("INVALID_REPOSITORY_FOR_GROUPS",
							WIMMessageHelper.generateMsgParms(var6), Level.SEVERE, CLASSNAME, var2);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var2);
		}

	}

	private static boolean isParamSet(Map var0, String[] var1) {
		boolean var2 = false;

		for (int var3 = 0; var3 < var1.length; ++var3) {
			if (var0.containsKey(var1[var3])) {
				var2 = true;
				break;
			}
		}

		return var2;
	}

	private static boolean validateConfig() {
		boolean var0 = true;
		String var1 = System.getProperty("wim.config.validation");
		if (var1 != null) {
			var0 = Boolean.getBoolean(var1);
			if (!var0) {
				trcLogger.log(Level.FINER, "wim.config.validation=" + var1);
				trcLogger.log(Level.FINER,
						"Virtual member manager CONFIG VALIDATION IS TURNED OFF. **** DO NOT TURN IT OFF ****");
			}
		}

		return var0;
	}

	public static void validateSupportChangeLogParameter(String var0) throws WIMConfigurationException {
		if (var0 != null && !"native".equalsIgnoreCase(var0) && !"none".equalsIgnoreCase(var0)) {
			throw new WIMConfigurationException("INVALID_SUPPORT_CHANGE_LOG", WIMMessageHelper.generateMsgParms(var0),
					CLASSNAME, "validateSupportChangeLogParameter");
		}
	}

	private static void validateSearchFilter(DirContext var0, String var1, String var2, String var3)
			throws WIMConfigurationException {
		if (var3 != null && var3.trim().length() > 0) {
			if (var0 == null) {
				throw new WIMConfigurationException("MISSING_OR_INVALID_CONNECTION_DATA",
						WIMMessageHelper.generateMsgParms(var2 == null ? var1 : var2), CLASSNAME,
						"validateSearchFilter");
			}

			try {
				SearchControls var5 = new SearchControls();
				var5.setSearchScope(0);
				var0.search("", var3, var5);
			} catch (InvalidSearchFilterException var6) {
				throw new WIMConfigurationException("INVALID_SEARCH_FILTER", WIMMessageHelper.generateMsgParms(var3),
						CLASSNAME, "validateSearchFilter", var6);
			} catch (NamingException var7) {
				trcLogger.logp(Level.FINE, CLASSNAME, "validateSearchFilter", "invalid search filter: " + var3, var7);
			}
		}

	}

	private static void validateSearchBases(DirContext var0, String var1, String var2, List var3)
			throws WIMConfigurationException {
		Object var5 = null;
		if (var3 != null && var3.size() > 0) {
			if (var0 == null) {
				throw new WIMConfigurationException("MISSING_OR_INVALID_CONNECTION_DATA",
						WIMMessageHelper.generateMsgParms(var2 == null ? var1 : var2), CLASSNAME,
						"validateSearchBases");
			}

			try {
				SearchControls var6 = new SearchControls();
				var6.setSearchScope(0);

				for (int var10 = 0; var10 < var3.size(); ++var10) {
					var0.search(new LdapName((String) var3.get(var10)), "(objectclass=*)", var6);
				}
			} catch (InvalidNameException var8) {
				throw new WIMConfigurationException("INVALID_SEARCH_BASE", WIMMessageHelper.generateMsgParms(var3),
						CLASSNAME, "validateSearchBases", var8);
			} catch (NamingException var9) {
				trcLogger.logp(Level.FINE, CLASSNAME, "validateSearchBases", "invalid searchBases: " + var3, var9);
				String var7 = var9.getMessage();
				if (var7 != null && var7.contains("[LDAP: error code 32 - No Such Object]")) {
					throw new WIMConfigurationException("INVALID_SEARCH_BASE", WIMMessageHelper.generateMsgParms(var3),
							CLASSNAME, "validateSearchBases");
				}
			}
		}

	}

	private static void validateObjectClasses(DirContext var0, String var1, String var2, List var3)
			throws WIMConfigurationException {
		if (var3 != null && var3.size() > 0) {
			if (var0 == null) {
				throw new WIMConfigurationException("MISSING_OR_INVALID_CONNECTION_DATA",
						WIMMessageHelper.generateMsgParms(var2 == null ? var1 : var2), CLASSNAME,
						"validateObjectClasses");
			}

			String var5 = null;

			try {
				DirContext var6 = var0.getSchema("");
				trcLogger.logp(Level.FINER, CLASSNAME, "validateObjectClasses", "getSchema=" + var6);

				for (int var7 = 0; var7 < var3.size(); ++var7) {
					var5 = (String) var3.get(var7);
					String var8 = "ClassDefinition/" + var5;
					trcLogger.logp(Level.FINER, CLASSNAME, "validateObjectClasses", "checking object class=" + var8);
					var6.getAttributes(var8);
				}
			} catch (NamingException var9) {
				if (var5 != null) {
					throw new WIMConfigurationException("INVALID_OBJECT_CLASSES",
							WIMMessageHelper.generateMsgParms(var5), CLASSNAME, "validateObjectClasses", var9);
				}

				throw new WIMConfigurationException("INVALID_OBJECT_CLASSES", WIMMessageHelper.generateMsgParms(var3),
						CLASSNAME, "validateObjectClasses", var9);
			}
		}

	}

	private static void validateBaseEntryNameInRepository(DirContext var0, String var1, String var2, List var3)
			throws WIMConfigurationException {
		if (var3 != null && var3.size() > 0) {
			if (var0 == null) {
				throw new WIMConfigurationException("MISSING_OR_INVALID_CONNECTION_DATA",
						WIMMessageHelper.generateMsgParms(var2 == null ? var1 : var2), CLASSNAME,
						"validateBaseEntryNameInRepository");
			}

			String var5 = null;

			try {
				SearchControls var6 = new SearchControls();
				var6.setSearchScope(0);

				for (int var7 = 0; var7 < var3.size(); ++var7) {
					var5 = (String) var3.get(var7);
					trcLogger.logp(Level.FINER, CLASSNAME, "validateBaseEntryNameInRepository",
							"validating nameInRepository " + var5);
					var0.search(new LdapName(var5), "(objectclass=*)", var6);
				}
			} catch (NamingException var8) {
				if (var5 != null) {
					throw new WIMConfigurationException("INVALID_BASE_ENTRY_NAME_IN_REPOSITORY",
							WIMMessageHelper.generateMsgParms(var5, var8.getMessage()), CLASSNAME,
							"validateBaseEntryNameInRepository", var8);
				}

				throw new WIMConfigurationException("INVALID_BASE_ENTRY_NAME_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var3, var8.getMessage()), CLASSNAME,
						"validateBaseEntryNameInRepository", var8);
			}
		}

	}

	private static boolean isStringEqual(String var0, String var1) {
		boolean var2 = false;
		if (var0 == null && var1 == null) {
			var2 = true;
		} else if (var0 != null && var1 != null) {
			var2 = var0.equalsIgnoreCase(var1);
		}

		return var2;
	}

	private static boolean isLastBaseEntryInRepository(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		boolean var3 = false;
		ProfileRepositoryType var4 = (ProfileRepositoryType) com.ibm.ws.wim.config.ConfigUtils.getRepositoryById(var0,
				var1);
		List var5 = var4.getBaseEntries();
		if (var5.size() == 1 && isStringEqual(var2, ((BaseEntriesType) var5.get(0)).getName())) {
			var3 = true;
		}

		return var3;
	}

	private static boolean isLastBaseEntryInRealm(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		boolean var3 = false;
		RealmConfigurationType var4 = getRealmConfig(var0);
		RealmType var5 = com.ibm.ws.wim.config.ConfigUtils.getRealm(var1, var4);
		List var6 = var5.getParticipatingBaseEntries();
		if (var6.size() == 1 && isStringEqual(var2, ((ParticipatingBaseEntriesType) var6.get(0)).getName())) {
			var3 = true;
		}

		return var3;
	}

	private static boolean isBaseEntryInRealms(ConfigurationProviderType var0, String var1) throws WIMException {
		boolean var2 = false;
		RealmConfigurationType var3 = getRealmConfig(var0);
		List var4 = var3.getRealms();

		for (int var5 = 0; var5 < var4.size(); ++var5) {
			RealmType var6 = (RealmType) var4.get(var5);
			List var7 = var6.getParticipatingBaseEntries();

			for (int var8 = 0; var8 < var7.size(); ++var8) {
				ParticipatingBaseEntriesType var9 = (ParticipatingBaseEntriesType) var7.get(var8);
				if (isStringEqual(var1, var9.getName())) {
					var2 = true;
					break;
				}
			}

			if (var2) {
				break;
			}
		}

		return var2;
	}

	public static boolean isBaseEntryInRepository(ConfigurationProviderType var0, String var1) throws WIMException {
		boolean var2 = false;
		List var3 = com.ibm.ws.wim.config.ConfigUtils.getProfileRepositories(var0);

		for (int var4 = 0; var4 < var3.size(); ++var4) {
			ProfileRepositoryType var5 = (ProfileRepositoryType) var3.get(var4);
			List var6 = var5.getBaseEntries();

			for (int var7 = 0; var7 < var6.size(); ++var7) {
				BaseEntriesType var8 = (BaseEntriesType) var6.get(var7);
				if (isStringEqual(var1, var8.getName())) {
					var2 = true;
					break;
				}
			}
		}

		return var2;
	}

	private static boolean isDN(String var0) {
		boolean var1 = false;

		try {
			if (var0 != null && !var0.startsWith(",") && !var0.endsWith(",")) {
				new LdapName(var0);
				var1 = true;
			}
		} catch (InvalidNameException var3) {
			trcLogger.logp(Level.FINER, CLASSNAME, "isDN", "not a DN:" + var0, var3);
		}

		return var1;
	}

	public static RealmConfigurationType getRealmConfig(ConfigurationProviderType var0) throws WIMException {
		String var1 = "getRealmConfig";
		RealmConfigurationType var2 = var0.getRealmConfiguration();
		if (var2 == null) {
			throw new WIMConfigurationException("MISSING_REALM_CONFIGURATION", Level.SEVERE, CLASSNAME, var1);
		} else {
			return var2;
		}
	}

	public static boolean fileExists(String var0) {
		try {
			if (var0 != null) {
				File var1 = new File(var0);
				if (var1.exists()) {
					return true;
				}
			}
		} catch (Exception var2) {
			trcLogger.logp(Level.FINER, CLASSNAME, "fileExists", "checking for file: " + var0, var2);
		}

		return false;
	}

	public static void checkNodeVersionsForHashing() throws WIMConfigurationException {
		checkNodeVersions(InterOpFeatures.HASH);
	}

	public static void checkNodeVersions(InterOpFeatures var0) throws WIMConfigurationException {
      if (trcLogger.isLoggable(Level.FINER)) {
         trcLogger.entering(CLASSNAME, "checkNodeVersions()", var0);
      }

      Session var2 = new Session();
      ConfigService var3 = ConfigServiceFactory.getConfigService();

      try {
         Set var4 = getNodesInCell(var3, var2);
         if (var4 != null && !var4.isEmpty()) {
            ArrayList var5 = new ArrayList();
            Iterator var6 = var4.iterator();

            while(var6.hasNext()) {
               String var7 = (String)var6.next();
               if (var7 != null && compareNodeVersion(var2, var7, var0) < 0) {
                  var5.add(var7);
               }
            }

            if (!var5.isEmpty()) {
               switch(1.$SwitchMap$com$ibm$ws$wim$config$ConfigValidator$InterOpFeatures[var0.ordinal()]) {
               case 1:
                  throw new WIMConfigurationException("UNSUPPORTED_HASHING_ALGORITHM_ON_NODES", new Object[]{var5});
               case 2:
                  throw new WIMConfigurationException("UNSUPPORTED_AUTH_MECH_ON_NODES", new Object[]{"GSSAPI (Kerberos)", var5});
               }
            }
         }
      } finally {
         try {
            var3.discard(var2);
         } catch (ConnectorException var15) {
            trcLogger.finest("checkNodeVersions(): Ignoring: " + var15.getMessage());
         } catch (ConfigServiceException var16) {
            trcLogger.finest("checkNodeVersions(): Ignoring: " + var16.getMessage());
         }

      }

      if (trcLogger.isLoggable(Level.FINER)) {
         trcLogger.exiting(CLASSNAME, "checkNodeVersions()");
      }

   }

	private static Set<String> getNodesInCell(ConfigService var0, Session var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getNodesInCell(ConfigService,Session)",
					new Object[]{var0, var1.getSessionId()});
		}

		HashSet var3 = null;

		try {
			ObjectName var4 = ConfigServiceHelper.createObjectName((ConfigDataId) null, "Node");
			ObjectName[] var5 = var0.queryConfigObjects(var1, (ObjectName) null, var4, (QueryExp) null);
			if (var5 != null && var5.length > 0) {
				var3 = new HashSet();
				ObjectName[] var6 = var5;
				int var7 = var5.length;

				for (int var8 = 0; var8 < var7; ++var8) {
					ObjectName var9 = var6[var8];
					var3.add(ConfigServiceHelper.getDisplayName(var9));
				}
			}
		} catch (AdminException var10) {
			throw new WIMConfigurationException("Error querying for nodes in cell.", var10);
		} catch (ConnectorException var11) {
			throw new WIMConfigurationException("Error querying for nodes in cell.", var11);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getNodesInCell(ConfigService,Session)", var3);
		}

		return var3;
	}

	private static int compareNodeVersion(Session var0, String var1) throws WIMConfigurationException {
		return compareNodeVersion(var0, var1, InterOpFeatures.HASH);
	}

	private static int compareNodeVersion(Session var0, String var1, InterOpFeatures var2)
			throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "compareNodeVersion(Session,String)",
					new Object[]{var0.getSessionId(), var1});
		}

		int var4 = 0;

		try {
			Properties var5 = new Properties();
			var5.setProperty("CONFIG_SESSION", var0.getSessionId());
			ManagedObjectMetadataAccessor var6 = ManagedObjectMetadataAccessorFactory.createAccessor(var5);
			ManagedObjectMetadataHelper var7 = new ManagedObjectMetadataHelper(var6);
			boolean var8 = false;

			try {
				var7.getNodeDeployedFeatures(var1);
			} catch (MetadataNotAvailableException var11) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.finest("compareNodeVersion(Session,String): Skipping check for node '" + var1
							+ "' as there are no deployed features. Possibly remote HTTP server (IHS, Apache, etc)?");
				}

				var8 = true;
			}

			if (!var8) {
				String var9 = var7.getNodeBaseProductVersion(var1);
				String var10 = getVersionToCompare(var9, var2);
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.finest("compareNodeVersion(Session,String): Node product version is: " + var9
							+ ", comparing against: " + var10);
				}

				var4 = Utils.compareVersions(var9, var10);
			}
		} catch (AdminException var12) {
			throw new WIMConfigurationException("Could not retrieve version for node '" + var1 + "'.", var12);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "compareNodeVersion(Session,String)", var4);
		}

		return var4;
	}

	public static String getVersionToCompare(String var0) {
		return getVersionToCompare(var0, InterOpFeatures.HASH);
	}

	public static String getVersionToCompare(String var0, InterOpFeatures var1) {
      if (trcLogger.isLoggable(Level.FINER)) {
         trcLogger.entering(CLASSNAME, "getVersionToCompare()");
      }

      String var3 = null;
      switch(1.$SwitchMap$com$ibm$ws$wim$config$ConfigValidator$InterOpFeatures[var1.ordinal()]) {
      case 1:
         if (var0.startsWith("8.5")) {
            var3 = "8.5.5.17";
         } else {
            var3 = "9.0.5.1";
         }
         break;
      case 2:
         if (var0.startsWith("8.5")) {
            var3 = "8.5.5.19";
         } else {
            var3 = "9.0.5.7";
         }
      }

      if (trcLogger.isLoggable(Level.FINER)) {
         trcLogger.exiting(CLASSNAME, "getVersionToCompare()", var3);
      }

      return var3;
   }

	public static List<String> checkWIMUserRegistryForPBKDF2(String var0) throws Exception {
		return checkWIMUserRegistryForFeature(var0, InterOpFeatures.HASH);
	}

	public static List<String> checkWIMUserRegistryForFeature(String var0, InterOpFeatures var1) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "checkWIMUserRegistryForPBKDF2(String)", new Object[]{var0, var1});
		}

		ArrayList var3 = new ArrayList();
		if (getUserRegistryInfo(var0, "WIMUserRegistry") != null) {
			if (!var0.trim().isEmpty()) {
				DomainManagerUtils.setVMMThreadDomainContextForCLI(var0);
			}

			Session var4 = new Session();

			try {
				Iterator var5 = com.ibm.ws.wim.config.ConfigUtils.getProfileRepositories(var4.getSessionId())
						.iterator();

				label153 : while (true) {
					while (true) {
						if (!var5.hasNext()) {
							break label153;
						}

						RepositoryType var6 = (RepositoryType) var5.next();
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.finest("checkWIMUserRegistryForPBKDF2(String): Found repository '" + var6.getId()
									+ "' in security domain '" + var0 + "'.");
						}

						String var15;
						if (var6 instanceof FileRepositoryType && var1 == InterOpFeatures.HASH) {
							FileRepositoryType var14 = (FileRepositoryType) var6;
							var15 = var14.getMessageDigestAlgorithm();
							if (PasswordEncryptionUtil.isPbkdf2(var15)) {
								var3.add(var14.getId());
							}
						} else if (var6 instanceof DatabaseRepositoryType && var1 == InterOpFeatures.HASH) {
							DatabaseRepositoryType var13 = (DatabaseRepositoryType) var6;
							var15 = var13.getHashAlgorithm();
							if (var15 != null) {
								var3.add(var13.getId());
							}
						} else if (var6 instanceof LdapRepositoryType && var1 == InterOpFeatures.GSSAPI) {
							LdapRepositoryType var7 = (LdapRepositoryType) var6;
							Iterator var8 = var7.getLdapServerConfiguration().getLdapServers().iterator();

							while (var8.hasNext()) {
								LdapServersType var9 = (LdapServersType) var8.next();
								if ("GSSAPI".equals(var9.getBindAuthMechanism())) {
									var3.add(var7.getId());
								}
							}
						}
					}
				}
			} finally {
				if (!var0.trim().isEmpty()) {
					DomainManagerUtils.cleanUpVMMThreadDomainContext();
				}

				ConfigServiceFactory.getConfigService().discard(var4);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "checkWIMUserRegistryForPBKDF2(String)", var3);
		}

		return var3;
	}

	private static Map<String, Object> getUserRegistryInfo(String var0, String var1) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getUserRegistryInfo(String,String)", new Object[]{var0, var1});
		}

		HashMap var3 = null;
		CommandMgr var4 = CommandMgr.getCommandMgr();
		if (var4 != null) {
			AdminCommand var5 = var4.createCommand("getUserRegistryInfo");
			if (var0 != null && !var0.trim().isEmpty()) {
				var5.setParameter("securityDomainName", var0);
			}

			if (var1 != null && !var1.trim().isEmpty()) {
				var5.setParameter("userRegistryType", var1);
			}

			ConfigService var6 = ConfigServiceFactory.getConfigService();
			Session var7 = new Session();

			try {
				var5.setConfigSession(var7);
				var5.execute();
				CommandResult var8 = var5.getCommandResult();
				if (!var8.isSuccessful()) {
					Throwable var22 = var8.getException();
					if (var22 instanceof Exception) {
						throw (Exception) var22;
					}

					throw new Exception(var22.getMessage(), var22);
				}

				AttributeList var9 = (AttributeList) var8.getResult();
				var3 = new HashMap();
				Iterator var10 = var9.asList().iterator();

				while (var10.hasNext()) {
					Attribute var11 = (Attribute) var10.next();
					var3.put(var11.getName(), var11.getValue());
				}
			} catch (CommandValidationException var20) {
				;
			} finally {
				try {
					var6.discard(var7);
				} catch (Exception var19) {
					trcLogger.finest("getUserRegistryInfo(String,String): Ignoring: " + var19.getMessage());
				}

			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getUserRegistryInfo(String,String)", var3);
		}

		return var3;
	}

	private static void validateBindAuthMechanism(String var0) throws WIMConfigurationException {
		if (validateConfig()) {
			if (var0 != null && !var0.trim().isEmpty()) {
				ValidationHelper.validateParam("bindAuthMechanism", var0, CONFIG_BIND_AUTH_TYPES);
			}

		}
	}

	private static void validateKerberosFiles(String var0, Map var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateKerberosFiles", "id=" + var0 + ", params=" + var1);
		}

		if (validateConfig()) {
			String var3 = (String) var1.get("krb5TicketCache");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "validateKerberosFiles", "Checking krb5TicketCache: " + var3);
			}

			validateKerberosFileExistsAndReadable(var0, var3);
			String var4 = (String) var1.get("krb5Config");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "validateKerberosFiles", "Checking krb5Config: " + var4);
			}

			validateKerberosFileExistsAndReadable(var0, var4);
			String var5 = (String) var1.get("krb5Keytab");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "validateKerberosFiles", "Checking krb5Keytab: " + var5);
			}

			validateKerberosFileExistsAndReadable(var0, var5);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateKerberosFiles");
			}

		}
	}

	private static void validateKerberosFileExistsAndReadable(String var0, String var1)
			throws WIMConfigurationException {
		String var3 = ConfigUtils.expandString(var1);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateKerberosFileExistsAndReadable",
					"incoming name: " + var1 + ", expanded: " + var3);
		}

		if (var3 != null && !var3.trim().isEmpty()) {
			File var4 = new File(var3);
			if (!var4.exists()) {
				throw new WIMConfigurationException("FILE_NOT_FOUND", WIMMessageHelper.generateMsgParms(var3),
						Level.SEVERE, CLASSNAME, "validateKerberosFileExistsAndReadable");
			}

			if (!var4.canRead()) {
				throw new WIMConfigurationException("CANNOT_READ_KRB5_FILE",
						WIMMessageHelper.generateMsgParms(var0, var3), Level.SEVERE, CLASSNAME,
						"validateKerberosFileExistsAndReadable");
			}
		}

	}

	private static void validateKrb5Principal(String var0, Map var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateKrb5Principal", "id=" + var0 + ", params=" + var1);
		}

		if (validateConfig()) {
			String var3 = (String) var1.get("krb5Principal");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "validateKrb5Principal",
						"Checking krb5Principal: [" + var3 + "]");
			}

			if (var3 != null && !var3.trim().isEmpty()) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "validateKrb5Principal");
				}

			} else {
				throw new WIMConfigurationException("MISSING_MANDATORY_PROPERTY",
						WIMMessageHelper.generateMsgParms("krb5Principal"), Level.SEVERE, CLASSNAME,
						"validateKrb5Principal");
			}
		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = ConfigValidator.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		DB_CONNECTION_PARAMS = new String[]{"dataSourceName", "databaseType", "dbURL", "dbAdminId", "dbAdminPassword",
				"JDBCDriverClass", "dbSchema"};
		LDAP_CONNECTION_PARAMS = new String[]{"host", "port", "bindDN", "bindPassword", "authentication", "sslEnabled",
				"bindAuthMechanism", "krb5Principal", "krb5TicketCache", "krb5Config", "krb5Keytab"};
	}
}