package com.google.inject.internal.cglib.proxy;

public interface Dispatcher extends Callback {
	Object loadObject() throws Exception;
}