package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_zh_TW extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: 偵測到已安裝的應用程式伺服器用戶端元件，其建置層次不一致。用戶端元件 {0} 的安裝建置層次是 {1}，不同於用戶端元件 {2} 的安裝建置層次 {3}。"},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E", "CWSJE0002E: 已安裝的應用程式伺服器用戶端元件的建置層次不一致，造成無法進一步執行。"},
			{"EXCP_CWSJE0003E", "CWSJE0003E: 無法存取 {1} 資源，因為異常狀況：{0}"}};

	public Object[][] getContents() {
		return resources;
	}
}