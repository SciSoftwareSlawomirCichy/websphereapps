package com.google.common.io;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.io.BaseEncoding.1;
import com.google.common.io.BaseEncoding.2;
import com.google.common.io.BaseEncoding.3;
import com.google.common.io.BaseEncoding.4;
import com.google.common.io.BaseEncoding.5;
import com.google.common.io.BaseEncoding.Alphabet;
import com.google.common.io.BaseEncoding.Base16Encoding;
import com.google.common.io.BaseEncoding.Base64Encoding;
import com.google.common.io.BaseEncoding.DecodingException;
import com.google.common.math.IntMath;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.math.RoundingMode;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
public abstract class BaseEncoding {
	private static final BaseEncoding BASE64 = new Base64Encoding("base64()",
			"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", '=');
	private static final BaseEncoding BASE64_URL = new Base64Encoding("base64Url()",
			"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", '=');
	private static final BaseEncoding BASE32 = new BaseEncoding.StandardBaseEncoding("base32()",
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ234567", '=');
	private static final BaseEncoding BASE32_HEX = new BaseEncoding.StandardBaseEncoding("base32Hex()",
			"0123456789ABCDEFGHIJKLMNOPQRSTUV", '=');
	private static final BaseEncoding BASE16 = new Base16Encoding("base16()", "0123456789ABCDEF");

	public String encode(byte[] bytes) {
		return this.encode(bytes, 0, bytes.length);
	}

	public final String encode(byte[] bytes, int off, int len) {
		Preconditions.checkPositionIndexes(off, off + len, bytes.length);
		StringBuilder result = new StringBuilder(this.maxEncodedSize(len));

		try {
			this.encodeTo(result, bytes, off, len);
		} catch (IOException var6) {
			throw new AssertionError(var6);
		}

		return result.toString();
	}

	@GwtIncompatible
	public abstract OutputStream encodingStream(Writer var1);

	@GwtIncompatible
   public final ByteSink encodingSink(CharSink encodedSink) {
      Preconditions.checkNotNull(encodedSink);
      return new 1(this, encodedSink);
   }

	private static byte[] extract(byte[] result, int length) {
		if (length == result.length) {
			return result;
		} else {
			byte[] trunc = new byte[length];
			System.arraycopy(result, 0, trunc, 0, length);
			return trunc;
		}
	}

	public abstract boolean canDecode(CharSequence var1);

	public final byte[] decode(CharSequence chars) {
		try {
			return this.decodeChecked(chars);
		} catch (DecodingException var3) {
			throw new IllegalArgumentException(var3);
		}
	}

	final byte[] decodeChecked(CharSequence chars) throws DecodingException {
		chars = this.trimTrailingPadding(chars);
		byte[] tmp = new byte[this.maxDecodedSize(chars.length())];
		int len = this.decodeTo(tmp, chars);
		return extract(tmp, len);
	}

	@GwtIncompatible
	public abstract InputStream decodingStream(Reader var1);

	@GwtIncompatible
   public final ByteSource decodingSource(CharSource encodedSource) {
      Preconditions.checkNotNull(encodedSource);
      return new 2(this, encodedSource);
   }

	abstract int maxEncodedSize(int var1);

	abstract void encodeTo(Appendable var1, byte[] var2, int var3, int var4) throws IOException;

	abstract int maxDecodedSize(int var1);

	abstract int decodeTo(byte[] var1, CharSequence var2) throws DecodingException;

	CharSequence trimTrailingPadding(CharSequence chars) {
		return (CharSequence) Preconditions.checkNotNull(chars);
	}

	public abstract BaseEncoding omitPadding();

	public abstract BaseEncoding withPadChar(char var1);

	public abstract BaseEncoding withSeparator(String var1, int var2);

	public abstract BaseEncoding upperCase();

	public abstract BaseEncoding lowerCase();

	public static BaseEncoding base64() {
		return BASE64;
	}

	public static BaseEncoding base64Url() {
		return BASE64_URL;
	}

	public static BaseEncoding base32() {
		return BASE32;
	}

	public static BaseEncoding base32Hex() {
		return BASE32_HEX;
	}

	public static BaseEncoding base16() {
		return BASE16;
	}

	@GwtIncompatible
   static Reader ignoringReader(Reader delegate, String toIgnore) {
      Preconditions.checkNotNull(delegate);
      Preconditions.checkNotNull(toIgnore);
      return new 3(delegate, toIgnore);
   }

	static Appendable separatingAppendable(Appendable delegate, String separator, int afterEveryChars) {
      Preconditions.checkNotNull(delegate);
      Preconditions.checkNotNull(separator);
      Preconditions.checkArgument(afterEveryChars > 0);
      return new 4(afterEveryChars, delegate, separator);
   }

	@GwtIncompatible
   static Writer separatingWriter(Writer delegate, String separator, int afterEveryChars) {
      Appendable seperatingAppendable = separatingAppendable(delegate, separator, afterEveryChars);
      return new 5(seperatingAppendable, delegate);
   }

	static final class SeparatedBaseEncoding extends BaseEncoding {
		private final BaseEncoding delegate;
		private final String separator;
		private final int afterEveryChars;

		SeparatedBaseEncoding(BaseEncoding delegate, String separator, int afterEveryChars) {
			this.delegate = (BaseEncoding) Preconditions.checkNotNull(delegate);
			this.separator = (String) Preconditions.checkNotNull(separator);
			this.afterEveryChars = afterEveryChars;
			Preconditions.checkArgument(afterEveryChars > 0, "Cannot add a separator after every %s chars",
					afterEveryChars);
		}

		CharSequence trimTrailingPadding(CharSequence chars) {
			return this.delegate.trimTrailingPadding(chars);
		}

		int maxEncodedSize(int bytes) {
			int unseparatedSize = this.delegate.maxEncodedSize(bytes);
			return unseparatedSize + this.separator.length()
					* IntMath.divide(Math.max(0, unseparatedSize - 1), this.afterEveryChars, RoundingMode.FLOOR);
		}

		@GwtIncompatible
		public OutputStream encodingStream(Writer output) {
			return this.delegate.encodingStream(separatingWriter(output, this.separator, this.afterEveryChars));
		}

		void encodeTo(Appendable target, byte[] bytes, int off, int len) throws IOException {
			this.delegate.encodeTo(separatingAppendable(target, this.separator, this.afterEveryChars), bytes, off, len);
		}

		int maxDecodedSize(int chars) {
			return this.delegate.maxDecodedSize(chars);
		}

		public boolean canDecode(CharSequence chars) {
			StringBuilder builder = new StringBuilder();

			for (int i = 0; i < chars.length(); ++i) {
				char c = chars.charAt(i);
				if (this.separator.indexOf(c) < 0) {
					builder.append(c);
				}
			}

			return this.delegate.canDecode(builder);
		}

		int decodeTo(byte[] target, CharSequence chars) throws DecodingException {
			StringBuilder stripped = new StringBuilder(chars.length());

			for (int i = 0; i < chars.length(); ++i) {
				char c = chars.charAt(i);
				if (this.separator.indexOf(c) < 0) {
					stripped.append(c);
				}
			}

			return this.delegate.decodeTo(target, stripped);
		}

		@GwtIncompatible
		public InputStream decodingStream(Reader reader) {
			return this.delegate.decodingStream(ignoringReader(reader, this.separator));
		}

		public BaseEncoding omitPadding() {
			return this.delegate.omitPadding().withSeparator(this.separator, this.afterEveryChars);
		}

		public BaseEncoding withPadChar(char padChar) {
			return this.delegate.withPadChar(padChar).withSeparator(this.separator, this.afterEveryChars);
		}

		public BaseEncoding withSeparator(String separator, int afterEveryChars) {
			throw new UnsupportedOperationException("Already have a separator");
		}

		public BaseEncoding upperCase() {
			return this.delegate.upperCase().withSeparator(this.separator, this.afterEveryChars);
		}

		public BaseEncoding lowerCase() {
			return this.delegate.lowerCase().withSeparator(this.separator, this.afterEveryChars);
		}

		public String toString() {
			return this.delegate + ".withSeparator(\"" + this.separator + "\", " + this.afterEveryChars + ")";
		}
	}

	static class StandardBaseEncoding extends BaseEncoding {
		final Alphabet alphabet;
		@NullableDecl
		final Character paddingChar;
		@MonotonicNonNullDecl
		private transient BaseEncoding upperCase;
		@MonotonicNonNullDecl
		private transient BaseEncoding lowerCase;

		StandardBaseEncoding(String name, String alphabetChars, @NullableDecl Character paddingChar) {
			this(new Alphabet(name, alphabetChars.toCharArray()), paddingChar);
		}

		StandardBaseEncoding(Alphabet alphabet, @NullableDecl Character paddingChar) {
			this.alphabet = (Alphabet) Preconditions.checkNotNull(alphabet);
			Preconditions.checkArgument(paddingChar == null || !alphabet.matches(paddingChar),
					"Padding character %s was already in alphabet", paddingChar);
			this.paddingChar = paddingChar;
		}

		int maxEncodedSize(int bytes) {
			return this.alphabet.charsPerChunk
					* IntMath.divide(bytes, this.alphabet.bytesPerChunk, RoundingMode.CEILING);
		}

		@GwtIncompatible
      public OutputStream encodingStream(Writer out) {
         Preconditions.checkNotNull(out);
         return new com.google.common.io.BaseEncoding.StandardBaseEncoding.1(this, out);
      }

		void encodeTo(Appendable target, byte[] bytes, int off, int len) throws IOException {
			Preconditions.checkNotNull(target);
			Preconditions.checkPositionIndexes(off, off + len, bytes.length);

			for (int i = 0; i < len; i += this.alphabet.bytesPerChunk) {
				this.encodeChunkTo(target, bytes, off + i, Math.min(this.alphabet.bytesPerChunk, len - i));
			}

		}

		void encodeChunkTo(Appendable target, byte[] bytes, int off, int len) throws IOException {
			Preconditions.checkNotNull(target);
			Preconditions.checkPositionIndexes(off, off + len, bytes.length);
			Preconditions.checkArgument(len <= this.alphabet.bytesPerChunk);
			long bitBuffer = 0L;

			int bitOffset;
			for (bitOffset = 0; bitOffset < len; ++bitOffset) {
				bitBuffer |= (long) (bytes[off + bitOffset] & 255);
				bitBuffer <<= 8;
			}

			bitOffset = (len + 1) * 8 - this.alphabet.bitsPerChar;

			int bitsProcessed;
			for (bitsProcessed = 0; bitsProcessed < len * 8; bitsProcessed += this.alphabet.bitsPerChar) {
				int charIndex = (int) (bitBuffer >>> bitOffset - bitsProcessed) & this.alphabet.mask;
				target.append(this.alphabet.encode(charIndex));
			}

			if (this.paddingChar != null) {
				while (bitsProcessed < this.alphabet.bytesPerChunk * 8) {
					target.append(this.paddingChar);
					bitsProcessed += this.alphabet.bitsPerChar;
				}
			}

		}

		int maxDecodedSize(int chars) {
			return (int) (((long) this.alphabet.bitsPerChar * (long) chars + 7L) / 8L);
		}

		CharSequence trimTrailingPadding(CharSequence chars) {
			Preconditions.checkNotNull(chars);
			if (this.paddingChar == null) {
				return chars;
			} else {
				char padChar = this.paddingChar;

				int l;
				for (l = chars.length() - 1; l >= 0 && chars.charAt(l) == padChar; --l) {
					;
				}

				return chars.subSequence(0, l + 1);
			}
		}

		public boolean canDecode(CharSequence chars) {
			Preconditions.checkNotNull(chars);
			chars = this.trimTrailingPadding(chars);
			if (!this.alphabet.isValidPaddingStartPosition(chars.length())) {
				return false;
			} else {
				for (int i = 0; i < chars.length(); ++i) {
					if (!this.alphabet.canDecode(chars.charAt(i))) {
						return false;
					}
				}

				return true;
			}
		}

		int decodeTo(byte[] target, CharSequence chars) throws DecodingException {
			Preconditions.checkNotNull(target);
			chars = this.trimTrailingPadding(chars);
			if (!this.alphabet.isValidPaddingStartPosition(chars.length())) {
				throw new DecodingException("Invalid input length " + chars.length());
			} else {
				int bytesWritten = 0;

				for (int charIdx = 0; charIdx < chars.length(); charIdx += this.alphabet.charsPerChunk) {
					long chunk = 0L;
					int charsProcessed = 0;

					int minOffset;
					for (minOffset = 0; minOffset < this.alphabet.charsPerChunk; ++minOffset) {
						chunk <<= this.alphabet.bitsPerChar;
						if (charIdx + minOffset < chars.length()) {
							chunk |= (long) this.alphabet.decode(chars.charAt(charIdx + charsProcessed++));
						}
					}

					minOffset = this.alphabet.bytesPerChunk * 8 - charsProcessed * this.alphabet.bitsPerChar;

					for (int offset = (this.alphabet.bytesPerChunk - 1) * 8; offset >= minOffset; offset -= 8) {
						target[bytesWritten++] = (byte) ((int) (chunk >>> offset & 255L));
					}
				}

				return bytesWritten;
			}
		}

		@GwtIncompatible
      public InputStream decodingStream(Reader reader) {
         Preconditions.checkNotNull(reader);
         return new com.google.common.io.BaseEncoding.StandardBaseEncoding.2(this, reader);
      }

		public BaseEncoding omitPadding() {
			return (BaseEncoding) (this.paddingChar == null ? this : this.newInstance(this.alphabet, (Character) null));
		}

		public BaseEncoding withPadChar(char padChar) {
			return (BaseEncoding) (8 % this.alphabet.bitsPerChar != 0
					&& (this.paddingChar == null || this.paddingChar != padChar)
							? this.newInstance(this.alphabet, padChar)
							: this);
		}

		public BaseEncoding withSeparator(String separator, int afterEveryChars) {
			for (int i = 0; i < separator.length(); ++i) {
				Preconditions.checkArgument(!this.alphabet.matches(separator.charAt(i)),
						"Separator (%s) cannot contain alphabet characters", separator);
			}

			if (this.paddingChar != null) {
				Preconditions.checkArgument(separator.indexOf(this.paddingChar) < 0,
						"Separator (%s) cannot contain padding character", separator);
			}

			return new BaseEncoding.SeparatedBaseEncoding(this, separator, afterEveryChars);
		}

		public BaseEncoding upperCase() {
			BaseEncoding result = this.upperCase;
			if (result == null) {
				Alphabet upper = this.alphabet.upperCase();
				result = this.upperCase = (BaseEncoding) (upper == this.alphabet
						? this
						: this.newInstance(upper, this.paddingChar));
			}

			return result;
		}

		public BaseEncoding lowerCase() {
			BaseEncoding result = this.lowerCase;
			if (result == null) {
				Alphabet lower = this.alphabet.lowerCase();
				result = this.lowerCase = (BaseEncoding) (lower == this.alphabet
						? this
						: this.newInstance(lower, this.paddingChar));
			}

			return result;
		}

		BaseEncoding newInstance(Alphabet alphabet, @NullableDecl Character paddingChar) {
			return new BaseEncoding.StandardBaseEncoding(alphabet, paddingChar);
		}

		public String toString() {
			StringBuilder builder = new StringBuilder("BaseEncoding.");
			builder.append(this.alphabet.toString());
			if (8 % this.alphabet.bitsPerChar != 0) {
				if (this.paddingChar == null) {
					builder.append(".omitPadding()");
				} else {
					builder.append(".withPadChar('").append(this.paddingChar).append("')");
				}
			}

			return builder.toString();
		}

		public boolean equals(@NullableDecl Object other) {
			if (!(other instanceof BaseEncoding.StandardBaseEncoding)) {
				return false;
			} else {
				BaseEncoding.StandardBaseEncoding that = (BaseEncoding.StandardBaseEncoding) other;
				return this.alphabet.equals(that.alphabet) && Objects.equal(this.paddingChar, that.paddingChar);
			}
		}

		public int hashCode() {
			return this.alphabet.hashCode() ^ Objects.hashCode(new Object[]{this.paddingChar});
		}
	}
}