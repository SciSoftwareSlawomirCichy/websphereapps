package com.ibm.ejs.container.interceptors;

import com.ibm.ejs.container.LifecycleInterceptorWrapper;
import com.ibm.ejs.container.ManagedBeanOBase;
import com.ibm.ejs.container.interceptors.InterceptorMetaData.1;
import com.ibm.ejs.container.interceptors.InterceptorMetaData.ManagedObjectInvocationContextImpl;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.managedobject.ManagedObjectContext;
import com.ibm.ws.managedobject.ManagedObjectFactory;
import com.ibm.ws.managedobject.ManagedObjectInvocationContext;
import com.ibm.wsspi.injectionengine.InjectionEngine;
import com.ibm.wsspi.injectionengine.InjectionTarget;
import java.lang.reflect.Method;

public class InterceptorMetaData {
	private static final String CLASS_NAME = InterceptorMetaData.class.getName();
	private static final TraceComponent tc = Tr.register(InterceptorMetaData.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	public final Class<?>[] ivInterceptorClasses;
	public final ManagedObjectFactory<?>[] ivInterceptorFactories;
	public final InterceptorProxy[] ivAroundConstructInterceptors;
	public final InterceptorProxy[] ivPrePassivateInterceptors;
	public final InterceptorProxy[] ivPreDestroyInterceptors;
	public final InterceptorProxy[] ivPostConstructInterceptors;
	public final InterceptorProxy[] ivPostActivateInterceptors;
	public final Method[] ivBeanLifecycleMethods;
	public InjectionTarget[][] ivInterceptorInjectionTargets;

	public InterceptorMetaData(Class<?>[] classes, ManagedObjectFactory<?>[] factories,
			InterceptorProxy[] aroundConstruct, InterceptorProxy[] postConstruct, InterceptorProxy[] postActivate,
			InterceptorProxy[] prePassivate, InterceptorProxy[] preDestroy, Method[] beanLifecycleMethods) {
		this.ivAroundConstructInterceptors = aroundConstruct;
		this.ivInterceptorClasses = classes;
		this.ivInterceptorFactories = factories;
		this.ivPostConstructInterceptors = postConstruct;
		this.ivPostActivateInterceptors = postActivate;
		this.ivPrePassivateInterceptors = prePassivate;
		this.ivPreDestroyInterceptors = preDestroy;
		this.ivBeanLifecycleMethods = beanLifecycleMethods;
	}

	public void createInterceptorInstances(InjectionEngine injectionEngine, Object[] interceptors, ManagedObjectContext managedObjectContext, ManagedBeanOBase targetContext) throws Exception {
      boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.entry(tc, "createInterceptorInstances");
      }

      if (this.ivInterceptorClasses != null) {
         ManagedObjectInvocationContext invocationContext = this.ivInterceptorFactories != null ? new ManagedObjectInvocationContextImpl(managedObjectContext, (1)null) : null;
         int numberOfInterceptors = this.ivInterceptorClasses.length;

         for(int i = 0; i < numberOfInterceptors; ++i) {
            if (this.ivInterceptorFactories != null && this.ivInterceptorFactories[i] != null) {
               ManagedObject<?> managedObject = this.ivInterceptorFactories[i].createManagedObject(invocationContext);
               interceptors[i] = managedObject.getObject();
            } else {
               interceptors[i] = this.ivInterceptorClasses[i].newInstance();
            }

            try {
               InjectionTarget[] targetsForClass = this.ivInterceptorInjectionTargets[i];
               if (targetsForClass.length > 0) {
                  InjectionTarget[] arr$ = targetsForClass;
                  int len$ = targetsForClass.length;

                  for(int i$ = 0; i$ < len$; ++i$) {
                     InjectionTarget oneTarget = arr$[i$];
                     injectionEngine.inject(interceptors[i], oneTarget, targetContext);
                  }
               }
            } catch (Throwable var14) {
               FFDCFilter.processException(var14, CLASS_NAME + "createInterceptorInstances", "229", this);
               if (isTraceOn && tc.isDebugEnabled()) {
                  Tr.debug(tc, "Injection failure", var14);
               }

               throw ExceptionUtil.EJBException("Injection failure", var14);
            }
         }
      }

      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.exit(tc, "createInterceptorInstances");
      }

   }

	public String toString() {
		StringBuffer buffer = new StringBuffer("Interceptor MetaData:\n");
		int b;
		int i$;
		if (this.ivInterceptorClasses != null) {
			buffer.append("     Interceptor classes:\n");
			Class[] arr$ = this.ivInterceptorClasses;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				Class<?> oneClass = arr$[i$];
				buffer.append("          " + oneClass.getName() + "\n");
			}
		} else {
			buffer.append("     Interceptor classes: NONE\n");
		}

		InterceptorProxy[] arr$;
		InterceptorProxy oneProxy;
		if (this.ivPostConstructInterceptors != null) {
			buffer.append("     PostConstruct interceptor methods:\n");
			arr$ = this.ivPostConstructInterceptors;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				oneProxy = arr$[i$];
				buffer.append("          " + oneProxy.toString() + "\n");
			}
		} else {
			buffer.append("     PostConstruct interceptor methods: NONE\n");
		}

		if (this.ivPostActivateInterceptors != null) {
			buffer.append("     PostActivate interceptor methods:\n");
			arr$ = this.ivPostActivateInterceptors;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				oneProxy = arr$[i$];
				buffer.append("          " + oneProxy.toString() + "\n");
			}
		} else {
			buffer.append("     PostActivate interceptor methods: NONE\n");
		}

		if (this.ivPrePassivateInterceptors != null) {
			buffer.append("     PrePassivate interceptor methods:\n");
			arr$ = this.ivPrePassivateInterceptors;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				oneProxy = arr$[i$];
				buffer.append("          " + oneProxy.toString() + "\n");
			}
		} else {
			buffer.append("     PrePassivate interceptor methods: NONE\n");
		}

		if (this.ivPreDestroyInterceptors != null) {
			buffer.append("     PreDestroy interceptor methods:\n");
			arr$ = this.ivPreDestroyInterceptors;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				oneProxy = arr$[i$];
				buffer.append("          " + oneProxy.toString() + "\n");
			}
		} else {
			buffer.append("     PreDestroy interceptor methods: NONE\n");
		}

		if (this.ivAroundConstructInterceptors != null) {
			buffer.append("     AroundConstruct interceptor methods:\n");
			arr$ = this.ivAroundConstructInterceptors;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				oneProxy = arr$[i$];
				buffer.append("          " + oneProxy.toString() + "\n");
			}
		} else {
			buffer.append("     AroundConstruct interceptor methods: NONE\n");
		}

		int a;
		if (this.ivBeanLifecycleMethods != null) {
			buffer.append("     BeanLifecycle methods:\n");

			for (a = 0; a < this.ivBeanLifecycleMethods.length; ++a) {
				buffer.append("          ").append(LifecycleInterceptorWrapper.TRACE_NAMES[a]).append(": ")
						.append(this.ivBeanLifecycleMethods[a]).append("\n");
			}
		} else {
			buffer.append("     BeanLifeCycle methods: NONE\n");
		}

		if (this.ivInterceptorInjectionTargets != null) {
			buffer.append("     InjectionTargets for interceptor classes:\n");

			for (a = 0; a < this.ivInterceptorInjectionTargets.length; ++a) {
				buffer.append("          Interceptor class: " + a + "\n");

				for (b = 0; b < this.ivInterceptorInjectionTargets[a].length; ++b) {
					buffer.append("               " + this.ivInterceptorInjectionTargets[a][b] + "\n");
				}
			}
		} else {
			buffer.append("     InjectionTargets for interceptor classes: NONE\n");
		}

		return buffer.toString();
	}
}