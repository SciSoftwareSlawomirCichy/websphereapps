package com.ibm.ISecurityUtilityImpl;

import org.omg.CORBA.UserException;

public class InvalidPasswordDecodingException extends UserException {
	private static final long serialVersionUID = -5159453445791067208L;
}