package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Supplier;
import com.google.common.collect.StandardRowSortedTable.1;
import com.google.common.collect.StandardRowSortedTable.RowKeySortedSet;
import com.google.common.collect.StandardRowSortedTable.RowSortedMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;

@GwtCompatible
class StandardRowSortedTable<R, C, V> extends StandardTable<R, C, V> implements RowSortedTable<R, C, V> {
	private transient SortedSet<R> rowKeySet;
	private transient StandardRowSortedTable<R, C, V>.RowSortedMap rowMap;
	private static final long serialVersionUID = 0L;

	StandardRowSortedTable(SortedMap<R, Map<C, V>> backingMap, Supplier<? extends Map<C, V>> factory) {
		super(backingMap, factory);
	}

	private SortedMap<R, Map<C, V>> sortedBackingMap() {
		return (SortedMap) this.backingMap;
	}

	public SortedSet<R> rowKeySet() {
      SortedSet<R> result = this.rowKeySet;
      return result == null ? (this.rowKeySet = new RowKeySortedSet(this, (1)null)) : result;
   }

	public SortedMap<R, Map<C, V>> rowMap() {
      StandardRowSortedTable<R, C, V>.RowSortedMap result = this.rowMap;
      return result == null ? (this.rowMap = new RowSortedMap(this, (1)null)) : result;
   }
}