package com.ibm.ws.wim.adapter.db;

public class DBEntityRelation {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private long descendantId;
	private long ancestorId;

	public long getAncestorId() {
		return this.ancestorId;
	}

	public long getDescendantId() {
		return this.descendantId;
	}

	public void setAncestorId(long var1) {
		this.ancestorId = var1;
	}

	public void setDescendantId(long var1) {
		this.descendantId = var1;
	}
}