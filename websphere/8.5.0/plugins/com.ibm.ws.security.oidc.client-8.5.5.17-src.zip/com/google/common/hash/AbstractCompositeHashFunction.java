package com.google.common.hash;

import com.google.common.base.Preconditions;
import com.google.common.hash.AbstractCompositeHashFunction.1;
import com.google.errorprone.annotations.Immutable;

@Immutable
abstract class AbstractCompositeHashFunction extends AbstractHashFunction {
	final HashFunction[] functions;
	private static final long serialVersionUID = 0L;

	AbstractCompositeHashFunction(HashFunction... functions) {
		HashFunction[] var2 = functions;
		int var3 = functions.length;

		for (int var4 = 0; var4 < var3; ++var4) {
			HashFunction function = var2[var4];
			Preconditions.checkNotNull(function);
		}

		this.functions = functions;
	}

	abstract HashCode makeHash(Hasher[] var1);

	public Hasher newHasher() {
		Hasher[] hashers = new Hasher[this.functions.length];

		for (int i = 0; i < hashers.length; ++i) {
			hashers[i] = this.functions[i].newHasher();
		}

		return this.fromHashers(hashers);
	}

	public Hasher newHasher(int expectedInputSize) {
		Preconditions.checkArgument(expectedInputSize >= 0);
		Hasher[] hashers = new Hasher[this.functions.length];

		for (int i = 0; i < hashers.length; ++i) {
			hashers[i] = this.functions[i].newHasher(expectedInputSize);
		}

		return this.fromHashers(hashers);
	}

	private Hasher fromHashers(Hasher[] hashers) {
      return new 1(this, hashers);
   }
}