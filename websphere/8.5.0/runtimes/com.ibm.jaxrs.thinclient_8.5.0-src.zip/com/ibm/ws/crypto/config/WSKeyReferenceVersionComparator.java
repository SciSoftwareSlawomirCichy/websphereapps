package com.ibm.ws.crypto.config;

import java.util.Comparator;

public class WSKeyReferenceVersionComparator implements Comparator {
	public int compare(Object o1, Object o2) {
		return ((KeyReference) o1).getVersion() - ((KeyReference) o2).getVersion();
	}

	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}