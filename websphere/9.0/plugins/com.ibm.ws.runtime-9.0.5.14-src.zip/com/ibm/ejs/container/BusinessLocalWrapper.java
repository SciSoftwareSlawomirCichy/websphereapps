package com.ibm.ejs.container;

public class BusinessLocalWrapper extends EJSWrapperBase {
}