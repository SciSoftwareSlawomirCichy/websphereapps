package com.ibm.ws.wim.pluginmanager;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.PluginConfigException;
import com.ibm.websphere.wim.exception.SubscriberException;
import com.ibm.websphere.wim.pluginmanager.context.PluginManagerConstants;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.util.Routines;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.ModificationSubscriber;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import com.ibm.ws.wim.configmodel.NotificationSubscriber;
import com.ibm.ws.wim.configmodel.NotificationSubscriberList;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.PostExit;
import com.ibm.ws.wim.configmodel.PreExit;
import com.ibm.ws.wim.configmodel.SubscriberType;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import com.ibm.ws.wim.configmodel.TopicSubscriber;
import com.ibm.ws.wim.configmodel.TopicSubscriberList;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.wsspi.wim.pluginmanager.Subscriber;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PGConfigManager {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static Logger trcLogger;
	private static Map<String, PGConfigManager> singleton;
	private PGSubscriptionManager subManager = null;

	public static synchronized PGConfigManager getConfigurationManager() {
		String var0 = DomainManagerUtils.getDomainId();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new PGConfigManager());
		}

		return (PGConfigManager) singleton.get(var0);
	}

	private void checkForNullorEmptyString(String var1, String var2) throws PluginConfigException {
		if (var1 == null || var1.trim().equals("")) {
			throw new PluginConfigException(var2 + " is either null or empty for Subscriber.");
		}
	}

	private HashMap loadSubscribersFromList(TopicSubscriber[] var1, PGSubscriptionManager var2)
			throws PluginConfigException {
		HashMap var3 = new HashMap();
		Routines.enterMethod(trcLogger, CLASSNAME, "loadSubscribersFromList", Level.FINEST);
		TopicSubscriber[] var5 = var1;
		if (trcLogger.isLoggable(Level.FINE)) {
			StringBuffer var6 = new StringBuffer();
			var6.append("Loading a total of ").append(var1.length).append(" Topic-Subscribers.");
			Routines.logMessage(trcLogger, CLASSNAME, "loadSubscribersFromList", Level.FINE, var6.toString());
		}

		for (int var20 = 0; var20 < var5.length; ++var20) {
			String var7 = var5[var20].getTopicSubscriberName();
			String var8 = var5[var20].getClassName();
			SubscriberType var9 = var5[var20].getTopicSubscriberType();
			this.checkForNullorEmptyString(var7, "topicSubscriberName");
			this.checkForNullorEmptyString(var8, "className");
			this.checkForNullorEmptyString(var9.getName(), "topicSubscriberType");
			Hashtable var10 = new Hashtable();
			ClassLoader var11 = Thread.currentThread().getContextClassLoader();

			try {
				Class var12 = null;

				try {
					var12 = Class.forName(var8);
				} catch (ClassNotFoundException var16) {
					if (var11 == null) {
						var11 = this.getClass().getClassLoader();
					}

					var12 = var11.loadClass(var8);
				}

				Subscriber var13;
				if (var2.isSubscriberAvailable(var7)) {
					var13 = var2.getSubscriber(var7);
					String var14 = var13.getClass().getName();
					if (!var14.equals(var8)) {
						if (trcLogger.isLoggable(Level.FINE)) {
							StringBuffer var15 = new StringBuffer();
							var15.append("Re-registering subscriber ").append(var7);
							var15.append(" Old-ClassName: ").append(var14);
							var15.append(" New-ClassName: ").append(var8);
							Routines.logMessage(trcLogger, CLASSNAME, "loadSubscribersFromList", Level.FINE,
									var15.toString());
						}

						Subscriber var22 = (Subscriber) var12.newInstance();
						var10.put("topicSubscriberName", var7);
						var22.initSubscriber(var10);
						var2.registerSubscriber(var7, var22);
						var3.put(var7, var22);
					}
				} else {
					if (trcLogger.isLoggable(Level.FINE)) {
						StringBuffer var21 = new StringBuffer();
						var21.append("Registering subscriber '").append(var7);
						var21.append("' of type '").append(var9.getName()).append("'");
						var21.append(" with classame '").append(var8).append("'.");
						Routines.logMessage(trcLogger, CLASSNAME, "loadSubscribersFromList", Level.FINE,
								var21.toString());
					}

					var13 = (Subscriber) var12.newInstance();
					var10.put("topicSubscriberName", var7);
					var13.initSubscriber(var10);
					var2.registerSubscriber(var7, var13);
					var3.put(var7, var13);
				}
			} catch (ClassNotFoundException var17) {
				throw new PluginConfigException("PLUGIN_MANAGER_SUBSCRIBER_NOT_FOUND_ERROR", new Object[]{var8, var7},
						Level.SEVERE, CLASSNAME, "loadSubscribersFromList", var17);
			} catch (SubscriberException var18) {
				throw new PluginConfigException("PLUGIN_MANAGER_SUBSCRIBER_LOAD_FAILURE", new Object[]{var7},
						Level.SEVERE, CLASSNAME, "loadSubscribersFromList", var18);
			} catch (Exception var19) {
				throw new PluginConfigException("PLUGIN_MANAGER_SUBSCRIBER_LOAD_FAILURE", new Object[]{var7},
						Level.SEVERE, CLASSNAME, "loadSubscribersFromList", var19);
			}
		}

		Routines.exitMethod(trcLogger, CLASSNAME, "loadSubscribersFromList", Level.FINEST);
		return var3;
	}

	private EmitterReference createEmitterRef(TopicEmitter var1) throws PluginConfigException {
		String var3 = var1.getTopicEmitterName();
		PreExit var4 = var1.getPreExit();
		InlineExit[] var5 = var1.getInlineExitAsArray();
		PostExit var6 = var1.getPostExit();
		EmitterReference var7 = new EmitterReference(var3);
		String var8 = PluginManagerConstants.PREEXIT_LITERAL.getName();
		StringBuffer var9 = new StringBuffer();
		var9.append(PluginManagerConstants.INLINEEXIT_LITERAL.getName());
		String var10 = PluginManagerConstants.POSTEXIT_LITERAL.getName();
		ModificationSubscriberList var11 = null;
		NotificationSubscriberList var12 = null;
		ModificationSubscriber[] var13 = null;
		NotificationSubscriber[] var14 = null;
		ExitPointExecList var15 = null;
		if (var4 != null) {
			var11 = var4.getModificationSubscriberList();
			var12 = var4.getNotificationSubscriberList();
			if (var11 != null) {
				var13 = var11.getModificationSubscriberAsArray();
			}

			if (var12 != null) {
				var14 = var12.getNotificationSubscriberAsArray();
			}

			var15 = this.getExitPointExecList(var3, var8, var14, var13);
			var7.setPreExitExecList(var15);
		} else {
			var15 = this.getExitPointExecList(var3, var8, (NotificationSubscriber[]) null,
					(ModificationSubscriber[]) null);
			var7.setPreExitExecList(var15);
		}

		if (var5 != null) {
			for (int var16 = 0; var16 < var5.length; ++var16) {
				var11 = null;
				var12 = null;
				var13 = null;
				var14 = null;
				var15 = null;
				InlineExit var17 = var5[var16];
				String var18 = var17.getInlineExitName();
				var11 = var17.getModificationSubscriberList();
				if (var11 != null) {
					var13 = var11.getModificationSubscriberAsArray();
				}

				var9.append(var18);
				if (var7.doesInlineExist(var18)) {
					throw new PluginConfigException("PLUGIN_MANAGER_MULTI_INLINE_DUPLICATE_NAME_ERROR",
							new Object[]{var18}, Level.SEVERE, CLASSNAME, "createEmitterRef");
				}

				var15 = this.getExitPointExecList(var3, var9.toString(), (NotificationSubscriber[]) null, var13);
				var7.setInlineExitExecList(var15, var18);
			}
		}

		var11 = null;
		var12 = null;
		var13 = null;
		var14 = null;
		var15 = null;
		if (var6 != null) {
			var11 = var6.getModificationSubscriberList();
			var12 = var6.getNotificationSubscriberList();
			if (var11 != null) {
				var13 = var11.getModificationSubscriberAsArray();
			}

			if (var12 != null) {
				var14 = var12.getNotificationSubscriberAsArray();
			}

			var15 = this.getExitPointExecList(var3, var10, var14, var13);
			var7.setPostExitExecList(var15);
		} else {
			var15 = this.getExitPointExecList(var3, var10, (NotificationSubscriber[]) null,
					(ModificationSubscriber[]) null);
			var7.setPostExitExecList(var15);
		}

		return var7;
	}

	private boolean emitterHasChanged(PGSubscriptionManager var1, HashMap var2, TopicEmitter var3) {
		boolean var4 = false;
		EmitterReference var5 = var1.getEmitter(var3.getTopicEmitterName());
		if (var5 != null && (var5.isChangedPreExit(var3, var2) || var5.isChangedInlineExits(var3, var2)
				|| var5.isChangedPostExit(var3, var2))) {
			var4 = true;
		}

		return var4;
	}

	private HashMap loadEmittersFromList(TopicEmitter[] var1, PGSubscriptionManager var2, HashMap var3)
			throws PluginConfigException {
		String var4 = "loadEmittersFromList";
		Routines.enterMethod(trcLogger, CLASSNAME, var4, Level.FINEST);
		HashMap var5 = new HashMap();
		HashSet var6 = new HashSet();

		for (int var7 = 0; var7 < var1.length; ++var7) {
			TopicEmitter var8 = var1[var7];
			String var9 = var8.getTopicEmitterName();
			if (var6.contains(var9)) {
				throw new PluginConfigException("PLUGIN_MANAGER_MULTI_TOPIC_EMITTER_DUPLICATE_NAME_ERROR",
						new Object[]{var9}, Level.SEVERE, CLASSNAME, var4);
			}

			var6.add(var9);
			if (var9 == null) {
				throw new PluginConfigException(
						"Please check the configuration file and set the attribute 'topicEmitterName' for an emitter.");
			}

			PreExit var10 = var8.getPreExit();
			InlineExit[] var11 = var8.getInlineExitAsArray();
			PostExit var12 = var8.getPostExit();
			EmitterReference var13;
			if (var2.isEmitterAvailable(var9)) {
				if (this.emitterHasChanged(var2, var3, var8)) {
					var13 = this.createEmitterRef(var8);
					var2.setEmitter(var13);
					var5.put(var9, var13);
				}
			} else {
				var13 = this.createEmitterRef(var8);
				var2.setEmitter(var13);
				var5.put(var9, var13);
			}
		}

		Routines.exitMethod(trcLogger, CLASSNAME, var4, Level.FINEST);
		return var5;
	}

	private String invalidSubscriberTypeMsg(String var1, String var2, String var3, String var4) {
		StringBuffer var5 = new StringBuffer();
		var5.append(var1).append(" point of Topic-Emitter '").append(var3);
		var5.append("' has a noncompliant Topic-Subscriber '").append(var4);
		var5.append("' of SubscriberType '").append(var2);
		var5.append("' stored in the ");
		String var6 = SubscriberType.MODIFICATION_SUBSCRIBER_LITERAL.getName();
		String var7 = SubscriberType.NOTIFICATION_SUBSCRIBER_LITERAL.getName();
		if (var2.equals(var6)) {
			var5.append(" NotificationList.");
		} else if (var2.equals(var7)) {
			var5.append(" ModificationList.");
		}

		return var5.toString();
	}

	private String makeSubscriberRefInvalidMsg(String var1, String var2, String var3, String var4) {
		StringBuffer var5 = new StringBuffer();
		var5.append(var1).append(" point of Topic-Emitter '").append(var3);
		var5.append("' has an invalid ").append(var2).append(" Reference ");
		var5.append("'").append(var4).append("' which is not found. ");
		var5.append("Please check the configuration file.");
		return var5.toString();
	}

	private ExitPointExecList getExitPointExecList(String var1, String var2, NotificationSubscriber[] var3,
			ModificationSubscriber[] var4) throws PluginConfigException {
		ExitPointExecList var6 = new ExitPointExecList(var1);
		int var7;
		String var8;
		Subscriber var9;
		com.ibm.wsspi.wim.pluginmanager.SubscriberType var10;
		HashSet var11;
		SubscriberRealmInfo var12;
		String var13;
		if (var3 != null) {
			for (var7 = 0; var7 < var3.length; ++var7) {
				var8 = var3[var7].getNotificationSubscriberReference();
				if (!this.subManager.isSubscriberAvailable(var8)) {
					var13 = SubscriberType.NOTIFICATION_SUBSCRIBER_LITERAL.getName();
					throw new PluginConfigException("PLUGIN_MANAGER_INVALID_SUBSCRIBER_REF_ERROR",
							new Object[]{var2, var1, var13, var8}, Level.SEVERE, CLASSNAME, "getExitPointExecList");
				}

				var9 = this.subManager.getSubscriber(var8);
				var10 = var9.getSubscriberType();
				if (var10.getValue() != 0) {
					throw new PluginConfigException("PLUGIN_MANAGER_INVALID_SUBSCRIBER_TYPE_ERROR",
							new Object[]{var2, var1, var8, var10.getName()}, Level.SEVERE, CLASSNAME,
							"getExitPointExecList");
				}

				var11 = new HashSet(var3[var7].getRealmList());
				var12 = new SubscriberRealmInfo(var9, var11);
				var6.addNotificationSubscriber(var12);
			}
		}

		if (var4 != null) {
			for (var7 = 0; var7 < var4.length; ++var7) {
				var8 = var4[var7].getModificationSubscriberReference();
				if (!this.subManager.isSubscriberAvailable(var8)) {
					var13 = SubscriberType.MODIFICATION_SUBSCRIBER_LITERAL.getName();
					throw new PluginConfigException("PLUGIN_MANAGER_INVALID_SUBSCRIBER_REF_ERROR",
							new Object[]{var2, var1, var13, var8}, Level.SEVERE, CLASSNAME, "getExitPointExecList");
				}

				var9 = this.subManager.getSubscriber(var8);
				var10 = var9.getSubscriberType();
				if (var10.getValue() != 1) {
					throw new PluginConfigException("PLUGIN_MANAGER_INVALID_SUBSCRIBER_TYPE_ERROR",
							new Object[]{var2, var1, var8, var10.getName()}, Level.SEVERE, CLASSNAME,
							"getExitPointExecList");
				}

				var11 = new HashSet(var4[var7].getRealmList());
				var12 = new SubscriberRealmInfo(var9, var11);
				var6.addModificationSubscriber(var12);
			}
		}

		return var6;
	}

	public void initializeConfiguration(PluginManagerConfigurationType var1, PGSubscriptionManager var2)
			throws PluginConfigException {
		String var3 = "initializeConfiguration";
		Routines.enterMethod(trcLogger, CLASSNAME, var3, Level.FINEST);
		this.subManager = var2;
		TopicSubscriberList var4 = var1.getTopicSubscriberList();
		TopicRegistrationList var5 = var1.getTopicRegistrationList();
		HashMap var6 = this.loadSubscribersFromList(var4.getTopicSubscriberAsArray(), var2);
		if (var6.size() > 0) {
			Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINER, "Changed Subscriber List --> BEGIN");
			Iterator var7 = var6.keySet().iterator();

			while (var7.hasNext()) {
				String var8 = (String) var7.next();
				Subscriber var9 = (Subscriber) var6.get(var8);
				StringBuffer var10 = new StringBuffer();
				var10.append(" SubscriberName: ").append(var9.getSubscriberName());
				var10.append(" SubscriberType: ").append(var9.getSubscriberType().getName());
				var10.append(" SubscriberClass: ").append(var9.getClass().getName());
				Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINER, var10.toString());
			}

			Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINER, "Changed Subscriber List --> END");
		}

		HashMap var12 = this.loadEmittersFromList(var5.getTopicEmitterAsArray(), var2, var6);
		if (var12.size() > 0) {
			Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINER, "Changed Emitter List --> BEGIN");
			Iterator var13 = var12.keySet().iterator();

			while (var13.hasNext()) {
				String var14 = (String) var13.next();
				EmitterReference var11 = (EmitterReference) var12.get(var14);
				Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINER, var11.printEmitterReference());
			}

			Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINER, "Changed Emitter List --> END");
		}

		Routines.exitMethod(trcLogger, CLASSNAME, var3, Level.FINEST);
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = PGConfigManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
	}
}