package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.openid20.util.OidUtil;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class MessageDigestUtil {
	private static final TraceComponent tc = Tr.register(MessageDigestUtil.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private static Object locker = new Object();
	private static MessageDigest md = null;
	private static final char[] map = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
			'e', 'f'};
	private static final SecureRandom srandom = new SecureRandom();

	public static String getDigest() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDigest()");
		}

		String digest = null;

		try {
			byte[] digestBytes = null;
			Object var2 = locker;
			byte[] digestBytes;
			synchronized (locker) {
				md.reset();
				byte[] seed = new byte[20];
				srandom.nextBytes(seed);
				md.update(seed);
				digestBytes = md.digest();
			}

			digest = toHex(digestBytes);
		} catch (Exception var6) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Internal error calculating message digest of :", var6);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDigest");
		}

		return digest;
	}

	private static String toHex(byte[] bytes) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "toHex(bytes[" + OidUtil.getObjState(bytes) + "])");
		}

		StringBuilder sb = new StringBuilder();
		byte[] arr$ = bytes;
		int len$ = bytes.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			byte b = arr$[i$];
			sb.append(map[b >>> 4 & 15]);
			sb.append(map[b & 15]);
		}

		String returnVal = sb.toString();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "toHex returns " + returnVal);
		}

		return returnVal;
	}

	static {
		try {
			md = MessageDigest.getInstance("SHA-1");
		} catch (NoSuchAlgorithmException var1) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Internal error initializing message digest", var1);
			}
		}

	}
}