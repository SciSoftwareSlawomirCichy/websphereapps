package com.google.common.io;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.base.Throwables;
import com.google.common.io.Closer.LoggingSuppressor;
import com.google.common.io.Closer.SuppressingSuppressor;
import com.google.common.io.Closer.Suppressor;
import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;

@Beta
public final class Closer implements Closeable {
	private static final Suppressor SUPPRESSOR;
	@VisibleForTesting
	final Suppressor suppressor;
	private final Deque<Closeable> stack = new ArrayDeque(4);
	private Throwable thrown;

	public static Closer create() {
		return new Closer(SUPPRESSOR);
	}

	@VisibleForTesting
	Closer(Suppressor suppressor) {
		this.suppressor = (Suppressor) Preconditions.checkNotNull(suppressor);
	}

	public <C extends Closeable> C register(C closeable) {
		this.stack.push(closeable);
		return closeable;
	}

	public RuntimeException rethrow(Throwable e) throws IOException {
		this.thrown = e;
		Throwables.propagateIfPossible(e, IOException.class);
		throw Throwables.propagate(e);
	}

	public <X extends Exception> RuntimeException rethrow(Throwable e, Class<X> declaredType) throws IOException, X {
		this.thrown = e;
		Throwables.propagateIfPossible(e, IOException.class);
		Throwables.propagateIfPossible(e, declaredType);
		throw Throwables.propagate(e);
	}

	public <X1 extends Exception, X2 extends Exception> RuntimeException rethrow(Throwable e, Class<X1> declaredType1,
			Class<X2> declaredType2) throws IOException, X1, X2 {
		this.thrown = e;
		Throwables.propagateIfPossible(e, IOException.class);
		Throwables.propagateIfPossible(e, declaredType1, declaredType2);
		throw Throwables.propagate(e);
	}

	public void close() throws IOException {
		Throwable throwable = this.thrown;

		while (!this.stack.isEmpty()) {
			Closeable closeable = (Closeable) this.stack.pop();

			try {
				closeable.close();
			} catch (Throwable var4) {
				if (throwable == null) {
					throwable = var4;
				} else {
					this.suppressor.suppress(closeable, throwable, var4);
				}
			}
		}

		if (this.thrown == null && throwable != null) {
			Throwables.propagateIfPossible(throwable, IOException.class);
			throw new AssertionError(throwable);
		}
	}

	static {
		SUPPRESSOR = (Suppressor) (SuppressingSuppressor.isAvailable()
				? SuppressingSuppressor.INSTANCE
				: LoggingSuppressor.INSTANCE);
	}
}