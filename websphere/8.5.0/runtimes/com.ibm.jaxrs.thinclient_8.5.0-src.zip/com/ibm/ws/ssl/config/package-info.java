package com.ibm.ws.ssl.config;

interface package-info {
}