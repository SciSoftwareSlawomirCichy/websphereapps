package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.ImmutableMap.1;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.collect.ImmutableMap.MapViewOfValuesAsSingletonSets;
import com.google.common.collect.ImmutableMap.SerializedForm;import com.google.common.collect.ImmutableMap.IteratorBasedImmutableMap.1EntrySetImpl;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.concurrent.LazyInit;
import java.io.Serializable;
import java.util.Collection;
import java.util.Comparator;
import java.util.Map;
import java.util.SortedMap;
import java.util.AbstractMap.SimpleImmutableEntry;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
public abstract class ImmutableMap<K, V> implements Map<K, V>, Serializable {
	static final Entry<?, ?>[] EMPTY_ENTRY_ARRAY = new Entry[0];
	@LazyInit
	private transient ImmutableSet<Entry<K, V>> entrySet;
	@LazyInit
	private transient ImmutableSet<K> keySet;
	@LazyInit
	private transient ImmutableCollection<V> values;
	@LazyInit
	private transient ImmutableSetMultimap<K, V> multimapView;

	public static <K, V> ImmutableMap<K, V> of() {
		return RegularImmutableMap.EMPTY;
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		return RegularImmutableMap.create(1, new Object[]{k1, v1});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		return RegularImmutableMap.create(2, new Object[]{k1, v1, k2, v2});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		CollectPreconditions.checkEntryNotNull(k3, v3);
		return RegularImmutableMap.create(3, new Object[]{k1, v1, k2, v2, k3, v3});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		CollectPreconditions.checkEntryNotNull(k3, v3);
		CollectPreconditions.checkEntryNotNull(k4, v4);
		return RegularImmutableMap.create(4, new Object[]{k1, v1, k2, v2, k3, v3, k4, v4});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		CollectPreconditions.checkEntryNotNull(k3, v3);
		CollectPreconditions.checkEntryNotNull(k4, v4);
		CollectPreconditions.checkEntryNotNull(k5, v5);
		return RegularImmutableMap.create(5, new Object[]{k1, v1, k2, v2, k3, v3, k4, v4, k5, v5});
	}

	static <K, V> Entry<K, V> entryOf(K key, V value) {
		CollectPreconditions.checkEntryNotNull(key, value);
		return new SimpleImmutableEntry(key, value);
	}

	public static <K, V> Builder<K, V> builder() {
		return new Builder();
	}

	@Beta
	public static <K, V> Builder<K, V> builderWithExpectedSize(int expectedSize) {
		CollectPreconditions.checkNonnegative(expectedSize, "expectedSize");
		return new Builder(expectedSize);
	}

	static void checkNoConflict(boolean safe, String conflictDescription, Entry<?, ?> entry1, Entry<?, ?> entry2) {
		if (!safe) {
			throw conflictException(conflictDescription, entry1, entry2);
		}
	}

	static IllegalArgumentException conflictException(String conflictDescription, Object entry1, Object entry2) {
		return new IllegalArgumentException(
				"Multiple entries with same " + conflictDescription + ": " + entry1 + " and " + entry2);
	}

	public static <K, V> ImmutableMap<K, V> copyOf(Map<? extends K, ? extends V> map) {
		if (map instanceof ImmutableMap && !(map instanceof SortedMap)) {
			ImmutableMap<K, V> kvMap = (ImmutableMap) map;
			if (!kvMap.isPartialView()) {
				return kvMap;
			}
		}

		return copyOf((Iterable) map.entrySet());
	}

	@Beta
	public static <K, V> ImmutableMap<K, V> copyOf(Iterable<? extends Entry<? extends K, ? extends V>> entries) {
		int initialCapacity = entries instanceof Collection ? ((Collection) entries).size() : 4;
		Builder<K, V> builder = new Builder(initialCapacity);
		builder.putAll(entries);
		return builder.build();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final V put(K k, V v) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final V remove(Object o) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final void putAll(Map<? extends K, ? extends V> map) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final void clear() {
		throw new UnsupportedOperationException();
	}

	public boolean isEmpty() {
		return this.size() == 0;
	}

	public boolean containsKey(@NullableDecl Object key) {
		return this.get(key) != null;
	}

	public boolean containsValue(@NullableDecl Object value) {
		return this.values().contains(value);
	}

	public abstract V get(@NullableDecl Object var1);

	public final V getOrDefault(@NullableDecl Object key, @NullableDecl V defaultValue) {
		V result = this.get(key);
		return result != null ? result : defaultValue;
	}

	public ImmutableSet<Entry<K, V>> entrySet() {
		ImmutableSet<Entry<K, V>> result = this.entrySet;
		return result == null ? (this.entrySet = this.createEntrySet()) : result;
	}

	abstract ImmutableSet<Entry<K, V>> createEntrySet();

	public ImmutableSet<K> keySet() {
		ImmutableSet<K> result = this.keySet;
		return result == null ? (this.keySet = this.createKeySet()) : result;
	}

	abstract ImmutableSet<K> createKeySet();

	UnmodifiableIterator<K> keyIterator() {
      UnmodifiableIterator<Entry<K, V>> entryIterator = this.entrySet().iterator();
      return new 1(this, entryIterator);
   }

	public ImmutableCollection<V> values() {
		ImmutableCollection<V> result = this.values;
		return result == null ? (this.values = this.createValues()) : result;
	}

	abstract ImmutableCollection<V> createValues();

	public ImmutableSetMultimap<K, V> asMultimap() {
      if (this.isEmpty()) {
         return ImmutableSetMultimap.of();
      } else {
         ImmutableSetMultimap<K, V> result = this.multimapView;
         return result == null ? (this.multimapView = new ImmutableSetMultimap(new MapViewOfValuesAsSingletonSets(this, (1)null), this.size(), (Comparator)null)) : result;
      }
   }

	public boolean equals(@NullableDecl Object object) {
		return Maps.equalsImpl(this, object);
	}

	abstract boolean isPartialView();

	public int hashCode() {
		return Sets.hashCodeImpl(this.entrySet());
	}

	boolean isHashCodeFast() {
		return false;
	}

	public String toString() {
		return Maps.toStringImpl(this);
	}

	Object writeReplace() {
		return new SerializedForm(this);
	}

	abstract static class IteratorBasedImmutableMap<K, V> extends ImmutableMap<K, V> {
		abstract UnmodifiableIterator<Entry<K, V>> entryIterator();

		ImmutableSet<K> createKeySet() {
			return new ImmutableMapKeySet(this);
		}

		ImmutableSet<Entry<K, V>> createEntrySet() {
         return new 1EntrySetImpl(this);
      }

		ImmutableCollection<V> createValues() {
			return new ImmutableMapValues(this);
		}
	}
}