package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.ContainerTx;

class TransactionKey {
	final ContainerTx tx;
	BeanId id;
	final int hashValue;

	TransactionKey(ContainerTx tx, BeanId id) {
		this.tx = tx;
		this.id = id;
		this.hashValue = (tx != null ? tx.hashCode() : 0) + id.hashCode();
	}

	public final int hashCode() {
		return this.hashValue;
	}

	public final boolean equals(Object o) {
		if (o instanceof TransactionKey) {
			TransactionKey key = (TransactionKey) o;
			if (this.tx == key.tx && (this.id == key.id || this.id.equals(key.id))) {
				this.id = key.id;
				return true;
			}
		}

		return false;
	}

	public final boolean equals(TransactionKey key) {
		if (key == null || this.tx != key.tx || this.id != key.id && !this.id.equals(key.id)) {
			return false;
		} else {
			this.id = key.id;
			return true;
		}
	}

	public String toString() {
		return "TransactionKey(" + this.tx + ", " + this.id + ")";
	}
}