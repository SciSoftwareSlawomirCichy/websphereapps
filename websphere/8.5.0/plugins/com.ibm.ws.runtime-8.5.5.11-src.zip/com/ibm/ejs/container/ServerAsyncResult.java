package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.interrupt.AsyncFutureGetODI;
import com.ibm.websphere.interrupt.InterruptObject;
import com.ibm.websphere.interrupt.ODIRegistrar;
import com.ibm.ws.asynchbeans.WSWorkItem;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class ServerAsyncResult implements Future<Object>, InternalAsyncResult {
	private static final String CLASS_NAME = ServerAsyncResult.class.getName();
	private static final TraceComponent tc;
	public WSWorkItem ivWorkItem;
	private Future<?> ivFuture;
	private Throwable ivException = null;
	private volatile boolean ivCancelled = false;
	private volatile boolean ivWasCancelCalled = false;
	private volatile boolean ivDone = false;
	private final CountDownLatch ivGate = new CountDownLatch(1);
	protected final EJBPMICollaborator ivPmiBean;

	public ServerAsyncResult(EJBPMICollaborator pmiBean) {
		this.ivPmiBean = pmiBean;
	}

	protected void done() {
		this.ivDone = true;
		this.ivGate.countDown();
	}

	public synchronized boolean cancel(boolean mayInterruptIfRunning) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "cancel - Future object: " + this, mayInterruptIfRunning);
		}

		boolean cancelled = false;
		if (!this.ivCancelled) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "attempting to remove from work queue");
			}

			cancelled = this.ivWorkItem.removeFromWorkQueue();
			if (cancelled) {
				this.ivCancelled = true;
				this.done();
				if (this.ivPmiBean != null) {
					this.ivPmiBean.asyncMethodCallCanceled();
					this.ivPmiBean.asyncQueSizeDecrement();
				}
			} else {
				this.ivWasCancelCalled = mayInterruptIfRunning;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "cancel", cancelled);
		}

		return cancelled;
	}

	public boolean wasCancelCalled() {
		return this.ivWasCancelCalled;
	}

	public Object get() throws InterruptedException, ExecutionException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "get - Future object: " + this);
		}

		this.await(0L, (TimeUnit) null);
		Object result = this.getResult();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "get: " + Util.identity(result));
		}

		return result;
	}

	private Object getResult() throws InterruptedException, ExecutionException {
		if (this.ivCancelled) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getResult: throwing CancellationException");
			}

			throw new CancellationException();
		} else if (this.ivException != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getResult: " + this.ivException);
			}

			throw new ExecutionException(this.ivException);
		} else {
			Object resultToReturn;
			if (this.ivFuture == null) {
				resultToReturn = null;
			} else {
				resultToReturn = this.ivFuture.get();
			}

			return resultToReturn;
		}
	}

	protected boolean await(long timeout, TimeUnit unit) throws InterruptedException {
		InterruptObject anOdi = null;
		if (ODIRegistrar.isODISupported() && !this.ivDone) {
			anOdi = new AsyncFutureGetODI(unit == null
					? "Async Future.get(): Awaiting Latch"
					: "Async Future.get(timeout=" + timeout + " unit=" + unit + ") : Awaiting Latch");
			ODIRegistrar.registerODI(anOdi);
		}

		boolean var5;
		try {
			if (unit == null) {
				this.ivGate.await();
				var5 = true;
				return var5;
			}

			var5 = this.ivGate.await(timeout, unit);
		} finally {
			if (anOdi != null) {
				ODIRegistrar.deRegisterODI(anOdi);
			}

		}

		return var5;
	}

	public Object get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			String completeTime = "Timeout setting: " + timeout + " " + unit;
			Tr.entry(tc, "get - " + completeTime + " Future object: " + this);
		}

		if (unit == null) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "get - null unit");
			}

			throw new NullPointerException("unit");
		} else if (!this.await(timeout, unit)) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "get - asynchronous method timed out, throwing TimeoutException.");
			}

			throw new TimeoutException();
		} else {
			Object resultToReturn = this.getResult();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "get: " + Util.identity(resultToReturn));
			}

			return resultToReturn;
		}
	}

	public boolean isCancelled() {
		boolean cancelled = this.ivCancelled;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isCancelled: " + cancelled + " Future object: " + this);
		}

		return cancelled;
	}

	public boolean isDone() {
		boolean done = this.ivDone;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isDone: " + done + " Future object: " + this);
		}

		return done;
	}

	void setResult(Future<?> theFuture) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setResult: " + Util.identity(theFuture) + " Future object: " + this);
		}

		this.ivFuture = theFuture;
		this.done();
	}

	void setException(Throwable theException) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setException - Future object: " + this, theException);
		}

		this.ivException = theException;
		this.done();
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}