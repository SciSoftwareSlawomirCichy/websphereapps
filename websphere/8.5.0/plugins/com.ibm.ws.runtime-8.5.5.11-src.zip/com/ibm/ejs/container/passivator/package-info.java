package com.ibm.ejs.container.passivator;

interface package-info {
}