package com.ibm.ws.ffdc;

import com.ibm.ws.ffdc.IntrospectionLevelMember.1;
import com.ibm.ws.ffdc.IntrospectionLevelMember.2;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.security.AccessController;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public final class IntrospectionLevelMember {
	public static final String $sccsid = "@(#) 1.4 SERV1/ws/code/ras.lite/src/com/ibm/ws/ffdc/IntrospectionLevelMember.java, WAS.ras.lite, WAS855.SERV1, cf051506.04 08/07/23 10:33:23 [2/19/15 14:14:30]";
	private static final String OBJECT_TYPE = "Object type";
	private static final String EQUALS = " = ";
	private static final int EQUALS_LENGTH = " = ".length();
	private static final int EXTRA_SPACE = 5;
	private static final int MAX_PRIMITIVE_ARRAY_LENGTH = 1024;
	private static final Field[] EMPTY_FIELDS = new Field[0];
	private Object _member;
	private int _level;
	private String _name;
	private String _description;
	private List<IntrospectionLevelMember> _children;
	private Set<IntrospectionLevelMember> _allKnownMembersInThisTree;

	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (obj == this) {
			return true;
		} else if (obj instanceof IntrospectionLevelMember) {
			IntrospectionLevelMember other = (IntrospectionLevelMember) obj;
			return this._member == other._member;
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this._member == null ? 0 : System.identityHashCode(this._member);
	}

	public IntrospectionLevelMember(Object member) {
		this(0, "Object type", member.getClass().getName(), member, new HashSet());
		this._allKnownMembersInThisTree.add(this);
	}

	private IntrospectionLevelMember(int level, String name, String description, Object member,
			Set<IntrospectionLevelMember> allKnownMembers) {
		this._level = level;
		this._name = name;
		this._description = description;
		this._member = member;
		this._allKnownMembersInThisTree = allKnownMembers;
	}

	public int sizeOfIntrospection() {
		return this._name.length() + this._description.length() + 5 + 2 * this._level;
	}

	public List<IntrospectionLevelMember> getChildren() {
		if (this._children == null) {
			this._children = new ArrayList();
			if (this._member != null) {
				if (this._member instanceof String) {
					this.addNewChild("String value", this._member);
				} else if (this._member instanceof FFDCSelfIntrospectable) {
					this.introspectSelfIntrospectable();
				} else {
					this.introspectViaReflection();
				}
			}
		}

		return this._children;
	}

	private void introspectViaReflection() {
		Class memberClass = this._member.getClass();
		if (memberClass.isArray()) {
			int length = Array.getLength(this._member);

			for (int i = 0; i < length; ++i) {
				Object value = Array.get(this._member, i);
				this.addNewChild(this._name + "[" + i + "]", value);
			}
		} else {
			for (Class currentClass = this._member.getClass(); currentClass != Object.class; currentClass = currentClass
					.getSuperclass()) {
				Field[] fields = this.getFields(currentClass);

				for (int i = 0; i < fields.length; ++i) {
					Field field = fields[i];
					Object value = this.getFieldValue(field);
					this.addNewChild(field.getName(), value);
				}
			}
		}

	}

	private void introspectSelfIntrospectable() {
		try {
			String[] strings = ((FFDCSelfIntrospectable) this._member).introspectSelf();
			if (strings != null) {
				for (int i = 0; i < strings.length; ++i) {
					if (strings[i] != null) {
						int equalsLoc = strings[i].indexOf(" = ");
						if (equalsLoc > 0 && equalsLoc < strings[i].length() - EQUALS_LENGTH) {
							this.addNewChild(strings[i].substring(0, equalsLoc),
									strings[i].substring(equalsLoc + EQUALS_LENGTH));
						} else if (equalsLoc > 0) {
							this.addNewChild(strings[i].substring(0, equalsLoc), "");
						} else {
							this.addNewChild("strings[" + i + "]", strings[i]);
						}
					} else {
						this.addNewChild("strings[" + i + "]", (Object) null);
					}
				}
			}
		} catch (RuntimeException var4) {
			;
		}

	}

	private void addNewChild(String name, Object value) {
		IntrospectionLevelMember prospectiveMember = new IntrospectionLevelMember(this._level + 1, name,
				this.makeDescription(value), this.makeMember(value), this._allKnownMembersInThisTree);
		if (this.makeMember(value) != null) {
			if (this._allKnownMembersInThisTree.contains(prospectiveMember)) {
				prospectiveMember = new IntrospectionLevelMember(this._level + 1, name, this.makeDescription(value),
						(Object) null, this._allKnownMembersInThisTree);
			} else {
				this._allKnownMembersInThisTree.add(prospectiveMember);
			}
		}

		this._children.add(prospectiveMember);
	}

	private Object getFieldValue(Field field) {
      Object field_value = AccessController.doPrivileged(new 1(this, field));
      return field_value;
   }

	private Field[] getFields(Class currentClass) {
      Field[] objectFields = (Field[])AccessController.doPrivileged(new 2(this, currentClass));
      return objectFields;
   }

	private String makeDescription(Object value) {
		String answer;
		if (value == null) {
			answer = "null";
		} else if (value instanceof String) {
			answer = "\"" + value + "\"";
		} else {
			Class objClass = value.getClass();
			if (objClass != Boolean.class && objClass != Character.class && objClass != Byte.class
					&& objClass != Short.class && objClass != Integer.class && objClass != Long.class
					&& objClass != Float.class && objClass != Double.class) {
				if (objClass.isArray()) {
					if (objClass.getComponentType().isPrimitive()) {
						answer = this.convertSimpleArrayToString(value);
					} else {
						answer = objClass.getComponentType() + "[" + Array.getLength(value) + "]";
					}
				} else {
					answer = value.getClass().toString() + "@" + Integer.toHexString(System.identityHashCode(value));
				}
			} else {
				answer = value.toString();
			}
		}

		return answer;
	}

	private String convertSimpleArrayToString(Object value) {
		int length = Array.getLength(value);
		StringBuffer temp = new StringBuffer("{");

		for (int i = 0; i < length && i < 1024; ++i) {
			Object element = Array.get(value, i);
			if (i > 0 && !(element instanceof Character)) {
				temp.append(",");
			}

			temp.append(element);
		}

		if (length > 1024) {
			if (!(Array.get(value, 0) instanceof Character)) {
				temp.append(",");
			}

			temp.append("...");
		}

		temp.append("} ");
		String answer = temp.toString();
		return answer;
	}

	private Object makeMember(Object value) {
		Object answer = null;
		if (value != null) {
			Class objClass = value.getClass();
			if (objClass.isArray()) {
				if (Array.getLength(value) > 0 && !objClass.getComponentType().isPrimitive()) {
					answer = value;
				}
			} else if (objClass != String.class && objClass != Boolean.class && objClass != Character.class
					&& objClass != Byte.class && objClass != Short.class && objClass != Integer.class
					&& objClass != Long.class && objClass != Float.class && objClass != Double.class
					&& objClass != String.class) {
				answer = value;
			}
		}

		return answer;
	}

	public void print(IncidentStream is, int maxDepth) {
		StringBuffer fullName = new StringBuffer();

		for (int i = 0; i < this._level; ++i) {
			fullName.append("  ");
		}

		fullName.append(this._name);
		is.writeLine(fullName.toString(), this._description);
		if (this._level < maxDepth) {
			List<IntrospectionLevelMember> children = this.getChildren();
			Iterator i$ = children.iterator();

			while (i$.hasNext()) {
				IntrospectionLevelMember ilm = (IntrospectionLevelMember) i$.next();
				ilm.print(is, maxDepth);
			}
		}

	}
}