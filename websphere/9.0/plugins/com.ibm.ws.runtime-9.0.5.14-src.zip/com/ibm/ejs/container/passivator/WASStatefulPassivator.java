package com.ibm.ejs.container.passivator;

import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.websphere.csi.SessionBeanStore;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.managedobject.ManagedObjectContext;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class WASStatefulPassivator extends SharedStatefulPassivator {
	public WASStatefulPassivator(SessionBeanStore beanStore, EJSContainer container, SfFailoverCache failoverCache) {
		super(beanStore, container, failoverCache);
	}

	protected void writeManagedObjectContext(ObjectOutputStream oos, ManagedObjectContext context) throws IOException {
		oos.writeObject(context);
	}

	protected ManagedObjectContext readManagedObjectContext(ObjectInputStream ois, BeanMetaData bmd, Object instance)
			throws IOException, ClassNotFoundException {
		return (ManagedObjectContext) ois.readObject();
	}
}