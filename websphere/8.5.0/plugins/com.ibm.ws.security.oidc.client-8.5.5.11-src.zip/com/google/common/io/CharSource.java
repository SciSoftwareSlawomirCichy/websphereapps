package com.google.common.io;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import javax.annotation.Nullable;

public abstract class CharSource {
	public abstract Reader openStream() throws IOException;

	public BufferedReader openBufferedStream() throws IOException {
		Reader reader = this.openStream();
		return reader instanceof BufferedReader ? (BufferedReader) reader : new BufferedReader(reader);
	}

	public long copyTo(Appendable appendable) throws IOException {
		Preconditions.checkNotNull(appendable);
		Closer closer = Closer.create();

		long var4;
		try {
			Reader reader = (Reader) closer.register(this.openStream());
			var4 = CharStreams.copy(reader, appendable);
		} catch (Throwable var9) {
			throw closer.rethrow(var9);
		} finally {
			closer.close();
		}

		return var4;
	}

	public long copyTo(CharSink sink) throws IOException {
		Preconditions.checkNotNull(sink);
		Closer closer = Closer.create();

		long var5;
		try {
			Reader reader = (Reader) closer.register(this.openStream());
			Writer writer = (Writer) closer.register(sink.openStream());
			var5 = CharStreams.copy(reader, writer);
		} catch (Throwable var10) {
			throw closer.rethrow(var10);
		} finally {
			closer.close();
		}

		return var5;
	}

	public String read() throws IOException {
		Closer closer = Closer.create();

		String var3;
		try {
			Reader reader = (Reader) closer.register(this.openStream());
			var3 = CharStreams.toString(reader);
		} catch (Throwable var7) {
			throw closer.rethrow(var7);
		} finally {
			closer.close();
		}

		return var3;
	}

	@Nullable
	public String readFirstLine() throws IOException {
		Closer closer = Closer.create();

		String var3;
		try {
			BufferedReader reader = (BufferedReader) closer.register(this.openBufferedStream());
			var3 = reader.readLine();
		} catch (Throwable var7) {
			throw closer.rethrow(var7);
		} finally {
			closer.close();
		}

		return var3;
	}

	public ImmutableList<String> readLines() throws IOException {
		Closer closer = Closer.create();

		try {
			BufferedReader reader = (BufferedReader) closer.register(this.openBufferedStream());
			ArrayList result = Lists.newArrayList();

			String line;
			while ((line = reader.readLine()) != null) {
				result.add(line);
			}

			ImmutableList var5 = ImmutableList.copyOf(result);
			return var5;
		} catch (Throwable var9) {
			throw closer.rethrow(var9);
		} finally {
			closer.close();
		}
	}
}