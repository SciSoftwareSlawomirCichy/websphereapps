package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_en extends ListResourceBundle {
	private static final Object[][] resources = new Object[0][];

	public Object[][] getContents() {
		return resources;
	}
}