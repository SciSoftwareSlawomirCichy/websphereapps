package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class InlineExitImpl extends EDataObjectImpl implements InlineExit {
	protected ModificationSubscriberList modificationSubscriberList = null;
	protected static final String INLINE_EXIT_NAME_EDEFAULT = null;
	protected String inlineExitName;

	protected InlineExitImpl() {
		this.inlineExitName = INLINE_EXIT_NAME_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getInlineExit();
	}

	public ModificationSubscriberList getModificationSubscriberList() {
		return this.modificationSubscriberList;
	}

	public NotificationChain basicSetModificationSubscriberList(ModificationSubscriberList var1,
			NotificationChain var2) {
		ModificationSubscriberList var3 = this.modificationSubscriberList;
		this.modificationSubscriberList = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 0, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setModificationSubscriberList(ModificationSubscriberList var1) {
		if (var1 != this.modificationSubscriberList) {
			NotificationChain var2 = null;
			if (this.modificationSubscriberList != null) {
				var2 = ((InternalEObject) this.modificationSubscriberList).eInverseRemove(this, -1, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -1, (Class) null, var2);
			}

			var2 = this.basicSetModificationSubscriberList(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var1, var1));
		}

	}

	public ModificationSubscriberList createModificationSubscriberList() {
		ModificationSubscriberList var1 = ConfigmodelFactory.eINSTANCE.createModificationSubscriberList();
		this.setModificationSubscriberList(var1);
		return var1;
	}

	public String getInlineExitName() {
		return this.inlineExitName;
	}

	public void setInlineExitName(String var1) {
		String var2 = this.inlineExitName;
		this.inlineExitName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.inlineExitName));
		}

	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return this.basicSetModificationSubscriberList((ModificationSubscriberList) null, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getModificationSubscriberList();
			case 1 :
				return this.getInlineExitName();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setModificationSubscriberList((ModificationSubscriberList) var2);
				return;
			case 1 :
				this.setInlineExitName((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setModificationSubscriberList((ModificationSubscriberList) null);
				return;
			case 1 :
				this.setInlineExitName(INLINE_EXIT_NAME_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.modificationSubscriberList != null;
			case 1 :
				return INLINE_EXIT_NAME_EDEFAULT == null
						? this.inlineExitName != null
						: !INLINE_EXIT_NAME_EDEFAULT.equals(this.inlineExitName);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (inlineExitName: ");
			var1.append(this.inlineExitName);
			var1.append(')');
			return var1.toString();
		}
	}
}