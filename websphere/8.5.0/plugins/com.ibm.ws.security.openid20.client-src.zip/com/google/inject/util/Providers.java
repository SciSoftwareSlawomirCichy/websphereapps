package com.google.inject.util;

import com.google.inject.Provider;
import com.google.inject.util.Providers.1;

public final class Providers {
	public static <T> Provider<T> of(T instance) {
      return new 1(instance);
   }
}