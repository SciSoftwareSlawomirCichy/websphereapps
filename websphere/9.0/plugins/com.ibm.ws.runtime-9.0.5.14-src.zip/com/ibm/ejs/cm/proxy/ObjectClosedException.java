package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.portability.PortableSQLException;

class ObjectClosedException extends PortableSQLException {
	private static final long serialVersionUID = 5873548908118996949L;

	ObjectClosedException(Proxy p) {
		super(p.getClass() + " is closed");
	}
}