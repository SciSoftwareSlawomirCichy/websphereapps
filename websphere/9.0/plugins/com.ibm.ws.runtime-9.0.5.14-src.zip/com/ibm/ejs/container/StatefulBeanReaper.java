package com.ibm.ejs.container;

import com.ibm.ejs.container.activator.Activator;
import com.ibm.ejs.container.passivator.StatefulPassivator;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Dumpable;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.FastHashtable;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public final class StatefulBeanReaper implements Runnable, Dumpable {
	private static final TraceComponent tc = Tr.register(StatefulBeanReaper.class, "EJBCache",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.StatefulBeanReaper";
	private long ivSweepInterval;
	private final FastHashtable<BeanId, TimeoutElement> ivStatefulBeanList;
	private static final long DEFAULT_MIN_CLEANUP_INTERVAL = 60000L;
	private static final long DEFAULT_CLEANUP_INTERVAL = 4200000L;
	private Activator ivActivator;
	private final SfFailoverCache ivSfFailoverCache;
	private boolean ivIsCanceled;
	private boolean ivIsRunning;
	private final ScheduledExecutorService ivScheduledExecutorService;
	private ScheduledFuture<?> ivScheduledFuture;
	protected boolean dumped;
	protected int numObjects;
	protected int numAdds;
	protected int numRemoves;
	protected int numNullRemoves;
	protected int numDeletes;

	public StatefulBeanReaper(Activator a, int numBuckets, SfFailoverCache failoverCache,
			ScheduledExecutorService scheduledExecutorService) {
		this(a, numBuckets, 60000L, failoverCache, scheduledExecutorService);
	}

	public StatefulBeanReaper(Activator a, int numBuckets, long cleanupInterval, SfFailoverCache failoverCache,
			ScheduledExecutorService scheduledExecutorService) {
		this.dumped = false;
		this.numObjects = 0;
		this.numAdds = 0;
		this.numRemoves = 0;
		this.numNullRemoves = 0;
		this.numDeletes = 0;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		if (EJSPlatformHelper.isZOS() && cleanupInterval == 0L) {
			this.ivSweepInterval = 4200000L;
		} else if (cleanupInterval < 60000L) {
			this.ivSweepInterval = 60000L;
		} else {
			this.ivSweepInterval = cleanupInterval;
		}

		this.ivStatefulBeanList = new FastHashtable(numBuckets);
		this.ivActivator = a;
		this.ivSfFailoverCache = failoverCache;
		this.ivScheduledExecutorService = scheduledExecutorService;
		Tr.registerDumpable(tc, this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init> : sweep = " + this.ivSweepInterval + " ms");
		}

	}

	public void start() {
	}

	public void run() {
		synchronized (this) {
			if (this.ivIsCanceled) {
				return;
			}

			this.ivIsRunning = true;
		}

		boolean var14 = false;

		label167 : {
			try {
				var14 = true;
				this.sweep();
				var14 = false;
				break label167;
			} catch (Exception var18) {
				FFDCFilter.processException(var18, "com.ibm.ejs.container.StatefulBeanReaper.alarm", "226", this);
				Tr.warning(tc, "UNEXPECTED_EXCEPTION_DURING_STATEFUL_BEAN_CLEANUP_CNTR0015W",
						new Object[]{this, var18});
				var14 = false;
			} finally {
				if (var14) {
					synchronized (this) {
						this.ivIsRunning = false;
						if (this.ivIsCanceled) {
							this.notify();
						} else if (this.numObjects != 0) {
							this.startAlarm();
						} else {
							this.ivScheduledFuture = null;
						}

					}
				}
			}

			synchronized (this) {
				this.ivIsRunning = false;
				if (this.ivIsCanceled) {
					this.notify();
					return;
				} else {
					if (this.numObjects != 0) {
						this.startAlarm();
					} else {
						this.ivScheduledFuture = null;
					}

					return;
				}
			}
		}

		synchronized (this) {
			this.ivIsRunning = false;
			if (this.ivIsCanceled) {
				this.notify();
			} else if (this.numObjects != 0) {
				this.startAlarm();
			} else {
				this.ivScheduledFuture = null;
			}
		}

	}

	public void sweep() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "Sweep : Stateful Beans = " + this.ivStatefulBeanList.size());
		}

		Enumeration e = this.ivStatefulBeanList.elements();

		while (e.hasMoreElements()) {
			TimeoutElement elt = (TimeoutElement) e.nextElement();
			if (elt.isTimedOut()) {
				this.deleteBean(elt.beanId);
			}
		}

		if (this.ivSfFailoverCache != null) {
			this.ivSfFailoverCache.sweep();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "Sweep : Stateful Beans = " + this.ivStatefulBeanList.size());
		}

	}

	public void finalSweep(StatefulPassivator passivator) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "finalSweep : Stateful Beans = " + this.ivStatefulBeanList.size());
		}

		Enumeration e = this.ivStatefulBeanList.elements();

		while (e.hasMoreElements()) {
			TimeoutElement elt = (TimeoutElement) e.nextElement();
			if (elt.passivated) {
				try {
					if (this.remove(elt.beanId)) {
						passivator.remove(elt.beanId, false);
					}
				} catch (RemoteException var5) {
					FFDCFilter.processException(var5, "com.ibm.ejs.container.StatefulBeanReaper.finalSweep", "298",
							this);
					Tr.warning(tc, "REMOVE_FROM_PASSIVATION_STORE_FAILED_CNTR0016W", new Object[]{elt.beanId, var5});
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "finalSweep : Stateful Beans = " + this.ivStatefulBeanList.size());
		}

	}

	public TimeoutElement getTimeoutElement(BeanId beanId) {
		return (TimeoutElement) this.ivStatefulBeanList.get(beanId);
	}

	public boolean beanExistsAndTimedOut(TimeoutElement elt, BeanId beanId) {
		if (elt == null) {
			if (this.ivSfFailoverCache != null) {
				return this.ivSfFailoverCache.beanExistsAndTimedOut(beanId);
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Session bean not in Reaper: Timeout = false");
				}

				return false;
			}
		} else {
			return elt.isTimedOut();
		}
	}

	public boolean beanDoesNotExistOrHasTimedOut(TimeoutElement elt, BeanId beanId) {
		if (elt == null) {
			return this.ivSfFailoverCache != null ? this.ivSfFailoverCache.beanDoesNotExistOrHasTimedOut(beanId) : true;
		} else {
			return elt.isTimedOut();
		}
	}

	private void deleteBean(BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "deleteBean " + beanId);
		}

		synchronized (this) {
			++this.numDeletes;
		}

		try {
			this.ivActivator.timeoutBean(beanId);
		} catch (Exception var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.StatefulBeanReaper.deleteBean", "367", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Unable to timeout session bean");
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "deleteBean");
		}

	}

	public void add(StatefulBeanO beanO) {
		BeanId id = beanO.beanId;
		TimeoutElement elt = beanO.ivTimeoutElement;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "add " + beanO.beanId + ", " + elt.timeout);
		}

		Object obj = this.ivStatefulBeanList.put(id, elt);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, obj != null ? "Stateful bean information replaced" : "Stateful bean information added");
		}

		synchronized (this) {
			if (this.numObjects == 0 && !this.ivIsCanceled) {
				this.startAlarm();
			}

			++this.numObjects;
			++this.numAdds;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "add");
		}

	}

	public boolean remove(BeanId id) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "remove (" + id + ")");
		}

		TimeoutElement elt = null;
		elt = (TimeoutElement) this.ivStatefulBeanList.remove(id);
		synchronized (this) {
			if (elt != null) {
				--this.numObjects;
				++this.numRemoves;
				if (this.numObjects == 0) {
					this.stopAlarm();
				}
			} else {
				++this.numNullRemoves;
			}
		}

		boolean result = elt != null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "remove (" + result + ")");
		}

		return result;
	}

	public synchronized Iterator<BeanId> getPassivatedStatefulBeanIds(J2EEName homeName) {
		ArrayList<BeanId> beanList = new ArrayList();
		Enumeration e = this.ivStatefulBeanList.elements();

		while (e.hasMoreElements()) {
			TimeoutElement elt = (TimeoutElement) e.nextElement();
			if (homeName.equals(elt.beanId.getJ2EEName()) && elt.passivated) {
				beanList.add(elt.beanId);
			}
		}

		return beanList.iterator();
	}

	public long getBeanTimeoutTime(BeanId beanId) {
		TimeoutElement elt = (TimeoutElement) this.ivStatefulBeanList.get(beanId);
		long timeoutTime = 0L;
		if (elt != null && elt.timeout != 0L) {
			timeoutTime = elt.lastAccessTime + elt.timeout;
			if (timeoutTime < 0L) {
				timeoutTime = Long.MAX_VALUE;
			}
		}

		return timeoutTime;
	}

	public void dump() {
		if (!this.dumped) {
			try {
				Tr.dump(tc, "-- StatefulBeanReaper Dump -- ", this);
				synchronized (this) {
					Tr.dump(tc, "Number of objects:      " + this.numObjects);
					Tr.dump(tc, "Number of adds:         " + this.numAdds);
					Tr.dump(tc, "Number of removes:      " + this.numRemoves);
					Tr.dump(tc, "Number of null removes: " + this.numNullRemoves);
					Tr.dump(tc, "Number of deletes:      " + this.numDeletes);
				}
			} finally {
				this.dumped = true;
			}

		}
	}

	public void resetDump() {
		this.dumped = false;
	}

	private void startAlarm() {
		this.ivScheduledFuture = this.ivScheduledExecutorService.schedule(this, this.ivSweepInterval,
				TimeUnit.MILLISECONDS);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "started alarm: " + this.ivScheduledFuture);
		}

	}

	private void stopAlarm() {
		if (this.ivScheduledFuture != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "stopping alarm: " + this.ivScheduledFuture);
			}

			this.ivScheduledFuture.cancel(false);
			this.ivScheduledFuture = null;
		}

	}

	public synchronized void cancel() {
		this.ivIsCanceled = true;
		this.stopAlarm();
		this.ivActivator = null;

		while (this.ivIsRunning) {
			try {
				this.wait();
			} catch (InterruptedException var2) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "interrupted", var2);
				}

				Thread.currentThread().interrupt();
			}
		}

	}
}