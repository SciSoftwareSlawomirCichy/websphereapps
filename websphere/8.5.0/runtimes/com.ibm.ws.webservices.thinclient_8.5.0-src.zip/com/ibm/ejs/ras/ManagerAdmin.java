package com.ibm.ejs.ras;

public final class ManagerAdmin {
	public static boolean isThinClient() {
		return true;
	}
}