package com.ibm.ws.ffdc.impl;

import com.ibm.etools.analysis.engine.Directive;
import com.ibm.etools.analysis.engine.Incident;
import com.ibm.etools.analysis.engine.Solution;
import com.ibm.etools.analysis.engine.engines.FFDCAnalysisEngine;
import com.ibm.ffdc.config.IncidentStream;
import com.ibm.ffdc.util.provider.CapturedDataElements;
import com.ibm.ws.exception.WsException;
import com.ibm.ws.ffdc.DiagnosticEngine;
import com.ibm.ws.ffdc.DiagnosticModule;
import com.ibm.ws.ffdc.FFDC;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DMAdapter extends CapturedDataElements {
	private final List<DiagnosticModule> dml;
	private final CallStack cs;
	private final Object callerThis;
	private final String sourceId;
	private static final String thisClass = DMAdapter.class.getName();
	private static Logger LOGGER;
	private static FFDCAnalysisEngine analysisEngine;
	static boolean isFFDCAnalysisEngineAvailable;

	public DMAdapter(String sourceId, Object reporter, Throwable th, Object[] cde) {
		super(cde);
		LOGGER.entering(thisClass, "constructor", new Object[]{sourceId, reporter, th, cde});
		this.cs = new CallStack(th);
		this.callerThis = reporter;
		this.sourceId = sourceId;
		Configure cfg = FFDC.getConfiguration();
		if (cfg == null) {
			this.dml = null;
		} else {
			this.dml = DiagnosticEngine.getDiagnosticModules(cfg.processLevel, reporter, sourceId, this.cs);
		}

	}

	public void formatTo(IncidentStream is) {
		List<DiagnosticModule> dml = this.dml;
		if (dml != null && !dml.isEmpty()) {
			com.ibm.ws.ffdc.IncidentStream incidentStream = (com.ibm.ws.ffdc.IncidentStream) is;
			FFDCAnalysisEngine analysisEngine = getAnalysisEngine();
			String[] directives;
			if (analysisEngine == null) {
				directives = null;
			} else {
				Incident incident = new Incident((String) null);
				incident.setMessageId(this.cs.getExceptionName());
				incident.setRawData(this.cs.getCallStack());
				Solution[] solutions = analysisEngine.analyzeForSolutions(incident);
				ArrayList<String> lDirectives = new ArrayList(10);
				Solution[] arr$ = solutions;
				int len$ = solutions.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					Solution solution = arr$[i$];
					incidentStream.writeLine("Solution", solution.getDescription());
					Directive[] aDirectives = solution.getDirectives();
					Directive[] arr$ = aDirectives;
					int len$ = aDirectives.length;

					for (int i$ = 0; i$ < len$; ++i$) {
						Directive d = arr$[i$];
						lDirectives.add(d.getDirectiveString());
					}
				}

				directives = (String[]) lDirectives.toArray(new String[0]);
			}

			Iterator i$ = dml.iterator();

			DiagnosticModule dm;
			do {
				if (!i$.hasNext()) {
					return;
				}

				dm = (DiagnosticModule) i$.next();
			} while (this.processDM(incidentStream, dm, directives));

		} else {
			is.write("Reporter", this.callerThis);
			super.formatTo(is);
		}
	}

	private boolean processDM(com.ibm.ws.ffdc.IncidentStream is, DiagnosticModule dm, String[] directives) {
		LOGGER.entering(thisClass, "processDM", new Object[]{is, dm, directives});
		return dm.dumpComponentData(directives, this.cs.getThrowable(), is, this.callerThis,
				this.getCapturedDataElements(), this.sourceId, this.cs);
	}

	private static synchronized FFDCAnalysisEngine getAnalysisEngine() {
		if (analysisEngine == null) {
			if (!isFFDCAnalysisEngineAvailable) {
				return null;
			}

			try {
				String qualifiedName = FFDCHelper.getFFDCDBName();
				analysisEngine = FFDCAnalysisEngine.getInstance(qualifiedName);
				LOGGER.logp(Level.INFO, thisClass, "getAnalysisEngine", "FFDCAnalysisEngineUsing", qualifiedName);
			} catch (WsException var1) {
				isFFDCAnalysisEngineAvailable = false;
				LOGGER.logp(Level.WARNING, thisClass, "getAnalysisEngine", "FFDCAnalysisEngineUsing", var1);
			}
		}

		return analysisEngine;
	}

	static {
		LOGGER = Logger.getLogger(thisClass, "com.ibm.ws.ffdc.resources.FFDCMessages");
		isFFDCAnalysisEngineAvailable = true;
	}
}