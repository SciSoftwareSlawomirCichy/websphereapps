package com.ibm.ejs.csi;

import com.ibm.websphere.csi.Pool;
import com.ibm.websphere.csi.PooledObjectMaster;

public abstract class PoolImplBase implements Pool {
	protected int minSize;
	protected int maxSize;
	protected boolean inactive = true;
	protected PoolManagerImpl poolMgr;
	private Class theTemplateClass = null;

	public abstract Object get();

	public Object get(Class c) throws InstantiationException, IllegalAccessException {
		if (c != this.theTemplateClass) {
			if (this.theTemplateClass != null) {
				throw new InstantiationException("Must use same class on all calls to get() and preLoad() methods");
			}

			this.theTemplateClass = c;
		}

		Object o = this.get();
		if (o == null) {
			o = c.newInstance();
		}

		return o;
	}

	public Object get(PooledObjectMaster m) {
		Object o = this.get();
		if (o == null) {
			o = m.newInstance();
		}

		return o;
	}

	public abstract void put(Object var1);

	abstract void periodicDrain();

	abstract void completeDrain();

	public void preLoad(Class c) throws InstantiationException, IllegalAccessException {
		if (c != this.theTemplateClass) {
			if (this.theTemplateClass != null) {
				throw new InstantiationException("Must use same class on all calls to get() and preLoad() methods");
			}

			this.theTemplateClass = c;
		}

		for (int i = 0; i < this.minSize; ++i) {
			this.put(c.newInstance());
		}

	}

	public void preLoad(PooledObjectMaster m) {
		for (int i = 0; i < this.minSize; ++i) {
			this.put(m.newInstance());
		}

	}

	public final void destroy() {
		this.poolMgr.remove(this);
		this.minSize = this.maxSize = 0;
		this.completeDrain();
	}
}