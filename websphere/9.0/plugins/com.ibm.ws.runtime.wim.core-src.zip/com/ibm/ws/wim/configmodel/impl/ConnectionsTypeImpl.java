package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class ConnectionsTypeImpl extends EDataObjectImpl implements ConnectionsType {
	protected static final String HOST_EDEFAULT = null;
	protected String host;
	protected static final int PORT_EDEFAULT = 389;
	protected int port;
	protected boolean portESet;

	protected ConnectionsTypeImpl() {
		this.host = HOST_EDEFAULT;
		this.port = 389;
		this.portESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getConnectionsType();
	}

	public String getHost() {
		return this.host;
	}

	public void setHost(String var1) {
		String var2 = this.host;
		this.host = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.host));
		}

	}

	public int getPort() {
		return this.port;
	}

	public void setPort(int var1) {
		int var2 = this.port;
		this.port = var1;
		boolean var3 = this.portESet;
		this.portESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.port, !var3));
		}

	}

	public void unsetPort() {
		int var1 = this.port;
		boolean var2 = this.portESet;
		this.port = 389;
		this.portESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 1, var1, 389, var2));
		}

	}

	public boolean isSetPort() {
		return this.portESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getHost();
			case 1 :
				return new Integer(this.getPort());
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setHost((String) var2);
				return;
			case 1 :
				this.setPort((Integer) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setHost(HOST_EDEFAULT);
				return;
			case 1 :
				this.unsetPort();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return HOST_EDEFAULT == null ? this.host != null : !HOST_EDEFAULT.equals(this.host);
			case 1 :
				return this.isSetPort();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (host: ");
			var1.append(this.host);
			var1.append(", port: ");
			if (this.portESet) {
				var1.append(this.port);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}