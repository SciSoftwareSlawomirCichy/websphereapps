package com.google.common.primitives;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.primitives.Chars.CharArrayAsList;
import com.google.common.primitives.Chars.LexicographicalComparator;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@GwtCompatible(emulated = true)
public final class Chars {
	public static final int BYTES = 2;

	public static int hashCode(char value) {
		return value;
	}

	public static char checkedCast(long value) {
		char result = (char) ((int) value);
		Preconditions.checkArgument((long) result == value, "Out of range: %s", new Object[]{value});
		return result;
	}

	public static char saturatedCast(long value) {
		if (value > 65535L) {
			return '￿';
		} else {
			return value < 0L ? ' ' : (char) ((int) value);
		}
	}

	public static int compare(char a, char b) {
		return a - b;
	}

	public static boolean contains(char[] array, char target) {
		char[] arr$ = array;
		int len$ = array.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			char value = arr$[i$];
			if (value == target) {
				return true;
			}
		}

		return false;
	}

	public static int indexOf(char[] array, char target) {
		return indexOf(array, target, 0, array.length);
	}

	private static int indexOf(char[] array, char target, int start, int end) {
		for (int i = start; i < end; ++i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static int indexOf(char[] array, char[] target) {
		Preconditions.checkNotNull(array, "array");
		Preconditions.checkNotNull(target, "target");
		if (target.length == 0) {
			return 0;
		} else {
			label28 : for (int i = 0; i < array.length - target.length + 1; ++i) {
				for (int j = 0; j < target.length; ++j) {
					if (array[i + j] != target[j]) {
						continue label28;
					}
				}

				return i;
			}

			return -1;
		}
	}

	public static int lastIndexOf(char[] array, char target) {
		return lastIndexOf(array, target, 0, array.length);
	}

	private static int lastIndexOf(char[] array, char target, int start, int end) {
		for (int i = end - 1; i >= start; --i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static char min(char... array) {
		Preconditions.checkArgument(array.length > 0);
		char min = array[0];

		for (int i = 1; i < array.length; ++i) {
			if (array[i] < min) {
				min = array[i];
			}
		}

		return min;
	}

	public static char max(char... array) {
		Preconditions.checkArgument(array.length > 0);
		char max = array[0];

		for (int i = 1; i < array.length; ++i) {
			if (array[i] > max) {
				max = array[i];
			}
		}

		return max;
	}

	public static char[] concat(char[]... arrays) {
		int length = 0;
		char[][] arr$ = arrays;
		int pos = arrays.length;

		for (int i$ = 0; i$ < pos; ++i$) {
			char[] array = arr$[i$];
			length += array.length;
		}

		char[] result = new char[length];
		pos = 0;
		char[][] arr$ = arrays;
		int len$ = arrays.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			char[] array = arr$[i$];
			System.arraycopy(array, 0, result, pos, array.length);
			pos += array.length;
		}

		return result;
	}

	@GwtIncompatible("doesn't work")
	public static byte[] toByteArray(char value) {
		return new byte[]{(byte) (value >> 8), (byte) value};
	}

	@GwtIncompatible("doesn't work")
	public static char fromByteArray(byte[] bytes) {
		Preconditions.checkArgument(bytes.length >= 2, "array too small: %s < %s", new Object[]{bytes.length, 2});
		return fromBytes(bytes[0], bytes[1]);
	}

	@GwtIncompatible("doesn't work")
	public static char fromBytes(byte b1, byte b2) {
		return (char) (b1 << 8 | b2 & 255);
	}

	public static char[] ensureCapacity(char[] array, int minLength, int padding) {
		Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[]{minLength});
		Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[]{padding});
		return array.length < minLength ? copyOf(array, minLength + padding) : array;
	}

	private static char[] copyOf(char[] original, int length) {
		char[] copy = new char[length];
		System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
		return copy;
	}

	public static String join(String separator, char... array) {
		Preconditions.checkNotNull(separator);
		int len = array.length;
		if (len == 0) {
			return "";
		} else {
			StringBuilder builder = new StringBuilder(len + separator.length() * (len - 1));
			builder.append(array[0]);

			for (int i = 1; i < len; ++i) {
				builder.append(separator).append(array[i]);
			}

			return builder.toString();
		}
	}

	public static Comparator<char[]> lexicographicalComparator() {
		return LexicographicalComparator.INSTANCE;
	}

	public static char[] toArray(Collection<Character> collection) {
		if (collection instanceof CharArrayAsList) {
			return ((CharArrayAsList) collection).toCharArray();
		} else {
			Object[] boxedArray = collection.toArray();
			int len = boxedArray.length;
			char[] array = new char[len];

			for (int i = 0; i < len; ++i) {
				array[i] = (Character) Preconditions.checkNotNull(boxedArray[i]);
			}

			return array;
		}
	}

	public static List<Character> asList(char... backingArray) {
		return (List) (backingArray.length == 0 ? Collections.emptyList() : new CharArrayAsList(backingArray));
	}
}