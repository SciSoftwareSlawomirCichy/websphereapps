package com.ibm.ws.wim;

import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.SchemaService;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.InvalidEntityTypeException;
import com.ibm.websphere.wim.exception.InvalidPropertyDefinitionException;
import com.ibm.websphere.wim.exception.InvalidRepositoryIdException;
import com.ibm.websphere.wim.exception.InvalidSchemaException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.SchemaAlreadyExistException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.security.authz.Entitlement;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.websphere.wim.util.XSDHelper;
import com.ibm.ws.wim.SchemaManager.1;
import com.ibm.ws.wim.SchemaManager.2;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.schema.DBDataType;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.util.AsyncUtils;
import com.ibm.ws.wim.util.ControlsHelper;
import com.ibm.ws.wim.util.DataGraphHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.wsspi.wim.Repository;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Type;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EPackage.Registry;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.EProperty;
import org.eclipse.emf.ecore.sdo.SDOFactory;
import org.eclipse.emf.ecore.sdo.impl.DynamicEDataObjectImpl.FactoryImpl;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;
import org.eclipse.xsd.ecore.XSDEcoreBuilder;
import org.eclipse.xsd.util.XSDResourceFactoryImpl;

public class SchemaManager implements SchemaService, DynamicConfigService {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	public static final String WIM_XML_EXTENSION_FILE = "wimxmlextension.xml";
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static Map<String, SchemaManager> singleton;
	private static final String eINSTANCE = "eINSTANCE";
	private ConfigManager iConfigMgr = null;
	private Map iPrefixToURI = null;
	private static Map globalIprefixToURI;
	private Map iEntitySubTypes = null;
	private String iXMLExtFilePath = null;
	boolean useGlobalSchema = false;
	static boolean globalSchemaInited;
	static boolean globalExtXMLLoaded;
	private Map uriToSchema = null;
	private static Map globalUriToSchema;
	private Map iEntityProps = null;
	private Map iProperties = null;
	private DataGraph iXMLExtDG = null;
	private static DataGraph globalXMLExtDG;
	private static boolean isAddSDOUtilAdapType;

	private SchemaManager() throws WIMException {
		this.iEntitySubTypes = new Hashtable();
		this.iEntityProps = new Hashtable();
		this.iProperties = new Hashtable();
		this.initialize();
	}

	public static synchronized SchemaManager singleton() throws WIMException {
		String var0 = DomainManagerUtils.getDomainId();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new SchemaManager());
		}

		return (SchemaManager) singleton.get(var0);
	}

	public static synchronized void verifyEMFModelPackageExists() {
		String var1 = DomainManagerUtils.getDomainId();
		if (singleton != null && singleton.get(var1) != null
				&& Registry.INSTANCE.getEPackage("http://www.ibm.com/websphere/wim") == null) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "verifyEMFModelPackageExists",
					"EMF model package is not visible.  Package will be re-registered");
			((SchemaManager) singleton.get(var1)).reRegisterPackages();
		}

	}

	public static void clearCache(String var0) {
		singleton.put(var0, (Object) null);
	}

	public void initialize() throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize");
		}

		this.iConfigMgr = ConfigManager.singleton();
		DataObject var2 = this.iConfigMgr.getConfig();
		DataObject var3 = var2.getDataObject("dynamicModel");
		String var4 = File.separator;
		Class var6;
		if (var3 != null) {
			String var5 = var3.getString("xsdFileName");
			if (var5 == null) {
				var5 = this.iConfigMgr.getWIMHomePath() + "model" + var4 + "wimextension.xsd";
			} else if (var5.indexOf(var4) == -1) {
				if (var5.equalsIgnoreCase("wimdatagraph.xsd")) {
					var5 = this.iConfigMgr.getWIMSchemaHomePath() + "model" + var4 + var5;
				} else {
					var5 = this.iConfigMgr.getWIMHomePath() + "model" + var4 + var5;
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize", "Use dynamic WIM model: " + var5);
			}

			this.useGlobalSchema = var3.getBoolean("useGlobalSchema") || DomainManagerUtils.isAdminDomain();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
						"Use dynamic WIM model as GlobalSchema " + this.useGlobalSchema);
			}

			if (this.useGlobalSchema) {
				this.uriToSchema = globalUriToSchema;
				this.iPrefixToURI = globalIprefixToURI;
				var6 = SchemaManager.class;
				synchronized (SchemaManager.class) {
					if (globalSchemaInited) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
									"Global Schema Already initialized.So not initializing again");
						}
					} else {
						this.loadModelFromXSD(var5);
					}
				}
			} else {
				this.uriToSchema = new HashMap();
				this.iPrefixToURI = new HashMap();
				this.loadModelFromXSD(var5);
			}
		} else {
			DataObject var13 = var2.getDataObject("staticModel");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize", "Use static WIM model.");
			}

			this.useGlobalSchema = var13.getBoolean("useGlobalSchema") || DomainManagerUtils.isAdminDomain();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
						"Use static WIM model as GlobalSchema " + this.useGlobalSchema);
			}

			if (this.useGlobalSchema) {
				this.uriToSchema = globalUriToSchema;
				this.iPrefixToURI = globalIprefixToURI;
				var6 = SchemaManager.class;
				synchronized (SchemaManager.class) {
					if (globalSchemaInited) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
									"Global Schema Already initialized.So not initializing again");
						}
					} else {
						this.loadModelFromPackage(var13);
					}
				}
			} else {
				this.uriToSchema = new HashMap();
				this.iPrefixToURI = new HashMap();
				this.loadModelFromPackage(var13);
			}
		}

		if (this.useGlobalSchema) {
			this.iXMLExtFilePath = this.iConfigMgr.getWIMHomePath() + "model" + var4 + "wimxmlextension.xml";
			Class var14 = SchemaManager.class;
			synchronized (SchemaManager.class) {
				if (globalExtXMLLoaded) {
					this.iXMLExtDG = globalXMLExtDG;
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
								"Using Global Schema. Extension XML already loaded.Not Loading again.");
					}
				} else {
					this.loadModelFromExtXML(this.iXMLExtFilePath);
				}
			}
		} else {
			this.iXMLExtFilePath = this.iConfigMgr.getWIMHomePath(DomainManagerUtils.getDomainName()) + "model" + var4
					+ "wimxmlextension.xml";
			this.loadModelFromExtXML(this.iXMLExtFilePath);
		}

		if (isAddSDOUtilAdapType) {
			initPackage("http://www.ibm.com/websphere/wim");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

	}

	public DataObject getWimXmlExtXml(String var1) throws InitializationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getWimXmlExtXml", "The path for wimxmlextension.xml provided is " + var1);
		}

		long var3 = System.currentTimeMillis();
		DataObject var5 = null;
		if (null != var1 && var1.trim().length() != 0) {
			try {
				FileInputStream var6 = new FileInputStream(var1);
				HashMap var7 = new HashMap();
				this.iXMLExtDG = SDOUtil.loadDataGraph(var6, var7);
				if (trcLogger.isLoggable(Level.FINER)) {
					long var8 = System.currentTimeMillis();
					trcLogger.logp(Level.FINER, CLASSNAME, "getWimXmlExtXml",
							"Loaded from " + var1 + " (" + (var8 - var3) + " milliseconds)");
				}
			} catch (FileNotFoundException var10) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "getWimXmlExtXml", "XML extension file " + var1 + " is not found.");
				}

				return var5;
			} catch (IOException var11) {
				throw new InitializationException("INVALID_WIM_EXTENSION_XML_FILE",
						WIMMessageHelper.generateMsgParms(var1, var11.getMessage()), CLASSNAME, "getWimXmlExtXml",
						var11);
			}

			if (null != this.iXMLExtDG) {
				var5 = this.iXMLExtDG.getRootObject();
				if (this.useGlobalSchema) {
					globalXMLExtDG = this.iXMLExtDG;
					globalExtXMLLoaded = true;
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getWimXmlExtXml", WIMTraceHelper.printDataObject(var5));
			}

			return var5;
		} else {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getWimXmlExtXml",
						"Exiting since the file path for wimxmlextension.xml is empty or null");
			}

			return var5;
		}
	}

	public String getNsPrefix(String var1) {
		Iterator var2 = this.iPrefixToURI.keySet().iterator();

		String var3;
		String var4;
		do {
			if (!var2.hasNext()) {
				return null;
			}

			var3 = (String) var2.next();
			var4 = (String) this.iPrefixToURI.get(var3);
		} while (!var4.equals(var1));

		return var3;
	}

	public String getNsURI(String var1) {
		return var1 != null && var1.length() != 0
				? (String) this.iPrefixToURI.get(var1)
				: "http://www.ibm.com/websphere/wim";
	}

	private void addPrefixToURIMap(String var1, String var2) throws InvalidSchemaException {
		if (var2 != null && var2.trim().length() != 0) {
			if (var1 == null) {
				var1 = var2.substring(var2.lastIndexOf("/") + 1);
			}

			if (this.iPrefixToURI.containsValue(var2)) {
				throw new InvalidSchemaException("DUPLICATE_NS_URI", WIMMessageHelper.generateMsgParms(var2), CLASSNAME,
						"addPrefixToURIMap");
			} else if (this.iPrefixToURI.containsKey(var1)) {
				throw new InvalidSchemaException("DUPLICATE_NS_PREFIX", WIMMessageHelper.generateMsgParms(var1, var2),
						CLASSNAME, "addPrefixToURIMap");
			} else {
				this.iPrefixToURI.put(var1, var2);
			}
		} else {
			throw new InvalidSchemaException("INVALID_NS_URI", CLASSNAME, "addPrefixToURIMap");
		}
	}

	private boolean addTempPrefixToURIMap(String var1, String var2) {
		if (var2 != null && var2.trim().length() != 0) {
			if (var1 == null) {
				var1 = var2.substring(var2.lastIndexOf("/") + 1);
			}

			if (!this.iPrefixToURI.containsValue(var2) && !this.iPrefixToURI.containsKey(var1)) {
				this.iPrefixToURI.put(var1, var2);
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	private void removeFromPrefixURIMap(String var1) {
		this.iPrefixToURI.remove(var1);
	}

	private void loadModelFromXSD(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "loadModelFromXSD", var1);
		}

		org.eclipse.emf.ecore.resource.Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xsd",
				new XSDResourceFactoryImpl());
		org.eclipse.emf.ecore.resource.Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("ecore",
				new EcoreResourceFactoryImpl());
		XSDEcoreBuilder var3 = new XSDEcoreBuilder();
		String var4 = "org.eclipse.emf.ecore.xml.namespace.impl.XMLNamespacePackageImpl";
		String var5 = "http://www.w3.org/XML/1998/namespace";
		EPackage var6 = Registry.INSTANCE.getEPackage(var5);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "loadModelFromXSD",
					"Before VMM replaces original package for xmlnamespace: " + var6 + "::" + var6);
		}

		Collection var7 = var3.generate(URI.createFileURI(var1));
		Iterator var8 = var7.iterator();

		EPackage var9;
		while (var8.hasNext()) {
			var9 = (EPackage) var8.next();
			String var10 = var9.getNsURI();
			String var11 = var9.getNsPrefix();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "loadModelFromXSD",
						"Package nsURI: " + var10 + ", nsPrefix=" + var11);
			}

			this.addPrefixToURIMap(var11, var10);
			var9.setEFactoryInstance(new FactoryImpl());
			if (this.useGlobalSchema) {
				DomainManagerUtils.putPackageInEMFGlobalRegistryFromVMM(var10, var9);
			} else {
				DomainManagerUtils.putPackageInEMFDomainRegistryFromVMM(var10, var9);
			}

			this.uriToSchema.put(var10, var9);
			this.readPackage(var9);
		}

		var9 = Registry.INSTANCE.getEPackage(var5);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "loadModelFromXSD",
					"After VMM replaced original package for xmlnamespace: " + var9 + "::" + var9);
		}

		if (Registry.INSTANCE.getEPackage("http://www.ibm.com/websphere/wim") == null) {
			throw new InitializationException("WIM_MODEL_PACKAGE_NOT_FOUND_IN_XSD",
					WIMMessageHelper.generateMsgParms("http://www.ibm.com/websphere/wim", var1), CLASSNAME,
					"loadModelFromXSD");
		} else {
			Registry.INSTANCE.remove(var5);
			Registry.INSTANCE.put(var5, var6);
			EPackage var12 = Registry.INSTANCE.getEPackage(var5);
			Object var13 = Registry.INSTANCE.get(var5);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "loadModelFromXSD",
						"After placing original package for xmlnamespace: " + var12 + "::" + var13);
			}

			if (this.useGlobalSchema) {
				globalSchemaInited = true;
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "loadModelFromXSD");
			}

		}
	}

	private void loadModelFromPackage(DataObject var1) throws WIMException {
		List var3 = var1.getList("packageName");
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "loadModelFromPackage", var3);
		}

		if (!var3.contains("com.ibm.websphere.wim.model.ModelPackage")) {
			var3.add("com.ibm.websphere.wim.model.ModelPackage");
		}

		for (int var4 = 0; var4 < var3.size(); ++var4) {
			String var5 = (String) var3.get(var4);

			try {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "loadModelFromPackage", "loading package " + var5);
				}

				Class var6 = Class.forName(var5);
				EPackage var7 = (EPackage) var6.getField("eINSTANCE").get(var6);
				String var8 = var7.getNsURI();
				String var9 = var7.getNsPrefix();
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "loadModelFromPackage",
							"nsURI=" + var8 + ", nsPrefix=" + var9);
				}

				this.addPrefixToURIMap(var9, var8);
				if (this.useGlobalSchema) {
					DomainManagerUtils.putPackageInEMFGlobalRegistryFromVMM(var8, var7);
				} else {
					DomainManagerUtils.putPackageInEMFDomainRegistryFromVMM(var8, var7);
				}

				this.uriToSchema.put(var8, var7);
				this.readPackage(var7);
			} catch (ClassNotFoundException var10) {
				throw new InitializationException("CLASS_OR_INTERFACE_NOT_FOUND",
						WIMMessageHelper.generateMsgParms(var5, "packageName"), CLASSNAME, "loadModelFromPackage",
						var10);
			} catch (NoSuchFieldException var11) {
				throw new InitializationException("INVALID_PACKAGE_NAME",
						WIMMessageHelper.generateMsgParms(var5, "packageName"), CLASSNAME, "loadModelFromPackage",
						var11);
			} catch (IllegalAccessException var12) {
				throw new InitializationException("INVALID_PACKAGE_NAME",
						WIMMessageHelper.generateMsgParms(var5, "packageName"), CLASSNAME, "loadModelFromPackage",
						var12);
			}
		}

		if (this.useGlobalSchema) {
			globalSchemaInited = true;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "loadModelFromPackage");
		}

	}

	private EPackage createPackage(String var1, String var2, String var3) throws InvalidSchemaException {
		EcoreFactory var4 = EcoreFactory.eINSTANCE;
		EPackage var5 = var4.createEPackage();
		var5.setNsURI(var1);
		if (var3 != null) {
			var5.setName(var3);
		}

		if (var2 != null) {
			var5.setNsPrefix(var2);
		}

		var5.setEFactoryInstance(new FactoryImpl());
		if (this.useGlobalSchema) {
			DomainManagerUtils.putPackageInEMFGlobalRegistryFromVMM(var1, var5);
		} else {
			DomainManagerUtils.putPackageInEMFDomainRegistryFromVMM(var1, var5);
		}

		this.uriToSchema.put(var1, var5);
		var2 = var5.getNsPrefix();
		this.addPrefixToURIMap(var2, var1);
		return var5;
	}

	private void addEntitySchema(DataObject var1, DataObject var2) throws WIMException {
		String var4 = var1.getString("entityName");
		String var5 = var1.getString("nsURI");
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "addEntitySchema", "entityName=" + var4 + ", nsURI=" + var5);
		}

		EPackage var6 = Registry.INSTANCE.getEPackage(var5);
		if (var6 == null) {
			var6 = this.createPackage(var5, var1.getString("nsPrefix"), (String) null);
		}

		if (this.getEClass(var4, var5) != null) {
			throw new SchemaAlreadyExistException("ENTITY_TYPE_ALREADY_DEFINED",
					WIMMessageHelper.generateMsgParms(var4, var5), CLASSNAME, "addEntitySchema");
		} else {
			String var7 = var1.getString("parentEntityName");
			EClass var8 = this.getEClass(var7);
			if (var8 == null) {
				throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
						WIMMessageHelper.generateMsgParms(var7), CLASSNAME, "addEntitySchema");
			} else {
				List var9 = var1.getList("properties");
				ArrayList var10 = new ArrayList(var9.size());

				for (int var11 = 0; var11 < var9.size(); ++var11) {
					DataObject var12 = (DataObject) var9.get(var11);
					String var13 = var12.getString("name");
					if (this.getProperty(var4, var13) != null) {
						throw new SchemaAlreadyExistException("PROPERTY_TYPE_ALREADY_DEFINED",
								WIMMessageHelper.generateMsgParms(var13, var4), CLASSNAME, "addEntitySchema");
					}

					EStructuralFeature var14 = XSDHelper.getGlobalFeature(var13);
					if (var14 == null) {
						throw new InvalidSchemaException("PROPERTY_NOT_DEFINED",
								WIMMessageHelper.generateMsgParms(var13), CLASSNAME, "addEntitySchema");
					}

					var10.add(var14);
				}

				EcoreFactory var20 = EcoreFactory.eINSTANCE;
				EClass var21 = var20.createEClass();
				var21.setName(var4);
				var21.getESuperTypes().add(var8);
				var6.getEClassifiers().add(var21);

				DataObject var24;
				for (int var22 = 0; var22 < var10.size(); ++var22) {
					var24 = (DataObject) var9.get(var22);
					String var15 = var24.getString("name");
					String var16 = XSDHelper.getNsURIFromQualifiedName(var15);
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "addEntitySchema",
								"Processing property " + var15 + ", propURI=" + var16);
					}

					EStructuralFeature var17 = (EStructuralFeature) var10.get(var22);
					EStructuralFeature var18 = (EStructuralFeature) EcoreUtil.copy(var17);
					var17.setTransient(false);
					var17.setVolatile(false);
					var17.setDerived(false);
					boolean var19 = var24.getBoolean("multiValued");
					if (var19) {
						var17.setUpperBound(-1);
					} else {
						var17.setUpperBound(1);
					}

					var21.getEStructuralFeatures().add(var17);
					ExtendedMetaData.INSTANCE.setNamespace(var17, var16);
				}

				Iterator var23 = this.iEntitySubTypes.keySet().iterator();

				while (var23.hasNext()) {
					String var26 = (String) var23.next();
					EClass var27 = this.getEClass(var26);
					if (var27 != null && var27.isSuperTypeOf(var21)) {
						Set var29 = (Set) this.iEntitySubTypes.get(var26);
						var29.add(this.getQualifiedTypeName(var5, var21.getName()));
					}
				}

				if (var2 != null) {
					DataObject var25 = DataGraphHelper.cloneDataObject(var1);
					var24 = var25.getDataObject("entityConfiguration");
					if (var24 != null) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "addEntitySchema",
									"Remove entity config from schema extension data");
						}

						var24.delete();
					}

					var9 = var25.getList("properties");

					for (int var28 = 0; var28 < var9.size(); ++var28) {
						DataObject var30 = (DataObject) var9.get(var28);
						List var31 = var30.getList("metaData");

						for (int var32 = 0; var32 < var31.size(); ++var32) {
							DataObject var33 = (DataObject) var31.get(var32);
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "addEntitySchema",
										"Remove prop metadata from schema extension data");
							}

							var33.delete();
						}
					}

					var2.getList("entitySchema").add(var25);
				}

				this.iEntitySubTypes.clear();
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "addEntitySchema", "New entity type '" + var4 + "' is created.");
				}

			}
		}
	}

	public EDataType getEDataType(String var1) {
		XMLTypePackage var2 = XMLTypePackage.eINSTANCE;
		EDataType var3 = null;
		if ("String".equalsIgnoreCase(var1)) {
			var3 = var2.getString();
		} else if ("Int".equalsIgnoreCase(var1)) {
			var3 = var2.getInt();
		} else if ("Date".equalsIgnoreCase(var1)) {
			var3 = var2.getDate();
		} else if ("Boolean".equalsIgnoreCase(var1)) {
			var3 = var2.getBoolean();
		} else if ("AnySimpleType".equalsIgnoreCase(var1)) {
			var3 = var2.getAnySimpleType();
		} else if ("Long".equalsIgnoreCase(var1)) {
			var3 = var2.getLong();
		} else if ("Double".equalsIgnoreCase(var1)) {
			var3 = var2.getDouble();
		} else if ("Base64Binary".equalsIgnoreCase(var1)) {
			var3 = var2.getBase64Binary();
		} else if ("AnyURI".equalsIgnoreCase(var1)) {
			var3 = var2.getAnyURI();
		} else if ("Byte".equalsIgnoreCase(var1)) {
			var3 = var2.getByte();
		} else if ("DateTime".equalsIgnoreCase(var1)) {
			var3 = var2.getDateTime();
		} else if ("Short".equalsIgnoreCase(var1)) {
			var3 = var2.getShort();
		} else if ("Token".equalsIgnoreCase(var1)) {
			var3 = var2.getToken();
		}

		return var3;
	}

	private void addPropertySchema(DataObject var1, DataObject var2) throws WIMException {
		String var4 = var1.getString("propertyName");
		EcoreFactory var5 = EcoreFactory.eINSTANCE;
		String var6 = var1.getString("dataType");
		String var7 = var1.getString("nsURI");
		String var8 = var1.getString("nsPrefix");
		boolean var9 = false;
		var9 = this.addTempPrefixToURIMap(var8, var7);
		String var10 = this.getQualifiedTypeName(var7, var4);
		List var11 = var1.getList("applicableEntityTypeNames");
		ArrayList var12 = new ArrayList(var11.size());

		for (int var13 = 0; var13 < var11.size(); ++var13) {
			String var14 = (String) var11.get(var13);
			EClass var15 = this.getEClass(var14);
			if (var15 == null) {
				throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
						WIMMessageHelper.generateMsgParms(var14), CLASSNAME, "addPropertySchema");
			}

			if (this.getProperty(var14, var10) != null) {
				throw new SchemaAlreadyExistException("PROPERTY_TYPE_ALREADY_DEFINED",
						WIMMessageHelper.generateMsgParms(var10, var14), CLASSNAME, "addPropertySchema");
			}

			var12.add(var15);
		}

		if (var9) {
			this.removeFromPrefixURIMap(var8);
		}

		EPackage var24 = Registry.INSTANCE.getEPackage(var7);
		if (var24 == null) {
			this.createPackage(var7, var8, (String) null);
		}

		EDataType var25 = this.getEDataType(var6);
		boolean var26 = var1.getBoolean("multiValued");
		List var16 = var1.getList("requiredEntityTypeNames");

		for (int var17 = 0; var17 < var12.size(); ++var17) {
			EClass var18 = (EClass) var12.get(var17);
			Object var19 = null;
			if (var25 != null) {
				var19 = var5.createEAttribute();
				((EStructuralFeature) var19).setEType(var25);
				if ("Boolean".equalsIgnoreCase(var6) || "Int".equalsIgnoreCase(var6)
						|| "Double".equalsIgnoreCase(var6)) {
					((EStructuralFeature) var19).setUnsettable(true);
				}
			} else {
				EClass var20 = this.getEClass(var6);
				if (var20 == null) {
					throw new InvalidSchemaException("REFERENCE_TYPE_NOT_FOUND",
							WIMMessageHelper.generateMsgParms(var6), CLASSNAME, "addPropertySchema");
				}

				var19 = var5.createEReference();
				((EStructuralFeature) var19).setEType(var20);
				((EReference) var19).setContainment(true);
			}

			ExtendedMetaData.INSTANCE.setFeatureKind((EStructuralFeature) var19, 4);
			((EStructuralFeature) var19).setName(var4);
			((EStructuralFeature) var19).setUnique(false);
			if (var26) {
				((EStructuralFeature) var19).setUpperBound(-1);
			} else {
				((EStructuralFeature) var19).setUpperBound(1);
			}

			boolean var30 = false;
			if (var16 != null && var16.size() > 0) {
				Iterator var21 = var16.iterator();

				while (var21.hasNext()) {
					if (var18.getName().equalsIgnoreCase((String) var21.next())) {
						((EStructuralFeature) var19).setLowerBound(1);
						var30 = true;
						break;
					}
				}

				if (!var30) {
					((EStructuralFeature) var19).setLowerBound(0);
				}
			}

			EClass var32 = this.getDocumentRoot("http://www.ibm.com/websphere/wim");
			var32.getEStructuralFeatures().add(var19);
			ExtendedMetaData.INSTANCE.setNamespace((EStructuralFeature) var19, var7);
			var18.getEStructuralFeatures().add(var19);
		}

		if (var2 != null) {
			DataObject var27 = DataGraphHelper.cloneDataObject(var1);
			List var28 = var27.getList("metaData");

			String var29;
			DataObject var31;
			for (var29 = ""; var28.size() != 0; var31.delete()) {
				var31 = (DataObject) var28.get(0);
				String var33 = var31.getString("name");
				if ("applicationId".equals(var33)) {
					var29 = (String) ((String) var31.getList("values").get(0));
				}
			}

			if (null != var29 && var29.trim().length() > 0) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "addPropertySchema",
							"The application Id of the extended property is " + var29);
				}

				var31 = var27.createDataObject("metaData");
				var31.set("name", "applicationId");
				var31.getList("values").add(var29.trim());
			}

			var2.getList("propertySchema").add(var27);
		}

		this.readPackage(this.getSchemaPackage(var7));
		synchronized (this) {
			this.iEntityProps.clear();
		}
	}

	private EClass getDocumentRoot(String var1) {
		EPackage var2 = this.getSchemaPackage(var1);
		if (var2 != null) {
			EList var3 = var2.getEClassifiers();

			for (int var4 = 0; var4 < var3.size(); ++var4) {
				Object var5 = var3.get(var4);
				if (var5 instanceof EClass) {
					EClass var6 = (EClass) var5;
					String var7 = var6.getName();
					if ("DocumentRoot".equals(var7)) {
						return var6;
					}
				}
			}
		}

		return null;
	}

	private void loadModelFromExtXML(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "loadModelFromExtXML", var1);
		}

		DataObject var3 = this.getWimXmlExtXml(var1);
		if (null == var3) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "loadModelFromExtXML",
						"XML extension file " + var1 + " is not found. No extension will be added.");
			}

		} else {
			DataObject var4 = var3.getDataObject("schema");
			if (var4 != null) {
				List var5 = var4.getList("entitySchema");

				for (int var6 = 0; var6 < var5.size(); ++var6) {
					DataObject var7 = (DataObject) var5.get(var6);
					this.addEntitySchema(var7, (DataObject) null);
				}

				List var9 = var4.getList("propertySchema");

				for (int var10 = 0; var10 < var9.size(); ++var10) {
					DataObject var8 = (DataObject) var9.get(var10);
					this.addPropertySchema(var8, (DataObject) null);
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "loadModelFromExtXML");
			}

		}
	}

	private DataObject postGetSchema(DataObject var1, DataObject var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "postGetSchema");
		}

		String var4 = AsyncUtils.getPostProcessing(var2);
		if (var4 != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "postGetSchema", "postProcess str=" + var4);
			}

			String var5 = null;
			String var6 = null;
			String var7 = null;
			if (var4.indexOf(":") < 0) {
				var5 = var4;
			} else {
				StringTokenizer var8 = new StringTokenizer(var4, ":");
				var5 = var8.nextToken();
				var6 = var8.nextToken();
				var7 = var8.nextToken();
			}

			if (var5.equals("appendPropertySchema")) {
				this.appendPropertySchema(var6, var7, var1);
			} else if (var5.equals("appendEntityTypeSchema")) {
				this.appendEntityTypeSchema(var1);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "postGetSchema");
		}

		return var1;
	}

	public DataObject getSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getSchema");
		}

		ProfileSecurityManager var3 = ProfileSecurityManager.singleton();
		var3.checkPermission_SuperUser(new Entitlement("GET", "SCHEMA"));
		DataObject var4 = this.createRootDataObject();
		if (AsyncUtils.isCheckAsyncOperationStatus(var1)) {
			String var18 = AsyncUtils.getRepositoryId(var1);
			var4 = this.getSchemaForRepository(var18, var1, var4);
			if (AsyncUtils.isOperationComplete(var4)) {
				var4 = this.postGetSchema(var4, var1);
			} else {
				AsyncUtils.setPostProcessing(var4, var1);
			}

			if (var4 != null) {
				this.addRequiredEntityTypeForRDN(var4);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "getSchema", WIMTraceHelper.printDataGraph(var4));
				}

				return var4;
			} else {
				throw new WIMApplicationException("INVALID_DATA_OBJECT", CLASSNAME, "getSchema");
			}
		} else {
			Map var5 = ControlsHelper.getControlMap(var1);
			DataObject var6 = (DataObject) var5.get("DataTypeControl");
			DataObject var7 = (DataObject) var5.get("ExtensionPropertyDataTypeControl");
			DataObject var8 = (DataObject) var5.get("PropertyDefinitionControl");
			DataObject var9 = (DataObject) var5.get("ExtensionPropertyDefinitionControl");
			DataObject var10 = (DataObject) var5.get("EntityTypeControl");
			String var11;
			int var13;
			List var20;
			if (var6 != null) {
				var11 = var6.getString("repositoryId");
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getSchema",
							"DataTypeControl is specified with repositoryId=" + var11);
				}

				if (var11 != null && var11.length() != 0) {
					var4 = this.getSchemaForRepository(var11, var1, var4);
				} else {
					var4 = this.createRootDataObject();
					DataObject var21 = var4.createDataObject("schema");
					this.getSupportedDataTypes(var21);
				}
			} else if (var7 != null) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getSchema", "LookasideDataTypeControl is specified.");
				}

				if (!RepositoryManager.singleton(false).isPropertyJoin()) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "getSchema",
								"Property join is not turned on while LookasideDataTypeControl is specified.");
					}

					throw new WIMApplicationException("PROPERTY_EXTENSION_REPOSITORY_NOT_DEFINED", CLASSNAME,
							"getSchema");
				}

				var4 = RepositoryManager.singleton(false).getLookasideRepository().getSchema(var1);
			} else {
				String var14;
				String var15;
				if (var10 != null) {
					var11 = var10.getString("repositoryId");
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "getSchema",
								"EntityTypeControl is specified with repositoryId=" + var11);
					}

					var20 = var10.getList("entityTypeNames");
					if (var20 != null && var20.size() > 0) {
						for (var13 = 0; var13 < var20.size(); ++var13) {
							var14 = (String) var20.get(var13);
							var15 = null;
							int var16 = var14.indexOf(":");
							if (var16 > 1) {
								var15 = var14.substring(0, var16);
								String var17 = this.getNsURI(var15);
								if (var17 == null) {
									throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
											WIMMessageHelper.generateMsgParms(var14), CLASSNAME, "getSchema");
								}
							}

							EClass var27 = this.getEClass(var14);
							if (var27 == null) {
								throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
										WIMMessageHelper.generateMsgParms(var14), CLASSNAME, "getSchema");
							}
						}
					}

					if (var11 != null && var11.length() != 0) {
						var4 = this.getSchemaForRepository(var11, var1, var4);
					} else {
						var4 = this.getSupportedEntityTypes(var10);
					}

					if (AsyncUtils.isOperationComplete(var4)) {
						this.appendEntityTypeSchema(var4);
					} else {
						AsyncUtils.setPostProcessing(var4, "appendEntityTypeSchema");
					}
				} else {
					String var12;
					if (var8 != null) {
						var11 = var8.getString("repositoryId");
						var12 = var8.getString("entityTypeName");
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "getSchema",
									"PropertyDefinitionControl is specified with repositoryId=" + var11
											+ ", entityTypeName=" + var12);
						}

						if (var12 == null || var12.trim().length() == 0) {
							throw new WIMApplicationException("MISSING_MANDATORY_PROPERTY",
									WIMMessageHelper.generateMsgParms("entityTypeName"), CLASSNAME, "getSchema");
						}

						String var22 = null;
						int var24 = var12.indexOf(":");
						if (var24 > 1) {
							var22 = var12.substring(0, var24);
							var15 = this.getNsURI(var22);
							if (var15 == null) {
								throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
										WIMMessageHelper.generateMsgParms(var12), CLASSNAME, "getSchema");
							}
						}

						EClass var26 = this.getEClass(var12);
						if (var26 == null) {
							throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
									WIMMessageHelper.generateMsgParms(var12), CLASSNAME, "getSchema");
						}

						if (var11 != null && var11.length() != 0) {
							var4 = this.getSchemaForRepository(var11, var1, var4);
						} else {
							var4 = this.getPropertySchema(var8);
						}

						if (var4 != null) {
							this.addRequiredEntityTypeForNonRDN(var8, var4);
						}

						if (AsyncUtils.isOperationComplete(var4)) {
							this.appendPropertySchema("propertySchema", var12, var4);
						} else {
							AsyncUtils.setPostProcessing(var4, "appendPropertySchema:propertySchema:" + var12);
						}
					} else if (var9 != null) {
						var11 = var9.getString("entityTypeName");
						if (var11 == null || var11.trim().length() == 0) {
							throw new WIMApplicationException("MISSING_MANDATORY_PROPERTY",
									WIMMessageHelper.generateMsgParms("entityTypeName"), CLASSNAME, "getSchema");
						}

						var12 = null;
						var13 = var11.indexOf(":");
						if (var13 > 1) {
							var12 = var11.substring(0, var13);
							var14 = this.getNsURI(var12);
							if (var14 == null) {
								throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
										WIMMessageHelper.generateMsgParms(var11), CLASSNAME, "getSchema");
							}
						}

						EClass var23 = this.getEClass(var11);
						if (var23 == null) {
							throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
									WIMMessageHelper.generateMsgParms(var11), CLASSNAME, "getSchema");
						}

						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "getSchema",
									"LookasideDataTypeControl is specified.");
						}

						if (!RepositoryManager.singleton(false).isPropertyJoin()) {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "getSchema",
										"Property join is not turned on while LookasidePropertyDefinitionControl is specified.");
							}

							throw new WIMApplicationException("PROPERTY_EXTENSION_REPOSITORY_NOT_DEFINED", CLASSNAME,
									"getSchema");
						}

						var4 = RepositoryManager.singleton(false).getLookasideRepository().getSchema(var1);
						if (AsyncUtils.isOperationComplete(var4)) {
							this.appendPropertySchema("extensionPropertySchema", var11, var4);
						}
					}
				}
			}

			DataObject var19 = var4.getDataObject("schema");
			if (var19 != null) {
				var20 = var19.getList("propertySchema");
				if (var20 != null && var20.size() > 0) {
					for (var13 = 0; var13 < var20.size(); ++var13) {
						DataObject var25 = (DataObject) var20.get(var13);
						if ("ibmPrimaryEmail".equals(var25.getString("propertyName"))) {
							var25.setString("propertyName", "ibm-primaryEmail");
							var25.setString("dataType", "String");
							var25.setString("multiValued", "false");
						} else if ("ibmJobTitle".equals(var25.getString("propertyName"))) {
							var25.setString("propertyName", "ibm-jobTitle");
							var25.setString("dataType", "String");
							var25.setString("multiValued", "true");
						}
					}
				}
			}

			if (var4 != null) {
				this.addRequiredEntityTypeForRDN(var4);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "getSchema", WIMTraceHelper.printDataGraph(var4));
				}

				return var4;
			} else {
				throw new WIMApplicationException("INVALID_DATA_OBJECT", CLASSNAME, "getSchema");
			}
		}
	}

	private void addRequiredEntityTypeForRDN(DataObject var1) {
		if (var1 != null) {
			DataObject var2 = var1.getDataObject("schema");
			if (var2 != null) {
				List var3 = var2.getList("propertySchema");
				if (var3 != null) {
					List var4 = this.iConfigMgr.getSupportedEntityTypes();
					HashMap var5 = new HashMap();

					int var6;
					String var7;
					List var8;
					for (var6 = 0; var6 < var4.size(); ++var6) {
						var7 = (String) var4.get(var6);
						var8 = this.iConfigMgr.getRDNProperties(var7);
						if (var8 != null && var8.size() > 0) {
							Object var9 = (List) var5.get((String) var8.get(0));
							if (var9 == null) {
								var9 = new ArrayList();
								var5.put((String) var8.get(0), var9);
							}

							((List) var9).add(var7);
						}
					}

					for (var6 = 0; var6 < var3.size(); ++var6) {
						var7 = ((DataObject) var3.get(var6)).getString("propertyName");
						if (var5.containsKey(var7)) {
							var8 = (List) var5.get(var7);
							List var10 = ((DataObject) var3.get(var6)).getList("requiredEntityTypeNames");
							var8.removeAll(var10);
							var10.addAll(var8);
						}
					}
				}
			}
		}

	}

	private void appendEntityTypeSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "appendEntityTypeSchema");
		}

		if (var1 != null) {
			DataObject var3 = var1.getDataObject("schema");
			if (var3 != null) {
				List var4 = var3.getList("entitySchema");
				if (var4 != null && var4.size() > 0) {
					for (int var5 = 0; var5 < var4.size(); ++var5) {
						DataObject var6 = (DataObject) var4.get(var5);
						String var7 = var6.getString("entityName");
						String var8 = var6.getString("nsURI");
						if (var7 == null || var7.length() == 0) {
							throw new WIMApplicationException("MISSING_MANDATORY_PROPERTY",
									WIMMessageHelper.generateMsgParms("entityName"), CLASSNAME,
									"appendEntityTypeSchema");
						}

						EClass var9 = this.getEClass(this.getQualifiedTypeName(var8, var7));
						if (var9 == null) {
							throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
									WIMMessageHelper.generateMsgParms(var7), CLASSNAME, "appendEntityTypeSchema");
						}

						EList var10 = var9.getESuperTypes();
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "appendEntityTypeSchema",
									"get super types [" + var7 + "]: [" + var10 + "]");
						}

						if (var10 != null && var10.size() > 0) {
							EClass var11 = (EClass) var10.get(0);
							String var12 = var11.getName();
							String var13 = var11.getEPackage().getNsURI();
							String var14 = this.getQualifiedTypeName(var13, var12);
							var6.setString("parentEntityName", var14);
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "appendEntityTypeSchema",
										"set super types : [" + var14 + "]");
							}
						} else if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "appendEntityTypeSchema",
									"no super type retrieved. ");
						}
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "appendEntityTypeSchema");
		}

	}

	private void appendPropertySchema(String var1, String var2, DataObject var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "appendPropertySchema");
		}

		EClass var5 = this.getEClass(var2);
		if (var5 == null) {
			throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED", WIMMessageHelper.generateMsgParms(var2),
					CLASSNAME, "appendPropertySchema");
		} else {
			if (var3 != null) {
				DataObject var6 = var3.getDataObject("schema");
				if (var6 != null) {
					List var7 = var6.getList(var1);
					if (var7 != null && var7.size() > 0) {
						for (int var8 = 0; var8 < var7.size(); ++var8) {
							DataObject var9 = (DataObject) var7.get(var8);
							String var10 = var9.getString("propertyName");
							if (var10 == null || var10.length() == 0) {
								throw new WIMApplicationException("MISSING_MANDATORY_PROPERTY",
										WIMMessageHelper.generateMsgParms("propertyName"), CLASSNAME,
										"appendPropertySchema");
							}

							String var11 = var9.getString("nsURI");
							String var12 = this.getNsPrefix(var11);
							String var13 = this.getQualifiedTypeName(var9.getString("nsURI"), var10);
							Property var14 = this.getProperty(var2, var13);
							if (var14 != null) {
								if (var14.isMany()) {
									var9.setBoolean("multiValued", true);
								} else {
									var9.setBoolean("multiValued", false);
								}

								var9.setString("dataType", var14.getType().getName());
								var9.setString("nsPrefix", var12);
								var9.setString("nsURI", var11);
							}
						}
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "appendPropertySchema");
			}

		}
	}

	private DataObject getSupportedEntityTypes(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getSupportedEntityTypes");
		}

		DataObject var3 = this.createRootDataObject();
		DataObject var4 = var3.createDataObject("schema");
		String var5 = null;
		String var6 = null;
		List var7 = var1.getList("entityTypeNames");
		if (var7 != null && var7.size() != 0) {
			for (int var13 = 0; var13 < var7.size(); ++var13) {
				String var14 = (String) var7.get(var13);
				DataObject var12 = var4.createDataObject("entitySchema");
				var5 = this.getTypeNsURI(var14);
				var6 = this.getNsPrefix(var5);
				var12.setString("entityName", this.getTypeName(var14));
				var12.setString("nsURI", var5);
				var12.setString("nsPrefix", var6);
			}
		} else {
			Set var8 = this.getSubEntityTypes("Entity");
			if (var8 != null) {
				Iterator var9 = var8.iterator();

				while (var9.hasNext()) {
					String var10 = (String) var9.next();
					DataObject var11 = var4.createDataObject("entitySchema");
					var5 = this.getTypeNsURI(var10);
					var6 = this.getNsPrefix(var5);
					var11.setString("entityName", this.getTypeName(var10));
					var11.setString("nsURI", var5);
					var11.setString("nsPrefix", var6);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getSupportedEntityTypes");
		}

		return var3;
	}

	private DataObject getPropertySchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getPropertySchema");
		}

		DataObject var3 = this.createRootDataObject();
		DataObject var4 = var3.createDataObject("schema");
		String var5 = var1.getString("entityTypeName");
		if (var5 != null && var5.length() != 0) {
			if (var5.startsWith("wim:")) {
				var5 = this.getTypeName(var5);
			}

			List var6 = this.getProperties(var5);
			String var7 = null;
			List var8 = var1.getList("propertyNames");
			String var11;
			String var12;
			DataObject var13;
			if (var8 != null && var8.size() != 0) {
				if (var6 != null) {
					List var14 = this.getQualifiedPropertyNames(var6);

					for (int var15 = 0; var15 < var8.size(); ++var15) {
						var7 = (String) var8.get(var15);
						if (var7.startsWith("wim:")) {
							var7 = this.getTypeName(var7);
						}

						if (!var14.contains(var7)) {
							throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
									WIMMessageHelper.generateMsgParms(var7, var5), CLASSNAME, "getPropertySchema");
						}

						var11 = this.getTypeNsURI(var7);
						var12 = this.getNsPrefix(var11);
						var13 = var4.createDataObject("propertySchema");
						var13.setString("propertyName", this.getTypeName(var7));
						var13.setString("nsURI", var11);
						var13.setString("nsPrefix", var12);
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "getPropertySchema", "append property schema: " + var8);
					}
				}
			} else {
				for (int var9 = 0; var9 < var6.size(); ++var9) {
					Property var10 = (Property) var6.get(var9);
					var7 = this.getQualifiedPropertyName(var10);
					var11 = this.getTypeNsURI(var7);
					var12 = this.getNsPrefix(var11);
					var13 = var4.createDataObject("propertySchema");
					var13.setString("propertyName", this.getTypeName(var7));
					var13.setString("nsURI", var11);
					var13.setString("nsPrefix", var12);
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getPropertySchema", "append property schema: " + var6);
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getPropertySchema");
			}

			return var3;
		} else {
			throw new WIMApplicationException("MISSING_MANDATORY_PROPERTY",
					WIMMessageHelper.generateMsgParms("entityTypeName"), CLASSNAME, "getPropertySchema");
		}
	}

	private DataObject getDataTypesFromSchema() throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getDataTypesFromSchema");
		}

		DataObject var2 = this.createRootDataObject();
		DataObject var3 = var2.createDataObject("schema");
		HashSet var4 = new HashSet();
		Set var5 = this.getSubEntityTypes("wim:Entity");
		Iterator var6 = var5.iterator();

		String var7;
		while (var6.hasNext()) {
			var7 = (String) var6.next();
			List var8 = this.getProperties(var7);

			for (int var9 = 0; var9 < var8.size(); ++var9) {
				Property var10 = (Property) var8.get(var9);
				String var11 = var10.getType().getName();
				var4.add(var11);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "getDataTypesFromSchema", "cached datatypes [" + var4 + "]. ");
		}

		var6 = var4.iterator();

		while (var6.hasNext()) {
			var7 = (String) var6.next();
			var3.getList("propertyDataTypes").add(var7);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getDataTypesFromSchema");
		}

		return var2;
	}

	public DataObject createSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createSchema", WIMTraceHelper.printDataObject(var1));
		}

		ProfileSecurityManager var3 = ProfileSecurityManager.singleton();
		var3.checkPermission_SuperUser(new Entitlement("CREATE", "SCHEMA"));
		if (EnvironmentManager.singleton().isSchemaUpdateNotAllowed()) {
			throw new DynamicUpdateConfigException("DYNAMIC_RELOAD_INVALID_UPDATE_AT_MANAGED_NODE", CLASSNAME,
					"createSchema");
		} else {
			DataObject var4 = null;
			if (var1 != null && (var4 = var1.getDataObject("schema")) != null) {
				this.validateSchemaAttributes(var4);
				var4 = DataGraphHelper.cloneDataObject(var4);
				if (this.iXMLExtDG == null) {
					this.iXMLExtDG = SDOFactory.eINSTANCE.createEDataGraph();
					this.iXMLExtDG.createRootObject("http://www.ibm.com/websphere/wim", "DocumentRoot");
					if (this.useGlobalSchema) {
						globalXMLExtDG = this.iXMLExtDG;
						globalExtXMLLoaded = true;
					}
				}

				DataObject var5 = this.iXMLExtDG.getRootObject().getDataObject("schema");
				if (var5 == null) {
					var5 = this.iXMLExtDG.getRootObject().createDataObject("schema");
				}

				List var6 = var4.getList("entitySchema");
				List var7 = var4.getList("propertySchema");
				List var8 = var4.getList("extensionPropertySchema");
				Object var9 = null;
				DataObject var10 = null;
				if (var6.size() > 0) {
					var10 = (DataObject) var6.get(0);
				} else if (var7.size() > 0) {
					var10 = (DataObject) var7.get(0);
				} else {
					if (var8.size() <= 0) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.exiting(CLASSNAME, "createSchema");
						}

						return var1;
					}

					var10 = (DataObject) var8.get(0);
				}

				var9 = var10.getList("repositoryIds");
				int var12;
				if (((List) var9).size() == 0) {
					String[] var11 = RepositoryManager.singleton().getRepositoryIds();
					var9 = new ArrayList(var11.length);

					for (var12 = 0; var12 < var11.length; ++var12) {
						((List) var9).add(var11[var12]);
					}
				}

				if (var6.size() > 0) {
					this.addEntitySchema(var10, var5);
				} else if (var7.size() > 0 || var8.size() > 0) {
					if (var7.size() > 0) {
						this.validateDBRepositoryPropertySchemaAttributes(var10, (List) var9);
					} else {
						this.validateLAPropertySchemaAttributes(var10, (List) var9);
					}

					this.addPropertySchema(var10, var5);
				}

				this.iConfigMgr.createSchema(var1);
				ArrayList var19 = new ArrayList(((List) var9).size());
				if (var6.size() <= 0 && var7.size() <= 0) {
					if (var8.size() > 0) {
						RepositoryManager.singleton().getLookasideRepository().createSchema(var1);
						ProfileManager.singleton().invalidLAProperties();
					}
				} else {
					for (var12 = 0; var12 < ((List) var9).size(); ++var12) {
						String var13 = (String) ((List) var9).get(var12);
						Repository var14 = RepositoryManager.singleton().getRepository(var13);

						try {
							var14.createSchema(var1);
							var19.add(var13);
						} catch (WIMException var18) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "createSchema", "Repository '" + var13
										+ "' does not support creating new schema: " + var18.toString());
							}
						}
					}
				}

				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "createSchema", "repositoryIds=" + var19);
				}

				String var20 = null;

				try {
					List var21 = ConfigManager.singleton().getRepsoitoryIds();
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createSchema", "all reposIds=" + var21);
					}

					for (int var24 = 0; var24 < var21.size(); ++var24) {
						var20 = (String) var21.get(var24);
						DataObject var15 = ConfigManager.singleton().getRepositoryDataObject(var20);
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME, "createSchema",
									"reposId=" + var20 + ", type=" + var15.getType().getName());
						}

						if (!var19.contains(var20) && "FileRepositoryType".equals(var15.getType().getName())) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "createSchema",
										"Calling createSchema on File Repository '" + var20
												+ "' so that it can reload the file registry data.");
							}

							Repository var16 = RepositoryManager.singleton().getRepository(var20);
							var16.createSchema(var1);
						}
					}
				} catch (WIMException var17) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createSchema",
								"Repository '" + var20 + "' does not support creating new schema: " + var17.toString());
					}
				}

				if (var19.size() > 0) {
					DataObject var22 = var1.getDataObject("schema");
					DataObject var25 = null;
					List var26 = var22.getList("propertySchema");
					if (var26.size() > 0) {
						var25 = (DataObject) var26.get(0);
					} else {
						List var27 = var22.getList("entitySchema");
						if (var27.size() > 0) {
							var25 = (DataObject) var27.get(0);
						}
					}

					if (var25 != null) {
						var25.unset("repositoryIds");
						var25.getList("repositoryIds").addAll(var19);
					}
				}

				EDataGraph var23 = SDOFactory.eINSTANCE.createEDataGraph();
				var23.createRootObject("http://www.ibm.com/websphere/wim", "DocumentRoot");
				var23.getRootObject().setDataObject("schema", DataGraphHelper.cloneDataObject(var5));
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "createSchema",
							"Saving into " + this.iXMLExtFilePath + "." + WIMTraceHelper.printDataGraph(var23));
				}

				DataGraphHelper.saveDataGraph(var23, this.iXMLExtFilePath);
				ProfileManager.singleton().initializePropertyCache();
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "createSchema", WIMTraceHelper.printDataObject(var1));
				}

				return var1;
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "createSchema",
							"Null DataObject or no schema present in the dataobject.");
				}

				return var1;
			}
		}
	}

	public void validateSchemaAttributes(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateSchemaAttributes");
		}

		List var3 = var1.getList("entitySchema");
		if (var3.size() > 1) {
			throw new InvalidSchemaException("CAN_NOT_CREATE_MULTIPLE_ENTITY_TYPES", CLASSNAME,
					"validateSchemaAttributes");
		} else {
			List var4 = var1.getList("propertySchema");
			List var5 = var1.getList("extensionPropertySchema");
			if (var4.size() <= 1 && var5.size() <= 1 && (var4.size() <= 0 || var5.size() <= 0)) {
				if (var3.size() > 0 && (var4.size() > 0 || var5.size() > 0)) {
					throw new InvalidSchemaException("CAN_NOT_CREATE_BOTH_ENTITY_AND_PROPERTY", CLASSNAME,
							"validateSchemaAttributes");
				} else {
					DataObject var6 = null;
					if (var3.size() > 0) {
						var6 = (DataObject) var3.get(0);
					} else if (var4.size() > 0) {
						var6 = (DataObject) var4.get(0);
					} else {
						if (var5.size() <= 0) {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.exiting(CLASSNAME, "validateSchemaAttributes");
							}

							return;
						}

						if (!RepositoryManager.singleton().isPropertyJoin()) {
							throw new DynamicUpdateConfigException("PROPERTY_EXTENSION_REPOSITORY_NOT_DEFINED",
									CLASSNAME, "validateSchemaAttributes");
						}

						var6 = (DataObject) var5.get(0);
					}

					List var7 = var6.getList("repositoryIds");
					if (var7 != null) {
						for (int var8 = 0; var8 < var7.size(); ++var8) {
							String var9 = (String) var7.get(var8);
							if (RepositoryManager.singleton().getRepository(var9) == null) {
								throw new InvalidRepositoryIdException("INVALID_REPOSITORY_ID",
										WIMMessageHelper.generateMsgParms(var9), CLASSNAME, "validateSchemaAttributes");
							}
						}
					}

					if (var3.size() > 0) {
						this.validateEnityTypeSchemaAttributes(var6);
					} else if (var4.size() > 0 || var5.size() > 0) {
						this.validatePropertyTypeSchemaAttributes(var6);
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "validateSchemaAttributes");
					}

				}
			} else {
				throw new InvalidSchemaException("CAN_NOT_CREATE_MULTIPLE_PROPERTY_TYPES", CLASSNAME,
						"validateSchemaAttributes");
			}
		}
	}

	private void validateWellFormedNessOfNsuriIfNullNsPrefix(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateWellFormedNessOfNsuriIfNullNsPrefix",
					"nsURI=" + var1 + ", nsPrefix=" + var2);
		}

		if ((var1 != null || var1.length() > 0) && (var2 == null || var2.length() == 0)) {
			var2 = this.getNsPrefix(var1);
			if (var2 == null) {
				String var4 = (new String(var1)).trim();

				try {
					var2 = var4.substring(var4.lastIndexOf("/") + 1);
				} catch (Exception var6) {
					;
				}

				if (var2 == null || var2.length() == 0) {
					throw new InvalidSchemaException("INVALID_NS_URI", CLASSNAME,
							"validateWellFormedNessOfNsuriIfNullNsPrefix");
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "validateWellFormedNessOfNsuriIfNullNsPrefix");
		}

	}

	private void validateDBPropertySchemaAttributes(DataObject var1, List var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateDBPropertySchemaAttributes", "reqReposIds=" + var2);
		}

		boolean var4 = false;
		String var5 = var1.getString("propertyName");
		List var6 = var1.getList("metaData");
		String var7 = var1.getString("dataType");
		DBDataType var8 = DAOHelper.getDBDataTypeFromCommonDataType(var7);
		String var9 = null;

		int var10;
		DataObject var11;
		String var12;
		for (var10 = 0; var10 < var2.size(); ++var10) {
			var9 = (String) var2.get(var10);
			if ("LA".equals(var9)) {
				var4 = true;
				break;
			}

			var11 = RepositoryManager.singleton().getRepositoryConfig(var9);
			var12 = var11.getType().getName();
			if ("DatabaseRepositoryType".equals(var12)) {
				var4 = true;
				break;
			}
		}

		if (!var4) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateDBPropertySchemaAttributes", "isRepoTypeDB=" + var4);
			}

		} else if (!"OBJECT".equalsIgnoreCase(var8.getDatatype())
				|| var8.getClassname() != null && var8.getClassname().length() != 0) {
			for (var10 = 0; var10 < var6.size(); ++var10) {
				var11 = (DataObject) var6.get(var10);
				var12 = var11.getString("name");
				String var13 = (String) ((String) var11.getList("values").get(0));
				if ("isComposite".equals(var12) && Boolean.valueOf(var13)) {
					throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
							WIMMessageHelper.generateMsgParms(var9 + "|" + "isComposite"), CLASSNAME,
							"validateDBPropertySchemaAttributes");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateDBPropertySchemaAttributes");
			}

		} else {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "validateDBPropertySchemaAttributes",
						"className=" + var8.getClassname());
			}

			throw new InvalidPropertyDefinitionException("INVALID_PROPERTY_DATA_TYPE",
					WIMMessageHelper.generateMsgParms(var5), CLASSNAME, "validateDBPropertySchemaAttributes");
		}
	}

	private void validateLAPropertySchemaAttributes(DataObject var1, List var2) throws WIMException {
		ArrayList var3 = new ArrayList();
		if (var2 != null) {
			var3.addAll(var2);
		}

		if (!var3.contains("LA")) {
			var3.add("LA");
		}

		this.validateDBPropertySchemaAttributes(var1, var3);
	}

	private void validateDBRepositoryPropertySchemaAttributes(DataObject var1, List var2) throws WIMException {
		this.validateDBPropertySchemaAttributes(var1, var2);
	}

	private void validateEnityTypeSchemaAttributes(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateEnityTypeSchemaAttributes");
		}

		String var3 = var1.getString("entityName");
		if (var3 != null && var3.length() != 0) {
			String var4 = var1.getString("nsURI");
			this.validateWellFormedNessOfNsuriIfNullNsPrefix(var4, var1.getString("nsPrefix"));
			if (this.getEClass(var3, var4) != null) {
				throw new SchemaAlreadyExistException("ENTITY_TYPE_ALREADY_DEFINED",
						WIMMessageHelper.generateMsgParms(var3, var4), CLASSNAME, "validateEnityTypeSchemaAttributes");
			} else {
				String var5 = var1.getString("parentEntityName");
				EClass var6 = this.getEClass(var5);
				if (var6 == null) {
					throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
							WIMMessageHelper.generateMsgParms(var5), CLASSNAME, "validateEnityTypeSchemaAttributes");
				} else {
					List var7 = var1.getList("properties");

					for (int var8 = 0; var8 < var7.size(); ++var8) {
						DataObject var9 = (DataObject) var7.get(var8);
						String var10 = var9.getString("name");
						if (this.getProperty(var3, var10) != null) {
							throw new SchemaAlreadyExistException("PROPERTY_TYPE_ALREADY_DEFINED",
									WIMMessageHelper.generateMsgParms(var10, var3), CLASSNAME,
									"validateEnityTypeSchemaAttributes");
						}

						EStructuralFeature var11 = XSDHelper.getGlobalFeature(var10);
						if (var11 == null) {
							throw new InvalidSchemaException("PROPERTY_NOT_DEFINED",
									WIMMessageHelper.generateMsgParms(var10), CLASSNAME,
									"validateEnityTypeSchemaAttributes");
						}
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "validateEnityTypeSchemaAttributes");
					}

				}
			}
		} else {
			throw new WIMApplicationException("MISSING_MANDATORY_PROPERTY",
					WIMMessageHelper.generateMsgParms("entityName"), CLASSNAME, "validateEnityTypeSchemaAttributes");
		}
	}

	private void validatePropertyTypeSchemaAttributes(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validatePropertyTypeSchemaAttributes");
		}

		String var3 = var1.getString("propertyName");
		if (var3 != null && var3.length() != 0) {
			String var4 = var1.getString("dataType");
			String var5 = var1.getString("nsURI");
			String var6 = var1.getString("nsPrefix");
			this.validateWellFormedNessOfNsuriIfNullNsPrefix(var5, var6);
			boolean var7 = false;
			var7 = this.addTempPrefixToURIMap(var6, var5);
			String var8 = this.getQualifiedTypeName(var5, var3);
			List var9 = var1.getList("applicableEntityTypeNames");

			for (int var10 = 0; var10 < var9.size(); ++var10) {
				String var11 = (String) var9.get(var10);
				EClass var12 = this.getEClass(var11);
				if (var12 == null) {
					throw new InvalidEntityTypeException("ENTITY_TYPE_NOT_SUPPORTED",
							WIMMessageHelper.generateMsgParms(var11), CLASSNAME,
							"validatePropertyTypeSchemaAttributes");
				}

				if (this.getProperty(var11, var8) != null) {
					throw new SchemaAlreadyExistException("PROPERTY_TYPE_ALREADY_DEFINED",
							WIMMessageHelper.generateMsgParms(var8, var11), CLASSNAME,
							"validatePropertyTypeSchemaAttributes");
				}
			}

			if (var7) {
				this.removeFromPrefixURIMap(var6);
			}

			EDataType var15 = this.getEDataType(var4);
			if (var15 == null) {
				EClass var16 = this.getEClass(var4);
				if (var16 == null) {
					throw new InvalidSchemaException("REFERENCE_TYPE_NOT_FOUND",
							WIMMessageHelper.generateMsgParms(var4), CLASSNAME, "validatePropertyTypeSchemaAttributes");
				}
			}

			List var17 = var1.getList("requiredEntityTypeNames");
			if (var17 != null) {
				List var18 = var1.getList("applicableEntityTypeNames");

				for (int var13 = 0; var13 < var17.size(); ++var13) {
					String var14 = (String) var17.get(var13);
					if (!var18.contains(var14)) {
						throw new InvalidPropertyDefinitionException("INVALID_PROPERTY_DEFINITION",
								WIMMessageHelper.generateMsgParms("requiredEntityTypeNames", var14, var3), CLASSNAME,
								"validatePropertyTypeSchemaAttributes");
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validatePropertyTypeSchemaAttributes");
			}

		} else {
			throw new WIMApplicationException("MISSING_MANDATORY_PROPERTY",
					WIMMessageHelper.generateMsgParms("propertyName"), CLASSNAME,
					"validatePropertyTypeSchemaAttributes");
		}
	}

	private void readPackage(EPackage var1) throws WIMApplicationException {
		String var3 = var1.getNsURI();
		String var4 = var1.getNsPrefix();
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "readPackage",
					"Package Name: " + var1.getName() + "\tPackage NSURI:" + var3 + "\tPreFix: " + var4);
		}

		EList var5 = var1.getEClassifiers();

		for (int var6 = 0; var6 < var5.size(); ++var6) {
			Object var7 = var5.get(var6);
			if (var7 instanceof EClass) {
				EClass var8 = (EClass) var7;
				String var9 = var8.getName();
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "readPackage", "\tClass Name: " + var9);
				}

				EList var10 = var8.getEAllStructuralFeatures();

				for (int var11 = 0; var11 < var10.size(); ++var11) {
					EStructuralFeature var12 = (EStructuralFeature) var10.get(var11);
					String var13 = var12.getName();
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "readPackage", "\t\tStructural Feature: " + var12);
					}
				}
			}
		}

	}

	public String getQualifiedTypeName(String var1, String var2) {
		if (!"http://www.ibm.com/websphere/wim".equals(var1)) {
			String var3 = this.getNsPrefix(var1);
			return var3 != null ? var3 + ":" + var2 : var2;
		} else {
			return var2;
		}
	}

	public String getQualifiedTypeName(Type var1) {
		return this.getQualifiedTypeName(var1.getURI(), var1.getName());
	}

	public String getQualifedTypeName(EClass var1) {
		String var2 = ExtendedMetaData.INSTANCE.getNamespace(var1);
		String var3 = var1.getName();
		return this.getQualifiedTypeName(var2, var3);
	}

	public EClass getEClass(String var1, String var2) {
      if (var2 == null || var2.trim().length() == 0) {
         var2 = "http://www.ibm.com/websphere/wim";
      }

      EPackage var4 = (EPackage)AccessController.doPrivileged(new 1(this, var2));
      return var4 != null ? (EClass)var4.getEClassifier(var1) : null;
   }

	public boolean isSuperType(String var1, String var2) {
		EClass var3 = this.getEClass(var1);
		if (var3 != null) {
			EClass var4 = this.getEClass(var2);
			if (var4 != null) {
				return var3.isSuperTypeOf(var4);
			}
		}

		return false;
	}

	public String getSuperType(List var1, String var2) {
		if (var1.contains(var2)) {
			return var2;
		} else {
			EClass var3 = this.getEClass(var2);
			if (var3 != null) {
				for (var3 = (EClass) var3.getESuperTypes().iterator()
						.next(); var3 != null; var3 = var3.getESuperTypes().size() != 0
								? (EClass) var3.getESuperTypes().iterator().next()
								: null) {
					String var4 = this.getQualifedTypeName(var3);
					if (var1.contains(var4)) {
						return var4;
					}
				}
			}

			return null;
		}
	}

	public Set getSubEntityTypes(String var1) {
		Object var3 = (Set) this.iEntitySubTypes.get(var1);
		if (var3 == null) {
			var3 = new HashSet();
			EClass var4 = this.getEClass(var1);
			if (var4 == null) {
				trcLogger.logp(Level.FINER, CLASSNAME, "getSubEntityTypes",
						"EMF package is not visible.  Package will re-registered");
				this.reRegisterPackages();
				var4 = this.getEClass(var1);
			}

			if (var4 != null) {
				Iterator var5 = this.iPrefixToURI.keySet().iterator();

				while (var5.hasNext()) {
					String var6 = (String) var5.next();
					String var7 = (String) this.iPrefixToURI.get(var6);
					EPackage var8 = XSDHelper.getPackage(var7);
					if (var8 == null) {
						var8 = (EPackage) this.uriToSchema.get(var7);
						if (this.useGlobalSchema) {
							DomainManagerUtils.putPackageInEMFGlobalRegistryFromVMM(var7, var8);
						} else {
							DomainManagerUtils.putPackageInEMFDomainRegistryFromVMM(var7, var8);
						}
					}

					EList var9 = var8.getEClassifiers();

					for (int var10 = 0; var10 < var9.size(); ++var10) {
						Object var11 = var9.get(var10);
						if (var11 instanceof EClass) {
							EClass var12 = (EClass) var11;
							if (var4.isSuperTypeOf(var12) && !var4.equals(var12)) {
								((Set) var3).add(this.getQualifiedTypeName(var7, var12.getName()));
							}
						}
					}
				}

				this.iEntitySubTypes.put(var1, var3);
			}
		}

		return (Set) var3;
	}

	public List getProperties(String var1) {
		Object var2 = (List) this.iEntityProps.get(var1);
		if (var2 == null) {
			synchronized (this) {
				EClass var4 = this.getEClass(var1);
				if (var4 != null) {
					EList var5 = var4.getEAllStructuralFeatures();
					var2 = new ArrayList(var5.size());

					for (int var6 = 0; var6 < var5.size(); ++var6) {
						EStructuralFeature var7 = (EStructuralFeature) var5.get(var6);
						((List) var2).add(SDOUtil.adaptProperty(var7));
					}

					this.iEntityProps.put(var1, var2);
				}
			}
		}

		return (List) var2;
	}

	public List getPropertyNames(String var1) {
		ArrayList var2 = null;
		List var3 = this.getProperties(var1);
		if (var3 != null) {
			var2 = new ArrayList(var3.size());

			for (int var4 = 0; var4 < var3.size(); ++var4) {
				var2.add(((Property) var3.get(var4)).getName());
			}
		}

		return var2;
	}

	public List getProperties(Type var1) {
		String var2 = this.getQualifiedTypeName(var1.getURI(), var1.getName());
		return this.getProperties(var2);
	}

	public String getQualifiedPropertyName(Property var1) {
		return XSDHelper.getQualifiedPropertyName(var1);
	}

	public String getQualifiedPropertyName(EStructuralFeature var1) {
		return XSDHelper.getQualifiedPropertyName(var1);
	}

	public Property getProperty(Type var1, String var2) {
		String var3 = var1.getURI() + ":" + var1.getName() + ":" + var2;
		Property var4 = (Property) this.iProperties.get(var3);
		if (var4 == null) {
			String var5 = null;
			String var6 = null;
			int var7 = var2.indexOf(":");
			if (var7 > 1) {
				var5 = this.getNsURI(var2.substring(0, var7));
				var6 = var2.substring(var7 + 1);
			} else {
				var6 = var2;
			}

			var4 = XSDHelper.getLocalProperty(var1.getURI(), var1.getName(), var5, var6);
			if (var4 != null) {
				this.iProperties.put(var3, var4);
			}
		}

		return var4;
	}

	public Property getProperty(String var1, String var2) {
		String var3 = null;
		String var4 = null;
		int var5 = var2.indexOf(":");
		if (var5 > 1) {
			var3 = this.getNsURI(var2.substring(0, var5));
			var4 = var2.substring(var5 + 1);
		} else {
			var4 = var2;
		}

		String var6 = null;
		String var7 = null;
		var5 = var1.indexOf(":");
		if (var5 > 1) {
			var6 = this.getNsURI(var1.substring(0, var5));
			var7 = var1.substring(var5 + 1);
		} else {
			var7 = var1;
		}

		Property var8 = XSDHelper.getLocalProperty(var6, var7, var3, var4);
		if (var8 == null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "getProperty",
						"EMF package is not visible.  Package will re-registered");
			}

			this.reRegisterPackages();
			return XSDHelper.getLocalProperty(var6, var7, var3, var4);
		} else {
			return var8;
		}
	}

	public Property getProperty(EStructuralFeature var1) {
		return SDOUtil.adaptProperty(var1);
	}

	public EClass getEClass(String var1) {
		String var2 = null;
		String var3 = null;
		int var4 = var1.indexOf(":");
		if (var4 > 1) {
			var2 = var1.substring(0, var4);
			var3 = var1.substring(var4 + 1);
		} else {
			var3 = var1;
		}

		return this.getEClass(var3, this.getNsURI(var2));
	}

	public EClass getEClass(Type var1) {
		return this.getEClass(var1.getName(), var1.getURI());
	}

	private void reRegisterPackages() {
		Iterator var1 = this.uriToSchema.keySet().iterator();

		while (var1.hasNext()) {
			String var2 = (String) var1.next();
			if (Registry.INSTANCE.getEPackage(var2) == null) {
				if (this.useGlobalSchema) {
					DomainManagerUtils.putPackageInEMFGlobalRegistryFromVMM(var2,
							(EPackage) this.uriToSchema.get(var2));
				} else {
					DomainManagerUtils.putPackageInEMFDomainRegistryFromVMM(var2,
							(EPackage) this.uriToSchema.get(var2));
				}
			}
		}

	}

	public byte[] getEPackages(String var1) throws WIMException {
		String var2 = "getEPackages";

		try {
			org.eclipse.emf.ecore.resource.Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("ecore",
					new EcoreResourceFactoryImpl());
			ResourceSetImpl var3 = new ResourceSetImpl();
			Resource var4 = var3.createResource(URI.createURI(".ecore"));
			EPackage var6;
			if (var1 != null) {
				EPackage var5 = Registry.INSTANCE.getEPackage(var1);
				if (var5 == null) {
					var5 = (EPackage) this.uriToSchema.get(var1);
					if (var5 != null) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, var2, "Re-register package: " + var1);
						}

						if (this.useGlobalSchema) {
							DomainManagerUtils.putPackageInEMFGlobalRegistryFromVMM(var1, var5);
						} else {
							DomainManagerUtils.putPackageInEMFDomainRegistryFromVMM(var1, var5);
						}
					}
				}

				if (var5 == null) {
					throw new InvalidSchemaException("SCHEMA_PACKAGE_NOT_FOUND",
							WIMMessageHelper.generateMsgParms(var1), CLASSNAME, var2);
				}

				var4.getContents().add(var5);

				for (var6 = var5.getESuperPackage(); var6 != null; var6 = var6.getESuperPackage()) {
					var4.getContents().add(var6);
				}
			} else {
				for (Iterator var8 = this.uriToSchema.keySet().iterator(); var8.hasNext(); var4.getContents()
						.add(var6)) {
					var1 = (String) var8.next();
					var6 = (EPackage) this.uriToSchema.get(var1);
					if (Registry.INSTANCE.getEPackage(var1) == null) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, var2, "Re-register package: " + var1);
						}

						if (this.useGlobalSchema) {
							DomainManagerUtils.putPackageInEMFGlobalRegistryFromVMM(var1, var6);
						} else {
							DomainManagerUtils.putPackageInEMFDomainRegistryFromVMM(var1, var6);
						}
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, var2, "Returning package: " + var1);
					}
				}
			}

			ByteArrayOutputStream var9 = new ByteArrayOutputStream(2064);
			var4.save(var9, Collections.EMPTY_MAP);
			return var9.toByteArray();
		} catch (IOException var7) {
			throw new WIMApplicationException(var7.toString());
		}
	}

	public DataObject createRootDataObject() throws WIMException {
      try {
         return (DataObject)AccessController.doPrivileged(new 2(this));
      } catch (PrivilegedActionException var2) {
         if (var2.getCause() instanceof WIMException) {
            throw (WIMException)var2.getCause();
         } else {
            throw new WIMException(var2.getCause());
         }
      }
   }

	public DataObject createDataObject(String var1, String var2) {
		return SDOHelper.createDataObject(var1, var2);
	}

	public EPackage getSchemaPackage(String var1) {
		return XSDHelper.getPackage(var1);
	}

	public String getTypeNsURI(String var1) {
		String var2 = null;
		int var3 = var1.indexOf(":");
		if (var3 > 1) {
			var2 = var1.substring(0, var3);
		}

		return this.getNsURI(var2);
	}

	public DataObject createDataObject(DataObject var1, String var2, String var3) {
		return var1.createDataObject(var2, this.getTypeNsURI(var3), this.getTypeName(var3));
	}

	public String getTypeName(String var1) {
		int var2 = var1.indexOf(":");
		return var2 > 0 ? var1.substring(var2 + 1) : var1;
	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "dynamicUpdateConfig", "not implemented for SchemaManager.");
		}

	}

	private void addRequiredEntityTypeForNonRDN(DataObject var1, DataObject var2) {
		if (var2 != null) {
			String var3 = var1.getString("entityTypeName");
			if (var3.startsWith("wim:")) {
				var3 = this.getTypeName(var3);
			}

			DataObject var4 = var2.getDataObject("schema");
			if (var4 != null) {
				List var5 = var4.getList("propertySchema");
				if (var5 != null) {
					List var6 = this.getProperties(var3);

					for (int var7 = 0; var7 < var6.size(); ++var7) {
						Property var8 = (Property) var6.get(var7);
						String var9 = this.getQualifiedPropertyName(var8);
						EProperty var10 = (EProperty) var8;

						for (int var11 = 0; var11 < var5.size(); ++var11) {
							String var12 = ((DataObject) var5.get(var11)).getString("propertyName");
							String var13 = ((DataObject) var5.get(var11)).getString("nsURI");
							var12 = this.getQualifiedTypeName(var13, var12);
							if (var12.equals(var9) && var10.getEStructuralFeature().getLowerBound() > 0
									&& !this.iConfigMgr.isRDNProperty(var3, var9)) {
								ArrayList var14 = new ArrayList();
								var14.add(var3);
								List var15 = ((DataObject) var5.get(var11)).getList("requiredEntityTypeNames");
								var14.removeAll(var15);
								var15.addAll(var14);
							}
						}
					}
				}
			}
		}

	}

	public void getSupportedDataTypes(DataObject var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getSupportedDataTypes");
		}

		var1.getList("propertyDataTypes").add("String");
		var1.getList("propertyDataTypes").add("Int");
		var1.getList("propertyDataTypes").add("Boolean");
		var1.getList("propertyDataTypes").add("Long");
		var1.getList("propertyDataTypes").add("Double");
		var1.getList("propertyDataTypes").add("Base64binary");
		var1.getList("propertyDataTypes").add("AnySimpleType");
		var1.getList("propertyDataTypes").add("AnyURI");
		var1.getList("propertyDataTypes").add("Byte");
		var1.getList("propertyDataTypes").add("DateTime");
		var1.getList("propertyDataTypes").add("Date");
		var1.getList("propertyDataTypes").add("Short");
		var1.getList("propertyDataTypes").add("Token");
		var1.getList("propertyDataTypes").add("IdentifierType");
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getSupportedDataTypes");
		}

	}

	private DataObject getSchemaForRepository(String var1, DataObject var2, DataObject var3) throws WIMException {
		String var4 = "getSchemaForRepository";
		Repository var5 = null;

		try {
			var5 = RepositoryManager.singleton(false).getRepository(var1);
		} catch (WIMException var7) {
			msgLogger.logp(Level.WARNING, CLASSNAME, var4, "REPOSITORY_INITIALIZATION_FAILED",
					WIMMessageHelper.generateMsgParms(var1, var7.getMessage()));
		}

		if (var5 != null) {
			var3 = var5.getSchema(var2);
		}

		return var3;
	}

	public List getQualifiedPropertyNames(List var1) {
		ArrayList var2 = new ArrayList(var1.size());

		for (int var3 = 0; var3 < var1.size(); ++var3) {
			Property var4 = (Property) var1.get(var3);
			var2.add(this.getQualifiedPropertyName(var4));
		}

		return var2;
	}

	private static void initPackage(String var0) {
		String var1 = "initPackage";
		EPackage var2 = Registry.INSTANCE.getEPackage(var0);
		if (var2 != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, var1, "Package [ " + var0 + " ] [ " + var2 + " ]");
			}

			TreeIterator var3 = var2.eAllContents();

			while (var3.hasNext()) {
				Object var4 = var3.next();
				if (var4 instanceof EClassifier) {
					EClassifier var5 = (EClassifier) var4;
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, var1,
								"EClassifier [ " + var5.getName() + " ] [ " + var5 + " ]");
					}

					SDOUtil.adaptType(var5);
				} else if (var4 instanceof EStructuralFeature) {
					EStructuralFeature var6 = (EStructuralFeature) var4;
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, var1,
								"EStructuralFeature [ " + var6.getName() + " ] [ " + var6 + " ]");
					}

					SDOUtil.adaptProperty(var6);
				}
			}
		} else if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, var1, "Package not found [ " + var0 + " ]");
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = SchemaManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
		globalIprefixToURI = Collections.synchronizedMap(new HashMap(1));
		globalSchemaInited = false;
		globalExtXMLLoaded = false;
		globalUriToSchema = Collections.synchronizedMap(new HashMap(1));
		globalXMLExtDG = null;
		isAddSDOUtilAdapType = false;
		String var0 = System.getProperty("addEMFSDOUtilAdapType");
		isAddSDOUtilAdapType = var0 != null && Boolean.parseBoolean(var0);
		if (isAddSDOUtilAdapType) {
			initPackage("http://www.eclipse.org/emf/2002/Ecore");
			initPackage("http://www.eclipse.org/emf/2003/SDO");
		}

	}
}