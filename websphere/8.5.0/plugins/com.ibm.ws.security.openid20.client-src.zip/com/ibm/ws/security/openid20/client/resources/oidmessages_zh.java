package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_zh extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"security.openid20.client.authrequestfailed",
					"CWTAI3002E: OpenID 依赖方 (RP) 由于异常 [{0}] 而未能将用户重定向至OpenID 提供程序 (OP) 已进行认证。"},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: OpenID 依赖方 (RP) 未能初始化，因为它未能获取 WebSphere 服务器的缺省 SSLContext。异常为 [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: OpenID 依赖方 (RP) 由于异常 [{1}] 而未能连接至由标识 [{0}] 指定的 OpenID 提供程序 (OP)。"},
			{"security.openid20.client.initializationfailed", "CWTAI3005E: OpenID 依赖方 (RP) 由于异常 [{0}] 而未能初始化。"},
			{"security.openid20.client.invalidaxrequired", "CWTAI3009E: OpenID 依赖方 (RP) 未初始化，因为 [{0}] 属性的值格式不正确。"},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: OpenID 依赖方 (RP) 未能使用 Basic Auth 令牌对请求进行认证，因为令牌值无效。"},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: OpenID 依赖方 (RP) 未能初始化，因为 [{0}] 属性未正确指定。该属性应该是一个有效的 URL。"},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: OpenID 依赖方 (RP) 从 OpenID 提供程序 (OP) 接收到不正确的响应。此错误的原因是 [{0}]。"},
			{"security.openid20.client.maxcachesizereached", "CWTAI3012E: OpenID 依赖方 (RP) 未能执行认证，因为它达到了其内部高速缓存的最大容量。"},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: OpenID 依赖方 (RP) 由于缺少必需属性 axRequiredAttribute[n] 而未能初始化。至少需要定义一个属性。"},
			{"security.openid20.client.missingproperty", "CWTAI3001E: OpenID 依赖方 (RP) 未能初始化，因为必需属性 [{0}] 的值缺失或者为空。"},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: OpenID 依赖方 (RP) 需要 SSL (HTTPS) 但 OpenID 提供程序(OP) URL 为 HTTP: [{0}]。[{1}] 属性应该与目标 URL 方案匹配。"},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: OpenID 依赖方 (RP) 从不支持 OpenID 规范 V2 的 OpenID 提供程序接收到响应。"},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: OpenID 依赖方 (RP) 在从 OpenID 提供程序 (OP) 接收到的响应的验证期间失败。异常为 [{0}]。"}};

	public Object[][] getContents() {
		return resources;
	}
}