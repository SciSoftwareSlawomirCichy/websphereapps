package com.google.inject.spi;

import com.google.inject.ConfigurationException;
import com.google.inject.Inject;
import com.google.inject.Key;
import com.google.inject.TypeLiteral;
import com.google.inject.internal.Annotations;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.ImmutableList;
import com.google.inject.internal.ImmutableSet;
import com.google.inject.internal.Lists;
import com.google.inject.internal.MoreTypes;
import com.google.inject.internal.Nullability;
import com.google.inject.spi.InjectionPoint.Factory;
import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public final class InjectionPoint {
	private final boolean optional;
	private final Member member;
	private final ImmutableList<Dependency<?>> dependencies;

	private InjectionPoint(Member member, ImmutableList<Dependency<?>> dependencies, boolean optional) {
		this.member = member;
		this.dependencies = dependencies;
		this.optional = optional;
	}

	InjectionPoint(TypeLiteral<?> type, Method method) {
		this.member = method;
		Inject inject = (Inject) method.getAnnotation(Inject.class);
		this.optional = inject.optional();
		this.dependencies = this.forMember(method, type, method.getParameterAnnotations());
	}

	InjectionPoint(TypeLiteral<?> type, Constructor<?> constructor) {
		this.member = constructor;
		this.optional = false;
		this.dependencies = this.forMember(constructor, type, constructor.getParameterAnnotations());
	}

	InjectionPoint(TypeLiteral<?> type, Field field) {
		this.member = field;
		Inject inject = (Inject) field.getAnnotation(Inject.class);
		this.optional = inject.optional();
		Annotation[] annotations = field.getAnnotations();
		Errors errors = new Errors(field);
		Key key = null;

		try {
			key = Annotations.getKey(type.getFieldType(field), field, annotations, errors);
		} catch (ErrorsException var8) {
			errors.merge(var8.getErrors());
		}

		errors.throwConfigurationExceptionIfErrorsExist();
		this.dependencies = ImmutableList.of(this.newDependency(key, Nullability.allowsNull(annotations), -1));
	}

	private ImmutableList<Dependency<?>> forMember(Member member, TypeLiteral<?> type,
			Annotation[][] paramterAnnotations) {
		Errors errors = new Errors(member);
		Iterator<Annotation[]> annotationsIterator = Arrays.asList(paramterAnnotations).iterator();
		List<Dependency<?>> dependencies = Lists.newArrayList();
		int index = 0;
		Iterator i$ = type.getParameterTypes(member).iterator();

		while (i$.hasNext()) {
			TypeLiteral parameterType = (TypeLiteral) i$.next();

			try {
				Annotation[] parameterAnnotations = (Annotation[]) annotationsIterator.next();
				Key<?> key = Annotations.getKey(parameterType, member, parameterAnnotations, errors);
				dependencies.add(this.newDependency(key, Nullability.allowsNull(parameterAnnotations), index));
				++index;
			} catch (ErrorsException var12) {
				errors.merge(var12.getErrors());
			}
		}

		errors.throwConfigurationExceptionIfErrorsExist();
		return ImmutableList.copyOf(dependencies);
	}

	private <T> Dependency<T> newDependency(Key<T> key, boolean allowsNull, int parameterIndex) {
		return new Dependency(this, key, allowsNull, parameterIndex);
	}

	public Member getMember() {
		return this.member;
	}

	public List<Dependency<?>> getDependencies() {
		return this.dependencies;
	}

	public boolean isOptional() {
		return this.optional;
	}

	public boolean equals(Object o) {
		return o instanceof InjectionPoint && this.member.equals(((InjectionPoint) o).member);
	}

	public int hashCode() {
		return this.member.hashCode();
	}

	public String toString() {
		return MoreTypes.toString(this.member);
	}

	public static InjectionPoint forConstructorOf(TypeLiteral<?> type) {
		Class<?> rawType = MoreTypes.getRawType(type.getType());
		Errors errors = new Errors(rawType);
		Constructor<?> injectableConstructor = null;
		Constructor[] arr$ = rawType.getDeclaredConstructors();
		int len$ = arr$.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Constructor<?> constructor = arr$[i$];
			Inject inject = (Inject) constructor.getAnnotation(Inject.class);
			if (inject != null) {
				if (inject.optional()) {
					errors.optionalConstructor(constructor);
				}

				if (injectableConstructor != null) {
					errors.tooManyConstructors(rawType);
				}

				injectableConstructor = constructor;
				checkForMisplacedBindingAnnotations(constructor, errors);
			}
		}

		errors.throwConfigurationExceptionIfErrorsExist();
		if (injectableConstructor != null) {
			return new InjectionPoint(type, injectableConstructor);
		} else {
			try {
				Constructor<?> noArgConstructor = rawType.getDeclaredConstructor();
				if (Modifier.isPrivate(noArgConstructor.getModifiers())
						&& !Modifier.isPrivate(rawType.getModifiers())) {
					errors.missingConstructor(rawType);
					throw new ConfigurationException(errors.getMessages());
				} else {
					checkForMisplacedBindingAnnotations(noArgConstructor, errors);
					return new InjectionPoint(type, noArgConstructor);
				}
			} catch (NoSuchMethodException var9) {
				errors.missingConstructor(rawType);
				throw new ConfigurationException(errors.getMessages());
			}
		}
	}

	public static InjectionPoint forConstructorOf(Class<?> type) {
		return forConstructorOf(TypeLiteral.get(type));
	}

	public static Set<InjectionPoint> forStaticMethodsAndFields(TypeLiteral type) {
		List<InjectionPoint> sink = Lists.newArrayList();
		Errors errors = new Errors();
		addInjectionPoints(type, Factory.FIELDS, true, sink, errors);
		addInjectionPoints(type, Factory.METHODS, true, sink, errors);
		ImmutableSet<InjectionPoint> result = ImmutableSet.copyOf(sink);
		if (errors.hasErrors()) {
			throw (new ConfigurationException(errors.getMessages())).withPartialValue(result);
		} else {
			return result;
		}
	}

	public static Set<InjectionPoint> forStaticMethodsAndFields(Class<?> type) {
		return forStaticMethodsAndFields(TypeLiteral.get(type));
	}

	public static Set<InjectionPoint> forInstanceMethodsAndFields(TypeLiteral<?> type) {
		List<InjectionPoint> sink = Lists.newArrayList();
		Errors errors = new Errors();
		addInjectionPoints(type, Factory.FIELDS, false, sink, errors);
		addInjectionPoints(type, Factory.METHODS, false, sink, errors);
		ImmutableSet<InjectionPoint> result = ImmutableSet.copyOf(sink);
		if (errors.hasErrors()) {
			throw (new ConfigurationException(errors.getMessages())).withPartialValue(result);
		} else {
			return result;
		}
	}

	public static Set<InjectionPoint> forInstanceMethodsAndFields(Class<?> type) {
		return forInstanceMethodsAndFields(TypeLiteral.get(type));
	}

	private static void checkForMisplacedBindingAnnotations(Member member, Errors errors) {
		Annotation misplacedBindingAnnotation = Annotations.findBindingAnnotation(errors, member,
				((AnnotatedElement) member).getAnnotations());
		if (misplacedBindingAnnotation != null) {
			if (member instanceof Method) {
				try {
					if (member.getDeclaringClass().getDeclaredField(member.getName()) != null) {
						return;
					}
				} catch (NoSuchFieldException var4) {
					;
				}
			}

			errors.misplacedBindingAnnotation(member, misplacedBindingAnnotation);
		}
	}

	private static <M extends Member & AnnotatedElement> void addInjectionPoints(TypeLiteral<?> type,
			Factory<M> factory, boolean statics, Collection<InjectionPoint> injectionPoints, Errors errors) {
		if (type.getType() != Object.class) {
			TypeLiteral<?> superType = type.getSupertype(type.getRawType().getSuperclass());
			addInjectionPoints(superType, factory, statics, injectionPoints, errors);
			addInjectorsForMembers(type, factory, statics, injectionPoints, errors);
		}
	}

	private static <M extends Member & AnnotatedElement> void addInjectorsForMembers(TypeLiteral<?> typeLiteral,
			Factory<M> factory, boolean statics, Collection<InjectionPoint> injectionPoints, Errors errors) {
		M[] arr$ = factory.getMembers(MoreTypes.getRawType(typeLiteral.getType()));
		int len$ = arr$.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			M member = arr$[i$];
			if (isStatic(member) == statics) {
				Inject inject = (Inject) ((AnnotatedElement) member).getAnnotation(Inject.class);
				if (inject != null) {
					try {
						injectionPoints.add(factory.create(typeLiteral, member, errors));
					} catch (ConfigurationException var11) {
						if (!inject.optional()) {
							errors.merge(var11.getErrorMessages());
						}
					}
				}
			}
		}

	}

	private static boolean isStatic(Member member) {
		return Modifier.isStatic(member.getModifiers());
	}
}