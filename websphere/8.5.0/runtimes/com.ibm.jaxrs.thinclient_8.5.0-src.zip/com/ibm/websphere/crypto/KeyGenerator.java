package com.ibm.websphere.crypto;

import java.security.Key;
import java.util.Properties;

public interface KeyGenerator {
	void init(Properties var1);

	Key generateKey() throws KeyException;
}