package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.csi.EJBMethodInfo;
import com.ibm.ws.appprofile.accessintent.AIEJBMethodInfo;
import com.ibm.ws.appprofile.accessintent.EJBAccessIntent;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;

public class WASEJBMethodInfoImpl extends SharedEJBMethodInfoImpl implements EJBMethodInfo, AIEJBMethodInfo {
	private static final TraceComponent tc = Tr.register(WASEJBMethodInfoImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	protected AccessIntent ivAccessIntent = null;

	public WASEJBMethodInfoImpl(int slotSize) {
		super(slotSize);
	}

	public void setPMInternalAccessIntent(AccessIntent ai) {
		this.ivAccessIntent = ai;
	}

	public AccessIntent getMethodAccessIntent(EJBAccessIntent aiService) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getMethodAccessIntent");
		}

		AccessIntent ai = aiService.getMethodAccessIntent(this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getMethodAccessIntent", ai);
		}

		return ai;
	}

	public AccessIntent getAccessIntent(EJBAccessIntent aiService) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAccessIntent");
		}

		AccessIntent ai = aiService.getAccessIntent(this, this.ivAccessIntent);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getAccessIntent", ai);
		}

		return ai;
	}

	protected void introspectCMP2xAccessIntent(IntrospectionWriter writer) {
		EntityHelperImpl entityHelperImpl = (EntityHelperImpl) this.bmd.container.ivEntityHelper;
		EJBAccessIntent aiService = entityHelperImpl.getEJBAccessIntent();
		if (aiService != null) {
			AccessIntent ai = this.getAccessIntent(aiService);
			String aiString = EntityHelperImpl.getAccessIntentString(ai);
			writer.println("CMP 2.x AccessIntent = " + aiString);
		}

	}
}