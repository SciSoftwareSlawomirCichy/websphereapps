package com.ibm.websphere.jaxrs.providers.json4j;

import com.ibm.json.java.JSONArray;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;
import org.apache.wink.common.internal.utils.MediaTypeUtils;
import org.apache.wink.common.utils.ProviderUtils;

@Provider
@Consumes({"application/json", "application/javascript"})
@Produces({"application/json", "application/javascript"})
public class JSON4JArrayProvider implements MessageBodyWriter<JSONArray>, MessageBodyReader<JSONArray> {
	public boolean isReadable(Class<?> clazz, Type type, Annotation[] annotations, MediaType mediaType) {
		return JSONArray.class == clazz;
	}

	public JSONArray readFrom(Class<JSONArray> clazz, Type type, Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, String> headers, InputStream is) throws IOException, WebApplicationException {
		return JSONArray.parse(new InputStreamReader(is, ProviderUtils.getCharset(mediaType)));
	}

	public long getSize(JSONArray obj, Class<?> clazz, Type type, Annotation[] annotations, MediaType mediaType) {
		return -1L;
	}

	public boolean isWriteable(Class<?> clazz, Type type, Annotation[] annotations, MediaType mediaType) {
		return JSONArray.class.isAssignableFrom(clazz);
	}

	public void writeTo(JSONArray arr, Class<?> clazz, Type type, Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, Object> headers, OutputStream os) throws IOException, WebApplicationException {
		mediaType = MediaTypeUtils.setDefaultCharsetOnMediaTypeHeader(headers, mediaType);
		OutputStreamWriter writer = new OutputStreamWriter(os, ProviderUtils.getCharset(mediaType));
		arr.serialize(writer);
	}
}