package com.google.common.io;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.hash.HashCode;
import com.google.common.hash.HashFunction;
import com.google.common.io.ByteStreams.1;
import com.google.common.io.ByteStreams.2;
import com.google.common.io.ByteStreams.3;
import com.google.common.io.ByteStreams.4;
import com.google.common.io.ByteStreams.5;
import com.google.common.io.ByteStreams.6;
import com.google.common.io.ByteStreams.7;
import com.google.common.io.ByteStreams.ByteArrayByteSource;
import com.google.common.io.ByteStreams.ByteArrayDataInputStream;
import com.google.common.io.ByteStreams.ByteArrayDataOutputStream;
import com.google.common.io.ByteStreams.LimitedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Arrays;
import java.util.zip.Checksum;

@Beta
public final class ByteStreams {
	private static final int BUF_SIZE = 4096;
	private static final OutputStream NULL_OUTPUT_STREAM = new 1();

	public static InputSupplier<ByteArrayInputStream> newInputStreamSupplier(byte[] b) {
		return asInputSupplier(asByteSource(b));
	}

	public static InputSupplier<ByteArrayInputStream> newInputStreamSupplier(byte[] b, int off, int len) {
		return asInputSupplier(asByteSource(b).slice((long) off, (long) len));
	}

	public static ByteSource asByteSource(byte[] b) {
      return new ByteArrayByteSource(b, (1)null);
   }

	public static void write(byte[] from, OutputSupplier<? extends OutputStream> to) throws IOException {
		asByteSink(to).write(from);
	}

	public static long copy(InputSupplier<? extends InputStream> from, OutputSupplier<? extends OutputStream> to)
			throws IOException {
		return asByteSource(from).copyTo(asByteSink(to));
	}

	public static long copy(InputSupplier<? extends InputStream> from, OutputStream to) throws IOException {
		return asByteSource(from).copyTo(to);
	}

	public static long copy(InputStream from, OutputSupplier<? extends OutputStream> to) throws IOException {
		return asByteSink(to).writeFrom(from);
	}

	public static long copy(InputStream from, OutputStream to) throws IOException {
		Preconditions.checkNotNull(from);
		Preconditions.checkNotNull(to);
		byte[] buf = new byte[4096];
		long total = 0L;

		while (true) {
			int r = from.read(buf);
			if (r == -1) {
				return total;
			}

			to.write(buf, 0, r);
			total += (long) r;
		}
	}

	public static long copy(ReadableByteChannel from, WritableByteChannel to) throws IOException {
		Preconditions.checkNotNull(from);
		Preconditions.checkNotNull(to);
		ByteBuffer buf = ByteBuffer.allocate(4096);
		long total = 0L;

		while (from.read(buf) != -1) {
			buf.flip();

			while (buf.hasRemaining()) {
				total += (long) to.write(buf);
			}

			buf.clear();
		}

		return total;
	}

	public static byte[] toByteArray(InputStream in) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		copy((InputStream) in, (OutputStream) out);
		return out.toByteArray();
	}

	public static byte[] toByteArray(InputSupplier<? extends InputStream> supplier) throws IOException {
		return asByteSource(supplier).read();
	}

	public static ByteArrayDataInput newDataInput(byte[] bytes) {
		return new ByteArrayDataInputStream(bytes);
	}

	public static ByteArrayDataInput newDataInput(byte[] bytes, int start) {
		Preconditions.checkPositionIndex(start, bytes.length);
		return new ByteArrayDataInputStream(bytes, start);
	}

	public static ByteArrayDataOutput newDataOutput() {
		return new ByteArrayDataOutputStream();
	}

	public static ByteArrayDataOutput newDataOutput(int size) {
		Preconditions.checkArgument(size >= 0, "Invalid size: %s", new Object[]{size});
		return new ByteArrayDataOutputStream(size);
	}

	public static OutputStream nullOutputStream() {
		return NULL_OUTPUT_STREAM;
	}

	public static InputStream limit(InputStream in, long limit) {
		return new LimitedInputStream(in, limit);
	}

	public static long length(InputSupplier<? extends InputStream> supplier) throws IOException {
		return asByteSource(supplier).size();
	}

	public static boolean equal(InputSupplier<? extends InputStream> supplier1,
			InputSupplier<? extends InputStream> supplier2) throws IOException {
		return asByteSource(supplier1).contentEquals(asByteSource(supplier2));
	}

	public static void readFully(InputStream in, byte[] b) throws IOException {
		readFully(in, b, 0, b.length);
	}

	public static void readFully(InputStream in, byte[] b, int off, int len) throws IOException {
		int read = read(in, b, off, len);
		if (read != len) {
			throw new EOFException(
					"reached end of stream after reading " + read + " bytes; " + len + " bytes expected");
		}
	}

	public static void skipFully(InputStream in, long n) throws IOException {
		long toSkip = n;

		while (n > 0L) {
			long amt = in.skip(n);
			if (amt == 0L) {
				if (in.read() == -1) {
					long skipped = toSkip - n;
					throw new EOFException("reached end of stream after skipping " + skipped + " bytes; " + toSkip
							+ " bytes expected");
				}

				--n;
			} else {
				n -= amt;
			}
		}

	}

	public static <T> T readBytes(InputSupplier<? extends InputStream> supplier, ByteProcessor<T> processor)
			throws IOException {
		Preconditions.checkNotNull(supplier);
		Preconditions.checkNotNull(processor);
		Closer closer = Closer.create();

		Object var4;
		try {
			InputStream in = (InputStream) closer.register((Closeable) supplier.getInput());
			var4 = readBytes(in, processor);
		} catch (Throwable var8) {
			throw closer.rethrow(var8);
		} finally {
			closer.close();
		}

		return var4;
	}

	public static <T> T readBytes(InputStream input, ByteProcessor<T> processor) throws IOException {
		Preconditions.checkNotNull(input);
		Preconditions.checkNotNull(processor);
		byte[] buf = new byte[4096];

		int read;
		do {
			read = input.read(buf);
		} while (read != -1 && processor.processBytes(buf, 0, read));

		return processor.getResult();
	}

	@Deprecated
   public static long getChecksum(InputSupplier<? extends InputStream> supplier, Checksum checksum) throws IOException {
      Preconditions.checkNotNull(checksum);
      return (Long)readBytes((InputSupplier)supplier, new 2(checksum));
   }

	public static HashCode hash(InputSupplier<? extends InputStream> supplier, HashFunction hashFunction)
			throws IOException {
		return asByteSource(supplier).hash(hashFunction);
	}

	public static int read(InputStream in, byte[] b, int off, int len) throws IOException {
		Preconditions.checkNotNull(in);
		Preconditions.checkNotNull(b);
		if (len < 0) {
			throw new IndexOutOfBoundsException("len is negative");
		} else {
			int total;
			int result;
			for (total = 0; total < len; total += result) {
				result = in.read(b, off + total, len - total);
				if (result == -1) {
					break;
				}
			}

			return total;
		}
	}

	public static InputSupplier<InputStream> slice(InputSupplier<? extends InputStream> supplier, long offset,
			long length) {
		return asInputSupplier(asByteSource(supplier).slice(offset, length));
	}

	public static InputSupplier<InputStream> join(Iterable<? extends InputSupplier<? extends InputStream>> suppliers) {
      Preconditions.checkNotNull(suppliers);
      return new 3(suppliers);
   }

	public static InputSupplier<InputStream> join(InputSupplier... suppliers) {
		return join((Iterable) Arrays.asList(suppliers));
	}

	static <S extends InputStream> InputSupplier<S> asInputSupplier(ByteSource source) {
      Preconditions.checkNotNull(source);
      return new 4(source);
   }

	static <S extends OutputStream> OutputSupplier<S> asOutputSupplier(ByteSink sink) {
      Preconditions.checkNotNull(sink);
      return new 5(sink);
   }

	static ByteSource asByteSource(InputSupplier<? extends InputStream> supplier) {
      Preconditions.checkNotNull(supplier);
      return new 6(supplier);
   }

	static ByteSink asByteSink(OutputSupplier<? extends OutputStream> supplier) {
      Preconditions.checkNotNull(supplier);
      return new 7(supplier);
   }
}