package javax.ws.rs.core;

import javax.ws.rs.ext.RuntimeDelegate;
import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;

public class NewCookie extends Cookie {
	public static final int DEFAULT_MAX_AGE = -1;
	private final String comment;
	private final int maxAge;
	private final boolean isSecure;
	private static final HeaderDelegate<NewCookie> headerDelegate = RuntimeDelegate.getInstance()
			.createHeaderDelegate(NewCookie.class);

	public NewCookie(Cookie cookie) {
		this(cookie, (String) null, -1, false);
	}

	public NewCookie(Cookie cookie, String comment, int maxAge, boolean secure) {
		super(cookie.getName(), cookie.getValue(), cookie.getPath(), cookie.getDomain(), cookie.getVersion());
		this.comment = comment;
		this.maxAge = maxAge;
		this.isSecure = secure;
	}

	public NewCookie(String name, String value) {
		this(name, value, (String) null, (String) null, (String) null, -1, false);
	}

	public NewCookie(String name, String value, String path, String domain, int version, String comment, int maxAge,
			boolean secure) {
		super(name, value, path, domain, version);
		this.comment = comment;
		this.maxAge = maxAge;
		this.isSecure = secure;
	}

	public NewCookie(String name, String value, String path, String domain, String comment, int maxAge,
			boolean secure) {
		this(name, value, path, domain, 1, comment, maxAge, secure);
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		} else if (obj == null) {
			return false;
		} else if (this.getClass() != obj.getClass()) {
			return false;
		} else {
			NewCookie other = (NewCookie) obj;
			if (!this.getName().equals(other.getName())) {
				return false;
			} else if (this.getVersion() != other.getVersion()) {
				return false;
			} else if (this.isSecure != other.isSecure) {
				return false;
			} else if (this.maxAge != other.maxAge) {
				return false;
			} else {
				String value = this.getValue();
				if (value == null) {
					if (other.getValue() != null) {
						return false;
					}
				} else if (!value.equals(other.getValue())) {
					return false;
				}

				String path = this.getPath();
				if (path == null) {
					if (other.getPath() != null) {
						return false;
					}
				} else if (!path.equals(other.getPath())) {
					return false;
				}

				String domain = this.getDomain();
				if (domain == null) {
					if (other.getDomain() != null) {
						return false;
					}
				} else if (!domain.equals(other.getDomain())) {
					return false;
				}

				if (this.comment == null) {
					if (other.comment != null) {
						return false;
					}
				} else if (!this.comment.equals(other.comment)) {
					return false;
				}

				return true;
			}
		}
	}

	public int hashCode() {
		int result = super.hashCode();
		result = 31 * result + (this.comment == null ? 0 : this.comment.hashCode());
		result = 31 * result + this.maxAge;
		result = 31 * result + (this.isSecure ? 1 : 0);
		return result;
	}

	public String getComment() {
		return this.comment;
	}

	public int getMaxAge() {
		return this.maxAge;
	}

	public boolean isSecure() {
		return this.isSecure;
	}

	public Cookie toCookie() {
		return new Cookie(this.getName(), this.getValue(), this.getPath(), this.getDomain(), this.getVersion());
	}

	public String toString() {
		return headerDelegate.toString(this);
	}

	public static NewCookie valueOf(String value) {
		return (NewCookie) headerDelegate.fromString(value);
	}
}