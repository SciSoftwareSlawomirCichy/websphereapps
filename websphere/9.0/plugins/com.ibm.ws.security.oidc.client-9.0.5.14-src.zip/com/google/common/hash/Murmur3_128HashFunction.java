package com.google.common.hash;

import com.google.common.hash.Murmur3_128HashFunction.Murmur3_128Hasher;
import com.google.errorprone.annotations.Immutable;
import java.io.Serializable;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Immutable
final class Murmur3_128HashFunction extends AbstractHashFunction implements Serializable {
	static final HashFunction MURMUR3_128 = new Murmur3_128HashFunction(0);
	static final HashFunction GOOD_FAST_HASH_128;
	private final int seed;
	private static final long serialVersionUID = 0L;

	Murmur3_128HashFunction(int seed) {
		this.seed = seed;
	}

	public int bits() {
		return 128;
	}

	public Hasher newHasher() {
		return new Murmur3_128Hasher(this.seed);
	}

	public String toString() {
		return "Hashing.murmur3_128(" + this.seed + ")";
	}

	public boolean equals(@NullableDecl Object object) {
		if (object instanceof Murmur3_128HashFunction) {
			Murmur3_128HashFunction other = (Murmur3_128HashFunction) object;
			return this.seed == other.seed;
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.getClass().hashCode() ^ this.seed;
	}

	static {
		GOOD_FAST_HASH_128 = new Murmur3_128HashFunction(Hashing.GOOD_FAST_HASH_SEED);
	}
}