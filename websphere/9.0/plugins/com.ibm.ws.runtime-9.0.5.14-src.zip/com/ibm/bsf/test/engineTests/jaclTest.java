package com.ibm.bsf.test.engineTests;

import com.ibm.bsf.BSFEngine;
import com.ibm.bsf.BSFException;
import com.ibm.bsf.test.BSFEngineTestTmpl;

public class jaclTest extends BSFEngineTestTmpl {
	private BSFEngine jaclEngine;

	public jaclTest(String var1) {
		super(var1);
	}

	public void setUp() {
		super.setUp();

		try {
			this.jaclEngine = this.bsfManager.loadScriptingEngine("jacl");
		} catch (Exception var2) {
			fail(this.failMessage("Failure attempting to load jacl", var2));
		}

	}

	public void testExec() {
		try {
			this.jaclEngine.exec("Test.jacl", 0, 0, "puts -nonewline \"PASSED\"");
		} catch (Exception var2) {
			fail(this.failMessage("exec() test failed", var2));
		}

		assertEquals("PASSED", this.getTmpOutStr());
	}

	public void testEval() {
		Integer var1 = null;

		try {
			var1 = (Integer) this.jaclEngine.eval("Test.jacl", 0, 0, "expr 1 + 1");
		} catch (Exception var3) {
			fail(this.failMessage("eval() test failed", var3));
		}

		assertEquals(new Integer(2), var1);
	}

	public void testCall() {
		Object[] var1 = new Object[]{new Integer(1)};
		Integer var2 = null;

		try {
			this.jaclEngine.exec("Test.jacl", 0, 0, "proc addOne {f} {\n return [expr $f + 1]\n}");
			var2 = (Integer) this.jaclEngine.call((Object) null, "addOne", var1);
		} catch (Exception var4) {
			fail(this.failMessage("call() test failed", var4));
		}

		assertEquals(new Integer(2), var2);
	}

	public void testIexec() {
		try {
			this.jaclEngine.iexec("Test.jacl", 0, 0, "puts -nonewline \"PASSED\"");
		} catch (Exception var2) {
			fail(this.failMessage("iexec() test failed", var2));
		}

		assertEquals("PASSED", this.getTmpOutStr());
	}

	public void testBSFManagerEval() {
		Integer var1 = null;

		try {
			var1 = (Integer) this.bsfManager.eval("jacl", "Test.jacl", 0, 0, "expr 1 + 1");
		} catch (Exception var3) {
			fail(this.failMessage("BSFManager eval() test failed", var3));
		}

		assertEquals(new Integer(2), var1);
	}

	public void testRegisterBean() {
		Integer var1 = new Integer(1);
		Integer var2 = null;

		try {
			this.bsfManager.registerBean("foo", var1);
			var2 = (Integer) this.jaclEngine.eval("Test.jacl", 0, 0, "bsf lookupBean \"foo\"");
		} catch (Exception var4) {
			fail(this.failMessage("registerBean() test failed", var4));
		}

		assertEquals(var1, var2);
	}

	public void testUnregisterBean() {
		Integer var1 = new Integer(1);
		Integer var2 = null;

		try {
			this.bsfManager.registerBean("foo", var1);
			this.bsfManager.unregisterBean("foo");
			var2 = (Integer) this.jaclEngine.eval("Test.jacl", 0, 0, "bsf lookupBean \"foo\"");
		} catch (BSFException var4) {
			;
		} catch (Exception var5) {
			fail(this.failMessage("unregisterBean() test failed", var5));
		}

		assertNull(var2);
	}

	public void testDeclareBean() {
		Integer var1 = new Integer(1);
		Integer var2 = null;

		try {
			this.bsfManager.declareBean("foo", var1,
					class$java$lang$Integer == null
							? (class$java$lang$Integer = class$("java.lang.Integer"))
							: class$java$lang$Integer);
			var2 = (Integer) this.jaclEngine.eval("Test.jacl", 0, 0,
					"proc ret {} {\n upvar 1 foo lfoo\n return $lfoo\n }\n ret");
		} catch (Exception var4) {
			fail(this.failMessage("declareBean() test failed", var4));
		}

		assertEquals(var1, var2);
	}

	public void testUndeclareBean() {
		Integer var1 = new Integer(1);
		Integer var2 = null;

		try {
			this.bsfManager.declareBean("foo", var1,
					class$java$lang$Integer == null
							? (class$java$lang$Integer = class$("java.lang.Integer"))
							: class$java$lang$Integer);
			this.bsfManager.undeclareBean("foo");
			var2 = (Integer) this.jaclEngine.eval("Test.jacl", 0, 0, "expr $foo + 1");
		} catch (Exception var4) {
			fail(this.failMessage("undeclareBean() test failed", var4));
		}

		assertEquals(var1, var2);
	}
}