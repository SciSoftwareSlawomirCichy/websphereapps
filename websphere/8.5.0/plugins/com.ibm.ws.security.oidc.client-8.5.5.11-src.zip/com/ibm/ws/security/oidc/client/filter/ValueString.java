package com.ibm.ws.security.oidc.client.filter;

public class ValueString implements IValue {
	String value;

	public ValueString(String value) {
		this.value = value;
	}

	public boolean equals(IValue str) {
		return str.getClass() != ValueString.class ? false : this.value.equals(((ValueString) str).value);
	}

	public boolean greaterThan(IValue str) {
		if (str.getClass() != ValueString.class) {
			return false;
		} else {
			return this.value.compareTo(((ValueString) str).value) > 0;
		}
	}

	public boolean lessThan(IValue str) {
		if (str.getClass() != ValueString.class) {
			return false;
		} else {
			return this.value.compareTo(((ValueString) str).value) < 0;
		}
	}

	public boolean containedBy(IValue str) {
		if (str.getClass() != ValueString.class) {
			return false;
		} else {
			return ((ValueString) str).value.indexOf(this.value) != -1;
		}
	}

	public String toString() {
		return this.value;
	}
}