package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.Label;

public interface ObjectSwitchCallback {
	void processCase(Object var1, Label var2) throws Exception;

	void processDefault() throws Exception;
}