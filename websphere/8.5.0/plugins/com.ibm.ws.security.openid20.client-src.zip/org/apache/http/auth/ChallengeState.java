package org.apache.http.auth;

public enum ChallengeState {
	TARGET, PROXY;
}