package com.ibm.ejs.csi;

import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.ContainerProperties;
import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSDeployedSupport;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.tx.jta.embeddable.EmbeddableTransactionManagerFactory;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRequiredException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.websphere.csi.LocalTranConfigData;
import com.ibm.websphere.csi.MethodInterface;
import com.ibm.websphere.uow.UOWSynchronizationRegistry;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.LocalTransaction.LocalTransactionCurrent;
import com.ibm.ws.LocalTransaction.RolledbackException;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.traceinfo.ejbcontainer.TETxLifeCycleInfo;
import com.ibm.ws.tx.embeddable.EmbeddableWebSphereTransactionManager;
import com.ibm.ws.uow.embeddable.UOWCompensatedException;
import com.ibm.wsspi.uow.UOWManagerFactory;
import javax.transaction.HeuristicMixedException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;

abstract class TranStrategy {
	private static final String CLASS_NAME = TranStrategy.class.getName();
	private static final TraceComponent tc;
	private static final UOWSynchronizationRegistry svUOWSynchReg;
	protected TransactionControlImpl txCtrl;
	protected LocalTransactionCurrent ltcCurrent;
	private EmbeddableWebSphereTransactionManager txManager = EmbeddableTransactionManagerFactory
			.getTransactionManager();

	protected TranStrategy(TransactionControlImpl txCtrl) {
		this.txCtrl = txCtrl;
		this.ltcCurrent = EmbeddableTransactionManagerFactory.getLocalTransactionCurrent();
	}

	abstract TxCookieImpl preInvoke(EJBKey var1, EJBMethodInfoImpl var2) throws CSIException;

	void postInvoke(EJBKey key, TxCookieImpl cookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "postInvoke");
		}

		if (!cookie.beginner) {
			this.txCtrl.completeTxTimeout();
		} else if (this.txCtrl.getRollbackOnly()) {
			CSITransactionRolledbackException timeoutEx = null;

			try {
				this.txCtrl.completeTxTimeout();
			} catch (CSITransactionRolledbackException var9) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "tran timed out; will throw ex after rollback");
				}

				timeoutEx = var9;
			}

			this.rollback(true, key, methodInfo);
			if (timeoutEx != null) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "postInvoke : " + timeoutEx);
				}

				throw timeoutEx;
			}

			MethodInterface methodType = methodInfo.getInterfaceType();
			BeanMetaData bmd = methodInfo.getBeanMetaData();
			EJBModuleMetaDataImpl mmd = bmd._moduleMetaData;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "EJBModuleMetaDataImpl.ivUseExtendedSetRollbackOnlyBehavior = "
						+ mmd.ivUseExtendedSetRollbackOnlyBehavior);
			}

			if (!mmd.ivUseExtendedSetRollbackOnlyBehavior || methodType == MethodInterface.MESSAGE_LISTENER
					|| methodType == MethodInterface.TIMED_OBJECT) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "postInvoke : Transaction marked rollbackonly");
				}

				throw new CSITransactionRolledbackException("Transaction marked rollbackonly");
			}
		} else {
			this.commit(key, methodInfo);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "postInvoke");
		}

	}

	void handleException(EJBKey key, TxCookieImpl txCookie, ExceptionType type, EJBMethodInfoImpl methodInfo)
			throws CSIException {
		if (type == ExceptionType.CHECKED_EXCEPTION) {
			this.postInvoke(key, txCookie, methodInfo);
		} else if (txCookie.beginner) {
			this.rollback(true, key, methodInfo);
		} else if (this.globalTxExists(false)) {
			this.txCtrl.completeTxTimeout();
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "handleException: marking client transaction rollbackOnly");
			}

			this.rollback(false, key, methodInfo);
			throw new CSITransactionRolledbackException();
		} else {
			LocalTransactionCoordinator coord = this.ltcCurrent.getLocalTranCoord();
			if (coord != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "handleException: marking client LTC rollbackOnly");
				}

				coord.setRollbackOnly();
			}

		}
	}

	final TxCookieImpl beginLocalTx(EJBKey ejbKey, EJBMethodInfoImpl methodInfo, Transaction suspendedGlobalTx)
			throws CSIException {
		BeanMetaData bmd = methodInfo.getBeanMetaData();
		int EJBType = bmd.getEJBComponentType();
		LocalTranConfigData ltcd = bmd.getLocalTranConfigData();
		boolean ltcBoundaryIsAS = ltcd.getValueBoundary() == 1;
		boolean suspendedLocalTxFound = false;
		LocalTransactionCoordinator savedLocalTx = null;
		boolean begunLocalTx = false;
		if (ltcBoundaryIsAS && (EJBType == 4 || EJBType == 5 || EJBType == 6)) {
			LocalTransactionCoordinator suspendedLocalTx = (LocalTransactionCoordinator) this.txCtrl.stickyLocalTxTable
					.remove(ejbKey);
			if (suspendedLocalTx != null) {
				suspendedLocalTxFound = true;

				try {
					savedLocalTx = this.ltcCurrent.getLocalTranCoord();
					this.suspendLocalTx(savedLocalTx);
					this.resumeLocalTx(suspendedLocalTx);
					begunLocalTx = true;
				} catch (Throwable var18) {
					FFDCFilter.processException(var18, CLASS_NAME + ".beginLocalTx", "200", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Local tx resume failed", var18);
					}

					if (savedLocalTx != null) {
						try {
							this.resumeLocalTx(savedLocalTx);
						} catch (Throwable var17) {
							FFDCFilter.processException(var17, CLASS_NAME + ".beginLocalTx", "212", this);
							if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
								Tr.event(tc, "Saved local tx resume failed", var17);
							}
						}
					}

					throw new CSIException("Resume local tx failed", var18);
				}
			}
		}

		if (!suspendedLocalTxFound) {
			try {
				boolean ltcUnresActionIsCommit = ltcd.getValueUnresolvedAction() == 1;
				boolean ltcResolverIsCAB = ltcd.getValueResolver() == 1;
				boolean ltcShareable = ltcd.isShareable();
				LocalTransactionCoordinator coord = this.ltcCurrent.getLocalTranCoord();
				if (coord == null) {
					if (ltcShareable) {
						this.ltcCurrent.beginShareable(ltcBoundaryIsAS, ltcUnresActionIsCommit, ltcResolverIsCAB);
					} else {
						this.ltcCurrent.begin(ltcBoundaryIsAS, ltcUnresActionIsCommit, ltcResolverIsCAB);
					}

					svUOWSynchReg.putResource("com.ibm.websphere.profile", methodInfo.getJPATaskName());
					begunLocalTx = true;
				} else if (coord.isShareable() && ltcShareable) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "LTC context shared");
					}
				} else {
					savedLocalTx = this.ltcCurrent.getLocalTranCoord();
					this.suspendLocalTx(savedLocalTx);
					if (ltcShareable) {
						this.ltcCurrent.beginShareable(ltcBoundaryIsAS, ltcUnresActionIsCommit, ltcResolverIsCAB);
					} else {
						this.ltcCurrent.begin(ltcBoundaryIsAS, ltcUnresActionIsCommit, ltcResolverIsCAB);
					}

					svUOWSynchReg.putResource("com.ibm.websphere.profile", methodInfo.getJPATaskName());
					begunLocalTx = true;
				}

				if (TraceComponent.isAnyTracingEnabled()
						&& (tc.isEventEnabled() || TETxLifeCycleInfo.isTraceEnabled())) {
					LocalTransactionCoordinator lCoord = this.txCtrl.getLocalCoord();
					if (tc.isEventEnabled()) {
						if (lCoord != null) {
							Tr.event(tc, "Began LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
						} else {
							Tr.event(tc, "Began LTC cntxt: null Coordinator!");
						}

						if (begunLocalTx) {
							Tr.event(tc, "Set JPA task name: " + methodInfo.getJPATaskName());
						}
					}

					if (lCoord != null && TETxLifeCycleInfo.isTraceEnabled()) {
						TETxLifeCycleInfo.traceLocalTxBegin("" + System.identityHashCode(lCoord), "Begin Local Tx");
					}
				}
			} catch (Exception var19) {
				FFDCFilter.processException(var19, CLASS_NAME + ".beginLocalTx", "217", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Begin local tx failed", var19);
				}

				if (savedLocalTx != null) {
					try {
						this.resumeLocalTx(savedLocalTx);
					} catch (Throwable var16) {
						FFDCFilter.processException(var16, CLASS_NAME + ".beginLocalTx", "242", this);
						if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
							Tr.event(tc, "Saved local tx resume failed", var16);
						}
					}
				}

				throw new CSIException("Begin local tx failed", var19);
			}
		}

		TxCookieImpl cookie = new TxCookieImpl(begunLocalTx, true, this, suspendedGlobalTx);
		cookie.suspendedLocalTx = savedLocalTx;
		return cookie;
	}

	final void suspendLocalTx(LocalTransactionCoordinator lCoord) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEventEnabled()) {
			if (lCoord != null) {
				Tr.event(tc, "Suspending LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
			} else {
				Tr.event(tc, "Suspending LTC cntxt: null Coordinator!");
			}
		}

		this.ltcCurrent.suspend();
		if (isTraceOn && lCoord != null && TETxLifeCycleInfo.isTraceEnabled()) {
			TETxLifeCycleInfo.traceLocalTxSuspend("" + System.identityHashCode(lCoord), "Suspend Local Tx");
		}

	}

	final void resumeLocalTx(LocalTransactionCoordinator lCoord) throws IllegalStateException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEventEnabled()) {
			if (lCoord != null) {
				Tr.event(tc, "Resuming LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
			} else {
				Tr.event(tc, "Resuming LTC cntxt: null Coordinator!");
			}
		}

		this.ltcCurrent.resume(lCoord);
		if (isTraceOn && lCoord != null && TETxLifeCycleInfo.isTraceEnabled()) {
			TETxLifeCycleInfo.traceLocalTxResume("" + System.identityHashCode(lCoord), "Resume Local Tx");
		}

	}

	final boolean globalTxExists(boolean failIfNonInterop) throws CSIException {
		Transaction tx = null;

		try {
			tx = this.txManager.getTransaction();
		} catch (SystemException var4) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Could not determine if there is a global tx active");
			}
		}

		if (failIfNonInterop && tx != null && ((UOWCoordinator) tx).getTxType() == 2) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Cannot proceed under a non-interoperable transaction context");
			}

			throw new CSITransactionRequiredException("Interoperable global transaction required");
		} else {
			return tx != null;
		}
	}

	final void beginGlobalTx(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		try {
			this.txCtrl.txService.begin();
			svUOWSynchReg.putResource("com.ibm.websphere.profile", methodInfo.getJPATaskName());
			if (TraceComponent.isAnyTracingEnabled()) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "Began TX cntxt: " + this.txCtrl.txService.getTransaction());
					Tr.event(tc, "Set JPA task name: " + methodInfo.getJPATaskName());
				}

				if (TETxLifeCycleInfo.isTraceEnabled()) {
					String idStr = this.txCtrl.txService.getTransaction().toString();
					int idx;
					idStr = idStr != null
							? ((idx = idStr.indexOf("(")) != -1
									? idStr.substring(idx + 1, idStr.indexOf(")"))
									: ((idx = idStr.indexOf("tid=")) != -1 ? idStr.substring(idx + 4) : idStr))
							: "NoTx";
					TETxLifeCycleInfo.traceGlobalTxBegin(idStr, "Begin Global Tx");
				}
			}

		} catch (Exception var5) {
			FFDCFilter.processException(var5, CLASS_NAME + ".beginGlobalTx", "243", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Begin global tx failed", var5);
			}

			throw new CSIException("Begin global tx failed", var5);
		}
	}

	final Transaction suspendGlobalTx(int action) throws CSIException {
		Transaction result = this.txCtrl.suspendGlobalTx(action);
		if (TraceComponent.isAnyTracingEnabled() && TETxLifeCycleInfo.isTraceEnabled()) {
			TETxLifeCycleInfo.traceGlobalTxSuspend("NoTx", "Suspend Global Tx");
		}

		return result;
	}

	final void resumeGlobalTx(Transaction control, int action) throws CSIException {
		try {
			this.txCtrl.resumeGlobalTx(control, action);
			if (TraceComponent.isAnyTracingEnabled() && TETxLifeCycleInfo.isTraceEnabled()) {
				String idStr = this.txCtrl.txService.getTransaction().toString();
				int idx;
				idStr = idStr != null
						? ((idx = idStr.indexOf("(")) != -1
								? idStr.substring(idx + 1, idStr.indexOf(")"))
								: ((idx = idStr.indexOf("tid=")) != -1 ? idStr.substring(idx + 4) : idStr))
						: "NoTx";
				TETxLifeCycleInfo.traceGlobalTxResume(idStr, "Resume Global Tx");
			}

		} catch (Exception var5) {
			FFDCFilter.processException(var5, CLASS_NAME + ".resumeGlobalTx", "335", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Global tx resume failed", var5);
			}

			throw new CSIException("", var5);
		}
	}

	final void commit(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSITransactionRolledbackException {
		LocalTransactionCoordinator lCoord = this.ltcCurrent.getLocalTranCoord();
		if (lCoord != null) {
			int EJBType = methodInfo.getBeanMetaData().getEJBComponentType();
			if (lCoord.isASScoped()) {
				if (!methodInfo.isHome() && EJBType != 7) {
					this.suspendLocalTx(lCoord);
					if (EJBType != 3 && EJBType != 2 && !methodInfo.getMethodName().equalsIgnoreCase("remove")) {
						this.txCtrl.stickyLocalTxTable.put(key, lCoord);
					}
				}
			} else {
				try {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Completing LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
					}

					lCoord.end(0);
					if (TraceComponent.isAnyTracingEnabled() && TETxLifeCycleInfo.isTraceEnabled()) {
						TETxLifeCycleInfo.traceLocalTxCommit("" + System.identityHashCode(lCoord),
								"Commit Local Tx - end");
					}
				} catch (Exception var6) {
					Exception ex = var6;
					FFDCFilter.processException(var6, CLASS_NAME + ".commit", "277", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Local tx completion failed", var6);
					}

					if (ContainerProperties.ExcludeNestedExceptions) {
						ex = null;
					}

					throw new CSITransactionRolledbackException("", ex);
				}
			}
		} else {
			try {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Committing TX cntxt: " + this.txCtrl.txService.getTransaction());
				}

				this.txCtrl.txService.commit();
				if (TraceComponent.isAnyTracingEnabled() && TETxLifeCycleInfo.isTraceEnabled()) {
					TETxLifeCycleInfo.traceGlobalTxCommit("NoTx", "Commit Global Tx");
				}
			} catch (HeuristicMixedException var7) {
				FFDCFilter.processException(var7, CLASS_NAME + ".commit", "856", this);
				if (tc.isEventEnabled()) {
					Tr.event(tc, "Global tx commit failed Heuristically", var7);
				}

				throw new CSITransactionRolledbackException("", var7);
			} catch (Exception var8) {
				Exception ex = var8;
				FFDCFilter.processException(var8, CLASS_NAME + ".commit", "294", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Global tx commit failed", var8);
				}

				if (ContainerProperties.ExcludeNestedExceptions) {
					ex = null;
				}

				throw new CSITransactionRolledbackException("", ex);
			}
		}

	}

	final void rollback(boolean beginner, EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		LocalTransactionCoordinator lCoord = this.ltcCurrent.getLocalTranCoord();
		if (lCoord == null) {
			try {
				if (beginner) {
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "Rolling back TX cntxt due to bean exception: "
								+ this.txCtrl.txService.getTransaction());
					}

					this.txCtrl.txService.rollback();
					if (isTraceOn && TETxLifeCycleInfo.isTraceEnabled()) {
						TETxLifeCycleInfo.traceGlobalTxRollback("NoTx", "Rollback Global Tx");
					}
				} else {
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "Marking TX cntxt for rollback due to bean exception: "
								+ this.txCtrl.txService.getTransaction());
					}

					this.txCtrl.txService.setRollbackOnly();
				}
			} catch (Exception var10) {
				FFDCFilter.processException(var10, CLASS_NAME + ".rollback", "405", this);
				String errStr = "Could not roll back global tx";
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, errStr, var10);
				}

				throw new CSIException(errStr, var10);
			}
		} else {
			int EJBType = methodInfo.getBeanMetaData().getEJBComponentType();
			if (lCoord.isASScoped()) {
				if (!methodInfo.isHome() && EJBType != 7) {
					lCoord.setRollbackOnly();
					this.suspendLocalTx(lCoord);
					if (EJBType != 3 && EJBType != 2 && !methodInfo.getMethodName().equalsIgnoreCase("remove")) {
						this.txCtrl.stickyLocalTxTable.put(key, lCoord);
					}
				}
			} else {
				try {
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "Completing LTC cntxt with rollback due to bean exception: tid="
								+ Integer.toHexString(lCoord.hashCode()) + "(LTC)");
					}

					lCoord.setRollbackOnly();
					lCoord.end(1);
					if (isTraceOn && TETxLifeCycleInfo.isTraceEnabled()) {
						TETxLifeCycleInfo.traceLocalTxRollback("" + System.identityHashCode(lCoord),
								"Rollback Local Tx - end");
					}
				} catch (RolledbackException var11) {
					FFDCFilter.processException(var11, CLASS_NAME + ".rollback", "375", this);
				} catch (UOWCompensatedException var12) {
					EJSDeployedSupport s = EJSContainer.getMethodContext();
					if (s.getException() == null) {
						FFDCFilter.processException(var12, CLASS_NAME + ".rollback", "1129", this);
						String errStr = "Could not complete local tx";
						if (isTraceOn && tc.isEventEnabled()) {
							Tr.event(tc, errStr, var12);
						}

						throw new CSIException(errStr, var12);
					}

					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Ignoring UOWCompensatedException; another exception already reported : "
								+ s.getException(), var12);
					}
				} catch (Exception var13) {
					FFDCFilter.processException(var13, CLASS_NAME + ".rollback", "378", this);
					String errStr = "Could not complete local tx";
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, errStr, var13);
					}

					throw new CSIException(errStr, var13);
				}
			}
		}

	}

	boolean isBmtActive() {
		return false;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		svUOWSynchReg = UOWManagerFactory.getUOWManager();
	}
}