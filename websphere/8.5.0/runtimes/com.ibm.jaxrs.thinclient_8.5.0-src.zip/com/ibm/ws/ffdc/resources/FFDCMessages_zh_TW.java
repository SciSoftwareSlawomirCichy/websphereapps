package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_zh_TW extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: 使用資料基本的分析引擎：{0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: 在 {0} {1} {2} 上已產生「FFDC 發生事件」"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE", "FFDC0002I: FFDC 日誌檔管理正試圖刪除檔案 {0}"},
			{"FFDCJANITOR_DELETED_FILES", "FFDC0004I: FFDC 日誌檔管理移除了已到達其配置之經歷時間上限的 {0} 個檔案，共 {1} 個檔案"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE", "FFDC0003I: FFDC 日誌檔管理無法刪除檔案 {0}"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST", "FFDC0001W: FFDC 日誌檔管理無法取得異常狀況檔案的清單"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC 已關閉發生事件串流檔 {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC 已開啟發生事件串流檔 {0}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE", "FFDC0012I: FFDC 無法關閉發生事件串流檔 {0}，捕捉到異常狀況 {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE", "FFDC0011I: FFDC 無法開啟或建立發生事件串流檔 {0}，捕捉到異常狀況 {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE", "FFDC0013I: FFDC 無法寫入發生事件串流檔 {0}，捕捉到異常狀況 {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}