package com.google.common.hash;

import com.google.common.base.Preconditions;
import com.google.common.hash.AbstractCompositeHashFunction.1;

abstract class AbstractCompositeHashFunction extends AbstractStreamingHashFunction {
	final HashFunction[] functions;
	private static final long serialVersionUID = 0L;

	AbstractCompositeHashFunction(HashFunction... functions) {
		HashFunction[] arr$ = functions;
		int len$ = functions.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			HashFunction function = arr$[i$];
			Preconditions.checkNotNull(function);
		}

		this.functions = functions;
	}

	abstract HashCode makeHash(Hasher[] var1);

	public Hasher newHasher() {
      Hasher[] hashers = new Hasher[this.functions.length];

      for(int i = 0; i < hashers.length; ++i) {
         hashers[i] = this.functions[i].newHasher();
      }

      return new 1(this, hashers);
   }
}