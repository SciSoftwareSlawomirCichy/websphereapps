package com.ibm.ejs.container.passivator;

import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.StatefulBeanO;
import com.ibm.websphere.csi.SessionBeanStore;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public abstract class SharedStatefulPassivator extends StatefulPassivator {
	public SharedStatefulPassivator(SessionBeanStore beanStore, EJSContainer container, SfFailoverCache failoverCache) {
		super(beanStore, container, failoverCache);
	}

	public ObjectOutputStream createPassivationOutputStream(OutputStream os) throws IOException {
		return new NewOutputStream(os, this.ivContainer);
	}

	public ObjectInputStream createActivationInputStream(InputStream is, StatefulBeanO beanO, ClassLoader classLoader)
			throws IOException {
		return new NewInputStream(is, beanO, classLoader, this.ivContainer);
	}
}