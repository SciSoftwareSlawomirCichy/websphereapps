package com.ibm.ejs.container;

public enum WrapperInterface {
	REMOTE(RemoteExceptionMappingStrategy.INSTANCE, true), HOME(RemoteExceptionMappingStrategy.INSTANCE, true), LOCAL(
			LocalExceptionMappingStrategy.INSTANCE, false), LOCAL_HOME(LocalExceptionMappingStrategy.INSTANCE,
					false), SERVICE_ENDPOINT(RemoteExceptionMappingStrategy.INSTANCE, false), MESSAGE_LISTENER(
							LocalExceptionMappingStrategy.INSTANCE,
							false), TIMED_OBJECT(LocalExceptionMappingStrategy.INSTANCE, false), BUSINESS_LOCAL(
									BusinessExceptionMappingStrategy.INSTANCE,
									false), BUSINESS_REMOTE(BusinessExceptionMappingStrategy.INSTANCE,
											false), BUSINESS_RMI_REMOTE(RemoteExceptionMappingStrategy.INSTANCE,
													true), LIFECYCLE_INTERCEPTOR(
															BusinessExceptionMappingStrategy.INSTANCE, false);

	final transient ExceptionMappingStrategy ivExceptionStrategy;
	final boolean ivORB;

	private WrapperInterface(ExceptionMappingStrategy exceptionStrategy, boolean orb) {
		this.ivExceptionStrategy = exceptionStrategy;
		this.ivORB = orb;
	}
}