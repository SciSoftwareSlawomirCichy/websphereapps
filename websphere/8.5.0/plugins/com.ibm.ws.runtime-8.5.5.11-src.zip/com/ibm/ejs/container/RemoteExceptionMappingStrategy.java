package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIAccessException;
import com.ibm.websphere.csi.CSIActivityCompletedException;
import com.ibm.websphere.csi.CSIActivityRequiredException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSIInvalidActivityException;
import com.ibm.websphere.csi.CSIInvalidTransactionException;
import com.ibm.websphere.csi.CSINoSuchObjectException;
import com.ibm.websphere.csi.CSITransactionRequiredException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.websphere.csi.OrbUtils;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.javax.activity.ActivityCompletedException;
import com.ibm.ws.javax.activity.ActivityRequiredException;
import com.ibm.ws.javax.activity.InvalidActivityException;
import com.ibm.ws.javax.ejb.ActivityCompletedLocalException;
import com.ibm.ws.javax.ejb.ActivityRequiredLocalException;
import com.ibm.ws.javax.ejb.InvalidActivityLocalException;
import java.rmi.AccessException;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.AccessLocalException;
import javax.ejb.ConcurrentAccessException;
import javax.ejb.ConcurrentAccessTimeoutException;
import javax.ejb.EJBException;
import javax.ejb.NoSuchEJBException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.TransactionRequiredLocalException;
import javax.ejb.TransactionRolledbackLocalException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.InvalidTransactionException;
import javax.transaction.TransactionRequiredException;
import javax.transaction.TransactionRolledbackException;

public class RemoteExceptionMappingStrategy extends ExceptionMappingStrategy {
	protected static TraceComponent tc = Tr.register(RemoteExceptionMappingStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.RemoteExceptionMappingStrategy";
	static final ExceptionMappingStrategy INSTANCE = new RemoteExceptionMappingStrategy();

	private static OrbUtils getOrbUtils() {
		return EJSContainer.getDefaultContainer().getOrbUtils();
	}

	private Throwable mapException(EJSDeployedSupport s, RemoteException ex) {
		try {
			CSIException csiex;
			if (ex instanceof CSIException) {
				csiex = (CSIException) ex;
				return this.mapCSIException(s, csiex);
			} else if (ex.detail instanceof CSIException) {
				csiex = (CSIException) ex.detail;
				return this.mapCSIException(s, csiex);
			} else if (ex instanceof CreateFailureException) {
				return (Throwable) (!s.ivWrapper.ivInterface.ivORB ? ex : getOrbUtils().mapException(ex));
			} else if (ex instanceof BeanNotReentrantException
					&& (s.ivWrapper.ivInterface == WrapperInterface.BUSINESS_RMI_REMOTE
							|| s.ivWrapper.ivInterface == WrapperInterface.SERVICE_ENDPOINT)) {
				BeanNotReentrantException bnre = (BeanNotReentrantException) ex;
				EJBException caex = bnre.isTimeout()
						? new ConcurrentAccessTimeoutException(ex.getMessage())
						: new ConcurrentAccessException(ex.getMessage());
				((EJBException) caex).setStackTrace(ex.getStackTrace());
				s.rootEx = (Throwable) caex;
				return this.mapEJBException(s, (EJBException) caex);
			} else if (ex.detail instanceof EJBException) {
				EJBException ejbex = (EJBException) ex.detail;
				return this.mapEJBException(s, ejbex);
			} else {
				return (Throwable) (!s.ivWrapper.ivInterface.ivORB ? ex : getOrbUtils().mapException(ex));
			}
		} catch (CSIException var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.RemoteExceptionMappingStrategy.mapException",
					"119", this);
			Tr.warning(tc, "UNABLE_TO_MAP_EXCEPTION_CNTR0013W", new Object[]{ex, var5});
			return ex;
		}
	}

	public final Throwable setUncheckedException(EJSDeployedSupport s, Throwable ex) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "setUncheckedException in param:" + ex);
		}

		if (s.ivException != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "setting unchecked exception again", ex);
				Tr.event(tc, "original exception", s.ivException);
			}

			return s.ivException;
		} else {
			Boolean applicationExceptionRollback = null;
			int moduleVersion = s.ivWrapper.bmd.ivModuleVersion;
			if (moduleVersion >= 30 && ex instanceof Exception && !(ex instanceof RemoteException)) {
				applicationExceptionRollback = s.getApplicationExceptionRollback((Throwable) ex);
			}

			if (applicationExceptionRollback != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "ApplicationException with rollback set to true, changing to a checked exception", ex);
				}

				s.exType = ExceptionType.CHECKED_EXCEPTION;
				s.ivException = (Throwable) ex;
				s.rootEx = (Throwable) ex;
				if (applicationExceptionRollback == Boolean.TRUE) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "ApplicationException with rollback set to true, setting rollback only", ex);
					}

					s.currentTx.setRollbackOnly();
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "setUncheckedException returning: " + s.ivException);
				}

				return s.ivException;
			} else {
				if (s.preInvokeException && (ex instanceof NoSuchObjectException || ex instanceof NoSuchEJBException
						|| ex instanceof CSIAccessException || ex instanceof BeanNotReentrantException)) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception should not cause rollback, changing to checked exception");
					}

					if (ex instanceof BeanNotReentrantException) {
						s.beanO = null;
					} else if (ex instanceof NoSuchEJBException) {
						StackTraceElement[] stack = ((Throwable) ex).getStackTrace();
						ex = new NoSuchObjectException(ExceptionUtil.getBaseMessage((Throwable) ex));
						((Throwable) ex).setStackTrace(stack);
					}

					s.exType = ExceptionType.CHECKED_EXCEPTION;
				} else {
					s.exType = ExceptionType.UNCHECKED_EXCEPTION;
					ExceptionUtil.logException(tc, (Throwable) ex, s.getEJBMethodMetaData(), s.getBeanO());
					FFDCFilter.processException((Throwable) ex,
							"com.ibm.ejs.container.RemoteExceptionMappingStrategy.setUncheckedException", "200", this);
				}

				s.rootEx = this.findRootCause((Throwable) ex);
				if (!(ex instanceof RemoteException)) {
					ex = new RemoteException("", (Throwable) ex);
					((Throwable) ex).setStackTrace(s.rootEx.getStackTrace());
				}

				s.ivException = this.mapException(s, (RemoteException) ex);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "setUncheckedException returning : " + s.ivException);
				}

				s.ivException.setStackTrace(s.rootEx.getStackTrace());
				return s.ivException;
			}
		}
	}

	private Exception mapCSIException(EJSDeployedSupport s, CSIException e) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "mapCSIException: " + e);
		}

		Exception mappedException = null;
		String message = " ";
		Object rex;
		if (e instanceof CSITransactionRolledbackException) {
			if (e.detail instanceof HeuristicMixedException) {
				rex = new RemoteException("", e.detail);
			} else if (ContainerProperties.IncludeNestedExceptionsExtended
					&& (s.began || ContainerProperties.AllowSpecViolationOnRollback)
					&& e.detail instanceof HeuristicRollbackException) {
				rex = new RemoteException("", e.detail);
			} else {
				rex = new TransactionRolledbackException(message);
			}
		} else if (e instanceof CSIAccessException) {
			rex = new AccessException(message);
		} else if (e instanceof CSIInvalidTransactionException) {
			rex = new InvalidTransactionException(message);
		} else if (e instanceof CSITransactionRequiredException) {
			rex = new TransactionRequiredException(message);
		} else if (e instanceof CSIInvalidActivityException) {
			rex = new InvalidActivityException(message);
		} else if (e instanceof CSIActivityRequiredException) {
			rex = new ActivityRequiredException(message);
		} else if (e instanceof CSIActivityCompletedException) {
			rex = new ActivityCompletedException(message);
		} else if (e instanceof CSINoSuchObjectException) {
			rex = new NoSuchObjectException(message);
		} else {
			e.detail = null;
			rex = new RemoteException(e.getMessage());
		}

		if (ContainerProperties.IncludeNestedExceptions) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Nested exceptions will be included on rollback when possible. " + rex + ": " + s.began);
			}

			if (rex instanceof TransactionRolledbackException
					&& (s.began || ContainerProperties.AllowSpecViolationOnRollback)) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"Transaction was begun in context of this bean method, or the user allows the spec to be violated (ContainerProperties.AllowSpecViolationOnRollback="
									+ ContainerProperties.AllowSpecViolationOnRollback + ").");
				}

				rex = new RemoteException("", (Throwable) rex);
			}
		}

		((RemoteException) rex).detail = s.rootEx;
		((RemoteException) rex).setStackTrace(s.rootEx.getStackTrace());
		if (s.ivWrapper.ivInterface.ivORB) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "mapCSIException calling OrbUtils.mapException: " + rex);
			}

			int minorCode = e.getMinorCode();
			if (minorCode == 0) {
				mappedException = getOrbUtils().mapException((RemoteException) rex);
			} else {
				mappedException = getOrbUtils().mapException((RemoteException) rex, minorCode);
			}
		} else {
			mappedException = rex;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "mapCSIException returning: " + mappedException);
		}

		return (Exception) mappedException;
	}

	public Exception mapCSITransactionRolledBackException(EJSDeployedSupport s, CSITransactionRolledbackException ex)
			throws CSIException {
		if (s.rootEx == null) {
			s.rootEx = ExceptionUtil.findRootCause(ex);
		}

		Exception mappedEx = this.mapCSIException(s, ex);
		mappedEx.setStackTrace(s.rootEx.getStackTrace());
		return mappedEx;
	}

	private Exception mapEJBException(EJSDeployedSupport s, EJBException e) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "mapEJBException: " + e);
		}

		Exception mappedException = null;
		String message = " ";
		Object rex;
		if (e instanceof TransactionRolledbackLocalException) {
			rex = new TransactionRolledbackException(message);
		} else if (e instanceof AccessLocalException) {
			rex = new AccessException(message);
		} else if (e instanceof InvalidTransactionLocalException) {
			rex = new InvalidTransactionException(message);
		} else if (e instanceof NoSuchObjectLocalException) {
			rex = new NoSuchObjectException(message);
		} else if (e instanceof TransactionRequiredLocalException) {
			rex = new TransactionRequiredException(message);
		} else if (e instanceof InvalidActivityLocalException) {
			rex = new InvalidActivityException(message);
		} else if (e instanceof ActivityRequiredLocalException) {
			rex = new ActivityRequiredException(message);
		} else if (e instanceof ActivityCompletedLocalException) {
			rex = new ActivityCompletedException(message);
		} else {
			rex = new RemoteException(message);
		}

		((RemoteException) rex).detail = s.rootEx;
		((RemoteException) rex).setStackTrace(s.rootEx.getStackTrace());
		if (s.ivWrapper.ivInterface.ivORB) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "mapEJBException calling OrbUtils.mapException: " + rex);
			}

			mappedException = getOrbUtils().mapException((RemoteException) rex);
		} else {
			mappedException = rex;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "mapEJBException returning: " + mappedException);
		}

		return (Exception) mappedException;
	}
}