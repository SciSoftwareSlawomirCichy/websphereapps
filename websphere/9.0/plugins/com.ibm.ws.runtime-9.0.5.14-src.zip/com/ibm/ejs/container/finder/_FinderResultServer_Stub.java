package com.ibm.ejs.container.finder;

import java.rmi.RemoteException;
import java.rmi.UnexpectedException;
import java.util.Vector;
import javax.rmi.CORBA.Stub;
import javax.rmi.CORBA.Util;
import org.omg.CORBA.SystemException;
import org.omg.CORBA.portable.ApplicationException;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.RemarshalException;
import org.omg.CORBA.portable.ServantObject;
import org.omg.CORBA_2_3.portable.InputStream;

public class _FinderResultServer_Stub extends Stub implements FinderResultServer {
	private static final String[] _type_ids = new String[]{
			"RMI:com.ibm.ejs.container.finder.FinderResultServer:0000000000000000"};

	public String[] _ids() {
		return (String[]) _type_ids.clone();
	}

	public Vector getNextWrapperCollection(int var1, int var2) throws RemoteException {
		while (true) {
			Vector var4;
			if (!Util.isLocal(this)) {
				InputStream var27 = null;

				try {
					try {
						OutputStream var28 = this._request("getNextWrapperCollection", true);
						var28.write_long(var1);
						var28.write_long(var2);
						var27 = (InputStream) this._invoke(var28);
						var4 = (Vector) var27.read_value(class$java$util$Vector != null
								? class$java$util$Vector
								: (class$java$util$Vector = class$("java.util.Vector")));
					} catch (ApplicationException var21) {
						var27 = (InputStream) var21.getInputStream();
						String var29 = var27.read_string();
						throw new UnexpectedException(var29);
					} catch (RemarshalException var22) {
						continue;
					}
				} catch (SystemException var23) {
					throw Util.mapSystemException(var23);
				} finally {
					this._releaseReply(var27);
				}

				return var4;
			} else {
				ServantObject var3 = this._servant_preinvoke("getNextWrapperCollection",
						class$com$ibm$ejs$container$finder$FinderResultServer != null
								? class$com$ibm$ejs$container$finder$FinderResultServer
								: (class$com$ibm$ejs$container$finder$FinderResultServer = class$(
										"com.ibm.ejs.container.finder.FinderResultServer")));
				if (var3 != null) {
					try {
						Vector var7 = ((FinderResultServer) var3.servant).getNextWrapperCollection(var1, var2);
						var4 = (Vector) Util.copyObject(var7, this._orb());
					} catch (Throwable var25) {
						Throwable var8 = (Throwable) Util.copyObject(var25, this._orb());
						throw Util.wrapException(var8);
					} finally {
						this._servant_postinvoke(var3);
					}

					return var4;
				}
			}
		}
	}

	public int size() throws RemoteException {
		while (true) {
			int var2;
			if (!Util.isLocal(this)) {
				org.omg.CORBA.portable.InputStream var25 = null;

				try {
					try {
						OutputStream var5 = this._request("size", true);
						var25 = this._invoke(var5);
						var2 = var25.read_long();
					} catch (ApplicationException var19) {
						var25 = var19.getInputStream();
						String var26 = var25.read_string();
						throw new UnexpectedException(var26);
					} catch (RemarshalException var20) {
						continue;
					}
				} catch (SystemException var21) {
					throw Util.mapSystemException(var21);
				} finally {
					this._releaseReply(var25);
				}

				return var2;
			} else {
				ServantObject var1 = this._servant_preinvoke("size",
						class$com$ibm$ejs$container$finder$FinderResultServer != null
								? class$com$ibm$ejs$container$finder$FinderResultServer
								: (class$com$ibm$ejs$container$finder$FinderResultServer = class$(
										"com.ibm.ejs.container.finder.FinderResultServer")));
				if (var1 != null) {
					try {
						var2 = ((FinderResultServer) var1.servant).size();
					} catch (Throwable var23) {
						Throwable var6 = (Throwable) Util.copyObject(var23, this._orb());
						throw Util.wrapException(var6);
					} finally {
						this._servant_postinvoke(var1);
					}

					return var2;
				}
			}
		}
	}
}