package com.google.common.reflect;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.reflect.TypeResolver.1;
import com.google.common.reflect.TypeResolver.TypeMappingIntrospector;
import com.google.common.reflect.Types.WildcardTypeImpl;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

class TypeResolver {
	private final ImmutableMap<TypeVariable<?>, Type> typeTable;

	public TypeResolver() {
		this.typeTable = ImmutableMap.of();
	}

	private TypeResolver(ImmutableMap<TypeVariable<?>, Type> typeTable) {
		this.typeTable = typeTable;
	}

	static TypeResolver accordingTo(Type type) {
		return (new TypeResolver()).where(TypeMappingIntrospector.getTypeMappings(type));
	}

	public final TypeResolver where(Type formal, Type actual) {
		Map<TypeVariable<?>, Type> mappings = Maps.newHashMap();
		populateTypeMappings(mappings, (Type) Preconditions.checkNotNull(formal),
				(Type) Preconditions.checkNotNull(actual));
		return this.where(mappings);
	}

	final TypeResolver where(Map<? extends TypeVariable<?>, ? extends Type> mappings) {
		Builder<TypeVariable<?>, Type> builder = ImmutableMap.builder();
		builder.putAll(this.typeTable);
		Iterator i$ = mappings.entrySet().iterator();

		while (i$.hasNext()) {
			Entry<? extends TypeVariable<?>, ? extends Type> mapping = (Entry) i$.next();
			TypeVariable<?> variable = (TypeVariable) mapping.getKey();
			Type type = (Type) mapping.getValue();
			Preconditions.checkArgument(!variable.equals(type), "Type variable %s bound to itself",
					new Object[]{variable});
			builder.put(variable, type);
		}

		return new TypeResolver(builder.build());
	}

	private static void populateTypeMappings(Map<TypeVariable<?>, Type> mappings, Type from, Type to) {
		if (!from.equals(to)) {
			if (from instanceof TypeVariable) {
				mappings.put((TypeVariable) from, to);
			} else if (from instanceof GenericArrayType) {
				populateTypeMappings(mappings, ((GenericArrayType) from).getGenericComponentType(),
						(Type) checkNonNullArgument(Types.getComponentType(to), "%s is not an array type.", to));
			} else {
				Type[] fromUpperBounds;
				Type[] toUpperBounds;
				if (from instanceof ParameterizedType) {
					ParameterizedType fromParameterizedType = (ParameterizedType) from;
					ParameterizedType toParameterizedType = (ParameterizedType) expectArgument(ParameterizedType.class,
							to);
					Preconditions.checkArgument(
							fromParameterizedType.getRawType().equals(toParameterizedType.getRawType()),
							"Inconsistent raw type: %s vs. %s", new Object[]{from, to});
					fromUpperBounds = fromParameterizedType.getActualTypeArguments();
					toUpperBounds = toParameterizedType.getActualTypeArguments();
					Preconditions.checkArgument(fromUpperBounds.length == toUpperBounds.length);

					for (int i = 0; i < fromUpperBounds.length; ++i) {
						populateTypeMappings(mappings, fromUpperBounds[i], toUpperBounds[i]);
					}
				} else {
					if (!(from instanceof WildcardType)) {
						throw new IllegalArgumentException("No type mapping from " + from);
					}

					WildcardType fromWildcardType = (WildcardType) from;
					WildcardType toWildcardType = (WildcardType) expectArgument(WildcardType.class, to);
					fromUpperBounds = fromWildcardType.getUpperBounds();
					toUpperBounds = toWildcardType.getUpperBounds();
					Type[] fromLowerBounds = fromWildcardType.getLowerBounds();
					Type[] toLowerBounds = toWildcardType.getLowerBounds();
					Preconditions.checkArgument(
							fromUpperBounds.length == toUpperBounds.length
									&& fromLowerBounds.length == toLowerBounds.length,
							"Incompatible type: %s vs. %s", new Object[]{from, to});

					int i;
					for (i = 0; i < fromUpperBounds.length; ++i) {
						populateTypeMappings(mappings, fromUpperBounds[i], toUpperBounds[i]);
					}

					for (i = 0; i < fromLowerBounds.length; ++i) {
						populateTypeMappings(mappings, fromLowerBounds[i], toLowerBounds[i]);
					}
				}
			}

		}
	}

	public final Type resolveType(Type type) {
		Preconditions.checkNotNull(type);
		if (type instanceof TypeVariable) {
			return this.resolveTypeVariable((TypeVariable) type);
		} else if (type instanceof ParameterizedType) {
			return this.resolveParameterizedType((ParameterizedType) type);
		} else if (type instanceof GenericArrayType) {
			return this.resolveGenericArrayType((GenericArrayType) type);
		} else if (type instanceof WildcardType) {
			WildcardType wildcardType = (WildcardType) type;
			return new WildcardTypeImpl(this.resolveTypes(wildcardType.getLowerBounds()),
					this.resolveTypes(wildcardType.getUpperBounds()));
		} else {
			return type;
		}
	}

	private Type[] resolveTypes(Type[] types) {
		Type[] result = new Type[types.length];

		for (int i = 0; i < types.length; ++i) {
			result[i] = this.resolveType(types[i]);
		}

		return result;
	}

	private Type resolveGenericArrayType(GenericArrayType type) {
		Type componentType = this.resolveType(type.getGenericComponentType());
		return Types.newArrayType(componentType);
	}

	private Type resolveTypeVariable(TypeVariable<?> var) {
      TypeResolver guarded = new 1(this, this.typeTable, var, this);
      return this.resolveTypeVariable(var, guarded);
   }

	Type resolveTypeVariable(TypeVariable<?> var, TypeResolver guardedResolver) {
		Preconditions.checkNotNull(guardedResolver);
		Type type = (Type) this.typeTable.get(var);
		if (type == null) {
			Type[] bounds = var.getBounds();
			return bounds.length == 0
					? var
					: Types.newTypeVariable(var.getGenericDeclaration(), var.getName(),
							guardedResolver.resolveTypes(bounds));
		} else {
			return guardedResolver.resolveType(type);
		}
	}

	private ParameterizedType resolveParameterizedType(ParameterizedType type) {
		Type owner = type.getOwnerType();
		Type resolvedOwner = owner == null ? null : this.resolveType(owner);
		Type resolvedRawType = this.resolveType(type.getRawType());
		Type[] vars = type.getActualTypeArguments();
		Type[] resolvedArgs = new Type[vars.length];

		for (int i = 0; i < vars.length; ++i) {
			resolvedArgs[i] = this.resolveType(vars[i]);
		}

		return Types.newParameterizedTypeWithOwner(resolvedOwner, (Class) resolvedRawType, resolvedArgs);
	}

	private static <T> T checkNonNullArgument(T arg, String format, Object... messageParams) {
		Preconditions.checkArgument(arg != null, format, messageParams);
		return arg;
	}

	private static <T> T expectArgument(Class<T> type, Object arg) {
		try {
			return type.cast(arg);
		} catch (ClassCastException var3) {
			throw new IllegalArgumentException(arg + " is not a " + type.getSimpleName());
		}
	}
}