package com.ibm.ffdc.impl;

import com.ibm.ffdc.Manager;
import com.ibm.ffdc.impl.Ffdc.1;
import com.ibm.ffdc.impl.Ffdc.2;
import com.ibm.ffdc.impl.Ffdc.3;
import com.ibm.ffdc.impl.Ffdc.4;
import com.ibm.ffdc.provider.FfdcProvider;
import com.ibm.ffdc.util.provider.FfdcOnDirProvider;
import com.ibm.ffdc.util.provider.FfdcOnFileProvider;
import com.ibm.ffdc.util.provider.FfdcOnPrintStreamProvider;
import com.ibm.ffdc.util.provider.Incident;
import java.io.File;
import java.io.FileOutputStream;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Ffdc implements Manager {
	private static FfdcProvider provider;
	static final String SYSTEM_ERR = "System.err";
	static final String SYSTEM_OUT = "System.out";
	static final String SUPPRESS = "Suppress";
	private static final String thisClass = Ffdc.class.getName();
	public static final String resourceBundleName = "com.ibm.ffdc.FFDCBundleMessages";
	private static Logger tracer;
	static final String FFDC_LOG = "com.ibm.ffdc.log";
	static final String FFDC_LOG_ENV = "com_ibm_ffdc_log";
	static final String DFLT_LOC = "user.install.root";
	static final String DFLT_LOC_ENV = "USER_INSTALL_ROOT";

	public Ffdc() {
		setup();
	}

	public String toString() {
		return asString();
	}

	private static String asString() {
		return Ffdc.class.getName() + "<" + provider + ">";
	}

	public static synchronized void set(FfdcProvider anFfdcProvider) {
		assert anFfdcProvider != null;

		FfdcProvider oldProvider = provider;
		provider = anFfdcProvider;
		if (oldProvider != null) {
			if (tracer.isLoggable(Level.FINER)) {
				tracer.logp(Level.FINER, thisClass, "set", "FfdcProvider uninstalled:" + toString(oldProvider));
			}

			release(oldProvider);
		}

		if (tracer.isLoggable(Level.FINER)) {
			tracer.logp(Level.FINER, thisClass, "set", "FfdcProvider installed:" + toString(provider));
		}

	}

	private static void release(FfdcProvider oldProvider) {
		try {
			oldProvider.release();
		} catch (Throwable var2) {
			tracer.logp(Level.FINER, thisClass, "set", "FFDC provider error", var2);
		}

	}

	public static synchronized void unset() {
		FfdcProvider oldProvider = provider;
		if (oldProvider != null && !(oldProvider instanceof EmptyProvider)) {
			set(new EmptyProvider());
		}
	}

	private static synchronized FfdcProvider setFailsafeProvider(Throwable th) {
		FfdcProvider oldProvider = provider;
		if (oldProvider != null && oldProvider instanceof EmptyProvider) {
			return oldProvider;
		} else {
			if (tracer.isLoggable(Level.INFO)) {
				tracer.logp(Level.INFO, thisClass, "setFailsafeProvider", "FFDCProviderAborted", toString(oldProvider));
				tracer.logp(Level.INFO, thisClass, "setFailsafeProvider", "FFDCProviderAbortedE", th);
			}

			EmptyProvider p = new EmptyProvider();
			set(p);
			return p;
		}
	}

	public static synchronized void abort(FfdcProvider failedProvider, Throwable th) {
		if (provider == failedProvider) {
			setFailsafeProvider(th);
		}

	}

	static String toString(FfdcProvider provider) {
		try {
			return String.valueOf(provider);
		} catch (Throwable var2) {
			if (tracer.isLoggable(Level.FINER)) {
				tracer.logp(Level.FINER, thisClass, "toString", "FFDC detects failure", var2);
			}

			return provider.getClass().getName();
		}
	}

	public com.ibm.ffdc.Ffdc getFfdc(Throwable exception, Object reporter, String sourceId, String probeId) {
		try {
			return provider.getFfdc(exception, reporter, sourceId, probeId);
		} catch (Throwable var6) {
			return setFailsafeProvider(var6).getFfdc(exception, reporter, sourceId, probeId);
		}
	}

	public com.ibm.ffdc.Ffdc getFfdc(Throwable exception, Object reporter, String sourceId) {
		try {
			return provider.getFfdc(exception, reporter, sourceId);
		} catch (Throwable var5) {
			return setFailsafeProvider(var5).getFfdc(exception, reporter, sourceId);
		}
	}

	public void log(Throwable exception, Object reporter, String sourceId, String probeId, Object... args) {
		try {
			provider.log(exception, reporter, sourceId, probeId, args);
		} catch (Throwable var7) {
			setFailsafeProvider(var7);
		}

	}

	public void log(Throwable exception, Object reporter, String sourceId, String probeId) {
		try {
			provider.log(exception, reporter, sourceId, probeId);
		} catch (Throwable var6) {
			setFailsafeProvider(var6);
		}

	}

	public List<Incident> getIncidents() {
		return provider.getIncidents();
	}

	public boolean unblockLogging(Incident incident) {
		return provider.unblockLogging(incident);
	}

	public void unblockLogging() {
		provider.unblockLogging();
	}

	private static synchronized void setup() {
		if (provider == null) {
			Object provider;
			try {
				provider = makeDefaultProvider();
			} catch (Throwable var2) {
				provider = new EmptyProvider();
				tracer.logp(Level.WARNING, thisClass, "setup", "FFDCFailSafeErrChk", var2);
			}

			set((FfdcProvider) provider);
		}
	}

	public static FfdcProvider makeDefaultProvider() throws Exception {
		String ffdclog = getFfdcLog();
		if (ffdclog != null && !String.valueOf((Object) null).equalsIgnoreCase(ffdclog)
				&& !"System.err".equalsIgnoreCase(ffdclog)) {
			if ("Suppress".equalsIgnoreCase(ffdclog)) {
				return new EmptyProvider();
			} else if ("System.out".equalsIgnoreCase(ffdclog)) {
				return new FfdcOnPrintStreamProvider(System.out, "System.out");
			} else {
				File logfile = new File(ffdclog);
				if (exists(logfile)) {
					return (FfdcProvider) (isDirectory(logfile)
							? new FfdcOnDirProvider(logfile)
							: new FfdcOnFileProvider(logfile, getFileOutputStream(logfile)));
				} else {
					return (FfdcProvider) (!ffdclog.endsWith(File.separator) && !ffdclog.endsWith("/")
							? new FfdcOnFileProvider(logfile, getFileOutputStream(logfile))
							: new FfdcOnDirProvider(logfile));
				}
			}
		} else {
			return new FfdcOnPrintStreamProvider(System.err, "System.err");
		}
	}

	private static boolean isDirectory(File f) throws PrivilegedActionException {
      return (Boolean)AccessController.doPrivileged(new 1(f));
   }

	private static boolean exists(File f) throws PrivilegedActionException {
      return (Boolean)AccessController.doPrivileged(new 2(f));
   }

	private static FileOutputStream getFileOutputStream(File log) throws PrivilegedActionException {
      return (FileOutputStream)AccessController.doPrivileged(new 3(log));
   }

	private static String getFfdcLog() throws PrivilegedActionException {
      String log = (String)AccessController.doPrivileged(new 4());
      tracer.logp(Level.FINER, thisClass, "getFfdcLog", "FFDC provider selection from prop or env or other resulted in: " + log);
      return log;
   }

	public static FfdcProvider getProvider() {
		return provider;
	}

	public static Logger getLogger() {
		return tracer;
	}

	static {
		try {
			tracer = Logger.getLogger(thisClass, "com.ibm.ffdc.FFDCBundleMessages");
		} catch (Throwable var1) {
			tracer = Logger.getLogger(thisClass);
			tracer.logp(Level.WARNING, "com.ibm.ffdc.impl.Ffdc", "<clinit>", "Unable to find FFDC message bundle.");
		}

	}
}