package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerAS;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSHome;
import com.ibm.ejs.container.HomeInternal;
import com.ibm.ejs.container.StatefulBeanReaper;
import com.ibm.ejs.container.passivator.StatefulPassivator;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.container.util.locking.LockTable;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.cache.Cache;
import com.ibm.ejs.util.cache.Element;
import com.ibm.websphere.csi.CacheElement;
import com.ibm.websphere.csi.EJBCache;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.PassivationPolicy;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.ws.ejbcontainer.diagnostics.TrDumpWriter;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ejbcontainer.runtime.EJBRuntime;
import com.ibm.ws.util.cache.DiscardWithLockStrategy;
import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.concurrent.ScheduledExecutorService;
import javax.ejb.DuplicateKeyException;

public final class Activator implements DiscardWithLockStrategy {
	public static final int UNCACHED_ACTIVATION_STRATEGY = 0;
	public static final int STATEFUL_ACTIVATE_ONCE_ACTIVATION_STRATEGY = 1;
	public static final int STATEFUL_ACTIVATE_TRAN_ACTIVATION_STRATEGY = 2;
	public static final int STATEFUL_ACTIVATE_SESSION_ACTIVATION_STRATEGY = 3;
	public static final int OPTA_ENTITY_ACTIVATION_STRATEGY = 4;
	public static final int OPTB_ENTITY_ACTIVATION_STRATEGY = 5;
	public static final int OPTC_ENTITY_ACTIVATION_STRATEGY = 6;
	public static final int ENTITY_SESSIONAL_TRAN_ACTIVATION_STRATEGY = 7;
	public static final int READONLY_ENTITY_ACTIVATION_STRATEGY = 8;
	private static final int NUM_STRATEGIES = 9;
	protected static final String[] svStrategyStrs = new String[]{"Uncached", "Stateful Once", "Stateful Transaction",
			"Stateful Session", "Entity Option A", "Entity Option B", "Entity Option C", "Entity Option C Sessional",
			"Entity Read Only"};
	EJBCache beanCache;
	LockTable activationLocks;
	protected EJSContainer container;
	private ActivationStrategy[] strategies;
	StatefulPassivator passivator;
	private static final TraceComponent tc = Tr.register(Activator.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	StatefulBeanReaper statefulBeanReaper;

	public Activator(EJSContainer container, EJBCache cache, PassivationPolicy passivationPolicy,
			StatefulPassivator passivator, SfFailoverCache failoverCache) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", new Object[]{container, cache, passivationPolicy});
		}

		ScheduledExecutorService deferrableExecutor = container.getEJBRuntime().getDeferrableScheduledExecutorService();
		if (EJSPlatformHelper.isZOS()) {
			long sweepInterval = 0L;
			Long sweepIntervallong = Long.getLong("com.ibm.websphere.bean.delete.sleep.time");
			if (sweepIntervallong != null) {
				sweepInterval = sweepIntervallong * 1000L;
			}

			this.statefulBeanReaper = new StatefulBeanReaper(this, cache.getNumBuckets(), sweepInterval, failoverCache,
					deferrableExecutor);
		} else {
			this.statefulBeanReaper = new StatefulBeanReaper(this, cache.getNumBuckets(), failoverCache,
					deferrableExecutor);
		}

		this.initialize(container, cache, passivationPolicy, passivator, failoverCache);
		if (!passivationPolicy.equals(PassivationPolicy.ON_DEMAND)) {
			this.statefulBeanReaper.start();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	private void initialize(EJSContainer container, EJBCache cache, PassivationPolicy passivationPolicy,
			StatefulPassivator passivator, SfFailoverCache failoverCache) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "initialize");
		}

		this.container = container;
		this.beanCache = cache;
		this.passivator = passivator;
		this.activationLocks = new LockTable(this.beanCache.getNumBuckets());
		EJBRuntime runtime = container.getEJBRuntime();
		this.strategies = new ActivationStrategy[9];

		for (int type = 0; type < this.strategies.length; ++type) {
			this.strategies[type] = runtime.createActivationStrategy(this, type, passivationPolicy);
		}

		this.beanCache.setDiscardStrategy(this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "initialize");
		}

	}

	public BeanO preInvokeActivateBean(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		return beanId.getActivationStrategy().atActivate(threadData, tx, beanId);
	}

	public BeanO activateBean(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		BeanO beanO = null;

		try {
			beanO = beanId.getActivationStrategy().atActivate(threadData, tx, beanId);
		} finally {
			if (beanO != null) {
				threadData.popCallbackBeanO();
			}

		}

		return beanO;
	}

	public void postInvoke(ContainerTx tx, BeanO bean) {
		bean.getActivationStrategy().atPostInvoke(tx, bean);
	}

	public BeanO addBean(ContainerTx tx, BeanO bean) throws DuplicateKeyException, RemoteException {
		return bean.getHome().getActivationStrategy().atCreate(tx, bean);
	}

	public boolean lockBean(ContainerTx tx, BeanId beanId) throws RemoteException {
		return beanId.getActivationStrategy().atLock(tx, beanId);
	}

	public void removeBean(ContainerTx tx, BeanO bean) {
		bean.getActivationStrategy().atRemove(tx, bean);
	}

	public BeanO getBean(ContainerTx tx, BeanId id) {
		return id.getActivationStrategy().atGet(tx, id);
	}

	public void commitBean(ContainerTx tx, BeanO bean) {
		bean.getActivationStrategy().atCommit(tx, bean);
	}

	public void unitOfWorkEnd(ContainerAS as, BeanO bean) {
		bean.getActivationStrategy().atUnitOfWorkEnd(as, bean);
	}

	public void rollbackBean(ContainerTx tx, BeanO bean) {
		bean.getActivationStrategy().atRollback(tx, bean);
	}

	public final void enlistBean(ContainerTx tx, BeanO bean) {
		bean.getActivationStrategy().atEnlist(tx, bean);
	}

	public void setCacheSweepInterval(long sweepInterval) {
		this.beanCache.setSweepInterval(sweepInterval);
	}

	public void setCachePreferredMaxSize(int size) {
		this.beanCache.setCachePreferredMaxSize(size);
	}

	public final ActivationStrategy getActivationStrategy(int id) {
		return this.strategies[id];
	}

	public final ActivationStrategy getActivationStrategy(EJSHome home, int id) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getActivationStrategy: " + this.beanCache.getName() + " used for " + home.getJ2EEName());
		}

		return this.strategies[id];
	}

	public static final String getActivationStrategyString(int id) {
		return id >= 0 && id < svStrategyStrs.length ? svStrategyStrs[id] : "Unknown (" + id + ")";
	}

	public void discardObject(EJBCache cache, Object key, Object object) throws RemoteException {
		BeanO bean = (BeanO) object;
		bean.getActivationStrategy().atDiscard(bean);
	}

	public LockTable getEvictionLockTable() {
		return this.activationLocks;
	}

	public void timeoutBean(BeanId beanId) throws RemoteException {
		beanId.getActivationStrategy().atTimeout(beanId);
	}

	public void terminate() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "terminate");
		}

		this.statefulBeanReaper.cancel();
		this.statefulBeanReaper.finalSweep(this.passivator);
		this.beanCache.terminate();
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "terminate");
		}

	}

	public void uninstallBean(J2EEName homeName) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "uninstallBean " + homeName);
		}

		int numEnumerated = 0;
		int numRemoved = 0;
		int numTimedout = 0;
		Enumeration enumerate = this.beanCache.enumerateElements();

		while (true) {
			BeanO cacheMember;
			J2EEName cacheHomeName;
			BeanId beanId;
			do {
				if (!enumerate.hasMoreElements()) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, this.beanCache.getName() + ": Uninstalled " + numRemoved
								+ " bean instances (total = " + numEnumerated + ")");
					}

					for (Iterator statefulBeans = this.statefulBeanReaper
							.getPassivatedStatefulBeanIds(homeName); statefulBeans.hasNext(); ++numTimedout) {
						beanId = (BeanId) statefulBeans.next();
						if (EJSPlatformHelper.isZOS()) {
							this.statefulBeanReaper.remove(beanId);
						} else {
							beanId.getActivationStrategy().atUninstall(beanId, (BeanO) null);
						}
					}

					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Passivated Beans: Uninstalled " + numTimedout + " bean instances");
					}

					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "uninstallBean");
					}

					return;
				}

				cacheMember = (BeanO) ((CacheElement) enumerate.nextElement()).getObject();
				beanId = cacheMember.getId();
				cacheHomeName = beanId.getJ2EEName();
				++numEnumerated;
			} while (!cacheHomeName.equals(homeName));

			HomeInternal home = cacheMember.getHome();
			BeanMetaData bmd = beanId.getBeanMetaData();
			if (EJSPlatformHelper.isZOS() && !bmd.ivHasAppManagedPersistenceContext
					&& !bmd.ivHasCMExtendedPersistenceContext) {
				try {
					home.getActivationStrategy().atPassivate(beanId);
				} catch (Exception var13) {
					Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{beanId, this, var13});
				}
			} else {
				home.getActivationStrategy().atUninstall(beanId, cacheMember);
			}

			++numRemoved;
		}
	}

	public int size() {
		int size = this.beanCache.getSize();
		return size;
	}

	public void dump() {
		if (tc.isDumpEnabled()) {
			this.introspect(new TrDumpWriter(tc));
		}
	}

	public void introspect(IntrospectionWriter writer) {
		Enumeration<Element> vEnum = ((Cache) this.beanCache).enumerateElements();
		writer.printHeader("Activator Dump : " + this.beanCache.getName());

		while (vEnum.hasMoreElements()) {
			Element element = (Element) vEnum.nextElement();
			Object key = element.getKey();
			if (key instanceof TransactionKey) {
				Object bean = element.getObject();
				String state = element.stateToString();
				ContainerTx tx = ((TransactionKey) key).tx;
				writer.println(bean + state + " : " + tx);
			} else {
				writer.println(element.toString());
			}
		}

		writer.printFooter();
	}
}