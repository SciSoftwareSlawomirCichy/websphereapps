package com.ibm.ws.wim;

import com.ibm.websphere.management.repository.ConfigRepository;
import com.ibm.websphere.management.repository.ConfigRepositoryFactory;
import com.ibm.websphere.security.auth.WSSubject;
import com.ibm.websphere.security.cred.WSCredential;
import com.ibm.websphere.wim.ProfileService;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.AttributeNotSupportedException;
import com.ibm.websphere.wim.exception.CertificateMapFailedException;
import com.ibm.websphere.wim.exception.CertificateMapNotSupportedException;
import com.ibm.websphere.wim.exception.ChangeControlException;
import com.ibm.websphere.wim.exception.DefaultParentNotFoundException;
import com.ibm.websphere.wim.exception.DuplicateLogonIdException;
import com.ibm.websphere.wim.exception.EntityAlreadyExistsException;
import com.ibm.websphere.wim.exception.EntityIdentifierNotSpecifiedException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.EntityNotInRealmScopeException;
import com.ibm.websphere.wim.exception.EntityTypeNotSupportedException;
import com.ibm.websphere.wim.exception.InvalidIdentifierException;
import com.ibm.websphere.wim.exception.InvalidUniqueIdException;
import com.ibm.websphere.wim.exception.MaxResultsExceededException;
import com.ibm.websphere.wim.exception.MissingSearchControlException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.PageControlException;
import com.ibm.websphere.wim.exception.PasswordCheckFailedException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.SortControlException;
import com.ibm.websphere.wim.exception.SubscriberCriticalException;
import com.ibm.websphere.wim.exception.UpdateOperationalPropertyException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.ws.wim.config.DynamicRealmConfig;
import com.ibm.ws.wim.env.ICacheUtil;
import com.ibm.ws.wim.federation.FederationEntity;
import com.ibm.ws.wim.lookaside.LookasideRepository;
import com.ibm.ws.wim.pluginmanager.PluginManager;
import com.ibm.ws.wim.security.authz.EntitlementRequest;
import com.ibm.ws.wim.security.authz.EntityResource;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.util.AsyncUtils;
import com.ibm.ws.wim.util.ControlsHelper;
import com.ibm.ws.wim.util.DataGraphHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.SortHandler;
import com.ibm.ws.wim.util.StringUtil;
import com.ibm.ws.wim.util.UniqueNameHelper;
import com.ibm.ws.wim.xpath.ParseException;
import com.ibm.ws.wim.xpath.TokenMgrError;
import com.ibm.ws.wim.xpath.WIMXPathInterpreter;
import com.ibm.ws.wim.xpath.mapping.datatype.FederationLogicalNode;
import com.ibm.ws.wim.xpath.mapping.datatype.FederationParenthesisNode;
import com.ibm.ws.wim.xpath.mapping.datatype.LogicalNode;
import com.ibm.ws.wim.xpath.mapping.datatype.ParenthesisNode;
import com.ibm.ws.wim.xpath.mapping.datatype.PropertyNode;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;
import com.ibm.ws.wim.xpath.util.ProfileManagerMetadataMapper;
import com.ibm.wsspi.wim.Repository;
import commonj.sdo.ChangeSummary;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Type;
import commonj.sdo.ChangeSummary.Setting;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.Subject;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.ecore.sdo.EChangeSummary;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.EDataObject;

public class ProfileManager implements ProfileService {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static Map<String, ProfileManager> singleton;
	private SchemaManager schemaMgr = null;
	private ConfigManager configMgr = null;
	private RepositoryManager reposMgr = null;
	private RealmManager realmMgr = null;
	private ProfileSecurityManager profileSecManager = null;
	private String pagingSearchCacheName = "WIMSearchCacheName";
	private ICacheUtil pagingSearchCache = null;
	private PropertyManager propMgr = null;
	private int searchTimeOut;
	private int maxSearchResults;
	private int maxTotalPagingSearchResults;
	private boolean pagingEntityObject = false;
	private boolean pagingCachesDiskOffLoad = false;
	private boolean throwEntityNotFoundException = false;
	private int pagedEntryTimeToLive;
	private static final String LA = "LA";
	private static final String REPOS = "REPOS";
	private Set<String> laSupportedProps = null;
	private int dMapPriority = 1;
	private static final String TOTAL_PAGED_RESULTS = "TotalPagedResults";
	private static final char CREATE = 'c';
	private static final char GET = 'g';
	private static final char DELETE = 'd';
	private static final char UPDATE = 'u';
	private static final char SEARCH = 's';
	private static final char LOGIN = 'l';
	private static final String CREATE_EMITTER = "create";
	private static final String GET_EMITTER = "get";
	private static final String DELETE_EMITTER = "delete";
	private static final String UPDATE_EMITTER = "update";
	private static final String SEARCH_EMITTER = "search";
	private static final String LOGIN_EMITTER = "login";
	private static final String THROW_ENTITY_NOT_FOUND_EXCEPTION = "com.ibm.ws.wim.search.ThrowEntityNotFoundException";
	private PluginManager pluginManager = null;
	private ConfigRepository repository = null;

	private ProfileManager() throws WIMException {
		this.initialize();
	}

	public static synchronized ProfileManager singleton() throws WIMException {
		String var0 = DomainManagerUtils.getDomainId();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new ProfileManager());
		}

		return (ProfileManager) singleton.get(var0);
	}

	public static void clearCache(String var0) {
		singleton.put(var0, (Object) null);
	}

	private DataObject getDataGraphClone(DataObject var1) throws WIMException {
		DataObject var2 = DataGraphHelper.cloneRootDataObject(var1);
		ChangeSummary var3 = var1.getDataGraph().getChangeSummary();
		if (var3 != null) {
			EChangeSummary var4 = (EChangeSummary) DataGraphHelper.cloneEObject((EDataObject) var3);
			((EDataGraph) var2.getDataGraph()).setEChangeSummary(var4);
		}

		return var2;
	}

	private DataObject getDeepDataGraphClone(DataObject var1) throws WIMException {
		DataObject var2 = DataGraphHelper.deepCloneRootDataObject(var1);
		return var2;
	}

	private DataObject genericProfileManagerMethod(String var1, String var2, char var3, DataObject var4)
			throws WIMException {
		DataObject var5 = null;
		DataObject var6 = null;
		DataObject var7 = null;
		boolean var8 = false;

		try {
			RealmManager.setRealmOnThread(this.getRealmName(var4));
			if (var4 != null && !var4.getType().getName().equals("RootType")) {
				throw new WIMApplicationException("INVALID_DATA_OBJECT_TYPE",
						WIMMessageHelper.generateMsgParms(var4.getType().getName(), var1, "RootType"), CLASSNAME, var1);
			}

			ChangeSummary var9 = var4.getDataGraph().getChangeSummary();
			if (var9 != null) {
				var6 = this.getDeepDataGraphClone(var4);
			} else {
				var6 = this.getDataGraphClone(var4);
			}

			var6 = this.pluginManager.preExitCall(var2, var6);
			var8 = true;
			switch (var3) {
				case 'c' :
					var7 = this.createImpl(var6);
					break;
				case 'd' :
					var7 = this.deleteImpl(var6);
				case 'e' :
				case 'f' :
				case 'h' :
				case 'i' :
				case 'j' :
				case 'k' :
				case 'm' :
				case 'n' :
				case 'o' :
				case 'p' :
				case 'q' :
				case 'r' :
				case 't' :
				default :
					break;
				case 'g' :
					var7 = this.getImpl(var6);
					break;
				case 'l' :
					var7 = this.loginImpl(var6);
					break;
				case 's' :
					var7 = this.searchImpl(var6);
					break;
				case 'u' :
					var7 = this.updateImpl(var6);
			}

			var5 = this.pluginManager.postExitCall(var2, var6, var7);
			if (var3 == 'g' && !var5.getDataGraph().getChangeSummary().isLogging()) {
				var5.getDataGraph().getChangeSummary().beginLogging();
			}
		} catch (SubscriberCriticalException var17) {
			throw new WIMApplicationException("SUBSCRIBER_CRITICAL_EXCEPTION",
					WIMMessageHelper.generateMsgParms(
							var17.getCause() != null ? var17.getCause().getMessage() : var17.getMessage()),
					Level.SEVERE, CLASSNAME, var1, var17.getCause());
		} catch (WIMException var18) {
			try {
				if (var8) {
					this.pluginManager.postExitCall(var2, var6, var7);
				}
			} catch (Exception var16) {
				if (trcLogger.isLoggable(Level.WARNING)) {
					trcLogger.logp(Level.WARNING, CLASSNAME, "WIM_API " + var1, "GENERIC", var16);
				}
			}

			throw var18;
		} finally {
			RealmManager.clearRealmOnThread();
		}

		return var5;
	}

	public DataObject create(DataObject var1) throws WIMException {
		String var3 = CLASSNAME + "." + "create";
		return this.genericProfileManagerMethod("create", var3, 'c', var1);
	}

	public DataObject get(DataObject var1) throws WIMException {
		String var3 = CLASSNAME + "." + "get";
		return this.genericProfileManagerMethod("get", var3, 'g', var1);
	}

	public DataObject delete(DataObject var1) throws WIMException {
		String var3 = CLASSNAME + "." + "delete";
		return this.genericProfileManagerMethod("delete", var3, 'd', var1);
	}

	public DataObject update(DataObject var1) throws WIMException {
		String var3 = CLASSNAME + "." + "update";
		return this.genericProfileManagerMethod("update", var3, 'u', var1);
	}

	public DataObject search(DataObject var1) throws WIMException {
		String var3 = CLASSNAME + "." + "search";
		return this.genericProfileManagerMethod("search", var3, 's', var1);
	}

	public DataObject login(DataObject var1) throws WIMException {
		String var3 = CLASSNAME + "." + "login";
		return this.genericProfileManagerMethod("login", var3, 'l', var1);
	}

	public DataObject createImpl(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createImpl", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var3 = DataGraphHelper.cloneRootDataObject(var1);
		DataObject var4 = null;
		int var5 = -1;
		DataObject var6 = null;
		List var7 = null;
		DataObject var9;
		String var10;
		String var14;
		Map var15;
		DataObject var17;
		String var19;
		DataObject var22;
		DataObject var23;
		String var26;
		if (AsyncUtils.isCheckAsyncOperationStatus(var3)) {
			var26 = AsyncUtils.getRepositoryId(var3);
			var5 = this.reposMgr.getRepositoryIndexByRepositoryID(var26);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "createImpl",
						"Checking the status of async create in repository " + var26);
			}

			var4 = this.reposMgr.getRepositories()[var5].create(var3);
		} else {
			int var8 = this.reposMgr.getNumberOfRepositories();
			var9 = null;
			var10 = null;
			String var11 = RealmManager.getRealmOnThread();
			List var12 = var3.getList("entities");
			if (var12 == null) {
				return null;
			}

			if (var12.size() > 1) {
				throw new OperationNotSupportedException("ACTION_MULTIPLE_ENTITIES_SPECIFIED",
						WIMMessageHelper.generateMsgParms("CREATE"), CLASSNAME, "createImpl");
			}

			if (var12.size() == 0) {
				throw new EntityNotFoundException("MISSING_ENTITY_DATA_OBJECT",
						WIMMessageHelper.generateMsgParms("create"), CLASSNAME, "createImpl");
			}

			if (var12.size() > 1) {
				throw new OperationNotSupportedException("ACTION_MULTIPLE_ENTITIES_SPECIFIED",
						WIMMessageHelper.generateMsgParms("UPDATE"), CLASSNAME, "createImpl");
			}

			DataObject var13 = (DataObject) var12.get(0);
			var14 = this.schemaMgr.getQualifiedTypeName(var13.getType());
			this.profileSecManager.checkPermission_CREATE(new EntityResource(var3, var13));
			this.checkCreateAndModifyTimeStamp(var14, var13);
			var15 = ControlsHelper.getControlMap(var3);
			DataObject var16 = (DataObject) var15.get("ViewControl");
			if (var16 != null) {
				var17 = this.pluginManager.inlineExitCall(CLASSNAME + "." + "create", var3, "createInViewExplicit");
				return var17;
			}

			var17 = null;
			String var18 = null;
			var17 = var13.getDataObject("parent");
			if (var17 != null) {
				var18 = var17.getDataObject("identifier").getString("uniqueName");
				if (var18 == null) {
					var19 = var17.getDataObject("identifier").getString("uniqueId");
					if (var19 != null) {
						var18 = this.getUniqueNameByUniqueId(var19, false, (Set) null);
						if (var18 == null || var18.length() == 0) {
							throw new InvalidUniqueIdException("INVALID_PARENT_UNIQUE_ID",
									WIMMessageHelper.generateMsgParms(var19), CLASSNAME, "createImpl");
						}
					}
				}
			}

			if (var18 == null) {
				var18 = this.realmMgr.getDefaultParentForEntityInRealm(var14, var11);
			} else if (!this.realmMgr.isUniqueNameInRealm(var18, var11)) {
				throw new EntityNotInRealmScopeException("ENTITY_NOT_IN_REALM_SCOPE",
						WIMMessageHelper.generateMsgParms(var18, var11), CLASSNAME, "createImpl");
			}

			if (var18 == null) {
				throw new DefaultParentNotFoundException("DEFAULT_PARENT_NOT_FOUND",
						WIMMessageHelper.generateMsgParms(var14, var11), CLASSNAME, "createImpl");
			}

			var18 = UniqueNameHelper.formatUniqueName(var18);
			if (var17 == null) {
				var17 = var13.createDataObject("parent");
				DataObject var33 = var17.createDataObject("identifier");
			}

			var17.getDataObject("identifier").setString("uniqueName", var18);
			var13.setDataObject("parent", var17);
			if (this.reposMgr.getNumberOfRepositories() > 1) {
				if (var5 < 0) {
					var5 = this.reposMgr.getRepositoryIndexByUniqueName(var18);
				}
			} else {
				var5 = 0;
			}

			var19 = this.reposMgr.getRepositoryIDByRepositoryIndex(var5);
			this.checkAccessibility('c', "CREATE", var19, var14);
			List var20;
			if (var14.equals("Group") || this.schemaMgr.isSuperType("Group", var14)) {
				var20 = var13.getList("members");
				if (var20 != null && var20.size() > 0) {
					var20 = this.setExtIdAndRepositoryIdForEntities(var20, var19, false, (Set) null);
					if (var20 != null && var20.size() > 0) {
						for (int var21 = 0; var21 < var20.size(); ++var21) {
							var22 = DataGraphHelper.cloneDataObject((DataObject) var20.get(var21));
							var23 = var22.getDataObject("identifier");
							String var24 = this.retrieveTargetRepository(var23);
							boolean var25 = this.reposMgr.canGroupAcceptMember(var19, var24);
							if (!var25 && !var19.equalsIgnoreCase(var24)) {
								throw new OperationNotSupportedException(
										"MISSING_REPOSITORIES_FOR_GROUPS_CONFIGURATION",
										WIMMessageHelper.generateMsgParms(var24), Level.SEVERE, CLASSNAME,
										"createImpl");
							}
						}
					}
				}
			}

			var20 = var13.getList("groups");
			List var36 = null;
			if (var20 != null && var20.size() > 0) {
				var36 = this.separateGroups(var20, var19);
				var7 = DataGraphHelper.cloneList(var20);
			}

			if (this.reposMgr.isAsyncModeSupported(var5) && var7 != null && var7.size() > 0) {
				throw new OperationNotSupportedException("ASYNC_CALL_WITH_MULTIPLE_REPOSITORIES_NOT_SUPPORTED",
						CLASSNAME, "createImpl");
			}

			if (var36 != null) {
				var13.unset("groups");
				var13.getList("groups").addAll(var36);
			}

			List var37 = this.configMgr.getRDNProperties(var14);
			if (var37 == null) {
				throw new EntityTypeNotSupportedException("ENTITY_TYPE_NOT_SUPPORTED",
						WIMMessageHelper.generateMsgParms(var14));
			}

			String var39 = UniqueNameHelper.constructUniqueName(var37, var13, var18);
			if (var39 != null && this.reposMgr.isEntryJoin()) {
				FederationEntity var40 = this.reposMgr.getFederationRepository().lookupByUniqueName(var39);
				if (var40 != null) {
					throw new EntityAlreadyExistsException("ENTITY_ALREADY_EXIST",
							WIMMessageHelper.generateMsgParms(var39), Level.SEVERE, CLASSNAME, "createImpl");
				}
			}

			this.processReferenceProperty(var13, var14, false, false, (Set) null);
			if (var39 != null) {
				if (this.reposMgr.isPropertyJoin()) {
					var6 = this.divideDataObject(var3, this.reposMgr.getRepositoryIDByRepositoryIndex(var5));
				}

				var13.createDataObject("identifier").setString("uniqueName", var39);
				if (var6 != null && this.reposMgr.isAsyncModeSupported(var5)) {
					throw new OperationNotSupportedException("ASYNC_CALL_WITH_MULTIPLE_REPOSITORIES_NOT_SUPPORTED",
							CLASSNAME, "createImpl");
				}

				var4 = this.reposMgr.getRepositories()[var5].create(var3);
			}
		}

		if (AsyncUtils.isOperationComplete(var4)) {
			var26 = this.reposMgr.getRepositoryIDByRepositoryIndex(var5);
			var9 = (DataObject) var4.getList("entities").get(0);
			var10 = this.schemaMgr.getQualifiedTypeName(var9.getType());
			DataObject var27 = var9.getDataObject("identifier");
			DataObject var28 = DataGraphHelper.cloneDataObject(var27);
			var28.setString("repositoryId", var26);
			String var29 = var27.getString("externalId");
			var14 = var27.getString("uniqueName");
			var15 = null;
			String var30;
			if (this.reposMgr.isEntryJoin()) {
				var30 = this.reposMgr.getFederationRepository().create(var10, var14, var26, var29);
			} else {
				var30 = var29;
			}

			var27.setString("uniqueId", var30);
			var27.setString("repositoryId", var26);
			DataObject var34;
			if (this.reposMgr.isPropertyJoin() && var6 != null) {
				List var31 = var6.getList("entities");
				var17 = (DataObject) var31.get(0);
				var17.setDataObject("identifier", var28);
				var34 = this.reposMgr.getLookasideRepository().create(var6);
			}

			if (var7 != null && var7.size() > 0) {
				for (int var32 = 0; var32 < var7.size(); ++var32) {
					var17 = (DataObject) var7.get(var32);
					var34 = var17.getDataObject("identifier");
					var19 = var34.getString("repositoryId");
					if (!var26.equals(var19)) {
						if (!this.reposMgr.isCrossRepositoryGroupMembership(var26)) {
							throw new OperationNotSupportedException("MISSING_REPOSITORIES_FOR_GROUPS_CONFIGURATION",
									WIMMessageHelper.generateMsgParms(var26), Level.SEVERE, CLASSNAME, "createImpl");
						}

						DataObject var35 = SDOHelper.createRootDataObject();
						DataObject var38 = SDOHelper.createEntityDataObject(var35, (String) null, "Group");
						var38.setDataObject("identifier", var34);
						var22 = var38.createDataObject("members");
						var22.setDataObject("identifier", var28);
						var23 = SDOHelper.createControlDataObject(var35, (String) null, "GroupMemberControl");
						this.update(var35);
					}
				}
			}

			this.profileSecManager.setEntitlements(var1, var4, new EntitlementRequest(var1));
			this.unsetExternalId(var4);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createImpl", WIMTraceHelper.printDataGraph(var4));
		}

		return var4;
	}

	private void checkCreateAndModifyTimeStamp(String var1, DataObject var2) throws WIMException {
		String var3 = "checkCreateOrModifyTimeStamp";
		boolean var4 = false;
		boolean var5 = false;
		Property var6 = null;
		EChangeSummary var7 = (EChangeSummary) var2.getDataGraph().getChangeSummary();
		List var8 = var7.getChangedDataObjects();
		if (var8.size() <= 0) {
			var6 = this.schemaMgr.getProperty(var1, "createTimestamp");
			if (var6 != null) {
				var4 = var2.isSet(var6);
			}

			var6 = this.schemaMgr.getProperty(var1, "modifyTimestamp");
			if (var6 != null) {
				var5 = var2.isSet(var6);
			}

			String var14 = null;
			if (var4) {
				var14 = "createTimestamp";
			} else if (var5) {
				var14 = "modifyTimestamp";
			}

			if (var14 != null) {
				throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE",
						WIMMessageHelper.generateMsgParms(var14), CLASSNAME, var3);
			}
		} else {
			DataObject var9 = (DataObject) var8.get(0);
			Iterator var10 = var7.getOldValues(var9).iterator();

			String var13;
			do {
				if (!var10.hasNext()) {
					return;
				}

				Setting var11 = (Setting) var10.next();
				Property var12 = var11.getProperty();
				var13 = var12.getName();
			} while (!"createTimestamp".equalsIgnoreCase(var13) && !"modifyTimestamp".equalsIgnoreCase(var13));

			throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE",
					WIMMessageHelper.generateMsgParms(var13), CLASSNAME, var3);
		}
	}

	private DataObject processIdentifierForLA(DataObject var1, String var2) throws WIMException {
		DataObject var3 = var1.getDataObject("identifier");
		DataObject var4 = DataGraphHelper.cloneDataObject(var3);
		String var5 = var3.getString("externalId");
		Object var6 = null;
		if (this.reposMgr.isEntryJoin()) {
			FederationEntity var7 = this.reposMgr.getFederationRepository().get(var2, var5);
			if (var7 != null) {
				var4.setString("externalId", var7.getExternalId());
			}
		}

		var4.setString("repositoryId", var2);
		return var4;
	}

	private DataObject keepCheckPointForReposOnly(DataObject var1, String var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "keepCheckPointForReposOnly", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var4 = DataGraphHelper.cloneRootDataObject(var1);
		Map var5 = ControlsHelper.getControlMap(var4);
		DataObject var6 = (DataObject) var5.get("ChangeControl");
		List var7 = var6.getList("checkPoint");
		if (var7 != null) {
			for (int var8 = 0; var8 < var7.size(); ++var8) {
				DataObject var9 = (DataObject) var7.get(var8);
				if (!var9.getString("repositoryId").equals(var2)) {
					var6.getList("checkPoint").remove(var8);
					--var8;
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "keepCheckPointForReposOnly", WIMTraceHelper.printDataObject(var4));
		}

		return var4;
	}

	public DataObject searchImpl(DataObject var1) throws WIMException {
		boolean var3 = true;
		StringBuffer var4 = new StringBuffer();
		boolean var5 = false;
		DataObject var6 = null;
		List var7 = null;
		DataObject var8 = null;
		boolean var9 = false;
		DataObject[] var10 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "searchImpl", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var11 = DataGraphHelper.cloneRootDataObject(var1);
		if (AsyncUtils.isCheckAsyncOperationStatus(var1)) {
			String var12 = AsyncUtils.getRepositoryId(var1);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "searchImpl",
						"Checking the status of async search in repository " + var12);
			}

			var6 = this.reposMgr.getRepository(var12).search(var1);
			var3 = false;
		}

		int var48 = this.reposMgr.getNumberOfRepositories();
		List[] var13 = new List[var48];

		for (int var14 = 0; var14 < var48; ++var14) {
			var13[var14] = new BasicEList();
		}

		DataObject var49 = null;
		Map var15 = ControlsHelper.getControlMap(var11);
		int var16 = 0;
		int var17 = 0;
		int var18 = 0;
		String var19 = RealmManager.getRealmOnThread();
		boolean var20 = this.realmMgr.getAllowOperationIfReposDown(var19);
		HashSet var21 = new HashSet();
		List var22 = var11.getList("contexts");
		DataObject var24;
		if (var22 != null && var22.size() > 0) {
			for (int var23 = 0; var23 < var22.size(); ++var23) {
				var24 = (DataObject) var22.get(var23);
				String var25 = var24.getString("key");
				if (var25 != null && "allowOperationIfReposDown".equals(var25)) {
					var20 = (Boolean) var24.get("value");
				}
			}
		}

		boolean var50 = true;
		var24 = (DataObject) var15.get("ChangeControl");
		if (var24 == null) {
			var50 = false;
			var24 = (DataObject) var15.get("SearchControl");
		} else {
			List var51 = var24.getList("checkPoint");
			if (var51.size() == 0) {
				var9 = true;
			}
		}

		DataObject var52 = (DataObject) var15.get("PageControl");
		DataObject var26 = (DataObject) var15.get("SortControl");
		if (var24 == null && var52 == null && var3) {
			throw new MissingSearchControlException("MISSING_SEARCH_CONTROL", CLASSNAME, "searchImpl");
		} else {
			Boolean var36;
			int var37;
			int var65;
			DataObject var67;
			DataObject var73;
			DataObject var79;
			DataObject var87;
			DataObject var88;
			if (var24 == null && var3) {
				byte[] var56 = var52.getBytes("cookie");
				if (var56 == null) {
					throw new PageControlException("MISSING_COOKIE", CLASSNAME, "searchImpl");
				} else {
					var18 = var52.getInt("size");
					if (this.pagingSearchCache != null) {
						Integer var60 = (Integer) this.pagingSearchCache.get("TotalPagedResults");
						String var76 = new String(var56);
						if (!this.pagingSearchCache.containsKey(var76)) {
							throw new PageControlException("INVALID_COOKIE", CLASSNAME, "searchImpl");
						}

						PageCacheEntry var74 = (PageCacheEntry) this.pagingSearchCache.get(var76);
						var65 = 0;
						var67 = null;
						var73 = null;
						var79 = null;
						List var84 = null;
						if (var74 != null) {
							var67 = var74.getDataObject();
							if (var67 != null) {
								var79 = DataGraphHelper.cloneRootDataObject(var67);
								var79.getList("entities").clear();
								var73 = DataGraphHelper.cloneRootDataObject(var67);
								var73.getList("entities").clear();
								if (var67 != null) {
									var84 = var67.getList("entities");
									if (var84 != null) {
										var65 = var84.size();
									}
								}
							}
						}

						if (var18 == 0) {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "searchImpl", "clean up the paging cache entry");
							}

							this.pagingSearchCache.put("TotalPagedResults", new Integer(var60 - var65));
							this.pagingSearchCache.invalidate(var76);
						} else {
							var49 = SDOHelper.createRootDataObject();
							var36 = null;
							List var86;
							if (var65 <= var18) {
								var86 = var84;
								this.pagingSearchCache.put("TotalPagedResults", new Integer(var60 - var65));
								this.pagingSearchCache.invalidate(var76);
								var56 = null;
							} else {
								var86 = var49.getList("entities");

								for (var37 = 0; var37 < var18; ++var37) {
									var88 = DataGraphHelper.cloneDataObject((DataObject) var84.get(var37));
									var86.add(var88);
								}

								List var89 = var84.subList(var18, var65);
								var73.getList("entities").addAll(var89);
								var74.setDataObject(var73);
								this.pagingSearchCache.put(var76, var74, this.dMapPriority, this.pagedEntryTimeToLive,
										this.pagingSearchCache.getSharedPushInt(), (Object[]) null);
								this.pagingSearchCache.put("TotalPagedResults", new Integer(var60 - var18));
							}

							if (this.pagingEntityObject && var86 != null) {
								var49.getList("entities").addAll(var86);
							} else {
								if (var86 != null) {
									var79.getList("entities").addAll(var86);
								}

								var49 = this.get(var79);
							}

							if (var56 != null) {
								var87 = var49.createDataObject("controls", "http://www.ibm.com/websphere/wim",
										"PageResponseControl");
								var87.setBytes("cookie", var56);
							}
						}
					}

					this.unsetExternalId(var49);
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "searchImpl", WIMTraceHelper.printDataObject(var49));
					}

					return var49;
				}
			} else {
				int var29;
				DataObject var30;
				String var31;
				int var53;
				List var58;
				if (var3 && var24 != null) {
					List var28;
					if (var26 != null) {
						List var27 = var26.getList("sortKeys");
						var28 = var24.getList("properties");

						for (var29 = 0; var29 < var27.size(); ++var29) {
							var30 = (DataObject) var27.get(var29);
							var31 = var30.getString("propertyName");
							if (!var28.contains(var31)) {
								var28.add(var31);
							}
						}
					}

					var16 = var24.getInt("countLimit");
					if (var16 < 0) {
						throw new SearchControlException("INCORRECT_COUNT_LIMIT",
								WIMMessageHelper.generateMsgParms(new Integer(var16)), CLASSNAME, "searchImpl");
					}

					if (var16 > 0) {
						var24.setInt("countLimit", var16 + 1);
					} else {
						var24.setInt("countLimit", this.maxSearchResults + 1);
					}

					var17 = var24.getInt("searchLimit");
					if (var17 < 0) {
						throw new SearchControlException("INCORRECT_SEARCH_LIMIT",
								WIMMessageHelper.generateMsgParms(new Integer(var17)), CLASSNAME, "searchImpl");
					}

					var53 = var24.getInt("timeLimit");
					if (var16 > 0 && var52 != null) {
						throw new SearchControlException("CANNOT_SPECIFY_COUNT_LIMIT", CLASSNAME, "searchImpl");
					}

					if (var53 <= 0) {
						var24.setInt("timeLimit", this.searchTimeOut);
					}

					var28 = var24.getList("searchBases");
					if (var50) {
						var58 = var24.getList("changeTypes");
						validateChangeTypes(var58);
					}

					boolean var61 = false;
					if (var28.size() > 0) {
						var13 = this.divideSearchBases(var28, var19, var13);
						var61 = true;
					} else {
						var13 = this.getSearchBasesFromRealm(var19, var13);
					}

					var5 = this.isAsyncSearch(var13, var4);
					if (var26 != null && var5) {
						var30 = var11.createDataObject("controls", "http://www.ibm.com/websphere/wim",
								"RequestControl");
						var30.setString("requiredInteractionStyle", "sync");
					}

					var7 = null;
					List var33;
					if (!this.reposMgr.isPropertyJoin()) {
						if (var5) {
							var6 = this.searchAsyncRepository(var4.toString(), var11);
						} else {
							List[] var63 = new List[var48];
							var10 = new DataObject[var48];

							for (var65 = 0; var65 < var48; ++var65) {
								if (var13 != null) {
									List var69 = var13[var65];
									List var77;
									Map var81;
									if (var69 != null && var69.size() > 0) {
										var24.setList("searchBases", var69);
										if (var61) {
											var73 = var11.createDataObject("contexts");
											var73.set("key", "realm");
											var73.set("value", "n/a");
										}

										var73 = this.searchRepository(var65, var11, (HashMap) null, var20, var21);
										if (var73 != null) {
											var77 = var73.getList("entities");
											if (var77 != null) {
												var63[var65] = var77;
											}

											var81 = ControlsHelper.getControlMap(var73);
											var10[var65] = (DataObject) var81.get("ChangeResponseControl");
										}
									} else if (var48 == 1) {
										var24.getList("searchBases").clear();
										var73 = this.searchRepository(var65, var11, (HashMap) null, var20, var21);
										if (var73 != null) {
											var77 = var73.getList("entities");
											if (var77 != null) {
												var63[var65] = var77;
											}

											var81 = ControlsHelper.getControlMap(var73);
											var10[var65] = (DataObject) var81.get("ChangeResponseControl");
										}
									}
								} else {
									var67 = this.searchRepository(var65, var11, (HashMap) null, var20, var21);
									if (var67 != null) {
										var33 = var67.getList("entities");
										if (var33 != null) {
											var63[var65] = var33;
										}

										Map var75 = ControlsHelper.getControlMap(var67);
										var10[var65] = (DataObject) var75.get("ChangeResponseControl");
									}
								}
							}

							var7 = this.mergeRepositoryEntities(var63, var20, var21);
						}
					} else {
						String var62 = var24.getString("expression");
						if (!var9 && (var62 == null || var62.length() == 0)) {
							throw new SearchControlException("MISSING_SEARCH_EXPRESSION", CLASSNAME, "searchImpl");
						}

						List var64 = DataGraphHelper.cloneList(var24.getList("properties"));
						boolean var32 = var24.getBoolean("returnSubType");
						var33 = this.configMgr.getSupportedEntityTypes();
						List[] var34 = new List[var48];
						var10 = new DataObject[var48];
						String var35 = new String();
						var36 = false;

						for (var37 = 0; var37 < var48; ++var37) {
							if (var13 != null) {
								List var38 = var13[var37];
								if (var38 != null && var38.size() > 0) {
									var24.setList("searchBases", var38);
									if (var61) {
										DataObject var39 = var11.createDataObject("contexts");
										var39.set("key", "realm");
										var39.set("value", "n/a");
									}
								} else {
									if (var48 != 1) {
										continue;
									}

									var24.getList("searchBases").clear();
								}
							}

							var88 = null;
							XPathNode var90 = null;
							List var40 = null;
							String var41 = this.reposMgr.getRepositoryIDByRepositoryIndex(var37);
							if (var62 != null) {
								WIMXPathInterpreter var42 = new WIMXPathInterpreter(new StringReader(var62));
								ProfileManagerMetadataMapper var43 = new ProfileManagerMetadataMapper(var41, var33);

								try {
									var90 = var42.parse(var43);
									var40 = var42.getEntityTypes();
									var36 = true;
								} catch (AttributeNotSupportedException var45) {
									var35 = var45.getMessage();
									continue;
								} catch (ParseException var46) {
									throw new SearchControlException("SEARCH_EXPRESSION_ERROR",
											WIMMessageHelper.generateMsgParms(var46.getMessage()), CLASSNAME,
											"searchImpl");
								} catch (TokenMgrError var47) {
									throw new SearchControlException("INVALID_SEARCH_EXPRESSION",
											WIMMessageHelper.generateMsgParms(var62), CLASSNAME, "searchImpl", var47);
								}
							} else {
								var36 = true;
							}

							HashMap var91 = this.validateAndDivideReturnProperties(var40, var64, var41, var32);
							short var92;
							if (var90 != null && ((var92 = var90.getNodeType()) == 4 || var92 == 8)) {
								if (var5) {
									throw new OperationNotSupportedException(
											"ASYNC_CALL_WITH_MULTIPLE_REPOSITORIES_NOT_SUPPORTED", CLASSNAME,
											"searchImpl");
								}

								var88 = this.splitSearch(var37, var40, var90, var11, var91, var20, var21);
							} else if (var5) {
								var6 = this.searchAsyncRepository(var4.toString(), var11);
							} else {
								var88 = this.propertyJoinSearch(var37, var90, var11, var91, var20, var21);
							}

							if (var88 != null) {
								var34[var37] = var88.getList("entities");
								Map var44 = ControlsHelper.getControlMap(var88);
								var10[var37] = (DataObject) var44.get("ChangeResponseControl");
							}
						}

						if (!var36) {
							throw new SearchControlException("SEARCH_EXPRESSION_ERROR",
									WIMMessageHelper.generateMsgParms(var35), CLASSNAME, "searchImpl");
						}

						var7 = this.mergeRepositoryEntities(var34, var20, var21);
					}
				}

				if (var5 || !var3) {
					if (!AsyncUtils.isOperationComplete(var6)) {
						if (!var3) {
							var18 = AsyncUtils.getPagingSize(var11);
							var16 = AsyncUtils.getCountLimit(var11);
							var17 = AsyncUtils.getSearchLimit(var11);
						} else if (var52 != null) {
							var18 = var52.getInt("size");
						}

						if (var18 > 0) {
							AsyncUtils.setPagingSize(var6, var18);
						}

						if (var16 > 0) {
							AsyncUtils.setCountLimit(var6, var16);
						}

						if (var17 > 0) {
							AsyncUtils.setSearchLimit(var6, var17);
						}

						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.exiting(CLASSNAME, "searchImpl", WIMTraceHelper.printDataGraph(var6));
						}

						return var6;
					}

					var7 = var6.getList("entities");
				}

				if (!this.profileSecManager.isCallerSuperUser()) {
					EntitlementRequest var54 = new EntitlementRequest(var11);
					Iterator var55 = var7.iterator();

					while (var55.hasNext()) {
						if (this.profileSecManager.checkPermission_SEARCH(
								new EntityResource(var11, (DataObject) var55.next()),
								var54.getEntitlementFilter()) == null) {
							var55.remove();
						}
					}
				}

				var8 = SDOHelper.createRootDataObject();
				var53 = var7.size();
				if (!var3) {
					var18 = AsyncUtils.getPagingSize(var11);
					var16 = AsyncUtils.getCountLimit(var11);
					var17 = AsyncUtils.getSearchLimit(var11);
				}

				if (var17 <= 0) {
					var17 = this.maxSearchResults;
				} else if (this.maxSearchResults > 0) {
					var17 = this.maxSearchResults > var17 ? var17 : this.maxSearchResults;
				}

				if (var17 > 0 && var53 > var17) {
					throw new MaxResultsExceededException("EXCEED_MAX_TOTAL_SEARCH_LIMIT",
							WIMMessageHelper.generateMsgParms(Integer.toString(var53), Integer.toString(var17)),
							CLASSNAME, "searchImpl");
				} else {
					DataObject var57;
					if (var50 && var10 != null && var10.length > 0) {
						var57 = var8.createDataObject("controls", "http://www.ibm.com/websphere/wim",
								"ChangeResponseControl");

						for (var29 = 0; var29 < var10.length; ++var29) {
							if (var10[var29] != null) {
								var30 = (DataObject) var10[var29].getList("checkPoint").get(0);
								if (var30.get("repositoryCheckPoint") != null) {
									var57.getList("checkPoint").add(DataGraphHelper.cloneDataObject(var30));
								}
							}
						}
					}

					if (var16 > 0 && var16 < var53) {
						var53 = var16;
						var57 = var8.createDataObject("controls", "http://www.ibm.com/websphere/wim",
								"SearchResponseControl");
						var57.setBoolean("hasMoreResults", true);
					}

					BasicEList var59 = new BasicEList();

					for (var29 = 0; var29 < var53; ++var29) {
						var30 = (DataObject) var7.get(var29);
						var31 = this.schemaMgr.getQualifiedTypeName(var30.getType());
						this.processReferenceProperty(var30, var31, true, var20, var21);
						var59.add(var30);
					}

					var58 = null;
					List var66;
					Object var70;
					if (var26 != null) {
						var66 = var26.getList("sortKeys");
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "searchImpl",
									WIMTraceHelper.printObjectArray(new Object[]{var66}));
						}

						if (var66 == null || var66.size() == 0) {
							throw new SortControlException("MISSING_SORT_KEY", CLASSNAME, "searchImpl");
						}

						SortHandler var68 = new SortHandler(var26);
						var70 = var68.sortEntities(var59);
					} else {
						var70 = var59;
					}

					if (var52 != null) {
						var18 = var52.getInt("size");
					}

					if (var18 > 0 && FactoryManager.getCacheUtil().isCacheAvailable()) {
						if (this.pagingSearchCache == null) {
							this.pagingSearchCache = FactoryManager.getCacheUtil();
							this.pagingSearchCache.initialize(this.pagingSearchCacheName,
									this.maxTotalPagingSearchResults, this.pagingCachesDiskOffLoad);
						}

						if (this.pagingSearchCache != null && var53 > var18) {
							var30 = null;
							DataObject var71 = SDOHelper.createRootDataObject();
							var70 = var8.getList("entities");

							for (int var72 = 0; var72 < var18; ++var72) {
								var73 = DataGraphHelper.cloneDataObject((DataObject) var59.get(var72));
								((List) var70).add(var73);
							}

							var67 = null;
							if (this.pagingEntityObject) {
								var66 = var59.subList(var18, var53);
							} else {
								var66 = var71.getList("entities");

								for (int var78 = 0; var78 < var7.size(); ++var78) {
									var79 = this.schemaMgr.createDataObject("http://www.ibm.com/websphere/wim",
											"Entity");
									var79.setDataObject("identifier",
											((DataObject) var59.get(var78)).getDataObject("identifier"));
									var66.add(var79);
									var67 = this.schemaMgr.createDataObject("http://www.ibm.com/websphere/wim",
											"PropertyControl");
									var67.setList("properties", var24.getList("properties"));
									var67.setList("contextProperties", var24.getList("contextProperties"));
								}
							}

							String var80 = this.pagingSearchCacheName + "time:" + System.currentTimeMillis();
							var71.getList("entities").addAll(var66);
							if (var67 != null) {
								var71.setDataObject("controls", var67);
							}

							PageCacheEntry var82 = new PageCacheEntry(var53, var71);
							byte[] var83 = var80.getBytes();
							String var85 = new String(var83);
							this.pagingSearchCache.put(var85, var82, this.dMapPriority, this.pagedEntryTimeToLive,
									this.pagingSearchCache.getSharedPushInt(), (Object[]) null);
							this.pagingSearchCache.put("TotalPagedResults", new Integer(var53 - var18));
							var87 = var8.createDataObject("controls", "http://www.ibm.com/websphere/wim",
									"PageResponseControl");
							var87.setBytes("cookie", var83);
							var87.setInt("totalSize", var53);
						}
					} else if (var52 != null && var18 == 0) {
						((List) var70).clear();
					}

					var8.getList("entities").addAll((Collection) var70);
					this.profileSecManager.setEntitlements(var11, var8, new EntitlementRequest(var11));
					this.unsetExternalId(var8);
					if (var20) {
						var30 = var8.createDataObject("contexts");
						var30.set("key", "failureRepositoryIDs");
						var30.set("value", var21);
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "searchImpl", WIMTraceHelper.printDataGraph(var8));
					}

					return var8;
				}
			}
		}
	}

	public static void validateChangeTypes(List var0) throws ChangeControlException {
		Object var2 = null;

		for (int var3 = 0; var3 < var0.size(); ++var3) {
			var2 = var0.get(var3);
			if (!"add".equals(var2) && !"delete".equals(var2) && !"rename".equals(var2) && !"modify".equals(var2)
					&& !"*".equals(var2)) {
				throw new ChangeControlException("INVALID_CHANGETYPE", WIMMessageHelper.generateMsgParms(var2),
						CLASSNAME, "validateChangeTypes");
			}
		}

	}

	public DataObject getImpl(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getImpl");
		}

		if (var1 == null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getImpl");
			}

			return null;
		} else {
			boolean var3 = false;
			EntitlementRequest var4 = new EntitlementRequest(var1);
			if (var4.isExclusive()) {
				this.profileSecManager.setEntitlements(var1, var1, var4);
				trcLogger.exiting(CLASSNAME, "getImpl", (Object) null);
				return var1;
			} else {
				Map var5 = ControlsHelper.getControlMap(var1.getDataGraph());
				String var6 = RealmManager.getRealmOnThread();
				boolean var7 = this.realmMgr.getAllowOperationIfReposDown(var6);
				boolean var8 = false;
				List var9 = var1.getList("contexts");
				DataObject var11;
				if (var9 != null && var9.size() > 0) {
					for (int var10 = 0; var10 < var9.size(); ++var10) {
						var11 = (DataObject) var9.get(var10);
						String var12 = var11.getString("key");
						if (var12 != null && "allowOperationIfReposDown".equals(var12)) {
							var7 = (Boolean) var11.get("value");
						}

						if (var12 != null && "trustEntityType".equals(var12)) {
							var8 = Boolean.valueOf((String) var11.get("value"))
									&& ProfileSecurityManager.singleton().isCallerSuperUser();
						}
					}
				}

				HashSet var41 = new HashSet();
				var11 = (DataObject) var5.get("ViewControl");
				DataObject var42;
				if (var11 != null) {
					var42 = this.pluginManager.inlineExitCall(CLASSNAME + "." + "get", var1, "getInViewExplicit");
					return var42;
				} else {
					if (this.reposMgr.isPropertyJoin()) {
						var3 = this.containLAProperties(var5);
					}

					var42 = (DataObject) var5.get("CheckGroupMembershipControl");
					DataObject var13 = this.schemaMgr.createRootDataObject();
					DataObject var15 = DataGraphHelper.cloneRootDataObject(var1);
					var15.getList("entities").clear();
					if (AsyncUtils.isCheckAsyncOperationStatus(var1)) {
						String var43 = AsyncUtils.getRepositoryId(var1);
						var13 = this.reposMgr.getRepository(var43).get(var1);
						if (AsyncUtils.isOperationComplete(var13)) {
							this.prepareDataGraphForCaller(var13, (String) null, (String) null, false, (Set) null);
							List var44 = var13.getList("entities");
							if (var44 != null && !var13.getDataGraph().getChangeSummary().isLogging()) {
								var13.getDataGraph().getChangeSummary().beginLogging();
							}
						}

						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.exiting(CLASSNAME, "getImpl");
						}

						return var13;
					} else {
						List var16 = var1.getList("entities");
						HashMap var17 = new HashMap();
						HashMap var18 = new HashMap();
						HashMap var19 = new HashMap();
						String var21 = null;
						int var22 = 0;

						String var24;
						DataObject var25;
						String var26;
						DataObject var29;
						while (var16.size() > 0) {
							++var22;
							DataObject var23 = (DataObject) var16.get(0);
							var24 = var23.getType().getName();
							var25 = var23.getDataObject("identifier");
							if (var25 == null) {
								throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED",
										CLASSNAME, "getImpl");
							}

							var26 = var25.getString("uniqueId");
							String var27 = var25.getString("uniqueName");
							if (var27 != null) {
								var27 = UniqueNameHelper.formatUniqueName(var27);
								var25.setString("uniqueName", var27);
							}

							String var28;
							if ((var26 == null || var26.trim().length() == 0)
									&& (var27 == null || var27.trim().length() == 0)) {
								var28 = var25.getString("externalName");
								if (var28 == null || var28.length() <= 0) {
									throw new InvalidIdentifierException("INVALID_IDENTIFIER",
											WIMMessageHelper.generateMsgParms(var26, var27), CLASSNAME, "getImpl");
								}

								var29 = (DataObject) var5.get("ExternalNameControl");
								if (var29 == null) {
									throw new WIMApplicationException("EXTERNAL_NAME_CONTROL_NOT_FOUND",
											WIMMessageHelper.generateMsgParms(var28), CLASSNAME, "getImpl");
								}

								DataObject var30 = null;
								String var31 = "ExternalNameControl-" + var22;
								if (!var18.containsKey(var31)) {
									var30 = DataGraphHelper.cloneRootDataObject(var15);
								}

								var30.getList("entities").add(var23);
								var18.put(var31, var30);
							} else {
								if (var8) {
									var28 = this.schemaMgr.getQualifiedTypeName(var23.getType());
									var21 = RepositoryManager.singleton().getRepositoryID(var27);
									if (trcLogger.isLoggable(Level.FINER)) {
										trcLogger.logp(Level.FINER, CLASSNAME, "getImpl",
												"Client entity type will be trusted: " + var28);
									}
								} else {
									if (trcLogger.isLoggable(Level.FINER)) {
										trcLogger.logp(Level.FINER, CLASSNAME, "getImpl",
												"Client entity type will NOT be trusted: " + var24);
									}

									var29 = this.retrieveEntity((String) null, var25, var7, var41);
									var28 = this.schemaMgr.getQualifiedTypeName(var29.getType());
									var27 = var25.getString("uniqueName");
									var21 = var25.getString("repositoryId");
									if (trcLogger.isLoggable(Level.FINER)) {
										trcLogger.logp(Level.FINER, CLASSNAME, "getImpl",
												"Entity type retrieved from repository: " + var28);
									}
								}

								this.checkAccessibility('g', "READ", var21, var28);
								if (var42 != null && this.schemaMgr.isSuperType("Group", var28)) {
									List var55 = var23.getList("members");
									this.setExtIdAndRepositoryIdForEntities(var55, var21, var7, var41);
								}

								if (var6 != null && !this.realmMgr.isUniqueNameInRealm(var27, var6)) {
									throw new EntityNotInRealmScopeException("ENTITY_NOT_IN_REALM_SCOPE",
											WIMMessageHelper.generateMsgParms(var27, var6), CLASSNAME, "getImpl");
								}

								var29 = null;
								if (!var17.containsKey(var21)) {
									var29 = DataGraphHelper.cloneRootDataObject(var15);
								} else {
									var29 = (DataObject) var17.get(var21);
								}

								var29.getList("entities").add(var23);
								var17.put(var21, var29);
							}
						}

						if (this.multipleRepositories(var17, var18) && this.containAsychRepository(var17, var18)) {
							throw new OperationNotSupportedException(
									"ASYNC_CALL_WITH_MULTIPLE_REPOSITORIES_NOT_SUPPORTED", CLASSNAME, "getImpl");
						} else {
							Iterator var45 = var18.keySet().iterator();

							String var60;
							DataObject var61;
							do {
								DataObject var53;
								DataObject var54;
								do {
									if (!var45.hasNext()) {
										var45 = var17.keySet().iterator();

										DataObject var50;
										List var57;
										while (var45.hasNext()) {
											var24 = (String) var45.next();
											var25 = (DataObject) var17.get(var24);
											var26 = null;

											try {
												var50 = this.reposMgr.getRepository(var24).get(var25);
											} catch (WIMException var36) {
												if (!var7) {
													throw var36;
												}

												trcLogger.logp(Level.FINER, CLASSNAME, "getImpl", "IGNORE: exception ["
														+ var36.getMessage() + "] on repository [" + var24 + "]");
												var41.add(var24);
												continue;
											}

											int var56;
											if (var5.containsKey("GroupMembershipControl")) {
												var53 = (DataObject) var5.get("GroupMembershipControl");
												var56 = var53.getInt("level");
												var29 = null;
												if (var5.containsKey("CacheControl")) {
													var29 = (DataObject) var5.get("CacheControl");
												}

												this.groupMembershipLookup(var50, var24, var53, var7, var41, var29);
											}

											if (var5.containsKey("GroupMemberControl")) {
												var53 = (DataObject) var5.get("GroupMemberControl");
												var56 = var53.getInt("level");
												var29 = null;
												if (var5.containsKey("CacheControl")) {
													var29 = (DataObject) var5.get("CacheControl");
												}

												this.groupMembershipLookup(var50, var24, var53, var7, var41, var29);
											}

											if (var50 != null && this.reposMgr.isPropertyJoin()) {
												var57 = var1.getDataGraph().getRootObject().getDataObject("Root")
														.getList("controls");

												try {
													if (var57.size() != 0) {
														if (var3) {
															var50.getList("controls").clear();
															var50.getList("controls").addAll(var57);
															RepositoryManager.singleton().getLookasideRepository()
																	.get(var50);
														}
													} else {
														RepositoryManager.singleton().getLookasideRepository()
																.get(var50);
													}
												} catch (WIMException var37) {
													if (!var7) {
														throw var37;
													}

													trcLogger.logp(Level.FINER, CLASSNAME, "getImpl",
															"IGNORE: exception [" + var37.getMessage()
																	+ "] on LA repository ");
													var41.add(this.reposMgr.getLookasideRepositoryID());
												}
											}

											this.prepareDataGraphForCaller(var50, (String) null, (String) null, var7,
													var41);
											var19.put(var24, var50);
										}

										List[] var46 = new List[var19.size()];
										var45 = var19.keySet().iterator();
										var22 = 0;

										while (var45.hasNext()) {
											String var47 = (String) var45.next();
											var50 = (DataObject) var19.get(var47);
											var46[var22++] = var50.getList("entities");
											var57 = var50.getList("controls");
											var13.getList("controls").addAll(var57);
										}

										List var49 = this.mergeEntitiesList(var46);
										if (var8) {
											for (int var51 = 0; var51 < var49.size(); ++var51) {
												var53 = (DataObject) var49.get(var51);
												var54 = var53.getDataObject("identifier");
												var60 = var54.getString("repositoryId");
												String var62 = this.schemaMgr.getQualifiedTypeName(var53.getType());
												this.checkAccessibility('g', "READ", var60, var62);
											}
										}

										if (!this.profileSecManager.isCallerSuperUser()) {
											Iterator var52 = var49.iterator();

											while (var52.hasNext()) {
												this.profileSecManager.checkPermission_GET(
														new EntityResource(var1, (DataObject) var52.next()));
											}
										}

										var50 = (DataObject) var5.get("SortControl");
										if (var50 != null) {
											var57 = var50.getList("sortKeys");
											if (trcLogger.isLoggable(Level.FINER)) {
												trcLogger.logp(Level.FINER, CLASSNAME, "getImpl",
														WIMTraceHelper.printObjectArray(new Object[]{var57}));
											}

											if (var57 == null || var57.size() == 0) {
												throw new SortControlException("MISSING_SORT_KEY", CLASSNAME,
														"getImpl");
											}

											SortHandler var58 = new SortHandler(var50);
											var49 = var58.sortEntities(var49);
										}

										var13.setList("entities", var49);
										this.profileSecManager.setEntitlements(var1, var13,
												new EntitlementRequest(var1));
										this.unsetExternalId(var13);
										if (var7) {
											var53 = var13.createDataObject("contexts");
											var53.set("key", "failureRepositoryIDs");
											var53.set("value", var41);
										}

										if (trcLogger.isLoggable(Level.FINER)) {
											trcLogger.exiting(CLASSNAME, "getImpl");
										}

										return var13;
									}

									var24 = (String) var45.next();
								} while (!var24.startsWith("ExternalNameControl"));

								var25 = (DataObject) var18.get(var24);
								List var48 = var25.getList("entities");
								var53 = (DataObject) var48.get(0);
								var54 = var53.getDataObject("identifier");
								var60 = var54.getString("externalName");
								List var59 = this.getReposForExternalName(var60, var6);
								var61 = null;

								for (int var32 = 0; var32 < var59.size(); ++var32) {
									try {
										String var33 = (String) var59.get(var32);
										var61 = this.reposMgr.getRepository(var33).get(var25);
										if (var61 != null && this.reposMgr.isPropertyJoin()) {
											List var34 = var1.getDataGraph().getRootObject().getDataObject("Root")
													.getList("controls");

											try {
												if (var34.size() != 0) {
													if (var3) {
														var61.getList("controls").clear();
														var61.getList("controls").addAll(var34);
														RepositoryManager.singleton().getLookasideRepository()
																.get(var61);
													}
												} else {
													RepositoryManager.singleton().getLookasideRepository().get(var61);
												}
											} catch (WIMException var38) {
												if (!var7) {
													throw var38;
												}

												trcLogger.logp(Level.FINER, CLASSNAME, "getImpl", "IGNORE: exception ["
														+ var38.getMessage() + "] on LA repository ");
												var41.add(this.reposMgr.getLookasideRepositoryID());
											}
										}
									} catch (EntityNotFoundException var39) {
										trcLogger.logp(Level.FINER, CLASSNAME, "getImpl",
												"IGNORE: exception [" + var39.getMessage() + "] on repository ["
														+ this.reposMgr.getRepositoryIDByRepositoryIndex(var32) + "]");
									} catch (WIMException var40) {
										trcLogger.logp(Level.FINER, CLASSNAME, "getImpl",
												"IGNORE: exception [" + var40.getMessage() + "] on repository ["
														+ this.reposMgr.getRepositoryIDByRepositoryIndex(var32) + "]");
										var41.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var32));
										continue;
									}

									if (var61 != null) {
										this.prepareDataGraphForCaller(var61, (String) null, (String) null, var7,
												var41);
										var19.put(var24, var61);
										break;
									}
								}
							} while (var61 != null);

							EntityNotFoundException var63 = new EntityNotFoundException("ENTITY_NOT_FOUND",
									WIMMessageHelper.generateMsgParms(var60), CLASSNAME, "getImpl");
							throw var63;
						}
					}
				}
			}
		}
	}

	private boolean containAsychRepository(HashMap var1, HashMap var2) throws WIMException {
		Set var3 = var1.keySet();
		Iterator var4 = var3.iterator();

		do {
			if (!var4.hasNext()) {
				return false;
			}
		} while (!this.reposMgr.isAsyncModeSupported((String) var4.next()));

		return true;
	}

	private boolean multipleRepositories(HashMap var1, HashMap var2) {
		return var1.size() > 1;
	}

	private boolean containLAProperties(Map var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "containLAProperties");
		}

		boolean var3 = false;
		Set var4 = this.getLAProperties();
		if (var1 != null) {
			Iterator var5 = var1.keySet().iterator();

			label56 : while (true) {
				List var8;
				do {
					DataObject var7;
					do {
						String var6;
						do {
							if (!var5.hasNext()) {
								break label56;
							}

							var6 = (String) var5.next();
						} while (!this.schemaMgr.isSuperType("PropertyControl", var6));

						var7 = (DataObject) var1.get(var6);
					} while (var7 == null);

					var8 = var7.getList("properties");
				} while (var8 == null);

				for (int var9 = 0; var9 < var8.size() && !var3; ++var9) {
					String var10 = (String) var8.get(var9);
					if (var4 != null && var4.contains(var10)) {
						var3 = true;
					} else if (var10.equals("*")) {
						var3 = true;
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "containLAProperties", "" + var3);
		}

		return var3;
	}

	private boolean containLAProperties(String var1, DataObject var2, List var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "containLAProperties(reposId,entity)");
		}

		boolean var5 = false;
		ArrayList var6 = new ArrayList();
		boolean var7 = false;
		if (var3 != null & var3.size() > 0) {
			var7 = true;

			for (int var8 = 0; var8 < var3.size(); ++var8) {
				Property var9 = (Property) var3.get(var8);
				var6.add(var9.getName());
			}
		}

		String var16 = this.schemaMgr.getQualifiedTypeName(var2.getType());
		HashSet var17 = this.propMgr.getLookAsidePropertyNameSet(var16) != null
				? new HashSet(this.propMgr.getLookAsidePropertyNameSet(var16))
				: null;
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "containLAProperties(reposId,entity)",
					"needCheck=" + var7 + ", delProNameList=" + var6);
			trcLogger.logp(Level.FINEST, CLASSNAME, "containLAProperties(reposId,entity)",
					"entity type=" + var16 + ", LA props=" + var17);
		}

		if (var17 != null) {
			Set var10 = this.propMgr.getRepositoryPropertyNameSet(var1, var16);
			Iterator var11;
			String var12;
			Property var13;
			if (var10 != null) {
				var11 = var10.iterator();

				while (var11.hasNext()) {
					var12 = (String) var11.next();
					var13 = this.schemaMgr.getProperty(var16, var12);
					if (var13 != null && var17.contains(var12)) {
						var17.remove(var12);
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "containLAProperties(reposId,entity)",
						"LA props(after removing repo props)=" + var17);
			}

			var11 = var17.iterator();

			while (var11.hasNext()) {
				var12 = (String) var11.next();
				var13 = this.schemaMgr.getProperty(var16, var12);

				try {
					if (var2.isSet(var13)) {
						var5 = true;
						break;
					}

					if (var7 && var6.contains(var13.getName())) {
						var5 = true;
						break;
					}
				} catch (IllegalArgumentException var15) {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "containLAProperties(reposId,entity)", "Exception:",
								var15);
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "containLAProperties(reposId,entity)", "" + var5);
		}

		return var5;
	}

	private Set getRepositoryPropertyNameSetWithoutLA(String var1, DataObject var2) throws WIMException {
		HashSet var3 = new HashSet(this.propMgr.getRepositoryPropertyNameSet(var1, var2.getType()));
		Set var4 = this.propMgr.getLookAsidePropertyNameSet(var2.getType());
		var3.removeAll(var4);
		var3.remove("identifier");
		var3.remove("viewIdentifiers");
		return var3;
	}

	private boolean containsRepositoryProperties(String var1, DataObject var2, EChangeSummary var3)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "containsRepositoryProperties");
		}

		boolean var5 = false;
		HashSet var6 = new HashSet(this.propMgr.getLookAsidePropertyNameSet(var2.getType()));
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "containsRepositoryProperties",
					"entity type=" + var2.getType() + ", LA props=" + var6);
		}

		HashSet var7 = new HashSet(this.propMgr.getRepositoryPropertyNameSet(var1, var2.getType()));
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "containsRepositoryProperties",
					"entity type=" + var2.getType() + ", REPO props=" + var7);
		}

		var6.removeAll(var7);
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "containsRepositoryProperties",
					"LA props(after removing repo props)=" + var6);
		}

		if (var7 != null && var3 != null) {
			List var8 = var3.getChangedDataObjects();
			if (var8.size() > 0) {
				DataObject var9 = (DataObject) var8.get(0);
				Iterator var10 = var3.getOldValues(var9).iterator();

				while (var10.hasNext()) {
					Setting var11 = (Setting) var10.next();
					Property var12 = var11.getProperty();
					String var13 = var12.getName();
					if ("ibmJobTitle".equals(var13)) {
						var13 = "ibm-jobTitle";
					} else if ("ibmPrimaryEmail".equals(var13)) {
						var13 = "ibm-primaryEmail";
					}

					if (!var6.contains(var13) && var7.contains(var13)) {
						var5 = true;
						break;
					}
				}
			} else {
				Iterator var15 = var7.iterator();

				while (var15.hasNext()) {
					String var16 = (String) var15.next();

					try {
						if (var2.isSet(var16)) {
							var5 = true;
							break;
						}
					} catch (IllegalArgumentException var14) {
						;
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "containsRepositoryProperties", "" + var5);
		}

		return var5;
	}

	private void removeLAProperties(String var1, DataObject var2, EChangeSummary var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "removeLAProperties");
		}

		Set var5 = this.propMgr.getLookAsidePropertyNameSet(var2.getType());
		Set var6 = this.propMgr.getRepositoryPropertyNameSet(var1, var2.getType());
		if (var5 != null) {
			var5.removeAll(var6);
			Iterator var7 = var5.iterator();

			while (var7.hasNext()) {
				String var8 = (String) var7.next();

				try {
					if (var2.isSet(var8)) {
						var2.unset(var8);
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "removeLAProperties", "remove la property " + var8);
						}
					}
				} catch (IllegalArgumentException var10) {
					;
				}
			}

			this.removePropertyFromChangeSummary(var5, var3);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "removeLAProperties");
		}

	}

	private void removePropertyFromChangeSummary(Set var1, EChangeSummary var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "removePropertyFromChangeSummary");
		}

		if (var2 != null) {
			List var4 = var2.getChangedDataObjects();

			label58 : for (int var5 = 0; var5 < var4.size(); ++var5) {
				DataObject var6 = (DataObject) var4.get(var5);
				Iterator var7 = var2.getOldValues(var6).iterator();

				while (true) {
					while (true) {
						if (!var7.hasNext()) {
							continue label58;
						}

						Setting var8 = (Setting) var7.next();
						Property var9 = var8.getProperty();
						String var10 = var9.getName();
						if (var1.contains(var10)) {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "removePropertyFromChangeSummary",
										"removing LA prop from changeSummary: " + var10);
							}

							var7.remove();
						} else if (var10.equalsIgnoreCase("ibmPrimaryEmail") && var1.contains("ibm-primaryEmail")) {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "removePropertyFromChangeSummary",
										"removing LA prop from changeSummary: ibm-primaryEmail");
							}

							var7.remove();
						} else if (var10.equalsIgnoreCase("ibmJobTitle") && var1.contains("ibm-jobTitle")) {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "removePropertyFromChangeSummary",
										"removing LA prop from changeSummary: ibm-jobTitle");
							}

							var7.remove();
						}
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "removePropertyFromChangeSummary");
		}

	}

	private void retainLAProperties(String var1, DataObject var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "retainLAProperties");
		}

		Set var4 = this.propMgr.getRepositoryPropertyNameSet(var1, var2.getType());
		Set var5 = this.propMgr.getLookAsidePropertyNameSet(var2.getType());
		if (var5 != null && var4 != null) {
			Iterator var6 = var4.iterator();

			while (var6.hasNext()) {
				String var7 = (String) var6.next();

				try {
					if (var2.isSet(var7) && !var5.contains(var7)) {
						var2.unset(var7);
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "retainLAProperties",
									"remove none la property " + var7);
						}
					}
				} catch (IllegalArgumentException var9) {
					;
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "retainLAProperties");
		}

	}

	private Set getLAProperties() {
		if (this.laSupportedProps == null) {
			this.laSupportedProps = new HashSet();
			RepositoryPropertyMap var1 = this.propMgr.getLookAsidePropertyNameMap();
			Set var2 = var1.getEntityTypes();
			Iterator var3 = var2.iterator();

			while (var3.hasNext()) {
				String var4 = (String) var3.next();
				Set var5 = var1.getRepositoryPropertySetByEntityType(var4);
				this.laSupportedProps.addAll(var5);
			}
		}

		return this.laSupportedProps;
	}

	protected void invalidLAProperties() {
		this.laSupportedProps = null;
	}

	private List mergeEntitiesList(List[] var1) {
		BasicEList var2 = new BasicEList();

		for (int var3 = 0; var3 < var1.length; ++var3) {
			if (var1[var3] != null) {
				var2.addAll(var1[var3]);
			}
		}

		return var2;
	}

	public void mergeLookasideDataObject(DataObject var1, DataObject var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "mergeLookasideDataObject", WIMMessageHelper
					.generateMsgParms(WIMTraceHelper.printDataGraph(var1), WIMTraceHelper.printDataGraph(var2)));
		}

		if (var1 != null && var2 != null) {
			List var4 = var2.getList("entities");

			for (int var5 = 0; var5 < var4.size(); ++var5) {
				DataObject var6 = (DataObject) var4.get(var5);
				Type var7 = var6.getType();
				Set var8 = this.propMgr.getLookAsidePropertyNameSet(var7);
				DataObject var9 = this.getTargetEntity(var1, var6.getDataObject("identifier"));
				if (var9 != null && var8 != null) {
					Iterator var10 = var8.iterator();

					while (var10.hasNext()) {
						String var11 = (String) var10.next();
						Property var12 = this.schemaMgr.getProperty(var7, var11);
						if (var12 != null && var6.isSet(var12)) {
							if (var12.isMany()) {
								var9.setList(var12, var6.getList(var12));
							} else {
								var9.set(var12, var6.get(var12));
							}
						}
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "mergeLookasideDataObject", WIMTraceHelper.printDataObject(var1));
			}

		} else {
			throw new WIMApplicationException("GENERIC",
					WIMMessageHelper.generateMsgParms("targetRoot=null or laRoot=null"), CLASSNAME,
					"mergeLookasideDataObject");
		}
	}

	private DataObject getTargetEntity(DataObject var1, DataObject var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getTargetEntity");
		}

		DataObject var4 = null;
		if (var1 != null && var2 != null) {
			List var5 = var1.getList("entities");

			for (int var6 = 0; var6 < var5.size(); ++var6) {
				DataObject var7 = (DataObject) var5.get(var6);
				DataObject var8 = var7.getDataObject("identifier");
				if (this.isIdentifierEqual(var8, var2)) {
					var4 = var7;
					break;
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getTargetEntity");
		}

		return var4;
	}

	private boolean isIdentifierEqual(DataObject var1, DataObject var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isIdentifierEqual");
		}

		boolean var4 = false;
		if (var1.getString("uniqueId") != null && var1.getString("uniqueId").equals(var2.getString("uniqueId"))) {
			var4 = true;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "isIdentifierEqual", "uniqueId matches");
			}
		} else if (var1.getString("uniqueName") != null
				&& var1.getString("uniqueName").equals(var2.getString("uniqueName"))) {
			var4 = true;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "isIdentifierEqual", "uniqueName matches");
			}
		} else if (var1.getString("externalId") != null
				&& var1.getString("externalId").equals(var2.getString("externalId"))) {
			var4 = true;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "isIdentifierEqual", "externalId matches");
			}
		} else if (var1.getString("externalName") != null
				&& var1.getString("externalName").equals(var2.getString("externalName"))) {
			var4 = true;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "isIdentifierEqual", "externalName matches");
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isIdentifierEqual");
		}

		return var4;
	}

	public DataObject deleteImpl(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteImpl");
		}

		this.reposMgr = RepositoryManager.singleton();
		if (var1 == null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "deleteImpl");
			}

			return null;
		} else {
			this.isReferenceToLoggedInUser(var1);
			ChangeSummary var3 = var1.getDataGraph().getChangeSummary();
			if (var3.isLogging()) {
				var3.endLogging();
			}

			DataObject var5 = DataGraphHelper.cloneRootDataObject(var1);
			boolean var6 = false;
			DataObject var8;
			Map var9;
			DataObject var10;
			if (AsyncUtils.isCheckAsyncOperationStatus(var5)) {
				String var21 = AsyncUtils.getRepositoryId(var5);
				var8 = this.reposMgr.getRepository(var21).delete(var5);
				if (var8 != null && AsyncUtils.isOperationComplete(var8)) {
					var9 = ControlsHelper.getControlMap(var1.getDataGraph());
					var10 = (DataObject) var9.get("DeleteControl");
					if (var10 != null) {
						var6 = var10.getBoolean("returnDeleted");
					}

					var8 = this.postDelete(var8, var21, var6);
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "deleteImpl");
				}

				return var8;
			} else {
				List var7 = var5.getList("entities");
				if (var7.size() == 0) {
					throw new EntityNotFoundException("MISSING_ENTITY_DATA_OBJECT",
							WIMMessageHelper.generateMsgParms("delete"), CLASSNAME, "deleteImpl");
				} else if (var7.size() > 1) {
					throw new OperationNotSupportedException("ACTION_MULTIPLE_ENTITIES_SPECIFIED",
							WIMMessageHelper.generateMsgParms("DELETE"), CLASSNAME, "deleteImpl");
				} else {
					var8 = (DataObject) var7.get(0);
					var9 = ControlsHelper.getControlMap(var1.getDataGraph());
					var10 = (DataObject) var9.get("ViewControl");
					DataObject var11;
					if (var10 != null) {
						var11 = this.pluginManager.inlineExitCall(CLASSNAME + "." + "delete", var1,
								"deleteInViewExplicit");
						return var11;
					} else {
						var11 = (DataObject) var9.get("DeleteControl");
						boolean var12 = false;
						if (var11 != null) {
							var12 = var11.getBoolean("deleteDescendants");
							var6 = var11.getBoolean("returnDeleted");
						}

						this.profileSecManager.checkPermission_DELETE(new EntityResource(var1, var8), var12);
						DataObject var13 = var8.getDataObject("identifier");
						if (var13 == null) {
							throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED",
									CLASSNAME, "deleteImpl");
						} else {
							DataObject var14 = var8;
							if (!var13.isSet("externalId") || !var13.isSet("externalName")
									|| !var13.isSet("repositoryId")) {
								var14 = this.retrieveEntity(var13.getString("repositoryId"), var13, false, (Set) null);
							}

							String var15 = var13.getString("repositoryId");
							String var16 = var13.getString("uniqueName");
							String var17 = RealmManager.getRealmOnThread();
							if (var17 != null && !this.realmMgr.isUniqueNameInRealm(var16, var17)) {
								throw new EntityNotInRealmScopeException("ENTITY_NOT_IN_REALM_SCOPE",
										WIMMessageHelper.generateMsgParms(var16, var17), CLASSNAME, "deleteImpl");
							} else {
								String var18 = this.schemaMgr.getQualifiedTypeName(var14.getType());
								this.checkAccessibility('d', "DELETE", var15, var18);
								EChangeSummary var19 = (EChangeSummary) DataGraphHelper
										.cloneEObject((EDataObject) var3);
								((EDataGraph) var5.getDataGraph()).setEChangeSummary(var19);
								DataObject var20 = RepositoryManager.singleton().getRepository(var15).delete(var5);
								if (var20 != null && AsyncUtils.isOperationComplete(var20)) {
									var20 = this.postDelete(var20, var15, var6);
								}

								if (trcLogger.isLoggable(Level.FINER)) {
									trcLogger.exiting(CLASSNAME, "deleteImpl");
								}

								return var20;
							}
						}
					}
				}
			}
		}
	}

	private DataObject postDelete(DataObject var1, String var2, boolean var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "postDelete");
		}

		DataObject var5 = DataGraphHelper.cloneRootDataObject(var1);
		List var6 = var1.getList("entities");
		List var7 = var5.getList("entities");
		if (var3) {
			this.prepareDataGraphForCaller(var1, (String) null, (String) null, false, (Set) null);
		}

		DataObject var9;
		if (this.reposMgr.isEntryJoin()) {
			for (int var8 = 0; var8 < var6.size(); ++var8) {
				var9 = (DataObject) var6.get(var8);
				DataObject var10 = var9.getDataObject("identifier");
				String var11 = var10.getString("uniqueName");
				String var12 = this.schemaMgr.getQualifiedTypeName(var9.getType());
				FederationEntity var13 = new FederationEntity();
				var13.setUniqueId(var10.getString("uniqueId"));
				var13.setUniqueName(var11);
				var13.setRepositoryId(var2);
				var13.setExternalId(var10.getString("externalId"));
				this.reposMgr.getFederationRepository().remove(var13);
			}
		}

		if (this.reposMgr.isPropertyJoin()) {
			DataObject var14 = this.schemaMgr.createRootDataObject();
			var14.setList("entities", var7);
			var9 = this.reposMgr.getLookasideRepository().delete(var14);
		}

		if (this.reposMgr.isCrossRepositoryGroupMembership(var2)) {
			var5 = DataGraphHelper.cloneRootDataObject(var1);
			var7 = var5.getList("entities");
			Set var15 = this.reposMgr.getRepositoriesForGroupMembership(var2);
			if (var15 != null) {
				Iterator var16 = var15.iterator();

				while (var16.hasNext()) {
					String var17 = (String) var16.next();
					if (this.reposMgr.isDBRepository(var17)) {
						DataObject var18 = this.schemaMgr.createRootDataObject();
						var18.setList("entities", var7);
						var18.createDataObject("controls", "http://www.ibm.com/websphere/wim",
								"GroupMembershipControl");
						DataObject var19 = this.reposMgr.getRepository(var17).delete(var18);
					} else if (!var17.equals(var2)) {
						throw new WIMApplicationException("CANNOT_STORE_ENTITY_FROM_OTHER_REPOSITORY",
								WIMMessageHelper.generateMsgParms(var2), CLASSNAME, "postDelete");
					}
				}
			}
		}

		if (!var3) {
			var6.clear();
		}

		if (!var1.getDataGraph().getChangeSummary().isLogging()) {
			var1.getDataGraph().getChangeSummary().beginLogging();
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "postDelete");
		}

		return var1;
	}

	private DataObject retrieveEntityFromRepository(String var1, DataObject var2, boolean var3, Set var4)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "retrieveEntityFromRepository",
					"(" + var1 + ", " + var2 + ", " + var3 + ", " + var4 + ")");
		}

		DataObject var6 = null;
		DataObject var7 = this.schemaMgr.createRootDataObject();
		String var8 = var2.getString("externalId");
		String var9 = var2.getString("externalName");
		String var10 = var2.getString("uniqueId");
		String var11 = var2.getString("uniqueName");
		if (var10 != null && var10.length() != 0 || var11 != null && var11.length() != 0) {
			DataObject var12;
			if (var6 == null) {
				var12 = var7.createDataObject("entities");
				DataObject var13 = var12.createDataObject("identifier");
				if (var8 != null) {
					var13.setString("externalId", var8);
				} else {
					var13.setString("externalId", var10);
				}

				var13.setString("externalName", var9);
				var13.setString("uniqueName", var11);
				DataObject var14 = var7.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"RequestControl");
				var14.setString("requiredInteractionStyle", "sync");
				DataObject var15;
				List var16;
				if (var10 != null && var1 == null) {
					if (var11 != null) {
						var1 = this.reposMgr.getRepositoryID(var11);
						var15 = this.reposMgr.getRepository(var1).get(var7);
						if (var15 != null) {
							var16 = var15.getList("entities");
							if (var16.size() >= 1) {
								var6 = (DataObject) var16.get(0);
							}
						}
					} else {
						for (int var21 = 0; var21 < this.reposMgr.getNumberOfRepositories() && var6 == null; ++var21) {
							try {
								DataObject var22 = this.reposMgr.getRepositories()[var21]
										.get(DataGraphHelper.cloneRootDataObject(var7));
								if (var22 != null) {
									List var17 = var22.getList("entities");
									if (var17.size() >= 1) {
										var6 = (DataObject) var17.get(0);
									}
								}
							} catch (EntityNotFoundException var18) {
								if (trcLogger.isLoggable(Level.FINER)) {
									trcLogger.logp(Level.FINER, CLASSNAME, "retrieveEntityFromRepository",
											"EntityNotFoundException[repoIndex=" + var21 + "] - " + var10);
								}
							} catch (WIMException var19) {
								if (!var3) {
									throw var19;
								}

								trcLogger.logp(Level.FINER, CLASSNAME, "retrieveEntityFromRepository",
										"IGNORE: exception [" + var19.getMessage()
												+ "] when retrieve entity from repository ["
												+ this.reposMgr.getRepositoryIDByRepositoryIndex(var21) + "]");
								var4.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var21));
							}
						}
					}
				} else {
					if (var1 == null) {
						var1 = this.reposMgr.getRepositoryID(var11);
					}

					var15 = this.reposMgr.getRepository(var1).get(var7);
					if (var15 != null) {
						var16 = var15.getList("entities");
						if (var16.size() >= 1) {
							var6 = (DataObject) var16.get(0);
						}
					}
				}
			}

			if (var6 == null) {
				var12 = null;
				String var20;
				if (var10 != null) {
					var20 = var10;
				} else {
					var20 = var11;
				}

				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var20),
						CLASSNAME, "retrieveEntityFromRepository");
			} else {
				var12 = var6.getDataObject("identifier");
				var2.setString("externalId", var12.getString("externalId"));
				var2.setString("externalName", var12.getString("externalName"));
				var2.setString("uniqueId", var12.getString("uniqueId"));
				var2.setString("uniqueName", var12.getString("uniqueName"));
				var2.setString("repositoryId", var12.getString("repositoryId"));
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "retrieveEntityFromRepository");
				}

				return var6;
			}
		} else {
			throw new InvalidIdentifierException("INVALID_IDENTIFIER", WIMMessageHelper.generateMsgParms(var10, var11),
					CLASSNAME, "retrieveEntityFromRepository");
		}
	}

	private DataObject retrieveEntity(String var1, DataObject var2, boolean var3, Set var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "retrieveEntity", "(" + var1 + ", " + var2 + ", " + var3 + ", " + var4 + ")");
		}

		DataObject var6 = null;
		String var7 = var2.getString("uniqueId");
		String var8 = var2.getString("uniqueName");
		if ((var7 == null || var7.length() == 0) && (var8 == null || var8.length() == 0)) {
			throw new InvalidIdentifierException("INVALID_IDENTIFIER", WIMMessageHelper.generateMsgParms(var7, var8),
					CLASSNAME, "retrieveEntity");
		} else {
			if (var8 != null) {
				var8 = UniqueNameHelper.formatUniqueName(var8);
			}

			if (this.reposMgr.isEntryJoin()) {
				try {
					FederationEntity var9 = null;
					if (var7 != null) {
						var9 = this.reposMgr.getFederationRepository().lookupByUniqueId(var7);
					} else {
						var9 = this.reposMgr.getFederationRepository().lookupByUniqueName(var8);
					}

					if (var9 != null) {
						String var10 = var9.getEntityType();
						String var11 = this.schemaMgr.getTypeNsURI(var10);
						String var12 = this.schemaMgr.getTypeName(var10);
						var6 = this.schemaMgr.createDataObject(var11, var12);
						DataObject var13 = var6.createDataObject("identifier");
						var13.setString("repositoryId", var9.getRepositoryId());
						var2.setString("repositoryId", var9.getRepositoryId());
						var13.setString("externalId", var9.getExternalId());
						var2.setString("externalId", var9.getExternalId());
						String var14 = var9.getUniqueName();
						if (var14 != null) {
							var13.setString("uniqueName", var14);
							var2.setString("uniqueName", var14);
						} else if (var8 != null) {
							var13.setString("uniqueName", var8);
						} else {
							var6 = null;
						}
					}
				} catch (WIMException var15) {
					if (!var3) {
						throw var15;
					}

					trcLogger.logp(Level.FINER, CLASSNAME, "retrieveEntity",
							"IGNORE: exception [" + var15.getMessage() + "] on FED repository");
					var4.add(this.reposMgr.getFederationRepositoryID());
				}
			}

			if (var6 == null) {
				var6 = this.retrieveEntityFromRepository(var1, var2, var3, var4);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "retrieveEntity");
			}

			return var6;
		}
	}

	public DataObject updateImpl(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		boolean var4 = trcLogger.isLoggable(Level.FINE);
		if (var3) {
			trcLogger.entering(CLASSNAME, "updateImpl");
		}

		if (var1 == null) {
			if (var3) {
				trcLogger.exiting(CLASSNAME, "updateImpl");
			}

			return null;
		} else {
			ChangeSummary var5 = var1.getDataGraph().getChangeSummary();
			if (var5.isLogging()) {
				var5.endLogging();
			}

			DataObject var7 = DataGraphHelper.deepCloneRootDataObject(var1);
			DataObject var8 = null;
			boolean var9 = true;
			String var10 = null;
			DataObject var11 = null;
			boolean var12 = true;
			Map var13 = ControlsHelper.getControlMap(var1);
			DataObject var14 = (DataObject) var13.get("CacheControl");
			DataObject var19;
			String var24;
			String var43;
			DataObject var47;
			DataObject var49;
			DataObject var52;
			String var58;
			if (var14 != null) {
				var43 = var14.getString("mode");
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "updateImpl", "Cache Control is passed with mode " + var43);
				}

				List var45;
				int var46;
				if (var43 != null && "clearAll".equalsIgnoreCase(var43)) {
					var45 = var1.getList("entities");

					for (var46 = 0; var46 < var45.size(); ++var46) {
						var47 = (DataObject) var45.get(var46);
						var19 = var47.getDataObject("identifier");
						var10 = var19.getString("repositoryId");
						if (var10 != null && var10.trim().length() > 0) {
							if (var10.equalsIgnoreCase("LA")) {
								LookasideRepository var51 = this.reposMgr.getLookasideRepository();
								var51.update(var7);
							} else {
								this.reposMgr.getRepository(var10).update(var7);
							}
						} else {
							int var50 = this.reposMgr.getRepositories().length;

							for (int var54 = 0; var54 < var50; ++var54) {
								try {
									Repository var56 = this.reposMgr.getRepositories()[var54];
									var56.update(var7);
								} catch (EntityNotFoundException var38) {
									if (var4) {
										trcLogger.logp(Level.FINE, CLASSNAME, "updateImpl", "Exception in clear cache",
												WIMMessageHelper.generateMsgParms(var38.getMessage()));
									}
								} catch (InvalidIdentifierException var39) {
									if (var4) {
										trcLogger.logp(Level.FINE, CLASSNAME, "updateImpl", "Exception in clear cache",
												WIMMessageHelper.generateMsgParms(var39.getMessage()));
									}
								} catch (OperationNotSupportedException var40) {
									if (var4) {
										trcLogger.logp(Level.FINE, CLASSNAME, "updateImpl", "Exception in clear cache",
												WIMMessageHelper.generateMsgParms(var40.getMessage()));
									}
								} catch (WIMApplicationException var41) {
									var58 = var41.getMessageKey();
									if (!"CANNOT_WRITE_TO_READ_ONLY_REPOSITORY".equalsIgnoreCase(var58)) {
										throw var41;
									}

									if (var4) {
										trcLogger.logp(Level.FINE, CLASSNAME, "updateImpl", "Exception in clear cache",
												WIMMessageHelper.generateMsgParms(var41.getMessage()));
									}
								}
							}

							LookasideRepository var57 = this.reposMgr.getLookasideRepository();
							if (var57 != null) {
								var57.update(var7);
							}
						}
					}
				} else if (var43 != null && "clearEntity".equalsIgnoreCase(var43)) {
					var45 = var1.getList("entities");

					for (var46 = 0; var46 < var45.size(); ++var46) {
						var47 = (DataObject) var45.get(var46);
						var19 = var47.getDataObject("identifier");
						var10 = var19.getString("repositoryId");
						if (var10 != null && var10.trim().length() > 0) {
							var49 = SDOHelper.createRootDataObject();
							var52 = SDOHelper.createEntityDataObject(var49, (String) null, var47.getType().getName());
							var52.setDataObject("identifier", var19);
							DataObject var55 = SDOHelper.createControlDataObject(var49, (String) null, "CacheControl");
							var55.setString("mode", "clearEntity");
							if (var10.equalsIgnoreCase("LA")) {
								LookasideRepository var59 = this.reposMgr.getLookasideRepository();
								var59.update(var49);
							} else {
								this.reposMgr.getRepository(var10).update(var49);
							}

							Iterator var60 = this.reposMgr.getRepositoriesForGroupMembership(var10).iterator();

							while (var60.hasNext()) {
								var24 = (String) var60.next();
								if (!var24.equals(var10)) {
									this.reposMgr.getRepository(var24).update(var49);
								}
							}
						}
					}
				}

				return null;
			} else {
				List var17;
				if (AsyncUtils.isCheckAsyncOperationStatus(var7)) {
					var10 = AsyncUtils.getRepositoryId(var7);
					var8 = this.reposMgr.getRepository(var10).update(var7);
					if (AsyncUtils.isOperationComplete(var8)) {
						var43 = null;
						String var44 = null;
						var17 = var8.getList("entities");
						if (var17.size() > 0) {
							var47 = (DataObject) var17.get(0);
							var19 = var47.getDataObject("identifier");
							if (var19 != null) {
								var43 = var19.getString("uniqueId");
								var44 = var19.getString("uniqueName");
							}
						}

						var8 = this.postUpdate(var7, var8, (DataObject) null, var43, var44);
					}

					if (var3) {
						trcLogger.exiting(CLASSNAME, "updateImpl");
					}

					return var8;
				} else {
					List var15 = var7.getList("entities");
					if (var15.size() == 0) {
						throw new EntityNotFoundException("MISSING_ENTITY_DATA_OBJECT",
								WIMMessageHelper.generateMsgParms("update"), CLASSNAME, "updateImpl");
					} else if (var15.size() > 1) {
						throw new OperationNotSupportedException("ACTION_MULTIPLE_ENTITIES_SPECIFIED",
								WIMMessageHelper.generateMsgParms("UPDATE"), CLASSNAME, "updateImpl");
					} else {
						ArrayList var16 = new ArrayList();
						var17 = var5.getChangedDataObjects();
						Iterator var18 = var17.iterator();

						label379 : while (var18.hasNext()) {
							var19 = (DataObject) var18.next();
							Iterator var20 = var5.getOldValues(var19).iterator();

							while (true) {
								Property var22;
								Object var23;
								do {
									if (!var20.hasNext()) {
										continue label379;
									}

									Setting var21 = (Setting) var20.next();
									var22 = var21.getProperty();
									var23 = var19.get(var22);
									if (var23 instanceof List && ((List) var23).size() == 0) {
										var23 = null;
									}
								} while (var23 != null && var19.isSet(var22));

								if (!var16.contains(var22)) {
									var16.add(var22);
								}
							}
						}

						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "updateImpl", "deletedAttributes=" + var16);
						}

						var47 = (DataObject) var15.get(0);
						String var48 = var47.getType().getName();
						this.profileSecManager.checkPermission_UPDATE(new EntityResource(var1, var47));
						var49 = var47.getDataObject("identifier");
						if (var49 == null) {
							throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED",
									CLASSNAME, "updateImpl");
						} else {
							var52 = var47;
							if (!var49.isSet("externalId") || !var49.isSet("externalName")
									|| !var49.isSet("repositoryId")) {
								var52 = this.retrieveEntity(var49.getString("repositoryId"), var49, false, (Set) null);
							}

							var10 = var49.getString("repositoryId");
							int var42 = this.reposMgr.getRepositoryIndexByRepositoryID(var10);
							String var53 = this.schemaMgr.getQualifiedTypeName(var52.getType());
							var58 = var49.getString("uniqueId");
							var24 = var49.getString("uniqueName");
							String var25 = RealmManager.getRealmOnThread();
							if (var25 != null && !this.realmMgr.isUniqueNameInRealm(var24, var25)) {
								throw new EntityNotInRealmScopeException("ENTITY_NOT_IN_REALM_SCOPE",
										WIMMessageHelper.generateMsgParms(var24, var25), CLASSNAME, "updateImpl");
							} else {
								this.checkCreateAndModifyTimeStamp(var53, var47);
								this.processReferenceProperty(var47, var48, false, false, (Set) null);
								List var26;
								int var27;
								DataObject var28;
								DataObject var29;
								String var30;
								if (this.schemaMgr.isSuperType("Group", var53)) {
									this.setExtIdAndRepositoryIdForEntities(var47.getList("members"), var10, false,
											(Set) null);
									var26 = var47.getList("members");
									if (var26 != null && var26.size() > 0) {
										for (var27 = 0; var27 < var26.size(); ++var27) {
											var28 = DataGraphHelper.cloneDataObject((DataObject) var26.get(var27));
											var29 = var28.getDataObject("identifier");
											var30 = this.retrieveTargetRepository(var29);
											boolean var31 = this.reposMgr.canGroupAcceptMember(var10, var30);
											if (!var31 && !var10.equalsIgnoreCase(var30)) {
												throw new OperationNotSupportedException(
														"MISSING_REPOSITORIES_FOR_GROUPS_CONFIGURATION",
														WIMMessageHelper.generateMsgParms(var30), Level.SEVERE,
														CLASSNAME, "updateImpl");
											}

											if (var12) {
												;
											}

											var12 = false;
										}
									}
								}

								if (this.reposMgr.isAsyncModeSupported(var42) && this.reposMgr.isPropertyJoin()) {
									DataObject var61 = this.divideDataObject(var7,
											this.reposMgr.getRepositoryIDByRepositoryIndex(var42));
									if (var61 != null) {
										throw new OperationNotSupportedException(
												"ASYNC_CALL_WITH_MULTIPLE_REPOSITORIES_NOT_SUPPORTED", CLASSNAME,
												"updateImpl");
									}
								}

								var26 = var47.getList("groups");
								if (var26 != null && var26.size() > 0) {
									if (this.reposMgr.isCrossRepositoryGroupMembership(var10)) {
										var12 = true;
										this.setExtIdAndRepositoryIdForEntities(var15, var10, false, (Set) null);
										HashMap var62 = new HashMap();

										for (int var63 = 0; var63 < var26.size(); ++var63) {
											var29 = DataGraphHelper.cloneDataObject((DataObject) var26.get(var63));
											DataObject var67 = var29.getDataObject("identifier");
											String var69 = this.retrieveTargetRepository(var67);
											Object var32 = (List) var62.get(var69);
											if (var32 == null) {
												var32 = new BasicEList();
											}

											((List) var32).add(var29);
											var62.put(var69, var32);
										}

										Iterator var65 = var62.keySet().iterator();

										for (boolean var66 = false; var65
												.hasNext(); var66 = this.reposMgr.isAsyncModeSupported(var30)) {
											if (var66) {
												throw new OperationNotSupportedException(
														"ASYNC_CALL_WITH_MULTIPLE_REPOSITORIES_NOT_SUPPORTED",
														CLASSNAME, "updateImpl");
											}

											var30 = (String) var65.next();
										}

										EChangeSummary var68 = (EChangeSummary) var7.getDataGraph().getChangeSummary();
										List var70 = (List) var62.get(var10);
										if (var70 == null) {
											var47.unset("groups");
										} else {
											var47.setList("groups", var70);
										}

										DataObject var71 = DataGraphHelper.cloneDataObject(var47);
										if (this.reposMgr.isPropertyJoin()
												&& this.containLAProperties(var10, var47, var16)) {
											if (this.containsRepositoryProperties(var10, var47, var68)) {
												this.checkAccessibility('u', "UPDATE", var10, var53);
												DataObject var33 = DataGraphHelper.deepCloneRootDataObject(var7);
												this.removeLAProperties(var10, var47, var68);
												var8 = this.reposMgr.getRepository(var10).update(var7);
												DataObject var34;
												if (var8.getList("entities").size() == 0) {
													var34 = var8.createDataObject("entities", var47.getType().getURI(),
															var53);
													var34.setDataObject("identifier",
															var47.getDataObject("identifier"));
												}

												var34 = this.processIdentifierForLA(var8.getDataObject("entities.0"),
														var10);
												var47 = var33.getDataObject("entities.0");
												this.retainLAProperties(var10, var47);
												var47.setDataObject("identifier", var34);
												var68 = (EChangeSummary) var7.getDataGraph().getChangeSummary();
												var33.getDataGraph().getChangeSummary().beginLogging();
												var33.getDataGraph().getChangeSummary().endLogging();
												this.removePropertyFromChangeSummary(
														this.getRepositoryPropertyNameSetWithoutLA(var10, var47),
														var68);
												((EDataGraph) var33.getDataGraph()).setEChangeSummary(var68);
												var11 = this.reposMgr.getLookasideRepository().update(var33);
											} else {
												var8 = this.reposMgr.getLookasideRepository().update(var7);
											}
										} else {
											this.checkAccessibility('u', "UPDATE", var10, var53);
											var8 = this.reposMgr.getRepository(var10).update(var7);
										}

										Iterator var72 = this.reposMgr.getRepositoriesForGroupMembership(var10)
												.iterator();

										while (var72.hasNext()) {
											String var73 = (String) var72.next();
											if (!var73.equals(var10)) {
												var70 = (List) var62.get(var73);
												if (var70 != null && var70.size() > 0) {
													DataObject var35 = SDOHelper.createRootDataObject();
													DataObject var36 = DataGraphHelper.cloneDataObject(var71);
													var36.setList("groups", var70);
													var35.getList("entities").add(var36);
													this.checkAccessibility('u', "UPDATE", var73, var53);
													DataObject var37 = this.reposMgr.getRepository(var73).update(var35);
												}
											}
										}
									} else {
										for (var27 = 0; var27 < var26.size(); ++var27) {
											var28 = DataGraphHelper.cloneDataObject((DataObject) var26.get(var27));
											var29 = var28.getDataObject("identifier");
											var30 = this.retrieveTargetRepository(var29);
											if (!var10.equalsIgnoreCase(var30)) {
												throw new OperationNotSupportedException(
														"MISSING_REPOSITORIES_FOR_GROUPS_CONFIGURATION",
														WIMMessageHelper.generateMsgParms(var30), Level.SEVERE,
														CLASSNAME, "updateImpl");
											}

											if (var12) {
												;
											}

											var12 = false;
										}
									}
								} else {
									var12 = false;
								}

								if (!var12) {
									EChangeSummary var64 = (EChangeSummary) var7.getDataGraph().getChangeSummary();
									this.setUniqueName(var26);
									if (this.reposMgr.isPropertyJoin()
											&& this.containLAProperties(var10, var47, var16)) {
										if (this.containsRepositoryProperties(var10, var47, var64)) {
											this.checkAccessibility('u', "UPDATE", var10, var53);
											var28 = DataGraphHelper.deepCloneRootDataObject(var7);
											this.removeLAProperties(var10, var47, var64);
											var8 = this.reposMgr.getRepository(var10).update(var7);
											if (var8.getList("entities").size() == 0) {
												var29 = var8.createDataObject("entities", var47.getType().getURI(),
														var53);
												var29.setDataObject("identifier", var47.getDataObject("identifier"));
											}

											var29 = this.processIdentifierForLA(var8.getDataObject("entities.0"),
													var10);
											var47 = var28.getDataObject("entities.0");
											this.retainLAProperties(var10, var47);
											var47.setDataObject("identifier", var29);
											var64 = (EChangeSummary) var28.getDataGraph().getChangeSummary();
											var28.getDataGraph().getChangeSummary().beginLogging();
											var28.getDataGraph().getChangeSummary().endLogging();
											this.removePropertyFromChangeSummary(
													this.getRepositoryPropertyNameSetWithoutLA(var10, var47), var64);
											((EDataGraph) var28.getDataGraph()).setEChangeSummary(var64);
											var11 = this.reposMgr.getLookasideRepository().update(var28);
										} else {
											var28 = DataGraphHelper.deepCloneRootDataObject(var7);
											var29 = this.divideDataObject(var28, var10);
											if (var29 == null) {
												var29 = SDOHelper.createRootDataObject();
												var47 = SDOHelper.createEntityDataObject(var29, (String) null,
														this.schemaMgr.getQualifiedTypeName(
																var28.getDataObject("entities.0").getType()));
												var47.setDataObject("identifier",
														var28.getDataObject("entities.0").getDataObject("identifier"));
											} else {
												var47 = var28.getDataObject("entities.0");
											}

											if (trcLogger.isLoggable(Level.FINEST)) {
												trcLogger.logp(Level.FINEST, CLASSNAME, "updateImpl",
														WIMTraceHelper.printDataGraph(var29));
											}

											var29.getDataGraph().getChangeSummary().beginLogging();
											var29.getDataGraph().getChangeSummary().endLogging();
											this.removePropertyFromChangeSummary(
													this.getRepositoryPropertyNameSetWithoutLA(var10, var47), var64);
											((EDataGraph) var29.getDataGraph()).setEChangeSummary(var64);
											var29.getDataObject("entities.0").setDataObject("identifier",
													var47.getDataObject("identifier"));
											var29.setList("contexts", var28.getList("contexts"));
											if (trcLogger.isLoggable(Level.FINEST)) {
												trcLogger.logp(Level.FINEST, CLASSNAME, "updateImpl",
														WIMTraceHelper.printDataGraph(var29));
											}

											var8 = this.reposMgr.getLookasideRepository().update(var29);
										}
									} else {
										this.checkAccessibility('u', "UPDATE", var10, var53);
										var8 = this.reposMgr.getRepository(var10).update(var7);
									}
								}

								if (AsyncUtils.isOperationComplete(var8)) {
									var8 = this.postUpdate(var7, var8, var11, var58, var24);
								}

								if (trcLogger.isLoggable(Level.FINER)) {
									trcLogger.exiting(CLASSNAME, "updateImpl");
								}

								return var8;
							}
						}
					}
				}
			}
		}
	}

	private DataObject postUpdate(DataObject var1, DataObject var2, DataObject var3, String var4, String var5)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "postUpdate");
		}

		if (var2 != null) {
			if (this.reposMgr.isPropertyJoin() && var3 != null) {
				this.mergeLookasideDataObject(var2, var3);
			}

			this.prepareDataGraphForCaller(var2, var4, var5, false, (Set) null);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "postUpdate", "profile manager -> update() end.");
			}

			this.profileSecManager.setEntitlements(var1, var2, new EntitlementRequest(var1));
			if (!var2.getDataGraph().getChangeSummary().isLogging()) {
				var2.getDataGraph().getChangeSummary().beginLogging();
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "postUpdate");
		}

		return var2;
	}

	private String getUniqueName(String var1, DataObject var2, boolean var3, Set var4) throws WIMException {
		String var6 = var2.getString("uniqueName");
		if (var6 != null) {
			return var6;
		} else {
			String var7 = var2.getString("uniqueId");
			if (this.reposMgr.isEntryJoin()) {
				try {
					FederationEntity var15 = this.reposMgr.getFederationRepository().lookupByUniqueId(var7);
					if (var15 == null) {
						throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var7),
								CLASSNAME, "getUniqueName");
					}

					return var15.getUniqueName();
				} catch (WIMException var14) {
					if (!var3) {
						throw var14;
					}

					trcLogger.logp(Level.FINER, CLASSNAME, "getUniqueName",
							"IGNORE: exception [" + var14.getMessage() + "] on FED repository");
					var4.add(this.reposMgr.getFederationRepositoryID());
				}
			}

			DataObject var8 = this.schemaMgr.createRootDataObject();
			DataObject var9 = var8.createDataObject("entities");
			DataObject var10 = var9.createDataObject("identifier");
			var10.setString("externalId", var7);
			DataObject var11 = this.reposMgr.getRepository(var1).get(var8);
			List var12 = var11.getList("entities");
			if (var12.size() == 1) {
				DataObject var13 = ((DataObject) var12.get(0)).getDataObject("identifier");
				return var13.getString("uniqueName");
			} else {
				trcLogger.logp(Level.FINER, CLASSNAME, "getUniqueName",
						"The underline repository [" + var1 + "] can not retrieve the entity. ");
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var7),
						CLASSNAME, "getUniqueName");
			}
		}
	}

	public void initialize() throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize");
		}

		String var2 = DomainManagerUtils.getDomainId();
		if (var2 != null && !"admin".equalsIgnoreCase(var2)) {
			this.pagingSearchCacheName = var2 + "/" + this.pagingSearchCacheName;
		}

		this.pluginManager = PluginManager.getPluginManager();
		EnvironmentManager.singleton();
		this.configMgr = ConfigManager.singleton();
		DataObject var3 = this.configMgr.getConfig();
		this.schemaMgr = SchemaManager.singleton();
		this.reposMgr = RepositoryManager.singleton();
		this.realmMgr = RealmManager.singleton();
		this.repository = ConfigRepositoryFactory.getConfigRepository();
		if (this.repository != null) {
			this.repository.addListener(new DynamicRealmConfig());
		}

		this.initializeProviderLevelParameters();
		this.initializePropertyCache();
		this.profileSecManager = ProfileSecurityManager.singleton();
		this.profileSecManager.initialize(var3.getDataGraph());
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

	}

	private void initializeProviderLevelParameters() throws WIMException {
		DataObject var1 = ConfigManager.singleton().getConfig();
		this.searchTimeOut = var1.getInt("searchTimeOut");
		this.pagingEntityObject = var1.getBoolean("pagingEntityObject");
		this.pagingCachesDiskOffLoad = var1.getBoolean("pagingCachesDiskOffLoad");
		this.maxSearchResults = var1.getInt("maxSearchResults");
		var1.getInt("maxPagingResults");
		this.maxTotalPagingSearchResults = var1.getInt("maxTotalPagingResults");
		this.pagedEntryTimeToLive = var1.getInt("pagedCacheTimeOut");
		if (System.getProperty("com.ibm.ws.wim.search.ThrowEntityNotFoundException") != null) {
			this.throwEntityNotFoundException = true;
		}

	}

	public void initializePropertyCache() throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initializePropertyCache");
		}

		String[] var2 = this.reposMgr.getRepositoryIds();
		List var3 = this.configMgr.getSupportedEntityTypes();
		DataObject var4 = SDOHelper.createRootDataObject();
		DataObject var5 = SDOHelper.createControlDataObject(var4, "http://www.ibm.com/websphere/wim",
				"PropertyDefinitionControl");
		this.propMgr = PropertyManager.singleton();
		RepositoryPropertyMap var6 = new RepositoryPropertyMap();
		RepositoryPropertyMap var8;
		int var9;
		String var10;
		if (var3 != null && var2 != null) {
			for (int var7 = 0; var7 < var2.length; ++var7) {
				var5.setString("repositoryId", var2[var7]);
				var8 = new RepositoryPropertyMap();

				for (var9 = 0; var9 < var3.size(); ++var9) {
					var10 = (String) var3.get(var9);
					var5.setString("entityTypeName", var10);
					var8 = this.loadPropertyDefinition(var4, var10, var8, var6);
				}

				this.propMgr.setPropertyMapByRepository(var2[var7], var8);
			}
		}

		if (this.reposMgr.isPropertyJoin()) {
			var4 = SDOHelper.createRootDataObject();
			DataObject var11 = SDOHelper.createControlDataObject(var4, "http://www.ibm.com/websphere/wim",
					"ExtensionPropertyDefinitionControl");
			var8 = new RepositoryPropertyMap();
			if (var3 != null) {
				for (var9 = 0; var9 < var3.size(); ++var9) {
					var10 = (String) var3.get(var9);
					var11.setString("entityTypeName", var10);
					var8 = this.loadPropertyDefinition(var4, var10, var8, var6);
				}

				this.propMgr.setLookAsidePropertyNameMap(var8);
			}
		}

		this.propMgr.setReferenceTypePropertyNameMap(var6);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initializePropertyCache");
		}

	}

	private RepositoryPropertyMap loadPropertyDefinition(DataObject var1, String var2, RepositoryPropertyMap var3,
			RepositoryPropertyMap var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "loadPropertyDefinition", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var6 = this.schemaMgr.getSchema(var1);
		if (var6 == null) {
			return var3;
		} else {
			DataObject var7 = var6.getDataObject("schema");
			if (var7 != null) {
				List var8 = var7.getList("propertySchema");
				if (var8 == null || var8.size() == 0) {
					var8 = var7.getList("extensionPropertySchema");
				}

				if (var8 != null && var8.size() != 0) {
					HashSet var9 = new HashSet();
					HashSet var10 = (HashSet) var4.getRepositoryPropertySetByEntityType(var2);
					if (var10 == null) {
						var10 = new HashSet();
					}

					for (int var11 = 0; var11 < var8.size(); ++var11) {
						DataObject var12 = (DataObject) var8.get(var11);
						String var13 = var12.getString("propertyName");
						String var14 = var12.getString("nsURI");
						String var15 = null;
						var15 = this.schemaMgr.getQualifiedTypeName(var14, var13);
						var9.add(var15);
						String var16 = var12.getString("dataType");
						if (var16 != null && var16.equals("IdentifierType") && !var15.equals("identifier")) {
							var10.add(var15);
						}
					}

					if (var9.size() > 0) {
						var3.setRepositoryPropertySetByEntityType(var2, var9);
					}

					if (var10.size() > 0) {
						var4.setRepositoryPropertySetByEntityType(var2, var10);
					}
				}
			}

			return var3;
		}
	}

	public DataObject loginImpl(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "loginImpl");
		}

		if (var1 == null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "loginImpl");
			}

			return null;
		} else {
			DataObject var3 = null;
			HashMap var5 = new HashMap();
			Object var6 = null;
			DataObject var7 = null;
			String var8 = null;
			String var9 = null;
			Object var10 = null;
			boolean var11 = false;
			HashSet var12 = new HashSet();
			int var13 = 0;
			HashSet var14 = new HashSet();
			DataObject var16;
			List var49;
			if (AsyncUtils.isCheckAsyncOperationStatus(var1)) {
				try {
					String var47 = AsyncUtils.getRepositoryId(var1);
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "loginImpl",
								"calling adapter [" + var47 + "] to check status");
					}

					var3 = this.reposMgr.getRepository(var47).login(var1);
					var49 = var3.getList("entities");
					if (var49.size() == 0) {
						throw new PasswordCheckFailedException("PRINCIPAL_NOT_FOUND", CLASSNAME, "loginImpl");
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "loginImpl", "after calling adapter [" + var47 + "]");
					}
				} catch (WIMException var39) {
					var6 = var39;
					this.recordLoginException(var39, var5);
				}
			} else {
				List var15 = var1.getList("entities");
				if (var15.size() == 0) {
					throw new EntityNotFoundException("MISSING_ENTITY_DATA_OBJECT",
							WIMMessageHelper.generateMsgParms("login"), CLASSNAME, "loginImpl");
				}

				if (var15.size() > 1) {
					throw new OperationNotSupportedException("ACTION_MULTIPLE_ENTITIES_SPECIFIED",
							WIMMessageHelper.generateMsgParms("login"), CLASSNAME, "loginImpl");
				}

				var16 = (DataObject) var15.get(0);
				var9 = var16.getString("principalName");
				byte[] var46 = var16.getBytes("password");
				if (!var16.isSet("certificate") && var9 == null) {
					throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PRINCIPAL_NAME", CLASSNAME, "loginImpl");
				}

				List var17 = var1.getList("contexts");
				if (var17 != null && var17.size() > 0) {
					for (int var18 = 0; var18 < var17.size(); ++var18) {
						DataObject var19 = (DataObject) var17.get(var18);
						String var20 = var19.getString("key");
						if (var20 != null && "allowOperationIfReposDown".equals(var20)) {
							var11 = (Boolean) var19.get("value");
						}
					}
				}

				Map var52 = ControlsHelper.getControlMap(var1.getDataGraph());
				var7 = (DataObject) var52.get("LoginControl");
				if (var7 == null) {
					var7 = var1.createDataObject("controls", "http://www.ibm.com/websphere/wim", "LoginControl");
				}

				List var54 = var7.getList("searchBases");
				int var56 = this.reposMgr.getNumberOfRepositories();
				String var21 = RealmManager.getRealmOnThread();
				List[] var22 = new List[this.reposMgr.getNumberOfRepositories()];

				int var23;
				for (var23 = 0; var23 < var56; ++var23) {
					var22[var23] = new BasicEList();
				}

				if (var54.size() > 0) {
					var22 = this.divideSearchBases(var54, var21, var22);
				} else {
					var22 = this.getSearchBasesFromRealm(var21, var22);
				}

				var23 = 0;
				int var24 = 0;
				int var25;
				List var26;
				if (var22 != null) {
					for (var25 = 0; var25 < var22.length; ++var25) {
						var26 = var22[var25];
						if (var26 != null && var26.size() > 0) {
							if (this.reposMgr.isAsyncModeSupported(var25)) {
								++var24;
							} else {
								++var23;
							}
						}
					}
				}

				if (var23 > 0 && var24 > 0 || var24 > 1) {
					throw new OperationNotSupportedException("ASYNC_CALL_WITH_MULTIPLE_REPOSITORIES_NOT_SUPPORTED",
							CLASSNAME, "loginImpl");
				}

				try {
					for (var25 = 0; var25 < var56; ++var25) {
						if (var22 != null) {
							var26 = var22[var25];
							if (var26 != null && var26.size() > 0) {
								try {
									DataObject var27 = DataGraphHelper.cloneRootDataObject(var1);
									Map var61 = ControlsHelper.getControlMap(var27.getDataGraph());
									DataObject var29 = (DataObject) var61.get("LoginControl");
									var29.setList("searchBases", var26);
									DataObject var30 = this.reposMgr.getRepositories()[var25].login(var27);
									if (trcLogger.isLoggable(Level.FINER)) {
										trcLogger.logp(Level.FINER, CLASSNAME, "loginImpl", "after calling adapter ["
												+ this.reposMgr.getRepositoryIDByRepositoryIndex(var25) + "]");
									}

									if (var3 == null) {
										if (var30.getList("entities").size() > 0) {
											var3 = var30;
											var8 = this.reposMgr.getRepositoryIDByRepositoryIndex(var25);
											var14.add(var8);
										}
									} else if (var30.getList("entities").size() > 0) {
										throw new DuplicateLogonIdException("MULTIPLE_PRINCIPALS_FOUND",
												WIMMessageHelper.generateMsgParms(var9,
														var8 + ", "
																+ this.reposMgr
																		.getRepositoryIDByRepositoryIndex(var25)),
												Level.SEVERE, CLASSNAME, "loginImpl");
									}
								} catch (PasswordCheckFailedException var41) {
									String var28 = var41.getMessageKey();
									if (!"PRINCIPAL_NOT_FOUND".equals(var28)) {
										if ("MISSING_OR_EMPTY_PRINCIPAL_NAME".equals(var28)) {
											throw var41;
										}

										if ("MULTIPLE_PRINCIPALS_FOUND".equals(var28)) {
											throw var41;
										}

										var14.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var25));
										var6 = var41;
										this.recordLoginException(var41, var5);
									}
								} catch (CertificateMapFailedException var42) {
									var14.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var25));
									var6 = var42;
									this.recordLoginException(var42, var5);
								} catch (CertificateMapNotSupportedException var43) {
									var6 = var43;
									this.recordLoginException(var43, var5);
									++var13;
								} catch (Exception var44) {
									var6 = new WIMException(var44);
									if (var44 instanceof DuplicateLogonIdException) {
										throw (DuplicateLogonIdException) var44;
									}

									if (!var11) {
										throw var6;
									}

									trcLogger.logp(Level.FINER, CLASSNAME, "loginImpl",
											"IGNORE: exception [" + ((WIMException) var6).getMessage()
													+ "] on repository ["
													+ this.reposMgr.getRepositoryIDByRepositoryIndex(var25) + "]");
									var12.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var25));
								}
							}
						}
					}
				} finally {
					PasswordUtil.erasePassword(var46);
				}
			}

			int var48 = var5.size();
			if (var3 == null && 0 == var48) {
				if (var5.containsKey("AUTHENTICATION_WITH_CERT_NOT_SUPPORTED")) {
					if (var13 == this.reposMgr.getNumberOfRepositories()) {
						throw new CertificateMapNotSupportedException("AUTHENTICATE_NOT_SUPPORTED",
								WIMMessageHelper.generateMsgParms("the specified certificate"), CLASSNAME, "loginImpl");
					} else {
						throw new CertificateMapFailedException("CERTIFICATE_MAP_FAILED",
								WIMMessageHelper.generateMsgParms(" the specified ceritifcate "), CLASSNAME,
								"loginImpl");
					}
				} else {
					throw new PasswordCheckFailedException("PRINCIPAL_NOT_FOUND",
							WIMMessageHelper.generateMsgParms(var9), CLASSNAME, "loginImpl");
				}
			} else if (var48 == 1) {
				if (var5.containsKey("AUTHENTICATION_WITH_CERT_NOT_SUPPORTED")
						&& var13 != this.reposMgr.getNumberOfRepositories()) {
					throw new CertificateMapFailedException("CERTIFICATE_MAP_FAILED",
							WIMMessageHelper.generateMsgParms(" the specified ceritifcate "), CLASSNAME, "loginImpl");
				} else {
					throw var6;
				}
			} else {
				String var51;
				if (var48 > 1) {
					trcLogger.logp(Level.FINER, CLASSNAME, "loginImpl", "countedException > 1 [" + var48 + "]");
					var16 = null;
					if (var14.size() == 0) {
						var51 = "repositories";
					} else {
						var51 = String.valueOf(var14);
					}

					throw new DuplicateLogonIdException("MULTIPLE_PRINCIPALS_FOUND",
							WIMMessageHelper.generateMsgParms(var9, var51), CLASSNAME, "loginImpl");
				} else {
					if (var48 == 0) {
						trcLogger.logp(Level.FINER, CLASSNAME, "loginImpl", "login successful.");
					} else if (var48 >= 1) {
						trcLogger.logp(Level.FINER, CLASSNAME, "loginImpl", "result != null && countedException >= 1");
						if (var5.containsKey("AUTHENTICATION_WITH_CERT_NOT_SUPPORTED")) {
							if (var13 == this.reposMgr.getNumberOfRepositories()) {
								throw new CertificateMapNotSupportedException("AUTHENTICATE_NOT_SUPPORTED",
										WIMMessageHelper.generateMsgParms("the specified certificate"), CLASSNAME,
										"loginImpl");
							}

							throw new CertificateMapFailedException("CERTIFICATE_MAP_FAILED",
									WIMMessageHelper.generateMsgParms(" the specified ceritifcate "), CLASSNAME,
									"loginImpl");
						}

						var16 = null;
						if (var14.size() == 0) {
							var51 = "repositories";
						} else {
							var51 = String.valueOf(var14);
						}

						throw new DuplicateLogonIdException("MULTIPLE_PRINCIPALS_FOUND",
								WIMMessageHelper.generateMsgParms(var9, var51), CLASSNAME, "loginImpl");
					}

					if (this.reposMgr.isPropertyJoin()) {
						var49 = var3.getList("entities");
						if (var49.size() > 0) {
							DataObject var50 = (DataObject) var49.get(0);
							String var53 = this.schemaMgr.getQualifiedTypeName(var50.getType());
							ArrayList var55 = new ArrayList();
							var55.add(var53);
							List var57 = var7.getList("properties");
							if (var57.size() > 0) {
								HashMap var58 = this.validateAndDivideReturnProperties(var55, var57, var8, false);
								List var59 = (List) var58.get("LA");

								try {
									if (var59 != null && var59.size() > 0) {
										DataObject var60 = var3.createDataObject("controls",
												"http://www.ibm.com/websphere/wim", "PropertyControl");
										var60.setList("properties", var59);
										var3 = this.reposMgr.getLookasideRepository().get(var3);
									}
								} catch (WIMException var40) {
									if (!var11) {
										throw var40;
									}

									trcLogger.logp(Level.FINER, CLASSNAME, "loginImpl",
											"IGNORE: exception [" + var40.getMessage() + "] on LA repository ");
									var12.add(this.reposMgr.getLookasideRepositoryID());
								}
							}
						}
					}

					this.prepareDataGraphForCaller(var3, (String) null, (String) null, var11, var12);
					if (var11) {
						var16 = var3.createDataObject("contexts");
						var16.set("key", "failureRepositoryIDs");
						var16.set("value", var12);
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "loginImpl");
					}

					return var3;
				}
			}
		}
	}

	private void recordLoginException(WIMException var1, Map var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "recordLoginException");
		}

		String var4 = var1.getMessageKey();
		if (var2.containsKey(var4)) {
			int var5 = (Integer) var2.get(var4) + 1;
			var2.put(var4, new Integer(var5));
		} else {
			var2.put(var4, new Integer(1));
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "recordLoginException", "record exception [" + var4 + "]");
			trcLogger.exiting(CLASSNAME, "recordLoginException");
		}

	}

	private List setExtIdAndRepositoryIdForEntities(List var1, String var2, boolean var3, Set var4)
			throws WIMException {
		if (var1 == null) {
			return null;
		} else {
			for (int var6 = 0; var6 < var1.size(); ++var6) {
				DataObject var7 = (DataObject) var1.get(var6);
				DataObject var8 = var7.getDataObject("identifier");
				if (var8 == null) {
					throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED",
							WIMMessageHelper.generateMsgParms(var7), Level.WARNING, CLASSNAME,
							"setExtIdAndRepositoryUUIDForEntities");
				}

				String var9 = var8.getString("uniqueId");
				String var10 = var8.getString("uniqueName");
				String var11 = null;
				String var12 = null;
				String var13 = null;
				if (this.reposMgr.isEntryJoin()) {
					FederationEntity var17 = null;

					try {
						if (var9 != null) {
							var17 = this.reposMgr.getFederationRepository().lookupByUniqueId(var9);
						} else if (var10 != null) {
							var17 = this.reposMgr.getFederationRepository().lookupByUniqueName(var10);
						}
					} catch (WIMException var16) {
						if (!var3) {
							throw var16;
						}

						trcLogger.logp(Level.FINER, CLASSNAME, "setExtIdAndRepositoryUUIDForEntities",
								"IGNORE: exception [" + var16.getMessage() + "] on FED repository");
						var4.add(this.reposMgr.getFederationRepositoryID());
					}

					if (var17 != null) {
						var11 = var17.getExternalId();
						var12 = var17.getRepositoryId();
						var13 = var17.getUniqueName();
					} else if (this.reposMgr.getNumberOfRepositories() == 1) {
						var11 = var9;
						var12 = this.reposMgr.getRepositoryIDByRepositoryIndex(0);
					} else {
						DataObject var15 = this.getIdentifierByUniqueIdOrUniqueName(var9, var10, var3, var4);
						if (var15 != null) {
							var11 = var15.getString("uniqueId");
							var12 = var15.getString("repositoryId");
							var13 = var15.getString("uniqueName");
						}
					}
				} else if (this.reposMgr.getNumberOfRepositories() == 1) {
					if (var9 != null) {
						var11 = var9;
						var12 = var2;
					}
				} else {
					DataObject var14 = this.getIdentifierByUniqueIdOrUniqueName(var9, var10, var3, var4);
					if (var14 != null) {
						var11 = var14.getString("externalId");
						var12 = var14.getString("repositoryId");
						var13 = var14.getString("uniqueName");
					}
				}

				if (var11 != null) {
					var8.setString("externalId", var11);
				}

				if (var12 != null) {
					var8.setString("repositoryId", var12);
				}

				if (var13 != null) {
					var8.setString("uniqueName", var13);
				}
			}

			return var1;
		}
	}

	private List setUniqueName(List var1) throws WIMException {
		if (var1 == null) {
			return null;
		} else {
			for (int var3 = 0; var3 < var1.size(); ++var3) {
				DataObject var4 = (DataObject) var1.get(var3);
				DataObject var5 = var4.getDataObject("identifier");
				if (var5 == null) {
					throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED",
							WIMMessageHelper.generateMsgParms(var4), Level.WARNING, CLASSNAME, "setUniqueName");
				}

				String var6 = var5.getString("uniqueId");
				String var7 = var5.getString("uniqueName");
				if (var7 == null) {
					if (var6 == null) {
						throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED",
								WIMMessageHelper.generateMsgParms(var4), Level.WARNING, CLASSNAME, "setUniqueName");
					}

					var7 = this.getUniqueNameByUniqueId(var6, false, (Set) null);
					if (var7 == null) {
						throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var6),
								CLASSNAME, "setUniqueName");
					}

					var5.setString("uniqueName", var7);
				}
			}

			return var1;
		}
	}

	private List separateGroups(List var1, String var2) throws WIMException {
		String var3 = "separateGroups";
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, var3);
		}

		var1 = this.setExtIdAndRepositoryIdForEntities(var1, var2, false, (Set) null);
		Object var5 = new BasicEList();
		if (this.reposMgr.getNumberOfRepositories() > 1 && var1 != null) {
			for (int var6 = 0; var6 < var1.size(); ++var6) {
				DataObject var7 = (DataObject) var1.get(var6);
				DataObject var8 = var7.getDataObject("identifier");
				if (var8 == null) {
					throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED",
							WIMMessageHelper.generateMsgParms(var7), Level.WARNING, CLASSNAME, var3);
				}

				String var9 = var8.getString("uniqueName");
				if (var9 != null) {
					String var10 = this.reposMgr.getRepositoryID(var9);
					if (var10.equals(var2)) {
						DataObject var11 = DataGraphHelper.cloneDataObject(var7);
						((List) var5).add(var11);
						var1.remove(var6);
						--var6;
					}
				}
			}
		} else {
			var5 = DataGraphHelper.cloneList(var1);
			if (var1 != null) {
				var1.clear();
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, var3);
		}

		return (List) var5;
	}

	private String getUniqueNameByUniqueId(String var1, boolean var2, Set var3) throws WIMException {
		String var5 = null;
		if (this.reposMgr.isEntryJoin()) {
			try {
				FederationEntity var6 = this.reposMgr.getFederationRepository().lookupByUniqueId(var1);
				if (var6 != null) {
					return var6.getUniqueName();
				}
			} catch (WIMException var15) {
				if (!var2) {
					throw var15;
				}

				trcLogger.logp(Level.FINER, CLASSNAME, "getUniqueNameByUniqueId",
						"IGNORE: exception [" + var15.getMessage() + "] on FED repository");
				var3.add(this.reposMgr.getFederationRepositoryID());
			}
		}

		boolean var16 = false;
		int var7 = 0;
		DataObject var8 = SDOHelper.createRootDataObject();
		var8.createDataObject("entities").createDataObject("identifier").setString("externalId", var1);

		while (var7 < this.reposMgr.getNumberOfRepositories() && !var16) {
			try {
				DataObject var9 = this.reposMgr.getRepositories()[var7].get(var8);
				if (var9 != null) {
					List var10 = var9.getList("entities");
					if (var10 != null) {
						DataObject var11 = (DataObject) var10.get(0);
						if (var11 != null) {
							DataObject var12 = var11.getDataObject("identifier");
							if (var12 != null) {
								var5 = var12.getString("uniqueName");
								var16 = true;
							}
						}
					}
				}
			} catch (EntityNotFoundException var13) {
				++var7;
			} catch (WIMException var14) {
				if (!var2) {
					throw var14;
				}

				trcLogger.logp(Level.FINER, CLASSNAME, "getUniqueNameByUniqueId",
						"IGNORE: exception [" + var14.getMessage() + "] on repository ["
								+ this.reposMgr.getRepositoryIDByRepositoryIndex(var7) + "]");
				var3.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var7));
				++var7;
			}
		}

		return var5;
	}

	private DataObject getIdentifierByUniqueIdOrUniqueName(String var1, String var2, boolean var3, Set var4)
			throws WIMException {
		DataObject var6 = null;
		Object var7 = null;
		boolean var8 = false;
		DataObject var9 = SDOHelper.createRootDataObject();
		DataObject var10 = var9.createDataObject("entities").createDataObject("identifier");
		int var11;
		DataObject var12;
		List var13;
		DataObject var14;
		if (var2 != null) {
			var11 = this.reposMgr.getRepositoryIndexByUniqueName(var2);
			if (var11 < 0) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var2),
						CLASSNAME, "getIdentifierByUniqueIdOrUniqueName");
			}

			var10.setString("uniqueName", var2);
			var12 = this.reposMgr.getRepositories()[var11].get(var9);
			if (var12 != null) {
				var13 = var12.getList("entities");
				if (var13 == null) {
					throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var2),
							CLASSNAME, "getIdentifierByUniqueIdOrUniqueName");
				}

				var14 = (DataObject) var13.get(0);
				if (var14 != null) {
					var6 = var14.getDataObject("identifier");
					if (var6 != null) {
						var8 = true;
					}
				}
			}
		} else {
			var11 = 0;

			while (var11 < this.reposMgr.getNumberOfRepositories() && !var8) {
				var9 = SDOHelper.createRootDataObject();
				var10 = var9.createDataObject("entities").createDataObject("identifier");
				if (var1 != null) {
					var10.setString("externalId", var1);
				}

				try {
					var12 = this.reposMgr.getRepositories()[var11].get(var9);
					if (var12 != null) {
						var13 = var12.getList("entities");
						if (var13 != null) {
							var14 = (DataObject) var13.get(0);
							if (var14 != null) {
								var6 = var14.getDataObject("identifier");
								if (var6 != null) {
									var8 = true;
								}
							}
						}
					}
				} catch (EntityNotFoundException var15) {
					++var11;
					var7 = var15;
				} catch (WIMException var16) {
					if (!var3) {
						throw var16;
					}

					trcLogger.logp(Level.FINER, CLASSNAME, "getIdentifierByUniqueIdOrUniqueName",
							"IGNORE: exception [" + var16.getMessage() + "] on repository ["
									+ this.reposMgr.getRepositoryIDByRepositoryIndex(var11) + "]");
					var4.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var11));
					var7 = var16;
				}
			}
		}

		if (!var8 && var7 != null) {
			throw var7;
		} else {
			return var6;
		}
	}

	private String getRepositoryIdByUniqueId(String var1, boolean var2, Set var3) throws WIMException {
		String var5 = null;
		if (this.reposMgr.getNumberOfRepositories() == 1) {
			return this.reposMgr.getRepositoryIDByRepositoryIndex(0);
		} else {
			if (this.reposMgr.isEntryJoin()) {
				try {
					FederationEntity var6 = this.reposMgr.getFederationRepository().get(var1);
					if (var6 != null) {
						return var6.getRepositoryId();
					}
				} catch (WIMException var15) {
					if (!var2) {
						throw var15;
					}

					trcLogger.logp(Level.FINER, CLASSNAME, "getRepositoryIdByUniqueId",
							"IGNORE: exception [" + var15.getMessage() + "] on FED repository");
					var3.add(this.reposMgr.getFederationRepositoryID());
				}
			}

			boolean var16 = false;
			int var7 = 0;
			DataObject var8 = SDOHelper.createRootDataObject();
			var8.createDataObject("entities").createDataObject("identifier").setString("externalId", var1);

			while (var7 < this.reposMgr.getNumberOfRepositories() && !var16) {
				try {
					DataObject var9 = this.reposMgr.getRepositories()[var7].get(var8);
					if (var9 != null) {
						List var10 = var9.getList("entities");
						if (var10 != null) {
							DataObject var11 = (DataObject) var10.get(0);
							if (var11 != null) {
								DataObject var12 = var11.getDataObject("identifier");
								if (var12 != null) {
									var5 = var12.getString("repositoryId");
									var16 = true;
								}
							}
						}
					}
				} catch (EntityNotFoundException var13) {
					++var7;
				} catch (WIMException var14) {
					if (!var2) {
						throw var14;
					}

					trcLogger.logp(Level.FINER, CLASSNAME, "getRepositoryIdByUniqueId",
							"IGNORE: exception [" + var14.getMessage() + "] on repository ["
									+ this.reposMgr.getRepositoryIDByRepositoryIndex(var7) + "]");
					var3.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var7));
					++var7;
				}
			}

			return var5;
		}
	}

	private List mergeRepositoryEntities(List[] var1, boolean var2, Set var3) throws WIMException {
		BasicEList var5 = null;
		if (var1 != null && var1.length > 0) {
			var5 = new BasicEList();

			for (int var6 = 0; var6 < var1.length; ++var6) {
				if (var1[var6] != null) {
					if (this.reposMgr.isEntryJoin()) {
						try {
							this.checkAndCreateEntryInFedTable(var6, var1[var6]);
						} catch (WIMException var8) {
							if (!var2) {
								throw var8;
							}

							trcLogger.logp(Level.FINER, CLASSNAME, "mergeRepositoryEntities",
									"IGNORE: exception [" + var8.getMessage() + "] on FED repository");
							var3.add(this.reposMgr.getFederationRepositoryID());
						}
					}

					var5.addAll(var1[var6]);
				}
			}
		}

		return var5;
	}

	private void checkAndCreateEntryInFedTable(int var1, List var2) throws WIMException {
		HashSet var3 = new HashSet();
		String var4 = this.reposMgr.getRepositoryIDByRepositoryIndex(var1);

		DataObject var7;
		String var9;
		for (int var5 = 0; var2 != null && var5 < var2.size(); ++var5) {
			DataObject var6 = (DataObject) var2.get(var5);
			var7 = var6.getDataObject("identifier");
			if (var7 != null) {
				String var8 = var7.getString("externalId");
				var9 = var7.getString("repositoryId");
				if (var9 != null && var9.equals(var4) && var8 != null) {
					var3.add(var8);
				}
			}
		}

		if (!var3.isEmpty()) {
			Map var13 = this.reposMgr.getFederationRepository().lookup(var4, var3);

			for (int var14 = 0; var14 < var2.size(); ++var14) {
				var7 = (DataObject) var2.get(var14);
				DataObject var15 = var7.getDataObject("identifier");
				var9 = var15.getString("externalId");
				if (var13 != null && !var13.isEmpty() && (var13.get(var9) != null || !var3.contains(var9))) {
					FederationEntity var16 = (FederationEntity) var13.get(var9);
					if (var16 != null) {
						var15.setString("uniqueId", var16.getUniqueId());
					}
				} else {
					String var10 = this.schemaMgr.getQualifiedTypeName(var7.getType());
					String var11 = var15.getString("uniqueName");
					String var12 = this.reposMgr.getFederationRepository().create(var10, var11, var4, var9);
					var15.setString("uniqueId", var12);
				}
			}
		}

	}

	public String getEntityType(DataObject var1) throws WIMException {
		return this.retrieveEntityType(this.retrieveTargetRepository(var1), var1);
	}

	private String retrieveEntityType(String var1, DataObject var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "retrieveEntityType", "(" + var1 + ", " + var2 + ")");
		}

		DataObject var4 = this.retrieveEntity(var1, var2, false, (Set) null);
		String var5 = this.schemaMgr.getQualifiedTypeName(var4.getType());
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "retrieveEntityType", var5);
		}

		return var5;
	}

	private boolean containToken(String var1, String var2) {
		boolean var4 = false;
		if (var1 != null) {
			StringTokenizer var5 = new StringTokenizer(var1, ";");

			while (var5.hasMoreTokens()) {
				String var6 = var5.nextToken();
				if (var6.equals(var2)) {
					var4 = true;
				}
			}
		}

		return var4;
	}

	private String retrieveTargetRepository(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "retrieveTargetRepository");
		}

		String var3 = null;
		String var4 = var1.getString("uniqueId");
		String var5 = var1.getString("uniqueName");
		if (var4 != null && var4.trim().length() != 0) {
			var3 = var1.getString("repositoryId");
			if (var3 == null) {
				this.retrieveEntity((String) null, var1, false, (Set) null);
			}

			var3 = var1.getString("repositoryId");
		} else {
			var3 = this.reposMgr.getRepositoryID(var5);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "retrieveTargetRepository", var3);
		}

		return var3;
	}

	private void mergeSchema(DataGraph var1, Map var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "mergeSchema");
		}

		DataObject var4 = var1.getRootObject().getDataObject("Root");
		DataObject var5 = var4.getDataObject("schema");
		List var6 = var4.getList("propertyDataTypes");
		Iterator var7 = var2.keySet().iterator();

		while (var7.hasNext()) {
			String var8 = (String) var7.next();
			DataGraph var9 = (DataGraph) var2.get(var8);
			if (var9 != null) {
				DataObject var10 = var9.getRootObject().getDataObject("Root").getDataObject("schema");
				List var11;
				if (var10 != null) {
					var11 = var10.getList("entitySchema");
					List var12 = var10.getList("propertySchema");
					List var13 = var10.getList("extensionPropertySchema");
					if (var11 != null) {
						var5.getList("entitySchema").addAll(var11);
					}

					if (var12 != null) {
						var5.getList("propertySchema").addAll(var12);
					}

					if (var13 != null) {
						var5.getList("extensionPropertySchema").addAll(var13);
					}
				}

				var11 = var9.getRootObject().getDataObject("Root").getList("propertyDataTypes");
				if (var11 != null) {
					var6.addAll(var11);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "mergeSchema");
		}

	}

	private void prepareDataGraphForCaller(DataObject var1, String var2, String var3, boolean var4, Set var5)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "prepareDataGraphForCaller");
		}

		if (var1 != null) {
			List var7 = var1.getList("entities");
			if (var7 != null) {
				for (int var8 = 0; var8 < var7.size(); ++var8) {
					DataObject var9 = (DataObject) var7.get(var8);
					String var10 = this.schemaMgr.getQualifiedTypeName(var9.getType());
					DataObject var11 = var9.getDataObject("identifier");
					if (var11 != null) {
						String var12 = var11.getString("repositoryId");
						this.prepareForCaller(var11, var10, var2, var3, var4, var5);
					}

					this.processReferenceProperty(var9, var10, true, var4, var5);
					int var13;
					DataObject var14;
					String var15;
					DataObject var16;
					List var17;
					if (this.schemaMgr.isSuperType("Group", var10)) {
						var17 = var9.getList("members");
						if (var17 != null) {
							for (var13 = 0; var13 < var17.size(); ++var13) {
								var14 = (DataObject) var17.get(var13);
								var15 = this.schemaMgr.getQualifiedTypeName(var14.getType());
								var16 = var14.getDataObject("identifier");
								this.prepareForCaller(var16, var15, (String) null, (String) null, var4, var5);
								this.processReferenceProperty(var14, var15, true, var4, var5);
							}
						}
					}

					var17 = var9.getList("groups");
					if (var17 != null) {
						for (var13 = 0; var13 < var17.size(); ++var13) {
							var14 = (DataObject) var17.get(var13);
							var15 = this.schemaMgr.getQualifiedTypeName(var14.getType());
							var16 = var14.getDataObject("identifier");
							this.prepareForCaller(var16, var15, (String) null, (String) null, var4, var5);
							if (this.propMgr.getReferencePropertyNameSet(var15) != null) {
								this.processReferenceProperty(var14, var15, true, var4, var5);
							}
						}
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "prepareDataGraphForCaller");
		}

	}

	private void prepareForCaller(DataObject var1, String var2, String var3, String var4, boolean var5, Set var6)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "prepareForCaller");
		}

		if (var1 != null) {
			String var8 = var1.getString("repositoryId");
			String var9 = var1.getString("externalId");
			String var10 = var1.getString("uniqueName");
			if (this.reposMgr.isEntryJoin()) {
				try {
					FederationEntity var11 = null;
					if (var3 != null) {
						var11 = this.reposMgr.getFederationRepository().lookupByUniqueId(var3);
					} else if (var4 != null) {
						var11 = this.reposMgr.getFederationRepository().lookupByUniqueName(var4);
					} else {
						var11 = this.reposMgr.getFederationRepository().lookupByUniqueName(var10);
					}

					if (var11 == null) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "prepareForCaller",
									"not found by uniqueName [" + var10 + "] so search by extID [" + var9 + "]");
						}

						var11 = this.reposMgr.getFederationRepository().get(var8, var9);
						if (var11 != null && trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "prepareForCaller", "found: " + var11);
						}
					}

					String var12;
					if (var11 == null) {
						var12 = this.reposMgr.getFederationRepository().create(var2, var10, var8, var9);
						var1.setString("uniqueId", var12);
					} else {
						var12 = var11.getUniqueId();
						var10 = var11.getUniqueName();
						String var13 = var11.getExternalId();
						String var14 = var1.getString("uniqueName");
						String var15 = var1.getString("externalId");
						if (!var13.equals(var15) && var15 != null) {
							this.reposMgr.getFederationRepository().updateExtId(var12, var15);
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "prepareForCaller", "update fedentity [" + var12
										+ "] with new extId [" + var15 + "], old value [" + var13 + "]");
							}
						}

						if (var14 != null && (var10 == null || !var10.equals(var14))) {
							this.reposMgr.getFederationRepository().updateUniqueName(var12, var14);
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "prepareForCaller", "update fedentity [" + var12
										+ "] with new uName [" + var14 + "], old value [" + var10 + "]");
							}
						}

						var1.setString("uniqueId", var12);
					}
				} catch (WIMException var16) {
					if (!var5) {
						throw var16;
					}

					trcLogger.logp(Level.FINER, CLASSNAME, "prepareForCaller",
							"IGNORE: exception [" + var16.getMessage() + "] on FED repository");
					var6.add(this.reposMgr.getFederationRepositoryID());
				}
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "prepareForCaller",
							"prepare identifier for caller, set [uniqueId=" + var9 + "]");
				}

				if (var9 != null) {
					var1.setString("uniqueId", var9);
				}
			}

			var1.unset("externalId");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "prepareForCaller");
		}

	}

	private void groupMembershipLookup(DataObject var1, String var2, DataObject var3, boolean var4, Set var5,
			DataObject var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "groupMembershipLookup", "repositoryId=" + var2);
		}

		int var8 = var3.getInt("level");
		if (var1 != null) {
			List var9 = var1.getList("entities");

			for (int var10 = 0; var10 < var9.size(); ++var10) {
				DataObject var11 = (DataObject) var9.get(var10);
				DataObject var12 = var11.getDataObject("identifier");
				int var15;
				DataObject var19;
				DataObject var24;
				List var25;
				DataObject var28;
				DataObject var29;
				DataObject var30;
				int var31;
				DataObject var33;
				if (var3.getType().getName().equals("GroupMembershipControl")) {
					List var13 = var11.getList("groups");
					ArrayList var14 = new ArrayList();
					var14.add(var12);
					if (var8 == 0) {
						for (var15 = 0; var15 < var13.size(); ++var15) {
							DataObject var16 = (DataObject) var13.get(var15);
							var14.add(var16.getDataObject("identifier"));
						}
					}

					Iterator var41 = this.reposMgr.getRepositoriesForGroupMembership(var2).iterator();

					label164 : while (true) {
						String var42;
						do {
							if (!var41.hasNext()) {
								break label164;
							}

							var42 = (String) var41.next();
						} while (var42.equals(var2));

						for (int var18 = 0; var18 < var14.size(); ++var18) {
							var19 = (DataObject) var14.get(var18);
							DataObject var20 = this.schemaMgr.createRootDataObject();
							DataObject var21 = var20.createDataObject("entities").createDataObject("identifier");
							var21.setString("uniqueId", var19.getString("uniqueId"));
							var21.setString("uniqueName", var19.getString("uniqueName"));
							var21.setString("repositoryId", var19.getString("repositoryId"));
							var21.setString("externalId", var19.getString("externalId"));
							var21.setString("externalName", var19.getString("externalName"));
							var20.getList("controls").add(DataGraphHelper.cloneDataObject(var3));
							if (var6 != null) {
								var20.getList("controls").add(DataGraphHelper.cloneDataObject(var6));
							}

							try {
								DataObject var22 = this.reposMgr.getRepository(var42).get(var20);
								if (var22 != null) {
									List var23 = var22.getList("entities");
									var24 = (DataObject) var23.get(0);
									var25 = var24.getList("groups");
									List var26 = var11.getList("groups");

									for (int var27 = 0; var27 < var25.size(); ++var27) {
										var28 = (DataObject) var25.get(var27);
										var29 = SDOHelper.cloneDataObject(var28);
										boolean var17 = false;
										var30 = var28.getDataObject("identifier");

										for (var31 = 0; var31 < var26.size(); ++var31) {
											DataObject var32 = (DataObject) var26.get(var31);
											var33 = var32.getDataObject("identifier");
											if (this.isIdentifierEqual(var33, var30)) {
												var17 = true;
												break;
											}
										}

										if (!var17) {
											var26.add(var29);
										}
									}
								}
							} catch (WIMException var35) {
								if (!var4) {
									throw var35;
								}

								trcLogger.logp(Level.FINER, CLASSNAME, "groupMembershipLookup",
										"IGNORE: exception [" + var35.getMessage() + "] on repository [" + var42 + "]");
								var5.add(var42);
							}
						}
					}
				}

				if (!var3.getType().getName().equals("GroupMemberControl")) {
					if (!"GroupMembershipControl".equals(var3.getType().getName())) {
						throw new WIMApplicationException("GENERIC",
								WIMMessageHelper.generateMsgParms(var3.getType().getName()), CLASSNAME,
								"groupMembershipLookup");
					}
				} else {
					String var39 = this.schemaMgr.getQualifiedTypeName(var11.getType());
					if (var39.equals("Group") || this.schemaMgr.isSuperType("Group", var39)) {
						List var40 = var11.getList("members");
						var15 = var40.size();
						ArrayList var43 = new ArrayList();
						if (var40 != null && var40.size() > 0) {
							for (int var44 = 0; var44 < var15; ++var44) {
								DataObject var45 = DataGraphHelper.cloneDataObject((DataObject) var40.get(var44));
								var19 = var45.getDataObject("identifier");
								String var46 = var19.getString("repositoryId");
								if (!var2.equalsIgnoreCase(var46) && !var43.contains(var46)) {
									boolean var47 = this.reposMgr.canGroupAcceptMember(var2, var46);
									if (var47) {
										Map var48 = this.getMembersInOtherRepositories(var11, var2, var4, var5);
										var15 = var40.size();
										if (var48 != null && !var48.isEmpty()) {
											Iterator var49 = var48.keySet().iterator();

											while (var49.hasNext()) {
												var24 = this.schemaMgr.createRootDataObject();
												var46 = (String) var49.next();
												var25 = (List) var48.get(var46);
												DataObject var50 = this.schemaMgr.createDataObject(
														"http://www.ibm.com/websphere/wim", "PropertyControl");
												var50.setList("properties", var3.getList("properties"));
												if (var8 != 1) {
													var24.getList("controls")
															.add(DataGraphHelper.cloneDataObject(var3));
												}

												var24.getList("controls").add(var50);
												if (var6 != null) {
													var24.getList("controls").add(var6);
												}

												var24.getList("entities").addAll(var25);
												var43.add(var46);

												try {
													DataObject var51 = this.reposMgr.getRepository(var46).get(var24);
													if (var51 != null) {
														List var52 = var51.getList("entities");

														for (int var53 = 0; var53 < var52.size(); ++var53) {
															var30 = (DataObject) var52.get(var53);
															String var57 = this.schemaMgr
																	.getQualifiedTypeName(var30.getType());
															if (this.schemaMgr.isSuperType("Group", var57)) {
																var11.getList("members")
																		.addAll(var30.getList("members"));
															}
														}

														var11.getList("members").addAll(var52);
													}
												} catch (EntityNotFoundException var37) {
													if (!this.reposMgr.isDeleteNonExistingMemebersFromGroup(var2,
															var46)) {
														throw var37;
													}

													var24.getList("entities").clear();
													var28 = null;
													var29 = this.schemaMgr.createRootDataObject();
													ArrayList var54 = new ArrayList();

													for (var31 = 0; var31 < var25.size(); ++var31) {
														var24.getList("entities").add(var25.get(var31));

														try {
															var28 = this.reposMgr.getRepository(var46).get(var24);
															if (var28 != null) {
																var29.getList("entities")
																		.addAll(var28.getList("entities"));
																var28.getList("entities").clear();
															}

															var24.getList("entities").clear();
														} catch (EntityNotFoundException var36) {
															if (trcLogger.isLoggable(Level.FINEST)) {
																trcLogger.logp(Level.FINEST, CLASSNAME,
																		"groupMembershipLookup",
																		"Exception thrown " + var36);
															}

															var54.add(var25.get(var31));
															var24.getList("entities").clear();
															if (var28 != null) {
																var28.getList("entities").clear();
															}
														}
													}

													if (var54 != null && var54.size() > 0) {
														this.deleteNonExistGrpMem(var1, var54);
													}

													if (var29 != null) {
														List var55 = var29.getList("entities");

														for (int var56 = 0; var56 < var55.size(); ++var56) {
															var33 = (DataObject) var55.get(var56);
															String var34 = this.schemaMgr
																	.getQualifiedTypeName(var33.getType());
															if (this.schemaMgr.isSuperType("Group", var34)) {
																var11.getList("members")
																		.addAll(var33.getList("members"));
															}
														}

														var11.getList("members").addAll(var55);
													}
												} catch (WIMException var38) {
													if (!var4) {
														throw var38;
													}

													trcLogger.logp(Level.FINER, CLASSNAME, "groupMembershipLookup",
															"IGNORE: exception [" + var38.getMessage()
																	+ "] on repository [" + var46 + "]");
													var5.add(var46);
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "groupMembershipLookup");
		}

	}

	private void deleteNonExistGrpMem(DataObject var1, List var2) throws WIMException {
		ArrayList var4 = new ArrayList();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteNonExistGrpMem",
					WIMTraceHelper.printDataGraph(var1) + "members which do not exist " + var2);
		}

		DataObject var5 = DataGraphHelper.deepCloneRootDataObject(var1);
		DataObject var6 = var5.getDataObject("entities.0");
		DataObject var7 = var6.getDataObject("identifier");
		if (var7 == null) {
			throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED", CLASSNAME,
					"deleteNonExistGrpMem");
		} else {
			Iterator var8 = var2.iterator();

			DataObject var9;
			DataObject var10;
			while (var8.hasNext()) {
				var9 = (DataObject) var8.next();
				var10 = var9.getDataObject("identifier");
				if (var10 == null) {
					throw new EntityIdentifierNotSpecifiedException("ENTITY_IDENTIFIER_NOT_SPECIFIED", CLASSNAME,
							"deleteNonExistGrpMem");
				}

				var4.add(var10.getString("externalId"));
			}

			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, CLASSNAME, "deleteNonExistGrpMem", "DELETED_GROUPMEMBER",
						WIMMessageHelper.generateMsgParms(var4));
			}

			if (var2 != null) {
				DataObject var13 = this.schemaMgr.createRootDataObject();
				var9 = var13.createDataObject("entities", "http://www.ibm.com/websphere/wim", "Group");
				var9.createDataObject("identifier");
				var9.setDataObject("identifier", var7);
				var9.getList("members").addAll(var2);
				var10 = var13.createDataObject("controls", "http://www.ibm.com/websphere/wim", "GroupMemberControl");
				var10.setInt("modifyMode", 3);
				String var11 = var7.getString("repositoryId");
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "deleteNonExistGrpMem",
							"before updating the greoup for deleting" + WIMTraceHelper.printDataGraph(var13));
				}

				DataObject var12 = this.reposMgr.getRepository(var11).update(var13);
			}

		}
	}

	private Map getMembersInOtherRepositories(DataObject var1, String var2, boolean var3, Set var4)
			throws WIMException {
		HashMap var6 = null;
		Object var7 = null;
		HashSet var8 = new HashSet();
		if (var1 != null) {
			List var9 = var1.getList("members");
			int var10 = 0;

			while (true) {
				if (var10 >= var9.size()) {
					if (var6 != null) {
						Iterator var17 = var8.iterator();

						while (var17.hasNext()) {
							var9.remove(var17.next());
						}
					}
					break;
				}

				DataObject var11 = (DataObject) var9.get(var10);
				DataObject var12 = var11.getDataObject("identifier");
				if (var12 != null) {
					String var13 = var12.getString("repositoryId");
					if (!var13.equals(var2)) {
						DataObject var14 = DataGraphHelper.cloneDataObject(var11);
						if (RepositoryManager.singleton().isEntryJoin()) {
							try {
								FederationEntity var15 = RepositoryManager.singleton().getFederationRepository()
										.get(var13, var12.getString("externalId"));
								if (var15 != null) {
									var14.getDataObject("identifier").setString("externalId", var15.getExternalId());
								}
							} catch (WIMException var16) {
								if (!var3) {
									throw var16;
								}

								trcLogger.logp(Level.FINER, CLASSNAME, "getMembersInOtherRepositories",
										"IGNORE: exception [" + var16.getMessage() + "] on FED repository");
								var4.add(this.reposMgr.getFederationRepositoryID());
							}
						}

						if (var6 == null) {
							var6 = new HashMap();
						}

						var7 = (List) var6.get(var13);
						if (var7 == null) {
							var7 = new BasicEList();
						}

						((List) var7).add(var14);
						var6.put(var13, var7);
						var8.add(var11);
					}
				}

				++var10;
			}
		}

		return var6;
	}

	private String getRealmName(DataObject var1) throws WIMApplicationException {
		String var2 = null;
		List var3 = var1.getList("contexts");
		if (var3 != null && var3.size() != 0) {
			for (int var4 = 0; var4 < var3.size() && (var2 == null || var2.length() == 0); ++var4) {
				DataObject var5 = (DataObject) var3.get(var4);
				String var6 = var5.getString("key");
				if (var6 != null && "realm".equals(var6)) {
					var2 = (String) var5.get("value");
				}
			}

			if (var2 == null) {
				var2 = this.realmMgr.getDefaultRealmName();
			}
		} else {
			var2 = this.realmMgr.getDefaultRealmName();
		}

		return var2;
	}

	private DataObject searchRepository(int var1, DataObject var2, HashMap var3, boolean var4, Set var5)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "searchRepository", "reposIndex=" + var1);
		}

		DataObject var7 = null;
		List var8 = null;
		List var9 = null;
		List var10 = null;
		boolean var11 = true;
		Map var12 = ControlsHelper.getControlMap(var2);
		DataObject var13 = (DataObject) var12.get("ChangeControl");
		if (var13 == null) {
			var13 = (DataObject) var12.get("SearchControl");
			var11 = false;
		}

		if (var3 != null) {
			var9 = (List) var3.get("REPOS");
			var10 = (List) var3.get("LA");
			if (var9 != null) {
				var13.setList("properties", var9);
			} else {
				var13.unset("properties");
			}
		}

		String var14;
		DataObject var16;
		try {
			var14 = this.reposMgr.getRepositoryIDByRepositoryIndex(var1);
			if (var11) {
				boolean var15 = this.isConfigChangeLogSupportEnabled(var14);
				if (var15) {
					var16 = this.keepCheckPointForReposOnly(var2, var14);
					var7 = this.reposMgr.getRepositories()[var1].search(var16);
				} else {
					var7 = SDOHelper.createRootDataObject();
					var16 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "ChangeResponseControl");
					var7.getList("controls").add(var16);
					DataObject var17 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "CheckPointType");
					var17.setString("repositoryId", var14);
					var16.setList("checkPoint", Collections.singletonList(var17));
				}
			} else {
				var7 = this.reposMgr.getRepositories()[var1].search(var2);
			}
		} catch (WIMException var18) {
			if (!var4) {
				throw var18;
			}

			trcLogger.logp(Level.FINER, CLASSNAME, "searchRepository", "IGNORE: exception [" + var18.getMessage()
					+ "] on repository [" + this.reposMgr.getRepositoryIDByRepositoryIndex(var1) + "]");
			var5.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var1));
		}

		if (var7 != null) {
			var8 = var7.getList("entities");
		}

		if (var8 != null && var8.size() > 0 && var10 != null && var10.size() > 0) {
			DataObject var19 = DataGraphHelper.cloneRootDataObject(var7);
			DataObject var20 = var19.createDataObject("controls", "http://www.ibm.com/websphere/wim",
					"PropertyControl");
			var20.setList("properties", var10);
			var7 = this.reposMgr.getLookasideRepository().get(var19);
		}

		var14 = this.reposMgr.getRepositoryIDByRepositoryIndex(var1);
		if (var7 != null) {
			var8 = var7.getList("entities");
			if (var8 != null && var8.size() > 0) {
				for (int var21 = 0; var21 < var8.size(); ++var21) {
					var16 = ((DataObject) var8.get(var21)).getDataObject("identifier");
					String var22 = var16.getString("externalId");
					var16.setString("repositoryId", var14);
					if (!this.reposMgr.isEntryJoin()) {
						var16.setString("uniqueId", var22);
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			if (var8 != null) {
				trcLogger.exiting(CLASSNAME, "searchRepository", "returning " + var8.size() + " entities");
			} else {
				trcLogger.exiting(CLASSNAME, "searchRepository", "returning null");
			}
		}

		return var7;
	}

	private boolean isConfigChangeLogSupportEnabled(String var1) throws WIMException {
		boolean var2 = false;
		DataObject var3 = ConfigManager.singleton().getRepositoryDataObject(var1);
		String var4 = var3.getString("supportChangeLog");
		if ("native".equals(var4)) {
			var2 = true;
		}

		return var2;
	}

	private DataObject searchAsyncRepository(String var1, DataObject var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "searchAsyncRepository");
		}

		DataObject var4 = this.reposMgr.getRepository(var1).search(var2);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "searchAsyncRepository", WIMTraceHelper.printDataObject(var4));
		}

		return var4;
	}

	private List searchLA(int var1, DataObject var2, HashMap var3, boolean var4, Set var5) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "searchLA", WIMTraceHelper.printDataGraph(var2));
		}

		DataObject var7 = null;
		List var8 = null;
		List var9 = null;
		List var10 = null;
		Map var11 = ControlsHelper.getControlMap(var2);
		DataObject var12 = (DataObject) var11.get("SearchControl");
		if (var3 != null) {
			var10 = (List) var3.get("LA");
			var9 = (List) var3.get("REPOS");
		}

		if (var10 != null && var10.size() > 0) {
			var12.setList("properties", var10);
		} else {
			var12.unset("properties");
		}

		try {
			var7 = this.reposMgr.getLookasideRepository().search(var2);
		} catch (WIMException var29) {
			if (!var4) {
				throw var29;
			}

			trcLogger.logp(Level.FINER, CLASSNAME, "searchLA",
					"IGNORE: exception [" + var29.getMessage() + "] on LA repository");
			var5.add(this.reposMgr.getLookasideRepositoryID());
		}

		DataObject var14;
		List var15;
		ArrayList var19;
		if (var7 != null) {
			DataObject var13 = DataGraphHelper.cloneRootDataObject(var7);
			var8 = var13.getList("entities");
			var14 = var13.createDataObject("controls", "http://www.ibm.com/websphere/wim", "PropertyControl");
			if (var9 != null) {
				var14.setList("properties", var9);
			} else {
				var14.unset("properties");
			}

			if (var8 != null && var8.size() > 0) {
				var15 = this.getEntitiesInRepository(var8, var1);
				if (var15 != null && var15.size() > 0) {
					var13.setList("entities", var15);
					DataObject var16 = null;

					try {
						try {
							var16 = this.reposMgr.getRepositories()[var1].get(var13);
						} catch (EntityNotFoundException var27) {
							if (this.throwEntityNotFoundException) {
								throw var27;
							}

							trcLogger.logp(Level.FINE, CLASSNAME, "searchLA",
									"Ignore exception [" + var27.getMessage());
							DataObject var18 = null;
							var19 = new ArrayList();
							DataObject var20 = this.schemaMgr.createRootDataObject();
							var14 = var20.createDataObject("controls", "http://www.ibm.com/websphere/wim",
									"PropertyControl");
							if (var9 != null) {
								var14.setList("properties", var9);
							} else {
								var14.unset("properties");
							}

							trcLogger.logp(Level.FINE, CLASSNAME, "searchLA",
									"Obsolete data exists in the Property Extension repository, retrieve one entity at a time and return the valid entries");

							for (int var21 = 0; var21 < var15.size(); ++var21) {
								DataObject var22 = (DataObject) var15.get(var21);
								DataObject var23 = DataGraphHelper.cloneDataObject(var22);
								BasicEList var24 = new BasicEList();
								var24.add(var23);
								var20.setList("entities", var24);

								try {
									var18 = this.reposMgr.getRepositories()[var1].get(var20);
									if (var18 != null) {
										var19.addAll(var18.getList("entities"));
									}
								} catch (EntityNotFoundException var26) {
									msgLogger.log(Level.WARNING, var26.getMessageKey(), var26.getMessageParams());
								}
							}

							if (var19.size() > 0) {
								var16 = this.schemaMgr.createRootDataObject();
								var16.setList("entities", var19);
							}
						}

						if (var16 != null) {
							this.mergeLookasideDataObject(var16, var7);
							var8 = var16.getList("entities");
						}
					} catch (WIMException var28) {
						if (!var4) {
							throw var28;
						}

						trcLogger.logp(Level.FINER, CLASSNAME, "searchLA", "IGNORE: exception [" + var28.getMessage()
								+ "] on repository [" + this.reposMgr.getRepositoryIDByRepositoryIndex(var1) + "]");
						var5.add(this.reposMgr.getRepositoryIDByRepositoryIndex(var1));
					}
				} else {
					var8.clear();
				}
			}
		}

		List var30 = var12.getList("searchBases");
		if (var30 != null && var30.size() > 0 && trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "searchLA", "SearchBase is Set");
		}

		if (var8 != null && var8.size() > 0 && var30 != null && var30.size() > 0) {
			var15 = null;
			Iterator var32 = var8.iterator();

			label110 : while (true) {
				DataObject var31;
				do {
					if (!var32.hasNext()) {
						break label110;
					}

					var14 = (DataObject) var32.next();
					var31 = var14.getDataObject("identifier");
				} while (var31 == null);

				String var17 = var31.getString("uniqueName");
				int var33 = 0;
				var19 = null;

				for (int var35 = 0; var35 < var30.size(); ++var35) {
					String var34 = var30.get(var35).toString();
					if (!StringUtil.endsWithIgnoreCase(var17, var34)) {
						++var33;
					}
				}

				if (var33 == var30.size()) {
					var32.remove();
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "searchLA", WIMTraceHelper.printObjectArray(new Object[]{var8}));
		}

		return var8;
	}

	private List getEntitiesInRepository(List var1, int var2) throws WIMException {
		int var3 = this.reposMgr.getNumberOfRepositories();
		Object var4 = new BasicEList();
		List var5 = DataGraphHelper.cloneList(var1);
		if (var3 == 1) {
			var4 = var5;
		} else {
			for (int var6 = 0; var6 < var5.size(); ++var6) {
				DataObject var7 = (DataObject) var5.get(var6);
				DataObject var8 = var7.getDataObject("identifier");
				if (var8 != null) {
					String var9 = var8.getString("repositoryId");
					if (var9 != null) {
						int var10 = this.reposMgr.getRepositoryIndexByRepositoryID(var9);
						if (var10 == var2) {
							((List) var4).add(var7);
						}
					}
				}
			}
		}

		return (List) var4;
	}

	private DataObject splitSearch(int var1, List var2, XPathNode var3, DataObject var4, HashMap var5, boolean var6,
			Set var7) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "splitSearch");
		}

		DataObject var9;
		var9 = null;
		short var10 = var3.getNodeType();
		label113 : switch (var10) {
			case 4 :
				FederationLogicalNode var11 = (FederationLogicalNode) var3;
				XPathNode var12 = (XPathNode) var11.getLeftChild();
				XPathNode var13 = (XPathNode) var11.getRightChild();
				String var14 = var11.getOperator();
				DataObject var15 = this.splitSearch(var1, var2, var12, var4, var5, var6, var7);
				DataObject var16 = this.splitSearch(var1, var2, var13, var4, var5, var6, var7);
				List var17;
				ArrayList var18;
				int var19;
				DataObject var20;
				DataObject var21;
				String var22;
				List var26;
				DataObject var30;
				if (var14.equals("or")) {
					var9 = var15;
					var17 = var15.getList("entities");
					var18 = new ArrayList(var17.size());

					for (var19 = 0; var19 < var17.size(); ++var19) {
						var20 = (DataObject) var17.get(var19);
						var21 = var20.getDataObject("identifier");
						if (var21 != null) {
							var22 = var21.getString("uniqueName");
							if (var22 != null) {
								var18.add(var22.toLowerCase());
							}
						}
					}

					var26 = var16.getList("entities");
					int var27 = 0;

					while (true) {
						if (var27 >= var26.size()) {
							break label113;
						}

						var21 = (DataObject) var26.get(var27);
						var30 = var21.getDataObject("identifier");
						if (var30 != null) {
							String var23 = var30.getString("uniqueName");
							if (var23 != null && !var18.contains(var23.toLowerCase())) {
								var9.getList("entities").add(var21);
							}
						}

						++var27;
					}
				} else {
					var17 = var15.getList("entities");
					var18 = new ArrayList(var17.size());

					for (var19 = 0; var19 < var17.size(); ++var19) {
						var20 = (DataObject) var17.get(var19);
						var21 = var20.getDataObject("identifier");
						if (var21 != null) {
							var22 = var21.getString("uniqueName");
							if (var22 != null) {
								var18.add(var22.toLowerCase());
							} else {
								var17.remove(var19);
								--var19;
							}
						}
					}

					var26 = var16.getList("entities");
					ArrayList var28 = new ArrayList(var26.size());

					DataObject var31;
					for (int var29 = 0; var29 < var26.size(); ++var29) {
						var30 = (DataObject) var26.get(var29);
						var31 = var30.getDataObject("identifier");
						if (var31 != null) {
							String var24 = var31.getString("uniqueName");
							if (var24 != null) {
								var28.add(var24.toLowerCase());
							} else {
								var26.remove(var29);
								--var29;
							}
						}
					}

					String var25;
					List var32;
					int var33;
					DataObject var34;
					if (var17.size() < var26.size()) {
						var9 = var15;
						var32 = var15.getList("entities");
						var33 = 0;

						while (true) {
							if (var33 >= var32.size()) {
								break label113;
							}

							var31 = (DataObject) var32.get(var33);
							var34 = var31.getDataObject("identifier");
							if (var34 != null) {
								var25 = var34.getString("uniqueName");
								if (!var28.contains(var25.toLowerCase())) {
									var32.remove(var33);
									--var33;
								}
							}

							++var33;
						}
					} else {
						var9 = var16;
						var32 = var16.getList("entities");
						var33 = 0;

						while (true) {
							if (var33 >= var32.size()) {
								break label113;
							}

							var31 = (DataObject) var32.get(var33);
							var34 = var31.getDataObject("identifier");
							if (var34 != null) {
								var25 = var34.getString("uniqueName");
								if (!var18.contains(var25.toLowerCase())) {
									var32.remove(var33);
									--var33;
								}
							}

							++var33;
						}
					}
				}
			case 8 :
				var3 = (XPathNode) ((FederationParenthesisNode) var3).getChild();
				var9 = this.splitSearch(var1, var2, var3, var4, var5, var6, var7);
				break;
			default :
				var4 = this.prepareSearchExpression(var2, var3, var4);
				var9 = this.propertyJoinSearch(var1, var3, var4, var5, var6, var7);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "splitSearch", WIMTraceHelper.printObjectArray(new Object[]{var9}));
		}

		return var9;
	}

	private DataObject prepareSearchExpression(List var1, XPathNode var2, DataObject var3) {
		String var4 = "@xsi:type='%ENTITYTYPE%'";
		String var5 = "(";
		String var6 = ")";
		String var7 = " and ";
		String var8 = " or ";
		String var9 = "(%SEARCH_STRING%)";
		StringBuffer var10 = new StringBuffer();
		StringBuffer var11 = new StringBuffer();
		StringBuffer var12 = new StringBuffer();
		if (var3 != null && var2 != null && var1 != null) {
			String var13;
			if (var1.size() == 1) {
				var13 = var4.replaceFirst("%ENTITYTYPE%", (String) var1.get(0));
				var11.append(var13);
			} else if (var1.size() > 1) {
				var11.append(var5);
				var13 = var4.replaceFirst("%ENTITYTYPE%", (String) var1.get(0));
				var11.append(var13);

				for (int var14 = 1; var14 < var1.size(); ++var14) {
					var11.append(var8);
					var13 = var4.replaceFirst("%ENTITYTYPE%", (String) var1.get(var14));
					var11.append(var13);
				}

				var11.append(var6);
			}

			short var17 = var2.getNodeType();
			switch (var17) {
				case 2 :
					var2 = (XPathNode) ((ParenthesisNode) var2).getChild();
				default :
					this.nodeToString(var12, var2);
					var10.append(var11);
					var10.append(var7);
					String var18 = var9.replaceFirst("%SEARCH_STRING%", var12.toString());
					var10.append(var18);
					Map var15 = ControlsHelper.getControlMap(var3);
					DataObject var16 = (DataObject) var15.get("SearchControl");
					var16.setString("expression", var10.toString());
			}
		}

		return var3;
	}

	private StringBuffer nodeToString(StringBuffer var1, XPathNode var2) {
		if (var2 != null && var1 != null) {
			short var3 = var2.getNodeType();
			switch (var3) {
				case 0 :
					var1.append(var2.toString());
					break;
				case 1 :
					var1 = this.nodeToString(var1, (XPathNode) ((LogicalNode) var2).getLeftChild());
					var1.append(" " + ((LogicalNode) var2).getOperator() + " ");
					var1 = this.nodeToString(var1, (XPathNode) ((LogicalNode) var2).getRightChild());
					break;
				case 2 :
					var1 = this.nodeToString(var1, (XPathNode) ((ParenthesisNode) var2).getChild());
			}
		}

		return var1;
	}

	private DataObject propertyJoinSearch(int var1, XPathNode var2, DataObject var3, HashMap var4, boolean var5,
			Set var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "propertyJoinSearch");
		}

		List var8 = null;
		boolean var9 = true;
		if (var2 != null) {
			short var10 = var2.getNodeType();
			switch (var10) {
				case 0 :
					var9 = ((PropertyNode) var2).isPropertyInRepository();
					break;
				case 1 :
					var9 = ((LogicalNode) var2).isPropertyInRepository();
					break;
				case 2 :
					var9 = ((ParenthesisNode) var2).isPropertyInRepository();
			}
		}

		DataObject var11 = null;
		if (var9) {
			var11 = this.searchRepository(var1, var3, var4, var5, var6);
		} else {
			var8 = this.searchLA(var1, var3, var4, var5, var6);
			var11 = this.schemaMgr.createRootDataObject();
			var11.getList("entities").addAll(var8);
		}

		return var11;
	}

	private HashMap validateAndDivideReturnProperties(List var1, List var2, String var3, boolean var4) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateAndDivideReturnProperties",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3}));
		}

		HashMap var6 = new HashMap();
		List var7 = DataGraphHelper.cloneList(var2);
		List var8 = DataGraphHelper.cloneList(var2);
		if (var1 != null && var4) {
			ArrayList var9 = new ArrayList();

			for (int var10 = 0; var10 < var1.size(); ++var10) {
				Set var11 = this.schemaMgr.getSubEntityTypes((String) var1.get(var10));
				if (var11 != null) {
					var9.addAll(var11);
				}
			}

			var1.addAll(var9);
		}

		Set var15 = this.propMgr.getLookAsidePropertyNameSet(var1);
		Set var16 = this.propMgr.getRepositoryPropertyNameSet(var3, var1);
		ArrayList var17 = new ArrayList();

		for (int var12 = 0; var12 < var7.size(); ++var12) {
			String var13 = (String) var7.get(var12);
			if (!var16.contains(var13) && !var13.equals("*")) {
				var17.add(var13);
			} else if (var13.equals("*")) {
				var7.clear();
				var7.add("*");
				var8.clear();
				var8.add("*");
				var6.put("REPOS", var7);
				var6.put("LA", var8);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "validateAndDivideReturnProperties",
							"propName=*, returnProps=" + var6);
				}

				return var6;
			}
		}

		var7.removeAll(var17);
		ArrayList var18 = new ArrayList();

		for (int var19 = 0; var19 < var8.size() && var15 != null; ++var19) {
			String var14 = (String) var8.get(var19);
			if (!var15.contains(var14)) {
				var18.add(var14);
			}
		}

		var8.removeAll(var18);
		var6.put("REPOS", var7);
		var6.put("LA", var8);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "validateAndDivideReturnProperties", var6);
		}

		return var6;
	}

	private void checkAccessibility(char var1, String var2, String var3, String var4) throws WIMException {
		switch (var1) {
			case 'c' :
			case 'd' :
			case 'u' :
				if (this.reposMgr.isReadOnly(var3)) {
					throw new OperationNotSupportedException("CANNOT_WRITE_TO_READ_ONLY_REPOSITORY",
							WIMMessageHelper.generateMsgParms(var3), CLASSNAME, "checkAccessibility");
				}
			case 'g' :
				if (this.reposMgr.isAccessEnabled(var2, var3) && !this.reposMgr.isEntityTypeActionSupported("UPDATE",
						var4, this.reposMgr.getRepositoryIndexByRepositoryID(var3))) {
					throw new OperationNotSupportedException("CANNOT_WRITE_TO_READ_ONLY_REPOSITORY",
							WIMMessageHelper.generateMsgParms(var3), CLASSNAME, "checkAccessibility");
				}
			default :
		}
	}

	private boolean isAsyncSearch(List[] var1, StringBuffer var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isAsyncSearch");
		}

		boolean var4 = false;
		int var5 = this.reposMgr.getNumberOfRepositories();

		for (int var6 = 0; var6 < var5; ++var6) {
			if (var1 == null || var1[var6] != null && var1[var6].size() > 0) {
				boolean var7 = this.reposMgr.isAsyncModeSupported(var6);
				if (var7 && var4) {
					throw new OperationNotSupportedException("ASYNC_CALL_WITH_MULTIPLE_REPOSITORIES_NOT_SUPPORTED",
							CLASSNAME, "isAsyncSearch");
				}

				if (var7) {
					var4 = var7;
					var2.append(this.reposMgr.getRepositoryIDByRepositoryIndex(var6));
				} else if (var4) {
					throw new OperationNotSupportedException("ASYNC_CALL_WITH_MULTIPLE_REPOSITORIES_NOT_SUPPORTED",
							CLASSNAME, "isAsyncSearch");
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isAsyncSearch");
		}

		return var4;
	}

	private void processReferenceProperty(DataObject var1, String var2, boolean var3, boolean var4, Set var5)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "processReferenceProperty",
					WIMMessageHelper.generateMsgParms(WIMTraceHelper.printDataObject(var1), var2));
		}

		Set var7 = this.propMgr.getReferencePropertyNameSet(var2);
		EDataObject var8 = (EDataObject) var1;
		if (var7 != null) {
			Iterator var9 = var7.iterator();

			label45 : while (true) {
				while (true) {
					Property var11;
					do {
						do {
							if (!var9.hasNext()) {
								break label45;
							}

							String var10 = (String) var9.next();
							var11 = this.schemaMgr.getProperty(var2, var10);
						} while (var11 == null);
					} while (!var1.isSet(var11));

					if (var11.isMany()) {
						List var14 = var1.getList(var11);

						for (int var13 = 0; var13 < var14.size(); ++var13) {
							this.processIdentifier((DataObject) var14.get(var13), var3, var4, var5);
						}
					} else {
						DataObject var12 = var1.getDataObject(var11);
						this.processIdentifier(var12, var3, var4, var5);
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "processReferenceProperty", WIMTraceHelper.printDataObject(var1));
		}

	}

	private void processIdentifier(DataObject var1, boolean var2, boolean var3, Set var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "processIdentifier", WIMTraceHelper.printDataObject(var1));
		}

		String var6 = var1.getString("uniqueName");
		String var7 = var1.getString("uniqueId");
		String var8 = var1.getString("externalId");
		String var9 = var1.getString("repositoryId");
		FederationEntity var10;
		if (var2) {
			if (this.reposMgr.isEntryJoin()) {
				try {
					var10 = null;
					if (var8 != null && var9 != null) {
						var10 = this.reposMgr.getFederationRepository().get(var9, var8);
						if (var10 != null) {
							var1.setString("uniqueId", var10.getUniqueId());
						}
					}
				} catch (WIMException var12) {
					if (!var3) {
						throw var12;
					}

					trcLogger.logp(Level.FINER, CLASSNAME, "processIdentifier",
							"IGNORE: exception [" + var12.getMessage() + "] on FED repository");
					var4.add(this.reposMgr.getFederationRepositoryID());
				}
			} else if (var8 != null) {
				var1.setString("uniqueId", var8);
			}

			var1.unset("externalId");
		} else {
			var10 = null;
			if (this.reposMgr.isEntryJoin()) {
				try {
					if (var7 != null) {
						var10 = this.reposMgr.getFederationRepository().lookupByUniqueId(var7);
						if (var10 == null) {
							throw new EntityNotFoundException("ENTITY_NOT_FOUND",
									WIMMessageHelper.generateMsgParms(var7), CLASSNAME, "processIdentifier");
						}

						var1.setString("externalId", var10.getExternalId());
						var1.setString("repositoryId", var10.getRepositoryId());
						var1.setString("uniqueName", var10.getUniqueName());
					} else if (var6 != null) {
						var10 = this.reposMgr.getFederationRepository().lookupByUniqueName(var6);
						if (var10 != null) {
							var1.setString("externalId", var10.getExternalId());
							var1.setString("repositoryId", var10.getRepositoryId());
							var1.setString("uniqueName", var10.getUniqueName());
						}
					}
				} catch (WIMException var13) {
					if (!var3) {
						throw var13;
					}

					trcLogger.logp(Level.FINER, CLASSNAME, "processIdentifier",
							"IGNORE: exception [" + var13.getMessage() + "] on FED repository");
					var4.add(this.reposMgr.getFederationRepositoryID());
				}
			}

			if (var10 == null) {
				if (this.reposMgr.getNumberOfRepositories() == 1 && this.reposMgr.isEntryJoin()) {
					if (var7 != null) {
						var1.setString("externalId", var7);
						var1.setString("repositoryId", this.reposMgr.getRepositoryIds()[0]);
					}
				} else {
					this.retrieveEntityFromRepository((String) null, var1, var3, var4);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "processIdentifier", WIMTraceHelper.printDataObject(var1));
		}

	}

	private List[] divideSearchBases(List var1, String var2, List[] var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "divideSearchBases",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3}));
		}

		for (int var5 = 0; var5 < var1.size(); ++var5) {
			String var6 = (String) var1.get(var5);
			if (var6 != null) {
				if (!this.realmMgr.isUniqueNameInRealm(var6, var2)) {
					throw new WIMApplicationException("NON_EXISTING_SEARCH_BASE",
							WIMMessageHelper.generateMsgParms(var6), CLASSNAME, "divideSearchBases");
				}

				int var7 = this.reposMgr.getRepositoryIndexByUniqueName(var6);
				var3[var7].add(var6);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "divideSearchBases", WIMTraceHelper.printObjectArray(new Object[]{var3}));
		}

		return var3;
	}

	private List[] getSearchBasesFromRealm(String var1, List[] var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getSearchBasesFromRealm",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2}));
		}

		Map var4 = this.realmMgr.getRepositoryIndexWithBaseEntriesByRealmName(var1);
		if (var4 == null) {
			for (int var5 = 0; var5 < this.reposMgr.getNumberOfRepositories(); ++var5) {
				var2[var5].addAll(
						this.reposMgr.getRepositoryBaseEntries(this.reposMgr.getRepositoryIDByRepositoryIndex(var5)));
			}
		} else {
			Set var9 = var4.keySet();
			Iterator var6 = var9.iterator();

			while (var6.hasNext()) {
				Integer var7 = (Integer) var6.next();
				List var8 = (List) var4.get(var7);
				var2[var7].addAll(var8);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getSearchBasesFromRealm",
					WIMTraceHelper.printObjectArray(new Object[]{var2}));
		}

		return var2;
	}

	private DataObject divideDataObject(DataObject var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "divideDataObject",
					WIMMessageHelper.generateMsgParms(WIMTraceHelper.printDataGraph(var1), var2));
		}

		DataObject var4 = SDOHelper.createRootDataObject();
		List var5 = var4.getList("entities");
		boolean var6 = false;
		List var7 = var1.getList("entities");
		DataObject var8 = (DataObject) var7.get(0);
		String var9 = this.schemaMgr.getQualifiedTypeName(var8.getType());
		DataObject var10 = DataGraphHelper.cloneDataObject(var8);
		Set var11 = this.propMgr.getLookAsidePropertyNameSet(var9);
		if (var11 != null) {
			Set var12 = this.propMgr.getRepositoryPropertyNameSet(var2, var9);
			Iterator var13;
			String var14;
			Property var15;
			if (var12 != null) {
				var13 = var12.iterator();

				while (var13.hasNext()) {
					var14 = (String) var13.next();
					var15 = this.schemaMgr.getProperty(var9, var14);
					if (var15 != null && var10.isSet(var15)) {
						var10.unset(var15);
					}
				}
			}

			var13 = var11.iterator();

			while (var13.hasNext()) {
				var14 = (String) var13.next();
				var15 = this.schemaMgr.getProperty(var9, var14);
				if (var15 != null && var8.isSet(var15) && var10.isSet(var15)) {
					var6 = true;
					var8.unset(var15);
				}
			}

			if (!var6) {
				var4 = null;
			} else {
				var5.add(var10);
			}
		} else {
			var4 = null;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			if (var4 != null) {
				trcLogger.exiting(CLASSNAME, "divideDataObject", WIMMessageHelper
						.generateMsgParms(WIMTraceHelper.printDataGraph(var1), WIMTraceHelper.printDataGraph(var4)));
			} else {
				trcLogger.exiting(CLASSNAME, "divideDataObject");
			}
		}

		return var4;
	}

	private void unsetExternalId(DataObject var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "unsetExternalId");
		}

		if (var1 != null) {
			List var3 = var1.getList("entities");
			if (var3 != null && var3.size() > 0) {
				for (int var4 = 0; var4 < var3.size(); ++var4) {
					DataObject var5 = (DataObject) var3.get(var4);
					DataObject var6 = var5.getDataObject("identifier");
					if (var6 != null) {
						var6.unset("externalId");
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "unsetExternalId");
		}

	}

	private void isReferenceToLoggedInUser(DataObject var1) throws WIMApplicationException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "isReferenceToLoggedInUser(DataObject)");
		}

		DataObject var4 = (DataObject) var1.getList("entities").get(0);
		DataObject var5 = var4.getDataObject("identifier");
		String var6 = var5.getString("uniqueName");
		String var7 = this.getCallerUniqueName();
		if (var6 != null && var6.equalsIgnoreCase(var7)) {
			if (var3) {
				trcLogger.exiting(CLASSNAME, "isReferenceToLoggedInUser(DataObject)",
						"#Logged-in user being deleted - Exception ");
			}

			throw new WIMApplicationException("CANNOT_DELETE_LOGGED_IN_USER", WIMMessageHelper.generateMsgParms(var6),
					Level.SEVERE, CLASSNAME, "isReferenceToLoggedInUser(DataObject)");
		} else {
			if (var3) {
				trcLogger.exiting(CLASSNAME, "isReferenceToLoggedInUser(DataObject)", "#success");
			}

		}
	}

	private String getCallerUniqueName() throws WIMApplicationException {
		boolean var2 = trcLogger.isLoggable(Level.FINER);
		if (var2) {
			trcLogger.entering(CLASSNAME, "getCallerUniqueName()");
		}

		String var3 = null;
		Subject var4 = null;
		WSCredential var5 = null;

		try {
			if ((var4 = WSSubject.getRunAsSubject()) == null) {
				var4 = WSSubject.getCallerSubject();
			}

			if (var4 == null) {
				throw new WIMApplicationException("AUTH_SUBJECT_FAILURE", Level.SEVERE, CLASSNAME,
						"getCallerUniqueName()");
			}

			Iterator var6 = var4.getPublicCredentials(WSCredential.class).iterator();
			if (var6.hasNext()) {
				var5 = (WSCredential) var6.next();
			}

			if (null == var5) {
				throw new WIMApplicationException("AUTH_SUBJECT_CRED_FAILURE", Level.SEVERE, CLASSNAME,
						"getCallerUniqueName()");
			}

			var3 = var5.getUniqueSecurityName();
			if (null == var3) {
				throw new WIMApplicationException("AUTH_SUBJECT_CRED_FAILURE", Level.SEVERE, CLASSNAME,
						"getCallerUniqueName()");
			}
		} catch (Exception var7) {
			if ("AUTH_SUBJECT_FAILURE".equals(var7.getMessage())) {
				throw new WIMApplicationException("AUTH_SUBJECT_FAILURE", Level.SEVERE, CLASSNAME,
						"getCallerUniqueName()", var7);
			}

			throw new WIMApplicationException("AUTH_SUBJECT_CRED_FAILURE", Level.SEVERE, CLASSNAME,
					"getCallerUniqueName()", var7);
		}

		if (var2) {
			trcLogger.exiting(CLASSNAME, "getCallerUniqueName()", "#Unique name from subject " + var3);
		}

		return var3;
	}

	public List getReposForExternalName(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getReposForExternalName", WIMMessageHelper.generateMsgParms(var1, var2));
		}

		var1 = UniqueNameHelper.getValidUniqueName(var1);
		ArrayList var4 = new ArrayList();
		if (var1 != null && !var1.trim().equals("")) {
			int var5 = var1.length();
			Map var6 = this.realmMgr.getRepositoryIndexWithBaseEntriesByRealmName(var2);
			Set var7 = var6.keySet();
			Iterator var8 = var7.iterator();

			while (true) {
				while (var8.hasNext()) {
					int var9 = (Integer) var8.next();
					List var10 = (List) var6.get(var9);
					String var11 = this.reposMgr.getRepositoryIDByRepositoryIndex(var9);
					DataObject var12 = this.reposMgr.getRepositoryConfig(var11);
					List var13 = var12.getList("baseEntries");

					for (int var14 = 0; var14 < var13.size(); ++var14) {
						DataObject var15 = (DataObject) var13.get(var14);
						if (var10.contains(var15.getString("name"))) {
							String var16 = var15.getString("nameInRepository");
							if (var16 == null) {
								var16 = var15.getString("name");
							}

							if (var16 != null && var16.trim().equals("")) {
								var4.add(var11);
							}

							var16 = UniqueNameHelper.getValidUniqueName(var16);
							if (var16 != null && var16.length() > 0) {
								int var17 = var16.length();
								if (var5 == var17 && var1.equalsIgnoreCase(var16)) {
									var4.add(0, var11);
									break;
								}

								if (var5 > var17 && StringUtil.endsWithIgnoreCase(var1, "," + var16)) {
									var4.add(0, var11);
									break;
								}
							}
						}
					}
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "getReposForExternalName", var4);
				}

				return var4;
			}
		} else {
			return var4;
		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = ProfileManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
	}
}