package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.wim.Service;
import com.ibm.websphere.wim.ServiceProvider;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.CertificateMapFailedException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.RealmManager;
import com.ibm.ws.wim.SPIServiceProvider;
import com.ibm.ws.wim.registry.WIMUserRegistryDefines;
import com.ibm.ws.wim.registry.dataobject.IDAndRealm;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.UniqueNameHelper;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BridgeUtils implements WIMUserRegistryDefines {
	private static final String COPYRIGHT_NOTICE;
	private final String className = BridgeUtils.class.getName();
	private Logger bridgeUtilsLog;
	private Logger bridgeUtilsTrace;
	private static Map<String, BridgeUtils> singleton;
	private Service wimService;
	private String wimServiceLock;
	private short groupLevel;
	public boolean useGlobalTransaction;
	public static boolean returnRealmInfoInUniqueUserId;
	private String groupLevelLock;
	public static Boolean allowDNAsPrincipalName;
	public static final String ALLOW_DN_PRINCIPAL_NAME_AS_LITERAL = "com.ibm.ws.wim.registry.allowDNPrincipalNameAsLiteral";
	public static Boolean dynamicVMMRealmUpdate;
	public static final String DYNAMIC_VMM_REALM_UPDATE = "com.ibm.websphere.security.dynamicVMMRealmUpdate";

	private BridgeUtils() {
		this.bridgeUtilsLog = WIMLogger.getMessageLogger(this.className);
		this.bridgeUtilsTrace = WIMLogger.getTraceLogger(this.className);
		this.wimService = null;
		this.wimServiceLock = "WIM_SERVICE_LOCK";
		this.groupLevel = 0;
		this.useGlobalTransaction = true;
		this.groupLevelLock = "GROUP_LEVEL_LOCK";
		String var1 = "BridgeUtils";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var1);
		}

		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.exiting(this.className, var1);
		}

	}

	public static synchronized BridgeUtils singleton() {
		String var0 = DomainManagerUtils.getDomainId();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new BridgeUtils());
		}

		return (BridgeUtils) singleton.get(var0);
	}

	public void initialize(Properties var1) throws CustomRegistryException, RemoteException {
		String var2 = "initialize";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var2, "inputProperties = " + var1);
		}

		String var3;
		try {
			var3 = this.wimServiceLock;
			synchronized (this.wimServiceLock) {
				this.wimService = ServiceProvider.singleton();
			}
		} catch (WIMException var20) {
			throw new CustomRegistryException(var20);
		}

		var3 = (String) var1.get("com.ibm.ws.wim.registry.useGlobalTransaction");
		if (var3 != null) {
			this.useGlobalTransaction = Boolean.parseBoolean(var3);
		}

		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.logp(Level.FINER, this.className, var2,
					"com.ibm.ws.wim.registry.useGlobalTransaction = " + this.useGlobalTransaction);
		}

		String var4 = (String) var1.get("com.ibm.ws.wim.registry.returnRealmQualifiedId");
		if (var4 != null) {
			returnRealmInfoInUniqueUserId = Boolean.parseBoolean(var4);
		}

		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.logp(Level.FINER, this.className, var2,
					"com.ibm.ws.wim.registry.returnRealmQualifiedId = " + returnRealmInfoInUniqueUserId);
		}

		String var5 = var1.getProperty("com.ibm.ws.wim.registry.allowDNPrincipalNameAsLiteral");
		if (var5 != null) {
			allowDNAsPrincipalName = Boolean.parseBoolean(var5);
		}

		String var6 = var1.getProperty("com.ibm.websphere.security.dynamicVMMRealmUpdate");
		if (var6 != null) {
			dynamicVMMRealmUpdate = Boolean.parseBoolean(var6);
		}

		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.logp(Level.FINER, this.className, var2,
					"com.ibm.websphere.security.dynamicVMMRealmUpdate = " + dynamicVMMRealmUpdate);
		}

		String var7 = (String) var1.get("com.ibm.ws.wim.registry.grouplevel");

		try {
			String var8;
			if (var7 != null && !var7.equals("")) {
				if (Short.parseShort(var7) == 1) {
					var8 = this.groupLevelLock;
					synchronized (this.groupLevelLock) {
						this.groupLevel = 1;
					}
				} else if (Short.parseShort(var7) == 0) {
					var8 = this.groupLevelLock;
					synchronized (this.groupLevelLock) {
						this.groupLevel = 0;
					}
				} else {
					var8 = this.groupLevelLock;
					synchronized (this.groupLevelLock) {
						this.groupLevel = 0;
					}
				}
			} else {
				var8 = this.groupLevelLock;
				synchronized (this.groupLevelLock) {
					this.groupLevel = 0;
				}
			}
		} catch (NumberFormatException var21) {
			String var9 = this.groupLevelLock;
			synchronized (this.groupLevelLock) {
				this.groupLevel = 0;
			}
		}

		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.exiting(this.className, var2);
		}

	}

	public void initializeSPIServiceProvider(Properties var1) throws CustomRegistryException, RemoteException {
		String var2 = "initializeSPIServiceProvider";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var2, "inputProperties = " + var1);
		}

		try {
			String var3 = this.wimServiceLock;
			synchronized (this.wimServiceLock) {
				this.wimService = new SPIServiceProvider((String) var1.get("SESSIONID"));
			}
		} catch (WIMException var6) {
			throw new CustomRegistryException(var6);
		}

		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.exiting(this.className, var2);
		}

	}

	protected void validateId(String var1) throws WIMException {
		String var2 = "validateId";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var2, "inputId = \"" + var1 + "\"");
		}

		if (var1 == null) {
			throw new WIMException(var1);
		} else {
			if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
				this.bridgeUtilsTrace.exiting(this.className, var2);
			}

		}
	}

	protected void validateLimit(int var1) throws WIMException {
		String var2 = "validateLimit";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var2, "inputLimit = \"" + var1 + "\"");
		}

		if (var1 < 0) {
			throw new WIMException(Integer.toString(var1));
		} else {
			if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
				this.bridgeUtilsTrace.exiting(this.className, var2);
			}

		}
	}

	protected void validateCertificateArray(X509Certificate[] var1) throws CertificateMapFailedException {
		String var2 = "validateCertificateArray";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var2, "inputCertificates = \"" + var1 + "\"");
		}

		if (var1 != null && var1[0] != null) {
			if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
				this.bridgeUtilsTrace.exiting(this.className, var2);
			}

		} else {
			throw new CertificateMapFailedException();
		}
	}

	protected IDAndRealm seperateIDAndRealm(String var1) throws WIMException {
		String var2 = "seperateIDAndRealm";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.logp(Level.FINER, this.className, var2, "inputString = \"" + var1 + "\"");
		}

		String var3 = RealmManager.singleton().getDefaultRealmName();
		String var4 = RealmManager.singleton().getDelimiter(var3);
		Set var5 = RealmManager.singleton().getRealmNames();
		HashMap var6 = new HashMap();
		Iterator var7 = var5.iterator();

		while (var7.hasNext()) {
			String var8 = (String) var7.next();
			String var9 = RealmManager.singleton().getDelimiter(var8);
			var6.put(var8, var9);
		}

		return this.seperateIDAndRealm(var1, var3, var4, var5, var6);
	}

	protected IDAndRealm seperateIDAndRealm(String var1, String var2, String var3, Set var4, Map var5)
			throws WIMException {
		String var6 = "seperateIDAndRealm";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var6, "inputString = \"" + var1 + "\"");
			this.bridgeUtilsTrace.entering(this.className, var6, "defaultRealm=" + var2 + ", defaultRealmDelimiter="
					+ var3 + ", realms=" + var4 + ", realmsDelimiter=" + var5);
		}

		IDAndRealm var7 = null;
		boolean var8 = false;
		boolean var9 = false;
		Iterator var10 = var4.iterator();

		label74 : while (true) {
			if (var10.hasNext() && !var8) {
				StringBuffer var11 = new StringBuffer();
				String var12 = (String) var10.next();
				String var13 = (String) var5.get(var12);
				var7 = new IDAndRealm();
				int var14 = var1.length() - 1;

				while (true) {
					if (var14 < 0) {
						continue label74;
					}

					if (Character.toString(var1.charAt(var14)).equals(var13)) {
						if (!var7.isRealmDefined()) {
							if (var14 - 1 >= 0 && var1.charAt(var14 - 1) == '\\') {
								var11.append(var1.charAt(var14));
								--var14;
							} else {
								String var15 = var11.reverse().toString();
								if (!var12.equals(var15)) {
									continue label74;
								}

								var7.setDelimiter(var13);
								var7.setRealm(var15);
								var11.setLength(0);
								var9 = true;
							}
						} else {
							if (var14 - 1 < 0 || var1.charAt(var14 - 1) != '\\') {
								throw new WIMException(var1);
							}

							var11.append(var1.charAt(var14));
							--var14;
						}
					} else {
						if (var14 == 0 && var9) {
							var11.append(var1.charAt(var14));
							var7.setId(var11.reverse().toString());
							var8 = true;
							continue label74;
						}

						if (var14 == 0) {
							var11.append(var1.charAt(var14));
							var7.setId(var11.reverse().toString());
							var11.setLength(0);
						} else {
							var11.append(var1.charAt(var14));
						}
					}

					--var14;
				}
			}

			if (!var7.isRealmDefined()) {
				var7.setDelimiter(var3);
				var7.setRealm(var2);
			}

			if (!var8 && var7.getId() == "") {
				var7.setId(var1);
			}

			if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
				this.bridgeUtilsTrace.exiting(this.className, var6, "returnValue = \"" + var7 + "\"");
			}

			return var7;
		}
	}

	public boolean isIdentifierTypeProperty(String var1) {
		String var2 = "isIdentifierTypeProperty";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var2, "inputProperty = \"" + var1 + "\"");
		}

		boolean var3 = false;
		if (var1 != null && (var1.equals("uniqueId") || var1.equals("uniqueName") || var1.equals("externalId")
				|| var1.equals("externalName"))) {
			var3 = true;
		}

		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.exiting(this.className, var2, "returnValue = \"" + Boolean.toString(var3) + "\"");
		}

		return var3;
	}

	protected void createRealmDataObject(DataObject var1, String var2) {
		String var3 = "createRealmDataObject";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var3,
					"inputRootDataObject = \"" + var1 + "\", inputRealm = \"" + var2 + "\"");
		}

		DataObject var4 = var1.createDataObject("contexts");
		var4.set("key", "realm");
		var4.set("value", var2);
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.exiting(this.className, var3);
		}

	}

	protected void createPropertyControlDataObject(DataObject var1, String var2) {
		String var3 = "createPropertyControlDataObject";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var3,
					"inputRootDataObject = \"" + var1 + "\", inputProperty = \"" + var2 + "\"");
		}

		DataObject var4 = var1.createDataObject("controls", "http://www.ibm.com/websphere/wim", "PropertyControl");
		var4.getList("properties").add(var2);
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.exiting(this.className, var3);
		}

	}

	protected void createLoginControlDataObject(DataObject var1, String var2) {
		String var3 = "createLoginControlDataObject";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var3,
					"inputRootDataObject = \"" + var1 + "\", inputProperty = \"" + var2 + "\"");
		}

		DataObject var4 = var1.createDataObject("controls", "http://www.ibm.com/websphere/wim", "LoginControl");
		var4.getList("properties").add(var2);
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.exiting(this.className, var3);
		}

	}

	protected DataObject getEntityByIdentifier(DataObject var1, String var2, String var3, String var4, BridgeUtils var5)
			throws WIMException, RemoteException {
		String var6 = "getEntityByIdentifier";
		this.bridgeUtilsTrace.entering(this.className, var6,
				"inputRootDataObject = \"" + var1 + "\", inputAttrName = \"" + var2 + "\", inputAttrValue = \"" + var3
						+ "\", outputAttrName = \"" + var4 + "\"");
		boolean var7 = var5.isIdentifierTypeProperty(var2);
		boolean var8 = var2.equals("externalName");
		boolean var9 = var5.isIdentifierTypeProperty(var4);
		DataObject var10 = null;
		if (var7) {
			if (!var9) {
				var5.createPropertyControlDataObject(var1, var4);
			}

			DataObject var11 = var1.createDataObject("entities");
			var11.createDataObject("identifier").setString(var2, var3);
			if (var8) {
				var1.createDataObject("controls", "http://www.ibm.com/websphere/wim", "ExternalNameControl");
			}

			var10 = var5.getWimService().get(var1);
		}

		this.bridgeUtilsTrace.exiting(this.className, var6, "returnValue = \"" + var10 + "\"");
		return var10;
	}

	protected void logException(Exception var1, String var2) {
		String var3 = "logException";
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, var3,
					"inputToLog = \"" + var1 + "\" inputClassname = \"" + var2 + "\"");
		}

		if (this.bridgeUtilsLog.isLoggable(Level.FINER)) {
			this.bridgeUtilsLog.logp(Level.SEVERE, var2, var3, "", WIMMessageHelper.generateMsgParms(var1));
		}

		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.exiting(this.className, var3);
		}

	}

	protected Service getWimService() {
		if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
			this.bridgeUtilsTrace.entering(this.className, "getWimService");
		}

		String var1 = this.wimServiceLock;
		synchronized (this.wimServiceLock) {
			if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
				this.bridgeUtilsTrace.exiting(this.className, "getWimService");
			}

			return this.wimService;
		}
	}

	protected short getGroupDepth() {
		String var1 = this.groupLevelLock;
		synchronized (this.groupLevelLock) {
			return this.groupLevel;
		}
	}

	protected String getRealInputAttrName(String var1, String var2, boolean var3) {
		String var4 = "getRealInputAttrName";
		this.bridgeUtilsTrace.entering(this.className, var4,
				"inputAttrName = \"" + var1 + "\", id = \"" + var2 + "\", isUser = \"" + var3 + "\"");
		boolean var5 = UniqueNameHelper.isDN(var2) != null;
		boolean var6 = this.isIdentifierTypeProperty(var1);
		if (!var6 && var5 && !allowDNAsPrincipalName) {
			if (this.bridgeUtilsLog.isLoggable(Level.FINER)) {
				this.bridgeUtilsLog.logp(Level.FINE, this.className, var4, "WARNING: the propertyForInput " + var1
						+ " doesn't match the format of input value " + var2 + ", switch to uniqueName");
			}

			var1 = "uniqueName";
		} else if (var6 && !var5) {
			if (var3) {
				if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
					this.bridgeUtilsTrace.logp(Level.WARNING, this.className, "", "the propertyForInput " + var1
							+ " doesn't match the format of input value " + var2 + ", switch to principalName");
				}

				var1 = "principalName";
			} else {
				if (this.bridgeUtilsTrace.isLoggable(Level.FINER)) {
					this.bridgeUtilsTrace.logp(Level.WARNING, this.className, "", "the propertyForInput " + var1
							+ " doesn't match the format of input value " + var2 + ", swith to cn");
				}

				var1 = "cn";
			}
		}

		this.bridgeUtilsTrace.exiting(this.className, var4, "returnValue = \"" + var1 + "\"");
		return var1;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		singleton = Collections.synchronizedMap(new HashMap());
		returnRealmInfoInUniqueUserId = false;
		allowDNAsPrincipalName = false;
		dynamicVMMRealmUpdate = false;
	}
}