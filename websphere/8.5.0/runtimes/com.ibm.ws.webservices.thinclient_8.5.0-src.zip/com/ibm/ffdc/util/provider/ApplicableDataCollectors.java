package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.Ffdc;
import com.ibm.ffdc.Manager;
import com.ibm.ffdc.config.DataCollector;
import com.ibm.ffdc.config.Formattable;
import com.ibm.ffdc.config.IncidentStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ApplicableDataCollectors extends FfdcProviderDependent<FfdcProvider> implements Formattable {
	private final Throwable th;
	private final List<DataCollector> rc;
	static final String BEGIN_DATA_COLLECTED = "Begin data collected by";
	static final String END_DATA_COLLECTED = "End data collected by";
	static final String DATA_COLLECTOR_FAILED_SEE_FFDC = "Data collector failed see FFDC";

	public ApplicableDataCollectors(FfdcProvider provider, Throwable th) {
		super(provider);
		this.th = th;
		this.rc = new ArrayList(provider.getDataCollectors().size());
		this.rc.addAll(provider.getDataCollectors());
	}

	public List<DataCollector> getDataCollectors(Throwable th) {
		ArrayList<DataCollector> result = new ArrayList();
		StackTraceElement[] stack = th.getStackTrace();
		StackTraceElement[] arr$ = stack;
		int len$ = stack.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			StackTraceElement ste = arr$[i$];
			this.collect(ste, result);
		}

		return result;
	}

	public Throwable getThrowable() {
		return this.th;
	}

	private void collect(StackTraceElement ste, List<DataCollector> collectors) {
		ListIterator dci = this.rc.listIterator();

		while (dci.hasNext()) {
			DataCollector dc = (DataCollector) dci.next();
			String[] supportedTypeNames = null;

			try {
				supportedTypeNames = dc.getSupportedTypeNames();
			} catch (Exception var11) {
				Manager.Ffdc.log(var11, this, this.getClass().getName(), "69");
				this.provider.deregister(dc);
			}

			if (supportedTypeNames != null && supportedTypeNames.length != 0) {
				String[] arr$ = supportedTypeNames;
				int len$ = supportedTypeNames.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					String stn = arr$[i$];
					String cname = ste.getClassName();
					if (stn.startsWith(ste.getClassName())) {
						if (stn.length() == cname.length()) {
							this.collect(dci, collectors, dc);
						} else if (stn.length() - cname.length() >= 2 && stn.charAt(cname.length()) == '#'
								&& stn.substring(cname.length() + 1).equals(ste.getMethodName())) {
							this.collect(dci, collectors, dc);
						}
					}
				}
			}
		}

	}

	private void collect(ListIterator<DataCollector> dci, List<DataCollector> collectors, DataCollector dc) {
		dci.remove();
		collectors.add(dc);
	}

	public void formatTo(IncidentStream is) {
		List<DataCollector> collectors = this.getDataCollectors(this.th);
		Iterator i$ = collectors.iterator();

		while (i$.hasNext()) {
			DataCollector collector = (DataCollector) i$.next();
			this.formatTo(collector, this.th, is);
		}

	}

	private void formatTo(DataCollector collector, Throwable th, IncidentStream is) {
		String collectorName;
		try {
			collectorName = collector.toString();
		} catch (Exception var8) {
			Ffdc ffdc = Manager.Ffdc.getFfdc(var8, this, this.getClass().getName(), "114");
			ffdc.log(new Object[0]);
			is.write("Data collector failed see FFDC", ffdc.toString());
			return;
		}

		is.write("Begin data collected by", collectorName);

		Collection data;
		try {
			data = collector.collect(th);
		} catch (Exception var9) {
			Ffdc ffdc = Manager.Ffdc.getFfdc(var9, this, this.getClass().getName() + "126");
			if (ffdc.isLoggable()) {
				ffdc.log(new Object[0]);
			}

			is.write("Data collector failed see FFDC", ffdc.toString());
			is.write("End data collected by", collectorName);
			return;
		}

		if (data != null && data.size() != 0) {
			Iterator i$ = data.iterator();

			while (i$.hasNext()) {
				Object o = i$.next();
				is.write((String) null, o);
			}

			is.write("End data collected by", collectorName);
		} else {
			is.write("End data collected by", collectorName);
		}
	}
}