package com.google.inject.internal.cglib.proxy;

import com.google.inject.internal.cglib.core.ClassEmitter;
import com.google.inject.internal.cglib.core.CodeEmitter;
import com.google.inject.internal.cglib.core.EmitUtils;
import com.google.inject.internal.cglib.core.MethodInfo;
import com.google.inject.internal.cglib.core.TypeUtils;
import com.google.inject.internal.cglib.proxy.CallbackGenerator.Context;
import java.util.Iterator;
import java.util.List;

class NoOpGenerator implements CallbackGenerator {
	public static final NoOpGenerator INSTANCE = new NoOpGenerator();

	public void generate(ClassEmitter ce, Context context, List methods) {
		Iterator it = methods.iterator();

		while (it.hasNext()) {
			MethodInfo method = (MethodInfo) it.next();
			if (TypeUtils.isProtected(context.getOriginalModifiers(method))
					&& TypeUtils.isPublic(method.getModifiers())) {
				CodeEmitter e = EmitUtils.begin_method(ce, method);
				e.load_this();
				e.load_args();
				e.super_invoke();
				e.return_value();
				e.end_method();
			}
		}

	}

	public void generateStatic(CodeEmitter e, Context context, List methods) {
	}
}