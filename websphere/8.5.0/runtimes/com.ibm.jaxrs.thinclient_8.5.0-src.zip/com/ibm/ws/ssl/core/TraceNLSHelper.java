package com.ibm.ws.ssl.core;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;

public class TraceNLSHelper {
	private static final TraceComponent tc = Tr.register(TraceNLSHelper.class, (String) null,
			"com.ibm.ws.ssl.resources.ssl");
	private static final TraceNLS tnls = TraceNLS.getTraceNLS("com.ibm.ws.ssl.resources.ssl");
	private static TraceNLSHelper thisClass = null;

	public static TraceNLSHelper getInstance() {
		if (thisClass == null) {
			thisClass = new TraceNLSHelper();
		}

		return thisClass;
	}

	public String getString(String key, String defaultString) {
		return tnls != null ? tnls.getString(key, defaultString) : defaultString;
	}

	public String getFormattedMessage(String key, Object[] args, String defaultString) {
		return tnls != null ? tnls.getFormattedMessage(key, args, defaultString) : defaultString;
	}
}