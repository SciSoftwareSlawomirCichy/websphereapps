package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class TopicRegistrationListImpl extends EDataObjectImpl implements TopicRegistrationList {
	protected EList topicEmitter = null;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getTopicRegistrationList();
	}

	public TopicEmitter[] getTopicEmitterAsArray() {
		List var1 = this.getTopicEmitter();
		return (TopicEmitter[]) ((TopicEmitter[]) var1.toArray(new TopicEmitter[var1.size()]));
	}

	public List getTopicEmitter() {
		if (this.topicEmitter == null) {
			this.topicEmitter = new EObjectContainmentEList(TopicEmitter.class, this, 0);
		}

		return this.topicEmitter;
	}

	public TopicEmitter createTopicEmitter() {
		TopicEmitter var1 = ConfigmodelFactory.eINSTANCE.createTopicEmitter();
		this.getTopicEmitter().add(var1);
		return var1;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getTopicEmitter()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getTopicEmitter();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getTopicEmitter().clear();
				this.getTopicEmitter().addAll((Collection) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getTopicEmitter().clear();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.topicEmitter != null && !this.topicEmitter.isEmpty();
			default :
				return this.eDynamicIsSet(var1);
		}
	}
}