package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.Type;
import com.google.inject.internal.cglib.core.KeyFactory.1;
import com.google.inject.internal.cglib.core.KeyFactory.2;
import com.google.inject.internal.cglib.core.KeyFactory.Generator;

public abstract class KeyFactory {
	private static final Signature GET_NAME = TypeUtils.parseSignature("String getName()");
	private static final Signature GET_CLASS = TypeUtils.parseSignature("Class getClass()");
	private static final Signature HASH_CODE = TypeUtils.parseSignature("int hashCode()");
	private static final Signature EQUALS = TypeUtils.parseSignature("boolean equals(Object)");
	private static final Signature TO_STRING = TypeUtils.parseSignature("String toString()");
	private static final Signature APPEND_STRING = TypeUtils.parseSignature("StringBuffer append(String)");
	private static final Type KEY_FACTORY = TypeUtils.parseType("com.google.inject.internal.cglib.core.KeyFactory");
	private static final int[] PRIMES = new int[]{11, 73, 179, 331, 521, 787, 1213, 1823, 2609, 3691, 5189, 7247, 10037,
			13931, 19289, 26627, 36683, 50441, 69403, 95401, 131129, 180179, 247501, 340057, 467063, 641371, 880603,
			1209107, 1660097, 2279161, 3129011, 4295723, 5897291, 8095873, 11114263, 15257791, 20946017, 28754629,
			39474179, 54189869, 74391461, 102123817, 140194277, 192456917, 264202273, 362693231, 497900099, 683510293,
			938313161, 1288102441, 1768288259};
	public static final Customizer CLASS_BY_NAME = new 1();
	public static final Customizer OBJECT_BY_CLASS = new 2();

	public static KeyFactory create(Class keyInterface) {
		return create(keyInterface, (Customizer) null);
	}

	public static KeyFactory create(Class keyInterface, Customizer customizer) {
		return create(keyInterface.getClassLoader(), keyInterface, customizer);
	}

	public static KeyFactory create(ClassLoader loader, Class keyInterface, Customizer customizer) {
		Generator gen = new Generator();
		gen.setInterface(keyInterface);
		gen.setCustomizer(customizer);
		gen.setClassLoader(loader);
		return gen.create();
	}
}