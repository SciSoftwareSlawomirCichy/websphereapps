package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import commonj.sdo.DataObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SupportedEntityTypeConfigHelper implements ConfigConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = SupportedEntityTypeConfigHelper.class.getName();
	private static final Logger trcLogger;

	public String createIdMgrSupportedEntityType(String var1, Map var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "createIdMgrSupportedEntityType", "params: " + var2.toString());
		}

		List var5 = (List) var2.get("rdnProperties");
		String var6 = (String) var2.get("defaultParent");
		String var7 = (String) var2.get("name");
		ValidationHelper.validateStringInputInList("rdnProperties", CLASSNAME, "createIdMgrSupportedEntityType", var5,
				false);
		ConfigurationProviderType var8 = ConfigUtils.getConfigProvider(var1);
		List var9 = var8.getSupportedEntityTypes();
		SupportedEntityTypesType var10 = getSupportEntityTypeByName(var9, var7);
		if (var10 != null) {
			throw new WIMConfigurationException("SUPPORTED_ENTITY_TYPE_ALREADY_EXISTS",
					WIMMessageHelper.generateMsgParms(var7), Level.SEVERE, CLASSNAME, "createIdMgrSupportedEntityType");
		} else {
			var10 = var8.createSupportedEntityTypes();
			var10.setName(var7);
			var10.setDefaultParent(var6);
			List var11 = var10.getRdnProperties();

			for (int var12 = 0; var12 < var5.size(); ++var12) {
				var11.add((String) var5.get(var12));
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "createIdMgrSupportedEntityType");
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public String updateIdMgrSupportedEntityType(String var1, Map var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "updateIdMgrSupportedEntityType", "params: " + var2.toString());
		}

		String var5 = (String) var2.get("name");
		List var6 = (List) var2.get("rdnProperties");
		String var7 = (String) var2.get("defaultParent");
		ConfigurationProviderType var8 = ConfigUtils.getConfigProvider(var1);
		List var9 = var8.getSupportedEntityTypes();
		ValidationHelper.validateStringInputInList("rdnProperties", CLASSNAME, "updateIdMgrSupportedEntityType", var6,
				true);
		SupportedEntityTypesType var10 = getSupportEntityTypeByName(var9, var5);
		if (var10 == null) {
			throw new WIMConfigurationException("INVALID_SUPPORTED_ENTITY_TYPE",
					WIMMessageHelper.generateMsgParms(var5), Level.SEVERE, CLASSNAME, "updateIdMgrSupportedEntityType");
		} else {
			if (var7 != null) {
				var10.setDefaultParent(var7);
			}

			List var11 = null;
			if (var6 != null) {
				var11 = var10.getRdnProperties();
				ConfigUtils.addOrRemovePresentList("rdnProperties", var6, var11);
				var11 = var10.getRdnProperties();
			}

			String var12 = ConfigUtils.saveConfig(var1);
			if (var11 != null && var11.size() == 0) {
				var12 = "MUST_ADD_RDN_PROP_TO_SUPPORTED_ENTITY_TYPE";
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "updateIdMgrSupportedEntityType");
			}

			return var12;
		}
	}

	public String deleteIdMgrSupportedEntityType(String var1, Map var2) throws WIMException {
		String var3 = (String) var2.get("name");
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrSupportedEntityType", "params: " + var2.toString());
		}

		ConfigurationProviderType var6 = ConfigUtils.getConfigProvider(var1);
		List var7 = var6.getSupportedEntityTypes();
		SupportedEntityTypesType var8 = getSupportEntityTypeByName(var7, var3);
		if (var8 == null) {
			throw new WIMConfigurationException("INVALID_SUPPORTED_ENTITY_TYPE",
					WIMMessageHelper.generateMsgParms(var3), Level.SEVERE, CLASSNAME, "deleteIdMgrSupportedEntityType");
		} else {
			((DataObject) var8).delete();
			if (var5) {
				trcLogger.exiting(CLASSNAME, "deleteIdMgrSupportedEntityType");
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public List listIdMgrSupportedEntityTypes(String var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "listIdMgrSupportedEntityTypes");
		}

		ArrayList var4 = new ArrayList();
		ConfigurationProviderType var5 = ConfigUtils.getConfigProvider(var1);
		List var6 = var5.getSupportedEntityTypes();

		for (int var7 = 0; var7 < var6.size(); ++var7) {
			SupportedEntityTypesType var8 = (SupportedEntityTypesType) var6.get(var7);
			var4.add(var8.getName());
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "listIdMgrSupportedEntityTypes", "result: " + var4.toString());
		}

		return var4;
	}

	public Map getIdMgrSupportedEntityType(String var1, Map var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrSupportedEntityType", "params: " + var2);
		}

		HashMap var5 = new HashMap();
		String var6 = (String) var2.get("name");
		ConfigurationProviderType var7 = ConfigUtils.getConfigProvider(var1);
		List var8 = var7.getSupportedEntityTypes();
		SupportedEntityTypesType var9 = getSupportEntityTypeByName(var8, var6);
		if (var9 == null) {
			throw new WIMConfigurationException("INVALID_SUPPORTED_ENTITY_TYPE",
					WIMMessageHelper.generateMsgParms(var6), Level.SEVERE, CLASSNAME, "getIdMgrSupportedEntityType");
		} else {
			var5.put("name", var6);
			var5.put("defaultParent", var9.getDefaultParent());
			var5.put("rdnProperties", ConfigUtils.convertEList(var9.getRdnProperties()));
			if (var4) {
				trcLogger.exiting(CLASSNAME, "getIdMgrSupportedEntityType", "result: " + var5.toString());
			}

			return var5;
		}
	}

	public static SupportedEntityTypesType getSupportEntityTypeByName(List var0, String var1) {
		boolean var2 = false;
		SupportedEntityTypesType var3 = null;

		for (int var4 = 0; var4 < var0.size(); ++var4) {
			var3 = (SupportedEntityTypesType) var0.get(var4);
			if (var3.getName().equals(var1)) {
				var2 = true;
				break;
			}
		}

		if (!var2) {
			var3 = null;
		}

		return var3;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}