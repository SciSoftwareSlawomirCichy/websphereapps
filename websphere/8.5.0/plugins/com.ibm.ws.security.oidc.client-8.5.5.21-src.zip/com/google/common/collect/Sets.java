package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Sets.1;
import com.google.common.collect.Sets.2;
import com.google.common.collect.Sets.3;
import com.google.common.collect.Sets.4;
import com.google.common.collect.Sets.5;
import com.google.common.collect.Sets.CartesianSet;
import com.google.common.collect.Sets.FilteredNavigableSet;
import com.google.common.collect.Sets.FilteredSet;
import com.google.common.collect.Sets.FilteredSortedSet;
import com.google.common.collect.Sets.PowerSet;
import com.google.common.collect.Sets.SetView;
import com.google.common.collect.Sets.UnmodifiableNavigableSet;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
public final class Sets {
	@GwtCompatible(serializable = true)
	public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(E anElement, E... otherElements) {
		return ImmutableEnumSet.asImmutable(EnumSet.of(anElement, otherElements));
	}

	@GwtCompatible(serializable = true)
	public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(Iterable<E> elements) {
		if (elements instanceof ImmutableEnumSet) {
			return (ImmutableEnumSet) elements;
		} else if (elements instanceof Collection) {
			Collection<E> collection = (Collection) elements;
			return collection.isEmpty() ? ImmutableSet.of() : ImmutableEnumSet.asImmutable(EnumSet.copyOf(collection));
		} else {
			Iterator<E> itr = elements.iterator();
			if (itr.hasNext()) {
				EnumSet<E> enumSet = EnumSet.of((Enum) itr.next());
				Iterators.addAll(enumSet, itr);
				return ImmutableEnumSet.asImmutable(enumSet);
			} else {
				return ImmutableSet.of();
			}
		}
	}

	public static <E extends Enum<E>> EnumSet<E> newEnumSet(Iterable<E> iterable, Class<E> elementType) {
		EnumSet<E> set = EnumSet.noneOf(elementType);
		Iterables.addAll(set, iterable);
		return set;
	}

	public static <E> HashSet<E> newHashSet() {
		return new HashSet();
	}

	public static <E> HashSet<E> newHashSet(E... elements) {
		HashSet<E> set = newHashSetWithExpectedSize(elements.length);
		Collections.addAll(set, elements);
		return set;
	}

	public static <E> HashSet<E> newHashSet(Iterable<? extends E> elements) {
		return elements instanceof Collection
				? new HashSet(Collections2.cast(elements))
				: newHashSet(elements.iterator());
	}

	public static <E> HashSet<E> newHashSet(Iterator<? extends E> elements) {
		HashSet<E> set = newHashSet();
		Iterators.addAll(set, elements);
		return set;
	}

	public static <E> HashSet<E> newHashSetWithExpectedSize(int expectedSize) {
		return new HashSet(Maps.capacity(expectedSize));
	}

	public static <E> Set<E> newConcurrentHashSet() {
		return Collections.newSetFromMap(new ConcurrentHashMap());
	}

	public static <E> Set<E> newConcurrentHashSet(Iterable<? extends E> elements) {
		Set<E> set = newConcurrentHashSet();
		Iterables.addAll(set, elements);
		return set;
	}

	public static <E> LinkedHashSet<E> newLinkedHashSet() {
		return new LinkedHashSet();
	}

	public static <E> LinkedHashSet<E> newLinkedHashSet(Iterable<? extends E> elements) {
		if (elements instanceof Collection) {
			return new LinkedHashSet(Collections2.cast(elements));
		} else {
			LinkedHashSet<E> set = newLinkedHashSet();
			Iterables.addAll(set, elements);
			return set;
		}
	}

	public static <E> LinkedHashSet<E> newLinkedHashSetWithExpectedSize(int expectedSize) {
		return new LinkedHashSet(Maps.capacity(expectedSize));
	}

	public static <E extends Comparable> TreeSet<E> newTreeSet() {
		return new TreeSet();
	}

	public static <E extends Comparable> TreeSet<E> newTreeSet(Iterable<? extends E> elements) {
		TreeSet<E> set = newTreeSet();
		Iterables.addAll(set, elements);
		return set;
	}

	public static <E> TreeSet<E> newTreeSet(Comparator<? super E> comparator) {
		return new TreeSet((Comparator) Preconditions.checkNotNull(comparator));
	}

	public static <E> Set<E> newIdentityHashSet() {
		return Collections.newSetFromMap(Maps.newIdentityHashMap());
	}

	@GwtIncompatible
	public static <E> CopyOnWriteArraySet<E> newCopyOnWriteArraySet() {
		return new CopyOnWriteArraySet();
	}

	@GwtIncompatible
	public static <E> CopyOnWriteArraySet<E> newCopyOnWriteArraySet(Iterable<? extends E> elements) {
		Collection<? extends E> elementsCollection = elements instanceof Collection
				? Collections2.cast(elements)
				: Lists.newArrayList(elements);
		return new CopyOnWriteArraySet((Collection) elementsCollection);
	}

	public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection) {
		if (collection instanceof EnumSet) {
			return EnumSet.complementOf((EnumSet) collection);
		} else {
			Preconditions.checkArgument(!collection.isEmpty(),
					"collection is empty; use the other version of this method");
			Class<E> type = ((Enum) collection.iterator().next()).getDeclaringClass();
			return makeComplementByHand(collection, type);
		}
	}

	public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection, Class<E> type) {
		Preconditions.checkNotNull(collection);
		return collection instanceof EnumSet
				? EnumSet.complementOf((EnumSet) collection)
				: makeComplementByHand(collection, type);
	}

	private static <E extends Enum<E>> EnumSet<E> makeComplementByHand(Collection<E> collection, Class<E> type) {
		EnumSet<E> result = EnumSet.allOf(type);
		result.removeAll(collection);
		return result;
	}

	@Deprecated
	public static <E> Set<E> newSetFromMap(Map<E, Boolean> map) {
		return Collections.newSetFromMap(map);
	}

	public static <E> SetView<E> union(Set<? extends E> set1, Set<? extends E> set2) {
      Preconditions.checkNotNull(set1, "set1");
      Preconditions.checkNotNull(set2, "set2");
      return new 1(set1, set2);
   }

	public static <E> SetView<E> intersection(Set<E> set1, Set<?> set2) {
      Preconditions.checkNotNull(set1, "set1");
      Preconditions.checkNotNull(set2, "set2");
      return new 2(set1, set2);
   }

	public static <E> SetView<E> difference(Set<E> set1, Set<?> set2) {
      Preconditions.checkNotNull(set1, "set1");
      Preconditions.checkNotNull(set2, "set2");
      return new 3(set1, set2);
   }

	public static <E> SetView<E> symmetricDifference(Set<? extends E> set1, Set<? extends E> set2) {
      Preconditions.checkNotNull(set1, "set1");
      Preconditions.checkNotNull(set2, "set2");
      return new 4(set1, set2);
   }

	public static <E> Set<E> filter(Set<E> unfiltered, Predicate<? super E> predicate) {
		if (unfiltered instanceof SortedSet) {
			return filter((SortedSet) unfiltered, predicate);
		} else if (unfiltered instanceof FilteredSet) {
			FilteredSet<E> filtered = (FilteredSet) unfiltered;
			Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
			return new FilteredSet((Set) filtered.unfiltered, combinedPredicate);
		} else {
			return new FilteredSet((Set) Preconditions.checkNotNull(unfiltered),
					(Predicate) Preconditions.checkNotNull(predicate));
		}
	}

	public static <E> SortedSet<E> filter(SortedSet<E> unfiltered, Predicate<? super E> predicate) {
		if (unfiltered instanceof FilteredSet) {
			FilteredSet<E> filtered = (FilteredSet) unfiltered;
			Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
			return new FilteredSortedSet((SortedSet) filtered.unfiltered, combinedPredicate);
		} else {
			return new FilteredSortedSet((SortedSet) Preconditions.checkNotNull(unfiltered),
					(Predicate) Preconditions.checkNotNull(predicate));
		}
	}

	@GwtIncompatible
	public static <E> NavigableSet<E> filter(NavigableSet<E> unfiltered, Predicate<? super E> predicate) {
		if (unfiltered instanceof FilteredSet) {
			FilteredSet<E> filtered = (FilteredSet) unfiltered;
			Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
			return new FilteredNavigableSet((NavigableSet) filtered.unfiltered, combinedPredicate);
		} else {
			return new FilteredNavigableSet((NavigableSet) Preconditions.checkNotNull(unfiltered),
					(Predicate) Preconditions.checkNotNull(predicate));
		}
	}

	public static <B> Set<List<B>> cartesianProduct(List<? extends Set<? extends B>> sets) {
		return CartesianSet.create(sets);
	}

	@SafeVarargs
	public static <B> Set<List<B>> cartesianProduct(Set... sets) {
		return cartesianProduct(Arrays.asList(sets));
	}

	@GwtCompatible(serializable = false)
	public static <E> Set<Set<E>> powerSet(Set<E> set) {
		return new PowerSet(set);
	}

	@Beta
   public static <E> Set<Set<E>> combinations(Set<E> set, int size) {
      ImmutableMap<E, Integer> index = Maps.indexMap(set);
      CollectPreconditions.checkNonnegative(size, "size");
      Preconditions.checkArgument(size <= index.size(), "size (%s) must be <= set.size() (%s)", size, index.size());
      if (size == 0) {
         return ImmutableSet.of(ImmutableSet.of());
      } else {
         return (Set)(size == index.size() ? ImmutableSet.of(index.keySet()) : new 5(size, index));
      }
   }

	static int hashCodeImpl(Set<?> s) {
		int hashCode = 0;

		for (Iterator var2 = s.iterator(); var2.hasNext(); hashCode = ~(~hashCode)) {
			Object o = var2.next();
			hashCode += o != null ? o.hashCode() : 0;
		}

		return hashCode;
	}

	static boolean equalsImpl(Set<?> s, @NullableDecl Object object) {
		if (s == object) {
			return true;
		} else if (object instanceof Set) {
			Set o = (Set) object;

			try {
				return s.size() == o.size() && s.containsAll(o);
			} catch (ClassCastException | NullPointerException var4) {
				return false;
			}
		} else {
			return false;
		}
	}

	public static <E> NavigableSet<E> unmodifiableNavigableSet(NavigableSet<E> set) {
		return (NavigableSet) (!(set instanceof ImmutableCollection) && !(set instanceof UnmodifiableNavigableSet)
				? new UnmodifiableNavigableSet(set)
				: set);
	}

	@GwtIncompatible
	public static <E> NavigableSet<E> synchronizedNavigableSet(NavigableSet<E> navigableSet) {
		return Synchronized.navigableSet(navigableSet);
	}

	static boolean removeAllImpl(Set<?> set, Iterator<?> iterator) {
		boolean changed;
		for (changed = false; iterator.hasNext(); changed |= set.remove(iterator.next())) {
			;
		}

		return changed;
	}

	static boolean removeAllImpl(Set<?> set, Collection<?> collection) {
		Preconditions.checkNotNull(collection);
		if (collection instanceof Multiset) {
			collection = ((Multiset) collection).elementSet();
		}

		return collection instanceof Set && ((Collection) collection).size() > set.size()
				? Iterators.removeAll(set.iterator(), (Collection) collection)
				: removeAllImpl(set, ((Collection) collection).iterator());
	}

	@Beta
	@GwtIncompatible
	public static <K extends Comparable<? super K>> NavigableSet<K> subSet(NavigableSet<K> set, Range<K> range) {
		if (set.comparator() != null && set.comparator() != Ordering.natural() && range.hasLowerBound()
				&& range.hasUpperBound()) {
			Preconditions.checkArgument(set.comparator().compare(range.lowerEndpoint(), range.upperEndpoint()) <= 0,
					"set is using a custom comparator which is inconsistent with the natural ordering.");
		}

		if (range.hasLowerBound() && range.hasUpperBound()) {
			return set.subSet(range.lowerEndpoint(), range.lowerBoundType() == BoundType.CLOSED, range.upperEndpoint(),
					range.upperBoundType() == BoundType.CLOSED);
		} else if (range.hasLowerBound()) {
			return set.tailSet(range.lowerEndpoint(), range.lowerBoundType() == BoundType.CLOSED);
		} else {
			return range.hasUpperBound()
					? set.headSet(range.upperEndpoint(), range.upperBoundType() == BoundType.CLOSED)
					: (NavigableSet) Preconditions.checkNotNull(set);
		}
	}
}