package com.ibm.json.java;

import java.io.BufferedReader;
import java.io.CharArrayReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PushbackReader;
import java.io.Reader;
import java.io.StringReader;

public class JSON {
	public static JSONArtifact parse(Reader var0, boolean var1) throws IOException, NullPointerException {
		if (var0 != null) {
			PushbackReader var2 = null;
			boolean var3 = false;
			Class var4 = var0.getClass();
			if (!StringReader.class.isAssignableFrom(var4) && !CharArrayReader.class.isAssignableFrom(var4)
					&& !PushbackReader.class.isAssignableFrom(var4) && !BufferedReader.class.isAssignableFrom(var4)) {
				var3 = true;
			}

			if (PushbackReader.class.isAssignableFrom(var4)) {
				var2 = (PushbackReader) var0;
			} else {
				var2 = new PushbackReader(var0);
			}

			Object var5 = var2;
			int var6 = var2.read();

			while (var6 != -1) {
				switch (var6) {
					case 8 :
					case 9 :
					case 10 :
					case 12 :
					case 13 :
					case 32 :
						var6 = var2.read();
						break;
					case 91 :
						var2.unread(var6);
						if (var3) {
							var5 = new BufferedReader(var2);
						}

						return JSONArray.parse((Reader) var5);
					case 123 :
						var2.unread(var6);
						if (var3) {
							var5 = new BufferedReader(var2);
						}

						if (var1) {
							return OrderedJSONObject.parse((Reader) var5);
						}

						return JSONObject.parse((Reader) var5);
					default :
						throw new IOException("Unexpected character: [" + (char) var6
								+ "] while scanning JSON String for JSON type.  Invalid JSON.");
				}
			}

			throw new IOException("Encountered end of stream before JSON data was read.  Invalid JSON");
		} else {
			throw new NullPointerException("reader cannot be null.");
		}
	}

	public static JSONArtifact parse(Reader var0) throws IOException, NullPointerException {
		return parse(var0, false);
	}

	public static JSONArtifact parse(InputStream var0, boolean var1) throws IOException, NullPointerException {
		if (var0 != null) {
			BufferedReader var2 = null;

			try {
				var2 = new BufferedReader(new InputStreamReader(var0, "UTF-8"));
			} catch (Exception var5) {
				IOException var4 = new IOException("Could not construct UTF-8 character reader for the InputStream");
				var4.initCause(var5);
				throw var4;
			}

			return parse((Reader) var2, var1);
		} else {
			throw new NullPointerException("is cannot be null");
		}
	}

	public static JSONArtifact parse(InputStream var0) throws IOException, NullPointerException {
		return parse(var0, false);
	}

	public static JSONArtifact parse(String var0, boolean var1) throws IOException, NullPointerException {
		if (var0 != null) {
			return parse((Reader) (new StringReader(var0)), var1);
		} else {
			throw new NullPointerException("str cannot be null");
		}
	}

	public static JSONArtifact parse(String var0) throws IOException, NullPointerException {
		return parse(var0, false);
	}
}