package com.ibm.ws.wim.lookaside;

import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.InvalidIdentifierException;
import com.ibm.websphere.wim.exception.InvalidPropertyDefinitionException;
import com.ibm.websphere.wim.exception.MissingMandatoryPropertyException;
import com.ibm.websphere.wim.exception.MissingSearchControlException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.DataAccessObject;
import com.ibm.ws.wim.dao.schema.DBDataType;
import com.ibm.ws.wim.dao.schema.DBRepositoryProperty;
import com.ibm.ws.wim.util.ControlsHelper;
import com.ibm.ws.wim.xpath.ParseException;
import com.ibm.ws.wim.xpath.TokenMgrError;
import com.ibm.ws.wim.xpath.WIMXPathInterpreter;
import com.ibm.ws.wim.xpath.lookaside.util.LAXPathTranslateHelper;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;
import com.ibm.ws.wim.xpath.util.MetadataMapper;
import commonj.sdo.ChangeSummary;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.ChangeSummary.Setting;
import java.io.StringReader;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LookasideAdapter implements LookasideRepository, DynamicConfigService {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final String PROPKEY_ROOT = "Root";
	private static final String PROPKEY_ANCESTORS = "Ancestors";
	private static final String PROPKEY_DESCENDENTS = "Descendents";
	private static final String PROPKEY_GROUPMEMBERS = "GroupMembers";
	private static final String PROPKEY_GROUPMEMBERSHIP = "GroupMembership";
	private boolean isDbSharedAcrossMultipleServers = false;
	SchemaManager schemaMgr = null;
	String reposId = "LA";
	int entityRetrievalLimit = 200;
	DataAccessObject dao = null;
	LAPropertyCache propertyManager = null;
	private boolean isUseTriggerForIdInLARepo = false;

	public DataObject create(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI create(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var3 = this.schemaMgr.createRootDataObject();
		List var4 = var1.getList("entities");
		DataObject var5 = (DataObject) var4.get(0);
		String var6 = var5.getDataObject("identifier").getString("externalId");
		String var7 = this.schemaMgr.getQualifiedTypeName(var5.getType());
		String var8 = var5.getDataObject("identifier").getString("repositoryId");
		if (var6 != null && var7 != null && var8 != null) {
			LAEntity var9 = new LAEntity();
			var9.setEntityType(var7);
			var9.setExternalId(var6);
			var9.setRepositoryId(var8);
			long var10 = this.dao.createLAEntity(var9);
			long var12 = System.currentTimeMillis();
			Timestamp var14 = new Timestamp(var12);
			var5.set("createTimestamp", var14);
			var5.set("modifyTimestamp", var14);
			this.createProperties(var10, var5);
			DataObject var15 = var3.createDataObject("entities", this.schemaMgr.getTypeNsURI(var7),
					this.schemaMgr.getTypeName(var7));
			DataObject var16 = var15.createDataObject("identifier");
			var16.setString("externalId", var6);
			var16.setString("repositoryId", var8);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI create(DataObject)", WIMTraceHelper.printDataObject(var3));
			}

			return var3;
		} else {
			throw new InvalidIdentifierException("INVALID_IDENTIFIER", CLASSNAME, "create(DataObject)");
		}
	}

	private void createProperties(long var1, DataObject var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createProperties(long mbrId, DataObject entity)");
		}

		String var5 = this.schemaMgr.getQualifiedTypeName(var3.getType());
		Hashtable[] var6 = new Hashtable[7];
		Hashtable var7 = null;
		Object var8 = this.propertyManager.getMandatoryAttributes(var5);
		if (var8 == null) {
			var8 = new HashSet();
		}

		Iterator var9 = ((Set) var8).iterator();

		while (var9.hasNext()) {
			String var10 = (String) var9.next();
			Property var11 = this.schemaMgr.getProperty(var5, var10);
			if (!var3.isSet(var11)) {
				Object[] var22 = new Object[]{var10};
				throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY", var22, CLASSNAME,
						"createProperties(long mbrId, DataObject entity)");
			}

			DBRepositoryProperty var12 = this.propertyManager.getPropertyDefinition(var10);
			Integer var13 = var12.getPropId();
			String var14 = var12.getDataType();
			short var15 = DAOHelper.getDataTypeId(var14);
			if (this.propertyManager.isCompositeProperty(var10)) {
				if (var7 == null) {
					var7 = new Hashtable();
				}

				Object[] var16;
				if (this.propertyManager.isMultivaluedProperty(var10)) {
					var16 = new Object[]{var10, var3.getList(var11)};
					var7.put(var13, var16);
				} else {
					var16 = new Object[]{var10, var3.get(var11)};
					var7.put(var13, var16);
				}
			} else {
				if (var6[var15] == null) {
					var6[var15] = new Hashtable();
				}

				if (this.propertyManager.isMultivaluedProperty(var10)) {
					var6[var15].put(var13, var3.getList(var11));
				} else {
					var6[var15].put(var13, var3.get(var11));
				}
			}
		}

		Object var20 = this.propertyManager.getSupportedAttributes(var5);
		if (var20 == null) {
			var20 = new HashSet();
		}

		Iterator var21 = ((Set) var20).iterator();

		while (var21.hasNext()) {
			String var23 = (String) var21.next();
			Property var24 = this.schemaMgr.getProperty(var5, var23);

			try {
				if (var3.isSet(var24) && !((Set) var8).contains(var24)) {
					DBRepositoryProperty var25 = this.propertyManager.getPropertyDefinition(var23);
					Integer var26 = var25.getPropId();
					String var27 = var25.getDataType();
					short var17 = DAOHelper.getDataTypeId(var27);
					if (this.propertyManager.isCompositeProperty(var23)) {
						if (var7 == null) {
							var7 = new Hashtable();
						}

						Object[] var18;
						if (this.propertyManager.isMultivaluedProperty(var23)) {
							var18 = new Object[]{var23, var3.getList(var24)};
							var7.put(var26, var18);
						} else {
							var18 = new Object[]{var23, var3.get(var24)};
							var7.put(var26, var18);
						}
					} else {
						if (var6[var17] == null) {
							var6[var17] = new Hashtable();
						}

						if (this.propertyManager.isMultivaluedProperty(var23)) {
							var6[var17].put(var26, var3.getList(var24));
						} else {
							var6[var17].put(var26, var3.get(var24));
						}
					}
				}
			} catch (Exception var19) {
				throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var19.getMessage()),
						CLASSNAME, "createProperties(long mbrId, DataObject entity)", var19);
			}
		}

		if (!this.isDbSharedAcrossMultipleServers) {
			this.dao.createProperties((short) 1, var1, var6, (Long) null,
					this.propertyManager.getMultiValuePropertyIds(),
					var3.getDataObject("identifier").getString("repositoryId"));
		} else {
			this.dao.createProperties1((short) 1, var1, var6, (Long) null,
					this.propertyManager.getMultiValuePropertyIds(),
					var3.getDataObject("identifier").getString("repositoryId"));
		}

		if (var7 != null && var7.size() != 0) {
			this.createCompositeProperties(var1, var7, this.propertyManager.getMultiValuePropertyIds());
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createProperties(long mbrId, DataObject entity)");
		}

	}

	private void createCompositeProperties(long var1, Hashtable var3, Set var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createCompositeProperties(short schema, long mbrId, Hashtable compAttrs, Set multiValProps)");
		}

		Set var6 = var3.keySet();

		Integer var8;
		String var10;
		Object var11;
		for (Iterator var7 = var6.iterator(); var7.hasNext(); this.createOneCompositeProperty(var8, var10, var1,
				(List) var11, (Long) null)) {
			var8 = (Integer) var7.next();
			Object[] var9 = (Object[]) ((Object[]) var3.get(var8));
			var10 = (String) var9[0];
			var11 = null;
			if (var4.contains(var8)) {
				var11 = (List) var9[1];
			} else {
				var11 = new ArrayList();
				((List) var11).add(var9[1]);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"createCompositeProperties(short schema, long mbrId, Hashtable compAttrs, Set multiValProps)");
		}

	}

	private void createOneCompositeProperty(Integer var1, String var2, long var3, List var5, Long var6)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createOneCompositeProperty");
		}

		for (int var8 = 0; var8 < var5.size(); ++var8) {
			Hashtable[] var9 = new Hashtable[7];
			Long var10 = this.dao.createCompositePropValue((short) 1, var1, var3, (Long) null, (String) null);
			DataObject var11 = (DataObject) var5.get(var8);
			Set var12 = (Set) this.propertyManager.getCompositeProperties().get(var2);
			Set var13 = this.propertyManager.getRequiredComponentProperties(var2);
			Iterator var14 = var12.iterator();

			while (var14.hasNext()) {
				String var15 = (String) var14.next();
				String var16 = DAOHelper.resumeComponentName(var15, var2);
				if (var11.isSet(var16)) {
					DBRepositoryProperty var17 = this.propertyManager.getPropertyDefinition(var15);
					Integer var18 = var17.getPropId();
					String var19 = var17.getDataType();
					short var20 = DAOHelper.getDataTypeId(var19);
					if (this.propertyManager.isCompositeProperty(var15)) {
						Object var21 = null;
						if (this.propertyManager.isMultivaluedProperty(var15)) {
							var21 = var11.getList(var16);
						} else {
							var21 = new ArrayList();
							((List) var21).add(var11.get(var16));
						}

						this.createOneCompositeProperty(var18, var15, var3, (List) var21, var10);
					} else {
						if (var9[var20] == null) {
							var9[var20] = new Hashtable();
						}

						if (this.propertyManager.isMultivaluedProperty(var15)) {
							var9[var20].put(var18, var11.getList(var16));
						} else {
							var9[var20].put(var18, var11.get(var16));
						}
					}
				} else if (var13.contains(var15)) {
					Object[] var22 = new Object[]{var16};
					throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY", var22, CLASSNAME,
							"createOneCompositeProperty");
				}
			}

			if (!this.isDbSharedAcrossMultipleServers) {
				this.dao.createProperties((short) 1, var3, var9, var10, this.propertyManager.getMultiValuePropertyIds(),
						this.reposId);
			} else {
				this.dao.createProperties1((short) 1, var3, var9, var10,
						this.propertyManager.getMultiValuePropertyIds(), this.reposId);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "createOneCompositeProperty");
		}

	}

	public DataObject delete(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI delete(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var3 = this.schemaMgr.createRootDataObject();
		List var4 = var1.getList("entities");
		if (var4 != null) {
			for (int var5 = 0; var5 < var4.size(); ++var5) {
				DataObject var6 = (DataObject) var4.get(var5);
				String var7 = var6.getDataObject("identifier").getString("externalId");
				String var8 = var6.getDataObject("identifier").getString("repositoryId");
				if (var7 != null && var8 != null) {
					this.dao.deleteLAEntity(var7, var8);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI delete(DataObject)", WIMTraceHelper.printDataObject(var3));
		}

		return var3;
	}

	private String[] getPropertiesForControl(DataObject var1) {
		ArrayList var2 = null;
		List var3 = null;
		if (var1 != null) {
			var2 = new ArrayList(var1.getList("properties"));
			var3 = var1.getList("contextProperties");

			for (int var4 = 0; var4 < var3.size(); ++var4) {
				DataObject var5 = (DataObject) var3.get(var4);
				var2.add(var5.getString("value"));
			}
		} else {
			var2 = new ArrayList();
		}

		return (String[]) ((String[]) var2.toArray(new String[0]));
	}

	private Map getPropertyNamesMap(DataObject var1) {
		Map var2 = ControlsHelper.getControlMap(var1);
		DataObject var3 = (DataObject) var2.get("PropertyControl");
		DataObject var4 = (DataObject) var2.get("AncestorControl");
		DataObject var5 = (DataObject) var2.get("DescendantControl");
		DataObject var6 = (DataObject) var2.get("GroupMemberControl");
		DataObject var7 = (DataObject) var2.get("GroupMembershipControl");
		String[] var8 = this.getPropertiesForControl(var3);
		String[] var9 = this.getPropertiesForControl(var4);
		String[] var10 = this.getPropertiesForControl(var5);
		String[] var11 = this.getPropertiesForControl(var6);
		String[] var12 = this.getPropertiesForControl(var7);
		Hashtable var13 = new Hashtable();
		var13.put("Root", var8);
		var13.put("Ancestors", var9);
		var13.put("Descendents", var10);
		var13.put("GroupMembers", var11);
		var13.put("GroupMembership", var12);
		return var13;
	}

	private void getEntityProperties(DataObject var1, String[] var2) throws WIMException {
		trcLogger.entering(CLASSNAME, "getEntityProperties(DataObject entity, String propNames[])");
		String var4 = this.schemaMgr.getQualifiedTypeName(var1.getType());
		String var5 = var1.getDataObject("identifier").getString("externalId");
		String var6 = var1.getDataObject("identifier").getString("repositoryId");
		LAEntity var7 = this.dao.findLAEntityByExtIdReposId(var5, var6);
		if (var7 != null) {
			String var8 = var7.getEntityType();
			long var9 = var7.getEntityId();
			var1.getDataObject("identifier").setString("repositoryId", var7.getRepositoryId().trim());
			if (var2.length > 0) {
				this.getProperties(var1, var9, var2);
			}
		} else {
			trcLogger.logp(Level.FINER, CLASSNAME, "getEntityProperties(DataObject entity, String propNames[])",
					"[" + var5 + "/" + var6 + "] not found in lookaside repository");
		}

		trcLogger.exiting(CLASSNAME, "getEntityProperties(DataObject entity, String propNames[])");
	}

	private void getRecursively(DataObject var1, String var2, Map var3, boolean var4) throws WIMException {
		trcLogger.entering(CLASSNAME,
				"getRecursively(DataObject entity, String propKey, Map propNamesMap, boolean getAll)");
		this.getEntityProperties(var1, (String[]) ((String[]) var3.get(var2)));
		if (var4 || var2.equals("Ancestors")) {
			DataObject var6 = (DataObject) var1.get("parent");
			if (var6 != null) {
				this.getRecursively(var6, "Ancestors", var3, false);
			}
		}

		int var7;
		DataObject var8;
		List var10;
		if (var4 || var2.equals("Descendents")) {
			var10 = var1.getList("children");

			for (var7 = 0; var7 < var10.size(); ++var7) {
				var8 = (DataObject) var10.get(var7);
				this.getRecursively(var8, "Descendents", var3, false);
			}
		}

		if (var4 || var2.equals("GroupMembership")) {
			var10 = var1.getList("groups");

			for (var7 = 0; var7 < var10.size(); ++var7) {
				var8 = (DataObject) var10.get(var7);
				this.getRecursively(var8, "GroupMembership", var3, false);
			}
		}

		if (var4 || var2.equals("GroupMembers")) {
			String var11 = this.schemaMgr.getQualifiedTypeName(var1.getType());
			if (this.schemaMgr.isSuperType("Group", var11)) {
				List var12 = var1.getList("members");

				for (int var13 = 0; var13 < var12.size(); ++var13) {
					DataObject var9 = (DataObject) var12.get(var13);
					this.getRecursively(var9, "GroupMembers", var3, false);
				}
			}
		}

		trcLogger.exiting(CLASSNAME,
				"getRecursively(DataObject entity, String propKey, Map propNamesMap, boolean getAll)");
	}

	public DataObject get(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI get(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		Map var3 = this.getPropertyNamesMap(var1);
		List var4 = var1.getList("entities");

		for (int var5 = 0; var5 < var4.size(); ++var5) {
			DataObject var6 = (DataObject) var4.get(var5);
			String var7 = var6.getString("changeType");
			if (!"delete".equals(var7)) {
				this.getRecursively(var6, "Root", var3, true);
			}
		}

		ControlsHelper.removeControls(var1);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI get(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		return var1;
	}

	public void initialize(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI initialize (DataObject laConfig)");
		}

		if (var1 == null) {
			throw new WIMSystemException("LOAD_DATAGRAPH_FAILED",
					WIMMessageHelper.generateMsgParms("lookaside repository configuration is not defined."), CLASSNAME,
					"initialize (DataObject laConfig)");
		} else {
			this.schemaMgr = SchemaManager.singleton();
			String var3 = var1.getString("databaseType");
			String var4 = var1.getString("dataSourceName");
			String var5 = var1.getString("dbURL");
			String var6 = var1.getString("dbAdminId");
			String var7 = var1.getString("dbAdminPassword");
			String var8 = var1.getString("JDBCDriverClass");
			String var9 = var1.getString("dbSchema");
			boolean var10 = false;
			if (var1.isSet("entityRetrievalLimit")) {
				this.entityRetrievalLimit = var1.getInt("entityRetrievalLimit");
			}

			this.dao = DAOHelper.getNewDAOClass(var3, var4, var5, var9, var6, var7, var8);
			this.propertyManager = LAPropertyCache.singleton(this.dao);
			String var11 = System.getProperty("com.ibm.ws.wim.registry.DbSharedAcrossMultipleServers");
			if (var11 != null) {
				this.isDbSharedAcrossMultipleServers = Boolean.parseBoolean(var11);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.log(Level.FINER, "com.ibm.ws.wim.registry.DbSharedAcrossMultipleServers="
							+ this.isDbSharedAcrossMultipleServers);
				}
			}

			String var12 = System.getProperty("com.ibm.ws.wim.registry.useTriggerForIdInLARepo");
			if (var12 != null) {
				this.isUseTriggerForIdInLARepo = Boolean.parseBoolean(var12);
				this.dao.setUseTriggerForIdInLARepo(this.isUseTriggerForIdInLARepo);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.log(Level.FINER,
							"com.ibm.ws.wim.registry.useTriggerForIdInLARepo=" + this.isUseTriggerForIdInLARepo);
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"WIM_SPI initialize (DataObject laConfig) : isDbSharedAcrossMultipleServers = "
								+ this.isDbSharedAcrossMultipleServers + " : isUseTriggerForIdInLARepo = "
								+ this.isUseTriggerForIdInLARepo);
			}

		}
	}

	public DataObject search(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI search(DataObject inRoot)", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var3 = null;
		String var4 = null;
		Map var5 = ControlsHelper.getControlMap(var1);
		DataObject var6 = (DataObject) var5.get("SearchControl");
		if (var6 == null) {
			throw new MissingSearchControlException("MISSING_SEARCH_CONTROL", CLASSNAME, "search(DataObject inRoot)");
		} else {
			List var7 = var6.getList("properties");
			var4 = var6.getString("expression");
			if (var4 != null && var4.length() != 0) {
				List var8 = var6.getList("searchBases");
				boolean var9 = var6.getBoolean("returnSubType");

				try {
					WIMXPathInterpreter var10 = new WIMXPathInterpreter(new StringReader(var4));
					XPathNode var11 = var10.parse((MetadataMapper) null);
					List var12 = var10.getEntityTypes();
					HashSet var13 = new HashSet();
					if (var9) {
						for (int var14 = 0; var14 < var12.size(); ++var14) {
							Set var15 = this.schemaMgr.getSubEntityTypes((String) var12.get(var14));
							if (var15 != null) {
								var13.addAll(var15);
							}

							var13.add((String) var12.get(var14));
						}
					} else {
						var13.addAll(var12);
					}

					if (var7.size() == 1) {
						String var28 = (String) var7.get(0);
						if (var28.equals("*")) {
							var7.clear();
							Iterator var30 = var13.iterator();

							while (var30.hasNext()) {
								Set var16 = this.propertyManager.getSupportedAttributes((String) var30.next());
								var7.addAll(var16);
							}
						}
					}

					ArrayList var29 = new ArrayList();
					String var31 = this.buildSearchConditionWhereClause(var13, var11, var29, var8);
					trcLogger.logp(Level.FINER, CLASSNAME, "search(DataObject inRoot)",
							"Search Condition WHERE: " + WIMTraceHelper.printObjectArray(new Object[]{var31}));
					var3 = this.schemaMgr.createRootDataObject();
					ArrayList var32 = new ArrayList();

					for (int var17 = 0; var17 < var7.size(); ++var17) {
						String var18 = (String) var7.get(var17);
						DBRepositoryProperty var19 = this.propertyManager.getPropertyDefinition(var18);
						if (var19 != null) {
							var32.add(var19);
						}
					}

					boolean var33 = false;
					if (var32.size() == 0) {
						var33 = true;
					}

					StringBuffer var34 = new StringBuffer();
					StringBuffer var35 = new StringBuffer(256);
					boolean[] var20 = new boolean[DAOHelper.types.length];
					StringBuffer var21 = new StringBuffer(256);
					int var22 = this.searchString(var34, var31, var29, var32, var3, var20, var35, var21);
					trcLogger.logp(Level.FINER, CLASSNAME, "search(DataObject inRoot)",
							"Search SQL " + WIMTraceHelper.printObjectArray(new Object[]{var34.toString()}));
					Map var23 = this.dao.searchLA(var34.toString(), var29, var33, var3, this.reposId, var22);
					List var24 = var3.getList("entities");
					if ((var35 != null || var21 != null) && var24.size() > 0) {
						String var25 = DAOHelper.buildEntityIdSQL(var23);
						if (var35.length() > 0) {
							this.dao.getCompositeProperties(var23, var35.toString(), var20, var25, false);
						}

						if (var21.length() > 0) {
							this.dao.getObjectProperties(var23, var21.toString(), var25, false);
						}
					}
				} catch (ParseException var26) {
					throw new SearchControlException("INVALID_SEARCH_EXPRESSION",
							WIMMessageHelper.generateMsgParms(var4), CLASSNAME, "search(DataObject inRoot)", var26);
				} catch (TokenMgrError var27) {
					throw new SearchControlException("INVALID_SEARCH_EXPRESSION",
							WIMMessageHelper.generateMsgParms(var4), CLASSNAME, "search(DataObject inRoot)", var27);
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "WIM_SPI search(DataObject inRoot)",
							WIMTraceHelper.printDataObject(var3));
				}

				return var3;
			} else {
				throw new SearchControlException("MISSING_SEARCH_EXPRESSION", CLASSNAME, "search(DataObject inRoot)");
			}
		}
	}

	private String buildSearchConditionWhereClause(Set var1, XPathNode var2, List var3, List var4)
			throws WIMApplicationException {
		StringBuffer var6 = null;
		StringBuffer var7 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "String buildSearchConditionWhereClause(Set, XPathNode, List, List)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3, var4}));
		}

		ArrayList var8 = new ArrayList();
		var8.addAll(var1);
		LAXPathTranslateHelper var9 = new LAXPathTranslateHelper(var8, var2, var3, this.propertyManager, this.dao);
		StringBuffer var10 = new StringBuffer();
		var9.genSearchString(var10, var2);
		var6 = var9.getWhereClause();
		var7 = var9.getFromClause();
		StringBuffer var11 = new StringBuffer(var7.length() + var6.length() + 128);
		var11.append(this.dao.getQuerySet().SearchLAEntitySubSelect);
		var11.append(var7);
		var11.append(var6);
		var11.append(this.dao.getQuerySet().AND);
		var11.append(this.dao.getQuerySet().LEFT_BRACKET);
		Iterator var12 = var1.iterator();
		String var13;
		if (var12.hasNext()) {
			var11.append(this.dao.getQuerySet().searchLAEntityTypeCondition);
			var13 = (String) var12.next();
			var11.append(var13);
			var11.append(this.dao.getQuerySet().SINGLE_QUOTE);
		}

		while (var12.hasNext()) {
			var11.append(this.dao.getQuerySet().OR);
			var11.append(this.dao.getQuerySet().searchLAEntityTypeCondition);
			var13 = (String) var12.next();
			var11.append(var13);
			var11.append(this.dao.getQuerySet().SINGLE_QUOTE);
		}

		var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
		var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
		var13 = var11.toString();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "String buildSearchConditionWhereClause(Set, XPathNode, List, List)",
					WIMTraceHelper.printObjectArray(new Object[]{var13, var3}));
		}

		return var13;
	}

	public DataObject update(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI update(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		Map var3 = ControlsHelper.getControlMap(var1);
		DataObject var4 = (DataObject) var3.get("CacheControl");
		if (var4 != null) {
			return null;
		} else {
			ArrayList var5 = new ArrayList();
			DataObject var6 = this.schemaMgr.createRootDataObject();

			try {
				ChangeSummary var7 = var1.getDataGraph().getChangeSummary();
				List var16 = var7.getChangedDataObjects();
				Iterator var9 = var16.iterator();

				DataObject var10;
				label61 : while (var9.hasNext()) {
					var10 = (DataObject) var9.next();
					Iterator var11 = var7.getOldValues(var10).iterator();

					while (true) {
						Property var13;
						Object var14;
						do {
							if (!var11.hasNext()) {
								continue label61;
							}

							Setting var12 = (Setting) var11.next();
							var13 = var12.getProperty();
							var14 = var10.get(var13);
							if (var14 instanceof List && ((List) var14).size() == 0) {
								var14 = null;
							}
						} while (var14 != null && var10.isSet(var13));

						if (!var5.contains(var13)) {
							var5.add(var13);
						}
					}
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "update(DataObject)", "deletedAttributes=" + var5);
				}

				List var17 = var1.getList("entities");
				var10 = (DataObject) var17.get(0);
				LAEntity var18 = null;
				String var19 = var10.getDataObject("identifier").getString("externalId");
				String var20 = var10.getDataObject("identifier").getString("repositoryId");
				if (var19 != null && var20 != null) {
					var18 = this.dao.findLAEntityByExtIdReposId(var19, var20);
				}

				if (var18 != null) {
					var10.getDataObject("identifier").set("externalId", var19);
					var10.getDataObject("identifier").set("repositoryId", var20);
					this.updateProperties(var18.getEntityId(), var10, var5);
					var6.getList("entities").add(var10);
				} else {
					var6 = this.create(var1);
				}
			} catch (Exception var15) {
				WIMApplicationException var8 = new WIMApplicationException(
						"Failed to update entity: " + var15.toString(), var15);
				throw var8;
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI update(DataObject)", WIMTraceHelper.printDataObject(var1));
			}

			return var6;
		}
	}

	private void replaceCompositeProperties(long var1, Hashtable var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "replaceCompositeProperties(long entId, Hashtable compProps)");
		}

		this.dao.deleteCompositeProperties((short) 0, var1, var3);
		this.createCompositeProperties(var1, var3, this.propertyManager.getMultiValuePropertyIds());
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "replaceCompositeProperties(long entId, Hashtable compProps)");
		}

	}

	public DataObject createSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI createSchema(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var3 = this.schemaMgr.createRootDataObject();
		DataObject var4 = var1.getDataObject("schema");
		if (var4 != null) {
			List var5 = var4.getList("entitySchema");
			String var10;
			if (var5 != null && var5.size() > 0) {
				for (int var6 = 0; var6 < var5.size(); ++var6) {
					DataObject var7 = (DataObject) var5.get(var6);
					String var8 = var7.getString("nsURI");
					String var9 = var7.getString("entityName");
					if (!var8.equals("http://www.ibm.com/websphere/wim")) {
						var9 = this.schemaMgr.getQualifiedTypeName(var8, var9);
					}

					var10 = var7.getString("parentEntityName");
					this.dao.createNewPropertyEntityRelationInLA(var9, var10, this.propertyManager);
					this.propertyManager.updatePropertyEntityRelationCache(var9, var10);
				}
			}

			List var22 = var4.getList("extensionPropertySchema");
			if (var22 != null && var22.size() > 0) {
				for (int var23 = 0; var23 < var22.size(); ++var23) {
					DataObject var24 = (DataObject) var22.get(var23);
					DBRepositoryProperty var25 = new DBRepositoryProperty();
					var10 = var24.getString("nsURI");
					String var11 = var24.getString("propertyName");
					if (!var10.equals("http://www.ibm.com/websphere/wim")) {
						var11 = this.schemaMgr.getQualifiedTypeName(var10, var11);
					}

					var25.setName(var11);
					List var12 = var24.getList("metaData");
					String var13 = var24.getString("dataType");
					DBDataType var14 = DAOHelper.getDBDataTypeFromCommonDataType(var13);
					var25.setDataType(var14.getDatatype());
					if (var14.getClassname() != null && var14.getClassname().length() != 0) {
						var25.setClassName(var14.getClassname());
					}

					var25.setMultipleValued(var24.getBoolean("multiValued"));

					String var18;
					for (int var15 = 0; var15 < var12.size(); ++var15) {
						DataObject var16 = (DataObject) var12.get(var15);
						String var17 = var16.getString("name");
						var18 = (String) ((String) var16.getList("values").get(0));
						if (var17.equals("classname")) {
							var25.setClassName(var18);
						} else if (var17.equals("applicationId")) {
							var25.setApplicationId(var18);
						} else if (var17.equals("caseExactMatch")) {
							var25.setCaseSensitive(new Boolean(var18));
						} else if (var17.equals("description")) {
							var25.setDescription(var18);
						} else if (var17.equals("isComposite")) {
							boolean var19 = new Boolean(var18);
							if (var19) {
								throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
										WIMMessageHelper.generateMsgParms(this.reposId + "|" + "isComposite"),
										CLASSNAME, "createSchema(DataObject)");
							}

							var25.setComposite(var19);
						} else if (var17.equals("multiValued")) {
							var25.setMultipleValued(new Boolean(var18));
						} else if (var17.equals("readOnly")) {
							var25.setReadOnly(new Boolean(var18));
						} else if (var17.equals("valueLength")) {
							var25.setValueLength(new Integer(var18));
						} else if (var17.equals("metaName")) {
							var25.setMetadataName(var18);
						}
					}

					if (var14.getDatatype().equals("OBJECT")
							&& (var25.getClassName() == null || var25.getClassName().length() == 0)) {
						throw new InvalidPropertyDefinitionException("INVALID_PROPERTY_DATA_TYPE",
								WIMMessageHelper.generateMsgParms(var24.getString("propertyName")), CLASSNAME,
								"createSchema(DataObject)");
					}

					if (var13.equalsIgnoreCase("STRING") && var25.getValueLength() == 0) {
						var25.setValueLength(254);
					}

					if (var25.getMetadataName() == null) {
						var25.setMetadataName("DEFAULT");
					}

					if (var25.getApplicationId() == null) {
						var25.setApplicationId("com.ibm.websphere.wim");
					}

					List var26 = var24.getList("applicableEntityTypeNames");
					HashSet var27 = new HashSet();

					for (int var28 = 0; var28 < var26.size(); ++var28) {
						var18 = (String) var26.get(var28);
						var27.add(var18);
						Set var31 = this.schemaMgr.getSubEntityTypes(var18);
						if (var31.size() != 0) {
							var27.addAll(var31);
						}
					}

					List var29 = var24.getList("requiredEntityTypeNames");
					HashSet var30 = null;
					int var32;
					if (var29 != null) {
						var30 = new HashSet();

						for (var32 = 0; var32 < var29.size(); ++var32) {
							String var20 = (String) var29.get(var32);
							if (!var26.contains(var20)) {
								throw new InvalidPropertyDefinitionException(
										"INVALID_PROPERTY_DEFINITION", WIMMessageHelper
												.generateMsgParms("requiredEntityTypeNames", var20, var25.getName()),
										CLASSNAME, "createSchema(DataObject)");
							}

							var30.add(var20);
							Set var21 = this.schemaMgr.getSubEntityTypes(var20);
							if (var21.size() != 0) {
								var30.addAll(var21);
							}
						}
					}

					var25.setApplicableEntityTypes(var27);
					var25.setRequiredEntityTypes(var30);
					var32 = this.dao.createLookAsidePropertyDefinition(var25);
					var25.setPropId(new Integer(var32));
					this.propertyManager.updatePropertyCache(var25);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI createSchema(DataObject)", WIMTraceHelper.printDataObject(var3));
		}

		return var3;
	}

	public DataObject getSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI getSchema(DataObject)", WIMTraceHelper.printDataObject(var1));
		}

		DataObject var3 = this.schemaMgr.createRootDataObject();
		Map var4 = ControlsHelper.getControlMap(var1);
		DataObject var5 = (DataObject) var4.get("ExtensionPropertyDataTypeControl");
		DataObject var6 = (DataObject) var4.get("ExtensionPropertyDefinitionControl");
		DataObject var7;
		if (var5 != null) {
			var7 = var3.getDataObject("schema");
			if (var7 == null) {
				var7 = var3.createDataObject("schema");
			}

			this.schemaMgr.getSupportedDataTypes(var7);
		} else if (var6 != null) {
			var7 = var3.getDataObject("schema");
			if (var7 == null) {
				var7 = var3.createDataObject("schema");
			}

			String var8 = var6.getString("entityTypeName");
			if (var8.startsWith("wim:")) {
				var8 = this.schemaMgr.getTypeName(var8);
			}

			List var9 = var6.getList("propertyNames");
			if (var9 != null && var9.size() > 0) {
				for (int var15 = 0; var15 < var9.size(); ++var15) {
					String var16 = (String) var9.get(var15);
					if (var16.startsWith("wim:")) {
						var16 = this.schemaMgr.getTypeName(var16);
					}

					DBRepositoryProperty var17 = this.propertyManager.getPropertyDefinition(var16);
					if (var17 == null) {
						throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
								WIMMessageHelper.generateMsgParms(var16, var8), CLASSNAME, "getSchema(DataObject)");
					}

					DataObject var18 = var7.createDataObject("extensionPropertySchema");
					DAOHelper.setPropertySchema(var17, var16, var18, var8);
				}
			} else {
				Set var10 = this.propertyManager.getSupportedAttributes(var8);
				if (var10 != null) {
					Iterator var11 = var10.iterator();

					while (var11.hasNext()) {
						String var12 = (String) var11.next();
						DBRepositoryProperty var13 = this.propertyManager.getPropertyDefinition(var12);
						if (var13 == null) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "getSchema(DataObject)",
										"The property " + var12 + " is not defined in repository " + this.reposId);
							}
						} else {
							DataObject var14 = var7.createDataObject("extensionPropertySchema");
							DAOHelper.setPropertySchema(var13, var12, var14, var8);
						}
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI getSchema(DataObject)", WIMTraceHelper.printDataObject(var3));
		}

		return var3;
	}

	private void getProperties(DataObject var1, long var2, String[] var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getProperties(DataObject entity, long entityId, String[] propNames)");
		}

		StringBuffer var6 = null;
		StringBuffer var7 = null;
		StringBuffer var8 = null;
		StringBuffer var9 = null;
		StringBuffer var10 = null;
		StringBuffer var11 = null;
		StringBuffer var12 = null;
		StringBuffer var13 = null;
		boolean var14 = false;
		boolean[] var15 = null;
		String var17;
		if (var4 != null) {
			for (int var16 = 0; var16 < var4.length; ++var16) {
				var17 = var4[var16];
				if (var17.equals("*")) {
					this.dao.readAllLAPropertiesForEntity(var2, var1);
				}

				DBRepositoryProperty var18 = this.propertyManager.getPropertyDefinition(var17);
				if (var18 != null) {
					if (!var18.isComposite()) {
						String var22 = var18.getDataType();
						short var20 = DAOHelper.getDataTypeId(var22);
						switch (var20) {
							case 0 :
								var6 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var6);
								break;
							case 1 :
								var9 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var9);
								break;
							case 2 :
								var8 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var8);
								break;
							case 3 :
								var7 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var7);
								break;
							case 4 :
								var10 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var10);
								break;
							case 5 :
								var11 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var11);
								break;
							case 6 :
								var12 = this.buildGetPropertyQuery(var20, var18.getPropId(), var4.length, var12);
						}
					} else {
						if (!var14) {
							var15 = new boolean[DAOHelper.types.length];

							for (int var19 = 0; var19 < DAOHelper.types.length; ++var19) {
								var15[var19] = false;
							}

							var14 = true;
							var13 = new StringBuffer(256);
							var13.append(var18.getPropId());
						} else {
							var13.append(this.dao.getQuerySet().COMMA);
							var13.append(var18.getPropId());
						}

						this.appendCompositeProperty(var18, var13, var15);
					}
				}
			}

			if (var6 != null) {
				var6.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readLAProperties(var2, var6, (short) 0, var1);
			}

			if (var7 != null) {
				var7.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readLAProperties(var2, var7, (short) 3, var1);
			}

			if (var8 != null) {
				var8.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readLAProperties(var2, var8, (short) 2, var1);
			}

			if (var9 != null) {
				var9.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readLAProperties(var2, var9, (short) 1, var1);
			}

			if (var10 != null) {
				var10.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readLAProperties(var2, var10, (short) 4, var1);
			}

			if (var11 != null) {
				var11.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readLAProperties(var2, var11, (short) 5, var1);
			}

			if (var12 != null) {
				var12.append(this.dao.getQuerySet().RIGHT_BRACKET);
				this.dao.readLAProperties(var2, var12, (short) 6, var1);
			}
		}

		if (var14) {
			HashMap var21 = new HashMap();
			var21.put(new Long(var2), var1);
			var17 = DAOHelper.buildEntityIdSQL(var21);
			this.dao.getCompositeProperties(var21, var13.toString(), var15, var17, false);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getProperties(DataObject entity, long entityId, String[] propNames)");
		}

	}

	private int searchString(StringBuffer var1, String var2, List var3, List var4, DataObject var5, boolean[] var6,
			StringBuffer var7, StringBuffer var8) throws WIMException {
		String var10 = "http://www.ibm.com/websphere/wim";
		int var11 = 1;
		int var12 = 1;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"searchString(StringBuffer sql, String conditionWhere, List parameters, List returnPropDefs, DataObject returnRT)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3, var4, var5, var7, var8}));
		}

		if (var4.size() == 0) {
			var1.ensureCapacity(256 + var2.length());
			var1.append(this.dao.getQuerySet().searchLANoResultPropertyWhere);
			var1.append(var2);
		} else {
			DBRepositoryProperty var13 = null;
			StringBuffer var14 = null;
			StringBuffer var15 = null;
			StringBuffer var16 = null;
			StringBuffer var17 = null;
			StringBuffer var18 = null;
			StringBuffer var19 = null;
			boolean var20 = false;

			for (int var21 = 0; var21 < var4.size(); ++var21) {
				var13 = (DBRepositoryProperty) var4.get(var21);
				if (var13.getParentCompositeName() != null) {
					trcLogger.logp(Level.FINER, CLASSNAME,
							"searchString(StringBuffer sql, String conditionWhere, List parameters, List returnPropDefs, DataObject returnRT)",
							"A component property '" + var13.getName()
									+ "' that is part of a composite property was specified stand alone.");
				}

				if (!var13.isComposite()) {
					String var24 = var13.getDataType();
					short var23 = DAOHelper.getDataTypeId(var24);
					switch (var23) {
						case 0 :
							if (var14 == null) {
								var14 = new StringBuffer(256);
								++var11;
								var14.append(var13.getPropId());
							} else {
								var14.append(this.dao.getQuerySet().COMMA);
								var14.append(var13.getPropId());
							}
							break;
						case 1 :
							if (var17 == null) {
								var17 = new StringBuffer(256);
								++var11;
								var17.append(var13.getPropId());
							} else {
								var17.append(this.dao.getQuerySet().COMMA);
								var17.append(var13.getPropId());
							}
							break;
						case 2 :
							if (var16 == null) {
								var16 = new StringBuffer(256);
								++var11;
								var16.append(var13.getPropId());
							} else {
								var16.append(this.dao.getQuerySet().COMMA);
								var16.append(var13.getPropId());
							}
							break;
						case 3 :
							if (var15 == null) {
								var15 = new StringBuffer(256);
								++var11;
								var15.append(var13.getPropId());
							} else {
								var15.append(this.dao.getQuerySet().COMMA);
								var15.append(var13.getPropId());
							}
							break;
						case 4 :
							if (var18 == null) {
								var18 = new StringBuffer(256);
								++var11;
								var18.append(var13.getPropId());
							} else {
								var18.append(this.dao.getQuerySet().COMMA);
								var18.append(var13.getPropId());
							}
							break;
						case 5 :
							if (var19 == null) {
								var19 = new StringBuffer(256);
								++var11;
								var19.append(var13.getPropId());
							} else {
								var19.append(this.dao.getQuerySet().COMMA);
								var19.append(var13.getPropId());
							}
							break;
						case 6 :
							if (var8.length() == 0) {
								++var11;
								var8.append(var13.getPropId());
							} else {
								var8.append(this.dao.getQuerySet().COMMA);
								var8.append(var13.getPropId());
							}
							break;
						default :
							throw new WIMApplicationException("INVALID_PROPERTY_DATA_TYPE",
									WIMMessageHelper.generateMsgParms(var13.getDataType()), CLASSNAME,
									"searchString(StringBuffer sql, String conditionWhere, List parameters, List returnPropDefs, DataObject returnRT)");
					}
				} else {
					if (!var20) {
						for (int var22 = 0; var22 < DAOHelper.types.length; ++var22) {
							var6[var22] = false;
						}

						var20 = true;
						var7.append(var13.getPropId());
					} else {
						var7.append(this.dao.getQuerySet().COMMA_AND_SPACE);
						var7.append(var13.getPropId());
					}

					this.appendCompositeProperty(var13, var7, var6);
				}
			}

			var1.ensureCapacity((var2.length() + 512) * var11);
			var1.append(this.dao.getQuerySet().findLAEntityGeneral);
			var1.append(this.dao.getQuerySet().AND);
			var1.append(var2);
			if (var14 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findStringPropertyForLAEntities);
				var1.append(this.dao.getQuerySet().findLAPropertyIdIn);
				var1.append(var14);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var15 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findIntegerPropertyForLAEntities);
				var1.append(this.dao.getQuerySet().findLAPropertyIdIn);
				var1.append(var15);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var16 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findDoublePropertyForLAEntities);
				var1.append(this.dao.getQuerySet().findLAPropertyIdIn);
				var1.append(var16);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var17 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findLongPropertyForLAEntities);
				var1.append(this.dao.getQuerySet().findLAPropertyIdIn);
				var1.append(var17);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var18 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findTimestampPropertyForLAEntities);
				var1.append(this.dao.getQuerySet().findLAPropertyIdIn);
				var1.append(var18);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			if (var19 != null) {
				var1.append(this.dao.getQuerySet().UNION);
				var1.append(this.dao.getQuerySet().findReferencePropertyForLAEntities);
				var1.append(this.dao.getQuerySet().findLAPropertyIdIn);
				var1.append(var19);
				var1.append(this.dao.getQuerySet().RIGHT_BRACKET);
				var1.append(this.dao.getQuerySet().AND);
				var1.append(var2);
				++var12;
			}

			var1.append(this.dao.getQuerySet().findLASpecificPropertyForEntitiesOrderBy);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"searchString(StringBuffer sql, String conditionWhere, List parameters, List returnPropDefs, DataObject returnRT)");
		}

		return var12;
	}

	private StringBuffer buildGetPropertyQuery(short var1, Integer var2, int var3, StringBuffer var4) {
		if (var4 == null) {
			var4 = new StringBuffer(256 + var3 * 8);
			var4.append(this.dao.getLAPropValuesByEntityQuery(var1));
			var4.append(var2);
		} else {
			var4.append(this.dao.getQuerySet().COMMA);
			var4.append(var2);
		}

		return var4;
	}

	private void updateProperties(long var1, DataObject var3, List var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateProperties(long mbrId, DataObject entity)", var1);
		}

		String var6 = this.schemaMgr.getQualifiedTypeName(var3.getType());
		Hashtable[] var7 = new Hashtable[7];
		Hashtable[] var8 = new Hashtable[7];
		Hashtable var9 = null;
		boolean var10 = false;
		Object var11 = this.propertyManager.getSupportedAttributes(var6);
		if (var11 == null) {
			var11 = new HashSet();
		}

		Iterator var12 = ((Set) var11).iterator();

		while (true) {
			while (true) {
				String var13;
				Property var14;
				DBRepositoryProperty var15;
				do {
					if (!var12.hasNext()) {
						if (var10) {
							this.dao.replaceProperties((short) 1, var1, var7,
									this.propertyManager.getMultiValuePropertyIds(), (String) null,
									this.isDbSharedAcrossMultipleServers);
						}

						if (var4 != null && var4.size() > 0) {
							for (int var21 = 0; var21 < var4.size(); ++var21) {
								var14 = (Property) var4.get(var21);
								var15 = this.propertyManager.getPropertyDefinition(var14.getName());
								String var22 = var15.getDataType();
								short var23 = DAOHelper.getDataTypeId(var22);
								Integer var24 = var15.getPropId();
								if (var8[var23] == null) {
									var8[var23] = new Hashtable();
								}

								var8[var23].put(var24, var14);
							}

							this.dao.deleteProperties((short) 1, var1, var8,
									this.propertyManager.getMultiValuePropertyIds(), (String) null);
						}

						if (var9 != null) {
							this.replaceCompositeProperties(var1, var9);
						}

						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.exiting(CLASSNAME, "updateProperties(long mbrId, DataObject entity)");
						}

						return;
					}

					var13 = (String) var12.next();
					var14 = this.schemaMgr.getProperty(var6, var13);
				} while (!var3.isSet(var14));

				var15 = this.propertyManager.getPropertyDefinition(var13);
				Integer var16 = var15.getPropId();
				String var17 = var15.getDataType();
				short var18 = DAOHelper.getDataTypeId(var17);
				if (this.propertyManager.isCompositeProperty(var13)) {
					if (var9 == null) {
						var9 = new Hashtable();
					}

					Object[] var25;
					if (this.propertyManager.isMultivaluedProperty(var13)) {
						var25 = new Object[]{var13, var3.getList(var14)};
						var9.put(var16, var25);
					} else {
						var25 = new Object[]{var13, var3.get(var14)};
						var9.put(var16, var25);
					}
				} else if (!this.propertyManager.isMultivaluedProperty(var13)) {
					if (var7[var18] == null) {
						var7[var18] = new Hashtable();
					}

					var7[var18].put(var16, var3.get(var14));
					var10 = true;
				} else {
					if (var7[var18] == null) {
						var7[var18] = new Hashtable();
					}

					List var19 = var3.getList(var14);
					Iterator var20 = var19.iterator();

					while (var20.hasNext()) {
						if (var20.next() == null) {
							var20.remove();
						}
					}

					if (var19.size() != 0) {
						var7[var18].put(var16, var19);
						var10 = true;
					}
				}
			}
		}
	}

	private void appendCompositeProperty(DBRepositoryProperty var1, StringBuffer var2, boolean[] var3) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"appendCompositeProperty(DBRepositoryProperty propDef, StringBuffer compositeQuery, boolean[] compositeTypes)");
		}

		Set var5 = var1.getComponentPropertyNames();
		if (var5 != null) {
			Iterator var6 = var5.iterator();

			while (var6.hasNext()) {
				DBRepositoryProperty var7 = this.propertyManager.getPropertyDefinition((String) var6.next());
				if (var7.isComposite()) {
					var2.append(this.dao.getQuerySet().COMMA_AND_SPACE);
					var2.append(var7.getPropId());
					this.appendCompositeProperty(var7, var2, var3);
				} else {
					String var8 = var7.getDataType();
					short var9 = DAOHelper.getDataTypeId(var8);
					var3[var9] = true;
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"appendCompositeProperty(DBRepositoryProperty propDef, StringBuffer compositeQuery, boolean[] compositeTypes)");
		}

	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
		}

		if (var1.equals("websphere.usermanager.serviceprovider.update.propertyextension.adminidpassword")) {
			byte[] var4 = (byte[]) ((byte[]) var2.get("DYNA_CONFIG_KEY_DB_ADMIN_PASSWORD"));

			try {
				String var5 = new String(var4, "UTF-8");
				this.dao.reload(var5);
			} catch (Exception var7) {
				Object var6;
				for (var6 = var7; ((Throwable) var6).getCause() != null; var6 = ((Throwable) var6).getCause()) {
					;
				}

				throw new DynamicUpdateConfigException("REPOSITORY_CONNECTION_FAILED",
						WIMMessageHelper.generateMsgParms(this.reposId, "DYNA_CONFIG_KEY_DB_ADMIN_PASSWORD",
								var6.getClass().getName()),
						CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = LookasideAdapter.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}