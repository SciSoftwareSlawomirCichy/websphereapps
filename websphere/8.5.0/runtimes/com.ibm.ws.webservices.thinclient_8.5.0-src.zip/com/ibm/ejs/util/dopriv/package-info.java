package com.ibm.ejs.util.dopriv;

interface package-info {
}