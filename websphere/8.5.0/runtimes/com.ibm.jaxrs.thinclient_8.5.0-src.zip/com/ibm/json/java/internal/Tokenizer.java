package com.ibm.json.java.internal;

import java.io.BufferedReader;
import java.io.CharArrayReader;
import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;
import java.io.StringReader;

public class Tokenizer {
	private Reader reader;
	private int lineNo;
	private int colNo;
	private int lastChar;

	public Tokenizer(Reader var1) throws IOException {
		Class var2 = var1.getClass();
		if (!StringReader.class.isAssignableFrom(var2) && !CharArrayReader.class.isAssignableFrom(var2)
				&& !PushbackReader.class.isAssignableFrom(var2) && !BufferedReader.class.isAssignableFrom(var2)) {
			var1 = new BufferedReader((Reader) var1);
		}

		this.reader = (Reader) var1;
		this.lineNo = 0;
		this.colNo = 0;
		this.lastChar = 10;
		this.readChar();
	}

	public Token next() throws IOException {
		while (Character.isWhitespace((char) this.lastChar)) {
			this.readChar();
		}

		switch (this.lastChar) {
			case -1 :
				this.readChar();
				return Token.TokenEOF;
			case 34 :
			case 39 :
				String var1 = this.readString();
				return new Token(var1);
			case 44 :
				this.readChar();
				return Token.TokenComma;
			case 45 :
			case 46 :
			case 48 :
			case 49 :
			case 50 :
			case 51 :
			case 52 :
			case 53 :
			case 54 :
			case 55 :
			case 56 :
			case 57 :
				Number var2 = this.readNumber();
				return new Token(var2);
			case 58 :
				this.readChar();
				return Token.TokenColon;
			case 91 :
				this.readChar();
				return Token.TokenBrackL;
			case 93 :
				this.readChar();
				return Token.TokenBrackR;
			case 102 :
			case 110 :
			case 116 :
				String var3 = this.readIdentifier();
				if (var3.equals("null")) {
					return Token.TokenNull;
				} else if (var3.equals("true")) {
					return Token.TokenTrue;
				} else {
					if (var3.equals("false")) {
						return Token.TokenFalse;
					}

					throw new IOException("Unexpected identifier '" + var3 + "' " + this.onLineCol());
				}
			case 123 :
				this.readChar();
				return Token.TokenBraceL;
			case 125 :
				this.readChar();
				return Token.TokenBraceR;
			default :
				throw new IOException("Unexpected character '" + (char) this.lastChar + "' " + this.onLineCol());
		}
	}

	private String readString() throws IOException {
		StringBuffer var1 = new StringBuffer();
		int var2 = this.lastChar;
		int var3 = this.lineNo;
		int var4 = this.colNo;
		this.readChar();

		while (-1 != this.lastChar && var2 != this.lastChar) {
			if (this.lastChar != 92) {
				var1.append((char) this.lastChar);
				this.readChar();
			} else {
				this.readChar();
				StringBuffer var5;
				int var7;
				switch (this.lastChar) {
					case 34 :
						this.readChar();
						var1.append('"');
						continue;
					case 39 :
						this.readChar();
						var1.append('\'');
						continue;
					case 47 :
						this.readChar();
						var1.append('/');
						continue;
					case 92 :
						this.readChar();
						var1.append('\\');
						continue;
					case 98 :
						this.readChar();
						var1.append('\b');
						continue;
					case 102 :
						this.readChar();
						var1.append('\f');
						continue;
					case 110 :
						this.readChar();
						var1.append('\n');
						continue;
					case 114 :
						this.readChar();
						var1.append('\r');
						continue;
					case 116 :
						this.readChar();
						var1.append('\t');
						continue;
					case 117 :
					case 120 :
						var5 = new StringBuffer();
						byte var6 = 2;
						if (this.lastChar == 117) {
							var6 = 4;
						}

						for (var7 = 0; var7 < var6; ++var7) {
							this.readChar();
							if (!this.isHexDigit(this.lastChar)) {
								throw new IOException("non-hex digit " + this.onLineCol());
							}

							var5.append((char) this.lastChar);
						}

						this.readChar();

						try {
							var7 = Integer.parseInt(var5.toString(), 16);
							var1.append((char) var7);
							continue;
						} catch (NumberFormatException var9) {
							throw new IOException("non-hex digit " + this.onLineCol());
						}
					default :
						if (!this.isOctalDigit(this.lastChar)) {
							throw new IOException("non-hex digit " + this.onLineCol());
						}

						var5 = new StringBuffer();
						var5.append((char) this.lastChar);
						var7 = 0;
				}

				while (var7 < 2) {
					this.readChar();
					if (!this.isOctalDigit(this.lastChar)) {
						break;
					}

					var5.append((char) this.lastChar);
					++var7;
				}

				try {
					var7 = Integer.parseInt(var5.toString(), 8);
					var1.append((char) var7);
				} catch (NumberFormatException var8) {
					throw new IOException("non-hex digit " + this.onLineCol());
				}
			}
		}

		if (-1 == this.lastChar) {
			throw new IOException("String not terminated " + this.onLineCol(var3, var4));
		} else {
			this.readChar();
			return var1.toString();
		}
	}

	private Number readNumber() throws IOException {
		StringBuffer var1 = new StringBuffer();
		int var2 = this.lineNo;
		int var3 = this.colNo;

		while (this.isDigitChar(this.lastChar)) {
			var1.append((char) this.lastChar);
			this.readChar();
		}

		String var4 = var1.toString();

		try {
			if (-1 != var4.indexOf(46)) {
				return Double.valueOf(var4);
			} else {
				String var5 = "";
				if (var4.startsWith("-")) {
					var5 = "-";
					var4 = var4.substring(1);
				}

				if (var4.toUpperCase().startsWith("0X")) {
					return Long.valueOf(var5 + var4.substring(2), 16);
				} else if (var4.equals("0")) {
					return new Long(0L);
				} else if (var4.startsWith("0") && var4.length() > 1) {
					return Long.valueOf(var5 + var4.substring(1), 8);
				} else {
					return (Number) (var4.indexOf("e") == -1 && var4.indexOf("E") == -1
							? Long.valueOf(var5 + var4, 10)
							: Double.valueOf(var5 + var4));
				}
			}
		} catch (NumberFormatException var7) {
			IOException var6 = new IOException("Invalid number literal " + this.onLineCol(var2, var3));
			var6.initCause(var7);
			throw var6;
		}
	}

	private boolean isHexDigit(int var1) {
		switch (var1) {
			case 48 :
			case 49 :
			case 50 :
			case 51 :
			case 52 :
			case 53 :
			case 54 :
			case 55 :
			case 56 :
			case 57 :
			case 65 :
			case 66 :
			case 67 :
			case 68 :
			case 69 :
			case 70 :
			case 97 :
			case 98 :
			case 99 :
			case 100 :
			case 101 :
			case 102 :
				return true;
			case 58 :
			case 59 :
			case 60 :
			case 61 :
			case 62 :
			case 63 :
			case 64 :
			case 71 :
			case 72 :
			case 73 :
			case 74 :
			case 75 :
			case 76 :
			case 77 :
			case 78 :
			case 79 :
			case 80 :
			case 81 :
			case 82 :
			case 83 :
			case 84 :
			case 85 :
			case 86 :
			case 87 :
			case 88 :
			case 89 :
			case 90 :
			case 91 :
			case 92 :
			case 93 :
			case 94 :
			case 95 :
			case 96 :
			default :
				return false;
		}
	}

	private boolean isOctalDigit(int var1) {
		switch (var1) {
			case 48 :
			case 49 :
			case 50 :
			case 51 :
			case 52 :
			case 53 :
			case 54 :
			case 55 :
				return true;
			default :
				return false;
		}
	}

	private boolean isDigitChar(int var1) {
		switch (var1) {
			case 43 :
			case 45 :
			case 46 :
			case 48 :
			case 49 :
			case 50 :
			case 51 :
			case 52 :
			case 53 :
			case 54 :
			case 55 :
			case 56 :
			case 57 :
			case 69 :
			case 88 :
			case 101 :
			case 120 :
				return true;
			default :
				return false;
		}
	}

	private String readIdentifier() throws IOException {
		StringBuffer var1 = new StringBuffer();

		while (-1 != this.lastChar && Character.isLetter((char) this.lastChar)) {
			var1.append((char) this.lastChar);
			this.readChar();
		}

		return var1.toString();
	}

	private void readChar() throws IOException {
		if (10 == this.lastChar) {
			this.colNo = 0;
			++this.lineNo;
		}

		this.lastChar = this.reader.read();
		if (-1 != this.lastChar) {
			++this.colNo;
		}
	}

	private String onLineCol(int var1, int var2) {
		return "on line " + var1 + ", column " + var2;
	}

	public String onLineCol() {
		return this.onLineCol(this.lineNo, this.colNo);
	}
}