package com.google.inject;

import com.google.inject.Initializer.InjectableReference;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.Lists;
import com.google.inject.internal.Maps;
import com.google.inject.internal.Preconditions;
import com.google.inject.spi.InjectionPoint;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;

class Initializer {
	private final Thread creatingThread = Thread.currentThread();
	private final CountDownLatch ready = new CountDownLatch(1);
	private final Map<Object, InjectableReference<?>> pendingInjection = Maps.newIdentityHashMap();

	public <T> Initializable<T> requestInjection(InjectorImpl injector, T instance, Object source,
			Set<InjectionPoint> injectionPoints) {
		Preconditions.checkNotNull(source);
		if (instance != null && (!injectionPoints.isEmpty() || injector.membersInjectorStore.hasTypeListeners())) {
			InjectableReference<T> initializable = new InjectableReference(this, injector, instance, source);
			this.pendingInjection.put(instance, initializable);
			return initializable;
		} else {
			return Initializables.of(instance);
		}
	}

	void validateOustandingInjections(Errors errors) {
		Iterator i$ = this.pendingInjection.values().iterator();

		while (i$.hasNext()) {
			InjectableReference reference = (InjectableReference) i$.next();

			try {
				reference.validate(errors);
			} catch (ErrorsException var5) {
				errors.merge(var5.getErrors());
			}
		}

	}

	void injectAll(Errors errors) {
		Iterator i$ = Lists.newArrayList(this.pendingInjection.values()).iterator();

		while (i$.hasNext()) {
			InjectableReference reference = (InjectableReference) i$.next();

			try {
				reference.get(errors);
			} catch (ErrorsException var5) {
				errors.merge(var5.getErrors());
			}
		}

		if (!this.pendingInjection.isEmpty()) {
			throw new AssertionError("Failed to satisfy " + this.pendingInjection);
		} else {
			this.ready.countDown();
		}
	}
}