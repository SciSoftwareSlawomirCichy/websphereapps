package com.google.common.io;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.base.Throwables;
import com.google.common.io.Closer.LoggingSuppressor;
import com.google.common.io.Closer.SuppressingSuppressor;
import com.google.common.io.Closer.Suppressor;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Beta
@GwtIncompatible
public final class Closer implements Closeable {
	private static final Suppressor SUPPRESSOR;
	@VisibleForTesting
	final Suppressor suppressor;
	private final Deque<Closeable> stack = new ArrayDeque(4);
	@MonotonicNonNullDecl
	private Throwable thrown;

	public static Closer create() {
		return new Closer(SUPPRESSOR);
	}

	@VisibleForTesting
	Closer(Suppressor suppressor) {
		this.suppressor = (Suppressor) Preconditions.checkNotNull(suppressor);
	}

	@CanIgnoreReturnValue
	public <C extends Closeable> C register(@NullableDecl C closeable) {
		if (closeable != null) {
			this.stack.addFirst(closeable);
		}

		return closeable;
	}

	public RuntimeException rethrow(Throwable e) throws IOException {
		Preconditions.checkNotNull(e);
		this.thrown = e;
		Throwables.propagateIfPossible(e, IOException.class);
		throw new RuntimeException(e);
	}

	public <X extends Exception> RuntimeException rethrow(Throwable e, Class<X> declaredType) throws IOException, X {
		Preconditions.checkNotNull(e);
		this.thrown = e;
		Throwables.propagateIfPossible(e, IOException.class);
		Throwables.propagateIfPossible(e, declaredType);
		throw new RuntimeException(e);
	}

	public <X1 extends Exception, X2 extends Exception> RuntimeException rethrow(Throwable e, Class<X1> declaredType1,
			Class<X2> declaredType2) throws IOException, X1, X2 {
		Preconditions.checkNotNull(e);
		this.thrown = e;
		Throwables.propagateIfPossible(e, IOException.class);
		Throwables.propagateIfPossible(e, declaredType1, declaredType2);
		throw new RuntimeException(e);
	}

	public void close() throws IOException {
		Throwable throwable = this.thrown;

		while (!this.stack.isEmpty()) {
			Closeable closeable = (Closeable) this.stack.removeFirst();

			try {
				closeable.close();
			} catch (Throwable var4) {
				if (throwable == null) {
					throwable = var4;
				} else {
					this.suppressor.suppress(closeable, throwable, var4);
				}
			}
		}

		if (this.thrown == null && throwable != null) {
			Throwables.propagateIfPossible(throwable, IOException.class);
			throw new AssertionError(throwable);
		}
	}

	static {
		SUPPRESSOR = (Suppressor) (SuppressingSuppressor.isAvailable()
				? SuppressingSuppressor.INSTANCE
				: LoggingSuppressor.INSTANCE);
	}
}