package com.ibm.bsf.util;

import java.beans.Introspector;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.StringTokenizer;
import java.util.Vector;

public class StringUtils {
	public static final String lineSeparator = System.getProperty("line.separator", "\n");
	public static final String lineSeparatorStr;

	public static String classNameToVarName(String var0) {
		int var1;
		for (var1 = 0; var0.endsWith("[]"); ++var1) {
			var0 = var0.substring(0, var0.length() - 2);
		}

		int var2 = var0.lastIndexOf(46);
		String var3 = Introspector.decapitalize(var2 != -1 ? var0.substring(var2 + 1) : var0);
		if (var1 > 0) {
			var3 = var3 + "_" + var1 + "D";
		}

		return getValidIdentifierName(var3);
	}

	public static String cleanString(String var0) {
		if (var0 == null) {
			return null;
		} else {
			char[] var1 = var0.toCharArray();
			StringBuffer var2 = new StringBuffer();

			for (int var3 = 0; var3 < var1.length; ++var3) {
				switch (var1[var3]) {
					case '\n' :
						var2.append("\\n");
						break;
					case '\r' :
						var2.append("\\r");
						break;
					case '"' :
						var2.append("\\\"");
						break;
					case '\\' :
						var2.append("\\\\");
						break;
					default :
						var2.append(var1[var3]);
				}
			}

			return var2.toString();
		}
	}

	public static String getChars(int var0, char var1) {
		if (var0 <= 0) {
			return "";
		} else {
			StringBuffer var2 = new StringBuffer(var0);

			for (int var3 = 0; var3 < var0; ++var3) {
				var2.append(var1);
			}

			return var2.toString();
		}
	}

	public static String getClassName(Class var0) {
		String var1 = var0.getName();
		return var0.isArray() ? parseDescriptor(var1) : var1;
	}

	public static String getCommaListFromVector(Vector var0) {
		StringBuffer var1 = new StringBuffer();

		for (int var2 = 0; var2 < var0.size(); ++var2) {
			var1.append((var2 > 0 ? ", " : "") + var0.elementAt(var2));
		}

		return var1.toString();
	}

	public static Reader getContentAsReader(URL var0) throws SecurityException, IllegalArgumentException, IOException {
		if (var0 == null) {
			throw new IllegalArgumentException("URL cannot be null.");
		} else {
			try {
				Object var1 = var0.getContent();
				if (var1 == null) {
					throw new IllegalArgumentException("No content.");
				} else if (var1 instanceof InputStream) {
					InputStreamReader var2 = new InputStreamReader((InputStream) var1);
					if (var2.ready()) {
						return var2;
					} else {
						throw new FileNotFoundException();
					}
				} else {
					throw new IllegalArgumentException(var1 instanceof String
							? (String) var1
							: "This URL points to a: " + getClassName(var1.getClass()));
				}
			} catch (SecurityException var3) {
				throw new SecurityException("Your JVM's SecurityManager has disallowed this.");
			} catch (FileNotFoundException var4) {
				throw new FileNotFoundException("This file was not found: " + var0);
			}
		}
	}

	public static String getContentAsString(URL var0) throws SecurityException, IllegalArgumentException, IOException {
		return IOUtils.getStringFromReader(getContentAsReader(var0));
	}

	public static String getSafeString(String var0) {
		BufferedReader var1 = new BufferedReader(new StringReader(var0));
		StringBuffer var2 = new StringBuffer();
		String var4 = null;

		String var3;
		try {
			for (; (var3 = var1.readLine()) != null; var4 = cleanString(var3)) {
				if (var4 != null) {
					var2.append("\"" + var4 + lineSeparatorStr + "\" +" + lineSeparator);
				}
			}
		} catch (IOException var6) {
			;
		}

		var2.append("\"" + (var4 != null ? var4 : "") + "\"" + lineSeparator);
		return var2.toString();
	}

	public static URL getURL(URL var0, String var1) throws MalformedURLException {
		return getURL(var0, var1, 1);
	}

	private static URL getURL(URL var0, String var1, int var2) throws MalformedURLException {
		URL var3 = null;

		try {
			var3 = new URL(var0, var1);

			try {
				var3.openStream();
			} catch (IOException var8) {
				throw new MalformedURLException("This file was not found: " + var3);
			}
		} catch (MalformedURLException var10) {
			var3 = new URL("file", "", var1);

			try {
				var3.openStream();
			} catch (IOException var9) {
				if (var0 != null) {
					String var6 = var0.getFile();
					String var7 = (new File(var6)).getParent();
					if (var7 != null && var2 < 3) {
						return getURL(new URL("file", "", var7 + '/'), var1, var2 + 1);
					}
				}

				throw new MalformedURLException("This file was not found: " + var3);
			}
		}

		return var3;
	}

	public static String getValidIdentifierName(String var0) {
		if (var0 != null && var0.length() != 0) {
			StringBuffer var1 = new StringBuffer();
			char[] var2 = var0.toCharArray();
			var1.append(Character.isJavaIdentifierStart(var2[0]) ? var2[0] : '_');

			for (int var3 = 1; var3 < var2.length; ++var3) {
				var1.append(Character.isJavaIdentifierPart(var2[var3]) ? var2[var3] : '_');
			}

			return var1.toString();
		} else {
			return null;
		}
	}

	public static boolean isValidIdentifierName(String var0) {
		if (var0 != null && var0.length() != 0) {
			char[] var1 = var0.toCharArray();
			if (!Character.isJavaIdentifierStart(var1[0])) {
				return false;
			} else {
				for (int var2 = 1; var2 < var1.length; ++var2) {
					if (!Character.isJavaIdentifierPart(var1[var2])) {
						return false;
					}
				}

				return true;
			}
		} else {
			return false;
		}
	}

	public static boolean isValidPackageName(String var0) {
		if (var0 == null) {
			return false;
		} else if (var0.length() == 0) {
			return true;
		} else {
			StringTokenizer var1 = new StringTokenizer(var0, ".", true);
			if (var1.countTokens() % 2 != 1) {
				return false;
			} else if (!isValidIdentifierName(var1.nextToken())) {
				return false;
			} else {
				do {
					if (!var1.hasMoreTokens()) {
						return true;
					}

					if (!var1.nextToken().equals(".")) {
						return false;
					}

					if (!var1.hasMoreTokens()) {
						return false;
					}
				} while (isValidIdentifierName(var1.nextToken()));

				return false;
			}
		}
	}

	private static String parseDescriptor(String var0) {
		char[] var1 = var0.toCharArray();
		int var2 = 0;

		int var3;
		for (var3 = 0; var1[var3] == '['; ++var3) {
			++var2;
		}

		StringBuffer var4 = new StringBuffer();
		switch (var1[var3++]) {
			case 'B' :
				var4.append("byte");
				break;
			case 'C' :
				var4.append("char");
				break;
			case 'D' :
				var4.append("double");
			case 'E' :
			case 'G' :
			case 'H' :
			case 'K' :
			case 'M' :
			case 'N' :
			case 'O' :
			case 'P' :
			case 'Q' :
			case 'R' :
			case 'T' :
			case 'U' :
			case 'V' :
			case 'W' :
			case 'X' :
			case 'Y' :
			default :
				break;
			case 'F' :
				var4.append("float");
				break;
			case 'I' :
				var4.append("int");
				break;
			case 'J' :
				var4.append("long");
				break;
			case 'L' :
				var4.append(var1, var3, var1.length - var3 - 1);
				break;
			case 'S' :
				var4.append("short");
				break;
			case 'Z' :
				var4.append("boolean");
		}

		for (var3 = 0; var3 < var2; ++var3) {
			var4.append("[]");
		}

		return var4.toString();
	}

	static {
		lineSeparatorStr = cleanString(lineSeparator);
	}
}