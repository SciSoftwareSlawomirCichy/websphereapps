package com.ibm.ejs.container;

import com.ibm.ws.ejb.portable.Constants;
import com.ibm.ws.ejb.portable.LoggerHelper;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.UnexpectedException;
import java.util.Arrays;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJBException;
import javax.rmi.PortableRemoteObject;
import javax.rmi.CORBA.Stub;
import javax.rmi.CORBA.Util;
import org.omg.CORBA.NO_RESPONSE;
import org.omg.CORBA.SystemException;
import org.omg.CORBA.portable.ApplicationException;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.RemarshalException;
import org.omg.CORBA.portable.ServantObject;
import org.omg.CORBA_2_3.portable.InputStream;

public class ClientAsyncResult implements Future, Serializable {
	private static final long serialVersionUID = -2495785869614768234L;
	private static final String CLASS_NAME;
	private static final Logger svLogger;
	public static final String disableAsyncResultRetries = "com.ibm.websphere.ejbcontainer.disableAsyncResultRetries";
	public static final boolean DisableAsyncResultRetries;
	public static final String asyncResultNoResponseBackoff = "com.ibm.websphere.ejbcontainer.asyncResultNoResponseBackoff";
	public static final long AsyncResultNoResponseBackoff;
	private static final long MIN_ASYNC_RESULT_NO_RESPONSE_WAIT_TIME;
	private transient RemoteAsyncResult ivServer = null;
	private final boolean ivServerExtended;
	private transient boolean ivUseServerExtended;
	private transient Object ivResult = null;
	private transient boolean ivDone = false;
	private transient CancellationException ivCancellationException = null;
	private transient ExecutionException ivExecutionException = null;
	private transient boolean ivBusinessRmiRemote = false;

	private EJBException initCause(EJBException ex) {
		if (ex.getCause() == null) {
			ex.initCause(ex.getCausedByException());
		}

		return ex;
	}

	public ClientAsyncResult(RemoteAsyncResult serverImpl, boolean businessRmiRemote) {
		this.ivServer = serverImpl;
		this.ivBusinessRmiRemote = businessRmiRemote;
		this.ivServerExtended = serverImpl instanceof RemoteAsyncResultExtended;
	}

	public String toString() {
		return super.toString() + "[rmi=" + this.ivBusinessRmiRemote + ", done=" + this.ivDone + ", exception="
				+ (this.ivExecutionException != null) + ", cancelled=" + (this.ivCancellationException != null)
				+ ", extended=" + this.ivUseServerExtended + ']';
	}

	public boolean cancel(boolean mayInterruptIfRunning) {
		boolean isTraceOn = svLogger.isLoggable(Level.FINER);
		if (isTraceOn) {
			svLogger.entering(CLASS_NAME, "cancel", new Object[]{this.toString(), mayInterruptIfRunning});
		}

		boolean cancelled = false;

		try {
			cancelled = this.ivServer != null ? this.ivServer.cancel(mayInterruptIfRunning) : false;
			if (cancelled) {
				this.ivCancellationException = new CancellationException();
				this.ivDone = true;
				this.ivServer = null;
			}
		} catch (RemoteException var6) {
			EJBException ejbEx = this.initCause(new EJBException(var6));
			if (isTraceOn) {
				svLogger.exiting(CLASS_NAME, "cancel", ejbEx);
			}

			throw ejbEx;
		}

		if (isTraceOn) {
			svLogger.exiting(CLASS_NAME, "cancel", cancelled);
		}

		return cancelled;
	}

	public boolean isCancelled() {
		if (svLogger.isLoggable(Level.FINER)) {
			svLogger.logp(Level.FINER, CLASS_NAME, "isCancelled", this.toString());
		}

		return this.ivCancellationException != null;
	}

	public Object get() throws ExecutionException, InterruptedException {
		boolean isTraceOn = svLogger.isLoggable(Level.FINER);
		if (isTraceOn) {
			svLogger.entering(CLASS_NAME, "get", this.toString());
		}

		if (this.ivCancellationException != null) {
			if (isTraceOn) {
				svLogger.exiting(CLASS_NAME, "get", this.ivCancellationException);
			}

			throw this.ivCancellationException;
		} else if (this.ivExecutionException != null) {
			if (isTraceOn) {
				svLogger.exiting(CLASS_NAME, "get", this.ivExecutionException);
			}

			throw this.ivExecutionException;
		} else {
			try {
				if (this.ivResult == null && this.ivServer != null) {
					if (this.ivUseServerExtended) {
						try {
							this.ivResult = this.waitForResult(0L);
						} catch (TimeoutException var5) {
							IllegalStateException ise = new IllegalStateException(var5);
							if (isTraceOn) {
								svLogger.exiting(CLASS_NAME, "get", ise);
							}

							throw ise;
						}
					} else {
						if (isTraceOn) {
							svLogger.logp(Level.FINER, CLASS_NAME, "get", "calling stub.get()");
						}

						this.ivResult = this.ivServer.get();
					}

					this.ivServer = null;
				}
			} catch (ExecutionException var6) {
				this.ivExecutionException = var6;
				this.ivServer = null;
				if (isTraceOn) {
					svLogger.exiting(CLASS_NAME, "get", var6);
				}

				throw var6;
			} catch (RemoteException var7) {
				if (isTraceOn) {
					svLogger.logp(Level.FINER, CLASS_NAME, "get", "caught RemoteException", var7);
				}

				this.ivServer = null;
				if (this.ivBusinessRmiRemote) {
					this.ivExecutionException = new ExecutionException(var7);
				} else {
					Throwable cause = var7.getCause();
					EJBException ejbEx = this.initCause(
							new EJBException((Exception) (cause instanceof Exception ? (Exception) cause : var7)));
					this.ivExecutionException = new ExecutionException(ejbEx);
				}

				if (isTraceOn) {
					svLogger.exiting(CLASS_NAME, "get", this.ivExecutionException);
				}

				throw this.ivExecutionException;
			}

			if (isTraceOn) {
				svLogger.exiting(CLASS_NAME, "get", "result");
			}

			return this.ivResult;
		}
	}

	public Object get(long timeout, TimeUnit unit) throws ExecutionException, InterruptedException, TimeoutException {
		boolean isTraceOn = svLogger.isLoggable(Level.FINER);
		if (isTraceOn) {
			svLogger.entering(CLASS_NAME, "get", new Object[]{this.toString(), timeout, unit});
		}

		if (this.ivCancellationException != null) {
			if (isTraceOn) {
				svLogger.exiting(CLASS_NAME, "get", this.ivCancellationException);
			}

			throw this.ivCancellationException;
		} else if (this.ivExecutionException != null) {
			if (isTraceOn) {
				svLogger.exiting(CLASS_NAME, "get", this.ivExecutionException);
			}

			throw this.ivExecutionException;
		} else {
			try {
				if (this.ivResult == null && this.ivServer != null) {
					long millis = unit.toMillis(timeout);
					if (this.ivUseServerExtended && millis > 0L) {
						this.ivResult = this.waitForResult(millis);
					} else {
						if (isTraceOn) {
							svLogger.logp(Level.FINER, CLASS_NAME, "get", "calling stub.get(long, String)");
						}

						this.ivResult = this.ivServer.get(timeout, unit.toString());
					}

					this.ivServer = null;
				}
			} catch (ExecutionException var8) {
				this.ivExecutionException = var8;
				this.ivServer = null;
				if (isTraceOn) {
					svLogger.exiting(CLASS_NAME, "get", var8);
				}

				throw var8;
			} catch (RemoteException var9) {
				if (isTraceOn) {
					svLogger.logp(Level.FINER, CLASS_NAME, "get", "caught RemoteException", var9);
				}

				this.ivServer = null;
				if (this.ivBusinessRmiRemote) {
					this.ivExecutionException = new ExecutionException(var9);
				} else {
					Throwable cause = var9.getCause();
					EJBException ejbEx = this.initCause(
							new EJBException((Exception) (cause instanceof Exception ? (Exception) cause : var9)));
					this.ivExecutionException = new ExecutionException(ejbEx);
				}

				if (isTraceOn) {
					svLogger.exiting(CLASS_NAME, "get", this.ivExecutionException);
				}

				throw this.ivExecutionException;
			}

			if (isTraceOn) {
				svLogger.exiting(CLASS_NAME, "get", "result");
			}

			return this.ivResult;
		}
	}

	private Object waitForResult(long timeoutMillis)
			throws ExecutionException, InterruptedException, TimeoutException, RemoteException {
		boolean isTraceOn = svLogger.isLoggable(Level.FINER);
		if (isTraceOn) {
			svLogger.entering(CLASS_NAME, "waitForResult", timeoutMillis);
		}

		long begin = System.nanoTime();
		long beginLastAttempt = begin;
		long end = begin + TimeUnit.MILLISECONDS.toNanos(timeoutMillis);
		boolean noResponse = false;
		long waitTimeMillis = timeoutMillis;
		long maxWaitTimeMillis = -1L;

		while (true) {
			if (isTraceOn) {
				svLogger.entering(CLASS_NAME, "waitForResult", "waiting " + waitTimeMillis);
			}

			Object[] resultArray;
			try {
				resultArray = this.stubWaitForResult((Stub) this.ivServer, waitTimeMillis);
			} catch (RemoteException var20) {
				Throwable cause = var20.getCause();
				if (!(cause instanceof NO_RESPONSE) || noResponse) {
					if (isTraceOn) {
						svLogger.exiting(CLASS_NAME, "waitForResult", var20);
					}

					throw var20;
				}

				if (isTraceOn) {
					svLogger.logp(Level.FINER, CLASS_NAME, "waitForResult", "retrying", cause);
				}

				resultArray = null;
				noResponse = true;
			}

			if (resultArray != null) {
				if (isTraceOn) {
					svLogger.exiting(CLASS_NAME, "waitForResult", "result");
				}

				return resultArray[0];
			}

			long now = System.nanoTime();
			long actualWaitTimeMillis;
			if (timeoutMillis > 0L) {
				actualWaitTimeMillis = TimeUnit.NANOSECONDS.toMillis(end - now);
				if (actualWaitTimeMillis <= 0L) {
					if (isTraceOn) {
						svLogger.exiting(CLASS_NAME, "waitForResult", "timeout");
					}

					throw new TimeoutException();
				}

				waitTimeMillis = actualWaitTimeMillis;
			}

			if (noResponse) {
				if (maxWaitTimeMillis == -1L) {
					actualWaitTimeMillis = TimeUnit.NANOSECONDS.toMillis(now - beginLastAttempt);
					maxWaitTimeMillis = Math.max(MIN_ASYNC_RESULT_NO_RESPONSE_WAIT_TIME,
							actualWaitTimeMillis - AsyncResultNoResponseBackoff);
				}

				if (timeoutMillis == 0L) {
					waitTimeMillis = maxWaitTimeMillis;
				} else {
					waitTimeMillis = Math.min(waitTimeMillis, maxWaitTimeMillis);
				}
			}

			beginLastAttempt = now;
		}
	}

	private Object[] stubWaitForResult(Stub stub, long waitTime)
			throws ExecutionException, InterruptedException, RemoteException {
		while (true) {
			Object[] var29;
			if (!Util.isLocal(stub)) {
				InputStream in = null;

				try {
					try {
						OutputStream out = stub._request("waitForResult", true);
						out.write_longlong(waitTime);
						in = (InputStream) stub._invoke(out);
						var29 = (Object[]) ((Object[]) in.read_value(array$Ljava$lang$Object == null
								? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;"))
								: array$Ljava$lang$Object));
					} catch (ApplicationException var21) {
						in = (InputStream) var21.getInputStream();
						String id = in.read_string();
						if (id.equals("IDL:java/util/concurrent/ExecutionEx:1.0")) {
							throw (ExecutionException) in
									.read_value(class$java$util$concurrent$ExecutionException == null
											? (class$java$util$concurrent$ExecutionException = class$(
													"java.util.concurrent.ExecutionException"))
											: class$java$util$concurrent$ExecutionException);
						}

						if (id.equals("IDL:java/lang/InterruptedEx:1.0")) {
							throw (InterruptedException) in.read_value(class$java$lang$InterruptedException == null
									? (class$java$lang$InterruptedException = class$("java.lang.InterruptedException"))
									: class$java$lang$InterruptedException);
						}

						throw new UnexpectedException(id);
					} catch (RemarshalException var22) {
						continue;
					}
				} catch (SystemException var23) {
					throw Util.mapSystemException(var23);
				} finally {
					stub._releaseReply(in);
				}

				return var29;
			} else {
				ServantObject so = stub._servant_preinvoke("waitForResult",
						class$com$ibm$ejs$container$RemoteAsyncResultExtended == null
								? (class$com$ibm$ejs$container$RemoteAsyncResultExtended = class$(
										"com.ibm.ejs.container.RemoteAsyncResultExtended"))
								: class$com$ibm$ejs$container$RemoteAsyncResultExtended);
				if (so != null) {
					try {
						Object[] result = ((RemoteAsyncResultExtended) so.servant).waitForResult(waitTime);
						var29 = (Object[]) ((Object[]) Util.copyObject(result, stub._orb()));
					} catch (Throwable var25) {
						Throwable exCopy = (Throwable) Util.copyObject(var25, stub._orb());
						if (exCopy instanceof ExecutionException) {
							throw (ExecutionException) exCopy;
						}

						if (exCopy instanceof InterruptedException) {
							throw (InterruptedException) exCopy;
						}

						throw Util.wrapException(exCopy);
					} finally {
						stub._servant_postinvoke(so);
					}

					return var29;
				}
			}
		}
	}

	public boolean isDone() {
		boolean isTraceOn = svLogger.isLoggable(Level.FINER);
		if (isTraceOn) {
			svLogger.entering(CLASS_NAME, "isDone", this.toString());
		}

		try {
			if (!this.ivDone) {
				this.ivDone = this.ivServer != null ? this.ivServer.isDone() : true;
			}
		} catch (RemoteException var3) {
			throw this.initCause(new EJBException(var3));
		}

		if (isTraceOn) {
			svLogger.exiting(CLASS_NAME, "isDone", this.ivDone);
		}

		return this.ivDone;
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		if (svLogger.isLoggable(Level.FINER)) {
			svLogger.logp(Level.FINER, CLASS_NAME, "writeObject", this.toString());
		}

		if (this.ivServer == null) {
			throw new EJBException("No Server side Future object exists.");
		} else {
			out.defaultWriteObject();
			out.write(Constants.CLIENT_ASYNC_RESULT_EYE_CATCHER);
			out.writeShort(1);
			out.writeShort(1);
			out.writeObject(this.ivServer);
			out.writeBoolean(this.ivBusinessRmiRemote);
		}
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		boolean isTraceOn = svLogger.isLoggable(Level.FINER);
		if (isTraceOn) {
			svLogger.entering(CLASS_NAME, "readObject");
		}

		in.defaultReadObject();
		byte[] ec = new byte[4];
		byte[] eyecatcher = Constants.CLIENT_ASYNC_RESULT_EYE_CATCHER;
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < 4; i += bytesRead) {
			bytesRead = in.read(ec, i, 4 - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < eyecatcher.length; ++i) {
			if (eyecatcher[i] != ec[i]) {
				String eyeCatcherString = Arrays.toString(ec);
				throw new IOException(
						"Invalid eye catcher '" + eyeCatcherString + "' in ClientAsyncResult input stream");
			}
		}

		short incoming_platform = in.readShort();
		short incoming_vid = in.readShort();
		this.ivServer = (RemoteAsyncResult) PortableRemoteObject.narrow(in.readObject(),
				class$com$ibm$ejs$container$RemoteAsyncResult == null
						? (class$com$ibm$ejs$container$RemoteAsyncResult = class$(
								"com.ibm.ejs.container.RemoteAsyncResult"))
						: class$com$ibm$ejs$container$RemoteAsyncResult);
		this.ivBusinessRmiRemote = in.readBoolean();
		this.ivUseServerExtended = this.ivServerExtended && !DisableAsyncResultRetries
				&& !Util.isLocal((Stub) this.ivServer);
		if (isTraceOn) {
			svLogger.exiting(CLASS_NAME, "readObject",
					this.toString() + ", platform=" + incoming_platform + ", version=" + incoming_vid + ", extended="
							+ this.ivServerExtended + ", server=" + this.ivServer);
		}

	}

	static {
		CLASS_NAME = (class$com$ibm$ejs$container$ClientAsyncResult == null
				? (class$com$ibm$ejs$container$ClientAsyncResult = class$("com.ibm.ejs.container.ClientAsyncResult"))
				: class$com$ibm$ejs$container$ClientAsyncResult).getName();
		svLogger = LoggerHelper.getLogger(CLASS_NAME, "EJBContainer");
		DisableAsyncResultRetries = Boolean.getBoolean("com.ibm.websphere.ejbcontainer.disableAsyncResultRetries");
		AsyncResultNoResponseBackoff = TimeUnit.SECONDS
				.toMillis((long) Integer.getInteger("com.ibm.websphere.ejbcontainer.asyncResultNoResponseBackoff", 30));
		MIN_ASYNC_RESULT_NO_RESPONSE_WAIT_TIME = TimeUnit.SECONDS.toMillis(1L);
	}
}