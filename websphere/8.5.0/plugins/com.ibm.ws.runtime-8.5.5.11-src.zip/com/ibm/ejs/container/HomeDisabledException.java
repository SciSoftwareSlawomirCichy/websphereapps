package com.ibm.ejs.container;

public class HomeDisabledException extends RuntimeException {
	private static final long serialVersionUID = 8801205964764897441L;

	public HomeDisabledException(String s) {
		super(s);
	}
}