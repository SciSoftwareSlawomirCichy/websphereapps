package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_zh extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: 分析引擎正在使用数据库：{0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: FFDC 事件发生于 {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE", "FFDC0002I: FFDC 日志文件管理正在尝试删除文件 {0}"},
			{"FFDCJANITOR_DELETED_FILES", "FFDC0004I: FFDC 日志文件管理记录了 {0} 个文件（共 {1} 个），这些文件已达到其配置的最长寿命"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE", "FFDC0003I: FFDC 日志文件管理无法删除文件 {0}"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST", "FFDC0001W: FFDC 日志文件管理无法获取异常文件列表"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC 已关闭事件流文件 {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC 已打开事件流文件 {0}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE", "FFDC0012I: FFDC 无法关闭事件流文件 {0}，捕获的异常 {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE", "FFDC0011I: FFDC 无法打开或创建事件流文件 {0}，捕获的异常 {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE", "FFDC0013I: FFDC 无法写入事件流文件 {0}，捕获的异常 {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}