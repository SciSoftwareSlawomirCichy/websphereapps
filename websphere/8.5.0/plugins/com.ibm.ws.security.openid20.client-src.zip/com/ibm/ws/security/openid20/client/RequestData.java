package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.openid20.util.OidUtil;
import java.util.Map;
import javax.security.auth.Subject;
import org.openid4java.discovery.DiscoveryInformation;

public class RequestData {
	private static final TraceComponent tc = Tr.register(RequestData.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private DiscoveryInformation discoveryInfo = null;
	private String requestMethod = null;
	private Map<String, String[]> parameterMap = null;
	private Subject subject = null;
	private String userName = null;
	private long creationTime = 0L;

	private RequestData() {
	}

	RequestData(DiscoveryInformation discoveryInfo, String reqMethod, Map<String, String[]> pm) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "RequestData(discoveryInfo[" + OidUtil.getObjState(discoveryInfo) + "],parameterMap["
					+ OidUtil.getObjState(pm) + "])");
		}

		this.discoveryInfo = discoveryInfo;
		this.requestMethod = reqMethod;
		this.parameterMap = pm;
		this.creationTime = System.currentTimeMillis();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "RequestData");
		}

	}

	void setSubject(Subject s) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setSubject(username[" + OidUtil.getObjState(s) + "])");
		}

		this.subject = s;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setSubject");
		}

	}

	public Subject getSubject() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSubject returns [" + OidUtil.getObjState(this.subject) + "]");
		}

		return this.subject;
	}

	void setUserName(String un) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setUserName(username[" + un + "])");
		}

		this.userName = un;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setUserName");
		}

	}

	public String getUserName() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getUserName returns [" + this.userName + "]");
		}

		return this.userName;
	}

	public String getMethod() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getMethod returns [" + this.requestMethod + "]");
		}

		return this.requestMethod;
	}

	public Map<String, String[]> getParameterMap() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getParameterMap returns [" + OidUtil.getObjState(this.parameterMap) + "]");
		}

		return this.parameterMap;
	}

	public DiscoveryInformation getDiscoveryInformation() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDiscoveryInformation returns [" + OidUtil.getObjState(this.discoveryInfo) + "]");
		}

		return this.discoveryInfo;
	}

	public long getCreationTime() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getCreationTime returns [" + this.creationTime + "]");
		}

		return this.creationTime;
	}

	public void purge() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "purge");
		}

		this.discoveryInfo = null;
		this.requestMethod = null;
		this.parameterMap = null;
		this.subject = null;
		this.userName = null;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "purge");
		}

	}
}