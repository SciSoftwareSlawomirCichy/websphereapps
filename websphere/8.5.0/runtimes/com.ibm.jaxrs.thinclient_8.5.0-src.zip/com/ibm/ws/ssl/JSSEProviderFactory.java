package com.ibm.ws.ssl;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.config.SecurityObjectLocator;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.ssl.JSSEProviderFactory.1;
import com.ibm.ws.ssl.JSSEProviderFactory.2;
import com.ibm.ws.ssl.JSSEProviderFactory.3;
import com.ibm.ws.ssl.JSSEProviderFactory.4;
import com.ibm.ws.ssl.JSSEProviderFactory.5;
import com.ibm.ws.ssl.JSSEProviderFactory.6;
import com.ibm.ws.ssl.JSSEProviderFactory.7;
import com.ibm.ws.ssl.config.FIPSManager;
import com.ibm.ws.ssl.config.FIPSUtils;
import com.ibm.ws.ssl.provider.IBMJSSE2Provider;
import com.ibm.ws.ssl.provider.IBMJSSEProvider;
import com.ibm.ws.ssl.provider.SunJSSEProvider;
import com.ibm.ws.util.PlatformHelperFactory;
import java.lang.reflect.Constructor;
import java.security.PrivilegedActionException;
import java.security.Provider;
import java.security.Security;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import javax.net.ssl.SSLContext;

public class JSSEProviderFactory {
	private static TraceComponent tc = Tr.register(JSSEProviderFactory.class.getName(), "SSL");
	private static JSSEProvider cachedProvider = null;
	private static Boolean USE_FIPS_FLAG = new Boolean(false);
	private static Hashtable providerCache = new Hashtable();
	private static String IBMJSSEFIPS_PROVIDER = "IBMJSSEFIPS";
	private static String IBMJSSE_PROVIDER = "IBMJSSE";
	private static String IBMJSSE2_PROVIDER = "IBMJSSE2";
	private static String SUNJSSE_PROVIDER = "SunJSSE";
	private static String DEFAULT_PROVIDER = "IBMJSSE2";
	private static String trustManagerFactoryAlgorithm = null;
	private static String keyManagerFactoryAlgorithm = null;
	private static String defaultSSLSocketFactory = null;
	private static String defaultSSLServerSocketFactory = null;
	private static String isFipsEnabled = null;
	private static boolean fipsInitialized = false;
	private static List fipsJCEProvidersObjectList = null;
	private static List fipsJSSEProvidersObjectList = null;
	private static String providerFromProviderList = "IBMJSSE2";

	public static JSSEProvider getInstance() {
		return getInstance((String) null);
	}

	public static JSSEProvider getInstance(String contextProvider) {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "getInstance: " + contextProvider);
      }

      if (contextProvider == null) {
         contextProvider = getProviderFromProviderList();
      }

      if (contextProvider == null) {
         contextProvider = DEFAULT_PROVIDER;
      }

      if (contextProvider != null) {
         if (isFipsEnabled() || contextProvider.equalsIgnoreCase(IBMJSSEFIPS_PROVIDER)) {
            contextProvider = IBMJSSE2_PROVIDER;
         }

         cachedProvider = (JSSEProvider)providerCache.get(contextProvider);
         if (cachedProvider != null) {
            if (tc.isEntryEnabled()) {
               Tr.exit(tc, "getInstance returning cached provider: " + cachedProvider);
            }

            return cachedProvider;
         }

         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "cachedProvider is null, proceeding to determine the provider.");
         }
      }

      AccessController.doPrivileged(new 1(contextProvider));
      Provider[] providerList = Security.getProviders();

      for(int i = 0; i < providerList.length; ++i) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Provider name [" + i + "]: " + providerList[i].getName());
         }

         if (cachedProvider == null && providerList[i].getName().equalsIgnoreCase(contextProvider)) {
            if (contextProvider.equalsIgnoreCase(IBMJSSE2_PROVIDER) && validateProvider(IBMJSSE2_PROVIDER)) {
               cachedProvider = new IBMJSSE2Provider();
               providerCache.put(IBMJSSE2_PROVIDER, cachedProvider);
               providerCache.put(contextProvider, cachedProvider);
            } else if (contextProvider.equalsIgnoreCase(IBMJSSE_PROVIDER) && validateProvider(IBMJSSE_PROVIDER)) {
               cachedProvider = new IBMJSSEProvider();
               providerCache.put(IBMJSSE_PROVIDER, cachedProvider);
               providerCache.put(contextProvider, cachedProvider);
               if (isFipsEnabled()) {
                  Tr.warning(tc, "UseFIPS is enabled but the SSL Configuration is not using FIPS approved JSSE Provider. FIPS approved cryptographic algorithms will not be used in this case.");
               }
            } else if (contextProvider.equalsIgnoreCase(SUNJSSE_PROVIDER) && validateProvider(SUNJSSE_PROVIDER)) {
               cachedProvider = new SunJSSEProvider();
               providerCache.put(SUNJSSE_PROVIDER, cachedProvider);
               providerCache.put(contextProvider, cachedProvider);
               if (isFipsEnabled()) {
                  Tr.warning(tc, "UseFIPS is enabled but the SSL Configuration is not using FIPS approved JSSE Provider. FIPS approved cryptographic algorithms will not be used in this case.");
               }
            } else {
               cachedProvider = new IBMJSSE2Provider();
               providerCache.put(IBMJSSE2_PROVIDER, cachedProvider);
               providerCache.put(contextProvider, cachedProvider);
            }
         }
      }

      if (cachedProvider == null) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "JSSE Provider is not found. Use IBMJSSE2Provider");
         }

         cachedProvider = new IBMJSSE2Provider();
         providerCache.put(IBMJSSE2_PROVIDER, cachedProvider);
         providerCache.put(contextProvider, cachedProvider);
      }

      if (PlatformHelperFactory.getPlatformHelper().isZOS()) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "On Z/OS need to see if the CMS provider needs reloading.");
         }

         reloadCMSProvider();
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "getInstance provider = " + cachedProvider);
      }

      return cachedProvider;
   }

	private static void reloadCMSProvider() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "reloadCMSProvider");
		}

		boolean useCMSDefault = false;
		if (SecurityObjectLocator.getSecurityConfig() != null) {
			SecurityObjectLocator.getSecurityConfig().getPropertyBool("com.ibm.websphere.security.cms.use.default",
					false);
		}

		if (!useCMSDefault) {
			Provider cmsProvider = Security.getProvider("IBMCMSProvider");
			if (cmsProvider != null) {
				try {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "CMS provider found, reloading with V3");
					}

					Constructor c = Class.forName("com.ibm.security.cmskeystore.CMSProvider")
							.getConstructor(String.class);
					Provider provider = (Provider) c.newInstance("V3");
					Security.removeProvider("IBMCMSProvider");
					Security.addProvider(provider);
				} catch (Exception var4) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception loading provider: " + var4);
					}
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "reloadCMSProvider");
		}

	}

	private static boolean validateProvider(String provider) {
      boolean success = true;

      try {
         SSLContext var2 = null;

         try {
            String protocol = "SSL";
            if (isFipsEnabled()) {
               if (isFips140_2Enabled()) {
                  protocol = "TLS";
               } else {
                  protocol = "TLSv1.2";
               }
            }

            var2 = (SSLContext)AccessController.doPrivileged(new 2(protocol, provider));
         } catch (PrivilegedActionException var6) {
            Exception ex = var6.getException();
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Error validating provider: " + provider + ", Exception: " + ex.getMessage(), new Object[]{ex});
            }

            success = false;
         }
      } catch (Throwable var7) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Error validating provider: " + provider + ", Exception: " + var7.getMessage(), new Object[]{var7});
         }

         success = false;
      }

      return success;
   }

	public static String getDefaultSSLSocketFactory() {
      if (defaultSSLSocketFactory == null) {
         defaultSSLSocketFactory = (String)AccessController.doPrivileged(new 3());
      }

      return defaultSSLSocketFactory;
   }

	public static String getDefaultSSLServerSocketFactory() {
      if (defaultSSLServerSocketFactory == null) {
         defaultSSLServerSocketFactory = (String)AccessController.doPrivileged(new 4());
      }

      return defaultSSLServerSocketFactory;
   }

	public static String getKeyManagerFactoryAlgorithm() {
      if (keyManagerFactoryAlgorithm == null) {
         keyManagerFactoryAlgorithm = (String)AccessController.doPrivileged(new 5());
      }

      return keyManagerFactoryAlgorithm;
   }

	public static String getTrustManagerFactoryAlgorithm() {
      if (trustManagerFactoryAlgorithm == null) {
         trustManagerFactoryAlgorithm = (String)AccessController.doPrivileged(new 6());
      }

      return trustManagerFactoryAlgorithm;
   }

	public static boolean isFipsEnabled() {
		return FIPSManager.getInstance().isFIPSEnabled();
	}

	public static String getFipsLevel() {
		return FIPSManager.getInstance().getFipsLevel();
	}

	public static String getSuiteBLevel() {
		return FIPSManager.getInstance().getSuiteBLevel();
	}

	public static boolean isFips140_2Enabled() {
		return FIPSUtils.isFips140_2Enabled(isFipsEnabled(), getFipsLevel(), getSuiteBLevel());
	}

	public static void initializeIBMCMSProvider() throws Exception {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "initializeIBMCMSProvider");
      }

      if (PlatformHelperFactory.getPlatformHelper().isOS400()) {
         if (tc.isEntryEnabled()) {
            Tr.exit(tc, "initializeIBMCMSProvider (iSeries platform)");
         }

      } else {
         Provider provider = Security.getProvider("IBMCMSProvider");
         if (provider != null) {
            if (tc.isEntryEnabled()) {
               Tr.exit(tc, "initializeIBMCMSProvider (already present)");
            }

         } else {
            AccessController.doPrivileged(new 7());
            if (tc.isEntryEnabled()) {
               Tr.exit(tc, "initializeIBMCMSProvider (provider initialized)");
            }

         }
      }
   }

	public static void initializeFips() throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeFips");
		}

		if (!fipsInitialized) {
			int ibmjce_position = false;
			int ibmjcefips_position = 0;
			int sun_position = false;
			Provider[] provider_list = null;
			Provider ibmjce = null;
			Provider ibmjcefips = null;
			Provider sun = null;

			try {
				provider_list = Security.getProviders();

				int i;
				for (i = 0; i < provider_list.length; ++i) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Provider[" + i + "]: " + provider_list[i].getName());
					}

					if (provider_list[i].getName().equals("IBMJCE")) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "IBMJCE provider at position " + i);
						}

						Provider var10000 = provider_list[i];
					} else if (provider_list[i].getName().equals("IBMJCEFIPS")) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "IBMJCEFIPS provider at position " + i);
						}

						ibmjcefips_position = i;
						ibmjcefips = provider_list[i];
					} else if (provider_list[i].getName().equals("SUN")) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "SUN provider at position " + i);
						}

						sun = provider_list[i];
					}
				}

				if (ibmjcefips == null) {
					provider_list = Security.getProviders();

					try {
						ibmjcefips = (Provider) Class.forName("com.ibm.crypto.fips.provider.IBMJCEFIPS").newInstance();
						if (sun != null) {
							insertProviderAt(sun, 1);
							insertProviderAt(ibmjcefips, 2);
						} else {
							insertProviderAt(ibmjcefips, 1);
						}
					} catch (Exception var8) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Exception loading provider: com.ibm.crypto.fips.provider.IBMJCEFIPS");
						}
					}
				} else if (ibmjcefips != null && ibmjcefips_position != 0) {
					provider_list = Security.getProviders();
					if (sun != null) {
						insertProviderAt(sun, 1);
						insertProviderAt(ibmjcefips, 2);
					} else {
						insertProviderAt(ibmjcefips, 1);
					}
				}

				provider_list = Security.getProviders();

				for (i = 0; i < provider_list.length; ++i) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Provider[" + i + "]: " + provider_list[i].getName() + ", info: "
								+ provider_list[i].getInfo());
					}
				}

				fipsInitialized = true;
			} catch (Exception var9) {
				Tr.warning(tc, "security.addprovider.error", new Object[]{var9});
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception caught adding IBMJCEFIPS provider.", new Object[]{var9});
				}

				throw var9;
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initializeFips");
		}

	}

	public static void insertProviderAt(Provider newProvider, int slot) {
		Provider[] provider_list = Security.getProviders();
		Provider[] newList = null;
		if (provider_list != null && provider_list.length > 0) {
			newList = new Provider[provider_list.length + 2];
			newList[slot] = newProvider;
		}

		int newListIndex = 1;

		int i;
		Provider currentProvider;
		for (i = 0; i < provider_list.length; ++i) {
			currentProvider = provider_list[i];
			if (currentProvider != null && currentProvider.getName() != newProvider.getName()) {
				while (newList[newListIndex] != null) {
					++newListIndex;
				}

				newList[newListIndex] = currentProvider;
				++newListIndex;
			}
		}

		removeAllProviders();
		provider_list = Security.getProviders();

		for (i = 0; i < newList.length; ++i) {
			currentProvider = newList[i];
			if (currentProvider != null) {
				int position = Security.insertProviderAt(currentProvider, i + 1);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, currentProvider.getName() + " provider added at position " + position);
				}
			}
		}

	}

	public static void removeAllProviders() {
		Provider[] provider_list = Security.getProviders();

		for (int i = 0; i < provider_list.length; ++i) {
			if (provider_list[i] != null) {
				String name = provider_list[i].getName();
				if (name != null) {
					Security.removeProvider(name);
				}
			}
		}

	}

	public static List fipsJCEProviders() {
		String[] fipsJCEProvidersList = new String[]{"IBMJCEFIPS"};
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "fipsJCEProviders");
		}

		if (fipsJCEProvidersObjectList == null) {
			fipsJCEProvidersObjectList = new ArrayList(fipsJCEProvidersList.length);
			if (isFips140_2Enabled()) {
				for (int i = 0; i < fipsJCEProvidersList.length; ++i) {
					fipsJCEProvidersObjectList.add(fipsJCEProvidersList[i]);
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "fipsJCEProviders: " + fipsJCEProvidersObjectList);
		}

		return fipsJCEProvidersObjectList;
	}

	private static String getProviderFromProviderList() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProviderFromProviderList");
		}

		Provider[] providerList = Security.getProviders();

		for (int i = 0; i < providerList.length; ++i) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Provider name [" + i + "]: " + providerList[i].getName());
			}

			if (providerList[i].getName().equalsIgnoreCase(IBMJSSE2_PROVIDER)) {
				providerFromProviderList = IBMJSSE2_PROVIDER;
				break;
			}

			if (providerList[i].getName().equalsIgnoreCase(IBMJSSE_PROVIDER)) {
				providerFromProviderList = IBMJSSE_PROVIDER;
				break;
			}

			if (providerList[i].getName().equalsIgnoreCase(SUNJSSE_PROVIDER)) {
				providerFromProviderList = SUNJSSE_PROVIDER;
				break;
			}
		}

		if (providerFromProviderList == null) {
			providerFromProviderList = IBMJSSE2_PROVIDER;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getProviderFromProviderList -> " + providerFromProviderList);
		}

		return providerFromProviderList;
	}
}