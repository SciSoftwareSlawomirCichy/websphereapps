package com.ibm.ws.wim.configmodel.util;

import com.ibm.ws.wim.configmodel.AttributeConfigurationType;
import com.ibm.ws.wim.configmodel.AttributeGroupType;
import com.ibm.ws.wim.configmodel.AttributeType;
import com.ibm.ws.wim.configmodel.AttributesCacheType;
import com.ibm.ws.wim.configmodel.AuthorizationType;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.CacheConfigurationType;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.ContextPoolType;
import com.ibm.ws.wim.configmodel.CustomPropertiesType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.configmodel.DocumentRoot;
import com.ibm.ws.wim.configmodel.DynamicMemberAttributesType;
import com.ibm.ws.wim.configmodel.DynamicModelType;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import com.ibm.ws.wim.configmodel.EnvironmentPropertiesType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.GroupConfigurationType;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.LdapEntityTypesType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.MemberAttributesType;
import com.ibm.ws.wim.configmodel.MembershipAttributeType;
import com.ibm.ws.wim.configmodel.ModificationSubscriber;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import com.ibm.ws.wim.configmodel.NotificationSubscriber;
import com.ibm.ws.wim.configmodel.NotificationSubscriberList;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.PostExit;
import com.ibm.ws.wim.configmodel.PreExit;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.PropertiesNotSupportedType;
import com.ibm.ws.wim.configmodel.PropertyExtensionRepositoryType;
import com.ibm.ws.wim.configmodel.RdnAttributesType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmDefaultParentType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.configmodel.SPIBridgeRepositoryType;
import com.ibm.ws.wim.configmodel.SearchResultsCacheType;
import com.ibm.ws.wim.configmodel.StaticModelType;
import com.ibm.ws.wim.configmodel.SubscriberType;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import com.ibm.ws.wim.configmodel.TopicSubscriber;
import com.ibm.ws.wim.configmodel.TopicSubscriberList;
import com.ibm.ws.wim.configmodel.UserRegistryInfoMappingType;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EValidator.PatternMatcher;
import org.eclipse.emf.ecore.util.EObjectValidator;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;
import org.eclipse.emf.ecore.xml.type.util.XMLTypeUtil;
import org.eclipse.emf.ecore.xml.type.util.XMLTypeValidator;

public class ConfigmodelValidator extends EObjectValidator {
	public static final ConfigmodelValidator INSTANCE = new ConfigmodelValidator();
	public static final String DIAGNOSTIC_SOURCE = "com.ibm.ws.wim.configmodel";
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;
	protected XMLTypeValidator xmlTypeValidator;
	public static final int CACHE_SIZE_LIMIT_TYPE__MIN__VALUE = 0;
	public static final int CACHE_SIZE_TYPE__MIN__VALUE = 100;
	public static final int CACHE_TIME_OUT_TYPE__MIN__VALUE = 0;
	public static final PatternMatcher[][] DN_TYPE__PATTERN__VALUES = new PatternMatcher[][]{
			{XMLTypeUtil.createPatternMatcher("(((.+)(=)(.+))(,(.+)(=)(.+))*)")}};
	public static final int INIT_POOL_SIZE_TYPE__MIN__VALUE = 1;
	public static final int INIT_POOL_SIZE_TYPE__MAX__VALUE = 50;
	public static final int MAX_POOL_SIZE_TYPE__MIN__VALUE = 0;
	public static final int POOL_TIME_OUT_TYPE__MIN__VALUE = 0;
	public static final int POOL_WAIT_TIME_TYPE__MIN__VALUE = 0;
	public static final int PREF_POOL_SIZE_TYPE__MIN__VALUE = 0;
	public static final int PREF_POOL_SIZE_TYPE__MAX__VALUE = 100;

	public ConfigmodelValidator() {
		this.xmlTypeValidator = XMLTypeValidator.INSTANCE;
	}

	protected EPackage getEPackage() {
		return ConfigmodelPackage.eINSTANCE;
	}

	protected boolean validate(int var1, Object var2, DiagnosticChain var3, Map var4) {
		switch (var1) {
			case 0 :
				return this.validateAttributeConfigurationType((AttributeConfigurationType) var2, var3, var4);
			case 1 :
				return this.validateAttributeGroupType((AttributeGroupType) var2, var3, var4);
			case 2 :
				return this.validateAttributesCacheType((AttributesCacheType) var2, var3, var4);
			case 3 :
				return this.validateAttributeType((AttributeType) var2, var3, var4);
			case 4 :
				return this.validateAuthorizationType((AuthorizationType) var2, var3, var4);
			case 5 :
				return this.validateBaseEntriesType((BaseEntriesType) var2, var3, var4);
			case 6 :
				return this.validateCacheConfigurationType((CacheConfigurationType) var2, var3, var4);
			case 7 :
				return this.validateConfigurationProviderType((ConfigurationProviderType) var2, var3, var4);
			case 8 :
				return this.validateConnectionsType((ConnectionsType) var2, var3, var4);
			case 9 :
				return this.validateContextPoolType((ContextPoolType) var2, var3, var4);
			case 10 :
				return this.validateCustomPropertiesType((CustomPropertiesType) var2, var3, var4);
			case 11 :
				return this.validateDatabaseRepositoryType((DatabaseRepositoryType) var2, var3, var4);
			case 12 :
				return this.validateDocumentRoot((DocumentRoot) var2, var3, var4);
			case 13 :
				return this.validateDynamicMemberAttributesType((DynamicMemberAttributesType) var2, var3, var4);
			case 14 :
				return this.validateDynamicModelType((DynamicModelType) var2, var3, var4);
			case 15 :
				return this.validateEntryMappingRepositoryType((EntryMappingRepositoryType) var2, var3, var4);
			case 16 :
				return this.validateEnvironmentPropertiesType((EnvironmentPropertiesType) var2, var3, var4);
			case 17 :
				return this.validateFileRepositoryType((FileRepositoryType) var2, var3, var4);
			case 18 :
				return this.validateGroupConfigurationType((GroupConfigurationType) var2, var3, var4);
			case 19 :
				return this.validateInlineExit((InlineExit) var2, var3, var4);
			case 20 :
				return this.validateLdapEntityTypesType((LdapEntityTypesType) var2, var3, var4);
			case 21 :
				return this.validateLdapRepositoryType((LdapRepositoryType) var2, var3, var4);
			case 22 :
				return this.validateLdapServerConfigurationType((LdapServerConfigurationType) var2, var3, var4);
			case 23 :
				return this.validateLdapServersType((LdapServersType) var2, var3, var4);
			case 24 :
				return this.validateMemberAttributesType((MemberAttributesType) var2, var3, var4);
			case 25 :
				return this.validateMembershipAttributeType((MembershipAttributeType) var2, var3, var4);
			case 26 :
				return this.validateModificationSubscriber((ModificationSubscriber) var2, var3, var4);
			case 27 :
				return this.validateModificationSubscriberList((ModificationSubscriberList) var2, var3, var4);
			case 28 :
				return this.validateNotificationSubscriber((NotificationSubscriber) var2, var3, var4);
			case 29 :
				return this.validateNotificationSubscriberList((NotificationSubscriberList) var2, var3, var4);
			case 30 :
				return this.validateParticipatingBaseEntriesType((ParticipatingBaseEntriesType) var2, var3, var4);
			case 31 :
				return this.validatePluginManagerConfigurationType((PluginManagerConfigurationType) var2, var3, var4);
			case 32 :
				return this.validatePostExit((PostExit) var2, var3, var4);
			case 33 :
				return this.validatePreExit((PreExit) var2, var3, var4);
			case 34 :
				return this.validateProfileRepositoryType((ProfileRepositoryType) var2, var3, var4);
			case 35 :
				return this.validatePropertiesNotSupportedType((PropertiesNotSupportedType) var2, var3, var4);
			case 36 :
				return this.validatePropertyExtensionRepositoryType((PropertyExtensionRepositoryType) var2, var3, var4);
			case 37 :
				return this.validateRdnAttributesType((RdnAttributesType) var2, var3, var4);
			case 38 :
				return this.validateRealmConfigurationType((RealmConfigurationType) var2, var3, var4);
			case 39 :
				return this.validateRealmDefaultParentType((RealmDefaultParentType) var2, var3, var4);
			case 40 :
				return this.validateRealmType((RealmType) var2, var3, var4);
			case 41 :
				return this.validateRepositoryType((RepositoryType) var2, var3, var4);
			case 42 :
				return this.validateSearchResultsCacheType((SearchResultsCacheType) var2, var3, var4);
			case 43 :
				return this.validateSPIBridgeRepositoryType((SPIBridgeRepositoryType) var2, var3, var4);
			case 44 :
				return this.validateStaticModelType((StaticModelType) var2, var3, var4);
			case 45 :
				return this.validateSupportedEntityTypesType((SupportedEntityTypesType) var2, var3, var4);
			case 46 :
				return this.validateTopicEmitter((TopicEmitter) var2, var3, var4);
			case 47 :
				return this.validateTopicRegistrationList((TopicRegistrationList) var2, var3, var4);
			case 48 :
				return this.validateTopicSubscriber((TopicSubscriber) var2, var3, var4);
			case 49 :
				return this.validateTopicSubscriberList((TopicSubscriberList) var2, var3, var4);
			case 50 :
				return this.validateUserRegistryInfoMappingType((UserRegistryInfoMappingType) var2, var3, var4);
			case 51 :
				return this.validateSubscriberType(var2, var3, var4);
			case 52 :
				return this.validateCacheSizeLimitType((Integer) var2, var3, var4);
			case 53 :
				return this.validateCacheSizeLimitTypeObject((Integer) var2, var3, var4);
			case 54 :
				return this.validateCacheSizeType((Integer) var2, var3, var4);
			case 55 :
				return this.validateCacheSizeTypeObject((Integer) var2, var3, var4);
			case 56 :
				return this.validateCacheTimeOutType((Integer) var2, var3, var4);
			case 57 :
				return this.validateCacheTimeOutTypeObject((Integer) var2, var3, var4);
			case 58 :
				return this.validateDNType((String) var2, var3, var4);
			case 59 :
				return this.validateInitPoolSizeType((Integer) var2, var3, var4);
			case 60 :
				return this.validateInitPoolSizeTypeObject((Integer) var2, var3, var4);
			case 61 :
				return this.validateMaxPoolSizeType((Integer) var2, var3, var4);
			case 62 :
				return this.validateMaxPoolSizeTypeObject((Integer) var2, var3, var4);
			case 63 :
				return this.validatePoolTimeOutType((Integer) var2, var3, var4);
			case 64 :
				return this.validatePoolTimeOutTypeObject((Integer) var2, var3, var4);
			case 65 :
				return this.validatePoolWaitTimeType((Integer) var2, var3, var4);
			case 66 :
				return this.validatePoolWaitTimeTypeObject((Integer) var2, var3, var4);
			case 67 :
				return this.validatePrefPoolSizeType((Integer) var2, var3, var4);
			case 68 :
				return this.validatePrefPoolSizeTypeObject((Integer) var2, var3, var4);
			case 69 :
				return this.validateRealmListType((List) var2, var3, var4);
			case 70 :
				return this.validateRealmListType1((List) var2, var3, var4);
			case 71 :
				return this.validateSubscriberTypeObject((SubscriberType) var2, var3, var4);
			default :
				return true;
		}
	}

	public boolean validateAttributeConfigurationType(AttributeConfigurationType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateAttributeGroupType(AttributeGroupType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateAttributesCacheType(AttributesCacheType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateAttributeType(AttributeType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateAuthorizationType(AuthorizationType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateBaseEntriesType(BaseEntriesType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateCacheConfigurationType(CacheConfigurationType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateConfigurationProviderType(ConfigurationProviderType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateConnectionsType(ConnectionsType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateContextPoolType(ContextPoolType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateCustomPropertiesType(CustomPropertiesType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateDatabaseRepositoryType(DatabaseRepositoryType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateDocumentRoot(DocumentRoot var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateDynamicMemberAttributesType(DynamicMemberAttributesType var1, DiagnosticChain var2,
			Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateDynamicModelType(DynamicModelType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateEntryMappingRepositoryType(EntryMappingRepositoryType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateEnvironmentPropertiesType(EnvironmentPropertiesType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateFileRepositoryType(FileRepositoryType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateGroupConfigurationType(GroupConfigurationType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateInlineExit(InlineExit var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateLdapEntityTypesType(LdapEntityTypesType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateLdapRepositoryType(LdapRepositoryType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateLdapServerConfigurationType(LdapServerConfigurationType var1, DiagnosticChain var2,
			Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateLdapServersType(LdapServersType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateMemberAttributesType(MemberAttributesType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateMembershipAttributeType(MembershipAttributeType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateModificationSubscriber(ModificationSubscriber var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateModificationSubscriberList(ModificationSubscriberList var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateNotificationSubscriber(NotificationSubscriber var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateNotificationSubscriberList(NotificationSubscriberList var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateParticipatingBaseEntriesType(ParticipatingBaseEntriesType var1, DiagnosticChain var2,
			Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validatePluginManagerConfigurationType(PluginManagerConfigurationType var1, DiagnosticChain var2,
			Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validatePostExit(PostExit var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validatePreExit(PreExit var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateProfileRepositoryType(ProfileRepositoryType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validatePropertiesNotSupportedType(PropertiesNotSupportedType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validatePropertyExtensionRepositoryType(PropertyExtensionRepositoryType var1, DiagnosticChain var2,
			Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateRdnAttributesType(RdnAttributesType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateRealmConfigurationType(RealmConfigurationType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateRealmDefaultParentType(RealmDefaultParentType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateRealmType(RealmType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateRepositoryType(RepositoryType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateSearchResultsCacheType(SearchResultsCacheType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateSPIBridgeRepositoryType(SPIBridgeRepositoryType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateStaticModelType(StaticModelType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateSupportedEntityTypesType(SupportedEntityTypesType var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateTopicEmitter(TopicEmitter var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateTopicRegistrationList(TopicRegistrationList var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateTopicSubscriber(TopicSubscriber var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateTopicSubscriberList(TopicSubscriberList var1, DiagnosticChain var2, Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateUserRegistryInfoMappingType(UserRegistryInfoMappingType var1, DiagnosticChain var2,
			Map var3) {
		return this.validate_EveryDefaultConstraint((EObject) var1, var2, var3);
	}

	public boolean validateSubscriberType(Object var1, DiagnosticChain var2, Map var3) {
		return true;
	}

	public boolean validateCacheSizeLimitType(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateCacheSizeLimitType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validateCacheSizeLimitType_Min(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 >= 0;
		if (!var4 && var2 != null) {
			this.reportMinViolation(ConfigmodelPackage.eINSTANCE.getCacheSizeLimitType(), new Integer(var1),
					new Integer(0), true, var2, var3);
		}

		return var4;
	}

	public boolean validateCacheSizeLimitTypeObject(Integer var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateCacheSizeLimitType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validateCacheSizeType(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateCacheSizeType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validateCacheSizeType_Min(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 >= 100;
		if (!var4 && var2 != null) {
			this.reportMinViolation(ConfigmodelPackage.eINSTANCE.getCacheSizeType(), new Integer(var1),
					new Integer(100), true, var2, var3);
		}

		return var4;
	}

	public boolean validateCacheSizeTypeObject(Integer var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateCacheSizeType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validateCacheTimeOutType(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateCacheTimeOutType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validateCacheTimeOutType_Min(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 >= 0;
		if (!var4 && var2 != null) {
			this.reportMinViolation(ConfigmodelPackage.eINSTANCE.getCacheTimeOutType(), new Integer(var1),
					new Integer(0), true, var2, var3);
		}

		return var4;
	}

	public boolean validateCacheTimeOutTypeObject(Integer var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateCacheTimeOutType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validateDNType(String var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateDNType_Pattern(var1, var2, var3);
		return var4;
	}

	public boolean validateDNType_Pattern(String var1, DiagnosticChain var2, Map var3) {
		return this.validatePattern(ConfigmodelPackage.eINSTANCE.getDNType(), var1, DN_TYPE__PATTERN__VALUES, var2,
				var3);
	}

	public boolean validateInitPoolSizeType(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateInitPoolSizeType_Min(var1, var2, var3);
		if (var4 || var2 != null) {
			var4 &= this.validateInitPoolSizeType_Max(var1, var2, var3);
		}

		return var4;
	}

	public boolean validateInitPoolSizeType_Min(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 >= 1;
		if (!var4 && var2 != null) {
			this.reportMinViolation(ConfigmodelPackage.eINSTANCE.getInitPoolSizeType(), new Integer(var1),
					new Integer(1), true, var2, var3);
		}

		return var4;
	}

	public boolean validateInitPoolSizeType_Max(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 <= 50;
		if (!var4 && var2 != null) {
			this.reportMaxViolation(ConfigmodelPackage.eINSTANCE.getInitPoolSizeType(), new Integer(var1),
					new Integer(50), true, var2, var3);
		}

		return var4;
	}

	public boolean validateInitPoolSizeTypeObject(Integer var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateInitPoolSizeType_Min(var1, var2, var3);
		if (var4 || var2 != null) {
			var4 &= this.validateInitPoolSizeType_Max(var1, var2, var3);
		}

		return var4;
	}

	public boolean validateMaxPoolSizeType(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateMaxPoolSizeType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validateMaxPoolSizeType_Min(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 >= 0;
		if (!var4 && var2 != null) {
			this.reportMinViolation(ConfigmodelPackage.eINSTANCE.getMaxPoolSizeType(), new Integer(var1),
					new Integer(0), true, var2, var3);
		}

		return var4;
	}

	public boolean validateMaxPoolSizeTypeObject(Integer var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateMaxPoolSizeType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validatePoolTimeOutType(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validatePoolTimeOutType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validatePoolTimeOutType_Min(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 >= 0;
		if (!var4 && var2 != null) {
			this.reportMinViolation(ConfigmodelPackage.eINSTANCE.getPoolTimeOutType(), new Integer(var1),
					new Integer(0), true, var2, var3);
		}

		return var4;
	}

	public boolean validatePoolTimeOutTypeObject(Integer var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validatePoolTimeOutType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validatePoolWaitTimeType(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validatePoolWaitTimeType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validatePoolWaitTimeType_Min(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 >= 0;
		if (!var4 && var2 != null) {
			this.reportMinViolation(ConfigmodelPackage.eINSTANCE.getPoolWaitTimeType(), new Integer(var1),
					new Integer(0), true, var2, var3);
		}

		return var4;
	}

	public boolean validatePoolWaitTimeTypeObject(Integer var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validatePoolWaitTimeType_Min(var1, var2, var3);
		return var4;
	}

	public boolean validatePrefPoolSizeType(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validatePrefPoolSizeType_Min(var1, var2, var3);
		if (var4 || var2 != null) {
			var4 &= this.validatePrefPoolSizeType_Max(var1, var2, var3);
		}

		return var4;
	}

	public boolean validatePrefPoolSizeType_Min(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 >= 0;
		if (!var4 && var2 != null) {
			this.reportMinViolation(ConfigmodelPackage.eINSTANCE.getPrefPoolSizeType(), new Integer(var1),
					new Integer(0), true, var2, var3);
		}

		return var4;
	}

	public boolean validatePrefPoolSizeType_Max(int var1, DiagnosticChain var2, Map var3) {
		boolean var4 = var1 <= 100;
		if (!var4 && var2 != null) {
			this.reportMaxViolation(ConfigmodelPackage.eINSTANCE.getPrefPoolSizeType(), new Integer(var1),
					new Integer(100), true, var2, var3);
		}

		return var4;
	}

	public boolean validatePrefPoolSizeTypeObject(Integer var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validatePrefPoolSizeType_Min(var1, var2, var3);
		if (var4 || var2 != null) {
			var4 &= this.validatePrefPoolSizeType_Max(var1, var2, var3);
		}

		return var4;
	}

	public boolean validateRealmListType(List var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateRealmListType_ItemType(var1, var2, var3);
		return var4;
	}

	public boolean validateRealmListType_ItemType(List var1, DiagnosticChain var2, Map var3) {
		boolean var4 = true;
		Iterator var5 = var1.iterator();

		while (var5.hasNext() && (var4 || var2 != null)) {
			Object var6 = var5.next();
			if (XMLTypePackage.eINSTANCE.getString().isInstance(var6)) {
				var4 &= this.xmlTypeValidator.validateString((String) var6, var2, var3);
			} else {
				var4 = false;
				this.reportDataValueTypeViolation(XMLTypePackage.eINSTANCE.getString(), var6, var2, var3);
			}
		}

		return var4;
	}

	public boolean validateRealmListType1(List var1, DiagnosticChain var2, Map var3) {
		boolean var4 = this.validateRealmListType1_ItemType(var1, var2, var3);
		return var4;
	}

	public boolean validateRealmListType1_ItemType(List var1, DiagnosticChain var2, Map var3) {
		boolean var4 = true;
		Iterator var5 = var1.iterator();

		while (var5.hasNext() && (var4 || var2 != null)) {
			Object var6 = var5.next();
			if (XMLTypePackage.eINSTANCE.getString().isInstance(var6)) {
				var4 &= this.xmlTypeValidator.validateString((String) var6, var2, var3);
			} else {
				var4 = false;
				this.reportDataValueTypeViolation(XMLTypePackage.eINSTANCE.getString(), var6, var2, var3);
			}
		}

		return var4;
	}

	public boolean validateSubscriberTypeObject(SubscriberType var1, DiagnosticChain var2, Map var3) {
		return true;
	}
}