package com.ibm.icu.text;

import com.ibm.icu.impl.ICUCache;
import com.ibm.icu.impl.ICUResourceBundle;
import com.ibm.icu.impl.SimpleCache;
import com.ibm.icu.text.DateIntervalFormat.BestMatchInfo;
import com.ibm.icu.text.DateIntervalInfo.PatternInfo;
import com.ibm.icu.util.Calendar;
import com.ibm.icu.util.Freezable;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.MissingResourceException;

public class DateIntervalInfo implements Cloneable, Freezable<DateIntervalInfo>, Serializable {
	static final int currentSerialVersion = 1;
	static final String[] CALENDAR_FIELD_TO_PATTERN_LETTER = new String[]{"G", "y", "M", "w", "W", "d", "D", "E", "F",
			"a", "h", "H", "m"};
	private static final long serialVersionUID = 1L;
	private static final int MINIMUM_SUPPORTED_CALENDAR_FIELD = 12;
	private static String FALLBACK_STRING = "fallback";
	private static String LATEST_FIRST_PREFIX = "latestFirst:";
	private static String EARLIEST_FIRST_PREFIX = "earliestFirst:";
	private static final ICUCache<String, DateIntervalInfo> DIICACHE = new SimpleCache();
	private String fFallbackIntervalPattern;
	private boolean fFirstDateInPtnIsLaterDate = false;
	private Map<String, Map<String, PatternInfo>> fIntervalPatterns = null;
	private transient boolean frozen = false;

	public DateIntervalInfo() {
		this.fIntervalPatterns = new HashMap();
		this.fFallbackIntervalPattern = "{0} – {1}";
	}

	public DateIntervalInfo(ULocale locale) {
		this.initializeData(locale);
	}

	private void initializeData(ULocale locale) {
		String key = locale.toString();
		DateIntervalInfo dii = (DateIntervalInfo) DIICACHE.get(key);
		if (dii == null) {
			this.setup(locale);
			dii = (DateIntervalInfo) this.clone();
			DIICACHE.put(key, dii);
		} else {
			this.initializeData(dii);
		}

	}

	private void initializeData(DateIntervalInfo dii) {
		this.fFallbackIntervalPattern = dii.fFallbackIntervalPattern;
		this.fFirstDateInPtnIsLaterDate = dii.fFirstDateInPtnIsLaterDate;
		this.fIntervalPatterns = dii.fIntervalPatterns;
	}

	private void setup(ULocale locale) {
		int DEFAULT_HASH_SIZE = 19;
		this.fIntervalPatterns = new HashMap(DEFAULT_HASH_SIZE);
		this.fFallbackIntervalPattern = "{0} – {1}";
		HashSet skeletonSet = new HashSet();

		try {
			ULocale parentLocale = locale;
			String calendarTypeToUse = locale.getKeywordValue("calendar");
			if (calendarTypeToUse == null) {
				String[] preferredCalendarTypes = Calendar.getKeywordValuesForLocale("calendar", locale, true);
				calendarTypeToUse = preferredCalendarTypes[0];
			}

			if (calendarTypeToUse == null) {
				calendarTypeToUse = "gregorian";
			}

			do {
				String name = parentLocale.getName();
				if (name.length() == 0) {
					break;
				}

				ICUResourceBundle rb = (ICUResourceBundle) UResourceBundle
						.getBundleInstance("com/ibm/icu/impl/data/icudt44b", locale);
				rb = rb.getWithFallback("calendar");
				ICUResourceBundle calTypeBundle = rb.getWithFallback(calendarTypeToUse);
				ICUResourceBundle itvDtPtnResource = calTypeBundle.getWithFallback("intervalFormats");
				String fallback = itvDtPtnResource.getStringWithFallback(FALLBACK_STRING);
				this.setFallbackIntervalPattern(fallback);
				int size = itvDtPtnResource.getSize();

				for (int index = 0; index < size; ++index) {
					String skeleton = itvDtPtnResource.get(index).getKey();
					if (!skeletonSet.contains(skeleton)) {
						skeletonSet.add(skeleton);
						if (skeleton.compareTo(FALLBACK_STRING) != 0) {
							ICUResourceBundle intervalPatterns = itvDtPtnResource.getWithFallback(skeleton);
							int ptnNum = intervalPatterns.getSize();

							for (int ptnIndex = 0; ptnIndex < ptnNum; ++ptnIndex) {
								String key = intervalPatterns.get(ptnIndex).getKey();
								String pattern = intervalPatterns.get(ptnIndex).getString();
								int calendarField = -1;
								if (key.compareTo(CALENDAR_FIELD_TO_PATTERN_LETTER[1]) == 0) {
									calendarField = 1;
								} else if (key.compareTo(CALENDAR_FIELD_TO_PATTERN_LETTER[2]) == 0) {
									calendarField = 2;
								} else if (key.compareTo(CALENDAR_FIELD_TO_PATTERN_LETTER[5]) == 0) {
									calendarField = 5;
								} else if (key.compareTo(CALENDAR_FIELD_TO_PATTERN_LETTER[9]) == 0) {
									calendarField = 9;
								} else if (key.compareTo(CALENDAR_FIELD_TO_PATTERN_LETTER[10]) == 0) {
									calendarField = 10;
								} else if (key.compareTo(CALENDAR_FIELD_TO_PATTERN_LETTER[12]) == 0) {
									calendarField = 12;
								}

								if (calendarField != -1) {
									this.setIntervalPatternInternally(skeleton, key, pattern);
								}
							}
						}
					}
				}

				parentLocale = parentLocale.getFallback();
			} while (parentLocale != null && !parentLocale.equals(ULocale.ROOT));
		} catch (MissingResourceException var20) {
			;
		}

	}

	private static int splitPatternInto2Part(String intervalPattern) {
		boolean inQuote = false;
		char prevCh = 0;
		int count = 0;
		int[] patternRepeated = new int[58];
		int PATTERN_CHAR_BASE = 65;
		boolean foundRepetition = false;

		int i;
		for (i = 0; i < intervalPattern.length(); ++i) {
			char ch = intervalPattern.charAt(i);
			if (ch != prevCh && count > 0) {
				int repeated = patternRepeated[prevCh - PATTERN_CHAR_BASE];
				if (repeated != 0) {
					foundRepetition = true;
					break;
				}

				patternRepeated[prevCh - PATTERN_CHAR_BASE] = 1;
				count = 0;
			}

			if (ch == '\'') {
				if (i + 1 < intervalPattern.length() && intervalPattern.charAt(i + 1) == '\'') {
					++i;
				} else {
					inQuote = !inQuote;
				}
			} else if (!inQuote && (ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z')) {
				prevCh = ch;
				++count;
			}
		}

		if (count > 0 && !foundRepetition && patternRepeated[prevCh - PATTERN_CHAR_BASE] == 0) {
			count = 0;
		}

		return i - count;
	}

	public void setIntervalPattern(String skeleton, int lrgDiffCalUnit, String intervalPattern) {
		if (this.frozen) {
			throw new UnsupportedOperationException("no modification is allowed after DII is frozen");
		} else if (lrgDiffCalUnit > 12) {
			throw new IllegalArgumentException("calendar field is larger than MINIMUM_SUPPORTED_CALENDAR_FIELD");
		} else {
			PatternInfo ptnInfo = this.setIntervalPatternInternally(skeleton,
					CALENDAR_FIELD_TO_PATTERN_LETTER[lrgDiffCalUnit], intervalPattern);
			if (lrgDiffCalUnit == 11) {
				this.setIntervalPattern(skeleton, CALENDAR_FIELD_TO_PATTERN_LETTER[9], ptnInfo);
				this.setIntervalPattern(skeleton, CALENDAR_FIELD_TO_PATTERN_LETTER[10], ptnInfo);
			} else if (lrgDiffCalUnit == 5 || lrgDiffCalUnit == 7) {
				this.setIntervalPattern(skeleton, CALENDAR_FIELD_TO_PATTERN_LETTER[5], ptnInfo);
			}

		}
	}

	private PatternInfo setIntervalPatternInternally(String skeleton, String lrgDiffCalUnit, String intervalPattern) {
		Map<String, PatternInfo> patternsOfOneSkeleton = (Map) this.fIntervalPatterns.get(skeleton);
		boolean emptyHash = false;
		if (patternsOfOneSkeleton == null) {
			patternsOfOneSkeleton = new HashMap();
			emptyHash = true;
		}

		boolean order = this.fFirstDateInPtnIsLaterDate;
		int earliestFirstLength;
		if (intervalPattern.startsWith(LATEST_FIRST_PREFIX)) {
			order = true;
			earliestFirstLength = LATEST_FIRST_PREFIX.length();
			intervalPattern = intervalPattern.substring(earliestFirstLength, intervalPattern.length());
		} else if (intervalPattern.startsWith(EARLIEST_FIRST_PREFIX)) {
			order = false;
			earliestFirstLength = EARLIEST_FIRST_PREFIX.length();
			intervalPattern = intervalPattern.substring(earliestFirstLength, intervalPattern.length());
		}

		PatternInfo itvPtnInfo = genPatternInfo(intervalPattern, order);
		((Map) patternsOfOneSkeleton).put(lrgDiffCalUnit, itvPtnInfo);
		if (emptyHash) {
			this.fIntervalPatterns.put(skeleton, patternsOfOneSkeleton);
		}

		return itvPtnInfo;
	}

	private void setIntervalPattern(String skeleton, String lrgDiffCalUnit, PatternInfo ptnInfo) {
		Map<String, PatternInfo> patternsOfOneSkeleton = (Map) this.fIntervalPatterns.get(skeleton);
		patternsOfOneSkeleton.put(lrgDiffCalUnit, ptnInfo);
	}

	static PatternInfo genPatternInfo(String intervalPattern, boolean laterDateFirst) {
		int splitPoint = splitPatternInto2Part(intervalPattern);
		String firstPart = intervalPattern.substring(0, splitPoint);
		String secondPart = null;
		if (splitPoint < intervalPattern.length()) {
			secondPart = intervalPattern.substring(splitPoint, intervalPattern.length());
		}

		return new PatternInfo(firstPart, secondPart, laterDateFirst);
	}

	public PatternInfo getIntervalPattern(String skeleton, int field) {
		if (field > 12) {
			throw new IllegalArgumentException("no support for field less than MINUTE");
		} else {
			Map<String, PatternInfo> patternsOfOneSkeleton = (Map) this.fIntervalPatterns.get(skeleton);
			if (patternsOfOneSkeleton != null) {
				PatternInfo intervalPattern = (PatternInfo) patternsOfOneSkeleton
						.get(CALENDAR_FIELD_TO_PATTERN_LETTER[field]);
				if (intervalPattern != null) {
					return intervalPattern;
				}
			}

			return null;
		}
	}

	public String getFallbackIntervalPattern() {
		return this.fFallbackIntervalPattern;
	}

	public void setFallbackIntervalPattern(String fallbackPattern) {
		if (this.frozen) {
			throw new UnsupportedOperationException("no modification is allowed after DII is frozen");
		} else {
			int firstPatternIndex = fallbackPattern.indexOf("{0}");
			int secondPatternIndex = fallbackPattern.indexOf("{1}");
			if (firstPatternIndex != -1 && secondPatternIndex != -1) {
				if (firstPatternIndex > secondPatternIndex) {
					this.fFirstDateInPtnIsLaterDate = true;
				}

				this.fFallbackIntervalPattern = fallbackPattern;
			} else {
				throw new IllegalArgumentException("no pattern {0} or pattern {1} in fallbackPattern");
			}
		}
	}

	public boolean getDefaultOrder() {
		return this.fFirstDateInPtnIsLaterDate;
	}

	public Object clone() {
		return this.frozen ? this : this.cloneUnfrozenDII();
	}

	private Object cloneUnfrozenDII() {
		try {
			DateIntervalInfo other = (DateIntervalInfo) super.clone();
			other.fFallbackIntervalPattern = this.fFallbackIntervalPattern;
			other.fFirstDateInPtnIsLaterDate = this.fFirstDateInPtnIsLaterDate;
			other.fIntervalPatterns = new HashMap();
			Iterator i$ = this.fIntervalPatterns.keySet().iterator();

			while (i$.hasNext()) {
				String skeleton = (String) i$.next();
				Map<String, PatternInfo> patternsOfOneSkeleton = (Map) this.fIntervalPatterns.get(skeleton);
				Map<String, PatternInfo> oneSetPtn = new HashMap();
				Iterator i$ = patternsOfOneSkeleton.keySet().iterator();

				while (i$.hasNext()) {
					String calField = (String) i$.next();
					PatternInfo value = (PatternInfo) patternsOfOneSkeleton.get(calField);
					oneSetPtn.put(calField, value);
				}

				other.fIntervalPatterns.put(skeleton, oneSetPtn);
			}

			other.frozen = false;
			return other;
		} catch (CloneNotSupportedException var9) {
			throw new IllegalStateException("clone is not supported");
		}
	}

	public boolean isFrozen() {
		return this.frozen;
	}

	public DateIntervalInfo freeze() {
		this.frozen = true;
		return this;
	}

	public DateIntervalInfo cloneAsThawed() {
		DateIntervalInfo result = (DateIntervalInfo) ((DateIntervalInfo) this.cloneUnfrozenDII());
		return result;
	}

	static void parseSkeleton(String skeleton, int[] skeletonFieldWidth) {
		int PATTERN_CHAR_BASE = 65;

		for (int i = 0; i < skeleton.length(); ++i) {
			++skeletonFieldWidth[skeleton.charAt(i) - PATTERN_CHAR_BASE];
		}

	}

	private static boolean stringNumeric(int fieldWidth, int anotherFieldWidth, char patternLetter) {
		return patternLetter == 'M'
				&& (fieldWidth <= 2 && anotherFieldWidth > 2 || fieldWidth > 2 && anotherFieldWidth <= 2);
	}

	BestMatchInfo getBestSkeleton(String inputSkeleton) {
		String bestSkeleton = inputSkeleton;
		int[] inputSkeletonFieldWidth = new int[58];
		int[] skeletonFieldWidth = new int[58];
		int DIFFERENT_FIELD = true;
		int STRING_NUMERIC_DIFFERENCE = true;
		int BASE = true;
		boolean replaceZWithV = false;
		if (inputSkeleton.indexOf(122) != -1) {
			inputSkeleton = inputSkeleton.replace('z', 'v');
			replaceZWithV = true;
		}

		parseSkeleton(inputSkeleton, inputSkeletonFieldWidth);
		int bestDistance = Integer.MAX_VALUE;
		int bestFieldDifference = 0;
		Iterator i$ = this.fIntervalPatterns.keySet().iterator();

		while (i$.hasNext()) {
			String skeleton = (String) i$.next();

			int distance;
			for (distance = 0; distance < skeletonFieldWidth.length; ++distance) {
				skeletonFieldWidth[distance] = 0;
			}

			parseSkeleton(skeleton, skeletonFieldWidth);
			distance = 0;
			int fieldDifference = 1;

			for (int i = 0; i < inputSkeletonFieldWidth.length; ++i) {
				int inputFieldWidth = inputSkeletonFieldWidth[i];
				int fieldWidth = skeletonFieldWidth[i];
				if (inputFieldWidth != fieldWidth) {
					if (inputFieldWidth == 0) {
						fieldDifference = -1;
						distance += 4096;
					} else if (fieldWidth == 0) {
						fieldDifference = -1;
						distance += 4096;
					} else if (stringNumeric(inputFieldWidth, fieldWidth, (char) (i + 65))) {
						distance += 256;
					} else {
						distance += Math.abs(inputFieldWidth - fieldWidth);
					}
				}
			}

			if (distance < bestDistance) {
				bestSkeleton = skeleton;
				bestDistance = distance;
				bestFieldDifference = fieldDifference;
			}

			if (distance == 0) {
				bestFieldDifference = 0;
				break;
			}
		}

		if (replaceZWithV && bestFieldDifference != -1) {
			bestFieldDifference = 2;
		}

		return new BestMatchInfo(bestSkeleton, bestFieldDifference);
	}

	public boolean equals(Object a) {
		if (a instanceof DateIntervalInfo) {
			DateIntervalInfo dtInfo = (DateIntervalInfo) a;
			return this.fIntervalPatterns.equals(dtInfo.fIntervalPatterns);
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.fIntervalPatterns.hashCode();
	}
}