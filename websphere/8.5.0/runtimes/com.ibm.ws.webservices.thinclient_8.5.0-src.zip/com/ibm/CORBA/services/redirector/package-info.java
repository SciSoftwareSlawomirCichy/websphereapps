package com.ibm.CORBA.services.redirector;

interface package-info {
}