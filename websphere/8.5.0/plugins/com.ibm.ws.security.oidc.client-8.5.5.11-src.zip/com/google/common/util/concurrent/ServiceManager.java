package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.Ordering;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.util.concurrent.Service.State;
import com.google.common.util.concurrent.ServiceManager.1;
import com.google.common.util.concurrent.ServiceManager.Listener;
import com.google.common.util.concurrent.ServiceManager.ServiceListener;
import com.google.common.util.concurrent.ServiceManager.ServiceManagerState;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
@Beta
public final class ServiceManager {
	private static final Logger logger = Logger.getLogger(ServiceManager.class.getName());
	private final ServiceManagerState state;
	private final ImmutableMap<Service, ServiceListener> services;

	public ServiceManager(Iterable<? extends Service> services) {
		ImmutableList<Service> copy = ImmutableList.copyOf(services);
		this.state = new ServiceManagerState(copy.size());
		Builder<Service, ServiceListener> builder = ImmutableMap.builder();
		Executor executor = MoreExecutors.sameThreadExecutor();
		Iterator i$ = copy.iterator();

		while (i$.hasNext()) {
			Service service = (Service) i$.next();
			ServiceListener listener = new ServiceListener(service, this.state);
			service.addListener(listener, executor);
			Preconditions.checkArgument(service.state() == State.NEW, "Can only manage NEW services, %s",
					new Object[]{service});
			builder.put(service, listener);
		}

		this.services = builder.build();
	}

	@Inject
	ServiceManager(Set<Service> services) {
		this((Iterable) services);
	}

	public void addListener(Listener listener, Executor executor) {
		this.state.addListener(listener, executor);
	}

	public ServiceManager startAsync() {
		Iterator i$ = this.services.entrySet().iterator();

		while (i$.hasNext()) {
			Entry<Service, ServiceListener> entry = (Entry) i$.next();
			Service service = (Service) entry.getKey();
			State state = service.state();
			Preconditions.checkState(state == State.NEW, "Service %s is %s, cannot start it.",
					new Object[]{service, state});
		}

		i$ = this.services.values().iterator();

		while (i$.hasNext()) {
			ServiceListener service = (ServiceListener) i$.next();
			service.start();
		}

		return this;
	}

	public void awaitHealthy() {
		this.state.awaitHealthy();
		Preconditions.checkState(this.isHealthy(), "Expected to be healthy after starting");
	}

	public void awaitHealthy(long timeout, TimeUnit unit) throws TimeoutException {
		if (!this.state.awaitHealthy(timeout, unit)) {
			throw new TimeoutException("Timeout waiting for the services to become healthy.");
		} else {
			Preconditions.checkState(this.isHealthy(), "Expected to be healthy after starting");
		}
	}

	public ServiceManager stopAsync() {
		Iterator i$ = this.services.keySet().iterator();

		while (i$.hasNext()) {
			Service service = (Service) i$.next();
			service.stop();
		}

		return this;
	}

	public void awaitStopped() {
		this.state.awaitStopped();
	}

	public void awaitStopped(long timeout, TimeUnit unit) throws TimeoutException {
		if (!this.state.awaitStopped(timeout, unit)) {
			throw new TimeoutException("Timeout waiting for the services to stop.");
		}
	}

	public boolean isHealthy() {
		Iterator i$ = this.services.keySet().iterator();

		Service service;
		do {
			if (!i$.hasNext()) {
				return true;
			}

			service = (Service) i$.next();
		} while (service.isRunning());

		return false;
	}

	public ImmutableMultimap<State, Service> servicesByState() {
		com.google.common.collect.ImmutableMultimap.Builder<State, Service> builder = ImmutableMultimap.builder();
		Iterator i$ = this.services.keySet().iterator();

		while (i$.hasNext()) {
			Service service = (Service) i$.next();
			builder.put(service.state(), service);
		}

		return builder.build();
	}

	public ImmutableMap<Service, Long> startupTimes() {
      Map<Service, Long> loadTimeMap = Maps.newHashMapWithExpectedSize(this.services.size());
      Iterator i$ = this.services.entrySet().iterator();

      while(i$.hasNext()) {
         Entry<Service, ServiceListener> entry = (Entry)i$.next();
         State state = ((Service)entry.getKey()).state();
         if (state != State.NEW && state != State.STARTING) {
            loadTimeMap.put(entry.getKey(), ((ServiceListener)entry.getValue()).startupTimeMillis());
         }
      }

      List<Entry<Service, Long>> servicesByStartTime = Ordering.natural().onResultOf(new 1(this)).sortedCopy(loadTimeMap.entrySet());
      Builder<Service, Long> builder = ImmutableMap.builder();
      Iterator i$ = servicesByStartTime.iterator();

      while(i$.hasNext()) {
         Entry<Service, Long> entry = (Entry)i$.next();
         builder.put(entry);
      }

      return builder.build();
   }

	public String toString() {
		return Objects.toStringHelper(ServiceManager.class).add("services", this.services.keySet()).toString();
	}
}