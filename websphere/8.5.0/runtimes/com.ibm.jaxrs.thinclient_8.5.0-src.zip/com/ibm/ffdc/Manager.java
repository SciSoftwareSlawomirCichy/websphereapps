package com.ibm.ffdc;

import com.ibm.ffdc.impl.Ffdc;
import com.ibm.ffdc.util.provider.Incident;
import java.util.List;

public interface Manager {
	Manager Ffdc = new Ffdc();

	com.ibm.ffdc.Ffdc getFfdc(Throwable var1, Object var2, String var3);

	com.ibm.ffdc.Ffdc getFfdc(Throwable var1, Object var2, String var3, String var4);

	void log(Throwable var1, Object var2, String var3, String var4, Object... var5);

	void log(Throwable var1, Object var2, String var3, String var4);

	List<Incident> getIncidents();

	boolean unblockLogging(Incident var1);

	void unblockLogging();
}