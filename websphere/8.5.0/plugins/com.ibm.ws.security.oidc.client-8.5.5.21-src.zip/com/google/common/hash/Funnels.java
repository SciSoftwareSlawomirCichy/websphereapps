package com.google.common.hash;

import com.google.common.annotations.Beta;
import com.google.common.hash.Funnels.ByteArrayFunnel;
import com.google.common.hash.Funnels.IntegerFunnel;
import com.google.common.hash.Funnels.LongFunnel;
import com.google.common.hash.Funnels.SequentialFunnel;
import com.google.common.hash.Funnels.SinkAsStream;
import com.google.common.hash.Funnels.StringCharsetFunnel;
import com.google.common.hash.Funnels.UnencodedCharsFunnel;
import java.io.OutputStream;
import java.nio.charset.Charset;

@Beta
public final class Funnels {
	public static Funnel<byte[]> byteArrayFunnel() {
		return ByteArrayFunnel.INSTANCE;
	}

	public static Funnel<CharSequence> unencodedCharsFunnel() {
		return UnencodedCharsFunnel.INSTANCE;
	}

	public static Funnel<CharSequence> stringFunnel(Charset charset) {
		return new StringCharsetFunnel(charset);
	}

	public static Funnel<Integer> integerFunnel() {
		return IntegerFunnel.INSTANCE;
	}

	public static <E> Funnel<Iterable<? extends E>> sequentialFunnel(Funnel<E> elementFunnel) {
		return new SequentialFunnel(elementFunnel);
	}

	public static Funnel<Long> longFunnel() {
		return LongFunnel.INSTANCE;
	}

	public static OutputStream asOutputStream(PrimitiveSink sink) {
		return new SinkAsStream(sink);
	}
}