package com.ibm.ejs.cm.portability;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.sql.SQLException;

public class StaleConnectionException extends PortableSQLException {
	private static final TraceComponent tc = Tr.register(StaleConnectionException.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");
	private static final long serialVersionUID = 731085915759246358L;

	public StaleConnectionException(SQLException nativeException) {
		super(nativeException);
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "The stack trace for the staleConn is: ", nativeException);
		}

	}

	public StaleConnectionException(String reason) {
		super(reason);
	}

	public StaleConnectionException() {
	}

	public StaleConnectionException(String reason, String state, int errCode) {
		super(reason, state, errCode);
	}
}