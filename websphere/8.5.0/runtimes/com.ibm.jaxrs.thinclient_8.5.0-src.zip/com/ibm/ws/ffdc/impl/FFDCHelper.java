package com.ibm.ws.ffdc.impl;

import com.ibm.ws.exception.WsException;
import com.ibm.ws.ffdc.FFDC;
import com.ibm.ws.ffdc.impl.FFDCHelper.1;
import com.ibm.ws.ffdc.impl.FFDCHelper.10;
import com.ibm.ws.ffdc.impl.FFDCHelper.11;
import com.ibm.ws.ffdc.impl.FFDCHelper.12;
import com.ibm.ws.ffdc.impl.FFDCHelper.13;
import com.ibm.ws.ffdc.impl.FFDCHelper.2;
import com.ibm.ws.ffdc.impl.FFDCHelper.3;
import com.ibm.ws.ffdc.impl.FFDCHelper.4;
import com.ibm.ws.ffdc.impl.FFDCHelper.5;
import com.ibm.ws.ffdc.impl.FFDCHelper.6;
import com.ibm.ws.ffdc.impl.FFDCHelper.7;
import com.ibm.ws.ffdc.impl.FFDCHelper.8;
import com.ibm.ws.ffdc.impl.FFDCHelper.9;
import com.ibm.ws.security.util.AccessController;
import java.io.File;
import java.io.FileFilter;
import java.io.InputStream;
import java.security.PrivilegedActionException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public class FFDCHelper {
	private static String svServerName = "";
	private static String svDefaultLoggingDirectory;
	private static String svDatabaseDirectory = null;
	private static final String classname = FFDCHelper.class.getName();
	private static Logger logger;
	private static boolean svServer;

	public static boolean isServer() {
		return svServer;
	}

	public static void setServer() {
		svServer = true;
	}

	public static String getServerName() {
		return svServerName;
	}

	public static void setServerName(String serverName) {
		if (serverName != null) {
			svServerName = serverName;
		}

	}

	public static String[] split(String aString, int ch) {
		if (aString != null && !aString.equals("")) {
			int numComponents = 0;
			int curIndex = 0;

			while (true) {
				curIndex = aString.indexOf(ch, curIndex);
				++numComponents;
				if (curIndex == -1) {
					String[] result = new String[numComponents];
					int start = 0;
					int end = aString.indexOf(ch, 0);

					for (int i = 0; i < numComponents; ++i) {
						if (i + 1 == numComponents) {
							result[i] = aString.substring(start);
						} else {
							result[i] = aString.substring(start, end);
						}

						start = end + 1;
						end = aString.indexOf(ch, start);
					}

					return result;
				}

				++curIndex;
			}
		} else {
			return new String[0];
		}
	}

	public static String generateFilename(String defaultPrefix) {
		try {
			Date date = new Date(System.currentTimeMillis());
			SimpleDateFormat formatter = new SimpleDateFormat("yy.MM.dd_HH.mm.ss.SSS");
			String ts = formatter.format(date);
			StringBuffer sb = new StringBuffer(64);
			if (FFDC.isZos()) {
				String stoken = FFDC.getzOSServantName();
				sb.append(FFDC.getFullServerName().trim());
				sb.append('_');
				sb.append(FFDC.getzOSjobName().trim());
				sb.append('_');
				sb.append(FFDC.getzOSjobNumber().trim());
				if (stoken != null) {
					sb.append('_');
					sb.append(stoken.trim());
				}
			} else {
				sb.append(svServerName);
			}

			sb.append('_');
			sb.append(defaultPrefix);
			sb.append('_');
			sb.append(ts);
			return new String(sb);
		} catch (Throwable var6) {
			logger.logp(Level.FINEST, classname, "generateOutputFileName", "FFDCHELPER_GENERATE_FILENAME_FAILED", var6);
			return null;
		}
	}

	public static synchronized String getDefaultLoggingDirectory() throws WsException {
		if (svDefaultLoggingDirectory == null) {
			String logDir = FFDC.getLogRoot();
			if (logDir == null) {
				throw new WsException("FFDCHelper - unable to obtain the install directory");
			}

			if (!logDir.endsWith("ffdc") && !logDir.endsWith("ffdc" + File.separator)) {
				if (logDir.endsWith(File.separator)) {
					logDir = logDir + "ffdc";
				} else {
					logDir = logDir + File.separator + "ffdc";
				}
			}

			File directory = new File(logDir);
			if (!fileExists(directory) && !makeDirectories(directory)) {
				throw new WsException("FFDCHelper - Unable to create directory  " + directory.getPath());
			}

			svDefaultLoggingDirectory = directory.getPath();
		}

		return svDefaultLoggingDirectory;
	}

	public static synchronized String getQualifiedDatabaseName(String databaseName) throws WsException {
		if (svDatabaseDirectory == null) {
			String dbDir = getSystemProperty("was.install.root");
			if (dbDir == null) {
				throw new WsException("FFDCHelper - unable to obtain the install directory");
			}

			if (!dbDir.endsWith(File.separator)) {
				dbDir = dbDir + File.separator;
			}

			dbDir = dbDir + "properties" + File.separator + "logbr" + File.separator + "ffdc" + File.separator + "adv"
					+ File.separator + databaseName;
			svDatabaseDirectory = dbDir;
		}

		return svDatabaseDirectory;
	}

	public static synchronized String getFFDCDBName() throws WsException {
		return getQualifiedDatabaseName("ffdcdb.xml");
	}

	public static String getSystemProperty(String propName) {
      String temp = propName;

      try {
         String prop = (String)AccessController.doPrivileged(new 1(temp));
         return prop;
      } catch (SecurityException var3) {
         logger.logp(Level.FINEST, classname, "getSystemProperty", "FFDCHELPER_SECURITYEXCEPTION", var3);
         return null;
      }
   }

	public static InputStream getResourceAsStream(String resource) throws PrivilegedActionException {
      InputStream stream = (InputStream)AccessController.doPrivileged(new 2(resource));
      return stream;
   }

	public static boolean deleteFile(File fileToDelete) {
      try {
         Boolean deleted = (Boolean)AccessController.doPrivileged(new 3(fileToDelete));
         return deleted;
      } catch (SecurityException var3) {
         logger.logp(Level.FINEST, classname, "deleteFile", "FFDCHELPER_SECURITYEXCEPTION", var3);
         return false;
      }
   }

	public static boolean fileExists(File fileToCheck) {
      File tempFileToCheck = fileToCheck;

      try {
         Boolean exists = (Boolean)AccessController.doPrivileged(new 4(tempFileToCheck));
         return exists;
      } catch (SecurityException var3) {
         logger.logp(Level.FINEST, classname, "fileExists", "FFDCHELPER_SECURITYEXCEPTION", var3);
         return false;
      }
   }

	public static long getFileLength(File fileToCheck) {
      File tempFileToCheck = fileToCheck;

      try {
         Long size = (Long)AccessController.doPrivileged(new 5(tempFileToCheck));
         return size;
      } catch (SecurityException var3) {
         logger.logp(Level.FINEST, classname, "getFileLength", "FFDCHELPER_SECURITYEXCEPTION", var3);
         return 0L;
      }
   }

	public static boolean canWriteFile(File fileToCheck) {
      File tempFileToCheck = fileToCheck;

      try {
         Boolean result = (Boolean)AccessController.doPrivileged(new 6(tempFileToCheck));
         return result;
      } catch (SecurityException var3) {
         logger.logp(Level.FINEST, classname, "canWriteFile", "FFDCHELPER_SECURITYEXCEPTION", var3);
         return false;
      }
   }

	public static boolean createNewFile(File fileToCreate) throws PrivilegedActionException {
      Boolean bool = (Boolean)AccessController.doPrivileged(new 7(fileToCreate));
      return bool;
   }

	public static boolean makeDirectories(File dirToMake) {
      File tempDirToMake = dirToMake;

      try {
         Boolean result = (Boolean)AccessController.doPrivileged(new 8(tempDirToMake));
         return result;
      } catch (SecurityException var3) {
         logger.logp(Level.FINEST, classname, "makeDirectories", "FFDCHELPER_SECURITYEXCEPTION", var3);
         return false;
      }
   }

	public static boolean renameFile(File current, File newName) {
      File tempCurrentFile = current;
      File tempNewName = newName;

      try {
         Boolean result = (Boolean)AccessController.doPrivileged(new 9(tempCurrentFile, tempNewName));
         return result;
      } catch (SecurityException var5) {
         logger.logp(Level.FINEST, classname, "renameFile", "FFDCHELPER_SECURITYEXCEPTION", var5);
         return false;
      }
   }

	public static boolean isFile(File fileToCheck) {
      File tempFileToCheck = fileToCheck;

      try {
         Boolean isFile = (Boolean)AccessController.doPrivileged(new 10(tempFileToCheck));
         return isFile;
      } catch (SecurityException var3) {
         logger.logp(Level.FINEST, classname, "isFile", "FFDCHELPER_SECURITYEXCEPTION", var3);
         return false;
      }
   }

	public static String[] listFileNames(File file) {
      File tempFile = file;

      try {
         String[] result = (String[])((String[])AccessController.doPrivileged(new 11(tempFile)));
         return result;
      } catch (SecurityException var3) {
         logger.logp(Level.FINEST, classname, "listFileNames", "FFDCHELPER_SECURITYEXCEPTION", var3);
         return new String[0];
      }
   }

	public static boolean isDirectory(File fileToCheck) {
      File tempFileToCheck = fileToCheck;

      try {
         Boolean exists = (Boolean)AccessController.doPrivileged(new 12(tempFileToCheck));
         return exists;
      } catch (SecurityException var3) {
         logger.logp(Level.FINEST, classname, "isDirectory", "FFDCHELPER_SECURITYEXCEPTION", var3);
         return false;
      }
   }

	public static File[] listFiles(File directory, FileFilter filter) {
      File tempFile = directory;
      FileFilter tempFilter = filter;

      try {
         File[] result = (File[])((File[])AccessController.doPrivileged(new 13(tempFile, tempFilter)));
         return result;
      } catch (SecurityException var5) {
         logger.logp(Level.FINEST, classname, "listFiles", "FFDCHELPER_SECURITYEXCEPTION", var5);
         return new File[0];
      }
   }

	public static DateFormat getBasicDateFormatter() {
		DateFormat formatter = DateFormat.getDateTimeInstance(3, 2);
		SimpleDateFormat formatter;
		if (formatter instanceof SimpleDateFormat) {
			SimpleDateFormat sdFormatter = (SimpleDateFormat) formatter;
			String pattern = sdFormatter.toPattern();
			int patternLength = pattern.length();
			int endOfSecsIndex = pattern.lastIndexOf(115) + 1;
			String newPattern = pattern.substring(0, endOfSecsIndex) + ":SSS z";
			if (endOfSecsIndex < patternLength) {
				newPattern = newPattern + pattern.substring(endOfSecsIndex, patternLength);
			}

			newPattern = newPattern.replace('h', 'H');
			newPattern = newPattern.replace('K', 'H');
			newPattern = newPattern.replace('k', 'H');
			newPattern = newPattern.replace('a', ' ');
			newPattern = newPattern.trim();
			sdFormatter.applyPattern(newPattern);
			formatter = sdFormatter;
		} else {
			formatter = new SimpleDateFormat("yy.MM.dd HH:mm:ss:SSS z");
		}

		return formatter;
	}

	public static String getThreadId() {
		LogRecord logRecord = new LogRecord(Level.FINE, "x");
		return getThreadId(logRecord);
	}

	public static String getThreadId(LogRecord logRecord) {
		StringBuffer buffer = new StringBuffer(16);
		String tid = Integer.toHexString(logRecord.getThreadID());
		int length = tid.length();

		for (int i = length; i < 8; ++i) {
			buffer.append('0');
		}

		buffer.append(tid);
		return buffer.toString();
	}

	static {
		logger = Logger.getLogger(classname, "com.ibm.ws.ffdc.resources.FFDCMessages");
		svServer = false;
	}
}