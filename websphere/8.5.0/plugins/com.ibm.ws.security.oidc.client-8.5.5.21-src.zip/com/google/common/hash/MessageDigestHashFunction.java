package com.google.common.hash;

import com.google.common.base.Preconditions;
import com.google.common.hash.MessageDigestHashFunction.1;
import com.google.common.hash.MessageDigestHashFunction.MessageDigestHasher;
import com.google.common.hash.MessageDigestHashFunction.SerializedForm;
import com.google.errorprone.annotations.Immutable;
import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Immutable
final class MessageDigestHashFunction extends AbstractHashFunction implements Serializable {
	private final MessageDigest prototype;
	private final int bytes;
	private final boolean supportsClone;
	private final String toString;

	MessageDigestHashFunction(String algorithmName, String toString) {
		this.prototype = getMessageDigest(algorithmName);
		this.bytes = this.prototype.getDigestLength();
		this.toString = (String) Preconditions.checkNotNull(toString);
		this.supportsClone = supportsClone(this.prototype);
	}

	MessageDigestHashFunction(String algorithmName, int bytes, String toString) {
		this.toString = (String) Preconditions.checkNotNull(toString);
		this.prototype = getMessageDigest(algorithmName);
		int maxLength = this.prototype.getDigestLength();
		Preconditions.checkArgument(bytes >= 4 && bytes <= maxLength, "bytes (%s) must be >= 4 and < %s", bytes,
				maxLength);
		this.bytes = bytes;
		this.supportsClone = supportsClone(this.prototype);
	}

	private static boolean supportsClone(MessageDigest digest) {
		try {
			digest.clone();
			return true;
		} catch (CloneNotSupportedException var2) {
			return false;
		}
	}

	public int bits() {
		return this.bytes * 8;
	}

	public String toString() {
		return this.toString;
	}

	private static MessageDigest getMessageDigest(String algorithmName) {
		try {
			return MessageDigest.getInstance(algorithmName);
		} catch (NoSuchAlgorithmException var2) {
			throw new AssertionError(var2);
		}
	}

	public Hasher newHasher() {
      if (this.supportsClone) {
         try {
            return new MessageDigestHasher((MessageDigest)this.prototype.clone(), this.bytes, (1)null);
         } catch (CloneNotSupportedException var2) {
            ;
         }
      }

      return new MessageDigestHasher(getMessageDigest(this.prototype.getAlgorithm()), this.bytes, (1)null);
   }

	Object writeReplace() {
      return new SerializedForm(this.prototype.getAlgorithm(), this.bytes, this.toString, (1)null);
   }
}