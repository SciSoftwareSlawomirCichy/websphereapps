package com.ibm.ejs.csi;

import com.ibm.websphere.csi.StatefulSessionKey;
import com.ibm.websphere.csi.StatefulSessionKeyFactory;
import com.ibm.ws.util.UUID;

public class SessionKeyFactoryImpl implements StatefulSessionKeyFactory {
	public StatefulSessionKey create() {
		UUID uuid = new UUID();
		return new StatefulSessionKeyImpl(uuid);
	}

	public StatefulSessionKey create(byte[] bytes) {
		return new StatefulSessionKeyImpl(new UUID(bytes));
	}
}