package org.apache.commons.codec;

public interface Encoder {
	Object encode(Object var1) throws EncoderException;
}