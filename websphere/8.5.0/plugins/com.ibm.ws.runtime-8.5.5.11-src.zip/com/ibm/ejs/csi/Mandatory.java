package com.ibm.ejs.csi;

import com.ibm.ejs.container.ContainerProperties;
import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRequiredException;
import com.ibm.websphere.csi.EJBKey;
import javax.transaction.Transaction;

final class Mandatory extends TranStrategy {
	private static final TraceComponent tc = Tr.register(Mandatory.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	Mandatory(TransactionControlImpl txCtrl) {
		super(txCtrl);
	}

	TxCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		if (!this.globalTxExists(true)) {
			throw new CSITransactionRequiredException("global tx required");
		} else {
			TxCookieImpl cookie = new TxCookieImpl(false, false, this, (Transaction) null);
			if (ContainerProperties.PI10351) {
				cookie.suspendedLocalTx = this.ltcCurrent.getLocalTranCoord();
				this.suspendLocalTx(cookie.suspendedLocalTx);
			}

			if (entryEnabled) {
				Tr.exit(tc, "preInvoke");
			}

			return cookie;
		}
	}

	void postInvoke(EJBKey key, TxCookieImpl txCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		if (txCookie.beginner) {
			Tr.error(tc, "PROTOCOL_ERROR_IN_CONTAINER_TRANSACTION_CNTR0050E");
		}

		super.postInvoke(key, txCookie, methodInfo);
		if (entryEnabled) {
			Tr.exit(tc, "postInvoke");
		}

	}
}