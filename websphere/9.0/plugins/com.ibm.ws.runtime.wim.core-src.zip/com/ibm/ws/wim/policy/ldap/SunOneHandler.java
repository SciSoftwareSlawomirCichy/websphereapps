package com.ibm.ws.wim.policy.ldap;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.ChangePasswordAfterResetException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.adapter.ldap.PasswordPolicyRequestControl;
import com.ibm.ws.wim.policy.PolicyHandler;
import commonj.sdo.DataObject;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.naming.OperationNotSupportedException;
import javax.naming.directory.DirContext;
import javax.naming.ldap.Control;
import javax.naming.ldap.LdapContext;

public class SunOneHandler extends PolicyHandler {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public DataObject loginPreProcess(DirContext var1, DataObject var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "loginPreProcess", WIMTraceHelper.printDataObject(var2));
		}

		Control[] var5 = new Control[]{new PasswordPolicyRequestControl()};

		try {
			((LdapContext) var1).setRequestControls(var5);
		} catch (NamingException var8) {
			String var7 = var8.toString(true);
			if (trcLogger.isLoggable(Level.SEVERE)) {
				trcLogger.logp(Level.SEVERE, CLASSNAME, "loginPreProcess", var7, var8);
			}

			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var7), Level.SEVERE,
					CLASSNAME, "loginPreProcess");
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "loginPreProcess",
					" returning DataObject: " + WIMTraceHelper.printDataObject(var2));
		}

		return var2;
	}

	public DataObject loginPostProcess(DirContext var1, DataObject var2, NamingException var3)
			throws NamingException, WIMException {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "loginPostProcess", WIMTraceHelper.printDataObject(var2));
		}

		String var6 = null;
		if (var3 != null && var1 != null) {
			var6 = this.getMessageKeyFromResponseCtl((LdapContext) var1);
			String var7 = var3.toString();
			if (trcLogger.isLoggable(Level.SEVERE)) {
				trcLogger.logp(Level.SEVERE, CLASSNAME, "loginPostProcess", var7, var3);
			}

			if (var6 != null) {
				if ("CHANGE_PWD_AFTER_RESET".equals(var6)) {
					throw new ChangePasswordAfterResetException("CHANGE_PWD_AFTER_RESET", Level.SEVERE, CLASSNAME,
							"loginPostProcess");
				}

				throw var3;
			}

			if (!(var3 instanceof OperationNotSupportedException)) {
				throw var3;
			}

			var6 = this.getVMMError(var3.getMessage());
			if ("CHANGE_PWD_AFTER_RESET".equals(var6)) {
				throw new ChangePasswordAfterResetException("CHANGE_PWD_AFTER_RESET", Level.SEVERE, CLASSNAME,
						"loginPostProcess");
			}
		}

		if (var5) {
			trcLogger.exiting(CLASSNAME, "loginPostProcess",
					" returning DataObject: " + WIMTraceHelper.printDataObject(var2));
		}

		return var2;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2014;
		CLASSNAME = SunOneHandler.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}