package com.google.inject.internal;

import com.google.inject.internal.UniqueAnnotations.1;
import java.lang.annotation.Annotation;
import java.util.concurrent.atomic.AtomicInteger;

public class UniqueAnnotations {
	private static final AtomicInteger nextUniqueValue = new AtomicInteger(1);

	public static Annotation create() {
		return create(nextUniqueValue.getAndIncrement());
	}

	static Annotation create(int value) {
      return new 1(value);
   }
}