package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_ru extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Механизм анализа использует базу данных {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Инцидент FFDC отправлен для {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: Служба управления файлами протоколов FFDC пытается удалить файл {0}"},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: Служба управления файлами протоколов FFDC удалила {0} из {1} файлов, для которых превышен срок хранения"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: Служба управления файлами протоколов FFDC не смогла удалить файл {0}"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: Службе управления файлами протоколов FFDC не удалось получить список файлов исключительных ситуаций"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC закрыла файл потока для инцидента {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC открыла файл потока для инцидента {0}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: FFDC не удалось закрыть файл потока для инцидента {0}, исключительная ситуация: {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: FFDC не удалось открыть или создать файл потока для инцидента {0}, исключительная ситуация: {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: FFDC не удалось записать в файл потока для инцидента {0}, исключительная ситуация: {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}