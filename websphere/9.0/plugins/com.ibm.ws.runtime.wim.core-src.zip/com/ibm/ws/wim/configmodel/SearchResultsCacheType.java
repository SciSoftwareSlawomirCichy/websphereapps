package com.ibm.ws.wim.configmodel;

public interface SearchResultsCacheType {
	int getCacheSize();

	void setCacheSize(int var1);

	void unsetCacheSize();

	boolean isSetCacheSize();

	int getCacheTimeOut();

	void setCacheTimeOut(int var1);

	void unsetCacheTimeOut();

	boolean isSetCacheTimeOut();

	boolean isEnabled();

	void setEnabled(boolean var1);

	void unsetEnabled();

	boolean isSetEnabled();

	int getSearchResultSizeLimit();

	void setSearchResultSizeLimit(int var1);

	void unsetSearchResultSizeLimit();

	boolean isSetSearchResultSizeLimit();

	String getCacheDistPolicy();

	void setCacheDistPolicy(String var1);

	void unsetCacheDistPolicy();

	boolean isSetCacheDistPolicy();
}