package com.ibm.ws.wim.configmodel;

public interface RepositoryType {
	String getAdapterClassName();

	void setAdapterClassName(String var1);

	String getId();

	void setId(String var1);
}