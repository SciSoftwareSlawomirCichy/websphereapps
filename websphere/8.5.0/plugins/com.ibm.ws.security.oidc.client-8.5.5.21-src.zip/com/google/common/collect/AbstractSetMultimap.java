package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedSet;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AbstractSetMultimap<K, V> extends AbstractMapBasedMultimap<K, V> implements SetMultimap<K, V> {
	private static final long serialVersionUID = 7431625294878419160L;

	protected AbstractSetMultimap(Map<K, Collection<V>> map) {
		super(map);
	}

	abstract Set<V> createCollection();

	Set<V> createUnmodifiableEmptyCollection() {
		return Collections.emptySet();
	}

	<E> Collection<E> unmodifiableCollectionSubclass(Collection<E> collection) {
		return Collections.unmodifiableSet((Set) collection);
	}

	Collection<V> wrapCollection(K key, Collection<V> collection) {
		return new WrappedSet(this, key, (Set) collection);
	}

	public Set<V> get(@NullableDecl K key) {
		return (Set) super.get(key);
	}

	public Set<Entry<K, V>> entries() {
		return (Set) super.entries();
	}

	@CanIgnoreReturnValue
	public Set<V> removeAll(@NullableDecl Object key) {
		return (Set) super.removeAll(key);
	}

	@CanIgnoreReturnValue
	public Set<V> replaceValues(@NullableDecl K key, Iterable<? extends V> values) {
		return (Set) super.replaceValues(key, values);
	}

	public Map<K, Collection<V>> asMap() {
		return super.asMap();
	}

	@CanIgnoreReturnValue
	public boolean put(@NullableDecl K key, @NullableDecl V value) {
		return super.put(key, value);
	}

	public boolean equals(@NullableDecl Object object) {
		return super.equals(object);
	}
}