package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.ServiceProvider;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.security.authz.jacc.JACCPolicyDefinition;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.UniqueNameHelper;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.io.File;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AuthzConfigCommandHelper implements ConfigConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	static final String SEARCH_PREFIX = "//entities[@xsi:type=";
	static final String SEARCH_PA_EXPR = "//entities[@xsi:type='PersonAccount' and uid='";
	static final String SEARCH_GROUP_EXPR = "//entities[@xsi:type='Group' and cn='";
	static List predefinedRoles;

	public String mapGroupToRole(Map var1) throws Exception {
		String var2 = "mapRoleToGroup";
		trcLogger.entering(CLASSNAME, var2, var1);
		String var3 = (String) var1.get("roleName");
		String var4 = (String) var1.get("groupId");
		if (var4.equals("ALLAUTHENTICATED")) {
			var4 = "AllAuthenticatedUsers";
		}

		this.mapToORRemoveFromRole(var3, var4, false, false);
		trcLogger.exiting(CLASSNAME, var2);
		return "COMMAND_COMPLETED_SUCCESSFULLY";
	}

	public String mapUserToRole(Map var1) throws Exception {
		String var2 = "mapUserToRole";
		trcLogger.entering(CLASSNAME, var2, var1);
		String var3 = (String) var1.get("roleName");
		String var4 = (String) var1.get("userId");
		this.mapToORRemoveFromRole(var3, var4, true, false);
		trcLogger.exiting(CLASSNAME, var2);
		return "COMMAND_COMPLETED_SUCCESSFULLY";
	}

	public String removeGroupsFromRole(Map var1) throws Exception {
		String var2 = "removeGroupsFromRole";
		trcLogger.entering(CLASSNAME, var2, var1);
		String var3 = (String) var1.get("roleName");
		String var4 = (String) var1.get("groupId");
		if (var4.equals("ALLAUTHENTICATED")) {
			var4 = "AllAuthenticatedUsers";
		}

		this.mapToORRemoveFromRole(var3, var4, false, true);
		trcLogger.exiting(CLASSNAME, var2);
		return "COMMAND_COMPLETED_SUCCESSFULLY";
	}

	public String removeUsersFromRole(Map var1) throws Exception {
		String var2 = "removeUsersFromRole";
		trcLogger.entering(CLASSNAME, var2, var1);
		String var3 = (String) var1.get("roleName");
		String var4 = (String) var1.get("userId");
		this.mapToORRemoveFromRole(var3, var4, true, true);
		trcLogger.exiting(CLASSNAME, var2);
		return "COMMAND_COMPLETED_SUCCESSFULLY";
	}

	private void mapToORRemoveFromRole(String var1, String var2, boolean var3, boolean var4) throws Exception {
		String var5 = "mapToORRemoveFromRole";
		trcLogger.entering(CLASSNAME, var5);
		this.validateRoles(var1);
		String var6;
		if (!var3 && var2.equals("AllAuthenticatedUsers")) {
			var6 = var2;
		} else if (var4 && "*".equals(var2)) {
			var6 = var2;
		} else {
			var6 = this.getUniqueName(var2, var3);
		}

		JACCPolicyDefinition var7 = this.getPolicy();
		if (var4) {
			var7.removePrincipalFromRole(var1, var6, this.getPrincipalRolePolicyFile(), var3);
		} else {
			var7.mapPrincipalToRole(var1, var6, this.getPrincipalRolePolicyFile(), var3);
		}

		trcLogger.exiting(CLASSNAME, var5);
	}

	public Map listUsersForRoles(Map var1) throws Exception {
		JACCPolicyDefinition var2 = this.getPolicy();
		return var2.listPrincipalsForRole(this.getPrincipalRolePolicyFile(), predefinedRoles, true);
	}

	public Map listGroupsForRoles(Map var1) throws Exception {
		JACCPolicyDefinition var2 = this.getPolicy();
		return var2.listPrincipalsForRole(this.getPrincipalRolePolicyFile(), predefinedRoles, false);
	}

	private JACCPolicyDefinition getPolicy() throws WIMException {
		ProfileSecurityManager var1 = ProfileSecurityManager.singleton();
		Object var2 = var1.getAuthzPolicy();
		return var2 != null && var2 instanceof JACCPolicyDefinition
				? (JACCPolicyDefinition) var2
				: this.getNewJaccPolicy();
	}

	private void validateRoles(String var1) throws WIMException {
		String var2 = "validateRoles";
		if (!predefinedRoles.contains(var1)) {
			throw new WIMException("INVALID_ROLE_NAME", WIMMessageHelper.generateMsgParms(var1), Level.SEVERE,
					CLASSNAME, var2);
		}
	}

	private String getUniqueName(String var1, boolean var2) throws WIMException, RemoteException {
		String var3 = "getUniqueName";
		DataObject var4;
		if (UniqueNameHelper.isDN(var1) != null) {
			var4 = getByUniqueName(var1);
		} else {
			var4 = search(var1, var2);
		}

		List var5 = var4.getList("entities");
		if (var5.size() > 1) {
			throw new WIMException("USER_OR_GROUP_ID_NOT_UNIQUE", WIMMessageHelper.generateMsgParms(var1), Level.SEVERE,
					CLASSNAME, var3);
		} else if (var5.size() < 1) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1), Level.SEVERE,
					CLASSNAME, var3);
		} else {
			DataObject var6 = (DataObject) var5.get(0);
			DataObject var7 = var6.getDataObject("identifier");
			return var7.getString("uniqueName");
		}
	}

	private static DataObject search(String var0, boolean var1) throws WIMException, RemoteException {
		String var2 = "search";
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, var2, "principalName= " + var0);
		}

		String var4 = null;
		if (var1) {
			var4 = "//entities[@xsi:type='PersonAccount' and uid='" + var0 + "']";
		} else {
			var4 = "//entities[@xsi:type='Group' and cn='" + var0 + "']";
		}

		if (var3) {
			trcLogger.logp(Level.FINER, CLASSNAME, var2, "searchExpr= " + var4);
		}

		ServiceProvider var5 = ServiceProvider.singleton();
		DataObject var6 = SchemaManager.singleton().createRootDataObject();
		DataObject var7 = var6.createDataObject("controls", "http://www.ibm.com/websphere/wim", "SearchControl");
		var7.setString("expression", var4);
		var7.setBoolean("returnSubType", true);
		DataObject var8 = var5.search(var6);
		if (var3) {
			trcLogger.exiting(CLASSNAME, var2, WIMTraceHelper.printDataObject(var8));
		}

		return var8;
	}

	private static DataObject getByUniqueName(String var0) throws WIMException, RemoteException {
		ServiceProvider var1 = ServiceProvider.singleton();
		DataObject var2 = SchemaManager.singleton().createRootDataObject();
		DataObject var3 = var2.createDataObject("entities");
		var3.createDataObject("identifier").setString("uniqueName", var0);
		return var1.get(var2);
	}

	private JACCPolicyDefinition getNewJaccPolicy() throws WIMException {
		DataObject var1 = this.getAuthzConfig();
		JACCPolicyDefinition var2 = new JACCPolicyDefinition(var1.getString("jaccPolicyClass"),
				var1.getString("jaccRoleMappingClass"), var1.getString("jaccPolicyConfigFactoryClass"),
				var1.getString("jaccRoleMappingConfigFactoryClass"), this.getAuthzHome());
		var2.loadPolicy(var1.getString("jaccRoleToPermissionPolicyId"), var1.getString("jaccPrincipalToRolePolicyId"),
				this.getAuthzHome() + File.separator + var1.getString("jaccRoleToPermissionPolicyFileName"),
				this.getAuthzHome() + File.separator + var1.getString("jaccPrincipalToRolePolicyFileName"));
		return var2;
	}

	private DataObject getAuthzConfig() throws WIMException {
		DataGraph var1 = ConfigManager.singleton().getConfig().getDataGraph();
		DataObject var2 = var1.getRootObject().getDataObject("configurationProvider");
		DataObject var3 = var2.getDataObject("authorization");
		return var3;
	}

	private String getAuthzHome() throws WIMException {
		String var1 = null;
		if (DomainManagerUtils.isAdminDomain()) {
			var1 = ConfigManager.singleton().getWIMHomePath() + JACCPolicyDefinition.POLICY_SUBDIR;
		} else {
			var1 = DomainManagerUtils.getDomainPath(DomainManagerUtils.getDomainName()) + "wim" + File.separator
					+ JACCPolicyDefinition.POLICY_SUBDIR;
		}

		return var1;
	}

	private String getPrincipalRolePolicyFile() throws WIMException {
		return this.getAuthzHome() + File.separator
				+ this.getAuthzConfig().getString("jaccPrincipalToRolePolicyFileName");
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010;
		CLASSNAME = AuthzConfigCommandHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		predefinedRoles = new ArrayList(5);
		predefinedRoles.add("IdMgrAdmin");
		predefinedRoles.add("IdMgrReader");
		predefinedRoles.add("IdMgrWriter");
	}
}