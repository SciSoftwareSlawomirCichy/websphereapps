package com.ibm.ejs.csi;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.StatefulBeanReaper;
import com.ibm.ejs.container.activator.StatefulSessionActivationStrategy;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.csi.FileBeanStore.1;
import com.ibm.ejs.csi.FileBeanStore.2;
import com.ibm.ejs.csi.FileBeanStore.3;
import com.ibm.ejs.csi.FileBeanStore.4;
import com.ibm.ejs.csi.FileBeanStore.5;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.websphere.csi.SessionBeanStore;
import com.ibm.websphere.csi.StreamUnavailableException;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.security.util.AccessController;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.PrivilegedActionException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class FileBeanStore implements SessionBeanStore {
	private static final TraceComponent tc = Tr.register(FileBeanStore.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.csi.FileBeanStore";
	private String passivationDir;
	private String serverName;
	private String clusterName;
	private static char[] hexChars = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
			'e', 'f'};

	public FileBeanStore(String passivationDir) {
		this(passivationDir, (String) null, (String) null);
	}

	public FileBeanStore(String passivationDir, String serverName, String clusterName) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", new Object[]{passivationDir, serverName, clusterName});
		}

		if (passivationDir != null && (new File(passivationDir)).isDirectory()) {
			this.passivationDir = passivationDir;
		} else {
			this.passivationDir = null;
			if (passivationDir != null) {
				Tr.warning(tc, "PASSIVATION_DIRECTORY_DOES_NOT_EXIST_CNTR0023W", passivationDir);
			}
		}

		this.serverName = serverName;
		this.clusterName = clusterName;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public GZIPInputStream getGZIPInputStream(EJBKey key) throws CSIException {
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "getGZIPInputStream", key);
      }

      String fileName = this.getPortableFilename(key.toString());
      String passDir = this.passivationDir;
      GZIPInputStream result = null;

      try {
         result = (GZIPInputStream)AccessController.doPrivileged(new 1(this, fileName, passDir));
      } catch (PrivilegedActionException var7) {
         Exception ex2 = var7.getException();
         if (ex2 instanceof FileNotFoundException) {
            FFDCFilter.processException((FileNotFoundException)ex2, "com.ibm.ejs.csi.FileBeanStore.getGZIPInputStream", "91", this);
            if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
               Tr.event(tc, "No file found while trying to activate passivated stateful session bean", fileName);
            }

            throw new StreamUnavailableException("");
         }

         if (ex2 instanceof IOException) {
            FFDCFilter.processException((IOException)ex2, "com.ibm.ejs.csi.FileBeanStore.getGZIPInputStream", "98", this);
            Tr.warning(tc, "IOEXCEPTION_READING_FILE_FOR_STATEFUL_SESSION_BEAN_CNTR0024W", new Object[]{fileName, this, (IOException)ex2});
            throw new CSIException("IOException reading input stream for stateful session bean", (IOException)ex2);
         }

         throw new CSIException("Unexpected exception reading input stream for stateful session bean", ex2);
      }

      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.exit(tc, "getGZIPInputStream");
      }

      return result;
   }

	public GZIPOutputStream getGZIPOutputStream(EJBKey key) throws CSIException {
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "getOutputStream ", key);
      }

      String fileName = this.getPortableFilename(key.toString());
      GZIPOutputStream result = null;
      StatefulBeanReaper reaper = null;
      if (EJSPlatformHelper.isZOS()) {
         reaper = ((StatefulSessionActivationStrategy)((BeanId)key).getActivationStrategy()).getReaper();
      }

      long beanTimeoutTime = EJSPlatformHelper.isZOS() ? reaper.getBeanTimeoutTime((BeanId)key) : 0L;

      try {
         result = (GZIPOutputStream)AccessController.doPrivileged(new 2(this, fileName, beanTimeoutTime));
      } catch (PrivilegedActionException var9) {
         IOException ex = (IOException)var9.getException();
         FFDCFilter.processException(ex, "com.ibm.ejs.csi.FileBeanStore.getOutputStream", "127", this);
         Tr.warning(tc, "IOEXCEPTION_WRITING_FILE_FOR_STATEFUL_SESSION_BEAN_CNTR0025W", new Object[]{fileName, this, ex});
         throw new CSIException("Unable to open output stream", ex);
      }

      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.exit(tc, "getOutputStream");
      }

      return result;
   }

	public void remove(EJBKey key) {
      String passDir = this.passivationDir;
      String fileName = this.getPortableFilename(key.toString());
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "remove file: " + fileName);
      }

      EJBKey tempKey = key;

      try {
         AccessController.doPrivileged(new 3(this, passDir, fileName, tempKey));
      } catch (PrivilegedActionException var6) {
         FFDCFilter.processException(var6.getException(), "com.ibm.ejs.csi.FileBeanStore.remove", "150", this);
         if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
            Tr.event(tc, "Failed to remove session bean state", new Object[]{key, var6});
         }
      }

      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.exit(tc, "remove file: " + fileName);
      }

   }

	private static String byteArrayToHexString(byte[] b) {
		StringBuffer result = new StringBuffer(b.length * 2);

		for (int i = 0; i < b.length; ++i) {
			result.append(hexChars[b[i] >> 4 & 15]);
			result.append(hexChars[b[i] & 15]);
		}

		return result.toString();
	}

	private String getPortableFilename(String fileName) {
		StringBuffer resultBuffer = new StringBuffer();
		int length = fileName.length();

		for (int i = 0; i < length; ++i) {
			char c = fileName.charAt(i);
			if (!Character.isLetterOrDigit(c) && c != '_' && c != '-' && c != '.') {
				resultBuffer.append('_');
			} else {
				resultBuffer.append(c);
			}
		}

		return resultBuffer.toString();
	}

	public OutputStream getOutputStream(EJBKey key) throws CSIException {
      String fileName = this.getPortableFilename(key.toString());
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "getOutputStream: file name = ", fileName);
      }

      FileOutputStream result = null;
      StatefulBeanReaper reaper = null;
      if (EJSPlatformHelper.isZOS()) {
         reaper = ((StatefulSessionActivationStrategy)((BeanId)key).getActivationStrategy()).getReaper();
      }

      long beanTimeoutTime = EJSPlatformHelper.isZOS() ? reaper.getBeanTimeoutTime((BeanId)key) : 0L;

      try {
         result = (FileOutputStream)AccessController.doPrivileged(new 4(this, fileName, beanTimeoutTime));
      } catch (PrivilegedActionException var9) {
         IOException ex = (IOException)var9.getException();
         FFDCFilter.processException(ex, "com.ibm.ejs.csi.FileBeanStore.getUnCompressedOutputStream", "460", this);
         Tr.warning(tc, "IOEXCEPTION_WRITING_FILE_FOR_STATEFUL_SESSION_BEAN_CNTR0025W", new Object[]{fileName, this, ex});
         throw new CSIException("Unable to open output stream", ex);
      }

      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.exit(tc, "getOutputStream");
      }

      return result;
   }

	public InputStream getInputStream(EJBKey key) throws CSIException {
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "getInputStream ", key);
      }

      String fileName = this.getPortableFilename(key.toString());
      FileInputStream result = null;

      try {
         result = (FileInputStream)AccessController.doPrivileged(new 5(this, fileName));
      } catch (PrivilegedActionException var6) {
         Exception ex2 = var6.getException();
         if (ex2 instanceof FileNotFoundException) {
            FFDCFilter.processException((FileNotFoundException)ex2, "com.ibm.ejs.csi.FileBeanStore.getInputStream", "524", this);
            if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
               Tr.event(tc, "No file found while trying to activate passivated stateful session bean", fileName);
            }

            throw new StreamUnavailableException("");
         }

         if (ex2 instanceof IOException) {
            FFDCFilter.processException((IOException)ex2, "com.ibm.ejs.csi.FileBeanStore.getInputStream", "531", this);
            Tr.warning(tc, "IOEXCEPTION_READING_FILE_FOR_STATEFUL_SESSION_BEAN_CNTR0024W", new Object[]{fileName, this, (IOException)ex2});
            throw new CSIException("IOException reading input stream for stateful session bean", (IOException)ex2);
         }

         throw new CSIException("Unexpected exception reading input stream for stateful session bean", ex2);
      }

      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.exit(tc, "getInputStream");
      }

      return result;
   }
}