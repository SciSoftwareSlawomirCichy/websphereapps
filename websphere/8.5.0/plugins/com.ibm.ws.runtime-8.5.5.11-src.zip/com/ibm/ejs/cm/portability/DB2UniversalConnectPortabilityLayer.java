package com.ibm.ejs.cm.portability;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.SQLException;

public final class DB2UniversalConnectPortabilityLayer extends DB2ConnectPortabilityLayer {
	private static DB2UniversalConnectPortabilityLayer instance;
	private static final TraceComponent tc = Tr.register(DB2UniversalConnectPortabilityLayer.class);

	protected DB2UniversalConnectPortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.errorMap.remove(new Integer(-30081));
		this.errorMap.put(new Integer(-4499), StaleConnectionException.class);
		this.defaultDataSourceProps.remove("connectionAttribute");
		this.defaultDataSourceProps.setProperty("resultSetHoldability", "2");
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new DB2UniversalConnectPortabilityLayer();
		}

		return instance;
	}
}