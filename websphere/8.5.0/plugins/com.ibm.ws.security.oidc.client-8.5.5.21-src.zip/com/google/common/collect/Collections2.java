package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2.FilteredCollection;
import com.google.common.collect.Collections2.OrderedPermutationCollection;
import com.google.common.collect.Collections2.PermutationCollection;
import com.google.common.collect.Collections2.TransformedCollection;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public final class Collections2 {
	public static <E> Collection<E> filter(Collection<E> unfiltered, Predicate<? super E> predicate) {
		return unfiltered instanceof FilteredCollection
				? ((FilteredCollection) unfiltered).createCombined(predicate)
				: new FilteredCollection((Collection) Preconditions.checkNotNull(unfiltered),
						(Predicate) Preconditions.checkNotNull(predicate));
	}

	static boolean safeContains(Collection<?> collection, @NullableDecl Object object) {
		Preconditions.checkNotNull(collection);

		try {
			return collection.contains(object);
		} catch (NullPointerException | ClassCastException var3) {
			return false;
		}
	}

	static boolean safeRemove(Collection<?> collection, @NullableDecl Object object) {
		Preconditions.checkNotNull(collection);

		try {
			return collection.remove(object);
		} catch (NullPointerException | ClassCastException var3) {
			return false;
		}
	}

	public static <F, T> Collection<T> transform(Collection<F> fromCollection, Function<? super F, T> function) {
		return new TransformedCollection(fromCollection, function);
	}

	static boolean containsAllImpl(Collection<?> self, Collection<?> c) {
		Iterator var2 = c.iterator();

		Object o;
		do {
			if (!var2.hasNext()) {
				return true;
			}

			o = var2.next();
		} while (self.contains(o));

		return false;
	}

	static String toStringImpl(Collection<?> collection) {
		StringBuilder sb = newStringBuilderForCollection(collection.size()).append('[');
		boolean first = true;
		Iterator var3 = collection.iterator();

		while (var3.hasNext()) {
			Object o = var3.next();
			if (!first) {
				sb.append(", ");
			}

			first = false;
			if (o == collection) {
				sb.append("(this Collection)");
			} else {
				sb.append(o);
			}
		}

		return sb.append(']').toString();
	}

	static StringBuilder newStringBuilderForCollection(int size) {
		CollectPreconditions.checkNonnegative(size, "size");
		return new StringBuilder((int) Math.min((long) size * 8L, 1073741824L));
	}

	static <T> Collection<T> cast(Iterable<T> iterable) {
		return (Collection) iterable;
	}

	@Beta
	public static <E extends Comparable<? super E>> Collection<List<E>> orderedPermutations(Iterable<E> elements) {
		return orderedPermutations(elements, Ordering.natural());
	}

	@Beta
	public static <E> Collection<List<E>> orderedPermutations(Iterable<E> elements, Comparator<? super E> comparator) {
		return new OrderedPermutationCollection(elements, comparator);
	}

	@Beta
	public static <E> Collection<List<E>> permutations(Collection<E> elements) {
		return new PermutationCollection(ImmutableList.copyOf(elements));
	}

	private static boolean isPermutation(List<?> first, List<?> second) {
		if (first.size() != second.size()) {
			return false;
		} else {
			ObjectCountHashMap<?> firstCounts = counts(first);
			ObjectCountHashMap<?> secondCounts = counts(second);
			if (first.size() != second.size()) {
				return false;
			} else {
				for (int i = 0; i < first.size(); ++i) {
					if (firstCounts.getValue(i) != secondCounts.get(firstCounts.getKey(i))) {
						return false;
					}
				}

				return true;
			}
		}
	}

	private static <E> ObjectCountHashMap<E> counts(Collection<E> collection) {
		ObjectCountHashMap<E> map = new ObjectCountHashMap();
		Iterator var2 = collection.iterator();

		while (var2.hasNext()) {
			E e = var2.next();
			map.put(e, map.get(e) + 1);
		}

		return map;
	}
}