package com.ibm.ejs.resources;

interface package-info {
}