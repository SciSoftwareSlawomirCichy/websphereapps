package com.ibm.ejs.container;

public class InvalidDescriptorException extends ContainerException {
	private static final long serialVersionUID = 7008930165729679009L;

	public InvalidDescriptorException(String s) {
		super(s);
	}

	public InvalidDescriptorException() {
	}
}