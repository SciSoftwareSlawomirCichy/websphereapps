package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.wsspi.security.policy.AbstractPolicies;
import com.ibm.wsspi.security.policy.EJBSecurityPolicy;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectOutputStream;
import java.util.Arrays;

public final class EJBSecurityPolicyImpl extends AbstractPolicies implements EJBSecurityPolicy {
	private static final TraceComponent tc = Tr.register(EJBSecurityPolicyImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	protected EJBMethodInfoImpl ivEMI;
	boolean ivDenyAll = false;
	boolean ivPermitAll = false;
	String[] ivRolesAllowed = null;

	public EJBSecurityPolicyImpl(boolean denyAll, boolean permitAll, String[] rolesAllowed, EJBMethodInfoImpl emi) {
		this.ivDenyAll = denyAll;
		this.ivPermitAll = permitAll;
		this.ivRolesAllowed = rolesAllowed;
		this.ivEMI = emi;
	}

	public boolean isPermitAll() {
		return this.ivPermitAll;
	}

	public void setPermitAll(boolean permitAll) {
		this.ivPermitAll = permitAll;
	}

	public boolean isDenyAll() {
		return this.ivDenyAll;
	}

	public void setDenyAll(boolean denyAll) {
		this.ivDenyAll = denyAll;
	}

	public String getRunAsSpecifiedIdentity() {
		return this.ivEMI.getRunAsSpecifiedIdentity();
	}

	public void setRunAsSpecifiedIdentity(String identity) {
		this.ivEMI.setRunAsSpecifiedIdentity(identity);
	}

	public boolean isRunAsCallerIdentity() {
		return this.ivEMI.isRunAsCallerIdentity();
	}

	public void setRunAsCallerIdentity(boolean runAs) {
		this.ivEMI.setRunAsCallerIdentity(runAs);
	}

	public String[] getRolesAllowed() {
		return this.ivRolesAllowed;
	}

	public void setRolesAllowed(String[] roles) {
		this.ivRolesAllowed = roles;
	}

	public String getRole(String link) {
		return this.ivEMI.getRole(link);
	}

	public void introspect(IntrospectionWriter writer) {
		writer.printHeading(1, "Security Policy Information");
		writer.println("DenyAll      = " + this.ivDenyAll);
		writer.println("PermitAll    = " + this.ivPermitAll);
		writer.println("RolesAllowed = " + Arrays.toString(this.ivRolesAllowed));
	}

	public Object getExtensionAdapter(Class clz) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getExtensionAdapter", clz);
		}

		Object adapter = null;
		if (EJSContainer.getDefaultContainer().ivEmbedded) {
			adapter = this.adapterCache.get(clz);
			if (adapter == null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc,
							"getExtensionAdapter - adapter not found in cache, creating new RunAsPolicyExtensionImpl");
				}

				try {
					adapter = Class.forName("com.ibm.ws.security.policy.RunAsPolicyExtensionImpl")
							.getConstructor(Object.class).newInstance(this);
					this.adapterCache.put(clz, adapter);
				} catch (Exception var4) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "getExtensionAdapter unexpected exception", var4);
					}
				}
			}
		} else {
			adapter = super.getExtensionAdapter(clz);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getExtensionAdapter", adapter);
		}

		return adapter;
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		throw new NotSerializableException();
	}
}