package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface StaticModelType {
	List getPackageName();

	String[] getPackageNameAsArray();

	boolean isUseGlobalSchema();

	void setUseGlobalSchema(boolean var1);

	void unsetUseGlobalSchema();

	boolean isSetUseGlobalSchema();
}