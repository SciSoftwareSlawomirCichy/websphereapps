package com.ibm.CSIv2Security;

public interface NotForwardableMechOID {
	String value = "No OID for this mechanism";
}