package com.ibm.websphere.crypto;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.security.WebSphereRuntimePermission;
import com.ibm.ws.crypto.config.KeySetGroupManager;
import com.ibm.ws.crypto.config.KeySetManager;
import com.ibm.ws.crypto.config.WSKeySet;
import com.ibm.ws.crypto.config.WSKeySetGroup;
import java.util.Map;

public class KeySetHelper {
	private static final TraceComponent tc = Tr.register(KeySetHelper.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private static KeySetHelper thisClass = null;
	private static final WebSphereRuntimePermission GET_KEYSETGROUPS = new WebSphereRuntimePermission(
			"getKeySetGroups");
	private static final WebSphereRuntimePermission GET_KEYSETS = new WebSphereRuntimePermission("getKeySets");

	public static KeySetHelper getInstance() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance");
		}

		if (thisClass == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Creating new instance of KeySetHelper.");
			}

			thisClass = new KeySetHelper();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance");
		}

		return thisClass;
	}

	public Map getAllKeysForKeySetGroup(String keySetGroupName) throws KeyException, SecurityException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getAllKeysByVersion", new Object[]{keySetGroupName});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_KEYSETGROUPS.toString());
			}

			try {
				sm.checkPermission(GET_KEYSETGROUPS);
			} catch (SecurityException var5) {
				Tr.debug(tc, "Expecting : " + GET_KEYSETGROUPS.toString() + "." + keySetGroupName);
				sm.checkPermission(new WebSphereRuntimePermission("GetKeySetGroups." + keySetGroupName));
			}
		}

		WSKeySetGroup keySetGroup = KeySetGroupManager.getInstance().getKeySetGroup(keySetGroupName);
		if (keySetGroup == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "The specified KeySetGroup name is not found.");
			}

			throw new KeyException("KeySetGroup name " + keySetGroupName + " is not found.");
		} else {
			Map allKeys = keySetGroup.getAllKeysByVersion();
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getAllKeysByVersion", new Object[]{allKeys});
			}

			return allKeys;
		}
	}

	public Map getLatestKeysForKeySetGroup(String keySetGroupName) throws KeyException, SecurityException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getLatestKeysForKeySetGroup", new Object[]{keySetGroupName});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_KEYSETGROUPS.toString());
			}

			try {
				sm.checkPermission(GET_KEYSETGROUPS);
			} catch (SecurityException var5) {
				Tr.debug(tc, "Expecting : " + GET_KEYSETGROUPS.toString() + "." + keySetGroupName);
				sm.checkPermission(new WebSphereRuntimePermission("GetKeySetGroups." + keySetGroupName));
			}
		}

		WSKeySetGroup keySetGroup = KeySetGroupManager.getInstance().getKeySetGroup(keySetGroupName);
		if (keySetGroup == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "The specified KeySetGroup name is not found.");
			}

			throw new KeyException("KeySetGroup name " + keySetGroupName + " is not found.");
		} else {
			Map latestKeys = keySetGroup.getLatestKeys();
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getLatestKeysForKeySetGroup", new Object[]{latestKeys});
			}

			return latestKeys;
		}
	}

	public Map getAllKeysForKeySet(String keySetName) throws KeyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getAllKeysForKeySet", new Object[]{keySetName});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_KEYSETS.toString());
			}

			try {
				sm.checkPermission(GET_KEYSETS);
			} catch (SecurityException var5) {
				Tr.debug(tc, "Expecting : " + GET_KEYSETS.toString() + "." + keySetName);
				sm.checkPermission(new WebSphereRuntimePermission("GetKeySets." + keySetName));
			}
		}

		WSKeySet keySet = KeySetManager.getInstance().getKeySet(keySetName);
		if (keySet == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "The specified KeySet name is not found.");
			}

			throw new KeyException("KeySet name " + keySetName + " is not found.");
		} else {
			Map allKeys = keySet.getAllKeys();
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getAllKeysForKeySet", new Object[]{allKeys});
			}

			return allKeys;
		}
	}

	public Object getLatestKeyForKeySet(String keySetName) throws KeyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getLatestKeyForKeySet", new Object[]{keySetName});
		}

		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Performing Java 2 Security Permission Check ...");
				Tr.debug(tc, "Expecting : " + GET_KEYSETS.toString());
			}

			try {
				sm.checkPermission(GET_KEYSETS);
			} catch (SecurityException var5) {
				Tr.debug(tc, "Expecting : " + GET_KEYSETS.toString() + "." + keySetName);
				sm.checkPermission(new WebSphereRuntimePermission("GetKeySets." + keySetName));
			}
		}

		WSKeySet keySet = KeySetManager.getInstance().getKeySet(keySetName);
		if (keySet == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "The specified KeySet name is not found.");
			}

			throw new KeyException("KeySet name " + keySetName + " is not found.");
		} else {
			Object latest = keySet.getLatestKey();
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getLatestKeyForKeySet", new Object[]{latest});
			}

			return latest;
		}
	}
}