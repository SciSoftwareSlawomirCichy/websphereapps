package com.ibm.websphere.crypto;

public class InvalidPasswordEncodingException extends Exception {
	private static final long serialVersionUID = -6049400841697995882L;
}