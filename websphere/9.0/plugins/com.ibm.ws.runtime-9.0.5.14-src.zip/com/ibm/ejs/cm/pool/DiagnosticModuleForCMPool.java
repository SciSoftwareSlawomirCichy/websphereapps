package com.ibm.ejs.cm.pool;

import com.ibm.ws.Transaction.TransactionManagerFactory;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.ffdc.DiagnosticModule;
import com.ibm.ws.ffdc.IncidentStream;
import java.sql.SQLException;
import java.util.Vector;

public class DiagnosticModuleForCMPool extends DiagnosticModule {
	public void ffdcDumpDefaultCM(Throwable th, IncidentStream is, Object callerThis, Object[] o, String sourceId) {
		if (sourceId.equals("com.ibm.ejs.cm.pool.ConnectO.prepare")
				|| sourceId.equals("com.ibm.ejs.cm.pool.ConnectO.enlist")) {
			is.writeLine("CONM6000W CONM6014I WTRN0062E ",
					"Possible misuse of connection manager may have caused 2PC transaction when 1PC tran was desired");
			ConnectO c = (ConnectO) callerThis;
			ConnectO initialConnectO = c;
			UOWCurrent uowCurrent = TransactionManagerFactory.getUOWCurrent();
			UOWCoordinator uowCoord = uowCurrent.getUOWCoord();
			Vector allConnsForThisTran = c.pool.getConnectionsForTransaction(uowCoord);
			if (allConnsForThisTran != null && allConnsForThisTran.size() > 1) {
				String password = c.getPassword();
				this.printConnectO(c, is, password);

				for (int i = 0; i < allConnsForThisTran.size(); ++i) {
					c = (ConnectO) allConnsForThisTran.elementAt(i);
					if (c != initialConnectO) {
						this.printConnectO(c, is, password);
					}
				}
			} else if (allConnsForThisTran != null && allConnsForThisTran.size() == 1) {
				is.writeLine("CONM6000W: Attempting to use a 1PC JDBC connection in a 2PC transaction.", "");
				is.writeLine("Driver used: ", c.getPhysicalConnection().getClass().getName());
				is.writeLine("Data Source Name: ", c.getPool().getAttributes().getName());
			}
		}

	}

	private void printConnectO(ConnectO c, IncidentStream is, String password) {
		is.writeLine("Connection ", "");
		is.writeLine("Username ", c.getUsername());
		is.writeLine("Same Password", password.equals(c.getPassword()) ? "Yes" : "No");

		try {
			is.writeLine("Isolation Level ", c.getTransactionIsolation());
		} catch (SQLException var8) {
			is.writeLine("Isolation Level ", var8.getMessage());
		}

		try {
			is.writeLine("Auto Commit ", c.getAutoCommit());
		} catch (SQLException var7) {
			is.writeLine("Auto Commit ", var7.getMessage());
		}

		try {
			is.writeLine("Read Only", c.isReadOnly());
		} catch (SQLException var6) {
			is.writeLine("Read Only", var6.getMessage());
		}

		try {
			is.writeLine("Catalog", c.getCatalog());
		} catch (SQLException var5) {
			is.writeLine("Catalog", var5.getMessage());
		}

		is.writeLine("Resource Name ", c.getResourceName());
		is.writeLine("", "");
	}
}