package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import commonj.sdo.DataObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LDAPServerConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = LDAPServerConfigHelper.class.getName();
	private static final Logger trcLogger;

	public String addIdMgrLDAPServer(String var1, Map var2) throws WIMException {
		String var3 = "addIdMgrLDAPServer";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "params: " + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var4 = (String) var2.get("id");
		String var5 = (String) var2.get("host");
		Integer var6 = (Integer) var2.get("port");
		ValidationHelper.validateIntegerInput("port", CLASSNAME, var3, var6);
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var4,
				"LdapRepositoryType");
		LdapServerConfigurationType var8 = var7.getLdapServerConfiguration();
		if (var8 == null) {
			var8 = var7.createLdapServerConfiguration();
		}

		LdapServersType var9 = this.getServerBasedOnPrimaryHost(var1, var4, var5, false);
		if (var9 != null) {
			throw new WIMConfigurationException("PRIMARY_HOST_ALREADY_EXISTS", WIMMessageHelper.generateMsgParms(var5),
					Level.SEVERE, CLASSNAME, var3);
		} else {
			HashMap var10 = new HashMap();
			var10.put("ldapServerType", var7.getLdapServerType());
			var10.put("certificateMapMode", var7.getCertificateMapMode());
			var10.put("certificateFilter", var7.getCertificateFilter());
			var10.put("sslConfiguration", var8.getSslConfiguration());
			var10.putAll(var2);
			ConfigValidator.validateLDAPParams(var4, var10);
			String var11 = (String) var2.get("ldapServerType");
			if (var11 != null) {
				var7.setLdapServerType(var11);
			}

			var11 = (String) var2.get("certificateMapMode");
			if (var11 != null) {
				var7.setCertificateMapMode(var11);
			}

			var11 = (String) var2.get("certificateFilter");
			if (var11 != null) {
				var7.setCertificateFilter(var11);
			}

			var11 = (String) var2.get("sslConfiguration");
			if (var11 != null) {
				var8.setSslConfiguration(var11);
			}

			var9 = var8.createLdapServers();
			this.setServerParams(var9, var2);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, var3);
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public String updateIdMgrLDAPServer(String var1, Map var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateIdMgrLDAPServer",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		Integer var4 = (Integer) var2.get("port");
		ValidationHelper.validateIntegerInput("port", CLASSNAME, "updateIdMgrLDAPServer", var4);
		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("host");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		LdapServersType var8 = this.getServerBasedOnPrimaryHost(var1, var5, var6, true);
		LdapServerConfigurationType var9 = var7.getLdapServerConfiguration();
		if (var9 == null) {
			var9 = var7.createLdapServerConfiguration();
		}

		HashMap var10 = new HashMap();
		LDAPRepositoryConfigHelper.copyLDAPConnectionData(var10, var8, var7);
		if (var2.containsKey("primary_host")) {
			var2.put("host", var2.get("primary_host"));
		}

		var10.putAll(var2);
		ConfigValidator.validateLDAPParams(var5, var10);
		String var11 = (String) var2.get("ldapServerType");
		if (var11 != null) {
			var7.setLdapServerType(var11);
		}

		var11 = (String) var2.get("certificateMapMode");
		if (var11 != null) {
			var7.setCertificateMapMode(var11);
		}

		var11 = (String) var2.get("certificateFilter");
		if (var11 != null) {
			var7.setCertificateFilter(var11);
		}

		var11 = (String) var2.get("sslConfiguration");
		if (var11 != null) {
			var9.setSslConfiguration(var11);
		}

		this.setServerParams(var8, var2);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrLDAPServer");
		}

		return ConfigUtils.saveConfig(var1);
	}

	void setServerParams(LdapServersType var1, Map var2) throws WIMException {
		String var3 = (String) var2.get("host");
		Integer var4 = (Integer) var2.get("port");
		String var5 = (String) var2.get("bindDN");
		String var6 = (String) var2.get("bindPassword");
		String var7 = (String) var2.get("authentication");
		String var8 = (String) var2.get("referal");
		String var9 = (String) var2.get("derefAliases");
		Boolean var10 = (Boolean) var2.get("sslEnabled");
		Boolean var11 = (Boolean) var2.get("connectionPool");
		Integer var12 = (Integer) var2.get("connectTimeout");
		if (var3 != null || var4 != null) {
			ConnectionsType var13 = null;
			List var14 = var1.getConnections();
			if (var14 != null && var14.size() != 0) {
				var13 = (ConnectionsType) var14.get(0);
			} else {
				var13 = var1.createConnections();
			}

			if (var3 != null) {
				var13.setHost(var3);
			}

			if (var4 != null) {
				var13.setPort(var4);
			}
		}

		if (var5 != null) {
			var1.setBindDN(var5);
		}

		if (var6 != null) {
			var1.setBindPassword(ConfigUtils.encodePassword(var6));
		}

		if (var7 != null) {
			var1.setAuthentication(var7);
		}

		if (var8 != null) {
			var1.setReferal(var8);
		}

		if (var9 != null) {
			var1.setDerefAliases(var9);
		}

		if (var10 != null) {
			var1.setSslEnabled(var10);
		}

		if (var11 != null) {
			var1.setConnectionPool(var11);
		}

		if (var12 != null) {
			var1.setConnectTimeout(var12);
		}

	}

	public String deleteIdMgrLDAPServer(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPServer", "params: " + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("host");
		LdapServersType var7 = this.getServerBasedOnPrimaryHost(var1, var5, var6, true);
		((DataObject) var7).delete();
		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPServer");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List listIdMgrLDAPServers(String var1, Map var2) throws WIMException {
		String var3 = "listIdMgrLDAPServers";
		Vector var4 = new Vector();
		String var5 = (String) var2.get("id");
		LdapRepositoryType var6 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		LdapServerConfigurationType var7 = var6.getLdapServerConfiguration();
		if (var7 == null) {
			throw new WIMConfigurationException("MISSING_LDAP_SERVER_CONFIGURATION",
					WIMMessageHelper.generateMsgParms(var5), Level.SEVERE, CLASSNAME, var3);
		} else {
			List var8 = var7.getLdapServers();
			Object var9 = null;
			Iterator var10 = var8.iterator();

			while (var10.hasNext()) {
				LdapServersType var11 = (LdapServersType) var10.next();
				List var12 = var11.getConnections();
				if (var12 != null && var12.size() != 0) {
					ConnectionsType var13 = (ConnectionsType) var12.get(0);
					var4.add(var13.getHost());
				}
			}

			return var4;
		}
	}

	public Map getIdMgrLDAPServer(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPServer", "params: " + var2);
		}

		HashMap var5 = new HashMap();
		String var6 = (String) var2.get("id");
		String var7 = (String) var2.get("host");
		LdapServersType var8 = this.getServerBasedOnPrimaryHost(var1, var6, var7, true);
		var5.put("id", var6);
		var5.put("host", var7);
		ConnectionsType var9 = (ConnectionsType) var8.getConnections().get(0);
		if (var9.isSetPort()) {
			var5.put("port", new Integer(var9.getPort()));
		}

		if (var8.getBindDN() != null) {
			var5.put("bindDN", var8.getBindDN());
		}

		if (var8.getBindPassword() != null) {
			var5.put("bindPassword", var8.getBindPassword());
		}

		if (var8.isSetAuthentication()) {
			var5.put("authentication", var8.getAuthentication());
		}

		if (var8.isSetReferal()) {
			var5.put("referal", var8.getReferal());
		}

		if (var8.getDerefAliases() != null) {
			var5.put("derefAliases", var8.getDerefAliases());
		}

		if (var8.isSetSslEnabled()) {
			var5.put("sslEnabled", var8.isSslEnabled());
		}

		if (var8.isSetConnectionPool()) {
			var5.put("connectionPool", var8.isConnectionPool());
		}

		if (var8.isSetConnectTimeout()) {
			var5.put("connectTimeout", new Integer(var8.getConnectTimeout()));
		}

		LdapRepositoryType var10 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var6,
				"LdapRepositoryType");
		if (var10.getLdapServerType() != null) {
			var5.put("ldapServerType", var10.getLdapServerType());
		}

		if (var10.getCertificateMapMode() != null) {
			var5.put("certificateMapMode", var10.getCertificateMapMode());
		}

		if (var10.getCertificateFilter() != null) {
			var5.put("certificateFilter", var10.getCertificateFilter());
		}

		LdapServerConfigurationType var11 = var10.getLdapServerConfiguration();
		if (var11 != null && var11.getSslConfiguration() != null) {
			var5.put("sslConfiguration", var11.getSslConfiguration());
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPServer", "result: " + var5.toString());
		}

		return var5;
	}

	public String addIdMgrLDAPBackupServer(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrLDAPBackupServer", "params: " + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("primary_host");
		String var7 = (String) var2.get("host");
		Integer var8 = (Integer) var2.get("port");
		ValidationHelper.validateIntegerInput("port", CLASSNAME, "addIdMgrLDAPBackupServer", var8);
		LdapRepositoryType var9 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		LdapServersType var10 = this.getServerBasedOnPrimaryHost(var1, var5, var6, true);
		List var11 = var10.getConnections();

		ConnectionsType var13;
		for (int var12 = 0; var12 < var11.size(); ++var12) {
			var13 = (ConnectionsType) var11.get(var12);
			if (var13.getHost().equalsIgnoreCase(var7)) {
				boolean var14 = true;
				if (var8 != null || var13.isSetPort()) {
					if (var8 != null && var13.isSetPort()) {
						if (var8 != var13.getPort()) {
							var14 = false;
						}
					} else {
						var14 = false;
					}
				}

				if (var14) {
					throw new WIMConfigurationException("BACKUP_HOST_PORT_ALREADY_EXISTS",
							WIMMessageHelper.generateMsgParms(var7, var8), CLASSNAME, "addIdMgrLDAPBackupServer");
				}
			}
		}

		HashMap var15 = new HashMap();
		LDAPRepositoryConfigHelper.copyLDAPConnectionData(var15, var10, var9);
		var15.put("host", var7);
		if (var8 != null) {
			var15.put("port", var8);
		} else {
			var15.remove("port");
		}

		ConfigValidator.validateLDAPParams(var5, var15);
		var13 = var10.createConnections();
		var13.setHost(var7);
		if (var8 != null) {
			var13.setPort(var8);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "addIdMgrLDAPBackupServer");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public String removeIdMgrLDAPBackupServer(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "removeIdMgrLDAPBackupServer", "params: " + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("primary_host");
		String var7 = (String) var2.get("host");
		Integer var8 = (Integer) var2.get("port");
		ValidationHelper.validateIntegerInput("port", CLASSNAME, "removeIdMgrLDAPBackupServer", var8);
		LdapServersType var9 = this.getServerBasedOnPrimaryHost(var1, var5, var6, true);
		boolean var10 = false;
		List var11 = var9.getConnections();

		for (int var12 = 1; var12 < var11.size(); ++var12) {
			ConnectionsType var13 = (ConnectionsType) var11.get(var12);
			if ("*".equals(var7)) {
				var11.remove(var12);
				var10 = true;
				--var12;
			} else if (var13.getHost().equals(var7)) {
				if (var8 != null) {
					if (var13.isSetPort() && var8 == var13.getPort()) {
						var10 = true;
						var11.remove(var12);
						break;
					}
				} else if (!var13.isSetPort()) {
					var10 = true;
					var11.remove(var12);
					--var12;
				}
			}
		}

		if (!var10) {
			throw new WIMConfigurationException("INVALID_BACKUP_HOST_PORT",
					WIMMessageHelper.generateMsgParms(var7, var8), Level.SEVERE, CLASSNAME,
					"removeIdMgrLDAPBackupServer");
		} else {
			if (var4) {
				trcLogger.exiting(CLASSNAME, "removeIdMgrLDAPBackupServer");
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public List listIdMgrLDAPBackupServers(String var1, Map var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrLDAPBackupServers", "params: " + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("primary_host");
		LdapServersType var7 = this.getServerBasedOnPrimaryHost(var1, var5, var6, true);
		List var8 = var7.getConnections();
		if (var8 == null) {
			throw new WIMConfigurationException("INVALID_PRIMARY_HOST", WIMMessageHelper.generateMsgParms(var6),
					Level.SEVERE, CLASSNAME, "listIdMgrLDAPBackupServers");
		} else {
			ArrayList var9 = new ArrayList();

			for (int var10 = 1; var10 < var8.size(); ++var10) {
				HashMap var11 = new HashMap();
				ConnectionsType var12 = (ConnectionsType) var8.get(var10);
				if (var12.isSetPort()) {
					var11.put(var12.getHost(), new Integer(var12.getPort()));
				} else {
					var11.put(var12.getHost(), (Object) null);
				}

				var9.add(var11);
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "listIdMgrLDAPBackupServers", "result: " + var9);
			}

			return var9;
		}
	}

	private LdapServersType getServerBasedOnPrimaryHost(String var1, String var2, String var3, boolean var4)
			throws WIMException {
		String var5 = "getServerBasedOnPrimaryHost";
		LdapRepositoryType var6 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		LdapServerConfigurationType var7 = var6.getLdapServerConfiguration();
		if (var7 == null) {
			throw new WIMConfigurationException("MISSING_LDAP_SERVER_CONFIGURATION",
					WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, var5);
		} else {
			List var8 = var7.getLdapServers();
			LdapServersType var9 = null;
			Iterator var10 = var8.iterator();

			while (var10.hasNext()) {
				LdapServersType var11 = (LdapServersType) var10.next();
				List var12 = var11.getConnections();
				if (var12.size() != 0) {
					ConnectionsType var13 = (ConnectionsType) var12.get(0);
					if (var13.getHost().equals(var3)) {
						var9 = var11;
						break;
					}
				}
			}

			if (var4 && var9 == null) {
				throw new WIMConfigurationException("INVALID_PRIMARY_HOST", WIMMessageHelper.generateMsgParms(var3),
						Level.SEVERE, CLASSNAME, var5);
			} else {
				return var9;
			}
		}
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}