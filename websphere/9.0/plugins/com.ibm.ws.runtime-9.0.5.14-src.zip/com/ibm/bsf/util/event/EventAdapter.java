package com.ibm.bsf.util.event;

public interface EventAdapter {
	void setEventProcessor(EventProcessor var1);
}