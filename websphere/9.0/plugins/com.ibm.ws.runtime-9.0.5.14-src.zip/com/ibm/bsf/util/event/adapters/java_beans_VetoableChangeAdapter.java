package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;

public class java_beans_VetoableChangeAdapter extends EventAdapterImpl implements VetoableChangeListener {
	public void vetoableChange(PropertyChangeEvent var1) throws PropertyVetoException {
		try {
			this.eventProcessor.processExceptionableEvent(var1.getPropertyName(), new Object[]{var1});
		} catch (PropertyVetoException var3) {
			throw var3;
		} catch (Exception var4) {
			;
		}

	}
}