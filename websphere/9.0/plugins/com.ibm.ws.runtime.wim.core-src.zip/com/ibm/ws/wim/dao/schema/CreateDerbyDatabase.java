package com.ibm.ws.wim.dao.schema;

import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.dao.DAOHelper;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CreateDerbyDatabase {
	private static final String DERBY_JDBC_DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = CreateDerbyDatabase.class.getName();
	private static final Logger trcLogger;

	public static void main(String[] var0) {
		try {
			trcLogger.log(Level.FINER, "Creating connection to Derby database...");
			DAOHelper.createConnection("org.apache.derby.jdbc.EmbeddedDriver", var0[0] + ";create=true",
					(Properties) null);
			trcLogger.log(Level.FINER, "Created and connected to database " + var0[0]);
		} catch (Throwable var2) {
			trcLogger.log(Level.FINER, "exception thrown", var2);
			var2.printStackTrace();
		}

	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}