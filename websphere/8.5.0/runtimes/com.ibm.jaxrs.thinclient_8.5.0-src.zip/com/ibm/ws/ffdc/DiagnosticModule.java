package com.ibm.ws.ffdc;

import com.ibm.ffdc.Manager;
import com.ibm.ws.ffdc.impl.CallStack;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class DiagnosticModule {
	String[] directives;
	String[] defaultDirectives;
	Hashtable methodTable = new Hashtable();
	boolean continueProcessing = true;
	private static ThreadLocal<CallStack> threadLocal = new ThreadLocal();
	static final Class[] ffdcDumpParams = new Class[]{Throwable.class, IncidentStream.class, Object.class,
			(new Object[0]).getClass(), String.class};
	static final String ffdcDumpPrefix = "ffdcdump";
	static final String ffdcDumpDefault = "default";
	static final boolean debug = false;
	static final int PREFLEN = "ffdcdump".length();

	protected final void init() throws DiagnosticModuleRegistrationFailureException {
		Method[] methods = null;

		try {
			methods = this.getClass().getMethods();
			this.buildMethods(methods);
		} catch (Exception var3) {
			methods = new Method[0];
			var3.printStackTrace();
			throw new DiagnosticModuleRegistrationFailureException("Exception: " + var3 + " caught!", var3);
		}
	}

	public boolean validate() {
		System.out.println("This method is NOT intended to be called from the runtime");
		System.out.println("but is provided as part of unit test for diagnostic modules");

		try {
			this.init();
		} catch (DiagnosticModuleRegistrationFailureException var4) {
			System.out.println("Diagnostic Module failed to register");
			var4.printStackTrace();
			return false;
		} catch (Throwable var5) {
			System.out.println("Some unknown failure occured");
			var5.printStackTrace();
			return false;
		}

		System.out.println("ffdc methods on the diagnostic module : ");
		Enumeration e = this.methodTable.keys();
		String methodName = null;

		while (e.hasMoreElements()) {
			methodName = (String) e.nextElement();
			System.out.println("    " + methodName);
		}

		System.out.println("The default directives are : ");
		if (this.defaultDirectives != null && this.defaultDirectives.length != 0) {
			for (int i = 0; i < this.defaultDirectives.length && this.defaultDirectives[i] != null; ++i) {
				System.out.println("    " + this.defaultDirectives[i]);
			}

			return true;
		} else {
			System.out.println("No default directives were found");
			System.out.println("This diagnostic module would fail to register");
			return false;
		}
	}

	public void stopProcessingException() {
		this.continueProcessing = false;
	}

	public boolean dumpComponentData(String[] input_directives, Throwable ex, IncidentStream ffdcis, Object callerThis,
			Object[] catcherObjects, String sourceId, CallStack callStack) {
		this.continueProcessing = true;

		try {
			threadLocal.set(callStack);
			ffdcis.writeLine("==> Performing default dump from " + this.getClass().getName() + " ", new Date());
			this.getDataForDirectives(this.defaultDirectives, ex, ffdcis, callerThis, catcherObjects, sourceId);
			if (input_directives != null && input_directives.length > 0) {
				ffdcis.writeLine("==> Default dump complete for " + this.getClass().getName()
						+ ".\n\n==> Now customized dump is running... ", new Date());
				this.getDataForDirectives(input_directives, ex, ffdcis, callerThis, catcherObjects, sourceId);
			}

			ffdcis.writeLine("==> Dump complete for " + this.getClass().getName() + " ", new Date());
		} catch (Throwable var12) {
			ffdcis.writeLine("==> Dump did not complete for " + this.getClass().getName() + " ", new Date());
		} finally {
			threadLocal.set((Object) null);
		}

		return this.continueProcessing;
	}

	protected static final String getExecutionMethodName() {
		CallStack exceptionCallStack = (CallStack) threadLocal.get();
		return exceptionCallStack != null ? exceptionCallStack.getExecutionMethodName() : null;
	}

	void buildMethods(Method[] methods) {
		for (int i = 0; i < methods.length; ++i) {
			Method method = methods[i];
			String name = method.getName().toLowerCase();
			if (name.length() > PREFLEN && name.startsWith("ffdcdump")) {
				Class[] params = method.getParameterTypes();
				if (params.length != ffdcDumpParams.length) {
					throw new IllegalStateException("Error: " + method + " starts with " + "ffdcdump" + " but takes "
							+ params.length + " parameters.  It is supposed to have " + ffdcDumpParams.length
							+ " parameters and have the signature " + "ffdcdump" + "<....>(" + this.buildParamList()
							+ ");" + " Method skipped!");
				}

				boolean error = false;

				for (int j = 0; j < params.length; ++j) {
					if (params[j] != ffdcDumpParams[j]) {
						throw new IllegalStateException("Error: " + method + " starts with " + "ffdcdump"
								+ " but does not conform to the signature\n\t" + "ffdcdump" + "<....>("
								+ this.buildParamList() + "); \n\tParameter " + (j + 1)
								+ " does not match.  Method skipped!");
					}
				}

				if (!error) {
					this.methodTable.put(name.substring(PREFLEN), method);
				}
			}
		}

		this.directives = new String[this.methodTable.size()];
		Vector defaultv = new Vector();
		int k = 0;
		Enumeration keys = this.methodTable.keys();

		while (keys.hasMoreElements()) {
			String directive = (String) keys.nextElement();
			this.directives[k++] = directive;
			if (directive.startsWith("default")) {
				defaultv.addElement(directive);
			}
		}

		if (defaultv.isEmpty()) {
			throw new IllegalStateException("Error: class " + this.getClass().getName()
					+ " must have at least one DEFAULT dumping method of the form:\n\t" + "ffdcdump" + "default"
					+ "<....>(" + this.buildParamList() + ");");
		} else {
			this.defaultDirectives = (String[]) ((String[]) defaultv.toArray(new String[0]));
		}
	}

	public String[] getDirectives() {
		return this.directives;
	}

	public void getDataForDirectives(String[] directives, Throwable ex, IncidentStream out, Object callerThis,
			Object[] catcherObjects, String sourceId) {
		if (directives != null) {
			for (int i = 0; i < directives.length; ++i) {
				String directive = directives[i];
				this.getDataForDirective(directive, ex, out, callerThis, catcherObjects, sourceId);
			}

		}
	}

	private void getDataForDirective(String directive, Throwable excep, IncidentStream out, Object callerThis,
			Object[] catcherObjects, String sourceId) {
		Method method = (Method) this.methodTable.get(directive.toLowerCase());
		if (method == null) {
			out.writeLine("Unsupported directive [" + directive + "] !!!", "");
		} else {
			try {
				Object[] o = new Object[ffdcDumpParams.length];
				o[0] = excep;
				o[1] = out;
				o[2] = callerThis;
				o[3] = catcherObjects;
				o[4] = sourceId;
				method.invoke(this, o);
				out.writeLine("+Data for directive [" + directive + "] obtained.", "");
			} catch (Throwable var11) {
				Throwable t = var11;

				try {
					String mname = method.getDeclaringClass().getName() + method.getName();
					Manager.Ffdc.log(t, this, this.getClass().getName(), "getDataForDirective", new Object[]{mname});
				} catch (Exception var10) {
					;
				}
			}

		}
	}

	String buildParamList() {
		StringBuffer sb = new StringBuffer();

		for (int j = 0; j < ffdcDumpParams.length; ++j) {
			sb.append(getTypeName(ffdcDumpParams[j]));
			if (j < ffdcDumpParams.length - 1) {
				sb.append(",");
			}
		}

		return sb.toString();
	}

	static String getTypeName(Class type) {
		if (type.isArray()) {
			try {
				Class cl = type;

				int dimensions;
				for (dimensions = 0; cl.isArray(); cl = cl.getComponentType()) {
					++dimensions;
				}

				StringBuffer sb = new StringBuffer();
				sb.append(cl.getName());

				for (int i = 0; i < dimensions; ++i) {
					sb.append("[]");
				}

				return sb.toString();
			} catch (Throwable var5) {
				;
			}
		}

		return type.getName();
	}

	void msg(Object o) {
		System.out.println(o);
	}
}