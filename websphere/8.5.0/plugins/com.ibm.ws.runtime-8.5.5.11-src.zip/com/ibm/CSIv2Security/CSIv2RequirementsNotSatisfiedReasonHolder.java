package com.ibm.CSIv2Security;

import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.Streamable;

public final class CSIv2RequirementsNotSatisfiedReasonHolder implements Streamable {
	public CSIv2RequirementsNotSatisfiedReason value = null;

	public CSIv2RequirementsNotSatisfiedReasonHolder() {
	}

	public CSIv2RequirementsNotSatisfiedReasonHolder(CSIv2RequirementsNotSatisfiedReason var1) {
		this.value = var1;
	}

	public void _read(InputStream var1) {
		this.value = CSIv2RequirementsNotSatisfiedReasonHelper.read(var1);
	}

	public void _write(OutputStream var1) {
		CSIv2RequirementsNotSatisfiedReasonHelper.write(var1, this.value);
	}

	public TypeCode _type() {
		return CSIv2RequirementsNotSatisfiedReasonHelper.type();
	}
}