package org.apache.http.client.utils;

public interface Idn {
	String toUnicode(String var1);
}