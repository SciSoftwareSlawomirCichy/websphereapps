package com.ibm.ws.wim.dao.derby;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.ws.wim.dao.QuerySet;

public class DerbyQuerySet extends QuerySet {
	static final String COPYRIGHT_NOTICE;

	public DerbyQuerySet() {
	}

	public DerbyQuerySet(String var1) {
		super(var1);
		this.initDerbySQL();
	}

	public void initDerbySQL() {
		this.selectSchema = "SELECT SCHEMANAME FROM SYS.SYSSCHEMAS WHERE SCHEMANAME = ? ";
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
	}
}