package com.ibm.wsspi.ssl;

public class WSPKIException extends Exception {
	public WSPKIException() {
	}

	public WSPKIException(String message) {
		super(message);
	}

	public WSPKIException(String message, Throwable cause) {
		super(message, cause);
	}

	public WSPKIException(Throwable cause) {
		super(cause);
	}
}