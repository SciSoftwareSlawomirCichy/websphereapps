package com.ibm.ejs.container;

import java.rmi.Remote;
import javax.rmi.CORBA.Tie;
import javax.rmi.CORBA.Util;
import org.omg.CORBA.BAD_OPERATION;
import org.omg.CORBA.ORB;
import org.omg.CORBA.SystemException;
import org.omg.CORBA.portable.Delegate;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ResponseHandler;
import org.omg.CORBA.portable.UnknownException;
import org.omg.CORBA_2_3.portable.ObjectImpl;

public class _EJBFactoryImpl_Tie extends ObjectImpl implements Tie {
	private EJBFactoryImpl target = null;
	private ORB orb = null;
	private static final String[] _type_ids = new String[]{
			"RMI:com.ibm.websphere.ejbcontainer.EJBFactory:0000000000000000",
			"RMI:com.ibm.websphere.csi.CSIServant:0000000000000000",
			"RMI:com.ibm.websphere.csi.TransactionalObject:0000000000000000"};

	public String[] _ids() {
		return (String[]) _type_ids.clone();
	}

	public OutputStream _invoke(String var1, InputStream var2, ResponseHandler var3) throws SystemException {
		try {
			org.omg.CORBA_2_3.portable.InputStream var4 = (org.omg.CORBA_2_3.portable.InputStream) var2;
			switch (var1.length()) {
				case 14 :
					if (var1.equals("findByBeanName")) {
						return this.findByBeanName(var4, var3);
					}
				case 15 :
					if (var1.equals("findByInterface")) {
						return this.findByInterface(var4, var3);
					}
				case 66 :
					if (var1.equals("create__CORBA_WStringValue__CORBA_WStringValue__CORBA_WStringValue")) {
						return this.create__CORBA_WStringValue__CORBA_WStringValue__CORBA_WStringValue(var4, var3);
					}
				case 86 :
					if (var1.equals(
							"create__CORBA_WStringValue__CORBA_WStringValue__CORBA_WStringValue__CORBA_WStringValue")) {
						return this
								.create__CORBA_WStringValue__CORBA_WStringValue__CORBA_WStringValue__CORBA_WStringValue(
										var4, var3);
					}
				default :
					throw new BAD_OPERATION();
			}
		} catch (SystemException var5) {
			throw var5;
		} catch (Throwable var6) {
			throw new UnknownException(var6);
		}
	}

	public void _set_delegate(Delegate var1) {
		super._set_delegate(var1);
		if (var1 != null) {
			this.orb = this._orb();
		} else {
			this.orb = null;
		}

	}

	private OutputStream create__CORBA_WStringValue__CORBA_WStringValue__CORBA_WStringValue(
			org.omg.CORBA_2_3.portable.InputStream var1, ResponseHandler var2) throws Throwable {
		String var3 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		String var4 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		String var5 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		Object var6 = this.target.create(var3, var4, var5);
		OutputStream var7 = var2.createReply();
		Util.writeAny(var7, var6);
		return var7;
	}

	private OutputStream create__CORBA_WStringValue__CORBA_WStringValue__CORBA_WStringValue__CORBA_WStringValue(
			org.omg.CORBA_2_3.portable.InputStream var1, ResponseHandler var2) throws Throwable {
		String var3 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		String var4 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		String var5 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		String var6 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		Object var7 = this.target.create(var3, var4, var5, var6);
		OutputStream var8 = var2.createReply();
		Util.writeAny(var8, var7);
		return var8;
	}

	public void deactivate() {
		if (this.orb != null) {
			this.orb.disconnect(this);
			this._set_delegate((Delegate) null);
		}

	}

	private OutputStream findByBeanName(org.omg.CORBA_2_3.portable.InputStream var1, ResponseHandler var2)
			throws Throwable {
		String var3 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		String var4 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		String var5 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		Object var6 = this.target.findByBeanName(var3, var4, var5);
		OutputStream var7 = var2.createReply();
		Util.writeAny(var7, var6);
		return var7;
	}

	private OutputStream findByInterface(org.omg.CORBA_2_3.portable.InputStream var1, ResponseHandler var2)
			throws Throwable {
		String var3 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		String var4 = (String) var1.read_value(class$java$lang$String != null
				? class$java$lang$String
				: (class$java$lang$String = class$("java.lang.String")));
		Object var5 = this.target.findByInterface(var3, var4);
		OutputStream var6 = var2.createReply();
		Util.writeAny(var6, var5);
		return var6;
	}

	public Remote getTarget() {
		return this.target;
	}

	public ORB orb() {
		return this._orb();
	}

	public void orb(ORB var1) {
		var1.connect(this);
	}

	public void setTarget(Remote var1) {
		this.target = (EJBFactoryImpl) var1;
	}

	public org.omg.CORBA.Object thisObject() {
		return this;
	}
}