package com.ibm.ws.wim.dao.db2;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.ws.wim.dao.AbstractDAO;

public class DB2DAO extends AbstractDAO {
	static final String COPYRIGHT_NOTICE;

	public DB2DAO(String var1, String var2, String var3, String var4, String var5) throws WIMException {
		super("db2", var1, var2, var3, var4, var5, new DB2QuerySet());
	}

	public DB2DAO(String var1, String var2, String var3, String var4, String var5, String var6) throws WIMException {
		super("db2", var1, var2, var3, var4, var5, var6, new DB2QuerySet(var3));
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
	}
}