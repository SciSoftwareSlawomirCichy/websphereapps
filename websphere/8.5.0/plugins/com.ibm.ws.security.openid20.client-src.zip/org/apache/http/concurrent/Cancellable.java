package org.apache.http.concurrent;

public interface Cancellable {
	boolean cancel();
}