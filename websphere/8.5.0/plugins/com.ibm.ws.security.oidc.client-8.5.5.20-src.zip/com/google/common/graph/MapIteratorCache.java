package com.google.common.graph;

import com.google.common.base.Preconditions;
import com.google.common.collect.UnmodifiableIterator;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

class MapIteratorCache<K, V> {
	private final Map<K, V> backingMap;
	@NullableDecl
	private transient Map.Entry<K, V> entrySetCache;

	MapIteratorCache(Map<K, V> backingMap) {
		this.backingMap = (Map) Preconditions.checkNotNull(backingMap);
	}

	@CanIgnoreReturnValue
	public V put(@NullableDecl K key, @NullableDecl V value) {
		this.clearCache();
		return this.backingMap.put(key, value);
	}

	@CanIgnoreReturnValue
	public V remove(@NullableDecl Object key) {
		this.clearCache();
		return this.backingMap.remove(key);
	}

	public void clear() {
		this.clearCache();
		this.backingMap.clear();
	}

	public V get(@NullableDecl Object key) {
		V value = this.getIfCached(key);
		return value != null ? value : this.getWithoutCaching(key);
	}

	public final V getWithoutCaching(@NullableDecl Object key) {
		return this.backingMap.get(key);
	}

	public final boolean containsKey(@NullableDecl Object key) {
		return this.getIfCached(key) != null || this.backingMap.containsKey(key);
	}

	public final Set<K> unmodifiableKeySet() {
		return new AbstractSet<K>() {
			public UnmodifiableIterator<K> iterator() {
				final Iterator<Map.Entry<K, V>> entryIterator = MapIteratorCache.this.backingMap.entrySet().iterator();
				return new UnmodifiableIterator<K>() {
					public boolean hasNext() {
						return entryIterator.hasNext();
					}

					public K next() {
						Map.Entry<K, V> entry = (Map.Entry) entryIterator.next();
						MapIteratorCache.this.entrySetCache = entry;
						return entry.getKey();
					}
				};
			}

			public int size() {
				return MapIteratorCache.this.backingMap.size();
			}

			public boolean contains(@NullableDecl Object key) {
				return MapIteratorCache.this.containsKey(key);
			}
		};
	}

	protected V getIfCached(@NullableDecl Object key) {
		Map.Entry<K, V> entry = this.entrySetCache;
		return entry != null && entry.getKey() == key ? entry.getValue() : null;
	}

	protected void clearCache() {
		this.entrySetCache = null;
	}
}