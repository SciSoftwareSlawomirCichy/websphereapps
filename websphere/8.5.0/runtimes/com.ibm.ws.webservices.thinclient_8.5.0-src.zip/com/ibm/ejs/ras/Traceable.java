package com.ibm.ejs.ras;

public interface Traceable {
	String toTraceString();
}