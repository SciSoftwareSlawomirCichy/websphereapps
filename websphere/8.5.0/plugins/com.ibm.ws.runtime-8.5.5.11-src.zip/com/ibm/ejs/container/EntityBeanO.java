package com.ibm.ejs.container;

import java.rmi.RemoteException;
import javax.ejb.EnterpriseBean;

public abstract class EntityBeanO extends BeanO {
	public EntityBeanO(EJSContainer container, EJSHome home) {
		super(container, home);
	}

	public abstract EnterpriseBean getEnterpriseBean() throws RemoteException;

	abstract void postFind() throws RemoteException;

	abstract void postHomeMethodCall();

	abstract void load(ContainerTx var1, boolean var2) throws RemoteException;

	abstract void enlistForOptionA(ContainerTx var1);

	abstract int getLockMode();
}