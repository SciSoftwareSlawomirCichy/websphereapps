package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.Multiset.Entry;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NavigableSet;
import java.util.Set;

@GwtCompatible(emulated = true)
public interface SortedMultiset<E> extends SortedMultisetBridge<E>, SortedIterable<E> {
	Comparator<? super E> comparator();

	Entry<E> firstEntry();

	Entry<E> lastEntry();

	Entry<E> pollFirstEntry();

	Entry<E> pollLastEntry();

	NavigableSet<E> elementSet();

	Set<Entry<E>> entrySet();

	Iterator<E> iterator();

	SortedMultiset<E> descendingMultiset();

	SortedMultiset<E> headMultiset(E var1, BoundType var2);

	SortedMultiset<E> subMultiset(E var1, BoundType var2, E var3, BoundType var4);

	SortedMultiset<E> tailMultiset(E var1, BoundType var2);
}