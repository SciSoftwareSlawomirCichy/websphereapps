package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.configmodel.AttributesCacheType;
import com.ibm.ws.wim.configmodel.CacheConfigurationType;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ContextPoolType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.PropertyExtensionRepositoryType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.configmodel.SearchResultsCacheType;
import com.ibm.ws.wim.env.IEncryptionUtil;
import commonj.sdo.DataObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConfigUtils implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = ConfigUtils.class.getName();
	private static final Logger trcLogger;

	public static ConfigurationProviderType getConfigProvider(String var0) throws WIMException {
		return ConfigSessionManager.singleton().getConfig(var0);
	}

	public static String saveConfig(String var0) throws WIMException {
		try {
			return ConfigSessionManager.singleton().saveConfig(var0, false);
		} catch (WIMException var2) {
			throw var2;
		} catch (Exception var3) {
			throw new WIMException(var3.getLocalizedMessage(), var3);
		}
	}

	public static void resetConfig(String var0) throws WIMException {
		try {
			ConfigSessionManager.singleton().resetConfig(var0);
		} catch (WIMException var2) {
			throw var2;
		} catch (Exception var3) {
			throw new WIMException(var3.getLocalizedMessage(), var3);
		}
	}

	public static List getProfileRepositories(ConfigurationProviderType var0) {
		ArrayList var1 = new ArrayList();
		List var2 = var0.getRepositories();

		for (int var3 = 0; var3 < var2.size(); ++var3) {
			RepositoryType var4 = (RepositoryType) var2.get(var3);
			if (!(var4 instanceof PropertyExtensionRepositoryType) && !(var4 instanceof EntryMappingRepositoryType)) {
				var1.add(var4);
			}
		}

		return var1;
	}

	public static List getProfileRepositories(String var0) throws WIMException {
		return getProfileRepositories(getConfigProvider(var0));
	}

	public static RepositoryType getRepositoryById(ConfigurationProviderType var0, String var1, boolean var2)
			throws WIMException {
		String var3 = "getRepositoryById";
		RepositoryType var4 = null;
		List var5 = var0.getRepositories();
		boolean var6 = false;

		for (int var7 = 0; var7 < var5.size(); ++var7) {
			RepositoryType var8 = (RepositoryType) var5.get(var7);
			if (var8.getId().equals(var1)) {
				var4 = var8;
				break;
			}
		}

		if (var4 == null && var2) {
			throw new WIMConfigurationException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateMsgParms(var1),
					Level.SEVERE, CLASSNAME, var3);
		} else {
			return var4;
		}
	}

	public static RepositoryType getRepositoryById(ConfigurationProviderType var0, String var1) throws WIMException {
		return getRepositoryById(var0, var1, true);
	}

	public static RepositoryType getRepositoryByIdIncludeLAandFED(String var0, String var1) throws WIMException {
		ConfigurationProviderType var3 = getConfigProvider(var0);
		Object var4 = null;
		if ("FED".equals(var1)) {
			var4 = var3.getEntryMappingRepository();
			if (var4 == null) {
				throw new WIMConfigurationException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateMsgParms(var1),
						Level.FINE, CLASSNAME, "getRepositoryByIdIncludeLAandFED");
			}
		} else if ("LA".equals(var1)) {
			var4 = var3.getPropertyExtensionRepository();
			if (var4 == null) {
				throw new WIMConfigurationException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateMsgParms(var1),
						Level.FINE, CLASSNAME, "getRepositoryByIdIncludeLAandFED");
			}
		} else {
			var4 = getRepositoryById(var0, var1);
		}

		return (RepositoryType) var4;
	}

	public static RepositoryType getRepositoryById(String var0, String var1, boolean var2) throws WIMException {
		return getRepositoryById(getConfigProvider(var0), var1, var2);
	}

	public static RepositoryType getRepositoryById(String var0, String var1) throws WIMException {
		return getRepositoryById(getConfigProvider(var0), var1, true);
	}

	public static RepositoryType validateAndGetRepository(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		String var3 = "validateAndGetRepository";
		RepositoryType var4 = getRepositoryById(var0, var1);
		if (var2 != null) {
			String var5 = ((DataObject) var4).getType().getName();
			if (!var5.equals(var2)) {
				throw new WIMConfigurationException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateMsgParms(var1),
						Level.SEVERE, CLASSNAME, var3);
			}
		}

		return var4;
	}

	public static RepositoryType validateAndGetRepository(String var0, String var1, String var2) throws WIMException {
		return validateAndGetRepository(getConfigProvider(var0), var1, var2);
	}

	public static void checkForValidRepositoryById(String var0, String var1) throws WIMException {
		String var2 = "checkForValidRepositoryById";
		RepositoryType var3 = getRepositoryById(var0, var1, false);
		if (var3 != null) {
			throw new WIMConfigurationException("REPOSITORY_ID_ALREADY_EXISTS", WIMMessageHelper.generateMsgParms(var1),
					Level.SEVERE, CLASSNAME, var2);
		} else {
			for (int var4 = 0; var4 < RESERVED_REPOSITORY_IDS.length; ++var4) {
				if (RESERVED_REPOSITORY_IDS[var4].equals(var1)) {
					throw new WIMConfigurationException("REPOSITORY_ID_RESERVED",
							WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, CLASSNAME, var2);
				}
			}

		}
	}

	public static Object getParamValue(Map var0, Map var1, String var2, boolean var3) {
		Object var4 = var0.get(var2);
		if (!var3 && var4 == null) {
			var4 = var1.get(var2);
		}

		return var4;
	}

	public static void setCommonRepositoryProperties(ProfileRepositoryType var0, Map var1, Map var2, boolean var3)
			throws WIMException {
		Object var4 = getParamValue(var1, var2, "adapterClassName", var3);
		if (var4 != null) {
			var0.setAdapterClassName((String) var4);
		}

		var4 = getParamValue(var1, var2, "supportPaging", var3);
		if (var4 != null) {
			var0.setSupportPaging((Boolean) var4);
		}

		var4 = getParamValue(var1, var2, "supportSorting", var3);
		if (var4 != null) {
			var0.setSupportSorting((Boolean) var4);
		}

		var4 = getParamValue(var1, var2, "supportTransactions", var3);
		if (var4 != null) {
			var0.setSupportTransactions((Boolean) var4);
		}

		var4 = getParamValue(var1, var2, "isExtIdUnique", var3);
		if (var4 != null) {
			var0.setIsExtIdUnique((Boolean) var4);
		}

		var4 = getParamValue(var1, var2, "supportExternalName", var3);
		if (var4 != null) {
			var0.setSupportExternalName((Boolean) var4);
		}

		var4 = getParamValue(var1, var2, "supportAsyncMode", var3);
		if (var4 != null) {
			var0.setSupportAsyncMode((Boolean) var4);
		}

	}

	public static RealmConfigurationType getOrCreateRealmConfig(String var0) throws Exception {
		ConfigurationProviderType var1 = getConfigProvider(var0);
		RealmConfigurationType var2 = var1.getRealmConfiguration();
		if (var2 == null) {
			var2 = var1.createRealmConfiguration();
		}

		return var2;
	}

	public static ContextPoolType getOrCreateContextPool(LdapRepositoryType var0) throws WIMException {
		ContextPoolType var1 = var0.getContextPool();
		if (var1 == null) {
			var1 = var0.createContextPool();
		}

		return var1;
	}

	public static CacheConfigurationType getOrCreateCacheConfiguration(LdapRepositoryType var0) throws WIMException {
		CacheConfigurationType var1 = var0.getCacheConfiguration();
		if (var1 == null) {
			var1 = var0.createCacheConfiguration();
		}

		return var1;
	}

	public static AttributesCacheType getOrCreateAttributesCache(LdapRepositoryType var0) throws WIMException {
		CacheConfigurationType var1 = getOrCreateCacheConfiguration(var0);
		AttributesCacheType var2 = var1.getAttributesCache();
		if (var2 == null) {
			var2 = var1.createAttributesCache();
		}

		return var2;
	}

	public static SearchResultsCacheType getOrCreateSearchResultsCache(LdapRepositoryType var0) throws WIMException {
		CacheConfigurationType var1 = getOrCreateCacheConfiguration(var0);
		SearchResultsCacheType var2 = var1.getSearchResultsCache();
		if (var2 == null) {
			var2 = var1.createSearchResultsCache();
		}

		return var2;
	}

	public static RealmConfigurationType getRealmConfig(String var0) throws WIMException {
		String var1 = "getRealmConfig";
		ConfigurationProviderType var2 = ConfigSessionManager.singleton().getConfig(var0);
		RealmConfigurationType var3 = var2.getRealmConfiguration();
		if (var3 == null) {
			throw new WIMConfigurationException("MISSING_REALM_CONFIGURATION", Level.SEVERE, CLASSNAME, var1);
		} else {
			return var3;
		}
	}

	public static RealmType getRealm(String var0, RealmConfigurationType var1, boolean var2) throws WIMException {
		String var3 = "getRealm";
		RealmType var4 = null;
		List var5 = var1.getRealms();

		for (int var6 = 0; var6 < var5.size(); ++var6) {
			RealmType var7 = (RealmType) var5.get(var6);
			if (var0.equals(var7.getName())) {
				var4 = var7;
				break;
			}
		}

		if (var4 == null && var2) {
			throw new WIMConfigurationException("INVALID_REALM_NAME", WIMMessageHelper.generateMsgParms(var0),
					Level.SEVERE, CLASSNAME, var3);
		} else {
			return var4;
		}
	}

	public static RealmType getRealm(String var0, RealmConfigurationType var1) throws WIMException {
		return getRealm(var0, var1, true);
	}

	public static ParticipatingBaseEntriesType getBaseEntryInRealm(String var0, RealmType var1) throws WIMException {
		String var2 = "getBaseEntryInRealm";
		ParticipatingBaseEntriesType var3 = null;
		List var4 = var1.getParticipatingBaseEntries();

		for (int var5 = 0; var5 < var4.size(); ++var5) {
			ParticipatingBaseEntriesType var6 = (ParticipatingBaseEntriesType) var4.get(var5);
			if (var0.equals(var6.getName())) {
				var3 = var6;
				break;
			}
		}

		if (var3 == null) {
			throw new WIMConfigurationException("BASE_ENTRY_NOT_FOUND_IN_REALM",
					WIMMessageHelper.generateMsgParms(var0, var1.getName()), Level.SEVERE, CLASSNAME, var2);
		} else {
			return var3;
		}
	}

	public static List convertEList(List var0) {
		ArrayList var1 = new ArrayList();
		var1.addAll(var0);
		return var1;
	}

	public static List convertArrayToList(String[] var0) {
		ArrayList var1 = new ArrayList();

		for (int var2 = 0; var2 < var0.length; ++var2) {
			var1.add(var0[var2]);
		}

		return var1;
	}

	public static void addOrRemovePresentList(String var0, List var1, List var2) {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.logp(Level.FINER, CLASSNAME, "addOrRemovePresentList",
					"elementName=" + var0 + ", valueList=" + var1);
			trcLogger.logp(Level.FINER, CLASSNAME, "addOrRemovePresentList", "presentList=" + var2);
		}

		if (var1 != null) {
			if (var1.size() == 0) {
				trcLogger.logp(Level.FINER, CLASSNAME, "addOrRemovePresentList", "deleting all values.");
				var2.clear();
			} else {
				for (int var5 = 0; var5 < var1.size(); ++var5) {
					String var6 = (String) var1.get(var5);
					if (!var2.contains(var6)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "addOrRemovePresentList",
								"adding " + var6 + " to " + var0);
						var2.add(var6);
					}
				}
			}
		}

	}

	public static boolean buildMapFromOldAndNewValues(Map var0, String[] var1, DataObject var2, Map var3) {
		boolean var4 = false;

		int var5;
		for (var5 = 0; var5 < var1.length; ++var5) {
			if (var3.containsKey(var1[var5])) {
				var4 = true;
				break;
			}
		}

		if (var4) {
			for (var5 = 0; var5 < var1.length; ++var5) {
				String var6 = var1[var5];
				if (var3.containsKey(var6)) {
					var0.put(var6, var3.get(var6));
				} else if (var2.isSet(var6)) {
					var0.put(var6, var2.get(var6));
				}
			}
		}

		return var4;
	}

	public static String getRepositoryType(RepositoryType var0) {
		if (var0 instanceof LdapRepositoryType) {
			return "LdapRepositoryType";
		} else if (var0 instanceof FileRepositoryType) {
			return "FileRepositoryType";
		} else if (var0 instanceof DatabaseRepositoryType) {
			return "DatabaseRepositoryType";
		} else if (var0 instanceof PropertyExtensionRepositoryType) {
			return "propertyExtensionRepository";
		} else {
			return var0 instanceof EntryMappingRepositoryType ? "entryMappingRepository" : var0.getClass().getName();
		}
	}

	protected static String encodePassword(String var0) {
		if (var0 != null && !var0.equals("")) {
			IEncryptionUtil var1 = FactoryManager.getEncryptionUtil();
			return var1.encode(var0);
		} else {
			return var0;
		}
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}