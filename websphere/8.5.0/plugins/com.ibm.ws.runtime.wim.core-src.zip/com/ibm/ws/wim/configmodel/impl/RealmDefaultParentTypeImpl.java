package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.RealmDefaultParentType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class RealmDefaultParentTypeImpl extends EDataObjectImpl implements RealmDefaultParentType {
	protected static final String ENTITY_TYPE_NAME_EDEFAULT = null;
	protected String entityTypeName;
	protected static final String PARENT_UNIQUE_NAME_EDEFAULT = null;
	protected String parentUniqueName;

	protected RealmDefaultParentTypeImpl() {
		this.entityTypeName = ENTITY_TYPE_NAME_EDEFAULT;
		this.parentUniqueName = PARENT_UNIQUE_NAME_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getRealmDefaultParentType();
	}

	public String getEntityTypeName() {
		return this.entityTypeName;
	}

	public void setEntityTypeName(String var1) {
		String var2 = this.entityTypeName;
		this.entityTypeName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.entityTypeName));
		}

	}

	public String getParentUniqueName() {
		return this.parentUniqueName;
	}

	public void setParentUniqueName(String var1) {
		String var2 = this.parentUniqueName;
		this.parentUniqueName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.parentUniqueName));
		}

	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getEntityTypeName();
			case 1 :
				return this.getParentUniqueName();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setEntityTypeName((String) var2);
				return;
			case 1 :
				this.setParentUniqueName((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setEntityTypeName(ENTITY_TYPE_NAME_EDEFAULT);
				return;
			case 1 :
				this.setParentUniqueName(PARENT_UNIQUE_NAME_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return ENTITY_TYPE_NAME_EDEFAULT == null
						? this.entityTypeName != null
						: !ENTITY_TYPE_NAME_EDEFAULT.equals(this.entityTypeName);
			case 1 :
				return PARENT_UNIQUE_NAME_EDEFAULT == null
						? this.parentUniqueName != null
						: !PARENT_UNIQUE_NAME_EDEFAULT.equals(this.parentUniqueName);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (entityTypeName: ");
			var1.append(this.entityTypeName);
			var1.append(", parentUniqueName: ");
			var1.append(this.parentUniqueName);
			var1.append(')');
			return var1.toString();
		}
	}
}