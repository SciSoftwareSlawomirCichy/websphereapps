package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Interners.1;
import com.google.common.collect.Interners.InternerBuilder;
import com.google.common.collect.Interners.InternerFunction;

@Beta
@GwtIncompatible
public final class Interners {
	public static InternerBuilder newBuilder() {
      return new InternerBuilder((1)null);
   }

	public static <E> Interner<E> newStrongInterner() {
		return newBuilder().strong().build();
	}

	@GwtIncompatible("java.lang.ref.WeakReference")
	public static <E> Interner<E> newWeakInterner() {
		return newBuilder().weak().build();
	}

	public static <E> Function<E, E> asFunction(Interner<E> interner) {
		return new InternerFunction((Interner) Preconditions.checkNotNull(interner));
	}
}