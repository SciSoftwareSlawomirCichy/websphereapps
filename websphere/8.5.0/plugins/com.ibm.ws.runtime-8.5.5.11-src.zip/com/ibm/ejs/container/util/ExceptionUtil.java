package com.ibm.ejs.container.util;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerException;
import com.ibm.ejs.container.UncheckedException;
import com.ibm.ejs.persistence.EJSPersistenceException;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.cpi.CPIException;
import com.ibm.websphere.cpmi.CPMIException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;
import com.ibm.ws.exception.WsNestedException;
import com.ibm.ws.javax.ejb.ActivityCompletedLocalException;
import com.ibm.ws.javax.ejb.ActivityRequiredLocalException;
import com.ibm.ws.javax.ejb.InvalidActivityLocalException;
import com.ibm.wsspi.injectionengine.InjectionException;
import com.ibm.wsspi.injectionengine.RecursiveInjectionException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import javax.ejb.AccessLocalException;
import javax.ejb.EJBException;
import javax.ejb.NoSuchEJBException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.TransactionRequiredLocalException;
import javax.ejb.TransactionRolledbackLocalException;
import javax.naming.NamingException;
import org.omg.CORBA.portable.UnknownException;

public class ExceptionUtil {
	private static TraceComponent tc = Tr.register(ExceptionUtil.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public static final String throwableToString(Throwable t) {
		StringWriter s = new StringWriter();
		PrintWriter p = new PrintWriter(s);
		printStackTrace(t, p);
		return s.toString();
	}

	private static final boolean hasBeenLogged(Throwable t) {
		boolean hasBeenLogged = false;
		Throwable cause = t;

		for (Throwable lastCause = null; cause != null && cause != lastCause; cause = cause.getCause()) {
			if (cause instanceof RecursiveInjectionException) {
				if (((RecursiveInjectionException) cause).ivLogged) {
					hasBeenLogged = true;
				} else {
					((RecursiveInjectionException) cause).ivLogged = true;
					hasBeenLogged = false;
				}
				break;
			}

			lastCause = cause;
		}

		return hasBeenLogged;
	}

	public static final void logException(TraceComponent compTc, Throwable t, EJBMethodMetaData m, BeanO bean) {
		if (!hasBeenLogged(t)) {
			BeanId beanId = null;
			if (bean != null) {
				beanId = bean.getId();
			}

			if (m == null) {
				if (beanId == null) {
					Tr.error(compTc, "NON_APPLICATION_EXCEPTION_CNTR0018E", t);
				} else {
					Tr.error(compTc, "NON_APPLICATION_EXCEPTION_ON_BEAN_CNTR0021E", new Object[]{t, beanId});
				}
			} else {
				String methodName = m.getMethodName();
				if (beanId == null) {
					Tr.error(compTc, "NON_APPLICATION_EXCEPTION_METHOD_CNTR0019E", new Object[]{t, methodName});
				} else {
					Tr.error(compTc, "NON_APPLICATION_EXCEPTION_METHOD_ON_BEAN_CNTR0020E",
							new Object[]{t, methodName, beanId});
				}
			}

		}
	}

	public static void logException(Throwable t) {
		logException(tc, t, (EJBMethodMetaData) null, (BeanO) null);
	}

	private static final void printStackTrace(Throwable t, PrintWriter p) {
		t.printStackTrace(p);
	}

	public static Throwable findRootCause(Throwable throwable) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "findRootCause: " + throwable);
		}

		Throwable root = throwable;
		Throwable next = throwable;

		while (next != null) {
			root = next;
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "finding cause of: " + next.getClass().getName());
			}

			if (next instanceof RemoteException) {
				next = ((RemoteException) next).detail;
			} else if (next instanceof WsNestedException) {
				next = ((WsNestedException) next).getCause();
			} else if (next instanceof TransactionRolledbackLocalException) {
				next = ((TransactionRolledbackLocalException) next).getCause();
			} else if (next instanceof AccessLocalException) {
				next = ((AccessLocalException) next).getCause();
			} else if (next instanceof NoSuchObjectLocalException) {
				next = ((NoSuchObjectLocalException) next).getCause();
			} else if (next instanceof TransactionRequiredLocalException) {
				next = ((TransactionRequiredLocalException) next).getCause();
			} else if (next instanceof InvalidActivityLocalException) {
				root = ((InvalidActivityLocalException) next).getCause();
			} else if (next instanceof ActivityRequiredLocalException) {
				root = ((ActivityRequiredLocalException) next).getCause();
			} else if (next instanceof ActivityCompletedLocalException) {
				next = ((ActivityCompletedLocalException) next).getCause();
			} else if (next instanceof NamingException) {
				next = ((NamingException) next).getRootCause();
			} else if (next instanceof InvocationTargetException) {
				next = ((InvocationTargetException) next).getTargetException();
			} else if (next instanceof UnknownException) {
				next = ((UnknownException) next).originalEx;
			} else if (next instanceof InjectionException) {
				next = next.getCause();
			} else {
				next = null;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "findRootCause returning: " + root);
		}

		return root;
	}

	public static Throwable findCause(Throwable throwable) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "findCause: " + throwable);
		}

		Throwable cause = throwable.getCause();
		if (cause == null && throwable instanceof EJBException) {
			cause = ((EJBException) throwable).getCausedByException();
		}

		if (cause != null) {
			while (cause instanceof ContainerException || cause instanceof UncheckedException
					|| cause instanceof EJSPersistenceException || cause instanceof CPIException
					|| cause instanceof CPMIException || cause instanceof CSIException
					|| cause instanceof InjectionException
					|| cause instanceof EJBException && cause instanceof WsNestedException) {
				Throwable nextCause = ((Throwable) cause).getCause();
				if (nextCause == null) {
					StackTraceElement[] stackTrace = ((Throwable) cause).getStackTrace();
					cause = new EJBException(((Throwable) cause).getMessage());
					((Throwable) cause).setStackTrace(stackTrace);
				} else {
					cause = nextCause;
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "findCause: " + cause);
		}

		return (Throwable) cause;
	}

	public static Exception Exception(Throwable cause) {
		return cause instanceof Exception ? (Exception) cause : new Exception("See nested Throwable", cause);
	}

	public static EJBException EJBException(Throwable cause) {
		return EJBException("See nested exception", cause);
	}

	public static EJBException EJBException(String message, Throwable cause) {
		EJBException ejbex = null;
		if (cause == null) {
			ejbex = new EJBException(message);
		}

		Throwable nextCause;
		for (; cause != null && !(cause instanceof RecursiveInjectionException)
				&& (cause instanceof ContainerException || cause instanceof UncheckedException
						|| cause instanceof EJSPersistenceException || cause instanceof CPIException
						|| cause instanceof CPMIException || cause instanceof CSIException
						|| cause instanceof InjectionException
						|| cause instanceof EJBException && cause instanceof WsNestedException); cause = nextCause) {
			nextCause = cause.getCause();
			if (nextCause == null) {
				ejbex = new EJBException(cause.getMessage());
				ejbex.setStackTrace(cause.getStackTrace());
			}
		}

		if (ejbex == null) {
			if (cause instanceof EJBException) {
				ejbex = (EJBException) cause;
				Throwable cause = ejbex.getCausedByException();
				if (cause != null && ejbex.getCause() == null) {
					ejbex.initCause(cause);
				}
			} else {
				ejbex = new EJBException(message, Exception(cause));
				if (ejbex.getCause() == null) {
					ejbex.initCause(cause);
				}
			}
		}

		return ejbex;
	}

	public static NoSuchEJBException NoSuchEJBException(String message, Throwable cause) {
		NoSuchEJBException nsejb;
		if (cause == null) {
			nsejb = new NoSuchEJBException(message);
		} else {
			if (cause instanceof Exception) {
				nsejb = new NoSuchEJBException(message, (Exception) cause);
			} else {
				Exception wrappedCause = new Exception("See nested Throwable", (Throwable) cause);
				nsejb = new NoSuchEJBException(message, wrappedCause);
				cause = wrappedCause;
			}

			if (nsejb.getCause() == null) {
				nsejb.initCause((Throwable) cause);
			}
		}

		return nsejb;
	}

	public static RemoteException RemoteException(Throwable cause) {
		return RemoteException("See nested exception", cause);
	}

	public static RemoteException RemoteException(String message, Throwable cause) {
		RemoteException remote = null;
		if (cause == null) {
			remote = new RemoteException(message);
		}

		Throwable nextCause;
		for (; cause != null && (cause instanceof ContainerException || cause instanceof UncheckedException
				|| cause instanceof EJSPersistenceException || cause instanceof CPIException
				|| cause instanceof CPMIException || cause instanceof CSIException
				|| cause instanceof InjectionException
				|| cause instanceof EJBException && cause instanceof WsNestedException); cause = nextCause) {
			nextCause = cause.getCause();
			if (nextCause == null) {
				remote = new RemoteException(cause.getMessage());
				remote.setStackTrace(cause.getStackTrace());
			}
		}

		if (remote == null) {
			if (cause instanceof RemoteException) {
				remote = (RemoteException) cause;
			} else {
				remote = new RemoteException(message, cause);
			}
		}

		return remote;
	}

	public static String getBaseMessage(Throwable exception) {
		String message = null;
		if (exception instanceof RemoteException) {
			RemoteException rex = (RemoteException) exception;
			Throwable detail = rex.detail;
			rex.detail = null;
			message = rex.getMessage();
			rex.detail = detail;
			if ("".equals(message) && detail != null) {
				message = getBaseMessage(detail);
			}
		} else if (exception != null) {
			message = exception.getMessage();
			if (message != null) {
				if (message.startsWith("nested exception is:")) {
					message = null;
				} else {
					int nestIndex = message.indexOf("; nested exception is:");
					if (nestIndex > -1) {
						message = message.substring(0, nestIndex);
					}
				}
			}
		}

		return message;
	}
}