package com.ibm.ffdc.util;

public class Klass {
	public static boolean isPrimitive(Class<?> cl) {
		return cl.isPrimitive() || cl.equals(Integer.class) || cl.equals(Byte.class) || cl.equals(Short.class)
				|| cl.equals(Long.class) || cl.equals(Float.class) || cl.equals(Double.class)
				|| cl.equals(Boolean.class) || cl.equals(Character.class);
	}

	public static boolean isByte(Class<?> cl) {
		return cl.equals(Byte.TYPE);
	}
}