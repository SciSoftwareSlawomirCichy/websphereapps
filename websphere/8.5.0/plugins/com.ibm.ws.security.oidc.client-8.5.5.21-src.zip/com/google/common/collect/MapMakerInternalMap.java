package com.google.common.collect;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Equivalence;
import com.google.common.base.Preconditions;
import com.google.common.collect.MapMaker.Dummy;
import com.google.common.collect.MapMakerInternalMap.1;
import com.google.common.collect.MapMakerInternalMap.DummyInternalEntry;
import com.google.common.collect.MapMakerInternalMap.EntrySet;
import com.google.common.collect.MapMakerInternalMap.InternalEntry;
import com.google.common.collect.MapMakerInternalMap.InternalEntryHelper;
import com.google.common.collect.MapMakerInternalMap.KeySet;
import com.google.common.collect.MapMakerInternalMap.Segment;
import com.google.common.collect.MapMakerInternalMap.SerializationProxy;
import com.google.common.collect.MapMakerInternalMap.Strength;
import com.google.common.collect.MapMakerInternalMap.Values;
import com.google.common.collect.MapMakerInternalMap.WeakValueReference;
import com.google.common.collect.MapMakerInternalMap.StrongKeyStrongValueEntry.Helper;
import com.google.common.primitives.Ints;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReferenceArray;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtIncompatible
class MapMakerInternalMap<K, V, E extends InternalEntry<K, V, E>, S extends Segment<K, V, E, S>>
		extends
			AbstractMap<K, V>
		implements
			ConcurrentMap<K, V>,
			Serializable {
	static final int MAXIMUM_CAPACITY = 1073741824;
	static final int MAX_SEGMENTS = 65536;
	static final int CONTAINS_VALUE_RETRIES = 3;
	static final int DRAIN_THRESHOLD = 63;
	static final int DRAIN_MAX = 16;
	static final long CLEANUP_EXECUTOR_DELAY_SECS = 60L;
	final transient int segmentMask;
	final transient int segmentShift;
	final transient Segment<K, V, E, S>[] segments;
	final int concurrencyLevel;
	final Equivalence<Object> keyEquivalence;
	final transient InternalEntryHelper<K, V, E, S> entryHelper;
	static final WeakValueReference<Object, Object, DummyInternalEntry> UNSET_WEAK_VALUE_REFERENCE = new 1();
	@MonotonicNonNullDecl
	transient Set<K> keySet;
	@MonotonicNonNullDecl
	transient Collection<V> values;
	@MonotonicNonNullDecl
	transient Set<Entry<K, V>> entrySet;
	private static final long serialVersionUID = 5L;

	private MapMakerInternalMap(MapMaker builder, InternalEntryHelper<K, V, E, S> entryHelper) {
		this.concurrencyLevel = Math.min(builder.getConcurrencyLevel(), 65536);
		this.keyEquivalence = builder.getKeyEquivalence();
		this.entryHelper = entryHelper;
		int initialCapacity = Math.min(builder.getInitialCapacity(), 1073741824);
		int segmentShift = 0;

		int segmentCount;
		for (segmentCount = 1; segmentCount < this.concurrencyLevel; segmentCount <<= 1) {
			++segmentShift;
		}

		this.segmentShift = 32 - segmentShift;
		this.segmentMask = segmentCount - 1;
		this.segments = this.newSegmentArray(segmentCount);
		int segmentCapacity = initialCapacity / segmentCount;
		if (segmentCapacity * segmentCount < initialCapacity) {
			++segmentCapacity;
		}

		int segmentSize;
		for (segmentSize = 1; segmentSize < segmentCapacity; segmentSize <<= 1) {
			;
		}

		for (int i = 0; i < this.segments.length; ++i) {
			this.segments[i] = this.createSegment(segmentSize, -1);
		}

	}

	static <K, V> MapMakerInternalMap<K, V, ? extends InternalEntry<K, V, ?>, ?> create(MapMaker builder) {
		if (builder.getKeyStrength() == Strength.STRONG && builder.getValueStrength() == Strength.STRONG) {
			return new MapMakerInternalMap(builder, Helper.instance());
		} else if (builder.getKeyStrength() == Strength.STRONG && builder.getValueStrength() == Strength.WEAK) {
			return new MapMakerInternalMap(builder,
					com.google.common.collect.MapMakerInternalMap.StrongKeyWeakValueEntry.Helper.instance());
		} else if (builder.getKeyStrength() == Strength.WEAK && builder.getValueStrength() == Strength.STRONG) {
			return new MapMakerInternalMap(builder,
					com.google.common.collect.MapMakerInternalMap.WeakKeyStrongValueEntry.Helper.instance());
		} else if (builder.getKeyStrength() == Strength.WEAK && builder.getValueStrength() == Strength.WEAK) {
			return new MapMakerInternalMap(builder,
					com.google.common.collect.MapMakerInternalMap.WeakKeyWeakValueEntry.Helper.instance());
		} else {
			throw new AssertionError();
		}
	}

	static <K> MapMakerInternalMap<K, Dummy, ? extends InternalEntry<K, Dummy, ?>, ?> createWithDummyValues(
			MapMaker builder) {
		if (builder.getKeyStrength() == Strength.STRONG && builder.getValueStrength() == Strength.STRONG) {
			return new MapMakerInternalMap(builder,
					com.google.common.collect.MapMakerInternalMap.StrongKeyDummyValueEntry.Helper.instance());
		} else if (builder.getKeyStrength() == Strength.WEAK && builder.getValueStrength() == Strength.STRONG) {
			return new MapMakerInternalMap(builder,
					com.google.common.collect.MapMakerInternalMap.WeakKeyDummyValueEntry.Helper.instance());
		} else if (builder.getValueStrength() == Strength.WEAK) {
			throw new IllegalArgumentException("Map cannot have both weak and dummy values");
		} else {
			throw new AssertionError();
		}
	}

	static <K, V, E extends InternalEntry<K, V, E>> WeakValueReference<K, V, E> unsetWeakValueReference() {
		return UNSET_WEAK_VALUE_REFERENCE;
	}

	static int rehash(int h) {
		h += h << 15 ^ -12931;
		h ^= h >>> 10;
		h += h << 3;
		h ^= h >>> 6;
		h += (h << 2) + (h << 14);
		return h ^ h >>> 16;
	}

	@VisibleForTesting
	E copyEntry(E original, E newNext) {
		int hash = original.getHash();
		return this.segmentFor(hash).copyEntry(original, newNext);
	}

	int hash(Object key) {
		int h = this.keyEquivalence.hash(key);
		return rehash(h);
	}

	void reclaimValue(WeakValueReference<K, V, E> valueReference) {
		E entry = valueReference.getEntry();
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimValue(entry.getKey(), hash, valueReference);
	}

	void reclaimKey(E entry) {
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimKey(entry, hash);
	}

	@VisibleForTesting
	boolean isLiveForTesting(InternalEntry<K, V, ?> entry) {
		return this.segmentFor(entry.getHash()).getLiveValueForTesting(entry) != null;
	}

	Segment<K, V, E, S> segmentFor(int hash) {
		return this.segments[hash >>> this.segmentShift & this.segmentMask];
	}

	Segment<K, V, E, S> createSegment(int initialCapacity, int maxSegmentSize) {
		return this.entryHelper.newSegment(this, initialCapacity, maxSegmentSize);
	}

	V getLiveValue(E entry) {
		if (entry.getKey() == null) {
			return null;
		} else {
			V value = entry.getValue();
			return value == null ? null : value;
		}
	}

	final Segment<K, V, E, S>[] newSegmentArray(int ssize) {
		return new Segment[ssize];
	}

	@VisibleForTesting
	Strength keyStrength() {
		return this.entryHelper.keyStrength();
	}

	@VisibleForTesting
	Strength valueStrength() {
		return this.entryHelper.valueStrength();
	}

	@VisibleForTesting
	Equivalence<Object> valueEquivalence() {
		return this.entryHelper.valueStrength().defaultEquivalence();
	}

	public boolean isEmpty() {
		long sum = 0L;
		Segment<K, V, E, S>[] segments = this.segments;

		int i;
		for (i = 0; i < segments.length; ++i) {
			if (segments[i].count != 0) {
				return false;
			}

			sum += (long) segments[i].modCount;
		}

		if (sum != 0L) {
			for (i = 0; i < segments.length; ++i) {
				if (segments[i].count != 0) {
					return false;
				}

				sum -= (long) segments[i].modCount;
			}

			if (sum != 0L) {
				return false;
			}
		}

		return true;
	}

	public int size() {
		Segment<K, V, E, S>[] segments = this.segments;
		long sum = 0L;

		for (int i = 0; i < segments.length; ++i) {
			sum += (long) segments[i].count;
		}

		return Ints.saturatedCast(sum);
	}

	public V get(@NullableDecl Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).get(key, hash);
		}
	}

	E getEntry(@NullableDecl Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).getEntry(key, hash);
		}
	}

	public boolean containsKey(@NullableDecl Object key) {
		if (key == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).containsKey(key, hash);
		}
	}

	public boolean containsValue(@NullableDecl Object value) {
		if (value == null) {
			return false;
		} else {
			Segment<K, V, E, S>[] segments = this.segments;
			long last = -1L;

			for (int i = 0; i < 3; ++i) {
				long sum = 0L;
				Segment[] var8 = segments;
				int var9 = segments.length;

				for (int var10 = 0; var10 < var9; ++var10) {
					Segment<K, V, E, S> segment = var8[var10];
					int unused = segment.count;
					AtomicReferenceArray<E> table = segment.table;

					for (int j = 0; j < table.length(); ++j) {
						for (InternalEntry e = (InternalEntry) table.get(j); e != null; e = e.getNext()) {
							V v = segment.getLiveValue(e);
							if (v != null && this.valueEquivalence().equivalent(value, v)) {
								return true;
							}
						}
					}

					sum += (long) segment.modCount;
				}

				if (sum == last) {
					break;
				}

				last = sum;
			}

			return false;
		}
	}

	@CanIgnoreReturnValue
	public V put(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, false);
	}

	@CanIgnoreReturnValue
	public V putIfAbsent(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, true);
	}

	public void putAll(Map<? extends K, ? extends V> m) {
		Iterator var2 = m.entrySet().iterator();

		while (var2.hasNext()) {
			Entry<? extends K, ? extends V> e = (Entry) var2.next();
			this.put(e.getKey(), e.getValue());
		}

	}

	@CanIgnoreReturnValue
	public V remove(@NullableDecl Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash);
		}
	}

	@CanIgnoreReturnValue
	public boolean remove(@NullableDecl Object key, @NullableDecl Object value) {
		if (key != null && value != null) {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash, value);
		} else {
			return false;
		}
	}

	@CanIgnoreReturnValue
	public boolean replace(K key, @NullableDecl V oldValue, V newValue) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(newValue);
		if (oldValue == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).replace(key, hash, oldValue, newValue);
		}
	}

	@CanIgnoreReturnValue
	public V replace(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).replace(key, hash, value);
	}

	public void clear() {
		Segment[] var1 = this.segments;
		int var2 = var1.length;

		for (int var3 = 0; var3 < var2; ++var3) {
			Segment<K, V, E, S> segment = var1[var3];
			segment.clear();
		}

	}

	public Set<K> keySet() {
		Set<K> ks = this.keySet;
		return ks != null ? ks : (this.keySet = new KeySet(this));
	}

	public Collection<V> values() {
		Collection<V> vs = this.values;
		return vs != null ? vs : (this.values = new Values(this));
	}

	public Set<Entry<K, V>> entrySet() {
		Set<Entry<K, V>> es = this.entrySet;
		return es != null ? es : (this.entrySet = new EntrySet(this));
	}

	private static <E> ArrayList<E> toArrayList(Collection<E> c) {
		ArrayList<E> result = new ArrayList(c.size());
		Iterators.addAll(result, c.iterator());
		return result;
	}

	Object writeReplace() {
		return new SerializationProxy(this.entryHelper.keyStrength(), this.entryHelper.valueStrength(),
				this.keyEquivalence, this.entryHelper.valueStrength().defaultEquivalence(), this.concurrencyLevel,
				this);
	}
}