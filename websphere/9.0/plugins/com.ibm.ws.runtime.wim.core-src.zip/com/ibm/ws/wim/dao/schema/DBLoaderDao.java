package com.ibm.ws.wim.dao.schema;

import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.adapter.db.DBCompositeRelation;
import com.ibm.ws.wim.adapter.db.DBProperty;
import com.ibm.ws.wim.adapter.db.DBPropertyEntity;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.LocalKeyManager;
import com.ibm.ws.wim.dao.QuerySet;
import com.ibm.ws.wim.dao.db2.DB2QuerySet;
import com.ibm.ws.wim.lookaside.LACompositeRelation;
import com.ibm.ws.wim.lookaside.LAProperty;
import com.ibm.ws.wim.lookaside.LAPropertyEntity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;

public class DBLoaderDao {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public static final String CLASSNAME = DBLoaderDao.class.getName();
	private static final Logger trcLogger;
	private String url;
	private String driver;
	private String user;
	private String password;
	private String dbschema;
	private boolean traceOn;
	QuerySet querySet;

	public DBLoaderDao() {
		this.url = null;
		this.driver = null;
		this.user = null;
		this.password = null;
		this.dbschema = null;
		this.querySet = new DB2QuerySet();
	}

	public DBLoaderDao(String var1, String var2, String var3, String var4, boolean var5) {
		this.url = null;
		this.driver = null;
		this.user = null;
		this.password = null;
		this.dbschema = null;
		this.querySet = new DB2QuerySet();
		this.url = var2;
		this.driver = var3;
		this.dbschema = var4;
		this.querySet = DAOHelper.getQuerySet(var1, var4);
		this.traceOn = var5;
	}

	public DBLoaderDao(String var1, String var2, String var3, boolean var4) {
		this(var1, var2, var3, (String) null, var4);
	}

	public DBLoaderDao(String var1, String var2, String var3, String var4, String var5, String var6, boolean var7) {
		this.url = null;
		this.driver = null;
		this.user = null;
		this.password = null;
		this.dbschema = null;
		this.querySet = new DB2QuerySet();
		this.url = var2;
		this.driver = var3;
		this.user = var4;
		this.password = var5;
		this.dbschema = var6;
		this.querySet = DAOHelper.getQuerySet(var1, var6);
		this.traceOn = var7;
	}

	public DBLoaderDao(String var1, String var2, String var3, String var4, String var5, boolean var6) {
		this(var1, var2, var3, var4, var5, (String) null, var6);
	}

	public void closeConnection(Connection var1) {
		try {
			if (var1 != null) {
				var1.close();
			}
		} catch (SQLException var6) {
			;
		} finally {
			var1 = null;
		}

	}

	public int createDBProperty(DBProperty var1) throws WIMSystemException {
		String var3 = var1.getTypeId();
		String var4 = var1.getMetadataName();
		int var5 = var1.getIsComposite();
		int var6 = var1.getValueLength();
		int var7 = var1.getReadOnly();
		int var8 = var1.getMultiValued();
		String var9 = var1.getName();
		int var10 = var1.getCaseExactMatch();
		String var11 = var1.getClassName();
		String var12 = var1.getDescription();
		String var13 = var1.getApplicationId();
		Connection var14 = null;
		PreparedStatement var15 = null;

		int var19;
		try {
			var14 = this.getConnection();
			LocalKeyManager var16 = new LocalKeyManager();
			var16.setQuerySet(this.querySet);
			var16.setSchema(this.dbschema);
			int var17 = (new Long(var16.getDBKeyForTable(var14, "DBPROP"))).intValue();
			String var18 = this.querySet.createDBProperty;
			var15 = var14.prepareStatement(var18);
			var15.setInt(1, var17);
			var15.setString(2, var9);
			var15.setString(3, var3);
			var15.setString(4, var4);
			var15.setInt(5, var5);
			var15.setInt(6, var6);
			var15.setInt(7, var7);
			var15.setInt(8, var8);
			var15.setInt(9, var10);
			var15.setString(10, var11);
			var15.setString(11, var12);
			var15.setString(12, var13);
			var15.executeUpdate();
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "createDBProperty",
						"attribute " + var9 + " is created with id=" + var17);
			}

			var19 = var17;
		} catch (SQLException var29) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var29.getMessage()),
					CLASSNAME, "createDBProperty", var29);
		} catch (NamingException var30) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var30.getMessage()),
					CLASSNAME, "createDBProperty", var30);
		} finally {
			try {
				if (var15 != null) {
					var15.close();
				}

				this.closeConnection(var14);
			} catch (Exception var28) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "createDBProperty", var28.getMessage(), var28);
				}
			}

		}

		return var19;
	}

	public void createDBPropertyEntity(DBPropertyEntity var1) throws WIMSystemException {
		int var3 = var1.getPropertyId();
		String var4 = var1.getApplicableEntityType();
		int var5 = var1.getRequiredEntityType();
		Connection var6 = null;

		try {
			var6 = this.getConnection();
			String var7 = this.querySet.createDBPropertyEntity;
			PreparedStatement var8 = var6.prepareStatement(var7);
			var8.setInt(1, var3);
			var8.setString(2, var4);
			var8.setInt(3, var5);
			var8.executeUpdate();
		} catch (SQLException var12) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var12.getMessage()),
					CLASSNAME, "createDBPropertyEntity", var12);
		} finally {
			this.closeConnection(var6);
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createDBPropertyEntity",
					"Entity Type " + var4 + " is created for " + var3);
		}

	}

	public void createDBCompositeRelation(DBCompositeRelation var1) throws WIMSystemException {
		int var3 = var1.getCompositeId();
		int var4 = var1.getComponentId();
		int var5 = var1.getRequiredInComposite();
		int var6 = var1.getKeyInComposite();
		Connection var7 = null;

		try {
			var7 = this.getConnection();
			String var8 = this.querySet.createDBCompositeRelation;
			PreparedStatement var9 = var7.prepareStatement(var8);
			var9.setInt(1, var3);
			var9.setInt(2, var4);
			var9.setInt(3, var5);
			var9.setInt(4, var6);
			var9.executeUpdate();
		} catch (SQLException var13) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var13.getMessage()),
					CLASSNAME, "createDBCompositeRelation", var13);
		} finally {
			this.closeConnection(var7);
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createDBCompositeRelation",
					"component " + var4 + " is set for parent composite " + var3);
		}

	}

	public int createLAProperty(LAProperty var1) throws WIMSystemException {
		String var3 = var1.getName();
		String var4 = var1.getDatatypeId();
		String var5 = var1.getMetadataName();
		int var6 = var1.getIsComposite();
		int var7 = var1.getValueLength();
		int var8 = var1.getReadOnly();
		int var9 = var1.getMultiValued();
		int var10 = var1.getCaseExactMatch();
		String var11 = var1.getClassname();
		String var12 = var1.getDescription();
		String var13 = var1.getApplicationId();
		Connection var14 = null;

		int var19;
		try {
			var14 = this.getConnection();
			LocalKeyManager var15 = new LocalKeyManager();
			var15.setQuerySet(this.querySet);
			var15.setSchema(this.dbschema);
			int var16 = (new Long(var15.getLAKeyForTable(var14, "LAPROP"))).intValue();
			String var17 = this.querySet.createLAProperty;
			PreparedStatement var18 = var14.prepareStatement(var17);
			var18.setLong(1, (long) var16);
			var18.setString(2, var3);
			var18.setString(3, var4);
			var18.setString(4, var5);
			var18.setInt(5, var6);
			var18.setInt(6, var7);
			var18.setInt(7, var8);
			var18.setInt(8, var9);
			var18.setInt(9, var10);
			var18.setString(10, var11);
			var18.setString(11, var12);
			var18.setString(12, var13);
			var18.executeUpdate();
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "createLAProperty",
						"Prooerty  " + var3 + " is created with id=" + var16);
			}

			var19 = var16;
		} catch (SQLException var24) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var24.getMessage()),
					CLASSNAME, "createLAProperty", var24);
		} catch (NamingException var25) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var25.getMessage()),
					CLASSNAME, "createLAProperty", var25);
		} finally {
			this.closeConnection(var14);
		}

		return var19;
	}

	public void createLAPropertyEntity(LAPropertyEntity var1) throws WIMSystemException {
		int var3 = var1.getPropertyId();
		String var4 = var1.getApplicableEntityType();
		int var5 = var1.getRequiredEntityType();
		Connection var6 = null;

		try {
			var6 = this.getConnection();
			String var7 = this.querySet.createLAPropertyEntity;
			PreparedStatement var8 = var6.prepareStatement(var7);
			var8.setInt(1, var3);
			var8.setString(2, var4);
			var8.setInt(3, var5);
			var8.executeUpdate();
		} catch (SQLException var12) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var12.getMessage()),
					CLASSNAME, "createLAPropertyEntity", var12);
		} finally {
			this.closeConnection(var6);
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createLAPropertyEntity",
					"Entity Type " + var4 + " is created for " + var3);
		}

	}

	public void createLACompositeRelation(LACompositeRelation var1) throws WIMSystemException {
		int var3 = var1.getCompositeId();
		int var4 = var1.getComponentId();
		int var5 = var1.getRequiredInComposite();
		int var6 = var1.getKeyInComposite();
		Connection var7 = null;

		try {
			var7 = this.getConnection();
			String var8 = this.querySet.createLACompositeRelation;
			PreparedStatement var9 = var7.prepareStatement(var8);
			var9.setInt(1, var3);
			var9.setInt(2, var4);
			var9.setInt(3, var5);
			var9.setInt(4, var6);
			var9.executeUpdate();
		} catch (SQLException var13) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var13.getMessage()),
					CLASSNAME, "createLACompositeRelation", var13);
		} finally {
			this.closeConnection(var7);
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createLACompositeRelation",
					"component " + var4 + " is set for parent composite " + var3);
		}

	}

	public Connection getConnection() throws WIMSystemException {
		return this.makeConnection();
	}

	public Connection makeConnection() throws WIMSystemException {
		trcLogger.entering(CLASSNAME, "makeConnection");
		Properties var2 = new Properties();
		if (this.user != null && this.password != null) {
			var2.put("user", this.user);
			var2.put("password", this.password);
		}

		Connection var3 = DAOHelper.createConnection(this.driver, this.url, var2);
		trcLogger.exiting(CLASSNAME, "makeConnection");
		return var3;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}