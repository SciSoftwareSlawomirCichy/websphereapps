package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import javax.ejb.TimedObject;
import javax.ejb.Timer;

public final class TimedObjectWrapper extends EJSWrapperBase {
	private static final TraceComponent tc = Tr.register(TimedObjectWrapper.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.TimedObjectWrapper";

	public void invokeCallback(Timer timer, int methodId, boolean persistentGlobalTx) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "invokeCallback: " + timer);
		}

		EJSDeployedSupport s = new EJSDeployedSupport();
		s.isPersistentTimeoutGlobalTx = persistentGlobalTx;

		try {
			EJBMethodInfoImpl methodInfo = this.methodInfos[methodId];
			Object[] args = methodInfo.ivNumberOfMethodParms == 1 ? new Object[]{timer} : new Object[0];
			Object timedObj = this.container.EjbPreInvoke(this, methodId, s, args);
			if (methodInfo.getAroundInterceptorProxies() != null) {
				this.container.invoke(s, timer);
			} else if (methodId == 0 && this.bmd.isTimedObject && this.bmd.ivTimeoutMethod == null) {
				((TimedObject) timedObj).ejbTimeout(timer);
			} else {
				s.methodInfo.ivMethod.invoke(timedObj, args);
			}
		} catch (InvocationTargetException var71) {
			Throwable targetEx = var71.getCause();
			if (targetEx == null) {
				targetEx = var71;
			}

			s.setUncheckedLocalException((Throwable) targetEx);
		} catch (Throwable var72) {
			FFDCFilter.processException(var72, "com.ibm.ejs.container.TimedObjectWrapper.invokeCallback", "83", this);
			s.setUncheckedLocalException(var72);
		} finally {
			try {
				this.container.postInvoke(this, methodId, s);
			} catch (RemoteException var69) {
				FFDCFilter.processException(var69, "com.ibm.ejs.container.TimedObjectWrapper.invokeCallback", "91",
						this);
				s.setUncheckedLocalException(var69);
			} finally {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "invokeCallback");
				}

			}

		}

	}
}