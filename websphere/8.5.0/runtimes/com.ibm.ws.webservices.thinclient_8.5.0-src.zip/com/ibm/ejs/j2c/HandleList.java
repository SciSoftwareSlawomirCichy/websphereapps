package com.ibm.ejs.j2c;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.ArrayList;
import javax.resource.ResourceException;
import javax.resource.spi.IllegalStateException;

public final class HandleList implements Serializable, HandleListInterface {
	private ArrayList<Object> handleList = new ArrayList();
	private boolean destroyed = false;
	private static final TraceComponent tc = Tr.register(HandleList.class, "WAS.j2c",
			"com.ibm.ejs.resources.J2CAMessages");
	private static final long serialVersionUID = -4425328702653290017L;

	public HandleList add(HCMDetails a) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "add HCMDetails");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "adding handle " + a._handle);
		}

		this.handleList.add(a);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.debug(tc, "  handleList size " + this.handleList.size());
		}

		Tr.exit(tc, "add HCMDetails");
		return this;
	}

	public void remove(Object r) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "remove");
		}

		if (!this.destroyed) {
			for (int index = this.handleList.size() - 1; index >= 0; --index) {
				HCMDetails hcmd = (HCMDetails) this.handleList.get(index);
				if (hcmd._handle.equals(r)) {
					this.handleList.remove(index);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.debug(tc, "  handleList size " + this.handleList.size());
						Tr.exit(tc, "remove, handle removed " + hcmd._handle);
					}

					return;
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "HandleList does not contain the handle attempting to be removed: " + r);
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "Ignoring remove request.  This is ok as it is being destroyed");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.debug(tc, "  handleList size " + this.handleList.size());
			Tr.exit(tc, "remove");
		}

	}

	public void close() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "close");
		}

		this.destroyed = true;

		for (int index = this.handleList.size() - 1; index >= 0; --index) {
			try {
				HCMDetails hcmd = (HCMDetails) this.handleList.get(index);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Closing cached handle " + hcmd._handle);
				}

				if (hcmd._handle instanceof Connection) {
					((Connection) hcmd._handle).close();
				} else if (hcmd._handle instanceof javax.jms.Connection) {
					((javax.jms.Connection) hcmd._handle).close();
				} else if (hcmd._handle instanceof javax.resource.cci.Connection) {
					((javax.resource.cci.Connection) hcmd._handle).close();
				} else {
					try {
						Method m = hcmd._handle.getClass().getMethod("close", (Class[]) null);
						m.invoke(hcmd._handle, (Object[]) null);
					} catch (Exception var4) {
						Tr.debug(tc,
								"Troubles with introspection while closing connection handles, exception = " + var4);
					}
				}
			} catch (Exception var5) {
				Tr.debug(tc, "Troubles with closing connection handles, exception = " + var5);
			}
		}

		this.clear();
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "close");
		}

	}

	public void reAssociate() throws ResourceException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "reAssociate");
		}

		for (int i = 0; i < this.handleList.size(); ++i) {
			HCMDetails hcmd = (HCMDetails) this.handleList.get(i);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "reAssociate " + hcmd._handle);
			}

			Object[] parms;
			try {
				hcmd._cm.reAssociate(hcmd);
			} catch (IllegalStateException var6) {
				parms = new Object[]{"reAssociate", "reAssociate", hcmd._handle, var6};
				Tr.warning(tc, "PARK_OR_REASSOCIATE_FAILED_W_J2CA0083", parms);
			} catch (Exception var7) {
				parms = new Object[]{"reAssociate", "reAssociate", hcmd._handle, var7};
				Tr.warning(tc, "PARK_OR_REASSOCIATE_FAILED_W_J2CA0083", parms);
				FFDCFilter.processException(var7, "com.ibm.ejs.j2c.HandleList.reAssociate", "297", this);
				ResourceException re = new ResourceException("Reassociate call Failed");
				re.initCause(var7);
				throw re;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "reAssociate");
		}

	}

	public void parkHandle() throws ResourceException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "parkHandle");
		}

		for (int i = 0; i < this.handleList.size(); ++i) {
			HCMDetails hcmd = (HCMDetails) this.handleList.get(i);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "....parking " + hcmd._handle);
			}

			Object[] parms;
			try {
				hcmd._cm.parkHandle(hcmd);
			} catch (IllegalStateException var6) {
				parms = new Object[]{"parkHandle", "parkHandle", hcmd._handle, var6};
				Tr.warning(tc, "PARK_OR_REASSOCIATE_FAILED_W_J2CA0083", parms);
			} catch (Exception var7) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "parkHandle: error");
				}

				parms = new Object[]{"parkHandle", "parkHandle", hcmd._handle, var7};
				Tr.warning(tc, "PARK_OR_REASSOCIATE_FAILED_W_J2CA0083", parms);
				FFDCFilter.processException(var7, "com.ibm.ejs.j2c.HandleList.parkHandle", "373", this);
				ResourceException re = new ResourceException("parkHandle call Failed");
				re.initCause(var7);
				throw re;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "parkHandle");
		}

	}

	public void printAllHandles() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "printAllHandles");
		}

		for (int index = this.handleList.size() - 1; index >= 0; --index) {
			HCMDetails hcmd = (HCMDetails) this.handleList.get(index);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "...." + hcmd._handle);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "printAllHandles");
		}

	}

	public void componentDestroyed() {
		int size = this.handleList.size();
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "componentDestroyed");
		}

		if (size > 0) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Closing " + size + " cached handle(s) at the end of boundary.");
			}

			this.close();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "componentDestroyed");
		}

	}

	private void clear() {
		this.destroyed = false;
		this.handleList.clear();
	}
}