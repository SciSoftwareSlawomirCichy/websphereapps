package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.DuplicateKeyException;
import javax.transaction.TransactionRolledbackException;

public class OptCEntityActivationStrategy extends ActivationStrategy {
	private static final TraceComponent tc = Tr.register(OptCEntityActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.activator.OptCEntityActivationStrategy";

	public OptCEntityActivationStrategy(Activator activator) {
		super(activator);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> complete");
		}

	}

	BeanO atActivate(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atActivate (" + beanId + ")", tx);
		}

		BeanO bean = null;
		boolean FoundInOptCTxCache = false;
		boolean exception = false;
		boolean activate = false;
		boolean pushedCallbackBeanO = false;
		TransactionKey key = null;

		try {
			bean = tx.find(beanId);
			if (bean != null) {
				FoundInOptCTxCache = true;
				threadData.pushCallbackBeanO(bean);
				pushedCallbackBeanO = true;
			} else {
				key = new TransactionKey(tx, beanId);
				synchronized (this.locks.getLock(key)) {
					if ((bean = (BeanO) this.cache.find(key)) == null) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Bean not in cache");
						}

						bean = beanId.getHome().createBeanO(threadData, tx, beanId);
						pushedCallbackBeanO = true;
						this.cache.insert(key, bean);
						bean.ivCacheKey = key;
						activate = true;
					} else {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Found bean in cache");
						}

						threadData.pushCallbackBeanO(bean);
						pushedCallbackBeanO = true;
					}
				}
			}

			boolean pin = false;
			if (activate) {
				bean.activate(beanId, tx);
				pin = bean.enlist(tx);
			} else {
				if (bean.getState() == 8) {
					pin = bean.enlist(tx);
				}

				bean.ensurePersistentState(tx);
			}

			if (!pin && !FoundInOptCTxCache) {
				this.cache.unpin(key);
			}
		} catch (NoSuchObjectException var20) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception while activating bean", var20);
			}

			exception = true;
			throw var20;
		} catch (RemoteException var21) {
			FFDCFilter.processException(var21,
					"com.ibm.ejs.container.activator.OptCEntityActivationStrategy.atActivate", "124", this);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception while activating bean", var21);
			}

			exception = true;
			throw var21;
		} catch (RuntimeException var22) {
			FFDCFilter.processException(var22,
					"com.ibm.ejs.container.activator.OptCEntityActivationStrategy.atActivate", "131", this);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception while activating bean", var22);
			}

			exception = true;
			throw var22;
		} finally {
			if (exception && bean != null) {
				if (pushedCallbackBeanO) {
					threadData.popCallbackBeanO();
				}

				bean.destroy();
				if (activate) {
					this.cache.remove(key, true);
					bean.ivCacheKey = null;
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atActivate");
			}

		}

		return bean;
	}

	void atPostInvoke(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atPostInvoke", new Object[]{tx, bean});
		}

		Object key = bean.ivCacheKey;
		if (key == null) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atPostInvoke : bean not in cache");
			}

		} else {
			synchronized (this.locks.getLock(key)) {
				BeanO beanO = (BeanO) this.cache.find(key);
				if (beanO != null) {
					this.cache.unpin(key);
					if (beanO.isRemoved() || beanO.isDiscarded()) {
						if (tx != null) {
							try {
								tx.delist(beanO);
							} catch (TransactionRolledbackException var10) {
								FFDCFilter.processException(var10,
										"com.ibm.ejs.container.activator.OptCEntityActivationStrategy.atPostInvoke",
										"188", this);
								if (isTraceOn && tc.isDebugEnabled()) {
									Tr.debug(tc, "Transaction has rolled back");
								}
							}
						}

						beanO = (BeanO) this.cache.remove(key, true);
						beanO.ivCacheKey = null;
						if (!beanO.isDiscarded()) {
							try {
								if (isTraceOn && tc.isDebugEnabled()) {
									Tr.debug(tc, "Passivating Bean after Remove");
								}

								beanO.passivate();
							} catch (RemoteException var9) {
								FFDCFilter.processException(var9,
										"com.ibm.ejs.container.activator.OptCEntityActivationStrategy.atPostInvoke",
										"210", this);
								if (isTraceOn && tc.isEventEnabled()) {
									Tr.event(tc, "Exception while passivating bean", var9);
								}

								beanO.destroy();
							}
						} else {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "Destroying Bean after Discard");
							}

							beanO.destroy();
						}
					}
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atPostInvoke");
			}

		}
	}

	BeanO atCreate(ContainerTx tx, BeanO bean) throws DuplicateKeyException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCreate", new Object[]{tx, bean});
		}

		TransactionKey key = new TransactionKey(tx, bean.getId());
		boolean inserted = false;
		boolean exception = false;

		try {
			synchronized (this.locks.getLock(key)) {
				if (this.cache.contains(key)) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "atCreate: Duplicate key", key);
					}

					throw new DuplicateKeyException();
				}

				this.cache.insert(key, bean);
				bean.ivCacheKey = key;
				inserted = true;
			}

			if (!bean.enlist(tx)) {
				this.cache.unpin(key);
			}
		} catch (RemoteException var15) {
			FFDCFilter.processException(var15, "com.ibm.ejs.container.activator.OptCEntityActivationStrategy.atCreate",
					"271", this);
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Error creating bean", var15);
			}

			exception = true;
			throw var15;
		} catch (RuntimeException var16) {
			FFDCFilter.processException(var16, "com.ibm.ejs.container.activator.OptCEntityActivationStrategy.atCreate",
					"278", this);
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "atCreate", var16);
			}

			exception = true;
			throw var16;
		} finally {
			if (exception) {
				bean.destroy();
				if (inserted) {
					this.cache.remove(key, true);
					bean.ivCacheKey = null;
				}
			}

		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCreate", (Object) null);
		}

		return null;
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit", new Object[]{tx, bean});
		}

		Object key = bean.ivCacheKey;
		BeanO beanO;
		synchronized (this.locks.getLock(key)) {
			beanO = (BeanO) this.cache.remove(key, true);
			beanO.ivCacheKey = null;
		}

		try {
			beanO.passivate();
		} catch (RemoteException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.container.activator.OptCEntityActivationStrategy.atCommit",
					"320", this);
			beanO.destroy();
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Exception while passivating bean", var9);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCommit");
		}

	}

	void atRollback(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRollback", new Object[]{tx, bean});
		}

		Object key = bean.ivCacheKey;
		BeanO beanO;
		synchronized (this.locks.getLock(key)) {
			beanO = (BeanO) this.cache.remove(key, true);
			beanO.ivCacheKey = null;
		}

		try {
			beanO.passivate();
		} catch (RemoteException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.container.activator.OptCEntityActivationStrategy.atRollback",
					"348", this);
			beanO.destroy();
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Exception while passivating bean", var9);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRollback");
		}

	}

	void atEnlist(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atEnlist", new Object[]{tx, bean});
		}

		this.cache.pin(bean.ivCacheKey);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atEnlist");
		}

	}

	void atRemove(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRemove", new Object[]{tx, bean});
		}

		Object key = bean.ivCacheKey;
		synchronized (this.locks.getLock(key)) {
			this.cache.remove(key, true);
			bean.ivCacheKey = null;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRemove");
		}

	}

	BeanO atGet(ContainerTx tx, BeanId id) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atGet", new Object[]{tx, id});
		}

		TransactionKey key = new TransactionKey(tx, id);
		BeanO result;
		synchronized (this.locks.getLock(key)) {
			result = (BeanO) this.cache.find(key);
			if (result != null) {
				this.cache.unpin(key);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atGet", result);
		}

		return result;
	}

	void atDiscard(BeanO bean) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atDiscard : " + bean);
		}

		try {
			bean.ivCacheKey = null;
			bean.passivate();
		} catch (RemoteException var4) {
			FFDCFilter.processException(var4, "com.ibm.ejs.container.activator.OptCEntityActivationStrategy.atDiscard",
					"412", this);
			Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{bean, this, var4});
			throw var4;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atDiscard");
		}

	}
}