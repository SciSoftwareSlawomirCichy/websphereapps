package com.ibm.ws.wim.config;

import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.wim.SchemaConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.ldap.LdapConfigManager;
import com.ibm.ws.wim.adapter.ldap.LdapConnection;
import com.ibm.ws.wim.adapter.ldap.LdapHelper;
import com.ibm.ws.wim.config.ConfigUtils.GlobalKrb5Config;
import com.ibm.ws.wim.configmodel.AttributeConfigurationType;
import com.ibm.ws.wim.configmodel.AttributeType;
import com.ibm.ws.wim.configmodel.AttributesCacheType;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.CacheConfigurationType;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.ContextPoolType;
import com.ibm.ws.wim.configmodel.DynamicMemberAttributesType;
import com.ibm.ws.wim.configmodel.GroupConfigurationType;
import com.ibm.ws.wim.configmodel.Krb5AuthenticationType;
import com.ibm.ws.wim.configmodel.LdapEntityTypesType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.MemberAttributesType;
import com.ibm.ws.wim.configmodel.MembershipAttributeType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.PropertiesNotSupportedType;
import com.ibm.ws.wim.configmodel.RdnAttributesType;
import com.ibm.ws.wim.configmodel.SearchResultsCacheType;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EcoreUtil;

public class LDAPRepositoryConfigHelper extends LDAPServerConfigHelper implements SchemaConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	String SEMICOLON_DELIMITER = ";";

	public String createIdMgrLDAPRepository(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "createIdMgrLDAPRepository", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		ConfigUtils.checkForValidRepositoryById(var1, var5);
		List var6 = (List) var2.get("loginProperties");
		ValidationHelper.validateStringInputInList("loginProperties", CLASSNAME, "createIdMgrLDAPRepository", var6,
				false);
		ConfigValidator.validateRepositoryParams(var5, "LdapRepositoryType", var2);
		ConfigurationProviderType var7 = ConfigUtils.getConfigProvider(var1);
		EClass var8 = ConfigManager.singleton().getConfigEClass("LdapRepositoryType");
		DataObject var9 = (DataObject) EcoreUtil.create(var8);
		var9.setString("id", var5);
		var7.getRepositories().add(var9);
		LdapRepositoryType var10 = (LdapRepositoryType) ConfigUtils.getRepositoryById(var7, var5);
		ConfigUtils.setCommonRepositoryProperties(var10, var2, this.getDefaultValue(), false);
		if (var6 != null) {
			List var11 = var10.getLoginProperties();
			ConfigUtils.addOrRemovePresentList("loginProperties", var6, var11);
		}

		String var16 = (String) ConfigUtils.getParamValue(var2, (Map) null, "ldapServerType", true);
		var10.setLdapServerType(var16);
		Boolean var12 = (Boolean) ConfigUtils.getParamValue(var2, this.getDefaultValue(), "translateRDN", false);
		var10.setTranslateRDN(var12);
		String var13 = (String) ConfigUtils.getParamValue(var2, this.getDefaultValue(), "certificateMapMode", false);
		if (var13 != null) {
			var10.setCertificateMapMode(var13);
		}

		var13 = (String) var2.get("certificateFilter");
		if (var13 != null) {
			var10.setCertificateFilter(var13);
		}

		var13 = (String) var2.get("supportChangeLog");
		ConfigValidator.validateSupportChangeLogParameter(var13);
		if (var13 != null) {
			var10.setSupportChangeLog(var13.toLowerCase());
		} else {
			var10.setSupportChangeLog("none");
		}

		LdapServerConfigurationType var14 = var10.createLdapServerConfiguration();
		this.setLdapServerConfigParams(var14, var2);
		Boolean var15 = (Boolean) var2.get("default");
		if (var15 != null && var15) {
			if (!var16.equals("IDS") && !var16.equals("SECUREWAY") && !var16.equals("IDS4") && !var16.equals("IDS51")
					&& !var16.equals("IDS52") && !var16.equals("IDS6") && !var16.equals("ZOSDS")) {
				if (!var16.equals("DOMINO") && !var16.equals("DOMINO5") && !var16.equals("DOMINO6")
						&& !var16.equals("DOMINO65")) {
					if (!var16.equals("NDS") && !var16.equals("SUNONE")) {
						if (!var16.equals("AD") && !var16.equals("AD2000") && !var16.equals("AD2003")) {
							if (var16.equals("ADAM")) {
								this.setDefaultsForADAM(var10);
							}
						} else {
							this.setDefaultsForActiveDirectory(var10);
						}
					} else {
						this.setDefaultsForNDSorSunone(var10, var16);
					}
				} else {
					this.setDefaultsForDomino(var10, var1);
				}
			} else {
				this.setDefaultsForIDS(var10);
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "createIdMgrLDAPRepository");
		}

		ConfigUtils.saveConfig(var1);
		return "MUST_ADD_BASE_ENTRY_TO_REPOSITORY";
	}

	@Deprecated
	public String updateIdMgrLDAPRepository(String var1, Map var2) throws WIMException {
		return this.updateIdMgrLDAPRepository((Map) var2, (Session) null);
	}

	public String updateIdMgrLDAPRepository(Map var1, Session var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "updateIdMgrLDAPRepository", "params=" + var1);
		}

		String var5 = var2.toString();
		String var6 = (String) var1.get("id");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var5, var6,
				"LdapRepositoryType");
		String var8 = (String) ConfigUtils.getParamValue(var1, (Map) null, "ldapServerType", true);
		List var9 = (List) var1.get("loginProperties");
		ValidationHelper.validateStringInputInList("loginProperties", CLASSNAME, "updateIdMgrLDAPRepository", var9,
				true);
		ConfigValidator.validateRepositoryParams(var6, "LdapRepositoryType", var1);
		Object var10 = new HashMap();
		if (var1.containsKey("sslConfiguration") || var1.containsKey("certificateMapMode")
				|| var1.containsKey("certificateFilter")) {
			try {
				var10 = this.getLDAPConnectionData(var7, var2);
			} catch (WIMConfigurationException var14) {
				;
			}
		}

		((Map) var10).putAll(var1);
		ConfigValidator.validateLDAPParams(var6, (Map) var10);
		if (var8 != null) {
			var7.setLdapServerType(var8);
		}

		ConfigUtils.setCommonRepositoryProperties(var7, var1, (Map) null, true);
		if (var9 != null) {
			List var11 = var7.getLoginProperties();
			ConfigUtils.addOrRemovePresentList("loginProperties", var9, var11);
		}

		Boolean var15 = (Boolean) ConfigUtils.getParamValue(var1, (Map) null, "translateRDN", true);
		if (var15 != null) {
			var7.setTranslateRDN(var15);
		}

		String var12 = (String) var1.get("certificateMapMode");
		if (var12 != null) {
			var7.setCertificateMapMode(var12);
		}

		var12 = (String) var1.get("certificateFilter");
		if (var12 != null) {
			var7.setCertificateFilter(var12);
		}

		var12 = (String) var1.get("supportChangeLog");
		if (var12 != null) {
			var7.setSupportChangeLog(var12.toLowerCase());
		}

		LdapServerConfigurationType var13 = var7.getLdapServerConfiguration();
		if (var13 == null) {
			var13 = var7.createLdapServerConfiguration();
		}

		this.setLdapServerConfigParams(var13, var1);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrLDAPRepository");
		}

		return ConfigUtils.saveConfig(var5);
	}

	@Deprecated
	public String addIdMgrLDAPEntityType(String var1, Map var2) throws WIMException {
		return this.addIdMgrLDAPEntityType((Map) var2, (Session) null);
	}

	public String addIdMgrLDAPEntityType(Map var1, Session var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrLDAPEntityType", "params=" + var1);
		}

		String var5 = var2.toString();
		String var6 = (String) var1.get("id");
		String var7 = (String) var1.get("name");
		String var8 = (String) var1.get("searchFilter");
		List var9 = (List) var1.get("objectClasses");
		List var10 = (List) var1.get("objectClassesForCreate");
		List var11 = (List) var1.get("searchBases");
		LdapRepositoryType var12 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var5, var6,
				"LdapRepositoryType");
		LdapEntityTypesType var13 = this.getEntityType(var12, var7, false);
		if (var13 != null) {
			throw new WIMConfigurationException("LDAP_ENTITY_TYPE_ALREADY_EXISTS",
					WIMMessageHelper.generateMsgParms(var7), Level.SEVERE, CLASSNAME, "addIdMgrLDAPEntityType");
		} else {
			Map var14 = this.getLDAPConnectionData(var12, var2);
			if (var14 != null) {
				if (var8 != null) {
					var14.put("searchFilter", var8);
				}

				if (var9 != null && var9.size() > 0) {
					var14.put("objectClasses", var9);
				}

				if (var10 != null && var10.size() > 0) {
					var14.put("objectClassesForCreate", var10);
				}

				if (var11 != null && var11.size() > 0) {
					var14.put("searchBases", var11);
				}

				ConfigValidator.validateLDAPParams(var6, var14);
			}

			List var15;
			if (var11 != null && var11.size() > 0) {
				var15 = var12.getBaseEntries();
				Iterator var16 = var11.iterator();

				label95 : while (true) {
					String var18;
					boolean var19;
					do {
						if (!var16.hasNext()) {
							break label95;
						}

						Object var17 = var16.next();
						var18 = (String) var17;
						var19 = false;
					} while (var15 == null);

					Iterator var20 = var15.iterator();

					while (var20.hasNext()) {
						Object var21 = var20.next();
						if (!var19) {
							BaseEntriesType var22 = (BaseEntriesType) var21;
							String var23 = null;
							if (var22 != null) {
								var23 = var22.getNameInRepository();
								if (var23 == null) {
									var23 = var22.getName();
								}
							}

							if (var23 != null && var18 != null && LdapHelper.isUnderBases(var18, var23)) {
								var19 = true;
							}
						}
					}

					if (!var19) {
						throw new WIMConfigurationException("INVALID_SEARCH_BASE",
								WIMMessageHelper.generateMsgParms(var11), CLASSNAME, "addIdMgrLDAPEntityType");
					}
				}
			}

			var13 = var12.createLdapEntityTypes();
			var13.setName(var7);
			if (var8 != null) {
				var13.setSearchFilter(var8);
			}

			var15 = var13.getObjectClasses();
			if (var9 != null) {
				ConfigUtils.addOrRemovePresentList("objectClasses", var9, var15);
			}

			var15 = var13.getObjectClassesForCreate();
			if (var10 != null) {
				ConfigUtils.addOrRemovePresentList("objectClassesForCreate", var10, var15);
			}

			var15 = var13.getSearchBases();
			if (var11 != null) {
				ConfigUtils.addOrRemovePresentList("searchBases", var11, var15);
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "addIdMgrLDAPEntityType");
			}

			return ConfigUtils.saveConfig(var5);
		}
	}

	@Deprecated
	public String updateIdMgrLDAPEntityType(String var1, Map var2) throws WIMException {
		return this.updateIdMgrLDAPEntityType((Map) var2, (Session) null);
	}

	public String updateIdMgrLDAPEntityType(Map var1, Session var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "updateIdMgrLDAPEntityType", "params=" + var1);
		}

		String var5 = var2.toString();
		String var6 = (String) var1.get("id");
		String var7 = (String) var1.get("name");
		String var8 = (String) var1.get("searchFilter");
		List var9 = (List) var1.get("objectClasses");
		List var10 = (List) var1.get("objectClassesForCreate");
		List var11 = (List) var1.get("searchBases");
		LdapRepositoryType var12 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var5, var6,
				"LdapRepositoryType");
		LdapEntityTypesType var13 = this.getEntityType(var12, var7, true);
		if (var8 != null || var9 != null && var9.size() > 0 || var10 != null && var10.size() > 0
				|| var11 != null && var11.size() > 0) {
			Map var14 = this.getLDAPConnectionData(var12, var2);
			if (var14 != null) {
				if (var8 != null) {
					var14.put("searchFilter", var8);
				}

				if (var9 != null && var9.size() > 0) {
					var14.put("objectClasses", var9);
				}

				if (var10 != null && var10.size() > 0) {
					var14.put("objectClassesForCreate", var10);
				}

				if (var11 != null && var11.size() > 0) {
					var14.put("searchBases", var11);
				}

				ConfigValidator.validateLDAPParams(var6, var14);
			}
		}

		List var23;
		if (var11 != null && var11.size() > 0) {
			var23 = var12.getBaseEntries();
			Iterator var15 = var11.iterator();

			label100 : while (true) {
				String var17;
				boolean var18;
				do {
					if (!var15.hasNext()) {
						break label100;
					}

					Object var16 = var15.next();
					var17 = (String) var16;
					var18 = false;
				} while (var23 == null);

				Iterator var19 = var23.iterator();

				while (var19.hasNext()) {
					Object var20 = var19.next();
					if (!var18) {
						BaseEntriesType var21 = (BaseEntriesType) var20;
						String var22 = null;
						if (var21 != null) {
							var22 = var21.getNameInRepository();
							if (var22 == null) {
								var22 = var21.getName();
							}
						}

						if (var22 != null && var17 != null && LdapHelper.isUnderBases(var17, var22)) {
							var18 = true;
						}
					}
				}

				if (!var18) {
					throw new WIMConfigurationException("INVALID_SEARCH_BASE", WIMMessageHelper.generateMsgParms(var11),
							CLASSNAME, "updateIdMgrLDAPEntityType");
				}
			}
		}

		if (var8 != null) {
			var13.setSearchFilter(var8);
		}

		var23 = var13.getObjectClasses();
		if (var9 != null) {
			ConfigUtils.addOrRemovePresentList("objectClasses", var9, var23);
		}

		var23 = var13.getObjectClassesForCreate();
		if (var10 != null) {
			ConfigUtils.addOrRemovePresentList("objectClassesForCreate", var10, var23);
		}

		var23 = var13.getSearchBases();
		if (var11 != null) {
			ConfigUtils.addOrRemovePresentList("searchBases", var11, var23);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrLDAPEntityType");
		}

		return ConfigUtils.saveConfig(var5);
	}

	public String deleteIdMgrLDAPEntityType(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPEntityType", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("name");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		LdapEntityTypesType var8 = this.getEntityType(var7, var6, true);
		((DataObject) var8).delete();
		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPEntityType");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List listIdMgrLDAPEntityTypes(String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrLDAPEntityTypes", "id=" + var2);
		}

		LdapRepositoryType var5 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		List var6 = var5.getLdapEntityTypes();
		Vector var7 = new Vector();
		if (var6 != null) {
			for (int var8 = 0; var8 < var6.size(); ++var8) {
				LdapEntityTypesType var9 = (LdapEntityTypesType) var6.get(var8);
				var7.add(var9.getName());
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "listIdMgrLDAPEntityTypes");
		}

		return var7;
	}

	public Map getIdMgrLDAPEntityType(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPEntityType", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("name");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		LdapEntityTypesType var8 = this.getEntityType(var7, var6, true);
		HashMap var9 = new HashMap();
		var9.put("id", var5);
		var9.put("name", var8.getName());
		var9.put("searchFilter", var8.getSearchFilter());
		var9.put("objectClasses", ConfigUtils.convertEList(var8.getObjectClasses()));
		var9.put("objectClassesForCreate", ConfigUtils.convertEList(var8.getObjectClassesForCreate()));
		var9.put("searchBases", ConfigUtils.convertEList(var8.getSearchBases()));
		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPEntityType");
		}

		return var9;
	}

	public String addIdMgrLDAPEntityTypeRDNAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrLDAPEntityTypeRDNAttr", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("entityTypeName");
		String var7 = (String) var2.get("name");
		String var8 = (String) var2.get("objectClass");
		LdapRepositoryType var9 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		LdapEntityTypesType var10 = this.getEntityType(var9, var6, true);
		RdnAttributesType var11 = this.getRDNAttr(var10, var7, false);
		if (var11 != null) {
			throw new WIMConfigurationException("RDN_ATTR_ALREADY_EXISTS", WIMMessageHelper.generateMsgParms(var7),
					Level.SEVERE, CLASSNAME, "addIdMgrLDAPEntityTypeRDNAttr");
		} else {
			var11 = var10.createRdnAttributes();
			var11.setName(var7);
			if (var8 != null) {
				var11.setObjectClass(var8);
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "addIdMgrLDAPEntityTypeRDNAttr");
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public String deleteIdMgrLDAPEntityTypeRDNAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPEntityTypeRDNAttr", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("entityTypeName");
		String var7 = (String) var2.get("name");
		LdapRepositoryType var8 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		LdapEntityTypesType var9 = this.getEntityType(var8, var6, true);
		RdnAttributesType var10 = this.getRDNAttr(var9, var7, true);
		((DataObject) var10).delete();
		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPEntityTypeRDNAttr");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public Map getIdMgrLDAPEntityTypeRDNAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPEntityTypeRDNAttr", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("entityTypeName");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		LdapEntityTypesType var8 = this.getEntityType(var7, var6, true);
		HashMap var9 = new HashMap();
		List var10 = var8.getRdnAttributes();
		if (var10 != null) {
			for (int var11 = 0; var11 < var10.size(); ++var11) {
				RdnAttributesType var12 = (RdnAttributesType) var10.get(var11);
				var9.put(var12.getName(), var12.getObjectClass());
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPEntityTypeRDNAttr", " returning " + var9);
		}

		return var9;
	}

	public String setIdMgrLDAPGroupConfig(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setIdMgrLDAPGroupConfig", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		LdapRepositoryType var6 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		Boolean var7 = (Boolean) var2.get("updateGroupMembership");
		String var8 = (String) var2.get("name");
		String var9 = (String) var2.get("scope");
		if (var9 != null) {
			ValidationHelper.validateParam("scope", var9, CONFIG_SCOPES);
		}

		GroupConfigurationType var10 = this.getLDAPGroupConfig(var6, false);
		if (var10 == null) {
			var10 = var6.createGroupConfiguration();
		}

		MembershipAttributeType var11 = var10.getMembershipAttribute();
		if (var8 != null) {
			if (var8.trim().equals("")) {
				if (var11 != null) {
					((DataObject) var11).delete();
				}
			} else {
				if (var11 == null) {
					var11 = var10.createMembershipAttribute();
					var11.setScope("direct");
				}

				var11.setName(var8);
				if (var9 != null) {
					var11.setScope(var9);
				}
			}
		} else if (var9 != null) {
			if (var11 == null) {
				throw new WIMConfigurationException("CONFIG_GROUP_SCOPE_CANNOT_BE_SET", Level.SEVERE, CLASSNAME,
						"setIdMgrLDAPGroupConfig");
			}

			var11.setScope(var9);
		}

		if (var7 != null) {
			var10.setUpdateGroupMembership(var7);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "setIdMgrLDAPGroupConfig");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public String deleteIdMgrLDAPGroupConfig(String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPGroupConfig", "id=" + var2);
		}

		LdapRepositoryType var5 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		GroupConfigurationType var6 = this.getLDAPGroupConfig(var5, true);
		if (var6 != null) {
			((DataObject) var6).delete();
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPGroupConfig");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public Map getIdMgrLDAPGroupConfig(String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPGroupConfig", "id=" + var2);
		}

		LdapRepositoryType var5 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		HashMap var6 = null;
		GroupConfigurationType var7 = this.getLDAPGroupConfig(var5, false);
		if (var7 != null) {
			var6 = new HashMap();
			if (var7.isSetUpdateGroupMembership()) {
				var6.put("updateGroupMembership", var7.isUpdateGroupMembership());
			}

			MembershipAttributeType var8 = var7.getMembershipAttribute();
			if (var8 != null) {
				var6.put("name", var8.getName());
				if (var8.isSetScope()) {
					var6.put("scope", var8.getScope());
				}
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPGroupConfig", " returning " + var6);
		}

		return var6;
	}

	public String addIdMgrLDAPGroupMemberAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrLDAPGroupMemberAttr", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("scope");
		if (var6 != null) {
			ValidationHelper.validateParam("scope", var6, CONFIG_SCOPES);
		}

		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		GroupConfigurationType var8 = this.getLDAPGroupConfig(var7, false);
		if (var8 == null) {
			var8 = var7.createGroupConfiguration();
		}

		String var9 = (String) var2.get("name");
		String var10 = (String) var2.get("objectClass");
		if (var10 != null && var10.trim().length() == 0) {
			var10 = null;
		}

		String var11 = (String) var2.get("dummyMember");
		if (var8 == null) {
			var8 = var7.createGroupConfiguration();
		}

		MemberAttributesType var12 = this.getGroupMemberAttr(var8, var9, false);
		if (var12 != null) {
			throw new WIMConfigurationException("GROUP_MEMBER_ATTR_ALREADY_EXISTS",
					WIMMessageHelper.generateMsgParms(var9), Level.SEVERE, CLASSNAME, "addIdMgrLDAPGroupMemberAttr");
		} else {
			boolean var13 = this.isGroupObjClassAlreadyConfigured(var8, var10);
			if (var13) {
				throw new WIMConfigurationException("GROUP_MEMBER_ATTR_FOR_OBJECTCLASS_EXISTS",
						WIMMessageHelper.generateMsgParms(var10), Level.SEVERE, CLASSNAME,
						"addIdMgrLDAPGroupMemberAttr");
			} else {
				var12 = var8.createMemberAttributes();
				var12.setName(var9);
				if (var10 != null) {
					var12.setObjectClass(var10);
				} else {
					var12.setObjectClass("");
				}

				if (var6 != null) {
					var12.setScope(var6);
				}

				if (var11 != null) {
					var12.setDummyMember(var11);
				}

				if (var4) {
					trcLogger.exiting(CLASSNAME, "addIdMgrLDAPGroupMemberAttr");
				}

				return ConfigUtils.saveConfig(var1);
			}
		}
	}

	private boolean isGroupObjClassAlreadyConfigured(GroupConfigurationType var1, String var2) {
		List var3 = var1.getMemberAttributes();
		if (var3 != null) {
			int var4;
			MemberAttributesType var5;
			if (var2 != null) {
				for (var4 = 0; var4 < var3.size(); ++var4) {
					var5 = (MemberAttributesType) var3.get(var4);
					if (var5.getObjectClass() != null && var5.getObjectClass().equalsIgnoreCase(var2)) {
						return true;
					}
				}
			} else {
				for (var4 = 0; var4 < var3.size(); ++var4) {
					var5 = (MemberAttributesType) var3.get(var4);
					if (var5.getObjectClass() == null) {
						return true;
					}
				}
			}
		}

		return false;
	}

	public String updateIdMgrLDAPGroupMemberAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "updateIdMgrLDAPGroupMemberAttr", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("scope");
		if (var6 != null) {
			ValidationHelper.validateParam("scope", var6, CONFIG_SCOPES);
		}

		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		GroupConfigurationType var8 = this.getLDAPGroupConfig(var7, true);
		String var9 = (String) var2.get("name");
		String var10 = (String) var2.get("objectClass");
		String var11 = (String) var2.get("dummyMember");
		MemberAttributesType var12 = this.getGroupMemberAttr(var8, var9, true);
		if (var10 != null) {
			var12.setObjectClass(var10);
		}

		if (var6 != null) {
			var12.setScope(var6);
		}

		if (var11 != null) {
			var12.setDummyMember(var11);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrLDAPGroupMemberAttr");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public String deleteIdMgrLDAPGroupMemberAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPGroupMemberAttr", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("name");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		GroupConfigurationType var8 = this.getLDAPGroupConfig(var7, true);
		MemberAttributesType var9 = this.getGroupMemberAttr(var8, var6, true);
		((DataObject) var9).delete();
		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPGroupMemberAttr");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List getIdMgrLDAPGroupMemberAttrs(String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPGroupMemberAttrs", "id=" + var2);
		}

		LdapRepositoryType var5 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		ArrayList var6 = new ArrayList();
		GroupConfigurationType var7 = this.getLDAPGroupConfig(var5, false);
		if (var7 != null) {
			List var8 = var7.getMemberAttributes();
			if (var8 != null) {
				for (int var9 = 0; var9 < var8.size(); ++var9) {
					MemberAttributesType var10 = (MemberAttributesType) var8.get(var9);
					HashMap var11 = new HashMap();
					var11.put("name", var10.getName());
					if (var10.getObjectClass() != null) {
						var11.put("objectClass", var10.getObjectClass());
					}

					if (var10.isSetScope()) {
						var11.put("scope", var10.getScope());
					}

					if (var10.getDummyMember() != null) {
						var11.put("dummyMember", var10.getDummyMember());
					}

					var6.add(var11);
				}
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPGroupMemberAttrs", " returning " + var6);
		}

		return var6;
	}

	public String addIdMgrLDAPGroupDynamicMemberAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrLDAPGroupDynamicMemberAttr", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		LdapRepositoryType var6 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		GroupConfigurationType var7 = this.getLDAPGroupConfig(var6, false);
		if (var7 == null) {
			var7 = var6.createGroupConfiguration();
		}

		String var8 = (String) var2.get("name");
		String var9 = (String) var2.get("objectClass");
		DynamicMemberAttributesType var10 = this.getGroupDynamicMemberAttr(var7, var8, false);
		if (var10 != null) {
			throw new WIMConfigurationException("DYMANIC_GROUP_MEMBER_ATTR_ALREADY_EXISTS",
					WIMMessageHelper.generateMsgParms(var8), Level.SEVERE, CLASSNAME,
					"addIdMgrLDAPGroupDynamicMemberAttr");
		} else {
			var10 = var7.createDynamicMemberAttributes();
			var10.setName(var8);
			var10.setObjectClass(var9);
			if (var4) {
				trcLogger.exiting(CLASSNAME, "addIdMgrLDAPGroupDynamicMemberAttr");
			}

			return ConfigUtils.saveConfig(var1);
		}
	}

	public String updateIdMgrLDAPGroupDynamicMemberAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "updateIdMgrLDAPGroupDynamicMemberAttr", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		LdapRepositoryType var6 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		GroupConfigurationType var7 = this.getLDAPGroupConfig(var6, true);
		String var8 = (String) var2.get("name");
		String var9 = (String) var2.get("objectClass");
		DynamicMemberAttributesType var10 = this.getGroupDynamicMemberAttr(var7, var8, true);
		var10.setObjectClass(var9);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrLDAPGroupDynamicMemberAttr");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public String deleteIdMgrLDAPGroupDynamicMemberAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPGroupDynamicMemberAttr", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("name");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		GroupConfigurationType var8 = this.getLDAPGroupConfig(var7, true);
		DynamicMemberAttributesType var9 = this.getGroupDynamicMemberAttr(var8, var6, true);
		((DataObject) var9).delete();
		if (var4) {
			trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPGroupDynamicMemberAttr");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List getIdMgrLDAPGroupDynamicMemberAttrs(String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPGroupDynamicMemberAttrs", "id=" + var2);
		}

		LdapRepositoryType var5 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		ArrayList var6 = new ArrayList();
		GroupConfigurationType var7 = this.getLDAPGroupConfig(var5, false);
		if (var7 != null) {
			List var8 = var7.getDynamicMemberAttributes();
			if (var8 != null) {
				for (int var9 = 0; var9 < var8.size(); ++var9) {
					DynamicMemberAttributesType var10 = (DynamicMemberAttributesType) var8.get(var9);
					HashMap var11 = new HashMap();
					var11.put("name", var10.getName());
					if (var10.getObjectClass() != null) {
						var11.put("objectClass", var10.getObjectClass());
					}

					var6.add(var11);
				}
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPGroupDynamicMemberAttrs", " returning " + var6);
		}

		return var6;
	}

	public String setIdMgrLDAPContextPool(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setIdMgrLDAPContextPool", "Parms: " + var2.toString());
		}

		String var5 = (String) var2.get("id");
		Boolean var6 = (Boolean) var2.get("enabled");
		Integer var7 = (Integer) var2.get("initPoolSize");
		Integer var8 = (Integer) var2.get("maxPoolSize");
		Integer var9 = (Integer) var2.get("prefPoolSize");
		Integer var10 = (Integer) var2.get("poolTimeOut");
		Integer var11 = (Integer) var2.get("poolWaitTime");
		LdapRepositoryType var12 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		ContextPoolType var13 = ConfigUtils.getOrCreateContextPool(var12);
		if (var6 != null) {
			var13.setEnabled(var6);
		}

		if (var7 != null) {
			var13.setInitPoolSize(var7);
		}

		if (var8 != null) {
			var13.setMaxPoolSize(var8);
		}

		if (var9 != null) {
			var13.setPrefPoolSize(var9);
		}

		if (var10 != null) {
			var13.setPoolTimeOut(var10);
		}

		if (var11 != null) {
			var13.setPoolWaitTime(var11);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "setIdMgrLDAPContextPool");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public Map getIdMgrLDAPContextPool(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPContextPool", "Parms: " + var2.toString());
		}

		HashMap var5 = new HashMap();
		String var6 = (String) var2.get("id");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var6,
				"LdapRepositoryType");
		ContextPoolType var8 = var7.getContextPool();
		if (var8 != null) {
			var5.put("enabled", var8.isEnabled());
			var5.put("initPoolSize", new Integer(var8.getInitPoolSize()));
			var5.put("maxPoolSize", new Integer(var8.getMaxPoolSize()));
			var5.put("prefPoolSize", new Integer(var8.getPrefPoolSize()));
			var5.put("poolTimeOut", new Integer(var8.getPoolTimeOut()));
			var5.put("poolWaitTime", new Integer(var8.getPoolWaitTime()));
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPContextPool", "Result: " + var5.toString());
		}

		return var5;
	}

	public String setIdMgrLDAPAttrCache(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setIdMgrLDAPAttrCache", "Parms: " + var2.toString());
		}

		String var5 = (String) var2.get("id");
		Boolean var6 = (Boolean) var2.get("enabled");
		Integer var7 = (Integer) var2.get("cacheSize");
		Integer var8 = (Integer) var2.get("cacheTimeOut");
		Integer var9 = (Integer) var2.get("attributeSizeLimit");
		String var10 = (String) var2.get("serverTTLAttribute");
		Boolean var11 = (Boolean) var2.get("cachesDiskOffLoad");
		String var12 = (String) var2.get("cacheDistPolicy");
		LdapRepositoryType var13 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		if (var12 != null && !"".equals(var12)) {
			ValidationHelper.validateParam("cacheDistPolicy", var12, CONFIG_CACHE_DIST_POLICIES);
		}

		CacheConfigurationType var14 = ConfigUtils.getOrCreateCacheConfiguration(var13);
		if (var11 != null) {
			var14.setCachesDiskOffLoad(var11);
		}

		AttributesCacheType var15 = ConfigUtils.getOrCreateAttributesCache(var13);
		if (var6 != null) {
			var15.setEnabled(var6);
		}

		if (var7 != null) {
			var15.setCacheSize(var7);
		}

		if (var8 != null) {
			var15.setCacheTimeOut(var8);
		}

		if (var9 != null) {
			var15.setAttributeSizeLimit(var9);
		}

		if (var10 != null) {
			var15.setServerTTLAttribute(var10);
		}

		if (var12 != null) {
			var15.setCacheDistPolicy(var12);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "setIdMgrLDAPAttrCache");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public Map getIdMgrLDAPAttrCache(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPAttrCache", "Parms: " + var2.toString());
		}

		HashMap var5 = new HashMap();
		String var6 = (String) var2.get("id");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var6,
				"LdapRepositoryType");
		CacheConfigurationType var8 = ConfigUtils.getOrCreateCacheConfiguration(var7);
		if (var8.isSetCachesDiskOffLoad()) {
			var5.put("cachesDiskOffLoad", var8.isCachesDiskOffLoad());
		}

		AttributesCacheType var9 = ConfigUtils.getOrCreateAttributesCache(var7);
		if (var9.isSetEnabled()) {
			var5.put("enabled", var9.isEnabled());
		}

		if (var9.isSetCacheSize()) {
			var5.put("cacheSize", new Integer(var9.getCacheSize()));
		}

		if (var9.isSetCacheTimeOut()) {
			var5.put("cacheTimeOut", new Integer(var9.getCacheTimeOut()));
		}

		if (var9.isSetAttributeSizeLimit()) {
			var5.put("attributeSizeLimit", new Integer(var9.getAttributeSizeLimit()));
		}

		if (var9.getServerTTLAttribute() != null) {
			var5.put("serverTTLAttribute", var9.getServerTTLAttribute());
		}

		if (var9.getCacheDistPolicy() != null) {
			var5.put("cacheDistPolicy", var9.getCacheDistPolicy());
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPAttrCache", "Result: " + var5.toString());
		}

		return var5;
	}

	public String setIdMgrLDAPSearchResultCache(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setIdMgrLDAPSearchResultCache", "Parms: " + var2.toString());
		}

		String var5 = (String) var2.get("id");
		Boolean var6 = (Boolean) var2.get("cachesDiskOffLoad");
		Boolean var7 = (Boolean) var2.get("enabled");
		Integer var8 = (Integer) var2.get("cacheSize");
		Integer var9 = (Integer) var2.get("cacheTimeOut");
		Integer var10 = (Integer) var2.get("searchResultSizeLimit");
		String var11 = (String) var2.get("cacheDistPolicy");
		LdapRepositoryType var12 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		if (var11 != null && !"".equals(var11)) {
			ValidationHelper.validateParam("cacheDistPolicy", var11, CONFIG_CACHE_DIST_POLICIES);
		}

		CacheConfigurationType var13 = ConfigUtils.getOrCreateCacheConfiguration(var12);
		if (var6 != null) {
			var13.setCachesDiskOffLoad(var6);
		}

		SearchResultsCacheType var14 = ConfigUtils.getOrCreateSearchResultsCache(var12);
		if (var7 != null) {
			var14.setEnabled(var7);
		}

		if (var8 != null) {
			var14.setCacheSize(var8);
		}

		if (var9 != null) {
			var14.setCacheTimeOut(var9);
		}

		if (var10 != null) {
			var14.setSearchResultSizeLimit(var10);
		}

		if (var11 != null) {
			var14.setCacheDistPolicy(var11);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "setIdMgrLDAPSearchResultCache");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public Map getIdMgrLDAPSearchResultCache(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPSearchResultCache", "Parms: " + var2.toString());
		}

		HashMap var5 = new HashMap();
		String var6 = (String) var2.get("id");
		LdapRepositoryType var7 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var6,
				"LdapRepositoryType");
		CacheConfigurationType var8 = ConfigUtils.getOrCreateCacheConfiguration(var7);
		if (var8.isSetCachesDiskOffLoad()) {
			var5.put("cachesDiskOffLoad", var8.isCachesDiskOffLoad());
		}

		SearchResultsCacheType var9 = ConfigUtils.getOrCreateSearchResultsCache(var7);
		if (var9.isSetEnabled()) {
			var5.put("enabled", var9.isEnabled());
		}

		if (var9.isSetCacheSize()) {
			var5.put("cacheSize", new Integer(var9.getCacheSize()));
		}

		if (var9.isSetCacheTimeOut()) {
			var5.put("cacheTimeOut", new Integer(var9.getCacheTimeOut()));
		}

		if (var9.isSetSearchResultSizeLimit()) {
			var5.put("searchResultSizeLimit", new Integer(var9.getSearchResultSizeLimit()));
		}

		if (var9.getCacheDistPolicy() != null) {
			var5.put("cacheDistPolicy", var9.getCacheDistPolicy());
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPSearchResultCache", "Result: " + var5.toString());
		}

		return var5;
	}

	public List listIdMgrSupportedLDAPServerTypes(String var1) throws WIMException {
		return ConfigUtils.convertArrayToList(CONFIG_LDAP_SUPPORTED_TYPES);
	}

	private Map getDefaultValue() {
		HashMap var1 = null;
		var1 = new HashMap();
		var1.put("adapterClassName", "com.ibm.ws.wim.adapter.ldap.LdapAdapter");
		var1.put("supportPaging", Boolean.valueOf("false"));
		var1.put("supportSorting", Boolean.valueOf("false"));
		var1.put("supportTransactions", Boolean.valueOf("false"));
		var1.put("supportTransactions", Boolean.valueOf("false"));
		var1.put("isExtIdUnique", Boolean.valueOf("true"));
		var1.put("supportExternalName", Boolean.valueOf("false"));
		var1.put("ldapServerType", "IDS51");
		var1.put("certificateMapMode", "exactdn");
		var1.put("translateRDN", Boolean.valueOf("false"));
		return var1;
	}

	private void setLdapServerConfigParams(LdapServerConfigurationType var1, Map var2) {
		Integer var3 = (Integer) var2.get("searchTimeLimit");
		if (var3 != null) {
			var1.setSearchTimeLimit(var3);
		}

		var3 = (Integer) var2.get("searchCountLimit");
		if (var3 != null) {
			var1.setSearchCountLimit(var3);
		}

		var3 = (Integer) var2.get("searchPageSize");
		if (var3 != null) {
			var1.setSearchPageSize(var3);
		}

		String var4 = (String) var2.get("sslConfiguration");
		if (var4 != null) {
			var1.setSslConfiguration(var4);
		}

		Boolean var5 = (Boolean) var2.get("returnToPrimaryServer");
		if (var5 != null) {
			var1.setReturnToPrimaryServer(var5);
		}

		var3 = (Integer) var2.get("primaryServerQueryTimeInterval");
		if (var3 != null) {
			var1.setPrimaryServerQueryTimeInterval(var3);
		}

	}

	private LdapEntityTypesType getEntityType(LdapRepositoryType var1, String var2, boolean var3) throws WIMException {
		String var4 = "getEntityType";
		LdapEntityTypesType var5 = null;
		List var6 = var1.getLdapEntityTypes();
		if (var6 != null) {
			for (int var7 = 0; var7 < var6.size(); ++var7) {
				LdapEntityTypesType var8 = (LdapEntityTypesType) var6.get(var7);
				if (var8.getName().equalsIgnoreCase(var2)) {
					var5 = var8;
					break;
				}
			}
		}

		if (var3 && var5 == null) {
			throw new WIMConfigurationException("INVALID_LDAP_ENTITY_TYPE", WIMMessageHelper.generateMsgParms(var2),
					Level.SEVERE, CLASSNAME, var4);
		} else {
			return var5;
		}
	}

	private RdnAttributesType getRDNAttr(LdapEntityTypesType var1, String var2, boolean var3) throws WIMException {
		String var4 = "getRDNAttr";
		RdnAttributesType var5 = null;
		List var6 = var1.getRdnAttributes();
		if (var6 != null) {
			for (int var7 = 0; var7 < var6.size(); ++var7) {
				RdnAttributesType var8 = (RdnAttributesType) var6.get(var7);
				if (var8.getName().equalsIgnoreCase(var2)) {
					var5 = var8;
					break;
				}
			}
		}

		if (var3 && var5 == null) {
			throw new WIMConfigurationException("INVALID_RDN_ATTR", WIMMessageHelper.generateMsgParms(var2),
					Level.SEVERE, CLASSNAME, var4);
		} else {
			return var5;
		}
	}

	private GroupConfigurationType getLDAPGroupConfig(LdapRepositoryType var1, boolean var2) throws WIMException {
		String var3 = "getLDAPGroupConfig";
		GroupConfigurationType var4 = var1.getGroupConfiguration();
		if (var2 && var4 == null) {
			throw new WIMConfigurationException("MISSING_LDAP_GROUP_CONFIGURATION",
					WIMMessageHelper.generateMsgParms(var1.getId()), Level.SEVERE, CLASSNAME, var3);
		} else {
			return var4;
		}
	}

	private MemberAttributesType getGroupMemberAttr(GroupConfigurationType var1, String var2, boolean var3)
			throws WIMException {
		String var4 = "getGroupMemberAttr";
		MemberAttributesType var5 = null;
		List var6 = var1.getMemberAttributes();
		if (var6 != null) {
			for (int var7 = 0; var7 < var6.size(); ++var7) {
				MemberAttributesType var8 = (MemberAttributesType) var6.get(var7);
				if (var8.getName().equalsIgnoreCase(var2)) {
					var5 = var8;
					break;
				}
			}
		}

		if (var3 && var5 == null) {
			throw new WIMConfigurationException("INVALID_GROUP_MEMBER_ATTR", WIMMessageHelper.generateMsgParms(var2),
					Level.SEVERE, CLASSNAME, var4);
		} else {
			return var5;
		}
	}

	private DynamicMemberAttributesType getGroupDynamicMemberAttr(GroupConfigurationType var1, String var2,
			boolean var3) throws WIMException {
		String var4 = "getGroupDynamicMemberAttr";
		DynamicMemberAttributesType var5 = null;
		List var6 = var1.getDynamicMemberAttributes();
		if (var6 != null) {
			for (int var7 = 0; var7 < var6.size(); ++var7) {
				DynamicMemberAttributesType var8 = (DynamicMemberAttributesType) var6.get(var7);
				if (var8.getName().equalsIgnoreCase(var2)) {
					var5 = var8;
					break;
				}
			}
		}

		if (var3 && var5 == null) {
			throw new WIMConfigurationException("INVALID_DYNAMIC_GROUP_MEMBER_ATTR",
					WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, var4);
		} else {
			return var5;
		}
	}

	private void setDefaultsForIDS(LdapRepositoryType var1) {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "setDefaultsForIDS");
		}

		LdapEntityTypesType var4 = var1.createLdapEntityTypes();
		var4.setName("Group");
		var4.getObjectClasses().add("groupOfNames");
		var4 = var1.createLdapEntityTypes();
		var4.setName("OrgContainer");
		var4.getObjectClasses().add("organization");
		var4.getObjectClasses().add("organizationalUnit");
		var4.getObjectClasses().add("domain");
		var4.getObjectClasses().add("container");
		RdnAttributesType var5 = var4.createRdnAttributes();
		var5.setName("o");
		var5.setObjectClass("organization");
		var5 = var4.createRdnAttributes();
		var5.setName("ou");
		var5.setObjectClass("organizationalUnit");
		var5 = var4.createRdnAttributes();
		var5.setName("dc");
		var5.setObjectClass("domain");
		var5 = var4.createRdnAttributes();
		var5.setName("cn");
		var5.setObjectClass("container");
		var4 = var1.createLdapEntityTypes();
		var4.setName("PersonAccount");
		var4.getObjectClasses().add("inetOrgPerson");
		GroupConfigurationType var6 = var1.createGroupConfiguration();
		MemberAttributesType var7 = var6.createMemberAttributes();
		var7.setName("member");
		var7.setObjectClass("groupOfNames");
		var7.setDummyMember("uid=dummy");
		var7.setScope("direct");
		AttributeConfigurationType var8 = var1.createAttributeConfiguration();
		AttributeType var9 = var8.createAttributes();
		var9.setName("userPassword");
		var9.setPropertyName("password");
		var9.getEntityTypes().add("PersonAccount");
		var9 = var8.createAttributes();
		var9.setName("krbPrincipalName");
		var9.setPropertyName("kerberosId");
		var9.getEntityTypes().add("PersonAccount");
		PropertiesNotSupportedType var10 = var8.createPropertiesNotSupported();
		var10.setName("homeAddress");
		var10 = var8.createPropertiesNotSupported();
		var10.setName("businessAddress");
		this.setDefaultContextPoolAndCache(var1);
		if (var3) {
			trcLogger.exiting(CLASSNAME, "setDefaultsForIDS");
		}

	}

	private void setDefaultContextPoolAndCache(LdapRepositoryType var1) {
		String var2 = "setDefaultContextPoolAndCache";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var2);
		}

		ContextPoolType var3 = var1.createContextPool();
		var3.setEnabled(true);
		var3.setInitPoolSize(1);
		var3.setMaxPoolSize(0);
		var3.setPrefPoolSize(3);
		var3.setPoolTimeOut(0);
		var3.setPoolWaitTime(3000);
		CacheConfigurationType var4 = var1.createCacheConfiguration();
		AttributesCacheType var5 = var4.createAttributesCache();
		var5.setEnabled(true);
		var5.setCacheSize(4000);
		var5.setCacheTimeOut(1200);
		var5.setAttributeSizeLimit(2000);
		SearchResultsCacheType var6 = var4.createSearchResultsCache();
		var6.setEnabled(true);
		var6.setCacheSize(2000);
		var6.setCacheTimeOut(600);
		var6.setSearchResultSizeLimit(1000);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var2);
		}

	}

	private void setDefaultsForDomino(LdapRepositoryType var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setDefaultsForDomino");
		}

		LdapEntityTypesType var5 = var1.createLdapEntityTypes();
		var5.setName("Group");
		var5.getObjectClasses().add("groupOfNames");
		var5 = var1.createLdapEntityTypes();
		var5.setName("OrgContainer");
		var5.getObjectClasses().add("organization");
		var5.getObjectClasses().add("organizationalUnit");
		var5.getObjectClasses().add("domain");
		var5.getObjectClasses().add("container");
		RdnAttributesType var6 = var5.createRdnAttributes();
		var6.setName("o");
		var6.setObjectClass("organization");
		var6 = var5.createRdnAttributes();
		var6.setName("ou");
		var6.setObjectClass("organizationalUnit");
		var6 = var5.createRdnAttributes();
		var6.setName("dc");
		var6.setObjectClass("domain");
		var6 = var5.createRdnAttributes();
		var6.setName("cn");
		var6.setObjectClass("container");
		var5 = var1.createLdapEntityTypes();
		var5.setName("PersonAccount");
		var5.getObjectClasses().add("inetOrgPerson");
		this.setPersonAccountRDNPropertyForDomino(var1, var2);
		GroupConfigurationType var7 = var1.createGroupConfiguration();
		MemberAttributesType var8 = var7.createMemberAttributes();
		var8.setName("member");
		var8.setObjectClass("groupOfNames");
		var8.setDummyMember("uid=dummy");
		var8.setScope("direct");
		AttributeConfigurationType var9 = var1.createAttributeConfiguration();
		AttributeType var10 = var9.createAttributes();
		var10.setName("userPassword");
		var10.setPropertyName("password");
		var10.getEntityTypes().add("PersonAccount");
		var10 = var9.createAttributes();
		var10.setName("krbPrincipalName");
		var10.setPropertyName("kerberosId");
		var10.getEntityTypes().add("PersonAccount");
		PropertiesNotSupportedType var11 = var9.createPropertiesNotSupported();
		var11.setName("homeAddress");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("businessAddress");
		this.setDefaultContextPoolAndCache(var1);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "setDefaultsForDomino");
		}

	}

	private void setPersonAccountRDNPropertyForDomino(LdapRepositoryType var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setPersonAccountRDNPropertyForDomino");
		}

		List var5 = ConfigUtils.getProfileRepositories(var2);
		if (var5 != null && var5.size() == 1) {
			ProfileRepositoryType var6 = (ProfileRepositoryType) var5.get(0);
			if (var1.getId().equals(var6.getId())) {
				ConfigurationProviderType var7 = ConfigUtils.getConfigProvider(var2);
				SupportedEntityTypesType var8 = SupportedEntityTypeConfigHelper
						.getSupportEntityTypeByName(var7.getSupportedEntityTypes(), "PersonAccount");
				if (var8 != null) {
					if (var4) {
						trcLogger.logp(Level.FINER, CLASSNAME, "setPersonAccountRDNPropertyForDomino",
								"setting the PersonAccount.RDNProperties to cn");
					}

					var8.getRdnProperties().clear();
					var8.getRdnProperties().add("cn");
				}
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "setPersonAccountRDNPropertyForDomino");
		}

	}

	private void setDefaultsForNDSorSunone(LdapRepositoryType var1, String var2) {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "setDefaultsForNDSorSunone");
		}

		LdapEntityTypesType var5 = var1.createLdapEntityTypes();
		var5.setName("Group");
		if (var2.equals("SUNONE")) {
			var5.getObjectClasses().add("groupOfUniqueNames");
		} else {
			var5.getObjectClasses().add("groupOfNames");
		}

		var5 = var1.createLdapEntityTypes();
		var5.setName("OrgContainer");
		var5.getObjectClasses().add("organization");
		var5.getObjectClasses().add("organizationalUnit");
		var5.getObjectClasses().add("domain");
		var5.getObjectClasses().add("container");
		RdnAttributesType var6 = var5.createRdnAttributes();
		var6.setName("o");
		var6.setObjectClass("organization");
		var6 = var5.createRdnAttributes();
		var6.setName("ou");
		var6.setObjectClass("organizationalUnit");
		var6 = var5.createRdnAttributes();
		var6.setName("dc");
		var6.setObjectClass("domain");
		var6 = var5.createRdnAttributes();
		var6.setName("cn");
		var6.setObjectClass("container");
		var5 = var1.createLdapEntityTypes();
		var5.setName("PersonAccount");
		var5.getObjectClasses().add("inetOrgPerson");
		GroupConfigurationType var7 = var1.createGroupConfiguration();
		MemberAttributesType var8 = var7.createMemberAttributes();
		if (var2.equals("SUNONE")) {
			var8.setName("uniquemember");
			var8.setObjectClass("groupOfUniqueNames");
		} else {
			var8.setName("member");
			var8.setObjectClass("groupOfNames");
		}

		var8.setScope("direct");
		AttributeConfigurationType var9 = var1.createAttributeConfiguration();
		AttributeType var10 = var9.createAttributes();
		var10.setName("userPassword");
		var10.setPropertyName("password");
		var10.getEntityTypes().add("PersonAccount");
		var10 = var9.createAttributes();
		var10.setName("krbPrincipalName");
		var10.setPropertyName("kerberosId");
		var10.getEntityTypes().add("PersonAccount");
		PropertiesNotSupportedType var11 = var9.createPropertiesNotSupported();
		var11.setName("homeAddress");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("businessAddress");
		this.setDefaultContextPoolAndCache(var1);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "setDefaultsForNDSorSunone");
		}

	}

	private void setDefaultsForActiveDirectory(LdapRepositoryType var1) {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "setDefaultsForActiveDirectory");
		}

		LdapEntityTypesType var4 = var1.createLdapEntityTypes();
		var4.setName("Group");
		var4.getObjectClasses().add("group");
		var4.setSearchFilter("(ObjectCategory=Group)");
		var4 = var1.createLdapEntityTypes();
		var4.setName("OrgContainer");
		var4.getObjectClasses().add("organization");
		var4.getObjectClasses().add("organizationalUnit");
		var4.getObjectClasses().add("domain");
		var4.getObjectClasses().add("container");
		RdnAttributesType var5 = var4.createRdnAttributes();
		var5.setName("o");
		var5.setObjectClass("organization");
		var5 = var4.createRdnAttributes();
		var5.setName("ou");
		var5.setObjectClass("organizationalUnit");
		var5 = var4.createRdnAttributes();
		var5.setName("dc");
		var5.setObjectClass("domain");
		var5 = var4.createRdnAttributes();
		var5.setName("cn");
		var5.setObjectClass("container");
		var4 = var1.createLdapEntityTypes();
		var4.setName("PersonAccount");
		var4.getObjectClasses().add("user");
		var4.setSearchFilter("(ObjectCategory=User)");
		GroupConfigurationType var6 = var1.createGroupConfiguration();
		MemberAttributesType var7 = var6.createMemberAttributes();
		var7.setName("member");
		var7.setObjectClass("group");
		var7.setScope("direct");
		MembershipAttributeType var8 = var6.createMembershipAttribute();
		var8.setName("memberof");
		var8.setScope("direct");
		AttributeConfigurationType var9 = var1.createAttributeConfiguration();
		AttributeType var10 = var9.createAttributes();
		var10.setName("userAccountControl");
		var10.setDefaultValue("544");
		var10.getEntityTypes().add("PersonAccount");
		var10 = var9.createAttributes();
		var10.setName("samAccountName");
		var10.setPropertyName("uid");
		var10.getEntityTypes().add("PersonAccount");
		var10 = var9.createAttributes();
		var10.setName("samAccountName");
		var10.setDefaultAttribute("cn");
		var10.getEntityTypes().add("Group");
		var10 = var9.createAttributes();
		var10.setName("groupType");
		var10.setDefaultValue("8");
		var10.getEntityTypes().add("Group");
		var10 = var9.createAttributes();
		var10.setName("unicodePwd");
		var10.setPropertyName("password");
		var10.setSyntax("unicodePwd");
		var10 = var9.createAttributes();
		var10.setName("userprincipalname");
		var10.setPropertyName("kerberosId");
		var10.getEntityTypes().add("PersonAccount");
		PropertiesNotSupportedType var11 = var9.createPropertiesNotSupported();
		var11.setName("description");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("jpegPhoto");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("labeledURI");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("carLicense");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("pager");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("roomNumber");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("localityName");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("stateOrProvinceName");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("countryName");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("employeeNumber");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("employeeType");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("businessCategory");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("departmentNumber");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("homeAddress");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("businessAddress");
		this.setDefaultContextPoolAndCache(var1);
		if (var3) {
			trcLogger.exiting(CLASSNAME, "setDefaultsForActiveDirectory");
		}

	}

	private void setDefaultsForADAM(LdapRepositoryType var1) {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "setDefaultsForActiveDirectory");
		}

		LdapEntityTypesType var4 = var1.createLdapEntityTypes();
		var4.setName("Group");
		var4.getObjectClasses().add("group");
		var4.setSearchFilter("(ObjectCategory=Group)");
		var4 = var1.createLdapEntityTypes();
		var4.setName("OrgContainer");
		var4.getObjectClasses().add("organization");
		var4.getObjectClasses().add("organizationalUnit");
		var4.getObjectClasses().add("domain");
		var4.getObjectClasses().add("container");
		RdnAttributesType var5 = var4.createRdnAttributes();
		var5.setName("o");
		var5.setObjectClass("organization");
		var5 = var4.createRdnAttributes();
		var5.setName("ou");
		var5.setObjectClass("organizationalUnit");
		var5 = var4.createRdnAttributes();
		var5.setName("dc");
		var5.setObjectClass("domain");
		var5 = var4.createRdnAttributes();
		var5.setName("cn");
		var5.setObjectClass("container");
		var4 = var1.createLdapEntityTypes();
		var4.setName("PersonAccount");
		var4.getObjectClasses().add("user");
		var4.setSearchFilter("(ObjectCategory=User)");
		GroupConfigurationType var6 = var1.createGroupConfiguration();
		MemberAttributesType var7 = var6.createMemberAttributes();
		var7.setName("member");
		var7.setObjectClass("group");
		var7.setScope("direct");
		MembershipAttributeType var8 = var6.createMembershipAttribute();
		var8.setName("memberof");
		var8.setScope("direct");
		AttributeConfigurationType var9 = var1.createAttributeConfiguration();
		AttributeType var10 = var9.createAttributes();
		var10.setName("cn");
		var10.setDefaultAttribute("cn");
		var10.getEntityTypes().add("Group");
		var10 = var9.createAttributes();
		var10.setName("groupType");
		var10.setDefaultValue("8");
		var10.getEntityTypes().add("Group");
		var10 = var9.createAttributes();
		var10.setName("unicodePwd");
		var10.setPropertyName("password");
		var10.setSyntax("unicodePwd");
		var10 = var9.createAttributes();
		var10.setName("userprincipalname");
		var10.setPropertyName("kerberosId");
		var10.getEntityTypes().add("PersonAccount");
		PropertiesNotSupportedType var11 = var9.createPropertiesNotSupported();
		var11.setName("description");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("jpegPhoto");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("labeledURI");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("carLicense");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("pager");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("roomNumber");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("localityName");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("stateOrProvinceName");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("countryName");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("employeeNumber");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("employeeType");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("businessCategory");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("departmentNumber");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("homeAddress");
		var11 = var9.createPropertiesNotSupported();
		var11.setName("businessAddress");
		this.setDefaultContextPoolAndCache(var1);
		if (var3) {
			trcLogger.exiting(CLASSNAME, "setDefaultsForActiveDirectory");
		}

	}

	private void setDefaultsForCustom(LdapRepositoryType var1) {
	}

	protected Map getLDAPConnectionData(LdapRepositoryType var1, Session var2) throws WIMConfigurationException {
		HashMap var3 = new HashMap();
		LdapServerConfigurationType var4 = var1.getLdapServerConfiguration();
		if (var4 == null) {
			throw new WIMConfigurationException("MISSING_LDAP_SERVER_CONFIGURATION",
					WIMMessageHelper.generateMsgParms(var1.getId()), Level.SEVERE, CLASSNAME, "getLDAPConnectionData");
		} else {
			if (var4 != null) {
				List var5 = var4.getLdapServers();
				if (var5 == null || var5.size() <= 0) {
					throw new WIMConfigurationException("MISSING_LDAP_SERVER_CONFIGURATION",
							WIMMessageHelper.generateMsgParms(var1.getId()), Level.SEVERE, CLASSNAME,
							"getLDAPConnectionData");
				}

				LdapServersType var6 = (LdapServersType) var5.get(0);
				copyLDAPConnectionData(var3, var6, var1, var2);
			}

			return var3;
		}
	}

	protected static void copyLDAPConnectionData(Map var0, LdapServersType var1, LdapRepositoryType var2, Session var3)
			throws WIMConfigurationException {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		List var6 = var1.getConnections();
		if (var6.size() > 0) {
			ConnectionsType var7 = (ConnectionsType) var6.get(0);
			var0.put("host", var7.getHost());
			if (var7.isSetPort()) {
				var0.put("port", new Integer(var7.getPort()));
			}
		}

		if (var1.getBindDN() != null) {
			var0.put("bindDN", var1.getBindDN());
		}

		if (var1.getBindPassword() != null) {
			var0.put("bindPassword", var1.getBindPassword());
		}

		if (var1.isSetAuthentication()) {
			var0.put("authentication", var1.getAuthentication());
		}

		if (var1.isSetSslEnabled()) {
			var0.put("sslEnabled", var1.isSslEnabled());
		}

		if (var1.isSetConnectTimeout()) {
			var0.put("connectTimeout", new Integer(var1.getConnectTimeout()));
		}

		if (var1.isSetBindAuthMechanism()) {
			var0.put("bindAuthMechanism", new String(var1.getBindAuthMechanism()));
			if (var1.getKrb5Authentication() != null) {
				if (var5) {
					trcLogger.logp(Level.FINER, CLASSNAME, "copyLDAPConnectionData", "Adding Krb5Authentication Info");
				}

				Krb5AuthenticationType var9 = var1.getKrb5Authentication();
				if (var9.isSetKrb5Principal()) {
					var0.put("krb5Principal", var9.getKrb5Principal());
				}

				if (var9.isSetKrb5TicketCache()) {
					var0.put("krb5TicketCache", var9.getKrb5TicketCache());
				}

				GlobalKrb5Config var8 = ConfigUtils.getSecurityKrb5Config(var2.getId(), var3, (ConfigService) null);
				if (var8 != null) {
					if (var8.keytab != null) {
						var0.put("krb5Keytab", var8.keytab);
					}

					if (var8.config != null) {
						var0.put("krb5Config", var8.config);
					}
				}
			} else if ("GSSAPI".equals(var1.getBindAuthMechanism()) && var5) {
				trcLogger.logp(Level.FINER, CLASSNAME, "copyLDAPConnectionData", "BindAuthMechanism is set to "
						+ var1.getBindAuthMechanism() + " but Krb5AuthenticationType is null, ");
			}
		}

		var0.put("ldapServerType", var2.getLdapServerType());
		var0.put("certificateMapMode", var2.getCertificateMapMode());
		var0.put("certificateFilter", var2.getCertificateFilter());
		LdapServerConfigurationType var10 = var2.getLdapServerConfiguration();
		if (var10 != null) {
			var0.put("sslConfiguration", var10.getSslConfiguration());
		}

	}

	public String addIdMgrLDAPAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrLDAPAttr", "params: " + var2.toString());
		}

		String var5 = (String) var2.get("id");
		List var6 = (List) var2.get("entityTypes");
		String var7 = (String) var2.get("name");
		String var8 = (String) var2.get("propertyName");
		String var9 = (String) var2.get("syntax");
		String var10 = (String) var2.get("defaultValue");
		String var11 = (String) var2.get("defaultAttribute");
		Object var12 = null;
		if (var8 != null && ("principalName".equalsIgnoreCase(var8) || "realm".equalsIgnoreCase(var8))) {
			throw new WIMConfigurationException("PROPERTY_CAN_NOT_BE_MAPPED", WIMMessageHelper.generateMsgParms(var8),
					CLASSNAME, "addIdMgrLDAPAttr");
		} else {
			ConfigurationProviderType var13 = ConfigUtils.getConfigProvider(var1);
			LdapRepositoryType var14 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
					"LdapRepositoryType");
			AttributeConfigurationType var15 = var14.getAttributeConfiguration();
			String var21;
			if (var15 != null) {
				List var16 = var15.getAttributes();
				int var17 = var16.size();

				for (int var19 = 0; var19 < var17; ++var19) {
					AttributeType var20 = (AttributeType) var16.get(var19);
					var21 = var20.getName();
					List var18;
					if (var21.equalsIgnoreCase(var7)) {
						var18 = var20.getEntityTypes();
						if (var8 == null) {
							this.validateMapping(var6, var7, var18);
						}
					}

					String var22 = var20.getPropertyName();
					if (var22 != null && var22.equalsIgnoreCase(var8)) {
						var18 = var20.getEntityTypes();
						this.validateMapping(var6, var8, var18);
					}
				}
			} else {
				var15 = var14.createAttributeConfiguration();
			}

			if (var7 != null && !this.validateAttributeName((DataObject) var14, var7)) {
				throw new WIMConfigurationException("ATTRIBUTE_NOT_SUPPORTED",
						WIMMessageHelper.generateMsgParms(var7.toString()), Level.SEVERE, CLASSNAME,
						"addIdMgrLDAPAttr");
			} else {
				this.validateEntityTypesAndPropertyName(var6, var8, var14, var1);
				AttributeType var23 = var15.createAttributes();
				List var24 = var15.getAttributes();
				var23.setName(var7);
				if (var6 != null && var6.size() > 0) {
					int var25 = var6.size();
					List var26 = var23.getEntityTypes();

					for (int var27 = 0; var27 < var25; ++var27) {
						var21 = (String) var6.get(var27);
						if (!var26.contains(var21)) {
							var26.add(var21);
						}
					}
				}

				if (var8 != null) {
					var23.setPropertyName(var8);
				}

				if (var9 != null && !var9.equalsIgnoreCase("string")) {
					var23.setSyntax(var9);
				}

				if (var10 != null) {
					var23.setDefaultValue(var10);
				}

				if (var11 != null) {
					var23.setDefaultAttribute(var11);
				}

				if (var4) {
					trcLogger.exiting(CLASSNAME, "addIdMgrLDAPAttr");
				}

				return ConfigUtils.saveConfig(var1);
			}
		}
	}

	public List listIdMgrLDAPAttrs(String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrLDAPAttrs");
		}

		LdapRepositoryType var5 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		ArrayList var6 = new ArrayList();
		AttributeConfigurationType var7 = var5.getAttributeConfiguration();
		if (null != var7) {
			List var8 = var7.getAttributes();
			int var9 = var8.size();

			for (int var10 = 0; var10 < var9; ++var10) {
				HashMap var11 = new HashMap();
				var11.put("id", var2);
				List var12 = ((AttributeType) var8.get(var10)).getEntityTypes();
				if (var12 != null && var12.size() > 0) {
					String var13 = (String) var12.get(0);
					if (var12.size() > 1) {
						int var14 = var12.size();

						for (int var15 = 1; var15 < var14; ++var15) {
							var13 = var13 + this.SEMICOLON_DELIMITER + var12.get(var15);
						}
					}

					var11.put("entityTypes", var13);
					ArrayList var17 = new ArrayList();
					Iterator var18 = var12.iterator();

					while (var18.hasNext()) {
						Object var16 = var18.next();
						var17.add(var16);
					}

					var11.put("entityTypesList", var17);
				}

				if (((AttributeType) var8.get(var10)).getName() != null) {
					var11.put("name", ((AttributeType) var8.get(var10)).getName());
				}

				if (((AttributeType) var8.get(var10)).getPropertyName() != null) {
					var11.put("propertyName", ((AttributeType) var8.get(var10)).getPropertyName());
				}

				if (((AttributeType) var8.get(var10)).getSyntax() != null) {
					var11.put("syntax", ((AttributeType) var8.get(var10)).getSyntax());
				}

				if (((AttributeType) var8.get(var10)).getDefaultValue() != null) {
					var11.put("defaultValue", ((AttributeType) var8.get(var10)).getDefaultValue());
				}

				if (((AttributeType) var8.get(var10)).getDefaultAttribute() != null) {
					var11.put("defaultAttribute", ((AttributeType) var8.get(var10)).getDefaultAttribute());
				}

				var6.add(var11);
			}
		} else if (var4) {
			trcLogger.logp(Level.WARNING, CLASSNAME, "listIdMgrLDAPAttrs",
					"Attributes are not configured for repository id : " + var2);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "listIdMgrLDAPAttrs", "result: " + var6.toString());
		}

		return var6;
	}

	public Map getIdMgrLDAPAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrLDAPAtt");
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("entityTypes");
		String var7 = (String) var2.get("name");
		HashMap var8 = new HashMap();
		String var9 = null;
		String var10 = null;
		String var11 = null;
		String var12 = null;
		String var13 = null;
		String var14 = null;
		ArrayList var15 = new ArrayList();
		LdapRepositoryType var16 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		AttributeConfigurationType var17 = var16.getAttributeConfiguration();
		List var18 = var17.getAttributes();

		int var19;
		for (var19 = 0; var19 < var18.size(); ++var19) {
			if (var7.equalsIgnoreCase(((AttributeType) var18.get(var19)).getName())) {
				if (var14 != null) {
					if (var14.equalsIgnoreCase(((AttributeType) var18.get(var19)).getEntityTypes().toString())) {
						var15.add(new Integer(var19));
					}
				} else {
					var15.add(new Integer(var19));
				}
			}
		}

		if (var15 != null && var15.size() != 0) {
			if (var15.size() != 1) {
				throw new WIMConfigurationException("MORE_THAN_ONE_ATTRIBUTE_MAPPING",
						WIMMessageHelper.generateMsgParms(var9), Level.WARNING, CLASSNAME, "getIdMgrLDAPAtt");
			}

			var19 = (Integer) var15.get(0);
			var9 = ((AttributeType) var18.get(var19)).getName();
			var10 = ((AttributeType) var18.get(var19)).getSyntax();
			var11 = ((AttributeType) var18.get(var19)).getDefaultValue();
			var12 = ((AttributeType) var18.get(var19)).getDefaultAttribute();
			var13 = ((AttributeType) var18.get(var19)).getPropertyName();
			var14 = ((AttributeType) var18.get(var19)).getEntityTypes().toString();
			var8.put("id", var5);
			var8.put("attributes", var9);
			if (var10 != null) {
				var8.put("syntax", var10);
			}

			if (var11 != null) {
				var8.put("defaultValue", var11);
			}

			if (var12 != null) {
				var8.put("defaultAttribute", var12);
			}

			if (var13 != null) {
				var8.put("propertyName", var13);
			}

			if (var14 != null) {
				var8.put("entityTypes", var14);
			}
		} else {
			trcLogger.logp(Level.WARNING, CLASSNAME, "getIdMgrLDAPAtt", "no attribute configration defined");
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrLDAPAtt", "resultMap: " + var8.toString());
		}

		return var8;
	}

	public String updateIdMgrLDAPAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "updateIdMgrLDAPAtts");
		}

		String var5 = null;
		String var6 = (String) var2.get("id");
		String var7 = (String) var2.get("entityTypes");
		String var8 = (String) var2.get("name");
		String var9 = (String) var2.get("propertyName");
		String var10 = (String) var2.get("syntax");
		String var11 = (String) var2.get("defaultValue");
		String var12 = (String) var2.get("defaultAttribute");
		LdapEntityTypesType var13 = null;
		boolean var14 = false;
		int var15 = -1;
		String var16 = "CONFIG_SAVED_IN_WORKSPACE";
		LdapRepositoryType var17 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var6,
				"LdapRepositoryType");
		AttributeConfigurationType var18 = var17.getAttributeConfiguration();
		List var19 = var18.getAttributes();

		for (int var20 = 0; var20 < var19.size(); ++var20) {
			var5 = ((AttributeType) var19.get(var20)).getName();
			if (var8.equalsIgnoreCase(var5)) {
				if (var7 == null) {
					var14 = true;
					var15 = var20;
					break;
				}

				var13 = this.getEntityType(var17, var7, false);
				if (var13 == null) {
					throw new WIMConfigurationException("ENTITY_TYPE_NOT_SUPPORTED",
							WIMMessageHelper.generateMsgParms(var8), Level.SEVERE, CLASSNAME, "updateIdMgrLDAPAtts");
				}

				if (((AttributeType) var19.get(var20)).getEntityTypes().size() != 0 && var13.getName()
						.equalsIgnoreCase((String) ((AttributeType) var19.get(var20)).getEntityTypes().get(0))) {
					var14 = true;
					var15 = var20;
					break;
				}
			}
		}

		if (var14) {
			AttributeType var21 = (AttributeType) var19.get(var15);
			if (var10 != null) {
				if (((AttributeType) var19.get(var15)).getSyntax() != null) {
					if (!((AttributeType) var19.get(var15)).getSyntax().equalsIgnoreCase(var10)) {
						var21.setSyntax(var10);
					}
				} else {
					var21.setSyntax(var10);
				}
			}

			if (var11 != null) {
				if (((AttributeType) var19.get(var15)).getDefaultValue() != null) {
					if (!((AttributeType) var19.get(var15)).getDefaultValue().equalsIgnoreCase(var11)) {
						var21.setDefaultValue(var11);
					}
				} else {
					var21.setDefaultValue(var11);
				}
			}

			if (var12 != null) {
				if (((AttributeType) var19.get(var15)).getDefaultAttribute() != null) {
					if (!((AttributeType) var19.get(var15)).getDefaultAttribute().equalsIgnoreCase(var12)) {
						var21.setDefaultAttribute(var12);
					}
				} else {
					var21.setDefaultAttribute(var12);
				}
			}

			if (var9 != null) {
				if (((AttributeType) var19.get(var15)).getPropertyName() != null) {
					if (!((AttributeType) var19.get(var15)).getPropertyName().equalsIgnoreCase(var9)) {
						var21.setPropertyName(var9);
					}
				} else {
					var21.setPropertyName(var9);
				}
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "updateIdMgrLDAPAtts");
			}

			ConfigUtils.saveConfig(var1);
			return var16;
		} else {
			throw new WIMConfigurationException("ATTRIBUTE_MAPPING_NOT_DEFINED",
					WIMMessageHelper.generateMsgParms(var5), CLASSNAME, "updateIdMgrLDAPAtts");
		}
	}

	public String deleteIdMgrLDAPAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPAttr", "params: " + var2.toString());
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("name");
		String var7 = (String) var2.get("propertyName");
		List var8 = (List) var2.get("entityTypes");
		ArrayList var9 = null;
		Object var10 = null;
		boolean var11 = false;
		String var12 = null;
		String var13 = "CONFIG_SAVED_IN_WORKSPACE";
		if (var6 == null && var7 == null || var6 != null && var7 != null) {
			throw new WIMConfigurationException("ATTR_OR_PROP_NAME_REQD", CLASSNAME, "deleteIdMgrLDAPAttr");
		} else {
			if (var7 != null && var6 == null) {
				var12 = var7;
			} else if (var6 != null && var7 == null) {
				var12 = var6;
			}

			LdapRepositoryType var14 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
					"LdapRepositoryType");
			if (var8 != null && var8.size() > 0) {
				var9 = new ArrayList();
				int var15 = var8.size();

				for (int var16 = 0; var16 < var15; ++var16) {
					var9.add(this.getEntityType(var14, (String) var8.get(var16), true).getName());
				}
			}

			AttributeConfigurationType var22 = var14.getAttributeConfiguration();
			List var23 = var22.getAttributes();
			ArrayList var17 = new ArrayList();
			Iterator var18 = var23.iterator();

			while (true) {
				while (true) {
					AttributeType var19;
					String var20;
					do {
						if (!var18.hasNext()) {
							if (!var11) {
								throw new WIMConfigurationException("ATTRIBUTE_MAPPING_NOT_DEFINED",
										WIMMessageHelper.generateMsgParms(var12), CLASSNAME, "deleteIdMgrLDAPAttr");
							}

							if (var17.size() > 0) {
								var23.removeAll(var17);
							}

							if (var4) {
								trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPAttr");
							}

							return ConfigUtils.saveConfig(var1);
						}

						var19 = (AttributeType) var18.next();
						var20 = var7 != null ? var19.getPropertyName() : var19.getName();
					} while (!var12.equalsIgnoreCase(var20));

					List var21 = var19.getEntityTypes();
					if (var9 != null && var9.size() > 0) {
						var11 = this.deleteMapping(var12, var9, var21);
						if (var11 && var21.size() == 0) {
							var17.add(var19);
						}
					} else {
						var17.add(var19);
						var11 = true;
					}
				}
			}
		}
	}

	private boolean validatePropertyName(String var1, String var2) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validatePropertyName", "entityType=" + var1 + ", propName=" + var2);
		}

		boolean var4 = false;
		if (var1 != null) {
			SchemaManager var5 = null;

			try {
				var5 = SchemaManager.singleton();
			} catch (WIMException var9) {
				throw new WIMConfigurationException(var9.getMessageKey(), var9.getMessageParams(), CLASSNAME,
						"validatePropertyName");
			}

			List var6 = var5.getProperties(var1);
			ArrayList var7 = new ArrayList();
			int var8;
			if (var6 != null) {
				for (var8 = 0; var8 < var6.size(); ++var8) {
					var7.add(((Property) var6.get(var8)).getName());
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "validatePropertyName", "props of " + var1 + ":" + var7);
			}

			for (var8 = 0; var8 < var7.size(); ++var8) {
				if (var2.equalsIgnoreCase((String) var7.get(var8))) {
					var4 = true;
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "validatePropertyName");
		}

		return var4;
	}

	private boolean validateAttributeName(DataObject var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateAttributeName", "attrName=" + var2);
		}

		DirContext var4 = null;
		String var5 = "AttributeDefinition";
		LdapConnection var6 = null;
		LdapConfigManager var7 = new LdapConfigManager();
		var7.initialize(var1);
		var6 = new LdapConnection(var7);
		var6.initialize(var1);

		boolean var9;
		try {
			var4 = var6.getDirContext();
			DirContext var8 = var4.getSchema("");
			var8.getAttributes(var5 + "/" + var2);
			boolean var10 = true;
			return var10;
		} catch (NameNotFoundException var15) {
			trcLogger.logp(Level.FINE, CLASSNAME, "validateAttributeName", "LDAP exception: " + var15.toString(true),
					var15);
			var9 = false;
		} catch (NamingException var16) {
			trcLogger.logp(Level.FINE, CLASSNAME, "validateAttributeName", "LDAP exception: " + var16.toString(true),
					var16);
			var9 = false;
			return var9;
		} finally {
			if (var4 != null) {
				var6.releaseDirContext(var4);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateAttributeName");
			}

		}

		return var9;
	}

	public String addIdMgrLDAPAttrNotSupported(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrLDAPAttrNotSupported", "params: " + var2.toString());
		}

		String var5 = (String) var2.get("id");
		List var6 = (List) var2.get("entityTypes");
		String var7 = (String) var2.get("propertyName");
		Object var8 = null;
		ConfigurationProviderType var9 = ConfigUtils.getConfigProvider(var1);
		LdapRepositoryType var10 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		AttributeConfigurationType var11 = var10.getAttributeConfiguration();
		String var17;
		if (var11 != null) {
			List var12 = var11.getPropertiesNotSupported();
			int var13 = var12.size();

			for (int var15 = 0; var15 < var13; ++var15) {
				PropertiesNotSupportedType var16 = (PropertiesNotSupportedType) var12.get(var15);
				var17 = var16.getName();
				if (var17.equalsIgnoreCase(var7)) {
					List var14 = var16.getEntityTypes();
					this.validateMapping(var6, var7, var14);
				}
			}
		} else {
			var11 = var10.createAttributeConfiguration();
		}

		this.validateEntityTypesAndPropertyName(var6, var7, var10, var1);
		PropertiesNotSupportedType var18 = var11.createPropertiesNotSupported();
		List var19 = var11.getPropertiesNotSupported();
		var18.setName(var7);
		if (var6 != null && var6.size() > 0) {
			int var20 = var6.size();
			List var21 = var18.getEntityTypes();

			for (int var22 = 0; var22 < var20; ++var22) {
				var17 = (String) var6.get(var22);
				if (!var21.contains(var17)) {
					var21.add(var17);
				}
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "addIdMgrLDAPAttrNotSupported");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List listIdMgrLDAPAttrsNotSupported(String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrLDAPAttrsNotSupported");
		}

		LdapRepositoryType var5 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		ArrayList var6 = new ArrayList();
		AttributeConfigurationType var7 = var5.getAttributeConfiguration();
		if (null != var7) {
			List var8 = var7.getPropertiesNotSupported();
			int var9 = var8.size();

			for (int var10 = 0; var10 < var9; ++var10) {
				HashMap var11 = new HashMap();
				var11.put("id", var2);
				List var12 = ((PropertiesNotSupportedType) var8.get(var10)).getEntityTypes();
				if (var12 != null && var12.size() > 0) {
					ArrayList var13 = new ArrayList();
					Iterator var14 = var12.iterator();

					while (var14.hasNext()) {
						Object var15 = var14.next();
						var13.add(var15);
					}

					var11.put("entityTypes", var13);
				}

				if (((PropertiesNotSupportedType) var8.get(var10)).getName() != null) {
					var11.put("propertyName", ((PropertiesNotSupportedType) var8.get(var10)).getName());
				}

				var6.add(var11);
			}
		} else if (var4) {
			trcLogger.logp(Level.WARNING, CLASSNAME, "listIdMgrLDAPAttrsNotSupported",
					"Attributes are not configured for repository id : " + var2);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "listIdMgrLDAPAttrsNotSupported", "result: " + var6.toString());
		}

		return var6;
	}

	public String deleteIdMgrLDAPAttrNotSupported(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPAttrNotSupported", "params: " + var2.toString());
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("propertyName");
		List var7 = (List) var2.get("entityTypes");
		ArrayList var8 = null;
		Object var9 = null;
		boolean var10 = false;
		String var11 = "CONFIG_SAVED_IN_WORKSPACE";
		LdapRepositoryType var12 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		if (var7 != null && var7.size() > 0) {
			var8 = new ArrayList();

			for (int var13 = 0; var13 < var7.size(); ++var13) {
				var8.add(this.getEntityType(var12, (String) var7.get(var13), true).getName());
			}
		}

		AttributeConfigurationType var20 = var12.getAttributeConfiguration();
		List var14 = var20.getPropertiesNotSupported();
		ArrayList var15 = new ArrayList();
		Iterator var16 = var14.iterator();

		while (true) {
			while (true) {
				PropertiesNotSupportedType var17;
				String var18;
				do {
					if (!var16.hasNext()) {
						if (var15.size() > 0) {
							var14.removeAll(var15);
						}

						if (!var10) {
							throw new WIMConfigurationException("ATTRIBUTE_MAPPING_NOT_DEFINED",
									WIMMessageHelper.generateMsgParms(var6), CLASSNAME,
									"deleteIdMgrLDAPAttrNotSupported");
						}

						if (var4) {
							trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPAttrNotSupported");
						}

						return ConfigUtils.saveConfig(var1);
					}

					var17 = (PropertiesNotSupportedType) var16.next();
					var18 = var17.getName();
				} while (!var18.equalsIgnoreCase(var6));

				List var19 = var17.getEntityTypes();
				if (var8 != null && var8.size() > 0) {
					var10 = this.deleteMapping(var6, var8, var19);
					if (var10 && var19.size() == 0) {
						var15.add(var17);
					}
				} else {
					var15.add(var17);
					var10 = true;
				}
			}
		}
	}

	public String addIdMgrLDAPExternalIdAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "addIdMgrLDAPExternalIdAttr", "params: " + var2.toString());
		}

		String var5 = (String) var2.get("id");
		List var6 = (List) var2.get("entityTypes");
		String var7 = (String) var2.get("name");
		String var8 = (String) var2.get("syntax");
		boolean var9 = (Boolean) var2.get("wimGenerate");
		Object var10 = null;
		ConfigurationProviderType var11 = ConfigUtils.getConfigProvider(var1);
		LdapRepositoryType var12 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		AttributeConfigurationType var13 = var12.getAttributeConfiguration();
		int var17;
		String var19;
		if (var13 != null) {
			List var14 = var13.getExternalIdAttributes();
			int var15 = var14.size();

			for (var17 = 0; var17 < var15; ++var17) {
				AttributeType var18 = (AttributeType) var14.get(var17);
				var19 = var18.getName();
				if (var19.equalsIgnoreCase(var7)) {
					List var16 = var18.getEntityTypes();
					this.validateMapping(var6, var7, var16);
				}
			}
		} else {
			var13 = var12.createAttributeConfiguration();
		}

		List var22;
		int var26;
		if (var7 != null) {
			DataObject var20 = ConfigManager.singleton().getConfig();
			var22 = var20.getList("repositories");
			DataObject var23 = null;
			var17 = var22.size();

			for (var26 = 0; var26 < var17; ++var26) {
				DataObject var27 = (DataObject) var22.get(var26);
				if (var27.getString("id").equalsIgnoreCase(var5)) {
					var23 = var27;
					break;
				}
			}

			if (var23 != null && !var7.equalsIgnoreCase("distinguishedName")
					&& !this.validateAttributeName(var23, var7)) {
				throw new WIMConfigurationException("ATTRIBUTE_NOT_SUPPORTED",
						WIMMessageHelper.generateMsgParms(var7.toString()), Level.SEVERE, CLASSNAME,
						"addIdMgrLDAPExternalIdAttr");
			}
		}

		this.validateEntityTypesAndPropertyName(var6, (String) null, var12, var1);
		AttributeType var21 = var13.createExternalIdAttributes();
		var22 = var13.getExternalIdAttributes();
		var21.setName(var7);
		if (var6 != null && var6.size() > 0) {
			int var24 = var6.size();
			List var25 = var21.getEntityTypes();

			for (var26 = 0; var26 < var24; ++var26) {
				var19 = (String) var6.get(var26);
				if (!var25.contains(var19)) {
					var25.add(var19);
				}
			}
		}

		if (var8 != null && !var8.equalsIgnoreCase("string")) {
			var21.setSyntax(var8);
		}

		if (var9) {
			var21.setWimGenerate(var9);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "addIdMgrLDAPExternalIdAttr");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public String deleteIdMgrLDAPExternalIdAttr(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteIdMgrLDAPExternalIdAttr", "params: " + var2.toString());
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("name");
		List var7 = (List) var2.get("entityTypes");
		boolean var8 = false;
		String var9 = "CONFIG_SAVED_IN_WORKSPACE";
		LdapRepositoryType var10 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var5,
				"LdapRepositoryType");
		ArrayList var11 = null;
		if (var7 != null && var7.size() > 0) {
			var11 = new ArrayList();
			int var12 = var7.size();

			for (int var13 = 0; var13 < var12; ++var13) {
				var11.add(this.getEntityType(var10, (String) var7.get(var13), true).getName());
			}
		}

		AttributeConfigurationType var19 = var10.getAttributeConfiguration();
		List var20 = var19.getExternalIdAttributes();
		ArrayList var14 = new ArrayList();
		Iterator var15 = var20.iterator();

		while (true) {
			while (true) {
				AttributeType var16;
				String var17;
				do {
					if (!var15.hasNext()) {
						if (!var8) {
							throw new WIMConfigurationException("ATTRIBUTE_MAPPING_NOT_DEFINED",
									WIMMessageHelper.generateMsgParms(var6), CLASSNAME,
									"deleteIdMgrLDAPExternalIdAttr");
						}

						if (var14.size() > 0) {
							var20.removeAll(var14);
						}

						if (var4) {
							trcLogger.exiting(CLASSNAME, "deleteIdMgrLDAPExternalIdAttr");
						}

						return ConfigUtils.saveConfig(var1);
					}

					var16 = (AttributeType) var15.next();
					var17 = var16.getName();
				} while (!var17.equalsIgnoreCase(var6));

				List var18 = var16.getEntityTypes();
				if (var11 != null && var11.size() > 0) {
					var8 = this.deleteMapping(var6, var11, var18);
					if (var8 && var18.size() == 0) {
						var14.add(var16);
					}
				} else {
					var14.add(var16);
					var8 = true;
				}
			}
		}
	}

	public List listIdMgrLDAPExternalIdAttrs(String var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listIdMgrLDAPExternalIdAttrs");
		}

		LdapRepositoryType var5 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var1, var2,
				"LdapRepositoryType");
		ArrayList var6 = new ArrayList();
		AttributeConfigurationType var7 = var5.getAttributeConfiguration();
		if (null != var7) {
			List var8 = var7.getExternalIdAttributes();
			int var9 = var8.size();

			for (int var10 = 0; var10 < var9; ++var10) {
				HashMap var11 = new HashMap();
				var11.put("id", var2);
				List var12 = ((AttributeType) var8.get(var10)).getEntityTypes();
				if (var12 != null && var12.size() > 0) {
					ArrayList var13 = new ArrayList();
					Iterator var14 = var12.iterator();

					while (var14.hasNext()) {
						Object var15 = var14.next();
						var13.add(var15);
					}

					var11.put("entityTypes", var13);
				}

				if (((AttributeType) var8.get(var10)).getName() != null) {
					var11.put("name", ((AttributeType) var8.get(var10)).getName());
				}

				if (((AttributeType) var8.get(var10)).getSyntax() != null) {
					var11.put("syntax", ((AttributeType) var8.get(var10)).getSyntax());
				}

				var11.put("wimGenerate", ((AttributeType) var8.get(var10)).isWimGenerate());
				var6.add(var11);
			}
		} else if (var4) {
			trcLogger.logp(Level.WARNING, CLASSNAME, "listIdMgrLDAPExternalIdAttrs",
					"Attributes are not configured for repository id : " + var2);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "listIdMgrLDAPExternalIdAttrs", "result: " + var6.toString());
		}

		return var6;
	}

	private void validateEntityTypesAndPropertyName(List var1, String var2, LdapRepositoryType var3, String var4)
			throws WIMException, WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateEntityTypeAndPropertyNames",
					"propName=" + var2 + ", entityTypeNameList=" + var1);
		}

		String var7;
		String var10;
		if (var1 != null && var1.size() > 0) {
			int var11 = var1.size();

			for (int var12 = 0; var12 < var11; ++var12) {
				var7 = (String) var1.get(var12);
				this.getEntityType(var3, var7, true);
				var10 = var2;
				if (var2 != null) {
					if (var2.equalsIgnoreCase("ibm-primaryEmail")) {
						var10 = "ibmPrimaryEmail";
					} else if (var2.equalsIgnoreCase("ibm-jobTitle")) {
						var10 = "ibmJobTitle";
					}

					if (!this.validatePropertyName(var7, var10)) {
						throw new WIMConfigurationException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
								WIMMessageHelper.generateMsgParms(var2, var7), Level.SEVERE, CLASSNAME,
								"validateEntityTypeAndPropertyNames");
					}
				}
			}
		} else {
			var7 = var2;
			if (var2 != null) {
				if (var2.equalsIgnoreCase("ibm-primaryEmail")) {
					var7 = "ibmPrimaryEmail";
				} else if (var2.equalsIgnoreCase("ibm-jobTitle")) {
					var7 = "ibmJobTitle";
				}

				List var8 = this.listIdMgrLDAPEntityTypes(var4, var3.getId());
				Iterator var9 = var8.iterator();

				while (var9.hasNext()) {
					var10 = (String) var9.next();
					if (!this.validatePropertyName(var10, var7)) {
						throw new WIMConfigurationException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
								WIMMessageHelper.generateMsgParms(var2, var10), Level.SEVERE, CLASSNAME,
								"validateEntityTypeAndPropertyNames");
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "validateEntityTypeAndPropertyNames");
		}

	}

	private void validateMapping(List var1, String var2, List var3) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateMapping",
					"attrName=" + var2 + ", entityTypeNameList=" + var1 + ", oldEntityTypes=" + var3);
		}

		if (var3 != null && var3.size() > 0) {
			if (var1 != null && var1.size() > 0) {
				int var5 = var1.size();

				for (int var6 = 0; var6 < var5; ++var6) {
					if (var3.contains(var1.get(var6))) {
						throw new WIMConfigurationException("ATTRIBUTE_MAPPING_ALREADY_EXISTS_FOR_ENTITY_TYPE",
								WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, "validateMapping");
					}
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "validateMapping");
				}

			} else {
				throw new WIMConfigurationException("INVALID_COMMON_ATTRIBUTE_MAPPING",
						WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, "validateMapping");
			}
		} else if (var1 != null && var1.size() > 0) {
			throw new WIMConfigurationException("COMMON_ATTRIBUTE_MAPPING_ALREADY_EXISTS",
					WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, "validateMapping");
		} else {
			throw new WIMConfigurationException("ATTRIBUTE_MAPPING_ALREADY_EXIST",
					WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, "validateMapping");
		}
	}

	private boolean deleteMapping(String var1, List var2, List var3) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "deleteMapping",
					"attrName=" + var1 + ", realEntityTypeList=" + var2 + ", entityTypeList=" + var3);
		}

		boolean var5 = false;
		if (var3 != null && var3.size() > 0) {
			if (var3.size() >= var2.size()) {
				if (var3.containsAll(var2)) {
					var3.removeAll(var2);
					var5 = true;
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "deleteMapping");
				}

				return var5;
			} else {
				throw new WIMConfigurationException("ATTRIBUTE_MAPPING_NOT_DEFINED_FOR_ENTITY_TYPE",
						WIMMessageHelper.generateMsgParms(var1), CLASSNAME, "deleteMapping");
			}
		} else {
			throw new WIMConfigurationException("ATTRIBUTE_MAPPING_NOT_DEFINED_FOR_ENTITY_TYPE",
					WIMMessageHelper.generateMsgParms(var1), CLASSNAME, "deleteMapping");
		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = LDAPRepositoryConfigHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}