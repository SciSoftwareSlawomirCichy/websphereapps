package com.ibm.ws.wim.adapter.db;

public class DBEntityIdEntityType {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private Long entId = null;
	private String entType = null;

	public Long getEntId() {
		return this.entId;
	}

	public void setEntId(Long var1) {
		this.entId = var1;
	}

	public String getEntType() {
		return this.entType;
	}

	public void setEntType(String var1) {
		this.entType = var1;
	}
}