package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_ro extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: A fost detectată o inconsistenţă în nivelurile de construire ale componentelor de client ale serverului de aplicaţii instalat. Nivelul biuldului instalat al componentei de client {0} care este {1} este diferit de nivelul de build al componentei client {2} care este {3}."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: A fost detectată o inconsistenţă în nivelurile de build ale componentelor de client ale serverului de aplicaţii instalat care împiedică executarea următoare."},
			{"EXCP_CWSJE0003E", "CWSJE0003E: Nu se poate accesa resursa {1} din cauza excepţiei: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}