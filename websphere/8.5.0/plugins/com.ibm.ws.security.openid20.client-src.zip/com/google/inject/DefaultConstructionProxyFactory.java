package com.google.inject;

import com.google.inject.DefaultConstructionProxyFactory.1;
import com.google.inject.DefaultConstructionProxyFactory.2;
import com.google.inject.spi.InjectionPoint;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

class DefaultConstructionProxyFactory<T> implements ConstructionProxyFactory<T> {
	private final InjectionPoint injectionPoint;

	DefaultConstructionProxyFactory(InjectionPoint injectionPoint) {
		this.injectionPoint = injectionPoint;
	}

	public ConstructionProxy<T> create() {
      Constructor<T> constructor = (Constructor)this.injectionPoint.getMember();
      if (Modifier.isPublic(constructor.getModifiers())) {
         return new 1(this, constructor);
      } else {
         constructor.setAccessible(true);
         return new 2(this, constructor);
      }
   }
}