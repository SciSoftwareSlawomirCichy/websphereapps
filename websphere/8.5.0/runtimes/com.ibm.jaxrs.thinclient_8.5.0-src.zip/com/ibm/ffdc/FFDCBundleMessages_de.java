package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_de extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: FFDC-Formatierungsprogramm hinzugefügt: {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Analysesteuerkomponente mit der Datenbank: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: Fehler beim Auflösen der Analysesteuerkomponente:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: FFDC-Datenkollektor hinzugefügt: {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: FFDC-Datenkollektor entfernt: {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: FFDC-Vorfall in SystemErr erstellt: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC wird im sicheren Modus ausgeführt. Suchen Sie nach dem Fehler {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: Weiterleitungsprogramm für FFDC-Vorfälle hinzugefügt: {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: Weiterleitungsprogramm für FFDC-Vorfälle entfernt: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: FFDC-Vorfall an {0} {1} {2} erstellt."},
			{"FFDCProviderAborted", "FFDC1000I: Der FFDC-provider {0} wurde abgebrochen. Die Ausnahme folgt."},
			{"FFDCProviderAbortedE", "FFDC1001I: Der FFDC-Provider wurde mit der Ausnahme {0} abgebrochen."},
			{"FFDCProviderException", "FFDC1008I: Ausnahme des FFDC-Providers:"},
			{"FFDCProviderInstalled", "FFDC1007I: FFDC-Provider installiert: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: FFDC-Formatierungsprogramm entfernt: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}