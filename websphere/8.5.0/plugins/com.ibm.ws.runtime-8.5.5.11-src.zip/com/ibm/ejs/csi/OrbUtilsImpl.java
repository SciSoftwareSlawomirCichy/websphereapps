package com.ibm.ejs.csi;

import com.ibm.ejs.oa.EJSORB;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.OrbUtils;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.javax.activity.ActivityCompletedException;
import com.ibm.ws.javax.activity.ActivityRequiredException;
import com.ibm.ws.javax.activity.InvalidActivityException;
import java.rmi.AccessException;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.rmi.CORBA.Stub;
import javax.transaction.InvalidTransactionException;
import javax.transaction.TransactionRequiredException;
import javax.transaction.TransactionRolledbackException;
import org.omg.CORBA.ACTIVITY_COMPLETED;
import org.omg.CORBA.ACTIVITY_REQUIRED;
import org.omg.CORBA.CompletionStatus;
import org.omg.CORBA.INVALID_ACTIVITY;
import org.omg.CORBA.INVALID_TRANSACTION;
import org.omg.CORBA.NO_PERMISSION;
import org.omg.CORBA.OBJECT_NOT_EXIST;
import org.omg.CORBA.SystemException;
import org.omg.CORBA.TRANSACTION_REQUIRED;
import org.omg.CORBA.TRANSACTION_ROLLEDBACK;
import org.omg.CORBA.portable.UnknownException;

public class OrbUtilsImpl implements OrbUtils {
	private static final String CLASS_NAME = "com.ibm.ejs.csi.OrbUtilsImpl";

	public void connectToOrb(Object stub) throws CSIException {
		try {
			((Stub) stub).connect(EJSORB.init());
		} catch (Exception var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.csi.OrbUtilsImpl.connectToOrb", "40", this);
			throw new CSIException("stub connect failed", var3);
		}
	}

	public Exception mapException(RemoteException ex) throws CSIException {
		String detail = ex.toString();
		Object sysex;
		if (ex instanceof NoSuchObjectException) {
			sysex = new OBJECT_NOT_EXIST(detail);
		} else if (ex instanceof TransactionRequiredException) {
			sysex = new TRANSACTION_REQUIRED(detail);
		} else if (ex instanceof TransactionRolledbackException) {
			sysex = new TRANSACTION_ROLLEDBACK(detail);
		} else if (ex instanceof InvalidTransactionException) {
			sysex = new INVALID_TRANSACTION(detail);
		} else if (ex instanceof AccessException) {
			sysex = new NO_PERMISSION(detail);
		} else if (ex instanceof ActivityRequiredException) {
			sysex = new ACTIVITY_REQUIRED(detail);
		} else if (ex instanceof InvalidActivityException) {
			sysex = new INVALID_ACTIVITY(detail);
		} else {
			if (!(ex instanceof ActivityCompletedException)) {
				return new UnknownException(ex);
			}

			sysex = new ACTIVITY_COMPLETED(detail);
		}

		((SystemException) sysex).initCause(ex);
		return (Exception) sysex;
	}

	public Exception mapException(RemoteException ex, int minorCode) throws CSIException {
		if (minorCode == 0) {
			return this.mapException(ex);
		} else {
			String detail = ex.toString();
			Object sysex;
			if (ex instanceof NoSuchObjectException) {
				sysex = new OBJECT_NOT_EXIST(detail, minorCode, CompletionStatus.COMPLETED_NO);
			} else if (ex instanceof TransactionRequiredException) {
				sysex = new TRANSACTION_REQUIRED(detail, minorCode, CompletionStatus.COMPLETED_NO);
			} else if (ex instanceof TransactionRolledbackException) {
				sysex = new TRANSACTION_ROLLEDBACK(detail, minorCode, CompletionStatus.COMPLETED_NO);
			} else if (ex instanceof InvalidTransactionException) {
				sysex = new INVALID_TRANSACTION(detail, minorCode, CompletionStatus.COMPLETED_MAYBE);
			} else if (ex instanceof AccessException) {
				sysex = new NO_PERMISSION(detail, minorCode, CompletionStatus.COMPLETED_NO);
			} else if (ex instanceof ActivityRequiredException) {
				sysex = new ACTIVITY_REQUIRED(detail, minorCode, CompletionStatus.COMPLETED_NO);
			} else if (ex instanceof InvalidActivityException) {
				sysex = new INVALID_ACTIVITY(detail, minorCode, CompletionStatus.COMPLETED_NO);
			} else {
				if (!(ex instanceof ActivityCompletedException)) {
					return new UnknownException(ex);
				}

				sysex = new ACTIVITY_COMPLETED(detail, minorCode, CompletionStatus.COMPLETED_NO);
			}

			((SystemException) sysex).initCause(ex.detail);
			return (Exception) sysex;
		}
	}
}