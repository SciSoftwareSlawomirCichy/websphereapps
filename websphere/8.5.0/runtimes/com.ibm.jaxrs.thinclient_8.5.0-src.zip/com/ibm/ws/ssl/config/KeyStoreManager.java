package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.misc.HexDumpEncoder;
import com.ibm.security.util.DerOutputStream;
import com.ibm.websphere.models.config.ipc.ssl.CryptoHardwareToken;
import com.ibm.websphere.models.config.ipc.ssl.KeyFileFormatKind;
import com.ibm.websphere.models.config.ipc.ssl.KeyStore;
import com.ibm.websphere.models.config.ipc.ssl.SecureSocketLayer;
import com.ibm.websphere.models.config.properties.Property;
import com.ibm.websphere.models.config.security.Security;
import com.ibm.websphere.ssl.SSLException;
import com.ibm.ws.security.config.SecurityConfig;
import com.ibm.ws.security.config.SecurityConfigManager;
import com.ibm.ws.security.config.SecurityConfigObject;
import com.ibm.ws.security.config.SecurityConfigObjectList;
import com.ibm.ws.security.config.SecurityObjectLocator;
import com.ibm.ws.security.util.KeyStoreTypeHelper;
import com.ibm.ws.ssl.config.KeyStoreManager.FileExistsAction;
import com.ibm.ws.ssl.config.KeyStoreManager.GetKeyStoreInputStreamAction;
import com.ibm.ws.ssl.config.KeyStoreManager.GetKeyStoreOutputStreamAction;
import com.ibm.ws.ssl.core.TraceNLSHelper;
import com.ibm.ws.ssl.core.WSPKCSInKeyStore;
import com.ibm.ws.ssl.core.WSPKCSInKeyStoreList;
import com.ibm.ws.ssl.model.CertReqInfo;
import com.ibm.ws.ssl.model.KeyStoreInfo;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.AccessController;
import java.security.MessageDigest;
import java.security.PrivilegedActionException;
import java.security.Provider;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import javax.management.ObjectName;

public class KeyStoreManager {
	private static final TraceComponent tc = Tr.register(KeyStoreManager.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private static KeyStoreManager thisClass = null;
	private HashMap keyStoreMap = new HashMap();
	private HashMap acceleratorMap = new HashMap();
	private static HashMap expandMap = new HashMap();
	private static String host;
	private static WSPKCSInKeyStoreList pkcsStoreList = new WSPKCSInKeyStoreList();

	public static KeyStoreManager getInstance() {
		if (thisClass == null) {
			getHostName();
			thisClass = new KeyStoreManager();
		}

		return thisClass;
	}

	public void loadKeyStores(Security security) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadKeyStores");
		}

		this.clearKeyStoreMap();
		List keyStoreList = security.getKeyStores();

		for (int i = 0; i < keyStoreList.size(); ++i) {
			KeyStore keyStore = (KeyStore) keyStoreList.get(i);
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Loading KeyStore name " + keyStore.getName() + ".");
			}

			this.loadWCCMKeyStore(keyStore);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadKeyStores");
		}

	}

	public void loadWCCMKeyStore(KeyStore keyStore) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadWCCMKeyStore");
		}

		String scopeString = null;
		if (keyStore.getManagementScope() != null) {
			scopeString = keyStore.getManagementScope().getScopeName();
		}

		if (scopeString != null && !ManagementScopeManager.getInstance().currentScopeContained(scopeString)) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "KeyStore is not in the current scope.");
			}

		} else {
			String alias = keyStore.getName();
			WSKeyStore wsks_key = new WSKeyStore(keyStore);
			if (alias != null && wsks_key != null) {
				this.addKeyStoreIfNotDuplicate(alias, wsks_key);
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "loadWCCMKeyStore (keystore)");
			}

		}
	}

	public WSKeyStore[] loadOldWCCMKeyStores(String alias, String sslType, SecureSocketLayer ssl) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadOldWCCMKeyStore");
		}

		String ignoreJVMKeystores = SSLConfigManager.getInstance()
				.getGlobalProperty("com.ibm.websphere.ssl.ignore.jvm.keystores", "false");
		if (ignoreJVMKeystores.equalsIgnoreCase("true")) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "returning null as com.ibm.websphere.ssl.ignore.jvm.keystores is set. ");
			}

			return null;
		} else {
			String keyStoreClientAlias = null;
			String keyStoreServerAlias = null;
			String keyStoreName = null;
			String keyStorePassword = null;
			String keyStoreFormat = null;
			String keyStoreProvider = null;
			String trustStoreName = null;
			String trustStorePassword = null;
			String trustStoreFormat = null;
			String trustStoreProvider = null;
			String tokenEnabled = null;
			String tokenLibrary = null;
			String tokenPassword = null;
			String tokenSlot = null;
			String tokenType = null;
			if (ssl != null && sslType != null && sslType.equals("SSSL")) {
				if (ssl != null && ssl.isSetEnableCryptoHardwareSupport() && ssl.isEnableCryptoHardwareSupport()) {
					keyStoreFormat = "JCE4758KS";
					keyStoreName = ssl.getKeyFileName();
					if (keyStoreName != null) {
						keyStoreName = "safkeyringhw:///" + keyStoreName;
					}

					keyStorePassword = ssl.getKeyFilePassword();
					if (keyStorePassword == null) {
						keyStorePassword = "password";
					}

					tokenEnabled = "true";
				} else {
					keyStoreFormat = "JCERACFKS";
					keyStoreName = ssl.getKeyFileName();
					if (keyStoreName != null) {
						keyStoreName = "safkeyring:///" + keyStoreName;
					}

					keyStorePassword = ssl.getKeyFilePassword();
					if (keyStorePassword == null) {
						keyStorePassword = "password";
					}

					tokenEnabled = "false";
				}
			} else {
				if (ssl != null && ssl.isSetEnableCryptoHardwareSupport() && ssl.isEnableCryptoHardwareSupport()) {
					tokenEnabled = "true";
					CryptoHardwareToken orbcrypto = ssl.getCryptoHardware();
					tokenType = orbcrypto.getTokenType();
					tokenLibrary = orbcrypto.getLibraryFile();
					tokenPassword = orbcrypto.getPassword();
				} else {
					tokenEnabled = "false";
				}

				if (ssl != null && ssl.getKeyFileName() != null && !ssl.getKeyFileName().equals("")) {
					keyStoreName = this.expand(ssl.getKeyFileName());
				} else if (ssl == null && System.getProperty("javax.net.ssl.keyStore") != null
						&& System.getProperty("javax.net.ssl.keyStore").length() > 0) {
					keyStoreName = System.getProperty("javax.net.ssl.keyStore");
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Due to missing property,  keyStoreName was not set");
				}

				if (ssl != null && ssl.getKeyFilePassword() != null && !ssl.getKeyFilePassword().equals("")) {
					keyStorePassword = ssl.getKeyFilePassword();
				} else if (ssl == null && System.getProperty("javax.net.ssl.keyStorePassword") != null
						&& System.getProperty("javax.net.ssl.keyStorePassword").length() > 0) {
					keyStorePassword = System.getProperty("javax.net.ssl.keyStorePassword");
					if (keyStorePassword != null) {
						keyStorePassword = SSLConfig.decodePassword(keyStorePassword);
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Decoded keyStorePassword from system prop.");
						}

						System.setProperty("javax.net.ssl.keyStorePassword", keyStorePassword);
					}
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Due to missing property,  keyStorePassword was not set");
				}

				if (ssl != null && ssl.getKeyFileFormat() != null && !ssl.getKeyFileFormat().equals("")) {
					keyStoreFormat = getKeyStoreType(ssl.getKeyFileFormat());
				} else if (ssl == null && System.getProperty("javax.net.ssl.keyStoreType") != null
						&& System.getProperty("javax.net.ssl.keyStoreType").length() > 0) {
					keyStoreFormat = System.getProperty("javax.net.ssl.keyStoreType");
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Due to missing property,  keyStoreFormat was not set");
				}

				if (ssl == null && System.getProperty("javax.net.ssl.keyStoreProvider") != null
						&& System.getProperty("javax.net.ssl.keyStoreProvider").length() > 0) {
					keyStoreProvider = System.getProperty("javax.net.ssl.keyStoreProvider");
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Due to missing property,  keyStoreProvider was not set");
				}

				if (ssl != null && ssl.getTrustFileName() != null && !ssl.getTrustFileName().equals("")) {
					trustStoreName = this.expand(ssl.getTrustFileName());
				} else if (ssl == null && System.getProperty("javax.net.ssl.trustStore") != null
						&& System.getProperty("javax.net.ssl.trustStore").length() > 0) {
					trustStoreName = System.getProperty("javax.net.ssl.trustStore");
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Due to missing property,  trustStoreProvider was not set");
				}

				if (ssl != null && ssl.getTrustFilePassword() != null && !ssl.getTrustFilePassword().equals("")) {
					trustStorePassword = ssl.getTrustFilePassword();
				} else if (ssl == null && System.getProperty("javax.net.ssl.trustStorePassword") != null
						&& System.getProperty("javax.net.ssl.trustStorePassword").length() > 0) {
					trustStorePassword = System.getProperty("javax.net.ssl.trustStorePassword");
					if (trustStorePassword != null) {
						trustStorePassword = SSLConfig.decodePassword(trustStorePassword);
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Decoded trustStorePassword from system prop.");
						}

						System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
					}
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Due to missing property,  trustStorePassword was not set");
				}

				if (ssl != null && ssl.getTrustFileFormat() != null && !ssl.getTrustFileFormat().equals("")) {
					trustStoreFormat = getKeyStoreType(ssl.getTrustFileFormat());
				} else if (ssl == null && System.getProperty("javax.net.ssl.trustStoreType") != null
						&& System.getProperty("javax.net.ssl.trustStoreType").length() > 0) {
					trustStoreFormat = System.getProperty("javax.net.ssl.trustStoreType");
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Due to missing property,  trustStoreFormat was not set");
				}

				if (ssl == null && System.getProperty("javax.net.ssl.trustStoreProvider") != null
						&& System.getProperty("javax.net.ssl.trustStoreProvider").length() > 0) {
					trustStoreProvider = System.getProperty("javax.net.ssl.trustStoreProvider");
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Due to missing property,  trustStoreProvider was not set");
				}
			}

			if (ssl != null) {
				for (int j = 0; j < ssl.getProperties().size(); ++j) {
					Property sslproperty = (Property) ssl.getProperties().get(j);
					if (sslproperty != null) {
						if (sslproperty.getName().equals("com.ibm.ssl.tokenSlot")) {
							tokenSlot = sslproperty.getValue();
						} else if (sslproperty.getName().equals("com.ibm.ssl.keyStoreClientAlias")) {
							keyStoreClientAlias = sslproperty.getValue();
						} else if (sslproperty.getName().equals("com.ibm.ssl.keyStoreServerAlias")) {
							keyStoreServerAlias = sslproperty.getValue();
						}
					}
				}
			}

			WSKeyStore wsks_key = null;
			WSKeyStore wsks_trust = null;
			if (tokenLibrary != null || keyStoreName != null) {
				wsks_key = new WSKeyStore();
				if (tokenEnabled != null) {
					wsks_key.setProperty("com.ibm.ssl.tokenEnabled", tokenEnabled);
				}

				wsks_key.setProperty("com.ibm.ssl.keyStoreScope",
						ManagementScopeManager.getInstance().getCellScopeName());
				if (keyStoreClientAlias != null) {
					wsks_key.setProperty("com.ibm.ssl.keyStoreClientAlias", keyStoreClientAlias);
				}

				if (keyStoreServerAlias != null) {
					wsks_key.setProperty("com.ibm.ssl.keyStoreServerAlias", keyStoreServerAlias);
				}

				if (ssl != null && sslType != null && sslType.equals("SSSL")) {
					wsks_key.setProperty("com.ibm.ssl.keyStoreScope",
							ManagementScopeManager.getInstance().getCellScopeName());
					if (keyStoreName != null) {
						wsks_key.setProperty("com.ibm.ssl.keyStore", keyStoreName);
					}

					if (keyStorePassword != null) {
						wsks_key.setProperty("com.ibm.ssl.keyStorePassword", keyStorePassword);
					}

					if (keyStoreFormat != null) {
						wsks_key.setProperty("com.ibm.ssl.keyStoreType", keyStoreFormat);
						if (!keyStoreFormat.equals("JKS") && !keyStoreFormat.equals("JCEKS")
								&& !keyStoreFormat.equals("PKCS12")) {
							wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
						} else {
							wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
						}
					}

					wsks_key.setProperty("com.ibm.ssl.keyStoreProvider", "IBMJCE");
					wsks_key.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
					wsks_key.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "false");
					wsks_key.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "false");
					wsks_key.setProperty("com.ibm.ssl.keyStoreUseForAcceleration", "false");
				} else if (tokenEnabled.equals("true")) {
					if (tokenLibrary != null) {
						wsks_key.setProperty("com.ibm.ssl.tokenLibraryFile", tokenLibrary);
						wsks_key.setProperty("com.ibm.ssl.keyStore", tokenLibrary);
					}

					if (tokenPassword != null) {
						wsks_key.setProperty("com.ibm.ssl.tokenPassword", tokenPassword);
						wsks_key.setProperty("com.ibm.ssl.keyStorePassword", tokenPassword);
					}

					if (tokenType != null) {
						wsks_key.setProperty("com.ibm.ssl.tokenType", tokenType);
						wsks_key.setProperty("com.ibm.ssl.keyStoreType", tokenType);
					}

					if (tokenSlot != null) {
						wsks_key.setProperty("com.ibm.ssl.tokenSlot", tokenSlot);
						wsks_key.setProperty("com.ibm.ssl.keyStoreSlot", tokenSlot);
					}

					wsks_key.setProperty("com.ibm.ssl.keyStoreProvider", "IBMPKCS11Impl");
					wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
					wsks_key.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
					wsks_key.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "true");
					wsks_key.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "false");
					wsks_key.setProperty("com.ibm.ssl.keyStoreUseForAcceleration", "true");
				} else {
					if (keyStoreName != null) {
						wsks_key.setProperty("com.ibm.ssl.keyStore", keyStoreName);
					}

					if (keyStorePassword != null) {
						wsks_key.setProperty("com.ibm.ssl.keyStorePassword", keyStorePassword);
					}

					if (keyStoreFormat != null) {
						wsks_key.setProperty("com.ibm.ssl.keyStoreType", keyStoreFormat);
						if (!keyStoreFormat.equals("JKS") && !keyStoreFormat.equals("JCEKS")
								&& !keyStoreFormat.equals("PKCS12")) {
							wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
						} else {
							wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
						}
					}

					if (keyStoreFormat != null && keyStoreFormat.equals("JCE4758KS")) {
						wsks_key.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
					} else {
						wsks_key.setProperty("com.ibm.ssl.keyStoreReadOnly", "false");
					}

					if (keyStoreProvider != null) {
						wsks_key.setProperty("com.ibm.ssl.keyStoreProvider", keyStoreProvider);
					} else {
						wsks_key.setProperty("com.ibm.ssl.keyStoreProvider", "IBMJCE");
					}

					wsks_key.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "false");
					wsks_key.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "true");
					wsks_key.setProperty("com.ibm.ssl.keyStoreUseForAcceleration", "false");
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Adding KeyStore name: " + alias + "_key");
				}

				wsks_key.setProperty("com.ibm.ssl.keyStoreName", alias + "_key");
				this.addKeyStoreIfNotDuplicate(alias + "_key", wsks_key);
			}

			if (trustStoreName != null) {
				wsks_trust = new WSKeyStore();
				wsks_trust.setProperty("com.ibm.ssl.tokenEnabled", "false");
				wsks_trust.setProperty("com.ibm.ssl.keyStoreScope",
						ManagementScopeManager.getInstance().getCellScopeName());
				wsks_trust.setProperty("com.ibm.ssl.keyStore", trustStoreName);
				if (trustStorePassword != null) {
					wsks_trust.setProperty("com.ibm.ssl.keyStorePassword", trustStorePassword);
				}

				if (trustStoreFormat != null) {
					wsks_trust.setProperty("com.ibm.ssl.keyStoreType", trustStoreFormat);
					if (!trustStoreFormat.equals("JKS") && !trustStoreFormat.equals("JCEKS")
							&& !trustStoreFormat.equals("PKCS12")) {
						wsks_trust.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
					} else {
						wsks_trust.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
					}
				}

				if (trustStoreFormat != null && trustStoreFormat.equals("JCE4758KS")) {
					wsks_trust.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
				} else {
					wsks_trust.setProperty("com.ibm.ssl.keyStoreReadOnly", "false");
				}

				if (trustStoreProvider != null) {
					wsks_trust.setProperty("com.ibm.ssl.keyStoreProvider", trustStoreProvider);
				} else {
					wsks_trust.setProperty("com.ibm.ssl.keyStoreProvider", "IBMJCE");
				}

				wsks_trust.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "false");
				wsks_trust.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "true");
				wsks_trust.setProperty("com.ibm.ssl.keyStoreUseForAcceleration", "false");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Adding TrustStore name: " + alias + "_trust");
				}

				wsks_trust.setProperty("com.ibm.ssl.keyStoreName", alias + "_trust");
				this.addKeyStoreIfNotDuplicate(alias + "_trust", wsks_trust);
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Total Number of KeyStores: " + this.keyStoreMap.size());
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "loadOldWCCMKeyStore");
			}

			if (wsks_key != null && wsks_trust != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Returning key and trust.");
				}

				return new WSKeyStore[]{wsks_key, wsks_trust};
			} else if (wsks_key != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Copying key to trust.");
				}

				wsks_trust = (WSKeyStore) wsks_key.clone();
				wsks_trust.setProperty("com.ibm.ssl.keyStoreName", alias + "_trust");
				this.addKeyStoreIfNotDuplicate(alias + "_trust", wsks_trust);
				return new WSKeyStore[]{wsks_key, wsks_trust};
			} else if (wsks_trust != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Copying trust to key.");
				}

				wsks_key = (WSKeyStore) wsks_trust.clone();
				wsks_key.setProperty("com.ibm.ssl.keyStoreName", alias + "_key");
				this.addKeyStoreIfNotDuplicate(alias + "_key", wsks_key);
				return new WSKeyStore[]{wsks_key, wsks_trust};
			} else {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Not returning any KeyStores from old WCCM config.");
				}

				return null;
			}
		}
	}

	public void loadKeyStores(SecurityConfigObject security) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadKeyStores");
		}

		this.clearKeyStoreMap();
		SecurityConfigObjectList keyStoreList = security.getObjectList("keyStores");

		for (int i = 0; i < keyStoreList.size(); ++i) {
			SecurityConfigObject keyStore = keyStoreList.get(i);
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Loading KeyStore name " + keyStore.getString("name") + ".");
			}

			this.loadKeyStore(keyStore);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadKeyStores");
		}

	}

	public void loadKeyStore(SecurityConfigObject keyStore) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadWCCMKeyStore");
		}

		String scopeString = null;
		SecurityConfigObject mgmtScope = keyStore.getObject("managementScope");
		if (mgmtScope != null) {
			scopeString = mgmtScope.getString("scopeName");
		}

		if (scopeString != null && !ManagementScopeManager.getInstance().currentScopeContained(scopeString)) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "KeyStore is not in the current scope.");
			}

		} else {
			String alias = keyStore.getString("name");
			WSKeyStore wsks_key = new WSKeyStore(keyStore);
			if (alias != null && wsks_key != null) {
				this.addKeyStoreIfNotDuplicate(alias, wsks_key);
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "loadWCCMKeyStore (keystore)");
			}

		}
	}

	public WSKeyStore[] loadOldWCCMKeyStores(String alias, String sslType, SecurityConfigObject ssl) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "loadOldWCCMKeyStores");
		}

		String keyStoreClientAlias = null;
		String keyStoreServerAlias = null;
		String keyStoreName = null;
		String keyStorePassword = null;
		String keyStoreFormat = null;
		String keyStoreProvider = null;
		String trustStoreName = null;
		String trustStorePassword = null;
		String trustStoreFormat = null;
		String trustStoreProvider = null;
		String tokenEnabled = null;
		String tokenLibrary = null;
		String tokenPassword = null;
		String tokenSlot = null;
		String tokenType = null;
		if (ssl != null && sslType != null && sslType.equals("SSSL")) {
			if (ssl != null && ssl.isSet("enableCryptoHardwareSupport")
					&& ssl.getBoolean("enableCryptoHardwareSupport")) {
				keyStoreFormat = "JCE4758KS";
				keyStoreName = ssl.getUnexpandedString("keyFileName");
				if (keyStoreName != null) {
					keyStoreName = "safkeyringhw:///" + keyStoreName;
				}

				keyStorePassword = ssl.getUnexpandedString("keyFilePassword");
				if (keyStorePassword == null) {
					keyStorePassword = "password";
				}

				tokenEnabled = "true";
			} else {
				keyStoreFormat = "JCERACFKS";
				keyStoreName = ssl.getUnexpandedString("keyFileName");
				if (keyStoreName != null) {
					keyStoreName = "safkeyring:///" + keyStoreName;
				}

				keyStorePassword = ssl.getUnexpandedString("keyFilePassword");
				if (keyStorePassword == null) {
					keyStorePassword = "password";
				}

				tokenEnabled = "false";
			}
		} else {
			if (ssl != null && ssl.isSet("enableCryptoHardwareSupport")
					&& ssl.getBoolean("enableCryptoHardwareSupport")) {
				tokenEnabled = "true";
				SecurityConfigObject orbcrypto = ssl.getObject("cryptoHardware");
				tokenType = orbcrypto.getString("tokenType");
				tokenLibrary = orbcrypto.getUnexpandedString("libraryFile");
				tokenPassword = orbcrypto.getDecodedString("password");
			} else {
				tokenEnabled = "false";
			}

			if (ssl == null && System.getProperty("javax.net.ssl.keyStoreProvider") != null) {
				keyStoreProvider = System.getProperty("javax.net.ssl.keyStoreProvider");
			}

			if (ssl != null && ssl.getUnexpandedString("keyFileName") != null
					&& !ssl.getUnexpandedString("keyFileName").equals("")) {
				keyStoreName = this.expand(ssl.getUnexpandedString("keyFileName"));
			} else if (ssl == null && System.getProperty("javax.net.ssl.keyStore") != null) {
				keyStoreName = System.getProperty("javax.net.ssl.keyStore");
			}

			String password = null;
			if (ssl != null) {
				password = ssl.getDecodedString("keyFilePassword");
			}

			if (password != null && !password.equals("")) {
				keyStorePassword = password;
			} else if (ssl == null && System.getProperty("javax.net.ssl.keyStorePassword") != null) {
				keyStorePassword = System.getProperty("javax.net.ssl.keyStorePassword");
				if (keyStorePassword != null) {
					keyStorePassword = SSLConfig.decodePassword(keyStorePassword);
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Decoded keyStorePassword from system prop.");
					}

					System.setProperty("javax.net.ssl.keyStorePassword", keyStorePassword);
				}
			}

			if (ssl != null && ssl.getString("keyFileFormat", "JKS") != null
					&& !ssl.getString("keyFileFormat", "JKS").equals("")) {
				keyStoreFormat = ssl.getString("keyFileFormat", "JKS");
			} else if (ssl == null && System.getProperty("javax.net.ssl.keyStoreType") != null) {
				keyStoreFormat = System.getProperty("javax.net.ssl.keyStoreType");
			}

			if (ssl == null && System.getProperty("javax.net.ssl.keyStoreProvider") != null) {
				keyStoreProvider = System.getProperty("javax.net.ssl.keyStoreProvider");
			}

			if (ssl != null && ssl.getUnexpandedString("trustFileName") != null
					&& !ssl.getUnexpandedString("trustFileName").equals("")) {
				trustStoreName = this.expand(ssl.getUnexpandedString("trustFileName"));
			} else if (ssl == null && System.getProperty("javax.net.ssl.trustStore") != null) {
				trustStoreName = System.getProperty("javax.net.ssl.trustStore");
			}

			password = null;
			if (ssl != null) {
				password = ssl.getDecodedString("trustFilePassword");
			}

			if (password != null && !password.equals("")) {
				trustStorePassword = password;
			} else if (ssl == null && System.getProperty("javax.net.ssl.trustStorePassword") != null) {
				trustStorePassword = System.getProperty("javax.net.ssl.trustStorePassword");
				if (trustStorePassword != null) {
					trustStorePassword = SSLConfig.decodePassword(trustStorePassword);
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Decoded trustStorePassword from system prop.");
					}

					System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
				}
			}

			if (ssl != null && ssl.getString("trustFileFormat", "JKS") != null
					&& !ssl.getString("trustFileFormat", "JKS").equals("")) {
				trustStoreFormat = ssl.getString("trustFileFormat", "JKS");
			} else if (ssl == null && System.getProperty("javax.net.ssl.trustStoreType") != null) {
				trustStoreFormat = System.getProperty("javax.net.ssl.trustStoreType");
			}

			if (ssl == null && System.getProperty("javax.net.ssl.trustStoreProvider") != null) {
				trustStoreProvider = System.getProperty("javax.net.ssl.trustStoreProvider");
			}
		}

		if (ssl != null) {
			SecurityConfigObjectList sslProps = ssl.getObjectList("properties");

			for (int j = 0; j < sslProps.size(); ++j) {
				SecurityConfigObject sslproperty = sslProps.get(j);
				if (sslproperty != null) {
					String name = sslproperty.getString("name");
					if (name.equals("com.ibm.ssl.tokenSlot")) {
						tokenSlot = sslproperty.getString("value");
					} else if (name.equals("com.ibm.ssl.keyStoreClientAlias")) {
						keyStoreClientAlias = sslproperty.getString("value");
					} else if (name.equals("com.ibm.ssl.keyStoreServerAlias")) {
						keyStoreServerAlias = sslproperty.getString("value");
					}
				}
			}
		}

		WSKeyStore wsks_key = null;
		WSKeyStore wsks_trust = null;
		if (tokenLibrary != null || keyStoreName != null) {
			wsks_key = new WSKeyStore();
			if (tokenEnabled != null) {
				wsks_key.setProperty("com.ibm.ssl.tokenEnabled", tokenEnabled);
			}

			wsks_key.setProperty("com.ibm.ssl.keyStoreScope", ManagementScopeManager.getInstance().getCellScopeName());
			if (keyStoreClientAlias != null) {
				wsks_key.setProperty("com.ibm.ssl.keyStoreClientAlias", keyStoreClientAlias);
			}

			if (keyStoreServerAlias != null) {
				wsks_key.setProperty("com.ibm.ssl.keyStoreServerAlias", keyStoreServerAlias);
			}

			if (ssl != null && sslType != null && sslType.equals("SSSL")) {
				wsks_key.setProperty("com.ibm.ssl.keyStoreScope",
						ManagementScopeManager.getInstance().getCellScopeName());
				if (keyStoreName != null) {
					wsks_key.setProperty("com.ibm.ssl.keyStore", keyStoreName);
				}

				if (keyStorePassword != null) {
					wsks_key.setProperty("com.ibm.ssl.keyStorePassword", keyStorePassword);
				}

				if (keyStoreFormat != null) {
					wsks_key.setProperty("com.ibm.ssl.keyStoreType", keyStoreFormat);
					if (!keyStoreFormat.equals("JKS") && !keyStoreFormat.equals("JCEKS")
							&& !keyStoreFormat.equals("PKCS12")) {
						wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
					} else {
						wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
					}
				}

				wsks_key.setProperty("com.ibm.ssl.keyStoreProvider", "IBMJCE");
				wsks_key.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
				wsks_key.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "false");
				wsks_key.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "false");
				wsks_key.setProperty("com.ibm.ssl.keyStoreUseForAcceleration", "false");
			} else if (tokenEnabled.equals("true")) {
				if (tokenLibrary != null) {
					wsks_key.setProperty("com.ibm.ssl.tokenLibraryFile", tokenLibrary);
					wsks_key.setProperty("com.ibm.ssl.keyStore", tokenLibrary);
				}

				if (tokenPassword != null) {
					wsks_key.setProperty("com.ibm.ssl.tokenPassword", tokenPassword);
					wsks_key.setProperty("com.ibm.ssl.keyStorePassword", tokenPassword);
				}

				if (tokenType != null) {
					wsks_key.setProperty("com.ibm.ssl.tokenType", tokenType);
					wsks_key.setProperty("com.ibm.ssl.keyStoreType", tokenType);
				}

				if (tokenSlot != null) {
					wsks_key.setProperty("com.ibm.ssl.tokenSlot", tokenSlot);
					wsks_key.setProperty("com.ibm.ssl.keyStoreSlot", tokenSlot);
				}

				wsks_key.setProperty("com.ibm.ssl.keyStoreProvider", "IBMPKCS11Impl");
				wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
				wsks_key.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
				wsks_key.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "true");
				wsks_key.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "false");
				wsks_key.setProperty("com.ibm.ssl.keyStoreUseForAcceleration", "true");
			} else {
				if (keyStoreName != null) {
					wsks_key.setProperty("com.ibm.ssl.keyStore", keyStoreName);
				}

				if (keyStorePassword != null) {
					wsks_key.setProperty("com.ibm.ssl.keyStorePassword", keyStorePassword);
				}

				if (keyStoreFormat != null) {
					wsks_key.setProperty("com.ibm.ssl.keyStoreType", keyStoreFormat);
					if (!keyStoreFormat.equals("JKS") && !keyStoreFormat.equals("JCEKS")
							&& !keyStoreFormat.equals("PKCS12")) {
						wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
					} else {
						wsks_key.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
					}
				}

				if (keyStoreFormat != null && keyStoreFormat.equals("JCE4758KS")) {
					wsks_key.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
				} else {
					wsks_key.setProperty("com.ibm.ssl.keyStoreReadOnly", "false");
				}

				wsks_key.setProperty("com.ibm.ssl.keyStoreProvider", "IBMJCE");
				wsks_key.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "false");
				wsks_key.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "true");
				wsks_key.setProperty("com.ibm.ssl.keyStoreUseForAcceleration", "false");
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Adding KeyStore name: " + alias + "_key");
			}

			wsks_key.setProperty("com.ibm.ssl.keyStoreName", alias + "_key");
			this.addKeyStoreIfNotDuplicate(alias + "_key", wsks_key);
		}

		if (trustStoreName != null) {
			wsks_trust = new WSKeyStore();
			wsks_trust.setProperty("com.ibm.ssl.tokenEnabled", "false");
			wsks_trust.setProperty("com.ibm.ssl.keyStoreScope",
					ManagementScopeManager.getInstance().getCellScopeName());
			wsks_trust.setProperty("com.ibm.ssl.keyStore", trustStoreName);
			if (trustStorePassword != null) {
				wsks_trust.setProperty("com.ibm.ssl.keyStorePassword", trustStorePassword);
			}

			if (trustStoreFormat != null) {
				wsks_trust.setProperty("com.ibm.ssl.keyStoreType", trustStoreFormat);
				if (!trustStoreFormat.equals("JKS") && !trustStoreFormat.equals("JCEKS")
						&& !trustStoreFormat.equals("PKCS12")) {
					wsks_trust.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
				} else {
					wsks_trust.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
				}
			}

			if (trustStoreFormat != null && trustStoreFormat.equals("JCE4758KS")) {
				wsks_trust.setProperty("com.ibm.ssl.keyStoreReadOnly", "true");
			} else {
				wsks_trust.setProperty("com.ibm.ssl.keyStoreReadOnly", "false");
			}

			wsks_trust.setProperty("com.ibm.ssl.keyStoreProvider", "IBMJCE");
			wsks_trust.setProperty("com.ibm.ssl.keyStoreInitializeAtStartup", "false");
			wsks_trust.setProperty("com.ibm.ssl.keyStoreCreateCMSStash", "true");
			wsks_trust.setProperty("com.ibm.ssl.keyStoreUseForAcceleration", "false");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Adding TrustStore name: " + alias + "_trust");
			}

			wsks_trust.setProperty("com.ibm.ssl.keyStoreName", alias + "_trust");
			this.addKeyStoreIfNotDuplicate(alias + "_trust", wsks_trust);
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Total Number of KeyStores: " + this.keyStoreMap.size());
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "loadOldWCCMKeyStore");
		}

		if (wsks_key != null && wsks_trust != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Returning key and trust.");
			}

			return new WSKeyStore[]{wsks_key, wsks_trust};
		} else if (wsks_key != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Copying key to trust.");
			}

			wsks_trust = (WSKeyStore) wsks_key.clone();
			wsks_trust.setProperty("com.ibm.ssl.keyStoreName", alias + "_trust");
			this.addKeyStoreIfNotDuplicate(alias + "_trust", wsks_trust);
			return new WSKeyStore[]{wsks_key, wsks_trust};
		} else if (wsks_trust != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Copying trust to key.");
			}

			wsks_key = (WSKeyStore) wsks_trust.clone();
			wsks_key.setProperty("com.ibm.ssl.keyStoreName", alias + "_key");
			this.addKeyStoreIfNotDuplicate(alias + "_key", wsks_key);
			return new WSKeyStore[]{wsks_key, wsks_trust};
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Not returning any KeyStores from old WCCM config.");
			}

			return null;
		}
	}

	public boolean checkIfClientKeyStoreAndTrustStoreExistsAndCreateIfNot(SSLConfig sslprops) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkIfClientKeyStoreAndTrustStoreExistsAndCreateIfNot");
		}

		boolean ksExists = false;
		boolean tsExists = false;
		String tokenEnabled = null;
		String tokenConfigFile = null;
		String fileBased = null;
		String keyStoreLocation = null;
		String password = null;
		String type = null;
		String provider = null;
		String readOnly = null;
		String scope = null;

		try {
			String name = sslprops.getProperty("com.ibm.ssl.keyStoreName");
			WSKeyStore wsks = this.getKeyStore(name);
			if (wsks == null) {
				wsks = new WSKeyStore();
				if (name != null) {
					wsks.setProperty("com.ibm.ssl.keyStoreName", name);
				}

				fileBased = sslprops.getProperty("com.ibm.ssl.keyStoreFileBased");
				if (fileBased != null) {
					wsks.setProperty("com.ibm.ssl.keyStoreFileBased", fileBased);
				}

				readOnly = sslprops.getProperty("com.ibm.ssl.keyStoreReadOnly");
				if (readOnly != null) {
					wsks.setProperty("com.ibm.ssl.keyStoreReadOnly", readOnly);
				}

				keyStoreLocation = sslprops.getProperty("com.ibm.ssl.keyStore");
				if (keyStoreLocation != null) {
					wsks.setProperty("com.ibm.ssl.keyStore", keyStoreLocation);
				}

				password = sslprops.getProperty("com.ibm.ssl.keyStorePassword");
				if (password != null) {
					wsks.setProperty("com.ibm.ssl.keyStorePassword", password);
				}

				tokenEnabled = sslprops.getProperty("com.ibm.ssl.tokenEnabled");
				if (tokenEnabled != null) {
					wsks.setProperty("com.ibm.ssl.tokenEnabled", tokenEnabled);
				}

				type = sslprops.getProperty("com.ibm.ssl.keyStoreType");
				if (type != null) {
					wsks.setProperty("com.ibm.ssl.keyStoreType", type);
					if (!type.equals("JKS") && !type.equals("JCEKS") && !type.equals("PKCS12")
							&& !type.equals("CMSKS")) {
						wsks.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
						fileBased = "false";
					} else {
						wsks.setProperty("com.ibm.ssl.keyStoreFileBased", "true");
						fileBased = "true";
					}

					if (type.equals("PKCS11") || type.equals("JCE4758KS")) {
						wsks.setProperty("com.ibm.ssl.tokenEnabled", "true");
					}

					readOnly = sslprops.getProperty("com.ibm.ssl.keyStoreReadOnly");
					if (readOnly != null) {
						wsks.setProperty("com.ibm.ssl.keyStoreReadOnly", readOnly);
					}
				}

				tokenConfigFile = sslprops.getProperty("com.ibm.ssl.tokenConfigFile");
				if (tokenConfigFile != null) {
					wsks.setProperty("com.ibm.ssl.tokenConfigFile", tokenConfigFile);
				}

				provider = sslprops.getProperty("com.ibm.ssl.keyStoreProvider");
				if (provider != null) {
					if (provider.equals("IBMPKCS11Impl")) {
						wsks.setProperty("com.ibm.ssl.tokenEnabled", "true");
					}

					wsks.setProperty("com.ibm.ssl.keyStoreProvider", provider);
				}

				scope = sslprops.getProperty("com.ibm.ssl.keyStoreScope");
				if (scope != null) {
					wsks.setProperty("com.ibm.ssl.keyStoreScope", scope);
				}

				this.keyStoreMap.put(name, wsks);
			}

			if (fileBased == null) {
				fileBased = wsks.getProperty("com.ibm.ssl.keyStoreFileBased");
			}

			if (readOnly == null) {
				readOnly = wsks.getProperty("com.ibm.ssl.keyStoreReadOnly");
			}

			if (keyStoreLocation == null) {
				keyStoreLocation = wsks.getProperty("com.ibm.ssl.keyStore");
			}

			String keyStoreFile = null;
			Certificate signer = null;
			Boolean readOnlyBoolean;
			Boolean initializeAtStartupBoolean;
			KeyStoreInfo ksInfo;
			String trustStoreReadOnly;
			String defaultAlias;
			if (fileBased != null && fileBased.equals("true") && readOnly != null && readOnly.equals("false")
					&& name != null && name.endsWith("DefaultKeyStore")) {
				try {
					URL conversionURL = new URL(keyStoreLocation);

					for (keyStoreFile = conversionURL.getFile(); keyStoreFile
							.startsWith("/"); keyStoreFile = keyStoreFile.substring(1)) {
						;
					}
				} catch (MalformedURLException var37) {
					keyStoreFile = keyStoreLocation;
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "File path for OutputStream: " + keyStoreFile);
				}

				File kFile = null;
				Boolean fileExists = Boolean.FALSE;
				if (keyStoreFile != null) {
					kFile = new File(keyStoreFile);
					FileExistsAction action = new FileExistsAction(this, kFile);
					fileExists = (Boolean) AccessController.doPrivileged(action);
				}

				if (kFile != null && fileExists) {
					ksExists = true;
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "checkIfClientKeyStoreAndTrustStoreExistsAndCreateIfNot -> (keystore exists)");
					}
				} else if (kFile != null) {
					if (password == null) {
						password = wsks.getProperty("com.ibm.ssl.keyStorePassword");
					}

					if (type == null) {
						type = wsks.getProperty("com.ibm.ssl.keyStoreType");
					}

					if (provider == null) {
						provider = wsks.getProperty("com.ibm.ssl.keyStoreProvider");
					}

					if (scope == null) {
						scope = wsks.getProperty("com.ibm.ssl.keyStoreScope");
					}

					Boolean fileBasedBoolean = Boolean.TRUE;
					readOnlyBoolean = Boolean.FALSE;
					initializeAtStartupBoolean = Boolean.TRUE;
					ksInfo = new KeyStoreInfo(name, keyStoreFile, password, provider, type, fileBasedBoolean,
							(String) null, scope, (ObjectName) null, readOnlyBoolean, initializeAtStartupBoolean,
							Boolean.FALSE, (String) null, new Integer(0), Boolean.FALSE, (List) null, (String) null);
					trustStoreReadOnly = sslprops.getProperty("com.ibm.ssl.keyStoreClientAlias");
					defaultAlias = SSLConfigManager.getInstance().getGlobalProperty("com.ibm.ssl.defaultCertReqAlias",
							"default");
					String alias = null;
					if (trustStoreReadOnly != null) {
						alias = trustStoreReadOnly;
					} else if (defaultAlias != null) {
						alias = defaultAlias;
					} else {
						alias = "default";
					}

					String sizeString = SSLConfigManager.getInstance()
							.getGlobalProperty("com.ibm.ssl.defaultCertReqKeySize", "2048");
					String subjectDN = this.expand(SSLConfigManager.getInstance()
							.getGlobalProperty("com.ibm.ssl.defaultCertReqSubjectDN", "cn=${hostname},o=IBM,c=US"));
					String daysString = SSLConfigManager.getInstance()
							.getGlobalProperty("com.ibm.ssl.defaultCertReqDays", "5475");
					int size = new Integer(sizeString);
					int days = new Integer(daysString);
					CertReqInfo certReq = new CertReqInfo(alias, size, subjectDN, days, ksInfo, (String) null);

					try {
						signer = CertificateManager.getInstance().chainedCertificateCreate(certReq, "root",
								(KeyStoreInfo) null);
					} catch (NoClassDefFoundError var35) {
						Manager.Ffdc.log(var35, this,
								"com.ibm.ws.ssl.config.KeyStoreManager.checkIfClientKeyStoreAndTrustStoreExistsAndCreateIfNot",
								"1339", new Object[]{this, new Object[]{var35}});
						String msg = TraceNLSHelper.getInstance().getFormattedMessage(
								"ssl.chained.create.error.CWPKI0043E", new Object[]{var35.toString()},
								"Error creating a chained certificate due to: " + var35);
						Tr.error(tc, msg);
						throw var35;
					}
				}
			}

			String trustStoreName = sslprops.getProperty("com.ibm.ssl.trustStoreName");
			WSKeyStore wsts = this.getKeyStore(trustStoreName);
			String trustStoreFileBased = null;
			String trustStoreLocation = null;
			readOnlyBoolean = null;
			initializeAtStartupBoolean = null;
			ksInfo = null;
			trustStoreReadOnly = null;
			tokenEnabled = null;
			tokenConfigFile = null;
			if (wsts == null) {
				wsts = new WSKeyStore();
				if (trustStoreName != null) {
					wsts.setProperty("com.ibm.ssl.keyStoreName", trustStoreName);
				}

				trustStoreFileBased = sslprops.getProperty("com.ibm.ssl.trustStoreFileBased");
				if (trustStoreFileBased != null) {
					wsts.setProperty("com.ibm.ssl.keyStoreFileBased", trustStoreFileBased);
				}

				trustStoreLocation = sslprops.getProperty("com.ibm.ssl.trustStore");
				if (trustStoreLocation != null) {
					wsts.setProperty("com.ibm.ssl.keyStore", trustStoreLocation);
				}

				String trustStorePassword = sslprops.getProperty("com.ibm.ssl.trustStorePassword");
				if (trustStorePassword != null) {
					wsts.setProperty("com.ibm.ssl.keyStorePassword", trustStorePassword);
				}

				if (tokenEnabled != null) {
					wsts.setProperty("com.ibm.ssl.tokenEnabled", tokenEnabled);
				}

				String trustStoreType = sslprops.getProperty("com.ibm.ssl.trustStoreType");
				if (trustStoreType != null) {
					if (trustStoreType.equals("PKCS11") || trustStoreType.equals("JCE4758KS")) {
						wsts.setProperty("com.ibm.ssl.tokenEnabled", "true");
					}

					if (trustStoreType.equals("JCERACFKS") || trustStoreType.equals("JCE4758KS")
							|| trustStoreType.equals("JCEHYBRIDRACFKS")) {
						wsts.setProperty("com.ibm.ssl.keyStoreFileBased", "false");
						fileBased = "false";
					}

					wsts.setProperty("com.ibm.ssl.keyStoreType", trustStoreType);
				}

				tokenConfigFile = sslprops.getProperty("com.ibm.ssl.tokenConfigFile");
				if (tokenConfigFile != null) {
					wsts.setProperty("com.ibm.ssl.tokenConfigFile", tokenConfigFile);
				}

				String trustStoreProvider = sslprops.getProperty("com.ibm.ssl.trustStoreProvider");
				if (trustStoreProvider != null) {
					wsts.setProperty("com.ibm.ssl.keyStoreProvider", trustStoreProvider);
				}

				trustStoreReadOnly = sslprops.getProperty("com.ibm.ssl.trustStoreReadOnly");
				if (trustStoreReadOnly != null) {
					wsts.setProperty("com.ibm.ssl.keyStoreReadOnly", trustStoreReadOnly);
				}

				this.keyStoreMap.put(trustStoreName, wsts);
			}

			if (trustStoreFileBased == null) {
				trustStoreFileBased = wsts.getProperty("com.ibm.ssl.keyStoreFileBased");
			}

			if (trustStoreLocation == null) {
				trustStoreLocation = wsts.getProperty("com.ibm.ssl.keyStore");
			}

			defaultAlias = null;
			if (!ksExists && trustStoreFileBased != null && trustStoreFileBased.equals("true") && trustStoreName != null
					&& trustStoreName.endsWith("DefaultTrustStore")) {
				try {
					URL conversionURL = new URL(trustStoreLocation);

					for (defaultAlias = conversionURL.getFile(); defaultAlias
							.startsWith("/"); defaultAlias = defaultAlias.substring(1)) {
						;
					}
				} catch (MalformedURLException var36) {
					defaultAlias = trustStoreLocation;
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "File path for OutputStream: " + defaultAlias);
				}

				File tFile = new File(defaultAlias);
				FileExistsAction action = new FileExistsAction(this, tFile);
				Boolean fileExists = (Boolean) AccessController.doPrivileged(action);
				if (fileExists) {
					tsExists = true;
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "checkIfClientKeyStoreAndTrustStoreExistsAndCreateIfNot -> (truststore exists)");
					}
				} else {
					java.security.KeyStore keyStore = wsts.getKeyStore(false, false);
					String signer_alias = "default_signer";
					if (keyStore != null && signer != null) {
						keyStore.setCertificateEntry(signer_alias, signer);
						wsts.store();
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Signer set in new truststore file.");
						}
					}
				}
			}
		} catch (Exception var38) {
			Manager.Ffdc.log(var38, this,
					"com.ibm.ws.ssl.config.KeyStoreManager.checkIfClientKeyStoreAndTrustStoreExistsAndCreateIfNot",
					"1476", new Object[]{this, new Object[]{var38}});
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception creating client keystore and/or truststore.", new Object[]{var38});
			}

			Tr.error(tc, "ssl.client.keystore.create.error.CWPKI0031E", new Object[]{var38.getMessage()});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "checkIfClientKeyStoreAndTrustStoreExistsAndCreateIfNot -> "
					+ (new Boolean(!ksExists && !tsExists)).toString());
		}

		return !ksExists && !tsExists;
	}

	public Certificate checkIfKeyStoreExistsAndCreateIfNot(WSKeyStore ks, SSLConfig config) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkIfKeyStoreExistsAndCreateIfNot");
		}

		String fileBased = ks.getProperty("com.ibm.ssl.keyStoreFileBased");
		String location = ks.getProperty("com.ibm.ssl.keyStore");
		String profileRoot = getConfigRoot();
		String expandedConfigRoot = null;
		if (profileRoot == null) {
			expandedConfigRoot = getInstance().expand("${CONFIG_ROOT}");
		}

		String keyStoreName = ks.getProperty("com.ibm.ssl.keyStoreName");
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Key store location: " + location);
		}

		if (keyStoreName != null
				&& (keyStoreName.endsWith("DefaultKeyStore") || keyStoreName.endsWith("RSATokenKeyStore"))
				&& fileBased != null && fileBased.equals("true")) {
			File keyStoreFile = new File(location);
			FileExistsAction action = new FileExistsAction(this, keyStoreFile);
			Boolean fileExists = (Boolean) AccessController.doPrivileged(action);
			if (fileExists) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "checkIfKeyStoreExistsAndCreateIfNot -> (exists)");
				}

				return null;
			} else {
				try {
					String name = ks.getProperty("com.ibm.ssl.keyStoreName");
					String password = ks.getProperty("com.ibm.ssl.keyStorePassword");
					String type = ks.getProperty("com.ibm.ssl.keyStoreType");
					String provider = ks.getProperty("com.ibm.ssl.keyStoreProvider");
					String scope = ks.getProperty("com.ibm.ssl.keyStoreScope");
					String stash = ks.getProperty("com.ibm.ssl.keyStoreCreateCMSStash");
					Boolean stashBoolean = Boolean.TRUE;
					if (stash != null) {
						stashBoolean = new Boolean(stash);
					}

					Boolean fileBasedBoolean = Boolean.TRUE;
					Boolean readOnlyBoolean = Boolean.FALSE;
					Boolean initializeAtStartupBoolean = Boolean.TRUE;
					KeyStoreInfo ksInfo = new KeyStoreInfo(name, location, password, provider, type, fileBasedBoolean,
							(String) null, scope, (ObjectName) null, readOnlyBoolean, initializeAtStartupBoolean,
							stashBoolean, (String) null, new Integer(0), Boolean.FALSE, (List) null, (String) null);
					if (keyStoreName.endsWith("RSATokenKeyStore")) {
						ksInfo.setUsage("RSATokenKeys");
					} else {
						ksInfo.setUsage("SSLKeys");
					}

					String clientAlias = config.getProperty("com.ibm.ssl.keyStoreClientAlias");
					String serverAlias = config.getProperty("com.ibm.ssl.keyStoreServerAlias");
					String defaultAlias = SSLConfigManager.getInstance()
							.getGlobalProperty("com.ibm.ssl.defaultCertReqAlias", "default");
					String alias = null;
					if (serverAlias != null) {
						alias = serverAlias;
					} else if (clientAlias != null) {
						alias = clientAlias;
					} else if (defaultAlias != null) {
						alias = defaultAlias;
					} else {
						alias = "default";
					}

					String sizeString = SSLConfigManager.getInstance()
							.getGlobalProperty("com.ibm.ssl.defaultCertReqKeySize", "2048");
					String subjectDN = this.expand(SSLConfigManager.getInstance()
							.getGlobalProperty("com.ibm.ssl.defaultCertReqSubjectDN", "cn=${hostname},o=IBM,c=US"));
					String daysString = SSLConfigManager.getInstance()
							.getGlobalProperty("com.ibm.ssl.defaultCertReqDays", "5475");
					int size = new Integer(sizeString);
					int days = new Integer(daysString);
					CertReqInfo certReq = new CertReqInfo(alias, size, subjectDN, days, ksInfo, (String) null);
					Certificate signer = CertificateManager.getInstance().chainedCertificateCreate(certReq, "root",
							(KeyStoreInfo) null);
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "checkIfKeyStoreExistsAndCreateIfNot");
					}

					return signer;
				} catch (Exception var33) {
					if (var33 instanceof SSLException) {
						throw (SSLException) var33;
					} else {
						throw new SSLException(var33.getMessage(), var33);
					}
				}
			}
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "checkIfKeyStoreExistsAndCreateIfNot (not filebased or in config root)");
			}

			return null;
		}
	}

	public void checkIfTrustStoreExistsAndCreateIfNot(WSKeyStore ts, SSLConfig config, Certificate signer)
			throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkIfTrustStoreExistsAndCreateIfNot");
		}

		String fileBased = ts.getProperty("com.ibm.ssl.keyStoreFileBased");
		String location = ts.getProperty("com.ibm.ssl.keyStore");
		String profileRoot = getConfigRoot();
		String expandedConfigRoot = null;
		if (profileRoot == null) {
			expandedConfigRoot = getInstance().expand("${CONFIG_ROOT}");
		}

		String trustStoreName = ts.getProperty("com.ibm.ssl.keyStoreName");
		if (trustStoreName != null
				&& (trustStoreName.endsWith("DefaultTrustStore") || trustStoreName.endsWith("RSATokenTrustStore"))
				&& fileBased != null && fileBased.equals("true")) {
			File trustStoreFile = new File(location);
			FileExistsAction action = new FileExistsAction(this, trustStoreFile);
			Boolean fileExists = (Boolean) AccessController.doPrivileged(action);
			if (fileExists) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "checkIfTrustStoreExistsAndCreateIfNot -> (exists)");
				}

				return;
			}

			try {
				String name = ts.getProperty("com.ibm.ssl.keyStoreName");
				String password = ts.getProperty("com.ibm.ssl.keyStorePassword");
				String type = ts.getProperty("com.ibm.ssl.keyStoreType");
				String provider = ts.getProperty("com.ibm.ssl.keyStoreProvider");
				String scope = ts.getProperty("com.ibm.ssl.keyStoreScope");
				java.security.KeyStore keyStore = this.getKeyStore(name, type, provider, location, password, scope,
						true, config);
				String signer_alias = "default_signer";
				if (keyStore != null && signer != null) {
					keyStore.setCertificateEntry(signer_alias, signer);
					FileOutputStream fos = new FileOutputStream(location);
					keyStore.store(fos, password.toCharArray());
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "checkIfTrustStoreExistsAndCreateIfNot (signer set)");
					}

					return;
				}
			} catch (Exception var20) {
				if (var20 instanceof SSLException) {
					throw (SSLException) var20;
				}

				throw new SSLException(var20.getMessage(), var20);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "checkIfTrustStoreExistsAndCreateIfNot (not filebased or in config root)");
		}

	}

	public void addKeyStoreIfNotDuplicate(String keyStoreName, WSKeyStore ks) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "addKeyStoreIfNotDuplicate", keyStoreName);
		}

		if (this.keyStoreMap.size() > 0) {
			Iterator keyStoreIterator = this.keyStoreMap.entrySet().iterator();

			while (keyStoreIterator.hasNext()) {
				Entry current = (Entry) keyStoreIterator.next();
				WSKeyStore mapks = (WSKeyStore) current.getValue();
				if (mapks.equals(ks)) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Found a matching KeyStore, adding reference to existing.");
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Adding keystore lookup as: " + keyStoreName);
					}

					this.keyStoreMap.put(keyStoreName, mapks);
					String accelerator = mapks.getProperty("com.ibm.ssl.keyStoreUseForAcceleration");
					if (accelerator != null && accelerator.equals("true")) {
						this.acceleratorMap.put(keyStoreName, mapks);
					}

					return;
				}
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Adding KeyStore to the Map: " + keyStoreName + ", values: " + ks);
		}

		if (SSLConfigManager.getInstance().validationEnabled()) {
			ks.provideExpirationWarnings(new Integer("60"), keyStoreName);
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Adding keystore lookup as: " + keyStoreName);
		}

		this.keyStoreMap.put(keyStoreName, ks);
		String accelerator = ks.getProperty("com.ibm.ssl.keyStoreUseForAcceleration");
		if (accelerator != null && accelerator.equals("true")) {
			this.acceleratorMap.put(keyStoreName, ks);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addKeyStoreIfNotDuplicate");
		}

	}

	public void exchangeSigners(String configRootKeyStore, KeyStore keystore, String configRootTrustStore,
			KeyStore truststore) {
		this.exchangeSigners(configRootKeyStore, keystore, false, configRootTrustStore, truststore, false);
	}

	public void exchangeSigners(String configRootKeyStore, KeyStore keystore, boolean cellKeyStore,
			String configRootTrustStore, KeyStore truststore, boolean cellTrustStore) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "exchangeSigners", new Object[]{keystore.getLocation(), truststore.getLocation()});
		}

		FileOutputStream fos = null;

		try {
			String name1 = keystore.getName();
			String location1 = this.fixupConfigRootForSignerExchange(configRootKeyStore, keystore.getLocation());
			if (cellKeyStore && location1.contains("${USER_INSTALL_ROOT}")) {
				location1 = this.expand(location1);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "expanded key store location to " + location1);
				}
			}

			String password1 = keystore.getPassword();
			String type1 = keystore.getType();
			String provider1 = keystore.getProvider();
			String scope1 = keystore.getManagementScope().getScopeName();
			java.security.KeyStore keyStore1 = this.getKeyStore(name1, type1, provider1, location1, password1, scope1,
					true, (SSLConfig) null);
			String name2 = truststore.getName();
			String location2 = this.fixupConfigRootForSignerExchange(configRootTrustStore, truststore.getLocation());
			if (cellTrustStore && location2.contains("${USER_INSTALL_ROOT}")) {
				location2 = this.expand(location2);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "expanded trust store location to " + location2);
				}
			}

			String password2 = truststore.getPassword();
			String type2 = truststore.getType();
			String provider2 = truststore.getProvider();
			String scope2 = truststore.getManagementScope().getScopeName();
			boolean keystore2modified = false;
			java.security.KeyStore keyStore2 = this.getKeyStore(name2, type2, provider2, location2, password2, scope2,
					true, (SSLConfig) null);
			if (keyStore1 != null && keyStore2 != null) {
				Enumeration alias1Enumeration = keyStore1.aliases();

				label256 : while (true) {
					while (true) {
						String alias;
						do {
							if (!alias1Enumeration.hasMoreElements()) {
								if (keystore2modified) {
									if (KeyStoreTypeHelper.isCMSKeyStore(type2)) {
										Class cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
										Method theMethod1 = cl1.getMethod("storeCMSKeyStore",
												java.security.KeyStore.class, String.class, String.class, String.class,
												String.class);
										theMethod1.invoke(cl1.newInstance(), keyStore2, location2, password2, type2,
												"true");
									} else {
										fos = new FileOutputStream(location2);
										keyStore2.store(fos, password2.toCharArray());
									}

									this.clearJavaKeyStoresFromKeyStoreMap();
								}
								break label256;
							}

							alias = (String) alias1Enumeration.nextElement();
						} while (!keyStore1.isKeyEntry(alias));

						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Key alias: " + alias);
						}

						Certificate[] signerChain = (Certificate[]) keyStore1.getCertificateChain(alias);
						X509Certificate signer = (X509Certificate) signerChain[signerChain.length - 1];
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Certificate DN: " + signer.getIssuerDN().getName());
						}

						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Certificate S/N: " + signer.getSerialNumber());
						}

						boolean exists = this.checkIfSignerAlreadyExistsInTrustStore(signer, keyStore2);
						if (!exists && !keyStore2.containsAlias(alias)) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Adding alias \"" + alias + "\" from keystore \"" + location1
										+ "\" to keystore \"" + location2 + "\".");
							}

							keyStore2.setCertificateEntry(alias, signer);
							keystore2modified = true;
						} else if (!exists) {
							int num = 1;
							String newAlias = null;

							do {
								newAlias = alias + "_" + num++;
							} while (keyStore2.containsAlias(newAlias));

							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Adding alias \"" + newAlias + "\" from keystore \"" + location1
										+ "\" to keystore \"" + location2 + "\".");
							}

							if (!keyStore2.containsAlias(newAlias)) {
								keyStore2.setCertificateEntry(newAlias, signer);
								keystore2modified = true;
							}
						}
					}
				}
			}
		} catch (Exception var38) {
			Manager.Ffdc.log(var38, this, "com.ibm.ws.ssl.config.KeyStoreManager.exchangeSigners", "1802",
					new Object[]{this, new Object[]{var38}});
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception exchanging signers.", new Object[]{var38});
			}

			Tr.error(tc, "ssl.signer.exchange.error.CWPKI0030E", new Object[]{var38.getMessage()});
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (Exception var37) {
					;
				}
			}

		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "exchangeSigners");
		}

	}

	public boolean checkIfSignerAlreadyExistsInTrustStore(X509Certificate signer, java.security.KeyStore trustStore) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkIfSignerAlreadyExistsInTrustStore");
		}

		try {
			String signerMD5Digest = this.generateDigest("MD5", signer);
			if (signerMD5Digest == null) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "checkIfSignerAlreadyExistsInTrustStore -> false (could not generate digest)");
				}

				return false;
			}

			Enumeration aliases = trustStore.aliases();

			while (aliases.hasMoreElements()) {
				String alias = (String) aliases.nextElement();
				if (trustStore.containsAlias(alias)) {
					X509Certificate cert = (X509Certificate) trustStore.getCertificate(alias);
					String certMD5Digest = this.generateDigest("MD5", cert);
					if (signerMD5Digest.equals(certMD5Digest)) {
						if (tc.isEntryEnabled()) {
							Tr.entry(tc, "checkIfSignerAlreadyExistsInTrustStore -> true (digest matches)");
						}

						return true;
					}
				}
			}
		} catch (Exception var8) {
			Manager.Ffdc.log(var8, this, "com.ibm.ws.ssl.config.KeyStoreManager.checkIfSignerAlreadyExistsInTrustStore",
					"1863", new Object[]{this, new Object[]{var8}});
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception checking if signer already exists.", new Object[]{var8});
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "checkIfSignerAlreadyExistsInTrustStore -> false (no digest matches)");
		}

		return false;
	}

	private String fixupConfigRootForSignerExchange(String configRoot, String location) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "fixupConfigRoot", new Object[]{configRoot, location});
		}

		String newPath = location;
		int index = location.indexOf("/cells/");
		if (index != -1) {
			String lastPart = location.substring(index);
			newPath = configRoot + lastPart;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "fixupConfigRoot -> " + newPath);
		}

		return newPath;
	}

	public WSKeyStore getKeyStore(String keyStoreName, String keyStoreScopeName, Object sessionObject) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getKeyStore", new Object[]{keyStoreName, sessionObject});
		}

		WSKeyStore wsks = null;

		try {
			Class cl1 = Class.forName("com.ibm.ws.ssl.utils.ProfileKeystoreUtils");
			if (cl1 != null) {
				Method theMethod1 = cl1.getMethod("getWSKeyStoreFromConfig", String.class, String.class, Object.class);
				wsks = (WSKeyStore) theMethod1.invoke((Object) null, keyStoreName, keyStoreScopeName, sessionObject);
			}

			if (wsks != null && tc.isDebugEnabled()) {
				Tr.debug(tc, "WSKeyStore was successfully created.");
			}
		} catch (Exception var7) {
			Manager.Ffdc.log(var7, this, "com.ibm.ws.ssl.config.KeyStoreManager.getKeyStore", "1917",
					new Object[]{this});
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Received the following exception while creating a keystore from the configuration.",
						new Object[]{var7});
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getKeyStore");
		}

		return wsks;
	}

	public WSKeyStore getKeyStore(String keyStoreName) {
		WSKeyStore ks = (WSKeyStore) this.keyStoreMap.get(keyStoreName);
		if (ks != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Returning a keyStore for name: " + keyStoreName);
			}
		} else if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Cannot find a keyStore for name: " + keyStoreName);
		}

		return ks;
	}

	public String[] getKeyStoreAliases() {
		return (String[]) ((String[]) this.keyStoreMap.keySet().toArray(new String[0]));
	}

	public String[] getAcceleratorAliases() {
		return (String[]) ((String[]) this.acceleratorMap.keySet().toArray(new String[0]));
	}

	public static String getKeyStoreType(KeyFileFormatKind type) {
		String keyFileFormat = null;
		if (type != null) {
			switch (type.getValue()) {
				case 2 :
					keyFileFormat = "JCEKS";
					break;
				default :
					keyFileFormat = type.getName();
			}
		}

		return keyFileFormat;
	}

	public java.security.KeyStore getKeyStore(String name, String type, String provider, String fileName,
			String password, String scope, boolean create, SSLConfig sslConfig) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getKeyStore",
					new Object[]{name, type, provider, fileName, scope, create, SSLConfigManager.mask(password)});
		}

		if (name != null && !create) {
			WSKeyStore keystore = (WSKeyStore) this.keyStoreMap.get(name);
			if (keystore != null) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getKeyStore (from WSKeyStore)");
				}

				return keystore.getKeyStore(false, false);
			}
		}

		java.security.KeyStore keyStore = null;
		FileOutputStream fos = null;
		InputStream inputStream = null;
		boolean not_finished = true;
		int retry_count = 0;
		boolean fileBased = true;
		ArrayList keyStoreTypes = new ArrayList();

		while (not_finished) {
			if (!type.equals("JCERACFKS") && !type.equals("JCEHYBRIDRACFKS")) {
				fileBased = true;
			} else {
				fileBased = false;
			}

			if (!KeyStoreTypeHelper.isCMSKeyStore(type)) {
				keyStore = java.security.KeyStore.getInstance(type);
			}

			char[] passphrase = null;
			if (password != null) {
				passphrase = password.toCharArray();
			}

			try {
				if (type != null && type.equals("PKCS11")) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Creating PKCS11 keystore.");
					}

					WSPKCSInKeyStore pKS = pkcsStoreList.insert(type, fileName, password, false, provider, false);
					if (pKS != null) {
						keyStore = pKS.getKS();
						not_finished = false;
					}
				} else if (null == fileName) {
					if (KeyStoreTypeHelper.isCMSKeyStore(type)) {
						Class cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
						Method theMethod1 = cl1.getMethod("loadCMSKeyStore", File.class, String.class, String.class,
								String.class, String.class, String.class);
						keyStore = (java.security.KeyStore) theMethod1.invoke(cl1.newInstance(), null, fileName,
								password, type, provider, "true");
						not_finished = false;
					} else {
						keyStore.load((InputStream) null, passphrase);
						not_finished = false;
					}
				} else {
					File f = new File(fileName);
					FileExistsAction action = new FileExistsAction(this, f);
					Boolean fileExists = (Boolean) AccessController.doPrivileged(action);
					Class cl1;
					Method theMethod1;
					if (!fileExists && fileBased) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "getKeyStore created new KeyStore: " + fileName);
						}

						if (KeyStoreTypeHelper.isCMSKeyStore(type)) {
							cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
							theMethod1 = cl1.getMethod("loadCMSKeyStore", File.class, String.class, String.class,
									String.class, String.class, String.class);
							keyStore = (java.security.KeyStore) theMethod1.invoke(cl1.newInstance(), null, fileName,
									password, type, provider, "true");
							not_finished = false;
						} else {
							keyStore.load((InputStream) null, passphrase);
							not_finished = false;
						}
					} else {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "getKeyStore created a new inputStream: " + fileName);
						}

						if (KeyStoreTypeHelper.isCMSKeyStore(type)) {
							cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
							theMethod1 = cl1.getMethod("loadCMSKeyStore", File.class, String.class, String.class,
									String.class, String.class, String.class);
							keyStore = (java.security.KeyStore) theMethod1.invoke(cl1.newInstance(), f, fileName,
									password, type, provider, "true");
							not_finished = false;
						} else {
							inputStream = this.getInputStream(fileName, create);
							keyStore.load(inputStream, passphrase);
							not_finished = false;
						}
					}
				}
			} catch (IOException var25) {
				if (!var25.getMessage().equalsIgnoreCase("Invalid keystore format")
						&& var25.getMessage().indexOf("DerInputStream.getLength()") == -1) {
					throw var25;
				}

				if (retry_count == 0) {
					String alias = "unknown";
					if (sslConfig != null) {
						alias = sslConfig.getProperty("com.ibm.ssl.alias");
					}

					Tr.warning(tc, "ssl.keystore.type.invalid.CWPKI0018W", new Object[]{type, alias});
					keyStoreTypes = new ArrayList(java.security.Security.getAlgorithms("KeyStore"));
				}

				if (retry_count >= keyStoreTypes.size()) {
					throw var25;
				}

				type = (String) keyStoreTypes.get(retry_count++);
				if (type.equals("PKCS11") || type.equals("IBMCMSKS")) {
					type = (String) keyStoreTypes.get(retry_count++);
				}
			} finally {
				if (fos != null) {
					((FileOutputStream) fos).close();
				}

				if (inputStream != null) {
					inputStream.close();
				}

			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getKeyStore (from SSLConfig properties)");
		}

		return keyStore;
	}

	public InputStream getInputStream(String fileName, boolean create) throws MalformedURLException, IOException {
		try {
			GetKeyStoreInputStreamAction action = new GetKeyStoreInputStreamAction(this, fileName, create);
			return (InputStream) AccessController.doPrivileged(action);
		} catch (PrivilegedActionException var5) {
			Exception ex = var5.getException();
			Manager.Ffdc.log(var5, this, "com.ibm.ws.ssl.provider.AbstractJSSEProvider", "2173",
					new Object[]{this, new Object[]{ex}});
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception opening keystore.", new Object[]{ex});
			}

			if (ex instanceof MalformedURLException) {
				throw (MalformedURLException) ex;
			} else if (ex instanceof IOException) {
				throw (IOException) ex;
			} else {
				throw new IOException(ex.getMessage());
			}
		}
	}

	public OutputStream getOutputStream(String fileName) throws MalformedURLException, IOException {
		try {
			GetKeyStoreOutputStreamAction action = new GetKeyStoreOutputStreamAction(this, fileName);
			return (OutputStream) AccessController.doPrivileged(action);
		} catch (PrivilegedActionException var4) {
			Exception ex = var4.getException();
			Manager.Ffdc.log(var4, this, "com.ibm.ws.ssl.config.KeyStoreManager.getOutputStream", "2247",
					new Object[]{this, new Object[]{ex}});
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception opening keystore.", new Object[]{ex});
			}

			if (ex instanceof MalformedURLException) {
				throw (MalformedURLException) ex;
			} else if (ex instanceof IOException) {
				throw (IOException) ex;
			} else {
				throw new IOException(ex.getMessage());
			}
		}
	}

	public String generateDigest(String algorithmName, X509Certificate cert) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "generateDigest", new Object[]{algorithmName});
		}

		try {
			if (cert != null) {
				DerOutputStream dos = new DerOutputStream();
				dos.write(cert.getEncoded());
				MessageDigest md = MessageDigest.getInstance(algorithmName);
				md.update(dos.toByteArray());
				byte[] ba = md.digest();
				String hex = (new HexDumpEncoder()).encode(ba);
				hex = hex.replaceAll("\\s", ":");
				String[] hexDigits = hex.split(":");
				if (hexDigits != null) {
					StringBuffer sb = new StringBuffer();

					for (int i = 0; i < hexDigits.length; ++i) {
						if (hexDigits[i] != null && hexDigits[i].length() == 2) {
							sb.append(hexDigits[i]);
							sb.append(":");
						}
					}

					sb.deleteCharAt(sb.length() - 1);
					return sb.toString().toUpperCase();
				}
			}
		} catch (NoClassDefFoundError var10) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "generateDigest", new Object[]{var10});
			}
		} catch (Exception var11) {
			Manager.Ffdc.log(var11, this, "com.ibm.ws.ssl.config.KeyStoreManager.generateDigest", "2394",
					new Object[]{this});
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "generateDigest", new Object[]{var11});
			}
		}

		return null;
	}

	protected void clearKeyStoreMap() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "clearKeyStoreMap");
		}

		this.keyStoreMap.clear();
		this.acceleratorMap.clear();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "clearKeyStoreMap");
		}

	}

	public void clearKSMap() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "clearKSMap");
		}

		this.keyStoreMap.clear();
		this.acceleratorMap.clear();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "clearKSMap");
		}

	}

	protected void clearKeyStoreFromMap(String keyStoreName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "clearKeyStoreFromMap", new Object[]{keyStoreName});
		}

		this.keyStoreMap.remove(keyStoreName);
		this.acceleratorMap.remove(keyStoreName);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "clearKeyStoreFromMap");
		}

	}

	public void clearJavaKeyStoresFromKeyStoreMap() {
		HashMap var1 = this.keyStoreMap;
		synchronized (this.keyStoreMap) {
			Iterator keyStoreMapIterator = this.keyStoreMap.entrySet().iterator();

			while (keyStoreMapIterator.hasNext()) {
				Entry entry = (Entry) keyStoreMapIterator.next();
				WSKeyStore ws = (WSKeyStore) entry.getValue();
				if (ws != null) {
					ws.clearJavaKeyStore();
				}
			}

		}
	}

	public String expand(String input) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "expand");
		}

		String tempInput = input;
		String output = null;
		String expand = null;
		output = (String) expandMap.get(input);
		if (output != null && !output.equals("")) {
			output = output.replace('\\', '/');
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "expand -> " + output);
			}

			return output;
		} else {
			try {
				if (SSLConfigManager.getInstance().isServerProcess()) {
					if (input.indexOf("${CONFIG_ROOT}") != -1) {
						expand = getConfigRoot();
						if (expand != null) {
							expand = expand.replace('\\', '/');
							output = input.replaceAll("\\$\\{CONFIG_ROOT\\}", expand);
						}

						if (expand == null) {
							expand = getUserInstallRoot();
							if (expand != null) {
								expand = expand + File.separator + "config";
								expand = expand.replace('\\', '/');
								output = input.replaceAll("\\$\\{CONFIG_ROOT\\}", expand);
							}
						}
					} else if (input.indexOf("${WORKSPACE_ROOT}") != -1) {
						expand = (getUserInstallRoot() != null
								? getUserInstallRoot()
								: System.getProperty("websphere.workspace.root")) + File.separator + "wstemp";
						if (expand != null) {
							expand = expand.replace('\\', '/');
							output = input.replaceAll("\\$\\{WORKSPACE_ROOT\\}", expand);
						}
					} else {
						Class SSLComponentImplClass = Class.forName("com.ibm.ws.ssl.core.SSLComponentImpl");
						Method getStaticExpandMethod = SSLComponentImplClass.getMethod("expand", String.class);
						output = (String) getStaticExpandMethod.invoke((Object) null, tempInput);
					}

					tempInput = output;
				}

				int index = tempInput.indexOf("${user.root}");
				String lastPart;
				String userRoot;
				String firstPart;
				if (index != -1) {
					firstPart = tempInput.substring(0, index);
					lastPart = tempInput.substring(index + "${user.root}".length());
					userRoot = SSLConfigManager.getInstance().getGlobalProperty("user.root");
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "User install root: " + userRoot);
					}

					if (userRoot != null) {
						if (firstPart != null && !firstPart.equals("")) {
							output = firstPart + userRoot + lastPart;
						} else {
							output = userRoot + lastPart;
						}

						tempInput = output;
					}
				}

				index = tempInput.indexOf("${USER_INSTALL_ROOT}");
				if (index != -1) {
					firstPart = tempInput.substring(0, index);
					lastPart = tempInput.substring(index + "${USER_INSTALL_ROOT}".length());
					userRoot = SSLConfigManager.getInstance().getGlobalProperty("user.root");
					if (userRoot == null) {
						userRoot = SSLConfigManager.getInstance().getGlobalProperty("user.install.root");
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "User install root: " + userRoot);
					}

					if (userRoot != null) {
						if (firstPart != null && !firstPart.equals("")) {
							output = firstPart + userRoot + lastPart;
						} else {
							output = userRoot + lastPart;
						}

						tempInput = output;
					}
				}

				tempInput = output = this.expandHostName(tempInput);
				index = tempInput.indexOf("${CONFIG_ROOT}");
				if (index != -1) {
					firstPart = tempInput.substring(0, index);
					lastPart = tempInput.substring(index + "${CONFIG_ROOT}".length());
					userRoot = SSLConfigManager.getInstance().getGlobalProperty("was.repository.root");
					if (userRoot == null) {
						userRoot = getUserInstallRoot();
						if (userRoot != null) {
							userRoot = userRoot + File.separator + "config";
						}
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "User install root: " + userRoot);
					}

					if (userRoot != null) {
						if (firstPart != null && !firstPart.equals("")) {
							output = firstPart + userRoot + lastPart;
						} else {
							output = userRoot + lastPart;
						}

						tempInput = output;
					}
				}

				index = tempInput.indexOf("${WORKSPACE_ROOT}");
				if (index != -1) {
					firstPart = tempInput.substring(0, index);
					lastPart = tempInput.substring(index + "${WORKSPACE_ROOT}".length());
					userRoot = null;
					if (SSLConfigManager.getInstance().getGlobalProperty("websphere.workspace.root") != null) {
						userRoot = SSLConfigManager.getInstance().getGlobalProperty("websphere.workspace.root");
					} else if (userRoot == null
							&& SSLConfigManager.getInstance().getGlobalProperty("user.root") != null) {
						userRoot = SSLConfigManager.getInstance().getGlobalProperty("user.root") + File.separator
								+ "wstemp";
					} else if (userRoot == null) {
						userRoot = getUserInstallRoot() + File.separator + "wstemp";
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "${WORKSPACE_ROOT} = " + userRoot);
					}

					if (userRoot != null) {
						if (firstPart != null && !firstPart.equals("")) {
							output = firstPart + userRoot + lastPart;
						} else {
							output = userRoot + lastPart;
						}
					}
				}
			} catch (Exception var9) {
				Manager.Ffdc.log(var9, this, "com.ibm.ws.ssl.config.KeyStoreManager.expand", "2636",
						new Object[]{this});
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Expand exception: ", new Object[]{var9});
				}
			}

			if (output != null) {
				output = output.replace('\\', '/');
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "expand -> " + output);
				}

				if (expandMap.size() > 50) {
					expandMap.clear();
					getHostName();
				}

				expandMap.put(input, output);
				return output;
			} else {
				input = input.replace('\\', '/');
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "expand -> (not expanded)");
				}

				return input;
			}
		}
	}

	String expandHostName(String input) {
		String output = input;
		int index = input.indexOf("${hostname}");
		if (index != -1) {
			String firstPart = input.substring(0, index);
			String lastPart = input.substring(index + "${hostname}".length());
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Hostname: " + host);
			}

			if (host != null) {
				output = firstPart + host + lastPart;
			}
		}

		return output;
	}

	public static String getHostName() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getHostName");
		}

		try {
			if (host == null) {
				host = InetAddress.getLocalHost().getCanonicalHostName();
				if (host != null) {
					expandMap.put("cn=${hostname},o=IBM,c=US", "cn=" + host + ",o=IBM,c=US");
					expandMap.put("${hostname}", host);
				}
			}
		} catch (UnknownHostException var1) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception getting canonical hostname.", new Object[]{var1});
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getHostName -> " + host);
		}

		return host;
	}

	public Boolean createPluginKeyStore(String hostname, String webServerDirectoryURI) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createPluginKeyStore", new Object[]{hostname, webServerDirectoryURI});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createPluginKeyStore");
		}

		return Boolean.TRUE;
	}

	public static String expandHostNameVariable(String subjectDN, String nodeHostName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "expandHostNameVariable", new Object[]{subjectDN, nodeHostName});
		}

		String expandedSubjectDN = subjectDN;
		int index1 = subjectDN.indexOf("${hostname}");
		if (index1 != -1) {
			String firstPart = subjectDN.substring(0, index1);
			String lastPart = subjectDN.substring(index1 + "${hostname}".length());
			if (firstPart != null && !firstPart.equals("") && lastPart != null && !lastPart.equals("")) {
				expandedSubjectDN = firstPart + nodeHostName + lastPart;
			} else if (firstPart != null && !firstPart.equals("")) {
				expandedSubjectDN = firstPart + nodeHostName;
			} else if (lastPart != null && !lastPart.equals("")) {
				expandedSubjectDN = nodeHostName + lastPart;
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "expandHostNameVariable -> " + expandedSubjectDN);
		}

		return expandedSubjectDN;
	}

	private static String fixupLocationWithRepositoryRoot(String repositoryRoot, String location) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "fixupLocationWithRepositoryRoot", new Object[]{repositoryRoot, location});
		}

		int index = location.indexOf("/cells/");
		String newPath = location;
		if (index != -1) {
			String lastPart = location.substring(index);
			newPath = repositoryRoot + lastPart;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "fixupLocationWithRepositoryRoot -> " + newPath);
		}

		return newPath;
	}

	public boolean isHWKeyStore(String keyStoreName) {
		WSKeyStore wsks = (WSKeyStore) this.keyStoreMap.get(keyStoreName);
		return this.isHWKeyStore(wsks);
	}

	public boolean isHWKeyStore(WSKeyStore wsks) {
		String isToken = "false";
		if (wsks != null) {
			isToken = wsks.getProperty("com.ibm.ssl.tokenEnabled");
		}

		return "true".equalsIgnoreCase(isToken);
	}

	public Provider getHWCryptoProviderInstance(String keyStoreName) {
		WSKeyStore wsks = (WSKeyStore) this.keyStoreMap.get(keyStoreName);
		return this.getHWCryptoProviderInstance(wsks);
	}

	public Provider getHWCryptoProviderInstance(WSKeyStore wsks) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getHWCryptoProviderInstance");
		}

		WSPKCSInKeyStore pKS = null;
		Provider p = null;
		boolean pureAcceleration = false;
		if (wsks != null) {
			String keyStoreFile = wsks.getProperty("com.ibm.ssl.keyStore");
			String keyStorePassword = wsks.getProperty("com.ibm.ssl.keyStorePassword");
			String keyStoreType = wsks.getProperty("com.ibm.ssl.keyStoreType");
			String keyStoreProvider = wsks.getProperty("com.ibm.ssl.keyStoreProvider");
			String useForAcceleration = wsks.getProperty("com.ibm.ssl.keyStoreUseForAcceleration");

			try {
				if (useForAcceleration != null && useForAcceleration.equals("true")) {
					pureAcceleration = true;
				}

				pKS = pkcsStoreList.insert(keyStoreType, keyStoreFile, keyStorePassword, true, keyStoreProvider,
						pureAcceleration);
			} catch (Exception var12) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Cannot get the HW crypto initialization status" + new Object[]{var12});
				}

				Manager.Ffdc.log(var12, this, "com.ibm.ws.ssl.config.KeyStoreManager.getHWCryptoProviderInstance",
						"2793", new Object[]{this});
				Tr.error(tc, "Cannot get the HW crypto initialization status", new Object[]{var12.getMessage()});
			}

			if (pKS != null) {
				try {
					p = pKS.getHWCryptoProviderInstance(keyStoreFile);
				} catch (Exception var11) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Cannot get the HW crypto provider instance" + new Object[]{var11});
					}

					Manager.Ffdc.log(var11, this, "com.ibm.ws.ssl.config.KeyStoreManager.getHWCryptoProviderInstance",
							"2805", new Object[]{this});
					Tr.error(tc, "Cannot get the HW crypto provider instance", new Object[]{var11.getMessage()});
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getHWCryptoProviderInstance");
		}

		return p;
	}

	public void returnHWCryptoProviderInstance(String keyStoreName, Provider hwProvider) {
		WSKeyStore wsks = (WSKeyStore) this.keyStoreMap.get(keyStoreName);
		this.returnHWCryptoProviderInstance(wsks, hwProvider);
	}

	public void returnHWCryptoProviderInstance(WSKeyStore wsks, Provider hwProvider) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "returnHWCryptoProviderInstance");
		}

		WSPKCSInKeyStore pKS = null;
		if (wsks != null) {
			String keyStoreFile = wsks.getProperty("com.ibm.ssl.keyStore");

			try {
				pKS = pkcsStoreList.getListElement(keyStoreFile);
			} catch (Exception var7) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Cannot get the HW crypto keystore list element" + new Object[]{keyStoreFile, var7});
				}
			}

			if (pKS != null) {
				try {
					pKS.returnHWCryptoProviderInstance(hwProvider);
				} catch (Exception var6) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Cannot return provider instance" + new Object[]{var6});
					}
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "returnHWCryptoProviderInstance");
		}

	}

	public static SecurityConfigObject getDefaultKeyStore(String defaultKeyStoreSuffix, String managementScope) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDefaultKeyStore");
		}

		if (managementScope == null) {
			managementScope = ManagementScopeManager.getInstance().getNodeScopeName();
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Selected default scope: " + managementScope);
		}

		if (managementScope.equals("client") && defaultKeyStoreSuffix.endsWith("RootStore")) {
			return null;
		} else {
			String keyStoreName = getDefaultKeyStoreName(defaultKeyStoreSuffix);
			SecurityConfigObject keyStore = null;

			try {
				SecurityConfigManager scm = SecurityObjectLocator.getSecurityConfigManager();
				if (scm == null) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "SecurityConfigManager is null.");
					}

					return null;
				}

				SecurityConfigObjectList keyStores = scm.getObjectList("security::keyStores");
				if (keyStores != null) {
					for (int i = 0; i < keyStores.size(); ++i) {
						keyStore = keyStores.get(i);
						String name = keyStore.getString("name");
						SecurityConfigObject myScope = keyStore.getObject("managementScope");
						String scope = myScope.getString("scopeName");
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Checking name and scope: " + name + ":" + scope);
						}

						if (keyStoreName != null && name.equals(keyStoreName) && scope != null
								&& scope.equals(managementScope)) {
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "getDefaultKeyStore", new Object[]{name});
							}

							return keyStore;
						}

						keyStore = null;
					}
				}
			} catch (Exception var10) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Unable to get the DefaultKeyStore " + keyStoreName, new Object[]{var10});
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getDefaultKeyStore", new Object[]{keyStore});
			}

			return keyStore;
		}
	}

	public static String getDefaultKeyStoreName(String defaultKeyStoreSuffix) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDefaultKeyStoreName");
		}

		String processType = ManagementScopeManager.getInstance().getProcessType();
		String keyStoreName = null;
		if (processType.equals("client")) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getDefaultKeyStoreName", (Object) null);
			}

			return null;
		} else {
			if (!processType.equals("UnManagedProcess") && !processType.equals("AdminAgent")
					&& !processType.equals("JobManager")) {
				if (!defaultKeyStoreSuffix.equalsIgnoreCase("DefaultKeyStore")
						&& !defaultKeyStoreSuffix.equalsIgnoreCase("DefaultTrustStore")
						&& !defaultKeyStoreSuffix.equalsIgnoreCase("RSATokenKeyStore")
						&& !defaultKeyStoreSuffix.equalsIgnoreCase("RSATokenTrustStore")) {
					keyStoreName = "Dmgr" + defaultKeyStoreSuffix;
				} else {
					keyStoreName = "Cell" + defaultKeyStoreSuffix;
				}
			} else {
				keyStoreName = "Node" + defaultKeyStoreSuffix;
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getDefaultKeyStoreName", keyStoreName);
			}

			return keyStoreName;
		}
	}

	public static SecurityConfigObject getKeyStore(String keyStoreName, String managementScope) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getKeyStore");
		}

		String keyStore;
		if (managementScope == null) {
			keyStore = ManagementScopeManager.getInstance().getProcessType();
			if (keyStore.equals("DeploymentManager")) {
				managementScope = ManagementScopeManager.getInstance().getCellScopeName();
			} else {
				managementScope = ManagementScopeManager.getInstance().getNodeScopeName();
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Selected default scope: " + managementScope);
		}

		keyStore = null;

		try {
			SecurityConfig secConfig = SecurityObjectLocator.getSecurityConfig();
			SecurityConfigObjectList keyStores = secConfig.getSCO().getObjectList("keyStores");
			if (keyStores != null) {
				for (int i = 0; i < keyStores.size(); ++i) {
					SecurityConfigObject keyStore = keyStores.get(i);
					String name = keyStore.getString("name");
					SecurityConfigObject myScope = keyStore.getObject("managementScope");
					String scope = myScope.getString("scopeName");
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Checking name and scope: " + name + ":" + scope);
					}

					if (keyStoreName != null && name.equals(keyStoreName) && scope != null
							&& scope.equals(managementScope)) {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "getDefaultKeyStore", new Object[]{name});
						}

						return keyStore;
					}

					keyStore = null;
				}
			}
		} catch (Exception var9) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Unable to get key store " + keyStoreName, new Object[]{var9});
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getKeyStore", new Object[]{keyStore});
		}

		return keyStore;
	}

	public static String getUserInstallRoot() {
		return stripLastSlash(SecurityObjectLocator.getAdminData().getUserInstallRootPath());
	}

	public static String getConfigRoot() {
		return stripLastSlash(SecurityObjectLocator.getAdminData().getConfigRootPath());
	}

	public static String stripLastSlash(String inputString) {
		if (inputString != null) {
			inputString = inputString.trim();
			if (inputString.endsWith("/") || inputString.endsWith("\\")) {
				return inputString.substring(0, inputString.length() - 1);
			}
		}

		return inputString;
	}

	public java.security.KeyStore getJavaKeyStore(String keyStoreName, String managementScope) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getJavaKeyStore", new Object[]{keyStoreName, managementScope});
		}

		java.security.KeyStore javaKeyStore = null;
		SecurityConfigObject keyStore = null;
		if (keyStoreName == null) {
			throw new SSLException("No keystore name provided.");
		} else {
			if (managementScope != null && managementScope.length() == 0) {
				managementScope = null;
			}

			if (managementScope != null
					&& !ManagementScopeManager.getInstance().currentScopeContained(managementScope)) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "KeyStore is not in the current scope.");
				}

				throw new SSLException("KeyStore is not in the current scope.");
			} else {
				WSKeyStore ks = (WSKeyStore) this.keyStoreMap.get(keyStoreName);
				if (ks != null && managementScope != null && managementScope.equals(ks.getManagementScope())) {
					if (tc.isDebugEnabled()) {
						Tr.exit(tc, "Found the keystore in cache return the java keystore value");
					}

					return ks.getKeyStore(false, false);
				} else {
					try {
						SecurityConfigManager scm = SecurityObjectLocator.getSecurityConfigManager();
						if (scm == null) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "SecurityConfigManager is null.");
							}

							return null;
						}

						SecurityConfigObjectList keyStores = scm.getObjectList("security::keyStores");
						if (keyStores != null) {
							for (int i = 0; i < keyStores.size(); ++i) {
								keyStore = keyStores.get(i);
								String name = keyStore.getString("name");
								SecurityConfigObject myScope = keyStore.getObject("managementScope");
								String scope = myScope.getString("scopeName");
								if (tc.isDebugEnabled()) {
									Tr.debug(tc, "Checking name and scope: " + name + ":" + scope);
								}

								WSKeyStore wsks = null;
								if (keyStoreName != null && name.equals(keyStoreName)) {
									if (tc.isEntryEnabled()) {
										Tr.debug(tc, "found the keystore", new Object[]{name});
									}

									if (managementScope != null && scope != null && managementScope.equals(scope)
											|| managementScope == null) {
										wsks = new WSKeyStore(keyStore);
									}

									if (wsks != null) {
										javaKeyStore = wsks.getKeyStore(false, false);
										wsks = null;
										break;
									}
								}
							}
						} else if (tc.isEntryEnabled()) {
							Tr.debug(tc, "keyStore are null might be a client process");
						}
					} catch (Exception var13) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Unable to get the getJavaKeyStore " + keyStoreName, new Object[]{var13});
						}

						throw var13;
					}

					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getJavaKeyStore");
					}

					return javaKeyStore;
				}
			}
		}
	}

	public WSKeyStore getWSKeyStore(String keyStoreName, String managementScope) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getWSKeyStore", new Object[]{keyStoreName, managementScope});
		}

		WSKeyStore ks = null;
		SecurityConfigObject keyStore = null;
		if (keyStoreName == null) {
			throw new SSLException("No keystore name provided.");
		} else {
			if (managementScope != null && managementScope.length() == 0) {
				managementScope = null;
			}

			if (managementScope != null && managementScope.length() > 0
					&& !ManagementScopeManager.getInstance().currentScopeContained(managementScope)) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "KeyStore is not in the current scope.");
				}

				throw new SSLException("KeyStore is not in the current scope.");
			} else {
				ks = (WSKeyStore) this.keyStoreMap.get(keyStoreName);
				if (ks != null) {
					if (managementScope != null && managementScope.length() > 0
							&& managementScope.equals(ks.getManagementScope())) {
						if (tc.isDebugEnabled()) {
							Tr.exit(tc, "Found the keystore in cache return the java keystore value");
						}

						return ks;
					}

					if (managementScope == null) {
						if (tc.isDebugEnabled()) {
							Tr.exit(tc,
									"Found the keystore in cache return the java keystore value.  Management scope passed in was null.");
						}

						return ks;
					}
				}

				try {
					SecurityConfigManager scm = SecurityObjectLocator.getSecurityConfigManager();
					if (scm == null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "SecurityConfigManager is null.");
						}

						return null;
					}

					SecurityConfigObjectList keyStores = scm.getObjectList("security::keyStores");
					if (keyStores != null) {
						for (int i = 0; i < keyStores.size(); ++i) {
							keyStore = keyStores.get(i);
							String name = keyStore.getString("name");
							SecurityConfigObject myScope = keyStore.getObject("managementScope");
							String scope = myScope.getString("scopeName");
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Checking name and scope: " + name + ":" + scope);
							}

							WSKeyStore wsks = null;
							if (keyStoreName != null && name.equals(keyStoreName)) {
								if (tc.isEntryEnabled()) {
									Tr.debug(tc, "found the keystore", new Object[]{name});
								}

								if (managementScope != null && scope != null && managementScope.equals(scope)
										|| managementScope == null) {
									wsks = new WSKeyStore(keyStore);
								}

								if (wsks != null) {
									ks = wsks;
									break;
								}
							}
						}
					} else if (tc.isEntryEnabled()) {
						Tr.debug(tc, "keyStore are null might be a client process");
					}
				} catch (Exception var12) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Unable to get the getJavaKeyStore " + keyStoreName, new Object[]{var12});
					}

					throw var12;
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getWSeyStore");
				}

				return ks;
			}
		}
	}

	public void refreshClientKeyStoreAndTrustStore(SSLConfig sslprops) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "refreshClientKeyStoreAndTrustStore");
		}

		if (sslprops != null && !sslprops.isEmpty()) {
			String keyStoreName = sslprops.getProperty("com.ibm.ssl.keyStoreName");
			this.clearKeyStoreFromMap(keyStoreName);
			String trustStoreName = sslprops.getProperty("com.ibm.ssl.trustStoreName");
			this.clearKeyStoreFromMap(trustStoreName);
			this.checkIfClientKeyStoreAndTrustStoreExistsAndCreateIfNot(sslprops);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "refreshClientKeyStoreAndTrustStore");
		}

	}
}