package com.google.common.annotations;

@GwtCompatible
public @interface VisibleForTesting {
}