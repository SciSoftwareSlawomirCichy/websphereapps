package com.ibm.ejs.util.am;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.am.AlarmManager.Implementation;
import com.ibm.ejs.util.am.AlarmManagerCSLM.1;
import com.ibm.ejs.util.am.AlarmManagerCSLM.DeferrableScheduledExecutorService;
import com.ibm.ejs.util.am.AlarmManagerCSLM.NonDeferrableScheduledExecutorService;
import com.ibm.ejs.util.am.AlarmManagerCSLM.ThreadPoolExecutor;
import com.ibm.ws.util.PlatformHelperFactory;
import java.util.Vector;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;

class AlarmManagerCSLM implements Implementation {
	private static final TraceComponent tc = Tr.register(AlarmManagerCSLM.class, (String) null, (String) null);
	static final ConcurrentSkipListMap<_Alarm, _Alarm> deferredAlarmQ = new ConcurrentSkipListMap();
	static final ConcurrentSkipListMap<_Alarm, _Alarm> nonDeferredAlarmQ = new ConcurrentSkipListMap();
	static AlarmManagerThreadCSLM deferredAlarmManagerThread;
	static AlarmManagerThreadCSLM nonDeferredAlarmManagerThread;
	private static boolean initialized = false;
	private static boolean deferred = false;
	private static Vector<_Alarm> deferredAlarmList = new Vector();
	private static int activeWork = 0;
	private static final Executor deferrableExecutor = new ThreadPoolExecutor(new AlarmThreadPool("Deferrable Alarm"));
	private static final Executor nondeferrableExecutor = new ThreadPoolExecutor(
			new AlarmThreadPool("Non-deferrable Alarm"));
	private static ScheduledExecutorService deferrableScheduledExecutorService;
	private static ScheduledExecutorService nondeferrableScheduledExecutorService;

	static final synchronized void init() {
		if (!initialized) {
			if (PlatformHelperFactory.getPlatformHelper().isBaseServantJvm()) {
				deferred = true;
			}

			deferredAlarmManagerThread = new AlarmManagerThreadCSLM(deferredAlarmQ, deferred);
			Thread dThread = new Thread(deferredAlarmManagerThread, "Deferred Alarm Manager");
			dThread.setDaemon(true);
			dThread.start();
			nonDeferredAlarmManagerThread = new AlarmManagerThreadCSLM(nonDeferredAlarmQ, false);
			Thread ndThread = new Thread(nonDeferredAlarmManagerThread, "Non-Deferred Alarm Manager");
			ndThread.setDaemon(true);
			ndThread.start();
			initialized = true;
		}
	}

	public ScheduledExecutorService getNonDeferrableScheduledExecutorService() {
		return nondeferrableScheduledExecutorService;
	}

	public ScheduledExecutorService createNonDeferrableScheduledExecutorService(Executor executor) {
		return new NonDeferrableScheduledExecutorService(executor);
	}

	public final Alarm createNonDeferrable(long n, AlarmListener l, Object alarmContext) {
		return this.createNonDeferrable(n, l, alarmContext, nondeferrableExecutor);
	}

	public final Alarm createNonDeferrable(long n, AlarmListener l, Object alarmContext, Executor executor) {
		init();
		boolean isAnyTracingEnabled = TraceComponent.isAnyTracingEnabled();
		if (isAnyTracingEnabled && tc.isEntryEnabled()) {
			Tr.entry(tc, "createNonDeferrable", new Object[]{new Long(n), l, alarmContext, executor});
		}

		if (l == null) {
			throw new NullPointerException();
		} else {
			if (n < 0L) {
				n = 0L;
			}

			_Alarm result = new _Alarm(n, l, alarmContext, false, executor);
			addNonDeferrable(result);
			if (isAnyTracingEnabled && tc.isEntryEnabled()) {
				Tr.exit(tc, "createNonDeferrable", result);
			}

			return result;
		}
	}

	protected static void addNonDeferrable(_Alarm result) {
		result.expirationTime += AlarmManager.getMillisTime();
		if (result.expirationTime < 0L) {
			result.expirationTime = Long.MAX_VALUE;
		}

		nonDeferredAlarmQ.put(result, result);
		_Alarm waitingOn = nonDeferredAlarmManagerThread.waitingOn;
		if (waitingOn == null || result.compareTo(waitingOn) < 0) {
			ConcurrentSkipListMap var2 = nonDeferredAlarmQ;
			synchronized (nonDeferredAlarmQ) {
				nonDeferredAlarmQ.notify();
			}
		}

	}

	public ScheduledExecutorService getDeferrableScheduledExecutorService() {
		return deferrableScheduledExecutorService;
	}

	public ScheduledExecutorService createDeferrableScheduledExecutorService(Executor executor) {
		return new DeferrableScheduledExecutorService(executor);
	}

	public final Alarm createDeferrable(long n, AlarmListener l, Object alarmContext) {
		init();
		boolean isAnyTracingEnabled = TraceComponent.isAnyTracingEnabled();
		if (isAnyTracingEnabled && tc.isEntryEnabled()) {
			Tr.entry(tc, "createDeferrable", new Object[]{new Long(n), l, alarmContext});
		}

		if (l == null) {
			throw new NullPointerException();
		} else {
			if (n < 0L) {
				n = 0L;
			}

			_Alarm result = new _Alarm(n, l, alarmContext, true, deferrableExecutor);
			addDeferrable(result);
			if (isAnyTracingEnabled && tc.isEntryEnabled()) {
				Tr.exit(tc, "createDeferrable", result);
			}

			return result;
		}
	}

	static void addDeferrable(_Alarm result) {
		if (deferred && activeWork <= 0) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Alarm has been deferred", result);
			}

			Vector var7 = deferredAlarmList;
			synchronized (deferredAlarmList) {
				deferredAlarmList.add(result);
			}
		} else {
			result.expirationTime += AlarmManager.getMillisTime();
			if (result.expirationTime < 0L) {
				result.expirationTime = Long.MAX_VALUE;
			}

			deferredAlarmQ.put(result, result);
			_Alarm waitingOn = deferredAlarmManagerThread.waitingOn;
			if (waitingOn == null || result.compareTo(waitingOn) < 0) {
				ConcurrentSkipListMap var2 = deferredAlarmQ;
				synchronized (deferredAlarmQ) {
					deferredAlarmQ.notify();
				}
			}
		}

	}

	public final void cancel(Alarm a) {
		boolean isAnyTracingEnabled = TraceComponent.isAnyTracingEnabled();
		if (isAnyTracingEnabled && tc.isEntryEnabled()) {
			Tr.exit(tc, "cancel");
		}

		this.disableAlarm(a);
		if (isAnyTracingEnabled && tc.isEntryEnabled()) {
			Tr.exit(tc, "cancel");
		}

	}

	public void stopMonitoring() {
		((ThreadPoolExecutor) deferrableExecutor).stopMonitoring();
		((ThreadPoolExecutor) nondeferrableExecutor).stopMonitoring();
	}

	public final boolean disableAlarm(Alarm a) {
		return disableAlarm((_Alarm) a);
	}

	static boolean disableAlarm(_Alarm a) {
		boolean isAnyTracingEnabled = TraceComponent.isAnyTracingEnabled();
		if (isAnyTracingEnabled && tc.isEntryEnabled()) {
			Tr.entry(tc, "disableAlarm", a);
		}

		boolean disabled = false;
		synchronized (a) {
			if (!a.fired) {
				disabled = true;
				a.fired = true;
			}
		}

		ConcurrentSkipListMap var12;
		if (a.deferrable) {
			Vector var3 = deferredAlarmList;
			synchronized (deferredAlarmList) {
				deferredAlarmList.remove(a);
			}

			deferredAlarmQ.remove(a);
			if (deferredAlarmManagerThread.waitingOn == a) {
				var12 = deferredAlarmQ;
				synchronized (deferredAlarmQ) {
					deferredAlarmQ.notify();
				}
			}
		} else {
			nonDeferredAlarmQ.remove(a);
			if (nonDeferredAlarmManagerThread.waitingOn == a) {
				var12 = nonDeferredAlarmQ;
				synchronized (nonDeferredAlarmQ) {
					nonDeferredAlarmQ.notify();
				}
			}
		}

		if (isAnyTracingEnabled && tc.isEntryEnabled()) {
			Tr.exit(tc, "disableAlarm", disabled);
		}

		return disabled;
	}

	private final void armDeferredAlarms() {
      this.createNonDeferrable(1000L, new 1(this), (Object)null);
   }

	public void incActiveWork() {
		ConcurrentSkipListMap var1 = deferredAlarmQ;
		synchronized (deferredAlarmQ) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "activeWork = " + activeWork);
			}

			if (activeWork == 0) {
				this.armDeferredAlarms();
			}

			++activeWork;
		}
	}

	public void decActiveWork() {
		ConcurrentSkipListMap var1 = deferredAlarmQ;
		synchronized (deferredAlarmQ) {
			--activeWork;
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "activeWork = " + activeWork);
			}

			if (activeWork == 0) {
				deferredAlarmQ.notify();
			}

		}
	}

	public int getActiveWork() {
		return activeWork;
	}

	static {
		deferrableScheduledExecutorService = new DeferrableScheduledExecutorService(deferrableExecutor);
		nondeferrableScheduledExecutorService = new NonDeferrableScheduledExecutorService(nondeferrableExecutor);
	}
}