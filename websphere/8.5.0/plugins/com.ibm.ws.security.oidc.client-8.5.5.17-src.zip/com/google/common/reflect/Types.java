package com.google.common.reflect;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicates;
import com.google.common.collect.Iterables;
import com.google.common.reflect.Types.1;
import com.google.common.reflect.Types.2;
import com.google.common.reflect.Types.ClassOwnership;
import com.google.common.reflect.Types.JavaVersion;
import com.google.common.reflect.Types.ParameterizedTypeImpl;
import com.google.common.reflect.Types.TypeVariableImpl;
import com.google.common.reflect.Types.TypeVariableInvocationHandler;
import com.google.common.reflect.Types.WildcardTypeImpl;
import java.lang.reflect.Array;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicReference;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

final class Types {
	private static final Function<Type, String> TYPE_NAME = new 1();
	private static final Joiner COMMA_JOINER = Joiner.on(", ").useForNull("null");

	static Type newArrayType(Type componentType) {
		if (componentType instanceof WildcardType) {
			WildcardType wildcard = (WildcardType) componentType;
			Type[] lowerBounds = wildcard.getLowerBounds();
			Preconditions.checkArgument(lowerBounds.length <= 1, "Wildcard cannot have more than one lower bounds.");
			if (lowerBounds.length == 1) {
				return supertypeOf(newArrayType(lowerBounds[0]));
			} else {
				Type[] upperBounds = wildcard.getUpperBounds();
				Preconditions.checkArgument(upperBounds.length == 1, "Wildcard should have only one upper bound.");
				return subtypeOf(newArrayType(upperBounds[0]));
			}
		} else {
			return JavaVersion.CURRENT.newArrayType(componentType);
		}
	}

	static ParameterizedType newParameterizedTypeWithOwner(@NullableDecl Type ownerType, Class<?> rawType,
			Type... arguments) {
		if (ownerType == null) {
			return newParameterizedType(rawType, arguments);
		} else {
			Preconditions.checkNotNull(arguments);
			Preconditions.checkArgument(rawType.getEnclosingClass() != null, "Owner type for unenclosed %s", rawType);
			return new ParameterizedTypeImpl(ownerType, rawType, arguments);
		}
	}

	static ParameterizedType newParameterizedType(Class<?> rawType, Type... arguments) {
		return new ParameterizedTypeImpl(ClassOwnership.JVM_BEHAVIOR.getOwnerType(rawType), rawType, arguments);
	}

	static <D extends GenericDeclaration> TypeVariable<D> newArtificialTypeVariable(D declaration, String name,
			Type... bounds) {
		return newTypeVariableImpl(declaration, name, bounds.length == 0 ? new Type[]{Object.class} : bounds);
	}

	@VisibleForTesting
	static WildcardType subtypeOf(Type upperBound) {
		return new WildcardTypeImpl(new Type[0], new Type[]{upperBound});
	}

	@VisibleForTesting
	static WildcardType supertypeOf(Type lowerBound) {
		return new WildcardTypeImpl(new Type[]{lowerBound}, new Type[]{Object.class});
	}

	static String toString(Type type) {
		return type instanceof Class ? ((Class) type).getName() : type.toString();
	}

	@NullableDecl
   static Type getComponentType(Type type) {
      Preconditions.checkNotNull(type);
      AtomicReference<Type> result = new AtomicReference();
      (new 2(result)).visit(new Type[]{type});
      return (Type)result.get();
   }

	@NullableDecl
	private static Type subtypeOfComponentType(Type[] bounds) {
		Type[] var1 = bounds;
		int var2 = bounds.length;

		for (int var3 = 0; var3 < var2; ++var3) {
			Type bound = var1[var3];
			Type componentType = getComponentType(bound);
			if (componentType != null) {
				if (componentType instanceof Class) {
					Class<?> componentClass = (Class) componentType;
					if (componentClass.isPrimitive()) {
						return componentClass;
					}
				}

				return subtypeOf(componentType);
			}
		}

		return null;
	}

	private static <D extends GenericDeclaration> TypeVariable<D> newTypeVariableImpl(D genericDeclaration, String name,
			Type[] bounds) {
		TypeVariableImpl<D> typeVariableImpl = new TypeVariableImpl(genericDeclaration, name, bounds);
		TypeVariable<D> typeVariable = (TypeVariable) Reflection.newProxy(TypeVariable.class,
				new TypeVariableInvocationHandler(typeVariableImpl));
		return typeVariable;
	}

	private static Type[] toArray(Collection<Type> types) {
		return (Type[]) types.toArray(new Type[types.size()]);
	}

	private static Iterable<Type> filterUpperBounds(Iterable<Type> bounds) {
		return Iterables.filter(bounds, Predicates.not(Predicates.equalTo(Object.class)));
	}

	private static void disallowPrimitiveType(Type[] types, String usedAs) {
		Type[] var2 = types;
		int var3 = types.length;

		for (int var4 = 0; var4 < var3; ++var4) {
			Type type = var2[var4];
			if (type instanceof Class) {
				Class<?> cls = (Class) type;
				Preconditions.checkArgument(!cls.isPrimitive(), "Primitive type '%s' used as %s", cls, usedAs);
			}
		}

	}

	static Class<?> getArrayClass(Class<?> componentType) {
		return Array.newInstance(componentType, 0).getClass();
	}
}