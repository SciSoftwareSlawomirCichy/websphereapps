package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.collect.FilteredKeyMultimap.AddRejectingList;
import com.google.common.collect.FilteredKeyMultimap.AddRejectingSet;
import com.google.common.collect.FilteredKeyMultimap.Entries;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
class FilteredKeyMultimap<K, V> extends AbstractMultimap<K, V> implements FilteredMultimap<K, V> {
	final Multimap<K, V> unfiltered;
	final Predicate<? super K> keyPredicate;

	FilteredKeyMultimap(Multimap<K, V> unfiltered, Predicate<? super K> keyPredicate) {
		this.unfiltered = (Multimap) Preconditions.checkNotNull(unfiltered);
		this.keyPredicate = (Predicate) Preconditions.checkNotNull(keyPredicate);
	}

	public Multimap<K, V> unfiltered() {
		return this.unfiltered;
	}

	public Predicate<? super Entry<K, V>> entryPredicate() {
		return Maps.keyPredicateOnEntries(this.keyPredicate);
	}

	public int size() {
		int size = 0;

		Collection collection;
		for (Iterator var2 = this.asMap().values().iterator(); var2.hasNext(); size += collection.size()) {
			collection = (Collection) var2.next();
		}

		return size;
	}

	public boolean containsKey(@NullableDecl Object key) {
		return this.unfiltered.containsKey(key) ? this.keyPredicate.apply(key) : false;
	}

	public Collection<V> removeAll(Object key) {
		return this.containsKey(key) ? this.unfiltered.removeAll(key) : this.unmodifiableEmptyCollection();
	}

	Collection<V> unmodifiableEmptyCollection() {
		return (Collection) (this.unfiltered instanceof SetMultimap ? ImmutableSet.of() : ImmutableList.of());
	}

	public void clear() {
		this.keySet().clear();
	}

	Set<K> createKeySet() {
		return Sets.filter(this.unfiltered.keySet(), this.keyPredicate);
	}

	public Collection<V> get(K key) {
		if (this.keyPredicate.apply(key)) {
			return this.unfiltered.get(key);
		} else {
			return (Collection) (this.unfiltered instanceof SetMultimap
					? new AddRejectingSet(key)
					: new AddRejectingList(key));
		}
	}

	Iterator<Entry<K, V>> entryIterator() {
		throw new AssertionError("should never be called");
	}

	Collection<Entry<K, V>> createEntries() {
		return new Entries(this);
	}

	Collection<V> createValues() {
		return new FilteredMultimapValues(this);
	}

	Map<K, Collection<V>> createAsMap() {
		return Maps.filterKeys(this.unfiltered.asMap(), this.keyPredicate);
	}

	Multiset<K> createKeys() {
		return Multisets.filter(this.unfiltered.keys(), this.keyPredicate);
	}
}