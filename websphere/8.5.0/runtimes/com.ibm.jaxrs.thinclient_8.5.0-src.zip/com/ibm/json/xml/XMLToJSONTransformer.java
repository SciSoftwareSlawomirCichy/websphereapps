package com.ibm.json.xml;

import com.ibm.json.xml.internal.JSONSAXHandler;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class XMLToJSONTransformer {
	private static String className = "com.ibm.json.xml.transform.XMLToJSONTransformer";
	private static Logger logger;

	public static void transform(InputStream var0, OutputStream var1) throws SAXException, IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "transform(InputStream, OutputStream)");
		}

		transform(var0, var1, false);
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "transform(InputStream, OutputStream)");
		}

	}

	public static void transform(InputStream var0, OutputStream var1, boolean var2) throws SAXException, IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(className, "transform(InputStream, OutputStream)");
		}

		if (var0 == null) {
			throw new NullPointerException("XMLStream cannot be null");
		} else if (var1 == null) {
			throw new NullPointerException("JSONStream cannot be null");
		} else {
			if (logger.isLoggable(Level.FINEST)) {
				logger.logp(Level.FINEST, className, "transform", "Fetching a SAX parser for use with JSONSAXHandler");
			}

			try {
				SAXParserFactory var3 = SAXParserFactory.newInstance();
				var3.setNamespaceAware(true);
				SAXParser var4 = var3.newSAXParser();
				XMLReader var5 = var4.getXMLReader();
				JSONSAXHandler var6 = new JSONSAXHandler(var1, var2);
				var5.setContentHandler(var6);
				var5.setErrorHandler(var6);
				InputSource var7 = new InputSource(new BufferedInputStream(var0));
				if (logger.isLoggable(Level.FINEST)) {
					logger.logp(Level.FINEST, className, "transform", "Parsing the XML content to JSON");
				}

				var7.setEncoding("UTF-8");
				var5.parse(var7);
				var6.flushBuffer();
			} catch (ParserConfigurationException var8) {
				throw new SAXException("Could not get a parser: " + var8.toString());
			}

			if (logger.isLoggable(Level.FINER)) {
				logger.exiting(className, "transform(InputStream, OutputStream)");
			}

		}
	}

	public static String transform(InputStream var0) throws SAXException, IOException {
		return transform(var0, false);
	}

	public static String transform(InputStream var0, boolean var1) throws SAXException, IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "transform(InputStream, boolean)");
		}

		ByteArrayOutputStream var2 = new ByteArrayOutputStream();
		String var3 = null;

		try {
			transform(var0, var2, var1);
			var3 = var2.toString("UTF-8");
			var2.close();
		} catch (UnsupportedEncodingException var6) {
			IOException var5 = new IOException(var6.toString());
			var5.initCause(var6);
			throw var5;
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "transform(InputStream, boolean)");
		}

		return var3;
	}

	public static String transform(File var0, boolean var1) throws SAXException, IOException {
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "transform(InputStream, boolean)");
		}

		FileInputStream var2 = new FileInputStream(var0);
		String var3 = null;
		var3 = transform((InputStream) var2, var1);
		var2.close();
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(className, "transform(InputStream, boolean)");
		}

		return var3;
	}

	public static String transform(File var0) throws SAXException, IOException {
		return transform(var0, false);
	}

	static {
		logger = Logger.getLogger(className, (String) null);
	}
}