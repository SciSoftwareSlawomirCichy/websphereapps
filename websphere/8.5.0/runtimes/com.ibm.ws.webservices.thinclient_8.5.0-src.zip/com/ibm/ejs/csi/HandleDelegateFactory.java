package com.ibm.ejs.csi;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;

public class HandleDelegateFactory implements ObjectFactory {
	private static final TraceComponent tc = Tr.register(HandleDelegateFactory.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable env) throws Exception {
		String thisMethod = "getObjectInstance(Object, Name, Context, Hashtable)";
		boolean isEntryEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isEntryEnabled() : false;
		if (isEntryEnabled) {
			Tr.entry(tc, thisMethod);
		}

		Object retObj = null;
		if (!(obj instanceof Reference)) {
			if (isEntryEnabled) {
				Tr.exit(tc, thisMethod, obj + " is not a Reference");
			}

			return null;
		} else {
			Reference ref = (Reference) obj;
			if (!ref.getFactoryClassName().equals(this.getClass().getName())) {
				if (isEntryEnabled) {
					Tr.exit(tc, thisMethod, "this is not the right factory for this Reference: " + obj);
				}

				return null;
			} else {
				retObj = HandleDelegateImpl.getInstance();
				if (isEntryEnabled) {
					Tr.exit(tc, thisMethod, "retObj = " + retObj);
				}

				return retObj;
			}
		}
	}
}