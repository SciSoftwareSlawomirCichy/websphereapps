package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.security.auth.kerberos.Krb5Utils;
import com.ibm.ws.security.util.ConfigUtils;
import com.ibm.ws.security.util.LRUCache;
import java.io.File;
import java.net.MalformedURLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.RefreshFailedException;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.kerberos.KerberosPrincipal;
import javax.security.auth.kerberos.KerberosTicket;
import javax.security.auth.login.LoginException;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;

public class KerberosService {
	private static final String CLASSNAME = KerberosService.class.getName();
	private static final Logger trcLogger;
	private static final LRUCache subjectCache;
	private static KerberosService INSTANCE;
	private static String krb5Config;

	public static synchronized KerberosService getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new KerberosService();
		}

		return INSTANCE;
	}

	public Subject getOrCreateSubject(String var1) throws LoginException, MalformedURLException {
		return this.getOrCreateSubject(var1, (String) null, (String) null, (String) null);
	}

	public Subject getOrCreateSubject(String var1, String var2, String var3, String var4)
			throws LoginException, MalformedURLException {
		if (var2 != null && (krb5Config == null || !krb5Config.equals(var2))) {
			krb5Config = ConfigUtils.expandString(var2);
			Krb5Utils.setKrbConfigProp(krb5Config);
		}

		KerberosPrincipal var5 = new KerberosPrincipal(var1);
		Subject var6 = (Subject) subjectCache.get(var5);
		Subject var7;
		if (var6 != null) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "getOrCreateSubject", "subject found in cache");
			}

			var7 = this.validateAndRefreshSubject(var5, var6);
			if (var7 != null) {
				return var7;
			}
		}

		var7 = this.doKerberosLogin(var1, var3, var4);
		subjectCache.put(var5, var7);
		return var7;
	}

	public Subject createTempSubject(String var1, String var2, String var3, String var4)
			throws LoginException, MalformedURLException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createTempSubject", "Temp subject requested for: principal " + var1
					+ ", config: " + var2 + ", ccache: " + var3 + ", keytab: " + var4);
		}

		if (var2 != null && (krb5Config == null || !krb5Config.equals(var2))) {
			krb5Config = ConfigUtils.expandString(var2);
			Krb5Utils.setKrbConfigProp(krb5Config);
		}

		Subject var5 = this.doKerberosLogin(var1, var3, var4);
		return var5;
	}

	public Subject validateAndRefreshSubject(KerberosPrincipal var1, Subject var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateAndRefreshSubject", var1);
		}

		Set var4 = var2.getPrivateCredentials(GSSCredential.class);
		Iterator var5 = var4.iterator();
		if (var5.hasNext()) {
			GSSCredential var6 = (GSSCredential) var5.next();
			int var7 = -1;

			try {
				var7 = var6.getRemainingLifetime();
			} catch (GSSException var15) {
				;
			}

			if (var7 <= 0) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "validateAndRefreshSubject",
							"no match because remaining lifetime is: " + var7);
				}

				return null;
			}
		}

		Set var17 = var2.getPrivateCredentials(KerberosTicket.class);
		Iterator var18 = var17.iterator();
		if (var18.hasNext()) {
			KerberosTicket var19 = (KerberosTicket) var18.next();
			if (var19.isDestroyed()) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "validateAndRefreshSubject",
							"Found destroyed kerberos ticket. Removing from cache");
				}

				return null;
			}

			long var8 = var19.getEndTime().getTime();
			long var10 = (new Date()).getTime();
			int var12 = 600000;
			boolean var13 = var19.isRenewable() && var8 < var10 + (long) var12;
			if (!var19.isCurrent() || var13) {
				if (!var19.isRenewable()) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "validateAndRefreshSubject",
								"no match because ticket is not current and not renewable");
					}

					return null;
				}

				if (!var13) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "validateAndRefreshSubject",
								"no match because ticket is renewable but past the renewTill time");
					}

					return null;
				}

				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "validateAndRefreshSubject",
							"found match for non-current ticket, but ticket is renewable. Attempting to renew now");
				}

				try {
					var19.refresh();
					subjectCache.put(var1, var2);
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "validateAndRefreshSubject",
								"Successfully renewed ticket and cached the updated subject");
					}
				} catch (RefreshFailedException var16) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "validateAndRefreshSubject",
								"unable to refresh kerberos ticket due to: " + var16);
					}

					return null;
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "validateAndRefreshSubject", "Found cached subject for principal: " + var1);
		}

		return var2;
	}

	private Subject doKerberosLogin(String var1, String var2, String var3)
			throws LoginException, MalformedURLException {
		Subject var4 = new Subject();
		Krb5LoginModuleProxy var5 = new Krb5LoginModuleProxy();
		HashMap var6 = new HashMap();
		HashMap var7 = new HashMap();
		var6.put("principal", var1);
		var6.put("credsType", "initiator");
		WIMConfigurationException var9;
		String var13;
		if (var2 != null && !var2.trim().isEmpty()) {
			var13 = ConfigUtils.expandString(var2);
			var13 = (new File(var13)).toURI().toURL().toString();
			var6.put("useCcache", var13);
			this.jdkKerberosLogin(var4, var5, var6, var7);
			if (var4.getPrincipals().isEmpty()) {
				var9 = new WIMConfigurationException("KRB5_LOGIN_FAILED_CACHE",
						WIMMessageHelper.generateMsgParms(var1, var13), Level.SEVERE, KerberosService.class.getName(),
						"doKerberosLogin");
				throw new LoginException(var9.getMessage());
			}
		} else if (var3 != null && !var3.trim().isEmpty()) {
			var13 = ConfigUtils.expandString(var3);
			var13 = (new File(var13)).toURI().toURL().toString();
			var6.put("useKeytab", var13);
			var6.put("credsType", "both");

			try {
				this.jdkKerberosLogin(var4, var5, var6, var7);
			} catch (LoginException var12) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "doKerberosLogin",
							"Exception logging in " + var1 + " with keytab (" + var3 + ") " + var13, var12);
				}

				WIMConfigurationException var10 = new WIMConfigurationException("KRB5_LOGIN_FAILED_KEYTAB",
						WIMMessageHelper.generateMsgParms(var1, var13), Level.SEVERE, KerberosService.class.getName(),
						"doKerberosLogin");
				LoginException var11 = new LoginException(
						var10.getMessage() + " " + var12.getClass().getName() + ": " + var12.getMessage());
				throw var11;
			}

			if (var4.getPrincipals().isEmpty()) {
				var9 = new WIMConfigurationException("KRB5_LOGIN_FAILED_KEYTAB",
						WIMMessageHelper.generateMsgParms(var1, var13), Level.SEVERE, KerberosService.class.getName(),
						"doKerberosLogin");
				throw new LoginException(var9.getMessage());
			}
		} else {
			var6.put("useDefaultKeytab", "true");
			var6.put("credsType", "both");
			this.jdkKerberosLogin(var4, var5, var6, var7);
			if (var4.getPrincipals().isEmpty()) {
				WIMConfigurationException var8 = new WIMConfigurationException("KRB5_LOGIN_FAILED_DEFAULT_KEYTAB",
						WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, KerberosService.class.getName(),
						"doKerberosLogin");
				throw new LoginException(var8.getMessage());
			}
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			var13 = var4 != null ? "is not null." : "is null.";
			trcLogger.logp(Level.FINEST, CLASSNAME, "doKerberosLogin", "subject: " + var13);
		}

		return var4;
	}

	private void jdkKerberosLogin(Subject var1, Krb5LoginModuleProxy var2, Map<String, String> var3,
			Map<String, Object> var4) throws LoginException {
		var2.initialize(var1, (CallbackHandler) null, var4, var3);
		var2.login();
		var2.commit();
	}

	public void clearPrincipalFromCache(String var1) throws LoginException {
		if ((var1 == null || var1.trim().isEmpty()) && trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "clearPrincipalFromCache",
					"Clear skipped because krb5Principal was " + (var1 == null ? var1 : " an empty string"));
		}

		Object var2 = subjectCache.remove(this.getKerberosPrincipal(var1));
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "clearPrincipalFromCache",
					"Clear requested for " + var1 + ": " + (var2 != null ? "removed" : "not found in cache"));
		}

	}

	private KerberosPrincipal getKerberosPrincipal(String var1) throws LoginException {
		try {
			return new KerberosPrincipal(var1);
		} catch (IllegalArgumentException var4) {
			WIMConfigurationException var3 = new WIMConfigurationException("INVALID_KRB5_PRINCIPAL",
					WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, KerberosService.class.getName(),
					"getKerberosPrincipal");
			throw new LoginException(var3.getMessage());
		}
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		subjectCache = new LRUCache(100);
		INSTANCE = null;
		krb5Config = null;
	}
}