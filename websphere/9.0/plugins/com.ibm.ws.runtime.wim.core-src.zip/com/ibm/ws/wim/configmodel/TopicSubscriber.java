package com.ibm.ws.wim.configmodel;

public interface TopicSubscriber {
	String getClassName();

	void setClassName(String var1);

	String getTopicSubscriberName();

	void setTopicSubscriberName(String var1);

	SubscriberType getTopicSubscriberType();

	void setTopicSubscriberType(SubscriberType var1);

	void unsetTopicSubscriberType();

	boolean isSetTopicSubscriberType();
}