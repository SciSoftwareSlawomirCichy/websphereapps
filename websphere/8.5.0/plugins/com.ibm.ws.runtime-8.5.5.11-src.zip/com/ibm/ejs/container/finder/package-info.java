package com.ibm.ejs.container.finder;

interface package-info {
}