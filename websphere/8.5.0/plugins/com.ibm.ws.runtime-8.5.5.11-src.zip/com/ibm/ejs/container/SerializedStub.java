package com.ibm.ejs.container;

import java.io.Serializable;
import javax.rmi.PortableRemoteObject;

public class SerializedStub implements Serializable {
	private static final long serialVersionUID = 3019532699780090519L;
	private final Object ivStub;
	private final Class ivClass;

	SerializedStub(Object stub, Class klass) {
		this.ivStub = stub;
		this.ivClass = klass;
	}

	private Object readResolve() {
		return PortableRemoteObject.narrow(this.ivStub, this.ivClass);
	}
}