package com.ibm.ejs.container;

public interface LocalBeanWrapperProxy extends WrapperProxy {
}