package com.ibm.ejs.container;

import com.ibm.ejs.container.interceptors.InterceptorMetaData;
import com.ibm.ejs.container.interceptors.InterceptorProxy;
import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.ws.ejbcontainer.CallbackKind;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ConstructionCallback;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.managedobject.ManagedObjectContext;
import com.ibm.ws.managedobject.ManagedObjectFactory;
import com.ibm.wsspi.injectionengine.InjectionEngine;
import com.ibm.wsspi.injectionengine.InjectionTarget;
import com.ibm.wsspi.injectionengine.InjectionTargetContext;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import javax.ejb.EJBException;

public abstract class ManagedBeanOBase extends BeanO implements ConstructionCallback {
	private static final String CLASS_NAME = ManagedBeanOBase.class.getName();
	private static final TraceComponent tc = Tr.register(ManagedBeanOBase.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	public Object ivEjbInstance;
	public ManagedObjectContext ivEjbManagedObjectContext;
	public ManagedObject<?> ivManagedObject;
	public Object[] ivInterceptors;

	public ManagedBeanOBase(EJSContainer c, EJSHome h) {
		super(c, h);
	}

	public void setEnterpriseBean(Object bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setEnterpriseBean : " + Util.identity(bean));
		}

		this.ivEjbInstance = bean;
	}

	private void createInterceptors(InterceptorMetaData imd) {
		this.ivInterceptors = new Object[imd.ivInterceptorClasses.length];

		try {
			imd.createInterceptorInstances(this.getInjectionEngine(), this.ivInterceptors,
					this.ivEjbManagedObjectContext, this);
		} catch (Throwable var3) {
			FFDCFilter.processException(var3, CLASS_NAME + ".ManagedBeanOBase", "177", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "interceptor creation failure", var3);
			}

			throw ExceptionUtil.EJBException("Interceptor creation failure", var3);
		}
	}

	public <T> T getInjectionTargetContextData(Class<T> type) {
		if (this.ivEjbManagedObjectContext != null) {
			T data = this.ivEjbManagedObjectContext.getContextData(type);
			if (data != null) {
				return data;
			}
		}

		return super.getInjectionTargetContextData(type);
	}

	protected void injectInstance(Object managedObject, InjectionTargetContext injectionContext) throws EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "injectInstance : " + Util.identity(managedObject) + ", " + injectionContext);
		}

		BeanMetaData bmd = this.home.beanMetaData;
		if (bmd.ivBeanInjectionTargets != null) {
			try {
				InjectionEngine injectionEngine = this.getInjectionEngine();
				InjectionTarget[] arr$ = bmd.ivBeanInjectionTargets;
				int len$ = arr$.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					InjectionTarget injectionTarget = arr$[i$];
					injectionEngine.inject(this.ivEjbInstance, injectionTarget, injectionContext);
				}
			} catch (Throwable var10) {
				FFDCFilter.processException(var10, CLASS_NAME + ".injectInstance", "134", this);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "injectInstance : Injection failure", var10);
				}

				throw ExceptionUtil.EJBException("Injection failure", var10);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "injectInstance");
		}

	}

	protected void releaseManagedObjectContext() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "releaseManagedObjectContext : " + this.ivEjbManagedObjectContext);
		}

		if (this.ivEjbManagedObjectContext != null) {
			this.ivEjbManagedObjectContext.release();
		}

	}

	protected void createInterceptorsAndInstance(CallbackContextHelper contextHelper) throws InvocationTargetException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createInterceptorsAndInstance : " + contextHelper);
		}

		BeanMetaData bmd = this.home.beanMetaData;
		ManagedObjectFactory<?> managedObjectFactory = bmd.ivEnterpriseBeanFactory;
		if (managedObjectFactory != null) {
			this.ivEjbManagedObjectContext = managedObjectFactory.createContext();
		}

		InterceptorMetaData imd = bmd.ivInterceptorMetaData;
		if (imd != null && !bmd.managedObjectManagesInjectionAndInterceptors) {
			this.createInterceptors(imd);
			if (bmd.ivCallbackKind == CallbackKind.InvocationContext) {
				InterceptorProxy[] aroundConstructProxies = imd.ivAroundConstructInterceptors;
				if (aroundConstructProxies != null) {
					InvocationContextImpl<?> context = this.callAroundConstructInterceptors(aroundConstructProxies,
							contextHelper);
					if (this.ivEjbInstance == null) {
						if (context.ivAroundConstructException != null) {
							Throwable t = context.ivAroundConstructException.getCause();
							if (t == null) {
								t = context.ivAroundConstructException;
							}

							throw ExceptionUtil.EJBException("AroundConstruct interceptors for the "
									+ bmd.enterpriseBeanName + " bean in the " + bmd._moduleMetaData.ivName
									+ " module in the " + bmd._moduleMetaData.ivAppName
									+ " application resulted in an exception being thrown from the constructor of the "
									+ bmd.enterpriseBeanClassName + " class.", (Throwable) t);
						}

						throw new EJBException(
								"AroundConstruct interceptors for the " + bmd.enterpriseBeanName + " bean in the "
										+ bmd._moduleMetaData.ivName + " module in the " + bmd._moduleMetaData.ivAppName
										+ " application did not call InvocationContext.proceed()");
					}
				}
			}
		}

		if (this.ivEjbInstance == null) {
			this.createInstance();
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createInterceptorsAndInstance");
		}

	}

	private void createInstance() throws InvocationTargetException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createInstance");
		}

		ManagedObjectFactory ejbManagedObjectFactory = this.home.beanMetaData.ivEnterpriseBeanFactory;

		try {
			if (ejbManagedObjectFactory != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "calling ManagedObjectFactory.createManagedObject(null)");
				}

				InvocationContextImpl invCtx = this.getInvocationContext();
				this.ivManagedObject = ejbManagedObjectFactory.createManagedObject(invCtx);
				this.ivEjbManagedObjectContext = this.ivManagedObject.getContext();
				this.setEnterpriseBean(this.ivManagedObject.getObject());
			} else {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "calling Constructor.newInstance");
				}

				Constructor<?> con = this.home.beanMetaData.getEnterpriseBeanClassConstructor();
				this.setEnterpriseBean(con.newInstance());
			}
		} catch (InvocationTargetException var4) {
			FFDCFilter.processException(var4, CLASS_NAME + ".createInstance", "216", this);
			throw var4;
		} catch (Exception var5) {
			FFDCFilter.processException(var5, CLASS_NAME + ".createInstance", "220", this);
			throw new EJBException(this.home.beanMetaData.enterpriseBeanClassName, var5);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createInstance");
		}

	}

	protected InvocationContextImpl getInvocationContext() {
		InvocationContextImpl invocationContext = this.createInvocationContext();
		invocationContext.initialize(this.ivEjbInstance, this.ivEjbManagedObjectContext, this.ivInterceptors);
		return invocationContext;
	}

	protected InvocationContextImpl createInvocationContext() {
		return new InvocationContextImpl();
	}

	private InvocationContextImpl<?> callAroundConstructInterceptors(InterceptorProxy[] proxies,
			CallbackContextHelper contextHelper) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "callAroundConstructInterceptors");
		}

		InvocationContextImpl invCtx = this.createInvocationContext();

		InvocationContextImpl var6;
		try {
			try {
				BeanMetaData bmd = this.home.beanMetaData;
				ManagedObjectFactory<?> managedObjectFactory = bmd.ivEnterpriseBeanFactory;
				invCtx.initializeForAroundConstruct(this.ivEjbManagedObjectContext, this.ivInterceptors, proxies);
				if (managedObjectFactory == null) {
					this.setEnterpriseBean(invCtx.aroundConstruct(this, new Object[0], (Map) null));
				} else {
					this.ivManagedObject = managedObjectFactory.createManagedObject(invCtx);
					this.setEnterpriseBean(this.ivManagedObject.getObject());
				}

				InvocationContextImpl var7 = invCtx;
				return var7;
			} catch (Throwable var11) {
				FFDCFilter.processException(var11, CLASS_NAME + ".callAroundConstructInterceptors", "240", this);
				if (invCtx.ivAroundConstructException == null) {
					throw ExceptionUtil.EJBException("AroundConstruct interceptor failure", var11);
				}
			}

			var6 = invCtx;
		} finally {
			if (contextHelper != null) {
				contextHelper.resetContextData();
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "callAroundConstructInterceptors");
			}

		}

		return var6;
	}

	public Constructor<?> getConstructor() {
		return this.home.beanMetaData.getEnterpriseBeanClassConstructor();
	}

	public Object proceed(Object[] parameters, Map data) throws Exception {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "proceed: calling Constructor.newInstance");
		}

		return this.getConstructor().newInstance(parameters);
	}
}