package com.ibm.ws.wim.adapter.urbridge;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.security.core.ContextManagerFactory;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.util.DomainManagerUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class URBridgeHelper {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;
	private static Map<String, List> personAccountTypeList;
	private static Map<String, List> groupAccountTypeList;

	public static boolean isSuperType(String var0, String var1) throws WIMException {
		return var0.equals(var1) || SchemaManager.singleton().isSuperType(var0, var1);
	}

	public static void mapSupportedEntityTypeList() throws WIMException {
		List var0 = ConfigManager.singleton().getSupportedEntityTypes();
		String var1 = DomainManagerUtils.getDomainId();
		personAccountTypeList.put(var1, new ArrayList(6));
		groupAccountTypeList.put(var1, new ArrayList(6));

		for (int var2 = 0; var2 < var0.size(); ++var2) {
			String var3 = (String) var0.get(var2);
			if (isSuperType("PersonAccount", var3)) {
				((List) personAccountTypeList.get(var1)).add(var3);
			}

			if (isSuperType("Group", var3)) {
				((List) groupAccountTypeList.get(var1)).add(var3);
			}
		}

	}

	public static String getPersonAccountType() {
		String var0 = DomainManagerUtils.getDomainId();
		return (String) ((List) personAccountTypeList.get(var0)).get(0);
	}

	public static String getGroupAccountType() {
		String var0 = DomainManagerUtils.getDomainId();
		return (String) ((List) groupAccountTypeList.get(var0)).get(0);
	}

	public static boolean isInternalServerId(String var0) {
		return ContextManagerFactory.getInstance().isInternalServerId(var0);
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = URBridge.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		personAccountTypeList = Collections.synchronizedMap(new HashMap());
		groupAccountTypeList = Collections.synchronizedMap(new HashMap());
	}
}