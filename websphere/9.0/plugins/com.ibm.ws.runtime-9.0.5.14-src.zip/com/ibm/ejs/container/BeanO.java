package com.ibm.ejs.container;

import com.ibm.ejs.container.activator.ActivationStrategy;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.csi.NullSecurityCollaborator;
import com.ibm.ejs.j2c.HandleList;
import com.ibm.ejs.j2c.HandleListInterface;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.BeanInstanceInfo;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.MethodInterface;
import com.ibm.websphere.csi.TransactionAttribute;
import com.ibm.websphere.ejbcontainer.EJBContextExtension;
import com.ibm.ws.csi.DispatchEventListenerCookie;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import com.ibm.ws.ejbcontainer.EJBSecurityCollaborator;
import com.ibm.ws.ejbcontainer.util.Pool;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.metadata.MethodMetaData;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import com.ibm.wsspi.injectionengine.InjectionBinding;
import com.ibm.wsspi.injectionengine.InjectionEngine;
import com.ibm.wsspi.injectionengine.InjectionException;
import com.ibm.wsspi.injectionengine.InjectionTargetContext;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.security.Identity;
import java.security.Principal;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.Properties;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EJBHome;
import javax.ejb.EJBLocalHome;
import javax.ejb.EnterpriseBean;
import javax.ejb.RemoveException;
import javax.ejb.ScheduleExpression;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;
import javax.transaction.UserTransaction;

public abstract class BeanO implements EJBContextExtension, TimerService, InjectionTargetContext, BeanInstanceInfo {
	private static final String CLASS_NAME = BeanO.class.getName();
	private static final TraceComponent tc = Tr.register(BeanO.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	protected static final boolean isZOS = EJSPlatformHelper.isZOS();
	protected int state;
	protected final transient EJSContainer container;
	protected final transient EJSHome home;
	protected transient EJBPMICollaborator pmiBean = null;
	protected BeanId beanId;
	protected transient Pool beanPool;
	private transient HandleList connectionHandleList = null;
	protected transient ContainerTx ivContainerTx = null;
	transient ActivationStrategy ivActivationStrategy;
	public transient Object ivCacheKey;

	public ContainerTx getContainerTx() {
		return this.ivContainerTx;
	}

	public void setContainerTx(ContainerTx ctx) {
		this.ivContainerTx = ctx;
	}

	public BeanO(EJSContainer c, EJSHome h) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "BeanO");
		}

		this.container = c;
		this.home = h;
		if (this.home != null) {
			this.pmiBean = this.home.pmiBean;
			if (this.pmiBean != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "pmiBean is non-null");
				}

				this.pmiBean.beanInstantiated();
			}

			this.beanPool = this.home.beanPool;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "BeanO");
		}

	}

	public String toString() {
		return this.getClass().getSimpleName() + '(' + this.beanId + ", " + this.getStateName(this.state) + ')';
	}

	abstract void initialize(boolean var1) throws RemoteException, InvocationTargetException;

	protected abstract String getStateName(int var1);

	protected final synchronized void setState(int newState) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
			TEBeanLifeCycleInfo.traceBeanState(this.state, this.getStateName(this.state), newState,
					this.getStateName(newState));
		}

		this.state = newState;
	}

	protected final synchronized void setState(int oldState, int newState)
			throws InvalidBeanOStateException, BeanNotReentrantException {
		if (this.state != oldState) {
			throw new InvalidBeanOStateException(this.getStateName(this.state), this.getStateName(oldState));
		} else {
			if (TraceComponent.isAnyTracingEnabled() && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceBeanState(this.state, this.getStateName(this.state), newState,
						this.getStateName(newState));
			}

			this.state = newState;
		}
	}

	public final void assertState(int expected) throws InvalidBeanOStateException {
		if (this.state != expected) {
			throw new InvalidBeanOStateException(this.getStateName(this.state), this.getStateName(expected));
		}
	}

	public final EJSContainer getContainer() {
		return this.container;
	}

	public final BeanId getId() {
		return this.beanId;
	}

	public final void setId(BeanId id) {
		this.beanId = id;
	}

	public final EJSHome getHome() {
		return this.home;
	}

	public abstract EnterpriseBean getEnterpriseBean() throws RemoteException;

	public abstract Object[] getInterceptors();

	public final ActivationStrategy getActivationStrategy() {
		if (this.ivActivationStrategy == null) {
			if (this.home == null) {
				this.ivActivationStrategy = EJSContainer.homeOfHomes.getActivationStrategy();
			} else {
				this.ivActivationStrategy = this.home.getActivationStrategy();
			}
		}

		return this.ivActivationStrategy;
	}

	public abstract void destroy();

	public abstract void activate(BeanId var1, ContainerTx var2) throws RemoteException;

	public void preEjbCreate() throws CreateException {
	}

	public abstract void postCreate(boolean var1) throws CreateException, RemoteException;

	public void afterPostCreate() throws CreateException, RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "afterPostCreate : no implementation");
		}

	}

	public void afterPostCreateCompletion() throws CreateException {
	}

	public abstract boolean enlist(ContainerTx var1) throws RemoteException;

	public abstract Object preInvoke(EJSDeployedSupport var1, ContainerTx var2) throws RemoteException;

	public abstract void postInvoke(int var1, EJSDeployedSupport var2) throws RemoteException;

	public void returnToPool() throws RemoteException {
		throw new UnsupportedOperationException();
	}

	public abstract void commit(ContainerTx var1) throws RemoteException;

	public abstract void rollback(ContainerTx var1) throws RemoteException;

	public abstract void store() throws RemoteException;

	public abstract void passivate() throws RemoteException;

	public abstract void remove() throws RemoteException, RemoveException;

	public abstract void discard();

	public abstract void beforeCompletion() throws RemoteException;

	public abstract boolean isRemoved();

	public abstract boolean isDestroyed();

	public abstract boolean isDiscarded();

	public abstract void invalidate();

	public abstract void checkTimerServiceAccess() throws IllegalStateException;

	@Deprecated
	public Identity getCallerIdentity() {
		EJSDeployedSupport s = EJSContainer.getMethodContext();
		if (s != null && s.methodInfo.ivInterface == MethodInterface.TIMED_OBJECT) {
			IllegalStateException ise = new IllegalStateException("getCallerIdentity() not allowed from ejbTimeout");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getCallerIdentity: " + ise);
			}

			throw ise;
		} else {
			EJBSecurityCollaborator<?> securityCollaborator = this.container.ivSecurityCollaborator;
			return securityCollaborator == null ? null : this.getCallerIdentity(securityCollaborator, s);
		}
	}

	@Deprecated
	private <T> Identity getCallerIdentity(EJBSecurityCollaborator<T> collaborator, EJSDeployedSupport s) {
		T uncheckedCookie = s == null ? null : s.securityCookie;
		return collaborator.getCallerIdentity(this.home.beanMetaData, s, uncheckedCookie);
	}

	public Principal getCallerPrincipal() {
		EJBSecurityCollaborator<?> securityCollaborator = this.container.ivSecurityCollaborator;
		return (Principal) (securityCollaborator == null
				? NullSecurityCollaborator.UNAUTHENTICATED
				: this.getCallerPrincipal(securityCollaborator, EJSContainer.getMethodContext()));
	}

	private <T> Principal getCallerPrincipal(EJBSecurityCollaborator<T> collaborator, EJSDeployedSupport s) {
		T uncheckedCookie = s == null ? null : s.securityCookie;
		return collaborator.getCallerPrincipal(this.home.beanMetaData, s, uncheckedCookie);
	}

	public EJBHome getEJBHome() {
		try {
			EJSWrapper wrapper = this.home.getWrapper().getRemoteWrapper();
			return (EJBHome) this.container.getEJBRuntime().getRemoteReference(wrapper,
					this.home.beanMetaData.homeInterfaceClass);
		} catch (IllegalStateException var3) {
			throw var3;
		} catch (Exception var4) {
			FFDCFilter.processException(var4, CLASS_NAME + ".getEJBHome", "522", this);
			ContainerEJBException ex2 = new ContainerEJBException("Failed to get the wrapper for home.", var4);
			Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var4, ex2.toString()});
			throw ex2;
		}
	}

	public EJBLocalHome getEJBLocalHome() {
		EJSWrapperCommon wCommon = null;

		try {
			wCommon = this.home.getWrapper();
		} catch (Exception var3) {
			FFDCFilter.processException(var3, CLASS_NAME + ".getEJBLocalHome", "547", this);
			Tr.warning(tc, "FAILED_TO_GET_WRAPPER_FOR_HOME_CNTR0002W", new Object[]{var3});
			return null;
		}

		return (EJBLocalHome) wCommon.getLocalObject();
	}

	@Deprecated
	public Properties getEnvironment() {
		return this.home.getEnvironment();
	}

	public synchronized UserTransaction getUserTransaction() {
		throw new IllegalStateException();
	}

	@Deprecated
	public boolean isCallerInRole(Identity id) {
		throw new UnsupportedOperationException();
	}

	public abstract boolean isCallerInRole(String var1);

	public boolean isCallerInRole(String roleName, Object bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCallerInRole, role = " + roleName + " EJB = " + bean);
		}

		EJBSecurityCollaborator<?> securityCollaborator = this.container.ivSecurityCollaborator;
		boolean inRole;
		if (securityCollaborator == null) {
			BeanMetaData bmd = this.home.beanMetaData;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"isCallerInRole called with security disabled for EJB module version = " + bmd.ivModuleVersion);
			}

			inRole = bmd.ivModuleVersion >= 30;
		} else {
			EJSDeployedSupport s = bean == null ? null : EJSContainer.getMethodContext();

			try {
				inRole = this.isCallerInRole(securityCollaborator, roleName, s);
			} catch (RuntimeException var8) {
				FFDCFilter.processException(var8, CLASS_NAME + ".isCallerInRole", "982", this);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "isCallerInRole collaborator throwing", var8);
				}

				throw var8;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isCallerInRole returning " + inRole);
		}

		return inRole;
	}

	private <T> boolean isCallerInRole(EJBSecurityCollaborator<T> collaborator, String roleName, EJSDeployedSupport s) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		String roleLink = null;
		BeanMetaData bmd = this.home.beanMetaData;
		if (bmd.ivRoleLinkMap != null) {
			String tempRoleLink = (String) this.home.beanMetaData.ivRoleLinkMap.get(roleName);
			if (!"".equals(tempRoleLink)) {
				roleLink = tempRoleLink;
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Role Link Found = " + tempRoleLink);
				}
			}
		}

		T uncheckedCookie = s == null ? null : s.securityCookie;
		return collaborator.isCallerInRole(bmd, s, uncheckedCookie, roleName, roleLink);
	}

	public boolean getRollbackOnly() {
		boolean rollbackOnly = false;
		ContainerTx tx = null;
		IllegalStateException ise = null;
		tx = this.container.getCurrentContainerTx();
		if (tx != null && tx.isTransactionGlobal()) {
			EJSDeployedSupport methodContext = EJSContainer.getMethodContext();
			if (methodContext != null) {
				EJBMethodInfoImpl methodInfo = methodContext.methodInfo;
				if (methodInfo.getTransactionAttribute() == TransactionAttribute.TX_SUPPORTS) {
					ise = new IllegalStateException("getRollbackOnly can not be called from a TX SUPPORTS method");
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "getRollbackOnly: " + ise);
					}

					throw ise;
				}
			}

			rollbackOnly = tx.getRollbackOnly() || tx.getGlobalRollbackOnly();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getRollbackOnly: " + rollbackOnly + ": " + this);
			}

			return rollbackOnly;
		} else {
			ise = new IllegalStateException("getRollbackOnly can not be called without a Transaction Context");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getRollbackOnly: " + ise);
			}

			throw ise;
		}
	}

	public void setRollbackOnly() {
		ContainerTx tx = null;
		IllegalStateException ise = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setRollbackOnly: " + this);
		}

		tx = this.container.getCurrentContainerTx();
		if (tx != null && tx.isTransactionGlobal()) {
			EJSDeployedSupport methodContext = EJSContainer.getMethodContext();
			if (methodContext != null) {
				EJBMethodInfoImpl methodInfo = methodContext.methodInfo;
				if (methodInfo.getTransactionAttribute() == TransactionAttribute.TX_SUPPORTS) {
					ise = new IllegalStateException("setRollbackOnly can not be called from a TX SUPPORTS method");
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "setRollbackOnly: " + ise);
					}

					throw ise;
				}

				if (tx.beganInThisScope()) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "setRollbackOnly called by beginner");
					}

					methodContext.ivBeginnerSetRollbackOnly = true;
				}
			}

			tx.setRollbackOnly();
		} else {
			ise = new IllegalStateException("setRollbackOnly can not be called without a Transaction Context");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "setRollbackOnly: " + ise);
			}

			throw ise;
		}
	}

	public TimerService getTimerService() throws IllegalStateException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			if (this.home.beanMetaData.timedMethodInfos == null) {
				Tr.debug(tc, "getTimerService: ***** Does not have timers *****");
			}

			Tr.debug(tc, "getTimerService: " + this);
		}

		return this;
	}

	public Object lookup(String name) {
		if (name == null) {
			throw new IllegalArgumentException("null 'name' parameter.");
		} else {
			Object result = null;
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "lookup: " + name);
			}

			String lookupName = name;
			if (name.startsWith("java:comp/env/")) {
				lookupName = name.substring(14);
			}

			InjectionBinding<?> binding = (InjectionBinding) this.home.beanMetaData.ivJavaColonCompEnvMap
					.get(lookupName);
			if (binding != null) {
				try {
					result = binding.getInjectionObject();
				} catch (InjectionException var8) {
					FFDCFilter.processException(var8, CLASS_NAME + ".lookup", "1342", this);
					IllegalArgumentException iae = new IllegalArgumentException("Failure occurred obtaining object for "
							+ name + " reference defined for " + this.home.beanMetaData.j2eeName, var8);
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "lookup: " + iae);
					}

					throw iae;
				}
			} else {
				result = this.container.getEJBRuntime().javaColonLookup(name, this.home);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "lookup: " + result.getClass().getName());
			}

			return result;
		}
	}

	public Map<String, Object> getContextData() {
		return EJSContainer.getThreadData().getContextData();
	}

	public Timer createTimer(long duration, Serializable info)
			throws IllegalArgumentException, IllegalStateException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createTimer: " + duration + ": " + info, this);
		}

		if (!this.home.beanMetaData.isTimedObject) {
			IllegalStateException ise = new IllegalStateException(
					"Timer Service: Bean does not implement TimedObject: " + this.beanId);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "createTimer: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			if (duration < 0L) {
				IllegalArgumentException iae = new IllegalArgumentException(
						"TimerService: duration not a valid value: " + duration);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "createTimer: " + iae);
				}

				throw iae;
			} else {
				long current = System.currentTimeMillis();
				Date expiration = new Date(current + duration);
				Timer timer = this.container.getEJBRuntime().createTimer(this, expiration, -1L,
						(ScheduleExpression) null, info, true);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createTimer: " + timer);
				}

				return timer;
			}
		}
	}

	public Timer createTimer(long initialDuration, long intervalDuration, Serializable info)
			throws IllegalArgumentException, IllegalStateException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createTimer: " + initialDuration + ", " + intervalDuration + ": " + info, this);
		}

		if (!this.home.beanMetaData.isTimedObject) {
			IllegalStateException ise = new IllegalStateException(
					"Timer Service: Bean does not implement TimedObject: " + this.beanId);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "createTimer: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			IllegalArgumentException iae = null;
			if (initialDuration < 0L) {
				iae = new IllegalArgumentException(
						"TimerService: initialDuration not a valid value: " + initialDuration);
			} else if (intervalDuration < 0L) {
				iae = new IllegalArgumentException(
						"TimerService: intervalDuration not a valid value: " + intervalDuration);
			}

			if (iae != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "createTimer: " + iae);
				}

				throw iae;
			} else {
				long current = System.currentTimeMillis();
				Date expiration = new Date(current + initialDuration);
				Timer timer = this.container.getEJBRuntime().createTimer(this, expiration, intervalDuration,
						(ScheduleExpression) null, info, true);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createTimer: " + timer);
				}

				return timer;
			}
		}
	}

	public Timer createTimer(Date expiration, Serializable info)
			throws IllegalArgumentException, IllegalStateException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createTimer: " + expiration + ": " + info, this);
		}

		if (!this.home.beanMetaData.isTimedObject) {
			IllegalStateException ise = new IllegalStateException(
					"Timer Service: Bean does not implement TimedObject: " + this.beanId);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "createTimer: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			if (expiration != null && expiration.getTime() >= 0L) {
				Timer timer = this.container.getEJBRuntime().createTimer(this, expiration, -1L,
						(ScheduleExpression) null, info, true);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createTimer: " + timer);
				}

				return timer;
			} else {
				IllegalArgumentException iae = new IllegalArgumentException(
						"TimerService: expiration not a valid value: " + expiration);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "createTimer: " + iae);
				}

				throw iae;
			}
		}
	}

	public Timer createTimer(Date initialExpiration, long intervalDuration, Serializable info)
			throws IllegalArgumentException, IllegalStateException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createTimer: " + initialExpiration + ", " + intervalDuration + ": " + info, this);
		}

		if (!this.home.beanMetaData.isTimedObject) {
			IllegalStateException ise = new IllegalStateException(
					"Timer Service: Bean does not implement TimedObject: " + this.beanId);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "createTimer: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			IllegalArgumentException iae = null;
			if (initialExpiration != null && initialExpiration.getTime() >= 0L) {
				if (intervalDuration < 0L) {
					iae = new IllegalArgumentException(
							"TimerService: intervalDuration not a valid value: " + intervalDuration);
				}
			} else {
				iae = new IllegalArgumentException(
						"TimerService: initialExpiration not a valid value: " + initialExpiration);
			}

			if (iae != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "createTimer: " + iae);
				}

				throw iae;
			} else {
				Timer timer = this.container.getEJBRuntime().createTimer(this, initialExpiration, intervalDuration,
						(ScheduleExpression) null, info, true);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createTimer: " + timer);
				}

				return timer;
			}
		}
	}

	public Collection<Timer> getTimers() throws IllegalStateException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getTimers: " + this);
		}

		if (this.home.beanMetaData.timedMethodInfos == null) {
			IllegalStateException ise = new IllegalStateException(
					"Timer Service: Bean does not have timers: " + this.beanId);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "getTimers: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			Collection<Timer> timers = this.container.getEJBRuntime().getTimers(this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getTimers: " + timers);
			}

			return timers;
		}
	}

	public Collection<Timer> getAllTimers() throws IllegalStateException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAllTimers: " + this);
		}

		this.checkTimerServiceAccess();
		Collection<Timer> timers = this.container.getEJBRuntime()
				.getAllTimers(this.beanId.getBeanMetaData()._moduleMetaData);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getAllTimers: " + timers);
		}

		return timers;
	}

	@Deprecated
	public void flush() throws RemoteException {
		this.container.flush();
	}

	public void flushCache() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "flushCache : " + this);
		}

		IllegalStateException ise = null;
		ContainerTx tx = this.container.getCurrentContainerTx();

		try {
			if (tx == null) {
				ise = new IllegalStateException("flushCache can not be called without a Transaction Context");
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "flushCache : " + ise);
				}

				throw ise;
			} else if (tx.getGlobalRollbackOnly()) {
				ise = new IllegalStateException("flushCache can not be called with transaction marked rollback only");
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "flushCache : " + ise);
				}

				throw ise;
			} else {
				tx.flush();
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "flushCache : successful");
				}

			}
		} catch (Throwable var6) {
			FFDCFilter.processException(var6, CLASS_NAME + ".flushCache", "1708", this);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "flushCache : " + var6);
			}

			if (tx != null) {
				tx.setRollbackOnly();
			}

			EJBException ejbex = ExceptionUtil.EJBException(var6);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "flushCache : " + ejbex);
			}

			throw ejbex;
		}
	}

	public boolean isTransactionGlobal() {
		ContainerTx tx = this.container.getCurrentContainerTx();
		boolean isGlobal = tx == null ? false : tx.isTransactionGlobal();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isTransactionGlobal : " + isGlobal);
		}

		return isGlobal;
	}

	public <T> T getInjectionTargetContextData(Class<T> data) {
		return data.isAssignableFrom(this.getClass()) ? data.cast(this) : null;
	}

	InjectionEngine getInjectionEngine() {
		return this.container.getEJBRuntime().getInjectionEngine();
	}

	HandleList getHandleList(boolean create) {
		if (this.connectionHandleList == null && create) {
			this.connectionHandleList = new HandleList();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getHandleList: created " + this.connectionHandleList);
			}
		}

		return this.connectionHandleList;
	}

	HandleListInterface reAssociateHandleList() throws CSIException {
		Object hl;
		if (this.connectionHandleList == null) {
			hl = HandleListProxy.INSTANCE;
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "reAssociateHandleList: " + this.connectionHandleList);
			}

			hl = this.connectionHandleList;

			try {
				((HandleListInterface) hl).reAssociate();
			} catch (Exception var3) {
				throw new CSIException("", var3);
			}
		}

		return (HandleListInterface) hl;
	}

	void parkHandleList() {
		if (this.connectionHandleList != null) {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "parkHandleList: " + this.connectionHandleList);
			}

			try {
				this.connectionHandleList.parkHandle();
			} catch (Exception var3) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "parkHandleList: exception", var3);
				}
			}
		}

	}

	protected final void destroyHandleList() {
		if (this.connectionHandleList != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "destroyHandleList: destroying " + this.connectionHandleList);
			}

			this.connectionHandleList.componentDestroyed();
			this.connectionHandleList = null;
		}

	}

	public synchronized int getState() {
		return this.state;
	}

	public abstract void ensurePersistentState(ContainerTx var1) throws RemoteException;

	protected BeanOCallDispatchToken callDispatchEventListeners(int dispatchEventCode, BeanOCallDispatchToken token) {
		DispatchEventListenerManager dispatchEventListenerManager = this.container.ivDispatchEventListenerManager;
		DispatchEventListenerCookie[] dispatchEventListenerCookies = null;
		EJBMethodMetaData methodMetaData = null;
		BeanOCallDispatchToken retToken = null;
		boolean doBeforeDispatch = false;
		boolean doAfterDispatch = false;
		if (dispatchEventListenerManager != null && dispatchEventListenerManager.dispatchEventListenersAreActive()) {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "callDispatchEventListeners: " + dispatchEventCode + ", " + this);
			}

			if (dispatchEventCode != 2 && dispatchEventCode != 4 && dispatchEventCode != 8 && dispatchEventCode != 10) {
				if (dispatchEventCode == 3 || dispatchEventCode == 5 || dispatchEventCode == 9
						|| dispatchEventCode == 11) {
					methodMetaData = token.getMethodMetaData();
					doAfterDispatch = token.getDoAfterDispatch();
					dispatchEventListenerCookies = token.getDispatchEventListenerCookies();
				}
			} else {
				methodMetaData = this.buildTempEJBMethodMetaData(dispatchEventCode, this.home.getBeanMetaData());
				retToken = new BeanOCallDispatchToken();
				retToken.setMethodMetaData(methodMetaData);
				EJSDeployedSupport s = EJSContainer.getMethodContext();
				if (s != null && s.beanO == this) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "using dispatch context from method context");
					}

					dispatchEventListenerCookies = s.ivDispatchEventListenerCookies;
				}

				if (dispatchEventListenerCookies == null) {
					dispatchEventListenerCookies = dispatchEventListenerManager
							.getNewDispatchEventListenerCookieArray();
					doBeforeDispatch = true;
					retToken.setDoAfterDispatch(true);
				}

				retToken.setDispatchEventListenerCookies(dispatchEventListenerCookies);
			}

			if (doBeforeDispatch) {
				dispatchEventListenerManager.callDispatchEventListeners(1, dispatchEventListenerCookies,
						methodMetaData);
			}

			dispatchEventListenerManager.callDispatchEventListeners(dispatchEventCode, dispatchEventListenerCookies,
					methodMetaData);
			if (doAfterDispatch) {
				dispatchEventListenerManager.callDispatchEventListeners(12, dispatchEventListenerCookies,
						methodMetaData);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "callDispatchEventListeners", retToken);
			}
		}

		return retToken;
	}

	private EJBMethodMetaData buildTempEJBMethodMetaData(int dispatchEventCode, BeanMetaData bmd) {
		String methName = "";
		String methSig = "";
		switch (dispatchEventCode) {
			case 2 :
				methName = "ejbActivate";
				methSig = "ejbActivate:";
				break;
			case 3 :
			case 5 :
			case 6 :
			case 7 :
			case 9 :
			default :
				Tr.error(tc, "Unsupported dispatchEventCode code passed to buildTempEJBMethodInfo - code = "
						+ dispatchEventCode);
				break;
			case 4 :
				methName = "ejbLoad";
				methSig = "ejbLoad:";
				break;
			case 8 :
				methName = "ejbStore";
				methSig = "ejbStore:";
				break;
			case 10 :
				methName = "ejbPassivate";
				methSig = "ejbPassivate:";
		}

		EJBMethodInfoImpl methodInfo = bmd
				.createEJBMethodInfoImpl(bmd.container.getEJBRuntime().getMetaDataSlotSize(MethodMetaData.class));
		methodInfo.initializeInstanceData(methSig, methName, bmd, MethodInterface.REMOTE,
				TransactionAttribute.TX_NOT_SUPPORTED, false);
		methodInfo.setMethodDescriptor("");
		return methodInfo;
	}

	public Timer createCalendarTimer(ScheduleExpression schedule) {
		return this.createCalendarTimer(schedule, (TimerConfig) null);
	}

	public Timer createCalendarTimer(ScheduleExpression schedule, TimerConfig timerConfig) {
		Serializable info = timerConfig == null ? null : timerConfig.getInfo();
		boolean persistent = timerConfig == null || timerConfig.isPersistent();
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createCalendarTimer: " + persistent, this);
		}

		IllegalStateException ise;
		if (!this.home.beanMetaData.isTimedObject) {
			ise = new IllegalStateException("Timer Service: Bean does not implement TimedObject: " + this.beanId);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createCalendarTimer: " + ise);
			}

			throw ise;
		} else if (this.home.beanMetaData.isEntityBean()) {
			ise = new IllegalStateException(
					"Timer Service: Entity beans cannot use calendar-based timers: " + this.beanId);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createCalendarTimer: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			if (schedule == null) {
				IllegalArgumentException ise = new IllegalArgumentException(
						"TimerService: schedule not a valid value: null");
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createCalendarTimer: " + ise);
				}

				throw ise;
			} else {
				Timer timer = this.container.getEJBRuntime().createTimer(this, (Date) null, -1L, schedule, info,
						persistent);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createCalendarTimer: " + timer);
				}

				return timer;
			}
		}
	}

	public Timer createIntervalTimer(Date initialExpiration, long intervalDuration, TimerConfig timerConfig)
			throws IllegalArgumentException, IllegalStateException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		boolean persistent = timerConfig == null ? true : timerConfig.isPersistent();
		Serializable info = timerConfig == null ? (Serializable) null : timerConfig.getInfo();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createIntervalTimer: " + initialExpiration + ", " + intervalDuration + ": " + info + ", "
					+ persistent, this);
		}

		if (!this.home.beanMetaData.isTimedObject) {
			IllegalStateException ise = new IllegalStateException(
					"Timer Service: Bean does not implement TimedObject: " + this.beanId);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "createIntervalTimer: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			IllegalArgumentException iae = null;
			if (initialExpiration != null && initialExpiration.getTime() >= 0L) {
				if (intervalDuration < 0L) {
					iae = new IllegalArgumentException(
							"TimerService: intervalDuration not a valid value: " + intervalDuration);
				}
			} else {
				iae = new IllegalArgumentException(
						"TimerService: initialExpiration not a valid value: " + initialExpiration);
			}

			if (iae != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "createIntervalTimer: " + iae);
				}

				throw iae;
			} else {
				Timer timer = this.container.getEJBRuntime().createTimer(this, initialExpiration, intervalDuration,
						(ScheduleExpression) null, info, persistent);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createIntervalTimer: " + timer);
				}

				return timer;
			}
		}
	}

	public Timer createIntervalTimer(long initialDuration, long intervalDuration, TimerConfig timerConfig)
			throws IllegalArgumentException, IllegalStateException, EJBException {
		boolean persistent = timerConfig == null ? true : timerConfig.isPersistent();
		Serializable info = timerConfig == null ? (Serializable) null : timerConfig.getInfo();
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createIntervalTimer: " + initialDuration + ", " + intervalDuration + ": " + info, this);
		}

		if (!this.home.beanMetaData.isTimedObject) {
			IllegalStateException ise = new IllegalStateException(
					"Timer Service: Bean does not implement TimedObject: " + this.beanId);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "createIntervalTimer: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			IllegalArgumentException iae = null;
			if (initialDuration < 0L) {
				iae = new IllegalArgumentException(
						"TimerService: initialDuration not a valid value: " + initialDuration);
			} else if (intervalDuration < 0L) {
				iae = new IllegalArgumentException(
						"TimerService: intervalDuration not a valid value: " + intervalDuration);
			}

			if (iae != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "createIntervalTimer: " + iae);
				}

				throw iae;
			} else {
				long current = System.currentTimeMillis();
				Date expiration = new Date(current + initialDuration);
				Timer timer = this.container.getEJBRuntime().createTimer(this, expiration, intervalDuration,
						(ScheduleExpression) null, info, persistent);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createIntervalTimer: " + timer);
				}

				return timer;
			}
		}
	}

	public Timer createSingleActionTimer(Date expiration, TimerConfig timerConfig)
			throws IllegalArgumentException, IllegalStateException, EJBException {
		boolean persistent = timerConfig == null ? true : timerConfig.isPersistent();
		Serializable info = timerConfig == null ? (Serializable) null : timerConfig.getInfo();
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createSingleActionTimer: " + expiration + ": " + info, this);
		}

		if (!this.home.beanMetaData.isTimedObject) {
			IllegalStateException ise = new IllegalStateException(
					"Timer Service: Bean does not implement TimedObject: " + this.beanId);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "createTimer: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			if (expiration != null && expiration.getTime() >= 0L) {
				Timer timer = this.container.getEJBRuntime().createTimer(this, expiration, -1L,
						(ScheduleExpression) null, info, persistent);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createSingleActionTimer: " + timer);
				}

				return timer;
			} else {
				IllegalArgumentException iae = new IllegalArgumentException(
						"TimerService: expiration not a valid value: " + expiration);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "createTimer: " + iae);
				}

				throw iae;
			}
		}
	}

	public Timer createSingleActionTimer(long duration, TimerConfig timerConfig)
			throws IllegalArgumentException, IllegalStateException, EJBException {
		boolean persistent = timerConfig == null ? true : timerConfig.isPersistent();
		Serializable info = timerConfig == null ? (Serializable) null : timerConfig.getInfo();
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createSingleActionTimer: " + duration + ": " + info, this);
		}

		if (!this.home.beanMetaData.isTimedObject) {
			IllegalStateException ise = new IllegalStateException(
					"Timer Service: Bean does not implement TimedObject: " + this.beanId);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "createTimer: " + ise);
			}

			throw ise;
		} else {
			this.checkTimerServiceAccess();
			if (duration < 0L) {
				IllegalArgumentException iae = new IllegalArgumentException(
						"TimerService: duration not a valid value: " + duration);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "createTimer: " + iae);
				}

				throw iae;
			} else {
				long current = System.currentTimeMillis();
				Date expiration = new Date(current + duration);
				Timer timer = this.container.getEJBRuntime().createTimer(this, expiration, -1L,
						(ScheduleExpression) null, info, persistent);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createSingleActionTimer: " + timer);
				}

				return timer;
			}
		}
	}
}