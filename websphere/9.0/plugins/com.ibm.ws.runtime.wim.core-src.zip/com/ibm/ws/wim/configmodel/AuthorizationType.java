package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface AuthorizationType {
	List getAttributeGroups();

	AttributeGroupType[] getAttributeGroupsAsArray();

	AttributeGroupType createAttributeGroups();

	String getDefaultAttributeGroup();

	void setDefaultAttributeGroup(String var1);

	boolean isImportPolicyFromFile();

	void setImportPolicyFromFile(boolean var1);

	void unsetImportPolicyFromFile();

	boolean isSetImportPolicyFromFile();

	boolean isIsAttributeGroupingEnabled();

	void setIsAttributeGroupingEnabled(boolean var1);

	void unsetIsAttributeGroupingEnabled();

	boolean isSetIsAttributeGroupingEnabled();

	boolean isIsSecurityEnabled();

	void setIsSecurityEnabled(boolean var1);

	void unsetIsSecurityEnabled();

	boolean isSetIsSecurityEnabled();

	String getJaccPolicyClass();

	void setJaccPolicyClass(String var1);

	String getJaccPolicyConfigFactoryClass();

	void setJaccPolicyConfigFactoryClass(String var1);

	String getJaccPrincipalToRolePolicyFileName();

	void setJaccPrincipalToRolePolicyFileName(String var1);

	String getJaccPrincipalToRolePolicyId();

	void setJaccPrincipalToRolePolicyId(String var1);

	String getJaccRoleMappingClass();

	void setJaccRoleMappingClass(String var1);

	String getJaccRoleMappingConfigFactoryClass();

	void setJaccRoleMappingConfigFactoryClass(String var1);

	String getJaccRoleToPermissionPolicyFileName();

	void setJaccRoleToPermissionPolicyFileName(String var1);

	String getJaccRoleToPermissionPolicyId();

	void setJaccRoleToPermissionPolicyId(String var1);

	boolean isUseSystemJACCProvider();

	void setUseSystemJACCProvider(boolean var1);

	void unsetUseSystemJACCProvider();

	boolean isSetUseSystemJACCProvider();
}