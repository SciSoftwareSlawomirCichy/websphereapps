package com.ibm.ws.ffdc.impl;

import com.ibm.ws.exception.WsException;
import com.ibm.ws.ffdc.FFDC;
import java.io.File;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FFDCJanitor {
	private static FFDCJanitor instance = new FFDCJanitor();
	private long timeOfTheDayForCleanup;
	private int daysBetweenCleanups;
	private long timeOfNextCleanup;
	private long maximumFileAge;
	private Object synchronizationGuard = new Object();
	private static final String classname = FFDCJanitor.class.getName();
	private static final Logger logger;
	private boolean firstCleanCheck = true;
	private boolean configured = false;

	public static FFDCJanitor getInstance() {
		return instance;
	}

	public void doCleanupIfNeeded() {
		logger.entering(classname, "doCleanupIfNeeded");
		if (!this.configured) {
			logger.exiting(classname, "doCleanupIfNeeded", "not configured - no-op");
		} else {
			boolean cleanupNeeded = false;
			long currentTime = System.currentTimeMillis();
			if (logger.isLoggable(Level.FINE)) {
				if (this.firstCleanCheck) {
					logger.logp(Level.FINE, classname, "doCleanupIfNeeded", "first clean will be performed");
				} else {
					logger.logp(Level.FINE, classname, "doCleanupIfNeeded",
							"TimeOfNext: " + new Date(this.timeOfNextCleanup) + "  cur: " + new Date(currentTime));
				}
			}

			Object incidentFilesToDelete = this.synchronizationGuard;
			synchronized (this.synchronizationGuard) {
				if (this.timeOfNextCleanup <= currentTime) {
					cleanupNeeded = true;
					this.setNextCleanupTime(currentTime);
				}
			}

			if (cleanupNeeded || this.firstCleanCheck) {
				cleanupNeeded = false;
				this.firstCleanCheck = false;
				incidentFilesToDelete = null;
				File[] summaryFiilesToDelete = null;
				FFDCExceptionFileFilter filter = new FFDCExceptionFileFilter();
				filter.setFileSelectionAttributes((String) null, (String) null, FFDC.getExceptionFileExtension(),
						(String) null, -1L, currentTime - this.maximumFileAge);

				File[] incidentFilesToDelete;
				try {
					incidentFilesToDelete = FFDCHelper.listFiles(new File(FFDCHelper.getDefaultLoggingDirectory()),
							filter);
					filter.setFileSelectionAttributes((String) null, (String) null, ".log", (String) null, -1L,
							currentTime - this.maximumFileAge);
					summaryFiilesToDelete = FFDCHelper.listFiles(new File(FFDCHelper.getDefaultLoggingDirectory()),
							filter);
				} catch (WsException var10) {
					incidentFilesToDelete = null;
					summaryFiilesToDelete = null;
					logger.logp(Level.WARNING, classname, "doCleanupIfNeeded",
							"MSG_FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST", var10);
				}

				File[] filesToBeDeleted = null;
				if (incidentFilesToDelete == null && summaryFiilesToDelete == null) {
					filesToBeDeleted = null;
				} else if (incidentFilesToDelete == null) {
					filesToBeDeleted = summaryFiilesToDelete;
				} else if (summaryFiilesToDelete == null) {
					filesToBeDeleted = incidentFilesToDelete;
				} else {
					filesToBeDeleted = new File[incidentFilesToDelete.length + summaryFiilesToDelete.length];
					System.arraycopy(incidentFilesToDelete, 0, filesToBeDeleted, 0, incidentFilesToDelete.length);
					System.arraycopy(summaryFiilesToDelete, 0, filesToBeDeleted, incidentFilesToDelete.length,
							summaryFiilesToDelete.length);
				}

				if (logger.isLoggable(Level.FINE)) {
					logger.logp(Level.FINE, classname, "doCleanupIfNeeded", "IncidentFiles: "
							+ (incidentFilesToDelete == null ? 0 : incidentFilesToDelete.length) + " SummaryFiles: "
							+ (summaryFiilesToDelete == null ? 0 : summaryFiilesToDelete.length) + " to delete");
				}

				if (filesToBeDeleted != null && filesToBeDeleted.length > 0) {
					logger.logp(Level.FINE, classname, "doCleanupIfNeeded",
							"Entering loop to delete: " + filesToBeDeleted.length + " files.");
					int deletedCounter = 0;

					for (int i = 0; i < filesToBeDeleted.length; ++i) {
						logger.logp(Level.FINE, classname, "doCleanupIfNeeded",
								"Attempting to delete file " + filesToBeDeleted[i].getName());
						if (FFDCHelper.deleteFile(filesToBeDeleted[i])) {
							++deletedCounter;
							logger.logp(Level.FINE, classname, "doCleanupIfNeeded",
									"Deleted file " + filesToBeDeleted[i].getName());
						} else if (filesToBeDeleted[i].exists()) {
							logger.logp(Level.INFO, classname, "doCleanupIfNeeded", "FFDCJANITOR_FAILED_TO_DELETE_FILE",
									new Object[]{filesToBeDeleted[i].getName()});
						}
					}

					logger.logp(Level.INFO, classname, "doCleanupIfNeeded", "FFDCJANITOR_DELETED_FILES",
							new Object[]{new Integer(deletedCounter), new Integer(filesToBeDeleted.length)});
				}
			}

			logger.exiting(classname, "doCleanupIfNeeded");
		}
	}

	void setTimeForCleanup(long timeOfDay) {
		this.timeOfTheDayForCleanup = timeOfDay >= 0L && timeOfDay < 86400000L ? timeOfDay : 0L;
		long currentTime = System.currentTimeMillis();
		Object var5 = this.synchronizationGuard;
		synchronized (this.synchronizationGuard) {
			this.setNextCleanupTime(currentTime);
		}

		this.configured = true;
		if (logger.isLoggable(Level.FINE)) {
			logger.logp(Level.FINE, classname, "setTimeForCleanup",
					"Configured to do cleanup every " + this.daysBetweenCleanups + " day(s), at " + timeOfDay / 3600000L
							+ ":" + (timeOfDay - 3600000L * (timeOfDay / 3600000L)) / 60000L + ", when files reach "
							+ this.maximumFileAge + "ms of age.");
		}

	}

	public void configure(Configure cfg) {
		this.daysBetweenCleanups = cfg.daysBetweenExceptionFilesCleanup;
		this.maximumFileAge = cfg.exceptionFileMaximumAge;
		if (cfg.timeOfTheDayForCleanup > 0L) {
			this.setTimeForCleanup(cfg.timeOfTheDayForCleanup);
		} else if (!this.configured) {
			Random rnd = new Random();
			this.setTimeForCleanup((long) (rnd.nextInt(1440) * 60 * 1000));
		}

	}

	private void setNextCleanupTime(long currentTime) {
		int offset = TimeZone.getDefault().getOffset(currentTime);
		this.timeOfNextCleanup = ((currentTime + (long) offset) / 86400000L
				+ (long) (this.configured ? this.daysBetweenCleanups : 0)) * 86400000L + this.timeOfTheDayForCleanup
				- (long) offset;
		if (logger.isLoggable(Level.FINE)) {
			logger.logp(Level.FINE, classname, "setNextCleanupTime",
					"Next clean up set for " + (new Date(this.timeOfNextCleanup)).toString());
		}

	}

	static {
		logger = Logger.getLogger(classname, "com.ibm.ws.ffdc.resources.FFDCMessages");
	}
}