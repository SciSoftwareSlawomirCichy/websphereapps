package com.google.common.hash;

import com.google.common.base.Preconditions;
import com.google.common.hash.AbstractNonStreamingHashFunction.BufferingHasher;
import com.google.errorprone.annotations.Immutable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;

@Immutable
abstract class AbstractNonStreamingHashFunction extends AbstractHashFunction {
	public Hasher newHasher() {
		return this.newHasher(32);
	}

	public Hasher newHasher(int expectedInputSize) {
		Preconditions.checkArgument(expectedInputSize >= 0);
		return new BufferingHasher(this, expectedInputSize);
	}

	public HashCode hashInt(int input) {
		return this.hashBytes(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(input).array());
	}

	public HashCode hashLong(long input) {
		return this.hashBytes(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(input).array());
	}

	public HashCode hashUnencodedChars(CharSequence input) {
		int len = input.length();
		ByteBuffer buffer = ByteBuffer.allocate(len * 2).order(ByteOrder.LITTLE_ENDIAN);

		for (int i = 0; i < len; ++i) {
			buffer.putChar(input.charAt(i));
		}

		return this.hashBytes(buffer.array());
	}

	public HashCode hashString(CharSequence input, Charset charset) {
		return this.hashBytes(input.toString().getBytes(charset));
	}

	public abstract HashCode hashBytes(byte[] var1, int var2, int var3);

	public HashCode hashBytes(ByteBuffer input) {
		return this.newHasher(input.remaining()).putBytes(input).hash();
	}
}