package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InvalidPropertyValueException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.ws.security.util.ConfigUtils;
import com.ibm.ws.wim.EnvironmentManager;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.ldap.LdapConnectionBase;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.DataAccessObject;
import com.ibm.ws.wim.env.IEncryptionUtil;
import com.sun.jndi.ldap.LdapName;
import commonj.sdo.Property;
import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.AuthenticationException;
import javax.naming.InvalidNameException;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InvalidSearchFilterException;
import javax.naming.directory.SearchControls;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;

public class ConfigValidator implements ConfigConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final String WIM_CONFIG_VALIDATION = "wim.config.validation";
	protected static final String[] DB_CONNECTION_PARAMS;
	protected static final String[] LDAP_CONNECTION_PARAMS;

	public static void validateRepositoryParams(String var0, String var1, Map var2) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateRepositoryParams",
					"id=" + var0 + ", type=" + var1 + ", params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		if (validateConfig()) {
			if (!var0.contains("<") && !var0.contains("&") && !var0.contains(">") && !var0.contains("\"")
					&& !var0.contains("'")) {
				validateLoginProperties((List) var2.get("loginProperties"));
				String var4 = (String) var2.get("adapterClassName");
				if (var4 != null) {
					try {
						Class.forName(var4);
					} catch (ClassNotFoundException var9) {
						ClassLoader var6 = Thread.currentThread().getContextClassLoader();
						if (var6 == null) {
							var6 = ConfigValidator.class.getClassLoader();
						}

						try {
							Class.forName(var4, true, var6);
						} catch (ClassNotFoundException var8) {
							throw new WIMConfigurationException("MISSING_OR_INVALID_ADAPTER_CLASS_NAME",
									WIMMessageHelper.generateMsgParms(var4), CLASSNAME, "validateRepositoryParams",
									var9);
						}
					}
				}

				if (!"DatabaseRepositoryType".equals(var1) && !"propertyExtensionRepository".equals(var1)
						&& !"entryMappingRepository".equals(var1)) {
					if ("FileRepositoryType".equals(var1)) {
						validateFileParams(var0, var2);
					} else if ("LdapRepositoryType".equals(var1)) {
						validateLDAPParams(var0, var2);
					} else if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateRepositoryParams",
								"No Validation performed for repository type=" + var1);
					}
				} else {
					validateDBParams(var0, var2);
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "validateRepositoryParams");
				}

			} else {
				throw new WIMConfigurationException("INVALID_REPOSITORY_ID", WIMMessageHelper.generateMsgParms(var0),
						CLASSNAME, "validateRepositoryParams");
			}
		}
	}

	public static void validateDBParams(String var0, Map var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateDBParams",
					"id=" + var0 + ", params=" + WIMTraceHelper.printMapWithoutPassword(var1));
		}

		if (validateConfig()) {
			boolean var3 = false;
			boolean var4 = false;
			String var5 = (String) var1.get("databaseType");
			validateSupportedDBType(var5);
			String var6 = (String) var1.get("dataSourceName");
			String var7 = (String) var1.get("dbURL");
			String var8 = (String) var1.get("dbAdminId");
			String var9 = (String) var1.get("dbAdminPassword");
			String var10 = (String) var1.get("JDBCDriverClass");
			String var11 = (String) var1.get("dbSchema");
			if (var5 != null && var6 != null && var7 != null) {
				try {
					if (var9 != null) {
						IEncryptionUtil var12 = FactoryManager.getEncryptionUtil();
						var9 = var12.decode(var9);
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateDBParams", "connecting to DB.");
					}

					DataAccessObject var17 = DAOHelper.getNewDAOClass(var5, var6, var7, var11, var8, var9, var10);
					if (var17.dsLookup() != null) {
						var3 = true;
						trcLogger.logp(Level.FINER, CLASSNAME, "validateDBParams", "the datasource was found: " + var6);
					} else {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateDBParams",
								"the datasource was NOT found: " + var6);
					}

					Connection var19 = var17.getDirectAccessConnection();
					trcLogger.logp(Level.FINER, CLASSNAME, "validateDBParams",
							"connected to DB using direct connection.");
					if (!"db2zos".equals(var5) && !"db2iseries".equals(var5)) {
						if (var11 != null && !var11.trim().equals("")) {
							var4 = var17.isValidSchema(var11);
						}
					} else {
						var4 = true;
					}

					try {
						var17.closeConnection(var19);
					} catch (Exception var15) {
						trcLogger.logp(Level.FINE, CLASSNAME, "validateDBParams",
								"Error closing the DB direct connection:" + var15.getMessage(), var15);
					}
				} catch (WIMException var16) {
					Object var13;
					for (var13 = var16; ((Throwable) var13).getCause() != null; var13 = ((Throwable) var13)
							.getCause()) {
						;
					}

					throw new WIMConfigurationException(
							"REPOSITORY_CONNECTION_FAILED", WIMMessageHelper.generateMsgParms(var7,
									WIMTraceHelper.printMapWithoutPassword(var1), var13.getClass().getName()),
							CLASSNAME, "validateDBParams", var16);
				}

				if (var11 != null && !var11.trim().equals("") && !var4) {
					throw new WIMConfigurationException("DBSCHEMA_NOT_AVAILABLE",
							WIMMessageHelper.generateMsgParms(var11), CLASSNAME, "validateDBParams");
				}

				if (!var3 && EnvironmentManager.singleton().isAminServiceAvailable()) {
					InvalidPropertyValueException var18 = new InvalidPropertyValueException("INVALID_PARAMETER_VALUE",
							WIMMessageHelper.generateMsgParms("dataSourceName"), Level.SEVERE, CLASSNAME,
							"validateDBParams");
					trcLogger.logp(Level.FINE, CLASSNAME, "validateDBParams", "DataSource is not found in server mode");
					throw new WIMConfigurationException(
							"REPOSITORY_CONNECTION_FAILED", WIMMessageHelper.generateMsgParms(var7,
									WIMTraceHelper.printMapWithoutPassword(var1), var18.getClass().getName()),
							CLASSNAME, "validateDBParams");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateDBParams");
			}

		}
	}

	public static void validateSupportedDBType(String var0) throws WIMConfigurationException {
		if (validateConfig()) {
			if (var0 != null) {
				ValidationHelper.validateParam("databaseType", var0, CONFIG_DB_SUPPORTED_TYPES);
			}

		}
	}

	public static void validateFileParams(String var0, Map var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateFileParams", "id=" + var0 + ", params=" + var1);
		}

		if (validateConfig()) {
			String var3 = (String) var1.get("messageDigestAlgorithm");
			if (var3 != null) {
				try {
					MessageDigest var4 = MessageDigest.getInstance(var3);
				} catch (NoSuchAlgorithmException var5) {
					throw new WIMConfigurationException("CONFIG_VALUE_NOT_VALID",
							WIMMessageHelper.generateMsgParms(var3, "messageDigestAlgorithm",
									WIMTraceHelper.printObjectArray(CONFIG_SUPPORTED_MDALGORITHMS)),
							Level.SEVERE, CLASSNAME, "validateFileParams");
				}
			}

			String var6 = (String) var1.get("baseDirectory");
			if (var6 != null && var6.trim().length() > 0 && !fileExists(var6)) {
				throw new WIMConfigurationException("DIRECTORY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var6),
						Level.SEVERE, CLASSNAME, "validateFileParams");
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "validateFileParams");
				}

			}
		}
	}

	public static void validateLDAPParams(String var0, Map var1) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateLDAPParams",
					"id=" + var0 + ", params=" + WIMTraceHelper.printMapWithoutPassword(var1));
		}

		if (validateConfig()) {
			String var3 = (String) var1.get("ldapServerType");
			if (var3 != null) {
				if (var3.equals("IDS4") || var3.equals("IDS51") || var3.equals("IDS52") || var3.equals("IDS6")
						|| var3.equals("SECUREWAY")) {
					var3 = "IDS";
				}

				if (var3.equals("DOMINO5") || var3.equals("DOMINO6") || var3.equals("DOMINO65")) {
					var3 = "DOMINO";
				}

				if (var3.equals("AD2000") || var3.equals("AD2003")) {
					var3 = "AD";
				}
			}

			validateLDAPServerType(var3);
			if (var3 != null) {
				ValidationHelper.validateParam("ldapServerType", var3, CONFIG_LDAP_SUPPORTED_TYPES);
			}

			var1.put("ldapServerType", var3);
			InitialLdapContext var4 = null;
			String var5 = null;
			String var7;
			String var10;
			if (isParamSet(var1, LDAP_CONNECTION_PARAMS)) {
				Hashtable var6 = new Hashtable();
				var6.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
				var7 = (String) var1.get("host");
				if ((!var7.startsWith("[") || !var7.endsWith("]")) && ConfigUtils.isIPv6Addr(var7)) {
					var7 = ConfigUtils.formatIPv6Addr(var7);
					var1.put("host", var7);
				}

				Integer var8 = (Integer) var1.get("port");
				boolean var9 = false;
				if (var1.get("sslEnabled") != null) {
					var9 = (Boolean) var1.get("sslEnabled");
				}

				var10 = null;
				if (var9) {
					var10 = "ldaps://";
				} else {
					var10 = "ldap://";
				}

				if (var8 != null) {
					var5 = var10 + var7 + ":" + var8;
				} else {
					var5 = var10 + var7;
				}

				var6.put("java.naming.provider.url", var5);
				String var11;
				if (var9) {
					var11 = (String) var1.get("sslConfiguration");
					if (var11 != null) {
						trcLogger.logp(Level.FINE, CLASSNAME, "validateLDAPParams",
								"Use WAS SSL Configuration. sslAlias=" + var11);
						LdapConnectionBase.setWASSSLAlias(var11, var6);
						var6.put("java.naming.ldap.factory.socket", "com.ibm.websphere.ssl.protocol.SSLSocketFactory");
					}

					var6.put("java.naming.security.protocol", "ssl");
				}

				try {
					var11 = (String) var1.get("bindDN");
					String var25;
					if (var11 != null && var11.trim().length() > 0) {
						var6.put("java.naming.security.principal", var11);
						var25 = (String) var1.get("bindPassword");
						if (var25 != null) {
							if (var25 != null) {
								IEncryptionUtil var13 = FactoryManager.getEncryptionUtil();
								var25 = var13.decode(var25);
							}

							var6.put("java.naming.security.credentials", PasswordUtil.getByteArrayPassword(var25));
						}
					}

					var25 = (String) var1.get("authentication");
					if (var25 != null) {
						var6.put("java.naming.security.authentication", var25);
					}

					int var26 = 20;
					if (var1.get("connectTimeout") != null) {
						int var14 = (Integer) var1.get("connectTimeout");
						if (var14 > 0) {
							var26 = var14;
						}
					}

					var6.put("com.sun.jndi.ldap.connect.timeout", Integer.toString(var26 * 1000));
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateLDAPParams", "connecting to LDAP with:" + var6);
					}

					var4 = new InitialLdapContext(var6, (Control[]) null);
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateLDAPParams", "connected to LDAP.");
					}
				} catch (Exception var20) {
					Object var12;
					for (var12 = var20; ((Throwable) var12).getCause() != null; var12 = ((Throwable) var12)
							.getCause()) {
						;
					}

					if (var20 instanceof AuthenticationException) {
						throw new WIMConfigurationException(
								"REPOSITORY_CONNECTION_FAILED", WIMMessageHelper.generateMsgParms(var5,
										WIMTraceHelper.printMapWithoutPassword(var1), var12.getClass().getName()),
								CLASSNAME, "validateLDAPParams");
					}

					throw new WIMConfigurationException(
							"REPOSITORY_CONNECTION_FAILED", WIMMessageHelper.generateMsgParms(var5,
									WIMTraceHelper.printMapWithoutPassword(var1), var12.getClass().getName()),
							CLASSNAME, "validateLDAPParams", var20);
				} finally {
					LdapConnectionBase.resetWASSSLAlias();
				}
			}

			List var22 = (List) var1.get("searchBases");
			validateSearchBases(var4, var0, var5, var22);
			var7 = (String) var1.get("searchFilter");
			validateSearchFilter(var4, var0, var5, var7);
			List var23 = (List) var1.get("objectClasses");
			validateObjectClasses(var4, var0, var5, var23);
			List var24 = (List) var1.get("nameInRepository");
			validateBaseEntryNameInRepository(var4, var0, var5, var24);
			var10 = (String) var1.get("supportChangeLog");
			validateSupportChangeLogParameter(var10);

			try {
				if (var4 != null) {
					var4.close();
				}
			} catch (Exception var19) {
				trcLogger.logp(Level.FINE, CLASSNAME, "validateLDAPParams",
						"Error closing the LDAP connection:" + var19.getMessage(), var19);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateLDAPParams");
			}

		}
	}

	public static void validateLDAPServerType(String var0) throws WIMConfigurationException {
		if (validateConfig()) {
			if (var0 != null) {
				ValidationHelper.validateParam("ldapServerType", var0, CONFIG_LDAP_SUPPORTED_TYPES);
			}

		}
	}

	public static void validateLoginProperties(List var0) throws WIMConfigurationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateLoginProperties", "loginProps=" + var0);
		}

		if (validateConfig()) {
			if (var0 != null && var0.size() > 0) {
				SchemaManager var2 = null;

				try {
					var2 = SchemaManager.singleton();
				} catch (WIMException var11) {
					throw new WIMConfigurationException(var11.getMessageKey(), var11.getMessageParams(), CLASSNAME,
							"validateLoginProperties");
				}

				Set var3 = var2.getSubEntityTypes("LoginAccount");
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "validateLoginProperties", "LoginAccount subtypes: " + var3);
				}

				boolean var4 = false;
				Iterator var5 = var3.iterator();

				while (var5.hasNext()) {
					String var6 = (String) var5.next();
					List var7 = var2.getProperties(var6);
					ArrayList var8 = new ArrayList();

					for (int var9 = 0; var9 < var7.size(); ++var9) {
						var8.add(((Property) var7.get(var9)).getName());
					}

					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "validateLoginProperties",
								"props of " + var6 + ":" + var8);
					}

					if (var8.contains("ibmPrimaryEmail")) {
						var8.add("ibm-primaryEmail");
					} else if (var8.contains("ibmJobTitle")) {
						var8.add("ibm-jobTitle");
					}

					boolean var12 = true;

					for (int var10 = 0; var10 < var0.size(); ++var10) {
						if (!var8.contains(var0.get(var10))) {
							var12 = false;
							break;
						}
					}

					if (var12) {
						var4 = true;
						break;
					}
				}

				if (!var4) {
					throw new WIMConfigurationException("INVALID_LOGIN_PROPERTIES",
							WIMMessageHelper.generateMsgParms(var0.toString()), CLASSNAME, "validateLoginProperties");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateLoginProperties");
			}

		}
	}

	public static void validateDeleteIdMgrRealm(ConfigurationProviderType var0, String var1) throws WIMException {
		String var2 = "validateDeleteIdMgrRealm";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2, "realmName=" + var1);
		}

		if (validateConfig()) {
			RealmConfigurationType var3 = getRealmConfig(var0);
			String var4 = var3.getDefaultRealm();
			if (var1.equals(var4)) {
				throw new WIMConfigurationException("CANNOT_DELETE_DEFAULT_REALM",
						WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, CLASSNAME, var2);
			} else {
				com.ibm.ws.wim.config.ConfigUtils.getRealm(var1, var3);
				List var5 = var3.getRealms();
				if (var5.size() == 1) {
					throw new WIMConfigurationException("CANNOT_DELETE_ONLY_REALM",
							WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, CLASSNAME, var2);
				} else {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, var2);
					}

				}
			}
		}
	}

	public static void validateAddIdMgrRealmBaseEntry(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		String var3 = "validateAddIdMgrRealmBaseEntry";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "realmName=" + var1 + ", baseEntryName=" + var2);
		}

		if (validateConfig()) {
			if (!isDN(var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_MUST_BE_DN", WIMMessageHelper.generateMsgParms(var2),
						Level.SEVERE, CLASSNAME, var3);
			} else if (!isBaseEntryInRepository(var0, var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_CANNOT_BE_ADDED_TO_REALM",
						WIMMessageHelper.generateMsgParms(var2, var1), Level.SEVERE, CLASSNAME, var3);
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, var3);
				}

			}
		}
	}

	public static void validateDeleteIdMgrRealmBaseEntry(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		String var3 = "validateDeleteIdMgrRealmBaseEntry";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "realmName=" + var1 + ", baseEntryName=" + var2);
		}

		if (validateConfig()) {
			RealmConfigurationType var4 = getRealmConfig(var0);
			String var5 = var4.getDefaultRealm();
			if (var1.equals(var5) && isLastBaseEntryInRealm(var0, var1, var2)) {
				throw new WIMConfigurationException("CANNOT_DELETE_ONLY_BASE_ENTRY_IN_REALM",
						WIMMessageHelper.generateMsgParms(var2, var1), Level.SEVERE, CLASSNAME, var3);
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, var3);
				}

			}
		}
	}

	public static void validateAddIdMgrRepositoryBaseEntry(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		String var3 = "validateAddIdMgrRepositoryBaseEntry";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "repoId=" + var1 + ", baseEntryName=" + var2);
		}

		if (validateConfig()) {
			if (!isDN(var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_MUST_BE_DN", WIMMessageHelper.generateMsgParms(var2),
						Level.SEVERE, CLASSNAME, var3);
			} else if (isBaseEntryInRepository(var0, var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_ALREADY_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var2, var1), Level.SEVERE, CLASSNAME, var3);
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, var3);
				}

			}
		}
	}

	public static void validateDeleteIdMgrRepositoryBaseEntry(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		String var3 = "validateDeleteIdMgrRepositoryBaseEntry";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "repoId=" + var1 + ", baseEntryName=" + var2);
		}

		if (validateConfig()) {
			if (isLastBaseEntryInRepository(var0, var1, var2)) {
				throw new WIMConfigurationException("CANNOT_DELETE_ONLY_BASE_ENTRY_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var2, var1), Level.SEVERE, CLASSNAME, var3);
			} else if (isBaseEntryInRealms(var0, var2)) {
				throw new WIMConfigurationException("BASE_ENTRY_STILL_REFERENCED_BY_REALM",
						WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, var3);
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, var3);
				}

			}
		}
	}

	public static void validateDeleteIdMgrRepository(ConfigurationProviderType var0, String var1) throws WIMException {
		String var2 = "validateDeleteIdMgrRepository";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2, "repoId=" + var1);
		}

		if (validateConfig()) {
			ProfileRepositoryType var3 = (ProfileRepositoryType) com.ibm.ws.wim.config.ConfigUtils
					.getRepositoryById(var0, var1);
			List var4 = var3.getBaseEntries();

			for (int var5 = 0; var5 < var4.size(); ++var5) {
				BaseEntriesType var6 = (BaseEntriesType) var4.get(var5);
				String var7 = var6.getName();
				if (isBaseEntryInRealms(var0, var7)) {
					throw new WIMConfigurationException("DELETE_REPOSITORY_PREREQUISITE_ERROR",
							WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, CLASSNAME, var2);
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, var2);
			}

		}
	}

	public static void validateRepositoriesForGroup(ConfigurationProviderType var0, List var1) throws WIMException {
		String var2 = "validateRepositoriesForGroup";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2, "reposForGroups=" + var1);
		}

		if (var1 != null && var1.size() > 0) {
			List var3 = com.ibm.ws.wim.config.ConfigUtils.getProfileRepositories(var0);
			ArrayList var4 = new ArrayList();

			int var5;
			for (var5 = 0; var5 < var3.size(); ++var5) {
				var4.add(((RepositoryType) var3.get(var5)).getId());
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, var2, "currentRepoIds=" + var4);
			}

			for (var5 = 0; var5 < var1.size(); ++var5) {
				String var6 = (String) var1.get(var5);
				if (!var4.contains(var6)) {
					throw new WIMConfigurationException("INVALID_REPOSITORY_FOR_GROUPS",
							WIMMessageHelper.generateMsgParms(var6), Level.SEVERE, CLASSNAME, var2);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var2);
		}

	}

	private static boolean isParamSet(Map var0, String[] var1) {
		boolean var2 = false;

		for (int var3 = 0; var3 < var1.length; ++var3) {
			if (var0.containsKey(var1[var3])) {
				var2 = true;
				break;
			}
		}

		return var2;
	}

	private static boolean validateConfig() {
		boolean var0 = true;
		String var1 = System.getProperty("wim.config.validation");
		if (var1 != null) {
			var0 = Boolean.getBoolean(var1);
			if (!var0) {
				trcLogger.log(Level.FINER, "wim.config.validation=" + var1);
				trcLogger.log(Level.FINER,
						"Virtual member manager CONFIG VALIDATION IS TURNED OFF. **** DO NOT TURN IT OFF ****");
			}
		}

		return var0;
	}

	public static void validateSupportChangeLogParameter(String var0) throws WIMConfigurationException {
		if (var0 != null && !"native".equalsIgnoreCase(var0) && !"none".equalsIgnoreCase(var0)) {
			throw new WIMConfigurationException("INVALID_SUPPORT_CHANGE_LOG", WIMMessageHelper.generateMsgParms(var0),
					CLASSNAME, "validateSupportChangeLogParameter");
		}
	}

	private static void validateSearchFilter(DirContext var0, String var1, String var2, String var3)
			throws WIMConfigurationException {
		if (var3 != null && var3.trim().length() > 0) {
			if (var0 == null) {
				throw new WIMConfigurationException("MISSING_OR_INVALID_CONNECTION_DATA",
						WIMMessageHelper.generateMsgParms(var2 == null ? var1 : var2), CLASSNAME,
						"validateSearchFilter");
			}

			try {
				SearchControls var5 = new SearchControls();
				var5.setSearchScope(0);
				var0.search("", var3, var5);
			} catch (InvalidSearchFilterException var6) {
				throw new WIMConfigurationException("INVALID_SEARCH_FILTER", WIMMessageHelper.generateMsgParms(var3),
						CLASSNAME, "validateSearchFilter", var6);
			} catch (NamingException var7) {
				trcLogger.logp(Level.FINE, CLASSNAME, "validateSearchFilter", "invalid search filter: " + var3, var7);
			}
		}

	}

	private static void validateSearchBases(DirContext var0, String var1, String var2, List var3)
			throws WIMConfigurationException {
		Object var5 = null;
		if (var3 != null && var3.size() > 0) {
			if (var0 == null) {
				throw new WIMConfigurationException("MISSING_OR_INVALID_CONNECTION_DATA",
						WIMMessageHelper.generateMsgParms(var2 == null ? var1 : var2), CLASSNAME,
						"validateSearchBases");
			}

			try {
				SearchControls var6 = new SearchControls();
				var6.setSearchScope(0);

				for (int var10 = 0; var10 < var3.size(); ++var10) {
					var0.search(new LdapName((String) var3.get(var10)), "(objectclass=*)", var6);
				}
			} catch (InvalidNameException var8) {
				throw new WIMConfigurationException("INVALID_SEARCH_BASE", WIMMessageHelper.generateMsgParms(var3),
						CLASSNAME, "validateSearchBases", var8);
			} catch (NamingException var9) {
				trcLogger.logp(Level.FINE, CLASSNAME, "validateSearchBases", "invalid searchBases: " + var3, var9);
				String var7 = var9.getMessage();
				if (var7 != null && var7.contains("[LDAP: error code 32 - No Such Object]")) {
					throw new WIMConfigurationException("INVALID_SEARCH_BASE", WIMMessageHelper.generateMsgParms(var3),
							CLASSNAME, "validateSearchBases");
				}
			}
		}

	}

	private static void validateObjectClasses(DirContext var0, String var1, String var2, List var3)
			throws WIMConfigurationException {
		if (var3 != null && var3.size() > 0) {
			if (var0 == null) {
				throw new WIMConfigurationException("MISSING_OR_INVALID_CONNECTION_DATA",
						WIMMessageHelper.generateMsgParms(var2 == null ? var1 : var2), CLASSNAME,
						"validateObjectClasses");
			}

			String var5 = null;

			try {
				DirContext var6 = var0.getSchema("");
				trcLogger.logp(Level.FINER, CLASSNAME, "validateObjectClasses", "getSchema=" + var6);

				for (int var7 = 0; var7 < var3.size(); ++var7) {
					var5 = (String) var3.get(var7);
					String var8 = "ClassDefinition/" + var5;
					trcLogger.logp(Level.FINER, CLASSNAME, "validateObjectClasses", "checking object class=" + var8);
					var6.getAttributes(var8);
				}
			} catch (NamingException var9) {
				if (var5 != null) {
					throw new WIMConfigurationException("INVALID_OBJECT_CLASSES",
							WIMMessageHelper.generateMsgParms(var5), CLASSNAME, "validateObjectClasses", var9);
				}

				throw new WIMConfigurationException("INVALID_OBJECT_CLASSES", WIMMessageHelper.generateMsgParms(var3),
						CLASSNAME, "validateObjectClasses", var9);
			}
		}

	}

	private static void validateBaseEntryNameInRepository(DirContext var0, String var1, String var2, List var3)
			throws WIMConfigurationException {
		if (var3 != null && var3.size() > 0) {
			if (var0 == null) {
				throw new WIMConfigurationException("MISSING_OR_INVALID_CONNECTION_DATA",
						WIMMessageHelper.generateMsgParms(var2 == null ? var1 : var2), CLASSNAME,
						"validateBaseEntryNameInRepository");
			}

			String var5 = null;

			try {
				SearchControls var6 = new SearchControls();
				var6.setSearchScope(0);

				for (int var7 = 0; var7 < var3.size(); ++var7) {
					var5 = (String) var3.get(var7);
					trcLogger.logp(Level.FINER, CLASSNAME, "validateBaseEntryNameInRepository",
							"validating nameInRepository " + var5);
					var0.search(new LdapName(var5), "(objectclass=*)", var6);
				}
			} catch (NamingException var8) {
				if (var5 != null) {
					throw new WIMConfigurationException("INVALID_BASE_ENTRY_NAME_IN_REPOSITORY",
							WIMMessageHelper.generateMsgParms(var5, var8.getMessage()), CLASSNAME,
							"validateBaseEntryNameInRepository", var8);
				}

				throw new WIMConfigurationException("INVALID_BASE_ENTRY_NAME_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var3, var8.getMessage()), CLASSNAME,
						"validateBaseEntryNameInRepository", var8);
			}
		}

	}

	private static boolean isStringEqual(String var0, String var1) {
		boolean var2 = false;
		if (var0 == null && var1 == null) {
			var2 = true;
		} else if (var0 != null && var1 != null) {
			var2 = var0.equalsIgnoreCase(var1);
		}

		return var2;
	}

	private static boolean isLastBaseEntryInRepository(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		boolean var3 = false;
		ProfileRepositoryType var4 = (ProfileRepositoryType) com.ibm.ws.wim.config.ConfigUtils.getRepositoryById(var0,
				var1);
		List var5 = var4.getBaseEntries();
		if (var5.size() == 1 && isStringEqual(var2, ((BaseEntriesType) var5.get(0)).getName())) {
			var3 = true;
		}

		return var3;
	}

	private static boolean isLastBaseEntryInRealm(ConfigurationProviderType var0, String var1, String var2)
			throws WIMException {
		boolean var3 = false;
		RealmConfigurationType var4 = getRealmConfig(var0);
		RealmType var5 = com.ibm.ws.wim.config.ConfigUtils.getRealm(var1, var4);
		List var6 = var5.getParticipatingBaseEntries();
		if (var6.size() == 1 && isStringEqual(var2, ((ParticipatingBaseEntriesType) var6.get(0)).getName())) {
			var3 = true;
		}

		return var3;
	}

	private static boolean isBaseEntryInRealms(ConfigurationProviderType var0, String var1) throws WIMException {
		boolean var2 = false;
		RealmConfigurationType var3 = getRealmConfig(var0);
		List var4 = var3.getRealms();

		for (int var5 = 0; var5 < var4.size(); ++var5) {
			RealmType var6 = (RealmType) var4.get(var5);
			List var7 = var6.getParticipatingBaseEntries();

			for (int var8 = 0; var8 < var7.size(); ++var8) {
				ParticipatingBaseEntriesType var9 = (ParticipatingBaseEntriesType) var7.get(var8);
				if (isStringEqual(var1, var9.getName())) {
					var2 = true;
					break;
				}
			}

			if (var2) {
				break;
			}
		}

		return var2;
	}

	public static boolean isBaseEntryInRepository(ConfigurationProviderType var0, String var1) throws WIMException {
		boolean var2 = false;
		List var3 = com.ibm.ws.wim.config.ConfigUtils.getProfileRepositories(var0);

		for (int var4 = 0; var4 < var3.size(); ++var4) {
			ProfileRepositoryType var5 = (ProfileRepositoryType) var3.get(var4);
			List var6 = var5.getBaseEntries();

			for (int var7 = 0; var7 < var6.size(); ++var7) {
				BaseEntriesType var8 = (BaseEntriesType) var6.get(var7);
				if (isStringEqual(var1, var8.getName())) {
					var2 = true;
					break;
				}
			}
		}

		return var2;
	}

	private static boolean isDN(String var0) {
		boolean var1 = false;

		try {
			if (var0 != null && !var0.startsWith(",") && !var0.endsWith(",")) {
				new LdapName(var0);
				var1 = true;
			}
		} catch (InvalidNameException var3) {
			trcLogger.logp(Level.FINER, CLASSNAME, "isDN", "not a DN:" + var0, var3);
		}

		return var1;
	}

	public static RealmConfigurationType getRealmConfig(ConfigurationProviderType var0) throws WIMException {
		String var1 = "getRealmConfig";
		RealmConfigurationType var2 = var0.getRealmConfiguration();
		if (var2 == null) {
			throw new WIMConfigurationException("MISSING_REALM_CONFIGURATION", Level.SEVERE, CLASSNAME, var1);
		} else {
			return var2;
		}
	}

	public static boolean fileExists(String var0) {
		try {
			if (var0 != null) {
				File var1 = new File(var0);
				if (var1.exists()) {
					return true;
				}
			}
		} catch (Exception var2) {
			trcLogger.logp(Level.FINER, CLASSNAME, "fileExists", "checking for file: " + var0, var2);
		}

		return false;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = ConfigValidator.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		DB_CONNECTION_PARAMS = new String[]{"dataSourceName", "databaseType", "dbURL", "dbAdminId", "dbAdminPassword",
				"JDBCDriverClass", "dbSchema"};
		LDAP_CONNECTION_PARAMS = new String[]{"host", "port", "bindDN", "bindPassword", "authentication", "sslEnabled"};
	}
}