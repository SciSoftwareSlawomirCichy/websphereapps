package com.ibm.ejs.container.util;

import com.ibm.ejs.container.ContainerEJBException;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSHome;
import com.ibm.ejs.container.HomeRecord;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.naming.util.CacheableReference;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;

public class EJBInterfaceObjectFactory implements ObjectFactory {
	private static final String CLASS_NAME = EJBInterfaceObjectFactory.class.getName();
	private static final TraceComponent tc;

	public static Reference createReference(HomeRecord homeRecord, String interfaceName, boolean isHome,
			boolean isLocal) {
		EJBInterfaceInfo info = new EJBInterfaceInfo(homeRecord.getJ2EEName(), interfaceName, isHome, isLocal);
		EJBInterfaceInfoRefAddr refAddr = new EJBInterfaceInfoRefAddr(info);
		int type = homeRecord.getBeanType();
		if (!isHome && type != 3 && type != 2) {
			return new Reference(interfaceName, refAddr, CLASS_NAME, (String) null);
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "creating cacheable reference");
			}

			return new CacheableReference(interfaceName, refAddr, CLASS_NAME, (String) null);
		}
	}

	public EJBInterfaceObjectFactory() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>");
		}

	}

	public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable<?, ?> environment)
			throws Exception {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getObjectInstance");
		}

		if (!(obj instanceof Reference)) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getObjectInstance : " + obj + " is not a Reference");
			}

			return null;
		} else {
			Reference ref = (Reference) obj;
			if (!ref.getFactoryClassName().equals(CLASS_NAME)) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "getObjectInstance : this is not the right factory for this Reference: " + obj);
				}

				return null;
			} else {
				RefAddr addr = ref.get("EJBInterfaceInfo");
				if (addr == null) {
					NamingException nex = new NamingException("The address for this Reference is empty (null)");
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "getObjectInstance : " + nex);
					}

					throw nex;
				} else {
					EJBInterfaceInfo info = (EJBInterfaceInfo) addr.getContent();
					J2EEName j2eeName = info.getJ2eeName();
					EJSContainer container = EJSContainer.getDefaultContainer();
					if (container == null) {
						throw new ContainerEJBException("The " + j2eeName.getComponent() + " bean in the "
								+ j2eeName.getModule() + " module of the " + j2eeName.getApplication()
								+ " application cannot be looked up because"
								+ " the EJB container is not started in this process."
								+ " EJB local interface views can only be looked up from"
								+ " processes where the EJB module is started.");
					} else {
						boolean local = info.isLocalInterfaceName();
						Object retObj;
						if (info.isHomeInterfaceName()) {
							retObj = local ? container.getEJBLocalHome(j2eeName) : container.getEJBHome(j2eeName);
						} else {
							EJSHome home = container.getStartedHome(j2eeName);
							String businessInterfaceName = info.getInterfaceName();
							retObj = local
									? home.createLocalBusinessObject(businessInterfaceName, false)
									: home.createRemoteBusinessObject(businessInterfaceName, false);
						}

						if (isTraceOn && tc.isEntryEnabled()) {
							Tr.exit(tc, "getObjectInstance : " + Util.identity(retObj));
						}

						return retObj;
					}
				}
			}
		}
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}