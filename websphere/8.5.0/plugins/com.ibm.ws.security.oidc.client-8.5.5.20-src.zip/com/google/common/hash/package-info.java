@CheckReturnValue
@ParametersAreNonnullByDefault
package com.google.common.hash;

import com.google.errorprone.annotations.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;