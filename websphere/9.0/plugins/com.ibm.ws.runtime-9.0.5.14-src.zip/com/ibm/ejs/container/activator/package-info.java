package com.ibm.ejs.container.activator;

interface package-info {
}