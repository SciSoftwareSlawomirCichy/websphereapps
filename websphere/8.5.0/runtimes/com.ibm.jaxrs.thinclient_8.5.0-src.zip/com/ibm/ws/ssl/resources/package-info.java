package com.ibm.ws.ssl.resources;

interface package-info {
}