package com.ibm.ejs.container;

public class LifecycleInterceptorWrapper extends EJSWrapperBase {
	public static final String[] METHOD_NAMES = new String[]{"PostConstruct lifecycle interceptor",
			"PreDestroy lifecycle interceptor"};
	public static final String[] TRACE_NAMES = new String[]{"PostConstruct", "PreDestroy"};
	private static final Class<?>[] NO_PARAMS = new Class[0];
	public static final Class<?>[][] METHOD_PARAM_TYPES;
	public static final String[] METHOD_SIGNATURES;
	public static final String[] METHOD_JDI_SIGNATURES;
	public static final int MID_POST_CONSTRUCT = 0;
	public static final int MID_PRE_DESTROY = 1;
	public static final int NUM_METHODS = 2;

	public LifecycleInterceptorWrapper(EJSContainer c, BeanO beanO) {
		this.container = c;
		this.wrapperManager = c.wrapperManager;
		this.ivCommon = null;
		this.isManagedWrapper = false;
		this.ivInterface = WrapperInterface.LIFECYCLE_INTERCEPTOR;
		this.beanId = beanO.beanId;
		this.bmd = beanO.home.beanMetaData;
		this.methodInfos = this.bmd.lifecycleInterceptorMethodInfos;
		this.methodNames = this.bmd.lifecycleInterceptorMethodNames;
		this.isolationAttrs = null;
		this.ivPmiBean = beanO.home.pmiBean;
	}

	static {
		METHOD_PARAM_TYPES = new Class[][]{NO_PARAMS, NO_PARAMS};
		METHOD_SIGNATURES = new String[]{"()", "()"};
		METHOD_JDI_SIGNATURES = new String[]{"()V", "()V"};
	}
}