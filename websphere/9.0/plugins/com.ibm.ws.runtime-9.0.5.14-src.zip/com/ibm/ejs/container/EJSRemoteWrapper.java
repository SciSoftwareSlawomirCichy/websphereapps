package com.ibm.ejs.container;

import com.ibm.websphere.csi.CSIServant;
import com.ibm.websphere.csi.TransactionalObject;
import javax.rmi.CORBA.Tie;

public abstract class EJSRemoteWrapper extends EJSWrapperBase implements CSIServant, TransactionalObject {
	public Object ivCluster;
	public Tie intie;
	public Object instub;

	public boolean wlmable() {
		throw new ContainerEJBException("wlmable call not expected to occur.");
	}
}