package com.ibm.ejs.oa;

import com.ibm.CORBA.iiop.ORB;
import com.ibm.CORBA.iiop.ThreadPool;
import com.ibm.ejs.EJSException;
import com.ibm.ws.orb.GlobalORBFactory;
import java.applet.Applet;
import java.util.Properties;

public class EJSORB {
	private static EJSORBImpl theORB;

	public static synchronized ORB init(String modelName, String serverName, String bootstrapHost, int bootstrapPort,
			ThreadPool threadPool, Properties orbProps) throws EJSException {
		if (theORB != null) {
			throw new RuntimeException("ORB has already been initialized");
		} else {
			theORB = new EJSServerORBImpl(modelName, serverName, bootstrapHost, bootstrapPort, threadPool, orbProps);
			return theORB.getORB();
		}
	}

	public static ORB init() {
		if (theORB == null) {
			synchronizedInit();
		}

		return theORB.getORB();
	}

	private static synchronized void synchronizedInit() {
		if (theORB == null) {
			theORB = new EJSClientORBImpl();
		}

	}

	public static ORB init(String bootstrapHost, int bootstrapPort, Properties props) {
		return (new EJSClientORBImpl(bootstrapHost, bootstrapPort, props)).getORB();
	}

	public static ORB init(Applet applet, String bootstrapHost, int bootstrapPort, Properties props) {
		return (new EJSClientORBImpl(applet, bootstrapHost, bootstrapPort, props)).getORB();
	}

	public static void terminate() {
		if (theORB != null) {
			theORB.terminate();
		}

	}

	public static ORB getORBInstance() {
		return init();
	}

	public static ORB globalORB() {
		Class var0 = GlobalORBFactory.class;
		synchronized (GlobalORBFactory.class) {
			return GlobalORBFactory.globalORB();
		}
	}
}