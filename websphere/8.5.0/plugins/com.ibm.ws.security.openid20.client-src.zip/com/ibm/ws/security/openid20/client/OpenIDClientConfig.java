package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.security.WebTrustAssociationFailedException;
import com.ibm.ws.security.openid20.util.MessageHelper;
import com.ibm.ws.security.openid20.util.OidUtil;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

public class OpenIDClientConfig {
	private static final TraceComponent tc = Tr.register(OpenIDClientConfig.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private String providerIdentifier = null;
	private ArrayList<String> effectiveUriList = null;
	private String[] mapAliasAsPrincipal = null;
	private List<UserInfo> userInfo = new ArrayList();
	private int axAttributeCount;
	private ArrayList<String> basicAuthUriList = null;
	private boolean tryOpenIDIfBasicAuthFails = true;
	private ArrayList<String> excludedUriList = null;
	private boolean allowStateless;
	private int maxAssociationAttempts;
	private long nonceValidTime;
	private boolean httpsRequired;
	private boolean mapIdentityToRegistryUser;
	private boolean useClientIdentity;
	private String sessionEncryptionType;
	private String signatureAlgorithm;
	private long connectTimeout;
	private long socketTimeout;
	private boolean hostNameVerificationEnabled;
	private int maxDiscoveryCacheSize;
	private int maxDiscoverRetry;
	private String realmName;
	private String authenticationMode;
	private String characterEncoding;
	private long cacheCleanupFrequency;
	private String JNDICacheName = null;
	private String realmIdentifier = null;
	private String groupIdentifier = null;
	private boolean includeCustomCacheKeyInSubject = true;
	private boolean httpOnly = true;

	private OpenIDClientConfig() {
	}

	public OpenIDClientConfig(Properties props) throws OpenIDRelyingPartyException, WebTrustAssociationFailedException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "OpenIDClientConfig(properties[" + OidUtil.getObjState(props) + "])");
		}

		this.providerIdentifier = OidUtil.getProperty(props, "providerIdentifier", (String) null);
		this.effectiveUriList = OidUtil.getUris(props, "effectiveUriList", (String) null);
		String mapAliases = OidUtil.getOptionalProperty(props, "mapAliasAsPrincipal", false);
		if (mapAliases != null) {
			this.mapAliasAsPrincipal = OidUtil.split(mapAliases, ",");
		}

		this.excludedUriList = OidUtil.getUris(props, "excludedUriList");
		this.basicAuthUriList = OidUtil.getUris(props, "basicAuthUriList");
		this.tryOpenIDIfBasicAuthFails = Boolean
				.parseBoolean(OidUtil.getProperty(props, "tryOpenIDIfBasicAuthFails", "true"));
		this.axAttributeCount = Integer.parseInt(OidUtil.getProperty(props, "axAttributeCount", "1"));
		this.mapIdentityToRegistryUser = Boolean
				.parseBoolean(OidUtil.getProperty(props, "mapIdentityToRegistryUser", "false"));
		this.useClientIdentity = Boolean.parseBoolean(OidUtil.getProperty(props, "useClientIdentity", "false"));
		this.connectTimeout = Long.parseLong(OidUtil.getProperty(props, "connectTimeout", "60"));
		this.allowStateless = Boolean.parseBoolean(OidUtil.getProperty(props, "allowStateless", "true"));
		this.nonceValidTime = Long.parseLong(OidUtil.getProperty(props, "nonceValidTime", "300"));
		this.maxDiscoveryCacheSize = Integer.parseInt(OidUtil.getProperty(props, "maxDiscoveryCacheSize", "10000"));
		this.maxDiscoverRetry = Integer.parseInt(OidUtil.getProperty(props, "maxDiscoverRetry", "2"));
		this.maxAssociationAttempts = Integer.parseInt(OidUtil.getProperty(props, "maxAssociationAttempts", "4"));
		this.socketTimeout = Long.parseLong(OidUtil.getProperty(props, "socketTimeout", "60"));
		this.hostNameVerificationEnabled = Boolean
				.parseBoolean(OidUtil.getProperty(props, "hostNameVerificationEnabled", "true"));
		this.httpsRequired = Boolean.parseBoolean(OidUtil.getProperty(props, "httpsRequired", "true"));
		this.authenticationMode = OidUtil.getProperty(props, "authenticationMode", "checkid_setup");
		this.realmName = OidUtil.getProperty(props, "realmName", "OpenIDDefaultRealm");
		this.characterEncoding = OidUtil.getProperty(props, "characterEncoding", "UTF-8");
		this.cacheCleanupFrequency = Long.parseLong(OidUtil.getProperty(props, "cacheCleanupFrequency", "3600"));
		this.JNDICacheName = OidUtil.getOptionalProperty(props, "jndiCacheName", false);
		this.realmIdentifier = OidUtil.getOptionalProperty(props, "realmIdentifier", false);
		this.groupIdentifier = OidUtil.getOptionalProperty(props, "groupIdentifier", false);
		this.includeCustomCacheKeyInSubject = Boolean
				.parseBoolean(OidUtil.getProperty(props, "includeCustomCacheKeyInSubject", "true"));
		this.httpOnly = Boolean.parseBoolean(OidUtil.getProperty(props, "httpOnly", "true"));
		boolean sharedKeyEncryptionEnabled = Boolean
				.parseBoolean(OidUtil.getProperty(props, "sharedKeyEncryptionEnabled", "true"));
		String hashAlgorithm = OidUtil.getProperty(props, "hashAlgorithm", "SHA256");
		this.setSessionEncryptionType(sharedKeyEncryptionEnabled, hashAlgorithm);
		this.setSignatureAlgorithm(hashAlgorithm);
		this.userInfo = this.getAxAttributeList(props);
		if (tc.isDebugEnabled()) {
			Iterator i$ = this.userInfo.iterator();

			while (i$.hasNext()) {
				UserInfo ui = (UserInfo) i$.next();
				Tr.debug(tc, "userInfo: [" + ui.toString() + "]");
			}
		}

		this.validateConfig();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "OpenIDClientConfig returns");
		}

	}

	private void setSessionEncryptionType(Boolean sharedKeyEnc, String hashAlgorithmValue) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setSessionEncryptionType(sharedKeyEnc[" + OidUtil.getObjState(sharedKeyEnc)
					+ "], hashAlgorithnValue[" + OidUtil.getObjState(hashAlgorithmValue) + "])");
		}

		if (sharedKeyEnc) {
			if ("SHA1".equalsIgnoreCase(hashAlgorithmValue)) {
				this.sessionEncryptionType = "DH-SHA1";
			} else {
				this.sessionEncryptionType = "DH-SHA256";
			}
		} else {
			this.sessionEncryptionType = "no-encryption";
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setSessionEncryptionType returns");
		}

	}

	private void setSignatureAlgorithm(String hashAlgorithmValue) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setSignatureAlgorithm(hashAlgorithmValue[" + OidUtil.getObjState(hashAlgorithmValue) + "])");
		}

		if ("SHA1".equalsIgnoreCase(hashAlgorithmValue)) {
			this.signatureAlgorithm = "HMAC-SHA1";
		} else {
			this.signatureAlgorithm = "HMAC-SHA256";
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setSignatureAlgorithm returns");
		}

	}

	private void validateConfig() throws WebTrustAssociationFailedException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "validateConfig");
		}

		try {
			new URL(this.providerIdentifier);
		} catch (MalformedURLException var3) {
			String msg = MessageHelper.getMessage("security.openid20.client.invalidprovideridentifier",
					"providerIdentifier");
			Tr.error(tc, msg);
			throw new WebTrustAssociationFailedException(msg);
		}

		if (!this.allowStateless && this.maxAssociationAttempts == 0) {
			this.maxAssociationAttempts = 4;
			Tr.warning(tc,
					"Defaulting to maxAssociation attempts as 4, since stateless mode is false and maxAssociationAttempts is 0");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "validateConfig returns");
		}

	}

	private List<UserInfo> getAxAttributeList(Properties props)
			throws OpenIDRelyingPartyException, WebTrustAssociationFailedException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getAxAttributeList(properties[" + OidUtil.getObjState(props) + "])");
		}

		List<UserInfo> uiList = new ArrayList();
		int count = this.getAxAttributeCount();
		Set<Object> keys = props.keySet();
		Iterator i$ = keys.iterator();

		while (true) {
			String aKey;
			boolean required;
			while (true) {
				if (!i$.hasNext()) {
					if (uiList.size() == 0) {
						String msg = MessageHelper.getMessage("security.openid20.client.minaxrequired");
						Tr.error(tc, msg);
						throw new WebTrustAssociationFailedException(msg);
					}

					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getAxAttributeList returns [" + OidUtil.getObjState(uiList) + "]");
					}

					return uiList;
				}

				Object key = i$.next();
				aKey = (String) key;
				required = false;
				if (aKey.contains("axRequiredAttribute")) {
					required = true;
					break;
				}

				if (aKey.contains("axOptionalAttribute")) {
					required = false;
					break;
				}
			}

			String attr = OidUtil.getProperty(props, aKey, (String) null);
			String[] axAttr = OidUtil.split(attr, ",", 2);
			String alias = axAttr[0].trim();
			String uriType = axAttr[1].trim();

			try {
				new URL(uriType);
			} catch (MalformedURLException var15) {
				String msg = MessageHelper.getMessage("security.openid20.client.invalidaxrequired", aKey);
				Tr.error(tc, msg);
				throw new WebTrustAssociationFailedException(msg);
			}

			UserInfo ui = new UserInfo(alias, uriType, count, required);
			uiList.add(ui);
		}
	}

	public String[] getMapAliasAsPrincipal() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getMapAliasAsPrincipal returns [" + this.mapAliasAsPrincipal + "]");
		}

		return this.mapAliasAsPrincipal;
	}

	public String getProviderIdentifier() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getProviderIdentifier returns [" + this.providerIdentifier + "]");
		}

		return this.providerIdentifier;
	}

	public ArrayList<String> getEffectiveUriList() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getEffectiveUriList returns [" + OidUtil.getObjState(this.effectiveUriList) + "]");
		}

		return this.effectiveUriList;
	}

	public ArrayList<String> getExcludedUriList() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getExcludedUriList returns [" + OidUtil.getObjState(this.excludedUriList) + "]");
		}

		return this.excludedUriList;
	}

	public ArrayList<String> getBasicAuthUriList() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getBasicAuthUriList returns [" + OidUtil.getObjState(this.basicAuthUriList) + "]");
		}

		return this.basicAuthUriList;
	}

	public boolean isTryOpenIDIfBasicAuthFails() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isTryOpenIDIfBasicAuthFails returns [" + this.tryOpenIDIfBasicAuthFails + "]");
		}

		return this.tryOpenIDIfBasicAuthFails;
	}

	public boolean getAllowStateless() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getAllowStateless returns [" + this.allowStateless + "]");
		}

		return this.allowStateless;
	}

	public long getNonceValidTime() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getNonceValidTime returns [" + this.nonceValidTime + "]");
		}

		return this.nonceValidTime * 1000L;
	}

	public int getMaxDiscoveryCacheSize() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getMaxDiscoveryCacheSize returns [" + this.maxDiscoveryCacheSize + "]");
		}

		return this.maxDiscoveryCacheSize;
	}

	public int getMaxAssociationAttemps() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getMaxAssociationAttemps returns [" + this.maxAssociationAttempts + "]");
		}

		return this.maxAssociationAttempts;
	}

	public String getSessionEncryptionType() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSessionEncryptionType returns [" + this.sessionEncryptionType + "]");
		}

		return this.sessionEncryptionType;
	}

	public String getSignatureAlgorithm() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSignatureAlgorithm returns [" + this.signatureAlgorithm + "]");
		}

		return this.signatureAlgorithm;
	}

	public String getRealmName() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getRealmName returns [" + this.realmName + "]");
		}

		return this.realmName;
	}

	public List<UserInfo> getUserInfo() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getUserInfo returns [" + OidUtil.getObjState(this.userInfo) + "]");
		}

		return this.userInfo;
	}

	public long getConnectTimeout() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getConnectTimeout returns [" + this.connectTimeout + "]");
		}

		return this.connectTimeout * 1000L;
	}

	public long getSocketTimeout() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSocketTimeout returns [" + this.socketTimeout + "]");
		}

		return this.socketTimeout * 1000L;
	}

	public boolean isHostNameVerificationEnabled() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isHostNameVerificationEnabled returns [" + this.hostNameVerificationEnabled + "]");
		}

		return this.hostNameVerificationEnabled;
	}

	public boolean ishttpsRequired() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "ishttpsRequired returns [" + this.httpsRequired + "]");
		}

		return this.httpsRequired;
	}

	public String getAuthenticationMode() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getAuthenticationMode returns [" + this.authenticationMode + "]");
		}

		return this.authenticationMode;
	}

	public boolean isMapIdentityToRegistryUser() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isMapIdentityToRegistryUser returns [" + this.mapIdentityToRegistryUser + "]");
		}

		return this.mapIdentityToRegistryUser;
	}

	public boolean isUseClientIdentity() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isUseClientIdentity returns [" + this.useClientIdentity + "]");
		}

		return this.useClientIdentity;
	}

	public int getMaxDiscoverRetry() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getMaxDiscoverRetry returns [" + this.maxDiscoverRetry + "]");
		}

		return this.maxDiscoverRetry;
	}

	public String getCharacterEncoding() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getCharacterEncoding returns [" + this.characterEncoding + "]");
		}

		return this.characterEncoding;
	}

	public long getCacheCleanupFrequency() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getCacheCleanupFrequency returns [" + this.cacheCleanupFrequency + "]");
		}

		return this.cacheCleanupFrequency;
	}

	public int getAxAttributeCount() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getAxAttributeCount returns [" + this.axAttributeCount + "]");
		}

		return this.axAttributeCount;
	}

	public String getJNDICacheName() {
		return this.JNDICacheName;
	}

	public String getRealmIdentifier() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getRealmIdentifier returns [" + this.realmIdentifier + "]");
		}

		return this.realmIdentifier;
	}

	public String getGroupIdentifier() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getGroupIdentifier returns [" + this.groupIdentifier + "]");
		}

		return this.groupIdentifier;
	}

	public boolean isIncludeCustomCacheKeyInSubject() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isIncludeCustomCacheKeyInSubject returns [" + this.includeCustomCacheKeyInSubject + "]");
		}

		return this.includeCustomCacheKeyInSubject;
	}

	public boolean httpOnly() {
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "httpOnly returns [" + this.httpOnly + "]");
		}

		return this.httpOnly;
	}
}