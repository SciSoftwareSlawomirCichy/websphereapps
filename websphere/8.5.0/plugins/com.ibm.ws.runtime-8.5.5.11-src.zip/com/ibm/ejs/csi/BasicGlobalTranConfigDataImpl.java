package com.ibm.ejs.csi;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.dopriv.SystemGetPropertyPrivileged;
import com.ibm.websphere.csi.GlobalTranConfigData;
import com.ibm.ws.security.util.AccessController;

public class BasicGlobalTranConfigDataImpl implements GlobalTranConfigData {
	private static final TraceComponent tc = Tr.register(BasicGlobalTranConfigDataImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	protected int timeout = 0;
	protected boolean isSendWSAT = false;

	public BasicGlobalTranConfigDataImpl() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>");
		}

	}

	public int getTransactionTimeout() {
		return this.timeout;
	}

	public boolean isSendWSAT() {
		return this.isSendWSAT;
	}

	public String toString() {
		String separator = (String) AccessController
				.doPrivileged(new SystemGetPropertyPrivileged("line.separator", "\n"));
		String sep = "                                 ";
		StringBuilder sb = new StringBuilder();
		sb.append(separator).append(sep).append("      ****** GLOBAL-TRANSACTION *******");
		sb.append(separator).append(sep).append("Timeout=").append(this.timeout);
		sb.append(separator).append(sep).append("isSendWSAT=").append(this.isSendWSAT);
		return sb.toString();
	}
}