package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_en extends ListResourceBundle {
	private static final Object[][] resources = new Object[0][];

	public Object[][] getContents() {
		return resources;
	}
}