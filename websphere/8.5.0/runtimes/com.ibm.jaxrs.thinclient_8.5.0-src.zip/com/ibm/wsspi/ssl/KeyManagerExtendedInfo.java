package com.ibm.wsspi.ssl;

import java.security.KeyStore;
import java.util.Properties;
import javax.net.ssl.X509KeyManager;

public interface KeyManagerExtendedInfo {
	void setCustomProperties(Properties var1);

	void setSSLConfig(Properties var1);

	void setDefaultX509KeyManager(X509KeyManager var1);

	void setKeyStore(KeyStore var1);

	void setKeyStoreServerAlias(String var1);

	void setKeyStoreClientAlias(String var1);
}