package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.Table.Cell;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.CompatibleWith;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public interface Table<R, C, V> {
	boolean contains(@NullableDecl @CompatibleWith("R") Object var1, @NullableDecl @CompatibleWith("C") Object var2);

	boolean containsRow(@NullableDecl @CompatibleWith("R") Object var1);

	boolean containsColumn(@NullableDecl @CompatibleWith("C") Object var1);

	boolean containsValue(@NullableDecl @CompatibleWith("V") Object var1);

	V get(@NullableDecl @CompatibleWith("R") Object var1, @NullableDecl @CompatibleWith("C") Object var2);

	boolean isEmpty();

	int size();

	boolean equals(@NullableDecl Object var1);

	int hashCode();

	void clear();

	@NullableDecl
	@CanIgnoreReturnValue
	V put(R var1, C var2, V var3);

	void putAll(Table<? extends R, ? extends C, ? extends V> var1);

	@NullableDecl
	@CanIgnoreReturnValue
	V remove(@NullableDecl @CompatibleWith("R") Object var1, @NullableDecl @CompatibleWith("C") Object var2);

	Map<C, V> row(R var1);

	Map<R, V> column(C var1);

	Set<Cell<R, C, V>> cellSet();

	Set<R> rowKeySet();

	Set<C> columnKeySet();

	Collection<V> values();

	Map<R, Map<C, V>> rowMap();

	Map<C, Map<R, V>> columnMap();
}