package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.collect.TreeRangeSet.AsRanges;
import com.google.common.collect.TreeRangeSet.Complement;
import com.google.common.collect.TreeRangeSet.SubRangeSet;
import java.io.Serializable;
import java.util.NavigableMap;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Beta
@GwtIncompatible
public class TreeRangeSet<C extends Comparable<?>> extends AbstractRangeSet<C> implements Serializable {
	@VisibleForTesting
	final NavigableMap<Cut<C>, Range<C>> rangesByLowerBound;
	@MonotonicNonNullDecl
	private transient Set<Range<C>> asRanges;
	@MonotonicNonNullDecl
	private transient Set<Range<C>> asDescendingSetOfRanges;
	@MonotonicNonNullDecl
	private transient RangeSet<C> complement;

	public static <C extends Comparable<?>> TreeRangeSet<C> create() {
		return new TreeRangeSet(new TreeMap());
	}

	public static <C extends Comparable<?>> TreeRangeSet<C> create(RangeSet<C> rangeSet) {
		TreeRangeSet<C> result = create();
		result.addAll(rangeSet);
		return result;
	}

	public static <C extends Comparable<?>> TreeRangeSet<C> create(Iterable<Range<C>> ranges) {
		TreeRangeSet<C> result = create();
		result.addAll(ranges);
		return result;
	}

	private TreeRangeSet(NavigableMap<Cut<C>, Range<C>> rangesByLowerCut) {
		this.rangesByLowerBound = rangesByLowerCut;
	}

	public Set<Range<C>> asRanges() {
		Set<Range<C>> result = this.asRanges;
		return result == null ? (this.asRanges = new AsRanges(this, this.rangesByLowerBound.values())) : result;
	}

	public Set<Range<C>> asDescendingSetOfRanges() {
		Set<Range<C>> result = this.asDescendingSetOfRanges;
		return result == null
				? (this.asDescendingSetOfRanges = new AsRanges(this, this.rangesByLowerBound.descendingMap().values()))
				: result;
	}

	@NullableDecl
	public Range<C> rangeContaining(C value) {
		Preconditions.checkNotNull(value);
		Entry<Cut<C>, Range<C>> floorEntry = this.rangesByLowerBound.floorEntry(Cut.belowValue(value));
		return floorEntry != null && ((Range) floorEntry.getValue()).contains(value)
				? (Range) floorEntry.getValue()
				: null;
	}

	public boolean intersects(Range<C> range) {
		Preconditions.checkNotNull(range);
		Entry<Cut<C>, Range<C>> ceilingEntry = this.rangesByLowerBound.ceilingEntry(range.lowerBound);
		if (ceilingEntry != null && ((Range) ceilingEntry.getValue()).isConnected(range)
				&& !((Range) ceilingEntry.getValue()).intersection(range).isEmpty()) {
			return true;
		} else {
			Entry<Cut<C>, Range<C>> priorEntry = this.rangesByLowerBound.lowerEntry(range.lowerBound);
			return priorEntry != null && ((Range) priorEntry.getValue()).isConnected(range)
					&& !((Range) priorEntry.getValue()).intersection(range).isEmpty();
		}
	}

	public boolean encloses(Range<C> range) {
		Preconditions.checkNotNull(range);
		Entry<Cut<C>, Range<C>> floorEntry = this.rangesByLowerBound.floorEntry(range.lowerBound);
		return floorEntry != null && ((Range) floorEntry.getValue()).encloses(range);
	}

	@NullableDecl
	private Range<C> rangeEnclosing(Range<C> range) {
		Preconditions.checkNotNull(range);
		Entry<Cut<C>, Range<C>> floorEntry = this.rangesByLowerBound.floorEntry(range.lowerBound);
		return floorEntry != null && ((Range) floorEntry.getValue()).encloses(range)
				? (Range) floorEntry.getValue()
				: null;
	}

	public Range<C> span() {
		Entry<Cut<C>, Range<C>> firstEntry = this.rangesByLowerBound.firstEntry();
		Entry<Cut<C>, Range<C>> lastEntry = this.rangesByLowerBound.lastEntry();
		if (firstEntry == null) {
			throw new NoSuchElementException();
		} else {
			return Range.create(((Range) firstEntry.getValue()).lowerBound, ((Range) lastEntry.getValue()).upperBound);
		}
	}

	public void add(Range<C> rangeToAdd) {
		Preconditions.checkNotNull(rangeToAdd);
		if (!rangeToAdd.isEmpty()) {
			Cut<C> lbToAdd = rangeToAdd.lowerBound;
			Cut<C> ubToAdd = rangeToAdd.upperBound;
			Entry<Cut<C>, Range<C>> entryBelowLB = this.rangesByLowerBound.lowerEntry(lbToAdd);
			if (entryBelowLB != null) {
				Range<C> rangeBelowLB = (Range) entryBelowLB.getValue();
				if (rangeBelowLB.upperBound.compareTo(lbToAdd) >= 0) {
					if (rangeBelowLB.upperBound.compareTo(ubToAdd) >= 0) {
						ubToAdd = rangeBelowLB.upperBound;
					}

					lbToAdd = rangeBelowLB.lowerBound;
				}
			}

			Entry<Cut<C>, Range<C>> entryBelowUB = this.rangesByLowerBound.floorEntry(ubToAdd);
			if (entryBelowUB != null) {
				Range<C> rangeBelowUB = (Range) entryBelowUB.getValue();
				if (rangeBelowUB.upperBound.compareTo(ubToAdd) >= 0) {
					ubToAdd = rangeBelowUB.upperBound;
				}
			}

			this.rangesByLowerBound.subMap(lbToAdd, ubToAdd).clear();
			this.replaceRangeWithSameLowerBound(Range.create(lbToAdd, ubToAdd));
		}
	}

	public void remove(Range<C> rangeToRemove) {
		Preconditions.checkNotNull(rangeToRemove);
		if (!rangeToRemove.isEmpty()) {
			Entry<Cut<C>, Range<C>> entryBelowLB = this.rangesByLowerBound.lowerEntry(rangeToRemove.lowerBound);
			if (entryBelowLB != null) {
				Range<C> rangeBelowLB = (Range) entryBelowLB.getValue();
				if (rangeBelowLB.upperBound.compareTo(rangeToRemove.lowerBound) >= 0) {
					if (rangeToRemove.hasUpperBound()
							&& rangeBelowLB.upperBound.compareTo(rangeToRemove.upperBound) >= 0) {
						this.replaceRangeWithSameLowerBound(
								Range.create(rangeToRemove.upperBound, rangeBelowLB.upperBound));
					}

					this.replaceRangeWithSameLowerBound(
							Range.create(rangeBelowLB.lowerBound, rangeToRemove.lowerBound));
				}
			}

			Entry<Cut<C>, Range<C>> entryBelowUB = this.rangesByLowerBound.floorEntry(rangeToRemove.upperBound);
			if (entryBelowUB != null) {
				Range<C> rangeBelowUB = (Range) entryBelowUB.getValue();
				if (rangeToRemove.hasUpperBound() && rangeBelowUB.upperBound.compareTo(rangeToRemove.upperBound) >= 0) {
					this.replaceRangeWithSameLowerBound(
							Range.create(rangeToRemove.upperBound, rangeBelowUB.upperBound));
				}
			}

			this.rangesByLowerBound.subMap(rangeToRemove.lowerBound, rangeToRemove.upperBound).clear();
		}
	}

	private void replaceRangeWithSameLowerBound(Range<C> range) {
		if (range.isEmpty()) {
			this.rangesByLowerBound.remove(range.lowerBound);
		} else {
			this.rangesByLowerBound.put(range.lowerBound, range);
		}

	}

	public RangeSet<C> complement() {
		RangeSet<C> result = this.complement;
		return result == null ? (this.complement = new Complement(this)) : result;
	}

	public RangeSet<C> subRangeSet(Range<C> view) {
		return (RangeSet) (view.equals(Range.all()) ? this : new SubRangeSet(this, view));
	}
}