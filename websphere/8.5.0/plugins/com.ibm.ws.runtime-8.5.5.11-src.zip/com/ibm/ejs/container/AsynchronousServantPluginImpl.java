package com.ibm.ejs.container;

import com.ibm.CORBA.iiop.AsynchronousServantPlugin;
import com.ibm.CORBA.iiop.ORB;
import com.ibm.CORBA.iiop.StalledRequestObserverFactory;
import com.ibm.ejs.container.AsynchronousServantPluginImpl.WaitForResultRequest;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import java.util.Observer;
import org.omg.CORBA.portable.InputStream;

public class AsynchronousServantPluginImpl implements AsynchronousServantPlugin {
	static final TraceComponent tc = Tr.register(AsynchronousServantPluginImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public void init(ORB arg0) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "init");
		}

	}

	public boolean isAsynchServant(Object servant) {
		boolean result = servant instanceof RemoteAsyncResultImpl;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isAsynchServant: " + Util.identity(servant) + " = " + result);
		}

		return result;
	}

	public boolean shouldRequestBeStalled(String operation, Object servant, InputStream input, Object[] orbData) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "shouldRequestBeStalled: " + operation + ", " + Util.identity(servant) + ", "
					+ Util.identity(input));
		}

		boolean stall;
		if (operation.equals("waitForResult")) {
			RemoteAsyncResultImpl asyncResult = (RemoteAsyncResultImpl) servant;
			if (asyncResult.isDone()) {
				stall = false;
			} else {
				long requestedWaitTime = input.read_longlong();
				long actualWaitTime = requestedWaitTime;
				if (requestedWaitTime <= 0L || requestedWaitTime > ContainerProperties.MaxAsyncResultWaitTime) {
					actualWaitTime = ContainerProperties.MaxAsyncResultWaitTime;
				}

				WaitForResultRequest request = new WaitForResultRequest(asyncResult);
				Observer observer = StalledRequestObserverFactory.createObserver(request, orbData);
				request.ivObserver = observer;
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "requestedWaitTime=" + requestedWaitTime + ", actualWaitTime=" + actualWaitTime
							+ ", request=" + request);
				}

				request.initialize(actualWaitTime);
				stall = true;
			}
		} else {
			stall = false;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "shouldRequestBeStalled: " + stall);
		}

		return stall;
	}
}