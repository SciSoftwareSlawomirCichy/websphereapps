package com.google.inject.matcher;

import com.google.inject.internal.Preconditions;
import com.google.inject.matcher.Matchers.1;
import com.google.inject.matcher.Matchers.AnnotatedWith;
import com.google.inject.matcher.Matchers.AnnotatedWithType;
import com.google.inject.matcher.Matchers.Any;
import com.google.inject.matcher.Matchers.IdenticalTo;
import com.google.inject.matcher.Matchers.InPackage;
import com.google.inject.matcher.Matchers.InSubpackage;
import com.google.inject.matcher.Matchers.Not;
import com.google.inject.matcher.Matchers.Only;
import com.google.inject.matcher.Matchers.Returns;
import com.google.inject.matcher.Matchers.SubclassesOf;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;

public class Matchers {
	private static final Matcher<Object> ANY = new Any((1)null);

	public static Matcher<Object> any() {
		return ANY;
	}

	public static <T> Matcher<T> not(Matcher<? super T> p) {
      return new Not(p, (1)null);
   }

	private static void checkForRuntimeRetention(Class<? extends Annotation> annotationType) {
		Retention retention = (Retention) annotationType.getAnnotation(Retention.class);
		Preconditions.checkArgument(retention != null && retention.value() == RetentionPolicy.RUNTIME,
				"Annotation " + annotationType.getSimpleName() + " is missing RUNTIME retention");
	}

	public static Matcher<AnnotatedElement> annotatedWith(Class<? extends Annotation> annotationType) {
		return new AnnotatedWithType(annotationType);
	}

	public static Matcher<AnnotatedElement> annotatedWith(Annotation annotation) {
		return new AnnotatedWith(annotation);
	}

	public static Matcher<Class> subclassesOf(Class<?> superclass) {
		return new SubclassesOf(superclass);
	}

	public static Matcher<Object> only(Object value) {
		return new Only(value);
	}

	public static Matcher<Object> identicalTo(Object value) {
		return new IdenticalTo(value);
	}

	public static Matcher<Class> inPackage(Package targetPackage) {
		return new InPackage(targetPackage);
	}

	public static Matcher<Class> inSubpackage(String targetPackageName) {
		return new InSubpackage(targetPackageName);
	}

	public static Matcher<Method> returns(Matcher<? super Class<?>> returnType) {
		return new Returns(returnType);
	}
}