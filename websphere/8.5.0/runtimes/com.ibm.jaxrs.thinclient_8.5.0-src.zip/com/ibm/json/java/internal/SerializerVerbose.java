package com.ibm.json.java.internal;

import java.io.IOException;
import java.io.Writer;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class SerializerVerbose extends Serializer {
	private int indent = 0;

	public SerializerVerbose(Writer var1) {
		super(var1);
	}

	public void space() throws IOException {
		this.writeRawString(" ");
	}

	public void newLine() throws IOException {
		this.writeRawString("\n");
	}

	public void indent() throws IOException {
		for (int var1 = 0; var1 < this.indent; ++var1) {
			this.writeRawString("   ");
		}

	}

	public void indentPush() {
		++this.indent;
	}

	public void indentPop() {
		--this.indent;
		if (this.indent < 0) {
			throw new IllegalStateException();
		}
	}

	public List getPropertyNames(Map var1) {
		List var2 = super.getPropertyNames(var1);
		Collections.sort(var2);
		return var2;
	}
}