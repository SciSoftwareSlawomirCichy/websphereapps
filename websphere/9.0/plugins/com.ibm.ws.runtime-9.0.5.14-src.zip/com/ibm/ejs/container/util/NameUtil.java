package com.ibm.ejs.container.util;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.javaee.dd.ejb.ComponentViewableBean;
import com.ibm.ws.javaee.dd.ejb.EnterpriseBean;
import com.ibm.ws.javaee.dd.ejb.Entity;
import com.ibm.ws.javaee.dd.ejb.Session;
import java.util.StringTokenizer;

public final class NameUtil {
	private static final TraceComponent tc = Tr.register(NameUtil.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	public static final String homeRemotePrefix = "EJSRemote";
	public static final String homeBeanPrefix = "EJS";
	public static final String remotePrefix = "EJSRemote";
	public static final String concreteBeanPrefix = "Concrete";
	public static final String persisterPrefix = "EJSJDBCPersister";
	public static final String endpointPrefix = "WSEJBProxy";
	public static final String mdbProxyPrefix = "MDBProxy";
	public static final String homeLocalPrefix = "EJSLocal";
	public static final String localPrefix = "EJSLocal";
	public static final String deployPackagePrefix = "com.ibm.ejs.container.deploy.";
	public static final int Max_Gen_File_Size = 100;
	public static final int Max_EjbName_Size = 32;
	public static final String UNKNOWN = "UNKNOWN";
	public static final String SINGLETON = "SG";
	public static final String STATELESS = "SL";
	public static final String STATEFUL = "SF";
	public static final String BEAN_MANAGED = "BMP";
	public static final String CONTAINER_MANAGED = "CMP";
	public static final String MESSAGE_DRIVEN = "MDB";
	public static final String MANAGED_BEAN = "MB";
	public static final int EJB_1X = 1;
	public static final int EJB_2X = 2;
	public static final int EJB_3X = 3;
	private String ivBeanName = null;
	private String ivFullBeanName = null;
	private String ivBeanType = null;
	private String ivHashSuffix = null;
	private int ivHashVersion = -1;
	private int ivVersion = -1;
	private final String ivRemoteHomeInterface;
	private final String ivRemoteInterface;
	private final String ivLocalHomeInterface;
	private final String ivLocalInterface;
	private final String[] ivBusinessRemote;
	private final String[] ivBusinessLocal;
	private final String ivBeanClass;
	private final String ivPrimaryKey;

	private static String getRemoteInterfaceName(EnterpriseBean enterpriseBean) {
		return enterpriseBean instanceof ComponentViewableBean
				? ((ComponentViewableBean) enterpriseBean).getRemoteInterfaceName()
				: null;
	}

	public static String getRemoteImplClassName(EnterpriseBean enterpriseBean, boolean isPost11DD) {
		String remoteInterfaceName = getRemoteInterfaceName(enterpriseBean);
		if (remoteInterfaceName == null) {
			return null;
		} else {
			String packageName = packageName(remoteInterfaceName);
			String remoteName = encodeBeanInterfacesName(enterpriseBean, isPost11DD, false, false, false);
			StringBuffer result = new StringBuffer();
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJSRemote");
			result.append(getUniquePrefix(enterpriseBean));
			result.append(remoteName);
			return result.toString();
		}
	}

	private static String getLocalInterfaceName(EnterpriseBean enterpriseBean) {
		return enterpriseBean instanceof ComponentViewableBean
				? ((ComponentViewableBean) enterpriseBean).getLocalInterfaceName()
				: null;
	}

	public static String getLocalImplClassName(EnterpriseBean enterpriseBean, boolean isPost11DD) {
		String localInterfaceName = getLocalInterfaceName(enterpriseBean);
		if (localInterfaceName == null) {
			return null;
		} else {
			String packageName = packageName(localInterfaceName);
			String localName = encodeBeanInterfacesName(enterpriseBean, isPost11DD, true, false, false);
			StringBuffer result = new StringBuffer();
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJSLocal");
			result.append(getUniquePrefix(enterpriseBean));
			result.append(localName);
			return result.toString();
		}
	}

	private static String getHomeInterfaceName(EnterpriseBean enterpriseBean) {
		return enterpriseBean instanceof ComponentViewableBean
				? ((ComponentViewableBean) enterpriseBean).getHomeInterfaceName()
				: null;
	}

	public static String getHomeRemoteImplClassName(EnterpriseBean enterpriseBean, boolean isPost11DD) {
		String homeInterfaceName = getHomeInterfaceName(enterpriseBean);
		if (homeInterfaceName == null) {
			return null;
		} else {
			String remoteInterfaceName = getRemoteInterfaceName(enterpriseBean);
			String packageName = packageName(remoteInterfaceName);
			String homeName = encodeBeanInterfacesName(enterpriseBean, isPost11DD, false, true, false);
			StringBuffer result = new StringBuffer();
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJSRemote");
			result.append(getUniquePrefix(enterpriseBean));
			result.append(homeName);
			return result.toString();
		}
	}

	private static String getLocalHomeInterfaceName(EnterpriseBean enterpriseBean) {
		return enterpriseBean instanceof ComponentViewableBean
				? ((ComponentViewableBean) enterpriseBean).getLocalHomeInterfaceName()
				: null;
	}

	public static String getHomeLocalImplClassName(EnterpriseBean enterpriseBean, boolean isPost11DD) {
		String homeLocalInterfaceName = getLocalHomeInterfaceName(enterpriseBean);
		if (homeLocalInterfaceName == null) {
			return null;
		} else {
			String localInterfaceName = getLocalInterfaceName(enterpriseBean);
			String packageName = packageName(localInterfaceName);
			String homeLocalName = encodeBeanInterfacesName(enterpriseBean, isPost11DD, true, true, false);
			StringBuffer result = new StringBuffer();
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJSLocal");
			result.append(getUniquePrefix(enterpriseBean));
			result.append(homeLocalName);
			return result.toString();
		}
	}

	public static String getAggregateLocalImplClassName(String localImplClassName) {
		StringBuilder aggregateName = new StringBuilder(localImplClassName);
		int index = localImplClassName.lastIndexOf("EJSLocal");
		aggregateName.setCharAt(index + "EJSLocal".length(), 'A');
		return aggregateName.toString();
	}

	public static String getHomeBeanClassName(EnterpriseBean enterpriseBean, boolean isPost11DD) {
		String packageName = null;
		String homeInterfaceName = getHomeInterfaceName(enterpriseBean);
		if (homeInterfaceName == null) {
			homeInterfaceName = getLocalHomeInterfaceName(enterpriseBean);
		}

		if (homeInterfaceName != null) {
			packageName = packageName(homeInterfaceName);
			StringBuffer result = new StringBuffer();
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJS");
			result.append(getUniquePrefix(enterpriseBean));
			String homeName = encodeBeanInterfacesName(enterpriseBean, isPost11DD, false, true, true);
			result.append(homeName);
			return result.toString();
		} else {
			return null;
		}
	}

	public static String getConcreteBeanClassName(EnterpriseBean enterpriseBean) {
		String beanClassName = enterpriseBean.getEjbClassName();
		String packageName = packageName(beanClassName);
		String beanName = encodeBeanInterfacesName(enterpriseBean, true, false, false, false);
		StringBuffer result = new StringBuffer();
		if (packageName != null) {
			result.append(packageName);
			result.append('.');
		}

		result.append("Concrete");
		result.append(beanName);
		return result.toString();
	}

	public static String getDeployedPersisterClassName(EnterpriseBean enterpriseBean) {
		String beanClassName = enterpriseBean.getEjbClassName();
		String packageName = packageName(beanClassName);
		String beanName = relativeName(beanClassName);
		StringBuffer result = new StringBuffer();
		if (packageName != null) {
			result.append(packageName);
			result.append('.');
		}

		result.append("EJSJDBCPersister");
		result.append(getUniquePrefix(enterpriseBean));
		result.append(beanName);
		return result.toString();
	}

	public static String getDeployedPersisterClassName(Object enterpriseBean) {
		return getDeployedPersisterClassName((EnterpriseBean) enterpriseBean);
	}

	public static String relativeName(String className) {
		return relativeName(className, ".");
	}

	public static String relativeName(String className, String delim) {
		String tmp = null;

		for (StringTokenizer st = new StringTokenizer(className, delim, false); st
				.hasMoreElements(); tmp = st.nextToken()) {
			;
		}

		return tmp;
	}

	public static String packageName(String className) {
		int index = className.lastIndexOf(46);
		return index != -1 ? className.substring(0, index) : null;
	}

	public static String getUniquePrefix(EnterpriseBean enterpriseBean) {
		String prefix = "";
		switch (enterpriseBean.getKindValue()) {
			case 0 :
				switch (((Session) enterpriseBean).getSessionTypeValue()) {
					case 0 :
						prefix = "Stateful";
						return prefix;
					case 1 :
						prefix = "Stateless";
						return prefix;
					case 2 :
						prefix = "Singleton";
						return prefix;
					default :
						if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
							Tr.event(tc, "Unknown session bean type");
						}

						return prefix;
				}
			case 1 :
				if (((Entity) enterpriseBean).getPersistenceTypeValue() == 1) {
					prefix = "CMP";
				} else {
					prefix = "BMP";
				}
				break;
			case 2 :
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "EJB Internal Error - MessageDriven has no unique prefix");
				}
				break;
			default :
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Unknown bean type");
				}
		}

		return prefix;
	}

	public static String getCreateTableStringsMethodNameBase() {
		return "getCreateTableSQLStrings_";
	}

	public static final String getHashStr(EnterpriseBean enterpriseBean) {
		StringBuffer hashStr = new StringBuffer(enterpriseBean.getName());
		String remoteHomeInterfaceName = getHomeInterfaceName(enterpriseBean);
		if (remoteHomeInterfaceName != null) {
			hashStr.append(remoteHomeInterfaceName);
		}

		String remoteBusinessInterfaceName = getRemoteInterfaceName(enterpriseBean);
		if (remoteBusinessInterfaceName != null) {
			hashStr.append(remoteBusinessInterfaceName);
		}

		String localHomeInterfaceName = getLocalHomeInterfaceName(enterpriseBean);
		if (localHomeInterfaceName != null) {
			hashStr.append(localHomeInterfaceName);
		}

		String localBusinessInterfaceName = getLocalInterfaceName(enterpriseBean);
		if (localBusinessInterfaceName != null) {
			hashStr.append(localBusinessInterfaceName);
		}

		String beanClassName = enterpriseBean.getEjbClassName();
		hashStr.append(beanClassName);
		if (enterpriseBean.getKindValue() == 1) {
			hashStr.append(((Entity) enterpriseBean).getPrimaryKeyName());
		}

		return hashStr.toString();
	}

	public static final String getHashStr(Object enterpriseBean) {
		return getHashStr((EnterpriseBean) enterpriseBean);
	}

	private static final String encodeBeanInterfacesName(EnterpriseBean enterpriseBean, boolean isPost11DD,
			boolean isLocal, boolean isHome, boolean isBean) {
		String rtnStr = null;
		if (!isPost11DD) {
			if (isHome) {
				if (isLocal) {
					rtnStr = getLocalHomeInterfaceName(enterpriseBean);
				} else {
					rtnStr = getHomeInterfaceName(enterpriseBean);
				}

				if (isBean) {
					rtnStr = rtnStr + "Bean";
				}
			} else if (isLocal) {
				rtnStr = getLocalInterfaceName(enterpriseBean);
			} else {
				rtnStr = getRemoteInterfaceName(enterpriseBean);
			}

			return relativeName(rtnStr);
		} else {
			String ejbName = enterpriseBean.getName();
			rtnStr = translateEjbName(ejbName);
			String hashStr = getHashStr(enterpriseBean);
			if (isHome) {
				rtnStr = rtnStr + "Home";
			}

			if (isBean) {
				rtnStr = rtnStr + "Bean";
			}

			return rtnStr + "_" + BuzzHash.computeHashStringMid32Bit(hashStr);
		}
	}

	private static boolean allHexDigits(String str, int start, int end) {
		boolean rtn = true;

		for (int i = start; i < end; ++i) {
			if ("0123456789abcdefABCDEF".indexOf(str.charAt(i)) == -1) {
				rtn = false;
				break;
			}
		}

		return rtn;
	}

	public static final String updateFilenameHashCode(EnterpriseBean enterpriseBean, String oldName) {
		String newName = null;
		int len = oldName.length();
		int last_ = len > 9 && oldName.charAt(len - 9) == '_' ? len - 9 : -1;
		if (last_ != -1) {
			++last_;
			if (allHexDigits(oldName, last_, len)) {
				String hashStr = getHashStr(enterpriseBean);
				newName = oldName.substring(0, last_) + BuzzHash.computeHashStringMid32Bit(hashStr, true);
			}
		}

		return newName;
	}

	public static final String updateFilenameHashCode(Object enterpriseBean, String oldName) {
		return updateFilenameHashCode((EnterpriseBean) enterpriseBean, oldName);
	}

	private static String translateEjbName(String ejbName) {
		ejbName = ejbName.trim();
		int len = ejbName.length();
		if (len > 32) {
			len = 32;
		}

		char[] translated = new char[len];

		for (int i = 0; i < len; ++i) {
			char curChar = ejbName.charAt(i);
			translated[i] = Character.isLetterOrDigit(curChar) ? curChar : 95;
		}

		return new String(translated);
	}

	public static void dumpClassNames(EnterpriseBean enterpriseBean, boolean isPost11DD) {
		System.out.println("<NameUtil><EjbName          > " + enterpriseBean.getName() + ":" + isPost11DD);
		System.out.println("<NameUtil><RemoteWrapper    > " + getRemoteImplClassName(enterpriseBean, isPost11DD));
		System.out.println("<NameUtil><RemoteHomeWrapper> " + getHomeRemoteImplClassName(enterpriseBean, isPost11DD));
		System.out.println("<NameUtil><LocalWrapper     > " + getLocalImplClassName(enterpriseBean, isPost11DD));
		System.out.println("<NameUtil><LocalHomeWrapper > " + getHomeLocalImplClassName(enterpriseBean, isPost11DD));
		System.out.println("<NameUtil><HomeBean         > " + getHomeBeanClassName(enterpriseBean, isPost11DD));
		System.out.println("<NameUtil><ConcreateBean    > " + getConcreteBeanClassName(enterpriseBean));
		System.out.println("<NameUtil><Persister        > " + getDeployedPersisterClassName(enterpriseBean));
	}

	public NameUtil(String beanName, String remoteHomeInterface, String remoteInterface, String localHomeInterface,
			String localInterface, String[] remoteBusinessInterfaces, String[] localBusinessInterfaces,
			String beanClass, String primaryKey, String beanType, int version) {
		if (beanName == null) {
			throw new IllegalArgumentException("Bean Name not specified.");
		} else {
			this.ivBeanName = translateEjbName(beanName);
			this.ivFullBeanName = beanName;
			if (version >= 1 && version <= 3) {
				if (version == 3 && beanType == "CMP") {
					this.ivVersion = 2;
				} else {
					this.ivVersion = version;
				}

				if (beanType != "SG" && beanType != "SL" && beanType != "SF" && beanType != "CMP" && beanType != "BMP"
						&& beanType != "MDB" && beanType != "MB") {
					throw new IllegalArgumentException("Unsupported bean type : " + beanType);
				} else {
					switch (this.ivVersion) {
						case 1 :
						case 2 :
							if (beanType == "SL") {
								this.ivBeanType = "Stateless";
							} else if (beanType == "SF") {
								this.ivBeanType = "Stateful";
							} else {
								this.ivBeanType = beanType;
							}
							break;
						case 3 :
							this.ivBeanType = beanType;
					}

					this.ivRemoteHomeInterface = remoteHomeInterface;
					this.ivRemoteInterface = remoteInterface;
					this.ivLocalHomeInterface = localHomeInterface;
					this.ivLocalInterface = localInterface;
					this.ivBusinessRemote = remoteBusinessInterfaces;
					this.ivBusinessLocal = localBusinessInterfaces;
					this.ivBeanClass = beanClass;
					this.ivPrimaryKey = primaryKey;
					this.ivHashSuffix = this.getHashSuffix(this.ivVersion >= 3);
				}
			} else {
				throw new IllegalArgumentException("Unsupported module version : " + version);
			}
		}
	}

	public String getBusinessRemoteImplClassName(int index) {
		if (this.ivBusinessRemote != null && this.ivVersion >= 3) {
			String remoteInterface = this.ivBusinessRemote[index];
			StringBuffer result = new StringBuffer();
			String packageName = packageName(remoteInterface);
			if (packageName != null) {
				if (packageName.startsWith("java.")) {
					result.append("com.ibm.ejs.container.deploy.");
				}

				result.append(packageName);
				result.append('.');
			}

			result.append("EJSRemote");
			result.append(index);
			result.append(this.ivBeanType);
			result.append(this.ivBeanName);
			result.append('_');
			result.append(this.ivHashSuffix);
			return result.toString();
		} else {
			throw new IllegalStateException("Remote Business interfaces are not supported in EJB 1.x and 2.x modules");
		}
	}

	public String getBusinessLocalImplClassName(int index) {
		if (this.ivBusinessLocal != null && this.ivVersion >= 3) {
			String localInterface = this.ivBusinessLocal[index];
			String bindex = null;
			if (index == 0 && localInterface.equals(this.ivBeanClass)) {
				bindex = "N";
			} else {
				bindex = Integer.toString(index);
			}

			StringBuffer result = new StringBuffer();
			String packageName = packageName(localInterface);
			if (packageName != null) {
				if (packageName.startsWith("java.")) {
					result.append("com.ibm.ejs.container.deploy.");
				}

				result.append(packageName);
				result.append('.');
			}

			result.append("EJSLocal");
			result.append(bindex);
			result.append(this.ivBeanType);
			result.append(this.ivBeanName);
			result.append('_');
			result.append(this.ivHashSuffix);
			return result.toString();
		} else {
			throw new IllegalStateException("Local Business interfaces are not supported in EJB 1.x and 2.x modules");
		}
	}

	public String getRemoteImplClassName() {
		if (this.ivRemoteInterface == null) {
			return null;
		} else {
			StringBuffer result = new StringBuffer();
			String packageName = packageName(this.ivRemoteInterface);
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJSRemote");
			if (this.ivVersion >= 3) {
				result.append("C");
			}

			result.append(this.ivBeanType);
			if (this.ivVersion >= 2) {
				result.append(this.ivBeanName);
				result.append('_');
				result.append(this.ivHashSuffix);
			} else {
				result.append(relativeName(this.ivRemoteInterface));
				if (this.ivHashVersion > 0) {
					result.append('_');
					result.append(this.ivHashSuffix);
				}
			}

			return result.toString();
		}
	}

	public String getLocalImplClassName() {
		if (this.ivLocalInterface == null) {
			return null;
		} else if (this.ivVersion == 1) {
			throw new IllegalStateException("Local interfaces are not supported in EJB 1.x modules");
		} else {
			StringBuffer result = new StringBuffer();
			String packageName = packageName(this.ivLocalInterface);
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJSLocal");
			if (this.ivVersion >= 3) {
				result.append("C");
			}

			result.append(this.ivBeanType);
			result.append(this.ivBeanName);
			result.append('_');
			result.append(this.ivHashSuffix);
			return result.toString();
		}
	}

	public String getHomeRemoteImplClassName() {
		if (this.ivRemoteHomeInterface == null) {
			return null;
		} else {
			StringBuffer result = new StringBuffer();
			String packageName = packageName(this.ivRemoteInterface);
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJSRemote");
			if (this.ivVersion >= 3) {
				result.append("C");
			}

			result.append(this.ivBeanType);
			if (this.ivVersion >= 2) {
				result.append(this.ivBeanName);
				result.append("Home");
				result.append('_');
				result.append(this.ivHashSuffix);
			} else {
				result.append(relativeName(this.ivRemoteHomeInterface));
				if (this.ivHashVersion > 0) {
					result.append('_');
					result.append(this.ivHashSuffix);
				}
			}

			return result.toString();
		}
	}

	public String getHomeLocalImplClassName() {
		if (this.ivLocalHomeInterface == null) {
			return null;
		} else if (this.ivVersion == 1) {
			throw new IllegalStateException("Local interfaces are not supported in EJB 1.x modules");
		} else {
			StringBuffer result = new StringBuffer();
			String packageName = packageName(this.ivLocalInterface);
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJSLocal");
			if (this.ivVersion >= 3) {
				result.append("C");
			}

			result.append(this.ivBeanType);
			result.append(this.ivBeanName);
			result.append("Home");
			result.append('_');
			result.append(this.ivHashSuffix);
			return result.toString();
		}
	}

	public String getHomeBeanClassName() {
		String homeInterface = this.ivRemoteHomeInterface == null
				? this.ivLocalHomeInterface
				: this.ivRemoteHomeInterface;
		if (homeInterface == null) {
			return null;
		} else {
			StringBuffer result = new StringBuffer();
			String packageName = packageName(homeInterface);
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("EJS");
			if (this.ivVersion >= 3) {
				result.append("C");
			}

			result.append(this.ivBeanType);
			if (this.ivVersion >= 2) {
				result.append(this.ivBeanName);
				result.append("HomeBean");
				result.append('_');
				result.append(this.ivHashSuffix);
			} else {
				result.append(relativeName(this.ivRemoteHomeInterface));
				result.append("Bean");
				if (this.ivHashVersion > 0) {
					result.append('_');
					result.append(this.ivHashSuffix);
				}
			}

			return result.toString();
		}
	}

	public String getConcreteBeanClassName() {
		if (this.ivVersion != 2 && this.ivBeanType != "CMP") {
			return null;
		} else {
			StringBuffer result = new StringBuffer();
			String packageName = packageName(this.ivBeanClass);
			if (packageName != null) {
				result.append(packageName);
				result.append('.');
			}

			result.append("Concrete");
			result.append(this.ivBeanName);
			result.append('_');
			result.append(this.ivHashSuffix);
			return result.toString();
		}
	}

	public String getDeployedPersisterClassName() {
		StringBuffer result = new StringBuffer();
		String packageName = packageName(this.ivBeanClass);
		if (packageName != null) {
			result.append(packageName);
			result.append('.');
		}

		result.append("EJSJDBCPersister");
		result.append(this.ivBeanType);
		result.append(relativeName(this.ivBeanClass));
		return result.toString();
	}

	public String getWebServiceEndpointProxyClassName() {
		StringBuilder result = new StringBuilder();
		String packageName = packageName(this.ivBeanClass);
		if (packageName != null) {
			result.append(packageName);
			result.append('.');
		}

		result.append("WSEJBProxy");
		result.append(this.ivBeanType);
		result.append(this.ivBeanName);
		result.append('_');
		result.append(this.ivHashSuffix);
		return result.toString();
	}

	public String getMDBProxyClassName() {
		StringBuilder result = new StringBuilder();
		String packageName = packageName(this.ivBeanClass);
		if (packageName != null) {
			result.append(packageName);
			result.append('.');
		}

		result.append("MDBProxy");
		result.append(this.ivBeanName);
		result.append('_');
		result.append(this.ivHashSuffix);
		return result.toString();
	}

	private final String getHashSuffix(boolean modified) {
		StringBuffer hashStr = new StringBuffer(this.ivFullBeanName);
		if (this.ivRemoteHomeInterface != null) {
			hashStr.append(this.ivRemoteHomeInterface);
		}

		if (this.ivRemoteInterface != null) {
			hashStr.append(this.ivRemoteInterface);
		}

		if (this.ivLocalHomeInterface != null) {
			hashStr.append(this.ivLocalHomeInterface);
		}

		if (this.ivLocalInterface != null) {
			hashStr.append(this.ivLocalInterface);
		}

		int i;
		if (this.ivBusinessRemote != null) {
			for (i = 0; i < this.ivBusinessRemote.length; ++i) {
				hashStr.append(this.ivBusinessRemote[i]);
			}
		}

		if (this.ivBusinessLocal != null) {
			for (i = 0; i < this.ivBusinessLocal.length; ++i) {
				hashStr.append(this.ivBusinessLocal[i]);
			}
		}

		hashStr.append(this.ivBeanClass);
		if (this.ivPrimaryKey != null) {
			hashStr.append(this.ivPrimaryKey);
		}

		this.ivHashVersion = modified ? 2 : 1;
		return BuzzHash.computeHashStringMid32Bit(hashStr.toString(), modified);
	}

	public final String updateFilenameHashCode(String fileName) {
		String nextName = null;
		int len = fileName.length();
		int last_ = len > 9 && fileName.charAt(len - 9) == '_' ? len - 9 : -1;
		if (last_ != -1) {
			++last_;
			if (allHexDigits(fileName, last_, len)) {
				if (this.ivHashVersion == 1) {
					this.ivHashSuffix = this.getHashSuffix(true);
					nextName = fileName.substring(0, last_) + this.ivHashSuffix;
				} else if (this.ivHashVersion == 2 && this.ivVersion == 1) {
					this.ivHashVersion = 0;
					nextName = fileName.substring(0, last_ - 1);
				}
			}
		}

		return nextName;
	}
}