package com.ibm.ws.wim.adapter.db;

public class DBEntity {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private long entityId;
	private String entityType;
	private String uniqueId;
	private String uniqueName;
	private String truncUniqueName;
	private String logonId;
	private byte[] logonPassword;
	private String salt;

	public String getLogonId() {
		return this.logonId;
	}

	public byte[] getLogonPassword() {
		return this.logonPassword;
	}

	public String getSalt() {
		return this.salt;
	}

	public void setLogonId(String var1) {
		this.logonId = var1;
	}

	public void setLogonPassword(byte[] var1) {
		this.logonPassword = var1;
	}

	public void setSalt(String var1) {
		this.salt = var1;
	}

	public long getEntityId() {
		return this.entityId;
	}

	public void setEntityId(long var1) {
		this.entityId = var1;
	}

	public String getEntityType() {
		return this.entityType;
	}

	public void setEntityType(String var1) {
		this.entityType = var1;
	}

	public String getTruncUniqueName() {
		return this.truncUniqueName;
	}

	public void setTruncUniqueName(String var1) {
		this.truncUniqueName = var1;
	}

	public String getUniqueId() {
		return this.uniqueId;
	}

	public void setUniqueId(String var1) {
		this.uniqueId = var1;
	}

	public String getUniqueName() {
		return this.uniqueName;
	}

	public void setUniqueName(String var1) {
		this.uniqueName = var1;
	}
}