package com.ibm.ejs.cm.pool;

import com.ibm.ejs.cm.CMProperties;
import com.ibm.ejs.cm.CMPropertiesImpl;
import com.ibm.ejs.cm.DSFactoryImpl;
import com.ibm.ejs.cm.DataSourceImpl;
import com.ibm.ejs.cm.cache.StatementCache;
import com.ibm.ejs.cm.portability.ConnectionProxyFactory;
import com.ibm.ejs.cm.portability.ErrorMap;
import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.cm.portability.PortabilityLayerExt;
import com.ibm.ejs.cm.portability.PortabilityLayerFactory;
import com.ibm.ejs.cm.portability.PortableDataSource;
import com.ibm.ejs.cm.portability.ResourceAllocationException;
import com.ibm.ejs.cm.proxy.ConnectionProxy;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import com.ibm.ejs.util.FastHashtable;
import com.ibm.ejs.util.Queue;
import com.ibm.ejs.util.am.Alarm;
import com.ibm.ejs.util.am.AlarmListener;
import com.ibm.ejs.util.am.AlarmManager;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.websphere.pmi.ConnPoolPerf;
import com.ibm.ws.Transaction.TransactionManagerFactory;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.Transaction.XAResourceInfo;
import com.ibm.ws.ffdc.FFDC;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.pmi.server.PmiFactory;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Enumeration;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Logger;
import javax.management.ObjectName;
import javax.management.QueryExp;

public final class ConnectionPool implements PortableDataSource, ConnectOEventListener, AlarmListener {
	private static final TraceNLS NLS;
	static final String NULL_USERNAME = "_null_username";
	static final String NULL_PASSWORD = "_null_password";
	private static final int CREATE_RETRY_LIMIT = 4;
	private final ConnectionFactory factory;
	private final CMPropertiesImpl attrs;
	private final String dsPassword;
	private final FastHashtable connectionsByTx;
	private final FastHashtable connectionsByUser;
	private final int statementCacheSize;
	private ErrorMap errorMap;
	private final Vector connections;
	private Queue waiters;
	private Queue freeList;
	private PortabilityLayer portability;
	private int connectionCount;
	private final syncInt connectionsInUse;
	private boolean destroyed;
	protected String xaResourceFactoryName;
	protected XAResourceInfo xaResourceInfo;
	private Alarm orphanAlarm;
	private static final Object ORPHAN_ALARM;
	private Alarm agedAlarm;
	private static final Object AGED_ALARM;
	private static final TraceComponent tc;
	protected ConnPoolPerf pmiData;

	public ConnectionPool(ConnectionFactory connectionFactory, CMProperties attrs, String password)
			throws SQLException {
		this(connectionFactory, attrs, (String) null, (XAResourceInfo) null, password);
	}

	public ConnectionPool(ConnectionFactory connectionFactory, CMProperties attributes, String xaResourceFactoryName,
			XAResourceInfo xaResourceInfo, String password) throws SQLException {
		this.connectionsByTx = new FastHashtable(255);
		this.connectionsByUser = new FastHashtable(11);
		this.errorMap = null;
		this.waiters = new Queue();
		this.freeList = new Queue();
		this.connectionCount = 0;
		this.connectionsInUse = new syncInt();
		this.destroyed = false;
		this.pmiData = null;
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", new Object[]{connectionFactory, attributes});
		}

		this.factory = connectionFactory;
		this.attrs = (CMPropertiesImpl) attributes;
		this.xaResourceFactoryName = xaResourceFactoryName;
		this.xaResourceInfo = xaResourceInfo;
		this.connections = new Vector(this.attrs.getMaxConnectionPoolSize());
		this.dsPassword = password;
		this.statementCacheSize = this.attrs.getMaxStatementCacheSize();
		this.createPmiData(this.attrs);
		this.setupOrphanAlarm();
		this.setupAgedAlarm();
		this.portability = PortabilityLayerFactory.getPortabilityLayer(this.attrs.getDataSourceProperties());
		int var10000 = this.attrs.getDiagOptions();
		CMPropertiesImpl var10001 = this.attrs;
		if (var10000 != 0) {
			Tr.audit(tc, "MSG_CONM_6025I", new Object[]{this.attrs.getName(), this.attrs.getDiagOptionsString()});
		}

		if (this.attrs.getOraTransLoose()) {
			Tr.warning(tc, "MSG_CONM_6021W");
		}

		this.errorMap = ErrorMap.createErrorMap(this.portability, this.attrs.getErrorMap());
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void freeConnection(ConnectO c) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "freeConnection", c);
		}

		c.decRef();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "freeConnection");
		}

	}

	public void destroy() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy");
		}

		Vector connections;
		Enumeration enumWaiters;
		synchronized (this) {
			connections = (Vector) this.connections.clone();
			enumWaiters = this.waiters.elements();
			this.destroyed = true;
			this.notifyAll();
		}

		while (enumWaiters.hasMoreElements()) {
			Waiter w = (Waiter) enumWaiters.nextElement();
			w.setWokeUpOnNotify(true);
			w.notify();
		}

		for (int i = 0; i < connections.size(); ++i) {
			this.destroyConnection((ConnectO) connections.elementAt(i));
		}

		if (this.orphanAlarm != null) {
			this.orphanAlarm.cancel();
		}

		Tr.audit(tc, "MSG_CONM_6007I", this.attrs.getName());
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "destroy");
		}

	}

	public synchronized void destroyAllFreeConnections() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "destroyAllFreeConnections of ");
		}

		Enumeration en = this.connectionsByUser.keys();

		while (en.hasMoreElements()) {
			String key = (String) en.nextElement();
			synchronized (this.connectionsByUser.getLock(key)) {
				Queue set = (Queue) this.connectionsByUser.get(key);
				if (set != null) {
					for (ConnectO victim = (ConnectO) set.removeHead(); victim != null; victim = (ConnectO) set
							.removeHead()) {
						this.connections.removeElement(victim);

						try {
							this.destroyConnection(victim);
						} catch (Exception var8) {
							;
						}
					}
				}
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Setting all in-use connections stale");
		}

		for (int i = 0; i < this.connections.size(); ++i) {
			((ConnectO) this.connections.elementAt(i)).maybeStale = true;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "destroyAllFreeConnections");
		}

	}

	public PortabilityLayerExt getPortabilityLayer() {
		return this.portability;
	}

	public CMProperties getAttributes() {
		return this.attrs;
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "unwrap(Class<T>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isWrapperFor(Class<?>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Connection getConnection() throws SQLException {
		return this.getConnection((String) null, (String) null);
	}

	public Connection getConnection(String username, String password) throws SQLException {
		ConnectO c = this.allocateConnection(username, password);
		ConnectionProxy cp = ((ConnectionProxyFactory) this.portability).createConnectionProxy(c);
		c.addEventListener(cp);
		return cp;
	}

	public int getLoginTimeout() throws SQLException {
		return this.attrs.getConnectionTimeout();
	}

	public synchronized void setLoginTimeout(int seconds) throws SQLException {
		this.factory.setLoginTimeout(seconds);
		this.attrs.setConnectionTimeout(seconds);
	}

	public PrintWriter getLogWriter() throws SQLException {
		return this.factory.getLogWriter();
	}

	public void setLogWriter(PrintWriter out) throws SQLException {
		this.factory.setLogWriter(out);
	}

	public Logger getParentLogger() throws SQLFeatureNotSupportedException {
		throw new SQLFeatureNotSupportedException();
	}

	public void connectionEnlisted(ConnectO c, Object coord) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connectionEnlisted", new Object[]{c, coord});
		}

		synchronized (this.connectionsByTx.getLock(coord)) {
			Vector set = (Vector) this.connectionsByTx.get(coord);
			if (set == null) {
				set = new Vector();
				this.connectionsByTx.put(coord, set);
			}

			set.addElement(c);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connectionEnlisted");
		}

	}

	public void connectionDestroyed(ConnectO c) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connectionDestroyed", c);
		}

		synchronized (this.connectionsByUser.getLock(c.getUsername())) {
			try {
				c.removeFromQueue();
			} catch (RuntimeException var5) {
				;
			}
		}

		this.connections.removeElement(c);
		if (tc.isEventEnabled()) {
			Tr.event(tc, "Shrinking pool", new Integer(this.connectionCount));
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connectionDestroyed");
		}

	}

	public boolean connectionIdleTimeout(ConnectO c) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connectionIdleTimeout", c);
		}

		synchronized (this) {
			label69 : {
				if (this.connectionCount > this.attrs.getMinConnectionPoolSize()) {
					boolean var10000;
					synchronized (this.connectionsByUser.getLock(c.getUsername())) {
						try {
							c.removeFromQueue();
							break label69;
						} catch (RuntimeException var7) {
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "connectionIdleTimeout: Not on free queue", c);
							}

							var10000 = true;
						}
					}

					return var10000;
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "connectionIdleTimeout: At minimum size");
				}

				return false;
			}

			this.commonDestroyForIdleAndAged(c);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connectionIdleTimeout");
		}

		return true;
	}

	public boolean connectionAgedTimeout(ConnectO c) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connectionAgedTimeout", c);
		}

		synchronized (this) {
			label43 : {
				boolean var10000;
				synchronized (this.connectionsByUser.getLock(c.getUsername())) {
					try {
						c.removeFromQueue();
						break label43;
					} catch (RuntimeException var7) {
						c.aged = -1;
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "connectionAgedTimeout: Not on free queue", c);
						}

						var10000 = true;
					}
				}

				return var10000;
			}

			this.commonDestroyForIdleAndAged(c);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connectionAgedTimeout");
		}

		return true;
	}

	public void commonDestroyForIdleAndAged(ConnectO c) {
		this.destroyConnection(c);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connectionIdleTimeout");
		}

	}

	public void connectionTxComplete(ConnectO c, int status, Object coord) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connectionTxComplete", new Object[]{c, new Integer(status), coord});
		}

		synchronized (this.connectionsByTx.getLock(coord)) {
			this.connectionsByTx.remove(coord);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connectionTxComplete");
		}

	}

	public void connectionOrphaned(ConnectO c) {
		if (tc.isEventEnabled()) {
			Tr.event(tc, "connectionOrphaned", c);
		}

	}

	public void setDestroyed(ConnectO c) {
		if (tc.isEventEnabled()) {
			Tr.event(tc, "setDestroyed", c);
		}

	}

	String getXAResourceFactoryName() {
		return this.xaResourceFactoryName;
	}

	XAResourceInfo getXAResourceInfo() {
		return this.xaResourceInfo;
	}

	StatementCache createStatementCache(Connection c, ConnectO co) {
		return this.statementCacheSize == 0 ? null : new StatementCache(c, this.pmiData, co, this.statementCacheSize);
	}

	int getIdleTimeoutInMillis() {
		return this.attrs.getIdleTimeoutInMillis();
	}

	void returnConnection(ConnectO c) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "returnConnection", c);
		}

		c.unsetTracer();
		syncInt var22;
		if (c.aged == -1) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Aged. Do not return to free pool");
			}

			synchronized (this) {
				this.connections.removeElement(c);
				this.destroyConnection(c);
				var22 = this.connectionsInUse;
				synchronized (this.connectionsInUse) {
					this.connectionsInUse.decInt();
					if (this.pmiData != null) {
						this.pmiData.connectionFreed(this.attrs.getMaxConnectionPoolSize(),
								this.connectionsInUse.getInt());
					}
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "returnConnection");
			}

		} else if (c.maybeStale) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Maybe Stale. Do not return to free pool");
			}

			synchronized (this) {
				this.connections.removeElement(c);
				this.destroyConnection(c);
				var22 = this.connectionsInUse;
				synchronized (this.connectionsInUse) {
					this.connectionsInUse.decInt();
					if (this.pmiData != null) {
						this.pmiData.connectionFreed(this.attrs.getMaxConnectionPoolSize(),
								this.connectionsInUse.getInt());
					}
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "returnConnection");
			}

		} else {
			if (this.attrs.isResetReadOnlyEnabled() && c.isReadOnlyChanged()) {
				try {
					c.setReadOnly(false);
				} catch (SQLException var20) {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "SQLException while resetting read only value");
					}
				}
			}

			synchronized (this.connectionsByUser.getLock(c.getUsername())) {
				Queue set = (Queue) this.connectionsByUser.get(c.getUsername());
				if (set == null) {
					set = new Queue();
					this.connectionsByUser.put(c.getUsername(), set);
				}

				set.addToTail(c);
			}

			Waiter w = null;
			Queue var4 = this.waiters;
			int numWaiters;
			synchronized (this.waiters) {
				numWaiters = this.waiters.size();
				if (numWaiters > 0) {
					w = (Waiter) this.waiters.removeHead();
				}
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "number of waiters: " + numWaiters);
			}

			if (w != null) {
				synchronized (w) {
					w.setWokeUpOnNotify(true);
					w.notify();
				}
			}

			syncInt var23 = this.connectionsInUse;
			synchronized (this.connectionsInUse) {
				this.connectionsInUse.decInt();
				if (this.pmiData != null) {
					this.pmiData.connectionFreed(this.attrs.getMaxConnectionPoolSize(), this.connectionsInUse.getInt());
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "returnConnection");
			}

		}
	}

	private ConnectO allocateConnection(String username, String password) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "allocateConnection", username);
		}

		String user = null;
		boolean nullUser = username == null || username.equals("");
		boolean nullPwd = password == null || password.equals("");
		if (nullUser) {
			if (!nullPwd) {
				throw new IllegalArgumentException(
						"Non-null password with null user - Please check configuration panels for datasource, ejb module, and ejb, as well as application code.");
			}

			user = this.attrs.getUser();
			if (user == null) {
				user = "_null_username";
			}
		} else {
			if (nullPwd) {
				throw new IllegalArgumentException("null password with user:'" + username
						+ "' - Please check configuration panels for datasource, ejb module, and ejb, as well as application code.");
			}

			user = username;
		}

		String pwd = null;
		if (nullPwd) {
			if (this.dsPassword == null) {
				pwd = "_null_password";
			} else {
				pwd = this.dsPassword;
			}
		} else {
			pwd = password;
		}

		UOWCurrent uowCurrent = TransactionManagerFactory.getUOWCurrent();
		UOWCoordinator uowCoord = uowCurrent.getUOWCoord();
		ConnectO result = this.findConnectionForTx(uowCoord, user, pwd);
		result.incRef();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "allocateConnection", result);
		}

		return result;
	}

	private ConnectO findConnectionForTx(UOWCoordinator uowCoord, String username, String password)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "findConnectionForTx", new Object[]{uowCoord, username});
		}

		ConnectO result = null;
		if (uowCoord != null) {
			synchronized (this.connectionsByTx.getLock(uowCoord)) {
				Vector set = (Vector) this.connectionsByTx.get(uowCoord);
				if (set != null) {
					for (int i = 0; i < set.size(); ++i) {
						ConnectO c = (ConnectO) set.elementAt(i);
						if (c.getUsername().equals(username)) {
							result = c;
							if (!c.getPassword().equals("_null_password") && !c.getPassword().equals(password)) {
								Tr.warning(tc,
										"Connection requested with same user id but different password than existing enlisted connection.  A new connection will be created and enlisted.");
								result = null;
							}
							break;
						}
					}
				} else if (tc.isEventEnabled()) {
					Tr.event(tc, "No connection list for transaction");
				}
			}
		}

		if (result == null) {
			result = this.findFreeConnection(username, password);
			if (this.attrs.isValidateEnabled()) {
				boolean connectionValidated = result.validate();
				if (!connectionValidated) {
					this.destroyConnection(result);
					this.destroyAllFreeConnections();
					result = this.findFreeConnection(username, password);
				}
			}

			if (!result.getPassword().equals("_null_password") && !result.getPassword().equals(password)) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc,
							"Connection retrieved from pool with same userid but different password.  Connection will be closed and new connection created.");
				}

				this.destroyConnection(result);
				result = this.createOrWaitForConnection(username, password);
			}

			this.allocateConnForTransaction(result, uowCoord);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "findConnectionForTx", result);
		}

		return result;
	}

	Vector getConnectionsForTransaction(UOWCoordinator uowCoord) {
		Vector connections = new Vector();
		Enumeration dataSources = DSFactoryImpl.getDataSources();
		DataSourceImpl ds = null;
		ConnectionPool pool = null;

		while (dataSources.hasMoreElements()) {
			try {
				ds = (DataSourceImpl) dataSources.nextElement();
				pool = ds.getSource();
				if (pool.connectionsByTx.get(uowCoord) != null) {
					connections.addAll((Vector) pool.connectionsByTx.get(uowCoord));
				}
			} catch (SQLException var7) {
				Tr.debug(tc, "Failed to get connections by tran from DataSource {0}", ds);
			}
		}

		return connections;
	}

	private void allocateConnForTransaction(ConnectO result, UOWCoordinator uowCoord) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "allocateConnForTransaction");
		}

		try {
			result.allocate(uowCoord);
		} catch (StaleConnectionException var8) {
			synchronized (this) {
				if (result.maybeStale) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Connection marked stale");
					}
				} else {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Stale connection. Free pool");
					}

					this.destroyAllFreeConnections();
				}
			}

			throw var8;
		}

		syncInt var3 = this.connectionsInUse;
		synchronized (this.connectionsInUse) {
			this.connectionsInUse.incInt();
			if (this.pmiData != null) {
				this.pmiData.connectionAllocated(this.attrs.getMaxConnectionPoolSize(), this.connectionsInUse.getInt());
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "allocateConnForTransaction");
		}

	}

	private ConnectO findFreeConnection(String username, String password) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "findFreeConnection", username);
		}

		ConnectO result = null;
		int numWaiters = false;
		Queue var5 = this.waiters;
		int numWaiters;
		synchronized (this.waiters) {
			numWaiters = this.waiters.size();
		}

		if (numWaiters == 0) {
			synchronized (this.connectionsByUser.getLock(username)) {
				Queue set = (Queue) this.connectionsByUser.get(username);
				if (set != null && set.size() > 0) {
					result = (ConnectO) set.removeTail();
					if (result != null) {
						result.orphaned = false;
					}
				}
			}
		}

		if (result == null) {
			result = this.createOrWaitForConnection(username, password);
		}

		CMPropertiesImpl var10001 = this.attrs;
		CMPropertiesImpl var10002 = this.attrs;
		if (this.attrs.isDiagOptionEnabled(2 | 4)) {
			result.setTracer();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "findFreeConnection", result);
		}

		return result;
	}

	private ConnectO createOrWaitForConnection(String username, String password) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createOrWaitForConnection", username);
		}

		ConnectO result = null;

		for (int failures = 0; !this.destroyed; result = null) {
			if (this.connectionCount < this.attrs.getMaxConnectionPoolSize()) {
				boolean createConn = false;
				int currentConnCount = -1;
				synchronized (this) {
					if (this.connectionCount < this.attrs.getMaxConnectionPoolSize()) {
						createConn = true;
						currentConnCount = this.connectionCount++;
					}
				}

				if (createConn) {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "Expanding pool", new Object[]{new Integer(this.connectionCount),
								new Integer(this.attrs.getMaxConnectionPoolSize())});
					}

					try {
						result = this.createConnection(username, password);
						if (this.pmiData != null) {
							this.pmiData.connectionCreated(currentConnCount + 1);
						}

						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "createOrWaitForConnection", result);
						}

						return result;
					} catch (ResourceAllocationException var15) {
						label127 : {
							synchronized (this) {
								--this.connectionCount;
							}

							if (this.connectionCount != 0) {
								++failures;
								if (failures <= 4) {
									Tr.warning(tc, "MSG_CONM_6001W");
									break label127;
								}
							}

							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "createOrWaitForConnection: Resource Allocation Exception", var15);
							}

							throw var15.getNativeException();
						}
					} catch (SQLException var16) {
						synchronized (this) {
							--this.connectionCount;
						}

						SQLException sqle = this.errorMap.translateException(var16);
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "createOrWaitForConnection: Exception", sqle);
						}

						throw sqle;
					} catch (Exception var17) {
						synchronized (this) {
							--this.connectionCount;
						}

						Tr.warning(tc, "MSG_CONM_6024W", var17);
						new StaleConnectionException(
								"Exception caught while processing createConnection.: " + var17.getMessage());
					}
				}
			}

			result = this.waitForVictimConnection();
			if (result.getUsername().equals(username) && result.getPassword().equals(password)) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "createOrWaitForConnection", result);
				}

				return result;
			}

			if (tc.isEventEnabled()) {
				Tr.event(tc, "Available connection has wrong username or password");
			}

			this.destroyConnection(result);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createOrWaitForConnection: Pool destroyed");
		}

		throw new ConnectionPoolDestroyedException();
	}

	private ConnectO createConnection(String username, String password) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createConnection", username);
		}

		ConnectO result = null;
		int retry = 1;

		while (true) {
			try {
				if (username == "_null_username" && password == "_null_password") {
					result = this.factory.createConnection(this);
				} else {
					result = this.factory.createConnection(this, username, password);
				}
				break;
			} catch (SQLException var8) {
				Tr.error(tc, "MSG_CONM_6009E", this.attrs.getName());
				--retry;
				if (retry == 0) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "createConnection", var8);
					}

					throw this.errorMap.translateException(var8);
				}
			}
		}

		result.addEventListener(this);
		synchronized (this) {
			if (this.destroyed) {
				this.destroyConnection(result);
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "createConnection: Pool destroyed");
				}

				throw new ConnectionPoolDestroyedException();
			}

			this.connections.addElement(result);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createConnection", result);
		}

		return result;
	}

	protected void destroyConnection(ConnectO conn) {
		conn.alreadyDestroyed = true;
		if (conn.state == 1 | conn.state == 2 | conn.state == 3 | conn.state == 4) {
			syncInt var2 = this.connectionsInUse;
			synchronized (this.connectionsInUse) {
				this.connectionsInUse.decInt();
				if (this.pmiData != null) {
					this.pmiData.connectionFreed(this.attrs.getMaxConnectionPoolSize(), this.connectionsInUse.getInt());
				}
			}
		}

		conn.destroy();
		synchronized (this) {
			--this.connectionCount;
			if (this.pmiData != null) {
				this.pmiData.connectionDestroyed(this.connectionCount);
			}

			if (tc.isEventEnabled()) {
				Tr.event(tc, "Shrinking pool", new Integer(this.connectionCount));
			}

		}
	}

	private ConnectO waitForVictimConnection() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "waitForVictimConnection");
		}

		ConnectO victim = null;
		long connTimeOutTime = (long) this.attrs.getConnectionTimeoutInMillis();
		long timeToWait = connTimeOutTime;
		boolean enableTimeout = connTimeOutTime != 0L;
		if (this.pmiData != null) {
			this.pmiData.beginWaitForConnection();
		}

		Waiter w = null;

		Queue var33;
		do {
			Enumeration en = this.connectionsByUser.keys();

			Queue set;
			while (victim == null && en.hasMoreElements()) {
				String key = (String) en.nextElement();
				synchronized (this.connectionsByUser.getLock(key)) {
					set = (Queue) this.connectionsByUser.get(key);
					victim = (ConnectO) set.removeHead();
				}
			}

			if (victim != null) {
				if (w != null && this.freeList.size() < 10) {
					var33 = this.freeList;
					synchronized (this.freeList) {
						if (this.freeList.size() < 10) {
							this.freeList.addToTail(w);
						}
					}
				}

				if (this.pmiData != null) {
					this.pmiData.endWaitForConnection((long) this.attrs.getConnectionTimeoutInMillis() - timeToWait);
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "waitForVictimConnection", victim);
				}

				return victim;
			}

			if (tc.isEventEnabled()) {
				Tr.event(tc, "Waiting for free connection: ", new Object[]{new Long(timeToWait),
						new Integer(this.connectionCount), new Integer(this.attrs.getMaxConnectionPoolSize())});
			}

			if (w == null) {
				var33 = this.freeList;
				synchronized (this.freeList) {
					w = (Waiter) this.freeList.removeHead();
				}

				if (w == null) {
					w = new Waiter();
				}
			}

			synchronized (w) {
				Queue var10 = this.waiters;
				synchronized (this.waiters) {
					if (timeToWait == connTimeOutTime) {
						w.setWokeUpOnNotify(false);
						this.waiters.addToTail(w);
					} else {
						w.setWokeUpOnNotify(false);
						this.waiters.addToHead(w);
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "number of waiters: " + this.waiters.size());
					}
				}

				try {
					if (!enableTimeout) {
						w.wait();
					} else {
						long waitStart = System.currentTimeMillis();
						w.wait(timeToWait);
						long waitEnd = System.currentTimeMillis();
						timeToWait -= waitEnd - waitStart;
					}
				} catch (InterruptedException var30) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "waitForVictimConnection: Interrupted!", var30);
					}

					set = this.waiters;
					synchronized (this.waiters) {
						w.removeFromQueue();
					}

					if (this.freeList.size() < 10) {
						set = this.freeList;
						synchronized (this.freeList) {
							if (this.freeList.size() < 10) {
								this.freeList.addToTail(w);
							}
						}
					}

					throw new SQLException("Interruped waiting for connection");
				}
			}

			if (this.destroyed) {
				if (this.freeList.size() < 10) {
					var33 = this.freeList;
					synchronized (this.freeList) {
						if (this.freeList.size() < 10) {
							this.freeList.addToTail(w);
						}
					}
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "waitForVictimConnection: Pool destroyed");
				}

				throw new ConnectionPoolDestroyedException();
			}
		} while (!enableTimeout || w.getWokeUpOnNotify());

		var33 = this.waiters;
		synchronized (this.waiters) {
			w.removeFromQueue();
		}

		if (this.pmiData != null) {
			this.pmiData.connectionWaitTimeout();
		}

		if (this.freeList.size() < 10) {
			var33 = this.freeList;
			synchronized (this.freeList) {
				if (this.freeList.size() < 10) {
					this.freeList.addToTail(w);
				}
			}
		}

		CMPropertiesImpl var10001 = this.attrs;
		if (this.attrs.isDiagOptionEnabled(4)) {
			Vector conns = (Vector) this.connections.clone();
			int size = conns.size();

			for (int i = 0; i < size; ++i) {
				ConnectO connecto = (ConnectO) conns.elementAt(i);
				if (connecto.state != 0) {
					Tr.warning(tc, "MSG_CONM_6026W", new Object[]{this.attrs.getName(), connecto.getTracer()});
				}
			}
		} else {
			Tr.warning(tc, "MSG_CONM_6008W", new Object[]{"diagOptions", new Integer(4), this.attrs.getName()});
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "waitForVictimConnection: Timeout " + w + " " + w.getWokeUpOnNotify());
		}

		throw new ConnectionWaitTimeoutException();
	}

	private void setupOrphanAlarm() {
		if (this.attrs.getOrphanTimeout() > 0) {
			this.orphanAlarm = AlarmManager.create(this.attrs.getOrphanTimeoutInMillis(), this, ORPHAN_ALARM);
		}

	}

	private void setupAgedAlarm() {
		if (this.attrs.getAgedTimeout() > 0) {
			this.agedAlarm = AlarmManager.create(this.attrs.getAgedTimeoutInMillis(), this, AGED_ALARM);
		}

	}

	public final void alarm(Object type) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "alarm", type);
		}

		Vector connections;
		int i;
		if (type == ORPHAN_ALARM) {
			this.orphanAlarm = null;
			connections = null;
			synchronized (this) {
				connections = (Vector) this.connections.clone();
			}

			for (i = 0; i < connections.size(); ++i) {
				((ConnectO) connections.elementAt(i)).checkForOrphan();
			}

			synchronized (this) {
				if (!this.destroyed) {
					this.setupOrphanAlarm();
				}
			}
		} else if (type == AGED_ALARM) {
			this.agedAlarm = null;
			connections = null;
			synchronized (this) {
				connections = (Vector) this.connections.clone();
			}

			for (i = 0; i < connections.size(); ++i) {
				((ConnectO) connections.elementAt(i)).checkForAged();
			}

			synchronized (this) {
				if (!this.destroyed) {
					this.setupAgedAlarm();
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "alarm");
		}

	}

	private synchronized int getConnectionCount() {
		return this.connectionCount;
	}

	public ErrorMap getErrorMap() {
		return this.errorMap;
	}

	private void createPmiData(CMPropertiesImpl attrs) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createPmiData");
		}

		ObjectName factoryName = null;
		ObjectName providerName = null;

		try {
			AdminService adminService = AdminServiceFactory.getAdminService();
			ObjectName name = new ObjectName("WebSphere:mbeanIdentifier=" + attrs.getMBeanProviderId() + ",*");
			Set s = adminService.queryNames(name, (QueryExp) null);
			providerName = (ObjectName) s.iterator().next();
			name = new ObjectName("WebSphere:mbeanIdentifier=" + attrs.getMBeanFactoryId() + ",*");
			s = adminService.queryNames(name, (QueryExp) null);
			factoryName = (ObjectName) s.iterator().next();
		} catch (Exception var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.cm.ConnectionPool.createPmiData", "1490", this);
			if (tc.isDebugEnabled()) {
				Tr.debug(tc,
						"Caught exception when trying to get objectNames for PMI data. Setting them to null and continuing");
				Tr.debug(tc, "Exception = " + var7);
				factoryName = null;
				providerName = null;
			}
		}

		if (factoryName != null && providerName != null) {
			this.pmiData = PmiFactory.createConnPoolPerf(attrs.getName(), providerName, factoryName);
		} else if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Warning : FactoryName or ProviderName was null when trying to create pmiData");
			Tr.debug(tc, "FactoryName = " + (factoryName == null ? "null" : "not null"));
			Tr.debug(tc, "ProviderName = " + (providerName == null ? "null" : "not null"));
			Tr.debug(tc, "Setting both to null - pmi can handle null values.");
			factoryName = null;
			providerName = null;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createPmiData");
		}

	}

	static {
		TraceComponent tc = Tr.register(ConnectionPool.class, (String) null, "com.ibm.ejs.resources.CONMMessages");
		DiagnosticModuleForCMPool dm = new DiagnosticModuleForCMPool();
		int check = FFDC.registerDiagnosticModule(dm, "com.ibm.ejs.cm.pool");
		if (check != 0 && tc.isDebugEnabled()) {
			Tr.debug(tc, "Error registering DiagnosticModule");
			Tr.debug(tc, "Value returned from attempt to register DM = " + check);
		}

		NLS = TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages");
		ORPHAN_ALARM = new Object();
		AGED_ALARM = new Object();
		tc = Tr.register(ConnectionPool.class, (String) null, "com.ibm.ejs.resources.CONMMessages");
	}
}