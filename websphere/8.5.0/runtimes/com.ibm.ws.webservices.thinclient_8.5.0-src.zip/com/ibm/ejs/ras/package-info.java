package com.ibm.ejs.ras;

interface package-info {
}