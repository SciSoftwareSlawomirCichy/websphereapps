package com.ibm.ws.wim.adapter.file.was;

import com.ibm.websphere.management.AdminContext;
import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.websphere.management.MBeanFactory;
import com.ibm.websphere.management.RuntimeCollaborator;
import com.ibm.websphere.management.exception.AdminException;
import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.ICustomHashAlgo;
import com.ibm.websphere.wim.SchemaConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.CertificateMapFailedException;
import com.ibm.websphere.wim.exception.CertificateMapNotSupportedException;
import com.ibm.websphere.wim.exception.CertificateMapperException;
import com.ibm.websphere.wim.exception.CustomHashFailedException;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.EntityAlreadyExistsException;
import com.ibm.websphere.wim.exception.EntityHasDescendantsException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.InvalidArgumentException;
import com.ibm.websphere.wim.exception.MissingMandatoryPropertyException;
import com.ibm.websphere.wim.exception.NetworkConfigSyncException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.PasswordCheckFailedException;
import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.RemoveEntityException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.UpdateOperationalPropertyException;
import com.ibm.websphere.wim.exception.UpdatePropertyException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.websphere.wim.util.UniqueIdGenerator;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.management.AdminHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.file.was.FileAdapter.1;
import com.ibm.ws.wim.management.DynamicReloadManager;
import com.ibm.ws.wim.management.FileAdapterMBean;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.util.AsyncUtils;
import com.ibm.ws.wim.util.Base64Coder;
import com.ibm.ws.wim.util.ControlsHelper;
import com.ibm.ws.wim.util.DataGraphHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.LoginHelper;
import com.ibm.ws.wim.util.PasswordEncryptionUtil;
import com.ibm.ws.wim.util.StringUtil;
import com.ibm.ws.wim.util.UniqueNameHelper;
import com.ibm.wsspi.management.collaborator.AgentProxyCollaborator;
import com.ibm.wsspi.management.collaborator.AgentProxyServantCollaborator;
import com.ibm.wsspi.wim.Repository;
import com.ibm.wsspi.wim.RepositoryImpl;
import commonj.sdo.ChangeSummary;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.ChangeSummary.Setting;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.ObjectName;
import javax.management.QueryExp;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.ModificationItem;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class FileAdapter extends RepositoryImpl implements Repository, DynamicConfigService, SchemaConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	public static final String UNIQUE_ID_PATH = "identifier/uniqueId";
	public static final String EXTERNAL_ID_PATH = "identifier/externalId";
	public static final String EXTERNAL_NAME_PATH = "identifier/externalName";
	public static final String UNIQUE_NAME_PATH = "identifier/uniqueName";
	public static final String DO_ENTITIES0 = "entities.0";
	public static final int INITIAL_CURRENT_LEVEL = 0;
	public static final List IDENTIFIER_REF;
	protected static final String WILDCARD = "*";
	private static ObjectName proxyMBean;
	private static Map<String, FileAdapter> instances;
	private FileData defaultFileData = null;
	private static Map<String, FileData> fileDataMap;
	private String sessionId = null;
	private String fileID = null;
	private String MDAlgorithm = null;
	private List<String> baseEntries = new ArrayList();
	private List<String> loginProperties = new ArrayList();
	private List<Boolean> loginPropertiesType = new ArrayList();
	private String mappedPrincipalNameProperty = null;
	private boolean mappedPrincipalNamePropertyMultiValued = false;
	private List<String> skipProps = null;
	private int saltLength;
	private int keyLength;
	private int hashIterations;
	private Map<String, Vector> entityRDNs;
	private Set<String> allEntityProps = null;
	private Set<String> allEntityCtxProps = null;
	private Set<String> allEntityRefProps = null;
	private SchemaManager schemaMgr;
	private boolean reloadSchema = true;
	private ConfigManager configMgr;
	private static FileRegistryEventHandler freh;
	private boolean caseSensitive = false;
	private String baseDir = null;
	private boolean baseDirSetInConfig = false;
	private String fileName = null;
	private String iCertMapMode = null;
	private String[] iCertFilterEles = null;
	private String iCustomHashImplClass = null;
	private ICustomHashAlgo customHashImplWrapperObj = null;
	private boolean accountLockoutEnabled = false;
	private AccountLockoutCacheConfig accountLockoutCacheConfig = null;

	public FileAdapter() {
	}

	public FileAdapter(String var1, DataObject var2, DataObject var3) throws WIMException {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "WIM_SPI <init>",
					"sessionId=" + var1 + ", cfgDO=" + WIMTraceHelper.printDataGraph(var2));
		}

		try {
			this.sessionId = var1;
			this.schemaMgr = SchemaManager.singleton();
			if (var2 != null) {
				this.getEntityRDNsFromConfigDO(var2);
			} else {
				this.getEntityRDNsFromConfigManager();
			}

			this.allEntityProps = new HashSet();
			this.allEntityCtxProps = new HashSet();
			this.allEntityRefProps = new HashSet();
			if (var3 == null) {
				if (var5) {
					trcLogger.logp(Level.FINER, CLASSNAME, "<init>",
							"File Repository is not configured, initialize with default settings.");
				}

				this.fileID = "InternalFileRepository";
				if (!DomainManagerUtils.isAdminAgent() && AdminContext.peek() != null) {
					this.fileID = DomainManagerUtils.getFileID(this.fileID);
				}

				this.saltLength = 32;
				this.keyLength = 32;
				this.hashIterations = 100000;
				this.MDAlgorithm = "PBKDF2WithHmacSHA1";
				this.accountLockoutEnabled = true;
				this.accountLockoutCacheConfig = new AccountLockoutCacheConfig(
						ConfigConstants.ACCOUNT_LOCKOUT_THRESHOLD_DEFAULT,
						(long) ConfigConstants.ACCOUNT_LOCKOUT_DURATION_DEFAULT,
						(long) ConfigConstants.IGNORE_FAILED_LOGIN_AFTER_DEFAULT);
				if (DomainManagerUtils.isAdminDomain()) {
					this.baseDir = ConfigManager.singleton().getWASConfigDirectory();
				} else {
					this.baseDir = DomainManagerUtils.getDomainPath(DomainManagerUtils.getDomainName());
				}

				this.baseEntries.add("o=defaultWIMFileBasedRealm");
				this.defaultFileData = new FileData(var1, this.baseDir, (String) null, this.entityRDNs, this.fileID,
						this.baseEntries, this.caseSensitive, DomainManagerUtils.getDomainName(),
						this.accountLockoutCacheConfig);
				this.defaultFileData.load((DataObject) null);
			} else {
				this.initialize(var3);
			}
		} catch (WIMException var7) {
			throw var7;
		} catch (Exception var8) {
			throw new InitializationException("REPOSITORY_INITIALIZATION_FAILED",
					WIMMessageHelper.generateMsgParms(this.fileID, var8.getMessage()), Level.SEVERE, CLASSNAME,
					"<init>", var8);
		}

		if (var5) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI <init>");
		}

	}

	public void initialize(DataObject var1) throws WIMException {
		super.initialize(var1);
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI initialize");
		}

		try {
			this.fileID = var1.getString("id");
			if (!DomainManagerUtils.isAdminAgent() && AdminContext.peek() != null) {
				this.fileID = DomainManagerUtils.getFileID(this.fileID);
			}

			String var4 = DomainManagerUtils.getDomainName();
			if (this.sessionId == null) {
				instances.put(this.fileID, this);
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
							"fileAdapter instance cache=" + instances.get(var4));
				}
			}

			this.schemaMgr = SchemaManager.singleton();
			this.baseDir = var1.getString("baseDirectory");
			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
						"security domain is " + var4 + ", baseDir from config is " + this.baseDir);
			}

			if (this.baseDir == null) {
				if (DynamicReloadManager.isRunningOnAdminAgent()) {
					this.baseDir = ConfigManager.singleton().getAdminAgentWASConfigDirectory();
					if (var3) {
						trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
								"baseDir from getAdminAgentWASConfigDirectory is " + this.baseDir);
					}
				} else if (DomainManagerUtils.isAdminDomain()) {
					this.baseDir = ConfigManager.singleton().getWASConfigDirectory();
					if (var3) {
						trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
								"baseDir from getWASConfigDirectory is " + this.baseDir);
					}
				} else {
					this.baseDir = DomainManagerUtils.getDomainPath(var4);
					if (var3) {
						trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
								"baseDir from getDomainPath is " + this.baseDir);
					}
				}
			} else {
				this.baseDirSetInConfig = true;
			}

			if (!FileUtils.fileExists(this.baseDir)) {
				throw new InitializationException("DIRECTORY_NOT_FOUND",
						WIMMessageHelper.generateMsgParms(this.baseDir), Level.SEVERE, CLASSNAME, "initialize");
			} else {
				this.fileName = var1.getString("fileName");
				this.MDAlgorithm = var1.getString("messageDigestAlgorithm");
				this.saltLength = var1.isSet("saltLength") ? var1.getInt("saltLength") : 32;
				this.keyLength = var1.isSet("keyLength") ? var1.getInt("keyLength") : 32;
				this.hashIterations = var1.isSet("hashIterations") ? var1.getInt("hashIterations") : 100000;
				this.caseSensitive = var1.getBoolean("caseSensitive");
				int var5 = var1.isSet("accountLockoutThreshold") ? var1.getInt("accountLockoutThreshold") : -1;
				int var7;
				if (var5 > 0) {
					this.accountLockoutEnabled = true;
					int var6 = var1.isSet("accountLockoutDuration")
							? var1.getInt("accountLockoutDuration")
							: ConfigConstants.ACCOUNT_LOCKOUT_DURATION_DEFAULT;
					var7 = var1.isSet("ignoreFailedLoginAfter")
							? var1.getInt("ignoreFailedLoginAfter")
							: ConfigConstants.IGNORE_FAILED_LOGIN_AFTER_DEFAULT;
					long var8 = (long) (var6 * '');
					long var10 = (long) (var7 * '');
					if (var8 < 1L) {
						throw new WIMConfigurationException("INVALID_PARAMETER_VALUE",
								WIMMessageHelper.generateMsgParms("accountLockoutDuration"), CLASSNAME, "initialize");
					}

					if (var10 < 1L) {
						throw new WIMConfigurationException("INVALID_PARAMETER_VALUE",
								WIMMessageHelper.generateMsgParms("ignoreFailedLoginAfter"), CLASSNAME, "initialize");
					}

					this.accountLockoutCacheConfig = new AccountLockoutCacheConfig(var5, var8, var10);
				}

				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "initialize", "from configDO, fileName=" + this.fileName
							+ ", MDAlgo=" + this.MDAlgorithm + ", saltLength=" + this.saltLength + ", keyLength="
							+ this.keyLength + ", hashIterations=" + this.hashIterations + ", caseSensitive="
							+ this.caseSensitive + ", accountLockoutThreshold=" + var5 + ", accountLockoutDuration="
							+ (this.accountLockoutCacheConfig != null
									? this.accountLockoutCacheConfig.getAccountLockoutDuration()
									: "not set")
							+ ", ignoreFailedLoginAfter="
							+ (this.accountLockoutCacheConfig != null
									? this.accountLockoutCacheConfig.getIgnoreFailedLoginAfter()
									: "not set"));
				}

				List var17 = var1.getList("baseEntries");

				for (var7 = 0; var7 < var17.size(); ++var7) {
					this.baseEntries.add(((DataObject) var17.get(var7)).getString("name"));
				}

				if (this.baseEntries.size() == 0 && this.sessionId != null) {
					this.baseEntries.add("o=defaultWIMFileBasedRealm");
				}

				List var18;
				if (this.sessionId == null) {
					this.getEntityRDNsFromConfigManager();
					var18 = var1.getList("loginProperties");
					if (var18.size() > 0) {
						this.loginProperties.clear();
						this.loginPropertiesType.clear();

						for (int var19 = 0; var19 < var18.size(); ++var19) {
							this.loginProperties.add((String) var18.get(var19));
							this.loginPropertiesType.add(Boolean.FALSE);
						}
					}

					if (this.loginProperties.size() > 0) {
						this.mappedPrincipalNameProperty = (String) this.loginProperties.get(0);
					}

					this.getContextAndRefrenceProperties();
				}

				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "initialize",
							"baseEntries=" + this.baseEntries + ", loginProperties=" + this.loginProperties);
				}

				this.defaultFileData = new FileData(this.sessionId, this.baseDir, this.fileName, this.entityRDNs,
						this.fileID, this.baseEntries, this.caseSensitive, var4, this.accountLockoutCacheConfig);
				this.defaultFileData.load((DataObject) null);
				if (DynamicReloadManager.isRunningOnAdminAgent()) {
					fileDataMap = new HashMap(5);
				}

				if (this.sessionId == null && (DynamicReloadManager.isRunningOnManagedProcOrNodeAgent()
						|| DynamicReloadManager.isRegisteredWithAdminAgentMode())) {
					if (freh == null) {
						String var20 = "websphere.usermanager.fileregistry.change";
						freh = new FileRegistryEventHandler(var20, this.fileID, this.defaultFileData, var4);
						DynamicReloadManager.singleton().registerEventAtNode(var20, freh);
					} else {
						freh.addFileId(this.fileID, this.defaultFileData, var4);
					}
				}

				var18 = var1.getList("CustomProperties");
				HashMap var21 = new HashMap();
				boolean var9 = false;
				String var11;
				String var22;
				if (var18 != null & !var18.isEmpty()) {
					var22 = null;
					var11 = null;

					for (int var12 = 0; var12 < var18.size(); ++var12) {
						DataObject var13 = (DataObject) var18.get(var12);
						var22 = var13.getString("name");
						var11 = var13.getString("value");
						if ("customHashImplClassName".equals(var22) && var21.containsKey(var22)) {
							var9 = true;
						}

						var21.put(var22, var11);
					}
				}

				if (var21.containsKey("certificateMapMode")) {
					var22 = (String) var21.get("certificateMapMode");
					if ("filterDescriptorMode".equalsIgnoreCase(var22)) {
						this.iCertMapMode = "filterDescriptorMode";
						var11 = (String) var21.get("certificateFilter");
						this.iCertFilterEles = parseFilterDescriptor(var11);
					} else if (!"exactDNMode".equalsIgnoreCase(var22) && !"exactDN".equalsIgnoreCase(var22)) {
						if ("notSupported".equalsIgnoreCase(var22)) {
							this.iCertMapMode = (String) var21.get("certificateMapMode");
						} else {
							this.iCertMapMode = (String) var21.get("certificateMapMode");
							msgLogger.logp(Level.WARNING, CLASSNAME, "initialize", "INVALID_PARAM_VALUE_WARN",
									WIMMessageHelper.generateMsgParms(this.iCertMapMode, "certificateMapMode"));
							this.iCertMapMode = null;
						}
					} else {
						this.iCertMapMode = "exactDNMode";
					}
				}

				if (var21.containsKey("customHashImplClassName")) {
					this.iCustomHashImplClass = (String) var21.get("customHashImplClassName");
				}

				if (this.iCustomHashImplClass != null) {
					var22 = null;

					Class var23;
					try {
						var23 = Class.forName(this.iCustomHashImplClass);
					} catch (ClassNotFoundException var14) {
						ClassLoader var25 = Thread.currentThread().getContextClassLoader();
						if (var25 == null) {
							var25 = this.getClass().getClassLoader();
						}

						var23 = Class.forName(this.iCustomHashImplClass, true, var25);
					}

					Object var24 = var23.newInstance();
					if (!(var24 instanceof ICustomHashAlgo)) {
						throw new WIMApplicationException("CLASS_OR_INTERFACE_NOT_FOUND",
								WIMMessageHelper.generateMsgParms(this.iCustomHashImplClass, "customHashImplClassName"),
								Level.SEVERE, CLASSNAME, "initialize");
					}

					this.customHashImplWrapperObj = (ICustomHashAlgo) var24;
					if (var9) {
						msgLogger.logp(Level.WARNING, CLASSNAME, "initialize", "DUPLICATE_CUSTOM_PROPERTY",
								WIMMessageHelper.generateMsgParms("customHashImplClassName", this.fileID));
						msgLogger.logp(Level.INFO, CLASSNAME, "initialize", "The custom class '"
								+ this.iCustomHashImplClass + "'"
								+ " will be used by the adapter and rest of the configured implementation classes will be ignored.",
								new Object());
					}
				}

				if (var3) {
					trcLogger.exiting(CLASSNAME, "WIM_SPI initialize");
				}

			}
		} catch (WIMException var15) {
			throw var15;
		} catch (Exception var16) {
			throw new InitializationException("REPOSITORY_INITIALIZATION_FAILED",
					WIMMessageHelper.generateMsgParms(this.fileID, var16.getMessage()), Level.SEVERE, CLASSNAME,
					"initialize", var16);
		}
	}

	public static String[] parseFilterDescriptor(String var0) throws CertificateMapperException {
		boolean var2 = trcLogger.isLoggable(Level.FINER);
		if (var2) {
			trcLogger.entering(CLASSNAME, "WIM_SPI parseFilterDescriptor", " mapDesc=" + var0);
		}

		Vector var6 = new Vector();
		int var4 = 0;
		int var3 = 0;

		for (int var5 = var0.length(); var4 < var5; var3 = var4) {
			var4 = var0.indexOf("${", var3);
			if (var4 == -1) {
				if (var3 < var5) {
					var6.addElement(var0.substring(var3));
					if (var2) {
						trcLogger.logp(Level.FINER, CLASSNAME, "parseFilterDescriptor",
								"Added element to list = " + var6.lastElement());
					}
				}
				break;
			}

			if (var3 < var4) {
				var6.addElement(var0.substring(var3, var4));
				if (var2) {
					trcLogger.logp(Level.FINER, CLASSNAME, "parseFilterDescriptor",
							"Added element to list = " + var6.lastElement());
				}
			}

			var3 = var4;
			var4 = var0.indexOf("}", var4);
			if (var4 == -1) {
				throw new CertificateMapperException("INVALID_PARAMETER_VALUE", WIMMessageHelper.generateMsgParms(var0),
						CLASSNAME, "parseFilterDescriptor");
			}

			++var4;
			var6.addElement(var0.substring(var3, var4));
			if (var2) {
				trcLogger.logp(Level.FINER, CLASSNAME, "parseFilterDescriptor",
						"Added element to list = " + var6.lastElement());
			}
		}

		String[] var7 = new String[var6.size()];

		for (int var8 = 0; var8 < var6.size(); ++var8) {
			var7[var8] = (String) var6.elementAt(var8);
		}

		if (var2) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI parseFilterDescriptor", " mapDescEles=" + var6);
		}

		return var7;
	}

	private FileData getFileData() throws WIMException {
		boolean var2 = trcLogger.isLoggable(Level.FINER);
		String var3 = DomainManagerUtils.getDomainName();
		if (this.sessionId == null && !this.baseDirSetInConfig && DynamicReloadManager.isRunningOnAdminAgent()) {
			String var4 = AdminContext.peek() + DomainManagerUtils.getDomainName();
			if (var4 != null) {
				String var5 = var4 + ":" + this.fileID;
				if (var2) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getFileData",
							"contextUUID=" + var4 + ", contextFileUUID=" + var5);
				}

				FileData var6 = (FileData) fileDataMap.get(var5);
				if (var6 == null) {
					String var7 = null;
					if (DomainManagerUtils.isAdminDomain()) {
						var7 = ConfigManager.singleton().getCurrentContextCellDirectory();
					} else {
						var7 = DomainManagerUtils.getDomainPath(var3);
					}

					if (var2) {
						trcLogger.logp(Level.FINER, CLASSNAME, "getFileData",
								"fileData is not cached, loading it from " + var7);
					}

					var6 = new FileData((String) null, var7, this.fileName, this.entityRDNs, this.fileID,
							this.baseEntries, this.caseSensitive, var3);
					var6.load((DataObject) null);
					fileDataMap.put(var5, var6);
					if (var2) {
						trcLogger.logp(Level.FINER, CLASSNAME, "getFileData",
								"cached fileData keys=" + fileDataMap.keySet());
					}
				}

				return var6;
			}
		}

		return this.defaultFileData;
	}

	private void getEntityRDNsFromConfigManager() throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getEntityRDNsFromConfigManager");
		}

		this.configMgr = ConfigManager.singleton();
		List var2 = this.configMgr.getSupportedEntityTypes();
		int var3 = var2.size();
		this.entityRDNs = new HashMap(var3);

		for (int var4 = 0; var4 < var3; ++var4) {
			String var5 = (String) var2.get(var4);
			List var6 = this.configMgr.getRDNProperties(var5);
			Vector var7 = new Vector(var6.size());

			int var8;
			for (var8 = 0; var8 < var6.size(); ++var8) {
				String var9 = (String) var6.get(var8);
				var7.add(var9);
				StringTokenizer var10 = new StringTokenizer(var9, "+");
				if (var10.countTokens() > 1) {
					while (var10.hasMoreTokens()) {
						var7.add(var10.nextToken());
					}
				}
			}

			this.entityRDNs.put(var5, var7);
			if (FileData.isSuperType("PersonAccount", var5)) {
				for (var8 = 0; var8 < var7.size(); ++var8) {
					this.loginProperties.add((String) var7.get(var8));
					this.loginPropertiesType.add(Boolean.FALSE);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getEntityRDNsFromConfigManager",
					"entityRDNs=" + this.entityRDNs + ", loginProperties=" + this.loginProperties);
		}

	}

	private void getEntityRDNsFromConfigDO(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getEntityRDNsFromConfigDO");
		}

		List var3 = var1.getList("supportedEntityTypes");
		if (var3 == null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getEntityRDNsFromConfigDO", "No Supported Entity type found");
			}

		} else {
			int var4 = var3.size();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "getEntityRDNsFromConfigDO", "Supported Entities=" + var4);
			}

			this.entityRDNs = new HashMap(var4);

			for (int var5 = 0; var5 < var4; ++var5) {
				DataObject var6 = (DataObject) var3.get(var5);
				String var7 = var6.getString("name");
				List var8 = var6.getList("rdnProperties");
				Vector var9 = new Vector(var8.size());

				int var10;
				for (var10 = 0; var10 < var8.size(); ++var10) {
					String var11 = (String) var8.get(var10);
					var9.add(var11);
					StringTokenizer var12 = new StringTokenizer(var11, "+");
					if (var12.countTokens() > 1) {
						while (var12.hasMoreTokens()) {
							var9.add(var12.nextToken());
						}
					}
				}

				this.entityRDNs.put(var7, var9);
				if (FileData.isSuperType("PersonAccount", var7)) {
					for (var10 = 0; var10 < var9.size(); ++var10) {
						this.loginProperties.add((String) var9.get(var10));
						this.loginPropertiesType.add(Boolean.FALSE);
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getEntityRDNsFromConfigDO",
						"entityRDNs=" + this.entityRDNs + ", loginProperties=" + this.loginProperties);
			}

		}
	}

	private void getContextAndRefrenceProperties() {
		if (this.reloadSchema) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "getContextAndRefrenceProperties");
			}

			this.reloadSchema = false;
			this.skipProps = new ArrayList();
			this.skipProps.add("identifier");
			this.skipProps.add("viewIdentifiers");
			this.skipProps.add("parent");
			this.skipProps.add("children");
			this.skipProps.add("groups");
			this.skipProps.add("createTimestamp");
			this.skipProps.add("modifyTimestamp");
			this.skipProps.add("entitlementInfo");
			this.allEntityProps = new HashSet();
			this.allEntityCtxProps = new HashSet();
			this.allEntityRefProps = new HashSet();
			Iterator var2 = this.entityRDNs.keySet().iterator();

			while (var2.hasNext()) {
				String var3 = (String) var2.next();
				List var4 = this.schemaMgr.getProperties(var3);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getContextAndRefrenceProperties",
							"entityType=" + var3 + ", propList=" + var4);
				}

				for (int var5 = 0; var4 != null && var5 < var4.size(); ++var5) {
					Property var6 = (Property) var4.get(var5);
					String var7 = var6.getName();
					if (var6.isMany()) {
						if (var7.equals(this.mappedPrincipalNameProperty)) {
							this.mappedPrincipalNamePropertyMultiValued = true;
						}

						int var8 = this.loginProperties.indexOf(var7);
						if (var8 != -1) {
							this.loginPropertiesType.set(var8, Boolean.TRUE);
						}
					}

					if ("LangType".equals(var6.getType().getName())) {
						this.allEntityCtxProps.add(var7);
					} else if (!this.skipProps.contains(var7)) {
						if ("IdentifierType".equals(var6.getType().getName())) {
							this.allEntityRefProps.add(var7);
						} else {
							this.allEntityProps.add(var7);
						}
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getContextAndRefrenceProperties",
						"allEntityRefProps=" + this.allEntityRefProps + "\nallEntityCtxProps=" + this.allEntityCtxProps
								+ "\nallEntityProps=" + this.allEntityProps);
			}
		}

	}

	public DataObject create(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI create", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var4 = null;
		if (DynamicReloadManager.isRegisteredWithAdminAgentMode()) {
			var4 = this.redirectOperation("create", var1);
			if (var3) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI create", WIMTraceHelper.printDataGraph(var4));
			}

			return var4;
		} else {
			this.validateProfileType("create");
			String var5 = null;
			FileData var6 = this.getFileData();

			try {
				AsyncUtils.asyncOperationNotSupported(var1, this.fileID, CLASSNAME, "create");
				var4 = this.schemaMgr.createRootDataObject();
				List var7 = var1.getList("entities");

				for (int var26 = 0; var26 < var7.size(); ++var26) {
					DataObject var9 = (DataObject) var7.get(var26);
					DataObject var10 = DataGraphHelper.cloneDataObject(var9);
					String var11 = var10.getType().getName();
					if (var10.isSet("createTimestamp")) {
						throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE",
								WIMMessageHelper.generateMsgParms("createTimestamp"), CLASSNAME, "create");
					}

					if (var10.isSet("modifyTimestamp")) {
						throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE",
								WIMMessageHelper.generateMsgParms("modifyTimestamp"), CLASSNAME, "create");
					}

					DataObject var12 = var10.getDataObject("identifier");
					var5 = var12.getString("uniqueName");
					String var13 = var6.getEntityID(var10);
					var12.setString("externalName", var5);
					if (var6.exists(var13, var5)) {
						throw new EntityAlreadyExistsException("ENTITY_ALREADY_EXIST",
								WIMMessageHelper.generateMsgParms(var5), Level.SEVERE, CLASSNAME, "create");
					}

					if (this.isPersonAccountType(var11)) {
						if (var10.isSet("principalName")) {
							throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
									WIMMessageHelper.generateMsgParms("principalName", this.fileID), CLASSNAME,
									"create");
						}

						if (var10.isSet("realm")) {
							throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
									WIMMessageHelper.generateMsgParms("realm", this.fileID), CLASSNAME, "create");
						}
					}

					String var18;
					String var19;
					if (this.isAccountType(var11) && var10.isSet("password")) {
						boolean var14 = false;
						String var15 = new String(var10.getBytes("password"));
						String var17;
						if (this.iCustomHashImplClass != null) {
							try {
								if (this.customHashImplWrapperObj.isPasswordHashed(var10.getString("uid"), var15)) {
									BASE64Encoder var16 = new BASE64Encoder();
									var17 = var16.encodeBuffer(var10.getBytes("password"));
									var10.set("password", var17.getBytes());
									var14 = true;
								}
							} catch (Exception var23) {
								throw new CustomHashFailedException("CUSTOM_HASH_FAILED", (Object[]) null,
										Level.WARNING, CLASSNAME, "create", var23);
							}
						}

						if (!var14) {
							StringTokenizer var29 = new StringTokenizer(var15, ":");
							if (var29.countTokens() > 3) {
								var17 = var29.nextToken();
								var18 = var29.nextToken();
								var19 = var29.nextToken();
								String var20 = var29.nextToken();
								var10.set("password",
										FileData.hashBPM(var10.getBytes("password"), var19, var17, var18, var20));
							} else if (PasswordEncryptionUtil.isPbkdf2(this.MDAlgorithm)) {
								var10.set("password", FileData.hashPbkdf2(var10.getBytes("password"), this.saltLength,
										this.hashIterations, this.keyLength, this.MDAlgorithm));
							} else {
								var10.set("password",
										FileData.hash(var10.getBytes("password"), this.saltLength, this.MDAlgorithm));
							}
						}
					}

					EClass var27 = this.schemaMgr.getEClass(var10.getType());
					EList var28 = var27.getEAllReferences();

					for (int var30 = 0; var30 < var28.size(); ++var30) {
						EReference var32 = (EReference) var28.get(var30);
						var18 = var32.getName();
						var19 = var32.getEType().getName();
						if (var10.isSet(var18) && ("Entity".equals(var19) || "Group".equals(var19)
								|| this.allEntityRefProps.contains(var18))) {
							if (var32.getUpperBound() == 1) {
								var6.mustExist((String) null, this.getUniqueName(var10.getDataObject(var18)));
							} else {
								List var39 = var10.getList(var18);

								for (int var21 = 0; var21 < var39.size(); ++var21) {
									String var22 = this.getUniqueName((DataObject) var39.get(var21));
									var6.mustExist((String) null, var22);
								}
							}
						}
					}

					EList var31 = var27.getEAllStructuralFeatures();

					for (int var33 = 0; var33 < var31.size(); ++var33) {
						EStructuralFeature var35 = (EStructuralFeature) var31.get(var33);
						var19 = var35.getName();
						if (var35.getLowerBound() == 1 && !var10.isSet(var19)) {
							Object[] var40 = new Object[]{var19};
							throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY", var40, CLASSNAME,
									"create");
						}
					}

					HashSet var34 = null;
					String var44;
					if (var10.isSet("groups")) {
						List var36 = var10.getList("groups");
						var34 = new HashSet();

						for (int var38 = 0; var38 < var36.size(); ++var38) {
							DataObject var42 = (DataObject) var36.get(var38);
							var44 = this.getUniqueName(var42);
							if (var6.groupMustExist((String) null, var44)) {
								var34.add(var44);
							}
						}

						var10.unset("groups");
					}

					if (var13 == null || var13.trim().length() == 0) {
						var13 = UniqueIdGenerator.newUniqueId();
						var12.setString("uniqueId", var13);
						var12.setString("externalId", var13);
					}

					var10.setString("createTimestamp", var6.getDateString());
					var6.addEntity(var11, var10, true);
					DataObject var37 = var4.createDataObject("entities", var10.getType().getURI(), var11);
					DataObject var41 = var37.createDataObject("identifier");
					var41.setString("uniqueName", var5);
					var41.setString("externalName", var5);
					var41.setString("uniqueId", var13);
					var41.setString("externalId", var13);
					var41.setString("repositoryId", this.fileID);
					if (var34 != null) {
						Iterator var43 = var34.iterator();

						while (var43.hasNext()) {
							var44 = (String) var43.next();
							var6.addMemberDNToGroup(var44, var5, false);
						}

						var6.saveEntities();
					}
				}
			} catch (WIMException var24) {
				throw var24;
			} catch (Exception var25) {
				WIMApplicationException var8 = new WIMApplicationException("ENTITY_CREATE_FAILED",
						WIMMessageHelper.generateMsgParms(var5, var25.getMessage()), Level.SEVERE, CLASSNAME, "create",
						var25);
				var8.setRootErrorSource(this.fileID);
				throw var8;
			}

			if (var3) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI create", WIMTraceHelper.printDataGraph(var4));
			}

			return var4;
		}
	}

	private boolean isPersonAccountType(String var1) throws WIMException {
		return FileData.isSuperType("PersonAccount", var1);
	}

	private boolean isAccountType(String var1) throws WIMException {
		return this.isPersonAccountType(var1) || FileData.isSuperType("LoginAccount", var1);
	}

	private void copyDataObject(DataObject var1, DataObject var2, List var3, List var4, List var5) throws Exception {
		this.getContextAndRefrenceProperties();
		boolean var6 = false;
		Object var7 = null;
		if (var3 != null) {
			if (var3.contains("principalName") && this.mappedPrincipalNameProperty != null) {
				if (!var3.contains("*") && !var3.contains(this.mappedPrincipalNameProperty)) {
					var3.add(this.mappedPrincipalNameProperty);
				}

				var6 = true;
			}

			for (int var8 = 0; var8 < var3.size(); ++var8) {
				String var9 = (String) var3.get(var8);
				if (this.allEntityRefProps.contains(var9)) {
					if (var7 == null) {
						var7 = new ArrayList();
						if (var5 != null) {
							((List) var7).addAll(var5);
						}
					}

					((List) var7).add(var9);
				}
			}

			if (var3.contains("*")) {
				for (Iterator var10 = this.allEntityRefProps.iterator(); var10.hasNext(); ((List) var7)
						.add(var10.next())) {
					if (var7 == null) {
						var7 = new ArrayList();
						if (var5 != null) {
							((List) var7).addAll(var5);
						}
					}
				}
			}
		}

		if (var7 == null) {
			var7 = var5;
		}

		DataGraphHelper.copyDataObject(var1, var2, var3, var4, (List) var7);
		if (var6 && this.mappedPrincipalNameProperty != null
				&& FileData.isSuperType("LoginAccount", var1.getType().getName())) {
			if (this.mappedPrincipalNamePropertyMultiValued) {
				List var11 = var1.getList(this.mappedPrincipalNameProperty);
				if (var11.size() > 0) {
					var1.set("principalName", var11.get(0));
				}
			} else {
				var1.set("principalName", var1.get(this.mappedPrincipalNameProperty));
			}
		}

		DataObject var12 = var1.getDataObject("identifier");
		if (var12 != null && !var12.isSet("repositoryId")) {
			var12.setString("repositoryId", this.fileID);
		}

	}

	public DataObject get(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI get", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var4 = this.schemaMgr.createRootDataObject();
		String var5 = null;
		FileData var6 = this.getFileData();

		try {
			AsyncUtils.asyncOperationNotSupported(var1, this.fileID, CLASSNAME, "get");
			Map var7 = ControlsHelper.getControlMap(var1);
			DataObject var38 = (DataObject) var7.get("PropertyControl");
			DataObject var9 = (DataObject) var7.get("AncestorControl");
			DataObject var10 = (DataObject) var7.get("DescendantControl");
			DataObject var11 = (DataObject) var7.get("GroupMembershipControl");
			DataObject var12 = (DataObject) var7.get("GroupMemberControl");
			DataObject var13 = (DataObject) var7.get("CheckGroupMembershipControl");
			List var14 = null;
			List var15 = null;
			if (var38 != null) {
				var14 = var38.getList("properties");
				var15 = var38.getList("contextProperties");
			}

			List var16 = var1.getList("entities");

			for (int var17 = 0; var17 < var16.size(); ++var17) {
				DataObject var18 = (DataObject) var16.get(var17);
				String var19 = var18.getType().getName();
				EClass var20 = this.schemaMgr.getEClass(var18.getType());
				var5 = this.getUniqueName(var18);
				DataObject var21 = var6.getByDN(var5);
				String var22 = var21.getType().getName();
				DataObject var23 = var4.createDataObject("entities", var21.getType().getURI(), var22);
				this.copyDataObject(var23, var21, var14, var15, IDENTIFIER_REF);
				int var24;
				List var25;
				List var26;
				FileXPathHelper var27;
				if (var12 != null) {
					var24 = var12.getInt("level");
					if (var24 < 0) {
						throw new InvalidArgumentException("INVALID_LEVEL_IN_CONTROL",
								WIMMessageHelper.generateMsgParms(new Integer(var24), "GroupMemberControl"),
								Level.WARNING, CLASSNAME, "get");
					}

					var25 = var12.getList("properties");
					var26 = var12.getList("contextProperties");
					var27 = new FileXPathHelper(var12.getString("expression"), var12.getList("searchBases"),
							this.loginProperties, this.loginPropertiesType, this.caseSensitive, false);
					this.getGroupMembers(var21, var23, var25, var26, var24, 0, var27, new HashSet());
				}

				if (var11 != null) {
					var24 = var11.getInt("level");
					if (var24 < 0) {
						throw new InvalidArgumentException("INVALID_LEVEL_IN_CONTROL",
								WIMMessageHelper.generateMsgParms(new Integer(var24), "GroupMembershipControl"),
								Level.WARNING, CLASSNAME, "get");
					}

					var25 = var11.getList("properties");
					var26 = var11.getList("contextProperties");
					EClass var41 = this.schemaMgr.getEClass("Group");
					FileXPathHelper var28 = new FileXPathHelper(var11.getString("expression"),
							var11.getList("searchBases"), this.loginProperties, this.loginPropertiesType,
							this.caseSensitive, false);
					this.getGroupMembership(var5, var23, var41, var25, var26, var24, 0, var28, new HashSet());
				}

				if (var13 != null) {
					var24 = var13.getInt("level");
					if (var24 < 0) {
						throw new InvalidArgumentException("INVALID_LEVEL_IN_CONTROL",
								WIMMessageHelper.generateMsgParms(new Integer(var24), "CheckGroupMembershipControl"),
								Level.WARNING, CLASSNAME, "get");
					}

					boolean var39 = var6.checkGroupMembership(var18, var24);
					DataObject var40 = var4.createDataObject("controls", "http://www.ibm.com/websphere/wim",
							"CheckGroupMembershipControl");
					var40.setBoolean("inGroup", var39);
				}

				DataObject var43;
				if (var9 != null) {
					var24 = var9.getInt("level");
					if (var24 < 0) {
						throw new InvalidArgumentException("INVALID_LEVEL_IN_CONTROL",
								WIMMessageHelper.generateMsgParms(new Integer(var24), "AncestorControl"), Level.WARNING,
								CLASSNAME, "get");
					}

					var25 = var9.getList("properties");
					var26 = var9.getList("contextProperties");
					List var42 = this.getAncestorDNs(var5, var24);
					var43 = var23;

					try {
						for (int var29 = 0; var29 < var42.size(); ++var29) {
							String var30 = (String) var42.get(var29);
							DataObject var31 = var6.getByDN(var30);
							String var32 = var31.getType().getName();
							EClass var33 = this.schemaMgr.getEClass(var31.getType());
							DataObject var34 = (DataObject) EcoreUtil.create(var33);
							this.copyDataObject(var34, var31, var25, var26, IDENTIFIER_REF);
							var43.setDataObject("parent", var34);
							var43 = var34;
						}
					} catch (EntityNotFoundException var35) {
						;
					}
				}

				if (var10 != null) {
					var24 = var10.getInt("level");
					if (var24 < 0) {
						throw new InvalidArgumentException("INVALID_LEVEL_IN_CONTROL",
								WIMMessageHelper.generateMsgParms(new Integer(var24), "DescendantControl"),
								Level.WARNING, CLASSNAME, "get");
					}

					var25 = var10.getList("properties");
					var26 = var10.getList("contextProperties");
					var27 = new FileXPathHelper(var10.getString("expression"), var10.getList("searchBases"),
							this.loginProperties, this.loginPropertiesType, this.caseSensitive, false);
					var43 = var6.getByDN(var5);
					this.getDescendants(var43, var23, var25, var26, var24, 0, var10.getBoolean("treeView"), var27);
				}
			}
		} catch (WIMException var36) {
			throw var36;
		} catch (Exception var37) {
			WIMApplicationException var8 = new WIMApplicationException("ENTITY_GET_FAILED",
					WIMMessageHelper.generateMsgParms(var5, var37.getMessage()), Level.SEVERE, CLASSNAME, "get", var37);
			var8.setRootErrorSource(this.fileID);
			throw var8;
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI get", WIMTraceHelper.printDataGraph(var4));
		}

		return var4;
	}

	private void getGroupMembers(DataObject var1, DataObject var2, List var3, List var4, int var5, int var6,
			FileXPathHelper var7, Set var8) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getGroupMembers",
					"currentLevel=" + var6 + ", for group: " + var1.getString("identifier/uniqueName"));
		}

		if (!FileData.isSuperType("Group", var1.getType().getName())) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getGroupMembers", "Entity is not a group:" + var1.getType().getName());
			}

		} else {
			int var10 = var6 + 1;
			List var11 = var1.getList("members");

			for (int var12 = 0; var12 < var11.size(); ++var12) {
				DataObject var13 = (DataObject) var11.get(var12);
				String var14 = var13.getString("identifier/uniqueName");
				if (!var8.contains(var14)) {
					var8.add(var14);
					DataObject var15 = this.getFileData().getByDN(var14);
					boolean var16 = false;
					if (var7 == null || var7.evaluate(var15)) {
						var16 = true;
						EClass var17 = this.schemaMgr.getEClass(var15.getType());
						DataObject var18 = (DataObject) EcoreUtil.create(var17);
						this.copyDataObject(var18, var15, var3, var4, IDENTIFIER_REF);
						var2.getList("members").add(var18);
					}

					if ((var5 == 0 || var10 < var5) && FileData.isSuperType("Group", var15.getType().getName())) {
						this.getGroupMembers(var15, var2, var3, var4, var5, var10, var7, var8);
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getGroupMembers", "Members returned are:" + var8);
			}

		}
	}

	private void getGroupMembership(String var1, DataObject var2, EClass var3, List var4, List var5, int var6, int var7,
			FileXPathHelper var8, Set var9) throws Exception {
		boolean var11 = trcLogger.isLoggable(Level.FINER);
		if (var11) {
			trcLogger.entering(CLASSNAME, "getGroupMembership", "currentLevel=" + var7 + ", for member: " + var1);
		}

		int var12 = var7 + 1;
		List var13 = this.getFileData().getGroupsForEntity(var1, var8);

		for (int var14 = 0; var14 < var13.size(); ++var14) {
			String var15 = (String) var13.get(var14);
			if (!var9.contains(var15)) {
				var9.add(var15);
				DataObject var16 = this.getFileData().getByDN(var15);
				DataObject var17 = (DataObject) EcoreUtil.create(var3);
				this.copyDataObject(var17, var16, var4, var5, IDENTIFIER_REF);
				var2.getList("groups").add(var17);
				if (var6 == 0 || var12 < var6) {
					this.getGroupMembership(var15, var2, var3, var4, var5, var6, var12, var8, var9);
				}
			}
		}

		if (var11) {
			trcLogger.exiting(CLASSNAME, "getGroupMembership", "Groups returned are:" + var9);
		}

	}

	private List getAncestorDNs(String var1, int var2) throws Exception {
		ArrayList var3 = new ArrayList();
		if (var1 != null && var1.trim().length() != 0) {
			String var4 = var1;
			int var5 = var1.indexOf(",");
			int var6 = 0;

			while (var5 > 0) {
				var4 = var4.substring(var5 + 1);
				var3.add(var4);
				var5 = var4.indexOf(",");
				++var6;
				if (var2 != 0 && var6 >= var2) {
					break;
				}
			}

			return var3;
		} else {
			return var3;
		}
	}

	private void getDescendants(DataObject var1, DataObject var2, List var3, List var4, int var5, int var6,
			boolean var7, FileXPathHelper var8) throws Exception {
		boolean var10 = trcLogger.isLoggable(Level.FINER);
		String var11 = var1.getString("identifier/uniqueName");
		if (var10) {
			trcLogger.entering(CLASSNAME, "getDescendants", "currentLevel=" + var6 + ", for parent: " + var11);
		}

		int var12 = var6 + 1;
		FileData var13 = this.getFileData();
		Set var14 = var13.getImmediateDescendants(var11);
		Iterator var15 = var14.iterator();

		while (true) {
			DataObject var17;
			DataObject var18;
			EClass var19;
			do {
				if (!var15.hasNext()) {
					if (var10) {
						trcLogger.exiting(CLASSNAME, "getDescendants");
					}

					return;
				}

				String var16 = (String) var15.next();
				var17 = var13.getByDN(var16);
				var18 = null;
				if (var8 == null || var8.evaluate(var17)) {
					var19 = this.schemaMgr.getEClass(var17.getType());
					var18 = (DataObject) EcoreUtil.create(var19);
					this.copyDataObject(var18, var17, var3, var4, IDENTIFIER_REF);
					var2.getList("children").add(var18);
				}
			} while (var5 != 0 && var12 >= var5);

			if (var7) {
				if (var18 == null && FileData.isSuperType("OrgContainer", var17.getType().getName())) {
					var19 = this.schemaMgr.getEClass(var17.getType());
					var18 = (DataObject) EcoreUtil.create(var19);
					this.copyDataObject(var18, var17, var3, var4, IDENTIFIER_REF);
					var2.getList("children").add(var18);
				}

				this.getDescendants(var17, var18, var3, var4, var5, var12, var7, var8);
			} else {
				this.getDescendants(var17, var2, var3, var4, var5, var12, var7, var8);
			}
		}
	}

	private void deleteAll(String var1, Map var2, boolean var3) throws Exception {
		FileData var4 = this.getFileData();
		if (var1 != null) {
			DataObject var5 = var4.getByDN(var1);
			String var6 = var5.getType().getName();
			if (FileData.isSuperType("OrgContainer", var6)) {
				Set var7 = var4.getImmediateDescendants(var1);
				if (var3) {
					Iterator var8 = var7.iterator();

					while (var8.hasNext()) {
						String var9 = (String) var8.next();
						this.deleteAll(var9, var2, true);
					}
				} else if (var7.size() > 0) {
					throw new EntityHasDescendantsException("ENTITY_HAS_DESCENDENTS",
							WIMMessageHelper.generateMsgParms(var1), Level.SEVERE, CLASSNAME, "deleteAll");
				}
			}

			List var10 = var4.deleteEntity(var1, true);
			if (var10 != null) {
				var2.put(var1, var10);
			}

			var4.cleanReferences((String) null, var1);
		}

	}

	public DataObject delete(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI delete", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var4 = this.schemaMgr.createRootDataObject();
		if (DynamicReloadManager.isRegisteredWithAdminAgentMode()) {
			var4 = this.redirectOperation("delete", var1);
			if (var3) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI delete", WIMTraceHelper.printDataGraph(var4));
			}

			return var4;
		} else {
			this.validateProfileType("delete");
			String var5 = null;
			FileData var6 = this.getFileData();

			try {
				AsyncUtils.asyncOperationNotSupported(var1, this.fileID, CLASSNAME, "delete");
				Map var7 = ControlsHelper.getControlMap(var1);
				DataObject var21 = (DataObject) var7.get("DeleteControl");
				boolean var9 = var21 != null ? var21.getBoolean("deleteDescendants") : false;
				List var10 = var1.getList("entities");
				HashMap var11 = new HashMap();

				for (int var12 = 0; var12 < var10.size(); ++var12) {
					DataObject var13 = (DataObject) var10.get(var12);
					var5 = var13.getString("identifier/uniqueName");
					if (var5 == null) {
						String var14 = var6.getEntityID(var13);
						var5 = var6.getDNForID(var14);
					}

					this.deleteAll(var5, var11, var9);
				}

				Iterator var22 = var11.keySet().iterator();

				while (var22.hasNext()) {
					String var23 = (String) var22.next();
					List var24 = (List) var11.get(var23);
					String var15 = (String) var24.get(0);
					String var16 = (String) var24.get(1);
					DataObject var17 = this.schemaMgr.createDataObject(var4, "entities", var15);
					DataObject var18 = var17.createDataObject("identifier");
					var18.setString("uniqueName", var5);
					var18.setString("externalName", var5);
					var18.setString("uniqueId", var16);
					var18.setString("externalId", var16);
					var18.setString("repositoryId", this.fileID);
				}
			} catch (WIMException var19) {
				throw var19;
			} catch (Exception var20) {
				RemoveEntityException var8 = new RemoveEntityException("ENTITY_DELETE_FAILED",
						WIMMessageHelper.generateMsgParms(var5, var20.getMessage()), Level.SEVERE, CLASSNAME, "delete",
						var20);
				var8.setRootErrorSource(this.fileID);
				throw var8;
			}

			if (var3) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI delete", WIMTraceHelper.printDataGraph(var4));
			}

			return var4;
		}
	}

	private DataObject buildReturnDataObjectForUpdate(DataObject var1, DataObject var2) throws Exception {
		if (var1 == null) {
			var1 = this.schemaMgr.createRootDataObject();
		}

		String var3 = var2.getType().getName();
		DataObject var4 = var1.createDataObject("entities", var2.getType().getURI(), var3);
		this.copyDataObject(var4, var2, (List) null, (List) null, IDENTIFIER_REF);
		return var1;
	}

	public DataObject update(DataObject var1) throws WIMException {
      boolean var3 = trcLogger.isLoggable(Level.FINER);
      boolean var4 = trcLogger.isLoggable(Level.FINEST);
      if (var3) {
         trcLogger.entering(CLASSNAME, "WIM_SPI update", WIMTraceHelper.printDataGraph(var1));
      }

      Map var5 = ControlsHelper.getControlMap(var1);
      DataObject var6 = (DataObject)var5.get("CacheControl");
      if (var6 != null) {
         return null;
      } else {
         DataObject var7 = null;
         if (DynamicReloadManager.isRegisteredWithAdminAgentMode()) {
            var7 = this.redirectOperation("update", var1);
            if (var3) {
               trcLogger.exiting(CLASSNAME, "WIM_SPI update", WIMTraceHelper.printDataGraph(var7));
            }

            return var7;
         } else {
            this.validateProfileType("update");
            String var8 = null;
            FileData var9 = this.getFileData();
            HashSet var10 = new HashSet(1);

            try {
               AsyncUtils.asyncOperationNotSupported(var1, this.fileID, CLASSNAME, "update");
               ChangeSummary var11 = var1.getDataGraph().getChangeSummary();
               List var39 = var11.getChangedDataObjects();
               DataObject var14;
               if (var39.size() > 0) {
                  Iterator var40 = var39.iterator();

                  while(true) {
                     if (!var40.hasNext()) {
                        if (var4) {
                           trcLogger.logp(Level.FINEST, CLASSNAME, "update", "updated");
                        }
                        break;
                     }

                     var14 = (DataObject)var40.next();
                     String var41 = var14.getType().getName();
                     Vector var42 = (Vector)this.entityRDNs.get(var41);
                     Property var43 = var14.getContainmentProperty();
                     String var44 = var43.getName();
                     if (this.skipProps.contains(var44)) {
                        throw new OperationNotSupportedException("UPDATE_PROPERTY_NOT_SUPPORTED_WITH_CHANGESUMMARY", CLASSNAME, "update");
                     }

                     if ("entities".equals(var44)) {
                        var8 = var14.getString("identifier/uniqueName");
                        if (var4) {
                           trcLogger.logp(Level.FINEST, CLASSNAME, "update", "updating: " + var8);
                        }

                        ArrayList var45 = new ArrayList();
                        String var46 = null;
                        Iterator var47 = var11.getOldValues(var14).iterator();

                        while(var47.hasNext()) {
                           Setting var48 = (Setting)var47.next();
                           Property var49 = var48.getProperty();
                           String var50 = var49.getName();
                           if ("createTimestamp".equals(var50)) {
                              throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE", WIMMessageHelper.generateMsgParms("createTimestamp"), CLASSNAME, "update");
                           }

                           if ("modifyTimestamp".equals(var50)) {
                              throw new UpdateOperationalPropertyException("CANNOT_SPECIFIED_OPERATIONAL_PROPERTY_VALUE", WIMMessageHelper.generateMsgParms("modifyTimestamp"), CLASSNAME, "update");
                           }

                           if (this.isPersonAccountType(var41)) {
                              if ("principalName".equals(var50)) {
                                 throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY", WIMMessageHelper.generateMsgParms("principalName", this.fileID), CLASSNAME, "update");
                              }

                              if ("realm".equals(var50)) {
                                 throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY", WIMMessageHelper.generateMsgParms("realm", this.fileID), CLASSNAME, "update");
                              }
                           }

                           Object var51 = var48.getValue();
                           Object var52 = var14.get(var49);
                           if (var42 != null && var42.contains(var50)) {
                              if (((String)var52).trim().length() <= 0) {
                                 throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY", WIMMessageHelper.generateMsgParms(var50), CLASSNAME, "update");
                              }

                              var46 = UniqueNameHelper.constructUniqueName(var42, var14, UniqueNameHelper.getParentDN(var8));
                              if (var3) {
                                 trcLogger.logp(Level.FINER, CLASSNAME, "update", "1. DN has changed: oldDN=" + var8 + " #newDN=" + var46);
                              }

                              if (var9.exists((String)null, var46)) {
                                 throw new EntityAlreadyExistsException("ENTITY_ALREADY_EXIST", WIMMessageHelper.generateMsgParms(var46), Level.SEVERE, CLASSNAME, "update");
                              }
                           } else if ("password".equals(var50) && var52 != null) {
                              if (PasswordEncryptionUtil.isPbkdf2(this.MDAlgorithm)) {
                                 var52 = FileData.hashPbkdf2((byte[])((byte[])var52), this.saltLength, this.hashIterations, this.keyLength, this.MDAlgorithm);
                              } else {
                                 var52 = FileData.hash((byte[])((byte[])var52), this.saltLength, this.MDAlgorithm);
                              }

                              if (this.accountLockoutEnabled) {
                                 if (var3) {
                                    trcLogger.logp(Level.FINER, CLASSNAME, "update", "DN is flagged for password update, may need to clear account lockoutcache. Path 1");
                                 }

                                 var10.add(var8);
                              }
                           }

                           if (var51 instanceof List && ((List)var51).size() == 0) {
                              var51 = null;
                           }

                           if (var52 instanceof List && ((List)var52).size() == 0) {
                              var52 = null;
                           }

                           if (var51 == null) {
                              var45.add(new ModificationItem(1, new BasicAttribute(var50, var52)));
                           } else if (var52 == null) {
                              var45.add(new ModificationItem(3, new BasicAttribute(var50, var52)));
                           } else {
                              var45.add(new ModificationItem(2, new BasicAttribute(var50, var52)));
                           }

                           if (var4) {
                              trcLogger.logp(Level.FINEST, CLASSNAME, "update", "changed " + var49.getName() + " from '" + var51 + "' to '" + var52 + "'");
                           }
                        }

                        if (var46 != null) {
                           var9.rename(var41, var8, var46);
                           var8 = var46;
                        }

                        var9.modifyProperties(var8, var45);
                        var7 = this.buildReturnDataObjectForUpdate(var7, var9.getByDN(var8));
                     }
                  }
               } else {
                  List var13 = var1.getList("entities");
                  var14 = (DataObject)var5.get("GroupMemberControl");
                  DataObject var15 = (DataObject)var5.get("GroupMembershipControl");
                  int var16 = 1;
                  if (var14 != null) {
                     var16 = var14.getInt("modifyMode");
                  }

                  int var17 = 1;
                  if (var15 != null) {
                     var17 = var15.getInt("modifyMode");
                  }

                  Vector var18 = null;
                  Vector var19 = null;

                  for(int var20 = 0; var20 < var13.size(); ++var20) {
                     DataObject var21 = (DataObject)var13.get(var20);
                     var8 = this.getUniqueName(var21);
                     String var22 = var21.getType().getName();
                     if (this.isPersonAccountType(var22)) {
                        if (var21.isSet("principalName")) {
                           throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY", WIMMessageHelper.generateMsgParms("principalName", this.fileID), CLASSNAME, "update");
                        }

                        if (var21.isSet("realm")) {
                           throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY", WIMMessageHelper.generateMsgParms("realm", this.fileID), CLASSNAME, "update");
                        }
                     }

                     String var23 = null;
                     boolean var24 = false;
                     DataObject var25 = var21.getDataObject("parent");
                     if (var25 != null) {
                        var23 = var25.getString("identifier/uniqueName");
                        if (!var9.normalizedStringsAreEqual(UniqueNameHelper.getParentDN(var8), var23)) {
                           var24 = true;
                        }
                     } else {
                        var23 = UniqueNameHelper.getParentDN(var8);
                     }

                     String var26 = null;
                     List var27 = (List)this.entityRDNs.get(var22);
                     if (var27 != null) {
                        var26 = UniqueNameHelper.constructUniqueName(var27, var21, var23, false);
                     }

                     if (var26 == null && var24) {
                        int var28 = var8.indexOf(UniqueNameHelper.getParentDN(var8));
                        var26 = var8.substring(0, var28) + var23;
                     }

                     ArrayList var53 = new ArrayList();
                     EClass var29 = this.schemaMgr.getEClass(var21.getType());
                     EList var30 = var29.getEAllStructuralFeatures();

                     for(int var31 = 0; var31 < var30.size(); ++var31) {
                        String var33;
                        BasicAttribute var34;
                        if (var30.get(var31) instanceof EAttribute) {
                           EAttribute var54 = (EAttribute)var30.get(var31);
                           var33 = var54.getName();
                           if (!"uniqueName".equals(var33) && !"externalId".equals(var33) && !"uniqueId".equals(var33) && var21.isSet(var33)) {
                              if (var27 != null && var27.contains(var33)) {
                                 String var56 = (String)var21.get(var33);
                                 if (var56.trim().length() <= 0) {
                                    throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY", WIMMessageHelper.generateMsgParms(var33), CLASSNAME, "update");
                                 }
                              }

                              var34 = null;
                              if (var54.getUpperBound() == 1) {
                                 if (!"createTimestamp".equals(var33) && !"modifyTimestamp".equals(var33)) {
                                    if ("password".equals(var33)) {
                                       if (PasswordEncryptionUtil.isPbkdf2(this.MDAlgorithm)) {
                                          var34 = new BasicAttribute(var33, FileData.hashPbkdf2(var21.getBytes(var33), this.saltLength, this.hashIterations, this.keyLength, this.MDAlgorithm));
                                       } else {
                                          var34 = new BasicAttribute(var33, FileData.hash(var21.getBytes(var33), this.saltLength, this.MDAlgorithm));
                                       }

                                       var53.add(new ModificationItem(2, var34));
                                       if (this.accountLockoutEnabled) {
                                          if (var3) {
                                             trcLogger.logp(Level.FINER, CLASSNAME, "update", "DN is flagged for password update, may need to clear account lockoutcache. Path 2.");
                                          }

                                          var10.add(var8);
                                       }
                                    } else {
                                       var34 = new BasicAttribute(var33, var21.get(var33));
                                       var53.add(new ModificationItem(2, var34));
                                    }
                                 }
                              } else {
                                 var34 = new BasicAttribute(var33, var21.getList(var33));
                                 var53.add(new ModificationItem(2, var34));
                              }
                           }
                        } else if (var30.get(var31) instanceof EReference) {
                           EReference var32 = (EReference)var30.get(var31);
                           var33 = var32.getName();
                           if (var21.isSet(var33) && !"identifier".equals(var33) && !"children".equals(var33)) {
                              int var35;
                              String var36;
                              List var55;
                              if ("members".equals(var33)) {
                                 var55 = var21.getList(var33);
                                 var19 = new Vector();

                                 for(var35 = 0; var35 < var55.size(); ++var35) {
                                    var36 = this.getUniqueName((DataObject)var55.get(var35));
                                    if (var9.mustExist((String)null, var36)) {
                                       var19.add(var36);
                                    }
                                 }
                              } else if ("groups".equals(var33)) {
                                 var55 = var21.getList(var33);
                                 var18 = new Vector();

                                 for(var35 = 0; var35 < var55.size(); ++var35) {
                                    var36 = this.getUniqueName((DataObject)var55.get(var35));
                                    if (var9.groupMustExist((String)null, var36)) {
                                       var18.add(var36);
                                    }
                                 }
                              } else {
                                 var34 = null;
                                 if (var32.getUpperBound() == 1) {
                                    var34 = new BasicAttribute(var33, var21.get(var33));
                                 } else {
                                    var34 = new BasicAttribute(var33, var21.getList(var33));
                                 }

                                 var53.add(new ModificationItem(2, var34));
                              }
                           }
                        }
                     }

                     if (var26 != null && !var8.equals(var26)) {
                        if (var3) {
                           trcLogger.logp(Level.FINER, CLASSNAME, "update", "2. DN has changed: oldDN=" + var8 + " #newDN=" + var26);
                        }

                        if (var9.exists((String)null, var26)) {
                           throw new EntityAlreadyExistsException("ENTITY_ALREADY_EXIST", WIMMessageHelper.generateMsgParms(var26), Level.SEVERE, CLASSNAME, "update");
                        }

                        var9.rename(var22, var8, var26);
                        var8 = var26;
                     }

                     if (var53.size() > 0) {
                        if (var3) {
                           trcLogger.logp(Level.FINER, CLASSNAME, "update", "update entry " + var8 + " with attributes " + var53 + "....");
                        }

                        var9.modifyProperties(var8, var53);
                        var53 = null;
                     }

                     if (var19 != null) {
                        var9.updateGroupMembers(var8, var19, var16);
                        var19 = null;
                     }

                     if (var18 != null) {
                        var9.updateGroupMembership(var8, var18, var17);
                        var18 = null;
                     }

                     var7 = this.buildReturnDataObjectForUpdate(var7, var9.getByDN(var8));
                  }
               }

               ProfileSecurityManager.singleton().runAsSuperUser(new 1(this, var9));
               if (this.accountLockoutEnabled) {
                  this.accountLockoutCacheConfig.clearUsersFromCache(var10, "a password update.");
               }
            } catch (WIMException var37) {
               throw var37;
            } catch (Exception var38) {
               WIMApplicationException var12 = new WIMApplicationException("ENTITY_UPDATE_FAILED", WIMMessageHelper.generateMsgParms(var8, var38.getMessage()), Level.SEVERE, CLASSNAME, "update", var38);
               var12.setRootErrorSource(this.fileID);
               throw var12;
            }

            if (var3) {
               trcLogger.exiting(CLASSNAME, "WIM_SPI update", WIMTraceHelper.printDataGraph(var7));
            }

            return var7;
         }
      }
   }

	private void printProperties(String var1) {
		List var2 = this.schemaMgr.getProperties(var1);

		for (int var3 = 0; var3 < var2.size(); ++var3) {
			Property var4 = (Property) var2.get(var3);
			String var5 = var4.getType().getName();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "printProperties",
						"entityType=" + var1 + ", name=" + var4.getName() + ", type=" + var5);
			}
		}

	}

	private String getUniqueName(DataObject var1) throws Exception {
		String var2 = null;
		FileData var3 = this.getFileData();
		String var4;
		if ("IdentifierType".equals(var1.getType().getName())) {
			var4 = var1.getString("externalId");
			if (var4 == null) {
				var4 = var1.getString("uniqueId");
			}

			if (var4 != null) {
				var2 = var3.getDNForID(var4);
			} else {
				var2 = var1.getString("uniqueName");
				if (var2 == null) {
					var2 = var1.getString("externalName");
				}
			}
		} else if (var1.getDataObject("identifier") != null) {
			var4 = var3.getEntityID(var1);
			if (var4 != null) {
				var2 = var3.getDNForID(var4);
			} else {
				var2 = var1.getString("identifier/uniqueName");
				if (var2 == null) {
					var2 = var1.getString("identifier/externalName");
				}
			}
		}

		return var2;
	}

	public DataObject search(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI search", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var4 = null;
		FileData var5 = this.getFileData();

		try {
			AsyncUtils.asyncOperationNotSupported(var1, this.fileID, CLASSNAME, "search");
			Map var6 = ControlsHelper.getControlMap(var1);
			DataObject var26 = (DataObject) var6.get("SearchControl");
			List var8 = var26.getList("properties");
			List var9 = var26.getList("contextProperties");
			List var10 = var26.getList("searchBases");
			String var11 = var26.getString("expression");
			boolean var12 = var26.getBoolean("returnSubType");
			if (var11 == null || var11.length() == 0) {
				throw new SearchControlException("MISSING_SEARCH_EXPRESSION", Level.SEVERE, CLASSNAME, "search");
			}

			String var13 = LoginHelper.getContextProperty(var1, "allowDNPrincipalNameAsLiteral");
			boolean var14 = var13.equalsIgnoreCase("true");
			FileXPathHelper var15 = new FileXPathHelper(var11, var10, this.loginProperties, this.loginPropertiesType,
					this.caseSensitive, var14);
			List var16 = var15.getEntityTypes();
			List var17 = null;

			try {
				if (var16.size() > 1) {
					var17 = var5.search(var16, var15, true, var12);
				} else {
					var17 = var5.search((String) var16.get(0), var15, true, var12);
				}
			} catch (IllegalArgumentException var22) {
				throw new SearchControlException("INVALID_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var11),
						CLASSNAME, "search", var22);
			} catch (EntityNotFoundException var23) {
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "WIM_SPI search", "Entity not found", var23);
				}
			}

			var4 = this.schemaMgr.createRootDataObject();
			if (var17 != null) {
				DataObject var18 = null;
				Iterator var19 = var17.iterator();

				while (var19.hasNext()) {
					var18 = (DataObject) var19.next();
					EClass var20 = this.schemaMgr.getEClass(var18.getType());
					DataObject var21 = (DataObject) EcoreUtil.create(var20);
					this.copyDataObject(var21, var18, var8, var9, IDENTIFIER_REF);
					var4.getList("entities").add(var21);
				}
			}
		} catch (WIMException var24) {
			throw var24;
		} catch (Exception var25) {
			WIMApplicationException var7 = new WIMApplicationException("ENTITY_SEARCH_FAILED",
					WIMMessageHelper.generateMsgParms(var25.getMessage()), Level.SEVERE, CLASSNAME, "search", var25);
			var7.setRootErrorSource(this.fileID);
			throw var7;
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI search", WIMTraceHelper.printDataGraph(var4));
		}

		return var4;
	}

	public DataObject login(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "WIM_SPI login", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var4 = null;
		DataObject var5 = null;
		String var6 = null;
		FileData var7 = this.getFileData();
		Map var8 = ControlsHelper.getControlMap(var1);

		try {
			AsyncUtils.asyncOperationNotSupported(var1, this.fileID, CLASSNAME, "login");
			DataObject var9 = var1.getDataObject("entities.0");
			if (var9.isSet("certificate") && "notSupported".equalsIgnoreCase(this.iCertMapMode)) {
				throw new CertificateMapNotSupportedException("AUTHENTICATION_WITH_CERT_NOT_SUPPORTED",
						WIMMessageHelper.generateMsgParms(this.fileID), CLASSNAME, "login");
			}

			if (var9.isSet("certificate") && this.iCertMapMode == null) {
				return this.schemaMgr.createRootDataObject();
			}

			List var10 = var9.getList("certificate");
			int var11 = var10.size();
			var6 = var9.getString("principalName");
			byte[] var12 = var9.getBytes("password");
			DataObject var15;
			String var16;
			String var18;
			if (var11 > 0) {
				X509Certificate[] var95 = new X509Certificate[var11];

				try {
					for (int var96 = 0; var96 < var95.length; ++var96) {
						ByteArrayInputStream var97 = new ByteArrayInputStream((byte[]) ((byte[]) var10.get(var96)));
						CertificateFactory var99 = CertificateFactory.getInstance("X.509");
						var95[var96] = (X509Certificate) var99.generateCertificate(var97);
						var97.close();
					}
				} catch (IOException var89) {
					throw new CertificateMapFailedException(var89.getMessage(), var89);
				} catch (CertificateException var90) {
					throw new CertificateMapFailedException("CERTIFICATE_MAP_FAILED", var90);
				}

				DataObject var98 = (DataObject) var8.get("LoginControl");
				var15 = var9.getDataObject("identifier");
				var16 = var9.getType().getName();
				var5 = this.mapCertificate(var95, var16, var98);
				var4 = this.schemaMgr.createRootDataObject();
				if (var5 != null) {
					List var100 = var98 != null ? var98.getList("properties") : null;
					var18 = var9.getType().getURI();
					DataObject var101 = var4.createDataObject("entities", var18, var5.getType().getName());
					this.copyDataObject(var101, var5, var100, (List) null, IDENTIFIER_REF);
					if (var6 != null) {
						var101.setString("principalName", var6);
					}
				}
			} else {
				if (var12 == null || var12.length == 0) {
					throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PASSWORD", (Object[]) null, Level.WARNING,
							CLASSNAME, "login");
				}

				String var13 = null;
				String var14 = null;
				var15 = var9.getDataObject("identifier");
				var16 = var9.getType().getName();
				String var17 = var9.getType().getURI();
				if (var15 != null) {
					var13 = var15.getString("uniqueName");
					var14 = var7.getIDFromIdentifier(var15);
				}

				var18 = LoginHelper.getContextProperty(var1, "allowDNPrincipalNameAsLiteral");
				boolean var19 = var18.equalsIgnoreCase("true");
				if (UniqueNameHelper.isDN(var6) != null) {
					var13 = var6;
				}

				ArrayList var26;
				if (var13 != null && var13.trim().length() != 0 && !var19) {
					try {
						var5 = var7.getByDN(var13);
					} catch (EntityNotFoundException var92) {
						if (var3) {
							trcLogger.logp(Level.FINER, CLASSNAME, "WIM_SPI login",
									"principal DN, " + var13 + ", not found in " + this.fileID, var92);
						}

						var4 = this.schemaMgr.createRootDataObject();
					}
				} else if (var14 != null && var14.trim().length() != 0) {
					var5 = var7.getByID(var14);
				} else {
					if (var6 == null || var6.trim().length() == 0) {
						throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PRINCIPAL_NAME", CLASSNAME, "login");
					}

					DataObject var20 = (DataObject) var8.get("LoginControl");
					String var21 = "'";
					if (var6.indexOf("'") != -1) {
						var21 = "\"";
					}

					String var22 = "//entities[@xsi:type=" + var21 + var16 + var21 + " and " + "principalName" + "="
							+ var21 + var6 + var21 + "]";
					List var23 = var20.getList("searchBases");
					FileXPathHelper var24 = new FileXPathHelper(var22, var23, this.loginProperties,
							this.loginPropertiesType, this.caseSensitive, var19);
					Object var25 = var7.search(var16, var24, true, true);
					if (var6.contains("*")) {
						var26 = new ArrayList();
						Iterator var27 = ((List) var25).iterator();

						while (var27.hasNext()) {
							DataObject var28 = (DataObject) var27.next();
							String var29 = (String) var28.get(this.mappedPrincipalNameProperty);
							if (var6.equals(var29)) {
								DataObject var30 = SDOHelper.cloneDataObject(var28);
								var26.add(var30);
							}
						}

						var25 = var26;
					}

					if (((List) var25).size() == 1) {
						var5 = (DataObject) ((List) var25).get(0);
					} else if (((List) var25).size() > 1) {
						throw new PasswordCheckFailedException("MULTIPLE_PRINCIPALS_FOUND",
								WIMMessageHelper.generateMsgParms(var6, this.getRepositoryId()), CLASSNAME, "login");
					}
				}

				if (var5 != null) {
					String var102 = null;
					DataObject var103;
					if (this.accountLockoutEnabled) {
						var103 = var5.getDataObject("identifier");
						if (var103 != null) {
							var102 = var103.getString("uniqueName");
						}

						if (var102 == null) {
							if (var3) {
								trcLogger.logp(Level.FINE, CLASSNAME, "WIM_SPI login",
										"The uniqueName could not be found for " + var6 + ", using principalName.");
							}

							var102 = var6;
						}

						boolean var104 = false;
						this.accountLockoutCacheConfig.acquireReadLock();

						try {
							var104 = this.accountLockoutCacheConfig.isUserInLockoutCache(var102);
						} finally {
							this.accountLockoutCacheConfig.releaseReadLock();
						}

						if (var104) {
							this.accountLockoutCacheConfig.acquireWriteLock();

							try {
								FileUserAccountLockoutData var109 = this.accountLockoutCacheConfig
										.reviewAccountStatus(var102);
								if (var109 != null && var109.isLocked()) {
									if (var3) {
										trcLogger.logp(Level.FINE, CLASSNAME, "WIM_SPI login", var102
												+ " is still locked out of their account. Last login failure before account lockout was at "
												+ FileUtils.getPrintableTimeStamp(var109.getLastTimeStamp())
												+ ". Total number of users in locked/failed login cache is "
												+ this.accountLockoutCacheConfig.getLockoutCacheSize());
									}

									msgLogger.logp(Level.WARNING, CLASSNAME, "login", "FILE_REPOSITORY_ACCOUNT_LOCKED",
											WIMMessageHelper.generateMsgParms(var102,
													">" + var109.getNumberOfFailures(),
													FileUtils.getPrintableTimeStamp(
															var109.getLastTimeStamp() + this.accountLockoutCacheConfig
																	.getAccountLockoutDuration()),
													FileUtils.getPrintableTimeStamp(var109.getFirstTimeStamp()),
													FileUtils.getPrintableTimeStamp(System.currentTimeMillis())));
									throw new PasswordCheckFailedException("PASSWORD_MATCH_FAILED_FOR_PRINCIPALNAME",
											WIMMessageHelper.generateMsgParms(var6), CLASSNAME, "login");
								}
							} finally {
								this.accountLockoutCacheConfig.releaseWriteLock();
							}
						}
					}

					if (!this.checkPassword(var6, var12, var5.getBytes("password"))) {
						try {
							if (this.accountLockoutEnabled) {
								this.accountLockoutCacheConfig.acquireWriteLock();

								try {
									FileUserAccountLockoutData var108 = this.accountLockoutCacheConfig
											.getLockoutEntry(var102);
									if (var108 == null) {
										var108 = new FileUserAccountLockoutData(var6,
												this.accountLockoutCacheConfig.getAccountLockoutThreshold());
									}

									if (var108.updateAccountForLoginFailure()) {
										msgLogger.logp(Level.WARNING, CLASSNAME, "login",
												"FILE_REPOSITORY_ACCOUNT_LOCKED",
												WIMMessageHelper.generateMsgParms(var102, var108.getNumberOfFailures(),
														FileUtils.getPrintableTimeStamp(var108.getLastTimeStamp()
																+ this.accountLockoutCacheConfig
																		.getAccountLockoutDuration()),
														FileUtils.getPrintableTimeStamp(var108.getFirstTimeStamp()),
														FileUtils.getPrintableTimeStamp(var108.getLastTimeStamp())));
									}

									this.accountLockoutCacheConfig.putLockoutEntry(var102, var108);
									this.accountLockoutCacheConfig.startAccountLockoutCacheChecker();
								} finally {
									this.accountLockoutCacheConfig.releaseWriteLock();
								}
							}
						} catch (Exception var88) {
							FFDCFilter.processException(var88, CLASSNAME + "." + "login", "2672");
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "WIM_SPI login",
										"Exception while trying to lock or add a login failure for " + var102, var88);
							}

							msgLogger.logp(Level.SEVERE, CLASSNAME, "login", "GENERIC",
									WIMMessageHelper.generateMsgParms(var88));
						}

						throw new PasswordCheckFailedException("PASSWORD_MATCH_FAILED_FOR_PRINCIPALNAME",
								WIMMessageHelper.generateMsgParms(var6), CLASSNAME, "login");
					}

					if (this.accountLockoutEnabled) {
						boolean var105 = false;
						this.accountLockoutCacheConfig.acquireReadLock();

						try {
							var105 = this.accountLockoutCacheConfig.isUserInLockoutCache(var102);
						} finally {
							this.accountLockoutCacheConfig.releaseReadLock();
						}

						if (var105) {
							HashSet var106 = new HashSet(1);
							var106.add(var102);
							this.accountLockoutCacheConfig.clearUsersFromCache(var106, "a succesful login");
						}
					}

					var103 = (DataObject) var8.get("LoginControl");
					List var107 = var103 != null ? var103.getList("properties") : null;
					var4 = this.schemaMgr.createRootDataObject();
					DataObject var110 = var4.createDataObject("entities", var17, var5.getType().getName());
					this.copyDataObject(var110, var5, var107, (List) null, IDENTIFIER_REF);

					try {
						String var111 = null;
						if (!(new String(var5.getBytes("password"), "UTF-8")).contains(this.MDAlgorithm)) {
							BASE64Decoder var112 = new BASE64Decoder();

							try {
								byte[] var113 = var112.decodeBuffer(new String(var5.getBytes("password")));
								var111 = (new String(var113, "UTF-8")).trim();
							} catch (IOException var84) {
								;
							}
						} else {
							var111 = new String(var5.getBytes("password"), "UTF-8");
						}

						if ((DynamicReloadManager.isRunningOnDeploymentManager()
								|| DynamicReloadManager.isRunningOnSingleServer()
								|| DynamicReloadManager.isConnectionTypeNone()
								|| DynamicReloadManager.isRunningOnAdminAgent()
								|| DynamicReloadManager.isRunningOnJobManager())
								&& this.customHashImplWrapperObj != null
								&& this.customHashImplWrapperObj.isPasswordHashed(var6, var111)) {
							DataObject var114 = this.schemaMgr.createRootDataObject();
							var26 = null;
							DataObject var115 = var114.createDataObject("entities", "http://www.ibm.com/websphere/wim",
									"PersonAccount");
							var115.createDataObject("identifier").setString("uniqueName",
									var5.getDataObject("identifier").getString("uniqueName"));
							var115.set("password", var12);
							this.update(var114);
						}
					} catch (Exception var91) {
						throw new CustomHashFailedException("CUSTOM_HASH_FAILED", (Object[]) null, Level.WARNING,
								CLASSNAME, "login", var91);
					}
				} else {
					if (var3) {
						trcLogger.logp(Level.FINER, CLASSNAME, "login",
								"principal, " + var6 + ", not found in " + this.fileID);
					}

					var4 = this.schemaMgr.createRootDataObject();
				}
			}
		} catch (WIMException var93) {
			throw var93;
		} catch (Exception var94) {
			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "login", "Login failed", var94);
			}

			throw new WIMApplicationException("PASSWORD_CHECKED_FAILED",
					WIMMessageHelper.generateMsgParms(var6, var94.getMessage()), Level.SEVERE, CLASSNAME, "login",
					var94);
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI login", WIMTraceHelper.printDataGraph(var4));
		}

		return var4;
	}

	private boolean checkPassword(String var1, byte[] var2, byte[] var3) throws WIMException {
		boolean var5 = false;
		boolean var6 = false;
		String var7 = null;

		try {
			if (var2 != null && var3 != null) {
				var7 = (new String(var3)).trim();
				StringTokenizer var8 = new StringTokenizer(var7, ":");
				BASE64Decoder var9;
				if (this.iCustomHashImplClass != null && var8.countTokens() < 3) {
					var9 = new BASE64Decoder();

					try {
						byte[] var10 = var9.decodeBuffer(new String(var3));
						var7 = (new String(var10)).trim();
					} catch (IOException var17) {
						;
					}
				}

				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "checkPassword", "setHashed=#" + var7 + "#");
				}

				String var21;
				String var22;
				try {
					if (this.iCustomHashImplClass != null) {
						var21 = (new String(var2, "UTF-8")).trim();
						if (this.customHashImplWrapperObj.isPasswordHashed(var1, var7)) {
							var6 = true;
							var22 = (new String(this.customHashImplWrapperObj.getHashedPassword(var1, var21), "UTF-8"))
									.trim();
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "checkPassword", "inpHashed=#" + var22 + "#");
							}

							if (var7.equals(var22)) {
								var5 = true;
							}
						}
					}
				} catch (Exception var18) {
					trcLogger.logp(Level.FINER, CLASSNAME, "checkPassword", "Custom hashing mechanism failed", var18);
					throw new CustomHashFailedException("CUSTOM_HASH_FAILED", (Object[]) null, Level.WARNING, CLASSNAME,
							"checkPassword", var18);
				}

				if (!var6) {
					var9 = null;
					var22 = null;
					String var11 = null;
					String var12 = null;
					String var13 = null;
					StringTokenizer var14 = new StringTokenizer(var7, ":");
					if (var14.countTokens() > 3) {
						var21 = var14.nextToken();
						if (PasswordEncryptionUtil.isPbkdf2(var21)) {
							var22 = var14.nextToken();
							var11 = var14.nextToken();
							var13 = var14.nextToken();
						} else {
							var22 = var14.nextToken();
							var11 = var14.nextToken();
							var12 = var14.nextToken();
						}
					} else {
						var21 = var14.nextToken();
						var11 = var14.nextToken();
					}

					byte[] var15;
					if (var13 != null) {
						var15 = PasswordEncryptionUtil.hashPbkdf2(var2, var11, var21, var22, var13).getBytes();
					} else if (var22 != null) {
						var15 = FileData.hashBPM(var2, var11, var21, var22, (String) null);
					} else {
						var15 = FileData.hash(var2, var11, var21);
					}

					String var16 = (new String(var15)).trim();
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "checkPassword", "inpHashed=#" + var16 + "#");
					}

					if (var7.equals(var16)) {
						var5 = true;
					}
				}
			}

			return var5;
		} catch (CustomHashFailedException var19) {
			throw var19;
		} catch (Exception var20) {
			trcLogger.logp(Level.FINER, CLASSNAME, "checkPassword", "Password match failed", var20);
			throw new PasswordCheckFailedException("PASSWORD_MATCH_FAILED", (Object[]) null, Level.WARNING, CLASSNAME,
					"checkPassword", var20);
		}
	}

	public void dumpFileData() throws WIMException {
		this.getFileData().dumpFileData();
	}

	public DataObject createSchema(DataObject var1) throws WIMException {
		this.reloadSchema = true;
		this.getFileData().load((DataObject) null);
		AsyncUtils.asyncOperationNotSupported(var1, this.fileID, CLASSNAME, "createSchema");
		throw new OperationNotSupportedException("OPERATION_NOT_SUPPORTED_IN_REPOSITORY",
				WIMMessageHelper.generateMsgParms("createSchema", this.fileID), CLASSNAME, "createSchema");
	}

	public DataObject getSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI getSchema", WIMTraceHelper.printDataObject(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.fileID, CLASSNAME, "getSchema");
		DataObject var3 = this.schemaMgr.createRootDataObject();
		DataObject var4 = var3.getDataObject("schema");
		if (var4 == null) {
			var4 = var3.createDataObject("schema");
		}

		Map var5 = ControlsHelper.getControlMap(var1);
		DataObject var6 = (DataObject) var5.get("DataTypeControl");
		DataObject var7 = (DataObject) var5.get("PropertyDefinitionControl");
		DataObject var8 = (DataObject) var5.get("EntityTypeControl");
		SchemaManager var9 = SchemaManager.singleton();
		if (var6 != null) {
			var9.getSupportedDataTypes(var4);
		} else {
			List var11;
			String var16;
			if (var8 != null) {
				List var10 = ConfigManager.singleton().getSupportedEntityTypes();
				var11 = var8.getList("entityTypeNames");
				int var12;
				String var15;
				if (var11 != null && var11.size() != 0) {
					for (var12 = 0; var12 < var11.size(); ++var12) {
						String var21 = (String) var11.get(var12);
						if (var21.startsWith("wim:")) {
							var21 = var9.getTypeName(var21);
						}

						if (var10.contains(var21)) {
							DataObject var23 = var4.createDataObject("entitySchema");
							var15 = var9.getTypeNsURI(var21);
							var16 = var9.getNsPrefix(var15);
							var23.set("entityName", var9.getTypeName(var21));
							var23.set("nsURI", var15);
							var23.set("nsPrefix", var16);
						} else if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME, "getSchema",
									"The entity type " + var21 + " is not supported in repository " + this.fileID);
						}
					}
				} else if (var10 != null && var10.size() > 0) {
					for (var12 = 0; var12 < var10.size(); ++var12) {
						DataObject var13 = var4.createDataObject("entitySchema");
						String var14 = (String) var10.get(var12);
						var15 = var9.getTypeNsURI(var14);
						var16 = var9.getNsPrefix(var15);
						var13.set("entityName", var9.getTypeName(var14));
						var13.set("nsURI", var15);
						var13.set("nsPrefix", var16);
					}
				}
			} else if (var7 != null) {
				String var19 = var7.getString("entityTypeName");
				if (var19.startsWith("wim:")) {
					var19 = var9.getTypeName(var19);
				}

				var11 = var9.getProperties(var19);
				String var20 = null;
				List var22 = var7.getList("propertyNames");
				String var17;
				DataObject var18;
				if (var22 != null && var22.size() > 0) {
					if (var11 != null) {
						List var25 = var9.getQualifiedPropertyNames(var11);

						for (int var27 = 0; var27 < var22.size(); ++var27) {
							var20 = (String) var22.get(var27);
							if (var20.startsWith("wim:")) {
								var20 = var9.getTypeName(var20);
							}

							if (!var25.contains(var20)) {
								throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
										WIMMessageHelper.generateMsgParms(var20, var19), CLASSNAME, "getSchema");
							}

							var16 = var9.getTypeNsURI(var20);
							var17 = var9.getNsPrefix(var16);
							var18 = var4.createDataObject("propertySchema");
							var18.setString("propertyName", var9.getTypeName(var20));
							var18.setString("nsURI", var16);
							var18.setString("nsPrefix", var17);
						}
					}
				} else {
					for (int var24 = 0; var11 != null && var24 < var11.size(); ++var24) {
						Property var26 = (Property) var11.get(var24);
						var20 = var9.getQualifiedPropertyName(var26);
						var16 = var9.getTypeNsURI(var20);
						var17 = var9.getNsPrefix(var16);
						var18 = var4.createDataObject("propertySchema");
						var18.setString("propertyName", var9.getTypeName(var20));
						var18.setString("nsURI", var16);
						var18.setString("nsPrefix", var17);
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI getSchema", WIMTraceHelper.printDataObject(var3));
		}

		return var3;
	}

	public List getBaseEntries() {
		return this.baseEntries;
	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI dynamicUpdateConfig",
					WIMMessageHelper.generateMsgParms(var1, WIMTraceHelper.printMapWithoutPassword(var2)));
		}

		if ("websphere.usermanager.serviceprovider.add.baseentry".equalsIgnoreCase(var1)) {
			String var4 = (String) var2.get("DYNA_CONFIG_KEY_BASE_ENTRY");
			var4 = UniqueNameHelper.getValidUniqueName(var4);
			if (var4 == null || var4.trim().equals("")) {
				throw new DynamicUpdateConfigException("INVALID_UNIQUE_NAME_SYNTAX",
						WIMMessageHelper.generateMsgParms(var4), CLASSNAME, "dynamicUpdateConfig");
			}

			for (int var5 = 0; var5 < this.baseEntries.size(); ++var5) {
				String var6 = (String) this.baseEntries.get(var5);
				if (var6.equalsIgnoreCase(var4)) {
					throw new DynamicUpdateConfigException("BASE_ENTRY_ALREADY_IN_REPOSITORY",
							WIMMessageHelper.generateMsgParms(var4, this.fileID), CLASSNAME, "dynamicUpdateConfig");
				}
			}

			this.getFileData().addBaseEntry(var4);
			this.baseEntries.add(var4);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI dynamicUpdateConfig",
						WIMMessageHelper.generateMsgParms(var1, WIMTraceHelper.printMapWithoutPassword(var2)));
			}
		}

	}

	public static boolean clearCache(String var0) {
		boolean var2 = false;
		boolean var3 = false;
		trcLogger.logp(Level.FINE, CLASSNAME, "clearCache", "key=" + var0);
		String var4 = DomainManagerUtils.getDomainName();
		if (var0 != null && fileDataMap != null) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "clearCache",
						"cached keys[" + fileDataMap.size() + "]=" + fileDataMap.keySet());
			}

			Iterator var5 = fileDataMap.keySet().iterator();

			while (var5.hasNext()) {
				String var6 = var5.next().toString();
				if (var6 != null && var6.startsWith(var0)) {
					var2 = false;
					if (fileDataMap.remove(var6) != null) {
						var2 = true;
					} else {
						var3 = true;
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "clearCache",
									" Failed to clear cache for =" + var6);
						}
					}
				}
			}
		}

		var2 = !var3 && var2;
		trcLogger.logp(Level.FINE, CLASSNAME, "clearCache", "cleared=" + var2);
		return var2;
	}

	private DataObject redirectOperation(String var1, DataObject var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "redirectOperation", "operation=" + var1);
		}

		ObjectName var4 = getProxyMBean();

		try {
			String[] var5 = new String[]{"commonj.sdo.DataObject", "java.lang.String"};
			Object[] var8 = new Object[]{var2, this.fileID};
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "redirectOperation",
						"calling the FileAdapterMBean proxy:" + var4.toString());
			}

			return (DataObject) AdminServiceFactory.getAdminService().invoke(var4, var1, var8, var5);
		} catch (Exception var7) {
			if (var7 instanceof WIMException) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "redirectOperation", "redirected operation failed", var7);
				}

				throw (WIMException) var7;
			} else {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "redirectOperation", "call redirect failed", var7);
				}

				for (Throwable var6 = var7.getCause(); var6 != null; var6 = var6.getCause()) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "redirectOperation", "cause: " + var6.getClass());
					}

					if (var6 instanceof WIMException) {
						throw (WIMException) var6;
					}
				}

				throw new WIMApplicationException("MBEAN_GET_CALL_FAILURE",
						WIMMessageHelper.generateMsgParms("FileAdapterMBean-Proxy", var7.getMessage()), Level.SEVERE,
						CLASSNAME, "redirectOperation", var7);
			}
		}
	}

	private static synchronized ObjectName getProxyMBean() throws WIMException {
		String var1 = DomainManagerUtils.getDomainName();
		if (proxyMBean == null) {
			initMBeanProxy();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "getProxyMBean", "Getting FileAdapterMBean proxy");
			}

			try {
				AdminService var2 = AdminServiceFactory.getAdminService();
				String var3 = var2.getProcessName();
				String var4 = "WebSphere:process=" + var3 + ",type=" + "FileAdapterMBean" + ",*";
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getProxyMBean", "query=" + var4);
				}

				ObjectName var5 = new ObjectName(var4);
				Set var6 = var2.queryNames(var5, (QueryExp) null);
				if (var6.size() < 1) {
					throw new WIMApplicationException("MBEAN_GET_CALL_FAILURE",
							WIMMessageHelper.generateMsgParms("FileAdapterMBean-Proxy", var4), Level.SEVERE, CLASSNAME,
							"getProxyMBean");
				}

				Object[] var7 = var6.toArray();
				proxyMBean = (ObjectName) var7[0];
			} catch (Exception var8) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getProxyMBean", "failed to get the MBean proxy", var8);
				}

				throw new WIMApplicationException("MBEAN_GET_CALL_FAILURE",
						WIMMessageHelper.generateMsgParms("FileAdapterMBean-Proxy", var8.getMessage()), Level.SEVERE,
						CLASSNAME, "getProxyMBean", var8);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "getProxyMBean",
						"FileAdapterMBean proxy obtained:" + proxyMBean.toString());
			}
		}

		return proxyMBean;
	}

	private static void initMBeanProxy() {
		boolean var1 = trcLogger.isLoggable(Level.FINE);
		if (var1) {
			trcLogger.logp(Level.FINE, CLASSNAME, "initMBeanProxy", "enter");
		}

		try {
			Object var2 = null;
			if (AdminHelper.getPlatformHelper().isServantJvm()) {
				var2 = new AgentProxyServantCollaborator(FileAdapterMBean.class);
			} else {
				var2 = new AgentProxyCollaborator(FileAdapterMBean.class);
			}

			if (var1) {
				trcLogger.logp(Level.FINE, CLASSNAME, "initMBeanProxy",
						"Activating FileAdapterMBean Proxy using collaborator:" + var2.getClass().getName());
			}

			MBeanFactory var3 = AdminServiceFactory.getMBeanFactory();
			ObjectName var4 = var3.activateMBean("FileAdapterMBean", (RuntimeCollaborator) var2, "FileAdapterMBean",
					"com/ibm/ws/wim/management/FileAdapterMBean.xml");
			((RuntimeCollaborator) var2).setObjectName(var4);
			msgLogger.log(Level.INFO, "MBEAN_INIT_SUCCESS", WIMMessageHelper.generateMsgParms(var4.toString()));
			if (var1) {
				trcLogger.logp(Level.FINE, CLASSNAME, "initMBeanProxy",
						"Activated FileAdapterMBean Proxy (" + var4.toString() + ")");
			}
		} catch (AdminException var5) {
			if (var1) {
				trcLogger.logp(Level.FINE, CLASSNAME, "initMBeanProxy", "MBEAN_INIT_FAILURE", var5);
			}

			msgLogger.logp(Level.SEVERE, CLASSNAME, "initMBeanProxy", "MBEAN_INIT_FAILURE",
					WIMMessageHelper.generateMsgParms("FileAdapterMBean", var5.getMessage()));
		}

		if (var1) {
			trcLogger.logp(Level.FINE, CLASSNAME, "initMBeanProxy", "exit");
		}

	}

	public static FileAdapter getInstance(String var0) {
		String var1 = DomainManagerUtils.getDomainName();
		if (!DomainManagerUtils.isAdminAgent() && AdminContext.peek() != null) {
			var0 = DomainManagerUtils.getFileID(var0);
		}

		return (FileAdapter) instances.get(var0);
	}

	private DataObject mapCertificate(X509Certificate[] var1, String var2, DataObject var3) throws WIMException {
		X509Certificate var5 = var1[0];
		DataObject var6 = null;
		FileData var7 = this.getFileData();
		boolean var8 = trcLogger.isLoggable(Level.FINER);
		String var9;
		if ("filterDescriptorMode".equalsIgnoreCase(this.iCertMapMode)) {
			var9 = this.getCertificateFilter(var5);
			var9 = var9.trim();
			if (var9 != null && !var9.startsWith("//entities")) {
				var9 = "//entities[@xsi:type='" + var2 + "' and (" + var9 + ")]";
			}

			List var10 = var3.getList("searchBases");
			FileXPathHelper var11 = null;

			try {
				var11 = new FileXPathHelper(var9, var10, this.loginProperties, this.loginPropertiesType,
						this.caseSensitive, false);
			} catch (WIMApplicationException var14) {
				if (var8) {
					trcLogger.logp(Level.FINER, CLASSNAME, "mapCertificate", "Search expression failure", var14);
				}

				throw new WIMException(var14.getMessageKey(),
						WIMMessageHelper.generateMsgParms(var9, var14.getMessage()), Level.SEVERE, CLASSNAME,
						"mapCertificate");
			}

			List var12;
			try {
				var12 = var7.search(var2, var11, true, true);
			} catch (Exception var15) {
				if (var8) {
					trcLogger.logp(Level.FINER, CLASSNAME, "mapCertificate", "Login failed", var15);
				}

				throw new WIMApplicationException("PASSWORD_CHECKED_FAILED",
						WIMMessageHelper.generateMsgParms(var9, var15.getMessage()), Level.SEVERE, CLASSNAME,
						"mapCertificate", var15);
			}

			if (var12.size() == 1) {
				var6 = (DataObject) var12.get(0);
			} else if (var12.size() > 1) {
				throw new CertificateMapFailedException("MULTIPLE_PRINCIPALS_FOUND",
						WIMMessageHelper.generateMsgParms(var9, this.getRepositoryId()), CLASSNAME, "mapCertificate");
			}
		} else {
			var9 = removeSpacesInDN(var5.getSubjectX500Principal().toString());

			try {
				var6 = var7.getByDN(var9);
			} catch (EntityNotFoundException var16) {
				if (var8) {
					trcLogger.logp(Level.FINER, CLASSNAME, "WIM_SPI mapCertificate",
							"principal DN, " + var9 + ", not found in " + this.fileID, var16);
				}
			} catch (Exception var17) {
				if (var8) {
					trcLogger.logp(Level.FINER, CLASSNAME, "mapCertificate", "Login failed", var17);
				}

				throw new WIMApplicationException("PASSWORD_CHECKED_FAILED",
						WIMMessageHelper.generateMsgParms(var9, var17.getMessage()), Level.SEVERE, CLASSNAME,
						"mapCertificate", var17);
			}
		}

		return var6;
	}

	private static String removeSpacesInDN(String var0) {
		String[] var1 = var0.split(",");
		StringBuilder var2 = new StringBuilder();

		for (int var3 = 0; var3 < var1.length; ++var3) {
			if (var1[var3].indexOf("=") >= 0) {
				var2.append(var1[var3].trim());
			} else {
				var2.append(var1[var3]);
			}

			if (var3 != var1.length - 1) {
				var2.append(",");
			}
		}

		return var2.toString();
	}

	public String getCertificateFilter(X509Certificate var1) throws CertificateMapperException {
		if (this.iCertFilterEles == null) {
			throw new CertificateMapperException("INVALID_PARAMETER_VALUE", CLASSNAME, "getCertificateFilter");
		} else {
			StringBuffer var3 = new StringBuffer();

			for (int var4 = 0; var4 < this.iCertFilterEles.length; ++var4) {
				String var5 = this.iCertFilterEles[var4];
				if (var5.charAt(0) != '$') {
					var3.append(var5);
				} else if (var5.equals("${UniqueKey}")) {
					var3.append(getUniqueKey(var1));
				} else if (var5.equals("${PublicKey}")) {
					var3.append(var1.getPublicKey().getEncoded());
				} else if (var5.startsWith("${Issuer")) {
					var3.append(getDNSubField(var5.substring(8, var5.length() - 1),
							removeSpacesInDN(var1.getIssuerX500Principal().toString())));
				} else if (var5.equals("${NotAfter}")) {
					var3.append(var1.getNotAfter().toString());
				} else if (var5.equals("${NotBefore}")) {
					var3.append(var1.getNotBefore().toString());
				} else if (var5.equals("${SerialNumber}")) {
					var3.append(var1.getSerialNumber());
				} else if (var5.equals("${SigAlgName}")) {
					var3.append(var1.getSigAlgName());
				} else if (var5.equals("${SigAlgOID}")) {
					var3.append(var1.getSigAlgOID());
				} else if (var5.equals("${SigAlgParams}")) {
					var3.append(var1.getSigAlgParams());
				} else if (var5.startsWith("${Subject")) {
					var3.append(getDNSubField(var5.substring(9, var5.length() - 1),
							removeSpacesInDN(var1.getSubjectX500Principal().toString())));
				} else {
					if (var5.equals("${TBSCertificate}")) {
						throw new CertificateMapperException("getTBSCertificate() is unsupported");
					}

					if (!var5.equals("${Version}")) {
						throw new CertificateMapperException("unknown variable: " + var5);
					}

					var3.append(var1.getVersion());
				}
			}

			return var3.toString();
		}
	}

	public static String getUniqueKey(X509Certificate var0) {
		StringBuffer var1 = new StringBuffer("subjectDN:");
		var1.append(removeSpacesInDN(var0.getSubjectX500Principal().toString())).append("issuerDN:")
				.append(removeSpacesInDN(var0.getIssuerX500Principal().toString()));
		return Base64Coder.base64Encode(getDigest(var1.toString()));
	}

	private static String getDigest(String var0) {
		MessageDigest var2;
		try {
			var2 = MessageDigest.getInstance("MD5");
		} catch (Exception var4) {
			trcLogger.logp(Level.FINE, CLASSNAME, "getDigest", var4.toString());
			return null;
		}

		var2.update(StringUtil.getBytes(var0));
		return StringUtil.toString(var2.digest());
	}

	static String getDNSubField(String var0, String var1) throws CertificateMapperException {
		if (var0.equals("DN")) {
			return var1;
		} else {
			StringTokenizer var3 = new StringTokenizer(var1);

			String var4;
			String var5;
			do {
				try {
					var4 = var3.nextToken(",= ");
					var5 = var3.nextToken(",");
					if (var5 != null) {
						var5 = var5.substring(1);
					}
				} catch (NoSuchElementException var7) {
					trcLogger.logp(Level.FINE, CLASSNAME, "getDNSubField", var7.toString());
					throw new CertificateMapperException("UNKOWN_DN_FIELD", WIMMessageHelper.generateMsgParms(var0),
							CLASSNAME, "getDNSubField");
				}
			} while (!var4.equals(var0));

			return var5;
		}
	}

	public void validateProfileType(String var1) throws NetworkConfigSyncException {
		if (this.sessionId == null && !DynamicReloadManager.isRunningOnDeploymentManager()
				&& !DynamicReloadManager.isRunningOnSingleServer() && !DynamicReloadManager.isConnectionTypeNone()
				&& !DynamicReloadManager.isRunningOnAdminAgent() && !DynamicReloadManager.isRunningOnJobManager()) {
			throw new NetworkConfigSyncException("DYNAMIC_RELOAD_INVALID_UPDATE_AT_MANAGED_NODE", Level.SEVERE,
					CLASSNAME, var1);
		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = FileAdapter.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
		IDENTIFIER_REF = DataGraphHelper.IDENTIFIER_REF;
		proxyMBean = null;
		instances = new HashMap(1);
		fileDataMap = null;
		freh = null;
	}
}