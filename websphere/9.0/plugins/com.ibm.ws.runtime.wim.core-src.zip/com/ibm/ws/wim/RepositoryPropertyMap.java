package com.ibm.ws.wim;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class RepositoryPropertyMap {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	HashMap reposPropCache = null;
	Set entityTypes = null;

	public RepositoryPropertyMap() {
		this.reposPropCache = new HashMap();
		this.entityTypes = new HashSet();
	}

	public Set getRepositoryPropertySetByEntityType(String var1) {
		HashSet var2 = null;
		if (var1 != null && this.reposPropCache != null) {
			var2 = (HashSet) this.reposPropCache.get(var1);
		}

		return var2;
	}

	public void setRepositoryPropertySetByEntityType(String var1, HashSet var2) {
		if (var1 != null && var2 != null) {
			this.reposPropCache.put(var1, var2);
			this.entityTypes.add(var1);
		}

	}

	public Set getEntityTypes() {
		return this.entityTypes;
	}
}