package com.google.common.graph;

import com.google.common.annotations.Beta;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Beta
public interface Graph<N> extends BaseGraph<N> {
	Set<N> nodes();

	Set<EndpointPair<N>> edges();

	boolean isDirected();

	boolean allowsSelfLoops();

	ElementOrder<N> nodeOrder();

	Set<N> adjacentNodes(N var1);

	Set<N> predecessors(N var1);

	Set<N> successors(N var1);

	Set<EndpointPair<N>> incidentEdges(N var1);

	int degree(N var1);

	int inDegree(N var1);

	int outDegree(N var1);

	boolean hasEdgeConnecting(N var1, N var2);

	boolean equals(@NullableDecl Object var1);

	int hashCode();
}