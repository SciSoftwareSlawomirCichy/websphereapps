package com.google.inject;

import com.google.inject.TypeConverterBindingProcessor.1;
import com.google.inject.TypeConverterBindingProcessor.2;
import com.google.inject.TypeConverterBindingProcessor.3;
import com.google.inject.TypeConverterBindingProcessor.4;
import com.google.inject.TypeConverterBindingProcessor.5;
import com.google.inject.TypeConverterBindingProcessor.6;
import com.google.inject.internal.Errors;
import com.google.inject.internal.MatcherAndConverter;
import com.google.inject.internal.SourceProvider;
import com.google.inject.internal.Strings;
import com.google.inject.matcher.Matcher;
import com.google.inject.matcher.Matchers;
import com.google.inject.spi.TypeConverter;
import com.google.inject.spi.TypeConverterBinding;
import java.lang.reflect.Method;

class TypeConverterBindingProcessor extends AbstractProcessor {
	TypeConverterBindingProcessor(Errors errors) {
		super(errors);
	}

	public void prepareBuiltInConverters(InjectorImpl injector) {
      this.injector = injector;

      try {
         this.convertToPrimitiveType(Integer.TYPE, Integer.class);
         this.convertToPrimitiveType(Long.TYPE, Long.class);
         this.convertToPrimitiveType(Boolean.TYPE, Boolean.class);
         this.convertToPrimitiveType(Byte.TYPE, Byte.class);
         this.convertToPrimitiveType(Short.TYPE, Short.class);
         this.convertToPrimitiveType(Float.TYPE, Float.class);
         this.convertToPrimitiveType(Double.TYPE, Double.class);
         this.convertToClass(Character.class, new 1(this));
         this.convertToClasses(Matchers.subclassesOf(Enum.class), new 2(this));
         this.internalConvertToTypes(new 3(this), new 4(this));
      } finally {
         this.injector = null;
      }

   }

	private <T> void convertToPrimitiveType(Class<T> primitiveType, Class<T> wrapperType) {
      try {
         Method parser = wrapperType.getMethod("parse" + Strings.capitalize(primitiveType.getName()), String.class);
         TypeConverter typeConverter = new 5(this, parser, wrapperType);
         this.convertToClass(wrapperType, typeConverter);
      } catch (NoSuchMethodException var5) {
         throw new AssertionError(var5);
      }
   }

	private <T> void convertToClass(Class<T> type, TypeConverter converter) {
		this.convertToClasses(Matchers.identicalTo(type), converter);
	}

	private void convertToClasses(Matcher<? super Class<?>> typeMatcher, TypeConverter converter) {
      this.internalConvertToTypes(new 6(this, typeMatcher), converter);
   }

	private void internalConvertToTypes(Matcher<? super TypeLiteral<?>> typeMatcher, TypeConverter converter) {
		this.injector.state
				.addConverter(new MatcherAndConverter(typeMatcher, converter, SourceProvider.UNKNOWN_SOURCE));
	}

	public Boolean visit(TypeConverterBinding command) {
		this.injector.state.addConverter(
				new MatcherAndConverter(command.getTypeMatcher(), command.getTypeConverter(), command.getSource()));
		return true;
	}
}