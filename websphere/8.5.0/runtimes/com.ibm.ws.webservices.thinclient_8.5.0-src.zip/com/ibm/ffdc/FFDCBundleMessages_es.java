package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_es extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: Se ha añadido el formateador FFDC {0}."},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: El motor de análisis está utilizando la base de datos: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: No se ha podido resolver el motor de análisis:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: Se añadió el recolector de datos FFDC {0}."},
			{"FFDCDataCollectorRemoved", "FFDC1012I: Se ha eliminado el recolector de datos FFDC {0}."},
			{"FFDCEmittedOnSysErr", "FFDC1004I: Se ha emitido un incidente FFDC en SystemErr: {0} {1}"},
			{"FFDCFailSafeErrChk",
					"FFDC1002W: FFDC en modalidad de protección contra anomalías. Verifique errores {0}."},
			{"FFDCForwarderAdded", "FFDC1013I: Se ha añadido el reenviador de incidentes FFDC {0}."},
			{"FFDCForwarderRemoved", "FFDC1014I: Se ha eliminado el reenviador de incidentes FFDC {0}."},
			{"FFDCIncidentEmitted", "FFDC1003I: Se ha emitido un incidente de FFDC en {0} {1} {2}"},
			{"FFDCProviderAborted",
					"FFDC1000I: El proveedor FFDC {0} terminó anormalmente. A continuación se proporciona la excepción."},
			{"FFDCProviderAbortedE", "FFDC1001I: El proveedor FFDC terminó anormalmente con la excepción {0}."},
			{"FFDCProviderException", "FFDC1008I: Excepción de proveedor FFDC:"},
			{"FFDCProviderInstalled", "FFDC1007I: Se ha instalado el proveedor FFDC: {0}."},
			{"FFDCRemovedFormatter", "FFDC1006I: Se ha eliminado el formateador FFDC {0}."}};

	public Object[][] getContents() {
		return resources;
	}
}