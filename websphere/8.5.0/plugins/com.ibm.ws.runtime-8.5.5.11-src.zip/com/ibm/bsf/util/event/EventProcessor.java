package com.ibm.bsf.util.event;

public interface EventProcessor {
	void processEvent(String var1, Object[] var2);

	void processExceptionableEvent(String var1, Object[] var2) throws Exception;
}