package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ejbcontainer.util.EJBSerializer.ObjectType;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;
import javax.ejb.EJBException;

public abstract class WrapperProxyState {
	private static final String CLASS_NAME = WrapperProxyState.class.getName();
	static final TraceComponent tc;
	final J2EEName ivJ2EEName;
	private final J2EEName ivUnversionedJ2EEName;
	private final byte[] ivUnversionedSerializerBytes;
	BeanId ivBeanId;
	volatile Object ivWrapper;

	public static WrapperProxyState getWrapperProxyState(Object proxy) {
		if (proxy instanceof BusinessLocalWrapperProxy) {
			return ((BusinessLocalWrapperProxy) proxy).ivState;
		} else if (proxy instanceof EJSLocalWrapperProxy) {
			return ((EJSLocalWrapperProxy) proxy).ivState;
		} else if (proxy instanceof LocalBeanWrapperProxy) {
			return EJSWrapperCommon.getLocalBeanWrapperProxy(proxy).ivState;
		} else if (proxy instanceof WrapperProxy) {
			throw new IllegalStateException(Util.identity(proxy));
		} else {
			throw new IllegalArgumentException(Util.identity(proxy));
		}
	}

	WrapperProxyState(EJSHome home, BeanId beanId, Object wrapper) {
		this.ivJ2EEName = home.getJ2EEName();
		J2EEName unversionedJ2EEName = null;
		byte[] unversionedSerializerBytes = null;
		BeanMetaData bmd = home.beanMetaData;
		if (bmd.ivUnversionedJ2eeName != null) {
			unversionedJ2EEName = bmd.ivUnversionedJ2eeName;
			unversionedSerializerBytes = beanId.getByteArrayBytes();
		}

		this.ivUnversionedJ2EEName = unversionedJ2EEName;
		this.ivUnversionedSerializerBytes = unversionedSerializerBytes;
		this.connect(beanId, wrapper);
	}

	public final String toString() {
		StringBuilder builder = (new StringBuilder(this.getClass().getSimpleName())).append('(');
		builder.append(this.ivJ2EEName.toString());
		if (this.ivWrapper == null) {
			builder.append(", disconnected");
		}

		if (this.ivUnversionedJ2EEName != null) {
			builder.append(", unversioned: " + this.ivUnversionedJ2EEName.getModule());
		}

		return builder.append(')').toString();
	}

	public abstract int hashCode();

	public abstract boolean equals(WrapperProxyState var1);

	final void connect(BeanId beanId, Object wrapper) {
		this.ivBeanId = beanId;
		this.ivWrapper = wrapper;
	}

	final void disconnect() {
		this.ivBeanId = null;
		this.ivWrapper = null;
	}

	final WrapperProxyState reconnect() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "reconnect: " + this);
		}

		HomeOfHomes homeOfHomes = EJSContainer.homeOfHomes;
		J2EEName j2eeName;
		if (this.ivUnversionedJ2EEName == null) {
			j2eeName = this.ivJ2EEName;
		} else {
			j2eeName = homeOfHomes.getVersionedJ2EEName(this.ivUnversionedJ2EEName);
		}

		EJSHome home = (EJSHome) homeOfHomes.getHome(j2eeName);
		if (home == null) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "reconnect: stopped");
			}

			throw new EJBException("The referenced " + j2eeName.getComponent() + " bean in the " + j2eeName.getModule()
					+ " module in the " + j2eeName.getApplication()
					+ " application has been stopped and must be started again to be used.");
		} else {
			WrapperProxyState state;
			try {
				state = this.reconnect(home);
			} catch (RemoteException var7) {
				FFDCFilter.processException(var7, this.getClass().getName() + ".update", "225", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "reconnect", var7);
				}

				throw new EJBException(var7);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "reconnect");
			}

			return state;
		}
	}

	abstract WrapperProxyState reconnect(EJSHome var1) throws RemoteException;

	public abstract ObjectType getSerializerObjectType();

	public final byte[] getSerializerBytes() {
		if (this.ivUnversionedSerializerBytes != null) {
			return this.ivUnversionedSerializerBytes;
		} else {
			BeanId beanId = this.ivBeanId;
			if (beanId == null) {
				beanId = this.getSerializerBeanId(this.ivJ2EEName);
			}

			return this.getSerializerBytes(beanId);
		}
	}

	abstract BeanId getSerializerBeanId(J2EEName var1);

	byte[] getSerializerBytes(BeanId beanId) {
		return beanId.getByteArrayBytes();
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}