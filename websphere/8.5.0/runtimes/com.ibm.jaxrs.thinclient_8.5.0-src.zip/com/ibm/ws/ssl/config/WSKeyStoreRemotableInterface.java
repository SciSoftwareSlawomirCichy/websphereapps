package com.ibm.ws.ssl.config;

import com.ibm.websphere.crypto.KeyException;

public interface WSKeyStoreRemotableInterface {
	Object[] invokeKeyStoreCommand(String var1, Object[] var2) throws KeyException;

	Object[] invokeKeyStoreCommand(String var1, Object[] var2, Boolean var3) throws KeyException;

	void store() throws Exception;
}