package com.ibm.ejs.csi;

import com.ibm.ws.runtime.deploy.DeployedModule;
import com.ibm.ws.runtime.service.MetaDataFactoryMgr;

public class WASEJBModuleMetaDataImpl extends SharedEJBModuleMetaDataImpl {
	public DeployedModule ivDeployedModule;
	public MetaDataFactoryMgr ivMetaDataFactoryMgr;

	public WASEJBModuleMetaDataImpl(int slotSize, EJBApplicationMetaData ejbAMD) {
		super(slotSize, ejbAMD);
	}

	protected void toString(StringBuilder sb, String nl, String indent) {
		sb.append(nl).append(indent).append("DeployedModule = ").append(this.ivDeployedModule);
		sb.append(nl).append(indent).append("MetaDataFactoryMgr = ").append(this.ivMetaDataFactoryMgr);
	}
}