package com.ibm.debug;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.webcontainer.metadata.WebComponentMetaData;
import com.ibm.ws.webcontainer.webapp.collaborator.WebAppInvocationCollaborator;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class DebugWebAppInvocationCollaborator implements WebAppInvocationCollaborator {
	protected String uriName = null;
	private static final TraceComponent tc = Tr.register(DebugWebAppInvocationCollaborator.class.getName(),
			"DebugComponent");

	public void preInvoke(WebComponentMetaData metaData) {
		String implementationClass = metaData.getImplementationClass();
		if (implementationClass != null && !checkfilterlist(implementationClass)
				&& metaData.getWebComponentType() == 2) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "JSP adding breakpoint at <init> in " + implementationClass);
			}

			String jspMethodSignature = "()V";
			DebugBreakpoints.debugJSPBreakpoint(implementationClass, "<init>", this.uriName, jspMethodSignature);
		}

	}

	public void postInvoke(WebComponentMetaData metaData) {
	}

	public void preInvoke(WebComponentMetaData metaData, ServletRequest req, ServletResponse res) {
		String currentUriName = null;
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "preInvoke");
		}

		String implementationClass = metaData.getImplementationClass();
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "preInvoke for " + this.getMethod(((HttpServletRequest) req).getMethod()) + " in "
					+ implementationClass);
		}

		if (implementationClass != null && !checkfilterlist(implementationClass)) {
			if (metaData.getWebComponentType() == 1) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "SERVLET adding breakpoint at "
							+ this.getMethod(((HttpServletRequest) req).getMethod()) + " in " + implementationClass);
				}

				currentUriName = ((HttpServletRequest) req).getRequestURI();
				this.setURIName(currentUriName);
				DebugBreakpoints.debugServletBreakpoint(implementationClass,
						this.getMethod(((HttpServletRequest) req).getMethod()));
			} else if (metaData.getWebComponentType() == 2) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "JSP adding breakpoint at _jspService in " + implementationClass);
				}

				String jspMethodSignature = "(Ljavax/servlet/http/HttpServletRequest;Ljavax/servlet/http/HttpServletResponse;)V";
				DebugBreakpoints.debugJSPBreakpoint(implementationClass, "_jspService",
						((HttpServletRequest) req).getRequestURI(), jspMethodSignature);
			} else if (tc.isDebugEnabled()) {
				Tr.debug(tc, "some other value " + metaData.getWebComponentType());
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "preInvoke");
		}

	}

	public void postInvoke(WebComponentMetaData metaData, ServletRequest req, ServletResponse res) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "postInvoke");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "postInvoke");
		}

	}

	protected String getMethod(String methodName) {
		if (methodName.equals("GET")) {
			return "doGet";
		} else if (methodName.equals("POST")) {
			return "doPost";
		} else if (methodName.equals("HEAD")) {
			return "doHead";
		} else if (methodName.equals("PUT")) {
			return "doPut";
		} else if (methodName.equals("DELETE")) {
			return "doDelete";
		} else if (methodName.equals("OPTIONS")) {
			return "doOptions";
		} else {
			return methodName.equals("TRACE") ? "doTrace" : methodName;
		}
	}

	protected static boolean checkfilterlist(String className) {
		if (className != null && DebugAppServerComponentImpl.debugClassFilters != null) {
			for (int i = 0; i < DebugAppServerComponentImpl.debugClassFilters.size(); ++i) {
				String filter = (String) DebugAppServerComponentImpl.debugClassFilters.get(i);
				int index = filter.indexOf(42);
				if (index != -1) {
					filter = filter.substring(0, index);
					if (className.startsWith(filter)) {
						return true;
					}
				} else if (className.equals(filter)) {
					return true;
				}
			}
		}

		return false;
	}

	protected String getURIName() {
		return this.uriName;
	}

	protected void setURIName(String currentUriName) {
		this.uriName = currentUriName;
	}

	public static void preInvokeForOSGi(String className, String methodName, String methodSignature, String bundleName,
			String bundleVersion) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "preInvokeForOSGi for " + className + "." + methodName + "." + methodSignature + " in bundle "
					+ bundleName + " version " + bundleVersion);
		}

		if (className != null && !checkfilterlist(className)) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, className + "." + methodName + "." + methodSignature
						+ " will not be filtered out, calling debugBluePrintBreakpoint");
			}

			DebugBreakpoints.debugBlueprintBreakpoint(className, methodName, methodSignature, bundleName,
					bundleVersion);
		} else if (tc.isDebugEnabled()) {
			Tr.debug(tc, "preInvokeforOSGi: " + className + " will  be filtered out.");
		}

	}
}