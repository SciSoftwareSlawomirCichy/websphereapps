package com.ibm.ws.security.openid20.util;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class MessageHelper {
	public static final String _TR_GROUP = "OpenIDClient";
	public static final String _MSG_FILE = "com.ibm.ws.security.openid20.client.resources.oidmessages";
	private static ResourceBundle resBundle = ResourceBundle
			.getBundle("com.ibm.ws.security.openid20.client.resources.oidmessages", Locale.getDefault());
	private static TraceComponent tc = Tr.register(MessageHelper.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");

	public static String getMessage(String key) {
		return getMessage(resBundle, key, (Object[]) null);
	}

	public static String getMessage(String key, String arg1) {
		return getMessage(key, new Object[]{arg1});
	}

	public static String getMessage(String key, Object[] args) {
		return getMessage(resBundle, key, args);
	}

	public static String getMessage(ResourceBundle bundle, String key, Object[] args) {
		String message = null;

		try {
			message = bundle.getString(key);
			if (message == null) {
				message = new String("Cannot find message key " + key + "in resource bundle" + bundle.toString());
				Tr.event(tc, message);
			}

			message = MessageFormat.format(message, args);
		} catch (MissingResourceException var5) {
			message = new String("Cannot find message key " + key + "in resource bundle " + bundle.toString());
			Tr.event(tc, message);
			return message;
		} catch (NullPointerException var6) {
			message = new String("Null pointer exception caught trying to find message key " + key
					+ " in resource bundle " + bundle.toString());
			Tr.event(tc, message);
		}

		return message;
	}
}