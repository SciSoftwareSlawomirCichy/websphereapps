package com.ibm.icu.text;

import com.ibm.icu.impl.ICUCache;
import com.ibm.icu.impl.ICUResourceBundle;
import com.ibm.icu.impl.SimpleCache;
import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;
import com.ibm.icu.util.UResourceBundleIterator;
import java.util.ArrayList;
import java.util.Locale;
import java.util.MissingResourceException;

class NumberingSystem {
	private String desc = "0123456789";
	private int radix = 10;
	private boolean algorithmic = false;
	private static ICUCache<String, NumberingSystem> cachedLocaleData = new SimpleCache();
	private static ICUCache<String, NumberingSystem> cachedStringData = new SimpleCache();

	public static NumberingSystem getInstance(int radix_in, boolean isAlgorithmic_in, String desc_in) {
		if (radix_in < 2) {
			throw new IllegalArgumentException("Invalid radix for numbering system");
		} else if (isAlgorithmic_in || desc_in.length() == radix_in && isValidDigitString(desc_in)) {
			NumberingSystem ns = new NumberingSystem();
			ns.radix = radix_in;
			ns.algorithmic = isAlgorithmic_in;
			ns.desc = desc_in;
			return ns;
		} else {
			throw new IllegalArgumentException("Invalid digit string for numbering system");
		}
	}

	public static NumberingSystem getInstance(Locale inLocale) {
		return getInstance(ULocale.forLocale(inLocale));
	}

	public static NumberingSystem getInstance(ULocale locale) {
		String numbersKeyword = locale.getKeywordValue("numbers");
		NumberingSystem ns;
		if (numbersKeyword != null) {
			ns = getInstanceByName(numbersKeyword);
			if (ns != null) {
				return ns;
			}
		}

		String baseName = locale.getBaseName();
		ns = (NumberingSystem) cachedLocaleData.get(baseName);
		if (ns != null) {
			return ns;
		} else {
			String defaultNumberingSystem;
			try {
				ICUResourceBundle rb = (ICUResourceBundle) UResourceBundle
						.getBundleInstance("com/ibm/icu/impl/data/icudt44b", locale);
				defaultNumberingSystem = rb.getString("defaultNumberingSystem");
			} catch (MissingResourceException var6) {
				ns = new NumberingSystem();
				cachedLocaleData.put(baseName, ns);
				return ns;
			}

			ns = getInstanceByName(defaultNumberingSystem);
			if (ns != null) {
				cachedLocaleData.put(baseName, ns);
				return ns;
			} else {
				ns = new NumberingSystem();
				cachedLocaleData.put(baseName, ns);
				return ns;
			}
		}
	}

	public static NumberingSystem getInstance() {
		return getInstance(ULocale.getDefault());
	}

	public static NumberingSystem getInstanceByName(String name) {
		NumberingSystem ns = (NumberingSystem) cachedStringData.get(name);
		if (ns != null) {
			return ns;
		} else {
			int radix;
			boolean isAlgorithmic;
			String description;
			try {
				UResourceBundle numberingSystemsInfo = UResourceBundle
						.getBundleInstance("com/ibm/icu/impl/data/icudt44b", "numberingSystems");
				UResourceBundle nsCurrent = numberingSystemsInfo.get("numberingSystems");
				UResourceBundle nsTop = nsCurrent.get(name);
				description = nsTop.getString("desc");
				UResourceBundle nsRadixBundle = nsTop.get("radix");
				UResourceBundle nsAlgBundle = nsTop.get("algorithmic");
				radix = nsRadixBundle.getInt();
				int algorithmic = nsAlgBundle.getInt();
				isAlgorithmic = algorithmic == 1;
			} catch (MissingResourceException var11) {
				return null;
			}

			ns = getInstance(radix, isAlgorithmic, description);
			cachedStringData.put(name, ns);
			return ns;
		}
	}

	public static String[] getAvailableNames() {
		UResourceBundle numberingSystemsInfo = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b",
				"numberingSystems");
		UResourceBundle nsCurrent = numberingSystemsInfo.get("numberingSystems");
		ArrayList<String> output = new ArrayList();
		UResourceBundleIterator it = nsCurrent.getIterator();

		while (it.hasNext()) {
			UResourceBundle temp = it.next();
			String nsName = temp.getKey();
			output.add(nsName);
		}

		return (String[]) output.toArray(new String[output.size()]);
	}

	public static boolean isValidDigitString(String str) {
		int prev = 0;
		int i = 0;
		UCharacterIterator it = UCharacterIterator.getInstance(str);
		it.setToStart();

		int c;
		while ((c = it.nextCodePoint()) != -1) {
			if (UCharacter.digit(c) != i) {
				return false;
			}

			if (prev != 0 && c != prev + 1) {
				return false;
			}

			if (UCharacter.isSupplementary(c)) {
				return false;
			}

			++i;
			prev = c;
		}

		return true;
	}

	public int getRadix() {
		return this.radix;
	}

	public String getDescription() {
		return this.desc;
	}

	public boolean isAlgorithmic() {
		return this.algorithmic;
	}
}