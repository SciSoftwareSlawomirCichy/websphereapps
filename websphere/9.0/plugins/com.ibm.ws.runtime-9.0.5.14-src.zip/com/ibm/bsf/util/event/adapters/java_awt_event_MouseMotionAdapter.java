package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class java_awt_event_MouseMotionAdapter extends EventAdapterImpl implements MouseMotionListener {
	public void mouseDragged(MouseEvent var1) {
		this.eventProcessor.processEvent("mouseDragged", new Object[]{var1});
	}

	public void mouseMoved(MouseEvent var1) {
		this.eventProcessor.processEvent("mouseMoved", new Object[]{var1});
	}
}