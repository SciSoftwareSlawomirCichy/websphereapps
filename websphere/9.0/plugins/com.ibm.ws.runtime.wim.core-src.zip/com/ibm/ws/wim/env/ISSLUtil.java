package com.ibm.ws.wim.env;

import com.ibm.websphere.wim.exception.WIMConfigurationException;
import java.util.Hashtable;
import java.util.Properties;

public interface ISSLUtil {
	void setSSLPropertiesOnThread(Properties var1);

	Properties getSSLPropertiesOnThread();

	void setSSLAlias(String var1, Hashtable var2) throws WIMConfigurationException;

	void resetSSLAlias();
}