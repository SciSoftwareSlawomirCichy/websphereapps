package com.ibm.ejs.util.dopriv;

import java.security.PrivilegedAction;

public class GetContextClassLoaderPrivileged implements PrivilegedAction {
	public ClassLoader currentClassLoader;

	public Object run() {
		this.currentClassLoader = Thread.currentThread().getContextClassLoader();
		return this.currentClassLoader;
	}
}