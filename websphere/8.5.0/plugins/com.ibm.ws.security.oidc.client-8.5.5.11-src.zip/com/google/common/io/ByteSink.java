package com.google.common.io;

import com.google.common.base.Preconditions;
import com.google.common.io.ByteSink.1;
import com.google.common.io.ByteSink.AsCharSink;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

public abstract class ByteSink {
	public CharSink asCharSink(Charset charset) {
      return new AsCharSink(this, charset, (1)null);
   }

	public abstract OutputStream openStream() throws IOException;

	public BufferedOutputStream openBufferedStream() throws IOException {
		OutputStream out = this.openStream();
		return out instanceof BufferedOutputStream ? (BufferedOutputStream) out : new BufferedOutputStream(out);
	}

	public void write(byte[] bytes) throws IOException {
		Preconditions.checkNotNull(bytes);
		Closer closer = Closer.create();

		try {
			OutputStream out = (OutputStream) closer.register(this.openStream());
			out.write(bytes);
		} catch (Throwable var7) {
			throw closer.rethrow(var7);
		} finally {
			closer.close();
		}

	}

	public long writeFrom(InputStream input) throws IOException {
		Preconditions.checkNotNull(input);
		Closer closer = Closer.create();

		long var4;
		try {
			OutputStream out = (OutputStream) closer.register(this.openStream());
			var4 = ByteStreams.copy(input, out);
		} catch (Throwable var9) {
			throw closer.rethrow(var9);
		} finally {
			closer.close();
		}

		return var4;
	}
}