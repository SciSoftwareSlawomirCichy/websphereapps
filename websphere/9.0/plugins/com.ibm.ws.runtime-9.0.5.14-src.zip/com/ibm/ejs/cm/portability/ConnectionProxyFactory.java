package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.cm.proxy.ConnectionProxy;

public interface ConnectionProxyFactory {
	ConnectionProxy createConnectionProxy(ConnectO var1);
}