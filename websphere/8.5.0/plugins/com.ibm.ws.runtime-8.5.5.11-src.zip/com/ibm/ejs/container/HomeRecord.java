package com.ibm.ejs.container;

import com.ibm.ejs.csi.EJBApplicationMetaData;
import com.ibm.ejs.csi.EJBModuleMetaDataImpl;
import com.ibm.websphere.csi.J2EEName;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

public class HomeRecord {
	protected BeanO beanO = null;
	protected volatile HomeInternal homeInternal = null;
	protected BeanMetaData bmd;
	protected EJBModuleMetaDataImpl ejbMmd;
	protected HomeOfHomes homeOfHomes;
	protected J2EEName j2eeName;
	protected int cmpVersion;
	protected String connFactoryName;
	protected String ejbName;
	protected ClassLoader classLoader;
	protected int beanType;
	protected BindingsHelper ivRemoteBindingsHelper = null;
	protected BindingsHelper ivLocalBindingsHelper = null;
	public final List<String> ivJavaGlobalBindings = new ArrayList();
	public final List<String> ivJavaAppBindings = new ArrayList();
	public Hashtable<String, HomeRecord> childBeans = new Hashtable();
	public boolean ivHasInheritance = false;
	public boolean ivIsChild = false;
	private Boolean ivShortDefaultBindingsEnabled = null;

	public HomeRecord(BeanMetaData bmd, HomeOfHomes homeOfHomes) {
		this.bmd = bmd;
		this.ejbMmd = bmd._moduleMetaData;
		this.homeOfHomes = homeOfHomes;
		this.j2eeName = bmd.j2eeName;
		this.cmpVersion = bmd.cmpVersion;
		this.connFactoryName = bmd.connFactoryName;
		this.ejbName = bmd.enterpriseBeanName;
		this.classLoader = bmd.classLoader;
		Hashtable<String, HomeRecord> homeMap = this.ejbMmd.ivHomeMap;
		homeMap.put(this.ejbName, this);
		this.ejbMmd.ivHomeMap = homeMap;
		this.beanType = bmd.type;
	}

	public boolean hasInheritance() {
		return this.ivHasInheritance;
	}

	public String getAppName() {
		return this.bmd.j2eeName.getApplication();
	}

	public EJSHome getTargetHome(String child) {
		EJSHome targetHome = null;
		HomeRecord targetHomeRecord = (HomeRecord) this.childBeans.get(child);
		if (targetHomeRecord == null) {
			Enumeration children = this.childBeans.elements();

			while (children.hasMoreElements()) {
				HomeRecord childHomeRecord = (HomeRecord) children.nextElement();
				targetHome = childHomeRecord.getTargetHome(child);
				if (targetHome != null) {
					break;
				}
			}
		}

		if (targetHomeRecord != null) {
			targetHome = targetHomeRecord.getHomeAndInitialize();
		}

		return targetHome;
	}

	public BeanMetaData getBeanMetaData() {
		return this.bmd;
	}

	public J2EEName getJ2EEName() {
		return this.j2eeName;
	}

	public String getJndiName() {
		return this.bmd.getJndiName();
	}

	public String getJNDIName(Object pkey) {
		return this.bmd.getJndiName();
	}

	public int getCmpVersion() {
		return this.cmpVersion;
	}

	public String getConnFactoryName() {
		return this.connFactoryName;
	}

	public EJSHome getHome() {
		EJSHome result = (EJSHome) this.homeInternal;
		return result;
	}

	public EJSHome getHomeAndInitialize() {
		EJSHome result = (EJSHome) this.homeInternal;
		if (result == null) {
			EJBModuleMetaDataImpl mmd = this.bmd._moduleMetaData;
			EJBApplicationMetaData ejbAMD = mmd.getEJBApplicationMetaData();
			ejbAMD.checkIfEJBWorkAllowed(mmd);
			synchronized (ejbAMD) {
				result = (EJSHome) this.homeInternal;
				if (result == null) {
					result = this.bmd.container.getEJBRuntime().initializeDeferredEJB(this);
				}
			}
		}

		return result;
	}

	public EJBModuleMetaDataImpl getEJBModuleMetaData() {
		return this.ejbMmd;
	}

	public String getEJBName() {
		return this.ejbName;
	}

	public ClassLoader getClassLoader() {
		return this.classLoader;
	}

	public int getBeanType() {
		return this.beanType;
	}

	public String toString() {
		String initialized = this.homeInternal == null ? "deferred" : "initialized";
		return "HomeRecord(" + this.j2eeName + ", " + this.bmd.getJndiName() + ", " + initialized + ")";
	}

	public boolean shortDefaultBindingsEnabled() {
		if (this.ivShortDefaultBindingsEnabled == null) {
			this.ivShortDefaultBindingsEnabled = BindingsHelper.shortDefaultBindingsEnabled(this.getAppName());
		}

		return this.ivShortDefaultBindingsEnabled;
	}

	public boolean bindToJavaNameSpaces() {
		return this.bmd.isSessionBean() && this.bmd._moduleMetaData.getEJBApplicationMetaData().isBindToJavaGlobal()
				&& this.bmd.enterpriseBeanName.indexOf(47) == -1
				|| this.bmd.isManagedBean() && !this.bmd.enterpriseBeanName.startsWith("$");
	}

	public boolean bindToJavaGlobalNameSpace() {
		return !this.bmd.isManagedBean();
	}

	public boolean bindInterfaceNames() {
		return !this.bmd.isManagedBean();
	}

	public boolean bindToContextRoot() {
		return !this.bmd.isManagedBean() && (!this.bmd.isSessionBean()
				|| this.bmd._moduleMetaData.getEJBApplicationMetaData().isBindToServerRoot());
	}
}