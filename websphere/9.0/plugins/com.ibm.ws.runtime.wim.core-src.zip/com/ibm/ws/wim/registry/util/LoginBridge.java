package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.security.CertificateMapFailedException;
import com.ibm.websphere.security.CertificateMapNotSupportedException;
import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.PasswordCheckFailedException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.ws.wim.RealmManager;
import com.ibm.ws.wim.registry.dataobject.IDAndRealm;
import com.ibm.ws.wim.util.StringUtil;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginBridge {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private final String className = LoginBridge.class.getName();
	private Logger loginBridgeTrace;
	private TypeMappings propertyMap;
	private BridgeUtils mappingUtils;

	public LoginBridge() {
		this.loginBridgeTrace = WIMLogger.getTraceLogger(this.className);
		this.propertyMap = new TypeMappings();
		this.mappingUtils = BridgeUtils.singleton();
		String var1 = "LoginBridge";
		if (this.loginBridgeTrace.isLoggable(Level.FINER)) {
			this.loginBridgeTrace.entering(this.className, var1);
		}

		if (this.loginBridgeTrace.isLoggable(Level.FINER)) {
			this.loginBridgeTrace.exiting(this.className, var1);
		}

	}

	public String checkPassword(String var1, String var2)
			throws PasswordCheckFailedException, CustomRegistryException, RemoteException {
		String var3 = "checkPassword";
		if (this.loginBridgeTrace.isLoggable(Level.FINER)) {
			this.loginBridgeTrace.entering(this.className, var3, "inputUser = \"" + var1 + "\", inputPassword = *");
		}

		StringBuffer var4 = new StringBuffer();

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var5 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var6 = this.mappingUtils.getWimService().createRootDataObject();
			if (var5.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var6, var5.getRealm());
				DataObject var7 = var6.createDataObject("contexts");
				var7.set("key", "allowOperationIfReposDown");
				var7.set("value", RealmManager.singleton().getAllowOperationIfReposDown(var5.getRealm()));
			}

			BridgeUtils var10000 = this.mappingUtils;
			boolean var13 = BridgeUtils.allowDNAsPrincipalName;
			DataObject var8;
			if (var13) {
				var8 = var6.createDataObject("contexts");
				var8.set("key", "allowDNPrincipalNameAsLiteral");
				var8.set("value", var13);
			}

			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var5.getRealm()))) {
				this.mappingUtils.createLoginControlDataObject(var6,
						this.propertyMap.getOutputUserSecurityName(var5.getRealm()));
			}

			var8 = var6.createDataObject("entities", "http://www.ibm.com/websphere/wim", "LoginAccount");
			String var9 = null;
			if (var13) {
				var9 = var1;
			} else {
				var9 = var5.getId();
			}

			var9 = StringUtil.escapeSearchExpression(var9);
			var8.set("principalName", var9);
			var8.set("password", PasswordUtil.getByteArrayPassword(var2));
			var6 = this.mappingUtils.getWimService().login(var6);
			List var10 = var6.getList("entities");
			if (var10.isEmpty()) {
				throw new com.ibm.websphere.wim.exception.PasswordCheckFailedException("ENTITY_NOT_FOUND",
						WIMMessageHelper.generateMsgParms(var1), this.className, var3);
			}

			DataObject var11 = (DataObject) var10.get(0);
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var5.getRealm()))) {
				var4.append(var11.getString(this.propertyMap.getOutputUserSecurityName(var5.getRealm())));
			} else {
				var4.append(
						var11.getString("identifier/" + this.propertyMap.getOutputUserSecurityName(var5.getRealm())));
			}

			if (var5.isRealmDefined() && !RealmManager.singleton().getDefaultRealmName().equals(var5.getRealm())) {
				var4.append(var5.getDelimiter() + var5.getRealm());
			}
		} catch (WIMException var12) {
			this.mappingUtils.logException(var12, this.className);
			if (var12 instanceof com.ibm.websphere.wim.exception.PasswordCheckFailedException) {
				throw new PasswordCheckFailedException(var12.getMessage(), var12);
			}

			if (var12 instanceof EntityNotFoundException) {
				throw new PasswordCheckFailedException(var12.getMessage(), var12);
			}

			throw new CustomRegistryException(var12);
		}

		if (this.loginBridgeTrace.isLoggable(Level.FINER)) {
			this.loginBridgeTrace.exiting(this.className, var3, "returnValue = \"" + var4 + "\"");
		}

		return var4.toString();
	}

	public String mapCertificate(X509Certificate[] var1) throws CertificateMapNotSupportedException,
			CertificateMapFailedException, CustomRegistryException, RemoteException {
		String var2 = "mapCertificate";
		if (this.loginBridgeTrace.isLoggable(Level.FINER)) {
			this.loginBridgeTrace.entering(this.className, var2, "inputCertificates = \"" + var1 + "\"");
		}

		StringBuffer var3 = new StringBuffer();

		try {
			this.mappingUtils.validateCertificateArray(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm("");
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var4.getRealm()))) {
				this.mappingUtils.createLoginControlDataObject(var5,
						this.propertyMap.getOutputUserSecurityName(var4.getRealm()));
			}

			DataObject var6 = var5.createDataObject("entities", "http://www.ibm.com/websphere/wim", "LoginAccount");
			var6.getList("certificate").add(var1[0].getEncoded());
			var5 = this.mappingUtils.getWimService().login(var5);
			List var7 = var5.getList("entities");
			if (var7.isEmpty()) {
				throw new com.ibm.websphere.wim.exception.CertificateMapFailedException();
			}

			DataObject var8 = (DataObject) var7.get(0);
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var4.getRealm()))) {
				var3.append(var8.getString(this.propertyMap.getOutputUserSecurityName(var4.getRealm())));
			} else {
				var3.append(
						var8.getString("identifier/" + this.propertyMap.getOutputUserSecurityName(var4.getRealm())));
			}

			if (var4.isRealmDefined() && !RealmManager.singleton().getDefaultRealmName().equals(var4.getRealm())) {
				var3.append(var4.getDelimiter() + var4.getRealm());
			}
		} catch (CertificateEncodingException var9) {
			this.mappingUtils.logException(var9, this.className);
			throw new CustomRegistryException(var9);
		} catch (WIMException var10) {
			this.mappingUtils.logException(var10, this.className);
			if (var10 instanceof com.ibm.websphere.wim.exception.CertificateMapNotSupportedException) {
				throw new CertificateMapNotSupportedException(var10);
			}

			if (var10 instanceof com.ibm.websphere.wim.exception.CertificateMapFailedException) {
				throw new CertificateMapFailedException(var10);
			}

			throw new CustomRegistryException(var10);
		}

		if (this.loginBridgeTrace.isLoggable(Level.FINER)) {
			this.loginBridgeTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3.toString();
	}
}