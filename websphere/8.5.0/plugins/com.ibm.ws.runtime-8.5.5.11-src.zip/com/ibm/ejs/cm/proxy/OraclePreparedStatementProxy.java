package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OraclePreparedStatementProxy extends PreparedStatementProxy {
	private static final TraceComponent tc = Tr.register(OraclePreparedStatementProxy.class);

	OraclePreparedStatementProxy(OracleConnectionProxy parent, PreparedStatement statement) {
		super(parent, statement);
	}

	public void setBytes(int parameterIndex, byte[] x) throws SQLException {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "byteArray length: " + (x == null ? 0 : x.length));
		}

		if (x != null && x.length > 2000) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "ORACLE setBytes byte array length > 2000 workaround.");
			}

			((PreparedStatement) this.getStatement()).setBinaryStream(parameterIndex, new ByteArrayInputStream(x),
					x.length);
		} else {
			((PreparedStatement) this.getStatement()).setBytes(parameterIndex, x);
		}

	}

	public void setString(int parameterIndex, String x) throws SQLException {
		int length = x == null ? 0 : x.getBytes().length;
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "string length: " + length);
		}

		if (length > 4000) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Oracle setString length > 4000 bytes workaround.");
			}

			((PreparedStatement) this.getStatement()).setCharacterStream(parameterIndex, new StringReader(x),
					x.length());
		} else {
			((PreparedStatement) this.getStatement()).setString(parameterIndex, x);
		}

	}
}