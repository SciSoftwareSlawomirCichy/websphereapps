package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Objects;
import com.google.common.collect.LinkedListMultimap.1;
import com.google.common.collect.LinkedListMultimap.2;
import com.google.common.collect.LinkedListMultimap.3;
import com.google.common.collect.LinkedListMultimap.4;
import com.google.common.collect.LinkedListMultimap.5;
import com.google.common.collect.LinkedListMultimap.6;
import com.google.common.collect.LinkedListMultimap.KeyList;
import com.google.common.collect.LinkedListMultimap.MultisetView;
import com.google.common.collect.LinkedListMultimap.Node;
import com.google.common.collect.LinkedListMultimap.NodeIterator;
import com.google.common.collect.LinkedListMultimap.ValueForKeyIterator;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(serializable = true, emulated = true)
public class LinkedListMultimap<K, V> implements ListMultimap<K, V>, Serializable {
	private transient Node<K, V> head;
	private transient Node<K, V> tail;
	private transient Map<K, KeyList<K, V>> keyToKeyList;
	private transient int size;
	private transient int modCount;
	private transient Set<K> keySet;
	private transient Multiset<K> keys;
	private transient List<V> valuesList;
	private transient List<Entry<K, V>> entries;
	private transient Map<K, Collection<V>> map;
	@GwtIncompatible("java serialization not supported")
	private static final long serialVersionUID = 0L;

	public static <K, V> LinkedListMultimap<K, V> create() {
		return new LinkedListMultimap();
	}

	public static <K, V> LinkedListMultimap<K, V> create(int expectedKeys) {
		return new LinkedListMultimap(expectedKeys);
	}

	public static <K, V> LinkedListMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap) {
		return new LinkedListMultimap(multimap);
	}

	LinkedListMultimap() {
		this.keyToKeyList = Maps.newHashMap();
	}

	private LinkedListMultimap(int expectedKeys) {
		this.keyToKeyList = new HashMap(expectedKeys);
	}

	private LinkedListMultimap(Multimap<? extends K, ? extends V> multimap) {
		this(multimap.keySet().size());
		this.putAll(multimap);
	}

	private Node<K, V> addNode(@Nullable K key, @Nullable V value, @Nullable Node<K, V> nextSibling) {
		Node<K, V> node = new Node(key, value);
		if (this.head == null) {
			this.head = this.tail = node;
			this.keyToKeyList.put(key, new KeyList(node));
			++this.modCount;
		} else {
			KeyList keyList;
			if (nextSibling == null) {
				this.tail.next = node;
				node.previous = this.tail;
				this.tail = node;
				keyList = (KeyList) this.keyToKeyList.get(key);
				if (keyList == null) {
					this.keyToKeyList.put(key, new KeyList(node));
					++this.modCount;
				} else {
					++keyList.count;
					Node<K, V> keyTail = keyList.tail;
					keyTail.nextSibling = node;
					node.previousSibling = keyTail;
					keyList.tail = node;
				}
			} else {
				keyList = (KeyList) this.keyToKeyList.get(key);
				++keyList.count;
				node.previous = nextSibling.previous;
				node.previousSibling = nextSibling.previousSibling;
				node.next = nextSibling;
				node.nextSibling = nextSibling;
				if (nextSibling.previousSibling == null) {
					((KeyList) this.keyToKeyList.get(key)).head = node;
				} else {
					nextSibling.previousSibling.nextSibling = node;
				}

				if (nextSibling.previous == null) {
					this.head = node;
				} else {
					nextSibling.previous.next = node;
				}

				nextSibling.previous = node;
				nextSibling.previousSibling = node;
			}
		}

		++this.size;
		return node;
	}

	private void removeNode(Node<K, V> node) {
		if (node.previous != null) {
			node.previous.next = node.next;
		} else {
			this.head = node.next;
		}

		if (node.next != null) {
			node.next.previous = node.previous;
		} else {
			this.tail = node.previous;
		}

		KeyList keyList;
		if (node.previousSibling == null && node.nextSibling == null) {
			keyList = (KeyList) this.keyToKeyList.remove(node.key);
			keyList.count = 0;
			++this.modCount;
		} else {
			keyList = (KeyList) this.keyToKeyList.get(node.key);
			--keyList.count;
			if (node.previousSibling == null) {
				keyList.head = node.nextSibling;
			} else {
				node.previousSibling.nextSibling = node.nextSibling;
			}

			if (node.nextSibling == null) {
				keyList.tail = node.previousSibling;
			} else {
				node.nextSibling.previousSibling = node.previousSibling;
			}
		}

		--this.size;
	}

	private void removeAllNodes(@Nullable Object key) {
		ValueForKeyIterator i = new ValueForKeyIterator(this, key);

		while (i.hasNext()) {
			i.next();
			i.remove();
		}

	}

	private static void checkElement(@Nullable Object node) {
		if (node == null) {
			throw new NoSuchElementException();
		}
	}

	public int size() {
		return this.size;
	}

	public boolean isEmpty() {
		return this.head == null;
	}

	public boolean containsKey(@Nullable Object key) {
		return this.keyToKeyList.containsKey(key);
	}

	public boolean containsValue(@Nullable Object value) {
		NodeIterator i = new NodeIterator(this);

		do {
			if (!i.hasNext()) {
				return false;
			}
		} while (!Objects.equal(((Node) i.next()).value, value));

		return true;
	}

	public boolean containsEntry(@Nullable Object key, @Nullable Object value) {
		ValueForKeyIterator i = new ValueForKeyIterator(this, key);

		do {
			if (!i.hasNext()) {
				return false;
			}
		} while (!Objects.equal(i.next(), value));

		return true;
	}

	public boolean put(@Nullable K key, @Nullable V value) {
		this.addNode(key, value, (Node) null);
		return true;
	}

	public boolean remove(@Nullable Object key, @Nullable Object value) {
		ValueForKeyIterator values = new ValueForKeyIterator(this, key);

		do {
			if (!values.hasNext()) {
				return false;
			}
		} while (!Objects.equal(values.next(), value));

		values.remove();
		return true;
	}

	public boolean putAll(@Nullable K key, Iterable<? extends V> values) {
		boolean changed = false;

		Object value;
		for (Iterator i$ = values.iterator(); i$.hasNext(); changed |= this.put(key, value)) {
			value = i$.next();
		}

		return changed;
	}

	public boolean putAll(Multimap<? extends K, ? extends V> multimap) {
		boolean changed = false;

		Entry entry;
		for (Iterator i$ = multimap.entries().iterator(); i$
				.hasNext(); changed |= this.put(entry.getKey(), entry.getValue())) {
			entry = (Entry) i$.next();
		}

		return changed;
	}

	public List<V> replaceValues(@Nullable K key, Iterable<? extends V> values) {
		List<V> oldValues = this.getCopy(key);
		ListIterator<V> keyValues = new ValueForKeyIterator(this, key);
		Iterator newValues = values.iterator();

		while (keyValues.hasNext() && newValues.hasNext()) {
			keyValues.next();
			keyValues.set(newValues.next());
		}

		while (keyValues.hasNext()) {
			keyValues.next();
			keyValues.remove();
		}

		while (newValues.hasNext()) {
			keyValues.add(newValues.next());
		}

		return oldValues;
	}

	private List<V> getCopy(@Nullable Object key) {
		return Collections.unmodifiableList(Lists.newArrayList(new ValueForKeyIterator(this, key)));
	}

	public List<V> removeAll(@Nullable Object key) {
		List<V> oldValues = this.getCopy(key);
		this.removeAllNodes(key);
		return oldValues;
	}

	public void clear() {
		this.head = null;
		this.tail = null;
		this.keyToKeyList.clear();
		this.size = 0;
		++this.modCount;
	}

	public List<V> get(@Nullable K key) {
      return new 1(this, key);
   }

	public Set<K> keySet() {
      Set<K> result = this.keySet;
      if (result == null) {
         this.keySet = (Set)(result = new 2(this));
      }

      return (Set)result;
   }

	public Multiset<K> keys() {
      Multiset<K> result = this.keys;
      if (result == null) {
         this.keys = (Multiset)(result = new MultisetView(this, (1)null));
      }

      return (Multiset)result;
   }

	public List<V> values() {
      List<V> result = this.valuesList;
      if (result == null) {
         this.valuesList = (List)(result = new 3(this));
      }

      return (List)result;
   }

	private static <K, V> Entry<K, V> createEntry(Node<K, V> node) {
      return new 4(node);
   }

	public List<Entry<K, V>> entries() {
      List<Entry<K, V>> result = this.entries;
      if (result == null) {
         this.entries = (List)(result = new 5(this));
      }

      return (List)result;
   }

	public Map<K, Collection<V>> asMap() {
      Map<K, Collection<V>> result = this.map;
      if (result == null) {
         this.map = (Map)(result = new 6(this));
      }

      return (Map)result;
   }

	public boolean equals(@Nullable Object other) {
		if (other == this) {
			return true;
		} else if (other instanceof Multimap) {
			Multimap<?, ?> that = (Multimap) other;
			return this.asMap().equals(that.asMap());
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.asMap().hashCode();
	}

	public String toString() {
		return this.asMap().toString();
	}

	@GwtIncompatible("java.io.ObjectOutputStream")
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		stream.writeInt(this.size());
		Iterator i$ = this.entries().iterator();

		while (i$.hasNext()) {
			Entry<K, V> entry = (Entry) i$.next();
			stream.writeObject(entry.getKey());
			stream.writeObject(entry.getValue());
		}

	}

	@GwtIncompatible("java.io.ObjectInputStream")
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		this.keyToKeyList = Maps.newLinkedHashMap();
		int size = stream.readInt();

		for (int i = 0; i < size; ++i) {
			K key = stream.readObject();
			V value = stream.readObject();
			this.put(key, value);
		}

	}
}