package com.google.inject.internal;

import com.google.inject.spi.Dependency;
import java.util.Map;

public final class InternalContext {
	private Map<Object, ConstructionContext<?>> constructionContexts = Maps.newHashMap();
	private Dependency dependency;

	public <T> ConstructionContext<T> getConstructionContext(Object key) {
		ConstructionContext<T> constructionContext = (ConstructionContext) this.constructionContexts.get(key);
		if (constructionContext == null) {
			constructionContext = new ConstructionContext();
			this.constructionContexts.put(key, constructionContext);
		}

		return constructionContext;
	}

	public Dependency getDependency() {
		return this.dependency;
	}

	public void setDependency(Dependency dependency) {
		this.dependency = dependency;
	}
}