package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.util.concurrent.AbstractScheduledService.1;
import com.google.common.util.concurrent.AbstractScheduledService.1ThreadFactoryImpl;
import com.google.common.util.concurrent.AbstractScheduledService.Scheduler;
import com.google.common.util.concurrent.AbstractScheduledService.ServiceDelegate;
import com.google.common.util.concurrent.Service.Listener;
import com.google.common.util.concurrent.Service.State;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Logger;

@Beta
@GwtIncompatible
public abstract class AbstractScheduledService implements Service {
	private static final Logger logger = Logger.getLogger(AbstractScheduledService.class.getName());
	private final AbstractService delegate = new ServiceDelegate(this, (1)null);

	protected abstract void runOneIteration() throws Exception;

	protected void startUp() throws Exception {
	}

	protected void shutDown() throws Exception {
	}

	protected abstract Scheduler scheduler();

	protected ScheduledExecutorService executor() {
      ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(new 1ThreadFactoryImpl(this));
      this.addListener(new 1(this, executor), MoreExecutors.directExecutor());
      return executor;
   }

	protected String serviceName() {
		return this.getClass().getSimpleName();
	}

	public String toString() {
		return this.serviceName() + " [" + this.state() + "]";
	}

	public final boolean isRunning() {
		return this.delegate.isRunning();
	}

	public final State state() {
		return this.delegate.state();
	}

	public final void addListener(Listener listener, Executor executor) {
		this.delegate.addListener(listener, executor);
	}

	public final Throwable failureCause() {
		return this.delegate.failureCause();
	}

	@CanIgnoreReturnValue
	public final Service startAsync() {
		this.delegate.startAsync();
		return this;
	}

	@CanIgnoreReturnValue
	public final Service stopAsync() {
		this.delegate.stopAsync();
		return this;
	}

	public final void awaitRunning() {
		this.delegate.awaitRunning();
	}

	public final void awaitRunning(long timeout, TimeUnit unit) throws TimeoutException {
		this.delegate.awaitRunning(timeout, unit);
	}

	public final void awaitTerminated() {
		this.delegate.awaitTerminated();
	}

	public final void awaitTerminated(long timeout, TimeUnit unit) throws TimeoutException {
		this.delegate.awaitTerminated(timeout, unit);
	}
}