package com.ibm.ejs.container;

public interface InternalAsyncResult {
	boolean wasCancelCalled();
}