package com.ibm.ejs.csi;

import com.ibm.ejs.models.base.bindings.commonbnd.Property;
import com.ibm.ejs.models.base.bindings.commonbnd.ResourceRefBinding;
import com.ibm.ejs.models.base.bindings.ejbbnd.CMPConnectionFactoryBinding;
import com.ibm.ejs.models.base.bindings.ejbbnd.EJBJarBinding;
import com.ibm.ejs.models.base.bindings.ejbbnd.EnterpriseBeanBinding;
import com.ibm.ejs.models.base.bindings.managedbeansbnd.ManagedBeanBinding;
import com.ibm.ejs.models.base.bindings.webappbnd.WebAppBinding;
import com.ibm.ejs.models.base.extensions.commonext.ResourceRefExtension;
import com.ibm.ejs.models.base.extensions.ejbext.EnterpriseBeanExtension;
import com.ibm.ejs.models.base.extensions.webappext.WebAppExtension;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.javaee.dd.ejb.EnterpriseBean;
import com.ibm.ws.javaee.dd.ejb.Entity;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import org.eclipse.emf.common.util.EList;
import org.eclipse.jst.j2ee.common.ResourceRef;
import org.eclipse.jst.j2ee.webapplication.WebApp;

public class ResRefListImpl extends BasicResRefListImpl {
	public static final String PM_CMP_CF_COMP_NAME = "PM/WebSphereCMPConnectionFactory";
	public static final String PM_CMP_CF_LOOKUP_NAME = "java:comp/PM/WebSphereCMPConnectionFactory";
	private static final TraceComponent tc = Tr.register(ResRefListImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private boolean initialized;

	public ResRefListImpl() {
		this.initialized = true;
	}

	public ResRefListImpl(String beanName, EnterpriseBean eb, EnterpriseBeanBinding ebb, EnterpriseBeanExtension ebx) {
		this.initialized = true;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init> for EJB");
		}

		if (eb != null && ebb != null && eb.getKindValue() == 1 && ((Entity) eb).getPersistenceTypeValue() == 1) {
			CMPConnectionFactoryBinding cmpConnFacBnd = ebb.getCmpConnectionFactory();
			String loginConfigurationName = null;
			EList properties = null;
			if (cmpConnFacBnd != null) {
				loginConfigurationName = cmpConnFacBnd.getLoginConfigurationName();
				properties = cmpConnFacBnd.getProperties();
			} else {
				EJBJarBinding ejbJarBinding = ebb.getModuleBinding();
				cmpConnFacBnd = ejbJarBinding.getDefaultCMPConnectionFactory();
				if (cmpConnFacBnd != null) {
					loginConfigurationName = cmpConnFacBnd.getLoginConfigurationName();
					properties = cmpConnFacBnd.getProperties();
				}
			}

			this.initializeFactoryBindings(cmpConnFacBnd, 0, loginConfigurationName, properties);
		}

		if (null != ebx) {
			List<ResourceRefExtension> extensions = ebx.getResourceRefExtensions();
			Iterator i$ = extensions.iterator();

			while (i$.hasNext()) {
				ResourceRefExtension extension = (ResourceRefExtension) i$.next();
				this.addExtension(extension);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init> for EJB");
		}

	}

	public ResRefListImpl(String beanName, ManagedBeanBinding mbb) {
		this.initialized = true;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init> for ManagedBean : " + beanName);
		}

		this._resRefVector = new Vector();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init> : " + this.toString());
		}

	}

	public ResRefListImpl(WebApp webApp, WebAppExtension webAppExt) {
		this(webApp, webAppExt, (WebAppBinding) null);
	}

	public ResRefListImpl(WebApp webApp, WebAppExtension webAppExt, WebAppBinding web_bindings) {
		this.initialized = true;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init> for WEB");
		}

		this._resRefVector = new Vector();
		if (null != webAppExt) {
			List<ResourceRefExtension> extensions = webAppExt.getResourceRefExtensions();
			Iterator i$ = extensions.iterator();

			while (i$.hasNext()) {
				ResourceRefExtension extension = (ResourceRefExtension) i$.next();
				this.addExtension(extension);
			}
		}

		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "The following list of resource ref's created:");
			Tr.debug(tc, this.toString());
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init> for WEB");
		}

	}

	private void initializeFactoryBindings(CMPConnectionFactoryBinding cmpConnFacBnd, int sharingScope,
			String loginConfigurationName, EList properties) {
		String jndiName_CF = null;
		if (null != cmpConnFacBnd) {
			jndiName_CF = cmpConnFacBnd.getJndiName();
			if (jndiName_CF == null) {
				jndiName_CF = "java:comp/PM/WebSphereCMPConnectionFactory";
			}

			this._resRefVector.add(new ResRefImpl("WebSphere CMP Resource Ref Connection Factory",
					"java:comp/PM/WebSphereCMPConnectionFactory", jndiName_CF, "javax.resource.cci.ConnectionFactory",
					cmpConnFacBnd.getResAuth().getValue() == 1 ? 0 : 1, sharingScope, 0, loginConfigurationName,
					properties));
		}

	}

	public void addExtension(ResourceRefExtension resourceReferenceExtension) {
		String name = resourceReferenceExtension.getResourceRef().getName();
		ResRefImpl resRef = this.findOrAddByName(name);
		if (resRef != null) {
			int branchCoupling;
			if (resourceReferenceExtension.isSetIsolationLevel()) {
				branchCoupling = resourceReferenceExtension.getIsolationLevel().getValue();
				resRef.setIsolationLevel(branchCoupling);
			}

			if (resourceReferenceExtension.isSetCommitPriority()) {
				branchCoupling = resourceReferenceExtension.getCommitPriority();
				resRef.setCommitPriority(branchCoupling);
			}

			if (resourceReferenceExtension.isSetBranchCoupling()) {
				branchCoupling = resourceReferenceExtension.getBranchCoupling().getValue();
				resRef.setBranchCoupling(branchCoupling);
			}
		}

	}

	public void addBinding(ResourceRefBinding binding) {
		ResourceRef resourceRef = binding.getBindingResourceRef();
		String name = resourceRef.getName();
		ResRefImpl resRef = this.findOrAddByName(name);
		if (resRef != null) {
			resRef.setJNDIName(binding.getJndiName());
			resRef.setLoginConfigurationName(binding.getLoginConfigurationName());
			List<Property> loginProperties = binding.getProperties();
			Iterator i$ = loginProperties.iterator();

			while (i$.hasNext()) {
				Property loginProperty = (Property) i$.next();
				resRef.addLoginProperty(loginProperty.getName(), loginProperty.getValue());
			}
		}

	}

	public void completeInitialization() {
		this.initialized = true;
	}

	public void setToUnintialized() {
		this.initialized = false;
	}

	public boolean isInitialized() {
		return this.initialized;
	}
}