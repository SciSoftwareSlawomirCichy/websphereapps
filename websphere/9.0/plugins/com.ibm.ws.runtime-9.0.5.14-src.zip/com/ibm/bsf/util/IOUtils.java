package com.ibm.bsf.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;

public class IOUtils {
	static boolean debug = false;

	public static String getStringFromReader(Reader var0) throws IOException {
		BufferedReader var1 = new BufferedReader(var0);
		StringWriter var2 = new StringWriter();
		PrintWriter var3 = new PrintWriter(var2);

		String var4;
		while ((var4 = var1.readLine()) != null) {
			var3.println(var4);
		}

		var3.flush();
		return var2.toString();
	}
}