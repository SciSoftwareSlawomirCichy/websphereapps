package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class java_awt_event_KeyAdapter extends EventAdapterImpl implements KeyListener {
	public void keyPressed(KeyEvent var1) {
		this.eventProcessor.processEvent("keyPressed", new Object[]{var1});
	}

	public void keyReleased(KeyEvent var1) {
		this.eventProcessor.processEvent("keyReleased", new Object[]{var1});
	}

	public void keyTyped(KeyEvent var1) {
		this.eventProcessor.processEvent("keyTyped", new Object[]{var1});
	}
}