package com.ibm.ws.wim.dao.schema;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JDBCSqlImport {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final char SQL_ENDING_DELIM = ';';
	private static final String SQL_COMMENT = "--";
	private JDBCConnection jdbcConnection;
	private Connection connection;
	private boolean debug;
	private boolean reportsqlerror;
	private String dbSchema;
	private String tbsprefix;
	private String tableBP;
	private String auxTableBP;
	private String indexTableBP;

	public JDBCSqlImport(String var1, String var2, String var3, String var4, String var5, String var6, String var7,
			String var8, String var9) throws WIMSystemException {
		this.jdbcConnection = new JDBCConnection();
		this.connection = null;
		this.debug = false;
		this.reportsqlerror = true;
		this.dbSchema = null;
		this.tbsprefix = null;
		this.tableBP = "BP0";
		this.auxTableBP = "BP0";
		this.indexTableBP = "BP0";
		this.jdbcConnection.setJdbcDriver(var2);
		this.jdbcConnection.setJdbcURL(var1);
		this.jdbcConnection.setJdbcUser(var3);
		this.jdbcConnection.setJdbcUserPassword(var4);
		this.connection = this.jdbcConnection.getConnection();
		this.dbSchema = var5;
		this.tbsprefix = var6;
		this.tableBP = var7;
		this.auxTableBP = var8;
		this.indexTableBP = var9;
	}

	public JDBCSqlImport(String var1, String var2, String var3, String var4, String var5, String var6, String var7,
			String var8) throws WIMSystemException {
		this(var1, var2, var3, var4, var5, (String) null, var6, var7, var8);
	}

	public JDBCSqlImport(String var1, String var2, String var3, String var4, String var5, String var6)
			throws WIMSystemException {
		this(var1, var2, (String) null, (String) null, var3, var4, var5, var6);
	}

	public JDBCSqlImport(String var1, String var2, String var3, String var4, String var5, String var6, String var7)
			throws WIMSystemException {
		this(var1, var2, var3, var4, (String) null, var5, var6, var7);
	}

	public JDBCSqlImport(String var1, String var2, String var3, String var4) throws WIMSystemException {
		this(var1, var2, var3, var4, (String) null, "BP0", "BP0", "BP0");
	}

	public JDBCSqlImport(String var1, String var2, String var3) throws WIMSystemException {
		this(var1, var2, (String) null, (String) null, var3, "BP0", "BP0", "BP0");
	}

	public JDBCSqlImport(String var1, String var2, String var3, String var4, String var5) throws WIMSystemException {
		this(var1, var2, (String) null, var3, var4, var5);
	}

	public JDBCSqlImport(String var1, String var2) throws WIMSystemException {
		this(var1, var2, (String) null);
	}

	public void importFile(String var1) throws WIMSystemException {
		if (trcLogger.isLoggable(Level.INFO)) {
			trcLogger.logp(Level.INFO, CLASSNAME, "importFile(String file)", "opening file:  " + var1);
		}

		try {
			String var3 = "";
			String var4 = "";
			String var5 = "";
			String var6 = "";
			String var7 = "";
			if (this.dbSchema != null && !this.dbSchema.trim().equals("")) {
				var3 = this.dbSchema.trim().toUpperCase() + ".";
			}

			if (this.tbsprefix != null && !this.tbsprefix.trim().equals("")) {
				var4 = this.tbsprefix.trim().toUpperCase();
			}

			if (this.tableBP != null && !this.tableBP.trim().equals("")) {
				var5 = this.tableBP.trim().toUpperCase();
			}

			if (this.auxTableBP != null && !this.auxTableBP.trim().equals("")) {
				var6 = this.auxTableBP.trim().toUpperCase();
			}

			if (this.indexTableBP != null && !this.indexTableBP.trim().equals("")) {
				var7 = this.indexTableBP.trim().toUpperCase();
			}

			FileInputStream var8 = new FileInputStream(var1);
			InputStreamReader var9 = new InputStreamReader(var8, "UTF-8");
			boolean var10 = true;
			StringBuffer var11 = new StringBuffer();

			while (true) {
				int var17;
				while ((var17 = var9.read()) != -1) {
					if ((char) var17 == ';') {
						if (var11.length() > 0) {
							String var12 = var11.toString().trim();
							if (var12.startsWith("--")) {
								int var13 = var12.lastIndexOf("--");
								if (var13 > 0) {
									var12 = var12.substring(var13 + 2);
								}
							}

							var12 = var12.replaceAll("@dbschema.@", var3);
							var12 = var12.replaceAll("@DbUser@.", var3);
							var12 = var12.replaceAll("@DEFAULT_TABLE@", var5);
							var12 = var12.replaceAll("@LOB_TABLE@", var6);
							var12 = var12.replaceAll("@INDEX_TABLE@", var7);
							var12 = var12.replaceAll("@TSPREFIX@", var4);
							if (trcLogger.isLoggable(Level.INFO)) {
								trcLogger.logp(Level.INFO, CLASSNAME, "importFile(String file)", var12);
							}

							try {
								PreparedStatement var18 = this.connection.prepareStatement(var12);
								var18.execute();
								var18.close();
							} catch (SQLException var14) {
								if (!var1.endsWith("dbclean.sql")) {
									throw new WIMSystemException("SQL_EXCEPTION",
											WIMMessageHelper.generateMsgParms(var14.getMessage()), CLASSNAME,
											"importFile(String file)", var14);
								}
							}
						}

						var11.delete(0, var11.length());
					} else {
						var11.append((char) var17);
					}
				}

				if (trcLogger.isLoggable(Level.INFO)) {
					trcLogger.logp(Level.INFO, CLASSNAME, "importFile(String file)",
							"left over file contents: " + var11.toString());
				}

				var9.close();
				if (trcLogger.isLoggable(Level.INFO)) {
					trcLogger.logp(Level.INFO, CLASSNAME, "importFile(String file)", "import completed!");
				}

				return;
			}
		} catch (FileNotFoundException var15) {
			throw new WIMSystemException("ERROR_READING_FILE",
					WIMMessageHelper.generateMsgParms(var1, var15.getMessage()), CLASSNAME, "importFile(String file)",
					var15);
		} catch (IOException var16) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var16.getMessage()), CLASSNAME,
					"importFile(String file)", var16);
		}
	}

	public static void main(String[] var0) throws WIMSystemException {
		int var1 = var0.length;
		String var2 = var0[0];
		String var3 = var0[1];
		String var4 = var0[2];
		String var5 = null;
		String var6 = null;
		String var7 = null;
		String var8 = null;
		String var9 = null;
		String var10 = null;
		String var11 = null;
		JDBCSqlImport var12 = null;
		if (var1 == 8) {
			var7 = var0[3];
			var8 = var0[4];
			var9 = var0[5];
			var10 = var0[6];
			var11 = var0[7];
			var12 = new JDBCSqlImport(var3, var4);
		} else {
			var5 = var0[3];
			var6 = var0[4];
			var7 = var0[5];
			var8 = var0[6];
			var9 = var0[7];
			var10 = var0[8];
			var11 = var0[9];
			var12 = new JDBCSqlImport(var3, var4, var5, var6);
		}

		if ("true".equalsIgnoreCase(var7)) {
			var12.setDebug(true);
		} else {
			var12.setDebug(false);
		}

		if ("true".equalsIgnoreCase(var8)) {
			var12.setReportsqlerror(true);
		} else {
			var12.setReportsqlerror(false);
		}

		var12.importFile(var2);
		var12.closeConnection();
	}

	public void setDebug(boolean var1) {
		this.debug = var1;
	}

	public void setReportsqlerror(boolean var1) {
		this.reportsqlerror = var1;
	}

	public void closeConnection() {
		try {
			if (this.connection != null && !this.connection.isClosed()) {
				this.connection.close();
			}
		} catch (Exception var3) {
			if (trcLogger.isLoggable(Level.INFO)) {
				trcLogger.logp(Level.INFO, CLASSNAME, "closeConnection",
						"encounter problem closing connection: " + var3.getMessage());
			}
		}

	}

	public boolean isValidSchema(String var1) throws WIMSystemException {
		if (trcLogger.isLoggable(Level.INFO)) {
			trcLogger.entering(CLASSNAME, "isValidSchema(String dbtype)",
					"dbtype= " + var1 + ", dbSchema= " + this.dbSchema);
		}

		boolean var3 = false;
		if (!"db2zos".equals(var1) && !"db2iseries".equals(var1)) {
			ResultSet var4 = null;

			try {
				String var5 = this.getSelectSchemaSql(var1);
				PreparedStatement var6 = this.connection.prepareStatement(var5);
				var6.setString(1, this.dbSchema.trim().toUpperCase());
				var4 = var6.executeQuery();
				if (var4.next()) {
					var3 = true;
				}
			} catch (SQLException var7) {
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var7.getMessage()),
						CLASSNAME, "isValidSchema(String dbtype)", var7);
			}
		} else {
			var3 = true;
		}

		if (trcLogger.isLoggable(Level.INFO)) {
			trcLogger.exiting(CLASSNAME, "isValidSchema(String dbtype)", var3);
		}

		return var3;
	}

	private String getSelectSchemaSql(String var1) {
		String var2 = null;
		if ("db2".equals(var1)) {
			var2 = "SELECT SCHEMANAME FROM SYSCAT.SCHEMATA WHERE SCHEMANAME = ? ";
		} else if ("oracle".equals(var1)) {
			var2 = "SELECT USERNAME FROM ALL_USERS WHERE  USERNAME = ? ";
		} else if ("sqlserver".equals(var1)) {
			var2 = "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ? ";
		} else if ("derby".equals(var1)) {
			var2 = "SELECT SCHEMANAME FROM SYS.SYSSCHEMAS WHERE SCHEMANAME = ? ";
		} else if ("informix".equals(var1)) {
			var2 = "SELECT UNIQUE OWNER FROM SYSTABLES WHERE tabid>99 AND OWNER = ?";
		}

		return var2;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = JDBCSqlImport.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}