package com.ibm.ejs.container;

public class ContainerFinderException extends ContainerException {
	private static final long serialVersionUID = -1949465464357313116L;

	public ContainerFinderException(String s) {
		super(s);
	}

	public ContainerFinderException() {
	}
}