package com.ibm.json.java.internal;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.json.java.OrderedJSONObject;
import java.io.IOException;
import java.io.Reader;

public class Parser {
	private Tokenizer tokenizer;
	private Token lastToken;

	public Parser(Reader var1) throws IOException {
		this.tokenizer = new Tokenizer(var1);
	}

	public JSONObject parse() throws IOException {
		return this.parse(false);
	}

	public JSONObject parse(boolean var1) throws IOException {
		this.lastToken = this.tokenizer.next();
		return this.parseObject(var1);
	}

	public JSONObject parseObject() throws IOException {
		return this.parseObject(false);
	}

	public JSONObject parseObject(boolean var1) throws IOException {
		Object var2 = null;
		if (!var1) {
			var2 = new JSONObject();
		} else {
			var2 = new OrderedJSONObject();
		}

		if (this.lastToken != Token.TokenBraceL) {
			throw new IOException("Expecting '{' " + this.tokenizer.onLineCol() + " instead, obtained token: '"
					+ this.lastToken + "'");
		} else {
			this.lastToken = this.tokenizer.next();

			while (this.lastToken != Token.TokenEOF) {
				if (this.lastToken == Token.TokenBraceR) {
					this.lastToken = this.tokenizer.next();
					return (JSONObject) var2;
				}

				if (!this.lastToken.isString()) {
					throw new IOException("Expecting string key " + this.tokenizer.onLineCol());
				}

				String var3 = this.lastToken.getString();
				this.lastToken = this.tokenizer.next();
				if (this.lastToken != Token.TokenColon) {
					throw new IOException("Expecting colon " + this.tokenizer.onLineCol());
				}

				this.lastToken = this.tokenizer.next();
				Object var4 = this.parseValue(var1);
				((JSONObject) var2).put(var3, var4);
				if (this.lastToken == Token.TokenComma) {
					this.lastToken = this.tokenizer.next();
				} else if (this.lastToken != Token.TokenBraceR) {
					throw new IOException("expecting either ',' or '}' " + this.tokenizer.onLineCol());
				}
			}

			throw new IOException("Unterminated object " + this.tokenizer.onLineCol());
		}
	}

	public JSONArray parseArray() throws IOException {
		return this.parseArray(false);
	}

	public JSONArray parseArray(boolean var1) throws IOException {
		JSONArray var2 = new JSONArray();
		if (this.lastToken != Token.TokenBrackL) {
			throw new IOException("Expecting '[' " + this.tokenizer.onLineCol());
		} else {
			this.lastToken = this.tokenizer.next();

			while (this.lastToken != Token.TokenEOF) {
				if (this.lastToken == Token.TokenBrackR) {
					this.lastToken = this.tokenizer.next();
					return var2;
				}

				Object var3 = this.parseValue(var1);
				var2.add(var3);
				if (this.lastToken == Token.TokenComma) {
					this.lastToken = this.tokenizer.next();
				} else if (this.lastToken != Token.TokenBrackR) {
					throw new IOException("expecting either ',' or ']' " + this.tokenizer.onLineCol());
				}
			}

			throw new IOException("Unterminated array " + this.tokenizer.onLineCol());
		}
	}

	public Object parseValue() throws IOException {
		return this.parseValue(false);
	}

	public Object parseValue(boolean var1) throws IOException {
		if (this.lastToken == Token.TokenEOF) {
			throw new IOException("Expecting property value " + this.tokenizer.onLineCol());
		} else if (this.lastToken.isNumber()) {
			Number var3 = this.lastToken.getNumber();
			this.lastToken = this.tokenizer.next();
			return var3;
		} else if (this.lastToken.isString()) {
			String var2 = this.lastToken.getString();
			this.lastToken = this.tokenizer.next();
			return var2;
		} else if (this.lastToken == Token.TokenFalse) {
			this.lastToken = this.tokenizer.next();
			return Boolean.FALSE;
		} else if (this.lastToken == Token.TokenTrue) {
			this.lastToken = this.tokenizer.next();
			return Boolean.TRUE;
		} else if (this.lastToken == Token.TokenNull) {
			this.lastToken = this.tokenizer.next();
			return null;
		} else if (this.lastToken == Token.TokenBrackL) {
			return this.parseArray(var1);
		} else if (this.lastToken == Token.TokenBraceL) {
			return this.parseObject(var1);
		} else {
			throw new IOException("Invalid token " + this.tokenizer.onLineCol());
		}
	}
}