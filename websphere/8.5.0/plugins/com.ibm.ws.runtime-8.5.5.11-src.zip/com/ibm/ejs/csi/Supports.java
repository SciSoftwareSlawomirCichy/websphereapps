package com.ibm.ejs.csi;

import com.ibm.ejs.container.ContainerProperties;
import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import javax.transaction.Transaction;

final class Supports extends TranStrategy {
	private static final TraceComponent tc = Tr.register(Supports.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	Supports(TransactionControlImpl txCtrl) {
		super(txCtrl);
	}

	TxCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		TxCookieImpl cookie = null;
		if (!this.globalTxExists(true)) {
			cookie = this.beginLocalTx(key, methodInfo, (Transaction) null);
		} else {
			cookie = new TxCookieImpl(false, false, this, (Transaction) null);
			if (ContainerProperties.PI10351) {
				cookie.suspendedLocalTx = this.ltcCurrent.getLocalTranCoord();
				this.suspendLocalTx(cookie.suspendedLocalTx);
			}
		}

		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		return cookie;
	}
}