package com.ibm.ejs.container.interceptors;

import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSDeployedSupport;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.csi.EJBModuleMetaDataImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Map;
import javax.ejb.EJBException;
import javax.ejb.Timer;
import javax.interceptor.InvocationContext;

public class InvocationContextImpl implements InvocationContext {
	private static final String CLASS_NAME = InvocationContextImpl.class.getName();
	private static final TraceComponent tc;
	private Method ivMethod;
	private Object ivBean;
	private Object[] ivParameters = new Object[0];
	private Timer ivTimer;
	private InterceptorProxy[] ivInterceptorProxies;
	private int ivNextIndex;
	private int ivNumberOfInterceptors;
	private Object[] ivInterceptors;
	private boolean ivParametersModified = false;
	private EJSDeployedSupport ivEJSDeployedSupport;
	private EJSContainer ivContainer = EJSContainer.getDefaultContainer();

	public void initialize(Object bean, Object[] interceptors) {
		this.initialize(bean, interceptors, (Timer) null);
	}

	public void initialize(Object bean, Object[] interceptors, Timer timer) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "initialize for bean = " + bean + ", interceptors = " + Arrays.toString(interceptors));
		}

		this.ivInterceptors = interceptors;
		this.ivBean = bean;
		this.ivTimer = timer;
	}

	public Object doAroundInvoke(InterceptorProxy[] proxies, Method businessMethod, Object[] parameters,
			EJSDeployedSupport s) throws Exception {
		this.ivMethod = businessMethod;
		this.ivParameters = parameters;
		this.ivInterceptorProxies = proxies;
		this.ivNextIndex = 0;
		this.ivNumberOfInterceptors = this.ivInterceptorProxies.length;
		this.ivParametersModified = false;
		this.ivEJSDeployedSupport = s;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "doAroundInvoke for business method: " + businessMethod.getName());
		}

		Object var5;
		try {
			var5 = this.proceed();
		} finally {
			this.ivMethod = null;
			this.ivParameters = null;
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "doAroundInvoke for business method: " + businessMethod.getName());
			}

		}

		return var5;
	}

	public void doLifeCycle(InterceptorProxy[] proxies, EJBModuleMetaDataImpl mmd) {
		this.ivMethod = null;
		this.ivParameters = null;
		this.ivInterceptorProxies = proxies;
		this.ivNumberOfInterceptors = this.ivInterceptorProxies.length;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "doLifeCycle, number of interceptors = " + this.ivNumberOfInterceptors);
		}

		if (this.ivNumberOfInterceptors > 0) {
			this.ivNextIndex = 0;

			try {
				this.proceed();
			} catch (Throwable var7) {
				this.lifeCycleExceptionHandler(var7, mmd);
			} finally {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "doLifeCycle");
				}

			}
		}

	}

	private void lifeCycleExceptionHandler(Throwable t, EJBModuleMetaDataImpl mmd) {
		if (t instanceof RuntimeException) {
			RuntimeException rtex = (RuntimeException) t;
			if (mmd.getApplicationExceptionRollback(rtex) != null) {
				InterceptorProxy w = this.ivInterceptorProxies[this.ivNextIndex - 1];
				String lifeCycle = w.getMethodGenericString();
				EJBException ex = ExceptionUtil
						.EJBException(lifeCycle + " is not allowed to throw an application exception", rtex);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "lifeCycleExceptionHandler throwing EJBException", ex);
				}

				throw ex;
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"lifeCycleExceptionHandler is rethrowing RuntimeException from lifecycle callback method: "
									+ t,
							t);
				}

				throw rtex;
			}
		} else if (t instanceof Error) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "lifeCycleExceptionHandler is rethrowing Error from lifecycle callback method: " + t, t);
			}

			throw (Error) t;
		} else {
			InterceptorProxy w = this.ivInterceptorProxies[this.ivNextIndex - 1];
			String lifeCycle = w.getMethodGenericString();
			EJBException ex = ExceptionUtil.EJBException(lifeCycle + " is not allowed to throw a checked exception", t);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "lifeCycleExceptionHandler throwing EJBException", ex);
			}

			throw ex;
		}
	}

	public Object getTarget() {
		return this.ivBean;
	}

	public Method getMethod() {
		return this.ivMethod;
	}

	public Object[] getParameters() {
		if (this.ivMethod == null) {
			throw new IllegalStateException(
					"InvocationContext.getParameter can not be called by lifecycle callback methods");
		} else {
			return this.ivParameters;
		}
	}

	public Object getTimer() {
		return this.ivTimer;
	}

	public void setParameters(Object[] args) {
		if (this.ivMethod == null) {
			throw new IllegalStateException(
					"InvocationContext.setParameter can not be called by lifecycle callback methods");
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "setParameters for business method: " + this.ivMethod.getName());
			}

			Class<?>[] parmTypes = this.ivMethod.getParameterTypes();
			int n = parmTypes.length;
			if (args == null) {
				if (n > 0) {
					throw new IllegalArgumentException("null not valid as argument for setParameters method.");
				}
			} else {
				if (args.length != n) {
					throw new IllegalArgumentException("wrong number of parameters for method being invoked.");
				}

				for (int i = 0; i < n; ++i) {
					Class<?> parmType = parmTypes[i];
					if (!parmType.isPrimitive()) {
						if (args[i] != null && !parmType.isInstance(args[i])) {
							throw new IllegalArgumentException("wrong data type for parameter " + (i + 1));
						}
					} else {
						if (parmType == Integer.TYPE && !(args[i] instanceof Integer)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Integer");
						}

						if (parmType == Long.TYPE && !(args[i] instanceof Long)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Long");
						}

						if (parmType == Short.TYPE && !(args[i] instanceof Short)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Short");
						}

						if (parmType == Boolean.TYPE && !(args[i] instanceof Boolean)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Boolean");
						}

						if (parmType == Byte.TYPE && !(args[i] instanceof Byte)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Byte");
						}

						if (parmType == Character.TYPE && !(args[i] instanceof Character)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Character");
						}

						if (parmType == Float.TYPE && !(args[i] instanceof Float)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Float");
						}

						if (parmType == Double.TYPE && !(args[i] instanceof Double)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Double");
						}
					}
				}

				this.ivParameters = args;
				this.ivParametersModified = true;
			}

		}
	}

	public Map<String, Object> getContextData() {
		return EJSContainer.getThreadData().getContextData();
	}

	public Object proceed() throws Exception {
		Object returnValue = null;

		try {
			if (this.ivNextIndex < this.ivNumberOfInterceptors) {
				InterceptorProxy w = this.ivInterceptorProxies[this.ivNextIndex];
				if (w.ivRequiresInvocationContext) {
					++this.ivNextIndex;
					returnValue = w.invokeInterceptor(this.ivBean, this, this.ivInterceptors);
				} else {
					while (w != null) {
						++this.ivNextIndex;
						returnValue = w.invokeInterceptor(this.ivBean, this, this.ivInterceptors);
						w = this.ivNextIndex < this.ivNumberOfInterceptors
								? this.ivInterceptorProxies[this.ivNextIndex]
								: null;
					}
				}
			} else if (this.ivMethod != null) {
				returnValue = this.ivContainer.invokeProceed(this.ivEJSDeployedSupport, this.ivMethod, this.ivBean,
						this.ivParameters, this.ivParametersModified);
			}

			return returnValue;
		} catch (InvocationTargetException var4) {
			Throwable t = var4.getTargetException();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "proceed unwrappering InvocationTargetException: " + t, t);
			}

			if (t instanceof RuntimeException) {
				throw (RuntimeException) t;
			} else if (t instanceof Error) {
				throw (Error) t;
			} else {
				throw (Exception) t;
			}
		}
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJB3Interceptors", "com.ibm.ejs.container.container");
	}
}