package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EDataTypeEList;

public class SupportedEntityTypesTypeImpl extends EDataObjectImpl implements SupportedEntityTypesType {
	protected EList rdnProperties = null;
	protected static final String DEFAULT_PARENT_EDEFAULT = null;
	protected String defaultParent;
	protected static final String NAME_EDEFAULT = null;
	protected String name;

	protected SupportedEntityTypesTypeImpl() {
		this.defaultParent = DEFAULT_PARENT_EDEFAULT;
		this.name = NAME_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getSupportedEntityTypesType();
	}

	public String[] getRdnPropertiesAsArray() {
		List var1 = this.getRdnProperties();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getRdnProperties() {
		if (this.rdnProperties == null) {
			this.rdnProperties = new EDataTypeEList(String.class, this, 0);
		}

		return this.rdnProperties;
	}

	public String getDefaultParent() {
		return this.defaultParent;
	}

	public void setDefaultParent(String var1) {
		String var2 = this.defaultParent;
		this.defaultParent = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.defaultParent));
		}

	}

	public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		String var2 = this.name;
		this.name = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.name));
		}

	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getRdnProperties();
			case 1 :
				return this.getDefaultParent();
			case 2 :
				return this.getName();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getRdnProperties().clear();
				this.getRdnProperties().addAll((Collection) var2);
				return;
			case 1 :
				this.setDefaultParent((String) var2);
				return;
			case 2 :
				this.setName((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getRdnProperties().clear();
				return;
			case 1 :
				this.setDefaultParent(DEFAULT_PARENT_EDEFAULT);
				return;
			case 2 :
				this.setName(NAME_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.rdnProperties != null && !this.rdnProperties.isEmpty();
			case 1 :
				return DEFAULT_PARENT_EDEFAULT == null
						? this.defaultParent != null
						: !DEFAULT_PARENT_EDEFAULT.equals(this.defaultParent);
			case 2 :
				return NAME_EDEFAULT == null ? this.name != null : !NAME_EDEFAULT.equals(this.name);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (rdnProperties: ");
			var1.append(this.rdnProperties);
			var1.append(", defaultParent: ");
			var1.append(this.defaultParent);
			var1.append(", name: ");
			var1.append(this.name);
			var1.append(')');
			return var1.toString();
		}
	}
}