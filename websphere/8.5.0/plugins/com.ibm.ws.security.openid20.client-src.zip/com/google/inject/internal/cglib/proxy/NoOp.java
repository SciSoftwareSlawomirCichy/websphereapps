package com.google.inject.internal.cglib.proxy;

import com.google.inject.internal.cglib.proxy.NoOp.1;

public interface NoOp extends Callback {
	NoOp INSTANCE = new 1();
}