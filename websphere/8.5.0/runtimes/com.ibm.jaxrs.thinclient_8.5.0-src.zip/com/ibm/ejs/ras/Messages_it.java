package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_it extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: Rilevata incongruenza nei livelli di build dei componenti client installati del server delle applicazioni. Il livello di build installato del componente client {0} che è {1} è diverso da quello del componente client {2} che è {3}."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: Il rilevamento di una incongruenza nei livelli di build dei componenti client del server delle applicazioni installati previene ulteriori eccezioni."},
			{"EXCP_CWSJE0003E", "CWSJE0003E: Impossibile accedere alla risorsa {1} per l''eccezione: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}