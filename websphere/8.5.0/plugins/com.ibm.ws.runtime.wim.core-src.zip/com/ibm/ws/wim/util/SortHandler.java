package com.ibm.ws.wim.util;

import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import commonj.sdo.DataObject;
import java.text.Collator;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SortHandler {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2011";
	public static final String CLASSNAME = SortHandler.class.getName();
	private static final Logger trcLogger;
	private DataObject sortControl = null;

	public SortHandler() {
	}

	public SortHandler(DataObject var1) {
		this.sortControl = var1;
	}

	public int compareEntitysWithRespectToProperties(DataObject var1, DataObject var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "compareEntitysWithRespectToProperties( DataObject, DataObject)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2}));
		}

		List var4 = this.sortControl.getList("sortKeys");
		int var5 = 0;

		for (int var6 = 0; var6 < var4.size() && var5 == 0; ++var6) {
			DataObject var7 = (DataObject) var4.get(var6);
			String var8 = var7.getString("propertyName");
			boolean var9 = var7.getBoolean("ascendingOrder");
			Object var10 = this.getPropertyValue(var1, var8, var9);
			Object var11 = this.getPropertyValue(var2, var8, var9);
			var5 = this.compareProperties(var10, var11);
			if (!var9) {
				var5 = 0 - var5;
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "compareEntitysWithRespectToProperties( DataObject, DataObject)",
					"return code = " + var5);
		}

		return var5;
	}

	public void setSortControl(DataObject var1) {
		this.sortControl = var1;
	}

	public DataObject getSortControl() {
		return this.sortControl;
	}

	public List sortEntities(List var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "List sortEntities(List)",
					WIMTraceHelper.printObjectArray(new Object[]{var1}));
		}

		if (var1 != null && var1.size() > 0) {
			Object[] var3 = var1.toArray();
			WIMSortCompare var4 = new WIMSortCompare(this.sortControl);
			Arrays.sort(var3, var4);
			var1.clear();

			for (int var5 = 0; var5 < var3.length; ++var5) {
				var1.add(var3[var5]);
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "List sortEntities(List)",
					WIMTraceHelper.printObjectArray(new Object[]{var1}));
		}

		return var1;
	}

	private Object getPropertyValue(DataObject var1, String var2, boolean var3) {
		Object var5 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "Object getPropertyValue(DataObject, String, boolean)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2, var3}));
		}

		Object var6 = null;

		try {
			var6 = var1.get(var2);
		} catch (IllegalArgumentException var10) {
			var5 = null;
		}

		if (var6 != null && !(var6 instanceof List)) {
			var5 = var6;
		} else if (var6 != null) {
			List var7 = (List) var6;
			if (var7.size() > 0) {
				var5 = var7.get(0);

				for (int var8 = 1; var8 < var7.size(); ++var8) {
					int var9 = this.compareProperties(var5, var7.get(var8));
					if (var9 > 0 && var3) {
						var5 = var7.get(var8);
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "Object getPropertyValue(DataObject, String, boolean)",
					WIMTraceHelper.printObjectArray(new Object[]{var5}));
		}

		return var5;
	}

	private int compareProperties(Object var1, Object var2) {
		Collator var4 = null;
		int var5 = 0;
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.entering(CLASSNAME, "compareProperties(Object, Object)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2}));
		}

		if (this.sortControl != null) {
			String var6 = this.sortControl.getString("locale");
			Locale var7 = Locale.getDefault();
			if (var6 != null) {
				int var8 = var6.indexOf("-");
				if (var8 != -1) {
					String var9 = var6.substring(0, var8);
					String var10 = var6.substring(var8 + 1);
					var7 = new Locale(var9, var10);
				} else {
					var7 = new Locale(var6);
				}
			}

			if (var7 != null) {
				var4 = Collator.getInstance(var7);
				var4.setStrength(3);
			}

			boolean var11 = false;
			if (var1 == null && var2 == null) {
				var5 = 0;
			} else if (var1 == null) {
				var5 = -1;
			} else if (var2 == null) {
				var5 = 1;
			} else if (var1 instanceof String) {
				var5 = var4.compare(var1, var2);
			} else if (var1 instanceof Integer) {
				var5 = ((Integer) var1).compareTo((Integer) var2);
			} else if (var1 instanceof Long) {
				var5 = ((Long) var1).compareTo((Long) var2);
			} else if (var1 instanceof Double) {
				var5 = ((Double) var1).compareTo((Double) var2);
			} else {
				var5 = var4.compare(var1.toString(), var2.toString());
			}
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.exiting(CLASSNAME, "compareProperties(Object, Object)", "return code = " + var5);
		}

		return var5;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}