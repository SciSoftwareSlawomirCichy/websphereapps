package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.AbstractMapBasedMultimap.AsMap;
import com.google.common.collect.AbstractMapBasedMultimap.EntryIterator;
import com.google.common.collect.AbstractMapBasedMultimap.KeySet;
import com.google.common.collect.AbstractMapBasedMultimap.RandomAccessWrappedList;
import com.google.common.collect.AbstractMapBasedMultimap.SortedAsMap;
import com.google.common.collect.AbstractMapBasedMultimap.SortedKeySet;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedCollection;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedList;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedSet;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedSortedSet;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.RandomAccess;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
abstract class AbstractMapBasedMultimap<K, V> extends AbstractMultimap<K, V> implements Serializable {
	private transient Map<K, Collection<V>> map;
	private transient int totalSize;
	private static final long serialVersionUID = 2447537837011683357L;

	protected AbstractMapBasedMultimap(Map<K, Collection<V>> map) {
		Preconditions.checkArgument(map.isEmpty());
		this.map = map;
	}

	final void setMap(Map<K, Collection<V>> map) {
		this.map = map;
		this.totalSize = 0;

		Collection values;
		for (Iterator i$ = map.values().iterator(); i$.hasNext(); this.totalSize += values.size()) {
			values = (Collection) i$.next();
			Preconditions.checkArgument(!values.isEmpty());
		}

	}

	Collection<V> createUnmodifiableEmptyCollection() {
		return this.unmodifiableCollectionSubclass(this.createCollection());
	}

	abstract Collection<V> createCollection();

	Collection<V> createCollection(@Nullable K key) {
		return this.createCollection();
	}

	Map<K, Collection<V>> backingMap() {
		return this.map;
	}

	public int size() {
		return this.totalSize;
	}

	public boolean containsKey(@Nullable Object key) {
		return this.map.containsKey(key);
	}

	public boolean put(@Nullable K key, @Nullable V value) {
		Collection<V> collection = (Collection) this.map.get(key);
		if (collection == null) {
			collection = this.createCollection(key);
			if (collection.add(value)) {
				++this.totalSize;
				this.map.put(key, collection);
				return true;
			} else {
				throw new AssertionError("New Collection violated the Collection spec");
			}
		} else if (collection.add(value)) {
			++this.totalSize;
			return true;
		} else {
			return false;
		}
	}

	private Collection<V> getOrCreateCollection(@Nullable K key) {
		Collection<V> collection = (Collection) this.map.get(key);
		if (collection == null) {
			collection = this.createCollection(key);
			this.map.put(key, collection);
		}

		return collection;
	}

	public Collection<V> replaceValues(@Nullable K key, Iterable<? extends V> values) {
		Iterator<? extends V> iterator = values.iterator();
		if (!iterator.hasNext()) {
			return this.removeAll(key);
		} else {
			Collection<V> collection = this.getOrCreateCollection(key);
			Collection<V> oldValues = this.createCollection();
			oldValues.addAll(collection);
			this.totalSize -= collection.size();
			collection.clear();

			while (iterator.hasNext()) {
				if (collection.add(iterator.next())) {
					++this.totalSize;
				}
			}

			return this.unmodifiableCollectionSubclass(oldValues);
		}
	}

	public Collection<V> removeAll(@Nullable Object key) {
		Collection<V> collection = (Collection) this.map.remove(key);
		if (collection == null) {
			return this.createUnmodifiableEmptyCollection();
		} else {
			Collection<V> output = this.createCollection();
			output.addAll(collection);
			this.totalSize -= collection.size();
			collection.clear();
			return this.unmodifiableCollectionSubclass(output);
		}
	}

	Collection<V> unmodifiableCollectionSubclass(Collection<V> collection) {
		if (collection instanceof SortedSet) {
			return Collections.unmodifiableSortedSet((SortedSet) collection);
		} else if (collection instanceof Set) {
			return Collections.unmodifiableSet((Set) collection);
		} else {
			return (Collection) (collection instanceof List
					? Collections.unmodifiableList((List) collection)
					: Collections.unmodifiableCollection(collection));
		}
	}

	public void clear() {
		Iterator i$ = this.map.values().iterator();

		while (i$.hasNext()) {
			Collection<V> collection = (Collection) i$.next();
			collection.clear();
		}

		this.map.clear();
		this.totalSize = 0;
	}

	public Collection<V> get(@Nullable K key) {
		Collection<V> collection = (Collection) this.map.get(key);
		if (collection == null) {
			collection = this.createCollection(key);
		}

		return this.wrapCollection(key, collection);
	}

	Collection<V> wrapCollection(@Nullable K key, Collection<V> collection) {
		if (collection instanceof SortedSet) {
			return new WrappedSortedSet(this, key, (SortedSet) collection, (WrappedCollection) null);
		} else if (collection instanceof Set) {
			return new WrappedSet(this, key, (Set) collection);
		} else {
			return (Collection) (collection instanceof List
					? this.wrapList(key, (List) collection, (WrappedCollection) null)
					: new WrappedCollection(this, key, collection, (WrappedCollection) null));
		}
	}

	private List<V> wrapList(@Nullable K key, List<V> list,
			@Nullable AbstractMapBasedMultimap<K, V>.WrappedCollection ancestor) {
		return (List) (list instanceof RandomAccess
				? new RandomAccessWrappedList(this, key, list, ancestor)
				: new WrappedList(this, key, list, ancestor));
	}

	private Iterator<V> iteratorOrListIterator(Collection<V> collection) {
		return (Iterator) (collection instanceof List ? ((List) collection).listIterator() : collection.iterator());
	}

	Set<K> createKeySet() {
		return (Set) (this.map instanceof SortedMap
				? new SortedKeySet(this, (SortedMap) this.map)
				: new KeySet(this, this.map));
	}

	private int removeValuesForKey(Object key) {
		Collection<V> collection = (Collection) Maps.safeRemove(this.map, key);
		int count = 0;
		if (collection != null) {
			count = collection.size();
			collection.clear();
			this.totalSize -= count;
		}

		return count;
	}

	public Collection<V> values() {
		return super.values();
	}

	public Collection<Entry<K, V>> entries() {
		return super.entries();
	}

	Iterator<Entry<K, V>> entryIterator() {
		return new EntryIterator(this);
	}

	Map<K, Collection<V>> createAsMap() {
		return (Map) (this.map instanceof SortedMap
				? new SortedAsMap(this, (SortedMap) this.map)
				: new AsMap(this, this.map));
	}
}