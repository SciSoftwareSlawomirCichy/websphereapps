package com.google.common.util.concurrent;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.AbstractCatchingFuture.AsyncCatchingFuture;
import com.google.common.util.concurrent.AbstractCatchingFuture.CatchingFuture;
import com.google.common.util.concurrent.FluentFuture.TrustedFuture;
import com.google.errorprone.annotations.ForOverride;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AbstractCatchingFuture<V, X extends Throwable, F, T> extends TrustedFuture<V> implements Runnable {
	@NullableDecl
	ListenableFuture<? extends V> inputFuture;
	@NullableDecl
	Class<X> exceptionType;
	@NullableDecl
	F fallback;

	static <V, X extends Throwable> ListenableFuture<V> create(ListenableFuture<? extends V> input,
			Class<X> exceptionType, Function<? super X, ? extends V> fallback, Executor executor) {
		CatchingFuture<V, X> future = new CatchingFuture(input, exceptionType, fallback);
		input.addListener(future, MoreExecutors.rejectionPropagatingExecutor(executor, future));
		return future;
	}

	static <X extends Throwable, V> ListenableFuture<V> create(ListenableFuture<? extends V> input,
			Class<X> exceptionType, AsyncFunction<? super X, ? extends V> fallback, Executor executor) {
		AsyncCatchingFuture<V, X> future = new AsyncCatchingFuture(input, exceptionType, fallback);
		input.addListener(future, MoreExecutors.rejectionPropagatingExecutor(executor, future));
		return future;
	}

	AbstractCatchingFuture(ListenableFuture<? extends V> inputFuture, Class<X> exceptionType, F fallback) {
		this.inputFuture = (ListenableFuture) Preconditions.checkNotNull(inputFuture);
		this.exceptionType = (Class) Preconditions.checkNotNull(exceptionType);
		this.fallback = Preconditions.checkNotNull(fallback);
	}

	public final void run() {
		ListenableFuture<? extends V> localInputFuture = this.inputFuture;
		Class<X> localExceptionType = this.exceptionType;
		F localFallback = this.fallback;
		if (!(localInputFuture == null | localExceptionType == null | localFallback == null | this.isCancelled())) {
			this.inputFuture = null;
			V sourceResult = null;
			Throwable throwable = null;

			try {
				sourceResult = Futures.getDone(localInputFuture);
			} catch (ExecutionException var14) {
				throwable = (Throwable) Preconditions.checkNotNull(var14.getCause());
			} catch (Throwable var15) {
				throwable = var15;
			}

			if (throwable == null) {
				this.set(sourceResult);
			} else if (!Platform.isInstanceOfThrowableClass(throwable, localExceptionType)) {
				this.setFuture(localInputFuture);
			} else {
				Throwable castThrowable = throwable;

				Object fallbackResult;
				label102 : {
					try {
						fallbackResult = this.doFallback(localFallback, castThrowable);
						break label102;
					} catch (Throwable var16) {
						this.setException(var16);
					} finally {
						this.exceptionType = null;
						this.fallback = null;
					}

					return;
				}

				this.setResult(fallbackResult);
			}
		}
	}

	protected String pendingToString() {
		ListenableFuture<? extends V> localInputFuture = this.inputFuture;
		Class<X> localExceptionType = this.exceptionType;
		F localFallback = this.fallback;
		String superString = super.pendingToString();
		String resultString = "";
		if (localInputFuture != null) {
			resultString = "inputFuture=[" + localInputFuture + "], ";
		}

		if (localExceptionType != null && localFallback != null) {
			return resultString + "exceptionType=[" + localExceptionType + "], fallback=[" + localFallback + "]";
		} else {
			return superString != null ? resultString + superString : null;
		}
	}

	@NullableDecl
	@ForOverride
	abstract T doFallback(F var1, X var2) throws Exception;

	@ForOverride
	abstract void setResult(@NullableDecl T var1);

	protected final void afterDone() {
		this.maybePropagateCancellationTo(this.inputFuture);
		this.inputFuture = null;
		this.exceptionType = null;
		this.fallback = null;
	}
}