package com.ibm.ejs.container.util;

import com.ibm.ws.util.PlatformHelper;
import com.ibm.ws.util.PlatformHelperFactory;

public class EJSPlatformHelper {
	public static final boolean runInZOS;
	public static final boolean runInZOSCRA;

	public static boolean isZOS() {
		return runInZOS;
	}

	public static boolean isZOSCRA() {
		return runInZOSCRA;
	}

	static {
		PlatformHelper helper = PlatformHelperFactory.getPlatformHelper();
		runInZOS = helper.isZOS();
		runInZOSCRA = helper.isCRAJvm();
	}
}