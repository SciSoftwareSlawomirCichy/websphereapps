package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.RegularImmutableMap.1;
import com.google.common.collect.RegularImmutableMap.EntrySet;
import com.google.common.collect.RegularImmutableMap.LinkedEntry;
import com.google.common.collect.RegularImmutableMap.NonTerminalEntry;
import com.google.common.collect.RegularImmutableMap.TerminalEntry;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(serializable = true, emulated = true)
final class RegularImmutableMap<K, V> extends ImmutableMap<K, V> {
	private final transient LinkedEntry<K, V>[] entries;
	private final transient LinkedEntry<K, V>[] table;
	private final transient int mask;
	private static final double MAX_LOAD_FACTOR = 1.2D;
	private static final long serialVersionUID = 0L;

	RegularImmutableMap(Entry... immutableEntries) {
		int size = immutableEntries.length;
		this.entries = this.createEntryArray(size);
		int tableSize = Hashing.closedTableSize(size, 1.2D);
		this.table = this.createEntryArray(tableSize);
		this.mask = tableSize - 1;

		for (int entryIndex = 0; entryIndex < size; ++entryIndex) {
			Entry<K, V> entry = immutableEntries[entryIndex];
			K key = entry.getKey();
			int keyHashCode = key.hashCode();
			int tableIndex = Hashing.smear(keyHashCode) & this.mask;
			LinkedEntry<K, V> existing = this.table[tableIndex];
			LinkedEntry<K, V> linkedEntry = newLinkedEntry(key, entry.getValue(), existing);
			this.table[tableIndex] = linkedEntry;

			for (this.entries[entryIndex] = linkedEntry; existing != null; existing = existing.next()) {
				Preconditions.checkArgument(!key.equals(existing.getKey()), "duplicate key: %s", new Object[]{key});
			}
		}

	}

	private LinkedEntry<K, V>[] createEntryArray(int size) {
		return new LinkedEntry[size];
	}

	private static <K, V> LinkedEntry<K, V> newLinkedEntry(K key, V value, @Nullable LinkedEntry<K, V> next) {
		return (LinkedEntry) (next == null ? new TerminalEntry(key, value) : new NonTerminalEntry(key, value, next));
	}

	public V get(@Nullable Object key) {
		if (key == null) {
			return null;
		} else {
			int index = Hashing.smear(key.hashCode()) & this.mask;

			for (LinkedEntry entry = this.table[index]; entry != null; entry = entry.next()) {
				K candidateKey = entry.getKey();
				if (key.equals(candidateKey)) {
					return entry.getValue();
				}
			}

			return null;
		}
	}

	public int size() {
		return this.entries.length;
	}

	boolean isPartialView() {
		return false;
	}

	ImmutableSet<Entry<K, V>> createEntrySet() {
      return new EntrySet(this, (1)null);
   }
}