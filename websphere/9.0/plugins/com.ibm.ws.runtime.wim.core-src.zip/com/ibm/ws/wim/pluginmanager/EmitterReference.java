package com.ibm.ws.wim.pluginmanager;

import com.ibm.websphere.wim.pluginmanager.context.PluginManagerConstants;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.ModificationSubscriber;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import com.ibm.ws.wim.configmodel.NotificationSubscriber;
import com.ibm.ws.wim.configmodel.NotificationSubscriberList;
import com.ibm.ws.wim.configmodel.PostExit;
import com.ibm.ws.wim.configmodel.PreExit;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

public class EmitterReference {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String emitterName;
	private String preExitPointName;
	private String postExitPointName;
	private HashSet inlineExitNames;
	private HashMap exitPointMap;
	private static String newline = System.getProperty("line.separator");

	public EmitterReference(String var1) {
		this.emitterName = var1;
		this.preExitPointName = var1 + "." + PluginManagerConstants.PREEXIT_LITERAL;
		this.postExitPointName = var1 + "." + PluginManagerConstants.POSTEXIT_LITERAL;
		this.exitPointMap = new HashMap();
		this.inlineExitNames = new HashSet();
	}

	private Object getSubscriber(Vector var1, String var2) {
		SubscriberRealmInfo var3 = null;
		Iterator var4 = var1.iterator();

		while (var4.hasNext()) {
			SubscriberRealmInfo var5 = (SubscriberRealmInfo) var4.next();
			String var6 = var5.getSubscriberName();
			if (var6.equals(var2)) {
				var3 = var5;
				break;
			}
		}

		return var3;
	}

	private boolean checkChangeInModSubscriberList(ModificationSubscriber[] var1, HashMap var2, Vector var3) {
		boolean var4 = false;

		for (int var5 = 0; var1 != null && var5 < var1.length; ++var5) {
			String var6 = var1[var5].getModificationSubscriberReference();
			HashSet var7 = new HashSet(var1[var5].getRealmList());
			if (var2.containsKey(var6)) {
				var4 = true;
				break;
			}

			Object var8 = this.getSubscriber(var3, var6);
			if (var8 == null) {
				var4 = true;
				break;
			}

			SubscriberRealmInfo var9 = (SubscriberRealmInfo) var8;
			HashSet var10 = var9.getRealmSet();
			if (!var10.equals(var7)) {
				var4 = true;
				break;
			}
		}

		return var4;
	}

	private boolean checkChangeInNotSubscriberList(NotificationSubscriber[] var1, HashMap var2, Vector var3) {
		boolean var4 = false;

		for (int var5 = 0; var1 != null && var5 < var1.length; ++var5) {
			String var6 = var1[var5].getNotificationSubscriberReference();
			HashSet var7 = new HashSet(var1[var5].getRealmList());
			if (var2.containsKey(var6)) {
				var4 = true;
				break;
			}

			Object var8 = this.getSubscriber(var3, var6);
			if (var8 == null) {
				var4 = true;
				break;
			}

			SubscriberRealmInfo var9 = (SubscriberRealmInfo) var8;
			HashSet var10 = var9.getRealmSet();
			if (!var10.equals(var7)) {
				var4 = true;
				break;
			}
		}

		return var4;
	}

	public boolean doesInlineExist(String var1) {
		String var2 = this.emitterName + "." + var1;
		return this.exitPointMap.containsKey(var2);
	}

	public String getEmitterName() {
		return this.emitterName;
	}

	public ExitPointExecList getPreExit() {
		ExitPointExecList var1 = (ExitPointExecList) this.exitPointMap.get(this.preExitPointName);
		return var1;
	}

	public ExitPointExecList getPostExit() {
		ExitPointExecList var1 = (ExitPointExecList) this.exitPointMap.get(this.postExitPointName);
		return var1;
	}

	public ExitPointExecList[] getInlineExits() {
		ExitPointExecList[] var1 = null;
		int var2 = this.inlineExitNames.size();
		if (var2 > 0) {
			var1 = new ExitPointExecList[var2];
			Iterator var3 = this.inlineExitNames.iterator();

			for (int var4 = 0; var3.hasNext(); var1[var4++] = (ExitPointExecList) this.exitPointMap.get(var3.next())) {
				;
			}
		}

		return var1;
	}

	public Vector getInlineExitModificationList(String var1) {
		String var2 = this.emitterName + "." + var1;
		Object var3 = this.exitPointMap.get(var2);
		ExitPointExecList var4 = null;
		Vector var5 = null;
		if (var3 != null && var3 instanceof ExitPointExecList) {
			var4 = (ExitPointExecList) var3;
			var5 = var4.getModificationList();
		}

		return var5;
	}

	public Vector getPostExitModificationList() {
		ExitPointExecList var1 = (ExitPointExecList) this.exitPointMap.get(this.postExitPointName);
		return var1.getModificationList();
	}

	public Vector getPostExitNotificationList() {
		ExitPointExecList var1 = (ExitPointExecList) this.exitPointMap.get(this.postExitPointName);
		return var1.getNotificationList();
	}

	public Vector getPreExitModificationList() {
		ExitPointExecList var1 = (ExitPointExecList) this.exitPointMap.get(this.preExitPointName);
		return var1.getModificationList();
	}

	public Vector getPreExitNotificationList() {
		ExitPointExecList var1 = (ExitPointExecList) this.exitPointMap.get(this.preExitPointName);
		return var1.getNotificationList();
	}

	public boolean isChangedInlineExits(TopicEmitter var1, HashMap var2) {
		boolean var3 = false;
		InlineExit[] var4 = var1.getInlineExitAsArray();
		int var5 = this.exitPointMap.size() - 2;
		if (var5 != var4.length) {
			var3 = true;
		}

		if (!var3) {
			for (int var6 = 0; var6 < var4.length; ++var6) {
				InlineExit var7 = var4[var6];
				String var8 = var7.getInlineExitName();
				ModificationSubscriberList var9 = var7.getModificationSubscriberList();
				ModificationSubscriber[] var10 = null;
				if (var9 != null) {
					var10 = var9.getModificationSubscriberAsArray();
				}

				if (!this.doesInlineExist(var8)) {
					var3 = true;
					break;
				}

				Vector var11 = this.getInlineExitModificationList(var8);
				if (var10 == null && var11.size() != 0 || var10 != null && var11.size() != var10.length) {
					var3 = true;
					break;
				}

				var3 = this.checkChangeInModSubscriberList(var10, var2, var11);
				if (var3) {
					break;
				}
			}
		}

		return var3;
	}

	public boolean isChangedPostExit(TopicEmitter var1, HashMap var2) {
		boolean var3 = false;
		PostExit var4 = var1.getPostExit();
		NotificationSubscriberList var5 = null;
		ModificationSubscriberList var6 = null;
		if (var4 != null) {
			var5 = var4.getNotificationSubscriberList();
			var6 = var4.getModificationSubscriberList();
		}

		NotificationSubscriber[] var7 = null;
		ModificationSubscriber[] var8 = null;
		if (var5 != null) {
			var7 = var5.getNotificationSubscriberAsArray();
		}

		if (var6 != null) {
			var8 = var6.getModificationSubscriberAsArray();
		}

		Vector var9 = this.getPostExitNotificationList();
		Vector var10 = this.getPostExitModificationList();
		if (var7 == null && var9.size() != 0 || var8 == null && var10.size() != 0) {
			var3 = true;
		}

		if (!var3) {
			if (var7 != null && var9.size() != var7.length) {
				var3 = true;
			}

			if (var8 != null && var10.size() != var8.length) {
				var3 = true;
			}
		}

		if (!var3) {
			var3 = this.checkChangeInModSubscriberList(var8, var2, var10);
		}

		if (!var3) {
			var3 = this.checkChangeInNotSubscriberList(var7, var2, var9);
		}

		return var3;
	}

	public boolean isChangedPreExit(TopicEmitter var1, HashMap var2) {
		boolean var3 = false;
		PreExit var4 = var1.getPreExit();
		NotificationSubscriberList var5 = null;
		ModificationSubscriberList var6 = null;
		if (var4 != null) {
			var5 = var4.getNotificationSubscriberList();
			var6 = var4.getModificationSubscriberList();
		}

		NotificationSubscriber[] var7 = null;
		ModificationSubscriber[] var8 = null;
		if (var5 != null) {
			var7 = var5.getNotificationSubscriberAsArray();
		}

		if (var6 != null) {
			var8 = var6.getModificationSubscriberAsArray();
		}

		Vector var9 = this.getPreExitNotificationList();
		Vector var10 = this.getPreExitModificationList();
		if (var7 == null && var9.size() != 0) {
			var3 = true;
		}

		if (var8 == null && var10.size() != 0) {
			var3 = true;
		}

		if (!var3) {
			if (var7 != null && var9.size() != var7.length) {
				var3 = true;
			}

			if (var8 != null && var10.size() != var8.length) {
				var3 = true;
			}
		}

		if (!var3) {
			var3 = this.checkChangeInNotSubscriberList(var7, var2, var9);
		}

		if (!var3) {
			var3 = this.checkChangeInModSubscriberList(var8, var2, var10);
		}

		return var3;
	}

	public void setInlineExitExecList(ExitPointExecList var1, String var2) {
		String var3 = this.emitterName + "." + var2;
		var1.setName(var3);
		this.inlineExitNames.add(var3);
		this.exitPointMap.put(var3, var1);
	}

	public void setPostExitExecList(ExitPointExecList var1) {
		var1.setName(this.postExitPointName);
		this.exitPointMap.put(this.postExitPointName, var1);
	}

	public void setPreExitExecList(ExitPointExecList var1) {
		var1.setName(this.preExitPointName);
		this.exitPointMap.put(this.preExitPointName, var1);
	}

	public String printEmitterReference() {
		StringBuffer var1 = new StringBuffer();
		var1.append("EmitterName: ").append(this.emitterName).append(newline);
		Iterator var2 = this.exitPointMap.keySet().iterator();

		while (var2.hasNext()) {
			String var3 = (String) var2.next();
			ExitPointExecList var4 = (ExitPointExecList) this.exitPointMap.get(var3);
			var1.append("+++++++++++++++++++++++++++++" + newline);
			var1.append(var4.printExitPointExecList());
			var1.append("+++++++++++++++++++++++++++++" + newline);
		}

		return var1.toString();
	}
}