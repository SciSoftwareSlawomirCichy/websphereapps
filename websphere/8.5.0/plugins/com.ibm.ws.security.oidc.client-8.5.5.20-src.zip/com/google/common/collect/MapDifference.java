package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public interface MapDifference<K, V> {
	boolean areEqual();

	Map<K, V> entriesOnlyOnLeft();

	Map<K, V> entriesOnlyOnRight();

	Map<K, V> entriesInCommon();

	Map<K, ValueDifference<V>> entriesDiffering();

	boolean equals(@NullableDecl Object var1);

	int hashCode();

	public interface ValueDifference<V> {
		V leftValue();

		V rightValue();

		boolean equals(@NullableDecl Object var1);

		int hashCode();
	}
}