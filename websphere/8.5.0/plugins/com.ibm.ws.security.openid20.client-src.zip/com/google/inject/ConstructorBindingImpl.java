package com.google.inject;

import com.google.inject.ConstructorBindingImpl.1;
import com.google.inject.ConstructorBindingImpl.Factory;
import com.google.inject.internal.BindingImpl;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.InternalFactory;
import com.google.inject.internal.Preconditions;
import com.google.inject.internal.Scoping;
import com.google.inject.internal.ToStringBuilder;
import com.google.inject.internal.ImmutableSet.Builder;
import com.google.inject.spi.BindingTargetVisitor;
import com.google.inject.spi.ConstructorBinding;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.InjectionPoint;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.aopalliance.intercept.MethodInterceptor;

class ConstructorBindingImpl<T> extends BindingImpl<T> implements ConstructorBinding<T> {
	private final Factory<T> factory;

	private ConstructorBindingImpl(Injector injector, Key<T> key, Object source,
			InternalFactory<? extends T> scopedFactory, Scoping scoping, Factory<T> factory) {
		super(injector, key, source, scopedFactory, scoping);
		this.factory = factory;
	}

	static <T> ConstructorBindingImpl<T> create(InjectorImpl injector, Key<T> key, Object source, Scoping scoping) {
      Factory<T> factoryFactory = new Factory((1)null);
      InternalFactory<? extends T> scopedFactory = Scopes.scope(key, injector, factoryFactory, scoping);
      return new ConstructorBindingImpl(injector, key, source, scopedFactory, scoping, factoryFactory);
   }

	public void initialize(InjectorImpl injector, Errors errors) throws ErrorsException {
		Factory.access$102(this.factory, injector.constructors.get(this.getKey().getTypeLiteral(), errors));
	}

	public <V> V acceptTargetVisitor(BindingTargetVisitor<? super T, V> visitor) {
		Preconditions.checkState(Factory.access$100(this.factory) != null, "not initialized");
		return visitor.visit(this);
	}

	public InjectionPoint getConstructor() {
		Preconditions.checkState(Factory.access$100(this.factory) != null, "Binding is not ready");
		return Factory.access$100(this.factory).getConstructionProxy().getInjectionPoint();
	}

	public Set<InjectionPoint> getInjectableMembers() {
		Preconditions.checkState(Factory.access$100(this.factory) != null, "Binding is not ready");
		return Factory.access$100(this.factory).getInjectableMembers();
	}

	public Map<Method, List<MethodInterceptor>> getMethodInterceptors() {
		Preconditions.checkState(Factory.access$100(this.factory) != null, "Binding is not ready");
		return Factory.access$100(this.factory).getConstructionProxy().getMethodInterceptors();
	}

	public Set<Dependency<?>> getDependencies() {
		return Dependency.forInjectionPoints(
				(new Builder()).add(this.getConstructor()).addAll(this.getInjectableMembers()).build());
	}

	public void applyTo(Binder binder) {
		throw new UnsupportedOperationException("This element represents a synthetic binding.");
	}

	public String toString() {
		return (new ToStringBuilder(ConstructorBinding.class)).add("key", this.getKey()).add("source", this.getSource())
				.add("scope", this.getScoping()).toString();
	}
}