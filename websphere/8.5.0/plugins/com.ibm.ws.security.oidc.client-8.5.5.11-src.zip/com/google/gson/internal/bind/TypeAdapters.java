package com.google.gson.internal.bind;

import com.google.gson.JsonElement;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.bind.TypeAdapters.1;
import com.google.gson.internal.bind.TypeAdapters.10;
import com.google.gson.internal.bind.TypeAdapters.11;
import com.google.gson.internal.bind.TypeAdapters.12;
import com.google.gson.internal.bind.TypeAdapters.13;
import com.google.gson.internal.bind.TypeAdapters.14;
import com.google.gson.internal.bind.TypeAdapters.15;
import com.google.gson.internal.bind.TypeAdapters.16;
import com.google.gson.internal.bind.TypeAdapters.17;
import com.google.gson.internal.bind.TypeAdapters.18;
import com.google.gson.internal.bind.TypeAdapters.19;
import com.google.gson.internal.bind.TypeAdapters.2;
import com.google.gson.internal.bind.TypeAdapters.20;
import com.google.gson.internal.bind.TypeAdapters.21;
import com.google.gson.internal.bind.TypeAdapters.22;
import com.google.gson.internal.bind.TypeAdapters.23;
import com.google.gson.internal.bind.TypeAdapters.24;
import com.google.gson.internal.bind.TypeAdapters.25;
import com.google.gson.internal.bind.TypeAdapters.26;
import com.google.gson.internal.bind.TypeAdapters.27;
import com.google.gson.internal.bind.TypeAdapters.28;
import com.google.gson.internal.bind.TypeAdapters.29;
import com.google.gson.internal.bind.TypeAdapters.3;
import com.google.gson.internal.bind.TypeAdapters.30;
import com.google.gson.internal.bind.TypeAdapters.31;
import com.google.gson.internal.bind.TypeAdapters.4;
import com.google.gson.internal.bind.TypeAdapters.5;
import com.google.gson.internal.bind.TypeAdapters.6;
import com.google.gson.internal.bind.TypeAdapters.7;
import com.google.gson.internal.bind.TypeAdapters.8;
import com.google.gson.internal.bind.TypeAdapters.9;
import com.google.gson.reflect.TypeToken;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.util.BitSet;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.UUID;

public final class TypeAdapters {
	public static final TypeAdapter<Class> CLASS = new 1();
	public static final TypeAdapterFactory CLASS_FACTORY;
	public static final TypeAdapter<BitSet> BIT_SET;
	public static final TypeAdapterFactory BIT_SET_FACTORY;
	public static final TypeAdapter<Boolean> BOOLEAN;
	public static final TypeAdapter<Boolean> BOOLEAN_AS_STRING;
	public static final TypeAdapterFactory BOOLEAN_FACTORY;
	public static final TypeAdapter<Number> BYTE;
	public static final TypeAdapterFactory BYTE_FACTORY;
	public static final TypeAdapter<Number> SHORT;
	public static final TypeAdapterFactory SHORT_FACTORY;
	public static final TypeAdapter<Number> INTEGER;
	public static final TypeAdapterFactory INTEGER_FACTORY;
	public static final TypeAdapter<Number> LONG;
	public static final TypeAdapter<Number> FLOAT;
	public static final TypeAdapter<Number> DOUBLE;
	public static final TypeAdapter<Number> NUMBER;
	public static final TypeAdapterFactory NUMBER_FACTORY;
	public static final TypeAdapter<Character> CHARACTER;
	public static final TypeAdapterFactory CHARACTER_FACTORY;
	public static final TypeAdapter<String> STRING;
	public static final TypeAdapter<BigDecimal> BIG_DECIMAL;
	public static final TypeAdapter<BigInteger> BIG_INTEGER;
	public static final TypeAdapterFactory STRING_FACTORY;
	public static final TypeAdapter<StringBuilder> STRING_BUILDER;
	public static final TypeAdapterFactory STRING_BUILDER_FACTORY;
	public static final TypeAdapter<StringBuffer> STRING_BUFFER;
	public static final TypeAdapterFactory STRING_BUFFER_FACTORY;
	public static final TypeAdapter<URL> URL;
	public static final TypeAdapterFactory URL_FACTORY;
	public static final TypeAdapter<URI> URI;
	public static final TypeAdapterFactory URI_FACTORY;
	public static final TypeAdapter<InetAddress> INET_ADDRESS;
	public static final TypeAdapterFactory INET_ADDRESS_FACTORY;
	public static final TypeAdapter<UUID> UUID;
	public static final TypeAdapterFactory UUID_FACTORY;
	public static final TypeAdapterFactory TIMESTAMP_FACTORY;
	public static final TypeAdapter<Calendar> CALENDAR;
	public static final TypeAdapterFactory CALENDAR_FACTORY;
	public static final TypeAdapter<Locale> LOCALE;
	public static final TypeAdapterFactory LOCALE_FACTORY;
	public static final TypeAdapter<JsonElement> JSON_ELEMENT;
	public static final TypeAdapterFactory JSON_ELEMENT_FACTORY;
	public static final TypeAdapterFactory ENUM_FACTORY;

	public static TypeAdapterFactory newEnumTypeHierarchyFactory() {
      return new 26();
   }

	public static <TT> TypeAdapterFactory newFactory(TypeToken<TT> type, TypeAdapter<TT> typeAdapter) {
      return new 27(type, typeAdapter);
   }

	public static <TT> TypeAdapterFactory newFactory(Class<TT> type, TypeAdapter<TT> typeAdapter) {
      return new 28(type, typeAdapter);
   }

	public static <TT> TypeAdapterFactory newFactory(Class<TT> unboxed, Class<TT> boxed, TypeAdapter<? super TT> typeAdapter) {
      return new 29(unboxed, boxed, typeAdapter);
   }

	public static <TT> TypeAdapterFactory newFactoryForMultipleTypes(Class<TT> base, Class<? extends TT> sub, TypeAdapter<? super TT> typeAdapter) {
      return new 30(base, sub, typeAdapter);
   }

	public static <TT> TypeAdapterFactory newTypeHierarchyFactory(Class<TT> clazz, TypeAdapter<TT> typeAdapter) {
      return new 31(clazz, typeAdapter);
   }

	static {
      CLASS_FACTORY = newFactory(Class.class, CLASS);
      BIT_SET = new 2();
      BIT_SET_FACTORY = newFactory(BitSet.class, BIT_SET);
      BOOLEAN = new 3();
      BOOLEAN_AS_STRING = new 4();
      BOOLEAN_FACTORY = newFactory(Boolean.TYPE, Boolean.class, BOOLEAN);
      BYTE = new 5();
      BYTE_FACTORY = newFactory(Byte.TYPE, Byte.class, BYTE);
      SHORT = new 6();
      SHORT_FACTORY = newFactory(Short.TYPE, Short.class, SHORT);
      INTEGER = new 7();
      INTEGER_FACTORY = newFactory(Integer.TYPE, Integer.class, INTEGER);
      LONG = new 8();
      FLOAT = new 9();
      DOUBLE = new 10();
      NUMBER = new 11();
      NUMBER_FACTORY = newFactory(Number.class, NUMBER);
      CHARACTER = new 12();
      CHARACTER_FACTORY = newFactory(Character.TYPE, Character.class, CHARACTER);
      STRING = new 13();
      BIG_DECIMAL = new 14();
      BIG_INTEGER = new 15();
      STRING_FACTORY = newFactory(String.class, STRING);
      STRING_BUILDER = new 16();
      STRING_BUILDER_FACTORY = newFactory(StringBuilder.class, STRING_BUILDER);
      STRING_BUFFER = new 17();
      STRING_BUFFER_FACTORY = newFactory(StringBuffer.class, STRING_BUFFER);
      URL = new 18();
      URL_FACTORY = newFactory(URL.class, URL);
      URI = new 19();
      URI_FACTORY = newFactory(URI.class, URI);
      INET_ADDRESS = new 20();
      INET_ADDRESS_FACTORY = newTypeHierarchyFactory(InetAddress.class, INET_ADDRESS);
      UUID = new 21();
      UUID_FACTORY = newFactory(UUID.class, UUID);
      TIMESTAMP_FACTORY = new 22();
      CALENDAR = new 23();
      CALENDAR_FACTORY = newFactoryForMultipleTypes(Calendar.class, GregorianCalendar.class, CALENDAR);
      LOCALE = new 24();
      LOCALE_FACTORY = newFactory(Locale.class, LOCALE);
      JSON_ELEMENT = new 25();
      JSON_ELEMENT_FACTORY = newTypeHierarchyFactory(JsonElement.class, JSON_ELEMENT);
      ENUM_FACTORY = newEnumTypeHierarchyFactory();
   }
}