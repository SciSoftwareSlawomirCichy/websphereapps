package com.ibm.ws.wim.xpath.util;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.ws.wim.PropertyManager;
import com.ibm.ws.wim.RepositoryPropertyMap;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.xpath.mapping.datatype.LogicalNode;
import com.ibm.ws.wim.xpath.mapping.datatype.ParenthesisNode;
import com.ibm.ws.wim.xpath.mapping.datatype.PropertyNode;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ProfileManagerMetadataMapper implements MetadataMapper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private List entityTypes = null;
	RepositoryPropertyMap laPropertyNames = null;
	RepositoryPropertyMap reposPropertyNames = null;

	public ProfileManagerMetadataMapper(String var1, List var2) throws WIMException {
		this.entityTypes = var2;
		PropertyManager var3 = PropertyManager.singleton();
		this.laPropertyNames = var3.getLookAsidePropertyNameMap();
		this.reposPropertyNames = var3.getPropertyMapByRepositoryId(var1);
	}

	public boolean isPropertyInLookAside(String var1, String var2) {
		boolean var3 = false;
		if (this.laPropertyNames != null && var1 != null) {
			HashSet var4 = (HashSet) this.laPropertyNames.getRepositoryPropertySetByEntityType(var2);
			if (var4 != null) {
				var3 = var4.contains(var1);
			} else {
				try {
					Set var5 = SchemaManager.singleton().getSubEntityTypes(var2);
					if (var5 != null) {
						Iterator var6 = var5.iterator();

						while (var6.hasNext() && !var3) {
							var4 = (HashSet) this.laPropertyNames
									.getRepositoryPropertySetByEntityType((String) var6.next());
							if (var4 != null) {
								var3 = var4.contains(var1);
							}
						}
					}
				} catch (Exception var7) {
					;
				}
			}
		}

		return var3;
	}

	public boolean isPropertyInRepository(String var1, String var2) {
		boolean var3 = false;
		if (this.reposPropertyNames != null && var1 != null) {
			Set var4 = this.reposPropertyNames.getRepositoryPropertySetByEntityType(var2);
			if (var4 != null) {
				var3 = var4.contains(var1);
			} else {
				try {
					Set var5 = SchemaManager.singleton().getSubEntityTypes(var2);
					if (var5 != null) {
						Iterator var6 = var5.iterator();

						while (var6.hasNext() && !var3) {
							var4 = this.reposPropertyNames.getRepositoryPropertySetByEntityType((String) var6.next());
							if (var4 != null) {
								var3 = var4.contains(var1);
							}
						}
					}
				} catch (Exception var7) {
					;
				}
			}
		}

		return var3;
	}

	public boolean isValidEntityType(String var1) {
		boolean var2 = false;
		if (this.entityTypes != null && var1 != null && var1.length() != 0) {
			var2 = this.entityTypes.contains(var1);
		}

		return var2;
	}

	public void genSearchString(StringBuffer var1, LogicalNode var2) {
	}

	public void genSearchString(StringBuffer var1, ParenthesisNode var2) {
	}

	public void genSearchString(StringBuffer var1, PropertyNode var2) {
	}
}