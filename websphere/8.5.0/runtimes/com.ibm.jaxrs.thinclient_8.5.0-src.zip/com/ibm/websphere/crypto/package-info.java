package com.ibm.websphere.crypto;

interface package-info {
}