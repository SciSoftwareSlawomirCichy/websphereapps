package com.ibm.ejs.container;

import com.ibm.ejs.container.activator.TimeoutKey;
import com.ibm.ejs.container.lock.LockStrategy;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.EJBMethodInfo;
import com.ibm.websphere.csi.InconsistentAccessIntentException;
import com.ibm.websphere.ejbcontainer.EntityContextExtension;
import com.ibm.ws.appprofile.accessintent.EJBAccessIntent;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;
import com.ibm.ws.exception.WsNestedException;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.security.Principal;
import java.util.Map;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.ejb.EnterpriseBean;
import javax.ejb.EntityBean;
import javax.ejb.RemoveException;
import javax.ejb.TimerService;
import javax.rmi.PortableRemoteObject;

public abstract class EntityBeanOImpl extends EntityBeanO implements EntityContextExtension {
	private static final TraceComponent tc = Tr.register(EntityBeanOImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.EntityBeanOImpl";
	protected EJBAccessIntent aiService;
	protected AccessIntent ivAccessIntent;
	protected boolean ivBMP = false;
	protected boolean cachedExclusive = false;
	protected final boolean ivReadOnly;
	protected boolean reentrant = false;
	protected int callDepth = 0;
	protected boolean created = false;
	protected boolean removed = false;
	protected boolean discarded = false;
	protected boolean dirty = false;
	protected boolean invalid = false;
	protected LockStrategy lockStrategy;
	protected EntityBean entityBean;
	protected boolean inStore = false;
	protected boolean inCreate = false;
	public static final int DESTROYED = 0;
	public static final int POOLED = 1;
	public static final int CREATING = 2;
	public static final int LOADING = 3;
	public static final int CACHED_EXCLUSIVE = 4;
	public static final int CACHED_SHARED = 5;
	public static final int ACTIVE = 6;
	public static final int IN_METHOD = 7;
	public static final int COMMITTING = 8;
	public static final int REFRESHING = 9;
	public static final int STORING = 10;
	public static final int PASSIVATING = 11;
	public static final int HYDRATING = 12;
	public static final int IN_FINDER = 13;
	public static final int PRE_CREATE = 14;
	public static final int ACTIVATING = 15;
	protected static final String[] StateStrs = new String[]{"DESTROYED", "POOLED", "CREATING", "LOADING",
			"CACHED_EXCLUSIVE", "CACHED_SHARED", "ACTIVE", "IN_METHOD", "COMMITTING", "REFRESHING", "STORING",
			"PASSIVATING", "HYDRATING", "IN_FINDER", "PRE_CREATE", "ACTIVATING"};

	public EntityBeanOImpl(EJSContainer c, EJSHome h) {
		super(c, h);
		this.reentrant = h.beanMetaData.reentrant;
		this.lockStrategy = h.getLockStrategy();
		this.cachedExclusive = h.beanMetaData.optionACommitOption;
		this.ivReadOnly = h.beanMetaData.ivReadOnlyCommitOption;
		BeanMetaData bmd = h.beanMetaData;
		this.ivBMP = bmd.getEJBComponentType() == 5;
		if (bmd.getEJBModuleVersion() >= 20 && bmd.getCMPVersion() != 1) {
			EntityHelperImpl entityHelperImpl = (EntityHelperImpl) c.ivEntityHelper;
			this.aiService = entityHelperImpl.getEJBAccessIntent();
		}

	}

	protected String getStateName(int state) {
		return StateStrs[state];
	}

	void setEnterpriseBean(EntityBean bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setEnterpriseBean : " + Util.identity(bean));
		}

		this.entityBean = bean;
	}

	void initialize(boolean reactivate) throws RemoteException, InvocationTargetException {
		this.createInstance();
		EJBThreadData threadData = EJSContainer.getThreadData();

		try {
			this.state = 14;
			threadData.pushCallbackBeanO(this);
			this.entityBean.setEntityContext(this);
			this.state = 1;
		} finally {
			threadData.popCallbackBeanO();
		}

	}

	private void createInstance() throws InvocationTargetException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createInstance");
		}

		try {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "calling Constructor.newInstance");
			}

			Constructor<?> con = this.home.beanMetaData.getEnterpriseBeanClassConstructor();
			this.setEnterpriseBean((EntityBean) con.newInstance());
		} catch (InvocationTargetException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.EntityBeanOImpl.createInstance", "216", this);
			throw var3;
		} catch (Exception var4) {
			FFDCFilter.processException(var4, "com.ibm.ejs.container.EntityBeanOImpl.createInstance", "220", this);
			throw new EJBException(this.home.beanMetaData.enterpriseBeanClassName, var4);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createInstance");
		}

	}

	public boolean isRemoved() {
		return this.removed;
	}

	public boolean isDestroyed() {
		return this.state == 0;
	}

	public boolean isDiscarded() {
		return this.discarded;
	}

	public int getLockMode() {
		return this.cachedExclusive ? 1 : this.getLockingMode();
	}

	public synchronized int getLockingMode() {
		if (this.removed) {
			return 1;
		} else {
			return this.dirty ? 1 : 0;
		}
	}

	protected final void waitUntilActive() throws RemoteException {
		do {
			if (this.state == 6) {
				return;
			}

			if (this.state == 0) {
				throw new BeanOActivationFailureException();
			}

			if (this.state == 1) {
				throw new BeanOActivationFailureException();
			}

			if (this.state == 8) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "waitUntilActive:COMMITTING", this);
				}

				this.setState(6);
				return;
			}
		} while (this.state != 10);

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "waitUntilActive: STORING", this);
		}

		this.setState(6);
	}

	public final synchronized void destroy() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "destroy", this);
		}

		if (this.state != 0) {
			this.ivContainerTx = null;
			this.ivAccessIntent = null;
			if (this.ivReadOnly && this.ivCacheKey != null) {
				((TimeoutKey) this.ivCacheKey).setDiscarded();
			}

			this.setState(0);
			EJBThreadData threadData = EJSContainer.getThreadData();
			boolean pushedCallbackBeanO = false;

			try {
				threadData.pushCallbackBeanO(this);
				pushedCallbackBeanO = true;
				this.entityBean.unsetEntityContext();
			} catch (Exception var7) {
				FFDCFilter.processException(var7, "com.ibm.ejs.container.EntityBeanOImpl.destroy", "317", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "unsetEntityContext raised an exception:", var7);
				}
			} finally {
				if (pushedCallbackBeanO) {
					threadData.popCallbackBeanO();
				}

				this.destroyHandleList();
			}

			if (this.pmiBean != null) {
				this.pmiBean.beanDestroyed();
			}

		}
	}

	public final void activate(BeanId id, ContainerTx tx) throws RemoteException {
		long pmiCookie = -1L;
		boolean callPmi = true;
		BeanOCallDispatchToken smfDispatchToken = null;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (this.state == 0) {
			throw new BeanOActivationFailureException();
		} else {
			synchronized (this) {
				if (!this.cachedExclusive && !this.ivReadOnly || this.state == 1) {
					this.setState(1, 15);
					this.beanId = id;

					try {
						if (this.pmiBean != null) {
							pmiCookie = this.pmiBean.activationTime();
						}

						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallEntry("ejbActivate");
						}

						if (isZOS) {
							smfDispatchToken = this.callDispatchEventListeners(2, (BeanOCallDispatchToken) null);
						}

						this.entityBean.ejbActivate();
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallExit("ejbActivate");
						}
					} catch (RemoteException var15) {
						FFDCFilter.processException(var15, "com.ibm.ejs.container.EntityBeanOImpl.activate", "392",
								this);
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Activation failed", var15);
						}

						this.destroy();
						callPmi = false;
						throw var15;
					} finally {
						if (smfDispatchToken != null) {
							this.callDispatchEventListeners(3, smfDispatchToken);
						}

						if (this.pmiBean != null && callPmi) {
							this.pmiBean.activationTime(pmiCookie);
						}

					}

					if (!this.cachedExclusive && !this.ivReadOnly) {
						this.setState(15, 5);
					} else {
						this.ivContainerTx = tx;
						this.load(tx, false);
						this.setState(15, 4);
					}

				}
			}
		}
	}

	public void preEjbCreate() throws CreateException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "preEjbCreate");
		}

		this.inCreate = true;
		if (this.aiService != null && this.ivBMP) {
			EJBMethodInfo methodInfo = EntityHelperImpl.getEJBMethodInfo();
			this.ivAccessIntent = methodInfo.getAccessIntent(this.aiService);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "preEjbCreate");
		}

	}

	public void afterPostCreateCompletion() throws CreateException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "afterPostCreateCompletion");
		}

		this.inCreate = false;
		if (this.aiService != null && this.ivContainerTx != null && this.home.hasMethodLevelAccessIntentSet()) {
			try {
				EntityContainerTx entityContainerTx = this.getEntityContainerTx();
				entityContainerTx.cacheAccessIntent(this.beanId, this.ivAccessIntent);
			} catch (InconsistentAccessIntentException var3) {
				throw new CreateException("caught exception during create: " + var3.getMessage());
			} catch (Throwable var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.container.EntityBeanOImpl.afterPostCreateCompletion",
						"602", this);
				throw new CreateException("caught Throwable during create: " + var4.getMessage());
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "afterPostCreateCompletion");
		}

	}

	public final boolean enlist(ContainerTx tx) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "enlist : " + this);
		}

		this.ivContainerTx = tx;
		boolean result;
		switch (this.state) {
			case 0 :
				throw new BeanOActivationFailureException();
			case 2 :
				result = tx.enlist(this);
				this.setState(6);
				return result;
			case 5 :
				try {
					this.loadForEnlist(tx);
				} catch (NoSuchObjectException var4) {
					this.destroy();
					throw var4;
				} catch (RemoteException var5) {
					FFDCFilter.processException(var5, "com.ibm.ejs.container.EntityBeanOImpl.enlist", "457", this);
					this.destroy();
					throw var5;
				}
			case 4 :
			case 12 :
				result = tx.enlist(this);
				this.setState(6);
				return result;
			case 6 :
				if (!this.cachedExclusive && !this.ivReadOnly) {
					return false;
				} else {
					if (this.aiService != null) {
						this.ivAccessIntent = this.home.hasMethodLevelAccessIntentSet()
								? this.getEntityContainerTx().getCachedAccessIntent(this.beanId)
								: EntityHelperImpl.getBeanLevelAccessIntent(this.home);
						if (this.ivAccessIntent == null) {
							try {
								this.setAccessIntent();
								if (this.cachedExclusive && this.ivAccessIntent.getConcurrencyControl() == 2) {
									throw new EJBException(
											"Optimistic concurrency not allowed with EJB commit option A");
								}
							} catch (InconsistentAccessIntentException var6) {
								FFDCFilter.processException(var6, "com.ibm.ejs.container.EntityBeanOImpl.enlist", "732",
										this);
								if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
									Tr.debug(tc, "EntityBeanO.enlist: " + var6);
								}

								throw new RemoteException(var6.getMessage(), var6);
							}
						}
					}

					if (this.invalid && this.ivReadOnly) {
						this.loadForEnlist(tx);
						this.invalid = false;
					}

					result = tx.enlist(this);
					if (result) {
						this.enlistForOptionA(tx);
					}

					return result;
				}
			case 7 :
				if (this.ivReadOnly) {
					if (this.aiService != null) {
						this.ivAccessIntent = this.home.hasMethodLevelAccessIntentSet()
								? this.getEntityContainerTx().getCachedAccessIntent(this.beanId)
								: EntityHelperImpl.getBeanLevelAccessIntent(this.home);
						if (this.ivAccessIntent == null) {
							try {
								this.setAccessIntent();
							} catch (InconsistentAccessIntentException var7) {
								FFDCFilter.processException(var7, "com.ibm.ejs.container.EntityBeanOImpl.enlist", "891",
										this);
								if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
									Tr.debug(tc, "EntityBeanO.enlist: " + var7);
								}

								throw new RemoteException(var7.getMessage(), var7);
							}
						}
					}

					result = tx.enlist(this);
					if (result) {
						this.enlistForOptionA(tx);
					}

					return result;
				}
			case 1 :
			case 3 :
			case 9 :
			case 11 :
			default :
				if (this.cachedExclusive) {
					return tx.enlist(this);
				} else {
					if (this.ivReadOnly && this.state == 15) {
						throw new BeanOActivationFailureException();
					}

					throw new InvalidBeanOStateException(this.getStateName(this.state),
							"OptA | CACHED_SHARED | HYDRATING CACHED_EXCLUSIVE | CREATING");
				}
			case 8 :
				result = tx.enlist(this);
				this.setState(6);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "committingEnlist", this);
				}

				return result;
			case 10 :
				return false;
		}
	}

	public void enlistForOptionA(ContainerTx tx) {
	}

	public void preFind() throws RemoteException {
		this.setState(1, 13);
		this.beanId = null;
	}

	public void postFind() throws RemoteException {
		this.ivContainerTx = null;
		this.ivAccessIntent = null;
		this.setState(13, 1);
	}

	public void preHomeMethodCall() {
		this.beanId = null;
	}

	public void postHomeMethodCall() {
	}

	public Object preInvoke(EJSDeployedSupport s, ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "preInvoke");
		}

		if (this.removed) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "preInvoke");
			}

			throw new NoSuchObjectException("");
		} else {
			if (this.invalid) {
				this.load(tx, false);
				this.invalid = false;
			}

			synchronized (this) {
				if (this.state == 7) {
					int id = s.methodId;
					if (!this.reentrant && id != -1 && id != -2 && id != -3) {
						if (isTraceOn && tc.isEntryEnabled()) {
							Tr.exit(tc, "preInvoke");
						}

						throw new BeanNotReentrantException(StateStrs[this.state]);
					}
				} else {
					if (this.state != 6) {
						this.waitUntilActive();
					}

					this.setState(6, 7);
				}

				++this.callDepth;
				if (!s.methodInfo.readOnlyAttr) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Bean marked dirty");
					}

					this.dirty = true;
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "preInvoke");
			}

			return this.entityBean;
		}
	}

	public final synchronized void postInvoke(int id, EJSDeployedSupport s) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "postInvoke");
		}

		if (this.state == 0) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "postInvoke");
			}

		} else {
			--this.callDepth;
			if (this.callDepth == 0) {
				this.setState(7, 6);
			}

			if (this.callDepth < 0) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "postInvoke");
				}

				throw new IllegalStateException();
			} else {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "postInvoke");
				}

			}
		}
	}

	public synchronized void beforeCompletion() throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "beforeCompletion", this);
		}

		if (this.ivReadOnly) {
			if (this.discarded) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "beforeCompletion: Discarded ReadOnly Bean... marking tran for rollback");
				}

				this.container.getActiveContainerTx().setRollbackOnly();
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "beforeCompletion: ReadOnly Bean... no action");
			}

		} else {
			switch (this.state) {
				case 0 :
				case 7 :
				case 8 :
					return;
				case 1 :
				case 2 :
				case 3 :
				case 4 :
				case 5 :
				default :
					throw new InvalidBeanOStateException(this.getStateName(this.state),
							"ACTIVE | IN_METHOD | DESTROYED");
				case 6 :
					this.store();
					this.setState(8);
			}
		}
	}

	public synchronized void commit(ContainerTx tx) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "commit", this);
		}

		this.ivContainerTx = null;
		this.ivAccessIntent = null;
		if (this.cachedExclusive) {
			switch (this.state) {
				case 7 :
					return;
				case 8 :
					this.setState(6);
					return;
				default :
					throw new InvalidBeanOStateException(this.getStateName(this.state), "COMMITTING | IN_METHOD");
			}
		} else if (this.ivReadOnly) {
			switch (this.state) {
				case 6 :
				case 7 :
					return;
				default :
					throw new InvalidBeanOStateException(this.getStateName(this.state), "ACTIVE | IN_METHOD");
			}
		} else {
			this.setState(8, 5);
		}
	}

	public synchronized void rollback(ContainerTx tx) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "rollback", this);
		}

		this.ivContainerTx = null;
		this.ivAccessIntent = null;
		switch (this.state) {
			case 0 :
				break;
			case 1 :
			case 2 :
			case 3 :
			case 4 :
			case 5 :
			default :
				throw new InvalidBeanOStateException(this.getStateName(this.state),
						"COMMITTING | ACTIVE | IN_METHOD | DESTROYED");
			case 6 :
			case 8 :
				if (this.cachedExclusive) {
					this.invalid = true;
					this.setState(6);
				} else if (this.ivReadOnly) {
					this.setState(6, 6);
				} else {
					this.setState(5);
				}
				break;
			case 7 :
				if (this.cachedExclusive) {
					this.invalid = true;
					this.setState(6);
				} else if (!this.ivReadOnly) {
					this.discard();
				}
		}

	}

	public final synchronized void passivate() throws RemoteException {
		boolean exception = false;
		long pmiCookie = -1L;
		BeanOCallDispatchToken smfDispatchToken = null;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "passivate", this);
		}

		if (this.state != 0) {
			if (this.removed && this.callDepth > 0) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "remove in reentrant method : destroying instead");
				}

				this.destroy();
			} else {
				EJBThreadData threadData = null;
				boolean popContexts = false;

				try {
					if (!this.cachedExclusive && !this.ivReadOnly) {
						if (this.state != 5 && !this.removed) {
							throw new InvalidBeanOStateException(this.getStateName(this.state),
									"CACHED_SHARED | removed");
						}
					} else if (this.state != 6 && this.state != 4) {
						throw new InvalidBeanOStateException(this.getStateName(this.state),
								"ACTIVE | CACHED_EXCLUSIVE");
					}

					if (!this.removed) {
						if (this.pmiBean != null) {
							pmiCookie = this.pmiBean.passivationTime();
						}

						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallEntry("ejbPassivate");
						}

						if (isZOS) {
							smfDispatchToken = this.callDispatchEventListeners(10, (BeanOCallDispatchToken) null);
						}

						threadData = EJSContainer.getThreadData();
						threadData.pushContexts(this);
						popContexts = true;
						this.entityBean.ejbPassivate();
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallExit("ejbPassivate");
						}
					}

					this.setState(1);
					this.ivContainerTx = null;
					this.ivAccessIntent = null;
				} catch (Throwable var12) {
					FFDCFilter.processException(var12, "com.ibm.ejs.container.EntityBeanOImpl.passivate", "834", this);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Exception occurred calling ejbPassivate", var12);
					}

					exception = true;
					pmiCookie = -1L;
					ExceptionUtil.logException(tc, var12, (EJBMethodMetaData) null, this);
					throw new RemoteException("Exception occurred in ejbPassivate", var12);
				} finally {
					if (popContexts) {
						threadData.popContexts();
					}

					if (smfDispatchToken != null) {
						this.callDispatchEventListeners(11, smfDispatchToken);
					}

					if (!this.removed && this.pmiBean != null) {
						this.pmiBean.passivationTime(pmiCookie);
					}

					if (!exception) {
						this.removed = false;
						this.dirty = false;
						this.beanId = null;
						this.setCMP11LoadedForUpdate(false);
						this.beanPool.put(this);
					} else {
						this.destroy();
					}

				}

			}
		}
	}

	public synchronized void remove() throws RemoteException, RemoveException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "remove");
		}

		this.assertState(7);
		if (this.removed) {
			throw new NoSuchObjectException("");
		} else {
			this.dirty = false;
			if (this.aiService != null && this.ivBMP && this.home.hasMethodLevelAccessIntentSet()) {
				try {
					EJBMethodInfo methodInfo = EntityHelperImpl.getEJBMethodInfo();
					AccessIntent ai = methodInfo.getAccessIntent(this.aiService);
					EntityContainerTx entityContainerTx = this.getEntityContainerTx();
					entityContainerTx.cacheAccessIntent(this.beanId, ai);
				} catch (InconsistentAccessIntentException var5) {
					throw new RemoveException("caught exception during remove: " + var5.getMessage());
				} catch (Throwable var6) {
					FFDCFilter.processException(var6, "com.ibm.ejs.container.EntityBeanOImpl.remove", "1187", this);
					throw new RemoveException("caught Throwable during remove: " + var6.getMessage());
				}
			}

			if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceEJBCallEntry("ejbRemove");
			}

			try {
				this.entityBean.ejbRemove();
			} catch (EJBException var7) {
				if (var7 instanceof WsNestedException) {
					Throwable cause = var7.getCause();
					if (cause instanceof RemoveException) {
						throw (RemoveException) cause;
					}

					FFDCFilter.processException(var7, "com.ibm.ejs.container.EntityBeanOImpl.remove", "1190", this);
				}

				throw var7;
			}

			if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceEJBCallExit("ejbRemove");
			}

			this.removed = true;
			if (this.pmiBean != null) {
				this.pmiBean.beanRemoved();
			}

			if (this.home.beanMetaData.isTimedObject) {
				this.container.getEJBRuntime().removeTimers(this);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "remove");
			}

		}
	}

	public synchronized void discard() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "discard", this);
		}

		this.discarded = true;
		this.ivContainerTx = null;
		this.ivAccessIntent = null;
		if (this.ivReadOnly && this.ivCacheKey != null) {
			((TimeoutKey) this.ivCacheKey).setDiscarded();
		}

		this.setState(0);
		this.destroyHandleList();
		if (this.pmiBean != null) {
			this.pmiBean.beanDiscarded();
			this.pmiBean.discardCount();
			this.pmiBean.beanDestroyed();
		}

	}

	public void invalidate() {
		if (!this.cachedExclusive) {
			this.invalid = true;
		}

	}

	public Object getBeanInstance() {
		return this.entityBean;
	}

	public Object[] getInterceptors() {
		return null;
	}

	public void checkTimerServiceAccess() throws IllegalStateException {
		if (this.state != 7 && this.state != 3 && this.state != 10 && this.state != 6) {
			IllegalStateException ise = new IllegalStateException(
					"EntityBean: Timer Service methods not allowed from state = " + this.getStateName(this.state));
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerServiceAccess: " + ise);
			}

			throw ise;
		}
	}

	public EJBObject getEJBObject() {
		EJBObject result = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getEJBObject", this.getStateName(this.state));
		}

		if (this.beanId == null) {
			throw new IllegalStateException();
		} else {
			synchronized (this) {
				if (this.state == 14) {
					throw new IllegalStateException();
				}
			}

			try {
				result = this.container.wrapperManager.getWrapper(this.beanId).getRemoteWrapper();
				EJBObject result = (EJBObject) PortableRemoteObject.toStub(result);
				return result;
			} catch (IllegalStateException var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.container.EntityBeanOImpl.getEJBObject", "992", this);
				throw var4;
			} catch (Exception var5) {
				FFDCFilter.processException(var5, "com.ibm.ejs.container.EntityBeanOImpl.getEJBObject", "997", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getEJBObject() failed", var5);
				}

				throw new IllegalStateException();
			}
		}
	}

	public EJBLocalObject getEJBLocalObject() {
		EJBLocalObject result = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getEJBLocalObject", this.getStateName(this.state));
		}

		if (this.beanId == null) {
			throw new IllegalStateException();
		} else {
			synchronized (this) {
				if (this.state == 14) {
					throw new IllegalStateException();
				}
			}

			try {
				result = this.container.wrapperManager.getWrapper(this.beanId).getLocalObject();
				return result;
			} catch (IllegalStateException var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.container.EntityBeanOImpl.getEJBLocalObject", "1034",
						this);
				throw var4;
			} catch (Throwable var5) {
				FFDCFilter.processException(var5, "com.ibm.ejs.container.EntityBeanOImpl.getEJBLocalObject", "1041",
						this);
				ContainerEJBException cex = new ContainerEJBException("getEJBLocalObject() failed", var5);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var5, cex.toString()});
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getEJBLocalObject() failed", var5);
				}

				throw cex;
			}
		}
	}

	public Object getPrimaryKey() {
		if (this.beanId == null) {
			throw new IllegalStateException();
		} else {
			synchronized (this) {
				if (this.state == 14) {
					throw new IllegalStateException();
				}
			}

			return this.beanId.getPrimaryKey();
		}
	}

	public void setRollbackOnly() {
		synchronized (this) {
			if (this.state == 14 || this.state == 15 || this.state == 0) {
				throw new IllegalStateException(
						"setRollbackOnly not allowed from " + StateStrs[this.state] + " state.");
			}
		}

		super.setRollbackOnly();
	}

	public boolean getRollbackOnly() {
		synchronized (this) {
			if (this.state == 14 || this.state == 15 || this.state == 0) {
				throw new IllegalStateException(
						"getRollbackOnly not allowed from " + StateStrs[this.state] + " state.");
			}
		}

		return super.getRollbackOnly();
	}

	public Principal getCallerPrincipal() {
		synchronized (this) {
			if (this.state == 14 || this.state == 0) {
				throw new IllegalStateException();
			}
		}

		return super.getCallerPrincipal();
	}

	public boolean isCallerInRole(String roleName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCallerInRole, role = " + roleName + ", state = " + StateStrs[this.state]);
		}

		EnterpriseBean bean = null;
		synchronized (this) {
			if (this.state == 14 || this.state == 0) {
				throw new IllegalStateException();
			}

			if (this.state == 7) {
				bean = this.entityBean;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isCallerInRole");
		}

		return super.isCallerInRole(roleName, bean);
	}

	public TimerService getTimerService() throws IllegalStateException {
		if (this.state != 14 && this.state != 0 && this.state != 13) {
			return super.getTimerService();
		} else {
			IllegalStateException ise = new IllegalStateException(
					"EntityBean: getTimerService not allowed from state = " + this.getStateName(this.state));
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getTimerService: " + ise);
			}

			throw ise;
		}
	}

	public Map<String, Object> getContextData() {
		IllegalStateException ise = new IllegalStateException(
				"EntityBean: getContextData not allowed from state = " + this.getStateName(this.state));
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getContextData: " + ise);
		}

		throw ise;
	}

	public void flushCache() {
		if (this.state != 14 && this.state != 0 && this.state != 15 && this.state != 11) {
			super.flushCache();
		} else {
			IllegalStateException ise = new IllegalStateException(
					"EntityBean: flushCache not allowed from state = " + this.getStateName(this.state));
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "flushCache: " + ise);
			}

			throw ise;
		}
	}

	public void ensurePersistentState(ContainerTx tx) throws RemoteException {
	}

	public void setCMP11LoadedForUpdate(boolean loadForUpdate) {
	}

	protected void setCMP11LoadedForUpdate(EJSDeployedSupport s, ContainerTx ctx) {
	}

	AccessIntent getCachedAccessIntent() throws CSITransactionRolledbackException {
		if (this.ivContainerTx == null) {
			this.ivContainerTx = this.container.getCurrentContainerTx();
		}

		EntityContainerTx entityContainerTx = this.getEntityContainerTx();
		return entityContainerTx.getCachedAccessIntent(this.beanId);
	}

	void setAccessIntent() throws InconsistentAccessIntentException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (this.home.hasMethodLevelAccessIntentSet()) {
			EJBMethodInfo methodInfo = EntityHelperImpl.getEJBMethodInfo();
			this.ivAccessIntent = methodInfo.getAccessIntent(this.aiService);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "setAccessIntent: method level AI: " + methodInfo.getMethodSignature());
			}

			if (this.beanId != null) {
				EntityContainerTx entityContainerTx = this.getEntityContainerTx();
				entityContainerTx.cacheAccessIntent(this.beanId, this.ivAccessIntent);
			}
		} else {
			this.ivAccessIntent = EntityHelperImpl.getBeanLevelAccessIntent(this.home);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "setAccessIntent: bean level AI: " + this.beanId);
			}
		}

		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, EntityHelperImpl.getAccessIntentString(this.ivAccessIntent));
		}

	}

	protected abstract void load(ContainerTx var1, boolean var2) throws RemoteException;

	protected abstract void loadForEnlist(ContainerTx var1) throws RemoteException;

	protected EntityContainerTx getEntityContainerTx() {
		return (EntityContainerTx) this.ivContainerTx;
	}
}