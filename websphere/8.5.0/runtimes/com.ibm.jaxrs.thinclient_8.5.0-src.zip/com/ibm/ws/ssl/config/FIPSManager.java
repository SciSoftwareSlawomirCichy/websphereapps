package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.websphere.ssl.SSLException;
import com.ibm.ws.ssl.JSSEProviderFactory;
import com.ibm.ws.ssl.core.Constants;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class FIPSManager {
	private static final TraceComponent tc = Tr.register(FIPSManager.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private static FIPSManager thisClass = null;
	private boolean fipsEnabled = false;
	private boolean fips140_2Enabled = false;
	private String fipsLevel = "";
	private String suiteBLevel = "";
	private boolean initialized = false;

	public static FIPSManager getInstance() {
		if (thisClass == null) {
			thisClass = new FIPSManager();
		}

		return thisClass;
	}

	public void initializeFIPS() throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeFips");
		}

		try {
			this.readWASPropertiesForFips();
			FIPSUtils.setJavaPropsForFips(this.fipsEnabled, this.fipsLevel, this.suiteBLevel);
			FIPSUtils.setSecurityProviders(this.fipsEnabled, this.fipsLevel, this.suiteBLevel);
			if (this.fipsEnabled && FIPSUtils.isFips140_2Enabled(this.fipsEnabled, this.fipsLevel, this.suiteBLevel)) {
				this.checkDefaultProviderListFromJavaSecurity();
				JSSEProviderFactory.initializeFips();
			}

			this.initialized = true;
		} catch (Exception var2) {
			Tr.debug(tc, "Exception initializing FIPS.", new Object[]{var2});
			Manager.Ffdc.log(var2, this, "com.ibm.ws.ssl.config.FIPSManager.initializeFIPS", "135", new Object[]{this});
			throw new SSLException(var2);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initializeFips");
		}

	}

	public boolean isFIPSEnabled() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isFIPSEnabled");
		}

		if (!this.initialized) {
			Tr.debug(tc, "FIPS parameters are not initialized yet.");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isFIPSEnabled -> " + this.fipsEnabled);
		}

		return this.fipsEnabled;
	}

	public String getFipsLevel() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getFipsLevel");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getFipsLevel -> " + this.fipsEnabled);
		}

		return this.fipsLevel;
	}

	public String getSuiteBLevel() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSuiteBLevel");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSuiteBLevel -> " + this.suiteBLevel);
		}

		return this.suiteBLevel;
	}

	protected void readWASPropertiesForFips() {
		this.fipsEnabled = FIPSUtils.checkFipsEnabled();
		this.fipsLevel = FIPSUtils.checkFipsLevel();
		this.suiteBLevel = FIPSUtils.checkSuiteBLevel();
		this.fips140_2Enabled = FIPSUtils.isFips140_2Enabled(this.fipsEnabled, this.fipsLevel, this.suiteBLevel);
		SSLConfigManager sslcm = SSLConfigManager.getInstance();
		if (sslcm.isServerProcess()) {
			if (this.fipsEnabled) {
				Tr.info(tc, "ssl.fips.enabled.CWPKI0012I");
			}

			int securityMode = FIPSUtils.getFipsSecurityMode(this.fipsEnabled, this.fipsLevel, this.suiteBLevel);
			Tr.info(tc, "ssl.fips.enabled.CWPKI0044I", new Object[]{Constants.securityModeName[securityMode]});
		}

	}

	private void checkDefaultProviderListFromJavaSecurity() {
		BufferedReader in = null;
		String s = null;
		String javaSecurityFile = null;
		boolean fipsFound = false;
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkDefaultProviderListFromJavaSecurity");
		}

		javaSecurityFile = this.getJavaSecurityFile();

		try {
			in = new BufferedReader(new FileReader(javaSecurityFile));

			while ((s = in.readLine()) != null) {
				if (!s.trim().startsWith("#") && s.trim().length() > 0 && s.trim().startsWith("security.provider")) {
					if (s.indexOf("com.ibm.crypto.fips.provider.IBMJCEFIPS") != -1) {
						fipsFound = true;
					}

					if (s.indexOf("com.ibm.crypto.provider.IBMJCE") != -1) {
						if (!fipsFound && this.fips140_2Enabled) {
							Tr.warning(tc, "ssl.checkProviderList.warning.CWPKI0013W");
							if (tc.isEntryEnabled()) {
								Tr.debug(tc,
										"In FIPS mode, IBMJCEFIPS provider is not found before the IBMJCE provider in the java.security file.");
							}
						}
						break;
					}
				}
			}
		} catch (FileNotFoundException var16) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "FileNotFoundException caught for " + javaSecurityFile);
			}
		} catch (Exception var17) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception caught: " + var17.getMessage());
			}
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception var15) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception caught: " + var15.getMessage());
				}
			}

		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "checkDefaultProviderListFromJavaSecurity");
		}

	}

	protected String getJavaSecurityFile() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getJavaSecurityFile");
		}

		String javaSecurityFile = null;
		if (System.getProperty("security.overridePropertiesFile") != null
				&& System.getProperty("security.overridePropertiesFile").equalsIgnoreCase("true")) {
			javaSecurityFile = System.getProperty("java.security.properties");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Overriding default java.security with java.security.properties= "
						+ System.getProperty("java.security.properties"));
			}
		}

		if (javaSecurityFile == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Find default java.security file");
			}

			if (System.getProperty("os.name").equals("OS/400")) {
				javaSecurityFile = System.getProperty("user.install.root") + File.separator + "properties"
						+ File.separator + "java.security";
			} else {
				String javaHome = System.getProperty("java.home");
				javaSecurityFile = javaHome + File.separator + "lib" + File.separator + "security" + File.separator
						+ "java.security";
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getJavaSecurityFile " + javaSecurityFile);
		}

		return javaSecurityFile;
	}
}