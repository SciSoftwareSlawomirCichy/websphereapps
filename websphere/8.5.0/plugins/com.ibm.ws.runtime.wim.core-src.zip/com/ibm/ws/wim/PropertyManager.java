package com.ibm.ws.wim;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.util.DomainManagerUtils;
import commonj.sdo.Type;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

public class PropertyManager {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;
	private static Map<String, PropertyManager> singleton;
	HashMap propCache = null;
	RepositoryPropertyMap lookAsidePropNames = null;
	RepositoryPropertyMap referenceTypePropNames = null;

	public static synchronized PropertyManager singleton() throws WIMException {
		String var0 = DomainManagerUtils.getDomainId();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new PropertyManager());
		}

		return (PropertyManager) singleton.get(var0);
	}

	public static void clearCache(String var0) {
		singleton.put(var0, (Object) null);
	}

	private PropertyManager() {
		this.propCache = new HashMap();
		this.lookAsidePropNames = new RepositoryPropertyMap();
		this.referenceTypePropNames = new RepositoryPropertyMap();
	}

	public void setPropertyMapByRepository(String var1, RepositoryPropertyMap var2) {
		if (var1 != null && var2 != null) {
			this.propCache.put(var1, var2);
		}

	}

	public RepositoryPropertyMap getPropertyMapByRepositoryId(String var1) {
		return var1 != null ? (RepositoryPropertyMap) this.propCache.get(var1) : null;
	}

	public Set getRepositoryPropertyNameSet(String var1, String var2) {
		if (var1 != null && var2 != null) {
			RepositoryPropertyMap var3 = (RepositoryPropertyMap) this.propCache.get(var1);
			return var3 != null ? var3.getRepositoryPropertySetByEntityType(var2) : null;
		} else {
			return null;
		}
	}

	public Set getRepositoryPropertyNameSet(String var1, Type var2) throws WIMException {
		if (var2 != null) {
			String var3 = SchemaManager.singleton().getQualifiedTypeName(var2);
			return this.getRepositoryPropertyNameSet(var1, var3);
		} else {
			return null;
		}
	}

	public Set getRepositoryPropertyNameSet(String var1, List var2) {
		if (var1 != null) {
			RepositoryPropertyMap var3 = (RepositoryPropertyMap) this.propCache.get(var1);
			return this.getPropertyNameSet(var3, var2);
		} else {
			return null;
		}
	}

	public RepositoryPropertyMap getLookAsidePropertyNameMap() {
		return this.lookAsidePropNames;
	}

	public RepositoryPropertyMap getReferenceTypePropertyNameMap() {
		return this.referenceTypePropNames;
	}

	public void setReferenceTypePropertyNameMap(RepositoryPropertyMap var1) {
		this.referenceTypePropNames = var1;
	}

	public void setLookAsidePropertyNameMap(RepositoryPropertyMap var1) {
		this.lookAsidePropNames = var1;
	}

	public Set getLookAsidePropertyNameSet(List var1) {
		return this.getPropertyNameSet(this.lookAsidePropNames, var1);
	}

	public Set getReferenceTypePropertyNameSet(List var1) {
		return this.getPropertyNameSet(this.referenceTypePropNames, var1);
	}

	private Set getPropertyNameSet(RepositoryPropertyMap var1, List var2) {
		HashSet var3 = null;
		if (var1 != null) {
			Object var4 = null;
			if (var2 == null) {
				var4 = var1.getEntityTypes();
			} else {
				var4 = new HashSet();

				for (int var5 = 0; var5 < var2.size(); ++var5) {
					((Set) var4).add(var2.get(var5));
				}
			}

			if (((Set) var4).size() > 0) {
				var3 = new HashSet();
				Iterator var8 = ((Set) var4).iterator();

				while (var8.hasNext()) {
					String var6 = (String) var8.next();
					if (var1 != null) {
						Set var7 = var1.getRepositoryPropertySetByEntityType(var6);
						if (var7 != null) {
							var3.addAll(var7);
						}
					}
				}
			}
		}

		return var3;
	}

	public Set getLookAsidePropertyNameSet(String var1) {
		Set var2 = null;
		if (this.lookAsidePropNames != null && var1 != null) {
			var2 = this.lookAsidePropNames.getRepositoryPropertySetByEntityType(var1);
		}

		return var2;
	}

	public Set getLookAsidePropertyNameSet(Type var1) throws WIMException {
		Set var2 = null;
		if (var1 != null) {
			String var3 = SchemaManager.singleton().getQualifiedTypeName(var1);
			var2 = this.getLookAsidePropertyNameSet(var3);
		}

		return var2;
	}

	public Set getReferencePropertyNameSet(String var1) {
		Set var2 = null;
		if (this.referenceTypePropNames != null && var1 != null) {
			var2 = this.referenceTypePropNames.getRepositoryPropertySetByEntityType(var1);
		}

		return var2;
	}

	public Set getReferencePropertyNameSet(Type var1) throws WIMException {
		Set var2 = null;
		if (var1 != null) {
			String var3 = SchemaManager.singleton().getQualifiedTypeName(var1);
			var2 = this.getReferencePropertyNameSet(var3);
		}

		return var2;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = PropertyManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
	}
}