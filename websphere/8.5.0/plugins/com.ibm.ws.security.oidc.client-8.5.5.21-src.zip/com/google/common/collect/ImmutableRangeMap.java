package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList.Builder;
import com.google.common.collect.ImmutableRangeMap.1;
import com.google.common.collect.ImmutableRangeMap.2;
import com.google.common.collect.ImmutableRangeMap.SerializedForm;
import com.google.common.collect.SortedLists.KeyAbsentBehavior;
import com.google.common.collect.SortedLists.KeyPresentBehavior;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Beta
@GwtIncompatible
public class ImmutableRangeMap<K extends Comparable<?>, V> implements RangeMap<K, V>, Serializable {
	private static final ImmutableRangeMap<Comparable<?>, Object> EMPTY = new ImmutableRangeMap(ImmutableList.of(),
			ImmutableList.of());
	private final transient ImmutableList<Range<K>> ranges;
	private final transient ImmutableList<V> values;
	private static final long serialVersionUID = 0L;

	public static <K extends Comparable<?>, V> ImmutableRangeMap<K, V> of() {
		return EMPTY;
	}

	public static <K extends Comparable<?>, V> ImmutableRangeMap<K, V> of(Range<K> range, V value) {
		return new ImmutableRangeMap(ImmutableList.of(range), ImmutableList.of(value));
	}

	public static <K extends Comparable<?>, V> ImmutableRangeMap<K, V> copyOf(RangeMap<K, ? extends V> rangeMap) {
		if (rangeMap instanceof ImmutableRangeMap) {
			return (ImmutableRangeMap) rangeMap;
		} else {
			Map<Range<K>, ? extends V> map = rangeMap.asMapOfRanges();
			Builder<Range<K>> rangesBuilder = new Builder(map.size());
			Builder<V> valuesBuilder = new Builder(map.size());
			Iterator var4 = map.entrySet().iterator();

			while (var4.hasNext()) {
				Entry<Range<K>, ? extends V> entry = (Entry) var4.next();
				rangesBuilder.add(entry.getKey());
				valuesBuilder.add(entry.getValue());
			}

			return new ImmutableRangeMap(rangesBuilder.build(), valuesBuilder.build());
		}
	}

	public static <K extends Comparable<?>, V> com.google.common.collect.ImmutableRangeMap.Builder<K, V> builder() {
		return new com.google.common.collect.ImmutableRangeMap.Builder();
	}

	ImmutableRangeMap(ImmutableList<Range<K>> ranges, ImmutableList<V> values) {
		this.ranges = ranges;
		this.values = values;
	}

	@NullableDecl
	public V get(K key) {
		int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), Cut.belowValue(key),
				KeyPresentBehavior.ANY_PRESENT, KeyAbsentBehavior.NEXT_LOWER);
		if (index == -1) {
			return null;
		} else {
			Range<K> range = (Range) this.ranges.get(index);
			return range.contains(key) ? this.values.get(index) : null;
		}
	}

	@NullableDecl
	public Entry<Range<K>, V> getEntry(K key) {
		int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), Cut.belowValue(key),
				KeyPresentBehavior.ANY_PRESENT, KeyAbsentBehavior.NEXT_LOWER);
		if (index == -1) {
			return null;
		} else {
			Range<K> range = (Range) this.ranges.get(index);
			return range.contains(key) ? Maps.immutableEntry(range, this.values.get(index)) : null;
		}
	}

	public Range<K> span() {
		if (this.ranges.isEmpty()) {
			throw new NoSuchElementException();
		} else {
			Range<K> firstRange = (Range) this.ranges.get(0);
			Range<K> lastRange = (Range) this.ranges.get(this.ranges.size() - 1);
			return Range.create(firstRange.lowerBound, lastRange.upperBound);
		}
	}

	@Deprecated
	public void put(Range<K> range, V value) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public void putCoalescing(Range<K> range, V value) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public void putAll(RangeMap<K, V> rangeMap) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public void clear() {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public void remove(Range<K> range) {
		throw new UnsupportedOperationException();
	}

	public ImmutableMap<Range<K>, V> asMapOfRanges() {
		if (this.ranges.isEmpty()) {
			return ImmutableMap.of();
		} else {
			RegularImmutableSortedSet<Range<K>> rangeSet = new RegularImmutableSortedSet(this.ranges,
					Range.rangeLexOrdering());
			return new ImmutableSortedMap(rangeSet, this.values);
		}
	}

	public ImmutableMap<Range<K>, V> asDescendingMapOfRanges() {
		if (this.ranges.isEmpty()) {
			return ImmutableMap.of();
		} else {
			RegularImmutableSortedSet<Range<K>> rangeSet = new RegularImmutableSortedSet(this.ranges.reverse(),
					Range.rangeLexOrdering().reverse());
			return new ImmutableSortedMap(rangeSet, this.values.reverse());
		}
	}

	public ImmutableRangeMap<K, V> subRangeMap(Range<K> range) {
      if (((Range)Preconditions.checkNotNull(range)).isEmpty()) {
         return of();
      } else if (!this.ranges.isEmpty() && !range.encloses(this.span())) {
         int lowerIndex = SortedLists.binarySearch(this.ranges, Range.upperBoundFn(), range.lowerBound, KeyPresentBehavior.FIRST_AFTER, KeyAbsentBehavior.NEXT_HIGHER);
         int upperIndex = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), range.upperBound, KeyPresentBehavior.ANY_PRESENT, KeyAbsentBehavior.NEXT_HIGHER);
         if (lowerIndex >= upperIndex) {
            return of();
         } else {
            int len = upperIndex - lowerIndex;
            ImmutableList<Range<K>> subRanges = new 1(this, len, lowerIndex, range);
            return new 2(this, subRanges, this.values.subList(lowerIndex, upperIndex), range, this);
         }
      } else {
         return this;
      }
   }

	public int hashCode() {
		return this.asMapOfRanges().hashCode();
	}

	public boolean equals(@NullableDecl Object o) {
		if (o instanceof RangeMap) {
			RangeMap<?, ?> rangeMap = (RangeMap) o;
			return this.asMapOfRanges().equals(rangeMap.asMapOfRanges());
		} else {
			return false;
		}
	}

	public String toString() {
		return this.asMapOfRanges().toString();
	}

	Object writeReplace() {
		return new SerializedForm(this.asMapOfRanges());
	}
}