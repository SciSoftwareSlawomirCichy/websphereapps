package com.ibm.ejs.cm;

import com.ibm.ejs.cm.logger.TraceWriter;
import com.ibm.ejs.cm.pool.ConnectionFactory;
import com.ibm.ejs.cm.pool.ConnectionPool;
import com.ibm.ejs.cm.pool.JTAConnectionFactory;
import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.cm.portability.PortabilityLayerFactory;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.Transaction.XAResourceInfo;
import java.io.PrintWriter;
import java.io.Writer;
import java.sql.SQLException;
import javax.sql.XADataSource;

class JDBC2PhaseRF extends DataSourceImpl {
	protected String xaResourceFactoryName;
	protected XAResourceInfo xaResourceInfo;
	private static final TraceComponent tc = Tr.register(JDBC2PhaseRF.class);

	JDBC2PhaseRF(CMProperties attrs) {
		super(attrs);
	}

	protected ConnectionFactory createConnectionFactory() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createConnectionFactory");
		}

		DataSourceProperties dsProps = this.attrs.getDataSourceProperties();
		PortabilityLayer pbl = PortabilityLayerFactory.getPortabilityLayer(dsProps);
		XADataSource ds = pbl.getXADataSource(dsProps);
		Writer w = new TraceWriter("jta." + this.attrs.getName());
		if (((TraceWriter) w).isTraceEnabled()) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Setting DataSource PrintWriter");
			}

			ds.setLogWriter(new PrintWriter(w));
		}

		ConnectionFactory factory = new JTAConnectionFactory(ds);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createConnectionFactory", factory);
		}

		return factory;
	}

	public void initialize(XAResourceInfo info, String xaResourceFactoryName) {
		this.xaResourceInfo = info;
		this.xaResourceFactoryName = xaResourceFactoryName;
	}

	public final synchronized ConnectionPool getSource() throws SQLException {
		if (this.source == null) {
			this.source = new ConnectionPool(this.createConnectionFactory(), this.attrs, this.xaResourceFactoryName,
					this.xaResourceInfo, this.attrs.getPassword());
		}

		return this.source;
	}
}