package com.ibm.ejs.cm.pool;

import com.ibm.ejs.util.QueueElement;

class Waiter extends QueueElement {
	private boolean wokeUpOnNotify;
	protected Thread t;

	protected Waiter() {
	}

	protected Waiter(Thread t) {
		this.t = t;
	}

	public void setWokeUpOnNotify(boolean value) {
		this.wokeUpOnNotify = value;
	}

	public boolean getWokeUpOnNotify() {
		return this.wokeUpOnNotify;
	}

	public void removeFromQueue() {
		if (this.queue != null) {
			this.queue.remove(this);
		}

	}

	protected Thread getThread() {
		return this.t;
	}
}