package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.CMProperties;
import java.sql.SQLException;
import javax.sql.DataSource;

public interface PortableDataSource extends DataSource {
	PortabilityLayerExt getPortabilityLayer() throws SQLException;

	CMProperties getAttributes();
}