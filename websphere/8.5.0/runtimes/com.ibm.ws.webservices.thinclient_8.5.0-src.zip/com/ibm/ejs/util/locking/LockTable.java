package com.ibm.ejs.util.locking;

public final class LockTable {
	private Object[] locks;

	public LockTable(int size) {
		this.locks = new Object[size];

		for (int i = 0; i < size; ++i) {
			this.locks[i] = new Object();
		}

	}

	public LockTable(int size, LockObjectFactory lf) {
		this.locks = new Object[size];

		for (int i = 0; i < size; ++i) {
			this.locks[i] = lf.getNewLockObject();
		}

	}

	public Object getLock(Object key) {
		return this.locks[(key.hashCode() & Integer.MAX_VALUE) % this.locks.length];
	}
}