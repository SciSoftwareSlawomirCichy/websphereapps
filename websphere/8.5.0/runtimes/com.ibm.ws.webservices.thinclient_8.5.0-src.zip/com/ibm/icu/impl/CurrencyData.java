package com.ibm.icu.impl;

import com.ibm.icu.impl.CurrencyData.1;
import com.ibm.icu.impl.CurrencyData.CurrencyDisplayInfoProvider;

public class CurrencyData {
	public static final CurrencyDisplayInfoProvider provider;

	static {
      Object temp = null;

      try {
         Class<?> clzz = Class.forName("com.ibm.icu.impl.ICUCurrencyDisplayInfoProvider");
         temp = (CurrencyDisplayInfoProvider)clzz.newInstance();
      } catch (Throwable var2) {
         temp = new 1();
      }

      provider = (CurrencyDisplayInfoProvider)temp;
   }
}