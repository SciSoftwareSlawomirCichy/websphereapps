package com.ibm.ws.wim.security.authz.jacc;

import com.ibm.sec.authz.jaccx.resource.Resource;
import com.ibm.sec.authz.jaccx.resource.ResourceContextHandler;
import com.ibm.ws.wim.security.authz.AccessHandler;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import javax.security.auth.Subject;

class ResourceContextHandlerImpl implements ResourceContextHandler {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String KEY_PREFIX = "com.ibm.websphere.wim.Entity.";
	private Set supportedKeys;
	private Set referencedAttrs = new HashSet();
	private AccessHandler accessHandler;

	public ResourceContextHandlerImpl(Set var1, AccessHandler var2) {
		this.supportedKeys = var1;
		this.accessHandler = var2;
		Iterator var4 = var1.iterator();

		while (var4.hasNext()) {
			String var3;
			if ((var3 = (String) var4.next()).startsWith("com.ibm.websphere.wim.Entity.")) {
				this.referencedAttrs.add(var3.substring("com.ibm.websphere.wim.Entity.".length()));
			}
		}

	}

	public String[] getAttributeNames() {
		return (String[]) ((String[]) this.supportedKeys.toArray(new String[this.supportedKeys.size()]));
	}

	public boolean supports(String var1) {
		return this.supportedKeys.contains(var1);
	}

	public Object getAttribute(Resource var1, String var2, Object var3) {
		Object var6 = null;
		if (var2.equals("is-owner")) {
			Subject var5 = (Subject) var3;
			Set var4 = this.accessHandler.getSubjectRelationships(var5, var1);
			return var4.contains("Owner") ? Boolean.TRUE : Boolean.FALSE;
		} else {
			if (var2.startsWith("com.ibm.websphere.wim.Entity.")) {
				var6 = this.accessHandler.getResourceAttribute(var1,
						var2.substring("com.ibm.websphere.wim.Entity.".length()), this.referencedAttrs);
			}

			return var6;
		}
	}
}