package com.google.common.base;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Suppliers.ExpiringMemoizingSupplier;
import com.google.common.base.Suppliers.MemoizingSupplier;
import com.google.common.base.Suppliers.SupplierComposition;
import com.google.common.base.Suppliers.SupplierFunction;
import com.google.common.base.Suppliers.SupplierOfInstance;
import com.google.common.base.Suppliers.ThreadSafeSupplier;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

@GwtCompatible
public final class Suppliers {
	public static <F, T> Supplier<T> compose(Function<? super F, T> function, Supplier<F> supplier) {
		Preconditions.checkNotNull(function);
		Preconditions.checkNotNull(supplier);
		return new SupplierComposition(function, supplier);
	}

	public static <T> Supplier<T> memoize(Supplier<T> delegate) {
		return (Supplier) (delegate instanceof MemoizingSupplier
				? delegate
				: new MemoizingSupplier((Supplier) Preconditions.checkNotNull(delegate)));
	}

	public static <T> Supplier<T> memoizeWithExpiration(Supplier<T> delegate, long duration, TimeUnit unit) {
		return new ExpiringMemoizingSupplier(delegate, duration, unit);
	}

	public static <T> Supplier<T> ofInstance(@Nullable T instance) {
		return new SupplierOfInstance(instance);
	}

	public static <T> Supplier<T> synchronizedSupplier(Supplier<T> delegate) {
		return new ThreadSafeSupplier((Supplier) Preconditions.checkNotNull(delegate));
	}

	@Beta
	public static <T> Function<Supplier<T>, T> supplierFunction() {
		return SupplierFunction.INSTANCE;
	}
}