package com.ibm.ejs.cm.proxy;

import java.sql.CallableStatement;

public class OracleCallableStatementProxy extends CallableStatementProxy {
	OracleCallableStatementProxy(OracleConnectionProxy parent, CallableStatement statement) {
		super(parent, statement);
	}
}