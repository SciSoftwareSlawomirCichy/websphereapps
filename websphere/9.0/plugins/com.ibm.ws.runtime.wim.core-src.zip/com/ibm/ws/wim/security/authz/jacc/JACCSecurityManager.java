package com.ibm.ws.wim.security.authz.jacc;

import com.ibm.sec.auth.subjectx.SubjectAttributes;
import com.ibm.sec.auth.subjectx.VirtualPrincipal;
import com.ibm.sec.authz.jaccx.DefaultEvaluationContext;
import com.ibm.sec.authz.jaccx.EntitlementPolicy;
import com.ibm.sec.authz.jaccx.EvaluationContext;
import com.ibm.sec.authz.jaccx.condition.AttributeName;
import com.ibm.sec.authz.jaccx.condition.RequestContext;
import com.ibm.sec.authz.jaccx.resource.Resource;
import com.ibm.sec.authz.jaccx.resource.ResourceContext;
import com.ibm.sec.authz.jaccx.role.RoleAssignmentCondition;
import com.ibm.sec.authz.jaccx.role.RoleCondition;
import com.ibm.sec.authz.jaccx.role.RoleMapping;
import com.ibm.sec.authz.jaccx.role.RoleMappingConfigurationFactory;
import com.ibm.sec.authz.jaccx.role.RoleMappingContext;
import com.ibm.sec.authz.jaccx.role.RoleMappingContextFactory;
import com.ibm.sec.authz.provider.CommonAuthzPolicy;
import com.ibm.sec.authz.provider.CommonAuthzPolicyConfigurationFactory;
import com.ibm.sec.authz.provider.CommonAuthzRoleMapping;
import com.ibm.sec.authz.provider.CommonAuthzRoleMappingConfigurationFactory;
import com.ibm.sec.authz.provider.MethodPermission;
import com.ibm.sec.authz.provider.config.CommonAuthzConfiguration;
import com.ibm.websphere.security.WSSecurityException;
import com.ibm.websphere.security.auth.CredentialDestroyedException;
import com.ibm.websphere.security.cred.WSCredential;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.security.authz.AuthSystemException;
import com.ibm.websphere.wim.security.authz.Entitlement;
import com.ibm.ws.security.auth.SubjectHelper;
import com.ibm.ws.security.core.ContextManager;
import com.ibm.ws.security.core.ContextManagerFactory;
import com.ibm.ws.wim.security.authz.AccessHandler;
import com.ibm.ws.wim.security.authz.EntitlementHelper;
import com.ibm.ws.wim.security.authz.jacc.JACCSecurityManager.1;
import com.ibm.ws.wim.security.authz.jacc.JACCSecurityManager.2;
import java.security.AccessController;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Policy;
import java.security.Principal;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.Subject;
import javax.security.auth.login.CredentialExpiredException;
import javax.security.jacc.PolicyConfigurationFactory;
import javax.security.jacc.PolicyContextException;

public class JACCSecurityManager {
	static final String COPYRIGHT_NOTICE;
	public static final String AUTHZ_HOME_DIR = "commonauthz.home";
	public static final String JACC_SUBJECT_KEY = "javax.security.auth.Subject.container";
	public static final String REQUEST_PREFIX = "com.ibm.websphere.wim.Context.";
	public static final String SUBJECT_PREFIX = "com.ibm.websphere.wim.Subject.";
	public static final String RESOURCE_PREFIX = "com.ibm.websphere.wim.Entity.";
	public static final String ATTRVALUE_NON_APPLICABLE = "$NON-APPLICABLE$";
	private static final String CLASSNAME;
	private static final Logger msgLogger;
	private static final Logger trcLogger;
	private Properties authzProps;
	private Object policy;
	private Object roleMapping;
	private Object policyConfigFactory;
	private Object roleMappingConfigFactory;
	private String policyContextId;
	private String appContextId;
	private RequestContext requestContext;
	private SubjectAttributes subjectAttributes;
	private ResourceContext resourceContext;
	private AccessHandler accessHandler;
	private Subject superUserSubject = new Subject();
	private static ThreadLocal runAsSubject;

	public JACCSecurityManager() {
		trcLogger.entering(CLASSNAME, "JACCSecurityManager()");
		trcLogger.exiting(CLASSNAME, "JACCSecurityManager()");
	}

	public JACCSecurityManager(String var1, String var2, String var3, String var4, String var5)
			throws AuthSystemException {
		trcLogger.entering(CLASSNAME, "JACCSecurityManager(...)");

		try {
			if (var5 == null) {
				var5 = System.getProperty("commonauthz.home");
			}

			trcLogger.log(Level.FINER, "Loading Argus config settings...");
			CommonAuthzConfiguration var6 = new CommonAuthzConfiguration(var5);
			this.authzProps = var6.getProperties();
			trcLogger.log(Level.FINER, "Initializing Argus Policy classes...");
			this.policy = new CommonAuthzPolicy(this.authzProps);
			this.policyConfigFactory = new CommonAuthzPolicyConfigurationFactory(this.authzProps);
			trcLogger.log(Level.FINER, "Initializing Argus RoleMapping classes...");
			this.roleMapping = new CommonAuthzRoleMapping(this.authzProps);
			this.roleMappingConfigFactory = new CommonAuthzRoleMappingConfigurationFactory(this.authzProps);
		} catch (Exception var7) {
			throw new AuthSystemException("AUTH_INIT_FAILURE", var7, Level.SEVERE);
		}

		trcLogger.exiting(CLASSNAME, "JACCSecurityManager(...)");
	}

	public void registerPolicy(String var1, String var2, AccessHandler var3) throws AuthSystemException {
		trcLogger.entering(CLASSNAME, "registerPolicy()");

		try {
			this.policyContextId = var1;
			this.appContextId = var2;
			this.accessHandler = var3;
			this.refreshPolicy();
			this.createContextHandlers();
		} catch (Exception var5) {
			throw new AuthSystemException("AUTH_INIT_FAILURE", var5, Level.SEVERE);
		}

		trcLogger.exiting(CLASSNAME, "registerPolicy()");
	}

	public void refreshPolicy() {
		trcLogger.entering(CLASSNAME, "refreshPolicy()");
		this.getPolicy().refresh();
		this.getRoleMapping().refresh();
		trcLogger.exiting(CLASSNAME, "refreshPolicy()");
	}

	private String getSubjectName(Subject var1) {
		return this.accessHandler.getSubjectPrincipal(var1).getName();
	}

	private Subject getServerSubject() throws WSSecurityException {
		return ContextManagerFactory.getInstance().getServerSubject();
	}

	private boolean isCallerServerSubject(Subject var1, Subject var2)
			throws CredentialDestroyedException, CredentialExpiredException {
		trcLogger.entering(CLASSNAME, "isCallerServerSubject()");
		boolean var3 = false;
		WSCredential var6 = SubjectHelper.getWSCredentialFromSubject(var1);
		WSCredential var7 = SubjectHelper.getWSCredentialFromSubject(var2);
		if (var7 != null && var7.isCurrent() && var6 != null && !var6.isUnauthenticated() && var6.isCurrent()) {
			String var4 = var6.getRealmUniqueSecurityName();
			String var5 = var7.getRealmUniqueSecurityName();
			if (var4 != null && var4.equals(var5)) {
				var3 = true;
			}
		}

		trcLogger.exiting(CLASSNAME, "isCallerServerSubject()");
		return var3;
	}

	private boolean isCallerAdministrator(Subject var1) throws WSSecurityException {
      trcLogger.entering(CLASSNAME, "isCallerAdministrator()");
      boolean var2 = false;
      Subject var3 = var1;

      Boolean var4;
      try {
         var4 = (Boolean)AccessController.doPrivileged(new 1(this, var3));
      } catch (PrivilegedActionException var6) {
         throw (WSSecurityException)var6.getException();
      }

      var2 = var4;
      trcLogger.exiting(CLASSNAME, "isCallerAdministrator()");
      return var2;
   }

	public boolean isServerSecurityEnabled() {
		trcLogger.entering(CLASSNAME, "isServerSecurityEnabled()");
		boolean var1 = true;

		try {
			ContextManager var2 = ContextManagerFactory.getInstance();
			var1 = var2.getServerSubject() != null && var2.isServerSubjectCreated();
		} catch (Exception var3) {
			trcLogger.log(Level.FINE, var3.getMessage(), var3);
		}

		trcLogger.exiting(CLASSNAME, "isServerSecurityEnabled() - " + var1);
		return var1;
	}

	public boolean isSuperUser(Subject var1) throws AuthSystemException {
		trcLogger.entering(CLASSNAME, "isSuperUser()");
		boolean var2 = this.superUserSubject.equals(runAsSubject.get());

		try {
			if (this.isServerSecurityEnabled()) {
				if (var2 = this.isCallerAdministrator(var1)) {
					trcLogger.log(Level.FINER, "The caller is running as the **WAS ADMINISTRATOR**");
				} else {
					trcLogger.log(Level.FINER, "The caller is NOT running as the WAS ADMINISTRATOR");
				}
			}
		} catch (WSSecurityException var6) {
			trcLogger.log(Level.FINE, "Skipping administrator role check: " + var6.getMessage());
		} catch (Exception var7) {
			throw new AuthSystemException("AUTH_CHECK_FAILURE", new Object[]{this.getSubjectName(var1)}, var7,
					Level.SEVERE);
		}

		if (var2) {
			trcLogger.log(Level.FINER, "The caller will be granted **SUPER USER** status");
		}

		trcLogger.exiting(CLASSNAME, "isSuperUser()");
		return var2;
	}

	public Object runAsSuperUser(PrivilegedExceptionAction var1) throws PrivilegedActionException {
		trcLogger.entering(CLASSNAME, "runAsSuperUser()");
		Subject var2 = (Subject) runAsSubject.get();
		runAsSubject.set(this.superUserSubject);

		Object var3;
		try {
			if (this.isServerSecurityEnabled()) {
				var3 = ContextManagerFactory.getInstance().runAsSystem(var1);
			} else {
				try {
					var3 = var1.run();
				} catch (Exception var8) {
					throw new PrivilegedActionException(var8);
				}
			}
		} finally {
			runAsSubject.set(var2);
		}

		trcLogger.exiting(CLASSNAME, "runAsSuperUser()");
		return var3;
	}

	public Set getRoles(Subject var1, Resource var2) throws AuthSystemException {
		trcLogger.entering(CLASSNAME, "getRoles()");
		HashSet var4 = new HashSet();

		try {
			EvaluationContext var5 = this.createEvaluationContext(var1, var2);
			Iterator var3 = this.getRoleMapping().getRoles(this.getRoleMappingContext(), var5);

			while (var3.hasNext()) {
				var4.add(var3.next());
			}
		} catch (Exception var7) {
			throw new AuthSystemException("AUTH_CHECK_FAILURE", new Object[]{this.getSubjectName(var1)}, var7,
					Level.SEVERE);
		}

		trcLogger.exiting(CLASSNAME, "getRoles()");
		return var4;
	}

	public Set getRoles(Subject var1) throws AuthSystemException {
		trcLogger.entering(CLASSNAME, "getRoles(subject)");
		HashSet var3 = new HashSet();

		try {
			Set var4 = this.accessHandler.getSubjectGroups(var1);
			var4.add(this.accessHandler.getSubjectPrincipal(var1));
			var4.add(VirtualPrincipal.AllAuthenticatedUsers);
			Iterator var5 = var4.iterator();

			while (var5.hasNext()) {
				Principal var6 = (Principal) var5.next();
				Iterator var2 = this.getRoleMapping().getRoleConditions(this.getRoleMappingContext(), var6);

				while (var2.hasNext()) {
					RoleCondition var7 = (RoleCondition) var2.next();
					if (var7 instanceof RoleAssignmentCondition) {
						var3.add(var7.getRole());
					}
				}
			}
		} catch (Exception var8) {
			throw new AuthSystemException("AUTH_CHECK_FAILURE", new Object[]{this.getSubjectName(var1)}, var8,
					Level.SEVERE);
		}

		trcLogger.exiting(CLASSNAME, "getRoles(subject)", var3);
		return var3;
	}

	public boolean doesEntitlementExist(Subject var1, Resource var2, Entitlement var3) throws AuthSystemException {
		trcLogger.entering(CLASSNAME, "doesEntitlementExist()");

		boolean var4;
		try {
			EvaluationContext var5 = this.createEvaluationContext(var1, var2);
			var4 = this.getRoleMapping().hasPermissionAtOrUnderneath(this.policyContextId, var5,
					EntitlementHelper.getMethodPermission(var3));
		} catch (Exception var7) {
			throw new AuthSystemException("AUTH_CHECK_FAILURE", new Object[]{this.getSubjectName(var1)}, var7,
					Level.SEVERE);
		}

		trcLogger.exiting(CLASSNAME, "doesEntitlementExist()");
		return var4;
	}

	public boolean hasEntitlement(Subject var1, Resource var2, Entitlement var3) throws AuthSystemException {
      trcLogger.entering(CLASSNAME, "hasEntitlement()");
      Subject var6 = var1;
      Entitlement var7 = var3;

      boolean var4;
      try {
         if (this.isSuperUser(var1)) {
            trcLogger.exiting(CLASSNAME, "hasEntitlement()");
            return true;
         }

         EvaluationContext var5 = this.createEvaluationContext(var1, var2);
         Boolean var8 = (Boolean)AccessController.doPrivileged(new 2(this, var6, var5, var7));
         var4 = var8;
      } catch (Exception var9) {
         throw new AuthSystemException("AUTH_CHECK_FAILURE", new Object[]{this.getSubjectName(var1)}, var9, Level.SEVERE);
      }

      trcLogger.exiting(CLASSNAME, "hasEntitlement()");
      return var4;
   }

	public Set getEntitlements(Subject var1, Resource var2) throws AuthSystemException {
		trcLogger.entering(CLASSNAME, "getEntitlements()");
		HashSet var6 = new HashSet();

		try {
			EvaluationContext var5 = this.createEvaluationContext(var1, var2);
			PermissionCollection var4 = this.getRoleMapping().getPermissions(this.policyContextId, var5);
			Enumeration var7 = var4.elements();

			while (var7.hasMoreElements()) {
				Permission var3;
				if ((var3 = (Permission) var7.nextElement()) instanceof MethodPermission) {
					var6.add(EntitlementHelper.getEntitlement((MethodPermission) var3));
				}
			}
		} catch (Exception var8) {
			throw new AuthSystemException("AUTH_CHECK_FAILURE", new Object[]{this.getSubjectName(var1)}, var8,
					Level.SEVERE);
		}

		trcLogger.exiting(CLASSNAME, "getEntitlements()");
		return var6;
	}

	private void createContextHandlers() throws ClassNotFoundException, PolicyContextException {
		trcLogger.entering(CLASSNAME, "createContextHandlers()");
		HashSet var1 = new HashSet();
		HashSet var2 = new HashSet();
		HashSet var3 = new HashSet();
		HashSet var4 = new HashSet();
		var4.addAll(((EntitlementPolicy) this.getPolicy()).getReferencedAttributeNames(this.policyContextId));
		var4.addAll(this.getRoleMapping().getReferencedAttributeNames(this.getRoleMappingContext()));
		Iterator var9 = var4.iterator();

		while (var9.hasNext()) {
			AttributeName var5 = (AttributeName) var9.next();
			if (var5.getSource() == 2 && var5.getAttributeName().startsWith("com.ibm.websphere.wim.Context.")) {
				var1.add(var5.getAttributeName());
			}

			if (var5.getSource() == 1 && var5.getAttributeName().startsWith("com.ibm.websphere.wim.Subject.")) {
				var2.add(var5.getAttributeName());
			}

			if (var5.getSource() == 3 && var5.getAttributeName().startsWith("com.ibm.websphere.wim.Entity.")) {
				var3.add(var5.getAttributeName());
			}
		}

		this.requestContext = new RequestContext();
		RequestContextHandlerImpl var6 = new RequestContextHandlerImpl(var1);
		var9 = var1.iterator();

		while (var9.hasNext()) {
			this.requestContext.registerHandler((String) var9.next(), var6, true);
		}

		var2.add("user");
		var2.add("group");
		this.subjectAttributes = new SubjectAttributes();
		SubjectAttributesHandlerImpl var7 = new SubjectAttributesHandlerImpl(var2, this.accessHandler);
		var9 = var2.iterator();

		while (var9.hasNext()) {
			this.subjectAttributes.registerHandler((String) var9.next(), var7, true);
		}

		var3.add("is-owner");
		this.resourceContext = new ResourceContext();
		ResourceContextHandlerImpl var8 = new ResourceContextHandlerImpl(var3, this.accessHandler);
		var9 = var3.iterator();

		while (var9.hasNext()) {
			this.resourceContext.registerHandler((String) var9.next(), var8, true);
		}

		trcLogger.exiting(CLASSNAME, "createContextHandlers()");
	}

	private EvaluationContext createEvaluationContext(Subject var1, Resource var2) throws PolicyContextException {
		trcLogger.entering(CLASSNAME, "createEvaluationContext()");
		DefaultEvaluationContext var3 = new DefaultEvaluationContext();
		PolicyContextHandlerImpl var4 = new PolicyContextHandlerImpl(var1, var2, this.requestContext,
				this.subjectAttributes, this.resourceContext);
		var3.registerHandler("javax.security.auth.Subject.container", var4, true);
		var3.registerHandler(Resource.JACC_RESOURCE_KEY, var4, true);
		var3.registerHandler(RequestContext.JACC_REQUEST_CONTEXT_KEY, var4, true);
		var3.registerHandler(SubjectAttributes.JACC_SUBJECT_ATTRIBUTES_KEY, var4, true);
		var3.registerHandler(ResourceContext.JACC_RESOURCE_CONTEXT_KEY, var4, true);
		this.requestContext.setHandlerData(this.accessHandler.getContextParameters(var2));
		this.accessHandler.clearThreadCache();
		trcLogger.exiting(CLASSNAME, "createEvaluationContext()");
		return var3;
	}

	protected Policy getPolicy() {
		return this.policy == null ? Policy.getPolicy() : (Policy) this.policy;
	}

	protected RoleMapping getRoleMapping() {
		return this.roleMapping == null ? RoleMapping.getRoleMapping() : (RoleMapping) this.roleMapping;
	}

	protected PolicyConfigurationFactory getPolicyConfigFactory()
			throws ClassNotFoundException, PolicyContextException {
		return this.policyConfigFactory == null
				? PolicyConfigurationFactory.getPolicyConfigurationFactory()
				: (PolicyConfigurationFactory) this.policyConfigFactory;
	}

	protected RoleMappingConfigurationFactory getRoleMappingConfigFactory() throws PolicyContextException {
		return this.roleMappingConfigFactory == null
				? RoleMappingConfigurationFactory.getRoleMappingConfigurationFactory()
				: (RoleMappingConfigurationFactory) this.roleMappingConfigFactory;
	}

	protected RoleMappingContext getRoleMappingContext() throws PolicyContextException, ClassNotFoundException {
		return ((RoleMappingContextFactory) this.getPolicy()).getRoleMappingContext(this.policyContextId);
	}

	protected RoleMappingContext getRoleMappingContext(String var1)
			throws PolicyContextException, ClassNotFoundException {
		return ((RoleMappingContextFactory) this.getPolicy()).getRoleMappingContext(var1);
	}

	public boolean isAdministrator(Subject var1) throws WIMException {
		Iterator var2 = this.getRoles(var1).iterator();

		String var3;
		do {
			if (!var2.hasNext()) {
				return false;
			}

			var3 = (String) var2.next();
		} while (!var3.equals("IdMgrAdmin"));

		return true;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = JACCSecurityManager.class.getName();
		msgLogger = WIMLogger.getMessageLogger("com.ibm.ws.wim.security.authz");
		trcLogger = WIMLogger.getTraceLogger("com.ibm.ws.wim.security.authz");
		runAsSubject = new ThreadLocal();
	}
}