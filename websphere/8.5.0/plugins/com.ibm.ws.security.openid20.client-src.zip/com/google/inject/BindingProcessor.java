package com.google.inject;

import com.google.inject.BindingProcessor.1;
import com.google.inject.BindingProcessor.CreationListener;
import com.google.inject.internal.Annotations;
import com.google.inject.internal.BindingImpl;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ExposedBindingImpl;
import com.google.inject.internal.ImmutableSet;
import com.google.inject.internal.Lists;
import com.google.inject.internal.ProviderMethod;
import com.google.inject.internal.Scoping;
import com.google.inject.internal.UntargettedBindingImpl;
import com.google.inject.spi.PrivateElements;
import com.google.inject.spi.ProviderInstanceBinding;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

class BindingProcessor extends AbstractProcessor {
	private final List<CreationListener> creationListeners = Lists.newArrayList();
	private final Initializer initializer;
	private final List<Runnable> uninitializedBindings = Lists.newArrayList();
	private static final Set<Class<?>> FORBIDDEN_TYPES = ImmutableSet
			.of(new Class[]{AbstractModule.class, Binder.class, Binding.class, Injector.class, Key.class,
					MembersInjector.class, Module.class, Provider.class, Scope.class, TypeLiteral.class});

	BindingProcessor(Errors errors, Initializer initializer) {
		super(errors);
		this.initializer = initializer;
	}

	public <T> Boolean visit(Binding<T> command) {
      Object source = command.getSource();
      if (!Void.class.equals(command.getKey().getRawType())) {
         Key<T> key = command.getKey();
         Class<? super T> rawType = key.getTypeLiteral().getRawType();
         if (rawType == Provider.class) {
            this.errors.bindingToProvider();
            return true;
         } else {
            this.validateKey(command.getSource(), command.getKey());
            Scoping scoping = Scopes.makeInjectable(((BindingImpl)command).getScoping(), this.injector, this.errors);
            command.acceptTargetVisitor(new 1(this, source, key, scoping));
            return true;
         }
      } else {
         if (command instanceof ProviderInstanceBinding && ((ProviderInstanceBinding)command).getProviderInstance() instanceof ProviderMethod) {
            this.errors.voidProviderMethod();
         } else {
            this.errors.missingConstantValues();
         }

         return true;
      }
   }

	public Boolean visit(PrivateElements privateElements) {
		Iterator i$ = privateElements.getExposedKeys().iterator();

		while (i$.hasNext()) {
			Key<?> key = (Key) i$.next();
			this.bindExposed(privateElements, key);
		}

		return false;
	}

	private <T> void bindExposed(PrivateElements privateElements, Key<T> key) {
		ExposedKeyFactory<T> exposedKeyFactory = new ExposedKeyFactory(key, privateElements);
		this.creationListeners.add(exposedKeyFactory);
		this.putBinding(new ExposedBindingImpl(this.injector, privateElements.getExposedSource(key), key,
				exposedKeyFactory, privateElements));
	}

	private <T> void validateKey(Object source, Key<T> key) {
		Annotations.checkForMisplacedScopeAnnotations(key.getRawType(), source, this.errors);
	}

	<T> UntargettedBindingImpl<T> invalidBinding(InjectorImpl injector, Key<T> key, Object source) {
		return new UntargettedBindingImpl(injector, key, source);
	}

	public void initializeBindings() {
		Iterator i$ = this.uninitializedBindings.iterator();

		while (i$.hasNext()) {
			Runnable initializer = (Runnable) i$.next();
			initializer.run();
		}

	}

	public void runCreationListeners() {
		Iterator i$ = this.creationListeners.iterator();

		while (i$.hasNext()) {
			CreationListener creationListener = (CreationListener) i$.next();
			creationListener.notify(this.errors);
		}

	}

	private void putBinding(BindingImpl<?> binding) {
		Key<?> key = binding.getKey();
		Class<?> rawType = key.getRawType();
		if (FORBIDDEN_TYPES.contains(rawType)) {
			this.errors.cannotBindToGuiceType(rawType.getSimpleName());
		} else {
			Binding<?> original = this.injector.state.getExplicitBinding(key);
			if (original != null && !this.isOkayDuplicate(original, binding)) {
				this.errors.bindingAlreadySet(key, original.getSource());
			} else {
				this.injector.state.parent().blacklist(key);
				this.injector.state.putBinding(key, binding);
			}
		}
	}

	private boolean isOkayDuplicate(Binding<?> original, BindingImpl<?> binding) {
		if (original instanceof ExposedBindingImpl) {
			ExposedBindingImpl exposed = (ExposedBindingImpl) original;
			InjectorImpl exposedFrom = (InjectorImpl) exposed.getPrivateElements().getInjector();
			return exposedFrom == binding.getInjector();
		} else {
			return false;
		}
	}
}