package com.ibm.ejs.csi;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.StatefulBeanReaper;
import com.ibm.ejs.container.activator.StatefulSessionActivationStrategy;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.csi.FileBeanStore.1;
import com.ibm.ejs.csi.FileBeanStore.2;
import com.ibm.ejs.csi.FileBeanStore.3;
import com.ibm.ejs.csi.FileBeanStore.4;
import com.ibm.ejs.csi.FileBeanStore.5;
import com.ibm.ejs.csi.FileBeanStore.FileBeanFilter;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.SessionBeanStore;
import com.ibm.websphere.csi.StreamUnavailableException;
import com.ibm.ws.ffdc.FFDCFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class FileBeanStore implements SessionBeanStore {
	private static final TraceComponent tc = Tr.register(FileBeanStore.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = FileBeanStore.class.getName();
	private static final String FILENAME_PREFIX = "BeanId_";
	private String passivationDir;
	private String serverName;
	private String clusterName;

	public FileBeanStore(String passivationDir) {
		this(passivationDir, "NoServer", (String) null);
	}

	public FileBeanStore(String passivationDir, String serverName, String clusterName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", new Object[]{passivationDir, serverName, clusterName});
		}

		if (passivationDir != null && (new File(passivationDir)).isDirectory()) {
			this.passivationDir = passivationDir;
		} else {
			this.passivationDir = null;
			if (passivationDir != null) {
				Tr.warning(tc, "PASSIVATION_DIRECTORY_DOES_NOT_EXIST_CNTR0023W", passivationDir);
			}
		}

		this.serverName = serverName;
		this.clusterName = clusterName;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void removeAll() {
      boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.entry(tc, "removeAll");
      }

      FileBeanFilter theFilter = new FileBeanFilter(this, (1)null);
      File[] files = (new File(this.passivationDir == null ? "." : this.passivationDir)).listFiles(theFilter);
      if (files != null) {
         File[] arr$ = files;
         int len$ = files.length;

         for(int i$ = 0; i$ < len$; ++i$) {
            File file = arr$[i$];
            String name = file.getName();
            if (name.startsWith("BeanId_")) {
               if (file.delete()) {
                  if (isTraceOn && tc.isDebugEnabled()) {
                     Tr.debug(tc, "deleted " + name);
                  }
               } else if (isTraceOn && tc.isDebugEnabled()) {
                  Tr.debug(tc, "failed to delete " + name);
               }
            } else if (isTraceOn && tc.isDebugEnabled()) {
               Tr.debug(tc, "skipping " + name);
            }
         }
      }

      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.exit(tc, "removeAll");
      }

   }

	private File getStatefulBeanFile(String fileNamePrefix, boolean checkAll) {
		File statefulBeanFile = null;
		if (this.clusterName != null) {
			statefulBeanFile = new File(this.passivationDir, fileNamePrefix + this.clusterName);
			if (checkAll && statefulBeanFile.exists()) {
				return statefulBeanFile;
			}
		}

		statefulBeanFile = new File(this.passivationDir, fileNamePrefix + this.serverName);
		return checkAll && statefulBeanFile.exists() ? statefulBeanFile : new File(this.passivationDir, fileNamePrefix);
	}

	public GZIPInputStream getGZIPInputStream(BeanId beanId) throws CSIException {
      boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.entry(tc, "getGZIPInputStream", beanId);
      }

      String fileName = this.getPortableFilename(beanId);
      GZIPInputStream result = null;

      try {
         result = (GZIPInputStream)AccessController.doPrivileged(new 1(this, fileName));
      } catch (PrivilegedActionException var7) {
         Exception ex2 = var7.getException();
         if (ex2 instanceof FileNotFoundException) {
            FFDCFilter.processException(ex2, CLASS_NAME + ".getGZIPInputStream", "91", this);
            if (isTraceOn && tc.isEventEnabled()) {
               Tr.event(tc, "No file found while trying to activate passivated stateful session bean", fileName);
            }

            throw new StreamUnavailableException("");
         }

         if (ex2 instanceof IOException) {
            FFDCFilter.processException(ex2, CLASS_NAME + ".getGZIPInputStream", "98", this);
            Tr.warning(tc, "IOEXCEPTION_READING_FILE_FOR_STATEFUL_SESSION_BEAN_CNTR0024W", new Object[]{fileName, this, ex2});
            throw new CSIException("IOException reading input stream for stateful session bean", (IOException)ex2);
         }

         throw new CSIException("Unexpected exception reading input stream for stateful session bean", ex2);
      }

      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.exit(tc, "getGZIPInputStream");
      }

      return result;
   }

	private long getBeanTimeoutTime(BeanId beanId) {
		if (EJSPlatformHelper.isZOS()) {
			StatefulSessionActivationStrategy as = (StatefulSessionActivationStrategy) beanId.getActivationStrategy();
			StatefulBeanReaper reaper = as.getReaper();
			return reaper.getBeanTimeoutTime(beanId);
		} else {
			return 0L;
		}
	}

	public GZIPOutputStream getGZIPOutputStream(BeanId beanId) throws CSIException {
      boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.entry(tc, "getOutputStream", beanId);
      }

      String fileName = this.getPortableFilename(beanId);
      long beanTimeoutTime = this.getBeanTimeoutTime(beanId);
      GZIPOutputStream result = null;

      try {
         result = (GZIPOutputStream)AccessController.doPrivileged(new 2(this, fileName, beanTimeoutTime));
      } catch (PrivilegedActionException var9) {
         Exception ex = var9.getException();
         FFDCFilter.processException(ex, CLASS_NAME + ".getOutputStream", "127", this);
         Tr.warning(tc, "IOEXCEPTION_WRITING_FILE_FOR_STATEFUL_SESSION_BEAN_CNTR0025W", new Object[]{fileName, this, ex});
         throw new CSIException("Unable to open output stream", ex);
      }

      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.exit(tc, "getOutputStream");
      }

      return result;
   }

	public void remove(BeanId beanId) {
      String fileName = this.getPortableFilename(beanId);
      boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.entry(tc, "remove: key=" + beanId + ", file=" + fileName);
      }

      try {
         AccessController.doPrivileged(new 3(this, fileName, isTraceOn));
      } catch (PrivilegedActionException var5) {
         FFDCFilter.processException(var5.getException(), CLASS_NAME + ".remove", "150", this);
         if (isTraceOn && tc.isEventEnabled()) {
            Tr.event(tc, "Failed to remove session bean state", new Object[]{beanId, var5});
         }
      }

      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.exit(tc, "remove");
      }

   }

	private String getPortableFilename(BeanId beanId) {
		StringBuilder result = new StringBuilder();
		result.append("BeanId_");
		this.appendPortableFilenameString(result, beanId.getJ2EEName().toString());
		result.append("__");
		this.appendPortableFilenameString(result, beanId.getPrimaryKey().toString());
		result.append('_');
		return result.toString();
	}

	private void appendPortableFilenameString(StringBuilder result, String s) {
		int length = s.length();

		for (int i = 0; i < length; ++i) {
			char c = s.charAt(i);
			if (!Character.isLetterOrDigit(c) && c != '_' && c != '-' && c != '.') {
				result.append('_');
			} else {
				result.append(c);
			}
		}

	}

	public OutputStream getOutputStream(BeanId beanId) throws CSIException {
      String fileName = this.getPortableFilename(beanId);
      boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.entry(tc, "getOutputStream: key=" + beanId + ", file=", fileName);
      }

      long beanTimeoutTime = this.getBeanTimeoutTime(beanId);
      FileOutputStream result = null;

      try {
         result = (FileOutputStream)AccessController.doPrivileged(new 4(this, fileName, beanTimeoutTime));
      } catch (PrivilegedActionException var8) {
         FFDCFilter.processException(var8, CLASS_NAME + ".getUnCompressedOutputStream", "460", this);
         Tr.warning(tc, "IOEXCEPTION_WRITING_FILE_FOR_STATEFUL_SESSION_BEAN_CNTR0025W", new Object[]{fileName, this, var8});
         throw new CSIException("Unable to open output stream", var8);
      }

      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.exit(tc, "getOutputStream");
      }

      return result;
   }

	public InputStream getInputStream(BeanId beanId) throws CSIException {
      boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.entry(tc, "getInputStream", beanId);
      }

      String fileName = this.getPortableFilename(beanId);
      FileInputStream result = null;

      try {
         result = (FileInputStream)AccessController.doPrivileged(new 5(this, fileName));
      } catch (PrivilegedActionException var7) {
         Exception ex2 = var7.getException();
         if (ex2 instanceof FileNotFoundException) {
            FFDCFilter.processException(ex2, CLASS_NAME + ".getInputStream", "524", this);
            if (isTraceOn && tc.isEventEnabled()) {
               Tr.event(tc, "No file found while trying to activate passivated stateful session bean", fileName);
            }

            throw new StreamUnavailableException("");
         }

         if (ex2 instanceof IOException) {
            FFDCFilter.processException(ex2, CLASS_NAME + ".getInputStream", "531", this);
            Tr.warning(tc, "IOEXCEPTION_READING_FILE_FOR_STATEFUL_SESSION_BEAN_CNTR0024W", new Object[]{fileName, this, ex2});
            throw new CSIException("IOException reading input stream for stateful session bean", (IOException)ex2);
         }

         throw new CSIException("Unexpected exception reading input stream for stateful session bean", ex2);
      }

      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.exit(tc, "getInputStream");
      }

      return result;
   }
}