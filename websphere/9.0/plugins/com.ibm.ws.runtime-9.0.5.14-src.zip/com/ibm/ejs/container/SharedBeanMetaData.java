package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.EJBComponentMetaData;
import com.ibm.websphere.csi.EJBConfigData;
import com.ibm.websphere.csi.EJBMethodInfo;
import com.ibm.websphere.csi.GlobalTranConfigData;
import com.ibm.websphere.csi.LocalTranConfigData;
import com.ibm.websphere.csi.MethodInterface;
import com.ibm.websphere.csi.ResRefList;
import com.ibm.ws.ejbcontainer.EJBMethodInterface;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;
import com.ibm.ws.naming.java.javaNameSpace;
import java.util.List;

public class SharedBeanMetaData extends BeanMetaData implements EJBComponentMetaData {
	private static final TraceComponent tc = Tr.register(SharedBeanMetaData.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	public EJBConfigData ejbConfigData;
	public javaNameSpace ivJavaNameSpace;

	public SharedBeanMetaData(int slotSize) {
		super(slotSize);
	}

	public void setJavaNameSpace(Object jns) {
		this.ivJavaNameSpace = (javaNameSpace) jns;
	}

	public javaNameSpace getJavaNameSpace() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getJavaNameSpace: nsID=" + this.getJavaNameSpaceID() + "  :  J2EEName = " + this.j2eeName);
		}

		return this.ivJavaNameSpace;
	}

	protected int getJavaNameSpaceID() {
		return this.ivJavaNameSpace == null ? -1 : this.ivJavaNameSpace.getNameSpaceID();
	}

	public LocalTranConfigData getLocalTran() {
		return this.getLocalTranConfigData();
	}

	public LocalTranConfigData getLocalTranConfigData() {
		return (LocalTranConfigData) this._localTran;
	}

	public GlobalTranConfigData getGlobalTranConfigData() {
		return (GlobalTranConfigData) this._globalTran;
	}

	public EJBMethodInfoImpl createEJBMethodInfoImpl(int slotSize) {
		return new SharedEJBMethodInfoImpl(slotSize);
	}

	public EJBMethodInfo[] getEJBMethodMetaData(MethodInterface methodInterface) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBMethodMetaData: " + methodInterface.toString());
		}

		EJBMethodInterface ejbMethodInterface = EJBMethodInterface.forValue(methodInterface.getValue());
		List<EJBMethodMetaData> methodMetaDatas = this.getEJBMethodMetaData(ejbMethodInterface);
		EJBMethodInfo[] methodInfos = null;
		if (methodMetaDatas != null) {
			methodInfos = new EJBMethodInfo[methodMetaDatas.size()];
			methodMetaDatas.toArray(methodInfos);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEJBMethodMetaData");
		}

		return methodInfos;
	}

	public ResRefList getResourceRefList() {
		return (ResRefList) this._resourceRefList;
	}
}