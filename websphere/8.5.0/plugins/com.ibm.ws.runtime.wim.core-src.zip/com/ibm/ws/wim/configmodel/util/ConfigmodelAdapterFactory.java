package com.ibm.ws.wim.configmodel.util;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.util.ConfigmodelAdapterFactory.1;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;
import org.eclipse.emf.ecore.EObject;

public class ConfigmodelAdapterFactory extends AdapterFactoryImpl {
	protected static ConfigmodelPackage modelPackage;
	protected ConfigmodelSwitch modelSwitch = new 1(this);

	public ConfigmodelAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = ConfigmodelPackage.eINSTANCE;
		}

	}

	public boolean isFactoryForType(Object var1) {
		if (var1 == modelPackage) {
			return true;
		} else if (var1 instanceof EObject) {
			return ((EObject) var1).eClass().getEPackage() == modelPackage;
		} else {
			return false;
		}
	}

	public Adapter createAdapter(Notifier var1) {
		return (Adapter) this.modelSwitch.doSwitch((EObject) var1);
	}

	public Adapter createAttributeConfigurationTypeAdapter() {
		return null;
	}

	public Adapter createAttributeGroupTypeAdapter() {
		return null;
	}

	public Adapter createAttributesCacheTypeAdapter() {
		return null;
	}

	public Adapter createAttributeTypeAdapter() {
		return null;
	}

	public Adapter createAuthorizationTypeAdapter() {
		return null;
	}

	public Adapter createBaseEntriesTypeAdapter() {
		return null;
	}

	public Adapter createCacheConfigurationTypeAdapter() {
		return null;
	}

	public Adapter createConfigurationProviderTypeAdapter() {
		return null;
	}

	public Adapter createConnectionsTypeAdapter() {
		return null;
	}

	public Adapter createContextPoolTypeAdapter() {
		return null;
	}

	public Adapter createCustomPropertiesTypeAdapter() {
		return null;
	}

	public Adapter createDatabaseRepositoryTypeAdapter() {
		return null;
	}

	public Adapter createDocumentRootAdapter() {
		return null;
	}

	public Adapter createDynamicMemberAttributesTypeAdapter() {
		return null;
	}

	public Adapter createDynamicModelTypeAdapter() {
		return null;
	}

	public Adapter createEntryMappingRepositoryTypeAdapter() {
		return null;
	}

	public Adapter createEnvironmentPropertiesTypeAdapter() {
		return null;
	}

	public Adapter createFileRepositoryTypeAdapter() {
		return null;
	}

	public Adapter createGroupConfigurationTypeAdapter() {
		return null;
	}

	public Adapter createInlineExitAdapter() {
		return null;
	}

	public Adapter createLdapEntityTypesTypeAdapter() {
		return null;
	}

	public Adapter createLdapRepositoryTypeAdapter() {
		return null;
	}

	public Adapter createLdapServerConfigurationTypeAdapter() {
		return null;
	}

	public Adapter createLdapServersTypeAdapter() {
		return null;
	}

	public Adapter createMemberAttributesTypeAdapter() {
		return null;
	}

	public Adapter createMembershipAttributeTypeAdapter() {
		return null;
	}

	public Adapter createModificationSubscriberAdapter() {
		return null;
	}

	public Adapter createModificationSubscriberListAdapter() {
		return null;
	}

	public Adapter createNotificationSubscriberAdapter() {
		return null;
	}

	public Adapter createNotificationSubscriberListAdapter() {
		return null;
	}

	public Adapter createParticipatingBaseEntriesTypeAdapter() {
		return null;
	}

	public Adapter createPluginManagerConfigurationTypeAdapter() {
		return null;
	}

	public Adapter createPostExitAdapter() {
		return null;
	}

	public Adapter createPreExitAdapter() {
		return null;
	}

	public Adapter createProfileRepositoryTypeAdapter() {
		return null;
	}

	public Adapter createPropertiesNotSupportedTypeAdapter() {
		return null;
	}

	public Adapter createPropertyExtensionRepositoryTypeAdapter() {
		return null;
	}

	public Adapter createRdnAttributesTypeAdapter() {
		return null;
	}

	public Adapter createRealmConfigurationTypeAdapter() {
		return null;
	}

	public Adapter createRealmDefaultParentTypeAdapter() {
		return null;
	}

	public Adapter createRealmTypeAdapter() {
		return null;
	}

	public Adapter createRepositoryTypeAdapter() {
		return null;
	}

	public Adapter createSearchResultsCacheTypeAdapter() {
		return null;
	}

	public Adapter createSPIBridgeRepositoryTypeAdapter() {
		return null;
	}

	public Adapter createStaticModelTypeAdapter() {
		return null;
	}

	public Adapter createSupportedEntityTypesTypeAdapter() {
		return null;
	}

	public Adapter createTopicEmitterAdapter() {
		return null;
	}

	public Adapter createTopicRegistrationListAdapter() {
		return null;
	}

	public Adapter createTopicSubscriberAdapter() {
		return null;
	}

	public Adapter createTopicSubscriberListAdapter() {
		return null;
	}

	public Adapter createUserRegistryInfoMappingTypeAdapter() {
		return null;
	}

	public Adapter createEObjectAdapter() {
		return null;
	}
}