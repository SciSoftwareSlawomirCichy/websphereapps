package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.AuthorizationType;
import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.DynamicModelType;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.PropertyExtensionRepositoryType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.StaticModelType;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class ConfigurationProviderTypeImpl extends EDataObjectImpl implements ConfigurationProviderType {
	protected DynamicModelType dynamicModel = null;
	protected StaticModelType staticModel = null;
	protected EList supportedEntityTypes = null;
	protected EntryMappingRepositoryType entryMappingRepository = null;
	protected PropertyExtensionRepositoryType propertyExtensionRepository = null;
	protected EList repositories = null;
	protected RealmConfigurationType realmConfiguration = null;
	protected PluginManagerConfigurationType pluginManagerConfiguration = null;
	protected AuthorizationType authorization = null;
	protected static final int MAX_PAGING_RESULTS_EDEFAULT = 500;
	protected int maxPagingResults = 500;
	protected boolean maxPagingResultsESet = false;
	protected static final int MAX_SEARCH_RESULTS_EDEFAULT = 2000;
	protected int maxSearchResults = 2000;
	protected boolean maxSearchResultsESet = false;
	protected static final int MAX_TOTAL_PAGING_RESULTS_EDEFAULT = 1000;
	protected int maxTotalPagingResults = 1000;
	protected boolean maxTotalPagingResultsESet = false;
	protected static final int PAGED_CACHE_TIME_OUT_EDEFAULT = 900;
	protected int pagedCacheTimeOut = 900;
	protected boolean pagedCacheTimeOutESet = false;
	protected static final boolean PAGING_CACHES_DISK_OFF_LOAD_EDEFAULT = false;
	protected boolean pagingCachesDiskOffLoad = false;
	protected boolean pagingCachesDiskOffLoadESet = false;
	protected static final boolean PAGING_ENTITY_OBJECT_EDEFAULT = true;
	protected boolean pagingEntityObject = true;
	protected boolean pagingEntityObjectESet = false;
	protected static final String SEARCH_TIME_OUT_EDEFAULT = "600000";
	protected String searchTimeOut = "600000";
	protected boolean searchTimeOutESet = false;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getConfigurationProviderType();
	}

	public DynamicModelType getDynamicModel() {
		return this.dynamicModel;
	}

	public NotificationChain basicSetDynamicModel(DynamicModelType var1, NotificationChain var2) {
		DynamicModelType var3 = this.dynamicModel;
		this.dynamicModel = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 0, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setDynamicModel(DynamicModelType var1) {
		if (var1 != this.dynamicModel) {
			NotificationChain var2 = null;
			if (this.dynamicModel != null) {
				var2 = ((InternalEObject) this.dynamicModel).eInverseRemove(this, -1, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -1, (Class) null, var2);
			}

			var2 = this.basicSetDynamicModel(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var1, var1));
		}

	}

	public DynamicModelType createDynamicModel() {
		DynamicModelType var1 = ConfigmodelFactory.eINSTANCE.createDynamicModelType();
		this.setDynamicModel(var1);
		return var1;
	}

	public StaticModelType getStaticModel() {
		return this.staticModel;
	}

	public NotificationChain basicSetStaticModel(StaticModelType var1, NotificationChain var2) {
		StaticModelType var3 = this.staticModel;
		this.staticModel = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 1, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setStaticModel(StaticModelType var1) {
		if (var1 != this.staticModel) {
			NotificationChain var2 = null;
			if (this.staticModel != null) {
				var2 = ((InternalEObject) this.staticModel).eInverseRemove(this, -2, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -2, (Class) null, var2);
			}

			var2 = this.basicSetStaticModel(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var1, var1));
		}

	}

	public StaticModelType createStaticModel() {
		StaticModelType var1 = ConfigmodelFactory.eINSTANCE.createStaticModelType();
		this.setStaticModel(var1);
		return var1;
	}

	public SupportedEntityTypesType[] getSupportedEntityTypesAsArray() {
		List var1 = this.getSupportedEntityTypes();
		return (SupportedEntityTypesType[]) ((SupportedEntityTypesType[]) var1
				.toArray(new SupportedEntityTypesType[var1.size()]));
	}

	public List getSupportedEntityTypes() {
		if (this.supportedEntityTypes == null) {
			this.supportedEntityTypes = new EObjectContainmentEList(SupportedEntityTypesType.class, this, 2);
		}

		return this.supportedEntityTypes;
	}

	public SupportedEntityTypesType createSupportedEntityTypes() {
		SupportedEntityTypesType var1 = ConfigmodelFactory.eINSTANCE.createSupportedEntityTypesType();
		this.getSupportedEntityTypes().add(var1);
		return var1;
	}

	public EntryMappingRepositoryType getEntryMappingRepository() {
		return this.entryMappingRepository;
	}

	public NotificationChain basicSetEntryMappingRepository(EntryMappingRepositoryType var1, NotificationChain var2) {
		EntryMappingRepositoryType var3 = this.entryMappingRepository;
		this.entryMappingRepository = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 3, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setEntryMappingRepository(EntryMappingRepositoryType var1) {
		if (var1 != this.entryMappingRepository) {
			NotificationChain var2 = null;
			if (this.entryMappingRepository != null) {
				var2 = ((InternalEObject) this.entryMappingRepository).eInverseRemove(this, -4, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -4, (Class) null, var2);
			}

			var2 = this.basicSetEntryMappingRepository(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var1, var1));
		}

	}

	public EntryMappingRepositoryType createEntryMappingRepository() {
		EntryMappingRepositoryType var1 = ConfigmodelFactory.eINSTANCE.createEntryMappingRepositoryType();
		this.setEntryMappingRepository(var1);
		return var1;
	}

	public PropertyExtensionRepositoryType getPropertyExtensionRepository() {
		return this.propertyExtensionRepository;
	}

	public NotificationChain basicSetPropertyExtensionRepository(PropertyExtensionRepositoryType var1,
			NotificationChain var2) {
		PropertyExtensionRepositoryType var3 = this.propertyExtensionRepository;
		this.propertyExtensionRepository = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 4, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setPropertyExtensionRepository(PropertyExtensionRepositoryType var1) {
		if (var1 != this.propertyExtensionRepository) {
			NotificationChain var2 = null;
			if (this.propertyExtensionRepository != null) {
				var2 = ((InternalEObject) this.propertyExtensionRepository).eInverseRemove(this, -5, (Class) null,
						var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -5, (Class) null, var2);
			}

			var2 = this.basicSetPropertyExtensionRepository(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var1, var1));
		}

	}

	public PropertyExtensionRepositoryType createPropertyExtensionRepository() {
		PropertyExtensionRepositoryType var1 = ConfigmodelFactory.eINSTANCE.createPropertyExtensionRepositoryType();
		this.setPropertyExtensionRepository(var1);
		return var1;
	}

	public ProfileRepositoryType[] getRepositoriesAsArray() {
		List var1 = this.getRepositories();
		return (ProfileRepositoryType[]) ((ProfileRepositoryType[]) var1
				.toArray(new ProfileRepositoryType[var1.size()]));
	}

	public List getRepositories() {
		if (this.repositories == null) {
			this.repositories = new EObjectContainmentEList(ProfileRepositoryType.class, this, 5);
		}

		return this.repositories;
	}

	public ProfileRepositoryType createRepositories() {
		ProfileRepositoryType var1 = ConfigmodelFactory.eINSTANCE.createProfileRepositoryType();
		this.getRepositories().add(var1);
		return var1;
	}

	public RealmConfigurationType getRealmConfiguration() {
		return this.realmConfiguration;
	}

	public NotificationChain basicSetRealmConfiguration(RealmConfigurationType var1, NotificationChain var2) {
		RealmConfigurationType var3 = this.realmConfiguration;
		this.realmConfiguration = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 6, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setRealmConfiguration(RealmConfigurationType var1) {
		if (var1 != this.realmConfiguration) {
			NotificationChain var2 = null;
			if (this.realmConfiguration != null) {
				var2 = ((InternalEObject) this.realmConfiguration).eInverseRemove(this, -7, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -7, (Class) null, var2);
			}

			var2 = this.basicSetRealmConfiguration(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 6, var1, var1));
		}

	}

	public RealmConfigurationType createRealmConfiguration() {
		RealmConfigurationType var1 = ConfigmodelFactory.eINSTANCE.createRealmConfigurationType();
		this.setRealmConfiguration(var1);
		return var1;
	}

	public PluginManagerConfigurationType getPluginManagerConfiguration() {
		return this.pluginManagerConfiguration;
	}

	public NotificationChain basicSetPluginManagerConfiguration(PluginManagerConfigurationType var1,
			NotificationChain var2) {
		PluginManagerConfigurationType var3 = this.pluginManagerConfiguration;
		this.pluginManagerConfiguration = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 7, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setPluginManagerConfiguration(PluginManagerConfigurationType var1) {
		if (var1 != this.pluginManagerConfiguration) {
			NotificationChain var2 = null;
			if (this.pluginManagerConfiguration != null) {
				var2 = ((InternalEObject) this.pluginManagerConfiguration).eInverseRemove(this, -8, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -8, (Class) null, var2);
			}

			var2 = this.basicSetPluginManagerConfiguration(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 7, var1, var1));
		}

	}

	public PluginManagerConfigurationType createPluginManagerConfiguration() {
		PluginManagerConfigurationType var1 = ConfigmodelFactory.eINSTANCE.createPluginManagerConfigurationType();
		this.setPluginManagerConfiguration(var1);
		return var1;
	}

	public AuthorizationType getAuthorization() {
		return this.authorization;
	}

	public NotificationChain basicSetAuthorization(AuthorizationType var1, NotificationChain var2) {
		AuthorizationType var3 = this.authorization;
		this.authorization = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 8, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setAuthorization(AuthorizationType var1) {
		if (var1 != this.authorization) {
			NotificationChain var2 = null;
			if (this.authorization != null) {
				var2 = ((InternalEObject) this.authorization).eInverseRemove(this, -9, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -9, (Class) null, var2);
			}

			var2 = this.basicSetAuthorization(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 8, var1, var1));
		}

	}

	public AuthorizationType createAuthorization() {
		AuthorizationType var1 = ConfigmodelFactory.eINSTANCE.createAuthorizationType();
		this.setAuthorization(var1);
		return var1;
	}

	public int getMaxPagingResults() {
		return this.maxPagingResults;
	}

	public void setMaxPagingResults(int var1) {
		int var2 = this.maxPagingResults;
		this.maxPagingResults = var1;
		boolean var3 = this.maxPagingResultsESet;
		this.maxPagingResultsESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 9, var2, this.maxPagingResults, !var3));
		}

	}

	public void unsetMaxPagingResults() {
		int var1 = this.maxPagingResults;
		boolean var2 = this.maxPagingResultsESet;
		this.maxPagingResults = 500;
		this.maxPagingResultsESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 9, var1, 500, var2));
		}

	}

	public boolean isSetMaxPagingResults() {
		return this.maxPagingResultsESet;
	}

	public int getMaxSearchResults() {
		return this.maxSearchResults;
	}

	public void setMaxSearchResults(int var1) {
		int var2 = this.maxSearchResults;
		this.maxSearchResults = var1;
		boolean var3 = this.maxSearchResultsESet;
		this.maxSearchResultsESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 10, var2, this.maxSearchResults, !var3));
		}

	}

	public void unsetMaxSearchResults() {
		int var1 = this.maxSearchResults;
		boolean var2 = this.maxSearchResultsESet;
		this.maxSearchResults = 2000;
		this.maxSearchResultsESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 10, var1, 2000, var2));
		}

	}

	public boolean isSetMaxSearchResults() {
		return this.maxSearchResultsESet;
	}

	public int getMaxTotalPagingResults() {
		return this.maxTotalPagingResults;
	}

	public void setMaxTotalPagingResults(int var1) {
		int var2 = this.maxTotalPagingResults;
		this.maxTotalPagingResults = var1;
		boolean var3 = this.maxTotalPagingResultsESet;
		this.maxTotalPagingResultsESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 11, var2, this.maxTotalPagingResults, !var3));
		}

	}

	public void unsetMaxTotalPagingResults() {
		int var1 = this.maxTotalPagingResults;
		boolean var2 = this.maxTotalPagingResultsESet;
		this.maxTotalPagingResults = 1000;
		this.maxTotalPagingResultsESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 11, var1, 1000, var2));
		}

	}

	public boolean isSetMaxTotalPagingResults() {
		return this.maxTotalPagingResultsESet;
	}

	public int getPagedCacheTimeOut() {
		return this.pagedCacheTimeOut;
	}

	public void setPagedCacheTimeOut(int var1) {
		int var2 = this.pagedCacheTimeOut;
		this.pagedCacheTimeOut = var1;
		boolean var3 = this.pagedCacheTimeOutESet;
		this.pagedCacheTimeOutESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 12, var2, this.pagedCacheTimeOut, !var3));
		}

	}

	public void unsetPagedCacheTimeOut() {
		int var1 = this.pagedCacheTimeOut;
		boolean var2 = this.pagedCacheTimeOutESet;
		this.pagedCacheTimeOut = 900;
		this.pagedCacheTimeOutESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 12, var1, 900, var2));
		}

	}

	public boolean isSetPagedCacheTimeOut() {
		return this.pagedCacheTimeOutESet;
	}

	public boolean isPagingCachesDiskOffLoad() {
		return this.pagingCachesDiskOffLoad;
	}

	public void setPagingCachesDiskOffLoad(boolean var1) {
		boolean var2 = this.pagingCachesDiskOffLoad;
		this.pagingCachesDiskOffLoad = var1;
		boolean var3 = this.pagingCachesDiskOffLoadESet;
		this.pagingCachesDiskOffLoadESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 13, var2, this.pagingCachesDiskOffLoad, !var3));
		}

	}

	public void unsetPagingCachesDiskOffLoad() {
		boolean var1 = this.pagingCachesDiskOffLoad;
		boolean var2 = this.pagingCachesDiskOffLoadESet;
		this.pagingCachesDiskOffLoad = false;
		this.pagingCachesDiskOffLoadESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 13, var1, false, var2));
		}

	}

	public boolean isSetPagingCachesDiskOffLoad() {
		return this.pagingCachesDiskOffLoadESet;
	}

	public boolean isPagingEntityObject() {
		return this.pagingEntityObject;
	}

	public void setPagingEntityObject(boolean var1) {
		boolean var2 = this.pagingEntityObject;
		this.pagingEntityObject = var1;
		boolean var3 = this.pagingEntityObjectESet;
		this.pagingEntityObjectESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 14, var2, this.pagingEntityObject, !var3));
		}

	}

	public void unsetPagingEntityObject() {
		boolean var1 = this.pagingEntityObject;
		boolean var2 = this.pagingEntityObjectESet;
		this.pagingEntityObject = true;
		this.pagingEntityObjectESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 14, var1, true, var2));
		}

	}

	public boolean isSetPagingEntityObject() {
		return this.pagingEntityObjectESet;
	}

	public String getSearchTimeOut() {
		return this.searchTimeOut;
	}

	public void setSearchTimeOut(String var1) {
		String var2 = this.searchTimeOut;
		this.searchTimeOut = var1;
		boolean var3 = this.searchTimeOutESet;
		this.searchTimeOutESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 15, var2, this.searchTimeOut, !var3));
		}

	}

	public void unsetSearchTimeOut() {
		String var1 = this.searchTimeOut;
		boolean var2 = this.searchTimeOutESet;
		this.searchTimeOut = "600000";
		this.searchTimeOutESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 15, var1, "600000", var2));
		}

	}

	public boolean isSetSearchTimeOut() {
		return this.searchTimeOutESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return this.basicSetDynamicModel((DynamicModelType) null, var4);
				case 1 :
					return this.basicSetStaticModel((StaticModelType) null, var4);
				case 2 :
					return ((InternalEList) this.getSupportedEntityTypes()).basicRemove(var1, var4);
				case 3 :
					return this.basicSetEntryMappingRepository((EntryMappingRepositoryType) null, var4);
				case 4 :
					return this.basicSetPropertyExtensionRepository((PropertyExtensionRepositoryType) null, var4);
				case 5 :
					return ((InternalEList) this.getRepositories()).basicRemove(var1, var4);
				case 6 :
					return this.basicSetRealmConfiguration((RealmConfigurationType) null, var4);
				case 7 :
					return this.basicSetPluginManagerConfiguration((PluginManagerConfigurationType) null, var4);
				case 8 :
					return this.basicSetAuthorization((AuthorizationType) null, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getDynamicModel();
			case 1 :
				return this.getStaticModel();
			case 2 :
				return this.getSupportedEntityTypes();
			case 3 :
				return this.getEntryMappingRepository();
			case 4 :
				return this.getPropertyExtensionRepository();
			case 5 :
				return this.getRepositories();
			case 6 :
				return this.getRealmConfiguration();
			case 7 :
				return this.getPluginManagerConfiguration();
			case 8 :
				return this.getAuthorization();
			case 9 :
				return new Integer(this.getMaxPagingResults());
			case 10 :
				return new Integer(this.getMaxSearchResults());
			case 11 :
				return new Integer(this.getMaxTotalPagingResults());
			case 12 :
				return new Integer(this.getPagedCacheTimeOut());
			case 13 :
				return this.isPagingCachesDiskOffLoad() ? Boolean.TRUE : Boolean.FALSE;
			case 14 :
				return this.isPagingEntityObject() ? Boolean.TRUE : Boolean.FALSE;
			case 15 :
				return this.getSearchTimeOut();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setDynamicModel((DynamicModelType) var2);
				return;
			case 1 :
				this.setStaticModel((StaticModelType) var2);
				return;
			case 2 :
				this.getSupportedEntityTypes().clear();
				this.getSupportedEntityTypes().addAll((Collection) var2);
				return;
			case 3 :
				this.setEntryMappingRepository((EntryMappingRepositoryType) var2);
				return;
			case 4 :
				this.setPropertyExtensionRepository((PropertyExtensionRepositoryType) var2);
				return;
			case 5 :
				this.getRepositories().clear();
				this.getRepositories().addAll((Collection) var2);
				return;
			case 6 :
				this.setRealmConfiguration((RealmConfigurationType) var2);
				return;
			case 7 :
				this.setPluginManagerConfiguration((PluginManagerConfigurationType) var2);
				return;
			case 8 :
				this.setAuthorization((AuthorizationType) var2);
				return;
			case 9 :
				this.setMaxPagingResults((Integer) var2);
				return;
			case 10 :
				this.setMaxSearchResults((Integer) var2);
				return;
			case 11 :
				this.setMaxTotalPagingResults((Integer) var2);
				return;
			case 12 :
				this.setPagedCacheTimeOut((Integer) var2);
				return;
			case 13 :
				this.setPagingCachesDiskOffLoad((Boolean) var2);
				return;
			case 14 :
				this.setPagingEntityObject((Boolean) var2);
				return;
			case 15 :
				this.setSearchTimeOut((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setDynamicModel((DynamicModelType) null);
				return;
			case 1 :
				this.setStaticModel((StaticModelType) null);
				return;
			case 2 :
				this.getSupportedEntityTypes().clear();
				return;
			case 3 :
				this.setEntryMappingRepository((EntryMappingRepositoryType) null);
				return;
			case 4 :
				this.setPropertyExtensionRepository((PropertyExtensionRepositoryType) null);
				return;
			case 5 :
				this.getRepositories().clear();
				return;
			case 6 :
				this.setRealmConfiguration((RealmConfigurationType) null);
				return;
			case 7 :
				this.setPluginManagerConfiguration((PluginManagerConfigurationType) null);
				return;
			case 8 :
				this.setAuthorization((AuthorizationType) null);
				return;
			case 9 :
				this.unsetMaxPagingResults();
				return;
			case 10 :
				this.unsetMaxSearchResults();
				return;
			case 11 :
				this.unsetMaxTotalPagingResults();
				return;
			case 12 :
				this.unsetPagedCacheTimeOut();
				return;
			case 13 :
				this.unsetPagingCachesDiskOffLoad();
				return;
			case 14 :
				this.unsetPagingEntityObject();
				return;
			case 15 :
				this.unsetSearchTimeOut();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.dynamicModel != null;
			case 1 :
				return this.staticModel != null;
			case 2 :
				return this.supportedEntityTypes != null && !this.supportedEntityTypes.isEmpty();
			case 3 :
				return this.entryMappingRepository != null;
			case 4 :
				return this.propertyExtensionRepository != null;
			case 5 :
				return this.repositories != null && !this.repositories.isEmpty();
			case 6 :
				return this.realmConfiguration != null;
			case 7 :
				return this.pluginManagerConfiguration != null;
			case 8 :
				return this.authorization != null;
			case 9 :
				return this.isSetMaxPagingResults();
			case 10 :
				return this.isSetMaxSearchResults();
			case 11 :
				return this.isSetMaxTotalPagingResults();
			case 12 :
				return this.isSetPagedCacheTimeOut();
			case 13 :
				return this.isSetPagingCachesDiskOffLoad();
			case 14 :
				return this.isSetPagingEntityObject();
			case 15 :
				return this.isSetSearchTimeOut();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (maxPagingResults: ");
			if (this.maxPagingResultsESet) {
				var1.append(this.maxPagingResults);
			} else {
				var1.append("<unset>");
			}

			var1.append(", maxSearchResults: ");
			if (this.maxSearchResultsESet) {
				var1.append(this.maxSearchResults);
			} else {
				var1.append("<unset>");
			}

			var1.append(", maxTotalPagingResults: ");
			if (this.maxTotalPagingResultsESet) {
				var1.append(this.maxTotalPagingResults);
			} else {
				var1.append("<unset>");
			}

			var1.append(", pagedCacheTimeOut: ");
			if (this.pagedCacheTimeOutESet) {
				var1.append(this.pagedCacheTimeOut);
			} else {
				var1.append("<unset>");
			}

			var1.append(", pagingCachesDiskOffLoad: ");
			if (this.pagingCachesDiskOffLoadESet) {
				var1.append(this.pagingCachesDiskOffLoad);
			} else {
				var1.append("<unset>");
			}

			var1.append(", pagingEntityObject: ");
			if (this.pagingEntityObjectESet) {
				var1.append(this.pagingEntityObject);
			} else {
				var1.append("<unset>");
			}

			var1.append(", searchTimeOut: ");
			if (this.searchTimeOutESet) {
				var1.append(this.searchTimeOut);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}