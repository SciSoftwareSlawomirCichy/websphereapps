package com.ibm.icu.impl;

import com.ibm.icu.impl.ZoneMeta.OlsonToMetaMappingEntry;
import com.ibm.icu.text.MessageFormat;
import com.ibm.icu.text.NumberFormat;
import com.ibm.icu.util.SimpleTimeZone;
import com.ibm.icu.util.TimeZone;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.Set;

public final class ZoneMeta {
	private static final boolean ASSERT = false;
	private static final String ZONEINFORESNAME = "zoneinfo64";
	private static final String kREGIONS = "Regions";
	private static final String kZONES = "Zones";
	private static final String kNAMES = "Names";
	private static final String kGMT_ID = "GMT";
	private static final String kCUSTOM_TZ_PREFIX = "GMT";
	private static String[] ZONEIDS = null;
	private static ICUCache<String, String> CANONICAL_ID_CACHE = new SimpleCache();
	private static ICUCache<String, String> REGION_CACHE = new SimpleCache();
	private static ICUCache<String, Boolean> SINGLE_COUNTRY_CACHE = new SimpleCache();
	private static final String DEF_REGION_FORMAT = "{0}";
	private static final String DEF_FALLBACK_FORMAT = "{1} ({0})";
	public static final String HOUR = "hourFormat";
	public static final String GMT = "gmtFormat";
	public static final String REGION_FORMAT = "regionFormat";
	public static final String FALLBACK_FORMAT = "fallbackFormat";
	public static final String ZONE_STRINGS = "zoneStrings";
	public static final String FORWARD_SLASH = "/";
	private static ICUCache<String, TimeZone> SYSTEM_ZONE_CACHE = new SimpleCache();
	private static final int kMAX_CUSTOM_HOUR = 23;
	private static final int kMAX_CUSTOM_MIN = 59;
	private static final int kMAX_CUSTOM_SEC = 59;
	private static ICUCache<String, List<OlsonToMetaMappingEntry>> OLSON_TO_META_CACHE = new SimpleCache();
	private static ICUCache<String, Map<String, String>> META_TO_OLSON_CACHE = new SimpleCache();

	public static synchronized String[] getAvailableIDs(String country) {
		String[] ids = null;

		try {
			UResourceBundle top = (ICUResourceBundle) ICUResourceBundle.getBundleInstance(
					"com/ibm/icu/impl/data/icudt44b", "zoneinfo64", ICUResourceBundle.ICU_DATA_CLASS_LOADER);
			UResourceBundle regions = top.get("Regions");
			List<String> countryZones = new ArrayList();

			for (int i = 0; i < regions.getSize(); ++i) {
				if (country.equals(regions.getString(i))) {
					String zoneName = getZoneID(i);
					countryZones.add(zoneName);
				}
			}

			if (countryZones.size() > 0) {
				ids = (String[]) countryZones.toArray(new String[countryZones.size()]);
			}
		} catch (MissingResourceException var7) {
			;
		}

		if (ids == null) {
			ids = new String[0];
		}

		return ids;
	}

	public static synchronized String[] getAvailableIDs() {
		String[] ids = getZoneIDs();
		return ids == null ? new String[0] : (String[]) ids.clone();
	}

	public static synchronized String[] getAvailableIDs(int offset) {
		String[] ids = null;
		String[] all = getZoneIDs();
		if (all != null) {
			ArrayList<String> zones = new ArrayList();
			String[] arr$ = all;
			int len$ = all.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				String zid = arr$[i$];
				TimeZone z = TimeZone.getTimeZone(zid);
				if (z != null && z.getID().equals(zid) && z.getRawOffset() == offset) {
					zones.add(zid);
				}
			}

			if (zones.size() > 0) {
				ids = (String[]) zones.toArray(new String[zones.size()]);
			}
		}

		if (ids == null) {
			ids = new String[0];
		}

		return ids;
	}

	public static synchronized int countEquivalentIDs(String id) {
		int count = 0;

		try {
			UResourceBundle res = openOlsonResource((UResourceBundle) null, id);
			UResourceBundle links = res.get("links");
			int[] v = links.getIntVector();
			count = v.length;
		} catch (MissingResourceException var5) {
			;
		}

		return count;
	}

	public static synchronized String getEquivalentID(String id, int index) {
		String result = "";
		int zoneIdx = -1;
		if (index >= 0) {
			try {
				UResourceBundle res = openOlsonResource((UResourceBundle) null, id);
				UResourceBundle links = res.get("links");
				int[] zones = links.getIntVector();
				if (index < zones.length) {
					zoneIdx = zones[index];
				}
			} catch (MissingResourceException var7) {
				zoneIdx = -1;
			}
		}

		if (zoneIdx >= 0) {
			String tmp = getZoneID(zoneIdx);
			if (tmp != null) {
				result = tmp;
			}
		}

		return result;
	}

	private static synchronized String[] getZoneIDs() {
		if (ZONEIDS == null) {
			try {
				UResourceBundle top = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b", "zoneinfo64",
						ICUResourceBundle.ICU_DATA_CLASS_LOADER);
				UResourceBundle names = top.get("Names");
				ZONEIDS = names.getStringArray();
			} catch (MissingResourceException var2) {
				;
			}
		}

		if (ZONEIDS == null) {
			ZONEIDS = new String[0];
		}

		return ZONEIDS;
	}

	private static String getZoneID(int idx) {
		if (idx >= 0) {
			String[] ids = getZoneIDs();
			if (idx < ids.length) {
				return ids[idx];
			}
		}

		return null;
	}

	private static int getZoneIndex(String zid) {
		int zoneIdx = -1;
		String[] all = getZoneIDs();
		if (all.length > 0) {
			int start = 0;
			int limit = all.length;
			int lastMid = Integer.MAX_VALUE;

			while (true) {
				int mid = (start + limit) / 2;
				if (lastMid == mid) {
					break;
				}

				lastMid = mid;
				int r = zid.compareTo(all[mid]);
				if (r == 0) {
					zoneIdx = mid;
					break;
				}

				if (r < 0) {
					limit = mid;
				} else {
					start = mid;
				}
			}
		}

		return zoneIdx;
	}

	public static String getCanonicalSystemID(String tzid) {
		String canonical = (String) CANONICAL_ID_CACHE.get(tzid);
		if (canonical == null) {
			int zoneIdx = getZoneIndex(tzid);
			if (zoneIdx >= 0) {
				try {
					UResourceBundle top = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b",
							"zoneinfo64", ICUResourceBundle.ICU_DATA_CLASS_LOADER);
					UResourceBundle zones = top.get("Zones");
					UResourceBundle zone = zones.get(zoneIdx);
					if (zone.getType() == 7) {
						String tmp = getZoneID(zone.getInt());
						if (tmp != null) {
							canonical = tmp;
						}
					} else {
						canonical = tzid;
					}

					UResourceBundle keyTypeData = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b",
							"keyTypeData", ICUResourceBundle.ICU_DATA_CLASS_LOADER);
					UResourceBundle typeAlias = keyTypeData.get("typeAlias");
					UResourceBundle aliasesForKey = typeAlias.get("timezone");
					String cldrCanonical = aliasesForKey.getString(canonical.replace('/', ':'));
					if (cldrCanonical != null) {
						canonical = cldrCanonical;
					}
				} catch (MissingResourceException var10) {
					;
				}
			}

			if (canonical != null) {
				CANONICAL_ID_CACHE.put(tzid, canonical);
			}
		}

		return canonical;
	}

	public static String getCanonicalCountry(String tzid) {
		String region = (String) REGION_CACHE.get(tzid);
		if (region == null) {
			int zoneIdx = getZoneIndex(tzid);
			if (zoneIdx >= 0) {
				try {
					UResourceBundle top = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b",
							"zoneinfo64", ICUResourceBundle.ICU_DATA_CLASS_LOADER);
					UResourceBundle regions = top.get("Regions");
					if (zoneIdx < regions.getSize()) {
						region = regions.getString(zoneIdx);
					}
				} catch (MissingResourceException var5) {
					;
				}

				if (region != null) {
					REGION_CACHE.put(tzid, region);
				}
			}
		}

		return region.equals("001") ? null : region;
	}

	public static String getSingleCountry(String tzid) {
		String country = getCanonicalCountry(tzid);
		if (country != null) {
			Boolean isSingle = (Boolean) SINGLE_COUNTRY_CACHE.get(tzid);
			if (isSingle == null) {
				boolean isSingleCountryZone = true;
				String[] ids = TimeZone.getAvailableIDs(country);
				if (ids.length > 1) {
					String canonical = getCanonicalSystemID(ids[0]);

					for (int i = 1; i < ids.length; ++i) {
						if (!canonical.equals(getCanonicalSystemID(ids[i]))) {
							isSingleCountryZone = false;
							break;
						}
					}
				}

				isSingle = isSingleCountryZone;
				SINGLE_COUNTRY_CACHE.put(tzid, isSingle);
			}

			if (!isSingle) {
				country = null;
			}
		}

		return country;
	}

	public static String getLocationFormat(String tzid, String city, ULocale locale) {
		String country_code = getCanonicalCountry(tzid);
		if (country_code == null) {
			return null;
		} else {
			String country = null;

			try {
				ICUResourceBundle rb = (ICUResourceBundle) UResourceBundle
						.getBundleInstance("com/ibm/icu/impl/data/icudt44b/region", locale);
				ULocale rbloc = rb.getULocale();
				if (!rbloc.equals(ULocale.ROOT) && rbloc.getLanguage().equals(locale.getLanguage())) {
					country = ULocale.getDisplayCountry("xx_" + country_code, locale);
				}
			} catch (MissingResourceException var7) {
				;
			}

			if (country == null || country.length() == 0) {
				country = country_code;
			}

			String flbPat;
			MessageFormat mf;
			if (getSingleCountry(tzid) != null) {
				flbPat = getTZLocalizationInfo(locale, "regionFormat");
				if (flbPat == null) {
					flbPat = "{0}";
				}

				mf = new MessageFormat(flbPat);
				return mf.format(new Object[]{country});
			} else {
				if (city == null) {
					city = tzid.substring(tzid.lastIndexOf(47) + 1).replace('_', ' ');
				}

				flbPat = getTZLocalizationInfo(locale, "fallbackFormat");
				if (flbPat == null) {
					flbPat = "{1} ({0})";
				}

				mf = new MessageFormat(flbPat);
				return mf.format(new Object[]{city, country});
			}
		}
	}

	public static String getTZLocalizationInfo(ULocale locale, String format) {
		String result = null;

		try {
			ICUResourceBundle bundle = (ICUResourceBundle) ICUResourceBundle
					.getBundleInstance("com/ibm/icu/impl/data/icudt44b/zone", locale);
			result = bundle.getStringWithFallback("zoneStrings/" + format);
		} catch (MissingResourceException var4) {
			result = null;
		}

		return result;
	}

	public static UResourceBundle openOlsonResource(UResourceBundle top, String id) {
		UResourceBundle res = null;
		int zoneIdx = getZoneIndex(id);
		if (zoneIdx >= 0) {
			try {
				if (top == null) {
					top = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b", "zoneinfo64",
							ICUResourceBundle.ICU_DATA_CLASS_LOADER);
				}

				UResourceBundle zones = top.get("Zones");
				UResourceBundle zone = zones.get(zoneIdx);
				if (zone.getType() == 7) {
					zone = zones.get(zone.getInt());
				}

				res = zone;
			} catch (MissingResourceException var6) {
				res = null;
			}
		}

		return res;
	}

	public static TimeZone getSystemTimeZone(String id) {
		TimeZone z = (TimeZone) SYSTEM_ZONE_CACHE.get(id);
		if (z == null) {
			try {
				UResourceBundle top = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b", "zoneinfo64",
						ICUResourceBundle.ICU_DATA_CLASS_LOADER);
				UResourceBundle res = openOlsonResource(top, id);
				z = new OlsonTimeZone(top, res);
				((TimeZone) z).setID(id);
				SYSTEM_ZONE_CACHE.put(id, z);
			} catch (Exception var4) {
				return null;
			}
		}

		return (TimeZone) ((TimeZone) z).clone();
	}

	public static TimeZone getGMT() {
		TimeZone z = new SimpleTimeZone(0, "GMT");
		z.setID("GMT");
		return z;
	}

	public static TimeZone getCustomTimeZone(String id) {
		int[] fields = new int[4];
		if (parseCustomID(id, fields)) {
			String zid = formatCustomID(fields[1], fields[2], fields[3], fields[0] < 0);
			int offset = fields[0] * ((fields[1] * 60 + fields[2]) * 60 + fields[3]) * 1000;
			return new SimpleTimeZone(offset, zid);
		} else {
			return null;
		}
	}

	public static String getCustomID(String id) {
		int[] fields = new int[4];
		return parseCustomID(id, fields) ? formatCustomID(fields[1], fields[2], fields[3], fields[0] < 0) : null;
	}

	static boolean parseCustomID(String id, int[] fields) {
		NumberFormat numberFormat = null;
		String idUppercase = id.toUpperCase();
		if (id != null && id.length() > "GMT".length() && idUppercase.startsWith("GMT")) {
			ParsePosition pos = new ParsePosition("GMT".length());
			int sign = 1;
			int hour = false;
			int min = 0;
			int sec = 0;
			if (id.charAt(pos.getIndex()) == '-') {
				sign = -1;
			} else if (id.charAt(pos.getIndex()) != '+') {
				return false;
			}

			pos.setIndex(pos.getIndex() + 1);
			numberFormat = NumberFormat.getInstance();
			numberFormat.setParseIntegerOnly(true);
			int start = pos.getIndex();
			Number n = numberFormat.parse(id, pos);
			if (pos.getIndex() == start) {
				return false;
			}

			int hour = n.intValue();
			int oldPos;
			if (pos.getIndex() < id.length()) {
				if (pos.getIndex() - start > 2 || id.charAt(pos.getIndex()) != ':') {
					return false;
				}

				pos.setIndex(pos.getIndex() + 1);
				oldPos = pos.getIndex();
				n = numberFormat.parse(id, pos);
				if (pos.getIndex() - oldPos != 2) {
					return false;
				}

				min = n.intValue();
				if (pos.getIndex() < id.length()) {
					if (id.charAt(pos.getIndex()) != ':') {
						return false;
					}

					pos.setIndex(pos.getIndex() + 1);
					oldPos = pos.getIndex();
					n = numberFormat.parse(id, pos);
					if (pos.getIndex() != id.length() || pos.getIndex() - oldPos != 2) {
						return false;
					}

					sec = n.intValue();
				}
			} else {
				oldPos = pos.getIndex() - start;
				if (oldPos <= 0 || 6 < oldPos) {
					return false;
				}

				switch (oldPos) {
					case 1 :
					case 2 :
					default :
						break;
					case 3 :
					case 4 :
						min = hour % 100;
						hour /= 100;
						break;
					case 5 :
					case 6 :
						sec = hour % 100;
						min = hour / 100 % 100;
						hour /= 10000;
				}
			}

			if (hour <= 23 && min <= 59 && sec <= 59) {
				if (fields != null) {
					if (fields.length >= 1) {
						fields[0] = sign;
					}

					if (fields.length >= 2) {
						fields[1] = hour;
					}

					if (fields.length >= 3) {
						fields[2] = min;
					}

					if (fields.length >= 4) {
						fields[3] = sec;
					}
				}

				return true;
			}
		}

		return false;
	}

	public static TimeZone getCustomTimeZone(int offset) {
		boolean negative = false;
		int tmp = offset;
		if (offset < 0) {
			negative = true;
			tmp = -offset;
		}

		int millis = tmp % 1000;
		tmp /= 1000;
		int sec = tmp % 60;
		tmp /= 60;
		int min = tmp % 60;
		int hour = tmp / 60;
		String zid = formatCustomID(hour, min, sec, negative);
		return new SimpleTimeZone(offset, zid);
	}

	static String formatCustomID(int hour, int min, int sec, boolean negative) {
		StringBuilder zid = new StringBuilder("GMT");
		if (hour != 0 || min != 0) {
			if (negative) {
				zid.append('-');
			} else {
				zid.append('+');
			}

			if (hour < 10) {
				zid.append('0');
			}

			zid.append(hour);
			zid.append(':');
			if (min < 10) {
				zid.append('0');
			}

			zid.append(min);
			if (sec != 0) {
				zid.append(':');
				if (sec < 10) {
					zid.append('0');
				}

				zid.append(sec);
			}
		}

		return zid.toString();
	}

	public static String getMetazoneID(String olsonID, long date) {
		String mzid = null;
		List<OlsonToMetaMappingEntry> mappings = getOlsonToMatazones(olsonID);
		if (mappings != null) {
			for (int i = 0; i < mappings.size(); ++i) {
				OlsonToMetaMappingEntry mzm = (OlsonToMetaMappingEntry) mappings.get(i);
				if (date >= mzm.from && date < mzm.to) {
					mzid = mzm.mzid;
					break;
				}
			}
		}

		return mzid;
	}

	static List<OlsonToMetaMappingEntry> getOlsonToMatazones(String tzid) {
		List<OlsonToMetaMappingEntry> mzMappings = (List) OLSON_TO_META_CACHE.get(tzid);
		if (mzMappings == null) {
			try {
				UResourceBundle bundle = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b",
						"metaZones");
				UResourceBundle metazoneInfoBundle = bundle.get("metazoneInfo");
				String canonicalID = TimeZone.getCanonicalID(tzid);
				if (canonicalID == null) {
					return null;
				}

				String tzkey = canonicalID.replace('/', ':');
				UResourceBundle zoneBundle = metazoneInfoBundle.get(tzkey);
				mzMappings = new LinkedList();

				for (int idx = 0; idx < zoneBundle.getSize(); ++idx) {
					UResourceBundle mz = zoneBundle.get(idx);
					String mzid = mz.getString(0);
					String from = "1970-01-01 00:00";
					String to = "9999-12-31 23:59";
					if (mz.getSize() == 3) {
						from = mz.getString(1);
						to = mz.getString(2);
					}

					OlsonToMetaMappingEntry mzmap = new OlsonToMetaMappingEntry();
					mzmap.mzid = mzid.intern();

					try {
						mzmap.from = parseDate(from);
						mzmap.to = parseDate(to);
					} catch (IllegalArgumentException var14) {
						continue;
					}

					((List) mzMappings).add(mzmap);
				}
			} catch (MissingResourceException var15) {
				;
			}

			if (mzMappings != null) {
				OLSON_TO_META_CACHE.put(tzid, mzMappings);
			}
		}

		return (List) mzMappings;
	}

	static long parseDate(String text) throws IllegalArgumentException {
		int year = 0;
		int month = 0;
		int day = 0;
		int hour = 0;
		int min = 0;

		int idx;
		int n;
		for (idx = 0; idx <= 3; ++idx) {
			n = text.charAt(idx) - 48;
			if (n < 0 || n >= 10) {
				throw new IllegalArgumentException("Bad year");
			}

			year = 10 * year + n;
		}

		for (idx = 5; idx <= 6; ++idx) {
			n = text.charAt(idx) - 48;
			if (n < 0 || n >= 10) {
				throw new IllegalArgumentException("Bad month");
			}

			month = 10 * month + n;
		}

		for (idx = 8; idx <= 9; ++idx) {
			n = text.charAt(idx) - 48;
			if (n < 0 || n >= 10) {
				throw new IllegalArgumentException("Bad day");
			}

			day = 10 * day + n;
		}

		for (idx = 11; idx <= 12; ++idx) {
			n = text.charAt(idx) - 48;
			if (n < 0 || n >= 10) {
				throw new IllegalArgumentException("Bad hour");
			}

			hour = 10 * hour + n;
		}

		for (idx = 14; idx <= 15; ++idx) {
			n = text.charAt(idx) - 48;
			if (n < 0 || n >= 10) {
				throw new IllegalArgumentException("Bad minute");
			}

			min = 10 * min + n;
		}

		long date = Grego.fieldsToDay(year, month - 1, day) * 86400000L + (long) (hour * 3600000) + (long) (min * '');
		return date;
	}

	public static String getZoneIdByMetazone(String metazoneID, String region) {
		String tzid = null;
		Map<String, String> zoneMap = (Map) META_TO_OLSON_CACHE.get(metazoneID);
		if (zoneMap == null) {
			try {
				UResourceBundle bundle = UResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b",
						"metaZones");
				UResourceBundle mapTimezones = bundle.get("mapTimezones");
				UResourceBundle territoryMap = mapTimezones.get(metazoneID);
				zoneMap = new HashMap();
				Set<String> territories = territoryMap.keySet();
				Iterator i$ = territories.iterator();

				while (i$.hasNext()) {
					String territory = (String) i$.next();
					String zone = territoryMap.getString(territory);
					((Map) zoneMap).put(territory, zone);
				}

				META_TO_OLSON_CACHE.put(metazoneID, zoneMap);
			} catch (MissingResourceException var11) {
				;
			}
		}

		if (zoneMap != null) {
			tzid = (String) ((Map) zoneMap).get(region);
			if (tzid == null) {
				tzid = (String) ((Map) zoneMap).get("001");
			}
		}

		return tzid;
	}
}