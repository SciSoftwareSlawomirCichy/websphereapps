package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.AttributeType;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EDataTypeEList;

public class AttributeTypeImpl extends EDataObjectImpl implements AttributeType {
	protected EList entityTypes = null;
	protected static final String DEFAULT_ATTRIBUTE_EDEFAULT = null;
	protected String defaultAttribute;
	protected static final String DEFAULT_VALUE_EDEFAULT = null;
	protected String defaultValue;
	protected static final String NAME_EDEFAULT = null;
	protected String name;
	protected static final String PROPERTY_NAME_EDEFAULT = null;
	protected String propertyName;
	protected static final String SYNTAX_EDEFAULT = null;
	protected String syntax;
	protected static final boolean WIM_GENERATE_EDEFAULT = false;
	protected boolean wimGenerate;
	protected boolean wimGenerateESet;

	protected AttributeTypeImpl() {
		this.defaultAttribute = DEFAULT_ATTRIBUTE_EDEFAULT;
		this.defaultValue = DEFAULT_VALUE_EDEFAULT;
		this.name = NAME_EDEFAULT;
		this.propertyName = PROPERTY_NAME_EDEFAULT;
		this.syntax = SYNTAX_EDEFAULT;
		this.wimGenerate = false;
		this.wimGenerateESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getAttributeType();
	}

	public String[] getEntityTypesAsArray() {
		List var1 = this.getEntityTypes();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getEntityTypes() {
		if (this.entityTypes == null) {
			this.entityTypes = new EDataTypeEList(String.class, this, 0);
		}

		return this.entityTypes;
	}

	public String getDefaultAttribute() {
		return this.defaultAttribute;
	}

	public void setDefaultAttribute(String var1) {
		String var2 = this.defaultAttribute;
		this.defaultAttribute = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.defaultAttribute));
		}

	}

	public String getDefaultValue() {
		return this.defaultValue;
	}

	public void setDefaultValue(String var1) {
		String var2 = this.defaultValue;
		this.defaultValue = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.defaultValue));
		}

	}

	public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		String var2 = this.name;
		this.name = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.name));
		}

	}

	public String getPropertyName() {
		return this.propertyName;
	}

	public void setPropertyName(String var1) {
		String var2 = this.propertyName;
		this.propertyName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var2, this.propertyName));
		}

	}

	public String getSyntax() {
		return this.syntax;
	}

	public void setSyntax(String var1) {
		String var2 = this.syntax;
		this.syntax = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 5, var2, this.syntax));
		}

	}

	public boolean isWimGenerate() {
		return this.wimGenerate;
	}

	public void setWimGenerate(boolean var1) {
		boolean var2 = this.wimGenerate;
		this.wimGenerate = var1;
		boolean var3 = this.wimGenerateESet;
		this.wimGenerateESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 6, var2, this.wimGenerate, !var3));
		}

	}

	public void unsetWimGenerate() {
		boolean var1 = this.wimGenerate;
		boolean var2 = this.wimGenerateESet;
		this.wimGenerate = false;
		this.wimGenerateESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 6, var1, false, var2));
		}

	}

	public boolean isSetWimGenerate() {
		return this.wimGenerateESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getEntityTypes();
			case 1 :
				return this.getDefaultAttribute();
			case 2 :
				return this.getDefaultValue();
			case 3 :
				return this.getName();
			case 4 :
				return this.getPropertyName();
			case 5 :
				return this.getSyntax();
			case 6 :
				return this.isWimGenerate() ? Boolean.TRUE : Boolean.FALSE;
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getEntityTypes().clear();
				this.getEntityTypes().addAll((Collection) var2);
				return;
			case 1 :
				this.setDefaultAttribute((String) var2);
				return;
			case 2 :
				this.setDefaultValue((String) var2);
				return;
			case 3 :
				this.setName((String) var2);
				return;
			case 4 :
				this.setPropertyName((String) var2);
				return;
			case 5 :
				this.setSyntax((String) var2);
				return;
			case 6 :
				this.setWimGenerate((Boolean) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getEntityTypes().clear();
				return;
			case 1 :
				this.setDefaultAttribute(DEFAULT_ATTRIBUTE_EDEFAULT);
				return;
			case 2 :
				this.setDefaultValue(DEFAULT_VALUE_EDEFAULT);
				return;
			case 3 :
				this.setName(NAME_EDEFAULT);
				return;
			case 4 :
				this.setPropertyName(PROPERTY_NAME_EDEFAULT);
				return;
			case 5 :
				this.setSyntax(SYNTAX_EDEFAULT);
				return;
			case 6 :
				this.unsetWimGenerate();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.entityTypes != null && !this.entityTypes.isEmpty();
			case 1 :
				return DEFAULT_ATTRIBUTE_EDEFAULT == null
						? this.defaultAttribute != null
						: !DEFAULT_ATTRIBUTE_EDEFAULT.equals(this.defaultAttribute);
			case 2 :
				return DEFAULT_VALUE_EDEFAULT == null
						? this.defaultValue != null
						: !DEFAULT_VALUE_EDEFAULT.equals(this.defaultValue);
			case 3 :
				return NAME_EDEFAULT == null ? this.name != null : !NAME_EDEFAULT.equals(this.name);
			case 4 :
				return PROPERTY_NAME_EDEFAULT == null
						? this.propertyName != null
						: !PROPERTY_NAME_EDEFAULT.equals(this.propertyName);
			case 5 :
				return SYNTAX_EDEFAULT == null ? this.syntax != null : !SYNTAX_EDEFAULT.equals(this.syntax);
			case 6 :
				return this.isSetWimGenerate();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (entityTypes: ");
			var1.append(this.entityTypes);
			var1.append(", defaultAttribute: ");
			var1.append(this.defaultAttribute);
			var1.append(", defaultValue: ");
			var1.append(this.defaultValue);
			var1.append(", name: ");
			var1.append(this.name);
			var1.append(", propertyName: ");
			var1.append(this.propertyName);
			var1.append(", syntax: ");
			var1.append(this.syntax);
			var1.append(", wimGenerate: ");
			if (this.wimGenerateESet) {
				var1.append(this.wimGenerate);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}