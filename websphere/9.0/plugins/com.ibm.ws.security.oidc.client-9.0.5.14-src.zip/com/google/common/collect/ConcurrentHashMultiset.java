package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.collect.ConcurrentHashMultiset.1;
import com.google.common.collect.ConcurrentHashMultiset.2;
import com.google.common.collect.ConcurrentHashMultiset.3;
import com.google.common.collect.ConcurrentHashMultiset.EntrySet;
import com.google.common.collect.ConcurrentHashMultiset.FieldSettersHolder;
import com.google.common.collect.Multiset.Entry;
import com.google.common.math.IntMath;
import com.google.common.primitives.Ints;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtIncompatible
public final class ConcurrentHashMultiset<E> extends AbstractMultiset<E> implements Serializable {
	private final transient ConcurrentMap<E, AtomicInteger> countMap;
	private static final long serialVersionUID = 1L;

	public static <E> ConcurrentHashMultiset<E> create() {
		return new ConcurrentHashMultiset(new ConcurrentHashMap());
	}

	public static <E> ConcurrentHashMultiset<E> create(Iterable<? extends E> elements) {
		ConcurrentHashMultiset<E> multiset = create();
		Iterables.addAll(multiset, elements);
		return multiset;
	}

	@Beta
	public static <E> ConcurrentHashMultiset<E> create(ConcurrentMap<E, AtomicInteger> countMap) {
		return new ConcurrentHashMultiset(countMap);
	}

	@VisibleForTesting
	ConcurrentHashMultiset(ConcurrentMap<E, AtomicInteger> countMap) {
		Preconditions.checkArgument(countMap.isEmpty(), "the backing map (%s) must be empty", countMap);
		this.countMap = countMap;
	}

	public int count(@NullableDecl Object element) {
		AtomicInteger existingCounter = (AtomicInteger) Maps.safeGet(this.countMap, element);
		return existingCounter == null ? 0 : existingCounter.get();
	}

	public int size() {
		long sum = 0L;

		AtomicInteger value;
		for (Iterator var3 = this.countMap.values().iterator(); var3.hasNext(); sum += (long) value.get()) {
			value = (AtomicInteger) var3.next();
		}

		return Ints.saturatedCast(sum);
	}

	public Object[] toArray() {
		return this.snapshot().toArray();
	}

	public <T> T[] toArray(T[] array) {
		return this.snapshot().toArray(array);
	}

	private List<E> snapshot() {
		List<E> list = Lists.newArrayListWithExpectedSize(this.size());
		Iterator var2 = this.entrySet().iterator();

		while (var2.hasNext()) {
			Entry<E> entry = (Entry) var2.next();
			E element = entry.getElement();

			for (int i = entry.getCount(); i > 0; --i) {
				list.add(element);
			}
		}

		return list;
	}

	@CanIgnoreReturnValue
	public int add(E element, int occurrences) {
		Preconditions.checkNotNull(element);
		if (occurrences == 0) {
			return this.count(element);
		} else {
			CollectPreconditions.checkPositive(occurrences, "occurences");

			AtomicInteger existingCounter;
			AtomicInteger newCounter;
			do {
				existingCounter = (AtomicInteger) Maps.safeGet(this.countMap, element);
				if (existingCounter == null) {
					existingCounter = (AtomicInteger) this.countMap.putIfAbsent(element,
							new AtomicInteger(occurrences));
					if (existingCounter == null) {
						return 0;
					}
				}

				while (true) {
					int oldValue = existingCounter.get();
					if (oldValue == 0) {
						newCounter = new AtomicInteger(occurrences);
						break;
					}

					try {
						int newValue = IntMath.checkedAdd(oldValue, occurrences);
						if (existingCounter.compareAndSet(oldValue, newValue)) {
							return oldValue;
						}
					} catch (ArithmeticException var6) {
						throw new IllegalArgumentException(
								"Overflow adding " + occurrences + " occurrences to a count of " + oldValue);
					}
				}
			} while (this.countMap.putIfAbsent(element, newCounter) != null
					&& !this.countMap.replace(element, existingCounter, newCounter));

			return 0;
		}
	}

	@CanIgnoreReturnValue
	public int remove(@NullableDecl Object element, int occurrences) {
		if (occurrences == 0) {
			return this.count(element);
		} else {
			CollectPreconditions.checkPositive(occurrences, "occurences");
			AtomicInteger existingCounter = (AtomicInteger) Maps.safeGet(this.countMap, element);
			if (existingCounter == null) {
				return 0;
			} else {
				int oldValue;
				int newValue;
				do {
					oldValue = existingCounter.get();
					if (oldValue == 0) {
						return 0;
					}

					newValue = Math.max(0, oldValue - occurrences);
				} while (!existingCounter.compareAndSet(oldValue, newValue));

				if (newValue == 0) {
					this.countMap.remove(element, existingCounter);
				}

				return oldValue;
			}
		}
	}

	@CanIgnoreReturnValue
	public boolean removeExactly(@NullableDecl Object element, int occurrences) {
		if (occurrences == 0) {
			return true;
		} else {
			CollectPreconditions.checkPositive(occurrences, "occurences");
			AtomicInteger existingCounter = (AtomicInteger) Maps.safeGet(this.countMap, element);
			if (existingCounter == null) {
				return false;
			} else {
				int oldValue;
				int newValue;
				do {
					oldValue = existingCounter.get();
					if (oldValue < occurrences) {
						return false;
					}

					newValue = oldValue - occurrences;
				} while (!existingCounter.compareAndSet(oldValue, newValue));

				if (newValue == 0) {
					this.countMap.remove(element, existingCounter);
				}

				return true;
			}
		}
	}

	@CanIgnoreReturnValue
	public int setCount(E element, int count) {
		Preconditions.checkNotNull(element);
		CollectPreconditions.checkNonnegative(count, "count");

		AtomicInteger existingCounter;
		AtomicInteger newCounter;
		label40 : do {
			existingCounter = (AtomicInteger) Maps.safeGet(this.countMap, element);
			if (existingCounter == null) {
				if (count == 0) {
					return 0;
				}

				existingCounter = (AtomicInteger) this.countMap.putIfAbsent(element, new AtomicInteger(count));
				if (existingCounter == null) {
					return 0;
				}
			}

			int oldValue;
			do {
				oldValue = existingCounter.get();
				if (oldValue == 0) {
					if (count == 0) {
						return 0;
					}

					newCounter = new AtomicInteger(count);
					continue label40;
				}
			} while (!existingCounter.compareAndSet(oldValue, count));

			if (count == 0) {
				this.countMap.remove(element, existingCounter);
			}

			return oldValue;
		} while (this.countMap.putIfAbsent(element, newCounter) != null
				&& !this.countMap.replace(element, existingCounter, newCounter));

		return 0;
	}

	@CanIgnoreReturnValue
	public boolean setCount(E element, int expectedOldCount, int newCount) {
		Preconditions.checkNotNull(element);
		CollectPreconditions.checkNonnegative(expectedOldCount, "oldCount");
		CollectPreconditions.checkNonnegative(newCount, "newCount");
		AtomicInteger existingCounter = (AtomicInteger) Maps.safeGet(this.countMap, element);
		if (existingCounter == null) {
			if (expectedOldCount != 0) {
				return false;
			} else if (newCount == 0) {
				return true;
			} else {
				return this.countMap.putIfAbsent(element, new AtomicInteger(newCount)) == null;
			}
		} else {
			int oldValue = existingCounter.get();
			if (oldValue == expectedOldCount) {
				if (oldValue == 0) {
					if (newCount == 0) {
						this.countMap.remove(element, existingCounter);
						return true;
					}

					AtomicInteger newCounter = new AtomicInteger(newCount);
					return this.countMap.putIfAbsent(element, newCounter) == null
							|| this.countMap.replace(element, existingCounter, newCounter);
				}

				if (existingCounter.compareAndSet(oldValue, newCount)) {
					if (newCount == 0) {
						this.countMap.remove(element, existingCounter);
					}

					return true;
				}
			}

			return false;
		}
	}

	Set<E> createElementSet() {
      Set<E> delegate = this.countMap.keySet();
      return new 1(this, delegate);
   }

	Iterator<E> elementIterator() {
		throw new AssertionError("should never be called");
	}

	@Deprecated
   public Set<Entry<E>> createEntrySet() {
      return new EntrySet(this, (1)null);
   }

	int distinctElements() {
		return this.countMap.size();
	}

	public boolean isEmpty() {
		return this.countMap.isEmpty();
	}

	Iterator<Entry<E>> entryIterator() {
      Iterator<Entry<E>> readOnlyIterator = new 2(this);
      return new 3(this, readOnlyIterator);
   }

	public Iterator<E> iterator() {
		return Multisets.iteratorImpl(this);
	}

	public void clear() {
		this.countMap.clear();
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		stream.writeObject(this.countMap);
	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		ConcurrentMap<E, Integer> deserializedCountMap = (ConcurrentMap) stream.readObject();
		FieldSettersHolder.COUNT_MAP_FIELD_SETTER.set(this, deserializedCountMap);
	}
}