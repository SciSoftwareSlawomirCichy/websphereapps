package com.ibm.bsf.util;

import java.util.Hashtable;

public class ObjectRegistry {
	Hashtable reg = new Hashtable();
	ObjectRegistry parent = null;

	public ObjectRegistry() {
	}

	public ObjectRegistry(ObjectRegistry var1) {
		this.parent = var1;
	}

	public Object lookup(String var1) throws IllegalArgumentException {
		Object var2 = this.reg.get(var1);
		if (var2 == null && this.parent != null) {
			var2 = this.parent.lookup(var1);
		}

		if (var2 == null) {
			throw new IllegalArgumentException("object '" + var1 + "' not in registry");
		} else {
			return var2;
		}
	}

	public void register(String var1, Object var2) {
		this.reg.put(var1, var2);
	}

	public void unregister(String var1) {
		this.reg.remove(var1);
	}
}