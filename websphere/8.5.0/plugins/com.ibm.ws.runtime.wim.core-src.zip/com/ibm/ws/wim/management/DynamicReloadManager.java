package com.ibm.ws.wim.management;

import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.configservice.ConfigDataId;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.management.configservice.ConfigServiceFactory;
import com.ibm.websphere.management.configservice.ConfigServiceHelper;
import com.ibm.websphere.wim.exception.NetworkConfigSyncException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.util.Routines;
import com.ibm.ws.management.AdminHelper;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.ObjectName;
import javax.management.QueryExp;

public class DynamicReloadManager {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = DynamicReloadManager.class.getName();
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static boolean isDMgrMode;
	private static boolean isNodeAgentMode;
	private static boolean isManagedProcessMode;
	private static boolean isSingleServerMode;
	private static boolean isConnectionTypeNoneMode;
	private static boolean isAdminAgentMode;
	private static boolean isJobManagerMode;
	private static boolean isRegisteredWithAdminAgent;
	private HashMap managedProcRegistrations;
	private HashMap mNodeLookupCache;
	private static DynamicReloadManager singletonObj;

	private DynamicReloadManager() {
		if (!isDMgrMode) {
			this.managedProcRegistrations = new HashMap();
			this.mNodeLookupCache = new HashMap();
		}

	}

	public static synchronized DynamicReloadManager singleton() {
		if (singletonObj == null) {
			singletonObj = new DynamicReloadManager();
		}

		return singletonObj;
	}

	private Vector getEventListeners(String var1) {
		Routines.enterMethod(trcLogger, CLASSNAME, "getEventListeners", Level.FINE);
		Vector var3 = null;
		if (this.mNodeLookupCache.containsKey(var1)) {
			var3 = (Vector) this.mNodeLookupCache.get(var1);
		} else {
			HashMap var4 = this.managedProcRegistrations;
			Iterator var5 = var4.keySet().iterator();
			HashMap var6 = new HashMap();

			label35 : while (true) {
				String var7;
				do {
					if (!var5.hasNext()) {
						if (var6.size() > 0) {
							var3 = new Vector(var6.values());
							this.mNodeLookupCache.put(var1, var3);
						}
						break label35;
					}

					var7 = (String) var5.next();
				} while (!var7.startsWith(var1) && !var7.equalsIgnoreCase(var1));

				Vector var8 = (Vector) var4.get(var7);
				Iterator var9 = var8.iterator();

				while (var9.hasNext()) {
					EventHandler var10 = (EventHandler) var9.next();
					String var11 = var10.getClass().getName();
					if (!var6.containsKey(var11)) {
						var6.put(var11, var10);
					}
				}
			}
		}

		Routines.exitMethod(trcLogger, CLASSNAME, "getEventListeners", Level.FINE);
		return var3;
	}

	private static void determineWASRuntimeContext() {
		trcLogger.entering(CLASSNAME, "determineWASRuntimeContext");
		isDMgrMode = false;
		isNodeAgentMode = false;
		isManagedProcessMode = false;
		isSingleServerMode = false;
		isConnectionTypeNoneMode = false;
		isAdminAgentMode = false;
		isJobManagerMode = false;
		isRegisteredWithAdminAgent = false;
		AdminService var1 = AdminServiceFactory.getAdminService();
		if (var1 != null) {
			String var2 = var1.getProcessType();
			if (var2.equals("ManagedProcess")) {
				isManagedProcessMode = true;
			} else if (var2.equals("DeploymentManager")) {
				isDMgrMode = true;
			} else if (var2.equals("NodeAgent")) {
				isNodeAgentMode = true;
			} else if (var2.equals("UnManagedProcess")) {
				isSingleServerMode = true;

				try {
					isRegisteredWithAdminAgent = AdminHelper.getInstance().isCellRegistered();
				} catch (Exception var4) {
					trcLogger.logp(Level.FINE, CLASSNAME, "determineWASRuntimeContext",
							"Exception determining if the cell is registered or not", var4);
				}
			} else if (var2.equals("AdminAgent")) {
				isAdminAgentMode = true;
			} else if (var2.equals("JobManager")) {
				isJobManagerMode = true;
			}
		} else {
			isConnectionTypeNoneMode = true;
		}

		trcLogger.exiting(CLASSNAME, "determineWASRuntimeContext",
				"isDMgrMode=" + isDMgrMode + ", isNodeAgentMode=" + isNodeAgentMode + ", isManagedProcessMode="
						+ isManagedProcessMode + ", isSingleServerMode=" + isSingleServerMode
						+ ", isConnectionTypeNoneMode=" + isConnectionTypeNoneMode + ", isAdminAgentMode="
						+ isAdminAgentMode + ", isJobManagerMode=" + isJobManagerMode + ", isRegisteredWithAdminAgent="
						+ isRegisteredWithAdminAgent);
	}

	public static boolean isConnectionTypeNone() {
		return isConnectionTypeNoneMode;
	}

	public static boolean isNetworkDeploymentMode() {
		return isManagedProcessMode || isDMgrMode || isNodeAgentMode;
	}

	public static boolean isRunningOnDeploymentManager() {
		return isDMgrMode;
	}

	public static boolean isRunningOnNodeAgent() {
		return isNodeAgentMode;
	}

	public static boolean isRunningOnManagedProc() {
		return isManagedProcessMode;
	}

	public static boolean isRunningOnManagedProcOrNodeAgent() {
		return isManagedProcessMode || isNodeAgentMode;
	}

	public static boolean isRunningOnSingleServer() {
		return isSingleServerMode;
	}

	public static boolean isRunningOnAdminAgent() {
		return isAdminAgentMode;
	}

	public static boolean isRunningOnJobManager() {
		return isJobManagerMode;
	}

	public static boolean isRegisteredWithAdminAgentMode() {
		return isRegisteredWithAdminAgent;
	}

	public static String getCellName() {
		AdminService var1 = AdminServiceFactory.getAdminService();
		String var0;
		if (var1 != null) {
			var0 = var1.getCellName();
		} else {
			var0 = System.getProperty("local.cell");
		}

		return var0;
	}

	public void registerEventAtNode(String var1, EventHandler var2) {
		Routines.enterMethod(trcLogger, CLASSNAME, "registerEventAtNode", Level.FINEST);
		if (!isRunningOnManagedProcOrNodeAgent() && !isRegisteredWithAdminAgentMode()) {
			Routines.exitResultMethod(trcLogger, CLASSNAME, "registerEventAtNode", Level.FINEST,
					"Existing without registering");
		} else {
			StringBuffer var4 = new StringBuffer();
			var4.append("Registering eventType <").append(var1).append("> ");
			var4.append(" with eventHandler <").append(var2.getClass().getName()).append(">");
			Routines.logMessage(trcLogger, CLASSNAME, "registerEventAtNode", Level.FINER, var4.toString());
			Vector var5;
			if (this.managedProcRegistrations.containsKey(var1)) {
				var5 = (Vector) this.managedProcRegistrations.get(var1);
				Iterator var6 = var5.iterator();
				boolean var7 = false;

				while (var6.hasNext()) {
					EventHandler var8 = (EventHandler) var6.next();
					if (var8.getClass().getName().equalsIgnoreCase(var2.getClass().getName())) {
						var7 = true;
						break;
					}
				}

				if (!var7) {
					var5.add(var2);
				}
			} else {
				var5 = new Vector();
				var5.add(var2);
				this.managedProcRegistrations.put(var1.toLowerCase(), var5);
			}

			Routines.exitMethod(trcLogger, CLASSNAME, "registerEventAtNode", Level.FINEST);
		}
	}

	public void broadcastEventAtDeploymentManager(String var1, String var2, EventDataWrapper var3)
			throws NetworkConfigSyncException {
		Routines.enterMethod(trcLogger, CLASSNAME, "broadcastEventAtDeploymentManager", Level.FINEST);
		String var5 = "processEvent";
		String[] var6 = new String[]{"java.lang.String", "java.lang.String", "java.lang.Object"};
		Object[] var7 = new Object[]{var1, var2, var3};
		HashSet var9 = new HashSet();
		if (!isDMgrMode && !isAdminAgentMode) {
			Routines.exitResultMethod(trcLogger, CLASSNAME, "broadcastEventAtDeploymentManager", Level.FINEST,
					"No action to take");
		} else {
			String var10 = "DYNAMIC_RELOAD_EVENT_BROADCAST_ERROR";
			if (isAdminAgentMode) {
				var10 = "DYNAMIC_RELOAD_EVENT_BROADCAST_ERROR_TO_PROFILE";
			}

			try {
				if (isDMgrMode) {
					msgLogger.logp(Level.INFO, CLASSNAME, "broadcastEventAtDeploymentManager",
							"DYNAMIC_RELOAD_DMGR_BROADCAST_EVENT", new Object[]{var1});
				}

				this.logEventDetails(var1, var2, var3, trcLogger);
				AdminService var11 = AdminServiceFactory.getAdminService();
				String var12 = "WebSphere:type=UserManagerMBean,*";
				Routines.logMessage(trcLogger, CLASSNAME, "broadcastEventAtDeploymentManager", Level.FINE,
						"Querying MBeans at managed nodes (" + var12 + ")...");
				ObjectName var13 = new ObjectName(var12);
				Set var8 = UserManagementProcess.suQueryNames(var11, var13, (QueryExp) null);
				Routines.logMessage(trcLogger, CLASSNAME, "broadcastEventAtDeploymentManager", Level.FINE,
						"Found MBeans running on " + var8.size() + " managed node(s)");
				Iterator var14 = var8.iterator();

				while (var14.hasNext()) {
					try {
						var13 = (ObjectName) var14.next();
						if (isAdminAgentMode) {
							msgLogger.logp(Level.INFO, CLASSNAME, "broadcastEventAtDeploymentManager",
									"DYNAMIC_RELOAD_AA_BROADCAST_EVENT_TO_PROFILE", new Object[]{var1, var13});
						}

						Routines.logMessage(trcLogger, CLASSNAME, "broadcastEventAtDeploymentManager", Level.FINE,
								"Sending event to managed node MBean (" + var13 + ")");
						Boolean var15 = (Boolean) UserManagementProcess.suInvokeAdminService(var11, var13, var5, var7,
								var6);
						if (var15.equals(Boolean.TRUE)) {
							var9.add(var13);
						}
					} catch (Exception var16) {
						msgLogger.logp(Level.WARNING, CLASSNAME, "broadcastEventAtDeploymentManager", var10);
						Routines.logException(trcLogger, CLASSNAME, "broadcastEventAtDeploymentManager", Level.SEVERE,
								var16.getMessage(), var16);
					}
				}
			} catch (Exception var17) {
				msgLogger.logp(Level.WARNING, CLASSNAME, "broadcastEventAtDeploymentManager", var10);
				Routines.logException(trcLogger, CLASSNAME, "broadcastEventAtDeploymentManager", Level.SEVERE,
						var17.getMessage(), var17);
			}

			this.logFailedNotifications(var1, var9);
			Routines.exitMethod(trcLogger, CLASSNAME, "broadcastEventAtDeploymentManager", Level.FINEST);
		}
	}

	public void broadcastEventAtNode(String var1, EventDataWrapper var2) {
		Routines.enterMethod(trcLogger, CLASSNAME, "broadcastEventAtNode", Level.FINEST);
		if (!isRunningOnManagedProcOrNodeAgent() && !isRegisteredWithAdminAgentMode()) {
			Routines.exitResultMethod(trcLogger, CLASSNAME, "broadcastEventAtNode", Level.FINEST, "No action to take");
		} else {
			Vector var4 = this.getEventListeners(var1);
			if (var4 != null) {
				Iterator var5 = var4.iterator();

				while (var5.hasNext()) {
					EventHandler var6 = (EventHandler) var5.next();
					var6.processEvent(var1, var2);
				}
			}

			Routines.exitMethod(trcLogger, CLASSNAME, "broadcastEventAtNode", Level.FINEST);
		}
	}

	public void logEventDetails(String var1, String var2, EventDataWrapper var3, Logger var4) {
		Routines.enterMethod(var4, CLASSNAME, "logEventDetails", Level.FINEST);
		StringBuffer var6 = new StringBuffer("Event Information\n");
		var6.append("\tEvent type: " + var1).append("\n");
		var6.append("\tEvent message: " + var2).append("\n");
		if (var3 != null) {
			var6.append("\tEvent data: \n");
			Object[] var7 = var3.getObjects();

			for (int var8 = 0; var8 < var7.length; ++var8) {
				String var9 = var7[var8].getClass().getName();
				var6.append("\t\tObject[").append(var8).append("] class: ").append(var9).append("\n");
				var6.append("\t\tObject[").append(var8).append("] value: ").append(var7[var8]).append("\n");
			}
		} else {
			var6.append("\tEvent data: (null)").append("\n");
		}

		Routines.logMessage(var4, CLASSNAME, "logEventDetails", Level.FINER, var6.toString());
		Routines.exitMethod(var4, CLASSNAME, "logEventDetails", Level.FINEST);
	}

	private boolean logFailedNotifications(String var1, Set var2) {
		Routines.enterMethod(trcLogger, CLASSNAME, "logFailedNotifications", Level.FINEST);
		boolean var4 = false;
		HashSet var5 = new HashSet();
		String var6 = "DYNAMIC_RELOAD_MANAGED_NODE_UNAVAILABLE";
		if (isAdminAgentMode) {
			var6 = "DYNAMIC_RELOAD_REGISTERED_PROFILE_UNAVAILABLE";
		}

		try {
			AdminService var7 = AdminServiceFactory.getAdminService();
			ConfigService var8 = ConfigServiceFactory.getConfigService();
			Session var9 = new Session();
			String var10 = var7.getCellName();
			ObjectName var11 = var8.resolve(var9, "Cell=" + var10)[0];
			ObjectName var12 = ConfigServiceHelper.createObjectName((ConfigDataId) null, "Node");
			ObjectName[] var13 = var8.queryConfigObjects(var9, var11, var12, (QueryExp) null);

			String var15;
			for (int var14 = 0; var14 < var13.length; ++var14) {
				var15 = var13[var14].getKeyProperty("_Websphere_Config_Data_Display_Name");
				ObjectName var16 = ConfigServiceHelper.createObjectName((ConfigDataId) null, "Server");
				ObjectName[] var17 = var8.queryConfigObjects(var9, var13[var14], var16, (QueryExp) null);

				for (int var18 = 0; var18 < var17.length; ++var18) {
					String var19 = var17[var18].getKeyProperty("_Websphere_Config_Data_Display_Name");
					if (!var10.equals(var7.getCellName()) || !var15.equals(var7.getNodeName())
							|| !var19.equals(var7.getProcessName())) {
						String var20 = "cell=" + var10 + "," + "node=" + var15 + "," + "process=" + var19;
						var5.add(var20);
						Routines.logMessage(trcLogger, CLASSNAME, "logFailedNotifications", Level.FINE,
								"Discovered config repository node (" + var20 + ")");
					}
				}
			}

			var8.discard(var9);
			Iterator var22 = var2.iterator();

			while (var22.hasNext()) {
				ObjectName var23 = (ObjectName) var22.next();
				String var24 = "cell=" + var23.getKeyProperty("cell") + "," + "node=" + var23.getKeyProperty("node")
						+ "," + "process=" + var23.getKeyProperty("process");
				var5.remove(var24);
			}

			var22 = var5.iterator();

			while (var22.hasNext()) {
				var4 = true;
				var15 = (String) var22.next();
				msgLogger.logp(Level.WARNING, CLASSNAME, "logFailedNotifications", var6, new Object[]{var15, var1});
			}
		} catch (Exception var21) {
			var4 = true;
			Routines.logException(trcLogger, CLASSNAME, "logFailedNotifications", Level.SEVERE, var21.getMessage(),
					var21);
		}

		Routines.exitMethod(trcLogger, CLASSNAME, "logFailedNotifications", Level.FINEST);
		return var4;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
		singletonObj = null;
		determineWASRuntimeContext();
	}
}