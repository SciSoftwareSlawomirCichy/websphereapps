package com.ibm.ws.wim.configmodel;

public interface SPIBridgeRepositoryType extends ProfileRepositoryType {
	String getWMMAdapterClassName();

	void setWMMAdapterClassName(String var1);
}