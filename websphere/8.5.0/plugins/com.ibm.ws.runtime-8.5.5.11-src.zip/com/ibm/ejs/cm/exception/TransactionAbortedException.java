package com.ibm.ejs.cm.exception;

import com.ibm.ejs.cm.portability.PortableSQLException;

public class TransactionAbortedException extends PortableSQLException {
	private static final long serialVersionUID = -5705875249175778354L;

	public TransactionAbortedException() {
		super("JTS/JTA transaction has been aborted");
	}
}