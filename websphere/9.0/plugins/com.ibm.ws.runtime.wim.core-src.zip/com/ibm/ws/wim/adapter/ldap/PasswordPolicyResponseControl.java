package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.ws.wim.util.ASN1Tag;
import com.ibm.ws.wim.util.BERDecoder;
import javax.naming.ldap.Control;

public class PasswordPolicyResponseControl implements Control {
	private static final String[] errorText = new String[]{"change after reset"};
	private static final long serialVersionUID = -1214676539512663676L;
	public static final String OID = "1.3.6.1.4.1.42.2.27.8.5.1";
	private static final int WARNING_TAG = 0;
	private static final int ERROR_TAG = 1;
	public static final int UNKNOWN = -1;
	public static final int PWD_EXPIRED = 0;
	public static final int ACCOUNT_LOCKED = 1;
	public static final int CHANGE_AFTER_RESET = 2;
	public static final int PWD_MOD_NOT_ALLOWED = 3;
	public static final int MUST_SUPPLY_OLD_PWD = 4;
	public static final int INVALID_PWD_SYNTAX = 5;
	public static final int PWD_TOO_SHORT = 6;
	public static final int PWD_TOO_YOUNG = 7;
	public static final int PWD_IN_HISTORY = 8;
	private static final int TIME_EXP_TAG = 0;
	private static final int OPENLDAP_WARNING = 160;
	private static final int GRACE_LOGINS_TAG = 1;
	private boolean criticality;
	private int errorValue = -1;
	private int graceLogins = -1;
	private int timeBeforeExp = -1;
	boolean errorRead;
	boolean warningRead;
	private byte[] berValue;

	public PasswordPolicyResponseControl(Control var1) throws WIMException {
		this.criticality = var1.isCritical();
		this.berValue = var1.getEncodedValue();
		if (this.berValue != null) {
			BERDecoder var2 = new BERDecoder(this.berValue);
			boolean var3 = false;

			try {
				int[] var4 = new int[]{0, 1};
				var2.decodeSequenceOf();
				int var5 = var2.peekNextTag();
				int var6 = var2.getActualTag();
				var5 = var2.decodeChoice(var4);
				int var7 = ASN1Tag.getTagNumber(var5);

				try {
					var2.decodeExplicit(var5);
				} catch (Exception var11) {
					var3 = true;
				}

				if (!var3) {
					if (var7 == 1) {
						try {
							this.readInError(var2);
						} catch (Exception var10) {
							BERDecoder var9 = new BERDecoder(this.berValue);
							var9.decodeSequenceOf();
							var5 = var9.peekNextTag();
							var5 = var9.decodeChoice(var4);
							this.errorValue = var9.decodeExplicitAsInt(var5);
							this.errorRead = true;
						}
					} else if (var7 == 0) {
						this.readInWarning(var2, var6);
					}
				}

			} catch (Exception var12) {
				throw new WIMException(var12);
			}
		}
	}

	public boolean isError() {
		return this.errorRead;
	}

	public boolean isWarning() {
		return this.warningRead;
	}

	public int getGraceLoginsLeft() {
		return this.graceLogins;
	}

	public int getTimeBeforeExpire() {
		return this.timeBeforeExp;
	}

	public int getError() {
		return this.errorValue;
	}

	private void readInWarning(BERDecoder var1, int var2) throws Exception {
		int[] var3 = new int[]{0, 1};
		int var4 = var1.decodeChoice(var3);
		int var5 = ASN1Tag.getTagNumber(var4);
		int var6 = 0;
		if (var2 == 160) {
			var6 = var1.decodeExplicitAsInt(var4);
		} else {
			var1.decodeExplicit(var4);
		}

		if (var5 == 0) {
			if (var2 == 160) {
				this.timeBeforeExp = var6;
			} else {
				this.timeBeforeExp = var1.decodeIntegerAsInt();
			}
		} else if (var5 == 1) {
			if (var2 == 160) {
				this.graceLogins = var6;
			} else {
				this.graceLogins = var1.decodeIntegerAsInt();
			}
		}

		this.warningRead = true;
	}

	private void readInError(BERDecoder var1) throws Exception {
		this.errorValue = var1.decodeEnumeration();
		this.errorRead = true;
	}

	public byte[] getEncodedValue() {
		return this.berValue;
	}

	public String getID() {
		return "1.3.6.1.4.1.42.2.27.8.5.1";
	}

	public boolean isCritical() {
		return this.criticality;
	}
}