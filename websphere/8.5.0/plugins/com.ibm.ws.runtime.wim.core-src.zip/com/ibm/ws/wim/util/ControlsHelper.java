package com.ibm.ws.wim.util;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.util.SDOHelper;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ControlsHelper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";

	public static Map getControlMap(DataGraph var0) {
		HashMap var1 = new HashMap();
		List var2 = var0.getRootObject().getDataObject("Root").getList("controls");
		if (var2 != null) {
			for (int var3 = 0; var3 < var2.size(); ++var3) {
				DataObject var4 = (DataObject) var2.get(var3);
				String var5 = var4.getType().getName();
				if (var1.get(var5) == null) {
					var1.put(var5, var4);
				}
			}
		}

		return var1;
	}

	public static Map getControlMap(DataObject var0) {
		HashMap var1 = new HashMap();
		List var2 = var0.getList("controls");
		if (var2 != null) {
			for (int var3 = 0; var3 < var2.size(); ++var3) {
				DataObject var4 = (DataObject) var2.get(var3);
				String var5 = var4.getType().getName();
				if (var1.get(var5) == null) {
					var1.put(var5, var4);
				}
			}
		}

		return var1;
	}

	public static String[] getPropertyNames(DataObject var0, boolean var1) {
		String[] var2 = new String[0];
		if (var0 != null) {
			List var3 = var0.getList("properties");
			if (var1) {
				var3.add("objectClass");
			}

			var2 = (String[]) ((String[]) var3.toArray(var2));
		}

		return var2;
	}

	public static String[] getPropertyNames(DataObject var0) {
		String[] var1 = new String[0];
		if (var0 != null) {
			List var2 = var0.getList("properties");
			var1 = (String[]) ((String[]) var2.toArray(var1));
		}

		return var1;
	}

	public static void removeControls(DataGraph var0) {
		List var1 = var0.getRootObject().getDataObject("Root").getList("controls");

		while (var1 != null && var1.size() > 0) {
			((DataObject) var1.get(0)).delete();
		}

	}

	public static void removeControls(DataObject var0) {
		List var1 = var0.getList("controls");

		while (var1 != null && var1.size() > 0) {
			((DataObject) var1.get(0)).delete();
		}

	}

	public static DataObject buildDGwithResponseControl(String var0) throws WIMException {
		DataObject var1 = SDOHelper.createRootDataObject();
		DataObject var2 = var1.createDataObject("controls", "http://www.ibm.com/websphere/wim", "ResponseControl");
		var2.setString("ticket", var0);
		var2.setBoolean("complete", false);
		return var1;
	}
}