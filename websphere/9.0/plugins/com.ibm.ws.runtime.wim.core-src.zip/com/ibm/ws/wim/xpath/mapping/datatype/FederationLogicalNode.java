package com.ibm.ws.wim.xpath.mapping.datatype;

public class FederationLogicalNode extends LogicalNode {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";

	public short getNodeType() {
		return 4;
	}
}