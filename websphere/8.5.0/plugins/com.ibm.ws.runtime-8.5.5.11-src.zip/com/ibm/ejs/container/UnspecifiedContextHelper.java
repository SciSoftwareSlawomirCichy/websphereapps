package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.tx.jta.embeddable.EmbeddableTransactionManagerFactory;
import com.ibm.websphere.csi.CSIException;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.LocalTransaction.LocalTransactionCurrent;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import com.ibm.ws.uow.embeddable.SystemException;
import com.ibm.ws.uow.embeddable.UOWToken;
import java.util.Map;

class UnspecifiedContextHelper {
	private static final String CLASS_NAME = UnspecifiedContextHelper.class.getName();
	private static final TraceComponent tc;
	private final BeanO ivBeanO;
	private final boolean ivPushAllContexts;
	private UOWToken ivUowToken;
	protected LocalTransactionCurrent ivLocalTransactionCurrent;
	private EJBThreadData ivThreadData;
	private boolean ivPopContexts;
	private int ivSavedLifecycleMethodContextIndex;
	private Map<String, Object> ivSavedLifecycleContextData;

	UnspecifiedContextHelper(BeanO beanO) {
		this(beanO, false);
	}

	UnspecifiedContextHelper(BeanO beanO, boolean pushAllContexts) {
		this.ivBeanO = beanO;
		this.ivPushAllContexts = pushAllContexts;
	}

	void begin(boolean beginLocalTx) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "begin");
		}

		this.ivThreadData = EJSContainer.getThreadData();
		if (this.ivPushAllContexts) {
			this.ivThreadData.pushContexts(this.ivBeanO);
		} else {
			this.ivThreadData.pushCallbackBeanO(this.ivBeanO);
		}

		this.ivPopContexts = true;
		this.ivSavedLifecycleContextData = this.ivThreadData.ivLifecycleContextData;
		this.ivThreadData.ivLifecycleContextData = null;
		this.ivSavedLifecycleMethodContextIndex = this.ivThreadData.ivLifecycleMethodContextIndex;
		this.ivThreadData.ivLifecycleMethodContextIndex = this.ivThreadData.ivEJSDeployedSupportContext
				.getContextIndex();
		if (beginLocalTx && this.ivBeanO.home.beanMetaData.ivModuleVersion >= 30) {
			if (this.ivUowToken != null) {
				throw new CSIException("Cannot begin until prior TX is resumed");
			}

			UOWCurrent uowCurrent = EmbeddableTransactionManagerFactory.getUOWCurrent();
			if (uowCurrent != null) {
				try {
					this.ivUowToken = this.ivBeanO.container.ivUOWManager.suspend();
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "Suspending TX/LTC cntxt: " + this.ivUowToken);
					}
				} catch (SystemException var5) {
					FFDCFilter.processException(var5, CLASS_NAME + ".begin", "140", this);
					throw new CSIException("Cannot begin due to failure in suspend.", var5);
				}
			}

			this.ivLocalTransactionCurrent = EmbeddableTransactionManagerFactory.getLocalTransactionCurrent();
			this.ivLocalTransactionCurrent.begin();
			if (isTraceOn && tc.isEventEnabled()) {
				LocalTransactionCoordinator lCoord = this.ivLocalTransactionCurrent.getLocalTranCoord();
				if (lCoord != null) {
					Tr.event(tc, "Began LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
				} else {
					Tr.event(tc, "Began LTC cntxt: null Coordinator!");
				}
			}

			this.ivBeanO.container.getCurrentTx((SynchronizationRegistryUOWScope) this.getUOWCoordinator(), true);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			if (this.ivUowToken != null) {
				Tr.exit(tc, "begin method suspended UOW with UOWHandle = " + this.ivUowToken);
			} else {
				Tr.exit(tc, "begin method did NOT suspend any UOW.");
			}
		}

	}

	void complete(boolean commit) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "complete called with commit argument set to: " + commit);
		}

		if (this.ivPopContexts) {
			if (this.ivPushAllContexts) {
				this.ivThreadData.popContexts();
			} else {
				this.ivThreadData.popCallbackBeanO();
			}

			this.ivThreadData.ivLifecycleContextData = this.ivSavedLifecycleContextData;
			this.ivThreadData.ivLifecycleMethodContextIndex = this.ivSavedLifecycleMethodContextIndex;
			this.ivThreadData = null;
		}

		boolean var12 = false;

		try {
			var12 = true;
			if (this.ivLocalTransactionCurrent != null) {
				int endMode = commit ? 0 : 1;
				if (isTraceOn && tc.isEventEnabled()) {
					LocalTransactionCoordinator lCoord = this.ivLocalTransactionCurrent.getLocalTranCoord();
					if (lCoord != null) {
						Tr.event(tc, "Completing LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
					} else {
						Tr.event(tc, "Completing LTC cntxt: null Coordinator!");
					}
				}

				this.ivLocalTransactionCurrent.complete(endMode);
				var12 = false;
			} else {
				var12 = false;
			}
		} catch (Throwable var15) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "unspecified UOW completion failure: " + var15, var15);
			}

			throw new CSIException("unspecified UOW completion failure: " + var15, var15);
		} finally {
			if (var12) {
				if (this.ivUowToken != null) {
					if (isTraceOn) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "complete is resuming UOW with UOWToken = " + this.ivUowToken);
						}

						if (tc.isEventEnabled()) {
							Tr.event(tc, "Resuming TX/LTC cntxt: " + this.ivUowToken);
						}
					}

					UOWToken token = this.ivUowToken;
					this.ivUowToken = null;

					try {
						this.ivBeanO.container.ivUOWManager.resume(token);
					} catch (SystemException var13) {
						FFDCFilter.processException(var13, CLASS_NAME + ".complete", "216", this);
						throw new CSIException("Cannot complete due to failure in resume.", var13);
					}
				}

			}
		}

		if (this.ivUowToken != null) {
			if (isTraceOn) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "complete is resuming UOW with UOWToken = " + this.ivUowToken);
				}

				if (tc.isEventEnabled()) {
					Tr.event(tc, "Resuming TX/LTC cntxt: " + this.ivUowToken);
				}
			}

			UOWToken token = this.ivUowToken;
			this.ivUowToken = null;

			try {
				this.ivBeanO.container.ivUOWManager.resume(token);
			} catch (SystemException var14) {
				FFDCFilter.processException(var14, CLASS_NAME + ".complete", "216", this);
				throw new CSIException("Cannot complete due to failure in resume.", var14);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "complete");
		}

	}

	private UOWCoordinator getUOWCoordinator() {
		UOWCoordinator uowCoord = null;
		UOWCurrent uowCurrent = EmbeddableTransactionManagerFactory.getUOWCurrent();
		if (uowCurrent != null) {
			uowCoord = uowCurrent.getUOWCoord();
		}

		return uowCoord;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}