package com.ibm.ws.wim.dao.schema;

import com.ibm.websphere.wim.common.RepositoryProperty;
import java.util.Set;

public class DBRepositoryProperty extends RepositoryProperty {
	private Integer propId;
	private String className;
	private String metadataName;
	private boolean readOnly = false;
	private boolean composite = false;
	private String description;
	private String applicationId;
	private String parentCompositeName;
	private boolean requiredInComposite = false;
	private boolean keyInComposite = false;
	private String keyComponentName;
	private Set componentPropertyNames;

	public Integer getPropId() {
		return this.propId;
	}

	public void setPropId(Integer var1) {
		this.propId = var1;
	}

	public String getKeyComponentName() {
		return this.keyComponentName;
	}

	public boolean isComposite() {
		return this.composite;
	}

	public boolean isKeyInComposite() {
		return this.keyInComposite;
	}

	public boolean isRequiredInComposite() {
		return this.requiredInComposite;
	}

	public void setComposite(boolean var1) {
		this.composite = var1;
	}

	public void setKeyComponentName(String var1) {
		this.keyComponentName = var1;
	}

	public void setKeyInComposite(boolean var1) {
		this.keyInComposite = var1;
	}

	public void setRequiredInComposite(boolean var1) {
		this.requiredInComposite = var1;
	}

	public String getClassName() {
		return this.className;
	}

	public boolean isReadOnly() {
		return this.readOnly;
	}

	public void setClassName(String var1) {
		this.className = var1;
	}

	public void setReadOnly(boolean var1) {
		this.readOnly = var1;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String var1) {
		this.description = var1;
	}

	public String getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(String var1) {
		this.applicationId = var1;
	}

	public String getMetadataName() {
		return this.metadataName;
	}

	public void setMetadataName(String var1) {
		this.metadataName = var1;
	}

	public Set getComponentPropertyNames() {
		return this.componentPropertyNames;
	}

	public void setComponentPropertyNames(Set var1) {
		this.componentPropertyNames = var1;
	}

	public String getParentCompositeName() {
		return this.parentCompositeName;
	}

	public void setParentCompositeName(String var1) {
		this.parentCompositeName = var1;
	}
}