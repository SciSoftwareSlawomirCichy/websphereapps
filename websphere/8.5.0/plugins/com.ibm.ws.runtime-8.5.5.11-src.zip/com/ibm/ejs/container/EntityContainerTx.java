package com.ibm.ejs.container;

import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.cpi.CPIException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.InconsistentAccessIntentException;
import com.ibm.websphere.csi.PMTxInfo;
import javax.transaction.Synchronization;

public interface EntityContainerTx extends PMTxInfo {
	AccessIntent cacheAccessIntent(BeanId var1, AccessIntent var2) throws InconsistentAccessIntentException;

	AccessIntent getCachedAccessIntent(BeanId var1);

	void flush() throws CSIException;

	void setRollbackOnly();

	void registerSynchronization(Synchronization var1) throws CPIException;

	void enlistContainerSync(Synchronization var1) throws CPIException;

	ContainerAS getContainerAS();

	ContainerTx getCurrentTx() throws CSITransactionRolledbackException;

	boolean beganInThisScope();

	boolean isFlushRequired();
}