package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_cs extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: Byl přidán formátovací modul FFDC {0}."},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Stroj pro analýzu používající databázi: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: Nepodařilo se převést stroj pro analýzu:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: Byl přidán kolektor dat FFDC {0}."},
			{"FFDCDataCollectorRemoved", "FFDC1012I: Byl odebrán kolektor dat FFDC {0}."},
			{"FFDCEmittedOnSysErr",
					"FFDC1004I: Událost FFDC byla vydána v rámci systémového chybového výstupu: {0} {1}."},
			{"FFDCFailSafeErrChk", "FFDC1002W: Modul FFDC pracuje v režimu překonání selhání. Vyhledejte chyby: {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: Byl přidán modul pro předávání událostí FFDC {0}."},
			{"FFDCForwarderRemoved", "FFDC1014I: Byl odebrán modul pro předávání událostí FFDC {0}."},
			{"FFDCIncidentEmitted", "FFDC1003I: Událost FFDC byla vydána v umístění {0} {1} {2}."},
			{"FFDCProviderAborted",
					"FFDC1000I: Činnost poskytovatele FFDC {0} byla předčasně ukončena. Výjimka je uvedena dále."},
			{"FFDCProviderAbortedE", "FFDC1001I: Činnost poskytovatele FFDC byla předčasně ukončena s výjimkou {0}."},
			{"FFDCProviderException", "FFDC1008I: Výjimka poskytovatele FFDC:"},
			{"FFDCProviderInstalled", "FFDC1007I: Byl instalován poskytovatel FFDC: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: Byl odebrán formátovací modul FFDC {0}."}};

	public Object[][] getContents() {
		return resources;
	}
}