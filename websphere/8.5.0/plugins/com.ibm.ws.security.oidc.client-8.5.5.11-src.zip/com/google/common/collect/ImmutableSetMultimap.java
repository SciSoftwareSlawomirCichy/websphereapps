package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMultimap.FieldSettersHolder;
import com.google.common.collect.ImmutableSetMultimap.Builder;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(serializable = true, emulated = true)
public class ImmutableSetMultimap<K, V> extends ImmutableMultimap<K, V> implements SetMultimap<K, V> {
	private final transient ImmutableSortedSet<V> emptySet;
	private transient ImmutableSetMultimap<V, K> inverse;
	private transient ImmutableSet<Entry<K, V>> entries;
	@GwtIncompatible("not needed in emulated source.")
	private static final long serialVersionUID = 0L;

	public static <K, V> ImmutableSetMultimap<K, V> of() {
		return EmptyImmutableSetMultimap.INSTANCE;
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		return builder.build();
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		builder.put(k2, v2);
		return builder.build();
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		builder.put(k2, v2);
		builder.put(k3, v3);
		return builder.build();
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		builder.put(k2, v2);
		builder.put(k3, v3);
		builder.put(k4, v4);
		return builder.build();
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		builder.put(k2, v2);
		builder.put(k3, v3);
		builder.put(k4, v4);
		builder.put(k5, v5);
		return builder.build();
	}

	public static <K, V> Builder<K, V> builder() {
		return new Builder();
	}

	public static <K, V> ImmutableSetMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap) {
		return copyOf(multimap, (Comparator) null);
	}

	private static <K, V> ImmutableSetMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap,
			Comparator<? super V> valueComparator) {
		Preconditions.checkNotNull(multimap);
		if (multimap.isEmpty() && valueComparator == null) {
			return of();
		} else {
			if (multimap instanceof ImmutableSetMultimap) {
				ImmutableSetMultimap<K, V> kvMultimap = (ImmutableSetMultimap) multimap;
				if (!kvMultimap.isPartialView()) {
					return kvMultimap;
				}
			}

			com.google.common.collect.ImmutableMap.Builder<K, ImmutableSet<V>> builder = ImmutableMap.builder();
			int size = 0;
			Iterator i$ = multimap.asMap().entrySet().iterator();

			while (i$.hasNext()) {
				Entry<? extends K, ? extends Collection<? extends V>> entry = (Entry) i$.next();
				K key = entry.getKey();
				Collection<? extends V> values = (Collection) entry.getValue();
				ImmutableSet<V> set = valueComparator == null
						? ImmutableSet.copyOf(values)
						: ImmutableSortedSet.copyOf(valueComparator, values);
				if (!((ImmutableSet) set).isEmpty()) {
					builder.put(key, set);
					size += ((ImmutableSet) set).size();
				}
			}

			return new ImmutableSetMultimap(builder.build(), size, valueComparator);
		}
	}

	ImmutableSetMultimap(ImmutableMap<K, ImmutableSet<V>> map, int size,
			@Nullable Comparator<? super V> valueComparator) {
		super(map, size);
		this.emptySet = valueComparator == null ? null : ImmutableSortedSet.emptySet(valueComparator);
	}

	public ImmutableSet<V> get(@Nullable K key) {
		ImmutableSet<V> set = (ImmutableSet) this.map.get(key);
		if (set != null) {
			return set;
		} else {
			return (ImmutableSet) (this.emptySet != null ? this.emptySet : ImmutableSet.of());
		}
	}

	public ImmutableSetMultimap<V, K> inverse() {
		ImmutableSetMultimap<V, K> result = this.inverse;
		return result == null ? (this.inverse = this.invert()) : result;
	}

	private ImmutableSetMultimap<V, K> invert() {
		Builder<V, K> builder = builder();
		Iterator i$ = this.entries().iterator();

		while (i$.hasNext()) {
			Entry<K, V> entry = (Entry) i$.next();
			builder.put(entry.getValue(), entry.getKey());
		}

		ImmutableSetMultimap<V, K> invertedMultimap = builder.build();
		invertedMultimap.inverse = this;
		return invertedMultimap;
	}

	@Deprecated
	public ImmutableSet<V> removeAll(Object key) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public ImmutableSet<V> replaceValues(K key, Iterable<? extends V> values) {
		throw new UnsupportedOperationException();
	}

	public ImmutableSet<Entry<K, V>> entries() {
		ImmutableSet<Entry<K, V>> result = this.entries;
		return result == null ? (this.entries = ImmutableSet.copyOf(super.entries())) : result;
	}

	@GwtIncompatible("java.io.ObjectOutputStream")
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		Serialization.writeMultimap(this, stream);
	}

	@GwtIncompatible("java.io.ObjectInputStream")
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		int keyCount = stream.readInt();
		if (keyCount < 0) {
			throw new InvalidObjectException("Invalid key count " + keyCount);
		} else {
			com.google.common.collect.ImmutableMap.Builder<Object, ImmutableSet<Object>> builder = ImmutableMap
					.builder();
			int tmpSize = 0;

			for (int i = 0; i < keyCount; ++i) {
				Object key = stream.readObject();
				int valueCount = stream.readInt();
				if (valueCount <= 0) {
					throw new InvalidObjectException("Invalid value count " + valueCount);
				}

				Object[] array = new Object[valueCount];

				for (int j = 0; j < valueCount; ++j) {
					array[j] = stream.readObject();
				}

				ImmutableSet<Object> valueSet = ImmutableSet.copyOf(array);
				if (valueSet.size() != array.length) {
					throw new InvalidObjectException("Duplicate key-value pairs exist for key " + key);
				}

				builder.put(key, valueSet);
				tmpSize += valueCount;
			}

			ImmutableMap tmpMap;
			try {
				tmpMap = builder.build();
			} catch (IllegalArgumentException var10) {
				throw (InvalidObjectException) (new InvalidObjectException(var10.getMessage())).initCause(var10);
			}

			FieldSettersHolder.MAP_FIELD_SETTER.set(this, tmpMap);
			FieldSettersHolder.SIZE_FIELD_SETTER.set(this, tmpSize);
		}
	}
}