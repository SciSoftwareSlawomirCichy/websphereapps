package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableSortedMap.1;import com.google.common.collect.ImmutableSortedMap.1EntrySet;
import com.google.common.collect.ImmutableSortedMap.Builder;
import com.google.common.collect.ImmutableSortedMap.SerializedForm;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.NavigableMap;
import java.util.SortedMap;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
public final class ImmutableSortedMap<K, V> extends ImmutableSortedMapFauxverideShim<K, V>
		implements
			NavigableMap<K, V> {
	private static final Comparator<Comparable> NATURAL_ORDER = Ordering.natural();
	private static final ImmutableSortedMap<Comparable, Object> NATURAL_EMPTY_MAP = new ImmutableSortedMap(
			ImmutableSortedSet.emptySet(Ordering.natural()), ImmutableList.of());
	private final transient RegularImmutableSortedSet<K> keySet;
	private final transient ImmutableList<V> valueList;
	private transient ImmutableSortedMap<K, V> descendingMap;
	private static final long serialVersionUID = 0L;

	static <K, V> ImmutableSortedMap<K, V> emptyMap(Comparator<? super K> comparator) {
		return Ordering.natural().equals(comparator)
				? of()
				: new ImmutableSortedMap(ImmutableSortedSet.emptySet(comparator), ImmutableList.of());
	}

	public static <K, V> ImmutableSortedMap<K, V> of() {
		return NATURAL_EMPTY_MAP;
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1) {
		return of(Ordering.natural(), k1, v1);
	}

	private static <K, V> ImmutableSortedMap<K, V> of(Comparator<? super K> comparator, K k1, V v1) {
		return new ImmutableSortedMap(new RegularImmutableSortedSet(ImmutableList.of(k1),
				(Comparator) Preconditions.checkNotNull(comparator)), ImmutableList.of(v1));
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2) {
		return ofEntries(entryOf(k1, v1), entryOf(k2, v2));
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		return ofEntries(entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3));
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3,
			K k4, V v4) {
		return ofEntries(entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4));
	}

	public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3,
			K k4, V v4, K k5, V v5) {
		return ofEntries(entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5));
	}

	private static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> ofEntries(Entry... entries) {
		return fromEntries(Ordering.natural(), false, entries, entries.length);
	}

	public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map) {
		Ordering<K> naturalOrder = (Ordering) NATURAL_ORDER;
		return copyOfInternal(map, naturalOrder);
	}

	public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map,
			Comparator<? super K> comparator) {
		return copyOfInternal(map, (Comparator) Preconditions.checkNotNull(comparator));
	}

	@Beta
	public static <K, V> ImmutableSortedMap<K, V> copyOf(Iterable<? extends Entry<? extends K, ? extends V>> entries) {
		Ordering<K> naturalOrder = (Ordering) NATURAL_ORDER;
		return copyOf((Iterable) entries, naturalOrder);
	}

	@Beta
	public static <K, V> ImmutableSortedMap<K, V> copyOf(Iterable<? extends Entry<? extends K, ? extends V>> entries,
			Comparator<? super K> comparator) {
		return fromEntries((Comparator) Preconditions.checkNotNull(comparator), false, entries);
	}

	public static <K, V> ImmutableSortedMap<K, V> copyOfSorted(SortedMap<K, ? extends V> map) {
		Comparator<? super K> comparator = map.comparator();
		if (comparator == null) {
			comparator = NATURAL_ORDER;
		}

		if (map instanceof ImmutableSortedMap) {
			ImmutableSortedMap<K, V> kvMap = (ImmutableSortedMap) map;
			if (!kvMap.isPartialView()) {
				return kvMap;
			}
		}

		return fromEntries(comparator, true, map.entrySet());
	}

	private static <K, V> ImmutableSortedMap<K, V> copyOfInternal(Map<? extends K, ? extends V> map,
			Comparator<? super K> comparator) {
		boolean sameComparator = false;
		if (map instanceof SortedMap) {
			SortedMap<?, ?> sortedMap = (SortedMap) map;
			Comparator<?> comparator2 = sortedMap.comparator();
			sameComparator = comparator2 == null ? comparator == NATURAL_ORDER : comparator.equals(comparator2);
		}

		if (sameComparator && map instanceof ImmutableSortedMap) {
			ImmutableSortedMap<K, V> kvMap = (ImmutableSortedMap) map;
			if (!kvMap.isPartialView()) {
				return kvMap;
			}
		}

		return fromEntries(comparator, sameComparator, map.entrySet());
	}

	private static <K, V> ImmutableSortedMap<K, V> fromEntries(Comparator<? super K> comparator, boolean sameComparator,
			Iterable<? extends Entry<? extends K, ? extends V>> entries) {
		Entry<K, V>[] entryArray = (Entry[]) ((Entry[]) Iterables.toArray(entries, EMPTY_ENTRY_ARRAY));
		return fromEntries(comparator, sameComparator, entryArray, entryArray.length);
	}

	private static <K, V> ImmutableSortedMap<K, V> fromEntries(Comparator<? super K> comparator, boolean sameComparator, Entry<K, V>[] entryArray, int size) {
      switch(size) {
      case 0:
         return emptyMap(comparator);
      case 1:
         return of(comparator, entryArray[0].getKey(), entryArray[0].getValue());
      default:
         Object[] keys = new Object[size];
         Object[] values = new Object[size];
         Object key;
         if (sameComparator) {
            for(int i = 0; i < size; ++i) {
               Object key = entryArray[i].getKey();
               key = entryArray[i].getValue();
               CollectPreconditions.checkEntryNotNull(key, key);
               keys[i] = key;
               values[i] = key;
            }
         } else {
            Arrays.sort(entryArray, 0, size, new 1(comparator));
            K prevKey = entryArray[0].getKey();
            keys[0] = prevKey;
            values[0] = entryArray[0].getValue();
            CollectPreconditions.checkEntryNotNull(keys[0], values[0]);

            for(int i = 1; i < size; ++i) {
               key = entryArray[i].getKey();
               V value = entryArray[i].getValue();
               CollectPreconditions.checkEntryNotNull(key, value);
               keys[i] = key;
               values[i] = value;
               checkNoConflict(comparator.compare(prevKey, key) != 0, "key", entryArray[i - 1], entryArray[i]);
               prevKey = key;
            }
         }

         return new ImmutableSortedMap(new RegularImmutableSortedSet(ImmutableList.asImmutableList(keys), comparator), ImmutableList.asImmutableList(values));
      }
   }

	public static <K extends Comparable<?>, V> Builder<K, V> naturalOrder() {
		return new Builder(Ordering.natural());
	}

	public static <K, V> Builder<K, V> orderedBy(Comparator<K> comparator) {
		return new Builder(comparator);
	}

	public static <K extends Comparable<?>, V> Builder<K, V> reverseOrder() {
		return new Builder(Ordering.natural().reverse());
	}

	ImmutableSortedMap(RegularImmutableSortedSet<K> keySet, ImmutableList<V> valueList) {
		this(keySet, valueList, (ImmutableSortedMap) null);
	}

	ImmutableSortedMap(RegularImmutableSortedSet<K> keySet, ImmutableList<V> valueList,
			ImmutableSortedMap<K, V> descendingMap) {
		this.keySet = keySet;
		this.valueList = valueList;
		this.descendingMap = descendingMap;
	}

	public int size() {
		return this.valueList.size();
	}

	public V get(@NullableDecl Object key) {
		int index = this.keySet.indexOf(key);
		return index == -1 ? null : this.valueList.get(index);
	}

	boolean isPartialView() {
		return this.keySet.isPartialView() || this.valueList.isPartialView();
	}

	public ImmutableSet<Entry<K, V>> entrySet() {
		return super.entrySet();
	}

	ImmutableSet<Entry<K, V>> createEntrySet() {
      return (ImmutableSet)(this.isEmpty() ? ImmutableSet.of() : new 1EntrySet(this));
   }

	public ImmutableSortedSet<K> keySet() {
		return this.keySet;
	}

	ImmutableSet<K> createKeySet() {
		throw new AssertionError("should never be called");
	}

	public ImmutableCollection<V> values() {
		return this.valueList;
	}

	ImmutableCollection<V> createValues() {
		throw new AssertionError("should never be called");
	}

	public Comparator<? super K> comparator() {
		return this.keySet().comparator();
	}

	public K firstKey() {
		return this.keySet().first();
	}

	public K lastKey() {
		return this.keySet().last();
	}

	private ImmutableSortedMap<K, V> getSubMap(int fromIndex, int toIndex) {
		if (fromIndex == 0 && toIndex == this.size()) {
			return this;
		} else {
			return fromIndex == toIndex
					? emptyMap(this.comparator())
					: new ImmutableSortedMap(this.keySet.getSubSet(fromIndex, toIndex),
							this.valueList.subList(fromIndex, toIndex));
		}
	}

	public ImmutableSortedMap<K, V> headMap(K toKey) {
		return this.headMap(toKey, false);
	}

	public ImmutableSortedMap<K, V> headMap(K toKey, boolean inclusive) {
		return this.getSubMap(0, this.keySet.headIndex(Preconditions.checkNotNull(toKey), inclusive));
	}

	public ImmutableSortedMap<K, V> subMap(K fromKey, K toKey) {
		return this.subMap(fromKey, true, toKey, false);
	}

	public ImmutableSortedMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive) {
		Preconditions.checkNotNull(fromKey);
		Preconditions.checkNotNull(toKey);
		Preconditions.checkArgument(this.comparator().compare(fromKey, toKey) <= 0,
				"expected fromKey <= toKey but %s > %s", fromKey, toKey);
		return this.headMap(toKey, toInclusive).tailMap(fromKey, fromInclusive);
	}

	public ImmutableSortedMap<K, V> tailMap(K fromKey) {
		return this.tailMap(fromKey, true);
	}

	public ImmutableSortedMap<K, V> tailMap(K fromKey, boolean inclusive) {
		return this.getSubMap(this.keySet.tailIndex(Preconditions.checkNotNull(fromKey), inclusive), this.size());
	}

	public Entry<K, V> lowerEntry(K key) {
		return this.headMap(key, false).lastEntry();
	}

	public K lowerKey(K key) {
		return Maps.keyOrNull(this.lowerEntry(key));
	}

	public Entry<K, V> floorEntry(K key) {
		return this.headMap(key, true).lastEntry();
	}

	public K floorKey(K key) {
		return Maps.keyOrNull(this.floorEntry(key));
	}

	public Entry<K, V> ceilingEntry(K key) {
		return this.tailMap(key, true).firstEntry();
	}

	public K ceilingKey(K key) {
		return Maps.keyOrNull(this.ceilingEntry(key));
	}

	public Entry<K, V> higherEntry(K key) {
		return this.tailMap(key, false).firstEntry();
	}

	public K higherKey(K key) {
		return Maps.keyOrNull(this.higherEntry(key));
	}

	public Entry<K, V> firstEntry() {
		return this.isEmpty() ? null : (Entry) this.entrySet().asList().get(0);
	}

	public Entry<K, V> lastEntry() {
		return this.isEmpty() ? null : (Entry) this.entrySet().asList().get(this.size() - 1);
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final Entry<K, V> pollFirstEntry() {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public final Entry<K, V> pollLastEntry() {
		throw new UnsupportedOperationException();
	}

	public ImmutableSortedMap<K, V> descendingMap() {
		ImmutableSortedMap<K, V> result = this.descendingMap;
		if (result == null) {
			return this.isEmpty()
					? emptyMap(Ordering.from(this.comparator()).reverse())
					: new ImmutableSortedMap((RegularImmutableSortedSet) this.keySet.descendingSet(),
							this.valueList.reverse(), this);
		} else {
			return result;
		}
	}

	public ImmutableSortedSet<K> navigableKeySet() {
		return this.keySet;
	}

	public ImmutableSortedSet<K> descendingKeySet() {
		return this.keySet.descendingSet();
	}

	Object writeReplace() {
		return new SerializedForm(this);
	}
}