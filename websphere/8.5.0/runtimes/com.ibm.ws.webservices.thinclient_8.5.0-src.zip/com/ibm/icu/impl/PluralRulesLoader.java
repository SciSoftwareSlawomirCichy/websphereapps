package com.ibm.icu.impl;

import com.ibm.icu.text.PluralRules;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;
import java.text.ParseException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.Set;
import java.util.TreeMap;

public class PluralRulesLoader {
	private final Map<String, PluralRules> rulesIdToRules = new HashMap();
	private Map<String, String> localeIdToRulesId;
	private Map<String, ULocale> rulesIdToEquivalentULocale;
	public static final PluralRulesLoader loader = new PluralRulesLoader();

	public ULocale[] getAvailableULocales() {
		Set<String> keys = this.getLocaleIdToRulesIdMap().keySet();
		ULocale[] locales = new ULocale[keys.size()];
		int n = 0;

		for (Iterator iter = keys.iterator(); iter
				.hasNext(); locales[n++] = ULocale.createCanonical((String) iter.next())) {
			;
		}

		return locales;
	}

	public ULocale getFunctionalEquivalent(ULocale locale, boolean[] isAvailable) {
		String rulesId;
		if (isAvailable != null && isAvailable.length > 0) {
			rulesId = ULocale.canonicalize(locale.getBaseName());
			Map<String, String> idMap = this.getLocaleIdToRulesIdMap();
			isAvailable[0] = idMap.containsKey(rulesId);
		}

		rulesId = this.getRulesIdForLocale(locale);
		if (rulesId != null && rulesId.trim().length() != 0) {
			ULocale result = (ULocale) this.getRulesIdToEquivalentULocaleMap().get(rulesId);
			return result == null ? ULocale.ROOT : result;
		} else {
			return ULocale.ROOT;
		}
	}

	private Map<String, String> getLocaleIdToRulesIdMap() {
		this.checkBuildRulesIdMaps();
		return this.localeIdToRulesId;
	}

	private Map<String, ULocale> getRulesIdToEquivalentULocaleMap() {
		this.checkBuildRulesIdMaps();
		return this.rulesIdToEquivalentULocale;
	}

	private void checkBuildRulesIdMaps() {
		if (this.localeIdToRulesId == null) {
			try {
				UResourceBundle pluralb = this.getPluralBundle();
				UResourceBundle localeb = pluralb.get("locales");
				this.localeIdToRulesId = new TreeMap();
				this.rulesIdToEquivalentULocale = new HashMap();

				for (int i = 0; i < localeb.getSize(); ++i) {
					UResourceBundle b = localeb.get(i);
					String id = b.getKey();
					String value = b.getString().intern();
					this.localeIdToRulesId.put(id, value);
					if (!this.rulesIdToEquivalentULocale.containsKey(value)) {
						this.rulesIdToEquivalentULocale.put(value, new ULocale(id));
					}
				}
			} catch (MissingResourceException var7) {
				this.localeIdToRulesId = Collections.emptyMap();
				this.rulesIdToEquivalentULocale = Collections.emptyMap();
			}
		}

	}

	public String getRulesIdForLocale(ULocale locale) {
		Map<String, String> idMap = this.getLocaleIdToRulesIdMap();
		String localeId = ULocale.canonicalize(locale.getBaseName());

		String rulesId;
		int ix;
		for (rulesId = null; null == (rulesId = (String) idMap.get(localeId)); localeId = localeId.substring(0, ix)) {
			ix = localeId.lastIndexOf("_");
			if (ix == -1) {
				break;
			}
		}

		return rulesId;
	}

	public PluralRules getRulesForRulesId(String rulesId) {
		PluralRules rules = (PluralRules) this.rulesIdToRules.get(rulesId);
		if (rules == null) {
			try {
				UResourceBundle pluralb = this.getPluralBundle();
				UResourceBundle rulesb = pluralb.get("rules");
				UResourceBundle setb = rulesb.get(rulesId);
				StringBuilder sb = new StringBuilder();

				for (int i = 0; i < setb.getSize(); ++i) {
					UResourceBundle b = setb.get(i);
					if (i > 0) {
						sb.append("; ");
					}

					sb.append(b.getKey());
					sb.append(": ");
					sb.append(b.getString());
				}

				rules = PluralRules.parseDescription(sb.toString());
			} catch (ParseException var9) {
				;
			} catch (MissingResourceException var10) {
				;
			}

			this.rulesIdToRules.put(rulesId, rules);
		}

		return rules;
	}

	public UResourceBundle getPluralBundle() throws MissingResourceException {
		return ICUResourceBundle.getBundleInstance("com/ibm/icu/impl/data/icudt44b", "plurals",
				ICUResourceBundle.ICU_DATA_CLASS_LOADER, true);
	}

	public PluralRules forLocale(ULocale locale) {
		String rulesId = this.getRulesIdForLocale(locale);
		if (rulesId != null && rulesId.trim().length() != 0) {
			PluralRules rules = this.getRulesForRulesId(rulesId);
			if (rules == null) {
				rules = PluralRules.DEFAULT;
			}

			return rules;
		} else {
			return PluralRules.DEFAULT;
		}
	}
}