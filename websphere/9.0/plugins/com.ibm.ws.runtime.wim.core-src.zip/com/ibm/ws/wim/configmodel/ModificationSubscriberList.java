package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface ModificationSubscriberList {
	List getModificationSubscriber();

	ModificationSubscriber[] getModificationSubscriberAsArray();

	ModificationSubscriber createModificationSubscriber();
}