package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.ImmutableCollection.1;
import com.google.common.collect.ImmutableCollection.SerializedForm;
import java.io.Serializable;
import java.util.Collection;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
public abstract class ImmutableCollection<E> implements Collection<E>, Serializable {
	static final ImmutableCollection<Object> EMPTY_IMMUTABLE_COLLECTION = new ImmutableCollection.EmptyImmutableCollection((1)null);
	private transient ImmutableList<E> asList;

	public abstract UnmodifiableIterator<E> iterator();

	public Object[] toArray() {
		return ObjectArrays.toArrayImpl(this);
	}

	public <T> T[] toArray(T[] other) {
		return ObjectArrays.toArrayImpl(this, other);
	}

	public boolean contains(@Nullable Object object) {
		return object != null && Iterators.contains(this.iterator(), object);
	}

	public boolean containsAll(Collection<?> targets) {
		return Collections2.containsAllImpl(this, targets);
	}

	public boolean isEmpty() {
		return this.size() == 0;
	}

	public String toString() {
		return Collections2.toStringImpl(this);
	}

	@Deprecated
	public final boolean add(E e) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final boolean remove(Object object) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final boolean addAll(Collection<? extends E> newElements) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final boolean removeAll(Collection<?> oldElements) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final boolean retainAll(Collection<?> elementsToKeep) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final void clear() {
		throw new UnsupportedOperationException();
	}

	public ImmutableList<E> asList() {
		ImmutableList<E> list = this.asList;
		return list == null ? (this.asList = this.createAsList()) : list;
	}

	ImmutableList<E> createAsList() {
		switch (this.size()) {
			case 0 :
				return ImmutableList.of();
			case 1 :
				return ImmutableList.of(this.iterator().next());
			default :
				return new RegularImmutableAsList(this, this.toArray());
		}
	}

	abstract boolean isPartialView();

	Object writeReplace() {
		return new SerializedForm(this.toArray());
	}

	private static class ArrayImmutableCollection<E> extends ImmutableCollection<E> {
		private final E[] elements;

		ArrayImmutableCollection(E[] elements) {
			this.elements = elements;
		}

		public int size() {
			return this.elements.length;
		}

		public boolean isEmpty() {
			return false;
		}

		public UnmodifiableIterator<E> iterator() {
			return Iterators.forArray(this.elements);
		}

		ImmutableList<E> createAsList() {
			return (ImmutableList) (this.elements.length == 1
					? new SingletonImmutableList(this.elements[0])
					: new RegularImmutableList(this.elements));
		}

		boolean isPartialView() {
			return false;
		}
	}

	private static class EmptyImmutableCollection extends ImmutableCollection<Object> {
		private static final Object[] EMPTY_ARRAY = new Object[0];

		private EmptyImmutableCollection() {
		}

		public int size() {
			return 0;
		}

		public boolean isEmpty() {
			return true;
		}

		public boolean contains(@Nullable Object object) {
			return false;
		}

		public UnmodifiableIterator<Object> iterator() {
			return Iterators.EMPTY_LIST_ITERATOR;
		}

		public Object[] toArray() {
			return EMPTY_ARRAY;
		}

		public <T> T[] toArray(T[] array) {
			if (array.length > 0) {
				array[0] = null;
			}

			return array;
		}

		ImmutableList<Object> createAsList() {
			return ImmutableList.of();
		}

		boolean isPartialView() {
			return false;
		}
	}
}