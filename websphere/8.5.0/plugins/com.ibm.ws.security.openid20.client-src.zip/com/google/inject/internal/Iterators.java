package com.google.inject.internal;

import com.google.inject.internal.Iterators.1;
import com.google.inject.internal.Iterators.2;
import com.google.inject.internal.Iterators.3;
import com.google.inject.internal.Iterators.4;
import com.google.inject.internal.Iterators.5;
import com.google.inject.internal.Iterators.6;
import com.google.inject.internal.Iterators.7;
import com.google.inject.internal.Iterators.8;
import com.google.inject.internal.Iterators.9;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;

public final class Iterators {
	static final Iterator<Object> EMPTY_ITERATOR = new 1();
	private static final ListIterator<Object> EMPTY_LIST_ITERATOR = new 2();

	public static <T> UnmodifiableIterator<T> emptyIterator() {
		return (UnmodifiableIterator) EMPTY_ITERATOR;
	}

	public static <T> ListIterator<T> emptyListIterator() {
		return EMPTY_LIST_ITERATOR;
	}

	public static <T> UnmodifiableIterator<T> unmodifiableIterator(Iterator<T> iterator) {
      Preconditions.checkNotNull(iterator);
      return new 3(iterator);
   }

	public static String toString(Iterator<?> iterator) {
		if (!iterator.hasNext()) {
			return "[]";
		} else {
			StringBuilder builder = new StringBuilder();
			builder.append('[').append(iterator.next());

			while (iterator.hasNext()) {
				builder.append(", ").append(iterator.next());
			}

			return builder.append(']').toString();
		}
	}

	public static <T> T getOnlyElement(Iterator<T> iterator) {
		T first = iterator.next();
		if (!iterator.hasNext()) {
			return first;
		} else {
			StringBuilder sb = new StringBuilder();
			sb.append("expected one element but was: <" + first);

			for (int i = 0; i < 4 && iterator.hasNext(); ++i) {
				sb.append(", " + iterator.next());
			}

			if (iterator.hasNext()) {
				sb.append(", ...");
			}

			sb.append(">");
			throw new IllegalArgumentException(sb.toString());
		}
	}

	public static <T> Iterator<T> concat(Iterator<? extends Iterator<? extends T>> inputs) {
      Preconditions.checkNotNull(inputs);
      return new 4(inputs);
   }

	public static <F, T> Iterator<T> transform(Iterator<F> fromIterator, Function<? super F, ? extends T> function) {
      Preconditions.checkNotNull(fromIterator);
      Preconditions.checkNotNull(function);
      return new 5(fromIterator, function);
   }

	public static <T> UnmodifiableIterator<T> forArray(T... array) {
      return new 6(array);
   }

	public static <T> UnmodifiableIterator<T> forArray(T[] array, int offset, int length) {
      Preconditions.checkArgument(length >= 0);
      int end = offset + length;
      Preconditions.checkPositionIndexes(offset, end, array.length);
      return new 7(offset, end, array);
   }

	public static <T> UnmodifiableIterator<T> singletonIterator(@Nullable T value) {
      return new 8(value);
   }

	public static <T> Enumeration<T> asEnumeration(Iterator<T> iterator) {
      Preconditions.checkNotNull(iterator);
      return new 9(iterator);
   }
}