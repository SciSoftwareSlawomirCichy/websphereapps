package com.ibm.ws.wim.adapter.file.was;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InvalidArgumentException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.util.StringUtil;
import com.ibm.ws.wim.util.UniqueNameHelper;
import com.ibm.ws.wim.xpath.TokenMgrError;
import com.ibm.ws.wim.xpath.WIMXPathInterpreter;
import com.ibm.ws.wim.xpath.mapping.datatype.LogicalNode;
import com.ibm.ws.wim.xpath.mapping.datatype.ParenthesisNode;
import com.ibm.ws.wim.xpath.mapping.datatype.PropertyNode;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;
import com.ibm.ws.wim.xpath.util.MetadataMapper;
import commonj.sdo.DataObject;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileXPathHelper {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private Stack logOps = null;
	private DataObject entity = null;
	private List entityTypes = null;
	private XPathNode node = null;
	private List searchBases = null;
	private List loginProperties = null;
	private List loginPropertiesType = null;
	private boolean isPrincipalNameSearch = false;
	private String principalNameDN = null;
	private boolean caseSensitive = false;
	private boolean isIgnoreDNBaseSearch = false;

	public FileXPathHelper() {
	}

	public FileXPathHelper(boolean var1) {
		this.caseSensitive = var1;
	}

	public FileXPathHelper(String var1, List var2, List var3, List var4, boolean var5, boolean var6)
			throws WIMException {
		boolean var8 = trcLogger.isLoggable(Level.FINEST);
		if (var8) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "<init>",
					"searchExpr=" + var1 + ", searchBases=" + var2 + ", ignoreDNBaseSearch=" + var6);
		}

		this.isIgnoreDNBaseSearch = var6;
		this.logOps = new Stack();
		this.parseSearchExpression(var1);
		this.searchBases = var2;
		this.loginProperties = var3;
		this.loginPropertiesType = var4;
		this.caseSensitive = var5;
	}

	public List getEntityTypes() {
		return this.entityTypes;
	}

	public XPathNode getNode() {
		return this.node;
	}

	public boolean isPrincipalNameSearch() {
		return this.isPrincipalNameSearch;
	}

	public String getPrincipalNameDN() {
		return this.principalNameDN;
	}

	public void parseSearchExpression(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "parseSearchExpression", "parsing " + var1);
		}

		try {
			if (var1 != null && var1.trim().length() != 0) {
				WIMXPathInterpreter var3 = new WIMXPathInterpreter(new StringReader(var1));
				this.node = var3.parse((MetadataMapper) null);
				this.entityTypes = var3.getEntityTypes();
				HashMap var4 = new HashMap();
				if (this.node != null) {
					Iterator var5 = this.node.getPropertyNodes(var4);

					while (var5.hasNext()) {
						PropertyNode var6 = (PropertyNode) var5.next();
						var6.setName(this.removeNamespace(var6.getName()));
						String var7 = (String) var6.getValue();
						this.validatePropertyNode(var6);
						this.countWildcardsAndValidatePattern(var7);
					}
				}

			}
		} catch (WIMException var8) {
			throw var8;
		} catch (Exception var9) {
			throw new WIMApplicationException("MALFORMED_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var1),
					Level.WARNING, CLASSNAME, "parseSearchExpression", var9);
		} catch (TokenMgrError var10) {
			throw new SearchControlException("INVALID_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var1),
					CLASSNAME, "parseSearchExpression", var10);
		}
	}

	public void validatePropertyNode(PropertyNode var1) throws Exception {
		String var3 = var1.getName();
		if (this.isPrincipalNameSearch) {
			throw new WIMApplicationException("CANNOT_SEARCH_PRINCIPAL_NAME_WITH_OTHER_PROPS", Level.WARNING, CLASSNAME,
					"validatePropertyNode");
		} else {
			if ("principalName".equals(var3)) {
				this.isPrincipalNameSearch = true;
				String var4 = (String) var1.getValue();
				if (var4 != null && !var4.trim().equals("") && UniqueNameHelper.isDN(var4) != null
						&& !this.isIgnoreDNBaseSearch) {
					this.principalNameDN = var4;
				}
			}

		}
	}

	public int countWildcardsAndValidatePattern(String var1) throws InvalidArgumentException {
		int var2 = 0;

		try {
			int var3 = var1.indexOf("*");
			if (var3 != -1) {
				while (var3 != -1 && var3 + 1 <= var1.length()) {
					++var2;
					var3 = var1.indexOf("*", var3 + 1);
				}
			}
		} catch (Exception var4) {
			;
		}

		if (var2 > 1) {
			boolean var5 = false;
			if (var2 == 2 && var1.length() > 2 && var1.startsWith("*") && var1.endsWith("*")) {
				var5 = true;
			}

			if (!var5) {
				throw new InvalidArgumentException("INVALID_SEARCH_PATTERN", WIMMessageHelper.generateMsgParms(var1),
						Level.WARNING, CLASSNAME, "countWildcardAndValidatePattern");
			}
		}

		return var2;
	}

	public String removeNamespace(String var1) {
		String var2 = var1.replace('\'', ' ').trim();
		int var3 = var2.indexOf(":");
		if (var3 > 0) {
			var2 = var2.substring(var3 + 1);
		}

		return var2;
	}

	public void setEntity(DataObject var1) {
		this.entity = var1;
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "setEntity",
					"evaluate search expression for " + var1.getString("identifier/uniqueName"));
		}

	}

	public boolean evaluate(DataObject var1) throws Exception {
		this.setEntity(var1);
		if (this.entityTypes == null && this.node == null) {
			return this.matchSearchBase();
		} else if (this.matchEntityType()) {
			return this.node != null ? this.evaluateXPathNode(this.node) : this.matchSearchBase();
		} else {
			return false;
		}
	}

	public boolean evaluateXPathNode(XPathNode var1) throws Exception {
		switch (var1.getNodeType()) {
			case 0 :
				return this.evaluateXPathNode((PropertyNode) var1);
			case 1 :
				return this.evaluateXPathNode((LogicalNode) var1);
			case 2 :
				return this.evaluateXPathNode((ParenthesisNode) var1);
			default :
				return false;
		}
	}

	private boolean evaluateXPathNode(PropertyNode var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.entering(CLASSNAME, "evaluateXPathNode(propertyNode)", "evaluating " + var1);
		}

		boolean var4 = false;
		if (this.matchSearchBase()) {
			try {
				String var5 = var1.getName();
				String var6 = var1.getOperator();
				String var7 = (String) var1.getValue();
				String var15;
				if (this.isPrincipalNameSearch) {
					if (this.principalNameDN != null) {
						var4 = this.patternMatch(this.entity.getString("identifier/uniqueName"), var6, var7);
					} else {
						for (int var14 = 0; var14 < this.loginProperties.size(); ++var14) {
							var15 = (String) this.loginProperties.get(var14);
							if (Boolean.FALSE.equals((Boolean) this.loginPropertiesType.get(var14))) {
								var4 = this.patternMatch(this.entity.getString(var15), var6, var7);
								if (var4) {
									break;
								}
							} else {
								List var16 = this.entity.getList(var15);

								for (int var17 = 0; var17 < var16.size(); ++var17) {
									var4 = this.patternMatch((String) var16.get(var17), var6, var7);
									if (var4) {
										break;
									}
								}
							}
						}
					}

					return var4;
				}

				if (this.entity.isSet(var5)) {
					Object var8 = this.entity.get(var5);
					if (var8 instanceof List) {
						List var9 = (List) var8;

						for (int var10 = 0; var10 < var9.size(); ++var10) {
							var8 = var9.get(var10);
							if (var8 instanceof DataObject) {
								DataObject var11 = (DataObject) var8;
								if (var11.getType().getName().equals("IdentifierType")) {
									String var12 = var11.getString("uniqueName");
									if (var12 == null) {
										var12 = var11.getString("externalName");
									}

									var4 = this.patternMatch(var12, var6, var7);
								}
							} else {
								var4 = this.patternMatch(var8, var6, var7);
							}

							if (var4) {
								break;
							}
						}
					} else {
						var15 = String.valueOf(var8);
						var4 = this.patternMatch(var15, var6, var7);
					}
				}
			} catch (Exception var13) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "evaluateXPathNode(propertyNode)", "Exception occurred:",
							var13);
				}

				throw var13;
			}
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "evaluateXPathNode(propertyNode)", "match=" + var4);
		}

		return var4;
	}

	public boolean matchSearchBase() {
		boolean var2 = true;
		if (this.searchBases != null && this.searchBases.size() > 0) {
			String var3 = null;
			DataObject var4 = this.entity.getDataObject("identifier");
			if (var4 != null) {
				var3 = var4.getString("uniqueName");
			}

			if (var3 != null) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "matchSearchBase", "evaluating dn:" + var3);
				}

				var2 = false;

				for (int var5 = 0; var5 < this.searchBases.size(); ++var5) {
					if (this.normalizedStringsEndsWith(var3, (String) this.searchBases.get(var5))) {
						var2 = true;
						break;
					}
				}
			}
		}

		return var2;
	}

	public boolean matchEntityType() throws WIMException {
		boolean var1 = false;
		String var2 = this.entity.getType().getName();

		for (int var3 = 0; var3 < this.entityTypes.size(); ++var3) {
			if (FileData.isSuperType((String) this.entityTypes.get(var3), var2)) {
				var1 = true;
				break;
			}
		}

		return var1;
	}

	private boolean normalizedStringsAreEqual(String var1, String var2) {
		return this.caseSensitive ? var1.equals(var2) : var1.equalsIgnoreCase(var2);
	}

	private boolean normalizedStringsStartsWith(String var1, String var2) {
		return this.caseSensitive ? var1.startsWith(var2) : StringUtil.startsWithIgnoreCase(var1, var2);
	}

	private boolean normalizedStringsEndsWith(String var1, String var2) {
		return this.caseSensitive ? var1.endsWith(var2) : StringUtil.endsWithIgnoreCase(var1, var2);
	}

	private int normalizedStringContains(String var1, String var2) {
		return this.caseSensitive ? var1.indexOf(var2) : StringUtil.containsIgnoreCase(var1, var2);
	}

	public boolean patternMatch(Object var1, String var2, String var3) {
		try {
			int var5;
			if (!var2.equals("=") && !var2.equals("!=")) {
				int var10 = Integer.parseInt(var1.toString());
				var5 = Integer.parseInt(var3);
				if (var2.equals("<")) {
					return var10 < var5;
				}

				if (var2.equals(">")) {
					return var10 > var5;
				}

				if (var2.equals("<=")) {
					return var10 <= var5;
				}

				if (var2.equals(">=")) {
					return var10 >= var5;
				}
			} else {
				String var4 = (String) var1;
				if (var2.equals("=") && var4 == null && var3 == null) {
					return true;
				}

				if (var4 != null && var3 != null) {
					var5 = this.countWildcardsAndValidatePattern(var3);
					if (var5 == 2) {
						String var6 = var3.substring(1, var3.length() - 1);
						if (var2.equals("=") && this.normalizedStringContains(var4, var6) != -1) {
							return true;
						}

						if (var2.equals("!=") && this.normalizedStringContains(var4, var6) == -1) {
							return true;
						}
					} else if (var5 == 1) {
						int var11 = var3.indexOf("*");
						String var7 = var3.substring(0, var11);
						String var8 = var3.substring(var11 + 1);
						if (var2.equals("=") && this.normalizedStringsStartsWith(var4, var7)
								&& this.normalizedStringsEndsWith(var4, var8)) {
							return true;
						}

						if (var2.equals("!=") && (!this.normalizedStringsStartsWith(var4, var7)
								|| !this.normalizedStringsEndsWith(var4, var8))) {
							return true;
						}
					} else {
						if (var2.equals("=") && this.normalizedStringsAreEqual(var4, var3)) {
							return true;
						}

						if (var2.equals("!=") && !this.normalizedStringsAreEqual(var4, var3)) {
							return true;
						}
					}
				}
			}

			return false;
		} catch (Exception var9) {
			var9.printStackTrace();
			return false;
		}
	}

	private boolean evaluateXPathNode(LogicalNode var1) throws Exception {
		boolean var2 = false;
		boolean var3 = this.evaluateXPathNode((XPathNode) var1.getLeftChild());
		boolean var4 = this.evaluateXPathNode((XPathNode) var1.getRightChild());
		if (var1.getOperator().equalsIgnoreCase("and")) {
			var2 = var3 && var4;
		} else {
			if (!var1.getOperator().equalsIgnoreCase("or")) {
				throw new WIMApplicationException("Logical operator " + var1.getOperator() + " is not supported");
			}

			var2 = var3 || var4;
		}

		return var2;
	}

	private boolean evaluateXPathNode(ParenthesisNode var1) throws Exception {
		return this.evaluateXPathNode((XPathNode) var1.getChild());
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = FileXPathHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}