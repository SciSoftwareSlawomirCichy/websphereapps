package com.google.common.reflect;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.UnmodifiableIterator;
import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Beta
public final class Parameter implements AnnotatedElement {
	private final Invokable<?, ?> declaration;
	private final int position;
	private final TypeToken<?> type;
	private final ImmutableList<Annotation> annotations;

	Parameter(Invokable<?, ?> declaration, int position, TypeToken<?> type, Annotation[] annotations) {
		this.declaration = declaration;
		this.position = position;
		this.type = type;
		this.annotations = ImmutableList.copyOf(annotations);
	}

	public TypeToken<?> getType() {
		return this.type;
	}

	public Invokable<?, ?> getDeclaringInvokable() {
		return this.declaration;
	}

	public boolean isAnnotationPresent(Class<? extends Annotation> annotationType) {
		return this.getAnnotation(annotationType) != null;
	}

	@NullableDecl
	public <A extends Annotation> A getAnnotation(Class<A> annotationType) {
		Preconditions.checkNotNull(annotationType);
		UnmodifiableIterator var2 = this.annotations.iterator();

		Annotation annotation;
		do {
			if (!var2.hasNext()) {
				return null;
			}

			annotation = (Annotation) var2.next();
		} while (!annotationType.isInstance(annotation));

		return (Annotation) annotationType.cast(annotation);
	}

	public Annotation[] getAnnotations() {
		return this.getDeclaredAnnotations();
	}

	public <A extends Annotation> A[] getAnnotationsByType(Class<A> annotationType) {
		return this.getDeclaredAnnotationsByType(annotationType);
	}

	public Annotation[] getDeclaredAnnotations() {
		return (Annotation[]) this.annotations.toArray(new Annotation[this.annotations.size()]);
	}

	@NullableDecl
	public <A extends Annotation> A getDeclaredAnnotation(Class<A> annotationType) {
		Preconditions.checkNotNull(annotationType);
		return (Annotation) FluentIterable.from(this.annotations).filter(annotationType).first().orNull();
	}

	public <A extends Annotation> A[] getDeclaredAnnotationsByType(Class<A> annotationType) {
		return (Annotation[]) FluentIterable.from(this.annotations).filter(annotationType).toArray(annotationType);
	}

	public boolean equals(@NullableDecl Object obj) {
		if (!(obj instanceof Parameter)) {
			return false;
		} else {
			Parameter that = (Parameter) obj;
			return this.position == that.position && this.declaration.equals(that.declaration);
		}
	}

	public int hashCode() {
		return this.position;
	}

	public String toString() {
		return this.type + " arg" + this.position;
	}
}