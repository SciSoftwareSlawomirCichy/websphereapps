package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_de extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: Die OpenID-Relying-Party (RP) konnte den Benutzer nicht zur Authentifizierung an den OpenID-Provider (OP) weiterleiten. Ursache ist die Ausnahme [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: Die OpenID-Relying-Party (RP) konnte nicht initialisiert werden, da der Standard-SSL-Kontext für den WebSphere-Server nicht abgerufen werden konnte. Ausnahme: [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: Die OpenID-Relying-Party (RP) konnte keine Verbindung zu dem OpenID-Provider (OP) herstellen, der über die ID [{0}] angegeben ist. Ursache ist die Ausnahme [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: Die OpenID-Relying-Party (RP) konnte aufgrund der Ausnahme [{0}] nicht initialisiert werden."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: Die OpenID-Relying-Party (RP) konnte nicht initialisiert werden, da der Wert für die Eigenschaft [{0}] nicht ordnungsgemäß formatiert ist."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: Die OpenID-Relying-Party (RP) konnte eine Anforderung mit dem Token für die Basisauthentifizierung (Basic Auth) nicht authentifizieren, da der Tokenwert nicht gültig ist."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: Die OpenID-Relying-Party (RP) konnte nicht initialisiert werden, da die Eigenschaft [{0}] nicht ordnungsgemäß angegeben ist. Es muss eine gültige URL sein."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: Die OpenID-Relying-Party (RP) hat eine falsche Antwort vom OpenID-Provider (OP) empfangen. Ursache für diesen Fehler: [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: Die OpenID-Relying-Party (RP) konnte die Authentifizierung nicht durchführen, da die maximale Kapazität des zugehörigen internen Caches erreicht ist."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: Die OpenID-Relying-Party (RP) konnte nicht initialisiert werden, da die erforderliche Eigenschaft axRequiredAttribute[n] fehlt. Mindestens eine Eigenschaft muss definiert sein."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: Die OpenID-Relying-Party (RP) konnte nicht initialisiert werden, da der Wert für die verbindliche Eigenschaft [{0}] fehlt oder leer ist."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: Die OpenID-Relying-Party (RP) setzt SSL (HTTPS) voraus, aber die OpenID-Provider-URL verwendet HTTP: [{0}]. Das Attribut [{1}] sollte mit dem Ziel-URL-Schema übereinstimmen. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: Die OpenID-Relying-Party (RP) hat eine Antwort vom OpenID-Provider (OP) empfangen, die die OpenID-Spezifikation Version 2 nicht unterstützt."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: Bei der Überprüfung der vom OpenID-Provider (OP) empfangenen Antwort ist bei der OpenID-Relying-Party (RP) ein Fehler aufgetreten. Ausnahme: [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}