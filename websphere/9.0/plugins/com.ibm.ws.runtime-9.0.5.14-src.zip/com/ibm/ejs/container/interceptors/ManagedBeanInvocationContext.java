package com.ibm.ejs.container.interceptors;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.util.HashMap;
import java.util.Map;

public class ManagedBeanInvocationContext<T> extends InvocationContextImpl<T> {
	private static final TraceComponent tc = Tr.register(ManagedBeanInvocationContext.class, "EJB3Interceptors",
			"com.ibm.ejs.container.container");
	private Map<String, Object> contextData;

	public Map<String, Object> getContextData() {
		if (this.contextData == null) {
			this.contextData = new HashMap();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "MB.getContextData: created empty");
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "MB.getContextData: " + this.contextData.size());
		}

		return this.contextData;
	}
}