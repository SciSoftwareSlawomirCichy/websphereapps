package com.ibm.debug;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;

public class DebugBreakpoints {
	private static final TraceComponent tc = Tr.register(DebugWebAppInvocationCollaborator.class.getName(),
			"DebugComponent");

	public static void debugJSPBreakpoint(String className, String methodName, String UriName,
			String jspMethodSignature) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "debugJSPBreakpoint for " + className + "." + methodName + " uri:" + UriName + " signature:"
					+ jspMethodSignature);
		}

	}

	public static void debugServletBreakpoint(String className, String methodName) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "debugServletBreakpoint for " + className + "." + methodName);
		}

	}

	public static void debugEJBBreakpoint(String className, String methodName, String jdiSignature) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "debugEJBBreakpoint for " + className + "." + methodName + "." + jdiSignature);
		}

	}

	public static void debugSend_RequestBreakpoint(String hostname, int portnumber, long requestId) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "debugSend_RequestBreakpoint");
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "hostname:" + hostname);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "debugSend_RequestBreakpoint");
		}

	}

	public static void debugReceive_ReplyBreakpoint(long requestId) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "debugReceive_ReplyBreakpoint");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "debugReceive_ReplyBreakpoint");
		}

	}

	public static void debugBlueprintBreakpoint(String className, String methodName, String methodSignature,
			String bundleName, String bundleVersion) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "debugBlueprintBreakpoint for " + className + "." + methodName + "." + methodSignature
					+ " in bundle " + bundleName + " version " + bundleVersion);
		}

	}
}