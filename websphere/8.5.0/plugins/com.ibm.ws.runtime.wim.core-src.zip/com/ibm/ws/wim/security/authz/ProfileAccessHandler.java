package com.ibm.ws.wim.security.authz;

import com.ibm.sec.auth.subjectx.VirtualPrincipal;
import com.ibm.sec.authz.jaccx.resource.Resource;
import com.ibm.websphere.security.cred.WSCredential;
import com.ibm.websphere.wim.ServiceProvider;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.security.authz.AuthSystemException;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.security.authz.ProfileAccessHandler.1;
import com.ibm.ws.wim.security.authz.ProfileAccessHandler.2;
import com.ibm.ws.wim.security.authz.jacc.GroupPrincipal;
import com.ibm.ws.wim.security.authz.jacc.UserPrincipal;
import com.ibm.ws.wim.util.DataGraphHelper;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.security.Principal;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.Subject;

public class ProfileAccessHandler implements AccessHandler {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger msgLogger;
	private static final Logger trcLogger;
	private static final String CONTEXT_PARAM_ENTITY_TYPE = "_ENTITY-TYPE";
	private static ThreadLocal subjectAttrCache;
	private static ThreadLocal resourceAttrCache;

	public void clearThreadCache() {
		trcLogger.entering(CLASSNAME, "clearThreadCache()");
		subjectAttrCache.set(new Hashtable());
		resourceAttrCache.set(new Hashtable());
		trcLogger.exiting(CLASSNAME, "clearThreadCache()");
	}

	public Map getContextParameters(Resource var1) {
		trcLogger.entering(CLASSNAME, "getContextParameters()");
		Hashtable var6 = new Hashtable();
		DataObject var3 = ((EntityResource) var1).getRoot();
		List var5 = var3.getList("contexts");
		Iterator var7 = var5.iterator();

		while (var7.hasNext()) {
			DataObject var4 = (DataObject) var7.next();
			var6.put(var4.getString("key"), var4.get("value"));
		}

		var6.put("_ENTITY-TYPE", ((EntityResource) var1).getEntityType());
		trcLogger.exiting(CLASSNAME, "getContextParameters() - " + var6);
		return var6;
	}

	public Set getResourceAttributeNames(Resource var1) {
		trcLogger.entering(CLASSNAME, "getResourceAttributeNames()");
		Set var2 = SDOHelper.getEntityAttributes(((EntityResource) var1).getEntity(), true, true);
		trcLogger.exiting(CLASSNAME, "getResourceAttributeNames()");
		return var2;
	}

	public Object getResourceAttribute(Resource var1, String var2, Set var3) {
      trcLogger.entering(CLASSNAME, "getResourceAttribute()");

      Object var4;
      try {
         var4 = ProfileSecurityManager.singleton().runAsSuperUser(new 1(this, var1, var2, var3));
      } catch (WIMException var6) {
         return null;
      }

      trcLogger.exiting(CLASSNAME, "getResourceAttribute()");
      return var4;
   }

	public Set getSubjectAttributeNames(Subject var1) {
		trcLogger.entering(CLASSNAME, "getSubjectAttributeNames()");
		Set var2 = SDOHelper.getEntityAttributes(this.createSubjectEntity(var1), true, true);
		trcLogger.exiting(CLASSNAME, "getSubjectAttributeNames()");
		return var2;
	}

	public Object getSubjectAttribute(Subject var1, String var2, Set var3) {
      trcLogger.entering(CLASSNAME, "getSubjectAttribute()");

      Object var4;
      try {
         var4 = ProfileSecurityManager.singleton().runAsSuperUser(new 2(this, var1, var2, var3));
      } catch (WIMException var6) {
         return null;
      }

      trcLogger.exiting(CLASSNAME, "getSubjectAttribute()");
      return var4;
   }

	public Principal getSubjectPrincipal(Subject var1) {
		Object var3 = VirtualPrincipal.AnonymousUser;
		WSCredential var2;
		if ((var2 = this.getWSCredential(var1)) != null) {
			try {
				var3 = new UserPrincipal(var2.getUniqueSecurityName());
			} catch (Exception var5) {
				msgLogger.log(Level.WARNING, "AUTH_SUBJECT_CRED_FAILURE", var5);
			}
		}

		return (Principal) var3;
	}

	private String getSubjectUniqueName(Subject var1) {
		String var2 = VirtualPrincipal.AnonymousUser.getName();
		WSCredential var3;
		if ((var3 = this.getWSCredential(var1)) != null) {
			try {
				var2 = var3.getUniqueSecurityName();
			} catch (Exception var5) {
				msgLogger.log(Level.WARNING, "AUTH_SUBJECT_CRED_FAILURE", var5);
			}
		}

		return var2;
	}

	public Set getSubjectGroups(Subject var1) {
		HashSet var2 = new HashSet();
		WSCredential var3;
		if ((var3 = this.getWSCredential(var1)) != null) {
			try {
				Iterator var4 = var3.getGroupIds().iterator();

				while (var4.hasNext()) {
					String var5 = (String) var4.next();
					var5 = var5.substring(var5.indexOf("/") + 1, var5.length());
					var2.add(new GroupPrincipal(var5));
				}
			} catch (Exception var6) {
				msgLogger.log(Level.WARNING, "AUTH_SUBJECT_CRED_FAILURE", var6);
			}
		}

		return var2;
	}

	public Set getSubjectRelationships(Subject var1, Resource var2) {
		trcLogger.entering(CLASSNAME, "getSubjectRelationships()");
		String var4 = null;
		HashSet var5 = new HashSet();
		DataObject var6 = ((EntityResource) var2).getEntity();
		String var3 = this.getSubjectUniqueName(var1);
		if (var6.get("identifier") != null) {
			var4 = var6.getString("identifier/uniqueName");
		}

		if (var3 != null && var4 != null && var3.equals(var4)) {
			var5.add("Owner");
		}

		trcLogger.exiting(CLASSNAME, "getSubjectRelationships() - " + var5);
		return var5;
	}

	private WSCredential getWSCredential(Subject var1) {
		WSCredential var3 = null;
		Iterator var2 = var1.getPublicCredentials(WSCredential.class).iterator();
		if (var2.hasNext()) {
			var3 = (WSCredential) var2.next();
		}

		return var3;
	}

	private Object getEntityAttribute(DataObject var1, String var2, Map var3, Set var4) {
		String var5 = null;
		String var6 = null;
		Object var7 = null;
		trcLogger.log(Level.FINEST, "Looking up attribute ''{0}'' for ''{1}'' to evaluate a conditional permission...",
				new Object[]{var2, SDOHelper.getEntityDisplayName(var1)});
		if ((var7 = var3.get(var2)) == null) {
			try {
				SchemaManager var14 = SchemaManager.singleton();
				if (var1.get("identifier") != null) {
					var5 = var1.getString("identifier/uniqueName");
					var6 = var1.getString("identifier/uniqueId");
				}

				Set var8;
				DataObject var11;
				Iterator var15;
				String var16;
				if (var5 == null && var6 == null) {
					var11 = var1;
				} else {
					ServiceProvider var13 = ServiceProvider.singleton();
					DataObject var9 = var13.createRootDataObject();
					var9.getList("entities").add(DataGraphHelper.cloneDataObject(var1));
					DataObject var12 = var9.createDataObject("controls", "http://www.ibm.com/websphere/wim",
							"PropertyControl");
					var8 = SDOHelper.getEntityAttributes(var1, true, true);
					if (!var8.contains(var2)) {
						var8.add(var2);
					}

					var15 = var8.iterator();

					while (true) {
						while (var15.hasNext()) {
							var16 = (String) var15.next();
							if (!var16.equals(var2) && !var4.contains(var16)) {
								var15.remove();
							} else {
								var12.getList("properties").add(var16);
							}
						}

						DataObject var10 = var13.get(var9);
						var11 = var10.getDataObject("entities.0");
						break;
					}
				}

				var8 = SDOHelper.getEntityAttributes(var11, false, true);
				var15 = var8.iterator();

				while (var15.hasNext()) {
					var16 = (String) var15.next();
					Object var17 = var11.get(var14.getProperty(var11.getType(), var16));
					if (var17 instanceof List) {
						var17 = new HashSet((List) var17);
					}

					if (var17 != null) {
						var3.put(var16, var17);
					}

					if (var2.equals(var16)) {
						var7 = var17;
					}
				}
			} catch (Exception var18) {
				throw new RuntimeException(new AuthSystemException("AUTH_RULE_ATTR_FAILURE",
						new Object[]{var2, SDOHelper.getEntityDisplayName(var1)}, var18, Level.SEVERE));
			}
		}

		if (var7 == null) {
			var7 = "$NON-APPLICABLE$";
			msgLogger.log(Level.WARNING, "AUTH_RULE_ATTR_MISSING",
					new Object[]{var2, SDOHelper.getEntityDisplayName(var1)});
		}

		trcLogger.log(Level.FINEST, "Found attribute ''{0}''=''{1}'' for ''{2}'' to evaluate a conditional permission",
				new Object[]{var2, var7, SDOHelper.getEntityDisplayName(var1)});
		return var7;
	}

	private DataObject createEntity(String var1, String var2) throws WIMException, RemoteException {
		DataObject var3 = ServiceProvider.singleton().createDataObject("http://www.ibm.com/websphere/wim", var1);
		var3.createDataObject("identifier");
		var3.setString("identifier/uniqueName", var2);
		return var3;
	}

	private DataObject createSubjectEntity(Subject var1) {
		DataObject var4 = null;

		try {
			String var2 = this.getSubjectUniqueName(var1);
			var4 = this.createEntity("Entity", var2);
			String var3 = SDOHelper.getEntityType(var4, false);
			var3 = var3.substring(0, var3.length() - 1);
			if (var3.indexOf(47) != -1) {
				var3 = var3.substring(var3.lastIndexOf(47) + 1);
			}

			var4 = this.createEntity(var3, var2);
		} catch (Exception var6) {
			trcLogger.log(Level.FINE, var6.getMessage(), var6);
		}

		return var4;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = ProfileAccessHandler.class.getName();
		msgLogger = WIMLogger.getMessageLogger("com.ibm.ws.wim.security.authz");
		trcLogger = WIMLogger.getTraceLogger("com.ibm.ws.wim.security.authz");
		subjectAttrCache = new ThreadLocal();
		resourceAttrCache = new ThreadLocal();
	}
}