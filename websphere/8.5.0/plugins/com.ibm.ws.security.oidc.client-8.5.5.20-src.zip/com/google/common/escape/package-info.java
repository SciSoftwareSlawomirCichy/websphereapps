@CheckReturnValue
@ParametersAreNonnullByDefault
package com.google.common.escape;

import com.google.errorprone.annotations.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;