package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.collect.RegularImmutableMap.EntrySet;
import com.google.common.collect.RegularImmutableMap.KeySet;
import com.google.common.collect.RegularImmutableMap.KeysOrValuesAsList;
import java.util.Arrays;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
final class RegularImmutableMap<K, V> extends ImmutableMap<K, V> {
	private static final int ABSENT = -1;
	static final ImmutableMap<Object, Object> EMPTY = new RegularImmutableMap((int[]) null, new Object[0], 0);
	private final transient int[] hashTable;
	@VisibleForTesting
	final transient Object[] alternatingKeysAndValues;
	private final transient int size;
	private static final long serialVersionUID = 0L;

	static <K, V> RegularImmutableMap<K, V> create(int n, Object[] alternatingKeysAndValues) {
		if (n == 0) {
			return (RegularImmutableMap) EMPTY;
		} else if (n == 1) {
			CollectPreconditions.checkEntryNotNull(alternatingKeysAndValues[0], alternatingKeysAndValues[1]);
			return new RegularImmutableMap((int[]) null, alternatingKeysAndValues, 1);
		} else {
			Preconditions.checkPositionIndex(n, alternatingKeysAndValues.length >> 1);
			int tableSize = ImmutableSet.chooseTableSize(n);
			int[] hashTable = createHashTable(alternatingKeysAndValues, n, tableSize, 0);
			return new RegularImmutableMap(hashTable, alternatingKeysAndValues, n);
		}
	}

	static int[] createHashTable(Object[] alternatingKeysAndValues, int n, int tableSize, int keyOffset) {
		if (n == 1) {
			CollectPreconditions.checkEntryNotNull(alternatingKeysAndValues[keyOffset],
					alternatingKeysAndValues[keyOffset ^ 1]);
			return null;
		} else {
			int mask = tableSize - 1;
			int[] hashTable = new int[tableSize];
			Arrays.fill(hashTable, -1);

			for (int i = 0; i < n; ++i) {
				Object key = alternatingKeysAndValues[2 * i + keyOffset];
				Object value = alternatingKeysAndValues[2 * i + (keyOffset ^ 1)];
				CollectPreconditions.checkEntryNotNull(key, value);
				int h = Hashing.smear(key.hashCode());

				while (true) {
					h &= mask;
					int previous = hashTable[h];
					if (previous == -1) {
						hashTable[h] = 2 * i + keyOffset;
						break;
					}

					if (alternatingKeysAndValues[previous].equals(key)) {
						throw new IllegalArgumentException("Multiple entries with same key: " + key + "=" + value
								+ " and " + alternatingKeysAndValues[previous] + "="
								+ alternatingKeysAndValues[previous ^ 1]);
					}

					++h;
				}
			}

			return hashTable;
		}
	}

	private RegularImmutableMap(int[] hashTable, Object[] alternatingKeysAndValues, int size) {
		this.hashTable = hashTable;
		this.alternatingKeysAndValues = alternatingKeysAndValues;
		this.size = size;
	}

	public int size() {
		return this.size;
	}

	@NullableDecl
	public V get(@NullableDecl Object key) {
		return get(this.hashTable, this.alternatingKeysAndValues, this.size, 0, key);
	}

	static Object get(@NullableDecl int[] hashTable, @NullableDecl Object[] alternatingKeysAndValues, int size,
			int keyOffset, @NullableDecl Object key) {
		if (key == null) {
			return null;
		} else if (size == 1) {
			return alternatingKeysAndValues[keyOffset].equals(key) ? alternatingKeysAndValues[keyOffset ^ 1] : null;
		} else if (hashTable == null) {
			return null;
		} else {
			int mask = hashTable.length - 1;
			int h = Hashing.smear(key.hashCode());

			while (true) {
				h &= mask;
				int index = hashTable[h];
				if (index == -1) {
					return null;
				}

				if (alternatingKeysAndValues[index].equals(key)) {
					return alternatingKeysAndValues[index ^ 1];
				}

				++h;
			}
		}
	}

	ImmutableSet<Entry<K, V>> createEntrySet() {
		return new EntrySet(this, this.alternatingKeysAndValues, 0, this.size);
	}

	ImmutableSet<K> createKeySet() {
		ImmutableList<K> keyList = new KeysOrValuesAsList(this.alternatingKeysAndValues, 0, this.size);
		return new KeySet(this, keyList);
	}

	ImmutableCollection<V> createValues() {
		return new KeysOrValuesAsList(this.alternatingKeysAndValues, 1, this.size);
	}

	boolean isPartialView() {
		return false;
	}
}