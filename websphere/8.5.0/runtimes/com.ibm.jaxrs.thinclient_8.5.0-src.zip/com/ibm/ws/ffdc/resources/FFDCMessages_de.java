package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_de extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Analysesteuerkomponente mit der Datenbank: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: FFDC-Vorfall an {0} {1} {2} erstellt."},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: Die Verwaltung für die FFDC-Protokolldateien versucht, die Datei {0} zu löschen."},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: Die Verwaltung für die FFDC-Protokolldateien hat {0} von {1} Dateien entfernt, die das konfigurierte maximale Alter erreicht haben."},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: Die Verwaltung für die FFDC-Protokolldateien konnte die Datei {0} nicht löschen."},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: Die Verwaltung für die FFDC-Protokolldateien konnte keine Liste der Ausnahmedateien abrufen."},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE",
					"FFDC0010I: FFDC hat die Datenstromdatei {0} für das Ereignis geschlossen."},
			{"INCIDENTSTREAMIMPL_CREATED_FILE",
					"FFDC0009I: FFDC hat die Datenstromdatei {0} für das Ereignis geöffnet."},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: FFDC konnte die Datenstromdatei {0} für das Ereignis nicht schließen. Die Ausnahme {1} wurde abgefangen."},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: FFDC konnte die Datenstromdatei {0} für das Ereignis nicht öffnen bzw. erstellen. Die Ausnahme {1} wurde abgefangen."},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: FFDC konnte nicht in die Datenstromdatei {0} für das Ereignis schreiben. Die Ausnahme {1} wurde abgefangen."}};

	public Object[][] getContents() {
		return resources;
	}
}