package com.ibm.ejs.container;

public class BMStatelessBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, EJSHome h) {
		return new BMStatelessBeanO(c, h);
	}
}