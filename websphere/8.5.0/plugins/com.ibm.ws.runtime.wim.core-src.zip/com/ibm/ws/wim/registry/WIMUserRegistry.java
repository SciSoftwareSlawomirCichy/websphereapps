package com.ibm.ws.wim.registry;

import com.ibm.websphere.security.CertificateMapFailedException;
import com.ibm.websphere.security.CertificateMapNotSupportedException;
import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.EntryNotFoundException;
import com.ibm.websphere.security.NotImplementedException;
import com.ibm.websphere.security.PasswordCheckFailedException;
import com.ibm.websphere.security.Result;
import com.ibm.websphere.security.UserRegistry;
import com.ibm.websphere.security.cred.WSCredential;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.extensionhelper.TransactionControl;
import com.ibm.ws.extensionhelper.TxHandle;
import com.ibm.ws.security.core.ContextManager;
import com.ibm.ws.security.core.ContextManagerFactory;
import com.ibm.ws.wim.EnvironmentManager;
import com.ibm.ws.wim.registry.WIMUserRegistry.1;
import com.ibm.ws.wim.registry.WIMUserRegistry.10;
import com.ibm.ws.wim.registry.WIMUserRegistry.11;
import com.ibm.ws.wim.registry.WIMUserRegistry.12;
import com.ibm.ws.wim.registry.WIMUserRegistry.13;
import com.ibm.ws.wim.registry.WIMUserRegistry.14;
import com.ibm.ws.wim.registry.WIMUserRegistry.15;
import com.ibm.ws.wim.registry.WIMUserRegistry.16;
import com.ibm.ws.wim.registry.WIMUserRegistry.2;
import com.ibm.ws.wim.registry.WIMUserRegistry.3;
import com.ibm.ws.wim.registry.WIMUserRegistry.4;
import com.ibm.ws.wim.registry.WIMUserRegistry.5;
import com.ibm.ws.wim.registry.WIMUserRegistry.6;
import com.ibm.ws.wim.registry.WIMUserRegistry.7;
import com.ibm.ws.wim.registry.WIMUserRegistry.8;
import com.ibm.ws.wim.registry.WIMUserRegistry.9;
import com.ibm.ws.wim.registry.WIMUserRegistry.MutableBoolean;
import com.ibm.ws.wim.registry.util.BridgeUtils;
import com.ibm.ws.wim.registry.util.DisplayNameBridge;
import com.ibm.ws.wim.registry.util.LoginBridge;
import com.ibm.ws.wim.registry.util.MembershipBridge;
import com.ibm.ws.wim.registry.util.SearchBridge;
import com.ibm.ws.wim.registry.util.SecurityNameBridge;
import com.ibm.ws.wim.registry.util.UniqueIdBridge;
import com.ibm.ws.wim.registry.util.ValidBridge;
import com.ibm.ws.wim.security.authz.AuthPrivilegedException;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.tx.JTAHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import java.rmi.RemoteException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.transaction.NotSupportedException;
import javax.transaction.SystemException;

public class WIMUserRegistry implements UserRegistry, WIMUserRegistryDefines {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	private final String className = WIMUserRegistry.class.getName();
	private Logger wimUserRegistryTrace;
	private static final String TOKEN_DELIMETER = "::";
	private BridgeUtils mappingUtils;
	private LoginBridge loginBridge;
	private DisplayNameBridge displayBridge;
	private SecurityNameBridge securityBridge;
	private UniqueIdBridge uniqueBridge;
	private ValidBridge validBridge;
	private SearchBridge searchBridge;
	private MembershipBridge membershipBridge;
	public static boolean WASStartUp = false;
	private EnvironmentManager environmentManager;
	private static JTAHelper jtaHelper = null;
	private boolean useGlobalTransaction;
	private String domainName;

	public WIMUserRegistry() {
		this.wimUserRegistryTrace = WIMLogger.getTraceLogger(this.className);
		this.environmentManager = null;
		this.useGlobalTransaction = true;
		this.domainName = null;
		String var1 = "WIMUserRegistry";
		if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
			this.wimUserRegistryTrace.entering(this.className, var1);
		}

		if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
			this.wimUserRegistryTrace.exiting(this.className, var1);
		}

	}

	public void initialize(Properties var1) throws CustomRegistryException, RemoteException {
		String var2 = "initialize";
		if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
			this.wimUserRegistryTrace.entering(this.className, var2, "inputProperties = " + var1);
		}

		ContextManager var3 = ContextManagerFactory.getInstance();
		String var4 = var3.getDomainId();
		if (var1.containsKey("security.domain.name")) {
			DomainManagerUtils.cleanUpVMMThreadDomainContext();
			DomainManagerUtils.setVMMThreadDomainContext(var1.getProperty("security.domain.name"));
			this.domainName = var1.getProperty("security.domain.name");
		}

		if (var1.containsKey("com.ibm.ws.security.userregistry.initialization")
				&& "startup".equals(var1.getProperty("com.ibm.ws.security.userregistry.initialization"))) {
			WASStartUp = true;
		}

		if (this.domainName == null && var1.containsKey("security.domain.type")) {
			String var5 = var1.getProperty("security.domain.type");
			if ("administration".equalsIgnoreCase(var5)) {
				this.domainName = "admin";
			}
		}

		this.mappingUtils = BridgeUtils.singleton();
		this.loginBridge = new LoginBridge();
		this.displayBridge = new DisplayNameBridge();
		this.securityBridge = new SecurityNameBridge();
		this.uniqueBridge = new UniqueIdBridge();
		this.validBridge = new ValidBridge();
		this.searchBridge = new SearchBridge();
		this.membershipBridge = new MembershipBridge();
		this.mappingUtils.initialize(var1);
		this.useGlobalTransaction = this.mappingUtils.useGlobalTransaction;
		if (!this.useGlobalTransaction) {
			jtaHelper = new JTAHelper();
			this.environmentManager = EnvironmentManager.singleton();
		}

		if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
			this.wimUserRegistryTrace.exiting(this.className, var2);
		}

	}

	public String checkPassword(String var1, String var2) throws PasswordCheckFailedException, CustomRegistryException, RemoteException {
      boolean var4 = false;
      TransactionControl var5 = null;
      TxHandle var6 = null;
      MutableBoolean var7 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var8;
         for(var8 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var8) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var8 > 0) {
            for(int var9 = 0; var9 < var8; ++var9) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "checkPassword", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      String var15;
      try {
         if (!this.useGlobalTransaction) {
            var5 = (TransactionControl)jtaHelper.getTransactionControl(var5, this.environmentManager);
            var4 = jtaHelper.useTransaction(var5, this.environmentManager);
            if (var4) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "checkPassword", "preinvoke(false,true)");
               }

               var6 = var5.preinvoke(false, true);
            }
         }

         var15 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 1(this, var1, var2, var7));
      } catch (Exception var13) {
         this.wimUserRegistryTrace.log(Level.FINER, var13.toString());
         this.handlePasswordCheckFailedException((WIMException)var13);
         this.handleCustomRemoteExceptions((WIMException)var13);
         this.handleTxException(var13);
         throw new CustomRegistryException(var13);
      } finally {
         if (!this.useGlobalTransaction && var4) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "checkPassword", "closeTransaction(" + var5 + " , " + var6 + " , " + var7.value + ")");
            }

            jtaHelper.closeTransaction("checkPassword", var5, var6, var7.value);
         }

      }

      return var15;
   }

	public String mapCertificate(X509Certificate[] var1) throws CertificateMapNotSupportedException, CertificateMapFailedException, CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "mapCertificate", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      String var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "mapCertificate", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 2(this, var1, var6));
      } catch (Exception var12) {
         this.handleCertificateExceptions((WIMException)var12);
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "mapCertificate", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("mapCertificate", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public String getRealm() throws CustomRegistryException, RemoteException {
      boolean var2 = false;
      TransactionControl var3 = null;
      TxHandle var4 = null;
      MutableBoolean var5 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var6;
         for(var6 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var6) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var6 > 0) {
            for(int var7 = 0; var7 < var6; ++var7) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getRealm", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      String var13;
      try {
         if (!this.useGlobalTransaction) {
            var3 = (TransactionControl)jtaHelper.getTransactionControl(var3, this.environmentManager);
            var2 = jtaHelper.useTransaction(var3, this.environmentManager);
            if (var2) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getRealm", "preinvoke(false,true)");
               }

               var4 = var3.preinvoke(false, true);
            }
         }

         var13 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 3(this, var5));
      } catch (Exception var11) {
         this.handleCustomRemoteExceptions((WIMException)var11);
         this.handleTxException(var11);
         throw new CustomRegistryException(var11);
      } finally {
         if (!this.useGlobalTransaction && var2) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getRealm", "closeTransaction(" + var3 + " , " + var4 + " , " + var5.value + ")");
            }

            jtaHelper.closeTransaction("getRealm", var3, var4, var5.value);
         }

      }

      return var13;
   }

	public Result getUsers(String var1, int var2) throws CustomRegistryException, RemoteException {
      boolean var4 = false;
      TransactionControl var5 = null;
      TxHandle var6 = null;
      MutableBoolean var7 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var8;
         for(var8 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var8) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var8 > 0) {
            for(int var9 = 0; var9 < var8; ++var9) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getUsers", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      Result var15;
      try {
         if (!this.useGlobalTransaction) {
            var5 = (TransactionControl)jtaHelper.getTransactionControl(var5, this.environmentManager);
            var4 = jtaHelper.useTransaction(var5, this.environmentManager);
            if (var4) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getUsers", "preinvoke(false,true)");
               }

               var6 = var5.preinvoke(false, true);
            }
         }

         var15 = (Result)ProfileSecurityManager.singleton().runAsSuperUser(new 4(this, var1, var2, var7));
      } catch (Exception var13) {
         this.handleCustomRemoteExceptions((WIMException)var13);
         this.handleTxException(var13);
         throw new CustomRegistryException(var13);
      } finally {
         if (!this.useGlobalTransaction && var4) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getUsers", "closeTransaction(" + var5 + " , " + var6 + " , " + var7.value + ")");
            }

            jtaHelper.closeTransaction("getUsers", var5, var6, var7.value);
         }

      }

      return var15;
   }

	public String getUserDisplayName(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getUserDisplayName", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      String var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getUserDisplayName", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 5(this, var1, var6));
      } catch (Exception var12) {
         this.handleEntryNotFoundException((WIMException)var12);
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getUserDisplayName", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("getUserDisplayName", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public String getUniqueUserId(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getUniqueUserId", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      String var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getUniqueUserId", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 6(this, var1, var6));
      } catch (Exception var12) {
         this.handleEntryNotFoundException((WIMException)var12);
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getUniqueUserId", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("getUniqueUserId", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public String getUserSecurityName(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getUserSecurityName", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      String var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getUserSecurityName", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 7(this, var1, var6));
      } catch (Exception var12) {
         this.handleEntryNotFoundException((WIMException)var12);
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getUserSecurityName", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("getUserSecurityName", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public boolean isValidUser(String var1) throws CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "isValidUser", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      boolean var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "isValidUser", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (Boolean)ProfileSecurityManager.singleton().runAsSuperUser(new 8(this, var1, var6));
      } catch (Exception var12) {
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "isValidUser", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("isValidUser", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public Result getGroups(String var1, int var2) throws CustomRegistryException, RemoteException {
      boolean var4 = false;
      TransactionControl var5 = null;
      TxHandle var6 = null;
      MutableBoolean var7 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var8;
         for(var8 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var8) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var8 > 0) {
            for(int var9 = 0; var9 < var8; ++var9) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getGroups", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      Result var15;
      try {
         if (!this.useGlobalTransaction) {
            var5 = (TransactionControl)jtaHelper.getTransactionControl(var5, this.environmentManager);
            var4 = jtaHelper.useTransaction(var5, this.environmentManager);
            if (var4) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getGroups", "preinvoke(false,true)");
               }

               var6 = var5.preinvoke(false, true);
            }
         }

         var15 = (Result)ProfileSecurityManager.singleton().runAsSuperUser(new 9(this, var1, var2, var7));
      } catch (Exception var13) {
         this.handleCustomRemoteExceptions((WIMException)var13);
         this.handleTxException(var13);
         throw new CustomRegistryException(var13);
      } finally {
         if (!this.useGlobalTransaction && var4) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getGroups", "closeTransaction(" + var5 + " , " + var6 + " , " + var7.value + ")");
            }

            jtaHelper.closeTransaction("getGroups", var5, var6, var7.value);
         }

      }

      return var15;
   }

	public String getGroupDisplayName(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getGroupDisplayName", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      String var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getGroupDisplayName", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 10(this, var1, var6));
      } catch (Exception var12) {
         this.handleEntryNotFoundException((WIMException)var12);
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getGroupDisplayName", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("getGroupDisplayName", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public String getUniqueGroupId(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getUniqueGroupId", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      String var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getUniqueGroupId", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 11(this, var1, var6));
      } catch (Exception var12) {
         this.handleEntryNotFoundException((WIMException)var12);
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getUniqueGroupId", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("getUniqueGroupId", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public List getUniqueGroupIds(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getUniqueGroupIds", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      List var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getUniqueGroupIds", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (List)ProfileSecurityManager.singleton().runAsSuperUser(new 12(this, var1, var6));
      } catch (Exception var12) {
         this.handleEntryNotFoundException((WIMException)var12);
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getUniqueGroupIds", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("getUniqueGroupIds", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public String getGroupSecurityName(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getGroupSecurityName", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      String var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getGroupSecurityName", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 13(this, var1, var6));
      } catch (Exception var12) {
         this.handleEntryNotFoundException((WIMException)var12);
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getGroupSecurityName", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("getGroupSecurityName", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public boolean isValidGroup(String var1) throws CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "isValidGroup", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      boolean var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "isValidGroup", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (Boolean)ProfileSecurityManager.singleton().runAsSuperUser(new 14(this, var1, var6));
      } catch (Exception var12) {
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "isValidGroup", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("isValidGroup", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public List getGroupsForUser(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
      boolean var3 = false;
      TransactionControl var4 = null;
      TxHandle var5 = null;
      MutableBoolean var6 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var7;
         for(var7 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var7) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var7 > 0) {
            for(int var8 = 0; var8 < var7; ++var8) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getGroupsForUser", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      List var14;
      try {
         if (!this.useGlobalTransaction) {
            var4 = (TransactionControl)jtaHelper.getTransactionControl(var4, this.environmentManager);
            var3 = jtaHelper.useTransaction(var4, this.environmentManager);
            if (var3) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getGroupsForUser", "preinvoke(false,true)");
               }

               var5 = var4.preinvoke(false, true);
            }
         }

         var14 = (List)ProfileSecurityManager.singleton().runAsSuperUser(new 15(this, var1, var6));
      } catch (Exception var12) {
         this.handleEntryNotFoundException((WIMException)var12);
         this.handleCustomRemoteExceptions((WIMException)var12);
         this.handleTxException(var12);
         throw new CustomRegistryException(var12);
      } finally {
         if (!this.useGlobalTransaction && var3) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getGroupsForUser", "closeTransaction(" + var4 + " , " + var5 + " , " + var6.value + ")");
            }

            jtaHelper.closeTransaction("getGroupsForUser", var4, var5, var6.value);
         }

      }

      return var14;
   }

	public Result getUsersForGroup(String var1, int var2) throws NotImplementedException, EntryNotFoundException, CustomRegistryException, RemoteException {
      boolean var4 = false;
      TransactionControl var5 = null;
      TxHandle var6 = null;
      MutableBoolean var7 = new MutableBoolean(this, false);
      if (this.domainName != null && !this.domainName.equalsIgnoreCase(DomainManagerUtils.getDomainId())) {
         int var8;
         for(var8 = 0; DomainManagerUtils.isInVMMDomainThreadContext(); ++var8) {
            DomainManagerUtils.cleanUpVMMThreadDomainContext();
         }

         if (var8 > 0) {
            for(int var9 = 0; var9 < var8; ++var9) {
               DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
            }
         } else {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.logp(Level.FINEST, this.className, "getUsersForGroup", "Setting up thread domain context ");
            }

            DomainManagerUtils.setVMMThreadDomainContext(this.domainName);
         }
      }

      Result var15;
      try {
         if (!this.useGlobalTransaction) {
            var5 = (TransactionControl)jtaHelper.getTransactionControl(var5, this.environmentManager);
            var4 = jtaHelper.useTransaction(var5, this.environmentManager);
            if (var4) {
               if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
                  this.wimUserRegistryTrace.entering(this.className, "getUsersForGroup", "preinvoke(false,true)");
               }

               var6 = var5.preinvoke(false, true);
            }
         }

         var15 = (Result)ProfileSecurityManager.singleton().runAsSuperUser(new 16(this, var1, var2, var7));
      } catch (Exception var13) {
         this.handleNotImplementedException((WIMException)var13);
         this.handleEntryNotFoundException((WIMException)var13);
         this.handleCustomRemoteExceptions((WIMException)var13);
         this.handleTxException(var13);
         throw new CustomRegistryException(var13);
      } finally {
         if (!this.useGlobalTransaction && var4) {
            if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
               this.wimUserRegistryTrace.exiting(this.className, "getUsersForGroup", "closeTransaction(" + var5 + " , " + var6 + " , " + var7.value + ")");
            }

            jtaHelper.closeTransaction("getUsersForGroup", var5, var6, var7.value);
         }

      }

      return var15;
   }

	public WSCredential createCredential(String var1)
			throws NotImplementedException, EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = "createCredential";
		if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
			this.wimUserRegistryTrace.entering(this.className, var2, "inputUserSecurityName = \"" + var1 + "\"");
		}

		Object var3 = null;
		if (this.wimUserRegistryTrace.isLoggable(Level.FINER)) {
			this.wimUserRegistryTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return (WSCredential) var3;
	}

	private void handleCustomRemoteExceptions(WIMException var1) throws CustomRegistryException, RemoteException {
		if (var1 instanceof AuthPrivilegedException) {
			if (var1.getCause() instanceof CustomRegistryException) {
				throw (CustomRegistryException) var1.getCause();
			}

			if (var1.getCause() instanceof RemoteException) {
				throw (RemoteException) var1.getCause();
			}
		}

	}

	private void handleEntryNotFoundException(WIMException var1) throws EntryNotFoundException {
		if (var1 instanceof AuthPrivilegedException && var1.getCause() instanceof EntryNotFoundException) {
			throw (EntryNotFoundException) var1.getCause();
		}
	}

	private void handlePasswordCheckFailedException(WIMException var1) throws PasswordCheckFailedException {
		if (var1 instanceof AuthPrivilegedException && var1.getCause() instanceof PasswordCheckFailedException) {
			throw (PasswordCheckFailedException) var1.getCause();
		}
	}

	private void handleCertificateExceptions(WIMException var1)
			throws CertificateMapNotSupportedException, CertificateMapFailedException {
		if (var1 instanceof AuthPrivilegedException) {
			if (var1.getCause() instanceof CertificateMapNotSupportedException) {
				throw (CertificateMapNotSupportedException) var1.getCause();
			}

			if (var1.getCause() instanceof CertificateMapFailedException) {
				throw (CertificateMapFailedException) var1.getCause();
			}
		}

	}

	private void handleNotImplementedException(WIMException var1) throws NotImplementedException {
		if (var1 instanceof AuthPrivilegedException && var1.getCause() instanceof NotImplementedException) {
			throw (NotImplementedException) var1.getCause();
		}
	}

	public static boolean getCurrentWASState() {
		return WASStartUp;
	}

	public static void seWASState() {
		WASStartUp = false;
	}

	private void handleTxException(Exception var1) throws CustomRegistryException {
		if (var1 instanceof NotSupportedException) {
			throw (CustomRegistryException) var1;
		} else if (var1 instanceof SystemException) {
			throw (CustomRegistryException) var1;
		}
	}

	private void closeTransaction(TransactionControl var1, TxHandle var2) {
		try {
			var1.postinvoke(var2);
		} catch (Exception var4) {
			var1.handleException(var2);
		}

	}
}