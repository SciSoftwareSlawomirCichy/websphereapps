package com.ibm.json.java;

import com.ibm.json.java.internal.Parser;
import com.ibm.json.java.internal.Serializer;
import com.ibm.json.java.internal.SerializerVerbose;
import java.io.BufferedWriter;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.HashMap;

public class JSONObject extends HashMap implements JSONArtifact {
	private static final long serialVersionUID = -3269263069889337298L;

	public static boolean isValidObject(Object var0) {
		return null == var0 ? true : isValidType(var0.getClass());
	}

	public static boolean isValidType(Class var0) {
		if (null == var0) {
			throw new IllegalArgumentException();
		} else if (String.class == var0) {
			return true;
		} else if (Boolean.class == var0) {
			return true;
		} else if (JSONObject.class.isAssignableFrom(var0)) {
			return true;
		} else if (JSONArray.class == var0) {
			return true;
		} else {
			return Number.class.isAssignableFrom(var0);
		}
	}

	public static JSONObject parse(Reader var0) throws IOException {
		return (new Parser(var0)).parse();
	}

	public static JSONObject parse(String var0) throws IOException {
		StringReader var1 = new StringReader(var0);
		return parse((Reader) var1);
	}

	public static JSONObject parse(InputStream var0) throws IOException {
		InputStreamReader var1 = null;

		try {
			var1 = new InputStreamReader(var0, "UTF-8");
		} catch (Exception var3) {
			var1 = new InputStreamReader(var0);
		}

		return parse((Reader) var1);
	}

	public void serialize(OutputStream var1) throws IOException {
		this.serialize(var1, false);
	}

	public void serialize(OutputStream var1, boolean var2) throws IOException {
		BufferedWriter var3 = null;

		try {
			var3 = new BufferedWriter(new OutputStreamWriter(var1, "UTF-8"));
		} catch (UnsupportedEncodingException var6) {
			IOException var5 = new IOException(var6.toString());
			var5.initCause(var6);
			throw var5;
		}

		this.serialize((Writer) var3, var2);
	}

	public void serialize(Writer var1) throws IOException {
		this.serialize(var1, false);
	}

	public void serialize(Writer var1, boolean var2) throws IOException {
		Class var4 = var1.getClass();
		if (!StringWriter.class.isAssignableFrom(var4) && !CharArrayWriter.class.isAssignableFrom(var4)
				&& !BufferedWriter.class.isAssignableFrom(var4)) {
			var1 = new BufferedWriter((Writer) var1);
		}

		Object var3;
		if (var2) {
			var3 = new SerializerVerbose((Writer) var1);
		} else {
			var3 = new Serializer((Writer) var1);
		}

		((Serializer) var3).writeObject(this).flush();
	}

	public String serialize(boolean var1) throws IOException {
		StringWriter var3 = new StringWriter();
		Object var2;
		if (var1) {
			var2 = new SerializerVerbose(var3);
		} else {
			var2 = new Serializer(var3);
		}

		((Serializer) var2).writeObject(this).flush();
		return var3.toString();
	}

	public String serialize() throws IOException {
		return this.serialize(false);
	}

	public Object put(Object var1, Object var2) {
		if (null == var1) {
			throw new IllegalArgumentException("key must not be null");
		} else if (!(var1 instanceof String)) {
			throw new IllegalArgumentException("key must be a String");
		} else if (!isValidObject(var2)) {
			if (var2 != null) {
				throw new IllegalArgumentException("Invalid type of value.  Type: [" + var2.getClass().getName()
						+ "] with value: [" + var2.toString() + "]");
			} else {
				throw new IllegalArgumentException("Invalid type of value.");
			}
		} else {
			return super.put(var1, var2);
		}
	}

	public String toString() {
		String var1 = null;

		try {
			var1 = this.serialize(false);
		} catch (IOException var3) {
			var1 = "JSON Generation Error: [" + var3.toString() + "]";
		}

		return var1;
	}
}