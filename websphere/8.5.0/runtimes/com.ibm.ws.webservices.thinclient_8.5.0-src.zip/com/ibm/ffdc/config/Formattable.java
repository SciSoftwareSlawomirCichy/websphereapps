package com.ibm.ffdc.config;

public interface Formattable {
	void formatTo(IncidentStream var1);
}