package com.ibm.ejs.util;

public class RingBuffer {
	private Object[] buffer;
	private int head = 0;
	private int tail = 0;
	private Object headLock = new Object();
	private Object tailLock = new Object();

	public RingBuffer(int size) {
		this.buffer = new Object[size];
	}

	public Object popHead() {
		Object var1 = this.headLock;
		synchronized (this.headLock) {
			Object result = this.buffer[this.head];
			if (result != null) {
				this.buffer[this.head] = null;
				this.head = ++this.head < this.buffer.length ? this.head : 0;
			}

			return result;
		}
	}

	public boolean pushTail(Object o) {
		Object var2 = this.tailLock;
		synchronized (this.tailLock) {
			if (this.buffer[this.tail] == null) {
				this.buffer[this.tail] = o;
				this.tail = ++this.tail < this.buffer.length ? this.tail : 0;
				return true;
			} else {
				return false;
			}
		}
	}

	public int size() {
		Object var1 = this.headLock;
		synchronized (this.headLock) {
			Object var2 = this.tailLock;
			int var10000;
			synchronized (this.tailLock) {
				if (this.head < this.tail) {
					var10000 = this.tail - this.head;
					return var10000;
				}

				if (this.head > this.tail) {
					var10000 = this.buffer.length - this.head + this.tail;
					return var10000;
				}

				var10000 = this.buffer[this.head] == null ? 0 : this.buffer.length;
			}

			return var10000;
		}
	}
}