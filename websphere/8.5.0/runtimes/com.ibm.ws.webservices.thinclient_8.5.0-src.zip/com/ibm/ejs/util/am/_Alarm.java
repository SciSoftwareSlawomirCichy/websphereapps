package com.ibm.ejs.util.am;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.ffdc.Manager;
import java.util.concurrent.Delayed;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

class _Alarm implements Alarm, Delayed, Runnable {
	private static final TraceComponent tc = Tr.register(_Alarm.class, (String) null, (String) null);
	long expirationTime;
	private static long localAlarmId = 1L;
	long alarmId;
	Object context;
	AlarmListener listener;
	boolean deferrable;
	boolean fired = false;
	Executor executor;

	_Alarm() {
		this.expirationTime = -1L;
		this.alarmId = getNextId();
		this.context = null;
		this.listener = null;
		this.deferrable = true;
	}

	_Alarm(long t, AlarmListener l, Object o, boolean d, Executor e) {
		this.expirationTime = t;
		this.alarmId = getNextId();
		this.listener = l;
		this.context = o;
		this.deferrable = d;
		this.executor = e;
	}

	void execute() {
		boolean isAnyTracingEnabled = TraceComponent.isAnyTracingEnabled();
		if (isAnyTracingEnabled && tc.isEntryEnabled()) {
			Tr.entry(tc, "firing alarm", this);
		}

		try {
			this.executor.execute(this);
		} catch (Throwable var5) {
			Throwable ex = var5;

			try {
				Manager.Ffdc.log(ex, this, "com.ibm.ejs.util.am._Alarm.execute", "103", new Object[]{this});
			} catch (NoClassDefFoundError var4) {
				Tr.event(tc, "Exception in alarm execution", new Object[]{this, var5});
			}
		}

		if (isAnyTracingEnabled && tc.isEntryEnabled()) {
			Tr.exit(tc, "alarm fired");
		}

	}

	public void run() {
		try {
			this.runImpl();
		} catch (Throwable var4) {
			Throwable t = var4;

			try {
				Manager.Ffdc.log(t, this, "com.ibm.ejs.util.am._Alarm.run", "95", new Object[]{this});
			} catch (NoClassDefFoundError var3) {
				;
			}

			Tr.event(tc, "firing alarm failed", new Object[]{this, var4});
		}

	}

	protected void runImpl() {
		this.listener.alarm(this.context);
	}

	public void cancel() {
		AlarmManager.cancel(this);
	}

	private static final synchronized long getNextId() {
		return (long) (localAlarmId++);
	}

	public final int compareTo(Delayed c) {
		if (this == c) {
			return 0;
		} else {
			long otherExpirationTime = ((_Alarm) c).expirationTime;
			if (this.expirationTime < otherExpirationTime) {
				return -1;
			} else if (this.expirationTime > otherExpirationTime) {
				return 1;
			} else {
				long otherAlarmId = ((_Alarm) c).alarmId;
				if (this.alarmId < otherAlarmId) {
					return -1;
				} else {
					return this.alarmId > otherAlarmId ? 1 : 0;
				}
			}
		}
	}

	public String toString() {
		return "_Alarm(" + this.expirationTime + "," + Util.identity(this.listener) + "," + Util.identity(this.context)
				+ ")";
	}

	public long getDelay(TimeUnit unit) {
		throw new UnsupportedOperationException();
	}
}