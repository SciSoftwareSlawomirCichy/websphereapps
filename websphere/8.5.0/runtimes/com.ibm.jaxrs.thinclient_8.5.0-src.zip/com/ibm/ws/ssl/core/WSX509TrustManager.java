package com.ibm.ws.ssl.core;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.websphere.ssl.JSSEHelper;
import com.ibm.ws.ssl.config.CertificateManager;
import com.ibm.ws.ssl.config.KeyStoreManager;
import com.ibm.ws.ssl.config.SSLConfig;
import com.ibm.ws.ssl.config.SSLConfigManager;
import com.ibm.ws.ssl.config.ThreadManager;
import com.ibm.ws.ssl.core.WSX509TrustManager.TimerAlarm;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider;
import com.ibm.ws.util.PlatformHelperFactory;
import com.ibm.wsspi.ssl.TrustManagerExtendedInfo;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Properties;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public final class WSX509TrustManager implements X509TrustManager {
	private TrustManager[] tm = null;
	private KeyStore ts = null;
	private String tsPw = null;
	private String tsFile = null;
	private String tsPass = null;
	private Map extendedInfo = null;
	private String peerHost = null;
	private SSLConfig config = null;
	private ArrayList signersAdded = new ArrayList();
	private ArrayList messagesPrinted = new ArrayList();
	private Class trustEvaluatorClass = null;
	private Object trustedIDEvaluatorObject = null;
	private Method mutualAuthCBINDCheckMethod = null;
	boolean isDoubleByteSystem = false;
	boolean skipDefaultTMIfCustomTMDefined = false;
	public static final int MAX_MSG_LEN = 79;
	public static final String INDENT = "           ";
	private static final TraceComponent tc = Tr.register(WSX509TrustManager.class, "SSL",
			"com.ibm.ws.ssl.resources.ssl");
	private static final TimerAlarm timer = new TimerAlarm();
	private static final String TRUST_EVALUATOR_CLASS_NAME = "com.ibm.ws.security.zOS.TrustedIDEvaluatorImpl";

	public WSX509TrustManager(TrustManager[] tmArray, Map connectionInfo, SSLConfig sslConfig, KeyStore trustStore,
			String trustStoreFilename, String trustStorePassword) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "WSX509TrustManager", new Object[]{connectionInfo, trustStoreFilename});
		}

		this.tm = tmArray;
		this.ts = trustStore;
		this.tsFile = trustStoreFilename;
		this.tsPass = trustStorePassword;
		this.config = sslConfig;
		this.extendedInfo = connectionInfo;
		String skip = SSLConfigManager.getInstance()
				.getGlobalProperty("com.ibm.ssl.skipDefaultTrustManagerWhenCustomDefined");
		if (skip != null && skip.equalsIgnoreCase("true")) {
			this.skipDefaultTMIfCustomTMDefined = true;
		}

		if (this.extendedInfo != null) {
			this.peerHost = (String) this.extendedInfo.get("com.ibm.ssl.remoteHost");

			for (int i = 0; i < tmArray.length; ++i) {
				if (tmArray[i] != null && tmArray[i] instanceof TrustManagerExtendedInfo) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Adding extended info to TrustManager " + tmArray[i].getClass().getName());
					}

					((TrustManagerExtendedInfo) tmArray[i]).setExtendedInfo(this.extendedInfo);
					((TrustManagerExtendedInfo) tmArray[i]).setSSLConfig(sslConfig);
				}
			}
		}

		if (PlatformHelperFactory.getPlatformHelper().isZOS()
				&& !PlatformHelperFactory.getPlatformHelper().isClientJvm()) {
			try {
				this.trustEvaluatorClass = Class.forName("com.ibm.ws.security.zOS.TrustedIDEvaluatorImpl");
				this.trustedIDEvaluatorObject = this.trustEvaluatorClass.newInstance();
				this.mutualAuthCBINDCheckMethod = this.trustEvaluatorClass.getMethod("mutualAuthCBINDCheck",
						X509Certificate[].class);
			} catch (Exception var9) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "No class, object, or method found for CBIND check", new Object[]{var9});
				}

				Manager.Ffdc.log(var9, this, "com.ibm.ws.ssl.core.WSX509TrustManager.WSX509TrustManager", "156",
						new Object[]{this});
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "WSX509TrustManager");
		}

	}

	public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkClientTrusted");
		}

		this.extendedInfo = JSSEHelper.getInstance().getInboundConnectionInfo();
		if (this.extendedInfo != null) {
			this.peerHost = (String) this.extendedInfo.get("com.ibm.ssl.remoteHost");
		}

		if (this.peerHost == null || this.peerHost != null && this.peerHost.equals("")) {
			this.peerHost = "unknown";
		}

		try {
			int i;
			if (tc.isDebugEnabled()) {
				for (i = 0; i < chain.length; ++i) {
					Tr.debug(tc, "chain[" + i + "]: " + chain[i].getSubjectDN());
				}
			}

			if (this.isCertificateAuthenticationDisabled()) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Certificate authentication is temporarily disabled due to configuration change.");
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "checkClientTrusted");
				}

				return;
			}

			for (i = 0; i < this.tm.length; ++i) {
				if (this.tm[i] != null && this.tm[i] instanceof X509TrustManager) {
					if (this.skipDefaultTMIfCustomTMDefined && i == 0 && this.tm.length > 1) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Skipping default trust manager name: " + this.tm[i].getClass().getName());
						}
					} else {
						this.checkClientTrusted((X509TrustManager) this.tm[i], chain, authType);
					}
				}
			}

			if (PlatformHelperFactory.getPlatformHelper().isZOS()
					&& !PlatformHelperFactory.getPlatformHelper().isClientJvm()) {
				Map connectionInfo = JSSEHelper.getInstance().getInboundConnectionInfo();
				if (connectionInfo != null) {
					String endpointName = (String) connectionInfo.get("com.ibm.ssl.endPointName");
					if (endpointName != null && endpointName.startsWith("WC_")) {
						try {
							if (this.mutualAuthCBINDCheckMethod != null && !(Boolean) this.mutualAuthCBINDCheckMethod
									.invoke(this.trustedIDEvaluatorObject, chain)) {
								if (tc.isEntryEnabled()) {
									Tr.exit(tc, "checkClientTrusted");
								}

								throw new CertificateException("CBIND check failed.");
							}
						} catch (Exception var6) {
							if (var6 instanceof CertificateException) {
								throw (CertificateException) var6;
							}

							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "checkClientTrusted");
							}

							throw new CertificateException("CBIND check failed.", var6);
						}
					}
				}
			}
		} catch (Throwable var7) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Caught exception in checkClientTrusted.", new Object[]{var7});
			}

			Manager.Ffdc.log(var7, this, "com.ibm.ws.ssl.core.WSX509TrustManager.checkClientTrusted", "271",
					new Object[]{this});
			if (var7 instanceof RuntimeException) {
				throw (RuntimeException) var7;
			}

			if (var7 instanceof CertificateException) {
				throw (CertificateException) var7;
			}

			throw new CertificateException(var7);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "checkClientTrusted");
		}

	}

	void checkClientTrusted(X509TrustManager tm, X509Certificate[] chain, String authType) throws CertificateException {
		try {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Delegating to X509TrustManager: " + tm.getClass().getName());
			}

			tm.checkClientTrusted(chain, authType);
		} catch (Exception var5) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Certificate Exception occurred: " + var5.getMessage());
			}

			Manager.Ffdc.log(var5, this, "com.ibm.ws.ssl.core.WSX509TrustManager.checkServerTrusted", "215",
					new Object[]{this});
			this.printClientHandshakeError(this.config, this.extendedInfo, this.tsFile, var5, chain, authType);
			if (var5 instanceof CertificateException) {
				throw (CertificateException) var5;
			} else {
				throw new CertificateException(var5.getMessage());
			}
		}
	}

	public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkServerTrusted");
		}

		Map currentConnectionInfo = ThreadManager.getInstance().getOutboundConnectionInfoInternal();
		if (currentConnectionInfo != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "original peerHost: " + this.peerHost);
				Tr.debug(tc, "currentConnectionInfo: " + currentConnectionInfo);
			}

			this.peerHost = (String) currentConnectionInfo.get("com.ibm.ssl.remoteHost");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "current peerHost: " + this.peerHost);
			}
		} else {
			currentConnectionInfo = this.extendedInfo;
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "currentConnectinInfo from extendedInfo: " + currentConnectionInfo);
			}
		}

		if (this.peerHost == null || this.peerHost != null && this.peerHost.equals("")) {
			this.peerHost = "unknown";
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Target host: " + this.peerHost);

			for (int j = 0; j < chain.length; ++j) {
				Tr.debug(tc, "Certificate information:");
				Tr.debug(tc, "  Subject DN: " + chain[j].getSubjectDN());
				Tr.debug(tc, "  Issuer DN: " + chain[j].getIssuerDN());
				Tr.debug(tc, "  Serial number: " + chain[j].getSerialNumber());
				Tr.debug(tc, "");
			}
		}

		if (this.isCertificateAuthenticationDisabled()) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Certificate authentication is temporarily disabled due to configuration change.");
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "checkServerTrusted");
			}

		} else {
			CertificateException originalException = null;

			for (int i = 0; i < this.tm.length; ++i) {
				if (this.tm[i] != null && this.tm[i] instanceof TrustManagerExtendedInfo) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc,
								"Setting current connection info to TrustManager " + this.tm[i].getClass().getName());
					}

					((TrustManagerExtendedInfo) this.tm[i]).setExtendedInfo(currentConnectionInfo);
				}

				if (this.tm[i] != null && this.tm[i] instanceof X509TrustManager) {
					if (this.skipDefaultTMIfCustomTMDefined && i == 0 && this.tm.length > 1) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Skipping default trust manager name: " + this.tm[i].getClass().getName());
						}
					} else {
						boolean var6 = false;

						try {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Delegating to X509TrustManager: " + this.tm[i].getClass().getName());
							}

							((X509TrustManager) this.tm[i]).checkServerTrusted(chain, authType);
						} catch (CertificateException var27) {
							CertificateException e = var27;
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Certificate Exception occurred: " + var27.getMessage());
							}

							boolean dateValid = this.checkIfExpiredBeforeOrAfter(chain);
							if (!dateValid) {
								throw var27;
							}

							boolean added = false;
							boolean readOnly = false;
							String readOnlyValue = this.getProperty("com.ibm.ssl.trustStoreReadOnly", this.config,
									SSLConfigManager.getInstance().isServerProcess());
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "readOnlyValue is " + readOnlyValue);
							}

							if (readOnlyValue != null && readOnlyValue.equalsIgnoreCase("true")) {
								readOnly = true;
							}

							boolean autoAccept = ThreadManager.getInstance().getAutoAcceptBootstrapSigner();
							if (tc.isDebugEnabled()) {
								Tr.debug(tc,
										"Server is NOT trusted by X509TrustManager, auto accept mode? " + autoAccept);
							}

							ThreadManager.getInstance().setAutoAcceptBootstrapSigner(false);
							boolean autoAcceptWithoutStorage = ThreadManager.getInstance()
									.getAutoAcceptBootstrapSignerWithoutStorage();
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Server is NOT trusted by X509TrustManager, auto accept w/o storage mode? "
										+ autoAcceptWithoutStorage);
							}

							ThreadManager.getInstance().setAutoAcceptBootstrapSignerWithoutStorage(false);
							String prompt = this.getProperty("com.ibm.ssl.enableSignerExchangePrompt", this.config,
									SSLConfigManager.getInstance().isServerProcess());
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Server is NOT trusted by X509TrustManager, prompt for signer exchange? "
										+ prompt);
							}

							if (autoAcceptWithoutStorage || !autoAccept && (prompt == null
									|| !prompt.equalsIgnoreCase("true") && !prompt.equalsIgnoreCase("yes")
											&& !prompt.equalsIgnoreCase("gui") && !prompt.equalsIgnoreCase("stdin"))) {
								if (ThreadManager.getInstance().getSetSignerOnThread()) {
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Setting signer chain on the thread from the WSX509TrustManager.");
									}

									ThreadManager.getInstance().setSignerChain(chain);
								} else {
									if (autoAcceptWithoutStorage) {
										if (tc.isDebugEnabled()) {
											Tr.debug(tc, "Accepting signer but not storing into trust store.");
										}

										if (tc.isEntryEnabled()) {
											Tr.exit(tc, "checkServerTrusted");
										}

										return;
									}

									this.printClientHandshakeError(this.config, currentConnectionInfo, this.tsFile,
											var27, chain, authType);
								}
							} else {
								String shaDigest = "Cannot determine SHA digest.";
								String md5Digest = "Cannot determine MD5 digest.";
								String answer = null;
								String yes = TraceNLSHelper.getInstance()
										.getString("ssl.trustmanager.signer.prompt.answer.yes", "y");
								yes = TraceNLSHelper.getInstance()
										.getString("ssl.trustmanager.signer.prompt.answer.yes", "y");
								if (yes != null) {
									yes = yes.trim().toLowerCase();
									if (yes.length() == 0) {
										yes = "y";
									}
								} else {
									yes = "y";
								}

								if (tc.isDebugEnabled()) {
									Tr.debug(tc, "Translated yes string is: " + yes);
								}

								try {
									shaDigest = KeyStoreManager.getInstance().generateDigest("SHA-1",
											chain[chain.length - 1]);
									md5Digest = KeyStoreManager.getInstance().generateDigest("MD5",
											chain[chain.length - 1]);
									if (shaDigest != null) {
										added = this.signersAdded.contains(shaDigest);
									}
								} catch (NoClassDefFoundError var26) {
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "No class found for generateDigest.", new Object[]{var26});
									}

									Manager.Ffdc.log(var26, this,
											"com.ibm.ws.ssl.core.WSX509TrustManager.checkServerTrusted", "424",
											new Object[]{this});
								}

								if (!added) {
									if (!autoAccept && !SSLConfigManager.getInstance().isServerProcess()) {
										if (prompt.equalsIgnoreCase("gui")) {
											try {
												SignerPromptPanel promptPanel = new SignerPromptPanel(500,
														this.peerHost, this.tsFile, chain[0].getSubjectDN().toString(),
														chain[0].getIssuerDN().toString(),
														chain[0].getSerialNumber().toString(),
														chain[0].getNotAfter().toString(), shaDigest, md5Digest);
												int result = promptPanel.showPanel();
												if (tc.isDebugEnabled()) {
													Tr.debug(tc, "Result from prompt panel: " + result);
												}

												if (result == 3) {
													answer = TraceNLSHelper.getInstance().getString(
															"ssl.trustmanager.signer.prompt.answer.yes", "y");
												} else {
													answer = TraceNLSHelper.getInstance()
															.getString("ssl.trustmanager.signer.prompt.answer.no", "n");
												}

												if (answer != null) {
													answer = answer.trim().toLowerCase();
												}
											} catch (Throwable var25) {
												if (tc.isDebugEnabled()) {
													Tr.debug(tc,
															"Received the following exception starting GUI prompt.",
															new Object[]{var25});
												}

												Manager.Ffdc.log(var25, this,
														"com.ibm.ws.ssl.core.WSX509TrustManager.checkServerTrusted",
														"462", new Object[]{this});
												answer = null;
											}
										}

										if (answer == null) {
											try {
												System.out.println("");
												System.out.println(TraceNLSHelper.getInstance().getString(
														"ssl.trustmanager.signer.prompt.CWPKI0100I",
														"*** SSL SIGNER EXCHANGE PROMPT ***"));
												System.out.println(TraceNLSHelper.getInstance().getFormattedMessage(
														"ssl.trustmanager.signer.prompt.CWPKI0101I",
														new Object[]{this.peerHost, this.tsFile},
														"SSL signer from target host " + this.peerHost
																+ " is not found in trust store " + this.tsFile
																+ ".\n\nHere's the signer information (verify the digest value matches what is displayed at the server):"));
												System.out.println("");

												for (int j = 0; j < chain.length; ++j) {
													System.out.println(TraceNLSHelper.getInstance().getString(
															"ssl.trustmanager.signer.prompt.CWPKI0102I",
															"  Subject DN:    ") + chain[j].getSubjectDN());
													System.out.println(TraceNLSHelper.getInstance().getString(
															"ssl.trustmanager.signer.prompt.CWPKI0103I",
															"  Issuer DN:     ") + chain[j].getIssuerDN());
													System.out.println(TraceNLSHelper.getInstance().getString(
															"ssl.trustmanager.signer.prompt.CWPKI0104I",
															"  Serial number: ") + chain[j].getSerialNumber());
													System.out.println(TraceNLSHelper.getInstance().getString(
															"ssl.trustmanager.signer.prompt.CWPKI0109I", "  Expires: ")
															+ chain[j].getNotAfter());
													System.out.println(TraceNLSHelper.getInstance().getString(
															"ssl.trustmanager.signer.prompt.CWPKI0105I",
															"  SHA-1 digest:  ") + shaDigest);
													System.out.println(TraceNLSHelper.getInstance().getString(
															"ssl.trustmanager.signer.prompt.CWPKI0106I",
															"  MD5 digest:    ") + md5Digest);
													System.out.println("");
												}

												if (!autoAccept) {
													System.out.print(TraceNLSHelper.getInstance().getString(
															"ssl.trustmanager.signer.prompt.CWPKI0107I",
															"Add signer to the trust store now? (y/n) "));
													System.out.flush();
													BufferedReader stdin = new BufferedReader(
															new InputStreamReader(System.in));
													answer = stdin.readLine();
													if (answer != null) {
														answer = answer.trim().toLowerCase();
													}
												}
											} catch (Exception var24) {
												if (tc.isDebugEnabled()) {
													Tr.debug(tc,
															"Received the following exception added signer to TrustStore.",
															new Object[]{var24});
												}

												Manager.Ffdc.log(var24, this,
														"com.ibm.ws.ssl.core.WSX509TrustManager.checkServerTrusted",
														"501", new Object[]{this});
											}
										}
									}

									try {
										if (!readOnly && (autoAccept || answer != null
												&& (answer.startsWith("y") || answer.startsWith(yes)))) {
											if (tc.isDebugEnabled()) {
												Tr.debug(tc,
														"Adding cert "
																+ chain[chain.length - 1].getSubjectDN().getName()
																+ " to TrustStore " + this.tsFile + ".");
											}

											String alias = chain[chain.length - 1].getSubjectDN().getName();
											if (alias.length() > 32) {
												alias = alias.substring(0, 31);
											}

											alias = alias.trim();
											String trustStoreName;
											if (!this.ts.containsAlias(alias)) {
												if (tc.isDebugEnabled()) {
													Tr.debug(tc, "Adding alias \"" + alias + "\" to truststore \""
															+ this.tsFile + "\".");
												}

												this.ts.setCertificateEntry(alias, chain[chain.length - 1]);
												if (autoAccept) {
													trustStoreName = this.getProperty("com.ibm.ssl.trustStoreName",
															this.config,
															SSLConfigManager.getInstance().isServerProcess());
													this.issueMessage("ssl.signer.add.to.local.truststore.CWPKI0308I",
															new Object[]{alias, trustStoreName, shaDigest},
															"CWPKI0308I: Adding signer alias \"" + alias
																	+ "\" to local keystore \"" + trustStoreName
																	+ "\" with the following SHA digest: " + shaDigest);
												}
											} else {
												trustStoreName = CertificateManager.getInstance()
														.incrementAlias(this.ts, alias);
												if (tc.isDebugEnabled()) {
													Tr.debug(tc, "Adding alias \"" + trustStoreName
															+ "\" to truststore \"" + this.tsFile + "\".");
												}

												this.ts.setCertificateEntry(trustStoreName, chain[chain.length - 1]);
												if (autoAccept) {
													String trustStoreName = this.getProperty(
															"com.ibm.ssl.trustStoreName", this.config,
															SSLConfigManager.getInstance().isServerProcess());
													this.issueMessage("ssl.signer.add.to.local.truststore.CWPKI0308I",
															new Object[]{trustStoreName, trustStoreName, shaDigest},
															"CWPKI0308I: Adding signer alias \"" + trustStoreName
																	+ "\" to local keystore \"" + trustStoreName
																	+ "\" with the following SHA digest: " + shaDigest);
												}
											}

											OutputStream fos = KeyStoreManager.getInstance()
													.getOutputStream(this.tsFile);

											try {
												this.ts.store(fos, this.tsPass.toCharArray());
											} catch (IOException var22) {
												if (!this
														.getProperty("com.ibm.ssl.keyStoreType", this.config,
																SSLConfigManager.getInstance().isServerProcess())
														.equals("JCERACFKS")
														&& !this.getProperty("com.ibm.ssl.keyStoreType", this.config,
																SSLConfigManager.getInstance().isServerProcess())
																.equals("JCECCARACFKS")) {
													throw e;
												}

												if (!KeyStoreManager.getInstance()
														.checkIfSignerAlreadyExistsInTrustStore(chain[chain.length - 1],
																this.ts)) {
													throw e;
												}

												Tr.debug(tc, "Certificate already exists in RACF: " + e.getMessage());
											}

											if (shaDigest != null) {
												this.signersAdded.add(shaDigest);
											}

											added = true;
											fos.close();
											AbstractJSSEProvider.clearSSLContextCache();
											KeyStoreManager.getInstance().clearJavaKeyStoresFromKeyStoreMap();
											if (!autoAccept) {
												System.out.println(TraceNLSHelper.getInstance().getString(
														"ssl.trustmanager.signer.prompt.CWPKI0108I",
														"A retry of the request may need to occur."));
											}
										} else {
											if (readOnly && answer != null
													&& (answer.startsWith("y") || answer.startsWith(yes))) {
												ThreadManager.getInstance()
														.setAutoAcceptBootstrapSignerWithoutStorage(true);
												if (tc.isDebugEnabled()) {
													Tr.debug(tc,
															"Accepting signer for read-only keystore per prompt response.");
												}

												if (tc.isEntryEnabled()) {
													Tr.exit(tc, "checkServerTrusted");
												}

												return;
											}

											if (answer != null) {
												this.printClientHandshakeError(this.config, currentConnectionInfo,
														this.tsFile, e, chain, authType);
											}
										}
									} catch (Exception var23) {
										if (tc.isDebugEnabled()) {
											Tr.debug(tc, "Received the following exception added signer to TrustStore.",
													new Object[]{var23});
										}

										Manager.Ffdc.log(var23, this,
												"com.ibm.ws.ssl.core.WSX509TrustManager.checkServerTrusted", "602",
												new Object[]{this});
									}
								}
							}

							if (!added) {
								throw var27;
							}
						}
					}
				}
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Server is trusted by all X509TrustManagers.");
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "checkServerTrusted");
			}

		}
	}

	private boolean checkIfExpiredBeforeOrAfter(X509Certificate[] chain) {
		if (chain != null && chain[0] != null) {
			long currentTime = System.currentTimeMillis();
			long notBefore = chain[0].getNotBefore().getTime();
			long notAfter = chain[0].getNotAfter().getTime();
			if (notBefore > currentTime) {
				Tr.error(tc, "ssl.certificate.before.date.invalid.CWPKI0311E",
						new Object[]{chain[0].getSubjectDN(), new Date(notBefore)});
				return false;
			} else if (notAfter < currentTime) {
				Tr.error(tc, "ssl.certificate.end.date.invalid.CWPKI0312E",
						new Object[]{chain[0].getSubjectDN(), new Date(notAfter)});
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}
	}

	private void printClientHandshakeError(SSLConfig config, Map extendedInfo, String tsFile, Exception e,
			X509Certificate[] chain, String authType) {
		String extendedMessage = e.getMessage();
		String subjectDN = "unknown";
		if (chain[0] != null) {
			subjectDN = chain[0].getSubjectDN().toString();
		}

		String alias = this.getProperty("com.ibm.ssl.alias", config, SSLConfigManager.getInstance().isServerProcess());
		String configURL = this.getProperty("com.ibm.ssl.configURLLoadedFrom", config,
				SSLConfigManager.getInstance().isServerProcess());
		String host = "unknown";
		String port = "0";
		if (extendedInfo != null) {
			host = (String) extendedInfo.get("com.ibm.ssl.remoteHost");
			port = (String) extendedInfo.get("com.ibm.ssl.remotePort");
		}

		String hostport = host + ":" + port;
		String message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.client.handshake.error.CWPKI0022E",
				new Object[]{subjectDN, hostport, tsFile, alias, configURL, extendedMessage},
				"CWPKI0022E: SSL handshake failure occurred.  A signer with SubjectDN " + subjectDN
						+ " was sent from target host/port " + hostport
						+ ".  The signer may need to be added to local trust store " + tsFile
						+ " located in SSL configuration alias " + alias + " loaded from configURL " + configURL
						+ ".  The extended error message from the SSL handshake is: " + extendedMessage);
		if (!this.messagesPrinted.contains(message)) {
			Tr.error(tc, "ssl.client.handshake.error.CWPKI0022E",
					new Object[]{subjectDN, hostport, tsFile, alias, configURL, extendedMessage});
			if (this.messagesPrinted.size() > 20) {
				this.messagesPrinted.clear();
			}

			this.messagesPrinted.add(message);
		}

		String helpMessage;
		if (SSLConfigManager.getInstance().isServerProcess()) {
			helpMessage = this.getProperty("com.ibm.ssl.trustStoreName", config,
					SSLConfigManager.getInstance().isServerProcess());
			String scope = this.getProperty("com.ibm.ssl.trustStoreScope", config,
					SSLConfigManager.getInstance().isServerProcess());
			String hostcert = host + "_cert";
			String helpMessage = null;
			if (host != null && host.length() != 0 && port != null && port.length() != 0) {
				helpMessage = TraceNLSHelper.getInstance().getFormattedMessage(
						"ssl.handshake.failure.server.info.CWPKI0428I",
						new Object[]{scope, helpMessage, host, port, hostcert},
						"The signer might need to be added to the local trust store. You can use the Retrieve from port option in the administrative console to retrieve the certificate and resolve the problem. If you determine that the request is trusted, complete the following steps: 1. Log into the administrative console.  2. Expand Security and click SSL certificate and key management. Under Configuration settings, click Manage endpoint security configurations. 3. Select the appropriate outbound configuration to get to the"
								+ scope
								+ " management scope. 4. Under Related Items, click Key stores and certificates and click the "
								+ helpMessage
								+ " key store. 5. Under Additional Properties, click Signer certificates and Retrieve From Port.  6. In the Host field, enter "
								+ host + " in the host name field, enter " + port + " in the Port field, and "
								+ hostcert
								+ " in the Alias field.  7. Click Retrieve Signer Information.  8. Verify that the certificate information is for a certificate that you can trust. 9. Click Apply and Save.");
			} else {
				helpMessage = TraceNLSHelper.getInstance().getFormattedMessage(
						"ssl.handshake.failure.server.info.CWPKI0429I",
						new Object[]{scope, helpMessage, host, port, hostcert},
						"The signer might need to be added to the local trust store. You can use the Retrieve from port option in the administrative console to retrieve the certificate and resolve the problem. If you determine that the request is trusted, complete the following steps: 1. Log into the administrative console.  2. Expand Security and click SSL certificate and key management. Under Configuration settings, click Manage endpoint security configurations. 3. Select the appropriate outbound configuration to get to the"
								+ scope
								+ " management scope. 4. Under Related Items, click Key stores and certificates and click the "
								+ helpMessage
								+ " key store. 5. Under Additional Properties, click Signer certificates and Retrieve From Port.  6. In the Host field, enter <target host name> in the host name field, enter <target host port> in the Port field, and "
								+ hostcert
								+ " in the Alias field.  7. Click Retrieve Signer Information.  8. Verify that the certificate information is for a certificate that you can trust. 9. Click Apply and Save. If you do not see an actual host and port field specified in step 6, your client has not specified the host and port.");
			}

			if (!this.messagesPrinted.contains(helpMessage)) {
				System.out.println("");
				System.out.println(message);
				System.out.println("");
				System.out.println("");
				System.out.println(helpMessage);
				System.out.println("");
				if (this.messagesPrinted.size() > 20) {
					this.messagesPrinted.clear();
				}

				this.messagesPrinted.add(helpMessage);
			}
		} else {
			helpMessage = TraceNLSHelper.getInstance().getString("ssl.handshake.failure.info.CWPKI0040I",
					"CWPKI0040I: An SSL handshake failure occurred from a client.  The server's SSL signer needs to be added to the client trust store.  A retrieveSigners utility is provided for this function.  Check with your administrator to have this utility run to setup the secure enviroment before running the client.   Additional, the com.ibm.ssl.enableSignerExchangePrompt can be enabled in ssl.client.props for DefaultSSLSettings in order to allow acceptance of the signer during the connection attempt.");
			if (!this.messagesPrinted.contains(helpMessage)) {
				System.out.println("");
				System.out.println(message);
				System.out.println("");
				System.out.println("");
				System.out.println(helpMessage);
				System.out.println("");
				if (this.messagesPrinted.size() > 20) {
					this.messagesPrinted.clear();
				}

				this.messagesPrinted.add(helpMessage);
			}
		}

	}

	public X509Certificate[] getAcceptedIssuers() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getAcceptedIssuers");
		}

		X509Certificate[] allIssuers = null;
		ArrayList allIssuersList = new ArrayList();

		for (int i = 0; i < this.tm.length; ++i) {
			if (this.tm[i] instanceof X509TrustManager) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Delegating to X509TrustManager: " + this.tm[i].getClass().getName());
				}

				allIssuers = (X509Certificate[]) ((X509TrustManager) this.tm[i]).getAcceptedIssuers();
				if (allIssuers != null) {
					for (int j = 0; j < allIssuers.length; ++j) {
						if (!allIssuersList.contains(allIssuers[j])) {
							allIssuersList.add(allIssuers[j]);
						}
					}
				}
			}
		}

		if (allIssuersList.size() > 0) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getAcceptedIssuers");
			}

			return (X509Certificate[]) ((X509Certificate[]) allIssuersList
					.toArray(new X509Certificate[allIssuersList.size()]));
		} else {
			return null;
		}
	}

	protected void issueMessage(String key, Object[] args, String defaultMsg) {
		String msg = TraceNLSHelper.getInstance().getFormattedMessage(key, args, defaultMsg);
		this.printMessage(msg);
	}

	protected void printMessage(String msg) {
		int maxLength = 79;
		if (this.isDoubleByteSystem(msg)) {
			maxLength /= 2;
		}

		this.printMessage(msg, maxLength, false);
	}

	private boolean isDoubleByteSystem(String sampleStr) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		label73 : {
			boolean var5;
			try {
				dos.writeUTF(sampleStr);
				dos.flush();
				break label73;
			} catch (IOException var15) {
				var5 = false;
			} finally {
				try {
					dos.close();
				} catch (IOException var14) {
					;
				}

			}

			return var5;
		}

		byte[] bytes = baos.toByteArray();
		if ((double) bytes.length > (double) sampleStr.length() + (double) sampleStr.length() * 0.1D) {
			this.isDoubleByteSystem = true;
		} else {
			this.isDoubleByteSystem = false;
		}

		return this.isDoubleByteSystem;
	}

	private void printMessage(String msg, int maxLength, boolean indent) {
		int maxLocalLength = maxLength;
		if (indent) {
			System.out.print("           ");
			maxLocalLength = maxLength - "           ".length();
		}

		if (msg.length() <= maxLocalLength) {
			System.out.println(msg);
		} else {
			int i = msg.lastIndexOf(32, maxLocalLength);
			if (i == -1) {
				i = msg.indexOf(32);
				if (i == -1) {
					System.out.println(msg);
					return;
				}
			}

			this.printMessage(msg.substring(0, i), maxLength, false);
			this.printMessage(msg.substring(i + 1), maxLength, true);
		}

	}

	private String getProperty(String propertyName, Properties prop, boolean processIsServer) {
		String value = null;
		if (prop != null) {
			if (!processIsServer) {
				value = System.getProperty(propertyName);
				if (value == null) {
					value = SSLConfigManager.getInstance().getGlobalProperty(propertyName);
				}
			}

			if (value == null) {
				value = prop.getProperty(propertyName);
			}
		} else {
			value = System.getProperty(propertyName);
			if (value == null) {
				value = SSLConfigManager.getInstance().getGlobalProperty(propertyName);
			}
		}

		return value;
	}

	private boolean isCertificateAuthenticationDisabled() {
		return timer.isCertificateAuthenticationDisabled();
	}

	protected static void temporarilyDisableCertificateAuthentication(Long millisToDisable) {
		timer.temporarilyDisableCertificateAuthentication(millisToDisable);
	}
}