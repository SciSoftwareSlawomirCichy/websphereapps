package com.ibm.ejs.oa;

import com.ibm.CORBA.iiop.Profile;
import com.ibm.wsspi.cluster.Identity;

public abstract class WLMProfileService {
	private static WLMProfileService service = null;

	public static WLMProfileService getService() {
		return service;
	}

	protected static void setService(WLMProfileService set_service) {
		service = set_service;
	}

	public abstract void setProfile(Profile var1);

	public abstract void setProfile(Profile var1, Identity var2);
}