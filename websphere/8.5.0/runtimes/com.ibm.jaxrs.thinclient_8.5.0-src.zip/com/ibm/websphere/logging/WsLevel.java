package com.ibm.websphere.logging;

import java.util.logging.Level;

public class WsLevel extends Level {
	private static final long serialVersionUID = -8795434113718441359L;
	public static final Level FATAL = new WsLevel("FATAL", 1100);
	public static final Level AUDIT = new WsLevel("AUDIT", 850);
	public static final Level DETAIL = new WsLevel("DETAIL", 625);
	public static Level[] LEVELS;
	public static int[] LEVEL_VALUES;

	WsLevel(String name, int value) {
		super(name, value, (String) null);
	}

	public static Level parse(String name) throws IllegalArgumentException, NullPointerException {
		if (name != null) {
			name = name.toUpperCase();
			if (name.equals(FATAL.getName())) {
				return FATAL;
			}

			if (name.equals(AUDIT.getName())) {
				return AUDIT;
			}

			if (name.equals(DETAIL.getName())) {
				return DETAIL;
			}
		}

		return Level.parse(name);
	}

	static {
		LEVELS = new Level[]{ALL, FINEST, FINER, FINE, DETAIL, CONFIG, INFO, AUDIT, WARNING, SEVERE, FATAL, OFF};
		LEVEL_VALUES = new int[LEVELS.length];

		for (int i = 0; i < LEVELS.length; ++i) {
			LEVEL_VALUES[i] = LEVELS[i].intValue();
		}

	}
}