package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.BeanNotReentrantException;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerException;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.container.EJSDeployedSupport;
import com.ibm.ejs.container.SessionBeanTimeoutException;
import com.ibm.ejs.container.StatefulBeanO;
import com.ibm.ejs.container.StatefulBeanReaper;
import com.ibm.ejs.container.TimeoutElement;
import com.ibm.ejs.container.passivator.StatefulPassivator;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.IllegalOperationException;
import com.ibm.websphere.csi.PassivationPolicy;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ejbcontainer.failover.SfFailoverClient;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.transaction.TransactionRolledbackException;

public abstract class StatefulSessionActivationStrategy extends ActivationStrategy {
	protected PassivationPolicy passivationPolicy;
	protected StatefulBeanReaper reaper;
	public StatefulPassivator ivPassivator;
	public SfFailoverCache ivSfFailoverCache;
	private static final TraceComponent tc = Tr.register(StatefulSessionActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.activator.StatefulSessionActivationStrategy";

	StatefulSessionActivationStrategy(Activator activator, PassivationPolicy passivationPolicy) {
		this(activator, passivationPolicy, (SfFailoverCache) null);
	}

	StatefulSessionActivationStrategy(Activator activator, PassivationPolicy passivationPolicy,
			SfFailoverCache failoverCache) {
		super(activator);
		this.passivationPolicy = passivationPolicy;
		this.reaper = activator.statefulBeanReaper;
		this.ivPassivator = activator.passivator;
		this.ivSfFailoverCache = failoverCache;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> : " + this + ", " + passivationPolicy + ", " + this.reaper + ", " + this.ivPassivator
					+ ", " + failoverCache);
		}

	}

	BeanO atCreate(ContainerTx tx, BeanO bean) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCreate");
		}

		StatefulBeanO sfbean = (StatefulBeanO) bean;
		BeanId id = bean.getId();
		MasterKey key = new MasterKey(id);
		boolean success = false;
		sfbean.ivCacheLock = this.locks.getLock(key);
		boolean var18 = false;

		Object var8;
		try {
			var18 = true;
			var8 = sfbean.ivCacheLock;
			synchronized (sfbean.ivCacheLock) {
				sfbean.ivCacheElement = this.cache.insert(key, bean);
				sfbean.ivCacheKey = key;
				this.reaper.add(sfbean);
				if (sfbean.sfsbFailoverEnabled()) {
					sfbean.createFailoverEntry();
				}
			}

			if (!bean.enlist(tx)) {
				this.cache.unpinElement(sfbean.ivCacheElement);
			}

			success = true;
			var18 = false;
		} finally {
			if (var18) {
				if (!success) {
					bean.destroy();
					Object var12 = sfbean.ivCacheLock;
					synchronized (sfbean.ivCacheLock) {
						this.cache.removeElement(sfbean.ivCacheElement, true);
						sfbean.ivCacheElement = null;
						sfbean.ivCacheKey = null;
						this.reaper.remove(id);
						if (sfbean.sfsbFailoverEnabled()) {
							sfbean.ivSfFailoverClient.removeEntry(id);
						}
					}

					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "atCreate: exception");
					}
				}

			}
		}

		if (!success) {
			bean.destroy();
			var8 = sfbean.ivCacheLock;
			synchronized (sfbean.ivCacheLock) {
				this.cache.removeElement(sfbean.ivCacheElement, true);
				sfbean.ivCacheElement = null;
				sfbean.ivCacheKey = null;
				this.reaper.remove(id);
				if (sfbean.sfsbFailoverEnabled()) {
					sfbean.ivSfFailoverClient.removeEntry(id);
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atCreate: exception");
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCreate");
		}

		return null;
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit", new Object[]{tx, bean});
		}

		StatefulBeanO sfbean = (StatefulBeanO) bean;
		Object var5 = sfbean.ivCacheLock;
		synchronized (sfbean.ivCacheLock) {
			if (bean.isRemoved()) {
				this.cache.removeElement(sfbean.ivCacheElement, true);
				bean.ivCacheKey = null;
				bean.destroy();
			} else {
				this.cache.unpinElement(sfbean.ivCacheElement);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCommit");
		}

	}

	void atEnlist(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atEnlist", new Object[]{tx, bean});
		}

		StatefulBeanO sfbean = (StatefulBeanO) bean;
		this.cache.pinElement(sfbean.ivCacheElement);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atEnlist");
		}

	}

	BeanO atActivate(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atActivate (" + beanId + ") : " + tx);
		}

		Throwable exception = null;
		MasterKey key = new MasterKey(beanId);
		TimeoutElement elt = null;
		boolean found = false;
		boolean locked = false;
		boolean pushedCallbackBeanO = false;
		EJSDeployedSupport methodContext = threadData.getMethodContext();
		StatefulBeanO bean = methodContext.getCachedWrapperBeanO();
		Object lock = bean != null ? bean.ivCacheLock : this.locks.getLock(key);
		long accessTimeout = Long.MIN_VALUE;
		boolean accessTimeoutReached = false;
		long waitTime = 0L;
		long endTime = 0L;
		synchronized (lock) {
			try {
				if (bean != null && bean.ivCacheKey != null) {
					this.cache.pinElement(bean.ivCacheElement);
				} else {
					bean = (StatefulBeanO) this.cache.find(key);
				}

				while (true) {
					found = bean != null;
					if (!found) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Bean not in cache");
						}

						elt = this.reaper.getTimeoutElement(beanId);
						boolean timedOut;
						if (EJSPlatformHelper.isZOS()) {
							timedOut = this.reaper.beanExistsAndTimedOut(elt, beanId)
									|| this.passivationPolicy.equals(PassivationPolicy.ON_DEMAND);
						} else {
							timedOut = this.reaper.beanDoesNotExistOrHasTimedOut(elt, beanId)
									|| this.passivationPolicy.equals(PassivationPolicy.ON_DEMAND);
						}

						if (timedOut) {
							if (this.reaper.beanExistsAndTimedOut(elt, beanId)) {
								if (isTraceOn && tc.isDebugEnabled()) {
									Tr.debug(tc, "Bean " + beanId + " in passivated filesystem or SfFailoverCache, "
											+ " but timed out.");
								}

								throw new SessionBeanTimeoutException("Stateful bean " + beanId + " timed out.");
							}

							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "Bean " + beanId + " not in the passivated filesystem either.");
							}

							throw new NoSuchObjectException("Stateful bean " + beanId + " was removed or timed out.");
						}

						bean = (StatefulBeanO) beanId.getHome().createBeanO(threadData, tx, beanId);
						pushedCallbackBeanO = true;
						bean.ivCacheLock = lock;
						bean.ivCacheElement = this.cache.insert(key, bean);
						bean.ivCacheKey = key;
						found = true;
						bean.initializeTimeout(elt);
						bean.activate(beanId, tx);
						if (elt == null) {
							this.reaper.add(bean);
						}

						if (bean.sfsbFailoverEnabled()) {
							bean.updateFailoverSetActiveProp();
						}

						if (beanId.getBeanMetaData().ivHasAppManagedPersistenceContext
								|| beanId.getBeanMetaData().ivHasCMExtendedPersistenceContext) {
							this.cache.markEvictionIneligible(key);
						}

						bean.lock(methodContext, tx);
						locked = true;
						break;
					}

					locked = bean.lock(methodContext, tx);
					tx = methodContext.getCurrentTx();
					if (locked) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Found bean - locked, attempting to use");
						}

						threadData.pushCallbackBeanO(bean);
						pushedCallbackBeanO = true;
						break;
					}

					if (accessTimeout == Long.MIN_VALUE) {
						accessTimeout = methodContext.getConcurrencyAccessTimeout();
						accessTimeoutReached = accessTimeout == 0L;
					}

					if (accessTimeoutReached) {
						bean = null;
						this.cache.unpin(key);
						String msg = "Stateful bean in use on another thread; access-timeout reached (" + accessTimeout
								+ " ms)";
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, msg);
						}

						throw new BeanNotReentrantException(msg, true);
					}

					bean.addLockWaiter();
					bean = null;
					this.cache.unpin(key);
					if (accessTimeout > 0L && endTime == 0L) {
						waitTime = accessTimeout;
						endTime = System.currentTimeMillis() + accessTimeout;
					}

					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Found bean - in use, waiting : " + waitTime + ", lock = " + lock);
					}

					lock.wait(waitTime);
					if (accessTimeout > 0L) {
						waitTime = endTime - System.currentTimeMillis();
						if (waitTime <= 0L) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "AccessTimeout reached");
							}

							accessTimeoutReached = true;
						}
					}

					bean = (StatefulBeanO) this.cache.find(key);
				}

				if (bean.isTimedOut()) {
					throw new SessionBeanTimeoutException("Stateful bean " + bean + " timed out");
				}

				if (bean.enlist(tx, methodContext.isTxEnlistNeededForActivate())) {
					this.cache.pinElement(bean.ivCacheElement);
				}
			} catch (InterruptedException var60) {
				FFDCFilter.processException(var60,
						"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atActivate", "384", this);
				exception = var60;
				throw new ContainerException(var60);
			} catch (NoSuchObjectException var61) {
				exception = var61;
				throw var61;
			} catch (RemoteException var62) {
				FFDCFilter.processException(var62,
						"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atActivate", "169", this);
				exception = var62;
				throw var62;
			} catch (RuntimeException var63) {
				FFDCFilter.processException(var63,
						"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atActivate", "175", this);
				exception = var63;
				throw var63;
			} finally {
				if (exception != null && isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "atActivation: exception raised", exception);
				}

				if (exception != null && bean != null) {
					if (pushedCallbackBeanO) {
						threadData.popCallbackBeanO();
					}

					if (found) {
						try {
							this.cache.remove(key, true);
							bean.ivCacheKey = null;
							this.reaper.remove(beanId);
							bean.destroy();
						} catch (IllegalOperationException var58) {
							this.cache.unpin(key);
						} finally {
							if (locked) {
								bean.unlock(lock);
							}

						}
					} else {
						bean.destroy();
					}
				}

			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atActivate : " + bean);
		}

		return bean;
	}

	void atPostInvoke(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atPostInvoke : " + tx + ", " + bean);
		}

		StatefulBeanO sfbean = (StatefulBeanO) bean;
		BeanId id = bean.getId();
		Object lock = sfbean.ivCacheLock;
		synchronized (lock) {
			if (sfbean.ivCacheKey != null) {
				this.cache.unpinElement(sfbean.ivCacheElement);
				if (!sfbean.isRemoved() && !sfbean.isDiscarded()) {
					sfbean.setLastAccessTime(System.currentTimeMillis());
				} else {
					if (tx != null) {
						try {
							tx.delist(sfbean);
						} catch (TransactionRolledbackException var10) {
							FFDCFilter.processException(var10,
									"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atPostInvoke",
									"261", this);
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "atPostInvoke : transaction has rolledback");
							}
						}
					}

					this.cache.removeElement(sfbean.ivCacheElement, true);
					sfbean.destroy();
					sfbean.ivCacheKey = null;
					this.reaper.remove(id);
				}

				sfbean.unlock(lock);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atPostInvoke");
		}

	}

	void atDiscard(BeanO bean) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atDiscard : " + bean);
		}

		try {
			BeanId beanId = ((StatefulBeanO) bean).getId();
			StatefulBeanO statefulBeanO = (StatefulBeanO) bean;
			bean.ivCacheKey = null;
			if (!statefulBeanO.isTimedOut()) {
				bean.passivate();
			} else {
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "Discarding session bean : " + bean);
				}

				this.reaper.remove(beanId);
				statefulBeanO.destroy();
			}
		} catch (RemoteException var5) {
			FFDCFilter.processException(var5,
					"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atDiscard", "368", this);
			Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{bean, this, var5});
			throw var5;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atDiscard");
		}

	}

	void atRemove(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRemove", new Object[]{tx, bean});
		}

		StatefulBeanO sfbean = (StatefulBeanO) bean;
		Object var4 = sfbean.ivCacheLock;
		synchronized (sfbean.ivCacheLock) {
			this.cache.removeElement(sfbean.ivCacheElement, true);
			bean.ivCacheKey = null;
		}

		this.reaper.remove(bean.getId());
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRemove");
		}

	}

	void atTimeout(BeanId beanId) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atTimeout " + beanId);
		}

		BeanO bean = null;
		Throwable exception = null;
		MasterKey key = new MasterKey(beanId);

		try {
			synchronized (this.locks.getLock(key)) {
				BeanMetaData bmd;
				SfFailoverClient failover;
				if ((bean = (BeanO) this.cache.findDontPinNAdjustPinCount(key, 0)) == null) {
					TimeoutElement elt = this.reaper.getTimeoutElement(beanId);
					if (this.reaper.beanExistsAndTimedOut(elt, beanId)) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Bean not in cache: removing file");
						}

						this.ivPassivator.remove(beanId, true);
						this.reaper.remove(beanId);
						bmd = beanId.getBeanMetaData();
						failover = bmd.getSfFailoverClient();
						if (failover != null) {
							failover.removeEntry(beanId);
						}
					} else if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Bean not in cache: already removed");
					}
				} else {
					StatefulBeanO sfbean = (StatefulBeanO) bean;
					if (sfbean.isTimedOut()) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Found bean in cache: passivating / removing");
						}

						try {
							bean = (BeanO) this.cache.remove(key, false);
							bean.ivCacheKey = null;
							this.reaper.remove(beanId);
							bmd = beanId.getBeanMetaData();
							failover = bmd.getSfFailoverClient();
							if (failover != null) {
								failover.removeEntry(beanId);
							}

							((StatefulBeanO) bean).uninstall();
						} catch (IllegalOperationException var17) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "Found bean in cache: active");
							}
						}
					} else if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Found bean in cache: no longer timed out");
					}
				}
			}
		} catch (RemoteException var19) {
			FFDCFilter.processException(var19,
					"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atTimeout", "474", this);
			exception = var19;
			throw var19;
		} catch (RuntimeException var20) {
			FFDCFilter.processException(var20,
					"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atTimeout", "480", this);
			exception = var20;
			throw var20;
		} finally {
			if (exception != null && isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "atTimeout: exception raised", exception);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atTimeout");
			}

		}

	}

	public void atPassivate(BeanId beanId) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atPassivate " + beanId);
		}

		BeanO bean = null;
		MasterKey key = new MasterKey(beanId);

		try {
			synchronized (this.locks.getLock(key)) {
				if ((bean = (BeanO) this.cache.findDontPinNAdjustPinCount(key, 0)) != null) {
					bean.passivate();
					this.cache.remove(key, false);
					bean.ivCacheKey = null;
					if (EJSPlatformHelper.isZOS() || this.passivationPolicy.equals(PassivationPolicy.ON_DEMAND)) {
						this.reaper.remove(beanId);
					}
				}
			}
		} catch (RemoteException var8) {
			FFDCFilter.processException(var8,
					"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atPassivate", "525", this);
			Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{bean, this, var8});
			throw var8;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atPassivate");
		}

	}

	BeanO atGet(ContainerTx tx, BeanId id) {
		throw new IllegalStateException();
	}

	void atUninstall(BeanId beanId, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atUninstall (" + beanId + ")");
		}

		MasterKey key = new MasterKey(beanId);
		synchronized (this.locks.getLock(key)) {
			if ((bean = (BeanO) this.cache.find(key)) == null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Bean not in cache: removing file");
				}

				try {
					if (this.reaper.remove(beanId)) {
						this.ivPassivator.remove(beanId, false);
					}
				} catch (RemoteException var8) {
					FFDCFilter.processException(var8,
							"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atUninstall", "598",
							this);
					Tr.warning(tc, "REMOVE_FROM_PASSIVATION_STORE_FAILED_CNTR0016W", new Object[]{beanId, var8});
				}
			} else {
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "Found bean in cache: uninstalling");
				}

				try {
					this.cache.remove(key, true);
					bean.ivCacheKey = null;
					this.reaper.remove(beanId);
					((StatefulBeanO) bean).uninstall();
				} catch (IllegalOperationException var9) {
					FFDCFilter.processException(var9,
							"com.ibm.ejs.container.activator.StatefulSessionActivationStrategy.atUninstall", "590",
							this);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Found bean in cache: active!");
					}

					this.cache.unpin(key);
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atUninstall");
		}

	}

	public StatefulBeanReaper getReaper() {
		return this.reaper;
	}
}