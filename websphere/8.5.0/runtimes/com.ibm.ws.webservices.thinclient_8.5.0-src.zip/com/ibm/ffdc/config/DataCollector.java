package com.ibm.ffdc.config;

import java.util.Collection;

public interface DataCollector {
	Collection<? extends Object> collect(Throwable var1);

	String[] getSupportedTypeNames();
}