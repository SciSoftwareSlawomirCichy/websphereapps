package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.DenseImmutableTable.1;
import com.google.common.collect.DenseImmutableTable.ColumnMap;
import com.google.common.collect.DenseImmutableTable.RowMap;
import com.google.common.collect.ImmutableTable.SerializedForm;
import com.google.common.collect.Table.Cell;
import com.google.errorprone.annotations.Immutable;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Immutable(containerOf = {"R", "C", "V"})
@GwtCompatible
final class DenseImmutableTable<R, C, V> extends RegularImmutableTable<R, C, V> {
	private final ImmutableMap<R, Integer> rowKeyToIndex;
	private final ImmutableMap<C, Integer> columnKeyToIndex;
	private final ImmutableMap<R, ImmutableMap<C, V>> rowMap;
	private final ImmutableMap<C, ImmutableMap<R, V>> columnMap;
	private final int[] rowCounts;
	private final int[] columnCounts;
	private final V[][] values;
	private final int[] cellRowIndices;
	private final int[] cellColumnIndices;

	DenseImmutableTable(ImmutableList<Cell<R, C, V>> cellList, ImmutableSet<R> rowSpace, ImmutableSet<C> columnSpace) {
      V[][] array = (Object[][])(new Object[rowSpace.size()][columnSpace.size()]);
      this.values = array;
      this.rowKeyToIndex = Maps.indexMap(rowSpace);
      this.columnKeyToIndex = Maps.indexMap(columnSpace);
      this.rowCounts = new int[this.rowKeyToIndex.size()];
      this.columnCounts = new int[this.columnKeyToIndex.size()];
      int[] cellRowIndices = new int[cellList.size()];
      int[] cellColumnIndices = new int[cellList.size()];

      for(int i = 0; i < cellList.size(); ++i) {
         Cell<R, C, V> cell = (Cell)cellList.get(i);
         R rowKey = cell.getRowKey();
         C columnKey = cell.getColumnKey();
         int rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
         int columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
         V existingValue = this.values[rowIndex][columnIndex];
         Preconditions.checkArgument(existingValue == null, "duplicate key: (%s, %s)", rowKey, columnKey);
         this.values[rowIndex][columnIndex] = cell.getValue();
         ++this.rowCounts[rowIndex];
         ++this.columnCounts[columnIndex];
         cellRowIndices[i] = rowIndex;
         cellColumnIndices[i] = columnIndex;
      }

      this.cellRowIndices = cellRowIndices;
      this.cellColumnIndices = cellColumnIndices;
      this.rowMap = new RowMap(this, (1)null);
      this.columnMap = new ColumnMap(this, (1)null);
   }

	public ImmutableMap<C, Map<R, V>> columnMap() {
		ImmutableMap<C, ImmutableMap<R, V>> columnMap = this.columnMap;
		return ImmutableMap.copyOf(columnMap);
	}

	public ImmutableMap<R, Map<C, V>> rowMap() {
		ImmutableMap<R, ImmutableMap<C, V>> rowMap = this.rowMap;
		return ImmutableMap.copyOf(rowMap);
	}

	public V get(@NullableDecl Object rowKey, @NullableDecl Object columnKey) {
		Integer rowIndex = (Integer) this.rowKeyToIndex.get(rowKey);
		Integer columnIndex = (Integer) this.columnKeyToIndex.get(columnKey);
		return rowIndex != null && columnIndex != null ? this.values[rowIndex][columnIndex] : null;
	}

	public int size() {
		return this.cellRowIndices.length;
	}

	Cell<R, C, V> getCell(int index) {
		int rowIndex = this.cellRowIndices[index];
		int columnIndex = this.cellColumnIndices[index];
		R rowKey = this.rowKeySet().asList().get(rowIndex);
		C columnKey = this.columnKeySet().asList().get(columnIndex);
		V value = this.values[rowIndex][columnIndex];
		return cellOf(rowKey, columnKey, value);
	}

	V getValue(int index) {
		return this.values[this.cellRowIndices[index]][this.cellColumnIndices[index]];
	}

	SerializedForm createSerializedForm() {
		return SerializedForm.create(this, this.cellRowIndices, this.cellColumnIndices);
	}
}