package com.google.common.hash;

import com.google.common.base.Supplier;
import com.google.common.hash.LongAddables.1;
import com.google.common.hash.LongAddables.2;

final class LongAddables {
	private static final Supplier<LongAddable> SUPPLIER;

	public static LongAddable create() {
		return (LongAddable) SUPPLIER.get();
	}

	static {
      Object supplier;
      try {
         new LongAdder();
         supplier = new 1();
      } catch (Throwable var2) {
         supplier = new 2();
      }

      SUPPLIER = (Supplier)supplier;
   }
}