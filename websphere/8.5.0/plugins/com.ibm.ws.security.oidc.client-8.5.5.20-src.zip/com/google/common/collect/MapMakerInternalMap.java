package com.google.common.collect;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Equivalence;
import com.google.common.base.Preconditions;
import com.google.common.collect.MapMaker.Dummy;
import com.google.common.primitives.Ints;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.concurrent.GuardedBy;
import com.google.j2objc.annotations.Weak;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.AbstractCollection;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.locks.ReentrantLock;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtIncompatible
class MapMakerInternalMap<K, V, E extends InternalEntry<K, V, E>, S extends Segment<K, V, E, S>>
		extends
			AbstractMap<K, V>
		implements
			ConcurrentMap<K, V>,
			Serializable {
	static final int MAXIMUM_CAPACITY = 1073741824;
	static final int MAX_SEGMENTS = 65536;
	static final int CONTAINS_VALUE_RETRIES = 3;
	static final int DRAIN_THRESHOLD = 63;
	static final int DRAIN_MAX = 16;
	static final long CLEANUP_EXECUTOR_DELAY_SECS = 60L;
	final transient int segmentMask;
	final transient int segmentShift;
	final transient Segment<K, V, E, S>[] segments;
	final int concurrencyLevel;
	final Equivalence<Object> keyEquivalence;
	final transient InternalEntryHelper<K, V, E, S> entryHelper;
	static final WeakValueReference<Object, Object, DummyInternalEntry> UNSET_WEAK_VALUE_REFERENCE = new WeakValueReference<Object, Object, DummyInternalEntry>() {
		public DummyInternalEntry getEntry() {
			return null;
		}

		public void clear() {
		}

		public Object get() {
			return null;
		}

		public WeakValueReference<Object, Object, DummyInternalEntry> copyFor(ReferenceQueue<Object> queue,
				DummyInternalEntry entry) {
			return this;
		}
	};
	@MonotonicNonNullDecl
	transient Set<K> keySet;
	@MonotonicNonNullDecl
	transient Collection<V> values;
	@MonotonicNonNullDecl
	transient Set<Map.Entry<K, V>> entrySet;
	private static final long serialVersionUID = 5L;

	private MapMakerInternalMap(MapMaker builder, InternalEntryHelper<K, V, E, S> entryHelper) {
		this.concurrencyLevel = Math.min(builder.getConcurrencyLevel(), 65536);
		this.keyEquivalence = builder.getKeyEquivalence();
		this.entryHelper = entryHelper;
		int initialCapacity = Math.min(builder.getInitialCapacity(), 1073741824);
		int segmentShift = 0;

		int segmentCount;
		for (segmentCount = 1; segmentCount < this.concurrencyLevel; segmentCount <<= 1) {
			++segmentShift;
		}

		this.segmentShift = 32 - segmentShift;
		this.segmentMask = segmentCount - 1;
		this.segments = this.newSegmentArray(segmentCount);
		int segmentCapacity = initialCapacity / segmentCount;
		if (segmentCapacity * segmentCount < initialCapacity) {
			++segmentCapacity;
		}

		int segmentSize;
		for (segmentSize = 1; segmentSize < segmentCapacity; segmentSize <<= 1) {
		}

		for (int i = 0; i < this.segments.length; ++i) {
			this.segments[i] = this.createSegment(segmentSize, -1);
		}

	}

	static <K, V> MapMakerInternalMap<K, V, ? extends InternalEntry<K, V, ?>, ?> create(MapMaker builder) {
		if (builder.getKeyStrength() == MapMakerInternalMap.Strength.STRONG
				&& builder.getValueStrength() == MapMakerInternalMap.Strength.STRONG) {
			return new MapMakerInternalMap(builder, MapMakerInternalMap.StrongKeyStrongValueEntry.Helper.instance());
		} else if (builder.getKeyStrength() == MapMakerInternalMap.Strength.STRONG
				&& builder.getValueStrength() == MapMakerInternalMap.Strength.WEAK) {
			return new MapMakerInternalMap(builder, MapMakerInternalMap.StrongKeyWeakValueEntry.Helper.instance());
		} else if (builder.getKeyStrength() == MapMakerInternalMap.Strength.WEAK
				&& builder.getValueStrength() == MapMakerInternalMap.Strength.STRONG) {
			return new MapMakerInternalMap(builder, MapMakerInternalMap.WeakKeyStrongValueEntry.Helper.instance());
		} else if (builder.getKeyStrength() == MapMakerInternalMap.Strength.WEAK
				&& builder.getValueStrength() == MapMakerInternalMap.Strength.WEAK) {
			return new MapMakerInternalMap(builder, MapMakerInternalMap.WeakKeyWeakValueEntry.Helper.instance());
		} else {
			throw new AssertionError();
		}
	}

	static <K> MapMakerInternalMap<K, MapMaker.Dummy, ? extends InternalEntry<K, MapMaker.Dummy, ?>, ?> createWithDummyValues(
			MapMaker builder) {
		if (builder.getKeyStrength() == MapMakerInternalMap.Strength.STRONG
				&& builder.getValueStrength() == MapMakerInternalMap.Strength.STRONG) {
			return new MapMakerInternalMap(builder, MapMakerInternalMap.StrongKeyDummyValueEntry.Helper.instance());
		} else if (builder.getKeyStrength() == MapMakerInternalMap.Strength.WEAK
				&& builder.getValueStrength() == MapMakerInternalMap.Strength.STRONG) {
			return new MapMakerInternalMap(builder, MapMakerInternalMap.WeakKeyDummyValueEntry.Helper.instance());
		} else if (builder.getValueStrength() == MapMakerInternalMap.Strength.WEAK) {
			throw new IllegalArgumentException("Map cannot have both weak and dummy values");
		} else {
			throw new AssertionError();
		}
	}

	static <K, V, E extends InternalEntry<K, V, E>> WeakValueReference<K, V, E> unsetWeakValueReference() {
		return UNSET_WEAK_VALUE_REFERENCE;
	}

	static int rehash(int h) {
		h += h << 15 ^ -12931;
		h ^= h >>> 10;
		h += h << 3;
		h ^= h >>> 6;
		h += (h << 2) + (h << 14);
		return h ^ h >>> 16;
	}

	@VisibleForTesting
	E copyEntry(E original, E newNext) {
		int hash = original.getHash();
		return this.segmentFor(hash).copyEntry(original, newNext);
	}

	int hash(Object key) {
		int h = this.keyEquivalence.hash(key);
		return rehash(h);
	}

	void reclaimValue(WeakValueReference<K, V, E> valueReference) {
		E entry = valueReference.getEntry();
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimValue(entry.getKey(), hash, valueReference);
	}

	void reclaimKey(E entry) {
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimKey(entry, hash);
	}

	@VisibleForTesting
	boolean isLiveForTesting(InternalEntry<K, V, ?> entry) {
		return this.segmentFor(entry.getHash()).getLiveValueForTesting(entry) != null;
	}

	Segment<K, V, E, S> segmentFor(int hash) {
		return this.segments[hash >>> this.segmentShift & this.segmentMask];
	}

	Segment<K, V, E, S> createSegment(int initialCapacity, int maxSegmentSize) {
		return this.entryHelper.newSegment(this, initialCapacity, maxSegmentSize);
	}

	V getLiveValue(E entry) {
		if (entry.getKey() == null) {
			return null;
		} else {
			V value = entry.getValue();
			return value == null ? null : value;
		}
	}

	final Segment<K, V, E, S>[] newSegmentArray(int ssize) {
		return new Segment[ssize];
	}

	@VisibleForTesting
	Strength keyStrength() {
		return this.entryHelper.keyStrength();
	}

	@VisibleForTesting
	Strength valueStrength() {
		return this.entryHelper.valueStrength();
	}

	@VisibleForTesting
	Equivalence<Object> valueEquivalence() {
		return this.entryHelper.valueStrength().defaultEquivalence();
	}

	public boolean isEmpty() {
		long sum = 0L;
		Segment<K, V, E, S>[] segments = this.segments;

		int i;
		for (i = 0; i < segments.length; ++i) {
			if (segments[i].count != 0) {
				return false;
			}

			sum += (long) segments[i].modCount;
		}

		if (sum != 0L) {
			for (i = 0; i < segments.length; ++i) {
				if (segments[i].count != 0) {
					return false;
				}

				sum -= (long) segments[i].modCount;
			}

			if (sum != 0L) {
				return false;
			}
		}

		return true;
	}

	public int size() {
		Segment<K, V, E, S>[] segments = this.segments;
		long sum = 0L;

		for (int i = 0; i < segments.length; ++i) {
			sum += (long) segments[i].count;
		}

		return Ints.saturatedCast(sum);
	}

	public V get(@NullableDecl Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).get(key, hash);
		}
	}

	E getEntry(@NullableDecl Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).getEntry(key, hash);
		}
	}

	public boolean containsKey(@NullableDecl Object key) {
		if (key == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).containsKey(key, hash);
		}
	}

	public boolean containsValue(@NullableDecl Object value) {
		if (value == null) {
			return false;
		} else {
			Segment<K, V, E, S>[] segments = this.segments;
			long last = -1L;

			for (int i = 0; i < 3; ++i) {
				long sum = 0L;
				Segment[] var8 = segments;
				int var9 = segments.length;

				for (int var10 = 0; var10 < var9; ++var10) {
					Segment<K, V, E, S> segment = var8[var10];
					int unused = segment.count;
					AtomicReferenceArray<E> table = segment.table;

					for (int j = 0; j < table.length(); ++j) {
						for (E e = (InternalEntry) table.get(j); e != null; e = e.getNext()) {
							V v = segment.getLiveValue(e);
							if (v != null && this.valueEquivalence().equivalent(value, v)) {
								return true;
							}
						}
					}

					sum += (long) segment.modCount;
				}

				if (sum == last) {
					break;
				}

				last = sum;
			}

			return false;
		}
	}

	@CanIgnoreReturnValue
	public V put(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, false);
	}

	@CanIgnoreReturnValue
	public V putIfAbsent(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, true);
	}

	public void putAll(Map<? extends K, ? extends V> m) {
		Iterator var2 = m.entrySet().iterator();

		while (var2.hasNext()) {
			Map.Entry<? extends K, ? extends V> e = (Map.Entry) var2.next();
			this.put(e.getKey(), e.getValue());
		}

	}

	@CanIgnoreReturnValue
	public V remove(@NullableDecl Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash);
		}
	}

	@CanIgnoreReturnValue
	public boolean remove(@NullableDecl Object key, @NullableDecl Object value) {
		if (key != null && value != null) {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash, value);
		} else {
			return false;
		}
	}

	@CanIgnoreReturnValue
	public boolean replace(K key, @NullableDecl V oldValue, V newValue) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(newValue);
		if (oldValue == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).replace(key, hash, oldValue, newValue);
		}
	}

	@CanIgnoreReturnValue
	public V replace(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).replace(key, hash, value);
	}

	public void clear() {
		Segment[] var1 = this.segments;
		int var2 = var1.length;

		for (int var3 = 0; var3 < var2; ++var3) {
			Segment<K, V, E, S> segment = var1[var3];
			segment.clear();
		}

	}

	public Set<K> keySet() {
		Set<K> ks = this.keySet;
		return ks != null ? ks : (this.keySet = new KeySet());
	}

	public Collection<V> values() {
		Collection<V> vs = this.values;
		return vs != null ? vs : (this.values = new Values());
	}

	public Set<Map.Entry<K, V>> entrySet() {
		Set<Map.Entry<K, V>> es = this.entrySet;
		return es != null ? es : (this.entrySet = new EntrySet());
	}

	private static <E> ArrayList<E> toArrayList(Collection<E> c) {
		ArrayList<E> result = new ArrayList(c.size());
		Iterators.addAll(result, c.iterator());
		return result;
	}

	Object writeReplace() {
		return new SerializationProxy(this.entryHelper.keyStrength(), this.entryHelper.valueStrength(),
				this.keyEquivalence, this.entryHelper.valueStrength().defaultEquivalence(), this.concurrencyLevel,
				this);
	}

	private static final class SerializationProxy<K, V> extends AbstractSerializationProxy<K, V> {
		private static final long serialVersionUID = 3L;

		SerializationProxy(Strength keyStrength, Strength valueStrength, Equivalence<Object> keyEquivalence,
				Equivalence<Object> valueEquivalence, int concurrencyLevel, ConcurrentMap<K, V> delegate) {
			super(keyStrength, valueStrength, keyEquivalence, valueEquivalence, concurrencyLevel, delegate);
		}

		private void writeObject(ObjectOutputStream out) throws IOException {
			out.defaultWriteObject();
			this.writeMapTo(out);
		}

		private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
			in.defaultReadObject();
			MapMaker mapMaker = this.readMapMaker(in);
			this.delegate = mapMaker.makeMap();
			this.readEntries(in);
		}

		private Object readResolve() {
			return this.delegate;
		}
	}

	abstract static class AbstractSerializationProxy<K, V> extends ForwardingConcurrentMap<K, V>
			implements
				Serializable {
		private static final long serialVersionUID = 3L;
		final Strength keyStrength;
		final Strength valueStrength;
		final Equivalence<Object> keyEquivalence;
		final Equivalence<Object> valueEquivalence;
		final int concurrencyLevel;
		transient ConcurrentMap<K, V> delegate;

		AbstractSerializationProxy(Strength keyStrength, Strength valueStrength, Equivalence<Object> keyEquivalence,
				Equivalence<Object> valueEquivalence, int concurrencyLevel, ConcurrentMap<K, V> delegate) {
			this.keyStrength = keyStrength;
			this.valueStrength = valueStrength;
			this.keyEquivalence = keyEquivalence;
			this.valueEquivalence = valueEquivalence;
			this.concurrencyLevel = concurrencyLevel;
			this.delegate = delegate;
		}

		protected ConcurrentMap<K, V> delegate() {
			return this.delegate;
		}

		void writeMapTo(ObjectOutputStream out) throws IOException {
			out.writeInt(this.delegate.size());
			Iterator var2 = this.delegate.entrySet().iterator();

			while (var2.hasNext()) {
				Map.Entry<K, V> entry = (Map.Entry) var2.next();
				out.writeObject(entry.getKey());
				out.writeObject(entry.getValue());
			}

			out.writeObject((Object) null);
		}

		MapMaker readMapMaker(ObjectInputStream in) throws IOException {
			int size = in.readInt();
			return (new MapMaker()).initialCapacity(size).setKeyStrength(this.keyStrength)
					.setValueStrength(this.valueStrength).keyEquivalence(this.keyEquivalence)
					.concurrencyLevel(this.concurrencyLevel);
		}

		void readEntries(ObjectInputStream in) throws IOException, ClassNotFoundException {
			while (true) {
				K key = in.readObject();
				if (key == null) {
					return;
				}

				V value = in.readObject();
				this.delegate.put(key, value);
			}
		}
	}

	private abstract static class SafeToArraySet<E> extends AbstractSet<E> {
		private SafeToArraySet() {
		}

		public Object[] toArray() {
			return MapMakerInternalMap.toArrayList(this).toArray();
		}

		public <T> T[] toArray(T[] a) {
			return MapMakerInternalMap.toArrayList(this).toArray(a);
		}
	}

	final class EntrySet extends SafeToArraySet<Map.Entry<K, V>> {
		EntrySet() {
			super(null);
		}

		public Iterator<Map.Entry<K, V>> iterator() {
			return MapMakerInternalMap.this.new EntryIterator();
		}

		public boolean contains(Object o) {
			if (!(o instanceof Map.Entry)) {
				return false;
			} else {
				Map.Entry<?, ?> e = (Map.Entry) o;
				Object key = e.getKey();
				if (key == null) {
					return false;
				} else {
					V v = MapMakerInternalMap.this.get(key);
					return v != null && MapMakerInternalMap.this.valueEquivalence().equivalent(e.getValue(), v);
				}
			}
		}

		public boolean remove(Object o) {
			if (!(o instanceof Map.Entry)) {
				return false;
			} else {
				Map.Entry<?, ?> e = (Map.Entry) o;
				Object key = e.getKey();
				return key != null && MapMakerInternalMap.this.remove(key, e.getValue());
			}
		}

		public int size() {
			return MapMakerInternalMap.this.size();
		}

		public boolean isEmpty() {
			return MapMakerInternalMap.this.isEmpty();
		}

		public void clear() {
			MapMakerInternalMap.this.clear();
		}
	}

	final class Values extends AbstractCollection<V> {
		public Iterator<V> iterator() {
			return MapMakerInternalMap.this.new ValueIterator();
		}

		public int size() {
			return MapMakerInternalMap.this.size();
		}

		public boolean isEmpty() {
			return MapMakerInternalMap.this.isEmpty();
		}

		public boolean contains(Object o) {
			return MapMakerInternalMap.this.containsValue(o);
		}

		public void clear() {
			MapMakerInternalMap.this.clear();
		}

		public Object[] toArray() {
			return MapMakerInternalMap.toArrayList(this).toArray();
		}

		public <T> T[] toArray(T[] a) {
			return MapMakerInternalMap.toArrayList(this).toArray(a);
		}
	}

	final class KeySet extends SafeToArraySet<K> {
		KeySet() {
			super(null);
		}

		public Iterator<K> iterator() {
			return MapMakerInternalMap.this.new KeyIterator();
		}

		public int size() {
			return MapMakerInternalMap.this.size();
		}

		public boolean isEmpty() {
			return MapMakerInternalMap.this.isEmpty();
		}

		public boolean contains(Object o) {
			return MapMakerInternalMap.this.containsKey(o);
		}

		public boolean remove(Object o) {
			return MapMakerInternalMap.this.remove(o) != null;
		}

		public void clear() {
			MapMakerInternalMap.this.clear();
		}
	}

	final class EntryIterator extends MapMakerInternalMap<K, V, E, S>.HashIterator<Map.Entry<K, V>> {
		EntryIterator() {
			super();
		}

		public Map.Entry<K, V> next() {
			return this.nextEntry();
		}
	}

	final class WriteThroughEntry extends AbstractMapEntry<K, V> {
		final K key;
		V value;

		WriteThroughEntry(K key, V value) {
			this.key = key;
			this.value = value;
		}

		public K getKey() {
			return this.key;
		}

		public V getValue() {
			return this.value;
		}

		public boolean equals(@NullableDecl Object object) {
			if (!(object instanceof Map.Entry)) {
				return false;
			} else {
				Map.Entry<?, ?> that = (Map.Entry) object;
				return this.key.equals(that.getKey()) && this.value.equals(that.getValue());
			}
		}

		public int hashCode() {
			return this.key.hashCode() ^ this.value.hashCode();
		}

		public V setValue(V newValue) {
			V oldValue = MapMakerInternalMap.this.put(this.key, newValue);
			this.value = newValue;
			return oldValue;
		}
	}

	final class ValueIterator extends MapMakerInternalMap<K, V, E, S>.HashIterator<V> {
		ValueIterator() {
			super();
		}

		public V next() {
			return this.nextEntry().getValue();
		}
	}

	final class KeyIterator extends MapMakerInternalMap<K, V, E, S>.HashIterator<K> {
		KeyIterator() {
			super();
		}

		public K next() {
			return this.nextEntry().getKey();
		}
	}

	abstract class HashIterator<T> implements Iterator<T> {
		int nextSegmentIndex;
		int nextTableIndex;
		@MonotonicNonNullDecl
		Segment<K, V, E, S> currentSegment;
		@MonotonicNonNullDecl
		AtomicReferenceArray<E> currentTable;
		@NullableDecl
		E nextEntry;
		@NullableDecl
		MapMakerInternalMap<K, V, E, S>.WriteThroughEntry nextExternal;
		@NullableDecl
		MapMakerInternalMap<K, V, E, S>.WriteThroughEntry lastReturned;

		HashIterator() {
			this.nextSegmentIndex = MapMakerInternalMap.this.segments.length - 1;
			this.nextTableIndex = -1;
			this.advance();
		}

		public abstract T next();

		final void advance() {
			this.nextExternal = null;
			if (!this.nextInChain()) {
				if (!this.nextInTable()) {
					while (this.nextSegmentIndex >= 0) {
						this.currentSegment = MapMakerInternalMap.this.segments[this.nextSegmentIndex--];
						if (this.currentSegment.count != 0) {
							this.currentTable = this.currentSegment.table;
							this.nextTableIndex = this.currentTable.length() - 1;
							if (this.nextInTable()) {
								return;
							}
						}
					}

				}
			}
		}

		boolean nextInChain() {
			if (this.nextEntry != null) {
				for (this.nextEntry = this.nextEntry.getNext(); this.nextEntry != null; this.nextEntry = this.nextEntry
						.getNext()) {
					if (this.advanceTo(this.nextEntry)) {
						return true;
					}
				}
			}

			return false;
		}

		boolean nextInTable() {
			while (true) {
				if (this.nextTableIndex >= 0) {
					if ((this.nextEntry = (InternalEntry) this.currentTable.get(this.nextTableIndex--)) == null
							|| !this.advanceTo(this.nextEntry) && !this.nextInChain()) {
						continue;
					}

					return true;
				}

				return false;
			}
		}

		boolean advanceTo(E entry) {
			boolean var4;
			try {
				K key = entry.getKey();
				V value = MapMakerInternalMap.this.getLiveValue(entry);
				if (value != null) {
					this.nextExternal = MapMakerInternalMap.this.new WriteThroughEntry(key, value);
					var4 = true;
					return var4;
				}

				var4 = false;
			} finally {
				this.currentSegment.postReadCleanup();
			}

			return var4;
		}

		public boolean hasNext() {
			return this.nextExternal != null;
		}

		MapMakerInternalMap<K, V, E, S>.WriteThroughEntry nextEntry() {
			if (this.nextExternal == null) {
				throw new NoSuchElementException();
			} else {
				this.lastReturned = this.nextExternal;
				this.advance();
				return this.lastReturned;
			}
		}

		public void remove() {
			CollectPreconditions.checkRemove(this.lastReturned != null);
			MapMakerInternalMap.this.remove(this.lastReturned.getKey());
			this.lastReturned = null;
		}
	}

	static final class CleanupMapTask implements Runnable {
		final WeakReference<MapMakerInternalMap<?, ?, ?, ?>> mapReference;

		public CleanupMapTask(MapMakerInternalMap<?, ?, ?, ?> map) {
			this.mapReference = new WeakReference(map);
		}

		public void run() {
			MapMakerInternalMap<?, ?, ?, ?> map = (MapMakerInternalMap) this.mapReference.get();
			if (map == null) {
				throw new CancellationException();
			} else {
				Segment[] var2 = map.segments;
				int var3 = var2.length;

				for (int var4 = 0; var4 < var3; ++var4) {
					Segment<?, ?, ?, ?> segment = var2[var4];
					segment.runCleanup();
				}

			}
		}
	}

	static final class WeakKeyDummyValueSegment<K>
			extends
				Segment<K, MapMaker.Dummy, WeakKeyDummyValueEntry<K>, WeakKeyDummyValueSegment<K>> {
		private final ReferenceQueue<K> queueForKeys = new ReferenceQueue();

		WeakKeyDummyValueSegment(
				MapMakerInternalMap<K, MapMaker.Dummy, WeakKeyDummyValueEntry<K>, WeakKeyDummyValueSegment<K>> map,
				int initialCapacity, int maxSegmentSize) {
			super(map, initialCapacity, maxSegmentSize);
		}

		WeakKeyDummyValueSegment<K> self() {
			return this;
		}

		ReferenceQueue<K> getKeyReferenceQueueForTesting() {
			return this.queueForKeys;
		}

		public WeakKeyDummyValueEntry<K> castForTesting(InternalEntry<K, MapMaker.Dummy, ?> entry) {
			return (WeakKeyDummyValueEntry) entry;
		}

		void maybeDrainReferenceQueues() {
			this.drainKeyReferenceQueue(this.queueForKeys);
		}

		void maybeClearReferenceQueues() {
			this.clearReferenceQueue(this.queueForKeys);
		}
	}

	static final class WeakKeyWeakValueSegment<K, V>
			extends
				Segment<K, V, WeakKeyWeakValueEntry<K, V>, WeakKeyWeakValueSegment<K, V>> {
		private final ReferenceQueue<K> queueForKeys = new ReferenceQueue();
		private final ReferenceQueue<V> queueForValues = new ReferenceQueue();

		WeakKeyWeakValueSegment(
				MapMakerInternalMap<K, V, WeakKeyWeakValueEntry<K, V>, WeakKeyWeakValueSegment<K, V>> map,
				int initialCapacity, int maxSegmentSize) {
			super(map, initialCapacity, maxSegmentSize);
		}

		WeakKeyWeakValueSegment<K, V> self() {
			return this;
		}

		ReferenceQueue<K> getKeyReferenceQueueForTesting() {
			return this.queueForKeys;
		}

		ReferenceQueue<V> getValueReferenceQueueForTesting() {
			return this.queueForValues;
		}

		public WeakKeyWeakValueEntry<K, V> castForTesting(InternalEntry<K, V, ?> entry) {
			return (WeakKeyWeakValueEntry) entry;
		}

		public WeakValueReference<K, V, WeakKeyWeakValueEntry<K, V>> getWeakValueReferenceForTesting(
				InternalEntry<K, V, ?> e) {
			return this.castForTesting(e).getValueReference();
		}

		public WeakValueReference<K, V, WeakKeyWeakValueEntry<K, V>> newWeakValueReferenceForTesting(
				InternalEntry<K, V, ?> e, V value) {
			return new WeakValueReferenceImpl(this.queueForValues, value, this.castForTesting(e));
		}

		public void setWeakValueReferenceForTesting(InternalEntry<K, V, ?> e,
				WeakValueReference<K, V, ? extends InternalEntry<K, V, ?>> valueReference) {
			WeakKeyWeakValueEntry<K, V> entry = this.castForTesting(e);
			WeakValueReference<K, V, WeakKeyWeakValueEntry<K, V>> previous = entry.valueReference;
			entry.valueReference = valueReference;
			previous.clear();
		}

		void maybeDrainReferenceQueues() {
			this.drainKeyReferenceQueue(this.queueForKeys);
			this.drainValueReferenceQueue(this.queueForValues);
		}

		void maybeClearReferenceQueues() {
			this.clearReferenceQueue(this.queueForKeys);
		}
	}

	static final class WeakKeyStrongValueSegment<K, V>
			extends
				Segment<K, V, WeakKeyStrongValueEntry<K, V>, WeakKeyStrongValueSegment<K, V>> {
		private final ReferenceQueue<K> queueForKeys = new ReferenceQueue();

		WeakKeyStrongValueSegment(
				MapMakerInternalMap<K, V, WeakKeyStrongValueEntry<K, V>, WeakKeyStrongValueSegment<K, V>> map,
				int initialCapacity, int maxSegmentSize) {
			super(map, initialCapacity, maxSegmentSize);
		}

		WeakKeyStrongValueSegment<K, V> self() {
			return this;
		}

		ReferenceQueue<K> getKeyReferenceQueueForTesting() {
			return this.queueForKeys;
		}

		public WeakKeyStrongValueEntry<K, V> castForTesting(InternalEntry<K, V, ?> entry) {
			return (WeakKeyStrongValueEntry) entry;
		}

		void maybeDrainReferenceQueues() {
			this.drainKeyReferenceQueue(this.queueForKeys);
		}

		void maybeClearReferenceQueues() {
			this.clearReferenceQueue(this.queueForKeys);
		}
	}

	static final class StrongKeyDummyValueSegment<K>
			extends
				Segment<K, MapMaker.Dummy, StrongKeyDummyValueEntry<K>, StrongKeyDummyValueSegment<K>> {
		StrongKeyDummyValueSegment(
				MapMakerInternalMap<K, MapMaker.Dummy, StrongKeyDummyValueEntry<K>, StrongKeyDummyValueSegment<K>> map,
				int initialCapacity, int maxSegmentSize) {
			super(map, initialCapacity, maxSegmentSize);
		}

		StrongKeyDummyValueSegment<K> self() {
			return this;
		}

		public StrongKeyDummyValueEntry<K> castForTesting(InternalEntry<K, MapMaker.Dummy, ?> entry) {
			return (StrongKeyDummyValueEntry) entry;
		}
	}

	static final class StrongKeyWeakValueSegment<K, V>
			extends
				Segment<K, V, StrongKeyWeakValueEntry<K, V>, StrongKeyWeakValueSegment<K, V>> {
		private final ReferenceQueue<V> queueForValues = new ReferenceQueue();

		StrongKeyWeakValueSegment(
				MapMakerInternalMap<K, V, StrongKeyWeakValueEntry<K, V>, StrongKeyWeakValueSegment<K, V>> map,
				int initialCapacity, int maxSegmentSize) {
			super(map, initialCapacity, maxSegmentSize);
		}

		StrongKeyWeakValueSegment<K, V> self() {
			return this;
		}

		ReferenceQueue<V> getValueReferenceQueueForTesting() {
			return this.queueForValues;
		}

		public StrongKeyWeakValueEntry<K, V> castForTesting(InternalEntry<K, V, ?> entry) {
			return (StrongKeyWeakValueEntry) entry;
		}

		public WeakValueReference<K, V, StrongKeyWeakValueEntry<K, V>> getWeakValueReferenceForTesting(
				InternalEntry<K, V, ?> e) {
			return this.castForTesting(e).getValueReference();
		}

		public WeakValueReference<K, V, StrongKeyWeakValueEntry<K, V>> newWeakValueReferenceForTesting(
				InternalEntry<K, V, ?> e, V value) {
			return new WeakValueReferenceImpl(this.queueForValues, value, this.castForTesting(e));
		}

		public void setWeakValueReferenceForTesting(InternalEntry<K, V, ?> e,
				WeakValueReference<K, V, ? extends InternalEntry<K, V, ?>> valueReference) {
			StrongKeyWeakValueEntry<K, V> entry = this.castForTesting(e);
			WeakValueReference<K, V, StrongKeyWeakValueEntry<K, V>> previous = entry.valueReference;
			entry.valueReference = valueReference;
			previous.clear();
		}

		void maybeDrainReferenceQueues() {
			this.drainValueReferenceQueue(this.queueForValues);
		}

		void maybeClearReferenceQueues() {
			this.clearReferenceQueue(this.queueForValues);
		}
	}

	static final class StrongKeyStrongValueSegment<K, V>
			extends
				Segment<K, V, StrongKeyStrongValueEntry<K, V>, StrongKeyStrongValueSegment<K, V>> {
		StrongKeyStrongValueSegment(
				MapMakerInternalMap<K, V, StrongKeyStrongValueEntry<K, V>, StrongKeyStrongValueSegment<K, V>> map,
				int initialCapacity, int maxSegmentSize) {
			super(map, initialCapacity, maxSegmentSize);
		}

		StrongKeyStrongValueSegment<K, V> self() {
			return this;
		}

		public StrongKeyStrongValueEntry<K, V> castForTesting(InternalEntry<K, V, ?> entry) {
			return (StrongKeyStrongValueEntry) entry;
		}
	}

	abstract static class Segment<K, V, E extends InternalEntry<K, V, E>, S extends Segment<K, V, E, S>>
			extends
				ReentrantLock {
		@Weak
		final MapMakerInternalMap<K, V, E, S> map;
		volatile int count;
		int modCount;
		int threshold;
		@MonotonicNonNullDecl
		volatile AtomicReferenceArray<E> table;
		final int maxSegmentSize;
		final AtomicInteger readCount = new AtomicInteger();

		Segment(MapMakerInternalMap<K, V, E, S> map, int initialCapacity, int maxSegmentSize) {
			this.map = map;
			this.maxSegmentSize = maxSegmentSize;
			this.initTable(this.newEntryArray(initialCapacity));
		}

		abstract S self();

		@GuardedBy("this")
		void maybeDrainReferenceQueues() {
		}

		void maybeClearReferenceQueues() {
		}

		void setValue(E entry, V value) {
			this.map.entryHelper.setValue(this.self(), entry, value);
		}

		E copyEntry(E original, E newNext) {
			return this.map.entryHelper.copy(this.self(), original, newNext);
		}

		AtomicReferenceArray<E> newEntryArray(int size) {
			return new AtomicReferenceArray(size);
		}

		void initTable(AtomicReferenceArray<E> newTable) {
			this.threshold = newTable.length() * 3 / 4;
			if (this.threshold == this.maxSegmentSize) {
				++this.threshold;
			}

			this.table = newTable;
		}

		abstract E castForTesting(InternalEntry<K, V, ?> var1);

		ReferenceQueue<K> getKeyReferenceQueueForTesting() {
			throw new AssertionError();
		}

		ReferenceQueue<V> getValueReferenceQueueForTesting() {
			throw new AssertionError();
		}

		WeakValueReference<K, V, E> getWeakValueReferenceForTesting(InternalEntry<K, V, ?> entry) {
			throw new AssertionError();
		}

		WeakValueReference<K, V, E> newWeakValueReferenceForTesting(InternalEntry<K, V, ?> entry, V value) {
			throw new AssertionError();
		}

		void setWeakValueReferenceForTesting(InternalEntry<K, V, ?> entry,
				WeakValueReference<K, V, ? extends InternalEntry<K, V, ?>> valueReference) {
			throw new AssertionError();
		}

		void setTableEntryForTesting(int i, InternalEntry<K, V, ?> entry) {
			this.table.set(i, this.castForTesting(entry));
		}

		E copyForTesting(InternalEntry<K, V, ?> entry, @NullableDecl InternalEntry<K, V, ?> newNext) {
			return this.map.entryHelper.copy(this.self(), this.castForTesting(entry), this.castForTesting(newNext));
		}

		void setValueForTesting(InternalEntry<K, V, ?> entry, V value) {
			this.map.entryHelper.setValue(this.self(), this.castForTesting(entry), value);
		}

		E newEntryForTesting(K key, int hash, @NullableDecl InternalEntry<K, V, ?> next) {
			return this.map.entryHelper.newEntry(this.self(), key, hash, this.castForTesting(next));
		}

		@CanIgnoreReturnValue
		boolean removeTableEntryForTesting(InternalEntry<K, V, ?> entry) {
			return this.removeEntryForTesting(this.castForTesting(entry));
		}

		E removeFromChainForTesting(InternalEntry<K, V, ?> first, InternalEntry<K, V, ?> entry) {
			return this.removeFromChain(this.castForTesting(first), this.castForTesting(entry));
		}

		@NullableDecl
		V getLiveValueForTesting(InternalEntry<K, V, ?> entry) {
			return this.getLiveValue(this.castForTesting(entry));
		}

		void tryDrainReferenceQueues() {
			if (this.tryLock()) {
				try {
					this.maybeDrainReferenceQueues();
				} finally {
					this.unlock();
				}
			}

		}

		@GuardedBy("this")
		void drainKeyReferenceQueue(ReferenceQueue<K> keyReferenceQueue) {
			int i = 0;

			Reference ref;
			while ((ref = keyReferenceQueue.poll()) != null) {
				E entry = (InternalEntry) ref;
				this.map.reclaimKey(entry);
				++i;
				if (i == 16) {
					break;
				}
			}

		}

		@GuardedBy("this")
		void drainValueReferenceQueue(ReferenceQueue<V> valueReferenceQueue) {
			int i = 0;

			Reference ref;
			while ((ref = valueReferenceQueue.poll()) != null) {
				WeakValueReference<K, V, E> valueReference = (WeakValueReference) ref;
				this.map.reclaimValue(valueReference);
				++i;
				if (i == 16) {
					break;
				}
			}

		}

		<T> void clearReferenceQueue(ReferenceQueue<T> referenceQueue) {
			while (referenceQueue.poll() != null) {
			}

		}

		E getFirst(int hash) {
			AtomicReferenceArray<E> table = this.table;
			return (InternalEntry) table.get(hash & table.length() - 1);
		}

		E getEntry(Object key, int hash) {
			if (this.count != 0) {
				for (E e = this.getFirst(hash); e != null; e = e.getNext()) {
					if (e.getHash() == hash) {
						K entryKey = e.getKey();
						if (entryKey == null) {
							this.tryDrainReferenceQueues();
						} else if (this.map.keyEquivalence.equivalent(key, entryKey)) {
							return e;
						}
					}
				}
			}

			return null;
		}

		E getLiveEntry(Object key, int hash) {
			return this.getEntry(key, hash);
		}

		V get(Object key, int hash) {
			Object var5;
			try {
				E e = this.getLiveEntry(key, hash);
				Object value;
				if (e == null) {
					value = null;
					return value;
				}

				value = e.getValue();
				if (value == null) {
					this.tryDrainReferenceQueues();
				}

				var5 = value;
			} finally {
				this.postReadCleanup();
			}

			return var5;
		}

		boolean containsKey(Object key, int hash) {
			boolean var4;
			try {
				if (this.count == 0) {
					boolean var8 = false;
					return var8;
				}

				E e = this.getLiveEntry(key, hash);
				var4 = e != null && e.getValue() != null;
			} finally {
				this.postReadCleanup();
			}

			return var4;
		}

		@VisibleForTesting
		boolean containsValue(Object value) {
			try {
				if (this.count != 0) {
					AtomicReferenceArray<E> table = this.table;
					int length = table.length();

					for (int i = 0; i < length; ++i) {
						for (E e = (InternalEntry) table.get(i); e != null; e = e.getNext()) {
							V entryValue = this.getLiveValue(e);
							if (entryValue != null && this.map.valueEquivalence().equivalent(value, entryValue)) {
								boolean var7 = true;
								return var7;
							}
						}
					}
				}

				boolean var11 = false;
				return var11;
			} finally {
				this.postReadCleanup();
			}
		}

		V put(K key, int hash, V value, boolean onlyIfAbsent) {
			this.lock();

			try {
				this.preWriteCleanup();
				int newCount = this.count + 1;
				if (newCount > this.threshold) {
					this.expand();
					newCount = this.count + 1;
				}

				AtomicReferenceArray<E> table = this.table;
				int index = hash & table.length() - 1;
				E first = (InternalEntry) table.get(index);

				InternalEntry e;
				Object entryKey;
				for (e = first; e != null; e = e.getNext()) {
					entryKey = e.getKey();
					if (e.getHash() == hash && entryKey != null && this.map.keyEquivalence.equivalent(key, entryKey)) {
						V entryValue = e.getValue();
						Object var12;
						if (entryValue != null) {
							if (onlyIfAbsent) {
								var12 = entryValue;
								return var12;
							}

							++this.modCount;
							this.setValue(e, value);
							var12 = entryValue;
							return var12;
						}

						++this.modCount;
						this.setValue(e, value);
						newCount = this.count;
						this.count = newCount;
						var12 = null;
						return var12;
					}
				}

				++this.modCount;
				e = this.map.entryHelper.newEntry(this.self(), key, hash, first);
				this.setValue(e, value);
				table.set(index, e);
				this.count = newCount;
				entryKey = null;
				return entryKey;
			} finally {
				this.unlock();
			}
		}

		@GuardedBy("this")
		void expand() {
			AtomicReferenceArray<E> oldTable = this.table;
			int oldCapacity = oldTable.length();
			if (oldCapacity < 1073741824) {
				int newCount = this.count;
				AtomicReferenceArray<E> newTable = this.newEntryArray(oldCapacity << 1);
				this.threshold = newTable.length() * 3 / 4;
				int newMask = newTable.length() - 1;

				for (int oldIndex = 0; oldIndex < oldCapacity; ++oldIndex) {
					E head = (InternalEntry) oldTable.get(oldIndex);
					if (head != null) {
						E next = head.getNext();
						int headIndex = head.getHash() & newMask;
						if (next == null) {
							newTable.set(headIndex, head);
						} else {
							E tail = head;
							int tailIndex = headIndex;

							InternalEntry e;
							int newIndex;
							for (e = next; e != null; e = e.getNext()) {
								newIndex = e.getHash() & newMask;
								if (newIndex != tailIndex) {
									tailIndex = newIndex;
									tail = e;
								}
							}

							newTable.set(tailIndex, tail);

							for (e = head; e != tail; e = e.getNext()) {
								newIndex = e.getHash() & newMask;
								E newNext = (InternalEntry) newTable.get(newIndex);
								E newFirst = this.copyEntry(e, newNext);
								if (newFirst != null) {
									newTable.set(newIndex, newFirst);
								} else {
									--newCount;
								}
							}
						}
					}
				}

				this.table = newTable;
				this.count = newCount;
			}
		}

		boolean replace(K key, int hash, V oldValue, V newValue) {
			this.lock();

			try {
				this.preWriteCleanup();
				AtomicReferenceArray<E> table = this.table;
				int index = hash & table.length() - 1;
				E first = (InternalEntry) table.get(index);

				for (E e = first; e != null; e = e.getNext()) {
					K entryKey = e.getKey();
					if (e.getHash() == hash && entryKey != null && this.map.keyEquivalence.equivalent(key, entryKey)) {
						V entryValue = e.getValue();
						boolean var17;
						if (entryValue != null) {
							if (this.map.valueEquivalence().equivalent(oldValue, entryValue)) {
								++this.modCount;
								this.setValue(e, newValue);
								var17 = true;
								return var17;
							}

							var17 = false;
							return var17;
						}

						if (isCollected(e)) {
							int newCount = this.count - 1;
							++this.modCount;
							E newFirst = this.removeFromChain(first, e);
							newCount = this.count - 1;
							table.set(index, newFirst);
							this.count = newCount;
						}

						var17 = false;
						return var17;
					}
				}

				boolean var16 = false;
				return var16;
			} finally {
				this.unlock();
			}
		}

		V replace(K key, int hash, V newValue) {
			this.lock();

			InternalEntry e;
			try {
				this.preWriteCleanup();
				AtomicReferenceArray<E> table = this.table;
				int index = hash & table.length() - 1;
				E first = (InternalEntry) table.get(index);

				for (e = first; e != null; e = e.getNext()) {
					K entryKey = e.getKey();
					if (e.getHash() == hash && entryKey != null && this.map.keyEquivalence.equivalent(key, entryKey)) {
						V entryValue = e.getValue();
						Object var10;
						if (entryValue == null) {
							if (isCollected(e)) {
								int newCount = this.count - 1;
								++this.modCount;
								E newFirst = this.removeFromChain(first, e);
								newCount = this.count - 1;
								table.set(index, newFirst);
								this.count = newCount;
							}

							var10 = null;
							return var10;
						}

						++this.modCount;
						this.setValue(e, newValue);
						var10 = entryValue;
						return var10;
					}
				}

				e = null;
			} finally {
				this.unlock();
			}

			return e;
		}

		@CanIgnoreReturnValue
		V remove(Object key, int hash) {
			this.lock();

			InternalEntry e;
			try {
				this.preWriteCleanup();
				int newCount = this.count - 1;
				AtomicReferenceArray<E> table = this.table;
				int index = hash & table.length() - 1;
				E first = (InternalEntry) table.get(index);

				for (e = first; e != null; e = e.getNext()) {
					K entryKey = e.getKey();
					if (e.getHash() == hash && entryKey != null && this.map.keyEquivalence.equivalent(key, entryKey)) {
						V entryValue = e.getValue();
						InternalEntry newFirst;
						if (entryValue == null && !isCollected(e)) {
							newFirst = null;
							return newFirst;
						}

						++this.modCount;
						newFirst = this.removeFromChain(first, e);
						newCount = this.count - 1;
						table.set(index, newFirst);
						this.count = newCount;
						Object var11 = entryValue;
						return var11;
					}
				}

				e = null;
			} finally {
				this.unlock();
			}

			return e;
		}

		boolean remove(Object key, int hash, Object value) {
			this.lock();

			try {
				this.preWriteCleanup();
				int newCount = this.count - 1;
				AtomicReferenceArray<E> table = this.table;
				int index = hash & table.length() - 1;
				E first = (InternalEntry) table.get(index);

				for (E e = first; e != null; e = e.getNext()) {
					K entryKey = e.getKey();
					if (e.getHash() == hash && entryKey != null && this.map.keyEquivalence.equivalent(key, entryKey)) {
						V entryValue = e.getValue();
						boolean explicitRemoval = false;
						if (this.map.valueEquivalence().equivalent(value, entryValue)) {
							explicitRemoval = true;
						} else if (!isCollected(e)) {
							boolean var18 = false;
							return var18;
						}

						++this.modCount;
						E newFirst = this.removeFromChain(first, e);
						newCount = this.count - 1;
						table.set(index, newFirst);
						this.count = newCount;
						boolean var13 = explicitRemoval;
						return var13;
					}
				}

				boolean var17 = false;
				return var17;
			} finally {
				this.unlock();
			}
		}

		void clear() {
			if (this.count != 0) {
				this.lock();

				try {
					AtomicReferenceArray<E> table = this.table;

					for (int i = 0; i < table.length(); ++i) {
						table.set(i, (Object) null);
					}

					this.maybeClearReferenceQueues();
					this.readCount.set(0);
					++this.modCount;
					this.count = 0;
				} finally {
					this.unlock();
				}
			}

		}

		@GuardedBy("this")
		E removeFromChain(E first, E entry) {
			int newCount = this.count;
			E newFirst = entry.getNext();

			for (E e = first; e != entry; e = e.getNext()) {
				E next = this.copyEntry(e, newFirst);
				if (next != null) {
					newFirst = next;
				} else {
					--newCount;
				}
			}

			this.count = newCount;
			return newFirst;
		}

		@CanIgnoreReturnValue
		boolean reclaimKey(E entry, int hash) {
			this.lock();

			boolean var13;
			try {
				int newCount = this.count - 1;
				AtomicReferenceArray<E> table = this.table;
				int index = hash & table.length() - 1;
				E first = (InternalEntry) table.get(index);

				for (E e = first; e != null; e = e.getNext()) {
					if (e == entry) {
						++this.modCount;
						E newFirst = this.removeFromChain(first, e);
						newCount = this.count - 1;
						table.set(index, newFirst);
						this.count = newCount;
						boolean var9 = true;
						return var9;
					}
				}

				var13 = false;
			} finally {
				this.unlock();
			}

			return var13;
		}

		@CanIgnoreReturnValue
		boolean reclaimValue(K key, int hash, WeakValueReference<K, V, E> valueReference) {
			this.lock();

			boolean var17;
			try {
				int newCount = this.count - 1;
				AtomicReferenceArray<E> table = this.table;
				int index = hash & table.length() - 1;
				E first = (InternalEntry) table.get(index);

				for (E e = first; e != null; e = e.getNext()) {
					K entryKey = e.getKey();
					if (e.getHash() == hash && entryKey != null && this.map.keyEquivalence.equivalent(key, entryKey)) {
						WeakValueReference<K, V, E> v = ((WeakValueEntry) e).getValueReference();
						if (v == valueReference) {
							++this.modCount;
							E newFirst = this.removeFromChain(first, e);
							newCount = this.count - 1;
							table.set(index, newFirst);
							this.count = newCount;
							boolean var12 = true;
							return var12;
						}

						boolean var11 = false;
						return var11;
					}
				}

				var17 = false;
			} finally {
				this.unlock();
			}

			return var17;
		}

		@CanIgnoreReturnValue
		boolean clearValueForTesting(K key, int hash,
				WeakValueReference<K, V, ? extends InternalEntry<K, V, ?>> valueReference) {
			this.lock();

			boolean var16;
			try {
				AtomicReferenceArray<E> table = this.table;
				int index = hash & table.length() - 1;
				E first = (InternalEntry) table.get(index);

				for (E e = first; e != null; e = e.getNext()) {
					K entryKey = e.getKey();
					if (e.getHash() == hash && entryKey != null && this.map.keyEquivalence.equivalent(key, entryKey)) {
						WeakValueReference<K, V, E> v = ((WeakValueEntry) e).getValueReference();
						if (v == valueReference) {
							E newFirst = this.removeFromChain(first, e);
							table.set(index, newFirst);
							boolean var11 = true;
							return var11;
						}

						boolean var10 = false;
						return var10;
					}
				}

				var16 = false;
			} finally {
				this.unlock();
			}

			return var16;
		}

		@GuardedBy("this")
		boolean removeEntryForTesting(E entry) {
			int hash = entry.getHash();
			int newCount = this.count - 1;
			AtomicReferenceArray<E> table = this.table;
			int index = hash & table.length() - 1;
			E first = (InternalEntry) table.get(index);

			for (E e = first; e != null; e = e.getNext()) {
				if (e == entry) {
					++this.modCount;
					E newFirst = this.removeFromChain(first, e);
					newCount = this.count - 1;
					table.set(index, newFirst);
					this.count = newCount;
					return true;
				}
			}

			return false;
		}

		static <K, V, E extends InternalEntry<K, V, E>> boolean isCollected(E entry) {
			return entry.getValue() == null;
		}

		@NullableDecl
		V getLiveValue(E entry) {
			if (entry.getKey() == null) {
				this.tryDrainReferenceQueues();
				return null;
			} else {
				V value = entry.getValue();
				if (value == null) {
					this.tryDrainReferenceQueues();
					return null;
				} else {
					return value;
				}
			}
		}

		void postReadCleanup() {
			if ((this.readCount.incrementAndGet() & 63) == 0) {
				this.runCleanup();
			}

		}

		@GuardedBy("this")
		void preWriteCleanup() {
			this.runLockedCleanup();
		}

		void runCleanup() {
			this.runLockedCleanup();
		}

		void runLockedCleanup() {
			if (this.tryLock()) {
				try {
					this.maybeDrainReferenceQueues();
					this.readCount.set(0);
				} finally {
					this.unlock();
				}
			}

		}
	}

	static final class WeakValueReferenceImpl<K, V, E extends InternalEntry<K, V, E>> extends WeakReference<V>
			implements
				WeakValueReference<K, V, E> {
		@Weak
		final E entry;

		WeakValueReferenceImpl(ReferenceQueue<V> queue, V referent, E entry) {
			super(referent, queue);
			this.entry = entry;
		}

		public E getEntry() {
			return this.entry;
		}

		public WeakValueReference<K, V, E> copyFor(ReferenceQueue<V> queue, E entry) {
			return new WeakValueReferenceImpl(queue, this.get(), entry);
		}
	}

	static final class DummyInternalEntry implements InternalEntry<Object, Object, DummyInternalEntry> {
		private DummyInternalEntry() {
			throw new AssertionError();
		}

		public DummyInternalEntry getNext() {
			throw new AssertionError();
		}

		public int getHash() {
			throw new AssertionError();
		}

		public Object getKey() {
			throw new AssertionError();
		}

		public Object getValue() {
			throw new AssertionError();
		}
	}

	interface WeakValueReference<K, V, E extends InternalEntry<K, V, E>> {
		@NullableDecl
		V get();

		E getEntry();

		void clear();

		WeakValueReference<K, V, E> copyFor(ReferenceQueue<V> var1, E var2);
	}

	static final class WeakKeyWeakValueEntry<K, V> extends AbstractWeakKeyEntry<K, V, WeakKeyWeakValueEntry<K, V>>
			implements
				WeakValueEntry<K, V, WeakKeyWeakValueEntry<K, V>> {
		private volatile WeakValueReference<K, V, WeakKeyWeakValueEntry<K, V>> valueReference = MapMakerInternalMap
				.unsetWeakValueReference();

		WeakKeyWeakValueEntry(ReferenceQueue<K> queue, K key, int hash,
				@NullableDecl WeakKeyWeakValueEntry<K, V> next) {
			super(queue, key, hash, next);
		}

		public V getValue() {
			return this.valueReference.get();
		}

		WeakKeyWeakValueEntry<K, V> copy(ReferenceQueue<K> queueForKeys, ReferenceQueue<V> queueForValues,
				WeakKeyWeakValueEntry<K, V> newNext) {
			WeakKeyWeakValueEntry<K, V> newEntry = new WeakKeyWeakValueEntry(queueForKeys, this.getKey(), this.hash,
					newNext);
			newEntry.valueReference = this.valueReference.copyFor(queueForValues, newEntry);
			return newEntry;
		}

		public void clearValue() {
			this.valueReference.clear();
		}

		void setValue(V value, ReferenceQueue<V> queueForValues) {
			WeakValueReference<K, V, WeakKeyWeakValueEntry<K, V>> previous = this.valueReference;
			this.valueReference = new WeakValueReferenceImpl(queueForValues, value, this);
			previous.clear();
		}

		public WeakValueReference<K, V, WeakKeyWeakValueEntry<K, V>> getValueReference() {
			return this.valueReference;
		}

		static final class Helper<K, V>
				implements
					InternalEntryHelper<K, V, WeakKeyWeakValueEntry<K, V>, WeakKeyWeakValueSegment<K, V>> {
			private static final Helper<?, ?> INSTANCE = new Helper();

			static <K, V> Helper<K, V> instance() {
				return INSTANCE;
			}

			public Strength keyStrength() {
				return MapMakerInternalMap.Strength.WEAK;
			}

			public Strength valueStrength() {
				return MapMakerInternalMap.Strength.WEAK;
			}

			public WeakKeyWeakValueSegment<K, V> newSegment(
					MapMakerInternalMap<K, V, WeakKeyWeakValueEntry<K, V>, WeakKeyWeakValueSegment<K, V>> map,
					int initialCapacity, int maxSegmentSize) {
				return new WeakKeyWeakValueSegment(map, initialCapacity, maxSegmentSize);
			}

			public WeakKeyWeakValueEntry<K, V> copy(WeakKeyWeakValueSegment<K, V> segment,
					WeakKeyWeakValueEntry<K, V> entry, @NullableDecl WeakKeyWeakValueEntry<K, V> newNext) {
				if (entry.getKey() == null) {
					return null;
				} else {
					return MapMakerInternalMap.Segment.isCollected(entry)
							? null
							: entry.copy(segment.queueForKeys, segment.queueForValues, newNext);
				}
			}

			public void setValue(WeakKeyWeakValueSegment<K, V> segment, WeakKeyWeakValueEntry<K, V> entry, V value) {
				entry.setValue(value, segment.queueForValues);
			}

			public WeakKeyWeakValueEntry<K, V> newEntry(WeakKeyWeakValueSegment<K, V> segment, K key, int hash,
					@NullableDecl WeakKeyWeakValueEntry<K, V> next) {
				return new WeakKeyWeakValueEntry(segment.queueForKeys, key, hash, next);
			}
		}
	}

	static final class WeakKeyStrongValueEntry<K, V> extends AbstractWeakKeyEntry<K, V, WeakKeyStrongValueEntry<K, V>>
			implements
				StrongValueEntry<K, V, WeakKeyStrongValueEntry<K, V>> {
		@NullableDecl
		private volatile V value = null;

		WeakKeyStrongValueEntry(ReferenceQueue<K> queue, K key, int hash,
				@NullableDecl WeakKeyStrongValueEntry<K, V> next) {
			super(queue, key, hash, next);
		}

		@NullableDecl
		public V getValue() {
			return this.value;
		}

		void setValue(V value) {
			this.value = value;
		}

		WeakKeyStrongValueEntry<K, V> copy(ReferenceQueue<K> queueForKeys, WeakKeyStrongValueEntry<K, V> newNext) {
			WeakKeyStrongValueEntry<K, V> newEntry = new WeakKeyStrongValueEntry(queueForKeys, this.getKey(), this.hash,
					newNext);
			newEntry.setValue(this.value);
			return newEntry;
		}

		static final class Helper<K, V>
				implements
					InternalEntryHelper<K, V, WeakKeyStrongValueEntry<K, V>, WeakKeyStrongValueSegment<K, V>> {
			private static final Helper<?, ?> INSTANCE = new Helper();

			static <K, V> Helper<K, V> instance() {
				return INSTANCE;
			}

			public Strength keyStrength() {
				return MapMakerInternalMap.Strength.WEAK;
			}

			public Strength valueStrength() {
				return MapMakerInternalMap.Strength.STRONG;
			}

			public WeakKeyStrongValueSegment<K, V> newSegment(
					MapMakerInternalMap<K, V, WeakKeyStrongValueEntry<K, V>, WeakKeyStrongValueSegment<K, V>> map,
					int initialCapacity, int maxSegmentSize) {
				return new WeakKeyStrongValueSegment(map, initialCapacity, maxSegmentSize);
			}

			public WeakKeyStrongValueEntry<K, V> copy(WeakKeyStrongValueSegment<K, V> segment,
					WeakKeyStrongValueEntry<K, V> entry, @NullableDecl WeakKeyStrongValueEntry<K, V> newNext) {
				return entry.getKey() == null ? null : entry.copy(segment.queueForKeys, newNext);
			}

			public void setValue(WeakKeyStrongValueSegment<K, V> segment, WeakKeyStrongValueEntry<K, V> entry,
					V value) {
				entry.setValue(value);
			}

			public WeakKeyStrongValueEntry<K, V> newEntry(WeakKeyStrongValueSegment<K, V> segment, K key, int hash,
					@NullableDecl WeakKeyStrongValueEntry<K, V> next) {
				return new WeakKeyStrongValueEntry(segment.queueForKeys, key, hash, next);
			}
		}
	}

	static final class WeakKeyDummyValueEntry<K>
			extends
				AbstractWeakKeyEntry<K, MapMaker.Dummy, WeakKeyDummyValueEntry<K>>
			implements
				StrongValueEntry<K, MapMaker.Dummy, WeakKeyDummyValueEntry<K>> {
		WeakKeyDummyValueEntry(ReferenceQueue<K> queue, K key, int hash, @NullableDecl WeakKeyDummyValueEntry<K> next) {
			super(queue, key, hash, next);
		}

		public MapMaker.Dummy getValue() {
			return Dummy.VALUE;
		}

		void setValue(MapMaker.Dummy value) {
		}

		WeakKeyDummyValueEntry<K> copy(ReferenceQueue<K> queueForKeys, WeakKeyDummyValueEntry<K> newNext) {
			return new WeakKeyDummyValueEntry(queueForKeys, this.getKey(), this.hash, newNext);
		}

		static final class Helper<K>
				implements
					InternalEntryHelper<K, MapMaker.Dummy, WeakKeyDummyValueEntry<K>, WeakKeyDummyValueSegment<K>> {
			private static final Helper<?> INSTANCE = new Helper();

			static <K> Helper<K> instance() {
				return INSTANCE;
			}

			public Strength keyStrength() {
				return MapMakerInternalMap.Strength.WEAK;
			}

			public Strength valueStrength() {
				return MapMakerInternalMap.Strength.STRONG;
			}

			public WeakKeyDummyValueSegment<K> newSegment(
					MapMakerInternalMap<K, MapMaker.Dummy, WeakKeyDummyValueEntry<K>, WeakKeyDummyValueSegment<K>> map,
					int initialCapacity, int maxSegmentSize) {
				return new WeakKeyDummyValueSegment(map, initialCapacity, maxSegmentSize);
			}

			public WeakKeyDummyValueEntry<K> copy(WeakKeyDummyValueSegment<K> segment, WeakKeyDummyValueEntry<K> entry,
					@NullableDecl WeakKeyDummyValueEntry<K> newNext) {
				return entry.getKey() == null ? null : entry.copy(segment.queueForKeys, newNext);
			}

			public void setValue(WeakKeyDummyValueSegment<K> segment, WeakKeyDummyValueEntry<K> entry,
					MapMaker.Dummy value) {
			}

			public WeakKeyDummyValueEntry<K> newEntry(WeakKeyDummyValueSegment<K> segment, K key, int hash,
					@NullableDecl WeakKeyDummyValueEntry<K> next) {
				return new WeakKeyDummyValueEntry(segment.queueForKeys, key, hash, next);
			}
		}
	}

	abstract static class AbstractWeakKeyEntry<K, V, E extends InternalEntry<K, V, E>> extends WeakReference<K>
			implements
				InternalEntry<K, V, E> {
		final int hash;
		@NullableDecl
		final E next;

		AbstractWeakKeyEntry(ReferenceQueue<K> queue, K key, int hash, @NullableDecl E next) {
			super(key, queue);
			this.hash = hash;
			this.next = next;
		}

		public K getKey() {
			return this.get();
		}

		public int getHash() {
			return this.hash;
		}

		public E getNext() {
			return this.next;
		}
	}

	static final class StrongKeyDummyValueEntry<K>
			extends
				AbstractStrongKeyEntry<K, MapMaker.Dummy, StrongKeyDummyValueEntry<K>>
			implements
				StrongValueEntry<K, MapMaker.Dummy, StrongKeyDummyValueEntry<K>> {
		StrongKeyDummyValueEntry(K key, int hash, @NullableDecl StrongKeyDummyValueEntry<K> next) {
			super(key, hash, next);
		}

		public MapMaker.Dummy getValue() {
			return Dummy.VALUE;
		}

		void setValue(MapMaker.Dummy value) {
		}

		StrongKeyDummyValueEntry<K> copy(StrongKeyDummyValueEntry<K> newNext) {
			return new StrongKeyDummyValueEntry(this.key, this.hash, newNext);
		}

		static final class Helper<K>
				implements
					InternalEntryHelper<K, MapMaker.Dummy, StrongKeyDummyValueEntry<K>, StrongKeyDummyValueSegment<K>> {
			private static final Helper<?> INSTANCE = new Helper();

			static <K> Helper<K> instance() {
				return INSTANCE;
			}

			public Strength keyStrength() {
				return MapMakerInternalMap.Strength.STRONG;
			}

			public Strength valueStrength() {
				return MapMakerInternalMap.Strength.STRONG;
			}

			public StrongKeyDummyValueSegment<K> newSegment(
					MapMakerInternalMap<K, MapMaker.Dummy, StrongKeyDummyValueEntry<K>, StrongKeyDummyValueSegment<K>> map,
					int initialCapacity, int maxSegmentSize) {
				return new StrongKeyDummyValueSegment(map, initialCapacity, maxSegmentSize);
			}

			public StrongKeyDummyValueEntry<K> copy(StrongKeyDummyValueSegment<K> segment,
					StrongKeyDummyValueEntry<K> entry, @NullableDecl StrongKeyDummyValueEntry<K> newNext) {
				return entry.copy(newNext);
			}

			public void setValue(StrongKeyDummyValueSegment<K> segment, StrongKeyDummyValueEntry<K> entry,
					MapMaker.Dummy value) {
			}

			public StrongKeyDummyValueEntry<K> newEntry(StrongKeyDummyValueSegment<K> segment, K key, int hash,
					@NullableDecl StrongKeyDummyValueEntry<K> next) {
				return new StrongKeyDummyValueEntry(key, hash, next);
			}
		}
	}

	static final class StrongKeyWeakValueEntry<K, V> extends AbstractStrongKeyEntry<K, V, StrongKeyWeakValueEntry<K, V>>
			implements
				WeakValueEntry<K, V, StrongKeyWeakValueEntry<K, V>> {
		private volatile WeakValueReference<K, V, StrongKeyWeakValueEntry<K, V>> valueReference = MapMakerInternalMap
				.unsetWeakValueReference();

		StrongKeyWeakValueEntry(K key, int hash, @NullableDecl StrongKeyWeakValueEntry<K, V> next) {
			super(key, hash, next);
		}

		public V getValue() {
			return this.valueReference.get();
		}

		public void clearValue() {
			this.valueReference.clear();
		}

		void setValue(V value, ReferenceQueue<V> queueForValues) {
			WeakValueReference<K, V, StrongKeyWeakValueEntry<K, V>> previous = this.valueReference;
			this.valueReference = new WeakValueReferenceImpl(queueForValues, value, this);
			previous.clear();
		}

		StrongKeyWeakValueEntry<K, V> copy(ReferenceQueue<V> queueForValues, StrongKeyWeakValueEntry<K, V> newNext) {
			StrongKeyWeakValueEntry<K, V> newEntry = new StrongKeyWeakValueEntry(this.key, this.hash, newNext);
			newEntry.valueReference = this.valueReference.copyFor(queueForValues, newEntry);
			return newEntry;
		}

		public WeakValueReference<K, V, StrongKeyWeakValueEntry<K, V>> getValueReference() {
			return this.valueReference;
		}

		static final class Helper<K, V>
				implements
					InternalEntryHelper<K, V, StrongKeyWeakValueEntry<K, V>, StrongKeyWeakValueSegment<K, V>> {
			private static final Helper<?, ?> INSTANCE = new Helper();

			static <K, V> Helper<K, V> instance() {
				return INSTANCE;
			}

			public Strength keyStrength() {
				return MapMakerInternalMap.Strength.STRONG;
			}

			public Strength valueStrength() {
				return MapMakerInternalMap.Strength.WEAK;
			}

			public StrongKeyWeakValueSegment<K, V> newSegment(
					MapMakerInternalMap<K, V, StrongKeyWeakValueEntry<K, V>, StrongKeyWeakValueSegment<K, V>> map,
					int initialCapacity, int maxSegmentSize) {
				return new StrongKeyWeakValueSegment(map, initialCapacity, maxSegmentSize);
			}

			public StrongKeyWeakValueEntry<K, V> copy(StrongKeyWeakValueSegment<K, V> segment,
					StrongKeyWeakValueEntry<K, V> entry, @NullableDecl StrongKeyWeakValueEntry<K, V> newNext) {
				return MapMakerInternalMap.Segment.isCollected(entry)
						? null
						: entry.copy(segment.queueForValues, newNext);
			}

			public void setValue(StrongKeyWeakValueSegment<K, V> segment, StrongKeyWeakValueEntry<K, V> entry,
					V value) {
				entry.setValue(value, segment.queueForValues);
			}

			public StrongKeyWeakValueEntry<K, V> newEntry(StrongKeyWeakValueSegment<K, V> segment, K key, int hash,
					@NullableDecl StrongKeyWeakValueEntry<K, V> next) {
				return new StrongKeyWeakValueEntry(key, hash, next);
			}
		}
	}

	static final class StrongKeyStrongValueEntry<K, V>
			extends
				AbstractStrongKeyEntry<K, V, StrongKeyStrongValueEntry<K, V>>
			implements
				StrongValueEntry<K, V, StrongKeyStrongValueEntry<K, V>> {
		@NullableDecl
		private volatile V value = null;

		StrongKeyStrongValueEntry(K key, int hash, @NullableDecl StrongKeyStrongValueEntry<K, V> next) {
			super(key, hash, next);
		}

		@NullableDecl
		public V getValue() {
			return this.value;
		}

		void setValue(V value) {
			this.value = value;
		}

		StrongKeyStrongValueEntry<K, V> copy(StrongKeyStrongValueEntry<K, V> newNext) {
			StrongKeyStrongValueEntry<K, V> newEntry = new StrongKeyStrongValueEntry(this.key, this.hash, newNext);
			newEntry.value = this.value;
			return newEntry;
		}

		static final class Helper<K, V>
				implements
					InternalEntryHelper<K, V, StrongKeyStrongValueEntry<K, V>, StrongKeyStrongValueSegment<K, V>> {
			private static final Helper<?, ?> INSTANCE = new Helper();

			static <K, V> Helper<K, V> instance() {
				return INSTANCE;
			}

			public Strength keyStrength() {
				return MapMakerInternalMap.Strength.STRONG;
			}

			public Strength valueStrength() {
				return MapMakerInternalMap.Strength.STRONG;
			}

			public StrongKeyStrongValueSegment<K, V> newSegment(
					MapMakerInternalMap<K, V, StrongKeyStrongValueEntry<K, V>, StrongKeyStrongValueSegment<K, V>> map,
					int initialCapacity, int maxSegmentSize) {
				return new StrongKeyStrongValueSegment(map, initialCapacity, maxSegmentSize);
			}

			public StrongKeyStrongValueEntry<K, V> copy(StrongKeyStrongValueSegment<K, V> segment,
					StrongKeyStrongValueEntry<K, V> entry, @NullableDecl StrongKeyStrongValueEntry<K, V> newNext) {
				return entry.copy(newNext);
			}

			public void setValue(StrongKeyStrongValueSegment<K, V> segment, StrongKeyStrongValueEntry<K, V> entry,
					V value) {
				entry.setValue(value);
			}

			public StrongKeyStrongValueEntry<K, V> newEntry(StrongKeyStrongValueSegment<K, V> segment, K key, int hash,
					@NullableDecl StrongKeyStrongValueEntry<K, V> next) {
				return new StrongKeyStrongValueEntry(key, hash, next);
			}
		}
	}

	interface WeakValueEntry<K, V, E extends InternalEntry<K, V, E>> extends InternalEntry<K, V, E> {
		WeakValueReference<K, V, E> getValueReference();

		void clearValue();
	}

	interface StrongValueEntry<K, V, E extends InternalEntry<K, V, E>> extends InternalEntry<K, V, E> {
	}

	abstract static class AbstractStrongKeyEntry<K, V, E extends InternalEntry<K, V, E>>
			implements
				InternalEntry<K, V, E> {
		final K key;
		final int hash;
		@NullableDecl
		final E next;

		AbstractStrongKeyEntry(K key, int hash, @NullableDecl E next) {
			this.key = key;
			this.hash = hash;
			this.next = next;
		}

		public K getKey() {
			return this.key;
		}

		public int getHash() {
			return this.hash;
		}

		public E getNext() {
			return this.next;
		}
	}

	interface InternalEntry<K, V, E extends InternalEntry<K, V, E>> {
		E getNext();

		int getHash();

		K getKey();

		V getValue();
	}

	interface InternalEntryHelper<K, V, E extends InternalEntry<K, V, E>, S extends Segment<K, V, E, S>> {
		Strength keyStrength();

		Strength valueStrength();

		S newSegment(MapMakerInternalMap<K, V, E, S> var1, int var2, int var3);

		E newEntry(S var1, K var2, int var3, @NullableDecl E var4);

		E copy(S var1, E var2, @NullableDecl E var3);

		void setValue(S var1, E var2, V var3);
	}

	static enum Strength {
		STRONG {
			Equivalence<Object> defaultEquivalence() {
				return Equivalence.equals();
			}
		},
		WEAK {
			Equivalence<Object> defaultEquivalence() {
				return Equivalence.identity();
			}
		};

		private Strength() {
		}

		abstract Equivalence<Object> defaultEquivalence();
	}
}