package com.google.common.base;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Converter.1;
import com.google.common.base.Converter.ConverterComposition;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.ForOverride;
import com.google.errorprone.annotations.concurrent.LazyInit;
import java.io.Serializable;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public abstract class Converter<A, B> implements Function<A, B> {
	private final boolean handleNullAutomatically;
	@LazyInit
	@MonotonicNonNullDecl
	private transient Converter<B, A> reverse;

	protected Converter() {
		this(true);
	}

	Converter(boolean handleNullAutomatically) {
		this.handleNullAutomatically = handleNullAutomatically;
	}

	@ForOverride
	protected abstract B doForward(A var1);

	@ForOverride
	protected abstract A doBackward(B var1);

	@NullableDecl
	@CanIgnoreReturnValue
	public final B convert(@NullableDecl A a) {
		return this.correctedDoForward(a);
	}

	@NullableDecl
	B correctedDoForward(@NullableDecl A a) {
		if (this.handleNullAutomatically) {
			return a == null ? null : Preconditions.checkNotNull(this.doForward(a));
		} else {
			return this.doForward(a);
		}
	}

	@NullableDecl
	A correctedDoBackward(@NullableDecl B b) {
		if (this.handleNullAutomatically) {
			return b == null ? null : Preconditions.checkNotNull(this.doBackward(b));
		} else {
			return this.doBackward(b);
		}
	}

	@CanIgnoreReturnValue
   public Iterable<B> convertAll(Iterable<? extends A> fromIterable) {
      Preconditions.checkNotNull(fromIterable, "fromIterable");
      return new 1(this, fromIterable);
   }

	@CanIgnoreReturnValue
	public Converter<B, A> reverse() {
		Converter<B, A> result = this.reverse;
		return result == null ? (this.reverse = new Converter.ReverseConverter(this)) : result;
	}

	public final <C> Converter<A, C> andThen(Converter<B, C> secondConverter) {
		return this.doAndThen(secondConverter);
	}

	<C> Converter<A, C> doAndThen(Converter<B, C> secondConverter) {
		return new ConverterComposition(this, (Converter) Preconditions.checkNotNull(secondConverter));
	}

	@Deprecated
	@NullableDecl
	@CanIgnoreReturnValue
	public final B apply(@NullableDecl A a) {
		return this.convert(a);
	}

	public boolean equals(@NullableDecl Object object) {
		return super.equals(object);
	}

	public static <A, B> Converter<A, B> from(Function<? super A, ? extends B> forwardFunction, Function<? super B, ? extends A> backwardFunction) {
      return new Converter.FunctionBasedConverter(forwardFunction, backwardFunction, (1)null);
   }

	public static <T> Converter<T, T> identity() {
		return Converter.IdentityConverter.INSTANCE;
	}

	private static final class IdentityConverter<T> extends Converter<T, T> implements Serializable {
		static final Converter.IdentityConverter INSTANCE = new Converter.IdentityConverter();
		private static final long serialVersionUID = 0L;

		protected T doForward(T t) {
			return t;
		}

		protected T doBackward(T t) {
			return t;
		}

		public Converter.IdentityConverter<T> reverse() {
			return this;
		}

		<S> Converter<T, S> doAndThen(Converter<T, S> otherConverter) {
			return (Converter) Preconditions.checkNotNull(otherConverter, "otherConverter");
		}

		public String toString() {
			return "Converter.identity()";
		}

		private Object readResolve() {
			return INSTANCE;
		}
	}

	private static final class FunctionBasedConverter<A, B> extends Converter<A, B> implements Serializable {
		private final Function<? super A, ? extends B> forwardFunction;
		private final Function<? super B, ? extends A> backwardFunction;

		private FunctionBasedConverter(Function<? super A, ? extends B> forwardFunction,
				Function<? super B, ? extends A> backwardFunction) {
			this.forwardFunction = (Function) Preconditions.checkNotNull(forwardFunction);
			this.backwardFunction = (Function) Preconditions.checkNotNull(backwardFunction);
		}

		protected B doForward(A a) {
			return this.forwardFunction.apply(a);
		}

		protected A doBackward(B b) {
			return this.backwardFunction.apply(b);
		}

		public boolean equals(@NullableDecl Object object) {
			if (!(object instanceof Converter.FunctionBasedConverter)) {
				return false;
			} else {
				Converter.FunctionBasedConverter<?, ?> that = (Converter.FunctionBasedConverter) object;
				return this.forwardFunction.equals(that.forwardFunction)
						&& this.backwardFunction.equals(that.backwardFunction);
			}
		}

		public int hashCode() {
			return this.forwardFunction.hashCode() * 31 + this.backwardFunction.hashCode();
		}

		public String toString() {
			return "Converter.from(" + this.forwardFunction + ", " + this.backwardFunction + ")";
		}
	}

	private static final class ReverseConverter<A, B> extends Converter<B, A> implements Serializable {
		final Converter<A, B> original;
		private static final long serialVersionUID = 0L;

		ReverseConverter(Converter<A, B> original) {
			this.original = original;
		}

		protected A doForward(B b) {
			throw new AssertionError();
		}

		protected B doBackward(A a) {
			throw new AssertionError();
		}

		@NullableDecl
		A correctedDoForward(@NullableDecl B b) {
			return this.original.correctedDoBackward(b);
		}

		@NullableDecl
		B correctedDoBackward(@NullableDecl A a) {
			return this.original.correctedDoForward(a);
		}

		public Converter<A, B> reverse() {
			return this.original;
		}

		public boolean equals(@NullableDecl Object object) {
			if (object instanceof Converter.ReverseConverter) {
				Converter.ReverseConverter<?, ?> that = (Converter.ReverseConverter) object;
				return this.original.equals(that.original);
			} else {
				return false;
			}
		}

		public int hashCode() {
			return ~this.original.hashCode();
		}

		public String toString() {
			return this.original + ".reverse()";
		}
	}
}