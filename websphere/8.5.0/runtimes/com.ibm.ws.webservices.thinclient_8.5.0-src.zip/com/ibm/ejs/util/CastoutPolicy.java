package com.ibm.ejs.util;

public interface CastoutPolicy {
	void castout(LRUCacheElement var1);
}