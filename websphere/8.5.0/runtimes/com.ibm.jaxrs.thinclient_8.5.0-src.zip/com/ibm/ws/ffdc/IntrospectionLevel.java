package com.ibm.ws.ffdc;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class IntrospectionLevel {
	public static final String $sccsid = "@(#) 1.1 SERV1/ws/code/ras.lite/src/com/ibm/ws/ffdc/IntrospectionLevel.java, WAS.ras.lite, WAS855.SERV1, cf051506.04 06/11/06 11:21:24 [2/19/15 14:14:30]";
	private int _sizeOfJustThisLevel = 0;
	private int _sizeOfAllLevelsUpToAndIncludingThisLevel = 0;
	private Set<IntrospectionLevelMember> _members;
	private IntrospectionLevel _nextLevel = null;
	private int _levelDepth;

	public IntrospectionLevel(Object rootObject) {
		this._levelDepth = 0;
		this._members = new HashSet();
		this._members.add(new IntrospectionLevelMember(rootObject));
		this.computeSizeOfLevelMembers();
		this._sizeOfAllLevelsUpToAndIncludingThisLevel = this._sizeOfJustThisLevel;
	}

	private IntrospectionLevel(int levelDepth, IntrospectionLevel parentLevel, Set<IntrospectionLevelMember> members) {
		this._members = members;
		this._levelDepth = levelDepth;
		this.computeSizeOfLevelMembers();
		if (parentLevel != null) {
			this._sizeOfAllLevelsUpToAndIncludingThisLevel = parentLevel.getNumberOfBytesInAllLevelsIncludingThisOne();
		}

		this._sizeOfAllLevelsUpToAndIncludingThisLevel += this._sizeOfJustThisLevel;
	}

	private void computeSizeOfLevelMembers() {
		this._sizeOfJustThisLevel = 0;

		IntrospectionLevelMember ilm;
		for (Iterator i$ = this._members.iterator(); i$
				.hasNext(); this._sizeOfJustThisLevel += ilm.sizeOfIntrospection()) {
			ilm = (IntrospectionLevelMember) i$.next();
		}

	}

	public IntrospectionLevel getNextLevel() {
		if (this._nextLevel == null) {
			Set<IntrospectionLevelMember> _nextSet = new HashSet();
			Iterator i$ = this._members.iterator();

			while (i$.hasNext()) {
				IntrospectionLevelMember ilm = (IntrospectionLevelMember) i$.next();
				_nextSet.addAll(ilm.getChildren());
			}

			this._nextLevel = new IntrospectionLevel(this._levelDepth + 1, this, _nextSet);
		}

		return this._nextLevel;
	}

	public int getNumberOfBytesinJustThisLevel() {
		return this._sizeOfJustThisLevel;
	}

	public boolean hasMembers() {
		return !this._members.isEmpty();
	}

	public int getNumberOfBytesInAllLevelsIncludingThisOne() {
		return this._sizeOfAllLevelsUpToAndIncludingThisLevel;
	}

	public void print(IncidentStream is, int actualDepth) {
		Iterator i$ = this._members.iterator();

		while (i$.hasNext()) {
			IntrospectionLevelMember ilm = (IntrospectionLevelMember) i$.next();
			ilm.print(is, actualDepth);
		}

	}
}