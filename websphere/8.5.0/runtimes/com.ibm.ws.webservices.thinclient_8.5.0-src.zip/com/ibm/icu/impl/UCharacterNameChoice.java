package com.ibm.icu.impl;

public interface UCharacterNameChoice {
	int UNICODE_CHAR_NAME = 0;
	int UNICODE_10_CHAR_NAME = 1;
	int EXTENDED_CHAR_NAME = 2;
	int CHAR_NAME_ALIAS = 3;
	int CHAR_NAME_CHOICE_COUNT = 4;
	int ISO_COMMENT_ = 4;
}