package com.ibm.ws.wim.policy;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.adapter.ldap.LdapConnection;
import com.ibm.ws.wim.adapter.ldap.LdapHelper;
import com.ibm.ws.wim.policy.ldap.SunOneHandler;
import com.ibm.ws.wim.policy.ldap.TDSHandler;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.wsspi.wim.adapter.ldap.GenericLdapPolicyHandler;
import com.ibm.wsspi.wim.adapter.ldap.ILdapPolicyHandler;
import commonj.sdo.DataObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;

public class PolicyHandlerFactory {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	static String DEFAULT_LDAP_MAPPING_FILE;
	static String DEFAULT_POLICY_DIR;

	public static Object getPolicyHandler(DataObject var0, LdapConnection var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		Object var4 = getDefaultHandler(var0, var1);
		String var5 = getDefaultPolicyFileName(var0);
		Properties var6 = null;
		if (var5 != null) {
			var6 = new Properties();

			try {
				if (var5.indexOf(File.separator) == -1) {
					var5 = ConfigManager.singleton().getWIMHomePath(DomainManagerUtils.getDomainName()) + "config"
							+ File.separator + var5;
				}

				FileInputStream var7 = new FileInputStream(var5);
				var6.load(var7);
			} catch (IOException var12) {
				if (var3) {
					trcLogger.logp(Level.SEVERE, CLASSNAME, "getPolicyHandler",
							"Policy Response Mapping properties File, " + var5 + "could not be loaded");
				}

				ClassLoader var8 = Thread.currentThread().getContextClassLoader();
				if (var8 == null) {
					var8 = PolicyHandlerFactory.class.getClassLoader();
				}

				InputStream var9 = var8.getResourceAsStream(var5);

				try {
					var6.load(var9);
				} catch (IOException var11) {
					if (var3) {
						trcLogger.logp(Level.SEVERE, CLASSNAME, "getPolicyHandler",
								"Policy Response Mapping properties File could not be loaded from " + var5);
					}
				}
			}
		}

		if (var4 != null) {
			if (var4 instanceof ILdapPolicyHandler) {
				((ILdapPolicyHandler) var4).initialize(var6, var0);
			}
		} else if (var3) {
			trcLogger.logp(Level.SEVERE, CLASSNAME, "getPolicyHandler", "Policy Handler is NULL.");
		}

		return var4;
	}

	private static String getDefaultPolicyFileName(DataObject var0) {
		String var1 = null;
		String var2 = var0.getType().getName();
		if (var2.equals("LdapRepositoryType")) {
			var1 = DEFAULT_LDAP_MAPPING_FILE;
		}

		if (var1 != null) {
			String var3 = System.getProperty("was.install.root");
			var1 = var3 + File.separator + "etc" + File.separator + "wim" + File.separator + DEFAULT_POLICY_DIR
					+ File.separator + var1;
		}

		return var1;
	}

	private static boolean isOpenLdapServer(LdapConnection var0) throws WIMException {
		boolean var2 = trcLogger.isLoggable(Level.FINER);
		boolean var3 = false;

		try {
			NamingEnumeration var4 = var0.search_skip_cache("", "(objectclass=*)", 0, (String[]) null,
					(Control[]) null);
			if (var4.hasMore()) {
				SearchResult var5 = (SearchResult) var4.next();
				if (var2) {
					trcLogger.logp(Level.FINER, CLASSNAME, "isOpenLdapServer", "searchResult=" + var5);
				}

				Attribute var6 = var5.getAttributes().get("objectclass");
				if (var6 != null && var6.contains("OpenLDAProotDSE")) {
					return true;
				}
			}

			return var3;
		} catch (NamingException var7) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var7.toString(true)),
					Level.SEVERE, CLASSNAME, "isOpenLdapServer", var7);
		}
	}

	private static Object getDefaultHandler(DataObject var0, LdapConnection var1) throws WIMException {
		Object var2 = null;
		String var3 = var0.getType().getName();
		String var4 = null;
		if (var3.equals("LdapRepositoryType")) {
			var4 = LdapHelper.getLdapServerType(var0);
		}

		if (var3.equals("ProfileRepositoryType")) {
			var4 = var0.getString("adapterClassName");
		}

		if (var4.startsWith("IDS")) {
			var2 = new TDSHandler();
		} else if (var4.startsWith("SUNONE")) {
			var2 = new SunOneHandler();
		} else if (var4.startsWith("AD")) {
			var2 = new GenericLdapPolicyHandler();
		} else if (var4.startsWith("CUSTOM") && isOpenLdapServer(var1)) {
			var2 = new PolicyHandler();
		}

		return var2;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2014;
		CLASSNAME = PolicyHandlerFactory.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		DEFAULT_LDAP_MAPPING_FILE = "LdapPolicyMessageMapping.properties";
		DEFAULT_POLICY_DIR = "policy";
	}
}