package com.ibm.wsspi.ssl;

import java.security.cert.X509Certificate;
import java.util.HashMap;
import javax.security.auth.x500.X500Principal;

public interface WSPKIClient {
	void init(HashMap var1) throws WSPKIException;

	X509Certificate[] requestCertificate(byte[] var1, X500Principal var2, byte[] var3, HashMap var4)
			throws WSPKIException;

	void revokeCertificate(X509Certificate[] var1, byte[] var2, String var3, HashMap var4) throws WSPKIException;

	X509Certificate[] queryCertificate(byte[] var1, HashMap var2) throws WSPKIException;
}