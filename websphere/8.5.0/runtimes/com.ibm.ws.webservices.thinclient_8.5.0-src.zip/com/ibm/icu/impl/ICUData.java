package com.ibm.icu.impl;

import com.ibm.icu.impl.ICUData.1;
import com.ibm.icu.impl.ICUData.2;
import com.ibm.icu.impl.ICUData.3;
import java.io.InputStream;
import java.net.URL;
import java.security.AccessController;
import java.util.MissingResourceException;

public final class ICUData {
	public static boolean exists(String resourceName) {
      URL i = null;
      if (System.getSecurityManager() != null) {
         i = (URL)AccessController.doPrivileged(new 1(resourceName));
      } else {
         i = ICUData.class.getResource(resourceName);
      }

      return i != null;
   }

	private static InputStream getStream(Class<?> root, String resourceName, boolean required) {
      InputStream i = null;
      if (System.getSecurityManager() != null) {
         i = (InputStream)AccessController.doPrivileged(new 2(root, resourceName));
      } else {
         i = root.getResourceAsStream(resourceName);
      }

      if (i == null && required) {
         throw new MissingResourceException("could not locate data " + resourceName, root.getPackage().getName(), resourceName);
      } else {
         return i;
      }
   }

	private static InputStream getStream(ClassLoader loader, String resourceName, boolean required) {
      InputStream i = null;
      if (System.getSecurityManager() != null) {
         i = (InputStream)AccessController.doPrivileged(new 3(loader, resourceName));
      } else {
         i = loader.getResourceAsStream(resourceName);
      }

      if (i == null && required) {
         throw new MissingResourceException("could not locate data", loader.toString(), resourceName);
      } else {
         return i;
      }
   }

	public static InputStream getStream(ClassLoader loader, String resourceName) {
		return getStream(loader, resourceName, false);
	}

	public static InputStream getRequiredStream(ClassLoader loader, String resourceName) {
		return getStream(loader, resourceName, true);
	}

	public static InputStream getStream(String resourceName) {
		return getStream(ICUData.class, resourceName, false);
	}

	public static InputStream getRequiredStream(String resourceName) {
		return getStream(ICUData.class, resourceName, true);
	}

	public static InputStream getStream(Class<?> root, String resourceName) {
		return getStream(root, resourceName, false);
	}

	public static InputStream getRequiredStream(Class<?> root, String resourceName) {
		return getStream(root, resourceName, true);
	}
}