package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.AttributeGroupType;
import com.ibm.ws.wim.configmodel.AuthorizationType;
import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class AuthorizationTypeImpl extends EDataObjectImpl implements AuthorizationType {
	protected EList attributeGroups = null;
	protected static final String DEFAULT_ATTRIBUTE_GROUP_EDEFAULT = null;
	protected String defaultAttributeGroup;
	protected static final boolean IMPORT_POLICY_FROM_FILE_EDEFAULT = false;
	protected boolean importPolicyFromFile;
	protected boolean importPolicyFromFileESet;
	protected static final boolean IS_ATTRIBUTE_GROUPING_ENABLED_EDEFAULT = false;
	protected boolean isAttributeGroupingEnabled;
	protected boolean isAttributeGroupingEnabledESet;
	protected static final boolean IS_SECURITY_ENABLED_EDEFAULT = false;
	protected boolean isSecurityEnabled;
	protected boolean isSecurityEnabledESet;
	protected static final String JACC_POLICY_CLASS_EDEFAULT = null;
	protected String jaccPolicyClass;
	protected static final String JACC_POLICY_CONFIG_FACTORY_CLASS_EDEFAULT = null;
	protected String jaccPolicyConfigFactoryClass;
	protected static final String JACC_PRINCIPAL_TO_ROLE_POLICY_FILE_NAME_EDEFAULT = null;
	protected String jaccPrincipalToRolePolicyFileName;
	protected static final String JACC_PRINCIPAL_TO_ROLE_POLICY_ID_EDEFAULT = null;
	protected String jaccPrincipalToRolePolicyId;
	protected static final String JACC_ROLE_MAPPING_CLASS_EDEFAULT = null;
	protected String jaccRoleMappingClass;
	protected static final String JACC_ROLE_MAPPING_CONFIG_FACTORY_CLASS_EDEFAULT = null;
	protected String jaccRoleMappingConfigFactoryClass;
	protected static final String JACC_ROLE_TO_PERMISSION_POLICY_FILE_NAME_EDEFAULT = null;
	protected String jaccRoleToPermissionPolicyFileName;
	protected static final String JACC_ROLE_TO_PERMISSION_POLICY_ID_EDEFAULT = null;
	protected String jaccRoleToPermissionPolicyId;
	protected static final boolean USE_SYSTEM_JACC_PROVIDER_EDEFAULT = false;
	protected boolean useSystemJACCProvider;
	protected boolean useSystemJACCProviderESet;

	protected AuthorizationTypeImpl() {
		this.defaultAttributeGroup = DEFAULT_ATTRIBUTE_GROUP_EDEFAULT;
		this.importPolicyFromFile = false;
		this.importPolicyFromFileESet = false;
		this.isAttributeGroupingEnabled = false;
		this.isAttributeGroupingEnabledESet = false;
		this.isSecurityEnabled = false;
		this.isSecurityEnabledESet = false;
		this.jaccPolicyClass = JACC_POLICY_CLASS_EDEFAULT;
		this.jaccPolicyConfigFactoryClass = JACC_POLICY_CONFIG_FACTORY_CLASS_EDEFAULT;
		this.jaccPrincipalToRolePolicyFileName = JACC_PRINCIPAL_TO_ROLE_POLICY_FILE_NAME_EDEFAULT;
		this.jaccPrincipalToRolePolicyId = JACC_PRINCIPAL_TO_ROLE_POLICY_ID_EDEFAULT;
		this.jaccRoleMappingClass = JACC_ROLE_MAPPING_CLASS_EDEFAULT;
		this.jaccRoleMappingConfigFactoryClass = JACC_ROLE_MAPPING_CONFIG_FACTORY_CLASS_EDEFAULT;
		this.jaccRoleToPermissionPolicyFileName = JACC_ROLE_TO_PERMISSION_POLICY_FILE_NAME_EDEFAULT;
		this.jaccRoleToPermissionPolicyId = JACC_ROLE_TO_PERMISSION_POLICY_ID_EDEFAULT;
		this.useSystemJACCProvider = false;
		this.useSystemJACCProviderESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getAuthorizationType();
	}

	public AttributeGroupType[] getAttributeGroupsAsArray() {
		List var1 = this.getAttributeGroups();
		return (AttributeGroupType[]) ((AttributeGroupType[]) var1.toArray(new AttributeGroupType[var1.size()]));
	}

	public List getAttributeGroups() {
		if (this.attributeGroups == null) {
			this.attributeGroups = new EObjectContainmentEList(AttributeGroupType.class, this, 0);
		}

		return this.attributeGroups;
	}

	public AttributeGroupType createAttributeGroups() {
		AttributeGroupType var1 = ConfigmodelFactory.eINSTANCE.createAttributeGroupType();
		this.getAttributeGroups().add(var1);
		return var1;
	}

	public String getDefaultAttributeGroup() {
		return this.defaultAttributeGroup;
	}

	public void setDefaultAttributeGroup(String var1) {
		String var2 = this.defaultAttributeGroup;
		this.defaultAttributeGroup = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.defaultAttributeGroup));
		}

	}

	public boolean isImportPolicyFromFile() {
		return this.importPolicyFromFile;
	}

	public void setImportPolicyFromFile(boolean var1) {
		boolean var2 = this.importPolicyFromFile;
		this.importPolicyFromFile = var1;
		boolean var3 = this.importPolicyFromFileESet;
		this.importPolicyFromFileESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.importPolicyFromFile, !var3));
		}

	}

	public void unsetImportPolicyFromFile() {
		boolean var1 = this.importPolicyFromFile;
		boolean var2 = this.importPolicyFromFileESet;
		this.importPolicyFromFile = false;
		this.importPolicyFromFileESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 2, var1, false, var2));
		}

	}

	public boolean isSetImportPolicyFromFile() {
		return this.importPolicyFromFileESet;
	}

	public boolean isIsAttributeGroupingEnabled() {
		return this.isAttributeGroupingEnabled;
	}

	public void setIsAttributeGroupingEnabled(boolean var1) {
		boolean var2 = this.isAttributeGroupingEnabled;
		this.isAttributeGroupingEnabled = var1;
		boolean var3 = this.isAttributeGroupingEnabledESet;
		this.isAttributeGroupingEnabledESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.isAttributeGroupingEnabled, !var3));
		}

	}

	public void unsetIsAttributeGroupingEnabled() {
		boolean var1 = this.isAttributeGroupingEnabled;
		boolean var2 = this.isAttributeGroupingEnabledESet;
		this.isAttributeGroupingEnabled = false;
		this.isAttributeGroupingEnabledESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 3, var1, false, var2));
		}

	}

	public boolean isSetIsAttributeGroupingEnabled() {
		return this.isAttributeGroupingEnabledESet;
	}

	public boolean isIsSecurityEnabled() {
		return this.isSecurityEnabled;
	}

	public void setIsSecurityEnabled(boolean var1) {
		boolean var2 = this.isSecurityEnabled;
		this.isSecurityEnabled = var1;
		boolean var3 = this.isSecurityEnabledESet;
		this.isSecurityEnabledESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var2, this.isSecurityEnabled, !var3));
		}

	}

	public void unsetIsSecurityEnabled() {
		boolean var1 = this.isSecurityEnabled;
		boolean var2 = this.isSecurityEnabledESet;
		this.isSecurityEnabled = false;
		this.isSecurityEnabledESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 4, var1, false, var2));
		}

	}

	public boolean isSetIsSecurityEnabled() {
		return this.isSecurityEnabledESet;
	}

	public String getJaccPolicyClass() {
		return this.jaccPolicyClass;
	}

	public void setJaccPolicyClass(String var1) {
		String var2 = this.jaccPolicyClass;
		this.jaccPolicyClass = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 5, var2, this.jaccPolicyClass));
		}

	}

	public String getJaccPolicyConfigFactoryClass() {
		return this.jaccPolicyConfigFactoryClass;
	}

	public void setJaccPolicyConfigFactoryClass(String var1) {
		String var2 = this.jaccPolicyConfigFactoryClass;
		this.jaccPolicyConfigFactoryClass = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 6, var2, this.jaccPolicyConfigFactoryClass));
		}

	}

	public String getJaccPrincipalToRolePolicyFileName() {
		return this.jaccPrincipalToRolePolicyFileName;
	}

	public void setJaccPrincipalToRolePolicyFileName(String var1) {
		String var2 = this.jaccPrincipalToRolePolicyFileName;
		this.jaccPrincipalToRolePolicyFileName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 7, var2, this.jaccPrincipalToRolePolicyFileName));
		}

	}

	public String getJaccPrincipalToRolePolicyId() {
		return this.jaccPrincipalToRolePolicyId;
	}

	public void setJaccPrincipalToRolePolicyId(String var1) {
		String var2 = this.jaccPrincipalToRolePolicyId;
		this.jaccPrincipalToRolePolicyId = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 8, var2, this.jaccPrincipalToRolePolicyId));
		}

	}

	public String getJaccRoleMappingClass() {
		return this.jaccRoleMappingClass;
	}

	public void setJaccRoleMappingClass(String var1) {
		String var2 = this.jaccRoleMappingClass;
		this.jaccRoleMappingClass = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 9, var2, this.jaccRoleMappingClass));
		}

	}

	public String getJaccRoleMappingConfigFactoryClass() {
		return this.jaccRoleMappingConfigFactoryClass;
	}

	public void setJaccRoleMappingConfigFactoryClass(String var1) {
		String var2 = this.jaccRoleMappingConfigFactoryClass;
		this.jaccRoleMappingConfigFactoryClass = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 10, var2, this.jaccRoleMappingConfigFactoryClass));
		}

	}

	public String getJaccRoleToPermissionPolicyFileName() {
		return this.jaccRoleToPermissionPolicyFileName;
	}

	public void setJaccRoleToPermissionPolicyFileName(String var1) {
		String var2 = this.jaccRoleToPermissionPolicyFileName;
		this.jaccRoleToPermissionPolicyFileName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 11, var2, this.jaccRoleToPermissionPolicyFileName));
		}

	}

	public String getJaccRoleToPermissionPolicyId() {
		return this.jaccRoleToPermissionPolicyId;
	}

	public void setJaccRoleToPermissionPolicyId(String var1) {
		String var2 = this.jaccRoleToPermissionPolicyId;
		this.jaccRoleToPermissionPolicyId = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 12, var2, this.jaccRoleToPermissionPolicyId));
		}

	}

	public boolean isUseSystemJACCProvider() {
		return this.useSystemJACCProvider;
	}

	public void setUseSystemJACCProvider(boolean var1) {
		boolean var2 = this.useSystemJACCProvider;
		this.useSystemJACCProvider = var1;
		boolean var3 = this.useSystemJACCProviderESet;
		this.useSystemJACCProviderESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 13, var2, this.useSystemJACCProvider, !var3));
		}

	}

	public void unsetUseSystemJACCProvider() {
		boolean var1 = this.useSystemJACCProvider;
		boolean var2 = this.useSystemJACCProviderESet;
		this.useSystemJACCProvider = false;
		this.useSystemJACCProviderESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 13, var1, false, var2));
		}

	}

	public boolean isSetUseSystemJACCProvider() {
		return this.useSystemJACCProviderESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getAttributeGroups()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getAttributeGroups();
			case 1 :
				return this.getDefaultAttributeGroup();
			case 2 :
				return this.isImportPolicyFromFile() ? Boolean.TRUE : Boolean.FALSE;
			case 3 :
				return this.isIsAttributeGroupingEnabled() ? Boolean.TRUE : Boolean.FALSE;
			case 4 :
				return this.isIsSecurityEnabled() ? Boolean.TRUE : Boolean.FALSE;
			case 5 :
				return this.getJaccPolicyClass();
			case 6 :
				return this.getJaccPolicyConfigFactoryClass();
			case 7 :
				return this.getJaccPrincipalToRolePolicyFileName();
			case 8 :
				return this.getJaccPrincipalToRolePolicyId();
			case 9 :
				return this.getJaccRoleMappingClass();
			case 10 :
				return this.getJaccRoleMappingConfigFactoryClass();
			case 11 :
				return this.getJaccRoleToPermissionPolicyFileName();
			case 12 :
				return this.getJaccRoleToPermissionPolicyId();
			case 13 :
				return this.isUseSystemJACCProvider() ? Boolean.TRUE : Boolean.FALSE;
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getAttributeGroups().clear();
				this.getAttributeGroups().addAll((Collection) var2);
				return;
			case 1 :
				this.setDefaultAttributeGroup((String) var2);
				return;
			case 2 :
				this.setImportPolicyFromFile((Boolean) var2);
				return;
			case 3 :
				this.setIsAttributeGroupingEnabled((Boolean) var2);
				return;
			case 4 :
				this.setIsSecurityEnabled((Boolean) var2);
				return;
			case 5 :
				this.setJaccPolicyClass((String) var2);
				return;
			case 6 :
				this.setJaccPolicyConfigFactoryClass((String) var2);
				return;
			case 7 :
				this.setJaccPrincipalToRolePolicyFileName((String) var2);
				return;
			case 8 :
				this.setJaccPrincipalToRolePolicyId((String) var2);
				return;
			case 9 :
				this.setJaccRoleMappingClass((String) var2);
				return;
			case 10 :
				this.setJaccRoleMappingConfigFactoryClass((String) var2);
				return;
			case 11 :
				this.setJaccRoleToPermissionPolicyFileName((String) var2);
				return;
			case 12 :
				this.setJaccRoleToPermissionPolicyId((String) var2);
				return;
			case 13 :
				this.setUseSystemJACCProvider((Boolean) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getAttributeGroups().clear();
				return;
			case 1 :
				this.setDefaultAttributeGroup(DEFAULT_ATTRIBUTE_GROUP_EDEFAULT);
				return;
			case 2 :
				this.unsetImportPolicyFromFile();
				return;
			case 3 :
				this.unsetIsAttributeGroupingEnabled();
				return;
			case 4 :
				this.unsetIsSecurityEnabled();
				return;
			case 5 :
				this.setJaccPolicyClass(JACC_POLICY_CLASS_EDEFAULT);
				return;
			case 6 :
				this.setJaccPolicyConfigFactoryClass(JACC_POLICY_CONFIG_FACTORY_CLASS_EDEFAULT);
				return;
			case 7 :
				this.setJaccPrincipalToRolePolicyFileName(JACC_PRINCIPAL_TO_ROLE_POLICY_FILE_NAME_EDEFAULT);
				return;
			case 8 :
				this.setJaccPrincipalToRolePolicyId(JACC_PRINCIPAL_TO_ROLE_POLICY_ID_EDEFAULT);
				return;
			case 9 :
				this.setJaccRoleMappingClass(JACC_ROLE_MAPPING_CLASS_EDEFAULT);
				return;
			case 10 :
				this.setJaccRoleMappingConfigFactoryClass(JACC_ROLE_MAPPING_CONFIG_FACTORY_CLASS_EDEFAULT);
				return;
			case 11 :
				this.setJaccRoleToPermissionPolicyFileName(JACC_ROLE_TO_PERMISSION_POLICY_FILE_NAME_EDEFAULT);
				return;
			case 12 :
				this.setJaccRoleToPermissionPolicyId(JACC_ROLE_TO_PERMISSION_POLICY_ID_EDEFAULT);
				return;
			case 13 :
				this.unsetUseSystemJACCProvider();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.attributeGroups != null && !this.attributeGroups.isEmpty();
			case 1 :
				return DEFAULT_ATTRIBUTE_GROUP_EDEFAULT == null
						? this.defaultAttributeGroup != null
						: !DEFAULT_ATTRIBUTE_GROUP_EDEFAULT.equals(this.defaultAttributeGroup);
			case 2 :
				return this.isSetImportPolicyFromFile();
			case 3 :
				return this.isSetIsAttributeGroupingEnabled();
			case 4 :
				return this.isSetIsSecurityEnabled();
			case 5 :
				return JACC_POLICY_CLASS_EDEFAULT == null
						? this.jaccPolicyClass != null
						: !JACC_POLICY_CLASS_EDEFAULT.equals(this.jaccPolicyClass);
			case 6 :
				return JACC_POLICY_CONFIG_FACTORY_CLASS_EDEFAULT == null
						? this.jaccPolicyConfigFactoryClass != null
						: !JACC_POLICY_CONFIG_FACTORY_CLASS_EDEFAULT.equals(this.jaccPolicyConfigFactoryClass);
			case 7 :
				return JACC_PRINCIPAL_TO_ROLE_POLICY_FILE_NAME_EDEFAULT == null
						? this.jaccPrincipalToRolePolicyFileName != null
						: !JACC_PRINCIPAL_TO_ROLE_POLICY_FILE_NAME_EDEFAULT
								.equals(this.jaccPrincipalToRolePolicyFileName);
			case 8 :
				return JACC_PRINCIPAL_TO_ROLE_POLICY_ID_EDEFAULT == null
						? this.jaccPrincipalToRolePolicyId != null
						: !JACC_PRINCIPAL_TO_ROLE_POLICY_ID_EDEFAULT.equals(this.jaccPrincipalToRolePolicyId);
			case 9 :
				return JACC_ROLE_MAPPING_CLASS_EDEFAULT == null
						? this.jaccRoleMappingClass != null
						: !JACC_ROLE_MAPPING_CLASS_EDEFAULT.equals(this.jaccRoleMappingClass);
			case 10 :
				return JACC_ROLE_MAPPING_CONFIG_FACTORY_CLASS_EDEFAULT == null
						? this.jaccRoleMappingConfigFactoryClass != null
						: !JACC_ROLE_MAPPING_CONFIG_FACTORY_CLASS_EDEFAULT
								.equals(this.jaccRoleMappingConfigFactoryClass);
			case 11 :
				return JACC_ROLE_TO_PERMISSION_POLICY_FILE_NAME_EDEFAULT == null
						? this.jaccRoleToPermissionPolicyFileName != null
						: !JACC_ROLE_TO_PERMISSION_POLICY_FILE_NAME_EDEFAULT
								.equals(this.jaccRoleToPermissionPolicyFileName);
			case 12 :
				return JACC_ROLE_TO_PERMISSION_POLICY_ID_EDEFAULT == null
						? this.jaccRoleToPermissionPolicyId != null
						: !JACC_ROLE_TO_PERMISSION_POLICY_ID_EDEFAULT.equals(this.jaccRoleToPermissionPolicyId);
			case 13 :
				return this.isSetUseSystemJACCProvider();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (defaultAttributeGroup: ");
			var1.append(this.defaultAttributeGroup);
			var1.append(", importPolicyFromFile: ");
			if (this.importPolicyFromFileESet) {
				var1.append(this.importPolicyFromFile);
			} else {
				var1.append("<unset>");
			}

			var1.append(", isAttributeGroupingEnabled: ");
			if (this.isAttributeGroupingEnabledESet) {
				var1.append(this.isAttributeGroupingEnabled);
			} else {
				var1.append("<unset>");
			}

			var1.append(", isSecurityEnabled: ");
			if (this.isSecurityEnabledESet) {
				var1.append(this.isSecurityEnabled);
			} else {
				var1.append("<unset>");
			}

			var1.append(", jaccPolicyClass: ");
			var1.append(this.jaccPolicyClass);
			var1.append(", jaccPolicyConfigFactoryClass: ");
			var1.append(this.jaccPolicyConfigFactoryClass);
			var1.append(", jaccPrincipalToRolePolicyFileName: ");
			var1.append(this.jaccPrincipalToRolePolicyFileName);
			var1.append(", jaccPrincipalToRolePolicyId: ");
			var1.append(this.jaccPrincipalToRolePolicyId);
			var1.append(", jaccRoleMappingClass: ");
			var1.append(this.jaccRoleMappingClass);
			var1.append(", jaccRoleMappingConfigFactoryClass: ");
			var1.append(this.jaccRoleMappingConfigFactoryClass);
			var1.append(", jaccRoleToPermissionPolicyFileName: ");
			var1.append(this.jaccRoleToPermissionPolicyFileName);
			var1.append(", jaccRoleToPermissionPolicyId: ");
			var1.append(this.jaccRoleToPermissionPolicyId);
			var1.append(", useSystemJACCProvider: ");
			if (this.useSystemJACCProviderESet) {
				var1.append(this.useSystemJACCProvider);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}