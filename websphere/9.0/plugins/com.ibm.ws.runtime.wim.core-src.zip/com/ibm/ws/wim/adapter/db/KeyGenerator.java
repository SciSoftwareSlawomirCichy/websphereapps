package com.ibm.ws.wim.adapter.db;

import com.ibm.websphere.ce.cm.DuplicateKeyException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.dao.DataAccessObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class KeyGenerator {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private final String className = KeyGenerator.class.getName();
	private Logger keyGeneratorLog;
	private Logger keyGeneratorTrace;
	private DataAccessObject dataAccess;
	private final String dataAccessLock;

	public KeyGenerator(DataAccessObject var1) {
		this.keyGeneratorLog = WIMLogger.getMessageLogger(this.className);
		this.keyGeneratorTrace = WIMLogger.getTraceLogger(this.className);
		this.dataAccess = null;
		this.dataAccessLock = "DATA_ACCESS_LOCK";
		String var2 = "KeyGenerator";
		if (this.keyGeneratorTrace.isLoggable(Level.FINER)) {
			this.keyGeneratorTrace.entering(this.className, var2);
		}

		this.dataAccess = var1;
		if (this.keyGeneratorTrace.isLoggable(Level.FINER)) {
			this.keyGeneratorTrace.exiting(this.className, var2);
		}

	}

	public long updateKey(String var1, String var2, long var3, long var5) {
		String var7 = "updateKey";
		Connection var8 = null;
		long var9 = var3;
		boolean var11 = false;
		PreparedStatement var12 = null;
		if (this.keyGeneratorTrace.isLoggable(Level.FINER)) {
			this.keyGeneratorTrace.entering(this.className, var7, "inputQuery = \"" + var1 + "\", inputTableName = \""
					+ var2 + "\", currentInputNextValue = \"" + var3 + "\"");
		}

		while (!var11) {
			boolean var37 = false;

			String var13;
			label332 : {
				label333 : {
					label334 : {
						try {
							var37 = true;
							this.getClass();
							var13 = "DATA_ACCESS_LOCK";
							synchronized ("DATA_ACCESS_LOCK") {
								var8 = this.dataAccess.getConnection();
							}

							var12 = var8.prepareStatement(var1);
							var12.setLong(1, var9);
							var12.setString(2, var2);
							var12.executeUpdate();
							var11 = true;
							var37 = false;
							break label332;
						} catch (WIMException var49) {
							if (this.keyGeneratorLog.isLoggable(Level.WARNING)) {
								this.keyGeneratorLog.logp(Level.WARNING, this.className, var7, "",
										WIMMessageHelper.generateMsgParms(var49));
								var11 = true;
								var37 = false;
								break label334;
							}

							var37 = false;
							break label334;
						} catch (DuplicateKeyException var50) {
							var9 += var5;
							var37 = false;
							break label333;
						} catch (SQLException var51) {
							if (this.keyGeneratorLog.isLoggable(Level.WARNING)) {
								this.keyGeneratorLog.logp(Level.WARNING, this.className, var7, "",
										WIMMessageHelper.generateMsgParms(var51));
								var11 = true;
								var37 = false;
							} else {
								var37 = false;
							}
						} finally {
							if (var37) {
								if (var12 != null) {
									try {
										var12.close();
									} catch (SQLException var44) {
										if (this.keyGeneratorLog.isLoggable(Level.WARNING)) {
											this.keyGeneratorLog.logp(Level.WARNING, this.className, var7, "",
													WIMMessageHelper.generateMsgParms(var44));
										}
									}
								}

								if (var8 != null) {
									this.getClass();
									String var20 = "DATA_ACCESS_LOCK";
									synchronized ("DATA_ACCESS_LOCK") {
										this.dataAccess.closeConnection(var8);
									}
								}

							}
						}

						if (var12 != null) {
							try {
								var12.close();
							} catch (SQLException var46) {
								if (this.keyGeneratorLog.isLoggable(Level.WARNING)) {
									this.keyGeneratorLog.logp(Level.WARNING, this.className, var7, "",
											WIMMessageHelper.generateMsgParms(var46));
								}
							}
						}

						if (var8 != null) {
							this.getClass();
							var13 = "DATA_ACCESS_LOCK";
							synchronized ("DATA_ACCESS_LOCK") {
								this.dataAccess.closeConnection(var8);
							}
						}
						continue;
					}

					if (var12 != null) {
						try {
							var12.close();
						} catch (SQLException var45) {
							if (this.keyGeneratorLog.isLoggable(Level.WARNING)) {
								this.keyGeneratorLog.logp(Level.WARNING, this.className, var7, "",
										WIMMessageHelper.generateMsgParms(var45));
							}
						}
					}

					if (var8 != null) {
						this.getClass();
						var13 = "DATA_ACCESS_LOCK";
						synchronized ("DATA_ACCESS_LOCK") {
							this.dataAccess.closeConnection(var8);
						}
					}
					continue;
				}

				if (var12 != null) {
					try {
						var12.close();
					} catch (SQLException var47) {
						if (this.keyGeneratorLog.isLoggable(Level.WARNING)) {
							this.keyGeneratorLog.logp(Level.WARNING, this.className, var7, "",
									WIMMessageHelper.generateMsgParms(var47));
						}
					}
				}

				if (var8 != null) {
					this.getClass();
					var13 = "DATA_ACCESS_LOCK";
					synchronized ("DATA_ACCESS_LOCK") {
						this.dataAccess.closeConnection(var8);
					}
				}
				continue;
			}

			if (var12 != null) {
				try {
					var12.close();
				} catch (SQLException var48) {
					if (this.keyGeneratorLog.isLoggable(Level.WARNING)) {
						this.keyGeneratorLog.logp(Level.WARNING, this.className, var7, "",
								WIMMessageHelper.generateMsgParms(var48));
					}
				}
			}

			if (var8 != null) {
				this.getClass();
				var13 = "DATA_ACCESS_LOCK";
				synchronized ("DATA_ACCESS_LOCK") {
					this.dataAccess.closeConnection(var8);
				}
			}
		}

		if (this.keyGeneratorTrace.isLoggable(Level.FINER)) {
			this.keyGeneratorTrace.exiting(this.className, var7);
		}

		return var9;
	}
}