package com.ibm.bsf.util.event;

import com.ibm.bsf.util.event.generator.EventAdapterGenerator;
import java.util.Hashtable;

public class EventAdapterRegistry {
	private static Hashtable reg = new Hashtable();
	private static ClassLoader cl = null;
	private static String adapterPackage = "com.ibm.bsf.util.event.adapters";
	private static String adapterSuffix = "Adapter";
	private static boolean dynamic = true;

	public static Class lookup(Class var0) {
		String var1 = var0.getName().replace('.', '_');
		Class var2 = (Class) reg.get(var1);
		if (var2 == null) {
			String var3 = var1.substring(0, var1.lastIndexOf("Listener"));
			String var4 = adapterPackage + "." + var3 + adapterSuffix;

			try {
				var2 = cl != null ? cl.loadClass(var4) : Class.forName(var4);
			} catch (ClassNotFoundException var6) {
				if (dynamic) {
					var2 = EventAdapterGenerator.makeEventAdapterClass(var0, false);
				}
			}

			if (var2 != null) {
				reg.put(var1, var2);
			}
		}

		return var2;
	}

	public static void register(Class var0, Class var1) {
		String var2 = var0.getName().replace('.', '_');
		reg.put(var2, var1);
	}

	public static void setClassLoader(ClassLoader var0) {
		cl = var0;
	}

	public static void setDynamic(boolean var0) {
		dynamic = var0;
	}
}