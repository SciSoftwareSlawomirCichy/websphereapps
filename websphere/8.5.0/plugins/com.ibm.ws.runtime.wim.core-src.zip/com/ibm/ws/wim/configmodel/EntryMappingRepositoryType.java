package com.ibm.ws.wim.configmodel;

public interface EntryMappingRepositoryType extends RepositoryType {
	String getDatabaseType();

	void setDatabaseType(String var1);

	String getDataSourceName();

	void setDataSourceName(String var1);

	String getDbAdminId();

	void setDbAdminId(String var1);

	String getDbAdminPassword();

	void setDbAdminPassword(String var1);

	String getDbURL();

	void setDbURL(String var1);

	String getDbSchema();

	void setDbSchema(String var1);

	String getJDBCDriverClass();

	void setJDBCDriverClass(String var1);
}