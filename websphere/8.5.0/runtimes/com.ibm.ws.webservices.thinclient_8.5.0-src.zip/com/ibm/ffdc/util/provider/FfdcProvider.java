package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.Ffdc;
import com.ibm.ffdc.config.DataCollector;
import com.ibm.ffdc.config.Formattable;
import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.config.IncidentForwarder;
import com.ibm.ffdc.util.formatting.ArrayFormatter;
import com.ibm.ffdc.util.formatting.ByteArrayFormatter;
import com.ibm.ffdc.util.formatting.JavaUtilFormatter;
import com.ibm.ffdc.util.provider.IncidentEntry.Key;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class FfdcProvider implements com.ibm.ffdc.provider.FfdcProvider {
	private final List<Formatter> formatters = new ArrayList();
	private final List<DataCollector> collectors = new ArrayList();
	private final List<IncidentForwarder> incidentForwarders = new ArrayList();
	private final TreeMap<Key, IncidentEntry[]> incidents = new TreeMap();
	private final List<Incident> incidentlist = new ArrayList(10);
	private static final String LOGGER_NAME = "com.ibm.ffdc.util.provider.FfdcProvider";
	private static final Logger logger = Logger.getLogger("com.ibm.ffdc.util.provider.FfdcProvider");
	private boolean processLoggedIncidents = false;
	private int internalFailures;
	static int internalFailureLimit = 10;

	protected FfdcProvider() {
		this.formatters.add(new ByteArrayFormatter());
		this.formatters.add(new ArrayFormatter());
		this.formatters.add(new JavaUtilFormatter());
	}

	protected synchronized IncidentEntry getIncident(Key key, ClassLoader cldr) {
		IncidentEntry[] aIE = (IncidentEntry[]) this.incidents.get(key);
		if (aIE == null) {
			return this.makeIncidentEntry(key, cldr, (IncidentEntry[]) null);
		} else {
			IncidentEntry incidentEntry = aIE[0];
			if (incidentEntry.hasSameClassLoader(cldr)) {
				incidentEntry.increment();
				return incidentEntry;
			} else {
				for (int i = 1; i < aIE.length; ++i) {
					incidentEntry = aIE[i];
					if (incidentEntry.hasSameClassLoader(cldr)) {
						incidentEntry.increment();
						return incidentEntry;
					}
				}

				return this.makeIncidentEntry(key, cldr, aIE);
			}
		}
	}

	private IncidentEntry makeIncidentEntry(Key key, ClassLoader cldr, IncidentEntry[] aIE) {
		IncidentEntry ie = new IncidentEntry(key, cldr);
		IncidentEntry[] aNewIE;
		if (aIE == null) {
			aNewIE = new IncidentEntry[]{ie};
		} else {
			int oldLength = aIE.length;
			aNewIE = new IncidentEntry[oldLength + 1];
			System.arraycopy(aIE, 0, aNewIE, 0, oldLength);
			aNewIE[oldLength] = ie;
		}

		boolean addIncident = false;
		if (this.incidents.get(key) == null) {
			addIncident = true;
		}

		this.incidents.put(key, aNewIE);
		if (addIncident) {
			this.incidentlist.add(ie);
		}

		return ie;
	}

	public void removeRecursiveIncident(IncidentEntry incident) {
		Iterator iter = this.incidentlist.iterator();

		while (iter.hasNext()) {
			Incident i = (Incident) iter.next();
			if (i.getSourceId().equals(incident.getSourceId()) && i.getProbeId().equals(incident.getProbeId())
					&& i.getExceptionName().equals(incident.getExceptionName())) {
				iter.remove();
				System.out.println("removing incident");
			}
		}

	}

	public List<Incident> getIncidents() {
		return Collections.unmodifiableList(this.incidentlist);
	}

	public boolean unblockLogging(Incident incident) {
		if (incident != null && incident instanceof IncidentEntry) {
			((IncidentEntry) incident).unblockLogging();
			return true;
		} else {
			return false;
		}
	}

	public void unblockLogging() {
		List<Incident> incidentList = this.getIncidents();
		Iterator i$ = incidentList.iterator();

		while (i$.hasNext()) {
			Incident incident = (Incident) i$.next();
			this.unblockLogging(incident);
		}

	}

	protected List<Formatter> getFormatters() {
		return this.copy(this.formatters);
	}

	public void register(Formatter formatter) {
		if (logger.isLoggable(Level.FINEST)) {
			logger.logp(Level.FINEST, this.getClass().getName(), "register",
					"Registering formatter: " + this.toString(formatter));
		}

		register(this.formatters, formatter);
	}

	public void deregister(Formatter formatter) {
		if (logger.isLoggable(Level.FINEST)) {
			logger.logp(Level.FINEST, this.getClass().getName(), "deregister",
					"Deegistering formatter: " + this.toString(formatter));
		}

		deregister(this.formatters, formatter);
	}

	public List<DataCollector> getDataCollectors() {
		return this.copy(this.collectors);
	}

	public void register(DataCollector collector) {
		if (logger.isLoggable(Level.FINEST)) {
			logger.logp(Level.FINEST, this.getClass().getName(), "register",
					"Registering data collector: " + this.toString(collector));
		}

		register(this.collectors, collector);
	}

	public void deregister(DataCollector collector) {
		if (logger.isLoggable(Level.FINEST)) {
			logger.logp(Level.FINEST, this.getClass().getName(), "deregister",
					"Deregistering data collector: " + this.toString(collector));
		}

		deregister(this.collectors, collector);
	}

	public void register(IncidentForwarder processor) {
		if (logger.isLoggable(Level.FINEST)) {
			logger.logp(Level.FINEST, this.getClass().getName(), "register",
					"Registering processor: " + this.toString(processor));
		}

		register(this.incidentForwarders, processor);
	}

	public void deregister(IncidentForwarder processor) {
		if (logger.isLoggable(Level.FINEST)) {
			logger.logp(Level.FINEST, this.getClass().getName(), "deregister",
					"Deregistering processor: " + this.toString(processor));
		}

		deregister(this.incidentForwarders, processor);
	}

	protected List<IncidentForwarder> getIncidentForwarders() {
		return this.incidentForwarders;
	}

	private static <T> void register(List<T> list, T t) {
		synchronized (list) {
			if (t != null && !list.contains(t)) {
				list.add(0, t);
			}
		}
	}

	private static <T> void deregister(List<T> list, T t) {
		synchronized (list) {
			list.remove(t);
		}
	}

	private <T> List<T> copy(List<T> source) {
		synchronized (source) {
			List<T> copy = new ArrayList(source.size());
			copy.addAll(source);
			return copy;
		}
	}

	public void release() {
		this.formatters.clear();
		this.collectors.clear();
		this.incidentForwarders.clear();
	}

	protected boolean isLoggable(IncidentEntry incident) {
		boolean logIncident = incident.tag();
		if (logIncident) {
			return true;
		} else {
			if (this.incidentForwarders != null && !this.incidentForwarders.isEmpty()) {
				Iterator i$ = this.incidentForwarders.iterator();

				while (i$.hasNext()) {
					IncidentForwarder incidentFwder = (IncidentForwarder) i$.next();
					if (incidentFwder instanceof LoggedIncidentForwarder) {
						this.processLoggedIncidents = ((LoggedIncidentForwarder) incidentFwder).processLoggedIncident();
						if (this.processLoggedIncidents) {
							this.unblockLogging(incident);
							return true;
						}
					}
				}
			}

			this.processLoggedIncidents = false;
			return false;
		}
	}

	protected void log(IncidentEntry incident, Object reporter, Throwable th, Object[] cde) throws Exception {
		CapturedDataElements capturedDataElements = cde == null ? null : new CapturedDataElements(cde);
		this.log(incident, reporter, th, capturedDataElements);
	}

	protected void log(IncidentEntry incident, Object reporter, Throwable th, CapturedDataElements capturedDataElements)
			throws Exception {
		if (th == null) {
			Ffdc.log(new IllegalArgumentException(" Ffdc invoked with null throwable"), this, this.getClass().getName(),
					"log");
		} else {
			boolean logIncident = incident.tag();
			if (!logIncident && this.processLoggedIncidents) {
				if (!this.incidentForwarders.isEmpty()) {
					this.postProcessLoggedIncidents(incident, th);
				}

			} else {
				List<Formattable> data = new ArrayList(2);
				if (capturedDataElements != null) {
					data.add(capturedDataElements);
				}

				data.add(new ApplicableDataCollectors(this, th));
				this.logIncident(incident, reporter, th, data);
				if (!this.incidentForwarders.isEmpty()) {
					this.postProcess(incident, th);
				}

			}
		}
	}

	private void postProcess(IncidentEntry incident, Throwable th) {
		List<IncidentForwarder> tempList = new ArrayList(this.incidentForwarders);
		Iterator i$ = tempList.iterator();

		while (i$.hasNext()) {
			IncidentForwarder incidentForwarder = (IncidentForwarder) i$.next();

			try {
				incidentForwarder.process(incident, th);
			} catch (Exception var7) {
				this.deregister(incidentForwarder);
				Ffdc.log(var7, this, this.getClass().getName(), "306");
			}
		}

	}

	private void postProcessLoggedIncidents(IncidentEntry incident, Throwable th) {
		List<IncidentForwarder> tempList = new ArrayList(this.incidentForwarders);
		Iterator i$ = tempList.iterator();

		while (i$.hasNext()) {
			IncidentForwarder incidentForwarder = (IncidentForwarder) i$.next();
			if (incidentForwarder instanceof LoggedIncidentForwarder) {
				boolean incidentForwardable = ((LoggedIncidentForwarder) incidentForwarder).processLoggedIncident();
				if (incidentForwardable) {
					try {
						incidentForwarder.process(incident, th);
					} catch (Exception var8) {
						this.deregister(incidentForwarder);
						Ffdc.log(var8, this, this.getClass().getName(), "326");
					}
				}
			}
		}

		this.processLoggedIncidents = false;
	}

	protected void logIncident(IncidentEntry incident, Object reporter, Throwable th, List<Formattable> data)
			throws Exception {
	}

	public Ffdc getFfdc(Throwable th, Object reporter, String sourceId, String probeId) {
		return new com.ibm.ffdc.util.provider.Ffdc(th, reporter, sourceId, probeId, this);
	}

	public Ffdc getFfdc(Throwable th, Object reporter, String sourceId) {
		return this.getFfdc(th, reporter, sourceId, (String) null);
	}

	public void log(Throwable th, Object reporter, String sourceId, String probeId, Object... args) {
		Ffdc ffdc = this.getFfdc(th, reporter, sourceId, probeId);
		if (ffdc.isLoggable()) {
			ffdc.log(args);
		}

	}

	public void log(Throwable th, Object reporter, String sourceId, String probeId) {
		Ffdc ffdc = this.getFfdc(th, reporter, sourceId, probeId);
		if (ffdc.isLoggable()) {
			ffdc.log(new Object[0]);
		}

	}

	protected IncidentLogger getIncidentLogger() {
		throw new UnsupportedOperationException();
	}

	protected IncidentSummaryLogger getIncidentSummaryLogger() {
		throw new UnsupportedOperationException();
	}

	public void ffdcerror(Throwable th) {
		++this.internalFailures;
		Logger logger1 = this.logger();
		if (logger1.isLoggable(Level.INFO)) {
			logger1.log(Level.INFO, "FFDC provider error", th);
		}

		if (this.internalFailures > internalFailureLimit) {
			com.ibm.ffdc.impl.Ffdc.abort(this, th);
		}

	}

	public void abort(Throwable th) {
		com.ibm.ffdc.impl.Ffdc.abort(this, th);
	}

	private String toString(Object obj) {
		try {
			return obj.toString();
		} catch (Exception var3) {
			this.log((Throwable) var3, this, (String) "toString", (String) obj.getClass().getName());
			return "Class: " + obj.getClass().getName();
		}
	}

	public Logger logger() {
		return logger;
	}
}