package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public class ValidationHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = ValidationHelper.class.getName();

	public static void validateParam(String var0, String var1, List var2) throws WIMConfigurationException {
		boolean var4 = false;

		for (int var5 = 0; var5 < var2.size(); ++var5) {
			String var6 = (String) var2.get(var5);
			if (var6.equals(var1)) {
				var4 = true;
				break;
			}
		}

		if (!var4) {
			throw new WIMConfigurationException("CONFIG_VALUE_NOT_VALID",
					WIMMessageHelper.generateMsgParms(var1, var0, var2.toString()), Level.SEVERE, CLASSNAME,
					"validateParam");
		}
	}

	public static void validateParam(String var0, String var1, String[] var2) throws WIMConfigurationException {
		boolean var4 = false;

		for (int var5 = 0; var5 < var2.length; ++var5) {
			if (var2[var5].equals(var1)) {
				var4 = true;
				break;
			}
		}

		if (!var4) {
			throw new WIMConfigurationException("CONFIG_VALUE_NOT_VALID",
					WIMMessageHelper.generateMsgParms(var1, var0, WIMTraceHelper.printObjectArray(var2)), Level.SEVERE,
					CLASSNAME, "validateParam");
		}
	}

	public static void validateParam(String var0, int var1, List var2) throws WIMConfigurationException {
		throw new WIMConfigurationException("METHOD_NOT_IMPLEMENTED",
				WIMMessageHelper.generateMsgParms("validateParam(String paramName, int param, List values)", CLASSNAME),
				Level.SEVERE, CLASSNAME, "validateParam(String paramName, int param, List values)");
	}

	public static void validateStringInputInList(String var0, String var1, String var2, List var3, boolean var4)
			throws WIMConfigurationException {
		boolean var5 = true;
		if (var3 != null) {
			if (var3.size() == 0 && !var4) {
				var5 = false;
			} else if (var3.size() == 1) {
				String var8 = (String) var3.get(0);
				if (var8.trim().length() == 0 && !var4) {
					var5 = false;
				}
			} else {
				for (int var6 = 0; var6 < var3.size(); ++var6) {
					String var7 = (String) var3.get(var6);
					if (var7.trim().length() == 0) {
						var5 = false;
						break;
					}
				}
			}

			if (!var5) {
				throw new WIMConfigurationException("INVALID_PARAMETER_VALUE", WIMMessageHelper.generateMsgParms(var0),
						var1, var2);
			}
		}

	}

	public static void validateIntegerInput(String var0, String var1, String var2, Integer var3)
			throws WIMConfigurationException {
		if (var3 != null && var3 < 0) {
			throw new WIMConfigurationException("INVALID_PARAMETER_VALUE", WIMMessageHelper.generateMsgParms(var0),
					var1, var2);
		}
	}

	public static void validateIntegerInputPositive(String var0, String var1, String var2, Integer var3)
			throws WIMConfigurationException {
		if (var3 != null && var3 < 1) {
			throw new WIMConfigurationException("INVALID_PARAMETER_VALUE", WIMMessageHelper.generateMsgParms(var0),
					var1, var2);
		}
	}

	public static void validateRequiredDBParameters(Map var0, String var1, String var2)
			throws WIMConfigurationException {
		String var3 = (String) var0.get("dataSourceName");
		String var4 = (String) var0.get("databaseType");
		String var5 = (String) var0.get("dbURL");
		String var6 = (String) var0.get("dbAdminId");
		String var7 = (String) var0.get("dbAdminPassword");
		if (var4 != null && var4.toLowerCase().startsWith("derby")) {
			if (var3 == null || var5 == null) {
				throw new WIMConfigurationException("REQUIRED_PARAMETERS_NOT_SPECIFIED",
						WIMMessageHelper.generateMsgParms("dataSourceName,databaseType,dbURL"), Level.SEVERE, var1,
						var2);
			}
		} else if (var3 == null || var4 == null || var5 == null || var6 == null || var7 == null) {
			throw new WIMConfigurationException("REQUIRED_PARAMETERS_NOT_SPECIFIED",
					WIMMessageHelper.generateMsgParms("dataSourceName,databaseType,dbURL,dbAdminId,dbAdminPassword"),
					Level.SEVERE, var1, var2);
		}

	}
}