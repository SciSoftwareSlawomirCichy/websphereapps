package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface LdapServerConfigurationType {
	List getLdapServers();

	LdapServersType[] getLdapServersAsArray();

	LdapServersType createLdapServers();

	boolean isAllowWriteToSecondaryServers();

	void setAllowWriteToSecondaryServers(boolean var1);

	void unsetAllowWriteToSecondaryServers();

	boolean isSetAllowWriteToSecondaryServers();

	int getAttributeRangeStep();

	void setAttributeRangeStep(int var1);

	void unsetAttributeRangeStep();

	boolean isSetAttributeRangeStep();

	int getPrimaryServerQueryTimeInterval();

	void setPrimaryServerQueryTimeInterval(int var1);

	void unsetPrimaryServerQueryTimeInterval();

	boolean isSetPrimaryServerQueryTimeInterval();

	boolean isReturnToPrimaryServer();

	void setReturnToPrimaryServer(boolean var1);

	void unsetReturnToPrimaryServer();

	boolean isSetReturnToPrimaryServer();

	int getSearchCountLimit();

	void setSearchCountLimit(int var1);

	void unsetSearchCountLimit();

	boolean isSetSearchCountLimit();

	int getSearchPageSize();

	void setSearchPageSize(int var1);

	void unsetSearchPageSize();

	boolean isSetSearchPageSize();

	int getSearchTimeLimit();

	void setSearchTimeLimit(int var1);

	void unsetSearchTimeLimit();

	boolean isSetSearchTimeLimit();

	String getSslConfiguration();

	void setSslConfiguration(String var1);

	String getSslKeyStore();

	void setSslKeyStore(String var1);

	String getSslKeyStorePassword();

	void setSslKeyStorePassword(String var1);

	String getSslKeyStoreType();

	void setSslKeyStoreType(String var1);

	String getSslTrustStore();

	void setSslTrustStore(String var1);

	String getSslTrustStorePassword();

	void setSslTrustStorePassword(String var1);

	String getSslTrustStoreType();

	void setSslTrustStoreType(String var1);
}