package com.google.inject.internal.cglib.proxy;

public interface FixedValue extends Callback {
	Object loadObject() throws Exception;
}