package com.ibm.ws.ssl.core;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.websphere.ssl.JSSEHelper;
import com.ibm.ws.ssl.config.SSLConfig;
import com.ibm.ws.ssl.config.SSLConfigManager;
import com.ibm.ws.ssl.config.ThreadManager;
import com.ibm.wsspi.ssl.KeyManagerExtendedInfo;
import java.net.Socket;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.X509Certificate;
import java.util.Map;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.X509ExtendedKeyManager;
import javax.net.ssl.X509KeyManager;

public final class WSX509KeyManager extends X509ExtendedKeyManager implements X509KeyManager {
	private static final TraceComponent tc = Tr.register(WSX509KeyManager.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private KeyManagerHelper helper = null;
	private SSLConfig config = null;
	private KeyStore ks = null;
	private KeyManager[] kmList = null;
	private X509KeyManager km = null;
	private X509KeyManager customKM = null;
	private CertMappingKeyManager certMappingKeyManager = null;
	private String clientAlias = null;
	private String serverAlias = null;
	private int clientslotnum = 0;
	private int serverslotnum = 0;

	public void setClientAlias(String alias, int slotnum) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setClientAlias", new Object[]{alias, new Integer(slotnum)});
		}

		if (!this.ks.containsAlias(alias)) {
			String keyFileName = this.config.getProperty("com.ibm.ssl.keyStore");
			String tokenLibraryFile = this.config.getProperty("com.ibm.ssl.tokenLibraryFile");
			String location = keyFileName != null ? keyFileName : tokenLibraryFile;
			String message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.client.alias.not.found.CWPKI0023E",
					new Object[]{alias, location}, "Client alias " + alias + " not found in keystore.");
			Tr.error(tc, message);
			throw new IllegalArgumentException(message);
		} else {
			this.clientAlias = alias;
			this.clientslotnum = slotnum;
			if (this.customKM != null && this.customKM instanceof KeyManagerExtendedInfo) {
				((KeyManagerExtendedInfo) this.customKM).setKeyStoreClientAlias(alias);
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setClientAlias");
			}

		}
	}

	public void setServerAlias(String alias, int slotnum) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setServerAlias", new Object[]{alias, new Integer(slotnum)});
		}

		if (!this.ks.containsAlias(alias)) {
			String keyFileName = this.config.getProperty("com.ibm.ssl.keyStore");
			String tokenLibraryFile = this.config.getProperty("com.ibm.ssl.tokenLibraryFile");
			String location = keyFileName != null ? keyFileName : tokenLibraryFile;
			String message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.server.alias.not.found.CWPKI0024E",
					new Object[]{alias, location}, "Server alias " + alias + " not found in keystore.");
			Tr.error(tc, message);
			throw new IllegalArgumentException(message);
		} else {
			this.serverAlias = alias;
			this.serverslotnum = slotnum;
			if (this.customKM != null && this.customKM instanceof KeyManagerExtendedInfo) {
				((KeyManagerExtendedInfo) this.customKM).setKeyStoreServerAlias(alias);
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setServerAlias");
			}

		}
	}

	public String chooseClientAlias(String[] keyType, Principal[] issuers, Socket socket) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseClientAlias", new Object[]{keyType, issuers, socket});
		}

		try {
			if (this.customKM != null) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseClientAlias -> " + this.customKM.getClass().getName());
				}

				return this.customKM.chooseClientAlias(keyType, issuers, socket);
			} else {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseClientAlias");
				}

				return this.chooseClientAlias(keyType[0], issuers);
			}
		} catch (Throwable var5) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Caught exception in chooseClientAlias.", new Object[]{var5});
			}

			Manager.Ffdc.log(var5, this, "com.ibm.ws.ssl.core.WSX509KeyManager.chooseClientAlias", "127",
					new Object[]{this});
			if (var5 instanceof RuntimeException) {
				throw (RuntimeException) var5;
			} else {
				throw new RuntimeException(var5);
			}
		}
	}

	public String chooseServerAlias(String keyType, Principal[] issuers, Socket socket) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseServerAlias", new Object[]{keyType, issuers, socket});
		}

		try {
			if (this.customKM != null) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseServerAlias -> " + this.customKM.getClass().getName());
				}

				return this.customKM.chooseServerAlias(keyType, issuers, socket);
			} else {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseServerAlias");
				}

				return this.chooseServerAlias(keyType, issuers);
			}
		} catch (Throwable var5) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Caught exception in chooseServerAlias.", new Object[]{var5});
			}

			Manager.Ffdc.log(var5, this, "com.ibm.ws.ssl.core.WSX509KeyManager.chooseServerAlias", "161",
					new Object[]{this});
			if (var5 instanceof RuntimeException) {
				throw (RuntimeException) var5;
			} else {
				throw new RuntimeException(var5);
			}
		}
	}

	public String chooseClientAlias(String keyType, Principal[] issuers) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseClientAlias", new Object[]{keyType, issuers});
		}

		Map connectionInfo = ThreadManager.getInstance().getOutboundConnectionInfoInternal();
		if (connectionInfo != null && connectionInfo.get("com.ibm.ssl.endPointName") != null
				&& connectionInfo.get("com.ibm.ssl.endPointName").equals("IIOP")
				&& !SSLConfigManager.getInstance().isClientAuthenticationEnabled()) {
			return null;
		} else {
			String[] keyArray;
			String matchedAlias;
			String newAlias;
			if (this.clientAlias != null && !this.clientAlias.equals("")) {
				keyArray = this.km.getClientAliases(keyType, issuers);
				matchedAlias = this.helper.getAlias(this.clientAlias, keyArray);
				if (matchedAlias != null && !matchedAlias.equals("")) {
					newAlias = this.helper.normalizeAliasName(matchedAlias, this.ks);
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "chooseClientAlias  (alias name match)", new Object[]{newAlias});
					}

					return newAlias;
				} else {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "chooseClientAlias (default)", new Object[]{this.clientAlias});
					}

					return this.clientAlias;
				}
			} else {
				keyArray = new String[]{keyType};
				matchedAlias = this.km.chooseClientAlias(keyArray, issuers, (Socket) null);
				newAlias = this.helper.normalizeAliasName(matchedAlias, this.ks);
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseClientAlias (from JSSE)", new Object[]{newAlias});
				}

				return newAlias;
			}
		}
	}

	public String chooseEngineServerAlias(String keyType, Principal[] issuers, SSLEngine engine) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseEngineServerAlias", new Object[]{keyType, issuers, engine});
		}

		String rc = null;
		if (null != this.customKM && this.customKM instanceof X509ExtendedKeyManager) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "chooseEngineServerAlias, using customKM -> " + this.customKM.getClass().getName());
			}

			rc = ((X509ExtendedKeyManager) this.customKM).chooseEngineServerAlias(keyType, issuers, engine);
		} else {
			rc = this.chooseServerAlias(keyType, issuers);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "chooseEngineServerAlias");
		}

		return rc;
	}

	public String chooseEngineClientAlias(String[] keyType, Principal[] issuers, SSLEngine engine) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseEngineClientAlias", new Object[]{keyType, issuers, engine});
		}

		String rc = null;
		if (null != this.customKM && this.customKM instanceof X509ExtendedKeyManager) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "chooseEngineClientAlias, using customKM -> " + this.customKM.getClass().getName());
			}

			rc = ((X509ExtendedKeyManager) this.customKM).chooseEngineClientAlias(keyType, issuers, engine);
		} else {
			rc = this.chooseClientAlias(keyType[0], issuers);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "chooseEngineClientAlias");
		}

		return rc;
	}

	public String chooseServerAlias(String keyType, Principal[] issuers) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chooseServerAlias", new Object[]{keyType, issuers});
		}

		Map connectionInfo = JSSEHelper.getInstance().getInboundConnectionInfo();
		String certMappingFile = this.certMappingKeyManager.getProperty("com.ibm.ssl.cert.mapping.file");
		String mappedAlias = null;
		Boolean webContainerInbound = null;
		if (connectionInfo != null) {
			webContainerInbound = (Boolean) connectionInfo.get("com.ibm.ssl.isWebContainerInbound");
		}

		if (webContainerInbound != null && webContainerInbound && certMappingFile != null) {
			mappedAlias = this.certMappingKeyManager.chooseServerAlias(keyType, issuers, (Socket) null);
		}

		if (mappedAlias == null) {
			String newAlias;
			if (this.serverAlias != null && !this.serverAlias.equals("")) {
				String[] list = this.km.getServerAliases(keyType, issuers);
				newAlias = this.helper.getAlias(this.serverAlias, list);
				if (newAlias != null && !newAlias.equals("")) {
					String newAlias = this.helper.normalizeAliasName(newAlias, this.ks);
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "chooseServerAlias (alias name match)", new Object[]{newAlias});
					}

					return newAlias;
				} else {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "chooseServerAlias (default)", new Object[]{this.serverAlias});
					}

					return this.serverAlias;
				}
			} else {
				String alias = this.km.chooseServerAlias(keyType, issuers, (Socket) null);
				newAlias = this.helper.normalizeAliasName(alias, this.ks);
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chooseServerAlias (from JSSE)", new Object[]{newAlias});
				}

				return newAlias;
			}
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "chooseServerAlias", new Object[]{mappedAlias});
			}

			return mappedAlias;
		}
	}

	public String[] getClientAliases(String keyType, Principal[] issuers) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getClientAliases", new Object[]{keyType, issuers});
		}

		if (this.customKM != null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getClientAliases -> " + this.customKM.getClass().getName());
			}

			return this.customKM.getClientAliases(keyType, issuers);
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getClientAliases -> " + this.km.getClass().getName());
			}

			return this.km.getClientAliases(keyType, issuers);
		}
	}

	public String[] getServerAliases(String keyType, Principal[] issuers) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getServerAliases", new Object[]{keyType, issuers});
		}

		if (this.customKM != null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getServerAliases -> " + this.customKM.getClass().getName());
			}

			return this.customKM.getServerAliases(keyType, issuers);
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getServerAliases -> " + this.km.getClass().getName());
			}

			return this.km.getServerAliases(keyType, issuers);
		}
	}

	public PrivateKey getPrivateKey(String s) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPrivateKey", new Object[]{s});
		}

		if (this.customKM != null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getPrivateKey -> " + this.customKM.getClass().getName());
			}

			return this.customKM.getPrivateKey(s);
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getPrivateKey -> " + this.km.getClass().getName());
			}

			return this.km.getPrivateKey(s);
		}
	}

	public X509Certificate[] getCertificateChain(String s) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getCertificateChain", new Object[]{s});
		}

		if (this.customKM != null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getCertificateChain -> " + this.customKM.getClass().getName());
			}

			return this.customKM.getCertificateChain(s);
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getCertificateChain -> " + this.km.getClass().getName());
			}

			return this.km.getCertificateChain(s);
		}
	}

	public X509KeyManager getX509KeyManager() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getX509KeyManager");
		}

		if (this.customKM != null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getX509KeyManager -> " + this.customKM.getClass().getName());
			}

			return this.customKM;
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getX509KeyManager -> " + this.km.getClass().getName());
			}

			return this.km;
		}
	}

	public WSX509KeyManager(KeyStore keystore, char[] ac, KeyManagerFactory kmf, SSLConfig sslConfig,
			X509KeyManager customKeyManager)
			throws UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {
		this.helper = new KeyManagerHelper();
		this.ks = keystore;
		this.kmList = kmf.getKeyManagers();
		this.certMappingKeyManager = new CertMappingKeyManager();
		if (this.kmList != null) {
			this.km = (X509KeyManager) this.kmList[0];
		}

		this.config = sslConfig;
		this.customKM = customKeyManager;
		if (this.customKM != null && this.customKM instanceof KeyManagerExtendedInfo) {
			if (sslConfig != null) {
				((KeyManagerExtendedInfo) this.customKM).setSSLConfig(sslConfig);
			}

			KeyManager[] kmList = kmf.getKeyManagers();
			X509KeyManager defaultX509keyManager = null;
			if (kmList != null && kmList[0] != null) {
				defaultX509keyManager = (X509KeyManager) kmList[0];
			}

			if (defaultX509keyManager != null) {
				((KeyManagerExtendedInfo) this.customKM).setDefaultX509KeyManager(defaultX509keyManager);
			}

			if (keystore != null) {
				((KeyManagerExtendedInfo) this.customKM).setKeyStore(keystore);
			}
		}

	}
}