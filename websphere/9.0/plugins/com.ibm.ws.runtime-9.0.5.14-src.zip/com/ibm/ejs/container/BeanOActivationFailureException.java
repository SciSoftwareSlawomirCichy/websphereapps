package com.ibm.ejs.container;

public class BeanOActivationFailureException extends ContainerException {
	private static final long serialVersionUID = 6114931973348549639L;
}