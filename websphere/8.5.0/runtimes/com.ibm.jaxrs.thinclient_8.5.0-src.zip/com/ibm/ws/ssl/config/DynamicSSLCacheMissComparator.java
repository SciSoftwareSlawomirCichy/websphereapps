package com.ibm.ws.ssl.config;

import java.util.Comparator;

public class DynamicSSLCacheMissComparator implements Comparator {
	public int compare(Object o1, Object o2) {
		return o1.hashCode() - o2.hashCode();
	}

	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}