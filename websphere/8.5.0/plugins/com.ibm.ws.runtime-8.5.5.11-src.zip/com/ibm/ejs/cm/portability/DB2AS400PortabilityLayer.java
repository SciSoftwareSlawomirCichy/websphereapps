package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

class DB2AS400PortabilityLayer extends DB2PortabilityLayer {
	private static DB2AS400PortabilityLayer instance;
	public static Vector procs = new Vector(1, 5);
	public static Vector colls = new Vector(1, 5);
	private static final TraceComponent tc = Tr.register(DB2AS400PortabilityLayer.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	protected DB2AS400PortabilityLayer() {
		this.defaultDataSourceProps.setProperty("cursorHold", "false");
		this.defaultDataSourceProps.remove("connectionAttribute");
	}

	public void createTable(Connection connection, String schema, String name, String sql) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTable", new Object[]{connection, schema, name, sql});
		}

		Statement statement = null;
		String newSchema = schema;
		String newName = name;
		sql = sql.trim();
		if (schema.endsWith(".")) {
			newSchema = schema.substring(0, schema.length() - 1);
		}

		String tempstr = "CREATE COLLECTION";
		if (sql.toUpperCase().startsWith(tempstr)) {
			newSchema = sql.substring(tempstr.length() + 1).trim();
			if (newSchema.endsWith(".")) {
				newSchema = newSchema.substring(0, newSchema.length() - 1);
			}
		}

		String tempstr2 = "CREATE TABLE";
		String recordWaitTime;
		if (sql.toUpperCase().startsWith(tempstr2)) {
			int idx = sql.indexOf("(");
			recordWaitTime = sql.substring(tempstr2.length() + 1, idx).trim();
			int idx2 = recordWaitTime.indexOf(".");
			if (idx2 == -1) {
				newSchema = null;
				newName = recordWaitTime;
			} else {
				newSchema = recordWaitTime.substring(0, idx2);
				newName = recordWaitTime.substring(idx2 + 1);
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "schema " + newSchema + " and table name " + newName);
		}

		try {
			label809 : {
				if (!colls.contains(newSchema) && newSchema != null) {
					try {
						statement = connection.createStatement();
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "creating collection: ", newSchema);
						}

						String s = new String("CREATE COLLECTION ") + newSchema;
						statement.executeUpdate(s);
						colls.addElement(newSchema);
					} catch (SQLException var39) {
						if (var39.getErrorCode() != -601) {
							throw var39;
						}

						if (tc.isEventEnabled()) {
							Tr.event(tc, "Collection already exists", newSchema);
						}

						colls.addElement(newSchema);
					}
				}

				boolean TABLE_CREATED = false;
				boolean var32 = false;

				Statement cp;
				String library;
				String fileWaitTime;
				CallableStatement cs;
				boolean autocommit;
				label811 : {
					try {
						var32 = true;
						if (!sql.toUpperCase().startsWith("CREATE COLLECTION")) {
							statement = connection.createStatement();
							statement.executeUpdate(sql);
							if (sql.toUpperCase().startsWith("CREATE TABLE")) {
								TABLE_CREATED = true;
								var32 = false;
							} else {
								var32 = false;
							}
						} else {
							var32 = false;
						}
						break label811;
					} catch (SQLException var42) {
						if (var42.getErrorCode() != -601) {
							throw var42;
						}

						if (tc.isEventEnabled()) {
							Tr.event(tc, "table already exists", sql);
							var32 = false;
						} else {
							var32 = false;
						}
					} finally {
						if (var32) {
							if (TABLE_CREATED && newSchema != null) {
								String recordWaitTime = null;
								recordWaitTime = System.getProperty("com.ibm.ejs.dbm.RecordWaitTime");
								if (recordWaitTime == null) {
									recordWaitTime = "*SAME";
								}

								String fileWaitTime = null;
								fileWaitTime = System.getProperty("com.ibm.ejs.dbm.FileWaitTime");
								if (fileWaitTime == null) {
									fileWaitTime = "*SAME";
								}

								if (fileWaitTime.equalsIgnoreCase("*SAME")
										&& recordWaitTime.equalsIgnoreCase("*SAME")) {
									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Wait time values left at default");
									}
								} else {
									Statement cp;
									if (!procs.contains(newSchema)) {
										if (tc.isDebugEnabled()) {
											Tr.debug(tc, "Creating wait time proc for collection " + newSchema);
										}

										try {
											cp = connection.createStatement();
											String library = System.getProperty("was.install.library");
											if (library == null) {
												Tr.error(tc, "MSG_CONM_7015E");
											}

											cp.execute("CREATE PROCEDURE " + newSchema
													+ ".WAITTIME(IN :TABLENAME VARCHAR (128), IN :LIBRARY VARCHAR (10), IN :WAITTIME VARCHAR (10), IN :RWAITTIME VARCHAR (10)) LANGUAGE C NOT DETERMINISTIC CONTAINS SQL EXTERNAL NAME "
													+ library + ".QEJBCHGPF PARAMETER STYLE GENERAL");
											procs.addElement(newSchema);
										} catch (SQLException var35) {
											if (var35.getErrorCode() != -454) {
												if (tc.isEventEnabled()) {
													Tr.event(tc, "Failed to create waittime procedure.", var35);
												}

												throw var35;
											}

											if (tc.isEventEnabled()) {
												Tr.event(tc, "PROCEDURE " + newSchema + ".WAITTIME already exists");
											}

											procs.addElement(newSchema);
										}
									}

									if (tc.isDebugEnabled()) {
										Tr.debug(tc, "Setting Default File Wait Time = " + fileWaitTime);
										Tr.debug(tc, "Setting Default Record Wait Time = " + recordWaitTime);
									}

									cp = null;

									try {
										boolean autocommit = connection.getAutoCommit();
										if (tc.isDebugEnabled()) {
											Tr.debug(tc, "autocommit: " + autocommit);
										}

										if (!autocommit) {
											if (tc.isDebugEnabled()) {
												Tr.debug(tc, "commit table create");
											}

											connection.commit();
										}

										if (tc.isDebugEnabled()) {
											Tr.debug(tc, "Changing Wait Times for " + newName + " in " + newSchema);
										}

										CallableStatement cs = connection
												.prepareCall("CALL " + newSchema + ".WAITTIME (?, ?, ?, ?)");
										cs.setString(1, newName);
										cs.setString(2, newSchema);
										cs.setString(3, fileWaitTime);
										cs.setString(4, recordWaitTime);
										cs.execute();
									} catch (SQLException var34) {
										if (tc.isEventEnabled()) {
											Tr.event(tc, "exception changing wait times ...", var34);
										}

										throw var34;
									}
								}
							}

						}
					}

					if (!TABLE_CREATED || newSchema == null) {
						break label809;
					}

					recordWaitTime = null;
					recordWaitTime = System.getProperty("com.ibm.ejs.dbm.RecordWaitTime");
					if (recordWaitTime == null) {
						recordWaitTime = "*SAME";
					}

					fileWaitTime = null;
					fileWaitTime = System.getProperty("com.ibm.ejs.dbm.FileWaitTime");
					if (fileWaitTime == null) {
						fileWaitTime = "*SAME";
					}

					if (fileWaitTime.equalsIgnoreCase("*SAME") && recordWaitTime.equalsIgnoreCase("*SAME")) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Wait time values left at default");
						}
						break label809;
					}

					if (!procs.contains(newSchema)) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Creating wait time proc for collection " + newSchema);
						}

						try {
							cp = connection.createStatement();
							library = System.getProperty("was.install.library");
							if (library == null) {
								Tr.error(tc, "MSG_CONM_7015E");
							}

							cp.execute("CREATE PROCEDURE " + newSchema
									+ ".WAITTIME(IN :TABLENAME VARCHAR (128), IN :LIBRARY VARCHAR (10), IN :WAITTIME VARCHAR (10), IN :RWAITTIME VARCHAR (10)) LANGUAGE C NOT DETERMINISTIC CONTAINS SQL EXTERNAL NAME "
									+ library + ".QEJBCHGPF PARAMETER STYLE GENERAL");
							procs.addElement(newSchema);
						} catch (SQLException var40) {
							if (var40.getErrorCode() != -454) {
								if (tc.isEventEnabled()) {
									Tr.event(tc, "Failed to create waittime procedure.", var40);
								}

								throw var40;
							}

							if (tc.isEventEnabled()) {
								Tr.event(tc, "PROCEDURE " + newSchema + ".WAITTIME already exists");
							}

							procs.addElement(newSchema);
						}
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Setting Default File Wait Time = " + fileWaitTime);
						Tr.debug(tc, "Setting Default Record Wait Time = " + recordWaitTime);
					}

					cp = null;

					try {
						autocommit = connection.getAutoCommit();
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "autocommit: " + autocommit);
						}

						if (!autocommit) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "commit table create");
							}

							connection.commit();
						}

						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Changing Wait Times for " + newName + " in " + newSchema);
						}

						cs = connection.prepareCall("CALL " + newSchema + ".WAITTIME (?, ?, ?, ?)");
						cs.setString(1, newName);
						cs.setString(2, newSchema);
						cs.setString(3, fileWaitTime);
						cs.setString(4, recordWaitTime);
						cs.execute();
						break label809;
					} catch (SQLException var36) {
						if (tc.isEventEnabled()) {
							Tr.event(tc, "exception changing wait times ...", var36);
						}

						throw var36;
					}
				}

				if (TABLE_CREATED && newSchema != null) {
					recordWaitTime = null;
					recordWaitTime = System.getProperty("com.ibm.ejs.dbm.RecordWaitTime");
					if (recordWaitTime == null) {
						recordWaitTime = "*SAME";
					}

					fileWaitTime = null;
					fileWaitTime = System.getProperty("com.ibm.ejs.dbm.FileWaitTime");
					if (fileWaitTime == null) {
						fileWaitTime = "*SAME";
					}

					if (fileWaitTime.equalsIgnoreCase("*SAME") && recordWaitTime.equalsIgnoreCase("*SAME")) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Wait time values left at default");
						}
					} else {
						if (!procs.contains(newSchema)) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Creating wait time proc for collection " + newSchema);
							}

							try {
								cp = connection.createStatement();
								library = System.getProperty("was.install.library");
								if (library == null) {
									Tr.error(tc, "MSG_CONM_7015E");
								}

								cp.execute("CREATE PROCEDURE " + newSchema
										+ ".WAITTIME(IN :TABLENAME VARCHAR (128), IN :LIBRARY VARCHAR (10), IN :WAITTIME VARCHAR (10), IN :RWAITTIME VARCHAR (10)) LANGUAGE C NOT DETERMINISTIC CONTAINS SQL EXTERNAL NAME "
										+ library + ".QEJBCHGPF PARAMETER STYLE GENERAL");
								procs.addElement(newSchema);
							} catch (SQLException var41) {
								if (var41.getErrorCode() != -454) {
									if (tc.isEventEnabled()) {
										Tr.event(tc, "Failed to create waittime procedure.", var41);
									}

									throw var41;
								}

								if (tc.isEventEnabled()) {
									Tr.event(tc, "PROCEDURE " + newSchema + ".WAITTIME already exists");
								}

								procs.addElement(newSchema);
							}
						}

						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Setting Default File Wait Time = " + fileWaitTime);
							Tr.debug(tc, "Setting Default Record Wait Time = " + recordWaitTime);
						}

						cp = null;

						try {
							autocommit = connection.getAutoCommit();
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "autocommit: " + autocommit);
							}

							if (!autocommit) {
								if (tc.isDebugEnabled()) {
									Tr.debug(tc, "commit table create");
								}

								connection.commit();
							}

							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Changing Wait Times for " + newName + " in " + newSchema);
							}

							cs = connection.prepareCall("CALL " + newSchema + ".WAITTIME (?, ?, ?, ?)");
							cs.setString(1, newName);
							cs.setString(2, newSchema);
							cs.setString(3, fileWaitTime);
							cs.setString(4, recordWaitTime);
							cs.execute();
						} catch (SQLException var37) {
							if (tc.isEventEnabled()) {
								Tr.event(tc, "exception changing wait times ...", var37);
							}

							throw var37;
						}
					}
				}
			}
		} catch (SQLException var44) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "rollback connection");
			}

			try {
				connection.rollback();
			} catch (SQLException var33) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "Error rolling back connection", var33);
				}

				throw var33;
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "createTable", var44);
			}

			throw this.translateException(var44);
		}

		try {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "commit connection");
			}

			connection.commit();
		} catch (SQLException var38) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Error commit connection", var38);
			}

			throw var38;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTable");
		}

	}

	public void createTableForPersister(Connection connection, String schema, String name, String sql)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTableForPersister", new Object[]{connection, schema, name, sql});
		}

		this.createTable(connection, schema, name, sql);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTableForPersister");
		}

	}

	public static PortabilityLayer getInstance(DataSourceProperties dsProps) throws SQLException {
		if (instance == null) {
			instance = new DB2AS400PortabilityLayer();
		}

		return instance;
	}
}