package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.SearchResultsCacheType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class SearchResultsCacheTypeImpl extends EDataObjectImpl implements SearchResultsCacheType {
	protected static final int CACHE_SIZE_EDEFAULT = 2000;
	protected int cacheSize = 2000;
	protected boolean cacheSizeESet = false;
	protected static final int CACHE_TIME_OUT_EDEFAULT = 600;
	protected int cacheTimeOut = 600;
	protected boolean cacheTimeOutESet = false;
	protected static final boolean ENABLED_EDEFAULT = true;
	protected boolean enabled = true;
	protected boolean enabledESet = false;
	protected static final int SEARCH_RESULT_SIZE_LIMIT_EDEFAULT = 1000;
	protected int searchResultSizeLimit = 1000;
	protected boolean searchResultSizeLimitESet = false;
	protected static final String CACHE_DIST_POLICY_EDEFAULT = "none";
	protected String cacheDistPolicy = "none";
	protected boolean cacheDistPolicyESet = false;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getSearchResultsCacheType();
	}

	public int getCacheSize() {
		return this.cacheSize;
	}

	public void setCacheSize(int var1) {
		int var2 = this.cacheSize;
		this.cacheSize = var1;
		boolean var3 = this.cacheSizeESet;
		this.cacheSizeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.cacheSize, !var3));
		}

	}

	public void unsetCacheSize() {
		int var1 = this.cacheSize;
		boolean var2 = this.cacheSizeESet;
		this.cacheSize = 2000;
		this.cacheSizeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 0, var1, 2000, var2));
		}

	}

	public boolean isSetCacheSize() {
		return this.cacheSizeESet;
	}

	public int getCacheTimeOut() {
		return this.cacheTimeOut;
	}

	public void setCacheTimeOut(int var1) {
		int var2 = this.cacheTimeOut;
		this.cacheTimeOut = var1;
		boolean var3 = this.cacheTimeOutESet;
		this.cacheTimeOutESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.cacheTimeOut, !var3));
		}

	}

	public void unsetCacheTimeOut() {
		int var1 = this.cacheTimeOut;
		boolean var2 = this.cacheTimeOutESet;
		this.cacheTimeOut = 600;
		this.cacheTimeOutESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 1, var1, 600, var2));
		}

	}

	public boolean isSetCacheTimeOut() {
		return this.cacheTimeOutESet;
	}

	public boolean isEnabled() {
		return this.enabled;
	}

	public void setEnabled(boolean var1) {
		boolean var2 = this.enabled;
		this.enabled = var1;
		boolean var3 = this.enabledESet;
		this.enabledESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.enabled, !var3));
		}

	}

	public void unsetEnabled() {
		boolean var1 = this.enabled;
		boolean var2 = this.enabledESet;
		this.enabled = true;
		this.enabledESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 2, var1, true, var2));
		}

	}

	public boolean isSetEnabled() {
		return this.enabledESet;
	}

	public int getSearchResultSizeLimit() {
		return this.searchResultSizeLimit;
	}

	public void setSearchResultSizeLimit(int var1) {
		int var2 = this.searchResultSizeLimit;
		this.searchResultSizeLimit = var1;
		boolean var3 = this.searchResultSizeLimitESet;
		this.searchResultSizeLimitESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.searchResultSizeLimit, !var3));
		}

	}

	public void unsetSearchResultSizeLimit() {
		int var1 = this.searchResultSizeLimit;
		boolean var2 = this.searchResultSizeLimitESet;
		this.searchResultSizeLimit = 1000;
		this.searchResultSizeLimitESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 3, var1, 1000, var2));
		}

	}

	public boolean isSetSearchResultSizeLimit() {
		return this.searchResultSizeLimitESet;
	}

	public String getCacheDistPolicy() {
		return this.cacheDistPolicy;
	}

	public void setCacheDistPolicy(String var1) {
		String var2 = this.cacheDistPolicy;
		this.cacheDistPolicy = var1;
		boolean var3 = this.cacheDistPolicyESet;
		this.cacheDistPolicyESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var2, this.cacheDistPolicy, !var3));
		}

	}

	public void unsetCacheDistPolicy() {
		String var1 = this.cacheDistPolicy;
		boolean var2 = this.cacheDistPolicyESet;
		this.cacheDistPolicy = "none";
		this.cacheDistPolicyESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 4, var1, "none", var2));
		}

	}

	public boolean isSetCacheDistPolicy() {
		return this.cacheDistPolicyESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return new Integer(this.getCacheSize());
			case 1 :
				return new Integer(this.getCacheTimeOut());
			case 2 :
				return this.isEnabled() ? Boolean.TRUE : Boolean.FALSE;
			case 3 :
				return new Integer(this.getSearchResultSizeLimit());
			case 4 :
				return this.getCacheDistPolicy();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setCacheSize((Integer) var2);
				return;
			case 1 :
				this.setCacheTimeOut((Integer) var2);
				return;
			case 2 :
				this.setEnabled((Boolean) var2);
				return;
			case 3 :
				this.setSearchResultSizeLimit((Integer) var2);
				return;
			case 4 :
				this.setCacheDistPolicy((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.unsetCacheSize();
				return;
			case 1 :
				this.unsetCacheTimeOut();
				return;
			case 2 :
				this.unsetEnabled();
				return;
			case 3 :
				this.unsetSearchResultSizeLimit();
				return;
			case 4 :
				this.unsetCacheDistPolicy();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.isSetCacheSize();
			case 1 :
				return this.isSetCacheTimeOut();
			case 2 :
				return this.isSetEnabled();
			case 3 :
				return this.isSetSearchResultSizeLimit();
			case 4 :
				return this.isSetCacheDistPolicy();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (cacheSize: ");
			if (this.cacheSizeESet) {
				var1.append(this.cacheSize);
			} else {
				var1.append("<unset>");
			}

			var1.append(", cacheTimeOut: ");
			if (this.cacheTimeOutESet) {
				var1.append(this.cacheTimeOut);
			} else {
				var1.append("<unset>");
			}

			var1.append(", enabled: ");
			if (this.enabledESet) {
				var1.append(this.enabled);
			} else {
				var1.append("<unset>");
			}

			var1.append(", searchResultSizeLimit: ");
			if (this.searchResultSizeLimitESet) {
				var1.append(this.searchResultSizeLimit);
			} else {
				var1.append("<unset>");
			}

			var1.append(", cacheDistPolicy: ");
			if (this.cacheDistPolicyESet) {
				var1.append(this.cacheDistPolicy);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}