package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.openid20.util.OidUtil;
import java.io.IOException;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import org.apache.http.conn.ssl.X509HostnameVerifier;

public class OpenIDDefaultHostnameVerifier implements X509HostnameVerifier {
	private static final TraceComponent tc = Tr.register(OpenIDDefaultHostnameVerifier.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");

	public void verify(String host, SSLSocket ssl) throws IOException {
		if (tc.isEntryEnabled()) {
			Tr.event(tc, "verify(host[" + host + "], ssl[" + OidUtil.getObjState(ssl) + "])");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "verify returns");
		}

	}

	public void verify(String host, X509Certificate cert) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.event(tc, "verify(host[" + host + "], cert[" + OidUtil.getObjState(cert) + "])");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "verify returns");
		}

	}

	public void verify(String host, String[] cns, String[] subjectAlts) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.event(tc, "verify(host[" + host + "], cns[" + OidUtil.getObjState(cns) + "],subjectAlts["
					+ OidUtil.getObjState(subjectAlts) + "])");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "verify returns");
		}

	}

	public boolean verify(String hostname, SSLSession session) {
		if (tc.isEntryEnabled()) {
			Tr.event(tc, "verify(hostname[" + hostname + "], session[" + OidUtil.getObjState(session) + "])");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "verify returns [true]");
		}

		return true;
	}
}