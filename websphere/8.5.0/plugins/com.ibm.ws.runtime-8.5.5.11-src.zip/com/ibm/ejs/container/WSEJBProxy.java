package com.ibm.ejs.container;

public abstract class WSEJBProxy {
	protected EJSContainer ivContainer = null;
	protected EJSDeployedSupport ivMethodContext = null;
	protected Object ivEjbInstance = null;
}