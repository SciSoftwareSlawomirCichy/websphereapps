package com.ibm.ejs.container;

import com.ibm.ejs.container.activator.ActivationStrategy;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.J2EEName;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.Handle;

public interface HomeInternal {
	String getJNDIName(Object var1);

	J2EEName getJ2EEName();

	BeanId getId();

	EJSWrapperCommon getWrapper() throws CSIException, RemoteException;

	EJSWrapperCommon getWrapper(BeanId var1) throws CSIException, RemoteException;

	BeanO createBeanO(EJBThreadData var1, ContainerTx var2, BeanId var3) throws RemoteException;

	EJSWrapperCommon internalCreateWrapper(BeanId var1) throws CreateException, RemoteException, CSIException;

	boolean isStatelessSessionHome();

	boolean isStatefulSessionHome();

	boolean isMessageDrivenHome();

	BeanMetaData getBeanMetaData(Object var1);

	ActivationStrategy getActivationStrategy();

	String getMethodName(Object var1, int var2, boolean var3);

	String getEnterpriseBeanClassName(Object var1);

	Handle createHandle(BeanId var1) throws RemoteException;

	ClassLoader getClassLoader();

	boolean isSingletonSessionHome();
}