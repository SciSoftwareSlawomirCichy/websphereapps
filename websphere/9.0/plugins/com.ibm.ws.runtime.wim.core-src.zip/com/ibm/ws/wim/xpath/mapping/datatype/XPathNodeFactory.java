package com.ibm.ws.wim.xpath.mapping.datatype;

public interface XPathNodeFactory {
	XPathPropertyNode getPropertyNodeInstance(String var1, String var2, Object var3);

	XPathLogicalNode getLogicalNodeInstance(String var1, Object var2, Object var3);

	XPathParenthesisNode getParenNodeInstance(XPathNode var1);
}