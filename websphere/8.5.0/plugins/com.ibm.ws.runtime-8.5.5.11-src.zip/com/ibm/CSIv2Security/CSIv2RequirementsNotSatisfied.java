package com.ibm.CSIv2Security;

import org.omg.CORBA.UserException;
import org.omg.CORBA.portable.IDLEntity;

public final class CSIv2RequirementsNotSatisfied extends UserException implements IDLEntity {
	public CSIv2RequirementsNotSatisfiedReason reason = null;
	public String debugMessage = "";

	public CSIv2RequirementsNotSatisfied() {
		super(CSIv2RequirementsNotSatisfiedHelper.id());
	}

	public CSIv2RequirementsNotSatisfied(CSIv2RequirementsNotSatisfiedReason var1, String var2) {
		super(CSIv2RequirementsNotSatisfiedHelper.id());
		this.reason = var1;
		this.debugMessage = var2;
	}

	public CSIv2RequirementsNotSatisfied(String var1, CSIv2RequirementsNotSatisfiedReason var2, String var3) {
		super(CSIv2RequirementsNotSatisfiedHelper.id() + "  " + var1);
		this.reason = var2;
		this.debugMessage = var3;
	}
}