package com.ibm.bsf.util.type;

public interface TypeConvertor {
	Object convert(Class var1, Class var2, Object var3);

	String getCodeGenString();
}