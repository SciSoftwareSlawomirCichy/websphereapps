package com.ibm.ejs.container.drs.ws390;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.wsspi.cluster.Identity;
import com.ibm.wsspi.drs.DRSBootstrapMsg;
import com.ibm.wsspi.drs.DRSControllerDataXfer;
import com.ibm.wsspi.drs.DRSDataXfer;
import com.ibm.wsspi.drs.DRSInstanceToken;
import com.ibm.wsspi.drs.DRSJvmId;
import com.ibm.wsspi.drs.DRSServantProxy;
import com.ibm.wsspi.drs.exception.DRSCongestedException;
import com.ibm.wsspi.drs.exception.DRSNotReadyException;
import java.util.ArrayList;

public class SfDRSControllerDataXferImpl implements DRSControllerDataXfer {
	private static TraceComponent tc = Tr.register(SfDRSControllerDataXferImpl.class, "EJBDRSCache",
			"com.ibm.ejs.container.container");
	private static boolean _loggedVersion = false;
	private boolean usingHAManager;
	private DRSDataXfer baseDDX;
	private SfDRSControllerInstanceImpl xddci;

	public SfDRSControllerDataXferImpl(SfDRSControllerInstanceImpl ddci, boolean _usingHAManager) {
		String m = "SfDRSControllerDataXferImpl - constructor ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl - constructor ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled() && !_loggedVersion) {
			Tr.debug(tc, "SfDRSControllerDataXferImpl - constructor Version 1.12 4/24/06 21:19:28");
			_loggedVersion = true;
		}

		this.xddci = ddci;
		this.baseDDX = null;
		this.usingHAManager = _usingHAManager;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl - constructor ");
		}

	}

	public void createEntry(DRSInstanceToken token, Object entryKey, Object value)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.createEntry()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.createEntry()Entry");
		}

		if (token == null) {
			Tr.error(tc, "SFB_CONTROLLER_NULLTOKEN_CNTR0101E", "SfDRSControllerDataXferImpl.createEntry()");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.createEntry() Exit - token = null.");
			}

		} else {
			this.xddci.dcml.createEntryInServants(token, entryKey, value);
			if (this.usingHAManager) {
				if (this.xddci.isDRSAvailable()) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "SfDRSControllerDataXferImpl.createEntry() sending createEntry to DRS");
					}

					try {
						this.baseDDX.createEntry(entryKey, value);
					} catch (DRSNotReadyException var6) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.createEntry() Exception Caught.Replication Service down. createEntry failed for id "
											+ entryKey);
						}

						this.xddci.setDRSReplicationDown();
					} catch (DRSCongestedException var7) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.createEntry() Exception Caught.Replication Congested. createEntry failed for id "
											+ entryKey);
						}

						this.xddci.setDRSCongested();
					} catch (Throwable var8) {
						FFDCFilter.processException(var8,
								"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.createProp", "163", this);
						Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
								new Object[]{"SfDRSControllerDataXferImpl.createEntry()", var8});
					}
				} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfDRSControllerDataXferImpl.createEntry() DRS is not available");
				}
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerDataXferImpl.createEntry() DRS/HAManager is not being used");
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.createEntry() Exit.");
			}

		}
	}

	public void createEntryProp(DRSInstanceToken token, Object entryKey, Object propKey, Object value)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.createEntryProp()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.createEntryProp() Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.createEntryProp() Exit.");
		}

	}

	public void updateEntry(DRSInstanceToken token, Object entryKey, Object value)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.updateEntry: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.updateEntry:  Entry. ");
		}

		if (token == null) {
			Tr.error(tc, "SFB_CONTROLLER_NULLTOKEN_CNTR0101E", "SfDRSControllerDataXferImpl.updateEntry: ");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.updateEntry:  Exit - token = null.");
			}

		} else {
			this.xddci.dcml.updateEntryInServants(token, entryKey, value);
			if (this.usingHAManager) {
				if (this.xddci.isDRSAvailable()) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "SfDRSControllerDataXferImpl.updateEntry:  sending createEntry to DRS");
					}

					try {
						this.baseDDX.updateEntry(entryKey, value);
					} catch (DRSNotReadyException var6) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.updateEntry:  Exception Caught.Replication Service down. updateEntry failed for id "
											+ entryKey);
						}

						this.xddci.setDRSReplicationDown();
					} catch (DRSCongestedException var7) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.updateEntry:  Exception Caught.Replication Congested. updateEntry failed for id "
											+ entryKey);
						}

						this.xddci.setDRSCongested();
					} catch (Throwable var8) {
						FFDCFilter.processException(var8,
								"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.updateEntry", "241", this);
						Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
								new Object[]{"SfDRSControllerDataXferImpl.updateEntry: ", var8});
					}
				} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfDRSControllerDataXferImpl.updateEntry:  DRS is not available");
				}
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerDataXferImpl.updateEntry:  DRS/HAManager is not being used");
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.updateEntry:  Exit.");
			}

		}
	}

	public void updateEntryProp(DRSInstanceToken token, Object entryKey, Object propKey, Object value)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.updateEntryProp()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.updateEntryProp() Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.updateEntryProp() Exit.");
		}

	}

	public Object getEntry(DRSInstanceToken token, Object entryKey) throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.getEntry: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getEntry: ");
		}

		Object rc = null;
		if (token == null) {
			Tr.error(tc, "SFB_CONTROLLER_NULLTOKEN_CNTR0101E", "SfDRSControllerDataXferImpl.getEntry: ");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.getEntry:  Exit - token = null.");
			}

			return rc;
		} else {
			rc = this.xddci.dcml.getEntryFromServants(token, entryKey);
			if (rc == null && this.usingHAManager) {
				if (this.xddci.isDRSAvailable()) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "SfDRSControllerDataXferImpl.getEntry:  sending getEntry to DRS");
					}

					try {
						rc = this.baseDDX.getEntry(entryKey);
					} catch (DRSNotReadyException var6) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.getEntry:  Exception Caught.Replication Service down. getEntry failed for id "
											+ entryKey);
						}

						this.xddci.setDRSReplicationDown();
					} catch (DRSCongestedException var7) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.getEntry:  Exception Caught.Replication Congested. getEntry failed for id "
											+ entryKey);
						}

						this.xddci.setDRSCongested();
					} catch (Throwable var8) {
						FFDCFilter.processException(var8,
								"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.getEntry", "319", this);
						Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
								new Object[]{"SfDRSControllerDataXferImpl.getEntry: ", var8});
					}
				} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfDRSControllerDataXferImpl.getEntry:  DRS is not available");
				}
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerDataXferImpl.getEntry:  DRS/HAManager is not being used");
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.getEntry:  Exit.");
			}

			return rc;
		}
	}

	public Object getEntry(DRSInstanceToken token, Object entryKey, DRSJvmId jvmId)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.getEntry: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getEntry: ");
		}

		Object rc = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.getEntry:  Exit.");
		}

		return rc;
	}

	public Object getEntryProp(DRSInstanceToken token, Object entryKey, Object propKey)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.getEntryProp: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getEntryProp:  Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.getEntryProp:  Exit.");
		}

		return null;
	}

	public void removeEntry(DRSInstanceToken token, Object entryKey)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.removeEntry: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.removeEntry:  Entry.");
		}

		if (token == null) {
			Tr.error(tc, "SFB_CONTROLLER_NULLTOKEN_CNTR0101E", "SfDRSControllerDataXferImpl.removeEntry: ");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.removeEntry:  Exit - token = null.");
			}

		} else {
			this.xddci.dcml.removeEntryInServants(token, entryKey);
			if (this.usingHAManager) {
				if (this.xddci.isDRSAvailable()) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "SfDRSControllerDataXferImpl.removeEntry:  sending createEntry to DRS");
					}

					try {
						this.baseDDX.removeEntry(entryKey);
					} catch (DRSNotReadyException var5) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.removeEntry:  Exception Caught.Replication Service down. removeEntry failed for id "
											+ entryKey);
						}

						this.xddci.setDRSReplicationDown();
					} catch (DRSCongestedException var6) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.removeEntry:  Exception Caught.Replication Congested. removeEntry failed for id "
											+ entryKey);
						}

						this.xddci.setDRSCongested();
					} catch (Throwable var7) {
						FFDCFilter.processException(var7,
								"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.removeEntry", "417", this);
						Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
								new Object[]{"SfDRSControllerDataXferImpl.removeEntry: ", var7});
					}
				} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfDRSControllerDataXferImpl.removeEntry:  DRS is not available");
				}
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerDataXferImpl.removeEntry:  DRS/HAManager is not being used");
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.removeEntry:  Exit.");
			}

		}
	}

	public void removeEntryProp(DRSInstanceToken token, Object entryKey, Object propKey, Object value)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.removeEntryProp()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.removeEntryProp() Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.removeEntryProp() Exit.");
		}

	}

	public void removeLocalEntry(DRSInstanceToken token, Object entryKey) {
		String m = "SfDRSControllerDataXferImpl.removeLocalEntry: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.removeLocalEntry: ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.removeLocalEntry:  Exit.");
		}

	}

	public boolean entryIDExists(DRSInstanceToken token, Object entryKey)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.entryIDExists: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.entryIDExists:  Entry");
		}

		boolean rc = false;
		if (token == null) {
			Tr.error(tc, "SFB_CONTROLLER_NULLTOKEN_CNTR0101E", "SfDRSControllerDataXferImpl.entryIDExists: ");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.entryIDExists:  Exit - token = null.");
			}

			return rc;
		} else {
			rc = this.xddci.dcml.getEntryIDExistsFromServants(token, entryKey);
			if (!rc && this.usingHAManager) {
				if (this.xddci.isDRSAvailable()) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "SfDRSControllerDataXferImpl.entryIDExists:  sending entryIDExists to DRS");
					}

					try {
						rc = this.baseDDX.entryIDExists(entryKey);
					} catch (DRSNotReadyException var6) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.entryIDExists:  Exception Caught.Replication Service down. entryIDExists failed for id "
											+ entryKey);
						}

						this.xddci.setDRSReplicationDown();
					} catch (DRSCongestedException var7) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"SfDRSControllerDataXferImpl.entryIDExists:  Exception Caught.Replication Congested. entryIDExists failed for id "
											+ entryKey);
						}

						this.xddci.setDRSCongested();
					} catch (Throwable var8) {
						FFDCFilter.processException(var8,
								"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.entryIDExists", "501",
								this);
						Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
								new Object[]{"SfDRSControllerDataXferImpl.entryIDExists: ", var8});
					}
				} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfDRSControllerDataXferImpl.entryIDExists:  DRS is not available");
				}
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerDataXferImpl.entryIDExists:  DRS/HAManager is not being used");
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerDataXferImpl.entryIDExists:  Exit rc = " + rc);
			}

			return rc;
		}
	}

	public boolean entryIDExists(DRSInstanceToken token, Object entryKey, boolean substringMatch) {
		String m = "SfDRSControllerDataXferImpl.entryIDExists(): ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.entryIDExists():  Entry");
		}

		boolean rc = false;
		rc = this.xddci.dcml.getEntryIDExistsFromServants(token, entryKey);
		if (!rc && this.usingHAManager) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerDataXferImpl.entryIDExists():  sending entryIDExists to DRS");
			}

			try {
				rc = this.baseDDX.entryIDExists(entryKey, substringMatch);
			} catch (Throwable var7) {
				FFDCFilter.processException(var7,
						"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.entryIDExists", "559", this);
				Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
						new Object[]{"SfDRSControllerDataXferImpl.entryIDExists(): ", var7});
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "SfDRSControllerDataXferImpl.entryIDExists():  DRS/HAManager is not being used");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.entryIDExists():  Exit rc = " + rc);
		}

		return rc;
	}

	public void announceEntries(DRSInstanceToken token, ArrayList list)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.announceEntries()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.announceEntries() Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.announceEntries() Exit.");
		}

	}

	public DRSJvmId announceEntries(DRSInstanceToken token, ArrayList list, String servantToken)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.announceEntries()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.announceEntries() Entry. ");
		}

		DRSJvmId rc = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.announceEntries() Exit.");
		}

		return (DRSJvmId) rc;
	}

	public void renounceEntries(DRSInstanceToken token, ArrayList list)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.renounceEntries: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.renounceEntries:  Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.renounceEntries:  Exit.");
		}

	}

	public void broadcast(DRSInstanceToken token, Object key) throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.broadcast: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.broadcast:  Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.broadcast:  Exit.");
		}

	}

	public boolean isCongested(DRSInstanceToken token) {
		String m = "SfDRSControllerDataXferImpl.isCongested: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.isCongested:  Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.isCongested:  Exit.");
		}

		return false;
	}

	public boolean isReplicationUp(DRSInstanceToken token) {
		String m = "SfDRSControllerDataXferImpl.isReplicationUp: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.isReplicationUp:  Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.isReplicationUp:  Exit.");
		}

		return true;
	}

	public Identity getWLMIdentity(DRSInstanceToken token, Object entryKey, boolean forceCreation) {
		String m = "SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey,boolean): ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey,boolean):  Entry ");
		}

		Identity rc = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc,
					"SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey,boolean):  source token = " + token);
		}

		if (entryKey != null) {
			if (this.usingHAManager) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey,boolean):  sending createEntry to DRS");
				}

				try {
					rc = this.baseDDX.getWLMIdentity(entryKey, forceCreation);
				} catch (Throwable var7) {
					FFDCFilter.processException(var7,
							"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.getWLMIdentity", "727", this);
					Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
							new Object[]{"SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey,boolean): ", var7});
				}
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey,boolean):  DRS/HAManager is not being used");
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey,boolean):  Exit.");
		}

		return rc;
	}

	public Identity getWLMIdentity(DRSInstanceToken token, Object entryKey) {
		String m = "SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey): ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey):  Entry ");
		}

		Identity rc = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey):  source token = " + token);
		}

		if (entryKey != null) {
			if (this.usingHAManager) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey):  sending createEntry to DRS");
				}

				try {
					rc = this.baseDDX.getWLMIdentity(entryKey);
				} catch (Throwable var6) {
					FFDCFilter.processException(var6,
							"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.getWLMIdentity", "787", this);
					Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
							new Object[]{"SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey): ", var6});
				}
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey):  DRS/HAManager is not being used");
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.getWLMIdentity(token,entryKey):  Exit.");
		}

		return rc;
	}

	public String getInstanceName() {
		String m = "SfDRSControllerDataXferImpl.getInstanceId: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getInstanceId: ");
		}

		String rc = null;
		if (this.usingHAManager) {
			rc = this.baseDDX.getInstanceName();
		} else {
			rc = this.xddci.instanceName;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.getInstanceId:  Exit - instance name = " + rc);
		}

		return rc;
	}

	public long getInstanceId() {
		String m = "SfDRSControllerDataXferImpl.getInstanceId: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getInstanceId: ");
		}

		long rc = 0L;
		if (this.usingHAManager) {
			rc = this.baseDDX.getInstanceId();
		} else {
			rc = this.xddci.instanceId;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.getInstanceId:  Exit - instance id = " + rc);
		}

		return rc;
	}

	public long getPartition(DRSInstanceToken token, Object entryKey) {
		String m = "SfDRSControllerDataXferImpl.getPartition: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getPartition:  Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.getPartition:  Exit.");
		}

		return 0L;
	}

	public boolean shouldPull(DRSInstanceToken token, Object entryKey) {
		String m = "SfDRSControllerDataXferImpl.shouldPull()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.shouldPull() Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.shouldPull() Exit.");
		}

		return false;
	}

	public boolean isMyCopyCurrent(DRSInstanceToken drsInstanceToken, Object key) {
		String m = "SfDRSControllerDataXferImpl.isMyCopyCurrent:";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.isMyCopyCurrent: Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.isMyCopyCurrent: Exit.");
		}

		return false;
	}

	public void generateBootstrapResponse(DRSInstanceToken token, DRSBootstrapMsg dbm)
			throws DRSCongestedException, DRSNotReadyException {
		String m = "SfDRSControllerDataXferImpl.generateBootstrapResponse: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.generateBootstrapResponse: Entry.");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.generateBootstrapResponse: Exit.");
		}

	}

	public DRSDataXfer getBaseDRSDataXfer() {
		String m = "SfDRSControllerDataXferImpl.getBaseDRSDataXfer: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getBaseDRSDataXfer:  Entry. ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.getBaseDRSDataXfer:  Exit.");
		}

		return this.baseDDX;
	}

	void setBaseDDX(DRSDataXfer ddx) {
		String m = "SfDRSControllerDataXferImpl.setBaseDDX(): ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.setBaseDDX():  Entry. ");
		}

		this.baseDDX = ddx;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.setBaseDDX():  Exit.");
		}

	}

	private DRSServantProxy getProxy(DRSInstanceToken _token) {
		String m = "SfDRSControllerDataXferImpl.getProxy()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.getProxy()Entry : token = " + _token);
		}

		DRSServantProxy rc = null;
		if (_token != null) {
			try {
				rc = this.xddci.drsServantProxyFactory.createProxyForSpecificServant(_token);
			} catch (Throwable var5) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					FFDCFilter.processException(var5,
							"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.getProxy", "961", this);
					Tr.debug(tc,
							"SfDRSControllerDataXferImpl.getProxy()Caught exception while trying to create a proxy to token "
									+ _token);
					Tr.debug(tc, "SfDRSControllerDataXferImpl.getProxy()This exception is not necessarily an error.");
					Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
							new Object[]{"SfDRSControllerDataXferImpl.getProxy()", var5});
				}

				rc = null;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.getProxy()Exit - rc = " + (rc == null ? "failure" : "success"));
		}

		return rc;
	}

	private byte[] convertToBytes(Object obj) {
		String m = "SfDRSControllerDataXferImpl.convertToBytes()";
		byte[] rc = null;
		if (obj != null) {
			try {
				rc = this.xddci.drsServantProxyFactory.getByteArray(obj);
			} catch (Throwable var5) {
				FFDCFilter.processException(var5,
						"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.convertToBytes", "984", this);
				Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
						new Object[]{"SfDRSControllerDataXferImpl.convertToBytes()", var5});
				rc = null;
			}
		}

		return rc;
	}

	public void shutdownInstance(DRSInstanceToken drsInstanceToken) {
		String m = "SfDRSControllerDataXferImpl.shutdownInstance(token): ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerDataXferImpl.shutdownInstance(token):  Entry ");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "SfDRSControllerDataXferImpl.shutdownInstance(token):  source token = " + drsInstanceToken);
		}

		if (this.usingHAManager) {
			if (this.xddci.isDRSAvailable()) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"SfDRSControllerDataXferImpl.shutdownInstance(token):  Attempting to shutdown DRS instance: ");
				}

				try {
					this.baseDDX.shutdownInstance();
				} catch (Throwable var4) {
					FFDCFilter.processException(var4,
							"com.ibm.ejs.container.drs.ws390.SfDRSControllerDataXferImpl.shutdownInstance", "1038",
							this);
					Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
							new Object[]{"SfDRSControllerDataXferImpl.shutdownInstance(token): ", var4});
				}
			} else if (tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerDataXferImpl.shutdownInstance(token):  DRS is not available");
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "SfDRSControllerDataXferImpl.shutdownInstance(token):  DRS/HAManager is not being used");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerDataXferImpl.shutdownInstance(token):  Exit.");
		}

	}
}