package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap.1MapViewOfValuesAsSingletonSets;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.collect.ImmutableMap.SerializedForm;
import java.io.Serializable;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(serializable = true, emulated = true)
public abstract class ImmutableMap<K, V> implements Map<K, V>, Serializable {
	private transient ImmutableSet<Entry<K, V>> entrySet;
	private transient ImmutableSet<K> keySet;
	private transient ImmutableCollection<V> values;
	private transient ImmutableSetMultimap<K, V> multimapView;

	public static <K, V> ImmutableMap<K, V> of() {
		return ImmutableBiMap.of();
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1) {
		return ImmutableBiMap.of(k1, v1);
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2) {
		return new RegularImmutableMap(new Entry[]{entryOf(k1, v1), entryOf(k2, v2)});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		return new RegularImmutableMap(new Entry[]{entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3)});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
		return new RegularImmutableMap(new Entry[]{entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4)});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
		return new RegularImmutableMap(
				new Entry[]{entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5)});
	}

	public static <K, V> Builder<K, V> builder() {
		return new Builder();
	}

	static <K, V> Entry<K, V> entryOf(K key, V value) {
		Preconditions.checkNotNull(key, "null key in entry: null=%s", new Object[]{value});
		Preconditions.checkNotNull(value, "null value in entry: %s=null", new Object[]{key});
		return Maps.immutableEntry(key, value);
	}

	public static <K, V> ImmutableMap<K, V> copyOf(Map<? extends K, ? extends V> map) {
		if (map instanceof ImmutableMap && !(map instanceof ImmutableSortedMap)) {
			ImmutableMap<K, V> kvMap = (ImmutableMap) map;
			if (!kvMap.isPartialView()) {
				return kvMap;
			}
		} else if (map instanceof EnumMap) {
			EnumMap<?, ?> enumMap = (EnumMap) map;
			Iterator i$ = enumMap.entrySet().iterator();

			while (i$.hasNext()) {
				Entry<?, ?> entry = (Entry) i$.next();
				Preconditions.checkNotNull(entry.getKey());
				Preconditions.checkNotNull(entry.getValue());
			}

			ImmutableMap<K, V> result = ImmutableEnumMap.asImmutable(new EnumMap(enumMap));
			return result;
		}

		Entry<K, V>[] entries = (Entry[]) map.entrySet().toArray(new Entry[0]);
		switch (entries.length) {
			case 0 :
				return of();
			case 1 :
				return new SingletonImmutableBiMap(entryOf(entries[0].getKey(), entries[0].getValue()));
			default :
				for (int i = 0; i < entries.length; ++i) {
					K k = entries[i].getKey();
					V v = entries[i].getValue();
					entries[i] = entryOf(k, v);
				}

				return new RegularImmutableMap(entries);
		}
	}

	@Deprecated
	public final V put(K k, V v) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final V remove(Object o) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final void putAll(Map<? extends K, ? extends V> map) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public final void clear() {
		throw new UnsupportedOperationException();
	}

	public boolean isEmpty() {
		return this.size() == 0;
	}

	public boolean containsKey(@Nullable Object key) {
		return this.get(key) != null;
	}

	public boolean containsValue(@Nullable Object value) {
		return value != null && Maps.containsValueImpl(this, value);
	}

	public abstract V get(@Nullable Object var1);

	public ImmutableSet<Entry<K, V>> entrySet() {
		ImmutableSet<Entry<K, V>> result = this.entrySet;
		return result == null ? (this.entrySet = this.createEntrySet()) : result;
	}

	abstract ImmutableSet<Entry<K, V>> createEntrySet();

	public ImmutableSet<K> keySet() {
		ImmutableSet<K> result = this.keySet;
		return result == null ? (this.keySet = this.createKeySet()) : result;
	}

	ImmutableSet<K> createKeySet() {
		return new ImmutableMapKeySet(this);
	}

	public ImmutableCollection<V> values() {
		ImmutableCollection<V> result = this.values;
		return result == null ? (this.values = new ImmutableMapValues(this)) : result;
	}

	@Beta
	public ImmutableSetMultimap<K, V> asMultimap() {
		ImmutableSetMultimap<K, V> result = this.multimapView;
		return result == null ? (this.multimapView = this.createMultimapView()) : result;
	}

	private ImmutableSetMultimap<K, V> createMultimapView() {
		ImmutableMap<K, ImmutableSet<V>> map = this.viewMapValuesAsSingletonSets();
		return new ImmutableSetMultimap(map, map.size(), (Comparator) null);
	}

	private ImmutableMap<K, ImmutableSet<V>> viewMapValuesAsSingletonSets() {
      return new 1MapViewOfValuesAsSingletonSets(this);
   }

	public boolean equals(@Nullable Object object) {
		return Maps.equalsImpl(this, object);
	}

	abstract boolean isPartialView();

	public int hashCode() {
		return this.entrySet().hashCode();
	}

	public String toString() {
		return Maps.toStringImpl(this);
	}

	Object writeReplace() {
		return new SerializedForm(this);
	}
}