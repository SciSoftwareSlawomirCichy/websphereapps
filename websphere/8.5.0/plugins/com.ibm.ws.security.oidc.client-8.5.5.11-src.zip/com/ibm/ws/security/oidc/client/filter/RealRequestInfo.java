package com.ibm.ws.security.oidc.client.filter;

import com.ibm.ws.runtime.metadata.ComponentMetaData;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import javax.servlet.http.HttpServletRequest;

public class RealRequestInfo implements IRequestInfo {
	private static final String REFERRER = "Referer";
	private HttpServletRequest req;

	public RealRequestInfo(HttpServletRequest req) {
		this.req = req;
	}

	public String getHeader(String name) {
		return this.req.getHeader(name);
	}

	public StringBuffer getRequestURL() {
		return this.req.getRequestURL();
	}

	public String getRequestURI() {
		return this.req.getRequestURI();
	}

	public String getQueryString() {
		return this.req.getQueryString();
	}

	public String getRemoteAddr() {
		return this.req.getRemoteAddr();
	}

	public String getReferer() {
		return this.req.getParameter("Referer");
	}

	public String getApplicationName() {
		ComponentMetaData wcmd = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor().getComponentMetaData();
		String appName = null;
		if (wcmd != null) {
			appName = wcmd.getModuleMetaData().getApplicationMetaData().getName();
		}

		return appName;
	}
}