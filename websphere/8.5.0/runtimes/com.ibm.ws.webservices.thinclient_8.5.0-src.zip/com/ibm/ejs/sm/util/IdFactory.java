package com.ibm.ejs.sm.util;

import java.util.Hashtable;

public class IdFactory {
	long nextId = 1L;
	Hashtable idTable = new Hashtable();

	public long create() {
		long id = (long) (this.nextId++);
		Long idObj = new Long(id);
		this.idTable.put(idObj, idObj);
		return id;
	}

	public void remove(long id) {
		this.idTable.remove(new Long(id));
	}

	public boolean isValid(long id) {
		return this.idTable.get(new Long(id)) != null;
	}

	public void removeAll() {
		this.idTable.clear();
	}
}