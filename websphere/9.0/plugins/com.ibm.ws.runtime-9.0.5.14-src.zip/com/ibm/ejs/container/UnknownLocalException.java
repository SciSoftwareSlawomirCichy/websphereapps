package com.ibm.ejs.container;

public class UnknownLocalException extends ContainerLocalException {
	private static final long serialVersionUID = -2906017836291024122L;

	public UnknownLocalException() {
	}

	public UnknownLocalException(String message) {
		super(message);
	}

	public UnknownLocalException(String message, Exception ex) {
		super(message, ex);
	}
}