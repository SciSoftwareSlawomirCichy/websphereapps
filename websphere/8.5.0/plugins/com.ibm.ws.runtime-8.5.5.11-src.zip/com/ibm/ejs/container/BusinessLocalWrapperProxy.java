package com.ibm.ejs.container;

public class BusinessLocalWrapperProxy implements WrapperProxy {
	volatile WrapperProxyState ivState;

	public BusinessLocalWrapperProxy(WrapperProxyState state) {
		this.ivState = state;
	}

	public String toString() {
		return super.toString() + '(' + this.ivState + ')';
	}

	public int hashCode() {
		return this.ivState.hashCode();
	}

	public boolean equals(Object o) {
		return o instanceof BusinessLocalWrapperProxy && this.ivState.equals(((BusinessLocalWrapperProxy) o).ivState);
	}
}