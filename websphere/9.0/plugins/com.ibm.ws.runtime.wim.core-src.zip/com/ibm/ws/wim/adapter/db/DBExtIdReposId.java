package com.ibm.ws.wim.adapter.db;

public class DBExtIdReposId {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String extId = null;
	private String reposId = null;

	public String getExtId() {
		return this.extId;
	}

	public void setExtId(String var1) {
		this.extId = var1;
	}

	public String getReposId() {
		return this.reposId;
	}

	public void setReposId(String var1) {
		this.reposId = var1;
	}
}