package com.ibm.ejs.csi;

import com.ibm.websphere.csi.StatefulSessionKey;
import com.ibm.ws.util.UUID;

final class StatefulSessionKeyImpl implements StatefulSessionKey {
	private static final long serialVersionUID = 9171900298892460198L;
	private transient UUID ivUuid;

	public StatefulSessionKeyImpl(UUID uuid) {
		this.ivUuid = uuid;
	}

	public int hashCode() {
		return this.ivUuid != null ? this.ivUuid.hashCode() : 0;
	}

	public boolean equals(Object obj) {
		if (obj != null && obj instanceof StatefulSessionKeyImpl && this.ivUuid != null) {
			StatefulSessionKeyImpl key = (StatefulSessionKeyImpl) obj;
			return this.ivUuid.equals(key.ivUuid);
		} else {
			return false;
		}
	}

	public boolean equals(StatefulSessionKeyImpl key) {
		return key != null && this.ivUuid != null ? this.ivUuid.equals(key.ivUuid) : false;
	}

	public byte[] getBytes() {
		return this.ivUuid != null ? this.ivUuid.toByteArray() : null;
	}

	public String toString() {
		return this.ivUuid != null ? this.ivUuid.toString() : null;
	}
}