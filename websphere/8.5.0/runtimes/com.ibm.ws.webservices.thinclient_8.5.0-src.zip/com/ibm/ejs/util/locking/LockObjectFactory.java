package com.ibm.ejs.util.locking;

public interface LockObjectFactory {
	Object getNewLockObject();
}