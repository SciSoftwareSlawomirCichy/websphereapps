package com.ibm.ws.ffdc.impl;

import java.io.OutputStream;

public final class IncidentStream extends com.ibm.ffdc.util.provider.IncidentStream<FfdcProvider>
		implements
			com.ibm.ws.ffdc.IncidentStream {
	public IncidentStream(FfdcProvider provider, OutputStream os) {
		super(provider, os, new Formatters(provider), provider.getConfiguration().introspectDepth);
	}

	public void write(String text, boolean value) {
		super.writeSimple(text, value, false);
	}

	public void write(String text, byte value) {
		super.writeSimple(text, value, false);
	}

	public void write(String text, char value) {
		super.writeSimple(text, value, false);
	}

	public void write(String text, short value) {
		super.writeSimple(text, value, false);
	}

	public void write(String text, int value) {
		super.writeSimple(text, value, false);
	}

	public void write(String text, long value) {
		super.writeSimple(text, value, false);
	}

	public void write(String text, float value) {
		super.writeSimple(text, value, false);
	}

	public void write(String text, double value) {
		super.writeSimple(text, value, false);
	}

	public void write(String text, String value) {
		super.writeSimple(text, value, false);
	}

	public void introspectAndWrite(String text, Object value) {
		super.write(text, value);
	}

	public void introspectAndWrite(String text, Object value, int depth) {
		this.write(text, value, depth);
	}

	public void introspectAndWrite(String text, Object value, int depth, int maxBytes) {
		super.write(text, value);
	}

	public void writeLine(String text, boolean value) {
		super.writeSimple(text, value, true);
	}

	public void writeLine(String text, byte value) {
		super.writeSimple(text, value, true);
	}

	public void writeLine(String text, char value) {
		super.writeSimple(text, value, true);
	}

	public void writeLine(String text, short value) {
		super.writeSimple(text, value, true);
	}

	public void writeLine(String text, int value) {
		super.writeSimple(text, value, true);
	}

	public void writeLine(String text, long value) {
		super.writeSimple(text, value, true);
	}

	public void writeLine(String text, float value) {
		super.writeSimple(text, value, true);
	}

	public void writeLine(String text, double value) {
		super.writeSimple(text, value, true);
	}

	public void writeLine(String text, String value) {
		super.writeSimple(text, value, true);
	}

	public void writeLine(String text, Object value) {
		super.writeSimple(text, value, true);
	}

	public void introspectAndWriteLine(String text, Object value) {
		super.write(text, value);
	}

	public void introspectAndWriteLine(String text, Object value, int depth) {
		this.write(text, value, depth);
	}

	public void introspectAndWriteLine(String text, Object value, int depth, int maxBytes) {
		this.write(text, value, depth);
	}
}