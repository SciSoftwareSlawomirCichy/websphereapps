package com.ibm.ws.wim.security.authz;

import com.ibm.websphere.wim.copyright.IBMCopyright;

public class MessageKeys {
	static final String COPYRIGHT_NOTICE;
	public static final String PACKAGE_NAME = "com.ibm.ws.wim.security.authz";
	public static final String TRC_ACCESS_FAILURE = "Access check for principal ''{0}'' failed for the following entitlement\n    ''{1}'' ''{2}''";
	public static final String TRC_ACCESS_SUCCESS = "Access check for principal ''{0}'' succeeded for the following entitlement\n    ''{1}'' ''{2}''";
	public static final String TRC_ENTITLE_FAILURE = "Entitlement check for principal ''{0}'' failed for the following entitlement\n    ''{1}'' ''{2}''";
	public static final String TRC_ENTITLE_SUCCESS = "Entitlement check for principal ''{0}'' succeeded for the following entitlement\n    ''{1}'' ''{2}''";
	public static final String TRC_ATTR_MAPPED_GROUP = "The attribute ''{0}'' was mapped to group ''{1}'' for the access check";
	public static final String TRC_ENTITY_TYPE = "The entity ''{0}'' is of type ''{1}''";
	public static final String TRC_ENTITY_MAPPED_DAPATH = "The entity ''{0}'' was mapped to the delegated administration path ''{1}''";
	public static final String TRC_CALLER_SUBJECT = "The caller subject principal name is ''{0}''";
	public static final String TRC_IS_WAS_ADMIN = "The caller is running as the **WAS ADMINISTRATOR**";
	public static final String TRC_IS_NOT_WAS_ADMIN = "The caller is NOT running as the WAS ADMINISTRATOR";
	public static final String TRC_IS_SUPER_USER = "The caller will be granted **SUPER USER** status";
	public static final String TRC_SUPER_USER_BYPASS = "Bypassing the authorization check because the caller has **SUPER USER** status";
	public static final String TRC_SUPER_USER_FAILURE = "An error occured while performing a task as the super user";
	public static final String TRC_VMM_AUTHORIZED_USER = " The caller has ''{0}'' Access since the caller has required VMM role";
	public static final String TRC_RULE_ATTR_REQUEST = "Looking up attribute ''{0}'' for ''{1}'' to evaluate a conditional permission...";
	public static final String TRC_RULE_ATTR_RESULT = "Found attribute ''{0}''=''{1}'' for ''{2}'' to evaluate a conditional permission";

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
	}
}