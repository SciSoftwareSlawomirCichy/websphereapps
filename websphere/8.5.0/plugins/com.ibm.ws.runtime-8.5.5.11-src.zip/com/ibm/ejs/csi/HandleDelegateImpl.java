package com.ibm.ejs.csi;

import com.ibm.ejs.oa.EJSORB;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.rmi.io.IIOPOutputStream;
import com.ibm.ws.ffdc.FFDCFilter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.rmi.RemoteException;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.ejb.spi.HandleDelegate;
import javax.rmi.PortableRemoteObject;
import javax.rmi.CORBA.Stub;

public final class HandleDelegateImpl implements HandleDelegate {
	private static final TraceComponent tc = Tr.register(HandleDelegateImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.csi.HandleDelegateImpl";
	private static final String ivEJBInfoClassName = "com.ibm.ejs.container.EJBInfoImpl";
	private static final Class<?> cvEJBHomeClass = EJBHome.class;
	private static final Class<?> cvEJBObjectClass = EJBObject.class;
	private static final HandleDelegateImpl cvTheInstance = new HandleDelegateImpl();

	static HandleDelegate getInstance() {
		return cvTheInstance;
	}

	private void getConnected(Object object) throws RemoteException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isEntryEnabled() : false;
		if (entryEnabled) {
			Tr.entry(tc, "getConnected");
		}

		try {
			((Stub) object)._orb();
		} catch (Throwable var4) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "connecting EJBHome or EJBObject to ORB", object);
			}

			((Stub) object).connect(EJSORB.init());
		}

		if (entryEnabled) {
			Tr.exit(tc, "getConnected");
		}

	}

	public EJBHome readEJBHome(ObjectInputStream istream) throws IOException, ClassNotFoundException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isEntryEnabled() : false;
		boolean debugEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isDebugEnabled() : false;
		if (entryEnabled) {
			Tr.entry(tc, "readEJBHome");
		}

		Object obj = null;
		EJBHome ejbHome = null;
		obj = istream.readObject();
		if (obj == null) {
			if (debugEnabled) {
				Tr.debug(tc, "null reference read from stream");
			}
		} else {
			if (obj instanceof String) {
				if (debugEnabled) {
					Tr.debug(tc, "HD deserialize non IIOP stream for home");
				}

				if (debugEnabled) {
					Tr.debug(tc, "String is read:  " + (String) obj);
				}

				obj = EJSORB.init().string_to_object((String) obj);
				if (debugEnabled) {
					Tr.debug(tc, "HD deserialized non IIOP stream for home");
				}
			} else if (debugEnabled) {
				Tr.debug(tc, "HD deserialized IIOP stream for home");
			}

			try {
				ejbHome = (EJBHome) PortableRemoteObject.narrow(obj, cvEJBHomeClass);
				this.getConnected(ejbHome);
			} catch (RemoteException var10) {
				FFDCFilter.processException(var10, "com.ibm.ejs.csi.HandleDelegateImpl.readEJBHome", "250", this);
				if (debugEnabled) {
					Tr.debug(tc, "ERROR: readEJBHome: Could not get EJBHome reference reconnected", var10);
				}

				throw var10;
			}
		}

		if (debugEnabled) {
			try {
				Class<?> ejbInfoClass = Class.forName("com.ibm.ejs.container.EJBInfoImpl");
				Constructor<?> ejbInfoCTOR = ejbInfoClass.getConstructor(Object.class);
				Object ejbInfo = ejbInfoCTOR.newInstance(ejbHome);
				Tr.debug(tc, ejbInfo.toString());
			} catch (Throwable var9) {
				Tr.debug(tc, "Unable to dump BasicEJBInfo object due to exception:  " + var9);
			}
		}

		if (entryEnabled) {
			Tr.exit(tc, "readEJBHome");
		}

		return ejbHome;
	}

	public EJBObject readEJBObject(ObjectInputStream istream) throws IOException, ClassNotFoundException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isEntryEnabled() : false;
		boolean debugEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isDebugEnabled() : false;
		if (entryEnabled) {
			Tr.entry(tc, "readEJBObject");
		}

		Object obj = null;
		EJBObject ejbObject = null;
		obj = istream.readObject();
		if (obj == null) {
			if (debugEnabled) {
				Tr.debug(tc, "null reference read from stream");
			}
		} else {
			if (obj instanceof String) {
				if (debugEnabled) {
					Tr.debug(tc, "HD deserialize non IIOP stream for EJB");
				}

				if (debugEnabled) {
					Tr.debug(tc, "String is read:  " + (String) obj);
				}

				obj = EJSORB.init().string_to_object((String) obj);
				if (debugEnabled) {
					Tr.debug(tc, "HD deserialized non IIOP stream for EJB");
				}
			} else {
				if (debugEnabled) {
					Tr.debug(tc, "obj instance of:  " + obj.getClass().getName());
				}

				if (debugEnabled) {
					Tr.debug(tc, "HD deserialized IIOP stream for EJB");
				}
			}

			try {
				ejbObject = (EJBObject) PortableRemoteObject.narrow(obj, cvEJBObjectClass);
				this.getConnected(ejbObject);
			} catch (RemoteException var10) {
				FFDCFilter.processException(var10, "com.ibm.ejs.csi.HandleDelegateImpl.readEJBObject", "323", this);
				if (debugEnabled) {
					Tr.debug(tc, "ERROR: readEJBObject: Could not get EJBObject reference reconnected", var10);
				}

				throw var10;
			}
		}

		if (debugEnabled) {
			try {
				Class<?> ejbInfoClass = Class.forName("com.ibm.ejs.container.EJBInfoImpl");
				Constructor<?> ejbInfoCTOR = ejbInfoClass.getConstructor(Object.class);
				Object ejbInfo = ejbInfoCTOR.newInstance(ejbObject);
				Tr.debug(tc, ejbInfo.toString());
			} catch (Throwable var9) {
				Tr.debug(tc, "Unable to dump BasicEJBInfo object due to exception:  " + var9);
			}
		}

		if (entryEnabled) {
			Tr.exit(tc, "readEJBObject");
		}

		return ejbObject;
	}

	public void writeEJBHome(EJBHome ejbHome, ObjectOutputStream ostream) throws IOException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isEntryEnabled() : false;
		boolean debugEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isDebugEnabled() : false;
		if (entryEnabled) {
			Tr.entry(tc, "writeEJBHome");
		}

		if (debugEnabled) {
			Tr.debug(tc, "ostream is:  " + ostream.getClass().getName());
		}

		if (ostream instanceof IIOPOutputStream) {
			if (debugEnabled) {
				Tr.debug(tc, "HD serialize  IIOP stream for home");
			}

			ostream.writeObject(ejbHome);
			if (debugEnabled) {
				Tr.debug(tc, "HD serialized  IIOP stream for home");
			}
		} else {
			if (debugEnabled) {
				Tr.debug(tc, "HD serialize  non IIOP stream for home");
			}

			if (ejbHome == null) {
				ostream.writeObject((Object) null);
			} else {
				ostream.writeObject(EJSORB.init().object_to_string((org.omg.CORBA.Object) ejbHome));
			}

			if (debugEnabled) {
				Tr.debug(tc, "HD serialized  non IIOP stream for home");
			}
		}

		if (entryEnabled) {
			Tr.exit(tc, "writeEJBHome");
		}

	}

	public void writeEJBObject(EJBObject ejbObject, ObjectOutputStream ostream) throws IOException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isEntryEnabled() : false;
		boolean debugEnabled = TraceComponent.isAnyTracingEnabled() ? tc.isDebugEnabled() : false;
		if (entryEnabled) {
			Tr.entry(tc, "writeEJBObject");
		}

		if (debugEnabled) {
			Tr.debug(tc, "ostream class is:  " + ostream.getClass().getName());
		}

		if (ostream instanceof IIOPOutputStream) {
			if (debugEnabled) {
				Tr.debug(tc, "HD serialize IIOP stream for EJB");
			}

			ostream.writeObject(ejbObject);
			if (debugEnabled) {
				Tr.debug(tc, "HD serialized IIOP stream for EJB");
			}
		} else {
			if (debugEnabled) {
				Tr.debug(tc, "HD serialize non IIOP stream for EJB");
			}

			if (ejbObject == null) {
				ostream.writeObject((Object) null);
			} else {
				ostream.writeObject(EJSORB.init().object_to_string((org.omg.CORBA.Object) ejbObject));
			}

			if (debugEnabled) {
				Tr.debug(tc, "HD serialize non IIOP stream for EJB");
			}
		}

		if (entryEnabled) {
			Tr.exit(tc, "writeEJBObject");
		}

	}
}