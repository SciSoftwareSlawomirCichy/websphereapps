package com.ibm.ws.wim.security.authz;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.security.authz.Entitlement;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.env.IAuthorizationService;
import com.ibm.ws.wim.util.DomainManagerUtils;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.security.PrivilegedExceptionAction;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.security.auth.Subject;

public class ProfileSecurityManager {
	static final String COPYRIGHT_NOTICE;
	private static Map<String, ProfileSecurityManager> singleton;
	private IAuthorizationService authService = null;

	private ProfileSecurityManager() {
		this.authService = FactoryManager.getAuthorizationService();
	}

	public static synchronized ProfileSecurityManager singleton() {
		String var0 = DomainManagerUtils.getDomainId();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new ProfileSecurityManager());
		}

		return (ProfileSecurityManager) singleton.get(var0);
	}

	public static void clearCache(String var0) {
		singleton.put(var0, (Object) null);
	}

	public synchronized void initialize(DataGraph var1) throws WIMException {
		this.authService.initialize(var1);
	}

	public synchronized void initialize(DataGraph var1, Object var2) throws WIMException {
		this.authService.initialize(var1, var2);
	}

	public void refresh() {
		this.authService.refresh();
	}

	public void checkPermission_SuperUser(Entitlement var1) throws WIMException {
		this.authService.checkPermission_SuperUser(var1);
	}

	public boolean isCallerSuperUser() throws WIMException {
		return this.authService.isCallerSuperUser();
	}

	public void checkPermission_CREATE(EntityResource var1) throws WIMException {
		this.authService.checkPermission_CREATE(var1);
	}

	public void checkPermission_DELETE(EntityResource var1, boolean var2) throws WIMException {
		this.authService.checkPermission_DELETE(var1, var2);
	}

	public void checkPermission_UPDATE(EntityResource var1) throws WIMException {
		this.authService.checkPermission_UPDATE(var1);
	}

	public DataObject checkPermission_GET(EntityResource var1) throws WIMException {
		return this.authService.checkPermission_GET(var1);
	}

	public DataObject checkPermission_LOGIN(EntityResource var1) throws WIMException {
		return this.authService.checkPermission_LOGIN(var1);
	}

	public DataObject checkPermission_SEARCH(EntityResource var1, Entitlement var2) throws WIMException {
		return this.authService.checkPermission_SEARCH(var1, var2);
	}

	public Set getRoles(EntityResource var1) throws WIMException {
		return this.authService.getRoles(var1);
	}

	public boolean doesEntitlementExist(EntityResource var1, Entitlement var2) throws WIMException {
		return this.authService.doesEntitlementExist(var1, var2);
	}

	public Set getEntitlements(EntityResource var1, EntitlementRequest var2) throws WIMException {
		return this.authService.getEntitlements(var1, var2);
	}

	public DataObject setEntitlements(DataObject var1, DataObject var2, EntitlementRequest var3) throws WIMException {
		return this.authService.setEntitlements(var1, var2, var3);
	}

	void setRunAsSubject(Subject var1) {
		this.authService.setRunAsSubject(var1);
	}

	public Object runAsSuperUser(PrivilegedExceptionAction var1) throws WIMException {
		return this.authService.runAsSuperUser(var1);
	}

	public Object getAuthzPolicy() {
		return this.authService.getAuthzPolicy();
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		singleton = Collections.synchronizedMap(new HashMap());
	}
}