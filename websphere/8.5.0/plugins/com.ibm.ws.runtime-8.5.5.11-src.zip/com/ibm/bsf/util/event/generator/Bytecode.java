package com.ibm.bsf.util.event.generator;

public class Bytecode {
	public static final byte C_Utf8 = 1;
	public static final byte C_Integer = 3;
	public static final byte C_Float = 4;
	public static final byte C_Long = 5;
	public static final byte C_Double = 6;
	public static final byte C_Class = 7;
	public static final byte C_String = 8;
	public static final byte C_FieldRef = 9;
	public static final byte C_MethodRef = 10;
	public static final byte C_InterfaceMethodRef = 11;
	public static final byte C_NameAndType = 12;

	public static byte[] addClass(byte[] var0, short var1) {
		return addRef((byte) 7, var0, var1);
	}

	public static byte[] addFieldRef(byte[] var0, short var1, short var2) {
		return addRef((byte) 9, var0, var1, var2);
	}

	public static byte[] addInteger(byte[] var0, int var1) {
		var0 = ByteUtility.addBytes(var0, (byte) 3);
		var0 = ByteUtility.addBytes(var0, var1);
		return var0;
	}

	public static byte[] addInterfaceMethodRef(byte[] var0, short var1, short var2) {
		return addRef((byte) 11, var0, var1, var2);
	}

	public static byte[] addLong(byte[] var0, long var1) {
		var0 = ByteUtility.addBytes(var0, (byte) 5);
		var0 = ByteUtility.addBytes(var0, var1);
		return var0;
	}

	public static byte[] addMethodRef(byte[] var0, short var1, short var2) {
		return addRef((byte) 10, var0, var1, var2);
	}

	public static byte[] addNameAndType(byte[] var0, short var1, short var2) {
		return addRef((byte) 12, var0, var1, var2);
	}

	public static byte[] addRef(byte var0, byte[] var1, short var2) {
		var1 = ByteUtility.addBytes(var1, var0);
		var1 = ByteUtility.addBytes(var1, var2);
		return var1;
	}

	public static byte[] addRef(byte var0, byte[] var1, short var2, short var3) {
		var1 = ByteUtility.addBytes(var1, var0);
		var1 = ByteUtility.addBytes(var1, var2);
		var1 = ByteUtility.addBytes(var1, var3);
		return var1;
	}

	public static byte[] addString(byte[] var0, short var1) {
		return addRef((byte) 8, var0, var1);
	}

	public static byte[] addUtf8(byte[] var0, String var1) {
		var0 = ByteUtility.addBytes(var0, (byte) 1);
		var0 = ByteUtility.addBytes(var0, (short) var1.length());
		var0 = ByteUtility.addBytes(var0, var1);
		return var0;
	}
}