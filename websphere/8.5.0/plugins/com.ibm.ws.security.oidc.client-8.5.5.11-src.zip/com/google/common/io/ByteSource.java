package com.google.common.io;

import com.google.common.base.Preconditions;
import com.google.common.hash.Funnels;
import com.google.common.hash.HashCode;
import com.google.common.hash.HashFunction;
import com.google.common.hash.Hasher;
import com.google.common.io.ByteSource.1;
import com.google.common.io.ByteSource.AsCharSource;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Arrays;

public abstract class ByteSource {
	private static final int BUF_SIZE = 4096;
	private static final byte[] countBuffer = new byte[4096];

	public CharSource asCharSource(Charset charset) {
      return new AsCharSource(this, charset, (1)null);
   }

	public abstract InputStream openStream() throws IOException;

	public BufferedInputStream openBufferedStream() throws IOException {
		InputStream in = this.openStream();
		return in instanceof BufferedInputStream ? (BufferedInputStream) in : new BufferedInputStream(in);
	}

	public ByteSource slice(long offset, long length) {
      return new ByteSource.SlicedByteSource(offset, length, (1)null);
   }

	public long size() throws IOException {
		Closer closer = Closer.create();

		InputStream in;
		long var3;
		try {
			in = (InputStream) closer.register(this.openStream());
			var3 = this.countBySkipping(in);
			return var3;
		} catch (IOException var17) {
			;
		} finally {
			closer.close();
		}

		closer = Closer.create();

		try {
			in = (InputStream) closer.register(this.openStream());
			var3 = this.countByReading(in);
		} catch (Throwable var15) {
			throw closer.rethrow(var15);
		} finally {
			closer.close();
		}

		return var3;
	}

	private long countBySkipping(InputStream in) throws IOException {
		long count = 0L;

		while (true) {
			while (true) {
				long skipped = in.skip((long) Math.min(in.available(), Integer.MAX_VALUE));
				if (skipped <= 0L) {
					if (in.read() == -1) {
						return count;
					}

					++count;
				} else {
					count += skipped;
				}
			}
		}
	}

	private long countByReading(InputStream in) throws IOException {
		long count;
		long read;
		for (count = 0L; (read = (long) in.read(countBuffer)) != -1L; count += read) {
			;
		}

		return count;
	}

	public long copyTo(OutputStream output) throws IOException {
		Preconditions.checkNotNull(output);
		Closer closer = Closer.create();

		long var4;
		try {
			InputStream in = (InputStream) closer.register(this.openStream());
			var4 = ByteStreams.copy(in, output);
		} catch (Throwable var9) {
			throw closer.rethrow(var9);
		} finally {
			closer.close();
		}

		return var4;
	}

	public long copyTo(ByteSink sink) throws IOException {
		Preconditions.checkNotNull(sink);
		Closer closer = Closer.create();

		long var5;
		try {
			InputStream in = (InputStream) closer.register(this.openStream());
			OutputStream out = (OutputStream) closer.register(sink.openStream());
			var5 = ByteStreams.copy(in, out);
		} catch (Throwable var10) {
			throw closer.rethrow(var10);
		} finally {
			closer.close();
		}

		return var5;
	}

	public byte[] read() throws IOException {
		Closer closer = Closer.create();

		byte[] var3;
		try {
			InputStream in = (InputStream) closer.register(this.openStream());
			var3 = ByteStreams.toByteArray(in);
		} catch (Throwable var7) {
			throw closer.rethrow(var7);
		} finally {
			closer.close();
		}

		return var3;
	}

	public HashCode hash(HashFunction hashFunction) throws IOException {
		Hasher hasher = hashFunction.newHasher();
		this.copyTo(Funnels.asOutputStream(hasher));
		return hasher.hash();
	}

	public boolean contentEquals(ByteSource other) throws IOException {
		Preconditions.checkNotNull(other);
		byte[] buf1 = new byte[4096];
		byte[] buf2 = new byte[4096];
		Closer closer = Closer.create();

		try {
			InputStream in1 = (InputStream) closer.register(this.openStream());
			InputStream in2 = (InputStream) closer.register(other.openStream());

			int read1;
			boolean var9;
			do {
				read1 = ByteStreams.read(in1, buf1, 0, 4096);
				int read2 = ByteStreams.read(in2, buf2, 0, 4096);
				if (read1 != read2 || !Arrays.equals(buf1, buf2)) {
					var9 = false;
					return var9;
				}
			} while (read1 == 4096);

			var9 = true;
			return var9;
		} catch (Throwable var13) {
			throw closer.rethrow(var13);
		} finally {
			closer.close();
		}
	}

	private final class SlicedByteSource extends ByteSource {
		private final long offset;
		private final long length;

		private SlicedByteSource(long offset, long length) {
			Preconditions.checkArgument(offset >= 0L, "offset (%s) may not be negative", new Object[]{offset});
			Preconditions.checkArgument(length >= 0L, "length (%s) may not be negative", new Object[]{length});
			this.offset = offset;
			this.length = length;
		}

		public InputStream openStream() throws IOException {
			InputStream in = ByteSource.this.openStream();
			if (this.offset > 0L) {
				try {
					ByteStreams.skipFully(in, this.offset);
				} catch (Throwable var8) {
					Throwable e = var8;
					Closer closer = Closer.create();
					closer.register(in);

					try {
						throw closer.rethrow(e);
					} finally {
						closer.close();
					}
				}
			}

			return ByteStreams.limit(in, this.length);
		}

		public ByteSource slice(long offset, long length) {
			Preconditions.checkArgument(offset >= 0L, "offset (%s) may not be negative", new Object[]{offset});
			Preconditions.checkArgument(length >= 0L, "length (%s) may not be negative", new Object[]{length});
			long maxLength = this.length - offset;
			return ByteSource.this.slice(this.offset + offset, Math.min(length, maxLength));
		}

		public String toString() {
			return ByteSource.this.toString() + ".slice(" + this.offset + ", " + this.length + ")";
		}
	}
}