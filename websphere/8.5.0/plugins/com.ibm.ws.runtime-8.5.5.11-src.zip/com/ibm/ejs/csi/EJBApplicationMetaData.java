package com.ibm.ejs.csi;

import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.ContainerProperties;
import com.ibm.ejs.container.EJBNotFoundException;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSHome;
import com.ibm.ejs.container.HomeRecord;
import com.ibm.ejs.container.TimerNp;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.ejbcontainer.AmbiguousEJBReferenceException;
import com.ibm.websphere.ejbcontainer.ApplicationNotStartedException;
import com.ibm.websphere.ejbcontainer.EJBStoppedException;
import com.ibm.ws.ejbcontainer.runtime.EJBApplicationEventListener;
import com.ibm.ws.exception.RuntimeWarning;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.metadata.ApplicationMetaData;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class EJBApplicationMetaData {
	private static final String CLASS_NAME = EJBApplicationMetaData.class.getName();
	private static final TraceComponent tc;
	private final EJSContainer ivContainer;
	private final String ivName;
	private final String ivLogicalName;
	private final boolean ivStandaloneModule;
	private final ApplicationMetaData ivApplicationMetaData;
	private final Set<EJBModuleMetaDataImpl> ivModules = new LinkedHashSet();
	private volatile boolean ivCurrentlyBlockingWork;
	private boolean ivBlockWorkUntilStarted;
	private Thread ivStartupThread;
	private boolean ivBindToServerRoot = true;
	private boolean ivBindToJavaGlobal = true;
	private boolean ivCheckConfig;
	private boolean ivIndirectLocalProxies;
	private List<J2EEName> ivStartupSingletonList;
	private LinkedHashMap<BeanMetaData, Set<String>> ivSingletonDependencies;
	private RuntimeWarning ivSingletonDependencyResolutionException;
	private LinkedHashSet<EJSHome> ivSingletonInitializations;
	private List<TimerNp> ivQueuedNonPersistentTimers;
	private boolean ivStopping;
	private EJBModuleMetaDataImpl ivModuleBeingAddedLate = null;

	public EJBApplicationMetaData(EJSContainer container, String name, String logicalName, boolean standaloneModule,
			ApplicationMetaData amd, boolean started, boolean blockWorkUntilStarted) {
		this.ivContainer = container;
		this.ivName = name;
		this.ivLogicalName = logicalName;
		this.ivStandaloneModule = standaloneModule;
		this.ivApplicationMetaData = amd;
		this.ivBlockWorkUntilStarted = blockWorkUntilStarted;
		if (!started) {
			this.ivCurrentlyBlockingWork = this.ivBlockWorkUntilStarted;
			this.ivStartupThread = Thread.currentThread();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "EJBApplicationMetaData object created for thread: " + this.ivStartupThread
					+ ", blockWorkUntilStarted=" + blockWorkUntilStarted);
		}

	}

	public String getName() {
		return this.ivName;
	}

	public String getLogicalName() {
		return this.ivLogicalName;
	}

	public boolean isStandaloneModule() {
		return this.ivStandaloneModule;
	}

	public ApplicationMetaData getApplicationMetaData() {
		return this.ivApplicationMetaData;
	}

	public void setBindToServerRoot(boolean bind) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setBindToServerRoot: " + bind);
		}

		this.ivBindToServerRoot = bind;
	}

	public boolean isBindToServerRoot() {
		return this.ivBindToServerRoot;
	}

	public void setBindToJavaGlobal(boolean bind) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setBindToJavaGlobal: " + bind);
		}

		this.ivBindToJavaGlobal = bind;
	}

	public boolean isBindToJavaGlobal() {
		return this.ivBindToJavaGlobal;
	}

	public void setCheckConfig(boolean checkConfig) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setCheckConfig: " + checkConfig);
		}

		this.ivCheckConfig = checkConfig;
	}

	public boolean isCheckConfig() {
		return this.ivCheckConfig;
	}

	public void setIndirectLocalProxies(boolean indirectLocalProxies) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setIndirectLocalProxies: " + indirectLocalProxies);
		}

		this.ivIndirectLocalProxies = indirectLocalProxies;
	}

	public boolean isIndirectLocalProxies() {
		return this.ivIndirectLocalProxies;
	}

	public void addSingleton(BeanMetaData bmd, boolean startup, Set<String> dependsOnLinks) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "addSingleton: " + bmd.j2eeName + " (startup=" + startup + ", dependsOn="
					+ (dependsOnLinks != null) + ")");
		}

		if (startup) {
			if (this.ivStartupSingletonList == null) {
				this.ivStartupSingletonList = new ArrayList();
			}

			this.ivStartupSingletonList.add(bmd.j2eeName);
		}

		if (dependsOnLinks != null) {
			if (this.ivSingletonDependencies == null) {
				this.ivSingletonDependencies = new LinkedHashMap();
			}

			this.ivSingletonDependencies.put(bmd, dependsOnLinks);
		}

	}

	public boolean checkIfEJBWorkAllowed(EJBModuleMetaDataImpl module) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (!this.ivCurrentlyBlockingWork) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkIfEJBWorkAllowed: " + module.getJ2EEName() + ": not blocking work");
			}

			return true;
		} else {
			EJBModuleMetaDataImpl moduleBeingAddedLate;
			synchronized (this) {
				if (!this.ivCurrentlyBlockingWork) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "checkIfEJBWorkAllowed: " + module.getJ2EEName() + ": not blocking work");
					}

					return true;
				}

				if (this.ivStartupThread == Thread.currentThread()) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "checkIfEJBWorkAllowed: " + module.getJ2EEName() + ": allowing startup thread");
					}

					return false;
				}

				moduleBeingAddedLate = this.ivModuleBeingAddedLate;
				if (moduleBeingAddedLate != null && moduleBeingAddedLate != module) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc,
								"checkIfEJBWorkAllowed: " + module.getJ2EEName() + ": allowing non-late-add module");
					}

					return true;
				}

				long end = System.currentTimeMillis() + ContainerProperties.BlockWorkUntilAppStartedWaitTime;
				if (end < 0L) {
					end = Long.MAX_VALUE;
				}

				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"checkIfEJBWorkAllowed: " + module.getJ2EEName() + ": waiting for application to start");
				}

				while (this.ivCurrentlyBlockingWork
						&& (moduleBeingAddedLate == null || moduleBeingAddedLate == this.ivModuleBeingAddedLate)) {
					try {
						long waitTime = end - System.currentTimeMillis();
						if (waitTime <= 0L) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "checkIfEJBWorkAllowed: wait timed out");
							}

							if (moduleBeingAddedLate != null) {
								throw new ApplicationNotStartedException("module " + module.getName()
										+ " in application " + this.ivName + " has not finished startup processing");
							}

							throw new ApplicationNotStartedException(
									"application " + this.ivName + " has not finished startup processing");
						}

						this.wait(waitTime);
					} catch (InterruptedException var10) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "checkIfEJBWorkAllowed: wait interrupted");
						}

						FFDCFilter.processException(var10, CLASS_NAME + ".checkIfEJBWorkAllowed", "360", this);
						Thread.currentThread().interrupt();
					}
				}
			}

			if (moduleBeingAddedLate != null && moduleBeingAddedLate.ivStopping) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkIfEJBWorkAllowed: module failed to start");
				}

				throw new EJBStoppedException(
						"module " + module.getName() + " in application " + this.ivName + " failed to start");
			} else if (this.ivStopping) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkIfEJBWorkAllowed: application failed to start");
				}

				throw new EJBStoppedException("application " + this.ivName + " failed to start");
			} else {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkIfEJBWorkAllowed: application started");
				}

				return true;
			}
		}
	}

	public synchronized void checkIfCreateNonPersistentTimerAllowed(EJBModuleMetaDataImpl mmd) {
		if (this.ivStopping) {
			throw new EJBStoppedException(this.ivName);
		} else if (mmd != null && mmd.ivStopping) {
			throw new EJBStoppedException(mmd.getJ2EEName().toString());
		}
	}

	public synchronized void startingModule(EJBModuleMetaDataImpl mmd, boolean blockWorkUntilStarted) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "startingModule: " + mmd.getJ2EEName() + ", blockWorkUntilStarted=" + blockWorkUntilStarted
					+ ", started=" + this.isStarted());
		}

		this.ivModules.add(mmd);
		if (this.isStarted()) {
			this.ivModuleBeingAddedLate = mmd;
			this.ivStartupThread = Thread.currentThread();
			this.ivBlockWorkUntilStarted |= blockWorkUntilStarted;
			this.ivCurrentlyBlockingWork = this.ivBlockWorkUntilStarted;
		}

	}

	private void finishStarting() throws RuntimeWarning {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "finishStarting: " + this.ivName);
		}

		if (this.ivModules != null) {
			this.notifyApplicationEventListeners(this.ivModules, true);
		}

		this.unblockThreadsWaitingForStart();
		synchronized (this) {
			if (this.ivQueuedNonPersistentTimers != null) {
				this.startQueuedNonPersistentTimerAlarms();
				this.ivQueuedNonPersistentTimers = null;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "finishStarting");
		}

	}

	public void startedModule(EJBModuleMetaDataImpl mmd) throws RuntimeWarning {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "startedModule: " + mmd.getJ2EEName());
		}

		if (this.ivSingletonDependencies != null) {
			this.resolveDependencies();
			this.ivSingletonDependencies = null;
		}

		if (this.ivStartupSingletonList != null) {
			this.createStartupBeans();
			this.ivStartupSingletonList = null;
		}

		if (this.ivModuleBeingAddedLate == mmd) {
			this.finishStarting();
		}

	}

	public void started() throws RuntimeWarning {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "started");
		}

		this.finishStarting();
	}

	private synchronized void unblockThreadsWaitingForStart() {
		this.ivStartupThread = null;
		this.ivModuleBeingAddedLate = null;
		this.ivCurrentlyBlockingWork = false;
		this.notifyAll();
	}

	private HomeRecord resolveEJBLink(J2EEName source, String link) throws RuntimeWarning {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "resolveEJBLink: " + link);
		}

		String module = source.getModule();
		String component = source.getComponent();

		HomeRecord result;
		try {
			result = EJSContainer.homeOfHomes.resolveEJBLink(source.getApplication(), module, link);
		} catch (EJBNotFoundException var8) {
			Tr.error(tc, "SINGLETON_DEPENDS_ON_NONEXISTENT_BEAN_CNTR0198E", new Object[]{component, module, link});
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "resolveEJBLink");
			}

			throw new RuntimeWarning("CNTR0198E: The " + component + " singleton session bean in the " + module
					+ " module depends on " + link + ", which does not exist.", var8);
		} catch (AmbiguousEJBReferenceException var9) {
			Tr.error(tc, "SINGLETON_DEPENDS_ON_AMBIGUOUS_NAME_CNTR0199E", new Object[]{component, module, link});
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "resolveEJBLink");
			}

			throw new RuntimeWarning("CNTR0199E: The " + component + " singleton session bean in the " + module
					+ " module depends on " + link + ", which does not uniquely specify an enterprise bean.", var9);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "resolveEJBLink: " + result);
		}

		return result;
	}

	private void resolveDependencies() throws RuntimeWarning {
		if (EJSPlatformHelper.isZOSCRA()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "resolveDependencies: skipped in adjunct process");
			}

		} else if (this.ivSingletonDependencyResolutionException != null) {
			throw this.ivSingletonDependencyResolutionException;
		} else {
			Set<BeanMetaData> used = new HashSet();
			Iterator i$ = (new ArrayList(this.ivSingletonDependencies.keySet())).iterator();

			while (i$.hasNext()) {
				BeanMetaData bmd = (BeanMetaData) i$.next();
				used.add(bmd);
				this.resolveBeanDependencies(bmd, used);
				used.remove(bmd);
			}

		}
	}

	private void resolveBeanDependencies(BeanMetaData bmd, Set<BeanMetaData> used) throws RuntimeWarning {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "resolveBeanDependencies: " + bmd.j2eeName);
		}

		if (bmd.ivDependsOn == null) {
			bmd.ivDependsOn = new ArrayList();
			Set<String> dependsOnLinks = (Set) this.ivSingletonDependencies.remove(bmd);
			if (dependsOnLinks != null) {
				Iterator i$ = dependsOnLinks.iterator();

				while (i$.hasNext()) {
					String dependencyLink = (String) i$.next();
					HomeRecord hr = this.resolveEJBLink(bmd.j2eeName, dependencyLink);
					BeanMetaData dependency = hr.getBeanMetaData();
					J2EEName dependencyName = dependency.j2eeName;
					if (!dependency.isSingletonSessionBean()) {
						Tr.error(tc, "SINGLETON_DEPENDS_ON_NON_SINGLETON_BEAN_CNTR0200E",
								new Object[]{bmd.j2eeName.getComponent(), bmd.j2eeName.getModule(),
										dependencyName.getComponent(), dependencyName.getModule()});
						throw new RuntimeWarning("CNTR0200E: The " + bmd.j2eeName.getComponent()
								+ " singleton session bean in the " + bmd.j2eeName.getModule()
								+ " module depends on the " + dependencyName.getComponent() + " enterprise bean in the "
								+ dependencyName.getModule() + ", but the target is not a singleton session bean.");
					}

					if (!used.add(dependency)) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "circular dependency from " + dependencyName);
						}

						Tr.error(tc, "SINGLETON_DEPENDS_ON_SELF_CNTR0201E",
								new Object[]{dependencyName.getComponent(), dependencyName.getModule()});
						throw new RuntimeWarning("CNTR0201E: The " + dependencyName.getComponent()
								+ " singleton session bean in the " + dependencyName.getModule()
								+ " module directly or indirectly depends on itself.");
					}

					bmd.ivDependsOn.add(dependencyName);
					this.resolveBeanDependencies(dependency, used);
					used.remove(dependency);
				}

				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "resolveBeanDependencies: " + bmd.j2eeName);
				}

			}
		}
	}

	public List<J2EEName> resolveBeanDependencies(BeanMetaData bmd) throws RuntimeWarning {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "resolveBeanDependencies: " + bmd.j2eeName);
		}

		if (bmd.ivDependsOn == null && this.ivSingletonDependencies != null) {
			Set<BeanMetaData> used = new HashSet();
			used.add(bmd);

			try {
				this.resolveBeanDependencies(bmd, used);
			} catch (RuntimeWarning var5) {
				this.ivSingletonDependencyResolutionException = var5;
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "resolveBeanDependencies: " + var5);
				}

				throw var5;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "resolveBeanDependencies: " + bmd.ivDependsOn);
		}

		return bmd.ivDependsOn;
	}

	private void createStartupBeans() throws RuntimeWarning {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (EJSPlatformHelper.isZOSCRA()) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "createStartupBeans: skipped in adjunct process");
			}

		} else {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "createStartupBeans");
			}

			int i = 0;

			for (int size = this.ivStartupSingletonList.size(); i < size; ++i) {
				J2EEName startupName = (J2EEName) this.ivStartupSingletonList.get(i);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Creating instance for Singleton Startup bean: " + startupName.toString());
				}

				try {
					EJSHome home = (EJSHome) EJSContainer.homeOfHomes.getHome(startupName);
					home.createSingletonBeanO();
				} catch (Throwable var6) {
					FFDCFilter.processException(var6, CLASS_NAME + ".createStartupBeans", "6921", this);
					Tr.error(tc, "STARTUP_SINGLETON_SESSION_BEAN_INITIALIZATION_FAILED_CNTR0190E",
							new Object[]{startupName.getComponent(), startupName.getModule(), var6});
					throw new RuntimeWarning(
							"CNTR0201E: The " + startupName.getComponent() + " startup singleton session bean in the "
									+ startupName.getModule() + " module failed initialization.",
							var6);
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createStartupBeans");
			}

		}
	}

	private void notifyApplicationEventListeners(Collection<EJBModuleMetaDataImpl> modules, boolean started)
			throws RuntimeWarning {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "notifyApplicationEventListeners: started=" + started);
		}

		RuntimeWarning warning = null;
		Iterator i$ = modules.iterator();

		while (true) {
			List listeners;
			do {
				if (!i$.hasNext()) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "notifyApplicationEventListeners: exception=" + warning);
					}

					if (warning != null) {
						throw warning;
					}

					return;
				}

				EJBModuleMetaDataImpl mmd = (EJBModuleMetaDataImpl) i$.next();
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "notifying listeners in module: " + mmd.ivJ2EEName);
				}

				listeners = mmd.ivApplicationEventListeners;
			} while (listeners == null);

			Iterator i$ = listeners.iterator();

			while (i$.hasNext()) {
				EJBApplicationEventListener listener = (EJBApplicationEventListener) i$.next();

				try {
					if (started) {
						listener.applicationStarted(this.ivName);
					} else {
						listener.applicationStopping(this.ivName);
					}
				} catch (Throwable var11) {
					FFDCFilter.processException(var11, CLASS_NAME + ".notifyApplicationEventListeners", "781", this);
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, listener + " threw unexpected throwable: " + var11, var11);
					}

					if (warning == null) {
						warning = new RuntimeWarning(var11);
					}
				}
			}
		}
	}

	private void startQueuedNonPersistentTimerAlarms() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (EJSPlatformHelper.isZOSCRA()) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "startQueuedNonPersistentTimerAlarms: skipped in adjunct process");
			}

		} else {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "startQueuedNonPersistentTimers");
			}

			Iterator i$ = this.ivQueuedNonPersistentTimers.iterator();

			while (i$.hasNext()) {
				TimerNp timer = (TimerNp) i$.next();
				timer.startAlarm();
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "startQueuedNonPersistentTimers");
			}

		}
	}

	public synchronized void addSingletonInitialization(EJSHome home) {
		if (this.ivStopping) {
			throw new EJBStoppedException(home.getJ2EEName().toString());
		} else {
			if (this.ivSingletonInitializations == null) {
				this.ivSingletonInitializations = new LinkedHashSet();
			}

			this.ivSingletonInitializations.add(home);
		}
	}

	public synchronized void queueOrStartNonPersistentTimerAlarm(TimerNp timer, EJBModuleMetaDataImpl module) {
		if (this.ivStopping) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "not starting timer alarm after application stop: " + timer);
			}
		} else if (this.isStarted()) {
			timer.startAlarm();
		} else if (this.ivModuleBeingAddedLate != null && this.ivModuleBeingAddedLate != module) {
			timer.startAlarm();
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "queueing timer alarm until full application start: " + timer);
			}

			if (this.ivQueuedNonPersistentTimers == null) {
				this.ivQueuedNonPersistentTimers = new ArrayList();
			}

			this.ivQueuedNonPersistentTimers.add(timer);
		}

	}

	private void beginStopping(boolean application, J2EEName j2eeName, Collection<EJBModuleMetaDataImpl> modules) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "beginStopping: application=" + application + ", " + j2eeName);
		}

		synchronized (this) {
			if (application) {
				this.ivStopping = true;
			}

			this.unblockThreadsWaitingForStart();
		}

		if (j2eeName != null) {
			this.ivContainer.getEJBRuntime().removeTimers(j2eeName);
		}

		if (this.ivSingletonInitializations != null) {
			List<EJSHome> reverse = new ArrayList(this.ivSingletonInitializations);
			int i = reverse.size();

			label49 : while (true) {
				EJSHome home;
				J2EEName homeJ2EEName;
				do {
					--i;
					if (i < 0) {
						break label49;
					}

					home = (EJSHome) reverse.get(i);
					homeJ2EEName = home.getJ2EEName();
				} while (!application && !j2eeName.getModule().equals(homeJ2EEName.getModule()));

				home.destroy();
				this.ivSingletonInitializations.remove(home);
			}
		}

		try {
			this.notifyApplicationEventListeners(modules, false);
		} catch (RuntimeWarning var9) {
			FFDCFilter.processException(var9, CLASS_NAME + ".stopping", "977", this);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "beginStopping");
		}

	}

	public void stoppingModule(EJBModuleMetaDataImpl mmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "stoppingModule: " + mmd.getJ2EEName());
		}

		if (!this.ivStopping) {
			mmd.ivStopping = true;
			this.ivModules.remove(mmd);

			try {
				this.beginStopping(false, mmd.getJ2EEName(), Collections.singletonList(mmd));
			} finally {
				this.ivSingletonDependencies = null;
				this.ivStartupSingletonList = null;
				this.ivQueuedNonPersistentTimers = null;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "stoppingModule");
		}

	}

	public void stopping() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "stopping");
		}

		J2EEName j2eeName = this.ivApplicationMetaData == null ? null : this.ivApplicationMetaData.getJ2EEName();
		this.beginStopping(true, j2eeName, this.ivModules);
	}

	public boolean isStarted() {
		return this.ivStartupThread == null;
	}

	public boolean isStopping() {
		return this.ivStopping;
	}

	void validateVersionedModuleBaseName(String appBaseName, String modBaseName) {
		Iterator i$ = this.ivModules.iterator();

		EJBModuleMetaDataImpl ejbMMD;
		do {
			if (!i$.hasNext()) {
				return;
			}

			ejbMMD = (EJBModuleMetaDataImpl) i$.next();
			String versionedAppBaseName = ejbMMD.ivVersionedAppBaseName;
			if (versionedAppBaseName != null && !versionedAppBaseName.equals(appBaseName)) {
				throw new IllegalArgumentException("appBaseName (" + appBaseName
						+ ") does not equal previously set value : " + versionedAppBaseName);
			}
		} while (!modBaseName.equals(ejbMMD.ivVersionedModuleBaseName));

		throw new IllegalArgumentException("duplicate baseName : " + modBaseName);
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}