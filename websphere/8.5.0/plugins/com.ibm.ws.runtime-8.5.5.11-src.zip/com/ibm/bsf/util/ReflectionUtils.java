package com.ibm.bsf.util;

import com.ibm.bsf.util.event.EventAdapter;
import com.ibm.bsf.util.event.EventAdapterRegistry;
import com.ibm.bsf.util.event.EventProcessor;
import com.ibm.bsf.util.type.TypeConvertor;
import com.ibm.bsf.util.type.TypeConvertorRegistry;
import java.beans.BeanInfo;
import java.beans.Beans;
import java.beans.EventSetDescriptor;
import java.beans.FeatureDescriptor;
import java.beans.IndexedPropertyDescriptor;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflectionUtils {
	public static void addEventListener(Object var0, String var1, EventProcessor var2) throws IntrospectionException,
			IllegalArgumentException, IllegalAccessException, InstantiationException, InvocationTargetException {
		BeanInfo var3 = Introspector.getBeanInfo(var0.getClass());
		EventSetDescriptor var4 = (EventSetDescriptor) findFeatureByName("event", var1, var3.getEventSetDescriptors());
		if (var4 == null) {
			throw new IllegalArgumentException(
					"event set '" + var1 + "' unknown for source type '" + var0.getClass() + "'");
		} else {
			Class var5 = var4.getListenerType();
			Class var6 = EventAdapterRegistry.lookup(var5);
			if (var6 == null) {
				throw new IllegalArgumentException(
						"event adapter for listner type '" + var5 + "' (eventset " + "'" + var1 + "') unknown");
			} else {
				EventAdapter var7 = (EventAdapter) var6.newInstance();
				var7.setEventProcessor(var2);
				Method var8;
				Object[] var9;
				if (!var1.equals("propertyChange") && !var1.equals("vetoableChange")) {
					var8 = var4.getAddListenerMethod();
					var9 = new Object[]{var7};
				} else {
					var8 = var4.getAddListenerMethod();
					var9 = new Object[]{var7};
				}

				var8.invoke(var0, var9);
			}
		}
	}

	public static Bean createBean(ClassLoader var0, String var1, Class[] var2, Object[] var3)
			throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, IOException {
		if (var2 != null) {
			Class var6 = var0 != null ? var0.loadClass(var1) : Class.forName(var1);
			Constructor var5 = MethodUtils.getConstructor(var6, var2);
			return new Bean(var6, var5.newInstance(var3));
		} else {
			Object var4 = Beans.instantiate(var0, var1);
			return new Bean(var4.getClass(), var4);
		}
	}

	public static Bean createBean(ClassLoader var0, String var1, Object[] var2)
			throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, IOException {
		Class[] var3 = null;
		if (var2 != null) {
			var3 = new Class[var2.length];

			for (int var4 = 0; var4 < var2.length; ++var4) {
				var3[var4] = var2[var4] != null ? var2[var4].getClass() : null;
			}
		}

		return createBean(var0, var1, var3, var2);
	}

	private static FeatureDescriptor findFeatureByName(String var0, String var1, FeatureDescriptor[] var2) {
		for (int var3 = 0; var3 < var2.length; ++var3) {
			if (var1.equals(var2[var3].getName())) {
				return var2[var3];
			}
		}

		return null;
	}

	public static Bean getField(Object var0, String var1) throws IllegalArgumentException, IllegalAccessException {
		Class var2 = var0 instanceof Class ? (Class) var0 : var0.getClass();

		try {
			Field var3 = var2.getField(var1);
			Class var4 = var3.getType();
			Object var5 = var3.get(var0);
			return new Bean(var4, var5);
		} catch (NoSuchFieldException var6) {
			throw new IllegalArgumentException("field '" + var1 + "' is " + "unknown for '" + var0 + "'");
		}
	}

	public static Bean getProperty(Object var0, String var1, Integer var2)
			throws IntrospectionException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		BeanInfo var3 = Introspector.getBeanInfo(var0.getClass());
		PropertyDescriptor var4 = (PropertyDescriptor) findFeatureByName("property", var1,
				var3.getPropertyDescriptors());
		if (var4 == null) {
			throw new IllegalArgumentException("property '" + var1 + "' is " + "unknown for '" + var0 + "'");
		} else {
			Method var5;
			Class var6;
			IndexedPropertyDescriptor var7;
			if (var2 != null) {
				if (!(var4 instanceof IndexedPropertyDescriptor)) {
					throw new IllegalArgumentException(
							"attempt to get non-indexed property '" + var1 + "' as being indexed");
				}

				var7 = (IndexedPropertyDescriptor) var4;
				var5 = var7.getIndexedReadMethod();
				var6 = var7.getIndexedPropertyType();
			} else {
				var5 = var4.getReadMethod();
				var6 = var4.getPropertyType();
			}

			if (var5 == null) {
				throw new IllegalArgumentException("property '" + var1 + "' is not readable");
			} else {
				var7 = null;
				Object var8;
				if (var2 != null) {
					var8 = var5.invoke(var0, var2);
				} else {
					var8 = var5.invoke(var0, (Object[]) null);
				}

				return new Bean(var6, var8);
			}
		}
	}

	public static void setField(Object var0, String var1, Bean var2, TypeConvertorRegistry var3)
			throws IllegalArgumentException, IllegalAccessException {
		Class var4 = var0 instanceof Class ? (Class) var0 : var0.getClass();

		try {
			Field var5 = var4.getField(var1);
			Class var6 = var5.getType();
			Object var7 = null;
			boolean var8 = true;
			if (var6.isAssignableFrom(var2.type)) {
				var7 = var2.value;
			} else if (var3 != null) {
				TypeConvertor var9 = var3.lookup(var2.type, var6);
				if (var9 != null) {
					var7 = var9.convert(var2.type, var6, var2.value);
				} else {
					var8 = false;
				}
			} else {
				var8 = false;
			}

			if (!var8) {
				throw new IllegalArgumentException("unable to assign '" + var2.value + "' to field '" + var1 + "'");
			} else {
				var5.set(var0, var7);
			}
		} catch (NoSuchFieldException var10) {
			throw new IllegalArgumentException("field '" + var1 + "' is " + "unknown for '" + var0 + "'");
		}
	}

	public static void setProperty(Object var0, String var1, Integer var2, Object var3, Class var4,
			TypeConvertorRegistry var5)
			throws IntrospectionException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		BeanInfo var6 = Introspector.getBeanInfo(var0.getClass());
		PropertyDescriptor var7 = (PropertyDescriptor) findFeatureByName("property", var1,
				var6.getPropertyDescriptors());
		if (var7 == null) {
			throw new IllegalArgumentException("property '" + var1 + "' is " + "unknown for '" + var0 + "'");
		} else {
			Method var8;
			Class var9;
			if (var2 != null) {
				if (!(var7 instanceof IndexedPropertyDescriptor)) {
					throw new IllegalArgumentException(
							"attempt to set non-indexed property '" + var1 + "' as being indexed");
				}

				IndexedPropertyDescriptor var11 = (IndexedPropertyDescriptor) var7;
				var8 = var11.getIndexedWriteMethod();
				var9 = var11.getIndexedPropertyType();
			} else {
				var8 = var7.getWriteMethod();
				var9 = var7.getPropertyType();
			}

			if (var8 == null) {
				throw new IllegalArgumentException("property '" + var1 + "' is not writeable");
			} else {
				Object var14 = null;
				boolean var12 = true;
				if (var9.isAssignableFrom(var4)) {
					var14 = var3;
				} else if (var5 != null) {
					TypeConvertor var13 = var5.lookup(var4, var9);
					if (var13 != null) {
						var14 = var13.convert(var4, var9, var3);
					} else {
						var12 = false;
					}
				} else {
					var12 = false;
				}

				if (!var12) {
					throw new IllegalArgumentException("unable to assign '" + var3 + "' to property '" + var1 + "'");
				} else {
					if (var2 != null) {
						var8.invoke(var0, var2, var14);
					} else {
						var8.invoke(var0, var14);
					}

				}
			}
		}
	}
}