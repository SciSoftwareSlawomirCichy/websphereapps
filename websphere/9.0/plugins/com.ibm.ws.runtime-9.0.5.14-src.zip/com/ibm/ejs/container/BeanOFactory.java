package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;

public abstract class BeanOFactory {
	private static final String CLASS_NAME = BeanOFactory.class.getName();
	private static final TraceComponent tc;

	protected abstract BeanO newInstance(EJSContainer var1, EJSHome var2);

	public final BeanO create(EJSContainer c, EJSHome h, boolean reactivate)
			throws RemoteException, InvocationTargetException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "create: " + h);
		}

		BeanO beanO = this.newInstance(c, h);
		boolean success = false;

		try {
			beanO.initialize(reactivate);
			success = true;
		} finally {
			if (!success) {
				beanO.discard();
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "create: " + beanO + ", success=" + success);
			}

		}

		return beanO;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}