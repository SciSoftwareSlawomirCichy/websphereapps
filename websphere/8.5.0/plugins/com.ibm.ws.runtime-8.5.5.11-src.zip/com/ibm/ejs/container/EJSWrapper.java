package com.ibm.ejs.container;

import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.ejb.Handle;
import javax.ejb.RemoveException;
import javax.rmi.PortableRemoteObject;
import javax.rmi.CORBA.Stub;

public class EJSWrapper extends EJSRemoteWrapper implements EJBObject {
	private static final String CLASS_NAME = "com.ibm.ejs.container.EJSWrapper";

	public EJBHome getEJBHome() throws RemoteException {
		return (EJBHome) PortableRemoteObject
				.toStub(this.wrapperManager.getWrapper(this.beanId.getHome().getId()).getRemoteWrapper());
	}

	public Handle getHandle() throws RemoteException {
		ComponentMetaDataAccessorImpl cmdAccessor = null;

		Handle var2;
		try {
			cmdAccessor = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor();
			cmdAccessor.beginContext(this.bmd);
			var2 = this.beanId.getHome().createHandle(this.beanId);
		} finally {
			if (cmdAccessor != null) {
				cmdAccessor.endContext();
			}

		}

		return var2;
	}

	public Object getPrimaryKey() throws RemoteException {
		HomeInternal hi = this.beanId.getHome();
		if (!hi.isStatelessSessionHome() && !hi.isStatefulSessionHome()) {
			return this.beanId.getPrimaryKey();
		} else {
			throw new IllegalSessionMethodException();
		}
	}

	public boolean isIdentical(EJBObject obj) throws RemoteException {
		try {
			Stub myStub = (Stub) PortableRemoteObject.toStub(this);
			return myStub.equals(obj);
		} catch (NoSuchObjectException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.EJSWrapper.isIdentical", "151", this);
			return false;
		} catch (ClassCastException var4) {
			FFDCFilter.processException(var4, "com.ibm.ejs.container.EJSWrapper.isIdentical", "154", this);
			return false;
		}
	}

	public void remove() throws RemoteException, RemoveException {
		this.container.removeBean(this);
	}
}