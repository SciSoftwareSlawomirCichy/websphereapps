package com.google.inject.internal;

import com.google.inject.TypeLiteral;
import com.google.inject.matcher.Matcher;
import com.google.inject.spi.TypeConverter;

public final class MatcherAndConverter {
	private final Matcher<? super TypeLiteral<?>> typeMatcher;
	private final TypeConverter typeConverter;
	private final Object source;

	public MatcherAndConverter(Matcher<? super TypeLiteral<?>> typeMatcher, TypeConverter typeConverter,
			Object source) {
		this.typeMatcher = (Matcher) Preconditions.checkNotNull(typeMatcher, "type matcher");
		this.typeConverter = (TypeConverter) Preconditions.checkNotNull(typeConverter, "converter");
		this.source = source;
	}

	public TypeConverter getTypeConverter() {
		return this.typeConverter;
	}

	public Matcher<? super TypeLiteral<?>> getTypeMatcher() {
		return this.typeMatcher;
	}

	public Object getSource() {
		return this.source;
	}

	public String toString() {
		return this.typeConverter + " which matches " + this.typeMatcher + " (bound at " + this.source + ")";
	}
}