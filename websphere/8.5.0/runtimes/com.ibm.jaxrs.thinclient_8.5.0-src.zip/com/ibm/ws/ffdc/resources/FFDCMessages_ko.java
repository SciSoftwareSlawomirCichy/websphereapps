package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_ko extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: {0} 데이터베이스를 사용하는 분석 엔진"},
			{"FFDCIncidentEmitted", "FFDC1003I: {0} {1} {2}에서 FFDC 인시던트가 생성됨"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE", "FFDC0002I: FFDC 로그 파일 관리에서 {0} 파일을 삭제하려고 시도"},
			{"FFDCJANITOR_DELETED_FILES", "FFDC0004I: FFDC 로그 파일 관리에서 구성된 최대 유효 기간에 도달한 {1}개의 파일 중 {0}개를 제거했습니다."},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE", "FFDC0003I: FFDC 로그 파일 관리에서 {0} 파일을 삭제하는 데 실패"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST", "FFDC0001W: FFDC 로그 파일 관리에서 예외 파일 목록을 얻는 데 실패"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC가 인시던트 스트림 파일 {0}을(를) 닫음"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC가 인시던트 스트림 파일 {0}을(를) 열었음"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE", "FFDC0012I: FFDC가 인시던트 스트림 파일 {0}을(를) 닫는 데 실패, {1} 예외 발생"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE", "FFDC0011I: FFDC가 인시던트 스트림 파일 {0}을(를) 열거나 작성하는 데 실패, {1} 예외 발생"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE", "FFDC0013I: FFDC가 인시던트 스트림 파일 {0}에 쓰는 데 실패, {1} 예외 발생"}};

	public Object[][] getContents() {
		return resources;
	}
}