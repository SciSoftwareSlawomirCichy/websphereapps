package com.ibm.ws.wim;

import com.ibm.websphere.wim.DynamicConfigConstants;
import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.security.authz.Entitlement;
import com.ibm.websphere.wim.util.Routines;
import com.ibm.ws.wim.management.DynamicReloadManager;
import com.ibm.ws.wim.management.EventDataWrapper;
import com.ibm.ws.wim.management.EventHandler;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.util.DomainManagerUtils;
import commonj.sdo.DataGraph;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EventManager implements EventHandler, DynamicConfigConstants, DynamicConfigService {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;
	private static Map<String, EventManager> singleton;
	private ConfigManager configManager = null;
	private RepositoryManager repositoryManager = null;
	private RealmManager realmManager = null;
	private static final String[] supportedEvents;
	private HashSet listeningEvents = null;

	public static synchronized EventManager singleton() throws WIMException {
		String var0 = DomainManagerUtils.getDomainName();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new EventManager());
		}

		return (EventManager) singleton.get(var0);
	}

	public static void clearCache(String var0) {
		singleton.put(var0, (Object) null);
	}

	private EventManager() throws WIMException {
		this.initialize();
	}

	private void initialize() throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

		this.listeningEvents = new HashSet();

		for (int var2 = 0; var2 < supportedEvents.length; ++var2) {
			this.listeningEvents.add(supportedEvents[var2]);
		}

		this.configManager = ConfigManager.singleton();
		SchemaManager.singleton();
		this.repositoryManager = RepositoryManager.singleton();
		this.realmManager = RealmManager.singleton();
		ProfileManager.singleton();
		if (DynamicReloadManager.isRunningOnManagedProcOrNodeAgent()) {
			this.registryEvents();
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

	}

	public boolean isListeningToEvent(String var1) {
		return this.listeningEvents != null && var1 != null && this.listeningEvents.contains(var1);
	}

	public String[] getEventProcessList() {
		return Routines.stringArrayCopy(supportedEvents);
	}

	public void processEvent(String var1, EventDataWrapper var2) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "processEvent", "eventType=" + var1 + ", eventDataWrapper=" + var2);
		}

		Hashtable var4 = (Hashtable) var2.getObject();

		try {
			this.dynamicUpdateConfig(var1, var4);
		} catch (WIMException var6) {
			Routines.logException(trcLogger, CLASSNAME, "processEvent", Level.WARNING, var6.getMessage(), var6);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "processEvent");
		}

	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "dynamicUpdateConfig", "eventType=" + var1 + ", configData=" + var2);
		}

		ProfileSecurityManager var4 = ProfileSecurityManager.singleton();
		var4.checkPermission_SuperUser(new Entitlement("DYNAMIC_UPDATE", "CONFIGURATION"));
		if ("websphere.usermanager.serviceprovider.update.ldap.bindinfo".equals(var1)) {
			this.configManager.dynamicUpdateConfig(var1, var2);
			this.repositoryManager.dynamicUpdateConfig(var1, var2);
		} else if (!"websphere.usermanager.serviceprovider.add.repository".equals(var1)
				&& !"websphere.usermanager.serviceprovider.add.propertyextensionrepository".equals(var1)) {
			if ("websphere.usermanager.serviceprovider.add.realm".equals(var1)) {
				this.configManager.dynamicUpdateConfig(var1, var2);
				this.realmManager.dynamicUpdateConfig(var1, var2);
			} else if (!"websphere.usermanager.serviceprovider.add.participatingbaseentry".equals(var1)
					&& !"websphere.usermanager.serviceprovider.add.defaultparenttorealm".equals(var1)) {
				if ("websphere.usermanager.serviceprovider.add.baseentry".equals(var1)) {
					DataGraph var5 = this.configManager.configDG;
					synchronized (this.configManager.configDG) {
						this.configManager.saveConfig();
						this.configManager.dynamicUpdateConfig(var1, var2);

						try {
							this.repositoryManager.dynamicUpdateConfig(var1, var2);
						} catch (Exception var8) {
							this.configManager.rollbackToSavedConfig();
							throw new DynamicUpdateConfigException("GENERIC", WIMMessageHelper.generateMsgParms(
									var8.getMessage(), Level.SEVERE, CLASSNAME, "dynamicUpdateConfig", var8));
						}
					}
				} else if ("websphere.usermanager.serviceprovider.add.entityconfig".equals(var1)) {
					this.configManager.dynamicUpdateConfig(var1, var2);
					this.repositoryManager.dynamicUpdateConfig(var1, var2);
				} else if ("websphere.usermanager.serviceprovider.add.propertyconfig".equals(var1)) {
					this.repositoryManager.dynamicUpdateConfig(var1, var2);
				} else if ("websphere.usermanager.serviceprovider.update.db.adminidpassword".equals(var1)
						|| "websphere.usermanager.serviceprovider.update.entrymapping.adminidpassword".equals(var1)
						|| "websphere.usermanager.serviceprovider.update.propertyextension.adminidpassword"
								.equals(var1)) {
					this.repositoryManager.dynamicUpdateConfig(var1, var2);
				}
			} else {
				this.realmManager.dynamicUpdateConfig(var1, var2);
			}
		} else {
			this.configManager.dynamicUpdateConfig(var1, var2);
			this.repositoryManager.dynamicUpdateConfig(var1, var2);
			ProfileManager.singleton().initializePropertyCache();
			if ("websphere.usermanager.serviceprovider.add.propertyextensionrepository".equals(var1)) {
				ProfileManager.singleton().invalidLAProperties();
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "dynamicUpdateConfig");
		}

	}

	private void registryEvents() {
		for (int var1 = 0; var1 < supportedEvents.length; ++var1) {
			DynamicReloadManager.singleton().registerEventAtNode(supportedEvents[var1], this);
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = EventManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
		supportedEvents = new String[]{"websphere.usermanager.serviceprovider.add.baseentry",
				"websphere.usermanager.serviceprovider.add.defaultparenttorealm",
				"websphere.usermanager.serviceprovider.add.entityconfig",
				"websphere.usermanager.serviceprovider.add.participatingbaseentry",
				"websphere.usermanager.serviceprovider.add.propertyconfig",
				"websphere.usermanager.serviceprovider.add.propertyextensionrepository",
				"websphere.usermanager.serviceprovider.add.realm",
				"websphere.usermanager.serviceprovider.add.repository",
				"websphere.usermanager.serviceprovider.update.db.adminidpassword",
				"websphere.usermanager.serviceprovider.update.entrymapping.adminidpassword",
				"websphere.usermanager.serviceprovider.update.ldap.bindinfo",
				"websphere.usermanager.serviceprovider.update.propertyextension.adminidpassword"};
	}
}