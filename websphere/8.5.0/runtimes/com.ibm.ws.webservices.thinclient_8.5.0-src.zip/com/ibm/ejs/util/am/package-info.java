package com.ibm.ejs.util.am;

interface package-info {
}