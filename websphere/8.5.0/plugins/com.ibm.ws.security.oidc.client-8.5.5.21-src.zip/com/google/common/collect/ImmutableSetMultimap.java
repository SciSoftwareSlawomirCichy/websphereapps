package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.MoreObjects;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMultimap.FieldSettersHolder;
import com.google.common.collect.ImmutableSetMultimap.Builder;
import com.google.common.collect.ImmutableSetMultimap.EntrySet;
import com.google.common.collect.ImmutableSetMultimap.SetFieldSettersHolder;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.concurrent.LazyInit;
import com.google.j2objc.annotations.RetainedWith;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
public class ImmutableSetMultimap<K, V> extends ImmutableMultimap<K, V> implements SetMultimap<K, V> {
	private final transient ImmutableSet<V> emptySet;
	@LazyInit
	@MonotonicNonNullDecl
	@RetainedWith
	private transient ImmutableSetMultimap<V, K> inverse;
	@MonotonicNonNullDecl
	private transient ImmutableSet<Entry<K, V>> entries;
	@GwtIncompatible
	private static final long serialVersionUID = 0L;

	public static <K, V> ImmutableSetMultimap<K, V> of() {
		return EmptyImmutableSetMultimap.INSTANCE;
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		return builder.build();
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		builder.put(k2, v2);
		return builder.build();
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		builder.put(k2, v2);
		builder.put(k3, v3);
		return builder.build();
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		builder.put(k2, v2);
		builder.put(k3, v3);
		builder.put(k4, v4);
		return builder.build();
	}

	public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
		Builder<K, V> builder = builder();
		builder.put(k1, v1);
		builder.put(k2, v2);
		builder.put(k3, v3);
		builder.put(k4, v4);
		builder.put(k5, v5);
		return builder.build();
	}

	public static <K, V> Builder<K, V> builder() {
		return new Builder();
	}

	public static <K, V> ImmutableSetMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap) {
		return copyOf(multimap, (Comparator) null);
	}

	private static <K, V> ImmutableSetMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap,
			Comparator<? super V> valueComparator) {
		Preconditions.checkNotNull(multimap);
		if (multimap.isEmpty() && valueComparator == null) {
			return of();
		} else {
			if (multimap instanceof ImmutableSetMultimap) {
				ImmutableSetMultimap<K, V> kvMultimap = (ImmutableSetMultimap) multimap;
				if (!kvMultimap.isPartialView()) {
					return kvMultimap;
				}
			}

			return fromMapEntries(multimap.asMap().entrySet(), valueComparator);
		}
	}

	@Beta
	public static <K, V> ImmutableSetMultimap<K, V> copyOf(
			Iterable<? extends Entry<? extends K, ? extends V>> entries) {
		return (new Builder()).putAll(entries).build();
	}

	static <K, V> ImmutableSetMultimap<K, V> fromMapEntries(
			Collection<? extends Entry<? extends K, ? extends Collection<? extends V>>> mapEntries,
			@NullableDecl Comparator<? super V> valueComparator) {
		if (mapEntries.isEmpty()) {
			return of();
		} else {
			com.google.common.collect.ImmutableMap.Builder<K, ImmutableSet<V>> builder = new com.google.common.collect.ImmutableMap.Builder(
					mapEntries.size());
			int size = 0;
			Iterator var4 = mapEntries.iterator();

			while (var4.hasNext()) {
				Entry<? extends K, ? extends Collection<? extends V>> entry = (Entry) var4.next();
				K key = entry.getKey();
				Collection<? extends V> values = (Collection) entry.getValue();
				ImmutableSet<V> set = valueSet(valueComparator, values);
				if (!set.isEmpty()) {
					builder.put(key, set);
					size += set.size();
				}
			}

			return new ImmutableSetMultimap(builder.build(), size, valueComparator);
		}
	}

	ImmutableSetMultimap(ImmutableMap<K, ImmutableSet<V>> map, int size,
			@NullableDecl Comparator<? super V> valueComparator) {
		super(map, size);
		this.emptySet = emptySet(valueComparator);
	}

	public ImmutableSet<V> get(@NullableDecl K key) {
		ImmutableSet<V> set = (ImmutableSet) this.map.get(key);
		return (ImmutableSet) MoreObjects.firstNonNull(set, this.emptySet);
	}

	public ImmutableSetMultimap<V, K> inverse() {
		ImmutableSetMultimap<V, K> result = this.inverse;
		return result == null ? (this.inverse = this.invert()) : result;
	}

	private ImmutableSetMultimap<V, K> invert() {
		Builder<V, K> builder = builder();
		UnmodifiableIterator var2 = this.entries().iterator();

		while (var2.hasNext()) {
			Entry<K, V> entry = (Entry) var2.next();
			builder.put(entry.getValue(), entry.getKey());
		}

		ImmutableSetMultimap<V, K> invertedMultimap = builder.build();
		invertedMultimap.inverse = this;
		return invertedMultimap;
	}

	@Deprecated
	@CanIgnoreReturnValue
	public ImmutableSet<V> removeAll(Object key) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@CanIgnoreReturnValue
	public ImmutableSet<V> replaceValues(K key, Iterable<? extends V> values) {
		throw new UnsupportedOperationException();
	}

	public ImmutableSet<Entry<K, V>> entries() {
		ImmutableSet<Entry<K, V>> result = this.entries;
		return result == null ? (this.entries = new EntrySet(this)) : result;
	}

	private static <V> ImmutableSet<V> valueSet(@NullableDecl Comparator<? super V> valueComparator,
			Collection<? extends V> values) {
		return (ImmutableSet) (valueComparator == null
				? ImmutableSet.copyOf(values)
				: ImmutableSortedSet.copyOf(valueComparator, values));
	}

	private static <V> ImmutableSet<V> emptySet(@NullableDecl Comparator<? super V> valueComparator) {
		return (ImmutableSet) (valueComparator == null
				? ImmutableSet.of()
				: ImmutableSortedSet.emptySet(valueComparator));
	}

	private static <V> com.google.common.collect.ImmutableSet.Builder<V> valuesBuilder(
			@NullableDecl Comparator<? super V> valueComparator) {
		return (com.google.common.collect.ImmutableSet.Builder) (valueComparator == null
				? new com.google.common.collect.ImmutableSet.Builder()
				: new com.google.common.collect.ImmutableSortedSet.Builder(valueComparator));
	}

	@GwtIncompatible
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		stream.writeObject(this.valueComparator());
		Serialization.writeMultimap(this, stream);
	}

	@NullableDecl
	Comparator<? super V> valueComparator() {
		return this.emptySet instanceof ImmutableSortedSet ? ((ImmutableSortedSet) this.emptySet).comparator() : null;
	}

	@GwtIncompatible
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		Comparator<Object> valueComparator = (Comparator) stream.readObject();
		int keyCount = stream.readInt();
		if (keyCount < 0) {
			throw new InvalidObjectException("Invalid key count " + keyCount);
		} else {
			com.google.common.collect.ImmutableMap.Builder<Object, ImmutableSet<Object>> builder = ImmutableMap
					.builder();
			int tmpSize = 0;

			for (int i = 0; i < keyCount; ++i) {
				Object key = stream.readObject();
				int valueCount = stream.readInt();
				if (valueCount <= 0) {
					throw new InvalidObjectException("Invalid value count " + valueCount);
				}

				com.google.common.collect.ImmutableSet.Builder<Object> valuesBuilder = valuesBuilder(valueComparator);

				for (int j = 0; j < valueCount; ++j) {
					valuesBuilder.add(stream.readObject());
				}

				ImmutableSet<Object> valueSet = valuesBuilder.build();
				if (valueSet.size() != valueCount) {
					throw new InvalidObjectException("Duplicate key-value pairs exist for key " + key);
				}

				builder.put(key, valueSet);
				tmpSize += valueCount;
			}

			ImmutableMap tmpMap;
			try {
				tmpMap = builder.build();
			} catch (IllegalArgumentException var11) {
				throw (InvalidObjectException) (new InvalidObjectException(var11.getMessage())).initCause(var11);
			}

			FieldSettersHolder.MAP_FIELD_SETTER.set(this, tmpMap);
			FieldSettersHolder.SIZE_FIELD_SETTER.set(this, tmpSize);
			SetFieldSettersHolder.EMPTY_SET_FIELD_SETTER.set(this, emptySet(valueComparator));
		}
	}
}