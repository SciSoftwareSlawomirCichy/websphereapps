package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.collect.HashBiMap.1;
import com.google.common.collect.HashBiMap.BiEntry;
import com.google.common.collect.HashBiMap.EntrySet;
import com.google.common.collect.HashBiMap.Inverse;
import com.google.common.collect.HashBiMap.KeySet;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
public final class HashBiMap<K, V> extends AbstractMap<K, V> implements BiMap<K, V>, Serializable {
	private static final double LOAD_FACTOR = 1.0D;
	private transient BiEntry<K, V>[] hashTableKToV;
	private transient BiEntry<K, V>[] hashTableVToK;
	private transient int size;
	private transient int mask;
	private transient int modCount;
	private transient BiMap<V, K> inverse;
	@GwtIncompatible("Not needed in emulated source")
	private static final long serialVersionUID = 0L;

	public static <K, V> HashBiMap<K, V> create() {
		return create(16);
	}

	public static <K, V> HashBiMap<K, V> create(int expectedSize) {
		return new HashBiMap(expectedSize);
	}

	public static <K, V> HashBiMap<K, V> create(Map<? extends K, ? extends V> map) {
		HashBiMap<K, V> bimap = create(map.size());
		bimap.putAll(map);
		return bimap;
	}

	private HashBiMap(int expectedSize) {
		this.init(expectedSize);
	}

	private void init(int expectedSize) {
		Preconditions.checkArgument(expectedSize >= 0, "expectedSize must be >= 0 but was %s",
				new Object[]{expectedSize});
		int tableSize = Hashing.closedTableSize(expectedSize, 1.0D);
		this.hashTableKToV = this.createTable(tableSize);
		this.hashTableVToK = this.createTable(tableSize);
		this.mask = tableSize - 1;
		this.modCount = 0;
		this.size = 0;
	}

	private void delete(BiEntry<K, V> entry) {
		int keyBucket = entry.keyHash & this.mask;
		BiEntry<K, V> prevBucketEntry = null;

		for (BiEntry bucketEntry = this.hashTableKToV[keyBucket]; bucketEntry != entry; bucketEntry = bucketEntry.nextInKToVBucket) {
			prevBucketEntry = bucketEntry;
		}

		if (prevBucketEntry == null) {
			this.hashTableKToV[keyBucket] = entry.nextInKToVBucket;
		} else {
			prevBucketEntry.nextInKToVBucket = entry.nextInKToVBucket;
		}

		int valueBucket = entry.valueHash & this.mask;
		prevBucketEntry = null;

		for (BiEntry bucketEntry = this.hashTableVToK[valueBucket]; bucketEntry != entry; bucketEntry = bucketEntry.nextInVToKBucket) {
			prevBucketEntry = bucketEntry;
		}

		if (prevBucketEntry == null) {
			this.hashTableVToK[valueBucket] = entry.nextInVToKBucket;
		} else {
			prevBucketEntry.nextInVToKBucket = entry.nextInVToKBucket;
		}

		--this.size;
		++this.modCount;
	}

	private void insert(BiEntry<K, V> entry) {
		int keyBucket = entry.keyHash & this.mask;
		entry.nextInKToVBucket = this.hashTableKToV[keyBucket];
		this.hashTableKToV[keyBucket] = entry;
		int valueBucket = entry.valueHash & this.mask;
		entry.nextInVToKBucket = this.hashTableVToK[valueBucket];
		this.hashTableVToK[valueBucket] = entry;
		++this.size;
		++this.modCount;
	}

	private static int hash(@Nullable Object o) {
		return Hashing.smear(o == null ? 0 : o.hashCode());
	}

	private BiEntry<K, V> seekByKey(@Nullable Object key, int keyHash) {
		for (BiEntry entry = this.hashTableKToV[keyHash & this.mask]; entry != null; entry = entry.nextInKToVBucket) {
			if (keyHash == entry.keyHash && Objects.equal(key, entry.key)) {
				return entry;
			}
		}

		return null;
	}

	private BiEntry<K, V> seekByValue(@Nullable Object value, int valueHash) {
		for (BiEntry entry = this.hashTableVToK[valueHash & this.mask]; entry != null; entry = entry.nextInVToKBucket) {
			if (valueHash == entry.valueHash && Objects.equal(value, entry.value)) {
				return entry;
			}
		}

		return null;
	}

	public boolean containsKey(@Nullable Object key) {
		return this.seekByKey(key, hash(key)) != null;
	}

	public boolean containsValue(@Nullable Object value) {
		return this.seekByValue(value, hash(value)) != null;
	}

	@Nullable
	public V get(@Nullable Object key) {
		BiEntry<K, V> entry = this.seekByKey(key, hash(key));
		return entry == null ? null : entry.value;
	}

	public V put(@Nullable K key, @Nullable V value) {
		return this.put(key, value, false);
	}

	public V forcePut(@Nullable K key, @Nullable V value) {
		return this.put(key, value, true);
	}

	private V put(@Nullable K key, @Nullable V value, boolean force) {
		int keyHash = hash(key);
		int valueHash = hash(value);
		BiEntry<K, V> oldEntryForKey = this.seekByKey(key, keyHash);
		if (oldEntryForKey != null && valueHash == oldEntryForKey.valueHash
				&& Objects.equal(value, oldEntryForKey.value)) {
			return value;
		} else {
			BiEntry<K, V> oldEntryForValue = this.seekByValue(value, valueHash);
			if (oldEntryForValue != null) {
				if (!force) {
					throw new IllegalArgumentException("value already present: " + value);
				}

				this.delete(oldEntryForValue);
			}

			if (oldEntryForKey != null) {
				this.delete(oldEntryForKey);
			}

			BiEntry<K, V> newEntry = new BiEntry(key, keyHash, value, valueHash);
			this.insert(newEntry);
			this.rehashIfNecessary();
			return oldEntryForKey == null ? null : oldEntryForKey.value;
		}
	}

	@Nullable
	private K putInverse(@Nullable V value, @Nullable K key, boolean force) {
		int valueHash = hash(value);
		int keyHash = hash(key);
		BiEntry<K, V> oldEntryForValue = this.seekByValue(value, valueHash);
		if (oldEntryForValue != null && keyHash == oldEntryForValue.keyHash
				&& Objects.equal(key, oldEntryForValue.key)) {
			return key;
		} else {
			BiEntry<K, V> oldEntryForKey = this.seekByKey(key, keyHash);
			if (oldEntryForKey != null) {
				if (!force) {
					throw new IllegalArgumentException("value already present: " + key);
				}

				this.delete(oldEntryForKey);
			}

			if (oldEntryForValue != null) {
				this.delete(oldEntryForValue);
			}

			BiEntry<K, V> newEntry = new BiEntry(key, keyHash, value, valueHash);
			this.insert(newEntry);
			this.rehashIfNecessary();
			return oldEntryForValue == null ? null : oldEntryForValue.key;
		}
	}

	private void rehashIfNecessary() {
		BiEntry<K, V>[] oldKToV = this.hashTableKToV;
		if (Hashing.needsResizing(this.size, oldKToV.length, 1.0D)) {
			int newTableSize = oldKToV.length * 2;
			this.hashTableKToV = this.createTable(newTableSize);
			this.hashTableVToK = this.createTable(newTableSize);
			this.mask = newTableSize - 1;
			this.size = 0;

			BiEntry nextEntry;
			for (int bucket = 0; bucket < oldKToV.length; ++bucket) {
				for (BiEntry entry = oldKToV[bucket]; entry != null; entry = nextEntry) {
					nextEntry = entry.nextInKToVBucket;
					this.insert(entry);
				}
			}

			++this.modCount;
		}

	}

	private BiEntry<K, V>[] createTable(int length) {
		return new BiEntry[length];
	}

	public V remove(@Nullable Object key) {
		BiEntry<K, V> entry = this.seekByKey(key, hash(key));
		if (entry == null) {
			return null;
		} else {
			this.delete(entry);
			return entry.value;
		}
	}

	public void clear() {
		this.size = 0;
		Arrays.fill(this.hashTableKToV, (Object) null);
		Arrays.fill(this.hashTableVToK, (Object) null);
		++this.modCount;
	}

	public int size() {
		return this.size;
	}

	public Set<K> keySet() {
      return new KeySet(this, (1)null);
   }

	public Set<V> values() {
		return this.inverse().keySet();
	}

	public Set<Entry<K, V>> entrySet() {
      return new EntrySet(this, (1)null);
   }

	public BiMap<V, K> inverse() {
      return this.inverse == null ? (this.inverse = new Inverse(this, (1)null)) : this.inverse;
   }

	@GwtIncompatible("java.io.ObjectOutputStream")
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		Serialization.writeMap(this, stream);
	}

	@GwtIncompatible("java.io.ObjectInputStream")
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		int size = Serialization.readCount(stream);
		this.init(size);
		Serialization.populateMap(this, stream, size);
	}
}