package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.Key;
import com.google.inject.Module;
import com.google.inject.Provider;
import com.google.inject.Provides;
import com.google.inject.TypeLiteral;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.Message;
import com.google.inject.util.Modules;
import java.lang.annotation.Annotation;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;

public final class ProviderMethodsModule implements Module {
	private final Object delegate;
	private final TypeLiteral<?> typeLiteral;

	private ProviderMethodsModule(Object delegate) {
		this.delegate = Preconditions.checkNotNull(delegate, "delegate");
		this.typeLiteral = TypeLiteral.get(this.delegate.getClass());
	}

	public static Module forModule(Module module) {
		return forObject(module);
	}

	public static Module forObject(Object object) {
		return (Module) (object instanceof ProviderMethodsModule
				? Modules.EMPTY_MODULE
				: new ProviderMethodsModule(object));
	}

	public synchronized void configure(Binder binder) {
		Iterator i$ = this.getProviderMethods(binder).iterator();

		while (i$.hasNext()) {
			ProviderMethod<?> providerMethod = (ProviderMethod) i$.next();
			providerMethod.configure(binder);
		}

	}

	public List<ProviderMethod<?>> getProviderMethods(Binder binder) {
		List<ProviderMethod<?>> result = Lists.newArrayList();

		for (Class c = this.delegate.getClass(); c != Object.class; c = c.getSuperclass()) {
			Method[] arr$ = c.getDeclaredMethods();
			int len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				Method method = arr$[i$];
				if (method.isAnnotationPresent(Provides.class)) {
					result.add(this.createProviderMethod(binder, method));
				}
			}
		}

		return result;
	}

	<T> ProviderMethod<T> createProviderMethod(Binder binder, Method method) {
		binder = binder.withSource(method);
		Errors errors = new Errors(method);
		List<Dependency<?>> dependencies = Lists.newArrayList();
		List<Provider<?>> parameterProviders = Lists.newArrayList();
		List<TypeLiteral<?>> parameterTypes = this.typeLiteral.getParameterTypes(method);
		Annotation[][] parameterAnnotations = method.getParameterAnnotations();

		Key key;
		for (int i = 0; i < parameterTypes.size(); ++i) {
			key = this.getKey(errors, (TypeLiteral) parameterTypes.get(i), method, parameterAnnotations[i]);
			dependencies.add(Dependency.get(key));
			parameterProviders.add(binder.getProvider(key));
		}

		TypeLiteral<T> returnType = this.typeLiteral.getReturnType(method);
		key = this.getKey(errors, returnType, method, method.getAnnotations());
		Class<? extends Annotation> scopeAnnotation = Annotations.findScopeAnnotation(errors, method.getAnnotations());
		Iterator i$ = errors.getMessages().iterator();

		while (i$.hasNext()) {
			Message message = (Message) i$.next();
			binder.addError(message);
		}

		return new ProviderMethod(key, method, this.delegate, ImmutableSet.copyOf(dependencies), parameterProviders,
				scopeAnnotation);
	}

	<T> Key<T> getKey(Errors errors, TypeLiteral<T> type, Member member, Annotation[] annotations) {
		Annotation bindingAnnotation = Annotations.findBindingAnnotation(errors, member, annotations);
		return bindingAnnotation == null ? Key.get(type) : Key.get(type, bindingAnnotation);
	}

	public boolean equals(Object o) {
		return o instanceof ProviderMethodsModule && ((ProviderMethodsModule) o).delegate == this.delegate;
	}

	public int hashCode() {
		return this.delegate.hashCode();
	}
}