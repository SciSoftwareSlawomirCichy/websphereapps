package com.ibm.ejs.oa.pool;

import com.ibm.CORBA.iiop.ORB;
import com.ibm.CORBA.iiop.WorkUnit;
import com.ibm.ejs.oa.pool.ThreadPool.1;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.util.ObjectPool;

public class ThreadPool implements com.ibm.CORBA.iiop.ThreadPool {
	private static final TraceComponent tc = Tr.register(ThreadPool.class, "ObjectAdapter",
			"com.ibm.ws.runtime.runtime");
	public static final int DEFAULT_MIN_SIZE = 2;
	public static final int DEFAULT_MAX_SIZE = 20;
	protected ObjectPool workerPool;
	protected com.ibm.ws.util.ThreadPool threadPool;
	private long timeoutInMillis;

	public ThreadPool(com.ibm.ws.util.ThreadPool tp) {
		this(tp, 0L);
	}

	public ThreadPool(com.ibm.ws.util.ThreadPool tp, long timeoutInMillis) {
      this.threadPool = tp;
      this.timeoutInMillis = timeoutInMillis;
      this.workerPool = new 1(this, "ORB thread pool", tp.getMaximumPoolSize());
   }

	public void cleanup() {
	}

	public void init(ORB orb) {
	}

	public void startWorkerThread(WorkUnit workUnit) {
		PooledThread req = (PooledThread) this.workerPool.remove();
		req.handleRequest(workUnit);
		Runnable result = null;

		try {
			result = this.threadPool.execute(req, this.timeoutInMillis);
		} catch (InterruptedException var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.oa.pool.ThreadPool.startWorkerThread", "83", this);
		} catch (RuntimeException var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.oa.pool.ThreadPool.startWorkerThread", "85", this);
			throw var6;
		} catch (Error var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.oa.pool.ThreadPool.startWorkerThread", "88", this);
			throw var7;
		}

		if (result == null) {
			Tr.warning(tc, "WSVR0627W", new Long(this.timeoutInMillis));
			throw new RuntimeException("ThreadPool queue is full");
		}
	}
}