package com.ibm.ws.ssl.resources;

import java.util.ListResourceBundle;

public class ssl_en extends ListResourceBundle {
	private static final Object[][] resources = new Object[0][];

	public Object[][] getContents() {
		return resources;
	}
}