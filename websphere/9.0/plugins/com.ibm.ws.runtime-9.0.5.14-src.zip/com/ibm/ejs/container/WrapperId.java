package com.ibm.ejs.container;

import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.ByteArray;

public final class WrapperId extends ByteArray {
	private static final String CLASS_NAME = WrapperId.class.getName();
	private static final TraceComponent tc;
	private static final byte[] header;
	private static final int HEADER_LEN;
	public int ivInterfaceIndex = -1;
	public String ivInterfaceClassName = null;
	public int ivBeanIdIndex = -1;

	public WrapperId(byte[] bytes) {
		super(bytes);
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init> byte array length: " + bytes.length);
		}

		int next;
		for (next = 0; next < HEADER_LEN; ++next) {
			if (bytes[next] != header[next]) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Header mismatch, invalid WrapperId.");
				}

				throw new RuntimeException("Header mismatch, invalid WrapperId.");
			}
		}

		next = HEADER_LEN;
		if (EJSPlatformHelper.isZOS()) {
			this.ivInterfaceIndex = (bytes[next++] & 255) << 24 | (bytes[next++] & 255) << 16
					| (bytes[next++] & 255) << 8 | bytes[next++] & 255;
		} else {
			this.ivInterfaceIndex = bytes[next++] & 255 | (bytes[next++] & 255) << 8 | (bytes[next++] & 255) << 16
					| (bytes[next++] & 255) << 24;
		}

		int interfaceNameLength = false;
		int interfaceNameLength;
		if (EJSPlatformHelper.isZOS()) {
			interfaceNameLength = (bytes[next++] & 255) << 24 | (bytes[next++] & 255) << 16 | (bytes[next++] & 255) << 8
					| bytes[next++] & 255;
		} else {
			interfaceNameLength = bytes[next++] & 255 | (bytes[next++] & 255) << 8 | (bytes[next++] & 255) << 16
					| (bytes[next++] & 255) << 24;
		}

		this.ivInterfaceClassName = new String(bytes, next, interfaceNameLength);
		this.ivBeanIdIndex = next + interfaceNameLength;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init> : " + this.ivInterfaceIndex + " : " + this.ivInterfaceClassName);
		}

	}

	public WrapperId(byte[] beanId, String interfaceName, int interfaceIndex) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>: " + interfaceIndex + ", " + interfaceName + ", " + beanId.length);
		}

		int beanIdLength = beanId.length;
		byte[] interfaceBytes = interfaceName.getBytes();
		int interfaceLength = interfaceBytes.length;
		int totalLength = HEADER_LEN + 8 + interfaceLength + beanIdLength;
		byte[] bytes = new byte[totalLength];
		int next = 0;

		for (int i = 0; i < HEADER_LEN; ++i) {
			bytes[next++] = header[i];
		}

		if (EJSPlatformHelper.isZOS()) {
			bytes[next++] = (byte) (interfaceIndex >> 24);
			bytes[next++] = (byte) (interfaceIndex >> 16);
			bytes[next++] = (byte) (interfaceIndex >> 8);
			bytes[next++] = (byte) interfaceIndex;
		} else {
			bytes[next++] = (byte) interfaceIndex;
			bytes[next++] = (byte) (interfaceIndex >> 8);
			bytes[next++] = (byte) (interfaceIndex >> 16);
			bytes[next++] = (byte) (interfaceIndex >> 24);
		}

		if (EJSPlatformHelper.isZOS()) {
			bytes[next++] = (byte) (interfaceLength >> 24);
			bytes[next++] = (byte) (interfaceLength >> 16);
			bytes[next++] = (byte) (interfaceLength >> 8);
			bytes[next++] = (byte) interfaceLength;
		} else {
			bytes[next++] = (byte) interfaceLength;
			bytes[next++] = (byte) (interfaceLength >> 8);
			bytes[next++] = (byte) (interfaceLength >> 16);
			bytes[next++] = (byte) (interfaceLength >> 24);
		}

		System.arraycopy(interfaceBytes, 0, bytes, next, interfaceLength);
		next += interfaceLength;
		this.ivInterfaceIndex = interfaceIndex;
		this.ivInterfaceClassName = interfaceName;
		this.ivBeanIdIndex = next;
		System.arraycopy(beanId, 0, bytes, next, beanIdLength);
		this.updateBytes(bytes);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init> : " + this.ivInterfaceIndex + " : " + this.ivBeanIdIndex + " : "
					+ this.ivInterfaceClassName);
		}

	}

	protected WrapperId() {
	}

	protected WrapperId(WrapperId wId) {
		super(wId);
		this.ivInterfaceIndex = wId.ivInterfaceIndex;
		this.ivInterfaceClassName = wId.ivInterfaceClassName;
		this.ivBeanIdIndex = wId.ivBeanIdIndex;
	}

	public com.ibm.ejs.container.util.ByteArray getBeanIdArray() {
		int beanIdLength = this.data.length - this.ivBeanIdIndex;
		byte[] beanIdBytes = new byte[beanIdLength];
		System.arraycopy(this.data, this.ivBeanIdIndex, beanIdBytes, 0, beanIdLength);
		return new com.ibm.ejs.container.util.ByteArray(beanIdBytes);
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		header = new byte[]{-83, -84, 0, 2, 0, 1};
		HEADER_LEN = header.length;
	}
}