package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_fr extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: Une incohérence a été détectée dans les niveaux de compilation des composants clients installés pour le serveur d''applications. Le niveau de compilation {1} est installé pour le composant client {0}, alors que le niveau de compilation {3} est installé pour le composant client {2}."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: Une incohérence a été détectée dans les niveaux de compilation des composants clients installés pour le serveur d'applications : l'exécution ne peut pas se poursuivre."},
			{"EXCP_CWSJE0003E", "CWSJE0003E: Impossible d''accéder à la ressource {1} à cause de l''exception : {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}