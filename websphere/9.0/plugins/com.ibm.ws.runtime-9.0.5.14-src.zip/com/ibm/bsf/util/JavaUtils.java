package com.ibm.bsf.util;

import com.ibm.bsf.debug.util.DebugLog;
import java.io.IOException;

public class JavaUtils {
	public static boolean JDKcompile(String var0, String var1) {
		DebugLog.stderrPrintln("JavaEngine: Compiling " + var0, 1);
		DebugLog.stderrPrintln("JavaEngine: Classpath is " + var1, 1);
		String var2 = DebugLog.getLogLevel() > 0 ? "-g" : "-O";
		String[] var3 = new String[]{"javac", var2, "-classpath", var1, var0};

		try {
			Process var4 = Runtime.getRuntime().exec(var3);
			var4.waitFor();
			return var4.exitValue() != 0;
		} catch (IOException var5) {
			DebugLog.stderrPrintln("ERROR: IO exception during exec(javac).", 1);
		} catch (SecurityException var6) {
			DebugLog.stderrPrintln("ERROR: Unable to create subprocess to exec(javac).", 1);
		} catch (InterruptedException var7) {
			DebugLog.stderrPrintln("ERROR: Wait for exec(javac) was interrupted.", 1);
		}

		return false;
	}
}