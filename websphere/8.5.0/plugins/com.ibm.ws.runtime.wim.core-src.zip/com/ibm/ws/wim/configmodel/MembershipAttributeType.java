package com.ibm.ws.wim.configmodel;

public interface MembershipAttributeType {
	String getName();

	void setName(String var1);

	String getScope();

	void setScope(String var1);

	void unsetScope();

	boolean isSetScope();
}