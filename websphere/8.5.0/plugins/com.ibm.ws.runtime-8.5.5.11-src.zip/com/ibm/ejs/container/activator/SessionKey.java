package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.ContainerAS;

class SessionKey {
	ContainerAS as;
	BeanId id;

	SessionKey(ContainerAS as, BeanId id) {
		this.as = as;
		this.id = id;
	}

	public final int hashCode() {
		return (this.as != null ? this.as.hashCode() : 0) + this.id.hashCode();
	}

	public final boolean equals(Object o) {
		if (!(o instanceof SessionKey)) {
			return false;
		} else {
			boolean var10000;
			label21 : {
				SessionKey key = (SessionKey) o;
				if (this.as != null) {
					if (!this.as.equals(key.as)) {
						break label21;
					}
				} else if (key.as != null) {
					break label21;
				}

				if (this.id.equals(key.id)) {
					var10000 = true;
					return var10000;
				}
			}

			var10000 = false;
			return var10000;
		}
	}

	public final boolean equals(SessionKey key) {
		if (key == null) {
			return false;
		} else {
			boolean var10000;
			label21 : {
				if (this.as != null) {
					if (!this.as.equals(key.as)) {
						break label21;
					}
				} else if (key.as != null) {
					break label21;
				}

				if (this.id.equals(key.id)) {
					var10000 = true;
					return var10000;
				}
			}

			var10000 = false;
			return var10000;
		}
	}

	public String toString() {
		return "ActivationKey(" + this.as + ", " + this.id + ")";
	}
}