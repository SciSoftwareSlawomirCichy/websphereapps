package com.ibm.ffdc.util.formatting;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class DateFormatProvider {
	public static DateFormat getDateFormat() {
		DateFormat formatter = DateFormat.getDateTimeInstance(3, 2);
		SimpleDateFormat formatter;
		if (formatter instanceof SimpleDateFormat) {
			SimpleDateFormat sdFormatter = (SimpleDateFormat) formatter;
			String pattern = sdFormatter.toPattern();
			int patternLength = pattern.length();
			int endOfSecsIndex = pattern.lastIndexOf(115) + 1;
			String newPattern = pattern.substring(0, endOfSecsIndex) + ":SSS z";
			if (endOfSecsIndex < patternLength) {
				newPattern = newPattern + pattern.substring(endOfSecsIndex, patternLength);
			}

			newPattern = newPattern.replace('h', 'H');
			newPattern = newPattern.replace('K', 'H');
			newPattern = newPattern.replace('k', 'H');
			newPattern = newPattern.replace('a', ' ');
			newPattern = newPattern.trim();
			sdFormatter.applyPattern(newPattern);
			formatter = sdFormatter;
		} else {
			formatter = new SimpleDateFormat("yy.MM.dd HH:mm:ss:SSS z");
		}

		return formatter;
	}
}