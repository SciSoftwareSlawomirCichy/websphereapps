package com.ibm.ejs.cm;

import com.ibm.ejs.cm.logger.TraceWriter;
import com.ibm.ejs.cm.pool.ConnectionFactory;
import com.ibm.ejs.cm.pool.JDBC1xConnectionFactory;
import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.cm.portability.PortabilityLayerFactory;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.PrintWriter;
import java.io.Writer;
import java.sql.SQLException;
import javax.sql.ConnectionPoolDataSource;

class JDBC1PhaseRF extends DataSourceImpl {
	private static final TraceComponent tc = Tr.register(JDBC1PhaseRF.class);

	JDBC1PhaseRF(CMProperties attrs) {
		super(attrs);
	}

	protected ConnectionFactory createConnectionFactory() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createConnectionFactory");
		}

		DataSourceProperties dsProps = this.attrs.getDataSourceProperties();
		PortabilityLayer pbl = PortabilityLayerFactory.getPortabilityLayer(dsProps);
		ConnectionPoolDataSource ds = pbl.getDataSource(dsProps);
		Writer w = new TraceWriter("jdbc." + this.attrs.getName());
		if (((TraceWriter) w).isTraceEnabled()) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Setting DataSource PrintWriter");
			}

			ds.setLogWriter(new PrintWriter(w));
		}

		ConnectionFactory factory = new JDBC1xConnectionFactory(ds);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createConnectionFactory", factory);
		}

		return factory;
	}
}