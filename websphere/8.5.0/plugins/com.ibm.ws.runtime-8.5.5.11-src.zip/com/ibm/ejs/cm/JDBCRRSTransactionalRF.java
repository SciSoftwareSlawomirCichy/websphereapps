package com.ibm.ejs.cm;

import com.ibm.ejs.cm.JDBCRRSTransactionalRF.1;
import com.ibm.ejs.cm.logger.TraceWriter;
import com.ibm.ejs.cm.pool.ConnectionFactory;
import com.ibm.ejs.cm.pool.RRSJdbcConnectionFactory;
import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.cm.portability.PortabilityLayerFactory;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.util.AccessController;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.security.PrivilegedActionException;
import java.sql.SQLException;
import javax.sql.ConnectionPoolDataSource;

class JDBCRRSTransactionalRF extends DataSourceImpl {
	private static final TraceComponent tc = Tr.register(JDBCRRSTransactionalRF.class);

	JDBCRRSTransactionalRF(CMProperties attrs) {
		super(attrs);
	}

	protected ConnectionFactory createConnectionFactory() throws SQLException {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "createConnectionFactory");
      }

      DataSourceProperties dsProps = this.attrs.getDataSourceProperties();
      String currentSQLID = null;
      String temp = dsProps.getProperty("currentSQLID");
      if (temp != null && temp.trim().length() > 0) {
         String dsClassName = dsProps.getDataSourceClassName();
         PropertyDescriptor[] descriptors = null;

         try {
            Class dsClass = Class.forName(dsClassName);
            descriptors = (PropertyDescriptor[])((PropertyDescriptor[])AccessController.doPrivileged(new 1(this, dsClass)));
            boolean sqlidExistsOnDS = false;

            for(int i = 0; i < descriptors.length; ++i) {
               if (descriptors[i].getName().equals("currentSQLID")) {
                  sqlidExistsOnDS = true;
                  break;
               }
            }

            if (!sqlidExistsOnDS) {
               if (tc.isDebugEnabled()) {
                  Tr.debug(tc, "Setting currentSQLID on the DataSource to: " + temp);
               }

               currentSQLID = temp;
               dsProps.remove("currentSQLID");
            } else if (tc.isDebugEnabled()) {
               Tr.debug(tc, "currentSQLID will be passed to physical DS");
            }
         } catch (ClassNotFoundException var9) {
            Tr.error(tc, "MSG_CONM_7001E", new Object[]{dsClassName, var9});
         } catch (PrivilegedActionException var10) {
            IntrospectionException ie = (IntrospectionException)var10.getException();
            Tr.error(tc, "MSG_CONM_7001E", new Object[]{dsClassName, ie});
         }
      }

      PortabilityLayer pbl = PortabilityLayerFactory.getPortabilityLayer(dsProps);
      ConnectionPoolDataSource ds = pbl.getDataSource(dsProps);
      Writer w = new TraceWriter("RRSTransactionalJdbc." + this.attrs.getName());
      if (((TraceWriter)w).isTraceEnabled()) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Setting DataSource PrintWriter");
         }

         ds.setLogWriter(new PrintWriter(w));
      }

      ConnectionFactory factory = new RRSJdbcConnectionFactory(ds);
      if (currentSQLID != null) {
         ((RRSJdbcConnectionFactory)factory).setCurrentSQLID(currentSQLID);
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "createConnectionFactory", factory);
      }

      return factory;
   }
}