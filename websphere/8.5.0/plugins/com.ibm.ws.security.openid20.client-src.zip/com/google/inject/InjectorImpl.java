package com.google.inject;

import com.google.inject.InjectorImpl.1;
import com.google.inject.InjectorImpl.2;
import com.google.inject.InjectorImpl.3;
import com.google.inject.InjectorImpl.4;
import com.google.inject.InjectorImpl.BindingsMultimap;
import com.google.inject.InjectorImpl.ConvertedConstantBindingImpl;
import com.google.inject.InjectorImpl.ProviderBindingImpl;
import com.google.inject.internal.Annotations;
import com.google.inject.internal.BindingImpl;
import com.google.inject.internal.Classes;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.ImmutableList;
import com.google.inject.internal.ImmutableSet;
import com.google.inject.internal.InstanceBindingImpl;
import com.google.inject.internal.InternalContext;
import com.google.inject.internal.InternalFactory;
import com.google.inject.internal.LinkedBindingImpl;
import com.google.inject.internal.LinkedProviderBindingImpl;
import com.google.inject.internal.Maps;
import com.google.inject.internal.MatcherAndConverter;
import com.google.inject.internal.Nullable;
import com.google.inject.internal.Scoping;
import com.google.inject.internal.SourceProvider;
import com.google.inject.internal.ToStringBuilder;
import com.google.inject.spi.Dependency;
import java.lang.annotation.Annotation;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

class InjectorImpl implements Injector, Lookups {
	final State state;
	final InjectorImpl parent;
	final BindingsMultimap bindingsMultimap = new BindingsMultimap((1)null);
	final Initializer initializer;
	final Map<Key<?>, BindingImpl<?>> jitBindings = Maps.newHashMap();
	Lookups lookups = new DeferredLookups(this);
	final ConstructorInjectorStore constructors = new ConstructorInjectorStore(this);
	MembersInjectorStore membersInjectorStore;
	final ThreadLocal<Object[]> localContext;

	InjectorImpl(@Nullable InjectorImpl parent, State state, Initializer initializer) {
      this.parent = parent;
      this.state = state;
      this.initializer = initializer;
      if (parent != null) {
         this.localContext = parent.localContext;
      } else {
         this.localContext = new 1(this);
      }

   }

	void index() {
		Iterator i$ = this.state.getExplicitBindingsThisLevel().values().iterator();

		while (i$.hasNext()) {
			Binding<?> binding = (Binding) i$.next();
			this.index(binding);
		}

	}

	<T> void index(Binding<T> binding) {
		this.bindingsMultimap.put(binding.getKey().getTypeLiteral(), binding);
	}

	public <T> List<Binding<T>> findBindingsByType(TypeLiteral<T> type) {
		return this.bindingsMultimap.getAll(type);
	}

	public <T> BindingImpl<T> getBinding(Key<T> key) {
		Errors errors = new Errors(key);

		try {
			BindingImpl<T> result = this.getBindingOrThrow(key, errors);
			errors.throwConfigurationExceptionIfErrorsExist();
			return result;
		} catch (ErrorsException var4) {
			throw new ConfigurationException(errors.merge(var4.getErrors()).getMessages());
		}
	}

	public <T> BindingImpl<T> getBindingOrThrow(Key<T> key, Errors errors) throws ErrorsException {
		BindingImpl<T> binding = this.state.getExplicitBinding(key);
		return binding != null ? binding : this.getJustInTimeBinding(key, errors);
	}

	public <T> Binding<T> getBinding(Class<T> type) {
		return this.getBinding(Key.get(type));
	}

	public Injector getParent() {
		return this.parent;
	}

	public Injector createChildInjector(Iterable<? extends Module> modules) {
		return (new InjectorBuilder()).parentInjector(this).addModules(modules).build();
	}

	public Injector createChildInjector(Module... modules) {
		return this.createChildInjector((Iterable) ImmutableList.of(modules));
	}

	private <T> BindingImpl<T> getJustInTimeBinding(Key<T> key, Errors errors) throws ErrorsException {
		synchronized (this.state.lock()) {
			for (InjectorImpl injector = this; injector != null; injector = injector.parent) {
				BindingImpl<T> binding = (BindingImpl) injector.jitBindings.get(key);
				if (binding != null) {
					return binding;
				}
			}

			return this.createJustInTimeBindingRecursive(key, errors);
		}
	}

	static boolean isProvider(Key<?> key) {
		return key.getTypeLiteral().getRawType().equals(Provider.class);
	}

	static boolean isMembersInjector(Key<?> key) {
		return key.getTypeLiteral().getRawType().equals(MembersInjector.class) && !key.hasAnnotationType();
	}

	private <T> BindingImpl<MembersInjector<T>> createMembersInjectorBinding(Key<MembersInjector<T>> key, Errors errors)
			throws ErrorsException {
		Type membersInjectorType = key.getTypeLiteral().getType();
		if (!(membersInjectorType instanceof ParameterizedType)) {
			throw errors.cannotInjectRawMembersInjector().toException();
		} else {
			TypeLiteral<T> instanceType = TypeLiteral
					.get(((ParameterizedType) membersInjectorType).getActualTypeArguments()[0]);
			MembersInjector<T> membersInjector = this.membersInjectorStore.get(instanceType, errors);
			InternalFactory<MembersInjector<T>> factory = new ConstantFactory(Initializables.of(membersInjector));
			return new InstanceBindingImpl(this, key, SourceProvider.UNKNOWN_SOURCE, factory, ImmutableSet.of(),
					membersInjector);
		}
	}

	private <T> BindingImpl<Provider<T>> createProviderBinding(Key<Provider<T>> key, Errors errors)
			throws ErrorsException {
		Type providerType = key.getTypeLiteral().getType();
		if (!(providerType instanceof ParameterizedType)) {
			throw errors.cannotInjectRawProvider().toException();
		} else {
			Type entryType = ((ParameterizedType) providerType).getActualTypeArguments()[0];
			Key<T> providedKey = key.ofType(entryType);
			BindingImpl<T> delegate = this.getBindingOrThrow(providedKey, errors);
			return new ProviderBindingImpl(this, key, delegate);
		}
	}

	private <T> BindingImpl<T> convertConstantStringBinding(Key<T> key, Errors errors) throws ErrorsException {
		Key<String> stringKey = key.ofType(String.class);
		BindingImpl<String> stringBinding = this.state.getExplicitBinding(stringKey);
		if (stringBinding != null && stringBinding.isConstant()) {
			String stringValue = (String) stringBinding.getProvider().get();
			Object source = stringBinding.getSource();
			TypeLiteral<T> type = key.getTypeLiteral();
			MatcherAndConverter matchingConverter = this.state.getConverter(stringValue, type, errors, source);
			if (matchingConverter == null) {
				return null;
			} else {
				try {
					T converted = matchingConverter.getTypeConverter().convert(stringValue, type);
					if (converted == null) {
						throw errors.converterReturnedNull(stringValue, source, type, matchingConverter).toException();
					} else if (!type.getRawType().isInstance(converted)) {
						throw errors.conversionTypeError(stringValue, source, type, matchingConverter, converted)
								.toException();
					} else {
						return new ConvertedConstantBindingImpl(this, key, converted, stringBinding);
					}
				} catch (ErrorsException var10) {
					throw var10;
				} catch (RuntimeException var11) {
					throw errors.conversionError(stringValue, source, type, matchingConverter, var11).toException();
				}
			}
		} else {
			return null;
		}
	}

	<T> void initializeBinding(BindingImpl<T> binding, Errors errors) throws ErrorsException {
		if (binding instanceof ConstructorBindingImpl) {
			Key<T> key = binding.getKey();
			this.jitBindings.put(key, binding);
			boolean successful = false;

			try {
				((ConstructorBindingImpl) binding).initialize(this, errors);
				successful = true;
			} finally {
				if (!successful) {
					this.jitBindings.remove(key);
				}

			}
		}

	}

	<T> BindingImpl<T> createUnitializedBinding(Key<T> key, Scoping scoping, Object source, Errors errors)
			throws ErrorsException {
		Class<?> rawType = key.getTypeLiteral().getRawType();
		if (!rawType.isArray() && !rawType.isEnum()) {
			if (rawType == TypeLiteral.class) {
				BindingImpl<T> binding = this.createTypeLiteralBinding(key, errors);
				return binding;
			} else {
				ImplementedBy implementedBy = (ImplementedBy) rawType.getAnnotation(ImplementedBy.class);
				if (implementedBy != null) {
					Annotations.checkForMisplacedScopeAnnotations(rawType, source, errors);
					return this.createImplementedByBinding(key, scoping, implementedBy, errors);
				} else {
					ProvidedBy providedBy = (ProvidedBy) rawType.getAnnotation(ProvidedBy.class);
					if (providedBy != null) {
						Annotations.checkForMisplacedScopeAnnotations(rawType, source, errors);
						return this.createProvidedByBinding(key, scoping, providedBy, errors);
					} else if (Modifier.isAbstract(rawType.getModifiers())) {
						throw errors.missingImplementation(key).toException();
					} else if (Classes.isInnerClass(rawType)) {
						throw errors.cannotInjectInnerClass(rawType).toException();
					} else {
						if (!scoping.isExplicitlyScoped()) {
							Class<? extends Annotation> scopeAnnotation = Annotations.findScopeAnnotation(errors,
									rawType);
							if (scopeAnnotation != null) {
								scoping = Scopes.makeInjectable(Scoping.forAnnotation(scopeAnnotation), this,
										errors.withSource(rawType));
							}
						}

						return ConstructorBindingImpl.create(this, key, source, scoping);
					}
				}
			}
		} else {
			throw errors.missingImplementation(key).toException();
		}
	}

	private <T> BindingImpl<TypeLiteral<T>> createTypeLiteralBinding(Key<TypeLiteral<T>> key, Errors errors)
			throws ErrorsException {
		Type typeLiteralType = key.getTypeLiteral().getType();
		if (!(typeLiteralType instanceof ParameterizedType)) {
			throw errors.cannotInjectRawTypeLiteral().toException();
		} else {
			ParameterizedType parameterizedType = (ParameterizedType) typeLiteralType;
			Type innerType = parameterizedType.getActualTypeArguments()[0];
			if (!(innerType instanceof Class) && !(innerType instanceof GenericArrayType)
					&& !(innerType instanceof ParameterizedType)) {
				throw errors.cannotInjectTypeLiteralOf(innerType).toException();
			} else {
				TypeLiteral<T> value = TypeLiteral.get(innerType);
				InternalFactory<TypeLiteral<T>> factory = new ConstantFactory(Initializables.of(value));
				return new InstanceBindingImpl(this, key, SourceProvider.UNKNOWN_SOURCE, factory, ImmutableSet.of(),
						value);
			}
		}
	}

	<T> BindingImpl<T> createProvidedByBinding(Key<T> key, Scoping scoping, ProvidedBy providedBy, Errors errors) throws ErrorsException {
      Class<?> rawType = key.getTypeLiteral().getRawType();
      Class<? extends Provider<?>> providerType = providedBy.value();
      if (providerType == rawType) {
         throw errors.recursiveProviderType().toException();
      } else {
         Key<? extends Provider<T>> providerKey = Key.get(providerType);
         BindingImpl<? extends Provider<?>> providerBinding = this.getBindingOrThrow(providerKey, errors);
         InternalFactory<T> internalFactory = new 2(this, providerKey, providerBinding, rawType, providerType);
         return new LinkedProviderBindingImpl(this, key, rawType, Scopes.scope(key, this, internalFactory, scoping), scoping, providerKey);
      }
   }

	<T> BindingImpl<T> createImplementedByBinding(Key<T> key, Scoping scoping, ImplementedBy implementedBy, Errors errors) throws ErrorsException {
      Class<?> rawType = key.getTypeLiteral().getRawType();
      Class<?> implementationType = implementedBy.value();
      if (implementationType == rawType) {
         throw errors.recursiveImplementationType().toException();
      } else if (!rawType.isAssignableFrom(implementationType)) {
         throw errors.notASubtype(implementationType, rawType).toException();
      } else {
         Key<? extends T> targetKey = Key.get(implementationType);
         BindingImpl<? extends T> targetBinding = this.getBindingOrThrow(targetKey, errors);
         InternalFactory<T> internalFactory = new 3(this, targetBinding, targetKey);
         return new LinkedBindingImpl(this, key, rawType, Scopes.scope(key, this, internalFactory, scoping), scoping, targetKey);
      }
   }

	private <T> BindingImpl<T> createJustInTimeBindingRecursive(Key<T> key, Errors errors) throws ErrorsException {
		if (this.parent != null) {
			try {
				return this.parent.createJustInTimeBindingRecursive(key, new Errors());
			} catch (ErrorsException var4) {
				;
			}
		}

		if (this.state.isBlacklisted(key)) {
			throw errors.childBindingAlreadySet(key).toException();
		} else {
			BindingImpl<T> binding = this.createJustInTimeBinding(key, errors);
			this.state.parent().blacklist(key);
			this.jitBindings.put(key, binding);
			return binding;
		}
	}

	<T> BindingImpl<T> createJustInTimeBinding(Key<T> key, Errors errors) throws ErrorsException {
		if (this.state.isBlacklisted(key)) {
			throw errors.childBindingAlreadySet(key).toException();
		} else {
			BindingImpl convertedBinding;
			if (isProvider(key)) {
				convertedBinding = this.createProviderBinding(key, errors);
				return convertedBinding;
			} else if (isMembersInjector(key)) {
				convertedBinding = this.createMembersInjectorBinding(key, errors);
				return convertedBinding;
			} else {
				convertedBinding = this.convertConstantStringBinding(key, errors);
				if (convertedBinding != null) {
					return convertedBinding;
				} else if (!key.hasAnnotationType()) {
					Object source = key.getTypeLiteral().getRawType();
					BindingImpl<T> binding = this.createUnitializedBinding(key, Scoping.UNSCOPED, source, errors);
					this.initializeBinding(binding, errors);
					return binding;
				} else {
					if (key.hasAttributes()) {
						try {
							Errors ignored = new Errors();
							return this.getBindingOrThrow(key.withoutAttributes(), ignored);
						} catch (ErrorsException var6) {
							;
						}
					}

					throw errors.missingImplementation(key).toException();
				}
			}
		}
	}

	<T> InternalFactory<? extends T> getInternalFactory(Key<T> key, Errors errors) throws ErrorsException {
		return this.getBindingOrThrow(key, errors).getInternalFactory();
	}

	public Map<Key<?>, Binding<?>> getBindings() {
		return this.state.getExplicitBindingsThisLevel();
	}

	SingleParameterInjector<?>[] getParametersInjectors(List<Dependency<?>> parameters, Errors errors)
			throws ErrorsException {
		if (parameters.isEmpty()) {
			return null;
		} else {
			int numErrorsBefore = errors.size();
			SingleParameterInjector<?>[] result = new SingleParameterInjector[parameters.size()];
			int i = 0;
			Iterator i$ = parameters.iterator();

			while (i$.hasNext()) {
				Dependency parameter = (Dependency) i$.next();

				try {
					result[i++] = this.createParameterInjector(parameter, errors.withSource(parameter));
				} catch (ErrorsException var9) {
					;
				}
			}

			errors.throwIfNewErrors(numErrorsBefore);
			return result;
		}
	}

	<T> SingleParameterInjector<T> createParameterInjector(Dependency<T> dependency, Errors errors)
			throws ErrorsException {
		InternalFactory<? extends T> factory = this.getInternalFactory(dependency.getKey(), errors);
		return new SingleParameterInjector(dependency, factory);
	}

	public void injectMembers(Object instance) {
		MembersInjector membersInjector = this.getMembersInjector(instance.getClass());
		membersInjector.injectMembers(instance);
	}

	public <T> MembersInjector<T> getMembersInjector(TypeLiteral<T> typeLiteral) {
		Errors errors = new Errors(typeLiteral);

		try {
			return this.membersInjectorStore.get(typeLiteral, errors);
		} catch (ErrorsException var4) {
			throw new ConfigurationException(errors.merge(var4.getErrors()).getMessages());
		}
	}

	public <T> MembersInjector<T> getMembersInjector(Class<T> type) {
		return this.getMembersInjector(TypeLiteral.get(type));
	}

	public <T> Provider<T> getProvider(Class<T> type) {
		return this.getProvider(Key.get(type));
	}

	<T> Provider<T> getProviderOrThrow(Key<T> key, Errors errors) throws ErrorsException {
      InternalFactory<? extends T> factory = this.getInternalFactory(key, errors);
      Dependency<T> dependency = Dependency.get(key);
      return new 4(this, dependency, factory);
   }

	public <T> Provider<T> getProvider(Key<T> key) {
		Errors errors = new Errors(key);

		try {
			Provider<T> result = this.getProviderOrThrow(key, errors);
			errors.throwIfNewErrors(0);
			return result;
		} catch (ErrorsException var4) {
			throw new ConfigurationException(errors.merge(var4.getErrors()).getMessages());
		}
	}

	public <T> T getInstance(Key<T> key) {
		return this.getProvider(key).get();
	}

	public <T> T getInstance(Class<T> type) {
		return this.getProvider(type).get();
	}

	<T> T callInContext(ContextualCallable<T> callable) throws ErrorsException {
		Object[] reference = (Object[]) this.localContext.get();
		if (reference[0] == null) {
			reference[0] = new InternalContext();

			Object var3;
			try {
				var3 = callable.call((InternalContext) reference[0]);
			} finally {
				reference[0] = null;
			}

			return var3;
		} else {
			return callable.call((InternalContext) reference[0]);
		}
	}

	public String toString() {
		return (new ToStringBuilder(Injector.class)).add("bindings", this.state.getExplicitBindingsThisLevel().values())
				.toString();
	}
}