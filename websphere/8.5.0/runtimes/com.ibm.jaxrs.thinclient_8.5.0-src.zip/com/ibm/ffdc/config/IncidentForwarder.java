package com.ibm.ffdc.config;

import com.ibm.ffdc.util.provider.Incident;

public interface IncidentForwarder {
	void process(Incident var1, Throwable var2);
}