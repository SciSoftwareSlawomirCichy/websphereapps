package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.csi.BeanManaged.InactivityAlarm;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.tx.jta.embeddable.EmbeddableTransactionManagerFactory;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.Transaction.NativeJDBCDriverHelper;
import com.ibm.ws.Transaction.TxProperties;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.tx.embeddable.EmbeddableWebSphereTransactionManager;
import java.util.Hashtable;
import javax.transaction.Transaction;

final class BeanManaged extends TranStrategy {
	private static final TraceComponent tc = Tr.register(BeanManaged.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private Hashtable<EJBKey, Transaction> suspendedBeans = new Hashtable();
	EmbeddableWebSphereTransactionManager tm = EmbeddableTransactionManagerFactory.getTransactionManager();
	private static final String CLASS_NAME = "com.ibm.ejs.csi.BeanManaged";

	BeanManaged(TransactionControlImpl txCtrl) {
		super(txCtrl);
	}

	TxCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		Transaction control = null;
		TxCookieImpl returnCookie = null;
		Transaction suspended = null;
		LocalTransactionCoordinator savedLocalTx = this.suspendLocalTx();
		if (this.globalTxExists(false)) {
			suspended = this.suspendGlobalTx(2);
		}

		control = (Transaction) this.suspendedBeans.remove(key);
		if (control != null) {
			this.tm.stopInactivityTimer(control);

			try {
				this.resumeGlobalTx(control, 2);
			} catch (CSIException var11) {
				try {
					if (suspended != null) {
						this.resumeGlobalTx(suspended, 2);
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "Resumed suspended global tran after resume of sticky tran failed");
						}
					} else if (savedLocalTx != null) {
						this.resumeLocalTx(savedLocalTx);
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "Resume of suspended local tx after resume of sticky tran failed");
						}
					}
				} catch (Throwable var10) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Resume of suspended global tran after resume of sticky tran failed");
					}

					if (!(var10 instanceof CSIException)) {
						FFDCFilter.processException(var11, "com.ibm.ejs.csi.BeanManaged.preinvoke", "139", this);
					}
				}

				throw new CSITransactionRolledbackException("Failed to resume transaction, possibly rolled back",
						var11);
			}

			returnCookie = new TxCookieImpl(false, false, this, suspended);
		} else {
			int EJBVersion = methodInfo.getBeanMetaData().getEJBModuleVersion();
			if (EJBVersion < 20 && !TxProperties.LTC_ALWAYS_REQUIRED) {
				returnCookie = new TxCookieImpl(false, false, this, suspended);
			} else {
				returnCookie = this.beginLocalTx(key, methodInfo, suspended);
			}
		}

		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		returnCookie.suspendedLocalTx = savedLocalTx;
		return returnCookie;
	}

	void postInvoke(EJBKey key, TxCookieImpl txCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		if (this.globalTxExists(false)) {
			if (!txCookie.methodInfo.isStatefulSessionBean()) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc,
							"Illegal Bean Managed Transaction: Only stateful session bean initiated transactions may span method requests.");
				}

				this.rollback(true, key, methodInfo);
				throw new CSITransactionRolledbackException();
			}

			CSITransactionRolledbackException rollbe = null;

			try {
				this.txCtrl.completeTxTimeout();
			} catch (CSITransactionRolledbackException var8) {
				this.rollback(false, key, methodInfo);
				rollbe = var8;
			}

			Transaction control = this.suspendGlobalTx(0);
			this.suspendedBeans.put(key, control);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Added to suspendedBeans list");
			}

			if (this.tm.startInactivityTimer(control, new InactivityAlarm(this, control))) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Inactivity timer started");
				}
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Failed to start inactivity timer: transaction not active or never times out");
			}

			if (EJSPlatformHelper.isZOS()) {
				NativeJDBCDriverHelper.threadSwitch();
			}

			if (rollbe != null) {
				throw rollbe;
			}
		} else {
			int EJBVersion = methodInfo.getBeanMetaData().getEJBModuleVersion();
			if (EJBVersion >= 20 || TxProperties.LTC_ALWAYS_REQUIRED) {
				if (this.txCtrl.getRollbackOnly()) {
					this.rollback(true, key, methodInfo);
				} else {
					this.commit(key, methodInfo);
				}
			}
		}

		if (entryEnabled) {
			Tr.exit(tc, "postInvoke");
		}

	}

	public void handleException(EJBKey key, TxCookieImpl txCookie, ExceptionType exType, EJBMethodInfoImpl methodInfo)
			throws CSIException {
		if (exType == ExceptionType.UNCHECKED_EXCEPTION && this.globalTxExists(false) && !txCookie.beginner) {
			if (txCookie.methodInfo.isStatefulSessionBean()) {
				this.rollback(true, key, methodInfo);
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc,
							"Illegal Bean Managed Transaction: Only stateful session bean initiated transactions may span method requests.");
				}

				this.rollback(true, key, methodInfo);
				throw new CSITransactionRolledbackException();
			}
		} else {
			super.handleException(key, txCookie, exType, methodInfo);
		}
	}

	boolean isBmtActive() {
		try {
			return this.globalTxExists(false);
		} catch (CSIException var2) {
			return false;
		}
	}
}