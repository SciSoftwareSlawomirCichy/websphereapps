package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.SchemaConstants;
import com.ibm.websphere.wim.exception.CertificateMapperException;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.InvalidInitPropertyException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.util.NodeHelper;
import com.ibm.ws.wim.util.StringLengthComparator;
import com.ibm.ws.wim.util.UniqueNameHelper;
import commonj.sdo.DataObject;
import commonj.sdo.Type;
import java.io.UnsupportedEncodingException;
import java.security.cert.X509Certificate;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

public class LdapConfigManager implements ConfigConstants, SchemaConstants, LdapConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = LdapConfigManager.class.getName();
	private static final Logger trcLogger;
	private ConfigManager iConfigMgr = null;
	private SchemaManager iSchemaMgr = null;
	private String iLdapType = null;
	private String[] iNodes = null;
	private String[] iNodesForCompare = null;
	private String[] iLdapNodes = null;
	private String[] iLdapNodesForCompare = null;
	private String[] iTopLdapNodes = null;
	private boolean iNeedSwitchNode = false;
	private boolean iNeedTranslateRDN = false;
	private List iLdapEntityTypeList = null;
	private LdapEntity[] iLdapEntities = null;
	private Set iAttrs = null;
	private Set iOperAttrs = null;
	private Set iDefaultValueAttrs = null;
	private Set iDefaultAttrAttrs = null;
	private Map iAttrNameToAttrMap = null;
	private Map iPropToAttrMap = null;
	private Map iAttrToPropMap = null;
	private Set iExtIds = null;
	private Set iConAttrs = null;
	private boolean isAnyExtIdDN = false;
	private String[] iMbrAttrs = null;
	private boolean iMbrAttrsAllScope = false;
	private boolean iMbrAttrsNestedScope = false;
	private short[] iMbrAttrScope = null;
	private Map iMbrAttrMap = null;
	private Map iDummyMbrMap = null;
	private boolean iUseDefaultMbrAttr = false;
	private String[] iDynaMbrAttrs = null;
	private Map iDynaMbrAttrMap = null;
	private List iDynaMbrObjectClass = new ArrayList();
	private String iDynaGrpFilter = null;
	private String iGrpMbrFilter = null;
	private String iMembershipAttrName = null;
	private short iMembershipAttrScope = 0;
	private List iLoginAttrs = null;
	private char[] iSpecialChars = new char[]{'(', ')', '\\'};
	private List iPersonAccountTypes = null;
	private List iPersonTypes = null;
	private List iGroupTypes = null;
	private String[] iGroupSearchBases = null;
	private boolean iUpdateGrpMbrship = false;
	private List iDataTypes = null;
	private List entityTypeProps = new ArrayList(3);
	public MessageFormat[] CONDITION_FORMATS = new MessageFormat[]{new MessageFormat("({0}={1})"),
			new MessageFormat("(!({0}={1}))"), new MessageFormat("(&({0}>={1})(!({0}={1})))"),
			new MessageFormat("(&({0}<={1})(!({0}={1})))"), new MessageFormat("({0}>={1})"),
			new MessageFormat("({0}<={1})")};
	private String iCertMapMode = null;
	private String[] iCertFilterEles = null;
	private String ldapTimestampFormat = null;
	private HashMap<String, String> iCustomProperties = null;
	private boolean usePrincipalNameForLogin = false;
	private boolean returnDNWithOutSpaceInGetMembers = false;
	private boolean includeGroupInSearchEntityTypes = false;
	private String useEncodingInSearchExpression = null;
	private boolean returnUniqueNameInNormalCaseIfExtIdMapToDN = false;
	private static boolean caseSensitiveDNForAttributeCache;
	private boolean minimizeContextPoolThreadBlock = true;
	private int maxThreadsToBlock = 5;
	private int bindTimeout = 1000;
	private String domainNameForAutomaticDiscoveryOfLDAPServers = null;
	private String isPolicyEnforced = null;
	private String vmmHandleReferal = "ignore";
	private String preFetchData = null;
	private Map<String, List> preFetchDataMap = null;
	private String ldapLoginGroupFilter = null;

	public LdapConfigManager() throws WIMException {
		this.iConfigMgr = ConfigManager.singleton();
		this.iSchemaMgr = SchemaManager.singleton();
	}

	public void initialize(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize(DataObject)");
		}

		this.iLdapType = var1.getString("ldapServerType");
		if (this.iLdapType == null) {
			this.iLdapType = "IDS52";
		} else {
			this.iLdapType = this.iLdapType.toUpperCase();
		}

		this.setCertificateMapMode(var1.getString("certificateMapMode"));
		if ("filterDescriptorMode".equalsIgnoreCase(this.getCertificateMapMode())) {
			this.setCertificateFilter(var1.getString("certificateFilter"));
		}

		this.setNodes(var1.getList("baseEntries"));
		this.setLDAPEntities(var1.getList("ldapEntityTypes"));
		this.setGroupConfiguration(var1.getDataObject("groupConfiguration"));
		DataObject var3 = var1.getDataObject("attributeConfiguration");
		this.setAttributes(var3);
		this.setExtIdAttributes(var3);
		this.setRDNProperties();
		this.setConfidentialAttributes();
		this.setGroupMemberFilter();
		this.setLoginProperties(var1.getList("loginProperties"));
		List var4 = var1.getList("CustomProperties");
		if (var4 != null & !var4.isEmpty()) {
			this.iCustomProperties = new HashMap();
			String var5 = null;
			String var6 = null;

			for (int var7 = 0; var7 < var4.size(); ++var7) {
				DataObject var8 = (DataObject) var4.get(var7);
				var5 = var8.getString("name");
				var6 = var8.getString("value");
				this.iCustomProperties.put(var5, var6);
			}

			if (this.iCustomProperties.containsKey("useInputPrincipalNameForLogin")) {
				var6 = (String) this.iCustomProperties.get("useInputPrincipalNameForLogin");
				if (var6.equalsIgnoreCase("true")) {
					this.usePrincipalNameForLogin = true;
				}
			}

			if (this.iCustomProperties.containsKey("returnDNWithOutSpaceInGetMembers")) {
				var6 = (String) this.iCustomProperties.get("returnDNWithOutSpaceInGetMembers");
				this.returnDNWithOutSpaceInGetMembers = Boolean.parseBoolean(var6);
			}

			if (this.iCustomProperties.containsKey("com.ibm.ws.wim.adapter.ldap.returnNestedNonGroupMembers")) {
				var6 = (String) this.iCustomProperties.get("com.ibm.ws.wim.adapter.ldap.returnNestedNonGroupMembers");
				if (var6.equalsIgnoreCase("true")) {
					this.includeGroupInSearchEntityTypes = true;
				}
			}

			if (this.iCustomProperties.containsKey("ldapTimestampFormat")) {
				var6 = (String) this.iCustomProperties.get("ldapTimestampFormat");
				this.ldapTimestampFormat = var6;
			}

			if (this.iCustomProperties.containsKey("useEncodingInSearchExpression")) {
				this.useEncodingInSearchExpression = (String) this.iCustomProperties
						.get("useEncodingInSearchExpression");

				try {
					"(c) Copyright International Business Machines Corporation 2005"
							.getBytes(this.useEncodingInSearchExpression);
				} catch (UnsupportedEncodingException var9) {
					trcLogger.logp(Level.WARNING, CLASSNAME, "initialize(DataObject)",
							"java.io.UnsupportedEncodingException: " + var9.getMessage());
					this.useEncodingInSearchExpression = "ISO8859_1";
				}
			}

			if (this.iCustomProperties.containsKey("returnUniqueNameInNormalCaseIfExtIdMapToDN")) {
				var6 = (String) this.iCustomProperties.get("returnUniqueNameInNormalCaseIfExtIdMapToDN");
				this.returnUniqueNameInNormalCaseIfExtIdMapToDN = Boolean.parseBoolean(var6);
			}

			if (this.iCustomProperties.containsKey("caseSensitiveDNForAttributeCache")) {
				var6 = (String) this.iCustomProperties.get("caseSensitiveDNForAttributeCache");
				caseSensitiveDNForAttributeCache = Boolean.parseBoolean(var6);
			}

			if (this.iCustomProperties.containsKey("minimizeContextPoolThreadBlock")) {
				var6 = (String) this.iCustomProperties.get("minimizeContextPoolThreadBlock");
				this.minimizeContextPoolThreadBlock = Boolean.parseBoolean(var6);
			}

			if (this.iCustomProperties.containsKey("maxThreadsToBlock")) {
				var6 = (String) this.iCustomProperties.get("maxThreadsToBlock");
				this.setMaxThreadsToBlock(Integer.parseInt(var6));
			}

			if (this.iCustomProperties.containsKey("bindTimeout")) {
				var6 = (String) this.iCustomProperties.get("bindTimeout");
				this.setBindTimeout(Integer.parseInt(var6));
			}

			if (this.iCustomProperties.containsKey("domainNameForAutomaticDiscoveryOfLDAPServers")) {
				var6 = (String) this.iCustomProperties.get("domainNameForAutomaticDiscoveryOfLDAPServers");
				this.domainNameForAutomaticDiscoveryOfLDAPServers = var6;
			}

			if (this.iCustomProperties.containsKey("preFetchData")) {
				var6 = (String) this.iCustomProperties.get("preFetchData");
				this.preFetchData = var6;
			}

			if (this.iCustomProperties.containsKey("vmmHandleReferal")) {
				var6 = (String) this.iCustomProperties.get("vmmHandleReferal");
				this.vmmHandleReferal = var6.toString();
			}

			if (this.iCustomProperties.containsKey("ldapLoginGroupFilter")) {
				var6 = (String) this.iCustomProperties.get("ldapLoginGroupFilter");
				this.ldapLoginGroupFilter = var6;
			}

			if (this.iCustomProperties.containsKey("isPolicyEnforced")) {
				var6 = (String) this.iCustomProperties.get("isPolicyEnforced");
				this.isPolicyEnforced = var6;
			}
		}

		if (this.getPreFetchData() != null) {
			this.populatePreFetchDataMap();
		}

		this.iNeedTranslateRDN = var1.getBoolean("translateRDN");
		this.entityTypeProps.add("parent");
		this.entityTypeProps.add("children");
		this.entityTypeProps.add("members");
		if (trcLogger.isLoggable(Level.FINE)) {
			StringBuffer var10 = new StringBuffer();
			var10.append("LDAPServerType: ").append(this.iLdapType).append("\n");
			var10.append("Nodes: ").append(WIMTraceHelper.printObjectArray(this.iNodes)).append("\n");
			var10.append("ReposNodes: ").append(WIMTraceHelper.printObjectArray(this.iLdapNodes)).append("\n");
			var10.append("TopReposNodes: ").append(WIMTraceHelper.printObjectArray(this.iTopLdapNodes)).append("\n");
			var10.append("NeedSwitchNode: ").append(this.iNeedSwitchNode).append("\n");
			var10.append("LDAPEntities: ").append("\n");

			for (int var11 = 0; var11 < this.iLdapEntities.length; ++var11) {
				var10.append(this.iLdapEntities[var11].toString());
			}

			var10.append("GroupMemberAttrs: ").append(this.iMbrAttrMap).append("memberAttrs: ")
					.append(WIMTraceHelper.printObjectArray(this.iMbrAttrs)).append("scopes: ")
					.append(WIMTraceHelper.printShortArray(this.iMbrAttrScope)).append("\n");
			var10.append("GroupMemberFilter: ").append(this.iGrpMbrFilter).append("\n");
			var10.append("GroupDynaMemberAttrs: ").append(this.iDynaMbrAttrMap).append("\n");
			var10.append("DynaGroupFilter: ").append(this.iDynaGrpFilter).append("\n");
			var10.append("GroupMembershipAttrs: ").append(this.iMembershipAttrName).append(" scope: ")
					.append(this.iMembershipAttrScope).append("\n");
			var10.append("PropToAttrMap: ").append(this.iPropToAttrMap).append("\n");
			var10.append("AttrToPropMap: ").append(this.iAttrToPropMap).append("\n");
			var10.append("ExtIds: ").append(this.iExtIds).append("\n");
			var10.append("AllAttrs: ").append(this.iAttrs).append("\n");
			var10.append("ConfidentialAttrs: ").append(this.iConAttrs).append("\n");
			var10.append("LoginAttrs: ").append(this.iLoginAttrs).append("\n");
			trcLogger.logp(Level.FINE, CLASSNAME, "initialize(DataObject)", var10.toString());
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize(DataObject)");
		}

	}

	public List getLoginAttributes() {
		return this.iLoginAttrs;
	}

	private void setLoginProperties(List var1) {
		if (this.iPersonAccountTypes.size() > 0) {
			LdapEntity var2 = this
					.getLdapEntity((String) this.iPersonAccountTypes.get(this.iPersonAccountTypes.size() - 1));
			this.iLoginAttrs = new ArrayList();

			int var3;
			String var4;
			for (var3 = 0; var3 < var1.size(); ++var3) {
				var4 = (String) var1.get(var3);
				this.iLoginAttrs.add(this.getAttributeName(var2, var4));
			}

			if (this.iLoginAttrs.size() == 0) {
				String[][] var7 = var2.getRDNAttributes();
				this.iLoginAttrs.add(var7[0][0]);
			}

			for (var3 = 0; var3 < this.iPersonAccountTypes.size(); ++var3) {
				var4 = (String) this.iPersonAccountTypes.get(var3);
				LdapEntity var5 = this.getLdapEntity(var4);
				String var6 = (String) this.iLoginAttrs.get(0);
				var5.addPropertyAttributeMap("principalName", var6);
			}
		}

	}

	public String switchToNode(String var1) {
		if (var1 != null && this.iNeedSwitchNode) {
			String var2 = var1.toLowerCase();
			StringBuffer var3 = new StringBuffer(var1);
			boolean var4 = false;
			String var5 = null;
			int var6 = 0;

			for (int var7 = this.iLdapNodesForCompare.length; var6 < var7; ++var6) {
				int var8 = var2.indexOf(this.iLdapNodesForCompare[var6]);
				if (var8 > -1) {
					if (var8 == 0) {
						if (this.iLdapNodesForCompare[var6].length() > 0) {
							return this.iNodes[var6];
						}

						var5 = this.iNodes[var6];
						if (var5 != null && var5.length() != 0) {
							var3.append(",");
						}

						var4 = true;
					} else {
						var3 = new StringBuffer(var3.substring(0, var8));
						var5 = this.iNodes[var6];
						var4 = true;
					}
					break;
				}
			}

			if (!var4) {
				return var1;
			} else {
				if (var5 != null && var5.length() != 0) {
					var3.append(var5);
				} else if (var5 != null) {
					var3 = new StringBuffer(var3.substring(0, var3.length() - 1));
				}

				return var3.toString();
			}
		} else {
			return var1;
		}
	}

	public String switchToLdapNode(String var1) {
		if (var1 != null && this.iNeedSwitchNode) {
			StringBuffer var2 = new StringBuffer(var1);
			String var3 = var1.toLowerCase();
			String var4 = null;
			int var5 = 0;

			for (int var6 = this.iNodesForCompare.length; var5 < var6; ++var5) {
				int var7 = var3.lastIndexOf(this.iNodesForCompare[var5]);
				if (var7 > -1) {
					if (var7 == 0) {
						if (this.iNodesForCompare[var5].length() > 0
								&& this.iNodesForCompare[var5].length() == var1.length()) {
							return this.iLdapNodes[var5];
						}

						if (this.iLdapNodes[var5].length() > 0) {
							var4 = "," + this.iLdapNodes[var5];
						} else {
							var4 = this.iLdapNodes[var5];
						}
					} else if (var1.length() - var7 == this.iNodesForCompare[var5].length()) {
						var4 = this.iLdapNodes[var5];
						if (var4 != null && var4.length() == 0 && var2.charAt(var7 - 1) == ',') {
							var2 = new StringBuffer(var2.substring(0, var7 - 1));
						} else {
							var2 = new StringBuffer(var2.substring(0, var7));
						}
						break;
					}
				}
			}

			if (var4 != null) {
				var2.append(var4);
			}

			return var2.toString();
		} else {
			return var1;
		}
	}

	private String[] getRepositoryNodes() {
		return this.iLdapNodes;
	}

	private String[] getRepositoryNodesForCompare() {
		return this.iLdapNodesForCompare;
	}

	private String[] getNodes() {
		return this.iNodes;
	}

	private String[] getNodesForCompare() {
		return this.iNodesForCompare;
	}

	public String[] getTopLdapNodes() {
		return this.iTopLdapNodes;
	}

	public String getLdapNode(String var1) {
		var1 = var1.toLowerCase();

		for (int var2 = 0; var2 < this.iNodesForCompare.length; ++var2) {
			if (this.iNodesForCompare[var2].equals(var1)) {
				return this.iLdapNodes[var2];
			}
		}

		return null;
	}

	public String getNode(String var1) {
		var1 = var1.toLowerCase();

		for (int var2 = 0; var2 < this.iLdapNodesForCompare.length; ++var2) {
			if (this.iLdapNodesForCompare[var2].equals(var1)) {
				return this.iNodes[var2];
			}
		}

		return null;
	}

	public void addBaseEntry(String var1, String var2) {
		if (var2 == null) {
			var2 = var1;
		} else if (!this.iNeedSwitchNode && !var1.equalsIgnoreCase(var2)) {
			this.iNeedSwitchNode = true;
		}

		String var4 = var1.toLowerCase();
		HashMap var5 = new HashMap(this.iNodesForCompare.length);
		HashMap var6 = new HashMap(this.iNodesForCompare.length);
		var5.put(var4, var1);
		var6.put(var4, var2);

		for (int var7 = 0; var7 < this.iNodesForCompare.length; ++var7) {
			var5.put(this.iNodesForCompare[var7], this.iNodes[var7]);
			var6.put(this.iNodesForCompare[var7], this.iLdapNodes[var7]);
		}

		String[] var12 = new String[this.iNodesForCompare.length + 1];
		System.arraycopy(this.iNodesForCompare, 0, var12, 0, this.iNodesForCompare.length);
		var12[var12.length - 1] = var1.toLowerCase();
		Arrays.sort(var12, new StringLengthComparator());
		String[] var8 = new String[this.iNodesForCompare.length + 1];
		String[] var9 = new String[this.iLdapNodes.length + 1];
		String[] var10 = new String[this.iLdapNodesForCompare.length + 1];

		for (int var11 = 0; var11 < var12.length; ++var11) {
			var8[var11] = (String) var5.get(var12[var11]);
			var9[var11] = (String) var6.get(var12[var11]);
			var10[var11] = var9[var11].toLowerCase();
		}

		this.iNodes = var8;
		this.iNodesForCompare = var12;
		this.iLdapNodes = var9;
		this.iLdapNodesForCompare = var10;
		this.iTopLdapNodes = NodeHelper.getTopNodes(var10);
		if (trcLogger.isLoggable(Level.FINE)) {
			StringBuffer var13 = new StringBuffer();
			var13.append("Nodes: ").append(WIMTraceHelper.printObjectArray(this.iNodes)).append("\n");
			var13.append("NodesForCompare: ").append(WIMTraceHelper.printObjectArray(this.iNodesForCompare))
					.append("\n");
			var13.append("ReposNodes: ").append(WIMTraceHelper.printObjectArray(this.iLdapNodes)).append("\n");
			var13.append("ReposNodesForCompare: ").append(WIMTraceHelper.printObjectArray(this.iLdapNodesForCompare))
					.append("\n");
			var13.append("TopReposNodes: ").append(WIMTraceHelper.printObjectArray(this.iTopLdapNodes)).append("\n");
			var13.append("NeedSwitchNode: ").append(this.iNeedSwitchNode).append("\n");
			trcLogger.logp(Level.FINE, CLASSNAME, "addBaseEntry", var13.toString());
		}

	}

	private void setNodes(List var1) throws InvalidInitPropertyException {
		int var3 = var1.size();
		HashMap var4 = new HashMap(var3);
		HashMap var5 = new HashMap(var3);
		String[] var6 = new String[var3];

		int var7;
		String var10;
		String var11;
		for (var7 = 0; var7 < var1.size(); ++var7) {
			DataObject var8 = (DataObject) var1.get(var7);
			String var9 = UniqueNameHelper.getValidUniqueName(var8.getString("name"));
			if (var9 == null) {
				throw new InvalidInitPropertyException("INVALID_UNIQUE_NAME_SYNTAX",
						WIMMessageHelper.generateNullMsgParms(), CLASSNAME, "setNodes(List)");
			}

			var10 = var8.getString("nameInRepository");
			if (var10 == null) {
				var10 = var9;
			} else {
				var10 = LdapHelper.getValidDN(var10);
				if (var10 == null) {
					throw new InvalidInitPropertyException("INVALID_DN_SYNTAX", WIMMessageHelper.generateNullMsgParms(),
							CLASSNAME, "setNodes(List)");
				}
			}

			if (!this.iNeedSwitchNode && !var9.equalsIgnoreCase(var10)) {
				this.iNeedSwitchNode = true;
			}

			var6[var7] = var10;
			var11 = var9.toLowerCase();
			var4.put(var11, var9);
			var5.put(var11, var10);
		}

		var7 = var4.size();
		String[] var14 = (String[]) ((String[]) var4.keySet().toArray(new String[0]));
		Arrays.sort(var14, new StringLengthComparator());
		this.iNodes = new String[var7];
		this.iNodesForCompare = new String[var7];
		this.iLdapNodes = new String[var7];
		this.iLdapNodesForCompare = new String[var7];

		for (int var15 = 0; var15 < var7; ++var15) {
			var10 = var14[var15];
			var11 = (String) var4.get(var10);
			String var12 = (String) var5.get(var10);
			String var13 = var12.toLowerCase();
			this.iNodes[var15] = var11;
			this.iNodesForCompare[var15] = var10;
			this.iLdapNodes[var15] = var12;
			this.iLdapNodesForCompare[var15] = var13;
		}

		this.iTopLdapNodes = NodeHelper.getTopNodes(var6);
	}

	private void setDefaultLDAPEntries() throws WIMException {
		byte var1 = 3;
		this.iLdapEntityTypeList = new ArrayList(var1);
		this.iLdapEntities = new LdapEntity[var1];
		this.iPersonAccountTypes = new ArrayList(var1);
		this.iPersonTypes = new ArrayList(var1);
		this.iGroupTypes = new ArrayList(var1);
		ArrayList var2 = new ArrayList();
		LdapEntity var3 = new LdapEntity("PersonAccount");
		ArrayList var4 = new ArrayList();
		if (this.iLdapType.startsWith("AD")) {
			var4.add("user");
		} else {
			var4.add("inetOrgPerson");
		}

		var3.setObjectClasses(var4);
		var3.setObjectClassesForCreate(var4);
		if (this.iLdapType.startsWith("AD")) {
			var3.setSearchFilter("(ObjectCategory=Person)");
		} else {
			var3.setSearchFilter((String) null);
		}

		var3.setSearchBases(this.getTopLdapNodes());
		this.iLdapEntityTypeList.add("PersonAccount");
		this.iLdapEntities[0] = var3;
		this.iPersonAccountTypes.add("PersonAccount");
		var3 = new LdapEntity("Group");
		var4 = new ArrayList();
		if (this.iLdapType.startsWith("AD")) {
			var4.add("group");
		} else {
			var4.add("groupOfNames");
		}

		var3.setObjectClasses(var4);
		var3.setObjectClassesForCreate(var4);
		if (this.iLdapType.startsWith("AD")) {
			var3.setSearchFilter("(ObjectCategory=Group)");
		} else {
			var3.setSearchFilter((String) null);
		}

		this.iLdapEntityTypeList.add("Group");
		this.iLdapEntities[1] = var3;
		this.iGroupTypes.add("Group");
		var3.setSearchBases(this.getTopLdapNodes());
		var2.addAll(var3.getSearchBaseList());
		this.iGroupSearchBases = (String[]) ((String[]) var2.toArray(new String[0]));
		this.iGroupSearchBases = NodeHelper.getTopNodes(this.iGroupSearchBases);
		var3 = new LdapEntity("OrgContainer");
		String[][] var5 = new String[][]{{"o"}, {"ou"}};
		String[] var6 = new String[]{"organization", "organizationalUnit"};
		var3.setRDNAttributes(var5, var6);
		var4 = new ArrayList();
		var4.add("organization");
		var4.add("organizationalUnit");
		var3.setObjectClasses(var4);
		var3.setObjectClassesForCreate(var4);
		var3.setSearchFilter((String) null);
		this.iLdapEntityTypeList.add("OrgContainer");
		this.iLdapEntities[2] = var3;
		var3.setSearchBases(this.getTopLdapNodes());
	}

	public void addAttribute(DataObject var1) {
		String var2 = var1.getString("name");
		String var3 = var2.toLowerCase();
		LdapAttribute var4 = (LdapAttribute) this.iAttrNameToAttrMap.get(var3);
		if (var4 == null) {
			var4 = new LdapAttribute(var2);
			this.iAttrNameToAttrMap.put(var3, var4);
		}

		var4.setSyntax(var1.getString("syntax"));
		String var5 = var1.getString("propertyName");
		List var6 = var1.getList("entityTypes");
		int var10;
		if (var6.size() == 0) {
			if (var5 != null) {
				this.iPropToAttrMap.put(var5, var2);
				Object var7 = (Set) this.iAttrToPropMap.get(var3);
				if (var7 == null) {
					var7 = new HashSet();
					this.iAttrToPropMap.put(var3, var7);
				}

				((Set) var7).add(var5);
			}

			if (var1.isSet("defaultValue")) {
				this.iDefaultValueAttrs.add(var3);

				for (var10 = 0; var10 < this.iLdapEntityTypeList.size(); ++var10) {
					var4.setDefaultValue((String) this.iLdapEntityTypeList.get(var10), var1.getString("defaultValue"));
				}
			}

			if (var1.isSet("defaultAttribute")) {
				this.iDefaultAttrAttrs.add(var3);

				for (var10 = 0; var10 < this.iLdapEntityTypeList.size(); ++var10) {
					var4.setDefaultAttribute((String) this.iLdapEntityTypeList.get(var10),
							var1.getString("defaultAttribute"));
				}
			}

			for (var10 = 0; var10 < this.iLdapEntities.length; ++var10) {
				if (this.iLdapEntities[var10].getProperty(var5) != null) {
					this.iLdapEntities[var10].addPropertyAttributeMap(var5, var2);
				}
			}
		} else {
			for (var10 = 0; var10 < var6.size(); ++var10) {
				String var8 = (String) var6.get(var10);
				if (var5 != null) {
					LdapEntity var9 = this.getLdapEntity(var8);
					var9.addPropertyAttributeMap(var5, var2);
				}

				var4.addEntityType(var8);
				if (var1.isSet("defaultValue")) {
					this.iDefaultValueAttrs.add(var3);
					var4.setDefaultValue(var8, var1.getString("defaultValue"));
				}

				if (var1.isSet("defaultAttribute")) {
					this.iDefaultAttrAttrs.add(var3);
					var4.setDefaultAttribute(var8, var1.getString("defaultAttribute"));
				}
			}
		}

	}

	public void addLdapEntity(DataObject var1) throws DynamicUpdateConfigException, WIMException {
		String var3 = var1.getString("name");
		if (this.getLdapEntity(var3) != null) {
			throw new DynamicUpdateConfigException("DUPLICATE_ENTITY_TYPE", WIMMessageHelper.generateMsgParms(var3),
					CLASSNAME, "addLdapEntity");
		} else {
			LdapEntity var4 = new LdapEntity(var1);
			if (var4.getSearchBases() == null) {
				var4.setSearchBases(this.getTopLdapNodes());
			} else {
				String[] var5 = var4.getSearchBases();
				String[] var6 = new String[var5.length];

				for (int var7 = 0; var7 < var5.length; ++var7) {
					var6[var7] = this.switchToLdapNode(var5[var7]);
				}

				var4.setSearchBases(var6);
			}

			var4.setExtId((String) this.iExtIds.iterator().next());
			List var11 = this.iConfigMgr.getRDNProperties(var3);
			String[][] var12 = new String[var11.size()][];
			String[][] var13 = new String[var11.size()][];

			for (int var8 = 0; var8 < var11.size(); ++var8) {
				var12[var8] = LdapHelper.getRDNs((String) var11.get(var8));
				var13[var8] = new String[var12[var8].length];

				for (int var9 = 0; var9 < var12[var8].length; ++var9) {
					String var10 = var12[var8][var9];
					var13[var8][var9] = this.getAttributeName(var4, var10);
				}
			}

			var4.setRDNProperties(var12, var13);
			if (this.iSchemaMgr.isSuperType("PersonAccount", var3)) {
				this.iPersonAccountTypes.add(var3);
			} else if (this.iSchemaMgr.isSuperType("Person", var3)) {
				this.iPersonTypes.add(var3);
			} else if (this.iSchemaMgr.isSuperType("Group", var3)) {
				this.iGroupTypes.add(var3);
				List var14 = var4.getSearchBaseList();
				String[] var16 = new String[this.iGroupSearchBases.length + var14.size()];
				System.arraycopy(this.iGroupSearchBases, 0, var16, 0, this.iGroupSearchBases.length);

				for (int var17 = this.iGroupSearchBases.length + 1; var17 < var16.length; ++var17) {
					var16[var17] = (String) var14.get(var17);
				}

				this.iGroupSearchBases = NodeHelper.getTopNodes(var16);
			}

			this.iLdapEntityTypeList.add(var3);
			LdapEntity[] var15 = new LdapEntity[this.iLdapEntities.length + 1];
			System.arraycopy(this.iLdapEntities, 0, var15, 0, this.iLdapEntities.length);
			var15[var15.length - 1] = var4;
			this.iLdapEntities = var15;
		}
	}

	private void setLDAPEntities(List var1) throws WIMException {
		int var3 = var1.size();
		if (var3 > 0) {
			this.iLdapEntityTypeList = new ArrayList(var3);
			this.iLdapEntities = new LdapEntity[var3];
			this.iPersonAccountTypes = new ArrayList(var3);
			this.iPersonTypes = new ArrayList(var3);
			this.iGroupTypes = new ArrayList(var3);
			ArrayList var4 = new ArrayList();

			for (int var5 = 0; var5 < var3; ++var5) {
				DataObject var6 = (DataObject) var1.get(var5);
				String var7 = var6.getString("name");
				if (this.getLdapEntity(var7) != null) {
					throw new InitializationException("DUPLICATE_ENTITY_TYPE", WIMMessageHelper.generateMsgParms(var7),
							CLASSNAME, "setLDAPEntities");
				}

				LdapEntity var8 = new LdapEntity(var6);
				if (var8.getSearchBases() == null) {
					var8.setSearchBases(this.getTopLdapNodes());
				} else {
					String[] var9 = var8.getSearchBases();
					String[] var10 = new String[var9.length];

					for (int var11 = 0; var11 < var9.length; ++var11) {
						var10[var11] = this.switchToLdapNode(var9[var11]);
					}

					var8.setSearchBases(var10);
				}

				this.iLdapEntityTypeList.add(var7);
				this.iLdapEntities[var5] = var8;
				if (this.iSchemaMgr.isSuperType("PersonAccount", var7)) {
					this.iPersonAccountTypes.add(var7);
				} else if (this.iSchemaMgr.isSuperType("Person", var7)) {
					this.iPersonTypes.add(var7);
				} else if (this.iSchemaMgr.isSuperType("Group", var7)) {
					this.iGroupTypes.add(var7);
					var4.addAll(var8.getSearchBaseList());
				}
			}

			this.iGroupSearchBases = (String[]) ((String[]) var4.toArray(new String[0]));
			this.iGroupSearchBases = NodeHelper.getTopNodes(this.iGroupSearchBases);
		} else {
			this.setDefaultLDAPEntries();
		}

	}

	public List getPersonTypes() {
		return this.iPersonTypes;
	}

	public List getGroupTypes() {
		return this.iGroupTypes;
	}

	public List getPersonAccountTypes() {
		return this.iPersonAccountTypes;
	}

	private void setRDNProperties() {
		List var1 = this.iConfigMgr.getSupportedEntityTypes();

		for (int var2 = 0; var2 < var1.size(); ++var2) {
			String var3 = (String) var1.get(var2);
			LdapEntity var4 = this.getLdapEntity(var3);
			if (var4 != null) {
				List var5 = this.iConfigMgr.getRDNProperties(var3);
				String[][] var6 = new String[var5.size()][];
				String[][] var7 = new String[var5.size()][];

				for (int var8 = 0; var8 < var5.size(); ++var8) {
					var6[var8] = LdapHelper.getRDNs((String) var5.get(var8));
					var7[var8] = new String[var6[var8].length];

					for (int var9 = 0; var9 < var6[var8].length; ++var9) {
						String var10 = var6[var8][var9];
						var7[var8][var9] = this.getAttributeName(var4, var10);
					}
				}

				var4.setRDNProperties(var6, var7);
				if (var4.needTranslateRDN()) {
					this.iNeedTranslateRDN = true;
				}
			}
		}

	}

	public LdapEntity[] getLdapEntities() {
		return this.iLdapEntities;
	}

	public String getLdapType() {
		return this.iLdapType;
	}

	public LdapEntity getLdapEntity(Type var1) {
		return this.getLdapEntity(this.iSchemaMgr.getQualifiedTypeName(var1.getURI(), var1.getName()));
	}

	private void setExtIdAttributes(DataObject var1) {
		this.iExtIds = new HashSet();
		List var2;
		if (var1 != null) {
			var2 = var1.getList("externalIdAttributes");
			int var3 = var2.size();

			for (int var4 = 0; var4 < var3; ++var4) {
				DataObject var5 = (DataObject) var2.get(var4);
				String var6 = var5.getString("name");
				LdapAttribute var7 = new LdapAttribute(var6);
				var7.setSyntax(var5.getString("syntax"));
				var7.setWIMGenerate(var5.getBoolean("wimGenerate"));
				this.iAttrNameToAttrMap.put(var6.toLowerCase(), var7);
				List var8 = var5.getList("entityTypes");
				int var9;
				if (var8.size() == 0) {
					for (var9 = 0; var9 < this.iLdapEntities.length; ++var9) {
						this.iLdapEntities[var9].setExtId(var6);
					}
				} else {
					for (var9 = 0; var9 < var8.size(); ++var9) {
						String var10 = (String) var8.get(var9);
						LdapEntity var11 = this.getLdapEntity(var10);
						var11.setExtId(var6);
					}
				}

				if (var6.equalsIgnoreCase("DistinguishedName")) {
					this.isAnyExtIdDN = true;
				}

				this.iExtIds.add(var6.toLowerCase());
			}
		}

		var2 = null;
		String var13 = "string";
		String var12;
		if (this.iLdapType.startsWith("IDS") && !this.iLdapType.startsWith("IDS4")) {
			var12 = "ibm-entryuuid";
		} else if (this.iLdapType.startsWith("AD")) {
			var12 = "objectguid";
			var13 = "octetString";
		} else if (this.iLdapType.startsWith("SUNONE")) {
			var12 = "nsuniqueid";
		} else if (this.iLdapType.startsWith("NDS")) {
			var12 = "guid";
			var13 = "octetString";
		} else {
			var12 = "DistinguishedName";
		}

		boolean var14 = false;

		for (int var15 = 0; var15 < this.iLdapEntities.length; ++var15) {
			if (this.iLdapEntities[var15].getExtId() == null) {
				this.iLdapEntities[var15].setExtId(var12);
				var14 = true;
			}
		}

		if (var14) {
			if (!var12.equalsIgnoreCase("DistinguishedName")) {
				this.iExtIds.add(var12.toLowerCase());
				LdapAttribute var16 = new LdapAttribute(var12);
				var16.setSyntax(var13);
				this.iAttrNameToAttrMap.put(var12.toLowerCase(), var16);
			} else {
				this.isAnyExtIdDN = true;
			}
		}

	}

	public void resetDefaultDominoExtIdAttribute(ArrayList var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "resetDefaultDominoExtIdAttribute()");
		}

		String var3 = "dominounid";

		for (int var4 = 0; var4 < this.iLdapEntities.length; ++var4) {
			if (var1 != null) {
				if (!var1.contains(this.iLdapEntities[var4].getName())) {
					this.iLdapEntities[var4].setExtId(var3);
				}
			} else if (this.iLdapEntities[var4].getExtId().equalsIgnoreCase("DistinguishedName")) {
				this.iLdapEntities[var4].setExtId(var3);
			}
		}

		this.iExtIds.add(var3.toLowerCase());
		LdapAttribute var5 = new LdapAttribute(var3);
		var5.setSyntax("string");
		this.iAttrNameToAttrMap.put(var3.toLowerCase(), var5);
		this.isAnyExtIdDN = false;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "resetDefaultDominoExtIdAttribute()");
		}

	}

	public Set getAttributesWithDefaultValue() {
		return this.iDefaultValueAttrs;
	}

	public Set getAttributesWithDefaultAttribute() {
		return this.iDefaultAttrAttrs;
	}

	private void setCertificateMapMode(String var1) {
		if ("filterDescriptorMode".equalsIgnoreCase(var1)) {
			this.iCertMapMode = "filterDescriptorMode";
		} else {
			this.iCertMapMode = "exactDNMode";
		}

	}

	private void setCertificateFilter(String var1) throws CertificateMapperException {
		this.iCertFilterEles = LdapHelper.parseFilterDescriptor(var1);
	}

	private String removeSpacesInDN(String var1) {
		String[] var2 = var1.split(",");
		StringBuilder var3 = new StringBuilder();

		for (int var4 = 0; var4 < var2.length; ++var4) {
			if (var2[var4].indexOf("=") >= 0) {
				var3.append(var2[var4].trim());
			} else {
				var3.append(var2[var4]);
			}

			if (var4 != var2.length - 1) {
				var3.append(",");
			}
		}

		return var3.toString();
	}

	public String getCertificateLDAPFilter(X509Certificate var1) throws CertificateMapperException {
		if (this.iCertFilterEles == null) {
			throw new CertificateMapperException("INVALID_CERTIFICATE_FILTER", CLASSNAME, "getCertificateLDAPFilter");
		} else {
			StringBuffer var3 = new StringBuffer();

			for (int var4 = 0; var4 < this.iCertFilterEles.length; ++var4) {
				String var5 = this.iCertFilterEles[var4];
				if (var5.charAt(0) != '$') {
					var3.append(var5);
				} else if (var5.equals("${UniqueKey}")) {
					var3.append(LdapHelper.getUniqueKey(var1));
				} else if (var5.equals("${PublicKey}")) {
					var3.append(var1.getPublicKey().getEncoded());
				} else if (!var5.equals("${BasicConstraints}")) {
					if (var5.startsWith("${Issuer")) {
						var3.append(LdapHelper.getDNSubField(var5.substring(8, var5.length() - 1),
								this.removeSpacesInDN(var1.getIssuerX500Principal().toString())));
					} else if (!var5.equals("${IssuerUniqueID}") && !var5.equals("${KeyUsage}")) {
						if (var5.equals("${NotAfter}")) {
							var3.append(var1.getNotAfter().toString());
						} else if (var5.equals("${NotBefore}")) {
							var3.append(var1.getNotBefore().toString());
						} else if (var5.equals("${SerialNumber}")) {
							var3.append(var1.getSerialNumber());
						} else if (var5.equals("${SigAlgName}")) {
							var3.append(var1.getSigAlgName());
						} else if (var5.equals("${SigAlgOID}")) {
							var3.append(var1.getSigAlgOID());
						} else if (var5.equals("${SigAlgParams}")) {
							var3.append(var1.getSigAlgParams());
						} else if (!var5.equals("${Signature}")) {
							if (var5.startsWith("${Subject")) {
								var3.append(LdapHelper.getDNSubField(var5.substring(9, var5.length() - 1),
										this.removeSpacesInDN(var1.getSubjectX500Principal().toString())));
							} else if (!var5.equals("${SubjectUniqueID}")) {
								if (var5.equals("${TBSCertificate}")) {
									throw new CertificateMapperException("getTBSCertificate() is unsupported");
								}

								if (!var5.equals("${Version}")) {
									throw new CertificateMapperException("unknown variable: " + var5);
								}

								var3.append(var1.getVersion());
							}
						}
					}
				}
			}

			return var3.toString();
		}
	}

	public String getCertificateMapMode() {
		return this.iCertMapMode;
	}

	private void setDefaultAttributes() {
		this.iDataTypes.add("String");
		this.iDataTypes.add("Base64Binary");
		LdapAttribute var1;
		HashSet var2;
		if (this.iLdapType.equals("ADAM")) {
			var1 = new LdapAttribute("unicodePwd");
			var1.setSyntax("unicodePwd");
			this.iAttrNameToAttrMap.put("unicodePwd".toLowerCase(), var1);
			this.iPropToAttrMap.put("password", "unicodePwd");
			var2 = new HashSet();
			var2.add("password");
			this.iAttrToPropMap.put("unicodePwd".toLowerCase(), var2);
			var1 = new LdapAttribute("groupType");
			this.iDefaultValueAttrs.add("groupType".toLowerCase());
			var1.setDefaultValue("Group", "8");
			this.iAttrNameToAttrMap.put("groupType".toLowerCase(), var1);
		} else if (this.iLdapType.startsWith("AD")) {
			var1 = new LdapAttribute("samAccountName");
			LdapEntity var4 = this.getLdapEntity("PersonAccount");
			var4.addPropertyAttributeMap("uid", "samAccountName");
			this.iDefaultAttrAttrs.add("samAccountName".toLowerCase());
			var1.addEntityType("Group");
			var1.setDefaultAttribute("Group", "cn");
			var1 = new LdapAttribute("unicodePwd");
			var1.setSyntax("unicodePwd");
			this.iAttrNameToAttrMap.put("unicodePwd".toLowerCase(), var1);
			this.iPropToAttrMap.put("password", "unicodePwd");
			HashSet var3 = new HashSet();
			var3.add("password");
			this.iAttrToPropMap.put("unicodePwd".toLowerCase(), var3);
			var1 = new LdapAttribute("userAccountControl");
			this.iDefaultValueAttrs.add("userAccountControl".toLowerCase());
			var1.setDefaultValue("PersonAccount", "544");
			this.iAttrNameToAttrMap.put("userAccountControl".toLowerCase(), var1);
			var1 = new LdapAttribute("groupType");
			this.iDefaultValueAttrs.add("groupType".toLowerCase());
			var1.setDefaultValue("Group", "8");
			this.iAttrNameToAttrMap.put("groupType".toLowerCase(), var1);
		} else {
			var1 = new LdapAttribute("userPassword");
			this.iAttrNameToAttrMap.put("userPassword".toLowerCase(), var1);
			this.iPropToAttrMap.put("password", "userPassword");
			var2 = new HashSet();
			var2.add("password");
			this.iAttrToPropMap.put("userPassword".toLowerCase(), var2);
		}

	}

	private void setAttributes(DataObject var1) {
		this.iAttrs = new HashSet();
		this.iOperAttrs = new HashSet();
		this.iAttrNameToAttrMap = new Hashtable();
		this.iPropToAttrMap = new Hashtable();
		this.iAttrToPropMap = new Hashtable();
		this.iDefaultValueAttrs = new HashSet();
		this.iDefaultAttrAttrs = new HashSet();
		this.iDataTypes = new ArrayList();
		HashSet var2 = new HashSet();
		HashMap var3 = new HashMap();
		String var13;
		if (var1 != null) {
			List var4 = var1.getList("attributes");
			int var5 = var4.size();

			for (int var6 = 0; var6 < var5; ++var6) {
				DataObject var7 = (DataObject) var4.get(var6);
				this.addAttribute(var7);
			}

			List var18 = var1.getList("propertiesNotSupported");
			int var20 = var18.size();

			for (int var8 = 0; var8 < var20; ++var8) {
				DataObject var9 = (DataObject) var18.get(var8);
				String var10 = var9.getString("name");
				List var11 = var9.getList("entityTypes");
				if (var11.size() == 0) {
					var2.add(var10);
					if (var10.equals("ibm-primaryEmail")) {
						var2.add("ibmPrimaryEmail");
					} else if (var10.equals("ibm-jobTitle")) {
						var2.add("ibmJobTitle");
					}
				} else {
					for (int var12 = 0; var12 < var11.size(); ++var12) {
						var13 = (String) var11.get(var12);
						Object var14 = (Set) var3.get(var13);
						if (var14 == null) {
							var14 = new HashSet();
							var3.put(var13, var14);
						}

						((Set) var14).add(var10);
						if (var10.equals("ibm-primaryEmail")) {
							((Set) var14).add("ibmPrimaryEmail");
						} else if (var10.equals("ibm-jobTitle")) {
							((Set) var14).add("ibmJobTitle");
						}
					}
				}
			}
		} else {
			this.setDefaultAttributes();
			var2.add("homeAddress");
			var2.add("businessAddress");
			if (this.iLdapType.startsWith("AD")) {
				var2.add("description");
				var2.add("jpegPhoto");
				var2.add("labeledURI");
				var2.add("carLicense");
				var2.add("pager");
				var2.add("roomNumber");
				var2.add("localityName");
				var2.add("stateOrProvinceName");
				var2.add("countryName");
				var2.add("employeeNumber");
				var2.add("employeeType");
				var2.add("businessCategory");
				var2.add("departmentNumber");
			}
		}

		this.iOperAttrs.add("createTimestamp");
		this.iOperAttrs.add("modifyTimestamp");

		for (int var16 = 0; var16 < this.iLdapEntities.length; ++var16) {
			LdapEntity var17 = this.iLdapEntities[var16];
			String var19 = var17.getName();
			EClass var21 = this.iSchemaMgr.getEClass(var19);
			if (var21 != null) {
				Set var22 = (Set) var3.get(var19);
				HashSet var23 = var2;
				if (var22 != null) {
					var2.addAll(var22);
				}

				EList var24 = var21.getEAllStructuralFeatures();

				for (int var25 = 0; var25 < var24.size(); ++var25) {
					EStructuralFeature var26 = (EStructuralFeature) var24.get(var25);
					var13 = this.iSchemaMgr.getQualifiedPropertyName(var26);
					if (!var23.contains(var13)) {
						String var27 = this.getAttributeName(var17, var13);
						String var15 = var26.getEType().getName();
						if (!this.iDataTypes.contains(var15)) {
							this.iDataTypes.add(var15);
						}

						if (!this.iOperAttrs.contains(var27)) {
							this.iAttrs.add(var27);
						}

						if (var17.getAttribute(var13) == null) {
							var17.addPropertyAttributeMap(var13, var27);
						}
					}
				}
			}
		}

	}

	public List getDataTypes() {
		return this.iDataTypes;
	}

	public boolean isPersistentProperty(String var1) {
		boolean var2 = true;
		return !"identifier".equals(var1) && !"partyRoles".equals(var1) && !"parent".equals(var1)
				&& !"children".equals(var1) && !"accounts".equals(var1) && !"groups".equals(var1)
				&& !"entitlementInfo".equals(var1) && !"groups".equals(var1) && !"children".equals(var1)
				&& !"members".equals(var1);
	}

	public String[] getAttributeNames(List var1, List var2, boolean var3, boolean var4) {
		HashSet var6 = new HashSet();
		ArrayList var7 = null;
		int var8;
		String var9;
		if (var1 != null && var1.size() > 0) {
			var7 = new ArrayList(var1.size());

			for (var8 = 0; var8 < var1.size(); ++var8) {
				var9 = (String) var1.get(var8);
				List var10 = this.getAllLdapEntities(var9);
				if (var10 != null) {
					var7.addAll(var10);
				}
			}
		}

		int var16;
		if (var2 != null) {
			for (var8 = 0; var8 < var2.size(); ++var8) {
				var9 = (String) var2.get(var8);
				LdapEntity var11;
				if (!"*".equals(var9)) {
					if (var7 != null && var7.size() > 0) {
						for (var16 = 0; var16 < var7.size(); ++var16) {
							var11 = (LdapEntity) var7.get(var16);
							var6.add(this.getAttributeName(var11, var9));
						}
					} else {
						var6.addAll(this.getAttributeNames(var9));
					}
				} else {
					if (var7 != null && var7.size() > 0) {
						for (var16 = 0; var16 < var7.size(); ++var16) {
							var11 = (LdapEntity) var7.get(var16);
							var6.addAll(var11.getAttributes());
						}
					} else {
						var6.addAll(this.getAllSuppotedAttributes());
					}

					var6.removeAll(this.entityTypeProps);
				}
			}
		}

		LdapEntity var13;
		if (this.getPreFetchData() != null && this.preFetchDataMap != null && var7 != null && var7.size() > 0) {
			for (var8 = 0; var8 < var7.size(); ++var8) {
				var13 = (LdapEntity) var7.get(var8);
				String var18 = var13.getName();
				if (var1.contains(var18) && this.preFetchDataMap.containsKey(var18)) {
					List var19 = (List) this.preFetchDataMap.get(var18);

					for (int var12 = 0; var12 < var19.size(); ++var12) {
						var6.add(this.getAttributeName(var13, (String) var19.get(var12)));
					}
				}
			}
		}

		int var15;
		if (var7 != null && var7.size() > 0) {
			for (var8 = 0; var8 < var7.size(); ++var8) {
				var13 = (LdapEntity) var7.get(var8);
				if (!"distinguishedName".equalsIgnoreCase(var13.getExtId())) {
					var6.add(var13.getExtId());
				}

				if (this.needTranslateRDN() && this.needTranslateRDN(var13.getName())) {
					var6.addAll(var13.getRDNAttributesList());
				}
			}
		} else {
			if (this.needTranslateRDN()) {
				LdapEntity[] var14 = this.getLdapEntities();

				for (var15 = 0; var15 < var14.length; ++var15) {
					var6.addAll(var14[var15].getRDNAttributesList());
				}
			}

			var6.addAll(this.getExtIds());
		}

		var6.add("objectClass");
		if (var3 && this.getMembershipAttribute() != null) {
			var6.add(this.getMembershipAttribute());
		}

		if (var4) {
			String[] var17 = this.getMemberAttributes();

			for (var15 = 0; var15 < var17.length; ++var15) {
				if (var17[var15] != null) {
					var6.add(var17[var15]);
				}
			}

			if (this.supportDynamicGroup()) {
				String[] var20 = this.getDynamicMemberAttributes();

				for (var16 = 0; var16 < var20.length; ++var16) {
					if (var20[var16] != null) {
						var6.add(var20[var16]);
					}
				}
			}
		}

		return (String[]) ((String[]) var6.toArray(new String[0]));
	}

	public String getAttributeName(LdapEntity var1, String var2) {
		String var3 = var1.getAttribute(var2);
		if (var3 == null) {
			var3 = (String) this.iPropToAttrMap.get(var2);
		}

		if (var3 == null) {
			int var4 = var2.indexOf(":");
			return var4 > -1 ? var2.substring(var4 + 1) : var2;
		} else {
			return var3;
		}
	}

	public Set getPropertyName(LdapEntity var1, String var2) {
		Object var3 = var1.getProperty(var2);
		if (var3 == null) {
			var3 = (Set) this.iAttrToPropMap.get(var2.toLowerCase());
		}

		if (var3 == null || ((Set) var3).size() == 0) {
			int var4 = var2.indexOf(";");
			if (var4 > 0) {
				String var5 = var2.substring(0, var4);
				var3 = var1.getProperty(var5);
				if (var3 == null) {
					var3 = (Set) this.iAttrToPropMap.get(var5.toLowerCase());
				}
			}

			if (var3 == null || ((Set) var3).size() == 0) {
				var3 = new HashSet();
				((Set) var3).add(var2);
			}
		}

		return (Set) var3;
	}

	public Set getAttributeNames(String var1) {
		HashSet var2 = new HashSet();

		for (int var3 = 0; var3 < this.iLdapEntities.length; ++var3) {
			String var4 = this.iLdapEntities[var3].getAttribute(var1);
			if (var4 != null) {
				var2.add(var4);
			}
		}

		String var5 = (String) this.iPropToAttrMap.get(var1);
		if (var5 != null) {
			var2.add(var5);
		}

		if (var2.size() == 0) {
			int var6 = var1.indexOf(":");
			if (var6 > -1) {
				var2.add(var1.substring(var6 + 1));
			} else {
				var2.add(var1);
			}
		}

		return var2;
	}

	public Set getAttributeNames(Set var1, String var2) {
		Object var3 = new HashSet();
		if (var1 == null) {
			var3 = this.getAttributeNames(var2);
		} else {
			Iterator var4 = var1.iterator();

			while (var4.hasNext()) {
				String var5 = (String) var4.next();
				LdapEntity var6 = this.getLdapEntity(var5);
				if (var6 != null) {
					String var7 = this.getAttributeName(var6, var2);
					if (var7 != null) {
						((Set) var3).add(var7);
					}
				}
			}
		}

		return (Set) var3;
	}

	public LdapEntity getLdapEntity(String var1) {
		if (var1 != null) {
			for (int var2 = 0; var2 < this.iLdapEntityTypeList.size(); ++var2) {
				String var3 = (String) this.iLdapEntityTypeList.get(var2);
				if (var3 != null && var3.equals(var1)) {
					return this.iLdapEntities[var2];
				}

				if (this.iSchemaMgr.isSuperType(var1, var3)) {
					return this.iLdapEntities[var2];
				}
			}
		}

		return null;
	}

	public List getAllLdapEntities(String var1) {
		if (var1 != null) {
			ArrayList var2 = new ArrayList();

			int var3;
			String var4;
			for (var3 = 0; var3 < this.iLdapEntityTypeList.size(); ++var3) {
				var4 = (String) this.iLdapEntityTypeList.get(var3);
				if (var4 != null && var4.equals(var1)) {
					var2.add(this.iLdapEntities[var3]);
				}
			}

			if (var2.size() != 0) {
				return var2;
			}

			for (var3 = 0; var3 < this.iLdapEntityTypeList.size(); ++var3) {
				var4 = (String) this.iLdapEntityTypeList.get(var3);
				if (this.iSchemaMgr.isSuperType(var1, var4)) {
					var2.add(this.iLdapEntities[var3]);
				}
			}

			if (var2.size() != 0) {
				return var2;
			}
		}

		return null;
	}

	public LdapAttribute getAttribute(String var1) {
		return (LdapAttribute) this.iAttrNameToAttrMap.get(var1.toLowerCase());
	}

	public Map getAttributes() {
		return this.iAttrNameToAttrMap;
	}

	public LdapAttribute getLdapAttribute(String var1) {
		return (LdapAttribute) this.iAttrNameToAttrMap.get(var1.toLowerCase());
	}

	public String getSyntax(String var1) {
		LdapAttribute var2 = (LdapAttribute) this.iAttrNameToAttrMap.get(var1.toLowerCase());
		return var2 != null ? var2.getSyntax() : "string";
	}

	public Set getConfidentialAttributes() {
		return this.iConAttrs;
	}

	public boolean isAnyExtIdDN() {
		return this.isAnyExtIdDN;
	}

	public Set getAllSuppotedAttributes() {
		return this.iAttrs;
	}

	public Set getOpertionalAttributes() {
		return this.iOperAttrs;
	}

	private void setConfidentialAttributes() {
		this.iConAttrs = new HashSet();
		this.iConAttrs.add("unicodePwd");
		this.iConAttrs.add("userPassword");
	}

	private void setGroupConfiguration(DataObject var1) {
		this.setUpdateGroupMembership(var1);
		this.setMemberAttributes(var1);
		this.setMembershipAttribute(var1);
		this.setDynaMemberAttributes(var1);
	}

	private static short getMembershipScope(String var0) {
		if (var0 != null) {
			var0 = var0.trim();
			if ("direct".equalsIgnoreCase(var0)) {
				return 0;
			} else if ("nested".equalsIgnoreCase(var0)) {
				return 1;
			} else {
				return (short) ("all".equalsIgnoreCase(var0) ? 2 : 0);
			}
		} else {
			return 0;
		}
	}

	private void setMembershipAttribute(DataObject var1) {
		DataObject var2 = null;
		if (var1 != null) {
			var2 = var1.getDataObject("membershipAttribute");
		}

		if (var2 == null) {
			if (this.iLdapType.startsWith("AD")) {
				this.iMembershipAttrName = "memberof";
				this.iMembershipAttrScope = 0;
			}
		} else {
			String var3 = var2.getString("name");
			if (var3.trim().length() == 0) {
				this.iMembershipAttrName = null;
			} else {
				this.iMembershipAttrName = var3;
				String var4 = var2.getString("scope");
				if (var4 == null) {
					this.iMembershipAttrScope = 0;
				} else {
					this.iMembershipAttrScope = LdapHelper.getMembershipScope(var4);
				}
			}
		}

	}

	private void setMemberAttributes(DataObject var1) {
		List var3 = null;
		if (var1 != null) {
			var3 = var1.getList("memberAttributes");
		}

		List var4 = this.getGroupTypes();
		ArrayList var5 = new ArrayList();

		int var6;
		int var9;
		for (var6 = 0; var6 < var4.size(); ++var6) {
			LdapEntity var7 = this.getLdapEntity((String) var4.get(var6));
			List var8 = var7.getObjectClasses();

			for (var9 = 0; var9 < var8.size(); ++var9) {
				String var10 = (String) var8.get(var9);
				var5.add(var10);
			}
		}

		this.iDummyMbrMap = new HashMap();
		if (var3 != null && var3.size() > 0) {
			var6 = var3.size();
			this.iMbrAttrMap = new HashMap(var6);
			ArrayList var16 = new ArrayList(var6);
			ArrayList var17 = new ArrayList(var6);

			for (var9 = 0; var9 < var6; ++var9) {
				DataObject var18 = (DataObject) var3.get(var9);
				String var11 = var18.getString("name");
				if (var11 != null && var11.trim().length() > 0) {
					String var12 = var18.getString("objectClass");
					String var13 = var18.getString("scope");
					String var14 = var18.getString("dummyMember");
					if (var13 == null) {
						var13 = "direct";
					}

					if (var12 == null) {
						for (int var15 = 0; var15 < var5.size(); ++var15) {
							this.iMbrAttrMap.put((String) var5.get(var15), var11);
						}
					} else {
						this.iMbrAttrMap.put(var12.toLowerCase(), var11);
					}

					if (var14 != null) {
						if (var14.trim().length() == 0) {
							this.iDummyMbrMap.remove(var11);
						} else {
							this.iDummyMbrMap.put(var11, var14);
						}
					} else if (this.iLdapType.startsWith("IDS") || this.iLdapType.startsWith("DOMINO")) {
						this.iDummyMbrMap.put(var11, "uid=dummy");
					}

					if (!var17.contains(var11)) {
						var17.add(var11);
						var16.add(var13);
					}

					if (var12 != null && !var5.contains(var12.toLowerCase())) {
						this.getLdapEntity((String) this.getGroupTypes().get(0)).addObjectClass(var12);
					}
				}
			}

			this.iMbrAttrs = (String[]) ((String[]) var17.toArray(new String[0]));
			this.iMbrAttrScope = new short[this.iMbrAttrs.length];
			this.iMbrAttrsAllScope = true;
			this.iMbrAttrsNestedScope = true;

			for (var9 = 0; var9 < var16.size(); ++var9) {
				this.iMbrAttrScope[var9] = LdapHelper.getMembershipScope((String) var16.get(var9));
				if (this.iMbrAttrScope[var9] == 0) {
					this.iMbrAttrsAllScope = false;
					this.iMbrAttrsNestedScope = false;
				} else if (this.iMbrAttrScope[var9] == 1) {
					this.iMbrAttrsAllScope = false;
				}
			}
		} else {
			this.iMbrAttrMap = new HashMap(var5.size());
			this.iMbrAttrScope = new short[var5.size()];

			for (var6 = 0; var6 < var5.size(); ++var6) {
				this.iMbrAttrMap.put((String) var5.get(var6), "member");
				this.iMbrAttrScope[var6] = 0;
			}

			this.iMbrAttrs = new String[1];
			this.iMbrAttrs[0] = "member";
			if (this.iLdapType.startsWith("IDS") || this.iLdapType.startsWith("DOMINO")) {
				this.iDummyMbrMap.put("member", "uid=dummy");
			}

			this.iUseDefaultMbrAttr = true;
		}

	}

	private void setDynaMemberAttributes(DataObject var1) {
		List var3 = null;
		if (var1 != null) {
			var3 = var1.getList("dynamicMemberAttributes");
		}

		LdapEntity var4 = this.getLdapEntity("Group");
		if (var3 != null && var3.size() > 0) {
			int var5 = var3.size();
			this.iDynaMbrAttrMap = new HashMap(var5);
			ArrayList var6 = new ArrayList(var5);
			List var7 = this.getGroupTypes();
			ArrayList var8 = new ArrayList();

			int var9;
			for (var9 = 0; var9 < var7.size(); ++var9) {
				LdapEntity var10 = this.getLdapEntity((String) var7.get(var9));
				List var11 = var10.getObjectClasses();

				for (int var12 = 0; var12 < var11.size(); ++var12) {
					String var13 = (String) var11.get(var12);
					var8.add(var13);
				}
			}

			for (var9 = 0; var9 < var5; ++var9) {
				DataObject var14 = (DataObject) var3.get(var9);
				String var15 = var14.getString("name");
				if (var15 != null && var15.trim().length() > 0) {
					String var16 = var14.getString("objectClass");
					if (var16 == null) {
						for (int var17 = 0; var17 < var8.size(); ++var17) {
							this.iDynaMbrAttrMap.put((String) var8.get(var17), var15);
							this.iDynaMbrObjectClass.add(var8.get(var17));
						}
					} else {
						this.iDynaMbrAttrMap.put(var16.toLowerCase(), var15);
						this.iDynaMbrObjectClass.add(var16);
					}

					if (!var6.contains(var15)) {
						var6.add(var15);
					}

					if (var16 != null && !var4.getObjectClasses().contains(var16.toLowerCase())) {
						var4.addObjectClass(var16);
					}
				}
			}

			this.iDynaMbrAttrs = (String[]) ((String[]) var6.toArray(new String[0]));
			this.setDynamicGroupFilter();
		}

	}

	public String getMembershipAttribute() {
		return this.iMembershipAttrName;
	}

	public short getMembershipAttributeScope() {
		return this.iMembershipAttrScope;
	}

	public boolean supportDynamicGroup() {
		return this.iDynaMbrAttrs != null;
	}

	public String[] getMemberAttributes() {
		return this.iMbrAttrs;
	}

	public String[] getDynamicMemberAttributes() {
		return this.iDynaMbrAttrs;
	}

	public short[] getMemberAttributesScope() {
		return this.iMbrAttrScope;
	}

	public String getDynamicGroupFilter() {
		return this.iDynaGrpFilter;
	}

	public String getDynamicMemberAttribute(Attribute var1) throws WIMSystemException {
		if (this.iDynaMbrAttrs == null) {
			return null;
		} else {
			if (var1 != null) {
				try {
					NamingEnumeration var3 = var1.getAll();

					while (var3.hasMoreElements()) {
						String var4 = (String) var3.nextElement();
						if (var4 != null) {
							String var5 = (String) this.iDynaMbrAttrMap.get(var4.toLowerCase());
							if (var5 != null) {
								return var5;
							}
						}
					}
				} catch (NamingException var6) {
					trcLogger.logp(Level.SEVERE, CLASSNAME, "getDynamicMemberAttribute", var6.toString(true));
					throw new WIMSystemException("NAMING_EXCEPTION",
							WIMMessageHelper.generateMsgParms(var6.toString(true)), CLASSNAME,
							"getDynamicMemberAttribute");
				}
			}

			return null;
		}
	}

	public String getMemberAttribute(Attribute var1) throws WIMSystemException {
		if (this.iMbrAttrs.length == 1) {
			return this.iMbrAttrs[0];
		} else {
			if (var1 != null) {
				try {
					NamingEnumeration var3 = var1.getAll();

					while (var3.hasMoreElements()) {
						String var4 = (String) var3.nextElement();
						if (var4 != null) {
							String var5 = (String) this.iMbrAttrMap.get(var4.toLowerCase());
							if (var5 != null) {
								return var5;
							}
						}
					}
				} catch (NamingException var6) {
					trcLogger.logp(Level.SEVERE, CLASSNAME, "getMemberAttribute(Attribute)", var6.toString(true));
					throw new WIMSystemException("NAMING_EXCEPTION",
							WIMMessageHelper.generateMsgParms(var6.toString(true)), CLASSNAME,
							"getMemberAttribute(Attribute)");
				}
			}

			return this.iMbrAttrs[0];
		}
	}

	public String[] getLdapNodes() {
		return this.iLdapNodes;
	}

	public String getExtId(String var1) {
		LdapEntity var2 = this.getLdapEntity(var1);
		if (var2 != null) {
			return var2.getExtId();
		} else {
			return this.iExtIds.size() == 1 ? (String) this.iExtIds.iterator().next() : "distinguishedName";
		}
	}

	public String getExtIdFromAttributes(String var1, String var2, Attributes var3) throws WIMSystemException {
		String var5 = this.getExtId(var2);
		if ("distinguishedName".equalsIgnoreCase(var5)) {
			return LdapHelper.toUpperCase(var1);
		} else {
			Attribute var6 = null;
			var6 = var3.get(var5);
			if (var6 == null) {
				throw new WIMSystemException("EXT_ID_VALUE_IS_NULL", WIMMessageHelper.generateMsgParms(var5, var1),
						CLASSNAME, "getExtId(String DN, javax.naming.directory.Attributes attributes)");
			} else if (var6.size() > 1) {
				throw new WIMSystemException("EXT_ID_HAS_MULTIPLE_VALUES", WIMMessageHelper.generateMsgParms(var5),
						CLASSNAME, "getExtId(String DN, javax.naming.directory.Attributes attributes)");
			} else {
				LdapAttribute var7 = this.getAttribute(var5);

				try {
					Object var8 = var6.get();
					if (var7 != null && "octetString".equalsIgnoreCase(var7.getSyntax())) {
						return LdapHelper.getOctetString((byte[]) ((byte[]) var8));
					} else {
						return var7 != null && "GUID".equalsIgnoreCase(var7.getSyntax())
								? LdapHelper.convertToDashedString((byte[]) ((byte[]) var8))
								: var8.toString();
					}
				} catch (NamingException var9) {
					trcLogger.logp(Level.SEVERE, CLASSNAME,
							"getExtId(String DN, javax.naming.directory.Attributes attributes)", var9.toString(true));
					throw new WIMSystemException("NAMING_EXCEPTION",
							WIMMessageHelper.generateMsgParms(var9.toString(true)), CLASSNAME,
							"getExtId(String DN, javax.naming.directory.Attributes attributes)");
				}
			}
		}
	}

	public Set getExtIds() {
		return this.iExtIds;
	}

	public String getLdapRDNFilter(LdapEntity var1, String var2) {
		StringBuffer var3 = new StringBuffer();
		ArrayList var4 = new ArrayList();
		char[] var5 = var2.toCharArray();
		int var6 = 0;

		int var7;
		for (var7 = 0; var7 < var5.length; ++var7) {
			if (var5[var7] == '+' && var5[var7 - 1] != '\\') {
				var4.add(var2.substring(var6, var7));
				var6 = var7 + 1;
			}
		}

		var4.add(var2.substring(var6));

		for (var7 = 0; var7 < var4.size(); ++var7) {
			String var8 = (String) var4.get(var7);
			int var9 = var8.indexOf(61);
			if (var9 > 0) {
				String var10 = var8.substring(0, var9);
				String var11 = var8.substring(var9 + 1);
				if (var1 != null) {
					String var15 = this.getAttributeName(var1, var10);
					var3.append("(").append(var15).append("=").append(var11).append(")");
				} else {
					Set var12 = this.getAttributeNames(var10);
					if (var12.size() > 1) {
						var3.append("(|");
					}

					Iterator var13 = var12.iterator();

					while (var13.hasNext()) {
						String var14 = (String) var13.next();
						var3.append("(").append(var14).append("=").append(var11).append(")");
					}

					if (var12.size() > 1) {
						var3.append(")");
					}
				}
			}
		}

		if (var4.size() > 1) {
			var3.insert(0, "(&").append(")");
		}

		return var3.toString();
	}

	public boolean retrieveMemberAttribute(int var1) {
		if (var1 == 1) {
			return false;
		} else {
			return this.iMbrAttrScope.length != 1 || this.iMbrAttrScope[0] != 2 && this.iMbrAttrScope[0] != 1;
		}
	}

	public String getEntityType(Attributes var1, String var2, String var3, String var4, List var5)
			throws WIMSystemException {
		String var7 = "Entity";
		Attribute var8 = var1.get("objectClass");
		if (var8 != null) {
			int var9 = this.iLdapEntities.length;
			ArrayList var10 = new ArrayList(var9);

			int var11;
			label50 : for (var11 = 0; var11 < var9; ++var11) {
				LdapEntity var12 = this.iLdapEntities[var9 - (var11 + 1)];
				List var13 = var12.getObjectClasses();

				for (int var14 = 0; var14 < var13.size(); ++var14) {
					String var15 = (String) var13.get(var14);
					if (LdapHelper.containIngorecaseValue(var8, var15)) {
						String var16 = var12.getName();
						if (var5 != null && var5.size() > 0) {
							int var17 = 0;

							while (true) {
								if (var17 >= var5.size()) {
									continue label50;
								}

								String var18 = (String) var5.get(var17);
								if (this.iSchemaMgr.isSuperType(var18, var16)) {
									var10.add(var16);
								}

								++var17;
							}
						}

						var10.add(var12.getName());
						break;
					}
				}
			}

			var11 = var10.size();
			if (var11 == 1) {
				var7 = (String) var10.get(0);
			} else if (var11 > 1) {
				var7 = (String) var10.get(0);
			}
		} else {
			var7 = (String) var5.get(0);
		}

		return var7;
	}

	public boolean needTranslateRDN() {
		return this.iNeedTranslateRDN;
	}

	public boolean needTranslateRDN(String var1) {
		if (var1 != null) {
			LdapEntity var2 = this.getLdapEntity(var1);
			if (var2 != null) {
				return var2.needTranslateRDN();
			}
		}

		return this.iNeedTranslateRDN;
	}

	public String getDummyMember(String var1) {
		return (String) this.iDummyMbrMap.get(var1);
	}

	public boolean isDummyMember(String var1) {
		return this.iDummyMbrMap.containsValue(var1);
	}

	private void setSpecialCharactors(char[] var1) {
		this.iSpecialChars = var1;
	}

	public char[] getSepcialCharactors() {
		return this.iSpecialChars;
	}

	public String escapeSpecialCharacters(String var1) {
		if (var1 == null) {
			return null;
		} else {
			StringBuilder var2 = new StringBuilder();
			char[] var3 = var1.toCharArray();
			int var4 = var1.length();
			int var5 = 0;

			int var7;
			for (char[] var6 = this.getSepcialCharactors(); var5 < var4; ++var5) {
				for (var7 = 0; var7 < var6.length; ++var7) {
					if (var3[var5] == var6[var7] && (var5 > 0 || var5 == 0)) {
						var2.append("\\");
					}
				}

				var2.append(var3[var5]);
			}

			if (this.useEncodingInSearchExpression != null) {
				var2 = new StringBuilder(
						LdapHelper.encodeAttribute(var2.toString(), this.useEncodingInSearchExpression));
			}

			var7 = 0;
			int var8 = 0;

			while (var8 < var2.length()) {
				var7 = var2.indexOf("\\*", var7);
				if (var7 < 0) {
					var8 = var2.length();
				} else {
					var2.deleteCharAt(var7);
					var8 = var7;
				}
			}

			return var2.toString();
		}
	}

	private void setGroupMemberFilter() {
		LdapEntity var2 = this.getLdapEntity("Group");
		String var3 = var2.getSearchFilter();
		StringBuffer var4 = new StringBuffer("(&");
		var4.append(var3);
		if (this.iMbrAttrs.length == 1) {
			var4.append("(").append(this.iMbrAttrs[0]).append("={0}))");
		} else {
			var4.append("(|");

			for (int var5 = 0; var5 < this.iMbrAttrs.length; ++var5) {
				var4.append("(").append(this.iMbrAttrs[var5]).append("={0})");
			}

			var4.append("))");
		}

		this.iGrpMbrFilter = var4.toString();
	}

	private void setDynamicGroupFilter() {
		LdapEntity var2 = this.getLdapEntity("Group");
		String var3 = var2.getSearchFilter();
		StringBuffer var4 = new StringBuffer("(&");
		int var5;
		if (this.iDynaMbrObjectClass != null && this.iDynaMbrObjectClass.size() > 0) {
			if (this.iDynaMbrObjectClass.size() == 1) {
				var4.append("(|(objectclass=").append(this.iDynaMbrObjectClass.get(0)).append(")");
				var4.append(var3);
				var4.append(")");
			} else {
				var4.append("(|");

				for (var5 = 0; var5 < this.iDynaMbrObjectClass.size(); ++var5) {
					var4.append("(objectclass=").append(this.iDynaMbrObjectClass.get(var5)).append(")");
				}

				var4.append(var3);
				var4.append(")");
			}
		} else {
			var4.append(var3);
		}

		if (this.iDynaMbrAttrs.length == 1) {
			var4.append("(").append(this.iDynaMbrAttrs[0]).append("=*))");
		} else {
			var4.append("(|");

			for (var5 = 0; var5 < this.iDynaMbrAttrs.length; ++var5) {
				var4.append("(").append(this.iDynaMbrAttrs[var5]).append("=*)");
			}

			var4.append("))");
		}

		this.iDynaGrpFilter = var4.toString();
	}

	public String getGroupMemberFilter() {
		return this.iGrpMbrFilter;
	}

	public String getGroupMemberFilter(String var1) {
		var1 = this.escapeSpecialCharacters(var1);
		Object[] var2 = new Object[]{var1};
		return (new MessageFormat(this.iGrpMbrFilter)).format(var2);
	}

	public Attribute getGroupMemberAttrs(Attributes var1, Attribute var2) throws WIMException {
		Attribute var3 = null;
		String var4 = null;
		if (var2 != null) {
			var4 = this.getMemberAttribute(var2);
			var3 = var1.remove(var4);
		} else {
			String[] var5 = this.getMemberAttributes();

			for (int var6 = 0; var6 < var5.length; ++var6) {
				var3 = var1.remove(var5[var6]);
				if (var3 != null) {
					break;
				}
			}
		}

		return var3;
	}

	public String getEntityTypesFilter(Set var1) {
		StringBuffer var2 = new StringBuffer();
		if (var1.size() > 1) {
			var2.append("(|");
		}

		Iterator var3 = var1.iterator();

		while (var3.hasNext()) {
			LdapEntity var4 = this.getLdapEntity((String) var3.next());
			if (var4 != null) {
				var2.lastIndexOf(var4.getSearchFilter());
				String var5 = var4.getSearchFilter();
				if (var2.indexOf(var5) > -1) {
					trcLogger.logp(Level.FINE, CLASSNAME, "getEntityTypesFilter",
							"Do not append ,found search filter already at " + var2.indexOf(var5));
				} else {
					trcLogger.logp(Level.FINE, CLASSNAME, "getEntityTypesFilter",
							"Appending searchfiter with sFilter... " + var5);
					var2.append(var4.getSearchFilter());
				}
			}
		}

		if (var1.size() > 1) {
			var2.append(")");
		}

		return var2.toString();
	}

	public List getLdapSubEntityTypes(String var1) {
		ArrayList var2 = new ArrayList(this.iSchemaMgr.getSubEntityTypes(var1));
		ArrayList var3 = new ArrayList(var2.size());

		for (int var4 = 0; var4 < var2.size(); ++var4) {
			String var5 = (String) var2.get(var4);
			if (this.getLdapEntity(var5) == null) {
				var3.add(var5);
			}
		}

		var2.removeAll(var3);
		return var2;
	}

	public Object getLdapValue(Object var1, String var2, String var3) throws WIMSystemException {
		LdapAttribute var6 = this.getLdapAttribute(var3);
		Object var5;
		if ("String".equals(var2)) {
			var5 = LdapHelper.getStringLdapValue(var1, var6, this.getLdapType());
		} else if ("DateTime".equals(var2)) {
			var5 = LdapHelper.getDateLdapValue(var1, var6, this.getLdapType());
		} else if ("Int".equals(var2)) {
			var5 = LdapHelper.getIntLdapValue(var1, var6, this.getLdapType());
		} else if ("LangType".equals(var2)) {
			if (var1 instanceof DataObject) {
				DataObject var7 = (DataObject) var1;
				var5 = var7.getString("value");
			} else {
				var5 = var1.toString();
			}
		} else {
			var5 = var1;
		}

		return var5;
	}

	private void setUpdateGroupMembership(DataObject var1) {
		if (var1 != null && var1.isSet("updateGroupMembership")) {
			this.iUpdateGrpMbrship = var1.getBoolean("updateGroupMembership");
		} else if (this.getLdapType().startsWith("DOMINO") || this.getLdapType().startsWith("SUNONE")) {
			this.iUpdateGrpMbrship = true;
		}

	}

	public boolean updateGroupMembership() {
		return this.iUpdateGrpMbrship;
	}

	public boolean isMemberAttributesAllScope() {
		return this.iMbrAttrsAllScope;
	}

	public boolean isMemberAttributesNestedScope() {
		return this.iMbrAttrsNestedScope;
	}

	public boolean isPerson(String var1) {
		return this.iPersonTypes.contains(var1);
	}

	public boolean isPersonAccount(String var1) {
		return this.iPersonAccountTypes.contains(var1);
	}

	public boolean isGroup(String var1) {
		return this.iGroupTypes.contains(var1);
	}

	public boolean containGroup(List var1) {
		if (var1 != null) {
			for (int var2 = 0; var2 < var1.size(); ++var2) {
				String var3 = (String) var1.get(var2);
				if (this.isGroup(var3)) {
					return true;
				}
			}
		}

		return false;
	}

	public String[] getGroupSearchBases() {
		return this.iGroupSearchBases;
	}

	public List getSupportedEntitTypes() {
		return this.iLdapEntityTypeList;
	}

	public short getOperator(String var1) {
		if (var1 == null) {
			return -1;
		} else if (var1.equals("=")) {
			return 0;
		} else if (var1.equals("!=")) {
			return 1;
		} else if (var1.equals(">")) {
			return 2;
		} else if (var1.equals("<")) {
			return 3;
		} else if (var1.equals(">=")) {
			return 4;
		} else {
			return (short) (var1.equals("<=") ? 5 : -1);
		}
	}

	public boolean isActiveDirectory() {
		return this.iLdapType.startsWith("AD");
	}

	public boolean isDefaultMbrAttr() {
		String var1 = "isDefaultMbrAttr";
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, var1, "use default member attribute: " + this.iUseDefaultMbrAttr);
		}

		return this.iUseDefaultMbrAttr;
	}

	public List getSupportedProperties(String var1, List var2) {
		Object var3 = null;
		HashSet var4 = null;
		if (var2 != null && var2.size() > 0) {
			if (var1 == null) {
				return var2;
			}

			var3 = new ArrayList();
			if (var1.equals("Entity")) {
				var4 = new HashSet();
				List var5 = this.getAllLdapEntities(var1);
				List var6 = null;

				for (int var7 = 0; var7 < var5.size(); ++var7) {
					var6 = this.getSupportedProperties((LdapEntity) var5.get(var7), var2);
					var4.addAll(var6);
				}

				((List) var3).addAll(var4);
			} else {
				LdapEntity var8 = this.getLdapEntity(var1);
				var3 = this.getSupportedProperties(var8, var2);
			}
		}

		return (List) var3;
	}

	public List getSupportedProperties(LdapEntity var1, List var2) {
		ArrayList var3 = new ArrayList();
		Iterator var4 = var2.iterator();

		while (var4.hasNext()) {
			String var5 = (String) var4.next();
			if (var5.equals("*")) {
				var3.add(var5);
			} else {
				String var6 = var1.getAttribute(var5);
				if (var6 == null) {
					var6 = (String) this.iPropToAttrMap.get(var5);
				}

				if (var6 != null) {
					var3.add(var5);
				}
			}
		}

		return var3;
	}

	public Map<String, String> getCustomPropsForLdap() {
		return this.iCustomProperties;
	}

	public boolean isSetUsePrincipalNameForLogin() {
		return this.usePrincipalNameForLogin;
	}

	public boolean isSetReturnDNWithOutSpaceInGetMembers() {
		return this.returnDNWithOutSpaceInGetMembers;
	}

	public boolean isIncludeGroupInSearchEntityTypes() {
		return this.includeGroupInSearchEntityTypes;
	}

	public String getTimestampFormat() {
		return this.ldapTimestampFormat;
	}

	public String getUseEncodingInSearchExpression() {
		return this.useEncodingInSearchExpression;
	}

	public boolean isReturnUniqueNameInNormalCaseIfExtIdMapToDN() {
		return this.returnUniqueNameInNormalCaseIfExtIdMapToDN;
	}

	public static boolean isCaseSensitiveDNForAttributeCache() {
		return caseSensitiveDNForAttributeCache;
	}

	public boolean isMinimizeContextPoolThreadBlock() {
		return this.minimizeContextPoolThreadBlock;
	}

	public int getMaxThreadsToBlock() {
		return this.maxThreadsToBlock;
	}

	public void setMaxThreadsToBlock(int var1) {
		this.maxThreadsToBlock = var1;
	}

	public int getBindTimeout() {
		return this.bindTimeout;
	}

	public void setBindTimeout(int var1) {
		this.bindTimeout = var1;
	}

	public String getDomainNameForAutomaticDiscoveryOfLDAPServers() {
		return this.domainNameForAutomaticDiscoveryOfLDAPServers;
	}

	public String getvmmHandleReferal() {
		return this.vmmHandleReferal;
	}

	public String getPreFetchData() {
		return this.preFetchData;
	}

	public String getLdaploginGroupFilter() {
		return this.ldapLoginGroupFilter;
	}

	public void populatePreFetchDataMap() {
		if (this.getPreFetchData() != null) {
			StringTokenizer var1 = new StringTokenizer(this.preFetchData, ";");
			if (this.preFetchDataMap == null) {
				this.preFetchDataMap = new HashMap();
			}

			while (var1.hasMoreTokens()) {
				String var2 = var1.nextToken();
				StringTokenizer var3 = new StringTokenizer(var2, ":");
				String var4 = var3.nextToken();
				String var5 = var3.nextToken();
				StringTokenizer var6 = new StringTokenizer(var5, ",");
				ArrayList var7 = new ArrayList();

				while (var6.hasMoreTokens()) {
					String var8 = var6.nextToken();
					var7.add(var8);
				}

				if (!var7.isEmpty()) {
					this.preFetchDataMap.put(var4, var7);
				}
			}
		}

	}

	public String getIsPolicyEnforced() {
		return this.isPolicyEnforced;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		caseSensitiveDNForAttributeCache = false;
	}
}