package com.ibm.ws.wim.dao.oracle;

import com.ibm.websphere.ce.cm.DuplicateKeyException;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InvalidPropertyValueException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.db.DBEntity;
import com.ibm.ws.wim.dao.AbstractDAO;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.util.DataGraphHelper;
import commonj.sdo.DataObject;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;

public class OracleDAO extends AbstractDAO {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;

	public OracleDAO(String var1, String var2, String var3, String var4, String var5, String var6) throws WIMException {
		super("oracle", var1, var2, var3, var4, var5, var6, new OracleQuerySet(var3));
	}

	public OracleDAO(String var1, String var2, String var3, String var4, String var5) throws WIMException {
		super("oracle", var1, var2, var3, var4, var5, new OracleQuerySet());
	}

	public void createProperties(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
		}

		if (var4 != null) {
			Connection var9 = null;
			PreparedStatement var10 = null;

			try {
				label402 : for (short var11 = 0; var11 < var4.length; ++var11) {
					if (var4[var11] != null) {
						String var12 = this.getInsertStmtForPropertyValue(var1, var11);
						int var13 = var4[var11].size();
						Set var14 = var4[var11].keySet();
						Iterator var15 = var14.iterator();
						if (var9 == null) {
							var9 = this.getConnection();
						}

						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME,
									"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
									"insert statement is " + var12);
						}

						var10 = var9.prepareStatement(var12);
						String var16 = DAOHelper.getValueTableName(var1, var11);

						while (true) {
							Integer var17;
							Object var18;
							do {
								if (!var15.hasNext()) {
									continue label402;
								}

								var17 = (Integer) var15.next();
								if (var6.contains(var17)) {
									var18 = (List) var4[var11].get(var17);
								} else {
									var18 = new ArrayList();
									((List) var18).add(var4[var11].get(var17));
								}
							} while (((List) var18).size() == 0);

							for (int var19 = 0; var19 < ((List) var18).size(); ++var19) {
								long var20 = -1L;
								if (var1 == 0) {
									var20 = this.getKeyManager().getDBKeyForTable(var9, var16);
								} else {
									var20 = this.getKeyManager().getLAKeyForTable(var9, var16);
								}

								var10.setLong(1, var20);
								var10.setInt(2, var17);
								var10.setString(3, DAOHelper.getDataType(var11));
								var10.setLong(4, var2);
								if (var5 != null) {
									var10.setLong(5, var5);
								} else {
									var10.setNull(5, -5);
								}

								var10.setString(6, "");

								try {
									DataObject var28;
									switch (var11) {
										case 0 :
											var10.setString(7, (String) ((List) var18).get(var19));
											var10.setString(8, ((String) ((List) var18).get(var19)).toLowerCase());
											break;
										case 1 :
											long var63 = 0L;

											try {
												var63 = (Long) ((List) var18).get(var19);
											} catch (ClassCastException var56) {
												var63 = Long.parseLong((String) ((List) var18).get(var19));
											}

											var10.setLong(7, var63);
											break;
										case 2 :
											double var65 = 0.0D;

											try {
												var65 = (Double) ((List) var18).get(var19);
											} catch (ClassCastException var55) {
												var65 = Double.parseDouble((String) ((List) var18).get(var19));
											}

											var10.setDouble(7, var65);
											break;
										case 3 :
											boolean var66 = false;

											int var67;
											try {
												var67 = (Integer) ((List) var18).get(var19);
											} catch (ClassCastException var54) {
												var67 = new Integer(((List) var18).get(var19).toString());
											}

											var10.setInt(7, var67);
											break;
										case 4 :
											if (trcLogger.isLoggable(Level.FINE)) {
												trcLogger.logp(Level.FINE, CLASSNAME,
														"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
														"parsing timestamp: " + ((List) var18).get(var19));
											}

											var28 = null;

											Timestamp var68;
											try {
												var68 = (Timestamp) ((List) var18).get(var19);
											} catch (ClassCastException var58) {
												if (trcLogger.isLoggable(Level.FINE)) {
													trcLogger.logp(Level.FINE, CLASSNAME,
															"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
															"Error converting timestamp: " + var58.getMessage());
												}

												try {
													var68 = Timestamp.valueOf((String) ((List) var18).get(var19));
												} catch (Exception var57) {
													if (trcLogger.isLoggable(Level.FINE)) {
														trcLogger.logp(Level.FINE, CLASSNAME,
																"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																"Error converting timestamp: " + var57.getMessage());
													}

													String var71 = ((List) var18).get(var19).toString();
													SimpleDateFormat var72 = new SimpleDateFormat(
															"yyyy-MM-dd'T'HH:mm:ss.SSS");

													try {
														var72.setTimeZone(TimeZone.getTimeZone("GMT"));
														Date var33 = var72.parse(var71);
														var68 = new Timestamp(var33.getTime());
													} catch (ParseException var53) {
														var72 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
														var72.setTimeZone(TimeZone.getTimeZone("GMT"));
														Date var34 = var72.parse(var71);
														var68 = new Timestamp(var34.getTime());
													}
												}
											}

											if (trcLogger.isLoggable(Level.FINE)) {
												trcLogger.logp(Level.FINE, CLASSNAME,
														"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
														"writing timestamp: " + var68);
											}

											var10.setTimestamp(7, var68);
											break;
										case 5 :
											DataObject var22 = (DataObject) ((List) var18).get(var19);
											if (RepositoryManager.singleton().isEntryJoin()) {
												DataGraphHelper.prepareIdentifierFromFedRepository(var22);
											} else {
												String var23;
												if (var1 == 0 && var7 != null) {
													var23 = var22.getString("uniqueName");
													DBEntity var64 = this.findDBEntityByUniqueNameKey(
															DAOHelper.getTruncatedUniqueName(var23));
													var22.setString("externalId", var64.getUniqueId());
													var22.setString("repositoryId", var7);
												} else if (var1 == 1) {
													var23 = var22.getString("uniqueName");
													String var24 = var22.getString("externalId");
													String var25 = var22.getString("repositoryId");
													if (var23 == null || var24 == null || var25 == null) {
														DataObject var26 = SchemaManager.singleton()
																.createRootDataObject();
														DataObject var27 = var26.createDataObject("entities",
																"http://www.ibm.com/websphere/wim", "Entity");
														var28 = var27.createDataObject("identifier");
														var28.setString("uniqueName", var23);
														var28.setString("externalId", var24);
														var28.setString("repositoryId", var25);
														DataObject var69 = RepositoryManager.singleton()
																.getRepositories()[0].get(var26);
														List var70 = var69.getList("entities");
														DataObject var31 = (DataObject) var70.get(0);
														DataObject var32 = var31.getDataObject("identifier");
														var23 = var32.getString("uniqueName");
														var24 = var32.getString("externalId");
														var25 = RepositoryManager.singleton().getRepositoryIds()[0];
														var22.setString("uniqueName", var23);
														var22.setString("externalId", var24);
														var22.setString("repositoryId", var7);
													}
												}
											}

											var10.setString(7,
													DAOHelper.getTruncatedUniqueName(var22.getString("uniqueName")));
											var10.setString(8, var22.getString("uniqueName"));
											var10.setString(9,
													DAOHelper.getTruncatedExternalId(var22.getString("externalId")));
											var10.setString(10, var22.getString("externalId"));
											var10.setString(11, var22.getString("repositoryId"));
											break;
										case 6 :
											ByteArrayOutputStream var29 = new ByteArrayOutputStream();
											ObjectOutputStream var30 = new ObjectOutputStream(var29);
											var30.writeObject(((List) var18).get(var19));
											var30.close();
											var10.setBytes(7, var29.toByteArray());
									}
								} catch (Exception var59) {
									throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
											WIMMessageHelper.generateMsgParms(var17), CLASSNAME,
											"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
											var59);
								}

								var10.executeUpdate();
							}
						}
					}
				}
			} catch (NamingException var60) {
				throw new WIMSystemException("NAMING_EXCEPTION", CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
						var60);
			} catch (SQLException var61) {
				throw new WIMSystemException("SQL_EXCEPTION", CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
						var61);
			} finally {
				try {
					this.closeConnection(var9);
				} catch (Exception var52) {
					;
				}

				try {
					var10.close();
				} catch (Exception var51) {
					;
				}

			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"createProperties(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
			}

		}
	}

	public void createProperties1(short var1, long var2, Hashtable[] var4, Long var5, Set var6, String var7)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
		}

		if (var4 != null) {
			int var9 = 0;
			Connection var10 = null;
			PreparedStatement var11 = null;

			try {
				label715 : for (short var12 = 0; var12 < var4.length; ++var12) {
					if (var4[var12] != null) {
						String var13 = this.getInsertStmtForPropertyValueWithoutKey(var1, var12);
						DAOHelper.getValueTableName(var1, var12);
						int var15 = var4[var12].size();
						Set var16 = var4[var12].keySet();
						Iterator var17 = var16.iterator();
						if (var10 == null) {
							var10 = this.getConnection();
						}

						while (true) {
							Integer var18;
							Object var19;
							do {
								if (!var17.hasNext()) {
									continue label715;
								}

								var18 = (Integer) var17.next();
								if (var6.contains(var18)) {
									var19 = (List) var4[var12].get(var18);
								} else {
									var19 = new ArrayList();
									((List) var19).add(var4[var12].get(var18));
								}
							} while (((List) var19).size() == 0);

							for (int var20 = 0; var20 < ((List) var19).size(); ++var20) {
								boolean var21 = false;

								while (!var21 && var9 < 25) {
									try {
										var11 = var10.prepareStatement(var13);
										var11.setInt(1, var18);
										var11.setString(2, DAOHelper.getDataType(var12));
										var11.setLong(3, var2);
										if (var5 != null) {
											var11.setLong(4, var5);
										} else {
											var11.setNull(4, -5);
										}

										var11.setString(5, "");

										try {
											DataObject var28;
											switch (var12) {
												case 0 :
													var11.setString(6, (String) ((List) var19).get(var20));
													var11.setString(7,
															((String) ((List) var19).get(var20)).toLowerCase());
													break;
												case 1 :
													long var87 = 0L;

													try {
														var87 = (Long) ((List) var19).get(var20);
													} catch (ClassCastException var79) {
														var87 = Long.parseLong((String) ((List) var19).get(var20));
													}

													var11.setLong(6, var87);
													break;
												case 2 :
													double var89 = 0.0D;

													try {
														var89 = (Double) ((List) var19).get(var20);
													} catch (ClassCastException var78) {
														var89 = Double.parseDouble((String) ((List) var19).get(var20));
													}

													var11.setDouble(6, var89);
													break;
												case 3 :
													boolean var90 = false;

													int var91;
													try {
														var91 = (Integer) ((List) var19).get(var20);
													} catch (ClassCastException var77) {
														var91 = new Integer(((List) var19).get(var20).toString());
													}

													var11.setInt(6, var91);
													break;
												case 4 :
													if (trcLogger.isLoggable(Level.FINE)) {
														trcLogger.logp(Level.FINE, CLASSNAME,
																"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																"parsing timestamp: " + ((List) var19).get(var20));
													}

													var28 = null;

													Timestamp var92;
													try {
														var92 = (Timestamp) ((List) var19).get(var20);
													} catch (ClassCastException var81) {
														if (trcLogger.isLoggable(Level.FINE)) {
															trcLogger.logp(Level.FINE, CLASSNAME,
																	"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																	"Error converting timestamp: "
																			+ var81.getMessage());
														}

														try {
															var92 = Timestamp
																	.valueOf((String) ((List) var19).get(var20));
														} catch (Exception var80) {
															if (trcLogger.isLoggable(Level.FINE)) {
																trcLogger.logp(Level.FINE, CLASSNAME,
																		"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																		"Error converting timestamp: "
																				+ var80.getMessage());
															}

															String var95 = ((List) var19).get(var20).toString();
															SimpleDateFormat var96 = new SimpleDateFormat(
																	"yyyy-MM-dd'T'HH:mm:ss.SSS");

															try {
																var96.setTimeZone(TimeZone.getTimeZone("GMT"));
																Date var33 = var96.parse(var95);
																var92 = new Timestamp(var33.getTime());
															} catch (ParseException var76) {
																var96 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
																var96.setTimeZone(TimeZone.getTimeZone("GMT"));
																Date var34 = var96.parse(var95);
																var92 = new Timestamp(var34.getTime());
															}
														}
													}

													if (trcLogger.isLoggable(Level.FINE)) {
														trcLogger.logp(Level.FINE, CLASSNAME,
																"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
																"writing timestamp: " + var92);
													}

													var11.setTimestamp(6, var92);
													break;
												case 5 :
													DataObject var22 = (DataObject) ((List) var19).get(var20);
													if (RepositoryManager.singleton().isEntryJoin()) {
														DataGraphHelper.prepareIdentifierFromFedRepository(var22);
													} else {
														String var23;
														if (var1 == 0 && var7 != null) {
															var23 = var22.getString("uniqueName");
															DBEntity var88 = this.findDBEntityByUniqueNameKey(
																	DAOHelper.getTruncatedUniqueName(var23));
															var22.setString("externalId", var88.getUniqueId());
															var22.setString("repositoryId", var7);
														} else if (var1 == 1) {
															var23 = var22.getString("uniqueName");
															String var24 = var22.getString("externalId");
															String var25 = var22.getString("repositoryId");
															if (var23 == null || var24 == null || var25 == null) {
																DataObject var26 = SchemaManager.singleton()
																		.createRootDataObject();
																DataObject var27 = var26.createDataObject("entities",
																		"http://www.ibm.com/websphere/wim", "Entity");
																var28 = var27.createDataObject("identifier");
																var28.setString("uniqueName", var23);
																var28.setString("externalId", var24);
																var28.setString("repositoryId", var25);
																DataObject var93 = RepositoryManager.singleton()
																		.getRepositories()[0].get(var26);
																List var94 = var93.getList("entities");
																DataObject var31 = (DataObject) var94.get(0);
																DataObject var32 = var31.getDataObject("identifier");
																var23 = var32.getString("uniqueName");
																var24 = var32.getString("externalId");
																var25 = RepositoryManager.singleton()
																		.getRepositoryIds()[0];
																var22.setString("uniqueName", var23);
																var22.setString("externalId", var24);
																var22.setString("repositoryId", var7);
															}
														}
													}

													var11.setString(6, DAOHelper
															.getTruncatedUniqueName(var22.getString("uniqueName")));
													var11.setString(7, var22.getString("uniqueName"));
													var11.setString(8, DAOHelper
															.getTruncatedExternalId(var22.getString("externalId")));
													var11.setString(9, var22.getString("externalId"));
													var11.setString(10, var22.getString("repositoryId"));
													break;
												case 6 :
													ByteArrayOutputStream var29 = new ByteArrayOutputStream();
													ObjectOutputStream var30 = new ObjectOutputStream(var29);
													var30.writeObject(((List) var19).get(var20));
													var30.close();
													var11.setBytes(6, var29.toByteArray());
											}
										} catch (Exception var82) {
											throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
													WIMMessageHelper.generateMsgParms(var18), CLASSNAME,
													"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													var82);
										}

										var11.executeUpdate();
										var21 = true;
									} catch (DuplicateKeyException var83) {
										var21 = false;
										if (!var83.getMessage().contains("WIMI")
												&& !var83.getMessage().contains("WIMF")) {
											throw new WIMSystemException("SQL_EXCEPTION",
													WIMMessageHelper.generateMsgParms(var83.getMessage()), CLASSNAME,
													"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													var83);
										}

										++var9;
										if (var9 >= 25) {
											var21 = true;
											throw new WIMSystemException("SQL_EXCEPTION",
													WIMMessageHelper.generateMsgParms(var83.getMessage()), CLASSNAME,
													"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													var83);
										}

										if (trcLogger.isLoggable(Level.FINE)) {
											trcLogger.logp(Level.FINE, CLASSNAME,
													"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
													" Reattempting " + var9 + " times");
										}
									} catch (SQLException var84) {
										var21 = true;
										throw new WIMSystemException("SQL_EXCEPTION",
												WIMMessageHelper.generateMsgParms(var84.getMessage()), CLASSNAME,
												"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)",
												var84);
									} finally {
										try {
											var11.close();
										} catch (Exception var75) {
											;
										}

										var11 = null;
									}
								}
							}
						}
					}
				}
			} finally {
				try {
					this.closeConnection(var10);
				} catch (Exception var74) {
					;
				}

				try {
					var11.close();
				} catch (Exception var73) {
					;
				}

				var10 = null;
				var11 = null;
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"createProperties1(short schema, long mbrId, Hashtable[] attrs, Set multiValProps, String reposId)");
			}

		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = OracleDAO.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}