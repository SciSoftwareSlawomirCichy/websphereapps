package com.ibm.ws.ssl;

import com.ibm.websphere.ssl.SSLException;
import com.ibm.ws.ssl.config.SSLConfig;
import java.net.URLStreamHandler;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Map;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

public interface JSSEProvider {
	String getSSLProtocolPackageHandler();

	String[] getCiphersForSecurityLevel(boolean var1, String var2);

	SSLContext getSSLContextInstance(SSLConfig var1) throws SSLException;

	SSLContext getSSLContext(Map<?, ?> var1, SSLConfig var2) throws Exception;

	URLStreamHandler getURLStreamHandler(SSLConfig var1) throws Exception;

	String getDefaultSSLSocketFactoryClass();

	SSLSocketFactory getSSLSocketFactory(Map<?, ?> var1, SSLConfig var2) throws Exception;

	SSLServerSocketFactory getSSLServerSocketFactory(SSLConfig var1) throws SSLException;

	TrustManagerFactory getTrustManagerFactoryInstance() throws NoSuchAlgorithmException, NoSuchProviderException;

	KeyManagerFactory getKeyManagerFactoryInstance() throws NoSuchAlgorithmException, NoSuchProviderException;

	KeyStore getKeyStoreInstance(String var1, String var2) throws KeyStoreException, NoSuchProviderException;

	String getKeyManager();

	String getTrustManager();

	String getContextProvider();

	String getKeyStoreProvider();

	String getSocketFactory();

	String getProtocolPackageHandler();
}