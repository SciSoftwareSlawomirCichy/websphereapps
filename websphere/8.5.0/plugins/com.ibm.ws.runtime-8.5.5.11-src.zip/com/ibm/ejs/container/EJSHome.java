package com.ibm.ejs.container;

import com.ibm.ejs.container.EJSHome.1;
import com.ibm.ejs.container.activator.ActivationStrategy;
import com.ibm.ejs.container.lock.LockStrategy;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.cpi.Finder;
import com.ibm.websphere.cpi.Persister;
import com.ibm.websphere.cpi.PersisterHome;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.HomeWrapperSet;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.MethodInterface;
import com.ibm.websphere.csi.TransactionAttribute;
import com.ibm.websphere.ejbcontainer.EJBStoppedException;
import com.ibm.ws.ejb.portable.HandleImpl;
import com.ibm.ws.ejb.portable.HomeHandleImpl;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import com.ibm.ws.ejbcontainer.util.ObjectUtil;
import com.ibm.ws.ejbcontainer.util.Pool;
import com.ibm.ws.ejbcontainer.util.PoolDiscardStrategy;
import com.ibm.ws.exception.RuntimeWarning;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.managedobject.ManagedObjectContext;
import com.ibm.ws.managedobject.ManagedObjectException;
import com.ibm.ws.managedobject.ManagedObjectFactory;
import com.ibm.ws.runtime.metadata.MethodMetaData;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import com.ibm.ws.util.ThreadContextAccessor;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.rmi.NoSuchObjectException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.ejb.EJBException;
import javax.ejb.EJBHome;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBMetaData;
import javax.ejb.EJBObject;
import javax.ejb.EnterpriseBean;
import javax.ejb.FinderException;
import javax.ejb.Handle;
import javax.ejb.HomeHandle;
import javax.ejb.IllegalLoopbackException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.rmi.PortableRemoteObject;

public abstract class EJSHome implements PoolDiscardStrategy, HomeInternal, SessionBean, PersisterHome {
	private static final TraceComponent tc = Tr.register(EJSHome.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.EJSHome";
	private static final ComponentMetaDataAccessorImpl ivCMDAccessor = ComponentMetaDataAccessorImpl
			.getComponentMetaDataAccessor();
	protected BeanOFactory beanOFactory;
	protected EJSContainer container;
	private EntityHelper ivEntityHelper;
	boolean noLocalCopies;
	boolean allowPrimaryKeyMutation;
	private boolean noPrimaryKeyMutation;
	protected String jndiName;
	protected J2EEName j2eeName;
	protected boolean statelessSessionHome = false;
	protected boolean statefulSessionHome = false;
	protected boolean messageDrivenHome = false;
	protected boolean ivSingletonSessionHome = false;
	protected int hashValue;
	protected BeanId ivHomeId;
	protected EJSWrapperCommon ivHomeWrappers = null;
	protected BeanId ivStatelessId = null;
	protected EJSWrapperCommon ivStatelessWrappers = null;
	protected EJSLocalWrapper ivStatefulBusinessHomeWrapper = null;
	protected Class<?> enterpriseBeanClass;
	protected Class<?> remoteEJBObjectClass;
	protected Class<?> localEJBObjectClass;
	protected BeanMetaData beanMetaData;
	protected ManagedObjectFactory ivFactory;
	private EJBMetaData ejbMetaData;
	private Properties environment = null;
	protected ActivationStrategy activationStrategy;
	protected EJBPMICollaborator pmiBean = null;
	protected Persister persister;
	protected LockStrategy lockStrategy;
	protected WrapperManager wrapperManager;
	protected boolean enabled;
	protected Pool beanPool;
	protected int ivNumberBeansCreated = 0;
	private static int BEAN_POOL_WAIT_INTERVAL = 10000;
	protected boolean ivAIServiceEnabled = false;
	protected EJBMethodInfoImpl defaultAIMethodInfo = null;
	protected static final int CachedAI_NotInitialize = 0;
	protected static final int CachedAI_HasMethodLevelAI = 1;
	protected static final int CachedAI_HasNoMethodLevelAI = -1;
	protected int cachedHasMethodLevelAI = 0;
	protected Object ivCachedBeanLevelAccessIntent = null;
	private static final boolean cvUsePortableClass;
	boolean ivAllowEarlyInsert = false;
	protected HomeRecord homeRecord = null;
	private SingletonBeanO ivSingletonBeanO = null;
	private boolean ivCreatingSingletonBeanO;
	private boolean ivSingletonBeanOCreateFailed;
	private boolean ivApplicationStarted = false;

	public EJSHome() throws RemoteException {
	}

	protected final void homeEnabled() {
		if (!this.enabled) {
			String msgTxt = "The referenced version of the " + this.j2eeName.getComponent() + " bean in the "
					+ this.j2eeName.getApplication() + " application has been stopped and may no longer be used. "
					+ "If the " + this.j2eeName.getApplication()
					+ " application has been started again, a new reference for " + "the new image of the "
					+ this.j2eeName.getComponent() + " bean must be obtained. Local references to a bean or home "
					+ "are no longer valid once the application has been stopped.";
			if (this.beanMetaData.ivModuleVersion < 30) {
				throw new HomeDisabledException(msgTxt);
			} else {
				throw new EJBStoppedException(msgTxt);
			}
		} else {
			if (!this.ivApplicationStarted) {
				this.ivApplicationStarted = this.beanMetaData._moduleMetaData.getEJBApplicationMetaData()
						.checkIfEJBWorkAllowed(this.beanMetaData._moduleMetaData);
			}

		}
	}

	private void enable(EJSContainer ejsContainer, BeanId id, BeanMetaData bmd) throws RemoteException {
		this.container = ejsContainer;
		this.ivEntityHelper = ejsContainer.ivEntityHelper;
		this.ivHomeId = id;
		this.beanMetaData = bmd;
		this.persister = this.beanMetaData.persister;
		this.wrapperManager = ejsContainer.getWrapperManager();
		this.jndiName = bmd.getJndiName();
		this.j2eeName = bmd.j2eeName;
		this.hashValue = this.j2eeName.hashCode();
		if (bmd.type != 8) {
			if (ejsContainer.pmiFactory != null) {
				this.pmiBean = ejsContainer.pmiFactory.createPmiBean(bmd, ejsContainer.ivName);
			}

			this.defaultAIMethodInfo = bmd
					.createEJBMethodInfoImpl(this.container.getEJBRuntime().getMetaDataSlotSize(MethodMetaData.class));
			this.defaultAIMethodInfo.initializeInstanceData("__defaultAIMethodInfo__",
					"__defaultAIMethodInfo__NameOnly", bmd, MethodInterface.REMOTE, TransactionAttribute.TX_SUPPORTS,
					false);
		}

		this.enabled = true;
		this.homeRecord = bmd.homeRecord;
	}

	public void initialize(EJSContainer ejsContainer, BeanId id, BeanMetaData bmd) throws RemoteException {
		bmd.ejbConfigData = null;
		this.noLocalCopies = ObjectUtil.NoLocalCopies;
		this.allowPrimaryKeyMutation = ContainerProperties.AllowPrimaryKeyMutation;
		this.noPrimaryKeyMutation = ContainerProperties.NoPrimaryKeyMutation;
		if (bmd.cmpVersion == 1) {
			this.ivAllowEarlyInsert = ContainerProperties.AllowEarlyInsert;
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled() && this.ivAllowEarlyInsert) {
				Tr.debug(tc, "Allow early insert property is true for CMP1.1 bean.");
			}
		}

		this.enable(ejsContainer, id, bmd);
	}

	public void completeInitialization() throws RemoteException {
      this.enterpriseBeanClass = this.beanMetaData.enterpriseBeanClass;
      this.remoteEJBObjectClass = this.beanMetaData.remoteImplClass;
      this.localEJBObjectClass = this.beanMetaData.localImplClass;
      this.environment = this.beanMetaData.envProps;
      this.ivFactory = this.beanMetaData.ivEnterpriseBeanFactory;
      if (this.beanMetaData.type == 3) {
         this.statelessSessionHome = true;
         this.ivStatelessId = new BeanId(this, (Serializable)null);
      } else if (this.beanMetaData.type == 4) {
         this.statefulSessionHome = true;
      } else if (this.beanMetaData.type == 7) {
         this.messageDrivenHome = true;
         this.ivStatelessId = new BeanId(this, (Serializable)null);
      } else if (this.beanMetaData.type == 2) {
         this.ivSingletonSessionHome = true;
         this.ivStatelessId = new BeanId(this, (Serializable)null);
      }

      if (this.statefulSessionHome && (this.beanMetaData.ivBusinessLocalInterfaceClasses != null || this.beanMetaData.ivBusinessRemoteInterfaceClasses != null)) {
         try {
            EJSLocalWrapper wrapper = new EJSLocalWrapper();
            wrapper.beanId = this.ivHomeId;
            wrapper.bmd = this.beanMetaData;
            wrapper.methodInfos = new EJBMethodInfoImpl[1];
            wrapper.methodNames = new String[]{"create"};
            wrapper.container = this.container;
            wrapper.wrapperManager = this.wrapperManager;
            wrapper.ivPmiBean = this.pmiBean;
            wrapper.ivCommon = null;
            wrapper.isManagedWrapper = false;
            wrapper.ivInterface = WrapperInterface.LOCAL_HOME;
            wrapper.methodInfos[0] = this.beanMetaData.createEJBMethodInfoImpl(this.beanMetaData.container.getEJBRuntime().getMetaDataSlotSize(MethodMetaData.class));
            wrapper.methodInfos[0].initializeInstanceData("create:", "create", this.beanMetaData, MethodInterface.LOCAL_HOME, TransactionAttribute.TX_NOT_SUPPORTED, false);
            wrapper.methodInfos[0].setMethodDescriptor("(Ljava.lang.Class;)Ljava.lang.Object;");
            this.ivStatefulBusinessHomeWrapper = wrapper;
         } catch (Throwable var2) {
            FFDCFilter.processException(var2, "com.ibm.ejs.container.EJSHome.completeInitialization", "642", this);
            throw ExceptionUtil.EJBException(var2);
         }
      }

      if (!this.beanMetaData.optionACommitOption && this.beanMetaData.ivMaxCreation <= 0) {
         this.lockStrategy = LockStrategy.NULL_LOCK_STRATEGY;
      } else {
         this.lockStrategy = LockStrategy.EXCLUSIVE_LOCK_STRATEGY;
      }

      if (!this.statefulSessionHome && !this.ivSingletonSessionHome) {
         this.beanPool = this.container.poolManager.create(this.beanMetaData.minPoolSize, this.beanMetaData.maxPoolSize, this.pmiBean, this);
         if (this.beanMetaData.ivInitialPoolSize != 0) {
            if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
               Tr.debug(tc, "Pre-loading BeanPool with " + this.beanMetaData.ivInitialPoolSize);
            }

            this.container.getEJBRuntime().getScheduledExecutorService().schedule(new 1(this), 0L, TimeUnit.MILLISECONDS);
         }
      } else {
         this.beanPool = null;
      }

      if (this.beanMetaData.getEJBModuleVersion() >= 20 && this.beanMetaData.getEJBComponentType() == 5) {
         this.ivAIServiceEnabled = true;
      }

   }

	protected BeanO createNewBeanO(ManagedObjectContext context) throws Exception {
		ManagedObject managedObject;
		Object bean;
		if (this.ivFactory == null) {
			managedObject = null;
			bean = this.enterpriseBeanClass.newInstance();
		} else {
			try {
				managedObject = this.ivFactory.create(context);
			} catch (ManagedObjectException var6) {
				Throwable cause = var6.getCause();
				throw (Exception) (cause instanceof Exception ? (Exception) cause : var6);
			}

			bean = managedObject.getObject();
		}

		return this.beanOFactory.create(this.container, managedObject, bean, this);
	}

	private void preLoadBeanPool() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "preLoadBeanPool: " + this.j2eeName);
		}

		Pool var2 = this.beanPool;
		synchronized (this.beanPool) {
			Object oldClassLoader = ThreadContextAccessor.UNCHANGED;

			try {
				ivCMDAccessor.beginContext(this.beanMetaData);
				oldClassLoader = EJBThreadData.svThreadContextAccessor
						.pushContextClassLoaderForUnprivileged(this.beanMetaData.ivContextClassLoader);

				for (int i = this.ivNumberBeansCreated; i < this.beanMetaData.ivInitialPoolSize; ++i) {
					BeanO beanO = this.createNewBeanO((ManagedObjectContext) null);
					this.beanPool.put(beanO);
					if (this.beanMetaData.ivMaxCreation > 0) {
						++this.ivNumberBeansCreated;
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "Pre-load BeanPool(" + this.ivNumberBeansCreated + "/"
									+ this.beanMetaData.ivMaxCreation + ")");
						}
					}
				}
			} catch (Throwable var11) {
				FFDCFilter.processException(var11, "com.ibm.ejs.container.EJSHome.preLoadBeanPool", "561", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Pre-load of BeanPool failed: exception ignored: " + var11);
				}

				Tr.warning(tc, "IGNORING_UNEXPECTED_EXCEPTION_CNTR0033E", var11);
			} finally {
				EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(oldClassLoader);
				ivCMDAccessor.endContext();
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "preLoadBeanPool");
		}

	}

	public synchronized void destroy() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			Tr.event(tc, "Destroying home ", new Object[]{this, this.j2eeName});
		}

		if (this.enabled) {
			if (this.ivSingletonBeanO != null) {
				try {
					this.ivSingletonBeanO.destroy();
				} catch (Throwable var2) {
					FFDCFilter.processException(var2, "com.ibm.ejs.container.EJSHome.destroy", "809", this);
				}
			}

			if (this.beanPool != null) {
				this.beanPool.destroy();
			}

			this.enabled = false;
			if (this.pmiBean != null) {
				this.container.pmiFactory.removePmiModule(this.pmiBean);
			}

		}
	}

	public int hashCode() {
		return this.hashValue;
	}

	public String getJNDIName(Object pkey) {
		return this.jndiName;
	}

	public J2EEName getJ2EEName() {
		return this.j2eeName;
	}

	public BeanId getId() {
		return this.ivHomeId;
	}

	public Object getCurrentThreadDeployedSupport() {
		return EJSContainer.getMethodContext();
	}

	public void setCustomFinderAccessIntentThreadState(boolean cfwithupdateaccess, boolean readonly,
			String methodname) {
		this.container.setCustomFinderAccessIntentThreadState(cfwithupdateaccess, readonly, methodname);
	}

	public void resetCustomFinderAccessIntentContext() {
		this.container.resetCustomFinderAccessIntentContext();
	}

	public final EJSWrapperCommon getWrapper() throws CSIException, RemoteException {
		this.homeEnabled();
		if (this.ivHomeWrappers == null || !this.ivHomeWrappers.inCache()) {
			this.ivHomeWrappers = this.wrapperManager.getWrapper(this.ivHomeId);
		}

		return this.ivHomeWrappers;
	}

	public final HomeWrapperSet getWrapperSet() throws CSIException, RemoteException {
		EJSWrapperCommon w = this.getWrapper();
		Remote remote = this.beanMetaData.homeRemoteImplClass == null ? null : w.getRemoteWrapper();
		Object local = this.beanMetaData.homeLocalImplClass == null ? null : w.getLocalWrapper();
		return new HomeBindingInfo(remote, local);
	}

	public final EJSWrapperCommon getWrapper(BeanId id) throws CSIException, RemoteException {
		this.homeEnabled();
		return this.wrapperManager.getWrapper(id);
	}

	final TimedObjectWrapper getTimedObjectWrapper(BeanId beanId) {
		TimedObjectWrapper timedWrapper = null;
		timedWrapper = (TimedObjectWrapper) this.container.ivTimedObjectPool.get();
		if (timedWrapper == null) {
			timedWrapper = new TimedObjectWrapper();
			timedWrapper.container = this.container;
			timedWrapper.wrapperManager = this.wrapperManager;
			timedWrapper.ivCommon = null;
			timedWrapper.isManagedWrapper = false;
			timedWrapper.ivInterface = WrapperInterface.TIMED_OBJECT;
		}

		timedWrapper.beanId = beanId;
		timedWrapper.bmd = this.beanMetaData;
		timedWrapper.methodInfos = this.beanMetaData.timedMethodInfos;
		timedWrapper.methodNames = this.beanMetaData.timedMethodNames;
		timedWrapper.isolationAttrs = null;
		timedWrapper.ivPmiBean = this.pmiBean;
		return timedWrapper;
	}

	final void putTimedObjectWrapper(TimedObjectWrapper timedWrapper) {
		timedWrapper.beanId = null;
		timedWrapper.bmd = null;
		timedWrapper.methodInfos = null;
		timedWrapper.isolationAttrs = null;
		timedWrapper.methodNames = null;
		timedWrapper.ivPmiBean = null;
		this.container.ivTimedObjectPool.put(timedWrapper);
	}

	private BeanO createBeanO(EJBThreadData threadData, ContainerTx tx, boolean activate, ManagedObjectContext context)
			throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createBeanO(ContainerTx, activate) activate = " + activate);
		}

		this.homeEnabled();
		BeanO result = null;
		if (this.beanMetaData.ivMaxCreation > 0) {
			result = this.allocateBeanO(tx);
		} else if (this.ivSingletonSessionHome) {
			result = this.createSingletonBeanO();
		} else if (this.beanPool != null) {
			result = (BeanO) this.beanPool.get();
		}

		if (result == null) {
			if (this.statefulSessionHome && activate) {
				result = this.beanOFactory.create(this.container, (ManagedObject) null, (Object) null, this);
			} else {
				long createStartTime = -1L;

				try {
					if (this.pmiBean != null && (this.statelessSessionHome || this.messageDrivenHome)) {
						createStartTime = this.pmiBean.initalTime(14);
					}

					result = this.createNewBeanO(context);
				} catch (EJBException var17) {
					FFDCFilter.processException(var17, "com.ibm.ejs.container.EJSHome.createBeanO", "1023", this);
					throw var17;
				} catch (RemoteException var18) {
					FFDCFilter.processException(var18, "com.ibm.ejs.container.EJSHome.createBeanO", "1029", this);
					throw var18;
				} catch (Exception var19) {
					FFDCFilter.processException(var19, "com.ibm.ejs.container.EJSHome.createBeanO", "561", this);
					throw new RemoteException(this.enterpriseBeanClass.getName(), var19);
				} finally {
					if (createStartTime > -1L) {
						this.pmiBean.finalTime(14, createStartTime);
					}

				}
			}
		} else if (!activate && this.beanMetaData.type == 6 && this.beanMetaData.cmpResetFields != null) {
			EnterpriseBean b = result.getEnterpriseBean();

			for (int i = 0; i < this.beanMetaData.cmpResetFields.length; ++i) {
				try {
					Field f = this.beanMetaData.cmpResetFields[i];
					Class<?> clzz = f.getType();
					if (clzz.isPrimitive()) {
						if (clzz == Long.TYPE) {
							f.setLong(b, 0L);
						} else if (clzz == Integer.TYPE) {
							f.setInt(b, 0);
						} else if (clzz == Boolean.TYPE) {
							f.setBoolean(b, false);
						} else if (clzz == Short.TYPE) {
							f.setShort(b, (short) 0);
						} else if (clzz == Byte.TYPE) {
							f.setByte(b, (byte) 0);
						} else if (clzz == Character.TYPE) {
							f.setChar(b, ' ');
						} else if (clzz == Double.TYPE) {
							f.setDouble(b, 0.0D);
						} else if (clzz == Float.TYPE) {
							f.setFloat(b, 0.0F);
						}
					} else {
						f.set(b, (Object) null);
					}
				} catch (IllegalAccessException var16) {
					FFDCFilter.processException(var16, "com.ibm.ejs.container.EJSHome.createBeanO", "598", this);
					throw new ContainerException("Problem occurred resetting CMP fields to Java default values", var16);
				}
			}
		}

		threadData.pushCallbackBeanO(result);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createBeanO(ContainerTx, activate) activate = " + activate);
		}

		return result;
	}

	public BeanO createBeanO(EJBThreadData threadData, ContainerTx tx, BeanId id) throws RemoteException {
		this.homeEnabled();
		BeanO result = this.createBeanO(threadData, tx, true, (ManagedObjectContext) null);
		result.setId(id);
		return result;
	}

	public BeanO createBeanO() throws RemoteException {
		EJSDeployedSupport s = EJSContainer.getMethodContext();
		return this.createBeanO(s.ivThreadData, s.currentTx, false, (ManagedObjectContext) null);
	}

	private BeanO allocateBeanO(ContainerTx tx) throws RemoteException {
		BeanO result = null;
		long wait_time = this.beanMetaData.ivMaxCreationTimeout;
		boolean beanAvailable = false;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "allocateBeanO: Obtaining HomeId lock for BeanPool : " + tx);
		}

		this.lockStrategy.lock(this.container, tx, this.ivHomeId, 1);
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "allocateBeanO: Obtained HomeId lock for BeanPool : " + tx);
		}

		try {
			while (!beanAvailable) {
				Pool var7 = this.beanPool;
				synchronized (this.beanPool) {
					result = (BeanO) this.beanPool.get();
					if (result == null) {
						if (this.ivNumberBeansCreated < this.beanMetaData.ivMaxCreation) {
							beanAvailable = true;
							++this.ivNumberBeansCreated;
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "allocateBeanO: Not found in BeanPool(" + this.ivNumberBeansCreated + "/"
										+ this.beanMetaData.ivMaxCreation + ") : creating new instance");
							}
						} else {
							long wait_interval = Math.min(wait_time, (long) BEAN_POOL_WAIT_INTERVAL);
							if (wait_interval > 0L) {
								if (isTraceOn && tc.isDebugEnabled()) {
									Tr.debug(tc,
											"allocateBeanO: Not found in BeanPool(" + this.ivNumberBeansCreated + "/"
													+ this.beanMetaData.ivMaxCreation + ") : waiting for bean - "
													+ wait_interval);
								}

								this.beanPool.wait(wait_interval);
								wait_time -= wait_interval;
							}
						}
					} else {
						beanAvailable = true;
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "allocateBeanO: Found in BeanPool(" + this.ivNumberBeansCreated + "/"
									+ this.beanMetaData.ivMaxCreation + ") : " + result);
						}
					}
				}

				if (!beanAvailable) {
					this.homeEnabled();
					if (tx.getGlobalRollbackOnly()) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"allocateBeanO: Tx timeout waiting for bean ("
											+ (this.beanMetaData.ivMaxCreationTimeout - wait_time) + "): BeanPool("
											+ this.ivNumberBeansCreated + "/" + this.beanMetaData.ivMaxCreation + ")");
						}

						throw new CSITransactionRolledbackException("Transaction timed out or marked rolled back");
					}

					if (wait_time <= 0L) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"allocateBeanO: Wait timeout waiting for bean ("
											+ this.beanMetaData.ivMaxCreationTimeout + "): BeanPool("
											+ this.ivNumberBeansCreated + "/" + this.beanMetaData.ivMaxCreation + ")");
						}

						throw new EJBException("Instance of EJB " + this.j2eeName + " not available : wait timeout");
					}
				}
			}
		} catch (InterruptedException var16) {
			FFDCFilter.processException(var16, "com.ibm.ejs.container.EJSHome.allocateBeanO", "919", this);
			ContainerEJBException ex = new ContainerEJBException(
					"Instance of EJB " + this.j2eeName + " not available : interrupted", var16);
			Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var16, ex.toString()});
			throw ex;
		} finally {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "allocateBeanO: Releasing HomeId lock for BeanPool : " + tx);
			}

			this.lockStrategy.unlock(this.container, this.ivHomeId, tx);
		}

		return result;
	}

	public EJSWrapper createWrapper(BeanId id) throws CreateException, RemoteException, CSIException {
		this.homeEnabled();
		EJSWrapper result = null;
		if (this.ivStatelessWrappers != null && this.ivStatelessWrappers.inCache()) {
			result = this.ivStatelessWrappers.getRemoteWrapper();
		} else if (this.statelessSessionHome) {
			this.ivStatelessWrappers = this.wrapperManager.getWrapper(this.ivStatelessId);
			result = this.ivStatelessWrappers.getRemoteWrapper();
		}

		return result;
	}

	public EJSLocalWrapper createWrapper_Local(BeanId id) throws CreateException, RemoteException, CSIException {
		this.homeEnabled();
		EJSLocalWrapper result = null;
		if (this.ivStatelessWrappers != null && this.ivStatelessWrappers.inCache()) {
			result = (EJSLocalWrapper) this.ivStatelessWrappers.getLocalObject();
		} else if (this.statelessSessionHome || this.messageDrivenHome) {
			this.ivStatelessWrappers = this.wrapperManager.getWrapper(this.ivStatelessId);
			result = (EJSLocalWrapper) this.ivStatelessWrappers.getLocalObject();
		}

		return result;
	}

	public Object createBusinessObject(String businessInterfaceName, boolean useSupporting)
			throws CreateException, RemoteException, ClassNotFoundException, EJBConfigurationException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createBusinessObject: " + businessInterfaceName);
		}

		int localIndex = this.beanMetaData.getLocalBusinessInterfaceIndex(businessInterfaceName);
		if (localIndex != -1) {
			return this.createLocalBusinessObject(localIndex, (ManagedObjectContext) null);
		} else {
			int remoteIndex = this.beanMetaData.getRemoteBusinessInterfaceIndex(businessInterfaceName);
			if (remoteIndex != -1) {
				this.container.getEJBRuntime().checkRemoteSupported(this, businessInterfaceName);
				return this.createRemoteBusinessObject(remoteIndex, (ManagedObjectContext) null);
			} else if (useSupporting) {
				Class<?> target = this.beanMetaData.classLoader.loadClass(businessInterfaceName);
				localIndex = this.beanMetaData.getAssignableLocalBusinessInterfaceIndex(target);
				remoteIndex = this.beanMetaData.getAssignableRemoteBusinessInterfaceIndex(target);
				EJBConfigurationException ejbex;
				if (localIndex != -1) {
					if (remoteIndex != -1) {
						Tr.error(tc, "AMBIGUOUS_REFERENCE_TO_DUPLICATE_INTERFACE_CNTR0155E",
								new Object[]{this.beanMetaData.enterpriseBeanName,
										this.beanMetaData._moduleMetaData.ivName, businessInterfaceName});
						ejbex = new EJBConfigurationException(
								"Another component has an ambiguous reference to interface: " + businessInterfaceName
										+ " which has both local and remote implementions on bean: " + this.j2eeName);
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "createBusinessObject : " + ejbex);
						}

						throw ejbex;
					} else {
						return this.createLocalBusinessObject(localIndex, (ManagedObjectContext) null);
					}
				} else if (remoteIndex == -1) {
					Tr.error(tc, "ATTEMPT_TO_REFERENCE_MISSING_INTERFACE_CNTR0154E",
							new Object[]{this.beanMetaData.enterpriseBeanName, this.beanMetaData._moduleMetaData.ivName,
									businessInterfaceName});
					ejbex = new EJBConfigurationException(
							"Another component is attempting to reference local interface: " + businessInterfaceName
									+ " which is not implemented by bean: " + this.j2eeName);
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "createBusinessObject : " + ejbex);
					}

					throw ejbex;
				} else {
					this.container.getEJBRuntime().checkRemoteSupported(this, businessInterfaceName);
					return this.createRemoteBusinessObject(remoteIndex, (ManagedObjectContext) null);
				}
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"createBusinessObject : IllegalStateException : Requested business interface not found : "
									+ businessInterfaceName);
				}

				throw new IllegalStateException("Requested business interface not found : " + businessInterfaceName);
			}
		}
	}

	public Object createLocalBusinessObject(String interfaceName, boolean useSupporting)
			throws RemoteException, CreateException, ClassNotFoundException, EJBConfigurationException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createLocalBusinessObject: " + interfaceName);
		}

		int interfaceIndex;
		if (useSupporting) {
			interfaceIndex = this.beanMetaData.getSupportingLocalBusinessInterfaceIndex(interfaceName);
		} else {
			interfaceIndex = this.beanMetaData.getRequiredLocalBusinessInterfaceIndex(interfaceName);
		}

		Object result = this.createLocalBusinessObject(interfaceIndex, (ManagedObjectContext) null);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createLocalBusinessObject returning: " + Util.identity(result));
		}

		return result;
	}

	public Object createLocalBusinessObject(int interfaceIndex, ManagedObjectContext context)
			throws RemoteException, CreateException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createLocalBusinessObject: " + interfaceIndex);
		}

		EJSWrapperCommon commonWrapper = this.createBusinessObjectWrappers(context);
		Object result = commonWrapper.getLocalBusinessObject(interfaceIndex);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createLocalBusinessObject returning: " + Util.identity(result));
		}

		return result;
	}

	public Object createRemoteBusinessObject(String interfaceName, boolean useSupporting)
			throws RemoteException, CreateException, ClassNotFoundException, EJBConfigurationException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createRemoteBusinessObject: " + interfaceName);
		}

		int interfaceIndex;
		if (useSupporting) {
			interfaceIndex = this.beanMetaData.getSupportingRemoteBusinessInterfaceIndex(interfaceName);
		} else {
			interfaceIndex = this.beanMetaData.getRemoteBusinessInterfaceIndex(interfaceName);
			if (interfaceIndex == -1) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"createRemoteBusinessObject : IllegalStateException : Requested business interface not found : "
									+ interfaceName);
				}

				throw new IllegalStateException("Requested business interface not found : " + interfaceName);
			}
		}

		Object result = this.createRemoteBusinessObject(interfaceIndex, (ManagedObjectContext) null);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createRemoteBusinessObject returning: " + Util.identity(result));
		}

		return result;
	}

	public Object createRemoteBusinessObject(int interfaceIndex, ManagedObjectContext context)
			throws RemoteException, CreateException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createRemoteBusinessObject: " + interfaceIndex);
		}

		EJSWrapperCommon commonWrapper = this.createBusinessObjectWrappers(context);
		Object result = commonWrapper.getRemoteBusinessObject(interfaceIndex);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createRemoteBusinessObject returning: " + Util.identity(result));
		}

		return result;
	}

	public Object createAggregateLocalReference(ManagedObjectContext context) throws CreateException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createAggregateLocalReference: " + this.beanMetaData.j2eeName);
		}

		Object result = null;

		try {
			EJSWrapperCommon wrappers = this.createBusinessObjectWrappers(context);
			result = wrappers.getAggregateLocalWrapper(this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createAggregateLocalReference: " + Util.identity(result));
			}

			return result;
		} catch (RemoteException var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.EJSHome.createAggregateLocalReference", "1697",
					this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createAggregateLocalReference: " + Util.identity(result));
			}

			throw ExceptionUtil.EJBException("Failed to create aggregate local reference: ", var5);
		}
	}

	private EJSWrapperCommon createBusinessObjectWrappers(ManagedObjectContext context)
			throws CreateException, RemoteException {
		this.homeEnabled();
		EJSWrapperCommon result = null;
		if (!this.ivSingletonSessionHome && !this.statelessSessionHome) {
			if (this.statefulSessionHome) {
				EJSDeployedSupport s = new EJSDeployedSupport();

				try {
					this.container.preInvoke(this.ivStatefulBusinessHomeWrapper, 0, s);
					BeanO beanO = null;
					boolean exceptionOccurred = false;
					boolean preEjbCreateCalled = false;

					try {
						beanO = this.createBeanO(s.ivThreadData, s.currentTx, false, context);
						preEjbCreateCalled = this.preEjbCreate(beanO);
						result = this.postCreateCommon(beanO, beanO.getId(), false);
						EJSContainer.getThreadData().popCallbackBeanO();
					} catch (CreateException var28) {
						exceptionOccurred = true;
						throw var28;
					} catch (Throwable var29) {
						exceptionOccurred = true;
						throw ExceptionUtil.EJBException("Create failed", var29);
					} finally {
						if (exceptionOccurred) {
							this.createFailure(beanO);
						} else if (preEjbCreateCalled) {
							this.afterPostCreateCompletion(beanO);
						}

					}
				} catch (CreateException var31) {
					s.setCheckedException(var31);
					throw var31;
				} catch (Throwable var32) {
					s.setUncheckedLocalException(var32);
				} finally {
					try {
						this.container.postInvoke(this.ivStatefulBusinessHomeWrapper, 0, s);
					} catch (Throwable var27) {
						s.setUncheckedLocalException(var27);
					}

				}
			}
		} else if (this.ivStatelessWrappers != null && this.ivStatelessWrappers.inCache()) {
			result = this.ivStatelessWrappers;
		} else {
			this.ivStatelessWrappers = this.wrapperManager.getWrapper(this.ivStatelessId);
			result = this.ivStatelessWrappers;
		}

		return result;
	}

	public EJSWrapperCommon internalCreateWrapper(BeanId id) throws RemoteException {
		this.homeEnabled();
		EJSWrapperCommon wrappers;
		if (this.ivStatelessWrappers != null) {
			wrappers = this.ivStatelessWrappers;
		} else {
			wrappers = new EJSWrapperCommon(this.remoteEJBObjectClass, this.localEJBObjectClass, id, this.beanMetaData,
					this.pmiBean, this.container, this.wrapperManager, false);
		}

		return wrappers;
	}

	public final boolean isMessageDrivenHome() {
		return this.messageDrivenHome;
	}

	public final boolean isSingletonSessionHome() {
		return this.ivSingletonSessionHome;
	}

	public final boolean isStatelessSessionHome() {
		return this.statelessSessionHome;
	}

	public final boolean isStatefulSessionHome() {
		return this.statefulSessionHome;
	}

	public boolean isManagedBeanHome() {
		return false;
	}

	public BeanMetaData getBeanMetaData(Object homeKey) {
		this.homeEnabled();
		return this.beanMetaData;
	}

	public BeanMetaData getBeanMetaData() {
		this.homeEnabled();
		return this.beanMetaData;
	}

	public ClassLoader getClassLoader() {
		this.homeEnabled();
		return this.beanMetaData.classLoader;
	}

	public final ActivationStrategy getActivationStrategy() {
		return this.activationStrategy;
	}

	public final String getMethodName(Object homeKey, int id, boolean isHome) {
		this.homeEnabled();
		return isHome ? this.beanMetaData.homeMethodNames[id] : this.beanMetaData.methodNames[id];
	}

	public String getEnterpriseBeanClassName(Object homeKey) {
		this.homeEnabled();
		return this.beanMetaData.enterpriseBeanClass.getName();
	}

	public final Handle createHandle(BeanId id) throws RemoteException {
		EJBObject wrapper = null;
		this.homeEnabled();
		wrapper = this.getWrapper(id).getRemoteWrapper();
		if (!this.statelessSessionHome && !this.statefulSessionHome) {
			if (cvUsePortableClass) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "createHandle():Creating portable HandleImpl");
				}

				return new HandleImpl((EJBObject) PortableRemoteObject.toStub(wrapper));
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "createHandle():Creating non-portable EntityHandle");
				}

				Properties pFake = null;
				return new EntityHandle(id, this.beanMetaData, (Properties) pFake);
			}
		} else {
			return this.container.sessionHandleFactory.create((EJBObject) PortableRemoteObject.toStub(wrapper));
		}
	}

	public EJSWrapperCommon activateBean(BeanId beanId, ContainerTx currentTx) throws CSIException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "activateBean (" + beanId + ")", currentTx);
		}

		this.homeEnabled();
		EJSWrapperCommon result = null;

		try {
			if (currentTx.ivFlushRequired) {
				IllegalStateException isex = new IllegalStateException(
						"Persistence Manager failed to perform synchronization of Entity beans prior to find<METHOD>");
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "activateBean", isex);
				}

				throw isex;
			}

			beanId = this.wrapperManager.beanIdCache.find(beanId);
			this.container.activator.activateBean(EJSContainer.getThreadData(), currentTx, beanId);
			result = this.wrapperManager.getWrapper(beanId);
		} catch (NoSuchObjectException var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.container.EJSHome.activateBean", "998", this);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "activateBean : NoSuchObjectException", var6);
			}

			result = this.getWrapper(beanId);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "activateBean", result);
		}

		return result;
	}

	public EJBObject activateBean(Object primaryKey) throws FinderException, RemoteException {
		EJSWrapperCommon wrappers = null;
		if (primaryKey == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "activateBean : key = null, returning null");
			}

			return null;
		} else {
			boolean pkeyCopyRequired = false;
			if (this.noLocalCopies && this.allowPrimaryKeyMutation && !this.statefulSessionHome) {
				pkeyCopyRequired = true;
			}

			wrappers = this.ivEntityHelper.activateBean_Common(this, primaryKey, pkeyCopyRequired);
			return wrappers.getRemoteWrapper();
		}
	}

	public EJBLocalObject activateBean_Local(Object primaryKey) throws FinderException, RemoteException {
		EJSWrapperCommon wrappers = null;
		if (primaryKey == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "activateBean_Local : key = null, returning null");
			}

			return null;
		} else {
			boolean pkeyCopyRequired = false;
			if (!this.noPrimaryKeyMutation && !this.statefulSessionHome) {
				pkeyCopyRequired = true;
			}

			wrappers = this.ivEntityHelper.activateBean_Common(this, primaryKey, pkeyCopyRequired);
			return wrappers.getLocalObject();
		}
	}

	public EJBObject getBeanWrapper(Object primaryKey) throws FinderException, RemoteException {
		BeanId id = new BeanId(this, (Serializable) primaryKey, false);
		return this.getWrapper(id).getRemoteWrapper();
	}

	public EJBObject getBean(String type, Object primaryKey, Object data) throws FinderException, RemoteException {
		return this.ivEntityHelper.getBean(this, type, primaryKey, data);
	}

	public final boolean hasInheritance() {
		return this.homeRecord.ivHasInheritance;
	}

	public boolean isChild() {
		return this.homeRecord.ivIsChild;
	}

	public EJBObject getBean(Object primaryKey) throws RemoteException {
		return this.ivEntityHelper.getBean(this, primaryKey);
	}

	public EJBLocalObject getBean_Local(Object primaryKey) throws RemoteException {
		return this.ivEntityHelper.getBean_Local(this, primaryKey);
	}

	public EJBObject postCreate(BeanO beanO, Object primaryKey, boolean inSupportOfEJBPostCreateChanges)
			throws CreateException, RemoteException {
		boolean supportEJBPostCreateChanges = inSupportOfEJBPostCreateChanges && !this.ivAllowEarlyInsert;
		if (this.noLocalCopies && this.allowPrimaryKeyMutation && !this.statefulSessionHome) {
			try {
				primaryKey = ObjectUtil.copy((Serializable) primaryKey);
			} catch (Throwable var7) {
				FFDCFilter.processException(var7, "com.ibm.ejs.container.EJSHome.postCreate", "1551", this);
				ContainerEJBException ex = new ContainerEJBException(
						"postCreate failed attempting to process PrimaryKey", var7);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var7, ex.toString()});
				throw ex;
			}
		}

		EJSWrapperCommon common = this.postCreateCommon(beanO, primaryKey, supportEJBPostCreateChanges);
		EJSWrapper w = common.getRemoteWrapper();
		if (!inSupportOfEJBPostCreateChanges || this.statefulSessionHome) {
			EJSContainer.getThreadData().popCallbackBeanO();
		}

		return w;
	}

	public EJBObject postCreate(BeanO beanO) throws CreateException, RemoteException {
		this.homeEnabled();
		return this.postCreate(beanO, beanO.getId(), false);
	}

	public EJBObject postCreate(BeanO beanO, boolean supportEJBPostCreateChanges)
			throws CreateException, RemoteException {
		this.homeEnabled();
		return this.postCreate(beanO, beanO.getId(), supportEJBPostCreateChanges);
	}

	public EJBObject postCreate(BeanO beanO, Object primaryKey) throws CreateException, RemoteException {
		this.homeEnabled();
		return this.postCreate(beanO, primaryKey, false);
	}

	private EJSWrapperCommon postCreateCommon(BeanO beanO, Object primaryKey, boolean supportEJBPostCreateChanges)
			throws CreateException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "postCreate", primaryKey);
		}

		ContainerTx currentTx = null;
		this.homeEnabled();
		if (!this.statefulSessionHome) {
			beanO.setId(new BeanId(this, (Serializable) primaryKey, false));
		}

		currentTx = this.container.getCurrentTx(false);
		this.container.lockBean(beanO, currentTx);
		beanO.postCreate(supportEJBPostCreateChanges);
		BeanO existingBeanO = this.container.addBean(beanO, currentTx);
		if (existingBeanO != null) {
			throw new DuplicateKeyException(primaryKey.toString());
		} else {
			if (!supportEJBPostCreateChanges && this.pmiBean != null) {
				this.pmiBean.beanCreated();
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "postCreate", beanO);
			}

			return this.wrapperManager.getWrapperForCreate(beanO);
		}
	}

	public void afterPostCreate(BeanO beanO, Object primaryKey) throws CreateException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "afterPostCreate", primaryKey);
		}

		if (!this.ivAllowEarlyInsert) {
			this.homeEnabled();
			beanO.afterPostCreate();
			if (this.pmiBean != null) {
				this.pmiBean.beanCreated();
			}
		}

		EJSContainer.getThreadData().popCallbackBeanO();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "afterPostCreate", beanO);
		}

	}

	public void afterPostCreateCompletion(BeanO beanO) throws CreateException {
		beanO.afterPostCreateCompletion();
	}

	public EJBLocalObject postCreate_Local(BeanO beanO, Object primaryKey, boolean supportEJBPostCreateChanges)
			throws CreateException, ContainerException, RemoteException {
		if (!this.noPrimaryKeyMutation && !this.statefulSessionHome) {
			try {
				primaryKey = ObjectUtil.copy((Serializable) primaryKey);
			} catch (Throwable var6) {
				FFDCFilter.processException(var6, "com.ibm.ejs.container.EJSHome.postCreate_Local", "1674", this);
				ContainerEJBException ex = new ContainerEJBException(
						"postCreate_Local failed attempting to process PrimaryKey", var6);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var6, ex.toString()});
				throw ex;
			}
		}

		EJSWrapperCommon common = this.postCreateCommon(beanO, primaryKey, supportEJBPostCreateChanges);
		EJBLocalObject w = common.getLocalObject();
		if (!supportEJBPostCreateChanges || this.statefulSessionHome) {
			EJSContainer.getThreadData().popCallbackBeanO();
		}

		return w;
	}

	public EJBLocalObject postCreate_Local(BeanO beanO) throws CreateException, ContainerException, RemoteException {
		this.homeEnabled();
		return this.postCreate_Local(beanO, beanO.getId(), false);
	}

	public EJBLocalObject postCreate_Local(BeanO beanO, boolean supportEJBPostCreateChanges)
			throws CreateException, ContainerException, RemoteException {
		this.homeEnabled();
		return this.postCreate_Local(beanO, beanO.getId(), supportEJBPostCreateChanges);
	}

	public EJBLocalObject postCreate_Local(BeanO beanO, Object primaryKey)
			throws CreateException, ContainerException, RemoteException {
		this.homeEnabled();
		return this.postCreate_Local(beanO, primaryKey, false);
	}

	public void createFailure(BeanO beanO) {
		if (beanO != null) {
			EJSContainer.getThreadData().popCallbackBeanO();
			beanO.destroy();

			try {
				this.container.removeBean(beanO);
			} catch (CSITransactionRolledbackException var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.EJSHome.createFailure", "1732", this);
			}
		}

	}

	public void remove(Handle handle) throws RemoteException, RemoveException {
		this.homeEnabled();
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "remove", handle);
		}

		EJBObject ejb = handle.getEJBObject();
		ejb.remove();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "remove");
		}

	}

	public void remove(Object primaryKey) throws RemoteException, RemoveException, FinderException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "remove(pk) : " + primaryKey);
		}

		this.homeEnabled();
		if (!this.statefulSessionHome && !this.statelessSessionHome && !this.messageDrivenHome) {
			BeanId beanId = this.ivEntityHelper.remove(this, primaryKey);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "remove(pk) : " + beanId);
			}

		} else {
			throw new RemoveException();
		}
	}

	public EntityBeanO getFindByPrimaryKeyEntityBeanO() throws RemoteException {
		return this.ivEntityHelper.getFindByPrimaryKeyEntityBeanO(this);
	}

	public EntityBeanO getFinderEntityBeanO() throws RemoteException {
		return this.ivEntityHelper.getFinderEntityBeanO(this);
	}

	public void discardFinderEntityBeanO(EntityBeanO beanO) throws RemoteException {
		this.ivEntityHelper.discardFinderEntityBeanO(this, beanO);
	}

	public void releaseFinderEntityBeanO(EntityBeanO beanO) throws RemoteException {
		this.ivEntityHelper.releaseFinderEntityBeanO(this, beanO);
	}

	public BeanManagedBeanO getFinderBeanO() throws RemoteException {
		return this.ivEntityHelper.getFinderBeanO(this);
	}

	public void releaseFinderBeanO(BeanManagedBeanO beanO) throws RemoteException {
		this.ivEntityHelper.releaseFinderBeanO(this, beanO);
	}

	public EntityBeanO getHomeMethodEntityBeanO() throws RemoteException {
		return this.ivEntityHelper.getHomeMethodEntityBeanO(this);
	}

	public void releaseHomeMethodEntityBeanO(EntityBeanO beanO) throws RemoteException {
		this.ivEntityHelper.releaseHomeMethodEntityBeanO(this, beanO);
	}

	public Enumeration getEnumeration(Finder finder) throws FinderException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEnumeration(EJSFinder)");
		}

		this.homeEnabled();
		ContainerTx currentTx = this.container.getCurrentTx(false);
		Enumeration rtnEnum = this.container.persisterFactory.wrapResultsInEnumeration(currentTx, this, finder);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEnumeration");
		}

		return rtnEnum;
	}

	public Collection getCollection(Finder finder) throws FinderException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getCollection(EJSFinder)");
		}

		this.homeEnabled();
		ContainerTx currentTx = this.container.getCurrentTx(false);
		Collection rtnColl = this.container.persisterFactory.wrapResultsInCollection(currentTx, this, finder);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getCollection");
		}

		return rtnColl;
	}

	public Enumeration getEnumeration(Enumeration keys) throws FinderException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEnumeration(Enumeration)");
		}

		this.homeEnabled();
		ContainerTx currentTx = this.container.getCurrentTx(false);
		Enumeration rtnEnum = this.container.persisterFactory.wrapResultsInEnumeration(currentTx, this, keys);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEnumeration");
		}

		return rtnEnum;
	}

	public Collection getCollection(Collection keys) throws FinderException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getCollection(Collection)");
		}

		this.homeEnabled();
		ContainerTx currentTx = this.container.getCurrentTx(false);
		Collection rtnColl = this.container.persisterFactory.wrapResultsInCollection(currentTx, this, keys);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getCollection");
		}

		return rtnColl;
	}

	public Enumeration getCMP20Enumeration(Enumeration keys) throws FinderException, RemoteException {
		return this.ivEntityHelper.getCMP20Enumeration(this, keys);
	}

	public Enumeration getCMP20Enumeration_Local(Enumeration keys) throws FinderException, RemoteException {
		return this.ivEntityHelper.getCMP20Enumeration_Local(this, keys);
	}

	public Collection getCMP20Collection(Collection keys) throws FinderException, RemoteException {
		return this.ivEntityHelper.getCMP20Collection(this, keys);
	}

	public Collection getCMP20Collection_Local(Collection keys) throws FinderException, RemoteException {
		return this.ivEntityHelper.getCMP20Collection_Local(this, keys);
	}

	public EJBMetaData getEJBMetaData() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBMetaData");
		}

		this.homeEnabled();
		if (this.ejbMetaData == null) {
			EJSWrapper wrapper = this.getWrapper().getRemoteWrapper();
			if (!cvUsePortableClass) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "getEJBMetaData():Creating non-portable EJBMetaDataImpl");
				}

				this.ejbMetaData = new EJBMetaDataImpl(this.beanMetaData, this.getWrapper().getRemoteWrapper(),
						this.j2eeName);
			} else {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "getEJBMetaData():Creating portable EJBMetaDataImpl");
				}

				EJBHome homeStub = (EJBHome) PortableRemoteObject.toStub(wrapper);
				Class<?> pKeyClass = null;
				if (this.beanMetaData.pKeyClass != null) {
					pKeyClass = this.beanMetaData.pKeyClass;
				}

				int beanType = 3;
				if (this.beanMetaData.type == 4) {
					beanType = 1;
				} else if (this.beanMetaData.type == 3) {
					beanType = 2;
				}

				this.ejbMetaData = new com.ibm.ws.ejb.portable.EJBMetaDataImpl(beanType, homeStub,
						this.beanMetaData.enterpriseBeanAbstractClass, this.beanMetaData.homeInterfaceClass,
						this.beanMetaData.remoteInterfaceClass, pKeyClass);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEJBMetaData", this.ejbMetaData);
		}

		return this.ejbMetaData;
	}

	public HomeHandle getHomeHandle() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getHomeHandle");
		}

		ComponentMetaDataAccessorImpl cmdAccessor = null;

		Object var13;
		try {
			cmdAccessor = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor();
			cmdAccessor.beginContext(this.beanMetaData);
			Object ehh = null;

			try {
				EJSWrapper wrapper;
				if (cvUsePortableClass) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "getHomeHandle():Creating portable HomeHandleImpl");
					}

					wrapper = this.getWrapper().getRemoteWrapper();
					EJBHome home = (EJBHome) PortableRemoteObject.toStub(wrapper);
					ehh = new HomeHandleImpl(home);
				} else {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "getHomeHandle():Creating non-portable EntityHomeHandle");
					}

					wrapper = null;
					ehh = new EntityHomeHandle(this.ivHomeId, this.beanMetaData.homeInterfaceClass.getName(),
							this.beanMetaData, wrapper);
				}
			} catch (Exception var10) {
				FFDCFilter.processException(var10, "com.ibm.ejs.container.EJSHome.getHomeHandle", "2362", this);
				EJBException ex = new EJBException("get of EJBHome failed", var10);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var10, ex.toString()});
				throw ex;
			} catch (Throwable var11) {
				FFDCFilter.processException(var11, "com.ibm.ejs.container.EJSHome.getHomeHandle", "2372", this);
				ContainerEJBException ex = new ContainerEJBException("get of EJBHome failed", var11);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var11, ex.toString()});
				throw ex;
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getHomeHandle", ehh);
			}

			var13 = ehh;
		} finally {
			if (cmdAccessor != null) {
				cmdAccessor.endContext();
			}

		}

		return (HomeHandle) var13;
	}

	public LockStrategy getLockStrategy() {
		return this.lockStrategy;
	}

	public Properties getEnvironment() {
		this.homeEnabled();
		return this.environment;
	}

	public void ejbCreate() throws RemoteException {
	}

	public void ejbActivate() throws RemoteException {
	}

	public void ejbPassivate() throws RemoteException {
		throw new NotImplementedException();
	}

	public void ejbRemove() throws RemoteException {
	}

	public void setSessionContext(SessionContext ctx) throws RemoteException {
	}

	public void discard(Object o) {
		BeanO beanO = (BeanO) o;
		beanO.destroy();
	}

	public boolean preEjbCreate(BeanO beanO) throws CreateException {
		if (this.beanMetaData.ivCacheReloadType != 0) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "CreateException: Read only EJB may not be created.");
			}

			throw new CreateException("Read only EJB may not be created.");
		} else {
			beanO.preEjbCreate();
			return true;
		}
	}

	public void postEjbPostCreate(BeanO beanO) throws CreateException {
		beanO.afterPostCreateCompletion();
	}

	protected final Object WASInternal_copyPrimaryKey(Object obj) {
		if (!this.noPrimaryKeyMutation && !this.statefulSessionHome) {
			Object copy = null;
			Object oldCL = EJBThreadData.svThreadContextAccessor
					.pushContextClassLoaderForUnprivileged(this.beanMetaData.classLoader);

			try {
				copy = ObjectUtil.copy((Serializable) obj);
			} catch (Throwable var9) {
				FFDCFilter.processException(var9, "com.ibm.ejs.container.EJSHome.WASInternal_copyPrimaryKey", "4016",
						this);
				ContainerEJBException ex = new ContainerEJBException(
						"WASInternal_copyPrimaryKey failed attempting to process PrimaryKey", var9);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var9, ex.toString()});
				throw ex;
			} finally {
				EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(oldCL);
			}

			return copy;
		} else {
			return obj;
		}
	}

	public final boolean hasMethodLevelAccessIntentSet() {
		return this.ivEntityHelper.hasMethodLevelAccessIntentSet(this);
	}

	public HomeRecord getHomeRecord() {
		return this.homeRecord;
	}

	public synchronized BeanO createSingletonBeanO() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createSingletonBeanO: " + this.j2eeName);
		}

		this.homeEnabled();
		BeanO result = null;
		if (this.ivSingletonBeanO == null) {
			if (this.ivCreatingSingletonBeanO) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createSingletonBeanO: IllegalLoopbackException");
				}

				throw new IllegalLoopbackException(
						"Cannot call a method on a singleton session bean while constructing the bean instance : "
								+ this.j2eeName);
			}

			if (this.ivSingletonBeanOCreateFailed) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "createSingletonBeanO: NoSuchEJBException - prior failure");
				}

				throw ExceptionUtil.NoSuchEJBException(
						"An error occurred during a previous attempt to initialize the singleton session bean "
								+ this.j2eeName + ".",
						(Throwable) null);
			}

			this.ivCreatingSingletonBeanO = true;

			try {
				this.ivSingletonBeanOCreateFailed = true;

				List dependsOn;
				try {
					dependsOn = this.beanMetaData._moduleMetaData.getEJBApplicationMetaData()
							.resolveBeanDependencies(this.beanMetaData);
				} catch (RuntimeWarning var23) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "dependency resolution error", var23);
					}

					throw ExceptionUtil.NoSuchEJBException(var23.getMessage(), var23);
				}

				if (dependsOn != null) {
					Iterator i$ = dependsOn.iterator();

					while (i$.hasNext()) {
						J2EEName dependency = (J2EEName) i$.next();
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "initializing dependency " + dependency);
						}

						try {
							EJSHome dependencyHome = (EJSHome) EJSContainer.homeOfHomes.getHome(dependency);
							dependencyHome.createSingletonBeanO();
						} catch (Throwable var22) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.exit(tc, "createSingletonBeanO: failed to initialize dependency", var22);
							}

							throw ExceptionUtil.NoSuchEJBException(
									"Failed to initialize singleton session bean " + this.j2eeName
											+ " because the dependency " + dependency + " failed to initialize.",
									var22);
						}
					}
				}

				this.beanMetaData._moduleMetaData.getEJBApplicationMetaData().addSingletonInitialization(this);
				long createStartTime = -1L;
				Object oldClassLoader = ThreadContextAccessor.UNCHANGED;

				try {
					if (this.pmiBean != null) {
						createStartTime = this.pmiBean.initalTime(14);
					}

					ivCMDAccessor.beginContext(this.beanMetaData);
					oldClassLoader = EJBThreadData.svThreadContextAccessor
							.pushContextClassLoaderForUnprivileged(this.beanMetaData.ivContextClassLoader);
					this.ivSingletonBeanO = (SingletonBeanO) this.createNewBeanO((ManagedObjectContext) null);
					this.ivSingletonBeanOCreateFailed = false;
				} catch (Throwable var21) {
					FFDCFilter.processException(var21, "com.ibm.ejs.container.EJSHome.createBeanO", "1047", this);
					String msgTxt = "An error occurred during initialization of singleton session bean " + this.j2eeName
							+ ", resulting in the discarding of the singleton instance.";
					throw ExceptionUtil.NoSuchEJBException(msgTxt, var21);
				} finally {
					EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(oldClassLoader);
					ivCMDAccessor.endContext();
					if (createStartTime > -1L) {
						this.pmiBean.finalTime(14, createStartTime);
					}

				}
			} finally {
				this.ivCreatingSingletonBeanO = false;
			}
		}

		result = this.ivSingletonBeanO;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createSingletonBeanO");
		}

		return result;
	}

	static {
		cvUsePortableClass = ContainerProperties.Portable;
	}
}