package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.managedobject.ManagedObject;
import java.rmi.RemoteException;

public class BMStatelessBeanO extends StatelessBeanO {
	private static final TraceComponent tc = Tr.register(BMStatelessBeanO.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public BMStatelessBeanO(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		super(c, mo, b, h);
	}

	public void setRollbackOnly() {
		throw new IllegalStateException();
	}

	public boolean getRollbackOnly() {
		throw new IllegalStateException();
	}

	public final void postInvoke(int id, EJSDeployedSupport s) throws RemoteException {
		if (this.state != 0) {
			ContainerTx tx = null;
			if (null == this.ivContainerTx) {
				tx = this.ivContainerTx;
			} else {
				tx = this.container.getCurrentTx(false);
			}

			if (tx != null && tx.isBmtActive(s.methodInfo)) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Stateless SB method is not allowed to leave a BMT active. Discarding bean.");
				}

				this.discard();
			}

			this.ivContainerTx = null;
		}
	}
}