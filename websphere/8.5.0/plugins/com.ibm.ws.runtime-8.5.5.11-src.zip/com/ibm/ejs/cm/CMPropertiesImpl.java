package com.ibm.ejs.cm;

import com.ibm.ISecurityUtilityImpl.PasswordUtil;
import com.ibm.ejs.cm.portability.PortableDataSource;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.advanced.cm.factory.CMFactoryException;
import com.ibm.websphere.advanced.cm.factory.DataSourceFactory;
import com.ibm.websphere.advanced.cm.factory.MissingRequiredPropertyException;
import com.ibm.websphere.advanced.cm.factory.DataSourceFactory.ResourceReferenceObjectFactory;
import com.ibm.ws.naming.util.CacheableReference;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import javax.naming.NamingException;
import javax.naming.Reference;
import javax.naming.Referenceable;
import javax.naming.StringRefAddr;

public class CMPropertiesImpl implements CMProperties, Cloneable, Serializable, Referenceable {
	private static final long serialVersionUID = 6331612919972538005L;
	private String name;
	private int diagOptions;
	public static final int DIAG_OPTION_OFF = 0;
	public static final int DIAG_OPTION_ORPHAN_NOTIFY = 1;
	public static final int DIAG_OPTION_ORPHAN_CODE_PATH = 2;
	public static final int DIAG_OPTION_CONN_WAIT_CODE_PATH = 4;
	private boolean transactionBranchesLooselyCoupled;
	private boolean validate;
	private String validateSQL;
	private String dataBaseVersion;
	private boolean resetReadOnly;
	private boolean secureXACredential;
	private int min;
	private int max;
	private int connTimeout;
	private int idleTimeout;
	private int orphanTimeout;
	private int agedTimeout;
	private int statementCacheSize;
	private int informixLockModeWait;
	private boolean informixAllowNewLine;
	private int oracleStmtCacheSize;
	private boolean disableCleanup;
	private Hashtable errorMap;
	private boolean disable2Phase;
	private DataSourceProperties dataSourceProperties;
	private Properties xaRecoveryProps;
	private static Hashtable xaRecoveryCredentials = new Hashtable();
	private static final String MAP_ERROR_CODE = "EC";
	private static final String MAP_SQL_STATE = "SS";
	private static final TraceComponent tc = Tr.register(CMProperties.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");
	private String mbeanFactoryId;
	private String mbeanProviderId;

	public CMPropertiesImpl() {
		this.diagOptions = 0;
		this.transactionBranchesLooselyCoupled = false;
		this.validate = false;
		this.dataBaseVersion = "0";
		this.resetReadOnly = false;
		this.secureXACredential = false;
		this.min = 1;
		this.max = 10;
		this.connTimeout = 180;
		this.idleTimeout = 1800;
		this.orphanTimeout = 1800;
		this.agedTimeout = 0;
		this.statementCacheSize = 10;
		this.informixLockModeWait = 0;
		this.informixAllowNewLine = false;
		this.oracleStmtCacheSize = 0;
		this.disableCleanup = false;
		this.errorMap = DataSourceFactory.DEFAULT_ERROR_MAP;
		this.disable2Phase = false;
		this.xaRecoveryProps = null;
		this.mbeanFactoryId = "";
		this.mbeanProviderId = "";
		this.dataSourceProperties = new DataSourceProperties();
	}

	public CMPropertiesImpl(String name, String dataSourceClassName) {
		this();
		this.setName(name);
		this.setDataSourceClassName(dataSourceClassName);
	}

	public CMPropertiesImpl(Properties props) throws CMFactoryException {
		this();
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		String propertyName = null;
		String propertyValue = null;

		try {
			Enumeration e = props.propertyNames();

			while (e.hasMoreElements()) {
				propertyName = (String) e.nextElement();
				propertyValue = props.getProperty(propertyName);
				if (propertyValue != null && !propertyValue.equals("")) {
					if (tc.isDebugEnabled()) {
						if (propertyName != null && propertyName.equals("password")) {
							Tr.debug(tc, "setting password=XXXXXXXX");
						} else {
							Tr.debug(tc, "setting " + propertyName + "=" + propertyValue);
						}
					}

					if (propertyName.equals("name")) {
						this.setName(propertyValue);
					} else if (propertyName.equals("dataSourceClassName")) {
						this.setDataSourceClassName(propertyValue);
					} else if (propertyName.equals("dataBaseVersion")) {
						this.setDataBaseVersion(propertyValue);
					} else if (propertyName.equals("minimumPoolSize")) {
						this.setMinConnectionPoolSize(Integer.parseInt(propertyValue));
					} else if (propertyName.equals("maximumPoolSize")) {
						this.setMaxConnectionPoolSize(Integer.parseInt(propertyValue));
					} else if (propertyName.equals("connectionTimeout")) {
						this.setConnectionTimeout(Integer.parseInt(propertyValue));
					} else if (propertyName.equals("idleTimeout")) {
						this.setIdleTimeout(Integer.parseInt(propertyValue));
					} else if (propertyName.equals("orphanTimeout")) {
						this.setOrphanTimeout(Integer.parseInt(propertyValue));
					} else if (propertyName.equals("agedTimeout")) {
						this.setAgedTimeout(Integer.parseInt(propertyValue));
					} else if (propertyName.equals("statementCacheSize")) {
						this.setMaxStatementCacheSize(Integer.parseInt(propertyValue));
					} else if (propertyName.equals("disableAutoConnectionCleanup")) {
						this.setAutoConnCleanupDisabled(Boolean.valueOf(propertyValue));
					} else if (propertyName.equals("errorMap")) {
						this.setErrorMap(stringToErrorMap(propertyValue));
					} else if (!propertyName.equals("oemId")) {
						if (propertyName.equals("disable2Phase")) {
							this.setDisable2Phase(Boolean.valueOf(propertyValue));
						} else if (propertyName.equals("informixLockModeWait")) {
							this.setInformixLockModeWait(Integer.parseInt(propertyValue));
						} else if (propertyName.equals("informixAllowNewLine")) {
							this.setInformixAllowNewLine(Boolean.valueOf(propertyValue));
						} else if (propertyName.equals("oracleStmtCacheSize")) {
							this.setOracleStmtCacheSize(Integer.parseInt(propertyValue));
						} else if (propertyName.equals("connectionValidation")) {
							this.setValidate(Boolean.valueOf(propertyValue));
						} else if (propertyName.equals("validationSQL")) {
							this.setValidateSQL(propertyValue);
						} else if (propertyName.equals("logOrphan")) {
							this.setLogOrphan(Boolean.valueOf(propertyValue));
						} else if (propertyName.equals("diagOptions")) {
							this.setDiagOptions(Integer.parseInt(propertyValue));
						} else if (propertyName.equals("transactionBranchesLooselyCoupled")) {
							this.setOraTransLoose(Boolean.valueOf(propertyValue));
						} else if (propertyName.equals("j2ee.resource.factory.href")) {
							this.setMBeanFactoryId(propertyValue);
						} else if (propertyName.equals("j2ee.resource.provider.href")) {
							this.setMBeanProviderId(propertyValue);
						} else if (propertyName.equals("resetReadOnly")) {
							this.setResetReadOnly(Boolean.valueOf(propertyValue));
						} else if (propertyName.equals("secureXACredential")) {
							this.setSecureXACredential(Boolean.valueOf(propertyValue));
						} else {
							this.setDataSourceProperty(propertyName, propertyValue);
						}
					}
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "ignoring null or empty property " + propertyName);
				}
			}
		} catch (NumberFormatException var5) {
			Tr.error(tc, "MSG_CONM_1000E", new Object[]{propertyValue, propertyName, this.getName()});
			throw var5;
		}

		if (this.xaRecoveryProps != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "adding xaRecoveryProps to xaRecoveryCredentials list, id, user:"
						+ this.getMBeanFactoryId() + " " + this.xaRecoveryProps.get("user"));
			}

			xaRecoveryCredentials.put(this.getMBeanFactoryId(), this.xaRecoveryProps);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>", this);
		}

	}

	public String toString() {
		String ls = System.getProperty("line.separator");
		String s = "CMProperties for DataSource \"" + this.name + "\"" + ls + "  "
				+ this.dataSourceProperties.toString() + ls + "  Connection Pool Properties: " + ls
				+ "    dataBaseVersion              = " + this.getDataBaseVersion() + ls
				+ "    minConnectionPoolSize        = " + this.getMinConnectionPoolSize() + ls
				+ "    maxConnectionPoolSize        = " + this.getMaxConnectionPoolSize() + ls
				+ "    connTimeout                  = " + this.getConnectionTimeout() + ls
				+ "    idleTimeout                  = " + this.getIdleTimeout() + ls
				+ "    orphanTimeout                = " + this.getOrphanTimeout() + ls
				+ "    agedTimeout                      = " + this.getAgedTimeout() + ls
				+ "    maxStatementCacheSize        = " + this.getMaxStatementCacheSize() + ls
				+ "    autoConnectionCleanupDisabled= " + this.isAutoConnCleanupDisabled() + ls
				+ "    errorMap                     = " + this.getErrorMap() + ls
				+ "    informixLockModeWait         = " + this.getInformixLockModeWait() + ls
				+ "    informixAllowNewLine         = " + this.getInformixAllowNewLine() + ls
				+ "    oracleStmtCacheSize          = " + this.getOracleStmtCacheSize() + ls
				+ "    connectionValidation         = " + this.isValidateEnabled() + ls
				+ "    validationSQL                = " + this.getValidateSQL() + ls
				+ "    logOrphan                    = " + this.getLogOrphan() + ls
				+ "    diagOptions                  = " + this.getDiagOptions() + ls
				+ "    TransactionBranchesLooselyCoupled = " + this.getOraTransLoose() + ls
				+ "    secureXACredential           = " + this.getSecureXACredential() + ls
				+ "    resetReadOnly                = " + this.isResetReadOnlyEnabled();
		return s;
	}

	public Reference getReference() throws NamingException {
		Reference ref = new CacheableReference(PortableDataSource.class.getName(),
				ResourceReferenceObjectFactory.class.getName(), (String) null);
		if (this.name != null) {
			ref.add(new StringRefAddr("name", this.name));
		}

		ref.add(new StringRefAddr("dataBaseVersion", this.dataBaseVersion));
		ref.add(new StringRefAddr("minimumPoolSize", Integer.toString(this.min)));
		ref.add(new StringRefAddr("maximumPoolSize", Integer.toString(this.max)));
		ref.add(new StringRefAddr("connectionTimeout", Integer.toString(this.connTimeout)));
		ref.add(new StringRefAddr("idleTimeout", Integer.toString(this.idleTimeout)));
		ref.add(new StringRefAddr("orphanTimeout", Integer.toString(this.orphanTimeout)));
		ref.add(new StringRefAddr("agedTimeout", Integer.toString(this.agedTimeout)));
		ref.add(new StringRefAddr("statementCacheSize", Integer.toString(this.statementCacheSize)));
		ref.add(new StringRefAddr("disableAutoConnectionCleanup", (new Boolean(this.disableCleanup)).toString()));
		if (this.errorMap != null) {
			ref.add(new StringRefAddr("errorMap", errorMapToString(this.errorMap)));
		}

		ref.add(new StringRefAddr("informixLockModeWait", Integer.toString(this.informixLockModeWait)));
		ref.add(new StringRefAddr("informixAllowNewLine", (new Boolean(this.informixAllowNewLine)).toString()));
		ref.add(new StringRefAddr("oracleStmtCacheSize", Integer.toString(this.oracleStmtCacheSize)));
		ref.add(new StringRefAddr("disable2Phase", (new Boolean(this.disable2Phase)).toString()));
		ref.add(new StringRefAddr("connectionValidation", (new Boolean(this.validate)).toString()));
		ref.add(new StringRefAddr("logOrphan", (new Boolean(this.getLogOrphan())).toString()));
		ref.add(new StringRefAddr("diagOptions", Integer.toString(this.diagOptions)));
		if (this.transactionBranchesLooselyCoupled) {
			ref.add(new StringRefAddr("transactionBranchesLooselyCoupled",
					(new Boolean(this.transactionBranchesLooselyCoupled)).toString()));
		}

		if (this.validateSQL != null) {
			ref.add(new StringRefAddr("validationSQL", this.validateSQL));
		}

		ref.add(new StringRefAddr("dataSourceClassName", this.dataSourceProperties.getDataSourceClassName()));
		ref.add(new StringRefAddr("j2ee.resource.factory.href", this.mbeanFactoryId));
		ref.add(new StringRefAddr("j2ee.resource.provider.href", this.mbeanProviderId));
		ref.add(new StringRefAddr("resetReadOnly", (new Boolean(this.resetReadOnly)).toString()));
		ref.add(new StringRefAddr("secureXACredential", (new Boolean(this.secureXACredential)).toString()));

		String propName;
		String propValue;
		for (Enumeration e = this.dataSourcePropertyNames(); e.hasMoreElements(); ref
				.add(new StringRefAddr(propName, propValue))) {
			propName = (String) e.nextElement();
			propValue = this.dataSourceProperties.getProperty(propName);
			if (propName.equals("password")) {
				propValue = PasswordUtil.passwordEncode(propValue);
			}
		}

		return ref;
	}

	public CMProperties loadFromReference(Reference ref) throws NumberFormatException, CMFactoryException {
		Properties props = new Properties();
		Enumeration e = ref.getAll();

		while (e.hasMoreElements()) {
			StringRefAddr addr = (StringRefAddr) e.nextElement();
			props.setProperty(addr.getType(), (String) addr.getContent());
		}

		String pwd = props.getProperty("password");
		if (pwd != null) {
			props.setProperty("password", PasswordUtil.passwordDecode(pwd));
		}

		return new CMPropertiesImpl(props);
	}

	public String getName() {
		return this.name;
	}

	public void setName(String newName) {
		if (newName != null && !newName.equals("")) {
			this.name = newName;
		} else {
			throw new IllegalArgumentException("Null or empty datasource name not allowed");
		}
	}

	public String getDataSourceClassName() {
		return this.dataSourceProperties.getDataSourceClassName();
	}

	public void setDataSourceClassName(String newDataSourceClassName) {
		String inputDataSourceClassName = newDataSourceClassName;
		Tr.debug(tc, "setDataSourceClassName() - input datasource class name is: " + newDataSourceClassName);
		if (newDataSourceClassName != null && !newDataSourceClassName.equals("")) {
			int i = newDataSourceClassName.indexOf(" ");
			if (i != -1 && i != 0) {
				inputDataSourceClassName = newDataSourceClassName.substring(0, i);
				Tr.debug(tc, "Embedded blanks removed from datasource class name. Adjusted datasource class name is: "
						+ inputDataSourceClassName);
			}

			this.dataSourceProperties.setDataSourceClassName(inputDataSourceClassName);
		} else {
			throw new IllegalArgumentException("Null or empty datasource class name not allowed");
		}
	}

	public String getDataBaseVersion() {
		return this.dataBaseVersion;
	}

	public void setDataBaseVersion(String newDataBaseVersion) {
		if (newDataBaseVersion != null && !newDataBaseVersion.equals("")) {
			this.dataBaseVersion = newDataBaseVersion;
		} else {
			throw new IllegalArgumentException("Null or empty database version not allowed");
		}
	}

	public int getMinConnectionPoolSize() {
		return this.min;
	}

	public void setMinConnectionPoolSize(int newPoolSize) {
		if (newPoolSize < 0) {
			throw new IllegalArgumentException("Pool size cannot be a negative number");
		} else {
			this.min = newPoolSize;
		}
	}

	public int getMaxConnectionPoolSize() {
		return this.max;
	}

	public void setMaxConnectionPoolSize(int newPoolSize) {
		if (newPoolSize < 1) {
			throw new IllegalArgumentException("Pool size must be greater than 0");
		} else {
			this.max = newPoolSize;
		}
	}

	public int getConnectionTimeout() {
		return this.connTimeout;
	}

	public int getConnectionTimeoutInMillis() {
		return this.connTimeout * 1000;
	}

	public void setConnectionTimeout(int newTimeout) {
		if (newTimeout < 0) {
			throw new IllegalArgumentException("Timeout cannot be a negative number");
		} else {
			this.connTimeout = newTimeout;
		}
	}

	public int getIdleTimeout() {
		return this.idleTimeout;
	}

	public int getIdleTimeoutInMillis() {
		return this.idleTimeout * 1000;
	}

	public void setIdleTimeout(int newTimeout) {
		if (newTimeout < 0) {
			throw new IllegalArgumentException("Timeout cannot be a negative number");
		} else {
			this.idleTimeout = newTimeout;
		}
	}

	public int getOrphanTimeout() {
		return this.orphanTimeout;
	}

	public long getOrphanTimeoutInMillis() {
		return (long) (this.orphanTimeout * 1000);
	}

	public void setOrphanTimeout(int newTimeout) {
		if (newTimeout < 0) {
			throw new IllegalArgumentException("Timeout cannot be a negative number");
		} else {
			this.orphanTimeout = newTimeout;
		}
	}

	public int getAgedTimeout() {
		return this.agedTimeout;
	}

	public long getAgedTimeoutInMillis() {
		return (long) (this.agedTimeout * 1000);
	}

	public void setAgedTimeout(int newTimeout) {
		if (newTimeout < 0) {
			throw new IllegalArgumentException("agedTimeout cannot be a negative number");
		} else {
			this.agedTimeout = newTimeout;
		}
	}

	public int getMaxStatementCacheSize() {
		return this.statementCacheSize;
	}

	public void setMaxStatementCacheSize(int newCacheSize) {
		if (newCacheSize < 0) {
			throw new IllegalArgumentException("Cache size cannot be a negative number");
		} else {
			this.statementCacheSize = newCacheSize;
		}
	}

	public String getUser() {
		return this.dataSourceProperties.getProperty("user");
	}

	public int getInformixLockModeWait() {
		return this.informixLockModeWait;
	}

	public boolean getInformixAllowNewLine() {
		return this.informixAllowNewLine;
	}

	public int getOracleStmtCacheSize() {
		return this.oracleStmtCacheSize;
	}

	public void setUser(String newUser) {
		if (newUser != null && !newUser.equals("")) {
			this.dataSourceProperties.setProperty("user", newUser);
		} else {
			this.dataSourceProperties.remove("user");
		}

	}

	public String getTmpUser() {
		return this.dataSourceProperties.getProperty("tmpUser");
	}

	public void setTmpUser(String newUser) {
		if (newUser != null && !newUser.equals("")) {
			this.dataSourceProperties.setProperty("tmpUser", newUser);
		} else {
			this.dataSourceProperties.remove("tmpUser");
		}

	}

	String getTmpPassword() {
		return this.dataSourceProperties.getProperty("tmpPassword");
	}

	public void setTmpPassword(String newPassword) {
		if (newPassword != null && !newPassword.equals("")) {
			this.dataSourceProperties.setProperty("tmpPassword", newPassword);
		} else {
			this.dataSourceProperties.remove("tmpPassword");
		}

	}

	public void setInformixLockModeWait(int value) {
		this.informixLockModeWait = value;
	}

	public void setInformixAllowNewLine(boolean value) {
		this.informixAllowNewLine = value;
	}

	public void setOracleStmtCacheSize(int value) {
		this.oracleStmtCacheSize = value;
	}

	String getPassword() {
		return this.dataSourceProperties.getProperty("password");
	}

	public void setPassword(String newPassword) {
		if (newPassword != null && !newPassword.equals("")) {
			this.dataSourceProperties.setProperty("password", newPassword);
		} else {
			this.dataSourceProperties.remove("password");
		}

	}

	public boolean isAutoConnCleanupDisabled() {
		return this.disableCleanup;
	}

	public void setAutoConnCleanupDisabled(boolean value) {
		this.disableCleanup = value;
	}

	public Hashtable getErrorMap() {
		return this.errorMap;
	}

	public void setErrorMap(Hashtable newErrorMap) {
		this.errorMap = newErrorMap;
	}

	public boolean isDisable2Phase() {
		return this.disable2Phase;
	}

	public void setDisable2Phase(boolean value) {
		this.disable2Phase = value;
	}

	public void setDataSourceProperty(String key, String value) {
		if (!this.getSecureXACredential() || !key.equals("user") && !key.equals("password")) {
			this.dataSourceProperties.setProperty(key, value);
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "secureXACredential set, not setting DataSourceProperty " + key);
			}

			if (this.xaRecoveryProps == null) {
				this.xaRecoveryProps = new Properties();
			}

			this.xaRecoveryProps.put(key, value);
		}

	}

	public String getDataSourceProperty(String key) {
		return this.dataSourceProperties.getProperty(key);
	}

	public Enumeration dataSourcePropertyNames() {
		return this.dataSourceProperties.propertyNames();
	}

	public DataSourceProperties getDataSourceProperties() {
		return this.dataSourceProperties;
	}

	public void validate() throws CMFactoryException {
		if (this.getName() == null) {
			Tr.error(tc, "MSG_CONM_1001E", new Object[]{"DataSourceFactory.NAME", ""});
			throw new MissingRequiredPropertyException("Required property DataSourceFactory.NAME is missing");
		} else if (this.getDataSourceClassName() == null) {
			Tr.error(tc, "MSG_CONM_1001E", new Object[]{"DataSourceFactory.DATASOURCE_CLASS_NAME", this.getName()});
			throw new MissingRequiredPropertyException(
					"Required property DataSourceFactory.DATASOURCE_CLASS_NAME for data source " + this.getName()
							+ " is missing");
		} else {
			if (this.getUser() == null && this.getPassword() != null) {
				Tr.warning(tc, "MSG_CONM_1004W", this.getName());
				this.setUser((String) null);
			}

			if (this.getUser() != null && this.getPassword() == null) {
				Tr.warning(tc, "MSG_CONM_1005W", new Object[]{this.getUser(), this.getName()});
				this.setPassword((String) null);
			}

		}
	}

	public void encodePassword() {
		if (this.getPassword() != null) {
			this.setPassword(PasswordUtil.passwordEncode(this.getPassword()));
		}

	}

	public void decodePassword() {
		if (this.getPassword() != null) {
			this.setPassword(PasswordUtil.passwordDecode(this.getPassword()));
		}

	}

	public Object clone() {
		CMPropertiesImpl clone = null;

		try {
			clone = (CMPropertiesImpl) super.clone();
		} catch (CloneNotSupportedException var3) {
			;
		}

		if (this.errorMap != null) {
			clone.errorMap = (Hashtable) this.errorMap.clone();
		}

		clone.dataSourceProperties = (DataSourceProperties) this.dataSourceProperties.clone();
		return clone;
	}

	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (obj == this) {
			return true;
		} else {
			try {
				CMPropertiesImpl p = (CMPropertiesImpl) obj;
				return (this.name == null && p.name == null || this.name != null && this.name.equals(p.name))
						&& this.min == p.min && this.max == p.max && this.connTimeout == p.connTimeout
						&& this.idleTimeout == p.idleTimeout && this.orphanTimeout == p.orphanTimeout
						&& this.statementCacheSize == p.statementCacheSize && this.disableCleanup == p.disableCleanup
						&& this.disable2Phase == p.disable2Phase && this.informixLockModeWait == p.informixLockModeWait
						&& this.oracleStmtCacheSize == p.oracleStmtCacheSize
						&& this.dataSourceProperties.equals(p.dataSourceProperties)
						&& (this.errorMap == null && p.errorMap == null || this.errorMap.equals(p.errorMap));
			} catch (ClassCastException var3) {
				return false;
			}
		}
	}

	private static Hashtable stringToErrorMap(String str) {
		Hashtable table = new Hashtable();
		StringTokenizer mappings = new StringTokenizer(str, ";");
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		if (classLoader == null) {
			classLoader = ClassLoader.getSystemClassLoader();
		}

		while (mappings.hasMoreTokens()) {
			String mapping = mappings.nextToken();
			int separator = mapping.lastIndexOf(61);
			String key = mapping.substring(2, separator);
			String exc = mapping.substring(separator + 1, mapping.length());

			try {
				Class excClass = exc.equals("") ? Void.class : classLoader.loadClass(exc);
				if (mapping.startsWith("EC")) {
					table.put(new Integer(key), excClass);
				} else {
					table.put(key, excClass);
				}
			} catch (ClassNotFoundException var9) {
				throw new IllegalArgumentException("Unknown exception class: " + exc);
			}
		}

		return table;
	}

	private static String errorMapToString(Hashtable table) {
		if (table == null) {
			return "";
		} else {
			StringBuffer sb = new StringBuffer();

			for (Iterator it = table.entrySet().iterator(); it.hasNext(); sb.append(';')) {
				Entry entry = (Entry) it.next();
				Object key = entry.getKey();
				sb.append(key instanceof Integer ? "EC" : "SS");
				sb.append(key);
				sb.append('=');
				if (entry.getValue() != null) {
					sb.append(((Class) entry.getValue()).getName());
				}
			}

			return sb.toString();
		}
	}

	public boolean isValidateEnabled() {
		return this.validate;
	}

	public void setValidate(boolean theValue) {
		this.validate = theValue;
	}

	public String getValidateSQL() {
		return this.validateSQL;
	}

	public void setValidateSQL(String theValue) {
		this.validateSQL = theValue;
	}

	public boolean getLogOrphan() {
		return (this.diagOptions & 1) > 0;
	}

	public void setLogOrphan(boolean theValue) {
		if (theValue) {
			this.diagOptions |= 1;
		}

	}

	public boolean getOraTransLoose() {
		return this.transactionBranchesLooselyCoupled;
	}

	public void setOraTransLoose(boolean theValue) {
		this.transactionBranchesLooselyCoupled = theValue;
	}

	protected Properties getXaRecoveryCredentials() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getXaRecoveryCredentials");
		}

		if (this.xaRecoveryProps == null) {
			this.xaRecoveryProps = (Properties) ((Properties) xaRecoveryCredentials.get(this.getMBeanFactoryId()));
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getXaRecoveryCredentials", this.xaRecoveryProps);
		}

		return this.xaRecoveryProps;
	}

	public boolean isResetReadOnlyEnabled() {
		return this.resetReadOnly;
	}

	private void setResetReadOnly(boolean theValue) {
		this.resetReadOnly = theValue;
	}

	private boolean getSecureXACredential() {
		return this.secureXACredential;
	}

	private void setSecureXACredential(boolean theValue) {
		this.secureXACredential = theValue;
		if (this.secureXACredential) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Removing user and password from dataSourceProperties");
			}

			String val = (String) this.dataSourceProperties.remove("user");
			if (val != null) {
				if (this.xaRecoveryProps == null) {
					this.xaRecoveryProps = new Properties();
				}

				this.xaRecoveryProps.put("user", val);
				val = null;
			}

			val = (String) this.dataSourceProperties.remove("password");
			if (val != null) {
				if (this.xaRecoveryProps == null) {
					this.xaRecoveryProps = new Properties();
				}

				this.xaRecoveryProps.put("password", val);
			}
		}

	}

	public String getMBeanFactoryId() {
		return this.mbeanFactoryId;
	}

	public String getMBeanProviderId() {
		return this.mbeanProviderId;
	}

	public void setMBeanFactoryId(String mbeanFactoryId) {
		this.mbeanFactoryId = mbeanFactoryId;
	}

	public void setMBeanProviderId(String mbeanProviderId) {
		this.mbeanProviderId = mbeanProviderId;
	}

	public void setDiagOptions(int iOptions) {
		if (iOptions < 0) {
			throw new IllegalArgumentException("The Connection Manager Diagnostic options must be zero (0) or greater");
		} else {
			if (this.diagOptions == 0) {
				this.diagOptions = iOptions;
			} else {
				this.diagOptions |= iOptions;
			}

		}
	}

	public int getDiagOptions() {
		return this.diagOptions;
	}

	public boolean isDiagOptionEnabled(int iOptions) {
		return (this.diagOptions & iOptions) > 0;
	}

	public String getDiagOptionsString() {
		Class c = this.getClass();
		Field[] f = c.getFields();
		String szOptions = "[" + this.diagOptions + "]=";
		StringBuffer sb = new StringBuffer(szOptions);

		for (int i = 0; i < f.length; ++i) {
			String szName = f[i].getName();
			if (szName.startsWith("DIAG_OPTION")) {
				try {
					if ((this.diagOptions & f[i].getInt((Object) null)) > 0) {
						sb.append(szName);
						sb.append(" ");
					}
				} catch (IllegalAccessException var8) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "getDiagOptionsString, Illegal Access Exception", var8);
					}

					return "Error getting diagnostic options";
				}
			}
		}

		if (sb.length() == szOptions.length()) {
			sb.append("Invalid Connection Manager Diagnostic Options Set");
		}

		return sb.toString();
	}
}