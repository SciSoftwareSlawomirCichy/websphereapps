package com.ibm.ejs.container;

public class IllegalBMTxAttrException extends ContainerException {
	private static final long serialVersionUID = -4603137228938112818L;
}