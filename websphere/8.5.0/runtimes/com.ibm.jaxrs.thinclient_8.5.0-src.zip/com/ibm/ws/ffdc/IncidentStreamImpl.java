package com.ibm.ws.ffdc;

import com.ibm.ws.ffdc.IncidentStreamImpl.1;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public final class IncidentStreamImpl implements IncidentStream {
	public static final String $sccsid = "@(#) 1.4 SERV1/ws/code/ras.lite/src/com/ibm/ws/ffdc/IncidentStreamImpl.java, WAS.ras.lite, WAS855.SERV1, cf051506.04 09/03/12 05:39:02 [2/19/15 14:14:30]";
	private static final int DEFAULT_DEPTH = 1;
	private static final int DEFAULT_MAX_SIZE = 1048576;
	private static final String EQUALS = " = ";
	private PrintStream ps;
	private boolean _createdPrintStream;

	public IncidentStreamImpl(String ffdcFileName) {
      try {
         FileOutputStream fos = (FileOutputStream)AccessController.doPrivileged(new 1(this, ffdcFileName));
         this.ps = new PrintStream(fos, true);
         this._createdPrintStream = true;
      } catch (PrivilegedActionException var3) {
         this.ps = System.err;
         this._createdPrintStream = false;
         this.processIncident(var3.getClass().getName(), "com.ibm.ws.ffdc.IncidentStreamImpl", "1", var3, this, new Object[]{ffdcFileName});
      }

   }

	public void introspectAndWrite(String text, Object value) {
		this.ps.println(text);
		this.introspect(value, 1, 1048576);
	}

	public void introspectAndWrite(String text, Object value, int depth) {
		this.ps.println(text);
		this.introspect(value, depth, 1048576);
	}

	public void introspectAndWrite(String text, Object value, int depth, int maxBytes) {
		this.ps.println(text);
		this.introspect(value, depth, maxBytes);
	}

	public void introspectAndWriteLine(String text, Object value) {
		this.introspectAndWrite(text, value);
		this.ps.println();
	}

	public void introspectAndWriteLine(String text, Object value, int depth) {
		this.introspectAndWrite(text, value, depth);
		this.ps.println();
	}

	public void introspectAndWriteLine(String text, Object value, int depth, int maxBytes) {
		this.introspectAndWrite(text, value, depth, maxBytes);
		this.ps.println();
	}

	public void write(String text, boolean value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	public void write(String text, byte value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	public void write(String text, char value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	public void write(String text, short value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	public void write(String text, int value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	public void write(String text, long value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	public void write(String text, float value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	public void write(String text, double value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	public void write(String text, String value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	public void write(String text, Object value) {
		this.printValueIntro(text);
		this.ps.print(value);
	}

	private void printValueIntro(String text) {
		if (text != null) {
			this.ps.print(text);
			this.ps.print(" = ");
		}

	}

	public void writeLine(String text, boolean value) {
		this.write(text, value);
		this.ps.println();
	}

	public void writeLine(String text, byte value) {
		this.write(text, value);
		this.ps.println();
	}

	public void writeLine(String text, char value) {
		this.write(text, value);
		this.ps.println();
	}

	public void writeLine(String text, short value) {
		this.write(text, value);
		this.ps.println();
	}

	public void writeLine(String text, int value) {
		this.write(text, value);
		this.ps.println();
	}

	public void writeLine(String text, long value) {
		this.write(text, value);
		this.ps.println();
	}

	public void writeLine(String text, float value) {
		this.write(text, value);
		this.ps.println();
	}

	public void writeLine(String text, double value) {
		this.write(text, value);
		this.ps.println();
	}

	public void writeLine(String text, String value) {
		this.write(text, value);
		this.ps.println();
	}

	public void writeLine(String text, Object value) {
		this.write(text, value);
		this.ps.println();
	}

	private void introspect(Object value, int max_depth, int max_size) {
		if (value == null) {
			this.ps.print("null");
		} else {
			IntrospectionLevel rootLevel = new IntrospectionLevel(value);
			IntrospectionLevel currentLevel = rootLevel;
			IntrospectionLevel nextLevel = rootLevel.getNextLevel();
			int totalBytes = rootLevel.getNumberOfBytesinJustThisLevel();

			int actualDepth;
			for (actualDepth = 0; actualDepth < max_depth && nextLevel.hasMembers()
					&& totalBytes <= max_size; ++actualDepth) {
				totalBytes -= currentLevel.getNumberOfBytesinJustThisLevel();
				totalBytes += currentLevel.getNumberOfBytesInAllLevelsIncludingThisOne();
				currentLevel = nextLevel;
				nextLevel = nextLevel.getNextLevel();
				totalBytes += currentLevel.getNumberOfBytesinJustThisLevel();
			}

			boolean exceededMaxBytes = false;
			if (totalBytes > max_size && actualDepth > 0) {
				--actualDepth;
				exceededMaxBytes = true;
			}

			rootLevel.print(this, actualDepth);
			if (exceededMaxBytes) {
				this.ps.println("Only " + actualDepth
						+ " levels of object introspection were performed because performing the next level would have exceeded the specified maximum bytes of "
						+ max_size);
			}
		}

	}

	public void close() {
		if (this._createdPrintStream) {
			this.ps.close();
		}

	}

	void processIncident(String txt, String sourceId, String probeId, Throwable th, Object callerThis,
			Object[] objectArray) {
		this.writeIncidentHeader(txt, sourceId, probeId, th);
		this.writeLine("Stack Dump", getStackTrace(th));
		StackTraceElement[] exceptionCallStack = th.getStackTrace();
		int commonIndex = compare(exceptionCallStack);
		Map<String, DiagnosticModule> modules = FFDC.getDiagnosticModuleMap();
		boolean foundAnyDM = false;
		if (commonIndex != -1) {
			boolean tryNextDM = true;
			String[] dmsCallStack = getCallStackFromStackTraceElement(exceptionCallStack);

			for (int i = commonIndex; i < exceptionCallStack.length && tryNextDM; ++i) {
				String packageName = getPackageName(exceptionCallStack[i].getClassName());

				while (packageName.length() != 0 && tryNextDM) {
					DiagnosticModule module = (DiagnosticModule) modules.get(packageName);
					if (module != null) {
						if (!foundAnyDM) {
							this.introspectAndWriteLine("Dump of callerThis", callerThis, 0);
						}

						foundAnyDM = true;
						tryNextDM = module.dumpComponentData(new String[0], th, this, callerThis, objectArray, sourceId,
								dmsCallStack);
					}

					int lastDot = packageName.lastIndexOf(46);
					if (lastDot == -1) {
						packageName = "";
					} else {
						packageName = packageName.substring(0, lastDot);
					}
				}
			}
		}

		if (!foundAnyDM) {
			this.introspectAndWriteLine("Dump of callerThis", callerThis, 3);
			if (objectArray != null) {
				for (int i = 0; i < objectArray.length; ++i) {
					this.introspectAndWriteLine("Dump of objectArray[" + i + "]", objectArray[i], 3);
				}
			}
		}

	}

	private void writeIncidentHeader(String txt, String sourceId, String probeId, Throwable th) {
		this.write("------Start of DE processing------", formatTime());
		this.writeLine(", key", txt);
		this.writeLine("Exception", th.getClass().getName());
		this.writeLine("Source", sourceId);
		this.writeLine("probeid", probeId);
	}

	private static String[] getCallStackFromStackTraceElement(StackTraceElement[] exceptionCallStack) {
		if (exceptionCallStack == null) {
			return null;
		} else {
			String[] answer = new String[exceptionCallStack.length];

			for (int i = 0; i < exceptionCallStack.length; ++i) {
				answer[exceptionCallStack.length - 1 - i] = exceptionCallStack[i].getClassName();
			}

			return answer;
		}
	}

	private static String getPackageName(String className) {
		int end = className.lastIndexOf(46);
		return end > 0 ? className.substring(0, end) : "";
	}

	private static int compare(StackTraceElement[] exceptionCallStack) {
		if (exceptionCallStack != null && exceptionCallStack.length != 0) {
			StackTraceElement[] currentCallStack = Thread.currentThread().getStackTrace();
			if (currentCallStack != null && currentCallStack.length != 0) {
				int proposedExceptionIndex = exceptionCallStack.length - 1;

				for (int proposedCurrentIndex = currentCallStack.length - 1; proposedExceptionIndex >= 0
						&& proposedCurrentIndex >= 0 && exceptionCallStack[proposedExceptionIndex] != null
						&& exceptionCallStack[proposedExceptionIndex].getClassName().equals(
								currentCallStack[proposedCurrentIndex].getClassName()); --proposedCurrentIndex) {
					--proposedExceptionIndex;
				}

				++proposedExceptionIndex;
				return proposedExceptionIndex > exceptionCallStack.length ? -1 : proposedExceptionIndex;
			} else {
				return -1;
			}
		} else {
			return -1;
		}
	}

	private static String formatTime() {
		return formatTime(new Date());
	}

	private static String formatTime(Date date) {
		DateFormat formatter = getBasicDateFormatter();
		StringBuffer answer = new StringBuffer();
		answer.append("[");
		formatter.format(date, answer, new FieldPosition(0));
		answer.append("]");
		return answer.toString();
	}

	private static DateFormat getBasicDateFormatter() {
		DateFormat formatter = DateFormat.getDateTimeInstance(3, 2);
		SimpleDateFormat formatter;
		if (formatter instanceof SimpleDateFormat) {
			SimpleDateFormat sdFormatter = (SimpleDateFormat) formatter;
			String pattern = sdFormatter.toPattern();
			int patternLength = pattern.length();
			int endOfSecsIndex = pattern.lastIndexOf(115) + 1;
			String newPattern = pattern.substring(0, endOfSecsIndex) + ":SSS z";
			if (endOfSecsIndex < patternLength) {
				newPattern = newPattern + pattern.substring(endOfSecsIndex, patternLength);
			}

			newPattern = newPattern.replace('h', 'H');
			newPattern = newPattern.replace('K', 'H');
			newPattern = newPattern.replace('k', 'H');
			newPattern = newPattern.replace('a', ' ');
			newPattern = newPattern.trim();
			sdFormatter.applyPattern(newPattern);
			formatter = sdFormatter;
		} else {
			formatter = new SimpleDateFormat("yy.MM.dd HH:mm:ss:SSS z");
		}

		return formatter;
	}

	static String getStackTrace(Throwable ex) {
		StringWriter sw = new StringWriter();
		ex.printStackTrace(new PrintWriter(sw));
		return sw.toString();
	}

	void processRepeatIncident(String txt, String sourceId, String probeId, Throwable th, Date timeOfOriginalFfdc) {
		this.writeIncidentHeader(txt, sourceId, probeId, th);
		this.writeLine((String) null, (String) "");
		this.writeLine((String) null, (String) "This is a reoccurrence of an earlier FFDC incident");
		this.writeLine("Time of original incident", formatTime(timeOfOriginalFfdc));
		this.writeLine((String) null, (String) "");
	}
}