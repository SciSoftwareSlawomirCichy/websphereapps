package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.MemberAttributesType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class MemberAttributesTypeImpl extends EDataObjectImpl implements MemberAttributesType {
	protected static final String DUMMY_MEMBER_EDEFAULT = null;
	protected String dummyMember;
	protected static final String NAME_EDEFAULT = null;
	protected String name;
	protected static final String OBJECT_CLASS_EDEFAULT = null;
	protected String objectClass;
	protected static final String SCOPE_EDEFAULT = "direct";
	protected String scope;
	protected boolean scopeESet;

	protected MemberAttributesTypeImpl() {
		this.dummyMember = DUMMY_MEMBER_EDEFAULT;
		this.name = NAME_EDEFAULT;
		this.objectClass = OBJECT_CLASS_EDEFAULT;
		this.scope = "direct";
		this.scopeESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getMemberAttributesType();
	}

	public String getDummyMember() {
		return this.dummyMember;
	}

	public void setDummyMember(String var1) {
		String var2 = this.dummyMember;
		this.dummyMember = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.dummyMember));
		}

	}

	public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		String var2 = this.name;
		this.name = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.name));
		}

	}

	public String getObjectClass() {
		return this.objectClass;
	}

	public void setObjectClass(String var1) {
		String var2 = this.objectClass;
		this.objectClass = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.objectClass));
		}

	}

	public String getScope() {
		return this.scope;
	}

	public void setScope(String var1) {
		String var2 = this.scope;
		this.scope = var1;
		boolean var3 = this.scopeESet;
		this.scopeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.scope, !var3));
		}

	}

	public void unsetScope() {
		String var1 = this.scope;
		boolean var2 = this.scopeESet;
		this.scope = "direct";
		this.scopeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 3, var1, "direct", var2));
		}

	}

	public boolean isSetScope() {
		return this.scopeESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getDummyMember();
			case 1 :
				return this.getName();
			case 2 :
				return this.getObjectClass();
			case 3 :
				return this.getScope();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setDummyMember((String) var2);
				return;
			case 1 :
				this.setName((String) var2);
				return;
			case 2 :
				this.setObjectClass((String) var2);
				return;
			case 3 :
				this.setScope((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setDummyMember(DUMMY_MEMBER_EDEFAULT);
				return;
			case 1 :
				this.setName(NAME_EDEFAULT);
				return;
			case 2 :
				this.setObjectClass(OBJECT_CLASS_EDEFAULT);
				return;
			case 3 :
				this.unsetScope();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return DUMMY_MEMBER_EDEFAULT == null
						? this.dummyMember != null
						: !DUMMY_MEMBER_EDEFAULT.equals(this.dummyMember);
			case 1 :
				return NAME_EDEFAULT == null ? this.name != null : !NAME_EDEFAULT.equals(this.name);
			case 2 :
				return OBJECT_CLASS_EDEFAULT == null
						? this.objectClass != null
						: !OBJECT_CLASS_EDEFAULT.equals(this.objectClass);
			case 3 :
				return this.isSetScope();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (dummyMember: ");
			var1.append(this.dummyMember);
			var1.append(", name: ");
			var1.append(this.name);
			var1.append(", objectClass: ");
			var1.append(this.objectClass);
			var1.append(", scope: ");
			if (this.scopeESet) {
				var1.append(this.scope);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}