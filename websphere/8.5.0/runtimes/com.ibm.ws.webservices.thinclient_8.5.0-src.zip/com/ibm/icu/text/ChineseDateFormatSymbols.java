package com.ibm.icu.text;

import com.ibm.icu.impl.CalendarData;
import com.ibm.icu.util.Calendar;
import com.ibm.icu.util.ChineseCalendar;
import com.ibm.icu.util.ULocale;
import java.util.Locale;

public class ChineseDateFormatSymbols extends DateFormatSymbols {
	static final long serialVersionUID = 6827816119783952890L;
	String[] isLeapMonth;

	public ChineseDateFormatSymbols() {
		this(ULocale.getDefault());
	}

	public ChineseDateFormatSymbols(Locale locale) {
		super(ChineseCalendar.class, ULocale.forLocale(locale));
	}

	public ChineseDateFormatSymbols(ULocale locale) {
		super(ChineseCalendar.class, locale);
	}

	public ChineseDateFormatSymbols(Calendar cal, Locale locale) {
		super(cal == null ? null : cal.getClass(), locale);
	}

	public ChineseDateFormatSymbols(Calendar cal, ULocale locale) {
		super(cal == null ? null : cal.getClass(), locale);
	}

	public String getLeapMonth(int leap) {
		return this.isLeapMonth[leap];
	}

	protected void initializeData(ULocale loc, CalendarData calData) {
		super.initializeData(loc, calData);
		this.isLeapMonth = calData.getStringArray("isLeapMonth");
	}

	void initializeData(DateFormatSymbols dfs) {
		super.initializeData(dfs);
		if (dfs instanceof ChineseDateFormatSymbols) {
			this.isLeapMonth = ((ChineseDateFormatSymbols) dfs).isLeapMonth;
		}

	}
}