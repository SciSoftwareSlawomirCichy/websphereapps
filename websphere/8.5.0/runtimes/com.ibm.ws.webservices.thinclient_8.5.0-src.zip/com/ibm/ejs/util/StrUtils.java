package com.ibm.ejs.util;

public class StrUtils {
	public static String[] split(String s, int ch) {
		int numComponents = 0;
		int currIndex = 0;

		while (true) {
			currIndex = s.indexOf(ch, currIndex);
			++numComponents;
			if (currIndex == -1) {
				String[] result = new String[numComponents];
				int start = 0;
				int end = s.indexOf(ch, currIndex);

				for (int i = 0; i < numComponents; ++i) {
					if (i + 1 == numComponents) {
						result[i] = s.substring(start);
					} else {
						result[i] = s.substring(start, end);
					}

					start = end + 1;
					end = s.indexOf(ch, start);
				}

				return result;
			}

			++currIndex;
		}
	}

	public static String getUrlPrefix(String url) {
		int current = 0;

		for (int i = 0; i < 3; ++i) {
			current = url.indexOf(47, current + 1);
			if (current == -1) {
				return null;
			}
		}

		return url.substring(0, current + 1);
	}

	public static final String peelQuotes(String s) {
		if (s.startsWith("\"")) {
			s = s.substring(1);
		}

		if (s.endsWith("\"")) {
			s = s.substring(0, s.length() - 1);
		}

		return s;
	}
}