package org.apache.http.auth.params;

public interface AuthPNames {
	String CREDENTIAL_CHARSET = "http.auth.credential-charset";
}