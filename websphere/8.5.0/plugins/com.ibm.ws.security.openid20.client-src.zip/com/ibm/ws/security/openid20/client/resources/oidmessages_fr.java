package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_fr extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: La partie utilisatrice (RP) OpenID n''a pas pu rediriger l''utilisateur vers le fournisseur OpenID (OP) en vue de son authentification à cause de l''exception [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: L''initialisation de la partie utilisatrice (RP) OpenID a échoué car celle-ci n''a pas pu obtenir le contexte SSL par défaut du serveur WebSphere. L''exception est [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: La partie utilisatrice (RP) OpenID n''a pas pu se connecter au fournisseur OpenID (OP) indiqué par l''identificateur [{0}] à cause de l''exception [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: L''initialisation de la partie utilisatrice (RP) OpenID a échoué à cause de l''exception [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: L''initialisation de la partie utilisatrice (RP) OpenID a échoué car la valeur de la propriété [{0}] n''est pas formatée correctement."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: La partie utilisatrice (RP) OpenID n'a pas réussi à authentifier une demande à l'aide du jeton d'authentification de base car la valeur de celui-ci n'est pas valide."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: L''initialisation de la partie utilisatrice (RP) OpenID a échoué car la propriété [{0}] n''est pas définie correctement. Il doit s''agir d''une URL valide."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: La partie utilisatrice (RP) OpenID an reçu une réponse non valide du fournisseur OpenID (OP). La cause de l''erreur est [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: La partie utilisatrice (RP) OpenID n'a pas pu réaliser l'authentification, car elle a atteint la capacité maximale de son cache interne."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: L'initialisation de la partie utilisatrice (RP) OpenID a échoué car l'attribut axRequiredAttribute[n] requis est manquant. Vous devez définir au moins une propriété."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: L''initialisation de la partie utilisatrice (RP) OpenID a échoué car la valeur de la propriété obligatoire [{0}] manque ou est vide."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: La partie utilisatrice (RP) OpenID nécessite SSL (HTTPS), mais l''URL du fournisseur OpenID (OP) est HTTP : [{0}].  L''attribut [{1}] doit correspondre au schéma de l''URL cible. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: La partie utilisatrice (RP) OpenID a reçu une réponse du fournisseur OpenID (OP) qui ne prend pas en charge la spécification OpenID version 2."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: La partie utilisatrice (RP) OpenID a échoué pendant la vérification de la réponse reçue du fournisseur OpenID (OP). L''exception est [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}