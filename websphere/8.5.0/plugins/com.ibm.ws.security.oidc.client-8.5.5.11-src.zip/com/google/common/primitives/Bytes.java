package com.google.common.primitives;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.primitives.Bytes.ByteArrayAsList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@GwtCompatible
public final class Bytes {
	public static int hashCode(byte value) {
		return value;
	}

	public static boolean contains(byte[] array, byte target) {
		byte[] arr$ = array;
		int len$ = array.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			byte value = arr$[i$];
			if (value == target) {
				return true;
			}
		}

		return false;
	}

	public static int indexOf(byte[] array, byte target) {
		return indexOf(array, target, 0, array.length);
	}

	private static int indexOf(byte[] array, byte target, int start, int end) {
		for (int i = start; i < end; ++i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static int indexOf(byte[] array, byte[] target) {
		Preconditions.checkNotNull(array, "array");
		Preconditions.checkNotNull(target, "target");
		if (target.length == 0) {
			return 0;
		} else {
			label28 : for (int i = 0; i < array.length - target.length + 1; ++i) {
				for (int j = 0; j < target.length; ++j) {
					if (array[i + j] != target[j]) {
						continue label28;
					}
				}

				return i;
			}

			return -1;
		}
	}

	public static int lastIndexOf(byte[] array, byte target) {
		return lastIndexOf(array, target, 0, array.length);
	}

	private static int lastIndexOf(byte[] array, byte target, int start, int end) {
		for (int i = end - 1; i >= start; --i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static byte[] concat(byte[]... arrays) {
		int length = 0;
		byte[][] arr$ = arrays;
		int pos = arrays.length;

		for (int i$ = 0; i$ < pos; ++i$) {
			byte[] array = arr$[i$];
			length += array.length;
		}

		byte[] result = new byte[length];
		pos = 0;
		byte[][] arr$ = arrays;
		int len$ = arrays.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			byte[] array = arr$[i$];
			System.arraycopy(array, 0, result, pos, array.length);
			pos += array.length;
		}

		return result;
	}

	public static byte[] ensureCapacity(byte[] array, int minLength, int padding) {
		Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[]{minLength});
		Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[]{padding});
		return array.length < minLength ? copyOf(array, minLength + padding) : array;
	}

	private static byte[] copyOf(byte[] original, int length) {
		byte[] copy = new byte[length];
		System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
		return copy;
	}

	public static byte[] toArray(Collection<? extends Number> collection) {
		if (collection instanceof ByteArrayAsList) {
			return ((ByteArrayAsList) collection).toByteArray();
		} else {
			Object[] boxedArray = collection.toArray();
			int len = boxedArray.length;
			byte[] array = new byte[len];

			for (int i = 0; i < len; ++i) {
				array[i] = ((Number) Preconditions.checkNotNull(boxedArray[i])).byteValue();
			}

			return array;
		}
	}

	public static List<Byte> asList(byte... backingArray) {
		return (List) (backingArray.length == 0 ? Collections.emptyList() : new ByteArrayAsList(backingArray));
	}
}