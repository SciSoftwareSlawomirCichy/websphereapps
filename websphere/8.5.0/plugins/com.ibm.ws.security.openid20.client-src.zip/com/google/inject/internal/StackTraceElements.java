package com.google.inject.internal;

import com.google.inject.internal.StackTraceElements.1;
import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.util.Map;

public class StackTraceElements {
	static final Map<Class<?>, LineNumbers> lineNumbersCache = (new MapMaker()).weakKeys().softValues().makeComputingMap(new 1());

	public static Object forMember(Member member) {
		if (member == null) {
			return SourceProvider.UNKNOWN_SOURCE;
		} else {
			Class declaringClass = member.getDeclaringClass();
			LineNumbers lineNumbers = (LineNumbers) lineNumbersCache.get(declaringClass);
			String fileName = lineNumbers.getSource();
			Integer lineNumberOrNull = lineNumbers.getLineNumber(member);
			int lineNumber = lineNumberOrNull == null ? lineNumbers.getFirstLine() : lineNumberOrNull;
			Class<? extends Member> memberType = MoreTypes.memberType(member);
			String memberName = memberType == Constructor.class ? "<init>" : member.getName();
			return new StackTraceElement(declaringClass.getName(), memberName, fileName, lineNumber);
		}
	}

	public static Object forType(Class<?> implementation) {
		LineNumbers lineNumbers = (LineNumbers) lineNumbersCache.get(implementation);
		int lineNumber = lineNumbers.getFirstLine();
		String fileName = lineNumbers.getSource();
		return new StackTraceElement(implementation.getName(), "class", fileName, lineNumber);
	}
}