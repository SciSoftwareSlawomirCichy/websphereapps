package com.ibm.icu.text;

import com.ibm.icu.impl.ICULocaleService;
import com.ibm.icu.impl.ICUResourceBundle;
import com.ibm.icu.impl.ICUService.Factory;
import com.ibm.icu.text.NumberFormat.NumberFormatFactory;
import com.ibm.icu.text.NumberFormat.NumberFormatShim;
import com.ibm.icu.text.NumberFormatServiceShim.NFFactory;
import com.ibm.icu.text.NumberFormatServiceShim.NFService;
import com.ibm.icu.util.ULocale;
import java.util.Locale;
import java.util.MissingResourceException;

class NumberFormatServiceShim extends NumberFormatShim {
	private static ICULocaleService service = new NFService();

	Locale[] getAvailableLocales() {
		return service.isDefault() ? ICUResourceBundle.getAvailableLocales() : service.getAvailableLocales();
	}

	ULocale[] getAvailableULocales() {
		return service.isDefault() ? ICUResourceBundle.getAvailableULocales() : service.getAvailableULocales();
	}

	Object registerFactory(NumberFormatFactory factory) {
		return service.registerFactory(new NFFactory(factory));
	}

	boolean unregister(Object registryKey) {
		return service.unregisterFactory((Factory) registryKey);
	}

	NumberFormat createInstance(ULocale desiredLocale, int choice) {
		ULocale[] actualLoc = new ULocale[1];
		NumberFormat fmt = (NumberFormat) service.get(desiredLocale, choice, actualLoc);
		if (fmt == null) {
			throw new MissingResourceException("Unable to construct NumberFormat", "", "");
		} else {
			fmt = (NumberFormat) fmt.clone();
			ULocale uloc = actualLoc[0];
			fmt.setLocale(uloc, uloc);
			return fmt;
		}
	}
}