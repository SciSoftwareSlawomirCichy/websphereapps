package com.ibm.ejs.container;

import java.rmi.RemoteException;
import java.util.concurrent.ExecutionException;

public interface RemoteAsyncResultExtended extends RemoteAsyncResult {
	Object[] waitForResult(long var1) throws ExecutionException, InterruptedException, RemoteException;
}