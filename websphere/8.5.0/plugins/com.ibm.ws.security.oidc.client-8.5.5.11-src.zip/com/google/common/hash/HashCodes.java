package com.google.common.hash;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.hash.HashCodes.BytesHashCode;
import com.google.common.hash.HashCodes.IntHashCode;
import com.google.common.hash.HashCodes.LongHashCode;

@Beta
public final class HashCodes {
	public static HashCode fromInt(int hash) {
		return new IntHashCode(hash);
	}

	public static HashCode fromLong(long hash) {
		return new LongHashCode(hash);
	}

	public static HashCode fromBytes(byte[] bytes) {
		Preconditions.checkArgument(bytes.length >= 1, "A HashCode must contain at least 1 byte.");
		return fromBytesNoCopy((byte[]) bytes.clone());
	}

	static HashCode fromBytesNoCopy(byte[] bytes) {
		return new BytesHashCode(bytes);
	}
}