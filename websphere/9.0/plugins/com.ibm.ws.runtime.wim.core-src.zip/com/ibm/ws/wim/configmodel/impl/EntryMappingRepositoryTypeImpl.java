package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

public class EntryMappingRepositoryTypeImpl extends RepositoryTypeImpl implements EntryMappingRepositoryType {
	protected static final String DATABASE_TYPE_EDEFAULT = null;
	protected String databaseType;
	protected static final String DATA_SOURCE_NAME_EDEFAULT = null;
	protected String dataSourceName;
	protected static final String DB_ADMIN_ID_EDEFAULT = null;
	protected String dbAdminId;
	protected static final String DB_ADMIN_PASSWORD_EDEFAULT = null;
	protected String dbAdminPassword;
	protected static final String DB_URL_EDEFAULT = null;
	protected static final String DB_SCHEMA_EDEFAULT = null;
	protected String dbSchema;
	protected String dbURL;
	protected static final String JDBC_DRIVER_CLASS_EDEFAULT = null;
	protected String jDBCDriverClass;

	protected EntryMappingRepositoryTypeImpl() {
		this.databaseType = DATABASE_TYPE_EDEFAULT;
		this.dataSourceName = DATA_SOURCE_NAME_EDEFAULT;
		this.dbAdminId = DB_ADMIN_ID_EDEFAULT;
		this.dbAdminPassword = DB_ADMIN_PASSWORD_EDEFAULT;
		this.dbSchema = DB_SCHEMA_EDEFAULT;
		this.dbURL = DB_URL_EDEFAULT;
		this.jDBCDriverClass = JDBC_DRIVER_CLASS_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getEntryMappingRepositoryType();
	}

	public String getDatabaseType() {
		return this.databaseType;
	}

	public void setDatabaseType(String var1) {
		String var2 = this.databaseType;
		this.databaseType = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.databaseType));
		}

	}

	public String getDataSourceName() {
		return this.dataSourceName;
	}

	public void setDataSourceName(String var1) {
		String var2 = this.dataSourceName;
		this.dataSourceName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.dataSourceName));
		}

	}

	public String getDbAdminId() {
		return this.dbAdminId;
	}

	public void setDbAdminId(String var1) {
		String var2 = this.dbAdminId;
		this.dbAdminId = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var2, this.dbAdminId));
		}

	}

	public String getDbAdminPassword() {
		return this.dbAdminPassword;
	}

	public void setDbAdminPassword(String var1) {
		String var2 = this.dbAdminPassword;
		this.dbAdminPassword = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 5, var2, this.dbAdminPassword));
		}

	}

	public String getDbURL() {
		return this.dbURL;
	}

	public void setDbURL(String var1) {
		String var2 = this.dbURL;
		this.dbURL = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 6, var2, this.dbURL));
		}

	}

	public String getDbSchema() {
		return this.dbSchema;
	}

	public void setDbSchema(String var1) {
		String var2 = this.dbSchema;
		this.dbSchema = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 7, var2, this.dbSchema));
		}

	}

	public String getJDBCDriverClass() {
		return this.jDBCDriverClass;
	}

	public void setJDBCDriverClass(String var1) {
		String var2 = this.jDBCDriverClass;
		this.jDBCDriverClass = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 8, var2, this.jDBCDriverClass));
		}

	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getAdapterClassName();
			case 1 :
				return this.getId();
			case 2 :
				return this.getDatabaseType();
			case 3 :
				return this.getDataSourceName();
			case 4 :
				return this.getDbAdminId();
			case 5 :
				return this.getDbAdminPassword();
			case 6 :
				return this.getDbURL();
			case 7 :
				return this.getDbSchema();
			case 8 :
				return this.getJDBCDriverClass();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName((String) var2);
				return;
			case 1 :
				this.setId((String) var2);
				return;
			case 2 :
				this.setDatabaseType((String) var2);
				return;
			case 3 :
				this.setDataSourceName((String) var2);
				return;
			case 4 :
				this.setDbAdminId((String) var2);
				return;
			case 5 :
				this.setDbAdminPassword((String) var2);
				return;
			case 6 :
				this.setDbURL((String) var2);
				return;
			case 7 :
				this.setDbSchema((String) var2);
				return;
			case 8 :
				this.setJDBCDriverClass((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName(ADAPTER_CLASS_NAME_EDEFAULT);
				return;
			case 1 :
				this.setId(ID_EDEFAULT);
				return;
			case 2 :
				this.setDatabaseType(DATABASE_TYPE_EDEFAULT);
				return;
			case 3 :
				this.setDataSourceName(DATA_SOURCE_NAME_EDEFAULT);
				return;
			case 4 :
				this.setDbAdminId(DB_ADMIN_ID_EDEFAULT);
				return;
			case 5 :
				this.setDbAdminPassword(DB_ADMIN_PASSWORD_EDEFAULT);
				return;
			case 6 :
				this.setDbURL(DB_URL_EDEFAULT);
				return;
			case 7 :
				this.setDbSchema(DB_SCHEMA_EDEFAULT);
				return;
			case 8 :
				this.setJDBCDriverClass(JDBC_DRIVER_CLASS_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return ADAPTER_CLASS_NAME_EDEFAULT == null
						? this.adapterClassName != null
						: !ADAPTER_CLASS_NAME_EDEFAULT.equals(this.adapterClassName);
			case 1 :
				return ID_EDEFAULT == null ? this.id != null : !ID_EDEFAULT.equals(this.id);
			case 2 :
				return DATABASE_TYPE_EDEFAULT == null
						? this.databaseType != null
						: !DATABASE_TYPE_EDEFAULT.equals(this.databaseType);
			case 3 :
				return DATA_SOURCE_NAME_EDEFAULT == null
						? this.dataSourceName != null
						: !DATA_SOURCE_NAME_EDEFAULT.equals(this.dataSourceName);
			case 4 :
				return DB_ADMIN_ID_EDEFAULT == null
						? this.dbAdminId != null
						: !DB_ADMIN_ID_EDEFAULT.equals(this.dbAdminId);
			case 5 :
				return DB_ADMIN_PASSWORD_EDEFAULT == null
						? this.dbAdminPassword != null
						: !DB_ADMIN_PASSWORD_EDEFAULT.equals(this.dbAdminPassword);
			case 6 :
				return DB_URL_EDEFAULT == null ? this.dbURL != null : !DB_URL_EDEFAULT.equals(this.dbURL);
			case 7 :
				return DB_SCHEMA_EDEFAULT == null ? this.dbSchema != null : !DB_SCHEMA_EDEFAULT.equals(this.dbSchema);
			case 8 :
				return JDBC_DRIVER_CLASS_EDEFAULT == null
						? this.jDBCDriverClass != null
						: !JDBC_DRIVER_CLASS_EDEFAULT.equals(this.jDBCDriverClass);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (databaseType: ");
			var1.append(this.databaseType);
			var1.append(", dataSourceName: ");
			var1.append(this.dataSourceName);
			var1.append(", dbAdminId: ");
			var1.append(this.dbAdminId);
			var1.append(", dbAdminPassword: ");
			var1.append(this.dbAdminPassword);
			var1.append(", dbURL: ");
			var1.append(this.dbURL);
			var1.append(", dbSchema: ");
			var1.append(this.dbSchema);
			var1.append(", jDBCDriverClass: ");
			var1.append(this.jDBCDriverClass);
			var1.append(')');
			return var1.toString();
		}
	}
}