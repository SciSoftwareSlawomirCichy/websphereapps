package com.ibm.ws.wim.adapter.ldap.change;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.adapter.ldap.LdapConnection;
import com.ibm.ws.wim.adapter.ldap.change.ad.ADChangeHandler;
import com.ibm.ws.wim.adapter.ldap.change.tds.TDSChangeHandler;
import commonj.sdo.DataObject;
import java.util.List;
import java.util.logging.Level;

public class ChangeHandlerFactory {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2009";
	private static final String CLASSNAME = ChangeHandlerFactory.class.getName();

	public static IChangeHandler getChangeHandler(LdapConnection var0) throws WIMException {
		String var2 = var0.getRepositoryId();
		DataObject var3 = ConfigManager.singleton().getRepositoryDataObject(var2);
		List var4 = var3.getList("CustomProperties");

		for (int var5 = 0; var5 < var4.size(); ++var5) {
			DataObject var6 = (DataObject) var4.get(var5);
			String var7 = var6.getString("name");
			if ("ChangeHandlerClassName".equals(var7)) {
				String var8 = var6.getString("value");

				try {
					Class var9 = Class.forName(var8);
					return (IChangeHandler) var9.newInstance();
				} catch (Exception var10) {
					throw new WIMException(var10);
				}
			}
		}

		String var11 = var0.getRepositoryType();
		if (var11.startsWith("IDS")) {
			return new TDSChangeHandler(var0);
		} else if (var11.startsWith("AD")) {
			return new ADChangeHandler(var0);
		} else {
			throw new WIMSystemException("NO_ASSOCIATED_CHANGE_HANDLER", WIMMessageHelper.generateMsgParms(var11),
					Level.SEVERE, CLASSNAME, "getChangeHandler");
		}
	}
}