package com.ibm.bsf.util;

import java.util.Hashtable;

class ScriptSymbolTable extends Hashtable {
	private Hashtable parentTable;

	ScriptSymbolTable(Hashtable var1) {
		this.parentTable = var1;
	}

	public synchronized Object get(Object var1) {
		Object var2 = super.get(var1);
		if (var2 == null && this.parentTable != null) {
			var2 = this.parentTable.get(var1);
		}

		return var2;
	}
}