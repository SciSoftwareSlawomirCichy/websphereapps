package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Analysis Engine using data base: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: FFDC Incident emitted on {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: FFDC log file management attempting to delete file {0}"},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: FFDC log file management removed {0} of {1} files that have reached their configured maximum age"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE", "FFDC0003I: FFDC log file management failed to delete file {0}"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: FFDC log file management failed to obtain list of exception files"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC closed incident stream file {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC opened incident stream file {0}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: FFDC failed to close incident stream file {0}, caught exception {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: FFDC failed to open or create incident stream file {0}, caught exception {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: FFDC failed to write to incident stream file {0}, caught exception {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}