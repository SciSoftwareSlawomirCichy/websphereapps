package com.google.common.primitives;

import com.google.errorprone.annotations.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;

// $FF: synthetic class
@ParametersAreNonnullByDefault
@CheckReturnValue
interface package-info {
}