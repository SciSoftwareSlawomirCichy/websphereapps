package com.ibm.ejs.csi;

import com.ibm.ejs.models.base.extensions.commonext.localtran.LocalTransaction;
import com.ibm.ejs.models.base.extensions.ejbext.EnterpriseBeanExtension;
import com.ibm.ejs.models.base.extensions.ejbext.LocalTran;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;

public class LocalTranConfigDataImpl extends BasicLocalTranConfigDataImpl {
	private static final TraceComponent tc = Tr.register(LocalTranConfigDataImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public LocalTranConfigDataImpl() {
	}

	public LocalTranConfigDataImpl(EnterpriseBeanExtension ebx) {
		if (ebx != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "CTOR was passed non-null EnterpriseBeanExtension object for config data");
			}

			if (ebx.getEnterpriseBean().isContainerManagedEntity()) {
				this.resolver = 1;
			}

			LocalTransaction localTransaction = ebx.getLocalTransaction();
			if (localTransaction != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "We have a LocalTransaction object, so use the 5.0 or later config data");
				}

				this.init(localTransaction);
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "No LocalTransaction object, checking for a LocalTran object");
				}

				LocalTran oldLocalTran = ebx.getLocalTran();
				if (oldLocalTran != null && oldLocalTran.isSetUnresolvedAction()
						&& oldLocalTran.getUnresolvedAction().getValue() == 1) {
					this.unresolvedAction = 1;
				}
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "CTOR was passed a null EnterpriseBeanExtension object, using default values for config data");
		}

	}

	public LocalTranConfigDataImpl(LocalTransaction ltx) {
		this.init(ltx);
	}

	private void init(LocalTransaction ltx) {
		if (ltx != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "init was passed non-null LocalTransaction object for config data");
			}

			if (ltx.isSetBoundary()) {
				this.boundary = ltx.getBoundary().getValue();
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "LocalTransaction boundary is NOT set, using default value of BeanMethod");
			}

			if (ltx.isSetResolver()) {
				this.resolver = ltx.getResolver().getValue();
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "LocalTransaction resolver is NOT set, using default value of Application");
			}

			if (ltx.isSetUnresolvedAction()) {
				this.unresolvedAction = ltx.getUnresolvedAction().getValue();
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "LocalTransaction unresolved action is NOT set, using default value of Rollback");
			}

			if (ltx.isSetShareable()) {
				this.isShareable = ltx.isShareable();
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "LocalTransaction isShareable action is NOT set, using default value of false");
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "init was passed a null LocalTransaction object, using default values for config data");
		}

	}
}