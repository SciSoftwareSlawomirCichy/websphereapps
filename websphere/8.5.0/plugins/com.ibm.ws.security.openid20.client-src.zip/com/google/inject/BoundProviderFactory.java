package com.google.inject;

import com.google.inject.BindingProcessor.CreationListener;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.InternalContext;
import com.google.inject.internal.InternalFactory;
import com.google.inject.spi.Dependency;

class BoundProviderFactory<T> implements InternalFactory<T>, CreationListener {
	private final InjectorImpl injector;
	final Key<? extends Provider<? extends T>> providerKey;
	final Object source;
	private InternalFactory<? extends Provider<? extends T>> providerFactory;

	BoundProviderFactory(InjectorImpl injector, Key<? extends Provider<? extends T>> providerKey, Object source) {
		this.injector = injector;
		this.providerKey = providerKey;
		this.source = source;
	}

	public void notify(Errors errors) {
		try {
			this.providerFactory = this.injector.getInternalFactory(this.providerKey, errors.withSource(this.source));
		} catch (ErrorsException var3) {
			errors.merge(var3.getErrors());
		}

	}

	public T get(Errors errors, InternalContext context, Dependency<?> dependency) throws ErrorsException {
		errors = errors.withSource(this.providerKey);
		Provider provider = (Provider) this.providerFactory.get(errors, context, dependency);

		try {
			return errors.checkForNull(provider.get(), this.source, dependency);
		} catch (RuntimeException var6) {
			throw errors.errorInProvider(var6).toException();
		}
	}

	public String toString() {
		return this.providerKey.toString();
	}
}