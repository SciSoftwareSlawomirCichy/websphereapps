package com.ibm.bsf.util.cf;

import com.ibm.bsf.debug.util.DebugLog;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;

public class CFDriver {
	public static void main(String[] var0) {
		if (var0.length % 2 == 0) {
			String var1 = null;
			String var2 = null;
			String var3 = null;
			String var4 = null;
			String var5 = null;
			String var6 = null;
			Object var7 = null;
			Object var8 = null;
			CodeFormatter var9 = new CodeFormatter();

			for (int var10 = 0; var10 < var0.length; var10 += 2) {
				if (var0[var10].startsWith("-i")) {
					var1 = var0[var10 + 1];
				} else if (var0[var10].startsWith("-o")) {
					var2 = var0[var10 + 1];
				} else if (var0[var10].startsWith("-m")) {
					var3 = var0[var10 + 1];
				} else if (var0[var10].startsWith("-st")) {
					var4 = var0[var10 + 1];
				} else if (var0[var10].startsWith("-d")) {
					var5 = var0[var10 + 1];
				} else if (var0[var10].startsWith("-sd")) {
					var6 = var0[var10 + 1];
				}
			}

			if (var1 != null) {
				try {
					var7 = new FileReader(var1);
				} catch (FileNotFoundException var14) {
					printError("Cannot open input file: " + var1);
					return;
				}
			} else {
				var7 = new InputStreamReader(System.in);
			}

			if (var2 != null) {
				try {
					var8 = new FileWriter(var2);
				} catch (IOException var13) {
					printError("Cannot open output file: " + var2);
					return;
				}
			} else {
				var8 = new OutputStreamWriter(System.out);
			}

			if (var3 != null) {
				try {
					var9.setMaxLineLength(Integer.parseInt(var3));
				} catch (NumberFormatException var12) {
					printError("Not a valid integer: " + var3);
					return;
				}
			}

			if (var4 != null) {
				try {
					var9.setIndentationStep(Integer.parseInt(var4));
				} catch (NumberFormatException var11) {
					printError("Not a valid integer: " + var4);
					return;
				}
			}

			if (var5 != null) {
				var9.setDelimiters(var5);
			}

			if (var6 != null) {
				var9.setStickyDelimiters(var6);
			}

			var9.formatCode((Reader) var7, (Writer) var8);
		} else {
			printHelp();
		}

	}

	private static void printError(String var0) {
		DebugLog.stderrPrintln("ERROR: " + var0, 2);
	}

	private static void printHelp() {
		System.out.println("Usage:");
		System.out.println();
		System.out.println("  java " + (class$com$ibm$bsf$util$cf$CFDriver == null
				? (class$com$ibm$bsf$util$cf$CFDriver = class$("com.ibm.bsf.util.cf.CFDriver"))
				: class$com$ibm$bsf$util$cf$CFDriver).getName() + " [args]");
		System.out.println();
		System.out.println("    args:");
		System.out.println();
		System.out.println("      [-in      fileName]   default: <STDIN>");
		System.out.println("      [-out     fileName]   default: <STDOUT>");
		System.out.println("      [-maxLine   length]   default: 74");
		System.out.println("      [-step        size]   default: 2");
		System.out.println("      [-delim      group]   default: (+");
		System.out.println("      [-sdelim     group]   default: ,");
	}
}