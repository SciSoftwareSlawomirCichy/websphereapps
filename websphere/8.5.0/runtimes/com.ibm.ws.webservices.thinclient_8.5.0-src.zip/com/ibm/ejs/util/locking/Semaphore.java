package com.ibm.ejs.util.locking;

public final class Semaphore extends Lockable {
}