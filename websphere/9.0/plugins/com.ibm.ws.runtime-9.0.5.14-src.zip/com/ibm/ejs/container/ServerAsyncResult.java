package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.ejb.AsyncResult;

public abstract class ServerAsyncResult implements Future<Object> {
	private static final TraceComponent tc = Tr.register(ServerAsyncResult.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private Future<?> ivFuture;
	private Throwable ivException = null;
	private volatile boolean ivCancelled = false;
	private volatile boolean ivWasCancelCalled = false;
	private volatile boolean ivDone = false;
	private final CountDownLatch ivGate = new CountDownLatch(1);
	public final EJBPMICollaborator ivPmiBean;

	public ServerAsyncResult(EJBPMICollaborator pmiBean) {
		this.ivPmiBean = pmiBean;
	}

	protected void done() {
		this.ivDone = true;
		this.ivGate.countDown();
	}

	public synchronized boolean cancel(boolean mayInterruptIfRunning) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "cancel - Future object: " + this, mayInterruptIfRunning);
		}

		boolean cancelled = false;
		if (!this.ivCancelled) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "attempting to remove from work queue");
			}

			cancelled = this.doCancel();
			if (cancelled) {
				this.ivCancelled = true;
				this.done();
				if (this.ivPmiBean != null) {
					this.ivPmiBean.asyncMethodCallCanceled();
					this.ivPmiBean.asyncQueSizeDecrement();
				}
			} else {
				this.ivWasCancelCalled = mayInterruptIfRunning;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "cancel", cancelled);
		}

		return cancelled;
	}

	protected abstract boolean doCancel();

	public boolean wasCancelCalled() {
		return this.ivWasCancelCalled;
	}

	public Object get() throws InterruptedException, ExecutionException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "get - Future object: " + this);
		}

		this.await(0L, (TimeUnit) null);
		Object result = this.getResult();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "get: " + Util.identity(result));
		}

		return result;
	}

	private Object getResult() throws InterruptedException, ExecutionException {
		if (this.ivCancelled) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getResult: throwing CancellationException");
			}

			throw new CancellationException();
		} else if (this.ivException != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getResult: " + this.ivException);
			}

			throw new ExecutionException(this.ivException);
		} else {
			Object resultToReturn = null;
			if (this.ivFuture != null) {
				resultToReturn = this.ivFuture.get();
			}

			return resultToReturn;
		}
	}

	private Object getResult(long timeout, TimeUnit unit)
			throws InterruptedException, ExecutionException, TimeoutException {
		if (this.ivCancelled) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getResult: throwing CancellationException");
			}

			throw new CancellationException();
		} else if (this.ivException != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getResult: " + this.ivException);
			}

			throw new ExecutionException(this.ivException);
		} else {
			Object resultToReturn = null;
			if (this.ivFuture != null) {
				if (this.ivFuture instanceof AsyncResult) {
					resultToReturn = this.ivFuture.get();
				} else {
					resultToReturn = this.ivFuture.get(timeout, unit);
				}
			}

			return resultToReturn;
		}
	}

	protected boolean await(long timeout, TimeUnit unit) throws InterruptedException {
		if (unit == null) {
			this.ivGate.await();
			return true;
		} else {
			return this.ivGate.await(timeout, unit);
		}
	}

	public Object get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			String completeTime = "Timeout setting: " + timeout + " " + unit;
			Tr.entry(tc, "get - " + completeTime + " Future object: " + this);
		}

		if (unit == null) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "get - null unit");
			}

			throw new NullPointerException("unit");
		} else {
			long startTime = System.nanoTime();
			if (!this.await(timeout, unit)) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "get - asynchronous method timed out, throwing TimeoutException.");
				}

				throw new TimeoutException();
			} else {
				long remainingTime = timeout - unit.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS);
				Object resultToReturn = this.getResult(remainingTime, unit);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "get: " + Util.identity(resultToReturn));
				}

				return resultToReturn;
			}
		}
	}

	public boolean isCancelled() {
		boolean cancelled = this.ivCancelled;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isCancelled: " + cancelled + " Future object: " + this);
		}

		return cancelled;
	}

	public boolean isDone() {
		boolean done = this.ivDone;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isDone: " + done + " Future object: " + this);
		}

		return done;
	}

	void setResult(Future<?> theFuture) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setResult: " + Util.identity(theFuture) + " Future object: " + this);
		}

		this.ivFuture = theFuture;
		this.done();
	}

	void setException(Throwable theException) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setException - Future object: " + this, theException);
		}

		this.ivException = theException;
		this.done();
	}
}