package com.ibm.ejs.ras.ffdc;

import com.ibm.ffdc.util.bulkdata.CapacityException;
import com.ibm.ffdc.util.bulkdata.FixedCapacityOutputStream;
import com.ibm.ffdc.util.provider.Incident;
import java.io.IOException;
import java.io.PrintStream;
import java.util.List;

final class IncidentSummaryLogger extends com.ibm.ffdc.util.provider.IncidentSummaryLogger<FfdcProvider> {
	public static final int MAXSUMMARYSIZE = 1048576;

	protected IncidentSummaryLogger(FfdcProvider provider) {
		super(provider);
	}

	protected void log(List<Incident> incidents) {
		if (this.getLogIdx() != incidents.size() - 1) {
			FixedCapacityOutputStream os = new FixedCapacityOutputStream(1048576);
			PrintStream ffdcFile = FfdcProvider.getFFDCFilePrintStream();
			if (ffdcFile != null) {
				try {
					PrintStream ps = new PrintStream(os);
					super.logIncidentSummary(ps, incidents);
					ps.flush();
					os.writeTo(ffdcFile);
				} catch (CapacityException var7) {
					try {
						os.writeTo(System.err);
					} catch (IOException var6) {
						this.ffdcerror(var6);
					}
				} catch (Throwable var8) {
					this.ffdcerror(var8);
				}
			}
		}

	}
}