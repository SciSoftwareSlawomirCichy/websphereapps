package com.ibm.ws.security.oidc.client.filter;

public class GreaterCondition extends SimpleCondition {
	public GreaterCondition(String key, IValue value) {
		super(key, value);
	}

	public boolean checkCondition(IValue test) throws FilterException {
		return this.getValue().greaterThan(test);
	}

	public String getOperand() {
		return ">";
	}
}