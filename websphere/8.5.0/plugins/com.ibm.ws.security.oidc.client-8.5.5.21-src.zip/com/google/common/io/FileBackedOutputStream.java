package com.google.common.io;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.io.FileBackedOutputStream.1;
import com.google.common.io.FileBackedOutputStream.2;
import com.google.common.io.FileBackedOutputStream.MemoryOutput;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Beta
@GwtIncompatible
public final class FileBackedOutputStream extends OutputStream {
	private final int fileThreshold;
	private final boolean resetOnFinalize;
	private final ByteSource source;
	private OutputStream out;
	private MemoryOutput memory;
	@NullableDecl
	private File file;

	@VisibleForTesting
	synchronized File getFile() {
		return this.file;
	}

	public FileBackedOutputStream(int fileThreshold) {
		this(fileThreshold, false);
	}

	public FileBackedOutputStream(int fileThreshold, boolean resetOnFinalize) {
      this.fileThreshold = fileThreshold;
      this.resetOnFinalize = resetOnFinalize;
      this.memory = new MemoryOutput((1)null);
      this.out = this.memory;
      if (resetOnFinalize) {
         this.source = new 1(this);
      } else {
         this.source = new 2(this);
      }

   }

	public ByteSource asByteSource() {
		return this.source;
	}

	private synchronized InputStream openInputStream() throws IOException {
		return (InputStream) (this.file != null
				? new FileInputStream(this.file)
				: new ByteArrayInputStream(this.memory.getBuffer(), 0, this.memory.getCount()));
	}

	public synchronized void reset() throws IOException {
      boolean var5 = false;

      try {
         var5 = true;
         this.close();
         var5 = false;
      } finally {
         if (var5) {
            if (this.memory == null) {
               this.memory = new MemoryOutput((1)null);
            } else {
               this.memory.reset();
            }

            this.out = this.memory;
            if (this.file != null) {
               File deleteMe = this.file;
               this.file = null;
               if (!deleteMe.delete()) {
                  throw new IOException("Could not delete: " + deleteMe);
               }
            }

         }
      }

      if (this.memory == null) {
         this.memory = new MemoryOutput((1)null);
      } else {
         this.memory.reset();
      }

      this.out = this.memory;
      if (this.file != null) {
         File deleteMe = this.file;
         this.file = null;
         if (!deleteMe.delete()) {
            throw new IOException("Could not delete: " + deleteMe);
         }
      }

   }

	public synchronized void write(int b) throws IOException {
		this.update(1);
		this.out.write(b);
	}

	public synchronized void write(byte[] b) throws IOException {
		this.write(b, 0, b.length);
	}

	public synchronized void write(byte[] b, int off, int len) throws IOException {
		this.update(len);
		this.out.write(b, off, len);
	}

	public synchronized void close() throws IOException {
		this.out.close();
	}

	public synchronized void flush() throws IOException {
		this.out.flush();
	}

	private void update(int len) throws IOException {
		if (this.file == null && this.memory.getCount() + len > this.fileThreshold) {
			File temp = File.createTempFile("FileBackedOutputStream", (String) null);
			if (this.resetOnFinalize) {
				temp.deleteOnExit();
			}

			FileOutputStream transfer = new FileOutputStream(temp);
			transfer.write(this.memory.getBuffer(), 0, this.memory.getCount());
			transfer.flush();
			this.out = transfer;
			this.file = temp;
			this.memory = null;
		}

	}
}