package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public final class WeakManagedBeanCache {
	private static final String CLASS_NAME = WeakManagedBeanCache.class.getName();
	private static final TraceComponent tc;
	private static WeakManagedBeanCache svInstance;
	private final ReferenceQueue<EJSWrapperBase> ivRefQueue = new ReferenceQueue();
	private final Map<WeakReference<EJSWrapperBase>, BeanO> ivCache = new HashMap();

	public static synchronized WeakManagedBeanCache instance() {
		if (svInstance == null) {
			svInstance = new WeakManagedBeanCache();
		}

		return svInstance;
	}

	private WeakManagedBeanCache() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "WeakManagedBeanCache : " + this.ivRefQueue + ", " + this.ivCache);
		}

	}

	public void add(EJSWrapperBase wrapper, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "add(" + Util.identity(wrapper) + ", " + bean + ")");
		}

		this.poll();
		WeakReference<EJSWrapperBase> key = new WeakReference(wrapper, this.ivRefQueue);
		Map var5 = this.ivCache;
		synchronized (this.ivCache) {
			this.ivCache.put(key, bean);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "add : key = " + key);
		}

	}

	public void remove(EJSHome home) {
		List<BeanO> removedBeans = new ArrayList();
		Map var3 = this.ivCache;
		synchronized (this.ivCache) {
			this.poll();
			Iterator it = this.ivCache.entrySet().iterator();

			while (true) {
				if (!it.hasNext()) {
					break;
				}

				BeanO bean = (BeanO) ((Entry) it.next()).getValue();
				if (bean.home == home) {
					it.remove();
					removedBeans.add(bean);
				}
			}
		}

		Iterator i$ = removedBeans.iterator();

		while (i$.hasNext()) {
			BeanO bean = (BeanO) i$.next();
			bean.destroy();
		}

	}

	private void poll() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		BeanO bean = null;
		int removeCount = 0;

		Reference ref;
		while ((ref = this.ivRefQueue.poll()) != null) {
			Map var5 = this.ivCache;
			synchronized (this.ivCache) {
				bean = (BeanO) this.ivCache.remove(ref);
			}

			++removeCount;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "poll : removed (" + ref + ", " + bean + ")");
			}

			if (bean != null) {
				bean.destroy();
			}
		}

		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "poll : size = " + this.ivCache.size() + ", removed = " + removeCount);
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		svInstance = null;
	}
}