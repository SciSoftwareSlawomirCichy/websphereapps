package com.ibm.ejs.oa;

import com.ibm.CORBA.iiop.IOR;
import com.ibm.CORBA.iiop.ORB;
import com.ibm.CORBA.iiop.Profile;
import com.ibm.CORBA.iiop.ThreadPool;
import com.ibm.ejs.EJSException;
import com.ibm.ejs.oa.LocationService.1;
import com.ibm.ejs.oa.LocationService.2;
import com.ibm.ejs.oa.LocationService.3;
import com.ibm.ejs.oa.LocationService.4;
import com.ibm.ejs.oa.LocationService.LSInvocation;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.orb.services.lsd.AdapterInfo;
import com.ibm.ws.orb.services.lsd.LocationServiceHelper;
import com.ibm.ws.orbimpl.services.lsd.IORPrototype;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.PrivilegedExceptionAction;
import java.util.Vector;

public class LocationService {
	private static com.ibm.ws.orb.services.lsd.LocationService ls;
	private static ORB_ServerImpl orbServer;
	private static byte[] serverUuid = null;
	private static IOR lsdIOR = null;
	private static IORPrototype lsdIORProto = null;
	private static LocationService locationService;
	private static final String CLASS_NAME = LocationService.class.getName();
	private static final TraceComponent tc;
	private static Class ctxMgrClz;
	private static Object ctxMgr;
	private static Boolean ctxMgrIsCellSecurityEnabled;
	private static boolean isSecurityServiceStarted;
	private static Vector invokeQueue;

	private LocationService() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		ls = null;
		orbServer = null;
		serverUuid = null;
		lsdIOR = null;
		lsdIORProto = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public static void initClient() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "initClient");
		}

		if (locationService != null) {
			throw new RuntimeException("LocationService already initialized");
		} else {
			locationService = new LocationService();
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "initClient");
			}

		}
	}

	public static LocationService getLocationService() {
		return locationService;
	}

	public static com.ibm.ws.orb.services.lsd.LocationService getRealLocationService() {
		LocationService var10000 = locationService;
		return ls;
	}

	public void register(ORB orb) throws EJSException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "register");
		}

		try {
			if (ls == null) {
				org.omg.CORBA.Object lsObj = orb.resolve_initial_references("LocationService");
				if (lsObj != null) {
					ls = LocationServiceHelper.narrow(lsObj);
				}

				if (ls == null) {
					return;
				}
			}

			if (orbServer == null) {
				orbServer = ORB_ServerImpl.getORBServer();
				orbServer.init(orb, this);
				orb.connect(orbServer);
			}

			if (serverUuid == null) {
				serverUuid = orb.getProperty("com.ibm.CORBA.ServerUUID").getBytes();
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "serverUuid = ", serverUuid.toString());
			}

			if (isCellSecurityEnabled() && !isSecurityServiceStarted()) {
				enqueueInvoke("invokeRegisterServer", new Class[]{ORB.class}, new Object[]{orb});
			} else {
				invokeRegisterServer(orb);
			}
		} catch (Exception var6) {
			throw new EJSException(
					"Could not register with Location Service Daemon, which could only reside in the NodeAgent. Make sure the NodeAgent for this node is up and running.",
					var6);
		} finally {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "register");
			}

		}

	}

	public static void invokeRegisterServer(ORB orb) throws EJSException {
      String methodName = "invokeRegisterServer()";
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "invokeRegisterServer()");
      }

      try {
         PrivilegedExceptionAction action = new 1();
         byte[] lsdInfo = (byte[])((byte[])runAsSystem(action));
         lsdIOR = ORB.createIOR(orb, new String(lsdInfo));
         lsdIORProto = new IORPrototype(orb, lsdIOR);
      } catch (Exception var7) {
         throw new EJSException("Could not register with Location Service Daemon, which could only reside in the NodeAgent. Make sure the NodeAgent for this node is up and running.", var7);
      } finally {
         if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
            Tr.exit(tc, "invokeRegisterServer()");
         }

      }

   }

	public void unregister() {
		if (ls != null) {
			invokeUnregisterServer();
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.debug(tc, "LSD is unavailable, unregister_server will not be performed.");
		}

	}

	public static void invokeUnregisterServer() {
      String methodName = "invokeUnregisterServer()";
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "invokeUnregisterServer()");
      }

      try {
         PrivilegedExceptionAction action = new 2();
         runAsSystem(action);
      } catch (Exception var5) {
         Tr.warning(tc, "Caught an exception while unregistering from LSD {0}", new Object[]{var5});
      } finally {
         if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
            Tr.exit(tc, "invokeUnregisterServer()");
         }

      }

   }

	public static void registerObjectAdapter(ORB orb, String oaName) {
		if (ls != null) {
			if (isCellSecurityEnabled() && !isSecurityServiceStarted()) {
				enqueueInvoke("invokeRegisterObjectAdapter", new Class[]{ORB.class, String.class},
						new Object[]{orb, oaName});
			} else {
				invokeRegisterObjectAdapter(orb, oaName);
			}
		}

	}

	public static void invokeRegisterObjectAdapter(ORB orb, String oaName) {
      String methodName = "invokeRegisterObjectAdapter()";
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "invokeRegisterObjectAdapter()");
      }

      if (ls != null) {
         byte[] orbUuid = serverUuid;
         IORPrototype adapterProto = new IORPrototype(orb, 0);
         AdapterInfo[] adapterInfoList = new AdapterInfo[]{new AdapterInfo(oaName.getBytes(), adapterProto.asIOR().stringify().getBytes())};
         PrivilegedExceptionAction action = new 3(orbUuid, adapterInfoList);
         runAsSystem(action);
      }

      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.exit(tc, "invokeRegisterObjectAdapter()");
      }

   }

	public static void unregisterObjectAdapter(ORB orb, String oaName) {
		if (ls != null) {
			invokeUnregisterObjectAdapter(orb, oaName);
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.debug(tc, "LSD is unavailable, unregister_object_adapters will not be performed.");
		}

	}

	public static void invokeUnregisterObjectAdapter(ORB orb, String oaName) {
      String methodName = "invokeUnregisterObjectAdapter()";
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "invokeUnregisterObjectAdapter()");
      }

      if (ls != null) {
         byte[] orbUuid = serverUuid;
         new IORPrototype(orb, 0);
         byte[][] adapterNameList = new byte[][]{oaName.getBytes()};
         PrivilegedExceptionAction action = new 4(orbUuid, adapterNameList);
         runAsSystem(action);
      }

      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.exit(tc, "invokeUnregisterObjectAdapter()");
      }

   }

	public static Profile getLSDIORProfile() {
		return lsdIOR != null ? lsdIOR.getProfile() : null;
	}

	public int getPort() {
		return lsdIOR.getProfile().getPort();
	}

	public String getHostname() {
		return lsdIOR.getProfile().getHost();
	}

	void setThreadPool(ThreadPool pool) {
	}

	private static boolean isCellSecurityEnabled() {
		if (ctxMgrIsCellSecurityEnabled != null) {
			return ctxMgrIsCellSecurityEnabled;
		} else {
			ctxMgrIsCellSecurityEnabled = false;

			try {
				if (ctxMgr == null) {
					Class ctxMgrFactoryClz = Class.forName("com.ibm.ws.security.core.ContextManagerFactory");
					Method ctxMgrFactoryGetInstance = ctxMgrFactoryClz.getMethod("getInstance", (Class[]) null);
					ctxMgr = ctxMgrFactoryGetInstance.invoke((Object) null, (Object[]) null);
					ctxMgrClz = Class.forName("com.ibm.ws.security.core.ContextManager");
				}

				Method isEnabled = ctxMgrClz.getMethod("isCellSecurityEnabled", (Class[]) null);
				ctxMgrIsCellSecurityEnabled = (Boolean) isEnabled.invoke(ctxMgr, (Object[]) null);
			} catch (InvocationTargetException var2) {
				FFDCFilter.processException(var2, CLASS_NAME + ".isCellSecurityEnabled", "375",
						new Object[]{ctxMgrIsCellSecurityEnabled, ctxMgr, ctxMgrClz});
				Throwable targetEx = var2.getTargetException();
				Tr.debug(tc, "isCellSecurityEnabled caught InvocationTargetException, target exception is: " + targetEx,
						targetEx);
			} catch (Exception var3) {
				FFDCFilter.processException(var3, CLASS_NAME + ".isCellSecurityEnabled", "383",
						new Object[]{ctxMgrIsCellSecurityEnabled, ctxMgr, ctxMgrClz});
				Tr.debug(tc, "isCellSecurityEnabled() caught unexpected exception: " + var3, var3);
			}

			return ctxMgrIsCellSecurityEnabled;
		}
	}

	public static boolean setSecurityServiceStarted(boolean isStarted) {
		String methodName = "setSecurityServiceStarted()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "setSecurityServiceStarted()");
		}

		isSecurityServiceStarted = isStarted;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setSecurityServiceStarted(): value=" + isSecurityServiceStarted);
		}

		if (isSecurityServiceStarted) {
			processAllInvoke();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "setSecurityServiceStarted()");
		}

		return isSecurityServiceStarted;
	}

	public static boolean isSecurityServiceStarted() {
		return isSecurityServiceStarted;
	}

	private static void enqueueInvoke(String name, Class[] parmTypes, Object[] args) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "enqueueInvoke():" + name);
		}

		invokeQueue.add(new LSInvocation(name, parmTypes, args));
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "enqueueInvoke()");
		}

	}

	private static void dequeueInvoke() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "dequeueInvoke()");
		}

		LSInvocation inv = (LSInvocation) invokeQueue.remove(0);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "dequeueInvoke():" + inv.methodName());
		}

		try {
			Method method = LocationService.class.getMethod(inv.methodName(), inv.parmTypes());
			method.invoke((Object) null, inv.args());
		} catch (Exception var2) {
			Tr.error(tc, "dequeueInvoke() invoke error:" + var2);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "dequeueInvoke()");
		}

	}

	private static void processAllInvoke() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "processAllInvoke()");
		}

		while (!invokeQueue.isEmpty()) {
			dequeueInvoke();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "processAllInvoke()");
		}

	}

	private static Object runAsSystem(PrivilegedExceptionAction action) {
		Object result = null;
		if (ctxMgrClz != null && ctxMgr != null) {
			try {
				Method m = ctxMgrClz.getMethod("runAsSystem", PrivilegedExceptionAction.class);
				result = m.invoke(ctxMgr, action);
			} catch (InvocationTargetException var4) {
				FFDCFilter.processException(var4, CLASS_NAME + ".runAsSystem", "465",
						new Object[]{ctxMgrIsCellSecurityEnabled, ctxMgr, ctxMgrClz});
				Throwable targetEx = var4.getTargetException();
				Tr.debug(tc,
						"Failed to reflectively invoke com.ibm.ws.security.core.ContextManager.runAsSystem(), target exception is: "
								+ targetEx,
						targetEx);
			} catch (Exception var5) {
				FFDCFilter.processException(var5, CLASS_NAME + ".runAsSystem", "473",
						new Object[]{ctxMgrIsCellSecurityEnabled, ctxMgr, ctxMgrClz});
				Tr.debug(tc, "Failed to reflectively invoke com.ibm.ws.security.core.ContextManager.runAsSystem()",
						var5);
			}
		}

		return result;
	}

	static {
		tc = Tr.register(CLASS_NAME, "ObjectAdapter", "com.ibm.ws.runtime.runtime");
		ctxMgrClz = null;
		ctxMgr = null;
		ctxMgrIsCellSecurityEnabled = null;
		isSecurityServiceStarted = false;
		invokeQueue = new Vector();
	}
}