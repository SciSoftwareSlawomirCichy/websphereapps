package com.google.common.escape;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.escape.CharEscaperBuilder.CharArrayDecorator;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

@Beta
@GwtCompatible
public final class CharEscaperBuilder {
	private final Map<Character, String> map = new HashMap();
	private int max = -1;

	@CanIgnoreReturnValue
	public CharEscaperBuilder addEscape(char c, String r) {
		this.map.put(c, Preconditions.checkNotNull(r));
		if (c > this.max) {
			this.max = c;
		}

		return this;
	}

	@CanIgnoreReturnValue
	public CharEscaperBuilder addEscapes(char[] cs, String r) {
		Preconditions.checkNotNull(r);
		char[] var3 = cs;
		int var4 = cs.length;

		for (int var5 = 0; var5 < var4; ++var5) {
			char c = var3[var5];
			this.addEscape(c, r);
		}

		return this;
	}

	public char[][] toArray() {
		char[][] result = new char[this.max + 1][];

		Entry entry;
		for (Iterator var2 = this.map.entrySet().iterator(); var2
				.hasNext(); result[(Character) entry.getKey()] = ((String) entry.getValue()).toCharArray()) {
			entry = (Entry) var2.next();
		}

		return result;
	}

	public Escaper toEscaper() {
		return new CharArrayDecorator(this.toArray());
	}
}