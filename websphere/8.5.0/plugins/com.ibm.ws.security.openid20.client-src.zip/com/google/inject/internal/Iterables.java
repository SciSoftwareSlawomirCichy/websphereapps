package com.google.inject.internal;

import com.google.inject.internal.Iterables.1;
import com.google.inject.internal.Iterables.2;
import com.google.inject.internal.Iterables.3;
import java.util.Arrays;
import java.util.Iterator;

public final class Iterables {
	public static String toString(Iterable<?> iterable) {
		return Iterators.toString(iterable.iterator());
	}

	public static <T> T getOnlyElement(Iterable<T> iterable) {
		return Iterators.getOnlyElement(iterable.iterator());
	}

	public static <T> Iterable<T> concat(Iterable<? extends T> a, Iterable<? extends T> b) {
		Preconditions.checkNotNull(a);
		Preconditions.checkNotNull(b);
		return concat(Arrays.asList(a, b));
	}

	public static <T> Iterable<T> concat(Iterable<? extends Iterable<? extends T>> inputs) {
      Function<Iterable<? extends T>, Iterator<? extends T>> function = new 1();
      Iterable<Iterator<? extends T>> iterators = transform(inputs, function);
      return new 2(iterators);
   }

	public static <F, T> Iterable<T> transform(Iterable<F> fromIterable, Function<? super F, ? extends T> function) {
      Preconditions.checkNotNull(fromIterable);
      Preconditions.checkNotNull(function);
      return new 3(fromIterable, function);
   }
}