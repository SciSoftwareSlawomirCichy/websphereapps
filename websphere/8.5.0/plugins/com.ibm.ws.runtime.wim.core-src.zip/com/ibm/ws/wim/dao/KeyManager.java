package com.ibm.ws.wim.dao;

import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.EnvironmentManager;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.adapter.db.KeyGenerator;
import com.ibm.ws.wim.env.ITransactionUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;

public class KeyManager {
	public static final String CLASSNAME = KeyManager.class.getName();
	private static final Logger trcLogger;
	private DataAccessObject dao = null;
	private Hashtable dbKeys = null;
	private Hashtable laKeys = null;
	public static final int KEY_TYPE_DB = 1;
	public static final int KEY_TYPE_LA = 2;
	private KeyGenerator keyGen = null;
	boolean dbInit = false;
	boolean laInit = false;
	private Object txControl = null;
	private ITransactionUtil jtaHelper = FactoryManager.getTransactionUtil();
	private EnvironmentManager environmentManager = null;
	String dbSchema = null;

	public KeyManager() {
		this.initializeTransactionControl();
	}

	public KeyManager(DataAccessObject var1) {
		this.dao = var1;
		this.initializeTransactionControl();
	}

	private void initializeTransactionControl() {
		this.environmentManager = EnvironmentManager.singleton();
	}

	public synchronized long getDBKeyForTable(Connection var1, String var2) throws SQLException, NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getDBKeyForTable");
		}

		if (this.dbSchema != null && !this.dbSchema.trim().equals("")) {
			var2 = this.dbSchema.trim() + "." + var2;
		}

		var2 = var2.trim().toUpperCase();
		if (!this.dbInit) {
			this.initialize(var1, 1);
		}

		long[] var8 = (long[]) ((long[]) this.dbKeys.get(var2));
		long var4 = var8[0];
		long var6 = var8[1];
		if (var4 > var6) {
			var4 = this.updateKey(var1, var2, 1);
			var8 = (long[]) ((long[]) this.dbKeys.get(var2));
		}

		long var9 = var4++;
		var8[0] = var4;
		this.dbKeys.put(var2, var8);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getDBKeyForTable");
		}

		return var9;
	}

	public synchronized long getLAKeyForTable(Connection var1, String var2) throws SQLException, NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getLAKeyForTable");
		}

		if (!this.laInit) {
			this.initialize(var1, 2);
		}

		if (this.dbSchema != null && !this.dbSchema.trim().equals("")) {
			var2 = this.dbSchema.trim() + "." + var2;
		}

		var2 = var2.trim().toUpperCase();
		long[] var8 = (long[]) ((long[]) this.laKeys.get(var2));
		long var4 = var8[0];
		long var6 = var8[1];
		if (var4 > var6) {
			var4 = this.updateKey(var1, var2, 2);
			var8 = (long[]) ((long[]) this.laKeys.get(var2));
		}

		long var9 = var4++;
		var8[0] = var4;
		this.laKeys.put(var2, var8);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getLAKeyForTable");
		}

		return var9;
	}

	private synchronized void initialize(Connection var1, int var2) throws SQLException, NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize");
		}

		long[] var4 = new long[]{0L, -1L};
		Hashtable var5 = new Hashtable();
		String var6 = null;
		String var7 = this.dao.getQuerySet().selectDBKeys;
		if (var2 == 2) {
			var7 = this.dao.getQuerySet().selectLAKeys;
		}

		PreparedStatement var8 = var1.prepareStatement(var7);
		ResultSet var9 = var8.executeQuery();

		while (var9.next()) {
			var6 = var9.getString("TABLENAME");
			var5.put(var6.trim().toUpperCase(), var4);
		}

		if (var2 == 1) {
			this.dbKeys = var5;
			this.dbInit = true;
		} else {
			this.laKeys = var5;
			this.laInit = true;
		}

		this.keyGen = new KeyGenerator(this.dao);
		if (var9 != null) {
			try {
				var9.close();
			} catch (Exception var12) {
				;
			}
		}

		if (var8 != null) {
			try {
				var8.close();
			} catch (Exception var11) {
				;
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

	}

	private long updateKey(Connection var1, String var2, int var3) throws SQLException, NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateKey");
		}

		long var5 = -1L;
		long var7 = -1L;
		long var9 = -1L;
		long var11 = -1L;
		String var13 = this.dao.getQuerySet().selectDBKeysByTable;
		if (var3 == 2) {
			var13 = this.dao.getQuerySet().selectLAKeysByTable;
		}

		PreparedStatement var14 = var1.prepareStatement(var13);
		var14.setString(1, var2);
		ResultSet var15 = var14.executeQuery();
		if (!var15.next()) {
			throw new SQLException("Key not found");
		} else {
			var5 = var15.getLong("COUNTER");
			var7 = var15.getLong("PREFETCH_SIZE");
			if (var15 != null) {
				try {
					var15.close();
				} catch (Exception var27) {
					;
				}
			}

			if (var14 != null) {
				try {
					var14.close();
				} catch (Exception var26) {
					;
				}
			}

			var9 = var5 + var7;
			var11 = var9 + 1L;
			String var16 = this.dao.getQuerySet().updateDBKeysByTable;
			if (var3 == 2) {
				var16 = this.dao.getQuerySet().updateLAKeysByTable;
			}

			Object var17 = null;
			boolean var18 = false;
			this.txControl = this.jtaHelper.getTransactionControl(this.txControl, this.environmentManager);
			boolean var19 = this.jtaHelper.useTransaction(this.txControl, this.environmentManager);

			try {
				if (var19) {
					var17 = this.jtaHelper.preinvoke(this.txControl, false, true);
				}

				var9 = this.keyGen.updateKey(var16, var2, var11, var7);
				var18 = true;
			} catch (Exception var28) {
				if (trcLogger.isLoggable(Level.SEVERE)) {
					trcLogger.logp(Level.SEVERE, CLASSNAME, "updateKey", "", WIMMessageHelper.generateMsgParms(var28));
				}
			} finally {
				if (var19) {
					this.jtaHelper.closeTransaction("updateKey", this.txControl, var17, var18);
				}

			}

			long[] var20 = new long[]{var5, var9};
			if (var3 == 1) {
				this.dbKeys.put(var2, var20);
			} else if (var3 == 2) {
				this.laKeys.put(var2, var20);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				StringBuffer var21 = new StringBuffer();
				var21.append("Update Key: Query=").append(var16).append(", table=").append(var2).append(", nextValue=")
						.append(var11);
				trcLogger.logp(Level.FINER, CLASSNAME, "updateKey", var21.toString());
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "updateKey");
			}

			return var9;
		}
	}

	public void setSchema(String var1) {
		this.dbSchema = var1;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}