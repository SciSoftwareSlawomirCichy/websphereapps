package com.ibm.ws.wim.adapter.ldap;

import javax.naming.NamingException;
import javax.naming.ldap.Control;

public class PagedResultsControl implements Control {
	static final long serialVersionUID = -6415779103893000950L;
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public static final String OID = "1.2.840.113556.1.4.319";
	int pageSize;
	private int ASN_BOOL;
	private int ASN_INT;
	private int ASN_OCTETS;
	private int ASN_SEQ;
	private byte[] value;
	private byte[] cookie;
	private int resultSize;

	public PagedResultsControl(int var1) throws NamingException {
		this(var1, new byte[0]);
	}

	public PagedResultsControl(int var1, byte[] var2) throws NamingException {
		this.ASN_BOOL = 1;
		this.ASN_INT = 2;
		this.ASN_OCTETS = 4;
		this.ASN_SEQ = 48;
		this.pageSize = var1;
		this.cookie = var2;
		this.encode();
	}

	public PagedResultsControl(byte[] var1) throws NamingException {
		this.ASN_BOOL = 1;
		this.ASN_INT = 2;
		this.ASN_OCTETS = 4;
		this.ASN_SEQ = 48;
		this.value = var1;
		this.decode();
	}

	public String getID() {
		return "1.2.840.113556.1.4.319";
	}

	public byte[] getEncodedValue() {
		return this.value;
	}

	public boolean isCritical() {
		return true;
	}

	public byte[] getCookie() {
		return this.cookie.length == 0 ? new byte[0] : this.cookie;
	}

	private void encode() {
		byte[] var1 = new byte[this.cookie.length + 20];
		int var2 = var1.length - 1;
		var2 -= this.cookie.length;
		System.arraycopy(this.cookie, 0, var1, var2, this.cookie.length);
		--var2;
		var1[var2] = (byte) this.cookie.length;
		if (this.cookie.length > 127) {
			--var2;
			var1[var2] = (byte) (this.cookie.length >> 8);
			if (this.cookie.length > 32767) {
				--var2;
				var1[var2] = (byte) (this.cookie.length >> 16);
				--var2;
				var1[var2] = -125;
			} else {
				--var2;
				var1[var2] = -126;
			}
		}

		--var2;
		var1[var2] = (byte) this.ASN_OCTETS;
		--var2;
		var1[var2] = (byte) this.pageSize;
		int var3 = var2;
		if (this.pageSize > 127) {
			--var2;
			var1[var2] = (byte) (this.pageSize >> 8);
		}

		if (this.pageSize > 32767) {
			--var2;
			var1[var2] = (byte) (this.pageSize >> 16);
		}

		--var2;
		var1[var2] = (byte) (var3 - var2);
		--var2;
		var1[var2] = (byte) this.ASN_INT;
		int var4 = var1.length - 1 - var2;
		--var2;
		var1[var2] = (byte) var4;
		if (var4 > 127) {
			--var2;
			var1[var2] = (byte) (var4 >> 8);
			if (var4 > 32767) {
				--var2;
				var1[var2] = (byte) (var4 >> 16);
				--var2;
				var1[var2] = -125;
			} else {
				--var2;
				var1[var2] = -126;
			}
		}

		--var2;
		var1[var2] = (byte) this.ASN_SEQ;
		this.value = new byte[var1.length - 1 - var2];
		System.arraycopy(var1, var2, this.value, 0, this.value.length);
	}

	private void decode() throws NamingException {
		byte var1 = 0;
		int var4 = var1 + 1;
		if (this.value[var1] != this.ASN_SEQ) {
			throw new NamingException("Illegal PagedResultsControl value");
		} else {
			int var2 = this.value[var4++] & 255;
			if (var2 > 127) {
				var4 += var2 - 128;
			}

			if (this.value[var4++] != this.ASN_INT) {
				throw new NamingException("Illegal PagedResultsControl value");
			} else {
				var2 = this.value[var4++] & 255;
				if (var2 > 4) {
					throw new NamingException("Illegal PagedResultsControl value");
				} else {
					for (this.pageSize = 0; var2-- > 0; this.pageSize = (this.pageSize << 8)
							+ (this.value[var4++] & 255)) {
						;
					}

					if (this.value[var4++] != this.ASN_OCTETS) {
						throw new NamingException("Illegal PagedResultsControl value");
					} else {
						var2 = this.value[var4++] & 255;
						if (var2 > 127) {
							int var3 = var2 - 128;

							for (var2 = 0; var3-- > 0; var2 = (var2 << 8) + (this.value[var4++] & 255)) {
								;
							}
						}

						this.cookie = new byte[var2];
						System.arraycopy(this.value, var4, this.cookie, 0, this.cookie.length);
					}
				}
			}
		}
	}

	public int getResultSize() {
		return this.resultSize;
	}
}