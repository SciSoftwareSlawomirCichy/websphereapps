package com.ibm.ejs.deployment;

import java.lang.reflect.Method;

public class DeploymentUtil {
	public static String methodKey(Method m) {
		return com.ibm.ejs.container.util.DeploymentUtil.methodKey(m);
	}

	public static Method[] getAllMethods(Class intf) {
		return com.ibm.ejs.container.util.DeploymentUtil.getAllMethods(intf);
	}

	public static Method[] getMethods(Class intf) {
		return com.ibm.ejs.container.util.DeploymentUtil.getMethods(intf);
	}
}