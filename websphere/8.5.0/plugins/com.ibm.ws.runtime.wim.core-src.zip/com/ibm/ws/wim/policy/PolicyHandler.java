package com.ibm.ws.wim.policy;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.ChangePasswordAfterResetException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.adapter.ldap.PasswordPolicyRequestControl;
import com.ibm.ws.wim.adapter.ldap.PasswordPolicyResponseControl;
import com.ibm.ws.wim.adapter.ldap.ResponseControlFactory;
import com.ibm.wsspi.wim.adapter.ldap.GenericLdapPolicyHandler;
import commonj.sdo.DataObject;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.ldap.Control;
import javax.naming.ldap.LdapContext;

public class PolicyHandler extends GenericLdapPolicyHandler {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static ResponseControlFactory responseCtrlFactObj;

	public PolicyHandler() {
		responseCtrlFactObj = new ResponseControlFactory();
	}

	public DataObject loginPreProcess(DirContext var1, DataObject var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "loginPreProcess", WIMTraceHelper.printDataObject(var2));
		}

		Control[] var5 = new Control[]{new PasswordPolicyRequestControl()};

		try {
			((LdapContext) var1).setRequestControls(var5);
		} catch (NamingException var8) {
			String var7 = var8.toString(true);
			if (trcLogger.isLoggable(Level.SEVERE)) {
				trcLogger.logp(Level.SEVERE, CLASSNAME, "loginPreProcess", var7, var8);
			}

			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var7), Level.SEVERE,
					CLASSNAME, "loginPreProcess");
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "loginPreProcess",
					" returning DataObject: " + WIMTraceHelper.printDataObject(var2));
		}

		return var2;
	}

	public DataObject loginPostProcess(DirContext var1, DataObject var2, NamingException var3)
			throws NamingException, WIMException {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "loginPostProcess", WIMTraceHelper.printDataObject(var2));
		}

		String var6 = null;
		if (var3 != null && var1 != null) {
			var6 = this.getMessageKeyFromResponseCtl((LdapContext) var1);
			String var7 = var3.toString();
			if (trcLogger.isLoggable(Level.SEVERE)) {
				trcLogger.logp(Level.SEVERE, CLASSNAME, "loginPostProcess", var7, var3);
			}

			if (var6 != null) {
				if ("CHANGE_PWD_AFTER_RESET".equals(var6)) {
					throw new ChangePasswordAfterResetException("CHANGE_PWD_AFTER_RESET", Level.SEVERE, CLASSNAME,
							"loginPostProcess");
				} else {
					throw var3;
				}
			} else {
				throw var3;
			}
		} else {
			if (var5) {
				trcLogger.exiting(CLASSNAME, "loginPostProcess",
						" returning DataObject: " + WIMTraceHelper.printDataObject(var2));
			}

			return var2;
		}
	}

	protected String getMessageKeyFromResponseCtl(LdapContext var1) throws WIMException {
		String var2 = "getMessageKeyFromResponseCtl";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2);
		}

		Control[] var3 = null;
		String var4 = null;

		try {
			var3 = var1.getResponseControls();
		} catch (NamingException var11) {
			if (trcLogger.isLoggable(Level.SEVERE)) {
				trcLogger.logp(Level.SEVERE, CLASSNAME, var2, var11.toString(true), var11);
			}

			var4 = WIMMessageHelper.generateMsgParms(var11.toString(true)).toString();
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var11.toString(true)),
					Level.SEVERE, CLASSNAME, var2);
		} finally {
			this.cleanControls(var1);
		}

		PasswordPolicyResponseControl var5 = null;

		int var6;
		for (var6 = 0; var3 != null && var6 < var3.length; ++var6) {
			if (var3[var6].getID().equals("1.3.6.1.4.1.42.2.27.8.5.1")) {
				try {
					var5 = (PasswordPolicyResponseControl) responseCtrlFactObj.getControlInstance(var3[var6]);
				} catch (NamingException var13) {
					if (trcLogger.isLoggable(Level.SEVERE)) {
						trcLogger.logp(Level.SEVERE, CLASSNAME, var2, var13.toString(true), var13);
					}
				}
				break;
			}
		}

		if (var5 != null) {
			var6 = var5.getError();
			if (var6 == -1) {
				var4 = null;
			} else {
				var4 = this.getVMMError((new Integer(var6)).toString());
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var2);
		}

		return var4;
	}

	protected void cleanControls(DirContext var1) throws WIMException {
		String var2 = "cleanControls";

		try {
			((LdapContext) var1).setRequestControls((Control[]) null);
		} catch (NamingException var4) {
			if (trcLogger.isLoggable(Level.SEVERE)) {
				trcLogger.logp(Level.SEVERE, CLASSNAME, var2, var4.toString(true), var4);
			}

			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var4.toString(true)),
					Level.SEVERE, CLASSNAME, var2);
		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2014;
		CLASSNAME = PolicyHandler.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		responseCtrlFactObj = null;
	}
}