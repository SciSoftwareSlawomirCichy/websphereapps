package com.ibm.icu.text;

import com.ibm.icu.text.CharsetRecog_mbcs.iteratedChar;
import java.util.Arrays;

abstract class CharsetRecog_mbcs extends CharsetRecognizer {
	abstract String getName();

	int match(CharsetDetector det, int[] commonChars) {
		int singleByteCharCount = 0;
		int doubleByteCharCount = 0;
		int commonCharCount = 0;
		int badCharCount = 0;
		int totalCharCount = 0;
		int confidence = 0;
		iteratedChar iter = new iteratedChar();
		iter.reset();

		do {
			if (!this.nextChar(iter, det)) {
				if (doubleByteCharCount <= 10 && badCharCount == 0) {
					if (doubleByteCharCount == 0 && totalCharCount < 10) {
						confidence = 0;
					} else {
						confidence = 10;
					}
					break;
				}

				if (doubleByteCharCount < 20 * badCharCount) {
					confidence = 0;
				} else if (commonChars == null) {
					confidence = 30 + doubleByteCharCount - 20 * badCharCount;
					if (confidence > 100) {
						confidence = 100;
					}
				} else {
					double maxVal = Math.log((double) ((float) doubleByteCharCount / 4.0F));
					double scaleFactor = 90.0D / maxVal;
					confidence = (int) (Math.log((double) (commonCharCount + 1)) * scaleFactor + 10.0D);
					confidence = Math.min(confidence, 100);
				}
				break;
			}

			++totalCharCount;
			if (iter.error) {
				++badCharCount;
			} else {
				long cv = (long) iter.charValue & 4294967295L;
				if (cv <= 255L) {
					++singleByteCharCount;
				} else {
					++doubleByteCharCount;
					if (commonChars != null && Arrays.binarySearch(commonChars, (int) cv) >= 0) {
						++commonCharCount;
					}
				}
			}
		} while (badCharCount < 2 || badCharCount * 5 < doubleByteCharCount);

		return confidence;
	}

	abstract boolean nextChar(iteratedChar var1, CharsetDetector var2);
}