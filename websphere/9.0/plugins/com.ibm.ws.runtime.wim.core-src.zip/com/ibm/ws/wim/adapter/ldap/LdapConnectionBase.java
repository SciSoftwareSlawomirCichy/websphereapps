package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.SchemaConstants;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.ws.wim.FactoryManager;
import java.util.Hashtable;

public class LdapConnectionBase implements ConfigConstants, SchemaConstants, LdapConstants {
	protected String iSSLFactory = null;
	public static final String WIM_SSL_SOCKE_FACTORY = "com.ibm.ws.security.registry.ldap.LdapSSLSocketFactory";
	public static final String JNDI_CALL = "JNDI_CALL ";
	public static final String WAS_SSL_SOCKE_FACTORY = "com.ibm.websphere.ssl.protocol.SSLSocketFactory";

	public static void setWASSSLAlias(String var0, Hashtable var1) throws WIMConfigurationException {
		FactoryManager.getSSLUtil().setSSLAlias(var0, var1);
	}

	public static void resetWASSSLAlias() {
		FactoryManager.getSSLUtil().resetSSLAlias();
	}
}