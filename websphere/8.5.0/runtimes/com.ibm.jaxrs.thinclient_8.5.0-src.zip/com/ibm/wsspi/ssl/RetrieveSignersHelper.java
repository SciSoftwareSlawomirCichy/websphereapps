package com.ibm.wsspi.ssl;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.ws.ssl.config.ThreadManager;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider;
import java.lang.reflect.Method;

public class RetrieveSignersHelper {
	private static RetrieveSignersHelper thisClass = null;
	private static Class cl1 = null;
	private static final TraceComponent tc = Tr.register(RetrieveSignersHelper.class, "SSL",
			"com.ibm.ws.ssl.resources.ssl");

	public static void main(String[] args) {
		new RetrieveSignersHelper();
		System.exit(getInstance().callRetrieveSigners(args));
	}

	public static RetrieveSignersHelper getInstance() {
		if (thisClass == null) {
			thisClass = new RetrieveSignersHelper();
		}

		return thisClass;
	}

	public int callRetrieveSigners(String[] args) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "callRetrieveSigners", new Object[]{args});
		}

		try {
			if (cl1 == null) {
				cl1 = Class.forName("com.ibm.ws.ssl.utils.RetrieveSigners");
			}

			if (cl1 != null) {
				Method theMethod1 = cl1.getMethod("mainForInProcess", String[].class);
				Integer result = (Integer) theMethod1.invoke((Object) null, args);
				AbstractJSSEProvider.clearSSLContextCache();
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "callRetrieveSigners");
				}

				return result;
			} else {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "callRetrieveSigners (could not load class.)");
				}

				return 1;
			}
		} catch (Exception var4) {
			Manager.Ffdc.log(var4, this, "com.ibm.wsspi.ssl.RetrieveSigners.callRetrieveSigners", "145",
					new Object[]{this});
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "RetreiveSigners did not execute.", new Object[]{var4});
			}

			return 1;
		}
	}

	public void autoAcceptSignerForThisConnectionOnly() {
		ThreadManager.getInstance().setAutoAcceptBootstrapSignerWithoutStorage(true);
	}

	public void autoAcceptSignerAndStoreInTrustStore() {
		ThreadManager.getInstance().setAutoAcceptBootstrapSigner(true);
	}
}