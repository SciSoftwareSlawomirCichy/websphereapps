package com.ibm.ejs.container;

import com.ibm.ejs.container.PersistentTimerTaskHandler.1;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.ejs.util.dopriv.GetContextClassLoaderPrivileged;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.TransactionAttribute;
import com.ibm.ws.ejb.portable.Constants;
import com.ibm.ws.ejbcontainer.runtime.EJBRuntime;
import com.ibm.ws.ejbcontainer.util.ParsedScheduleExpression;
import com.ibm.ws.ejbcontainer.util.ScheduleExpressionParser;
import com.ibm.ws.ffdc.FFDCFilter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.Arrays;
import java.util.Date;
import javax.ejb.EJBException;

public abstract class PersistentTimerTaskHandler implements Runnable, Serializable {
	private static final TraceComponent tc = Tr.register(PersistentTimerTaskHandler.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = PersistentTimerTaskHandler.class.getName();
	private static final long serialVersionUID = -8200752857441853748L;
	private static final byte[] EYECATCHER;
	private static final short PLATFORM = 1;
	protected transient J2EEName j2eeName;
	protected transient int methodId;
	private transient String automaticMethodName;
	private transient String automaticClassName;
	private transient byte[] userInfoBytes;
	protected transient long expiration;
	protected transient long interval;
	protected transient ParsedScheduleExpression parsedSchedule;

	private PersistentTimerTaskHandler(J2EEName j2eeName, Serializable info) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>: " + j2eeName + ", " + Util.identity(info));
		}

		this.j2eeName = j2eeName;
		this.userInfoBytes = serializeObject(info);
	}

	protected PersistentTimerTaskHandler(J2EEName j2eeName, Serializable info, Date expiration, long interval) {
		this(j2eeName, info);
		this.expiration = expiration.getTime();
		this.interval = interval;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>: " + this);
		}

	}

	protected PersistentTimerTaskHandler(J2EEName j2eeName, Serializable info,
			ParsedScheduleExpression parsedSchedule) {
		this(j2eeName, info);
		this.parsedSchedule = parsedSchedule;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>: " + this);
		}

	}

	protected PersistentTimerTaskHandler(J2EEName j2eeName, Serializable info, ParsedScheduleExpression parsedSchedule,
			int methodId, String methodName, String className) {
		this(j2eeName, info);
		this.parsedSchedule = parsedSchedule;
		this.methodId = methodId;
		this.automaticMethodName = methodName;
		this.automaticClassName = className;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>: " + this);
		}

	}

	public void run() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "run: " + this);
		}

		EJSHome home;
		try {
			home = EJSContainer.getDefaultContainer().getInstalledHome(this.j2eeName);
			if (home.beanMetaData.timedMethodInfos == null) {
				Tr.warning(tc, "HOME_NOT_FOUND_CNTR0092W", this.j2eeName);
				throw new EJBNotFoundException(
						"Incompatible Application Change: " + this.j2eeName + " no longer supports timers.");
			}
		} catch (EJBNotFoundException var9) {
			FFDCFilter.processException(var9, CLASS_NAME + ".run", "305", this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "run: Failed locating timer bean " + this.j2eeName + " : " + var9);
			}

			throw new TimerServiceException("Failed locating timer bean " + this.j2eeName, var9);
		}

		if (this.automaticMethodName != null && !this.validateAutomaticTimer(home.beanMetaData)) {
			Tr.error(tc, "AUTOMATIC_TIMER_VALIDATION_FAILED_CNTR0301E", new Object[]{this.j2eeName.getComponent(),
					this.j2eeName.getModule(), this.j2eeName.getApplication(), this.automaticMethodName});
			throw new EJBException("CNTR0220I: The " + this.j2eeName.getComponent() + " enterprise bean in the "
					+ this.j2eeName.getModule() + " module of the " + this.j2eeName.getApplication()
					+ " application has an automatic timer for the " + this.automaticMethodName
					+ " method, but an incompatible change was made to the application since the server created the timer.");
		} else {
			PersistentTimer timer = this.createTimer(home.container.getEJBRuntime());
			TimedObjectWrapper timedObject = home.getTimedObjectWrapper(home.ivStatelessId);

			try {
				timer.isTimeoutCallback = true;
				boolean runInGlobalTx = runInGlobalTransaction(timedObject.methodInfos[this.methodId]);
				timedObject.invokeCallback(timer, this.methodId, runInGlobalTx);
			} finally {
				timer.isTimeoutCallback = false;
				home.putTimedObjectWrapper(timedObject);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "run: " + this);
				}

			}

		}
	}

	protected abstract PersistentTimer createTimer(EJBRuntime var1);

	private boolean validateAutomaticTimer(BeanMetaData bmd) {
		if (bmd.timedMethodInfos != null && this.methodId <= bmd.timedMethodInfos.length) {
			Method method = bmd.timedMethodInfos[this.methodId].ivMethod;
			if (!method.getName().equals(this.automaticMethodName)) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "validateAutomaticTimer: ivAutomaticMethodName=" + this.automaticMethodName + " != "
							+ method.getName());
				}

				return false;
			} else if (this.automaticClassName != null
					&& !this.automaticClassName.equals(method.getDeclaringClass().getName())) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "validateAutomaticTimer: ivAutomaticClassName=" + this.automaticClassName + " != "
							+ method.getDeclaringClass().getName());
				}

				return false;
			} else {
				return true;
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "validateAutomaticTimer: ivMethodId=" + this.methodId + " > "
						+ Arrays.toString(bmd.timedMethodInfos));
			}

			return false;
		}
	}

	protected boolean isAutomaticTimer() {
		return this.automaticMethodName != null;
	}

	public String getAutomaticTimerMethodName() {
		return this.automaticMethodName;
	}

	public Serializable getUserInfo() throws TimerServiceException {
      if (this.userInfoBytes == null) {
         if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
            Tr.debug(tc, "getUserInfo: null");
         }

         return null;
      } else {
         Serializable userInfo = null;

         TimerServiceException ex;
         try {
            ClassLoader loader = EJSContainer.getClassLoader(this.j2eeName);
            if (loader == null) {
               loader = (ClassLoader)AccessController.doPrivileged(new GetContextClassLoaderPrivileged());
            }

            ByteArrayInputStream bais = new ByteArrayInputStream(this.userInfoBytes);
            EJBRuntime ejbRuntime = EJSContainer.getDefaultContainer().getEJBRuntime();
            ObjectInputStream objIstream = ejbRuntime.createObjectInputStream(bais, loader);
            userInfo = (Serializable)AccessController.doPrivileged(new 1(this, objIstream));
         } catch (PrivilegedActionException var6) {
            ex = new TimerServiceException("Failure deserializing timer info object.", var6.getException());
            if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
               Tr.debug(tc, "getUserInfo: " + ex);
            }

            throw ex;
         } catch (IOException var7) {
            FFDCFilter.processException(var7, CLASS_NAME + ".getUserInfo", "406");
            ex = new TimerServiceException("Failure deserializing timer info object.", var7);
            if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
               Tr.debug(tc, "getUserInfo: " + ex);
            }

            throw ex;
         }

         if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
            Tr.debug(tc, "getUserInfo: " + Util.identity(userInfo));
         }

         return userInfo;
      }
   }

	public abstract Date getNextTimeout(Date var1, Date var2);

	public ParsedScheduleExpression getParsedSchedule() {
		return this.parsedSchedule;
	}

	public J2EEName getJ2EEName() {
		return this.j2eeName;
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "writeObject: " + this);
		}

		int version = 1;
		if (this.parsedSchedule != null) {
			version = 2;
		}

		out.defaultWriteObject();
		out.write(EYECATCHER);
		out.writeShort(1);
		out.writeShort(version);
		out.writeObject(this.j2eeName.getBytes());
		out.writeObject(this.userInfoBytes);
		switch (version) {
			case 1 :
				out.writeLong(this.expiration);
				out.writeLong(this.interval);
				break;
			case 2 :
				out.writeObject(this.parsedSchedule);
				out.writeInt(this.methodId);
				out.writeObject(this.automaticMethodName);
				out.writeObject(this.automaticClassName);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "writeObject");
		}

	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "readObject");
		}

		in.defaultReadObject();
		byte[] eyeCatcher = new byte[EYECATCHER.length];
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < EYECATCHER.length; i += bytesRead) {
			bytesRead = in.read(eyeCatcher, i, EYECATCHER.length - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < EYECATCHER.length; ++i) {
			if (EYECATCHER[i] != eyeCatcher[i]) {
				String eyeCatcherString = new String(eyeCatcher);
				throw new IOException("Invalid eye catcher '" + eyeCatcherString + "' in TimerHandle input stream");
			}
		}

		short incoming_platform = in.readShort();
		short incoming_vid = in.readShort();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "version = " + incoming_vid);
		}

		if (incoming_vid != 1 && incoming_vid != 2) {
			throw new InvalidObjectException(
					"EJB TimerTaskHandler data stream is not of the correct version, this client should be updated.");
		} else {
			byte[] j2eeNameBytes = (byte[]) ((byte[]) in.readObject());
			this.j2eeName = EJSContainer.j2eeNameFactory.create(j2eeNameBytes);
			this.userInfoBytes = (byte[]) ((byte[]) in.readObject());
			switch (incoming_vid) {
				case 1 :
					this.expiration = in.readLong();
					this.interval = in.readLong();
					break;
				case 2 :
					this.parsedSchedule = (ParsedScheduleExpression) in.readObject();
					this.methodId = in.readInt();
					this.automaticMethodName = (String) in.readObject();
					this.automaticClassName = (String) in.readObject();
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "readObject: " + this);
			}

		}
	}

	protected static boolean runInGlobalTransaction(EJBMethodInfoImpl methodInfo) {
		return methodInfo.getTransactionAttribute() == TransactionAttribute.TX_REQUIRED;
	}

	protected BeanMetaData getBeanMetaData() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getBeanMetaData: " + this);
		}

		EJSHome home;
		try {
			home = EJSContainer.getDefaultContainer().getInstalledHome(this.j2eeName);
			if (home.beanMetaData.timedMethodInfos == null) {
				Tr.warning(tc, "HOME_NOT_FOUND_CNTR0092W", this.j2eeName);
				throw new EJBNotFoundException(
						"Incompatible Application Change: " + this.j2eeName + " no longer supports timers.");
			}
		} catch (EJBNotFoundException var4) {
			FFDCFilter.processException(var4, CLASS_NAME + ".getBeanMetaData", "635", this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getBeanMetaData: Failed locating timer bean " + this.j2eeName + " : " + var4);
			}

			throw new TimerServiceException("Failed locating timer bean " + this.j2eeName, var4);
		}

		BeanMetaData bmd = home.beanMetaData;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getBeanMetaData: " + bmd);
		}

		return bmd;
	}

	private static byte[] serializeObject(Object obj) {
		if (obj == null) {
			return null;
		} else {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			try {
				ObjectOutputStream out = new ObjectOutputStream(baos);
				out.writeObject(obj);
				out.flush();
			} catch (IOException var3) {
				throw new EJBException("Timer info object failed to serialize.", var3);
			}

			return baos.toByteArray();
		}
	}

	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getSimpleName()).append("(");
		builder.append(this.j2eeName).append(", ");
		if (this.parsedSchedule == null) {
			builder.append(new Date(this.expiration)).append(", ").append(this.interval);
		} else {
			builder.append(this.methodId).append(", ");
			builder.append(ScheduleExpressionParser.toString(this.parsedSchedule.getSchedule()));
		}

		builder.append(")");
		return builder.toString();
	}

	static {
		EYECATCHER = Constants.TIMER_TASK_EYE_CATCHER;
	}
}