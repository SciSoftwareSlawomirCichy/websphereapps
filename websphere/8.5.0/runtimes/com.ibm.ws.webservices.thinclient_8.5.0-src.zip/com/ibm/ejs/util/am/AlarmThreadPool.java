package com.ibm.ejs.util.am;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.util.ThreadPool;

class AlarmThreadPool extends ThreadPool {
	private static final TraceComponent tc = Tr.register(AlarmThreadPool.class, "RuntimeUtils",
			"com.ibm.ws.utils.resources.nls.UtilsMessages");
	private static final String svClassName = AlarmThreadPool.class.getName();
	private static final String THRESHOLD_CUSTOM_PROPERTY_NAME = "com.ibm.websphere.alarmthreadmonitor.threshold.millis";
	private static final String DEFAULT_THRESHOLD_VALUE = "10000";
	private static boolean svCustomPropertyPreviouslyLogged = false;
	private static int minPoolSize = Integer.getInteger("com.ibm.ejs.util.am.AlarmThreadPool.minPoolSize", 1);
	private static int maxPoolSize = Integer.getInteger("com.ibm.ejs.util.am.AlarmThreadPool.maxPoolSize",
			Math.max(4, Runtime.getRuntime().availableProcessors() / 2));
	private static int idleTimeout = 90000;
	private static final String svThresholdProperty = System
			.getProperty("com.ibm.websphere.alarmthreadmonitor.threshold.millis");

	AlarmThreadPool() {
		super("Alarm", minPoolSize, maxPoolSize);
		this.setKeepAliveTime((long) idleTimeout);
		this.disableBufferLimitReachedLogging();

		try {
			new AlarmThreadMonitor(this, this.getHungAlarmThreadThresholdMillis());
		} catch (Throwable var2) {
			Tr.debug(tc, "Alarm threadPool monitoring not supported", var2);
		}

		svCustomPropertyPreviouslyLogged = true;
	}

	AlarmThreadPool(String threadPoolName) {
		super(threadPoolName, minPoolSize, maxPoolSize);
		this.setKeepAliveTime((long) idleTimeout);
		this.disableBufferLimitReachedLogging();

		try {
			new AlarmThreadMonitor(this, this.getHungAlarmThreadThresholdMillis());
		} catch (Throwable var3) {
			Tr.debug(tc, "Alarm threadPool monitoring not supported", var3);
		}

		svCustomPropertyPreviouslyLogged = true;
	}

	private long getHungAlarmThreadThresholdMillis() {
		Long thresholdValue;
		if (svThresholdProperty == null) {
			thresholdValue = new Long("10000");
		} else {
			try {
				thresholdValue = new Long(svThresholdProperty);
			} catch (NumberFormatException var3) {
				if (!svCustomPropertyPreviouslyLogged) {
					Tr.info(tc, "UTLS0012");
				}

				thresholdValue = new Long("10000");
			}

			if (thresholdValue >= 0L && thresholdValue <= 600000L) {
				if (!svCustomPropertyPreviouslyLogged) {
					Tr.info(tc, "UTLS0010", new Object[]{thresholdValue});
				}
			} else if (!svCustomPropertyPreviouslyLogged) {
				Tr.info(tc, "UTLS0012");
			}
		}

		return thresholdValue;
	}
}