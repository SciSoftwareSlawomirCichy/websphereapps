package com.ibm.ws.ffdc.impl;

import com.ibm.ffdc.config.Formattable;
import com.ibm.ffdc.util.provider.FfdcSummaryProvider;
import com.ibm.ffdc.util.provider.Incident;
import com.ibm.ffdc.util.provider.IncidentEntry;
import com.ibm.ffdc.util.provider.IncidentLogger;
import com.ibm.ws.exception.WsException;
import com.ibm.ws.ffdc.FFDC;
import com.ibm.ws.ffdc.impl.FfdcProvider.1;
import com.ibm.ws.security.util.ServerIdentityHelper;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.AccessController;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class FfdcProvider extends FfdcSummaryProvider implements com.ibm.ffdc.provider.FfdcProvider {
	private ConfigurationHelper configurationHelper;
	private WrappingFileOutputStream incidentSummaryStream;
	private static final String FFDC_SUFFIX = ".txt";
	private static final String thisClass = FfdcProvider.class.getName();
	private static final Logger logger = Logger.getLogger("com.ibm.ws.ffdc.impl.FfdcProviders");
	private static final Logger LOGGER;
	private static final boolean increaseMessageSeverity;
	private static final Level incidentCreatedLevel;
	private final byte[] truncateString = "..FFDC report truncated".getBytes();
	private static long lastTimeOfDump;
	private static int numberOfEntiesProcessed;
	private static final long lowWaterTime = 60000L;
	private static final int normalDumpThreshold = 10;
	private static final long highWaterTime = 300000L;

	public FfdcProvider() {
		this.getConfigurationHelper();
	}

	public synchronized Configure getConfiguration() {
		return this.getConfigurationHelper().getConfiguration();
	}

	protected final boolean isLoggable(IncidentEntry incident) {
		return super.isLoggable(incident) && this.getConfigurationHelper().hasPermissionForLogging();
	}

	private synchronized ConfigurationHelper getConfigurationHelper() {
		if (this.configurationHelper == null) {
			this.configurationHelper = new ConfigurationHelper(this);
		}

		return this.configurationHelper;
	}

	protected void logIncident(IncidentEntry incident, Object reporter, Throwable th, List<Formattable> data) {
		IncidentLogger<FfdcProvider> incidentLogger = new IncidentLogger(this);
		this.logIncident(incidentLogger, incident, reporter, th, data);
	}

	protected void logSummary() {
		IncidentLogger<FfdcProvider> incidentLogger = new IncidentLogger(this);
		this.logSummary(incidentLogger);
	}

	protected void logIncident(IncidentLogger<FfdcProvider> incidentLogger, IncidentEntry incident, Object reporter, Throwable th, List<Formattable> data) {
      FFDCJanitor.getInstance().doCleanupIfNeeded();
      String prefix = FFDCHelper.generateFilename(Integer.toHexString(Thread.currentThread().hashCode()));

      String dirpath;
      try {
         dirpath = FFDCHelper.getDefaultLoggingDirectory();
      } catch (WsException var30) {
         this.abort(var30);
         return;
      }

      FixedCapacityStream os = new FixedCapacityStream();
      File[] aF = new File[]{null};
      ServerIdentityHelper sih = FFDC.isZos() ? ServerIdentityHelper.getServerIdentityHelper() : null;
      Object credToken = null;

      FileOutputStream out;
      label157: {
         try {
            if (sih != null) {
               sih = ServerIdentityHelper.getServerIdentityHelper();
               credToken = sih.push();
            }

            out = (FileOutputStream)AccessController.doPrivileged(new 1(this, aF, prefix, dirpath));
            break label157;
         } catch (Exception var31) {
            this.abort(var31);
         } finally {
            try {
               if (sih != null) {
                  sih.pop(credToken);
               }
            } catch (Exception var26) {
               this.abort(var26);
            }

         }

         return;
      }

      String incidentFile = aF[0].getAbsolutePath();
      os.reset(this.getMaxIncidentSize() - this.truncateString.length);

      try {
         IncidentStream is = new IncidentStream(this, os);
         incidentLogger.writeIncidentTo(is, incident, reporter, th, data);
         is.release();
         incident.setLabel(incidentFile);
         os.writeTo(out);
      } catch (IOException var29) {
         this.ffdcerror(var29);
      }

      if (os.isTruncated) {
         try {
            out.write(this.truncateString);
         } catch (IOException var28) {
            this.ffdcerror(var28);
         }

         logger.log(Level.FINEST, "Truncated FFDC Incident emitted " + incidentFile);
      }

      LOGGER.logp(incidentCreatedLevel, FfdcProvider.class.getName(), "logIncident", "FFDCIncidentEmitted", new Object[]{incidentFile, incident.getSourceId(), incident.getProbeId()});

      try {
         if (out != null) {
            out.flush();
            out.close();
         }
      } catch (IOException var27) {
         this.ffdcerror(var27);
      }

   }

	protected void log(IncidentEntry incident, Object reporter, Throwable th, Object[] cde) throws Exception {
		if (cde != null && cde.length == 1 && cde[0] instanceof DMAdapter) {
			super.log(incident, reporter, th, (DMAdapter) cde[0]);
		} else {
			super.log(incident, reporter, th, cde);
		}

	}

	private synchronized void logSummary(IncidentLogger<FfdcProvider> incidentLogger) {
		long currentTime = System.currentTimeMillis();
		List<Incident> incidents = this.getIncidents();
		if (dumpAlgorithm(currentTime)) {
			WrappingFileOutputStream ws;
			try {
				ws = this.getIncidentSummaryStream();
				ws.getChanel().truncate(0L);
			} catch (WsException var7) {
				this.abort(var7);
				return;
			} catch (IOException var8) {
				this.abort(var8);
				return;
			}

			incidentLogger.logIncidentSummary(ws, incidents);
		}
	}

	private WrappingFileOutputStream getIncidentSummaryStream() throws WsException, IOException {
		if (this.incidentSummaryStream != null) {
			return this.incidentSummaryStream;
		} else {
			this.incidentSummaryStream = this.getConfigurationHelper().getIncidentSummaryStream();
			return this.incidentSummaryStream;
		}
	}

	private static boolean dumpAlgorithm(long currentTime) {
		boolean dumpTable = false;
		++numberOfEntiesProcessed;
		if (currentTime - lastTimeOfDump > 300000L) {
			dumpTable = true;
		} else if (numberOfEntiesProcessed > 10 && currentTime - lastTimeOfDump > 60000L) {
			dumpTable = true;
		}

		if (dumpTable) {
			lastTimeOfDump = currentTime;
			numberOfEntiesProcessed = 0;
		}

		return dumpTable;
	}

	private int getMaxIncidentSize() {
		int filesize = false;
		int filesize = this.getConfigurationHelper().getFfdcSize();
		return filesize;
	}

	static {
		LOGGER = Logger.getLogger(thisClass, "com.ibm.ws.ffdc.resources.FFDCMessages");
		increaseMessageSeverity = !"false"
				.equalsIgnoreCase(System.getProperty("com.ibm.ws.ffdc.IncreaseMessageSeverity"));
		incidentCreatedLevel = increaseMessageSeverity ? Level.WARNING : Level.INFO;
		lastTimeOfDump = 0L;
		numberOfEntiesProcessed = 0;
	}
}