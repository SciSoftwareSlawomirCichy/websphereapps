package org.apache.http.conn.params;

@Deprecated
public interface ConnConnectionPNames {

	String MAX_STATUS_LINE_GARBAGE = "http.connection.max-status-line-garbage";
}