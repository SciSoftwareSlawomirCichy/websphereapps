package com.ibm.icu.text;

import com.ibm.icu.impl.ICUConfig;
import com.ibm.icu.impl.UCharacterProperty;
import com.ibm.icu.impl.Utility;
import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.math.MathContext;
import com.ibm.icu.text.DecimalFormat.AffixForCurrency;
import com.ibm.icu.text.NumberFormat.Field;
import com.ibm.icu.util.Currency;
import com.ibm.icu.util.CurrencyAmount;
import com.ibm.icu.util.ULocale;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.AttributedCharacterIterator;
import java.text.AttributedString;
import java.text.ChoiceFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class DecimalFormat extends NumberFormat {
	private static double epsilon = 1.0E-11D;
	private static final int CURRENCY_SIGN_COUNT_IN_SYMBOL_FORMAT = 1;
	private static final int CURRENCY_SIGN_COUNT_IN_ISO_FORMAT = 2;
	private static final int CURRENCY_SIGN_COUNT_IN_PLURAL_FORMAT = 3;
	private static final int STATUS_INFINITE = 0;
	private static final int STATUS_POSITIVE = 1;
	private static final int STATUS_UNDERFLOW = 2;
	private static final int STATUS_LENGTH = 3;
	private static final UnicodeSet dotEquivalents = (new UnicodeSet(
			new int[]{46, 46, 8228, 8228, 12290, 12290, 65042, 65042, 65106, 65106, 65294, 65294, 65377, 65377}))
					.freeze();
	private static final UnicodeSet commaEquivalents = (new UnicodeSet(new int[]{44, 44, 1548, 1548, 1643, 1643, 12289,
			12289, 65040, 65041, 65104, 65105, 65292, 65292, 65380, 65380})).freeze();
	private static final UnicodeSet strictDotEquivalents = (new UnicodeSet(
			new int[]{46, 46, 8228, 8228, 65106, 65106, 65294, 65294, 65377, 65377})).freeze();
	private static final UnicodeSet strictCommaEquivalents = (new UnicodeSet(
			new int[]{44, 44, 1643, 1643, 65040, 65040, 65104, 65104, 65292, 65292})).freeze();
	private static final UnicodeSet defaultGroupingSeparators = (new UnicodeSet(new int[]{32, 32, 39, 39, 44, 44, 46,
			46, 160, 160, 1548, 1548, 1643, 1644, 8192, 8202, 8216, 8217, 8228, 8228, 8239, 8239, 8287, 8287, 12288,
			12290, 65040, 65042, 65104, 65106, 65287, 65287, 65292, 65292, 65294, 65294, 65377, 65377, 65380, 65380}))
					.freeze();
	private static final UnicodeSet strictDefaultGroupingSeparators = (new UnicodeSet(new int[]{32, 32, 39, 39, 44, 44,
			46, 46, 160, 160, 1643, 1644, 8192, 8202, 8216, 8217, 8228, 8228, 8239, 8239, 8287, 8287, 12288, 12288,
			65040, 65040, 65104, 65104, 65106, 65106, 65287, 65287, 65292, 65292, 65294, 65294, 65377, 65377}))
					.freeze();
	private static final UnicodeSet EMPTY_SET = (new UnicodeSet()).freeze();
	private static final int PARSE_MAX_EXPONENT = 1000;
	static final double roundingIncrementEpsilon = 1.0E-9D;
	private transient DigitList digitList = new DigitList();
	private String positivePrefix = "";
	private String positiveSuffix = "";
	private String negativePrefix = "-";
	private String negativeSuffix = "";
	private String posPrefixPattern;
	private String posSuffixPattern;
	private String negPrefixPattern;
	private String negSuffixPattern;
	private ChoiceFormat currencyChoice;
	private int multiplier = 1;
	private byte groupingSize = 3;
	private byte groupingSize2 = 0;
	private boolean decimalSeparatorAlwaysShown = false;
	private DecimalFormatSymbols symbols = null;
	private boolean useSignificantDigits = false;
	private int minSignificantDigits = 1;
	private int maxSignificantDigits = 6;
	private boolean useExponentialNotation;
	private byte minExponentDigits;
	private boolean exponentSignAlwaysShown = false;
	private BigDecimal roundingIncrement = null;
	private transient com.ibm.icu.math.BigDecimal roundingIncrementICU = null;
	private transient double roundingDouble = 0.0D;
	private transient double roundingDoubleReciprocal = 0.0D;
	private int roundingMode = 6;
	private MathContext mathContext = new MathContext(0, 0);
	private int formatWidth = 0;
	private char pad = ' ';
	private int padPosition = 0;
	private boolean parseBigDecimal = false;
	static final int currentSerialVersion = 3;
	private int serialVersionOnStream = 3;
	public static final int PAD_BEFORE_PREFIX = 0;
	public static final int PAD_AFTER_PREFIX = 1;
	public static final int PAD_BEFORE_SUFFIX = 2;
	public static final int PAD_AFTER_SUFFIX = 3;
	private static final char PATTERN_ZERO_DIGIT = '0';
	private static final char PATTERN_GROUPING_SEPARATOR = ',';
	private static final char PATTERN_DECIMAL_SEPARATOR = '.';
	private static final char PATTERN_DIGIT = '#';
	static final char PATTERN_SIGNIFICANT_DIGIT = '@';
	static final char PATTERN_EXPONENT = 'E';
	static final char PATTERN_PLUS_SIGN = '+';
	private static final char PATTERN_PER_MILLE = '‰';
	private static final char PATTERN_PERCENT = '%';
	static final char PATTERN_PAD_ESCAPE = '*';
	private static final char PATTERN_MINUS = '-';
	private static final char PATTERN_SEPARATOR = ';';
	private static final char CURRENCY_SIGN = '¤';
	private static final char QUOTE = '\'';
	static final int DOUBLE_INTEGER_DIGITS = 309;
	static final int DOUBLE_FRACTION_DIGITS = 340;
	static final int MAX_SCIENTIFIC_INTEGER_DIGITS = 8;
	private static final long serialVersionUID = 864413376551465018L;
	private ArrayList<FieldPosition> attributes = new ArrayList();
	private String formatPattern = "";
	private int style = 0;
	private int currencySignCount = 0;
	private transient Set<AffixForCurrency> affixPatternsForCurrency = null;
	private transient boolean isReadyForParsing = false;
	private CurrencyPluralInfo currencyPluralInfo = null;

	public DecimalFormat() {
		ULocale def = ULocale.getDefault();
		String pattern = getPattern(def, 0);
		this.symbols = new DecimalFormatSymbols(def);
		this.setCurrency(Currency.getInstance(def));
		this.applyPatternWithoutExpandAffix(pattern, false);
		if (this.currencySignCount == 3) {
			this.currencyPluralInfo = new CurrencyPluralInfo(def);
		} else {
			this.expandAffixAdjustWidth((String) null);
		}

	}

	public DecimalFormat(String pattern) {
		ULocale def = ULocale.getDefault();
		this.symbols = new DecimalFormatSymbols(def);
		this.setCurrency(Currency.getInstance(def));
		this.applyPatternWithoutExpandAffix(pattern, false);
		if (this.currencySignCount == 3) {
			this.currencyPluralInfo = new CurrencyPluralInfo(def);
		} else {
			this.expandAffixAdjustWidth((String) null);
		}

	}

	public DecimalFormat(String pattern, DecimalFormatSymbols symbols) {
		this.createFromPatternAndSymbols(pattern, symbols);
	}

	private void createFromPatternAndSymbols(String pattern, DecimalFormatSymbols inputSymbols) {
		this.symbols = (DecimalFormatSymbols) inputSymbols.clone();
		this.setCurrencyForSymbols();
		this.applyPatternWithoutExpandAffix(pattern, false);
		if (this.currencySignCount == 3) {
			this.currencyPluralInfo = new CurrencyPluralInfo(this.symbols.getLocale());
		} else {
			this.expandAffixAdjustWidth((String) null);
		}

	}

	public DecimalFormat(String pattern, DecimalFormatSymbols symbols, CurrencyPluralInfo infoInput, int style) {
		CurrencyPluralInfo info = infoInput;
		if (style == 6) {
			info = (CurrencyPluralInfo) infoInput.clone();
		}

		this.create(pattern, symbols, info, style);
	}

	private void create(String pattern, DecimalFormatSymbols inputSymbols, CurrencyPluralInfo info, int inputStyle) {
		if (inputStyle != 6) {
			this.createFromPatternAndSymbols(pattern, inputSymbols);
		} else {
			this.symbols = (DecimalFormatSymbols) inputSymbols.clone();
			this.currencyPluralInfo = info;
			String currencyPluralPatternForOther = this.currencyPluralInfo.getCurrencyPluralPattern("other");
			this.applyPatternWithoutExpandAffix(currencyPluralPatternForOther, false);
			this.setCurrencyForSymbols();
		}

		this.style = inputStyle;
	}

	DecimalFormat(String pattern, DecimalFormatSymbols inputSymbols, int style) {
		CurrencyPluralInfo info = null;
		if (style == 6) {
			info = new CurrencyPluralInfo(inputSymbols.getLocale());
		}

		this.create(pattern, inputSymbols, info, style);
	}

	public StringBuffer format(double number, StringBuffer result, FieldPosition fieldPosition) {
		return this.format(number, result, fieldPosition, false);
	}

	private StringBuffer format(double number, StringBuffer result, FieldPosition fieldPosition, boolean parseAttr) {
		fieldPosition.setBeginIndex(0);
		fieldPosition.setEndIndex(0);
		if (Double.isNaN(number)) {
			if (fieldPosition.getField() == 0) {
				fieldPosition.setBeginIndex(result.length());
			} else if (fieldPosition.getFieldAttribute() == Field.INTEGER) {
				fieldPosition.setBeginIndex(result.length());
			}

			result.append(this.symbols.getNaN());
			if (parseAttr) {
				this.addAttribute(Field.INTEGER, result.length() - this.symbols.getNaN().length(), result.length());
			}

			if (fieldPosition.getField() == 0) {
				fieldPosition.setEndIndex(result.length());
			} else if (fieldPosition.getFieldAttribute() == Field.INTEGER) {
				fieldPosition.setEndIndex(result.length());
			}

			this.addPadding(result, fieldPosition, 0, 0);
			return result;
		} else {
			if (this.multiplier != 1) {
				number *= (double) this.multiplier;
			}

			boolean isNegative = number < 0.0D || number == 0.0D && 1.0D / number < 0.0D;
			if (isNegative) {
				number = -number;
			}

			if (this.roundingDouble > 0.0D) {
				double newNumber = round(number, this.roundingDouble, this.roundingDoubleReciprocal, this.roundingMode,
						isNegative);
				if (newNumber == 0.0D && number != newNumber) {
					isNegative = false;
				}

				number = newNumber;
			}

			if (Double.isInfinite(number)) {
				int prefixLen = this.appendAffix(result, isNegative, true, parseAttr);
				if (fieldPosition.getField() == 0) {
					fieldPosition.setBeginIndex(result.length());
				} else if (fieldPosition.getFieldAttribute() == Field.INTEGER) {
					fieldPosition.setBeginIndex(result.length());
				}

				result.append(this.symbols.getInfinity());
				if (parseAttr) {
					this.addAttribute(Field.INTEGER, result.length() - this.symbols.getInfinity().length(),
							result.length());
				}

				if (fieldPosition.getField() == 0) {
					fieldPosition.setEndIndex(result.length());
				} else if (fieldPosition.getFieldAttribute() == Field.INTEGER) {
					fieldPosition.setEndIndex(result.length());
				}

				int suffixLen = this.appendAffix(result, isNegative, false, parseAttr);
				this.addPadding(result, fieldPosition, prefixLen, suffixLen);
				return result;
			} else {
				DigitList var11 = this.digitList;
				synchronized (this.digitList) {
					this.digitList.set(number, this.precision(false),
							!this.useExponentialNotation && !this.areSignificantDigitsUsed());
					return this.subformat(number, result, fieldPosition, isNegative, false, parseAttr);
				}
			}
		}
	}

	private static double round(double number, double roundingInc, double roundingIncReciprocal, int mode,
			boolean isNegative) {
		double div;
		div = roundingIncReciprocal == 0.0D ? number / roundingInc : number * roundingIncReciprocal;
		label60 : switch (mode) {
			case 0 :
				div = Math.ceil(div - epsilon);
				break;
			case 1 :
				div = Math.floor(div + epsilon);
				break;
			case 2 :
				div = isNegative ? Math.floor(div + epsilon) : Math.ceil(div - epsilon);
				break;
			case 3 :
				div = isNegative ? Math.ceil(div - epsilon) : Math.floor(div + epsilon);
				break;
			case 4 :
			case 5 :
			case 6 :
			default :
				double ceil = Math.ceil(div);
				double ceildiff = ceil - div;
				double floor = Math.floor(div);
				double floordiff = div - floor;
				switch (mode) {
					case 4 :
						div = ceildiff <= floordiff + epsilon ? ceil : floor;
						break label60;
					case 5 :
						div = floordiff <= ceildiff + epsilon ? floor : ceil;
						break label60;
					case 6 :
						if (floordiff + epsilon < ceildiff) {
							div = floor;
						} else if (ceildiff + epsilon < floordiff) {
							div = ceil;
						} else {
							double testFloor = floor / 2.0D;
							div = testFloor == Math.floor(testFloor) ? floor : ceil;
						}
						break label60;
					default :
						throw new IllegalArgumentException("Invalid rounding mode: " + mode);
				}
			case 7 :
				if (div != Math.floor(div)) {
					throw new ArithmeticException("Rounding necessary");
				}

				return number;
		}

		number = roundingIncReciprocal == 0.0D ? div * roundingInc : div / roundingIncReciprocal;
		return number;
	}

	public StringBuffer format(long number, StringBuffer result, FieldPosition fieldPosition) {
		return this.format(number, result, fieldPosition, false);
	}

	private StringBuffer format(long number, StringBuffer result, FieldPosition fieldPosition, boolean parseAttr) {
		fieldPosition.setBeginIndex(0);
		fieldPosition.setEndIndex(0);
		if (this.roundingIncrementICU != null) {
			return this.format(com.ibm.icu.math.BigDecimal.valueOf(number), result, fieldPosition);
		} else {
			boolean isNegative = number < 0L;
			if (isNegative) {
				number = -number;
			}

			if (this.multiplier != 1) {
				boolean tooBig = false;
				long cutoff;
				if (number < 0L) {
					cutoff = Long.MIN_VALUE / (long) this.multiplier;
					tooBig = number <= cutoff;
				} else {
					cutoff = Long.MAX_VALUE / (long) this.multiplier;
					tooBig = number > cutoff;
				}

				if (tooBig) {
					return this.format(BigInteger.valueOf(isNegative ? -number : number), result, fieldPosition,
							parseAttr);
				}
			}

			number *= (long) this.multiplier;
			DigitList var12 = this.digitList;
			synchronized (this.digitList) {
				this.digitList.set(number, this.precision(true));
				return this.subformat((double) number, result, fieldPosition, isNegative, true, parseAttr);
			}
		}
	}

	public StringBuffer format(BigInteger number, StringBuffer result, FieldPosition fieldPosition) {
		return this.format(number, result, fieldPosition, false);
	}

	private StringBuffer format(BigInteger number, StringBuffer result, FieldPosition fieldPosition,
			boolean parseAttr) {
		if (this.roundingIncrementICU != null) {
			return this.format(new com.ibm.icu.math.BigDecimal(number), result, fieldPosition);
		} else {
			if (this.multiplier != 1) {
				number = number.multiply(BigInteger.valueOf((long) this.multiplier));
			}

			DigitList var5 = this.digitList;
			synchronized (this.digitList) {
				this.digitList.set(number, this.precision(true));
				return this.subformat(number.intValue(), result, fieldPosition, number.signum() < 0, true, parseAttr);
			}
		}
	}

	public StringBuffer format(BigDecimal number, StringBuffer result, FieldPosition fieldPosition) {
		return this.format(number, result, fieldPosition, false);
	}

	private StringBuffer format(BigDecimal number, StringBuffer result, FieldPosition fieldPosition,
			boolean parseAttr) {
		if (this.multiplier != 1) {
			number = number.multiply(BigDecimal.valueOf((long) this.multiplier));
		}

		if (this.roundingIncrement != null) {
			number = number.divide(this.roundingIncrement, 0, this.roundingMode).multiply(this.roundingIncrement);
		}

		DigitList var5 = this.digitList;
		synchronized (this.digitList) {
			this.digitList.set(number, this.precision(false),
					!this.useExponentialNotation && !this.areSignificantDigitsUsed());
			return this.subformat(number.doubleValue(), result, fieldPosition, number.signum() < 0, false, parseAttr);
		}
	}

	public StringBuffer format(com.ibm.icu.math.BigDecimal number, StringBuffer result, FieldPosition fieldPosition) {
		if (this.multiplier != 1) {
			number = number.multiply(com.ibm.icu.math.BigDecimal.valueOf((long) this.multiplier), this.mathContext);
		}

		if (this.roundingIncrementICU != null) {
			number = number.divide(this.roundingIncrementICU, 0, this.roundingMode).multiply(this.roundingIncrementICU,
					this.mathContext);
		}

		DigitList var4 = this.digitList;
		synchronized (this.digitList) {
			this.digitList.set(number, this.precision(false),
					!this.useExponentialNotation && !this.areSignificantDigitsUsed());
			return this.subformat(number.doubleValue(), result, fieldPosition, number.signum() < 0, false, false);
		}
	}

	private boolean isGroupingPosition(int pos) {
		boolean result = false;
		if (this.isGroupingUsed() && pos > 0 && this.groupingSize > 0) {
			if (this.groupingSize2 > 0 && pos > this.groupingSize) {
				result = (pos - this.groupingSize) % this.groupingSize2 == 0;
			} else {
				result = pos % this.groupingSize == 0;
			}
		}

		return result;
	}

	private int precision(boolean isIntegral) {
		if (this.areSignificantDigitsUsed()) {
			return this.getMaximumSignificantDigits();
		} else if (this.useExponentialNotation) {
			return this.getMinimumIntegerDigits() + this.getMaximumFractionDigits();
		} else {
			return isIntegral ? 0 : this.getMaximumFractionDigits();
		}
	}

	private StringBuffer subformat(int number, StringBuffer result, FieldPosition fieldPosition, boolean isNegative,
			boolean isInteger, boolean parseAttr) {
		return this.currencySignCount == 3
				? this.subformat(this.currencyPluralInfo.select((double) number), result, fieldPosition, isNegative,
						isInteger, parseAttr)
				: this.subformat(result, fieldPosition, isNegative, isInteger, parseAttr);
	}

	private StringBuffer subformat(double number, StringBuffer result, FieldPosition fieldPosition, boolean isNegative,
			boolean isInteger, boolean parseAttr) {
		return this.currencySignCount == 3
				? this.subformat(this.currencyPluralInfo.select(number), result, fieldPosition, isNegative, isInteger,
						parseAttr)
				: this.subformat(result, fieldPosition, isNegative, isInteger, parseAttr);
	}

	private StringBuffer subformat(String pluralCount, StringBuffer result, FieldPosition fieldPosition,
			boolean isNegative, boolean isInteger, boolean parseAttr) {
		if (this.style == 6) {
			String currencyPluralPattern = this.currencyPluralInfo.getCurrencyPluralPattern(pluralCount);
			if (!this.formatPattern.equals(currencyPluralPattern)) {
				this.applyPatternWithoutExpandAffix(currencyPluralPattern, false);
			}
		}

		this.expandAffixAdjustWidth(pluralCount);
		return this.subformat(result, fieldPosition, isNegative, isInteger, parseAttr);
	}

	private StringBuffer subformat(StringBuffer result, FieldPosition fieldPosition, boolean isNegative,
			boolean isInteger, boolean parseAttr) {
		char zero = this.symbols.getZeroDigit();
		int zeroDelta = zero - 48;
		char grouping = this.currencySignCount > 0
				? this.symbols.getMonetaryGroupingSeparator()
				: this.symbols.getGroupingSeparator();
		char decimal = this.currencySignCount > 0
				? this.symbols.getMonetaryDecimalSeparator()
				: this.symbols.getDecimalSeparator();
		boolean useSigDig = this.areSignificantDigitsUsed();
		int maxIntDig = this.getMaximumIntegerDigits();
		int minIntDig = this.getMinimumIntegerDigits();
		if (this.digitList.isZero()) {
			this.digitList.decimalAt = 0;
		}

		int prefixLen = this.appendAffix(result, isNegative, true, parseAttr);
		int i;
		int suffixLen;
		int sigCount;
		int minSigDig;
		int exponent;
		int digitIndex;
		int sizeBeforeIntegerPart;
		int fracBegin;
		int maxSigDig;
		if (this.useExponentialNotation) {
			if (fieldPosition.getField() == 0) {
				fieldPosition.setBeginIndex(result.length());
				fieldPosition.setEndIndex(-1);
			} else if (fieldPosition.getField() == 1) {
				fieldPosition.setBeginIndex(-1);
			} else if (fieldPosition.getFieldAttribute() == Field.INTEGER) {
				fieldPosition.setBeginIndex(result.length());
				fieldPosition.setEndIndex(-1);
			} else if (fieldPosition.getFieldAttribute() == Field.FRACTION) {
				fieldPosition.setBeginIndex(-1);
			}

			suffixLen = result.length();
			sigCount = -1;
			minSigDig = -1;
			int minFracDig = false;
			if (useSigDig) {
				minIntDig = 1;
				maxIntDig = 1;
				maxSigDig = this.getMinimumSignificantDigits() - 1;
			} else {
				maxSigDig = this.getMinimumFractionDigits();
				if (maxIntDig > 8) {
					maxIntDig = 1;
					if (maxIntDig < minIntDig) {
						maxIntDig = minIntDig;
					}
				}

				if (maxIntDig > minIntDig) {
					minIntDig = 1;
				}
			}

			exponent = this.digitList.decimalAt;
			if (maxIntDig > 1 && maxIntDig != minIntDig) {
				exponent = exponent > 0 ? (exponent - 1) / maxIntDig : exponent / maxIntDig - 1;
				exponent *= maxIntDig;
			} else {
				exponent -= minIntDig <= 0 && maxSigDig <= 0 ? 1 : minIntDig;
			}

			digitIndex = minIntDig + maxSigDig;
			sizeBeforeIntegerPart = this.digitList.isZero() ? minIntDig : this.digitList.decimalAt - exponent;
			int totalDigits = this.digitList.count;
			if (digitIndex > totalDigits) {
				totalDigits = digitIndex;
			}

			if (sizeBeforeIntegerPart > totalDigits) {
				totalDigits = sizeBeforeIntegerPart;
			}

			for (i = 0; i < totalDigits; ++i) {
				if (i == sizeBeforeIntegerPart) {
					if (fieldPosition.getField() == 0) {
						fieldPosition.setEndIndex(result.length());
					} else if (fieldPosition.getFieldAttribute() == Field.INTEGER) {
						fieldPosition.setEndIndex(result.length());
					}

					if (parseAttr) {
						sigCount = result.length();
						this.addAttribute(Field.INTEGER, suffixLen, result.length());
					}

					result.append(decimal);
					if (parseAttr) {
						fracBegin = result.length() - 1;
						this.addAttribute(Field.DECIMAL_SEPARATOR, fracBegin, result.length());
						minSigDig = result.length();
					}

					if (fieldPosition.getField() == 1) {
						fieldPosition.setBeginIndex(result.length());
					} else if (fieldPosition.getFieldAttribute() == Field.FRACTION) {
						fieldPosition.setBeginIndex(result.length());
					}
				}

				result.append(i < this.digitList.count ? (char) (this.digitList.digits[i] + zeroDelta) : zero);
			}

			if (this.digitList.isZero() && totalDigits == 0) {
				result.append(zero);
			}

			if (fieldPosition.getField() == 0) {
				if (fieldPosition.getEndIndex() < 0) {
					fieldPosition.setEndIndex(result.length());
				}
			} else if (fieldPosition.getField() == 1) {
				if (fieldPosition.getBeginIndex() < 0) {
					fieldPosition.setBeginIndex(result.length());
				}

				fieldPosition.setEndIndex(result.length());
			} else if (fieldPosition.getFieldAttribute() == Field.INTEGER) {
				if (fieldPosition.getEndIndex() < 0) {
					fieldPosition.setEndIndex(result.length());
				}
			} else if (fieldPosition.getFieldAttribute() == Field.FRACTION) {
				if (fieldPosition.getBeginIndex() < 0) {
					fieldPosition.setBeginIndex(result.length());
				}

				fieldPosition.setEndIndex(result.length());
			}

			if (parseAttr) {
				if (sigCount < 0) {
					this.addAttribute(Field.INTEGER, suffixLen, result.length());
				}

				if (minSigDig > 0) {
					this.addAttribute(Field.FRACTION, minSigDig, result.length());
				}
			}

			result.append(this.symbols.getExponentSeparator());
			if (parseAttr) {
				this.addAttribute(Field.EXPONENT_SYMBOL, result.length() - this.symbols.getExponentSeparator().length(),
						result.length());
			}

			if (this.digitList.isZero()) {
				exponent = 0;
			}

			boolean negativeExponent = exponent < 0;
			int expBegin;
			if (negativeExponent) {
				exponent = -exponent;
				result.append(this.symbols.getMinusSign());
				if (parseAttr) {
					this.addAttribute(Field.EXPONENT_SIGN, result.length() - 1, result.length());
				}
			} else if (this.exponentSignAlwaysShown) {
				result.append(this.symbols.getPlusSign());
				if (parseAttr) {
					expBegin = result.length() - 1;
					this.addAttribute(Field.EXPONENT_SIGN, expBegin, result.length());
				}
			}

			expBegin = result.length();
			this.digitList.set((long) exponent);
			int expDig = this.minExponentDigits;
			if (this.useExponentialNotation && expDig < 1) {
				expDig = 1;
			}

			for (i = this.digitList.decimalAt; i < expDig; ++i) {
				result.append(zero);
			}

			for (i = 0; i < this.digitList.decimalAt; ++i) {
				result.append(i < this.digitList.count ? (char) (this.digitList.digits[i] + zeroDelta) : zero);
			}

			if (parseAttr) {
				this.addAttribute(Field.EXPONENT, expBegin, result.length());
			}
		} else {
			suffixLen = result.length();
			if (fieldPosition.getField() == 0) {
				fieldPosition.setBeginIndex(result.length());
			} else if (fieldPosition.getFieldAttribute() == Field.INTEGER) {
				fieldPosition.setBeginIndex(result.length());
			}

			sigCount = 0;
			minSigDig = this.getMinimumSignificantDigits();
			maxSigDig = this.getMaximumSignificantDigits();
			if (!useSigDig) {
				minSigDig = 0;
				maxSigDig = Integer.MAX_VALUE;
			}

			exponent = useSigDig ? Math.max(1, this.digitList.decimalAt) : minIntDig;
			if (this.digitList.decimalAt > 0 && exponent < this.digitList.decimalAt) {
				exponent = this.digitList.decimalAt;
			}

			digitIndex = 0;
			if (exponent > maxIntDig && maxIntDig >= 0) {
				exponent = maxIntDig;
				digitIndex = this.digitList.decimalAt - maxIntDig;
			}

			sizeBeforeIntegerPart = result.length();

			for (i = exponent - 1; i >= 0; --i) {
				if (i < this.digitList.decimalAt && digitIndex < this.digitList.count && sigCount < maxSigDig) {
					byte d = this.digitList.digits[digitIndex++];
					result.append((char) (d + zeroDelta));
					++sigCount;
				} else {
					result.append(zero);
					if (sigCount > 0) {
						++sigCount;
					}
				}

				if (this.isGroupingPosition(i)) {
					result.append(grouping);
					if (parseAttr) {
						this.addAttribute(Field.GROUPING_SEPARATOR, result.length() - 1, result.length());
					}
				}
			}

			if (fieldPosition.getField() == 0) {
				fieldPosition.setEndIndex(result.length());
			} else if (fieldPosition.getFieldAttribute() == Field.INTEGER) {
				fieldPosition.setEndIndex(result.length());
			}

			boolean var10000;
			label444 : {
				if (isInteger || digitIndex >= this.digitList.count) {
					label437 : {
						if (useSigDig) {
							if (sigCount < minSigDig) {
								break label437;
							}
						} else if (this.getMinimumFractionDigits() > 0) {
							break label437;
						}

						var10000 = false;
						break label444;
					}
				}

				var10000 = true;
			}

			boolean fractionPresent = var10000;
			if (!fractionPresent && result.length() == sizeBeforeIntegerPart) {
				result.append(zero);
			}

			if (parseAttr) {
				this.addAttribute(Field.INTEGER, suffixLen, result.length());
			}

			if (this.decimalSeparatorAlwaysShown || fractionPresent) {
				result.append(decimal);
				if (parseAttr) {
					this.addAttribute(Field.DECIMAL_SEPARATOR, result.length() - 1, result.length());
				}
			}

			if (fieldPosition.getField() == 1) {
				fieldPosition.setBeginIndex(result.length());
			} else if (fieldPosition.getFieldAttribute() == Field.FRACTION) {
				fieldPosition.setBeginIndex(result.length());
			}

			fracBegin = result.length();
			exponent = useSigDig ? Integer.MAX_VALUE : this.getMaximumFractionDigits();
			if (useSigDig && (sigCount == maxSigDig || sigCount >= minSigDig && digitIndex == this.digitList.count)) {
				exponent = 0;
			}

			for (i = 0; i < exponent && (useSigDig || i < this.getMinimumFractionDigits()
					|| !isInteger && digitIndex < this.digitList.count); ++i) {
				if (-1 - i > this.digitList.decimalAt - 1) {
					result.append(zero);
				} else {
					if (!isInteger && digitIndex < this.digitList.count) {
						result.append((char) (this.digitList.digits[digitIndex++] + zeroDelta));
					} else {
						result.append(zero);
					}

					++sigCount;
					if (useSigDig
							&& (sigCount == maxSigDig || digitIndex == this.digitList.count && sigCount >= minSigDig)) {
						break;
					}
				}
			}

			if (fieldPosition.getField() == 1) {
				fieldPosition.setEndIndex(result.length());
			} else if (fieldPosition.getFieldAttribute() == Field.FRACTION) {
				fieldPosition.setEndIndex(result.length());
			}

			if (parseAttr && (this.decimalSeparatorAlwaysShown || fractionPresent)) {
				this.addAttribute(Field.FRACTION, fracBegin, result.length());
			}
		}

		suffixLen = this.appendAffix(result, isNegative, false, parseAttr);
		this.addPadding(result, fieldPosition, prefixLen, suffixLen);
		return result;
	}

	private final void addPadding(StringBuffer result, FieldPosition fieldPosition, int prefixLen, int suffixLen) {
		if (this.formatWidth > 0) {
			int len = this.formatWidth - result.length();
			if (len > 0) {
				char[] padding = new char[len];

				for (int i = 0; i < len; ++i) {
					padding[i] = this.pad;
				}

				switch (this.padPosition) {
					case 0 :
						result.insert(0, padding);
						break;
					case 1 :
						result.insert(prefixLen, padding);
						break;
					case 2 :
						result.insert(result.length() - suffixLen, padding);
						break;
					case 3 :
						result.append(padding);
				}

				if (this.padPosition == 0 || this.padPosition == 1) {
					fieldPosition.setBeginIndex(fieldPosition.getBeginIndex() + len);
					fieldPosition.setEndIndex(fieldPosition.getEndIndex() + len);
				}
			}
		}

	}

	public Number parse(String text, ParsePosition parsePosition) {
		return (Number) this.parse(text, parsePosition, false);
	}

	CurrencyAmount parseCurrency(String text, ParsePosition pos) {
		return (CurrencyAmount) this.parse(text, pos, true);
	}

	private Object parse(String text, ParsePosition parsePosition, boolean parseCurrency) {
		int backup;
		int i = backup = parsePosition.getIndex();
		if (this.formatWidth > 0 && (this.padPosition == 0 || this.padPosition == 1)) {
			i = this.skipPadding(text, i);
		}

		if (text.regionMatches(i, this.symbols.getNaN(), 0, this.symbols.getNaN().length())) {
			i += this.symbols.getNaN().length();
			if (this.formatWidth > 0 && (this.padPosition == 2 || this.padPosition == 3)) {
				i = this.skipPadding(text, i);
			}

			parsePosition.setIndex(i);
			return new Double(Double.NaN);
		} else {
			boolean[] status = new boolean[3];
			Currency[] currency = parseCurrency ? new Currency[1] : null;
			if (this.currencySignCount > 0) {
				if (!this.parseForCurrency(text, parsePosition, parseCurrency, currency, status)) {
					return null;
				}
			} else if (!this.subparse(text, parsePosition, this.digitList, false, status, currency,
					this.negPrefixPattern, this.negSuffixPattern, this.posPrefixPattern, this.posSuffixPattern, 0)) {
				parsePosition.setIndex(backup);
				return null;
			}

			Number n = null;
			if (status[0]) {
				n = new Double(status[1] ? Double.POSITIVE_INFINITY : Double.NEGATIVE_INFINITY);
			} else if (status[2]) {
				n = status[1] ? new Double("0.0") : new Double("-0.0");
			} else if (!status[1] && this.digitList.isZero()) {
				n = new Double("-0.0");
			} else {
				int mult;
				for (mult = this.multiplier; mult % 10 == 0; mult /= 10) {
					--this.digitList.decimalAt;
				}

				if (!this.parseBigDecimal && mult == 1 && this.digitList.isIntegral()) {
					if (this.digitList.decimalAt < 12) {
						long l = 0L;
						if (this.digitList.count > 0) {
							int nx;
							for (nx = 0; nx < this.digitList.count; l = l * 10L
									+ (long) ((char) this.digitList.digits[nx++]) - 48L) {
								;
							}

							while (nx++ < this.digitList.decimalAt) {
								l *= 10L;
							}

							if (!status[1]) {
								l = -l;
							}
						}

						n = new Long(l);
					} else {
						BigInteger big = this.digitList.getBigInteger(status[1]);
						n = big.bitLength() < 64 ? new Long(big.longValue()) : big;
					}
				} else {
					com.ibm.icu.math.BigDecimal big = this.digitList.getBigDecimalICU(status[1]);
					n = big;
					if (mult != 1) {
						n = big.divide(com.ibm.icu.math.BigDecimal.valueOf((long) mult), this.mathContext);
					}
				}
			}

			return parseCurrency ? new CurrencyAmount((Number) n, currency[0]) : n;
		}
	}

	private boolean parseForCurrency(String text, ParsePosition parsePosition, boolean parseCurrency,
			Currency[] currency, boolean[] status) {
		int origPos = parsePosition.getIndex();
		int maxPosIndex;
		if (!this.isReadyForParsing) {
			maxPosIndex = this.currencySignCount;
			this.setupCurrencyAffixForAllPatterns();
			if (maxPosIndex == 3) {
				this.applyPatternWithoutExpandAffix(this.formatPattern, false);
			} else {
				this.applyPattern(this.formatPattern, false);
			}

			this.isReadyForParsing = true;
		}

		maxPosIndex = origPos;
		int maxErrorPos = -1;
		boolean[] savedStatus = null;
		boolean[] tmpStatus = new boolean[3];
		ParsePosition tmpPos = new ParsePosition(origPos);
		DigitList tmpDigitList = new DigitList();
		boolean found;
		if (this.style == 6) {
			found = this.subparse(text, tmpPos, tmpDigitList, false, tmpStatus, currency, this.negPrefixPattern,
					this.negSuffixPattern, this.posPrefixPattern, this.posSuffixPattern, 1);
		} else {
			found = this.subparse(text, tmpPos, tmpDigitList, false, tmpStatus, currency, this.negPrefixPattern,
					this.negSuffixPattern, this.posPrefixPattern, this.posSuffixPattern, 0);
		}

		if (found) {
			if (tmpPos.getIndex() > origPos) {
				maxPosIndex = tmpPos.getIndex();
				savedStatus = tmpStatus;
				this.digitList = tmpDigitList;
			}
		} else {
			maxErrorPos = tmpPos.getErrorIndex();
		}

		Iterator i$ = this.affixPatternsForCurrency.iterator();

		while (i$.hasNext()) {
			AffixForCurrency affix = (AffixForCurrency) i$.next();
			tmpStatus = new boolean[3];
			tmpPos = new ParsePosition(origPos);
			tmpDigitList = new DigitList();
			boolean result = this.subparse(text, tmpPos, tmpDigitList, false, tmpStatus, currency, affix.getNegPrefix(),
					affix.getNegSuffix(), affix.getPosPrefix(), affix.getPosSuffix(), affix.getPatternType());
			if (result) {
				found = true;
				if (tmpPos.getIndex() > maxPosIndex) {
					maxPosIndex = tmpPos.getIndex();
					savedStatus = tmpStatus;
					this.digitList = tmpDigitList;
				}
			} else {
				maxErrorPos = tmpPos.getErrorIndex() > maxErrorPos ? tmpPos.getErrorIndex() : maxErrorPos;
			}
		}

		tmpStatus = new boolean[3];
		tmpPos = new ParsePosition(origPos);
		tmpDigitList = new DigitList();
		int savedCurrencySignCount = this.currencySignCount;
		this.currencySignCount = 0;
		boolean result = this.subparse(text, tmpPos, tmpDigitList, false, tmpStatus, currency, this.negativePrefix,
				this.negativeSuffix, this.positivePrefix, this.positiveSuffix, 0);
		this.currencySignCount = savedCurrencySignCount;
		if (result) {
			if (tmpPos.getIndex() > maxPosIndex) {
				maxPosIndex = tmpPos.getIndex();
				savedStatus = tmpStatus;
				this.digitList = tmpDigitList;
			}

			found = true;
		} else {
			maxErrorPos = tmpPos.getErrorIndex() > maxErrorPos ? tmpPos.getErrorIndex() : maxErrorPos;
		}

		if (!found) {
			parsePosition.setErrorIndex(maxErrorPos);
		} else {
			parsePosition.setIndex(maxPosIndex);
			parsePosition.setErrorIndex(-1);

			for (int index = 0; index < 3; ++index) {
				status[index] = savedStatus[index];
			}
		}

		return found;
	}

	private void setupCurrencyAffixForAllPatterns() {
		if (this.currencyPluralInfo == null) {
			this.currencyPluralInfo = new CurrencyPluralInfo(this.symbols.getLocale());
		}

		this.affixPatternsForCurrency = new HashSet();
		String savedFormatPattern = this.formatPattern;
		this.applyPatternWithoutExpandAffix(getPattern(this.symbols.getLocale(), 1), false);
		AffixForCurrency affixes = new AffixForCurrency(this.negPrefixPattern, this.negSuffixPattern,
				this.posPrefixPattern, this.posSuffixPattern, 0);
		this.affixPatternsForCurrency.add(affixes);
		Iterator<String> iter = this.currencyPluralInfo.pluralPatternIterator();
		HashSet currencyUnitPatternSet = new HashSet();

		while (iter.hasNext()) {
			String pluralCount = (String) iter.next();
			String currencyPattern = this.currencyPluralInfo.getCurrencyPluralPattern(pluralCount);
			if (currencyPattern != null && !currencyUnitPatternSet.contains(currencyPattern)) {
				currencyUnitPatternSet.add(currencyPattern);
				this.applyPatternWithoutExpandAffix(currencyPattern, false);
				affixes = new AffixForCurrency(this.negPrefixPattern, this.negSuffixPattern, this.posPrefixPattern,
						this.posSuffixPattern, 1);
				this.affixPatternsForCurrency.add(affixes);
			}
		}

		this.formatPattern = savedFormatPattern;
	}

	private final boolean subparse(String text, ParsePosition parsePosition, DigitList digits, boolean isExponent,
			boolean[] status, Currency[] currency, String negPrefix, String negSuffix, String posPrefix,
			String posSuffix, int type) {
		int position = parsePosition.getIndex();
		int oldStart = parsePosition.getIndex();
		if (this.formatWidth > 0 && this.padPosition == 0) {
			position = this.skipPadding(text, position);
		}

		int posMatch = this.compareAffix(text, position, false, true, posPrefix, type, currency);
		int negMatch = this.compareAffix(text, position, true, true, negPrefix, type, currency);
		if (posMatch >= 0 && negMatch >= 0) {
			if (posMatch > negMatch) {
				negMatch = -1;
			} else if (negMatch > posMatch) {
				posMatch = -1;
			}
		}

		if (posMatch >= 0) {
			position += posMatch;
		} else {
			if (negMatch < 0) {
				parsePosition.setErrorIndex(position);
				return false;
			}

			position += negMatch;
		}

		if (this.formatWidth > 0 && this.padPosition == 1) {
			position = this.skipPadding(text, position);
		}

		status[0] = false;
		if (!isExponent
				&& text.regionMatches(position, this.symbols.getInfinity(), 0, this.symbols.getInfinity().length())) {
			position += this.symbols.getInfinity().length();
			status[0] = true;
		} else {
			digits.decimalAt = digits.count = 0;
			char zero = this.symbols.getZeroDigit();
			char decimal = this.currencySignCount > 0
					? this.symbols.getMonetaryDecimalSeparator()
					: this.symbols.getDecimalSeparator();
			char grouping = this.symbols.getGroupingSeparator();
			String exponentSep = this.symbols.getExponentSeparator();
			boolean sawDecimal = false;
			boolean sawGrouping = false;
			boolean sawExponent = false;
			boolean sawDigit = false;
			long exponent = 0L;
			int digit = false;
			boolean strictParse = this.isParseStrict();
			boolean strictFail = false;
			int lastGroup = -1;
			int gs2 = this.groupingSize2 == 0 ? this.groupingSize : this.groupingSize2;
			boolean strictLeadingZero = false;
			int leadingZeroPos = 0;
			int leadingZeroCount = 0;
			boolean skipExtendedSeparatorParsing = ICUConfig
					.get("com.ibm.icu.text.DecimalFormat.SkipExtendedSeparatorParsing", "false").equals("true");
			UnicodeSet decimalEquiv = skipExtendedSeparatorParsing
					? EMPTY_SET
					: this.getEquivalentDecimals(decimal, strictParse);
			UnicodeSet groupEquiv = skipExtendedSeparatorParsing
					? EMPTY_SET
					: (strictParse ? strictDefaultGroupingSeparators : defaultGroupingSeparators);
			int digitCount = 0;

			int backup;
			for (backup = -1; position < text.length(); ++position) {
				char ch = text.charAt(position);
				int digit = ch - zero;
				if (digit < 0 || digit > 9) {
					digit = UCharacter.digit(ch, 10);
				}

				if (digit == 0) {
					if (strictParse && backup != -1) {
						if (lastGroup != -1 && backup - lastGroup - 1 != gs2
								|| lastGroup == -1 && position - oldStart - 1 > gs2) {
							strictFail = true;
							break;
						}

						lastGroup = backup;
					}

					backup = -1;
					sawDigit = true;
					if (digits.count == 0) {
						if (!sawDecimal) {
							if (strictParse && !isExponent) {
								if (!strictLeadingZero) {
									leadingZeroPos = position + 1;
								}

								strictLeadingZero = true;
								++leadingZeroCount;
							}
						} else {
							--digits.decimalAt;
						}
					} else {
						++digitCount;
						digits.append((char) (digit + 48));
					}
				} else if (digit > 0 && digit <= 9) {
					if (strictParse && backup != -1) {
						if (lastGroup != -1 && backup - lastGroup - 1 != gs2
								|| lastGroup == -1 && position - oldStart - 1 > gs2) {
							strictFail = true;
							break;
						}

						lastGroup = backup;
					}

					sawDigit = true;
					++digitCount;
					digits.append((char) (digit + 48));
					backup = -1;
				} else if (!isExponent && ch == decimal) {
					if (strictParse
							&& (backup != -1 || lastGroup != -1 && position - lastGroup != this.groupingSize + 1)) {
						strictFail = true;
						break;
					}

					if (this.isParseIntegerOnly() || sawDecimal) {
						break;
					}

					digits.decimalAt = digitCount;
					sawDecimal = true;
				} else if (!isExponent && this.isGroupingUsed() && ch == grouping) {
					if (sawDecimal) {
						break;
					}

					if (strictParse && (!sawDigit || backup != -1)) {
						strictFail = true;
						break;
					}

					backup = position;
					sawGrouping = true;
				} else if (!isExponent && !sawDecimal && decimalEquiv.contains(ch)) {
					if (strictParse
							&& (backup != -1 || lastGroup != -1 && position - lastGroup != this.groupingSize + 1)) {
						strictFail = true;
						break;
					}

					if (this.isParseIntegerOnly()) {
						break;
					}

					digits.decimalAt = digitCount;
					decimal = ch;
					sawDecimal = true;
				} else {
					if (isExponent || !this.isGroupingUsed() || sawGrouping || !groupEquiv.contains(ch)) {
						if (isExponent || sawExponent
								|| !text.regionMatches(position, exponentSep, 0, exponentSep.length())) {
							break;
						}

						boolean negExp = false;
						int pos = position + exponentSep.length();
						if (pos < text.length()) {
							ch = text.charAt(pos);
							if (ch == this.symbols.getPlusSign()) {
								++pos;
							} else if (ch == this.symbols.getMinusSign()) {
								++pos;
								negExp = true;
							}
						}

						DigitList exponentDigits = new DigitList();

						for (exponentDigits.count = 0; pos < text.length(); ++pos) {
							digit = text.charAt(pos) - zero;
							if (digit < 0 || digit > 9) {
								digit = UCharacter.digit(text.charAt(pos), 10);
							}

							if (digit < 0 || digit > 9) {
								break;
							}

							exponentDigits.append((char) (digit + 48));
						}

						if (exponentDigits.count <= 0) {
							break;
						}

						if (!strictParse || backup == -1 && lastGroup == -1) {
							if (exponentDigits.count > 10) {
								if (negExp) {
									status[2] = true;
								} else {
									status[0] = true;
								}
							} else {
								exponentDigits.decimalAt = exponentDigits.count;
								exponent = exponentDigits.getLong();
								if (negExp) {
									exponent = -exponent;
								}
							}

							position = pos;
							sawExponent = true;
							break;
						}

						strictFail = true;
						break;
					}

					if (sawDecimal) {
						break;
					}

					if (strictParse && (!sawDigit || backup != -1)) {
						strictFail = true;
						break;
					}

					grouping = ch;
					backup = position;
					sawGrouping = true;
				}
			}

			if (backup != -1) {
				position = backup;
			}

			if (!sawDecimal) {
				digits.decimalAt = digitCount;
			}

			if (strictParse && strictLeadingZero
					&& leadingZeroCount + digits.decimalAt > this.getMinimumIntegerDigits()) {
				parsePosition.setIndex(oldStart);
				parsePosition.setErrorIndex(leadingZeroPos);
				return false;
			}

			if (strictParse && !sawDecimal && lastGroup != -1 && position - lastGroup != this.groupingSize + 1) {
				strictFail = true;
			}

			if (strictFail) {
				parsePosition.setIndex(oldStart);
				parsePosition.setErrorIndex(position);
				return false;
			}

			exponent += (long) digits.decimalAt;
			if (exponent < -1000L) {
				status[2] = true;
			} else if (exponent > 1000L) {
				status[0] = true;
			} else {
				digits.decimalAt = (int) exponent;
			}

			if (!sawDigit && digitCount == 0) {
				parsePosition.setIndex(oldStart);
				parsePosition.setErrorIndex(oldStart);
				return false;
			}
		}

		if (this.formatWidth > 0 && this.padPosition == 2) {
			position = this.skipPadding(text, position);
		}

		if (posMatch >= 0) {
			posMatch = this.compareAffix(text, position, false, false, posSuffix, type, currency);
		}

		if (negMatch >= 0) {
			negMatch = this.compareAffix(text, position, true, false, negSuffix, type, currency);
		}

		if (posMatch >= 0 && negMatch >= 0) {
			if (posMatch > negMatch) {
				negMatch = -1;
			} else if (negMatch > posMatch) {
				posMatch = -1;
			}
		}

		if (posMatch >= 0 == negMatch >= 0) {
			parsePosition.setErrorIndex(position);
			return false;
		} else {
			position += posMatch >= 0 ? posMatch : negMatch;
			if (this.formatWidth > 0 && this.padPosition == 3) {
				position = this.skipPadding(text, position);
			}

			parsePosition.setIndex(position);
			status[1] = posMatch >= 0;
			if (parsePosition.getIndex() == oldStart) {
				parsePosition.setErrorIndex(position);
				return false;
			} else {
				return true;
			}
		}
	}

	private UnicodeSet getEquivalentDecimals(char decimal, boolean strictParse) {
		UnicodeSet equivSet = EMPTY_SET;
		if (strictParse) {
			if (strictDotEquivalents.contains(decimal)) {
				equivSet = strictDotEquivalents;
			} else if (strictCommaEquivalents.contains(decimal)) {
				equivSet = strictCommaEquivalents;
			}
		} else if (dotEquivalents.contains(decimal)) {
			equivSet = dotEquivalents;
		} else if (commaEquivalents.contains(decimal)) {
			equivSet = commaEquivalents;
		}

		return equivSet;
	}

	private final int skipPadding(String text, int position) {
		while (position < text.length() && text.charAt(position) == this.pad) {
			++position;
		}

		return position;
	}

	private int compareAffix(String text, int pos, boolean isNegative, boolean isPrefix, String affixPat, int type,
			Currency[] currency) {
		if (currency == null && this.currencyChoice == null && this.currencySignCount <= 0) {
			return isPrefix
					? compareSimpleAffix(isNegative ? this.negativePrefix : this.positivePrefix, text, pos)
					: compareSimpleAffix(isNegative ? this.negativeSuffix : this.positiveSuffix, text, pos);
		} else {
			return this.compareComplexAffix(affixPat, text, pos, type, currency);
		}
	}

	private static int compareSimpleAffix(String affix, String input, int pos) {
		int start = pos;
		int i = 0;

		while (true) {
			while (i < affix.length()) {
				int c = UTF16.charAt(affix, i);
				int len = UTF16.getCharCount(c);
				if (!UCharacterProperty.isRuleWhiteSpace(c)) {
					if (pos >= input.length() || UTF16.charAt(input, pos) != c) {
						return -1;
					}

					i += len;
					pos += len;
				} else {
					boolean literalMatch = false;

					while (pos < input.length() && UTF16.charAt(input, pos) == c) {
						literalMatch = true;
						i += len;
						pos += len;
						if (i == affix.length()) {
							break;
						}

						c = UTF16.charAt(affix, i);
						len = UTF16.getCharCount(c);
						if (!UCharacterProperty.isRuleWhiteSpace(c)) {
							break;
						}
					}

					i = skipRuleWhiteSpace(affix, i);
					int s = pos;
					pos = skipUWhiteSpace(input, pos);
					if (pos == s && !literalMatch) {
						return -1;
					}

					i = skipUWhiteSpace(affix, i);
				}
			}

			return pos - start;
		}
	}

	private static int skipRuleWhiteSpace(String text, int pos) {
		while (true) {
			if (pos < text.length()) {
				int c = UTF16.charAt(text, pos);
				if (UCharacterProperty.isRuleWhiteSpace(c)) {
					pos += UTF16.getCharCount(c);
					continue;
				}
			}

			return pos;
		}
	}

	private static int skipUWhiteSpace(String text, int pos) {
		while (true) {
			if (pos < text.length()) {
				int c = UTF16.charAt(text, pos);
				if (UCharacter.isUWhiteSpace(c)) {
					pos += UTF16.getCharCount(c);
					continue;
				}
			}

			return pos;
		}
	}

	private int compareComplexAffix(String affixPat, String text, int pos, int type, Currency[] currency) {
		int start = pos;
		int i = 0;

		while (i < affixPat.length() && pos >= 0) {
			char c = affixPat.charAt(i++);
			if (c == '\'') {
				while (true) {
					int j = affixPat.indexOf(39, i);
					if (j == i) {
						pos = match(text, pos, 39);
						i = j + 1;
						break;
					}

					if (j <= i) {
						throw new RuntimeException();
					}

					pos = match(text, pos, affixPat.substring(i, j));
					i = j + 1;
					if (i >= affixPat.length() || affixPat.charAt(i) != '\'') {
						break;
					}

					pos = match(text, pos, 39);
					++i;
				}
			} else {
				switch (c) {
					case '%' :
						c = this.symbols.getPercent();
						break;
					case '-' :
						c = this.symbols.getMinusSign();
						break;
					case '¤' :
						boolean intl = i < affixPat.length() && affixPat.charAt(i) == 164;
						if (intl) {
							++i;
						}

						boolean plural = i < affixPat.length() && affixPat.charAt(i) == 164;
						if (plural) {
							++i;
							intl = false;
						}

						ULocale uloc = this.getLocale(ULocale.VALID_LOCALE);
						if (uloc == null) {
							uloc = this.symbols.getLocale(ULocale.VALID_LOCALE);
						}

						ParsePosition ppos = new ParsePosition(pos);
						String iso = Currency.parse(uloc, text, type, ppos);
						if (iso != null) {
							if (currency != null) {
								currency[0] = Currency.getInstance(iso);
							}

							pos = ppos.getIndex();
						} else {
							pos = -1;
						}
						continue;
					case '‰' :
						c = this.symbols.getPerMill();
				}

				pos = match(text, pos, c);
				if (UCharacterProperty.isRuleWhiteSpace(c)) {
					i = skipRuleWhiteSpace(affixPat, i);
				}
			}
		}

		return pos - start;
	}

	static final int match(String text, int pos, int ch) {
		if (pos >= text.length()) {
			return -1;
		} else if (UCharacterProperty.isRuleWhiteSpace(ch)) {
			int s = pos;
			pos = skipRuleWhiteSpace(text, pos);
			return pos == s ? -1 : pos;
		} else {
			return pos >= 0 && UTF16.charAt(text, pos) == ch ? pos + UTF16.getCharCount(ch) : -1;
		}
	}

	static final int match(String text, int pos, String str) {
		int i = 0;

		while (i < str.length() && pos >= 0) {
			int ch = UTF16.charAt(str, i);
			i += UTF16.getCharCount(ch);
			pos = match(text, pos, ch);
			if (UCharacterProperty.isRuleWhiteSpace(ch)) {
				i = skipRuleWhiteSpace(str, i);
			}
		}

		return pos;
	}

	public DecimalFormatSymbols getDecimalFormatSymbols() {
		try {
			return (DecimalFormatSymbols) this.symbols.clone();
		} catch (Exception var2) {
			return null;
		}
	}

	public void setDecimalFormatSymbols(DecimalFormatSymbols newSymbols) {
		this.symbols = (DecimalFormatSymbols) newSymbols.clone();
		this.setCurrencyForSymbols();
		this.expandAffixes((String) null);
	}

	private void setCurrencyForSymbols() {
		DecimalFormatSymbols def = new DecimalFormatSymbols(this.symbols.getLocale());
		if (this.symbols.getCurrencySymbol().equals(def.getCurrencySymbol())
				&& this.symbols.getInternationalCurrencySymbol().equals(def.getInternationalCurrencySymbol())) {
			this.setCurrency(Currency.getInstance(this.symbols.getLocale()));
		} else {
			this.setCurrency((Currency) null);
		}

	}

	public String getPositivePrefix() {
		return this.positivePrefix;
	}

	public void setPositivePrefix(String newValue) {
		this.positivePrefix = newValue;
		this.posPrefixPattern = null;
	}

	public String getNegativePrefix() {
		return this.negativePrefix;
	}

	public void setNegativePrefix(String newValue) {
		this.negativePrefix = newValue;
		this.negPrefixPattern = null;
	}

	public String getPositiveSuffix() {
		return this.positiveSuffix;
	}

	public void setPositiveSuffix(String newValue) {
		this.positiveSuffix = newValue;
		this.posSuffixPattern = null;
	}

	public String getNegativeSuffix() {
		return this.negativeSuffix;
	}

	public void setNegativeSuffix(String newValue) {
		this.negativeSuffix = newValue;
		this.negSuffixPattern = null;
	}

	public int getMultiplier() {
		return this.multiplier;
	}

	public void setMultiplier(int newValue) {
		if (newValue == 0) {
			throw new IllegalArgumentException("Bad multiplier: " + newValue);
		} else {
			this.multiplier = newValue;
		}
	}

	public BigDecimal getRoundingIncrement() {
		return this.roundingIncrementICU == null ? null : this.roundingIncrementICU.toBigDecimal();
	}

	public void setRoundingIncrement(BigDecimal newValue) {
		if (newValue == null) {
			this.setRoundingIncrement((com.ibm.icu.math.BigDecimal) null);
		} else {
			this.setRoundingIncrement(new com.ibm.icu.math.BigDecimal(newValue));
		}

	}

	public void setRoundingIncrement(com.ibm.icu.math.BigDecimal newValue) {
		int i = newValue == null ? 0 : newValue.compareTo(com.ibm.icu.math.BigDecimal.ZERO);
		if (i < 0) {
			throw new IllegalArgumentException("Illegal rounding increment");
		} else {
			if (i == 0) {
				this.setInternalRoundingIncrement((com.ibm.icu.math.BigDecimal) null);
			} else {
				this.setInternalRoundingIncrement(newValue);
			}

			this.setRoundingDouble();
		}
	}

	public void setRoundingIncrement(double newValue) {
		if (newValue < 0.0D) {
			throw new IllegalArgumentException("Illegal rounding increment");
		} else {
			this.roundingDouble = newValue;
			this.roundingDoubleReciprocal = 0.0D;
			if (newValue == 0.0D) {
				this.setRoundingIncrement((com.ibm.icu.math.BigDecimal) null);
			} else {
				this.roundingDouble = newValue;
				if (this.roundingDouble < 1.0D) {
					double rawRoundedReciprocal = 1.0D / this.roundingDouble;
					this.setRoundingDoubleReciprocal(rawRoundedReciprocal);
				}

				this.setInternalRoundingIncrement(new com.ibm.icu.math.BigDecimal(newValue));
			}

		}
	}

	private void setRoundingDoubleReciprocal(double rawRoundedReciprocal) {
		this.roundingDoubleReciprocal = Math.rint(rawRoundedReciprocal);
		if (Math.abs(rawRoundedReciprocal - this.roundingDoubleReciprocal) > 1.0E-9D) {
			this.roundingDoubleReciprocal = 0.0D;
		}

	}

	public int getRoundingMode() {
		return this.roundingMode;
	}

	public void setRoundingMode(int roundingMode) {
		if (roundingMode >= 0 && roundingMode <= 7) {
			this.roundingMode = roundingMode;
			if (this.getRoundingIncrement() == null) {
				this.setRoundingIncrement(Math.pow(10.0D, (double) (-this.getMaximumFractionDigits())));
			}

		} else {
			throw new IllegalArgumentException("Invalid rounding mode: " + roundingMode);
		}
	}

	public int getFormatWidth() {
		return this.formatWidth;
	}

	public void setFormatWidth(int width) {
		if (width < 0) {
			throw new IllegalArgumentException("Illegal format width");
		} else {
			this.formatWidth = width;
		}
	}

	public char getPadCharacter() {
		return this.pad;
	}

	public void setPadCharacter(char padChar) {
		this.pad = padChar;
	}

	public int getPadPosition() {
		return this.padPosition;
	}

	public void setPadPosition(int padPos) {
		if (padPos >= 0 && padPos <= 3) {
			this.padPosition = padPos;
		} else {
			throw new IllegalArgumentException("Illegal pad position");
		}
	}

	public boolean isScientificNotation() {
		return this.useExponentialNotation;
	}

	public void setScientificNotation(boolean useScientific) {
		this.useExponentialNotation = useScientific;
	}

	public byte getMinimumExponentDigits() {
		return this.minExponentDigits;
	}

	public void setMinimumExponentDigits(byte minExpDig) {
		if (minExpDig < 1) {
			throw new IllegalArgumentException("Exponent digits must be >= 1");
		} else {
			this.minExponentDigits = minExpDig;
		}
	}

	public boolean isExponentSignAlwaysShown() {
		return this.exponentSignAlwaysShown;
	}

	public void setExponentSignAlwaysShown(boolean expSignAlways) {
		this.exponentSignAlwaysShown = expSignAlways;
	}

	public int getGroupingSize() {
		return this.groupingSize;
	}

	public void setGroupingSize(int newValue) {
		this.groupingSize = (byte) newValue;
	}

	public int getSecondaryGroupingSize() {
		return this.groupingSize2;
	}

	public void setSecondaryGroupingSize(int newValue) {
		this.groupingSize2 = (byte) newValue;
	}

	public MathContext getMathContextICU() {
		return this.mathContext;
	}

	public java.math.MathContext getMathContext() {
		try {
			return this.mathContext == null
					? null
					: new java.math.MathContext(this.mathContext.getDigits(),
							RoundingMode.valueOf(this.mathContext.getRoundingMode()));
		} catch (Exception var2) {
			return null;
		}
	}

	public void setMathContextICU(MathContext newValue) {
		this.mathContext = newValue;
	}

	public void setMathContext(java.math.MathContext newValue) {
		this.mathContext = new MathContext(newValue.getPrecision(), 1, false, newValue.getRoundingMode().ordinal());
	}

	public boolean isDecimalSeparatorAlwaysShown() {
		return this.decimalSeparatorAlwaysShown;
	}

	public void setDecimalSeparatorAlwaysShown(boolean newValue) {
		this.decimalSeparatorAlwaysShown = newValue;
	}

	public CurrencyPluralInfo getCurrencyPluralInfo() {
		try {
			return this.currencyPluralInfo == null ? null : (CurrencyPluralInfo) this.currencyPluralInfo.clone();
		} catch (Exception var2) {
			return null;
		}
	}

	public void setCurrencyPluralInfo(CurrencyPluralInfo newInfo) {
		this.currencyPluralInfo = (CurrencyPluralInfo) newInfo.clone();
		this.isReadyForParsing = false;
	}

	public Object clone() {
		try {
			DecimalFormat other = (DecimalFormat) super.clone();
			other.symbols = (DecimalFormatSymbols) this.symbols.clone();
			other.digitList = new DigitList();
			if (this.currencyPluralInfo != null) {
				other.currencyPluralInfo = (CurrencyPluralInfo) this.currencyPluralInfo.clone();
			}

			return other;
		} catch (Exception var2) {
			throw new IllegalStateException();
		}
	}

	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (!super.equals(obj)) {
			return false;
		} else {
			DecimalFormat other = (DecimalFormat) obj;
			return this.currencySignCount == other.currencySignCount
					&& (this.style != 6 || this.equals(this.posPrefixPattern, other.posPrefixPattern)
							&& this.equals(this.posSuffixPattern, other.posSuffixPattern)
							&& this.equals(this.negPrefixPattern, other.negPrefixPattern)
							&& this.equals(this.negSuffixPattern, other.negSuffixPattern))
					&& this.multiplier == other.multiplier && this.groupingSize == other.groupingSize
					&& this.groupingSize2 == other.groupingSize2
					&& this.decimalSeparatorAlwaysShown == other.decimalSeparatorAlwaysShown
					&& this.useExponentialNotation == other.useExponentialNotation
					&& (!this.useExponentialNotation || this.minExponentDigits == other.minExponentDigits)
					&& this.useSignificantDigits == other.useSignificantDigits
					&& (!this.useSignificantDigits || this.minSignificantDigits == other.minSignificantDigits
							&& this.maxSignificantDigits == other.maxSignificantDigits)
					&& this.symbols.equals(other.symbols)
					&& Utility.objectEquals(this.currencyPluralInfo, other.currencyPluralInfo);
		}
	}

	private boolean equals(String pat1, String pat2) {
		if (pat1 != null && pat2 != null) {
			return pat1.equals(pat2) ? true : this.unquote(pat1).equals(this.unquote(pat2));
		} else {
			return pat1 == null && pat2 == null;
		}
	}

	private String unquote(String pat) {
		StringBuilder buf = new StringBuilder(pat.length());
		int i = 0;

		while (i < pat.length()) {
			char ch = pat.charAt(i++);
			if (ch != '\'') {
				buf.append(ch);
			}
		}

		return buf.toString();
	}

	public int hashCode() {
		return super.hashCode() * 37 + this.positivePrefix.hashCode();
	}

	public String toPattern() {
		return this.style == 6 ? this.formatPattern : this.toPattern(false);
	}

	public String toLocalizedPattern() {
		return this.style == 6 ? this.formatPattern : this.toPattern(true);
	}

	private void expandAffixes(String pluralCount) {
		this.currencyChoice = null;
		StringBuffer buffer = new StringBuffer();
		if (this.posPrefixPattern != null) {
			this.expandAffix(this.posPrefixPattern, pluralCount, buffer, false);
			this.positivePrefix = buffer.toString();
		}

		if (this.posSuffixPattern != null) {
			this.expandAffix(this.posSuffixPattern, pluralCount, buffer, false);
			this.positiveSuffix = buffer.toString();
		}

		if (this.negPrefixPattern != null) {
			this.expandAffix(this.negPrefixPattern, pluralCount, buffer, false);
			this.negativePrefix = buffer.toString();
		}

		if (this.negSuffixPattern != null) {
			this.expandAffix(this.negSuffixPattern, pluralCount, buffer, false);
			this.negativeSuffix = buffer.toString();
		}

	}

	private void expandAffix(String pattern, String pluralCount, StringBuffer buffer, boolean doFormat) {
		buffer.setLength(0);
		int i = 0;

		while (true) {
			while (true) {
				while (i < pattern.length()) {
					char c = pattern.charAt(i++);
					if (c == '\'') {
						while (true) {
							int j = pattern.indexOf(39, i);
							if (j == i) {
								buffer.append('\'');
								i = j + 1;
								break;
							}

							if (j <= i) {
								throw new RuntimeException();
							}

							buffer.append(pattern.substring(i, j));
							i = j + 1;
							if (i >= pattern.length() || pattern.charAt(i) != '\'') {
								break;
							}

							buffer.append('\'');
							++i;
						}
					} else {
						switch (c) {
							case '%' :
								c = this.symbols.getPercent();
								break;
							case '-' :
								c = this.symbols.getMinusSign();
								break;
							case '¤' :
								boolean intl = i < pattern.length() && pattern.charAt(i) == 164;
								boolean plural = false;
								if (intl) {
									++i;
									if (i < pattern.length() && pattern.charAt(i) == 164) {
										plural = true;
										intl = false;
										++i;
									}
								}

								String s = null;
								Currency currency = this.getCurrency();
								if (currency != null) {
									boolean[] isChoiceFormat;
									if (plural && pluralCount != null) {
										isChoiceFormat = new boolean[1];
										s = currency.getName(this.symbols.getULocale(), 2, pluralCount, isChoiceFormat);
									} else if (!intl) {
										isChoiceFormat = new boolean[1];
										s = currency.getName(this.symbols.getULocale(), 0, isChoiceFormat);
										if (isChoiceFormat[0]) {
											if (doFormat) {
												FieldPosition pos = new FieldPosition(0);
												this.currencyChoice.format(this.digitList.getDouble(), buffer, pos);
												continue;
											}

											if (this.currencyChoice == null) {
												this.currencyChoice = new ChoiceFormat(s);
											}

											s = String.valueOf('¤');
										}
									} else {
										s = currency.getCurrencyCode();
									}
								} else {
									s = intl
											? this.symbols.getInternationalCurrencySymbol()
											: this.symbols.getCurrencySymbol();
								}

								buffer.append(s);
								continue;
							case '‰' :
								c = this.symbols.getPerMill();
						}

						buffer.append(c);
					}
				}

				return;
			}
		}
	}

	private int appendAffix(StringBuffer buf, boolean isNegative, boolean isPrefix, boolean parseAttr) {
		String affix;
		if (this.currencyChoice != null) {
			affix = null;
			if (isPrefix) {
				affix = isNegative ? this.negPrefixPattern : this.posPrefixPattern;
			} else {
				affix = isNegative ? this.negSuffixPattern : this.posSuffixPattern;
			}

			StringBuffer affixBuf = new StringBuffer();
			this.expandAffix(affix, (String) null, affixBuf, true);
			buf.append(affixBuf);
			return affixBuf.length();
		} else {
			affix = null;
			if (isPrefix) {
				affix = isNegative ? this.negativePrefix : this.positivePrefix;
			} else {
				affix = isNegative ? this.negativeSuffix : this.positiveSuffix;
			}

			if (parseAttr) {
				int offset = affix.indexOf(this.symbols.getCurrencySymbol());
				if (-1 == offset) {
					offset = affix.indexOf(this.symbols.getPercent());
					if (-1 == offset) {
						offset = 0;
					}
				}

				this.formatAffix2Attribute(affix, buf.length() + offset, buf.length() + affix.length());
			}

			buf.append(affix);
			return affix.length();
		}
	}

	private void formatAffix2Attribute(String affix, int begin, int end) {
		if (affix.indexOf(this.symbols.getCurrencySymbol()) > -1) {
			this.addAttribute(Field.CURRENCY, begin, end);
		} else if (affix.indexOf(this.symbols.getMinusSign()) > -1) {
			this.addAttribute(Field.SIGN, begin, end);
		} else if (affix.indexOf(this.symbols.getPercent()) > -1) {
			this.addAttribute(Field.PERCENT, begin, end);
		} else if (affix.indexOf(this.symbols.getPerMill()) > -1) {
			this.addAttribute(Field.PERMILLE, begin, end);
		}

	}

	private void addAttribute(Field field, int begin, int end) {
		FieldPosition pos = new FieldPosition(field);
		pos.setBeginIndex(begin);
		pos.setEndIndex(end);
		this.attributes.add(pos);
	}

	public AttributedCharacterIterator formatToCharacterIterator(Object obj) {
		if (!(obj instanceof Number)) {
			throw new IllegalArgumentException();
		} else {
			Number number = (Number) obj;
			StringBuffer text = null;
			this.attributes.clear();
			if (obj instanceof BigInteger) {
				text = this.format((BigInteger) number, new StringBuffer(), new FieldPosition(0), true);
			} else if (obj instanceof BigDecimal) {
				text = this.format((BigDecimal) number, new StringBuffer(), new FieldPosition(0), true);
			} else if (obj instanceof Double) {
				text = this.format(number.doubleValue(), new StringBuffer(), new FieldPosition(0), true);
			} else if (obj instanceof Integer || obj instanceof Long) {
				text = this.format(number.longValue(), new StringBuffer(), new FieldPosition(0), true);
			}

			AttributedString as = new AttributedString(text.toString());

			for (int i = 0; i < this.attributes.size(); ++i) {
				FieldPosition pos = (FieldPosition) this.attributes.get(i);
				java.text.Format.Field attribute = pos.getFieldAttribute();
				as.addAttribute(attribute, attribute, pos.getBeginIndex(), pos.getEndIndex());
			}

			return as.getIterator();
		}
	}

	private void appendAffixPattern(StringBuffer buffer, boolean isNegative, boolean isPrefix, boolean localized) {
		String affixPat = null;
		if (isPrefix) {
			affixPat = isNegative ? this.negPrefixPattern : this.posPrefixPattern;
		} else {
			affixPat = isNegative ? this.negSuffixPattern : this.posSuffixPattern;
		}

		int j;
		char ch;
		if (affixPat == null) {
			String affix = null;
			if (isPrefix) {
				affix = isNegative ? this.negativePrefix : this.positivePrefix;
			} else {
				affix = isNegative ? this.negativeSuffix : this.positiveSuffix;
			}

			buffer.append('\'');

			for (j = 0; j < affix.length(); ++j) {
				ch = affix.charAt(j);
				if (ch == '\'') {
					buffer.append(ch);
				}

				buffer.append(ch);
			}

			buffer.append('\'');
		} else {
			if (!localized) {
				buffer.append(affixPat);
			} else {
				for (int i = 0; i < affixPat.length(); ++i) {
					ch = affixPat.charAt(i);
					switch (ch) {
						case '%' :
							ch = this.symbols.getPercent();
							break;
						case '\'' :
							j = affixPat.indexOf(39, i + 1);
							if (j < 0) {
								throw new IllegalArgumentException("Malformed affix pattern: " + affixPat);
							}

							buffer.append(affixPat.substring(i, j + 1));
							i = j;
							continue;
						case '-' :
							ch = this.symbols.getMinusSign();
							break;
						case '‰' :
							ch = this.symbols.getPerMill();
					}

					if (ch != this.symbols.getDecimalSeparator() && ch != this.symbols.getGroupingSeparator()) {
						buffer.append(ch);
					} else {
						buffer.append('\'');
						buffer.append(ch);
						buffer.append('\'');
					}
				}
			}

		}
	}

	private String toPattern(boolean localized) {
		StringBuffer result = new StringBuffer();
		char zero = localized ? this.symbols.getZeroDigit() : 48;
		char digit = localized ? this.symbols.getDigit() : 35;
		char sigDigit = 0;
		boolean useSigDig = this.areSignificantDigitsUsed();
		if (useSigDig) {
			sigDigit = localized ? this.symbols.getSignificantDigit() : 64;
		}

		char group = localized ? this.symbols.getGroupingSeparator() : 44;
		int roundingDecimalPos = 0;
		String roundingDigits = null;
		int padPos = this.formatWidth > 0 ? this.padPosition : -1;
		String padSpec = this.formatWidth > 0
				? (new StringBuffer(2)).append(localized ? this.symbols.getPadEscape() : '*').append(this.pad)
						.toString()
				: null;
		int i;
		if (this.roundingIncrementICU != null) {
			i = this.roundingIncrementICU.scale();
			roundingDigits = this.roundingIncrementICU.movePointRight(i).toString();
			roundingDecimalPos = roundingDigits.length() - i;
		}

		for (int part = 0; part < 2; ++part) {
			if (padPos == 0) {
				result.append(padSpec);
			}

			this.appendAffixPattern(result, part != 0, true, localized);
			if (padPos == 1) {
				result.append(padSpec);
			}

			int sub0Start = result.length();
			int g = this.isGroupingUsed() ? Math.max(0, this.groupingSize) : 0;
			if (g > 0 && this.groupingSize2 > 0 && this.groupingSize2 != this.groupingSize) {
				g += this.groupingSize2;
			}

			int maxDig = false;
			int minDig = false;
			int maxSigDig = 0;
			int maxDig;
			int minDig;
			if (useSigDig) {
				minDig = this.getMinimumSignificantDigits();
				maxDig = maxSigDig = this.getMaximumSignificantDigits();
			} else {
				minDig = this.getMinimumIntegerDigits();
				maxDig = this.getMaximumIntegerDigits();
			}

			if (this.useExponentialNotation) {
				if (maxDig > 8) {
					maxDig = 1;
				}
			} else if (useSigDig) {
				maxDig = Math.max(maxDig, g + 1);
			} else {
				maxDig = Math.max(Math.max(g, this.getMinimumIntegerDigits()), roundingDecimalPos) + 1;
			}

			int add;
			for (i = maxDig; i > 0; --i) {
				if (!this.useExponentialNotation && i < maxDig && this.isGroupingPosition(i)) {
					result.append(group);
				}

				if (useSigDig) {
					result.append(maxSigDig >= i && i > maxSigDig - minDig ? sigDigit : digit);
				} else {
					if (roundingDigits != null) {
						add = roundingDecimalPos - i;
						if (add >= 0 && add < roundingDigits.length()) {
							result.append((char) (roundingDigits.charAt(add) - 48 + zero));
							continue;
						}
					}

					result.append(i <= minDig ? zero : digit);
				}
			}

			if (!useSigDig) {
				if (this.getMaximumFractionDigits() > 0 || this.decimalSeparatorAlwaysShown) {
					result.append(localized ? this.symbols.getDecimalSeparator() : '.');
				}

				add = roundingDecimalPos;

				for (i = 0; i < this.getMaximumFractionDigits(); ++i) {
					if (roundingDigits != null && add < roundingDigits.length()) {
						result.append(add < 0 ? zero : (char) (roundingDigits.charAt(add) - 48 + zero));
						++add;
					} else {
						result.append(i < this.getMinimumFractionDigits() ? zero : digit);
					}
				}
			}

			if (this.useExponentialNotation) {
				if (localized) {
					result.append(this.symbols.getExponentSeparator());
				} else {
					result.append('E');
				}

				if (this.exponentSignAlwaysShown) {
					result.append(localized ? this.symbols.getPlusSign() : '+');
				}

				for (i = 0; i < this.minExponentDigits; ++i) {
					result.append(zero);
				}
			}

			if (padSpec != null && !this.useExponentialNotation) {
				add = this.formatWidth - result.length() + sub0Start
						- (part == 0
								? this.positivePrefix.length() + this.positiveSuffix.length()
								: this.negativePrefix.length() + this.negativeSuffix.length());

				while (add > 0) {
					result.insert(sub0Start, digit);
					++maxDig;
					--add;
					if (add > 1 && this.isGroupingPosition(maxDig)) {
						result.insert(sub0Start, group);
						--add;
					}
				}
			}

			if (padPos == 2) {
				result.append(padSpec);
			}

			this.appendAffixPattern(result, part != 0, false, localized);
			if (padPos == 3) {
				result.append(padSpec);
			}

			if (part == 0) {
				if (this.negativeSuffix.equals(this.positiveSuffix)
						&& this.negativePrefix.equals('-' + this.positivePrefix)) {
					break;
				}

				result.append(localized ? this.symbols.getPatternSeparator() : ';');
			}
		}

		return result.toString();
	}

	public void applyPattern(String pattern) {
		this.applyPattern(pattern, false);
	}

	public void applyLocalizedPattern(String pattern) {
		this.applyPattern(pattern, true);
	}

	private void applyPattern(String pattern, boolean localized) {
		this.applyPatternWithoutExpandAffix(pattern, localized);
		this.expandAffixAdjustWidth((String) null);
	}

	private void expandAffixAdjustWidth(String pluralCount) {
		this.expandAffixes(pluralCount);
		if (this.formatWidth > 0) {
			this.formatWidth += this.positivePrefix.length() + this.positiveSuffix.length();
		}

	}

	private void applyPatternWithoutExpandAffix(String pattern, boolean localized) {
		char zeroDigit = '0';
		char sigDigit = '@';
		char groupingSeparator = ',';
		char decimalSeparator = '.';
		char percent = '%';
		char perMill = 8240;
		char digit = '#';
		char separator = ';';
		String exponent = String.valueOf('E');
		char plus = '+';
		char padEscape = '*';
		char minus = '-';
		if (localized) {
			zeroDigit = this.symbols.getZeroDigit();
			sigDigit = this.symbols.getSignificantDigit();
			groupingSeparator = this.symbols.getGroupingSeparator();
			decimalSeparator = this.symbols.getDecimalSeparator();
			percent = this.symbols.getPercent();
			perMill = this.symbols.getPerMill();
			digit = this.symbols.getDigit();
			separator = this.symbols.getPatternSeparator();
			exponent = this.symbols.getExponentSeparator();
			plus = this.symbols.getPlusSign();
			padEscape = this.symbols.getPadEscape();
			minus = this.symbols.getMinusSign();
		}

		char nineDigit = (char) (zeroDigit + 9);
		boolean gotNegative = false;
		int pos = 0;

		for (int part = 0; part < 2 && pos < pattern.length(); ++part) {
			int subpart = 1;
			int sub0Start = 0;
			int sub0Limit = 0;
			int sub2Limit = 0;
			StringBuilder prefix = new StringBuilder();
			StringBuilder suffix = new StringBuilder();
			int decimalPos = -1;
			int multpl = 1;
			int digitLeftCount = 0;
			int zeroDigitCount = 0;
			int digitRightCount = 0;
			int sigDigitCount = 0;
			byte groupingCount = -1;
			byte groupingCount2 = -1;
			int padPos = -1;
			char padChar = 0;
			int incrementPos = -1;
			long incrementVal = 0L;
			byte expDigits = -1;
			boolean expSignAlways = false;
			StringBuilder affix = prefix;

			int start;
			int digitTotalCount;
			int effectiveDecimalPos;
			label490 : for (start = pos; pos < pattern.length(); ++pos) {
				digitTotalCount = pattern.charAt(pos);
				switch (subpart) {
					case 0 :
						if (digitTotalCount == digit) {
							if (zeroDigitCount <= 0 && sigDigitCount <= 0) {
								++digitLeftCount;
							} else {
								++digitRightCount;
							}

							if (groupingCount >= 0 && decimalPos < 0) {
								++groupingCount;
							}
						} else if ((digitTotalCount < zeroDigit || digitTotalCount > nineDigit)
								&& digitTotalCount != sigDigit) {
							if (digitTotalCount == groupingSeparator) {
								if (digitTotalCount == 39 && pos + 1 < pattern.length()) {
									char after = pattern.charAt(pos + 1);
									if (after != digit && (after < zeroDigit || after > nineDigit)) {
										if (after != '\'') {
											if (groupingCount < 0) {
												subpart = 3;
											} else {
												subpart = 2;
												affix = suffix;
												sub0Limit = pos--;
											}
											continue;
										}

										++pos;
									}
								}

								if (decimalPos >= 0) {
									this.patternError("Grouping separator after decimal", pattern);
								}

								groupingCount2 = groupingCount;
								groupingCount = 0;
							} else if (digitTotalCount == decimalSeparator) {
								if (decimalPos >= 0) {
									this.patternError("Multiple decimal separators", pattern);
								}

								decimalPos = digitLeftCount + zeroDigitCount + digitRightCount;
							} else {
								if (pattern.regionMatches(pos, exponent, 0, exponent.length())) {
									if (expDigits >= 0) {
										this.patternError("Multiple exponential symbols", pattern);
									}

									if (groupingCount >= 0) {
										this.patternError("Grouping separator in exponential", pattern);
									}

									pos += exponent.length();
									if (pos < pattern.length() && pattern.charAt(pos) == plus) {
										expSignAlways = true;
										++pos;
									}

									for (expDigits = 0; pos < pattern.length()
											&& pattern.charAt(pos) == zeroDigit; ++pos) {
										++expDigits;
									}

									if (digitLeftCount + zeroDigitCount < 1 && sigDigitCount + digitRightCount < 1
											|| sigDigitCount > 0 && digitLeftCount > 0 || expDigits < 1) {
										this.patternError("Malformed exponential", pattern);
									}
								}

								subpart = 2;
								affix = suffix;
								sub0Limit = pos--;
							}
						} else {
							if (digitRightCount > 0) {
								this.patternError("Unexpected '" + digitTotalCount + '\'', pattern);
							}

							if (digitTotalCount == sigDigit) {
								++sigDigitCount;
							} else {
								++zeroDigitCount;
								if (digitTotalCount != zeroDigit) {
									effectiveDecimalPos = digitLeftCount + zeroDigitCount + digitRightCount;
									if (incrementPos >= 0) {
										while (incrementPos < effectiveDecimalPos) {
											incrementVal *= 10L;
											++incrementPos;
										}
									} else {
										incrementPos = effectiveDecimalPos;
									}

									incrementVal += (long) (digitTotalCount - zeroDigit);
								}
							}

							if (groupingCount >= 0 && decimalPos < 0) {
								++groupingCount;
							}
						}
						break;
					case 1 :
					case 2 :
						if (digitTotalCount != digit && digitTotalCount != groupingSeparator
								&& digitTotalCount != decimalSeparator
								&& (digitTotalCount < zeroDigit || digitTotalCount > nineDigit)
								&& digitTotalCount != sigDigit) {
							if (digitTotalCount == 164) {
								boolean doubled = pos + 1 < pattern.length() && pattern.charAt(pos + 1) == 164;
								if (doubled) {
									++pos;
									affix.append((char) digitTotalCount);
									if (pos + 1 < pattern.length() && pattern.charAt(pos + 1) == 164) {
										++pos;
										affix.append((char) digitTotalCount);
										this.currencySignCount = 3;
									} else {
										this.currencySignCount = 2;
									}
								} else {
									this.currencySignCount = 1;
								}
							} else if (digitTotalCount == 39) {
								if (pos + 1 < pattern.length() && pattern.charAt(pos + 1) == '\'') {
									++pos;
									affix.append((char) digitTotalCount);
								} else {
									subpart += 2;
								}
							} else {
								if (digitTotalCount == separator) {
									if (subpart == 1 || part == 1) {
										this.patternError("Unquoted special character '" + digitTotalCount + '\'',
												pattern);
									}

									sub2Limit = pos++;
									break label490;
								}

								if (digitTotalCount != percent && digitTotalCount != perMill) {
									if (digitTotalCount == minus) {
										digitTotalCount = 45;
									} else if (digitTotalCount == padEscape) {
										if (padPos >= 0) {
											this.patternError("Multiple pad specifiers", pattern);
										}

										if (pos + 1 == pattern.length()) {
											this.patternError("Invalid pad specifier", pattern);
										}

										padPos = pos++;
										padChar = pattern.charAt(pos);
										break;
									}
								} else {
									if (multpl != 1) {
										this.patternError("Too many percent/permille characters", pattern);
									}

									multpl = digitTotalCount == percent ? 100 : 1000;
									digitTotalCount = digitTotalCount == percent ? 37 : 8240;
								}
							}
						} else {
							if (subpart == 1) {
								subpart = 0;
								sub0Start = pos--;
								break;
							}

							if (digitTotalCount == 39) {
								if (pos + 1 < pattern.length() && pattern.charAt(pos + 1) == '\'') {
									++pos;
									affix.append((char) digitTotalCount);
								} else {
									subpart += 2;
								}
								break;
							}

							this.patternError("Unquoted special character '" + digitTotalCount + '\'', pattern);
						}

						affix.append((char) digitTotalCount);
						break;
					case 3 :
					case 4 :
						if (digitTotalCount == 39) {
							if (pos + 1 < pattern.length() && pattern.charAt(pos + 1) == '\'') {
								++pos;
								affix.append((char) digitTotalCount);
							} else {
								subpart -= 2;
							}
						}

						affix.append((char) digitTotalCount);
				}
			}

			if (subpart == 3 || subpart == 4) {
				this.patternError("Unterminated quote", pattern);
			}

			if (sub0Limit == 0) {
				sub0Limit = pattern.length();
			}

			if (sub2Limit == 0) {
				sub2Limit = pattern.length();
			}

			if (zeroDigitCount == 0 && sigDigitCount == 0 && digitLeftCount > 0 && decimalPos >= 0) {
				digitTotalCount = decimalPos;
				if (decimalPos == 0) {
					digitTotalCount = decimalPos + 1;
				}

				digitRightCount = digitLeftCount - digitTotalCount;
				digitLeftCount = digitTotalCount - 1;
				zeroDigitCount = 1;
			}

			if (decimalPos < 0 && digitRightCount > 0 && sigDigitCount == 0
					|| decimalPos >= 0 && (sigDigitCount > 0 || decimalPos < digitLeftCount
							|| decimalPos > digitLeftCount + zeroDigitCount)
					|| groupingCount == 0 || groupingCount2 == 0 || sigDigitCount > 0 && zeroDigitCount > 0
					|| subpart > 2) {
				this.patternError("Malformed pattern", pattern);
			}

			if (padPos >= 0) {
				if (padPos == start) {
					padPos = 0;
				} else if (padPos + 2 == sub0Start) {
					padPos = 1;
				} else if (padPos == sub0Limit) {
					padPos = 2;
				} else if (padPos + 2 == sub2Limit) {
					padPos = 3;
				} else {
					this.patternError("Illegal pad position", pattern);
				}
			}

			if (part == 0) {
				this.posPrefixPattern = this.negPrefixPattern = prefix.toString();
				this.posSuffixPattern = this.negSuffixPattern = suffix.toString();
				this.useExponentialNotation = expDigits >= 0;
				if (this.useExponentialNotation) {
					this.minExponentDigits = expDigits;
					this.exponentSignAlwaysShown = expSignAlways;
				}

				digitTotalCount = digitLeftCount + zeroDigitCount + digitRightCount;
				effectiveDecimalPos = decimalPos >= 0 ? decimalPos : digitTotalCount;
				boolean useSigDig = sigDigitCount > 0;
				this.setSignificantDigitsUsed(useSigDig);
				int scale;
				if (useSigDig) {
					this.setMinimumSignificantDigits(sigDigitCount);
					this.setMaximumSignificantDigits(sigDigitCount + digitRightCount);
				} else {
					scale = effectiveDecimalPos - digitLeftCount;
					this.setMinimumIntegerDigits(scale);
					this.setMaximumIntegerDigits(this.useExponentialNotation ? digitLeftCount + scale : 309);
					this.setMaximumFractionDigits(decimalPos >= 0 ? digitTotalCount - decimalPos : 0);
					this.setMinimumFractionDigits(decimalPos >= 0 ? digitLeftCount + zeroDigitCount - decimalPos : 0);
				}

				this.setGroupingUsed(groupingCount > 0);
				this.groupingSize = groupingCount > 0 ? groupingCount : 0;
				this.groupingSize2 = groupingCount2 > 0 && groupingCount2 != groupingCount ? groupingCount2 : 0;
				this.multiplier = multpl;
				this.setDecimalSeparatorAlwaysShown(decimalPos == 0 || decimalPos == digitTotalCount);
				if (padPos >= 0) {
					this.padPosition = padPos;
					this.formatWidth = sub0Limit - sub0Start;
					this.pad = padChar;
				} else {
					this.formatWidth = 0;
				}

				if (incrementVal != 0L) {
					scale = incrementPos - effectiveDecimalPos;
					this.roundingIncrementICU = com.ibm.icu.math.BigDecimal.valueOf(incrementVal,
							scale > 0 ? scale : 0);
					if (scale < 0) {
						this.roundingIncrementICU = this.roundingIncrementICU.movePointRight(-scale);
					}

					this.setRoundingDouble();
					this.roundingMode = 6;
				} else {
					this.setRoundingIncrement((com.ibm.icu.math.BigDecimal) null);
				}
			} else {
				this.negPrefixPattern = prefix.toString();
				this.negSuffixPattern = suffix.toString();
				gotNegative = true;
			}
		}

		if (pattern.length() == 0) {
			this.posPrefixPattern = this.posSuffixPattern = "";
			this.setMinimumIntegerDigits(0);
			this.setMaximumIntegerDigits(309);
			this.setMinimumFractionDigits(0);
			this.setMaximumFractionDigits(340);
		}

		if (!gotNegative || this.negPrefixPattern.equals(this.posPrefixPattern)
				&& this.negSuffixPattern.equals(this.posSuffixPattern)) {
			this.negSuffixPattern = this.posSuffixPattern;
			this.negPrefixPattern = '-' + this.posPrefixPattern;
		}

		this.setLocale((ULocale) null, (ULocale) null);
		this.formatPattern = pattern;
		if (this.currencySignCount == 3 && this.currencyPluralInfo == null) {
			this.currencyPluralInfo = new CurrencyPluralInfo(this.symbols.getLocale());
		}

	}

	private void setRoundingDouble() {
		if (this.roundingIncrementICU == null) {
			this.roundingDouble = 0.0D;
			this.roundingDoubleReciprocal = 0.0D;
		} else {
			this.roundingDouble = this.roundingIncrementICU.doubleValue();
			this.setRoundingDoubleReciprocal(
					com.ibm.icu.math.BigDecimal.ONE.divide(this.roundingIncrementICU, 6).doubleValue());
		}

	}

	private void patternError(String msg, String pattern) {
		throw new IllegalArgumentException(msg + " in pattern \"" + pattern + '"');
	}

	public void setMaximumIntegerDigits(int newValue) {
		super.setMaximumIntegerDigits(Math.min(newValue, 309));
	}

	public void setMinimumIntegerDigits(int newValue) {
		super.setMinimumIntegerDigits(Math.min(newValue, 309));
	}

	public int getMinimumSignificantDigits() {
		return this.minSignificantDigits;
	}

	public int getMaximumSignificantDigits() {
		return this.maxSignificantDigits;
	}

	public void setMinimumSignificantDigits(int min) {
		if (min < 1) {
			min = 1;
		}

		int max = Math.max(this.maxSignificantDigits, min);
		this.minSignificantDigits = min;
		this.maxSignificantDigits = max;
	}

	public void setMaximumSignificantDigits(int max) {
		if (max < 1) {
			max = 1;
		}

		int min = Math.min(this.minSignificantDigits, max);
		this.minSignificantDigits = min;
		this.maxSignificantDigits = max;
	}

	public boolean areSignificantDigitsUsed() {
		return this.useSignificantDigits;
	}

	public void setSignificantDigitsUsed(boolean useSignificantDigits) {
		this.useSignificantDigits = useSignificantDigits;
	}

	public void setCurrency(Currency theCurrency) {
		super.setCurrency(theCurrency);
		if (theCurrency != null) {
			boolean[] isChoiceFormat = new boolean[1];
			String s = theCurrency.getName(this.symbols.getULocale(), 0, isChoiceFormat);
			this.symbols.setCurrencySymbol(s);
			this.symbols.setInternationalCurrencySymbol(theCurrency.getCurrencyCode());
		}

		if (this.currencySignCount > 0) {
			if (theCurrency != null) {
				this.setRoundingIncrement(theCurrency.getRoundingIncrement());
				int d = theCurrency.getDefaultFractionDigits();
				this.setMinimumFractionDigits(d);
				this.setMaximumFractionDigits(d);
			}

			this.expandAffixes((String) null);
		}

	}

	protected Currency getEffectiveCurrency() {
		Currency c = this.getCurrency();
		if (c == null) {
			c = Currency.getInstance(this.symbols.getInternationalCurrencySymbol());
		}

		return c;
	}

	public void setMaximumFractionDigits(int newValue) {
		super.setMaximumFractionDigits(Math.min(newValue, 340));
	}

	public void setMinimumFractionDigits(int newValue) {
		super.setMinimumFractionDigits(Math.min(newValue, 340));
	}

	public void setParseBigDecimal(boolean value) {
		this.parseBigDecimal = value;
	}

	public boolean isParseBigDecimal() {
		return this.parseBigDecimal;
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		this.attributes.clear();
		stream.defaultWriteObject();
	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		if (this.getMaximumIntegerDigits() > 309) {
			this.setMaximumIntegerDigits(309);
		}

		if (this.getMaximumFractionDigits() > 340) {
			this.setMaximumFractionDigits(340);
		}

		if (this.serialVersionOnStream < 2) {
			this.exponentSignAlwaysShown = false;
			this.setInternalRoundingIncrement((com.ibm.icu.math.BigDecimal) null);
			this.setRoundingDouble();
			this.roundingMode = 6;
			this.formatWidth = 0;
			this.pad = ' ';
			this.padPosition = 0;
			if (this.serialVersionOnStream < 1) {
				this.useExponentialNotation = false;
			}
		}

		if (this.serialVersionOnStream < 3) {
			this.setCurrencyForSymbols();
		}

		this.serialVersionOnStream = 3;
		this.digitList = new DigitList();
		if (this.roundingIncrement != null) {
			this.setInternalRoundingIncrement(new com.ibm.icu.math.BigDecimal(this.roundingIncrement));
			this.setRoundingDouble();
		}

	}

	private void setInternalRoundingIncrement(com.ibm.icu.math.BigDecimal value) {
		this.roundingIncrementICU = value;
		this.roundingIncrement = value == null ? null : value.toBigDecimal();
	}
}