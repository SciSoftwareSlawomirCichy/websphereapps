package com.google.common.base;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.JdkPattern.JdkMatcher;
import java.io.Serializable;
import java.util.regex.Pattern;

@GwtIncompatible
final class JdkPattern extends CommonPattern implements Serializable {
	private final Pattern pattern;
	private static final long serialVersionUID = 0L;

	JdkPattern(Pattern pattern) {
		this.pattern = (Pattern) Preconditions.checkNotNull(pattern);
	}

	public CommonMatcher matcher(CharSequence t) {
		return new JdkMatcher(this.pattern.matcher(t));
	}

	public String pattern() {
		return this.pattern.pattern();
	}

	public int flags() {
		return this.pattern.flags();
	}

	public String toString() {
		return this.pattern.toString();
	}
}