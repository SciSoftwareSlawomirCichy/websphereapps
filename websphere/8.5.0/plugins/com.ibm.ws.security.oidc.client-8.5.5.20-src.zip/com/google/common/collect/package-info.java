@CheckReturnValue
@ParametersAreNonnullByDefault
package com.google.common.collect;

import com.google.errorprone.annotations.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;