package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.Type;

public abstract class ClassInfo {
	public abstract Type getType();

	public abstract Type getSuperType();

	public abstract Type[] getInterfaces();

	public abstract int getModifiers();

	public boolean equals(Object o) {
		if (o == null) {
			return false;
		} else {
			return !(o instanceof ClassInfo) ? false : this.getType().equals(((ClassInfo) o).getType());
		}
	}

	public int hashCode() {
		return this.getType().hashCode();
	}

	public String toString() {
		return this.getType().getClassName();
	}
}