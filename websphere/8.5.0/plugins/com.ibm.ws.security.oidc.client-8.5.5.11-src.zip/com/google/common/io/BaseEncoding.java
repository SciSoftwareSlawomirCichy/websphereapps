package com.google.common.io;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.CharMatcher;
import com.google.common.base.Preconditions;
import com.google.common.io.BaseEncoding.1;
import com.google.common.io.BaseEncoding.2;
import com.google.common.io.BaseEncoding.3;
import com.google.common.io.BaseEncoding.4;
import com.google.common.io.BaseEncoding.5;
import com.google.common.io.BaseEncoding.6;
import com.google.common.io.BaseEncoding.Alphabet;
import com.google.common.io.GwtWorkarounds.ByteInput;
import com.google.common.io.GwtWorkarounds.ByteOutput;
import com.google.common.io.GwtWorkarounds.CharInput;
import com.google.common.io.GwtWorkarounds.CharOutput;
import com.google.common.math.IntMath;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.math.RoundingMode;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;

@Beta
@GwtCompatible(emulated = true)
public abstract class BaseEncoding {
	private static final BaseEncoding BASE64 = new BaseEncoding.StandardBaseEncoding("base64()",
			"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", '=');
	private static final BaseEncoding BASE64_URL = new BaseEncoding.StandardBaseEncoding("base64Url()",
			"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", '=');
	private static final BaseEncoding BASE32 = new BaseEncoding.StandardBaseEncoding("base32()",
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ234567", '=');
	private static final BaseEncoding BASE32_HEX = new BaseEncoding.StandardBaseEncoding("base32Hex()",
			"0123456789ABCDEFGHIJKLMNOPQRSTUV", '=');
	private static final BaseEncoding BASE16 = new BaseEncoding.StandardBaseEncoding("base16()", "0123456789ABCDEF",
			(Character) null);

	public String encode(byte[] bytes) {
		return this.encode((byte[]) Preconditions.checkNotNull(bytes), 0, bytes.length);
	}

	public final String encode(byte[] bytes, int off, int len) {
		Preconditions.checkNotNull(bytes);
		Preconditions.checkPositionIndexes(off, off + len, bytes.length);
		CharOutput result = GwtWorkarounds.stringBuilderOutput(this.maxEncodedSize(len));
		ByteOutput byteOutput = this.encodingStream(result);

		try {
			for (int i = 0; i < len; ++i) {
				byteOutput.write(bytes[off + i]);
			}

			byteOutput.close();
			return result.toString();
		} catch (IOException var7) {
			throw new AssertionError("impossible");
		}
	}

	@GwtIncompatible("Writer,OutputStream")
	public final OutputStream encodingStream(Writer writer) {
		return GwtWorkarounds.asOutputStream(this.encodingStream(GwtWorkarounds.asCharOutput(writer)));
	}

	@GwtIncompatible("Writer,OutputStream")
   public final OutputSupplier<OutputStream> encodingStream(OutputSupplier<? extends Writer> writerSupplier) {
      Preconditions.checkNotNull(writerSupplier);
      return new 1(this, writerSupplier);
   }

	@GwtIncompatible("ByteSink,CharSink")
   public final ByteSink encodingSink(CharSink encodedSink) {
      Preconditions.checkNotNull(encodedSink);
      return new 2(this, encodedSink);
   }

	private static byte[] extract(byte[] result, int length) {
		if (length == result.length) {
			return result;
		} else {
			byte[] trunc = new byte[length];
			System.arraycopy(result, 0, trunc, 0, length);
			return trunc;
		}
	}

	public final byte[] decode(CharSequence chars) {
		CharSequence chars = this.padding().trimTrailingFrom(chars);
		ByteInput decodedInput = this.decodingStream(GwtWorkarounds.asCharInput(chars));
		byte[] tmp = new byte[this.maxDecodedSize(chars.length())];
		int index = 0;

		try {
			for (int i = decodedInput.read(); i != -1; i = decodedInput.read()) {
				tmp[index++] = (byte) i;
			}
		} catch (IOException var6) {
			throw new IllegalArgumentException(var6);
		}

		return extract(tmp, index);
	}

	@GwtIncompatible("Reader,InputStream")
	public final InputStream decodingStream(Reader reader) {
		return GwtWorkarounds.asInputStream(this.decodingStream(GwtWorkarounds.asCharInput(reader)));
	}

	@GwtIncompatible("Reader,InputStream")
   public final InputSupplier<InputStream> decodingStream(InputSupplier<? extends Reader> readerSupplier) {
      Preconditions.checkNotNull(readerSupplier);
      return new 3(this, readerSupplier);
   }

	@GwtIncompatible("ByteSource,CharSource")
   public final ByteSource decodingSource(CharSource encodedSource) {
      Preconditions.checkNotNull(encodedSource);
      return new 4(this, encodedSource);
   }

	abstract int maxEncodedSize(int var1);

	abstract ByteOutput encodingStream(CharOutput var1);

	abstract int maxDecodedSize(int var1);

	abstract ByteInput decodingStream(CharInput var1);

	abstract CharMatcher padding();

	@CheckReturnValue
	public abstract BaseEncoding omitPadding();

	@CheckReturnValue
	public abstract BaseEncoding withPadChar(char var1);

	@CheckReturnValue
	public abstract BaseEncoding withSeparator(String var1, int var2);

	@CheckReturnValue
	public abstract BaseEncoding upperCase();

	@CheckReturnValue
	public abstract BaseEncoding lowerCase();

	public static BaseEncoding base64() {
		return BASE64;
	}

	public static BaseEncoding base64Url() {
		return BASE64_URL;
	}

	public static BaseEncoding base32() {
		return BASE32;
	}

	public static BaseEncoding base32Hex() {
		return BASE32_HEX;
	}

	public static BaseEncoding base16() {
		return BASE16;
	}

	static CharInput ignoringInput(CharInput delegate, CharMatcher toIgnore) {
      Preconditions.checkNotNull(delegate);
      Preconditions.checkNotNull(toIgnore);
      return new 5(delegate, toIgnore);
   }

	static CharOutput separatingOutput(CharOutput delegate, String separator, int afterEveryChars) {
      Preconditions.checkNotNull(delegate);
      Preconditions.checkNotNull(separator);
      Preconditions.checkArgument(afterEveryChars > 0);
      return new 6(afterEveryChars, separator, delegate);
   }

	static final class SeparatedBaseEncoding extends BaseEncoding {
		private final BaseEncoding delegate;
		private final String separator;
		private final int afterEveryChars;
		private final CharMatcher separatorChars;

		SeparatedBaseEncoding(BaseEncoding delegate, String separator, int afterEveryChars) {
			this.delegate = (BaseEncoding) Preconditions.checkNotNull(delegate);
			this.separator = (String) Preconditions.checkNotNull(separator);
			this.afterEveryChars = afterEveryChars;
			Preconditions.checkArgument(afterEveryChars > 0, "Cannot add a separator after every %s chars",
					new Object[]{afterEveryChars});
			this.separatorChars = CharMatcher.anyOf(separator).precomputed();
		}

		CharMatcher padding() {
			return this.delegate.padding();
		}

		int maxEncodedSize(int bytes) {
			int unseparatedSize = this.delegate.maxEncodedSize(bytes);
			return unseparatedSize + this.separator.length()
					* IntMath.divide(Math.max(0, unseparatedSize - 1), this.afterEveryChars, RoundingMode.FLOOR);
		}

		ByteOutput encodingStream(CharOutput output) {
			return this.delegate.encodingStream(separatingOutput(output, this.separator, this.afterEveryChars));
		}

		int maxDecodedSize(int chars) {
			return this.delegate.maxDecodedSize(chars);
		}

		ByteInput decodingStream(CharInput input) {
			return this.delegate.decodingStream(ignoringInput(input, this.separatorChars));
		}

		public BaseEncoding omitPadding() {
			return this.delegate.omitPadding().withSeparator(this.separator, this.afterEveryChars);
		}

		public BaseEncoding withPadChar(char padChar) {
			return this.delegate.withPadChar(padChar).withSeparator(this.separator, this.afterEveryChars);
		}

		public BaseEncoding withSeparator(String separator, int afterEveryChars) {
			throw new UnsupportedOperationException("Already have a separator");
		}

		public BaseEncoding upperCase() {
			return this.delegate.upperCase().withSeparator(this.separator, this.afterEveryChars);
		}

		public BaseEncoding lowerCase() {
			return this.delegate.lowerCase().withSeparator(this.separator, this.afterEveryChars);
		}

		public String toString() {
			return this.delegate.toString() + ".withSeparator(\"" + this.separator + "\", " + this.afterEveryChars
					+ ")";
		}
	}

	static final class StandardBaseEncoding extends BaseEncoding {
		private final Alphabet alphabet;
		@Nullable
		private final Character paddingChar;
		private transient BaseEncoding upperCase;
		private transient BaseEncoding lowerCase;

		StandardBaseEncoding(String name, String alphabetChars, @Nullable Character paddingChar) {
			this(new Alphabet(name, alphabetChars.toCharArray()), paddingChar);
		}

		StandardBaseEncoding(Alphabet alphabet, Character paddingChar) {
			this.alphabet = (Alphabet) Preconditions.checkNotNull(alphabet);
			Preconditions.checkArgument(paddingChar == null || !alphabet.matches(paddingChar),
					"Padding character %s was already in alphabet", new Object[]{paddingChar});
			this.paddingChar = paddingChar;
		}

		CharMatcher padding() {
			return this.paddingChar == null ? CharMatcher.NONE : CharMatcher.is(this.paddingChar);
		}

		int maxEncodedSize(int bytes) {
			return this.alphabet.charsPerChunk
					* IntMath.divide(bytes, this.alphabet.bytesPerChunk, RoundingMode.CEILING);
		}

		ByteOutput encodingStream(CharOutput out) {
         Preconditions.checkNotNull(out);
         return new com.google.common.io.BaseEncoding.StandardBaseEncoding.1(this, out);
      }

		int maxDecodedSize(int chars) {
			return (int) (((long) this.alphabet.bitsPerChar * (long) chars + 7L) / 8L);
		}

		ByteInput decodingStream(CharInput reader) {
         Preconditions.checkNotNull(reader);
         return new com.google.common.io.BaseEncoding.StandardBaseEncoding.2(this, reader);
      }

		public BaseEncoding omitPadding() {
			return this.paddingChar == null
					? this
					: new BaseEncoding.StandardBaseEncoding(this.alphabet, (Character) null);
		}

		public BaseEncoding withPadChar(char padChar) {
			return 8 % this.alphabet.bitsPerChar != 0 && (this.paddingChar == null || this.paddingChar != padChar)
					? new BaseEncoding.StandardBaseEncoding(this.alphabet, padChar)
					: this;
		}

		public BaseEncoding withSeparator(String separator, int afterEveryChars) {
			Preconditions.checkNotNull(separator);
			Preconditions.checkArgument(this.padding().or(this.alphabet).matchesNoneOf(separator),
					"Separator cannot contain alphabet or padding characters");
			return new BaseEncoding.SeparatedBaseEncoding(this, separator, afterEveryChars);
		}

		public BaseEncoding upperCase() {
			BaseEncoding result = this.upperCase;
			if (result == null) {
				Alphabet upper = this.alphabet.upperCase();
				result = this.upperCase = upper == this.alphabet
						? this
						: new BaseEncoding.StandardBaseEncoding(upper, this.paddingChar);
			}

			return result;
		}

		public BaseEncoding lowerCase() {
			BaseEncoding result = this.lowerCase;
			if (result == null) {
				Alphabet lower = this.alphabet.lowerCase();
				result = this.lowerCase = lower == this.alphabet
						? this
						: new BaseEncoding.StandardBaseEncoding(lower, this.paddingChar);
			}

			return result;
		}

		public String toString() {
			StringBuilder builder = new StringBuilder("BaseEncoding.");
			builder.append(this.alphabet.toString());
			if (8 % this.alphabet.bitsPerChar != 0) {
				if (this.paddingChar == null) {
					builder.append(".omitPadding()");
				} else {
					builder.append(".withPadChar(").append(this.paddingChar).append(')');
				}
			}

			return builder.toString();
		}
	}
}