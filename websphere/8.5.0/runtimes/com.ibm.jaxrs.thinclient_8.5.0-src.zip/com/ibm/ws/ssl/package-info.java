package com.ibm.ws.ssl;

interface package-info {
}