package com.ibm.ejs.container;

import com.ibm.ws.csi.TimerTaskInfo;
import com.ibm.ws.scheduler.TaskInfoRegistry;

public class EJBTimerTaskInfoService implements TaskInfoRegistry {
	public Class getTaskInfoImplementation() {
		return TimerTaskInfoImpl.class;
	}

	public Class getTaskInfoInterface() {
		return TimerTaskInfo.class;
	}

	public int getID() {
		return 8448;
	}

	public String getDescription() {
		return "EJB Timer Service Task";
	}
}