package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ContextPoolType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class ContextPoolTypeImpl extends EDataObjectImpl implements ContextPoolType {
	protected static final boolean ENABLED_EDEFAULT = true;
	protected boolean enabled = true;
	protected boolean enabledESet = false;
	protected static final int INIT_POOL_SIZE_EDEFAULT = 1;
	protected int initPoolSize = 1;
	protected boolean initPoolSizeESet = false;
	protected static final int MAX_POOL_SIZE_EDEFAULT = 0;
	protected int maxPoolSize = 0;
	protected boolean maxPoolSizeESet = false;
	protected static final int POOL_TIME_OUT_EDEFAULT = 0;
	protected int poolTimeOut = 0;
	protected boolean poolTimeOutESet = false;
	protected static final int POOL_WAIT_TIME_EDEFAULT = 3000;
	protected int poolWaitTime = 3000;
	protected boolean poolWaitTimeESet = false;
	protected static final int PREF_POOL_SIZE_EDEFAULT = 3;
	protected int prefPoolSize = 3;
	protected boolean prefPoolSizeESet = false;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getContextPoolType();
	}

	public boolean isEnabled() {
		return this.enabled;
	}

	public void setEnabled(boolean var1) {
		boolean var2 = this.enabled;
		this.enabled = var1;
		boolean var3 = this.enabledESet;
		this.enabledESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.enabled, !var3));
		}

	}

	public void unsetEnabled() {
		boolean var1 = this.enabled;
		boolean var2 = this.enabledESet;
		this.enabled = true;
		this.enabledESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 0, var1, true, var2));
		}

	}

	public boolean isSetEnabled() {
		return this.enabledESet;
	}

	public int getInitPoolSize() {
		return this.initPoolSize;
	}

	public void setInitPoolSize(int var1) {
		int var2 = this.initPoolSize;
		this.initPoolSize = var1;
		boolean var3 = this.initPoolSizeESet;
		this.initPoolSizeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.initPoolSize, !var3));
		}

	}

	public void unsetInitPoolSize() {
		int var1 = this.initPoolSize;
		boolean var2 = this.initPoolSizeESet;
		this.initPoolSize = 1;
		this.initPoolSizeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 1, var1, 1, var2));
		}

	}

	public boolean isSetInitPoolSize() {
		return this.initPoolSizeESet;
	}

	public int getMaxPoolSize() {
		return this.maxPoolSize;
	}

	public void setMaxPoolSize(int var1) {
		int var2 = this.maxPoolSize;
		this.maxPoolSize = var1;
		boolean var3 = this.maxPoolSizeESet;
		this.maxPoolSizeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var2, this.maxPoolSize, !var3));
		}

	}

	public void unsetMaxPoolSize() {
		int var1 = this.maxPoolSize;
		boolean var2 = this.maxPoolSizeESet;
		this.maxPoolSize = 0;
		this.maxPoolSizeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 2, var1, 0, var2));
		}

	}

	public boolean isSetMaxPoolSize() {
		return this.maxPoolSizeESet;
	}

	public int getPoolTimeOut() {
		return this.poolTimeOut;
	}

	public void setPoolTimeOut(int var1) {
		int var2 = this.poolTimeOut;
		this.poolTimeOut = var1;
		boolean var3 = this.poolTimeOutESet;
		this.poolTimeOutESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.poolTimeOut, !var3));
		}

	}

	public void unsetPoolTimeOut() {
		int var1 = this.poolTimeOut;
		boolean var2 = this.poolTimeOutESet;
		this.poolTimeOut = 0;
		this.poolTimeOutESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 3, var1, 0, var2));
		}

	}

	public boolean isSetPoolTimeOut() {
		return this.poolTimeOutESet;
	}

	public int getPoolWaitTime() {
		return this.poolWaitTime;
	}

	public void setPoolWaitTime(int var1) {
		int var2 = this.poolWaitTime;
		this.poolWaitTime = var1;
		boolean var3 = this.poolWaitTimeESet;
		this.poolWaitTimeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var2, this.poolWaitTime, !var3));
		}

	}

	public void unsetPoolWaitTime() {
		int var1 = this.poolWaitTime;
		boolean var2 = this.poolWaitTimeESet;
		this.poolWaitTime = 3000;
		this.poolWaitTimeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 4, var1, 3000, var2));
		}

	}

	public boolean isSetPoolWaitTime() {
		return this.poolWaitTimeESet;
	}

	public int getPrefPoolSize() {
		return this.prefPoolSize;
	}

	public void setPrefPoolSize(int var1) {
		int var2 = this.prefPoolSize;
		this.prefPoolSize = var1;
		boolean var3 = this.prefPoolSizeESet;
		this.prefPoolSizeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 5, var2, this.prefPoolSize, !var3));
		}

	}

	public void unsetPrefPoolSize() {
		int var1 = this.prefPoolSize;
		boolean var2 = this.prefPoolSizeESet;
		this.prefPoolSize = 3;
		this.prefPoolSizeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 5, var1, 3, var2));
		}

	}

	public boolean isSetPrefPoolSize() {
		return this.prefPoolSizeESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.isEnabled() ? Boolean.TRUE : Boolean.FALSE;
			case 1 :
				return new Integer(this.getInitPoolSize());
			case 2 :
				return new Integer(this.getMaxPoolSize());
			case 3 :
				return new Integer(this.getPoolTimeOut());
			case 4 :
				return new Integer(this.getPoolWaitTime());
			case 5 :
				return new Integer(this.getPrefPoolSize());
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setEnabled((Boolean) var2);
				return;
			case 1 :
				this.setInitPoolSize((Integer) var2);
				return;
			case 2 :
				this.setMaxPoolSize((Integer) var2);
				return;
			case 3 :
				this.setPoolTimeOut((Integer) var2);
				return;
			case 4 :
				this.setPoolWaitTime((Integer) var2);
				return;
			case 5 :
				this.setPrefPoolSize((Integer) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.unsetEnabled();
				return;
			case 1 :
				this.unsetInitPoolSize();
				return;
			case 2 :
				this.unsetMaxPoolSize();
				return;
			case 3 :
				this.unsetPoolTimeOut();
				return;
			case 4 :
				this.unsetPoolWaitTime();
				return;
			case 5 :
				this.unsetPrefPoolSize();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.isSetEnabled();
			case 1 :
				return this.isSetInitPoolSize();
			case 2 :
				return this.isSetMaxPoolSize();
			case 3 :
				return this.isSetPoolTimeOut();
			case 4 :
				return this.isSetPoolWaitTime();
			case 5 :
				return this.isSetPrefPoolSize();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (enabled: ");
			if (this.enabledESet) {
				var1.append(this.enabled);
			} else {
				var1.append("<unset>");
			}

			var1.append(", initPoolSize: ");
			if (this.initPoolSizeESet) {
				var1.append(this.initPoolSize);
			} else {
				var1.append("<unset>");
			}

			var1.append(", maxPoolSize: ");
			if (this.maxPoolSizeESet) {
				var1.append(this.maxPoolSize);
			} else {
				var1.append("<unset>");
			}

			var1.append(", poolTimeOut: ");
			if (this.poolTimeOutESet) {
				var1.append(this.poolTimeOut);
			} else {
				var1.append("<unset>");
			}

			var1.append(", poolWaitTime: ");
			if (this.poolWaitTimeESet) {
				var1.append(this.poolWaitTime);
			} else {
				var1.append("<unset>");
			}

			var1.append(", prefPoolSize: ");
			if (this.prefPoolSizeESet) {
				var1.append(this.prefPoolSize);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}