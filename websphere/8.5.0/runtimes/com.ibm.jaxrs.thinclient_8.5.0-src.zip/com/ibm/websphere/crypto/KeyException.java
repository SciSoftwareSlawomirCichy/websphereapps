package com.ibm.websphere.crypto;

public class KeyException extends Exception {
	public KeyException() {
	}

	public KeyException(Exception e) {
		super(e);
	}

	public KeyException(String message) {
		super(message);
	}

	public KeyException(String message, Exception e) {
		super(message, e);
	}
}