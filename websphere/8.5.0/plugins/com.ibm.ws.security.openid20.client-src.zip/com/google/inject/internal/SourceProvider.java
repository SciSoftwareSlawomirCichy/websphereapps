package com.google.inject.internal;

import java.util.List;

public class SourceProvider {
	public static final Object UNKNOWN_SOURCE = "[unknown source]";
	private final ImmutableSet<String> classNamesToSkip;
	public static final SourceProvider DEFAULT_INSTANCE = new SourceProvider(
			ImmutableSet.of(SourceProvider.class.getName()));

	public SourceProvider() {
		this.classNamesToSkip = ImmutableSet.of(SourceProvider.class.getName());
	}

	private SourceProvider(Iterable<String> classesToSkip) {
		this.classNamesToSkip = ImmutableSet.copyOf(classesToSkip);
	}

	public SourceProvider plusSkippedClasses(Class... moreClassesToSkip) {
		return new SourceProvider(Iterables.concat(this.classNamesToSkip, asStrings(moreClassesToSkip)));
	}

	private static List<String> asStrings(Class... classes) {
		List<String> strings = Lists.newArrayList();
		Class[] arr$ = classes;
		int len$ = classes.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Class c = arr$[i$];
			strings.add(c.getName());
		}

		return strings;
	}

	public StackTraceElement get() {
		StackTraceElement[] arr$ = (new Throwable()).getStackTrace();
		int len$ = arr$.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			StackTraceElement element = arr$[i$];
			String className = element.getClassName();
			if (!this.classNamesToSkip.contains(className)) {
				return element;
			}
		}

		throw new AssertionError();
	}
}