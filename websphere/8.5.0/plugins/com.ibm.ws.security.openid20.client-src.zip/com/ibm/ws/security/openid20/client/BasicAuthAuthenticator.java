package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.security.WebTrustAssociationFailedException;
import com.ibm.ws.security.openid20.client.BasicAuthAuthenticator.1;
import com.ibm.ws.security.openid20.util.MessageHelper;
import com.ibm.ws.security.openid20.util.OidUtil;
import com.ibm.ws.util.Base64;
import com.ibm.wsspi.security.tai.TAIResult;
import java.math.BigInteger;
import java.security.AccessController;
import java.security.SecureRandom;
import java.util.Hashtable;
import javax.security.auth.Subject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BasicAuthAuthenticator {
	private static final TraceComponent tc = Tr.register(BasicAuthAuthenticator.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private static SecureRandom srandom = new SecureRandom();

	public static TAIResult authenticate(HttpServletRequest req, HttpServletResponse res, OpenIDClientConfig config)
			throws WebTrustAssociationFailedException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "authenticate(req[" + OidUtil.getObjState(req) + "], res[" + OidUtil.getObjState(res)
					+ "], config[" + OidUtil.getObjState(config) + "])");
		}

		String[] basicAuth = null;

		String userSecurityName;
		try {
			basicAuth = extractBasicAuthHeader(req);
		} catch (OpenIDRelyingPartyException var7) {
			userSecurityName = MessageHelper.getMessage("security.openid20.client.invalidbasicauthheader");
			Tr.error(tc, userSecurityName);
			throw new WebTrustAssociationFailedException(userSecurityName);
		}

		String realmName = config.getRealmName();
		if (basicAuth == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Request does not have basic Auth header.. ignoring basic auth");
			}

			if (!config.isTryOpenIDIfBasicAuthFails()) {
				userSecurityName = "Request does not have basic Auth header";
				res.addHeader("WWW-Authenticate", "Bearer realm=\"" + realmName + "\", error=" + userSecurityName);
				return TAIResult.create(401);
			} else {
				return null;
			}
		} else {
			try {
				req.login(basicAuth[0], basicAuth[1]);
				userSecurityName = req.getUserPrincipal().getName();
				if (userSecurityName != null) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Authentication using Basic Auth for user " + basicAuth[0] + " successful");
					}

					return TAIResult.create(200, userSecurityName, getSubject(userSecurityName));
				} else {
					throw new ServletException("userSecurityName is null");
				}
			} catch (ServletException var8) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Failed to authenticate using basic auth token " + var8.getMessage());
				}

				if (!config.isTryOpenIDIfBasicAuthFails()) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "user authentication for " + basicAuth[0] + " failed... attempting OpenID");
					}

					String error = "Failed to authenticate using basic auth token";
					res.addHeader("WWW-Authenticate", "Bearer realm=\"" + realmName + "\", error=" + error);
					return TAIResult.create(401);
				} else {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "authenticate returns [null]");
					}

					return null;
				}
			}
		}
	}

	private static String[] extractBasicAuthHeader(HttpServletRequest req) throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "extractBasicAuthHeader(req[" + OidUtil.getObjState(req) + "])");
		}

		String[] basicAuth = null;
		String authHeader = req.getHeader("Authorization");
		if (authHeader != null && authHeader.startsWith("Basic")) {
			String token = authHeader.substring("Basic".length());
			if (token.length() > 0) {
				Object var4 = null;

				byte[] decodedBasicAuth;
				try {
					decodedBasicAuth = Base64.decode(token);
				} catch (Exception var7) {
					String msg = "Failed to decode the basic auth token, exception: " + var7.getMessage();
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, msg);
					}

					throw new OpenIDRelyingPartyException(msg);
				}

				basicAuth = OidUtil.split(new String(decodedBasicAuth), ":", 2);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "extractBasicAuthHeader returns [" + OidUtil.getObjState(basicAuth) + "]");
		}

		return basicAuth;
	}

	private static Subject getSubject(String usn) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSubject(usn[" + usn + "])");
		}

		Subject jaasSubject = new Subject();
		Hashtable<String, Object> credentials = new Hashtable();
		credentials.put("com.ibm.wsspi.security.cred.cacheKey", usn + (new BigInteger(130, srandom)).toString(32));
		addToSubjectAsPublicCredentials(jaasSubject, credentials);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSubject returns [" + OidUtil.getObjState(jaasSubject) + "]");
		}

		return jaasSubject;
	}

	private static void addToSubjectAsPublicCredentials(Subject subject, Object credentials) {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "addToSubjectAsPublicCredentials");
      }

      if (subject != null) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Adding public cred");
         }

         AccessController.doPrivileged(new 1(subject, credentials));
      } else if (tc.isDebugEnabled()) {
         Tr.debug(tc, "Subject is null");
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "addToSubjectAsPublicCredentials");
      }

   }
}