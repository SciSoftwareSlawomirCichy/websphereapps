package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.config.IncidentForwarder;

public interface LoggedIncidentForwarder extends IncidentForwarder {
	boolean processLoggedIncident();
}