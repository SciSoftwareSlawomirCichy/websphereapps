package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_de extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: Es wurde eine Inkonsistenz bei den Build-Stufen der installierten Clientkomponenten des Anwendungsservers gefunden. Die installierte Build-Stufe der Clientkomponente {0} ist {1}, und die Clientkomponente {2} hat die Build-Stufe {3}."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: Eine Inkonsistenz bei den Build-Stufen der installierten Clientkomponenten des Anwendungsservers verhindert eine weitere Ausführung."},
			{"EXCP_CWSJE0003E",
					"CWSJE0003E: Der Zugriff auf die Ressource {1} ist nicht möglich, weil die Ausnahme {0} eingetreten ist."}};

	public Object[][] getContents() {
		return resources;
	}
}