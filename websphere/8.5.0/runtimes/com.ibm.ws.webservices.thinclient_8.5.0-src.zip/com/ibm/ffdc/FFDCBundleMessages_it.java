package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_it extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: Programma di formattazione FFDC {0} aggiunto"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Il motore di analisi utilizza il database: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: Impossibile risolvere il motore di analisi:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: Programma di raccolta dati FFDC {0} aggiunto"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: Programma di raccolta dati FFDC {0} rimosso"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: Incidente FFDC emesso in SystemErr: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC in modalità failsafe, controllare gli errori {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: Programma di inoltro incidente FFDC {0} aggiunto"},
			{"FFDCForwarderRemoved", "FFDC1014I: Programma di inoltro incidente FFDC {0} rimosso"},
			{"FFDCIncidentEmitted", "FFDC1003I: Incidente FFDC emesso in {0} {1} {2}"},
			{"FFDCProviderAborted", "FFDC1000I: Provider FFDC {0} interrotto; segue l''eccezione"},
			{"FFDCProviderAbortedE", "FFDC1001I: Provider FFDC interrotto con eccezione {0}"},
			{"FFDCProviderException", "FFDC1008I: Eccezione relativa al provider FFDC:"},
			{"FFDCProviderInstalled", "FFDC1007I: Provider FFDC installato: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: Programma di formattazione FFDC {0} rimosso"}};

	public Object[][] getContents() {
		return resources;
	}
}