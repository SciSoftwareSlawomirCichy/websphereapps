package com.google.inject;

import com.google.inject.Scopes.1;
import com.google.inject.Scopes.2;
import com.google.inject.internal.Errors;
import com.google.inject.internal.InternalFactory;
import com.google.inject.internal.Scoping;
import java.lang.annotation.Annotation;

public class Scopes {
	public static final Scope SINGLETON = new 1();
	public static final Scope NO_SCOPE = new 2();

	static <T> InternalFactory<? extends T> scope(Key<T> key, InjectorImpl injector,
			InternalFactory<? extends T> creator, Scoping scoping) {
		if (scoping.isNoScope()) {
			return creator;
		} else {
			Scope scope = scoping.getScopeInstance();
			Provider<T> scoped = scope.scope(key, new ProviderToInternalFactoryAdapter(injector, creator));
			return new InternalFactoryToProviderAdapter(Initializables.of(scoped));
		}
	}

	static Scoping makeInjectable(Scoping scoping, InjectorImpl injector, Errors errors) {
		Class<? extends Annotation> scopeAnnotation = scoping.getScopeAnnotation();
		if (scopeAnnotation == null) {
			return scoping;
		} else {
			Scope scope = injector.state.getScope(scopeAnnotation);
			if (scope != null) {
				return Scoping.forInstance(scope);
			} else {
				errors.scopeNotFound(scopeAnnotation);
				return Scoping.UNSCOPED;
			}
		}
	}
}