package com.ibm.ws.wim.pluginmanager;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.PluginConfigException;
import com.ibm.websphere.wim.exception.SubscriberCriticalException;
import com.ibm.websphere.wim.exception.SubscriberException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.pluginmanager.context.ContextFactory;
import com.ibm.websphere.wim.pluginmanager.context.EmitterExceptionContext;
import com.ibm.websphere.wim.pluginmanager.context.ExceptionContext;
import com.ibm.websphere.wim.pluginmanager.context.InlineExitContext;
import com.ibm.websphere.wim.pluginmanager.context.ModificationListContext;
import com.ibm.websphere.wim.pluginmanager.context.ModificationSubscriberContext;
import com.ibm.websphere.wim.pluginmanager.context.NotificationListContext;
import com.ibm.websphere.wim.pluginmanager.context.NotificationSubscriberContext;
import com.ibm.websphere.wim.pluginmanager.context.PluginManagerConstants;
import com.ibm.websphere.wim.pluginmanager.context.PostExitContext;
import com.ibm.websphere.wim.pluginmanager.context.PreExitContext;
import com.ibm.websphere.wim.pluginmanager.context.SubscriberExecContext;
import com.ibm.websphere.wim.pluginmanager.context.SubscriberExecStatus;
import com.ibm.websphere.wim.pluginmanager.context.UIDContext;
import com.ibm.websphere.wim.pluginmanager.context.impl.ContextFactoryImpl;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.util.Routines;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import com.ibm.ws.wim.pluginmanager.PluginManager.1;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.wsspi.wim.pluginmanager.ModificationSubscriber;
import com.ibm.wsspi.wim.pluginmanager.NotificationSubscriber;
import com.ibm.wsspi.wim.pluginmanager.Subscriber;
import commonj.sdo.DataObject;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PluginManager {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static Map<String, PluginManager> singleton;
	private PGConfigManager configManager;
	private PGSubscriptionManager subscriptionManager;
	private static Map<String, ContextFactory> expContextFactory;
	private ConcurrentHashMap transInProcess;
	private boolean inShutdownProcess;

	private PluginManager() throws PluginConfigException, WIMException {
		this.initPluginManagerConfiguration();
		this.inShutdownProcess = false;
		this.transInProcess = new ConcurrentHashMap();
	}

	private void initPluginManagerConfiguration() throws PluginConfigException, WIMException {
      ConfigurationProviderType var1 = (ConfigurationProviderType)ProfileSecurityManager.singleton().runAsSuperUser(new 1(this));
      this.configManager = PGConfigManager.getConfigurationManager();
      this.subscriptionManager = PGSubscriptionManager.getSubscriptionManager();
      PluginManagerConfigurationType var2 = var1.getPluginManagerConfiguration();
      if (var2 == null) {
         var2 = var1.createPluginManagerConfiguration();
         this.initPluginManager(var2, true);
      } else {
         this.initPluginManager(var2, false);
      }

   }

	public void initPluginManager(PluginManagerConfigurationType var1, boolean var2) throws PluginConfigException {
		trcLogger.entering(CLASSNAME, "initPluginManager", "emptyConfig=" + var2);
		if (var2) {
			var1.createTopicRegistrationList();
			var1.createTopicSubscriberList();
			TopicRegistrationList var4 = var1.getTopicRegistrationList();
			Vector var5 = DefaultPluginManagerConfig.getDefaultVectorList();
			Iterator var6 = var5.iterator();

			while (var6.hasNext()) {
				String var7 = (String) var6.next();
				TopicEmitter var8 = var4.createTopicEmitter();
				var8.setTopicEmitterName(var7);
			}
		}

		this.configManager.initializeConfiguration(var1, this.subscriptionManager);
		trcLogger.exiting(CLASSNAME, "initPluginManager");
	}

	public void shutdownPluginManager() {
		this.inShutdownProcess = true;
		this.subscriptionManager.shutdownSubscribers();
	}

	public static PluginManager getPluginManager() throws PluginConfigException, WIMException {
		String var0 = DomainManagerUtils.getDomainId();
		if (singleton.get(var0) == null) {
			singleton.put(var0, new PluginManager());
			expContextFactory.put(var0, new ContextFactoryImpl());
		}

		return (PluginManager) singleton.get(var0);
	}

	public static PluginManager singleton() throws PluginConfigException, WIMException {
		return getPluginManager();
	}

	private ModificationSubscriberContext createModificationSubContext(EmitterExceptionContext var1, String var2,
			int var3, Throwable var4) {
		ModificationSubscriberContext var5 = null;
		SubscriberExecContext var6 = null;
		ModificationListContext var7 = null;
		String var8 = var1.getTopicEmitterName();
		switch (var3) {
			case 0 :
				PreExitContext var11 = var1.getPreExit();
				var11.setFailedSubscriber(var8);
				var11.setIsSuccessful(false);
				var7 = var11.getModificationListContext();
				var5 = var7.createSubscriberExecuteContext();
				break;
			case 1 :
				InlineExitContext var10 = var1.getInlineExitContext(var2);
				var10.setFailedSubscriber(var8);
				var10.setIsSuccessful(false);
				var7 = var10.getModificationListContext();
				var5 = var7.createSubscriberExecuteContext();
				break;
			case 2 :
				PostExitContext var9 = var1.getPostExit();
				var9.setFailedSubscriber(var8);
				var9.setIsSuccessful(false);
				var7 = var9.getModificationListContext();
				var5 = var7.createSubscriberExecuteContext();
		}

		var1.setAnyPluginFailure(false);
		var5.setSubscriberName(var8);
		var6 = var5.createExecuteContext();
		if (var4 instanceof SubscriberException) {
			this.setExceptionContext(var6, (SubscriberException) var4);
		} else {
			var6.setReasonString(var4.getMessage());
			var6.setExceptionMsg(Routines.getErrorMessage(var4));
			var6.setStatus(SubscriberExecStatus.FAILURE_LITERAL);
		}

		return var5;
	}

	private NotificationSubscriberContext createNotificationSubContext(EmitterExceptionContext var1, int var2,
			String var3, Throwable var4) {
		NotificationListContext var5 = null;
		NotificationSubscriberContext var6 = null;
		SubscriberExecContext var7 = null;
		switch (var2) {
			case 0 :
				PreExitContext var9 = var1.getPreExit();
				var9.setFailedSubscriber(var3);
				var9.setIsSuccessful(false);
				var5 = var9.getNotificationListContext();
				var6 = var5.createSubscriberExecuteContext();
				break;
			case 2 :
				PostExitContext var8 = var1.getPostExit();
				var8.setFailedSubscriber(var3);
				var8.setIsSuccessful(false);
				var5 = var8.getNotificationListContext();
				var6 = var5.createSubscriberExecuteContext();
		}

		var6.setSubscriberName(var3);
		var7 = var6.createExecuteContext();
		if (var4 instanceof SubscriberException) {
			this.setExceptionContext(var7, (SubscriberException) var4);
		} else {
			var7.setReasonString(var4.getMessage());
			var7.setExceptionMsg(Routines.getErrorMessage(var4));
			var7.setStatus(SubscriberExecStatus.FAILURE_LITERAL);
		}

		return var6;
	}

	private void recoveryExecSubscriberList(HashSet var1, int var2, String var3, String var4, String var5,
			ExceptionContext var6) {
		String var7 = "recoveryExecSubscriberList";
		Iterator var8 = var1.iterator();

		while (var8.hasNext()) {
			SubscriberRealmInfo var9 = (SubscriberRealmInfo) var8.next();
			Subscriber var10 = var9.getSubscriber();
			String var11 = var9.getSubscriberName();
			Routines.logMessage(trcLogger, CLASSNAME, var7, Level.FINEST, var11);

			try {
				var10.recovery(var4, var2, var3, var6);
			} catch (SubscriberException var14) {
				StringBuffer var13 = new StringBuffer();
				var13.append("Exception occured during recovery of subscriber '");
				var13.append(var10.getSubscriberName());
				var13.append("' of Topic-Emitter '").append(var4).append("'.");
				Routines.logException(trcLogger, CLASSNAME, var7, Level.FINE, var13.toString(), var14);
			}
		}

	}

	private NotificationListContext getNotificationListContext(int var1, EmitterExceptionContext var2) {
		NotificationListContext var3 = null;
		switch (var1) {
			case 0 :
				var3 = var2.getPreExit().getNotificationListContext();
				if (var3 == null) {
					var3 = var2.getPreExit().createNotificationListContext();
				}
				break;
			case 2 :
				var3 = var2.getPostExit().getNotificationListContext();
				if (var3 == null) {
					var3 = var2.getPostExit().createNotificationListContext();
				}
		}

		return var3;
	}

	private ModificationListContext getModificationListContext(int var1, EmitterExceptionContext var2, String var3) {
		ModificationListContext var4 = null;
		switch (var1) {
			case 0 :
				var4 = var2.getPreExit().getModificationListContext();
				if (var4 == null) {
					var4 = var2.getPreExit().createModificationListContext();
				}
				break;
			case 1 :
				var4 = var2.getInlineExitContext(var3).getModificationListContext();
				if (var4 == null) {
					var4 = var2.getInlineExitContext(var3).createModificationListContext();
				}
				break;
			case 2 :
				var4 = var2.getPostExit().getModificationListContext();
				if (var4 == null) {
					var4 = var2.getPostExit().createModificationListContext();
				}
		}

		return var4;
	}

	private boolean initModifyExecute(HashSet var1, HashSet var2, Vector var3, ExceptionContext var4,
			EmitterExceptionContext var5, DataObject var6, DataObject var7, String var8, int var9, String var10)
			throws SubscriberCriticalException {
		boolean var12 = true;
		boolean var13 = false;
		String var14 = var5.getTopicEmitterName();
		ModificationListContext var15 = this.getModificationListContext(var9, var5, var10);
		Iterator var16 = var3.iterator();
		DataObject var17 = null;
		DataObject var18 = null;
		if (var6 != null) {
			var17 = var6.getDataGraph().getRootObject().getDataObject("Root");
		}

		if (var7 != null) {
			var18 = var7.getDataGraph().getRootObject().getDataObject("Root");
		}

		int var19 = 0;

		while (var16.hasNext()) {
			SubscriberRealmInfo var20 = (SubscriberRealmInfo) var16.next();
			HashSet var21 = var20.getRealmSet();
			ModificationSubscriber var22 = (ModificationSubscriber) var20.getSubscriber();
			String var23 = var20.getSubscriberName();

			try {
				boolean var24 = false;
				if (var21.contains("All") || var8 != null && var21.contains(var8)) {
					Routines.logMessage(trcLogger, CLASSNAME, "initModifyExecute", Level.FINEST, var23);
					++var19;
					switch (var9) {
						case 0 :
							var13 = var22.preExitCall(var14, var17);
							break;
						case 1 :
							var13 = var22.inlineExitCall(var14, var17, var10);
							break;
						case 2 :
							var13 = var22.postExitCall(var14, var17, var18);
					}

					this.addExecutedSubscriber(var2, var20);
					var1.add(var20);
					var24 = true;
					if (!var13) {
						var12 = false;
						var15.setVetoed(true);
						var15.setVetoSubscriberName(var23);
						Routines.logMessage(trcLogger, CLASSNAME, "initModifyExecute", Level.FINEST,
								var23 + " has vetoed.");
					}
				}

				if (var24) {
					ModificationSubscriberContext[] var30 = var15.getSubscriberExecuteContextAsArray();
					if (var30 == null || var30.length < var19) {
						ModificationSubscriberContext var31 = var15.createSubscriberExecuteContext();
						var31.setSubscriberName(var22.getSubscriberName());
						SubscriberExecContext var32 = var31.createExecuteContext();
						var32.setStatus(SubscriberExecStatus.SUCCESS_LITERAL);
					}
				}
			} catch (Throwable var29) {
				Routines.logException(trcLogger, CLASSNAME, "initModifyExecute", Level.WARNING, "", var29);
				ModificationSubscriberContext var25 = this.createModificationSubContext(var5, var10, var9, var29);
				SubscriberExecContext var26 = var25.getExecuteContext();
				this.setFailedSubscriberContext(var5, var9, var10, var23);
				SubscriberException var27 = null;
				boolean var28 = true;
				if (var29 instanceof SubscriberException) {
					var27 = (SubscriberException) var29;
					this.setExceptionContext(var26, var27);
					var28 = false;
				}

				if (var28 || var27 != null && var27.getStatus().equals(SubscriberExecStatus.FAILURE_LITERAL)) {
					throw new SubscriberCriticalException(var23, var5, var29);
				}
			}
		}

		return var12;
	}

	private void commitOrRollback(boolean var1, HashSet var2, DataObject var3, EmitterExceptionContext var4, int var5,
			String var6) throws SubscriberCriticalException {
		String var7 = "initiateCommit";
		Iterator var8 = var2.iterator();
		String var9 = var4.getTopicEmitterName();
		ModificationListContext var10 = this.getModificationListContext(var5, var4, var6);
		DataObject var11 = null;
		if (var3 != null) {
			var11 = var3.getDataGraph().getRootObject().getDataObject("Root");
		}

		while (var8.hasNext()) {
			SubscriberRealmInfo var12 = (SubscriberRealmInfo) var8.next();
			ModificationSubscriber var13 = (ModificationSubscriber) var12.getSubscriber();
			String var14 = var13.getSubscriberName();
			Routines.logMessage(trcLogger, CLASSNAME, var7, Level.FINEST, var14);

			try {
				if (var1) {
					var13.commit(var9, var11, var5, var6);
				} else {
					var13.rollback(var9, var11, var5, var6);
				}
			} catch (Throwable var20) {
				ModificationSubscriberContext var16 = var10.getSubscriberExecuteContext(var14);
				SubscriberExecContext var17 = null;
				if (var1) {
					var17 = var16.createCommitContext();
				} else {
					var17 = var16.createRollbackContext();
				}

				this.setFailedSubscriberContext(var4, var5, var6, var14);
				SubscriberException var18 = null;
				boolean var19 = true;
				if (var20 instanceof SubscriberException) {
					var18 = (SubscriberException) var20;
					this.setExceptionContext(var17, var18);
					var19 = false;
					Routines.logException(trcLogger, CLASSNAME, var7, Level.WARNING, var18.getReasonString(), var20);
				} else {
					var17.setReasonString(var20.getMessage());
					var17.setExceptionMsg(Routines.getErrorMessage(var20));
					var17.setStatus(SubscriberExecStatus.FAILURE_LITERAL);
					Routines.logException(trcLogger, CLASSNAME, var7, Level.WARNING, var20.getMessage(), var20);
				}

				if (var19 || var18 != null && var18.getStatus().equals(SubscriberExecStatus.FAILURE_LITERAL)) {
					throw new SubscriberCriticalException(var14, var4, var20);
				}
			}
		}

	}

	private void setFailedSubscriberContext(EmitterExceptionContext var1, int var2, String var3, String var4) {
		switch (var2) {
			case 0 :
				PreExitContext var7 = var1.getPreExit();
				var7.setIsSuccessful(false);
				var7.setFailedSubscriber(var4);
				break;
			case 1 :
				InlineExitContext var6 = var1.getInlineExitContext(var3);
				var6.setIsSuccessful(false);
				var6.setFailedSubscriber(var4);
				break;
			case 2 :
				PostExitContext var5 = var1.getPostExit();
				var5.setIsSuccessful(false);
				var5.setFailedSubscriber(var4);
		}

	}

	private void addExecutedSubscriber(HashSet var1, SubscriberRealmInfo var2) {
		Iterator var3 = var1.iterator();
		boolean var4 = false;

		while (var3.hasNext()) {
			SubscriberRealmInfo var5 = (SubscriberRealmInfo) var3.next();
			if (var5.getSubscriberName().equals(var2.getSubscriberName())) {
				var4 = true;
				break;
			}
		}

		if (!var4) {
			var1.add(var2);
		}

	}

	public void initNotifyExecute(HashSet var1, Vector var2, ExceptionContext var3, EmitterExceptionContext var4,
			DataObject var5, DataObject var6, String var7, int var8, String var9) throws SubscriberCriticalException {
		String var10 = "initNotifyExecute";
		NotificationListContext var11 = this.getNotificationListContext(var8, var4);
		Iterator var12 = var2.iterator();
		int var13 = 0;
		DataObject var14 = null;
		DataObject var15 = null;
		if (var5 != null) {
			var14 = var5.getDataGraph().getRootObject().getDataObject("Root");
		}

		if (var6 != null) {
			var15 = var6.getDataGraph().getRootObject().getDataObject("Root");
		}

		String var16 = var4.getTopicEmitterName();

		while (var12.hasNext()) {
			SubscriberRealmInfo var17 = (SubscriberRealmInfo) var12.next();
			HashSet var18 = var17.getRealmSet();
			NotificationSubscriber var19 = (NotificationSubscriber) var17.getSubscriber();
			String var20 = var17.getSubscriberName();

			try {
				boolean var21 = false;
				if (var18.contains("All") || var7 != null && var18.contains(var7)) {
					Routines.logMessage(trcLogger, CLASSNAME, var10, Level.FINEST, var20);
					++var13;
					switch (var8) {
						case 0 :
							var19.preExitCall(var16, var14);
							break;
						case 2 :
							var19.postExitCall(var16, var14, var15);
					}

					this.addExecutedSubscriber(var1, var17);
					var21 = true;
				}

				if (var21) {
					NotificationSubscriberContext[] var27 = var11.getSubscriberExecuteContextAsArray();
					if (var27 == null || var27.length < var13) {
						NotificationSubscriberContext var28 = var11.createSubscriberExecuteContext();
						var28.setSubscriberName(var19.getSubscriberName());
						SubscriberExecContext var29 = var28.createExecuteContext();
						var29.setStatus(SubscriberExecStatus.SUCCESS_LITERAL);
					}
				}
			} catch (Throwable var26) {
				NotificationSubscriberContext var22 = this.createNotificationSubContext(var4, var8, var20, var26);
				SubscriberExecContext var23 = var22.getExecuteContext();
				SubscriberException var24 = null;
				boolean var25 = true;
				if (var26 instanceof SubscriberException) {
					var24 = (SubscriberException) var26;
					this.setExceptionContext(var23, var24);
					var25 = false;
				} else {
					var23.setReasonString(var26.getMessage());
					var23.setExceptionMsg(Routines.getErrorMessage(var26));
					var23.setStatus(SubscriberExecStatus.FAILURE_LITERAL);
				}

				if (var25 || var24 != null && var24.getStatus().equals(SubscriberExecStatus.FAILURE_LITERAL)) {
					throw new SubscriberCriticalException(var20, var4, var26);
				}
			}
		}

	}

	private void setExceptionContext(SubscriberExecContext var1, SubscriberException var2) {
		var1.setExceptionMsg(var2.getExceptionMsg());
		var1.setStatus(var2.getStatus());
		var1.setReasonCode(var2.getReasonCode());
		var1.setReasonString(var2.getReasonString());
	}

	public DataObject preExitCall(String var1, DataObject var2) throws SubscriberCriticalException {
		String var3 = "preExitCall";
		String var4 = DomainManagerUtils.getDomainId();
		if (this.inShutdownProcess) {
			StringBuffer var28 = new StringBuffer();
			var28.append("PluginManager in shutdown mode or is shutdown.");
			throw new SubscriberCriticalException(var28.toString());
		} else if (this.subscriptionManager.isEmitterAvailable(var1) && this.subscriptionManager.isEmitterEmpty(var1)) {
			Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINE,
					var1 + " emitter function doesnot have any subscribers.");
			return var2;
		} else {
			byte var5 = 0;
			String var6 = PluginManagerConstants.PREEXIT_LITERAL.getName();
			if (this.subscriptionManager.isEmitterAvailable(var1)) {
				String var8 = Routines.getUniqueID();
				EmitterReference var9 = this.subscriptionManager.getEmitter(var1);
				RuntimeEmitterContext var10 = new RuntimeEmitterContext(var9);
				HashSet var11 = var10.getExecutedSubscriberList();
				this.transInProcess.put(var8, var10);
				DataObject var12 = var2.getDataGraph().getRootObject().getDataObject("Root");
				List var13 = var12.getList("contexts");
				String var14 = null;
				DataObject var15 = null;
				DataObject var16 = null;

				DataObject var18;
				String var19;
				for (int var17 = 0; var17 < var13.size(); ++var17) {
					var18 = (DataObject) var13.get(var17);
					var19 = var18.getString("key");
					if (var19 != null && var19.equals(PluginManagerConstants.REALM_LITERAL.getName())) {
						var14 = var18.getString("value");
					} else if (var19 != null
							&& var19.equals(PluginManagerConstants.PLUGIN_UID_CONTEXT_LITERAL.getName())) {
						var15 = var18;
					} else if (var19 != null
							&& var19.equals(PluginManagerConstants.PLUGIN_EXCEPTION_CONTEXT_LITERAL.getName())) {
						var16 = var18;
					}
				}

				Object var29 = null;
				var18 = null;
				var19 = null;
				UIDContext var30;
				if (var15 != null) {
					var30 = (UIDContext) var15.get("value");
				} else {
					var15 = var12.createDataObject("contexts");
					var30 = ((ContextFactory) expContextFactory.get(var4)).createUIDContext();
					var15.set("key", PluginManagerConstants.PLUGIN_UID_CONTEXT_LITERAL.getName());
					var15.set("value", var30);
				}

				ExceptionContext var31;
				if (var16 != null) {
					var31 = (ExceptionContext) var16.get("value");
				} else {
					var16 = var12.createDataObject("contexts");
					var31 = ((ContextFactory) expContextFactory.get(var4)).createExceptionContext();
					var16.set("key", PluginManagerConstants.PLUGIN_EXCEPTION_CONTEXT_LITERAL.getName());
					var16.set("value", var31);
				}

				EmitterExceptionContext var20 = var31.createEmitterExceptionContext();
				var20.setTopicEmitterName(var1);
				var20.setAnyPluginFailure(false);
				PreExitContext var21 = var20.createPreExit();
				var21.setIsSuccessful(true);
				var30.getUID().add(var8);
				String var22 = var1 + ".preExit";
				Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST, "BEGIN " + var22);

				try {
					Vector var23 = var9.getPreExitNotificationList();
					Vector var24 = var9.getPreExitModificationList();
					Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
							"BEGIN Execute Notification Subscribers --->");
					if (!var23.isEmpty()) {
						this.initNotifyExecute(var11, var23, var31, var20, var2, (DataObject) null, var14, var5,
								(String) null);
					}

					Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
							"END Execute Notification Subscribers <---");
					HashSet var25 = new HashSet();
					if (!var24.isEmpty()) {
						Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
								"BEGIN Execute Modification Subscribers --->");
						boolean var26 = this.initModifyExecute(var25, var11, var24, var31, var20, var2,
								(DataObject) null, var14, var5, (String) null);
						Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
								"END Execute Modification Subscribers <---");
						if (var26) {
							Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
									"BEGIN Commit Modification Subscribers --->");
							this.commitOrRollback(true, var25, var2, var20, var5, (String) null);
							Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
									"END Commit Modification Subscribers <---");
						} else {
							Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
									"BEGIN Rollback Modification Subscribers --->");
							this.commitOrRollback(false, var25, var2, var20, var5, (String) null);
							Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
									"END Rollback Modification Subscribers <---");
						}
					}
				} catch (SubscriberCriticalException var27) {
					var20.setAnyPluginFailure(true);
					var21.setIsSuccessful(false);
					var21.setFailedSubscriber(var27.getCriticalSubscriber());
					Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
							"Failed Subscriber: " + var27.getCriticalSubscriber());
					this.transInProcess.remove(var8);
					Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST,
							"BEGIN Recovery for Subscribers --->");
					this.recoveryExecSubscriberList(var11, var5, (String) null, var1, var6, var31);
					Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST, "END Recovery for Subscribers <---");
					Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST, "END " + var22);
					throw var27;
				}

				Routines.logMessage(trcLogger, CLASSNAME, var3, Level.FINEST, "END " + var22);
			} else {
				trcLogger.logp(Level.FINER, CLASSNAME, var3, "Topic-Emitter " + var1 + " is not configured.");
			}

			return var2;
		}
	}

	public DataObject inlineExitCall(String var1, DataObject var2, String var3) throws SubscriberCriticalException {
		if (this.subscriptionManager.isEmitterAvailable(var1) && this.subscriptionManager.isEmitterEmpty(var1)) {
			return var2;
		} else {
			String var4 = "inlineExitCall";
			byte var5 = 1;
			String var6 = PluginManagerConstants.INLINEEXIT_LITERAL.getName();
			if (this.subscriptionManager.isEmitterAvailable(var1)) {
				UIDContext var8 = null;
				ExceptionContext var9 = null;
				DataObject var10 = var2.getDataGraph().getRootObject().getDataObject("Root");
				List var11 = var10.getList("contexts");
				String var12 = null;
				DataObject var13 = null;
				DataObject var14 = null;

				for (int var15 = 0; var15 < var11.size(); ++var15) {
					DataObject var16 = (DataObject) var11.get(var15);
					String var17 = var16.getString("key");
					if (var17 != null && var17.equals(PluginManagerConstants.REALM_LITERAL.getName())) {
						var12 = var16.getString("value");
					} else if (var17 != null
							&& var17.equals(PluginManagerConstants.PLUGIN_UID_CONTEXT_LITERAL.getName())) {
						var13 = var16;
					} else if (var17 != null
							&& var17.equals(PluginManagerConstants.PLUGIN_EXCEPTION_CONTEXT_LITERAL.getName())) {
						var14 = var16;
					}
				}

				if (var13 != null && var14 != null) {
					var8 = (UIDContext) var13.get("value");
					var9 = (ExceptionContext) var14.get("value");
					String var28 = (String) var8.getUID().get(var8.getUID().size() - 1);
					RuntimeEmitterContext var29 = (RuntimeEmitterContext) this.transInProcess.get(var28);
					if (var29 != null) {
						EmitterReference var30 = var29.getEmitterReference();
						List var18 = var9.getEmitterExceptionContext();
						EmitterExceptionContext var19 = (EmitterExceptionContext) var18.get(var18.size() - 1);
						HashSet var20 = var29.getExecutedSubscriberList();
						HashSet var21 = new HashSet();
						InlineExitContext var22 = var19.createInlineExit();
						var22.setIsSuccessful(true);
						var22.setInlineExitName(var3);
						String var23 = var1 + ".inlineExit." + var3;
						Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST, "BEGIN " + var23);

						try {
							Vector var24 = var30.getInlineExitModificationList(var3);
							if (!var24.isEmpty()) {
								Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
										"BEGIN Execute Modification Subscribers --->");
								boolean var25 = this.initModifyExecute(var21, var20, var24, var9, var19, var2,
										(DataObject) null, var12, var5, var3);
								Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
										"END Execute Modification Subscribers <---");
								if (var25) {
									Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
											"BEGIN Commit Modification Subscribers --->");
									this.commitOrRollback(true, var21, var2, var19, var5, var3);
									Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
											"END Commit Modification Subscribers <---");
								} else {
									Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
											"BEGIN Rollback Modification Subscribers --->");
									this.commitOrRollback(false, var21, var2, var19, var5, var3);
									Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
											"END Rollback Modification Subscribers <---");
								}
							}
						} catch (SubscriberCriticalException var26) {
							var19.setAnyPluginFailure(true);
							var22.setIsSuccessful(false);
							var22.setFailedSubscriber(var26.getCriticalSubscriber());
							Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
									"Failed Subscriber: " + var26.getCriticalSubscriber());
							this.transInProcess.remove(var28);
							Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
									"BEGIN Recovery for Subscribers --->");
							this.recoveryExecSubscriberList(var20, var5, var3, var1, var6, var9);
							Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
									"END Recovery for Subscribers <---");
							Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST, "END " + var23);
							throw var26;
						}

						Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST, "END " + var23);
					}
				} else {
					StringBuffer var27 = new StringBuffer();
					var27.append(
							"DataGraph daisyChainDG does not have a properly set UIDContext or ExceptionContext element.");
					Routines.logMessage(trcLogger, CLASSNAME, var4, Level.SEVERE, var27.toString());
				}
			} else {
				trcLogger.logp(Level.FINER, CLASSNAME, var4, "Topic-Emitter " + var1 + " is not configured.");
			}

			return var2;
		}
	}

	public DataObject postExitCall(String var1, DataObject var2, DataObject var3) throws SubscriberCriticalException {
		if (this.subscriptionManager.isEmitterAvailable(var1) && this.subscriptionManager.isEmitterEmpty(var1)) {
			return var3;
		} else {
			String var4 = "postExitCall";
			byte var5 = 2;
			String var6 = PluginManagerConstants.POSTEXIT_LITERAL.getName();
			if (this.subscriptionManager.isEmitterAvailable(var1)) {
				UIDContext var8 = null;
				ExceptionContext var9 = null;
				DataObject var10 = var2.getDataGraph().getRootObject().getDataObject("Root");
				List var11 = var10.getList("contexts");
				String var12 = null;
				DataObject var13 = null;
				DataObject var14 = null;

				for (int var15 = 0; var15 < var11.size(); ++var15) {
					DataObject var16 = (DataObject) var11.get(var15);
					String var17 = var16.getString("key");
					if (var17 != null && var17.equals(PluginManagerConstants.REALM_LITERAL.getName())) {
						var12 = var16.getString("value");
					} else if (var17 != null
							&& var17.equals(PluginManagerConstants.PLUGIN_UID_CONTEXT_LITERAL.getName())) {
						var13 = var16;
					} else if (var17 != null
							&& var17.equals(PluginManagerConstants.PLUGIN_EXCEPTION_CONTEXT_LITERAL.getName())) {
						var14 = var16;
					}
				}

				if (var13 != null && var14 != null) {
					var8 = (UIDContext) var13.get("value");
					var9 = (ExceptionContext) var14.get("value");
					String var29 = (String) var8.getUID().get(var8.getUID().size() - 1);
					RuntimeEmitterContext var30 = (RuntimeEmitterContext) this.transInProcess.get(var29);
					if (var30 != null) {
						EmitterReference var31 = var30.getEmitterReference();
						List var18 = var9.getEmitterExceptionContext();
						EmitterExceptionContext var19 = (EmitterExceptionContext) var18.get(var18.size() - 1);
						HashSet var20 = var30.getExecutedSubscriberList();
						PostExitContext var21 = var19.createPostExit();
						var21.setIsSuccessful(true);
						String var22 = var1 + ".postExit";
						Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST, "BEGIN " + var22);

						try {
							Vector var23 = var31.getPostExitModificationList();
							Vector var24 = var31.getPostExitNotificationList();
							HashSet var25 = new HashSet();
							if (!var23.isEmpty()) {
								Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
										"BEGIN Execute Modification Subscribers --->");
								boolean var26 = this.initModifyExecute(var25, var20, var23, var9, var19, var2, var3,
										var12, var5, (String) null);
								Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
										"END Execute Modification Subscribers <---");
								if (var26) {
									Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
											"BEGIN Commit Modification Subscribers --->");
									this.commitOrRollback(true, var25, var2, var19, var5, (String) null);
									Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
											"END Commit Modification Subscribers <---");
								} else {
									Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
											"BEGIN Rollback Modification Subscribers --->");
									this.commitOrRollback(false, var25, var2, var19, var5, (String) null);
									Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
											"END Rollback Modification Subscribers <---");
								}
							}

							if (!var24.isEmpty()) {
								Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
										"BEGIN Execute Notification Subscribers --->");
								this.initNotifyExecute(var20, var24, var9, var19, var2, var3, var12, var5,
										(String) null);
								Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
										"END Execute Notification Subscribers <---");
							}

							this.transInProcess.remove(var29);
						} catch (SubscriberCriticalException var27) {
							var19.setAnyPluginFailure(true);
							var21.setIsSuccessful(false);
							var21.setFailedSubscriber(var27.getCriticalSubscriber());
							Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
									"Failed Subscriber: " + var27.getCriticalSubscriber());
							this.transInProcess.remove(var29);
							Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
									"BEGIN Recovery for Subscribers --->");
							this.recoveryExecSubscriberList(var20, var5, (String) null, var1, var6, var9);
							Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST,
									"END Recovery for Subscribers <---");
							Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST, "END " + var22);
							throw var27;
						}

						Routines.logMessage(trcLogger, CLASSNAME, var4, Level.FINEST, "END " + var22);
					}
				} else {
					StringBuffer var28 = new StringBuffer();
					var28.append(
							"DataGraph daisyChainDG does not have a properly set UIDContext or ExceptionContext element.");
					Routines.logMessage(trcLogger, CLASSNAME, var4, Level.SEVERE, var28.toString());
				}
			} else {
				trcLogger.logp(Level.FINER, CLASSNAME, var4, "Topic-Emitter " + var1 + " is not configured.");
			}

			this.cleanPluginManagerContext(var3);
			return var3;
		}
	}

	public void cleanPluginManagerContext(DataObject var1) {
		if (var1 != null) {
			DataObject var2 = var1.getDataGraph().getRootObject().getDataObject("Root");
			List var3 = var2.getList("contexts");
			Object var4 = null;
			DataObject var5 = null;
			DataObject var6 = null;

			DataObject var8;
			String var9;
			for (int var7 = 0; var7 < var3.size(); ++var7) {
				var8 = (DataObject) var3.get(var7);
				var9 = var8.getString("key");
				if (var9 != null && var9.equals(PluginManagerConstants.PLUGIN_UID_CONTEXT_LITERAL.getName())) {
					var5 = var8;
				} else if (var9 != null
						&& var9.equals(PluginManagerConstants.PLUGIN_EXCEPTION_CONTEXT_LITERAL.getName())) {
					var6 = var8;
				}
			}

			boolean var15 = false;
			var8 = null;
			var9 = null;
			if (var5 != null && var6 != null) {
				UIDContext var16 = (UIDContext) var5.get("value");
				ExceptionContext var17 = (ExceptionContext) var6.get("value");
				List var10 = var16.getUID();
				var10.remove(var10.size() - 1);
				if (var10.size() == 0) {
					var15 = true;
				}

				List var11 = var17.getEmitterExceptionContext();
				var11.remove(var11.size() - 1);
				if (var11.size() == 0) {
					var15 = true;
				}

				if (var15) {
					for (int var12 = 0; var12 < var3.size(); ++var12) {
						DataObject var13 = (DataObject) var3.get(var12);
						String var14 = var13.getString("key");
						if (var14 != null
								&& var14.equals(PluginManagerConstants.PLUGIN_UID_CONTEXT_LITERAL.getName())) {
							var3.remove(var12);
							--var12;
						} else if (var14 != null
								&& var14.equals(PluginManagerConstants.PLUGIN_EXCEPTION_CONTEXT_LITERAL.getName())) {
							var3.remove(var12);
							--var12;
						}
					}
				}
			}

		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = PluginManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
		expContextFactory = Collections.synchronizedMap(new HashMap());
	}
}