package com.google.common.collect;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.MutableClassToInstanceMap.1;
import com.google.common.collect.MutableClassToInstanceMap.2;
import com.google.common.collect.MutableClassToInstanceMap.SerializedForm;
import com.google.common.primitives.Primitives;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

@GwtIncompatible
public final class MutableClassToInstanceMap<B> extends ForwardingMap<Class<? extends B>, B>
		implements
			ClassToInstanceMap<B>,
			Serializable {
	private final Map<Class<? extends B>, B> delegate;

	public static <B> MutableClassToInstanceMap<B> create() {
		return new MutableClassToInstanceMap(new HashMap());
	}

	public static <B> MutableClassToInstanceMap<B> create(Map<Class<? extends B>, B> backingMap) {
		return new MutableClassToInstanceMap(backingMap);
	}

	private MutableClassToInstanceMap(Map<Class<? extends B>, B> delegate) {
		this.delegate = (Map) Preconditions.checkNotNull(delegate);
	}

	protected Map<Class<? extends B>, B> delegate() {
		return this.delegate;
	}

	static <B> Entry<Class<? extends B>, B> checkedEntry(Entry<Class<? extends B>, B> entry) {
      return new 1(entry);
   }

	public Set<Entry<Class<? extends B>, B>> entrySet() {
      return new 2(this);
   }

	@CanIgnoreReturnValue
	public B put(Class<? extends B> key, B value) {
		return super.put(key, cast(key, value));
	}

	public void putAll(Map<? extends Class<? extends B>, ? extends B> map) {
		Map<Class<? extends B>, B> copy = new LinkedHashMap(map);
		Iterator var3 = copy.entrySet().iterator();

		while (var3.hasNext()) {
			Entry<? extends Class<? extends B>, B> entry = (Entry) var3.next();
			cast((Class) entry.getKey(), entry.getValue());
		}

		super.putAll(copy);
	}

	@CanIgnoreReturnValue
	public <T extends B> T putInstance(Class<T> type, T value) {
		return cast(type, this.put(type, value));
	}

	public <T extends B> T getInstance(Class<T> type) {
		return cast(type, this.get(type));
	}

	@CanIgnoreReturnValue
	private static <B, T extends B> T cast(Class<T> type, B value) {
		return Primitives.wrap(type).cast(value);
	}

	private Object writeReplace() {
		return new SerializedForm(this.delegate());
	}
}