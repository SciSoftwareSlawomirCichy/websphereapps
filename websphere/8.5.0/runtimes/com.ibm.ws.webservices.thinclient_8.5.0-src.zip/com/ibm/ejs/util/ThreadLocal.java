package com.ibm.ejs.util;

import com.ibm.ejs.util.ThreadLocal.1;
import com.ibm.ejs.util.ThreadLocal.2;
import com.ibm.ejs.util.ThreadLocal.Entry;
import com.ibm.ffdc.Manager;
import java.lang.ref.ReferenceQueue;
import java.util.Random;

public class ThreadLocal {
	ReferenceQueue queue = new ReferenceQueue();
	int nbuckets = 127;
	Entry[] buckets;

	public ThreadLocal() {
		this.buckets = new Entry[this.nbuckets];
	}

	protected Object initialValue() {
		return null;
	}

	public Object get() {
		Entry ourEntry = this.ourEntry(true);
		return ourEntry == null ? null : ourEntry.value;
	}

	public void set(Object value) {
		this.clean();
		Entry ourEntry = this.ourEntry(false);
		ourEntry.value = value;
	}

	private Entry ourEntry(boolean doingGet) {
		Thread ourThread = Thread.currentThread();
		int bucketIndex = (ourThread.hashCode() & Integer.MAX_VALUE) % this.nbuckets;
		Entry ourEntry = this.lookup(ourThread, bucketIndex);
		if (ourEntry == null) {
			Object value = doingGet ? this.initialValue() : null;
			if (value != null || !doingGet) {
				this.insert(ourEntry = new Entry(ourThread, bucketIndex, value, this.queue));
			}
		}

		return ourEntry;
	}

	void clean() {
		Entry oldEntry;
		while ((oldEntry = (Entry) this.queue.poll()) != null) {
			this.remove(oldEntry);
		}

	}

	Entry lookup(Thread t, int bucketIndex) {
		for (Entry e = this.buckets[bucketIndex]; e != null; e = e.next) {
			if (e.get() == t) {
				return e;
			}
		}

		return null;
	}

	void insert(Entry e) {
		Entry[] var2 = this.buckets;
		synchronized (this.buckets) {
			e.next = this.buckets[e.bucketIndex];
			this.buckets[e.bucketIndex] = e;
		}
	}

	void remove(Entry e) {
		Entry[] var2 = this.buckets;
		synchronized (this.buckets) {
			Entry x = this.buckets[e.bucketIndex];
			if (x == e) {
				this.buckets[e.bucketIndex] = x.next;
			} else {
				while (x != null) {
					if (x.next == e) {
						x.next = e.next;
						break;
					}

					x = x.next;
				}
			}

		}
	}

	static void main(String[] args) {
      ThreadLocal var = new 1();
      Random r = new Random();
      int threadCount = Integer.parseInt(args[0]);

      for(int i = 0; i < threadCount; ++i) {
         (new 2(i, var, r)).start();
         pause(2500);
      }

   }

	static void pause(int millis) {
		Object o = new Object();

		try {
			synchronized (o) {
				o.wait((long) millis);
			}
		} catch (InterruptedException var5) {
			Manager.Ffdc.log(var5, ThreadLocal.class, "com.ibm.ejs.util.ThreadLocal.pause", "129");
		}

	}
}