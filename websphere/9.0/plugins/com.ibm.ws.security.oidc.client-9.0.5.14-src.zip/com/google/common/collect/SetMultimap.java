package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public interface SetMultimap<K, V> extends Multimap<K, V> {
	Set<V> get(@NullableDecl K var1);

	@CanIgnoreReturnValue
	Set<V> removeAll(@NullableDecl Object var1);

	@CanIgnoreReturnValue
	Set<V> replaceValues(K var1, Iterable<? extends V> var2);

	Set<Entry<K, V>> entries();

	Map<K, Collection<V>> asMap();

	boolean equals(@NullableDecl Object var1);
}