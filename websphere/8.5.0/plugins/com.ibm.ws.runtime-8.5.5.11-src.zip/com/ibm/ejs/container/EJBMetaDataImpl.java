package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ffdc.FFDCFilter;
import java.io.Serializable;
import java.rmi.NoSuchObjectException;
import javax.ejb.EJBHome;
import javax.ejb.EJBMetaData;
import javax.rmi.PortableRemoteObject;

public class EJBMetaDataImpl implements EJBMetaData, Serializable {
	private EJBHome home;
	private final String beanClassName;
	private final String remoteInterfaceClassName;
	private final String homeInterfaceClassName;
	private final String primaryKeyClassName;
	private final boolean session;
	private final boolean statelessSession;
	private static final long serialVersionUID = 4092588565014573628L;
	private static final TraceComponent tc = Tr.register(EJBMetaDataImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.EJBMetaDataImpl";

	public EJBMetaDataImpl(BeanMetaData beanMetaData, EJSWrapper home, J2EEName j2eeName) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		try {
			this.home = (EJBHome) ((EJBHome) PortableRemoteObject.toStub(home));
		} catch (NoSuchObjectException var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.EJBMetaDataImpl.EJBMetaDataImpl", "85", this);
			Tr.warning(tc, "UNABLE_CONVERT_REMOTE_2_STUB_CNTR0045W", var5.toString());
		}

		this.beanClassName = beanMetaData.enterpriseBeanAbstractClass.getName();
		this.remoteInterfaceClassName = beanMetaData.remoteInterfaceClass.getName();
		this.homeInterfaceClassName = beanMetaData.homeInterfaceClass.getName();
		if (beanMetaData.pKeyClass != null) {
			this.primaryKeyClassName = beanMetaData.pKeyClass.getName();
		} else {
			this.primaryKeyClassName = null;
		}

		if (beanMetaData.type == 4) {
			this.session = true;
			this.statelessSession = false;
		} else if (beanMetaData.type == 3) {
			this.session = true;
			this.statelessSession = true;
		} else {
			this.session = false;
			this.statelessSession = false;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public EJBHome getEJBHome() {
		return this.home;
	}

	public Class getHomeInterfaceClass() {
		Class homeInterfaceClass = null;

		try {
			ClassLoader cl = Thread.currentThread().getContextClassLoader();
			homeInterfaceClass = cl.loadClass(this.homeInterfaceClassName);
		} catch (ClassNotFoundException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.EJBMetaDataImpl.getHomeInterfaceClass", "140",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Failed to load home interface class", this.homeInterfaceClassName);
			}
		}

		return homeInterfaceClass;
	}

	public Class getPrimaryKeyClass() {
		Class primaryKeyClass = null;
		if (this.session) {
			throw new RuntimeException("No PrimaryKeyClass for Session Bean");
		} else {
			try {
				ClassLoader cl = Thread.currentThread().getContextClassLoader();
				primaryKeyClass = cl.loadClass(this.primaryKeyClassName);
			} catch (ClassNotFoundException var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.EJBMetaDataImpl.getPrimaryKeyClass", "163",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Failed to load primary key class", this.primaryKeyClassName);
				}
			}

			return primaryKeyClass;
		}
	}

	public Class getRemoteInterfaceClass() {
		Class remoteInterfaceClass = null;

		try {
			ClassLoader cl = Thread.currentThread().getContextClassLoader();
			remoteInterfaceClass = cl.loadClass(this.remoteInterfaceClassName);
		} catch (ClassNotFoundException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.EJBMetaDataImpl.getRemoteInterfaceClass", "183",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Failed to load remote interface class", this.remoteInterfaceClassName);
			}
		}

		return remoteInterfaceClass;
	}

	public String getBeanClassName() {
		return this.beanClassName;
	}

	public boolean isSession() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isSession = " + this.session);
		}

		return this.session;
	}

	public boolean isStatelessSession() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isStatelessSession = " + this.statelessSession);
		}

		return this.statelessSession;
	}
}