package com.ibm.ejs.oa;

import com.ibm.websphere.csi.ObjectAdapter;
import com.ibm.websphere.csi.ServantManager;
import org.omg.CORBA.SystemException;

public interface EJSRootObjectAdapter {
	ObjectAdapter createObjectAdapter(String var1) throws AdapterAlreadyExistsException;

	EJSObjectAdapter createObjectAdapter(String var1, ServantManager var2) throws AdapterAlreadyExistsException;

	void destroyObjectAdapter(String var1);

	void quiesce(SystemException var1);
}