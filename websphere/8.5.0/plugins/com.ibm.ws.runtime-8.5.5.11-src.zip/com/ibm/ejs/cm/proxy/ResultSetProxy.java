package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;

public class ResultSetProxy extends Proxy implements ResultSet {
	private static final TraceNLS NLS = TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages");
	private ResultSet rs;
	private static final TraceComponent tc = Tr.register(ResultSetProxy.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public int getHoldability() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getHoldability()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Reader getNCharacterStream(int columnIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNCharacterStream(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Reader getNCharacterStream(String columnLabel) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNCharacterStream(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public NClob getNClob(int columnIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNClob(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public NClob getNClob(String columnLabel) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNClob(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public String getNString(int columnIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNString(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public String getNString(String columnLabel) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getNString(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public RowId getRowId(int columnIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getRowId(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public RowId getRowId(String columnLabel) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getRowId(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public SQLXML getSQLXML(int columnIndex) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getSQLXML(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public SQLXML getSQLXML(String columnLabel) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getSQLXML(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateAsciiStream(int columnIndex, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateAsciiStream(int, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateAsciiStream(String columnLabel, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateAsciiStream(String, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateAsciiStream(int columnIndex, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateAsciiStream(int, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateAsciiStream(String columnLabel, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateAsciiStream(String, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateBinaryStream(int columnIndex, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateBinaryStream(int, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateBinaryStream(String columnLabel, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateBinaryStream(String, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateBinaryStream(int columnIndex, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateBinaryStream(int, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateBinaryStream(String columnLabel, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateBinaryStream(String, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateBlob(int, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateBlob(String columnLabel, InputStream inputStream) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateBlob(String, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateBlob(int columnIndex, InputStream inputStream, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateBlob(int, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateBlob(String columnLabel, InputStream inputStream, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateBlob(String, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateCharacterStream(int columnIndex, Reader x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateCharacterStream(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateCharacterStream(String columnLabel, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateCharacterStream(String, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateCharacterStream(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateCharacterStream(String, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateClob(int columnIndex, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateClob(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateClob(String columnLabel, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateClob(String, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateClob(int columnIndex, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateClob(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateClob(String columnLabel, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateClob(String, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNCharacterStream(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNCharacterStream(String columnLabel, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNCharacterStream(String, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNCharacterStream(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNCharacterStream(String, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNClob(int columnIndex, NClob nClob) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNClob(int, NClob)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNClob(String columnLabel, NClob nClob) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNClob(String, NClob)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNClob(int columnIndex, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNClob(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNClob(String columnLabel, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNClob(String, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNClob(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNClob(String columnLabel, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNClob(String, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNString(int columnIndex, String nString) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNString(int, String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateNString(String columnLabel, String nString) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateNString(String, String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateRowId(int columnIndex, RowId x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateRowId(int, RowId)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateRowId(String columnLabel, RowId x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateRowId(String, RowId)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateSQLXML(int, SQLXML)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void updateSQLXML(String columnLabel, SQLXML xmlObject) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "updateSQLXML(String, SQLXML)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isWrapperFor(Class<?>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "unwrap(Class<T>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public URL getURL(int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getURL(int)");
		throw new SQLException("This method is not supported.");
	}

	public URL getURL(String s) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getUrl(String)");
		throw new SQLException("This method is not supported.");
	}

	public void updateArray(int i, Array array) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "updateArray(int, java.sql.Array)");
		throw new SQLException("This method is not supported.");
	}

	public void updateArray(String s, Array array) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "updateArray(String, java.sql.Array)");
		throw new SQLException("This method is not supported.");
	}

	public void updateBlob(int i, Blob b) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "updateBlob(int, java.sql.Blob)");
		throw new SQLException("This method is not supported.");
	}

	public void updateBlob(String s, Blob b) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "updateBlob(String, java.sql.Blob)");
		throw new SQLException("This method is not supported.");
	}

	public void updateClob(int i, Clob c) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "updateClob(int, java.sql.Clob)");
		throw new SQLException("This method is not supported.");
	}

	public void updateClob(String s, Clob c) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "updateClob(String, java.sql.Clob)");
		throw new SQLException("This method is not supported.");
	}

	public void updateRef(int i, Ref r) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "updateRef(int, java.sql.Ref)");
		throw new SQLException("This method is not supported.");
	}

	public void updateRef(String s, Ref r) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "updateRef(String, java.sql.Ref)");
		throw new SQLException("This method is not supported.");
	}

	ResultSetProxy(StatementProxy parent, ResultSet rs) {
		super(parent);
		this.rs = rs;
	}

	public Reader getCharacterStream(int columnIndex) throws SQLException {
		return this.getResultSet().getCharacterStream(columnIndex);
	}

	public Reader getCharacterStream(String columnName) throws SQLException {
		return this.getResultSet().getCharacterStream(columnName);
	}

	public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
		return this.getResultSet().getBigDecimal(columnIndex);
	}

	public BigDecimal getBigDecimal(String columnName) throws SQLException {
		return this.getResultSet().getBigDecimal(columnName);
	}

	public boolean isBeforeFirst() throws SQLException {
		return this.getResultSet().isBeforeFirst();
	}

	public boolean isAfterLast() throws SQLException {
		return this.getResultSet().isAfterLast();
	}

	public boolean isFirst() throws SQLException {
		return this.getResultSet().isFirst();
	}

	public boolean isLast() throws SQLException {
		return this.getResultSet().isLast();
	}

	public void beforeFirst() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getResultSet().beforeFirst();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public void afterLast() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getResultSet().afterLast();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public boolean first() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				boolean var3;
				try {
					this.__preInvoke();
					var3 = this.getResultSet().first();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}

				return var3;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public boolean last() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				boolean var3;
				try {
					this.__preInvoke();
					var3 = this.getResultSet().last();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}

				return var3;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public int getRow() throws SQLException {
		return this.getResultSet().getRow();
	}

	public boolean absolute(int row) throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				boolean var4;
				try {
					this.__preInvoke();
					var4 = this.getResultSet().absolute(row);
				} catch (SQLException var10) {
					x = var10;
					throw this.translateException(var10);
				} finally {
					this.__postInvoke(x);
				}

				return var4;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public boolean relative(int rows) throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				boolean var4;
				try {
					this.__preInvoke();
					var4 = this.getResultSet().relative(rows);
				} catch (SQLException var10) {
					x = var10;
					throw this.translateException(var10);
				} finally {
					this.__postInvoke(x);
				}

				return var4;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public boolean previous() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				boolean var3;
				try {
					this.__preInvoke();
					var3 = this.getResultSet().previous();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}

				return var3;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public void setFetchDirection(int direction) throws SQLException {
		this.getResultSet().setFetchDirection(direction);
	}

	public int getFetchDirection() throws SQLException {
		return this.getResultSet().getFetchDirection();
	}

	public void setFetchSize(int rows) throws SQLException {
		this.getResultSet().setFetchSize(rows);
	}

	public int getFetchSize() throws SQLException {
		return this.getResultSet().getFetchSize();
	}

	public int getType() throws SQLException {
		return this.getResultSet().getType();
	}

	public int getConcurrency() throws SQLException {
		return this.getResultSet().getConcurrency();
	}

	public boolean rowUpdated() throws SQLException {
		return this.getResultSet().rowUpdated();
	}

	public boolean rowInserted() throws SQLException {
		return this.getResultSet().rowInserted();
	}

	public boolean rowDeleted() throws SQLException {
		return this.getResultSet().rowDeleted();
	}

	public void updateNull(int columnIndex) throws SQLException {
		this.getResultSet().updateNull(columnIndex);
	}

	public void updateBoolean(int columnIndex, boolean x) throws SQLException {
		this.getResultSet().updateBoolean(columnIndex, x);
	}

	public void updateByte(int columnIndex, byte x) throws SQLException {
		this.getResultSet().updateByte(columnIndex, x);
	}

	public void updateShort(int columnIndex, short x) throws SQLException {
		this.getResultSet().updateShort(columnIndex, x);
	}

	public void updateInt(int columnIndex, int x) throws SQLException {
		this.getResultSet().updateInt(columnIndex, x);
	}

	public void updateLong(int columnIndex, long x) throws SQLException {
		this.getResultSet().updateLong(columnIndex, x);
	}

	public void updateFloat(int columnIndex, float x) throws SQLException {
		this.getResultSet().updateFloat(columnIndex, x);
	}

	public void updateDouble(int columnIndex, double x) throws SQLException {
		this.getResultSet().updateDouble(columnIndex, x);
	}

	public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
		this.getResultSet().updateBigDecimal(columnIndex, x);
	}

	public void updateString(int columnIndex, String x) throws SQLException {
		this.getResultSet().updateString(columnIndex, x);
	}

	public void updateBytes(int columnIndex, byte[] x) throws SQLException {
		this.getResultSet().updateBytes(columnIndex, x);
	}

	public void updateDate(int columnIndex, Date x) throws SQLException {
		this.getResultSet().updateDate(columnIndex, x);
	}

	public void updateTime(int columnIndex, Time x) throws SQLException {
		this.getResultSet().updateTime(columnIndex, x);
	}

	public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
		this.getResultSet().updateTimestamp(columnIndex, x);
	}

	public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
		this.getResultSet().updateAsciiStream(columnIndex, x, length);
	}

	public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
		this.getResultSet().updateBinaryStream(columnIndex, x, length);
	}

	public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
		this.getResultSet().updateCharacterStream(columnIndex, x, length);
	}

	public void updateObject(int columnIndex, Object x, int scale) throws SQLException {
		this.getResultSet().updateObject(columnIndex, x, scale);
	}

	public void updateObject(int columnIndex, Object x) throws SQLException {
		this.getResultSet().updateObject(columnIndex, x);
	}

	public void updateNull(String columnName) throws SQLException {
		this.getResultSet().updateNull(columnName);
	}

	public void updateBoolean(String columnName, boolean x) throws SQLException {
		this.getResultSet().updateBoolean(columnName, x);
	}

	public void updateByte(String columnName, byte x) throws SQLException {
		this.getResultSet().updateByte(columnName, x);
	}

	public void updateShort(String columnName, short x) throws SQLException {
		this.getResultSet().updateShort(columnName, x);
	}

	public void updateInt(String columnName, int x) throws SQLException {
		this.getResultSet().updateInt(columnName, x);
	}

	public void updateLong(String columnName, long x) throws SQLException {
		this.getResultSet().updateLong(columnName, x);
	}

	public void updateFloat(String columnName, float x) throws SQLException {
		this.getResultSet().updateFloat(columnName, x);
	}

	public void updateDouble(String columnName, double x) throws SQLException {
		this.getResultSet().updateDouble(columnName, x);
	}

	public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
		this.getResultSet().updateBigDecimal(columnName, x);
	}

	public void updateString(String columnName, String x) throws SQLException {
		this.getResultSet().updateString(columnName, x);
	}

	public void updateBytes(String columnName, byte[] x) throws SQLException {
		this.getResultSet().updateBytes(columnName, x);
	}

	public void updateDate(String columnName, Date x) throws SQLException {
		this.getResultSet().updateDate(columnName, x);
	}

	public void updateTime(String columnName, Time x) throws SQLException {
		this.getResultSet().updateTime(columnName, x);
	}

	public void updateTimestamp(String columnName, Timestamp x) throws SQLException {
		this.getResultSet().updateTimestamp(columnName, x);
	}

	public void updateAsciiStream(String columnName, InputStream x, int length) throws SQLException {
		this.getResultSet().updateAsciiStream(columnName, x, length);
	}

	public void updateBinaryStream(String columnName, InputStream x, int length) throws SQLException {
		this.getResultSet().updateBinaryStream(columnName, x, length);
	}

	public void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException {
		this.getResultSet().updateCharacterStream(columnName, reader, length);
	}

	public void updateObject(String columnName, Object x, int scale) throws SQLException {
		this.getResultSet().updateObject(columnName, x, scale);
	}

	public void updateObject(String columnName, Object x) throws SQLException {
		this.getResultSet().updateObject(columnName, x);
	}

	public void insertRow() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getResultSet().insertRow();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public void updateRow() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getResultSet().updateRow();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public void deleteRow() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getResultSet().deleteRow();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public void refreshRow() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getResultSet().refreshRow();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public void cancelRowUpdates() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getResultSet().cancelRowUpdates();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public void moveToInsertRow() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getResultSet().moveToInsertRow();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public void moveToCurrentRow() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getResultSet().moveToCurrentRow();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public Statement getStatement() throws SQLException {
		return (Statement) this.getParent();
	}

	public Object getObject(int i, Map<String, Class<?>> map) throws SQLException {
		return this.getResultSet().getObject(i, map);
	}

	public Ref getRef(int i) throws SQLException {
		return this.getResultSet().getRef(i);
	}

	public Blob getBlob(int i) throws SQLException {
		return this.getResultSet().getBlob(i);
	}

	public Clob getClob(int i) throws SQLException {
		return this.getResultSet().getClob(i);
	}

	public Array getArray(int i) throws SQLException {
		return this.getResultSet().getArray(i);
	}

	public Object getObject(String colName, Map<String, Class<?>> map) throws SQLException {
		return this.getResultSet().getObject(colName, map);
	}

	public Ref getRef(String colName) throws SQLException {
		return this.getResultSet().getRef(colName);
	}

	public Blob getBlob(String colName) throws SQLException {
		return this.getResultSet().getBlob(colName);
	}

	public Clob getClob(String colName) throws SQLException {
		return this.getResultSet().getClob(colName);
	}

	public Array getArray(String colName) throws SQLException {
		return this.getResultSet().getArray(colName);
	}

	public Date getDate(int columnIndex, Calendar cal) throws SQLException {
		return ((PortabilityLayer) ((ConnectionProxy) ((ConnectionProxy) this.getParent().getParent())).getConnection()
				.getPortabilityLayer()).getDate(this.getResultSet(), columnIndex, cal);
	}

	public Date getDate(String columnName, Calendar cal) throws SQLException {
		return ((PortabilityLayer) ((ConnectionProxy) ((ConnectionProxy) this.getParent().getParent())).getConnection()
				.getPortabilityLayer()).getDate(this.getResultSet(), columnName, cal);
	}

	public Time getTime(int columnIndex, Calendar cal) throws SQLException {
		return ((PortabilityLayer) ((ConnectionProxy) ((ConnectionProxy) this.getParent().getParent())).getConnection()
				.getPortabilityLayer()).getTime(this.getResultSet(), columnIndex, cal);
	}

	public Time getTime(String columnName, Calendar cal) throws SQLException {
		return ((PortabilityLayer) ((ConnectionProxy) ((ConnectionProxy) this.getParent().getParent())).getConnection()
				.getPortabilityLayer()).getTime(this.getResultSet(), columnName, cal);
	}

	public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException {
		return this.getResultSet().getTimestamp(columnIndex, cal);
	}

	public Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException {
		return this.getResultSet().getTimestamp(columnName, cal);
	}

	public boolean next() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			Object lockObject = this.getLockObject();
			if (lockObject != null) {
				synchronized (this.getLockObject()) {
					boolean var4;
					try {
						this.__preInvoke();
						var4 = this.getResultSet().next();
					} catch (SQLException var10) {
						x = var10;
						throw this.translateException(var10);
					} finally {
						this.__postInvoke(x);
					}

					return var4;
				}
			} else {
				throw new StaleConnectionException(this.getClass() + " is closed");
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public void close() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "close");
		}

		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				this.reallyClose();
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "close");
		}

	}

	protected void closeFromParent() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "closeFromParent");
		}

		if (!this.isClosed()) {
			this.reallyClose();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "closeFromParent");
		}

	}

	public void reallyClose() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "reallyClose");
		}

		try {
			super.close();
			if (this.rs != null) {
				this.rs.close();
			}

			this.parent = null;
		} catch (SQLException var6) {
			SQLException x = this.translateException(var6);
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Exception closing result set", x);
			}

			throw x;
		} finally {
			this.rs = null;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "reallyClose");
		}

	}

	public boolean wasNull() throws SQLException {
		return this.getResultSet().wasNull();
	}

	public String getString(int columnIndex) throws SQLException {
		return this.getResultSet().getString(columnIndex);
	}

	public boolean getBoolean(int columnIndex) throws SQLException {
		return this.getResultSet().getBoolean(columnIndex);
	}

	public byte getByte(int columnIndex) throws SQLException {
		return this.getResultSet().getByte(columnIndex);
	}

	public short getShort(int columnIndex) throws SQLException {
		return this.getResultSet().getShort(columnIndex);
	}

	public int getInt(int columnIndex) throws SQLException {
		return this.getResultSet().getInt(columnIndex);
	}

	public long getLong(int columnIndex) throws SQLException {
		return this.getResultSet().getLong(columnIndex);
	}

	public float getFloat(int columnIndex) throws SQLException {
		return this.getResultSet().getFloat(columnIndex);
	}

	public double getDouble(int columnIndex) throws SQLException {
		return this.getResultSet().getDouble(columnIndex);
	}

	public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
		return this.getResultSet().getBigDecimal(columnIndex, scale);
	}

	public byte[] getBytes(int columnIndex) throws SQLException {
		return this.getResultSet().getBytes(columnIndex);
	}

	public Date getDate(int columnIndex) throws SQLException {
		return ((PortabilityLayer) ((ConnectionProxy) ((ConnectionProxy) this.getParent().getParent())).getConnection()
				.getPortabilityLayer()).getDate(this.getResultSet(), columnIndex);
	}

	public Time getTime(int columnIndex) throws SQLException {
		return ((PortabilityLayer) ((ConnectionProxy) ((ConnectionProxy) this.getParent().getParent())).getConnection()
				.getPortabilityLayer()).getTime(this.getResultSet(), columnIndex);
	}

	public Timestamp getTimestamp(int columnIndex) throws SQLException {
		return this.getResultSet().getTimestamp(columnIndex);
	}

	public InputStream getAsciiStream(int columnIndex) throws SQLException {
		return this.getResultSet().getAsciiStream(columnIndex);
	}

	public InputStream getUnicodeStream(int columnIndex) throws SQLException {
		return this.getResultSet().getUnicodeStream(columnIndex);
	}

	public InputStream getBinaryStream(int columnIndex) throws SQLException {
		return this.getResultSet().getBinaryStream(columnIndex);
	}

	public String getString(String columnName) throws SQLException {
		return this.getResultSet().getString(columnName);
	}

	public boolean getBoolean(String columnName) throws SQLException {
		return this.getResultSet().getBoolean(columnName);
	}

	public byte getByte(String columnName) throws SQLException {
		return this.getResultSet().getByte(columnName);
	}

	public short getShort(String columnName) throws SQLException {
		return this.getResultSet().getShort(columnName);
	}

	public int getInt(String columnName) throws SQLException {
		return this.getResultSet().getInt(columnName);
	}

	public long getLong(String columnName) throws SQLException {
		return this.getResultSet().getLong(columnName);
	}

	public float getFloat(String columnName) throws SQLException {
		return this.getResultSet().getFloat(columnName);
	}

	public double getDouble(String columnName) throws SQLException {
		return this.getResultSet().getDouble(columnName);
	}

	public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException {
		return this.getResultSet().getBigDecimal(columnName, scale);
	}

	public byte[] getBytes(String columnName) throws SQLException {
		return this.getResultSet().getBytes(columnName);
	}

	public Date getDate(String columnName) throws SQLException {
		return ((PortabilityLayer) ((ConnectionProxy) ((ConnectionProxy) this.getParent().getParent())).getConnection()
				.getPortabilityLayer()).getDate(this.getResultSet(), columnName);
	}

	public Time getTime(String columnName) throws SQLException {
		return ((PortabilityLayer) ((ConnectionProxy) ((ConnectionProxy) this.getParent().getParent())).getConnection()
				.getPortabilityLayer()).getTime(this.getResultSet(), columnName);
	}

	public Timestamp getTimestamp(String columnName) throws SQLException {
		return this.getResultSet().getTimestamp(columnName);
	}

	public InputStream getAsciiStream(String columnName) throws SQLException {
		return this.getResultSet().getAsciiStream(columnName);
	}

	public InputStream getUnicodeStream(String columnName) throws SQLException {
		return this.getResultSet().getUnicodeStream(columnName);
	}

	public InputStream getBinaryStream(String columnName) throws SQLException {
		return this.getResultSet().getBinaryStream(columnName);
	}

	public SQLWarning getWarnings() throws SQLException {
		return this.getResultSet().getWarnings();
	}

	public void clearWarnings() throws SQLException {
		this.getResultSet().clearWarnings();
	}

	public String getCursorName() throws SQLException {
		return this.getResultSet().getCursorName();
	}

	public ResultSetMetaData getMetaData() throws SQLException {
		return this.getResultSet().getMetaData();
	}

	public Object getObject(int columnIndex) throws SQLException {
		return this.getResultSet().getObject(columnIndex);
	}

	public Object getObject(String columnName) throws SQLException {
		return this.getResultSet().getObject(columnName);
	}

	public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public int findColumn(String columnName) throws SQLException {
		return this.getResultSet().findColumn(columnName);
	}

	public SQLException translateException(SQLException e) throws SQLException {
		StatementProxy sProxy = (StatementProxy) this.getParent();
		return (SQLException) (sProxy != null
				? ((ConnectionProxy) ((ConnectionProxy) sProxy.getParent())).translateException(e)
				: new StaleConnectionException(e));
	}

	protected final ResultSet getResultSet() throws SQLException {
		if (this.isClosed()) {
			throw new StaleConnectionException(this.getClass() + " is closed");
		} else {
			return this.rs;
		}
	}
}