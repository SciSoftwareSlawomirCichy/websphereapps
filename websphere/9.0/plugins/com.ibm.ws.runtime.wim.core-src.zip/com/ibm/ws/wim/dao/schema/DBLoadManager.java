package com.ibm.ws.wim.dao.schema;

import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.adapter.db.DBCompositeRelation;
import com.ibm.ws.wim.adapter.db.DBProperty;
import com.ibm.ws.wim.adapter.db.DBPropertyEntity;
import com.ibm.ws.wim.lookaside.LACompositeRelation;
import com.ibm.ws.wim.lookaside.LAProperty;
import com.ibm.ws.wim.lookaside.LAPropertyEntity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DBLoadManager {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public static final String CLASSNAME = DBLoadManager.class.getName();
	private static final Logger trcLogger;
	private String dbType;
	private String url;
	private String driver;
	private String user;
	private String password;
	private String dbschema;
	private DBLoaderDao dbLoaderDao;
	private boolean traceOn;

	public DBLoadManager() {
	}

	public DBLoadManager(String var1, String var2, String var3, boolean var4) throws WIMSystemException {
		this(var1, var2, var3, (String) null, var4);
	}

	public DBLoadManager(String var1, String var2, String var3, String var4, boolean var5) throws WIMSystemException {
		this.dbType = var1;
		this.url = var2;
		this.driver = var3;
		this.traceOn = var5;
		this.dbschema = var4;
	}

	public DBLoadManager(String var1, String var2, String var3, String var4, String var5, boolean var6)
			throws WIMSystemException {
		this(var1, var2, var3, var4, var5, (String) null, var6);
	}

	public DBLoadManager(String var1, String var2, String var3, String var4, String var5, String var6, boolean var7)
			throws WIMSystemException {
		this.dbType = var1;
		this.url = var2;
		this.driver = var3;
		this.user = var4;
		this.password = var5;
		this.dbschema = var6;
		this.traceOn = var7;
	}

	private Set getEntityNameSet(Element var1) {
		HashSet var2 = null;
		NodeList var3 = var1.getElementsByTagName("wimprop:entityName");
		if (var3.getLength() != 0) {
			var2 = new HashSet();
		}

		for (int var4 = 0; var4 < var3.getLength(); ++var4) {
			Node var5 = var3.item(var4);
			var2.add(var5.getFirstChild().getNodeValue());
		}

		return var2;
	}

	public void createDBCompRelationEntry(int var1, Hashtable var2) throws WIMSystemException {
		Enumeration var4 = var2.keys();

		while (var4.hasMoreElements()) {
			Integer var5 = (Integer) var4.nextElement();
			Hashtable var6 = (Hashtable) var2.get(var5);
			DBCompositeRelation var7 = new DBCompositeRelation();
			var7.setCompositeId(var1);
			var7.setComponentId(var5);
			boolean var8 = new Boolean((String) var6.get("requiredInComposite"));
			var7.setRequiredInComposite(var8 ? 1 : 0);
			boolean var9 = new Boolean((String) var6.get("keyInComposite"));
			var7.setKeyInComposite(var9 ? 1 : 0);

			try {
				this.dbLoaderDao.createDBCompositeRelation(var7);
			} catch (Exception var11) {
				throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var11.getMessage()),
						CLASSNAME, "createDBCompRelationEntry", var11);
			}
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createDBCompRelationEntry",
					"Database composite property: " + var1 + " is created.");
		}

	}

	public void createLACompRelationEntry(int var1, Hashtable var2) throws WIMSystemException {
		Enumeration var4 = var2.keys();

		while (var4.hasMoreElements()) {
			Integer var5 = (Integer) var4.nextElement();
			Hashtable var6 = (Hashtable) var2.get(var5);
			LACompositeRelation var7 = new LACompositeRelation();
			var7.setCompositeId(var1);
			var7.setComponentId(var5);
			boolean var8 = new Boolean((String) var6.get("requiredInComposite"));
			var7.setRequiredInComposite(var8 ? 1 : 0);
			boolean var9 = new Boolean((String) var6.get("keyInComposite"));
			var7.setKeyInComposite(var9 ? 1 : 0);

			try {
				this.dbLoaderDao.createLACompositeRelation(var7);
			} catch (Exception var11) {
				throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var11.getMessage()),
						CLASSNAME, "createLACompRelationEntry", var11);
			}
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createLACompRelationEntry",
					"Lookaside composite property: " + var1 + " is created.");
		}

	}

	public Hashtable createNCompositePropertyEntry(String var1, Element var2, boolean var3, Set var4, String var5)
			throws WIMSystemException {
		Hashtable var7 = new Hashtable();
		DBRepositoryProperty var8 = new DBRepositoryProperty();
		boolean var9 = true;
		String var10 = var1 + "/" + var2.getAttribute("wimPropertyName");
		var8.setName(var10);
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createNCompositePropertyEntry",
					"...Loading composite property: " + var8.getName());
		}

		var8.setDataType("OBJECT");
		var8.setValueLength(0);
		var8.setMetadataName("DEFAULT");
		String var11 = var2.getAttribute("multiValued");
		if (var11.length() != 0) {
			var8.setMultipleValued(new Boolean(var11));
		}

		var8.setDescription(var2.getAttribute("description"));
		String var12 = var2.getAttribute("readOnly");
		if (var12.length() != 0) {
			var8.setReadOnly(new Boolean(var12));
		}

		var8.setApplicationId(var5);
		var8.setComposite(true);
		var8.setApplicableEntityTypes(var4);

		try {
			new Integer(-1);
			Integer var13;
			if (var3) {
				var13 = this.createDBProp(var8);
			} else {
				var13 = this.createLAProp(var8);
			}

			Hashtable var14 = new Hashtable();
			String var15 = var2.getAttribute("requiredInComposite");
			String var16 = var2.getAttribute("keyInComposite");
			var14.put("requiredInComposite", var15);
			var14.put("keyInComposite", var16);
			if (var13 != -1) {
				var7.put(var13, var14);
			}

			NodeList var17 = var2.getChildNodes();
			int var18 = var17.getLength();

			for (int var19 = 0; var19 < var18; ++var19) {
				Node var20 = var17.item(var19);
				new Hashtable();
				new Hashtable();
				if (var20.getNodeType() == 1) {
					String var23 = ((Element) var20).getTagName();
					if (var23.equals("wimprop:componentProperty")) {
						Hashtable var21 = this.createComponentPropertyEntry(var8.getName(), (Element) var20, var3,
								var8.getApplicableEntityTypes(), var8.getApplicationId());
						if (var3) {
							this.createDBCompRelationEntry(var13, var21);
						} else {
							this.createLACompRelationEntry(var13, var21);
						}
					} else if (var23.equals("wimprop:compositeProperty")) {
						Hashtable var22 = this.createNCompositePropertyEntry(var8.getName(), (Element) var20, var3,
								var8.getApplicableEntityTypes(), var8.getApplicationId());
						if (var3) {
							this.createDBCompRelationEntry(var13, var22);
						} else {
							this.createLACompRelationEntry(var13, var22);
						}
					}
				}
			}

			return var7;
		} catch (Exception var24) {
			throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var24.getMessage()),
					CLASSNAME, "createNCompositePropertyEntry", var24);
		}
	}

	public void createCompositePropertyEntry(NodeList var1, boolean var2) throws WIMSystemException {
		for (int var4 = 0; var4 < var1.getLength(); ++var4) {
			Element var5 = (Element) var1.item(var4);
			DBRepositoryProperty var6 = new DBRepositoryProperty();
			String var7 = var5.getAttribute("wimPropertyName");
			var6.setName(var7);
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "createCompositePropertyEntry",
						"...Loading composite property: " + var6.getName());
			}

			var6.setDataType("OBJECT");
			var6.setValueLength(0);
			String var8 = var5.getAttribute("metadataName");
			if (var8.trim().length() == 0) {
				var8 = "DEFAULT";
			}

			var6.setMetadataName(var8);
			String var9 = var5.getAttribute("multiValued");
			if (var9.length() != 0) {
				var6.setMultipleValued(new Boolean(var9));
			}

			var6.setDescription(var5.getAttribute("description"));
			String var10 = var5.getAttribute("readOnly");
			if (var10.length() != 0) {
				var6.setReadOnly(new Boolean(var10));
			}

			String var11 = var5.getAttribute("applicationId");
			if (var11.trim().length() == 0) {
				var11 = "com.ibm.websphere.wim";
			}

			var6.setApplicationId(var11);
			var6.setComposite(true);
			NodeList var12 = var5.getElementsByTagName("wimprop:applicableEntityName");
			if (var12.getLength() != 0) {
				Element var13 = (Element) var12.item(0);
				Set var14 = this.getEntityNameSet(var13);
				if (var14 != null) {
					var6.setApplicableEntityTypes(var14);
				}
			}

			NodeList var23 = var5.getElementsByTagName("wimprop:requiredEntityName");
			if (var23.getLength() != 0) {
				Element var24 = (Element) var23.item(0);
				Set var15 = this.getEntityNameSet(var24);
				if (var15 != null) {
					var6.setRequiredEntityTypes(var15);
				}
			}

			try {
				int var25;
				if (var2) {
					var25 = this.createDBProp(var6);
				} else {
					var25 = this.createLAProp(var6);
				}

				NodeList var26 = var5.getChildNodes();
				int var16 = var26.getLength();

				for (int var17 = 0; var17 < var16; ++var17) {
					Node var18 = var26.item(var17);
					new Hashtable();
					new Hashtable();
					if (var18.getNodeType() == 1) {
						String var21 = ((Element) var18).getTagName();
						if (var21.equals("wimprop:componentProperty")) {
							Hashtable var19 = this.createComponentPropertyEntry(var6.getName(), (Element) var18, var2,
									var6.getApplicableEntityTypes(), var6.getApplicationId());
							if (var2) {
								this.createDBCompRelationEntry(var25, var19);
							} else {
								this.createLACompRelationEntry(var25, var19);
							}
						} else if (var21.equals("wimprop:componentCompositeProperty")) {
							Hashtable var20 = this.createNCompositePropertyEntry(var6.getName(), (Element) var18, var2,
									var6.getApplicableEntityTypes(), var6.getApplicationId());
							if (var2) {
								this.createDBCompRelationEntry(var25, var20);
							} else {
								this.createLACompRelationEntry(var25, var20);
							}
						}
					}
				}
			} catch (Exception var22) {
				throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var22.getMessage()),
						CLASSNAME, "createCompositePropertyEntry", var22);
			}
		}

	}

	public Integer createDBProp(DBRepositoryProperty var1) throws WIMSystemException {
		DBProperty var3 = new DBProperty();
		var3.setName(var1.getName());
		var3.setTypeId(var1.getDataType().toUpperCase(Locale.ENGLISH));
		var3.setMetadataName(var1.getMetadataName());
		var3.setValueLength(var1.getValueLength());
		if (var1.isCaseSensitive()) {
			var3.setCaseExactMatch(1);
		} else {
			var3.setCaseExactMatch(0);
		}

		if (var1.isMultipleValued()) {
			var3.setMultiValued(1);
		} else {
			var3.setMultiValued(0);
		}

		if (var1.isReadOnly()) {
			var3.setReadOnly(1);
		} else {
			var3.setReadOnly(0);
		}

		var3.setClassName(var1.getClassName());
		var3.setDescription(var1.getDescription());
		var3.setApplicationId(var1.getApplicationId());
		if (var1.isComposite()) {
			var3.setIsComposite(1);
		} else {
			var3.setIsComposite(0);
		}

		int var4 = this.dbLoaderDao.createDBProperty(var3);
		Set var5 = var1.getApplicableEntityTypes();
		Set var6 = var1.getRequiredEntityTypes();
		DBPropertyEntity var8;
		if (var5 != null) {
			for (Iterator var7 = var5.iterator(); var7.hasNext(); this.dbLoaderDao.createDBPropertyEntity(var8)) {
				var8 = new DBPropertyEntity();
				var8.setPropertyId(var4);
				String var9 = (String) var7.next();
				var8.setApplicableEntityType(var9);
				if (var6 != null && var6.contains(var9)) {
					var8.setRequiredEntityType(1);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createDBProp",
					"Database Property:" + var1.getName() + " is loaded.");
		}

		return new Integer(var4);
	}

	public Integer createLAProp(DBRepositoryProperty var1) throws WIMSystemException {
		LAProperty var3 = new LAProperty();
		var3.setName(var1.getName());
		var3.setDatatypeId(var1.getDataType().toUpperCase(Locale.ENGLISH));
		var3.setMetadataName(var1.getMetadataName());
		var3.setValueLength(var1.getValueLength());
		if (var1.isCaseSensitive()) {
			var3.setCaseExactMatch(1);
		} else {
			var3.setCaseExactMatch(0);
		}

		if (var1.isMultipleValued()) {
			var3.setMultiValued(1);
		} else {
			var3.setMultiValued(0);
		}

		if (var1.isReadOnly()) {
			var3.setReadOnly(1);
		} else {
			var3.setReadOnly(0);
		}

		var3.setClassname(var1.getClassName());
		var3.setDescription(var1.getDescription());
		var3.setApplicationId(var1.getApplicationId());
		if (var1.isComposite()) {
			var3.setIsComposite(1);
		} else {
			var3.setIsComposite(0);
		}

		int var4 = this.dbLoaderDao.createLAProperty(var3);
		Set var5 = var1.getApplicableEntityTypes();
		Set var6 = var1.getRequiredEntityTypes();
		LAPropertyEntity var8;
		if (var5 != null) {
			for (Iterator var7 = var5.iterator(); var7.hasNext(); this.dbLoaderDao.createLAPropertyEntity(var8)) {
				var8 = new LAPropertyEntity();
				var8.setPropertyId(var4);
				String var9 = (String) var7.next();
				var8.setApplicableEntityType(var9);
				if (var6 != null && var6.contains(var9)) {
					var8.setRequiredEntityType(1);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createLAProp",
					"Lookaside Property:" + var1.getName() + " is loaded.");
		}

		return new Integer(var4);
	}

	public Hashtable createComponentPropertyEntry(String var1, Element var2, boolean var3, Set var4, String var5)
			throws WIMSystemException {
		Hashtable var7 = new Hashtable();
		DBRepositoryProperty var8 = new DBRepositoryProperty();
		var8.setName(var1 + "/" + var2.getAttribute("wimPropertyName"));
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "createComponentPropertyEntry",
					"...Loading property: " + var8.getName());
		}

		var8.setDataType(var2.getAttribute("dataType"));
		String var9 = var2.getAttribute("valueLength");
		if (var9.length() == 0) {
			if (var8.getDataType().toUpperCase(Locale.ENGLISH).equals("STRING")) {
				var9 = "1500";
			} else {
				var9 = "0";
			}
		}

		var8.setValueLength(new Integer(var9));
		var8.setMetadataName("DEFAULT");
		String var10 = var2.getAttribute("multiValued");
		if (var10.length() != 0) {
			var8.setMultipleValued(new Boolean(var10));
		}

		String var11 = var2.getAttribute("readOnly");
		if (var11.length() != 0) {
			var8.setReadOnly(new Boolean(var11));
		}

		String var12 = var2.getAttribute("classname");
		if (var12.length() != 0 && var8.getDataType().equalsIgnoreCase("OBJECT")) {
			var8.setClassName(var12);
		}

		String var13 = var2.getAttribute("caseExactMatch");
		if (var13.length() != 0) {
			var8.setCaseSensitive(new Boolean(var13));
		}

		String var14 = var2.getAttribute("description");
		if (var14.length() != 0) {
			var8.setDescription(var14);
		}

		var8.setApplicationId(var5);
		var8.setApplicableEntityTypes(var4);
		new Integer(-1);

		Integer var15;
		try {
			if (var3) {
				var15 = this.createDBProp(var8);
			} else {
				var15 = this.createLAProp(var8);
			}
		} catch (Exception var19) {
			throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var19.getMessage()),
					CLASSNAME, "createComponentPropertyEntry", var19);
		}

		Hashtable var16 = new Hashtable();
		String var17 = var2.getAttribute("requiredInComposite");
		String var18 = var2.getAttribute("keyInComposite");
		var16.put("requiredInComposite", var17);
		var16.put("keyInComposite", var18);
		if (var15 != -1) {
			var7.put(var15, var16);
		}

		return var7;
	}

	public void createSinglePropertyEntry(NodeList var1, boolean var2) throws WIMSystemException {
		for (int var4 = 0; var4 < var1.getLength(); ++var4) {
			Element var5 = (Element) var1.item(var4);
			DBRepositoryProperty var6 = new DBRepositoryProperty();
			var6.setName(var5.getAttribute("wimPropertyName"));
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "createSinglePropertyEntry",
						"...Loading property: " + var6.getName());
			}

			var6.setDataType(var5.getAttribute("dataType"));
			String var7 = var5.getAttribute("valueLength");
			if (var7.length() == 0) {
				if (var6.getDataType().toUpperCase(Locale.ENGLISH).equals("STRING")) {
					var7 = "1500";
				} else {
					var7 = "0";
				}
			}

			var6.setValueLength(new Integer(var7));
			String var8 = var5.getAttribute("metadataName");
			if (var8.trim().length() == 0) {
				var8 = "DEFAULT";
			}

			var6.setMetadataName(var8);
			String var9 = var5.getAttribute("multiValued");
			if (var9.length() != 0) {
				var6.setMultipleValued(new Boolean(var9));
			}

			String var10 = var5.getAttribute("readOnly");
			if (var10.length() != 0) {
				var6.setReadOnly(new Boolean(var10));
			}

			String var11 = var5.getAttribute("classname");
			if (var11.length() != 0 && var6.getDataType().equalsIgnoreCase("OBJECT")) {
				var6.setClassName(var11);
			}

			String var12 = var5.getAttribute("caseExactMatch");
			if (var12.length() != 0) {
				var6.setCaseSensitive(new Boolean(var12));
			}

			String var13 = var5.getAttribute("description");
			if (var13.trim().length() != 0) {
				var6.setDescription(var13);
			}

			String var14 = var5.getAttribute("applicationId");
			if (var14.trim().length() == 0) {
				var14 = "com.ibm.websphere.wim";
			}

			var6.setApplicationId(var14);
			NodeList var15 = var5.getElementsByTagName("wimprop:applicableEntityName");
			Element var16 = (Element) var15.item(0);
			Set var17 = this.getEntityNameSet(var16);
			if (var17 != null) {
				var6.setApplicableEntityTypes(var17);
			}

			NodeList var18 = var5.getElementsByTagName("wimprop:requiredEntityName");
			if (var18.getLength() != 0) {
				Element var19 = (Element) var18.item(0);
				Set var20 = this.getEntityNameSet(var19);
				if (var17 != null) {
					var6.setRequiredEntityTypes(var20);
				}
			}

			try {
				if (var2) {
					this.createDBProp(var6);
				} else {
					this.createLAProp(var6);
				}
			} catch (Exception var21) {
				throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var21.getMessage()),
						CLASSNAME, "createSinglePropertyEntry", var21);
			}
		}

	}

	public void initialize(String var1) throws WIMSystemException {
		try {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "initialize", "File: " + var1 + " is processing...");
			}

			DocumentBuilderFactory var3 = FactoryManager.getDocumentBuilderFactory();
			var3.setValidating(false);
			DocumentBuilder var4 = var3.newDocumentBuilder();
			Document var5 = var4.parse(var1);
			Element var6 = var5.getDocumentElement();
			String var7 = var6.getAttribute("repositoryName");
			boolean var8 = false;
			if (var7.equalsIgnoreCase("wimDB")) {
				var8 = true;
			} else {
				if (!var7.equalsIgnoreCase("wimLA")) {
					String var19 = "repositoryName in file " + var1 + " must be either " + "wimDB" + " or " + "wimLA";
					throw new WIMSystemException(var19, CLASSNAME, "initialize");
				}

				var8 = false;
			}

			if (trcLogger.isLoggable(Level.FINE)) {
				if (var8) {
					trcLogger.logp(Level.FINE, CLASSNAME, "initialize",
							"Loading property data into database repository.");
				} else {
					trcLogger.logp(Level.FINE, CLASSNAME, "initialize",
							"Loading property data into lookaside repository");
				}
			}

			if (this.user != null && this.password != null) {
				this.dbLoaderDao = new DBLoaderDao(this.dbType, this.url, this.driver, this.user, this.password,
						this.dbschema, this.traceOn);
			} else {
				this.dbLoaderDao = new DBLoaderDao(this.dbType, this.url, this.driver, this.dbschema, this.traceOn);
			}

			if (!var8 && var6.getElementsByTagName("wimprop:property").getLength() == 0
					&& var6.getElementsByTagName("wimprop:compositeProperty").getLength() == 0) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "initialize",
							"Checking whether the database exist and also if the tables exist in the database....");
				}

				Connection var9 = null;

				try {
					var9 = this.dbLoaderDao.getConnection();
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "initialize",
								"Database exists.Now checking whether the tables exist..");
					}

					String var10 = this.dbLoaderDao.querySet.selectLAKeys;
					PreparedStatement var11 = var9.prepareStatement(var10);
					var11.executeQuery();
				} catch (Exception var16) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "initialize",
								"Either the database or the tables in the database do not exist ", var16);
					}

					if (!(var16.getCause() instanceof SQLException)) {
						throw new WIMSystemException("SQL_EXCEPTION",
								WIMMessageHelper.generateMsgParms(var16.getMessage()), CLASSNAME, "initialize", var16);
					}

					throw var16;
				} finally {
					if (var9 != null) {
						var9.close();
					}

				}
			}

			this.createSinglePropertyEntry(var6.getElementsByTagName("wimprop:property"), var8);
			this.createCompositePropertyEntry(var6.getElementsByTagName("wimprop:compositeProperty"), var8);
		} catch (Exception var18) {
			throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var18.getMessage()),
					CLASSNAME, "initialize", var18);
		}
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}