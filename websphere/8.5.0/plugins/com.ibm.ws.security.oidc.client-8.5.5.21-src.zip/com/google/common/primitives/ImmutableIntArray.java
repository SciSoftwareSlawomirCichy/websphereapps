package com.google.common.primitives;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.primitives.ImmutableIntArray.1;
import com.google.common.primitives.ImmutableIntArray.AsList;
import com.google.common.primitives.ImmutableIntArray.Builder;
import com.google.errorprone.annotations.Immutable;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@Immutable
@Beta
@GwtCompatible
public final class ImmutableIntArray implements Serializable {
	private static final ImmutableIntArray EMPTY = new ImmutableIntArray(new int[0]);
	private final int[] array;
	private final transient int start;
	private final int end;

	public static ImmutableIntArray of() {
		return EMPTY;
	}

	public static ImmutableIntArray of(int e0) {
		return new ImmutableIntArray(new int[]{e0});
	}

	public static ImmutableIntArray of(int e0, int e1) {
		return new ImmutableIntArray(new int[]{e0, e1});
	}

	public static ImmutableIntArray of(int e0, int e1, int e2) {
		return new ImmutableIntArray(new int[]{e0, e1, e2});
	}

	public static ImmutableIntArray of(int e0, int e1, int e2, int e3) {
		return new ImmutableIntArray(new int[]{e0, e1, e2, e3});
	}

	public static ImmutableIntArray of(int e0, int e1, int e2, int e3, int e4) {
		return new ImmutableIntArray(new int[]{e0, e1, e2, e3, e4});
	}

	public static ImmutableIntArray of(int e0, int e1, int e2, int e3, int e4, int e5) {
		return new ImmutableIntArray(new int[]{e0, e1, e2, e3, e4, e5});
	}

	public static ImmutableIntArray of(int first, int... rest) {
		Preconditions.checkArgument(rest.length <= 2147483646, "the total number of elements must fit in an int");
		int[] array = new int[rest.length + 1];
		array[0] = first;
		System.arraycopy(rest, 0, array, 1, rest.length);
		return new ImmutableIntArray(array);
	}

	public static ImmutableIntArray copyOf(int[] values) {
		return values.length == 0 ? EMPTY : new ImmutableIntArray(Arrays.copyOf(values, values.length));
	}

	public static ImmutableIntArray copyOf(Collection<Integer> values) {
		return values.isEmpty() ? EMPTY : new ImmutableIntArray(Ints.toArray(values));
	}

	public static ImmutableIntArray copyOf(Iterable<Integer> values) {
		return values instanceof Collection ? copyOf((Collection) values) : builder().addAll(values).build();
	}

	public static Builder builder(int initialCapacity) {
		Preconditions.checkArgument(initialCapacity >= 0, "Invalid initialCapacity: %s", initialCapacity);
		return new Builder(initialCapacity);
	}

	public static Builder builder() {
		return new Builder(10);
	}

	private ImmutableIntArray(int[] array) {
		this(array, 0, array.length);
	}

	private ImmutableIntArray(int[] array, int start, int end) {
		this.array = array;
		this.start = start;
		this.end = end;
	}

	public int length() {
		return this.end - this.start;
	}

	public boolean isEmpty() {
		return this.end == this.start;
	}

	public int get(int index) {
		Preconditions.checkElementIndex(index, this.length());
		return this.array[this.start + index];
	}

	public int indexOf(int target) {
		for (int i = this.start; i < this.end; ++i) {
			if (this.array[i] == target) {
				return i - this.start;
			}
		}

		return -1;
	}

	public int lastIndexOf(int target) {
		for (int i = this.end - 1; i >= this.start; --i) {
			if (this.array[i] == target) {
				return i - this.start;
			}
		}

		return -1;
	}

	public boolean contains(int target) {
		return this.indexOf(target) >= 0;
	}

	public int[] toArray() {
		return Arrays.copyOfRange(this.array, this.start, this.end);
	}

	public ImmutableIntArray subArray(int startIndex, int endIndex) {
		Preconditions.checkPositionIndexes(startIndex, endIndex, this.length());
		return startIndex == endIndex
				? EMPTY
				: new ImmutableIntArray(this.array, this.start + startIndex, this.start + endIndex);
	}

	public List<Integer> asList() {
      return new AsList(this, (1)null);
   }

	public boolean equals(@NullableDecl Object object) {
		if (object == this) {
			return true;
		} else if (!(object instanceof ImmutableIntArray)) {
			return false;
		} else {
			ImmutableIntArray that = (ImmutableIntArray) object;
			if (this.length() != that.length()) {
				return false;
			} else {
				for (int i = 0; i < this.length(); ++i) {
					if (this.get(i) != that.get(i)) {
						return false;
					}
				}

				return true;
			}
		}
	}

	public int hashCode() {
		int hash = 1;

		for (int i = this.start; i < this.end; ++i) {
			hash *= 31;
			hash += Ints.hashCode(this.array[i]);
		}

		return hash;
	}

	public String toString() {
		if (this.isEmpty()) {
			return "[]";
		} else {
			StringBuilder builder = new StringBuilder(this.length() * 5);
			builder.append('[').append(this.array[this.start]);

			for (int i = this.start + 1; i < this.end; ++i) {
				builder.append(", ").append(this.array[i]);
			}

			builder.append(']');
			return builder.toString();
		}
	}

	public ImmutableIntArray trimmed() {
		return this.isPartialView() ? new ImmutableIntArray(this.toArray()) : this;
	}

	private boolean isPartialView() {
		return this.start > 0 || this.end < this.array.length;
	}

	Object writeReplace() {
		return this.trimmed();
	}

	Object readResolve() {
		return this.isEmpty() ? EMPTY : this;
	}
}