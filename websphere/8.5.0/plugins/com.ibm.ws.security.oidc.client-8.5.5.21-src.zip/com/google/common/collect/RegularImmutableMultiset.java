package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.collect.Multiset.Entry;
import com.google.common.collect.RegularImmutableMultiset.1;
import com.google.common.collect.RegularImmutableMultiset.ElementSet;
import com.google.common.collect.RegularImmutableMultiset.SerializedForm;
import com.google.common.primitives.Ints;
import com.google.errorprone.annotations.concurrent.LazyInit;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true, serializable = true)
class RegularImmutableMultiset<E> extends ImmutableMultiset<E> {
	static final RegularImmutableMultiset<Object> EMPTY = new RegularImmutableMultiset(ObjectCountHashMap.create());
	final transient ObjectCountHashMap<E> contents;
	private final transient int size;
	@LazyInit
	private transient ImmutableSet<E> elementSet;

	RegularImmutableMultiset(ObjectCountHashMap<E> contents) {
		this.contents = contents;
		long size = 0L;

		for (int i = 0; i < contents.size(); ++i) {
			size += (long) contents.getValue(i);
		}

		this.size = Ints.saturatedCast(size);
	}

	boolean isPartialView() {
		return false;
	}

	public int count(@NullableDecl Object element) {
		return this.contents.get(element);
	}

	public int size() {
		return this.size;
	}

	public ImmutableSet<E> elementSet() {
      ImmutableSet<E> result = this.elementSet;
      return result == null ? (this.elementSet = new ElementSet(this, (1)null)) : result;
   }

	Entry<E> getEntry(int index) {
		return this.contents.getEntry(index);
	}

	@GwtIncompatible
	Object writeReplace() {
		return new SerializedForm(this);
	}
}