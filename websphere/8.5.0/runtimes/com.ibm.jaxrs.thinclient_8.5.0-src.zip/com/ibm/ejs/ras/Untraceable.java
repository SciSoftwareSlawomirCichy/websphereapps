package com.ibm.ejs.ras;

public interface Untraceable {
}