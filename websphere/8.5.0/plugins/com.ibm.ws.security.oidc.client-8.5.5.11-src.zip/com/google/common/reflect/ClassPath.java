package com.google.common.reflect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import com.google.common.collect.Ordering;
import com.google.common.collect.ImmutableSortedSet.Builder;
import com.google.common.reflect.ClassPath.ClassInfo;
import com.google.common.reflect.ClassPath.ResourceInfo;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.logging.Logger;
import javax.annotation.Nullable;

@Beta
public final class ClassPath {
	private static final Logger logger = Logger.getLogger(ClassPath.class.getName());
	private static final Splitter CLASS_PATH_ATTRIBUTE_SEPARATOR = Splitter.on(" ").omitEmptyStrings();
	private static final String CLASS_FILE_NAME_EXTENSION = ".class";
	private final ImmutableSet<ResourceInfo> resources;

	private ClassPath(ImmutableSet<ResourceInfo> resources) {
		this.resources = resources;
	}

	public static ClassPath from(ClassLoader classloader) throws IOException {
		Builder<ResourceInfo> resources = new Builder(Ordering.usingToString());
		Iterator i$ = getClassPathEntries(classloader).entrySet().iterator();

		while (i$.hasNext()) {
			Entry<URI, ClassLoader> entry = (Entry) i$.next();
			browse((URI) entry.getKey(), (ClassLoader) entry.getValue(), resources);
		}

		return new ClassPath(resources.build());
	}

	public ImmutableSet<ResourceInfo> getResources() {
		return this.resources;
	}

	public ImmutableSet<ClassInfo> getTopLevelClasses() {
		com.google.common.collect.ImmutableSet.Builder<ClassInfo> builder = ImmutableSet.builder();
		Iterator i$ = this.resources.iterator();

		while (i$.hasNext()) {
			ResourceInfo resource = (ResourceInfo) i$.next();
			if (resource instanceof ClassInfo) {
				builder.add((ClassInfo) resource);
			}
		}

		return builder.build();
	}

	public ImmutableSet<ClassInfo> getTopLevelClasses(String packageName) {
		Preconditions.checkNotNull(packageName);
		com.google.common.collect.ImmutableSet.Builder<ClassInfo> builder = ImmutableSet.builder();
		Iterator i$ = this.getTopLevelClasses().iterator();

		while (i$.hasNext()) {
			ClassInfo classInfo = (ClassInfo) i$.next();
			if (classInfo.getPackageName().equals(packageName)) {
				builder.add(classInfo);
			}
		}

		return builder.build();
	}

	public ImmutableSet<ClassInfo> getTopLevelClassesRecursive(String packageName) {
		Preconditions.checkNotNull(packageName);
		String packagePrefix = packageName + '.';
		com.google.common.collect.ImmutableSet.Builder<ClassInfo> builder = ImmutableSet.builder();
		Iterator i$ = this.getTopLevelClasses().iterator();

		while (i$.hasNext()) {
			ClassInfo classInfo = (ClassInfo) i$.next();
			if (classInfo.getName().startsWith(packagePrefix)) {
				builder.add(classInfo);
			}
		}

		return builder.build();
	}

	@VisibleForTesting
	static ImmutableMap<URI, ClassLoader> getClassPathEntries(ClassLoader classloader) {
		LinkedHashMap<URI, ClassLoader> entries = Maps.newLinkedHashMap();
		ClassLoader parent = classloader.getParent();
		if (parent != null) {
			entries.putAll(getClassPathEntries(parent));
		}

		if (classloader instanceof URLClassLoader) {
			URLClassLoader urlClassLoader = (URLClassLoader) classloader;
			URL[] arr$ = urlClassLoader.getURLs();
			int len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				URL entry = arr$[i$];

				URI uri;
				try {
					uri = entry.toURI();
				} catch (URISyntaxException var10) {
					throw new IllegalArgumentException(var10);
				}

				if (!entries.containsKey(uri)) {
					entries.put(uri, classloader);
				}
			}
		}

		return ImmutableMap.copyOf(entries);
	}

	private static void browse(URI uri, ClassLoader classloader,
			com.google.common.collect.ImmutableSet.Builder<ResourceInfo> resources) throws IOException {
		if (uri.getScheme().equals("file")) {
			browseFrom(new File(uri), classloader, resources);
		}

	}

	@VisibleForTesting
	static void browseFrom(File file, ClassLoader classloader,
			com.google.common.collect.ImmutableSet.Builder<ResourceInfo> resources) throws IOException {
		if (file.exists()) {
			if (file.isDirectory()) {
				browseDirectory(file, classloader, resources);
			} else {
				browseJar(file, classloader, resources);
			}

		}
	}

	private static void browseDirectory(File directory, ClassLoader classloader,
			com.google.common.collect.ImmutableSet.Builder<ResourceInfo> resources) {
		browseDirectory(directory, classloader, "", resources);
	}

	private static void browseDirectory(File directory, ClassLoader classloader, String packagePrefix,
			com.google.common.collect.ImmutableSet.Builder<ResourceInfo> resources) {
		File[] arr$ = directory.listFiles();
		int len$ = arr$.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			File f = arr$[i$];
			String name = f.getName();
			if (f.isDirectory()) {
				browseDirectory(f, classloader, packagePrefix + name + "/", resources);
			} else {
				String resourceName = packagePrefix + name;
				resources.add(ResourceInfo.of(resourceName, classloader));
			}
		}

	}

	private static void browseJar(File file, ClassLoader classloader,
			com.google.common.collect.ImmutableSet.Builder<ResourceInfo> resources) throws IOException {
		JarFile jarFile;
		try {
			jarFile = new JarFile(file);
		} catch (IOException var13) {
			return;
		}

		try {
			Iterator i$ = getClassPathFromManifest(file, jarFile.getManifest()).iterator();

			while (i$.hasNext()) {
				URI uri = (URI) i$.next();
				browse(uri, classloader, resources);
			}

			Enumeration entries = jarFile.entries();

			while (entries.hasMoreElements()) {
				JarEntry entry = (JarEntry) entries.nextElement();
				if (!entry.isDirectory() && !entry.getName().startsWith("META-INF/")) {
					resources.add(ResourceInfo.of(entry.getName(), classloader));
				}
			}
		} finally {
			try {
				jarFile.close();
			} catch (IOException var12) {
				;
			}

		}

	}

	@VisibleForTesting
	static ImmutableSet<URI> getClassPathFromManifest(File jarFile, @Nullable Manifest manifest) {
		if (manifest == null) {
			return ImmutableSet.of();
		} else {
			com.google.common.collect.ImmutableSet.Builder<URI> builder = ImmutableSet.builder();
			String classpathAttribute = manifest.getMainAttributes().getValue("Class-Path");
			if (classpathAttribute != null) {
				Iterator i$ = CLASS_PATH_ATTRIBUTE_SEPARATOR.split(classpathAttribute).iterator();

				while (i$.hasNext()) {
					String path = (String) i$.next();

					URI uri;
					try {
						uri = getClassPathEntry(jarFile, path);
					} catch (URISyntaxException var8) {
						logger.warning("Invalid Class-Path entry: " + path);
						continue;
					}

					builder.add(uri);
				}
			}

			return builder.build();
		}
	}

	@VisibleForTesting
	static URI getClassPathEntry(File jarFile, String path) throws URISyntaxException {
		URI uri = new URI(path);
		return uri.isAbsolute()
				? uri
				: (new File(jarFile.getParentFile(), path.replace('/', File.separatorChar))).toURI();
	}

	@VisibleForTesting
	static String getClassName(String filename) {
		int classNameEnd = filename.length() - ".class".length();
		return filename.substring(0, classNameEnd).replace('/', '.');
	}
}