package com.ibm.ejs.container;

import com.ibm.ejs.container.MDBInterceptorWrapper.CheckedException;
import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.ws.ffdc.FFDCFilter;
import javax.ejb.Timer;
import javax.jms.Message;
import javax.jms.MessageListener;

public class MDBInterceptorWrapper implements MessageListener {
	private static final String CLASS_NAME = MDBInterceptorWrapper.class.getName();
	private static final TraceComponent tc = Tr.register(MDBInterceptorWrapper.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private final MessageDrivenBeanO ivBeanO;
	private final EJSDeployedSupport ivEJSDeployedSupport;

	MDBInterceptorWrapper(MessageDrivenBeanO beanO, EJSDeployedSupport s) {
		this.ivBeanO = beanO;
		this.ivEJSDeployedSupport = s;
	}

	public void onMessage(Message message) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "onMessage: " + this.ivBeanO.beanId + ", " + Util.identity(message));
		}

		EJSDeployedSupport s = this.ivEJSDeployedSupport;
		InvocationContextImpl inv = s.getInvocationContext(this.ivBeanO.ivEjbInstance, this.ivBeanO.ivInterceptors,
				(Timer) null);
		EJBMethodInfoImpl methodInfo = s.methodInfo;

		try {
			inv.doAroundInvoke(methodInfo.ivAroundInterceptors, methodInfo.ivMethod, new Object[]{message}, s);
		} catch (RuntimeException var7) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "onMessage", var7);
			}

			throw var7;
		} catch (Exception var8) {
			FFDCFilter.processException(var8, CLASS_NAME + ".onMessage", "92", this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "onMessage", var8);
			}

			throw new CheckedException(var8);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "onMessage");
		}

	}
}