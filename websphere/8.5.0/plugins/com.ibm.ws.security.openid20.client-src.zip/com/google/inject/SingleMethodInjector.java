package com.google.inject;

import com.google.inject.InjectorImpl.MethodInvoker;
import com.google.inject.SingleMethodInjector.1;
import com.google.inject.SingleMethodInjector.2;
import com.google.inject.internal.BytecodeGen;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.InternalContext;
import com.google.inject.internal.BytecodeGen.Visibility;
import com.google.inject.internal.cglib.reflect.FastMethod;
import com.google.inject.spi.InjectionPoint;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

class SingleMethodInjector implements SingleMemberInjector {
	final MethodInvoker methodInvoker;
	final SingleParameterInjector<?>[] parameterInjectors;
	final InjectionPoint injectionPoint;

	public SingleMethodInjector(InjectorImpl injector, InjectionPoint injectionPoint, Errors errors)
			throws ErrorsException {
		this.injectionPoint = injectionPoint;
		Method method = (Method) injectionPoint.getMember();
		this.methodInvoker = this.createMethodInvoker(method);
		this.parameterInjectors = injector.getParametersInjectors(injectionPoint.getDependencies(), errors);
	}

	private MethodInvoker createMethodInvoker(Method method) {
      int modifiers = method.getModifiers();
      if (!Modifier.isPrivate(modifiers) && !Modifier.isProtected(modifiers)) {
         FastMethod fastMethod = BytecodeGen.newFastClass(method.getDeclaringClass(), Visibility.forMember(method)).getMethod(method);
         return new 1(this, fastMethod);
      } else {
         if (!Modifier.isPublic(modifiers)) {
            method.setAccessible(true);
         }

         return new 2(this, method);
      }
   }

	public InjectionPoint getInjectionPoint() {
		return this.injectionPoint;
	}

	public void inject(Errors errors, InternalContext context, Object o) {
		Object[] parameters;
		try {
			parameters = SingleParameterInjector.getAll(errors, context, this.parameterInjectors);
		} catch (ErrorsException var7) {
			errors.merge(var7.getErrors());
			return;
		}

		try {
			this.methodInvoker.invoke(o, parameters);
		} catch (IllegalAccessException var8) {
			throw new AssertionError(var8);
		} catch (InvocationTargetException var9) {
			Throwable cause = var9.getCause() != null ? var9.getCause() : var9;
			errors.withSource(this.injectionPoint).errorInjectingMethod((Throwable) cause);
		}

	}
}