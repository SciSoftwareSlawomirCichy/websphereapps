package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.container.EJSHome;
import com.ibm.ejs.container.lock.LockStrategy;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.IllegalOperationException;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.transaction.TransactionRolledbackException;

public class OptAEntityActivationStrategy extends SingletonActivationStrategy {
	protected int maxRetries = 10;
	protected Activator activator;
	private static final TraceComponent tc = Tr.register(OptAEntityActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.activator.OptAEntityActivationStrategy";

	public OptAEntityActivationStrategy(Activator activator) {
		super(activator);
		this.activator = activator;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> complete");
		}

	}

	protected BeanO doActivation(EJBThreadData threadData, ContainerTx tx, BeanId beanId, boolean takeInvocationRef)
			throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "doActivation (" + beanId + ")", new Object[]{tx, takeInvocationRef});
		}

		BeanO bean = null;
		Throwable exception = null;
		MasterKey key = new MasterKey(beanId);
		boolean pin = false;
		boolean pushedCallbackBeanO = false;
		LockStrategy lockStrategy = null;
		boolean locked = false;
		boolean var56 = false;

		try {
			var56 = true;
			lockStrategy = ((EJSHome) beanId.getHome()).getLockStrategy();
			lockStrategy.lock(this.activator.container, tx, beanId, 1);
			locked = true;
			synchronized (this.locks.getLock(key)) {
				if ((bean = (BeanO) this.cache.find(key)) == null) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Bean not in cache");
					}

					bean = beanId.getHome().createBeanO(threadData, tx, beanId);
					pushedCallbackBeanO = true;
					this.cache.insert(key, bean);
					bean.ivCacheKey = key;
				} else {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Found bean in cache");
					}

					threadData.pushCallbackBeanO(bean);
					pushedCallbackBeanO = true;
				}
			}

			int state = bean.getState();
			if (state != 8 && state != 10) {
				bean.activate(beanId, tx);
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "OptACommitting");
			}

			pin = bean.enlist(tx);
			if (takeInvocationRef && pin) {
				this.cache.pin(key);
				var56 = false;
			} else if (!takeInvocationRef) {
				if (!pin) {
					this.cache.unpin(key);
					var56 = false;
				} else {
					var56 = false;
				}
			} else {
				var56 = false;
			}
		} catch (NoSuchObjectException var64) {
			exception = var64;
			throw var64;
		} catch (RemoteException var65) {
			FFDCFilter.processException(var65,
					"com.ibm.ejs.container.activator.OptAEntityActivationStrategy.doActivation", "135", this);
			exception = var65;
			throw var65;
		} catch (RuntimeException var66) {
			FFDCFilter.processException(var66,
					"com.ibm.ejs.container.activator.OptAEntityActivationStrategy.doActivation", "167", this);
			exception = var66;
			throw var66;
		} catch (Throwable var67) {
			FFDCFilter.processException(var67,
					"com.ibm.ejs.container.activator.OptAEntityActivationStrategy.doActivation", "172", this);
			exception = var67;
			throw ExceptionUtil.EJBException(var67);
		} finally {
			if (var56) {
				if (exception != null) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "doActivation: exception raised", exception);
					}

					try {
						if (bean != null) {
							if (pushedCallbackBeanO) {
								threadData.popCallbackBeanO();
							}

							if (pin) {
								tx.delist(bean);
							}

							synchronized (this.locks.getLock(key)) {
								this.cache.remove(key, true);
								bean.ivCacheKey = null;
							}

							bean.destroy();
						}
					} catch (IllegalOperationException var60) {
						FFDCFilter.processException(var60,
								"com.ibm.ejs.container.activator.OptAEntityActivationStrategy.doActivation", "168",
								this);
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "doActivation: cache remove failed,  just unpinning, not unlocking");
						}

						this.cache.unpin(key);
						locked = false;
					} finally {
						if (locked) {
							lockStrategy.unlock(this.activator.container, beanId, tx);
						}

					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "doActivation", bean);
				}

			}
		}

		if (exception != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "doActivation: exception raised", exception);
			}

			try {
				if (bean != null) {
					if (pushedCallbackBeanO) {
						threadData.popCallbackBeanO();
					}

					if (pin) {
						tx.delist(bean);
					}

					synchronized (this.locks.getLock(key)) {
						this.cache.remove(key, true);
						bean.ivCacheKey = null;
					}

					bean.destroy();
				}
			} catch (IllegalOperationException var62) {
				FFDCFilter.processException(var62,
						"com.ibm.ejs.container.activator.OptAEntityActivationStrategy.doActivation", "168", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "doActivation: cache remove failed,  just unpinning, not unlocking");
				}

				this.cache.unpin(key);
				locked = false;
			} finally {
				if (locked) {
					lockStrategy.unlock(this.activator.container, beanId, tx);
				}

			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "doActivation", bean);
		}

		return bean;
	}

	BeanO atCreate(ContainerTx tx, BeanO bean) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCreate", new Object[]{tx, bean});
		}

		BeanId beanId = bean.getId();
		MasterKey key = new MasterKey(beanId);
		boolean inserted = false;
		boolean exception = false;
		boolean var24 = false;

		label234 : {
			BeanO var9;
			try {
				label235 : {
					var24 = true;
					synchronized (this.locks.getLock(key)) {
						BeanO existingBean = (BeanO) this.cache.find(key);
						if (existingBean != null) {
							this.cache.unpin(key);
							if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
								Tr.exit(tc, "atCreate: found bean in cache", existingBean);
							}

							var9 = existingBean;
							var24 = false;
							break label235;
						}

						this.cache.insert(key, bean);
						bean.ivCacheKey = key;
						inserted = true;
					}

					if (!bean.enlist(tx)) {
						this.cache.unpin(key);
						var24 = false;
					} else {
						var24 = false;
					}
					break label234;
				}
			} catch (RemoteException var29) {
				FFDCFilter.processException(var29,
						"com.ibm.ejs.container.activator.OptAEntityActivationStrategy.atCreate", "260", this);
				exception = true;
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Exception raised", var29);
				}

				throw var29;
			} catch (RuntimeException var30) {
				FFDCFilter.processException(var30,
						"com.ibm.ejs.container.activator.OptAEntityActivationStrategy.atCreate", "267", this);
				exception = true;
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "atCreate", var30);
				}

				throw var30;
			} finally {
				if (var24) {
					if (exception) {
						bean.destroy();
						if (inserted) {
							synchronized (this.locks.getLock(key)) {
								this.cache.remove(key, true);
								bean.ivCacheKey = null;
							}
						}
					}

				}
			}

			if (exception) {
				bean.destroy();
				if (inserted) {
					synchronized (this.locks.getLock(key)) {
						this.cache.remove(key, true);
						bean.ivCacheKey = null;
					}
				}
			}

			return var9;
		}

		if (exception) {
			bean.destroy();
			if (inserted) {
				synchronized (this.locks.getLock(key)) {
					this.cache.remove(key, true);
					bean.ivCacheKey = null;
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCreate (null)");
		}

		return null;
	}

	BeanO atActivate(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		return this.doActivation(threadData, tx, beanId, false);
	}

	void atPostInvoke(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atPostInvoke", new Object[]{tx, bean});
		}

		BeanId id = bean.getId();
		Object key = bean.ivCacheKey;
		boolean removed = false;
		if (key == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atPostInvoke : bean not in cache");
			}

		} else {
			LockStrategy lockStrategy = ((EJSHome) id.getHome()).getLockStrategy();
			synchronized (this.locks.getLock(key)) {
				BeanO beanO = (BeanO) this.cache.find(key);
				if (beanO != null) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Found bean in cache");
					}

					this.cache.unpin(key);
					if (beanO.isRemoved() || beanO.isDiscarded()) {
						if (tx != null) {
							try {
								tx.delist(beanO);
							} catch (TransactionRolledbackException var11) {
								FFDCFilter.processException(var11,
										"com.ibm.ejs.container.activator.OptAEntityActivationStrategy.atPostInvoke",
										"336", this);
								if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
									Tr.debug(tc, "Transaction has rolled back");
								}
							}
						}

						((BeanO) this.cache.remove(key, true)).destroy();
						bean.ivCacheKey = null;
						removed = true;
					}
				}
			}

			if (removed) {
				lockStrategy.unlock(this.activator.container, id, tx);
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atPostInvoke");
			}

		}
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit", new Object[]{tx, bean});
		}

		BeanId id = bean.getId();
		boolean var8 = false;

		try {
			var8 = true;
			super.atCommit(tx, bean);
			var8 = false;
		} finally {
			if (var8) {
				LockStrategy var6 = ((EJSHome) id.getHome()).getLockStrategy();
				var6.unlock(this.activator.container, id, tx);
			}
		}

		LockStrategy lockStrategy = ((EJSHome) id.getHome()).getLockStrategy();
		lockStrategy.unlock(this.activator.container, id, tx);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCommit");
		}

	}

	void atRollback(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRollback", new Object[]{tx, bean});
		}

		BeanId id = bean.getId();
		boolean var11 = false;

		try {
			var11 = true;
			Object key = bean.ivCacheKey;
			synchronized (this.locks.getLock(key)) {
				bean = (BeanO) this.cache.find(key);
				if (bean != null) {
					this.cache.unpin(key);
					((BeanO) this.cache.remove(key, true)).destroy();
					bean.ivCacheKey = null;
				}

				var11 = false;
			}
		} finally {
			if (var11) {
				LockStrategy var8 = ((EJSHome) id.getHome()).getLockStrategy();
				var8.unlock(this.activator.container, id, tx);
			}
		}

		LockStrategy lockStrategy = ((EJSHome) id.getHome()).getLockStrategy();
		lockStrategy.unlock(this.activator.container, id, tx);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRollback");
		}

	}

	void atDiscard(BeanO bean) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atDiscard", bean);
		}

		try {
			bean.ivCacheKey = null;
			bean.passivate();
		} catch (RemoteException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.activator.OptAEntityActivationStrategy.atDiscard",
					"423", this);
			Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{bean, this, var3});
			throw var3;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atDiscard");
		}

	}

	boolean atLock(ContainerTx tx, BeanId id) throws RemoteException {
		LockStrategy lockStrategy = ((EJSHome) id.getHome()).getLockStrategy();
		return lockStrategy.lock(this.activator.container, tx, id, 1);
	}

	void atUninstall(BeanId id, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atUninstall (" + bean + ")");
		}

		Object key = bean.ivCacheKey;
		if (key == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUninstall: bean already removed");
			}

		} else {
			synchronized (this.locks.getLock(key)) {
				try {
					bean = (BeanO) this.cache.remove(key, false);
					bean.ivCacheKey = null;
					bean.destroy();
				} catch (IllegalOperationException var7) {
					FFDCFilter.processException(var7,
							"com.ibm.ejs.container.activator.OptAEntityActivationStrategy.atUninstall", "457", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Unable to remove uninstalled bean instance", var7);
					}
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUninstall");
			}

		}
	}
}