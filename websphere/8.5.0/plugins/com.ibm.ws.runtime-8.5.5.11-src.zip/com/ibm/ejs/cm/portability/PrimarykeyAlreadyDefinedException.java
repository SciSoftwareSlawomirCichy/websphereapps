package com.ibm.ejs.cm.portability;

import java.sql.SQLException;

public final class PrimarykeyAlreadyDefinedException extends PortableSQLException {
	private static final long serialVersionUID = 1181495517716834966L;

	PrimarykeyAlreadyDefinedException(SQLException nativeException) {
		super(nativeException);
	}

	PrimarykeyAlreadyDefinedException() {
	}
}