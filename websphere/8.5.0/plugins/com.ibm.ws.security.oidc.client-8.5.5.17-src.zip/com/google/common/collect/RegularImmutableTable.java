package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.RegularImmutableTable.1;
import com.google.common.collect.RegularImmutableTable.CellSet;
import com.google.common.collect.RegularImmutableTable.Values;
import com.google.common.collect.Table.Cell;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class RegularImmutableTable<R, C, V> extends ImmutableTable<R, C, V> {
	abstract Cell<R, C, V> getCell(int var1);

	final ImmutableSet<Cell<R, C, V>> createCellSet() {
      return (ImmutableSet)(this.isEmpty() ? ImmutableSet.of() : new CellSet(this, (1)null));
   }

	abstract V getValue(int var1);

	final ImmutableCollection<V> createValues() {
      return (ImmutableCollection)(this.isEmpty() ? ImmutableList.of() : new Values(this, (1)null));
   }

	static <R, C, V> RegularImmutableTable<R, C, V> forCells(List<Cell<R, C, V>> cells, @NullableDecl Comparator<? super R> rowComparator, @NullableDecl Comparator<? super C> columnComparator) {
      Preconditions.checkNotNull(cells);
      if (rowComparator != null || columnComparator != null) {
         Comparator<Cell<R, C, V>> comparator = new 1(rowComparator, columnComparator);
         Collections.sort(cells, comparator);
      }

      return forCellsInternal(cells, rowComparator, columnComparator);
   }

	static <R, C, V> RegularImmutableTable<R, C, V> forCells(Iterable<Cell<R, C, V>> cells) {
		return forCellsInternal(cells, (Comparator) null, (Comparator) null);
	}

	private static <R, C, V> RegularImmutableTable<R, C, V> forCellsInternal(Iterable<Cell<R, C, V>> cells,
			@NullableDecl Comparator<? super R> rowComparator, @NullableDecl Comparator<? super C> columnComparator) {
		Set<R> rowSpaceBuilder = new LinkedHashSet();
		Set<C> columnSpaceBuilder = new LinkedHashSet();
		ImmutableList<Cell<R, C, V>> cellList = ImmutableList.copyOf(cells);
		Iterator var6 = cells.iterator();

		while (var6.hasNext()) {
			Cell<R, C, V> cell = (Cell) var6.next();
			rowSpaceBuilder.add(cell.getRowKey());
			columnSpaceBuilder.add(cell.getColumnKey());
		}

		ImmutableSet<R> rowSpace = rowComparator == null
				? ImmutableSet.copyOf(rowSpaceBuilder)
				: ImmutableSet.copyOf(ImmutableList.sortedCopyOf(rowComparator, rowSpaceBuilder));
		ImmutableSet<C> columnSpace = columnComparator == null
				? ImmutableSet.copyOf(columnSpaceBuilder)
				: ImmutableSet.copyOf(ImmutableList.sortedCopyOf(columnComparator, columnSpaceBuilder));
		return forOrderedComponents(cellList, rowSpace, columnSpace);
	}

	static <R, C, V> RegularImmutableTable<R, C, V> forOrderedComponents(ImmutableList<Cell<R, C, V>> cellList,
			ImmutableSet<R> rowSpace, ImmutableSet<C> columnSpace) {
		return (RegularImmutableTable) ((long) cellList.size() > (long) rowSpace.size() * (long) columnSpace.size() / 2L
				? new DenseImmutableTable(cellList, rowSpace, columnSpace)
				: new SparseImmutableTable(cellList, rowSpace, columnSpace));
	}
}