package com.ibm.ejs.oa;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;

public class EJSORBFactory implements ObjectFactory {
	private static final TraceComponent tc = Tr.register(EJSORBFactory.class, "ObjectAdapter",
			"com.ibm.ws.runtime.runtime");

	public EJSORBFactory() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable env) throws Exception {
		String thisMethod = "getObjectInstance(Object, Name, Context, Hashtable)";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, thisMethod);
		}

		Object retObj = null;
		if (!(obj instanceof Reference)) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, thisMethod, obj + " is not a Reference");
			}

			return null;
		} else {
			Reference ref = (Reference) obj;
			if (!ref.getFactoryClassName().equals(this.getClass().getName())) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, thisMethod, "this is not the right factory for this Reference: " + obj);
				}

				return null;
			} else {
				retObj = EJSORB.getORBInstance();
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, thisMethod, "retObj = " + retObj);
				}

				return retObj;
			}
		}
	}
}