package com.ibm.ejs.container.finder;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Vector;

public interface FinderResultServer extends Remote {
	Vector getNextWrapperCollection(int var1, int var2) throws RemoteException;

	int size() throws RemoteException;
}