package com.ibm.ws.wim.dao.schema;

public interface DBPropertyConstants {
	String PRE_FIX = "wimprop:";
	String REPOSITORY_PROPERTY = "repositoryProperty";
	String REPOSITORY_NAME = "repositoryName";
	String WIM_DB = "wimDB";
	String WIM_LA = "wimLA";
	String PROPERTY = "property";
	String WIM_PROPERTY_NAME = "wimPropertyName";
	String DATA_TYPE = "dataType";
	String VALUE_LENGTH = "valueLength";
	String METADATA_NAME = "metadataName";
	String MULTI_VALUED = "multiValued";
	String READ_ONLY = "readOnly";
	String CLASSNAME = "classname";
	String CASE_EXACT_MATCH = "caseExactMatch";
	String DESCRIPTION = "description";
	String APPLICATION_ID = "applicationId";
	String APPLICABLE_ENTITY_NAME = "applicableEntityName";
	String REQUIRED_ENTITY_NAME = "requiredEntityName";
	String ENTITY_NAME = "entityName";
	String COMPOSITE_PROPERTY = "compositeProperty";
	String COMPONENT_PROPERTY = "componentProperty";
	String COMPONENT_COMPOSITE_PROPERTY = "componentCompositeProperty";
	String REQUIRED_IN_COMPOSITE = "requiredInComposite";
	String KEY_IN_COMPOSITE = "keyInComposite";
	String META_NAME_DEFAULT_VALUE = "DEFAULT";
	String APPLICATION_ID_DEFAULT_VALUE = "com.ibm.websphere.wim";
	String DATA_TYPE_NAME_IDENTIFIER = "IDENTIFIER";
	String DATA_TYPE_NAME_OBJECT = "OBJECT";
	String DATA_TYPE_NAME_STRING = "STRING";
	String DATA_TYPE_NAME_LONG = "LONG";
	String DATA_TYPE_NAME_INTEGER = "INTEGER";
	String DATA_TYPE_NAME_DOUBLE = "DOUBLE";
	String DATA_TYPE_NAME_TIMESTAMP = "TIMESTAMP";
	String DATA_TYPE_NAME_BYTEARRAY = "BYTEARRAY";
}