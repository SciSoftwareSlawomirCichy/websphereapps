package com.ibm.ejs.util;

public abstract class LRUCacheElement extends QueueElement {
	protected Object key;
}