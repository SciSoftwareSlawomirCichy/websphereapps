package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableBiMap.Builder;
import com.google.common.collect.ImmutableBiMap.SerializedForm;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;

@GwtCompatible(serializable = true, emulated = true)
public abstract class ImmutableBiMap<K, V> extends ImmutableMap<K, V> implements BiMap<K, V> {
	public static <K, V> ImmutableBiMap<K, V> of() {
		return EmptyImmutableBiMap.INSTANCE;
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1) {
		Preconditions.checkNotNull(k1, "null key in entry: null=%s", new Object[]{v1});
		Preconditions.checkNotNull(v1, "null value in entry: %s=null", new Object[]{k1});
		return new SingletonImmutableBiMap(k1, v1);
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2) {
		return (new Builder()).put(k1, v1).put(k2, v2).build();
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		return (new Builder()).put(k1, v1).put(k2, v2).put(k3, v3).build();
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
		return (new Builder()).put(k1, v1).put(k2, v2).put(k3, v3).put(k4, v4).build();
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
		return (new Builder()).put(k1, v1).put(k2, v2).put(k3, v3).put(k4, v4).put(k5, v5).build();
	}

	public static <K, V> Builder<K, V> builder() {
		return new Builder();
	}

	public static <K, V> ImmutableBiMap<K, V> copyOf(Map<? extends K, ? extends V> map) {
		if (map instanceof ImmutableBiMap) {
			ImmutableBiMap<K, V> bimap = (ImmutableBiMap) map;
			if (!bimap.isPartialView()) {
				return bimap;
			}
		}

		return fromEntries(ImmutableList.copyOf(map.entrySet()));
	}

	static <K, V> ImmutableBiMap<K, V> fromEntries(Collection<? extends Entry<? extends K, ? extends V>> entries) {
		switch (entries.size()) {
			case 0 :
				return of();
			case 1 :
				Entry<? extends K, ? extends V> entry = (Entry) Iterables.getOnlyElement(entries);
				return new SingletonImmutableBiMap(entry.getKey(), entry.getValue());
			default :
				return new RegularImmutableBiMap(entries);
		}
	}

	public abstract ImmutableBiMap<V, K> inverse();

	public ImmutableSet<V> values() {
		return this.inverse().keySet();
	}

	@Deprecated
	public V forcePut(K key, V value) {
		throw new UnsupportedOperationException();
	}

	Object writeReplace() {
		return new SerializedForm(this);
	}
}