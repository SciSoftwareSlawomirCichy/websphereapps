package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.DescendingMultiset.1;
import com.google.common.collect.Multiset.Entry;
import com.google.common.collect.SortedMultisets.NavigableElementSet;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NavigableSet;
import java.util.Set;

@GwtCompatible(emulated = true)
abstract class DescendingMultiset<E> extends ForwardingMultiset<E> implements SortedMultiset<E> {
	private transient Comparator<? super E> comparator;
	private transient NavigableSet<E> elementSet;
	private transient Set<Entry<E>> entrySet;

	abstract SortedMultiset<E> forwardMultiset();

	public Comparator<? super E> comparator() {
		Comparator<? super E> result = this.comparator;
		return result == null
				? (this.comparator = Ordering.from(this.forwardMultiset().comparator()).reverse())
				: result;
	}

	public NavigableSet<E> elementSet() {
		NavigableSet<E> result = this.elementSet;
		return result == null ? (this.elementSet = new NavigableElementSet(this)) : result;
	}

	public Entry<E> pollFirstEntry() {
		return this.forwardMultiset().pollLastEntry();
	}

	public Entry<E> pollLastEntry() {
		return this.forwardMultiset().pollFirstEntry();
	}

	public SortedMultiset<E> headMultiset(E toElement, BoundType boundType) {
		return this.forwardMultiset().tailMultiset(toElement, boundType).descendingMultiset();
	}

	public SortedMultiset<E> subMultiset(E fromElement, BoundType fromBoundType, E toElement, BoundType toBoundType) {
		return this.forwardMultiset().subMultiset(toElement, toBoundType, fromElement, fromBoundType)
				.descendingMultiset();
	}

	public SortedMultiset<E> tailMultiset(E fromElement, BoundType boundType) {
		return this.forwardMultiset().headMultiset(fromElement, boundType).descendingMultiset();
	}

	protected Multiset<E> delegate() {
		return this.forwardMultiset();
	}

	public SortedMultiset<E> descendingMultiset() {
		return this.forwardMultiset();
	}

	public Entry<E> firstEntry() {
		return this.forwardMultiset().lastEntry();
	}

	public Entry<E> lastEntry() {
		return this.forwardMultiset().firstEntry();
	}

	abstract Iterator<Entry<E>> entryIterator();

	public Set<Entry<E>> entrySet() {
		Set<Entry<E>> result = this.entrySet;
		return result == null ? (this.entrySet = this.createEntrySet()) : result;
	}

	Set<Entry<E>> createEntrySet() {
      return new 1(this);
   }

	public Iterator<E> iterator() {
		return Multisets.iteratorImpl(this);
	}

	public Object[] toArray() {
		return this.standardToArray();
	}

	public <T> T[] toArray(T[] array) {
		return this.standardToArray(array);
	}

	public String toString() {
		return this.entrySet().toString();
	}
}