@CheckReturnValue
@ParametersAreNonnullByDefault
package com.google.common.eventbus;

import com.google.errorprone.annotations.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;