package com.ibm.ws.wim.xpath.lookaside.util;

import com.ibm.websphere.wim.exception.InvalidPropertyValueException;
import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.DataAccessObject;
import com.ibm.ws.wim.dao.schema.DBRepositoryProperty;
import com.ibm.ws.wim.lookaside.LAPropertyCache;
import com.ibm.ws.wim.util.SearchParameter;
import com.ibm.ws.wim.xpath.mapping.datatype.LogicalNode;
import com.ibm.ws.wim.xpath.mapping.datatype.ParenthesisNode;
import com.ibm.ws.wim.xpath.mapping.datatype.PropertyNode;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;
import com.ibm.ws.wim.xpath.util.XPathTranslateHelper;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Stack;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LAXPathTranslateHelper implements XPathTranslateHelper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public static final String CLASSNAME = LAXPathTranslateHelper.class.getName();
	private static final Logger trcLogger;
	public int numSearchProperties = 0;
	private LAPropertyCache propertyMgr = null;
	private DataAccessObject dao = null;
	public StringBuffer whereClause = null;
	public StringBuffer fromClause = null;
	HashSet incrementTypes = new HashSet();
	HashSet incrementExcludeTypes = new HashSet();
	Stack logOps = new Stack();
	short stringCount = 1;
	short integerCount = 1;
	short longCount = 1;
	short doubleCount = 1;
	short timestampCount = 1;
	short entityRefCount = 1;
	boolean needTopRightParenthesis = false;
	List parameters = null;

	public LAXPathTranslateHelper(List var1, XPathNode var2, List var3, LAPropertyCache var4, DataAccessObject var5) {
		HashMap var6 = new HashMap();
		this.numSearchProperties = var6.size();
		this.propertyMgr = var4;
		this.dao = var5;
		this.parameters = var3;
		this.whereClause = new StringBuffer(this.numSearchProperties * 128);
		this.fromClause = new StringBuffer((this.numSearchProperties + 1) * 16);
		this.fromClause.append(var5.getQuerySet().searchFromLAEntity);
		this.whereClause.append(var5.getQuerySet().searchWhere1Equals1);
		if (var2 != null) {
			this.whereClause.append(var5.getQuerySet().AND);
		}

	}

	public void genSearchString(StringBuffer var1, XPathNode var2) throws WIMApplicationException {
		if (var2 != null) {
			switch (var2.getNodeType()) {
				case 0 :
					this.whereClause.append('(');
					this.needTopRightParenthesis = true;
					this.genSearchString(var1, (PropertyNode) var2);
					break;
				case 1 :
					this.whereClause.append('(');
					this.needTopRightParenthesis = true;
					this.genSearchString(var1, (LogicalNode) var2);
					break;
				case 2 :
					this.genSearchString(var1, (ParenthesisNode) var2);
			}

			if (this.needTopRightParenthesis) {
				this.whereClause.append(')');
			}

		}
	}

	public StringBuffer getFromClause() {
		return this.fromClause;
	}

	public StringBuffer getWhereClause() {
		return this.whereClause;
	}

	private void genSearchString(StringBuffer var1, PropertyNode var2) throws WIMApplicationException {
		String var4 = var2.getName();
		DBRepositoryProperty var5 = this.propertyMgr.getPropertyDefinition(var4);
		if (var5 == null) {
			throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED", WIMMessageHelper.generateMsgParms(var4),
					CLASSNAME, "genSearchString(StringBuffer searchExpBuffer,PropertyNode propNode)");
		} else if (var5.isComposite()) {
			throw new SearchControlException("SEARCH_BY_COMPOSITE_PROPERTY_NOT_SUPPORTED",
					WIMMessageHelper.generateMsgParms(var4), CLASSNAME,
					"genSearchString(StringBuffer searchExpBuffer,PropertyNode propNode)");
		} else {
			StringBuffer var6 = new StringBuffer();
			StringBuffer var7 = new StringBuffer();
			this.appendFromClause(var5, var6, var7);
			this.appendWhereClause(var2, var5, var6, var7);
			if (!this.logOps.isEmpty() && this.logOps.contains("and")) {
				this.incrementTypes.add(var5.getDataType());
				if (this.logOps.contains("or")) {
					this.incrementExcludeTypes.add(var5.getDataType());
				}
			}

		}
	}

	private void genSearchString(StringBuffer var1, ParenthesisNode var2) throws WIMApplicationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "genSearchString(StringBuffer, ParenthesisNode)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2}));
		}

		XPathNode var4 = (XPathNode) var2.getChild();
		this.whereClause.append(this.dao.getQuerySet().LEFT_BRACKET);
		this.genStringChild(var1, var4);
		this.whereClause.append(this.dao.getQuerySet().RIGHT_BRACKET);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "genSearchString(StringBuffer, ParenthesisNode)");
		}

	}

	private void genSearchString(StringBuffer var1, LogicalNode var2) throws WIMApplicationException {
		boolean var3 = false;
		boolean var4 = false;
		HashSet var5 = null;
		this.logOps.push(var2.getOperator());
		this.genStringChild(var1, (XPathNode) var2.getLeftChild());
		if (var2.getOperator().equals("and")) {
			var4 = true;
			this.whereClause.append(this.dao.getQuerySet().AND);
		} else {
			this.whereClause.append(this.dao.getQuerySet().OR);
			if (!this.incrementExcludeTypes.isEmpty()) {
				var5 = (HashSet) this.incrementTypes.clone();
				this.incrementTypes.removeAll(this.incrementExcludeTypes);
			}
		}

		this.genStringChild(var1, (XPathNode) var2.getRightChild());
		this.logOps.pop();
		if (var4) {
			if (!this.logOps.isEmpty() && !this.logOps.contains("and")) {
				this.incrementTypes.clear();
				this.incrementExcludeTypes.clear();
				this.resetTypeCounts();
			}
		} else {
			if (!this.logOps.isEmpty() && ((String) this.logOps.peek()).equals("and")) {
				this.incrementExcludeTypes.clear();
			}

			if (var5 != null) {
				this.incrementTypes = var5;
				var5 = null;
			}
		}

	}

	private void genStringChild(StringBuffer var1, XPathNode var2) throws WIMApplicationException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "genStringChild(StringBuffer, XPathNode)",
					WIMTraceHelper.printObjectArray(new Object[]{var1, var2}));
		}

		switch (var2.getNodeType()) {
			case 0 :
				this.genSearchString(var1, (PropertyNode) var2);
				break;
			case 1 :
				this.genSearchString(var1, (LogicalNode) var2);
				break;
			case 2 :
				this.genSearchString(var1, (ParenthesisNode) var2);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "genStringChild(StringBuffer, XPathNode)");
		}

	}

	private void appendFromClause(DBRepositoryProperty var1, StringBuffer var2, StringBuffer var3)
			throws WIMApplicationException {
		boolean var5 = false;
		if (!this.incrementTypes.isEmpty() && this.incrementTypes.contains(var1.getDataType())) {
			var5 = true;
		}

		String var6 = var1.getDataType();
		short var7 = DAOHelper.getDataTypeId(var6);
		switch (var7) {
			case 0 :
				if (var5) {
					++this.stringCount;
				}

				var2.append("S" + this.stringCount);
				if (var1.isCaseSensitive()) {
					var3.append(var2 + this.dao.getQuerySet().dotColumnValue);
				} else {
					var3.append(var2 + this.dao.getQuerySet().dotColumnValueKey);
				}

				if (this.fromClause.toString().indexOf(" " + var2) == -1) {
					this.fromClause.append(this.dao.getQuerySet().COMMA);
					this.fromClause.append(this.dao.getQuerySet().laTableStringValue);
					this.fromClause.append(var2);
				}
				break;
			case 1 :
				if (var5) {
					++this.longCount;
				}

				var2.append("L" + this.longCount);
				var3.append(var2 + this.dao.getQuerySet().dotColumnValue);
				if (this.fromClause.toString().indexOf(" " + var2) == -1) {
					this.fromClause.append(this.dao.getQuerySet().COMMA);
					this.fromClause.append(this.dao.getQuerySet().laTableLongValue);
					this.fromClause.append(var2);
				}
				break;
			case 2 :
				if (var5) {
					++this.doubleCount;
				}

				var2.append("D" + this.doubleCount);
				var3.append(var2 + this.dao.getQuerySet().dotColumnValue);
				if (this.fromClause.toString().indexOf(" " + var2) == -1) {
					this.fromClause.append(this.dao.getQuerySet().COMMA);
					this.fromClause.append(this.dao.getQuerySet().laTableDoubleValue);
					this.fromClause.append(var2);
				}
				break;
			case 3 :
				if (var5) {
					++this.integerCount;
				}

				var2.append("I" + this.integerCount);
				var3.append(var2 + this.dao.getQuerySet().dotColumnValue);
				if (this.fromClause.toString().indexOf(" " + var2) == -1) {
					this.fromClause.append(this.dao.getQuerySet().COMMA);
					this.fromClause.append(this.dao.getQuerySet().laTableIntegerValue);
					this.fromClause.append(var2);
				}
				break;
			case 4 :
				if (var5) {
					++this.timestampCount;
				}

				var2.append("T" + this.timestampCount);
				var3.append(var2 + this.dao.getQuerySet().dotColumnValue);
				if (this.fromClause.toString().indexOf(" " + var2) == -1) {
					this.fromClause.append(this.dao.getQuerySet().COMMA);
					this.fromClause.append(this.dao.getQuerySet().laTableTimeStampValue);
					this.fromClause.append(var2);
				}
				break;
			case 5 :
				if (var5) {
					++this.entityRefCount;
				}

				var2.append("R" + this.entityRefCount);
				var3.append(var2 + this.dao.getQuerySet().dotColumnRefUnameKey);
				if (this.fromClause.toString().indexOf(" " + var2) == -1) {
					this.fromClause.append(this.dao.getQuerySet().COMMA);
					this.fromClause.append(this.dao.getQuerySet().laTableReferenceValue);
					this.fromClause.append(var2);
				}
				break;
			case 6 :
				throw new SearchControlException("SEARCH_BY_LOB_PROPERTY_NOT_SUPPORTED",
						WIMMessageHelper.generateMsgParms(var1.getName()), CLASSNAME,
						"appendFromClause(DBRepositoryProperty, StringBuffer, StringBuffer)");
			default :
				throw new SearchControlException("PROPERTY_INVALID_DATA_TYPE",
						WIMMessageHelper.generateMsgParms(var1.getName()), CLASSNAME,
						"appendFromClause(DBRepositoryProperty, StringBuffer, StringBuffer)");
		}

	}

	private void appendWhereClause(PropertyNode var1, DBRepositoryProperty var2, StringBuffer var3, StringBuffer var4)
			throws WIMApplicationException {
		String var6 = var2.getDataType();
		short var7 = DAOHelper.getDataTypeId(var6);
		Integer var8 = var2.getPropId();
		String var9 = var1.getOperator();
		this.whereClause.append(var3);
		this.whereClause.append(this.dao.getQuerySet().searchLAEntityJoinCondition);
		this.whereClause.append(var3);
		this.whereClause.append(this.dao.getQuerySet().searchPropertyIdCondition);
		SearchParameter var10 = new SearchParameter((short) 3, var8);
		if (this.parameters == null) {
			this.parameters = new ArrayList();
		}

		this.parameters.add(var10);
		this.whereClause.append(this.dao.getQuerySet().LEFT_BRACKET);
		this.whereClause.append(var4 + " ");
		Object var11 = var1.getValue();
		Object var12 = null;
		if (var9.equals("=") && var11 instanceof String) {
			int var13 = ((String) var11).indexOf("\\*");
			if (var13 < 0) {
				if (((String) var11).indexOf(42) >= 0) {
					var9 = "LIKE";
					var11 = ((String) var11).replace('*', '%');
				}
			} else {
				StringBuffer var14 = new StringBuffer((String) var11);
				var13 = 0;
				boolean var15 = true;
				int var16 = 0;

				while (true) {
					while (var16 < var14.length()) {
						int var17 = var14.indexOf("*", var13);
						var13 = var14.indexOf("\\*", var13);
						if (var13 < 0 && var15) {
							var16 = var14.length();
						} else {
							if (var17 != var13 + 1 && var17 > 0) {
								var9 = "LIKE";
								if (var13 < 0) {
									var13 = var14.length();
								}

								String var18 = var14.substring(var17, var13);
								var18 = var18.replace('*', '%');
								var14.replace(var17, var13, var18);
							}

							if (var13 >= 0 && var13 < var14.length()) {
								var14.deleteCharAt(var13);
							}

							++var13;
							var16 = var13;
							var15 = false;
						}
					}

					var11 = var14.toString();
					break;
				}
			}
		}

		String var22;
		if (var11 != null) {
			try {
				switch (var7) {
					case 0 :
						var12 = var11;
						break;
					case 1 :
						var12 = new Long(var11.toString());
						break;
					case 2 :
						var12 = new Double(var11.toString());
						break;
					case 3 :
						var12 = new Integer(var11.toString());
						break;
					case 4 :
						var22 = var11.toString();
						SimpleDateFormat var21 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
						var21.setTimeZone(TimeZone.getTimeZone("GMT"));
						Date var23 = var21.parse(var22);
						var12 = new Timestamp(var23.getTime());
						break;
					case 5 :
						var12 = DAOHelper.getTruncatedUniqueName(var11.toString().trim());
				}
			} catch (NumberFormatException var19) {
				throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
						WIMMessageHelper.generateMsgParms(var2.getName()), CLASSNAME,
						"appendWhereClause(PropertyNode propNode, DBRepositoryProperty propDef, StringBuffer tableName, StringBuffer columnName)",
						var19);
			} catch (ParseException var20) {
				throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE_FORMAT",
						WIMMessageHelper.generateMsgParms(var2.getName()), CLASSNAME,
						"appendWhereClause(PropertyNode propNode, DBRepositoryProperty propDef, StringBuffer tableName, StringBuffer columnName)",
						var20);
			}
		}

		var9 = this.dao.getOperator(var9, var7);
		this.whereClause.append(var9 + " ");
		this.whereClause.append("?");
		this.whereClause.append(this.dao.getQuerySet().RIGHT_BRACKET);
		var10 = new SearchParameter(var7, var8, var12);
		if (!var2.isCaseSensitive()) {
			var22 = (String) var10.paramValue;
			if (var22 != null) {
				var10.paramValue = var22.toLowerCase();
			}
		}

		this.parameters.add(var10);
	}

	private void resetTypeCounts() {
		this.stringCount = 1;
		this.integerCount = 1;
		this.longCount = 1;
		this.doubleCount = 1;
		this.timestampCount = 1;
		this.entityRefCount = 1;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}