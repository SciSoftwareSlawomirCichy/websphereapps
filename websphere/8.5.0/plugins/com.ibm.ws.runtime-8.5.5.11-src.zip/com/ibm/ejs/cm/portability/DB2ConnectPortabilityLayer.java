package com.ibm.ejs.cm.portability;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.sql.Statement;

class DB2ConnectPortabilityLayer extends DB2PortabilityLayer {
	private static DB2ConnectPortabilityLayer instance;
	private int is390 = 0;
	private static final String RRString = " WITH RR KEEP UPDATE LOCKS";
	private static final String RSString = " WITH RS KEEP UPDATE LOCKS";
	private static final TraceComponent tc = Tr.register(DB2ConnectPortabilityLayer.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	protected DB2ConnectPortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.typeMap.setElementAt(" VARCHAR(255) NOT NULL ", 3);
		this.typeMap.setElementAt(" VARCHAR(255) ", 4);
		this.typeMap.setElementAt(" VARCHAR(255) NOT NULL ", 11);
		this.typeMap.setElementAt(" VARCHAR(255) ", 12);
		this.typeMap.setElementAt(" LONG VARCHAR FOR BIT DATA ", 10);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	protected void setIs390(int value) {
		this.is390 = value;
	}

	public void createTable(Connection connection, String schema, String name, String sql) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTable", new Object[]{connection, schema, name, sql});
		}

		boolean autocommit = connection.getAutoCommit();
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "autocommit: " + autocommit);
		}

		if (autocommit) {
			connection.setAutoCommit(false);
		}

		Statement statement = null;

		try {
			String newsql;
			String idxstr;
			if (sql.indexOf("BLOB") != -1) {
				newsql = sql.toUpperCase();
				int idx = newsql.indexOf("PRIMARY KEY");
				idxstr = name;
				if (name.length() > 12) {
					idxstr = name.substring(0, 12);
				}

				String rowid = " " + idxstr + "_rowid ROWID GENERATED ALWAYS, ";
				if (idx == -1) {
					throw new SQLException("not a valid sql create table string, needs primary key field.");
				}

				newsql = newsql.substring(0, idx) + rowid + newsql.substring(idx);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "new sql createtable string:", newsql);
				}

				try {
					statement = connection.createStatement();
					statement.executeUpdate(newsql);
				} catch (SQLException var29) {
					if (tc.isEventEnabled() && var29.getErrorCode() == -601) {
						Tr.event(tc, "table already exists", newsql);
					}

					throw var29;
				}

				String primarykey = this.getPrimaryKey(sql);
				String scm;
				if (primarykey != null) {
					scm = name;
					if (name.length() > 14) {
						scm = name.substring(0, 14);
					}

					String idxstr = "create unique index " + scm + "_idx" + " on " + name + " (" + primarykey + ")";
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "create idx: ", idxstr);
					}

					try {
						statement = connection.createStatement();
						statement.executeUpdate(idxstr);
					} catch (SQLException var28) {
						if (var28.getErrorCode() == -601) {
							if (tc.isEventEnabled()) {
								Tr.event(tc, "idx already exists", idxstr);
							}

							throw new SQLException("idx already exists: " + idxstr);
						}

						throw var28;
					}
				}

				scm = null;
				if (schema.endsWith(".")) {
					scm = schema.substring(0, schema.length() - 1);
				} else {
					scm = schema;
				}

				boolean more = idx != -1;
				String s = sql;

				for (int count = 0; more; ++count) {
					s = this.createAuxTable(connection, s, name, scm, count);
					more = s.indexOf("BLOB") != -1;
				}
			} else {
				try {
					statement = connection.createStatement();
					statement.executeUpdate(sql);
				} catch (SQLException var27) {
					if (var27.getErrorCode() == -601 && tc.isEventEnabled()) {
						Tr.event(tc, "table already exists", sql);
					}

					throw var27;
				}

				newsql = this.getPrimaryKey(sql);
				if (newsql != null) {
					String nameidx = name;
					if (name.length() > 14) {
						nameidx = name.substring(0, 14);
					}

					idxstr = "create unique index " + nameidx + "_idx" + " on " + name + " (" + newsql + ")";
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "create idx: ", idxstr);
					}

					try {
						statement = connection.createStatement();
						statement.executeUpdate(idxstr);
					} catch (SQLException var26) {
						if (var26.getErrorCode() == -601) {
							if (tc.isEventEnabled()) {
								Tr.event(tc, "idx already exists", idxstr);
							}

							throw new SQLException("idx already exists: " + idxstr);
						}

						throw var26;
					}
				}
			}
		} catch (SQLException var31) {
			if (var31.getErrorCode() == -601) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "name already exists; rollback connection");
				}

				try {
					connection.rollback();
				} catch (SQLException var25) {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "Error rolling back connection", var25);
					}
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "createTable", var31);
			}

			throw this.translateException(var31);
		} finally {
			if (statement != null) {
				statement.close();
			}

		}

		try {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "commit connection");
			}

			connection.commit();
		} catch (SQLException var30) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Error commit connection", var30);
			}

			throw var30;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTable");
		}

	}

	private String getPrimaryKey(String s) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPrimaryKey");
		}

		String sql = s.toUpperCase();
		String primarykey = null;
		int idx = sql.indexOf("PRIMARY KEY");
		if (idx != -1) {
			String substr = sql.substring(idx);
			int idx2 = substr.indexOf("(");
			int idx3 = substr.indexOf(")");
			primarykey = substr.substring(idx2 + 1, idx3);
			primarykey = primarykey.trim();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getPrimaryKey: ", primarykey);
		}

		return primarykey;
	}

	private String createAuxTable(Connection con, String sql, String name, String schema, int count)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createAuxTable: ", sql);
		}

		if (count > 9) {
			throw new SQLException("can not handle more than 10 BLOB datatype fields in a table.");
		} else {
			String ltsname = name.substring(0, 7);
			char c = Integer.toString(count).charAt(0);
			ltsname = ltsname + count;
			if (ltsname.indexOf("_") != -1) {
				ltsname = ltsname.replace('_', c);
			}

			String s = new String("CREATE LOB TABLESPACE ");
			s = s + ltsname;
			int idx = sql.indexOf("BLOB");
			String substr = sql.substring(0, idx);
			sql.substring(idx);
			String substr3 = sql.substring(idx + 4);
			int idx2 = substr.lastIndexOf(",");
			int idx3 = substr.indexOf("(");
			int idx4 = idx2 > idx3 ? idx2 : idx3;
			String colname = null;
			String auxtbl = null;
			if (idx4 == -1) {
				throw new SQLException("create aux table fails", sql);
			} else {
				colname = sql.substring(idx2 + 1, idx);
				colname = colname.trim();
				String auxtblname = ltsname + "_" + colname;
				if (auxtblname.length() > 18) {
					auxtblname = auxtblname.substring(0, 18);
				}

				auxtbl = "create aux table " + auxtblname + " in " + ltsname + " stores " + name + " column " + colname;
				Statement statement = null;
				Object target = null;

				try {
					statement = con.createStatement();
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "create lob table space: ", s);
					}

					statement.executeUpdate(s);
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "create aux table: ", auxtbl);
					}

					statement.executeUpdate(auxtbl);
					String auxtblidx = auxtblname;
					if (auxtblname.length() > 14) {
						auxtblidx = auxtblname.substring(0, 14);
					}

					String idxstr = "create unique index " + auxtblidx + "_idx" + " on " + auxtblname;
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "create idx: ", idxstr);
					}

					statement.executeUpdate(idxstr);
				} catch (SQLException var26) {
					if (var26.getErrorCode() == -601) {
						if (tc.isEventEnabled()) {
							Tr.event(tc, "object already exists: ", target);
						}

						throw new SQLException("object already exists: " + target);
					}

					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "createAuxTable", var26);
					}

					throw var26;
				} finally {
					if (statement != null) {
						statement.close();
					}

				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "createAuxTable", substr3);
				}

				return substr3;
			}
		}
	}

	public void createTableForPersister(Connection connection, String schema, String name, String sql)
			throws SQLException {
		this.createTable(connection, schema, name, sql);
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new DB2ConnectPortabilityLayer();
		}

		return instance;
	}

	public boolean supportsExtendedForUpdate(Connection conn) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "supportsExtendedForUpdate(Connection)");
		}

		switch (this.is390) {
			case -1 :
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "supportsExtendedForUpdate(Connection)", new Boolean(false));
				}

				return false;
			case 0 :
				String prodName;
				try {
					DatabaseMetaData dbmd = conn.getMetaData();
					prodName = dbmd.getDatabaseProductName();
				} catch (SQLException var4) {
					throw this.translateException(var4);
				}

				if (!prodName.equalsIgnoreCase("DB2") && !prodName.substring(0, 3).equalsIgnoreCase("DSN")) {
					this.is390 = -1;
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "supportsExtendedForUpdate(Connection)", new Boolean(false));
					}

					return false;
				}

				this.is390 = 1;
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "supportsExtendedForUpdate(Connection)", new Boolean(true));
				}

				return true;
			case 1 :
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "supportsExtendedForUpdate(Connection)", new Boolean(true));
				}

				return true;
			default :
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "The is390 variable is set to an incorrect value of " + this.is390);
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "supportsExtendedForUpdate(Connection)", new Boolean(false));
				}

				return false;
		}
	}

	public synchronized Object extendedForUpdateInfo(Connection conn) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "extendedForUpdateInfo(Connection)");
		}

		try {
			Integer isoLevel = new Integer(conn.getTransactionIsolation());
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "extendedForUpdateInfo(Connection)", isoLevel);
			}

			return isoLevel;
		} catch (SQLException var3) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "extendedForUpdateInfo(Connection)");
			}

			throw this.translateException(var3);
		}
	}

	public synchronized String processSQLForExtendedUpdate(String sql, int isoLevel) {
		if (isoLevel == 4) {
			return sql + " WITH RS KEEP UPDATE LOCKS";
		} else {
			return isoLevel == 8 ? sql + " WITH RR KEEP UPDATE LOCKS" : sql;
		}
	}

	public String processSQL(String sqlString, int isolevel, boolean addForUpdate, boolean addextendedforUpdateSyntax) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "processSQL - sqlString, isolevel, addForUpdate, addextendedforupdate: ",
					new Object[]{sqlString, new Integer(isolevel), new Boolean(addForUpdate),
							new Boolean(addextendedforUpdateSyntax)});
		}

		if ((addForUpdate || addextendedforUpdateSyntax) && sqlString != null) {
			StringBuffer stmt = new StringBuffer(250);
			stmt.append(sqlString);
			if (addForUpdate) {
				stmt.append(" FOR UPDATE");
			}

			if (addextendedforUpdateSyntax) {
				switch (this.is390) {
					case 0 :
						Tr.warning(tc, "MSG_CONM_7020W");
						break;
					case 1 :
						switch (isolevel) {
							case 4 :
								stmt.append(" WITH RS KEEP UPDATE LOCKS");
								break;
							case 8 :
								stmt.append(" WITH RR KEEP UPDATE LOCKS");
						}
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "processSQL - The modified sqlString is: ", stmt);
			}

			return new String(stmt);
		} else {
			return sqlString;
		}
	}
}