package com.ibm.ejs.oa;

public class Utility {
	static char[] hexChars = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

	public static String longToHexString(long v) {
		char[] c = new char[]{hexChars[(int) (v >> 60 & 15L)], hexChars[(int) (v >> 56 & 15L)],
				hexChars[(int) (v >> 52 & 15L)], hexChars[(int) (v >> 48 & 15L)], hexChars[(int) (v >> 44 & 15L)],
				hexChars[(int) (v >> 40 & 15L)], hexChars[(int) (v >> 36 & 15L)], hexChars[(int) (v >> 32 & 15L)],
				hexChars[(int) (v >> 28 & 15L)], hexChars[(int) (v >> 24 & 15L)], hexChars[(int) (v >> 20 & 15L)],
				hexChars[(int) (v >> 16 & 15L)], hexChars[(int) (v >> 12 & 15L)], hexChars[(int) (v >> 8 & 15L)],
				hexChars[(int) (v >> 4 & 15L)], hexChars[(int) (v & 15L)]};
		return new String(c, 0, 16);
	}

	public static long hexStringToLong(String a) throws Exception {
		long res = 0L;
		if (a.length() != 16) {
			throw new Exception();
		} else {
			long factor = 1L;

			for (int i = 0; i < 16; ++i) {
				char c = a.charAt(15 - i);
				if (c >= '0' && c < '9') {
					res += (long) (c - 48) * factor;
				} else {
					if (c < 'a' || c > 'f') {
						throw new Exception();
					}

					res += (long) (10 + (c - 97)) * factor;
				}

				factor <<= 4;
			}

			return res;
		}
	}

	public static int bytesToInt(byte[] array, int offset) {
		if (array.length - (offset + 4) < 0) {
			return -1;
		} else {
			int b1 = array[offset++] << 24 & -16777216;
			int b2 = array[offset++] << 16 & 16711680;
			int b3 = array[offset++] << 8 & '＀';
			int b4 = array[offset++] << 0 & 255;
			return b1 | b2 | b3 | b4;
		}
	}

	public static void intToBytes(int value, byte[] array, int offset) {
		array[offset++] = (byte) (value >>> 24 & 255);
		array[offset++] = (byte) (value >>> 16 & 255);
		array[offset++] = (byte) (value >>> 8 & 255);
		array[offset++] = (byte) (value >>> 0 & 255);
	}
}