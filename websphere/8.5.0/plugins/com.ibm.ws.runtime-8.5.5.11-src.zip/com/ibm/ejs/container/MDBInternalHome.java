package com.ibm.ejs.container;

public interface MDBInternalHome {
	void activateEndpoint() throws Exception;

	void deactivateEndpoint() throws Exception;
}