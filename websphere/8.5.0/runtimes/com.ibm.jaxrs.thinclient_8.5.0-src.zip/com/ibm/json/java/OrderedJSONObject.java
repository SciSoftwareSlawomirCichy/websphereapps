package com.ibm.json.java;

import com.ibm.json.java.internal.Parser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;

public class OrderedJSONObject extends JSONObject {
	private static final long serialVersionUID = -3269263069889337299L;
	private ArrayList order = null;

	public OrderedJSONObject() {
		this.order = new ArrayList();
	}

	public static JSONObject parse(Reader var0) throws IOException {
		BufferedReader var1 = new BufferedReader(var0);
		return (new Parser(var1)).parse(true);
	}

	public static JSONObject parse(String var0) throws IOException {
		StringReader var1 = new StringReader(var0);
		return parse((Reader) var1);
	}

	public static JSONObject parse(InputStream var0) throws IOException {
		InputStreamReader var1 = null;

		try {
			var1 = new InputStreamReader(var0, "UTF-8");
		} catch (Exception var3) {
			var1 = new InputStreamReader(var0);
		}

		return parse((Reader) var1);
	}

	public Object put(Object var1, Object var2) {
		if (null == var1) {
			throw new IllegalArgumentException("key must not be null");
		} else if (!(var1 instanceof String)) {
			throw new IllegalArgumentException("key must be a String");
		} else if (!isValidObject(var2)) {
			if (var2 != null) {
				throw new IllegalArgumentException("Invalid type of value.  Type: [" + var2.getClass().getName()
						+ "] with value: [" + var2.toString() + "]");
			} else {
				throw new IllegalArgumentException("Invalid type of value.");
			}
		} else {
			if (!this.containsKey(var1)) {
				this.order.add(var1);
			}

			return super.put(var1, var2);
		}
	}

	public Object remove(Object var1) {
		Object var2 = null;
		if (null == var1) {
			throw new IllegalArgumentException("key must not be null");
		} else {
			if (this.containsKey(var1)) {
				var2 = super.remove(var1);

				for (int var3 = 0; var3 < this.order.size(); ++var3) {
					Object var4 = this.order.get(var3);
					if (var4.equals(var1)) {
						this.order.remove(var3);
						break;
					}
				}
			}

			return var2;
		}
	}

	public void clear() {
		super.clear();
		this.order.clear();
	}

	public Object clone() {
		OrderedJSONObject var1 = (OrderedJSONObject) super.clone();
		Iterator var2 = var1.getOrder();

		for (ArrayList var3 = new ArrayList(); var2.hasNext(); var1.order = var3) {
			var3.add(var2.next());
		}

		return var1;
	}

	public Iterator getOrder() {
		return this.order.iterator();
	}
}