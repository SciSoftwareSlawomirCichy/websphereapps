package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedCollection;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedNavigableSet;
import com.google.common.collect.AbstractMapBasedMultimap.WrappedSortedSet;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.NavigableSet;
import java.util.SortedSet;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AbstractSortedSetMultimap<K, V> extends AbstractSetMultimap<K, V> implements SortedSetMultimap<K, V> {
	private static final long serialVersionUID = 430848587173315748L;

	protected AbstractSortedSetMultimap(Map<K, Collection<V>> map) {
		super(map);
	}

	abstract SortedSet<V> createCollection();

	SortedSet<V> createUnmodifiableEmptyCollection() {
		return this.unmodifiableCollectionSubclass(this.createCollection());
	}

	<E> SortedSet<E> unmodifiableCollectionSubclass(Collection<E> collection) {
		return (SortedSet) (collection instanceof NavigableSet
				? Sets.unmodifiableNavigableSet((NavigableSet) collection)
				: Collections.unmodifiableSortedSet((SortedSet) collection));
	}

	Collection<V> wrapCollection(K key, Collection<V> collection) {
		return (Collection) (collection instanceof NavigableSet
				? new WrappedNavigableSet(this, key, (NavigableSet) collection, (WrappedCollection) null)
				: new WrappedSortedSet(this, key, (SortedSet) collection, (WrappedCollection) null));
	}

	public SortedSet<V> get(@NullableDecl K key) {
		return (SortedSet) super.get(key);
	}

	@CanIgnoreReturnValue
	public SortedSet<V> removeAll(@NullableDecl Object key) {
		return (SortedSet) super.removeAll(key);
	}

	@CanIgnoreReturnValue
	public SortedSet<V> replaceValues(@NullableDecl K key, Iterable<? extends V> values) {
		return (SortedSet) super.replaceValues(key, values);
	}

	public Map<K, Collection<V>> asMap() {
		return super.asMap();
	}

	public Collection<V> values() {
		return super.values();
	}
}