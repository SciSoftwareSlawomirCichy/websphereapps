package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_ro extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Analysis Engine care utilizează baza de date: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Incident FFDC emis pe {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: Încercarea gestiunii de fişiere istoric FFDC de a şterge fişierul {0}"},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: Gestiunea fişierelor istoric FFDC a înlăturat {0} din {1} fişiere care şi-au atins vârsta maximă configurată"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: Gestiunea de fişiere istoric FFDC a eşuat să şteargă fişierul {0}"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: Gestiunea de fişiere istoric FFDC a eşuat obţinerea listei de fişiere de excepţii"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC a închis fişierul flux de incidente {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC a deschis fişierul flux de incidente {0}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: FFDC a eşuat să închidă fişierul flux de incidente {0}, excepţia găsită {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: FFDC a eşuat să deschidă sau să creeze fişierul flux de incidente {0}, excepţia găsită {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: FFDC a eşuat să scrie în fişierul flux de incidente {0}, excepţia găsită {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}