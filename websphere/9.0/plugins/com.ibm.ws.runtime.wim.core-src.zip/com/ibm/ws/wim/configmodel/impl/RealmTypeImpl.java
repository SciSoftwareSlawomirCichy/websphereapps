package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.RealmDefaultParentType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.UserRegistryInfoMappingType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class RealmTypeImpl extends EDataObjectImpl implements RealmType {
	protected EList participatingBaseEntries = null;
	protected EList defaultParents = null;
	protected UserRegistryInfoMappingType uniqueUserIdMapping = null;
	protected UserRegistryInfoMappingType userSecurityNameMapping = null;
	protected UserRegistryInfoMappingType userDisplayNameMapping = null;
	protected UserRegistryInfoMappingType uniqueGroupIdMapping = null;
	protected UserRegistryInfoMappingType groupSecurityNameMapping = null;
	protected UserRegistryInfoMappingType groupDisplayNameMapping = null;
	protected static final boolean ALLOW_OPERATION_IF_REPOS_DOWN_EDEFAULT = false;
	protected boolean allowOperationIfReposDown = false;
	protected boolean allowOperationIfReposDownESet = false;
	protected static final String DELIMITER_EDEFAULT = "@";
	protected String delimiter = "@";
	protected boolean delimiterESet = false;
	protected static final String NAME_EDEFAULT = null;
	protected String name;
	protected static final String SECURITY_USE_EDEFAULT = "active";
	protected String securityUse;
	protected boolean securityUseESet;

	protected RealmTypeImpl() {
		this.name = NAME_EDEFAULT;
		this.securityUse = "active";
		this.securityUseESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getRealmType();
	}

	public ParticipatingBaseEntriesType[] getParticipatingBaseEntriesAsArray() {
		List var1 = this.getParticipatingBaseEntries();
		return (ParticipatingBaseEntriesType[]) ((ParticipatingBaseEntriesType[]) var1
				.toArray(new ParticipatingBaseEntriesType[var1.size()]));
	}

	public List getParticipatingBaseEntries() {
		if (this.participatingBaseEntries == null) {
			this.participatingBaseEntries = new EObjectContainmentEList(ParticipatingBaseEntriesType.class, this, 0);
		}

		return this.participatingBaseEntries;
	}

	public ParticipatingBaseEntriesType createParticipatingBaseEntries() {
		ParticipatingBaseEntriesType var1 = ConfigmodelFactory.eINSTANCE.createParticipatingBaseEntriesType();
		this.getParticipatingBaseEntries().add(var1);
		return var1;
	}

	public RealmDefaultParentType[] getDefaultParentsAsArray() {
		List var1 = this.getDefaultParents();
		return (RealmDefaultParentType[]) ((RealmDefaultParentType[]) var1
				.toArray(new RealmDefaultParentType[var1.size()]));
	}

	public List getDefaultParents() {
		if (this.defaultParents == null) {
			this.defaultParents = new EObjectContainmentEList(RealmDefaultParentType.class, this, 1);
		}

		return this.defaultParents;
	}

	public RealmDefaultParentType createDefaultParents() {
		RealmDefaultParentType var1 = ConfigmodelFactory.eINSTANCE.createRealmDefaultParentType();
		this.getDefaultParents().add(var1);
		return var1;
	}

	public UserRegistryInfoMappingType getUniqueUserIdMapping() {
		return this.uniqueUserIdMapping;
	}

	public NotificationChain basicSetUniqueUserIdMapping(UserRegistryInfoMappingType var1, NotificationChain var2) {
		UserRegistryInfoMappingType var3 = this.uniqueUserIdMapping;
		this.uniqueUserIdMapping = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 2, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setUniqueUserIdMapping(UserRegistryInfoMappingType var1) {
		if (var1 != this.uniqueUserIdMapping) {
			NotificationChain var2 = null;
			if (this.uniqueUserIdMapping != null) {
				var2 = ((InternalEObject) this.uniqueUserIdMapping).eInverseRemove(this, -3, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -3, (Class) null, var2);
			}

			var2 = this.basicSetUniqueUserIdMapping(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var1, var1));
		}

	}

	public UserRegistryInfoMappingType createUniqueUserIdMapping() {
		UserRegistryInfoMappingType var1 = ConfigmodelFactory.eINSTANCE.createUserRegistryInfoMappingType();
		this.setUniqueUserIdMapping(var1);
		return var1;
	}

	public UserRegistryInfoMappingType getUserSecurityNameMapping() {
		return this.userSecurityNameMapping;
	}

	public NotificationChain basicSetUserSecurityNameMapping(UserRegistryInfoMappingType var1, NotificationChain var2) {
		UserRegistryInfoMappingType var3 = this.userSecurityNameMapping;
		this.userSecurityNameMapping = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 3, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setUserSecurityNameMapping(UserRegistryInfoMappingType var1) {
		if (var1 != this.userSecurityNameMapping) {
			NotificationChain var2 = null;
			if (this.userSecurityNameMapping != null) {
				var2 = ((InternalEObject) this.userSecurityNameMapping).eInverseRemove(this, -4, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -4, (Class) null, var2);
			}

			var2 = this.basicSetUserSecurityNameMapping(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var1, var1));
		}

	}

	public UserRegistryInfoMappingType createUserSecurityNameMapping() {
		UserRegistryInfoMappingType var1 = ConfigmodelFactory.eINSTANCE.createUserRegistryInfoMappingType();
		this.setUserSecurityNameMapping(var1);
		return var1;
	}

	public UserRegistryInfoMappingType getUserDisplayNameMapping() {
		return this.userDisplayNameMapping;
	}

	public NotificationChain basicSetUserDisplayNameMapping(UserRegistryInfoMappingType var1, NotificationChain var2) {
		UserRegistryInfoMappingType var3 = this.userDisplayNameMapping;
		this.userDisplayNameMapping = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 4, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setUserDisplayNameMapping(UserRegistryInfoMappingType var1) {
		if (var1 != this.userDisplayNameMapping) {
			NotificationChain var2 = null;
			if (this.userDisplayNameMapping != null) {
				var2 = ((InternalEObject) this.userDisplayNameMapping).eInverseRemove(this, -5, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -5, (Class) null, var2);
			}

			var2 = this.basicSetUserDisplayNameMapping(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var1, var1));
		}

	}

	public UserRegistryInfoMappingType createUserDisplayNameMapping() {
		UserRegistryInfoMappingType var1 = ConfigmodelFactory.eINSTANCE.createUserRegistryInfoMappingType();
		this.setUserDisplayNameMapping(var1);
		return var1;
	}

	public UserRegistryInfoMappingType getUniqueGroupIdMapping() {
		return this.uniqueGroupIdMapping;
	}

	public NotificationChain basicSetUniqueGroupIdMapping(UserRegistryInfoMappingType var1, NotificationChain var2) {
		UserRegistryInfoMappingType var3 = this.uniqueGroupIdMapping;
		this.uniqueGroupIdMapping = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 5, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setUniqueGroupIdMapping(UserRegistryInfoMappingType var1) {
		if (var1 != this.uniqueGroupIdMapping) {
			NotificationChain var2 = null;
			if (this.uniqueGroupIdMapping != null) {
				var2 = ((InternalEObject) this.uniqueGroupIdMapping).eInverseRemove(this, -6, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -6, (Class) null, var2);
			}

			var2 = this.basicSetUniqueGroupIdMapping(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 5, var1, var1));
		}

	}

	public UserRegistryInfoMappingType createUniqueGroupIdMapping() {
		UserRegistryInfoMappingType var1 = ConfigmodelFactory.eINSTANCE.createUserRegistryInfoMappingType();
		this.setUniqueGroupIdMapping(var1);
		return var1;
	}

	public UserRegistryInfoMappingType getGroupSecurityNameMapping() {
		return this.groupSecurityNameMapping;
	}

	public NotificationChain basicSetGroupSecurityNameMapping(UserRegistryInfoMappingType var1,
			NotificationChain var2) {
		UserRegistryInfoMappingType var3 = this.groupSecurityNameMapping;
		this.groupSecurityNameMapping = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 6, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setGroupSecurityNameMapping(UserRegistryInfoMappingType var1) {
		if (var1 != this.groupSecurityNameMapping) {
			NotificationChain var2 = null;
			if (this.groupSecurityNameMapping != null) {
				var2 = ((InternalEObject) this.groupSecurityNameMapping).eInverseRemove(this, -7, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -7, (Class) null, var2);
			}

			var2 = this.basicSetGroupSecurityNameMapping(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 6, var1, var1));
		}

	}

	public UserRegistryInfoMappingType createGroupSecurityNameMapping() {
		UserRegistryInfoMappingType var1 = ConfigmodelFactory.eINSTANCE.createUserRegistryInfoMappingType();
		this.setGroupSecurityNameMapping(var1);
		return var1;
	}

	public UserRegistryInfoMappingType getGroupDisplayNameMapping() {
		return this.groupDisplayNameMapping;
	}

	public NotificationChain basicSetGroupDisplayNameMapping(UserRegistryInfoMappingType var1, NotificationChain var2) {
		UserRegistryInfoMappingType var3 = this.groupDisplayNameMapping;
		this.groupDisplayNameMapping = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 7, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setGroupDisplayNameMapping(UserRegistryInfoMappingType var1) {
		if (var1 != this.groupDisplayNameMapping) {
			NotificationChain var2 = null;
			if (this.groupDisplayNameMapping != null) {
				var2 = ((InternalEObject) this.groupDisplayNameMapping).eInverseRemove(this, -8, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -8, (Class) null, var2);
			}

			var2 = this.basicSetGroupDisplayNameMapping(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 7, var1, var1));
		}

	}

	public UserRegistryInfoMappingType createGroupDisplayNameMapping() {
		UserRegistryInfoMappingType var1 = ConfigmodelFactory.eINSTANCE.createUserRegistryInfoMappingType();
		this.setGroupDisplayNameMapping(var1);
		return var1;
	}

	public boolean isAllowOperationIfReposDown() {
		return this.allowOperationIfReposDown;
	}

	public void setAllowOperationIfReposDown(boolean var1) {
		boolean var2 = this.allowOperationIfReposDown;
		this.allowOperationIfReposDown = var1;
		boolean var3 = this.allowOperationIfReposDownESet;
		this.allowOperationIfReposDownESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 11, var2, this.allowOperationIfReposDown, !var3));
		}

	}

	public void unsetAllowOperationIfReposDown() {
		boolean var1 = this.allowOperationIfReposDown;
		boolean var2 = this.allowOperationIfReposDownESet;
		this.allowOperationIfReposDown = false;
		this.allowOperationIfReposDownESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 11, var1, false, var2));
		}

	}

	public boolean isSetAllowOperationIfReposDown() {
		return this.allowOperationIfReposDownESet;
	}

	public String getDelimiter() {
		return this.delimiter;
	}

	public void setDelimiter(String var1) {
		String var2 = this.delimiter;
		this.delimiter = var1;
		boolean var3 = this.delimiterESet;
		this.delimiterESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 8, var2, this.delimiter, !var3));
		}

	}

	public void unsetDelimiter() {
		String var1 = this.delimiter;
		boolean var2 = this.delimiterESet;
		this.delimiter = "@";
		this.delimiterESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 8, var1, "@", var2));
		}

	}

	public boolean isSetDelimiter() {
		return this.delimiterESet;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		String var2 = this.name;
		this.name = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 9, var2, this.name));
		}

	}

	public String getSecurityUse() {
		return this.securityUse;
	}

	public void setSecurityUse(String var1) {
		String var2 = this.securityUse;
		this.securityUse = var1;
		boolean var3 = this.securityUseESet;
		this.securityUseESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 10, var2, this.securityUse, !var3));
		}

	}

	public void unsetSecurityUse() {
		String var1 = this.securityUse;
		boolean var2 = this.securityUseESet;
		this.securityUse = "active";
		this.securityUseESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 10, var1, "active", var2));
		}

	}

	public boolean isSetSecurityUse() {
		return this.securityUseESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getParticipatingBaseEntries()).basicRemove(var1, var4);
				case 1 :
					return ((InternalEList) this.getDefaultParents()).basicRemove(var1, var4);
				case 2 :
					return this.basicSetUniqueUserIdMapping((UserRegistryInfoMappingType) null, var4);
				case 3 :
					return this.basicSetUserSecurityNameMapping((UserRegistryInfoMappingType) null, var4);
				case 4 :
					return this.basicSetUserDisplayNameMapping((UserRegistryInfoMappingType) null, var4);
				case 5 :
					return this.basicSetUniqueGroupIdMapping((UserRegistryInfoMappingType) null, var4);
				case 6 :
					return this.basicSetGroupSecurityNameMapping((UserRegistryInfoMappingType) null, var4);
				case 7 :
					return this.basicSetGroupDisplayNameMapping((UserRegistryInfoMappingType) null, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getParticipatingBaseEntries();
			case 1 :
				return this.getDefaultParents();
			case 2 :
				return this.getUniqueUserIdMapping();
			case 3 :
				return this.getUserSecurityNameMapping();
			case 4 :
				return this.getUserDisplayNameMapping();
			case 5 :
				return this.getUniqueGroupIdMapping();
			case 6 :
				return this.getGroupSecurityNameMapping();
			case 7 :
				return this.getGroupDisplayNameMapping();
			case 8 :
				return this.getDelimiter();
			case 9 :
				return this.getName();
			case 10 :
				return this.getSecurityUse();
			case 11 :
				return this.isAllowOperationIfReposDown() ? Boolean.TRUE : Boolean.FALSE;
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getParticipatingBaseEntries().clear();
				this.getParticipatingBaseEntries().addAll((Collection) var2);
				return;
			case 1 :
				this.getDefaultParents().clear();
				this.getDefaultParents().addAll((Collection) var2);
				return;
			case 2 :
				this.setUniqueUserIdMapping((UserRegistryInfoMappingType) var2);
				return;
			case 3 :
				this.setUserSecurityNameMapping((UserRegistryInfoMappingType) var2);
				return;
			case 4 :
				this.setUserDisplayNameMapping((UserRegistryInfoMappingType) var2);
				return;
			case 5 :
				this.setUniqueGroupIdMapping((UserRegistryInfoMappingType) var2);
				return;
			case 6 :
				this.setGroupSecurityNameMapping((UserRegistryInfoMappingType) var2);
				return;
			case 7 :
				this.setGroupDisplayNameMapping((UserRegistryInfoMappingType) var2);
				return;
			case 8 :
				this.setDelimiter((String) var2);
				return;
			case 9 :
				this.setName((String) var2);
				return;
			case 10 :
				this.setSecurityUse((String) var2);
				return;
			case 11 :
				this.setAllowOperationIfReposDown((Boolean) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getParticipatingBaseEntries().clear();
				return;
			case 1 :
				this.getDefaultParents().clear();
				return;
			case 2 :
				this.setUniqueUserIdMapping((UserRegistryInfoMappingType) null);
				return;
			case 3 :
				this.setUserSecurityNameMapping((UserRegistryInfoMappingType) null);
				return;
			case 4 :
				this.setUserDisplayNameMapping((UserRegistryInfoMappingType) null);
				return;
			case 5 :
				this.setUniqueGroupIdMapping((UserRegistryInfoMappingType) null);
				return;
			case 6 :
				this.setGroupSecurityNameMapping((UserRegistryInfoMappingType) null);
				return;
			case 7 :
				this.setGroupDisplayNameMapping((UserRegistryInfoMappingType) null);
				return;
			case 8 :
				this.unsetDelimiter();
				return;
			case 9 :
				this.setName(NAME_EDEFAULT);
				return;
			case 10 :
				this.unsetSecurityUse();
				return;
			case 11 :
				this.unsetAllowOperationIfReposDown();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.participatingBaseEntries != null && !this.participatingBaseEntries.isEmpty();
			case 1 :
				return this.defaultParents != null && !this.defaultParents.isEmpty();
			case 2 :
				return this.uniqueUserIdMapping != null;
			case 3 :
				return this.userSecurityNameMapping != null;
			case 4 :
				return this.userDisplayNameMapping != null;
			case 5 :
				return this.uniqueGroupIdMapping != null;
			case 6 :
				return this.groupSecurityNameMapping != null;
			case 7 :
				return this.groupDisplayNameMapping != null;
			case 8 :
				return this.isSetDelimiter();
			case 9 :
				return NAME_EDEFAULT == null ? this.name != null : !NAME_EDEFAULT.equals(this.name);
			case 10 :
				return this.isSetSecurityUse();
			case 11 :
				return this.isSetAllowOperationIfReposDown();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (delimiter: ");
			if (this.delimiterESet) {
				var1.append(this.delimiter);
			} else {
				var1.append("<unset>");
			}

			var1.append(", name: ");
			var1.append(this.name);
			var1.append(", allowOperationIfReposDown: ");
			if (this.allowOperationIfReposDownESet) {
				var1.append(this.allowOperationIfReposDown);
			} else {
				var1.append("<unset>");
			}

			var1.append(", securityUse: ");
			if (this.securityUseESet) {
				var1.append(this.securityUse);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}