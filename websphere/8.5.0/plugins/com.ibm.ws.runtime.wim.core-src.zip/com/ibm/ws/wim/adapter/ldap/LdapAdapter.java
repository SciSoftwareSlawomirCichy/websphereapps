package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.security.auth.WSSubject;
import com.ibm.websphere.security.cred.WSCredential;
import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.SchemaConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.CertificateMapFailedException;
import com.ibm.websphere.wim.exception.ChangeControlException;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.EntityHasDescendantsException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.EntityTypeNotSupportedException;
import com.ibm.websphere.wim.exception.InvalidEntityTypeException;
import com.ibm.websphere.wim.exception.InvalidPropertyValueException;
import com.ibm.websphere.wim.exception.MissingMandatoryPropertyException;
import com.ibm.websphere.wim.exception.PasswordCheckFailedException;
import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.UpdatePropertyException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.websphere.wim.util.UniqueIdGenerator;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.ldap.change.ChangeHandlerFactory;
import com.ibm.ws.wim.adapter.ldap.change.IChangeHandler;
import com.ibm.ws.wim.policy.PolicyHandlerFactory;
import com.ibm.ws.wim.util.AsyncUtils;
import com.ibm.ws.wim.util.ControlsHelper;
import com.ibm.ws.wim.util.LoginHelper;
import com.ibm.ws.wim.util.NodeHelper;
import com.ibm.ws.wim.util.UniqueNameHelper;
import com.ibm.ws.wim.xpath.ParseException;
import com.ibm.ws.wim.xpath.TokenMgrError;
import com.ibm.ws.wim.xpath.WIMXPathInterpreter;
import com.ibm.ws.wim.xpath.ldap.util.LdapXPathTranslateHelper;
import com.ibm.ws.wim.xpath.mapping.datatype.PropertyNode;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;
import com.ibm.ws.wim.xpath.util.MetadataMapper;
import com.ibm.wsspi.wim.Repository;
import com.ibm.wsspi.wim.RepositoryImpl;
import com.ibm.wsspi.wim.adapter.ldap.ILdapPolicyHandler;
import com.sun.jndi.ldap.LdapName;
import commonj.sdo.ChangeSummary;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Type;
import commonj.sdo.ChangeSummary.Setting;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.AuthenticationException;
import javax.naming.AuthenticationNotSupportedException;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.OperationNotSupportedException;
import javax.naming.directory.Attribute;
import javax.naming.directory.AttributeInUseException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.NoSuchAttributeException;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.LdapContext;
import javax.security.auth.Subject;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

public class LdapAdapter extends RepositoryImpl
		implements
			Repository,
			DynamicConfigService,
			SchemaConstants,
			LdapConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private SchemaManager iSchemaMgr = null;
	private LdapConfigManager iLdapConfigMgr = null;
	protected LdapConnection iLdapConn = null;
	protected IChangeHandler changeHandler = null;
	protected ILdapPolicyHandler policyHandler = null;
	private boolean isActiveDirectory = false;

	public void initialize(DataObject var1) throws WIMException {
		super.initialize(var1);
		this.iSchemaMgr = SchemaManager.singleton();
		this.iLdapConfigMgr = new LdapConfigManager();
		this.iLdapConfigMgr.initialize(var1);
		this.isActiveDirectory = this.iLdapConfigMgr.isActiveDirectory();
		this.iLdapConn = new LdapConnection(this.iLdapConfigMgr);
		this.iLdapConn.initialize(var1);
		if (var1.getString("supportChangeLog").equalsIgnoreCase("native")) {
			this.changeHandler = ChangeHandlerFactory.getChangeHandler(this.iLdapConn);
		}

		if (this.iLdapConfigMgr.getLdapType().startsWith("DOMINO") && this.iLdapConfigMgr.isAnyExtIdDN()) {
			this.resetDefaultDominoExtIdAttributes(var1);
		}

		if (this.iLdapConfigMgr.getIsPolicyEnforced() != null) {
			this.policyHandler = (ILdapPolicyHandler) PolicyHandlerFactory.getPolicyHandler(var1, this.iLdapConn);
		}

	}

	private void resetDefaultDominoExtIdAttributes(DataObject var1) throws WIMException {
		DataObject var2 = var1.getDataObject("attributeConfiguration");
		ArrayList var3 = null;
		if (var2 != null) {
			List var4 = var2.getList("externalIdAttributes");
			int var5 = var4.size();
			if (var5 > 0) {
				for (int var6 = 0; var6 < var5; ++var6) {
					DataObject var7 = (DataObject) var4.get(var6);
					List var8 = var7.getList("entityTypes");
					if (var8 != null && var3 == null) {
						var3 = new ArrayList();
					}

					var3.addAll(var8);
				}

				if (var3 == null || var3.size() == 0) {
					return;
				}
			}
		}

		if (this.isDominounidSupport()) {
			this.iLdapConfigMgr.resetDefaultDominoExtIdAttribute(var3);
		}
	}

	private boolean isDominounidSupport() throws WIMException {
		DirContext var2 = null;

		boolean var4;
		try {
			var2 = this.iLdapConn.getDirContext();
			DirContext var3 = var2.getSchema("");
			Attributes var13 = var3.getAttributes("AttributeDefinition/dominounid");
			boolean var5 = true;
			return var5;
		} catch (NameNotFoundException var10) {
			var4 = false;
			return var4;
		} catch (NamingException var11) {
			trcLogger.logp(Level.FINE, CLASSNAME, "isDominounidSupport", "LDAP exception: " + var11.toString(true));
			var4 = false;
		} finally {
			this.iLdapConn.releaseDirContext(var2);
		}

		return var4;
	}

	public DataObject create(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI create", WIMTraceHelper.printDataGraph(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.getRepositoryId(), CLASSNAME, "create");
		DataObject var3 = (DataObject) var1.getList("entities").get(0);
		Type var4 = var3.getType();
		String var5 = var4.getName();
		DataObject var6 = this.iSchemaMgr.createRootDataObject();
		DataObject var7 = var3.getDataObject("identifier");
		var3.unset("identifier");
		String var8 = var7.getString("externalName");
		String var9 = var7.getString("uniqueName");
		LdapEntity var10 = this.iLdapConfigMgr.getLdapEntity(var4);
		if (var10 == null) {
			throw new EntityTypeNotSupportedException("ENTITY_TYPE_NOT_SUPPORTED",
					WIMMessageHelper.generateMsgParms(var5), CLASSNAME, "create");
		} else {
			String var11 = var10.getName();
			if (this.iLdapConfigMgr.isPersonAccount(var11)) {
				if (var3.isSet("principalName")) {
					throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
							WIMMessageHelper.generateMsgParms("principalName", this.getRepositoryId()), CLASSNAME,
							"create");
				}

				if (var3.isSet("realm")) {
					throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
							WIMMessageHelper.generateMsgParms("realm", this.getRepositoryId()), CLASSNAME, "create");
				}
			}

			EClass var12 = this.iSchemaMgr.getEClass(var3.getType());
			EList var13 = var12.getEAllStructuralFeatures();
			BasicAttributes var14 = new BasicAttributes();
			List var15 = null;
			List var16 = null;

			Set var22;
			Iterator var23;
			for (int var17 = 0; var17 < var13.size(); ++var17) {
				EStructuralFeature var18 = (EStructuralFeature) var13.get(var17);
				Property var19 = this.iSchemaMgr.getProperty(var18);
				String var20 = this.iSchemaMgr.getQualifiedPropertyName(var18);
				String var21 = var18.getName();
				if (var18.getLowerBound() == 1 && !var3.isSet(var21)) {
					Object[] var36 = new Object[]{var21};
					throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY", var36, CLASSNAME,
							"create");
				}

				if (var3.isSet(var19)) {
					if (this.iLdapConfigMgr.isPersistentProperty(var20)) {
						var22 = this.getAttribute(var3, (Object) null, var19, var20, var10);
						var23 = var22.iterator();

						while (var23.hasNext()) {
							var14.put((Attribute) var23.next());
						}
					} else if ("members".equals(var20)) {
						var16 = var3.getList(var19);
					} else if ("groups".equals(var20)) {
						var15 = var3.getList(var19);
					}
				}
			}

			if (var8 == null) {
				var8 = this.getDN(var9, var11, var14, false, true);
			}

			Attribute var31 = var10.getObjectClassAttribute(var8);
			var14.put(var31);
			String var32 = var10.getExtId();
			String var33 = null;
			LdapAttribute var34 = this.iLdapConfigMgr.getAttribute(var32);
			if (var34 != null && var34.isWIMGenerate()) {
				var33 = UniqueIdGenerator.newUniqueId();
				var14.put(new BasicAttribute(var32, var33));
			}

			boolean var35 = this.iLdapConfigMgr.isGroup(var11);
			String var27;
			String var37;
			if (var16 != null && var16.size() > 0) {
				if (!var35) {
					throw new InvalidEntityTypeException("ENTITY_IS_NOT_A_GROUP",
							WIMMessageHelper.generateMsgParms(var9), Level.SEVERE, CLASSNAME, "create");
				}

				var37 = this.iLdapConfigMgr.getMemberAttribute(var31);
				if (var16.size() > 0) {
					BasicAttribute var39 = new BasicAttribute(var37);

					for (int var40 = 0; var40 < var16.size(); ++var40) {
						DataObject var25 = ((DataObject) var16.get(var40)).getDataObject("identifier");
						LdapEntry var26 = this.iLdapConn.getEntityByIdentifier(var25, (List) null, (List) null, false,
								false);
						var27 = var26.getDN();
						var39.add(var27);
					}

					var14.put(var39);
				}
			} else if (var35) {
				var37 = this.iLdapConfigMgr.getMemberAttribute(var31);
				String var38 = this.iLdapConfigMgr.getDummyMember(var37);
				if (var38 != null) {
					BasicAttribute var24 = new BasicAttribute(var37, var38);
					var14.put(var24);
				}
			}

			var22 = this.iLdapConfigMgr.getAttributesWithDefaultValue();
			var23 = var22.iterator();

			while (var23.hasNext()) {
				String var42 = (String) var23.next();
				LdapAttribute var44 = this.iLdapConfigMgr.getLdapAttribute(var42);
				if (var44 != null) {
					Object var48 = var44.getDefaultValue(var11);
					if (var48 != null && !LdapHelper.inAttributes(var42, var14)) {
						var14.put(new BasicAttribute(var44.getName(), var48));
					}
				}
			}

			Set var41 = this.iLdapConfigMgr.getAttributesWithDefaultAttribute();
			Iterator var43 = var41.iterator();

			while (var43.hasNext()) {
				String var46 = (String) var43.next();
				LdapAttribute var49 = this.iLdapConfigMgr.getLdapAttribute(var46);
				if (var49 != null) {
					var27 = var49.getDefaultAttribute(var11);
					if (var27 != null && !LdapHelper.inAttributes(var46, var14)) {
						Attribute var28 = var14.get(var27);
						if (var28 != null) {
							var14.put(LdapHelper.cloneAttribute(var49.getName(), var28));
						}
					}
				}
			}

			Attribute var45 = null;
			if (this.iLdapConfigMgr.getLdapType().equals("AD2003")) {
				var45 = var14.remove("userAccountControl");
			}

			DirContext var47 = this.iLdapConn.createSubcontext(var8, var14);

			try {
				var47.close();
			} catch (NamingException var30) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var30.toString(true)), Level.SEVERE, CLASSNAME, "create");
			}

			if (var45 != null) {
				BasicAttributes var50 = new BasicAttributes();
				var50.put(var45);

				try {
					this.iLdapConn.modifyAttributes(var8, 2, var50);
				} catch (NamingException var29) {
					throw new WIMSystemException("NAMING_EXCEPTION",
							WIMMessageHelper.generateMsgParms(var29.toString(true)), CLASSNAME, "create");
				}
			}

			if (var15 != null) {
				this.updateGroups(var8, var15, 1);
			}

			if (var33 == null) {
				var33 = this.getExtId(var8, var32, (Attributes) null);
			}

			this.iLdapConn.invalidateNamesCache();
			DataObject var51 = var6.createDataObject("entities", var4.getURI(), var5);
			DataObject var52 = var51.createDataObject("identifier");
			if (this.iLdapConfigMgr.needTranslateRDN(var5) && !this.iLdapConfigMgr.needTranslateRDN()) {
				var52.setString("uniqueName", this.iLdapConfigMgr.switchToNode(var8));
			} else {
				var52.setString("uniqueName", var9);
			}

			var52.setString("externalName", var8);
			var52.setString("externalId", var33);
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI create", WIMTraceHelper.printDataGraph(var6));
			}

			return var6;
		}
	}

	private String getExtId(String var1, String var2, Attributes var3) throws WIMException {
		if ("distinguishedName".equalsIgnoreCase(var2)) {
			return LdapHelper.toUpperCase(var1);
		} else {
			Attribute var5 = null;
			if (var3 != null) {
				var5 = var3.get(var2);
			}

			if (var5 == null) {
				String[] var6 = new String[]{var2};
				var3 = this.iLdapConn.checkAttributesCache(var1, var6);
				var5 = var3.get(var2);
			}

			if (var5 == null) {
				return LdapHelper.toUpperCase(var1);
			} else if (var5.size() > 1) {
				throw new WIMSystemException("EXT_ID_HAS_MULTIPLE_VALUES", WIMMessageHelper.generateMsgParms(var5),
						CLASSNAME, "getExtId(String DN, javax.naming.directory.Attributes attributes)");
			} else {
				LdapAttribute var9 = this.iLdapConfigMgr.getAttribute(var2);

				try {
					Object var7 = var5.get();
					if (var9 != null && "octetString".equalsIgnoreCase(var9.getSyntax())) {
						return LdapHelper.getOctetString((byte[]) ((byte[]) var7));
					} else {
						return var9 != null && "GUID".equalsIgnoreCase(var9.getSyntax())
								? LdapHelper.convertToDashedString((byte[]) ((byte[]) var7))
								: var7.toString();
					}
				} catch (NamingException var8) {
					throw new WIMSystemException("NAMING_EXCEPTION",
							WIMMessageHelper.generateMsgParms(var8.toString(true)), Level.SEVERE, CLASSNAME,
							"getExtId(String DN, javax.naming.directory.Attributes attributes)");
				}
			}
		}
	}

	private Object getPropertyValue(Property var1, String var2, Object var3) {
		return var3;
	}

	private Set getAttribute(DataObject var1, Object var2, Property var3, String var4, LdapEntity var5)
			throws WIMException {
		HashMap var7 = new HashMap();
		ArrayList var8 = new ArrayList(1);
		var8.add(var4);
		List var9 = this.iLdapConfigMgr.getSupportedProperties(var5, var8);
		if (var9 != null && var9.size() != 0) {
			String var10 = this.iLdapConfigMgr.getAttributeName(var5, var4);
			String var11 = var3.getType().getName();
			LdapAttribute var12 = this.iLdapConfigMgr.getLdapAttribute(var10);
			String var13 = this.iLdapConfigMgr.getLdapType();
			Object var14 = null;
			if (var3.isMany()) {
				if (var2 != null) {
					var14 = (List) var2;
				} else {
					var14 = var1.getList(var3);
				}
			} else {
				var14 = new ArrayList(1);
				if (var2 != null) {
					((List) var14).add(var2);
				} else {
					((List) var14).add(var1.get(var3));
				}
			}

			for (int var15 = 0; var15 < ((List) var14).size(); ++var15) {
				Object var17 = ((List) var14).get(var15);
				Object var18 = null;
				if ("String".equals(var11)) {
					var18 = LdapHelper.getStringLdapValue(var17, var12, var13);
				} else if ("DateTime".equals(var11)) {
					var18 = LdapHelper.getDateLdapValue(var17, var12, var13);
				} else {
					DataObject var19;
					if ("IdentifierType".equals(var11)) {
						if (var17 != null) {
							var19 = (DataObject) var17;

							try {
								LdapEntry var20 = this.iLdapConn.getEntityByIdentifier(var19, (List) null, (List) null,
										false, false);
								var18 = var20.getDN();
							} catch (EntityNotFoundException var21) {
								throw new InvalidPropertyValueException("INVALID_PROPERTY_VALUE",
										WIMMessageHelper.generateMsgParms(var4), CLASSNAME, "getAttribute", var21);
							}
						}
					} else if ("Base64Binary".equals(var11)) {
						if (var12 != null && "unicodePwd".equalsIgnoreCase(var12.getSyntax())) {
							var18 = LdapHelper.encodePassword(new String((byte[]) ((byte[]) var17)));
						} else {
							var18 = var17;
						}
					} else if ("Int".equals(var11)) {
						var18 = LdapHelper.getIntLdapValue(var17, var12, var13);
					} else if ("LangType".equals(var11)) {
						var19 = (DataObject) var17;
						var18 = var19.getString("value");
					} else {
						var18 = var17.toString();
					}
				}

				if (var18 != null) {
					Object var23 = (Attribute) var7.get(var10);
					if (var23 == null) {
						var23 = new BasicAttribute(var10);
						var7.put(var10, var23);
					}

					((Attribute) var23).add(var18);
				}
			}

			HashSet var22 = new HashSet(var7.values());
			return var22;
		} else {
			return new HashSet();
		}
	}

	private List getGroups(String var1) throws WIMException {
		ArrayList var3 = new ArrayList();
		String var4 = this.iLdapConfigMgr.getGroupMemberFilter(var1);
		String[] var5 = this.iLdapConfigMgr.getGroupSearchBases();

		for (int var6 = 0; var6 < var5.length; ++var6) {
			String var7 = var5[var6];
			NamingEnumeration var8 = this.iLdapConn.search(var7, var4, 2, LDAP_ATTR_OBJECTCLASS_ARRAY);

			while (var8.hasMoreElements()) {
				SearchResult var9 = (SearchResult) var8.nextElement();
				if (var9 != null) {
					String var10 = var9.getName();
					if (var10 != null && var10.trim().length() != 0) {
						var3.add(LdapHelper.prepareDN(var10, var7));
					}
				}
			}
		}

		return var3;
	}

	private void updateGroupMember(String var1, String var2) throws WIMException {
		if (this.iLdapConfigMgr.updateGroupMembership()) {
			String var4 = this.iLdapConfigMgr.getGroupMemberFilter(var1);
			String[] var5 = this.iLdapConfigMgr.getMemberAttributes();
			HashMap var6 = new HashMap(var5.length);

			for (int var7 = 0; var7 < var5.length; ++var7) {
				String var8 = var5[var7];
				ModificationItem var9 = new ModificationItem(3, new BasicAttribute(var8, var1));
				ModificationItem[] var10 = null;
				if (var2 != null) {
					ModificationItem var11 = new ModificationItem(1, new BasicAttribute(var8, var2));
					var10 = new ModificationItem[]{var11, var9};
				} else {
					var10 = new ModificationItem[]{var9};
				}

				var6.put(var8.toLowerCase(), var10);
			}

			String[] var19 = this.iLdapConfigMgr.getGroupSearchBases();

			label63 : for (int var20 = 0; var20 < var19.length; ++var20) {
				String var21 = var19[var20];
				NamingEnumeration var22 = this.iLdapConn.search(var21, var4, 2, LDAP_ATTR_OBJECTCLASS_ARRAY);

				while (true) {
					String var13;
					ModificationItem[] var16;
					do {
						String var12;
						SearchResult var23;
						do {
							do {
								do {
									if (!var22.hasMoreElements()) {
										continue label63;
									}

									var23 = (SearchResult) var22.nextElement();
								} while (var23 == null);

								var12 = var23.getName();
							} while (var12 == null);
						} while (var12.trim().length() == 0);

						var13 = LdapHelper.prepareDN(var12, var21);
						Attributes var14 = var23.getAttributes();
						String var15 = this.iLdapConfigMgr.getMemberAttribute(var14.get("objectClass"));
						var16 = (ModificationItem[]) ((ModificationItem[]) var6.get(var15.toLowerCase()));
					} while (var16 == null);

					try {
						this.iLdapConn.modifyAttributes(var13, var16);
					} catch (Exception var18) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME, "updateGroupMember",
									"Updating group " + var13 + " for " + var1 + " failed due to: " + var18.toString());
						}
					}
				}
			}

		}
	}

	public DataObject delete(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI delete(DataGraph)", WIMTraceHelper.printDataGraph(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.getRepositoryId(), CLASSNAME, "delete(DataGraph)");
		Map var3 = ControlsHelper.getControlMap(var1);
		DataObject var4 = (DataObject) var3.get("DeleteControl");
		boolean var5 = false;
		if (var4 != null) {
			var5 = var4.getBoolean("deleteDescendants");
		}

		DataObject var6 = (DataObject) var1.getList("entities").get(0);
		DataObject var7 = var6.getDataObject("identifier");
		LdapEntry var8 = this.iLdapConn.getEntityByIdentifier(var7, (List) null, (List) null, false, false);
		DataObject var9 = this.iSchemaMgr.createRootDataObject();
		List var10 = this.deleteAll(var8, var5);

		for (int var11 = 0; var11 < var10.size(); ++var11) {
			LdapEntry var12 = (LdapEntry) var10.get(var11);
			this.createEntityFromLdapEntry(var9, "entities", var12, (List) null);
			this.updateGroupMember(var8.getDN(), (String) null);
			this.iLdapConn.invalidateAttributes(var12.getDN(), var12.getExtId(), var12.getUniqueName());
		}

		this.iLdapConn.invalidateNamesCache();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI delete(DataGraph)", WIMTraceHelper.printDataGraph(var9));
		}

		return var9;
	}

	private List deleteAll(LdapEntry var1, boolean var2) throws WIMException {
		String var3 = var1.getDN();
		ArrayList var4 = new ArrayList();
		List var5 = this.getDescendants(var3, 1);
		String var8;
		if (var5.size() > 0) {
			if (!var2) {
				throw new EntityHasDescendantsException("ENTITY_HAS_DESCENDENTS",
						WIMMessageHelper.generateMsgParms(var3), Level.SEVERE, CLASSNAME, "deleteAll");
			}

			for (int var6 = 0; var6 < var5.size(); ++var6) {
				LdapEntry var7 = (LdapEntry) var5.get(var6);
				var8 = var1.getDN();
				var4.addAll(this.deleteAll(var7, true));
			}
		}

		this.deletePreExit(var3);
		List var9 = this.getGroups(var3);
		this.iLdapConn.destroySubcontext(var3);
		var4.add(var1);

		for (int var10 = 0; var10 < var9.size(); ++var10) {
			var8 = (String) var9.get(var10);
			this.iLdapConn.invalidateAttributes(var8, (String) null, (String) null);
		}

		return var4;
	}

	protected void deletePreExit(String var1) throws WIMException {
	}

	private List getDescendants(String var1, int var2) throws WIMException {
		byte var4 = 1;
		if (var2 == 0) {
			var4 = 2;
		}

		ArrayList var5 = new ArrayList();
		Set var6 = this.iLdapConn.searchEntities(var1, "objectClass=*", (Object[]) null, var4, (List) null, (List) null,
				false, false);
		Iterator var7 = var6.iterator();

		while (var7.hasNext()) {
			LdapEntry var8 = (LdapEntry) var7.next();
			var5.add(var8);
		}

		return var5;
	}

	private void updateGroups(String var1, List var2, int var3) throws WIMException {
		if (var2.size() > 0) {
			String var5 = null;
			List var6 = this.iLdapConfigMgr.getGroupTypes();

			for (int var7 = 0; var7 < var2.size(); ++var7) {
				DataObject var8 = ((DataObject) var2.get(var7)).getDataObject("identifier");
				LdapEntry var9 = this.iLdapConn.getEntityByIdentifier(var8, var6, (List) null, false, false);
				if (!this.iLdapConfigMgr.isGroup(var9.getType())) {
					throw new InvalidEntityTypeException("ENTITY_IS_NOT_A_GROUP",
							WIMMessageHelper.generateMsgParms(var8.getString("uniqueName")), Level.SEVERE, CLASSNAME,
							"updateGroups(String, List, int)");
				}

				String var10 = var9.getDN();
				if (var5 == null) {
					Attributes var11 = var9.getAttributes();
					Attribute var12 = var11.get("objectClass");
					var5 = this.iLdapConfigMgr.getMemberAttribute(var12);
				}

				BasicAttributes var21 = new BasicAttributes();
				BasicAttribute var22 = new BasicAttribute(var5, var1);
				var21.put(var22);

				try {
					if (3 == var3) {
						try {
							this.iLdapConn.modifyAttributes(var10, 3, var21);
						} catch (NoSuchAttributeException var14) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "updateGroups(String, List, int)",
										"Entity " + var1 + " is already not a member of group " + var10 + ":"
												+ var14.toString(true));
							}
						} catch (OperationNotSupportedException var15) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "updateGroups(String, List, int)",
										"Entity " + var1 + " is already not a member of group " + var10 + ":"
												+ var15.toString(true));
							}
						}
					} else if (2 == var3) {
						try {
							this.iLdapConn.modifyAttributes(var10, 2, var21);
						} catch (NoSuchAttributeException var16) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "updateGroups(String, List, int)",
										"Entity " + var1 + " is already not a member of group " + var10 + ":"
												+ var16.toString(true));
							}
						} catch (OperationNotSupportedException var17) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "updateGroups(String, List, int)",
										"Entity " + var1 + " is already not a member of group " + var10 + ":"
												+ var17.toString(true));
							}
						}
					} else {
						try {
							this.iLdapConn.modifyAttributes(var10, 1, var21);
						} catch (AttributeInUseException var18) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "updateGroups(String, List, int)", "Entity "
										+ var1 + " is already a member of group " + var10 + ":" + var18.toString(true));
							}
						} catch (NameAlreadyBoundException var19) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "updateGroups(String, List, int)", "Entity "
										+ var1 + " is already a member of group" + var10 + ":" + var19.toString(true));
							}
						}
					}
				} catch (NamingException var20) {
					throw new WIMSystemException("NAMING_EXCEPTION",
							WIMMessageHelper.generateMsgParms(var20.toString(true)), CLASSNAME,
							"updateGroups(String, List, int)");
				}

				this.iLdapConn.invalidateAttributes(var10, var9.getExtId(), var9.getUniqueName());
			}
		}

	}

	private DataObject updateByChangeSummary(DataObject var1, List var2) throws WIMException {
		DataObject var4 = (DataObject) var1.getList("entities").get(0);
		String var5 = this.iSchemaMgr.getQualifiedTypeName(var4.getType());
		DataObject var6 = var4.getDataObject("identifier");
		ArrayList var7 = new ArrayList(1);
		var7.add(var5);
		LdapEntry var8 = this.iLdapConn.getEntityByIdentifier(var6, var7, (List) null, false, false);
		String var9 = var8.getDN();
		String var10 = var8.getExtId();
		String var11 = var8.getUniqueName();
		String var12 = var8.getType();
		LdapEntity var13 = this.iLdapConfigMgr.getLdapEntity(var12);
		String[] var14 = LdapHelper.getRDNAttributes(var9);
		String[] var15 = null;
		DataObject var16 = this.iSchemaMgr.createRootDataObject();
		ChangeSummary var17 = var1.getDataGraph().getChangeSummary();
		ArrayList var18 = new ArrayList();
		Iterator var19 = var2.iterator();

		label163 : while (true) {
			DataObject var20;
			String var23;
			String var24;
			do {
				String var21;
				do {
					if (!var19.hasNext()) {
						if (var18.size() > 0) {
							ModificationItem[] var40 = new ModificationItem[0];
							var40 = (ModificationItem[]) ((ModificationItem[]) var18.toArray(var40));

							try {
								this.iLdapConn.modifyAttributes(var9, var40);
							} catch (NamingException var38) {
								throw new WIMSystemException("NAMING_EXCEPTION",
										WIMMessageHelper.generateMsgParms(var38.toString(true)), CLASSNAME,
										"updateByChangeSummary");
							}
						}

						this.iLdapConn.invalidateAttributes(var9, var10, var11);
						this.iLdapConn.invalidateNamesCache();
						return var16;
					}

					var20 = (DataObject) var19.next();
					var21 = this.iSchemaMgr.getQualifiedTypeName(var20.getType());
				} while (!var12.equals(var21));

				DataObject var22 = var20.getDataObject("identifier");
				var23 = var22.getString("uniqueName");
				var24 = var22.getString("externalId");
			} while (!var11.equalsIgnoreCase(var23) && !var10.equals(var24));

			Iterator var25 = var17.getOldValues(var20).iterator();

			while (true) {
				label159 : while (true) {
					Property var27;
					String var28;
					Object var29;
					Object var30;
					do {
						if (!var25.hasNext()) {
							continue label163;
						}

						Setting var26 = (Setting) var25.next();
						var27 = var26.getProperty();
						var28 = this.iSchemaMgr.getQualifiedPropertyName(var27);
						if ("principalName".equals(var28) && this.iSchemaMgr.isSuperType("LoginAccount", var5)) {
							throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
									WIMMessageHelper.generateMsgParms("principalName", this.getRepositoryId()),
									CLASSNAME, "updateByChangeSummary");
						}

						var29 = var26.getValue();
						var30 = var20.get(var27);
						if (var29 instanceof List && ((List) var29).size() == 0) {
							var29 = null;
						}

						if (var30 instanceof List && ((List) var30).size() == 0) {
							var30 = null;
						}

						Object var31 = null;
						if (var29 != null && var30 != null && var30 instanceof List) {
							List var32 = (List) var30;
							List var33 = (List) var29;
							ArrayList var34 = new ArrayList(var32);
							var32.removeAll(var33);
							var33.removeAll(var34);
							var30 = var32;
							var29 = var33;
						}
					} while (!this.iLdapConfigMgr.isPersistentProperty(var28));

					Set var41;
					Iterator var43;
					Attribute var45;
					if (var29 != null && var29 instanceof List && ((List) var29).size() > 0 && var30 != null) {
						var41 = this.getAttribute(var4, var29, var27, var28, var13);
						var43 = var41.iterator();

						while (var43.hasNext()) {
							var45 = (Attribute) var43.next();
							var18.add(new ModificationItem(3, var45));
						}
					}

					if (var30 == null) {
						String var42 = this.iLdapConfigMgr.getAttributeName(var13, var28);
						BasicAttribute var44 = new BasicAttribute(var42);
						var18.add(new ModificationItem(3, var44));
					} else {
						var41 = this.getAttribute(var4, var30, var27, var28, var13);
						var43 = var41.iterator();

						while (true) {
							while (true) {
								while (true) {
									boolean var35;
									do {
										if (!var43.hasNext()) {
											continue label159;
										}

										var45 = (Attribute) var43.next();
										var35 = false;

										for (int var36 = 0; var36 < var14.length; ++var36) {
											if (var45.getID().equalsIgnoreCase(var14[var36])) {
												if (var15 == null) {
													var15 = new String[var14.length];
												}

												try {
													var15[var36] = (String) var45.get();
												} catch (NamingException var39) {
													trcLogger.logp(Level.FINE, CLASSNAME, "updateByChangeSummary",
															var39.toString(true));
													throw new WIMSystemException("NAMING_EXCEPTION",
															WIMMessageHelper.generateMsgParms(var39.toString(true)),
															Level.SEVERE, CLASSNAME, "updateByChangeSummary");
												}

												var35 = true;
											}
										}
									} while (var35);

									if (var29 == null) {
										if (this.isActiveDirectory && "unicodePwd".equalsIgnoreCase(var45.getID())) {
											var18.add(new ModificationItem(2, var45));
										} else if ("userPassword".equalsIgnoreCase(var45.getID())) {
											var18.add(new ModificationItem(2, var45));
										} else {
											var18.add(new ModificationItem(1, var45));
										}
									} else if (var29 instanceof List) {
										var18.add(new ModificationItem(1, var45));
									} else {
										var18.add(new ModificationItem(2, var45));
									}
								}
							}
						}
					}
				}
			}
		}
	}

	private DataObject updateByDataGraph(DataObject var1) throws WIMException {
		DataObject var3 = this.iSchemaMgr.createRootDataObject();
		DataObject var4 = (DataObject) var1.getList("entities").get(0);
		String var5 = this.iSchemaMgr.getQualifiedTypeName(var4.getType());
		if (this.iSchemaMgr.isSuperType("LoginAccount", var5) && var4.isSet("principalName")) {
			throw new UpdatePropertyException("CAN_NOT_UPDATE_PROPERTY_IN_REPOSITORY",
					WIMMessageHelper.generateMsgParms("principalName", this.getRepositoryId()), CLASSNAME,
					"updateByDataGraph");
		} else {
			ArrayList var6 = new ArrayList(1);
			var6.add(var5);
			DataObject var7 = var4.getDataObject("identifier");
			LdapEntry var8 = this.iLdapConn.getEntityByIdentifier(var7, var6, (List) null, false, false);
			String var9 = var8.getDN();
			String var10 = var8.getExtId();
			String var11 = var8.getUniqueName();
			String var12 = var8.getType();
			LdapEntity var13 = this.iLdapConfigMgr.getLdapEntity(var12);
			Map var14 = ControlsHelper.getControlMap(var1);
			DataObject var15 = (DataObject) var14.get("GroupMemberControl");
			DataObject var16 = (DataObject) var14.get("GroupMembershipControl");
			EClass var17 = this.iSchemaMgr.getEClass(var4.getType());
			EList var18 = var17.getEAllStructuralFeatures();
			ArrayList var19 = new ArrayList();
			List var20 = null;
			List var21 = null;
			String[] var22 = LdapHelper.getRDNAttributes(var9);
			String[] var23 = null;

			for (int var24 = 0; var24 < var18.size(); ++var24) {
				EStructuralFeature var25 = (EStructuralFeature) var18.get(var24);
				Property var26 = this.iSchemaMgr.getProperty(var25);
				String var27 = this.iSchemaMgr.getQualifiedPropertyName(var25);
				if (var4.isSet(var26)) {
					if (!this.iLdapConfigMgr.isPersistentProperty(var27)) {
						if ("members".equals(var27)) {
							var21 = var4.getList(var26);
						} else if ("groups".equals(var27)) {
							var20 = var4.getList(var26);
						}
					} else {
						Set var28 = this.getAttribute(var4, (Object) null, var26, var27, var13);
						Iterator var29 = var28.iterator();

						while (var29.hasNext()) {
							Attribute var30 = (Attribute) var29.next();
							boolean var31 = false;

							for (int var32 = 0; var32 < var22.length; ++var32) {
								if (var30.getID().equalsIgnoreCase(var22[var32])) {
									if (var23 == null) {
										var23 = new String[var22.length];
									}

									try {
										var23[var32] = (String) var30.get();
									} catch (NamingException var34) {
										throw new WIMSystemException("NAMING_EXCEPTION",
												WIMMessageHelper.generateMsgParms(var34.toString(true)), Level.SEVERE,
												CLASSNAME, "updateByDataGraph");
									}

									var31 = true;
								}
							}

							if (!var31) {
								var19.add(new ModificationItem(2, var30));
							}
						}
					}
				}
			}

			boolean var39 = false;
			int var40 = 1;
			String var41;
			int var45;
			if (var21 != null && var21.size() > 0) {
				if (!this.iLdapConfigMgr.isGroup(var12)) {
					throw new InvalidEntityTypeException("ENTITY_IS_NOT_A_GROUP",
							WIMMessageHelper.generateMsgParms(var8.getUniqueName()), Level.SEVERE, CLASSNAME,
							"updateByDataGraph");
				}

				var41 = this.iLdapConfigMgr.getMemberAttribute(var8.getAttributes().get("objectClass"));
				BasicAttribute var43 = new BasicAttribute(var41);
				if (var15 != null) {
					var40 = var15.getInt("modifyMode");
				}

				for (var45 = 0; var45 < var21.size(); ++var45) {
					DataObject var47 = ((DataObject) var21.get(var45)).getDataObject("identifier");
					LdapEntry var48 = this.iLdapConn.getEntityByIdentifier(var47, (List) null, (List) null, false,
							false);
					String var49 = var48.getDN();
					this.iLdapConn.invalidateAttributes(var49, var48.getExtId(), var48.getUniqueName());
					var43.add(var49);
				}

				if (3 == var40) {
					var19.add(new ModificationItem(3, var43));
				} else if (2 == var40) {
					var19.add(new ModificationItem(2, var43));
				} else {
					var19.add(new ModificationItem(1, var43));
				}

				var39 = true;
			}

			if (var19.size() > 0) {
				ModificationItem[] var42 = new ModificationItem[0];
				var42 = (ModificationItem[]) ((ModificationItem[]) var19.toArray(var42));

				try {
					this.iLdapConn.modifyAttributes(var9, var42);
				} catch (AttributeInUseException var35) {
					if (!var39 || 1 != var40) {
						throw new WIMSystemException("NAMING_EXCEPTION",
								WIMMessageHelper.generateMsgParms(var35.toString(true)), Level.SEVERE, CLASSNAME,
								"updateByDataGraph");
					}

					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "updateByDataGraph",
								"Entity  is already a member of group " + var9 + ":" + var35.toString(true));
					}
				} catch (NoSuchAttributeException var36) {
					if (!var39 || 3 != var40) {
						throw new WIMSystemException("NAMING_EXCEPTION",
								WIMMessageHelper.generateMsgParms(var36.toString(true)), Level.SEVERE, CLASSNAME,
								"updateByDataGraph");
					}

					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "updateByDataGraph",
								"Entity  is already not a member of group " + var9 + ":" + var36.toString(true));
					}
				} catch (OperationNotSupportedException var37) {
					if (!var39 || 3 != var40) {
						throw new WIMSystemException("NAMING_EXCEPTION",
								WIMMessageHelper.generateMsgParms(var37.toString(true)), Level.SEVERE, CLASSNAME,
								"updateByDataGraph");
					}

					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "updateByDataGraph",
								"Entity  is already not a member of group " + var9 + ":" + var37.toString(true));
					}
				} catch (NamingException var38) {
					throw new WIMSystemException("NAMING_EXCEPTION",
							WIMMessageHelper.generateMsgParms(var38.toString(true)), CLASSNAME, "updateByDataGraph");
				}
			}

			var41 = null;
			boolean var44 = false;
			if (var23 != null) {
				var41 = LdapHelper.replaceRDN(var9, var22, var23);
				if (!var41.equalsIgnoreCase(var9)) {
					this.iLdapConn.rename(var9, var41);
					this.updateGroupMember(var9, var41);
					ArrayList var46 = new ArrayList(1);
					var46.add(var12);
					var8 = this.iLdapConn.getEntityByIdentifier(var41, (String) null, (String) null, var46, (List) null,
							false, false);
					var44 = true;
				}
			}

			if (var20 != null) {
				var45 = 1;
				if (var16 != null) {
					var45 = var16.getInt("modifyMode");
				}

				this.updateGroups(var44 ? var41 : var9, var20, var45);
			}

			this.iLdapConn.invalidateAttributes(var9, var10, var11);
			this.iLdapConn.invalidateNamesCache();
			this.createEntityFromLdapEntry(var3, "entities", var8, (List) null);
			return var3;
		}
	}

	public DataObject update(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI update", WIMTraceHelper.printDataGraph(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.getRepositoryId(), CLASSNAME, "update");
		Map var3 = ControlsHelper.getControlMap(var1);
		DataObject var4 = (DataObject) var3.get("CacheControl");
		if (var4 != null) {
			String var12 = var4.getString("mode");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "update", "Cache Control is passed with mode " + var12);
			}

			if (var12 != null && "clearAll".equalsIgnoreCase(var12)) {
				this.iLdapConn.invalidateAttributeCache();
				this.iLdapConn.invalidateNamesCache();
				String var13 = this.getCallerUniqueName();
				msgLogger.logp(Level.WARNING, CLASSNAME, "update", "CLEAR_ALL_CLEAR_CACHE_MODE",
						WIMMessageHelper.generateMsgParms(this.getRepositoryId(), var12, var13));
			} else if (var12 != null && "clearEntity".equalsIgnoreCase(var12)) {
				DataObject var11 = (DataObject) var1.getList("entities").get(0);
				DataObject var14 = var11.getDataObject("identifier");
				String var8 = var14.getString("externalName");
				String var9 = var14.getString("externalId");
				String var10 = var14.getString("uniqueName");
				this.iLdapConn.invalidateAttributes(var8, var9, var10);
				this.iLdapConn.invalidateNamesCache();
			} else {
				msgLogger.logp(Level.WARNING, CLASSNAME, "update", "UNKNOWN_CLEAR_CACHE_MODE",
						WIMMessageHelper.generateMsgParms(this.getRepositoryId(), var12));
			}

			return null;
		} else {
			DataObject var5 = null;
			ChangeSummary var6 = var1.getDataGraph().getChangeSummary();
			List var7 = var6.getChangedDataObjects();
			if (var7.size() > 0) {
				var5 = this.updateByChangeSummary(var1, var7);
			} else {
				var5 = this.updateByDataGraph(var1);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "WIM_SPI update", WIMTraceHelper.printDataGraph(var5));
			}

			return var5;
		}
	}

	private DataObject createIdentiferFromLdapEntry(LdapEntry var1) throws WIMException {
		DataObject var2 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "IdentifierType");
		var2.setString("uniqueName", var1.getUniqueName());
		var2.setString("externalId", var1.getExtId());
		var2.setString("externalName", var1.getDN());
		var2.setString("repositoryId", this.getRepositoryId());
		return var2;
	}

	private DataObject createEntityFromLdapEntry(DataObject var1, String var2, LdapEntry var3, List var4)
			throws WIMException {
		String var5 = var3.getType();
		DataObject var6 = null;
		if (var5 != null) {
			var6 = this.iSchemaMgr.createDataObject(var1, var2, var5);
		} else {
			var6 = var1.createDataObject(var2);
		}

		DataObject var7 = var6.createDataObject("identifier");
		var7.setString("uniqueName", var3.getUniqueName());
		var7.setString("externalId", var3.getExtId());
		var7.setString("externalName", var3.getDN());
		var7.setString("repositoryId", this.getRepositoryId());
		String var8 = var3.getChangeType();
		if (var8 != null) {
			var6.setString("changeType", var8);
			if (!"delete".equals(var8)) {
				this.populateEntity(var6, var4, var3.getAttributes());
			}
		} else {
			this.populateEntity(var6, var4, var3.getAttributes());
		}

		return var6;
	}

	public DataObject get(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI get", WIMTraceHelper.printDataGraph(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.getRepositoryId(), CLASSNAME, "get");
		DataObject var3 = this.iSchemaMgr.createRootDataObject();
		Map var4 = ControlsHelper.getControlMap(var1);
		DataObject var5 = (DataObject) var4.get("PropertyControl");
		DataObject var6 = (DataObject) var4.get("GroupMembershipControl");
		DataObject var7 = (DataObject) var4.get("GroupMemberControl");
		DataObject var8 = (DataObject) var4.get("AncestorControl");
		DataObject var9 = (DataObject) var4.get("DescendantControl");
		DataObject var10 = (DataObject) var4.get("CheckGroupMembershipControl");
		DataObject var11 = (DataObject) var4.get("CacheControl");
		boolean var12 = false;
		if (var11 != null) {
			String var13 = var11.getString("mode");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "get", "Cache Control is passed with mode " + var13);
			}

			if (var13 != null && "clearAll".equalsIgnoreCase(var13)) {
				this.iLdapConn.invalidateAttributeCache();
				this.iLdapConn.invalidateNamesCache();
				String var29 = this.getCallerUniqueName();
				msgLogger.logp(Level.WARNING, CLASSNAME, "get", "CLEAR_ALL_CLEAR_CACHE_MODE",
						WIMMessageHelper.generateMsgParms(this.getRepositoryId(), var13, var29));
			} else if (var13 != null && "clearEntity".equalsIgnoreCase(var13)) {
				List var14 = var1.getList("entities");

				for (int var15 = 0; var15 < var14.size(); ++var15) {
					DataObject var16 = (DataObject) var14.get(var15);
					String var17 = this.iSchemaMgr.getQualifiedTypeName(var16.getType());
					DataObject var18 = var16.getDataObject("identifier");
					String var19 = var18.getString("externalName");
					String var20 = var18.getString("externalId");
					String var21 = var18.getString("uniqueName");
					this.iLdapConn.invalidateAttributes(var19, var20, var21);
				}

				var12 = true;
			} else {
				msgLogger.logp(Level.WARNING, CLASSNAME, "get", "UNKNOWN_CLEAR_CACHE_MODE",
						WIMMessageHelper.generateMsgParms(this.getRepositoryId(), var13));
			}
		}

		List var28 = null;
		if (var5 != null) {
			var28 = var5.getList("properties");
		}

		boolean var30 = false;
		if (var7 != null
				&& (this.iLdapConfigMgr.getMembershipAttribute() == null || !this.iLdapConfigMgr.isDefaultMbrAttr())) {
			var30 = true;
		}

		List var31 = var1.getList("entities");

		for (int var32 = 0; var32 < var31.size(); ++var32) {
			DataObject var33 = (DataObject) var31.get(var32);
			String var34 = this.iSchemaMgr.getQualifiedTypeName(var33.getType());
			List var35 = this.iLdapConfigMgr.getSupportedProperties(var34, var28);
			ArrayList var36 = new ArrayList(1);
			var36.add(var34);
			DataObject var37 = var33.getDataObject("identifier");
			LdapEntry var22 = this.iLdapConn.getEntityByIdentifier(var37, var36, var35, var6 != null || var10 != null,
					var30);
			DataObject var23 = this.createEntityFromLdapEntry(var3, "entities", var22, var35);
			if (var12) {
				if (this.iLdapConfigMgr.isGroup(var22.getType())) {
					if (var7 != null) {
						this.iLdapConn.invalidateNamesCache();
					}

					if (var6 != null || var10 != null) {
						this.iLdapConn.invalidateNamesCache();
					}
				} else if ((this.iLdapConfigMgr.isPerson(var22.getType())
						|| this.iLdapConfigMgr.isPersonAccount(var22.getType())) && (var6 != null || var10 != null)) {
					if (this.iLdapConfigMgr.getMembershipAttribute() != null) {
						String var24 = this.iLdapConfigMgr.getMembershipAttribute();
						Attribute var25 = var22.getAttributes().get(var24);

						try {
							if (var25 == null || var25 != null && var25.size() == 1 && var25.get(0) == null) {
								this.iLdapConn.invalidateNamesCache();
							}

							if (this.iLdapConfigMgr.getMembershipAttributeScope() != 2
									&& this.iLdapConfigMgr.supportDynamicGroup()) {
								this.iLdapConn.invalidateNamesCache();
							}
						} catch (NamingException var27) {
							this.iLdapConn.invalidateNamesCache();
						}
					} else {
						this.iLdapConn.invalidateNamesCache();
					}
				}
			}

			this.getGroups(var23, var22, var6);
			if (this.iLdapConfigMgr.isGroup(var22.getType())) {
				this.getMembers(var23, var22, var7);
			}

			this.getDescendants(var23, var22, var9);
			this.getAncestors(var23, var22, var8);
			if (var10 != null) {
				int var38 = var10.getInt("level");
				DataObject var39 = var3.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"CheckGroupMembershipControl");
				var39.setBoolean("inGroup", this.isMemberInGroup(var33, var22, var38));
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI get", WIMTraceHelper.printDataGraph(var3));
		}

		return var3;
	}

	private boolean getGroupsByMembership(DataObject var1, LdapEntry var2, String[] var3, int var4, List var5,
			String var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getGroupsByMembership",
					WIMMessageHelper.generateMsgParms(WIMTraceHelper.printDataObject(var1), var2,
							WIMTraceHelper.printObjectArray(var3), new Integer(var4), var5, var6));
		}

		boolean var8 = var4 == 0 && this.iLdapConfigMgr.getMembershipAttributeScope() == 0;
		boolean var9 = false;
		List var10 = this.iLdapConfigMgr.getSupportedProperties("Group", var5);
		String var11 = this.iLdapConfigMgr.getMembershipAttribute();
		Attribute var12 = var2.getAttributes().get(var11);

		try {
			if (var12 == null || var12 != null && var12.size() == 1 && var12.get(0) == null) {
				if (this.iLdapConfigMgr.getLdapType().startsWith("IDS") && var11 != null
						&& var11.equalsIgnoreCase("ibm-allGroups")) {
					var9 = false;
				} else {
					var9 = this.getGroupsByMember(var1, var2, var3, var4, var10, var6);
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "getGroupsByMembership", var9);
				}

				return var9;
			}

			if (var12.size() == 0) {
				var9 = false;
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "getGroupsByMembership", var9);
				}

				return var9;
			}

			HashMap var13 = null;
			if (var8) {
				var13 = new HashMap();
			}

			HashSet var14 = new HashSet();
			List var15 = this.iLdapConfigMgr.getGroupTypes();
			NamingEnumeration var16 = var12.getAll();

			while (var16.hasMoreElements()) {
				String var17 = (String) var16.nextElement();
				if (var6 != null && var6.equalsIgnoreCase(var17)) {
					var9 = true;
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "getGroupsByMembership", var9);
					}

					return var9;
				}

				if (LdapHelper.isUnderBases(var17, var3)) {
					LdapEntry var18 = null;

					try {
						var18 = this.iLdapConn.getEntityByIdentifier(var17, (String) null, (String) null, var15, var10,
								var8, false);
					} catch (EntityNotFoundException var30) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME, "getGroupsByMembership",
									"Group " + var17 + " is not found and ingored.");
						}
						continue;
					}

					if (!this.iLdapConfigMgr.isGroup(var18.getType())) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME, "getGroupsByMembership",
									"Ldap entry " + var17 + " is not a Group.");
						}
					} else {
						if (var1 != null) {
							this.createEntityFromLdapEntry(var1, "groups", var18, var10);
						}

						if (var8) {
							String var19 = var17.toLowerCase();
							var13.put(var19, var18.getAttributes().get(var11));
							var14.add(var19);
						}
					}
				}
			}

			Map var32 = null;
			HashMap var33 = null;
			boolean var34 = this.iLdapConfigMgr.getMembershipAttributeScope() != 2
					&& this.iLdapConfigMgr.supportDynamicGroup();
			String var22;
			if (var34) {
				var32 = this.iLdapConn.getDynamicGroups(var3, var10, true);
				var33 = new HashMap(var32.size());
				Iterator var20 = var32.keySet().iterator();

				label275 : while (true) {
					String var21;
					LdapEntry var23;
					LdapURL[] var26;
					do {
						do {
							do {
								Attribute var25;
								do {
									if (!var20.hasNext()) {
										break label275;
									}

									var21 = (String) var20.next();
									var22 = var21.toLowerCase();
									var23 = (LdapEntry) var32.get(var21);
									Attributes var24 = var23.getAttributes();
									var25 = var24.get(
											this.iLdapConfigMgr.getDynamicMemberAttribute(var24.get("objectClass")));
								} while (var25 == null);

								var26 = LdapHelper.getLdapURLs(var25);
							} while (var26 == null);
						} while (var26.length <= 0);

						var33.put(var21, var26);
					} while (var13 != null && (var13 == null || var13.containsKey(var22)));

					if (this.iLdapConn.isMemberInURLQuery(var26, var2.getDN())) {
						if (var6 != null && var6.equalsIgnoreCase(var21)) {
							var9 = true;
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.exiting(CLASSNAME, "getGroupsByMembership", new Boolean(var9));
							}

							return var9;
						}

						if (var1 != null) {
							this.createEntityFromLdapEntry(var1, "groups", var23, var10);
						}

						if (var8) {
							var13.put(var22, var23.getAttributes().get(var11));
							var14.add(var22);
						}
					}
				}
			}

			if (!var8 && var6 != null) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "getGroupsByMembership", new Boolean(var9));
				}

				return var9;
			}

			label249 : while (var14.size() > 0) {
				HashSet var35 = new HashSet();
				Iterator var36 = var14.iterator();

				while (true) {
					LdapEntry var27;
					String var40;
					String var41;
					label240 : do {
						if (!var36.hasNext()) {
							var14 = var35;
							continue label249;
						}

						var22 = (String) var36.next();
						Attribute var37 = (Attribute) var13.get(var22.toLowerCase());
						if (var37 != null) {
							NamingEnumeration var38 = var37.getAll();

							while (true) {
								do {
									do {
										do {
											if (!var38.hasMoreElements()) {
												continue label240;
											}

											var40 = (String) var38.nextElement();
										} while (var40 == null);

										if (var6 != null && var6.equalsIgnoreCase(var40)) {
											var9 = true;
											if (trcLogger.isLoggable(Level.FINER)) {
												trcLogger.exiting(CLASSNAME, "getGroupsByMembership",
														new Boolean(var9));
											}

											return var9;
										}
									} while (!LdapHelper.isUnderBases(var40, var3));

									var41 = var40.toLowerCase();
								} while (var13.containsKey(var41));

								var27 = null;

								try {
									var27 = this.iLdapConn.getEntityByIdentifier(var40, (String) null, (String) null,
											var15, var10, var8, false);
								} catch (EntityNotFoundException var29) {
									if (trcLogger.isLoggable(Level.FINE)) {
										trcLogger.logp(Level.FINE, CLASSNAME, "getGroupsByMembership",
												"Group " + var40 + " is not found and ingored.");
									}
									continue;
								}

								if (!this.iLdapConfigMgr.isGroup(var27.getType())) {
									if (trcLogger.isLoggable(Level.FINE)) {
										trcLogger.logp(Level.FINE, CLASSNAME, "getGroupsByMembership",
												"Ldap entry " + var40 + " is not a Group.");
									}
								} else {
									if (var1 != null) {
										this.createEntityFromLdapEntry(var1, "groups", var27, var10);
									}

									if (var8) {
										var13.put(var41, var27.getAttributes().get(var11));
										if (!var14.contains(var41)) {
											var35.add(var41);
										}
									}
								}
							}
						}
					} while (!var34);

					Iterator var39 = var33.keySet().iterator();

					while (var39.hasNext()) {
						var40 = (String) var39.next();
						var41 = var40.toLowerCase();
						if (!var13.containsKey(var41) && this.iLdapConn
								.isMemberInURLQuery((LdapURL[]) ((LdapURL[]) var33.get(var40)), var22)) {
							if (var6 != null && var6.equalsIgnoreCase(var40)) {
								var9 = true;
								if (trcLogger.isLoggable(Level.FINER)) {
									trcLogger.exiting(CLASSNAME, "getGroupsByMembership", new Boolean(var9));
								}

								return var9;
							}

							var27 = (LdapEntry) var32.get(var40);
							if (var1 != null) {
								this.createEntityFromLdapEntry(var1, "groups", var27, var10);
							}

							var13.put(var41, var27.getAttributes().get(var11));
							if (!var14.contains(var41)) {
								var35.add(var41);
							}
						}
					}
				}
			}
		} catch (NamingException var31) {
			trcLogger.logp(Level.FINE, CLASSNAME, "getGroupsByMembership", var31.toString(true));
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var31.toString(true)),
					CLASSNAME, "getGroupsByMembership");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getGroupsByMembership", new Boolean(var9));
		}

		return var9;
	}

	private boolean getGroupsByMember(DataObject var1, LdapEntry var2, String[] var3, int var4, List var5, String var6)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getGroupsByMember",
					WIMMessageHelper.generateMsgParms(WIMTraceHelper.printDataObject(var1), var2,
							WIMTraceHelper.printObjectArray(var3), new Integer(var4), var5, var6));
		}

		boolean var8 = false;
		if ("ldapLoginGroupFilter" == var6) {
			var8 = true;
			var6 = null;
		}

		boolean var9 = var4 == 0 && !this.iLdapConfigMgr.isMemberAttributesNestedScope();
		boolean var10 = false;
		String var11 = this.iLdapConfigMgr.getGroupMemberFilter(var2.getDN());
		List var12 = this.iLdapConfigMgr.getGroupTypes();
		if (var8 && this.iLdapConfigMgr.getLdaploginGroupFilter() != null) {
			var11 = "(&" + this.iLdapConfigMgr.getLdaploginGroupFilter() + var11 + ")";
		}

		HashSet var13 = new HashSet();
		HashSet var14 = new HashSet();
		List var15 = this.iLdapConfigMgr.getSupportedProperties("Group", var5);
		int var16 = 0;

		Iterator var19;
		String var21;
		for (int var17 = var3.length; var16 < var17; ++var16) {
			Set var18 = this.iLdapConn.searchEntities(var3[var16], var11, (Object[]) null, 2, var12, var15, false,
					false);
			var19 = var18.iterator();

			while (var19.hasNext()) {
				LdapEntry var20 = (LdapEntry) var19.next();
				if (var1 != null) {
					this.createEntityFromLdapEntry(var1, "groups", var20, var15);
				}

				var21 = var20.getDN();
				if (var6 != null && var6.equalsIgnoreCase(var21)) {
					var10 = true;
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "getGroupsByMember", var10);
					}

					return var10;
				}

				if (var9) {
					String var22 = var21.toLowerCase();
					var13.add(var22);
					var14.add(var22);
				}
			}
		}

		Map var29 = null;
		HashMap var30 = null;
		boolean var31 = !this.iLdapConfigMgr.isMemberAttributesAllScope() && this.iLdapConfigMgr.supportDynamicGroup();
		if (var31) {
			var29 = this.iLdapConn.getDynamicGroups(var3, var15, false);
			var30 = new HashMap(var29.size());
			var19 = var29.keySet().iterator();

			while (var19.hasNext()) {
				String var33 = (String) var19.next();
				var21 = var33.toLowerCase();
				LdapEntry var35 = (LdapEntry) var29.get(var33);
				Attributes var23 = var35.getAttributes();
				Attribute var24 = var23.get(this.iLdapConfigMgr.getDynamicMemberAttribute(var23.get("objectClass")));
				if (var24 != null) {
					LdapURL[] var25 = LdapHelper.getLdapURLs(var24);
					if (var25 != null && var25.length > 0) {
						var30.put(var33, var25);
						if (!var14.contains(var21) && this.iLdapConn.isMemberInURLQuery(var25, var2.getDN())) {
							if (var6 != null && var6.equalsIgnoreCase(var33)) {
								var10 = true;
								if (trcLogger.isLoggable(Level.FINER)) {
									trcLogger.exiting(CLASSNAME, "getGroupsByMember", new Boolean(var10));
								}

								return var10;
							}

							if (var1 != null) {
								this.createEntityFromLdapEntry(var1, "groups", var35, var15);
							}

							if (var9) {
								var13.add(var21);
								var14.add(var21);
							}
						}
					}
				}
			}
		}

		if (!var9 && var6 != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getGroupsByMember", new Boolean(var10));
			}

			return var10;
		} else {
			HashSet var32;
			label175 : for (; var13.size() > 0; var13 = var32) {
				var32 = new HashSet();
				Iterator var34 = var13.iterator();

				while (true) {
					do {
						if (!var34.hasNext()) {
							continue label175;
						}

						var21 = (String) var34.next();
						var11 = this.iLdapConfigMgr.getGroupMemberFilter(var21);
						int var36 = 0;

						for (int var37 = var3.length; var36 < var37; ++var36) {
							Set var40 = this.iLdapConn.searchEntities(var3[var36], var11, (Object[]) null, 2, var12,
									var15, false, false);
							Iterator var42 = var40.iterator();

							while (var42.hasNext()) {
								LdapEntry var26 = (LdapEntry) var42.next();
								String var27 = var26.getDN();
								if (var6 != null && var6.equalsIgnoreCase(var27)) {
									var10 = true;
									if (trcLogger.isLoggable(Level.FINER)) {
										trcLogger.exiting(CLASSNAME, "getGroupsByMember", new Boolean(var10));
									}

									return var10;
								}

								String var28 = var27.toLowerCase();
								if (!var14.contains(var28)) {
									if (var1 != null) {
										this.createEntityFromLdapEntry(var1, "groups", var26, var15);
									}

									var14.add(var28);
									if (!var13.contains(var28)) {
										var32.add(var28);
									}
								}
							}
						}
					} while (!var31);

					Iterator var38 = var30.keySet().iterator();

					while (var38.hasNext()) {
						String var39 = (String) var38.next();
						String var41 = var39.toLowerCase();
						if (!var14.contains(var41) && this.iLdapConn
								.isMemberInURLQuery((LdapURL[]) ((LdapURL[]) var30.get(var39)), var21)) {
							LdapEntry var43 = (LdapEntry) var29.get(var39);
							if (var6 != null && var6.equalsIgnoreCase(var39)) {
								var10 = true;
								if (trcLogger.isLoggable(Level.FINER)) {
									trcLogger.exiting(CLASSNAME, "getGroupsByMember", new Boolean(var10));
								}

								return var10;
							}

							if (var1 != null) {
								this.createEntityFromLdapEntry(var1, "groups", var43, var15);
							}

							var14.add(var41);
							if (!var13.contains(var41)) {
								var32.add(var41);
							}
						}
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getGroupsByMember", new Boolean(var10));
			}

			return var10;
		}
	}

	private boolean isMemberInGroup(DataObject var1, LdapEntry var2, int var3) throws WIMException {
		List var5 = var1.getList("groups");
		LdapEntry var6 = null;
		String var7 = null;
		if (var5.size() > 0) {
			var6 = var2;
			DataObject var8 = (DataObject) var5.get(0);
			LdapEntry var9 = this.iLdapConn.getEntityByIdentifier(var8.getDataObject("identifier"), (List) null,
					(List) null, false, false);
			if (!this.iLdapConfigMgr.isGroup(var9.getType())) {
				throw new InvalidEntityTypeException("ENTITY_IS_NOT_A_GROUP",
						WIMMessageHelper.generateMsgParms(var9.getUniqueName()), Level.SEVERE, CLASSNAME,
						"isMemberInGroup");
			}

			var7 = var9.getDN();
		} else {
			if (!this.iLdapConfigMgr.isGroup(var2.getType())) {
				return false;
			}

			List var10 = var1.getList("members");
			if (var10.size() <= 0) {
				return false;
			}

			DataObject var12 = (DataObject) var10.get(0);
			var6 = this.iLdapConn.getEntityByIdentifier(var12.getDataObject("identifier"), (List) null, (List) null,
					true, false);
			var7 = var2.getDN();
		}

		String[] var11 = this.iLdapConfigMgr.getGroupSearchBases();
		return this.iLdapConfigMgr.getMembershipAttribute() != null
				? this.getGroupsByMembership((DataObject) null, var6, var11, var3, (List) null, var7)
				: this.getGroupsByMember((DataObject) null, var6, var11, var3, (List) null, var7);
	}

	private void getGroups(DataObject var1, LdapEntry var2, DataObject var3) throws WIMException {
		if (var3 != null) {
			int var4 = var3.getInt("level");
			List var5 = var3.getList("properties");
			String[] var6 = null;
			String var7 = null;
			List var8 = var3.getList("searchBases");
			List var9 = var3.getList("contextProperties");
			if (var9 != null && var9.size() > 0) {
				var7 = ((DataObject) var9.get(0)).getString("value");
			} else {
				trcLogger.logp(Level.FINE, CLASSNAME, "getGroups", "No context set for Group search filter");
			}

			int var10 = var8.size();
			String[] var11 = this.iLdapConfigMgr.getGroupSearchBases();
			if (var10 == 0) {
				var6 = var11;
			} else {
				ArrayList var12 = new ArrayList(var10);

				for (int var13 = 0; var13 < var10; ++var13) {
					String var14 = (String) var8.get(var13);
					String var15 = this.getDN(var14, (String) null, (Attributes) null, true, false);
					var12.add(var15);
				}

				var6 = (String[]) ((String[]) var12.toArray(new String[0]));
			}

			var6 = NodeHelper.getTopNodes(var6);
			if (this.iLdapConfigMgr.getMembershipAttribute() != null
					&& this.iLdapConfigMgr.getLdaploginGroupFilter() == null) {
				this.getGroupsByMembership(var1, var2, var6, var4, var5, (String) null);
			} else {
				this.getGroupsByMember(var1, var2, var6, var4, var5, var7);
			}

		}
	}

	private LdapSearchControl getLdapSearchControl(DataObject var1, boolean var2, boolean var3) throws WIMException {
		List var5 = var1.getList("properties");
		int var6 = var1.getInt("countLimit");
		int var7 = var1.getInt("timeLimit");
		boolean var8 = var1.getBoolean("returnSubType");
		String var9 = var1.getString("expression");
		HashSet var10 = new HashSet();
		ArrayList var11 = null;
		String var12 = null;
		boolean var13 = false;
		String var14 = null;
		if (var9 != null && var9.trim().length() > 0) {
			WIMXPathInterpreter var24 = new WIMXPathInterpreter(new StringReader(var9));

			try {
				XPathNode var27 = var24.parse((MetadataMapper) null);
				List var17 = var24.getEntityTypes();
				String var19;
				if (var8) {
					for (int var18 = 0; var18 < var17.size(); ++var18) {
						var19 = (String) var17.get(var18);
						var10.add(var19);
						List var20 = this.iLdapConfigMgr.getLdapSubEntityTypes(var19);
						var10.addAll(var20);
					}
				} else {
					var10.addAll(var17);
				}

				var11 = new ArrayList(var10);
				if (var27 != null) {
					HashMap var29 = new HashMap();
					Iterator var31 = var27.getPropertyNodes(var29);

					while (var31.hasNext()) {
						PropertyNode var32 = (PropertyNode) var31.next();
						String var21 = var32.getName();
						if (var21.equals("principalName")) {
							if (var29.size() > 1) {
								throw new SearchControlException("CANNOT_SEARCH_PRINCIPAL_NAME_WITH_OTHER_PROPS",
										CLASSNAME, "getLdapSearchControl");
							}

							var13 = true;
							break;
						}
					}
				}

				if (var13) {
					if (var27.getNodeType() != 0) {
						throw new SearchControlException("CANNOT_SEARCH_PRINCIPAL_NAME_WITH_OTHER_PROPS", CLASSNAME,
								"getLdapSearchControl");
					}

					PropertyNode var30 = (PropertyNode) var27;
					var19 = (String) var30.getValue();
					String var33 = UniqueNameHelper.getValidUniqueName(var19);
					if (var33 != null && !var3) {
						var14 = this.getDN(var33, "PersonAccount", (Attributes) null, true, false);
					} else {
						var12 = this.getPrincipalNameFilter(var19);
					}
				} else {
					var12 = this.getSearchFilter(var10, var27);
				}
			} catch (ParseException var22) {
				throw new SearchControlException("INVALID_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var9),
						CLASSNAME, "getLdapSearchControl", var22);
			} catch (TokenMgrError var23) {
				throw new SearchControlException("INVALID_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var9),
						CLASSNAME, "getLdapSearchControl", var23);
			}
		} else {
			LdapEntity[] var15 = this.iLdapConfigMgr.getLdapEntities();

			for (int var16 = 0; var16 < var15.length; ++var16) {
				var10.add(var15[var16].getName());
			}
		}

		if (var12 != null) {
			var12 = "(&" + this.iLdapConfigMgr.getEntityTypesFilter(var10) + var12 + ")";
		} else {
			var12 = this.iLdapConfigMgr.getEntityTypesFilter(var10);
		}

		if (var11 != null && var11.size() > 0) {
			boolean var25 = this.isEntitySearchBaseConfigured(var11);
			if (var25 && !var2) {
				trcLogger.logp(Level.FINE, CLASSNAME, "getLdapSearchControl",
						"Entity search base is configured, so realm search base will be ignored");
				var1.getList("searchBases").clear();
				trcLogger.logp(Level.FINE, CLASSNAME, "getLdapSearchControl",
						"Search base has been changed to entity search base");
			}
		}

		if (var2) {
			trcLogger.logp(Level.FINE, CLASSNAME, "getLdapSearchControl",
					"Search base explicitly set by client, so configured search bases will be ignored");
		}

		String[] var26 = this.getBases(var1, var11);
		if (var14 != null) {
			if (!LdapHelper.isUnderBases(var14, var26)) {
				var26 = new String[0];
			} else {
				var26 = new String[]{var14};
			}
		}

		LdapSearchControl var28 = new LdapSearchControl(var26, var11, var12, var5, var6, var7);
		if (var14 != null) {
			var28.setScope(0);
		}

		return var28;
	}

	private String getSearchFilter(Set var1, XPathNode var2) throws WIMException {
		String var4 = null;
		StringBuffer var5 = new StringBuffer();
		Object var6 = null;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getSearchFilter",
					WIMMessageHelper.generateMsgParms(var1, WIMTraceHelper.printObjectArray(new Object[]{var2})));
		}

		if (var2 != null) {
			LdapXPathTranslateHelper var7 = new LdapXPathTranslateHelper(var1, this.iLdapConfigMgr);
			var7.genSearchString(var5, var2);
			if (var5.length() > 0 && (var5.charAt(0) != '(' || var5.charAt(var5.length() - 1) != ')')) {
				var5.insert(0, '(');
				var5.append(')');
			}

			var4 = var5.toString();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getSearchFilter", WIMTraceHelper.printObjectArray(new Object[]{var4}));
			}
		}

		return var4;
	}

	private void getMembers(DataObject var1, LdapEntry var2, DataObject var3) throws WIMException {
		if (var3 != null) {
			int var5 = var3.getInt("level");
			List var6 = var3.getList("properties");
			List var7 = this.getEntityTypes(var3);
			String[] var8 = this.getBases(var3, var7);
			if (!this.iLdapConfigMgr.isDefaultMbrAttr()) {
				this.getMembersByMember(var1, var2, var8, var5, var6, var7);
			} else if (this.iLdapConfigMgr.getMembershipAttribute() != null) {
				this.getMembersByMembership(var1, var2, var8, var5, var6, var7);
			} else {
				this.getMembersByMember(var1, var2, var8, var5, var6, var7);
			}

		}
	}

	private boolean isEntitySearchBaseConfigured(List var1) {
		boolean var2 = false;
		if (var1 != null) {
			for (int var3 = 0; var3 < var1.size(); ++var3) {
				LdapEntity var4 = this.iLdapConfigMgr.getLdapEntity((String) var1.get(var3));
				if (var4 != null && var4.isSearchBaseConfigured()) {
					var2 = true;
					trcLogger.logp(Level.FINEST, CLASSNAME, "isEntitySearchBaseConfigured",
							"Search base is explicitly configured for " + var1.get(var3) + ": "
									+ var4.getSearchBaseList());
				}
			}
		}

		return var2;
	}

	private String[] getBases(DataObject var1, List var2) throws WIMException {
		String[] var3 = null;
		List var4 = var1.getList("searchBases");
		int var5 = var4.size();
		int var7;
		if (var5 > 0) {
			var3 = (String[]) ((String[]) var4.toArray(new String[0]));
			var3 = NodeHelper.getTopNodes(var3);
			boolean var6 = true;

			for (var7 = 0; var7 < var3.length; ++var7) {
				String var8 = var3[var7];
				String var9 = this.getDN(var8, (String) null, (Attributes) null, true, false);
				var3[var7] = var9;
				var3 = NodeHelper.getTopNodes(var3);
			}
		} else {
			ArrayList var10 = new ArrayList();
			if (var2 == null) {
				var3 = this.iLdapConfigMgr.getTopLdapNodes();
			} else {
				for (var7 = 0; var7 < var2.size(); ++var7) {
					LdapEntity var11 = this.iLdapConfigMgr.getLdapEntity((String) var2.get(var7));
					if (var11 == null) {
						var3 = this.iLdapConfigMgr.getTopLdapNodes();
						break;
					}

					var10.addAll(var11.getSearchBaseList());
				}

				if (var3 == null) {
					var3 = (String[]) ((String[]) var10.toArray(new String[0]));
					var3 = NodeHelper.getTopNodes(var3);
				}
			}
		}

		return var3;
	}

	private void getMembersByMembership(DataObject var1, LdapEntry var2, String[] var3, int var4, List var5, List var6)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getMembersByMembership",
					WIMMessageHelper.generateMsgParms(WIMTraceHelper.printDataObject(var1), var2,
							WIMTraceHelper.printObjectArray(var3), new Integer(var4), var5, var6));
		}

		boolean var8 = var4 == 0 && this.iLdapConfigMgr.getMembershipAttributeScope() == 0;
		String var9 = this.iLdapConfigMgr.getMembershipAttribute();
		boolean var10 = this.iLdapConfigMgr.containGroup(var6);
		ArrayList var11 = new ArrayList();

		for (int var12 = 0; var12 < var3.length; ++var12) {
			var11.add(var3[var12]);
		}

		StringBuffer var27 = new StringBuffer("(&(" + var9 + "={0})");
		if (var6.size() > 1 || !var10 && var8) {
			var27.append("(|");
		}

		Iterator var13 = var6.iterator();

		while (var13.hasNext()) {
			LdapEntity var14 = this.iLdapConfigMgr.getLdapEntity((String) var13.next());
			var27.append(var14.getSearchFilter());
		}

		if (!var10 && var8) {
			LdapEntity var28 = this.iLdapConfigMgr.getLdapEntity("Group");
			var27.append(var28.getSearchFilter());
			var11.addAll(var28.getSearchBaseList());
		}

		if (var6.size() > 1 || !var10 && var8) {
			var27.append(")");
		}

		var27.append(")");
		Object[] var29 = new Object[]{var2.getDN()};
		String[] var30 = new String[0];
		var30 = (String[]) ((String[]) var11.toArray(var30));
		var30 = NodeHelper.getTopNodes(var30);
		HashSet var15 = new HashSet();
		HashSet var16 = new HashSet();

		label124 : for (int var17 = 0; var17 < var30.length; ++var17) {
			Set var18 = this.iLdapConn.searchEntities(var30[var17], var27.toString(), var29, 2, var6, var5, false,
					false);
			Iterator var19 = var18.iterator();

			while (true) {
				LdapEntry var20;
				String var21;
				do {
					if (!var19.hasNext()) {
						continue label124;
					}

					var20 = (LdapEntry) var19.next();
					var21 = var20.getDN();
					if (!this.iLdapConfigMgr.isGroup(var20.getType())) {
						break;
					}

					if (var8) {
						String var22 = var21.toLowerCase();
						var15.add(var22);
						var16.add(var22);
					}
				} while (!var10);

				if (LdapHelper.isUnderBases(var21, var3) && LdapHelper.isEntityTypeInList(var20.getType(), var6)) {
					this.createEntityFromLdapEntry(var1, "members", var20, var5);
				}
			}
		}

		if (var8) {
			while (var15.size() > 0) {
				HashSet var31 = new HashSet();
				Iterator var32 = var15.iterator();

				while (var32.hasNext()) {
					String var33 = (String) var32.next();
					String var34 = var33.toLowerCase();
					var29[0] = var33;

					label101 : for (int var35 = 0; var35 < var30.length; ++var35) {
						Set var36 = this.iLdapConn.searchEntities(var30[var35], var27.toString(), var29, 2, var6, var5,
								false, false);
						Iterator var23 = var36.iterator();

						while (true) {
							LdapEntry var24;
							String var25;
							do {
								if (!var23.hasNext()) {
									continue label101;
								}

								var24 = (LdapEntry) var23.next();
								var25 = var24.getDN();
								String var26 = var25.toLowerCase();
								if (var16.contains(var26) || !this.iLdapConfigMgr.isGroup(var24.getType())) {
									break;
								}

								if (!var15.contains(var26)) {
									var31.add(var26);
								}

								var16.add(var26);
							} while (!var10);

							if (LdapHelper.isUnderBases(var25, var3)
									&& LdapHelper.isEntityTypeInList(var24.getType(), var6)) {
								this.createEntityFromLdapEntry(var1, "members", var24, var5);
							}
						}
					}
				}

				var15 = var31;
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getMembersByMembership");
		}

	}

	private void getMembersByMember(DataObject var1, LdapEntry var2, String[] var3, int var4, List var5, List var6)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getMembersByMember",
					WIMMessageHelper.generateMsgParms(WIMTraceHelper.printDataObject(var1), var2,
							WIMTraceHelper.printObjectArray(var3), new Integer(var4), var5, var6));
		}

		Attributes var8 = var2.getAttributes();
		Object var9 = this.iLdapConfigMgr.getGroupMemberAttrs(var8, var8.get("objectClass"));
		if (this.iLdapConfigMgr.supportDynamicGroup()) {
			String var10 = this.iLdapConfigMgr.getDynamicMemberAttribute(var8.get("objectClass"));
			if (var10 != null) {
				List var11 = this.getDynamicMembers(var8.remove(var10));
				if (var11 != null && var11.size() > 0) {
					if (var9 == null) {
						String var12 = null;
						if (var8.get("objectClass") != null) {
							var12 = this.iLdapConfigMgr.getMemberAttribute(var8.get("objectClass"));
						}

						var9 = new BasicAttribute(var12);
					}

					Iterator var33 = var11.iterator();

					while (var33.hasNext()) {
						((Attribute) var9).add(var33.next());
					}
				}
			}
		}

		if (var9 == null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getMembersByMember");
			}

		} else {
			boolean var30 = var4 == 0 && !this.iLdapConfigMgr.isMemberAttributesNestedScope();
			HashMap var32 = new HashMap();
			ArrayList var34 = new ArrayList();
			if (var6 != null) {
				var34.addAll(var6);
			}

			String[] var13 = null;
			String var16;
			List var17;
			if (this.iLdapConfigMgr.isIncludeGroupInSearchEntityTypes()) {
				if (!var34.contains("Group")) {
					var34.add("Group");
				}

				DataObject var14 = var1.getDataObject("identifier");
				String var15 = var14.getString("uniqueName");
				var16 = RepositoryManager.singleton().getRepositoryID(var15);
				var17 = RepositoryManager.singleton().getRepositoryBaseEntries(var16);
				var13 = (String[]) ((String[]) var17.toArray(new String[0]));
				var13 = NodeHelper.getTopNodes(var13);
			}

			HashMap var35 = new HashMap();

			try {
				NamingEnumeration var36 = ((Attribute) var9).getAll();

				label217 : while (true) {
					String var18;
					LdapEntry var38;
					while (true) {
						while (true) {
							if (!var36.hasMoreElements()) {
								HashSet var40;
								if (var30) {
									label187 : for (HashSet var37 = new HashSet(var32.keySet()); var37
											.size() > 0; var37 = var40) {
										var40 = new HashSet();
										Iterator var39 = var37.iterator();

										label184 : while (true) {
											Attribute var31;
											do {
												if (!var39.hasNext()) {
													continue label187;
												}

												var18 = (String) var39.next();
												String var42 = var18.toLowerCase();
												var31 = (Attribute) var32.get(var42);
											} while (var31 == null);

											NamingEnumeration var43 = var31.getAll();

											while (true) {
												String var21;
												String var22;
												while (true) {
													do {
														if (!var43.hasMoreElements()) {
															continue label184;
														}

														var21 = (String) var43.next();
														if (this.iLdapConfigMgr
																.isSetReturnDNWithOutSpaceInGetMembers()) {
															var21 = LdapHelper.getValidDN(var21);
														}
													} while (var21 == null);

													var22 = var21.toLowerCase();
													if (this.iLdapConfigMgr.isIncludeGroupInSearchEntityTypes()) {
														if (!this.iLdapConfigMgr.isDummyMember(var21)
																&& LdapHelper.isUnderBases(var21, var13)
																&& this.startWithSameRDN(var21, var34, var30)
																&& !var32.containsKey(var22)
																&& !var35.containsKey(var21.toLowerCase())) {
															break;
														}
													} else if (!this.iLdapConfigMgr.isDummyMember(var21)
															&& LdapHelper.isUnderBases(var21, var3)
															&& this.startWithSameRDN(var21, var6, var30)
															&& !var32.containsKey(var22)) {
														break;
													}
												}

												LdapEntry var23 = null;

												try {
													var23 = this.iLdapConn.getEntityByIdentifier(var21, (String) null,
															(String) null, var34, var5, false, var30);
													var35.put(var21.toLowerCase(), true);
												} catch (EntityNotFoundException var27) {
													if (trcLogger.isLoggable(Level.FINE)) {
														trcLogger.logp(Level.FINE, CLASSNAME, "getMembersByMember",
																"Group member " + var21 + " is not found and ignored.");
													}
													continue;
												}

												String var24 = var23.getType();
												if (LdapHelper.isEntityTypeInList(var24, var6)) {
													List var25 = this.iLdapConfigMgr.getSupportedProperties(var24,
															var5);
													this.createEntityFromLdapEntry(var1, "members", var23, var25);
												}

												if (var30 && this.iLdapConfigMgr.isGroup(var24)) {
													Attributes var44 = var23.getAttributes();
													Attribute var26 = this.iLdapConfigMgr.getGroupMemberAttrs(var44,
															var44.get("objectClass"));
													if (var26 != null) {
														var32.put(var21.toLowerCase(), var26);
													}

													if (!var37.contains(var22)) {
														var40.add(var22);
													}
												}
											}
										}
									}
								}
								break label217;
							}

							var16 = (String) var36.next();
							if (this.iLdapConfigMgr.isSetReturnDNWithOutSpaceInGetMembers()) {
								var16 = LdapHelper.getValidDN(var16);
							}

							if (this.iLdapConfigMgr.isIncludeGroupInSearchEntityTypes()) {
								if (!this.iLdapConfigMgr.isDummyMember(var16) && LdapHelper.isUnderBases(var16, var13)
										&& this.startWithSameRDN(var16, var34, var30)
										&& !var35.containsKey(var16.toLowerCase())) {
									break;
								}
							} else if (!this.iLdapConfigMgr.isDummyMember(var16) && LdapHelper.isUnderBases(var16, var3)
									&& this.startWithSameRDN(var16, var6, var30)) {
								break;
							}
						}

						var17 = null;

						try {
							var38 = this.iLdapConn.getEntityByIdentifier(var16, (String) null, (String) null, var34,
									var5, false, var30);
							var35.put(var16.toLowerCase(), true);
							break;
						} catch (EntityNotFoundException var28) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "getMembersByMember",
										"Group member " + var16 + " is not found and ignored.");
							}
						}
					}

					var18 = var38.getType();
					if (LdapHelper.isEntityTypeInList(var18, var6)) {
						List var19 = this.iLdapConfigMgr.getSupportedProperties(var18, var5);
						this.createEntityFromLdapEntry(var1, "members", var38, var19);
					}

					if (var30 && this.iLdapConfigMgr.isGroup(var18)) {
						Attributes var41 = var38.getAttributes();
						Attribute var20 = this.iLdapConfigMgr.getGroupMemberAttrs(var41, var41.get("objectClass"));
						if (var20 != null) {
							var32.put(var16.toLowerCase(), var20);
						}
					}
				}
			} catch (NamingException var29) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var29.toString(true)), CLASSNAME, "getMembersByMember");
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getMembersByMember");
			}

		}
	}

	private boolean startWithSameRDN(String var1, List var2, boolean var3) {
		var1 = var1.toLowerCase();
		boolean var4 = false;

		for (int var5 = 0; var5 < var2.size(); ++var5) {
			String var6 = (String) var2.get(var5);
			if (this.iLdapConfigMgr.isGroup(var6)) {
				var4 = true;
			}

			if (this.iLdapConfigMgr.getLdapEntity(var6).startWithSameRDN(var1)) {
				return true;
			}
		}

		if (var3 && !var4 && this.iLdapConfigMgr.getLdapEntity("Group").startWithSameRDN(var1)) {
			return true;
		} else {
			return false;
		}
	}

	private void getAncestors(DataObject var1, LdapEntry var2, DataObject var3) throws WIMException {
		if (var3 != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "getAncestors");
			}

			List var5 = var3.getList("properties");
			int var6 = var3.getInt("level");
			List var7 = this.getEntityTypes(var3);
			String[] var8 = this.getBases(var3, var7);
			boolean var9 = var3.getBoolean("treeView");
			String var10 = var2.getDN();
			List var11 = this.iLdapConn.getAncestorDNs(var10, var6);
			DataObject var12 = var1;

			for (int var13 = 0; var13 < var11.size(); ++var13) {
				String var14 = (String) var11.get(var13);
				if (var14.length() != 0 && LdapHelper.isUnderBases(var14, var8)) {
					LdapEntry var15 = this.iLdapConn.getEntityByIdentifier(var14, (String) null, (String) null, var7,
							var5, false, false);
					String var16 = var15.getType();
					DataObject var17 = null;
					if (var7.contains(var16)) {
						var17 = this.createEntityFromLdapEntry(var12, "parent", var15, var5);
					} else {
						var17 = this.createEntityFromLdapEntry(var12, "parent", var15, (List) null);
					}

					var12 = var17;
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getAncestors");
			}

		}
	}

	private void getDescendants(DataObject var1, LdapEntry var2, DataObject var3) throws WIMException {
		if (var3 != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "getDescendants");
			}

			List var5 = var3.getList("properties");
			int var6 = var3.getInt("level");
			List var7 = this.getEntityTypes(var3);
			String[] var8 = this.getBases(var3, var7);
			boolean var9 = var3.getBoolean("treeView");
			byte var10 = 1;
			if (var6 == 0 && !var9) {
				var10 = 2;
			}

			HashSet var11 = new HashSet();
			HashMap var12 = new HashMap();
			Set var13 = this.iLdapConn.searchEntities(var2.getDN(), "objectClass=*", (Object[]) null, var10, var7, var5,
					false, false);
			Iterator var14 = var13.iterator();

			String var16;
			while (var14.hasNext()) {
				LdapEntry var15 = (LdapEntry) var14.next();
				var16 = var15.getType();
				String var17 = var15.getDN();
				DataObject var18 = null;
				if (LdapHelper.isUnderBases(var17, var8) && var7.contains(var16)) {
					var18 = this.createEntityFromLdapEntry(var1, "children", var15, var5);
				} else if (var9) {
					var18 = this.createEntityFromLdapEntry(var1, "children", var15, (List) null);
				}

				if (var9) {
					var11.add(var17);
					var12.put(var17, var18);
				}
			}

			if (var9) {
				while (var11.size() > 0) {
					HashSet var23 = new HashSet();
					Iterator var24 = var11.iterator();

					while (var24.hasNext()) {
						var16 = (String) var24.next();
						DataObject var25 = (DataObject) var12.get(var16);
						var13 = this.iLdapConn.searchEntities(var16, "objectClass=*", (Object[]) null, var10, var7,
								var5, false, false);
						Iterator var26 = var13.iterator();

						while (var26.hasNext()) {
							LdapEntry var19 = (LdapEntry) var26.next();
							String var20 = var19.getType();
							String var21 = var19.getDN();
							DataObject var22 = null;
							if (var7.contains(var20)) {
								var22 = this.createEntityFromLdapEntry(var25, "children", var19, var5);
							} else if (var9) {
								var22 = this.createEntityFromLdapEntry(var25, "children", var19, (List) null);
							}

							if (!var11.contains(var21)) {
								var23.add(var21);
								var12.put(var21, var22);
							}
						}
					}

					var11 = var23;
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "getDescendants");
			}

		}
	}

	private List getEntityTypes(DataObject var1) throws WIMException {
		String var2 = "getEntityTypes";
		String var3 = var1.getString("expression");
		HashSet var4 = new HashSet();
		if (var3 != null && var3.trim().length() > 0) {
			WIMXPathInterpreter var9 = new WIMXPathInterpreter(new StringReader(var3));

			try {
				XPathNode var10 = var9.parse((MetadataMapper) null);
			} catch (ParseException var7) {
				throw new SearchControlException("INVALID_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var3),
						CLASSNAME, var2, var7);
			} catch (TokenMgrError var8) {
				throw new SearchControlException("INVALID_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var3),
						CLASSNAME, var2, var8);
			}

			List var11 = var9.getEntityTypes();
			var4.addAll(var11);
		} else {
			LdapEntity[] var5 = this.iLdapConfigMgr.getLdapEntities();

			for (int var6 = 0; var6 < var5.length; ++var6) {
				var4.add(var5[var6].getName());
			}
		}

		return new ArrayList(var4);
	}

	public DataObject login(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI login", WIMTraceHelper.printDataGraph(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.getRepositoryId(), CLASSNAME, "login");
		List var3 = var1.getList("entities");
		DataObject var4 = (DataObject) var3.get(0);
		String var5 = this.iSchemaMgr.getQualifiedTypeName(var4.getType());
		Map var6 = ControlsHelper.getControlMap(var1);
		DataObject var7 = (DataObject) var6.get("LoginControl");
		if (var7 == null) {
			var7 = SDOHelper.createControlDataObject(var1, "http://www.ibm.com/websphere/wim", "LoginControl");
		}

		LdapSearchControl var8 = null;
		String var9 = var4.getString("principalName");
		if (var9 != null) {
			var9 = var9.replace("*", "\\*");
		}

		byte[] var10 = var4.getBytes("password");
		List var11 = var4.getList("certificate");
		int var12 = var11.size();
		LdapEntry var13 = null;
		DataObject var14 = this.iSchemaMgr.createRootDataObject();
		if (var12 > 0) {
			X509Certificate[] var15 = new X509Certificate[var12];

			try {
				for (int var16 = 0; var16 < var15.length; ++var16) {
					ByteArrayInputStream var17 = new ByteArrayInputStream((byte[]) ((byte[]) var11.get(var16)));
					CertificateFactory var18 = CertificateFactory.getInstance("X.509");
					var15[var16] = (X509Certificate) var18.generateCertificate(var17);
					var17.close();
				}
			} catch (IOException var30) {
				throw new CertificateMapFailedException(var30.getMessage(), var30);
			} catch (CertificateException var31) {
				throw new CertificateMapFailedException("CERTIFICATE_MAP_FAILED", var31);
			}

			var8 = this.getLdapSearchControl(var7, false, false);
			var13 = this.mapCertificate(var15, var8);
			if (var13 == null) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "WIM_SPI login", WIMTraceHelper.printDataGraph(var14));
				}

				return var14;
			}
		} else {
			if (var9 == null || var9.trim().length() == 0) {
				throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PRINCIPAL_NAME", CLASSNAME, "login");
			}

			if (var10 == null || var10.length == 0) {
				throw new PasswordCheckFailedException("MISSING_OR_EMPTY_PASSWORD", CLASSNAME, "login");
			}

			String var32 = "'";
			if (var9.indexOf("'") != -1) {
				var32 = "\"";
			}

			String var33 = "@xsi:type=" + var32 + var5 + var32 + " and " + "principalName" + "=" + var32 + var9 + var32;
			var7.setString("expression", var33);
			String var34 = LoginHelper.getContextProperty(var1, "allowDNPrincipalNameAsLiteral");
			boolean var35 = var34.equalsIgnoreCase("true");
			var8 = this.getLdapSearchControl(var7, false, var35);
			String[] var19 = var8.getBases();
			String var20 = var8.getFilter();
			if (this.iLdapConfigMgr.getUseEncodingInSearchExpression() != null) {
				var20 = LdapHelper.encodeAttribute(var20, this.iLdapConfigMgr.getUseEncodingInSearchExpression());
			}

			int var21 = var8.getCountLimit();
			int var22 = var8.getTimeLimit();
			List var23 = var8.getEntityTypes();
			List var24 = var8.getPropertyNmaes();
			int var25 = var8.getScope();
			int var26 = 0;

			for (int var27 = 0; var27 < var19.length; ++var27) {
				try {
					Set var28 = this.iLdapConn.searchEntities(var19[var27], var20, (Object[]) null, var25, var23, var24,
							false, false, var21, var22);
					if (var28.size() > 1) {
						throw new PasswordCheckFailedException("MULTIPLE_PRINCIPALS_FOUND",
								WIMMessageHelper.generateMsgParms(var9, this.getRepositoryId()), CLASSNAME, "login");
					}

					if (var28.size() == 1) {
						if (var26 == 0) {
							var13 = (LdapEntry) var28.iterator().next();
						}

						++var26;
						if (var26 > 1) {
							throw new PasswordCheckFailedException("MULTIPLE_PRINCIPALS_FOUND",
									WIMMessageHelper.generateMsgParms(var9, this.getRepositoryId()), CLASSNAME,
									"login");
						}
					}
				} catch (EntityNotFoundException var29) {
					;
				}
			}

			if (var13 == null) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "WIM_SPI login", WIMTraceHelper.printDataGraph(var14));
				}

				return var14;
			}

			String var36 = var13.getDN();
			this.authenticateWithPassword(var36, var10, var9);
		}

		this.createEntityFromLdapEntry(var14, "entities", var13, var7.getList("properties"));
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI login", WIMTraceHelper.printDataGraph(var14));
		}

		return var14;
	}

	private void authenticateWithPassword(String var1, byte[] var2, String var3) throws WIMException {
		DirContext var5 = null;
		NamingException var6 = new NamingException();

		try {
			Control[] var16 = null;
			if (this.policyHandler != null && this.iLdapConfigMgr.getIsPolicyEnforced() != null) {
				DirContext var8 = this.iLdapConn.getDirContext();
				LdapContext var9 = ((LdapContext) var8).newInstance((Control[]) null);
				this.iLdapConn.releaseDirContext(var8);
				this.policyHandler.loginPreProcess(var9, (DataObject) null);
				var16 = ((LdapContext) var9).getRequestControls();
				var9.close();
			}

			if (this.iLdapConfigMgr.isSetUsePrincipalNameForLogin()) {
				var5 = this.iLdapConn.createDirContext(var3, var2, var16, var6);
			} else {
				var5 = this.iLdapConn.createDirContext(var1, var2, var16, var6);
			}

			var6 = (NamingException) var6.getRootCause();
			if (this.policyHandler != null && this.iLdapConfigMgr.getIsPolicyEnforced() != null) {
				this.policyHandler.loginPostProcess(var5, (DataObject) null, var6);
			}

			var5.close();
		} catch (AuthenticationNotSupportedException var12) {
			throw new com.ibm.websphere.wim.exception.AuthenticationNotSupportedException("AUTHENTICATE_NOT_SUPPORTED",
					WIMMessageHelper.generateMsgParms(this.getRepositoryId(), var12.toString(true)), CLASSNAME,
					"authenticateWithPassword");
		} catch (AuthenticationException var13) {
			AuthenticationException var7 = var13;

			try {
				if (this.policyHandler != null && this.iLdapConfigMgr.getIsPolicyEnforced() != null) {
					this.policyHandler.loginPostProcess((DirContext) null, (DataObject) null, var7);
				}
			} catch (NamingException var10) {
				;
			}

			throw new PasswordCheckFailedException("PASSWORD_CHECKED_FAILED",
					WIMMessageHelper.generateMsgParms(var3, var13.toString(true)), CLASSNAME,
					"authenticateWithPassword");
		} catch (NameNotFoundException var14) {
			throw new EntityNotFoundException("LDAP_ENTRY_NOT_FOUND",
					WIMMessageHelper.generateMsgParms(var1, var14.toString(true)), CLASSNAME,
					"authenticateWithPassword");
		} catch (NamingException var15) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var15.toString(true)),
					Level.SEVERE, CLASSNAME, "authenticateWithPassword");
		}

		if (var5 != null) {
			try {
				var5.close();
			} catch (NamingException var11) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var11.toString(true)), Level.SEVERE, CLASSNAME,
						"authenticateWithPassword");
			}
		}

	}

	private LdapEntry mapCertificate(X509Certificate[] var1, LdapSearchControl var2) throws WIMException {
		LdapEntry var4 = null;
		X509Certificate var5 = var1[0];
		String var6;
		if ("filterDescriptorMode".equalsIgnoreCase(this.iLdapConfigMgr.getCertificateMapMode())) {
			var6 = this.iLdapConfigMgr.getCertificateLDAPFilter(var5);
			var6 = var6.trim();
			String[] var7 = var2.getBases();
			int var8 = var2.getCountLimit();
			int var9 = var2.getTimeLimit();
			List var10 = var2.getEntityTypes();
			List var11 = var2.getPropertyNmaes();
			int var12 = var2.getScope();
			int var13 = 0;

			for (int var14 = 0; var14 < var7.length; ++var14) {
				try {
					Set var15 = this.iLdapConn.searchEntities(var7[var14], var6, (Object[]) null, var12, var10, var11,
							false, false, var8, var9);
					if (var15.size() > 1) {
						throw new CertificateMapFailedException("MULTIPLE_PRINCIPALS_FOUND",
								WIMMessageHelper.generateMsgParms(var6, this.getRepositoryId()), CLASSNAME,
								"mapCertificate");
					}

					if (var15.size() == 1) {
						if (var13 == 0) {
							var4 = (LdapEntry) var15.iterator().next();
						}

						++var13;
						if (var13 > 1) {
							throw new CertificateMapFailedException("MULTIPLE_PRINCIPALS_FOUND",
									WIMMessageHelper.generateMsgParms(var6, this.getRepositoryId()), CLASSNAME,
									"mapCertificate");
						}
					}
				} catch (EntityNotFoundException var17) {
					;
				}
			}
		} else {
			var6 = LdapHelper.getValidDN(var5.getSubjectX500Principal().getName());

			try {
				var4 = this.iLdapConn.getEntityByIdentifier(var6, (String) null, (String) null, (List) null,
						var2.getPropertyNmaes(), false, false);
			} catch (EntityNotFoundException var16) {
				;
			}
		}

		return var4;
	}

	private String getPrincipalNameFilter(String var1) {
		List var2 = this.iLdapConfigMgr.getLoginAttributes();
		var1 = LdapName.escapeAttributeValue(var1);
		StringBuffer var3 = new StringBuffer();
		if (var2.size() > 1) {
			var3.append("(|");
		}

		for (int var4 = 0; var4 < var2.size(); ++var4) {
			var3.append("(" + var2.get(var4) + "=" + var1 + ")");
		}

		if (var2.size() > 1) {
			var3.append(")");
		}

		return var3.toString();
	}

	private List getLoginAttributes(DataObject var1) {
		Object var2 = null;
		List var3 = var1.getList("mappedProperties");
		LdapEntity var4 = this.iLdapConfigMgr.getLdapEntity("Person");
		int var5 = var3.size();
		if (var5 == 0) {
			var2 = this.iLdapConfigMgr.getLoginAttributes();
		} else {
			var2 = new ArrayList(var5);

			for (int var6 = 0; var6 < var5; ++var6) {
				String var7 = (String) var3.get(var6);
				((List) var2).add(this.iLdapConfigMgr.getAttributeName(var4, var7));
			}
		}

		return (List) var2;
	}

	private String getPersonUniqueId(String var1) {
		int var2 = var1.indexOf("account");
		return var2 == 0 ? var1.substring("account".length()) : var1;
	}

	private String getPersonUniqueName(String var1) {
		return null;
	}

	public DataObject search(DataObject var1) throws WIMException {
		boolean var3 = false;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI search", WIMTraceHelper.printDataGraph(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.getRepositoryId(), CLASSNAME, "search");
		String var4 = null;
		Map var5 = ControlsHelper.getControlMap(var1);
		DataObject var6 = (DataObject) var5.get("CacheControl");
		if (var6 != null) {
			String var7 = var6.getString("mode");
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "search", "Cache Control is passed with mode " + var7);
			}

			if (var7 != null && "clearAll".equalsIgnoreCase(var7)) {
				this.iLdapConn.invalidateAttributeCache();
				this.iLdapConn.invalidateNamesCache();
				String var8 = this.getCallerUniqueName();
				msgLogger.logp(Level.WARNING, CLASSNAME, "search", "CLEAR_ALL_CLEAR_CACHE_MODE",
						WIMMessageHelper.generateMsgParms(this.getRepositoryId(), var7, var8));
			} else if (var7 != null && "clearEntity".equalsIgnoreCase(var7)) {
				msgLogger.logp(Level.WARNING, CLASSNAME, "search", "UNSUPPORTED_CLEAR_CACHE_MODE",
						WIMMessageHelper.generateMsgParms(this.getRepositoryId(), var7));
			} else {
				msgLogger.logp(Level.WARNING, CLASSNAME, "search", "UNKNOWN_CLEAR_CACHE_MODE",
						WIMMessageHelper.generateMsgParms(this.getRepositoryId(), var7));
			}
		}

		boolean var33 = true;
		DataObject var34 = (DataObject) var5.get("ChangeControl");
		if (var34 == null) {
			var33 = false;
			var34 = (DataObject) var5.get("SearchControl");
		} else {
			List var9 = var34.getList("checkPoint");
			if (var9.size() == 0) {
				var3 = true;
			}
		}

		if (var34 != null) {
			var4 = var34.getString("expression");
			if (!var3 && (var4 == null || var4.length() == 0)) {
				throw new SearchControlException("MISSING_SEARCH_EXPRESSION", CLASSNAME, "search");
			}
		}

		Set var35 = LoginHelper.getSpecifiedRealms(var1);
		boolean var10 = var35.contains("n/a");
		String var11 = LoginHelper.getContextProperty(var1, "allowDNPrincipalNameAsLiteral");
		boolean var12 = var11.equalsIgnoreCase("true");
		LdapSearchControl var13 = this.getLdapSearchControl(var34, var10, var12);
		String[] var14 = var13.getBases();
		String var15 = var13.getFilter();
		int var16 = var13.getCountLimit();
		int var17 = var13.getTimeLimit();
		List var18 = var13.getEntityTypes();
		List var19 = var13.getPropertyNmaes();
		int var20 = var13.getScope();
		DataObject var21 = this.iSchemaMgr.createRootDataObject();
		if (var33) {
			String var22 = this.changeHandler.getCurrentCheckPoint();
			DataObject var23 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "CheckPointType");
			var23.setString("repositoryId", this.iReposId);
			var23.setString("repositoryCheckPoint", var22);
			DataObject var24 = SDOHelper.createControlDataObject(var21, "http://www.ibm.com/websphere/wim",
					"ChangeResponseControl");
			var24.getList("checkPoint").add(var23);
			List var25 = var34.getList("checkPoint");
			if (var25 != null && var25.size() > 0) {
				DataObject var26 = (DataObject) var25.get(0);
				var22 = var26.getString("repositoryCheckPoint");
				if (var22 == null) {
					throw new ChangeControlException("NULL_CHECKPOINT_VALUE", Level.SEVERE, CLASSNAME, "search");
				}

				boolean var27 = true;
				List var28 = var34.getList("changeTypes");

				for (int var29 = 0; var29 < var14.length; ++var29) {
					List var30 = this.changeHandler.searchChangedEntities(var22, var28, var14[var29], var15, var20,
							var18, var19, var16, var17);
					if (var30 != null) {
						for (int var31 = 0; var31 < var30.size(); ++var31) {
							LdapEntry var32 = (LdapEntry) var30.get(var31);
							if (this.isActiveDirectory) {
								if ("delete".equalsIgnoreCase(var32.getChangeType())) {
									this.iLdapConn.invalidateAttributes(
											this.iLdapConfigMgr.switchToLdapNode(var32.getUniqueName()),
											var32.getExtId(), var32.getUniqueName());
								} else {
									this.iLdapConn.invalidateAttributes(var32.getDN(), var32.getExtId(),
											var32.getUniqueName());
								}
							} else if (var27) {
								if (var32.getExtId() == null && "delete".equalsIgnoreCase(var32.getChangeType())) {
									this.iLdapConn.invalidateAttributeCache();
									var27 = false;
								} else {
									this.iLdapConn.invalidateAttributes(var32.getDN(), var32.getExtId(),
											var32.getUniqueName());
								}
							}

							this.createEntityFromLdapEntry(var21, "entities", var32, var19);
						}

						if (var30.size() > 0) {
							this.iLdapConn.invalidateNamesCache();
						}
					}
				}
			}
		} else {
			for (int var36 = 0; var36 < var14.length; ++var36) {
				Set var37 = this.iLdapConn.searchEntities(var14[var36], var15, (Object[]) null, var20, var18, var19,
						false, false, var16, var17);
				Iterator var38 = var37.iterator();

				while (var38.hasNext()) {
					LdapEntry var39 = (LdapEntry) var38.next();
					this.createEntityFromLdapEntry(var21, "entities", var39, var19);
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI search", WIMTraceHelper.printDataGraph(var21));
		}

		return var21;
	}

	private void getPropertyDefinitions(DataObject var1, DataObject var2)
			throws InvalidEntityTypeException, PropertyNotDefinedException {
		String var4 = var2.getString("entityTypeName");
		if (var4 != null) {
			if (var4.startsWith("wim:")) {
				var4 = this.iSchemaMgr.getTypeName(var4);
			}

			LdapEntity var5 = this.iLdapConfigMgr.getLdapEntity(var4);
			if (var5 == null) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "getPropertyDefinitions(DataObject, DataObject)",
							"Entity type " + var4 + " is invalid and is ignored.");
				}

				return;
			}

			Object var6 = var2.getList("propertyNames");
			Set var7 = var5.getProperties();
			String var10;
			if (((List) var6).size() == 0) {
				var6 = new ArrayList(var7);
			} else {
				boolean var8 = false;
				String var9 = null;
				var10 = null;

				for (int var11 = 0; var11 < ((List) var6).size(); ++var11) {
					var10 = (String) ((List) var6).get(var11);
					int var17 = var10.indexOf(":");
					if (var17 > 1) {
						var9 = var10.substring(0, var17);
						if (var9.equals("wim")) {
							var10 = var10.substring(var17 + 1, var10.length());
							((List) var6).remove(var11);
							((List) var6).add(var11, var10);
						}
					}
				}

				ArrayList var20 = new ArrayList((Collection) var6);
				var20.removeAll(var7);
				if (var20.size() > 0) {
					throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
							WIMMessageHelper.generateMsgParms(var20.get(0), var4), CLASSNAME,
							"getPropertyDefinitions(DataObject, DataObject)");
				}
			}

			DataObject var18 = var1.getDataObject("schema");
			if (var18 == null) {
				var18 = var1.createDataObject("schema");
			}

			for (int var19 = 0; var19 < ((List) var6).size(); ++var19) {
				var10 = (String) ((List) var6).get(var19);
				if (this.iSchemaMgr.getProperty(var4, var10) == null && trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getPropertyDefinitions(DataObject, DataObject)",
							"Property type " + var10 + " is invalid and is ignored.");
				}

				String var21 = this.iSchemaMgr.getTypeName(var10);
				String var12 = this.iSchemaMgr.getTypeNsURI(var10);
				DataObject var13 = var18.createDataObject("propertySchema");
				var13.set("propertyName", var21);
				var13.set("nsURI", var12);
				var13.set("nsPrefix", this.iSchemaMgr.getNsPrefix(var12));
				DataObject var14 = null;
				String var15 = this.iLdapConfigMgr.getAttributeName(var5, var10);
				if (!var10.equals(var15)) {
					var14 = var13.createDataObject("metaData");
					var14.set("name", "repositoryPropertyName");
					var14.getList("values").add(var15);
				}

				LdapAttribute var16 = this.iLdapConfigMgr.getLdapAttribute(var15);
				if (var16 != null && var16.getSyntax() != null) {
					if (var14 == null) {
						var14 = var13.createDataObject("metaData");
					}

					var14.set("name", "repositoryDataType");
					var14.getList("values").add(var16.getSyntax());
				}
			}
		}

	}

	private void getDataTypes(DataObject var1, DataObject var2) throws InvalidEntityTypeException {
		DataObject var4 = var1.getDataObject("schema");
		if (var4 == null) {
			var4 = var1.createDataObject("schema");
		}

		this.iSchemaMgr.getSupportedDataTypes(var4);
	}

	private void getEntityTypeDefinitions(DataObject var1, DataObject var2) throws InvalidEntityTypeException {
		List var4 = var2.getList("entityTypeNames");
		LdapEntity[] var5 = null;
		int var7;
		if (var4 != null && var4.size() > 0) {
			ArrayList var6 = new ArrayList(var4.size());

			for (var7 = 0; var7 < var4.size(); ++var7) {
				String var8 = (String) var4.get(var7);
				LdapEntity var9 = this.iLdapConfigMgr.getLdapEntity(var8);
				if (var9 == null) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "getEntityTypeDefinitions(DataObject, DataObject)",
								"Entity type " + var8 + " is invalid and is ignored.");
					}
				} else {
					var6.add(var9);
				}
			}

			var5 = (LdapEntity[]) ((LdapEntity[]) var6.toArray(new LdapEntity[0]));
		} else {
			var5 = this.iLdapConfigMgr.getLdapEntities();
		}

		DataObject var21 = var1.getDataObject("schema");
		if (var21 == null) {
			var21 = var1.createDataObject("schema");
		}

		for (var7 = 0; var7 < var5.length; ++var7) {
			LdapEntity var22 = var5[var7];
			String var23 = var22.getName();
			DataObject var10 = var21.createDataObject("entitySchema");
			String var11 = this.iSchemaMgr.getTypeName(var23);
			String var12 = this.iSchemaMgr.getTypeNsURI(var23);
			String var13 = this.iSchemaMgr.getNsPrefix(var12);
			var10.set("entityName", var11);
			var10.set("nsURI", var12);
			var10.set("nsPrefix", var13);
			DataObject var14 = var10.createDataObject("entityConfiguration");
			DataObject var15 = var14.createDataObject("metaData");
			var15.set("name", "rdnAttributes");
			String[][] var16 = var22.getRDNAttributes();

			for (int var17 = 0; var17 < var16.length; ++var17) {
				String[] var18 = var16[var17];
				String var19 = null;
				if (var18.length == 1) {
					var19 = var18[0];
				} else {
					for (int var20 = 0; var20 < var18.length; ++var20) {
						if (var20 > 0) {
							var19 = var19 + "+" + var18[var20];
						} else {
							var19 = var18[var20];
						}
					}
				}

				var15.getList("values").add(var19);
			}

			var15 = var14.createDataObject("metaData");
			var15.set("name", "objectClasses");
			var15.setList("values", var22.getObjectClasses());
			var15 = var14.createDataObject("metaData");
			var15.set("name", "searchFilter");
			var15.getList("values").add(var22.getSearchFilter());
			var15 = var14.createDataObject("metaData");
			var15.set("name", "searchBases");
			var15.getList("values").addAll(var22.getSearchBaseList());
			String var24 = "1";
		}

	}

	public DataObject getSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI getSchema", WIMTraceHelper.printDataGraph(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.getRepositoryId(), CLASSNAME, "getSchema");
		Map var3 = ControlsHelper.getControlMap(var1);
		DataObject var4 = (DataObject) var3.get("EntityTypeControl");
		DataObject var5 = (DataObject) var3.get("PropertyDefinitionControl");
		DataObject var6 = (DataObject) var3.get("DataTypeControl");
		DataObject var7 = this.iSchemaMgr.createRootDataObject();
		if (var4 != null) {
			this.getEntityTypeDefinitions(var7, var4);
		}

		if (var5 != null) {
			this.getPropertyDefinitions(var7, var5);
		}

		if (var6 != null) {
			this.getDataTypes(var7, var6);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI getSchema", WIMTraceHelper.printDataGraph(var7));
		}

		return var7;
	}

	public DataObject createSchema(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI createSchema", WIMTraceHelper.printDataGraph(var1));
		}

		AsyncUtils.asyncOperationNotSupported(var1, this.getRepositoryId(), CLASSNAME, "createSchema");
		DataObject var3 = var1.getDataObject("schema");
		DataObject var4;
		if (var3 != null) {
			var4 = ConfigManager.singleton().getRepositoryDataObject(this.getRepositoryId());
			this.iLdapConfigMgr.initialize(var4);
			this.iLdapConn.initializeRetrieveAttrIds();
		}

		var4 = this.iSchemaMgr.createRootDataObject();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI createSchema", WIMTraceHelper.printDataGraph(var4));
		}

		return var4;
	}

	private void populateEntity(DataObject var1, List var2, Attributes var3) throws WIMException {
		if (var2 != null && var2.size() != 0) {
			String var5 = this.iSchemaMgr.getQualifiedTypeName(var1.getType());
			LdapEntity var6 = this.iLdapConfigMgr.getLdapEntity(var5);
			Set var7 = var6.getAttributes();
			List var8 = this.iLdapConfigMgr.getSupportedProperties(var5, var2);

			try {
				ArrayList var9 = new ArrayList();
				NamingEnumeration var10 = var3.getAll();

				label121 : while (var10.hasMore()) {
					boolean var11 = false;
					Attribute var12 = (Attribute) var10.next();
					String var13 = var12.getID();
					int var14 = var13.indexOf(59);
					if (var14 > 0) {
						var13 = var13.substring(0, var14);
					}

					if (var7.contains(var13)) {
						var11 = true;
					} else {
						Iterator var15 = var7.iterator();

						while (var15.hasNext()) {
							String var16 = (String) var15.next();
							if (var16.equalsIgnoreCase(var13)) {
								var11 = true;
								break;
							}
						}
					}

					if (!var11 && ("userPassword".equalsIgnoreCase(var13) || "unicodePwd".equalsIgnoreCase(var13))) {
						var11 = true;
					}

					Set var23 = this.iLdapConfigMgr.getPropertyName(var6, var13);
					boolean var24 = false;
					if (var23.contains("ibmPrimaryEmail") && var23.contains("ibm-primaryEmail")) {
						var24 = true;
					}

					if (var23.contains("ibmJobTitle") && var23.contains("ibm-jobTitle")) {
						var24 = true;
					}

					Iterator var17 = var23.iterator();

					while (true) {
						Property var21;
						do {
							label111 : do {
								while (true) {
									String var18;
									do {
										do {
											if (!var17.hasNext()) {
												continue label121;
											}

											var18 = (String) var17.next();
										} while (var18.equalsIgnoreCase("ibmPrimaryEmail") && var24);
									} while (var18.equalsIgnoreCase("ibmJobTitle") && var24);

									for (int var19 = 0; var19 < var8.size(); ++var19) {
										String var20 = (String) var8.get(var19);
										if ("*".equals(var20) && var11 || var20.equalsIgnoreCase(var18)) {
											var21 = this.iSchemaMgr.getProperty(var1.getType(), var18);
											continue label111;
										}
									}
								}
							} while (var21 == null);
						} while (var9.contains(var21.getName()) && var13.equalsIgnoreCase(var21.getName()));

						this.setPropertyValue(var1, var12, var21, this.iLdapConfigMgr.getLdapAttribute(var13));
						if (!var9.contains(var21.getName())) {
							var9.add(var21.getName());
						}
					}
				}

			} catch (NamingException var22) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var22.toString(true)), Level.SEVERE, CLASSNAME,
						"populateEntity");
			}
		}
	}

	private String getString(boolean var1, Object var2) {
		return var1 ? LdapHelper.getOctetString((byte[]) ((byte[]) var2)) : var2.toString();
	}

	private String getDateString(Object var1) throws WIMSystemException {
		String var2 = "getDateString(Object)";
		if (var1 instanceof Date) {
			return SDOHelper.getDateString((Date) var1);
		} else {
			String var3 = null;
			SimpleDateFormat var4 = null;
			StringBuffer var5 = new StringBuffer(var1.toString());
			int var6 = var5.indexOf("Z");
			if (var6 == -1) {
				var6 = var5.indexOf("z");
			}

			if (var6 != -1) {
				var5.replace(var6, var6, "-0000");
			}

			var3 = this.iLdapConfigMgr.getTimestampFormat();
			if (var3 != null) {
				var4 = new SimpleDateFormat(var3);
			} else if (this.iLdapConfigMgr.getLdapType().startsWith("IDS")) {
				int var7 = var5.indexOf("-");
				if (var5.indexOf(".-") == -1) {
					while (var5.substring(0, var7).length() < 21) {
						if (var5.indexOf(".") == -1) {
							var5.replace(var7, var7, ".");
							++var7;
						}

						var5.replace(var7, var7, "0");
						var7 = var5.indexOf("-");
					}
				}

				var4 = new SimpleDateFormat("yyyyMMddHHmmss.SSSZ");
				var5 = new StringBuffer(var5.substring(0, 18) + var5.substring(21));
			} else if (!this.iLdapConfigMgr.getLdapType().startsWith("SUNONE")
					&& !this.iLdapConfigMgr.getLdapType().startsWith("DOMINO")
					&& !this.iLdapConfigMgr.getLdapType().startsWith("NDS")) {
				if (var5.toString().contains(".")) {
					var4 = new SimpleDateFormat("yyyyMMddHHmmss.SZ");
				} else {
					var4 = new SimpleDateFormat("yyyyMMddHHmmssZ");
				}
			} else {
				var4 = new SimpleDateFormat("yyyyMMddHHmmssZ");
			}

			Date var10 = null;

			try {
				var10 = var4.parse(var5.toString());
			} catch (java.text.ParseException var9) {
				throw new WIMSystemException("SYSTEM_EXCEPTION", WIMMessageHelper.generateMsgParms(var9.toString()),
						Level.WARNING, CLASSNAME, var2);
			}

			return SDOHelper.getDateString(var10);
		}
	}

	private void setPropertyValue(DataObject var1, Attribute var2, Property var3, LdapAttribute var4)
			throws WIMException {
		String var6 = var3.getType().getName();
		boolean var7 = var3.isMany();
		String var8 = "string";
		if (var4 != null) {
			var8 = var4.getSyntax();
		}

		try {
			Object var18;
			if ("String".equals(var6)) {
				boolean var9 = "octetString".equalsIgnoreCase(var8);
				if (var7) {
					NamingEnumeration var10 = var2.getAll();

					while (var10.hasMoreElements()) {
						Object var11 = var10.nextElement();
						if (var11 != null) {
							var1.getList(var3).add(this.getString(var9, var11));
						}
					}
				} else {
					var18 = var2.get();
					if (var18 != null) {
						var1.set(var3, this.getString(var9, var18));
					}
				}
			} else {
				NamingEnumeration var16;
				Object var17;
				if ("DateTime".equals(var6)) {
					if (var7) {
						var16 = var2.getAll();

						while (var16.hasMoreElements()) {
							var18 = var16.nextElement();
							if (var18 != null) {
								var1.getList(var3).add(this.getDateString(var18));
							}
						}
					} else {
						var17 = var2.get();
						if (var17 != null) {
							var1.set(var3, this.getDateString(var17));
						}
					}
				} else if ("Int".equals(var6)) {
					if (var7) {
						var16 = var2.getAll();

						while (var16.hasMoreElements()) {
							var18 = var16.nextElement();
							if (var18 != null) {
								var1.getList(var3).add(new Integer(var18.toString()));
							}
						}
					} else {
						var17 = var2.get();
						if (var17 != null) {
							var1.setInt(var3, Integer.parseInt(var17.toString()));
						}
					}
				} else if ("IdentifierType".equals(var6)) {
					try {
						if (var7) {
							var16 = var2.getAll();

							while (var16.hasMoreElements()) {
								String var20 = (String) var16.nextElement();
								if (var20 != null) {
									LdapEntry var21 = this.iLdapConn.getEntityByIdentifier(var20, (String) null,
											(String) null, (List) null, (List) null, false, false);
									var1.getList(var3).add(this.createIdentiferFromLdapEntry(var21));
								}
							}
						} else {
							String var19 = (String) var2.get();
							if (var19 != null) {
								LdapEntry var22 = this.iLdapConn.getEntityByIdentifier(var19, (String) null,
										(String) null, (List) null, (List) null, false, false);
								var1.set(var3, this.createIdentiferFromLdapEntry(var22));
							}
						}
					} catch (WIMException var12) {
						if ("LDAP_ENTRY_NOT_FOUND".equalsIgnoreCase(var12.getMessageKey())) {
							throw new WIMSystemException("INVALID_PROPERTY_VALUE",
									WIMMessageHelper.generateMsgParms(var3.getName(),
											var1.getDataObject("identifier").getString("externalName")),
									CLASSNAME, "setValue(DataObject, Object, String, String)");
						}

						throw var12;
					}
				} else if ("Base64Binary".equals(var6)) {
					if (var7) {
						var16 = var2.getAll();

						while (var16.hasMoreElements()) {
							var18 = var16.nextElement();
							if (var18 != null) {
								var1.getList(var3).add(var18);
							}
						}
					} else {
						var17 = var2.get();
						if (var17 != null) {
							var1.set(var3, var17);
						}
					}
				} else if ("LangType".equals(var6)) {
					if (var7) {
						var16 = var2.getAll();

						while (var16.hasMoreElements()) {
							var18 = var16.nextElement();
							if (var18 != null) {
								DataObject var23 = var1.createDataObject(var3);
								var23.set("value", var18);
							}
						}
					} else {
						var17 = var2.get();
						if (var17 != null) {
							DataObject var24 = var1.createDataObject(var3);
							var24.set("value", var17);
						}
					}
				} else if ("Boolean".equals(var6)) {
					if (var7) {
						var16 = var2.getAll();

						while (var16.hasMoreElements()) {
							var18 = var16.nextElement();
							if (var18 != null) {
								var1.getList(var3).add(new Boolean(var18.toString()));
							}
						}
					} else {
						var17 = var2.get();
						if (var17 != null) {
							var1.setBoolean(var3, Boolean.parseBoolean(var17.toString()));
						}
					}
				} else if ("Long".equals(var6)) {
					if (var7) {
						var16 = var2.getAll();

						while (var16.hasMoreElements()) {
							var18 = var16.nextElement();
							if (var18 != null) {
								var1.getList(var3).add(new Long(var18.toString()));
							}
						}
					} else {
						var17 = var2.get();
						if (var17 != null) {
							var1.setLong(var3, Long.parseLong(var17.toString()));
						}
					}
				} else if (var7) {
					var16 = var2.getAll();

					while (var16.hasMoreElements()) {
						var18 = var16.nextElement();
						if (var18 != null) {
							var1.getList(var3).add(var18);
						}
					}
				} else {
					var17 = var2.get();
					if (var17 != null) {
						var1.set(var3, var17);
					}
				}
			}
		} catch (NamingException var13) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var13.toString(true)),
					Level.WARNING, CLASSNAME, "setValue(DataObject, Object, String, String)");
		} catch (ClassCastException var14) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "setValue(DataObject, Object, String, String)", var14.toString());
			}

			msgLogger.logp(Level.SEVERE, CLASSNAME, "setValue(DataObject, Object, String, String)",
					"INVALID_PROPERTY_DATA_TYPE", WIMMessageHelper.generateMsgParms(var3.getName()));
		} catch (ArrayStoreException var15) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "setValue(DataObject, Object, String, String)", var15.toString());
			}

			msgLogger.logp(Level.SEVERE, CLASSNAME, "setValue(DataObject, Object, String, String)",
					"INVALID_PROPERTY_DATA_TYPE", WIMMessageHelper.generateMsgParms(var3.getName()));
		}

	}

	private String getDN(String var1, String var2, Attributes var3, boolean var4, boolean var5) throws WIMException {
		String var7 = null;
		String var8 = this.iLdapConfigMgr.getLdapNode(var1);
		if (var8 != null) {
			return var8;
		} else {
			var1 = this.iLdapConfigMgr.switchToLdapNode(var1);
			if ((var5 || this.iLdapConfigMgr.needTranslateRDN()) && this.iLdapConfigMgr.needTranslateRDN(var2)) {
				try {
					if (var2 != null) {
						LdapEntity var9 = this.iLdapConfigMgr.getLdapEntity(var2);
						if (var9 != null && var3 != null) {
							String[] var10 = LdapHelper.getRDNAttributes(var1);
							String[][] var11 = var9.getWIMRDNProperties();
							String[][] var12 = var9.getRDNAttributes();
							Attribute[] var13 = new Attribute[var11.length];
							String[] var14 = new String[var11.length];

							for (int var15 = 0; var15 < var11.length; ++var15) {
								String[] var16 = var11[var15];
								boolean var17 = true;

								for (int var18 = 0; var18 < var16.length; ++var18) {
									if (!var16[var18].equalsIgnoreCase(var10[var18])) {
										var17 = false;
									}
								}

								if (var17) {
									String[] var23 = var12[var15];

									for (int var19 = 0; var19 < var23.length; ++var19) {
										var13[var19] = var3.get(var23[var19]);
										if (var13[var19] == null && !var4) {
											throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY",
													WIMMessageHelper.generateMsgParms(var16[var19]), CLASSNAME,
													"getDN");
										}

										var14[var19] = (String) var13[var19].get();
									}

									var7 = LdapHelper.replaceRDN(var1, var23, var14);
								}
							}
						}
					}

					if (var7 == null && var4) {
						Attributes var21 = this.iLdapConn.getAttributesByUniqueName(var1, new String[0], (List) null);
						Attribute var22 = var21.get("distinguishedName");
						var7 = (String) var22.get();
					}
				} catch (NamingException var20) {
					throw new WIMSystemException("NAMING_EXCEPTION",
							WIMMessageHelper.generateMsgParms(var20.toString(true)), CLASSNAME, "getDN");
				}
			}

			if (var7 == null) {
				var7 = var1;
			} else if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "getDN", "Translated DN: " + var7);
			}

			return var7;
		}
	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI dynamicUpdateConfig",
					WIMMessageHelper.generateMsgParms(var1, WIMTraceHelper.printMapWithoutPassword(var2)));
		}

		if ("websphere.usermanager.serviceprovider.update.ldap.bindinfo".equalsIgnoreCase(var1)) {
			this.iLdapConn.dynamicUpdateConfig(var1, var2);
		} else if ("websphere.usermanager.serviceprovider.add.baseentry".equalsIgnoreCase(var1)) {
			String var4 = (String) var2.get("DYNA_CONFIG_KEY_BASE_ENTRY");
			var4 = UniqueNameHelper.getValidUniqueName(var4);
			if (var4 == null) {
				throw new DynamicUpdateConfigException("INVALID_UNIQUE_NAME_SYNTAX",
						WIMMessageHelper.generateNullMsgParms(), CLASSNAME, "dynamicUpdateConfig");
			}

			String var5 = (String) var2.get("DYNA_CONFIG_KEY_BASE_ENTRY_IN_REPOS");
			if (var5 != null) {
				var5 = UniqueNameHelper.getValidUniqueName(var5);
				if (var5 == null) {
					throw new DynamicUpdateConfigException("INVALID_UNIQUE_NAME_SYNTAX",
							WIMMessageHelper.generateNullMsgParms(), CLASSNAME, "dynamicUpdateConfig");
				}
			} else {
				var5 = var4;
			}

			try {
				this.iLdapConn.lookup(var5);
			} catch (NamingException var9) {
				throw new DynamicUpdateConfigException("BASE_ENTRY_NOT_FOUND_IN_REPOSITORY",
						WIMMessageHelper.generateMsgParms(var4, this.iReposId), Level.SEVERE, CLASSNAME,
						"dynamicUpdateConfig");
			}

			this.iLdapConfigMgr.addBaseEntry(var4, var5);
		} else if ("websphere.usermanager.serviceprovider.add.entityconfig".equalsIgnoreCase(var1)) {
			Map var10 = (Map) var2.get("DYNA_CONFIG_KEY_ENTITY_CONFIGS");
			if (var10 != null) {
				Set var12 = var10.keySet();
				Iterator var6 = var12.iterator();

				while (var6.hasNext()) {
					String var7 = (String) var6.next();
					if (this.iReposId.equals(var7)) {
						DataObject var8 = (DataObject) var10.get(var7);
						this.iLdapConfigMgr.addLdapEntity(var8);
					}
				}
			}
		} else if ("websphere.usermanager.serviceprovider.add.propertyconfig".equalsIgnoreCase(var1)) {
			DataObject var11 = (DataObject) var2.get("DYNA_CONFIG_KEY_PROP_CONFIG");
			this.iLdapConfigMgr.addAttribute(var11);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "WIM_SPI dynamicUpdateConfig");
		}

	}

	private List getDynamicMembers(Attribute var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "getDynamicMembers", WIMMessageHelper.generateMsgParms(var1));
		}

		ArrayList var3 = new ArrayList();
		if (var1 != null) {
			try {
				NamingEnumeration var4 = var1.getAll();

				label65 : while (true) {
					LdapURL var6;
					do {
						while (true) {
							if (!var4.hasMoreElements()) {
								break label65;
							}

							String var5 = (String) ((String) var4.nextElement());
							if (var5 != null) {
								var6 = new LdapURL(var5);
								break;
							}

							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "getDynamicMembers", "LDAP URL=null.");
							}
						}
					} while (!var6.parsedOK());

					byte var7 = 0;
					String var8 = var6.get_scope();
					if (var8 != null) {
						if (var8.compareToIgnoreCase("base") == 0) {
							var7 = 0;
						} else if (var8.compareToIgnoreCase("one") == 0) {
							var7 = 1;
						} else if (var8.compareToIgnoreCase("sub") == 0) {
							var7 = 2;
						}
					}

					String var9 = var6.get_filter();
					if (var9 == null) {
						var9 = "(objectClass=*)";
					}

					String var10 = var6.get_dn();
					String[] var11 = var6.get_attributes();
					NamingEnumeration var12 = this.iLdapConn.search(var10, var9, var7, var11);

					while (var12.hasMoreElements()) {
						SearchResult var13 = (SearchResult) var12.nextElement();
						if (var13 != null) {
							String var14 = LdapHelper.prepareDN(var13.getName(), var10);
							var3.add(var14);
						}
					}
				}
			} catch (NamingException var15) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var15.toString(true)), Level.SEVERE, CLASSNAME,
						"getDynamicMembers");
			}
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "getDynamicMembers");
		}

		return var3;
	}

	private String getCallerUniqueName() throws WIMApplicationException {
		boolean var2 = trcLogger.isLoggable(Level.FINER);
		if (var2) {
			trcLogger.entering(CLASSNAME, "getCallerUniqueName()");
		}

		String var3 = null;
		Subject var4 = null;
		WSCredential var5 = null;

		try {
			if ((var4 = WSSubject.getRunAsSubject()) == null) {
				var4 = WSSubject.getCallerSubject();
			}

			if (var4 != null) {
				Iterator var6 = var4.getPublicCredentials(WSCredential.class).iterator();
				if (var6.hasNext()) {
					var5 = (WSCredential) var6.next();
				}
			}

			if (var5 == null) {
				return null;
			}

			var3 = var5.getUniqueSecurityName();
		} catch (Exception var7) {
			return null;
		}

		if (var2) {
			trcLogger.exiting(CLASSNAME, "getCallerUniqueName()", "#Unique name from subject " + var3);
		}

		return var3;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = LdapAdapter.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
	}
}