package com.ibm.ejs.container;

public class UserActionException extends Exception {
	private static final long serialVersionUID = -6645328035635864281L;
}