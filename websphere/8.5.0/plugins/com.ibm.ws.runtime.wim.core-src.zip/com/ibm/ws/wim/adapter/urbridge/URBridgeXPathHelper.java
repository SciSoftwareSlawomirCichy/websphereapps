package com.ibm.ws.wim.adapter.urbridge;

import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.SearchControlException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.xpath.TokenMgrError;
import com.ibm.ws.wim.xpath.WIMXPathInterpreter;
import com.ibm.ws.wim.xpath.mapping.datatype.PropertyNode;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;
import com.ibm.ws.wim.xpath.util.MetadataMapper;
import commonj.sdo.Property;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class URBridgeXPathHelper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	private static final String CLASSNAME = URBridgeXPathHelper.class.getName();
	private static final Logger trcLogger;
	private List entityTypes = null;
	private XPathNode node = null;

	public URBridgeXPathHelper() {
	}

	public URBridgeXPathHelper(String var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "<init>", "searchExpr=" + var1);
		}

		this.parseSearchExpression(var1);
	}

	public List getEntityTypes() {
		return this.entityTypes;
	}

	public XPathNode getNode() {
		return this.node;
	}

	public void parseSearchExpression(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "parseSearchExpression", "parsing " + var1);
		}

		try {
			if (var1 != null && var1.trim().length() != 0) {
				WIMXPathInterpreter var3 = new WIMXPathInterpreter(new StringReader(var1));
				this.node = var3.parse((MetadataMapper) null);
				this.entityTypes = var3.getEntityTypes();
				HashMap var4 = new HashMap();
				if (this.node != null) {
					SchemaManager var5 = SchemaManager.singleton();
					Iterator var6 = this.node.getPropertyNodes(var4);
					if (var6.hasNext()) {
						PropertyNode var7 = (PropertyNode) var6.next();
						this.node = var7;
						var7.setName(this.removeNamespace(var7.getName()));
						String var8 = var7.getName();
						Property var9 = null;
						Object var10 = null;

						String var12;
						for (Iterator var11 = this.entityTypes.iterator(); var11.hasNext()
								&& var9 == null; var9 = var5.getProperty(var12, var8)) {
							var12 = (String) var11.next();
							if (var12.equalsIgnoreCase("LoginAccount")) {
								var12 = "PersonAccount";
							}
						}

						if (var9 == null) {
							throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
									WIMMessageHelper.generateMsgParms(var8, this.entityTypes), CLASSNAME,
									"parseSearchExpression");
						}
					}
				}

			}
		} catch (Exception var13) {
			throw new WIMApplicationException("MALFORMED_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var1),
					Level.WARNING, CLASSNAME, "parseSearchExpression", var13);
		} catch (TokenMgrError var14) {
			throw new SearchControlException("INVALID_SEARCH_EXPRESSION", WIMMessageHelper.generateMsgParms(var1),
					CLASSNAME, "parseSearchExpression", var14);
		}
	}

	public String removeNamespace(String var1) {
		String var2 = var1.replace('\'', ' ').trim();
		int var3 = var2.indexOf(":");
		if (var3 > 0) {
			var2 = var2.substring(var3 + 1);
		}

		return var2;
	}

	public String getExpression() throws Exception {
		boolean var2 = trcLogger.isLoggable(Level.FINEST);
		if (var2) {
			trcLogger.logp(Level.FINE, CLASSNAME, "getExpression", this.node.toString());
		}

		switch (this.node.getNodeType()) {
			case 0 :
				return this.getExpression((PropertyNode) this.node);
			case 1 :
			case 2 :
			default :
				return "";
		}
	}

	private String getExpression(PropertyNode var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getExpression", "propNode " + var1);
		}

		String var4 = (String) var1.getValue();
		if (var3) {
			trcLogger.exiting(CLASSNAME, "getExpression", "pattern=" + var4);
		}

		return var4;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}