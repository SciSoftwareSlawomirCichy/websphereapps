package com.ibm.ws.wim.env.was;

import com.ibm.websphere.cache.DistributedObjectCache;
import com.ibm.websphere.cache.DynamicCacheAccessor;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.env.ICacheUtil;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.wsspi.cache.DistributedObjectCacheFactory;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CacheUtilImpl implements ICacheUtil {
	static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;
	private DistributedObjectCache cache = null;
	private static Map<String, Boolean> isDynaCacheServiceStarted;

	public boolean isCacheInitialized() {
		return this.cache != null;
	}

	public boolean isCacheAvailable() {
		String var2 = DomainManagerUtils.getDomainId();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "isCacheAvailable", "domainId=" + var2);
		}

		if (isDynaCacheServiceStarted.get(var2) == null) {
			isDynaCacheServiceStarted.put(var2, new Boolean(false));
		}

		if ((Boolean) isDynaCacheServiceStarted.get(var2)) {
			return true;
		} else {
			try {
				Class.forName("com.ibm.websphere.cache.DynamicCacheAccessor");

				try {
					this.initialize("WIMInitCache", 1, false, 2);
					isDynaCacheServiceStarted.put(var2, new Boolean(true));
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.logp(Level.FINER, CLASSNAME, "isCacheAvailable",
								"isDynaCacheServiceStarted=" + isDynaCacheServiceStarted);
					}
				} catch (NullPointerException var4) {
					;
				}
			} catch (ClassNotFoundException var5) {
				;
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "isCacheAvailable");
			}

			return (Boolean) isDynaCacheServiceStarted.get(var2);
		}
	}

	public int getNotSharedInt() {
		return 1;
	}

	public int getSharedPushInt() {
		return 2;
	}

	public int getSharedPushPullInt() {
		return 4;
	}

	public void setSharingPolicy(int var1) {
		this.cache.setSharingPolicy(var1);
	}

	public int getSharingPolicy() {
		return this.cache.getSharingPolicy();
	}

	public void setTimeToLive(int var1) {
		this.cache.setTimeToLive(var1);
	}

	public Object get(Object var1) {
		return this.cache.get(var1);
	}

	public Object put(Object var1, Object var2) {
		return this.cache.put(var1, var2);
	}

	public Object put(Object var1, Object var2, int var3, int var4, int var5, Object[] var6) {
		return this.cache.put(var1, var2, var3, var4, var5, var6);
	}

	public void invalidate(Object var1) {
		this.cache.invalidate(var1);
	}

	public int size() {
		return this.cache.size();
	}

	public int size(boolean var1) {
		return this.cache.size(var1);
	}

	public void clear() {
		this.cache.clear();
	}

	public boolean isEmpty() {
		return this.cache.isEmpty();
	}

	public boolean isEmpty(boolean var1) {
		return this.cache.isEmpty(var1);
	}

	public boolean containsKey(Object var1) {
		return this.cache.containsKey(var1);
	}

	public boolean containsKey(Object var1, boolean var2) {
		return this.cache.containsKey(var1, var2);
	}

	public Set keySet() {
		return this.cache.keySet();
	}

	public Set keySet(boolean var1) {
		return this.cache.keySet(var1);
	}

	public boolean containsValue(Object var1) {
		return this.cache.containsValue(var1);
	}

	public Set entrySet() {
		return this.cache.entrySet();
	}

	public void putAll(Map var1) {
		this.cache.putAll(var1);
	}

	public Object remove(Object var1) {
		return this.cache.remove(var1);
	}

	public Collection values() {
		return this.cache.values();
	}

	public ICacheUtil initialize(String var1, int var2, boolean var3) {
		return this.initialize(var1, var2, var3, 2);
	}

	public ICacheUtil initialize(String var1, int var2, boolean var3, int var4) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize",
					"cacheName=" + var1 + ", cacheSize=" + var2 + ", diskOffLoad=" + var3 + ", sharingPolicy=" + var4);
		}

		if (DynamicCacheAccessor.isCachingEnabled()) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initialize", "caching enabled, init cache.");
			}

			Properties var6 = new Properties();
			var6.put("com.ibm.ws.cache.CacheConfig.cacheSize", String.valueOf(var2));
			var6.put("com.ibm.ws.cache.CacheConfig.enableDiskOffload", String.valueOf(var3));
			this.cache = DistributedObjectCacheFactory.getMap(var1, var6);
			if (this.cache != null) {
				this.cache.setSharingPolicy(var4);
				trcLogger.logp(Level.FINE, CLASSNAME, "initialize", "DistributedObjectCache found");
			} else {
				trcLogger.logp(Level.FINE, CLASSNAME, "initialize", "DistributedObjectCache NOT found");
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize", "cache=" + this.cache);
		}

		return this.cache != null ? this : null;
	}

	public int getSharingPolicyInt(String var1) {
		byte var2 = 1;
		if ("none".equalsIgnoreCase(var1)) {
			var2 = 1;
		} else if ("push".equalsIgnoreCase(var1)) {
			var2 = 2;
		} else if ("push_pull".equalsIgnoreCase(var1)) {
			var2 = 4;
		}

		return var2;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010;
		CLASSNAME = CacheUtilImpl.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		isDynaCacheServiceStarted = Collections.synchronizedMap(new HashMap());
	}
}