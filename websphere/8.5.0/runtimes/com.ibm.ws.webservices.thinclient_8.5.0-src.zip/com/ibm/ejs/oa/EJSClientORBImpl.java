package com.ibm.ejs.oa;

import java.applet.Applet;
import java.util.Properties;

class EJSClientORBImpl extends EJSORBImpl {
	EJSClientORBImpl() {
		this((String) null, -1, (Properties) null);
	}

	EJSClientORBImpl(String bootstrapHost, int bootstrapPort, Properties userProps) {
		this((Applet) null, bootstrapHost, bootstrapPort, userProps);
	}

	EJSClientORBImpl(Applet applet, String bootstrapHost, int bootstrapPort, Properties userProps) {
		Properties orbProperties = new Properties(defaultProperties);
		if (userProps != null) {
			orbProperties.putAll(userProps);
		}

		this.initializeORB(applet, bootstrapHost, bootstrapPort, userProps);
	}

	void terminate() {
	}
}