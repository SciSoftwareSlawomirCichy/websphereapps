package com.ibm.icu.text;

import com.ibm.icu.impl.Normalizer2Impl.UTF16Plus;
import com.ibm.icu.text.NormalizationTransliterator.1;
import com.ibm.icu.text.NormalizationTransliterator.2;
import com.ibm.icu.text.NormalizationTransliterator.3;
import com.ibm.icu.text.NormalizationTransliterator.4;
import com.ibm.icu.text.NormalizationTransliterator.5;
import com.ibm.icu.text.NormalizationTransliterator.6;
import com.ibm.icu.text.Transliterator.Position;

final class NormalizationTransliterator extends Transliterator {
	private final Normalizer2 norm2;

	static void register() {
      Transliterator.registerFactory("Any-NFC", new 1());
      Transliterator.registerFactory("Any-NFD", new 2());
      Transliterator.registerFactory("Any-NFKC", new 3());
      Transliterator.registerFactory("Any-NFKD", new 4());
      Transliterator.registerFactory("Any-FCD", new 5());
      Transliterator.registerFactory("Any-FCC", new 6());
      Transliterator.registerSpecialInverse("NFC", "NFD", true);
      Transliterator.registerSpecialInverse("NFKC", "NFKD", true);
      Transliterator.registerSpecialInverse("FCC", "NFD", false);
      Transliterator.registerSpecialInverse("FCD", "FCD", false);
   }

	private NormalizationTransliterator(String id, Normalizer2 n2) {
		super(id, (UnicodeFilter) null);
		this.norm2 = n2;
	}

	protected void handleTransliterate(Replaceable text, Position offsets, boolean isIncremental) {
		int start = offsets.start;
		int limit = offsets.limit;
		if (start < limit) {
			StringBuilder segment = new StringBuilder();
			StringBuilder normalized = new StringBuilder();
			int c = text.char32At(start);

			do {
				int prev = start;
				segment.setLength(0);

				do {
					segment.appendCodePoint(c);
					start += Character.charCount(c);
				} while (start < limit && !this.norm2.hasBoundaryBefore(c = text.char32At(start)));

				if (start == limit && isIncremental && !this.norm2.hasBoundaryAfter(c)) {
					start = prev;
					break;
				}

				this.norm2.normalize(segment, normalized);
				if (!UTF16Plus.equal(segment, normalized)) {
					text.replace(prev, start, normalized.toString());
					int delta = normalized.length() - (start - prev);
					start += delta;
					limit += delta;
				}
			} while (start < limit);

			offsets.start = start;
			offsets.contextLimit += limit - offsets.limit;
			offsets.limit = limit;
		}
	}
}