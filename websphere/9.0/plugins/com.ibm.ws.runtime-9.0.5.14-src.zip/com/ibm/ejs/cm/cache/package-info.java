package com.ibm.ejs.cm.cache;

interface package-info {
}