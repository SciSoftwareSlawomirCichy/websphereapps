package com.ibm.ejs.container.drs.ws390;

import com.ibm.CORBA.iiop.ORB;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.ws.util.PlatformHelperFactory;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SfPlatformHelper {
	private static boolean initialized = false;
	private static Integer lock = new Integer(0);
	private static boolean _is_zOS = false;
	private static boolean _is_zOS_servant = false;
	private static boolean _is_zOS_controller = false;
	private static String processType = null;
	private static TraceComponent tc = Tr.register(SfPlatformHelper.class, "EJBDRSCache",
			"com.ibm.ejs.container.container");
	public static final String EJBCONTAINER_ENABLE_BASE_REPLICATION = "EJBContainerEnableUnmanagedServerReplication";
	private static boolean isBaseServerReplicationEnabled = false;
	private static boolean isBaseServer = false;
	private static boolean _loggedVersion = false;

	public static void init() {
		String m = "SfPlatformHelper.init: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.init: Entry.");
		}

		Integer var1 = lock;
		synchronized (lock) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled() && !_loggedVersion) {
				Tr.debug(tc, "SfPlatformHelper.init: Version 1.4 10/27/09 17:46:17");
				_loggedVersion = true;
			}

			if (!initialized) {
				processType = AdminServiceFactory.getAdminService().getProcessType();
				if (processType != null) {
					isBaseServer = processType.equals("UnManagedProcess");
				}

				String enableBaseReplication = System.getProperty("EJBContainerEnableUnmanagedServerReplication");
				if (enableBaseReplication != null && enableBaseReplication.equals("true")) {
					isBaseServerReplicationEnabled = true;
				}

				_is_zOS = PlatformHelperFactory.getPlatformHelper().isZOS();
				if (_is_zOS) {
					_is_zOS_controller = PlatformHelperFactory.getPlatformHelper().isControlJvm();
					_is_zOS_servant = PlatformHelperFactory.getPlatformHelper().isServantJvm();
				} else {
					_is_zOS_controller = false;
					_is_zOS_servant = false;
				}

				initialized = true;
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfPlatformHelper.init: _is_zOS = " + _is_zOS);
					Tr.debug(tc, "SfPlatformHelper.init: _is_zOS_controller = " + _is_zOS_controller);
					Tr.debug(tc, "SfPlatformHelper.init: _is_zOS_servant = " + _is_zOS_servant);
					Tr.debug(tc, "SfPlatformHelper.init:  Process Type = " + processType);
					Tr.debug(tc, "SfPlatformHelper.init:  enableBaseReplication = "
							+ (enableBaseReplication == null ? "null" : enableBaseReplication));
					Tr.debug(tc, "SfPlatformHelper.init:  isBaseServerReplicationEnabled = "
							+ isBaseServerReplicationEnabled);
					Tr.debug(tc, "SfPlatformHelper.init:  isBaseServer = " + isBaseServer);
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.init: Exit.");
		}

	}

	public static boolean isZOS() {
		String m = "SfPlatformHelper.isZOS: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.isZOS: Entry.");
		}

		if (!initialized) {
			init();
		}

		boolean rc = _is_zOS;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.isZOS: Exit - " + rc);
		}

		return rc;
	}

	public static boolean isZOS_Controller() {
		String m = "SfPlatformHelper.isZOS_Controller: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.isZOS_Controller: Entry.");
		}

		if (!initialized) {
			init();
		}

		boolean rc = _is_zOS && _is_zOS_controller;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.isZOS_Controller: Exit - " + rc);
		}

		return rc;
	}

	public static boolean isZOS_Servant() {
		String m = "SfPlatformHelper.isZOS_Servant: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.isZOS_Servant: Entry.");
		}

		if (!initialized) {
			init();
		}

		boolean rc = _is_zOS && _is_zOS_servant;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.isZOS_Servant: Exit - " + rc);
		}

		return rc;
	}

	public static String getZOSUniqueId() {
		String m = "SfPlatformHelper.getZOSUniqueId: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.getZOSUniqueId: Entry.");
		}

		String rc = null;
		if (!initialized) {
			init();
		}

		if (_is_zOS) {
			rc = PlatformHelperFactory.getPlatformHelper().getUniqueId();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.getZOSUniqueId: Exit - unique id " + rc);
		}

		return rc;
	}

	public static boolean isBaseServer() {
		String m = "SfPlatformHelper.isBaseServer: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.isBaseServer: Entry.");
		}

		if (!initialized) {
			init();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.isBaseServer: Exit - isBaseServer = " + isBaseServer);
		}

		return isBaseServer;
	}

	public static boolean isZOSBaseServer() {
		String m = "SfPlatformHelper.isZOSBaseServer: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.isZOSBaseServer: Entry.");
		}

		boolean rc = false;
		if (!initialized) {
			init();
		}

		rc = _is_zOS && isBaseServer;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.isZOSBaseServer: Exit - isZOSBaseServer = " + rc);
		}

		return rc;
	}

	public static boolean isBaseServerReplicationEnabled() {
		String m = "SfPlatformHelper.isBaseServerReplicationEnabled: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.isBaseServerReplicationEnabled: Entry.");
		}

		if (!initialized) {
			init();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.isBaseServerReplicationEnabled: Exit - isBaseServerReplicationEnabled = "
					+ isBaseServerReplicationEnabled);
		}

		return isBaseServerReplicationEnabled;
	}

	public static boolean isZOSBaseServerReplicationEnabled() {
		String m = "SfPlatformHelper.isZOSBaseServerReplicationEnabled: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.isZOSBaseServerReplicationEnabled: Entry.");
		}

		if (!initialized) {
			init();
		}

		boolean rc = _is_zOS && isBaseServer && isBaseServerReplicationEnabled;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc,
					"SfPlatformHelper.isZOSBaseServerReplicationEnabled: Exit - isZOSBaseServerReplicationEnabled = "
							+ rc);
		}

		return rc;
	}

	public static String getZOSStoken() {
		String m = "SfPlatformHelper.getZOSServantToken: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.getZOSServantToken: Entry.");
		}

		String rc = null;
		if (!initialized) {
			init();
		}

		if (_is_zOS) {
			rc = PlatformHelperFactory.getPlatformHelper().getServantToken();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.getZOSServantToken: Exit - stoken = " + rc);
		}

		return rc;
	}

	public static String getZOSServantToken() {
		return getZOSStoken();
	}

	public static ORB getZOSORB() {
		String m = "SfPlatformHelper.init: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.init: Entry.");
		}

		ORB rc = null;
		if (!initialized) {
			init();
		}

		if (_is_zOS) {
			rc = (ORB) PlatformHelperFactory.getPlatformHelper().getGlobalORB();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.init: Exit.");
		}

		return rc;
	}

	public static byte[] getByteArray(Object _obj) throws IOException {
		String m = "SfPlatformHelper.init: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.init: Entry.");
		}

		byte[] byteArray = new byte[0];
		if (_obj != null) {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream objectOut = new ObjectOutputStream(bos);
			objectOut.writeObject(_obj);
			byteArray = bos.toByteArray();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.init: Exit.");
		}

		return byteArray;
	}

	public static Object getObject(byte[] _bytes) throws IOException, ClassNotFoundException {
		String m = "SfPlatformHelper.getObject: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfPlatformHelper.getObject: Entry.");
		}

		Object obj = null;
		if (_bytes != null && _bytes.length > 0) {
			ByteArrayInputStream bis = new ByteArrayInputStream(_bytes);
			ObjectInputStream objectIn = new ObjectInputStream(bis);
			obj = objectIn.readObject();
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfPlatformHelper.getObject: Exit.");
		}

		return obj;
	}
}