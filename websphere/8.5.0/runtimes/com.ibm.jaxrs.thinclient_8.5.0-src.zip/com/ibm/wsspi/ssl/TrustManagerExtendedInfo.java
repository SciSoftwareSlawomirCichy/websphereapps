package com.ibm.wsspi.ssl;

import java.util.Map;
import java.util.Properties;

public interface TrustManagerExtendedInfo {
	void setCustomProperties(Properties var1);

	void setExtendedInfo(Map var1);

	void setSSLConfig(Properties var1);
}