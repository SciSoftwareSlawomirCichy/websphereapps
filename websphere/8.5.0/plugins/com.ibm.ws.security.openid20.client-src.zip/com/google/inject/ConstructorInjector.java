package com.google.inject;

import com.google.inject.internal.ConstructionContext;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.ImmutableSet;
import com.google.inject.internal.InternalContext;
import com.google.inject.spi.InjectionPoint;
import java.lang.reflect.InvocationTargetException;

class ConstructorInjector<T> {
	private final ImmutableSet<InjectionPoint> injectableMembers;
	private final SingleParameterInjector<?>[] parameterInjectors;
	private final ConstructionProxy<T> constructionProxy;
	private final MembersInjectorImpl<T> membersInjector;

	ConstructorInjector(ImmutableSet<InjectionPoint> injectableMembers, ConstructionProxy<T> constructionProxy,
			SingleParameterInjector<?>[] parameterInjectors, MembersInjectorImpl<T> membersInjector)
			throws ErrorsException {
		this.injectableMembers = injectableMembers;
		this.constructionProxy = constructionProxy;
		this.parameterInjectors = parameterInjectors;
		this.membersInjector = membersInjector;
	}

	public ImmutableSet<InjectionPoint> getInjectableMembers() {
		return this.injectableMembers;
	}

	ConstructionProxy<T> getConstructionProxy() {
		return this.constructionProxy;
	}

	Object construct(Errors errors, InternalContext context, Class<?> expectedType) throws ErrorsException {
		ConstructionContext<T> constructionContext = context.getConstructionContext(this);
		if (constructionContext.isConstructing()) {
			return constructionContext.createProxy(errors, expectedType);
		} else {
			T t = constructionContext.getCurrentReference();
			if (t != null) {
				return t;
			} else {
				Object var18;
				try {
					constructionContext.startConstruction();

					try {
						Object[] parameters = SingleParameterInjector.getAll(errors, context, this.parameterInjectors);
						t = this.constructionProxy.newInstance(parameters);
						constructionContext.setProxyDelegates(t);
					} finally {
						constructionContext.finishConstruction();
					}

					constructionContext.setCurrentReference(t);
					this.membersInjector.injectMembers(t, errors, context);
					this.membersInjector.notifyListeners(t, errors);
					var18 = t;
				} catch (InvocationTargetException var16) {
					Throwable cause = var16.getCause() != null ? var16.getCause() : var16;
					throw errors.withSource(this.constructionProxy.getInjectionPoint())
							.errorInjectingConstructor((Throwable) cause).toException();
				} finally {
					constructionContext.removeCurrentReference();
				}

				return var18;
			}
		}
	}
}