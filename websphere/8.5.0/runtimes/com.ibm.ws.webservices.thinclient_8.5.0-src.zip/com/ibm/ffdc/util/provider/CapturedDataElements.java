package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.config.Formattable;
import com.ibm.ffdc.config.IncidentStream;

public class CapturedDataElements implements Formattable {
	final Object[] cde;
	public static final String CAPTURED_DATA_ELEMENTS_BEGIN = "CapturedDataElements begin";
	public static final String CAPTURED_DATA_ELEMENTS_END = "CapturedDataElements end";
	public static final String ARG = "arg";

	public CapturedDataElements(Object[] cde) {
		this.cde = cde;
	}

	protected Object[] getCapturedDataElements() {
		return this.cde;
	}

	public void formatTo(IncidentStream is) {
		if (this.cde != null && this.cde.length != 0) {
			try {
				is.write((String) null, "CapturedDataElements begin");
				String arg = "arg";
				int length = this.cde.length;

				for (int i = 0; i < length; ++i) {
					Object o = this.cde[i];
					String label = arg + (length == 1 ? "" : i);
					is.write(label, o);
				}
			} finally {
				is.write((String) null, "CapturedDataElements end");
			}

		}
	}
}