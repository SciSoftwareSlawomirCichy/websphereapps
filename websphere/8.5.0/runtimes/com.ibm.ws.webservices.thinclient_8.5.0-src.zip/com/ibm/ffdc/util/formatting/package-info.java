package com.ibm.ffdc.util.formatting;

interface package-info {
}