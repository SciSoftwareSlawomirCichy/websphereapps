package com.ibm.ejs.container;

import java.io.Serializable;
import java.rmi.Remote;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import javax.rmi.CORBA.Tie;
import javax.rmi.CORBA.Util;
import org.omg.CORBA.BAD_OPERATION;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.CORBA.SystemException;
import org.omg.CORBA.portable.Delegate;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ResponseHandler;
import org.omg.CORBA.portable.UnknownException;
import org.omg.CORBA_2_3.portable.ObjectImpl;

public class _RemoteAsyncResultImpl_Tie extends ObjectImpl implements Tie {
	private RemoteAsyncResultImpl target = null;
	private ORB orb = null;
	private static final String[] _type_ids = new String[]{
			"RMI:com.ibm.ejs.container.RemoteAsyncResult:0000000000000000",
			"RMI:com.ibm.ejs.container.RemoteAsyncResultExtended:0000000000000000"};

	public void setTarget(Remote target) {
		this.target = (RemoteAsyncResultImpl) target;
	}

	public Remote getTarget() {
		return this.target;
	}

	public Object thisObject() {
		return this;
	}

	public void deactivate() {
		if (this.orb != null) {
			this.orb.disconnect(this);
			this._set_delegate((Delegate) null);
		}

	}

	public ORB orb() {
		return this._orb();
	}

	public void orb(ORB orb) {
		orb.connect(this);
	}

	public void _set_delegate(Delegate del) {
		super._set_delegate(del);
		if (del != null) {
			this.orb = this._orb();
		} else {
			this.orb = null;
		}

	}

	public String[] _ids() {
		return _type_ids;
	}

	public OutputStream _invoke(String method, InputStream _in, ResponseHandler reply) throws SystemException {
		try {
			org.omg.CORBA_2_3.portable.InputStream in = (org.omg.CORBA_2_3.portable.InputStream) _in;
			switch (method.length()) {
				case 5 :
					if (method.equals("get__")) {
						return this.get__(in, reply);
					}
				case 6 :
					if (method.equals("cancel")) {
						return this.cancel(in, reply);
					}
				case 9 :
					if (method.equals("_get_done")) {
						return this._get_done(in, reply);
					}
				case 13 :
					if (method.equals("waitForResult")) {
						return this.waitForResult(in, reply);
					}
				case 14 :
					if (method.equals("_get_cancelled")) {
						return this._get_cancelled(in, reply);
					}
				case 34 :
					if (method.equals("get__long_long__CORBA_WStringValue")) {
						return this.get__long_long__CORBA_WStringValue(in, reply);
					}
				default :
					throw new BAD_OPERATION();
			}
		} catch (SystemException var5) {
			throw var5;
		} catch (Throwable var6) {
			throw new UnknownException(var6);
		}
	}

	private OutputStream cancel(org.omg.CORBA_2_3.portable.InputStream in, ResponseHandler reply) throws Throwable {
		boolean arg0 = in.read_boolean();
		boolean result = this.target.cancel(arg0);
		OutputStream out = reply.createReply();
		out.write_boolean(result);
		return out;
	}

	private OutputStream get__(org.omg.CORBA_2_3.portable.InputStream in, ResponseHandler reply) throws Throwable {
		java.lang.Object result;
		String id;
		org.omg.CORBA_2_3.portable.OutputStream out;
		try {
			result = this.target.get();
		} catch (ExecutionException var7) {
			id = "IDL:java/util/concurrent/ExecutionEx:1.0";
			out = (org.omg.CORBA_2_3.portable.OutputStream) reply.createExceptionReply();
			out.write_string(id);
			out.write_value(var7, ExecutionException.class);
			return out;
		} catch (InterruptedException var8) {
			id = "IDL:java/lang/InterruptedEx:1.0";
			out = (org.omg.CORBA_2_3.portable.OutputStream) reply.createExceptionReply();
			out.write_string(id);
			out.write_value(var8, InterruptedException.class);
			return out;
		}

		OutputStream out = reply.createReply();
		Util.writeAny(out, result);
		return out;
	}

	private OutputStream get__long_long__CORBA_WStringValue(org.omg.CORBA_2_3.portable.InputStream in,
			ResponseHandler reply) throws Throwable {
		long arg0 = in.read_longlong();
		String arg1 = (String) in.read_value(String.class);

		java.lang.Object result;
		String id;
		org.omg.CORBA_2_3.portable.OutputStream out;
		try {
			result = this.target.get(arg0, arg1);
		} catch (ExecutionException var10) {
			id = "IDL:java/util/concurrent/ExecutionEx:1.0";
			out = (org.omg.CORBA_2_3.portable.OutputStream) reply.createExceptionReply();
			out.write_string(id);
			out.write_value(var10, ExecutionException.class);
			return out;
		} catch (InterruptedException var11) {
			id = "IDL:java/lang/InterruptedEx:1.0";
			out = (org.omg.CORBA_2_3.portable.OutputStream) reply.createExceptionReply();
			out.write_string(id);
			out.write_value(var11, InterruptedException.class);
			return out;
		} catch (TimeoutException var12) {
			id = "IDL:java/util/concurrent/TimeoutEx:1.0";
			out = (org.omg.CORBA_2_3.portable.OutputStream) reply.createExceptionReply();
			out.write_string(id);
			out.write_value(var12, TimeoutException.class);
			return out;
		}

		OutputStream out = reply.createReply();
		Util.writeAny(out, result);
		return out;
	}

	private OutputStream _get_cancelled(org.omg.CORBA_2_3.portable.InputStream in, ResponseHandler reply)
			throws Throwable {
		boolean result = this.target.isCancelled();
		OutputStream out = reply.createReply();
		out.write_boolean(result);
		return out;
	}

	private OutputStream _get_done(org.omg.CORBA_2_3.portable.InputStream in, ResponseHandler reply) throws Throwable {
		boolean result = this.target.isDone();
		OutputStream out = reply.createReply();
		out.write_boolean(result);
		return out;
	}

	private OutputStream waitForResult(org.omg.CORBA_2_3.portable.InputStream in, ResponseHandler reply)
			throws Throwable {
		long arg0 = in.read_longlong();

		java.lang.Object[] result;
		String id;
		org.omg.CORBA_2_3.portable.OutputStream out;
		try {
			result = this.target.waitForResult(arg0);
		} catch (ExecutionException var9) {
			id = "IDL:java/util/concurrent/ExecutionEx:1.0";
			out = (org.omg.CORBA_2_3.portable.OutputStream) reply.createExceptionReply();
			out.write_string(id);
			out.write_value(var9, ExecutionException.class);
			return out;
		} catch (InterruptedException var10) {
			id = "IDL:java/lang/InterruptedEx:1.0";
			out = (org.omg.CORBA_2_3.portable.OutputStream) reply.createExceptionReply();
			out.write_string(id);
			out.write_value(var10, InterruptedException.class);
			return out;
		}

		org.omg.CORBA_2_3.portable.OutputStream out = (org.omg.CORBA_2_3.portable.OutputStream) reply.createReply();
		out.write_value(this.cast_array(result), java.lang.Object[].class);
		return out;
	}

	private Serializable cast_array(java.lang.Object obj) {
		return (Serializable) obj;
	}
}