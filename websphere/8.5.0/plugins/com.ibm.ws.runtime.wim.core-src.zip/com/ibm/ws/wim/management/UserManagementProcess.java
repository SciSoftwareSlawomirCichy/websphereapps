package com.ibm.ws.wim.management;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.websphere.management.MBeanFactory;
import com.ibm.websphere.management.exception.AdminException;
import com.ibm.websphere.security.WSSecurityHelper;
import com.ibm.websphere.wim.ServiceProvider;
import com.ibm.websphere.wim.exception.NetworkConfigSyncException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.util.Routines;
import com.ibm.ws.exception.ComponentDisabledException;
import com.ibm.ws.exception.ConfigurationError;
import com.ibm.ws.exception.ConfigurationWarning;
import com.ibm.ws.exception.RuntimeError;
import com.ibm.ws.exception.RuntimeWarning;
import com.ibm.ws.management.AdminHelper;
import com.ibm.ws.wim.management.UserManagementProcess.1;
import com.ibm.ws.wim.management.UserManagementProcess.2;
import com.ibm.ws.wim.management.UserManagementProcess.3;
import com.ibm.ws.wim.management.UserManagementProcess.4;
import com.ibm.ws.wim.management.UserManagementProcess.5;
import com.ibm.ws.wim.security.authz.AuthPrivilegedException;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.wsspi.runtime.component.WsComponent;
import java.security.PrivilegedExceptionAction;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.InstanceAlreadyExistsException;
import javax.management.MalformedObjectNameException;
import javax.management.Notification;
import javax.management.NotificationFilter;
import javax.management.NotificationFilterSupport;
import javax.management.NotificationListener;
import javax.management.ObjectName;
import javax.management.QueryExp;

public class UserManagementProcess implements WsComponent, NotificationListener {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = UserManagementProcess.class.getName();
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static ObjectName umMBean;
	private String componentState;

	public String getName() {
		return CLASSNAME;
	}

	public String getState() {
		return this.componentState;
	}

	public void start() throws RuntimeError, RuntimeWarning {
		this.componentState = "STARTING";
		this.componentState = "STARTED";
	}

	public void stop() {
		this.componentState = "STOPPING";
		this.componentState = "STOPPED";
	}

	public void destroy() {
		this.componentState = "DESTROYING";
		this.componentState = "DESTROYED";
	}

	private void registerNotificationListenerToNode() {
		Routines.enterMethod(trcLogger, CLASSNAME, "registerNotificationListenerToNode", Level.FINEST);
		DynamicReloadManager var2 = DynamicReloadManager.singleton();
		Routines.exitMethod(trcLogger, CLASSNAME, "registerNotificationListenerToNode", Level.FINEST);
	}

	private void registerUserManagerMBean() throws AdminException {
		Routines.enterMethod(trcLogger, CLASSNAME, "registerUserManagerMBean", Level.FINEST);
		MBeanFactory var2 = AdminServiceFactory.getMBeanFactory();

		try {
			UserManagerMBean var3 = UserManagerMBean.getInstance();
			umMBean = var2.activateMBean("UserManagerMBean", var3, "UserManagerMBeanID",
					"com/ibm/ws/wim/management/UserManagerMBean.xml");
			var3.setObjectName(umMBean);
			Routines.logMessage(trcLogger, CLASSNAME, "registerUserManagerMBean", Level.FINE,
					"Activated UserManagerMBean (" + umMBean.toString() + ")");
		} catch (AdminException var4) {
			if (!(var4.getCause() instanceof InstanceAlreadyExistsException)) {
				throw var4;
			}

			Routines.logMessage(trcLogger, CLASSNAME, "registerUserManagerMBean", Level.FINE,
					"Caught exception: UserManagerMBean has already been activated");
		}

		Routines.exitMethod(trcLogger, CLASSNAME, "registerUserManagerMBean", Level.FINEST);
	}

	private void deregisterUserManagerMBean() throws AdminException {
		if (umMBean != null) {
			MBeanFactory var1 = AdminServiceFactory.getMBeanFactory();
			var1.deactivateMBean(umMBean);
		}

	}

	private boolean isAdminAgentMode() {
		return "AdminAgent".equals(AdminServiceFactory.getAdminService().getProcessType());
	}

	private boolean isRegisteredWithAdminAgent() {
		if ("UnManagedProcess".equals(AdminServiceFactory.getAdminService().getProcessType())) {
			try {
				return AdminHelper.getInstance().isCellRegistered();
			} catch (Exception var2) {
				trcLogger.logp(Level.FINE, CLASSNAME, "isRegisteredWithAdminAgent",
						"Exception determining if the cell is registered or not", var2);
			}
		}

		return false;
	}

	public void initialize(Object var1) throws ComponentDisabledException, ConfigurationWarning, ConfigurationError {
		this.componentState = "INITIALIZING";
		Routines.enterMethod(trcLogger, CLASSNAME, "initialize", Level.FINEST);
		AdminService var3 = AdminServiceFactory.getAdminService();
		if (this.isNDProcessType(var3.getProcessType()) || this.isAdminAgentMode()
				|| this.isRegisteredWithAdminAgent()) {
			this.startBootstrapSequence();
		}

		this.componentState = "INITIALIZED";
		Routines.exitMethod(trcLogger, CLASSNAME, "initialize", Level.FINEST);
	}

	private boolean isNDProcessType(String var1) {
		return var1.equals("DeploymentManager") || var1.equals("ManagedProcess") || var1.equals("NodeAgent");
	}

	private void startBootstrapSequence() {
		Routines.enterMethod(trcLogger, CLASSNAME, "startBootstrapSequence", Level.FINEST);
		msgLogger.log(Level.INFO, "DYNAMIC_RELOAD_START_BOOTSTRAP");

		try {
			NotificationFilterSupport var2 = new NotificationFilterSupport();
			var2.enableType("j2ee.state.running");
			AdminService var3 = AdminServiceFactory.getAdminService();
			String var4 = "WebSphere:type=Server,node=" + var3.getNodeName() + ",process=" + var3.getProcessName()
					+ ",*";
			ObjectName var5 = new ObjectName(var4);
			Routines.logMessage(trcLogger, CLASSNAME, "startBootstrapSequence", Level.FINE,
					"Registering listener for local server MBean (" + var4 + ")");
			var3.addNotificationListenerExtended(var5, this, var2, (Object) null);
		} catch (MalformedObjectNameException var6) {
			msgLogger.logp(Level.SEVERE, CLASSNAME, "startBootstrapSequence", "DYNAMIC_RELOAD_INIT_FAILURE");
			Routines.logException(trcLogger, CLASSNAME, "startBootstrapSequence", Level.SEVERE,
					"DYNAMIC_RELOAD_INIT_FAILURE", var6);
		}

		msgLogger.log(Level.INFO, "DYNAMIC_RELOAD_WAIT_NOTIF_SERVER_STARTED");
		Routines.exitMethod(trcLogger, CLASSNAME, "startBootstrapSequence", Level.FINEST);
	}

	public void handleNotification(Notification var1, Object var2) {
		Routines.enterMethod(trcLogger, CLASSNAME, "handleNotification", Level.FINEST);
		if (var1.getType().equals("j2ee.state.running")) {
			msgLogger.log(Level.INFO, "DYNAMIC_RELOAD_RECEIVED_NOTIF_SERVER_STARTED");
			AdminService var4 = AdminServiceFactory.getAdminService();
			String var5 = var4.getProcessType();
			if (WSSecurityHelper.isGlobalSecurityEnabled()) {
				Routines.logMessage(trcLogger, CLASSNAME, "handleNotification", Level.FINE,
						"Starting the component because global security is enabled");

				try {
					ServiceProvider.singleton();
					if (var5.equals("ManagedProcess") || var5.equals("NodeAgent")
							|| this.isRegisteredWithAdminAgent()) {
						this.registerNotificationListenerToNode();
						this.registerUserManagerMBean();
					}
				} catch (Exception var7) {
					msgLogger.logp(Level.SEVERE, CLASSNAME, "handleNotification", "DYNAMIC_RELOAD_INIT_FAILURE");
					Routines.logException(trcLogger, CLASSNAME, "handleNotification", Level.SEVERE,
							"DYNAMIC_RELOAD_INIT_FAILURE", var7);
				}

				msgLogger.log(Level.INFO, "DYNAMIC_RELOAD_INIT_SUCCESS");
			} else {
				Routines.logMessage(trcLogger, CLASSNAME, "handleNotification", Level.FINE,
						"Component will NOT be started because global security is disabled");
			}
		}

		Routines.exitMethod(trcLogger, CLASSNAME, "handleNotification", Level.FINEST);
	}

	static AdminClient getDeploymentManagerAdminClient() throws NetworkConfigSyncException {
      try {
         return (AdminClient)ProfileSecurityManager.singleton().runAsSuperUser(new 1());
      } catch (Exception var1) {
         Exception var0 = var1;
         if (var1 instanceof AuthPrivilegedException) {
            var0 = (Exception)var1.getCause();
         }

         throw new NetworkConfigSyncException(var0.getMessage(), Level.SEVERE, CLASSNAME, "getDeploymentManagerAdminClient", var0);
      }
   }

	static void suAddNotificationListenerExtended(AdminService var0, ObjectName var1, NotificationListener var2, NotificationFilter var3, Object var4) throws NetworkConfigSyncException {
      try {
         ProfileSecurityManager.singleton().runAsSuperUser(new 2(var0, var1, var2, var3, var4));
      } catch (Exception var6) {
         Exception var5 = var6;
         if (var6 instanceof AuthPrivilegedException) {
            var5 = (Exception)var6.getCause();
         }

         throw new NetworkConfigSyncException(var5.getMessage(), Level.SEVERE, CLASSNAME, "suAddNotificationListenerExtended", var5);
      }
   }

	static Set suQueryNames(AdminService var0, ObjectName var1, QueryExp var2) throws NetworkConfigSyncException {
      try {
         return (Set)ProfileSecurityManager.singleton().runAsSuperUser(new 3(var0, var1, var2));
      } catch (Exception var4) {
         Exception var3 = var4;
         if (var4 instanceof AuthPrivilegedException) {
            var3 = (Exception)var4.getCause();
         }

         throw new NetworkConfigSyncException(var3.getMessage(), Level.SEVERE, CLASSNAME, "suQueryNames", var3);
      }
   }

	static Object suInvokeAdminService(AdminService var0, ObjectName var1, String var2, Object[] var3, String[] var4) throws NetworkConfigSyncException {
      try {
         return ProfileSecurityManager.singleton().runAsSuperUser(new 4(var0, var1, var2, var3, var4));
      } catch (Exception var6) {
         Exception var5 = var6;
         if (var6 instanceof AuthPrivilegedException) {
            var5 = (Exception)var6.getCause();
         }

         throw new NetworkConfigSyncException(var5.getMessage(), Level.SEVERE, CLASSNAME, "suInvokeAdminService", var5);
      }
   }

	static Object runAsSuper(PrivilegedExceptionAction var0) throws Exception {
      try {
         return ProfileSecurityManager.singleton().runAsSuperUser(new 5(var0));
      } catch (Exception var2) {
         Exception var1 = var2;
         if (var2 instanceof AuthPrivilegedException) {
            var1 = (Exception)var2.getCause();
         }

         throw var1;
      }
   }

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
	}
}