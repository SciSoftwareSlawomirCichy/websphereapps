package com.google.inject.internal;

import com.google.inject.internal.ConstructionContext.DelegatingInvocationHandler;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ConstructionContext<T> {
	T currentReference;
	boolean constructing;
	List<DelegatingInvocationHandler<T>> invocationHandlers;

	public T getCurrentReference() {
		return this.currentReference;
	}

	public void removeCurrentReference() {
		this.currentReference = null;
	}

	public void setCurrentReference(T currentReference) {
		this.currentReference = currentReference;
	}

	public boolean isConstructing() {
		return this.constructing;
	}

	public void startConstruction() {
		this.constructing = true;
	}

	public void finishConstruction() {
		this.constructing = false;
		this.invocationHandlers = null;
	}

	public Object createProxy(Errors errors, Class<?> expectedType) throws ErrorsException {
		if (!expectedType.isInterface()) {
			throw errors.cannotSatisfyCircularDependency(expectedType).toException();
		} else {
			if (this.invocationHandlers == null) {
				this.invocationHandlers = new ArrayList();
			}

			DelegatingInvocationHandler<T> invocationHandler = new DelegatingInvocationHandler();
			this.invocationHandlers.add(invocationHandler);
			ClassLoader classLoader = BytecodeGen.getClassLoader(expectedType);
			return expectedType.cast(Proxy.newProxyInstance(classLoader, new Class[]{expectedType}, invocationHandler));
		}
	}

	public void setProxyDelegates(T delegate) {
		if (this.invocationHandlers != null) {
			Iterator i$ = this.invocationHandlers.iterator();

			while (i$.hasNext()) {
				DelegatingInvocationHandler<T> handler = (DelegatingInvocationHandler) i$.next();
				handler.setDelegate(delegate);
			}
		}

	}
}