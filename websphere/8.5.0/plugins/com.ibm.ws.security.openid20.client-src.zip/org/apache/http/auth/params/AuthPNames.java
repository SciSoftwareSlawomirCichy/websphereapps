package org.apache.http.auth.params;

public interface AuthPNames {
	String CREDENTIAL_CHARSET = "http.auth.credential-charset";
	String TARGET_AUTH_PREF = "http.auth.target-scheme-pref";
	String PROXY_AUTH_PREF = "http.auth.proxy-scheme-pref";
}