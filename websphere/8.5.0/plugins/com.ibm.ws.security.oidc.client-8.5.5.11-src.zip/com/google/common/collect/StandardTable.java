package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.base.Supplier;
import com.google.common.collect.StandardTable.1;
import com.google.common.collect.StandardTable.CellSet;
import com.google.common.collect.StandardTable.Column;
import com.google.common.collect.StandardTable.ColumnKeyIterator;
import com.google.common.collect.StandardTable.ColumnKeySet;
import com.google.common.collect.StandardTable.ColumnMap;
import com.google.common.collect.StandardTable.Row;
import com.google.common.collect.StandardTable.RowKeySet;
import com.google.common.collect.StandardTable.RowMap;
import com.google.common.collect.StandardTable.Values;
import com.google.common.collect.Table.Cell;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible
class StandardTable<R, C, V> implements Table<R, C, V>, Serializable {
	@GwtTransient
	final Map<R, Map<C, V>> backingMap;
	@GwtTransient
	final Supplier<? extends Map<C, V>> factory;
	private transient StandardTable<R, C, V>.CellSet cellSet;
	private transient StandardTable<R, C, V>.RowKeySet rowKeySet;
	private transient Set<C> columnKeySet;
	private transient StandardTable<R, C, V>.Values values;
	private transient StandardTable<R, C, V>.RowMap rowMap;
	private transient StandardTable<R, C, V>.ColumnMap columnMap;
	private static final long serialVersionUID = 0L;

	StandardTable(Map<R, Map<C, V>> backingMap, Supplier<? extends Map<C, V>> factory) {
		this.backingMap = backingMap;
		this.factory = factory;
	}

	public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey) {
		if (rowKey != null && columnKey != null) {
			Map<C, V> map = (Map) Maps.safeGet(this.backingMap, rowKey);
			return map != null && Maps.safeContainsKey(map, columnKey);
		} else {
			return false;
		}
	}

	public boolean containsColumn(@Nullable Object columnKey) {
		if (columnKey == null) {
			return false;
		} else {
			Iterator i$ = this.backingMap.values().iterator();

			Map map;
			do {
				if (!i$.hasNext()) {
					return false;
				}

				map = (Map) i$.next();
			} while (!Maps.safeContainsKey(map, columnKey));

			return true;
		}
	}

	public boolean containsRow(@Nullable Object rowKey) {
		return rowKey != null && Maps.safeContainsKey(this.backingMap, rowKey);
	}

	public boolean containsValue(@Nullable Object value) {
		if (value == null) {
			return false;
		} else {
			Iterator i$ = this.backingMap.values().iterator();

			Map map;
			do {
				if (!i$.hasNext()) {
					return false;
				}

				map = (Map) i$.next();
			} while (!map.containsValue(value));

			return true;
		}
	}

	public V get(@Nullable Object rowKey, @Nullable Object columnKey) {
		if (rowKey != null && columnKey != null) {
			Map<C, V> map = (Map) Maps.safeGet(this.backingMap, rowKey);
			return map == null ? null : Maps.safeGet(map, columnKey);
		} else {
			return null;
		}
	}

	public boolean isEmpty() {
		return this.backingMap.isEmpty();
	}

	public int size() {
		int size = 0;

		Map map;
		for (Iterator i$ = this.backingMap.values().iterator(); i$.hasNext(); size += map.size()) {
			map = (Map) i$.next();
		}

		return size;
	}

	public boolean equals(@Nullable Object obj) {
		if (obj == this) {
			return true;
		} else if (obj instanceof Table) {
			Table<?, ?, ?> other = (Table) obj;
			return this.cellSet().equals(other.cellSet());
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.cellSet().hashCode();
	}

	public String toString() {
		return this.rowMap().toString();
	}

	public void clear() {
		this.backingMap.clear();
	}

	private Map<C, V> getOrCreate(R rowKey) {
		Map<C, V> map = (Map) this.backingMap.get(rowKey);
		if (map == null) {
			map = (Map) this.factory.get();
			this.backingMap.put(rowKey, map);
		}

		return map;
	}

	public V put(R rowKey, C columnKey, V value) {
		Preconditions.checkNotNull(rowKey);
		Preconditions.checkNotNull(columnKey);
		Preconditions.checkNotNull(value);
		return this.getOrCreate(rowKey).put(columnKey, value);
	}

	public void putAll(Table<? extends R, ? extends C, ? extends V> table) {
		Iterator i$ = table.cellSet().iterator();

		while (i$.hasNext()) {
			Cell<? extends R, ? extends C, ? extends V> cell = (Cell) i$.next();
			this.put(cell.getRowKey(), cell.getColumnKey(), cell.getValue());
		}

	}

	public V remove(@Nullable Object rowKey, @Nullable Object columnKey) {
		if (rowKey != null && columnKey != null) {
			Map<C, V> map = (Map) Maps.safeGet(this.backingMap, rowKey);
			if (map == null) {
				return null;
			} else {
				V value = map.remove(columnKey);
				if (map.isEmpty()) {
					this.backingMap.remove(rowKey);
				}

				return value;
			}
		} else {
			return null;
		}
	}

	private Map<R, V> removeColumn(Object column) {
		Map<R, V> output = new LinkedHashMap();
		Iterator iterator = this.backingMap.entrySet().iterator();

		while (iterator.hasNext()) {
			Entry<R, Map<C, V>> entry = (Entry) iterator.next();
			V value = ((Map) entry.getValue()).remove(column);
			if (value != null) {
				output.put(entry.getKey(), value);
				if (((Map) entry.getValue()).isEmpty()) {
					iterator.remove();
				}
			}
		}

		return output;
	}

	private boolean containsMapping(Object rowKey, Object columnKey, Object value) {
		return value != null && value.equals(this.get(rowKey, columnKey));
	}

	private boolean removeMapping(Object rowKey, Object columnKey, Object value) {
		if (this.containsMapping(rowKey, columnKey, value)) {
			this.remove(rowKey, columnKey);
			return true;
		} else {
			return false;
		}
	}

	public Set<Cell<R, C, V>> cellSet() {
      StandardTable<R, C, V>.CellSet result = this.cellSet;
      return result == null ? (this.cellSet = new CellSet(this, (1)null)) : result;
   }

	public Map<C, V> row(R rowKey) {
		return new Row(this, rowKey);
	}

	public Map<R, V> column(C columnKey) {
		return new Column(this, columnKey);
	}

	public Set<R> rowKeySet() {
		Set<R> result = this.rowKeySet;
		return result == null ? (this.rowKeySet = new RowKeySet(this)) : result;
	}

	public Set<C> columnKeySet() {
      Set<C> result = this.columnKeySet;
      return result == null ? (this.columnKeySet = new ColumnKeySet(this, (1)null)) : result;
   }

	Iterator<C> createColumnKeyIterator() {
      return new ColumnKeyIterator(this, (1)null);
   }

	public Collection<V> values() {
      StandardTable<R, C, V>.Values result = this.values;
      return result == null ? (this.values = new Values(this, (1)null)) : result;
   }

	public Map<R, Map<C, V>> rowMap() {
		StandardTable<R, C, V>.RowMap result = this.rowMap;
		return result == null ? (this.rowMap = new RowMap(this)) : result;
	}

	public Map<C, Map<R, V>> columnMap() {
      StandardTable<R, C, V>.ColumnMap result = this.columnMap;
      return result == null ? (this.columnMap = new ColumnMap(this, (1)null)) : result;
   }
}