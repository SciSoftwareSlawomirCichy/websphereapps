package com.ibm.ws.wim.management;

import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.websphere.management.RuntimeCollaborator;
import com.ibm.websphere.management.exception.AdminException;
import com.ibm.websphere.wim.ServiceProvider;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.adapter.file.was.FileAdapter;
import commonj.sdo.DataObject;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.ObjectName;

public class FileAdapterMBeanImpl extends RuntimeCollaborator implements FileAdapterMBean {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2008";
	private static final String CLASSNAME = FileAdapterMBeanImpl.class.getName();
	private static final Logger trcLogger;
	private ObjectName mbean = null;

	public String getDescription() {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "getDescription", "");
		}

		return "virtual member manager File Adapter MBean";
	}

	public DataObject create(DataObject var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "create", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var5 = this.getFileAdapter(var2).create(var1);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "create");
		}

		return var5;
	}

	public DataObject update(DataObject var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "update", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var5 = this.getFileAdapter(var2).update(var1);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "update");
		}

		return var5;
	}

	public DataObject delete(DataObject var1, String var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "delete", WIMTraceHelper.printDataGraph(var1));
		}

		DataObject var5 = this.getFileAdapter(var2).delete(var1);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "delete");
		}

		return var5;
	}

	public void activate() throws AdminException {
		this.mbean = AdminServiceFactory.getMBeanFactory().activateMBean("FileAdapterMBean", this, "FileAdapterMBean",
				"com/ibm/ws/wim/management/FileAdapterMBean.xml");
	}

	public void deactivate() throws AdminException {
		if (this.mbean != null) {
			AdminServiceFactory.getMBeanFactory().deactivateMBean(this.mbean);
		}

	}

	private FileAdapter getFileAdapter(String var1) throws WIMException {
		ServiceProvider.singleton();
		return FileAdapter.getInstance(var1);
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}