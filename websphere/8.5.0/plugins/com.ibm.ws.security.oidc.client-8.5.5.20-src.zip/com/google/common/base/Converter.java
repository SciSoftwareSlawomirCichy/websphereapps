package com.google.common.base;

import com.google.common.annotations.GwtCompatible;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.ForOverride;
import com.google.errorprone.annotations.concurrent.LazyInit;
import java.io.Serializable;
import java.util.Iterator;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public abstract class Converter<A, B> implements Function<A, B> {
	private final boolean handleNullAutomatically;
	@LazyInit
	@MonotonicNonNullDecl
	private transient Converter<B, A> reverse;

	protected Converter() {
		this(true);
	}

	Converter(boolean handleNullAutomatically) {
		this.handleNullAutomatically = handleNullAutomatically;
	}

	@ForOverride
	protected abstract B doForward(A var1);

	@ForOverride
	protected abstract A doBackward(B var1);

	@NullableDecl
	@CanIgnoreReturnValue
	public final B convert(@NullableDecl A a) {
		return this.correctedDoForward(a);
	}

	@NullableDecl
	B correctedDoForward(@NullableDecl A a) {
		if (this.handleNullAutomatically) {
			return a == null ? null : Preconditions.checkNotNull(this.doForward(a));
		} else {
			return this.doForward(a);
		}
	}

	@NullableDecl
	A correctedDoBackward(@NullableDecl B b) {
		if (this.handleNullAutomatically) {
			return b == null ? null : Preconditions.checkNotNull(this.doBackward(b));
		} else {
			return this.doBackward(b);
		}
	}

	@CanIgnoreReturnValue
	public Iterable<B> convertAll(final Iterable<? extends A> fromIterable) {
		Preconditions.checkNotNull(fromIterable, "fromIterable");
		return new Iterable<B>() {
			public Iterator<B> iterator() {
				return new Iterator<B>() {
					private final Iterator<? extends A> fromIterator = fromIterable.iterator();

					public boolean hasNext() {
						return this.fromIterator.hasNext();
					}

					public B next() {
						return Converter.this.convert(this.fromIterator.next());
					}

					public void remove() {
						this.fromIterator.remove();
					}
				};
			}
		};
	}

	@CanIgnoreReturnValue
	public Converter<B, A> reverse() {
		Converter<B, A> result = this.reverse;
		return result == null ? (this.reverse = new ReverseConverter(this)) : result;
	}

	public final <C> Converter<A, C> andThen(Converter<B, C> secondConverter) {
		return this.doAndThen(secondConverter);
	}

	<C> Converter<A, C> doAndThen(Converter<B, C> secondConverter) {
		return new ConverterComposition(this, (Converter) Preconditions.checkNotNull(secondConverter));
	}

	/** @deprecated */
	@Deprecated
	@NullableDecl
	@CanIgnoreReturnValue
	public final B apply(@NullableDecl A a) {
		return this.convert(a);
	}

	public boolean equals(@NullableDecl Object object) {
		return super.equals(object);
	}

	public static <A, B> Converter<A, B> from(Function<? super A, ? extends B> forwardFunction,
			Function<? super B, ? extends A> backwardFunction) {
		return new FunctionBasedConverter(forwardFunction, backwardFunction);
	}

	public static <T> Converter<T, T> identity() {
		return Converter.IdentityConverter.INSTANCE;
	}

	private static final class IdentityConverter<T> extends Converter<T, T> implements Serializable {
		static final IdentityConverter INSTANCE = new IdentityConverter();
		private static final long serialVersionUID = 0L;

		protected T doForward(T t) {
			return t;
		}

		protected T doBackward(T t) {
			return t;
		}

		public IdentityConverter<T> reverse() {
			return this;
		}

		<S> Converter<T, S> doAndThen(Converter<T, S> otherConverter) {
			return (Converter) Preconditions.checkNotNull(otherConverter, "otherConverter");
		}

		public String toString() {
			return "Converter.identity()";
		}

		private Object readResolve() {
			return INSTANCE;
		}
	}

	private static final class FunctionBasedConverter<A, B> extends Converter<A, B> implements Serializable {
		private final Function<? super A, ? extends B> forwardFunction;
		private final Function<? super B, ? extends A> backwardFunction;

		private FunctionBasedConverter(Function<? super A, ? extends B> forwardFunction,
				Function<? super B, ? extends A> backwardFunction) {
			this.forwardFunction = (Function) Preconditions.checkNotNull(forwardFunction);
			this.backwardFunction = (Function) Preconditions.checkNotNull(backwardFunction);
		}

		protected B doForward(A a) {
			return this.forwardFunction.apply(a);
		}

		protected A doBackward(B b) {
			return this.backwardFunction.apply(b);
		}

		public boolean equals(@NullableDecl Object object) {
			if (!(object instanceof FunctionBasedConverter)) {
				return false;
			} else {
				FunctionBasedConverter<?, ?> that = (FunctionBasedConverter) object;
				return this.forwardFunction.equals(that.forwardFunction)
						&& this.backwardFunction.equals(that.backwardFunction);
			}
		}

		public int hashCode() {
			return this.forwardFunction.hashCode() * 31 + this.backwardFunction.hashCode();
		}

		public String toString() {
			return "Converter.from(" + this.forwardFunction + ", " + this.backwardFunction + ")";
		}
	}

	private static final class ConverterComposition<A, B, C> extends Converter<A, C> implements Serializable {
		final Converter<A, B> first;
		final Converter<B, C> second;
		private static final long serialVersionUID = 0L;

		ConverterComposition(Converter<A, B> first, Converter<B, C> second) {
			this.first = first;
			this.second = second;
		}

		protected C doForward(A a) {
			throw new AssertionError();
		}

		protected A doBackward(C c) {
			throw new AssertionError();
		}

		@NullableDecl
		C correctedDoForward(@NullableDecl A a) {
			return this.second.correctedDoForward(this.first.correctedDoForward(a));
		}

		@NullableDecl
		A correctedDoBackward(@NullableDecl C c) {
			return this.first.correctedDoBackward(this.second.correctedDoBackward(c));
		}

		public boolean equals(@NullableDecl Object object) {
			if (!(object instanceof ConverterComposition)) {
				return false;
			} else {
				ConverterComposition<?, ?, ?> that = (ConverterComposition) object;
				return this.first.equals(that.first) && this.second.equals(that.second);
			}
		}

		public int hashCode() {
			return 31 * this.first.hashCode() + this.second.hashCode();
		}

		public String toString() {
			return this.first + ".andThen(" + this.second + ")";
		}
	}

	private static final class ReverseConverter<A, B> extends Converter<B, A> implements Serializable {
		final Converter<A, B> original;
		private static final long serialVersionUID = 0L;

		ReverseConverter(Converter<A, B> original) {
			this.original = original;
		}

		protected A doForward(B b) {
			throw new AssertionError();
		}

		protected B doBackward(A a) {
			throw new AssertionError();
		}

		@NullableDecl
		A correctedDoForward(@NullableDecl B b) {
			return this.original.correctedDoBackward(b);
		}

		@NullableDecl
		B correctedDoBackward(@NullableDecl A a) {
			return this.original.correctedDoForward(a);
		}

		public Converter<A, B> reverse() {
			return this.original;
		}

		public boolean equals(@NullableDecl Object object) {
			if (object instanceof ReverseConverter) {
				ReverseConverter<?, ?> that = (ReverseConverter) object;
				return this.original.equals(that.original);
			} else {
				return false;
			}
		}

		public int hashCode() {
			return ~this.original.hashCode();
		}

		public String toString() {
			return this.original + ".reverse()";
		}
	}
}