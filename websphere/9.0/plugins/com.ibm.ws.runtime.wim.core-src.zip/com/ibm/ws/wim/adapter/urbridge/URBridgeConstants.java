package com.ibm.ws.wim.adapter.urbridge;

public interface URBridgeConstants {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	String USER_DISPLAY_NAME_PROP = "userDisplayNameProperty";
	String USER_SECURITY_NAME_PROP = "userSecurityNameProperty";
	String UNIQUE_USER_ID_PROP = "uniqueUserIdProperty";
	String GROUP_DISPLAY_NAME_PROP = "groupDisplayNameProperty";
	String GROUP_SECURITY_NAME_PROP = "groupSecurityNameProperty";
	String UNIQUE_GROUP_ID_PROP = "uniqueGroupIdProperty";
	String USER_DISPLAY_NAME_DEFAULT_PROP = "displayName";
	String USER_SECURITY_NAME_DEFAULT_PROP = "uniqueName";
	String UNIQUE_USER_ID_DEFAULT_PROP = "uniqueId";
	String GROUP_DISPLAY_NAME_DEFAULT_PROP = "displayName";
	String GROUP_SECURITY_NAME_DEFAULT_PROP = "uniqueName";
	String UNIQUE_GROUP_ID_DEFAULT_PROP = "uniqueId";
	String DISPLAY_NAME = "displayName";
	String CUSTOM_REGISTRY_IMPL_CLASS = "registryImplClass";
}