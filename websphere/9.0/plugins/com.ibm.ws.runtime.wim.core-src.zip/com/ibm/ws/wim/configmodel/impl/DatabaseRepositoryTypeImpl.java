package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import java.util.Collection;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.InternalEList;

public class DatabaseRepositoryTypeImpl extends ProfileRepositoryTypeImpl implements DatabaseRepositoryType {
	protected static final String DATABASE_TYPE_EDEFAULT = null;
	protected String databaseType;
	protected static final String DATA_SOURCE_NAME_EDEFAULT = null;
	protected String dataSourceName;
	protected static final String DB_ADMIN_ID_EDEFAULT = null;
	protected String dbAdminId;
	protected static final String DB_ADMIN_PASSWORD_EDEFAULT = null;
	protected String dbAdminPassword;
	protected static final String DB_URL_EDEFAULT = null;
	protected String dbURL;
	protected static final String DB_SCHEMA_EDEFAULT = null;
	protected String dbSchema;
	protected static final String ENCRYPTION_KEY_EDEFAULT = null;
	protected String encryptionKey;
	protected static final int ENTITY_RETRIEVAL_LIMIT_EDEFAULT = 50;
	protected int entityRetrievalLimit;
	protected boolean entityRetrievalLimitESet;
	protected static final String JDBC_DRIVER_CLASS_EDEFAULT = null;
	protected String jDBCDriverClass;
	protected static final int SALT_LENGTH_EDEFAULT = 12;
	protected int saltLength;
	protected boolean saltLengthESet;
	protected static final String HASH_ALGORITHM_EDEFAULT = null;
	protected String hashAlgorithm;
	protected boolean hashAlgorithmESet;
	protected static final int HASH_ITERATIONS_EDEFAULT = 100000;
	protected int hashIterations;
	protected boolean hashIterationsESet;
	protected static final int HASH_KEY_LENGTH_EDEFAULT = 32;
	protected int hashKeyLength;
	protected boolean hashKeyLengthESet;
	protected static final int HASH_SALT_LENGTH_EDEFAULT = 32;
	protected int hashSaltLength;
	protected boolean hashSaltLengthESet;

	protected DatabaseRepositoryTypeImpl() {
		this.databaseType = DATABASE_TYPE_EDEFAULT;
		this.dataSourceName = DATA_SOURCE_NAME_EDEFAULT;
		this.dbAdminId = DB_ADMIN_ID_EDEFAULT;
		this.dbAdminPassword = DB_ADMIN_PASSWORD_EDEFAULT;
		this.dbURL = DB_URL_EDEFAULT;
		this.dbSchema = DB_SCHEMA_EDEFAULT;
		this.encryptionKey = ENCRYPTION_KEY_EDEFAULT;
		this.entityRetrievalLimit = 50;
		this.entityRetrievalLimitESet = false;
		this.jDBCDriverClass = JDBC_DRIVER_CLASS_EDEFAULT;
		this.saltLength = 12;
		this.saltLengthESet = false;
		this.hashAlgorithm = HASH_ALGORITHM_EDEFAULT;
		this.hashAlgorithmESet = false;
		this.hashIterations = 100000;
		this.hashIterationsESet = false;
		this.hashKeyLength = 32;
		this.hashKeyLengthESet = false;
		this.hashSaltLength = 32;
		this.hashSaltLengthESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getDatabaseRepositoryType();
	}

	public String getDatabaseType() {
		return this.databaseType;
	}

	public void setDatabaseType(String var1) {
		String var2 = this.databaseType;
		this.databaseType = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 18, var2, this.databaseType));
		}

	}

	public String getDataSourceName() {
		return this.dataSourceName;
	}

	public void setDataSourceName(String var1) {
		String var2 = this.dataSourceName;
		this.dataSourceName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 19, var2, this.dataSourceName));
		}

	}

	public String getDbAdminId() {
		return this.dbAdminId;
	}

	public void setDbAdminId(String var1) {
		String var2 = this.dbAdminId;
		this.dbAdminId = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 20, var2, this.dbAdminId));
		}

	}

	public String getDbAdminPassword() {
		return this.dbAdminPassword;
	}

	public void setDbAdminPassword(String var1) {
		String var2 = this.dbAdminPassword;
		this.dbAdminPassword = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 21, var2, this.dbAdminPassword));
		}

	}

	public String getDbURL() {
		return this.dbURL;
	}

	public void setDbURL(String var1) {
		String var2 = this.dbURL;
		this.dbURL = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 22, var2, this.dbURL));
		}

	}

	public String getDbSchema() {
		return this.dbSchema;
	}

	public void setDbSchema(String var1) {
		String var2 = this.dbSchema;
		this.dbSchema = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 23, var2, this.dbSchema));
		}

	}

	public String getEncryptionKey() {
		return this.encryptionKey;
	}

	public void setEncryptionKey(String var1) {
		String var2 = this.encryptionKey;
		this.encryptionKey = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 24, var2, this.encryptionKey));
		}

	}

	public int getEntityRetrievalLimit() {
		return this.entityRetrievalLimit;
	}

	public void setEntityRetrievalLimit(int var1) {
		int var2 = this.entityRetrievalLimit;
		this.entityRetrievalLimit = var1;
		boolean var3 = this.entityRetrievalLimitESet;
		this.entityRetrievalLimitESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 25, var2, this.entityRetrievalLimit, !var3));
		}

	}

	public void unsetEntityRetrievalLimit() {
		int var1 = this.entityRetrievalLimit;
		boolean var2 = this.entityRetrievalLimitESet;
		this.entityRetrievalLimit = 50;
		this.entityRetrievalLimitESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 25, var1, 50, var2));
		}

	}

	public boolean isSetEntityRetrievalLimit() {
		return this.entityRetrievalLimitESet;
	}

	public String getJDBCDriverClass() {
		return this.jDBCDriverClass;
	}

	public void setJDBCDriverClass(String var1) {
		String var2 = this.jDBCDriverClass;
		this.jDBCDriverClass = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 26, var2, this.jDBCDriverClass));
		}

	}

	public int getSaltLength() {
		return this.saltLength;
	}

	public void setSaltLength(int var1) {
		int var2 = this.saltLength;
		this.saltLength = var1;
		boolean var3 = this.saltLengthESet;
		this.saltLengthESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 27, var2, this.saltLength, !var3));
		}

	}

	public void unsetSaltLength() {
		int var1 = this.saltLength;
		boolean var2 = this.saltLengthESet;
		this.saltLength = 12;
		this.saltLengthESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 27, var1, 12, var2));
		}

	}

	public boolean isSetSaltLength() {
		return this.saltLengthESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 2 :
					return ((InternalEList) this.getBaseEntries()).basicRemove(var1, var4);
				case 9 :
					return ((InternalEList) this.getCustomProperties()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getAdapterClassName();
			case 1 :
				return this.getId();
			case 2 :
				return this.getBaseEntries();
			case 3 :
				return this.getEntityTypesNotAllowCreate();
			case 4 :
				return this.getEntityTypesNotAllowUpdate();
			case 5 :
				return this.getEntityTypesNotAllowRead();
			case 6 :
				return this.getEntityTypesNotAllowDelete();
			case 7 :
				return this.getRepositoriesForGroups();
			case 8 :
				return this.getLoginProperties();
			case 9 :
				return this.getCustomProperties();
			case 10 :
				return this.isIsExtIdUnique() ? Boolean.TRUE : Boolean.FALSE;
			case 11 :
				return this.isReadOnly() ? Boolean.TRUE : Boolean.FALSE;
			case 12 :
				return this.isSupportAsyncMode() ? Boolean.TRUE : Boolean.FALSE;
			case 13 :
				return this.isSupportExternalName() ? Boolean.TRUE : Boolean.FALSE;
			case 14 :
				return this.isSupportPaging() ? Boolean.TRUE : Boolean.FALSE;
			case 15 :
				return this.isSupportSorting() ? Boolean.TRUE : Boolean.FALSE;
			case 16 :
				return this.isSupportTransactions() ? Boolean.TRUE : Boolean.FALSE;
			case 17 :
				return this.getSupportChangeLog();
			case 18 :
				return this.getDatabaseType();
			case 19 :
				return this.getDataSourceName();
			case 20 :
				return this.getDbAdminId();
			case 21 :
				return this.getDbAdminPassword();
			case 22 :
				return this.getDbURL();
			case 23 :
				return this.getDbSchema();
			case 24 :
				return this.getEncryptionKey();
			case 25 :
				return new Integer(this.getEntityRetrievalLimit());
			case 26 :
				return this.getJDBCDriverClass();
			case 27 :
				return new Integer(this.getSaltLength());
			case 28 :
				return this.getHashAlgorithm();
			case 29 :
				return new Integer(this.getHashIterations());
			case 30 :
				return new Integer(this.getHashKeyLength());
			case 31 :
				return new Integer(this.getHashSaltLength());
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName((String) var2);
				return;
			case 1 :
				this.setId((String) var2);
				return;
			case 2 :
				this.getBaseEntries().clear();
				this.getBaseEntries().addAll((Collection) var2);
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				this.getEntityTypesNotAllowCreate().addAll((Collection) var2);
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				this.getEntityTypesNotAllowUpdate().addAll((Collection) var2);
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				this.getEntityTypesNotAllowRead().addAll((Collection) var2);
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				this.getEntityTypesNotAllowDelete().addAll((Collection) var2);
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				this.getRepositoriesForGroups().addAll((Collection) var2);
				return;
			case 8 :
				this.getLoginProperties().clear();
				this.getLoginProperties().addAll((Collection) var2);
				return;
			case 9 :
				this.getCustomProperties().clear();
				this.getCustomProperties().addAll((Collection) var2);
				return;
			case 10 :
				this.setIsExtIdUnique((Boolean) var2);
				return;
			case 11 :
				this.setReadOnly((Boolean) var2);
				return;
			case 12 :
				this.setSupportAsyncMode((Boolean) var2);
				return;
			case 13 :
				this.setSupportExternalName((Boolean) var2);
				return;
			case 14 :
				this.setSupportPaging((Boolean) var2);
				return;
			case 15 :
				this.setSupportSorting((Boolean) var2);
				return;
			case 16 :
				this.setSupportTransactions((Boolean) var2);
				return;
			case 17 :
				this.setSupportChangeLog((String) var2);
				return;
			case 18 :
				this.setDatabaseType((String) var2);
				return;
			case 19 :
				this.setDataSourceName((String) var2);
				return;
			case 20 :
				this.setDbAdminId((String) var2);
				return;
			case 21 :
				this.setDbAdminPassword((String) var2);
				return;
			case 22 :
				this.setDbURL((String) var2);
				return;
			case 23 :
				this.setDbSchema((String) var2);
				return;
			case 24 :
				this.setEncryptionKey((String) var2);
				return;
			case 25 :
				this.setEntityRetrievalLimit((Integer) var2);
				return;
			case 26 :
				this.setJDBCDriverClass((String) var2);
				return;
			case 27 :
				this.setSaltLength((Integer) var2);
				return;
			case 28 :
				this.setHashAlgorithm((String) var2);
				return;
			case 29 :
				this.setHashIterations((Integer) var2);
				return;
			case 30 :
				this.setHashKeyLength((Integer) var2);
				return;
			case 31 :
				this.setHashSaltLength((Integer) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName(ADAPTER_CLASS_NAME_EDEFAULT);
				return;
			case 1 :
				this.setId(ID_EDEFAULT);
				return;
			case 2 :
				this.getBaseEntries().clear();
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				return;
			case 8 :
				this.getLoginProperties().clear();
				return;
			case 9 :
				this.getCustomProperties().clear();
				return;
			case 10 :
				this.unsetIsExtIdUnique();
				return;
			case 11 :
				this.unsetReadOnly();
				return;
			case 12 :
				this.unsetSupportAsyncMode();
				return;
			case 13 :
				this.unsetSupportExternalName();
				return;
			case 14 :
				this.unsetSupportPaging();
				return;
			case 15 :
				this.unsetSupportSorting();
				return;
			case 16 :
				this.unsetSupportTransactions();
				return;
			case 17 :
				this.unsetSupportChangeLog();
				return;
			case 18 :
				this.setDatabaseType(DATABASE_TYPE_EDEFAULT);
				return;
			case 19 :
				this.setDataSourceName(DATA_SOURCE_NAME_EDEFAULT);
				return;
			case 20 :
				this.setDbAdminId(DB_ADMIN_ID_EDEFAULT);
				return;
			case 21 :
				this.setDbAdminPassword(DB_ADMIN_PASSWORD_EDEFAULT);
				return;
			case 22 :
				this.setDbURL(DB_URL_EDEFAULT);
				return;
			case 23 :
				this.setDbSchema(DB_SCHEMA_EDEFAULT);
				return;
			case 24 :
				this.setEncryptionKey(ENCRYPTION_KEY_EDEFAULT);
				return;
			case 25 :
				this.unsetEntityRetrievalLimit();
				return;
			case 26 :
				this.setJDBCDriverClass(JDBC_DRIVER_CLASS_EDEFAULT);
				return;
			case 27 :
				this.unsetSaltLength();
				return;
			case 28 :
				this.unsetHashAlgorithm();
				return;
			case 29 :
				this.unsetHashIterations();
				return;
			case 30 :
				this.unsetHashKeyLength();
				return;
			case 31 :
				this.unsetHashSaltLength();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return ADAPTER_CLASS_NAME_EDEFAULT == null
						? this.adapterClassName != null
						: !ADAPTER_CLASS_NAME_EDEFAULT.equals(this.adapterClassName);
			case 1 :
				return ID_EDEFAULT == null ? this.id != null : !ID_EDEFAULT.equals(this.id);
			case 2 :
				return this.baseEntries != null && !this.baseEntries.isEmpty();
			case 3 :
				return this.entityTypesNotAllowCreate != null && !this.entityTypesNotAllowCreate.isEmpty();
			case 4 :
				return this.entityTypesNotAllowUpdate != null && !this.entityTypesNotAllowUpdate.isEmpty();
			case 5 :
				return this.entityTypesNotAllowRead != null && !this.entityTypesNotAllowRead.isEmpty();
			case 6 :
				return this.entityTypesNotAllowDelete != null && !this.entityTypesNotAllowDelete.isEmpty();
			case 7 :
				return this.repositoriesForGroups != null && !this.repositoriesForGroups.isEmpty();
			case 8 :
				return this.loginProperties != null && !this.loginProperties.isEmpty();
			case 9 :
				return this.customProperties != null && !this.customProperties.isEmpty();
			case 10 :
				return this.isSetIsExtIdUnique();
			case 11 :
				return this.isSetReadOnly();
			case 12 :
				return this.isSetSupportAsyncMode();
			case 13 :
				return this.isSetSupportExternalName();
			case 14 :
				return this.isSetSupportPaging();
			case 15 :
				return this.isSetSupportSorting();
			case 16 :
				return this.isSetSupportTransactions();
			case 17 :
				return this.isSetSupportChangeLog();
			case 18 :
				return DATABASE_TYPE_EDEFAULT == null
						? this.databaseType != null
						: !DATABASE_TYPE_EDEFAULT.equals(this.databaseType);
			case 19 :
				return DATA_SOURCE_NAME_EDEFAULT == null
						? this.dataSourceName != null
						: !DATA_SOURCE_NAME_EDEFAULT.equals(this.dataSourceName);
			case 20 :
				return DB_ADMIN_ID_EDEFAULT == null
						? this.dbAdminId != null
						: !DB_ADMIN_ID_EDEFAULT.equals(this.dbAdminId);
			case 21 :
				return DB_ADMIN_PASSWORD_EDEFAULT == null
						? this.dbAdminPassword != null
						: !DB_ADMIN_PASSWORD_EDEFAULT.equals(this.dbAdminPassword);
			case 22 :
				return DB_URL_EDEFAULT == null ? this.dbURL != null : !DB_URL_EDEFAULT.equals(this.dbURL);
			case 23 :
				return DB_SCHEMA_EDEFAULT == null ? this.dbSchema != null : !DB_SCHEMA_EDEFAULT.equals(this.dbSchema);
			case 24 :
				return ENCRYPTION_KEY_EDEFAULT == null
						? this.encryptionKey != null
						: !ENCRYPTION_KEY_EDEFAULT.equals(this.encryptionKey);
			case 25 :
				return this.isSetEntityRetrievalLimit();
			case 26 :
				return JDBC_DRIVER_CLASS_EDEFAULT == null
						? this.jDBCDriverClass != null
						: !JDBC_DRIVER_CLASS_EDEFAULT.equals(this.jDBCDriverClass);
			case 27 :
				return this.isSetSaltLength();
			case 28 :
				return this.isSetHashAlgorithm();
			case 29 :
				return this.isSetHashIterations();
			case 30 :
				return this.isSetHashKeyLength();
			case 31 :
				return this.isSetHashSaltLength();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (databaseType: ");
			var1.append(this.databaseType);
			var1.append(", dataSourceName: ");
			var1.append(this.dataSourceName);
			var1.append(", dbAdminId: ");
			var1.append(this.dbAdminId);
			var1.append(", dbAdminPassword: ");
			var1.append(this.dbAdminPassword);
			var1.append(", dbURL: ");
			var1.append(this.dbURL);
			var1.append(", dbSchema: ");
			var1.append(this.dbSchema);
			var1.append(", encryptionKey: ");
			var1.append(this.encryptionKey);
			var1.append(", entityRetrievalLimit: ");
			if (this.entityRetrievalLimitESet) {
				var1.append(this.entityRetrievalLimit);
			} else {
				var1.append("<unset>");
			}

			var1.append(", jDBCDriverClass: ");
			var1.append(this.jDBCDriverClass);
			var1.append(", saltLength: ");
			if (this.saltLengthESet) {
				var1.append(this.saltLength);
			} else {
				var1.append("<unset>");
			}

			var1.append(", hashAlgorithm: ");
			if (this.hashAlgorithmESet) {
				var1.append(this.hashAlgorithm);
			} else {
				var1.append("<unset>");
			}

			var1.append(", hashIterations: ");
			if (this.hashIterationsESet) {
				var1.append(this.hashIterations);
			} else {
				var1.append("<unset>");
			}

			var1.append(", hashKeyLength: ");
			if (this.hashKeyLengthESet) {
				var1.append(this.hashKeyLength);
			} else {
				var1.append("<unset>");
			}

			var1.append(", hashSaltLength: ");
			if (this.hashSaltLengthESet) {
				var1.append(this.hashSaltLength);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}

	public String getHashAlgorithm() {
		return this.hashAlgorithm;
	}

	public void setHashAlgorithm(String var1) {
		String var2 = this.hashAlgorithm;
		this.hashAlgorithm = var1;
		boolean var3 = this.hashAlgorithmESet;
		this.hashAlgorithmESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 28, var2, this.hashAlgorithm, !var3));
		}

	}

	public void unsetHashAlgorithm() {
		String var1 = this.hashAlgorithm;
		boolean var2 = this.hashAlgorithmESet;
		this.hashAlgorithm = HASH_ALGORITHM_EDEFAULT;
		this.hashAlgorithmESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 28, var1, HASH_ALGORITHM_EDEFAULT, var2));
		}

	}

	public boolean isSetHashAlgorithm() {
		return this.hashAlgorithmESet;
	}

	public int getHashIterations() {
		return this.hashIterations;
	}

	public void setHashIterations(int var1) {
		int var2 = this.hashIterations;
		this.hashIterations = var1;
		boolean var3 = this.hashIterationsESet;
		this.hashIterationsESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 29, var2, this.hashIterations, !var3));
		}

	}

	public void unsetHashIterations() {
		int var1 = this.hashIterations;
		boolean var2 = this.hashIterationsESet;
		this.hashKeyLength = 100000;
		this.hashKeyLengthESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 29, var1, 100000, var2));
		}

	}

	public boolean isSetHashIterations() {
		return this.hashIterationsESet;
	}

	public int getHashKeyLength() {
		return this.hashKeyLength;
	}

	public void setHashKeyLength(int var1) {
		int var2 = this.hashKeyLength;
		this.hashKeyLength = var1;
		boolean var3 = this.hashKeyLengthESet;
		this.hashKeyLengthESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 30, var2, this.hashKeyLength, !var3));
		}

	}

	public void unsetHashKeyLength() {
		int var1 = this.hashKeyLength;
		boolean var2 = this.hashKeyLengthESet;
		this.hashKeyLength = 32;
		this.hashKeyLengthESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 30, var1, 32, var2));
		}

	}

	public boolean isSetHashKeyLength() {
		return this.hashKeyLengthESet;
	}

	public int getHashSaltLength() {
		return this.hashSaltLength;
	}

	public void setHashSaltLength(int var1) {
		int var2 = this.hashSaltLength;
		this.hashSaltLength = var1;
		boolean var3 = this.hashSaltLengthESet;
		this.hashSaltLengthESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 31, var2, this.hashSaltLength, !var3));
		}

	}

	public void unsetHashSaltLength() {
		int var1 = this.hashSaltLength;
		boolean var2 = this.hashSaltLengthESet;
		this.hashSaltLength = 32;
		this.hashSaltLengthESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 31, var1, 32, var2));
		}

	}

	public boolean isSetHashSaltLength() {
		return this.hashSaltLengthESet;
	}
}