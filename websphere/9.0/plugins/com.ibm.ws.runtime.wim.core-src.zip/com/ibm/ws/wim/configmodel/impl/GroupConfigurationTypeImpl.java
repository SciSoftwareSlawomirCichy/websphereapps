package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.DynamicMemberAttributesType;
import com.ibm.ws.wim.configmodel.GroupConfigurationType;
import com.ibm.ws.wim.configmodel.MemberAttributesType;
import com.ibm.ws.wim.configmodel.MembershipAttributeType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class GroupConfigurationTypeImpl extends EDataObjectImpl implements GroupConfigurationType {
	protected EList memberAttributes = null;
	protected EList dynamicMemberAttributes = null;
	protected MembershipAttributeType membershipAttribute = null;
	protected static final boolean UPDATE_GROUP_MEMBERSHIP_EDEFAULT = false;
	protected boolean updateGroupMembership = false;
	protected boolean updateGroupMembershipESet = false;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getGroupConfigurationType();
	}

	public MemberAttributesType[] getMemberAttributesAsArray() {
		List var1 = this.getMemberAttributes();
		return (MemberAttributesType[]) ((MemberAttributesType[]) var1.toArray(new MemberAttributesType[var1.size()]));
	}

	public List getMemberAttributes() {
		if (this.memberAttributes == null) {
			this.memberAttributes = new EObjectContainmentEList(MemberAttributesType.class, this, 0);
		}

		return this.memberAttributes;
	}

	public MemberAttributesType createMemberAttributes() {
		MemberAttributesType var1 = ConfigmodelFactory.eINSTANCE.createMemberAttributesType();
		this.getMemberAttributes().add(var1);
		return var1;
	}

	public DynamicMemberAttributesType[] getDynamicMemberAttributesAsArray() {
		List var1 = this.getDynamicMemberAttributes();
		return (DynamicMemberAttributesType[]) ((DynamicMemberAttributesType[]) var1
				.toArray(new DynamicMemberAttributesType[var1.size()]));
	}

	public List getDynamicMemberAttributes() {
		if (this.dynamicMemberAttributes == null) {
			this.dynamicMemberAttributes = new EObjectContainmentEList(DynamicMemberAttributesType.class, this, 1);
		}

		return this.dynamicMemberAttributes;
	}

	public DynamicMemberAttributesType createDynamicMemberAttributes() {
		DynamicMemberAttributesType var1 = ConfigmodelFactory.eINSTANCE.createDynamicMemberAttributesType();
		this.getDynamicMemberAttributes().add(var1);
		return var1;
	}

	public MembershipAttributeType getMembershipAttribute() {
		return this.membershipAttribute;
	}

	public NotificationChain basicSetMembershipAttribute(MembershipAttributeType var1, NotificationChain var2) {
		MembershipAttributeType var3 = this.membershipAttribute;
		this.membershipAttribute = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 2, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setMembershipAttribute(MembershipAttributeType var1) {
		if (var1 != this.membershipAttribute) {
			NotificationChain var2 = null;
			if (this.membershipAttribute != null) {
				var2 = ((InternalEObject) this.membershipAttribute).eInverseRemove(this, -3, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -3, (Class) null, var2);
			}

			var2 = this.basicSetMembershipAttribute(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var1, var1));
		}

	}

	public MembershipAttributeType createMembershipAttribute() {
		MembershipAttributeType var1 = ConfigmodelFactory.eINSTANCE.createMembershipAttributeType();
		this.setMembershipAttribute(var1);
		return var1;
	}

	public boolean isUpdateGroupMembership() {
		return this.updateGroupMembership;
	}

	public void setUpdateGroupMembership(boolean var1) {
		boolean var2 = this.updateGroupMembership;
		this.updateGroupMembership = var1;
		boolean var3 = this.updateGroupMembershipESet;
		this.updateGroupMembershipESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.updateGroupMembership, !var3));
		}

	}

	public void unsetUpdateGroupMembership() {
		boolean var1 = this.updateGroupMembership;
		boolean var2 = this.updateGroupMembershipESet;
		this.updateGroupMembership = false;
		this.updateGroupMembershipESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 3, var1, false, var2));
		}

	}

	public boolean isSetUpdateGroupMembership() {
		return this.updateGroupMembershipESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getMemberAttributes()).basicRemove(var1, var4);
				case 1 :
					return ((InternalEList) this.getDynamicMemberAttributes()).basicRemove(var1, var4);
				case 2 :
					return this.basicSetMembershipAttribute((MembershipAttributeType) null, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getMemberAttributes();
			case 1 :
				return this.getDynamicMemberAttributes();
			case 2 :
				return this.getMembershipAttribute();
			case 3 :
				return this.isUpdateGroupMembership() ? Boolean.TRUE : Boolean.FALSE;
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getMemberAttributes().clear();
				this.getMemberAttributes().addAll((Collection) var2);
				return;
			case 1 :
				this.getDynamicMemberAttributes().clear();
				this.getDynamicMemberAttributes().addAll((Collection) var2);
				return;
			case 2 :
				this.setMembershipAttribute((MembershipAttributeType) var2);
				return;
			case 3 :
				this.setUpdateGroupMembership((Boolean) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getMemberAttributes().clear();
				return;
			case 1 :
				this.getDynamicMemberAttributes().clear();
				return;
			case 2 :
				this.setMembershipAttribute((MembershipAttributeType) null);
				return;
			case 3 :
				this.unsetUpdateGroupMembership();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.memberAttributes != null && !this.memberAttributes.isEmpty();
			case 1 :
				return this.dynamicMemberAttributes != null && !this.dynamicMemberAttributes.isEmpty();
			case 2 :
				return this.membershipAttribute != null;
			case 3 :
				return this.isSetUpdateGroupMembership();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (updateGroupMembership: ");
			if (this.updateGroupMembershipESet) {
				var1.append(this.updateGroupMembership);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}