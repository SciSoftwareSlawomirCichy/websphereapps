package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.collect.ImmutableMapValues.1;
import com.google.common.collect.ImmutableMapValues.2;
import com.google.common.collect.ImmutableMapValues.SerializedForm;
import com.google.j2objc.annotations.Weak;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
final class ImmutableMapValues<K, V> extends ImmutableCollection<V> {
	@Weak
	private final ImmutableMap<K, V> map;

	ImmutableMapValues(ImmutableMap<K, V> map) {
		this.map = map;
	}

	public int size() {
		return this.map.size();
	}

	public UnmodifiableIterator<V> iterator() {
      return new 1(this);
   }

	public boolean contains(@NullableDecl Object object) {
		return object != null && Iterators.contains(this.iterator(), object);
	}

	boolean isPartialView() {
		return true;
	}

	public ImmutableList<V> asList() {
      ImmutableList<Entry<K, V>> entryList = this.map.entrySet().asList();
      return new 2(this, entryList);
   }

	@GwtIncompatible
	Object writeReplace() {
		return new SerializedForm(this.map);
	}
}