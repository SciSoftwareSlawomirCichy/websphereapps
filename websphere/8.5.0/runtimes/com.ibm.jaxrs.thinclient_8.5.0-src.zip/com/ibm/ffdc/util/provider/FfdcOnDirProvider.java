package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.config.Formattable;
import com.ibm.ffdc.impl.Ffdc;
import com.ibm.ffdc.util.provider.FfdcOnDirProvider.1;
import com.ibm.ffdc.util.provider.FfdcOnDirProvider.2;
import com.ibm.ffdc.util.provider.FfdcOnDirProvider.3;
import com.ibm.ffdc.util.provider.FfdcOnDirProvider.4;
import com.ibm.ffdc.util.provider.FfdcOnDirProvider.5;
import com.ibm.ffdc.util.provider.FfdcOnDirProvider.FfdcJanitor;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.List;
import java.util.logging.Level;

public final class FfdcOnDirProvider extends FfdcProvider implements com.ibm.ffdc.provider.FfdcProvider {
	private int size = -1;
	private final File ffdcdir;
	private final File ffdcSummary;
	private static final String INCIDENT_SUMMARY_NAME = "FfdcSummary.txt";
	private static final String FFDC_PREFIX = "ffdc.";
	private static final String FFDC_SUFFIX = ".txt";
	private static final int daysToKeepIncidents = Integer.getInteger("com.ibm.ffdc.retentiondays", 7);
	private static final int hoursBetweenChecks = Integer.getInteger("com.ibm.ffdc.hourintervalforcleanup", 24);
	private static final long millisBetweenChecks;
	private static long lastCheck;
	private static final long millisToKeepIncidents;

	public FfdcOnDirProvider(File homedir) throws PrivilegedActionException {
      this.ffdcdir = homedir;
      mkdir(this.ffdcdir);
      this.ffdcSummary = new File(this.ffdcdir, "FfdcSummary.txt");
      if (daysToKeepIncidents > 0) {
         FfdcJanitor ffdcJanitor = new FfdcJanitor(this, (1)null);
         ffdcJanitor.run();
      }

   }

	protected synchronized void logIncident(IncidentEntry incident, Object reporter, Throwable th, List<Formattable> data) {
      if (daysToKeepIncidents > 0 && System.currentTimeMillis() > lastCheck + millisBetweenChecks) {
         FfdcJanitor ffdcJanitor = new FfdcJanitor(this, (1)null);
         ffdcJanitor.run();
      }

      IncidentLogger<FfdcOnDirProvider> incidentLogger = new IncidentLogger(this);
      this.logIncident(incidentLogger, incident, reporter, th, data);
      this.logSummary(incidentLogger);
   }

	private void logIncident(IncidentLogger<FfdcOnDirProvider> incidentLogger, IncidentEntry incident, Object reporter, Throwable th, List<Formattable> data) {
      File[] aF = new File[]{null};

      FileOutputStream out;
      try {
         out = (FileOutputStream)AccessController.doPrivileged(new 1(this, aF));
      } catch (Exception var11) {
         this.abort(var11);
         return;
      }

      String incidentFile = aF[0].getAbsolutePath();

      try {
         IncidentStream<FfdcOnDirProvider> is = new IncidentStream(this, out);
         incidentLogger.writeIncidentTo(is, incident, reporter, th, data);
         out.flush();
         incident.setLabel(incidentFile);
         Ffdc.getLogger().logp(Level.INFO, FfdcOnDirProvider.class.getName(), "logIncident", "FFDCIncidentEmitted", new Object[]{incidentFile, incident.getSourceId(), incident.getProbeId()});
      } catch (IOException var10) {
         this.ffdcerror(var10);
      }

   }

	private synchronized void logSummary(IncidentLogger<FfdcOnDirProvider> incidentLogger) {
      List<Incident> incidents = this.getIncidents();
      if (this.size != incidents.size()) {
         FileOutputStream outs;
         try {
            outs = (FileOutputStream)AccessController.doPrivileged(new 2(this));
         } catch (Exception var6) {
            this.ffdcerror(var6);
            return;
         }

         try {
            incidentLogger.logIncidentSummary(outs, incidents);
            this.size = incidents.size();
            outs.flush();
            outs.close();
         } catch (IOException var5) {
            this.ffdcerror(var5);
         }

      }
   }

	private static Void mkdir(File f) throws PrivilegedActionException {
      return (Void)AccessController.doPrivileged(new 3(f));
   }

	private static Void delete(File f) throws PrivilegedActionException {
      return (Void)AccessController.doPrivileged(new 4(f));
   }

	private static File[] listFiles(File f) throws PrivilegedActionException {
      return (File[])AccessController.doPrivileged(new 5(f));
   }

	static {
		millisBetweenChecks = (long) (hoursBetweenChecks * 60 * 60 * 1000);
		lastCheck = 0L;
		millisToKeepIncidents = (long) (daysToKeepIncidents * 24 * 60 * 60 * 1000);
	}
}