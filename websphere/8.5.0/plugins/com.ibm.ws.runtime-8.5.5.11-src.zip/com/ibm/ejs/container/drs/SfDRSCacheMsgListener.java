package com.ibm.ejs.container.drs;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.failover.SfFailoverKey;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.wsspi.cluster.Identity;
import com.ibm.wsspi.drs.DRSCacheMsg;
import com.ibm.wsspi.drs.DRSCacheMsgListener;
import com.ibm.wsspi.drs.DRSEventObject;
import java.util.Collections;
import java.util.EventObject;
import java.util.Map;
import java.util.WeakHashMap;

public class SfDRSCacheMsgListener implements DRSCacheMsgListener {
	private static final TraceComponent tc = Tr.register(SfDRSCacheMsgListener.class, "EJBDRSCache",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.drs.SfDRSCacheMsgListener";
	private final SfDRSCache ivStatefulDRSCache;
	private SfDRSClient ivSfDRSClient;
	private Map<Identity, Long> ivNowThePrimaryMap = Collections.synchronizedMap(new WeakHashMap());

	public SfDRSCacheMsgListener(SfDRSCache drsCache) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSCacheMsgListener CTOR", drsCache);
		}

		this.ivStatefulDRSCache = drsCache;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSCacheMsgListener CTOR");
		}

	}

	void setSfDRSClient(SfDRSClient drsClient) {
		this.ivSfDRSClient = drsClient;
	}

	public void createEntry(Object entryKey, Object value) {
		SfFailoverKey key = null;

		try {
			key = (SfFailoverKey) entryKey;
			SfDRSCacheEntry cacheEntry = (SfDRSCacheEntry) value;
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.entry(tc, "createEntry, key = " + key + ", " + cacheEntry);
			}

			this.ivStatefulDRSCache.addCacheEntry(key, cacheEntry, this);
		} catch (Throwable var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.drs.SfDRSCacheMsgListener.createEntry", "135",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "createEntry caught Throwable", var5);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "createEntry, key = " + key);
		}

	}

	public Object getEntry(Object entryKey) {
		SfDRSCacheEntry entry = null;
		SfFailoverKey key = null;

		try {
			key = (SfFailoverKey) entryKey;
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.entry(tc, "getEntry, key = " + key);
			}

			entry = this.ivStatefulDRSCache.getCacheEntry(key);
		} catch (Throwable var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.drs.SfDRSCacheMsgListener.getEntry", "173", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getEntry caught Throwable", var5);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEntry, " + entry);
		}

		return entry;
	}

	public boolean entryIDExists(Object entryKey) {
		boolean exists = false;
		SfFailoverKey key = null;

		try {
			key = (SfFailoverKey) entryKey;
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.entry(tc, "entryIDExists, key = " + key);
			}

			exists = this.ivStatefulDRSCache.beanExists(key);
		} catch (Throwable var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.drs.SfDRSCacheMsgListener.entryIDExists", "211",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "entryIDExists failed", var5);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "entryIDExists returning " + exists + " for key = " + key);
		}

		return exists;
	}

	public void event(DRSEventObject eventObject) {
		if (this.ivSfDRSClient == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "event: not ready to recieve events : ", eventObject);
			}
		} else {
			this.ivSfDRSClient.event(eventObject);
		}

	}

	public void removeEntry(Object entryKey) {
		SfFailoverKey key = null;

		try {
			key = (SfFailoverKey) entryKey;
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.entry(tc, "removeEntry, key = " + key);
			}

			this.ivStatefulDRSCache.removeCacheEntry(key);
		} catch (Throwable var4) {
			FFDCFilter.processException(var4, "com.ibm.ejs.container.drs.SfDRSCacheMsgListener.removeEntry", "260",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "removeEntry failed", var4);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "removeEntry, key = " + key);
		}

	}

	public void updateEntry(Object entryKey, Object value) {
		SfFailoverKey key = null;

		try {
			key = (SfFailoverKey) entryKey;
			SfDRSCacheEntry cacheEntry = (SfDRSCacheEntry) value;
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.entry(tc, "updateEntry, key = " + key + ", " + cacheEntry);
			}

			this.ivStatefulDRSCache.updateCacheEntry(key, cacheEntry, this);
		} catch (Throwable var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.drs.SfDRSCacheMsgListener.updateEntry", "300",
					this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "updateEntry failed", var5);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "updateEntry, key = " + key);
		}

	}

	public void createEntryProp(Object entryKey, Object propKey, Object value) {
	}

	public void removeEntryProp(Object entryKey, Object propKey, Object value) {
	}

	public void nowThePrimary(long partitionId) {
	}

	public void nowThePrimary(Identity id) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "nowThePrimary call for WLM Identity: " + id);
		}

		this.ivNowThePrimaryMap.put(id, System.currentTimeMillis());
	}

	public Object broadcast(Object key) {
		return null;
	}

	public void processDRSCacheMsgEvent(EventObject obj) {
	}

	public void response(Object response) {
	}

	public void asyncAck(DRSCacheMsg in, DRSCacheMsg out) {
	}

	public void updateEntryProp(Object entryKey, Object propKey, Object value) {
	}

	public Object getEntryProp(Object entryKey, Object propKey) {
		return null;
	}

	void removeIfPrimary(SfFailoverKey key) {
		Identity id = this.ivSfDRSClient.getWLMIdentity(key);
		if (id != null && !this.ivNowThePrimaryMap.containsKey(id)) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "removeIfPrimary - not the primary, so removeLocalEntry is being invoked for key = " + key
						+ " id = " + id);
			}

			this.ivSfDRSClient.removeLocalEntry(key);
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "removeIfPrimary removing DRS entry for key = " + key + " id = " + id);
			}

			this.ivSfDRSClient.removeEntry(key);
		}

	}
}