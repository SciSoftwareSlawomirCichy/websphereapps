package com.ibm.ejs.container;

import com.ibm.ejs.container.finder.FinderResultClientCollection_Local;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.cpmi.CPMIException;
import com.ibm.ws.cpmi.association.CMRHelper;
import com.ibm.ws.ejbpersistence.associations.AssociationLink;
import com.ibm.ws.ejbpersistence.beanextensions.ConcreteBeanLinkTarget;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;
import java.util.Collection;

public class CMRHelperImpl implements CMRHelper {
	private static final TraceComponent tc = Tr.register(CMRHelperImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.CMRHelperImpl";
	private AccessIntent ivAccessIntent;

	public final void beginCMRMaintenance(AccessIntent ai) throws CPMIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "beginCMRMaintenance", new Object[]{ai});
		}

		this.ivAccessIntent = ai;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "beginCMRMaintenance");
		}

	}

	public final void endCMRMaintenance() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "endCMRMaintenance");
		}

		this.ivAccessIntent = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "endCMRMaintenance");
		}

	}

	public final AccessIntent getCMRCollectionAccessIntent(Collection collection) {
		return ((FinderResultClientCollection_Local) collection).getCollectionAccessIntent();
	}

	public AssociationLink getLink(Object ejb, String name) {
		return this.getLink(ejb, name, (AccessIntent) null);
	}

	public AssociationLink getLink(Object ejb, String name, AccessIntent ai) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getLink", new Object[]{ejb, name, ai});
		}

		EJSContainer container = EJSContainer.getDefaultContainer();
		EJSDeployedSupport s = null;
		EJSWrapperBase wrapper = null;
		AssociationLink rtnLink = null;

		try {
			wrapper = (EJSWrapperBase) ejb;
			if (ai == null) {
				EntityContainerTx tx = EntityHelperImpl.getCurrentTx(container);
				ai = tx.getCachedAccessIntent(wrapper.beanId);
				if (ai == null) {
					ai = this.ivAccessIntent;
				}
			}

			s = new EJSDeployedSupport();
			EJBMethodInfoImpl methodInfo = EntityHelperImpl.mapPMMethodInfo(s, wrapper, -1, "getLink:java.lang.String",
					ai);
			ConcreteBeanLinkTarget beanRef = (ConcreteBeanLinkTarget) container.preInvoke(wrapper, -1, s, methodInfo);
			rtnLink = beanRef.getLink(name);
		} catch (RemoteException var72) {
			FFDCFilter.processException(var72, "com.ibm.ejs.container.CMRHelperImpl.getLink", "162");
			s.setUncheckedLocalException(var72);
		} catch (Throwable var73) {
			FFDCFilter.processException(var73, "com.ibm.ejs.container.CMRHelperImpl.getLink", "167");
			s.setUncheckedLocalException(var73);
		} finally {
			try {
				if (s != null) {
					container.postInvoke(wrapper, -1, s);
				}
			} catch (RemoteException var71) {
				FFDCFilter.processException(var71, "com.ibm.ejs.container.CMRHelperImpl.getLink", "181");
				s.setUncheckedLocalException(var71);
			} finally {
				if (s != null) {
					container.putEJSDeployedSupport(s);
				}

			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "getLink");
			}

		}

		return rtnLink;
	}
}