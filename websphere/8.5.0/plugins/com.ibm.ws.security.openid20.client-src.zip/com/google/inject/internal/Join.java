package com.google.inject.internal;

import com.google.inject.internal.Join.1;
import com.google.inject.internal.Join.JoinException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public final class Join {
	public static String join(String delimiter, Iterable<?> tokens) {
		return join(delimiter, tokens.iterator());
	}

	public static String join(String delimiter, Object[] tokens) {
		return join(delimiter, (Iterable) Arrays.asList(tokens));
	}

	public static String join(String delimiter, @Nullable Object firstToken, Object... otherTokens) {
		Preconditions.checkNotNull(otherTokens);
		return join(delimiter, (Iterable) Lists.newArrayList(firstToken, otherTokens));
	}

	public static String join(String delimiter, Iterator<?> tokens) {
		StringBuilder sb = new StringBuilder();
		join((Appendable) sb, (String) delimiter, (Iterator) tokens);
		return sb.toString();
	}

	public static String join(String keyValueSeparator, String entryDelimiter, Map<?, ?> map) {
		return ((StringBuilder) join(new StringBuilder(), keyValueSeparator, (String) entryDelimiter, (Map) map))
				.toString();
	}

	public static <T extends Appendable> T join(T appendable, String delimiter, Iterable<?> tokens) {
		return join(appendable, delimiter, tokens.iterator());
	}

	public static <T extends Appendable> T join(T appendable, String delimiter, Object[] tokens) {
		return join((Appendable) appendable, (String) delimiter, (Iterable) Arrays.asList(tokens));
	}

	public static <T extends Appendable> T join(T appendable, String delimiter, @Nullable Object firstToken,
			Object... otherTokens) {
		Preconditions.checkNotNull(otherTokens);
		return join((Appendable) appendable, (String) delimiter,
				(Iterable) Lists.newArrayList(firstToken, otherTokens));
	}

	public static <T extends Appendable> T join(T appendable, String delimiter, Iterator<?> tokens) {
      Preconditions.checkNotNull(appendable);
      Preconditions.checkNotNull(delimiter);
      if (tokens.hasNext()) {
         try {
            appendOneToken(appendable, tokens.next());

            while(tokens.hasNext()) {
               appendable.append(delimiter);
               appendOneToken(appendable, tokens.next());
            }
         } catch (IOException var4) {
            throw new JoinException(var4, (1)null);
         }
      }

      return appendable;
   }

	public static <T extends Appendable> T join(T appendable, String keyValueSeparator, String entryDelimiter, Map<?, ?> map) {
      Preconditions.checkNotNull(appendable);
      Preconditions.checkNotNull(keyValueSeparator);
      Preconditions.checkNotNull(entryDelimiter);
      Iterator<? extends Entry<?, ?>> entries = map.entrySet().iterator();
      if (entries.hasNext()) {
         try {
            appendOneEntry(appendable, keyValueSeparator, (Entry)entries.next());

            while(entries.hasNext()) {
               appendable.append(entryDelimiter);
               appendOneEntry(appendable, keyValueSeparator, (Entry)entries.next());
            }
         } catch (IOException var6) {
            throw new JoinException(var6, (1)null);
         }
      }

      return appendable;
   }

	private static void appendOneEntry(Appendable appendable, String keyValueSeparator, Entry<?, ?> entry)
			throws IOException {
		appendOneToken(appendable, entry.getKey());
		appendable.append(keyValueSeparator);
		appendOneToken(appendable, entry.getValue());
	}

	private static void appendOneToken(Appendable appendable, Object token) throws IOException {
		appendable.append(toCharSequence(token));
	}

	private static CharSequence toCharSequence(Object token) {
		return (CharSequence) (token instanceof CharSequence ? (CharSequence) token : String.valueOf(token));
	}
}