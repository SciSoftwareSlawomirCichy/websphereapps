package com.ibm.ejs.container;

import com.ibm.ejs.container.passivator.PassivatorSerializableHandle;
import com.ibm.ejs.container.util.ByteArray;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.ws.ejb.portable.Constants;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Hashtable;

public final class TimerNpHandleImpl implements Serializable, PassivatorSerializableHandle {
	private static final TraceComponent tc = Tr.register(TimerNpHandleImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final long serialVersionUID = 1137182555465371492L;
	private static final byte[] EYECATCHER;
	private static final short PLATFORM = 1;
	private static final short VERSION_ID = 1;
	private transient String ivTaskId;
	private transient BeanId ivBeanId;

	TimerNpHandleImpl(BeanId beanId, String taskId) {
		this.ivBeanId = beanId;
		this.ivTaskId = taskId;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, this.toString());
		}

	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "writeObject: " + this);
		}

		out.defaultWriteObject();
		out.write(EYECATCHER);
		out.writeShort(1);
		out.writeShort(1);
		out.writeUTF(this.ivTaskId);
		out.writeObject(this.ivBeanId.getByteArrayBytes());
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "writeObject");
		}

	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "readObject");
		}

		in.defaultReadObject();
		byte[] eyeCatcher = new byte[EYECATCHER.length];
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < EYECATCHER.length; i += bytesRead) {
			bytesRead = in.read(eyeCatcher, i, EYECATCHER.length - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < EYECATCHER.length; ++i) {
			if (EYECATCHER[i] != eyeCatcher[i]) {
				String eyeCatcherString = new String(eyeCatcher);
				throw new IOException("Invalid eye catcher '" + eyeCatcherString + "' in TimerHandle input stream");
			}
		}

		short incoming_platform = in.readShort();
		short incoming_vid = in.readShort();
		if (incoming_vid != 1) {
			throw new InvalidObjectException(
					"EJB TimerHandle data stream is not of the correct version, this client should be updated.");
		} else {
			this.ivTaskId = in.readUTF();
			byte[] bytes = (byte[]) ((byte[]) in.readObject());
			ByteArray byteArray = new ByteArray(bytes);
			EJSContainer container = EJSContainer.getDefaultContainer();
			this.ivBeanId = BeanId.getBeanId(byteArray, container);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "readObject: " + this);
			}

		}
	}

	public Object getSerializedObject() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		Object timer = null;
		Hashtable var3 = TimerNpImpl.timerHash;
		synchronized (TimerNpImpl.timerHash) {
			if (TimerNpImpl.timerHash.containsKey(this.ivTaskId)) {
				timer = TimerNpImpl.timerHash.get(this.ivTaskId);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "getSerializedObject returning timerHash.get(" + this.ivTaskId + ") :" + timer);
				}
			} else {
				EJSHome home = (EJSHome) this.ivBeanId.home;
				ContainerTx containerTx = null;

				try {
					containerTx = home.container.getCurrentTx(false);
				} catch (CSITransactionRolledbackException var8) {
					;
				}

				if (containerTx != null && containerTx.timersQueuedToStart != null
						&& containerTx.timersQueuedToStart.containsKey(this.ivTaskId)) {
					timer = containerTx.timersQueuedToStart.get(this.ivTaskId);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "getSerializedObject returning timer from timersQueuedToStart");
					}
				} else if (containerTx != null && containerTx.timersCanceled != null
						&& containerTx.timersCanceled.containsKey(this.ivTaskId)) {
					timer = containerTx.timersCanceled.get(this.ivTaskId);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "getSerializedObject returning timer from timersCanceled");
					}
				} else {
					timer = new TimerNpImpl(this.ivBeanId, this.ivTaskId);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "getSerializedObject returning new TimerNpImpl");
					}
				}
			}

			return timer;
		}
	}

	static {
		EYECATCHER = Constants.TIMER_HANDLE_EYE_CATCHER;
	}
}