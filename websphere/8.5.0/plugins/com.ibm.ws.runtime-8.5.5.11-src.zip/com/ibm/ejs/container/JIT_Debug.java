package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.ejs.util.dopriv.GetContextClassLoaderPrivileged;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.util.dopriv.GetClassLoaderPrivileged;

public class JIT_Debug {
	private static final TraceComponent tc = Tr.register(JIT_Debug.class, "JITDeployRuntime",
			"com.ibm.ejs.container.container");

	public static Object checkCast(Object value, Object object, String valueClassName) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			ClassLoader valueLoader = value == null
					? null
					: (ClassLoader) AccessController.doPrivileged(new GetClassLoaderPrivileged(value.getClass()));
			ClassLoader contextLoader = (ClassLoader) AccessController
					.doPrivileged(new GetContextClassLoaderPrivileged());
			ClassLoader objectLoader = (ClassLoader) AccessController
					.doPrivileged(new GetClassLoaderPrivileged(object.getClass()));

			ClassLoader objectValueLoader;
			try {
				Class<?> objectValueClass = Class.forName(valueClassName, false, objectLoader);
				objectValueLoader = objectValueClass == null
						? null
						: (ClassLoader) AccessController.doPrivileged(new GetClassLoaderPrivileged(objectValueClass));
			} catch (Throwable var8) {
				Tr.debug(tc, "checkCast: failed to load " + valueClassName, var8);
				objectValueLoader = null;
			}

			Tr.debug(tc, "checkCast: value=" + Util.identity(value) + ", valueClassName=" + valueClassName,
					", valueLoader=" + Util.identity(valueLoader) + ", contextLoader=" + Util.identity(contextLoader)
							+ ", object=" + Util.identity(object) + ", objectLoader=" + Util.identity(objectLoader)
							+ ", objectValueLoader=" + Util.identity(objectValueLoader));
		}

		return value;
	}
}