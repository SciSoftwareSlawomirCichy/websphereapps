package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.Label;

public interface ProcessSwitchCallback {
	void processCase(int var1, Label var2) throws Exception;

	void processDefault() throws Exception;
}