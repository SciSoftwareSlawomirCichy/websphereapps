package com.ibm.ws.logging;

import java.util.Collections;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggerHelper {
	public static void addLoggerToGroup(Logger logger, String groups) {
		if (logger == null) {
			throw new NullPointerException("logger");
		} else if (groups == null) {
			throw new NullPointerException("groups");
		} else if (!(logger instanceof WsLogger)) {
			throw new IllegalArgumentException("logger");
		} else {
			WsLogger wsLogger = (WsLogger) logger;
			String[] arr$ = groups.split("[,;:]");
			int len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				String group = arr$[i$];
				wsLogger.addLoggerToGroup(group);
			}

		}
	}

	public static String getExtension(Logger logger, String name) {
		if (logger == null) {
			throw new NullPointerException("logger");
		} else if (name == null) {
			throw new NullPointerException("name");
		} else if (!(logger instanceof WsLogger)) {
			throw new IllegalArgumentException("logger");
		} else {
			return null;
		}
	}

	public static Map getExtensions(Logger logger) {
		if (logger == null) {
			throw new NullPointerException("logger");
		} else if (!(logger instanceof WsLogger)) {
			throw new IllegalArgumentException("logger");
		} else {
			return Collections.emptyMap();
		}
	}

	public static void addExtension(Logger logger, String name, String value) {
		if (logger == null) {
			throw new NullPointerException("logger");
		} else if (name == null) {
			throw new NullPointerException("name");
		} else if (value == null) {
			throw new NullPointerException("value");
		} else if (!(logger instanceof WsLogger)) {
			throw new IllegalArgumentException("logger");
		}
	}

	public static void addExtensions(Logger logger, Map extensions) {
		if (logger == null) {
			throw new NullPointerException("logger");
		} else if (extensions == null) {
			throw new NullPointerException("extensions");
		} else if (!(logger instanceof WsLogger)) {
			throw new IllegalArgumentException("logger");
		}
	}

	public static void removeExtension(Logger logger, String name) {
		if (logger == null) {
			throw new NullPointerException("logger");
		} else if (name == null) {
			throw new NullPointerException("name");
		} else if (!(logger instanceof WsLogger)) {
			throw new IllegalArgumentException("logger");
		}
	}

	public static void clearExtensions(Logger logger) {
		if (logger == null) {
			throw new NullPointerException("logger");
		} else if (!(logger instanceof WsLogger)) {
			throw new IllegalArgumentException("logger");
		}
	}

	public static void setAttributes(Logger logger, String organization, String product, String component,
			Level minimumLocalizationLevel) {
		if (logger == null) {
			throw new NullPointerException("logger");
		} else if (!(logger instanceof WsLogger)) {
			throw new IllegalArgumentException("logger");
		}
	}
}