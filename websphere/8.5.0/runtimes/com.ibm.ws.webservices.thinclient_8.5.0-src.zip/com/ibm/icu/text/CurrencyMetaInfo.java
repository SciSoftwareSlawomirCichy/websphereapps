package com.ibm.icu.text;

import com.ibm.icu.text.CurrencyMetaInfo.CurrencyDigits;
import com.ibm.icu.text.CurrencyMetaInfo.CurrencyFilter;
import com.ibm.icu.text.CurrencyMetaInfo.CurrencyInfo;
import com.ibm.icu.util.GregorianCalendar;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class CurrencyMetaInfo {
	private static final CurrencyMetaInfo impl;
	private static final boolean hasData;

	protected static final CurrencyDigits defaultDigits = new CurrencyDigits(2, 0);

	public static CurrencyMetaInfo getInstance() {
		return impl;
	}

	public static boolean hasData() {
		return hasData;
	}

	public List<CurrencyInfo> currencyInfo(CurrencyFilter filter) {
		return Collections.emptyList();
	}

	public List<String> currencies(CurrencyFilter filter) {
		return Collections.emptyList();
	}

	public List<String> regions(CurrencyFilter filter) {
		return Collections.emptyList();
	}

	public CurrencyDigits currencyDigits(String isoCode) {
		return defaultDigits;
	}

	private static String dateString(long date) {
		if (date != Long.MAX_VALUE && date != Long.MIN_VALUE) {
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTimeInMillis(date);
			return "" + gc.get(1) + '-' + (gc.get(2) + 1) + '-' + gc.get(5);
		} else {
			return null;
		}
	}

	private static String debugString(Object o) {
		StringBuilder sb = new StringBuilder();

		try {
			Field[] arr$ = o.getClass().getFields();
			int len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				Field f = arr$[i$];
				Object v = f.get(o);
				if (v != null) {
					String s;
					if (v instanceof Date) {
						s = dateString(((Date) v).getTime());
					} else if (v instanceof Long) {
						s = dateString((Long) v);
					} else {
						s = String.valueOf(v);
					}

					if (s != null) {
						if (sb.length() > 0) {
							sb.append(",");
						}

						sb.append(f.getName()).append("='").append(s).append("'");
					}
				}
			}
		} catch (Throwable var8) {
			;
		}

		sb.insert(0, o.getClass().getSimpleName() + "(");
		sb.append(")");
		return sb.toString();
	}

	static {
		CurrencyMetaInfo temp = null;
		boolean tempHasData = false;

		try {
			Class<?> clzz = Class.forName("com.ibm.icu.impl.ICUCurrencyMetaInfo");
			temp = (CurrencyMetaInfo) clzz.newInstance();
			tempHasData = true;
		} catch (Throwable var3) {
			temp = new CurrencyMetaInfo();
		}

		impl = temp;
		hasData = tempHasData;
	}
}