package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.AbstractMapBasedMultiset.1;
import com.google.common.collect.AbstractMapBasedMultiset.MapBasedMultisetIterator;
import com.google.common.collect.Multiset.Entry;
import com.google.common.primitives.Ints;
import java.io.InvalidObjectException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
abstract class AbstractMapBasedMultiset<E> extends AbstractMultiset<E> implements Serializable {
	private transient Map<E, Count> backingMap;
	private transient long size;
	@GwtIncompatible("not needed in emulated source.")
	private static final long serialVersionUID = -2250766705698539974L;

	protected AbstractMapBasedMultiset(Map<E, Count> backingMap) {
		this.backingMap = (Map) Preconditions.checkNotNull(backingMap);
		this.size = (long) super.size();
	}

	void setBackingMap(Map<E, Count> backingMap) {
		this.backingMap = backingMap;
	}

	public Set<Entry<E>> entrySet() {
		return super.entrySet();
	}

	Iterator<Entry<E>> entryIterator() {
      Iterator<java.util.Map.Entry<E, Count>> backingEntries = this.backingMap.entrySet().iterator();
      return new 1(this, backingEntries);
   }

	public void clear() {
		Iterator i$ = this.backingMap.values().iterator();

		while (i$.hasNext()) {
			Count frequency = (Count) i$.next();
			frequency.set(0);
		}

		this.backingMap.clear();
		this.size = 0L;
	}

	int distinctElements() {
		return this.backingMap.size();
	}

	public int size() {
		return Ints.saturatedCast(this.size);
	}

	public Iterator<E> iterator() {
		return new MapBasedMultisetIterator(this);
	}

	public int count(@Nullable Object element) {
		Count frequency = (Count) Maps.safeGet(this.backingMap, element);
		return frequency == null ? 0 : frequency.get();
	}

	public int add(@Nullable E element, int occurrences) {
		if (occurrences == 0) {
			return this.count(element);
		} else {
			Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s",
					new Object[]{occurrences});
			Count frequency = (Count) this.backingMap.get(element);
			int oldCount;
			if (frequency == null) {
				oldCount = 0;
				this.backingMap.put(element, new Count(occurrences));
			} else {
				oldCount = frequency.get();
				long newCount = (long) oldCount + (long) occurrences;
				Preconditions.checkArgument(newCount <= 2147483647L, "too many occurrences: %s",
						new Object[]{newCount});
				frequency.getAndAdd(occurrences);
			}

			this.size += (long) occurrences;
			return oldCount;
		}
	}

	public int remove(@Nullable Object element, int occurrences) {
		if (occurrences == 0) {
			return this.count(element);
		} else {
			Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s",
					new Object[]{occurrences});
			Count frequency = (Count) this.backingMap.get(element);
			if (frequency == null) {
				return 0;
			} else {
				int oldCount = frequency.get();
				int numberRemoved;
				if (oldCount > occurrences) {
					numberRemoved = occurrences;
				} else {
					numberRemoved = oldCount;
					this.backingMap.remove(element);
				}

				frequency.addAndGet(-numberRemoved);
				this.size -= (long) numberRemoved;
				return oldCount;
			}
		}
	}

	public int setCount(@Nullable E element, int count) {
		Multisets.checkNonnegative(count, "count");
		Count existingCounter;
		int oldCount;
		if (count == 0) {
			existingCounter = (Count) this.backingMap.remove(element);
			oldCount = getAndSet(existingCounter, count);
		} else {
			existingCounter = (Count) this.backingMap.get(element);
			oldCount = getAndSet(existingCounter, count);
			if (existingCounter == null) {
				this.backingMap.put(element, new Count(count));
			}
		}

		this.size += (long) (count - oldCount);
		return oldCount;
	}

	private static int getAndSet(Count i, int count) {
		return i == null ? 0 : i.getAndSet(count);
	}

	@GwtIncompatible("java.io.ObjectStreamException")
	private void readObjectNoData() throws ObjectStreamException {
		throw new InvalidObjectException("Stream data required");
	}
}