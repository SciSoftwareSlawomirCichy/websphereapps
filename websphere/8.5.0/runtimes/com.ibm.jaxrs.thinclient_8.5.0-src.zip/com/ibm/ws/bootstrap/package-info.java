package com.ibm.ws.bootstrap;

interface package-info {
}