package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.collect.ImmutableMapKeySet.KeySetSerializedForm;
import com.google.j2objc.annotations.Weak;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
final class ImmutableMapKeySet<K, V> extends IndexedImmutableSet<K> {
	@Weak
	private final ImmutableMap<K, V> map;

	ImmutableMapKeySet(ImmutableMap<K, V> map) {
		this.map = map;
	}

	public int size() {
		return this.map.size();
	}

	public UnmodifiableIterator<K> iterator() {
		return this.map.keyIterator();
	}

	public boolean contains(@NullableDecl Object object) {
		return this.map.containsKey(object);
	}

	K get(int index) {
		return ((Entry) this.map.entrySet().asList().get(index)).getKey();
	}

	boolean isPartialView() {
		return true;
	}

	@GwtIncompatible
	Object writeReplace() {
		return new KeySetSerializedForm(this.map);
	}
}