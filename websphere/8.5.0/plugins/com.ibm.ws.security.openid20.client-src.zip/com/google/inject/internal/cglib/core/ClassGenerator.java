package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.ClassVisitor;

public interface ClassGenerator {
	void generateClass(ClassVisitor var1) throws Exception;
}