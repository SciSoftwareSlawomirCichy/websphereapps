package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableSet.Builder;
import com.google.common.collect.RegularImmutableTable.1;
import com.google.common.collect.RegularImmutableTable.DenseImmutableTable;
import com.google.common.collect.RegularImmutableTable.SparseImmutableTable;
import com.google.common.collect.Table.Cell;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;

@GwtCompatible
abstract class RegularImmutableTable<R, C, V> extends ImmutableTable<R, C, V> {
	private transient ImmutableCollection<V> values;
	private transient ImmutableSet<Cell<R, C, V>> cellSet;

	private RegularImmutableTable() {
	}

	public final ImmutableCollection<V> values() {
		ImmutableCollection<V> result = this.values;
		return result == null ? (this.values = this.createValues()) : result;
	}

	abstract ImmutableCollection<V> createValues();

	public abstract int size();

	public final boolean containsValue(@Nullable Object value) {
		return this.values().contains(value);
	}

	public final ImmutableSet<Cell<R, C, V>> cellSet() {
		ImmutableSet<Cell<R, C, V>> result = this.cellSet;
		return result == null ? (this.cellSet = this.createCellSet()) : result;
	}

	abstract ImmutableSet<Cell<R, C, V>> createCellSet();

	public final boolean isEmpty() {
		return false;
	}

	static final <R, C, V> RegularImmutableTable<R, C, V> forCells(List<Cell<R, C, V>> cells, @Nullable Comparator<? super R> rowComparator, @Nullable Comparator<? super C> columnComparator) {
      Preconditions.checkNotNull(cells);
      if (rowComparator != null || columnComparator != null) {
         Comparator<Cell<R, C, V>> comparator = new 1(rowComparator, columnComparator);
         Collections.sort(cells, comparator);
      }

      return forCellsInternal(cells, rowComparator, columnComparator);
   }

	static final <R, C, V> RegularImmutableTable<R, C, V> forCells(Iterable<Cell<R, C, V>> cells) {
		return forCellsInternal(cells, (Comparator) null, (Comparator) null);
	}

	private static final <R, C, V> RegularImmutableTable<R, C, V> forCellsInternal(Iterable<Cell<R, C, V>> cells,
			@Nullable Comparator<? super R> rowComparator, @Nullable Comparator<? super C> columnComparator) {
		Builder<R> rowSpaceBuilder = ImmutableSet.builder();
		Builder<C> columnSpaceBuilder = ImmutableSet.builder();
		ImmutableList<Cell<R, C, V>> cellList = ImmutableList.copyOf(cells);
		Iterator i$ = cellList.iterator();

		while (i$.hasNext()) {
			Cell<R, C, V> cell = (Cell) i$.next();
			rowSpaceBuilder.add(cell.getRowKey());
			columnSpaceBuilder.add(cell.getColumnKey());
		}

		ImmutableSet<R> rowSpace = rowSpaceBuilder.build();
		if (rowComparator != null) {
			List<R> rowList = Lists.newArrayList(rowSpace);
			Collections.sort(rowList, rowComparator);
			rowSpace = ImmutableSet.copyOf(rowList);
		}

		ImmutableSet<C> columnSpace = columnSpaceBuilder.build();
		if (columnComparator != null) {
			List<C> columnList = Lists.newArrayList(columnSpace);
			Collections.sort(columnList, columnComparator);
			columnSpace = ImmutableSet.copyOf(columnList);
		}

		return (RegularImmutableTable) (cellList.size() > rowSpace.size() * columnSpace.size() / 2
				? new DenseImmutableTable(cellList, rowSpace, columnSpace)
				: new SparseImmutableTable(cellList, rowSpace, columnSpace));
	}
}