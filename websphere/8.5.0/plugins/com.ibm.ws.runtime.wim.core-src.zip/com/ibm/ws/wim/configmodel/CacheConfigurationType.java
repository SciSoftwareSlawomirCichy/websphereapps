package com.ibm.ws.wim.configmodel;

public interface CacheConfigurationType {
	AttributesCacheType getAttributesCache();

	void setAttributesCache(AttributesCacheType var1);

	AttributesCacheType createAttributesCache();

	SearchResultsCacheType getSearchResultsCache();

	void setSearchResultsCache(SearchResultsCacheType var1);

	SearchResultsCacheType createSearchResultsCache();

	boolean isCachesDiskOffLoad();

	void setCachesDiskOffLoad(boolean var1);

	void unsetCachesDiskOffLoad();

	boolean isSetCachesDiskOffLoad();
}