package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_hu extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: A telepített alkalmazáskiszolgáló ügyfélösszetevők összeépítési szintjei nem egységesek. A telepített {0} ügyfélösszetevő összeépítési szintje {1}, és ez nem egyezik meg a(z) {2} ügyfélösszetevő {3} szintjével."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: A telepített alkalmazáskiszolgáló ügyfélösszetevők összeépítési szintjeinek inkonzisztenciája megakadályozza a további végrehajtást."},
			{"EXCP_CWSJE0003E", "CWSJE0003E: A(z) {1} erőforrás nem érhető el a következő kivétel miatt: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}