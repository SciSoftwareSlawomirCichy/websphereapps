package com.ibm.ws.security.oidc.client.filter;

public abstract class SimpleCondition implements ICondition {
	private String key;
	private IValue value;

	protected SimpleCondition(String key, IValue value) {
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return this.key;
	}

	public IValue getValue() {
		return this.value;
	}

	public String toString() {
		return this.getValue() + this.getOperand();
	}

	public abstract boolean checkCondition(IValue var1) throws FilterException;

	public abstract String getOperand();
}