package com.ibm.ws.security.oidc.client.filter;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class OrCondition implements ICondition {
	List<IValue> values = new LinkedList();
	String key;

	public OrCondition(String key, List<IValue> values) {
		this.values = values;
		this.key = key;
	}

	public OrCondition(String key) {
		this.key = key;
	}

	public boolean checkCondition(IValue test) throws FilterException {
		Iterator iter = this.values.iterator();

		IValue value;
		do {
			if (!iter.hasNext()) {
				return false;
			}

			value = (IValue) iter.next();
		} while (!value.containedBy(test));

		return true;
	}

	public String getKey() {
		return this.key;
	}

	public void addValue(IValue value) {
		this.values.add(value);
	}

	public String toString() {
		StringBuffer buf = new StringBuffer();
		Iterator iter = this.values.iterator();

		while (iter.hasNext()) {
			IValue value = (IValue) iter.next();
			buf.append(value);
			buf.append('|');
		}

		buf.append("^=");
		return buf.toString();
	}
}