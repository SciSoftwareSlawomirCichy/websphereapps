package com.google.gson.internal;

import com.google.gson.internal.UnsafeAllocator.1;
import com.google.gson.internal.UnsafeAllocator.2;
import com.google.gson.internal.UnsafeAllocator.3;
import com.google.gson.internal.UnsafeAllocator.4;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class UnsafeAllocator {
	public abstract <T> T newInstance(Class<T> var1) throws Exception;

	public static UnsafeAllocator create() {
      try {
         Class<?> unsafeClass = Class.forName("sun.misc.Unsafe");
         Field f = unsafeClass.getDeclaredField("theUnsafe");
         f.setAccessible(true);
         Object unsafe = f.get((Object)null);
         Method allocateInstance = unsafeClass.getMethod("allocateInstance", Class.class);
         return new 1(allocateInstance, unsafe);
      } catch (Exception var6) {
         Method getConstructorId;
         try {
            getConstructorId = ObjectInputStream.class.getDeclaredMethod("newInstance", Class.class, Class.class);
            getConstructorId.setAccessible(true);
            return new 2(getConstructorId);
         } catch (Exception var5) {
            try {
               getConstructorId = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
               getConstructorId.setAccessible(true);
               int constructorId = (Integer)getConstructorId.invoke((Object)null, Object.class);
               Method newInstance = ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, Integer.TYPE);
               newInstance.setAccessible(true);
               return new 3(newInstance, constructorId);
            } catch (Exception var4) {
               return new 4();
            }
         }
      }
   }
}