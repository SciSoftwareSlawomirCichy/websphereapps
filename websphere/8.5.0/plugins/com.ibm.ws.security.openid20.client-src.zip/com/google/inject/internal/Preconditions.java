package com.google.inject.internal;

import java.util.Collection;
import java.util.Iterator;

public final class Preconditions {
	public static void checkArgument(boolean expression) {
		if (!expression) {
			throw new IllegalArgumentException();
		}
	}

	public static void checkArgument(boolean expression, Object errorMessage) {
		if (!expression) {
			throw new IllegalArgumentException(String.valueOf(errorMessage));
		}
	}

	public static void checkArgument(boolean expression, String errorMessageTemplate, Object... errorMessageArgs) {
		if (!expression) {
			throw new IllegalArgumentException(format(errorMessageTemplate, errorMessageArgs));
		}
	}

	public static void checkState(boolean expression) {
		if (!expression) {
			throw new IllegalStateException();
		}
	}

	public static void checkState(boolean expression, Object errorMessage) {
		if (!expression) {
			throw new IllegalStateException(String.valueOf(errorMessage));
		}
	}

	public static void checkState(boolean expression, String errorMessageTemplate, Object... errorMessageArgs) {
		if (!expression) {
			throw new IllegalStateException(format(errorMessageTemplate, errorMessageArgs));
		}
	}

	public static <T> T checkNotNull(T reference) {
		if (reference == null) {
			throw new NullPointerException();
		} else {
			return reference;
		}
	}

	public static <T> T checkNotNull(T reference, Object errorMessage) {
		if (reference == null) {
			throw new NullPointerException(String.valueOf(errorMessage));
		} else {
			return reference;
		}
	}

	public static <T> T checkNotNull(T reference, String errorMessageTemplate, Object... errorMessageArgs) {
		if (reference == null) {
			throw new NullPointerException(format(errorMessageTemplate, errorMessageArgs));
		} else {
			return reference;
		}
	}

	public static <T extends Iterable<?>> T checkContentsNotNull(T iterable) {
		if (containsOrIsNull(iterable)) {
			throw new NullPointerException();
		} else {
			return iterable;
		}
	}

	public static <T extends Iterable<?>> T checkContentsNotNull(T iterable, Object errorMessage) {
		if (containsOrIsNull(iterable)) {
			throw new NullPointerException(String.valueOf(errorMessage));
		} else {
			return iterable;
		}
	}

	public static <T extends Iterable<?>> T checkContentsNotNull(T iterable, String errorMessageTemplate,
			Object... errorMessageArgs) {
		if (containsOrIsNull(iterable)) {
			throw new NullPointerException(format(errorMessageTemplate, errorMessageArgs));
		} else {
			return iterable;
		}
	}

	private static boolean containsOrIsNull(Iterable<?> iterable) {
		if (iterable == null) {
			return true;
		} else if (iterable instanceof Collection) {
			Collection collection = (Collection) iterable;

			try {
				return collection.contains((Object) null);
			} catch (NullPointerException var3) {
				return false;
			}
		} else {
			Iterator i$ = iterable.iterator();

			Object element;
			do {
				if (!i$.hasNext()) {
					return false;
				}

				element = i$.next();
			} while (element != null);

			return true;
		}
	}

	public static void checkElementIndex(int index, int size) {
		checkElementIndex(index, size, "index");
	}

	public static void checkElementIndex(int index, int size, String desc) {
		checkArgument(size >= 0, "negative size: %s", size);
		if (index < 0) {
			throw new IndexOutOfBoundsException(format("%s (%s) must not be negative", desc, index));
		} else if (index >= size) {
			throw new IndexOutOfBoundsException(format("%s (%s) must be less than size (%s)", desc, index, size));
		}
	}

	public static void checkPositionIndex(int index, int size) {
		checkPositionIndex(index, size, "index");
	}

	public static void checkPositionIndex(int index, int size, String desc) {
		checkArgument(size >= 0, "negative size: %s", size);
		if (index < 0) {
			throw new IndexOutOfBoundsException(format("%s (%s) must not be negative", desc, index));
		} else if (index > size) {
			throw new IndexOutOfBoundsException(
					format("%s (%s) must not be greater than size (%s)", desc, index, size));
		}
	}

	public static void checkPositionIndexes(int start, int end, int size) {
		checkPositionIndex(start, size, "start index");
		checkPositionIndex(end, size, "end index");
		if (end < start) {
			throw new IndexOutOfBoundsException(
					format("end index (%s) must not be less than start index (%s)", end, start));
		}
	}

	static String format(String template, Object... args) {
		StringBuilder builder = new StringBuilder(template.length() + 16 * args.length);
		int templateStart = 0;

		int i;
		int placeholderStart;
		for (i = 0; i < args.length; templateStart = placeholderStart + 2) {
			placeholderStart = template.indexOf("%s", templateStart);
			if (placeholderStart == -1) {
				break;
			}

			builder.append(template.substring(templateStart, placeholderStart));
			builder.append(args[i++]);
		}

		builder.append(template.substring(templateStart));
		if (i < args.length) {
			builder.append(" [");
			builder.append(args[i++]);

			while (i < args.length) {
				builder.append(", ");
				builder.append(args[i++]);
			}

			builder.append("]");
		}

		return builder.toString();
	}
}