package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.ws.ActivitySession.ActivitySession;
import javax.transaction.Transaction;

final class AS_Unknown extends ActivitySessionStrategy {
	AS_Unknown(UOWControlImpl UOWCtrl) {
		super(UOWCtrl);
	}

	ASCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		return new ASCookieImpl(false, this, (ActivitySession) null, (Transaction) null);
	}

	void postInvoke(EJBKey key, ASCookieImpl ASCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
	}
}