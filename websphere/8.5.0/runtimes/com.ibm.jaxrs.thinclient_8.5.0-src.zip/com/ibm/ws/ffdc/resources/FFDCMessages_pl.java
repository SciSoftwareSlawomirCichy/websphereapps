package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_pl extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Mechanizm analizy używa bazy danych: {0}"},
			{"FFDCIncidentEmitted",
					"FFDC1003I: Zdarzenie FFDC zostało wyemitowane w następującym miejscu: {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: Funkcja zarządzania plikami dzienników FFDC próbuje usunąć plik {0}"},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: Funkcja zarządzania plikami dzienników FFDC usunęła {0} z {1} plików, które osiągnęły skonfigurowany dla nich maksymalny wiek"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: Nie powiodła się próba usunięcia pliku {0} przez funkcję zarządzania plikami dzienników FFDC"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: Nie powiodła się próba pobrania listy plików wyjątków przez funkcję zarządzania plikami dzienników FFDC"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: Mechanizm FFDC zamknął plik strumienia zdarzenia {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: Mechanizm FFDC otworzył plik strumienia zdarzenia {0}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: Nie powiodła się próba zamknięcia pliku strumienia zdarzenia {0} przez mechanizm FFDC. Wychwycony wyjątek: {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: Nie powiodła się próba otwarcia lub utworzenia pliku strumienia zdarzenia {0} przez mechanizm FFDC. Wychwycony wyjątek: {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: Nie powiodła się próba dokonania zapisu w pliku strumienia zdarzenia {0} przez mechanizm FFDC. Wychwycony wyjątek: {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}