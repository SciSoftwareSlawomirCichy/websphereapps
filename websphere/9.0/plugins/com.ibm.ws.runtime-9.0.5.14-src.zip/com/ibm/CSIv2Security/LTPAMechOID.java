package com.ibm.CSIv2Security;

public interface LTPAMechOID {
	String value = "oid:1.3.18.0.2.30.2";
}