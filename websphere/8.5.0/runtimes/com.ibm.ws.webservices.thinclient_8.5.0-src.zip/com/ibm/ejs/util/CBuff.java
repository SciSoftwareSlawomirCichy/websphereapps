package com.ibm.ejs.util;

import com.ibm.ejs.util.CBuff.CBuffEnum;
import com.ibm.ffdc.Manager;
import java.util.Enumeration;

public class CBuff {
	protected int size = 1024;
	protected Object[] elements;
	protected int tail = -1;
	protected int count = 0;

	public CBuff(int n) {
		this.elements = new Object[this.size];
		this.setSize(n);
	}

	public void put(Object o) {
		if (this.size != 0) {
			if (this.count < this.size) {
				++this.count;
			}

			this.tail = (this.tail + 1) % this.size;
			this.elements[this.tail] = o;
		}

	}

	public int getSize() {
		return this.size;
	}

	public void setSize(int newSize) {
		if (newSize != this.size && newSize >= 0) {
			try {
				Object[] newElements = new Object[newSize];
				if (newSize < this.count || this.size == this.count && this.size != 0) {
					int head = false;
					int copyCount = false;
					int copyBase = false;
					int head;
					int copyBase;
					if (this.size > newSize) {
						copyBase = newSize;
						head = (this.tail + this.size - newSize + 1) % this.size;
					} else {
						copyBase = this.size;
						head = (this.tail + 1) % this.size;
					}

					int copyCount;
					if (copyBase < this.size - head) {
						copyCount = copyBase;
					} else {
						copyCount = this.size - head;
					}

					System.arraycopy(this.elements, head, newElements, 0, copyCount);
					if (copyCount < copyBase) {
						System.arraycopy(this.elements, 0, newElements, copyCount, copyBase - copyCount);
					}

					this.count = copyBase;
					this.tail = copyBase - 1;
				} else {
					System.arraycopy(this.elements, 0, newElements, 0, this.count);
				}

				this.size = newSize;
				this.elements = newElements;
			} catch (OutOfMemoryError var6) {
				Manager.Ffdc.log(var6, this, "com.ibm.ejs.util.CBuff.setSize", "170", new Object[]{this});
			}

		}
	}

	public Enumeration elements() {
		int head = -1;
		if (this.count == this.size) {
			head = this.tail;
		}

		return new CBuffEnum(this, this.elements, this.size, this.count, head, this.tail);
	}
}