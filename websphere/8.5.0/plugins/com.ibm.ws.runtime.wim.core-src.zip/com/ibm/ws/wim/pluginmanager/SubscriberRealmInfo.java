package com.ibm.ws.wim.pluginmanager;

import com.ibm.wsspi.wim.pluginmanager.Subscriber;
import java.util.HashSet;
import java.util.Iterator;

public class SubscriberRealmInfo {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private HashSet realmSet;
	private Subscriber subscriber;
	private static String newline = System.getProperty("line.separator");

	public SubscriberRealmInfo(Subscriber var1, HashSet var2) {
		this.realmSet = var2;
		this.subscriber = var1;
	}

	public boolean doesContainRealm(String var1) {
		return this.realmSet.contains(var1);
	}

	public Subscriber getSubscriber() {
		return this.subscriber;
	}

	public void setSubscriber(Subscriber var1) {
		this.subscriber = var1;
	}

	public String getSubscriberName() {
		return this.subscriber.getSubscriberName();
	}

	public boolean equals(Object var1) {
		if (!(var1 instanceof SubscriberRealmInfo)) {
			return false;
		} else {
			SubscriberRealmInfo var2 = (SubscriberRealmInfo) var1;
			boolean var3 = this.subscriber.getSubscriberName().equals(var2.getSubscriberName());
			boolean var4 = this.realmSet.equals(var2.realmSet);
			return var3 && var4;
		}
	}

	public HashSet getRealmSet() {
		return this.realmSet;
	}

	public void setRealmSet(HashSet var1) {
		this.realmSet = var1;
	}

	public String printSubscriberRealmInfo() {
		StringBuffer var1 = new StringBuffer();
		var1.append(" SubscriberName: ").append(this.getSubscriberName()).append(" RealmList: ");
		Iterator var2 = this.realmSet.iterator();

		while (var2.hasNext()) {
			var1.append(var2.next()).append(" ");
		}

		var1.append(newline);
		return var1.toString();
	}
}