package com.ibm.ws.wim.configmodel.util;

import com.ibm.ws.wim.configmodel.AttributeConfigurationType;
import com.ibm.ws.wim.configmodel.AttributeGroupType;
import com.ibm.ws.wim.configmodel.AttributeType;
import com.ibm.ws.wim.configmodel.AttributesCacheType;
import com.ibm.ws.wim.configmodel.AuthorizationType;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.CacheConfigurationType;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.ContextPoolType;
import com.ibm.ws.wim.configmodel.CustomPropertiesType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.configmodel.DocumentRoot;
import com.ibm.ws.wim.configmodel.DynamicMemberAttributesType;
import com.ibm.ws.wim.configmodel.DynamicModelType;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import com.ibm.ws.wim.configmodel.EnvironmentPropertiesType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.GroupConfigurationType;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.Krb5AuthenticationType;
import com.ibm.ws.wim.configmodel.LdapEntityTypesType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.MemberAttributesType;
import com.ibm.ws.wim.configmodel.MembershipAttributeType;
import com.ibm.ws.wim.configmodel.ModificationSubscriber;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import com.ibm.ws.wim.configmodel.NotificationSubscriber;
import com.ibm.ws.wim.configmodel.NotificationSubscriberList;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.PostExit;
import com.ibm.ws.wim.configmodel.PreExit;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.PropertiesNotSupportedType;
import com.ibm.ws.wim.configmodel.PropertyExtensionRepositoryType;
import com.ibm.ws.wim.configmodel.RdnAttributesType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmDefaultParentType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.configmodel.SPIBridgeRepositoryType;
import com.ibm.ws.wim.configmodel.SearchResultsCacheType;
import com.ibm.ws.wim.configmodel.StaticModelType;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import com.ibm.ws.wim.configmodel.TopicSubscriber;
import com.ibm.ws.wim.configmodel.TopicSubscriberList;
import com.ibm.ws.wim.configmodel.UserRegistryInfoMappingType;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

public class ConfigmodelSwitch {
	protected static ConfigmodelPackage modelPackage;

	public ConfigmodelSwitch() {
		if (modelPackage == null) {
			modelPackage = ConfigmodelPackage.eINSTANCE;
		}

	}

	public Object doSwitch(EObject var1) {
		return this.doSwitch(var1.eClass(), var1);
	}

	protected Object doSwitch(EClass var1, EObject var2) {
		if (var1.eContainer() == modelPackage) {
			return this.doSwitch(var1.getClassifierID(), var2);
		} else {
			EList var3 = var1.getESuperTypes();
			return var3.isEmpty() ? this.defaultCase(var2) : this.doSwitch((EClass) var3.get(0), var2);
		}
	}

	protected Object doSwitch(int var1, EObject var2) {
		Object var4;
		switch (var1) {
			case 0 :
				AttributeConfigurationType var55 = (AttributeConfigurationType) var2;
				var4 = this.caseAttributeConfigurationType(var55);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 1 :
				AttributeGroupType var54 = (AttributeGroupType) var2;
				var4 = this.caseAttributeGroupType(var54);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 2 :
				AttributesCacheType var53 = (AttributesCacheType) var2;
				var4 = this.caseAttributesCacheType(var53);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 3 :
				AttributeType var52 = (AttributeType) var2;
				var4 = this.caseAttributeType(var52);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 4 :
				AuthorizationType var51 = (AuthorizationType) var2;
				var4 = this.caseAuthorizationType(var51);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 5 :
				BaseEntriesType var50 = (BaseEntriesType) var2;
				var4 = this.caseBaseEntriesType(var50);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 6 :
				CacheConfigurationType var49 = (CacheConfigurationType) var2;
				var4 = this.caseCacheConfigurationType(var49);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 7 :
				ConfigurationProviderType var48 = (ConfigurationProviderType) var2;
				var4 = this.caseConfigurationProviderType(var48);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 8 :
				ConnectionsType var47 = (ConnectionsType) var2;
				var4 = this.caseConnectionsType(var47);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 9 :
				ContextPoolType var46 = (ContextPoolType) var2;
				var4 = this.caseContextPoolType(var46);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 10 :
				CustomPropertiesType var45 = (CustomPropertiesType) var2;
				var4 = this.caseCustomPropertiesType(var45);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 11 :
				DatabaseRepositoryType var44 = (DatabaseRepositoryType) var2;
				var4 = this.caseDatabaseRepositoryType(var44);
				if (var4 == null) {
					var4 = this.caseProfileRepositoryType(var44);
				}

				if (var4 == null) {
					var4 = this.caseRepositoryType(var44);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 12 :
				DocumentRoot var43 = (DocumentRoot) var2;
				var4 = this.caseDocumentRoot(var43);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 13 :
				DynamicMemberAttributesType var42 = (DynamicMemberAttributesType) var2;
				var4 = this.caseDynamicMemberAttributesType(var42);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 14 :
				DynamicModelType var41 = (DynamicModelType) var2;
				var4 = this.caseDynamicModelType(var41);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 15 :
				EntryMappingRepositoryType var40 = (EntryMappingRepositoryType) var2;
				var4 = this.caseEntryMappingRepositoryType(var40);
				if (var4 == null) {
					var4 = this.caseRepositoryType(var40);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 16 :
				EnvironmentPropertiesType var39 = (EnvironmentPropertiesType) var2;
				var4 = this.caseEnvironmentPropertiesType(var39);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 17 :
				FileRepositoryType var38 = (FileRepositoryType) var2;
				var4 = this.caseFileRepositoryType(var38);
				if (var4 == null) {
					var4 = this.caseProfileRepositoryType(var38);
				}

				if (var4 == null) {
					var4 = this.caseRepositoryType(var38);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 18 :
				GroupConfigurationType var37 = (GroupConfigurationType) var2;
				var4 = this.caseGroupConfigurationType(var37);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 19 :
				InlineExit var36 = (InlineExit) var2;
				var4 = this.caseInlineExit(var36);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 20 :
				LdapEntityTypesType var35 = (LdapEntityTypesType) var2;
				var4 = this.caseLdapEntityTypesType(var35);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 21 :
				LdapRepositoryType var34 = (LdapRepositoryType) var2;
				var4 = this.caseLdapRepositoryType(var34);
				if (var4 == null) {
					var4 = this.caseProfileRepositoryType(var34);
				}

				if (var4 == null) {
					var4 = this.caseRepositoryType(var34);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 22 :
				LdapServerConfigurationType var33 = (LdapServerConfigurationType) var2;
				var4 = this.caseLdapServerConfigurationType(var33);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 23 :
				LdapServersType var32 = (LdapServersType) var2;
				var4 = this.caseLdapServersType(var32);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 24 :
				MemberAttributesType var31 = (MemberAttributesType) var2;
				var4 = this.caseMemberAttributesType(var31);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 25 :
				MembershipAttributeType var30 = (MembershipAttributeType) var2;
				var4 = this.caseMembershipAttributeType(var30);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 26 :
				ModificationSubscriber var29 = (ModificationSubscriber) var2;
				var4 = this.caseModificationSubscriber(var29);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 27 :
				ModificationSubscriberList var28 = (ModificationSubscriberList) var2;
				var4 = this.caseModificationSubscriberList(var28);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 28 :
				NotificationSubscriber var27 = (NotificationSubscriber) var2;
				var4 = this.caseNotificationSubscriber(var27);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 29 :
				NotificationSubscriberList var26 = (NotificationSubscriberList) var2;
				var4 = this.caseNotificationSubscriberList(var26);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 30 :
				ParticipatingBaseEntriesType var25 = (ParticipatingBaseEntriesType) var2;
				var4 = this.caseParticipatingBaseEntriesType(var25);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 31 :
				PluginManagerConfigurationType var24 = (PluginManagerConfigurationType) var2;
				var4 = this.casePluginManagerConfigurationType(var24);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 32 :
				PostExit var23 = (PostExit) var2;
				var4 = this.casePostExit(var23);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 33 :
				PreExit var22 = (PreExit) var2;
				var4 = this.casePreExit(var22);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 34 :
				ProfileRepositoryType var21 = (ProfileRepositoryType) var2;
				var4 = this.caseProfileRepositoryType(var21);
				if (var4 == null) {
					var4 = this.caseRepositoryType(var21);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 35 :
				PropertiesNotSupportedType var20 = (PropertiesNotSupportedType) var2;
				var4 = this.casePropertiesNotSupportedType(var20);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 36 :
				PropertyExtensionRepositoryType var19 = (PropertyExtensionRepositoryType) var2;
				var4 = this.casePropertyExtensionRepositoryType(var19);
				if (var4 == null) {
					var4 = this.caseRepositoryType(var19);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 37 :
				RdnAttributesType var18 = (RdnAttributesType) var2;
				var4 = this.caseRdnAttributesType(var18);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 38 :
				RealmConfigurationType var17 = (RealmConfigurationType) var2;
				var4 = this.caseRealmConfigurationType(var17);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 39 :
				RealmDefaultParentType var16 = (RealmDefaultParentType) var2;
				var4 = this.caseRealmDefaultParentType(var16);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 40 :
				RealmType var15 = (RealmType) var2;
				var4 = this.caseRealmType(var15);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 41 :
				RepositoryType var14 = (RepositoryType) var2;
				var4 = this.caseRepositoryType(var14);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 42 :
				SearchResultsCacheType var13 = (SearchResultsCacheType) var2;
				var4 = this.caseSearchResultsCacheType(var13);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 43 :
				SPIBridgeRepositoryType var12 = (SPIBridgeRepositoryType) var2;
				var4 = this.caseSPIBridgeRepositoryType(var12);
				if (var4 == null) {
					var4 = this.caseProfileRepositoryType(var12);
				}

				if (var4 == null) {
					var4 = this.caseRepositoryType(var12);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 44 :
				StaticModelType var11 = (StaticModelType) var2;
				var4 = this.caseStaticModelType(var11);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 45 :
				SupportedEntityTypesType var10 = (SupportedEntityTypesType) var2;
				var4 = this.caseSupportedEntityTypesType(var10);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 46 :
				TopicEmitter var9 = (TopicEmitter) var2;
				var4 = this.caseTopicEmitter(var9);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 47 :
				TopicRegistrationList var8 = (TopicRegistrationList) var2;
				var4 = this.caseTopicRegistrationList(var8);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 48 :
				TopicSubscriber var7 = (TopicSubscriber) var2;
				var4 = this.caseTopicSubscriber(var7);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 49 :
				TopicSubscriberList var6 = (TopicSubscriberList) var2;
				var4 = this.caseTopicSubscriberList(var6);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 50 :
				UserRegistryInfoMappingType var5 = (UserRegistryInfoMappingType) var2;
				var4 = this.caseUserRegistryInfoMappingType(var5);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 51 :
			case 52 :
			case 53 :
			case 54 :
			case 55 :
			case 56 :
			case 57 :
			case 58 :
			case 59 :
			case 60 :
			case 61 :
			case 62 :
			case 63 :
			case 64 :
			case 65 :
			case 66 :
			case 67 :
			case 68 :
			case 69 :
			case 70 :
			case 71 :
			default :
				return this.defaultCase(var2);
			case 72 :
				Krb5AuthenticationType var3 = (Krb5AuthenticationType) var2;
				var4 = this.caseKrb5AuthenticationType(var3);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
		}
	}

	public Object caseAttributeConfigurationType(AttributeConfigurationType var1) {
		return null;
	}

	public Object caseAttributeGroupType(AttributeGroupType var1) {
		return null;
	}

	public Object caseAttributesCacheType(AttributesCacheType var1) {
		return null;
	}

	public Object caseAttributeType(AttributeType var1) {
		return null;
	}

	public Object caseAuthorizationType(AuthorizationType var1) {
		return null;
	}

	public Object caseBaseEntriesType(BaseEntriesType var1) {
		return null;
	}

	public Object caseCacheConfigurationType(CacheConfigurationType var1) {
		return null;
	}

	public Object caseConfigurationProviderType(ConfigurationProviderType var1) {
		return null;
	}

	public Object caseConnectionsType(ConnectionsType var1) {
		return null;
	}

	public Object caseContextPoolType(ContextPoolType var1) {
		return null;
	}

	public Object caseCustomPropertiesType(CustomPropertiesType var1) {
		return null;
	}

	public Object caseDatabaseRepositoryType(DatabaseRepositoryType var1) {
		return null;
	}

	public Object caseDocumentRoot(DocumentRoot var1) {
		return null;
	}

	public Object caseDynamicMemberAttributesType(DynamicMemberAttributesType var1) {
		return null;
	}

	public Object caseDynamicModelType(DynamicModelType var1) {
		return null;
	}

	public Object caseEntryMappingRepositoryType(EntryMappingRepositoryType var1) {
		return null;
	}

	public Object caseEnvironmentPropertiesType(EnvironmentPropertiesType var1) {
		return null;
	}

	public Object caseKrb5AuthenticationType(Krb5AuthenticationType var1) {
		return null;
	}

	public Object caseFileRepositoryType(FileRepositoryType var1) {
		return null;
	}

	public Object caseGroupConfigurationType(GroupConfigurationType var1) {
		return null;
	}

	public Object caseInlineExit(InlineExit var1) {
		return null;
	}

	public Object caseLdapEntityTypesType(LdapEntityTypesType var1) {
		return null;
	}

	public Object caseLdapRepositoryType(LdapRepositoryType var1) {
		return null;
	}

	public Object caseLdapServerConfigurationType(LdapServerConfigurationType var1) {
		return null;
	}

	public Object caseLdapServersType(LdapServersType var1) {
		return null;
	}

	public Object caseMemberAttributesType(MemberAttributesType var1) {
		return null;
	}

	public Object caseMembershipAttributeType(MembershipAttributeType var1) {
		return null;
	}

	public Object caseModificationSubscriber(ModificationSubscriber var1) {
		return null;
	}

	public Object caseModificationSubscriberList(ModificationSubscriberList var1) {
		return null;
	}

	public Object caseNotificationSubscriber(NotificationSubscriber var1) {
		return null;
	}

	public Object caseNotificationSubscriberList(NotificationSubscriberList var1) {
		return null;
	}

	public Object caseParticipatingBaseEntriesType(ParticipatingBaseEntriesType var1) {
		return null;
	}

	public Object casePluginManagerConfigurationType(PluginManagerConfigurationType var1) {
		return null;
	}

	public Object casePostExit(PostExit var1) {
		return null;
	}

	public Object casePreExit(PreExit var1) {
		return null;
	}

	public Object caseProfileRepositoryType(ProfileRepositoryType var1) {
		return null;
	}

	public Object casePropertiesNotSupportedType(PropertiesNotSupportedType var1) {
		return null;
	}

	public Object casePropertyExtensionRepositoryType(PropertyExtensionRepositoryType var1) {
		return null;
	}

	public Object caseRdnAttributesType(RdnAttributesType var1) {
		return null;
	}

	public Object caseRealmConfigurationType(RealmConfigurationType var1) {
		return null;
	}

	public Object caseRealmDefaultParentType(RealmDefaultParentType var1) {
		return null;
	}

	public Object caseRealmType(RealmType var1) {
		return null;
	}

	public Object caseRepositoryType(RepositoryType var1) {
		return null;
	}

	public Object caseSearchResultsCacheType(SearchResultsCacheType var1) {
		return null;
	}

	public Object caseSPIBridgeRepositoryType(SPIBridgeRepositoryType var1) {
		return null;
	}

	public Object caseStaticModelType(StaticModelType var1) {
		return null;
	}

	public Object caseSupportedEntityTypesType(SupportedEntityTypesType var1) {
		return null;
	}

	public Object caseTopicEmitter(TopicEmitter var1) {
		return null;
	}

	public Object caseTopicRegistrationList(TopicRegistrationList var1) {
		return null;
	}

	public Object caseTopicSubscriber(TopicSubscriber var1) {
		return null;
	}

	public Object caseTopicSubscriberList(TopicSubscriberList var1) {
		return null;
	}

	public Object caseUserRegistryInfoMappingType(UserRegistryInfoMappingType var1) {
		return null;
	}

	public Object defaultCase(EObject var1) {
		return null;
	}
}