package com.ibm.ejs.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MathUtil {
	public static final int MAX_PRIME_INTEGER = 2147482661;

	public static int findNextPrime(int number) {
		if (number <= 2) {
			return 2;
		} else {
			if (isEven(number)) {
				++number;
			}

			if (number > 2147482661) {
				return number;
			} else {
				for (int next = number; next < number + 1000; next += 2) {
					if (isPrime(next)) {
						return next;
					}
				}

				return number;
			}
		}
	}

	public static boolean isPrime(int number) {
		if (number != 2 && number != 3 && number != 5 && number != 7 && number != 11 && number != 13 && number != 17
				&& number != 19) {
			if (number % 2 != 0 && number % 3 != 0 && number % 5 != 0 && number % 7 != 0 && number % 11 != 0
					&& number % 13 != 0 && number % 17 != 0 && number % 19 != 0) {
				long numberMinusOne = (long) (number - 1);
				long s = 0L;

				long d;
				for (d = numberMinusOne; isEven(d); ++s) {
					d /= 2L;
				}

				long d1 = d;

				for (int a = 2; a <= 5; ++a) {
					if (a != 4) {
						long prod = 1L;
						long a2j = (long) a;

						for (d = d1; d > 0L; a2j = a2j * a2j % (long) number) {
							if (isOdd(d)) {
								prod = prod * a2j % (long) number;
							}

							d /= 2L;
						}

						if (prod != 1L && prod != numberMinusOne) {
							for (long i = 1L; i <= s; ++i) {
								prod = prod * prod % (long) number;
								if (prod == numberMinusOne) {
									break;
								}
							}

							if (prod != numberMinusOne) {
								return false;
							}
						}
					}
				}

				if (number != 25326001 && number != 161304001 && number != 960946321 && number != 1157839381) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return true;
		}
	}

	public static boolean isOdd(int number) {
		return isOdd((long) number);
	}

	public static boolean isOdd(long number) {
		return number % 2L != 0L;
	}

	public static boolean isEven(int number) {
		return isEven((long) number);
	}

	public static boolean isEven(long number) {
		return number % 2L == 0L;
	}

	public static void main(String[] args) {
		System.out.println("Testing out findNextPrime()....................");
		Date start = new Date();
		int prime = 0;
		int primesToFind = 100008;
		int columns = 9;
		int[] primes = new int[columns];
		int index = false;

		for (int i = 0; i < primesToFind; ++i) {
			prime = findNextPrime(prime);
			int index = i % columns;
			primes[index] = prime;
			if (index == columns - 1) {
				String output = "Primes[" + (i + 1) + "] : ";

				for (int j = 0; j < columns; ++j) {
					output = output + primes[j];
					if (j < columns - 1) {
						output = output + ", ";
					}
				}

				System.out.println(output);
			}

			switch (i + 1) {
				case 100 :
					if (prime != 541) {
						System.out.println("ERROR - findNextPrime not working!!!!!!!!!!!!!");
						System.out.println("100th prime is 541, but found " + prime);
						System.exit(-1);
					}
					break;
				case 1000 :
					if (prime != 7919) {
						System.out.println("ERROR - findNextPrime not working!!!!!!!!!!!!!");
						System.out.println("1,000th prime is 7919, but found " + prime);
						System.exit(-1);
					}
					break;
				case 10000 :
					if (prime != 104729) {
						System.out.println("ERROR - findNextPrime not working!!!!!!!!!!!!!");
						System.out.println("10,000th prime is 104729, but found " + prime);
						System.exit(-1);
					}
					break;
				case 100008 :
					if (prime != 1299827) {
						System.out.println("ERROR - findNextPrime not working!!!!!!!!!!!!!");
						System.out.println("100,008th prime is 1299827, but found " + prime);
						System.exit(-1);
					}
			}

			++prime;
		}

		Date end = new Date();
		long findTime = end.getTime() - start.getTime();
		Date find = new Date(findTime);
		SimpleDateFormat formatter = new SimpleDateFormat("mm:ss:SS");
		String findTimeStr = formatter.format(find);
		System.out.println("Time to find " + primesToFind + " primes : " + findTimeStr);
		System.exit(0);
	}
}