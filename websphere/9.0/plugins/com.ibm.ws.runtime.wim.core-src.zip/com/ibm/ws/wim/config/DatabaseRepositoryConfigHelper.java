package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.util.PasswordEncryptionUtil;
import commonj.sdo.DataObject;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.SecretKeyFactory;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EcoreUtil;

public class DatabaseRepositoryConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public String createIdMgrDBRepository(String var1, Map<String, Object> var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "createIdMgrDBRepository",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("dataSourceName");
		String var7 = (String) var2.get("databaseType");
		String var8 = (String) var2.get("dbURL");
		String var9 = (String) var2.get("dbAdminId");
		String var10 = (String) var2.get("dbAdminPassword");
		String var11 = (String) var2.get("JDBCDriverClass");
		Integer var12 = (Integer) var2.get("entityRetrievalLimit");
		Integer var13 = (Integer) var2.get("saltLength");
		String var14 = (String) var2.get("encryptionKey");
		String var15 = (String) var2.get("dbSchema");
		String var16 = (String) var2.get("hashAlgorithm");
		Integer var17 = (Integer) var2.get("hashSaltLength");
		Integer var18 = (Integer) var2.get("hashKeyLength");
		Integer var19 = (Integer) var2.get("hashIterations");
		ValidationHelper.validateRequiredDBParameters(var2, CLASSNAME, "createIdMgrDBRepository");
		ValidationHelper.validateIntegerInput("saltLength", CLASSNAME, "createIdMgrDBRepository", var13);
		ValidationHelper.validateIntegerInput("hashSaltLength", CLASSNAME, "createIdMgrDBRepository", var17);
		ValidationHelper.validateIntegerInput("hashKeyLength", CLASSNAME, "createIdMgrDBRepository", var18);
		ValidationHelper.validateIntegerInput("hashIterations", CLASSNAME, "createIdMgrDBRepository", var19);
		ConfigUtils.checkForValidRepositoryById(var1, var5);
		ConfigValidator.validateRepositoryParams(var5, "DatabaseRepositoryType", var2);
		validateHashAlgorithm(var16);
		ConfigUtils.getRepositoryById(var1, var5, false);
		ConfigurationProviderType var20 = ConfigUtils.getConfigProvider(var1);
		EClass var21 = ConfigManager.singleton().getConfigEClass("DatabaseRepositoryType");
		DataObject var22 = (DataObject) EcoreUtil.create(var21);
		var22.setString("id", var5);
		var20.getRepositories().add(var22);
		DatabaseRepositoryType var23 = (DatabaseRepositoryType) ConfigUtils.getRepositoryById(var20, var5);
		ConfigUtils.setCommonRepositoryProperties(var23, var2, this.getDefaultValue(), false);
		if (var6 != null) {
			var23.setDataSourceName(var6);
		}

		if (var7 != null) {
			var23.setDatabaseType(var7);
		}

		if (var8 != null) {
			var23.setDbURL(var8);
		}

		if (var9 != null) {
			var23.setDbAdminId(var9);
		}

		if (var10 != null) {
			var23.setDbAdminPassword(ConfigUtils.encodePassword(var10));
		}

		if (var15 != null) {
			var23.setDbSchema(var15);
		}

		if (var11 != null) {
			var23.setJDBCDriverClass(var11);
		}

		if (var12 != null) {
			var23.setEntityRetrievalLimit(var12);
		}

		if (var13 != null) {
			var23.setSaltLength(var13);
		}

		if (var14 != null) {
			var23.setEncryptionKey(var14);
		}

		if (var16 != null && !"SHA-1".equalsIgnoreCase(var16)) {
			var23.setHashAlgorithm(var16);
		}

		if (var19 != null) {
			var23.setHashIterations(var19);
		}

		if (var18 != null) {
			var23.setHashKeyLength(var18);
		}

		if (var17 != null) {
			var23.setHashSaltLength(var17);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "createIdMgrDBRepository");
		}

		ConfigUtils.saveConfig(var1);
		return "MUST_ADD_BASE_ENTRY_TO_REPOSITORY";
	}

	public String updateIdMgrDBRepository(String var1, Map var2) throws WIMException {
		String var4 = (String) var2.get("id");
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "updateIdMgrDBRepository",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		DatabaseRepositoryType var6 = (DatabaseRepositoryType) ConfigUtils.validateAndGetRepository(var1, var4,
				"DatabaseRepositoryType");
		String var7 = (String) var2.get("dataSourceName");
		String var8 = (String) var2.get("databaseType");
		String var9 = (String) var2.get("dbURL");
		String var10 = (String) var2.get("dbAdminId");
		String var11 = (String) var2.get("dbAdminPassword");
		String var12 = (String) var2.get("JDBCDriverClass");
		Integer var13 = (Integer) var2.get("entityRetrievalLimit");
		Integer var14 = (Integer) var2.get("saltLength");
		String var15 = (String) var2.get("encryptionKey");
		String var16 = (String) var2.get("dbSchema");
		String var17 = (String) var2.get("hashAlgorithm");
		Integer var18 = (Integer) var2.get("hashSaltLength");
		Integer var19 = (Integer) var2.get("hashKeyLength");
		Integer var20 = (Integer) var2.get("hashIterations");
		if (var14 != null) {
			ValidationHelper.validateIntegerInput("saltLength", CLASSNAME, "updateIdMgrDBRepository", var14);
		}

		if (var8 != null) {
			ValidationHelper.validateParam("databaseType", var8, CONFIG_DB_SUPPORTED_TYPES);
		}

		ValidationHelper.validateIntegerInput("hashSaltLength", CLASSNAME, "updateIdMgrDBRepository", var18);
		ValidationHelper.validateIntegerInput("hashKeyLength", CLASSNAME, "updateIdMgrDBRepository", var19);
		ValidationHelper.validateIntegerInput("hashIterations", CLASSNAME, "updateIdMgrDBRepository", var20);
		HashMap var21 = new HashMap();
		boolean var22 = ConfigUtils.buildMapFromOldAndNewValues(var21, ConfigValidator.DB_CONNECTION_PARAMS,
				(DataObject) var6, var2);
		if (var22) {
			ConfigValidator.validateDBParams(var4, var21);
		}

		validateHashAlgorithm(var17);
		if (var7 != null) {
			var6.setDataSourceName(var7);
		}

		if (var8 != null) {
			var6.setDatabaseType(var8);
		}

		if (var9 != null) {
			var6.setDbURL(var9);
		}

		if (var10 != null) {
			var6.setDbAdminId(var10);
		}

		if (var11 != null) {
			var6.setDbAdminPassword(ConfigUtils.encodePassword(var11));
		}

		if (var16 != null) {
			var6.setDbSchema(var16);
		}

		if (var12 != null) {
			var6.setJDBCDriverClass(var12);
		}

		if (var13 != null) {
			var6.setEntityRetrievalLimit(var13);
		}

		if (var14 != null) {
			var6.setSaltLength(var14);
		}

		if (var15 != null) {
			var6.setEncryptionKey(var15);
		}

		if (var17 != null) {
			if ("SHA-1".equalsIgnoreCase(var17)) {
				var6.setHashAlgorithm((String) null);
			} else {
				var6.setHashAlgorithm(var17);
			}
		}

		if (var20 != null) {
			var6.setHashIterations(var20);
		}

		if (var19 != null) {
			var6.setHashKeyLength(var19);
		}

		if (var18 != null) {
			var6.setHashSaltLength(var18);
		}

		if (var5) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrDBRepository");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List<?> listIdMgrSupportedDBTypes(String var1) throws WIMException {
		return ConfigUtils.convertArrayToList(CONFIG_DB_SUPPORTED_TYPES);
	}

	private Map<String, Object> getDefaultValue() {
		HashMap var1 = null;
		var1 = new HashMap();
		var1.put("adapterClassName", "com.ibm.ws.wim.adapter.db.DBAdapter");
		var1.put("supportPaging", Boolean.valueOf("false"));
		var1.put("supportSorting", Boolean.valueOf("false"));
		var1.put("supportTransactions", Boolean.valueOf("false"));
		var1.put("isExtIdUnique", Boolean.valueOf("true"));
		var1.put("supportExternalName", Boolean.valueOf("false"));
		var1.put("supportExternalName", Boolean.valueOf("false"));
		return var1;
	}

	public static void validateHashAlgorithm(String var0) throws WIMConfigurationException {
		if (var0 != null && !var0.trim().isEmpty()) {
			if (PasswordEncryptionUtil.isPbkdf2(var0)) {
				ConfigValidator.checkNodeVersionsForHashing();

				try {
					SecretKeyFactory.getInstance(var0);
				} catch (NoSuchAlgorithmException var3) {
					throw new WIMConfigurationException("CONFIG_VALUE_NOT_VALID",
							WIMMessageHelper.generateMsgParms(var0, "hashAlgorithm",
									WIMTraceHelper.printObjectArray(getSupportedHashingAlgorithms())),
							Level.SEVERE, CLASSNAME, "validateHashAlgorithm");
				}
			} else if (!"SHA-1".equalsIgnoreCase(var0)) {
				throw new WIMConfigurationException("CONFIG_VALUE_NOT_VALID",
						WIMMessageHelper.generateMsgParms(var0, "hashAlgorithm",
								WIMTraceHelper.printObjectArray(getSupportedHashingAlgorithms())),
						Level.SEVERE, CLASSNAME, "validateHashAlgorithm");
			}
		}

	}

	private static String[] getSupportedHashingAlgorithms() {
		return new String[]{"SHA-1", "PBKDF2WithHmacSHA1"};
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = DatabaseRepositoryConfigHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}