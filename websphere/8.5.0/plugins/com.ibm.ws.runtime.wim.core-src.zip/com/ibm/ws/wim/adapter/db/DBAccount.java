package com.ibm.ws.wim.adapter.db;

public class DBAccount {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private long entityId;
	private byte[] password;
	private String salt;
	private String externalId;
	private String repositoryId;

	public long getEntityId() {
		return this.entityId;
	}

	public void setEntityId(long var1) {
		this.entityId = var1;
	}

	public String getExternalId() {
		return this.externalId;
	}

	public void setExternalId(String var1) {
		this.externalId = var1;
	}

	public byte[] getPassword() {
		return this.password;
	}

	public void setPassword(byte[] var1) {
		this.password = var1;
	}

	public String getRepositoryId() {
		return this.repositoryId;
	}

	public void setRepositoryId(String var1) {
		this.repositoryId = var1;
	}

	public String getSalt() {
		return this.salt;
	}

	public void setSalt(String var1) {
		this.salt = var1;
	}
}