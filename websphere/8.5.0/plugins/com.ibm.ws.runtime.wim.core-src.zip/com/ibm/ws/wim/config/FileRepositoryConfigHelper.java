package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import commonj.sdo.DataObject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EcoreUtil;

public class FileRepositoryConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public String createIdMgrFileRepository(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "createIdMgrFileRepository", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("messageDigestAlgorithm");
		Integer var7 = (Integer) var2.get("saltLength");
		ValidationHelper.validateIntegerInput("saltLength", CLASSNAME, "createIdMgrFileRepository", var7);
		ConfigValidator.validateRepositoryParams(var5, "FileRepositoryType", var2);
		ConfigurationProviderType var8 = ConfigUtils.getConfigProvider(var1);
		if (!var5.equals("InternalFileRepository")) {
			ConfigUtils.checkForValidRepositoryById(var1, var5);
		} else {
			RepositoryType var9 = ConfigUtils.getRepositoryById(var1, var5, false);
			if (var9 != null) {
				throw new WIMConfigurationException("REPOSITORY_ID_ALREADY_EXISTS",
						WIMMessageHelper.generateMsgParms(var5), Level.SEVERE, CLASSNAME, "createIdMgrFileRepository");
			}
		}

		EClass var12 = ConfigManager.singleton().getConfigEClass("FileRepositoryType");
		DataObject var10 = (DataObject) EcoreUtil.create(var12);
		var10.setString("id", var5);
		var8.getRepositories().add(var10);
		FileRepositoryType var11 = (FileRepositoryType) ConfigUtils.getRepositoryById(var8, var5);
		ConfigUtils.setCommonRepositoryProperties(var11, var2, this.getDefaultValue(), false);
		if (var2.get("baseDirectory") != null && ((String) var2.get("baseDirectory")).trim().length() > 0) {
			var11.setBaseDirectory((String) var2.get("baseDirectory"));
		}

		if (var2.get("fileName") != null) {
			var11.setFileName((String) var2.get("fileName"));
		}

		if (var7 != null) {
			var11.setSaltLength(var7);
		}

		if (var6 != null) {
			var11.setMessageDigestAlgorithm(var6);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "createIdMgrFileRepository");
		}

		ConfigUtils.saveConfig(var1);
		return "MUST_ADD_BASE_ENTRY_TO_REPOSITORY";
	}

	public String updateIdMgrFileRepository(String var1, Map var2) throws Exception {
		String var4 = (String) var2.get("id");
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "updateIdMgrFileRepository", "params=" + var2);
		}

		FileRepositoryType var6 = (FileRepositoryType) ConfigUtils.validateAndGetRepository(var1, var4,
				"FileRepositoryType");
		String var7 = (String) var2.get("messageDigestAlgorithm");
		ConfigValidator.validateFileParams(var4, var2);
		Integer var8 = (Integer) var2.get("saltLength");
		ValidationHelper.validateIntegerInput("saltLength", CLASSNAME, "updateIdMgrFileRepository", var8);
		String var9 = (String) var2.get("baseDirectory");
		if (var9 != null && var9.trim().length() > 0) {
			var6.setBaseDirectory(var9.trim());
		} else if (var9 != null && var9.trim().length() == 0) {
			var6.setBaseDirectory((String) null);
		}

		if (var2.get("fileName") != null) {
			var6.setFileName((String) var2.get("fileName"));
		}

		if (var8 != null) {
			var6.setSaltLength(var8);
		}

		if (var7 != null) {
			var6.setMessageDigestAlgorithm(var7);
		}

		if (var5) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrFileRepository");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List listIdMgrSupportedMessageDigestAlgorithms(String var1) throws WIMException {
		return ConfigUtils.convertArrayToList(CONFIG_SUPPORTED_MDALGORITHMS);
	}

	private Map getDefaultValue() {
		HashMap var1 = null;
		var1 = new HashMap();
		var1.put("adapterClassName", "com.ibm.ws.wim.adapter.file.was.FileAdapter");
		var1.put("supportPaging", Boolean.valueOf("false"));
		var1.put("supportSorting", Boolean.valueOf("false"));
		var1.put("supportTransactions", Boolean.valueOf("false"));
		var1.put("isExtIdUnique", Boolean.valueOf("true"));
		var1.put("supportExternalName", Boolean.valueOf("false"));
		var1.put("supportExternalName", Boolean.valueOf("false"));
		return var1;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = FileRepositoryConfigHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}