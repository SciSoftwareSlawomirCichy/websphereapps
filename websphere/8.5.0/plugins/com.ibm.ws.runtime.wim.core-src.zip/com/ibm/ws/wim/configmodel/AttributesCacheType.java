package com.ibm.ws.wim.configmodel;

public interface AttributesCacheType {
	int getAttributeSizeLimit();

	void setAttributeSizeLimit(int var1);

	void unsetAttributeSizeLimit();

	boolean isSetAttributeSizeLimit();

	int getCacheSize();

	void setCacheSize(int var1);

	void unsetCacheSize();

	boolean isSetCacheSize();

	int getCacheTimeOut();

	void setCacheTimeOut(int var1);

	void unsetCacheTimeOut();

	boolean isSetCacheTimeOut();

	boolean isEnabled();

	void setEnabled(boolean var1);

	void unsetEnabled();

	boolean isSetEnabled();

	String getServerTTLAttribute();

	void setServerTTLAttribute(String var1);

	String getCacheDistPolicy();

	void setCacheDistPolicy(String var1);

	void unsetCacheDistPolicy();

	boolean isSetCacheDistPolicy();
}