package com.ibm.bsf;

public class BSFException extends Exception {
	public static int REASON_INVALID_ARGUMENT = 0;
	public static int REASON_IO_ERROR = 10;
	public static int REASON_UNKNOWN_LANGUAGE = 20;
	public static int REASON_EXECUTION_ERROR = 100;
	public static int REASON_UNSUPPORTED_FEATURE = 499;
	public static int REASON_OTHER_ERROR = 500;
	int reason;
	Throwable targetThrowable;

	public BSFException(int var1, String var2) {
		super(var2);
		this.reason = var1;
	}

	public BSFException(int var1, String var2, Throwable var3) {
		this(var1, var2);
		this.targetThrowable = var3;
	}

	public BSFException(String var1) {
		this(REASON_OTHER_ERROR, var1);
	}

	public int getReason() {
		return this.reason;
	}

	public Throwable getTargetException() {
		return this.targetThrowable;
	}

	public void printStackTrace() {
		if (this.targetThrowable != null) {
			String var1 = this.getMessage();
			if (var1 != null && !var1.equals(this.targetThrowable.getMessage())) {
				System.err.print(var1 + ": ");
			}

			this.targetThrowable.printStackTrace();
		} else {
			super.printStackTrace();
		}

	}
}