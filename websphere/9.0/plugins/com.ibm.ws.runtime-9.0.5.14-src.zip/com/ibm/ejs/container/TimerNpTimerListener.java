package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import commonj.timers.Timer;
import commonj.timers.TimerListener;
import commonj.timers.TimerManager;
import java.util.Date;

public class TimerNpTimerListener extends TimerNpRunnable implements TimerListener {
	private static final String CLASS_NAME = TimerNpTimerListener.class.getName();
	private static TraceComponent tc;
	public static TimerManager svTimerManager;
	private volatile Timer ivTask = null;

	public TimerNpTimerListener(TimerNpImpl timerNpImpl, int retryLimit, int retryInterval) {
		super(timerNpImpl, retryLimit, (long) retryInterval);
	}

	protected void schedule(long expiration) {
		this.ivTask = svTimerManager.schedule(this, new Date(expiration));
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "schedule : created " + this.ivTask);
		}

	}

	protected void scheduleNext(long nextExpiration) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "scheduleNext : " + nextExpiration);
		}

		this.ivTask = svTimerManager.schedule(this, new Date(nextExpiration));
	}

	protected void scheduleRetry(long retryInterval) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "scheduleRetry : " + retryInterval);
		}

		this.ivTask = svTimerManager.schedule(this, retryInterval);
	}

	protected void cancel() {
		Timer task = this.ivTask;
		if (task != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "cancel : " + task);
			}

			this.ivTask = null;
			task.cancel();
		}

	}

	public void timerExpired(Timer timer) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "timerExpired : " + timer);
		}

		this.run();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "timerExpired");
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		svTimerManager = null;
	}
}