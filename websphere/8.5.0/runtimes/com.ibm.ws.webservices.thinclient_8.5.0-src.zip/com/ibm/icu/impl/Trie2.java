package com.ibm.icu.impl;

import com.ibm.icu.impl.Trie2.1;
import com.ibm.icu.impl.Trie2.2;
import com.ibm.icu.impl.Trie2.CharSequenceIterator;
import com.ibm.icu.impl.Trie2.Range;
import com.ibm.icu.impl.Trie2.Trie2Iterator;
import com.ibm.icu.impl.Trie2.UTrie2Header;
import com.ibm.icu.impl.Trie2.ValueMapper;
import com.ibm.icu.impl.Trie2.ValueWidth;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

public abstract class Trie2 implements Iterable<Range> {
	private static ValueMapper defaultValueMapper = new 1();
	UTrie2Header header;
	char[] index;
	int data16;
	int[] data32;
	int indexLength;
	int dataLength;
	int index2NullOffset;
	int initialValue;
	int errorValue;
	int highStart;
	int highValueIndex;
	int dataNullOffset;
	int fHash;
	static final int UTRIE2_OPTIONS_VALUE_BITS_MASK = 15;
	static final int UTRIE2_SHIFT_1 = 11;
	static final int UTRIE2_SHIFT_2 = 5;
	static final int UTRIE2_SHIFT_1_2 = 6;
	static final int UTRIE2_OMITTED_BMP_INDEX_1_LENGTH = 32;
	static final int UTRIE2_CP_PER_INDEX_1_ENTRY = 2048;
	static final int UTRIE2_INDEX_2_BLOCK_LENGTH = 64;
	static final int UTRIE2_INDEX_2_MASK = 63;
	static final int UTRIE2_DATA_BLOCK_LENGTH = 32;
	static final int UTRIE2_DATA_MASK = 31;
	static final int UTRIE2_INDEX_SHIFT = 2;
	static final int UTRIE2_DATA_GRANULARITY = 4;
	static final int UTRIE2_INDEX_2_OFFSET = 0;
	static final int UTRIE2_LSCP_INDEX_2_OFFSET = 2048;
	static final int UTRIE2_LSCP_INDEX_2_LENGTH = 32;
	static final int UTRIE2_INDEX_2_BMP_LENGTH = 2080;
	static final int UTRIE2_UTF8_2B_INDEX_2_OFFSET = 2080;
	static final int UTRIE2_UTF8_2B_INDEX_2_LENGTH = 32;
	static final int UTRIE2_INDEX_1_OFFSET = 2112;
	static final int UTRIE2_MAX_INDEX_1_LENGTH = 512;
	static final int UTRIE2_BAD_UTF8_DATA_OFFSET = 128;
	static final int UTRIE2_DATA_START_OFFSET = 192;
	static final int UNEWTRIE2_INDEX_GAP_OFFSET = 2080;
	static final int UNEWTRIE2_INDEX_GAP_LENGTH = 576;
	static final int UNEWTRIE2_MAX_INDEX_2_LENGTH = 35488;
	static final int UNEWTRIE2_INDEX_1_LENGTH = 544;
	static final int UNEWTRIE2_MAX_DATA_LENGTH = 1115264;

	public static Trie2 createFromSerialized(InputStream is) throws IOException {
      DataInputStream dis = new DataInputStream(is);
      boolean needByteSwap = false;
      UTrie2Header header = new UTrie2Header();
      header.signature = dis.readInt();
      switch(header.signature) {
      case 845771348:
         needByteSwap = true;
         header.signature = Integer.reverseBytes(header.signature);
         break;
      case 1416784178:
         needByteSwap = false;
         break;
      default:
         throw new IllegalArgumentException("Stream does not contain a serialized UTrie2");
      }

      header.options = swapShort(needByteSwap, dis.readUnsignedShort());
      header.indexLength = swapShort(needByteSwap, dis.readUnsignedShort());
      header.shiftedDataLength = swapShort(needByteSwap, dis.readUnsignedShort());
      header.index2NullOffset = swapShort(needByteSwap, dis.readUnsignedShort());
      header.dataNullOffset = swapShort(needByteSwap, dis.readUnsignedShort());
      header.shiftedHighStart = swapShort(needByteSwap, dis.readUnsignedShort());
      if ((header.options & 15) > 1) {
         throw new IllegalArgumentException("UTrie2 serialized format error.");
      } else {
         ValueWidth width;
         Object This;
         if ((header.options & 15) == 0) {
            width = ValueWidth.BITS_16;
            This = new Trie2_16();
         } else {
            width = ValueWidth.BITS_32;
            This = new Trie2_32();
         }

         ((Trie2)This).header = header;
         ((Trie2)This).indexLength = header.indexLength;
         ((Trie2)This).dataLength = header.shiftedDataLength << 2;
         ((Trie2)This).index2NullOffset = header.index2NullOffset;
         ((Trie2)This).dataNullOffset = header.dataNullOffset;
         ((Trie2)This).highStart = header.shiftedHighStart << 11;
         ((Trie2)This).highValueIndex = ((Trie2)This).dataLength - 4;
         if (width == ValueWidth.BITS_16) {
            ((Trie2)This).highValueIndex += ((Trie2)This).indexLength;
         }

         int indexArraySize = ((Trie2)This).indexLength;
         if (width == ValueWidth.BITS_16) {
            indexArraySize += ((Trie2)This).dataLength;
         }

         ((Trie2)This).index = new char[indexArraySize];

         int i;
         for(i = 0; i < ((Trie2)This).indexLength; ++i) {
            ((Trie2)This).index[i] = swapChar(needByteSwap, dis.readChar());
         }

         if (width == ValueWidth.BITS_16) {
            ((Trie2)This).data16 = ((Trie2)This).indexLength;

            for(i = 0; i < ((Trie2)This).dataLength; ++i) {
               ((Trie2)This).index[((Trie2)This).data16 + i] = swapChar(needByteSwap, dis.readChar());
            }
         } else {
            ((Trie2)This).data32 = new int[((Trie2)This).dataLength];

            for(i = 0; i < ((Trie2)This).dataLength; ++i) {
               ((Trie2)This).data32[i] = swapInt(needByteSwap, dis.readInt());
            }
         }

         switch(2.$SwitchMap$com$ibm$icu$impl$Trie2$ValueWidth[width.ordinal()]) {
         case 1:
            ((Trie2)This).data32 = null;
            ((Trie2)This).initialValue = ((Trie2)This).index[((Trie2)This).dataNullOffset];
            ((Trie2)This).errorValue = ((Trie2)This).index[((Trie2)This).data16 + 128];
            break;
         case 2:
            ((Trie2)This).data16 = 0;
            ((Trie2)This).initialValue = ((Trie2)This).data32[((Trie2)This).dataNullOffset];
            ((Trie2)This).errorValue = ((Trie2)This).data32[128];
            break;
         default:
            throw new IllegalArgumentException("UTrie2 serialized format error.");
         }

         return (Trie2)This;
      }
   }

	private static int swapShort(boolean needSwap, int value) {
		return needSwap ? Short.reverseBytes((short) value) & '￿' : value;
	}

	private static char swapChar(boolean needSwap, char value) {
		return needSwap ? (char) Short.reverseBytes((short) value) : value;
	}

	private static int swapInt(boolean needSwap, int value) {
		return needSwap ? Integer.reverseBytes(value) : value;
	}

	public static int getVersion(InputStream is, boolean littleEndianOk) throws IOException {
		if (!is.markSupported()) {
			throw new IllegalArgumentException("Input stream must support mark().");
		} else {
			is.mark(4);
			byte[] sig = new byte[4];
			is.read(sig);
			is.reset();
			if (sig[0] == 84 && sig[1] == 114 && sig[2] == 105 && sig[3] == 101) {
				return 1;
			} else if (sig[0] == 84 && sig[1] == 114 && sig[2] == 105 && sig[3] == 50) {
				return 2;
			} else {
				if (littleEndianOk) {
					if (sig[0] == 101 && sig[1] == 105 && sig[2] == 114 && sig[3] == 84) {
						return 1;
					}

					if (sig[0] == 50 && sig[1] == 105 && sig[2] == 114 && sig[3] == 84) {
						return 2;
					}
				}

				return 0;
			}
		}
	}

	public abstract int get(int var1);

	public abstract int getFromU16SingleLead(char var1);

	public final boolean equals(Object other) {
		if (!(other instanceof Trie2)) {
			return false;
		} else {
			Trie2 OtherTrie = (Trie2) other;
			Iterator<Range> otherIter = OtherTrie.iterator();
			Iterator i$ = this.iterator();

			Range rangeFromOther;
			Range rangeFromThis;
			do {
				if (!i$.hasNext()) {
					if (otherIter.hasNext()) {
						return false;
					}

					if (this.errorValue == OtherTrie.errorValue && this.initialValue == OtherTrie.initialValue) {
						return true;
					}

					return false;
				}

				rangeFromThis = (Range) i$.next();
				if (!otherIter.hasNext()) {
					return false;
				}

				rangeFromOther = (Range) otherIter.next();
			} while (rangeFromThis.equals(rangeFromOther));

			return false;
		}
	}

	public int hashCode() {
		if (this.fHash == 0) {
			int hash = initHash();

			Range r;
			for (Iterator i$ = this.iterator(); i$.hasNext(); hash = hashInt(hash, r.hashCode())) {
				r = (Range) i$.next();
			}

			if (hash == 0) {
				hash = 1;
			}

			this.fHash = hash;
		}

		return this.fHash;
	}

	public Iterator<Range> iterator() {
		return this.iterator(defaultValueMapper);
	}

	public Iterator<Range> iterator(ValueMapper mapper) {
		return new Trie2Iterator(this, mapper);
	}

	public Iterator<Range> iteratorForLeadSurrogate(char lead, ValueMapper mapper) {
		return new Trie2Iterator(this, lead, mapper);
	}

	public Iterator<Range> iteratorForLeadSurrogate(char lead) {
		return new Trie2Iterator(this, lead, defaultValueMapper);
	}

	protected int serializeHeader(DataOutputStream dos) throws IOException {
		int bytesWritten = 0;
		dos.writeInt(this.header.signature);
		dos.writeShort(this.header.options);
		dos.writeShort(this.header.indexLength);
		dos.writeShort(this.header.shiftedDataLength);
		dos.writeShort(this.header.index2NullOffset);
		dos.writeShort(this.header.dataNullOffset);
		dos.writeShort(this.header.shiftedHighStart);
		int bytesWritten = bytesWritten + 16;

		for (int i = 0; i < this.header.indexLength; ++i) {
			dos.writeChar(this.index[i]);
		}

		bytesWritten += this.header.indexLength;
		return bytesWritten;
	}

	public CharSequenceIterator charSequenceIterator(CharSequence text, int index) {
		return new CharSequenceIterator(this, text, index);
	}

	int rangeEnd(int start, int limitp, int val) {
		int limit = Math.min(this.highStart, limitp);

		int c;
		for (c = start + 1; c < limit && this.get(c) == val; ++c) {
			;
		}

		if (c >= this.highStart) {
			c = limitp;
		}

		return c - 1;
	}

	private static int initHash() {
		return -2128831035;
	}

	private static int hashByte(int h, int b) {
		h *= 16777619;
		h ^= b;
		return h;
	}

	private static int hashUChar32(int h, int c) {
		h = hashByte(h, c & 255);
		h = hashByte(h, c >> 8 & 255);
		h = hashByte(h, c >> 16);
		return h;
	}

	private static int hashInt(int h, int i) {
		h = hashByte(h, i & 255);
		h = hashByte(h, i >> 8 & 255);
		h = hashByte(h, i >> 16 & 255);
		h = hashByte(h, i >> 24 & 255);
		return h;
	}
}