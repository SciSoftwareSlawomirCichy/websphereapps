package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.concurrent.LazyInit;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedMap;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
public abstract class ImmutableMap<K, V> implements Map<K, V>, Serializable {
	static final Map.Entry<?, ?>[] EMPTY_ENTRY_ARRAY = new Map.Entry[0];
	@LazyInit
	private transient ImmutableSet<Map.Entry<K, V>> entrySet;
	@LazyInit
	private transient ImmutableSet<K> keySet;
	@LazyInit
	private transient ImmutableCollection<V> values;
	@LazyInit
	private transient ImmutableSetMultimap<K, V> multimapView;

	public static <K, V> ImmutableMap<K, V> of() {
		return RegularImmutableMap.EMPTY;
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		return RegularImmutableMap.create(1, new Object[]{k1, v1});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		return RegularImmutableMap.create(2, new Object[]{k1, v1, k2, v2});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		CollectPreconditions.checkEntryNotNull(k3, v3);
		return RegularImmutableMap.create(3, new Object[]{k1, v1, k2, v2, k3, v3});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		CollectPreconditions.checkEntryNotNull(k3, v3);
		CollectPreconditions.checkEntryNotNull(k4, v4);
		return RegularImmutableMap.create(4, new Object[]{k1, v1, k2, v2, k3, v3, k4, v4});
	}

	public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		CollectPreconditions.checkEntryNotNull(k3, v3);
		CollectPreconditions.checkEntryNotNull(k4, v4);
		CollectPreconditions.checkEntryNotNull(k5, v5);
		return RegularImmutableMap.create(5, new Object[]{k1, v1, k2, v2, k3, v3, k4, v4, k5, v5});
	}

	static <K, V> Map.Entry<K, V> entryOf(K key, V value) {
		CollectPreconditions.checkEntryNotNull(key, value);
		return new AbstractMap.SimpleImmutableEntry(key, value);
	}

	public static <K, V> Builder<K, V> builder() {
		return new Builder();
	}

	@Beta
	public static <K, V> Builder<K, V> builderWithExpectedSize(int expectedSize) {
		CollectPreconditions.checkNonnegative(expectedSize, "expectedSize");
		return new Builder(expectedSize);
	}

	static void checkNoConflict(boolean safe, String conflictDescription, Map.Entry<?, ?> entry1,
			Map.Entry<?, ?> entry2) {
		if (!safe) {
			throw conflictException(conflictDescription, entry1, entry2);
		}
	}

	static IllegalArgumentException conflictException(String conflictDescription, Object entry1, Object entry2) {
		return new IllegalArgumentException(
				"Multiple entries with same " + conflictDescription + ": " + entry1 + " and " + entry2);
	}

	public static <K, V> ImmutableMap<K, V> copyOf(Map<? extends K, ? extends V> map) {
		if (map instanceof ImmutableMap && !(map instanceof SortedMap)) {
			ImmutableMap<K, V> kvMap = (ImmutableMap) map;
			if (!kvMap.isPartialView()) {
				return kvMap;
			}
		}

		return copyOf((Iterable) map.entrySet());
	}

	@Beta
	public static <K, V> ImmutableMap<K, V> copyOf(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries) {
		int initialCapacity = entries instanceof Collection ? ((Collection) entries).size() : 4;
		Builder<K, V> builder = new Builder(initialCapacity);
		builder.putAll(entries);
		return builder.build();
	}

	ImmutableMap() {
	}

	/** @deprecated */
	@Deprecated
	@CanIgnoreReturnValue
	public final V put(K k, V v) {
		throw new UnsupportedOperationException();
	}

	/** @deprecated */
	@Deprecated
	@CanIgnoreReturnValue
	public final V remove(Object o) {
		throw new UnsupportedOperationException();
	}

	/** @deprecated */
	@Deprecated
	public final void putAll(Map<? extends K, ? extends V> map) {
		throw new UnsupportedOperationException();
	}

	/** @deprecated */
	@Deprecated
	public final void clear() {
		throw new UnsupportedOperationException();
	}

	public boolean isEmpty() {
		return this.size() == 0;
	}

	public boolean containsKey(@NullableDecl Object key) {
		return this.get(key) != null;
	}

	public boolean containsValue(@NullableDecl Object value) {
		return this.values().contains(value);
	}

	public abstract V get(@NullableDecl Object var1);

	public final V getOrDefault(@NullableDecl Object key, @NullableDecl V defaultValue) {
		V result = this.get(key);
		return result != null ? result : defaultValue;
	}

	public ImmutableSet<Map.Entry<K, V>> entrySet() {
		ImmutableSet<Map.Entry<K, V>> result = this.entrySet;
		return result == null ? (this.entrySet = this.createEntrySet()) : result;
	}

	abstract ImmutableSet<Map.Entry<K, V>> createEntrySet();

	public ImmutableSet<K> keySet() {
		ImmutableSet<K> result = this.keySet;
		return result == null ? (this.keySet = this.createKeySet()) : result;
	}

	abstract ImmutableSet<K> createKeySet();

	UnmodifiableIterator<K> keyIterator() {
		final UnmodifiableIterator<Map.Entry<K, V>> entryIterator = this.entrySet().iterator();
		return new UnmodifiableIterator<K>() {
			public boolean hasNext() {
				return entryIterator.hasNext();
			}

			public K next() {
				return ((Map.Entry) entryIterator.next()).getKey();
			}
		};
	}

	public ImmutableCollection<V> values() {
		ImmutableCollection<V> result = this.values;
		return result == null ? (this.values = this.createValues()) : result;
	}

	abstract ImmutableCollection<V> createValues();

	public ImmutableSetMultimap<K, V> asMultimap() {
		if (this.isEmpty()) {
			return ImmutableSetMultimap.of();
		} else {
			ImmutableSetMultimap<K, V> result = this.multimapView;
			return result == null
					? (this.multimapView = new ImmutableSetMultimap(new MapViewOfValuesAsSingletonSets(), this.size(),
							(Comparator) null))
					: result;
		}
	}

	public boolean equals(@NullableDecl Object object) {
		return Maps.equalsImpl(this, object);
	}

	abstract boolean isPartialView();

	public int hashCode() {
		return Sets.hashCodeImpl(this.entrySet());
	}

	boolean isHashCodeFast() {
		return false;
	}

	public String toString() {
		return Maps.toStringImpl(this);
	}

	Object writeReplace() {
		return new SerializedForm(this);
	}

	static class SerializedForm implements Serializable {
		private final Object[] keys;
		private final Object[] values;
		private static final long serialVersionUID = 0L;

		SerializedForm(ImmutableMap<?, ?> map) {
			this.keys = new Object[map.size()];
			this.values = new Object[map.size()];
			int i = 0;

			for (UnmodifiableIterator var3 = map.entrySet().iterator(); var3.hasNext(); ++i) {
				Map.Entry<?, ?> entry = (Map.Entry) var3.next();
				this.keys[i] = entry.getKey();
				this.values[i] = entry.getValue();
			}

		}

		Object readResolve() {
			Builder<Object, Object> builder = new Builder(this.keys.length);
			return this.createMap(builder);
		}

		Object createMap(Builder<Object, Object> builder) {
			for (int i = 0; i < this.keys.length; ++i) {
				builder.put(this.keys[i], this.values[i]);
			}

			return builder.build();
		}
	}

	private final class MapViewOfValuesAsSingletonSets extends IteratorBasedImmutableMap<K, ImmutableSet<V>> {
		private MapViewOfValuesAsSingletonSets() {
		}

		public int size() {
			return ImmutableMap.this.size();
		}

		ImmutableSet<K> createKeySet() {
			return ImmutableMap.this.keySet();
		}

		public boolean containsKey(@NullableDecl Object key) {
			return ImmutableMap.this.containsKey(key);
		}

		public ImmutableSet<V> get(@NullableDecl Object key) {
			V outerValue = ImmutableMap.this.get(key);
			return outerValue == null ? null : ImmutableSet.of(outerValue);
		}

		boolean isPartialView() {
			return ImmutableMap.this.isPartialView();
		}

		public int hashCode() {
			return ImmutableMap.this.hashCode();
		}

		boolean isHashCodeFast() {
			return ImmutableMap.this.isHashCodeFast();
		}

		UnmodifiableIterator<Map.Entry<K, ImmutableSet<V>>> entryIterator() {
			final Iterator<Map.Entry<K, V>> backingIterator = ImmutableMap.this.entrySet().iterator();
			return new UnmodifiableIterator<Map.Entry<K, ImmutableSet<V>>>() {
				public boolean hasNext() {
					return backingIterator.hasNext();
				}

				public Map.Entry<K, ImmutableSet<V>> next() {
					final Map.Entry<K, V> backingEntry = (Map.Entry) backingIterator.next();
					return new AbstractMapEntry<K, ImmutableSet<V>>() {
						public K getKey() {
							return backingEntry.getKey();
						}

						public ImmutableSet<V> getValue() {
							return ImmutableSet.of(backingEntry.getValue());
						}
					};
				}
			};
		}
	}

	abstract static class IteratorBasedImmutableMap<K, V> extends ImmutableMap<K, V> {
		abstract UnmodifiableIterator<Map.Entry<K, V>> entryIterator();

		ImmutableSet<K> createKeySet() {
			return new ImmutableMapKeySet(this);
		}

		ImmutableSet<Map.Entry<K, V>> createEntrySet() {
			class EntrySetImpl extends ImmutableMapEntrySet<K, V> {
				ImmutableMap<K, V> map() {
					return IteratorBasedImmutableMap.this;
				}

				public UnmodifiableIterator<Map.Entry<K, V>> iterator() {
					return IteratorBasedImmutableMap.this.entryIterator();
				}
			}

			return new EntrySetImpl();
		}

		ImmutableCollection<V> createValues() {
			return new ImmutableMapValues(this);
		}
	}

	public static class Builder<K, V> {
		@MonotonicNonNullDecl
		Comparator<? super V> valueComparator;
		Object[] alternatingKeysAndValues;
		int size;
		boolean entriesUsed;

		public Builder() {
			this(4);
		}

		Builder(int initialCapacity) {
			this.alternatingKeysAndValues = new Object[2 * initialCapacity];
			this.size = 0;
			this.entriesUsed = false;
		}

		private void ensureCapacity(int minCapacity) {
			if (minCapacity * 2 > this.alternatingKeysAndValues.length) {
				this.alternatingKeysAndValues = Arrays.copyOf(this.alternatingKeysAndValues,
						com.google.common.collect.ImmutableCollection.Builder
								.expandedCapacity(this.alternatingKeysAndValues.length, minCapacity * 2));
				this.entriesUsed = false;
			}

		}

		@CanIgnoreReturnValue
		public Builder<K, V> put(K key, V value) {
			this.ensureCapacity(this.size + 1);
			CollectPreconditions.checkEntryNotNull(key, value);
			this.alternatingKeysAndValues[2 * this.size] = key;
			this.alternatingKeysAndValues[2 * this.size + 1] = value;
			++this.size;
			return this;
		}

		@CanIgnoreReturnValue
		public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry) {
			return this.put(entry.getKey(), entry.getValue());
		}

		@CanIgnoreReturnValue
		public Builder<K, V> putAll(Map<? extends K, ? extends V> map) {
			return this.putAll((Iterable) map.entrySet());
		}

		@CanIgnoreReturnValue
		@Beta
		public Builder<K, V> putAll(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries) {
			if (entries instanceof Collection) {
				this.ensureCapacity(this.size + ((Collection) entries).size());
			}

			Iterator var2 = entries.iterator();

			while (var2.hasNext()) {
				Map.Entry<? extends K, ? extends V> entry = (Map.Entry) var2.next();
				this.put(entry);
			}

			return this;
		}

		@CanIgnoreReturnValue
		@Beta
		public Builder<K, V> orderEntriesByValue(Comparator<? super V> valueComparator) {
			Preconditions.checkState(this.valueComparator == null, "valueComparator was already set");
			this.valueComparator = (Comparator) Preconditions.checkNotNull(valueComparator, "valueComparator");
			return this;
		}

		public ImmutableMap<K, V> build() {
			this.sortEntries();
			this.entriesUsed = true;
			return RegularImmutableMap.create(this.size, this.alternatingKeysAndValues);
		}

		void sortEntries() {
			if (this.valueComparator != null) {
				if (this.entriesUsed) {
					this.alternatingKeysAndValues = Arrays.copyOf(this.alternatingKeysAndValues, 2 * this.size);
				}

				Map.Entry<K, V>[] entries = new Map.Entry[this.size];

				int i;
				for (i = 0; i < this.size; ++i) {
					entries[i] = new AbstractMap.SimpleImmutableEntry(this.alternatingKeysAndValues[2 * i],
							this.alternatingKeysAndValues[2 * i + 1]);
				}

				Arrays.sort(entries, 0, this.size,
						Ordering.from(this.valueComparator).onResultOf(Maps.valueFunction()));

				for (i = 0; i < this.size; ++i) {
					this.alternatingKeysAndValues[2 * i] = entries[i].getKey();
					this.alternatingKeysAndValues[2 * i + 1] = entries[i].getValue();
				}
			}

		}
	}
}