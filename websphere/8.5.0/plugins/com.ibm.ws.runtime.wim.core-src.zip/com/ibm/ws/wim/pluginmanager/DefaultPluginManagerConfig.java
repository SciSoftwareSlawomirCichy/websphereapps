package com.ibm.ws.wim.pluginmanager;

import java.util.Vector;

public class DefaultPluginManagerConfig {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static Vector DEFAULT_EMITTER_LIST = null;

	public static Vector getDefaultVectorList() {
		return DEFAULT_EMITTER_LIST;
	}

	static {
		DEFAULT_EMITTER_LIST = new Vector();
		DEFAULT_EMITTER_LIST.add("com.ibm.ws.wim.ProfileManager.create");
		DEFAULT_EMITTER_LIST.add("com.ibm.ws.wim.ProfileManager.delete");
		DEFAULT_EMITTER_LIST.add("com.ibm.ws.wim.ProfileManager.login");
		DEFAULT_EMITTER_LIST.add("com.ibm.ws.wim.ProfileManager.search");
		DEFAULT_EMITTER_LIST.add("com.ibm.ws.wim.ProfileManager.update");
		DEFAULT_EMITTER_LIST.add("com.ibm.ws.wim.ProfileManager.get");
	}
}