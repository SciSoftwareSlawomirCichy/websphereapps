package com.ibm.ejs.util;

final class Bucket<K, V> {
	Element<K, V> ivHead;
	private int ivNumElements;

	Element<K, V> findByKey(K key) {
		for (Element e = this.ivHead; e != null; e = e.ivNext) {
			if (key.equals(e.ivKey)) {
				return e;
			}
		}

		return null;
	}

	Element<K, V> replaceByKey(K key, V object) {
		Element<K, V> element = this.removeByKey(key);
		this.addByKey(key, object);
		return element;
	}

	void addByKey(K key, V object) {
		Element<K, V> newElement = new Element(key, object);
		newElement.ivNext = this.ivHead;
		this.ivHead = newElement;
		++this.ivNumElements;
	}

	Element<K, V> removeByKey(K key) {
		Element<K, V> previous = null;

		for (Element e = this.ivHead; e != null; e = e.ivNext) {
			if (key.equals(e.ivKey)) {
				if (previous == null) {
					this.ivHead = e.ivNext;
				} else {
					previous.ivNext = e.ivNext;
				}

				--this.ivNumElements;
				return e;
			}

			previous = e;
		}

		return null;
	}

	public int size() {
		return this.ivNumElements;
	}

	void clear() {
		this.ivNumElements = 0;
		this.ivHead = null;
	}
}