package com.ibm.icu.text;

import com.ibm.icu.impl.Utility;
import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.MessageFormat.Field;
import com.ibm.icu.util.ULocale;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.text.AttributedCharacterIterator;
import java.text.AttributedString;
import java.text.CharacterIterator;
import java.text.ChoiceFormat;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.AttributedCharacterIterator.Attribute;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class MessageFormat extends UFormat {
	static final long serialVersionUID = 7136212545847378651L;
	private Locale locale;
	private ULocale ulocale;
	private String pattern;
	private static final int INITIAL_FORMATS = 10;
	private Format[] formats;
	private int[] offsets;
	private int[] argumentNumbers;
	private String[] argumentNames;
	private boolean argumentNamesAreNumeric;
	private int maxOffset;
	private static final String[] typeList = new String[]{"", "number", "date", "time", "choice", "spellout", "ordinal",
			"duration", "plural", "select"};
	private static final int TYPE_EMPTY = 0;
	private static final int TYPE_NUMBER = 1;
	private static final int TYPE_DATE = 2;
	private static final int TYPE_TIME = 3;
	private static final int TYPE_CHOICE = 4;
	private static final int TYPE_SPELLOUT = 5;
	private static final int TYPE_ORDINAL = 6;
	private static final int TYPE_DURATION = 7;
	private static final int TYPE_PLURAL = 8;
	private static final int TYPE_SELECT = 9;
	private static final String[] modifierList = new String[]{"", "currency", "percent", "integer"};
	private static final int MODIFIER_EMPTY = 0;
	private static final int MODIFIER_CURRENCY = 1;
	private static final int MODIFIER_PERCENT = 2;
	private static final int MODIFIER_INTEGER = 3;
	private static final String[] dateModifierList = new String[]{"", "short", "medium", "long", "full"};
	private static final int DATE_MODIFIER_EMPTY = 0;
	private static final int DATE_MODIFIER_SHORT = 1;
	private static final int DATE_MODIFIER_MEDIUM = 2;
	private static final int DATE_MODIFIER_LONG = 3;
	private static final int DATE_MODIFIER_FULL = 4;
	private static final char SINGLE_QUOTE = '\'';
	private static final char CURLY_BRACE_LEFT = '{';
	private static final char CURLY_BRACE_RIGHT = '}';
	private static final int STATE_INITIAL = 0;
	private static final int STATE_SINGLE_QUOTE = 1;
	private static final int STATE_IN_QUOTE = 2;
	private static final int STATE_MSG_ELEMENT = 3;

	public MessageFormat(String pattern) {
		this.pattern = "";
		this.formats = new Format[10];
		this.offsets = new int[10];
		this.argumentNumbers = new int[10];
		this.argumentNames = new String[10];
		this.argumentNamesAreNumeric = true;
		this.maxOffset = -1;
		this.ulocale = ULocale.getDefault();
		this.applyPattern(pattern);
	}

	public MessageFormat(String pattern, Locale locale) {
		this(pattern, ULocale.forLocale(locale));
	}

	public MessageFormat(String pattern, ULocale locale) {
		this.pattern = "";
		this.formats = new Format[10];
		this.offsets = new int[10];
		this.argumentNumbers = new int[10];
		this.argumentNames = new String[10];
		this.argumentNamesAreNumeric = true;
		this.maxOffset = -1;
		this.ulocale = locale;
		this.applyPattern(pattern);
	}

	public void setLocale(Locale locale) {
		this.setLocale(ULocale.forLocale(locale));
	}

	public void setLocale(ULocale locale) {
		String existingPattern = this.toPattern();
		this.ulocale = locale;
		this.applyPattern(existingPattern);
	}

	public Locale getLocale() {
		return this.ulocale.toLocale();
	}

	public ULocale getULocale() {
		return this.ulocale;
	}

	public void applyPattern(String pttrn) {
		StringBuilder[] segments = new StringBuilder[4];

		int part;
		for (part = 0; part < segments.length; ++part) {
			segments[part] = new StringBuilder();
		}

		part = 0;
		int formatNumber = 0;
		boolean inQuote = false;
		int braceStack = 0;
		this.maxOffset = -1;

		for (int i = 0; i < pttrn.length(); ++i) {
			char ch = pttrn.charAt(i);
			if (part == 0) {
				if (ch == '\'') {
					if (i + 1 < pttrn.length() && pttrn.charAt(i + 1) == '\'') {
						segments[part].append(ch);
						++i;
					} else {
						inQuote = !inQuote;
					}
				} else if (ch == '{' && !inQuote) {
					part = 1;
				} else {
					segments[part].append(ch);
				}
			} else if (inQuote) {
				segments[part].append(ch);
				if (ch == '\'') {
					inQuote = false;
				}
			} else {
				switch (ch) {
					case '\'' :
						inQuote = true;
					default :
						segments[part].append(ch);
						break;
					case ',' :
						if (part < 3) {
							++part;
						} else {
							segments[part].append(ch);
						}
						break;
					case '{' :
						++braceStack;
						segments[part].append(ch);
						break;
					case '}' :
						if (braceStack == 0) {
							part = 0;
							this.makeFormat(i, formatNumber, segments);
							++formatNumber;
						} else {
							--braceStack;
							segments[part].append(ch);
						}
				}
			}
		}

		if (braceStack == 0 && part != 0) {
			this.maxOffset = -1;
			throw new IllegalArgumentException("Unmatched braces in the pattern.");
		} else {
			this.pattern = segments[0].toString();
		}
	}

	public String toPattern() {
		int lastOffset = 0;
		StringBuilder result = new StringBuilder();

		for (int i = 0; i <= this.maxOffset; ++i) {
			copyAndFixQuotes(this.pattern, lastOffset, this.offsets[i], result);
			lastOffset = this.offsets[i];
			result.append('{');
			result.append(this.argumentNames[i]);
			if (this.formats[i] != null) {
				if (this.formats[i] instanceof DecimalFormat) {
					if (this.formats[i].equals(NumberFormat.getInstance(this.ulocale))) {
						result.append(",number");
					} else if (this.formats[i].equals(NumberFormat.getCurrencyInstance(this.ulocale))) {
						result.append(",number,currency");
					} else if (this.formats[i].equals(NumberFormat.getPercentInstance(this.ulocale))) {
						result.append(",number,percent");
					} else if (this.formats[i].equals(NumberFormat.getIntegerInstance(this.ulocale))) {
						result.append(",number,integer");
					} else {
						result.append(",number," + ((DecimalFormat) this.formats[i]).toPattern());
					}
				} else if (this.formats[i] instanceof SimpleDateFormat) {
					if (this.formats[i].equals(DateFormat.getDateInstance(2, this.ulocale))) {
						result.append(",date");
					} else if (this.formats[i].equals(DateFormat.getDateInstance(3, this.ulocale))) {
						result.append(",date,short");
					} else if (this.formats[i].equals(DateFormat.getDateInstance(1, this.ulocale))) {
						result.append(",date,long");
					} else if (this.formats[i].equals(DateFormat.getDateInstance(0, this.ulocale))) {
						result.append(",date,full");
					} else if (this.formats[i].equals(DateFormat.getTimeInstance(2, this.ulocale))) {
						result.append(",time");
					} else if (this.formats[i].equals(DateFormat.getTimeInstance(3, this.ulocale))) {
						result.append(",time,short");
					} else if (this.formats[i].equals(DateFormat.getTimeInstance(1, this.ulocale))) {
						result.append(",time,long");
					} else if (this.formats[i].equals(DateFormat.getTimeInstance(0, this.ulocale))) {
						result.append(",time,full");
					} else {
						result.append(",date," + ((SimpleDateFormat) this.formats[i]).toPattern());
					}
				} else if (this.formats[i] instanceof ChoiceFormat) {
					result.append(",choice," + ((ChoiceFormat) this.formats[i]).toPattern());
				} else {
					String pat;
					if (this.formats[i] instanceof PluralFormat) {
						pat = ((PluralFormat) this.formats[i]).toPattern();
						pat = this.duplicateSingleQuotes(pat);
						result.append(",plural," + pat);
					} else if (this.formats[i] instanceof SelectFormat) {
						pat = ((SelectFormat) this.formats[i]).toPattern();
						pat = this.duplicateSingleQuotes(pat);
						result.append(",select," + pat);
					}
				}
			}

			result.append('}');
		}

		copyAndFixQuotes(this.pattern, lastOffset, this.pattern.length(), result);
		return result.toString();
	}

	private String duplicateSingleQuotes(String pat) {
		String result = pat;
		if (pat.indexOf(39) != 0) {
			StringBuilder buf = new StringBuilder();

			for (int j = 0; j < pat.length(); ++j) {
				char ch = pat.charAt(j);
				if (ch == '\'') {
					buf.append(ch);
				}

				buf.append(ch);
			}

			result = buf.toString();
		}

		return result;
	}

	public void setFormatsByArgumentIndex(Format[] newFormats) {
		if (!this.argumentNamesAreNumeric) {
			throw new IllegalArgumentException(
					"This method is not available in MessageFormat objects that use alphanumeric argument names.");
		} else {
			for (int i = 0; i <= this.maxOffset; ++i) {
				int j = Integer.parseInt(this.argumentNames[i]);
				if (j < newFormats.length) {
					this.formats[i] = newFormats[j];
				}
			}

		}
	}

	public void setFormatsByArgumentName(Map<String, Format> newFormats) {
		for (int i = 0; i <= this.maxOffset; ++i) {
			if (newFormats.containsKey(this.argumentNames[i])) {
				Format f = (Format) newFormats.get(this.argumentNames[i]);
				this.formats[i] = f;
			}
		}

	}

	public void setFormats(Format[] newFormats) {
		int runsToCopy = newFormats.length;
		if (runsToCopy > this.maxOffset + 1) {
			runsToCopy = this.maxOffset + 1;
		}

		for (int i = 0; i < runsToCopy; ++i) {
			this.formats[i] = newFormats[i];
		}

	}

	public void setFormatByArgumentIndex(int argumentIndex, Format newFormat) {
		if (!this.argumentNamesAreNumeric) {
			throw new IllegalArgumentException(
					"This method is not available in MessageFormat objects that use alphanumeric argument names.");
		} else {
			for (int j = 0; j <= this.maxOffset; ++j) {
				if (Integer.parseInt(this.argumentNames[j]) == argumentIndex) {
					this.formats[j] = newFormat;
				}
			}

		}
	}

	public void setFormatByArgumentName(String argumentName, Format newFormat) {
		for (int i = 0; i <= this.maxOffset; ++i) {
			if (argumentName.equals(this.argumentNames[i])) {
				this.formats[i] = newFormat;
			}
		}

	}

	public void setFormat(int formatElementIndex, Format newFormat) {
		this.formats[formatElementIndex] = newFormat;
	}

	public Format[] getFormatsByArgumentIndex() {
		if (!this.argumentNamesAreNumeric) {
			throw new IllegalArgumentException(
					"This method is not available in MessageFormat objects that use alphanumeric argument names.");
		} else {
			int maximumArgumentNumber = -1;

			int i;
			for (int i = 0; i <= this.maxOffset; ++i) {
				i = Integer.parseInt(this.argumentNames[i]);
				if (i > maximumArgumentNumber) {
					maximumArgumentNumber = i;
				}
			}

			Format[] resultArray = new Format[maximumArgumentNumber + 1];

			for (i = 0; i <= this.maxOffset; ++i) {
				resultArray[Integer.parseInt(this.argumentNames[i])] = this.formats[i];
			}

			return resultArray;
		}
	}

	public Format[] getFormats() {
		Format[] resultArray = new Format[this.maxOffset + 1];
		System.arraycopy(this.formats, 0, resultArray, 0, this.maxOffset + 1);
		return resultArray;
	}

	public Set<String> getFormatArgumentNames() {
		Set<String> result = new HashSet();

		for (int i = 0; i <= this.maxOffset; ++i) {
			result.add(this.argumentNames[i]);
		}

		return result;
	}

	public Format getFormatByArgumentName(String argumentName) {
		for (int i = 0; i <= this.maxOffset; ++i) {
			if (argumentName.equals(this.argumentNames[i])) {
				return this.formats[i];
			}
		}

		return null;
	}

	public final StringBuffer format(Object[] arguments, StringBuffer result, FieldPosition pos) {
		if (!this.argumentNamesAreNumeric) {
			throw new IllegalArgumentException(
					"This method is not available in MessageFormat objects that use alphanumeric argument names.");
		} else {
			return this.subformat((Object[]) arguments, result, pos, (List) null);
		}
	}

	public final StringBuffer format(Map<String, Object> arguments, StringBuffer result, FieldPosition pos) {
		return this.subformat((Map) arguments, result, pos, (List) null);
	}

	public static String format(String pattern, Object[] arguments) {
		MessageFormat temp = new MessageFormat(pattern);
		return temp.format(arguments);
	}

	public static String format(String pattern, Map<String, Object> arguments) {
		MessageFormat temp = new MessageFormat(pattern);
		return temp.format(arguments);
	}

	public boolean usesNamedArguments() {
		return !this.argumentNamesAreNumeric;
	}

	public final StringBuffer format(Object arguments, StringBuffer result, FieldPosition pos) {
		if (arguments != null && !(arguments instanceof Map)) {
			if (!this.argumentNamesAreNumeric) {
				throw new IllegalArgumentException(
						"This method is not available in MessageFormat objects that use alphanumeric argument names.");
			} else {
				return this.subformat((Object[]) ((Object[]) ((Object[]) arguments)), result, pos, (List) null);
			}
		} else {
			return this.subformat((Map) ((Map) arguments), result, pos, (List) null);
		}
	}

	public AttributedCharacterIterator formatToCharacterIterator(Object arguments) {
		StringBuffer result = new StringBuffer();
		ArrayList<AttributedCharacterIterator> iterators = new ArrayList();
		if (arguments == null) {
			throw new NullPointerException("formatToCharacterIterator must be passed non-null object");
		} else {
			if (arguments instanceof Map) {
				this.subformat((Map) ((Map) arguments), result, (FieldPosition) null, iterators);
			} else {
				this.subformat((Object[]) ((Object[]) ((Object[]) arguments)), result, (FieldPosition) null, iterators);
			}

			return iterators.size() == 0
					? _createAttributedCharacterIterator("")
					: _createAttributedCharacterIterator((AttributedCharacterIterator[]) iterators
							.toArray(new AttributedCharacterIterator[iterators.size()]));
		}
	}

	public Object[] parse(String source, ParsePosition pos) {
		if (!this.argumentNamesAreNumeric) {
			throw new IllegalArgumentException(
					"This method is not available in MessageFormat objects that use named argument.");
		} else {
			Map<String, Object> objectMap = this.parseToMap(source, pos);
			int maximumArgumentNumber = -1;

			for (int i = 0; i <= this.maxOffset; ++i) {
				int argumentNumber = Integer.parseInt(this.argumentNames[i]);
				if (argumentNumber > maximumArgumentNumber) {
					maximumArgumentNumber = argumentNumber;
				}
			}

			if (objectMap == null) {
				return null;
			} else {
				Object[] resultArray = new Object[maximumArgumentNumber + 1];

				String key;
				for (Iterator i$ = objectMap.keySet().iterator(); i$
						.hasNext(); resultArray[Integer.parseInt(key)] = objectMap.get(key)) {
					key = (String) i$.next();
				}

				return resultArray;
			}
		}
	}

	public Map<String, Object> parseToMap(String source, ParsePosition pos) {
		HashMap resultMap;
		if (source == null) {
			resultMap = new HashMap();
			return resultMap;
		} else {
			resultMap = new HashMap();
			int patternOffset = 0;
			int sourceOffset = pos.getIndex();
			ParsePosition tempStatus = new ParsePosition(0);

			int i;
			for (i = 0; i <= this.maxOffset; ++i) {
				int len = this.offsets[i] - patternOffset;
				if (len != 0 && !this.pattern.regionMatches(patternOffset, source, sourceOffset, len)) {
					pos.setErrorIndex(sourceOffset);
					return null;
				}

				sourceOffset += len;
				patternOffset += len;
				if (this.formats[i] == null) {
					int tempLength = i != this.maxOffset ? this.offsets[i + 1] : this.pattern.length();
					int next;
					if (patternOffset >= tempLength) {
						next = source.length();
					} else {
						next = source.indexOf(this.pattern.substring(patternOffset, tempLength), sourceOffset);
					}

					if (next < 0) {
						pos.setErrorIndex(sourceOffset);
						return null;
					}

					String strValue = source.substring(sourceOffset, next);
					if (!strValue.equals("{" + this.argumentNames[i] + "}")) {
						resultMap.put(this.argumentNames[i], source.substring(sourceOffset, next));
					}

					sourceOffset = next;
				} else {
					tempStatus.setIndex(sourceOffset);
					resultMap.put(this.argumentNames[i], this.formats[i].parseObject(source, tempStatus));
					if (tempStatus.getIndex() == sourceOffset) {
						pos.setErrorIndex(sourceOffset);
						return null;
					}

					sourceOffset = tempStatus.getIndex();
				}
			}

			i = this.pattern.length() - patternOffset;
			if (i != 0 && !this.pattern.regionMatches(patternOffset, source, sourceOffset, i)) {
				pos.setErrorIndex(sourceOffset);
				return null;
			} else {
				pos.setIndex(sourceOffset + i);
				return resultMap;
			}
		}
	}

	public Object[] parse(String source) throws ParseException {
		ParsePosition pos = new ParsePosition(0);
		Object[] result = this.parse(source, pos);
		if (pos.getIndex() == 0) {
			throw new ParseException("MessageFormat parse error!", pos.getErrorIndex());
		} else {
			return result;
		}
	}

	public Map<String, Object> parseToMap(String source) throws ParseException {
		ParsePosition pos = new ParsePosition(0);
		Map<String, Object> result = this.parseToMap(source, pos);
		if (pos.getIndex() == 0) {
			throw new ParseException("MessageFormat parse error!", pos.getErrorIndex());
		} else {
			return result;
		}
	}

	public Object parseObject(String source, ParsePosition pos) {
		return this.argumentNamesAreNumeric ? this.parse(source, pos) : this.parseToMap(source, pos);
	}

	public Object clone() {
		MessageFormat other = (MessageFormat) super.clone();
		other.formats = (Format[]) this.formats.clone();

		for (int i = 0; i < this.formats.length; ++i) {
			if (this.formats[i] != null) {
				other.formats[i] = (Format) this.formats[i].clone();
			}
		}

		other.offsets = (int[]) this.offsets.clone();
		other.argumentNames = (String[]) this.argumentNames.clone();
		other.argumentNamesAreNumeric = this.argumentNamesAreNumeric;
		return other;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		} else if (obj != null && this.getClass() == obj.getClass()) {
			MessageFormat other = (MessageFormat) obj;
			return this.maxOffset == other.maxOffset && this.pattern.equals(other.pattern)
					&& Utility.objectEquals(this.ulocale, other.ulocale)
					&& Utility.arrayEquals(this.offsets, other.offsets)
					&& Utility.arrayEquals(this.argumentNames, other.argumentNames)
					&& Utility.arrayEquals(this.formats, other.formats)
					&& this.argumentNamesAreNumeric == other.argumentNamesAreNumeric;
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.pattern.hashCode();
	}

	private StringBuffer subformat(Object[] arguments, StringBuffer result, FieldPosition fp,
			List<AttributedCharacterIterator> characterIterators) {
		return this.subformat(this.arrayToMap(arguments), result, fp, characterIterators);
	}

	private StringBuffer subformat(Map<String, Object> arguments, StringBuffer result, FieldPosition fp,
			List<AttributedCharacterIterator> characterIterators) {
		int lastOffset = 0;
		int last = result.length();

		for (int i = 0; i <= this.maxOffset; ++i) {
			result.append(this.pattern.substring(lastOffset, this.offsets[i]));
			lastOffset = this.offsets[i];
			String argumentName = this.argumentNames[i];
			if (arguments != null && arguments.containsKey(argumentName)) {
				Object obj = arguments.get(argumentName);
				String arg = null;
				Format subFormatter = null;
				if (obj == null) {
					arg = "null";
				} else if (this.formats[i] != null) {
					subFormatter = this.formats[i];
					if (subFormatter instanceof ChoiceFormat || subFormatter instanceof PluralFormat
							|| subFormatter instanceof SelectFormat) {
						arg = this.formats[i].format(obj);
						if (arg.indexOf(123) >= 0) {
							subFormatter = new MessageFormat(arg, this.ulocale);
							obj = arguments;
							arg = null;
						}
					}
				} else if (obj instanceof Number) {
					subFormatter = NumberFormat.getInstance(this.ulocale);
				} else if (obj instanceof Date) {
					subFormatter = DateFormat.getDateTimeInstance(3, 3, this.ulocale);
				} else if (obj instanceof String) {
					arg = (String) obj;
				} else {
					arg = obj.toString();
					if (arg == null) {
						arg = "null";
					}
				}

				if (characterIterators != null) {
					if (last != result.length()) {
						characterIterators.add(_createAttributedCharacterIterator(result.substring(last)));
						last = result.length();
					}

					if (subFormatter != null) {
						AttributedCharacterIterator subIterator = ((Format) subFormatter)
								.formatToCharacterIterator(obj);
						this.append(result, subIterator);
						if (last != result.length()) {
							characterIterators.add(_createAttributedCharacterIterator(
									(AttributedCharacterIterator) subIterator, Field.ARGUMENT,
									this.argumentNamesAreNumeric ? new Integer(argumentName) : argumentName));
							last = result.length();
						}

						arg = null;
					}

					if (arg != null && arg.length() > 0) {
						result.append(arg);
						characterIterators.add(_createAttributedCharacterIterator((String) arg, Field.ARGUMENT,
								this.argumentNamesAreNumeric ? new Integer(argumentName) : argumentName));
						last = result.length();
					}
				} else {
					if (subFormatter != null) {
						arg = ((Format) subFormatter).format(obj);
					}

					last = result.length();
					result.append(arg);
					if (i == 0 && fp != null && Field.ARGUMENT.equals(fp.getFieldAttribute())) {
						fp.setBeginIndex(last);
						fp.setEndIndex(result.length());
					}

					last = result.length();
				}
			} else {
				result.append("{" + argumentName + "}");
			}
		}

		result.append(this.pattern.substring(lastOffset, this.pattern.length()));
		if (characterIterators != null && last != result.length()) {
			characterIterators.add(_createAttributedCharacterIterator(result.substring(last)));
		}

		return result;
	}

	private void append(StringBuffer result, CharacterIterator iterator) {
		if (iterator.first() != '￿') {
			result.append(iterator.first());

			char aChar;
			while ((aChar = iterator.next()) != '￿') {
				result.append(aChar);
			}
		}

	}

	private void makeFormat(int position, int offsetNumber, StringBuilder[] segments) {
		int oldMaxOffset;
		if (offsetNumber >= this.formats.length) {
			oldMaxOffset = this.formats.length * 2;
			Format[] newFormats = new Format[oldMaxOffset];
			int[] newOffsets = new int[oldMaxOffset];
			String[] newArgumentNames = new String[oldMaxOffset];
			System.arraycopy(this.formats, 0, newFormats, 0, this.maxOffset + 1);
			System.arraycopy(this.offsets, 0, newOffsets, 0, this.maxOffset + 1);
			System.arraycopy(this.argumentNames, 0, newArgumentNames, 0, this.maxOffset + 1);
			this.formats = newFormats;
			this.offsets = newOffsets;
			this.argumentNames = newArgumentNames;
		}

		oldMaxOffset = this.maxOffset;
		this.maxOffset = offsetNumber;
		this.offsets[offsetNumber] = segments[0].length();
		this.argumentNames[offsetNumber] = segments[1].toString();

		int argumentNumber;
		try {
			argumentNumber = Integer.parseInt(segments[1].toString());
		} catch (NumberFormatException var17) {
			argumentNumber = -1;
		}

		if (offsetNumber == 0) {
			this.argumentNamesAreNumeric = argumentNumber >= 0;
		}

		if ((!this.argumentNamesAreNumeric || argumentNumber >= 0)
				&& (this.argumentNamesAreNumeric || this.isAlphaIdentifier(this.argumentNames[offsetNumber]))) {
			Object newFormat;
			newFormat = null;
			int subformatType = findKeyword(segments[2].toString(), typeList);
			String quotedPattern;
			RuleBasedNumberFormat rbnf;
			label119 : switch (subformatType) {
				case 0 :
					break;
				case 1 :
					switch (findKeyword(segments[3].toString(), modifierList)) {
						case 0 :
							newFormat = NumberFormat.getInstance(this.ulocale);
							break label119;
						case 1 :
							newFormat = NumberFormat.getCurrencyInstance(this.ulocale);
							break label119;
						case 2 :
							newFormat = NumberFormat.getPercentInstance(this.ulocale);
							break label119;
						case 3 :
							newFormat = NumberFormat.getIntegerInstance(this.ulocale);
							break label119;
						default :
							newFormat = new DecimalFormat(segments[3].toString(),
									new DecimalFormatSymbols(this.ulocale));
							break label119;
					}
				case 2 :
					switch (findKeyword(segments[3].toString(), dateModifierList)) {
						case 0 :
							newFormat = DateFormat.getDateInstance(2, this.ulocale);
							break label119;
						case 1 :
							newFormat = DateFormat.getDateInstance(3, this.ulocale);
							break label119;
						case 2 :
							newFormat = DateFormat.getDateInstance(2, this.ulocale);
							break label119;
						case 3 :
							newFormat = DateFormat.getDateInstance(1, this.ulocale);
							break label119;
						case 4 :
							newFormat = DateFormat.getDateInstance(0, this.ulocale);
							break label119;
						default :
							newFormat = new SimpleDateFormat(segments[3].toString(), this.ulocale);
							break label119;
					}
				case 3 :
					switch (findKeyword(segments[3].toString(), dateModifierList)) {
						case 0 :
							newFormat = DateFormat.getTimeInstance(2, this.ulocale);
							break label119;
						case 1 :
							newFormat = DateFormat.getTimeInstance(3, this.ulocale);
							break label119;
						case 2 :
							newFormat = DateFormat.getTimeInstance(2, this.ulocale);
							break label119;
						case 3 :
							newFormat = DateFormat.getTimeInstance(1, this.ulocale);
							break label119;
						case 4 :
							newFormat = DateFormat.getTimeInstance(0, this.ulocale);
							break label119;
						default :
							newFormat = new SimpleDateFormat(segments[3].toString(), this.ulocale);
							break label119;
					}
				case 4 :
					try {
						newFormat = new ChoiceFormat(segments[3].toString());
						break;
					} catch (Exception var16) {
						this.maxOffset = oldMaxOffset;
						throw new IllegalArgumentException("Choice Pattern incorrect");
					}
				case 5 :
					rbnf = new RuleBasedNumberFormat(this.ulocale, 1);
					quotedPattern = segments[3].toString().trim();
					if (quotedPattern.length() != 0) {
						try {
							rbnf.setDefaultRuleSet(quotedPattern);
						} catch (Exception var15) {
							;
						}
					}

					newFormat = rbnf;
					break;
				case 6 :
					rbnf = new RuleBasedNumberFormat(this.ulocale, 2);
					quotedPattern = segments[3].toString().trim();
					if (quotedPattern.length() != 0) {
						try {
							rbnf.setDefaultRuleSet(quotedPattern);
						} catch (Exception var14) {
							;
						}
					}

					newFormat = rbnf;
					break;
				case 7 :
					rbnf = new RuleBasedNumberFormat(this.ulocale, 3);
					quotedPattern = segments[3].toString().trim();
					if (quotedPattern.length() != 0) {
						try {
							rbnf.setDefaultRuleSet(quotedPattern);
						} catch (Exception var13) {
							;
						}
					}

					newFormat = rbnf;
					break;
				case 8 :
				case 9 :
					StringBuilder unquotedPattern = new StringBuilder();
					quotedPattern = segments[3].toString();
					boolean inQuote = false;

					for (int i = 0; i < quotedPattern.length(); ++i) {
						char ch = quotedPattern.charAt(i);
						if (ch == '\'') {
							if (i + 1 < quotedPattern.length() && quotedPattern.charAt(i + 1) == '\'') {
								unquotedPattern.append(ch);
								++i;
							} else {
								inQuote = !inQuote;
							}
						} else {
							unquotedPattern.append(ch);
						}
					}

					if (subformatType == 8) {
						PluralFormat pls = new PluralFormat(this.ulocale, unquotedPattern.toString());
						newFormat = pls;
					} else {
						newFormat = new SelectFormat(unquotedPattern.toString());
					}
					break;
				default :
					this.maxOffset = oldMaxOffset;
					throw new IllegalArgumentException("unknown format type at ");
			}

			this.formats[offsetNumber] = (Format) newFormat;
			segments[1].setLength(0);
			segments[2].setLength(0);
			segments[3].setLength(0);
		} else {
			throw new IllegalArgumentException(
					"All argument identifiers have to be either non-negative numbers or strings following the pattern ([:ID_Start:] [:ID_Continue:]*).\nFor more details on these unicode sets, visit http://demo.icu-project.org/icu-bin/ubrowse");
		}
	}

	private static final int findKeyword(String s, String[] list) {
		s = s.trim().toLowerCase();

		for (int i = 0; i < list.length; ++i) {
			if (s.equals(list[i])) {
				return i;
			}
		}

		return -1;
	}

	private static final void copyAndFixQuotes(String source, int start, int end, StringBuilder target) {
		boolean gotLB = false;

		for (int i = start; i < end; ++i) {
			char ch = source.charAt(i);
			if (ch == '{') {
				target.append("'{'");
				gotLB = true;
			} else if (ch == '}') {
				if (gotLB) {
					target.append(ch);
					gotLB = false;
				} else {
					target.append("'}'");
				}
			} else if (ch == '\'') {
				target.append("''");
			} else {
				target.append(ch);
			}
		}

	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		if (this.argumentNames == null) {
			this.argumentNamesAreNumeric = true;
			this.argumentNames = new String[this.argumentNumbers.length];

			for (int i = 0; i < this.argumentNumbers.length; ++i) {
				this.argumentNames[i] = String.valueOf(this.argumentNumbers[i]);
			}
		}

		boolean isValid = this.maxOffset >= -1 && this.formats.length > this.maxOffset
				&& this.offsets.length > this.maxOffset && this.argumentNames.length > this.maxOffset;
		if (isValid) {
			int lastOffset = this.pattern.length() + 1;

			for (int i = this.maxOffset; i >= 0; --i) {
				if (this.offsets[i] < 0 || this.offsets[i] > lastOffset) {
					isValid = false;
					break;
				}

				lastOffset = this.offsets[i];
			}
		}

		if (!isValid) {
			throw new InvalidObjectException("Could not reconstruct MessageFormat from corrupt stream.");
		} else {
			if (this.ulocale == null) {
				this.ulocale = ULocale.forLocale(this.locale);
			}

		}
	}

	private Map<String, Object> arrayToMap(Object[] array) {
		Map<String, Object> map = new HashMap();
		if (array != null) {
			for (int i = 0; i < array.length; ++i) {
				map.put(Integer.toString(i), array[i]);
			}
		}

		return map;
	}

	private boolean isAlphaIdentifier(String argument) {
		if (argument.length() == 0) {
			return false;
		} else {
			for (int i = 0; i < argument.length(); ++i) {
				if (i == 0 && !UCharacter.isUnicodeIdentifierStart(argument.charAt(i))
						|| i > 0 && !UCharacter.isUnicodeIdentifierPart(argument.charAt(i))) {
					return false;
				}
			}

			return true;
		}
	}

	public static String autoQuoteApostrophe(String pattern) {
		StringBuilder buf = new StringBuilder(pattern.length() * 2);
		int state = 0;
		int braceCount = 0;
		int i = 0;

		for (int j = pattern.length(); i < j; ++i) {
			char c;
			c = pattern.charAt(i);
			label39 : switch (state) {
				case 0 :
					switch (c) {
						case '\'' :
							state = 1;
							break label39;
						case '{' :
							state = 3;
							++braceCount;
						default :
							break label39;
					}
				case 1 :
					switch (c) {
						case '\'' :
							state = 0;
							break label39;
						case '{' :
						case '}' :
							state = 2;
							break label39;
						default :
							buf.append('\'');
							state = 0;
							break label39;
					}
				case 2 :
					switch (c) {
						case '\'' :
							state = 0;
						default :
							break label39;
					}
				case 3 :
					switch (c) {
						case '{' :
							++braceCount;
							break;
						case '}' :
							--braceCount;
							if (braceCount == 0) {
								state = 0;
							}
					}
			}

			buf.append(c);
		}

		if (state == 1 || state == 2) {
			buf.append('\'');
		}

		return new String(buf);
	}

	private static AttributedCharacterIterator _createAttributedCharacterIterator(String text) {
		AttributedString as = new AttributedString(text);
		return as.getIterator();
	}

	private static AttributedCharacterIterator _createAttributedCharacterIterator(
			AttributedCharacterIterator[] iterators) {
		if (iterators != null && iterators.length != 0) {
			StringBuilder sb = new StringBuilder();

			int offset;
			int i;
			for (int i = 0; i < iterators.length; ++i) {
				offset = iterators[i].getBeginIndex();
				i = iterators[i].getEndIndex();

				while (offset < i) {
					sb.append(iterators[i].setIndex(offset++));
				}
			}

			AttributedString as = new AttributedString(sb.toString());
			offset = 0;

			for (i = 0; i < iterators.length; ++i) {
				iterators[i].first();
				int start = iterators[i].getBeginIndex();

				do {
					Map<Attribute, Object> map = iterators[i].getAttributes();
					int len = iterators[i].getRunLimit() - start;
					if (map.size() > 0) {
						Iterator i$ = map.entrySet().iterator();

						while (i$.hasNext()) {
							Entry<Attribute, Object> entry = (Entry) i$.next();
							as.addAttribute((Attribute) entry.getKey(), entry.getValue(), offset, offset + len);
						}
					}

					offset += len;
					start += len;
					iterators[i].setIndex(start);
				} while (iterators[i].current() != '￿');
			}

			return as.getIterator();
		} else {
			return _createAttributedCharacterIterator("");
		}
	}

	private static AttributedCharacterIterator _createAttributedCharacterIterator(AttributedCharacterIterator iterator,
			Attribute key, Object value) {
		AttributedString as = new AttributedString(iterator);
		as.addAttribute(key, value);
		return as.getIterator();
	}

	private static AttributedCharacterIterator _createAttributedCharacterIterator(String text, Attribute key,
			Object value) {
		AttributedString as = new AttributedString(text);
		as.addAttribute(key, value);
		return as.getIterator();
	}
}