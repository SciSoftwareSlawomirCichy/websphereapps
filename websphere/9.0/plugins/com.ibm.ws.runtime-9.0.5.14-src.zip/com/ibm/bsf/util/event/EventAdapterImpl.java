package com.ibm.bsf.util.event;

public class EventAdapterImpl implements EventAdapter {
	protected EventProcessor eventProcessor;

	public void setEventProcessor(EventProcessor var1) {
		this.eventProcessor = var1;
	}
}