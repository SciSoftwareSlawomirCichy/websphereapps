package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.EntryNotFoundException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InvalidIdentifierException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.registry.dataobject.IDAndRealm;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DisplayNameBridge {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private final String className = DisplayNameBridge.class.getName();
	private Logger displayNameBridgeTrace;
	private TypeMappings propertyMap;
	private BridgeUtils mappingUtils;

	public DisplayNameBridge() {
		this.displayNameBridgeTrace = WIMLogger.getTraceLogger(this.className);
		this.propertyMap = new TypeMappings();
		this.mappingUtils = BridgeUtils.singleton();
		String var1 = "DisplayNameBridge";
		if (this.displayNameBridgeTrace.isLoggable(Level.FINER)) {
			this.displayNameBridgeTrace.entering(this.className, var1);
		}

		if (this.displayNameBridgeTrace.isLoggable(Level.FINER)) {
			this.displayNameBridgeTrace.exiting(this.className, var1);
		}

	}

	public String getUserDisplayName(String var1)
			throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = "getUserDisplayName";
		if (this.displayNameBridgeTrace.isLoggable(Level.FINER)) {
			this.displayNameBridgeTrace.entering(this.className, var2, "inputUserSecurityName = \"" + var1 + "\"");
		}

		String var3 = "";

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
			}

			String var6 = "'";
			String var7 = var4.getId();
			if (var7.indexOf("'") != -1) {
				var6 = "\"";
			}

			String var8 = this.propertyMap.getInputUserSecurityName(var4.getRealm());
			var8 = this.mappingUtils.getRealInputAttrName(var8, var7, true);
			String var9 = this.propertyMap.getOutputUserDisplayName(var4.getRealm());
			BridgeUtils var10000 = this.mappingUtils;
			boolean var10 = BridgeUtils.allowDNAsPrincipalName;
			DataObject var11;
			if (var10) {
				var11 = var5.createDataObject("contexts");
				var11.set("key", "allowDNPrincipalNameAsLiteral");
				var11.set("value", var10);
			}

			var11 = null;

			try {
				var11 = this.mappingUtils.getEntityByIdentifier(var5, var8, var7, var9, this.mappingUtils);
			} catch (WIMException var20) {
				if (!var10) {
					throw var20;
				}
			}

			if (var11 != null) {
				var5 = var11;
			} else {
				DataObject var12 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"SearchControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputUserDisplayName(var4.getRealm()))) {
					var12.getList("properties").add(this.propertyMap.getOutputUserDisplayName(var4.getRealm()));
				}

				if (var10) {
					var8 = "principalName";
				}

				var12.setString("expression",
						"//entities[@xsi:type='LoginAccount' and " + var8 + "=" + var6 + var7 + var6 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
			}

			List var22 = var5.getList("entities");
			if (var22.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var2);
			}

			if (var22.size() != 1) {
				boolean var23 = false;
				int var25 = var22.size();
				StringBuilder var15 = new StringBuilder();
				HashSet var16 = new HashSet();

				for (int var24 = 0; var24 < var25; ++var24) {
					DataObject var17 = (DataObject) var22.get(var24);
					if (var17.get("identifier") != null) {
						DataObject var18 = (DataObject) var17.get("identifier");
						if (var18.get("repositoryId") != null) {
							String var19 = String.valueOf(var18.get("repositoryId"));
							if (!var16.contains(var19)) {
								var16.add(var19);
							}
						}
					}
				}

				if (var16.size() == 0) {
					var15.append("repositories");
				} else {
					var15.append(var16);
				}

				throw new EntityNotFoundException("MULTIPLE_PRINCIPALS_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var15), this.className, var2);
			}

			DataObject var13 = (DataObject) var22.get(0);
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputUserDisplayName(var4.getRealm()))) {
				String var14 = this.propertyMap.getOutputUserDisplayName(var4.getRealm());
				if (var14.equals("displayName")) {
					if (var13.getList(var14).size() == 0) {
						var3 = "";
					} else {
						var3 = (String) var13.getList(var14).get(0);
					}
				} else {
					var3 = var13.getString(var14);
				}
			} else {
				var3 = var13.getString("identifier/" + this.propertyMap.getOutputUserDisplayName(var4.getRealm()));
			}
		} catch (WIMException var21) {
			this.mappingUtils.logException(var21, this.className);
			if (!(var21 instanceof EntityNotFoundException) && !(var21 instanceof InvalidIdentifierException)) {
				throw new CustomRegistryException(var21);
			}

			throw new EntryNotFoundException(var21);
		}

		if (this.displayNameBridgeTrace.isLoggable(Level.FINER)) {
			this.displayNameBridgeTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getGroupDisplayName(String var1)
			throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = "getGroupDisplayName";
		if (this.displayNameBridgeTrace.isLoggable(Level.FINER)) {
			this.displayNameBridgeTrace.entering(this.className, var2, "inputGroupSecurityName = \"" + var1 + "\"");
		}

		String var3 = "";

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
			}

			String var6 = "'";
			String var7 = var4.getId();
			if (var7.indexOf("'") != -1) {
				var6 = "\"";
			}

			String var8 = this.propertyMap.getInputGroupSecurityName(var4.getRealm());
			var8 = this.mappingUtils.getRealInputAttrName(var8, var7, false);
			String var9 = this.propertyMap.getOutputGroupDisplayName(var4.getRealm());
			DataObject var10 = this.mappingUtils.getEntityByIdentifier(var5, var8, var7, var9, this.mappingUtils);
			if (var10 != null) {
				var5 = var10;
			} else {
				DataObject var11 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"SearchControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputGroupDisplayName(var4.getRealm()))) {
					var11.getList("properties").add(this.propertyMap.getOutputGroupDisplayName(var4.getRealm()));
				}

				var11.setString("expression",
						"//entities[@xsi:type='Group' and " + var8 + "=" + var6 + var7 + var6 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
			}

			List var20 = var5.getList("entities");
			if (var20.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var2);
			}

			if (var20.size() != 1) {
				boolean var21 = false;
				int var13 = var20.size();
				StringBuilder var14 = new StringBuilder();
				HashSet var15 = new HashSet();

				for (int var22 = 0; var22 < var13; ++var22) {
					DataObject var16 = (DataObject) var20.get(var22);
					if (var16.get("identifier") != null) {
						DataObject var17 = (DataObject) var16.get("identifier");
						if (var17.get("repositoryId") != null) {
							String var18 = String.valueOf(var17.get("repositoryId"));
							if (!var15.contains(var18)) {
								var15.add(var18);
							}
						}
					}
				}

				if (var15.size() == 0) {
					var14.append("repositories");
				} else {
					var14.append(var15);
				}

				throw new EntityNotFoundException("MULTIPLE_PRINCIPALS_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var14), this.className, var2);
			}

			DataObject var12 = (DataObject) var20.get(0);
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputGroupDisplayName(var4.getRealm()))) {
				var3 = var12.getString(this.propertyMap.getOutputGroupDisplayName(var4.getRealm()));
			} else {
				var3 = var12.getString("identifier/" + this.propertyMap.getOutputGroupDisplayName(var4.getRealm()));
			}
		} catch (WIMException var19) {
			this.mappingUtils.logException(var19, this.className);
			if (!(var19 instanceof EntityNotFoundException) && !(var19 instanceof InvalidIdentifierException)) {
				throw new CustomRegistryException(var19);
			}

			throw new EntryNotFoundException(var19);
		}

		if (this.displayNameBridgeTrace.isLoggable(Level.FINER)) {
			this.displayNameBridgeTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}
}