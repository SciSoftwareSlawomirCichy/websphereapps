package com.ibm.ws.wim.util;

import java.util.ArrayList;
import java.util.Arrays;

public class NodeHelper {
	public static String[] getTopNodes(String[] var0) {
		int var1 = var0.length;
		if (var1 == 1) {
			return var0;
		} else {
			ArrayList var2 = new ArrayList(var1);

			for (int var3 = 0; var3 < var0.length; ++var3) {
				String var4 = var0[var3];
				if (var4.length() == 0) {
					return new String[]{var4};
				}

				boolean var5 = false;

				for (int var6 = 0; var6 < var2.size(); ++var6) {
					if (var4.equalsIgnoreCase((String) var2.get(var6))) {
						var5 = true;
					}
				}

				if (!var5) {
					var2.add(var4);
					var0[var3] = var4.toLowerCase();
				}
			}

			Arrays.sort(var0, new StringLengthComparator());
			ArrayList var11 = new ArrayList(var1);

			int var12;
			for (var12 = 0; var12 < var0.length; ++var12) {
				var11.add(var0[var12]);
			}

			var12 = 1;

			for (int var13 = var11.size() - var12; var13 > 0 && var13 < var11.size(); var13 = var11.size() - var12) {
				String var14 = (String) var11.get(var13);
				ArrayList var7 = new ArrayList();

				int var8;
				for (var8 = 0; var8 < var13; ++var8) {
					String var9 = (String) var11.get(var8);
					int var10 = var9.indexOf(var14);
					if (var10 > -1 && var9.length() - var10 == var14.length()) {
						var7.add(var9);
					}
				}

				for (var8 = 0; var8 < var7.size(); ++var8) {
					var11.remove(var7.get(var8));
				}

				++var12;
			}

			ArrayList var15 = new ArrayList();

			for (int var16 = 0; var16 < var2.size(); ++var16) {
				String var17 = (String) var2.get(var16);
				if (var11.contains(var17.toLowerCase())) {
					var15.add(var17);
				}
			}

			return (String[]) ((String[]) var15.toArray(new String[0]));
		}
	}
}