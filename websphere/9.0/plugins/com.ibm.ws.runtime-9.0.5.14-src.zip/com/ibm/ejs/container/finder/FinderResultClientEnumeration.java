package com.ibm.ejs.container.finder;

import com.ibm.ws.ejb.portable.Constants;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Vector;

public class FinderResultClientEnumeration extends FinderResultClientBase implements Enumeration, Serializable {
	static final byte[] frceEyecatcher;
	static final short frcePlatform = 1;
	static final short frceVersionID = 1;
	private static final long serialVersionUID = 92421000330697159L;

	public FinderResultClientEnumeration(Vector wrappers) {
		super((FinderResultServer) null, wrappers, (Object) null, Integer.MAX_VALUE);
	}

	public FinderResultClientEnumeration(FinderResultServer serverImpl, int chunkSize) throws RemoteException {
		super(serverImpl, serverImpl.getNextWrapperCollection(0, chunkSize), (Object) null, chunkSize);
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
		out.write(frceEyecatcher);
		out.writeShort(1);
		out.writeShort(1);
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		byte[] ec = new byte[4];
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < 4; i += bytesRead) {
			bytesRead = in.read(ec, i, 4 - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < frceEyecatcher.length; ++i) {
			if (frceEyecatcher[i] != ec[i]) {
				String eyeCatcherString = new String(ec);
				throw new IOException(
						"Invalid eye catcher '" + eyeCatcherString + "' in FinderResultClientEnumeration input stream");
			}
		}

		in.readShort();
		in.readShort();
	}

	public Vector getCurrentWrappers() {
		return this.wrappers;
	}

	static {
		frceEyecatcher = Constants.FINDER_RESULT_CLIENT_ENUMERATION_EYE_CATCHER;
	}
}