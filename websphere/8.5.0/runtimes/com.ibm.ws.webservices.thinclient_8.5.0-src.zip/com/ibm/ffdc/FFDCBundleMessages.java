package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: FFDC Formatter Added {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Analysis Engine using data base: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: Failed to resolve Analysis Engine:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: FFDC Data Collector Added {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: FFDC Data Collector Removed {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: FFDC Incident emitted on SystemErr: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC in failsafe mode, check for errors {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: FFDC Incident Forwarder Added {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: FFDC Incident Forwarder Removed {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: FFDC Incident emitted on {0} {1} {2}"},
			{"FFDCProviderAborted", "FFDC1000I: FFDC provider {0} aborted, Exception follows"},
			{"FFDCProviderAbortedE", "FFDC1001I: FFDC provider aborted with exception {0}"},
			{"FFDCProviderException", "FFDC1008I: FFDC Provider Exception:"},
			{"FFDCProviderInstalled", "FFDC1007I: FFDC Provider Installed: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: FFDC Formatter Removed {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}