package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.CMProperties;
import com.ibm.ejs.cm.CMPropertiesImpl;
import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.cm.cache.CachedStatement;
import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.cm.portability.PortabilityLayerImpl.1;
import com.ibm.ejs.cm.proxy.ConnectionProxy;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import com.ibm.ws.security.util.AccessController;
import java.lang.reflect.Constructor;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;
import javax.sql.XAConnection;
import javax.sql.XADataSource;

abstract class PortabilityLayerImpl implements PortabilityLayer, ConnectionProxyFactory {
	private static final Class[] setterParamList = new Class[]{String.class};
	protected Hashtable errorMap = new Hashtable();
	protected Vector typeMap = new Vector(13);
	protected String namedColumnSpec_cosnaming_name = "VARCHAR(255) not null";
	private static final int PROCESS_TYPE_ERROR_CODE = 0;
	private static final int PROCESS_TYPE_SQL_STATE = 1;
	protected final Properties defaultDataSourceProps = new Properties();
	private static final String bundleName = "com.ibm.ejs.resources.CONMMessages";
	private static final TraceComponent tc = Tr.register(PortabilityLayerImpl.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	protected PortabilityLayerImpl() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.typeMap.setSize(13);
		this.typeMap.setElementAt(" VARCHAR(64) NOT NULL ", 0);
		this.typeMap.setElementAt(" VARCHAR(64) NOT NULL ", 1);
		this.typeMap.setElementAt(" VARCHAR(64) ", 2);
		this.typeMap.setElementAt(" VARCHAR(256) NOT NULL ", 3);
		this.typeMap.setElementAt(" VARCHAR(256) ", 4);
		this.typeMap.setElementAt(" VARCHAR(1024) NOT NULL ", 5);
		this.typeMap.setElementAt(" VARCHAR(1024) ", 6);
		this.typeMap.setElementAt(" LONG VARCHAR NOT NULL ", 7);
		this.typeMap.setElementAt(" LONG VARCHAR ", 8);
		this.typeMap.setElementAt(" LONG VARBINARY ", 9);
		this.typeMap.setElementAt(" LONG VARBINARY ", 10);
		this.typeMap.setElementAt(" VARCHAR(256) NOT NULL ", 11);
		this.typeMap.setElementAt(" VARCHAR(256) ", 12);
		this.errorMap.put("57011", ResourceAllocationException.class);
		this.errorMap.put("57030", ResourceAllocationException.class);
		this.errorMap.put("55032", StaleConnectionException.class);
		this.errorMap.put("08001", StaleConnectionException.class);
		this.errorMap.put("08003", StaleConnectionException.class);
		this.errorMap.put("40003", StaleConnectionException.class);
		this.errorMap.put("S1000", StaleConnectionException.class);
		this.errorMap.put("08S01", StaleConnectionException.class);
		this.errorMap.put("23505", DuplicateKeyException.class);
		this.errorMap.put("08006", StaleConnectionException.class);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public SQLException translateException(SQLException e) {
		return this.translateException(e, (Hashtable) null);
	}

	public SQLException translateException(SQLException e, Hashtable customMap) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "translateException",
					new Object[]{"Error Code = " + e.getErrorCode(), "SQL State  = " + e.getSQLState(), e});
		}

		if (e instanceof PortableSQLException) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "translateException: Already translated");
			}

			return e;
		} else if (e instanceof BatchUpdateException) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "translateException: Not translating java.sql.BatchUpdateException");
			}

			return e;
		} else {
			Class eClass = null;
			new Integer(e.getErrorCode());
			String eState = e.getSQLState();
			String eMessage = e.getMessage();
			if (customMap != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Trying vendor code in CUSTOM map");
				}

				eClass = this.processListOfExceptions(e, customMap, 0);
			}

			if (eClass == null && eState != null && customMap != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Trying SQL State in CUSTOM map");
				}

				eClass = this.processListOfExceptions(e, customMap, 1);
			}

			if (eClass == null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Trying vendor code in DEFAULT map");
				}

				eClass = this.processListOfExceptions(e, this.errorMap, 0);
			}

			if (eClass == null && eState != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Trying SQL State in DEFAULT map");
				}

				eClass = this.processListOfExceptions(e, this.errorMap, 1);
			}

			if (eClass == null) {
				SQLException e1 = null;
				e1 = e.getNextException();
				if (e1 != null) {
					e = e1;
					new Integer(e1.getErrorCode());
					eState = e1.getSQLState();
					eMessage = e1.getMessage();
					if (customMap != null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Trying vendor code in CUSTOM map after get next exception");
						}

						eClass = this.processListOfExceptions(e1, customMap, 0);
					}

					if (eClass == null && eState != null && customMap != null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Trying SQL State in CUSTOM map afer get next exception");
						}

						eClass = this.processListOfExceptions(e1, customMap, 1);
					}

					if (eClass == null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Trying vendor code in DEFAULT map after get next exception");
						}

						eClass = this.processListOfExceptions(e1, this.errorMap, 0);
					}

					if (eClass == null && eState != null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Trying SQL State in DEFAULT map after get next exception");
						}

						eClass = this.processListOfExceptions(e1, this.errorMap, 1);
					}
				}
			}

			if (eClass == null && eMessage != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Trying detail message in DEFAULT map");
				}

				eClass = (Class) this.errorMap.get(eMessage);
			}

			if (eClass != null && !eClass.equals(Void.class)) {
				try {
					Class[] params = new Class[]{SQLException.class};
					Constructor ctor = eClass.getDeclaredConstructor(params);
					PortableSQLException translation = (PortableSQLException) ctor.newInstance(e);
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "translateException", translation);
					}

					return translation;
				} catch (Exception var11) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "Exception instantiating exception", var11);
					}

					throw new Error(var11.toString());
				}
			} else {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "translateException: No translation found");
				}

				return e;
			}
		}
	}

	private Class processListOfExceptions(SQLException e, Hashtable map, int processType) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "processListOfExceptions");
		}

		SQLException sqe = e;
		Object exceptionClass = null;
		String eState = null;

		for (Integer eCode = null; sqe != null; sqe = sqe.getNextException()) {
			if (processType == 1) {
				eState = sqe.getSQLState();
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Processing SQLState", eState);
				}

				exceptionClass = map.get(eState);
			} else {
				eCode = new Integer(sqe.getErrorCode());
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Processing errorCode", eCode);
				}

				exceptionClass = map.get(eCode);
			}

			if (exceptionClass == null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "No translatable exception found, do not translate");
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "processListOfExceptions", (Object) null);
				}

				return null;
			}

			if (exceptionClass.equals(Void.class)) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Void translate found, no further translation required");
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "processListOfExceptions", (Object) null);
				}

				return (Class) exceptionClass;
			}

			if (!(exceptionClass instanceof String) || !((String) exceptionClass).equals("MaybeStale")) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception Translated");
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "processListOfExceptions", (Class) exceptionClass);
				}

				return (Class) exceptionClass;
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Possible translation for exception, continue through chain");
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "No next exception to translate, do not translate");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "processListOfExceptions", (Object) null);
		}

		return null;
	}

	public void createTable(Connection connection, String schema, String name, String sql) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTable", new Object[]{connection, schema, name, sql});
		}

		Statement statement = null;

		try {
			statement = connection.createStatement();
			statement.executeUpdate(sql);
		} catch (SQLException var10) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "createTable", var10);
			}

			throw this.translateException(var10);
		} finally {
			if (statement != null) {
				statement.close();
			}

		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTable");
		}

	}

	public void createTable(Connection connection, String schema, String sql) throws SQLException {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "createTable", new Object[]{connection, schema, sql});
      }

      Object[] msgArgs = this.supportsSchema() ? new Object[]{schema} : new Object[]{""};
      String formattedSql = (String)AccessController.doPrivileged(new 1(this, sql, msgArgs));
      this.createTable(connection, schema, (String)null, formattedSql);
      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "createTable");
      }

   }

	public void createTableForPersister(Connection connection, String schema, String name, String sql)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTableForPersister", new Object[]{connection, schema, name, sql});
		}

		Statement statement = null;

		try {
			statement = connection.createStatement();
			statement.executeUpdate(sql);
		} catch (SQLException var10) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "createTableForPersister", var10);
			}

			throw this.translateException(var10);
		} finally {
			if (statement != null) {
				statement.close();
			}

		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTableForPersister");
		}

	}

	public void setTransactionIsolation(Connection connection, int isolationLevel) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setTransactionIsolation", new Object[]{connection, new Integer(isolationLevel)});
		}

		try {
			connection.setTransactionIsolation(isolationLevel);
		} catch (SQLException var4) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setTransactionIsolation", var4);
			}

			throw this.translateException(var4);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setTransactionIsolation");
		}

	}

	public void setDate(PreparedStatement ps, int parameterIndex, Date date, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setDate", new Object[]{ps, new Integer(parameterIndex), date, cal});
		}

		if (date == null) {
			ps.setNull(parameterIndex, 91);
		} else {
			ps.setDate(parameterIndex, date, cal);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setDate");
		}

	}

	public void setDate(PreparedStatement ps, int parameterIndex, Date date) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setDate", new Object[]{ps, new Integer(parameterIndex), date});
		}

		if (date == null) {
			ps.setNull(parameterIndex, 91);
		} else {
			ps.setDate(parameterIndex, date);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setDate");
		}

	}

	public void setTime(PreparedStatement ps, int parameterIndex, Time time, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setTime", new Object[]{ps, new Integer(parameterIndex), time, cal});
		}

		if (time == null) {
			ps.setNull(parameterIndex, 92);
		} else {
			ps.setTime(parameterIndex, time, cal);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setTime");
		}

	}

	public void setTime(PreparedStatement ps, int parameterIndex, Time time) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setTime", new Object[]{ps, new Integer(parameterIndex), time});
		}

		if (time == null) {
			ps.setNull(parameterIndex, 92);
		} else {
			ps.setTime(parameterIndex, time);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setTime");
		}

	}

	public Date getDate(ResultSet rs, int columnIndex, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDate", new Object[]{rs, new Integer(columnIndex), cal});
		}

		Date d = rs.getDate(columnIndex, cal);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDate");
		}

		return d;
	}

	public Date getDate(ResultSet rs, String columnName, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDate", new Object[]{rs, columnName, cal});
		}

		Date d = rs.getDate(columnName, cal);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDate");
		}

		return d;
	}

	public Date getDate(ResultSet rs, int columnIndex) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDate", new Object[]{rs, new Integer(columnIndex)});
		}

		Date d = rs.getDate(columnIndex);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDate");
		}

		return d;
	}

	public Date getDate(ResultSet rs, String columnName) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDate", new Object[]{rs, columnName});
		}

		Date d = rs.getDate(columnName);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDate");
		}

		return d;
	}

	public Time getTime(ResultSet rs, int columnIndex, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTime", new Object[]{rs, new Integer(columnIndex), cal});
		}

		Time t = rs.getTime(columnIndex, cal);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTime");
		}

		return t;
	}

	public Time getTime(ResultSet rs, String columnName, Calendar cal) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTime", new Object[]{rs, columnName, cal});
		}

		Time t = rs.getTime(columnName, cal);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTime");
		}

		return t;
	}

	public Time getTime(ResultSet rs, int columnIndex) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTime", new Object[]{rs, new Integer(columnIndex)});
		}

		Time t = rs.getTime(columnIndex);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTime");
		}

		return t;
	}

	public Time getTime(ResultSet rs, String columnName) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTime", new Object[]{rs, columnName});
		}

		Time t = rs.getTime(columnName);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTime");
		}

		return t;
	}

	public String scanSQL(String sql) {
		return sql;
	}

	public String getColumnTypeSpec(int type) {
		return (String) this.typeMap.elementAt(type);
	}

	public String getNamedColumnSpec(int id) {
		return this.namedColumnSpec_cosnaming_name;
	}

	public final Hashtable getErrorMap() {
		return this.errorMap;
	}

	public ConnectionPoolDataSource getDataSource(DataSourceProperties dsProps) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getDataSource", dsProps);
		}

		this.addDefaultProperties(dsProps);
		ConnectionPoolDataSource ds = dsProps.getConnectionPoolDataSource();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getDataSource", ds);
		}

		return ds;
	}

	public XADataSource getXADataSource(DataSourceProperties dsProps) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getXADataSource", dsProps);
		}

		this.addDefaultProperties(dsProps);
		XADataSource ds = dsProps.getXADataSource();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getXADataSource", ds);
		}

		return ds;
	}

	private void addDefaultProperties(DataSourceProperties dsProps) {
		Properties defaultProps = this.getDefaultDataSourceProps();
		Enumeration e = defaultProps.propertyNames();

		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			if (this.keyIsSpecial(key)) {
				this.handleSpecialKey(dsProps, defaultProps, key);
			} else if (dsProps.getProperty(key) == null) {
				dsProps.setProperty(key, defaultProps.getProperty(key));
			}
		}

	}

	public static PortabilityLayer getInstance(DataSourceProperties dsProps) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance", dsProps);
		}

		PortabilityLayer pl = null;
		Connection conn = null;
		PooledConnection pconn = null;
		XAConnection xaconn = null;

		try {
			String user = dsProps.getProperty("user");
			String tmpUser;
			if ((dsProps.getDataSourceType() & 1) != 0) {
				if (user == null) {
					tmpUser = dsProps.getProperty("tmpUser");
					if (tmpUser != null) {
						conn = dsProps.getDataSource().getConnection(tmpUser, dsProps.getProperty("tmpPassword"));
					} else {
						conn = dsProps.getDataSource().getConnection();
					}
				} else {
					conn = dsProps.getDataSource().getConnection(user, dsProps.getProperty("password"));
				}

				pl = PortabilityLayerFactory.getPortabilityLayer(dsProps.getDataSourceClassName(), conn);
			} else if ((dsProps.getDataSourceType() & 2) != 0) {
				if (user == null) {
					tmpUser = dsProps.getProperty("tmpUser");
					if (tmpUser != null) {
						pconn = dsProps.getConnectionPoolDataSource().getPooledConnection(tmpUser,
								dsProps.getProperty("tmpPassword"));
					} else {
						pconn = dsProps.getConnectionPoolDataSource().getPooledConnection();
					}
				} else {
					pconn = dsProps.getConnectionPoolDataSource().getPooledConnection(user,
							dsProps.getProperty("password"));
				}

				conn = pconn.getConnection();
				pl = PortabilityLayerFactory.getPortabilityLayer(dsProps.getDataSourceClassName(), conn);
			} else if ((dsProps.getDataSourceType() & 4) != 0) {
				if (user == null) {
					tmpUser = dsProps.getProperty("tmpUser");
					if (tmpUser != null) {
						xaconn = dsProps.getXADataSource().getXAConnection(tmpUser, dsProps.getProperty("tmpPassword"));
					} else {
						xaconn = dsProps.getXADataSource().getXAConnection();
					}
				} else {
					xaconn = dsProps.getXADataSource().getXAConnection(user, dsProps.getProperty("password"));
				}

				conn = xaconn.getConnection();
				pl = PortabilityLayerFactory.getPortabilityLayer(dsProps.getDataSourceClassName(), conn);
			}
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException var18) {
					;
				}
			}

			if (pconn != null) {
				try {
					pconn.close();
				} catch (SQLException var17) {
					;
				}
			}

			if (xaconn != null) {
				try {
					xaconn.close();
				} catch (SQLException var16) {
					;
				}
			}

			if (pl == null) {
				pl = GenericPortabilityLayer.getInstance(dsProps);
			}

		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance", pl);
		}

		return pl;
	}

	static PortabilityLayer getPortabilityLayer(Connection conn) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPortabilityLayer", conn);
			Tr.exit(tc, "getPortabilityLayer", (Object) null);
		}

		return null;
	}

	public Properties getDefaultDataSourceProps() {
		return this.defaultDataSourceProps;
	}

	public String addRowLockHint(String sql) {
		return sql + " FOR UPDATE";
	}

	public boolean supportsRowLockHint() {
		return true;
	}

	public boolean supportsSchema() {
		return true;
	}

	public ConnectionProxy createConnectionProxy(ConnectO connection) {
		return new ConnectionProxy(connection);
	}

	protected static String replaceString(String oriStr, String oldStr, String newStr) {
		StringBuffer strBuf = new StringBuffer();
		StringTokenizer strTok = new StringTokenizer(oriStr);

		while (strTok.hasMoreTokens()) {
			String token = strTok.nextToken();
			if (token.equals(oldStr + ",")) {
				strBuf.append(newStr + ", ");
			} else {
				strBuf.append(token + " ");
			}
		}

		oriStr = strBuf.toString();
		return oriStr;
	}

	public void configureConnection(Connection conn, CMPropertiesImpl props) throws SQLException {
	}

	public void configurePooledConnection(PooledConnection pconn, CMProperties props) throws SQLException {
	}

	public void configureXAConnection(XAConnection xaconn, CMProperties props) throws SQLException {
	}

	public void setHugeStringForPreparedStatement(HugeString bigstr, PreparedStatement ps, int index)
			throws SQLException {
		ps.setString(index, bigstr.getString());
	}

	public boolean checkCMPStoreOperation(String beanId, Connection c, boolean loadedForUpdate) throws SQLException {
		boolean logged = false;
		int isoLevel = c.getTransactionIsolation();
		if (isoLevel != 2 && isoLevel != 1) {
			if (!loadedForUpdate) {
				logged = true;
				Tr.service(tc, "MSG_CONM_7010W", beanId);
			}
		} else {
			logged = true;
			Tr.service(tc, "MSG_CONM_7008W", beanId);
		}

		return logged;
	}

	public int getPreferredIsolationLevel() {
		return 4;
	}

	public boolean supportsExtendedForUpdate(Connection conn) throws SQLException {
		return false;
	}

	public synchronized Object extendedForUpdateInfo(Connection conn) throws SQLException {
		return null;
	}

	public void resetStatement(CachedStatement statement) throws SQLException {
		statement.setMaxRows(0);
	}

	protected boolean keyIsSpecial(String key) {
		return false;
	}

	protected void handleSpecialKey(DataSourceProperties dsProps, Properties defaultProps, String key) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "handleSpecialKey", key);
			Tr.exit(tc, "handleSpecialKey");
		}

	}

	public synchronized String processSQLForExtendedUpdate(String sql, int isoLevel) {
		return sql;
	}

	public String processSQL(String sqlString, int isolevel, boolean addForUpdate, boolean addextendedforUpdateSyntax) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "processSQL - sqlString, isolevel, addForUpdate, addextendedforupdate: ",
					new Object[]{sqlString, new Integer(isolevel), new Boolean(addForUpdate),
							new Boolean(addextendedforUpdateSyntax)});
		}

		if (addForUpdate) {
			StringBuffer sb = new StringBuffer(250);
			sb.append(sqlString).append(" FOR UPDATE");
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "processSQL - modified sqlString is: " + sb);
			}

			return new String(sb);
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "processSQL - no change: ", sqlString);
			}

			return sqlString;
		}
	}
}