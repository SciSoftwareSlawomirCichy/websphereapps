package com.ibm.ejs;

public class EJSSecurityException extends EJSException {
	public EJSSecurityException(String s) {
		super(s);
	}

	public EJSSecurityException(String s, Throwable ex) {
		super(s, ex);
	}
}