package com.ibm.ejs.cm.cache;

import com.ibm.ejs.cm.cache.StatementCache.1;
import com.ibm.ejs.cm.exception.ConnectionPoolInternalErrorException;
import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.cm.portability.ResourceAllocationException;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.CastoutPolicy;
import com.ibm.ejs.util.LRUCache;
import com.ibm.websphere.pmi.ConnPoolPerf;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

public final class StatementCache {
	private static final int RESOURCE_ALLOCATION_RETRY_LIMIT = 4;
	private final LRUCache freeStatements;
	private final ArrayList busyStatements;
	private final ConnPoolPerf connPoolData;
	private final ConnectO connectO;
	private final Connection conn;
	private static final TraceComponent tc = Tr.register(StatementCache.class);

	public StatementCache(Connection c, ConnPoolPerf pmiData, ConnectO co, int maxsize) {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "<init>", new Object[]{c});
      }

      this.connectO = co;
      this.connPoolData = pmiData;
      this.conn = c;
      CastoutPolicy policy = new 1(this);
      this.freeStatements = new LRUCache(maxsize, policy);
      this.busyStatements = new ArrayList(maxsize);
      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "<init>");
      }

   }

	public CachedStatement prepareStatement(String sql, int type, int concurrency) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "prepareStatement", sql);
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "sql, type, and concurrency", new Object[]{sql, new Integer(type), new Integer(concurrency)});
		}

		StringBuffer sbKey = new StringBuffer(sql.length() + 25);
		sbKey.append(sql).append(type).append(concurrency);
		String key = sbKey.toString();
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Key for Hashtable ", key);
		}

		CachedStatement s = null;
		synchronized (this) {
			s = (CachedStatement) this.freeStatements.remove(key);
		}

		if (s == null) {
			s = this.reallyPrepareStatement(key, sql, type, concurrency);
		} else {
			synchronized (this) {
				this.busyStatements.add(s);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "prepareStatement", s);
		}

		return s;
	}

	public void releaseStatements() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "releaseStatements");
		}

		if (this.busyStatements != null) {
			Iterator i = this.busyStatements.iterator();

			while (i.hasNext()) {
				CachedStatement stmt = (CachedStatement) i.next();
				this.freeStatements.put(stmt.getStatementString(), stmt);
			}

			this.busyStatements.clear();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "releaseStatements");
		}

	}

	synchronized void releaseStatement(CachedStatement statement) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "releaseStatement", statement);
		}

		boolean removeSuccessful = this.busyStatements.remove(statement);
		if (!removeSuccessful) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "releaseStatement: Unknown statement");
			}

			throw new ConnectionPoolInternalErrorException(statement + " doesn't belong to this cache");
		} else {
			statement.clearParameters();
			PortabilityLayer pbl = (PortabilityLayer) this.connectO.getPortabilityLayer();
			pbl.resetStatement(statement);
			this.freeStatements.put(statement.getStatementString(), statement);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "releaseStatement");
			}

		}
	}

	public void destroy() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy");
		}

		Enumeration e = this.freeStatements.elements();

		while (e.hasMoreElements()) {
			((CachedStatement) e.nextElement()).destroy();
		}

		Iterator i = this.busyStatements.iterator();

		while (i.hasNext()) {
			((CachedStatement) i.next()).destroy();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "destroy");
		}

	}

	private CachedStatement reallyPrepareStatement(String key, String sql, int type, int concurrency)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "reallyPrepareStatement", new Object[]{key, sql});
		}

		int failures = 0;

		while (true) {
			try {
				CachedStatement s;
				if (type == 1003 && concurrency == 1007) {
					s = new CachedStatement(this, key, this.conn.prepareStatement(sql));
				} else {
					s = new CachedStatement(this, key, this.conn.prepareStatement(sql, type, concurrency));
				}

				synchronized (this) {
					this.busyStatements.add(s);
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "reallyPrepareStatement", s);
				}

				return s;
			} catch (ResourceAllocationException var10) {
				++failures;
				if (failures > 4) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "reallyPrepareStatement: hit retry limit", var10.getNativeException());
					}

					throw var10.getNativeException();
				}
			} catch (SQLException var11) {
				if (this.connectO != null) {
					throw this.connectO.translateException(var11);
				}

				throw var11;
			}
		}
	}
}