package com.ibm.ejs.csi;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.am.Alarm;
import com.ibm.ejs.util.am.AlarmListener;
import com.ibm.ejs.util.am.AlarmManager;
import com.ibm.websphere.csi.Pool;
import com.ibm.websphere.csi.PoolDiscardStrategy;
import com.ibm.websphere.csi.PoolManager;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import java.util.ArrayList;
import java.util.List;

public class PoolManagerImpl extends PoolManager implements AlarmListener {
	private static final String CLASS_NAME = PoolManagerImpl.class.getName();
	private static final TraceComponent tc;
	private final List<PoolImplBase> pools = new ArrayList();
	private PoolImplBase[] poolArray = new PoolImplBase[10];
	private long drainInterval = 30000L;
	private Alarm ivAlarm;
	private boolean ivIsCanceled = false;
	private boolean ivIsRunning;

	public void setDrainInterval(long di) {
		this.drainInterval = di;
	}

	public void alarm(Object alarmContext) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.entry(tc, "alarm");
		}

		synchronized (this) {
			if (this.ivIsCanceled) {
				return;
			}

			this.ivIsRunning = true;
			int numPools = this.pools.size();
			if (numPools > 0) {
				if (numPools > this.poolArray.length) {
					this.poolArray = new PoolImplBase[numPools];
				}

				this.pools.toArray(this.poolArray);
			}
		}

		boolean var14 = false;

		try {
			var14 = true;
			int i = 0;

			while (true) {
				if (i >= this.poolArray.length) {
					var14 = false;
					break;
				}

				if (this.poolArray[i] == null) {
					var14 = false;
					break;
				}

				if (this.poolArray[i].inactive) {
					this.poolArray[i].periodicDrain();
				} else {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "setting inactive: " + this.poolArray[i]);
					}

					this.poolArray[i].inactive = true;
				}

				this.poolArray[i] = null;
				++i;
			}
		} finally {
			if (var14) {
				synchronized (this) {
					this.ivIsRunning = false;
					if (this.ivIsCanceled) {
						this.notify();
					} else if (!this.pools.isEmpty()) {
						this.startAlarm();
					} else {
						this.ivAlarm = null;
					}

				}
			}
		}

		synchronized (this) {
			this.ivIsRunning = false;
			if (this.ivIsCanceled) {
				this.notify();
			} else if (!this.pools.isEmpty()) {
				this.startAlarm();
			} else {
				this.ivAlarm = null;
			}
		}

		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.exit(tc, "alarm");
		}

	}

	synchronized void add(PoolImplBase p) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "add: " + p);
		}

		if (!this.ivIsCanceled) {
			if (this.pools.isEmpty()) {
				this.startAlarm();
			}

			this.pools.add(p);
		}

	}

	synchronized void remove(Pool p) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "remove: " + p);
		}

		this.pools.remove(p);
		if (this.pools.isEmpty()) {
			this.stopAlarm();
		}

	}

	public Pool createThreadSafePool(int minimum, int maximum) {
		PoolImplBase result = new PoolImplThreadSafe(minimum, maximum, 20, (EJBPMICollaborator) null,
				(PoolDiscardStrategy) null, this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "createThreadSafePool: " + result);
		}

		return result;
	}

	public Pool createThreadSafePool(int minimum, int maximum, EJBPMICollaborator beanPerf) {
		PoolImplBase result = new PoolImplThreadSafe(minimum, maximum, 20, beanPerf, (PoolDiscardStrategy) null, this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "createThreadSafePool: " + result);
		}

		return result;
	}

	public Pool create(int minimum, int maximum, EJBPMICollaborator beanPerf, PoolDiscardStrategy d) {
		PoolImplBase result = new PoolImplThreadSafe(minimum, maximum, 20, beanPerf, d, this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "create: " + result);
		}

		return result;
	}

	private void startAlarm() {
		this.ivAlarm = AlarmManager.createDeferrable(this.drainInterval, this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "started alarm: " + this.ivAlarm);
		}

	}

	private void stopAlarm() {
		if (this.ivAlarm != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "stopping alarm: " + this.ivAlarm);
			}

			this.ivAlarm.cancel();
			this.ivAlarm = null;
		}

	}

	public synchronized void cancel() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "cancel");
		}

		this.ivIsCanceled = true;
		this.stopAlarm();

		while (this.ivIsRunning) {
			try {
				this.wait();
			} catch (InterruptedException var2) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "cancel: interrupted", var2);
				}

				Thread.currentThread().interrupt();
			}
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", (String) null);
	}
}