package com.ibm.ejs.container;

import com.ibm.websphere.csi.J2EEName;
import java.util.ArrayList;

public final class BindingData {
	public J2EEName ivExplicitBean;
	public String ivExplicitInterface;
	public ArrayList<J2EEName> ivImplicitBeans;
}