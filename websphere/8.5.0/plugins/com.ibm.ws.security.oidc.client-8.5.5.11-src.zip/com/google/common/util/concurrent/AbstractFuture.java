package com.google.common.util.concurrent;

import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.AbstractFuture.Sync;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.annotation.Nullable;

public abstract class AbstractFuture<V> implements ListenableFuture<V> {
	private final Sync<V> sync = new Sync();
	private final ExecutionList executionList = new ExecutionList();

	public V get(long timeout, TimeUnit unit) throws InterruptedException, TimeoutException, ExecutionException {
		return this.sync.get(unit.toNanos(timeout));
	}

	public V get() throws InterruptedException, ExecutionException {
		return this.sync.get();
	}

	public boolean isDone() {
		return this.sync.isDone();
	}

	public boolean isCancelled() {
		return this.sync.isCancelled();
	}

	public boolean cancel(boolean mayInterruptIfRunning) {
		if (!this.sync.cancel(mayInterruptIfRunning)) {
			return false;
		} else {
			this.executionList.execute();
			if (mayInterruptIfRunning) {
				this.interruptTask();
			}

			return true;
		}
	}

	protected void interruptTask() {
	}

	protected final boolean wasInterrupted() {
		return this.sync.wasInterrupted();
	}

	public void addListener(Runnable listener, Executor exec) {
		this.executionList.add(listener, exec);
	}

	protected boolean set(@Nullable V value) {
		boolean result = this.sync.set(value);
		if (result) {
			this.executionList.execute();
		}

		return result;
	}

	protected boolean setException(Throwable throwable) {
		boolean result = this.sync.setException((Throwable) Preconditions.checkNotNull(throwable));
		if (result) {
			this.executionList.execute();
		}

		if (throwable instanceof Error) {
			throw (Error) throwable;
		} else {
			return result;
		}
	}

	static final CancellationException cancellationExceptionWithCause(@Nullable String message,
			@Nullable Throwable cause) {
		CancellationException exception = new CancellationException(message);
		exception.initCause(cause);
		return exception;
	}
}