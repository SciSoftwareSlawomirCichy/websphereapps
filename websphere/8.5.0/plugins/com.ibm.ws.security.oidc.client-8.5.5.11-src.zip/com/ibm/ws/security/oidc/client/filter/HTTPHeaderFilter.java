package com.ibm.ws.security.oidc.client.filter;

import javax.servlet.http.HttpServletRequest;

public interface HTTPHeaderFilter {
	boolean init(String var1);

	boolean isAccepted(HttpServletRequest var1);

	void setProcessAll(boolean var1);

	boolean noFilter();
}