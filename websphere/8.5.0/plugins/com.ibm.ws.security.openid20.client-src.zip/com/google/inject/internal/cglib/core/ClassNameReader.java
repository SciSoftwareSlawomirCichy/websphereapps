package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.ClassReader;
import com.google.inject.internal.asm.ClassVisitor;
import com.google.inject.internal.cglib.core.ClassNameReader.1;
import com.google.inject.internal.cglib.core.ClassNameReader.EarlyExitException;
import java.util.ArrayList;

public class ClassNameReader {
	private static final EarlyExitException EARLY_EXIT = new EarlyExitException((1)null);

	public static String getClassName(ClassReader r) {
		return getClassInfo(r)[0];
	}

	public static String[] getClassInfo(ClassReader r) {
      ArrayList array = new ArrayList();

      try {
         r.accept(new 1((ClassVisitor)null, array), 6);
      } catch (EarlyExitException var3) {
         ;
      }

      return (String[])((String[])array.toArray(new String[0]));
   }
}