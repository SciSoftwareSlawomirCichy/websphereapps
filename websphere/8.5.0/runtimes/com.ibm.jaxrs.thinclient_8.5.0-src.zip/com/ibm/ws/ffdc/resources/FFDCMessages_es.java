package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_es extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: El motor de análisis está utilizando la base de datos: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Incidencia de FFDC emitida en {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: La gestión de archivos de anotaciones cronológicas de FFDC está intentando suprimir el archivo {0}"},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: La gestión de archivos de anotaciones cronológicas de FFDC ha eliminado {0} de {1} archivos que han alcanzado su antigüedad máxima configurada"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: La gestión de archivos de anotaciones cronológicas de FFDC no ha podido suprimir el archivo {0}"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: La gestión de archivos de anotaciones cronológicas de FFDC no ha podido obtener la lista de archivos de excepciones"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC ha cerrado el archivo continuo de incidencia {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC ha abierto un archivo continuo {0} de incidentes"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: FFDC no ha podido cerrar el archivo continuo {0} de incidentes, se ha capturado la excepción {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: FFDC no ha podido abrir o crear el archivo continuo de incidencia {0}, ha captado la excepción {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: FFDC no ha podido escribir en el archivo continuo {0} de incidentes, se ha capturado la excepción {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}