package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;

@GwtCompatible(serializable = true, emulated = true)
public class HashMultiset<E> extends AbstractMapBasedMultiset<E> {
	@GwtIncompatible
	private static final long serialVersionUID = 0L;

	public static <E> HashMultiset<E> create() {
		return create(3);
	}

	public static <E> HashMultiset<E> create(int distinctElements) {
		return new HashMultiset(distinctElements);
	}

	public static <E> HashMultiset<E> create(Iterable<? extends E> elements) {
		HashMultiset<E> multiset = create(Multisets.inferDistinctElements(elements));
		Iterables.addAll(multiset, elements);
		return multiset;
	}

	HashMultiset(int distinctElements) {
		super(distinctElements);
	}

	void init(int distinctElements) {
		this.backingMap = new ObjectCountHashMap(distinctElements);
	}
}