package com.ibm.ejs.ras;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Logger;

public class TraceComponent {
	public static final String $sccsid = "@(#) 1.14 SERV1/ws/code/ras.lite/src/com/ibm/ejs/ras/TraceComponent.java, WAS.ras.lite, WAS855.SERV1, cf172003.01 11/09/22 16:05:08 [1/28/20 10:11:16]";
	private String name;
	private volatile String group = "";
	private List<String> groups;
	private String bundle;
	private static final int TRACE_LEVEL_OFF = 16;
	private int traceLevel = 16;
	private Logger logger = null;
	private volatile boolean isDumpEnabled = false;
	private volatile boolean isDebugEnabled = false;
	private volatile boolean isEntryEnabled = false;
	private volatile boolean isEventEnabled = false;
	private volatile boolean isDetailEnabled = false;
	private volatile boolean isConfigEnabled = false;
	private volatile boolean isInfoEnabled = false;
	private volatile boolean isAuditEnabled = false;
	private volatile boolean isWarningEnabled = false;
	private volatile boolean isErrorEnabled = false;
	private volatile boolean isFatalEnabled = false;
	private volatile boolean isServiceEnabled = false;
	private static volatile long noActiveTraceComponents;
	private TraceStateChangeListener wsLogger = null;
	private static String[][] traceLevels;

	TraceComponent(String name) {
		this.name = name;
	}

	public TraceComponent(String name, String group, String bundle) {
		this.name = name;
		if (group != null) {
			this.group = group;
		}

		this.bundle = bundle;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	public Logger getLogger() {
		return this.logger;
	}

	private static synchronized void incrementNoActiveTraceComponents() {
		++noActiveTraceComponents;
	}

	private static synchronized void decrementNoActiveTraceComponents() {
		if (noActiveTraceComponents > 0L) {
			--noActiveTraceComponents;
		}

	}

	public synchronized void addGroup(String group) {
		if (this.group.isEmpty()) {
			this.group = group;
		} else {
			List<String> groups = this.groups;
			if (groups == null) {
				this.groups = (List) (groups = new ArrayList(1));
			}

			((List) groups).add(group);
		}

	}

	public final synchronized void setTraceSpec(String s) {
		if (s != null) {
			boolean oldTraceState = this.isDumpEnabled | this.isDebugEnabled | this.isEntryEnabled | this.isEventEnabled
					| this.isDetailEnabled | this.isConfigEnabled | this.isInfoEnabled | this.isAuditEnabled
					| this.isWarningEnabled | this.isErrorEnabled | this.isFatalEnabled | this.isServiceEnabled;
			this.isDumpEnabled = false;
			this.isDebugEnabled = false;
			this.isEntryEnabled = false;
			this.isEventEnabled = false;
			this.isDetailEnabled = false;
			this.isConfigEnabled = false;
			this.isInfoEnabled = false;
			this.isAuditEnabled = false;
			this.isWarningEnabled = false;
			this.isErrorEnabled = false;
			this.isFatalEnabled = false;
			this.isServiceEnabled = false;
			this.traceLevel = 16;
			StringTokenizer st = new StringTokenizer(s, ":");

			while (st.hasMoreTokens()) {
				this.traceSpec(st.nextToken());
			}

			boolean newTraceState = this.isDumpEnabled | this.isDebugEnabled | this.isEntryEnabled | this.isEventEnabled
					| this.isDetailEnabled | this.isConfigEnabled | this.isInfoEnabled | this.isAuditEnabled
					| this.isWarningEnabled | this.isErrorEnabled | this.isFatalEnabled | this.isServiceEnabled;
			if (!oldTraceState && newTraceState) {
				incrementNoActiveTraceComponents();
			}

			if (oldTraceState && !newTraceState) {
				decrementNoActiveTraceComponents();
			}

			if (this.wsLogger != null) {
				this.wsLogger.traceStateChanged();
			}
		}

	}

	public static boolean isAnyTracingEnabled() {
		return noActiveTraceComponents > 0L;
	}

	public final boolean isDumpEnabled() {
		return this.isDumpEnabled;
	}

	final void setResourceBundleName(String name) {
		this.bundle = name;
	}

	public final String getResourceBundleName() {
		return this.bundle;
	}

	public final void setLoggerForCallback(TraceStateChangeListener logger) {
		this.wsLogger = logger;
	}

	public final String getName() {
		return this.name;
	}

	public final boolean isDebugEnabled() {
		return this.isDebugEnabled;
	}

	public final boolean isEntryEnabled() {
		return this.isEntryEnabled;
	}

	public final boolean isEventEnabled() {
		return this.isEventEnabled;
	}

	public final boolean isDetailEnabled() {
		return this.isDetailEnabled;
	}

	public final boolean isConfigEnabled() {
		return this.isConfigEnabled;
	}

	public final boolean isInfoEnabled() {
		return this.isInfoEnabled;
	}

	public final boolean isAuditEnabled() {
		return this.isAuditEnabled;
	}

	public final boolean isWarningEnabled() {
		return this.isWarningEnabled;
	}

	public final boolean isErrorEnabled() {
		return this.isErrorEnabled;
	}

	public final boolean isFatalEnabled() {
		return this.isFatalEnabled;
	}

	public final boolean isServiceEnabled() {
		return this.isServiceEnabled;
	}

	private void traceSpec(String s) {
		String clazz = "*";
		String level = "all";
		String setting = "enabled";
		StringTokenizer st = new StringTokenizer(s, "=");
		if (st.hasMoreTokens()) {
			clazz = st.nextToken();
		}

		if (st.hasMoreTokens()) {
			level = st.nextToken();
			if ("dump".equals(level)) {
				level = "debug";
			}
		}

		if (st.hasMoreTokens()) {
			setting = st.nextToken();
		}

		if (setting.equals("enabled")) {
			boolean process;
			int traceLevelCount;
			if (clazz.endsWith("*")) {
				if (clazz.length() > 1) {
					clazz = clazz.substring(0, clazz.length() - 1);
				}

				process = clazz.equals("*") || this.name.startsWith(clazz) || this.group.startsWith(clazz);
				if (!process && !this.group.isEmpty()) {
					synchronized (this) {
						if (this.groups != null) {
							for (traceLevelCount = 0; traceLevelCount < this.groups.size(); ++traceLevelCount) {
								if (((String) this.groups.get(traceLevelCount)).startsWith(clazz)) {
									process = true;
									break;
								}
							}
						}
					}
				}
			} else {
				process = this.name.equals(clazz) || this.group.equals(clazz);
				if (!process && !this.group.isEmpty()) {
					synchronized (this) {
						if (this.groups != null) {
							process = this.groups.contains(clazz);
						}
					}
				}
			}

			if (process) {
				int found = -1;
				traceLevelCount = 1;

				for (int i = 0; i < Array.getLength(traceLevels) && found < 0; ++i) {
					for (int j = 0; j < Array.getLength(traceLevels[i]) && found < 0; ++j) {
						if (level.equals(traceLevels[i][j])) {
							found = i;
							this.traceLevel = traceLevelCount;
						}

						++traceLevelCount;
					}
				}

				if (found >= 0) {
					this.isDumpEnabled = found <= 1;
					this.isDebugEnabled = found <= 1;
					this.isEntryEnabled = found <= 2;
					this.isEventEnabled = found <= 3;
					this.isDetailEnabled = found <= 4;
					this.isConfigEnabled = found <= 5;
					this.isInfoEnabled = found <= 6;
					this.isAuditEnabled = found <= 7;
					this.isServiceEnabled = found <= 7;
					this.isWarningEnabled = found <= 8;
					this.isErrorEnabled = found <= 9;
					this.isFatalEnabled = found <= 10;
				}
			}
		}

	}

	public final int getLevel() {
		return this.traceLevel;
	}

	static {
		Tr.init();
		noActiveTraceComponents = 0L;
		traceLevels = new String[][]{{"all"}, {"finest", "debug"}, {"finer", "entryExit"}, {"fine", "event"},
				{"detail"}, {"config"}, {"info"}, {"audit"}, {"warning"}, {"severe", "error"}, {"fatal"}, {"off"}};
	}
}