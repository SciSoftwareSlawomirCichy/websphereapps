package com.ibm.ejs.container;

import com.ibm.websphere.interrupt.AsyncFutureGetODI;
import com.ibm.websphere.interrupt.InterruptObject;
import com.ibm.websphere.interrupt.ODIRegistrar;
import com.ibm.ws.asynchbeans.WSWorkItem;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import java.util.concurrent.TimeUnit;

public class ServerAsyncResultImpl extends ServerAsyncResult {
	public WSWorkItem ivWorkItem;

	public ServerAsyncResultImpl(EJBPMICollaborator pmiBean) {
		super(pmiBean);
	}

	protected boolean doCancel() {
		return this.ivWorkItem.removeFromWorkQueue();
	}

	protected boolean await(long timeout, TimeUnit unit) throws InterruptedException {
		InterruptObject anOdi = null;
		if (ODIRegistrar.isODISupported() && !this.isDone()) {
			anOdi = new AsyncFutureGetODI(unit == null
					? "Async Future.get(): Awaiting Latch"
					: "Async Future.get(timeout=" + timeout + " unit=" + unit + ") : Awaiting Latch");
			ODIRegistrar.registerODI(anOdi);
		}

		boolean var5;
		try {
			var5 = super.await(timeout, unit);
		} finally {
			if (anOdi != null) {
				ODIRegistrar.deRegisterODI(anOdi);
			}

		}

		return var5;
	}
}