package com.ibm.ws.wim.dao;

import com.ibm.websphere.wim.copyright.IBMCopyright;

public abstract class QuerySet {
	static final String COPYRIGHT_NOTICE;
	public String DBENTITY = "DBENTITY";
	public String DBENTREL = "DBENTREL";
	public String DBSTRPROP = "DBSTRPROP";
	public String DBLONGPROP = "DBLONGPROP";
	public String DBINTPROP = "DBINTPROP";
	public String DBREFPROP = "DBREFPROP";
	public String DBTSPROP = "DBTSPROP";
	public String DBBLOBPROP = "DBBLOBPROP";
	public String DBCOMPPROP = "DBCOMPPROP";
	public String DBPROPENT = "DBPROPENT";
	public String DBPROPTYPE = "DBPROPTYPE";
	public String DBACCT = "DBACCT";
	public String DBDBLPROP = "DBDBLPROP";
	public String DBGRPREL = "DBGRPREL";
	public String DBPROP = "DBPROP";
	public String DBCOMPREL = "DBCOMPREL";
	public String DBKEYS = "DBKEYS";
	public String LACOMPREL = "LACOMPREL";
	public String LAKEYS = "LAKEYS";
	public String LAPROP = "LAPROP";
	public String LAENTITY = "LAENTITY";
	public String LASTRPROP = "LASTRPROP";
	public String LALONGPROP = "LALONGPROP";
	public String LADBLPROP = "LADBLPROP";
	public String LAINTPROP = "LAINTPROP";
	public String LAREFPROP = "LAREFPROP";
	public String LATSPROP = "LATSPROP";
	public String LABLOBPROP = "LABLOBPROP";
	public String LACOMPPROP = "LACOMPPROP";
	public String LAPROPENT = "LAPROPENT";
	public String FEDENTITY = "FEDENTITY";
	public String createDBEntity;
	public String createEntityRelation;
	public String createDBStringValue;
	public String createDBLongValue;
	public String createDBDoubleValue;
	public String createDBIntegerValue;
	public String createDBReferenceValue;
	public String createDBTimestampValue;
	public String createDBBlobValue;
	public String createDBCompositePropertyValue;
	public String createLAEntity;
	public String createLAStringValue;
	public String createLALongValue;
	public String createLADoubleValue;
	public String createLAIntegerValue;
	public String createLAReferenceValue;
	public String createLATimestampValue;
	public String createLABlobValue;
	public String createLACompositePropertyValue;
	public String createAccount;
	public String createDBGrpRelation;
	public String createPropertyDefintion;
	public String createLAPropertyDefintion;
	public String createPropertyEntity;
	public String removeDBGroupRelationMain;
	public String orRemoveDBGroupRelationByExtIdAndReposId;
	public String deleteDBEntityWithDescendants;
	public String deleteAllDBGrpRelationForMember;
	public String unassignGrpRelation;
	public String deleteAllDBGrpRelationForGroup;
	public String deleteLAEntity;
	public String deletePropertiesFromDBStringProp;
	public String deletePropertiesFromDBIntegerProp;
	public String deletePropertiesFromDBDoubleProp;
	public String deletePropertiesFromDBBlobProp;
	public String deletePropertiesFromDBTimestampProp;
	public String deletePropertiesFromDBLongProp;
	public String deletePropertiesFromDBReferenceProp;
	public String entityIDEquals;
	public String deletePropertiesFromLAStringProp;
	public String deletePropertiesFromLAIntegerProp;
	public String deletePropertiesFromLADoubleProp;
	public String deletePropertiesFromLABlobProp;
	public String deletePropertiesFromLATimestampProp;
	public String deletePropertiesFromLALongProp;
	public String deletePropertiesFromLAReferenceProp;
	public String deleteDBCompositeProperties;
	public String deleteLACompositeProperties;
	public String updateEntityUniqueName;
	public String updatePrincipalNamePassword;
	public String updatePrincipalName;
	public String updateDBAcct;
	public String updatePrincipal;
	public String updateDBStringValue;
	public String updateDBLongValue;
	public String updateDBDoubleValue;
	public String updateDBIntegerValue;
	public String updateDBTimestampValue;
	public String updateDBReferenceValue;
	public String updateDBBlobValue;
	public String updateLAStringValue;
	public String updateLALongValue;
	public String updateLADoubleValue;
	public String updateLAIntegerValue;
	public String updateLATimestampValue;
	public String updateLAReferenceValue;
	public String updateLABlobValue;
	public String updateDBStringValueWithOldValue;
	public String updateDBLongValueWithOldValue;
	public String updateDBDoubleValueWithOldValue;
	public String updateDBIntegerValueWithOldValue;
	public String updateDBTimestampValueWithOldValue;
	public String updateDBReferenceValueWithOldValue;
	public String updateDBBlobValueWithOldValue;
	public String updateLAStringValueWithOldValue;
	public String updateLALongValueWithOldValue;
	public String updateLADoubleValueWithOldValue;
	public String updateLAIntegerValueWithOldValue;
	public String updateLATimestampValueWithOldValue;
	public String updateLAReferenceValueWithOldValue;
	public String updateLABlobValueWithOldValue;
	public String searchFromDBEntity;
	public String searchWhere1Equals1;
	public String dotColumnValue;
	public String dotColumnValueKey;
	public String dotColumnRefUnameKey;
	public String dbTableStringValue;
	public String dbTableIntegerValue;
	public String dbTableLongValue;
	public String dbTableDoubleValue;
	public String dbTableTimeStampValue;
	public String dbTableReferenceValue;
	public String searchDBEntityJoinCondition;
	public String searchPropertyIdCondition;
	public String searchDBEntitySubSelect;
	public String searchDBEntityTypeCondition;
	public String searchDBNoResultPropertyWhere;
	public String getDBObjectPropertyValuesByEntityIds;
	public String andDBObjectPropertyIdInWithLeftBracket;
	public String andDBCompositePropertyIdInWithLeftBracket;
	public String andDBCompositeEntityIdInWithLeftBracket;
	public String findCompositePropertiesForDBEntities;
	public String findStringCompositePropertiessForDBEntities;
	public String findLongCompositePropertiessForDBEntities;
	public String findDoubleCompositePropertiessForDBEntities;
	public String findIntegerCompositePropertiessForDBEntities;
	public String findTimestampCompositePropertiessForDBEntities;
	public String findReferenceCompositePropertiessForDBEntities;
	public String searchFromDBEntityAndDBTableStringValue;
	public String isMemberinImmediateGroup;
	public String ENTITY_ID_IN;
	public String UNIQUE_NAME_KEY = " UNIQUE_NAME_KEY";
	public String SINGLE_QUOTE = "'";
	public String SEARCH_BASE_EXPRESSION = "LOWER(UNIQUE_NAME) LIKE '%?%'";
	public String COMMA = ",";
	public String COMMA_AND_SPACE = ", ";
	public String RIGHT_BRACKET = ")";
	public String LEFT_BRACKET = "(";
	public String AND = " AND ";
	public String OR = " OR ";
	public String WHERE = " WHERE ";
	public String UNION = " UNION ";
	public String UNION_ALL = " UNION ALL ";
	public String NOT_EQUAL = "<>";
	public String LIKE = " LIKE ";
	public String PARAM_MARKER = " ? ";
	public String searchFromLAEntity;
	public String laTableStringValue;
	public String laTableIntegerValue;
	public String laTableLongValue;
	public String laTableDoubleValue;
	public String laTableTimeStampValue;
	public String laTableReferenceValue;
	public String searchLAEntityJoinCondition;
	public String SearchLAEntitySubSelect;
	public String searchLAEntityTypeCondition;
	public String searchLANoResultPropertyWhere;
	public String findLAEntityGeneral;
	public String findLAPropertyIdIn;
	public String findStringPropertyForLAEntities;
	public String findLongPropertyForLAEntities;
	public String findDoublePropertyForLAEntities;
	public String findIntegerPropertyForLAEntities;
	public String findTimestampPropertyForLAEntities;
	public String findReferencePropertyForLAEntities;
	public String findLASpecificPropertyForEntitiesOrderBy;
	public String getLAObjectPropertyValuesByEntityIds;
	public String andLAObjectPropertyIdInWithLeftBracket;
	public String andLACompositePropertyIdInWithLeftBracket;
	public String andLACompositeEntityIdInWithLeftBracket;
	public String findCompositePropertiesOrderBy;
	public String findCompositePropertiesForLAEntities;
	public String findStringCompositePropertiessForLAEntities;
	public String findLongCompositePropertiessForLAEntities;
	public String findDoubleCompositePropertiessForLAEntities;
	public String findIntegerCompositePropertiessForLAEntities;
	public String findTimestampCompositePropertiessForLAEntities;
	public String findReferenceCompositePropertiessForLAEntities;
	public String findDBAllProperties;
	public String findLAAllProperties;
	public String selectGEntIdwithGNames;
	public String selectGEntIdwithGUIDs;
	public String findDescendantsByUniqueNames;
	public String findDBEntitysByUniqueNameKeyLike;
	public String findUniqueIdByUniqueNameKey;
	public String findDBAllCompositeProperties;
	public String findDBAllCompositePropertiesOrderBy;
	public String findLAAllCompositeProperties;
	public String findDBEntityByUniqueId;
	public String findDBEntityByUniqueNameKey;
	public String findParentByEntityId;
	public String findAllDescendantsByUniqueNameKey;
	public String entityTypesIn;
	public String findChildrenByUniqueNameKey;
	public String findChildrenByAncestorIdIn;
	public String childrenEntityTypesIn;
	public String findImmediateGroupIdsByExtIdAndReposId;
	public String findImmediateGroupIdsByExtIdAndReposIdUnderSearchBases;
	public String uniqueNameEndWith;
	public String findNestedGroupIdsByExtIdAndReposId;
	public String findNestedGroupIdsByExtIdAndReposIdUnderSearchBases;
	public String findImmediateGroupMemberIdsByGroupEntId;
	public String findImmediateGroupMemberIdsByGroupEntIdForEntityType;
	public String findImmediateGroupMemberIdsByGroupEntIdForEntityTypeWhere;
	public String findLeafEntityUniqueName;
	public String findDBEntityByEntityId;
	public String findDBAccountByEntId;
	public String findLAEntityByExtIdReposId;
	public String getDBStringPropValuesByEntityId;
	public String getDBIntegerPropValuesByEntityId;
	public String getDBLongPropValuesByEntityId;
	public String getDBDoublePropValuesByEntityId;
	public String getDBTimestampPropValuesByEntityId;
	public String getDBReferencePropValuesByEntityId;
	public String getDBObjectPropValuesByEntityId;
	public String getLAStringPropValuesByEntityId;
	public String getLAIntegerPropValuesByEntityId;
	public String getLALongPropValuesByEntityId;
	public String getLADoublePropValuesByEntityId;
	public String getLATimestampPropValuesByEntityId;
	public String getLAReferencePropValuesByEntityId;
	public String getLAObjectPropValuesByEntityId;
	public String orderByPropertyNameInGetProperties;
	public String findDBEntityGeneral;
	public String findStringPropertyForEntities;
	public String findLongPropertyForEntities;
	public String findDoublePropertyForEntities;
	public String findIntegerPropertyForEntities;
	public String findTimestampPropertyForEntities;
	public String findReferencePropertyForEntities;
	public String findDBPropertyIdIn;
	public String findSpecificPropertyForEntitiesOrderBy;
	public String getAllSupportedPropertyTypes;
	public String getLAAllSupportedPropertyTypes;
	public String findAllStringPropertiesForEntity;
	public String findAllLongPropertiesForEntity;
	public String findAllDoublePropertiesForEntity;
	public String findAllIntegerPropertiesForEntity;
	public String findAllTimestampPropertiesForEntity;
	public String findAllReferencePropertiesForEntity;
	public String findAllBlobPropertiesForEntity;
	public String orderByPropId;
	public String findAllPropertiesForEntity;
	public String findAllStringPropertiesForLAEntity;
	public String findAllLongPropertiesForLAEntity;
	public String findAllDoublePropertiesForLAEntity;
	public String findAllIntegerPropertiesForLAEntity;
	public String findAllTimestampPropertiesForLAEntity;
	public String findAllReferencePropertiesForLAEntity;
	public String findAllBlobPropertiesForLAEntity;
	public String findAllPropertiesForLAEntity;
	public String createDBProperty;
	public String createDBPropertyEntity;
	public String createDBCompositeRelation;
	public String createLAProperty;
	public String createLAPropertyEntity;
	public String createLACompositeRelation;
	public String createFederationEntity;
	public String findFederationEntityByRepositoryAndExternalId;
	public String findFederationEntityByUniqueId;
	public String findFederationEntityByUniqueName;
	public String removeFederationEntityByEntityId;
	public String removeFederationEntityByEntityName;
	public String removeFederationEntityByExternalId;
	public String updateFederationExternalIdByUniqueId;
	public String updateFederationUniqueNameByUniqueId;
	public String findFederationEntitiesByReposIdAndExtIds;
	public String findFederationEntitiesByUniqueIds;
	public String findDBEntityIdByTruncUniqueName;
	public String findDBEntityIdByUniqueId;
	public String selectDBKeys;
	public String selectDBKeysByTable;
	public String selectLAKeys;
	public String selectLAKeysByTable;
	public String updateDBKeysByTable;
	public String updateLAKeysByTable;
	public String updateDefaultOrg;
	public String findDBPropId;
	public String getLAPropAttributeForEntitype;
	public String getLAEntitypesForExisting;
	public String getLAEntIdsByPropIdAndEntTypes;
	public String getLAEntIdsWhereClause;
	public String deleteEntityDataFromLAPropValueTable;
	public String whereINEIdsClause;
	public String andPropIDEqualTo;
	public String unionOfAllEidsFromValueTables;
	public String getEidsForLACleanup;
	public String deleteEntityFromLAIfNoPropValueIsAssociateWith;
	public String selectSchema;
	public String createDBStringValueWithoutKey = "INSERT INTO DBSTRPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE, VALUE_KEY) VALUES (  ((SELECT coalesce(MAX(VALUE_ID),0) FROM DBSTRPROP))+ 51 , ?, ?, ?, ?, ?, ?, ?)";
	public String createDBLongValueWithoutKey = "INSERT INTO DBLONGPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (((SELECT coalesce(MAX(VALUE_ID),0) FROM DBLONGPROP))+ 51, ?, ?, ?, ?, ?, ?)";
	public String createDBDoubleValueWithoutKey = "INSERT INTO DBDBLPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (((SELECT coalesce(MAX(VALUE_ID),0) FROM DBDBLPROP))+ 51, ?, ?, ?, ?, ?, ?)";
	public String createDBIntegerValueWithoutKey = "INSERT INTO DBINTPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (((SELECT coalesce(MAX(VALUE_ID),0) FROM DBINTPROP))+ 51, ?, ?, ?, ?, ?, ?)";
	public String createDBReferenceValueWithoutKey = "INSERT INTO DBREFPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, REF_UNAME_KEY, REF_UNAME, REF_EXT_ID, REF_FULL_EXT_ID, REF_REPOS_ID) VALUES (((SELECT coalesce(MAX(VALUE_ID),0) FROM DBREFPROP))+ 51, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	public String createDBTimestampValueWithoutKey = "INSERT INTO DBTSPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (((SELECT coalesce(MAX(VALUE_ID),0) FROM DBTSPROP))+ 51, ?, ?, ?, ?, ?, ?)";
	public String createDBBlobValueWithoutKey = "INSERT INTO DBBLOBPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (((SELECT coalesce(MAX(VALUE_ID),0) FROM DBBLOBPROP))+ 51, ?, ?, ?, ?, ?, ?)";
	public String createDBCompositePropertyValueWithoutKey = "INSERT INTO DBCOMPPROP(VALUE_ID, PROP_ID, ENTITY_ID, COMPOSITE_ID, META_VALUE) VALUES (((SELECT coalesce(MAX(VALUE_ID),0) FROM DBCOMPPROP )+ 51, ?, ?, ?, ?)";
	public String createLAStringValueWithoutKey = "INSERT INTO LASTRPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE, VALUE_KEY) VALUES ( ((SELECT coalesce(MAX(VALUE_ID),0) FROM LASTRPROP))+ 51  , ?, ?, ?, ?, ?, ?, ?)";
	public String createLALongValueWithoutKey = "INSERT INTO LALONGPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (  ((SELECT coalesce(MAX(VALUE_ID),0) FROM LALONGPROP))+ 51  , ?, ?, ?, ?, ?, ?)";
	public String createLADoubleValueWithoutKey = "INSERT INTO LADBLPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (  ((SELECT coalesce(MAX(VALUE_ID),0) FROM LADBLPROP))+ 51  , ?, ?, ?, ?, ?, ?)";
	public String createLAIntegerValueWithoutKey = "INSERT INTO LAINTPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (  ((SELECT coalesce(MAX(VALUE_ID),0) FROM LAINTPROP))+ 51  , ?, ?, ?, ?, ?, ?)";
	public String createLAReferenceValueWithoutKey = "INSERT INTO LAREFPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, REF_UNAME_KEY, REF_UNAME, REF_EXT_ID, REF_FULL_EXT_ID, REF_REPOS_ID) VALUES (  ((SELECT coalesce(MAX(VALUE_ID),0) FROM LAREFPROP))+ 51  , ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	public String createLATimestampValueWithoutKey = "INSERT INTO LATSPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (  ((SELECT coalesce(MAX(VALUE_ID),0) FROM LATSPROP))+ 51  , ?, ?, ?, ?, ?, ?)";
	public String createLABlobValueWithoutKey = "INSERT INTO LABLOBPROP (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (  ((SELECT coalesce(MAX(VALUE_ID),0) FROM LABLOBPROP))+ 51  , ?, ?, ?, ?, ?, ?)";
	public String createLACompositePropertyValueWithoutKey = "INSERT INTO LACOMPPROP(VALUE_ID, PROP_ID, ENTITY_ID, COMPOSITE_ID, META_VALUE) VALUES ( ((SELECT coalesce(MAX(VALUE_ID),0) FROM LACOMPPROP))+ 51 , ?, ?, ?, ?)";
	public String createLAStringValueWithoutValueId = "INSERT INTO LASTRPROP (PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE, VALUE_KEY) VALUES ( ?, ?, ?, ?, ?, ?, ?)";
	public String createLALongValueWithoutValueId = "INSERT INTO LALONGPROP (PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (   ?, ?, ?, ?, ?, ?)";
	public String createLADoubleValueWithoutValueId = "INSERT INTO LADBLPROP (PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (   ?, ?, ?, ?, ?, ?)";
	public String createLAIntegerValueWithoutValueId = "INSERT INTO LAINTPROP ( PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (  ?, ?, ?, ?, ?, ?)";
	public String createLAReferenceValueWithoutValueId = "INSERT INTO LAREFPROP (PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, REF_UNAME_KEY, REF_UNAME, REF_EXT_ID, REF_FULL_EXT_ID, REF_REPOS_ID) VALUES (  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	public String createLATimestampValueWithoutValueId = "INSERT INTO LATSPROP (PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (   ?, ?, ?, ?, ?, ?)";
	public String createLABlobValueWithoutValueId = "INSERT INTO LABLOBPROP (PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (   ?, ?, ?, ?, ?, ?)";
	public String createLACompositePropertyValueWithoutValueId = "INSERT INTO LACOMPPROP( PROP_ID, ENTITY_ID, COMPOSITE_ID, META_VALUE) VALUES (  ?, ?, ?, ?)";

	public QuerySet() {
		this.initSQL();
	}

	public QuerySet(String var1) {
		this.prependSchema(var1);
		this.initSQL();
	}

	public void prependSchema(String var1) {
		if (var1 != null && var1.trim().length() >= 1) {
			String var2 = var1.trim() + ".";
			this.DBENTITY = var2 + "DBENTITY";
			this.DBENTREL = var2 + "DBENTREL";
			this.DBSTRPROP = var2 + "DBSTRPROP";
			this.DBLONGPROP = var2 + "DBLONGPROP";
			this.DBINTPROP = var2 + "DBINTPROP";
			this.DBREFPROP = var2 + "DBREFPROP";
			this.DBTSPROP = var2 + "DBTSPROP";
			this.DBBLOBPROP = var2 + "DBBLOBPROP";
			this.DBCOMPPROP = var2 + "DBCOMPPROP";
			this.DBPROPENT = var2 + "DBPROPENT";
			this.DBPROPTYPE = var2 + "DBPROPTYPE";
			this.DBACCT = var2 + "DBACCT";
			this.DBDBLPROP = var2 + "DBDBLPROP";
			this.DBGRPREL = var2 + "DBGRPREL";
			this.DBPROP = var2 + "DBPROP";
			this.LACOMPREL = var2 + "LACOMPREL";
			this.DBCOMPREL = var2 + "DBCOMPREL";
			this.DBKEYS = var2 + "DBKEYS";
			this.LAKEYS = var2 + "LAKEYS";
			this.FEDENTITY = var2 + "FEDENTITY";
			this.LAPROP = var2 + "LAPROP";
			this.LAENTITY = var2 + "LAENTITY";
			this.LASTRPROP = var2 + "LASTRPROP";
			this.LALONGPROP = var2 + "LALONGPROP";
			this.LADBLPROP = var2 + "LADBLPROP";
			this.LAINTPROP = var2 + "LAINTPROP";
			this.LAREFPROP = var2 + "LAREFPROP";
			this.LATSPROP = var2 + "LATSPROP";
			this.LABLOBPROP = var2 + "LABLOBPROP";
			this.LACOMPPROP = var2 + "LACOMPPROP";
			this.LAPROPENT = var2 + "LAPROPENT";
		}
	}

	public void initSQL() {
		this.selectSchema = "SELECT SCHEMANAME FROM SYSCAT.SCHEMATA WHERE SCHEMANAME = ? ";
		this.createDBEntity = "INSERT INTO " + this.DBENTITY
				+ " (ENTITY_ID, ENTITY_TYPE, UNIQUE_ID, UNIQUE_NAME, UNIQUE_NAME_KEY) VALUES (?, ?, ?, ?, ?)";
		this.createEntityRelation = "INSERT INTO " + this.DBENTREL + "(DESCENDANT_ID, ANCESTOR_ID) VALUES (?, ?)";
		this.createDBStringValue = "INSERT INTO " + this.DBSTRPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE, VALUE_KEY) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		this.createDBLongValue = "INSERT INTO " + this.DBLONGPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createDBDoubleValue = "INSERT INTO " + this.DBDBLPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createDBIntegerValue = "INSERT INTO " + this.DBINTPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createDBReferenceValue = "INSERT INTO " + this.DBREFPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, REF_UNAME_KEY, REF_UNAME, REF_EXT_ID, REF_FULL_EXT_ID, REF_REPOS_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		this.createDBTimestampValue = "INSERT INTO " + this.DBTSPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createDBBlobValue = "INSERT INTO " + this.DBBLOBPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createDBCompositePropertyValue = "INSERT INTO " + this.DBCOMPPROP
				+ "(VALUE_ID, PROP_ID, ENTITY_ID, COMPOSITE_ID, META_VALUE) VALUES (?, ?, ?, ?, ?)";
		this.createLAEntity = "INSERT INTO " + this.LAENTITY
				+ "(ENTITY_ID, ENTITY_TYPE, EXT_ID, FULL_EXT_ID, REPOS_ID) VALUES (?, ?, ?, ?, ?)";
		this.createLAStringValue = "INSERT INTO " + this.LASTRPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE, VALUE_KEY) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		this.createLALongValue = "INSERT INTO " + this.LALONGPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createLADoubleValue = "INSERT INTO " + this.LADBLPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createLAIntegerValue = "INSERT INTO " + this.LAINTPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createLAReferenceValue = "INSERT INTO " + this.LAREFPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, REF_UNAME_KEY, REF_UNAME, REF_EXT_ID, REF_FULL_EXT_ID, REF_REPOS_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		this.createLATimestampValue = "INSERT INTO " + this.LATSPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createLABlobValue = "INSERT INTO " + this.LABLOBPROP
				+ " (VALUE_ID, PROP_ID, TYPE_ID, ENTITY_ID, COMPOSITE, META_VALUE, PROPVALUE) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.createLACompositePropertyValue = "INSERT INTO " + this.LACOMPPROP
				+ "(VALUE_ID, PROP_ID, ENTITY_ID, COMPOSITE_ID, META_VALUE) VALUES (?, ?, ?, ?, ?)";
		this.createAccount = "INSERT INTO " + this.DBACCT
				+ " (ENTITY_ID, PASSWORD, SALT, EXT_ID, FULL_EXT_ID, REPOS_ID) VALUES (?, ?, ?, ?, ?, ?)";
		this.createDBGrpRelation = "INSERT INTO " + this.DBGRPREL
				+ " (GRP_ID, REPOS_ID, EXT_ID, FULL_EXT_ID) VALUES (?, ?, ?, ?)";
		this.createPropertyDefintion = "INSERT INTO " + this.DBPROP
				+ " (PROP_ID, NAME, TYPE_ID, META_NAME, IS_COMPOSITE, VALUE_LENGTH, READ_ONLY, MULTI_VALUED, CASE_EXACT_MATCH, CLASSNAME, DESCRIPTION, APPLICATION_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		this.createLAPropertyDefintion = "INSERT INTO " + this.LAPROP
				+ "(PROP_ID, NAME, TYPE_ID, META_NAME, IS_COMPOSITE, VALUE_LENGTH, READ_ONLY, MULTI_VALUED, CASE_EXACT_MATCH, CLASSNAME, DESCRIPTION, APPLICATION_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		this.createPropertyEntity = "INSERT INTO " + this.DBPROPENT
				+ " (PROP_ID, APPLICABLE_ENTTYPE, REQUIRED_ENTTYPE) VALUES (?, ?, ?)";
		this.removeDBGroupRelationMain = "DELETE FROM " + this.DBGRPREL + " WHERE (EXT_ID = ? AND REPOS_ID = ?)";
		this.orRemoveDBGroupRelationByExtIdAndReposId = " OR (EXT_ID = ? AND REPOS_ID = ?)";
		this.deleteDBEntityWithDescendants = "DELETE FROM " + this.DBENTITY + " WHERE UNIQUE_NAME_KEY LIKE ?";
		this.deleteAllDBGrpRelationForMember = "DELETE FROM " + this.DBGRPREL + " WHERE REPOS_ID = ? AND EXT_ID = ?";
		this.unassignGrpRelation = "DELETE FROM " + this.DBGRPREL + " WHERE GRP_ID = ? AND REPOS_ID = ? AND EXT_ID = ?";
		this.deleteAllDBGrpRelationForGroup = "DELETE FROM " + this.DBGRPREL + " WHERE GRP_ID = ?";
		this.deleteLAEntity = "DELETE FROM " + this.LAENTITY + " WHERE EXT_ID = ? AND REPOS_ID = ?";
		this.deletePropertiesFromDBStringProp = "DELETE FROM " + this.DBSTRPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromDBIntegerProp = "DELETE FROM " + this.DBINTPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromDBDoubleProp = "DELETE FROM " + this.DBDBLPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromDBBlobProp = "DELETE FROM " + this.DBBLOBPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromDBTimestampProp = "DELETE FROM " + this.DBTSPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromDBLongProp = "DELETE FROM " + this.DBLONGPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromDBReferenceProp = "DELETE FROM " + this.DBREFPROP + " WHERE PROP_ID IN (";
		this.entityIDEquals = " ENTITY_ID = ? ";
		this.deletePropertiesFromLAStringProp = "DELETE FROM " + this.LASTRPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromLAIntegerProp = "DELETE FROM " + this.LAINTPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromLADoubleProp = "DELETE FROM " + this.LADBLPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromLABlobProp = "DELETE FROM " + this.LABLOBPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromLATimestampProp = "DELETE FROM " + this.LATSPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromLALongProp = "DELETE FROM " + this.LALONGPROP + " WHERE PROP_ID IN (";
		this.deletePropertiesFromLAReferenceProp = "DELETE FROM " + this.LAREFPROP + " WHERE PROP_ID IN (";
		this.deleteDBCompositeProperties = "DELETE FROM " + this.DBCOMPPROP + " WHERE ENTITY_ID = ? AND PROP_ID IN (";
		this.deleteLACompositeProperties = "DELETE FROM " + this.LACOMPPROP + " WHERE ENTITY_ID = ? AND PROP_ID IN (";
		this.updateEntityUniqueName = "UPDATE " + this.DBENTITY
				+ " SET UNIQUE_NAME = ?, UNIQUE_NAME_KEY = ? WHERE ENTITY_ID = ?";
		this.updatePrincipalNamePassword = "UPDATE " + this.DBACCT
				+ " SET PRINCIPAL_NAME = ?, PASSWORD = ?, SALT = ? WHERE ENTITY_ID = ?";
		this.updatePrincipalName = "UPDATE " + this.DBACCT + " SET PRINCIPAL_NAME = ? WHERE ENTITY_ID = ?";
		this.updateDBAcct = "UPDATE " + this.DBACCT
				+ " SET PASSWORD = ?, SALT = ?, EXT_ID = ?, FULL_EXT_ID = ?, REPOS_ID = ? WHERE ENTITY_ID = ?";
		this.updatePrincipal = "UPDATE " + this.DBACCT + " SET EXT_ID = ?, REPOS_ID = ? WHERE ENTITY_ID = ?";
		this.updateDBStringValue = "UPDATE " + this.DBSTRPROP
				+ " SET PROPVALUE = ?, VALUE_KEY= ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateDBLongValue = "UPDATE " + this.DBLONGPROP + " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateDBDoubleValue = "UPDATE " + this.DBDBLPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateDBIntegerValue = "UPDATE " + this.DBINTPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateDBTimestampValue = "UPDATE " + this.DBTSPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateDBReferenceValue = "UPDATE " + this.DBREFPROP
				+ " SET REF_UNAME_KEY = ?, REF_UNAME = ?, REF_EXT_ID = ?, REF_FULL_EXT_ID = ?, REF_REPOS_ID WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateDBBlobValue = "UPDATE " + this.DBBLOBPROP + " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateLAStringValue = "UPDATE " + this.LASTRPROP
				+ " SET PROPVALUE = ?, VALUE_KEY= ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateLALongValue = "UPDATE " + this.LALONGPROP + " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateLADoubleValue = "UPDATE " + this.LADBLPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateLAIntegerValue = "UPDATE " + this.LAINTPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateLATimestampValue = "UPDATE " + this.LATSPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateLAReferenceValue = "UPDATE " + this.LAREFPROP
				+ " SET REF_UNAME_KEY = ?, REF_UNAME = ?, REF_EXT_ID = ?, REF_FULL_EXT_ID = ?, REF_REPOS_ID WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateLABlobValue = "UPDATE " + this.LABLOBPROP + " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ?";
		this.updateDBStringValueWithOldValue = "UPDATE " + this.DBSTRPROP
				+ " SET PROPVALUE = ?, VALUE_KEY= ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND VALUE_KEY = ?";
		this.updateDBLongValueWithOldValue = "UPDATE " + this.DBLONGPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.updateDBDoubleValueWithOldValue = "UPDATE " + this.DBDBLPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.updateDBIntegerValueWithOldValue = "UPDATE " + this.DBINTPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.updateDBTimestampValueWithOldValue = "UPDATE " + this.DBTSPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.updateDBReferenceValueWithOldValue = "UPDATE " + this.DBREFPROP
				+ " SET REF_UNAME_KEY = ?, REF_UNAME = ?, REF_EXT_ID = ?, REF_FULL_EXT_ID = ?, REF_REPOS_ID = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND REF_EXT_ID = ? AND REF_REPOS_ID = ?";
		this.updateDBBlobValueWithOldValue = "UPDATE " + this.DBBLOBPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.updateLAStringValueWithOldValue = "UPDATE " + this.LASTRPROP
				+ " SET PROPVALUE = ?, VALUE_KEY= ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND VALUE_KEY = ?";
		this.updateLALongValueWithOldValue = "UPDATE " + this.LALONGPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.updateLADoubleValueWithOldValue = "UPDATE " + this.LADBLPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.updateLAIntegerValueWithOldValue = "UPDATE " + this.LAINTPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.updateLATimestampValueWithOldValue = "UPDATE " + this.LATSPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.updateLAReferenceValueWithOldValue = "UPDATE " + this.LAREFPROP
				+ " SET REF_UNAME_KEY = ?, REF_UNAME = ?, REF_EXT_ID = ?, REF_FULL_EXT_ID = ?, REF_REPOS_ID = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND REF_EXT_ID = ? AND REF_REPOS_ID = ?";
		this.updateLABlobValueWithOldValue = "UPDATE " + this.LABLOBPROP
				+ " SET PROPVALUE = ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND PROPVALUE = ?";
		this.searchFromDBEntity = " FROM " + this.DBENTITY + " ";
		this.searchWhere1Equals1 = " WHERE 1=1 ";
		this.dotColumnValue = ".PROPVALUE";
		this.dotColumnValueKey = ".VALUE_KEY";
		this.dotColumnRefUnameKey = ".REF_UNAME_KEY";
		this.dbTableStringValue = " " + this.DBSTRPROP + " ";
		this.dbTableIntegerValue = " " + this.DBINTPROP + " ";
		this.dbTableLongValue = " " + this.DBLONGPROP + " ";
		this.dbTableDoubleValue = " " + this.DBDBLPROP + " ";
		this.dbTableTimeStampValue = " " + this.DBTSPROP + " ";
		this.dbTableReferenceValue = " " + this.DBREFPROP + " ";
		this.searchDBEntityJoinCondition = ".ENTITY_ID = " + this.DBENTITY + ".ENTITY_ID AND ";
		this.searchPropertyIdCondition = ".PROP_ID = ? AND ";
		this.searchDBEntitySubSelect = " " + this.DBENTITY + ".ENTITY_ID IN ( SELECT " + this.DBENTITY
				+ ".ENTITY_ID AS ENTITY_ID ";
		this.searchDBEntityTypeCondition = "" + this.DBENTITY + ".ENTITY_TYPE='";
		this.searchDBNoResultPropertyWhere = " SELECT ENTITY_ID, UNIQUE_NAME, UNIQUE_ID, ENTITY_TYPE  FROM "
				+ this.DBENTITY + " WHERE ";
		this.getDBObjectPropertyValuesByEntityIds = " SELECT " + this.DBBLOBPROP + ".ENTITY_ID, " + this.DBPROP
				+ ".NAME, " + this.DBPROP + ".MULTI_VALUED, " + this.DBBLOBPROP + ".PROPVALUE FROM " + this.DBBLOBPROP
				+ ", " + this.DBPROP + " WHERE " + this.DBPROP + ".PROP_ID = " + this.DBBLOBPROP + ".PROP_ID AND "
				+ this.DBBLOBPROP + ".ENTITY_ID IN ( ";
		this.andDBObjectPropertyIdInWithLeftBracket = " AND " + this.DBBLOBPROP + ".PROP_ID IN ( ";
		this.andDBCompositePropertyIdInWithLeftBracket = " AND " + this.DBCOMPPROP + ".PROP_ID IN (";
		this.andDBCompositeEntityIdInWithLeftBracket = " AND " + this.DBCOMPPROP + ".ENTITY_ID IN (";
		this.findCompositePropertiesForDBEntities = "SELECT -100 AS VALUEINDEX, 0 AS DATATYPE, " + this.DBCOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.DBCOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME, "
				+ this.DBCOMPPROP + ".COMPOSITE_ID, " + this.DBPROP + ".PROP_ID,  " + this.DBPROP + ".NAME, "
				+ this.DBPROP
				+ ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE,  '' AS REF_EXT_ID, '' AS REF_REPOS_ID,  '' AS REF_UNAME_KEY FROM "
				+ this.DBPROP + ", " + this.DBCOMPPROP + " CHILD, " + this.DBCOMPPROP + ", " + this.DBPROP
				+ " COMPOSITE WHERE " + this.DBPROP + ".PROP_ID = CHILD.PROP_ID AND COMPOSITE.PROP_ID = "
				+ this.DBCOMPPROP + ".PROP_ID ";
		this.findStringCompositePropertiessForDBEntities = "SELECT 10 AS VALUEINDEX, 0 AS DATATYPE, " + this.DBCOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.DBCOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  "
				+ this.DBCOMPPROP + ".COMPOSITE_ID, " + this.DBPROP + ".PROP_ID,  " + this.DBPROP + ".NAME, "
				+ this.DBPROP + ".MULTI_VALUED AS MULTI_VALUED, " + this.DBSTRPROP
				+ ".PROPVALUE AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.DBSTRPROP + ", " + this.DBPROP + ", " + this.DBCOMPPROP + ", " + this.DBPROP
				+ " COMPOSITE WHERE " + this.DBSTRPROP + ".PROP_ID = " + this.DBPROP + ".PROP_ID AND " + this.DBCOMPPROP
				+ ".VALUE_ID = " + this.DBSTRPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.DBCOMPPROP
				+ ".PROP_ID AND " + this.DBSTRPROP + ".ENTITY_ID = " + this.DBCOMPPROP + ".ENTITY_ID ";
		this.findLongCompositePropertiessForDBEntities = "SELECT 11 AS VALUEINDEX, 1 AS DATATYPE, " + this.DBCOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.DBCOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  "
				+ this.DBCOMPPROP + ".COMPOSITE_ID, " + this.DBPROP + ".PROP_ID,  " + this.DBPROP + ".NAME, "
				+ this.DBPROP + ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, " + this.DBLONGPROP
				+ ".PROPVALUE AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.DBLONGPROP + ", " + this.DBPROP + ", " + this.DBCOMPPROP + ", " + this.DBPROP
				+ " COMPOSITE WHERE " + this.DBLONGPROP + ".PROP_ID = " + this.DBPROP + ".PROP_ID AND "
				+ this.DBCOMPPROP + ".VALUE_ID = " + this.DBLONGPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = "
				+ this.DBCOMPPROP + ".PROP_ID AND " + this.DBLONGPROP + ".ENTITY_ID = " + this.DBCOMPPROP
				+ ".ENTITY_ID ";
		this.findDoubleCompositePropertiessForDBEntities = "SELECT 12 AS VALUEINDEX, 2 AS DATATYPE, " + this.DBCOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.DBCOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  "
				+ this.DBCOMPPROP + ".COMPOSITE_ID, " + this.DBPROP + ".PROP_ID,  " + this.DBPROP + ".NAME, "
				+ this.DBPROP + ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE,  " + this.DBDBLPROP
				+ ".PROPVALUE AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.DBDBLPROP + ", " + this.DBPROP + ", " + this.DBCOMPPROP + ", " + this.DBPROP
				+ " COMPOSITE WHERE " + this.DBDBLPROP + ".PROP_ID = " + this.DBPROP + ".PROP_ID AND " + this.DBCOMPPROP
				+ ".VALUE_ID = " + this.DBDBLPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.DBCOMPPROP
				+ ".PROP_ID AND " + this.DBDBLPROP + ".ENTITY_ID = " + this.DBCOMPPROP + ".ENTITY_ID ";
		this.findIntegerCompositePropertiessForDBEntities = "SELECT 13 AS VALUEINDEX, 3 AS DATATYPE, " + this.DBCOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.DBCOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  "
				+ this.DBCOMPPROP + ".COMPOSITE_ID, " + this.DBPROP + ".PROP_ID,  " + this.DBPROP + ".NAME, "
				+ this.DBPROP + ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE,  0 AS DOUBLEVALUE, "
				+ this.DBINTPROP
				+ ".PROPVALUE AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.DBINTPROP + ", " + this.DBPROP + ", " + this.DBCOMPPROP + ", " + this.DBPROP
				+ " COMPOSITE WHERE " + this.DBINTPROP + ".PROP_ID = " + this.DBPROP + ".PROP_ID AND " + this.DBCOMPPROP
				+ ".VALUE_ID = " + this.DBINTPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.DBCOMPPROP
				+ ".PROP_ID AND " + this.DBINTPROP + ".ENTITY_ID = " + this.DBCOMPPROP + ".ENTITY_ID ";
		this.findTimestampCompositePropertiessForDBEntities = "SELECT 14 AS VALUEINDEX, 4 AS DATATYPE, "
				+ this.DBCOMPPROP + ".ENTITY_ID AS ENTITY_ID, " + this.DBCOMPPROP
				+ ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  " + this.DBCOMPPROP + ".COMPOSITE_ID, " + this.DBPROP
				+ ".PROP_ID,  " + this.DBPROP + ".NAME, " + this.DBPROP
				+ ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE,  0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, "
				+ this.DBTSPROP
				+ ".PROPVALUE AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.DBTSPROP + ", " + this.DBPROP + ", " + this.DBCOMPPROP + ", " + this.DBPROP + " COMPOSITE WHERE "
				+ this.DBTSPROP + ".PROP_ID = " + this.DBPROP + ".PROP_ID AND " + this.DBCOMPPROP + ".VALUE_ID = "
				+ this.DBTSPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.DBCOMPPROP + ".PROP_ID AND "
				+ this.DBTSPROP + ".ENTITY_ID = " + this.DBCOMPPROP + ".ENTITY_ID ";
		this.findReferenceCompositePropertiessForDBEntities = "SELECT 15 AS VALUEINDEX, 5 AS DATATYPE, "
				+ this.DBCOMPPROP + ".ENTITY_ID AS ENTITY_ID, " + this.DBCOMPPROP
				+ ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  " + this.DBCOMPPROP + ".COMPOSITE_ID, " + this.DBPROP
				+ ".PROP_ID,  " + this.DBPROP + ".NAME, " + this.DBPROP
				+ ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE,  0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, "
				+ this.DBREFPROP + ".REF_FULL_EXT_ID AS REF_EXT_ID, " + this.DBREFPROP
				+ ".REF_REPOS_ID AS REF_REPOS_ID, " + this.DBREFPROP + ".REF_UNAME AS REF_UNAME_KEY  FROM "
				+ this.DBREFPROP + ", " + this.DBPROP + ", " + this.DBCOMPPROP + ", " + this.DBPROP
				+ " COMPOSITE WHERE " + this.DBREFPROP + ".PROP_ID = " + this.DBPROP + ".PROP_ID AND " + this.DBCOMPPROP
				+ ".VALUE_ID = " + this.DBREFPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.DBCOMPPROP
				+ ".PROP_ID AND " + this.DBREFPROP + ".ENTITY_ID = " + this.DBCOMPPROP + ".ENTITY_ID ";
		this.searchFromDBEntityAndDBTableStringValue = " FROM " + this.DBENTITY + ", " + this.DBSTRPROP + " ";
		this.isMemberinImmediateGroup = "SELECT * FROM " + this.DBGRPREL
				+ " WHERE GRP_ID = ? AND EXT_ID = ? AND REPOS_ID = ?";
		this.searchFromLAEntity = " FROM " + this.LAENTITY + " ";
		this.laTableStringValue = " " + this.LASTRPROP + " ";
		this.laTableIntegerValue = " " + this.LAINTPROP + " ";
		this.laTableLongValue = " " + this.LALONGPROP + " ";
		this.laTableDoubleValue = " " + this.LADBLPROP + " ";
		this.laTableTimeStampValue = " " + this.LATSPROP + " ";
		this.laTableReferenceValue = " " + this.LAREFPROP + " ";
		this.searchLAEntityJoinCondition = ".ENTITY_ID = " + this.LAENTITY + ".ENTITY_ID AND ";
		this.SearchLAEntitySubSelect = " " + this.LAENTITY + ".ENTITY_ID IN ( SELECT " + this.LAENTITY
				+ ".ENTITY_ID AS ENTITY_ID ";
		this.searchLAEntityTypeCondition = "" + this.LAENTITY + ".ENTITY_TYPE='";
		this.searchLANoResultPropertyWhere = " SELECT ENTITY_TYPE, EXT_ID, REPOS_ID FROM " + this.LAENTITY + " WHERE ";
		this.findLAEntityGeneral = "SELECT -100  AS VALUEINDEX, 0 AS DATATYPE, " + this.LAENTITY
				+ ".ENTITY_ID AS ENTITY_ID, ENTITY_TYPE, FULL_EXT_ID,REPOS_ID, 0 AS PROP_ID, '' AS NAME, 0 AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE,  0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_UNAME_KEY, '' AS REF_EXT_ID, '' AS REF_REPOS_ID  FROM "
				+ this.LAENTITY + " WHERE 1=1 ";
		this.findLAPropertyIdIn = " AND " + this.LAPROP + ".PROP_ID IN (";
		this.findStringPropertyForLAEntities = "SELECT 10  AS VALUEINDEX, 0 AS DATATYPE, " + this.LAENTITY
				+ ".ENTITY_ID AS ENTITY_ID, ENTITY_TYPE, FULL_EXT_ID, REPOS_ID, " + this.LAPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, " + this.LASTRPROP
				+ ".PROPVALUE AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LAPROP + ", " + this.LASTRPROP + ", " + this.LAENTITY + " WHERE " + this.LAENTITY
				+ ".ENTITY_ID = " + this.LASTRPROP + ".ENTITY_ID AND " + this.LASTRPROP + ".PROP_ID = " + this.LAPROP
				+ ".PROP_ID ";
		this.findLongPropertyForLAEntities = "SELECT 11  AS VALUEINDEX, 1 AS DATATYPE, " + this.LAENTITY
				+ ".ENTITY_ID AS ENTITY_ID, ENTITY_TYPE, FULL_EXT_ID, REPOS_ID, " + this.LAPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, '' AS STRINGVALUE, " + this.LALONGPROP
				+ ".PROPVALUE AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LAPROP + ", " + this.LALONGPROP + ", " + this.LAENTITY + " WHERE " + this.LAENTITY
				+ ".ENTITY_ID = " + this.LALONGPROP + ".ENTITY_ID AND " + this.LALONGPROP + ".PROP_ID = " + this.LAPROP
				+ ".PROP_ID ";
		this.findDoublePropertyForLAEntities = "SELECT 12  AS VALUEINDEX, 2 AS DATATYPE, " + this.LAENTITY
				+ ".ENTITY_ID AS ENTITY_ID, ENTITY_TYPE, FULL_EXT_ID, REPOS_ID, " + this.LAPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, " + this.LADBLPROP
				+ ".PROPVALUE AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LAPROP + ", " + this.LADBLPROP + ", " + this.LAENTITY + " WHERE " + this.LAENTITY
				+ ".ENTITY_ID = " + this.LADBLPROP + ".ENTITY_ID AND " + this.LADBLPROP + ".PROP_ID = " + this.LAPROP
				+ ".PROP_ID ";
		this.findIntegerPropertyForLAEntities = "SELECT 13  AS VALUEINDEX, 3 AS DATATYPE, " + this.LAENTITY
				+ ".ENTITY_ID AS ENTITY_ID, ENTITY_TYPE, FULL_EXT_ID, REPOS_ID, " + this.LAPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, "
				+ this.LAINTPROP
				+ ".PROPVALUE AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LAPROP + ", " + this.LAINTPROP + ", " + this.LAENTITY + " WHERE " + this.LAENTITY
				+ ".ENTITY_ID = " + this.LAINTPROP + ".ENTITY_ID AND " + this.LAINTPROP + ".PROP_ID = " + this.LAPROP
				+ ".PROP_ID ";
		this.findTimestampPropertyForLAEntities = "SELECT 14  AS VALUEINDEX, 4 AS DATATYPE, " + this.LAENTITY
				+ ".ENTITY_ID AS ENTITY_ID, ENTITY_TYPE, FULL_EXT_ID, REPOS_ID, " + this.LAPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, "
				+ this.LATSPROP
				+ ".PROPVALUE AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LAPROP + ", " + this.LATSPROP + ", " + this.LAENTITY + " WHERE " + this.LAENTITY
				+ ".ENTITY_ID = " + this.LATSPROP + ".ENTITY_ID AND " + this.LATSPROP + ".PROP_ID = " + this.LAPROP
				+ ".PROP_ID ";
		this.findReferencePropertyForLAEntities = "SELECT 15  AS VALUEINDEX, 5 AS DATATYPE, " + this.LAENTITY
				+ ".ENTITY_ID AS ENTITY_ID, ENTITY_TYPE, FULL_EXT_ID, REPOS_ID, " + this.LAPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, "
				+ this.LAREFPROP + ".REF_UNAME AS REF_UNAME_KEY, " + this.LAREFPROP + ".REF_REPOS_ID AS REF_REPOS_ID, "
				+ this.LAREFPROP + ".REF_FULL_EXT_ID AS REF_EXT_ID  FROM " + this.LAPROP + ", " + this.LAREFPROP + ", "
				+ this.LAENTITY + " WHERE " + this.LAENTITY + ".ENTITY_ID = " + this.LAREFPROP + ".ENTITY_ID AND "
				+ this.LAREFPROP + ".PROP_ID = " + this.LAPROP + ".PROP_ID ";
		this.findLASpecificPropertyForEntitiesOrderBy = " ORDER BY ENTITY_ID, PROP_ID, VALUEINDEX";
		this.getLAObjectPropertyValuesByEntityIds = " SELECT " + this.LABLOBPROP + ".ENTITY_ID, " + this.LAPROP
				+ ".NAME, " + this.LAPROP + ".MULTI_VALUED, " + this.LABLOBPROP + ".PROPVALUE FROM " + this.LABLOBPROP
				+ ", " + this.LAPROP + " WHERE " + this.LAPROP + ".PROP_ID = " + this.LABLOBPROP + ".PROP_ID AND "
				+ this.LABLOBPROP + ".ENTITY_ID IN ( ";
		this.andLAObjectPropertyIdInWithLeftBracket = " AND " + this.LABLOBPROP + ".PROP_ID IN ( ";
		this.andLACompositePropertyIdInWithLeftBracket = " AND " + this.LACOMPPROP + ".PROP_ID IN (";
		this.andLACompositeEntityIdInWithLeftBracket = " AND " + this.LACOMPPROP + ".ENTITY_ID IN (";
		this.findCompositePropertiesOrderBy = " ORDER BY ENTITY_ID, VALUE_ID, COMPOSITE_ID, PROP_ID,  VALUEINDEX";
		this.findCompositePropertiesForLAEntities = "SELECT -100 AS VALUEINDEX, 0 AS DATATYPE, " + this.LACOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.LACOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME, "
				+ this.LACOMPPROP + ".COMPOSITE_ID, " + this.LAPROP + ".PROP_ID,  " + this.LAPROP + ".NAME, "
				+ this.LAPROP
				+ ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE,  '' AS REF_EXT_ID, '' AS REF_REPOS_ID,  '' AS REF_UNAME_KEY FROM "
				+ this.LAPROP + ", " + this.LACOMPPROP + " CHILD, " + this.LACOMPPROP + ", " + this.LAPROP
				+ " COMPOSITE WHERE " + this.LAPROP + ".PROP_ID = CHILD.PROP_ID AND COMPOSITE.PROP_ID = "
				+ this.LACOMPPROP + ".PROP_ID ";
		this.findStringCompositePropertiessForLAEntities = "SELECT 10 AS VALUEINDEX, 0 AS DATATYPE, " + this.LACOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.LACOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  "
				+ this.LACOMPPROP + ".COMPOSITE_ID, " + this.LAPROP + ".PROP_ID,  " + this.LAPROP + ".NAME, "
				+ this.LAPROP + ".MULTI_VALUED AS MULTI_VALUED, " + this.LASTRPROP
				+ ".PROPVALUE AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LASTRPROP + ", " + this.LAPROP + ", " + this.LACOMPPROP + ", " + this.LAPROP
				+ " COMPOSITE WHERE " + this.LASTRPROP + ".PROP_ID = " + this.LAPROP + ".PROP_ID AND " + this.LACOMPPROP
				+ ".VALUE_ID = " + this.LASTRPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.LACOMPPROP
				+ ".PROP_ID AND " + this.LASTRPROP + ".ENTITY_ID = " + this.LACOMPPROP + ".ENTITY_ID ";
		this.findLongCompositePropertiessForLAEntities = "SELECT 11 AS VALUEINDEX, 1 AS DATATYPE, " + this.LACOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.LACOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  "
				+ this.LACOMPPROP + ".COMPOSITE_ID, " + this.LAPROP + ".PROP_ID,  " + this.LAPROP + ".NAME, "
				+ this.LAPROP + ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, " + this.LALONGPROP
				+ ".PROPVALUE AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LALONGPROP + ", " + this.LAPROP + ", " + this.LACOMPPROP + ", " + this.LAPROP
				+ " COMPOSITE WHERE " + this.LALONGPROP + ".PROP_ID = " + this.LAPROP + ".PROP_ID AND "
				+ this.LACOMPPROP + ".VALUE_ID = " + this.LALONGPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = "
				+ this.LACOMPPROP + ".PROP_ID AND " + this.LALONGPROP + ".ENTITY_ID = " + this.LACOMPPROP
				+ ".ENTITY_ID ";
		this.findDoubleCompositePropertiessForLAEntities = "SELECT 12 AS VALUEINDEX, 2 AS DATATYPE, " + this.LACOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.LACOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  "
				+ this.LACOMPPROP + ".COMPOSITE_ID, " + this.LAPROP + ".PROP_ID,  " + this.LAPROP + ".NAME, "
				+ this.LAPROP + ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE,  " + this.LADBLPROP
				+ ".PROPVALUE AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LADBLPROP + ", " + this.LAPROP + ", " + this.LACOMPPROP + ", " + this.LAPROP
				+ " COMPOSITE WHERE " + this.LADBLPROP + ".PROP_ID = " + this.LAPROP + ".PROP_ID AND " + this.LACOMPPROP
				+ ".VALUE_ID = " + this.LADBLPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.LACOMPPROP
				+ ".PROP_ID AND " + this.LADBLPROP + ".ENTITY_ID = " + this.LACOMPPROP + ".ENTITY_ID ";
		this.findIntegerCompositePropertiessForLAEntities = "SELECT 13 AS VALUEINDEX, 3 AS DATATYPE, " + this.LACOMPPROP
				+ ".ENTITY_ID AS ENTITY_ID, " + this.LACOMPPROP + ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  "
				+ this.LACOMPPROP + ".COMPOSITE_ID, " + this.LAPROP + ".PROP_ID,  " + this.LAPROP + ".NAME, "
				+ this.LAPROP + ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE,  0 AS DOUBLEVALUE, "
				+ this.LAINTPROP
				+ ".PROPVALUE AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LAINTPROP + ", " + this.LAPROP + ", " + this.LACOMPPROP + ", " + this.LAPROP
				+ " COMPOSITE WHERE " + this.LAINTPROP + ".PROP_ID = " + this.LAPROP + ".PROP_ID AND " + this.LACOMPPROP
				+ ".VALUE_ID = " + this.LAINTPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.LACOMPPROP
				+ ".PROP_ID AND " + this.LAINTPROP + ".ENTITY_ID = " + this.LACOMPPROP + ".ENTITY_ID ";
		this.findTimestampCompositePropertiessForLAEntities = "SELECT 14 AS VALUEINDEX, 4 AS DATATYPE, "
				+ this.LACOMPPROP + ".ENTITY_ID AS ENTITY_ID, " + this.LACOMPPROP
				+ ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  " + this.LACOMPPROP + ".COMPOSITE_ID, " + this.LAPROP
				+ ".PROP_ID,  " + this.LAPROP + ".NAME, " + this.LAPROP
				+ ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE,  0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, "
				+ this.LATSPROP
				+ ".PROPVALUE AS TIMESTAMPVALUE, '' AS REF_EXT_ID, '' AS REF_REPOS_ID, '' AS REF_UNAME_KEY  FROM "
				+ this.LATSPROP + ", " + this.LAPROP + ", " + this.LACOMPPROP + ", " + this.LAPROP + " COMPOSITE WHERE "
				+ this.LATSPROP + ".PROP_ID = " + this.LAPROP + ".PROP_ID AND " + this.LACOMPPROP + ".VALUE_ID = "
				+ this.LATSPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.LACOMPPROP + ".PROP_ID AND "
				+ this.LATSPROP + ".ENTITY_ID = " + this.LACOMPPROP + ".ENTITY_ID ";
		this.findReferenceCompositePropertiessForLAEntities = "SELECT 15 AS VALUEINDEX, 5 AS DATATYPE, "
				+ this.LACOMPPROP + ".ENTITY_ID AS ENTITY_ID, " + this.LACOMPPROP
				+ ".VALUE_ID, COMPOSITE.NAME AS COMP_NAME,  " + this.LACOMPPROP + ".COMPOSITE_ID, " + this.LAPROP
				+ ".PROP_ID,  " + this.LAPROP + ".NAME, " + this.LAPROP
				+ ".MULTI_VALUED AS MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE,  0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE, "
				+ this.LAREFPROP + ".REF_FULL_EXT_ID AS REF_EXT_ID, " + this.LAREFPROP
				+ ".REF_REPOS_ID AS REF_REPOS_ID, " + this.LAREFPROP + ".REF_UNAME_KEY AS REF_UNAME_KEY  FROM "
				+ this.LAREFPROP + ", " + this.LAPROP + ", " + this.LACOMPPROP + ", " + this.LAPROP
				+ " COMPOSITE WHERE " + this.LAREFPROP + ".PROP_ID = " + this.LAPROP + ".PROP_ID AND " + this.LACOMPPROP
				+ ".VALUE_ID = " + this.LAREFPROP + ".COMPOSITE AND COMPOSITE.PROP_ID = " + this.LACOMPPROP
				+ ".PROP_ID AND " + this.LAREFPROP + ".ENTITY_ID = " + this.LACOMPPROP + ".ENTITY_ID ";
		this.findDBAllProperties = "SELECT T1.PROP_ID, T1.NAME, T1.TYPE_ID, T1.META_NAME, T1.IS_COMPOSITE, T1.VALUE_LENGTH, T1.READ_ONLY, T1.MULTI_VALUED, T1.CASE_EXACT_MATCH,  T1.CLASSNAME, T1.DESCRIPTION,  T1.APPLICATION_ID, T2.APPLICABLE_ENTTYPE, T2.REQUIRED_ENTTYPE FROM "
				+ this.DBPROP + " T1, " + this.DBPROPENT + " T2 WHERE T1.PROP_ID = T2.PROP_ID ORDER BY T1.PROP_ID";
		this.findLAAllProperties = "SELECT T1.PROP_ID, T1.NAME, T1.TYPE_ID, T1.META_NAME, T1.IS_COMPOSITE, T1.VALUE_LENGTH, T1.READ_ONLY, T1.MULTI_VALUED, T1.CASE_EXACT_MATCH,  T1.CLASSNAME, T1.DESCRIPTION,  T1.APPLICATION_ID, T2.APPLICABLE_ENTTYPE, T2.REQUIRED_ENTTYPE FROM "
				+ this.LAPROP + " T1, " + this.LAPROPENT + " T2 WHERE T1.PROP_ID = T2.PROP_ID ORDER BY T1.PROP_ID";
		this.selectGEntIdwithGNames = "SELECT ENTITY_ID FROM " + this.DBENTITY + " WHERE UNIQUE_NAME_KEY = ?";
		this.selectGEntIdwithGUIDs = "SELECT ENTITY_ID FROM " + this.DBENTITY + " WHERE UNIQUE_ID = ?";
		this.findDescendantsByUniqueNames = "SELECT DESCENDANT_ID FROM " + this.DBENTREL + ", " + this.DBENTITY
				+ " WHERE ANCESTOR_ID = ENTITY_ID AND UNIQUE_NAME_KEY = ?";
		this.findDBEntitysByUniqueNameKeyLike = "SELECT ENTITY_ID, ENTITY_TYPE, UNIQUE_ID, UNIQUE_NAME FROM "
				+ this.DBENTITY + " WHERE UNIQUE_NAME_KEY LIKE ?";
		this.findUniqueIdByUniqueNameKey = "SELECT UNIQUE_ID FROM " + this.DBENTITY + " WHERE UNIQUE_NAME_KEY=?";
		this.findDBAllCompositeProperties = "SELECT T1.COMPOSITE_ID, T1.COMPONENT_ID, T1.IS_REQUIRED, T1.IS_KEY, T2.NAME AS COMPONENT_NAME, T3.NAME AS COMPOSITE_NAME FROM "
				+ this.DBCOMPREL + " T1, " + this.DBPROP + " T2, " + this.DBPROP
				+ " T3 WHERE T1.COMPONENT_ID = T2.PROP_ID AND T1.COMPOSITE_ID = T3.PROP_ID AND T1.COMPOSITE_ID IN ( ";
		this.findDBAllCompositePropertiesOrderBy = " ORDER BY T1.COMPOSITE_ID ";
		this.findLAAllCompositeProperties = "SELECT T1.COMPOSITE_ID, T1.COMPONENT_ID, T1.IS_REQUIRED, T1.IS_KEY, T2.NAME AS COMPONENT_NAME, T3.NAME AS COMPOSITE_NAME FROM "
				+ this.LACOMPREL + " T1, " + this.LAPROP + " T2, " + this.LAPROP
				+ " T3 WHERE T1.COMPONENT_ID = T2.PROP_ID AND T1.COMPOSITE_ID = T3.PROP_ID AND T1.COMPOSITE_ID IN ( ";
		this.findDBEntityByUniqueId = "SELECT ENTITY_ID, ENTITY_TYPE, UNIQUE_ID, UNIQUE_NAME, UNIQUE_NAME_KEY FROM "
				+ this.DBENTITY + " WHERE UNIQUE_ID = ?";
		this.findDBEntityByUniqueNameKey = "SELECT ENTITY_ID, ENTITY_TYPE, UNIQUE_ID, UNIQUE_NAME, UNIQUE_NAME_KEY FROM "
				+ this.DBENTITY + " WHERE UNIQUE_NAME_KEY = ?";
		this.findParentByEntityId = "SELECT T1.ENTITY_ID, T1.UNIQUE_ID, T1.UNIQUE_NAME, T1.ENTITY_TYPE FROM "
				+ this.DBENTITY + " T1, " + this.DBENTREL
				+ " T2 WHERE T2.DESCENDANT_ID = ? AND T2.ANCESTOR_ID = T1.ENTITY_ID";
		this.findAllDescendantsByUniqueNameKey = "SELECT ENTITY_ID FROM " + this.DBENTITY
				+ " WHERE UNIQUE_NAME_KEY LIKE ?";
		this.entityTypesIn = " AND ENTITY_TYPE IN (";
		this.findChildrenByUniqueNameKey = "SELECT T2.DESCENDANT_ID FROM " + this.DBENTITY + " T1, " + this.DBENTREL
				+ " T2, " + this.DBENTITY
				+ " T3 WHERE T1.ENTITY_ID = T2.ANCESTOR_ID AND T1.UNIQUE_NAME_KEY=? AND T2.DESCENDANT_ID = T3.ENTITY_ID ";
		this.findChildrenByAncestorIdIn = "SELECT T2.DESCENDANT_ID FROM " + this.DBENTITY + " T3, " + this.DBENTREL
				+ " T2 WHERE T2.ANCESTOR_ID in ( ";
		this.childrenEntityTypesIn = " AND T3.ENTITY_TYPE IN (";
		this.findImmediateGroupIdsByExtIdAndReposId = "SELECT GRP_ID FROM " + this.DBGRPREL
				+ " WHERE EXT_ID = ? AND REPOS_ID = ?";
		this.findImmediateGroupIdsByExtIdAndReposIdUnderSearchBases = "SELECT T1.GRP_ID FROM " + this.DBGRPREL + " T1, "
				+ this.DBENTITY + " T2 WHERE T1.EXT_ID = ? AND T1.REPOS_ID = ? AND T1.GRP_ID = T2.ENTITY_ID AND (";
		this.uniqueNameEndWith = " LOWER(T2.UNIQUE_NAME) LIKE ? ";
		this.findNestedGroupIdsByExtIdAndReposId = "SELECT GRP_ID, UNIQUE_ID FROM " + this.DBENTITY + ", "
				+ this.DBGRPREL + " WHERE EXT_ID = ? AND REPOS_ID = ? AND GRP_ID = ENTITY_ID";
		this.findNestedGroupIdsByExtIdAndReposIdUnderSearchBases = "SELECT T1.GRP_ID, T2.UNIQUE_ID FROM "
				+ this.DBGRPREL + " T1, " + this.DBENTITY
				+ " T2 WHERE T1.EXT_ID = ? AND T1.REPOS_ID = ? AND T1.GRP_ID = T2.ENTITY_ID AND (";
		this.findImmediateGroupMemberIdsByGroupEntId = "SELECT EXT_ID, REPOS_ID, ENTITY_ID, ENTITY_TYPE FROM "
				+ this.DBGRPREL + " LEFT JOIN " + this.DBENTITY + " ON " + this.DBENTITY + ".UNIQUE_ID = "
				+ this.DBGRPREL + ".EXT_ID  WHERE GRP_ID = ? ";
		this.findImmediateGroupMemberIdsByGroupEntIdForEntityType = "SELECT FULL_EXT_ID, REPOS_ID, ENTITY_ID, ENTITY_TYPE FROM "
				+ this.DBGRPREL + " LEFT JOIN " + this.DBENTITY + " ON " + this.DBENTITY + ".UNIQUE_ID = "
				+ this.DBGRPREL + ".EXT_ID AND " + this.DBENTITY + ".ENTITY_TYPE IN (";
		this.findImmediateGroupMemberIdsByGroupEntIdForEntityTypeWhere = " WHERE GRP_ID = ?";
		this.findLeafEntityUniqueName = "SELECT UNIQUE_NAME FROM " + this.DBENTITY + ", " + this.DBENTREL
				+ " WHERE ENTITY_ID = ANCESTOR_ID AND ENTITY_ID = ?";
		this.findDBEntityByEntityId = "SELECT ENTITY_ID, ENTITY_TYPE, UNIQUE_ID, UNIQUE_NAME, UNIQUE_NAME_KEY FROM "
				+ this.DBENTITY + " WHERE ENTITY_ID = ?";
		this.findDBAccountByEntId = "SELECT ENTITY_ID, PASSWORD, SALT, EXT_ID, REPOS_ID FROM " + this.DBACCT
				+ " WHERE ENTITY_ID = ?";
		this.findLAEntityByExtIdReposId = "SELECT ENTITY_ID, ENTITY_TYPE, EXT_ID, REPOS_ID FROM " + this.LAENTITY
				+ " WHERE EXT_ID = ? AND REPOS_ID = ?";
		this.getDBStringPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.DBSTRPROP
				+ " T1, " + this.DBPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getDBIntegerPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.DBINTPROP
				+ " T1, " + this.DBPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getDBLongPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.DBLONGPROP
				+ " T1, " + this.DBPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getDBDoublePropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.DBDBLPROP
				+ " T1, " + this.DBPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getDBTimestampPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.DBTSPROP
				+ " T1, " + this.DBPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getDBReferencePropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.REF_UNAME, T1.REF_FULL_EXT_ID, T1.REF_REPOS_ID FROM "
				+ this.DBREFPROP + " T1, " + this.DBPROP
				+ " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getDBObjectPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.DBBLOBPROP
				+ " T1, " + this.DBPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getLAStringPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.LASTRPROP
				+ " T1, " + this.LAPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getLAIntegerPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.LAINTPROP
				+ " T1, " + this.LAPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getLALongPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.LALONGPROP
				+ " T1, " + this.LAPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getLADoublePropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.LADBLPROP
				+ " T1, " + this.LAPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getLATimestampPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.LATSPROP
				+ " T1, " + this.LAPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getLAReferencePropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.REF_UNAME, T1.REF_FULL_EXT_ID, T1.REF_REPOS_ID FROM "
				+ this.LAREFPROP + " T1, " + this.LAPROP
				+ " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.getLAObjectPropValuesByEntityId = " SELECT T2.NAME, T2.MULTI_VALUED, T1.PROPVALUE FROM " + this.LABLOBPROP
				+ " T1, " + this.LAPROP + " T2 WHERE T2.PROP_ID = T1.PROP_ID AND T1.ENTITY_ID = ? AND T1.PROP_ID IN ( ";
		this.orderByPropertyNameInGetProperties = " ORDER BY T2.NAME ";
		this.findDBEntityGeneral = "SELECT -100  as VALUEINDEX, -1 as DATATYPE, " + this.DBENTITY
				+ ".ENTITY_ID as ENTITY_ID, UNIQUE_NAME, UNIQUE_ID, ENTITY_TYPE, 0 as PROP_ID, '' as NAME, 0 AS MULTI_VALUED, '' as STRINGVALUE, 0 as INTEGERVALUE, 0 as DOUBLEVALUE, 0 as LONGVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.DBENTITY + " WHERE 1=1 ";
		this.findStringPropertyForEntities = "SELECT 10 AS VALUEINDEX, 0 AS DATATYPE, " + this.DBENTITY
				+ ".ENTITY_ID AS ENTITY_ID, UNIQUE_NAME_KEY, UNIQUE_ID, ENTITY_TYPE, " + this.DBPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, " + this.DBSTRPROP
				+ ".PROPVALUE AS STRINGVALUE, 0 AS INTEGERVALUE, 0 AS DOUBLEVALUE, 0 AS LONGVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.DBPROP + ", " + this.DBSTRPROP + ", " + this.DBENTITY + " WHERE " + this.DBENTITY
				+ ".ENTITY_ID = " + this.DBSTRPROP + ".ENTITY_ID AND " + this.DBSTRPROP + ".PROP_ID = " + this.DBPROP
				+ ".PROP_ID ";
		this.findLongPropertyForEntities = "SELECT 13 AS VALUEINDEX, 1 AS DATATYPE, " + this.DBENTITY
				+ ".ENTITY_ID AS ENTITY_ID, UNIQUE_NAME_KEY, UNIQUE_ID, ENTITY_TYPE, " + this.DBPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS INTEGERVALUE, 0 AS DOUBLEVALUE, "
				+ this.DBLONGPROP + ".PROPVALUE AS LONGVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.DBPROP + ", " + this.DBLONGPROP + ", " + this.DBENTITY + " WHERE " + this.DBENTITY
				+ ".ENTITY_ID = " + this.DBLONGPROP + ".ENTITY_ID AND " + this.DBLONGPROP + ".PROP_ID = " + this.DBPROP
				+ ".PROP_ID";
		this.findDoublePropertyForEntities = "SELECT 12 AS VALUEINDEX, 2 AS DATATYPE, " + this.DBENTITY
				+ ".ENTITY_ID AS ENTITY_ID, UNIQUE_NAME_KEY, UNIQUE_ID, ENTITY_TYPE, " + this.DBPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS INTEGERVALUE, " + this.DBDBLPROP
				+ ".PROPVALUE AS DOUBLEVALUE, 0 AS LONGVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.DBPROP + ", " + this.DBDBLPROP + ", " + this.DBENTITY + " WHERE " + this.DBENTITY
				+ ".ENTITY_ID = " + this.DBDBLPROP + ".ENTITY_ID AND " + this.DBDBLPROP + ".PROP_ID = " + this.DBPROP
				+ ".PROP_ID";
		this.findIntegerPropertyForEntities = "SELECT 11 AS VALUEINDEX, 3 AS DATATYPE, " + this.DBENTITY
				+ ".ENTITY_ID AS ENTITY_ID, UNIQUE_NAME_KEY, UNIQUE_ID, ENTITY_TYPE, " + this.DBPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, '' AS STRINGVALUE, " + this.DBINTPROP
				+ ".PROPVALUE AS INTEGERVALUE, 0 AS DOUBLEVALUE, 0 AS LONGVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.DBPROP + ", " + this.DBINTPROP + ", " + this.DBENTITY + " WHERE " + this.DBENTITY
				+ ".ENTITY_ID = " + this.DBINTPROP + ".ENTITY_ID AND " + this.DBINTPROP + ".PROP_ID = " + this.DBPROP
				+ ".PROP_ID";
		this.findTimestampPropertyForEntities = "SELECT 14 AS VALUEINDEX, 4 AS DATATYPE, " + this.DBENTITY
				+ ".ENTITY_ID AS ENTITY_ID, UNIQUE_NAME_KEY, UNIQUE_ID, ENTITY_TYPE, " + this.DBPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS INTEGERVALUE, 0 AS DOUBLEVALUE, 0 AS LONGVALUE, "
				+ this.DBTSPROP + ".PROPVALUE AS TIMESTAMPVALUE FROM " + this.DBPROP + ", " + this.DBTSPROP + ", "
				+ this.DBENTITY + " WHERE " + this.DBENTITY + ".ENTITY_ID = " + this.DBTSPROP + ".ENTITY_ID AND "
				+ this.DBTSPROP + ".PROP_ID = " + this.DBPROP + ".PROP_ID";
		this.findReferencePropertyForEntities = "SELECT 4  AS VALUEINDEX, 5 AS DATATYPE, " + this.DBENTITY
				+ ".ENTITY_ID AS ENTITY_ID, REF_FULL_EXT_ID, REF_REPOS_ID, ENTITY_TYPE, " + this.DBPROP
				+ ".PROP_ID AS PROP_ID, NAME, MULTI_VALUED, " + this.DBREFPROP
				+ ".REF_UNAME AS STRINGVALUE, 0 AS INTEGERVALUE, 0 AS DOUBLEVALUE, 0 AS BIGINTVALUE, TIMESTAMP('19680204000000') AS TIMESTAMPVALUE FROM "
				+ this.DBPROP + ", " + this.DBREFPROP + ", " + this.DBENTITY + " WHERE " + this.DBENTITY
				+ ".ENTITY_ID = " + this.DBREFPROP + ".ENTITY_ID AND " + this.DBREFPROP + ".PROP_ID = " + this.DBPROP
				+ ".PROP_ID";
		this.findDBPropertyIdIn = " AND " + this.DBPROP + ".PROP_ID IN (";
		this.findSpecificPropertyForEntitiesOrderBy = " ORDER BY ENTITY_ID, PROP_ID, VALUEINDEX";
		this.getAllSupportedPropertyTypes = "SELECT TYPE_ID FROM " + this.DBPROPTYPE + "";
		this.getLAAllSupportedPropertyTypes = "SELECT TYPE_ID FROM " + this.LAPROP + "TYPE";
		this.findAllStringPropertiesForEntity = " (SELECT 9 AS VALUEINDEX, 0 AS DATATYPE,  '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.DBPROP + ".PROP_ID AS PROP_ID, " + this.DBPROP + ".NAME AS NAME, MULTI_VALUED, " + this.DBSTRPROP
				+ ".PROPVALUE AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.DBPROP + ", " + this.DBSTRPROP + " WHERE " + this.DBSTRPROP + ".ENTITY_ID = ? AND " + this.DBPROP
				+ ".PROP_ID = " + this.DBSTRPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllLongPropertiesForEntity = " (SELECT 10 AS VALUEINDEX, 1 AS DATATYPE, '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.DBPROP + ".PROP_ID AS PROP_ID, " + this.DBPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, " + this.DBLONGPROP
				+ ".PROPVALUE AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.DBPROP + ", " + this.DBLONGPROP + " WHERE " + this.DBLONGPROP + ".ENTITY_ID = ? AND "
				+ this.DBPROP + ".PROP_ID = " + this.DBLONGPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllDoublePropertiesForEntity = " (SELECT 11 AS VALUEINDEX, 2 AS DATATYPE, '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.DBPROP + ".PROP_ID AS PROP_ID, " + this.DBPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, " + this.DBDBLPROP
				+ ".PROPVALUE AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.DBPROP + ", " + this.DBDBLPROP + " WHERE " + this.DBDBLPROP + ".ENTITY_ID = ? AND " + this.DBPROP
				+ ".PROP_ID = " + this.DBDBLPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllIntegerPropertiesForEntity = " (SELECT 12 AS VALUEINDEX, 3 AS DATATYPE, '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.DBPROP + ".PROP_ID AS PROP_ID, " + this.DBPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, " + this.DBINTPROP
				+ ".PROPVALUE AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM " + this.DBPROP + ", "
				+ this.DBINTPROP + " WHERE " + this.DBINTPROP + ".ENTITY_ID = ? AND " + this.DBPROP + ".PROP_ID = "
				+ this.DBINTPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllTimestampPropertiesForEntity = " (SELECT 13 AS VALUEINDEX, 4 AS DATATYPE, '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.DBPROP + ".PROP_ID AS PROP_ID, " + this.DBPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, "
				+ this.DBTSPROP + ".PROPVALUE as TIMESTAMPVALUE FROM " + this.DBPROP + ", " + this.DBTSPROP + " WHERE "
				+ this.DBTSPROP + ".ENTITY_ID = ? AND " + this.DBPROP + ".PROP_ID = " + this.DBTSPROP
				+ ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllReferencePropertiesForEntity = " (SELECT 3 AS VALUEINDEX, 5 AS DATATYPE, REF_UNAME AS UNIQUE_NAME, REF_FULL_EXT_ID AS EXT_ID, REF_REPOS_ID AS REPOS_ID, "
				+ this.DBPROP + ".PROP_ID AS PROP_ID, " + this.DBPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.DBPROP + ", " + this.DBREFPROP + " WHERE " + this.DBREFPROP + ".ENTITY_ID = ? AND " + this.DBPROP
				+ ".PROP_ID = " + this.DBREFPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllBlobPropertiesForEntity = " (SELECT " + this.DBPROP + ".PROP_ID AS PROP_ID, " + this.DBPROP
				+ ".NAME AS NAME, MULTI_VALUED, " + this.DBBLOBPROP + ".PROPVALUE AS BLOBVALUE FROM " + this.DBPROP
				+ ", " + this.DBBLOBPROP + " WHERE " + this.DBBLOBPROP + ".ENTITY_ID = ? AND " + this.DBPROP
				+ ".PROP_ID = " + this.DBBLOBPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.orderByPropId = " ORDER BY PROP_ID ";
		this.findAllPropertiesForEntity = this.findAllStringPropertiesForEntity + this.UNION_ALL
				+ this.findAllLongPropertiesForEntity + this.UNION_ALL + this.findAllDoublePropertiesForEntity
				+ this.UNION_ALL + this.findAllIntegerPropertiesForEntity + this.UNION_ALL
				+ this.findAllTimestampPropertiesForEntity + this.UNION_ALL + this.findAllReferencePropertiesForEntity
				+ this.orderByPropId;
		this.findAllStringPropertiesForLAEntity = " (SELECT 9 AS VALUEINDEX, 0 AS DATATYPE,  '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.LAPROP + ".PROP_ID AS PROP_ID, " + this.LAPROP + ".NAME AS NAME, MULTI_VALUED, " + this.LASTRPROP
				+ ".PROPVALUE AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.LAPROP + ", " + this.LASTRPROP + " WHERE " + this.LASTRPROP + ".ENTITY_ID = ? AND " + this.LAPROP
				+ ".PROP_ID = " + this.LASTRPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllLongPropertiesForLAEntity = " (SELECT 10 AS VALUEINDEX, 1 AS DATATYPE, '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.LAPROP + ".PROP_ID AS PROP_ID, " + this.LAPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, " + this.LALONGPROP
				+ ".PROPVALUE AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.LAPROP + ", " + this.LALONGPROP + " WHERE " + this.LALONGPROP + ".ENTITY_ID = ? AND "
				+ this.LAPROP + ".PROP_ID = " + this.LALONGPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllDoublePropertiesForLAEntity = " (SELECT 11 AS VALUEINDEX, 2 AS DATATYPE, '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.LAPROP + ".PROP_ID AS PROP_ID, " + this.LAPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, " + this.LADBLPROP
				+ ".PROPVALUE AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.LAPROP + ", " + this.LADBLPROP + " WHERE " + this.LADBLPROP + ".ENTITY_ID = ? AND " + this.LAPROP
				+ ".PROP_ID = " + this.LADBLPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllIntegerPropertiesForLAEntity = " (SELECT 12 AS VALUEINDEX, 3 AS DATATYPE, '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.LAPROP + ".PROP_ID AS PROP_ID, " + this.LAPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, " + this.LAINTPROP
				+ ".PROPVALUE AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM " + this.LAPROP + ", "
				+ this.LAINTPROP + " WHERE " + this.LAINTPROP + ".ENTITY_ID = ? AND " + this.LAPROP + ".PROP_ID = "
				+ this.LAINTPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllTimestampPropertiesForLAEntity = " (SELECT 13 AS VALUEINDEX, 4 AS DATATYPE, '' AS UNIQUE_NAME, '' AS EXT_ID, '' AS REPOS_ID, "
				+ this.LAPROP + ".PROP_ID AS PROP_ID, " + this.LAPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, "
				+ this.LATSPROP + ".PROPVALUE as TIMESTAMPVALUE FROM " + this.LAPROP + ", " + this.LATSPROP + " WHERE "
				+ this.LATSPROP + ".ENTITY_ID = ? AND " + this.LAPROP + ".PROP_ID = " + this.LATSPROP
				+ ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllReferencePropertiesForLAEntity = " (SELECT 3 AS VALUEINDEX, 5 AS DATATYPE, REF_UNAME AS UNIQUE_NAME, REF_FULL_EXT_ID AS EXT_ID, REF_REPOS_ID AS REPOS_ID, "
				+ this.LAPROP + ".PROP_ID AS PROP_ID, " + this.LAPROP
				+ ".NAME AS NAME, MULTI_VALUED, '' AS STRINGVALUE, 0 AS LONGVALUE, 0 AS DOUBLEVALUE, 0 AS INTEGERVALUE, TIMESTAMP('19680204000000') as TIMESTAMPVALUE FROM "
				+ this.LAPROP + ", " + this.LAREFPROP + " WHERE " + this.LAREFPROP + ".ENTITY_ID = ? AND " + this.LAPROP
				+ ".PROP_ID = " + this.LAREFPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllBlobPropertiesForLAEntity = " (SELECT " + this.LAPROP + ".PROP_ID AS PROP_ID, " + this.LAPROP
				+ ".NAME AS NAME, MULTI_VALUED, " + this.LABLOBPROP + ".PROPVALUE AS BLOBVALUE FROM " + this.LAPROP
				+ ", " + this.LABLOBPROP + " WHERE " + this.LABLOBPROP + ".ENTITY_ID = ? AND " + this.LAPROP
				+ ".PROP_ID = " + this.LABLOBPROP + ".PROP_ID AND COMPOSITE IS NULL) ";
		this.findAllPropertiesForLAEntity = this.findAllStringPropertiesForLAEntity + this.UNION_ALL
				+ this.findAllLongPropertiesForLAEntity + this.UNION_ALL + this.findAllDoublePropertiesForLAEntity
				+ this.UNION_ALL + this.findAllIntegerPropertiesForLAEntity + this.UNION_ALL
				+ this.findAllTimestampPropertiesForLAEntity + this.UNION_ALL
				+ this.findAllReferencePropertiesForLAEntity + this.orderByPropId;
		this.ENTITY_ID_IN = this.DBENTITY + ".ENTITY_ID IN ( ";
		this.createDBProperty = "INSERT INTO " + this.DBPROP
				+ " (PROP_ID, NAME, TYPE_ID, META_NAME, IS_COMPOSITE, VALUE_LENGTH, READ_ONLY, MULTI_VALUED, CASE_EXACT_MATCH, CLASSNAME, DESCRIPTION, APPLICATION_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		this.createDBPropertyEntity = "INSERT INTO " + this.DBPROPENT
				+ " (PROP_ID, APPLICABLE_ENTTYPE, REQUIRED_ENTTYPE) VALUES (?, ?, ?)";
		this.createDBCompositeRelation = "INSERT INTO " + this.DBCOMPREL
				+ " (COMPOSITE_ID, COMPONENT_ID, IS_REQUIRED, IS_KEY) VALUES (?, ?, ?, ?)";
		this.createLAProperty = "INSERT INTO " + this.LAPROP
				+ " (PROP_ID, NAME, TYPE_ID, META_NAME, IS_COMPOSITE, VALUE_LENGTH, READ_ONLY, MULTI_VALUED, CASE_EXACT_MATCH, CLASSNAME, DESCRIPTION, APPLICATION_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		this.createLAPropertyEntity = "INSERT INTO " + this.LAPROPENT
				+ "(PROP_ID, APPLICABLE_ENTTYPE, REQUIRED_ENTTYPE) VALUES (?, ?, ?)";
		this.createLACompositeRelation = "INSERT INTO " + this.LACOMPREL
				+ " (COMPOSITE_ID, COMPONENT_ID, IS_REQUIRED, IS_KEY) VALUES (?, ?, ?, ?)";
		this.createFederationEntity = "INSERT INTO " + this.FEDENTITY
				+ " ( UNIQUE_ID, UNIQUE_NAME_KEY, UNIQUE_NAME, ENTITY_TYPE, REPOS_ID, EXT_ID, FULL_EXT_ID ) VALUES (?, ?, ?, ?, ?, ?, ?)";
		this.findFederationEntityByRepositoryAndExternalId = "SELECT UNIQUE_ID, UNIQUE_NAME, ENTITY_TYPE, REPOS_ID, FULL_EXT_ID FROM "
				+ this.FEDENTITY + " WHERE REPOS_ID = ? and EXT_ID = ?";
		this.findFederationEntityByUniqueId = "SELECT UNIQUE_ID, UNIQUE_NAME, ENTITY_TYPE, REPOS_ID, FULL_EXT_ID FROM "
				+ this.FEDENTITY + " WHERE UNIQUE_ID = ?";
		this.findFederationEntityByUniqueName = "SELECT UNIQUE_ID, UNIQUE_NAME, ENTITY_TYPE, REPOS_ID, FULL_EXT_ID FROM "
				+ this.FEDENTITY + " WHERE UNIQUE_NAME_KEY = ?";
		this.removeFederationEntityByEntityId = "DELETE FROM " + this.FEDENTITY + " WHERE UNIQUE_ID = ?";
		this.removeFederationEntityByEntityName = "DELETE FROM " + this.FEDENTITY + " WHERE UNIQUE_NAME_KEY = ?";
		this.removeFederationEntityByExternalId = "DELETE FROM " + this.FEDENTITY
				+ " WHERE EXT_ID = ? AND REPOS_ID = ?";
		this.updateFederationExternalIdByUniqueId = "UPDATE " + this.FEDENTITY
				+ " SET FULL_EXT_ID = ?, EXT_ID = ? WHERE UNIQUE_ID = ?";
		this.updateFederationUniqueNameByUniqueId = "UPDATE " + this.FEDENTITY
				+ " SET UNIQUE_NAME = ?, UNIQUE_NAME_KEY = ? WHERE UNIQUE_ID = ?";
		this.findFederationEntitiesByReposIdAndExtIds = "SELECT UNIQUE_ID, UNIQUE_NAME, ENTITY_TYPE, REPOS_ID, FULL_EXT_ID FROM "
				+ this.FEDENTITY + " WHERE REPOS_ID = ? AND EXT_ID IN (";
		this.findFederationEntitiesByUniqueIds = "SELECT UNIQUE_ID, UNIQUE_NAME, ENTITY_TYPE, REPOS_ID, FULL_EXT_ID FROM "
				+ this.FEDENTITY + " WHERE UNIQUE_ID IN (";
		this.findDBEntityIdByTruncUniqueName = "SELECT ENTITY_ID FROM " + this.DBENTITY + " WHERE UNIQUE_NAME_KEY = ?";
		this.findDBEntityIdByUniqueId = "SELECT ENTITY_ID FROM " + this.DBENTITY + " WHERE UNIQUE_ID= ?";
		this.selectDBKeys = "SELECT * FROM " + this.DBKEYS;
		this.selectDBKeysByTable = "SELECT * FROM " + this.DBKEYS + " WHERE TABLENAME = ?";
		this.selectLAKeys = "SELECT * FROM " + this.LAKEYS;
		this.selectLAKeysByTable = "SELECT * FROM " + this.LAKEYS + " WHERE TABLENAME = ?";
		this.updateDBKeysByTable = "UPDATE " + this.DBKEYS + " SET COUNTER = ? WHERE TABLENAME = ?";
		this.updateLAKeysByTable = "UPDATE " + this.LAKEYS + " SET COUNTER = ? WHERE TABLENAME = ?";
		this.updateDefaultOrg = "UPDATE " + this.DBENTITY
				+ " SET UNIQUE_NAME = ?, UNIQUE_NAME_KEY = ? WHERE ENTITY_ID=-2000";
		this.findDBPropId = "SELECT PROP_ID FROM " + this.DBPROP + " WHERE NAME = ?";
		this.getLAPropAttributeForEntitype = "SELECT T1.PROP_ID, T1.TYPE_ID FROM   " + this.LAPROP + " T1 , "
				+ this.LAPROPENT + " T2 WHERE T1.NAME = ? AND T2.PROP_ID = T1.PROP_ID AND T2.APPLICABLE_ENTTYPE IN (";
		this.getLAEntitypesForExisting = "SELECT DISTINCT ENTITY_TYPE FROM   " + this.LAENTITY + " WHERE 1=1 ";
		this.getLAEntIdsByPropIdAndEntTypes = "SELECT T1.ENTITY_ID, T1.FULL_EXT_ID, T1.REPOS_ID FROM " + this.LAENTITY
				+ " T1, ";
		this.getLAEntIdsWhereClause = " T2 WHERE T1.ENTITY_ID = T2.ENTITY_ID AND T2.PROP_ID = ? AND T1.ENTITY_TYPE in (";
		this.deleteEntityDataFromLAPropValueTable = "DELETE FROM ";
		this.whereINEIdsClause = " WHERE ENTITY_ID IN (";
		this.andPropIDEqualTo = " AND PROP_ID = ?";
		this.unionOfAllEidsFromValueTables = "SELECT ENTITY_ID FROM " + this.LALONGPROP
				+ "  UNION SELECT ENTITY_ID FROM " + this.LABLOBPROP + "  UNION SELECT ENTITY_ID FROM " + this.LADBLPROP
				+ "  UNION SELECT ENTITY_ID FROM " + this.LAINTPROP + "  UNION SELECT ENTITY_ID FROM " + this.LAREFPROP
				+ " UNION SELECT ENTITY_ID FROM " + this.LASTRPROP + " UNION SELECT ENTITY_ID FROM " + this.LATSPROP
				+ " UNION SELECT ENTITY_ID FROM " + this.LACOMPPROP + " ";
		this.getEidsForLACleanup = "SELECT T1.ENTITY_ID, T1.FULL_EXT_ID, T1.REPOS_ID FROM " + this.LAENTITY
				+ " T1 WHERE T1.ENTITY_ID NOT IN " + this.LEFT_BRACKET + this.unionOfAllEidsFromValueTables
				+ this.RIGHT_BRACKET;
		this.deleteEntityFromLAIfNoPropValueIsAssociateWith = "DELETE FROM " + this.LAENTITY + " WHERE ENTITY_ID NOT IN"
				+ this.LEFT_BRACKET + this.unionOfAllEidsFromValueTables + this.RIGHT_BRACKET;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
	}
}