package com.ibm.ws.wim.config;

import com.ibm.websphere.management.repository.ConfigRepository;
import com.ibm.websphere.management.repository.DocumentContentSource;
import com.ibm.websphere.management.repository.client.ConfigRepositoryClientFactory;
import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.ServiceProvider;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.ws.security.util.WSEncoderDecoder;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.util.DataGraphHelper;
import commonj.sdo.DataObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;

public class DynamicConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = DynamicConfigHelper.class.getName();
	private static final Logger trcLogger;

	public String updateIdMgrLDAPBindInfo(String var1, Map var2) throws Exception {
		String var3 = "updateIdMgrLDAPBindInfo";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var3, "params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var4 = (String) var2.get("id");
		String var5 = (String) var2.get("bindDN");
		String var6 = (String) var2.get("bindPassword");
		if (var5 != null && var6 == null) {
			throw new WIMConfigurationException("RELATED_PARAMETERS_NOT_SPECIFIED",
					WIMMessageHelper.generateMsgParms("bindDN", "bindPassword"), Level.SEVERE, CLASSNAME, var3);
		} else if (var5 == null && var6 != null) {
			throw new WIMConfigurationException("RELATED_PARAMETERS_NOT_SPECIFIED",
					WIMMessageHelper.generateMsgParms("bindPassword", "bindDN"), Level.SEVERE, CLASSNAME, var3);
		} else {
			Hashtable var7 = new Hashtable();
			var7.put("DYNA_CONFIG_KEY_REPOS_ID", var4);
			if (var5 != null && var6 != null) {
				var7.put("DYNA_CONFIG_KEY_LDAP_BIND_DN", var5);
				var7.put("DYNA_CONFIG_KEY_LDAP_BIND_PASSWORD", PasswordUtil.getByteArrayPassword(var6));
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, var3, "getting service provider singleton");
			}

			ServiceProvider var8 = ServiceProvider.singleton();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, var3, "calling dynamicUpdateConfig for " + var4);
			}

			var8.dynamicUpdateConfig("websphere.usermanager.serviceprovider.update.ldap.bindinfo", var7);
			if (var5 != null && var6 != null) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, var3, "getting persisted configuration");
				}

				Properties var9 = new Properties();
				var9.setProperty("location", "local");
				ConfigRepository var10 = null;
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, var3, "getting and initializing local ConfigRepository...");
				}

				var10 = ConfigRepositoryClientFactory.getConfigRepositoryClient(var9);
				var10.initialize(var9);
				String var11 = "cells/" + ConfigManager.singleton().getCellName() + "/" + "wim" + "/" + "config" + "/"
						+ "wimconfig.xml";
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, var3, "extracting config file using uri=" + var11);
				}

				DocumentContentSource var12 = var10.extract(var11);
				InputStream var13 = var12.getSource();
				HashMap var14 = new HashMap();
				EDataGraph var15 = SDOUtil.loadDataGraph(var13, var14);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, var3, "config file is loaded");
				}

				ConfigurationProviderType var16 = null;
				if (var15 == null) {
					throw new WIMConfigurationException("WIM_CONFIG_XML_FILE_NOT_FOUND",
							WIMMessageHelper.generateMsgParms(var11), CLASSNAME, var3);
				}

				var16 = (ConfigurationProviderType) var15.getRootObject().getDataObject("configurationProvider");
				LdapRepositoryType var17 = (LdapRepositoryType) ConfigUtils.validateAndGetRepository(var16, var4,
						"LdapRepositoryType");
				LdapServerConfigurationType var18 = var17.getLdapServerConfiguration();
				if (var18 == null) {
					throw new WIMConfigurationException("MISSING_LDAP_SERVER_CONFIGURATION",
							WIMMessageHelper.generateMsgParms(var4), Level.SEVERE, CLASSNAME, var3);
				}

				List var19 = var18.getLdapServers();
				if (var19.size() == 0) {
					throw new WIMConfigurationException("MISSING_LDAP_SERVER_CONFIGURATION",
							WIMMessageHelper.generateMsgParms(var4), Level.SEVERE, CLASSNAME, var3);
				}

				LdapServersType var20 = (LdapServersType) var19.get(0);
				if (var5 != null) {
					var20.setBindDN(var5);
				}

				if (var6 != null) {
					var20.setBindPassword(this.encodePassword(var6));
				}

				ByteArrayOutputStream var21 = new ByteArrayOutputStream();
				((EDataGraph) ((DataObject) var16).getDataGraph()).getDataGraphResource().save(var21, (Map) null);
				var12.setSource(new ByteArrayInputStream(DataGraphHelper.insertCopyright(var21)));
				var10.modify(var12);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, var3, "config file is updated with new bind info");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, var3);
			}

			return "COMMAND_COMPLETED_SUCCESSFULLY";
		}
	}

	private String encodePassword(String var1) {
		WSEncoderDecoder var2 = new WSEncoderDecoder();
		return var2.encode(var1);
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}