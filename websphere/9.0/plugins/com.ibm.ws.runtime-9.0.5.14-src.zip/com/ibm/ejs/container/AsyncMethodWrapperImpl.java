package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.asynchbeans.Work;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.asynchbeans.TaskDetails;
import javax.rmi.CORBA.Util;
import org.omg.CORBA.SystemException;

public final class AsyncMethodWrapperImpl extends AsyncMethodWrapper implements Work, TaskDetails {
	private static final String CLASS_NAME = AsyncMethodWrapperImpl.class.getName();
	private static final TraceComponent tc;

	public AsyncMethodWrapperImpl(EJSWrapperBase theCallingWrapper, int theMethodId, Object[] theMethodArgs,
			ServerAsyncResult theServerFuture) {
		super(theCallingWrapper, theMethodId, theMethodArgs, theServerFuture);
	}

	protected Throwable mapSystemExceptionBackToRemoteException(Throwable ex) {
		if (ex instanceof SystemException) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "mapping SystemException back to RemoteException: " + ex);
			}

			return Util.mapSystemException((SystemException) ex);
		} else {
			return ex;
		}
	}

	public synchronized void release() {
	}

	public String getOwner() {
		return null;
	}

	public String getTaskName() {
		J2EEName j2eeName = this.beanId.getJ2EEName();
		return j2eeName.getApplication() + ":" + j2eeName.getComponent() + ":"
				+ this.methodInfos[this.ivMethodId].getMethodName() + " (EJB Async)";
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}