package com.google.common.primitives;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Converter;
import com.google.common.base.Preconditions;
import com.google.common.primitives.Shorts.LexicographicalComparator;
import com.google.common.primitives.Shorts.ShortArrayAsList;
import com.google.common.primitives.Shorts.ShortConverter;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@GwtCompatible(emulated = true)
public final class Shorts {
	public static final int BYTES = 2;
	public static final short MAX_POWER_OF_TWO = 16384;

	public static int hashCode(short value) {
		return value;
	}

	public static short checkedCast(long value) {
		short result = (short) ((int) value);
		Preconditions.checkArgument((long) result == value, "Out of range: %s", value);
		return result;
	}

	public static short saturatedCast(long value) {
		if (value > 32767L) {
			return 32767;
		} else {
			return value < -32768L ? -32768 : (short) ((int) value);
		}
	}

	public static int compare(short a, short b) {
		return a - b;
	}

	public static boolean contains(short[] array, short target) {
		short[] var2 = array;
		int var3 = array.length;

		for (int var4 = 0; var4 < var3; ++var4) {
			short value = var2[var4];
			if (value == target) {
				return true;
			}
		}

		return false;
	}

	public static int indexOf(short[] array, short target) {
		return indexOf(array, target, 0, array.length);
	}

	private static int indexOf(short[] array, short target, int start, int end) {
		for (int i = start; i < end; ++i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static int indexOf(short[] array, short[] target) {
		Preconditions.checkNotNull(array, "array");
		Preconditions.checkNotNull(target, "target");
		if (target.length == 0) {
			return 0;
		} else {
			label28 : for (int i = 0; i < array.length - target.length + 1; ++i) {
				for (int j = 0; j < target.length; ++j) {
					if (array[i + j] != target[j]) {
						continue label28;
					}
				}

				return i;
			}

			return -1;
		}
	}

	public static int lastIndexOf(short[] array, short target) {
		return lastIndexOf(array, target, 0, array.length);
	}

	private static int lastIndexOf(short[] array, short target, int start, int end) {
		for (int i = end - 1; i >= start; --i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static short min(short... array) {
		Preconditions.checkArgument(array.length > 0);
		short min = array[0];

		for (int i = 1; i < array.length; ++i) {
			if (array[i] < min) {
				min = array[i];
			}
		}

		return min;
	}

	public static short max(short... array) {
		Preconditions.checkArgument(array.length > 0);
		short max = array[0];

		for (int i = 1; i < array.length; ++i) {
			if (array[i] > max) {
				max = array[i];
			}
		}

		return max;
	}

	@Beta
	public static short constrainToRange(short value, short min, short max) {
		Preconditions.checkArgument(min <= max, "min (%s) must be less than or equal to max (%s)", min, max);
		return value < min ? min : (value < max ? value : max);
	}

	public static short[] concat(short[]... arrays) {
		int length = 0;
		short[][] var2 = arrays;
		int pos = arrays.length;

		for (int var4 = 0; var4 < pos; ++var4) {
			short[] array = var2[var4];
			length += array.length;
		}

		short[] result = new short[length];
		pos = 0;
		short[][] var9 = arrays;
		int var10 = arrays.length;

		for (int var6 = 0; var6 < var10; ++var6) {
			short[] array = var9[var6];
			System.arraycopy(array, 0, result, pos, array.length);
			pos += array.length;
		}

		return result;
	}

	@GwtIncompatible
	public static byte[] toByteArray(short value) {
		return new byte[]{(byte) (value >> 8), (byte) value};
	}

	@GwtIncompatible
	public static short fromByteArray(byte[] bytes) {
		Preconditions.checkArgument(bytes.length >= 2, "array too small: %s < %s", bytes.length, 2);
		return fromBytes(bytes[0], bytes[1]);
	}

	@GwtIncompatible
	public static short fromBytes(byte b1, byte b2) {
		return (short) (b1 << 8 | b2 & 255);
	}

	@Beta
	public static Converter<String, Short> stringConverter() {
		return ShortConverter.INSTANCE;
	}

	public static short[] ensureCapacity(short[] array, int minLength, int padding) {
		Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", minLength);
		Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", padding);
		return array.length < minLength ? Arrays.copyOf(array, minLength + padding) : array;
	}

	public static String join(String separator, short... array) {
		Preconditions.checkNotNull(separator);
		if (array.length == 0) {
			return "";
		} else {
			StringBuilder builder = new StringBuilder(array.length * 6);
			builder.append(array[0]);

			for (int i = 1; i < array.length; ++i) {
				builder.append(separator).append(array[i]);
			}

			return builder.toString();
		}
	}

	public static Comparator<short[]> lexicographicalComparator() {
		return LexicographicalComparator.INSTANCE;
	}

	public static void sortDescending(short[] array) {
		Preconditions.checkNotNull(array);
		sortDescending(array, 0, array.length);
	}

	public static void sortDescending(short[] array, int fromIndex, int toIndex) {
		Preconditions.checkNotNull(array);
		Preconditions.checkPositionIndexes(fromIndex, toIndex, array.length);
		Arrays.sort(array, fromIndex, toIndex);
		reverse(array, fromIndex, toIndex);
	}

	public static void reverse(short[] array) {
		Preconditions.checkNotNull(array);
		reverse(array, 0, array.length);
	}

	public static void reverse(short[] array, int fromIndex, int toIndex) {
		Preconditions.checkNotNull(array);
		Preconditions.checkPositionIndexes(fromIndex, toIndex, array.length);
		int i = fromIndex;

		for (int j = toIndex - 1; i < j; --j) {
			short tmp = array[i];
			array[i] = array[j];
			array[j] = tmp;
			++i;
		}

	}

	public static short[] toArray(Collection<? extends Number> collection) {
		if (collection instanceof ShortArrayAsList) {
			return ((ShortArrayAsList) collection).toShortArray();
		} else {
			Object[] boxedArray = collection.toArray();
			int len = boxedArray.length;
			short[] array = new short[len];

			for (int i = 0; i < len; ++i) {
				array[i] = ((Number) Preconditions.checkNotNull(boxedArray[i])).shortValue();
			}

			return array;
		}
	}

	public static List<Short> asList(short... backingArray) {
		return (List) (backingArray.length == 0 ? Collections.emptyList() : new ShortArrayAsList(backingArray));
	}
}