package com.google.inject;

import com.google.inject.Initializables.1;

class Initializables {
	static <T> Initializable<T> of(T instance) {
      return new 1(instance);
   }
}