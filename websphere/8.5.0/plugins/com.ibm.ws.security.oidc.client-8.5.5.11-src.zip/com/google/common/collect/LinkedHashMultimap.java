package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.collect.LinkedHashMultimap.1;
import com.google.common.collect.LinkedHashMultimap.ValueEntry;
import com.google.common.collect.LinkedHashMultimap.ValueSet;
import com.google.common.collect.LinkedHashMultimap.ValueSetLink;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(serializable = true, emulated = true)
public final class LinkedHashMultimap<K, V> extends AbstractSetMultimap<K, V> {
	private static final int DEFAULT_KEY_CAPACITY = 16;
	private static final int DEFAULT_VALUE_SET_CAPACITY = 2;
	@VisibleForTesting
	static final double VALUE_SET_LOAD_FACTOR = 1.0D;
	@VisibleForTesting
	transient int valueSetCapacity = 2;
	private transient ValueEntry<K, V> multimapHeaderEntry;
	@GwtIncompatible("java serialization not supported")
	private static final long serialVersionUID = 1L;

	public static <K, V> LinkedHashMultimap<K, V> create() {
		return new LinkedHashMultimap(16, 2);
	}

	public static <K, V> LinkedHashMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey) {
		return new LinkedHashMultimap(Maps.capacity(expectedKeys), Maps.capacity(expectedValuesPerKey));
	}

	public static <K, V> LinkedHashMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap) {
		LinkedHashMultimap<K, V> result = create(multimap.keySet().size(), 2);
		result.putAll(multimap);
		return result;
	}

	private static <K, V> void succeedsInValueSet(ValueSetLink<K, V> pred, ValueSetLink<K, V> succ) {
		pred.setSuccessorInValueSet(succ);
		succ.setPredecessorInValueSet(pred);
	}

	private static <K, V> void succeedsInMultimap(ValueEntry<K, V> pred, ValueEntry<K, V> succ) {
		pred.setSuccessorInMultimap(succ);
		succ.setPredecessorInMultimap(pred);
	}

	private static <K, V> void deleteFromValueSet(ValueSetLink<K, V> entry) {
		succeedsInValueSet(entry.getPredecessorInValueSet(), entry.getSuccessorInValueSet());
	}

	private static <K, V> void deleteFromMultimap(ValueEntry<K, V> entry) {
		succeedsInMultimap(entry.getPredecessorInMultimap(), entry.getSuccessorInMultimap());
	}

	private LinkedHashMultimap(int keyCapacity, int valueSetCapacity) {
		super(new LinkedHashMap(keyCapacity));
		Preconditions.checkArgument(valueSetCapacity >= 0, "expectedValuesPerKey must be >= 0 but was %s",
				new Object[]{valueSetCapacity});
		this.valueSetCapacity = valueSetCapacity;
		this.multimapHeaderEntry = new ValueEntry((Object) null, (Object) null, 0, (ValueEntry) null);
		succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
	}

	Set<V> createCollection() {
		return new LinkedHashSet(this.valueSetCapacity);
	}

	Collection<V> createCollection(K key) {
		return new ValueSet(this, key, this.valueSetCapacity);
	}

	public Set<V> replaceValues(@Nullable K key, Iterable<? extends V> values) {
		return super.replaceValues(key, values);
	}

	public Set<Entry<K, V>> entries() {
		return super.entries();
	}

	public Collection<V> values() {
		return super.values();
	}

	Iterator<Entry<K, V>> entryIterator() {
      return new 1(this);
   }

	public void clear() {
		super.clear();
		succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
	}

	@GwtIncompatible("java.io.ObjectOutputStream")
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		stream.writeInt(this.valueSetCapacity);
		stream.writeInt(this.keySet().size());
		Iterator i$ = this.keySet().iterator();

		while (i$.hasNext()) {
			K key = i$.next();
			stream.writeObject(key);
		}

		stream.writeInt(this.size());
		i$ = this.entries().iterator();

		while (i$.hasNext()) {
			Entry<K, V> entry = (Entry) i$.next();
			stream.writeObject(entry.getKey());
			stream.writeObject(entry.getValue());
		}

	}

	@GwtIncompatible("java.io.ObjectInputStream")
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		this.multimapHeaderEntry = new ValueEntry((Object) null, (Object) null, 0, (ValueEntry) null);
		succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
		this.valueSetCapacity = stream.readInt();
		int distinctKeys = stream.readInt();
		Map<K, Collection<V>> map = new LinkedHashMap(Maps.capacity(distinctKeys));

		int entries;
		for (entries = 0; entries < distinctKeys; ++entries) {
			K key = stream.readObject();
			map.put(key, this.createCollection(key));
		}

		entries = stream.readInt();

		for (int i = 0; i < entries; ++i) {
			K key = stream.readObject();
			V value = stream.readObject();
			((Collection) map.get(key)).add(value);
		}

		this.setMap(map);
	}
}