package com.ibm.ejs.util.am;

import com.ibm.ejs.util.am.AlarmManager.Implementation;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;

public class AlarmManager {
	private static Implementation impl = new AlarmManagerCSLM();
	static final long startTime = System.nanoTime();

	public static final Alarm create(long n, AlarmListener listener, Object alarmContext) {
		return impl.createDeferrable(n, listener, alarmContext);
	}

	public static final Alarm create(long n, AlarmListener listener) {
		return impl.createDeferrable(n, listener, (Object) null);
	}

	public static ScheduledExecutorService getNonDeferrableScheduledExecutorService() {
		return impl.getNonDeferrableScheduledExecutorService();
	}

	public static ScheduledExecutorService createNonDeferrableScheduledExecutorService(Executor executor) {
		return impl.createNonDeferrableScheduledExecutorService(executor);
	}

	public static final Alarm createNonDeferrable(long n, AlarmListener l, Object alarmContext) {
		return impl.createNonDeferrable(n, l, alarmContext);
	}

	public static final Alarm createNonDeferrable(long n, AlarmListener l, Object alarmContext, Executor executor) {
		return impl.createNonDeferrable(n, l, alarmContext, executor);
	}

	public static final Alarm createNonDeferrable(long n, AlarmListener l) {
		return impl.createNonDeferrable(n, l, (Object) null);
	}

	public static ScheduledExecutorService getDeferrableScheduledExecutorService() {
		return impl.getDeferrableScheduledExecutorService();
	}

	public static ScheduledExecutorService createDeferrableScheduledExecutorService(Executor executor) {
		return impl.createDeferrableScheduledExecutorService(executor);
	}

	public static final Alarm createDeferrable(long n, AlarmListener l, Object alarmContext) {
		return impl.createDeferrable(n, l, alarmContext);
	}

	public static final Alarm createDeferrable(long n, AlarmListener l) {
		return impl.createDeferrable(n, l, (Object) null);
	}

	public static final void stopMonitoring() {
		impl.stopMonitoring();
	}

	static final void cancel(Alarm a) {
		impl.cancel(a);
	}

	public static final boolean disableAlarm(Alarm a) {
		return impl.disableAlarm(a);
	}

	public static void incActiveWork() {
		impl.incActiveWork();
	}

	public static void decActiveWork() {
		impl.decActiveWork();
	}

	public static int getActiveWork() {
		return impl.getActiveWork();
	}

	public static long getMillisTime() {
		long time = System.nanoTime() - startTime;
		return time / 1000000L;
	}
}