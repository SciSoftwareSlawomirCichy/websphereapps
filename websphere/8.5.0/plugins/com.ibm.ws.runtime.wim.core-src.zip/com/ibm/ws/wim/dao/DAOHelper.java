package com.ibm.ws.wim.dao;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.bootstrap.ExtClassLoader;
import com.ibm.ws.runtime.service.VariableMap;
import com.ibm.wsspi.runtime.service.WsServiceRegistry;
import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DAOHelper extends DAOHelperBase {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public static Class loadJDBCClass(String var0) throws WIMSystemException {
		Class var2 = null;
		Object var3 = null;
		String var4 = null;
		trcLogger.entering(CLASSNAME, "loadJDBCClass(String dbDriver)", "dbDriver=" + var0);
		if ((var2 = (Class) dbClassMap.get(var0)) == null) {
			trcLogger.log(Level.FINE, "Loading JDBC driver class: " + var0);
			var3 = ExtClassLoader.getInstance();
			if (var3 == null) {
				var3 = DAOHelper.class.getClassLoader();
			}

			try {
				String var5 = "${VMM_JDBC_CLASSPATH}";
				trcLogger.log(Level.FINER, "Getting " + var5 + " using variable map...");
				VariableMap var6 = (VariableMap) WsServiceRegistry.getService("", VariableMap.class);
				var4 = var6.expand(var5);
				trcLogger.log(Level.FINER, "Custom classloader WAS variable: VMM_JDBC_CLASSPATH=" + var4);
				if (var4 == null) {
					trcLogger.log(Level.FINER, "Using default classloader");
				} else {
					trcLogger.log(Level.FINER, "Building custom classloader...");
					ArrayList var7 = new ArrayList();
					StringTokenizer var8 = new StringTokenizer(var4, File.pathSeparator);

					while (var8.hasMoreTokens()) {
						File var9 = new File(var8.nextToken());
						var7.add(var9.toURL());
						trcLogger.log(Level.FINER, "\tAdded classpath entry: " + var9);
					}

					URL[] var12 = (URL[]) ((URL[]) var7.toArray(new URL[var7.size()]));
					var3 = new URLClassLoader(var12, DAOHelper.class.getClassLoader());
				}
			} catch (Exception var11) {
				trcLogger.log(Level.FINE, "Failed to retrieve WAS variable: VMM_JDBC_CLASSPATH", var11);
			}

			try {
				trcLogger.log(Level.FINER, "Loading JDBC driver... using " + var3);
				var2 = ((ClassLoader) var3).loadClass(var0);
				trcLogger.log(Level.FINER, "Loaded JDBC driver successfully");
			} catch (ClassNotFoundException var10) {
				throw new WIMSystemException(var10);
			}

			dbClassMap.put(var0, var2);
		} else {
			trcLogger.log(Level.FINE, "Retrieving JDBC driver class from cache: " + var0);
		}

		trcLogger.exiting(CLASSNAME, "loadJDBCClass(String dbDriver)");
		return var2;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = DAOHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}