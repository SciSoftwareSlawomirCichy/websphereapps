package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.security.certclient.util.PkNewCertFactory;
import com.ibm.security.certclient.util.PkNewCertificate;
import com.ibm.security.certclient.util.PkSsCertFactory;
import com.ibm.security.certclient.util.PkSsCertificate;
import com.ibm.websphere.crypto.KeyException;
import com.ibm.websphere.ssl.SSLException;
import com.ibm.ws.security.config.SecurityConfigObject;
import com.ibm.ws.security.config.SecurityObjectLocator;
import com.ibm.ws.security.util.KeyStoreTypeHelper;
import com.ibm.ws.ssl.JSSEProviderFactory;
import com.ibm.ws.ssl.core.TraceNLSHelper;
import com.ibm.ws.ssl.model.CertReqInfo;
import com.ibm.ws.ssl.model.KeyStoreInfo;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.management.ObjectName;

public class CertificateManager {
	private static final TraceComponent tc = Tr.register(CertificateManager.class, "SSL",
			"com.ibm.ws.ssl.resources.ssl");
	private static CertificateManager thisClass = null;

	public static CertificateManager getInstance() {
		if (thisClass == null) {
			thisClass = new CertificateManager();
		}

		return thisClass;
	}

	public Certificate selfSignedCertificateCreate(CertReqInfo ssCertInfo) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "selfSignedCertificateCreate", new Object[]{ssCertInfo});
		}

		InputStream is = null;
		FileOutputStream fos = null;
		String alias = null;
		String subjectDN = null;
		int size = false;
		int validDays = false;
		KeyStoreInfo keyStoreInfo = null;
		String keyStoreFile = null;
		String keyStoreType = null;
		String keyStoreProvider = null;
		String password = null;
		subjectDN = ssCertInfo.getSubjectDN();
		alias = ssCertInfo.getLabel();
		int size = ssCertInfo.getSize();
		int validDays = ssCertInfo.getValidDays();
		keyStoreInfo = ssCertInfo.getKsInfo();
		keyStoreFile = KeyStoreManager.getInstance().expand(keyStoreInfo.getLocation());
		keyStoreType = keyStoreInfo.getType();
		keyStoreProvider = keyStoreInfo.getProvider();
		password = keyStoreInfo.getPassword();
		Boolean stash = keyStoreInfo.getStashFile();
		PkSsCertificate SsCertificate = null;
		Certificate certificate = null;
		KeyStore ks = null;

		try {
			boolean isCA = false;
			if (ssCertInfo.getKsInfo().getName().endsWith("DefaultRootStore")
					|| ssCertInfo.getKsInfo().getName().endsWith("RSATokenRootStore")) {
				isCA = true;
			}

			Date deltaDate = new Date();
			deltaDate.setTime(deltaDate.getTime() - 86400000L);
			ArrayList subjectAltNames = new ArrayList();

			String ssCertificate;
			try {
				ssCertificate = SecurityObjectLocator.getAdminData().getUserInstallRootPath();
				if (ssCertificate != null) {
					Class cl1 = Class.forName("com.ibm.ws.ssl.commands.ProfileCreation.PrepareKeysUtility");
					Method theMethod1 = cl1.getMethod("getProfileUUID", String.class, Object.class);
					String profileUUID = (String) theMethod1.invoke((Object) null, ssCertificate, null);
					if (tc.isDebugEnabled()) {
						Tr.debug(tc,
								"Retrieved the following profileUUID for the alternate Subject name: " + profileUUID);
					}

					subjectAltNames.add("ProfileUUID:" + profileUUID);
				} else {
					subjectAltNames.add("ProfileUUID:" + subjectDN);
				}
			} catch (Exception var33) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception creating profileUUID, using subjectDN instead: " + subjectDN,
							new Object[]{var33});
				}

				subjectAltNames.add("ProfileUUID:" + subjectDN);
			}

			ssCertificate = null;
			String jceProvider = Security.getProperty("DEFAULT_JCE_PROVIDER");
			if (jceProvider == null || jceProvider.trim().isEmpty()) {
				if (!JSSEProviderFactory.isFipsEnabled()) {
					jceProvider = "IBMJCE";
				} else {
					jceProvider = "IBMJCEFIPS";
				}
			}

			try {
				SsCertificate = PkSsCertFactory.newSsCert(size, subjectDN, validDays, deltaDate, true, true,
						subjectAltNames, (List) null, (List) null, jceProvider, (KeyPair) null, isCA);
			} catch (NoSuchMethodError var34) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Certificate Signing API's are not available: " + var34.getMessage());
				}

				SsCertificate = PkSsCertFactory.newSsCert(size, subjectDN, validDays, deltaDate, true, true,
						subjectAltNames, (List) null, (List) null, jceProvider, (KeyPair) null);
			}

			try {
				Tr.audit(tc,
						"Self Signed Certificate: notBefore time: "
								+ SsCertificate.getCertificate().getNotBefore().toString() + " notAfter time: "
								+ SsCertificate.getCertificate().getNotAfter().toString());
			} catch (Throwable var32) {
				;
			}

			ks = KeyStore.getInstance(keyStoreType, keyStoreProvider);
			if (keyStoreFile == null || keyStoreFile.equals("")) {
				throw new FileNotFoundException("KeyStore file path cannot not be missing or null.");
			}

			File f = new File(keyStoreFile);
			Method theMethod1;
			Class cl1;
			if (!f.exists()) {
				ks.load((InputStream) null, password.toCharArray());
			} else if (KeyStoreTypeHelper.isCMSKeyStore(keyStoreType)) {
				cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
				theMethod1 = cl1.getMethod("loadCMSKeyStore", File.class, String.class, String.class, String.class,
						String.class, String.class);
				ks = (KeyStore) theMethod1.invoke(cl1.newInstance(), f, keyStoreFile, password, keyStoreType,
						keyStoreProvider, stash.toString());
			} else {
				is = KeyStoreManager.getInstance().getInputStream(keyStoreFile, true);
				ks.load(is, password.toCharArray());
			}

			SsCertificate.setToKeyStore(alias, password, ks);
			certificate = ks.getCertificate(alias);
			if (KeyStoreTypeHelper.isCMSKeyStore(keyStoreType)) {
				cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
				theMethod1 = cl1.getMethod("storeCMSKeyStore", KeyStore.class, String.class, String.class, String.class,
						String.class);
				theMethod1.invoke(cl1.newInstance(), ks, keyStoreFile, password, keyStoreType, stash.toString());
			} else if (keyStoreInfo.getFileBased()) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "KeyStore is file based");
				}

				fos = new FileOutputStream(keyStoreFile);
				ks.store(fos, password.toCharArray());
			} else {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "KeyStore is not file based");
				}

				URL ring = new URL(keyStoreFile);
				URLConnection ringConnect = ring.openConnection();
				OutputStream os = ringConnect.getOutputStream();
				ks.store(os, password.toCharArray());
			}
		} catch (Exception var35) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Error creating keystore or certificate.", new Object[]{var35});
			}

			Tr.error(tc, "ssl.self.signed.create.error.CWPKI0032E", new Object[]{var35.getMessage()});
			String message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.self.signed.create.error.CWPKI0032E",
					new Object[]{var35.getMessage()},
					"Error creating a self-signed certificate.  The exception is " + var35.getMessage());
			throw new SSLException(message, var35);
		} finally {
			if (is != null) {
				is.close();
			}

			if (fos != null) {
				fos.close();
			}

		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "selfSignedCertificateCreate");
		}

		return certificate;
	}

	public Certificate chainedCertificateCreate(CertReqInfo chainedCertInfo, String rootCertificateAlias,
			KeyStoreInfo rootKeyStore) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chainedCertificateCreate", new Object[]{chainedCertInfo, rootCertificateAlias});
		}

		if (chainedCertInfo != null && tc.isDebugEnabled()) {
			Tr.entry(tc, "chainedCertificateCreate", "chainedCertInfo=" + chainedCertInfo.toString());
		}

		if (rootCertificateAlias != null && tc.isDebugEnabled()) {
			Tr.entry(tc, "rootCertificateAlias", "rootCertificateAlias=" + rootCertificateAlias);
		}

		if (rootKeyStore != null && tc.isDebugEnabled()) {
			Tr.entry(tc, "rootKeyStore", "rootKeyStore=" + rootKeyStore.toString());
		}

		String subjectDN = chainedCertInfo.getSubjectDN();
		String alias = chainedCertInfo.getLabel();
		int keySize = chainedCertInfo.getSize();
		int validDays = chainedCertInfo.getValidDays();
		KeyStoreInfo keyStoreInfo = chainedCertInfo.getKsInfo();
		String keyStoreFile = keyStoreInfo.getLocation();
		String keyStoreType = keyStoreInfo.getType();
		String keyStoreUsage = keyStoreInfo.getUsage();
		String keyStoreProvider = keyStoreInfo.getProvider();
		String password = keyStoreInfo.getPassword();
		Boolean stash = keyStoreInfo.getStashFile();
		SecurityConfigObject rootKeyStoreObject = null;
		String rootKeyStoreName = null;
		String rootPassword = null;
		if (rootKeyStore == null) {
			if (keyStoreUsage != null && keyStoreUsage.equals("RSATokenKeys")) {
				rootKeyStoreObject = KeyStoreManager.getDefaultKeyStore("RSATokenRootStore", (String) null);
			} else {
				rootKeyStoreObject = KeyStoreManager.getDefaultKeyStore("DefaultRootStore", (String) null);
			}

			if (rootKeyStoreObject == null) {
				return this.selfSignedCertificateCreate(chainedCertInfo);
			}

			rootKeyStoreName = rootKeyStoreObject.getString("name");
			rootPassword = rootKeyStoreObject.getDecodedString("password");
		} else {
			rootKeyStoreName = rootKeyStore.getName();
			rootPassword = rootKeyStore.getPassword();
		}

		WSKeyStore rootStore = null;
		if (rootKeyStore == null) {
			rootStore = new WSKeyStore(rootKeyStoreObject);
		} else {
			rootStore = new WSKeyStore(rootKeyStore);
		}

		String method = "containsAlias";
		Object[] parms = new Object[]{rootCertificateAlias};
		Object[] containsAlias = rootStore.invokeKeyStoreCommand(method, parms, true);
		if (tc.isDebugEnabled()) {
			Tr.debug(tc,
					"containsAlias[0] is " + (Boolean) containsAlias[0] + "rootKeyStoreObject " + rootKeyStoreObject);
		}

		String rootSubjectDN;
		String message;
		if (!(Boolean) containsAlias[0] && rootKeyStoreObject != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "The root certificate does not exist so create it.");
			}

			rootSubjectDN = null;
			int rootValidDays = 7300;
			int rootCertKeySize = Integer.parseInt("2048");
			String cellName = ManagementScopeManager.getInstance().getCellName();
			message = ManagementScopeManager.getInstance().getNodeName();
			if (rootSubjectDN == null) {
				rootSubjectDN = "cn=${hostname},ou=Root Certificate,ou=" + cellName + ",ou=" + message + ",o=IBM,c=US";
			}

			SSLConfigManager sslConfigManager = SSLConfigManager.getInstance();
			String rootCertReqSubjectDNCustomProp = sslConfigManager.getGlobalProperty("com.ibm.ssl.rootCertSubjectDN");
			String rootCertReqAliasCustomProp = sslConfigManager.getGlobalProperty("com.ibm.ssl.rootCertAlias");
			String rootCertReqValidDaysCustomProp = sslConfigManager.getGlobalProperty("com.ibm.ssl.rootCertValidDays");
			String rootCertReqKeySizeCustomProp = sslConfigManager.getGlobalProperty("com.ibm.ssl.rootCertKeySize");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc,
						"RootCertCustom Props: com.ibm.ssl.rootCertSubjectDN is set to "
								+ rootCertReqSubjectDNCustomProp + " " + "com.ibm.ssl.rootCertAlias" + " is set to "
								+ rootCertReqAliasCustomProp + " " + "com.ibm.ssl.rootCertValidDays" + " is set to "
								+ rootCertReqValidDaysCustomProp + " " + "com.ibm.ssl.rootCertKeySize" + " is set to "
								+ rootCertReqKeySizeCustomProp);
			}

			if (rootCertReqSubjectDNCustomProp != null) {
				rootSubjectDN = rootCertReqSubjectDNCustomProp;
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "rootSubjectDN has been updated.");
				}
			}

			if (rootCertReqAliasCustomProp != null) {
				rootCertificateAlias = rootCertReqAliasCustomProp;
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "rootCertificateAlias has been updated.");
				}
			}

			if (rootCertReqValidDaysCustomProp != null) {
				rootValidDays = Integer.parseInt(rootCertReqValidDaysCustomProp);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "rootValidDays has been updated.");
				}
			}

			if (rootCertReqKeySizeCustomProp != null) {
				rootCertKeySize = Integer.parseInt(rootCertReqKeySizeCustomProp);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "rootCertkeySize has been updated.");
				}
			}

			String host = null;

			try {
				host = InetAddress.getLocalHost().getCanonicalHostName();
			} catch (UnknownHostException var45) {
				if (!System.getProperty("os.name").equals("OS/400")) {
					throw var45;
				}

				host = "LOOPBACK";
			}

			rootSubjectDN = KeyStoreManager.expandHostNameVariable(rootSubjectDN, host);
			KeyStoreInfo rootKeyStoreInfo = new KeyStoreInfo(rootKeyStoreName,
					rootKeyStoreObject.getUnexpandedString("location"), rootPassword,
					rootKeyStoreObject.getString("provider"), rootKeyStoreObject.getString("type"),
					rootKeyStoreObject.getBoolean("fileBased"), (String) null, (String) null, (ObjectName) null,
					rootKeyStoreObject.getBoolean("readOnly"), (Boolean) null, (Boolean) null, (String) null,
					(Integer) null, (Boolean) null, (List) null, (String) null);
			CertReqInfo rootCertInfo = new CertReqInfo(rootCertificateAlias, keySize, rootSubjectDN, rootValidDays,
					rootKeyStoreInfo, rootKeyStoreObject.getUnexpandedString("location"));
			this.selfSignedCertificateCreate(rootCertInfo);
			rootStore.clearJavaKeyStore();
			rootStore = new WSKeyStore(rootKeyStoreObject);
		}

		rootSubjectDN = null;

		PkNewCertificate chainedCert;
		try {
			chainedCert = this.chainedCertificateCreate(chainedCertInfo, rootCertificateAlias, rootStore,
					rootKeyStoreName, rootPassword.toCharArray());
		} catch (ClassNotFoundException var42) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Certificate Signing API's are not available: " + var42.getMessage());
			}

			return this.selfSignedCertificateCreate(chainedCertInfo);
		}

		InputStream is = null;
		FileOutputStream fos = null;

		try {
			KeyStore targetKeyStore = KeyStore.getInstance(keyStoreType, keyStoreProvider);
			File f = new File(keyStoreFile);
			if (!f.exists()) {
				targetKeyStore.load((InputStream) null, password.toCharArray());
			} else if (KeyStoreTypeHelper.isCMSKeyStore(keyStoreType)) {
				Class cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
				Method theMethod1 = cl1.getMethod("loadCMSKeyStore", File.class, String.class, String.class,
						String.class, String.class, String.class);
				targetKeyStore = (KeyStore) theMethod1.invoke(cl1.newInstance(), f, keyStoreFile, password,
						keyStoreType, keyStoreProvider, stash.toString());
			} else {
				is = KeyStoreManager.getInstance().getInputStream(keyStoreFile, true);
				targetKeyStore.load(is, password.toCharArray());
			}

			chainedCert.setToKeyStore(alias, password, targetKeyStore);
			Certificate[] certificateChain = targetKeyStore.getCertificateChain(alias);
			if (KeyStoreTypeHelper.isCMSKeyStore(keyStoreType)) {
				Class cl1 = Class.forName("com.ibm.ws.ssl.config.CMSKeyStoreUtility");
				Method theMethod1 = cl1.getMethod("storeCMSKeyStore", KeyStore.class, String.class, String.class,
						String.class, String.class);
				theMethod1.invoke(cl1.newInstance(), targetKeyStore, keyStoreFile, password, keyStoreType,
						stash.toString());
			} else if (keyStoreInfo.getFileBased()) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "KeyStore is a file based");
				}

				fos = new FileOutputStream(keyStoreFile);
				targetKeyStore.store(fos, password.toCharArray());
			} else {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "KeyStore is not file based");
				}

				URL ring = new URL(keyStoreFile);
				URLConnection ringConnect = ring.openConnection();
				OutputStream os = ringConnect.getOutputStream();
				targetKeyStore.store(os, password.toCharArray());
			}

			X509Certificate[] chainedCertificate = chainedCert.getCertificateChain();

			try {
				Tr.audit(tc,
						"Chained Certificate\n\t Owner: " + chainedCertificate[0].getSubjectDN() + "\n\t" + " Issuer: "
								+ chainedCertificate[0].getIssuerDN() + "\n\t" + " Not Before: "
								+ chainedCertificate[0].getNotBefore().toString() + "\n\t" + " Not After: "
								+ chainedCertificate[0].getNotAfter().toString() + "\n\t" + " Serial: "
								+ chainedCertificate[0].getSerialNumber());
			} catch (Throwable var41) {
				;
			}

			if (certificateChain != null && certificateChain.length > 0) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "chainedCertificateCreate (success)");
				}

				Certificate var59 = certificateChain[certificateChain.length - 1];
				return var59;
			}
		} catch (Exception var43) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Error creating keystore or certificate.", new Object[]{var43});
			}

			Tr.error(tc, "ssl.chained.create.error.CWPKI0043E", new Object[]{var43.getMessage()});
			message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.chained.create.error.CWPKI0043E",
					new Object[]{var43.getMessage()},
					"Error creating a chained certificate.  The exception is " + var43.getMessage());
			throw new SSLException(message, var43);
		} finally {
			if (is != null) {
				is.close();
			}

			if (fos != null) {
				fos.close();
			}

		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "chainedCertificateCreate (null)");
		}

		return null;
	}

	public PkNewCertificate chainedCertificateCreate(CertReqInfo chainedCertInfo, String rootCertificateAlias,
			WSKeyStore rootStore, String rootKeyStoreName, char[] rootPassword) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "chainedCertificateCreate", new Object[]{chainedCertInfo});
		}

		InputStream is = null;
		FileOutputStream fos = null;
		String subjectDN = chainedCertInfo.getSubjectDN();
		String alias = chainedCertInfo.getLabel();
		int keySize = chainedCertInfo.getSize();
		int validDays = chainedCertInfo.getValidDays();

		try {
			Thread.currentThread().getContextClassLoader()
					.loadClass("com.ibm.security.certclient.util.PkNewCertFactory");
		} catch (ClassNotFoundException var29) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Certificate Signing API's are not available: " + var29.getMessage());
			}

			throw var29;
		}

		PkNewCertificate chainedCert = null;
		Certificate[] rootCertChain = null;
		X509Certificate[] rootCertChainX509 = null;
		PrivateKey rootPrivateKey = null;
		ArrayList subjectAltNames = new ArrayList();

		String method;
		try {
			method = SecurityObjectLocator.getAdminData().getUserInstallRootPath();
			if (method != null) {
				Class cl1 = Class.forName("com.ibm.ws.ssl.commands.ProfileCreation.PrepareKeysUtility");
				Method theMethod1 = cl1.getMethod("getProfileUUID", String.class, Object.class);
				String profileUUID = (String) theMethod1.invoke((Object) null, method, null);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Retrieved the following profileUUID for the alternate Subject name: " + profileUUID);
				}

				subjectAltNames.add("ProfileUUID:" + profileUUID);
			} else {
				subjectAltNames.add("ProfileUUID:" + subjectDN);
			}
		} catch (Exception var32) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception creating profileUUID, using subjectDN instead: " + subjectDN,
						new Object[]{var32});
			}

			subjectAltNames.add("ProfileUUID:" + subjectDN);
		}

		try {
			method = "containsAlias";
			Object[] parms = new Object[]{rootCertificateAlias};
			Object[] containsAlias = rootStore.invokeKeyStoreCommand(method, parms);
			method = "isKeyEntry";
			parms = new Object[]{rootCertificateAlias};
			Object[] isKeyEntry = rootStore.invokeKeyStoreCommand(method, parms);
			String msg;
			if (!(Boolean) containsAlias[0]) {
				msg = TraceNLSHelper.getInstance().getFormattedMessage("ssl.command.cert.does.not.exist.CWPKI0655E",
						new Object[]{alias, rootKeyStoreName}, "Certificate alias \"" + rootCertificateAlias
								+ "\" does not exist in key store \"" + rootKeyStoreName + "\".");
				throw new Exception(msg);
			}

			if (!(Boolean) isKeyEntry[0]) {
				msg = TraceNLSHelper.getInstance().getFormattedMessage("ssl.command.not.personal.cert.CWPKI0666E",
						new Object[]{alias},
						"Certificate \"" + rootCertificateAlias + "\" is not a personal certificate.");
				throw new Exception(msg);
			}

			method = "getCertificateChain";
			parms = new Object[]{rootCertificateAlias};
			Object[] certArray = rootStore.invokeKeyStoreCommand(method, parms);
			rootCertChain = (Certificate[]) ((Certificate[]) certArray[0]);
			if (rootCertChain != null) {
				rootCertChainX509 = new X509Certificate[rootCertChain.length];

				for (int i = 0; i < rootCertChain.length; ++i) {
					rootCertChainX509[i] = (X509Certificate) rootCertChain[i];
				}
			}

			if (rootCertChainX509[0].getBasicConstraints() == -1) {
				String msg = TraceNLSHelper.getInstance().getFormattedMessage("ssl.command.cert.not.ca.CWPKI0701E",
						new Object[]{alias}, "Certificate specified as alias \"" + rootCertificateAlias
								+ "\" is not a certificate authority (CA) certificate");
				throw new Exception(msg);
			}

			method = "getKey";
			parms = new Object[]{rootCertificateAlias, rootPassword};
			Object[] key = rootStore.invokeKeyStoreCommand(method, parms);
			rootPrivateKey = (PrivateKey) key[0];
			boolean isCA = false;
			if (chainedCertInfo.getKsInfo().getName().endsWith("DefaultRootStore")) {
				isCA = true;
			}

			Date deltaDate = new Date();
			deltaDate.setTime(deltaDate.getTime() - 86400000L);
			String jceProvider = Security.getProperty("DEFAULT_JCE_PROVIDER");
			chainedCert = PkNewCertFactory.newCert(keySize, subjectDN, validDays, deltaDate, true, subjectAltNames,
					(List) null, (List) null, jceProvider, (KeyPair) null, rootCertChainX509, rootPrivateKey, isCA);
		} catch (Exception var30) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Error creating keystore or certificate.", new Object[]{var30});
			}

			Tr.error(tc, "ssl.chained.create.error.CWPKI0043E", new Object[]{var30.getMessage()});
			String message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.chained.create.error.CWPKI0043E",
					new Object[]{var30.getMessage()},
					"Error creating a chained certificate.  The exception is " + var30.getMessage());
			throw new SSLException(message, var30);
		} finally {
			if (is != null) {
				((InputStream) is).close();
			}

			if (fos != null) {
				((FileOutputStream) fos).close();
			}

		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "chainedCertificateCreate");
		}

		return chainedCert;
	}

	public boolean isKeyCertJarAvailable() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isKeyCertJarAvailable");
		}

		boolean result = true;
		String clz = "com.ibm.security.certclient.util.PkSsCertFactory";

		try {
			Thread.currentThread().getContextClassLoader().loadClass(clz);
		} catch (ClassNotFoundException var4) {
			if (tc.isEntryEnabled()) {
				Tr.debug(tc, "isKeyCertJarAvailable", "Unable to load class \"" + clz + "\".");
			}

			result = false;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isKeyCertJarAvailable", result);
		}

		return result;
	}

	public byte[] getEncodedRootSigner(String type) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getEncodedRootSigner", new Object[]{type});
		}

		Certificate cert = this.getRootSigner(type);
		if (cert != null) {
			try {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getEncodedRootSigner (success)");
				}

				return (byte[]) cert.getEncoded();
			} catch (CertificateEncodingException var4) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Error encoding root signer.", new Object[]{var4});
				}

				Manager.Ffdc.log(var4, this, "com.ibm.ws.ssl.config.CertificateManager.getEncodedRootSigner", "600",
						new Object[]{this});
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getEncodedRootSigner (null)");
		}

		return null;
	}

	public Certificate getRootSigner(String type) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getRootSigner", new Object[]{type});
		}

		Certificate[] cert = null;
		String keyStoreName = null;
		String alias = null;
		WSKeyStore wsks = null;
		if (type.equalsIgnoreCase("SSL")) {
			keyStoreName = KeyStoreManager.getDefaultKeyStoreName("DefaultKeyStore");
			wsks = KeyStoreManager.getInstance().getKeyStore(keyStoreName);
			alias = SecurityObjectLocator.getSecurityConfig().getProperty("com.ibm.ssl.rootCertAlias");
			if (alias == null || alias.length() == 0) {
				alias = "default";
			}
		} else {
			if (!type.equalsIgnoreCase("RSA")) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getRootSigner: Invalid input \"type\".");
				}

				return null;
			}

			keyStoreName = KeyStoreManager.getDefaultKeyStoreName("RSATokenKeyStore");
			wsks = KeyStoreManager.getInstance().getKeyStore(keyStoreName);
			alias = SecurityObjectLocator.getSecurityConfig().getProperty("com.ibm.rsa.rootCertAlias");
			if (alias == null || alias.length() == 0) {
				alias = "default";
			}
		}

		WSKeyStoreRemotableInterface wsksr = null;
		if (wsks != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Getting remotable instance of WSKeyStore name: " + keyStoreName);
			}

			wsksr = WSKeyStoreRemotableFactory.getInstance(wsks);
		}

		if (wsksr != null) {
			String method = "getCertificateChain";
			Object[] parms = new Object[]{alias};
			Object[] returnedData = null;

			try {
				returnedData = wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
				if (returnedData != null && returnedData[0] != null) {
					cert = (Certificate[]) ((Certificate[]) returnedData[0]);
					if (cert != null) {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "getRootSigner (success): "
									+ ((X509Certificate) cert[cert.length - 1]).getSubjectDN());
						}

						return cert[cert.length - 1];
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Did not get a certificate in returnedData from specific alias: " + alias);
					}
				} else {
					method = "aliases";
					parms = new Object[0];
					returnedData = null;
					returnedData = wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
					if (returnedData != null && returnedData[0] != null) {
						String[] aliases = (String[]) ((String[]) returnedData);

						for (int i = 0; i < aliases.length; ++i) {
							String newAlias = aliases[i];
							method = "isKeyEntry";
							parms = new Object[]{newAlias};
							returnedData = null;
							returnedData = wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
							if (returnedData != null && returnedData[0] != null) {
								Boolean isKeyEntry = (Boolean) returnedData[0];
								if (isKeyEntry) {
									method = "getCertificateChain";
									parms = new Object[]{newAlias};
									returnedData = null;
									returnedData = wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
									if (returnedData != null && returnedData.length > 0) {
										cert = (Certificate[]) ((Certificate[]) returnedData[0]);
										if (cert != null) {
											if (tc.isEntryEnabled()) {
												Tr.exit(tc, "getRootSigner (success): "
														+ ((X509Certificate) cert[cert.length - 1]).getSubjectDN());
											}

											return cert[cert.length - 1];
										}
									}
								} else if (tc.isDebugEnabled()) {
									Tr.debug(tc, "Alias \"" + newAlias + "\" is not a key entry.");
								}
							}
						}

						if (tc.isDebugEnabled()) {
							Tr.debug(tc,
									"Did not find a certificate from the list of aliases in the keystore that matched isKeyEntry().");
						}
					} else if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Did not find any certificates in the returnedData.");
					}
				}
			} catch (KeyException var14) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Error obtaining the root signer.", new Object[]{var14});
				}

				Manager.Ffdc.log(var14, this, "com.ibm.ws.ssl.config.CertificateManager.getRootSigner", "729",
						new Object[]{this});
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Error getting the root signer from keystore " + keyStoreName + ".");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getRootSigner (null)");
		}

		return null;
	}

	public void addRootSigner(Certificate cert, String type) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "addRootSigner", new Object[]{cert, type});
		}

		String keyStoreName = null;
		String alias = ((X509Certificate) cert).getSubjectDN().toString();
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Adding signer of type \"" + type + "\" with alias: " + alias);
		}

		if (type == null) {
			type = "SSL";
		}

		if (type.equalsIgnoreCase("SSL")) {
			keyStoreName = KeyStoreManager.getDefaultKeyStoreName("DefaultTrustStore");
		} else {
			if (!type.equalsIgnoreCase("RSA")) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "addRootSigner: Invalid input \"type\".");
				}

				return;
			}

			keyStoreName = KeyStoreManager.getDefaultKeyStoreName("RSATokenTrustStore");
		}

		WSKeyStore wsks = KeyStoreManager.getInstance().getKeyStore(keyStoreName);
		WSKeyStoreRemotableInterface wsksr = null;
		if (wsks != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Getting remotable instance of WSKeyStore.");
			}

			wsksr = WSKeyStoreRemotableFactory.getInstance(wsks);
		}

		if (wsksr != null) {
			Boolean ksReadOnly = Boolean.getBoolean(wsks.getProperty("com.ibm.ssl.keyStoreReadOnly"));
			if (ksReadOnly) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "addRootSigner (read-only, noop)");
				}

				return;
			}

			try {
				String method = "reinitializeKeyStore";
				Object[] parms = null;
				Object[] returnedData = null;
				wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "keyStore reinitialized");
				}

				method = "getCertificateAlias";
				parms = new Object[]{cert};
				returnedData = null;
				returnedData = wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
				if (returnedData != null && returnedData[0] != null && !returnedData[0].equals("<null>")) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "addRootSigner (already exists)", new Object[]{returnedData[0]});
					}

					return;
				}

				method = "setCertificateEntry";
				parms = new Object[]{alias, cert};
				wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
				wsksr.store();
				KeyStoreManager.getInstance().clearJavaKeyStoresFromKeyStoreMap();
				AbstractJSSEProvider.clearSSLContextCache();
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Successfully added signer to keystore: " + keyStoreName);
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "addRootSigner (success)");
				}

				return;
			} catch (Exception var11) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Error adding the root signer.", new Object[]{var11});
				}

				Manager.Ffdc.log(var11, this, "com.ibm.ws.ssl.config.CertificateManager.addRootSigner", "812",
						new Object[]{this});
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Adding the root signer to keystore " + keyStoreName + ".");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addRootSigner");
		}

	}

	public void deleteRootSigner(Certificate cert, String type) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "deleteRootSigner", new Object[]{cert, type});
		}

		String keyStoreName = null;
		String alias = null;
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Deleting signer of type \"" + type + "\".");
		}

		if (type == null) {
			type = "SSL";
		}

		if (type.equalsIgnoreCase("SSL")) {
			keyStoreName = KeyStoreManager.getDefaultKeyStoreName("DefaultTrustStore");
		} else {
			if (!type.equalsIgnoreCase("RSA")) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "deleteRootSigner: Invalid input \"type\".");
				}

				return;
			}

			keyStoreName = KeyStoreManager.getDefaultKeyStoreName("RSATokenTrustStore");
		}

		WSKeyStore wsks = KeyStoreManager.getInstance().getKeyStore(keyStoreName);
		WSKeyStoreRemotableInterface wsksr = null;
		if (wsks != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Getting remotable instance of WSKeyStore.");
			}

			wsksr = WSKeyStoreRemotableFactory.getInstance(wsks);
		}

		if (wsksr != null) {
			Boolean ksReadOnly = Boolean.getBoolean(wsks.getProperty("com.ibm.ssl.keyStoreReadOnly"));
			if (ksReadOnly) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "deleteRootSigner (read-only, noop)");
				}

				return;
			}

			String method = "reinitializeKeyStore";
			Object[] parms = null;
			Object[] returnedData = null;

			try {
				wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "keyStore reinitialized");
				}

				method = "getCertificateAlias";
				parms = new Object[]{cert};
				returnedData = null;
				returnedData = wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
				if (returnedData != null && returnedData[0] != null && !returnedData[0].equals("<null>")) {
					alias = (String) returnedData[0];
					if (alias != null) {
						method = "deleteEntry";
						parms = new Object[]{alias};
						wsksr.invokeKeyStoreCommand(method, parms, Boolean.FALSE);
						wsksr.store();
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "deleteRootSigner (success)");
						}

						return;
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Did not get a certificate from the returned data.");
					}
				} else if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Did not get any returned data.");
				}
			} catch (Exception var12) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Error deleting the root signer.", new Object[]{var12});
				}

				Manager.Ffdc.log(var12, this, "com.ibm.ws.ssl.config.CertificateManager.deleteRootSigner", "896",
						new Object[]{this});
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Did not delete root signer from keystore " + keyStoreName + ".");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "deleteRootSigner");
		}

	}

	public EncodedCertificateInfo createPersonalCertificate(CertReqInfo certRequestInfo, String type) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createPersonalCertificate", new Object[]{certRequestInfo, type});
		}

		SecurityConfigObject rootKeyStoreObject = null;
		String rootKeyStoreName = null;
		String rootPassword = null;
		String alias = "root";

		try {
			if (type.equalsIgnoreCase("SSL")) {
				rootKeyStoreObject = KeyStoreManager.getDefaultKeyStore("DefaultRootStore", (String) null);
				alias = SecurityObjectLocator.getSecurityConfig().getProperty("com.ibm.ws.ssl.rootCertAlias");
				if (alias == null || alias.length() == 0) {
					alias = "root";
				}

				rootKeyStoreName = rootKeyStoreObject.getString("name");
				rootPassword = rootKeyStoreObject.getDecodedString("password");
			} else {
				if (!type.equalsIgnoreCase("RSA")) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "getRootSigner: Invalid input \"type\".");
					}

					return null;
				}

				rootKeyStoreObject = KeyStoreManager.getDefaultKeyStore("RSATokenRootStore", (String) null);
				alias = SecurityObjectLocator.getSecurityConfig().getProperty("com.ibm.ws.rsa.rootCertAlias");
				if (alias == null || alias.length() == 0) {
					alias = "root";
				}

				rootKeyStoreName = rootKeyStoreObject.getString("name");
				rootPassword = rootKeyStoreObject.getDecodedString("password");
			}

			WSKeyStore wsks = KeyStoreManager.getInstance().getKeyStore(rootKeyStoreName);
			PkNewCertificate chainedCert = this.chainedCertificateCreate(certRequestInfo, alias, wsks, rootKeyStoreName,
					rootPassword.toCharArray());
			return new EncodedCertificateInfo(chainedCert);
		} catch (Exception var9) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception creating a personal certificate.", new Object[]{var9});
			}

			Manager.Ffdc.log(var9, this, "com.ibm.ws.ssl.config.CertificateManager.createPersonalCertificate", "980",
					new Object[]{this});
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "createPersonalCertificate");
			}

			return null;
		}
	}

	public Certificate[] createPersonalCertificate(byte[] cert_request, String type) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createPersonalCertificate");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createPersonalCertificate");
		}

		return null;
	}

	public String incrementAlias(KeyStore jKeyStore, String alias) throws KeyStoreException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "incrementAlias", new Object[]{alias});
		}

		int num = 1;
		String newAlias = null;
		int aliasLi = true;
		String last = null;
		String first = null;

		do {
			try {
				if (newAlias != null) {
					alias = newAlias;
				}

				int aliasLi = alias.lastIndexOf(95);
				if (aliasLi == -1) {
					throw new NumberFormatException();
				}

				last = alias.substring(aliasLi + 1);
				first = alias.substring(0, aliasLi + 1);
				int n = Integer.parseInt(last);
				StringBuilder var10000 = (new StringBuilder()).append(first);
				++n;
				newAlias = var10000.append(last.replaceAll(last, Integer.toString(n))).toString();
			} catch (NumberFormatException var9) {
				newAlias = alias + "_" + num++;
			}
		} while (jKeyStore.containsAlias(newAlias));

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "incrementAlias", new Object[]{newAlias});
		}

		return newAlias;
	}

	private void runTest() {
		KeyStoreInfo ksi = new KeyStoreInfo("PeteKeyStore", "c:/temp/pete_key.p12", "WebAS", "IBMJCE", "PKCS12",
				Boolean.TRUE, "", (String) null, (ObjectName) null, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE,
				(String) null, (Integer) null, Boolean.FALSE, (List) null, "Pete's key store");
		CertReqInfo cri = new CertReqInfo("mycert", 1024, "cn=pete,o=ibm,c=us", 365, ksi, ksi.getLocation());
		EncodedCertificateInfo eci_rsa = this.createPersonalCertificate(cri, "RSA");
		System.out.println(eci_rsa);
		byte[] eci_rsa_bytes = eci_rsa.getBytes();
		EncodedCertificateInfo eci_rsa_after_decode = EncodedCertificateInfo.createFromBytes(eci_rsa_bytes);
		System.out.println(eci_rsa_after_decode);
		EncodedCertificateInfo eci_ssl = this.createPersonalCertificate(cri, "SSL");
		System.out.println(eci_ssl);
		byte[] eci_ssl_bytes = eci_ssl.getBytes();
		EncodedCertificateInfo eci_ssl_after_decode = EncodedCertificateInfo.createFromBytes(eci_ssl_bytes);
		System.out.println(eci_ssl_after_decode);
	}
}