package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_pl extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: Dodano formater FFDC {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Mechanizm analizy używa bazy danych: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: Rozstrzygnięcie mechanizmu analizy nie powiodło się:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: Dodano kolektor danych FFDC {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: Usunięto kolektor danych FFDC {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: Zdarzenie FFDC zostało wyemitowane do obiektu SystemErr: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: Mechanizm FFDC działa w trybie bezpiecznym, sprawdź błędy {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: Dodano moduł przekazujący zdarzenia FFDC {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: Usunięto moduł przekazujący zdarzenia FFDC {0}"},
			{"FFDCIncidentEmitted",
					"FFDC1003I: Zdarzenie FFDC zostało wyemitowane w następującym miejscu: {0} {1} {2}"},
			{"FFDCProviderAborted", "FFDC1000I: Przerwano działanie dostawcy FFDC {0}, wystąpił poniższy wyjątek"},
			{"FFDCProviderAbortedE", "FFDC1001I: Przerwano działanie dostawcy FFDC, wystąpił wyjątek {0}"},
			{"FFDCProviderException", "FFDC1008I: Wyjątek dostawcy FFDC:"},
			{"FFDCProviderInstalled", "FFDC1007I: Zainstalowano dostawcę FFDC: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: Usunięto formater FFDC {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}