package com.ibm.bsf.test;

import com.ibm.bsf.BSFException;
import com.ibm.bsf.util.BSFEngineImpl;

public class fakeEngine extends BSFEngineImpl {
	public Object call(Object var1, String var2, Object[] var3) throws BSFException {
		return Boolean.TRUE;
	}

	public Object eval(String var1, int var2, int var3, Object var4) throws BSFException {
		return Boolean.TRUE;
	}

	public void iexec(String var1, int var2, int var3, Object var4) throws BSFException {
		System.out.print("PASSED");
	}

	public void exec(String var1, int var2, int var3, Object var4) throws BSFException {
		System.out.print("PASSED");
	}

	public void terminate() {
		super.terminate();
		System.out.print("PASSED");
	}
}