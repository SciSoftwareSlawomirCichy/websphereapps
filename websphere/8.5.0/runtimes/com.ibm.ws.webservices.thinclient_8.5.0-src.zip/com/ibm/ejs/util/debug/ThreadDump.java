package com.ibm.ejs.util.debug;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.process.Process;
import com.ibm.ws.process.ProcessFactory;
import com.ibm.ws.process.exception.ProcessOpException;

public class ThreadDump {
	private static Process proc = null;
	private static final TraceComponent tc = Tr.register(ThreadDump.class);

	public static void invoke() {
		Tr.entry(tc, "invoke");
		if (proc == null) {
			try {
				proc = ProcessFactory.createSelf();
			} catch (ProcessOpException var2) {
				FFDCFilter.processException(var2, "com.ibm.ejs.util.debug.ThreadDump.invoke", "46");
				Tr.error(tc, "Could not create process reference to self for dumping JVM thread stack.  Exception:"
						+ var2.toString());
			}
		}

		try {
			proc.generateJVMDump();
		} catch (ProcessOpException var1) {
			FFDCFilter.processException(var1, "com.ibm.ejs.util.debug.ThreadDump.invoke", "58");
			Tr.error(tc, "Could not dump JVM thread stack.  Exception:" + var1.toString());
		}

		Tr.exit(tc, "invoke");
	}
}