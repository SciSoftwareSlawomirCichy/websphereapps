package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.collect.ForwardingObject;
import com.google.common.util.concurrent.Service.Listener;
import com.google.common.util.concurrent.Service.State;
import java.util.concurrent.Executor;

@Deprecated
@Beta
public abstract class ForwardingService extends ForwardingObject implements Service {
	protected abstract Service delegate();

	public ListenableFuture<State> start() {
		return this.delegate().start();
	}

	public State state() {
		return this.delegate().state();
	}

	public ListenableFuture<State> stop() {
		return this.delegate().stop();
	}

	public State startAndWait() {
		return this.delegate().startAndWait();
	}

	public State stopAndWait() {
		return this.delegate().stopAndWait();
	}

	public boolean isRunning() {
		return this.delegate().isRunning();
	}

	public void addListener(Listener listener, Executor executor) {
		this.delegate().addListener(listener, executor);
	}

	public Throwable failureCause() {
		return this.delegate().failureCause();
	}

	protected State standardStartAndWait() {
		return (State) Futures.getUnchecked(this.start());
	}

	protected State standardStopAndWait() {
		return (State) Futures.getUnchecked(this.stop());
	}
}