package com.google.common.hash;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.hash.Hashing.1;
import com.google.common.hash.Hashing.ChecksumType;
import com.google.common.hash.Hashing.ConcatenatedHashFunction;
import com.google.common.hash.Hashing.LinearCongruentialGenerator;
import com.google.common.hash.Hashing.Md5Holder;
import com.google.common.hash.Hashing.Sha1Holder;
import com.google.common.hash.Hashing.Sha256Holder;
import com.google.common.hash.Hashing.Sha384Holder;
import com.google.common.hash.Hashing.Sha512Holder;
import java.security.Key;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import javax.crypto.spec.SecretKeySpec;

@Beta
public final class Hashing {
	static final int GOOD_FAST_HASH_SEED = (int) System.currentTimeMillis();

	public static HashFunction goodFastHash(int minimumBits) {
      int bits = checkPositiveAndMakeMultipleOf32(minimumBits);
      if (bits == 32) {
         return Murmur3_32HashFunction.GOOD_FAST_HASH_32;
      } else if (bits <= 128) {
         return Murmur3_128HashFunction.GOOD_FAST_HASH_128;
      } else {
         int hashFunctionsNeeded = (bits + 127) / 128;
         HashFunction[] hashFunctions = new HashFunction[hashFunctionsNeeded];
         hashFunctions[0] = Murmur3_128HashFunction.GOOD_FAST_HASH_128;
         int seed = GOOD_FAST_HASH_SEED;

         for(int i = 1; i < hashFunctionsNeeded; ++i) {
            seed += 1500450271;
            hashFunctions[i] = murmur3_128(seed);
         }

         return new ConcatenatedHashFunction(hashFunctions, (1)null);
      }
   }

	public static HashFunction murmur3_32(int seed) {
		return new Murmur3_32HashFunction(seed);
	}

	public static HashFunction murmur3_32() {
		return Murmur3_32HashFunction.MURMUR3_32;
	}

	public static HashFunction murmur3_128(int seed) {
		return new Murmur3_128HashFunction(seed);
	}

	public static HashFunction murmur3_128() {
		return Murmur3_128HashFunction.MURMUR3_128;
	}

	public static HashFunction sipHash24() {
		return SipHashFunction.SIP_HASH_24;
	}

	public static HashFunction sipHash24(long k0, long k1) {
		return new SipHashFunction(2, 4, k0, k1);
	}

	@Deprecated
	public static HashFunction md5() {
		return Md5Holder.MD5;
	}

	@Deprecated
	public static HashFunction sha1() {
		return Sha1Holder.SHA_1;
	}

	public static HashFunction sha256() {
		return Sha256Holder.SHA_256;
	}

	public static HashFunction sha384() {
		return Sha384Holder.SHA_384;
	}

	public static HashFunction sha512() {
		return Sha512Holder.SHA_512;
	}

	public static HashFunction hmacMd5(Key key) {
		return new MacHashFunction("HmacMD5", key, hmacToString("hmacMd5", key));
	}

	public static HashFunction hmacMd5(byte[] key) {
		return hmacMd5((Key) (new SecretKeySpec((byte[]) Preconditions.checkNotNull(key), "HmacMD5")));
	}

	public static HashFunction hmacSha1(Key key) {
		return new MacHashFunction("HmacSHA1", key, hmacToString("hmacSha1", key));
	}

	public static HashFunction hmacSha1(byte[] key) {
		return hmacSha1((Key) (new SecretKeySpec((byte[]) Preconditions.checkNotNull(key), "HmacSHA1")));
	}

	public static HashFunction hmacSha256(Key key) {
		return new MacHashFunction("HmacSHA256", key, hmacToString("hmacSha256", key));
	}

	public static HashFunction hmacSha256(byte[] key) {
		return hmacSha256((Key) (new SecretKeySpec((byte[]) Preconditions.checkNotNull(key), "HmacSHA256")));
	}

	public static HashFunction hmacSha512(Key key) {
		return new MacHashFunction("HmacSHA512", key, hmacToString("hmacSha512", key));
	}

	public static HashFunction hmacSha512(byte[] key) {
		return hmacSha512((Key) (new SecretKeySpec((byte[]) Preconditions.checkNotNull(key), "HmacSHA512")));
	}

	private static String hmacToString(String methodName, Key key) {
		return String.format("Hashing.%s(Key[algorithm=%s, format=%s])", methodName, key.getAlgorithm(),
				key.getFormat());
	}

	public static HashFunction crc32c() {
		return Crc32cHashFunction.CRC_32_C;
	}

	public static HashFunction crc32() {
		return ChecksumType.CRC_32.hashFunction;
	}

	public static HashFunction adler32() {
		return ChecksumType.ADLER_32.hashFunction;
	}

	public static HashFunction farmHashFingerprint64() {
		return FarmHashFingerprint64.FARMHASH_FINGERPRINT_64;
	}

	public static int consistentHash(HashCode hashCode, int buckets) {
		return consistentHash(hashCode.padToLong(), buckets);
	}

	public static int consistentHash(long input, int buckets) {
		Preconditions.checkArgument(buckets > 0, "buckets must be positive: %s", buckets);
		LinearCongruentialGenerator generator = new LinearCongruentialGenerator(input);
		int candidate = 0;

		while (true) {
			int next = (int) ((double) (candidate + 1) / generator.nextDouble());
			if (next < 0 || next >= buckets) {
				return candidate;
			}

			candidate = next;
		}
	}

	public static HashCode combineOrdered(Iterable<HashCode> hashCodes) {
		Iterator<HashCode> iterator = hashCodes.iterator();
		Preconditions.checkArgument(iterator.hasNext(), "Must be at least 1 hash code to combine.");
		int bits = ((HashCode) iterator.next()).bits();
		byte[] resultBytes = new byte[bits / 8];
		Iterator var4 = hashCodes.iterator();

		while (var4.hasNext()) {
			HashCode hashCode = (HashCode) var4.next();
			byte[] nextBytes = hashCode.asBytes();
			Preconditions.checkArgument(nextBytes.length == resultBytes.length,
					"All hashcodes must have the same bit length.");

			for (int i = 0; i < nextBytes.length; ++i) {
				resultBytes[i] = (byte) (resultBytes[i] * 37 ^ nextBytes[i]);
			}
		}

		return HashCode.fromBytesNoCopy(resultBytes);
	}

	public static HashCode combineUnordered(Iterable<HashCode> hashCodes) {
		Iterator<HashCode> iterator = hashCodes.iterator();
		Preconditions.checkArgument(iterator.hasNext(), "Must be at least 1 hash code to combine.");
		byte[] resultBytes = new byte[((HashCode) iterator.next()).bits() / 8];
		Iterator var3 = hashCodes.iterator();

		while (var3.hasNext()) {
			HashCode hashCode = (HashCode) var3.next();
			byte[] nextBytes = hashCode.asBytes();
			Preconditions.checkArgument(nextBytes.length == resultBytes.length,
					"All hashcodes must have the same bit length.");

			for (int i = 0; i < nextBytes.length; ++i) {
				resultBytes[i] += nextBytes[i];
			}
		}

		return HashCode.fromBytesNoCopy(resultBytes);
	}

	static int checkPositiveAndMakeMultipleOf32(int bits) {
		Preconditions.checkArgument(bits > 0, "Number of bits must be positive");
		return bits + 31 & -32;
	}

	public static HashFunction concatenating(HashFunction first, HashFunction second, HashFunction... rest) {
      List<HashFunction> list = new ArrayList();
      list.add(first);
      list.add(second);
      list.addAll(Arrays.asList(rest));
      return new ConcatenatedHashFunction((HashFunction[])list.toArray(new HashFunction[0]), (1)null);
   }

	public static HashFunction concatenating(Iterable<HashFunction> hashFunctions) {
      Preconditions.checkNotNull(hashFunctions);
      List<HashFunction> list = new ArrayList();
      Iterator var2 = hashFunctions.iterator();

      while(var2.hasNext()) {
         HashFunction hashFunction = (HashFunction)var2.next();
         list.add(hashFunction);
      }

      Preconditions.checkArgument(list.size() > 0, "number of hash functions (%s) must be > 0", list.size());
      return new ConcatenatedHashFunction((HashFunction[])list.toArray(new HashFunction[0]), (1)null);
   }
}