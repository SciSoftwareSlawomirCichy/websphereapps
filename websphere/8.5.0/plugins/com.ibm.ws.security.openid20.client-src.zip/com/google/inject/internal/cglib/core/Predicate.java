package com.google.inject.internal.cglib.core;

public interface Predicate {
	boolean evaluate(Object var1);
}