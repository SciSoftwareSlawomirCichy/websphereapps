package com.ibm.ejs.container;

import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;
import javax.ejb.EJBException;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBLocalObject;
import javax.ejb.RemoveException;

public class EJSLocalWrapper extends EJSWrapperBase implements EJBLocalObject {
	private static final String CLASS_NAME = "com.ibm.ejs.container.EJSLocalWrapper";

	public EJBLocalHome getEJBLocalHome() throws EJBException {
		EJBLocalHome result = null;

		try {
			if (this.beanId._isHome) {
				throw new IllegalStateException("getEJBLocalHome is not a method of a EJBLocalHome object.");
			} else {
				result = (EJBLocalHome) this.wrapperManager.getWrapper(this.beanId.getHome().getId()).getLocalObject();
				return result;
			}
		} catch (RemoteException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.EJSLocalWrapper.getEJBLocalHome", "67", this);
			throw new EJBException(var3);
		}
	}

	public Object getPrimaryKey() throws EJBException {
		HomeInternal hi = this.beanId.getHome();
		if (!hi.isStatelessSessionHome() && !hi.isStatefulSessionHome()) {
			return ((EJSHome) hi).WASInternal_copyPrimaryKey(this.beanId.getPrimaryKey());
		} else {
			throw new IllegalSessionMethodLocalException();
		}
	}

	public boolean isIdentical(EJBLocalObject obj) throws EJBException {
		HomeInternal hi = this.beanId.getHome();
		if (hi.isStatefulSessionHome()) {
			return this.beanId.equals(((EJSLocalWrapper) obj).beanId);
		} else if (hi.isStatelessSessionHome()) {
			BeanId thisHomeId = hi.getId();
			BeanId cmpHomeId = ((EJSLocalWrapper) obj).beanId.getHome().getId();
			return thisHomeId.equals(cmpHomeId);
		} else {
			return this.getPrimaryKey().equals(obj.getPrimaryKey());
		}
	}

	public void remove() throws RemoveException, EJBException {
		try {
			this.container.removeBean(this);
		} catch (RemoteException var2) {
			FFDCFilter.processException(var2, "com.ibm.ejs.container.EJSLocalWrapper.remove", "132", this);
			throw new EJBException(var2);
		}
	}
}