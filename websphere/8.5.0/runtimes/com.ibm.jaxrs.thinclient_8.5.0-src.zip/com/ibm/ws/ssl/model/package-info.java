package com.ibm.ws.ssl.model;

interface package-info {
}