package com.ibm.ejs.container.drs.ws390;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.wsspi.cluster.Identity;
import com.ibm.wsspi.drs.DRSCacheMsg;
import com.ibm.wsspi.drs.DRSCacheMsgListener;
import com.ibm.wsspi.drs.DRSEventObject;
import com.ibm.wsspi.drs.DRSInstanceToken;
import com.ibm.wsspi.drs.DRSServantProxy;
import java.util.Iterator;

public class SfDRSControllerCacheMsgListenerImpl implements DRSCacheMsgListener {
	private static TraceComponent tc = Tr.register(SfDRSControllerCacheMsgListenerImpl.class, "EJBDRSCache",
			"com.ibm.ejs.container.container");
	private static boolean _loggedVersion = false;
	private SfDRSControllerInstanceImpl xddci = null;
	private Integer eventLock;

	public SfDRSControllerCacheMsgListenerImpl(SfDRSControllerInstanceImpl ddci) {
		String m = "SfDRSControllerCacheMsgListenerImpl - constructor";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl - constructor");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled() && !_loggedVersion) {
			Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl - constructorVersion 1.10 1/11/06 13:15:35");
			_loggedVersion = true;
		}

		this.xddci = ddci;
		this.eventLock = new Integer(234);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl - constructor");
		}

	}

	public void event(DRSEventObject eventObject) {
		String m = "SfDRSControllerCacheMsgListenerImpl.event: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.event: Entry");
		}

		if (eventObject == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.event: Exit - event parameter is null");
			}

		} else {
			int event = eventObject.getEvent();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl.event:  Event = " + eventObject);
			}

			if (event == 1) {
				this.xddci.setDRSReplicationUp();
			} else if (event == 2) {
				this.xddci.setDRSReplicationDown();
			} else if (event == 3) {
				this.xddci.setDRSCongested();
			} else if (event == 4) {
				this.xddci.setDRSNotCongested();
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.event: ");
			}

		}
	}

	public void createEntry(Object entryKey, Object value) {
		String m = "SfDRSControllerCacheMsgListenerImpl.createEntry: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.createEntry: Entry");
		}

		this.createEntryInServants((DRSInstanceToken) null, entryKey, value);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.createEntry:  Exit.");
		}

	}

	public void createEntryProp(Object entryKey, Object propKey, Object value) {
		String m = "SfDRSControllerCacheMsgListenerImpl.createEntryProp: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.createEntryProp: Entry");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.createEntryProp:  Exit.");
		}

	}

	public void updateEntry(Object entryKey, Object value) {
		String m = "SfDRSControllerCacheMsgListenerImpl.updateEntry: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.updateEntry: Entry");
		}

		this.updateEntryInServants((DRSInstanceToken) null, entryKey, value);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.updateEntry:  Exit.");
		}

	}

	public void updateEntryProp(Object entryKey, Object propKey, Object value) {
		String m = "SfDRSControllerCacheMsgListenerImpl.updateEntryProp: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.updateEntryProp: Entry");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.updateEntryProp:  Exit.");
		}

	}

	public Object getEntry(Object entryKey) {
		String m = "SfDRSControllerCacheMsgListenerImpl.getEntry: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.getEntry:  entryKey=" + entryKey);
		}

		Object rc = null;
		if (entryKey != null) {
			rc = this.getEntryFromServants((DRSInstanceToken) null, entryKey);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.getEntry:  rc = " + (rc == null ? "null" : "not null"));
		}

		return rc;
	}

	public Object getEntryProp(Object entryKey, Object propKey) {
		String m = "SfDRSControllerCacheMsgListenerImpl.getEntryProp: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryProp: Entry");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryProp:  Exit.");
		}

		return null;
	}

	public void removeEntry(Object entryKey) {
		String m = "SfDRSControllerCacheMsgListenerImpl.removeEntry: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.removeEntry: Entry");
		}

		this.removeEntryInServants((DRSInstanceToken) null, entryKey);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.removeEntry:  Exit.");
		}

	}

	public void removeEntryProp(Object entryKey, Object propKey, Object value) {
		String m = "SfDRSControllerCacheMsgListenerImpl.removeEntryProp: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.removeEntryProp: Entry");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.removeEntryProp:  Exit.");
		}

	}

	public boolean entryIDExists(Object entryKey) {
		String m = "SfDRSControllerCacheMsgListenerImpl.entryIDExists()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.entryIDExists() entryKey = " + entryKey);
		}

		boolean rc = false;
		if (entryKey != null) {
			rc = this.getEntryIDExistsFromServants((DRSInstanceToken) null, entryKey);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.entryIDExists() Exit - rc = " + rc);
		}

		return rc;
	}

	public void asyncAck(DRSCacheMsg in, DRSCacheMsg out) {
		String m = "SfDRSControllerCacheMsgListenerImpl.asyncAck()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.asyncAck() DRSCacheMsg in " + in + " out=" + out);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.asyncAck() Exit.");
		}

	}

	public void nowThePrimary(long partitionId) {
		String m = "SfDRSControllerCacheMsgListenerImpl.nowThePrimary()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.nowThePrimary() partitionId" + partitionId);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.nowThePrimary() Exit.");
		}

	}

	public void nowThePrimary(Identity id) {
		String m = "SfDRSControllerCacheMsgListenerImpl.nowThePrimary()";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.nowThePrimary() Identity" + id);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.nowThePrimary() Exit.");
		}

	}

	public void response(Object response) {
		String m = "SfDRSControllerCacheMsgListenerImpl.response: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.response: Entry");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.response:  Exit.");
		}

	}

	public Object broadcast(Object key) {
		String m = "SfDRSControllerCacheMsgListenerImpl.broadcast: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.broadcast: Entry");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.broadcast:  Exit.");
		}

		return null;
	}

	void createEntryInServants(DRSInstanceToken sourceToken, Object entryKey, Object value) {
		String m = "SfDRSControllerCacheMsgListenerImpl.createEntryInServants: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc,
					"SfDRSControllerCacheMsgListenerImpl.createEntryInServants: Entry : sourceToken = " + sourceToken);
		}

		if (entryKey != null && value != null) {
			DRSServantProxy proxy = null;
			DRSInstanceToken stoken = null;
			byte[] tokenBytes = null;
			byte[] entryKeyBytes = this.convertToBytes(entryKey);
			byte[] valueBytes = this.convertToBytes(value);
			if (entryKeyBytes != null && valueBytes != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl.createEntryInServants:  There are "
							+ this.xddci.getDRSInstanceTokenTable().size() + " servants in the table");
				}

				Iterator iter = this.xddci.getDRSInstanceTokenTable().getIterator();

				while (iter.hasNext()) {
					stoken = (DRSInstanceToken) iter.next();
					if (!stoken.equals(sourceToken)) {
						byte[] tokenBytes = this.convertToBytes(stoken);
						if (tokenBytes != null) {
							proxy = this.getProxy(stoken);
							if (proxy != null) {
								try {
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										Tr.debug(tc,
												"SfDRSControllerCacheMsgListenerImpl.createEntryInServants:  sending createEntry to SR with stoken= "
														+ stoken);
									}

									proxy.createEntry(tokenBytes, entryKeyBytes, valueBytes);
								} catch (Throwable var12) {
									FFDCFilter.processException(var12,
											"com.ibm.ejs.container.drs.ws390.SfDRSControllerCacheMsgListenerImpl.createEntryInServants",
											"451", this);
									Tr.error(tc, "SFB_CONTROLLER_EXCEPTOKEN_CNTR0105E",
											new Object[]{"SfDRSControllerCacheMsgListenerImpl.createEntryInServants: ",
													var12, stoken});
								}
							} else {
								Tr.error(tc, "SFB_CONTROLLER_NOPROXY_CNTR0106E", new Object[]{
										"SfDRSControllerCacheMsgListenerImpl.createEntryInServants: ", stoken});
							}
						} else {
							Tr.error(tc, "SFB_CONTROLLER_TOKENBYTES_CNTR0107E", new Object[]{
									"SfDRSControllerCacheMsgListenerImpl.createEntryInServants: ", stoken});
						}
					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.createEntryInServants:  Exit.");
				}

			} else {
				if (entryKeyBytes == null) {
					Tr.error(tc, "SFB_CONTROLLER_KEYBYTES_CNTR0104E",
							"SfDRSControllerCacheMsgListenerImpl.createEntryInServants: ");
				}

				if (value == null) {
					Tr.error(tc, "SFB_CONTROLLER_VALUEBYTES_CNTR0110E",
							"SfDRSControllerCacheMsgListenerImpl.createEntryInServants: ");
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc,
							"SfDRSControllerCacheMsgListenerImpl.createEntryInServants: Exit - cannot convert a parameter to byte array");
				}

			}
		} else {
			if (entryKey == null) {
				Tr.error(tc, "SFB_CONTROLLER_ENTRYKEY_CNTR0102E",
						"SfDRSControllerCacheMsgListenerImpl.createEntryInServants: ");
			}

			if (value == null) {
				Tr.error(tc, "SFB_CONTROLLER_KEYVALUE_CNTR0103E",
						"SfDRSControllerCacheMsgListenerImpl.createEntryInServants: ");
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.createEntryInServants: Exit - a parameter is null");
			}

		}
	}

	void updateEntryInServants(DRSInstanceToken sourceToken, Object entryKey, Object value) {
		String m = "SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			if (sourceToken == null) {
				Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: Entry : sourceToken = null");
			} else {
				Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: Entry : sourceToken = "
						+ sourceToken);
			}
		}

		if (entryKey != null && value != null) {
			DRSServantProxy proxy = null;
			DRSInstanceToken stoken = null;
			byte[] tokenBytes = null;
			byte[] entryKeyBytes = this.convertToBytes(entryKey);
			byte[] valueBytes = this.convertToBytes(value);
			if (entryKeyBytes != null && valueBytes != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl.updateEntryInServants:  There are "
							+ this.xddci.getDRSInstanceTokenTable().size() + " servants in the table");
				}

				Iterator iter = this.xddci.getDRSInstanceTokenTable().getIterator();

				while (iter.hasNext()) {
					stoken = (DRSInstanceToken) iter.next();
					if (!stoken.equals(sourceToken)) {
						byte[] tokenBytes = this.convertToBytes(stoken);
						if (tokenBytes != null) {
							proxy = this.getProxy(stoken);
							if (proxy != null) {
								try {
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										Tr.debug(tc,
												"SfDRSControllerCacheMsgListenerImpl.updateEntryInServants:  sending updateEntry to SR with stoken= "
														+ stoken);
									}

									proxy.updateEntry(tokenBytes, entryKeyBytes, valueBytes);
								} catch (Throwable var12) {
									FFDCFilter.processException(var12,
											"com.ibm.ejs.container.drs.ws390.SfDRSControllerCacheMsgListenerImpl.updateEntryInServants",
											"539", this);
									Tr.error(tc, "SFB_CONTROLLER_EXCEPTOKEN_CNTR0105E",
											new Object[]{"SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: ",
													var12, stoken});
								}
							} else {
								Tr.error(tc, "SFB_CONTROLLER_NOPROXY_CNTR0106E", new Object[]{
										"SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: ", stoken});
							}
						} else {
							Tr.error(tc, "SFB_CONTROLLER_TOKENBYTES_CNTR0107E", new Object[]{
									"SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: ", stoken});
						}
					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.updateEntryInServants:  Exit.");
				}

			} else {
				if (entryKeyBytes == null) {
					Tr.error(tc, "SFB_CONTROLLER_KEYBYTES_CNTR0104E",
							"SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: ");
				}

				if (value == null) {
					Tr.error(tc, "SFB_CONTROLLER_VALUEBYTES_CNTR0110E",
							"SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: ");
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc,
							"SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: Exit - cannot convert a parameter to byte array");
				}

			}
		} else {
			if (entryKey == null) {
				Tr.error(tc, "SFB_CONTROLLER_ENTRYKEY_CNTR0102E",
						"SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: ");
			}

			if (value == null) {
				Tr.error(tc, "SFB_CONTROLLER_KEYVALUE_CNTR0103E",
						"SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: ");
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.updateEntryInServants: Exit - a parameter is null");
			}

		}
	}

	void removeEntryInServants(DRSInstanceToken sourceToken, Object entryKey) {
		String m = "SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			if (sourceToken == null) {
				Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: Entry : sourceToken = null");
			} else {
				Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: Entry : sourceToken = "
						+ sourceToken);
			}
		}

		if (entryKey == null) {
			Tr.error(tc, "SFB_CONTROLLER_ENTRYKEY_CNTR0102E",
					"SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: ");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: Exit - a parameter is null");
			}

		} else {
			DRSServantProxy proxy = null;
			DRSInstanceToken stoken = null;
			byte[] tokenBytes = null;
			byte[] entryKeyBytes = this.convertToBytes(entryKey);
			if (entryKeyBytes == null) {
				Tr.error(tc, "SFB_CONTROLLER_KEYBYTES_CNTR0104E",
						"SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: ");
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc,
							"SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: Exit - cannot convert a parameter to byte array");
				}

			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl.removeEntryInServants:  There are "
							+ this.xddci.getDRSInstanceTokenTable().size() + " servants in the table");
				}

				Iterator iter = this.xddci.getDRSInstanceTokenTable().getIterator();

				while (iter.hasNext()) {
					stoken = (DRSInstanceToken) iter.next();
					if (!stoken.equals(sourceToken)) {
						byte[] tokenBytes = this.convertToBytes(stoken);
						if (tokenBytes != null) {
							proxy = this.getProxy(stoken);
							if (proxy != null) {
								try {
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										Tr.debug(tc,
												"SfDRSControllerCacheMsgListenerImpl.removeEntryInServants:  sending removeEntry to SR with stoken= "
														+ stoken);
									}

									proxy.removeEntry(tokenBytes, entryKeyBytes);
								} catch (Throwable var10) {
									FFDCFilter.processException(var10,
											"com.ibm.ejs.container.drs.ws390.SfDRSControllerCacheMsgListenerImpl.removeEntryInServants",
											"615", this);
									Tr.error(tc, "SFB_CONTROLLER_EXCEPTOKEN_CNTR0105E",
											new Object[]{"SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: ",
													var10, stoken});
								}
							} else {
								Tr.error(tc, "SFB_CONTROLLER_NOPROXY_CNTR0106E", new Object[]{
										"SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: ", stoken});
							}
						} else {
							Tr.error(tc, "SFB_CONTROLLER_TOKENBYTES_CNTR0107E", new Object[]{
									"SfDRSControllerCacheMsgListenerImpl.removeEntryInServants: ", stoken});
						}
					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.removeEntryInServants:  Exit.");
				}

			}
		}
	}

	void sendEventToAllServants(DRSEventObject event) {
		String m = "SfDRSControllerCacheMsgListenerImpl.sendEventToAllServants: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.sendEventToAllServants: ");
		}

		if (event == null) {
			Tr.error(tc, "SFB_CONTROLLER_EVENT_CNTR0109E",
					"SfDRSControllerCacheMsgListenerImpl.sendEventToAllServants: ");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.sendEventToAllServants: Exit - a parameter is null");
			}

		} else {
			DRSServantProxy proxy = null;
			DRSInstanceToken token = null;
			Iterator iter = this.xddci.getDRSInstanceTokenTable().getIterator();
			Integer var6 = this.eventLock;
			synchronized (this.eventLock) {
				if (iter != null) {
					while (iter.hasNext()) {
						token = (DRSInstanceToken) iter.next();
						this.sendEvent(token, event);
					}
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.sendEventToAllServants: ");
			}

		}
	}

	void sendEvent(DRSInstanceToken token, DRSEventObject event) {
		String m = "SfDRSControllerCacheMsgListenerImpl.sendEvent: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.sendEvent: Entry.");
		}

		DRSServantProxy proxy = null;
		if (token != null && event != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl.sendEvent: Token = " + token + " event = " + event);
			}

			Integer var5 = this.eventLock;
			synchronized (this.eventLock) {
				byte[] eventObjectBytes = this.convertToBytes(event);
				byte[] tokenBytes = this.convertToBytes(token);
				if (eventObjectBytes != null) {
					if (tokenBytes != null) {
						proxy = this.getProxy(token);
						if (proxy != null) {
							try {
								if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
									Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl.sendEvent:  sending event ("
											+ event + ") to SR with token= " + token);
								}

								proxy.event(tokenBytes, eventObjectBytes);
							} catch (Throwable var10) {
								FFDCFilter.processException(var10,
										"com.ibm.ejs.container.drs.ws390.SfDRSControllerCacheMsgListenerImpl.sendEvent",
										"700", this);
								Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
										new Object[]{"SfDRSControllerCacheMsgListenerImpl.sendEvent: ", var10});
							}
						} else {
							Tr.error(tc, "SFB_CONTROLLER_NOPROXY_CNTR0106E",
									new Object[]{"SfDRSControllerCacheMsgListenerImpl.sendEvent: ", token});
						}
					} else {
						Tr.error(tc, "SFB_CONTROLLER_TOKENBYTES_CNTR0107E",
								new Object[]{"SfDRSControllerCacheMsgListenerImpl.sendEvent: ", token});
					}
				} else {
					Tr.error(tc, "SFB_CONTROLLER_EVENTBYTES_CNTR0111E",
							new Object[]{"SfDRSControllerCacheMsgListenerImpl.sendEvent: ", event});
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.sendEvent: Exit.");
			}

		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.sendEvent: Exit - token or event is null");
			}

		}
	}

	Object getEntryFromServants(DRSInstanceToken sourceToken, Object entryKey) {
		String m = "SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			if (sourceToken == null) {
				Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: Entry : sourceToken = null");
			} else {
				Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: Entry : sourceToken = "
						+ sourceToken);
			}
		}

		Object rc = null;
		if (entryKey == null) {
			Tr.error(tc, "SFB_CONTROLLER_ENTRYKEY_CNTR0102E",
					"SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: ");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: Exit - a parameter is null");
			}
		} else {
			DRSServantProxy proxy = null;
			DRSInstanceToken stoken = null;
			byte[] tokenBytes = null;
			byte[] entryKeyBytes = this.convertToBytes(entryKey);
			if (entryKeyBytes == null) {
				Tr.error(tc, "SFB_CONTROLLER_KEYBYTES_CNTR0104E",
						"SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: ");
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc,
							"SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: Exit - cannot convert a parameter to byte array");
				}

				return rc;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryFromServants:  There are "
						+ this.xddci.getDRSInstanceTokenTable().size() + " servants in the table");
			}

			Iterator iter = this.xddci.getDRSInstanceTokenTable().getIterator();

			while (rc == null && iter.hasNext()) {
				stoken = (DRSInstanceToken) iter.next();
				if (!stoken.equals(sourceToken)) {
					byte[] tokenBytes = this.convertToBytes(stoken);
					if (tokenBytes != null) {
						proxy = this.getProxy(stoken);
						if (proxy != null) {
							try {
								if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
									Tr.debug(tc,
											"SfDRSControllerCacheMsgListenerImpl.getEntryFromServants:  sending getEntry to SR with stoken= "
													+ stoken);
								}

								byte[] tmp = proxy.getEntry(tokenBytes, entryKeyBytes);
								if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
									Tr.debug(tc,
											"SfDRSControllerCacheMsgListenerImpl.getEntryFromServants:  SR with stoken= "
													+ stoken + " returned " + (tmp == null ? "null" : "not null"));
								}

								if (tmp != null) {
									rc = SfPlatformHelper.getObject(tmp);
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										Tr.debug(tc,
												"SfDRSControllerCacheMsgListenerImpl.getEntryFromServants:  SR with stoken= "
														+ stoken + " returned an object");
									}
								}
							} catch (Throwable var11) {
								FFDCFilter.processException(var11,
										"com.ibm.ejs.container.drs.ws390.SfDRSControllerCacheMsgListenerImpl.getEntryFromServants",
										"782", this);
								Tr.error(tc, "SFB_CONTROLLER_EXCEPTOKEN_CNTR0105E", new Object[]{
										"SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: ", var11, stoken});
								rc = null;
							}
						} else {
							Tr.error(tc, "SFB_CONTROLLER_NOPROXY_CNTR0106E",
									new Object[]{"SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: ", stoken});
						}
					} else {
						Tr.error(tc, "SFB_CONTROLLER_TOKENBYTES_CNTR0107E",
								new Object[]{"SfDRSControllerCacheMsgListenerImpl.getEntryFromServants: ", stoken});
					}
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryFromServants:  Exit rc = "
					+ (rc == null ? "null" : "not null"));
		}

		return rc;
	}

	boolean getEntryIDExistsFromServants(DRSInstanceToken sourceToken, Object entryKey) {
		String m = "SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			if (sourceToken == null) {
				Tr.entry(tc,
						"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: Entry : sourceToken = null");
			} else {
				Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: Entry : sourceToken = "
						+ sourceToken);
			}
		}

		boolean rc = false;
		if (entryKey == null) {
			Tr.error(tc, "SFB_CONTROLLER_ENTRYKEY_CNTR0102E",
					"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: ");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc,
						"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: Exit - a parameter is null");
			}

			return rc;
		} else {
			DRSServantProxy proxy = null;
			DRSInstanceToken stoken = null;
			byte[] tokenBytes = null;
			byte[] entryKeyBytes = this.convertToBytes(entryKey);
			if (entryKeyBytes == null) {
				Tr.error(tc, "SFB_CONTROLLER_KEYBYTES_CNTR0104E",
						"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: ");
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc,
							"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: Exit - cannot convert a parameter to byte array");
				}

				return rc;
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants:  There are "
							+ this.xddci.getDRSInstanceTokenTable().size() + " servants in the table");
				}

				Iterator iter = this.xddci.getDRSInstanceTokenTable().getIterator();

				while (!rc && iter.hasNext()) {
					stoken = (DRSInstanceToken) iter.next();
					if (!stoken.equals(sourceToken)) {
						byte[] tokenBytes = this.convertToBytes(stoken);
						if (tokenBytes != null) {
							proxy = this.getProxy(stoken);
							if (proxy != null) {
								try {
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										Tr.debug(tc,
												"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants:  sending createEntry to SR with stoken= "
														+ stoken);
									}

									rc = proxy.entryIDExists(tokenBytes, entryKeyBytes);
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										Tr.debug(tc,
												"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants:  SR with stoken= "
														+ stoken + " returned rc = " + rc);
									}
								} catch (Throwable var11) {
									FFDCFilter.processException(var11,
											"com.ibm.ejs.container.drs.ws390.SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants",
											"864", this);
									Tr.error(tc, "SFB_CONTROLLER_EXCEPTOKEN_CNTR0105E", new Object[]{
											"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: ", var11,
											stoken});
								}
							} else {
								Tr.error(tc, "SFB_CONTROLLER_NOPROXY_CNTR0106E", new Object[]{
										"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: ", stoken});
							}
						} else {
							Tr.error(tc, "SFB_CONTROLLER_TOKENBYTES_CNTR0107E", new Object[]{
									"SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants: ", stoken});
						}
					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.getEntryIDExistsFromServants:  Exit rc = " + rc);
				}

				return rc;
			}
		}
	}

	private DRSServantProxy getProxy(DRSInstanceToken _token) {
		String m = "SfDRSControllerCacheMsgListenerImpl.getProxy: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.getProxy: Entry");
		}

		DRSServantProxy rc = null;
		if (_token != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "SfDRSControllerCacheMsgListenerImpl.getProxy: Token = " + _token);
			}

			try {
				rc = this.xddci.drsServantProxyFactory.createProxyForSpecificServant(_token);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"SfDRSControllerCacheMsgListenerImpl.getProxy:  Successfully acquired proxy for Token = "
									+ _token);
				}
			} catch (Throwable var5) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					FFDCFilter.processException(var5,
							"com.ibm.ejs.container.drs.ws390.SfDRSControllerCacheMsgListenerImpl.getProxy", "903",
							this);
					Tr.debug(tc,
							"SfDRSControllerCacheMsgListenerImpl.getProxy: Caught exception while trying to create a proxy to token "
									+ _token);
					Tr.debug(tc,
							"SfDRSControllerCacheMsgListenerImpl.getProxy: This exception is not necessarily an error.");
					Tr.error(tc, "SFB_CONTROLLER_EXCEPTPROXY_CNTR0108E",
							new Object[]{"SfDRSControllerCacheMsgListenerImpl.getProxy: ", var5, _token});
				}

				rc = null;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc,
					"SfDRSControllerCacheMsgListenerImpl.getProxy: Exit rc = " + (rc == null ? "failure" : "success"));
		}

		return rc;
	}

	private byte[] convertToBytes(Object obj) {
		String m = "SfDRSControllerCacheMsgListenerImpl.convertToBytes: ";
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSControllerCacheMsgListenerImpl.convertToBytes: Entry");
		}

		byte[] rc = null;
		if (obj != null) {
			try {
				rc = this.xddci.drsServantProxyFactory.getByteArray(obj);
			} catch (Throwable var5) {
				FFDCFilter.processException(var5,
						"com.ibm.ejs.container.drs.ws390.SfDRSControllerCacheMsgListenerImpl.convertToBytes", "932",
						this);
				Tr.error(tc, "SFB_CONTROLLER_EXCEPTION_CNTR0100E",
						new Object[]{"SfDRSControllerCacheMsgListenerImpl.convertToBytes: ", var5});
				rc = null;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSControllerCacheMsgListenerImpl.convertToBytes: Exit rc = "
					+ (rc == null ? "failure" : "success"));
		}

		return rc;
	}
}