package com.ibm.ejs.cm.exception;

interface package-info {
}