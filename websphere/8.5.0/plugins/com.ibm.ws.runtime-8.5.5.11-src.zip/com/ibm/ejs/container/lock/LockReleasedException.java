package com.ibm.ejs.container.lock;

public class LockReleasedException extends LockException {
	private static final long serialVersionUID = -1316438387962623085L;
}