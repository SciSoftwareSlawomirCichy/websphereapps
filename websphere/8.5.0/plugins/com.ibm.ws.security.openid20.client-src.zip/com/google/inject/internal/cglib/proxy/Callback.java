package com.google.inject.internal.cglib.proxy;

public interface Callback {
}