package com.ibm.ejs.cm.portability;

import java.sql.SQLException;

public class ResourceAllocationException extends PortableSQLException {
	private static final long serialVersionUID = -8120563427736344038L;

	protected ResourceAllocationException(SQLException nativeException) {
		super(nativeException);
	}

	protected ResourceAllocationException() {
	}
}