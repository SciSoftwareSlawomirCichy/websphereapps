package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface TopicEmitter {
	PreExit getPreExit();

	void setPreExit(PreExit var1);

	PreExit createPreExit();

	List getInlineExit();

	InlineExit[] getInlineExitAsArray();

	InlineExit createInlineExit();

	PostExit getPostExit();

	void setPostExit(PostExit var1);

	PostExit createPostExit();

	String getTopicEmitterName();

	void setTopicEmitterName(String var1);
}