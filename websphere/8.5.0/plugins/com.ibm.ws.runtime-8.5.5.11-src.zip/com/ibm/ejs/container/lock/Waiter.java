package com.ibm.ejs.container.lock;

class Waiter {
	final Lock theLock;
	final Locker locker;
	int mode;
	boolean released;

	Waiter(Lock l, Locker locker, int mode) {
		this.theLock = l;
		this.locker = locker;
		this.mode = mode;
		this.released = false;
	}
}