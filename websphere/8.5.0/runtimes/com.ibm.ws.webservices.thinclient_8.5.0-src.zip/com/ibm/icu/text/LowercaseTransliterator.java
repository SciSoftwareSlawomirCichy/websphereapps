package com.ibm.icu.text;

import com.ibm.icu.impl.UCaseProps;
import com.ibm.icu.text.LowercaseTransliterator.1;
import com.ibm.icu.text.Transliterator.Position;
import com.ibm.icu.util.ULocale;
import java.io.IOException;

class LowercaseTransliterator extends Transliterator {
	static final String _ID = "Any-Lower";
	private ULocale locale;
	private UCaseProps csp;
	private ReplaceableContextIterator iter;
	private StringBuffer result;
	private int[] locCache;

	static void register() {
      Transliterator.registerFactory("Any-Lower", new 1());
      Transliterator.registerSpecialInverse("Lower", "Upper", true);
   }

	public LowercaseTransliterator(ULocale loc) {
		super("Any-Lower", (UnicodeFilter) null);
		this.locale = loc;

		try {
			this.csp = UCaseProps.getSingleton();
		} catch (IOException var3) {
			this.csp = null;
		}

		this.iter = new ReplaceableContextIterator();
		this.result = new StringBuffer();
		this.locCache = new int[1];
		this.locCache[0] = 0;
	}

	protected void handleTransliterate(Replaceable text, Position offsets, boolean isIncremental) {
		if (this.csp != null) {
			if (offsets.start < offsets.limit) {
				this.iter.setText(text);
				this.result.setLength(0);
				this.iter.setIndex(offsets.start);
				this.iter.setLimit(offsets.limit);
				this.iter.setContextLimits(offsets.contextStart, offsets.contextLimit);

				int c;
				while ((c = this.iter.nextCaseMapCP()) >= 0) {
					c = this.csp.toFullLower(c, this.iter, this.result, this.locale, this.locCache);
					if (this.iter.didReachLimit() && isIncremental) {
						offsets.start = this.iter.getCaseMapCPStart();
						return;
					}

					if (c >= 0) {
						int delta;
						if (c <= 31) {
							delta = this.iter.replace(this.result.toString());
							this.result.setLength(0);
						} else {
							delta = this.iter.replace(UTF16.valueOf(c));
						}

						if (delta != 0) {
							offsets.limit += delta;
							offsets.contextLimit += delta;
						}
					}
				}

				offsets.start = offsets.limit;
			}
		}
	}
}