package com.ibm.ws.wim.security.authz;

import com.ibm.websphere.wim.exception.WIMSystemException;
import java.util.logging.Level;

public class AuthPrivilegedException extends WIMSystemException {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String MSG_CLASSNAME = AuthPrivilegedException.class.getName();
	private static final String MSG_METHODNAME = null;

	public AuthPrivilegedException(String var1, Level var2) {
		super(var1, var2, MSG_CLASSNAME, MSG_METHODNAME);
	}

	public AuthPrivilegedException(String var1, Object[] var2, Level var3) {
		super(var1, var2, var3, MSG_CLASSNAME, MSG_METHODNAME);
	}

	public AuthPrivilegedException(String var1, Throwable var2, Level var3) {
		super(var1, var3, MSG_CLASSNAME, MSG_METHODNAME, var2);
	}

	public AuthPrivilegedException(String var1, Object[] var2, Throwable var3, Level var4) {
		super(var1, var2, var4, MSG_CLASSNAME, MSG_METHODNAME, var3);
	}
}