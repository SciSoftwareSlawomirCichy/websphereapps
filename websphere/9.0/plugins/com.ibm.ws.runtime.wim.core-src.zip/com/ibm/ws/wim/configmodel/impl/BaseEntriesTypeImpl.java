package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class BaseEntriesTypeImpl extends EDataObjectImpl implements BaseEntriesType {
	protected static final String NAME_EDEFAULT = null;
	protected String name;
	protected static final String NAME_IN_REPOSITORY_EDEFAULT = null;
	protected String nameInRepository;

	protected BaseEntriesTypeImpl() {
		this.name = NAME_EDEFAULT;
		this.nameInRepository = NAME_IN_REPOSITORY_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getBaseEntriesType();
	}

	public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		String var2 = this.name;
		this.name = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.name));
		}

	}

	public String getNameInRepository() {
		return this.nameInRepository;
	}

	public void setNameInRepository(String var1) {
		String var2 = this.nameInRepository;
		this.nameInRepository = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.nameInRepository));
		}

	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getName();
			case 1 :
				return this.getNameInRepository();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setName((String) var2);
				return;
			case 1 :
				this.setNameInRepository((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setName(NAME_EDEFAULT);
				return;
			case 1 :
				this.setNameInRepository(NAME_IN_REPOSITORY_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return NAME_EDEFAULT == null ? this.name != null : !NAME_EDEFAULT.equals(this.name);
			case 1 :
				return NAME_IN_REPOSITORY_EDEFAULT == null
						? this.nameInRepository != null
						: !NAME_IN_REPOSITORY_EDEFAULT.equals(this.nameInRepository);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (name: ");
			var1.append(this.name);
			var1.append(", nameInRepository: ");
			var1.append(this.nameInRepository);
			var1.append(')');
			return var1.toString();
		}
	}
}