package com.ibm.ws.wim.util;

final class DecStack {
	int[] stack;
	DecStack prev;
	DecStack next;
}