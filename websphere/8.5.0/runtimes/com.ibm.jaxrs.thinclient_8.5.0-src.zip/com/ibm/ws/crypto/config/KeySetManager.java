package com.ibm.ws.crypto.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.websphere.crypto.KeyException;
import com.ibm.websphere.models.config.ipc.ssl.KeySet;
import com.ibm.websphere.models.config.security.Security;
import com.ibm.ws.security.config.SecurityConfigObject;
import com.ibm.ws.security.config.SecurityConfigObjectList;
import com.ibm.ws.ssl.config.AdminContextHelper;
import com.ibm.ws.ssl.config.ManagementScopeManager;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class KeySetManager {
	private static final TraceComponent tc = Tr.register(KeySetManager.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private static KeySetManager thisClass = null;
	private static ConcurrentHashMap<String, KeySetManager> instanceCache = new ConcurrentHashMap();
	private static Object lockObject = new Object();
	private HashMap keySetMap = null;

	private KeySetManager() {
		this.keySetMap = new HashMap();
	}

	public static KeySetManager getInstance() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInstance");
		}

		String uuid = AdminContextHelper.peekAdminContext();
		if (uuid == null) {
			uuid = "admin";
		}

		KeySetManager instance = (KeySetManager) instanceCache.get(uuid);
		if (instance == null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "getInstance did not find KeySetManager in the cache");
			}

			Object var2 = lockObject;
			synchronized (lockObject) {
				instance = (KeySetManager) instanceCache.get(uuid);
				if (instance == null) {
					instance = new KeySetManager();
					if (instance != null) {
						instanceCache.put(uuid, instance);
					}
				}
			}
		} else if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getInstance found KeySetManager in the cache");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInstance", instance);
		}

		return instance;
	}

	public static void releaseInstance() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "releaseInstance");
		}

		String uuid = AdminContextHelper.peekAdminContext();
		if (uuid == null) {
			uuid = "admin";
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "releaseInstance using uuid " + uuid);
		}

		instanceCache.remove(uuid);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "releaseInstance");
		}

	}

	public synchronized void initializeKeySets(Security security, boolean reinitialize) throws KeyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeKeySets");
		}

		try {
			if (reinitialize) {
				this.keySetMap.clear();
			}

			List keySetList = security.getKeySets();
			if (keySetList != null && keySetList.size() > 0) {
				for (int i = 0; i < keySetList.size(); ++i) {
					KeySet ks = (KeySet) keySetList.get(i);
					if (ks != null) {
						String scope = ks.getManagementScope().getScopeName();
						if (scope != null && !ManagementScopeManager.getInstance().currentScopeContained(scope)) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Skipping keyset name \"" + ks.getName() + "\" having scope \"" + scope
										+ "\".");
							}
						} else {
							WSKeySet kset = new WSKeySet(ks);
							if (kset != null) {
								this.keySetMap.put(ks.getName(), kset);
							}
						}
					}
				}
			}
		} catch (Exception var8) {
			Tr.debug(tc, "Exception initializing KeySets.", new Object[]{var8});
			Manager.Ffdc.log(var8, this, "com.ibm.ws.crypto.config.KeySetManager.initializeKeySets", "104",
					new Object[]{this});
			throw new KeyException(var8);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initializeKeySets");
		}

	}

	public synchronized void initializeKeySets(SecurityConfigObject security, boolean reinitialize)
			throws KeyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeKeySets " + reinitialize);
		}

		try {
			if (reinitialize) {
				this.keySetMap.clear();
			}

			SecurityConfigObjectList keySetList = security.getObjectList("keySets");
			if (keySetList != null && keySetList.size() > 0) {
				for (int i = 0; i < keySetList.size(); ++i) {
					SecurityConfigObject ks = keySetList.get(i);
					if (ks != null) {
						String scope = ks.getObject("managementScope").getString("scopeName");
						if (scope != null && !ManagementScopeManager.getInstance().currentScopeContained(scope)) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Skipping keyset name \"" + ks.getString("name") + "\" having scope \""
										+ scope + "\".");
							}
						} else {
							WSKeySet kset = new WSKeySet(ks);
							if (kset != null) {
								this.keySetMap.put(ks.getString("name"), kset);
							}
						}
					}
				}
			}
		} catch (Exception var8) {
			Tr.debug(tc, "Exception initializing KeySets.", new Object[]{var8});
			Manager.Ffdc.log(var8, this, "com.ibm.ws.crypto.config.KeySetManager.initializeKeySets", "156",
					new Object[]{this});
			throw new KeyException(var8);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initializeKeySets");
		}

	}

	public WSKeySet getKeySet(String name) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getKeySet -> " + name);
		}

		boolean found = false;
		WSKeySet wsks = (WSKeySet) this.keySetMap.get(name);
		if (wsks != null) {
			found = true;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getKeySet -> " + found);
		}

		return wsks;
	}
}