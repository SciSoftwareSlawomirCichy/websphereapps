package com.google.inject;

interface Lookups {
	<T> Provider<T> getProvider(Key<T> var1);

	<T> MembersInjector<T> getMembersInjector(TypeLiteral<T> var1);
}