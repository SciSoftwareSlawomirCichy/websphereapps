package com.ibm.ejs.csi;

import com.ibm.ejs.csi.NullSecurityCollaborator.1;
import com.ibm.ejs.csi.NullSecurityCollaborator.UnauthenticatedIdentity;
import java.security.Identity;

public class NullSecurityCollaborator {
	public static final Identity UNAUTHENTICATED = new UnauthenticatedIdentity("UNAUTHENTICATED", (1)null);
}