package com.google.common.graph;

import com.google.common.base.Preconditions;
import com.google.common.graph.MapIteratorCache.1;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

class MapIteratorCache<K, V> {
	private final Map<K, V> backingMap;
	@NullableDecl
	private transient Entry<K, V> entrySetCache;

	MapIteratorCache(Map<K, V> backingMap) {
		this.backingMap = (Map) Preconditions.checkNotNull(backingMap);
	}

	@CanIgnoreReturnValue
	public V put(@NullableDecl K key, @NullableDecl V value) {
		this.clearCache();
		return this.backingMap.put(key, value);
	}

	@CanIgnoreReturnValue
	public V remove(@NullableDecl Object key) {
		this.clearCache();
		return this.backingMap.remove(key);
	}

	public void clear() {
		this.clearCache();
		this.backingMap.clear();
	}

	public V get(@NullableDecl Object key) {
		V value = this.getIfCached(key);
		return value != null ? value : this.getWithoutCaching(key);
	}

	public final V getWithoutCaching(@NullableDecl Object key) {
		return this.backingMap.get(key);
	}

	public final boolean containsKey(@NullableDecl Object key) {
		return this.getIfCached(key) != null || this.backingMap.containsKey(key);
	}

	public final Set<K> unmodifiableKeySet() {
      return new 1(this);
   }

	protected V getIfCached(@NullableDecl Object key) {
		Entry<K, V> entry = this.entrySetCache;
		return entry != null && entry.getKey() == key ? entry.getValue() : null;
	}

	protected void clearCache() {
		this.entrySetCache = null;
	}
}