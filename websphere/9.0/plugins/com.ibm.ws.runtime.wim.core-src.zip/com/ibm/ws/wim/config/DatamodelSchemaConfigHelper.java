package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InvalidArgumentException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.DynamicModelType;
import com.ibm.ws.wim.configmodel.StaticModelType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DatamodelSchemaConfigHelper implements ConfigConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public String setIdMgrDymanicDatamodelSchema(String var1, String var2) throws Exception {
		ConfigurationProviderType var3 = ConfigUtils.getConfigProvider(var1);
		DynamicModelType var4 = var3.createDynamicModel();
		var4.setXsdFileName(var2);
		return ConfigUtils.saveConfig(var1);
	}

	public static String isIdMgrUseGlobalSchemaForModel(String var0, Map var1) throws Exception {
		ConfigurationProviderType var2 = ConfigSessionManager.singleton().getConfig(var0);
		boolean var3 = false;
		String var4 = (String) var1.get("securityDomainName");
		if (var4.equalsIgnoreCase("admin")) {
			throw new InvalidArgumentException("DOMAIN_CANNOT_BE_ADMIN");
		} else {
			StaticModelType var5 = null;
			DynamicModelType var6 = var2.getDynamicModel();
			if (var6 != null) {
				var3 = var6.isUseGlobalSchema();
			} else {
				var5 = var2.getStaticModel();
				var3 = var5.isUseGlobalSchema();
			}

			return (new Boolean(var3)).toString();
		}
	}

	public static String setIdMgrUseGlobalSchemaForModel(String var0, Map var1) throws Exception {
		String var2 = "setIdMgrUseGlobalSchemaForModel";
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, var2, "params: " + var1.toString());
		}

		Boolean var4 = (Boolean) var1.get("useGlobalSchema");
		String var5 = (String) var1.get("securityDomainName");
		if (var5.equalsIgnoreCase("admin")) {
			throw new InvalidArgumentException("DOMAIN_CANNOT_BE_ADMIN");
		} else {
			ConfigurationProviderType var6 = ConfigUtils.getConfigProvider(var0);
			StaticModelType var7 = null;
			DynamicModelType var8 = var6.getDynamicModel();
			if (var8 != null) {
				var8.setUseGlobalSchema(var4);
			} else {
				var7 = var6.getStaticModel();
				var7.setUseGlobalSchema(var4);
			}

			if (var3) {
				trcLogger.exiting(CLASSNAME, var2, "params: " + var1.toString());
			}

			return ConfigUtils.saveConfig(var0);
		}
	}

	public Map getIdMgrDatamodelSchemaSettings(String var1) throws Exception {
		HashMap var2 = new HashMap();
		ConfigurationProviderType var3 = ConfigSessionManager.singleton().getConfig(var1);
		StaticModelType var4 = var3.getStaticModel();
		DynamicModelType var5 = var3.createDynamicModel();
		if (var5 != null) {
			var2.put("dataModelSetting", "dynamicModel");
			var2.put("xsdFileName", var5.getXsdFileName());
		} else if (var4 != null) {
			var2.put("dataModelSetting", "staticModel");
			List var6 = var4.getPackageName();
			var2.put("packageNames", var6);
		} else {
			var2 = null;
		}

		return var2;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = DatamodelSchemaConfigHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}