package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

public class java_awt_event_AdjustmentAdapter extends EventAdapterImpl implements AdjustmentListener {
	public void adjustmentValueChanged(AdjustmentEvent var1) {
		this.eventProcessor.processEvent("adjustmentValueChanged", new Object[]{var1});
	}
}