package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.ComparisonChain.1;
import java.util.Comparator;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public abstract class ComparisonChain {
	private static final ComparisonChain ACTIVE = new 1();
	private static final ComparisonChain LESS = new ComparisonChain.InactiveComparisonChain(-1);
	private static final ComparisonChain GREATER = new ComparisonChain.InactiveComparisonChain(1);

	private ComparisonChain() {
	}

	public static ComparisonChain start() {
		return ACTIVE;
	}

	public abstract ComparisonChain compare(Comparable<?> var1, Comparable<?> var2);

	public abstract <T> ComparisonChain compare(@NullableDecl T var1, @NullableDecl T var2, Comparator<T> var3);

	public abstract ComparisonChain compare(int var1, int var2);

	public abstract ComparisonChain compare(long var1, long var3);

	public abstract ComparisonChain compare(float var1, float var2);

	public abstract ComparisonChain compare(double var1, double var3);

	@Deprecated
	public final ComparisonChain compare(Boolean left, Boolean right) {
		return this.compareFalseFirst(left, right);
	}

	public abstract ComparisonChain compareTrueFirst(boolean var1, boolean var2);

	public abstract ComparisonChain compareFalseFirst(boolean var1, boolean var2);

	public abstract int result();

	private static final class InactiveComparisonChain extends ComparisonChain {
		final int result;

		InactiveComparisonChain(int result) {
         super((1)null);
         this.result = result;
      }

		public ComparisonChain compare(@NullableDecl Comparable left, @NullableDecl Comparable right) {
			return this;
		}

		public <T> ComparisonChain compare(@NullableDecl T left, @NullableDecl T right,
				@NullableDecl Comparator<T> comparator) {
			return this;
		}

		public ComparisonChain compare(int left, int right) {
			return this;
		}

		public ComparisonChain compare(long left, long right) {
			return this;
		}

		public ComparisonChain compare(float left, float right) {
			return this;
		}

		public ComparisonChain compare(double left, double right) {
			return this;
		}

		public ComparisonChain compareTrueFirst(boolean left, boolean right) {
			return this;
		}

		public ComparisonChain compareFalseFirst(boolean left, boolean right) {
			return this;
		}

		public int result() {
			return this.result;
		}
	}
}