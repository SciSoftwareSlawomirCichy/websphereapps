package com.google.inject.util;

import com.google.inject.Module;
import com.google.inject.internal.ImmutableSet;
import com.google.inject.util.Modules.1;
import com.google.inject.util.Modules.2;
import com.google.inject.util.Modules.OverriddenModuleBuilder;
import com.google.inject.util.Modules.RealOverriddenModuleBuilder;
import java.util.Arrays;
import java.util.Set;

public final class Modules {
	public static final Module EMPTY_MODULE = new 1();

	public static OverriddenModuleBuilder override(Module... modules) {
      return new RealOverriddenModuleBuilder(Arrays.asList(modules), (1)null);
   }

	public static OverriddenModuleBuilder override(Iterable<? extends Module> modules) {
      return new RealOverriddenModuleBuilder(modules, (1)null);
   }

	public static Module combine(Module... modules) {
		return combine((Iterable) ImmutableSet.of(modules));
	}

	public static Module combine(Iterable<? extends Module> modules) {
      Set<Module> modulesSet = ImmutableSet.copyOf(modules);
      return new 2(modulesSet);
   }
}