package com.ibm.ejs.util;

final class Element<K, V> {
	final K ivKey;
	final V ivObject;
	Element<K, V> ivNext;

	Element(K key, V object) {
		this.ivKey = key;
		this.ivObject = object;
	}

	public String toString() {
		return "Element: " + this.ivKey.toString() + " " + this.ivObject.toString();
	}
}