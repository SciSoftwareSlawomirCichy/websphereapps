package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import com.ibm.ws.wim.configmodel.NotificationSubscriberList;
import com.ibm.ws.wim.configmodel.PreExit;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class PreExitImpl extends EDataObjectImpl implements PreExit {
	protected NotificationSubscriberList notificationSubscriberList = null;
	protected ModificationSubscriberList modificationSubscriberList = null;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getPreExit();
	}

	public NotificationSubscriberList getNotificationSubscriberList() {
		return this.notificationSubscriberList;
	}

	public NotificationChain basicSetNotificationSubscriberList(NotificationSubscriberList var1,
			NotificationChain var2) {
		NotificationSubscriberList var3 = this.notificationSubscriberList;
		this.notificationSubscriberList = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 0, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setNotificationSubscriberList(NotificationSubscriberList var1) {
		if (var1 != this.notificationSubscriberList) {
			NotificationChain var2 = null;
			if (this.notificationSubscriberList != null) {
				var2 = ((InternalEObject) this.notificationSubscriberList).eInverseRemove(this, -1, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -1, (Class) null, var2);
			}

			var2 = this.basicSetNotificationSubscriberList(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var1, var1));
		}

	}

	public NotificationSubscriberList createNotificationSubscriberList() {
		NotificationSubscriberList var1 = ConfigmodelFactory.eINSTANCE.createNotificationSubscriberList();
		this.setNotificationSubscriberList(var1);
		return var1;
	}

	public ModificationSubscriberList getModificationSubscriberList() {
		return this.modificationSubscriberList;
	}

	public NotificationChain basicSetModificationSubscriberList(ModificationSubscriberList var1,
			NotificationChain var2) {
		ModificationSubscriberList var3 = this.modificationSubscriberList;
		this.modificationSubscriberList = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 1, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setModificationSubscriberList(ModificationSubscriberList var1) {
		if (var1 != this.modificationSubscriberList) {
			NotificationChain var2 = null;
			if (this.modificationSubscriberList != null) {
				var2 = ((InternalEObject) this.modificationSubscriberList).eInverseRemove(this, -2, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -2, (Class) null, var2);
			}

			var2 = this.basicSetModificationSubscriberList(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var1, var1));
		}

	}

	public ModificationSubscriberList createModificationSubscriberList() {
		ModificationSubscriberList var1 = ConfigmodelFactory.eINSTANCE.createModificationSubscriberList();
		this.setModificationSubscriberList(var1);
		return var1;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return this.basicSetNotificationSubscriberList((NotificationSubscriberList) null, var4);
				case 1 :
					return this.basicSetModificationSubscriberList((ModificationSubscriberList) null, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getNotificationSubscriberList();
			case 1 :
				return this.getModificationSubscriberList();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setNotificationSubscriberList((NotificationSubscriberList) var2);
				return;
			case 1 :
				this.setModificationSubscriberList((ModificationSubscriberList) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setNotificationSubscriberList((NotificationSubscriberList) null);
				return;
			case 1 :
				this.setModificationSubscriberList((ModificationSubscriberList) null);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.notificationSubscriberList != null;
			case 1 :
				return this.modificationSubscriberList != null;
			default :
				return this.eDynamicIsSet(var1);
		}
	}
}