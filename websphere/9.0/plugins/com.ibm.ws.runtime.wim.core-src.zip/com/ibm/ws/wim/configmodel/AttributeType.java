package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface AttributeType {
	List getEntityTypes();

	String[] getEntityTypesAsArray();

	String getDefaultAttribute();

	void setDefaultAttribute(String var1);

	String getDefaultValue();

	void setDefaultValue(String var1);

	String getName();

	void setName(String var1);

	String getPropertyName();

	void setPropertyName(String var1);

	String getSyntax();

	void setSyntax(String var1);

	boolean isWimGenerate();

	void setWimGenerate(boolean var1);

	void unsetWimGenerate();

	boolean isSetWimGenerate();
}