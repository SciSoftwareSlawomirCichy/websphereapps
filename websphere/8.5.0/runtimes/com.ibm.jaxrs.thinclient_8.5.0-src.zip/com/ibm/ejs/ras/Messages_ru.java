package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_ru extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: Обнаружено несоответствие уровней компоновки установленных компонентов клиента сервера приложений. Уровень компоновки установленного компонента клиента {0}, являющегося {1}, отличается от уровня компоновки компонента клиента {2}, являющегося {3}."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: Несоответствие уровней компоновки установленных компонентов клиента сервера приложений препятствует дальнейшей работе."},
			{"EXCP_CWSJE0003E",
					"CWSJE0003E: Не удалось обратиться к ресурсу {1} по причине исключительной ситуации: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}