package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2.1;
import com.google.common.collect.Collections2.FilteredCollection;
import com.google.common.collect.Collections2.OrderedPermutationCollection;
import com.google.common.collect.Collections2.PermutationCollection;
import com.google.common.collect.Collections2.TransformedCollection;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

@GwtCompatible
public final class Collections2 {
	static final Joiner STANDARD_JOINER = Joiner.on(", ").useForNull("null");

	public static <E> Collection<E> filter(Collection<E> unfiltered, Predicate<? super E> predicate) {
		return unfiltered instanceof FilteredCollection
				? ((FilteredCollection) unfiltered).createCombined(predicate)
				: new FilteredCollection((Collection) Preconditions.checkNotNull(unfiltered),
						(Predicate) Preconditions.checkNotNull(predicate));
	}

	static boolean safeContains(Collection<?> collection, Object object) {
		Preconditions.checkNotNull(collection);

		try {
			return collection.contains(object);
		} catch (ClassCastException var3) {
			return false;
		} catch (NullPointerException var4) {
			return false;
		}
	}

	static boolean safeRemove(Collection<?> collection, Object object) {
		Preconditions.checkNotNull(collection);

		try {
			return collection.remove(object);
		} catch (ClassCastException var3) {
			return false;
		} catch (NullPointerException var4) {
			return false;
		}
	}

	public static <F, T> Collection<T> transform(Collection<F> fromCollection, Function<? super F, T> function) {
		return new TransformedCollection(fromCollection, function);
	}

	static boolean containsAllImpl(Collection<?> self, Collection<?> c) {
		Preconditions.checkNotNull(self);
		Iterator i$ = c.iterator();

		Object o;
		do {
			if (!i$.hasNext()) {
				return true;
			}

			o = i$.next();
		} while (self.contains(o));

		return false;
	}

	static String toStringImpl(Collection<?> collection) {
      StringBuilder sb = newStringBuilderForCollection(collection.size()).append('[');
      STANDARD_JOINER.appendTo(sb, Iterables.transform(collection, new 1(collection)));
      return sb.append(']').toString();
   }

	static StringBuilder newStringBuilderForCollection(int size) {
		Preconditions.checkArgument(size >= 0, "size must be non-negative");
		return new StringBuilder((int) Math.min((long) size * 8L, 1073741824L));
	}

	static <T> Collection<T> cast(Iterable<T> iterable) {
		return (Collection) iterable;
	}

	@Beta
	public static <E extends Comparable<? super E>> Collection<List<E>> orderedPermutations(Iterable<E> elements) {
		return orderedPermutations(elements, Ordering.natural());
	}

	@Beta
	public static <E> Collection<List<E>> orderedPermutations(Iterable<E> elements, Comparator<? super E> comparator) {
		return new OrderedPermutationCollection(elements, comparator);
	}

	@Beta
	public static <E> Collection<List<E>> permutations(Collection<E> elements) {
		return new PermutationCollection(ImmutableList.copyOf(elements));
	}

	private static boolean isPermutation(List<?> first, List<?> second) {
		if (first.size() != second.size()) {
			return false;
		} else {
			Multiset<?> firstSet = HashMultiset.create(first);
			Multiset<?> secondSet = HashMultiset.create(second);
			return firstSet.equals(secondSet);
		}
	}

	private static boolean isPositiveInt(long n) {
		return n >= 0L && n <= 2147483647L;
	}
}