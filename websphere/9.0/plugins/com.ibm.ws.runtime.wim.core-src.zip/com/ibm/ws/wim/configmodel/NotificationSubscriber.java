package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface NotificationSubscriber {
	String getNotificationSubscriberReference();

	void setNotificationSubscriberReference(String var1);

	List getRealmList();

	void setRealmList(List var1);

	void unsetRealmList();

	boolean isSetRealmList();
}