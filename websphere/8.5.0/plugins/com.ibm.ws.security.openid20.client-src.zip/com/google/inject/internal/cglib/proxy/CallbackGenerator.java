package com.google.inject.internal.cglib.proxy;

import com.google.inject.internal.cglib.core.ClassEmitter;
import com.google.inject.internal.cglib.core.CodeEmitter;
import com.google.inject.internal.cglib.proxy.CallbackGenerator.Context;
import java.util.List;

interface CallbackGenerator {
	void generate(ClassEmitter var1, Context var2, List var3) throws Exception;

	void generateStatic(CodeEmitter var1, Context var2, List var3) throws Exception;
}