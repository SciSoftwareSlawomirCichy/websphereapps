package com.ibm.ejs.container;

import java.rmi.RemoteException;

public class ContainerException extends RemoteException {
	private static final long serialVersionUID = -3000641845739978815L;

	public ContainerException(String s) {
		super(s);
	}

	public ContainerException(String s, Throwable ex) {
		super(s, ex);
	}

	public ContainerException(Throwable ex) {
		super("", ex);
	}

	public ContainerException() {
	}
}