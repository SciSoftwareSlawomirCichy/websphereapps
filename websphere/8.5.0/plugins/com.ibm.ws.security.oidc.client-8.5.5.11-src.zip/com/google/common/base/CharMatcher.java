package com.google.common.base;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.CharMatcher.1;
import com.google.common.base.CharMatcher.10;
import com.google.common.base.CharMatcher.11;
import com.google.common.base.CharMatcher.12;
import com.google.common.base.CharMatcher.13;
import com.google.common.base.CharMatcher.14;
import com.google.common.base.CharMatcher.15;
import com.google.common.base.CharMatcher.2;
import com.google.common.base.CharMatcher.3;
import com.google.common.base.CharMatcher.4;
import com.google.common.base.CharMatcher.5;
import com.google.common.base.CharMatcher.6;
import com.google.common.base.CharMatcher.7;
import com.google.common.base.CharMatcher.8;
import com.google.common.base.CharMatcher.9;
import com.google.common.base.CharMatcher.And;
import com.google.common.base.CharMatcher.BitSetMatcher;
import com.google.common.base.CharMatcher.NegatedFastMatcher;
import com.google.common.base.CharMatcher.NegatedMatcher;
import com.google.common.base.CharMatcher.Or;
import com.google.common.base.CharMatcher.RangesMatcher;
import java.util.Arrays;
import java.util.BitSet;
import javax.annotation.CheckReturnValue;

@Beta
@GwtCompatible(emulated = true)
public abstract class CharMatcher implements Predicate<Character> {
	public static final CharMatcher BREAKING_WHITESPACE = new 1();
	public static final CharMatcher ASCII = inRange(' ', '', "CharMatcher.ASCII");
	private static final String ZEROES = "0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０";
	private static final String NINES;
	public static final CharMatcher DIGIT;
	public static final CharMatcher JAVA_DIGIT;
	public static final CharMatcher JAVA_LETTER;
	public static final CharMatcher JAVA_LETTER_OR_DIGIT;
	public static final CharMatcher JAVA_UPPER_CASE;
	public static final CharMatcher JAVA_LOWER_CASE;
	public static final CharMatcher JAVA_ISO_CONTROL;
	public static final CharMatcher INVISIBLE;
	public static final CharMatcher SINGLE_WIDTH;
	public static final CharMatcher ANY;
	public static final CharMatcher NONE;
	final String description;
	private static final int DISTINCT_CHARS = 65536;
	private static final String WHITESPACE_TABLE = "        \t\n\f\r                             　                              ᠎   ";
	public static final CharMatcher WHITESPACE;

	private static String showCharacter(char c) {
		String hex = "0123456789ABCDEF";
		char[] tmp = new char[]{'\\', 'u', ' ', ' ', ' ', ' '};

		for (int i = 0; i < 4; ++i) {
			tmp[5 - i] = hex.charAt(c & 15);
			c = (char) (c >> 4);
		}

		return String.copyValueOf(tmp);
	}

	public static CharMatcher is(char match) {
      String description = "CharMatcher.is('" + showCharacter(match) + "')";
      return new 9(description, match);
   }

	public static CharMatcher isNot(char match) {
      String description = "CharMatcher.isNot(" + Integer.toHexString(match) + ")";
      return new 10(description, match);
   }

	public static CharMatcher anyOf(CharSequence sequence) {
      switch(sequence.length()) {
      case 0:
         return NONE;
      case 1:
         return is(sequence.charAt(0));
      case 2:
         return isEither(sequence.charAt(0), sequence.charAt(1));
      default:
         char[] chars = sequence.toString().toCharArray();
         Arrays.sort(chars);
         StringBuilder description = new StringBuilder("CharMatcher.anyOf(\"");
         char[] arr$ = chars;
         int len$ = chars.length;

         for(int i$ = 0; i$ < len$; ++i$) {
            char c = arr$[i$];
            description.append(showCharacter(c));
         }

         description.append("\")");
         return new 11(description.toString(), chars);
      }
   }

	private static CharMatcher isEither(char match1, char match2) {
      String description = "CharMatcher.anyOf(\"" + showCharacter(match1) + showCharacter(match2) + "\")";
      return new 12(description, match1, match2);
   }

	public static CharMatcher noneOf(CharSequence sequence) {
		return anyOf(sequence).negate();
	}

	public static CharMatcher inRange(char startInclusive, char endInclusive) {
		Preconditions.checkArgument(endInclusive >= startInclusive);
		String description = "CharMatcher.inRange('" + showCharacter(startInclusive) + "', '"
				+ showCharacter(endInclusive) + "')";
		return inRange(startInclusive, endInclusive, description);
	}

	static CharMatcher inRange(char startInclusive, char endInclusive, String description) {
      return new 13(description, startInclusive, endInclusive);
   }

	public static CharMatcher forPredicate(Predicate<? super Character> predicate) {
      Preconditions.checkNotNull(predicate);
      if (predicate instanceof CharMatcher) {
         return (CharMatcher)predicate;
      } else {
         String description = "CharMatcher.forPredicate(" + predicate + ")";
         return new 14(description, predicate);
      }
   }

	CharMatcher(String description) {
		this.description = description;
	}

	protected CharMatcher() {
		this.description = super.toString();
	}

	public abstract boolean matches(char var1);

	public CharMatcher negate() {
		return new NegatedMatcher(this);
	}

	public CharMatcher and(CharMatcher other) {
		return new And(this, (CharMatcher) Preconditions.checkNotNull(other));
	}

	public CharMatcher or(CharMatcher other) {
		return new Or(this, (CharMatcher) Preconditions.checkNotNull(other));
	}

	public CharMatcher precomputed() {
		return Platform.precomputeCharMatcher(this);
	}

	CharMatcher withToString(String description) {
		throw new UnsupportedOperationException();
	}

	@GwtIncompatible("java.util.BitSet")
	CharMatcher precomputedInternal() {
		BitSet table = new BitSet();
		this.setBits(table);
		int totalCharacters = table.cardinality();
		if (totalCharacters * 2 <= 65536) {
			return precomputedPositive(totalCharacters, table, this.description);
		} else {
			table.flip(0, 65536);
			int negatedCharacters = 65536 - totalCharacters;
			return new NegatedFastMatcher(this.toString(),
					precomputedPositive(negatedCharacters, table, this.description + ".negate()"));
		}
	}

	@GwtIncompatible("java.util.BitSet")
   private static CharMatcher precomputedPositive(int totalCharacters, BitSet table, String description) {
      switch(totalCharacters) {
      case 0:
         return NONE;
      case 1:
         return is((char)table.nextSetBit(0));
      case 2:
         char c1 = (char)table.nextSetBit(0);
         char c2 = (char)table.nextSetBit(c1 + 1);
         return isEither(c1, c2);
      default:
         return (CharMatcher)(isSmall(totalCharacters, table.length()) ? SmallCharMatcher.from(table, description) : new BitSetMatcher(table, description, (1)null));
      }
   }

	private static boolean isSmall(int totalCharacters, int tableLength) {
		return totalCharacters <= 1023 && tableLength > totalCharacters * 16;
	}

	@GwtIncompatible("java.util.BitSet")
	void setBits(BitSet table) {
		for (int c = 65535; c >= 0; --c) {
			if (this.matches((char) c)) {
				table.set(c);
			}
		}

	}

	public boolean matchesAnyOf(CharSequence sequence) {
		return !this.matchesNoneOf(sequence);
	}

	public boolean matchesAllOf(CharSequence sequence) {
		for (int i = sequence.length() - 1; i >= 0; --i) {
			if (!this.matches(sequence.charAt(i))) {
				return false;
			}
		}

		return true;
	}

	public boolean matchesNoneOf(CharSequence sequence) {
		return this.indexIn(sequence) == -1;
	}

	public int indexIn(CharSequence sequence) {
		int length = sequence.length();

		for (int i = 0; i < length; ++i) {
			if (this.matches(sequence.charAt(i))) {
				return i;
			}
		}

		return -1;
	}

	public int indexIn(CharSequence sequence, int start) {
		int length = sequence.length();
		Preconditions.checkPositionIndex(start, length);

		for (int i = start; i < length; ++i) {
			if (this.matches(sequence.charAt(i))) {
				return i;
			}
		}

		return -1;
	}

	public int lastIndexIn(CharSequence sequence) {
		for (int i = sequence.length() - 1; i >= 0; --i) {
			if (this.matches(sequence.charAt(i))) {
				return i;
			}
		}

		return -1;
	}

	public int countIn(CharSequence sequence) {
		int count = 0;

		for (int i = 0; i < sequence.length(); ++i) {
			if (this.matches(sequence.charAt(i))) {
				++count;
			}
		}

		return count;
	}

	@CheckReturnValue
	public String removeFrom(CharSequence sequence) {
		String string = sequence.toString();
		int pos = this.indexIn(string);
		if (pos == -1) {
			return string;
		} else {
			char[] chars = string.toCharArray();
			int spread = 1;

			label25 : while (true) {
				++pos;

				while (pos != chars.length) {
					if (this.matches(chars[pos])) {
						++spread;
						continue label25;
					}

					chars[pos - spread] = chars[pos];
					++pos;
				}

				return new String(chars, 0, pos - spread);
			}
		}
	}

	@CheckReturnValue
	public String retainFrom(CharSequence sequence) {
		return this.negate().removeFrom(sequence);
	}

	@CheckReturnValue
	public String replaceFrom(CharSequence sequence, char replacement) {
		String string = sequence.toString();
		int pos = this.indexIn(string);
		if (pos == -1) {
			return string;
		} else {
			char[] chars = string.toCharArray();
			chars[pos] = replacement;

			for (int i = pos + 1; i < chars.length; ++i) {
				if (this.matches(chars[i])) {
					chars[i] = replacement;
				}
			}

			return new String(chars);
		}
	}

	@CheckReturnValue
	public String replaceFrom(CharSequence sequence, CharSequence replacement) {
		int replacementLen = replacement.length();
		if (replacementLen == 0) {
			return this.removeFrom(sequence);
		} else if (replacementLen == 1) {
			return this.replaceFrom(sequence, replacement.charAt(0));
		} else {
			String string = sequence.toString();
			int pos = this.indexIn(string);
			if (pos == -1) {
				return string;
			} else {
				int len = string.length();
				StringBuilder buf = new StringBuilder(len * 3 / 2 + 16);
				int oldpos = 0;

				do {
					buf.append(string, oldpos, pos);
					buf.append(replacement);
					oldpos = pos + 1;
					pos = this.indexIn(string, oldpos);
				} while (pos != -1);

				buf.append(string, oldpos, len);
				return buf.toString();
			}
		}
	}

	@CheckReturnValue
	public String trimFrom(CharSequence sequence) {
		int len = sequence.length();

		int first;
		for (first = 0; first < len && this.matches(sequence.charAt(first)); ++first) {
			;
		}

		int last;
		for (last = len - 1; last > first && this.matches(sequence.charAt(last)); --last) {
			;
		}

		return sequence.subSequence(first, last + 1).toString();
	}

	@CheckReturnValue
	public String trimLeadingFrom(CharSequence sequence) {
		int len = sequence.length();

		for (int first = 0; first < len; ++first) {
			if (!this.matches(sequence.charAt(first))) {
				return sequence.subSequence(first, len).toString();
			}
		}

		return "";
	}

	@CheckReturnValue
	public String trimTrailingFrom(CharSequence sequence) {
		int len = sequence.length();

		for (int last = len - 1; last >= 0; --last) {
			if (!this.matches(sequence.charAt(last))) {
				return sequence.subSequence(0, last + 1).toString();
			}
		}

		return "";
	}

	@CheckReturnValue
	public String collapseFrom(CharSequence sequence, char replacement) {
		int len = sequence.length();

		for (int i = 0; i < len; ++i) {
			char c = sequence.charAt(i);
			if (this.matches(c)) {
				if (c != replacement || i != len - 1 && this.matches(sequence.charAt(i + 1))) {
					StringBuilder builder = (new StringBuilder(len)).append(sequence.subSequence(0, i))
							.append(replacement);
					return this.finishCollapseFrom(sequence, i + 1, len, replacement, builder, true);
				}

				++i;
			}
		}

		return sequence.toString();
	}

	@CheckReturnValue
	public String trimAndCollapseFrom(CharSequence sequence, char replacement) {
		int len = sequence.length();

		int first;
		for (first = 0; first < len && this.matches(sequence.charAt(first)); ++first) {
			;
		}

		int last;
		for (last = len - 1; last > first && this.matches(sequence.charAt(last)); --last) {
			;
		}

		return first == 0 && last == len - 1
				? this.collapseFrom(sequence, replacement)
				: this.finishCollapseFrom(sequence, first, last + 1, replacement, new StringBuilder(last + 1 - first),
						false);
	}

	private String finishCollapseFrom(CharSequence sequence, int start, int end, char replacement,
			StringBuilder builder, boolean inMatchingGroup) {
		for (int i = start; i < end; ++i) {
			char c = sequence.charAt(i);
			if (this.matches(c)) {
				if (!inMatchingGroup) {
					builder.append(replacement);
					inMatchingGroup = true;
				}
			} else {
				builder.append(c);
				inMatchingGroup = false;
			}
		}

		return builder.toString();
	}

	public boolean apply(Character character) {
		return this.matches(character);
	}

	public String toString() {
		return this.description;
	}

	static {
      StringBuilder builder = new StringBuilder("0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".length());

      for(int i = 0; i < "0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".length(); ++i) {
         builder.append((char)("0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".charAt(i) + 9));
      }

      NINES = builder.toString();
      DIGIT = new RangesMatcher("CharMatcher.DIGIT", "0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".toCharArray(), NINES.toCharArray());
      JAVA_DIGIT = new 2("CharMatcher.JAVA_DIGIT");
      JAVA_LETTER = new 3("CharMatcher.JAVA_LETTER");
      JAVA_LETTER_OR_DIGIT = new 4("CharMatcher.JAVA_LETTER_OR_DIGIT");
      JAVA_UPPER_CASE = new 5("CharMatcher.JAVA_UPPER_CASE");
      JAVA_LOWER_CASE = new 6("CharMatcher.JAVA_LOWER_CASE");
      JAVA_ISO_CONTROL = inRange(' ', '').or(inRange('', '')).withToString("CharMatcher.JAVA_ISO_CONTROL");
      INVISIBLE = new RangesMatcher("CharMatcher.INVISIBLE", " ­؀۝܏ ᠎   ⁪　?﻿￹￺".toCharArray(), "  ­؄۝܏ ᠎‏ ⁤⁯　﻿￹￻".toCharArray());
      SINGLE_WIDTH = new RangesMatcher("CharMatcher.SINGLE_WIDTH", " ־א׳؀ݐ฀Ḁ℀ﭐﹰ｡".toCharArray(), "ӹ־ת״ۿݿ๿₯℺﷿﻿ￜ".toCharArray());
      ANY = new 7("CharMatcher.ANY");
      NONE = new 8("CharMatcher.NONE");
      WHITESPACE = new 15("CharMatcher.WHITESPACE");
   }
}