package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.AttributeConfigurationType;
import com.ibm.ws.wim.configmodel.AttributeGroupType;
import com.ibm.ws.wim.configmodel.AttributeType;
import com.ibm.ws.wim.configmodel.AttributesCacheType;
import com.ibm.ws.wim.configmodel.AuthorizationType;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.CacheConfigurationType;
import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.ContextPoolType;
import com.ibm.ws.wim.configmodel.CustomPropertiesType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.configmodel.DocumentRoot;
import com.ibm.ws.wim.configmodel.DynamicMemberAttributesType;
import com.ibm.ws.wim.configmodel.DynamicModelType;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import com.ibm.ws.wim.configmodel.EnvironmentPropertiesType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.GroupConfigurationType;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.Krb5AuthenticationType;
import com.ibm.ws.wim.configmodel.LdapEntityTypesType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.MemberAttributesType;
import com.ibm.ws.wim.configmodel.MembershipAttributeType;
import com.ibm.ws.wim.configmodel.ModificationSubscriber;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import com.ibm.ws.wim.configmodel.NotificationSubscriber;
import com.ibm.ws.wim.configmodel.NotificationSubscriberList;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.PostExit;
import com.ibm.ws.wim.configmodel.PreExit;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.PropertiesNotSupportedType;
import com.ibm.ws.wim.configmodel.PropertyExtensionRepositoryType;
import com.ibm.ws.wim.configmodel.RdnAttributesType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmDefaultParentType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.configmodel.SPIBridgeRepositoryType;
import com.ibm.ws.wim.configmodel.SearchResultsCacheType;
import com.ibm.ws.wim.configmodel.StaticModelType;
import com.ibm.ws.wim.configmodel.SubscriberType;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import com.ibm.ws.wim.configmodel.TopicSubscriber;
import com.ibm.ws.wim.configmodel.TopicSubscriberList;
import com.ibm.ws.wim.configmodel.UserRegistryInfoMappingType;
import com.ibm.ws.wim.configmodel.impl.ConfigmodelPackageImpl.1;
import java.util.List;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EPackage.Registry;
import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.xml.type.impl.XMLTypePackageImpl;

public class ConfigmodelPackageImpl extends EPackageImpl implements ConfigmodelPackage {
	private EClass attributeConfigurationTypeEClass = null;
	private EClass attributeGroupTypeEClass = null;
	private EClass attributesCacheTypeEClass = null;
	private EClass attributeTypeEClass = null;
	private EClass authorizationTypeEClass = null;
	private EClass baseEntriesTypeEClass = null;
	private EClass cacheConfigurationTypeEClass = null;
	private EClass configurationProviderTypeEClass = null;
	private EClass connectionsTypeEClass = null;
	private EClass contextPoolTypeEClass = null;
	private EClass customPropertiesTypeEClass = null;
	private EClass databaseRepositoryTypeEClass = null;
	private EClass documentRootEClass = null;
	private EClass dynamicMemberAttributesTypeEClass = null;
	private EClass dynamicModelTypeEClass = null;
	private EClass entryMappingRepositoryTypeEClass = null;
	private EClass environmentPropertiesTypeEClass = null;
	private EClass krb5AuthenticationTypeEClass = null;
	private EClass fileRepositoryTypeEClass = null;
	private EClass groupConfigurationTypeEClass = null;
	private EClass inlineExitEClass = null;
	private EClass ldapEntityTypesTypeEClass = null;
	private EClass ldapRepositoryTypeEClass = null;
	private EClass ldapServerConfigurationTypeEClass = null;
	private EClass ldapServersTypeEClass = null;
	private EClass memberAttributesTypeEClass = null;
	private EClass membershipAttributeTypeEClass = null;
	private EClass modificationSubscriberEClass = null;
	private EClass modificationSubscriberListEClass = null;
	private EClass notificationSubscriberEClass = null;
	private EClass notificationSubscriberListEClass = null;
	private EClass participatingBaseEntriesTypeEClass = null;
	private EClass pluginManagerConfigurationTypeEClass = null;
	private EClass postExitEClass = null;
	private EClass preExitEClass = null;
	private EClass profileRepositoryTypeEClass = null;
	private EClass propertiesNotSupportedTypeEClass = null;
	private EClass propertyExtensionRepositoryTypeEClass = null;
	private EClass rdnAttributesTypeEClass = null;
	private EClass realmConfigurationTypeEClass = null;
	private EClass realmDefaultParentTypeEClass = null;
	private EClass realmTypeEClass = null;
	private EClass repositoryTypeEClass = null;
	private EClass searchResultsCacheTypeEClass = null;
	private EClass spiBridgeRepositoryTypeEClass = null;
	private EClass staticModelTypeEClass = null;
	private EClass supportedEntityTypesTypeEClass = null;
	private EClass topicEmitterEClass = null;
	private EClass topicRegistrationListEClass = null;
	private EClass topicSubscriberEClass = null;
	private EClass topicSubscriberListEClass = null;
	private EClass userRegistryInfoMappingTypeEClass = null;
	private EEnum subscriberTypeEEnum = null;
	private EDataType cacheSizeLimitTypeEDataType = null;
	private EDataType cacheSizeLimitTypeObjectEDataType = null;
	private EDataType cacheSizeTypeEDataType = null;
	private EDataType cacheSizeTypeObjectEDataType = null;
	private EDataType cacheTimeOutTypeEDataType = null;
	private EDataType cacheTimeOutTypeObjectEDataType = null;
	private EDataType dnTypeEDataType = null;
	private EDataType initPoolSizeTypeEDataType = null;
	private EDataType initPoolSizeTypeObjectEDataType = null;
	private EDataType maxPoolSizeTypeEDataType = null;
	private EDataType maxPoolSizeTypeObjectEDataType = null;
	private EDataType poolTimeOutTypeEDataType = null;
	private EDataType poolTimeOutTypeObjectEDataType = null;
	private EDataType poolWaitTimeTypeEDataType = null;
	private EDataType poolWaitTimeTypeObjectEDataType = null;
	private EDataType prefPoolSizeTypeEDataType = null;
	private EDataType prefPoolSizeTypeObjectEDataType = null;
	private EDataType realmListTypeEDataType = null;
	private EDataType realmListType1EDataType = null;
	private EDataType subscriberTypeObjectEDataType = null;
	private static boolean isInited = false;
	private boolean isCreated = false;
	private boolean isInitialized = false;

	private ConfigmodelPackageImpl() {
		super("http://www.ibm.com/websphere/wim/config", ConfigmodelFactory.eINSTANCE);
	}

	public static ConfigmodelPackage init() {
      if (isInited) {
         return (ConfigmodelPackage)Registry.INSTANCE.getEPackage("http://www.ibm.com/websphere/wim/config");
      } else {
         ConfigmodelPackageImpl var0 = (ConfigmodelPackageImpl)(Registry.INSTANCE.getEPackage("http://www.ibm.com/websphere/wim/config") instanceof ConfigmodelPackageImpl ? Registry.INSTANCE.getEPackage("http://www.ibm.com/websphere/wim/config") : new ConfigmodelPackageImpl());
         isInited = true;
         XMLTypePackageImpl.init();
         var0.createPackageContents();
         var0.initializePackageContents();
         org.eclipse.emf.ecore.EValidator.Registry.INSTANCE.put(var0, new 1());
         var0.freeze();
         return var0;
      }
   }

	public EClass getAttributeConfigurationType() {
		return this.attributeConfigurationTypeEClass;
	}

	public EReference getAttributeConfigurationType_ExternalIdAttributes() {
		return (EReference) this.attributeConfigurationTypeEClass.getEStructuralFeatures().get(0);
	}

	public EReference getAttributeConfigurationType_Attributes() {
		return (EReference) this.attributeConfigurationTypeEClass.getEStructuralFeatures().get(1);
	}

	public EReference getAttributeConfigurationType_PropertiesNotSupported() {
		return (EReference) this.attributeConfigurationTypeEClass.getEStructuralFeatures().get(2);
	}

	public EClass getAttributeGroupType() {
		return this.attributeGroupTypeEClass;
	}

	public EAttribute getAttributeGroupType_GroupName() {
		return (EAttribute) this.attributeGroupTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getAttributeGroupType_AttributeNames() {
		return (EAttribute) this.attributeGroupTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getAttributesCacheType() {
		return this.attributesCacheTypeEClass;
	}

	public EAttribute getAttributesCacheType_AttributeSizeLimit() {
		return (EAttribute) this.attributesCacheTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getAttributesCacheType_CacheSize() {
		return (EAttribute) this.attributesCacheTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getAttributesCacheType_CacheTimeOut() {
		return (EAttribute) this.attributesCacheTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getAttributesCacheType_Enabled() {
		return (EAttribute) this.attributesCacheTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getAttributesCacheType_ServerTTLAttribute() {
		return (EAttribute) this.attributesCacheTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getAttributesCacheType_CacheDistPolicy() {
		return (EAttribute) this.attributesCacheTypeEClass.getEStructuralFeatures().get(5);
	}

	public EClass getAttributeType() {
		return this.attributeTypeEClass;
	}

	public EAttribute getAttributeType_EntityTypes() {
		return (EAttribute) this.attributeTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getAttributeType_DefaultAttribute() {
		return (EAttribute) this.attributeTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getAttributeType_DefaultValue() {
		return (EAttribute) this.attributeTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getAttributeType_Name() {
		return (EAttribute) this.attributeTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getAttributeType_PropertyName() {
		return (EAttribute) this.attributeTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getAttributeType_Syntax() {
		return (EAttribute) this.attributeTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getAttributeType_WimGenerate() {
		return (EAttribute) this.attributeTypeEClass.getEStructuralFeatures().get(6);
	}

	public EClass getAuthorizationType() {
		return this.authorizationTypeEClass;
	}

	public EReference getAuthorizationType_AttributeGroups() {
		return (EReference) this.authorizationTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getAuthorizationType_DefaultAttributeGroup() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getAuthorizationType_ImportPolicyFromFile() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getAuthorizationType_IsAttributeGroupingEnabled() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getAuthorizationType_IsSecurityEnabled() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getAuthorizationType_JaccPolicyClass() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getAuthorizationType_JaccPolicyConfigFactoryClass() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(6);
	}

	public EAttribute getAuthorizationType_JaccPrincipalToRolePolicyFileName() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(7);
	}

	public EAttribute getAuthorizationType_JaccPrincipalToRolePolicyId() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(8);
	}

	public EAttribute getAuthorizationType_JaccRoleMappingClass() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(9);
	}

	public EAttribute getAuthorizationType_JaccRoleMappingConfigFactoryClass() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(10);
	}

	public EAttribute getAuthorizationType_JaccRoleToPermissionPolicyFileName() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(11);
	}

	public EAttribute getAuthorizationType_JaccRoleToPermissionPolicyId() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(12);
	}

	public EAttribute getAuthorizationType_UseSystemJACCProvider() {
		return (EAttribute) this.authorizationTypeEClass.getEStructuralFeatures().get(13);
	}

	public EClass getBaseEntriesType() {
		return this.baseEntriesTypeEClass;
	}

	public EAttribute getBaseEntriesType_Name() {
		return (EAttribute) this.baseEntriesTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getBaseEntriesType_NameInRepository() {
		return (EAttribute) this.baseEntriesTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getCacheConfigurationType() {
		return this.cacheConfigurationTypeEClass;
	}

	public EReference getCacheConfigurationType_AttributesCache() {
		return (EReference) this.cacheConfigurationTypeEClass.getEStructuralFeatures().get(0);
	}

	public EReference getCacheConfigurationType_SearchResultsCache() {
		return (EReference) this.cacheConfigurationTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getCacheConfigurationType_CachesDiskOffLoad() {
		return (EAttribute) this.cacheConfigurationTypeEClass.getEStructuralFeatures().get(2);
	}

	public EClass getConfigurationProviderType() {
		return this.configurationProviderTypeEClass;
	}

	public EReference getConfigurationProviderType_DynamicModel() {
		return (EReference) this.configurationProviderTypeEClass.getEStructuralFeatures().get(0);
	}

	public EReference getConfigurationProviderType_StaticModel() {
		return (EReference) this.configurationProviderTypeEClass.getEStructuralFeatures().get(1);
	}

	public EReference getConfigurationProviderType_SupportedEntityTypes() {
		return (EReference) this.configurationProviderTypeEClass.getEStructuralFeatures().get(2);
	}

	public EReference getConfigurationProviderType_EntryMappingRepository() {
		return (EReference) this.configurationProviderTypeEClass.getEStructuralFeatures().get(3);
	}

	public EReference getConfigurationProviderType_PropertyExtensionRepository() {
		return (EReference) this.configurationProviderTypeEClass.getEStructuralFeatures().get(4);
	}

	public EReference getConfigurationProviderType_Repositories() {
		return (EReference) this.configurationProviderTypeEClass.getEStructuralFeatures().get(5);
	}

	public EReference getConfigurationProviderType_RealmConfiguration() {
		return (EReference) this.configurationProviderTypeEClass.getEStructuralFeatures().get(6);
	}

	public EReference getConfigurationProviderType_PluginManagerConfiguration() {
		return (EReference) this.configurationProviderTypeEClass.getEStructuralFeatures().get(7);
	}

	public EReference getConfigurationProviderType_Authorization() {
		return (EReference) this.configurationProviderTypeEClass.getEStructuralFeatures().get(8);
	}

	public EAttribute getConfigurationProviderType_MaxPagingResults() {
		return (EAttribute) this.configurationProviderTypeEClass.getEStructuralFeatures().get(9);
	}

	public EAttribute getConfigurationProviderType_MaxSearchResults() {
		return (EAttribute) this.configurationProviderTypeEClass.getEStructuralFeatures().get(10);
	}

	public EAttribute getConfigurationProviderType_MaxTotalPagingResults() {
		return (EAttribute) this.configurationProviderTypeEClass.getEStructuralFeatures().get(11);
	}

	public EAttribute getConfigurationProviderType_PagedCacheTimeOut() {
		return (EAttribute) this.configurationProviderTypeEClass.getEStructuralFeatures().get(12);
	}

	public EAttribute getConfigurationProviderType_PagingCachesDiskOffLoad() {
		return (EAttribute) this.configurationProviderTypeEClass.getEStructuralFeatures().get(13);
	}

	public EAttribute getConfigurationProviderType_PagingEntityObject() {
		return (EAttribute) this.configurationProviderTypeEClass.getEStructuralFeatures().get(14);
	}

	public EAttribute getConfigurationProviderType_SearchTimeOut() {
		return (EAttribute) this.configurationProviderTypeEClass.getEStructuralFeatures().get(15);
	}

	public EClass getConnectionsType() {
		return this.connectionsTypeEClass;
	}

	public EAttribute getConnectionsType_Host() {
		return (EAttribute) this.connectionsTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getConnectionsType_Port() {
		return (EAttribute) this.connectionsTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getContextPoolType() {
		return this.contextPoolTypeEClass;
	}

	public EAttribute getContextPoolType_Enabled() {
		return (EAttribute) this.contextPoolTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getContextPoolType_InitPoolSize() {
		return (EAttribute) this.contextPoolTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getContextPoolType_MaxPoolSize() {
		return (EAttribute) this.contextPoolTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getContextPoolType_PoolTimeOut() {
		return (EAttribute) this.contextPoolTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getContextPoolType_PoolWaitTime() {
		return (EAttribute) this.contextPoolTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getContextPoolType_PrefPoolSize() {
		return (EAttribute) this.contextPoolTypeEClass.getEStructuralFeatures().get(5);
	}

	public EClass getCustomPropertiesType() {
		return this.customPropertiesTypeEClass;
	}

	public EAttribute getCustomPropertiesType_Name() {
		return (EAttribute) this.customPropertiesTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getCustomPropertiesType_Value() {
		return (EAttribute) this.customPropertiesTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getDatabaseRepositoryType() {
		return this.databaseRepositoryTypeEClass;
	}

	public EAttribute getDatabaseRepositoryType_DatabaseType() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getDatabaseRepositoryType_DataSourceName() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getDatabaseRepositoryType_DbAdminId() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getDatabaseRepositoryType_DbAdminPassword() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getDatabaseRepositoryType_DbURL() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getDatabaseRepositoryType_DbSchema() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getDatabaseRepositoryType_EncryptionKey() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(6);
	}

	public EAttribute getDatabaseRepositoryType_EntityRetrievalLimit() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(7);
	}

	public EAttribute getDatabaseRepositoryType_JDBCDriverClass() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(8);
	}

	public EAttribute getDatabaseRepositoryType_SaltLength() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(9);
	}

	public EAttribute getDatabaseRepositoryType_HashAlgorithm() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(10);
	}

	public EAttribute getDatabaseRepositoryType_HashIterations() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(11);
	}

	public EAttribute getDatabaseRepositoryType_HashKeyLength() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(12);
	}

	public EAttribute getDatabaseRepositoryType_HashSaltLength() {
		return (EAttribute) this.databaseRepositoryTypeEClass.getEStructuralFeatures().get(13);
	}

	public EClass getDocumentRoot() {
		return this.documentRootEClass;
	}

	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute) this.documentRootEClass.getEStructuralFeatures().get(0);
	}

	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference) this.documentRootEClass.getEStructuralFeatures().get(1);
	}

	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference) this.documentRootEClass.getEStructuralFeatures().get(2);
	}

	public EReference getDocumentRoot_ConfigurationProvider() {
		return (EReference) this.documentRootEClass.getEStructuralFeatures().get(3);
	}

	public EClass getDynamicMemberAttributesType() {
		return this.dynamicMemberAttributesTypeEClass;
	}

	public EAttribute getDynamicMemberAttributesType_Name() {
		return (EAttribute) this.dynamicMemberAttributesTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getDynamicMemberAttributesType_ObjectClass() {
		return (EAttribute) this.dynamicMemberAttributesTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getDynamicModelType() {
		return this.dynamicModelTypeEClass;
	}

	public EAttribute getDynamicModelType_UseGlobalSchema() {
		return (EAttribute) this.dynamicModelTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getDynamicModelType_XsdFileName() {
		return (EAttribute) this.dynamicModelTypeEClass.getEStructuralFeatures().get(0);
	}

	public EClass getEntryMappingRepositoryType() {
		return this.entryMappingRepositoryTypeEClass;
	}

	public EAttribute getEntryMappingRepositoryType_DatabaseType() {
		return (EAttribute) this.entryMappingRepositoryTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getEntryMappingRepositoryType_DataSourceName() {
		return (EAttribute) this.entryMappingRepositoryTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getEntryMappingRepositoryType_DbAdminId() {
		return (EAttribute) this.entryMappingRepositoryTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getEntryMappingRepositoryType_DbAdminPassword() {
		return (EAttribute) this.entryMappingRepositoryTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getEntryMappingRepositoryType_DbURL() {
		return (EAttribute) this.entryMappingRepositoryTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getEntryMappingRepositoryType_DbSchema() {
		return (EAttribute) this.entryMappingRepositoryTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getEntryMappingRepositoryType_JDBCDriverClass() {
		return (EAttribute) this.entryMappingRepositoryTypeEClass.getEStructuralFeatures().get(6);
	}

	public EClass getEnvironmentPropertiesType() {
		return this.environmentPropertiesTypeEClass;
	}

	public EAttribute getEnvironmentPropertiesType_Name() {
		return (EAttribute) this.environmentPropertiesTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getEnvironmentPropertiesType_Value() {
		return (EAttribute) this.environmentPropertiesTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getFileRepositoryType() {
		return this.fileRepositoryTypeEClass;
	}

	public EAttribute getFileRepositoryType_BaseDirectory() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getFileRepositoryType_CaseSensitive() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getFileRepositoryType_FileName() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getFileRepositoryType_MessageDigestAlgorithm() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getFileRepositoryType_SaltLength() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getFileRepositoryType_KeyLength() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getFileRepositoryType_HashIterations() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(6);
	}

	public EAttribute getFileRepositoryType_AccountLockoutThreshold() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(7);
	}

	public EAttribute getFileRepositoryType_AccountLockoutDuration() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(8);
	}

	public EAttribute getFileRepositoryType_IgnoreFailedLoginAfter() {
		return (EAttribute) this.fileRepositoryTypeEClass.getEStructuralFeatures().get(9);
	}

	public EClass getGroupConfigurationType() {
		return this.groupConfigurationTypeEClass;
	}

	public EReference getGroupConfigurationType_MemberAttributes() {
		return (EReference) this.groupConfigurationTypeEClass.getEStructuralFeatures().get(0);
	}

	public EReference getGroupConfigurationType_DynamicMemberAttributes() {
		return (EReference) this.groupConfigurationTypeEClass.getEStructuralFeatures().get(1);
	}

	public EReference getGroupConfigurationType_MembershipAttribute() {
		return (EReference) this.groupConfigurationTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getGroupConfigurationType_UpdateGroupMembership() {
		return (EAttribute) this.groupConfigurationTypeEClass.getEStructuralFeatures().get(3);
	}

	public EClass getInlineExit() {
		return this.inlineExitEClass;
	}

	public EReference getInlineExit_ModificationSubscriberList() {
		return (EReference) this.inlineExitEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getInlineExit_InlineExitName() {
		return (EAttribute) this.inlineExitEClass.getEStructuralFeatures().get(1);
	}

	public EClass getLdapEntityTypesType() {
		return this.ldapEntityTypesTypeEClass;
	}

	public EReference getLdapEntityTypesType_RdnAttributes() {
		return (EReference) this.ldapEntityTypesTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getLdapEntityTypesType_ObjectClasses() {
		return (EAttribute) this.ldapEntityTypesTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getLdapEntityTypesType_ObjectClassesForCreate() {
		return (EAttribute) this.ldapEntityTypesTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getLdapEntityTypesType_SearchBases() {
		return (EAttribute) this.ldapEntityTypesTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getLdapEntityTypesType_Name() {
		return (EAttribute) this.ldapEntityTypesTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getLdapEntityTypesType_SearchFilter() {
		return (EAttribute) this.ldapEntityTypesTypeEClass.getEStructuralFeatures().get(5);
	}

	public EClass getLdapRepositoryType() {
		return this.ldapRepositoryTypeEClass;
	}

	public EReference getLdapRepositoryType_LdapServerConfiguration() {
		return (EReference) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(0);
	}

	public EReference getLdapRepositoryType_LdapEntityTypes() {
		return (EReference) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(1);
	}

	public EReference getLdapRepositoryType_GroupConfiguration() {
		return (EReference) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(2);
	}

	public EReference getLdapRepositoryType_AttributeConfiguration() {
		return (EReference) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(3);
	}

	public EReference getLdapRepositoryType_ContextPool() {
		return (EReference) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(4);
	}

	public EReference getLdapRepositoryType_CacheConfiguration() {
		return (EReference) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getLdapRepositoryType_CertificateFilter() {
		return (EAttribute) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(6);
	}

	public EAttribute getLdapRepositoryType_CertificateMapMode() {
		return (EAttribute) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(7);
	}

	public EAttribute getLdapRepositoryType_LdapServerType() {
		return (EAttribute) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(8);
	}

	public EAttribute getLdapRepositoryType_TranslateRDN() {
		return (EAttribute) this.ldapRepositoryTypeEClass.getEStructuralFeatures().get(9);
	}

	public EClass getLdapServerConfigurationType() {
		return this.ldapServerConfigurationTypeEClass;
	}

	public EReference getLdapServerConfigurationType_LdapServers() {
		return (EReference) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getLdapServerConfigurationType_AllowWriteToSecondaryServers() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getLdapServerConfigurationType_AttributeRangeStep() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getLdapServerConfigurationType_PrimaryServerQueryTimeInterval() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getLdapServerConfigurationType_ReturnToPrimaryServer() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getLdapServerConfigurationType_SearchCountLimit() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getLdapServerConfigurationType_SearchPageSize() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(6);
	}

	public EAttribute getLdapServerConfigurationType_SearchTimeLimit() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(7);
	}

	public EAttribute getLdapServerConfigurationType_SslConfiguration() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(8);
	}

	public EAttribute getLdapServerConfigurationType_SslKeyStore() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(9);
	}

	public EAttribute getLdapServerConfigurationType_SslKeyStorePassword() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(10);
	}

	public EAttribute getLdapServerConfigurationType_SslKeyStoreType() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(11);
	}

	public EAttribute getLdapServerConfigurationType_SslTrustStore() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(12);
	}

	public EAttribute getLdapServerConfigurationType_SslTrustStorePassword() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(13);
	}

	public EAttribute getLdapServerConfigurationType_SslTrustStoreType() {
		return (EAttribute) this.ldapServerConfigurationTypeEClass.getEStructuralFeatures().get(14);
	}

	public EClass getLdapServersType() {
		return this.ldapServersTypeEClass;
	}

	public EReference getLdapServersType_Connections() {
		return (EReference) this.ldapServersTypeEClass.getEStructuralFeatures().get(0);
	}

	public EReference getLdapServersType_EnvironmentProperties() {
		return (EReference) this.ldapServersTypeEClass.getEStructuralFeatures().get(1);
	}

	public EReference getLdapServersType_Krb5Authentication() {
		return (EReference) this.ldapServersTypeEClass.getEStructuralFeatures().get(11);
	}

	public EAttribute getLdapServersType_Authentication() {
		return (EAttribute) this.ldapServersTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getLdapServersType_BindDN() {
		return (EAttribute) this.ldapServersTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getLdapServersType_BindPassword() {
		return (EAttribute) this.ldapServersTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getLdapServersType_ConnectionPool() {
		return (EAttribute) this.ldapServersTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getLdapServersType_ConnectTimeout() {
		return (EAttribute) this.ldapServersTypeEClass.getEStructuralFeatures().get(6);
	}

	public EAttribute getLdapServersType_DerefAliases() {
		return (EAttribute) this.ldapServersTypeEClass.getEStructuralFeatures().get(7);
	}

	public EAttribute getLdapServersType_Referal() {
		return (EAttribute) this.ldapServersTypeEClass.getEStructuralFeatures().get(8);
	}

	public EAttribute getLdapServersType_SslEnabled() {
		return (EAttribute) this.ldapServersTypeEClass.getEStructuralFeatures().get(9);
	}

	public EAttribute getLdapServersType_BindAuthMechanism() {
		return (EAttribute) this.ldapServersTypeEClass.getEStructuralFeatures().get(10);
	}

	public EClass getKrb5AuthenticationType() {
		return this.krb5AuthenticationTypeEClass;
	}

	public EAttribute getKrb5AuthenticationType_Krb5Principal() {
		return (EAttribute) this.krb5AuthenticationTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getKrb5AuthenticationType_Krb5TicketCache() {
		return (EAttribute) this.krb5AuthenticationTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getMemberAttributesType() {
		return this.memberAttributesTypeEClass;
	}

	public EAttribute getMemberAttributesType_DummyMember() {
		return (EAttribute) this.memberAttributesTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getMemberAttributesType_Name() {
		return (EAttribute) this.memberAttributesTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getMemberAttributesType_ObjectClass() {
		return (EAttribute) this.memberAttributesTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getMemberAttributesType_Scope() {
		return (EAttribute) this.memberAttributesTypeEClass.getEStructuralFeatures().get(3);
	}

	public EClass getMembershipAttributeType() {
		return this.membershipAttributeTypeEClass;
	}

	public EAttribute getMembershipAttributeType_Name() {
		return (EAttribute) this.membershipAttributeTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getMembershipAttributeType_Scope() {
		return (EAttribute) this.membershipAttributeTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getModificationSubscriber() {
		return this.modificationSubscriberEClass;
	}

	public EAttribute getModificationSubscriber_ModificationSubscriberReference() {
		return (EAttribute) this.modificationSubscriberEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getModificationSubscriber_RealmList() {
		return (EAttribute) this.modificationSubscriberEClass.getEStructuralFeatures().get(1);
	}

	public EClass getModificationSubscriberList() {
		return this.modificationSubscriberListEClass;
	}

	public EReference getModificationSubscriberList_ModificationSubscriber() {
		return (EReference) this.modificationSubscriberListEClass.getEStructuralFeatures().get(0);
	}

	public EClass getNotificationSubscriber() {
		return this.notificationSubscriberEClass;
	}

	public EAttribute getNotificationSubscriber_NotificationSubscriberReference() {
		return (EAttribute) this.notificationSubscriberEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getNotificationSubscriber_RealmList() {
		return (EAttribute) this.notificationSubscriberEClass.getEStructuralFeatures().get(1);
	}

	public EClass getNotificationSubscriberList() {
		return this.notificationSubscriberListEClass;
	}

	public EReference getNotificationSubscriberList_NotificationSubscriber() {
		return (EReference) this.notificationSubscriberListEClass.getEStructuralFeatures().get(0);
	}

	public EClass getParticipatingBaseEntriesType() {
		return this.participatingBaseEntriesTypeEClass;
	}

	public EAttribute getParticipatingBaseEntriesType_Name() {
		return (EAttribute) this.participatingBaseEntriesTypeEClass.getEStructuralFeatures().get(0);
	}

	public EClass getPluginManagerConfigurationType() {
		return this.pluginManagerConfigurationTypeEClass;
	}

	public EReference getPluginManagerConfigurationType_TopicSubscriberList() {
		return (EReference) this.pluginManagerConfigurationTypeEClass.getEStructuralFeatures().get(0);
	}

	public EReference getPluginManagerConfigurationType_TopicRegistrationList() {
		return (EReference) this.pluginManagerConfigurationTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getPostExit() {
		return this.postExitEClass;
	}

	public EReference getPostExit_ModificationSubscriberList() {
		return (EReference) this.postExitEClass.getEStructuralFeatures().get(0);
	}

	public EReference getPostExit_NotificationSubscriberList() {
		return (EReference) this.postExitEClass.getEStructuralFeatures().get(1);
	}

	public EClass getPreExit() {
		return this.preExitEClass;
	}

	public EReference getPreExit_NotificationSubscriberList() {
		return (EReference) this.preExitEClass.getEStructuralFeatures().get(0);
	}

	public EReference getPreExit_ModificationSubscriberList() {
		return (EReference) this.preExitEClass.getEStructuralFeatures().get(1);
	}

	public EClass getProfileRepositoryType() {
		return this.profileRepositoryTypeEClass;
	}

	public EReference getProfileRepositoryType_BaseEntries() {
		return (EReference) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getProfileRepositoryType_EntityTypesNotAllowCreate() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getProfileRepositoryType_EntityTypesNotAllowUpdate() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getProfileRepositoryType_EntityTypesNotAllowRead() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getProfileRepositoryType_EntityTypesNotAllowDelete() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getProfileRepositoryType_RepositoriesForGroups() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getProfileRepositoryType_LoginProperties() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(6);
	}

	public EReference getProfileRepositoryType_CustomProperties() {
		return (EReference) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(7);
	}

	public EAttribute getProfileRepositoryType_IsExtIdUnique() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(8);
	}

	public EAttribute getProfileRepositoryType_ReadOnly() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(9);
	}

	public EAttribute getProfileRepositoryType_SupportAsyncMode() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(10);
	}

	public EAttribute getProfileRepositoryType_SupportExternalName() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(11);
	}

	public EAttribute getProfileRepositoryType_SupportPaging() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(12);
	}

	public EAttribute getProfileRepositoryType_SupportSorting() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(13);
	}

	public EAttribute getProfileRepositoryType_SupportTransactions() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(14);
	}

	public EAttribute getProfileRepositoryType_SupportChangeLog() {
		return (EAttribute) this.profileRepositoryTypeEClass.getEStructuralFeatures().get(15);
	}

	public EClass getPropertiesNotSupportedType() {
		return this.propertiesNotSupportedTypeEClass;
	}

	public EAttribute getPropertiesNotSupportedType_EntityTypes() {
		return (EAttribute) this.propertiesNotSupportedTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getPropertiesNotSupportedType_Name() {
		return (EAttribute) this.propertiesNotSupportedTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getPropertyExtensionRepositoryType() {
		return this.propertyExtensionRepositoryTypeEClass;
	}

	public EAttribute getPropertyExtensionRepositoryType_DatabaseType() {
		return (EAttribute) this.propertyExtensionRepositoryTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getPropertyExtensionRepositoryType_DataSourceName() {
		return (EAttribute) this.propertyExtensionRepositoryTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getPropertyExtensionRepositoryType_DbAdminId() {
		return (EAttribute) this.propertyExtensionRepositoryTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getPropertyExtensionRepositoryType_DbAdminPassword() {
		return (EAttribute) this.propertyExtensionRepositoryTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getPropertyExtensionRepositoryType_DbURL() {
		return (EAttribute) this.propertyExtensionRepositoryTypeEClass.getEStructuralFeatures().get(4);
	}

	public EAttribute getPropertyExtensionRepositoryType_DbSchema() {
		return (EAttribute) this.propertyExtensionRepositoryTypeEClass.getEStructuralFeatures().get(5);
	}

	public EAttribute getPropertyExtensionRepositoryType_EntityRetrievalLimit() {
		return (EAttribute) this.propertyExtensionRepositoryTypeEClass.getEStructuralFeatures().get(6);
	}

	public EAttribute getPropertyExtensionRepositoryType_JDBCDriverClass() {
		return (EAttribute) this.propertyExtensionRepositoryTypeEClass.getEStructuralFeatures().get(7);
	}

	public EClass getRdnAttributesType() {
		return this.rdnAttributesTypeEClass;
	}

	public EAttribute getRdnAttributesType_Name() {
		return (EAttribute) this.rdnAttributesTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getRdnAttributesType_ObjectClass() {
		return (EAttribute) this.rdnAttributesTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getRealmConfigurationType() {
		return this.realmConfigurationTypeEClass;
	}

	public EReference getRealmConfigurationType_Realms() {
		return (EReference) this.realmConfigurationTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getRealmConfigurationType_DefaultRealm() {
		return (EAttribute) this.realmConfigurationTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getRealmDefaultParentType() {
		return this.realmDefaultParentTypeEClass;
	}

	public EAttribute getRealmDefaultParentType_EntityTypeName() {
		return (EAttribute) this.realmDefaultParentTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getRealmDefaultParentType_ParentUniqueName() {
		return (EAttribute) this.realmDefaultParentTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getRealmType() {
		return this.realmTypeEClass;
	}

	public EReference getRealmType_ParticipatingBaseEntries() {
		return (EReference) this.realmTypeEClass.getEStructuralFeatures().get(0);
	}

	public EReference getRealmType_DefaultParents() {
		return (EReference) this.realmTypeEClass.getEStructuralFeatures().get(1);
	}

	public EReference getRealmType_UniqueUserIdMapping() {
		return (EReference) this.realmTypeEClass.getEStructuralFeatures().get(2);
	}

	public EReference getRealmType_UserSecurityNameMapping() {
		return (EReference) this.realmTypeEClass.getEStructuralFeatures().get(3);
	}

	public EReference getRealmType_UserDisplayNameMapping() {
		return (EReference) this.realmTypeEClass.getEStructuralFeatures().get(4);
	}

	public EReference getRealmType_UniqueGroupIdMapping() {
		return (EReference) this.realmTypeEClass.getEStructuralFeatures().get(5);
	}

	public EReference getRealmType_GroupSecurityNameMapping() {
		return (EReference) this.realmTypeEClass.getEStructuralFeatures().get(6);
	}

	public EReference getRealmType_GroupDisplayNameMapping() {
		return (EReference) this.realmTypeEClass.getEStructuralFeatures().get(7);
	}

	public EAttribute getRealmType_Delimiter() {
		return (EAttribute) this.realmTypeEClass.getEStructuralFeatures().get(8);
	}

	public EAttribute getRealmType_Name() {
		return (EAttribute) this.realmTypeEClass.getEStructuralFeatures().get(9);
	}

	public EAttribute getRealmType_SecurityUse() {
		return (EAttribute) this.realmTypeEClass.getEStructuralFeatures().get(10);
	}

	public EAttribute getRealmType_AllowOperationIfReposDown() {
		return (EAttribute) this.realmTypeEClass.getEStructuralFeatures().get(11);
	}

	public EClass getRepositoryType() {
		return this.repositoryTypeEClass;
	}

	public EAttribute getRepositoryType_AdapterClassName() {
		return (EAttribute) this.repositoryTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getRepositoryType_Id() {
		return (EAttribute) this.repositoryTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getSearchResultsCacheType() {
		return this.searchResultsCacheTypeEClass;
	}

	public EAttribute getSearchResultsCacheType_CacheSize() {
		return (EAttribute) this.searchResultsCacheTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getSearchResultsCacheType_CacheTimeOut() {
		return (EAttribute) this.searchResultsCacheTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getSearchResultsCacheType_Enabled() {
		return (EAttribute) this.searchResultsCacheTypeEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getSearchResultsCacheType_SearchResultSizeLimit() {
		return (EAttribute) this.searchResultsCacheTypeEClass.getEStructuralFeatures().get(3);
	}

	public EAttribute getSearchResultsCacheType_CacheDistPolicy() {
		return (EAttribute) this.searchResultsCacheTypeEClass.getEStructuralFeatures().get(4);
	}

	public EClass getSPIBridgeRepositoryType() {
		return this.spiBridgeRepositoryTypeEClass;
	}

	public EAttribute getSPIBridgeRepositoryType_WMMAdapterClassName() {
		return (EAttribute) this.spiBridgeRepositoryTypeEClass.getEStructuralFeatures().get(0);
	}

	public EClass getStaticModelType() {
		return this.staticModelTypeEClass;
	}

	public EAttribute getStaticModelType_PackageName() {
		return (EAttribute) this.staticModelTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getStaticModelType_UseGlobalSchema() {
		return (EAttribute) this.staticModelTypeEClass.getEStructuralFeatures().get(1);
	}

	public EClass getSupportedEntityTypesType() {
		return this.supportedEntityTypesTypeEClass;
	}

	public EAttribute getSupportedEntityTypesType_RdnProperties() {
		return (EAttribute) this.supportedEntityTypesTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getSupportedEntityTypesType_DefaultParent() {
		return (EAttribute) this.supportedEntityTypesTypeEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getSupportedEntityTypesType_Name() {
		return (EAttribute) this.supportedEntityTypesTypeEClass.getEStructuralFeatures().get(2);
	}

	public EClass getTopicEmitter() {
		return this.topicEmitterEClass;
	}

	public EReference getTopicEmitter_PreExit() {
		return (EReference) this.topicEmitterEClass.getEStructuralFeatures().get(0);
	}

	public EReference getTopicEmitter_InlineExit() {
		return (EReference) this.topicEmitterEClass.getEStructuralFeatures().get(1);
	}

	public EReference getTopicEmitter_PostExit() {
		return (EReference) this.topicEmitterEClass.getEStructuralFeatures().get(2);
	}

	public EAttribute getTopicEmitter_TopicEmitterName() {
		return (EAttribute) this.topicEmitterEClass.getEStructuralFeatures().get(3);
	}

	public EClass getTopicRegistrationList() {
		return this.topicRegistrationListEClass;
	}

	public EReference getTopicRegistrationList_TopicEmitter() {
		return (EReference) this.topicRegistrationListEClass.getEStructuralFeatures().get(0);
	}

	public EClass getTopicSubscriber() {
		return this.topicSubscriberEClass;
	}

	public EAttribute getTopicSubscriber_ClassName() {
		return (EAttribute) this.topicSubscriberEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getTopicSubscriber_TopicSubscriberName() {
		return (EAttribute) this.topicSubscriberEClass.getEStructuralFeatures().get(1);
	}

	public EAttribute getTopicSubscriber_TopicSubscriberType() {
		return (EAttribute) this.topicSubscriberEClass.getEStructuralFeatures().get(2);
	}

	public EClass getTopicSubscriberList() {
		return this.topicSubscriberListEClass;
	}

	public EReference getTopicSubscriberList_TopicSubscriber() {
		return (EReference) this.topicSubscriberListEClass.getEStructuralFeatures().get(0);
	}

	public EClass getUserRegistryInfoMappingType() {
		return this.userRegistryInfoMappingTypeEClass;
	}

	public EAttribute getUserRegistryInfoMappingType_PropertyForInput() {
		return (EAttribute) this.userRegistryInfoMappingTypeEClass.getEStructuralFeatures().get(0);
	}

	public EAttribute getUserRegistryInfoMappingType_PropertyForOutput() {
		return (EAttribute) this.userRegistryInfoMappingTypeEClass.getEStructuralFeatures().get(1);
	}

	public EEnum getSubscriberType() {
		return this.subscriberTypeEEnum;
	}

	public EDataType getCacheSizeLimitType() {
		return this.cacheSizeLimitTypeEDataType;
	}

	public EDataType getCacheSizeLimitTypeObject() {
		return this.cacheSizeLimitTypeObjectEDataType;
	}

	public EDataType getCacheSizeType() {
		return this.cacheSizeTypeEDataType;
	}

	public EDataType getCacheSizeTypeObject() {
		return this.cacheSizeTypeObjectEDataType;
	}

	public EDataType getCacheTimeOutType() {
		return this.cacheTimeOutTypeEDataType;
	}

	public EDataType getCacheTimeOutTypeObject() {
		return this.cacheTimeOutTypeObjectEDataType;
	}

	public EDataType getDNType() {
		return this.dnTypeEDataType;
	}

	public EDataType getInitPoolSizeType() {
		return this.initPoolSizeTypeEDataType;
	}

	public EDataType getInitPoolSizeTypeObject() {
		return this.initPoolSizeTypeObjectEDataType;
	}

	public EDataType getMaxPoolSizeType() {
		return this.maxPoolSizeTypeEDataType;
	}

	public EDataType getMaxPoolSizeTypeObject() {
		return this.maxPoolSizeTypeObjectEDataType;
	}

	public EDataType getPoolTimeOutType() {
		return this.poolTimeOutTypeEDataType;
	}

	public EDataType getPoolTimeOutTypeObject() {
		return this.poolTimeOutTypeObjectEDataType;
	}

	public EDataType getPoolWaitTimeType() {
		return this.poolWaitTimeTypeEDataType;
	}

	public EDataType getPoolWaitTimeTypeObject() {
		return this.poolWaitTimeTypeObjectEDataType;
	}

	public EDataType getPrefPoolSizeType() {
		return this.prefPoolSizeTypeEDataType;
	}

	public EDataType getPrefPoolSizeTypeObject() {
		return this.prefPoolSizeTypeObjectEDataType;
	}

	public EDataType getRealmListType() {
		return this.realmListTypeEDataType;
	}

	public EDataType getRealmListType1() {
		return this.realmListType1EDataType;
	}

	public EDataType getSubscriberTypeObject() {
		return this.subscriberTypeObjectEDataType;
	}

	public ConfigmodelFactory getConfigmodelFactory() {
		return (ConfigmodelFactory) this.getEFactoryInstance();
	}

	public void createPackageContents() {
		if (!this.isCreated) {
			this.isCreated = true;
			this.attributeConfigurationTypeEClass = this.createEClass(0);
			this.createEReference(this.attributeConfigurationTypeEClass, 0);
			this.createEReference(this.attributeConfigurationTypeEClass, 1);
			this.createEReference(this.attributeConfigurationTypeEClass, 2);
			this.attributeGroupTypeEClass = this.createEClass(1);
			this.createEAttribute(this.attributeGroupTypeEClass, 0);
			this.createEAttribute(this.attributeGroupTypeEClass, 1);
			this.attributesCacheTypeEClass = this.createEClass(2);
			this.createEAttribute(this.attributesCacheTypeEClass, 0);
			this.createEAttribute(this.attributesCacheTypeEClass, 1);
			this.createEAttribute(this.attributesCacheTypeEClass, 2);
			this.createEAttribute(this.attributesCacheTypeEClass, 3);
			this.createEAttribute(this.attributesCacheTypeEClass, 4);
			this.createEAttribute(this.attributesCacheTypeEClass, 5);
			this.attributeTypeEClass = this.createEClass(3);
			this.createEAttribute(this.attributeTypeEClass, 0);
			this.createEAttribute(this.attributeTypeEClass, 1);
			this.createEAttribute(this.attributeTypeEClass, 2);
			this.createEAttribute(this.attributeTypeEClass, 3);
			this.createEAttribute(this.attributeTypeEClass, 4);
			this.createEAttribute(this.attributeTypeEClass, 5);
			this.createEAttribute(this.attributeTypeEClass, 6);
			this.authorizationTypeEClass = this.createEClass(4);
			this.createEReference(this.authorizationTypeEClass, 0);
			this.createEAttribute(this.authorizationTypeEClass, 1);
			this.createEAttribute(this.authorizationTypeEClass, 2);
			this.createEAttribute(this.authorizationTypeEClass, 3);
			this.createEAttribute(this.authorizationTypeEClass, 4);
			this.createEAttribute(this.authorizationTypeEClass, 5);
			this.createEAttribute(this.authorizationTypeEClass, 6);
			this.createEAttribute(this.authorizationTypeEClass, 7);
			this.createEAttribute(this.authorizationTypeEClass, 8);
			this.createEAttribute(this.authorizationTypeEClass, 9);
			this.createEAttribute(this.authorizationTypeEClass, 10);
			this.createEAttribute(this.authorizationTypeEClass, 11);
			this.createEAttribute(this.authorizationTypeEClass, 12);
			this.createEAttribute(this.authorizationTypeEClass, 13);
			this.baseEntriesTypeEClass = this.createEClass(5);
			this.createEAttribute(this.baseEntriesTypeEClass, 0);
			this.createEAttribute(this.baseEntriesTypeEClass, 1);
			this.cacheConfigurationTypeEClass = this.createEClass(6);
			this.createEReference(this.cacheConfigurationTypeEClass, 0);
			this.createEReference(this.cacheConfigurationTypeEClass, 1);
			this.createEAttribute(this.cacheConfigurationTypeEClass, 2);
			this.configurationProviderTypeEClass = this.createEClass(7);
			this.createEReference(this.configurationProviderTypeEClass, 0);
			this.createEReference(this.configurationProviderTypeEClass, 1);
			this.createEReference(this.configurationProviderTypeEClass, 2);
			this.createEReference(this.configurationProviderTypeEClass, 3);
			this.createEReference(this.configurationProviderTypeEClass, 4);
			this.createEReference(this.configurationProviderTypeEClass, 5);
			this.createEReference(this.configurationProviderTypeEClass, 6);
			this.createEReference(this.configurationProviderTypeEClass, 7);
			this.createEReference(this.configurationProviderTypeEClass, 8);
			this.createEAttribute(this.configurationProviderTypeEClass, 9);
			this.createEAttribute(this.configurationProviderTypeEClass, 10);
			this.createEAttribute(this.configurationProviderTypeEClass, 11);
			this.createEAttribute(this.configurationProviderTypeEClass, 12);
			this.createEAttribute(this.configurationProviderTypeEClass, 13);
			this.createEAttribute(this.configurationProviderTypeEClass, 14);
			this.createEAttribute(this.configurationProviderTypeEClass, 15);
			this.connectionsTypeEClass = this.createEClass(8);
			this.createEAttribute(this.connectionsTypeEClass, 0);
			this.createEAttribute(this.connectionsTypeEClass, 1);
			this.contextPoolTypeEClass = this.createEClass(9);
			this.createEAttribute(this.contextPoolTypeEClass, 0);
			this.createEAttribute(this.contextPoolTypeEClass, 1);
			this.createEAttribute(this.contextPoolTypeEClass, 2);
			this.createEAttribute(this.contextPoolTypeEClass, 3);
			this.createEAttribute(this.contextPoolTypeEClass, 4);
			this.createEAttribute(this.contextPoolTypeEClass, 5);
			this.customPropertiesTypeEClass = this.createEClass(10);
			this.createEAttribute(this.customPropertiesTypeEClass, 0);
			this.createEAttribute(this.customPropertiesTypeEClass, 1);
			this.databaseRepositoryTypeEClass = this.createEClass(11);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 18);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 19);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 20);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 21);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 22);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 23);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 24);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 25);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 26);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 27);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 28);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 29);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 30);
			this.createEAttribute(this.databaseRepositoryTypeEClass, 31);
			this.documentRootEClass = this.createEClass(12);
			this.createEAttribute(this.documentRootEClass, 0);
			this.createEReference(this.documentRootEClass, 1);
			this.createEReference(this.documentRootEClass, 2);
			this.createEReference(this.documentRootEClass, 3);
			this.dynamicMemberAttributesTypeEClass = this.createEClass(13);
			this.createEAttribute(this.dynamicMemberAttributesTypeEClass, 0);
			this.createEAttribute(this.dynamicMemberAttributesTypeEClass, 1);
			this.dynamicModelTypeEClass = this.createEClass(14);
			this.createEAttribute(this.dynamicModelTypeEClass, 0);
			this.createEAttribute(this.dynamicModelTypeEClass, 1);
			this.entryMappingRepositoryTypeEClass = this.createEClass(15);
			this.createEAttribute(this.entryMappingRepositoryTypeEClass, 2);
			this.createEAttribute(this.entryMappingRepositoryTypeEClass, 3);
			this.createEAttribute(this.entryMappingRepositoryTypeEClass, 4);
			this.createEAttribute(this.entryMappingRepositoryTypeEClass, 5);
			this.createEAttribute(this.entryMappingRepositoryTypeEClass, 6);
			this.createEAttribute(this.entryMappingRepositoryTypeEClass, 7);
			this.createEAttribute(this.entryMappingRepositoryTypeEClass, 8);
			this.environmentPropertiesTypeEClass = this.createEClass(16);
			this.createEAttribute(this.environmentPropertiesTypeEClass, 0);
			this.createEAttribute(this.environmentPropertiesTypeEClass, 1);
			this.fileRepositoryTypeEClass = this.createEClass(17);
			this.createEAttribute(this.fileRepositoryTypeEClass, 18);
			this.createEAttribute(this.fileRepositoryTypeEClass, 19);
			this.createEAttribute(this.fileRepositoryTypeEClass, 20);
			this.createEAttribute(this.fileRepositoryTypeEClass, 21);
			this.createEAttribute(this.fileRepositoryTypeEClass, 22);
			this.createEAttribute(this.fileRepositoryTypeEClass, 23);
			this.createEAttribute(this.fileRepositoryTypeEClass, 24);
			this.createEAttribute(this.fileRepositoryTypeEClass, 25);
			this.createEAttribute(this.fileRepositoryTypeEClass, 26);
			this.createEAttribute(this.fileRepositoryTypeEClass, 27);
			this.groupConfigurationTypeEClass = this.createEClass(18);
			this.createEReference(this.groupConfigurationTypeEClass, 0);
			this.createEReference(this.groupConfigurationTypeEClass, 1);
			this.createEReference(this.groupConfigurationTypeEClass, 2);
			this.createEAttribute(this.groupConfigurationTypeEClass, 3);
			this.inlineExitEClass = this.createEClass(19);
			this.createEReference(this.inlineExitEClass, 0);
			this.createEAttribute(this.inlineExitEClass, 1);
			this.ldapEntityTypesTypeEClass = this.createEClass(20);
			this.createEReference(this.ldapEntityTypesTypeEClass, 0);
			this.createEAttribute(this.ldapEntityTypesTypeEClass, 1);
			this.createEAttribute(this.ldapEntityTypesTypeEClass, 2);
			this.createEAttribute(this.ldapEntityTypesTypeEClass, 3);
			this.createEAttribute(this.ldapEntityTypesTypeEClass, 4);
			this.createEAttribute(this.ldapEntityTypesTypeEClass, 5);
			this.ldapRepositoryTypeEClass = this.createEClass(21);
			this.createEReference(this.ldapRepositoryTypeEClass, 18);
			this.createEReference(this.ldapRepositoryTypeEClass, 19);
			this.createEReference(this.ldapRepositoryTypeEClass, 20);
			this.createEReference(this.ldapRepositoryTypeEClass, 21);
			this.createEReference(this.ldapRepositoryTypeEClass, 22);
			this.createEReference(this.ldapRepositoryTypeEClass, 23);
			this.createEAttribute(this.ldapRepositoryTypeEClass, 24);
			this.createEAttribute(this.ldapRepositoryTypeEClass, 25);
			this.createEAttribute(this.ldapRepositoryTypeEClass, 26);
			this.createEAttribute(this.ldapRepositoryTypeEClass, 27);
			this.ldapServerConfigurationTypeEClass = this.createEClass(22);
			this.createEReference(this.ldapServerConfigurationTypeEClass, 0);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 1);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 2);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 3);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 4);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 5);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 6);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 7);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 8);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 9);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 10);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 11);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 12);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 13);
			this.createEAttribute(this.ldapServerConfigurationTypeEClass, 14);
			this.ldapServersTypeEClass = this.createEClass(23);
			this.createEReference(this.ldapServersTypeEClass, 0);
			this.createEReference(this.ldapServersTypeEClass, 1);
			this.createEAttribute(this.ldapServersTypeEClass, 2);
			this.createEAttribute(this.ldapServersTypeEClass, 3);
			this.createEAttribute(this.ldapServersTypeEClass, 4);
			this.createEAttribute(this.ldapServersTypeEClass, 5);
			this.createEAttribute(this.ldapServersTypeEClass, 6);
			this.createEAttribute(this.ldapServersTypeEClass, 7);
			this.createEAttribute(this.ldapServersTypeEClass, 8);
			this.createEAttribute(this.ldapServersTypeEClass, 9);
			this.createEAttribute(this.ldapServersTypeEClass, 10);
			this.krb5AuthenticationTypeEClass = this.createEClass(72);
			this.createEAttribute(this.krb5AuthenticationTypeEClass, 0);
			this.createEAttribute(this.krb5AuthenticationTypeEClass, 1);
			this.createEReference(this.ldapServersTypeEClass, 11);
			this.memberAttributesTypeEClass = this.createEClass(24);
			this.createEAttribute(this.memberAttributesTypeEClass, 0);
			this.createEAttribute(this.memberAttributesTypeEClass, 1);
			this.createEAttribute(this.memberAttributesTypeEClass, 2);
			this.createEAttribute(this.memberAttributesTypeEClass, 3);
			this.membershipAttributeTypeEClass = this.createEClass(25);
			this.createEAttribute(this.membershipAttributeTypeEClass, 0);
			this.createEAttribute(this.membershipAttributeTypeEClass, 1);
			this.modificationSubscriberEClass = this.createEClass(26);
			this.createEAttribute(this.modificationSubscriberEClass, 0);
			this.createEAttribute(this.modificationSubscriberEClass, 1);
			this.modificationSubscriberListEClass = this.createEClass(27);
			this.createEReference(this.modificationSubscriberListEClass, 0);
			this.notificationSubscriberEClass = this.createEClass(28);
			this.createEAttribute(this.notificationSubscriberEClass, 0);
			this.createEAttribute(this.notificationSubscriberEClass, 1);
			this.notificationSubscriberListEClass = this.createEClass(29);
			this.createEReference(this.notificationSubscriberListEClass, 0);
			this.participatingBaseEntriesTypeEClass = this.createEClass(30);
			this.createEAttribute(this.participatingBaseEntriesTypeEClass, 0);
			this.pluginManagerConfigurationTypeEClass = this.createEClass(31);
			this.createEReference(this.pluginManagerConfigurationTypeEClass, 0);
			this.createEReference(this.pluginManagerConfigurationTypeEClass, 1);
			this.postExitEClass = this.createEClass(32);
			this.createEReference(this.postExitEClass, 0);
			this.createEReference(this.postExitEClass, 1);
			this.preExitEClass = this.createEClass(33);
			this.createEReference(this.preExitEClass, 0);
			this.createEReference(this.preExitEClass, 1);
			this.profileRepositoryTypeEClass = this.createEClass(34);
			this.createEReference(this.profileRepositoryTypeEClass, 2);
			this.createEAttribute(this.profileRepositoryTypeEClass, 3);
			this.createEAttribute(this.profileRepositoryTypeEClass, 4);
			this.createEAttribute(this.profileRepositoryTypeEClass, 5);
			this.createEAttribute(this.profileRepositoryTypeEClass, 6);
			this.createEAttribute(this.profileRepositoryTypeEClass, 7);
			this.createEAttribute(this.profileRepositoryTypeEClass, 8);
			this.createEReference(this.profileRepositoryTypeEClass, 9);
			this.createEAttribute(this.profileRepositoryTypeEClass, 10);
			this.createEAttribute(this.profileRepositoryTypeEClass, 11);
			this.createEAttribute(this.profileRepositoryTypeEClass, 12);
			this.createEAttribute(this.profileRepositoryTypeEClass, 13);
			this.createEAttribute(this.profileRepositoryTypeEClass, 14);
			this.createEAttribute(this.profileRepositoryTypeEClass, 15);
			this.createEAttribute(this.profileRepositoryTypeEClass, 16);
			this.createEAttribute(this.profileRepositoryTypeEClass, 17);
			this.propertiesNotSupportedTypeEClass = this.createEClass(35);
			this.createEAttribute(this.propertiesNotSupportedTypeEClass, 0);
			this.createEAttribute(this.propertiesNotSupportedTypeEClass, 1);
			this.propertyExtensionRepositoryTypeEClass = this.createEClass(36);
			this.createEAttribute(this.propertyExtensionRepositoryTypeEClass, 2);
			this.createEAttribute(this.propertyExtensionRepositoryTypeEClass, 3);
			this.createEAttribute(this.propertyExtensionRepositoryTypeEClass, 4);
			this.createEAttribute(this.propertyExtensionRepositoryTypeEClass, 5);
			this.createEAttribute(this.propertyExtensionRepositoryTypeEClass, 6);
			this.createEAttribute(this.propertyExtensionRepositoryTypeEClass, 7);
			this.createEAttribute(this.propertyExtensionRepositoryTypeEClass, 8);
			this.createEAttribute(this.propertyExtensionRepositoryTypeEClass, 9);
			this.rdnAttributesTypeEClass = this.createEClass(37);
			this.createEAttribute(this.rdnAttributesTypeEClass, 0);
			this.createEAttribute(this.rdnAttributesTypeEClass, 1);
			this.realmConfigurationTypeEClass = this.createEClass(38);
			this.createEReference(this.realmConfigurationTypeEClass, 0);
			this.createEAttribute(this.realmConfigurationTypeEClass, 1);
			this.realmDefaultParentTypeEClass = this.createEClass(39);
			this.createEAttribute(this.realmDefaultParentTypeEClass, 0);
			this.createEAttribute(this.realmDefaultParentTypeEClass, 1);
			this.realmTypeEClass = this.createEClass(40);
			this.createEReference(this.realmTypeEClass, 0);
			this.createEReference(this.realmTypeEClass, 1);
			this.createEReference(this.realmTypeEClass, 2);
			this.createEReference(this.realmTypeEClass, 3);
			this.createEReference(this.realmTypeEClass, 4);
			this.createEReference(this.realmTypeEClass, 5);
			this.createEReference(this.realmTypeEClass, 6);
			this.createEReference(this.realmTypeEClass, 7);
			this.createEAttribute(this.realmTypeEClass, 8);
			this.createEAttribute(this.realmTypeEClass, 9);
			this.createEAttribute(this.realmTypeEClass, 10);
			this.createEAttribute(this.realmTypeEClass, 11);
			this.repositoryTypeEClass = this.createEClass(41);
			this.createEAttribute(this.repositoryTypeEClass, 0);
			this.createEAttribute(this.repositoryTypeEClass, 1);
			this.searchResultsCacheTypeEClass = this.createEClass(42);
			this.createEAttribute(this.searchResultsCacheTypeEClass, 0);
			this.createEAttribute(this.searchResultsCacheTypeEClass, 1);
			this.createEAttribute(this.searchResultsCacheTypeEClass, 2);
			this.createEAttribute(this.searchResultsCacheTypeEClass, 3);
			this.createEAttribute(this.searchResultsCacheTypeEClass, 4);
			this.spiBridgeRepositoryTypeEClass = this.createEClass(43);
			this.createEAttribute(this.spiBridgeRepositoryTypeEClass, 18);
			this.staticModelTypeEClass = this.createEClass(44);
			this.createEAttribute(this.staticModelTypeEClass, 0);
			this.createEAttribute(this.staticModelTypeEClass, 1);
			this.supportedEntityTypesTypeEClass = this.createEClass(45);
			this.createEAttribute(this.supportedEntityTypesTypeEClass, 0);
			this.createEAttribute(this.supportedEntityTypesTypeEClass, 1);
			this.createEAttribute(this.supportedEntityTypesTypeEClass, 2);
			this.topicEmitterEClass = this.createEClass(46);
			this.createEReference(this.topicEmitterEClass, 0);
			this.createEReference(this.topicEmitterEClass, 1);
			this.createEReference(this.topicEmitterEClass, 2);
			this.createEAttribute(this.topicEmitterEClass, 3);
			this.topicRegistrationListEClass = this.createEClass(47);
			this.createEReference(this.topicRegistrationListEClass, 0);
			this.topicSubscriberEClass = this.createEClass(48);
			this.createEAttribute(this.topicSubscriberEClass, 0);
			this.createEAttribute(this.topicSubscriberEClass, 1);
			this.createEAttribute(this.topicSubscriberEClass, 2);
			this.topicSubscriberListEClass = this.createEClass(49);
			this.createEReference(this.topicSubscriberListEClass, 0);
			this.userRegistryInfoMappingTypeEClass = this.createEClass(50);
			this.createEAttribute(this.userRegistryInfoMappingTypeEClass, 0);
			this.createEAttribute(this.userRegistryInfoMappingTypeEClass, 1);
			this.subscriberTypeEEnum = this.createEEnum(51);
			this.cacheSizeLimitTypeEDataType = this.createEDataType(52);
			this.cacheSizeLimitTypeObjectEDataType = this.createEDataType(53);
			this.cacheSizeTypeEDataType = this.createEDataType(54);
			this.cacheSizeTypeObjectEDataType = this.createEDataType(55);
			this.cacheTimeOutTypeEDataType = this.createEDataType(56);
			this.cacheTimeOutTypeObjectEDataType = this.createEDataType(57);
			this.dnTypeEDataType = this.createEDataType(58);
			this.initPoolSizeTypeEDataType = this.createEDataType(59);
			this.initPoolSizeTypeObjectEDataType = this.createEDataType(60);
			this.maxPoolSizeTypeEDataType = this.createEDataType(61);
			this.maxPoolSizeTypeObjectEDataType = this.createEDataType(62);
			this.poolTimeOutTypeEDataType = this.createEDataType(63);
			this.poolTimeOutTypeObjectEDataType = this.createEDataType(64);
			this.poolWaitTimeTypeEDataType = this.createEDataType(65);
			this.poolWaitTimeTypeObjectEDataType = this.createEDataType(66);
			this.prefPoolSizeTypeEDataType = this.createEDataType(67);
			this.prefPoolSizeTypeObjectEDataType = this.createEDataType(68);
			this.realmListTypeEDataType = this.createEDataType(69);
			this.realmListType1EDataType = this.createEDataType(70);
			this.subscriberTypeObjectEDataType = this.createEDataType(71);
		}
	}

	public void initializePackageContents() {
		if (!this.isInitialized) {
			this.isInitialized = true;
			this.setName("com.ibm.ws.wim.configmodel");
			this.setNsPrefix("config");
			this.setNsURI("http://www.ibm.com/websphere/wim/config");
			XMLTypePackageImpl var1 = (XMLTypePackageImpl) Registry.INSTANCE
					.getEPackage("http://www.eclipse.org/emf/2003/XMLType");
			this.databaseRepositoryTypeEClass.getESuperTypes().add(this.getProfileRepositoryType());
			this.entryMappingRepositoryTypeEClass.getESuperTypes().add(this.getRepositoryType());
			this.fileRepositoryTypeEClass.getESuperTypes().add(this.getProfileRepositoryType());
			this.ldapRepositoryTypeEClass.getESuperTypes().add(this.getProfileRepositoryType());
			this.profileRepositoryTypeEClass.getESuperTypes().add(this.getRepositoryType());
			this.propertyExtensionRepositoryTypeEClass.getESuperTypes().add(this.getRepositoryType());
			this.spiBridgeRepositoryTypeEClass.getESuperTypes().add(this.getProfileRepositoryType());
			this.initEClass(this.attributeConfigurationTypeEClass, AttributeConfigurationType.class,
					"AttributeConfigurationType", false, false, true);
			this.initEReference(this.getAttributeConfigurationType_ExternalIdAttributes(), this.getAttributeType(),
					(EReference) null, "externalIdAttributes", (String) null, 0, -1, AttributeConfigurationType.class,
					false, false, true, true, false, false, true, false, true);
			this.initEReference(this.getAttributeConfigurationType_Attributes(), this.getAttributeType(),
					(EReference) null, "attributes", (String) null, 0, -1, AttributeConfigurationType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEReference(this.getAttributeConfigurationType_PropertiesNotSupported(),
					this.getPropertiesNotSupportedType(), (EReference) null, "propertiesNotSupported", (String) null, 0,
					-1, AttributeConfigurationType.class, false, false, true, true, false, false, true, false, true);
			this.initEClass(this.attributeGroupTypeEClass, AttributeGroupType.class, "AttributeGroupType", false, false,
					true);
			this.initEAttribute(this.getAttributeGroupType_GroupName(), var1.getString(), "groupName", (String) null, 1,
					1, AttributeGroupType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getAttributeGroupType_AttributeNames(), var1.getString(), "attributeNames",
					(String) null, 1, -1, AttributeGroupType.class, false, false, true, false, false, false, false,
					true);
			this.initEClass(this.attributesCacheTypeEClass, AttributesCacheType.class, "AttributesCacheType", false,
					false, true);
			this.initEAttribute(this.getAttributesCacheType_AttributeSizeLimit(), this.getCacheSizeLimitType(),
					"attributeSizeLimit", "2000", 0, 1, AttributesCacheType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getAttributesCacheType_CacheSize(), this.getCacheSizeType(), "cacheSize", "4000",
					0, 1, AttributesCacheType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getAttributesCacheType_CacheTimeOut(), this.getCacheTimeOutType(), "cacheTimeOut",
					"1200", 0, 1, AttributesCacheType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getAttributesCacheType_Enabled(), var1.getBoolean(), "enabled", "true", 0, 1,
					AttributesCacheType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getAttributesCacheType_ServerTTLAttribute(), var1.getString(),
					"serverTTLAttribute", (String) null, 0, 1, AttributesCacheType.class, false, false, true, false,
					false, false, false, true);
			this.initEAttribute(this.getAttributesCacheType_CacheDistPolicy(), var1.getToken(), "cacheDistPolicy",
					"push", 0, 1, AttributesCacheType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.attributeTypeEClass, AttributeType.class, "AttributeType", false, false, true);
			this.initEAttribute(this.getAttributeType_EntityTypes(), var1.getString(), "entityTypes", (String) null, 0,
					-1, AttributeType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getAttributeType_DefaultAttribute(), var1.getString(), "defaultAttribute",
					(String) null, 0, 1, AttributeType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getAttributeType_DefaultValue(), var1.getString(), "defaultValue", (String) null,
					0, 1, AttributeType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getAttributeType_Name(), var1.getString(), "name", (String) null, 1, 1,
					AttributeType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getAttributeType_PropertyName(), var1.getString(), "propertyName", (String) null,
					0, 1, AttributeType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getAttributeType_Syntax(), var1.getString(), "syntax", (String) null, 0, 1,
					AttributeType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getAttributeType_WimGenerate(), var1.getBoolean(), "wimGenerate", "false", 0, 1,
					AttributeType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.authorizationTypeEClass, AuthorizationType.class, "AuthorizationType", false, false,
					true);
			this.initEReference(this.getAuthorizationType_AttributeGroups(), this.getAttributeGroupType(),
					(EReference) null, "attributeGroups", (String) null, 0, -1, AuthorizationType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEAttribute(this.getAuthorizationType_DefaultAttributeGroup(), var1.getString(),
					"defaultAttributeGroup", (String) null, 1, 1, AuthorizationType.class, false, false, true, false,
					false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_ImportPolicyFromFile(), var1.getBoolean(),
					"importPolicyFromFile", (String) null, 1, 1, AuthorizationType.class, false, false, true, true,
					false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_IsAttributeGroupingEnabled(), var1.getBoolean(),
					"isAttributeGroupingEnabled", (String) null, 1, 1, AuthorizationType.class, false, false, true,
					true, false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_IsSecurityEnabled(), var1.getBoolean(), "isSecurityEnabled",
					(String) null, 1, 1, AuthorizationType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_JaccPolicyClass(), var1.getString(), "jaccPolicyClass",
					(String) null, 0, 1, AuthorizationType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_JaccPolicyConfigFactoryClass(), var1.getString(),
					"jaccPolicyConfigFactoryClass", (String) null, 0, 1, AuthorizationType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_JaccPrincipalToRolePolicyFileName(), var1.getString(),
					"jaccPrincipalToRolePolicyFileName", (String) null, 0, 1, AuthorizationType.class, false, false,
					true, false, false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_JaccPrincipalToRolePolicyId(), var1.getString(),
					"jaccPrincipalToRolePolicyId", (String) null, 0, 1, AuthorizationType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_JaccRoleMappingClass(), var1.getString(),
					"jaccRoleMappingClass", (String) null, 0, 1, AuthorizationType.class, false, false, true, false,
					false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_JaccRoleMappingConfigFactoryClass(), var1.getString(),
					"jaccRoleMappingConfigFactoryClass", (String) null, 0, 1, AuthorizationType.class, false, false,
					true, false, false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_JaccRoleToPermissionPolicyFileName(), var1.getString(),
					"jaccRoleToPermissionPolicyFileName", (String) null, 0, 1, AuthorizationType.class, false, false,
					true, false, false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_JaccRoleToPermissionPolicyId(), var1.getString(),
					"jaccRoleToPermissionPolicyId", (String) null, 0, 1, AuthorizationType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getAuthorizationType_UseSystemJACCProvider(), var1.getBoolean(),
					"useSystemJACCProvider", (String) null, 1, 1, AuthorizationType.class, false, false, true, true,
					false, false, false, true);
			this.initEClass(this.baseEntriesTypeEClass, BaseEntriesType.class, "BaseEntriesType", false, false, true);
			this.initEAttribute(this.getBaseEntriesType_Name(), var1.getToken(), "name", (String) null, 1, 1,
					BaseEntriesType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getBaseEntriesType_NameInRepository(), var1.getToken(), "nameInRepository",
					(String) null, 0, 1, BaseEntriesType.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.cacheConfigurationTypeEClass, CacheConfigurationType.class, "CacheConfigurationType",
					false, false, true);
			this.initEReference(this.getCacheConfigurationType_AttributesCache(), this.getAttributesCacheType(),
					(EReference) null, "attributesCache", (String) null, 0, 1, CacheConfigurationType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEReference(this.getCacheConfigurationType_SearchResultsCache(), this.getSearchResultsCacheType(),
					(EReference) null, "searchResultsCache", (String) null, 0, 1, CacheConfigurationType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEAttribute(this.getCacheConfigurationType_CachesDiskOffLoad(), var1.getBoolean(),
					"cachesDiskOffLoad", "false", 0, 1, CacheConfigurationType.class, false, false, true, true, false,
					false, false, true);
			this.initEClass(this.configurationProviderTypeEClass, ConfigurationProviderType.class,
					"ConfigurationProviderType", false, false, true);
			this.initEReference(this.getConfigurationProviderType_DynamicModel(), this.getDynamicModelType(),
					(EReference) null, "dynamicModel", (String) null, 0, 1, ConfigurationProviderType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEReference(this.getConfigurationProviderType_StaticModel(), this.getStaticModelType(),
					(EReference) null, "staticModel", (String) null, 0, 1, ConfigurationProviderType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEReference(this.getConfigurationProviderType_SupportedEntityTypes(),
					this.getSupportedEntityTypesType(), (EReference) null, "supportedEntityTypes", (String) null, 0, -1,
					ConfigurationProviderType.class, false, false, true, true, false, false, true, false, true);
			this.initEReference(this.getConfigurationProviderType_EntryMappingRepository(),
					this.getEntryMappingRepositoryType(), (EReference) null, "entryMappingRepository", (String) null, 0,
					1, ConfigurationProviderType.class, false, false, true, true, false, false, true, false, true);
			this.initEReference(this.getConfigurationProviderType_PropertyExtensionRepository(),
					this.getPropertyExtensionRepositoryType(), (EReference) null, "propertyExtensionRepository",
					(String) null, 0, 1, ConfigurationProviderType.class, false, false, true, true, false, false, true,
					false, true);
			this.initEReference(this.getConfigurationProviderType_Repositories(), this.getProfileRepositoryType(),
					(EReference) null, "repositories", (String) null, 1, -1, ConfigurationProviderType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEReference(this.getConfigurationProviderType_RealmConfiguration(),
					this.getRealmConfigurationType(), (EReference) null, "realmConfiguration", (String) null, 0, 1,
					ConfigurationProviderType.class, false, false, true, true, false, false, true, false, true);
			this.initEReference(this.getConfigurationProviderType_PluginManagerConfiguration(),
					this.getPluginManagerConfigurationType(), (EReference) null, "pluginManagerConfiguration",
					(String) null, 0, 1, ConfigurationProviderType.class, false, false, true, true, false, false, true,
					false, true);
			this.initEReference(this.getConfigurationProviderType_Authorization(), this.getAuthorizationType(),
					(EReference) null, "authorization", (String) null, 1, 1, ConfigurationProviderType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEAttribute(this.getConfigurationProviderType_MaxPagingResults(), var1.getInt(), "maxPagingResults",
					"500", 0, 1, ConfigurationProviderType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getConfigurationProviderType_MaxSearchResults(), var1.getInt(), "maxSearchResults",
					"2000", 0, 1, ConfigurationProviderType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getConfigurationProviderType_MaxTotalPagingResults(), var1.getInt(),
					"maxTotalPagingResults", "1000", 0, 1, ConfigurationProviderType.class, false, false, true, true,
					false, false, false, true);
			this.initEAttribute(this.getConfigurationProviderType_PagedCacheTimeOut(), var1.getInt(),
					"pagedCacheTimeOut", "900", 0, 1, ConfigurationProviderType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getConfigurationProviderType_PagingCachesDiskOffLoad(), var1.getBoolean(),
					"pagingCachesDiskOffLoad", "false", 0, 1, ConfigurationProviderType.class, false, false, true, true,
					false, false, false, true);
			this.initEAttribute(this.getConfigurationProviderType_PagingEntityObject(), var1.getBoolean(),
					"pagingEntityObject", "true", 0, 1, ConfigurationProviderType.class, false, false, true, true,
					false, false, false, true);
			this.initEAttribute(this.getConfigurationProviderType_SearchTimeOut(), var1.getString(), "searchTimeOut",
					"600000", 0, 1, ConfigurationProviderType.class, false, false, true, true, false, false, false,
					true);
			this.initEClass(this.connectionsTypeEClass, ConnectionsType.class, "ConnectionsType", false, false, true);
			this.initEAttribute(this.getConnectionsType_Host(), var1.getString(), "host", (String) null, 1, 1,
					ConnectionsType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getConnectionsType_Port(), var1.getInt(), "port", "389", 0, 1,
					ConnectionsType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.contextPoolTypeEClass, ContextPoolType.class, "ContextPoolType", false, false, true);
			this.initEAttribute(this.getContextPoolType_Enabled(), var1.getBoolean(), "enabled", "true", 0, 1,
					ContextPoolType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getContextPoolType_InitPoolSize(), this.getInitPoolSizeType(), "initPoolSize", "1",
					0, 1, ContextPoolType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getContextPoolType_MaxPoolSize(), this.getMaxPoolSizeType(), "maxPoolSize", "0", 0,
					1, ContextPoolType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getContextPoolType_PoolTimeOut(), this.getPoolTimeOutType(), "poolTimeOut", "0", 0,
					1, ContextPoolType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getContextPoolType_PoolWaitTime(), this.getPoolWaitTimeType(), "poolWaitTime",
					"3000", 0, 1, ContextPoolType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getContextPoolType_PrefPoolSize(), this.getPrefPoolSizeType(), "prefPoolSize", "3",
					0, 1, ContextPoolType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.customPropertiesTypeEClass, CustomPropertiesType.class, "CustomPropertiesType", false,
					false, true);
			this.initEAttribute(this.getCustomPropertiesType_Name(), var1.getString(), "name", (String) null, 1, 1,
					CustomPropertiesType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getCustomPropertiesType_Value(), var1.getString(), "value", (String) null, 1, 1,
					CustomPropertiesType.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.databaseRepositoryTypeEClass, DatabaseRepositoryType.class, "DatabaseRepositoryType",
					false, false, true);
			this.initEAttribute(this.getDatabaseRepositoryType_DatabaseType(), var1.getString(), "databaseType",
					(String) null, 1, 1, DatabaseRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getDatabaseRepositoryType_DataSourceName(), var1.getString(), "dataSourceName",
					(String) null, 1, 1, DatabaseRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getDatabaseRepositoryType_DbAdminId(), var1.getString(), "dbAdminId",
					(String) null, 0, 1, DatabaseRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getDatabaseRepositoryType_DbAdminPassword(), var1.getString(), "dbAdminPassword",
					(String) null, 0, 1, DatabaseRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getDatabaseRepositoryType_DbURL(), var1.getString(), "dbURL", (String) null, 1, 1,
					DatabaseRepositoryType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getDatabaseRepositoryType_DbSchema(), var1.getString(), "dbSchema", (String) null,
					0, 1, DatabaseRepositoryType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getDatabaseRepositoryType_EncryptionKey(), var1.getString(), "encryptionKey",
					(String) null, 0, 1, DatabaseRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getDatabaseRepositoryType_EntityRetrievalLimit(), var1.getInt(),
					"entityRetrievalLimit", "50", 0, 1, DatabaseRepositoryType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getDatabaseRepositoryType_JDBCDriverClass(), var1.getString(), "jDBCDriverClass",
					(String) null, 0, 1, DatabaseRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getDatabaseRepositoryType_SaltLength(), var1.getInt(), "saltLength", "12", 0, 1,
					DatabaseRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getDatabaseRepositoryType_HashAlgorithm(), var1.getString(), "hashAlgorithm",
					(String) null, 0, 1, DatabaseRepositoryType.class, false, false, true, true, false, false, false,
					true);
			this.initEAttribute(this.getDatabaseRepositoryType_HashIterations(), var1.getInt(), "hashIterations",
					"100000", 0, 1, DatabaseRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getDatabaseRepositoryType_HashKeyLength(), var1.getInt(), "hashKeyLength", "32", 0,
					1, DatabaseRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getDatabaseRepositoryType_HashSaltLength(), var1.getInt(), "hashSaltLength", "32",
					0, 1, DatabaseRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.documentRootEClass, DocumentRoot.class, "DocumentRoot", false, false, true);
			this.initEAttribute(this.getDocumentRoot_Mixed(), this.ecorePackage.getEFeatureMapEntry(), "mixed",
					(String) null, 0, -1, (Class) null, false, false, true, false, false, false, false, true);
			this.initEReference(this.getDocumentRoot_XMLNSPrefixMap(), this.ecorePackage.getEStringToStringMapEntry(),
					(EReference) null, "xMLNSPrefixMap", (String) null, 0, -1, (Class) null, true, false, true, true,
					false, false, false, false, true);
			this.initEReference(this.getDocumentRoot_XSISchemaLocation(),
					this.ecorePackage.getEStringToStringMapEntry(), (EReference) null, "xSISchemaLocation",
					(String) null, 0, -1, (Class) null, true, false, true, true, false, false, false, false, true);
			this.initEReference(this.getDocumentRoot_ConfigurationProvider(), this.getConfigurationProviderType(),
					(EReference) null, "configurationProvider", (String) null, 0, -2, (Class) null, true, true, true,
					true, false, false, true, true, true);
			this.initEClass(this.dynamicMemberAttributesTypeEClass, DynamicMemberAttributesType.class,
					"DynamicMemberAttributesType", false, false, true);
			this.initEAttribute(this.getDynamicMemberAttributesType_Name(), var1.getString(), "name", (String) null, 1,
					1, DynamicMemberAttributesType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getDynamicMemberAttributesType_ObjectClass(), var1.getString(), "objectClass",
					(String) null, 1, 1, DynamicMemberAttributesType.class, false, false, true, false, false, false,
					false, true);
			this.initEClass(this.dynamicModelTypeEClass, DynamicModelType.class, "DynamicModelType", false, false,
					true);
			this.initEAttribute(this.getDynamicModelType_XsdFileName(), var1.getString(), "xsdFileName",
					"wimextension.xsd", 0, 1, DynamicModelType.class, false, false, true, true, false, false, false,
					true);
			this.initEAttribute(this.getDynamicModelType_UseGlobalSchema(), var1.getBoolean(), "useGlobalSchema",
					"false", 0, 1, DynamicModelType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.entryMappingRepositoryTypeEClass, EntryMappingRepositoryType.class,
					"EntryMappingRepositoryType", false, false, true);
			this.initEAttribute(this.getEntryMappingRepositoryType_DatabaseType(), var1.getString(), "databaseType",
					(String) null, 1, 1, EntryMappingRepositoryType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getEntryMappingRepositoryType_DataSourceName(), var1.getString(), "dataSourceName",
					(String) null, 1, 1, EntryMappingRepositoryType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getEntryMappingRepositoryType_DbAdminId(), var1.getString(), "dbAdminId",
					(String) null, 0, 1, EntryMappingRepositoryType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getEntryMappingRepositoryType_DbAdminPassword(), var1.getString(),
					"dbAdminPassword", (String) null, 0, 1, EntryMappingRepositoryType.class, false, false, true, false,
					false, false, false, true);
			this.initEAttribute(this.getEntryMappingRepositoryType_DbURL(), var1.getString(), "dbURL", (String) null, 1,
					1, EntryMappingRepositoryType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getEntryMappingRepositoryType_DbSchema(), var1.getString(), "dbSchema",
					(String) null, 0, 1, EntryMappingRepositoryType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getEntryMappingRepositoryType_JDBCDriverClass(), var1.getString(),
					"jDBCDriverClass", (String) null, 0, 1, EntryMappingRepositoryType.class, false, false, true, false,
					false, false, false, true);
			this.initEClass(this.environmentPropertiesTypeEClass, EnvironmentPropertiesType.class,
					"EnvironmentPropertiesType", false, false, true);
			this.initEAttribute(this.getEnvironmentPropertiesType_Name(), var1.getString(), "name", (String) null, 1, 1,
					EnvironmentPropertiesType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getEnvironmentPropertiesType_Value(), var1.getString(), "value", (String) null, 1,
					1, EnvironmentPropertiesType.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.krb5AuthenticationTypeEClass, Krb5AuthenticationType.class, "Krb5AuthenticationType",
					false, false, true);
			this.initEAttribute(this.getKrb5AuthenticationType_Krb5Principal(), var1.getString(), "krb5Principal",
					(String) null, 1, 1, Krb5AuthenticationType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getKrb5AuthenticationType_Krb5TicketCache(), var1.getString(), "krb5TicketCache",
					(String) null, 0, 1, Krb5AuthenticationType.class, false, false, true, false, false, false, false,
					true);
			this.initEClass(this.fileRepositoryTypeEClass, FileRepositoryType.class, "FileRepositoryType", false, false,
					true);
			this.initEAttribute(this.getFileRepositoryType_BaseDirectory(), var1.getString(), "baseDirectory",
					(String) null, 0, 1, FileRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getFileRepositoryType_CaseSensitive(), var1.getBoolean(), "caseSensitive", "false",
					0, 1, FileRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getFileRepositoryType_FileName(), var1.getString(), "fileName", (String) null, 0,
					1, FileRepositoryType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getFileRepositoryType_MessageDigestAlgorithm(), var1.getString(),
					"messageDigestAlgorithm", "SHA-1", 0, 1, FileRepositoryType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getFileRepositoryType_SaltLength(), var1.getInt(), "saltLength", "32", 0, 1,
					FileRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getFileRepositoryType_KeyLength(), var1.getInt(), "keyLength", "32", 0, 1,
					FileRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getFileRepositoryType_HashIterations(), var1.getInt(), "hashIterations", "100000",
					0, 1, FileRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getFileRepositoryType_AccountLockoutThreshold(), var1.getInt(),
					"accountLockoutThreshold", "5", 0, 1, FileRepositoryType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getFileRepositoryType_AccountLockoutDuration(), var1.getInt(),
					"accountLockoutDuration", "15", 0, 1, FileRepositoryType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getFileRepositoryType_IgnoreFailedLoginAfter(), var1.getInt(),
					"ignoreFailedLoginAfter", "15", 0, 1, FileRepositoryType.class, false, false, true, true, false,
					false, false, true);
			this.initEClass(this.groupConfigurationTypeEClass, GroupConfigurationType.class, "GroupConfigurationType",
					false, false, true);
			this.initEReference(this.getGroupConfigurationType_MemberAttributes(), this.getMemberAttributesType(),
					(EReference) null, "memberAttributes", (String) null, 0, -1, GroupConfigurationType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEReference(this.getGroupConfigurationType_DynamicMemberAttributes(),
					this.getDynamicMemberAttributesType(), (EReference) null, "dynamicMemberAttributes", (String) null,
					0, -1, GroupConfigurationType.class, false, false, true, true, false, false, true, false, true);
			this.initEReference(this.getGroupConfigurationType_MembershipAttribute(), this.getMembershipAttributeType(),
					(EReference) null, "membershipAttribute", (String) null, 0, 1, GroupConfigurationType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEAttribute(this.getGroupConfigurationType_UpdateGroupMembership(), var1.getBoolean(),
					"updateGroupMembership", "false", 0, 1, GroupConfigurationType.class, false, false, true, true,
					false, false, false, true);
			this.initEClass(this.inlineExitEClass, InlineExit.class, "InlineExit", false, false, true);
			this.initEReference(this.getInlineExit_ModificationSubscriberList(), this.getModificationSubscriberList(),
					(EReference) null, "modificationSubscriberList", (String) null, 1, 1, InlineExit.class, false,
					false, true, true, false, false, true, false, true);
			this.initEAttribute(this.getInlineExit_InlineExitName(), var1.getString(), "inlineExitName", (String) null,
					1, 1, InlineExit.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.ldapEntityTypesTypeEClass, LdapEntityTypesType.class, "LdapEntityTypesType", false,
					false, true);
			this.initEReference(this.getLdapEntityTypesType_RdnAttributes(), this.getRdnAttributesType(),
					(EReference) null, "rdnAttributes", (String) null, 0, -1, LdapEntityTypesType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEAttribute(this.getLdapEntityTypesType_ObjectClasses(), var1.getString(), "objectClasses",
					(String) null, 1, -1, LdapEntityTypesType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getLdapEntityTypesType_ObjectClassesForCreate(), var1.getString(),
					"objectClassesForCreate", (String) null, 0, -1, LdapEntityTypesType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getLdapEntityTypesType_SearchBases(), var1.getToken(), "searchBases",
					(String) null, 0, -1, LdapEntityTypesType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getLdapEntityTypesType_Name(), var1.getString(), "name", (String) null, 1, 1,
					LdapEntityTypesType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getLdapEntityTypesType_SearchFilter(), var1.getString(), "searchFilter",
					(String) null, 0, 1, LdapEntityTypesType.class, false, false, true, false, false, false, false,
					true);
			this.initEClass(this.ldapRepositoryTypeEClass, LdapRepositoryType.class, "LdapRepositoryType", false, false,
					true);
			this.initEReference(this.getLdapRepositoryType_LdapServerConfiguration(),
					this.getLdapServerConfigurationType(), (EReference) null, "ldapServerConfiguration", (String) null,
					1, 1, LdapRepositoryType.class, false, false, true, true, false, false, true, false, true);
			this.initEReference(this.getLdapRepositoryType_LdapEntityTypes(), this.getLdapEntityTypesType(),
					(EReference) null, "ldapEntityTypes", (String) null, 0, -1, LdapRepositoryType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEReference(this.getLdapRepositoryType_GroupConfiguration(), this.getGroupConfigurationType(),
					(EReference) null, "groupConfiguration", (String) null, 0, 1, LdapRepositoryType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEReference(this.getLdapRepositoryType_AttributeConfiguration(),
					this.getAttributeConfigurationType(), (EReference) null, "attributeConfiguration", (String) null, 0,
					1, LdapRepositoryType.class, false, false, true, true, false, false, true, false, true);
			this.initEReference(this.getLdapRepositoryType_ContextPool(), this.getContextPoolType(), (EReference) null,
					"contextPool", (String) null, 0, 1, LdapRepositoryType.class, false, false, true, true, false,
					false, true, false, true);
			this.initEReference(this.getLdapRepositoryType_CacheConfiguration(), this.getCacheConfigurationType(),
					(EReference) null, "cacheConfiguration", (String) null, 0, 1, LdapRepositoryType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEAttribute(this.getLdapRepositoryType_CertificateFilter(), var1.getString(), "certificateFilter",
					(String) null, 0, 1, LdapRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getLdapRepositoryType_CertificateMapMode(), var1.getToken(), "certificateMapMode",
					"exactdn", 0, 1, LdapRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getLdapRepositoryType_LdapServerType(), var1.getToken(), "ldapServerType",
					(String) null, 1, 1, LdapRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getLdapRepositoryType_TranslateRDN(), var1.getBoolean(), "translateRDN", "false",
					0, 1, LdapRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.ldapServerConfigurationTypeEClass, LdapServerConfigurationType.class,
					"LdapServerConfigurationType", false, false, true);
			this.initEReference(this.getLdapServerConfigurationType_LdapServers(), this.getLdapServersType(),
					(EReference) null, "ldapServers", (String) null, 1, -1, LdapServerConfigurationType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_AllowWriteToSecondaryServers(), var1.getBoolean(),
					"allowWriteToSecondaryServers", "false", 0, 1, LdapServerConfigurationType.class, false, false,
					true, true, false, false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_AttributeRangeStep(), var1.getInt(),
					"attributeRangeStep", "0", 0, 1, LdapServerConfigurationType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_PrimaryServerQueryTimeInterval(), var1.getInt(),
					"primaryServerQueryTimeInterval", "15", 0, 1, LdapServerConfigurationType.class, false, false, true,
					true, false, false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_ReturnToPrimaryServer(), var1.getBoolean(),
					"returnToPrimaryServer", "true", 0, 1, LdapServerConfigurationType.class, false, false, true, true,
					false, false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SearchCountLimit(), var1.getInt(),
					"searchCountLimit", "0", 0, 1, LdapServerConfigurationType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SearchPageSize(), var1.getInt(), "searchPageSize",
					"0", 0, 1, LdapServerConfigurationType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SearchTimeLimit(), var1.getInt(), "searchTimeLimit",
					"0", 0, 1, LdapServerConfigurationType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SslConfiguration(), var1.getString(),
					"sslConfiguration", (String) null, 0, 1, LdapServerConfigurationType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SslKeyStore(), var1.getString(), "sslKeyStore",
					(String) null, 0, 1, LdapServerConfigurationType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SslKeyStorePassword(), var1.getString(),
					"sslKeyStorePassword", (String) null, 0, 1, LdapServerConfigurationType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SslKeyStoreType(), var1.getString(),
					"sslKeyStoreType", (String) null, 0, 1, LdapServerConfigurationType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SslTrustStore(), var1.getString(), "sslTrustStore",
					(String) null, 0, 1, LdapServerConfigurationType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SslTrustStorePassword(), var1.getString(),
					"sslTrustStorePassword", (String) null, 0, 1, LdapServerConfigurationType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getLdapServerConfigurationType_SslTrustStoreType(), var1.getString(),
					"sslTrustStoreType", (String) null, 0, 1, LdapServerConfigurationType.class, false, false, true,
					false, false, false, false, true);
			this.initEClass(this.ldapServersTypeEClass, LdapServersType.class, "LdapServersType", false, false, true);
			this.initEReference(this.getLdapServersType_Connections(), this.getConnectionsType(), (EReference) null,
					"connections", (String) null, 1, -1, LdapServersType.class, false, false, true, true, false, false,
					true, false, true);
			this.initEReference(this.getLdapServersType_EnvironmentProperties(), this.getEnvironmentPropertiesType(),
					(EReference) null, "environmentProperties", (String) null, 0, -1, LdapServersType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEReference(this.getLdapServersType_Krb5Authentication(), this.getKrb5AuthenticationType(),
					(EReference) null, "krb5Authentication", (String) null, 0, 1, LdapServersType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEAttribute(this.getLdapServersType_Authentication(), var1.getString(), "authentication", "simple",
					0, 1, LdapServersType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getLdapServersType_BindDN(), this.getDNType(), "bindDN", (String) null, 0, 1,
					LdapServersType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getLdapServersType_BindPassword(), var1.getString(), "bindPassword", (String) null,
					0, 1, LdapServersType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getLdapServersType_ConnectionPool(), var1.getBoolean(), "connectionPool", "false",
					0, 1, LdapServersType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getLdapServersType_ConnectTimeout(), var1.getInt(), "connectTimeout", "0", 0, 1,
					LdapServersType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getLdapServersType_DerefAliases(), var1.getToken(), "derefAliases", "always", 0, 1,
					LdapServersType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getLdapServersType_Referal(), var1.getToken(), "referal", "ignore", 0, 1,
					LdapServersType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getLdapServersType_SslEnabled(), var1.getBoolean(), "sslEnabled", "false", 0, 1,
					LdapServersType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getLdapServersType_BindAuthMechanism(), var1.getString(), "bindAuthMechanism",
					(String) null, 0, 1, LdapServersType.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.memberAttributesTypeEClass, MemberAttributesType.class, "MemberAttributesType", false,
					false, true);
			this.initEAttribute(this.getMemberAttributesType_DummyMember(), var1.getString(), "dummyMember",
					(String) null, 0, 1, MemberAttributesType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getMemberAttributesType_Name(), var1.getString(), "name", (String) null, 1, 1,
					MemberAttributesType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getMemberAttributesType_ObjectClass(), var1.getString(), "objectClass",
					(String) null, 0, 1, MemberAttributesType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getMemberAttributesType_Scope(), var1.getToken(), "scope", "direct", 0, 1,
					MemberAttributesType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.membershipAttributeTypeEClass, MembershipAttributeType.class,
					"MembershipAttributeType", false, false, true);
			this.initEAttribute(this.getMembershipAttributeType_Name(), var1.getString(), "name", (String) null, 1, 1,
					MembershipAttributeType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getMembershipAttributeType_Scope(), var1.getToken(), "scope", "direct", 0, 1,
					MembershipAttributeType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.modificationSubscriberEClass, ModificationSubscriber.class, "ModificationSubscriber",
					false, false, true);
			this.initEAttribute(this.getModificationSubscriber_ModificationSubscriberReference(), var1.getString(),
					"modificationSubscriberReference", (String) null, 1, 1, ModificationSubscriber.class, false, false,
					true, false, false, false, false, true);
			this.initEAttribute(this.getModificationSubscriber_RealmList(), this.getRealmListType(), "realmList", "All",
					1, 1, ModificationSubscriber.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.modificationSubscriberListEClass, ModificationSubscriberList.class,
					"ModificationSubscriberList", false, false, true);
			this.initEReference(this.getModificationSubscriberList_ModificationSubscriber(),
					this.getModificationSubscriber(), (EReference) null, "modificationSubscriber", (String) null, 0, -1,
					ModificationSubscriberList.class, false, false, true, true, false, false, true, false, true);
			this.initEClass(this.notificationSubscriberEClass, NotificationSubscriber.class, "NotificationSubscriber",
					false, false, true);
			this.initEAttribute(this.getNotificationSubscriber_NotificationSubscriberReference(), var1.getString(),
					"notificationSubscriberReference", (String) null, 1, 1, NotificationSubscriber.class, false, false,
					true, false, false, false, false, true);
			this.initEAttribute(this.getNotificationSubscriber_RealmList(), this.getRealmListType1(), "realmList",
					"All", 1, 1, NotificationSubscriber.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.notificationSubscriberListEClass, NotificationSubscriberList.class,
					"NotificationSubscriberList", false, false, true);
			this.initEReference(this.getNotificationSubscriberList_NotificationSubscriber(),
					this.getNotificationSubscriber(), (EReference) null, "notificationSubscriber", (String) null, 0, -1,
					NotificationSubscriberList.class, false, false, true, true, false, false, true, false, true);
			this.initEClass(this.participatingBaseEntriesTypeEClass, ParticipatingBaseEntriesType.class,
					"ParticipatingBaseEntriesType", false, false, true);
			this.initEAttribute(this.getParticipatingBaseEntriesType_Name(), var1.getToken(), "name", (String) null, 1,
					1, ParticipatingBaseEntriesType.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.pluginManagerConfigurationTypeEClass, PluginManagerConfigurationType.class,
					"PluginManagerConfigurationType", false, false, true);
			this.initEReference(this.getPluginManagerConfigurationType_TopicSubscriberList(),
					this.getTopicSubscriberList(), (EReference) null, "topicSubscriberList", (String) null, 1, 1,
					PluginManagerConfigurationType.class, false, false, true, true, false, false, true, false, true);
			this.initEReference(this.getPluginManagerConfigurationType_TopicRegistrationList(),
					this.getTopicRegistrationList(), (EReference) null, "topicRegistrationList", (String) null, 1, 1,
					PluginManagerConfigurationType.class, false, false, true, true, false, false, true, false, true);
			this.initEClass(this.postExitEClass, PostExit.class, "PostExit", false, false, true);
			this.initEReference(this.getPostExit_ModificationSubscriberList(), this.getModificationSubscriberList(),
					(EReference) null, "modificationSubscriberList", (String) null, 1, 1, PostExit.class, false, false,
					true, true, false, false, true, false, true);
			this.initEReference(this.getPostExit_NotificationSubscriberList(), this.getNotificationSubscriberList(),
					(EReference) null, "notificationSubscriberList", (String) null, 1, 1, PostExit.class, false, false,
					true, true, false, false, true, false, true);
			this.initEClass(this.preExitEClass, PreExit.class, "PreExit", false, false, true);
			this.initEReference(this.getPreExit_NotificationSubscriberList(), this.getNotificationSubscriberList(),
					(EReference) null, "notificationSubscriberList", (String) null, 1, 1, PreExit.class, false, false,
					true, true, false, false, true, false, true);
			this.initEReference(this.getPreExit_ModificationSubscriberList(), this.getModificationSubscriberList(),
					(EReference) null, "modificationSubscriberList", (String) null, 1, 1, PreExit.class, false, false,
					true, true, false, false, true, false, true);
			this.initEClass(this.profileRepositoryTypeEClass, ProfileRepositoryType.class, "ProfileRepositoryType",
					false, false, true);
			this.initEReference(this.getProfileRepositoryType_BaseEntries(), this.getBaseEntriesType(),
					(EReference) null, "baseEntries", (String) null, 1, -1, ProfileRepositoryType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEAttribute(this.getProfileRepositoryType_EntityTypesNotAllowCreate(), var1.getString(),
					"entityTypesNotAllowCreate", (String) null, 0, -1, ProfileRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_EntityTypesNotAllowUpdate(), var1.getString(),
					"entityTypesNotAllowUpdate", (String) null, 0, -1, ProfileRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_EntityTypesNotAllowRead(), var1.getString(),
					"entityTypesNotAllowRead", (String) null, 0, -1, ProfileRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_EntityTypesNotAllowDelete(), var1.getString(),
					"entityTypesNotAllowDelete", (String) null, 0, -1, ProfileRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_RepositoriesForGroups(), var1.getString(),
					"repositoriesForGroups", (String) null, 0, -1, ProfileRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_LoginProperties(), var1.getString(), "loginProperties",
					(String) null, 0, -1, ProfileRepositoryType.class, false, false, true, false, false, false, false,
					true);
			this.initEReference(this.getProfileRepositoryType_CustomProperties(), this.getCustomPropertiesType(),
					(EReference) null, "customProperties", (String) null, 0, -1, ProfileRepositoryType.class, false,
					false, true, true, false, false, true, false, true);
			this.initEAttribute(this.getProfileRepositoryType_IsExtIdUnique(), var1.getBoolean(), "isExtIdUnique",
					"true", 0, 1, ProfileRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_ReadOnly(), var1.getBoolean(), "readOnly", "false", 0, 1,
					ProfileRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_SupportAsyncMode(), var1.getBoolean(), "supportAsyncMode",
					"false", 0, 1, ProfileRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_SupportExternalName(), var1.getBoolean(),
					"supportExternalName", "false", 0, 1, ProfileRepositoryType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_SupportPaging(), var1.getBoolean(), "supportPaging",
					(String) null, 1, 1, ProfileRepositoryType.class, false, false, true, true, false, false, false,
					true);
			this.initEAttribute(this.getProfileRepositoryType_SupportSorting(), var1.getBoolean(), "supportSorting",
					"false", 0, 1, ProfileRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_SupportTransactions(), var1.getBoolean(),
					"supportTransactions", "false", 0, 1, ProfileRepositoryType.class, false, false, true, true, false,
					false, false, true);
			this.initEAttribute(this.getProfileRepositoryType_SupportChangeLog(), var1.getToken(), "supportChangeLog",
					"none", 0, 1, ProfileRepositoryType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.propertiesNotSupportedTypeEClass, PropertiesNotSupportedType.class,
					"PropertiesNotSupportedType", false, false, true);
			this.initEAttribute(this.getPropertiesNotSupportedType_EntityTypes(), var1.getString(), "entityTypes",
					(String) null, 0, -1, PropertiesNotSupportedType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getPropertiesNotSupportedType_Name(), var1.getString(), "name", (String) null, 1,
					1, PropertiesNotSupportedType.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.propertyExtensionRepositoryTypeEClass, PropertyExtensionRepositoryType.class,
					"PropertyExtensionRepositoryType", false, false, true);
			this.initEAttribute(this.getPropertyExtensionRepositoryType_DatabaseType(), var1.getString(),
					"databaseType", (String) null, 1, 1, PropertyExtensionRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getPropertyExtensionRepositoryType_DataSourceName(), var1.getString(),
					"dataSourceName", (String) null, 1, 1, PropertyExtensionRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getPropertyExtensionRepositoryType_DbAdminId(), var1.getString(), "dbAdminId",
					(String) null, 0, 1, PropertyExtensionRepositoryType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getPropertyExtensionRepositoryType_DbAdminPassword(), var1.getString(),
					"dbAdminPassword", (String) null, 0, 1, PropertyExtensionRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getPropertyExtensionRepositoryType_DbURL(), var1.getString(), "dbURL",
					(String) null, 1, 1, PropertyExtensionRepositoryType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getPropertyExtensionRepositoryType_DbSchema(), var1.getString(), "dbSchema",
					(String) null, 0, 1, PropertyExtensionRepositoryType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getPropertyExtensionRepositoryType_EntityRetrievalLimit(), var1.getInt(),
					"entityRetrievalLimit", "50", 0, 1, PropertyExtensionRepositoryType.class, false, false, true, true,
					false, false, false, true);
			this.initEAttribute(this.getPropertyExtensionRepositoryType_JDBCDriverClass(), var1.getString(),
					"jDBCDriverClass", (String) null, 0, 1, PropertyExtensionRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEClass(this.rdnAttributesTypeEClass, RdnAttributesType.class, "RdnAttributesType", false, false,
					true);
			this.initEAttribute(this.getRdnAttributesType_Name(), var1.getString(), "name", (String) null, 1, 1,
					RdnAttributesType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getRdnAttributesType_ObjectClass(), var1.getString(), "objectClass", (String) null,
					0, 1, RdnAttributesType.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.realmConfigurationTypeEClass, RealmConfigurationType.class, "RealmConfigurationType",
					false, false, true);
			this.initEReference(this.getRealmConfigurationType_Realms(), this.getRealmType(), (EReference) null,
					"realms", (String) null, 1, -1, RealmConfigurationType.class, false, false, true, true, false,
					false, true, false, true);
			this.initEAttribute(this.getRealmConfigurationType_DefaultRealm(), var1.getString(), "defaultRealm",
					(String) null, 1, 1, RealmConfigurationType.class, false, false, true, false, false, false, false,
					true);
			this.initEClass(this.realmDefaultParentTypeEClass, RealmDefaultParentType.class, "RealmDefaultParentType",
					false, false, true);
			this.initEAttribute(this.getRealmDefaultParentType_EntityTypeName(), var1.getString(), "entityTypeName",
					(String) null, 1, 1, RealmDefaultParentType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getRealmDefaultParentType_ParentUniqueName(), var1.getString(), "parentUniqueName",
					(String) null, 1, 1, RealmDefaultParentType.class, false, false, true, false, false, false, false,
					true);
			this.initEClass(this.realmTypeEClass, RealmType.class, "RealmType", false, false, true);
			this.initEReference(this.getRealmType_ParticipatingBaseEntries(), this.getParticipatingBaseEntriesType(),
					(EReference) null, "participatingBaseEntries", (String) null, 1, -1, RealmType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEReference(this.getRealmType_DefaultParents(), this.getRealmDefaultParentType(), (EReference) null,
					"defaultParents", (String) null, 0, -1, RealmType.class, false, false, true, true, false, false,
					true, false, true);
			this.initEReference(this.getRealmType_UniqueUserIdMapping(), this.getUserRegistryInfoMappingType(),
					(EReference) null, "uniqueUserIdMapping", (String) null, 1, 1, RealmType.class, false, false, true,
					true, false, false, true, false, true);
			this.initEReference(this.getRealmType_UserSecurityNameMapping(), this.getUserRegistryInfoMappingType(),
					(EReference) null, "userSecurityNameMapping", (String) null, 1, 1, RealmType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEReference(this.getRealmType_UserDisplayNameMapping(), this.getUserRegistryInfoMappingType(),
					(EReference) null, "userDisplayNameMapping", (String) null, 1, 1, RealmType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEReference(this.getRealmType_UniqueGroupIdMapping(), this.getUserRegistryInfoMappingType(),
					(EReference) null, "uniqueGroupIdMapping", (String) null, 1, 1, RealmType.class, false, false, true,
					true, false, false, true, false, true);
			this.initEReference(this.getRealmType_GroupSecurityNameMapping(), this.getUserRegistryInfoMappingType(),
					(EReference) null, "groupSecurityNameMapping", (String) null, 1, 1, RealmType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEReference(this.getRealmType_GroupDisplayNameMapping(), this.getUserRegistryInfoMappingType(),
					(EReference) null, "groupDisplayNameMapping", (String) null, 1, 1, RealmType.class, false, false,
					true, true, false, false, true, false, true);
			this.initEAttribute(this.getRealmType_Delimiter(), var1.getString(), "delimiter", "@", 0, 1,
					RealmType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getRealmType_Name(), var1.getString(), "name", (String) null, 1, 1,
					RealmType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getRealmType_SecurityUse(), var1.getString(), "securityUse", "active", 0, 1,
					RealmType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getRealmType_AllowOperationIfReposDown(), var1.getBoolean(),
					"allowOperationIfReposDown", "false", 0, 1, RealmType.class, false, false, true, true, false, false,
					false, true);
			this.initEClass(this.repositoryTypeEClass, RepositoryType.class, "RepositoryType", false, false, true);
			this.initEAttribute(this.getRepositoryType_AdapterClassName(), var1.getString(), "adapterClassName",
					(String) null, 0, 1, RepositoryType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getRepositoryType_Id(), var1.getID(), "id", (String) null, 1, 1,
					RepositoryType.class, false, false, true, false, true, false, false, true);
			this.initEClass(this.searchResultsCacheTypeEClass, SearchResultsCacheType.class, "SearchResultsCacheType",
					false, false, true);
			this.initEAttribute(this.getSearchResultsCacheType_CacheSize(), this.getCacheSizeType(), "cacheSize",
					"2000", 0, 1, SearchResultsCacheType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getSearchResultsCacheType_CacheTimeOut(), this.getCacheTimeOutType(),
					"cacheTimeOut", "600", 0, 1, SearchResultsCacheType.class, false, false, true, true, false, false,
					false, true);
			this.initEAttribute(this.getSearchResultsCacheType_Enabled(), var1.getBoolean(), "enabled", "true", 0, 1,
					SearchResultsCacheType.class, false, false, true, true, false, false, false, true);
			this.initEAttribute(this.getSearchResultsCacheType_SearchResultSizeLimit(), this.getCacheSizeLimitType(),
					"searchResultSizeLimit", "1000", 0, 1, SearchResultsCacheType.class, false, false, true, true,
					false, false, false, true);
			this.initEAttribute(this.getSearchResultsCacheType_CacheDistPolicy(), var1.getToken(), "cacheDistPolicy",
					"push", 0, 1, SearchResultsCacheType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.spiBridgeRepositoryTypeEClass, SPIBridgeRepositoryType.class,
					"SPIBridgeRepositoryType", false, false, true);
			this.initEAttribute(this.getSPIBridgeRepositoryType_WMMAdapterClassName(), var1.getString(),
					"wMMAdapterClassName", (String) null, 1, 1, SPIBridgeRepositoryType.class, false, false, true,
					false, false, false, false, true);
			this.initEClass(this.staticModelTypeEClass, StaticModelType.class, "StaticModelType", false, false, true);
			this.initEAttribute(this.getStaticModelType_PackageName(), var1.getString(), "packageName", (String) null,
					0, -1, StaticModelType.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getStaticModelType_UseGlobalSchema(), var1.getBoolean(), "useGlobalSchema",
					"false", 0, 1, StaticModelType.class, false, false, true, true, false, false, false, true);
			this.initEClass(this.supportedEntityTypesTypeEClass, SupportedEntityTypesType.class,
					"SupportedEntityTypesType", false, false, true);
			this.initEAttribute(this.getSupportedEntityTypesType_RdnProperties(), var1.getString(), "rdnProperties",
					(String) null, 1, -1, SupportedEntityTypesType.class, false, false, true, false, false, false,
					false, true);
			this.initEAttribute(this.getSupportedEntityTypesType_DefaultParent(), var1.getString(), "defaultParent",
					(String) null, 1, 1, SupportedEntityTypesType.class, false, false, true, false, false, false, false,
					true);
			this.initEAttribute(this.getSupportedEntityTypesType_Name(), var1.getString(), "name", (String) null, 1, 1,
					SupportedEntityTypesType.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.topicEmitterEClass, TopicEmitter.class, "TopicEmitter", false, false, true);
			this.initEReference(this.getTopicEmitter_PreExit(), this.getPreExit(), (EReference) null, "preExit",
					(String) null, 1, 1, TopicEmitter.class, false, false, true, true, false, false, true, false, true);
			this.initEReference(this.getTopicEmitter_InlineExit(), this.getInlineExit(), (EReference) null,
					"inlineExit", (String) null, 0, -1, TopicEmitter.class, false, false, true, true, false, false,
					true, false, true);
			this.initEReference(this.getTopicEmitter_PostExit(), this.getPostExit(), (EReference) null, "postExit",
					(String) null, 1, 1, TopicEmitter.class, false, false, true, true, false, false, true, false, true);
			this.initEAttribute(this.getTopicEmitter_TopicEmitterName(), var1.getString(), "topicEmitterName",
					(String) null, 0, 1, TopicEmitter.class, false, false, true, false, false, false, false, true);
			this.initEClass(this.topicRegistrationListEClass, TopicRegistrationList.class, "TopicRegistrationList",
					false, false, true);
			this.initEReference(this.getTopicRegistrationList_TopicEmitter(), this.getTopicEmitter(), (EReference) null,
					"topicEmitter", (String) null, 0, -1, TopicRegistrationList.class, false, false, true, true, false,
					false, true, false, true);
			this.initEClass(this.topicSubscriberEClass, TopicSubscriber.class, "TopicSubscriber", false, false, true);
			this.initEAttribute(this.getTopicSubscriber_ClassName(), var1.getString(), "className", (String) null, 1, 1,
					TopicSubscriber.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getTopicSubscriber_TopicSubscriberName(), var1.getString(), "topicSubscriberName",
					(String) null, 0, 1, TopicSubscriber.class, false, false, true, false, false, false, false, true);
			this.initEAttribute(this.getTopicSubscriber_TopicSubscriberType(), this.getSubscriberType(),
					"topicSubscriberType", "NotificationSubscriber", 0, 1, TopicSubscriber.class, false, false, true,
					true, false, false, false, true);
			this.initEClass(this.topicSubscriberListEClass, TopicSubscriberList.class, "TopicSubscriberList", false,
					false, true);
			this.initEReference(this.getTopicSubscriberList_TopicSubscriber(), this.getTopicSubscriber(),
					(EReference) null, "topicSubscriber", (String) null, 0, -1, TopicSubscriberList.class, false, false,
					true, true, false, false, true, false, true);
			this.initEClass(this.userRegistryInfoMappingTypeEClass, UserRegistryInfoMappingType.class,
					"UserRegistryInfoMappingType", false, false, true);
			this.initEAttribute(this.getUserRegistryInfoMappingType_PropertyForInput(), var1.getString(),
					"propertyForInput", (String) null, 1, 1, UserRegistryInfoMappingType.class, false, false, true,
					false, false, false, false, true);
			this.initEAttribute(this.getUserRegistryInfoMappingType_PropertyForOutput(), var1.getString(),
					"propertyForOutput", (String) null, 1, 1, UserRegistryInfoMappingType.class, false, false, true,
					false, false, false, false, true);
			this.initEEnum(this.subscriberTypeEEnum, SubscriberType.class, "SubscriberType");
			this.addEEnumLiteral(this.subscriberTypeEEnum, SubscriberType.NOTIFICATION_SUBSCRIBER_LITERAL);
			this.addEEnumLiteral(this.subscriberTypeEEnum, SubscriberType.MODIFICATION_SUBSCRIBER_LITERAL);
			this.initEDataType(this.cacheSizeLimitTypeEDataType, Integer.TYPE, "CacheSizeLimitType", true, false);
			this.initEDataType(this.cacheSizeLimitTypeObjectEDataType, Integer.class, "CacheSizeLimitTypeObject", true,
					false);
			this.initEDataType(this.cacheSizeTypeEDataType, Integer.TYPE, "CacheSizeType", true, false);
			this.initEDataType(this.cacheSizeTypeObjectEDataType, Integer.class, "CacheSizeTypeObject", true, false);
			this.initEDataType(this.cacheTimeOutTypeEDataType, Integer.TYPE, "CacheTimeOutType", true, false);
			this.initEDataType(this.cacheTimeOutTypeObjectEDataType, Integer.class, "CacheTimeOutTypeObject", true,
					false);
			this.initEDataType(this.dnTypeEDataType, String.class, "DNType", true, false);
			this.initEDataType(this.initPoolSizeTypeEDataType, Integer.TYPE, "InitPoolSizeType", true, false);
			this.initEDataType(this.initPoolSizeTypeObjectEDataType, Integer.class, "InitPoolSizeTypeObject", true,
					false);
			this.initEDataType(this.maxPoolSizeTypeEDataType, Integer.TYPE, "MaxPoolSizeType", true, false);
			this.initEDataType(this.maxPoolSizeTypeObjectEDataType, Integer.class, "MaxPoolSizeTypeObject", true,
					false);
			this.initEDataType(this.poolTimeOutTypeEDataType, Integer.TYPE, "PoolTimeOutType", true, false);
			this.initEDataType(this.poolTimeOutTypeObjectEDataType, Integer.class, "PoolTimeOutTypeObject", true,
					false);
			this.initEDataType(this.poolWaitTimeTypeEDataType, Integer.TYPE, "PoolWaitTimeType", true, false);
			this.initEDataType(this.poolWaitTimeTypeObjectEDataType, Integer.class, "PoolWaitTimeTypeObject", true,
					false);
			this.initEDataType(this.prefPoolSizeTypeEDataType, Integer.TYPE, "PrefPoolSizeType", true, false);
			this.initEDataType(this.prefPoolSizeTypeObjectEDataType, Integer.class, "PrefPoolSizeTypeObject", true,
					false);
			this.initEDataType(this.realmListTypeEDataType, List.class, "RealmListType", true, false);
			this.initEDataType(this.realmListType1EDataType, List.class, "RealmListType1", true, false);
			this.initEDataType(this.subscriberTypeObjectEDataType, SubscriberType.class, "SubscriberTypeObject", true,
					true);
			this.createResource("http://www.ibm.com/websphere/wim/config");
			this.createExtendedMetaDataAnnotations();
		}
	}

	protected void createExtendedMetaDataAnnotations() {
		String var1 = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		this.addAnnotation(this.attributeConfigurationTypeEClass, var1,
				new String[]{"name", "attributeConfiguration_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getAttributeConfigurationType_ExternalIdAttributes(), var1,
				new String[]{"kind", "element", "name", "externalIdAttributes", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getAttributeConfigurationType_Attributes(), var1,
				new String[]{"kind", "element", "name", "attributes", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getAttributeConfigurationType_PropertiesNotSupported(), var1,
				new String[]{"kind", "element", "name", "propertiesNotSupported", "namespace", "##targetNamespace"});
		this.addAnnotation(this.attributeGroupTypeEClass, var1,
				new String[]{"name", "AttributeGroupType", "kind", "elementOnly"});
		this.addAnnotation(this.getAttributeGroupType_GroupName(), var1,
				new String[]{"kind", "element", "name", "groupName", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getAttributeGroupType_AttributeNames(), var1,
				new String[]{"kind", "element", "name", "attributeNames", "namespace", "##targetNamespace"});
		this.addAnnotation(this.attributesCacheTypeEClass, var1,
				new String[]{"name", "attributesCache_._type", "kind", "empty"});
		this.addAnnotation(this.getAttributesCacheType_AttributeSizeLimit(), var1,
				new String[]{"kind", "attribute", "name", "attributeSizeLimit"});
		this.addAnnotation(this.getAttributesCacheType_CacheSize(), var1,
				new String[]{"kind", "attribute", "name", "cacheSize"});
		this.addAnnotation(this.getAttributesCacheType_CacheTimeOut(), var1,
				new String[]{"kind", "attribute", "name", "cacheTimeOut"});
		this.addAnnotation(this.getAttributesCacheType_Enabled(), var1,
				new String[]{"kind", "attribute", "name", "enabled"});
		this.addAnnotation(this.getAttributesCacheType_ServerTTLAttribute(), var1,
				new String[]{"kind", "attribute", "name", "serverTTLAttribute"});
		this.addAnnotation(this.getAttributesCacheType_CacheDistPolicy(), var1,
				new String[]{"kind", "attribute", "name", "cacheDistPolicy"});
		this.addAnnotation(this.attributeTypeEClass, var1,
				new String[]{"name", "AttributeType", "kind", "elementOnly"});
		this.addAnnotation(this.getAttributeType_EntityTypes(), var1,
				new String[]{"kind", "element", "name", "entityTypes", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getAttributeType_DefaultAttribute(), var1,
				new String[]{"kind", "attribute", "name", "defaultAttribute"});
		this.addAnnotation(this.getAttributeType_DefaultValue(), var1,
				new String[]{"kind", "attribute", "name", "defaultValue"});
		this.addAnnotation(this.getAttributeType_Name(), var1, new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getAttributeType_PropertyName(), var1,
				new String[]{"kind", "attribute", "name", "propertyName"});
		this.addAnnotation(this.getAttributeType_Syntax(), var1, new String[]{"kind", "attribute", "name", "syntax"});
		this.addAnnotation(this.getAttributeType_WimGenerate(), var1,
				new String[]{"kind", "attribute", "name", "wimGenerate"});
		this.addAnnotation(this.authorizationTypeEClass, var1,
				new String[]{"name", "AuthorizationType", "kind", "elementOnly"});
		this.addAnnotation(this.getAuthorizationType_AttributeGroups(), var1,
				new String[]{"kind", "element", "name", "attributeGroups", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getAuthorizationType_DefaultAttributeGroup(), var1,
				new String[]{"kind", "attribute", "name", "defaultAttributeGroup"});
		this.addAnnotation(this.getAuthorizationType_ImportPolicyFromFile(), var1,
				new String[]{"kind", "attribute", "name", "importPolicyFromFile"});
		this.addAnnotation(this.getAuthorizationType_IsAttributeGroupingEnabled(), var1,
				new String[]{"kind", "attribute", "name", "isAttributeGroupingEnabled"});
		this.addAnnotation(this.getAuthorizationType_IsSecurityEnabled(), var1,
				new String[]{"kind", "attribute", "name", "isSecurityEnabled"});
		this.addAnnotation(this.getAuthorizationType_JaccPolicyClass(), var1,
				new String[]{"kind", "attribute", "name", "jaccPolicyClass"});
		this.addAnnotation(this.getAuthorizationType_JaccPolicyConfigFactoryClass(), var1,
				new String[]{"kind", "attribute", "name", "jaccPolicyConfigFactoryClass"});
		this.addAnnotation(this.getAuthorizationType_JaccPrincipalToRolePolicyFileName(), var1,
				new String[]{"kind", "attribute", "name", "jaccPrincipalToRolePolicyFileName"});
		this.addAnnotation(this.getAuthorizationType_JaccPrincipalToRolePolicyId(), var1,
				new String[]{"kind", "attribute", "name", "jaccPrincipalToRolePolicyId"});
		this.addAnnotation(this.getAuthorizationType_JaccRoleMappingClass(), var1,
				new String[]{"kind", "attribute", "name", "jaccRoleMappingClass"});
		this.addAnnotation(this.getAuthorizationType_JaccRoleMappingConfigFactoryClass(), var1,
				new String[]{"kind", "attribute", "name", "jaccRoleMappingConfigFactoryClass"});
		this.addAnnotation(this.getAuthorizationType_JaccRoleToPermissionPolicyFileName(), var1,
				new String[]{"kind", "attribute", "name", "jaccRoleToPermissionPolicyFileName"});
		this.addAnnotation(this.getAuthorizationType_JaccRoleToPermissionPolicyId(), var1,
				new String[]{"kind", "attribute", "name", "jaccRoleToPermissionPolicyId"});
		this.addAnnotation(this.getAuthorizationType_UseSystemJACCProvider(), var1,
				new String[]{"kind", "attribute", "name", "useSystemJACCProvider"});
		this.addAnnotation(this.baseEntriesTypeEClass, var1,
				new String[]{"name", "baseEntries_._type", "kind", "empty"});
		this.addAnnotation(this.getBaseEntriesType_Name(), var1, new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getBaseEntriesType_NameInRepository(), var1,
				new String[]{"kind", "attribute", "name", "nameInRepository"});
		this.addAnnotation(this.cacheConfigurationTypeEClass, var1,
				new String[]{"name", "cacheConfiguration_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getCacheConfigurationType_AttributesCache(), var1,
				new String[]{"kind", "element", "name", "attributesCache", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getCacheConfigurationType_SearchResultsCache(), var1,
				new String[]{"kind", "element", "name", "searchResultsCache", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getCacheConfigurationType_CachesDiskOffLoad(), var1,
				new String[]{"kind", "attribute", "name", "cachesDiskOffLoad"});
		this.addAnnotation(this.cacheSizeLimitTypeEDataType, var1, new String[]{"name", "cacheSizeLimitType",
				"baseType", "http://www.eclipse.org/emf/2003/XMLType#int", "minInclusive", "0"});
		this.addAnnotation(this.cacheSizeLimitTypeObjectEDataType, var1,
				new String[]{"name", "cacheSizeLimitType:Object", "baseType", "cacheSizeLimitType"});
		this.addAnnotation(this.cacheSizeTypeEDataType, var1, new String[]{"name", "cacheSizeType", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#int", "minInclusive", "100"});
		this.addAnnotation(this.cacheSizeTypeObjectEDataType, var1,
				new String[]{"name", "cacheSizeType:Object", "baseType", "cacheSizeType"});
		this.addAnnotation(this.cacheTimeOutTypeEDataType, var1, new String[]{"name", "cacheTimeOutType", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#int", "minInclusive", "0"});
		this.addAnnotation(this.cacheTimeOutTypeObjectEDataType, var1,
				new String[]{"name", "cacheTimeOutType:Object", "baseType", "cacheTimeOutType"});
		this.addAnnotation(this.configurationProviderTypeEClass, var1,
				new String[]{"name", "configurationProvider_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getConfigurationProviderType_DynamicModel(), var1,
				new String[]{"kind", "element", "name", "dynamicModel", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getConfigurationProviderType_StaticModel(), var1,
				new String[]{"kind", "element", "name", "staticModel", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getConfigurationProviderType_SupportedEntityTypes(), var1,
				new String[]{"kind", "element", "name", "supportedEntityTypes", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getConfigurationProviderType_EntryMappingRepository(), var1,
				new String[]{"kind", "element", "name", "entryMappingRepository", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getConfigurationProviderType_PropertyExtensionRepository(), var1, new String[]{"kind",
				"element", "name", "propertyExtensionRepository", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getConfigurationProviderType_Repositories(), var1,
				new String[]{"kind", "element", "name", "repositories", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getConfigurationProviderType_RealmConfiguration(), var1,
				new String[]{"kind", "element", "name", "realmConfiguration", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getConfigurationProviderType_PluginManagerConfiguration(), var1, new String[]{"kind",
				"element", "name", "pluginManagerConfiguration", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getConfigurationProviderType_Authorization(), var1,
				new String[]{"kind", "element", "name", "authorization", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getConfigurationProviderType_MaxPagingResults(), var1,
				new String[]{"kind", "attribute", "name", "maxPagingResults"});
		this.addAnnotation(this.getConfigurationProviderType_MaxSearchResults(), var1,
				new String[]{"kind", "attribute", "name", "maxSearchResults"});
		this.addAnnotation(this.getConfigurationProviderType_MaxTotalPagingResults(), var1,
				new String[]{"kind", "attribute", "name", "maxTotalPagingResults"});
		this.addAnnotation(this.getConfigurationProviderType_PagedCacheTimeOut(), var1,
				new String[]{"kind", "attribute", "name", "pagedCacheTimeOut"});
		this.addAnnotation(this.getConfigurationProviderType_PagingCachesDiskOffLoad(), var1,
				new String[]{"kind", "attribute", "name", "pagingCachesDiskOffLoad"});
		this.addAnnotation(this.getConfigurationProviderType_PagingEntityObject(), var1,
				new String[]{"kind", "attribute", "name", "pagingEntityObject"});
		this.addAnnotation(this.getConfigurationProviderType_SearchTimeOut(), var1,
				new String[]{"kind", "attribute", "name", "searchTimeOut"});
		this.addAnnotation(this.connectionsTypeEClass, var1,
				new String[]{"name", "connections_._type", "kind", "empty"});
		this.addAnnotation(this.getConnectionsType_Host(), var1, new String[]{"kind", "attribute", "name", "host"});
		this.addAnnotation(this.getConnectionsType_Port(), var1, new String[]{"kind", "attribute", "name", "port"});
		this.addAnnotation(this.contextPoolTypeEClass, var1,
				new String[]{"name", "contextPool_._type", "kind", "empty"});
		this.addAnnotation(this.getContextPoolType_Enabled(), var1,
				new String[]{"kind", "attribute", "name", "enabled"});
		this.addAnnotation(this.getContextPoolType_InitPoolSize(), var1,
				new String[]{"kind", "attribute", "name", "initPoolSize"});
		this.addAnnotation(this.getContextPoolType_MaxPoolSize(), var1,
				new String[]{"kind", "attribute", "name", "maxPoolSize"});
		this.addAnnotation(this.getContextPoolType_PoolTimeOut(), var1,
				new String[]{"kind", "attribute", "name", "poolTimeOut"});
		this.addAnnotation(this.getContextPoolType_PoolWaitTime(), var1,
				new String[]{"kind", "attribute", "name", "poolWaitTime"});
		this.addAnnotation(this.getContextPoolType_PrefPoolSize(), var1,
				new String[]{"kind", "attribute", "name", "prefPoolSize"});
		this.addAnnotation(this.customPropertiesTypeEClass, var1,
				new String[]{"name", "CustomProperties_._type", "kind", "empty"});
		this.addAnnotation(this.getCustomPropertiesType_Name(), var1,
				new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getCustomPropertiesType_Value(), var1,
				new String[]{"kind", "attribute", "name", "value"});
		this.addAnnotation(this.databaseRepositoryTypeEClass, var1,
				new String[]{"name", "DatabaseRepositoryType", "kind", "elementOnly"});
		this.addAnnotation(this.getDatabaseRepositoryType_DatabaseType(), var1,
				new String[]{"kind", "attribute", "name", "databaseType"});
		this.addAnnotation(this.getDatabaseRepositoryType_DataSourceName(), var1,
				new String[]{"kind", "attribute", "name", "dataSourceName"});
		this.addAnnotation(this.getDatabaseRepositoryType_DbAdminId(), var1,
				new String[]{"kind", "attribute", "name", "dbAdminId"});
		this.addAnnotation(this.getDatabaseRepositoryType_DbAdminPassword(), var1,
				new String[]{"kind", "attribute", "name", "dbAdminPassword"});
		this.addAnnotation(this.getDatabaseRepositoryType_DbURL(), var1,
				new String[]{"kind", "attribute", "name", "dbURL"});
		this.addAnnotation(this.getDatabaseRepositoryType_DbSchema(), var1,
				new String[]{"kind", "attribute", "name", "dbSchema"});
		this.addAnnotation(this.getDatabaseRepositoryType_EncryptionKey(), var1,
				new String[]{"kind", "attribute", "name", "encryptionKey"});
		this.addAnnotation(this.getDatabaseRepositoryType_EntityRetrievalLimit(), var1,
				new String[]{"kind", "attribute", "name", "entityRetrievalLimit"});
		this.addAnnotation(this.getDatabaseRepositoryType_JDBCDriverClass(), var1,
				new String[]{"kind", "attribute", "name", "JDBCDriverClass"});
		this.addAnnotation(this.getDatabaseRepositoryType_SaltLength(), var1,
				new String[]{"kind", "attribute", "name", "saltLength"});
		this.addAnnotation(this.getDatabaseRepositoryType_HashAlgorithm(), var1,
				new String[]{"kind", "attribute", "name", "hashAlgorithm"});
		this.addAnnotation(this.getDatabaseRepositoryType_HashIterations(), var1,
				new String[]{"kind", "attribute", "name", "hashIterations"});
		this.addAnnotation(this.getDatabaseRepositoryType_HashKeyLength(), var1,
				new String[]{"kind", "attribute", "name", "hashKeyLength"});
		this.addAnnotation(this.getDatabaseRepositoryType_HashSaltLength(), var1,
				new String[]{"kind", "attribute", "name", "hashSaltLength"});
		this.addAnnotation(this.dnTypeEDataType, var1, new String[]{"name", "DNType", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#string", "pattern", "(((.+)(=)(.+))(,(.+)(=)(.+))*)"});
		this.addAnnotation(this.documentRootEClass, var1, new String[]{"name", "", "kind", "mixed"});
		this.addAnnotation(this.getDocumentRoot_Mixed(), var1,
				new String[]{"kind", "elementWildcard", "name", ":mixed"});
		this.addAnnotation(this.getDocumentRoot_XMLNSPrefixMap(), var1,
				new String[]{"kind", "attribute", "name", "xmlns:prefix"});
		this.addAnnotation(this.getDocumentRoot_XSISchemaLocation(), var1,
				new String[]{"kind", "attribute", "name", "xsi:schemaLocation"});
		this.addAnnotation(this.getDocumentRoot_ConfigurationProvider(), var1,
				new String[]{"kind", "element", "name", "configurationProvider", "namespace", "##targetNamespace"});
		this.addAnnotation(this.dynamicMemberAttributesTypeEClass, var1,
				new String[]{"name", "dynamicMemberAttributes_._type", "kind", "empty"});
		this.addAnnotation(this.getDynamicMemberAttributesType_Name(), var1,
				new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getDynamicMemberAttributesType_ObjectClass(), var1,
				new String[]{"kind", "attribute", "name", "objectClass"});
		this.addAnnotation(this.dynamicModelTypeEClass, var1,
				new String[]{"name", "dynamicModel_._type", "kind", "empty"});
		this.addAnnotation(this.getDynamicModelType_XsdFileName(), var1,
				new String[]{"kind", "attribute", "name", "xsdFileName"});
		this.addAnnotation(this.getDynamicModelType_UseGlobalSchema(), var1,
				new String[]{"kind", "attribute", "name", "useGlobalSchema"});
		this.addAnnotation(this.entryMappingRepositoryTypeEClass, var1,
				new String[]{"name", "EntryMappingRepositoryType", "kind", "empty"});
		this.addAnnotation(this.getEntryMappingRepositoryType_DatabaseType(), var1,
				new String[]{"kind", "attribute", "name", "databaseType"});
		this.addAnnotation(this.getEntryMappingRepositoryType_DataSourceName(), var1,
				new String[]{"kind", "attribute", "name", "dataSourceName"});
		this.addAnnotation(this.getEntryMappingRepositoryType_DbAdminId(), var1,
				new String[]{"kind", "attribute", "name", "dbAdminId"});
		this.addAnnotation(this.getEntryMappingRepositoryType_DbAdminPassword(), var1,
				new String[]{"kind", "attribute", "name", "dbAdminPassword"});
		this.addAnnotation(this.getEntryMappingRepositoryType_DbURL(), var1,
				new String[]{"kind", "attribute", "name", "dbURL"});
		this.addAnnotation(this.getEntryMappingRepositoryType_DbSchema(), var1,
				new String[]{"kind", "attribute", "name", "dbSchema"});
		this.addAnnotation(this.getEntryMappingRepositoryType_JDBCDriverClass(), var1,
				new String[]{"kind", "attribute", "name", "JDBCDriverClass"});
		this.addAnnotation(this.environmentPropertiesTypeEClass, var1,
				new String[]{"name", "environmentProperties_._type", "kind", "empty"});
		this.addAnnotation(this.getEnvironmentPropertiesType_Name(), var1,
				new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getEnvironmentPropertiesType_Value(), var1,
				new String[]{"kind", "attribute", "name", "value"});
		this.addAnnotation(this.krb5AuthenticationTypeEClass, var1,
				new String[]{"name", "krb5Authentication_._type", "kind", "empty"});
		this.addAnnotation(this.getKrb5AuthenticationType_Krb5Principal(), var1,
				new String[]{"kind", "attribute", "name", "krb5Principal"});
		this.addAnnotation(this.getKrb5AuthenticationType_Krb5TicketCache(), var1,
				new String[]{"kind", "attribute", "name", "krb5TicketCache"});
		this.addAnnotation(this.fileRepositoryTypeEClass, var1,
				new String[]{"name", "FileRepositoryType", "kind", "elementOnly"});
		this.addAnnotation(this.getFileRepositoryType_BaseDirectory(), var1,
				new String[]{"kind", "attribute", "name", "baseDirectory"});
		this.addAnnotation(this.getFileRepositoryType_CaseSensitive(), var1,
				new String[]{"kind", "attribute", "name", "caseSensitive"});
		this.addAnnotation(this.getFileRepositoryType_FileName(), var1,
				new String[]{"kind", "attribute", "name", "fileName"});
		this.addAnnotation(this.getFileRepositoryType_MessageDigestAlgorithm(), var1,
				new String[]{"kind", "attribute", "name", "messageDigestAlgorithm"});
		this.addAnnotation(this.getFileRepositoryType_SaltLength(), var1,
				new String[]{"kind", "attribute", "name", "saltLength"});
		this.addAnnotation(this.getFileRepositoryType_KeyLength(), var1,
				new String[]{"kind", "attribute", "name", "keyLength"});
		this.addAnnotation(this.getFileRepositoryType_HashIterations(), var1,
				new String[]{"kind", "attribute", "name", "hashIterations"});
		this.addAnnotation(this.getFileRepositoryType_AccountLockoutThreshold(), var1,
				new String[]{"kind", "attribute", "name", "accountLockoutThreshold"});
		this.addAnnotation(this.getFileRepositoryType_AccountLockoutDuration(), var1,
				new String[]{"kind", "attribute", "name", "accountLockoutDuration"});
		this.addAnnotation(this.getFileRepositoryType_IgnoreFailedLoginAfter(), var1,
				new String[]{"kind", "attribute", "name", "ignoreFailedLoginAfter"});
		this.addAnnotation(this.groupConfigurationTypeEClass, var1,
				new String[]{"name", "groupConfiguration_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getGroupConfigurationType_MemberAttributes(), var1,
				new String[]{"kind", "element", "name", "memberAttributes", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getGroupConfigurationType_DynamicMemberAttributes(), var1,
				new String[]{"kind", "element", "name", "dynamicMemberAttributes", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getGroupConfigurationType_MembershipAttribute(), var1,
				new String[]{"kind", "element", "name", "membershipAttribute", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getGroupConfigurationType_UpdateGroupMembership(), var1,
				new String[]{"kind", "attribute", "name", "updateGroupMembership"});
		this.addAnnotation(this.initPoolSizeTypeEDataType, var1, new String[]{"name", "initPoolSizeType", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#int", "minInclusive", "1", "maxInclusive", "50"});
		this.addAnnotation(this.initPoolSizeTypeObjectEDataType, var1,
				new String[]{"name", "initPoolSizeType:Object", "baseType", "initPoolSizeType"});
		this.addAnnotation(this.inlineExitEClass, var1, new String[]{"name", "InlineExit", "kind", "elementOnly"});
		this.addAnnotation(this.getInlineExit_ModificationSubscriberList(), var1, new String[]{"kind", "element",
				"name", "modificationSubscriberList", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getInlineExit_InlineExitName(), var1,
				new String[]{"kind", "attribute", "name", "inlineExitName"});
		this.addAnnotation(this.ldapEntityTypesTypeEClass, var1,
				new String[]{"name", "ldapEntityTypes_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getLdapEntityTypesType_RdnAttributes(), var1,
				new String[]{"kind", "element", "name", "rdnAttributes", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapEntityTypesType_ObjectClasses(), var1,
				new String[]{"kind", "element", "name", "objectClasses", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapEntityTypesType_ObjectClassesForCreate(), var1,
				new String[]{"kind", "element", "name", "objectClassesForCreate", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapEntityTypesType_SearchBases(), var1,
				new String[]{"kind", "element", "name", "searchBases", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapEntityTypesType_Name(), var1, new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getLdapEntityTypesType_SearchFilter(), var1,
				new String[]{"kind", "attribute", "name", "searchFilter"});
		this.addAnnotation(this.ldapRepositoryTypeEClass, var1,
				new String[]{"name", "LdapRepositoryType", "kind", "elementOnly"});
		this.addAnnotation(this.getLdapRepositoryType_LdapServerConfiguration(), var1,
				new String[]{"kind", "element", "name", "ldapServerConfiguration", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapRepositoryType_LdapEntityTypes(), var1,
				new String[]{"kind", "element", "name", "ldapEntityTypes", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapRepositoryType_GroupConfiguration(), var1,
				new String[]{"kind", "element", "name", "groupConfiguration", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapRepositoryType_AttributeConfiguration(), var1,
				new String[]{"kind", "element", "name", "attributeConfiguration", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapRepositoryType_ContextPool(), var1,
				new String[]{"kind", "element", "name", "contextPool", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapRepositoryType_CacheConfiguration(), var1,
				new String[]{"kind", "element", "name", "cacheConfiguration", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapRepositoryType_CertificateFilter(), var1,
				new String[]{"kind", "attribute", "name", "certificateFilter"});
		this.addAnnotation(this.getLdapRepositoryType_CertificateMapMode(), var1,
				new String[]{"kind", "attribute", "name", "certificateMapMode"});
		this.addAnnotation(this.getLdapRepositoryType_LdapServerType(), var1,
				new String[]{"kind", "attribute", "name", "ldapServerType"});
		this.addAnnotation(this.getLdapRepositoryType_TranslateRDN(), var1,
				new String[]{"kind", "attribute", "name", "translateRDN"});
		this.addAnnotation(this.ldapServerConfigurationTypeEClass, var1,
				new String[]{"name", "ldapServerConfiguration_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getLdapServerConfigurationType_LdapServers(), var1,
				new String[]{"kind", "element", "name", "ldapServers", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapServerConfigurationType_AllowWriteToSecondaryServers(), var1,
				new String[]{"kind", "attribute", "name", "allowWriteToSecondaryServers"});
		this.addAnnotation(this.getLdapServerConfigurationType_AttributeRangeStep(), var1,
				new String[]{"kind", "attribute", "name", "attributeRangeStep"});
		this.addAnnotation(this.getLdapServerConfigurationType_PrimaryServerQueryTimeInterval(), var1,
				new String[]{"kind", "attribute", "name", "primaryServerQueryTimeInterval"});
		this.addAnnotation(this.getLdapServerConfigurationType_ReturnToPrimaryServer(), var1,
				new String[]{"kind", "attribute", "name", "returnToPrimaryServer"});
		this.addAnnotation(this.getLdapServerConfigurationType_SearchCountLimit(), var1,
				new String[]{"kind", "attribute", "name", "searchCountLimit"});
		this.addAnnotation(this.getLdapServerConfigurationType_SearchPageSize(), var1,
				new String[]{"kind", "attribute", "name", "searchPageSize"});
		this.addAnnotation(this.getLdapServerConfigurationType_SearchTimeLimit(), var1,
				new String[]{"kind", "attribute", "name", "searchTimeLimit"});
		this.addAnnotation(this.getLdapServerConfigurationType_SslConfiguration(), var1,
				new String[]{"kind", "attribute", "name", "sslConfiguration"});
		this.addAnnotation(this.getLdapServerConfigurationType_SslKeyStore(), var1,
				new String[]{"kind", "attribute", "name", "sslKeyStore"});
		this.addAnnotation(this.getLdapServerConfigurationType_SslKeyStorePassword(), var1,
				new String[]{"kind", "attribute", "name", "sslKeyStorePassword"});
		this.addAnnotation(this.getLdapServerConfigurationType_SslKeyStoreType(), var1,
				new String[]{"kind", "attribute", "name", "sslKeyStoreType"});
		this.addAnnotation(this.getLdapServerConfigurationType_SslTrustStore(), var1,
				new String[]{"kind", "attribute", "name", "sslTrustStore"});
		this.addAnnotation(this.getLdapServerConfigurationType_SslTrustStorePassword(), var1,
				new String[]{"kind", "attribute", "name", "sslTrustStorePassword"});
		this.addAnnotation(this.getLdapServerConfigurationType_SslTrustStoreType(), var1,
				new String[]{"kind", "attribute", "name", "sslTrustStoreType"});
		this.addAnnotation(this.ldapServersTypeEClass, var1,
				new String[]{"name", "ldapServers_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getLdapServersType_Connections(), var1,
				new String[]{"kind", "element", "name", "connections", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapServersType_EnvironmentProperties(), var1,
				new String[]{"kind", "element", "name", "environmentProperties", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapServersType_Krb5Authentication(), var1,
				new String[]{"kind", "element", "name", "krb5Authentication", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getLdapServersType_Authentication(), var1,
				new String[]{"kind", "attribute", "name", "authentication"});
		this.addAnnotation(this.getLdapServersType_BindDN(), var1, new String[]{"kind", "attribute", "name", "bindDN"});
		this.addAnnotation(this.getLdapServersType_BindPassword(), var1,
				new String[]{"kind", "attribute", "name", "bindPassword"});
		this.addAnnotation(this.getLdapServersType_ConnectionPool(), var1,
				new String[]{"kind", "attribute", "name", "connectionPool"});
		this.addAnnotation(this.getLdapServersType_ConnectTimeout(), var1,
				new String[]{"kind", "attribute", "name", "connectTimeout"});
		this.addAnnotation(this.getLdapServersType_DerefAliases(), var1,
				new String[]{"kind", "attribute", "name", "derefAliases"});
		this.addAnnotation(this.getLdapServersType_Referal(), var1,
				new String[]{"kind", "attribute", "name", "referal"});
		this.addAnnotation(this.getLdapServersType_SslEnabled(), var1,
				new String[]{"kind", "attribute", "name", "sslEnabled"});
		this.addAnnotation(this.getLdapServersType_BindAuthMechanism(), var1,
				new String[]{"kind", "attribute", "name", "bindAuthMechanism"});
		this.addAnnotation(this.maxPoolSizeTypeEDataType, var1, new String[]{"name", "maxPoolSizeType", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#int", "minInclusive", "0"});
		this.addAnnotation(this.maxPoolSizeTypeObjectEDataType, var1,
				new String[]{"name", "maxPoolSizeType:Object", "baseType", "maxPoolSizeType"});
		this.addAnnotation(this.memberAttributesTypeEClass, var1,
				new String[]{"name", "memberAttributes_._type", "kind", "empty"});
		this.addAnnotation(this.getMemberAttributesType_DummyMember(), var1,
				new String[]{"kind", "attribute", "name", "dummyMember"});
		this.addAnnotation(this.getMemberAttributesType_Name(), var1,
				new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getMemberAttributesType_ObjectClass(), var1,
				new String[]{"kind", "attribute", "name", "objectClass"});
		this.addAnnotation(this.getMemberAttributesType_Scope(), var1,
				new String[]{"kind", "attribute", "name", "scope"});
		this.addAnnotation(this.membershipAttributeTypeEClass, var1,
				new String[]{"name", "membershipAttribute_._type", "kind", "empty"});
		this.addAnnotation(this.getMembershipAttributeType_Name(), var1,
				new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getMembershipAttributeType_Scope(), var1,
				new String[]{"kind", "attribute", "name", "scope"});
		this.addAnnotation(this.modificationSubscriberEClass, var1,
				new String[]{"name", "ModificationSubscriber", "kind", "elementOnly"});
		this.addAnnotation(this.getModificationSubscriber_ModificationSubscriberReference(), var1, new String[]{"kind",
				"element", "name", "modificationSubscriberReference", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getModificationSubscriber_RealmList(), var1,
				new String[]{"kind", "element", "name", "realmList", "namespace", "##targetNamespace"});
		this.addAnnotation(this.modificationSubscriberListEClass, var1,
				new String[]{"name", "ModificationSubscriberList", "kind", "elementOnly"});
		this.addAnnotation(this.getModificationSubscriberList_ModificationSubscriber(), var1,
				new String[]{"kind", "element", "name", "modificationSubscriber", "namespace", "##targetNamespace"});
		this.addAnnotation(this.notificationSubscriberEClass, var1,
				new String[]{"name", "NotificationSubscriber", "kind", "elementOnly"});
		this.addAnnotation(this.getNotificationSubscriber_NotificationSubscriberReference(), var1, new String[]{"kind",
				"element", "name", "notificationSubscriberReference", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getNotificationSubscriber_RealmList(), var1,
				new String[]{"kind", "element", "name", "realmList", "namespace", "##targetNamespace"});
		this.addAnnotation(this.notificationSubscriberListEClass, var1,
				new String[]{"name", "NotificationSubscriberList", "kind", "elementOnly"});
		this.addAnnotation(this.getNotificationSubscriberList_NotificationSubscriber(), var1,
				new String[]{"kind", "element", "name", "notificationSubscriber", "namespace", "##targetNamespace"});
		this.addAnnotation(this.participatingBaseEntriesTypeEClass, var1,
				new String[]{"name", "participatingBaseEntries_._type", "kind", "empty"});
		this.addAnnotation(this.getParticipatingBaseEntriesType_Name(), var1,
				new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.pluginManagerConfigurationTypeEClass, var1,
				new String[]{"name", "pluginManagerConfigurationType", "kind", "elementOnly"});
		this.addAnnotation(this.getPluginManagerConfigurationType_TopicSubscriberList(), var1,
				new String[]{"kind", "element", "name", "topicSubscriberList", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getPluginManagerConfigurationType_TopicRegistrationList(), var1,
				new String[]{"kind", "element", "name", "topicRegistrationList", "namespace", "##targetNamespace"});
		this.addAnnotation(this.poolTimeOutTypeEDataType, var1, new String[]{"name", "poolTimeOutType", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#int", "minInclusive", "0"});
		this.addAnnotation(this.poolTimeOutTypeObjectEDataType, var1,
				new String[]{"name", "poolTimeOutType:Object", "baseType", "poolTimeOutType"});
		this.addAnnotation(this.poolWaitTimeTypeEDataType, var1, new String[]{"name", "poolWaitTimeType", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#int", "minInclusive", "0"});
		this.addAnnotation(this.poolWaitTimeTypeObjectEDataType, var1,
				new String[]{"name", "poolWaitTimeType:Object", "baseType", "poolWaitTimeType"});
		this.addAnnotation(this.postExitEClass, var1, new String[]{"name", "PostExit", "kind", "elementOnly"});
		this.addAnnotation(this.getPostExit_ModificationSubscriberList(), var1, new String[]{"kind", "element", "name",
				"modificationSubscriberList", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getPostExit_NotificationSubscriberList(), var1, new String[]{"kind", "element", "name",
				"notificationSubscriberList", "namespace", "##targetNamespace"});
		this.addAnnotation(this.preExitEClass, var1, new String[]{"name", "PreExit", "kind", "elementOnly"});
		this.addAnnotation(this.getPreExit_NotificationSubscriberList(), var1, new String[]{"kind", "element", "name",
				"notificationSubscriberList", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getPreExit_ModificationSubscriberList(), var1, new String[]{"kind", "element", "name",
				"modificationSubscriberList", "namespace", "##targetNamespace"});
		this.addAnnotation(this.prefPoolSizeTypeEDataType, var1, new String[]{"name", "prefPoolSizeType", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#int", "minInclusive", "0", "maxInclusive", "100"});
		this.addAnnotation(this.prefPoolSizeTypeObjectEDataType, var1,
				new String[]{"name", "prefPoolSizeType:Object", "baseType", "prefPoolSizeType"});
		this.addAnnotation(this.profileRepositoryTypeEClass, var1,
				new String[]{"name", "ProfileRepositoryType", "kind", "elementOnly"});
		this.addAnnotation(this.getProfileRepositoryType_BaseEntries(), var1,
				new String[]{"kind", "element", "name", "baseEntries", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getProfileRepositoryType_EntityTypesNotAllowCreate(), var1,
				new String[]{"kind", "element", "name", "EntityTypesNotAllowCreate", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getProfileRepositoryType_EntityTypesNotAllowUpdate(), var1,
				new String[]{"kind", "element", "name", "EntityTypesNotAllowUpdate", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getProfileRepositoryType_EntityTypesNotAllowRead(), var1,
				new String[]{"kind", "element", "name", "EntityTypesNotAllowRead", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getProfileRepositoryType_EntityTypesNotAllowDelete(), var1,
				new String[]{"kind", "element", "name", "EntityTypesNotAllowDelete", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getProfileRepositoryType_RepositoriesForGroups(), var1,
				new String[]{"kind", "element", "name", "repositoriesForGroups", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getProfileRepositoryType_LoginProperties(), var1,
				new String[]{"kind", "element", "name", "loginProperties", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getProfileRepositoryType_CustomProperties(), var1,
				new String[]{"kind", "element", "name", "CustomProperties", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getProfileRepositoryType_IsExtIdUnique(), var1,
				new String[]{"kind", "attribute", "name", "isExtIdUnique"});
		this.addAnnotation(this.getProfileRepositoryType_ReadOnly(), var1,
				new String[]{"kind", "attribute", "name", "readOnly"});
		this.addAnnotation(this.getProfileRepositoryType_SupportAsyncMode(), var1,
				new String[]{"kind", "attribute", "name", "supportAsyncMode"});
		this.addAnnotation(this.getProfileRepositoryType_SupportExternalName(), var1,
				new String[]{"kind", "attribute", "name", "supportExternalName"});
		this.addAnnotation(this.getProfileRepositoryType_SupportPaging(), var1,
				new String[]{"kind", "attribute", "name", "supportPaging"});
		this.addAnnotation(this.getProfileRepositoryType_SupportSorting(), var1,
				new String[]{"kind", "attribute", "name", "supportSorting"});
		this.addAnnotation(this.getProfileRepositoryType_SupportTransactions(), var1,
				new String[]{"kind", "attribute", "name", "supportTransactions"});
		this.addAnnotation(this.getProfileRepositoryType_SupportChangeLog(), var1,
				new String[]{"kind", "attribute", "name", "supportChangeLog"});
		this.addAnnotation(this.propertiesNotSupportedTypeEClass, var1,
				new String[]{"name", "propertiesNotSupported_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getPropertiesNotSupportedType_EntityTypes(), var1,
				new String[]{"kind", "element", "name", "entityTypes", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getPropertiesNotSupportedType_Name(), var1,
				new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.propertyExtensionRepositoryTypeEClass, var1,
				new String[]{"name", "PropertyExtensionRepositoryType", "kind", "empty"});
		this.addAnnotation(this.getPropertyExtensionRepositoryType_DatabaseType(), var1,
				new String[]{"kind", "attribute", "name", "databaseType"});
		this.addAnnotation(this.getPropertyExtensionRepositoryType_DataSourceName(), var1,
				new String[]{"kind", "attribute", "name", "dataSourceName"});
		this.addAnnotation(this.getPropertyExtensionRepositoryType_DbAdminId(), var1,
				new String[]{"kind", "attribute", "name", "dbAdminId"});
		this.addAnnotation(this.getPropertyExtensionRepositoryType_DbAdminPassword(), var1,
				new String[]{"kind", "attribute", "name", "dbAdminPassword"});
		this.addAnnotation(this.getPropertyExtensionRepositoryType_DbURL(), var1,
				new String[]{"kind", "attribute", "name", "dbURL"});
		this.addAnnotation(this.getPropertyExtensionRepositoryType_DbSchema(), var1,
				new String[]{"kind", "attribute", "name", "dbSchema"});
		this.addAnnotation(this.getPropertyExtensionRepositoryType_EntityRetrievalLimit(), var1,
				new String[]{"kind", "attribute", "name", "entityRetrievalLimit"});
		this.addAnnotation(this.getPropertyExtensionRepositoryType_JDBCDriverClass(), var1,
				new String[]{"kind", "attribute", "name", "JDBCDriverClass"});
		this.addAnnotation(this.rdnAttributesTypeEClass, var1,
				new String[]{"name", "rdnAttributes_._type", "kind", "empty"});
		this.addAnnotation(this.getRdnAttributesType_Name(), var1, new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getRdnAttributesType_ObjectClass(), var1,
				new String[]{"kind", "attribute", "name", "objectClass"});
		this.addAnnotation(this.realmConfigurationTypeEClass, var1,
				new String[]{"name", "RealmConfigurationType", "kind", "elementOnly"});
		this.addAnnotation(this.getRealmConfigurationType_Realms(), var1,
				new String[]{"kind", "element", "name", "realms", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getRealmConfigurationType_DefaultRealm(), var1,
				new String[]{"kind", "attribute", "name", "defaultRealm"});
		this.addAnnotation(this.realmDefaultParentTypeEClass, var1,
				new String[]{"name", "RealmDefaultParentType", "kind", "empty"});
		this.addAnnotation(this.getRealmDefaultParentType_EntityTypeName(), var1,
				new String[]{"kind", "attribute", "name", "entityTypeName"});
		this.addAnnotation(this.getRealmDefaultParentType_ParentUniqueName(), var1,
				new String[]{"kind", "attribute", "name", "parentUniqueName"});
		this.addAnnotation(this.realmListTypeEDataType, var1,
				new String[]{"name", "realmList_._type", "itemType", "http://www.eclipse.org/emf/2003/XMLType#string"});
		this.addAnnotation(this.realmListType1EDataType, var1, new String[]{"name", "realmList_._1_._type", "itemType",
				"http://www.eclipse.org/emf/2003/XMLType#string"});
		this.addAnnotation(this.realmTypeEClass, var1, new String[]{"name", "RealmType", "kind", "elementOnly"});
		this.addAnnotation(this.getRealmType_ParticipatingBaseEntries(), var1,
				new String[]{"kind", "element", "name", "participatingBaseEntries", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getRealmType_DefaultParents(), var1,
				new String[]{"kind", "element", "name", "defaultParents", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getRealmType_UniqueUserIdMapping(), var1,
				new String[]{"kind", "element", "name", "uniqueUserIdMapping", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getRealmType_UserSecurityNameMapping(), var1,
				new String[]{"kind", "element", "name", "userSecurityNameMapping", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getRealmType_UserDisplayNameMapping(), var1,
				new String[]{"kind", "element", "name", "userDisplayNameMapping", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getRealmType_UniqueGroupIdMapping(), var1,
				new String[]{"kind", "element", "name", "uniqueGroupIdMapping", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getRealmType_GroupSecurityNameMapping(), var1,
				new String[]{"kind", "element", "name", "groupSecurityNameMapping", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getRealmType_GroupDisplayNameMapping(), var1,
				new String[]{"kind", "element", "name", "groupDisplayNameMapping", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getRealmType_Delimiter(), var1, new String[]{"kind", "attribute", "name", "delimiter"});
		this.addAnnotation(this.getRealmType_Name(), var1, new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.getRealmType_SecurityUse(), var1,
				new String[]{"kind", "attribute", "name", "securityUse"});
		this.addAnnotation(this.getRealmType_AllowOperationIfReposDown(), var1,
				new String[]{"kind", "attribute", "name", "allowOperationIfReposDown"});
		this.addAnnotation(this.repositoryTypeEClass, var1, new String[]{"name", "RepositoryType", "kind", "empty"});
		this.addAnnotation(this.getRepositoryType_AdapterClassName(), var1,
				new String[]{"kind", "attribute", "name", "adapterClassName"});
		this.addAnnotation(this.getRepositoryType_Id(), var1, new String[]{"kind", "attribute", "name", "id"});
		this.addAnnotation(this.searchResultsCacheTypeEClass, var1,
				new String[]{"name", "searchResultsCache_._type", "kind", "empty"});
		this.addAnnotation(this.getSearchResultsCacheType_CacheSize(), var1,
				new String[]{"kind", "attribute", "name", "cacheSize"});
		this.addAnnotation(this.getSearchResultsCacheType_CacheTimeOut(), var1,
				new String[]{"kind", "attribute", "name", "cacheTimeOut"});
		this.addAnnotation(this.getSearchResultsCacheType_Enabled(), var1,
				new String[]{"kind", "attribute", "name", "enabled"});
		this.addAnnotation(this.getSearchResultsCacheType_SearchResultSizeLimit(), var1,
				new String[]{"kind", "attribute", "name", "searchResultSizeLimit"});
		this.addAnnotation(this.getSearchResultsCacheType_CacheDistPolicy(), var1,
				new String[]{"kind", "attribute", "name", "cacheDistPolicy"});
		this.addAnnotation(this.spiBridgeRepositoryTypeEClass, var1,
				new String[]{"name", "SPIBridgeRepositoryType", "kind", "elementOnly"});
		this.addAnnotation(this.getSPIBridgeRepositoryType_WMMAdapterClassName(), var1,
				new String[]{"kind", "attribute", "name", "WMMAdapterClassName"});
		this.addAnnotation(this.staticModelTypeEClass, var1,
				new String[]{"name", "staticModel_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getStaticModelType_PackageName(), var1,
				new String[]{"kind", "element", "name", "packageName", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getStaticModelType_UseGlobalSchema(), var1,
				new String[]{"kind", "attribute", "name", "useGlobalSchema"});
		this.addAnnotation(this.subscriberTypeEEnum, var1, new String[]{"name", "SubscriberType"});
		this.addAnnotation(this.subscriberTypeObjectEDataType, var1,
				new String[]{"name", "SubscriberType:Object", "baseType", "SubscriberType"});
		this.addAnnotation(this.supportedEntityTypesTypeEClass, var1,
				new String[]{"name", "supportedEntityTypes_._type", "kind", "elementOnly"});
		this.addAnnotation(this.getSupportedEntityTypesType_RdnProperties(), var1,
				new String[]{"kind", "element", "name", "rdnProperties", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getSupportedEntityTypesType_DefaultParent(), var1,
				new String[]{"kind", "attribute", "name", "defaultParent"});
		this.addAnnotation(this.getSupportedEntityTypesType_Name(), var1,
				new String[]{"kind", "attribute", "name", "name"});
		this.addAnnotation(this.topicEmitterEClass, var1, new String[]{"name", "TopicEmitter", "kind", "elementOnly"});
		this.addAnnotation(this.getTopicEmitter_PreExit(), var1,
				new String[]{"kind", "element", "name", "preExit", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getTopicEmitter_InlineExit(), var1,
				new String[]{"kind", "element", "name", "inlineExit", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getTopicEmitter_PostExit(), var1,
				new String[]{"kind", "element", "name", "postExit", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getTopicEmitter_TopicEmitterName(), var1,
				new String[]{"kind", "attribute", "name", "topicEmitterName"});
		this.addAnnotation(this.topicRegistrationListEClass, var1,
				new String[]{"name", "TopicRegistrationList", "kind", "elementOnly"});
		this.addAnnotation(this.getTopicRegistrationList_TopicEmitter(), var1,
				new String[]{"kind", "element", "name", "topicEmitter", "namespace", "##targetNamespace"});
		this.addAnnotation(this.topicSubscriberEClass, var1,
				new String[]{"name", "TopicSubscriber", "kind", "elementOnly"});
		this.addAnnotation(this.getTopicSubscriber_ClassName(), var1,
				new String[]{"kind", "element", "name", "className", "namespace", "##targetNamespace"});
		this.addAnnotation(this.getTopicSubscriber_TopicSubscriberName(), var1,
				new String[]{"kind", "attribute", "name", "topicSubscriberName"});
		this.addAnnotation(this.getTopicSubscriber_TopicSubscriberType(), var1,
				new String[]{"kind", "attribute", "name", "topicSubscriberType"});
		this.addAnnotation(this.topicSubscriberListEClass, var1,
				new String[]{"name", "TopicSubscriberList", "kind", "elementOnly"});
		this.addAnnotation(this.getTopicSubscriberList_TopicSubscriber(), var1,
				new String[]{"kind", "element", "name", "topicSubscriber", "namespace", "##targetNamespace"});
		this.addAnnotation(this.userRegistryInfoMappingTypeEClass, var1,
				new String[]{"name", "UserRegistryInfoMappingType", "kind", "empty"});
		this.addAnnotation(this.getUserRegistryInfoMappingType_PropertyForInput(), var1,
				new String[]{"kind", "attribute", "name", "propertyForInput"});
		this.addAnnotation(this.getUserRegistryInfoMappingType_PropertyForOutput(), var1,
				new String[]{"kind", "attribute", "name", "propertyForOutput"});
	}
}