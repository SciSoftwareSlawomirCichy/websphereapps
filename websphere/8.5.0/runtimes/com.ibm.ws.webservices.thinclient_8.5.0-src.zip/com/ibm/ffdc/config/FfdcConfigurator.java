package com.ibm.ffdc.config;

import com.ibm.ffdc.impl.Ffdc;

public class FfdcConfigurator {
	public static synchronized void register(DataCollector dc) {
		Ffdc.getProvider().register(dc);
	}

	public static synchronized void deregister(DataCollector dc) {
		Ffdc.getProvider().deregister(dc);
	}

	public static synchronized void register(Formatter f) {
		Ffdc.getProvider().register(f);
	}

	public static synchronized void deregister(Formatter f) {
		Ffdc.getProvider().deregister(f);
	}

	public static synchronized void register(IncidentForwarder f) {
		Ffdc.getProvider().register(f);
	}

	public static synchronized void deregister(IncidentForwarder f) {
		Ffdc.getProvider().deregister(f);
	}

	static {
		new Ffdc();
	}
}