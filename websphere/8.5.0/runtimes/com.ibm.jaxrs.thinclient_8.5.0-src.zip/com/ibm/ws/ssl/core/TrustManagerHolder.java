package com.ibm.ws.ssl.core;

import javax.net.ssl.TrustManager;

public class TrustManagerHolder {
	private TrustManager[] tmArray = null;

	public void setTrustManagers(TrustManager[] tm) {
		this.tmArray = tm;
	}

	public TrustManager[] getTrustManagers() {
		return this.tmArray;
	}
}