package com.ibm.ws.ssl.config;

import com.ibm.ffdc.Manager;
import java.lang.reflect.Method;

public class AdminContextHelper {
	private static Class adminContextClazz = null;
	private static Method pushMethod = null;
	private static Method popMethod = null;
	private static Method peekMethod = null;
	private static final Class thisClass = AdminContextHelper.class;

	public static boolean pushAdminContext(String uuid) {
		try {
			Boolean ret = (Boolean) pushMethod.invoke((Object) null, uuid);
			return ret;
		} catch (Throwable var2) {
			Manager.Ffdc.log(var2, thisClass, "com.ibm.ws.ssl.config.AdminContextHelper.pushAdminContext", "%C");
			return false;
		}
	}

	public static void popAdminContext() {
		try {
			popMethod.invoke((Object) null);
		} catch (Throwable var1) {
			Manager.Ffdc.log(var1, thisClass, "com.ibm.ws.ssl.config.AdminContextHelper.popAdminContext", "%C");
		}

	}

	public static String peekAdminContext() {
		try {
			String ret = (String) peekMethod.invoke((Object) null);
			return ret;
		} catch (Throwable var1) {
			Manager.Ffdc.log(var1, thisClass, "com.ibm.ws.ssl.config.AdminContextHelper.peekAdminContext", "%C");
			return null;
		}
	}

	static {
		try {
			adminContextClazz = Class.forName("com.ibm.websphere.management.AdminContext");
			pushMethod = adminContextClazz.getMethod("push", String.class);
			popMethod = adminContextClazz.getMethod("pop");
			peekMethod = adminContextClazz.getMethod("peek");
		} catch (Throwable var1) {
			;
		}

	}
}