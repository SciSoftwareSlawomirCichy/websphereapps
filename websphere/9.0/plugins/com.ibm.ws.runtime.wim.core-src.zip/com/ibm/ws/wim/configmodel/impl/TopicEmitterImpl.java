package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.PostExit;
import com.ibm.ws.wim.configmodel.PreExit;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class TopicEmitterImpl extends EDataObjectImpl implements TopicEmitter {
	protected PreExit preExit = null;
	protected EList inlineExit = null;
	protected PostExit postExit = null;
	protected static final String TOPIC_EMITTER_NAME_EDEFAULT = null;
	protected String topicEmitterName;

	protected TopicEmitterImpl() {
		this.topicEmitterName = TOPIC_EMITTER_NAME_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getTopicEmitter();
	}

	public PreExit getPreExit() {
		return this.preExit;
	}

	public NotificationChain basicSetPreExit(PreExit var1, NotificationChain var2) {
		PreExit var3 = this.preExit;
		this.preExit = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 0, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setPreExit(PreExit var1) {
		if (var1 != this.preExit) {
			NotificationChain var2 = null;
			if (this.preExit != null) {
				var2 = ((InternalEObject) this.preExit).eInverseRemove(this, -1, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -1, (Class) null, var2);
			}

			var2 = this.basicSetPreExit(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var1, var1));
		}

	}

	public PreExit createPreExit() {
		PreExit var1 = ConfigmodelFactory.eINSTANCE.createPreExit();
		this.setPreExit(var1);
		return var1;
	}

	public InlineExit[] getInlineExitAsArray() {
		List var1 = this.getInlineExit();
		return (InlineExit[]) ((InlineExit[]) var1.toArray(new InlineExit[var1.size()]));
	}

	public List getInlineExit() {
		if (this.inlineExit == null) {
			this.inlineExit = new EObjectContainmentEList(InlineExit.class, this, 1);
		}

		return this.inlineExit;
	}

	public InlineExit createInlineExit() {
		InlineExit var1 = ConfigmodelFactory.eINSTANCE.createInlineExit();
		this.getInlineExit().add(var1);
		return var1;
	}

	public PostExit getPostExit() {
		return this.postExit;
	}

	public NotificationChain basicSetPostExit(PostExit var1, NotificationChain var2) {
		PostExit var3 = this.postExit;
		this.postExit = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 2, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setPostExit(PostExit var1) {
		if (var1 != this.postExit) {
			NotificationChain var2 = null;
			if (this.postExit != null) {
				var2 = ((InternalEObject) this.postExit).eInverseRemove(this, -3, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -3, (Class) null, var2);
			}

			var2 = this.basicSetPostExit(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 2, var1, var1));
		}

	}

	public PostExit createPostExit() {
		PostExit var1 = ConfigmodelFactory.eINSTANCE.createPostExit();
		this.setPostExit(var1);
		return var1;
	}

	public String getTopicEmitterName() {
		return this.topicEmitterName;
	}

	public void setTopicEmitterName(String var1) {
		String var2 = this.topicEmitterName;
		this.topicEmitterName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 3, var2, this.topicEmitterName));
		}

	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return this.basicSetPreExit((PreExit) null, var4);
				case 1 :
					return ((InternalEList) this.getInlineExit()).basicRemove(var1, var4);
				case 2 :
					return this.basicSetPostExit((PostExit) null, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getPreExit();
			case 1 :
				return this.getInlineExit();
			case 2 :
				return this.getPostExit();
			case 3 :
				return this.getTopicEmitterName();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setPreExit((PreExit) var2);
				return;
			case 1 :
				this.getInlineExit().clear();
				this.getInlineExit().addAll((Collection) var2);
				return;
			case 2 :
				this.setPostExit((PostExit) var2);
				return;
			case 3 :
				this.setTopicEmitterName((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setPreExit((PreExit) null);
				return;
			case 1 :
				this.getInlineExit().clear();
				return;
			case 2 :
				this.setPostExit((PostExit) null);
				return;
			case 3 :
				this.setTopicEmitterName(TOPIC_EMITTER_NAME_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.preExit != null;
			case 1 :
				return this.inlineExit != null && !this.inlineExit.isEmpty();
			case 2 :
				return this.postExit != null;
			case 3 :
				return TOPIC_EMITTER_NAME_EDEFAULT == null
						? this.topicEmitterName != null
						: !TOPIC_EMITTER_NAME_EDEFAULT.equals(this.topicEmitterName);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (topicEmitterName: ");
			var1.append(this.topicEmitterName);
			var1.append(')');
			return var1.toString();
		}
	}
}