package com.ibm.ws.security.oidc.client.filter;

public class ContainsCondition extends SimpleCondition {
	public ContainsCondition(String key, IValue value) {
		super(key, value);
	}

	public boolean checkCondition(IValue test) throws FilterException {
		return this.getValue().containedBy(test);
	}

	public String getOperand() {
		return "%=";
	}
}