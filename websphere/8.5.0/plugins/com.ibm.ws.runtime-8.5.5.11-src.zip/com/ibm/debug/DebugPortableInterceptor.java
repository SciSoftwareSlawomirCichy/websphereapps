package com.ibm.debug;

import com.ibm.CORBA.iiop.ExtendedClientRequestInfo;
import com.ibm.CORBA.iiop.ExtendedORBInitInfo;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.orb.transport.ConnectionInformation;
import org.omg.CORBA.LocalObject;
import org.omg.PortableInterceptor.ClientRequestInfo;
import org.omg.PortableInterceptor.ClientRequestInterceptor;
import org.omg.PortableInterceptor.ORBInitInfo;
import org.omg.PortableInterceptor.ORBInitializer;
import org.omg.PortableInterceptor.ORBInitInfoPackage.DuplicateName;

public class DebugPortableInterceptor extends LocalObject implements ORBInitializer, ClientRequestInterceptor {
	private static final long serialVersionUID = -5816149204370478657L;
	private static final TraceComponent tc = Tr.register(DebugPortableInterceptor.class.getName(), "DebugPI");

	public void pre_init(ORBInitInfo initInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "pre_init", initInfo);
		}

		try {
			((ExtendedORBInitInfo) initInfo).add_client_request_interceptor(this, false);
		} catch (DuplicateName var3) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "pre_init already registered");
			}

			return;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "pre_init registered");
		}

	}

	public void post_init(ORBInitInfo initInfo) {
	}

	public void send_request(ClientRequestInfo requestInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "send_request", requestInfo);
		}

		ExtendedClientRequestInfo exci = (ExtendedClientRequestInfo) requestInfo;
		ConnectionInformation ci = (ConnectionInformation) exci.getConnectionData();
		String hostname = ci.getRemoteHost();
		int portnumber = ci.getRemotePort();
		DebugBreakpoints.debugSend_RequestBreakpoint(hostname, portnumber, (long) requestInfo.request_id());
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "send_request");
		}

	}

	public void receive_reply(ClientRequestInfo requestInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "receive_reply", requestInfo);
		}

		DebugBreakpoints.debugReceive_ReplyBreakpoint((long) requestInfo.request_id());
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "send_request");
		}

	}

	public String name() {
		return "com.ibm.debug.DebugPortableInterceptor";
	}

	public void destroy() {
	}

	public void send_poll(ClientRequestInfo info) {
	}

	public void receive_exception(ClientRequestInfo info) {
	}

	public void receive_other(ClientRequestInfo info) {
	}
}