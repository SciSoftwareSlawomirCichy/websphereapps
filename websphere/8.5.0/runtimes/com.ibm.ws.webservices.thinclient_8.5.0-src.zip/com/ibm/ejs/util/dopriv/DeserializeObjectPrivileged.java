package com.ibm.ejs.util.dopriv;

import com.ibm.ws.util.WsObjectInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.security.PrivilegedExceptionAction;

public final class DeserializeObjectPrivileged implements PrivilegedExceptionAction {
	private static final DeserializeObjectPrivileged[] svPool = new DeserializeObjectPrivileged[10];
	private static int svPoolSize = 0;
	public byte[] ivBytesToDeserialize;

	public static DeserializeObjectPrivileged getDeserializeObjectPrivileged() {
		DeserializeObjectPrivileged rtnObj = null;
		DeserializeObjectPrivileged[] var1 = svPool;
		synchronized (svPool) {
			if (svPoolSize > 0) {
				--svPoolSize;
				rtnObj = svPool[svPoolSize];
				svPool[svPoolSize] = null;
			}
		}

		if (rtnObj == null) {
			rtnObj = new DeserializeObjectPrivileged();
		}

		return rtnObj;
	}

	public static void releaseDeserializeObjectPrivileged(DeserializeObjectPrivileged rtnObj) {
		rtnObj.ivBytesToDeserialize = null;
		DeserializeObjectPrivileged[] var1 = svPool;
		synchronized (svPool) {
			if (svPoolSize < svPool.length) {
				svPool[svPoolSize] = rtnObj;
				++svPoolSize;
			}

		}
	}

	public Object run() throws IOException, ClassNotFoundException {
		return this.deserializeObject(this.ivBytesToDeserialize);
	}

	public Object deserializeObject(byte[] bytes) throws IOException, ClassNotFoundException {
		if (bytes == null) {
			return null;
		} else {
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
			ObjectInputStream in = new WsObjectInputStream(bais);
			Object rtnObj = in.readObject();
			return rtnObj;
		}
	}
}