package com.ibm.ejs.cm.portability;

interface package-info {
}