package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_es extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: La parte dependiente (RP) de OpenID no ha podido redireccionar al usuario al proveedor (OP) de OpenID para su autenticación debido a la excepción [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: La parte dependiente (RP) de OpenID no se ha podido inicializar porque no ha podido obtener el SSLContext predeterminado para el servidor WebSphere. La excepción es [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: La parte dependiente (RP) de OpenID no ha podido conectar con el proveedor (OP) de OpenID especificado por el identificador [{0}] debido a la excepción [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: La parte dependiente (RP) de OpenID no se ha podido inicializar debido a la excepción [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: La parte dependiente (RP) de OpenID se ha inicializado porque el valor de la propiedad [{0}] no tiene el formato correcto."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: La parte dependiente (RP) de OpenID no ha podido autenticar una solicitud utilizando la señal Basic Auth porque el valor de la señal no es válido."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: La parte dependiente (RP) de OpenID no se ha podido inicializar porque la propiedad [{0}] no se ha especificado correctamente. Debería ser un URL válido."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: La parte dependiente (RP) de OpenID ha recibido una respuesta incorrecta del proveedor (OP) de OpenID. La causa de este error es [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: La parte dependiente (RP) de OpenID no ha podido realizar la autenticación porque ha alcanzado la capacidad máxima de su memoria caché interna."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: La parte dependiente (RP) de OpenID no se ha podido inicializar porque falta la propiedad obligatoria axRequiredAttribute[n]. Es necesario definir al menos una propiedad."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: La parte dependiente (RP) de OpenID no se ha podido inicializar porque falta el valor de la propiedad obligatoria [{0}] o está vacío."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: La parte dependiente (RP) de OpenID requiere SSL (HTTPS) pero el URL del proveedor (OP) de OpenID es HTTP: [{0}].  El atributo [{1}] debería coincidir con el esquema del URL de destino. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: La parte dependiente (RP) de OpenID ha recibido una respuesta del proveedor (OP) de OpenID que no soporta la versión 2 de la especificación de OpenID."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: La parte dependiente (RP) de OpenID no ha podido verificar la respuesta recibida del proveedor (OP) de OpenID. La excepción era [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}