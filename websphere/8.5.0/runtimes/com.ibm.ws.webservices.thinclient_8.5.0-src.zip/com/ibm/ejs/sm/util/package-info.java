package com.ibm.ejs.sm.util;

interface package-info {
}