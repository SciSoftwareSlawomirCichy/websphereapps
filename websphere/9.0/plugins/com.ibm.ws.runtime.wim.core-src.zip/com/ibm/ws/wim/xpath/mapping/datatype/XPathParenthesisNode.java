package com.ibm.ws.wim.xpath.mapping.datatype;

public interface XPathParenthesisNode extends XPathNode {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";

	void setChild(Object var1);

	Object getChild();

	void setPropertyLocation(boolean var1);

	boolean isPropertyInRepository();
}