package com.ibm.ws.wim;

import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.EnvironmentManager.1;
import com.ibm.ws.wim.management.DynamicReloadManager;
import java.security.AccessController;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.Notification;
import javax.management.NotificationFilterSupport;
import javax.management.NotificationListener;
import javax.management.ObjectName;
import javax.management.QueryExp;

public class EnvironmentManager implements NotificationListener {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	public static final String CLASSNAME = EnvironmentManager.class.getName();
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static EnvironmentManager singleton;
	private boolean isServerStarted = false;
	private boolean isZOSPlatform = false;
	public static boolean isServerUp;

	private EnvironmentManager() {
		this.initialize();
	}

	public static synchronized EnvironmentManager singleton() {
		if (singleton == null) {
			singleton = new EnvironmentManager();
		}

		return singleton;
	}

	private void initialize() {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize");
		}

		String var2 = System.getProperty("os.name");
		if (var2.equalsIgnoreCase("z/OS") || var2.equalsIgnoreCase("OS/390")) {
			this.isZOSPlatform = true;
		}

		try {
			AdminService var3 = this.getAdminService();
			if (var3 != null) {
				String var4 = var3.getProcessType();
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "initialize", "processType is " + var4);
				}

				ObjectName var5 = new ObjectName("WebSphere:type=Server,*");
				Set var6 = var3.queryNames(var5, (QueryExp) null);
				String var8;
				if (!var6.isEmpty()) {
					ObjectName var7 = (ObjectName) var6.iterator().next();
					var8 = (String) var3.getAttribute(var7, "state");
					if ("STARTED".equals(var8)) {
						this.isServerStarted = true;
						isServerUp = this.isServerStarted;
					}
				}

				NotificationFilterSupport var10 = new NotificationFilterSupport();
				var10.enableType("j2ee.state.running");
				var8 = null;
				ObjectName var11 = new ObjectName("WebSphere:*,type=Server");
				var3.addNotificationListenerExtended(var11, this, var10, (Object) null);
			} else {
				msgLogger.logp(Level.WARNING, CLASSNAME, "initialize", "ADMIN_SERVICE_REGISTRATION_FAILED");
			}
		} catch (Exception var9) {
			msgLogger.logp(Level.WARNING, CLASSNAME, "initialize", "ADMIN_SERVICE_REGISTRATION_FAILED", var9);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize", "isServerStarted=" + this.isServerStarted);
		}

	}

	private boolean isServerStartedProcess(String var1) {
		boolean var3 = false;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isServerStartedProcess");
		}

		if (var1.equals("ManagedProcess") || var1.equals("DeploymentManager") || var1.equals("UnManagedProcess")) {
			var3 = true;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isServerStartedProcess", "result=" + var3);
		}

		return var3;
	}

	public void handleNotification(Notification var1, Object var2) {
		if (var1.getType().equals("j2ee.state.running")) {
			this.isServerStarted = true;
			isServerUp = this.isServerStarted;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "handleNotification", "server started.");
			}
		}

	}

	private void checkZOSServerStatus() {
		if (this.isZOSPlatform) {
			try {
				this.getAdminService();
			} catch (Exception var2) {
				var2.printStackTrace();
			}
		}

	}

	public boolean isDirectAccessMode() {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isDirectAccessMode");
		}

		boolean var2 = false;

		try {
			if (this.isZOSPlatform) {
				this.checkZOSServerStatus();
			}

			if (this.isNodeAgent() || this.isZOSControlRegion() || !this.isServerStarted) {
				var2 = true;
			}
		} catch (Exception var4) {
			var2 = true;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isDirectAccessMode", "isDirectAccessMode=" + var2);
		}

		return var2;
	}

	public boolean isZOSControlRegion() {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isZOSControlRegion");
		}

		boolean var2 = false;
		if (this.isZOSPlatform) {
			AdminService var3 = this.getAdminService();
			if (var3 != null) {
				String var4 = var3.getJvmType();
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "isZOSControlRegion", "JVMType is " + var4);
				}

				if (var4 != null && var4.equals("Control")) {
					var2 = true;
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isZOSControlRegion", "isZOSControlRegion=" + var2);
		}

		return var2;
	}

	public boolean isNodeAgent() {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isNodeAgent");
		}

		boolean var2 = false;
		AdminService var3 = this.getAdminService();
		String var4 = var3.getProcessType();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "isNodeAgent", "processType is " + var4);
		}

		if (var4 != null && var4.equals("NodeAgent")) {
			var2 = true;
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isNodeAgent", "isNodeAgent=" + var2);
		}

		return var2;
	}

	public boolean isZOSPlatform() {
		return this.isZOSPlatform;
	}

	public AdminService getAdminService() {
      return (AdminService)AccessController.doPrivileged(new 1(this));
   }

	public boolean isAminServiceAvailable() {
		return this.getAdminService() != null;
	}

	public boolean isSchemaUpdateNotAllowed() {
		return !DynamicReloadManager.isConnectionTypeNone() && !DynamicReloadManager.isRunningOnDeploymentManager()
				&& !DynamicReloadManager.isRunningOnSingleServer() && !DynamicReloadManager.isRunningOnAdminAgent()
				&& !DynamicReloadManager.isRunningOnJobManager();
	}

	public boolean isConfigUpdateNotAllowed() {
		return !DynamicReloadManager.isRunningOnDeploymentManager() && !DynamicReloadManager.isRunningOnSingleServer()
				&& !DynamicReloadManager.isRunningOnAdminAgent() && !DynamicReloadManager.isRunningOnJobManager();
	}

	public static boolean getWASServerStatus() {
		return isServerUp;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
		singleton = null;
		isServerUp = false;
	}
}