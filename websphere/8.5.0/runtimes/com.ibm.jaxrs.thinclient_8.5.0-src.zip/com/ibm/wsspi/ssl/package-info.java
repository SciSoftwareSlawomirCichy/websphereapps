package com.ibm.wsspi.ssl;

interface package-info {
}