package com.ibm.ejs.cm.portability;

import java.sql.SQLException;

final class TableDoesNotExistException extends PortableSQLException {
	private static final long serialVersionUID = 6022234606879936328L;

	TableDoesNotExistException(SQLException nativeException) {
		super(nativeException);
	}

	TableDoesNotExistException() {
	}
}