package com.ibm.ejs.container;

import com.ibm.ejs.container.passivator.PassivatorSerializable;
import com.ibm.ejs.container.passivator.PassivatorSerializableHandle;
import com.ibm.ejs.csi.EJBApplicationMetaData;
import com.ibm.ejs.csi.EJBModuleMetaDataImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ejbcontainer.util.ParsedScheduleExpression;
import com.ibm.ws.ejbcontainer.util.ScheduleExpressionParser;
import com.ibm.ws.runtime.metadata.ModuleMetaData;
import com.ibm.ws.util.UUID;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.ejb.EJBException;
import javax.ejb.NoMoreTimeoutsException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.ScheduleExpression;
import javax.ejb.Timer;
import javax.ejb.TimerHandle;

public final class TimerNpImpl implements Timer, PassivatorSerializable {
	private static final TraceComponent tc = Tr.register(TimerNpImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final Map<String, TimerNpImpl> svActiveTimers = new LinkedHashMap();
	protected String ivTaskId;
	private static long ivTaskSeqNo = 0L;
	private final EJSContainer ivContainer;
	private final BeanId ivBeanId;
	private final BeanMetaData ivBMD;
	int ivMethodId;
	private Serializable ivInfo;
	private long ivExpiration;
	private long ivInterval;
	private ParsedScheduleExpression ivParsedScheduleExpression;
	private volatile boolean ivDestroyed;
	Thread ivTimeoutThread;
	private long ivLastExpiration;
	private TimerNpRunnable ivTaskHandler;

	private TimerNpImpl(EJSContainer container, BeanMetaData bmd, BeanId beanId, Serializable info) {
		this.ivTaskId = "_NP";
		this.ivDestroyed = false;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			String infoClassName = info == null ? null : info.getClass().getName();
			Tr.entry(tc, "TimerNpImpl : " + beanId + ", " + infoClassName);
		}

		this.ivContainer = container;
		this.ivBMD = bmd;
		this.ivBeanId = beanId;
		this.ivInfo = this.ivContainer.ivObjectCopier.copy(info);
		this.ivTaskId = incrementTaskSeqNo();
	}

	public TimerNpImpl(BeanId beanId, Date expiration, long interval, Serializable info) {
		this(((EJSHome) beanId.home).container, ((EJSHome) beanId.home).beanMetaData, beanId, info);
		this.ivExpiration = expiration.getTime();
		this.ivInterval = interval;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, this.toString());
		}

	}

	private TimerNpImpl(BeanId beanId, String taskId) {
		this.ivTaskId = "_NP";
		this.ivDestroyed = false;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "TimerNpImpl : " + beanId + ", " + taskId);
		}

		this.ivContainer = ((EJSHome) beanId.home).container;
		this.ivTaskId = taskId;
		this.ivBMD = ((EJSHome) beanId.home).beanMetaData;
		this.ivBeanId = beanId;
		this.ivDestroyed = true;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, this.toString());
		}

	}

	public TimerNpImpl(EJSContainer container, BeanMetaData bmd, BeanId beanId, int methodId,
			ParsedScheduleExpression parsedExpr, Serializable info) {
		this(container, bmd, beanId, info);
		this.ivMethodId = methodId;
		this.ivExpiration = Math.max(0L, parsedExpr.getFirstTimeout());
		this.ivParsedScheduleExpression = parsedExpr;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, this.toString());
		}

	}

	public TimerNpImpl(BeanId beanId, ParsedScheduleExpression parsedExpr, Serializable info) {
		this(((EJSHome) beanId.home).container, ((EJSHome) beanId.home).beanMetaData, beanId, 0, parsedExpr, info);
	}

	String getTaskId() {
		return this.ivTaskId;
	}

	private static synchronized String incrementTaskSeqNo() {
		++ivTaskSeqNo;
		String taskId = ivTaskSeqNo + "_NP_" + new UUID();
		return taskId;
	}

	public BeanId getIvBeanId() {
		return this.ivBeanId;
	}

	boolean isIvDestroyed() {
		return this.ivDestroyed;
	}

	public void start() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "start: " + this);
		}

		EJBModuleMetaDataImpl ejbModuleMetaData = this.ivBMD._moduleMetaData;
		EJBApplicationMetaData ejbAmd = ejbModuleMetaData.getEJBApplicationMetaData();
		synchronized (this) {
			if (ejbAmd.isStopping()) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "start: not started - application stop");
				}

				this.ivDestroyed = true;
				return;
			}

			if (this.ivDestroyed || this.ivExpiration == 0L) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "start: not started - destroyed = " + this.ivDestroyed + ", expiration = "
							+ this.ivExpiration);
				}

				return;
			}

			Map var5 = svActiveTimers;
			synchronized (svActiveTimers) {
				svActiveTimers.put(this.ivTaskId, this);
			}
		}

		boolean queuedOrStarted = ejbAmd.queueOrStartNonPersistentTimerAlarm(this, ejbModuleMetaData);
		if (!queuedOrStarted) {
			this.remove(true);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "start");
		}

	}

	public synchronized void schedule() {
		if (this.ivTaskHandler == null && !this.ivDestroyed) {
			this.ivTaskHandler = this.ivContainer.getEJBRuntime().createNonPersistentTimerTaskHandler(this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"schedule: scheduling timer for " + this.ivExpiration + " / " + new Date(this.ivExpiration));
			}

			this.ivTaskHandler.schedule(this.ivExpiration);
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "schedule: timer already scheduled or destroyed : destroyed=" + this.ivDestroyed);
		}

	}

	synchronized long calculateNextExpiration() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "calculateNextExpiration: " + this);
		}

		this.ivLastExpiration = this.ivExpiration;
		if (this.ivParsedScheduleExpression != null) {
			this.ivExpiration = Math.max(0L, this.ivParsedScheduleExpression.getNextTimeout(this.ivExpiration));
		} else if (this.ivInterval > 0L) {
			this.ivExpiration += this.ivInterval;
		} else {
			this.ivExpiration = 0L;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "calculateNextExpiration: " + this.ivExpiration);
		}

		return this.ivExpiration;
	}

	synchronized void scheduleNext() {
		if (!this.ivDestroyed) {
			if (this.ivExpiration != 0L) {
				if (this.ivTaskHandler != null) {
					this.ivTaskHandler.scheduleNext(this.ivExpiration);
				} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "scheduleNext: not scheduled, timer in cancelled state : " + this.ivTaskId);
				}
			} else {
				this.remove(true);
			}
		}

	}

	synchronized void scheduleRetry(long retryInterval) {
		if (!this.ivDestroyed) {
			if (this.ivTaskHandler != null) {
				this.ivTaskHandler.scheduleRetry(retryInterval);
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "scheduleRetry: not scheduled, timer in cancelled state : " + this.ivTaskId);
				}

				this.ivExpiration = this.ivLastExpiration;
			}
		}

	}

	private void checkIfCancelled() {
		if (this.ivDestroyed && this.ivTimeoutThread != Thread.currentThread()) {
			String msg = "Timer with ID " + this.ivTaskId + " has been canceled.";
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkIfCancelled: NoSuchObjectLocalException : " + msg);
			}

			throw new NoSuchObjectLocalException(msg);
		} else {
			ContainerTx tx = this.ivContainer.getCurrentContainerTx();
			if (tx != null && tx.timersCanceled != null && tx.timersCanceled.containsValue(this)) {
				String msg = "Timer with ID " + this.ivTaskId + " has been canceled in the current transaction.";
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkIfCancelled: NoSuchObjectLocalException : " + msg);
				}

				throw new NoSuchObjectLocalException(msg);
			}
		}
	}

	void checkLateTimerThreshold() {
		this.ivContainer.getEJBRuntime().checkLateTimerThreshold(new Date(this.ivLastExpiration), this.ivTaskId,
				this.ivBeanId.j2eeName);
	}

	public void cancel() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "cancel: " + this);
		}

		this.checkTimerAccess();
		this.checkIfCancelled();
		ContainerTx tx = this.ivContainer.getCurrentContainerTx();
		if (tx != null) {
			boolean queuedToStart = tx.timersQueuedToStart != null
					? tx.timersQueuedToStart.remove(this.ivTaskId) != null
					: false;
			if (queuedToStart) {
				this.remove(true);
			} else {
				this.remove(false);
				if (tx.timersCanceled == null) {
					tx.timersCanceled = new LinkedHashMap();
				}

				tx.timersCanceled.put(this.ivTaskId, this);
			}
		} else {
			this.remove(true);
		}

		if (this.ivTimeoutThread == Thread.currentThread()) {
			this.ivTimeoutThread = null;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "cancel: successful");
		}

	}

	public long getTimeRemaining() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		Date nextTime = this.getNextTimeout();
		long currentTime = System.currentTimeMillis();
		long remaining = nextTime.getTime() - currentTime;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getTimeRemaining: " + remaining);
		}

		return remaining;
	}

	public Date getNextTimeout()
			throws IllegalStateException, NoSuchObjectLocalException, EJBException, NoMoreTimeoutsException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getNextTimeout: " + this);
		}

		this.checkTimerAccess();
		this.checkIfCancelled();
		Date nextTime;
		if (this.ivExpiration == 0L) {
			if (this.ivParsedScheduleExpression != null) {
				String msg;
				if (this.ivTimeoutThread == Thread.currentThread()) {
					msg = "Timer with ID " + this.ivTaskId + " has no more timeouts.";
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "getNextTimeout: NoMoreTimeoutsException : " + msg);
					}

					throw new NoMoreTimeoutsException(msg);
				} else {
					msg = "Timer with ID " + this.ivTaskId + " was created with no scheduled timeouts.";
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "getNextTimeout: NoSuchObjectLocalException : no expirations : " + msg);
					}

					throw new NoSuchObjectLocalException(msg);
				}
			} else {
				nextTime = new Date(this.ivLastExpiration);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "getNextTimeout: no timeouts : " + nextTime);
				}

				return nextTime;
			}
		} else if (this.ivTimeoutThread != null && this.ivTimeoutThread != Thread.currentThread()) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getNextTimeout: non firing thread : " + new Date(this.ivLastExpiration));
			}

			return new Date(this.ivLastExpiration);
		} else {
			nextTime = new Date(this.ivExpiration);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getNextTimeout: " + nextTime);
			}

			return nextTime;
		}
	}

	public Serializable getInfo() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getInfo: " + this);
		}

		this.checkTimerAccess();
		this.checkIfCancelled();
		Serializable info = this.ivContainer.ivObjectCopier.copy(this.ivInfo);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getInfo: " + Util.identity(info));
		}

		return info;
	}

	public TimerHandle getHandle() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		throw new IllegalStateException("getHandle method not allowed on non-persistent timers.");
	}

	public boolean isCalendarTimer() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCalendarTimer: " + this);
		}

		this.checkTimerAccess();
		this.checkIfCancelled();
		boolean result = this.ivParsedScheduleExpression != null;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isCalendarTimer: " + result);
		}

		return result;
	}

	public ScheduleExpression getSchedule() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getSchedule: " + this);
		}

		this.checkTimerAccess();
		this.checkIfCancelled();
		if (!this.isCalendarTimer()) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getSchedule: IllegalStateException : Timer is not a calendar-based timer");
			}

			throw new IllegalStateException("Timer is not a calendar-based timer");
		} else {
			ScheduleExpression result = this.ivContainer.ivObjectCopier
					.copy(this.ivParsedScheduleExpression.getSchedule());
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getSchedule: " + ScheduleExpressionParser.toString(result));
			}

			return result;
		}
	}

	public boolean isPersistent() {
		this.checkTimerAccess();
		this.checkIfCancelled();
		return false;
	}

	protected void remove(boolean destroy) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "remove(destroy=" + destroy + ") : " + this);
		}

		synchronized (this) {
			Map var4 = svActiveTimers;
			synchronized (svActiveTimers) {
				svActiveTimers.remove(this.ivTaskId);
			}

			if (destroy) {
				this.ivDestroyed = true;
			}

			if (this.ivTaskHandler != null) {
				this.ivTaskHandler.cancel();
				this.ivTaskHandler = null;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "remove");
		}

	}

	public static Collection<Timer> findTimersByBeanId(BeanId beanId, ContainerTx tx) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "findTimersByBeanId: " + beanId);
		}

		int numActive = false;
		ArrayList<Timer> timers = new ArrayList();
		Map var5 = svActiveTimers;
		int numActive;
		synchronized (svActiveTimers) {
			Iterator i$ = svActiveTimers.values().iterator();

			while (i$.hasNext()) {
				TimerNpImpl npTimer = (TimerNpImpl) i$.next();
				if (npTimer.ivBeanId.equals(beanId)) {
					timers.add(npTimer);
				}
			}

			numActive = svActiveTimers.size();
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "findTimersByBeanId: " + timers.size() + "(of " + numActive + " active)");
		}

		return timers;
	}

	public static Collection<Timer> findTimersByModule(ModuleMetaData mmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "findTimersByModule: " + mmd);
		}

		int numActive = false;
		ArrayList<Timer> timers = new ArrayList();
		Map var4 = svActiveTimers;
		int numActive;
		synchronized (svActiveTimers) {
			Iterator i$ = svActiveTimers.values().iterator();

			while (i$.hasNext()) {
				TimerNpImpl npTimer = (TimerNpImpl) i$.next();
				if (npTimer.ivBMD.getModuleMetaData() == mmd) {
					timers.add(npTimer);
				}
			}

			numActive = svActiveTimers.size();
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "findTimersByModule: " + timers.size() + "(of " + numActive + " active)");
		}

		return timers;
	}

	public static void removeTimersByJ2EEName(J2EEName j2eeName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "removeTimersByJ2EEName: " + j2eeName);
		}

		Collection<TimerNpImpl> timersToRemove = null;
		Map var3 = svActiveTimers;
		synchronized (svActiveTimers) {
			if (svActiveTimers.size() > 0) {
				String appToRemove = j2eeName.getApplication();
				String modToRemove = j2eeName.getModule();
				Iterator i$ = svActiveTimers.values().iterator();

				label65 : while (true) {
					TimerNpImpl timer;
					J2EEName timerJ2EEName;
					do {
						do {
							if (!i$.hasNext()) {
								break label65;
							}

							timer = (TimerNpImpl) i$.next();
							timerJ2EEName = timer.ivBeanId.j2eeName;
						} while (!appToRemove.equals(timerJ2EEName.getApplication()));
					} while (modToRemove != null && !modToRemove.equals(timerJ2EEName.getModule()));

					if (timersToRemove == null) {
						timersToRemove = new ArrayList();
					}

					timersToRemove.add(timer);
				}
			}
		}

		if (timersToRemove != null) {
			Iterator i$ = timersToRemove.iterator();

			while (i$.hasNext()) {
				TimerNpImpl timer = (TimerNpImpl) i$.next();
				timer.remove(true);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "removeTimersByJ2EEName: removed " + (timersToRemove != null ? timersToRemove.size() : 0));
		}

	}

	protected void checkTimerAccess() throws IllegalStateException {
		BeanO beanO = EJSContainer.getCallbackBeanO();
		if (beanO != null) {
			beanO.checkTimerServiceAccess();
		} else {
			if (!this.ivContainer.allowTimerAccessOutsideBean) {
				IllegalStateException ise = new IllegalStateException(
						"Timer: Timer methods not allowed - no active EJB");
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkTimerAccess: " + ise);
				}

				throw ise;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerAccess: Timer access permitted outside of bean");
			}
		}

	}

	public PassivatorSerializableHandle getSerializableObject() {
		TimerNpHandleImpl timerHandle = new TimerNpHandleImpl(this.ivBeanId, this.ivTaskId);
		return timerHandle;
	}

	protected static Timer getDeserializedTimer(BeanId beanId, String taskId) {
		Map var3 = svActiveTimers;
		Timer timer;
		synchronized (svActiveTimers) {
			timer = (Timer) svActiveTimers.get(taskId);
			if (timer != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getDeserializedTimer: found in active timer map : " + timer);
				}

				return timer;
			}
		}

		EJSHome home = (EJSHome) beanId.home;
		ContainerTx containerTx = home.container.getCurrentContainerTx();
		if (containerTx != null) {
			if (containerTx.timersQueuedToStart != null) {
				timer = (Timer) containerTx.timersQueuedToStart.get(taskId);
				if (timer != null) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "getDeserializedTimer: found in timersQueuedToStart : " + timer);
					}

					return timer;
				}
			}

			if (containerTx.timersCanceled != null) {
				timer = (Timer) containerTx.timersCanceled.get(taskId);
				if (timer != null) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "getDeserializedTimer: found in timersCanceled : " + timer);
					}

					return timer;
				}
			}
		}

		Timer timer = new TimerNpImpl(beanId, taskId);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getDeserializedTimer: not found - returning destroyed Timer : " + timer);
		}

		return timer;
	}

	public boolean equals(Object obj) {
		if (obj instanceof TimerNpImpl) {
			TimerNpImpl timer = (TimerNpImpl) obj;
			return this.ivTaskId.equals(timer.ivTaskId);
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.ivTaskId.hashCode();
	}

	public String toString() {
		return "TimerNpImpl(" + this.ivTaskId + ", " + this.ivBeanId + ", " + this.ivExpiration + ", " + this.ivInterval
				+ ", " + this.ivDestroyed + ", " + Util.identity(this.ivInfo) + ")";
	}
}