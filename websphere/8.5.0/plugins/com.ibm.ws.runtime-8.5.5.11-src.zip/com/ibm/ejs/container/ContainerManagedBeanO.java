package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.cpi.CPIException;
import com.ibm.websphere.cpi.Persister;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EnterpriseBean;
import javax.ejb.ObjectNotFoundException;
import javax.ejb.RemoveException;
import javax.ejb.TimerService;

public class ContainerManagedBeanO extends EntityBeanOImpl {
	private static final TraceComponent tc = Tr.register(ContainerManagedBeanO.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final TraceComponent tcClntInfo = Tr.register("WAS.clientinfopluslogging",
			"WAS.clientinfopluslogging", (String) null);
	private static final String CLASS_NAME = "com.ibm.ejs.container.ContainerManagedBeanO";
	protected boolean ivStored = false;
	protected Persister persister;
	private Object[] ivDataCache = null;
	private boolean ivLoadForUpdate = false;
	private boolean inLoadMethodForUpdate = false;
	private int dataCacheLength = 0;
	private int dataCacheCounter = 0;
	private int ivModuleVersion;

	public ContainerManagedBeanO(EJSContainer c, EnterpriseBean b, EJSHome h) {
		super(c, b, h);
		this.persister = h.beanMetaData.persister;
		this.ivModuleVersion = h.beanMetaData.ivModuleVersion;
	}

	public final void commit(ContainerTx tx) throws RemoteException {
		this.ivDataCache = null;
		this.dataCacheCounter = 0;
		super.commit(tx);
	}

	public final void rollback(ContainerTx tx) throws RemoteException {
		this.ivDataCache = null;
		this.dataCacheCounter = 0;
		super.rollback(tx);
	}

	public final void setDataCache(Object[] data) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "setDataCache");
		}

		this.ivDataCache = data;
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "the length of optimistic data array on setDataCache is  " + data.length + "    ", this);
		}

		this.dataCacheLength = data.length;
		++this.dataCacheCounter;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "setDataCache");
		}

	}

	public final Object[] getDataCache() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getDataCache");
		}

		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "the length of optimistic data array on getDataCache " + this.dataCacheLength, this);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getDataCache");
		}

		return this.ivDataCache;
	}

	public void setCMP11LoadedForUpdate(EJSDeployedSupport s, ContainerTx ctx) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "setCMP11LoadedForUpdate:" + this.ivLoadForUpdate + " " + this.toString());
		}

		String customFinderMethodName = null;
		boolean customFinderHonorRWAI = false;
		boolean updateAccessIntent = false;
		boolean stateInfoViaDeployedSupport = true;
		CMP11CustomFinderAccIntentState cfThreadAIState = this.container.getCustomFinderAccessIntentThreadState();
		if (cfThreadAIState != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "CF Access Intent State Present:" + cfThreadAIState.toString());
			}

			customFinderMethodName = cfThreadAIState.methodName;
			customFinderHonorRWAI = cfThreadAIState.customFinderWithUpdateIntent;
			updateAccessIntent = cfThreadAIState.readOnlyAttr;
			stateInfoViaDeployedSupport = false;
		} else {
			if (s.methodInfo == null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Deployed Support Not Null, MethodInfo null");
				}

				return;
			}

			customFinderHonorRWAI = s.methodInfo.getIsCMP11CustomFinderWithForUpdateAI();
			customFinderMethodName = s.methodInfo.getMethodName();
			updateAccessIntent = s.methodInfo.getReadOnlyAttribute();
		}

		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "method:" + customFinderMethodName + " CF w/RW AI:" + customFinderHonorRWAI + " read-only:"
					+ updateAccessIntent + " Via Deployed Support " + stateInfoViaDeployedSupport);
		}

		if (!customFinderHonorRWAI) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc,
						"Method not custom finder with update access intent, ivLoadForUpdate:" + this.ivLoadForUpdate);
			}

		} else {
			this.ivLoadForUpdate = !updateAccessIntent;

			try {
				boolean DBSupportsForUpdate = false;
				DBSupportsForUpdate = this.persister.dbSupportsSelectForUpdate();
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "DBFU:" + DBSupportsForUpdate);
				}

				if (!DBSupportsForUpdate) {
					this.ivLoadForUpdate = false;
				}
			} catch (Exception var10) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "WARNING Exception received while checking if database supports For Update:" + var10);
				}
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "ivLoadForUpdate:" + this.ivLoadForUpdate);
				if (ctx != null) {
					Tr.debug(tc, " Tx:" + ctx + " Gbl: " + ctx.isTransactionGlobal());
				}
			}

			if (this.ivModuleVersion == 11) {
				this.ivLoadForUpdate = ctx != null && ctx.isTransactionGlobal() && this.ivLoadForUpdate;
			} else {
				this.ivLoadForUpdate = ctx != null && this.ivLoadForUpdate;
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "setCustomFinderSetLoadedForUpdate ivloadForUpdate:" + this.ivLoadForUpdate);
			}

		}
	}

	public boolean getivLoadForUpdate() {
		return this.ivLoadForUpdate;
	}

	public void setCMP11LoadedForUpdate(boolean loadForUpdate) {
		this.ivLoadForUpdate = loadForUpdate;
	}

	public boolean getCalledFromLoadMethodForUpdate() {
		return this.inLoadMethodForUpdate;
	}

	public EnterpriseBean getEnterpriseBean() throws RemoteException {
		this.assertState(1);
		return this.entityBean;
	}

	public final synchronized void postCreate(boolean supportEjbPostCreateChanges)
			throws CreateException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "postCreate");
		}

		this.ivLoadForUpdate = true;

		try {
			this.setState(1, 2);
			if (!supportEjbPostCreateChanges) {
				this.persister.setContextData(this);
				this.persister.create(this.entityBean);
				this.persister.setContextData((EntityBeanO) null);
			}
		} catch (CreateException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.container.ContainerManagedBeanO.postCreate", "287", this);
			throw var9;
		} catch (RemoteException var10) {
			FFDCFilter.processException(var10, "com.ibm.ejs.container.ContainerManagedBeanO.postCreate", "292", this);
			this.destroy();
			throw var10;
		} catch (Exception var11) {
			FFDCFilter.processException(var11, "com.ibm.ejs.container.ContainerManagedBeanO.postCreate", "298", this);
			this.destroy();
			throw new CPIException(var11);
		} finally {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "postCreate");
			}

		}

	}

	public final synchronized void afterPostCreate() throws CreateException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "afterPostCreate");
		}

		try {
			this.persister.setContextData(this);
			this.persister.create(this.entityBean);
			this.persister.setContextData((EntityBeanO) null);
		} catch (CreateException var8) {
			FFDCFilter.processException(var8, "com.ibm.ejs.container.ContainerManagedBeanO.afterPostCreate", "345",
					this);
			throw var8;
		} catch (RemoteException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.container.ContainerManagedBeanO.afterPostCreate", "351",
					this);
			this.destroy();
			throw var9;
		} catch (Exception var10) {
			FFDCFilter.processException(var10, "com.ibm.ejs.container.ContainerManagedBeanO.afterPostCreate", "358",
					this);
			this.destroy();
			throw new CPIException(var10);
		} finally {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "afterPostCreate");
			}

		}

	}

	public final void store() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "store : " + this);
		}

		if (this.dirty && !this.inCreate && !this.inStore && this.state != 8) {
			long pmiCookie = -1L;
			BeanOCallDispatchToken smfDispatchToken = null;
			int savedState = this.state;
			switch (this.state) {
				case 6 :
				case 7 :
					this.setState(10);
					this.inStore = true;
					this.ivStored = true;
					boolean lvSetContextData = false;

					try {
						if (this.pmiBean != null) {
							pmiCookie = this.pmiBean.storeTime();
						}

						if (this.ivDataCache == null) {
							if (!this.cachedExclusive) {
								this.persister.checkCMPStoreOperation(this.beanId, this.ivLoadForUpdate);
							}
						} else {
							if (this.dataCacheCounter != 1 && isTraceOn && tc.isEventEnabled()) {
								Tr.event(tc, "@@@@ dataCacheCounter is not expected 1,  actual value is   "
										+ this.dataCacheCounter);
							}

							if (this.dataCacheLength != this.ivDataCache.length && isTraceOn && tc.isEventEnabled()) {
								Tr.event(tc, "@@@@ expected dataCacheLength is " + this.dataCacheLength
										+ "  , actual length is " + this.ivDataCache.length);
							}

							lvSetContextData = true;
						}

						if (isTraceOn) {
							if (tcClntInfo.isDebugEnabled()) {
								Tr.debug(tcClntInfo, "ejbStore");
							}

							if (TEBeanLifeCycleInfo.isTraceEnabled()) {
								TEBeanLifeCycleInfo.traceEJBCallEntry("ejbStore");
							}
						}

						if (isZOS) {
							smfDispatchToken = this.callDispatchEventListeners(8, (BeanOCallDispatchToken) null);
						}

						this.entityBean.ejbStore();
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallExit("ejbStore");
						}

						if (lvSetContextData) {
							this.persister.setContextData(this);
						}

						this.persister.store(this.entityBean);
						if (this.ivDataCache != null && this.callDepth > 0 && this.ivContainerTx != null) {
							this.load(this.ivContainerTx, false);
						}
					} catch (RemoteException var12) {
						FFDCFilter.processException(var12, "com.ibm.ejs.container.ContainerManagedBeanO.store", "461",
								this);
						this.destroy();
						throw var12;
					} catch (Exception var13) {
						FFDCFilter.processException(var13, "com.ibm.ejs.container.ContainerManagedBeanO.store", "472",
								this);
						this.destroy();
						throw new CPIException(var13);
					} finally {
						if (smfDispatchToken != null) {
							this.callDispatchEventListeners(9, smfDispatchToken);
						}

						this.persister.setContextData((EntityBeanO) null);
						if (pmiCookie != -1L) {
							this.pmiBean.storeTime(pmiCookie);
						}

						this.inStore = false;
					}

					if (savedState == 6) {
						this.dirty = false;
					}

					this.setState(savedState);
					break;
				default :
					throw new InvalidBeanOStateException(this.stateStrs[this.state], "ACTIVE | IN_METHOD");
			}
		} else if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "Not Storing: dirty = " + this.dirty + ", inCreate = " + this.inCreate + ", inStore = "
					+ this.inStore, this);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "store : " + this);
		}

	}

	public final synchronized void remove() throws RemoteException, RemoveException {
		super.remove();

		try {
			this.persister.setContextData(this);
			this.persister.remove(this.entityBean);
			this.ivDataCache = null;
			this.dataCacheCounter = 0;
			this.persister.setContextData((EntityBeanO) null);
		} catch (RemoteException var2) {
			FFDCFilter.processException(var2, "com.ibm.ejs.container.ContainerManagedBeanO.remove", "535", this);
			throw var2;
		} catch (Exception var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.ContainerManagedBeanO.remove", "540", this);
			throw new CPIException(var3);
		}
	}

	public void hydrate(Persister p, Object data, Object pkey, BeanId id) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "hydrate: " + this.toString());
		}

		synchronized (this) {
			this.beanId = id;
			long pmiCookie = -1L;
			if (this.pmiBean != null) {
				pmiCookie = this.pmiBean.activationTime();
			}

			BeanOCallDispatchToken smfDispatchToken = null;

			try {
				if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
					TEBeanLifeCycleInfo.traceEJBCallEntry("ejbActivate");
				}

				if (isZOS) {
					smfDispatchToken = this.callDispatchEventListeners(2, (BeanOCallDispatchToken) null);
				}

				this.entityBean.ejbActivate();
			} finally {
				if (smfDispatchToken != null) {
					this.callDispatchEventListeners(3, smfDispatchToken);
				}

				if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
					TEBeanLifeCycleInfo.traceEJBCallExit("ejbActivate");
				}

				if (this.pmiBean != null) {
					this.pmiBean.activationTime(pmiCookie);
				}

			}

			try {
				p.setContextData(this);
				p.hydrate(this.entityBean, data, pkey);
				this.persister.setContextData((EntityBeanO) null);
			} catch (Exception var15) {
				FFDCFilter.processException(var15, "com.ibm.ejs.container.ContainerManagedBeanO.hydrate", "592", this);
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "hydration failed", var15);
				}

				this.destroy();
				throw new ContainerInternalError(var15);
			}

			pmiCookie = -1L;
			if (this.pmiBean != null) {
				pmiCookie = this.pmiBean.loadTime();
			}

			if (isTraceOn) {
				if (tcClntInfo.isDebugEnabled()) {
					Tr.debug(tcClntInfo, "ejbLoad");
				}

				if (TEBeanLifeCycleInfo.isTraceEnabled()) {
					TEBeanLifeCycleInfo.traceEJBCallEntry("ejbLoad");
				}
			}

			this.entityBean.ejbLoad();
			if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceEJBCallExit("ejbLoad");
			}

			if (pmiCookie != -1L) {
				this.pmiBean.loadTime(pmiCookie);
			}

			if (this.cachedExclusive) {
				this.setState(1, 4);
			} else {
				this.setState(1, 12);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "hydrate");
		}

	}

	protected final void loadForEnlist(ContainerTx tx) throws RemoteException {
		boolean forUpdate = !EJSContainer.getMethodContext().methodInfo.getReadOnlyAttribute();
		if (this.ivModuleVersion == 11) {
			this.load(tx != null && tx.isTransactionGlobal() && forUpdate);
		} else {
			this.load(tx != null && forUpdate);
		}

	}

	protected final void load(boolean forUpdate) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "load(forupdate): " + this.toString());
		}

		boolean exceptionCaught = false;
		this.ivStored = false;
		long pmiCookie = -1L;
		boolean var29 = false;

		try {
			var29 = true;
			if (this.pmiBean != null) {
				pmiCookie = this.pmiBean.loadTime();
			}

			this.persister.setContextData(this);
			this.ivLoadForUpdate = forUpdate && this.persister.dbSupportsSelectForUpdate();
			this.inLoadMethodForUpdate = this.ivLoadForUpdate;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Update Intent(" + forUpdate + ") Load For Update(" + this.ivLoadForUpdate + ")");
			}

			this.persister.load(this.entityBean, this.beanId.getPrimaryKey(), this.ivLoadForUpdate);
			var29 = false;
		} catch (ObjectNotFoundException var32) {
			exceptionCaught = true;
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Load failed. Expected when row does not exist in the database. ", var32);
			}

			throw new NoSuchObjectException("");
		} catch (RemoteException var33) {
			exceptionCaught = true;
			FFDCFilter.processException(var33, "com.ibm.ejs.container.ContainerManagedBeanO.load", "700", this);
			throw var33;
		} catch (Exception var34) {
			exceptionCaught = true;
			FFDCFilter.processException(var34, "com.ibm.ejs.container.ContainerManagedBeanO.load", "711", this);
			throw new CPIException(var34);
		} finally {
			if (var29) {
				this.inLoadMethodForUpdate = false;
				this.persister.setContextData((EntityBeanO) null);
				BeanOCallDispatchToken smfDispatchToken = null;
				if (!exceptionCaught) {
					try {
						if (isTraceOn) {
							if (tcClntInfo.isDebugEnabled()) {
								Tr.debug(tcClntInfo, "ejbLoad");
							}

							if (TEBeanLifeCycleInfo.isTraceEnabled()) {
								TEBeanLifeCycleInfo.traceEJBCallEntry("ejbLoad");
							}
						}

						if (isZOS) {
							smfDispatchToken = this.callDispatchEventListeners(4, (BeanOCallDispatchToken) null);
						}

						this.entityBean.ejbLoad();
					} finally {
						if (smfDispatchToken != null) {
							this.callDispatchEventListeners(5, smfDispatchToken);
						}

						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallExit("ejbLoad");
						}

					}
				}

				if (pmiCookie != -1L) {
					this.pmiBean.loadTime(pmiCookie);
				}

			}
		}

		this.inLoadMethodForUpdate = false;
		this.persister.setContextData((EntityBeanO) null);
		BeanOCallDispatchToken smfDispatchToken = null;
		if (!exceptionCaught) {
			try {
				if (isTraceOn) {
					if (tcClntInfo.isDebugEnabled()) {
						Tr.debug(tcClntInfo, "ejbLoad");
					}

					if (TEBeanLifeCycleInfo.isTraceEnabled()) {
						TEBeanLifeCycleInfo.traceEJBCallEntry("ejbLoad");
					}
				}

				if (isZOS) {
					smfDispatchToken = this.callDispatchEventListeners(4, (BeanOCallDispatchToken) null);
				}

				this.entityBean.ejbLoad();
			} finally {
				if (smfDispatchToken != null) {
					this.callDispatchEventListeners(5, smfDispatchToken);
				}

				if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
					TEBeanLifeCycleInfo.traceEJBCallExit("ejbLoad");
				}

			}
		}

		if (pmiCookie != -1L) {
			this.pmiBean.loadTime(pmiCookie);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "load");
		}

	}

	protected final void load(ContainerTx tx, boolean forUpdate) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "load(tx, forupdate): " + this.toString());
		}

		if (this.ivModuleVersion == 11) {
			this.load(tx != null && tx.isTransactionGlobal() && forUpdate);
		} else {
			this.load(tx != null && forUpdate);
		}

	}

	public void ensurePersistentState(ContainerTx tx) throws RemoteException {
		if (this.ivDataCache != null && this.ivStored && (this.getState() == 6 || this.getState() == 8)) {
			boolean lReadOnly = EJSContainer.getMethodContext().methodInfo.getReadOnlyAttribute();
			if (!lReadOnly) {
				this.load(tx, false);
			}
		}

	}

	public TimerService getTimerService() throws IllegalStateException {
		IllegalStateException ise = new IllegalStateException(
				"EntityBean: getTimerService not allowed from CMP 1.x Entity Bean");
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getTimerService: " + ise);
		}

		throw ise;
	}

	public void checkTimerServiceAccess() throws IllegalStateException {
		IllegalStateException ise = new IllegalStateException(
				"EntityBean: Timer Service methods not allowed from CMP 1.1 beans.");
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "checkTimerServiceAccess: " + ise);
		}

		throw ise;
	}

	public String toString() {
		return "ContainerManagedBeanO(" + this.beanId + ", state = " + StateStrs[this.state] + ")";
	}

	public final AccessIntent getAccessIntent() {
		return this.ivAccessIntent;
	}
}