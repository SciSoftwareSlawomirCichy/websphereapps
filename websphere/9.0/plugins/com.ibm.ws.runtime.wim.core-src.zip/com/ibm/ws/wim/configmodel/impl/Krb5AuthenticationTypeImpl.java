package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.Krb5AuthenticationType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class Krb5AuthenticationTypeImpl extends EDataObjectImpl implements Krb5AuthenticationType {
	protected static final String KRB5_PRINCIPAL_EDEFAULT = null;
	protected String krb5Principal;
	protected boolean krb5PrincipalESet;
	protected static final String KRB5_TICKET_CACHE_EDEFAULT = null;
	protected String krb5TicketCache;
	protected boolean krb5TicketCacheESet;

	protected Krb5AuthenticationTypeImpl() {
		this.krb5Principal = KRB5_PRINCIPAL_EDEFAULT;
		this.krb5PrincipalESet = false;
		this.krb5TicketCache = KRB5_TICKET_CACHE_EDEFAULT;
		this.krb5TicketCacheESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getKrb5AuthenticationType();
	}

	public String getKrb5Principal() {
		return this.krb5Principal;
	}

	public void setKrb5Principal(String var1) {
		String var2 = this.krb5Principal;
		this.krb5Principal = var1;
		boolean var3 = this.krb5PrincipalESet;
		this.krb5PrincipalESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.krb5Principal, !var3));
		}

	}

	public String getKrb5TicketCache() {
		return this.krb5TicketCache;
	}

	public void setKrb5TicketCache(String var1) {
		String var2 = this.krb5TicketCache;
		this.krb5TicketCache = var1;
		boolean var3 = this.krb5TicketCacheESet;
		this.krb5TicketCacheESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.krb5TicketCache, !var3));
		}

	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getKrb5Principal();
			case 1 :
				return this.getKrb5TicketCache();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setKrb5Principal((String) var2);
				return;
			case 1 :
				this.setKrb5TicketCache((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setKrb5Principal(KRB5_PRINCIPAL_EDEFAULT);
				return;
			case 1 :
				this.setKrb5TicketCache(KRB5_TICKET_CACHE_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return KRB5_PRINCIPAL_EDEFAULT == null
						? this.krb5Principal != null
						: !KRB5_PRINCIPAL_EDEFAULT.equals(this.krb5Principal);
			case 1 :
				return KRB5_TICKET_CACHE_EDEFAULT == null
						? this.krb5TicketCache != null
						: !KRB5_TICKET_CACHE_EDEFAULT.equals(this.krb5TicketCache);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append("(krb5Principal: ");
			var1.append(this.krb5Principal);
			var1.append(", krb5TicketCache: ");
			var1.append(this.krb5TicketCache);
			var1.append(')');
			return var1.toString();
		}
	}

	public boolean isSetKrb5Principal() {
		return this.krb5PrincipalESet;
	}

	public boolean isSetKrb5TicketCache() {
		return this.krb5TicketCacheESet;
	}

	public void unsetKrb5Principal() {
		String var1 = this.krb5Principal;
		boolean var2 = this.krb5PrincipalESet;
		this.krb5Principal = KRB5_PRINCIPAL_EDEFAULT;
		this.krb5PrincipalESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 0, var1, KRB5_PRINCIPAL_EDEFAULT, var2));
		}

	}

	public void unsetKrb5TicketCache() {
		String var1 = this.krb5TicketCache;
		boolean var2 = this.krb5TicketCacheESet;
		this.krb5TicketCache = KRB5_TICKET_CACHE_EDEFAULT;
		this.krb5TicketCacheESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 1, var1, KRB5_TICKET_CACHE_EDEFAULT, var2));
		}

	}
}