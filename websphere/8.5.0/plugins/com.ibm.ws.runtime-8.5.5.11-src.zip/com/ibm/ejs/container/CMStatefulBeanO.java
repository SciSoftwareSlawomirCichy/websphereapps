package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.managedobject.ManagedObjectState;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import javax.ejb.SessionSynchronization;
import javax.transaction.UserTransaction;

public class CMStatefulBeanO extends StatefulBeanO {
	private static final String CLASS_NAME = CMStatefulBeanO.class.getName();
	private static final TraceComponent tc;
	private SessionSynchronization sessionSync = null;
	public Method ivAfterBegin = null;
	public Method ivBeforeCompletion = null;
	public Method ivAfterCompletion = null;

	public CMStatefulBeanO(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		super(c, mo, b, h);
		if (b instanceof SessionSynchronization) {
			this.sessionSync = (SessionSynchronization) b;
		}

		this.ivAfterBegin = h.beanMetaData.ivAfterBegin;
		this.ivBeforeCompletion = h.beanMetaData.ivBeforeCompletion;
		this.ivAfterCompletion = h.beanMetaData.ivAfterCompletion;
	}

	public void setEnterpriseBean(Object sb, ManagedObjectState state) {
		super.setEnterpriseBean(sb, state);
		if (this.ivEjbInstance instanceof SessionSynchronization) {
			this.sessionSync = (SessionSynchronization) this.ivEjbInstance;
		}

	}

	public boolean enlist(ContainerTx tx) throws RemoteException {
		return this.enlist(tx, true);
	}

	public final synchronized boolean enlist(ContainerTx tx, boolean txEnlist) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "enlist: " + this.stateStrs[this.state], new Object[]{tx, txEnlist});
		}

		switch (this.state) {
			case 3 :
				if (this.currentTx != null) {
					throw new BeanNotReentrantException(this.stateStrs[this.state] + ": Tx != null");
				}

				this.currentTx = tx;
				boolean result = !txEnlist || tx.enlist(this);
				if ((this.ivAfterBegin != null || this.sessionSync != null) && tx.isTransactionGlobal()) {
					this.setState(13);
					if (this.ivAfterBegin != null) {
						this.invokeSessionSynchMethod(this.ivAfterBegin, (Object[]) null);
					} else {
						this.sessionSync.afterBegin();
					}
				}

				this.setState(5);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "enlist: " + result + ": " + this.stateStrs[this.state]);
				}

				return result;
			case 4 :
			case 8 :
			case 9 :
			case 10 :
			case 11 :
			default :
				throw new InvalidBeanOStateException(this.stateStrs[this.state], "METHOD_READY | TX_METHOD_READY");
			case 5 :
				if (this.currentTx != tx) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist: not re-entrant");
					}

					throw new BeanNotReentrantException(StateStrs[this.state] + ": wrong transaction");
				}

				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "enlist: false");
				}

				return false;
			case 6 :
			case 12 :
			case 13 :
			case 14 :
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "enlist: not re-entrant");
				}

				if (this.currentTx != tx) {
					throw new BeanNotReentrantException(StateStrs[this.state] + ": wrong transaction");
				}

				throw new BeanNotReentrantException(this.stateStrs[this.state]);
			case 7 :
				if (this.currentTx != tx) {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist: not re-entrant");
					}

					throw new BeanNotReentrantException(StateStrs[this.state] + ": wrong transaction");
				} else {
					boolean result1 = tx.enlist(this);
					this.setState(5);
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist: " + result1 + ": " + this.stateStrs[this.state]);
					}

					return result1;
				}
		}
	}

	public final synchronized void commit(ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "commit: " + this.stateStrs[this.state], tx);
		}

		if (this.removed) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "commit: removed");
			}

		} else {
			if (tx.ivRemoveBeanO == this) {
				this.completeRemoveMethod(tx);
			} else {
				this.setState(7, 14);
				if ((this.ivAfterCompletion != null || this.sessionSync != null) && tx.isTransactionGlobal()) {
					EJBThreadData threadData = EJSContainer.getThreadData();
					threadData.pushContexts(this);

					try {
						if (this.ivAfterCompletion != null) {
							this.invokeSessionSynchMethod(this.ivAfterCompletion, new Object[]{true});
						} else {
							this.sessionSync.afterCompletion(true);
						}
					} finally {
						threadData.popContexts();
					}
				}

				this.setState(14, 3);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "commit: " + this.stateStrs[this.state]);
			}

		}
	}

	public final synchronized void rollback(ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "rollback: " + StateStrs[this.state], tx);
		}

		if (this.removed) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "rollback: removed");
			}

		} else {
			switch (this.state) {
				case 0 :
					if (this.ivBeforeCompletion == null && this.sessionSync == null) {
						if (isTraceOn && tc.isEntryEnabled()) {
							Tr.exit(tc, "rollback: InvalidBeanOStateException: " + StateStrs[this.state]);
						}

						throw new InvalidBeanOStateException(StateStrs[this.state],
								"COMMITTING_OUTSIDE_METHOD | TX_METHOD_READY | TX_IN_METHOD");
					}

					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "SessionSynchronization.beforeCompletion exception?");
					}
					break;
				case 1 :
				case 2 :
				case 3 :
				case 4 :
				case 8 :
				case 9 :
				case 10 :
				case 11 :
				default :
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "rollback: InvalidBeanOStateException: " + StateStrs[this.state]);
					}

					throw new InvalidBeanOStateException(StateStrs[this.state],
							"COMMITTING_OUTSIDE_METHOD | TX_METHOD_READY | TX_IN_METHOD");
				case 5 :
				case 7 :
				case 13 :
					this.setState(3);
					break;
				case 6 :
				case 12 :
					this.setState(4);
			}

			if (tx.ivRemoveBeanO == this) {
				this.completeRemoveMethod(tx);
			} else {
				int savedState = this.state;
				this.setState(14);
				if ((this.ivAfterCompletion != null || this.sessionSync != null) && tx.isTransactionGlobal()) {
					EJBThreadData threadData = EJSContainer.getThreadData();
					threadData.pushContexts(this);

					try {
						if (this.ivAfterCompletion != null) {
							this.invokeSessionSynchMethod(this.ivAfterCompletion, new Object[]{false});
						} else {
							this.sessionSync.afterCompletion(false);
						}
					} finally {
						threadData.popContexts();
					}
				}

				this.setState(savedState);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "rollback: " + StateStrs[this.state]);
			}

		}
	}

	public final synchronized void beforeCompletion() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "beforeCompletion: " + StateStrs[this.state]);
		}

		if (this.removed) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "beforeCompletion: removed");
			}

		} else {
			switch (this.state) {
				case 0 :
				case 3 :
				case 4 :
				case 14 :
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "beforeCompletion: asynch rollback: " + this.stateStrs[this.state]);
					}

					return;
				case 1 :
				case 2 :
				case 6 :
				case 7 :
				case 8 :
				case 9 :
				case 10 :
				case 11 :
				case 12 :
				case 13 :
				default :
					throw new InvalidBeanOStateException(this.stateStrs[this.state],
							"TX_METHOD_READY | TX_IN_METHOD | METHOD_READY | DESTROYED");
				case 5 :
					this.setState(7);
					if (this.ivBeforeCompletion != null || this.sessionSync != null) {
						ContainerTx tx = this.container.getCurrentTx();
						if (tx != null && tx.isTransactionGlobal() && !tx.getRollbackOnly()
								&& tx.ivRemoveBeanO != this) {
							EJBThreadData threadData = EJSContainer.getThreadData();
							threadData.pushContexts(this);

							try {
								if (this.ivBeforeCompletion != null) {
									this.invokeSessionSynchMethod(this.ivBeforeCompletion, (Object[]) null);
								} else {
									this.sessionSync.beforeCompletion();
								}
							} finally {
								threadData.popContexts();
							}
						}
					}

					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "beforeCompletion: " + this.stateStrs[this.state]);
					}

			}
		}
	}

	public synchronized UserTransaction getUserTransaction() {
		throw new IllegalStateException();
	}

	protected boolean eligibleForUnlock() {
		return this.state == 3 || this.state == 5 || this.state == 0;
	}

	private void invokeSessionSynchMethod(Method method, Object[] parameters) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			StringBuilder traceMsg = new StringBuilder("invoking session synchronization method : ");
			traceMsg.append(method.getName());
			if (parameters != null && parameters.length > 0) {
				traceMsg.append("(").append(parameters[0]).append(")");
			}

			Tr.debug(tc, traceMsg.toString());
		}

		try {
			method.invoke(this.ivEjbInstance, parameters);
		} catch (IllegalArgumentException var6) {
			FFDCFilter.processException(var6, CLASS_NAME + ".invokeSessionSynchMethod", "601",
					new Object[]{this, method, this.ivEjbInstance, parameters});
			throw var6;
		} catch (IllegalAccessException var7) {
			FFDCFilter.processException(var7, CLASS_NAME + ".invokeSessionSynchMethod", "610",
					new Object[]{this, method, this.ivEjbInstance, parameters});
			throw ExceptionUtil.EJBException("Failure invoking session synchronization method " + method, var7);
		} catch (InvocationTargetException var8) {
			FFDCFilter.processException(var8, CLASS_NAME + ".invokeSessionSynchMethod", "618",
					new Object[]{this, method, this.ivEjbInstance, parameters});
			Throwable cause = var8.getCause();
			if (cause instanceof RuntimeException) {
				throw (RuntimeException) cause;
			} else if (cause instanceof Error) {
				throw (Error) cause;
			} else {
				throw ExceptionUtil.EJBException("Failure invoking session synchronization method " + method, var8);
			}
		}
	}

	public final String toString() {
		return this.toString("CMStatefulBeanO");
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}