package com.ibm.ws.wim.schema;

import com.ibm.websphere.wim.exception.InvalidEntityTypeException;
import com.ibm.websphere.wim.exception.InvalidRepositoryIdException;
import com.ibm.websphere.wim.exception.InvalidSchemaException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.SchemaManager;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;

public class SchemaValidator {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2009";
	private static final String CLASSNAME = SchemaValidator.class.getName();
	private static final Logger trcLogger;

	public static void validateEntityTypeName(List var0) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateEntityTypeName", "The list of Applicable Entity types are " + var0);
		}

		for (int var2 = 0; var2 < var0.size(); ++var2) {
			String var3 = (String) var0.get(var2);
			String var4 = null;
			int var5 = var3.indexOf(":");
			if (var5 > 1) {
				var4 = var3.substring(0, var5);
				if (null == SchemaManager.singleton().getNsURI(var4)) {
					throw new InvalidSchemaException("INVALID_NS_PREFIX_FOR_ENTITY_TYPE_OR_PROPERTY",
							WIMMessageHelper.generateMsgParms(var4, var3.substring(var5 + 1)), Level.SEVERE, CLASSNAME,
							"validateEntityTypeName");
				}
			}

			EClass var6 = SchemaManager.singleton().getEClass(var3);
			if (var6 == null) {
				throw new InvalidEntityTypeException("EXTEND_SCHEMA_PROPERTY_EXTENSION_INVALID_APPLICABLE_ENTITY_TYPE",
						WIMMessageHelper.generateMsgParms(var3), Level.SEVERE, CLASSNAME, "validateEntityTypeName");
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "validateEntityTypeName");
		}

	}

	public static void validateRequiredEntityTypeName(List var0, List var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateRequiredEntityTypeName",
					"The list of Applicable Entity types are " + var0 + " and Required Entity types are " + var1);
		}

		if (var1 != null && var1.size() != 0) {
			for (int var3 = 0; var3 < var1.size(); ++var3) {
				String var4 = (String) var1.get(var3);
				EClass var5 = SchemaManager.singleton().getEClass(var4);
				if (var5 == null) {
					throw new InvalidEntityTypeException(
							"EXTEND_SCHEMA_PROPERTY_EXTENSION_INVALID_REQUIRED_ENTITY_TYPE",
							WIMMessageHelper.generateMsgParms(var4), Level.SEVERE, CLASSNAME,
							"validateRequiredEntityTypeName");
				}

				if (!var0.contains(var4)) {
					throw new InvalidEntityTypeException(
							"EXTEND_SCHEMA_PROPERTY_EXTENSION_INVALID_REQUIRED_NOTIN_APPLICABLE_ENTITY_TYPE",
							WIMMessageHelper.generateMsgParms(var4), Level.SEVERE, CLASSNAME,
							"validateRequiredEntityTypeName");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateRequiredEntityTypeName");
			}

		}
	}

	public static void validateDataType(String var0, String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateDataType",
					"The property Name is " + var1 + " and Datatype is " + var0);
		}

		EDataType var3 = SchemaManager.singleton().getEDataType(var0);
		if (var3 == null) {
			throw new WIMConfigurationException("EXTEND_SCHEMA_PROPERTY_EXTENSION_INVALID_DATA_TYPE",
					WIMMessageHelper.generateMsgParms(var0, var1), Level.SEVERE, CLASSNAME, "validateDataType");
		} else {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateDataType");
			}

		}
	}

	public static void validateRepositoryId(List var0) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateRepositoryId", "The list of repositories are " + var0);
		}

		if (var0 != null && var0.size() != 0) {
			for (int var2 = 0; var2 < var0.size(); ++var2) {
				String var3 = (String) var0.get(var2);
				if (!var3.equalsIgnoreCase("LA") && RepositoryManager.singleton().getRepository(var3) == null) {
					throw new InvalidRepositoryIdException("INVALID_REPOSITORY_ID",
							WIMMessageHelper.generateMsgParms(var3), Level.SEVERE, CLASSNAME, "validateRepositoryId");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateRepositoryId");
			}

		}
	}

	public static void validateNameSpaceAttributes(String var0, String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "validateNameSpaceAttributes",
					"The name space URI is  " + var0 + " and the nsprefix is " + var1);
		}

		if (var0 != null || var1 != null) {
			if (var0 == null && (var1 != null || var1.trim().length() > 0)) {
				if (null == SchemaManager.singleton().getNsURI(var1)) {
					throw new InvalidSchemaException("NO_NS_PREFIX_FOR_NS_URI", WIMMessageHelper.generateMsgParms(var0),
							Level.SEVERE, CLASSNAME, "validateNameSpaceAttributes");
				}
			} else if (var1 == null && (var0 != null || var0.trim().length() > 0)) {
				if (null == SchemaManager.singleton().getNsPrefix(var0)) {
					throw new InvalidSchemaException("INVALID_NS_PREFIX", WIMMessageHelper.generateMsgParms(var1),
							Level.SEVERE, CLASSNAME, "validateNameSpaceAttributes");
				}
			} else {
				String var3 = SchemaManager.singleton().getNsURI(var1.trim());
				String var4 = SchemaManager.singleton().getNsPrefix(var0.trim());
				if ((null != var3 || null != var4) && (!var0.trim().equals(var3) || !var1.trim().equals(var4))) {
					throw new InvalidSchemaException("DUPLICATE_NS_PREFIX",
							WIMMessageHelper.generateMsgParms(var1, var0), Level.SEVERE, CLASSNAME,
							"validateNameSpaceAttributes");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "validateNameSpaceAttributes");
			}

		}
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}