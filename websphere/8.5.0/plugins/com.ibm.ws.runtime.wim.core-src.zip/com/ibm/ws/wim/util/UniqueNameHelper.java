package com.ibm.ws.wim.util;

import com.ibm.websphere.wim.exception.InvalidPropertyValueException;
import com.ibm.websphere.wim.exception.InvalidUniqueNameException;
import com.ibm.websphere.wim.exception.MissingMandatoryPropertyException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.ldap.LdapHelper;
import com.sun.jndi.ldap.LdapName;
import commonj.sdo.DataObject;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import javax.naming.InvalidNameException;

public class UniqueNameHelper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = UniqueNameHelper.class.getName();
	public static final String ENTITY_DN_SEPARATOR = ",";

	public static String isDN(String var0) {
		if (var0 == null) {
			return null;
		} else {
			LdapName var2 = null;

			try {
				var2 = new LdapName(var0);
				return var2.getPrefix(var2.size()).toString();
			} catch (InvalidNameException var4) {
				return null;
			}
		}
	}

	public static String formatUniqueName(String var0) throws InvalidUniqueNameException {
		String var2 = getValidUniqueName(var0);
		if (var2 == null) {
			throw new InvalidUniqueNameException("INVALID_UNIQUE_NAME_SYNTAX", WIMMessageHelper.generateMsgParms(var0),
					CLASSNAME, "formatUniqueName(String)");
		} else {
			return var2;
		}
	}

	public static String getParentDN(String var0) throws InvalidUniqueNameException {
		if (var0 == null) {
			return var0;
		} else {
			String var2 = null;

			try {
				LdapName var3 = new LdapName(var0);
				if (var3.size() == 0) {
					return null;
				} else {
					var2 = var3.getPrefix(var3.size() - 1).toString();
					return var2;
				}
			} catch (InvalidNameException var4) {
				throw new InvalidUniqueNameException("INVALID_UNIQUE_NAME_SYNTAX",
						WIMMessageHelper.generateMsgParms(var0), CLASSNAME, "getRDN(String)");
			}
		}
	}

	public static String getRDN(String var0) throws InvalidUniqueNameException {
		if (var0 == null) {
			return var0;
		} else {
			String var2 = null;

			try {
				LdapName var3 = new LdapName(var0);
				if (var3.size() == 0) {
					return var0;
				} else {
					var2 = var3.get(var3.size() - 1);
					return var2;
				}
			} catch (InvalidNameException var4) {
				throw new InvalidUniqueNameException("INVALID_UNIQUE_NAME_SYNTAX",
						WIMMessageHelper.generateMsgParms(var0), CLASSNAME, "getRDN(String)");
			}
		}
	}

	public static String getRDNProperty(String var0) throws InvalidUniqueNameException {
		String var1 = null;
		String var2 = getRDN(var0);
		int var3 = var2.indexOf(61);
		if (var3 != -1) {
			var1 = var2.substring(0, var3);
		}

		return var1;
	}

	public static String[] getRDNComponents(String var0) {
		if (var0 == null) {
			return null;
		} else {
			String[] var1 = null;
			int var2 = var0.indexOf(43);
			if (var2 == -1) {
				var1 = new String[]{var0};
				return var1;
			} else if (var2 == 0) {
				var1 = new String[]{var0.substring(1)};
				return var1;
			} else {
				ArrayList var3 = new ArrayList();
				Object var4 = null;

				int var5;
				for (var5 = 0; var2 > -1; var2 = var0.indexOf(43, var2 + 1)) {
					if (var0.charAt(var2 - 1) != '\\') {
						var3.add(var0.substring(var5, var2));
						var5 = var2 + 1;
					}
				}

				var3.add(var0.substring(var5));
				var1 = new String[var3.size()];
				var1 = (String[]) ((String[]) var3.toArray(var1));
				return var1;
			}
		}
	}

	public static String[] getRDNAttrTypesByRDNComponents(String[] var0) {
		if (var0 == null) {
			return null;
		} else {
			String[] var1 = null;
			int var2 = var0.length;
			var1 = new String[var2];

			for (int var3 = 0; var3 < var2; ++var3) {
				int var4 = var0[var3].indexOf(61);
				if (var4 > -1) {
					var1[var3] = var0[var3].substring(0, var4);
				}
			}

			return var1;
		}
	}

	public static String[] getRDNAttrTypesForComparison(String[] var0) {
		int var1 = var0.length;
		String[] var2 = new String[var1];

		for (int var3 = 0; var3 < var1; ++var3) {
			var2[var3] = var0[var3].toLowerCase();
		}

		return var2;
	}

	public static String getValidUniqueName(String var0) {
		return LdapHelper.getValidDN(var0);
	}

	public static String[] getRDNs(String var0) {
		StringTokenizer var1 = new StringTokenizer(var0, "+");
		ArrayList var2 = new ArrayList();

		while (var1.hasMoreTokens()) {
			String var3 = var1.nextToken();
			var2.add(var3);
		}

		return (String[]) ((String[]) var2.toArray(new String[0]));
	}

	public static String constructUniqueName(List var0, String[] var1, String var2) throws InvalidUniqueNameException {
		if (var0 != null) {
			int var3 = var0.size();
			if (var3 == var1.length && var3 != 0) {
				StringBuffer var4 = new StringBuffer();

				for (int var5 = 0; var5 < var3; ++var5) {
					if (var1[var5] != null && var1[var5].length() != 0) {
						if (var5 != 0 && var4.length() != 0) {
							var4.append("+");
						}

						var4.append((String) var0.get(var5) + "=" + LdapName.escapeAttributeValue(var1[var5]));
					}
				}

				String var6 = null;
				if (var2.length() == 0) {
					var6 = var4.toString();
				} else {
					var6 = var4.toString() + "," + var2;
				}

				return formatUniqueName(var6);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static String constructUniqueName(String[] var0, String[] var1, String var2)
			throws InvalidUniqueNameException {
		if (var0 != null) {
			int var4 = var0.length;
			if (var4 == var1.length && var4 != 0) {
				StringBuffer var5 = new StringBuffer();

				for (int var6 = 0; var6 < var4; ++var6) {
					if (var1[var6] != null && var1[var6].length() != 0) {
						if (var6 != 0 && var5.length() != 0) {
							var5.append("+");
						}

						var5.append(var0[var6] + "=" + LdapName.escapeAttributeValue(var1[var6]));
					}
				}

				String var7 = null;
				if (var2.length() == 0) {
					var7 = var5.toString();
				} else {
					var7 = var5.toString() + "," + var2;
				}

				return formatUniqueName(var7);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static String constructUniqueName(List var0, DataObject var1, String var2) throws WIMException {
		return constructUniqueName(var0, var1, var2, true);
	}

	public static String constructUniqueName(List var0, DataObject var1, String var2, boolean var3)
			throws WIMException {
		boolean var5 = false;
		String var6 = null;
		String var7 = null;

		for (int var8 = 0; var8 < var0.size(); ++var8) {
			String[] var9 = getRDNs((String) var0.get(var8));
			int var10 = var9.length;
			String[] var11 = new String[var10];
			boolean var12 = true;

			String var14;
			for (int var13 = 0; var13 < var10 && var12; ++var13) {
				var14 = var9[var13];
				String var15 = var1.getString(var14);
				if (var15 == null) {
					var12 = false;
					var7 = var14;
				} else {
					if (var15.trim().length() == 0) {
						SchemaManager var16 = SchemaManager.singleton();
						String var17 = var16.getQualifiedTypeName(var1.getType());
						throw new InvalidPropertyValueException("CAN_NOT_CONSTRUCT_UNIQUE_NAME",
								WIMMessageHelper.generateMsgParms(var14, var17), CLASSNAME,
								"constructUniqueName(List,DataObject,String,boolean)");
					}

					var11[var13] = var15;
				}
			}

			if (var12) {
				if (!var5) {
					var6 = constructUniqueName(var9, var11, var2);
					var5 = true;
				} else if (var3) {
					SchemaManager var18 = SchemaManager.singleton();
					var14 = var18.getQualifiedTypeName(var1.getType());
					throw new InvalidUniqueNameException("CAN_NOT_CONSTRUCT_UNIQUE_NAME",
							WIMMessageHelper.generateMsgParms(var0.toString(), var14), CLASSNAME,
							"constructUniqueName(List,DataObject,String,boolean)");
				}
			}
		}

		if (var7 != null && !var5 && var3) {
			throw new MissingMandatoryPropertyException("MISSING_MANDATORY_PROPERTY",
					WIMMessageHelper.generateMsgParms(var7), CLASSNAME,
					"constructUniqueName(List,DataObject,String,boolean)");
		} else {
			return var6;
		}
	}

	public static boolean isUniqueNameUnderSearchBases(String var0, List var1) {
		if (var1 != null && var1.size() != 0) {
			for (int var2 = 0; var2 < var1.size(); ++var2) {
				String var3 = (String) var1.get(var2);
				if (var0.trim().toLowerCase().endsWith(var3.toLowerCase())) {
					return true;
				}
			}

			return false;
		} else {
			return true;
		}
	}

	public static String replaceRDNProperty(String var0, String var1) {
		int var2 = var0.indexOf("=");
		if (var2 > 0) {
			var0 = var1 + var0.substring(var2);
		}

		return var0;
	}
}