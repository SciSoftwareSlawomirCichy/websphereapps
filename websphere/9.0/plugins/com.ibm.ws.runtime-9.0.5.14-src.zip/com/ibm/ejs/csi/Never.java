package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import javax.transaction.Transaction;

final class Never extends TranStrategy {
	private static final TraceComponent tc = Tr.register(Never.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	Never(TransactionControlImpl txCtrl) {
		super(txCtrl);
	}

	TxCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		if (this.globalTxExists(false)) {
			throw new CSIException("TX_NEVER method called within a global tx");
		} else {
			TxCookieImpl cookie = this.beginLocalTx(key, methodInfo, (Transaction) null);
			if (entryEnabled) {
				Tr.exit(tc, "preInvoke");
			}

			return cookie;
		}
	}

	void postInvoke(EJBKey key, TxCookieImpl txCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		super.postInvoke(key, txCookie, methodInfo);
		if (entryEnabled) {
			Tr.exit(tc, "postInvoke");
		}

	}
}