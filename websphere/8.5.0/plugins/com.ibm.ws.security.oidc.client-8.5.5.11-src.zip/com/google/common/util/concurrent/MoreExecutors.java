package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import com.google.common.base.Throwables;
import com.google.common.collect.Lists;
import com.google.common.collect.Queues;
import com.google.common.util.concurrent.MoreExecutors.1;
import com.google.common.util.concurrent.MoreExecutors.Application;
import com.google.common.util.concurrent.MoreExecutors.ListeningDecorator;
import com.google.common.util.concurrent.MoreExecutors.SameThreadExecutorService;
import com.google.common.util.concurrent.MoreExecutors.ScheduledListeningDecorator;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public final class MoreExecutors {
	@Beta
	public static ExecutorService getExitingExecutorService(ThreadPoolExecutor executor, long terminationTimeout,
			TimeUnit timeUnit) {
		return (new Application()).getExitingExecutorService(executor, terminationTimeout, timeUnit);
	}

	@Beta
	public static ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor,
			long terminationTimeout, TimeUnit timeUnit) {
		return (new Application()).getExitingScheduledExecutorService(executor, terminationTimeout, timeUnit);
	}

	@Beta
	public static void addDelayedShutdownHook(ExecutorService service, long terminationTimeout, TimeUnit timeUnit) {
		(new Application()).addDelayedShutdownHook(service, terminationTimeout, timeUnit);
	}

	@Beta
	public static ExecutorService getExitingExecutorService(ThreadPoolExecutor executor) {
		return (new Application()).getExitingExecutorService(executor);
	}

	@Beta
	public static ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor) {
		return (new Application()).getExitingScheduledExecutorService(executor);
	}

	private static void useDaemonThreadFactory(ThreadPoolExecutor executor) {
		executor.setThreadFactory(
				(new ThreadFactoryBuilder()).setDaemon(true).setThreadFactory(executor.getThreadFactory()).build());
	}

	public static ListeningExecutorService sameThreadExecutor() {
      return new SameThreadExecutorService((1)null);
   }

	public static ListeningExecutorService listeningDecorator(ExecutorService delegate) {
		return (ListeningExecutorService) (delegate instanceof ListeningExecutorService
				? (ListeningExecutorService) delegate
				: (delegate instanceof ScheduledExecutorService
						? new ScheduledListeningDecorator((ScheduledExecutorService) delegate)
						: new ListeningDecorator(delegate)));
	}

	public static ListeningScheduledExecutorService listeningDecorator(ScheduledExecutorService delegate) {
		return (ListeningScheduledExecutorService) (delegate instanceof ListeningScheduledExecutorService
				? (ListeningScheduledExecutorService) delegate
				: new ScheduledListeningDecorator(delegate));
	}

	static <T> T invokeAnyImpl(ListeningExecutorService executorService, Collection<? extends Callable<T>> tasks,
			boolean timed, long nanos) throws InterruptedException, ExecutionException, TimeoutException {
		Preconditions.checkNotNull(executorService);
		int ntasks = tasks.size();
		Preconditions.checkArgument(ntasks > 0);
		List<Future<T>> futures = Lists.newArrayListWithCapacity(ntasks);
		LinkedBlockingQueue futureQueue = Queues.newLinkedBlockingQueue();
		boolean var23 = false;

		Object var27;
		try {
			var23 = true;
			ExecutionException ee = null;
			long lastTime = timed ? System.nanoTime() : 0L;
			Iterator<? extends Callable<T>> it = tasks.iterator();
			futures.add(submitAndAddQueueListener(executorService, (Callable) it.next(), futureQueue));
			--ntasks;
			int active = 1;

			while (true) {
				Future<T> f = (Future) futureQueue.poll();
				if (f == null) {
					if (ntasks > 0) {
						--ntasks;
						futures.add(submitAndAddQueueListener(executorService, (Callable) it.next(), futureQueue));
						++active;
					} else {
						if (active == 0) {
							if (ee == null) {
								ee = new ExecutionException((Throwable) null);
							}

							throw ee;
						}

						if (timed) {
							f = (Future) futureQueue.poll(nanos, TimeUnit.NANOSECONDS);
							if (f == null) {
								throw new TimeoutException();
							}

							long now = System.nanoTime();
							nanos -= now - lastTime;
							lastTime = now;
						} else {
							f = (Future) futureQueue.take();
						}
					}
				}

				if (f != null) {
					--active;

					try {
						var27 = f.get();
						var23 = false;
						break;
					} catch (ExecutionException var24) {
						ee = var24;
					} catch (RuntimeException var25) {
						ee = new ExecutionException(var25);
					}
				}
			}
		} finally {
			if (var23) {
				Iterator i$ = futures.iterator();

				while (i$.hasNext()) {
					Future<T> f = (Future) i$.next();
					f.cancel(true);
				}

			}
		}

		Iterator i$ = futures.iterator();

		while (i$.hasNext()) {
			Future<T> f = (Future) i$.next();
			f.cancel(true);
		}

		return var27;
	}

	private static <T> ListenableFuture<T> submitAndAddQueueListener(ListeningExecutorService executorService, Callable<T> task, BlockingQueue<Future<T>> queue) {
      ListenableFuture<T> future = executorService.submit(task);
      future.addListener(new 1(queue, future), sameThreadExecutor());
      return future;
   }

	@Beta
	public static ThreadFactory platformThreadFactory() {
		if (!isAppEngine()) {
			return Executors.defaultThreadFactory();
		} else {
			try {
				return (ThreadFactory) Class.forName("com.google.appengine.api.ThreadManager")
						.getMethod("currentRequestThreadFactory").invoke((Object) null);
			} catch (IllegalAccessException var1) {
				throw new RuntimeException("Couldn't invoke ThreadManager.currentRequestThreadFactory", var1);
			} catch (ClassNotFoundException var2) {
				throw new RuntimeException("Couldn't invoke ThreadManager.currentRequestThreadFactory", var2);
			} catch (NoSuchMethodException var3) {
				throw new RuntimeException("Couldn't invoke ThreadManager.currentRequestThreadFactory", var3);
			} catch (InvocationTargetException var4) {
				throw Throwables.propagate(var4.getCause());
			}
		}
	}

	private static boolean isAppEngine() {
		if (System.getProperty("com.google.appengine.runtime.environment") == null) {
			return false;
		} else {
			try {
				return Class.forName("com.google.apphosting.api.ApiProxy").getMethod("getCurrentEnvironment")
						.invoke((Object) null) != null;
			} catch (ClassNotFoundException var1) {
				return false;
			} catch (InvocationTargetException var2) {
				return false;
			} catch (IllegalAccessException var3) {
				return false;
			} catch (NoSuchMethodException var4) {
				return false;
			}
		}
	}

	static Thread newThread(String name, Runnable runnable) {
		Preconditions.checkNotNull(name);
		Preconditions.checkNotNull(runnable);
		Thread result = platformThreadFactory().newThread(runnable);

		try {
			result.setName(name);
		} catch (SecurityException var4) {
			;
		}

		return result;
	}
}