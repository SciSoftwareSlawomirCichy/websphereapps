package com.ibm.ejs.container;

import com.ibm.ejs.container.passivator.PassivatorSerializableHandle;
import com.ibm.ejs.container.util.ByteArray;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.scheduler.Scheduler;
import com.ibm.websphere.scheduler.TaskInvalid;
import com.ibm.websphere.scheduler.TaskStatus;
import com.ibm.ws.ejb.portable.Constants;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.component.WASEJBRuntime;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import javax.ejb.EJBException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.Timer;
import javax.ejb.TimerHandle;

public final class TimerHandleImpl implements TimerHandle, Serializable, PassivatorSerializableHandle {
	private static final TraceComponent tc = Tr.register(TimerHandleImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.TimerHandleImpl";
	private static final long serialVersionUID = -7720620493313660153L;
	private static final byte[] EYECATCHER;
	private static final short PLATFORM = 1;
	private static final short VERSION_ID = 1;
	private transient String ivTaskId;
	private transient BeanId ivBeanId;
	private transient int ivHashCode;
	private transient boolean isTimer;

	TimerHandleImpl(BeanId beanId, String taskId, int hashcode, boolean timer) {
		this.ivBeanId = beanId;
		this.ivTaskId = taskId;
		this.ivHashCode = hashcode;
		this.isTimer = timer;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, this.toString());
		}

	}

	public Timer getTimer() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getTimer: " + this);
		}

		if (EJSPlatformHelper.isZOSCRA()) {
			NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(
					this.toString() + " -- called from the adjunct control region.");
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getTimer: " + nsoe);
			}

			throw nsoe;
		} else {
			this.checkTimerAccess();

			TimerImpl timer;
			try {
				EJSHome home = (EJSHome) this.ivBeanId.home;
				Scheduler scheduler = ((WASEJBRuntime) home.container.getEJBRuntime()).getTimerServiceScheduler();
				if ((home.beanMetaData.allowCachedTimerDataForMethods & 82) == 0) {
					TaskStatus taskStatus = scheduler.getStatus(this.ivTaskId);
					timer = new TimerImpl(this.ivBeanId, this.ivTaskId, this.ivHashCode);
					timer.ivStatus = taskStatus;
				} else {
					TimerTaskInfoImpl taskInfo = (TimerTaskInfoImpl) scheduler.getTask(this.ivTaskId);
					timer = new TimerImpl(this.ivBeanId, this.ivTaskId, this.ivHashCode);
					timer.ivHandler = taskInfo.getHandler();
					timer.ivStatus = taskInfo;
				}
			} catch (TaskInvalid var6) {
				NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(this.toString(), var6);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "getTimer: " + nsoe);
				}

				throw nsoe;
			} catch (Throwable var7) {
				FFDCFilter.processException(var7, "com.ibm.ejs.container.TimerHandleImpl.getTimer", "109", this);
				TimerServiceException tse = new TimerServiceException(this.toString(), var7);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "getTimer: " + tse);
				}

				throw tse;
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getTimer: " + timer);
			}

			return timer;
		}
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "writeObject: " + this);
		}

		out.defaultWriteObject();
		out.write(EYECATCHER);
		out.writeShort(1);
		out.writeShort(1);
		out.writeBoolean(this.isTimer);
		out.writeUTF(this.ivTaskId);
		out.writeInt(this.ivHashCode);
		out.writeObject(this.ivBeanId.getByteArrayBytes());
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "writeObject");
		}

	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "readObject");
		}

		in.defaultReadObject();
		byte[] eyeCatcher = new byte[EYECATCHER.length];
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < EYECATCHER.length; i += bytesRead) {
			bytesRead = in.read(eyeCatcher, i, EYECATCHER.length - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < EYECATCHER.length; ++i) {
			if (EYECATCHER[i] != eyeCatcher[i]) {
				String eyeCatcherString = new String(eyeCatcher);
				throw new IOException("Invalid eye catcher '" + eyeCatcherString + "' in TimerHandle input stream");
			}
		}

		short incoming_platform = in.readShort();
		short incoming_vid = in.readShort();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "readObject: platform = " + incoming_platform + ", version = " + incoming_vid);
		}

		if (incoming_vid != 1) {
			throw new InvalidObjectException(
					"EJB TimerHandle data stream is not of the correct version, this client should be updated.");
		} else {
			this.isTimer = in.readBoolean();
			this.ivTaskId = in.readUTF();
			this.ivHashCode = in.readInt();
			byte[] bytes = (byte[]) ((byte[]) in.readObject());
			ByteArray byteArray = new ByteArray(bytes);
			EJSContainer container = EJSContainer.getDefaultContainer();
			this.ivBeanId = BeanId.getBeanId(byteArray, container);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "readObject: " + this);
			}

		}
	}

	public Object getSerializedObject() {
		if (this.isTimer) {
			Object timer = new TimerImpl(this.ivBeanId, this.ivTaskId, this.ivHashCode);
			return timer;
		} else {
			return this;
		}
	}

	private void checkTimerAccess() throws IllegalStateException {
		if (ContainerProperties.DisablePersistentTimers) {
			IllegalStateException ise = new IllegalStateException("Persistent timers disabled");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerAccess: " + ise);
			}

			throw ise;
		} else {
			BeanO beanO = EJSContainer.getCallbackBeanO();
			if (beanO != null) {
				beanO.checkTimerServiceAccess();
			} else {
				if (!EJSContainer.getDefaultContainer().allowTimerAccessOutsideBean) {
					IllegalStateException ise = new IllegalStateException(
							"TimerHandle: Timer methods not allowed - no active EJB");
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "checkTimerAccess: " + ise);
					}

					throw ise;
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkTimerAccess: TimerHandle access permitted outside of bean");
				}
			}

		}
	}

	public boolean equals(Object obj) {
		if (obj instanceof TimerHandleImpl) {
			TimerHandleImpl timerHandle = (TimerHandleImpl) obj;
			if (this.ivHashCode == timerHandle.ivHashCode && this.ivTaskId.equals(timerHandle.ivTaskId)) {
				return true;
			}
		}

		return false;
	}

	public boolean equals(TimerHandleImpl timerHandle) {
		return timerHandle != null && this.ivHashCode == timerHandle.ivHashCode
				&& this.ivTaskId.equals(timerHandle.ivTaskId);
	}

	public int hashCode() {
		return this.ivHashCode;
	}

	public String toString() {
		return "TimerHandleImpl(" + this.ivTaskId + ", " + this.ivBeanId + ")";
	}

	static {
		EYECATCHER = Constants.TIMER_HANDLE_EYE_CATCHER;
	}
}