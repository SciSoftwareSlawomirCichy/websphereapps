package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.RateLimiter.Bursty;
import com.google.common.util.concurrent.RateLimiter.SleepingTicker;
import com.google.common.util.concurrent.RateLimiter.WarmingUp;
import java.util.concurrent.TimeUnit;
import javax.annotation.concurrent.ThreadSafe;

@ThreadSafe
@Beta
public abstract class RateLimiter {
	private final SleepingTicker ticker;
	private final long offsetNanos;
	double storedPermits;
	double maxPermits;
	volatile double stableIntervalMicros;
	private final Object mutex;
	private long nextFreeTicketMicros;

	public static RateLimiter create(double permitsPerSecond) {
		return create(SleepingTicker.SYSTEM_TICKER, permitsPerSecond);
	}

	@VisibleForTesting
	static RateLimiter create(SleepingTicker ticker, double permitsPerSecond) {
		RateLimiter rateLimiter = new Bursty(ticker);
		rateLimiter.setRate(permitsPerSecond);
		return rateLimiter;
	}

	public static RateLimiter create(double permitsPerSecond, long warmupPeriod, TimeUnit unit) {
		return create(SleepingTicker.SYSTEM_TICKER, permitsPerSecond, warmupPeriod, unit);
	}

	@VisibleForTesting
	static RateLimiter create(SleepingTicker ticker, double permitsPerSecond, long warmupPeriod, TimeUnit timeUnit) {
		RateLimiter rateLimiter = new WarmingUp(ticker, warmupPeriod, timeUnit);
		rateLimiter.setRate(permitsPerSecond);
		return rateLimiter;
	}

	@VisibleForTesting
	static RateLimiter createBursty(SleepingTicker ticker, double permitsPerSecond, int maxBurstSize) {
		Bursty rateLimiter = new Bursty(ticker);
		rateLimiter.setRate(permitsPerSecond);
		rateLimiter.maxPermits = (double) maxBurstSize;
		return rateLimiter;
	}

	private RateLimiter(SleepingTicker ticker) {
		this.mutex = new Object();
		this.nextFreeTicketMicros = 0L;
		this.ticker = ticker;
		this.offsetNanos = ticker.read();
	}

	public final void setRate(double permitsPerSecond) {
		Preconditions.checkArgument(permitsPerSecond > 0.0D && !Double.isNaN(permitsPerSecond),
				"rate must be positive");
		Object var3 = this.mutex;
		synchronized (this.mutex) {
			this.resync(this.readSafeMicros());
			double stableIntervalMicros = (double) TimeUnit.SECONDS.toMicros(1L) / permitsPerSecond;
			this.stableIntervalMicros = stableIntervalMicros;
			this.doSetRate(permitsPerSecond, stableIntervalMicros);
		}
	}

	abstract void doSetRate(double var1, double var3);

	public final double getRate() {
		return (double) TimeUnit.SECONDS.toMicros(1L) / this.stableIntervalMicros;
	}

	public void acquire() {
		this.acquire(1);
	}

	public void acquire(int permits) {
		checkPermits(permits);
		Object var4 = this.mutex;
		long microsToWait;
		synchronized (this.mutex) {
			microsToWait = this.reserveNextTicket((double) permits, this.readSafeMicros());
		}

		this.ticker.sleepMicrosUninterruptibly(microsToWait);
	}

	public boolean tryAcquire(long timeout, TimeUnit unit) {
		return this.tryAcquire(1, timeout, unit);
	}

	public boolean tryAcquire(int permits) {
		return this.tryAcquire(permits, 0L, TimeUnit.MICROSECONDS);
	}

	public boolean tryAcquire() {
		return this.tryAcquire(1, 0L, TimeUnit.MICROSECONDS);
	}

	public boolean tryAcquire(int permits, long timeout, TimeUnit unit) {
		long timeoutMicros = unit.toMicros(timeout);
		checkPermits(permits);
		Object var9 = this.mutex;
		long microsToWait;
		synchronized (this.mutex) {
			long nowMicros = this.readSafeMicros();
			if (this.nextFreeTicketMicros > nowMicros + timeoutMicros) {
				return false;
			}

			microsToWait = this.reserveNextTicket((double) permits, nowMicros);
		}

		this.ticker.sleepMicrosUninterruptibly(microsToWait);
		return true;
	}

	private static void checkPermits(int permits) {
		Preconditions.checkArgument(permits > 0, "Requested permits must be positive");
	}

	private long reserveNextTicket(double requiredPermits, long nowMicros) {
		this.resync(nowMicros);
		long microsToNextFreeTicket = this.nextFreeTicketMicros - nowMicros;
		double storedPermitsToSpend = Math.min(requiredPermits, this.storedPermits);
		double freshPermits = requiredPermits - storedPermitsToSpend;
		long waitMicros = this.storedPermitsToWaitTime(this.storedPermits, storedPermitsToSpend)
				+ (long) (freshPermits * this.stableIntervalMicros);
		this.nextFreeTicketMicros += waitMicros;
		this.storedPermits -= storedPermitsToSpend;
		return microsToNextFreeTicket;
	}

	abstract long storedPermitsToWaitTime(double var1, double var3);

	private void resync(long nowMicros) {
		if (nowMicros > this.nextFreeTicketMicros) {
			this.storedPermits = Math.min(this.maxPermits,
					this.storedPermits + (double) (nowMicros - this.nextFreeTicketMicros) / this.stableIntervalMicros);
			this.nextFreeTicketMicros = nowMicros;
		}

	}

	private long readSafeMicros() {
		return TimeUnit.NANOSECONDS.toMicros(this.ticker.read() - this.offsetNanos);
	}

	public String toString() {
		return String.format("RateLimiter[stableRate=%3.1fqps]", 1000000.0D / this.stableIntervalMicros);
	}
}