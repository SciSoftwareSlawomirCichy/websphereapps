package com.ibm.icu.text;

import com.ibm.icu.impl.Assert;
import java.io.IOException;
import java.io.InputStream;
import java.text.CharacterIterator;
import java.util.Stack;
import java.util.Vector;

public class DictionaryBasedBreakIterator extends RuleBasedBreakIterator {
	private boolean usingCTDictionary = false;
	private BreakDictionary dictionary;
	int[] cachedBreakPositions;
	int positionInCache;

	protected DictionaryBasedBreakIterator(InputStream compiledRules) throws IOException {
		this.fRData = RBBIDataWrapper.get(compiledRules);
		this.dictionary = null;
		this.usingCTDictionary = true;
	}

	public DictionaryBasedBreakIterator(String rules, InputStream dictionaryStream) throws IOException {
		super(rules);
		this.dictionary = new BreakDictionary(dictionaryStream);
	}

	public DictionaryBasedBreakIterator(InputStream compiledRules, InputStream dictionaryStream) throws IOException {
		this.fRData = RBBIDataWrapper.get(compiledRules);
		this.dictionary = new BreakDictionary(dictionaryStream);
	}

	public void setText(CharacterIterator newText) {
		super.setText(newText);
		this.cachedBreakPositions = null;
		this.fDictionaryCharCount = 0;
		this.positionInCache = 0;
	}

	public int first() {
		this.cachedBreakPositions = null;
		this.fDictionaryCharCount = 0;
		this.positionInCache = 0;
		return super.first();
	}

	public int last() {
		this.cachedBreakPositions = null;
		this.fDictionaryCharCount = 0;
		this.positionInCache = 0;
		return super.last();
	}

	public int previous() {
		CharacterIterator text = this.getText();
		if (this.cachedBreakPositions != null && this.positionInCache > 0) {
			--this.positionInCache;
			text.setIndex(this.cachedBreakPositions[this.positionInCache]);
			return this.cachedBreakPositions[this.positionInCache];
		} else {
			this.cachedBreakPositions = null;
			int offset = this.current();
			int result = super.previous();
			if (this.cachedBreakPositions != null) {
				this.positionInCache = this.cachedBreakPositions.length - 2;
				return result;
			} else {
				while (result < offset) {
					int nextResult = this.next();
					if (nextResult >= offset) {
						break;
					}

					result = nextResult;
				}

				if (this.cachedBreakPositions != null) {
					this.positionInCache = this.cachedBreakPositions.length - 2;
				}

				if (result != -1) {
					text.setIndex(result);
				}

				return result;
			}
		}
	}

	public int preceding(int offset) {
		CharacterIterator text = this.getText();
		checkOffset(offset, text);
		if (this.cachedBreakPositions != null && offset > this.cachedBreakPositions[0]
				&& offset <= this.cachedBreakPositions[this.cachedBreakPositions.length - 1]) {
			for (this.positionInCache = 0; this.positionInCache < this.cachedBreakPositions.length
					&& offset > this.cachedBreakPositions[this.positionInCache]; ++this.positionInCache) {
				;
			}

			--this.positionInCache;
			text.setIndex(this.cachedBreakPositions[this.positionInCache]);
			return text.getIndex();
		} else {
			this.cachedBreakPositions = null;
			return super.preceding(offset);
		}
	}

	public int following(int offset) {
		CharacterIterator text = this.getText();
		checkOffset(offset, text);
		if (this.cachedBreakPositions != null && offset >= this.cachedBreakPositions[0]
				&& offset < this.cachedBreakPositions[this.cachedBreakPositions.length - 1]) {
			for (this.positionInCache = 0; this.positionInCache < this.cachedBreakPositions.length
					&& offset >= this.cachedBreakPositions[this.positionInCache]; ++this.positionInCache) {
				;
			}

			text.setIndex(this.cachedBreakPositions[this.positionInCache]);
			return text.getIndex();
		} else {
			this.cachedBreakPositions = null;
			return super.following(offset);
		}
	}

	public int getRuleStatus() {
		return 0;
	}

	public int getRuleStatusVec(int[] fillInArray) {
		if (fillInArray != null && fillInArray.length >= 1) {
			fillInArray[0] = 0;
		}

		return 1;
	}

	protected int handleNext() {
		CharacterIterator text = this.getText();
		if (this.cachedBreakPositions == null || this.positionInCache == this.cachedBreakPositions.length - 1) {
			int startPos = text.getIndex();
			this.fDictionaryCharCount = 0;
			int result = super.handleNext();
			if (this.usingCTDictionary || this.fDictionaryCharCount <= 1 || result - startPos <= 1) {
				this.cachedBreakPositions = null;
				return result;
			}

			this.divideUpDictionaryRange(startPos, result);
		}

		if (this.cachedBreakPositions != null) {
			++this.positionInCache;
			text.setIndex(this.cachedBreakPositions[this.positionInCache]);
			return this.cachedBreakPositions[this.positionInCache];
		} else {
			Assert.assrt(false);
			return -9999;
		}
	}

	private void divideUpDictionaryRange(int startPos, int endPos) {
		CharacterIterator text = this.getText();
		text.setIndex(startPos);

		int c;
		for (c = CICurrent32(text); !this.isDictionaryChar(c); c = CINext32(text)) {
			;
		}

		Stack<Integer> currentBreakPositions = new Stack();
		Stack<Integer> possibleBreakPositions = new Stack();
		Vector<Integer> wrongBreakPositions = new Vector();
		int state = 0;
		int farthestEndPoint = text.getIndex();
		Stack<Integer> bestBreakPositions = null;
		c = CICurrent32(text);

		while (true) {
			if (this.dictionary.at(state, 0) == -1) {
				possibleBreakPositions.push(text.getIndex());
			}

			state = this.dictionary.at(state, (char) c) & '￿';
			if (state == 65535) {
				currentBreakPositions.push(text.getIndex());
				break;
			}

			if (state != 0 && text.getIndex() < endPos) {
				c = CINext32(text);
			} else {
				if (text.getIndex() > farthestEndPoint) {
					farthestEndPoint = text.getIndex();
					bestBreakPositions = (Stack) ((Stack) currentBreakPositions.clone());
				}

				while (!possibleBreakPositions.isEmpty()
						&& wrongBreakPositions.contains(possibleBreakPositions.peek())) {
					possibleBreakPositions.pop();
				}

				if (possibleBreakPositions.isEmpty()) {
					if (bestBreakPositions != null) {
						currentBreakPositions = bestBreakPositions;
						if (farthestEndPoint >= endPos) {
							break;
						}

						text.setIndex(farthestEndPoint + 1);
					} else {
						if ((currentBreakPositions.size() == 0
								|| (Integer) currentBreakPositions.peek() != text.getIndex())
								&& text.getIndex() != startPos) {
							currentBreakPositions.push(text.getIndex());
						}

						CINext32(text);
						currentBreakPositions.push(text.getIndex());
					}
				} else {
					Integer temp = (Integer) possibleBreakPositions.pop();
					Integer temp2 = null;

					while (!currentBreakPositions.isEmpty() && temp < (Integer) currentBreakPositions.peek()) {
						temp2 = (Integer) currentBreakPositions.pop();
						wrongBreakPositions.addElement(temp2);
					}

					currentBreakPositions.push(temp);
					text.setIndex((Integer) currentBreakPositions.peek());
				}

				c = CICurrent32(text);
				state = 0;
				if (text.getIndex() >= endPos) {
					break;
				}
			}
		}

		if (!currentBreakPositions.isEmpty()) {
			currentBreakPositions.pop();
		}

		currentBreakPositions.push(endPos);
		this.cachedBreakPositions = new int[currentBreakPositions.size() + 1];
		this.cachedBreakPositions[0] = startPos;

		for (int i = 0; i < currentBreakPositions.size(); ++i) {
			this.cachedBreakPositions[i + 1] = (Integer) currentBreakPositions.elementAt(i);
		}

		this.positionInCache = 0;
	}
}