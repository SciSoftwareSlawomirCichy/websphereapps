package com.ibm.ws.wim.configmodel;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.eclipse.emf.common.util.AbstractEnumerator;

public final class SubscriberType extends AbstractEnumerator {
	public static final int NOTIFICATION_SUBSCRIBER = 0;
	public static final int MODIFICATION_SUBSCRIBER = 1;
	public static final SubscriberType NOTIFICATION_SUBSCRIBER_LITERAL = new SubscriberType(0,
			"NotificationSubscriber");
	public static final SubscriberType MODIFICATION_SUBSCRIBER_LITERAL = new SubscriberType(1,
			"ModificationSubscriber");
	private static final SubscriberType[] VALUES_ARRAY;
	public static final List VALUES;

	public static SubscriberType get(String var0) {
		for (int var1 = 0; var1 < VALUES_ARRAY.length; ++var1) {
			SubscriberType var2 = VALUES_ARRAY[var1];
			if (var2.toString().equals(var0)) {
				return var2;
			}
		}

		return null;
	}

	public static SubscriberType get(int var0) {
		switch (var0) {
			case 0 :
				return NOTIFICATION_SUBSCRIBER_LITERAL;
			case 1 :
				return MODIFICATION_SUBSCRIBER_LITERAL;
			default :
				return null;
		}
	}

	private SubscriberType(int var1, String var2) {
		super(var1, var2);
	}

	static {
		VALUES_ARRAY = new SubscriberType[]{NOTIFICATION_SUBSCRIBER_LITERAL, MODIFICATION_SUBSCRIBER_LITERAL};
		VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));
	}
}