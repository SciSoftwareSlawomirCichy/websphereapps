package com.ibm.ejs.j2c;

public interface HandleListInterface {
	HandleList add(HCMDetails var1);

	void remove(Object var1);

	void reAssociate() throws Exception;

	void parkHandle() throws Exception;
}