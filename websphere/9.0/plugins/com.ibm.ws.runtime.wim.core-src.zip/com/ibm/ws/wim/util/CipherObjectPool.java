package com.ibm.ws.wim.util;

import com.ibm.websphere.wim.ras.WIMLogger;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;

public class CipherObjectPool extends WIMObjectPool {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = CipherObjectPool.class.getName();
	private static final Logger trcLogger;

	public CipherObjectPool(String var1, long var2) {
		super(var1, var2);
	}

	protected Object create() {
		Cipher var1 = null;

		try {
			var1 = Cipher.getInstance("DESede/CBC/PKCS5Padding");
		} catch (Exception var3) {
			trcLogger.log(Level.FINER, "Fatal exception in creating TripleDESCipher");
			var3.printStackTrace();
		}

		return var1;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}