package com.ibm.ejs.container.passivator;

import com.ibm.ejs.container.BusinessLocalWrapper;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSLocalWrapper;
import com.ibm.ejs.container.EJSWrapperBase;
import com.ibm.ejs.container.EJSWrapperCommon;
import com.ibm.ejs.container.LocalBeanWrapper;
import com.ibm.ejs.container.SerializedStub;
import com.ibm.ejs.container.StatefulBeanO;
import com.ibm.ejs.container.WrapperProxy;
import com.ibm.ejs.container.WrapperProxyState;
import com.ibm.ejs.container.passivator.NewOutputStream.1;
import com.ibm.ejs.container.util.SerializableByteArray;
import com.ibm.ejs.container.util.StatefulBeanOReplacement;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.util.AccessController;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

class NewOutputStream extends ObjectOutputStream {
	private static final String CLASS_NAME = "com.ibm.ejs.container.passivator.NewOutputStream";
	private static final TraceComponent tc = Tr.register("com.ibm.ejs.container.passivator.NewOutputStream",
			"EJBContainer", "com.ibm.ejs.container.container");

	NewOutputStream(OutputStream os, EJSContainer container) throws IOException {
      super(os);
      boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.entry(tc, "NewOutputStream: " + os);
      }

      AccessController.doPrivileged(new 1(this));
      if (isTraceOn && tc.isEntryEnabled()) {
         Tr.exit(tc, "NewOutputStream");
      }

   }

	protected Object replaceObject(Object obj) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			String className = obj == null ? null : obj.getClass().getName();
			Tr.entry(tc, "replaceObject: " + className);
		}

		SerializableByteArray replace;
		if (obj instanceof WrapperProxy) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "replacing WrapperProxy");
			}

			WrapperProxyState state = WrapperProxyState.getWrapperProxyState(obj);
			replace = new SerializableByteArray(state);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "replaceObject: " + replace);
			}

			return replace;
		} else if (!(obj instanceof EJSLocalWrapper) && !(obj instanceof BusinessLocalWrapper)) {
			if (obj instanceof LocalBeanWrapper) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "replacing LocalBeanWrapper");
				}

				EJSWrapperBase wrapperBase = EJSWrapperCommon.getLocalBeanWrapperBase((LocalBeanWrapper) obj);
				replace = new SerializableByteArray(wrapperBase);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "replaceObject: " + replace);
				}

				return replace;
			} else if (obj instanceof StatefulBeanO) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "replacing StatefulBeanO");
				}

				Object replace = new StatefulBeanOReplacement();
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "replaceObject: " + replace);
				}

				return replace;
			} else if (obj instanceof PassivatorSerializable) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "replacing PassivatorSerializable");
				}

				Object replace = ((PassivatorSerializable) obj).getSerializableObject();
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "replaceObject: " + replace);
				}

				return replace;
			} else if (obj instanceof SerializedStub) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "replacing SerializedStub");
				}

				Object replace = new SerializedStubString((SerializedStub) obj);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "replaceObject: " + replace);
				}

				return replace;
			} else {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "replaceObject: original object");
				}

				return obj;
			}
		} else {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "replacing EJSLocalWrapper/BusinessLocalWrapper");
			}

			replace = new SerializableByteArray((EJSWrapperBase) obj);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "replaceObject: " + replace);
			}

			return replace;
		}
	}
}