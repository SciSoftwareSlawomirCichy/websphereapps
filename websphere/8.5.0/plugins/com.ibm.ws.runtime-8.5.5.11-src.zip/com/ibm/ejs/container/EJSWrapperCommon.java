package com.ibm.ejs.container;

import com.ibm.ejs.container.EJSWrapperCommon.1;
import com.ibm.ejs.container.WrapperProxyState.BusinessLocal;
import com.ibm.ejs.container.WrapperProxyState.LocalHome;
import com.ibm.ejs.container.WrapperProxyState.LocalObject;
import com.ibm.ejs.container.util.DeploymentUtil;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.container.util.NameUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.ejs.util.cache.Bucket;
import com.ibm.ejs.util.cache.Element;
import com.ibm.ejs.util.cache.WrapperBucket;
import com.ibm.ejs.util.dopriv.SetAccessiblePrivilegedAction;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import com.ibm.ws.ejbcontainer.failover.SfFailoverClient;
import com.ibm.ws.ejbcontainer.jitdeploy.EJBWrapperType;
import com.ibm.ws.ejbcontainer.jitdeploy.JITDeploy;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.util.ThreadContextAccessor;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.rmi.NoSuchObjectException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.security.PrivilegedActionException;
import javax.ejb.EJBException;
import javax.ejb.EJBLocalObject;
import javax.rmi.PortableRemoteObject;

public final class EJSWrapperCommon extends Element {
	private static final TraceComponent tc = Tr.register(EJSWrapperCommon.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.EJSWrapperCommon";
	private static final boolean isZOS = EJSPlatformHelper.isZOS();
	protected EJSWrapper remoteWrapper;
	private EJSRemoteWrapper ivRemoteObject;
	protected EJSLocalWrapper localWrapper;
	private EJBLocalObject localProxy;
	private WrapperProxyState localWrapperProxyState;
	private Object[] ivBusinessLocal;
	private Object[] ivBusinessLocalProxies;
	private WrapperProxyState[] ivBusinessLocalWrapperProxyStates;
	private BusinessRemoteWrapper[] ivBusinessRemote;
	private boolean[] ivBusinessRemoteRegistered;
	private boolean isRemoteRegistered;
	StatefulBeanO ivCachedBeanO;
	private BeanId ivBeanId;
	private BeanMetaData ivBMD;
	private static final ThreadContextAccessor svThreadContextAccessor = (ThreadContextAccessor) AccessController
			.doPrivileged(ThreadContextAccessor.getPrivilegedAction());

	public EJSWrapperCommon(Class<?> remoteClass, Class<?> localClass, BeanId id, BeanMetaData bmd,
			EJBPMICollaborator pmiBean, EJSContainer container, WrapperManager wrapperManager, boolean isHome)
			throws RemoteException {
		super(id.getByteArray());
		this.ivBeanId = id;
		String className = null;

		try {
			this.ivBMD = bmd;
			SfFailoverClient bRemote;
			if (remoteClass != null) {
				className = remoteClass.getName();
				this.remoteWrapper = (EJSWrapper) remoteClass.newInstance();
				this.ivRemoteObject = this.remoteWrapper;
				this.remoteWrapper.beanId = id;
				this.remoteWrapper.bmd = bmd;
				this.remoteWrapper.methodInfos = isHome ? bmd.homeMethodInfos : bmd.methodInfos;
				this.remoteWrapper.isolationAttrs = isHome ? bmd.homeIsolationAttrs : bmd.isolationAttrs;
				this.remoteWrapper.methodNames = isHome ? bmd.homeMethodNames : bmd.methodNames;
				this.remoteWrapper.container = container;
				this.remoteWrapper.wrapperManager = wrapperManager;
				this.remoteWrapper.ivPmiBean = pmiBean;
				this.remoteWrapper.ivCommon = this;
				this.remoteWrapper.isManagedWrapper = true;
				this.remoteWrapper.ivInterface = isHome ? WrapperInterface.HOME : WrapperInterface.REMOTE;
				if (!isHome && bmd.isStatefulSessionBean()) {
					this.remoteWrapper.ivCluster = null;
					bRemote = bmd.ivSfFailoverClient;
					if (bRemote != null) {
						this.remoteWrapper.ivCluster = bRemote.getWLMIdentity(id);
					}

					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "SFSB WLM Cluster Identity from failover: " + this.remoteWrapper.ivCluster);
					}
				} else {
					this.remoteWrapper.ivCluster = bmd.ivCluster;
				}
			}

			if (localClass != null) {
				className = localClass.getName();
				this.localWrapper = (EJSLocalWrapper) localClass.newInstance();
				this.localWrapper.beanId = id;
				this.localWrapper.bmd = bmd;
				this.localWrapper.methodInfos = isHome ? bmd.localHomeMethodInfos : bmd.localMethodInfos;
				this.localWrapper.methodNames = isHome ? bmd.localHomeMethodNames : bmd.localMethodNames;
				this.localWrapper.container = container;
				this.localWrapper.wrapperManager = wrapperManager;
				this.localWrapper.ivPmiBean = pmiBean;
				this.localWrapper.ivCommon = this;
				this.localWrapper.isManagedWrapper = false;
				this.localWrapper.ivInterface = isHome ? WrapperInterface.LOCAL_HOME : WrapperInterface.LOCAL;
				this.localProxy = this.localWrapper;
				if (bmd.ivIndirectLocalProxies) {
					this.localWrapperProxyState = (WrapperProxyState) (isHome
							? new LocalHome(bmd.getHome(), this.localWrapper)
							: new LocalObject(bmd.getHome(), this.localWrapper));
					Constructor<?> localProxyCtor = isHome
							? bmd.homeLocalImplProxyConstructor
							: bmd.localImplProxyConstructor;
					this.localProxy = (EJBLocalObject) localProxyCtor.newInstance(this.localWrapperProxyState);
				}
			}

			int i;
			if (!isHome && bmd.ivBusinessLocalImplClasses != null) {
				bRemote = null;
				BusinessLocalWrapper bLocal = null;
				i = bmd.ivBusinessLocalImplClasses.length;
				this.ivBusinessLocal = new Object[i];
				this.ivBusinessLocalProxies = this.ivBusinessLocal;
				if (bmd.ivIndirectLocalProxies) {
					this.ivBusinessLocalProxies = new Object[i];
					this.ivBusinessLocalWrapperProxyStates = new WrapperProxyState[i];
				}

				for (int i = 0; i < i; ++i) {
					className = bmd.ivBusinessLocalImplClasses[i].getName();
					Object wrapper = bmd.ivBusinessLocalImplClasses[i].newInstance();
					if (i == 0 && bmd.ivLocalBean) {
						bLocal = new BusinessLocalWrapper();
						bmd.ivLocalBeanContainerField.set(wrapper, container);
						bmd.ivLocalBeanWrapperField.set(wrapper, bLocal);
					} else {
						bLocal = (BusinessLocalWrapper) wrapper;
					}

					bLocal.beanId = id;
					bLocal.bmd = bmd;
					bLocal.methodInfos = bmd.localMethodInfos;
					bLocal.methodNames = bmd.localMethodNames;
					bLocal.container = container;
					bLocal.wrapperManager = wrapperManager;
					bLocal.ivPmiBean = pmiBean;
					bLocal.ivCommon = this;
					bLocal.isManagedWrapper = false;
					bLocal.ivInterface = WrapperInterface.BUSINESS_LOCAL;
					bLocal.ivBusinessInterfaceIndex = i;
					this.ivBusinessLocal[i] = wrapper;
					if (bmd.ivIndirectLocalProxies) {
						WrapperProxyState state = new BusinessLocal(bmd.getHome(), id, this.ivBusinessLocal[i],
								bmd.ivBusinessLocalInterfaceClasses[i], i);
						this.ivBusinessLocalWrapperProxyStates[i] = state;
						this.ivBusinessLocalProxies[i] = bmd.ivBusinessLocalImplProxyConstructors[i].newInstance(state);
					}
				}
			}

			if (!isHome && bmd.ivBusinessRemoteImplClasses != null) {
				bRemote = null;
				int numRemoteWrappers = bmd.ivBusinessRemoteImplClasses.length;
				this.ivBusinessRemote = new BusinessRemoteWrapper[numRemoteWrappers];
				this.ivBusinessRemoteRegistered = new boolean[numRemoteWrappers];

				for (i = 0; i < numRemoteWrappers; ++i) {
					className = bmd.ivBusinessRemoteImplClasses[i].getName();
					BusinessRemoteWrapper bRemote = (BusinessRemoteWrapper) bmd.ivBusinessRemoteImplClasses[i]
							.newInstance();
					bRemote.beanId = id;
					bRemote.bmd = bmd;
					bRemote.methodInfos = bmd.methodInfos;
					bRemote.isolationAttrs = bmd.isolationAttrs;
					bRemote.methodNames = bmd.methodNames;
					bRemote.container = container;
					bRemote.wrapperManager = wrapperManager;
					bRemote.ivPmiBean = pmiBean;
					bRemote.ivCommon = this;
					bRemote.isManagedWrapper = true;
					if (Remote.class.isAssignableFrom(bmd.ivBusinessRemoteInterfaceClasses[i])) {
						bRemote.ivInterface = WrapperInterface.BUSINESS_RMI_REMOTE;
					} else {
						bRemote.ivInterface = WrapperInterface.BUSINESS_REMOTE;
					}

					bRemote.ivBusinessInterfaceIndex = i;
					if (!bmd.isStatefulSessionBean()) {
						bRemote.ivCluster = bmd.ivCluster;
					} else {
						bRemote.ivCluster = null;
						SfFailoverClient failover = bmd.ivSfFailoverClient;
						if (failover != null) {
							bRemote.ivCluster = failover.getWLMIdentity(id);
						}

						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "SFSB WLM Cluster Identity from failover: " + bRemote.ivCluster);
						}
					}

					this.ivBusinessRemote[i] = bRemote;
				}
			}

		} catch (Exception var15) {
			FFDCFilter.processException(var15, "com.ibm.ejs.container.EJSWrapperCommon.EJSWrapperCommon", "123", this);
			throw new ContainerException(className, var15);
		}
	}

	public static EJSWrapperBase getLocalBeanWrapperBase(Object obj) {
		try {
			Field wrapperBaseField = obj.getClass().getDeclaredField("ivWrapperBase");
			SetAccessiblePrivilegedAction privilegedFieldAction = new SetAccessiblePrivilegedAction(wrapperBaseField,
					true);
			AccessController.doPrivileged(privilegedFieldAction);
			return (EJSWrapperBase) wrapperBaseField.get(obj);
		} catch (NoSuchFieldException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.EJSWrapperCommon.getLocalBeanWrapperBase", "417");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getLocalBeanWrapperBase: " + var3);
			}

			throw ExceptionUtil.EJBException("Malformed LocalBeanWrapper.", var3);
		} catch (IllegalAccessException var4) {
			FFDCFilter.processException(var4, "com.ibm.ejs.container.EJSWrapperCommon.getLocalBeanWrapperBase", "424");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getLocalBeanWrapperBase: " + var4);
			}

			throw ExceptionUtil.EJBException("Malformed LocalBeanWrapper.", var4);
		} catch (PrivilegedActionException var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.EJSWrapperCommon.getLocalBeanWrapperBase", "431");
			Exception ex = var5.getException();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getLocalBeanWrapperBase: " + ex);
			}

			throw ExceptionUtil.EJBException("Malformed LocalBeanWrapper.", ex);
		}
	}

	public static BusinessLocalWrapperProxy getLocalBeanWrapperProxy(Object obj) {
		try {
			Field wrapperBaseField = obj.getClass().getDeclaredField("ivProxy");
			SetAccessiblePrivilegedAction privilegedFieldAction = new SetAccessiblePrivilegedAction(wrapperBaseField,
					true);
			AccessController.doPrivileged(privilegedFieldAction);
			return (BusinessLocalWrapperProxy) wrapperBaseField.get(obj);
		} catch (NoSuchFieldException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.EJSWrapperCommon.getLocalBeanWrapperProxy", "534");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getLocalBeanWrapperProxy: " + var3);
			}

			throw ExceptionUtil.EJBException("Malformed LocalBeanWrapperProxy.", var3);
		} catch (IllegalAccessException var4) {
			FFDCFilter.processException(var4, "com.ibm.ejs.container.EJSWrapperCommon.getLocalBeanWrapperProxy", "541");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getLocalBeanWrapperProxy: " + var4);
			}

			throw ExceptionUtil.EJBException("Malformed LocalBeanWrapperProxy.", var4);
		} catch (PrivilegedActionException var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.EJSWrapperCommon.getLocalBeanWrapperProxy", "548");
			Exception ex = var5.getException();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.exit(tc, "getLocalBeanWrapperProxy: " + ex);
			}

			throw ExceptionUtil.EJBException("Malformed LocalBeanWrapperProxy.", ex);
		}
	}

	public EJSWrapperCommon(EJSRemoteWrapper ejbFactory, BeanId beanId, Object cluster, EJSContainer container) {
		super(beanId.getByteArray());
		this.ivBeanId = beanId;
		this.ivBMD = null;
		this.ivRemoteObject = ejbFactory;
		this.ivRemoteObject.beanId = beanId;
		this.ivRemoteObject.bmd = null;
		this.ivRemoteObject.methodInfos = null;
		this.ivRemoteObject.methodNames = null;
		this.ivRemoteObject.isolationAttrs = null;
		this.ivRemoteObject.container = container;
		this.ivRemoteObject.wrapperManager = container.wrapperManager;
		this.ivRemoteObject.ivPmiBean = null;
		this.ivRemoteObject.ivCommon = this;
		this.ivRemoteObject.isManagedWrapper = true;
		this.ivRemoteObject.ivInterface = WrapperInterface.HOME;
		this.ivRemoteObject.ivCluster = cluster;
	}

	public EJSWrapper getRemoteWrapper() {
		if (this.remoteWrapper == null) {
			throw new IllegalStateException("Remote interface not defined");
		} else {
			this.registerServant();
			return this.remoteWrapper;
		}
	}

	public EJSRemoteWrapper getRemoteObject() {
		if (this.ivRemoteObject == null) {
			throw new IllegalStateException("Remote interface not defined");
		} else {
			this.registerServant();
			return this.ivRemoteObject;
		}
	}

	protected void registerServant() {
		if (this.ivRemoteObject != null) {
			EJSRemoteWrapper var1 = this.ivRemoteObject;
			synchronized (this.ivRemoteObject) {
				if (!this.isRemoteRegistered) {
					try {
						if (!isZOS) {
							Object originalLoader = ThreadContextAccessor.UNCHANGED;

							try {
								if (this.ivBMD != null) {
									originalLoader = EJBThreadData.svThreadContextAccessor
											.pushContextClassLoaderForUnprivileged(this.ivBMD.classLoader);
									if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
										if (originalLoader != ThreadContextAccessor.UNCHANGED) {
											Tr.debug(tc, "registerServant : old ClassLoader = " + originalLoader);
											Tr.debug(tc,
													"registerServant : new ClassLoader = " + this.ivBMD.classLoader);
										} else {
											Tr.debug(tc, "registerServant : current ClassLoader = "
													+ this.ivBMD.classLoader);
										}
									}
								}

								this.ivRemoteObject.container.getEJBRuntime().registerServant(
										this.ivRemoteObject.beanId.getByteArray(), this.ivRemoteObject);
							} finally {
								EJBThreadData.svThreadContextAccessor
										.popContextClassLoaderForUnprivileged(originalLoader);
							}
						}

						this.isRemoteRegistered = true;
					} catch (Exception var9) {
						FFDCFilter.processException(var9, "com.ibm.ejs.container.EJSWrapperCommon.registerServant",
								"184", this);
						if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
							Tr.event(tc, "Failed to register wrapper instance",
									new Object[]{this.ivRemoteObject, var9});
						}
					}
				}
			}
		}

	}

	private void registerServant(BusinessRemoteWrapper wrapper, int i) {
		synchronized (wrapper) {
			if (!this.ivBusinessRemoteRegistered[i]) {
				try {
					if (!isZOS) {
						WrapperId wrapperId = new WrapperId(wrapper.beanId.getByteArrayBytes(),
								wrapper.bmd.ivBusinessRemoteInterfaceClasses[i].getName(), i);
						Object originalLoader = ThreadContextAccessor.UNCHANGED;

						try {
							if (this.ivBMD != null) {
								originalLoader = EJBThreadData.svThreadContextAccessor
										.pushContextClassLoaderForUnprivileged(this.ivBMD.classLoader);
								if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
									if (originalLoader != ThreadContextAccessor.UNCHANGED) {
										Tr.debug(tc, "registerServant : old ClassLoader = " + originalLoader);
										Tr.debug(tc, "registerServant : new ClassLoader = " + this.ivBMD.classLoader);
									} else {
										Tr.debug(tc,
												"registerServant : current ClassLoader = " + this.ivBMD.classLoader);
									}
								}
							}

							wrapper.container.getEJBRuntime().registerServant(wrapperId, wrapper);
						} finally {
							EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(originalLoader);
						}
					}

					this.ivBusinessRemoteRegistered[i] = true;
				} catch (Throwable var12) {
					FFDCFilter.processException(var12, "com.ibm.ejs.container.EJSWrapperCommon.registerServant", "439",
							this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Failed to register wrapper instance", new Object[]{wrapper, var12});
					}
				}
			}

		}
	}

	protected void disconnect() {
		if (this.localWrapperProxyState != null) {
			this.localWrapperProxyState.disconnect();
		}

		int i;
		if (this.ivBusinessLocalWrapperProxyStates != null) {
			WrapperProxyState[] arr$ = this.ivBusinessLocalWrapperProxyStates;
			i = arr$.length;

			for (int i$ = 0; i$ < i; ++i$) {
				WrapperProxyState state = arr$[i$];
				state.disconnect();
			}
		}

		if (this.ivRemoteObject != null) {
			EJSRemoteWrapper var11 = this.ivRemoteObject;
			synchronized (this.ivRemoteObject) {
				if (this.isRemoteRegistered) {
					try {
						if (!isZOS || this.ivRemoteObject.intie != null) {
							this.ivRemoteObject.container.getEJBRuntime().unregisterServant(this.ivRemoteObject);
						}

						this.isRemoteRegistered = false;
					} catch (Exception var9) {
						FFDCFilter.processException(var9, "com.ibm.ejs.container.EJSWrapperCommon.unregisterServant",
								"207", this);
						if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
							Tr.event(tc, "Failed to unregister wrapper instance",
									new Object[]{this.ivRemoteObject, var9});
						}
					}
				}
			}
		}

		if (this.ivBusinessRemote != null) {
			int numWrappers = this.ivBusinessRemote.length;

			for (i = 0; i < numWrappers; ++i) {
				BusinessRemoteWrapper wrapper = this.ivBusinessRemote[i];
				synchronized (wrapper) {
					if (this.ivBusinessRemoteRegistered[i]) {
						try {
							if (!isZOS || wrapper.intie != null) {
								wrapper.container.getEJBRuntime().unregisterServant(wrapper);
							}

							this.ivBusinessRemoteRegistered[i] = false;
						} catch (Throwable var7) {
							FFDCFilter.processException(var7,
									"com.ibm.ejs.container.EJSWrapperCommon.unregisterServant", "516", this);
							if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
								Tr.event(tc, "Failed to unregister wrapper instance", new Object[]{wrapper, var7});
							}
						}
					}
				}
			}
		}

	}

	public EJBLocalObject getLocalObject() {
		if (this.localProxy != null) {
			if (this.localWrapperProxyState != null && this.localWrapperProxyState.ivWrapper == null) {
				this.localWrapperProxyState.connect(this.ivBeanId, this.localWrapper);
			}

			return this.localProxy;
		} else {
			throw new IllegalStateException("Local interface not defined");
		}
	}

	public EJSLocalWrapper getLocalWrapper() {
		if (this.localWrapper == null) {
			throw new IllegalStateException("Local interface not defined");
		} else {
			return this.localWrapper;
		}
	}

	public WrapperProxyState getLocalWrapperProxyState() {
		return this.localWrapperProxyState;
	}

	public Object getLocalBusinessObject(int interfaceIndex) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc,
					"getLocalBusinessObject : " + this.ivBusinessLocalProxies[interfaceIndex].getClass().getName());
		}

		if (this.ivBusinessLocalWrapperProxyStates != null
				&& this.ivBusinessLocalWrapperProxyStates[interfaceIndex].ivWrapper == null) {
			this.ivBusinessLocalWrapperProxyStates[interfaceIndex].connect(this.ivBeanId,
					this.ivBusinessLocal[interfaceIndex]);
		}

		return this.ivBusinessLocalProxies[interfaceIndex];
	}

	public Object getRemoteBusinessObject(int interfaceIndex) throws RemoteException {
		Class<?>[] bInterfaceClasses = this.ivBMD.ivBusinessRemoteInterfaceClasses;
		BusinessRemoteWrapper wrapper = this.ivBusinessRemote[interfaceIndex];
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getRemoteBusinessObject : " + wrapper.getClass().getName());
		}

		this.registerServant(wrapper, interfaceIndex);
		ClassLoader classLoader = this.ivBMD.classLoader;
		Object result = toStub(wrapper, classLoader, bInterfaceClasses[interfaceIndex]);
		return result;
	}

	public static Remote toStub(BusinessRemoteWrapper remote, ClassLoader classLoader, Class<?> businessClass) throws NoSuchObjectException {
      if (svThreadContextAccessor.isPrivileged()) {
         return toStubPrivileged(remote, classLoader, businessClass);
      } else {
         try {
            return (Remote)AccessController.doPrivileged(new 1(remote, classLoader, businessClass));
         } catch (PrivilegedActionException var5) {
            Throwable cause = var5.getCause();
            if (cause instanceof NoSuchObjectException) {
               throw (NoSuchObjectException)cause;
            } else {
               throw new Error(cause);
            }
         }
      }
   }

	static Remote toStubPrivileged(Remote remote, ClassLoader classLoader, Class<?> businessClass)
			throws NoSuchObjectException {
		Thread currentThread = Thread.currentThread();
		ClassLoader contextClassLoader = svThreadContextAccessor.getContextClassLoader(currentThread);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "calling toStub with EJB class loader");
		}

		Remote stub;
		if (contextClassLoader == classLoader) {
			stub = PortableRemoteObject.toStub(remote);
		} else {
			svThreadContextAccessor.setContextClassLoader(currentThread, classLoader);

			try {
				stub = PortableRemoteObject.toStub(remote);
			} finally {
				svThreadContextAccessor.setContextClassLoader(currentThread, contextClassLoader);
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "calling narrow with context class loader");
			}

			try {
				return (Remote) PortableRemoteObject.narrow(stub,
						contextClassLoader.loadClass(businessClass.getName()));
			} catch (Exception var10) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "ignoring narrow exception", var10);
				}
			}
		}

		return stub;
	}

	public WrapperProxyState getBusinessObjectWrapperProxyState(Class<?> businessInterface) {
		if (this.ivBusinessLocalWrapperProxyStates == null) {
			return null;
		} else {
			Class<?>[] bInterfaces = this.ivBMD.ivBusinessLocalInterfaceClasses;
			if (bInterfaces != null) {
				int numInterfaces = bInterfaces.length;

				for (int i = 0; i < numInterfaces; ++i) {
					if (bInterfaces[i] == businessInterface) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "getBusinessObjectWrapperProxyState : "
									+ this.ivBusinessLocal[i].getClass().getName());
						}

						return this.ivBusinessLocalWrapperProxyStates[i];
					}
				}
			}

			throw new IllegalStateException(
					"Requested local business interface not found : " + businessInterface.getName());
		}
	}

	public BusinessRemoteWrapper getRemoteBusinessWrapper(WrapperId wrapperId) {
		int remoteIndex = wrapperId.ivInterfaceIndex;
		BusinessRemoteWrapper wrapper = null;
		String wrapperInterfaceName = "";
		if (remoteIndex < this.ivBusinessRemote.length) {
			wrapper = this.ivBusinessRemote[remoteIndex];
			wrapperInterfaceName = this.ivBMD.ivBusinessRemoteInterfaceClasses[remoteIndex].getName();
		}

		String interfaceName = wrapperId.ivInterfaceClassName;
		if (wrapper == null || !wrapperInterfaceName.equals(interfaceName)) {
			wrapper = null;

			for (int i = 0; i < this.ivBusinessRemote.length; ++i) {
				wrapperInterfaceName = this.ivBMD.ivBusinessRemoteInterfaceClasses[i].getName();
				if (wrapperInterfaceName.equals(interfaceName)) {
					remoteIndex = i;
					wrapper = this.ivBusinessRemote[i];
					wrapperId.ivInterfaceIndex = i;
					break;
				}
			}

			if (wrapper == null) {
				throw new IllegalStateException("Remote " + interfaceName + " interface not defined");
			}
		}

		this.registerServant(wrapper, remoteIndex);
		return wrapper;
	}

	public Object getAggregateLocalWrapper(EJSHome home) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (this.ivBusinessLocal == null) {
			J2EEName j2eeName = this.ivBeanId.getJ2EEName();
			throw new EJBException("The " + j2eeName.getComponent() + " bean in the " + j2eeName.getModule()
					+ " module of the " + j2eeName.getApplication() + " application has no business local interfaces.");
		} else if (this.ivBusinessLocal.length == 1) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "getAggregateLocalWrapper: single interface: " + Util.identity(this.ivBusinessLocal[0]));
			}

			return this.ivBusinessLocal[0];
		} else {
			String wrapperClassName = null;

			try {
				BeanMetaData bLocal = this.ivBMD;
				synchronized (this.ivBMD) {
					if (this.ivBMD.ivAggregateLocalImplClass == null) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"getAggregateLocalWrapper: generating wrapper class for " + this.ivBMD.j2eeName);
						}

						Method[] localBeanMethods = DeploymentUtil.getMethods(this.ivBMD.localInterfaceClass,
								this.ivBMD.ivBusinessLocalInterfaceClasses);
						wrapperClassName = NameUtil
								.getAggregateLocalImplClassName(this.ivBMD.ivBusinessLocalImplClasses[0].getName());
						this.ivBMD.ivAggregateLocalImplClass = JITDeploy.generateEJBWrapper(this.ivBMD.classLoader,
								wrapperClassName, this.ivBMD.ivBusinessLocalInterfaceClasses,
								this.ivBMD.ivLocalBean ? EJBWrapperType.LOCAL_BEAN : EJBWrapperType.BUSINESS_LOCAL,
								localBeanMethods, this.ivBMD.localMethodInfos, this.ivBMD.enterpriseBeanClassName,
								this.ivBMD.j2eeName.toString(), this.ivBMD.container.getEJBRuntime().getClassDefiner());
						wrapperClassName = null;
					}
				}

				bLocal = null;
				Object wrapper = this.ivBMD.ivAggregateLocalImplClass.newInstance();
				BusinessLocalWrapper bLocal;
				if (this.ivBMD.ivLocalBean) {
					Field containerField = this.ivBMD.ivAggregateLocalImplClass.getDeclaredField("container");
					containerField.setAccessible(true);
					Field wrapperField = this.ivBMD.ivAggregateLocalImplClass.getDeclaredField("ivWrapperBase");
					wrapperField.setAccessible(true);
					bLocal = new BusinessLocalWrapper();
					containerField.set(wrapper, home.container);
					wrapperField.set(wrapper, bLocal);
				} else {
					bLocal = (BusinessLocalWrapper) wrapper;
				}

				bLocal.beanId = this.ivBeanId;
				bLocal.bmd = this.ivBMD;
				bLocal.methodInfos = this.ivBMD.localMethodInfos;
				bLocal.methodNames = this.ivBMD.localMethodNames;
				bLocal.container = home.container;
				bLocal.wrapperManager = home.wrapperManager;
				bLocal.ivPmiBean = home.pmiBean;
				bLocal.ivCommon = this;
				bLocal.isManagedWrapper = false;
				bLocal.ivInterface = WrapperInterface.BUSINESS_LOCAL;
				bLocal.ivBusinessInterfaceIndex = -2;
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "getAggregateLocalWrapper: " + Util.identity(wrapper));
				}

				return wrapper;
			} catch (Exception var9) {
				FFDCFilter.processException(var9, "com.ibm.ejs.container.EJSWrapperCommon.getAggregateLocalWrapper",
						"970", this);
				if (wrapperClassName != null) {
					throw ExceptionUtil.EJBException("Failed to generate aggregate local reference class "
							+ wrapperClassName + " for bean " + this.ivBMD.j2eeName + " : ", var9);
				} else {
					throw ExceptionUtil.EJBException(
							"Failed to create aggregate local reference for bean " + this.ivBMD.j2eeName + " : ", var9);
				}
			}
		}
	}

	public BeanId getBeanId() {
		return this.ivBeanId;
	}

	public boolean pinOnce() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "pinOnce: " + this.ivBeanId);
		}

		boolean pinnedOnce = false;
		Bucket var2 = this.ivBucket;
		synchronized (this.ivBucket) {
			if (this.pinned == 0) {
				++this.pinned;
				pinnedOnce = true;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "pinOnce : " + this.pinned);
		}

		return pinnedOnce;
	}

	public void unpin() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "unpin: " + this.ivBeanId);
		}

		Bucket var1 = this.ivBucket;
		synchronized (this.ivBucket) {
			if (this.pinned > 0) {
				--this.pinned;
				((WrapperBucket) this.ivBucket).ivWrapperCache.touch(this);
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "unpin: Not pinned : " + this.pinned);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "unpin");
		}

	}

	public boolean inCache() {
		boolean inCache = false;
		Bucket var2 = this.ivBucket;
		synchronized (this.ivBucket) {
			if (this.pinned >= 0) {
				((WrapperBucket) this.ivBucket).ivWrapperCache.touch(this);
				inCache = true;
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "touch: inCache = " + inCache + ", " + this.ivBeanId);
		}

		return inCache;
	}

	public String toString() {
		String businessRemote = "NoBRemote, ";
		int len$;
		if (this.ivBusinessRemote != null) {
			businessRemote = "BR: ";
			BusinessRemoteWrapper[] arr$ = this.ivBusinessRemote;
			int len$ = arr$.length;

			for (len$ = 0; len$ < len$; ++len$) {
				BusinessRemoteWrapper wrapper = arr$[len$];
				businessRemote = businessRemote + wrapper.getClass().getName();
				businessRemote = businessRemote + ", ";
			}
		}

		String businessLocal = "NoBLocal, ";
		if (this.ivBusinessLocal != null) {
			businessLocal = this.ivBusinessLocalWrapperProxyStates == null ? "BL: " : "BLP: ";
			Object[] arr$ = this.ivBusinessLocal;
			len$ = arr$.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				Object wrapper = arr$[i$];
				businessLocal = businessLocal + wrapper.getClass().getName();
				businessLocal = businessLocal + ", ";
			}
		}

		return "EJSWrapperCommon(" + this.ivBeanId + ", "
				+ (this.ivRemoteObject != null ? this.ivRemoteObject.getClass().getName() : "NoRemote") + ", "
				+ (this.localWrapper != null ? this.localWrapper.getClass().getName() : "NoLocal") + ", "
				+ businessRemote + businessLocal + "pinned = " + this.pinned + ", accessed = " + this.accessedSweep
				+ ")";
	}
}