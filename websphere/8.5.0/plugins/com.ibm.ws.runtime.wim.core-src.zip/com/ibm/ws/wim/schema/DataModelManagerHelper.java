package com.ibm.ws.wim.schema;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.config.ConfigUtils;
import com.ibm.ws.wim.configmodel.LdapEntityTypesType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.util.DomainManagerUtils;
import commonj.sdo.DataObject;
import java.io.File;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataModelManagerHelper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2009";
	private static final String CLASSNAME = DataModelManagerHelper.class.getName();
	private static final Logger trcLogger;
	private static final String IS_MULTI_VALUE = "isMultiValued";
	public static final String SCHEMA_MESSAGE_KEY = "Message_key";
	public static final String MSG_PARAMS = "MSG_Params_key";

	public Map addPropertyToEntityTypes(String var1, Map var2) throws WIMException, RemoteException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		HashMap var5 = new HashMap();
		if (var4) {
			trcLogger.entering(CLASSNAME, "addPropertyToEntityTypes",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		DataObject var6 = null;
		String var7 = (String) var2.get("nsURI");
		String var8 = (String) var2.get("dataType");
		Boolean var9 = (Boolean) var2.get("isMultiValued");
		String var10 = (String) var2.get("name");
		List var11 = (List) var2.get("entityTypeNames");
		List var12 = (List) var2.get("requiredEntityTypeNames");
		List var13 = (List) var2.get("repositoryIds");
		String var14 = (String) var2.get("nsPrefix");
		String var15 = (String) var2.get("applicationId");
		Object var23 = var12 == null ? new ArrayList() : var12;
		Object var24 = var13 == null ? new ArrayList() : var13;
		SchemaValidator.validateDataType(var8, var10);
		SchemaValidator.validateEntityTypeName(var11);
		SchemaValidator.validateRequiredEntityTypeName(var11, (List) var23);
		SchemaValidator.validateRepositoryId((List) var24);
		SchemaValidator.validateNameSpaceAttributes(var7, var14);
		var7 = null != var7 ? var7.trim() : "";
		var14 = null != var14 ? var14.trim() : "";
		if (var7.length() == 0 && var14.length() == 0) {
			var7 = "http://www.ibm.com/websphere/wim";
			var14 = SchemaManager.singleton().getNsPrefix(var7);
		} else if (var7.length() == 0) {
			var7 = SchemaManager.singleton().getNsURI(var14);
		} else if (var14.length() == 0) {
			var14 = SchemaManager.singleton().getNsPrefix(var7);
		}

		SchemaManager var16 = SchemaManager.singleton();
		var6 = var16.createRootDataObject();
		DataObject var17 = var6.createDataObject("schema");
		String var19 = "propertySchema";
		if (var24 != null && ((List) var24).size() > 0 && ((List) var24).contains("LA")) {
			var19 = "extensionPropertySchema";
			((List) var24).remove("LA");
		}

		DataObject var18 = var17.createDataObject(var19);
		var18.set("nsURI", var7);
		var18.set("dataType", var8);
		var18.set("multiValued", var9);
		var18.set("propertyName", var10);
		var18.set("repositoryIds", var24);
		var18.set("nsPrefix", var14);
		List var20 = var18.getList("applicableEntityTypeNames");
		var20.addAll(var11);
		List var21 = var18.getList("requiredEntityTypeNames");
		if (var21 != null && ((List) var23).size() > 0) {
			var21.addAll((Collection) var23);
		}

		if (null != var15 && var15.trim().length() > 0) {
			DataObject var22 = var18.createDataObject("metaData");
			var22.set("name", "applicationId");
			var22.getList("values").add(var15.trim());
		}

		var16.createSchema(var6);
		var5.put("Message_key", "EXTEND_SCHEMA_PROPERTY_EXTENSION_SUCCESSFUL");
		var5.put("MSG_Params_key", WIMMessageHelper.generateMsgParms(var10, var11.toString()));
		if (var4) {
			trcLogger.exiting(CLASSNAME, "addPropertyToEntityTypes",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var5));
		}

		return var5;
	}

	public Map listPropertyExtensions(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "listPropertyExtensions",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var5 = (String) var2.get("applicationId");
		var5 = var5 == null ? "" : var5;
		String var6 = File.separator;
		String var7 = null;
		if ("admin".equals(DomainManagerUtils.getDomainName())) {
			var7 = ConfigManager.singleton().getWIMHomePath() + "model" + var6 + "wimxmlextension.xml";
		} else {
			var7 = DomainManagerUtils.getDomainPath(DomainManagerUtils.getDomainName()) + "wim" + var6 + "model" + var6
					+ "wimxmlextension.xml";
		}

		SchemaManager var8 = SchemaManager.singleton();
		DataObject var9 = var8.getWimXmlExtXml(var7);
		if (null == var9) {
			if (var4) {
				trcLogger.exiting(CLASSNAME, "listPropertyExtensions",
						"Exiting since root representing WIMXMLExtension.xml is null");
			}

			return new HashMap();
		} else {
			DataObject var10 = var9.getDataObject("schema");
			List var11 = var10.getList("propertySchema");
			HashMap var12 = new HashMap();

			for (int var13 = 0; var13 < var11.size(); ++var13) {
				DataObject var14 = (DataObject) var11.get(var13);
				List var15 = var14.getList("metaData");
				String var16 = "";

				String var19;
				for (int var17 = 0; var17 < var15.size(); ++var17) {
					DataObject var18 = (DataObject) var15.get(var17);
					var19 = var18.getString("name");
					if ("applicationId".equals(var19)) {
						var16 = var18.getList("values").size() > 0 ? var18.getList("values").get(0).toString() : "";
						break;
					}
				}

				if (var5.length() == 0 || var5.equals(var16)) {
					String var27 = (String) var14.get("propertyName");
					String var28 = (String) var14.get("nsURI");
					var19 = (String) var14.get("dataType");
					Object var20 = var14.get("nsPrefix");
					Boolean var21 = var14.getBoolean("multiValued");
					List var22 = ConfigUtils.convertEList(var14.getList("applicableEntityTypeNames"));
					List var23 = var14.getList("repositoryIds").size() > 0
							? ConfigUtils.convertEList(var14.getList("repositoryIds"))
							: null;
					List var24 = var14.getList("requiredEntityTypeNames").size() > 0
							? ConfigUtils.convertEList(var14.getList("requiredEntityTypeNames"))
							: null;
					String var25 = null != var20 && ((String) var20).length() > 0 ? (String) var20 : null;
					HashMap var26 = new HashMap();
					var26.put("nsURI", var28);
					var26.put("dataType", var19);
					if (null != var25) {
						var26.put("nsPrefix", var25);
					}

					var26.put("isMultiValued", var21);
					if (null != var23) {
						var26.put("repositoryIds", var23);
					}

					var26.put("entityTypeNames", var22);
					if (null != var24) {
						var26.put("requiredEntityTypeNames", var24);
					}

					if (var16.length() > 0) {
						var26.put("applicationId", var16);
					}

					var12.put(var27, var26);
				}
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "listPropertyExtensions", "Extended Properties are :" + var12.toString());
			}

			return var12;
		}
	}

	public Map getPropertySchema(String var1, Map var2) throws WIMException, RemoteException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getPropertySchema",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var6 = (String) var2.get("entityTypeName");
		List var7 = (List) var2.get("propertyNames");
		Object var30 = var7 == null ? new ArrayList() : var7;
		String var8 = (String) var2.get("id");
		RepositoryType var9 = null;
		if (var8 != null) {
			if (!"LA".equals(var8)) {
				var9 = ConfigUtils.getRepositoryById(var1, var8);
				var8 = var9.getId();
			} else {
				var8 = "LA";
			}
		}

		Object var10 = new ArrayList();
		RepositoryType var13;
		if (var6 == null) {
			if (!((List) var30).isEmpty()) {
				throw new WIMException("ENTITY_TYPE_NAME_NOT_SPECIFIED", WIMMessageHelper.generateMsgParms(var8),
						CLASSNAME, "getPropertySchema");
			}

			if (var8 != null && !"LA".equals(var8)) {
				DataObject var11 = ConfigManager.singleton().getConfig();
				List var12 = var11.getList("repositories");
				var13 = null;

				for (int var14 = 0; var14 < var12.size(); ++var14) {
					var13 = (RepositoryType) var12.get(var14);
					if (var13.getId().equals(var8)) {
						DataObject var15 = (DataObject) var13;
						String var16 = var15.getType().getName();
						if ("LdapRepositoryType".equals(var16)) {
							var10 = this.getEntityTypesForRepo(var8, var15);
						} else {
							var10 = new ArrayList(this.getEntityTypesForRepo((String) null, (DataObject) null));
						}

						String var17 = var15.getString("adapterClassName");
						if (var17.equals("com.ibm.ws.wim.adapter.urbridge.URBridge")) {
							Iterator var18 = ((List) var10).iterator();

							while (var18.hasNext()) {
								String var19 = (String) var18.next();
								if (!isSuperType("Group", var19) && !isSuperType("PersonAccount", var19)) {
									var18.remove();
								}
							}
						}
					}
				}
			} else {
				var10 = this.getEntityTypesForRepo((String) null, (DataObject) null);
			}
		} else {
			((List) var10).add(var6);
		}

		SchemaManager var31 = SchemaManager.singleton();
		DataObject var32 = var31.createRootDataObject();
		var13 = null;
		DataObject var33;
		if (!"LA".equals(var8)) {
			var33 = SDOHelper.createControlDataObject(var32, (String) null, "PropertyDefinitionControl");
			var33.setString("repositoryId", var8);
		} else {
			var33 = SDOHelper.createControlDataObject(var32, (String) null, "ExtensionPropertyDefinitionControl");
		}

		DataObject var34 = null;
		HashMap var35 = new HashMap();

		for (int var36 = 0; var36 < ((List) var10).size(); ++var36) {
			var33.setString("entityTypeName", (String) ((List) var10).get(var36));
			var33.setList("propertyNames", (List) var30);
			var34 = var31.getSchema(var32);
			DataObject var37 = var34.getDataObject("schema");
			new ArrayList();
			if (var37 != null) {
				List var38;
				if (!"LA".equals(var8)) {
					var38 = var37.getList("propertySchema");
				} else {
					var38 = var37.getList("extensionPropertySchema");
				}

				HashMap var39 = new HashMap();

				for (int var20 = 0; var20 < var38.size(); ++var20) {
					DataObject var21 = (DataObject) var38.get(var20);
					HashMap var22 = new HashMap();
					String var23 = (String) var21.get("propertyName");
					String var24 = (String) var21.get("nsURI");
					String var25 = (String) var21.get("dataType");
					Boolean var26 = var21.getBoolean("multiValued");
					String var27 = (String) var21.get("nsPrefix");
					List var28 = var21.getList("requiredEntityTypeNames").size() > 0
							? ConfigUtils.convertEList(var21.getList("requiredEntityTypeNames"))
							: null;
					boolean var29 = false;
					if (var28 != null && var28.contains(((List) var10).get(var36))) {
						var29 = true;
					}

					var24 = var24 != null ? var24 : "http://www.ibm.com/websphere/wim";
					var27 = var27 != null ? var27 : "wim";
					var22.put("nsPrefix", var27);
					var22.put("nsURI", var24);
					var22.put("dataType", var25);
					var22.put("multiValued", var26);
					var22.put("isRequired", var29);
					var23 = var27.equals("wim") ? var23 : var27.concat(":").concat(var23);
					var39.put(var23, var22);
				}

				String var40 = ((List) var10).get(var36).toString();
				if (var40.startsWith("wim")) {
					int var41 = var40.indexOf(":");
					var35.put(var40.substring(var41 + 1), var39);
				} else {
					var35.put(var40, var39);
				}
			}
		}

		return var35;
	}

	public List getEntityTypesForRepo(String var1, DataObject var2) throws WIMException {
		Object var3 = new ArrayList();
		if (var1 != null && var2 != null) {
			new ArrayList();
			List var4 = var2.getList("ldapEntityTypes");

			for (int var5 = 0; var5 < var4.size(); ++var5) {
				LdapEntityTypesType var6 = (LdapEntityTypesType) var4.get(var5);
				((List) var3).add(var6.getName());
			}
		} else {
			var3 = ConfigManager.singleton().getSupportedEntityTypes();
		}

		return (List) var3;
	}

	public static boolean isSuperType(String var0, String var1) throws WIMException {
		return var0.equals(var1) || SchemaManager.singleton().isSuperType(var0, var1);
	}

	public Map getEntityTypeSchema(String var1, Map var2) throws WIMException, RemoteException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getEntityTypeSchema",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var5 = (String) var2.get("id");
		RepositoryType var6 = null;
		if (var5 != null) {
			var6 = ConfigUtils.getRepositoryById(var1, var5);
			var5 = var6.getId();
		}

		List var7 = (List) var2.get("entityTypeNames");
		SchemaManager var8 = SchemaManager.singleton();
		DataObject var9 = var8.createRootDataObject();
		DataObject var10 = SDOHelper.createControlDataObject(var9, (String) null, "EntityTypeControl");
		if (var5 != null) {
			var10.setString("repositoryId", var5);
		}

		if (!var7.isEmpty()) {
			var10.setList("entityTypeNames", var7);
		}

		DataObject var11 = var8.getSchema(var9);
		DataObject var12 = var11.getDataObject("schema");
		HashMap var13 = new HashMap();
		if (var12 != null) {
			List var14 = var12.getList("entitySchema");

			for (int var15 = 0; var15 < var14.size(); ++var15) {
				DataObject var16 = (DataObject) var14.get(var15);
				HashMap var17 = new HashMap();
				String var18 = (String) var16.get("parentEntityName");
				String var19 = (String) var16.get("entityName");
				String var20 = (String) var16.get("nsURI");
				String var21 = (String) var16.get("nsPrefix");
				var20 = var20 != null ? var20 : "http://www.ibm.com/websphere/wim";
				var21 = var21 != null ? var21 : "wim";
				var17.put("nsPrefix", var21);
				var17.put("nsURI", var20);
				var17.put("parentEntityName", var18);
				var19 = var21.equals("wim") ? var19 : var21.concat(":").concat(var19);
				var13.put(var19, var17);
			}
		}

		return var13;
	}

	public List getSupportedDataTypes(String var1, Map var2) throws WIMException, RemoteException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getSupportedDataType",
					"params=" + WIMTraceHelper.printMapWithoutPassword(var2));
		}

		String var5 = (String) var2.get("id");
		RepositoryType var6 = null;
		if (var5 != null) {
			if (!"LA".equals(var5)) {
				var6 = ConfigUtils.getRepositoryById(var1, var5);
				var5 = var6.getId();
			} else {
				var5 = "LA";
			}
		}

		SchemaManager var7 = SchemaManager.singleton();
		DataObject var8 = var7.createRootDataObject();
		DataObject var9 = null;
		if (!"LA".equals(var5)) {
			var9 = SDOHelper.createControlDataObject(var8, (String) null, "DataTypeControl");
			var9.setString("repositoryId", var5);
		} else {
			var9 = SDOHelper.createControlDataObject(var8, (String) null, "ExtensionPropertyDataTypeControl");
		}

		DataObject var10 = var7.getSchema(var8);
		DataObject var11 = var10.getDataObject("schema");
		ArrayList var12 = new ArrayList();
		if (var11 != null) {
			List var13 = var11.getList("propertyDataTypes");

			for (int var14 = 0; var14 < var13.size(); ++var14) {
				var12.add(var13.get(var14));
			}
		}

		return var12;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}