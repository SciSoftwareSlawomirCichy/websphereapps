package com.ibm.ejs.container.passivator;

import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.passivator.NewInputStream.1;
import com.ibm.ejs.container.util.SerializableByteArray;
import com.ibm.ejs.container.util.StatefulBeanOReplacement;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.util.dopriv.LoadClassPrivileged;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.io.StreamCorruptedException;
import java.security.PrivilegedActionException;
import javax.rmi.CORBA.Stub;

class NewInputStream extends ObjectInputStream {
	BeanO activatedBeanO;
	private ClassLoader ivClassLoader;
	private EJSContainer ivContainer;
	private static final TraceComponent tc = Tr.register(NewInputStream.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.passivator.NewInputStream";

	NewInputStream(InputStream is, BeanO bo, ClassLoader classLoader, EJSContainer container) throws StreamCorruptedException, IOException {
      super(is);
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "NewInputStream: Input stream:" + is + ", activatedBeanO: " + bo);
      }

      this.activatedBeanO = bo;
      this.ivClassLoader = classLoader;
      this.ivContainer = container;
      AccessController.doPrivileged(new 1(this));
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.exit(tc, "NewInputStream");
      }

   }

	protected Object resolveObject(Object obj) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			String className = obj == null ? null : obj.getClass().getName();
			Tr.entry(tc, "resolveObject: " + className);
		}

		if (obj instanceof StatefulBeanOReplacement) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "replacing StatefulBeanOReplacement");
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "resolveObject: " + this.activatedBeanO);
			}

			return this.activatedBeanO;
		} else if (obj instanceof Stub) {
			try {
				this.ivContainer.getOrbUtils().connectToOrb(obj);
			} catch (CSIException var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.passivator.NewInputStream.resolveObject",
						"172", this);
				Tr.warning(tc, "FAILED_TO_CONNECT_TO_ORB_CNTR0006W", var3);
				return null;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "resolveObject: original remote object");
			}

			return obj;
		} else {
			Object resolve;
			if (!(obj instanceof SerializableByteArray)) {
				if (obj instanceof PassivatorSerializableHandle) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "replacing PassivatorSerializableHandle");
					}

					resolve = ((PassivatorSerializableHandle) obj).getSerializedObject();
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "resolveObject: " + resolve);
					}

					return resolve;
				} else {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "resolveObject: original object");
					}

					return obj;
				}
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "replacing SerializableByteArray with EJSLocalWrapper");
				}

				try {
					resolve = ((SerializableByteArray) obj).getWrapper();
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "resolveObject: " + resolve.getClass().getName());
					}

					return resolve;
				} catch (Exception var4) {
					FFDCFilter.processException(var4, "com.ibm.ejs.container.passivator.NewInputStream.resolveObject",
							"191", this);
					Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{obj, this, var4});
					if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
						Tr.exit(tc, "resolveObject: null : ERROR");
					}

					return null;
				}
			}
		}
	}

	protected Class<?> resolveClass(ObjectStreamClass streamClass) throws IOException, ClassNotFoundException {
		String className = streamClass.getName();
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "resolveClass: " + className);
		}

		if (this.ivClassLoader != null) {
			Class beanClass;
			try {
				beanClass = (Class) AccessController
						.doPrivileged(new LoadClassPrivileged(className, this.ivClassLoader));
			} catch (PrivilegedActionException var6) {
				ClassNotFoundException ex = (ClassNotFoundException) var6.getException();
				FFDCFilter.processException(ex, "com.ibm.ejs.container.passivator.NewInputStream.resolveClass", "185",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Unable to find " + className + " for passivated bean");
				}

				throw ex;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "resolveClass returning: " + beanClass);
			}

			return beanClass;
		} else {
			throw new ClassNotFoundException();
		}
	}
}