package com.google.common.eventbus;

import com.google.common.base.Throwables;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableList.Builder;
import com.google.common.eventbus.AnnotatedHandlerFinder.1;
import com.google.common.reflect.TypeToken;
import com.google.common.util.concurrent.UncheckedExecutionException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Set;

class AnnotatedHandlerFinder implements HandlerFindingStrategy {
	private static final LoadingCache<Class<?>, ImmutableList<Method>> handlerMethodsCache = CacheBuilder.newBuilder().weakKeys().build(new 1());

	public Multimap<Class<?>, EventHandler> findAllHandlers(Object listener) {
		Multimap<Class<?>, EventHandler> methodsInListener = HashMultimap.create();
		Class<?> clazz = listener.getClass();
		Iterator i$ = getAnnotatedMethods(clazz).iterator();

		while (i$.hasNext()) {
			Method method = (Method) i$.next();
			Class<?>[] parameterTypes = method.getParameterTypes();
			Class<?> eventType = parameterTypes[0];
			EventHandler handler = makeHandler(listener, method);
			methodsInListener.put(eventType, handler);
		}

		return methodsInListener;
	}

	private static ImmutableList<Method> getAnnotatedMethods(Class<?> clazz) {
		try {
			return (ImmutableList) handlerMethodsCache.getUnchecked(clazz);
		} catch (UncheckedExecutionException var2) {
			throw Throwables.propagate(var2.getCause());
		}
	}

	private static ImmutableList<Method> getAnnotatedMethodsInternal(Class<?> clazz) {
		Set<? extends Class<?>> supers = TypeToken.of(clazz).getTypes().rawTypes();
		Builder<Method> result = ImmutableList.builder();
		Method[] arr$ = clazz.getMethods();
		int len$ = arr$.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Method method = arr$[i$];
			Iterator i$ = supers.iterator();

			while (i$.hasNext()) {
				Class c = (Class) i$.next();

				try {
					Method m = c.getMethod(method.getName(), method.getParameterTypes());
					if (m.isAnnotationPresent(Subscribe.class)) {
						Class<?>[] parameterTypes = method.getParameterTypes();
						if (parameterTypes.length != 1) {
							throw new IllegalArgumentException("Method " + method
									+ " has @Subscribe annotation, but requires " + parameterTypes.length
									+ " arguments.  Event handler methods must require a single argument.");
						}

						Class<?> eventType = parameterTypes[0];
						result.add(method);
						break;
					}
				} catch (NoSuchMethodException var12) {
					;
				}
			}
		}

		return result.build();
	}

	private static EventHandler makeHandler(Object listener, Method method) {
		Object wrapper;
		if (methodIsDeclaredThreadSafe(method)) {
			wrapper = new EventHandler(listener, method);
		} else {
			wrapper = new SynchronizedEventHandler(listener, method);
		}

		return (EventHandler) wrapper;
	}

	private static boolean methodIsDeclaredThreadSafe(Method method) {
		return method.getAnnotation(AllowConcurrentEvents.class) != null;
	}
}