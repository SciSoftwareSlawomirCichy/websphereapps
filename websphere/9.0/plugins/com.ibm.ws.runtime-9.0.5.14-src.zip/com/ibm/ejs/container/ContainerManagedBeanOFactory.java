package com.ibm.ejs.container;

public class ContainerManagedBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, EJSHome h) {
		return new ContainerManagedBeanO(c, h);
	}
}