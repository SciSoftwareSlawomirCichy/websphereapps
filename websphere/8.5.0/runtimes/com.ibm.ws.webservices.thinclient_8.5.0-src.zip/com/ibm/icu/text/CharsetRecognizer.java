package com.ibm.icu.text;

abstract class CharsetRecognizer {
	abstract String getName();

	public String getLanguage() {
		return null;
	}

	abstract int match(CharsetDetector var1);
}