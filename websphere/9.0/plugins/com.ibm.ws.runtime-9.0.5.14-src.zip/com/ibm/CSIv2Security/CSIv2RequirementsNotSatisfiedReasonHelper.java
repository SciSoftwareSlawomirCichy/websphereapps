package com.ibm.CSIv2Security;

import org.omg.CORBA.Any;
import org.omg.CORBA.BAD_OPERATION;
import org.omg.CORBA.ORB;
import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;

public abstract class CSIv2RequirementsNotSatisfiedReasonHelper {
	private static String _id = "IDL:ibm.com/CSIv2Security/CSIv2RequirementsNotSatisfiedReason:1.0";
	private static volatile TypeCode __typeCode = null;

	public static void insert(Any var0, CSIv2RequirementsNotSatisfiedReason var1) {
		OutputStream var2 = var0.create_output_stream();
		var0.type(type());
		write(var2, var1);
		var0.read_value(var2.create_input_stream(), type());
	}

	public static CSIv2RequirementsNotSatisfiedReason extract(Any var0) {
		if (!var0.type().equal(type())) {
			throw new BAD_OPERATION(
					"extract() failed.Expected a com.ibm.CSIv2Security.CSIv2RequirementsNotSatisfiedReason .");
		} else {
			return read(var0.create_input_stream());
		}
	}

	public static TypeCode type() {
		TypeCode var0 = __typeCode;
		if (var0 == null) {
			var0 = ORB.init().create_enum_tc(id(), "CSIv2RequirementsNotSatisfiedReason",
					new String[]{"NotSatisfiedByClient", "NotSatisfiedByTarget", "NotSupported"});
			__typeCode = var0;
		}

		return var0;
	}

	public static String id() {
		return _id;
	}

	public static CSIv2RequirementsNotSatisfiedReason read(InputStream var0) {
		return CSIv2RequirementsNotSatisfiedReason.from_int(var0.read_long());
	}

	public static void write(OutputStream var0, CSIv2RequirementsNotSatisfiedReason var1) {
		var0.write_long(var1.value());
	}
}