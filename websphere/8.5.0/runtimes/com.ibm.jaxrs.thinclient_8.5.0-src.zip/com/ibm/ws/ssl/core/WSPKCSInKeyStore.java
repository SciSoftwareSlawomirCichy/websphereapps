package com.ibm.ws.ssl.core;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.ws.ssl.JSSEProvider;
import com.ibm.ws.ssl.JSSEProviderFactory;
import com.ibm.ws.ssl.core.WSPKCSInKeyStore.1;
import com.ibm.ws.ssl.core.WSPKCSInKeyStore.2;
import com.ibm.ws.ssl.core.WSPKCSInKeyStore.AddHardwareProviderAction;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.lang.reflect.Constructor;
import java.security.AccessController;
import java.security.KeyStore;
import java.security.PrivilegedActionException;
import java.security.Provider;
import java.security.Security;
import java.util.Stack;
import java.util.prefs.Preferences;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManagerFactory;

public final class WSPKCSInKeyStore {
	private static final TraceComponent tc = Tr.register(WSPKCSInKeyStore.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");
	private static final String DEFAULT_PKCS11_PROVIDER_CLASS_NAME = "com.ibm.crypto.pkcs11impl.provider.IBMPKCS11Impl";
	private static final String PKCS11_MARKER = "PKCS11";
	private static final String IBMPKCS11_PROVIDER_NAME = "IBMPKCS11";
	private static final String IBMPKCS11Impl_PROVIDER_NAME = "IBMPKCS11Impl";
	private KeyManagerFactory kmf;
	private KeyStore ks;
	private TrustManagerFactory tmf;
	private KeyStore ts;
	private JSSEProvider jsseProvider = null;
	private static Provider hwProvider = null;
	private String tokenLib_key;
	private String tokenType_key;
	private String tokenLib_trust;
	private String tokenType_trust;
	private static String pkcsTypeIBM = "PKCS11IMPLKS";
	private static String pkcsTypeSun = "PKCS11";
	private static String pkcsProvider = "IBMPKCS11Impl";
	public static final int DEFAULT_SLOT = 0;
	public static final int SLOT_NOT_SPECIFIED = -1;
	private Stack providerInstancePool = new Stack();
	private int noOfWorkerThreads = 0;
	private int noOfProvidersCreated = 0;
	private BufferedReader fileReader = null;
	private StringBuffer tokenConfigBuffer = new StringBuffer();
	private String nameAttribute = null;

	public WSPKCSInKeyStore(String tokenLibraryFile, String tokenPassword) throws Exception {
		this.initializePKCS11ImplProvider(tokenLibraryFile, tokenPassword);
	}

	public WSPKCSInKeyStore(String tokenConfigName) throws Exception {
		this.initializePKCS11ImplProvider(tokenConfigName);
	}

	public void asKeyStore(String tokenType, String tokenlib, String tokenPwd, String contextProvider,
			boolean pureAcceleration) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "asKeyStore() : contextProvider: " + contextProvider);
		}

		String pkcsType = pkcsTypeIBM;
		if ("IBMPKCS11Impl".equalsIgnoreCase(contextProvider)) {
			contextProvider = hwProvider.getName();
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "IBMPKCS11Impl is detected. current provider: " + contextProvider);
			}
		} else if (contextProvider != null && contextProvider.startsWith("SunPKCS11")) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Sun's provider is detected. Default context provider will be selected.");
			}

			contextProvider = null;
			pkcsType = pkcsTypeSun;
		}

		this.jsseProvider = JSSEProviderFactory.getInstance(contextProvider);

		try {
			if (this.tokenLib_key == null || this.tokenLib_key.compareToIgnoreCase(tokenlib) != 0 || this.ks == null) {
				if (this.tokenLib_trust != null && tokenlib.compareTo(this.tokenLib_trust) == 0 && this.ts != null) {
					this.kmf = this.jsseProvider.getKeyManagerFactoryInstance();
					this.ks = this.ts;
					if (!pureAcceleration) {
						this.kmf.init(this.ts, tokenPwd.toCharArray());
					}
				} else {
					this.kmf = this.jsseProvider.getKeyManagerFactoryInstance();
					this.ks = KeyStore.getInstance(pkcsType, hwProvider.getName());
					if (!pureAcceleration) {
						try {
							this.ks.load((InputStream) null, tokenPwd.toCharArray());
							this.kmf.init(this.ks, tokenPwd.toCharArray());
						} catch (Exception var8) {
							if (tokenPwd.length() != 0) {
								throw var8;
							}

							Tr.debug(tc, "substitute null for empty string on ks.load");
							this.ks.load((InputStream) null, (char[]) null);
							this.kmf.init(this.ks, (char[]) null);
						}
					}
				}

				this.tokenLib_key = new String(tokenlib);
				this.tokenType_key = new String(tokenType);
			}
		} catch (Exception var9) {
			this.kmf = null;
			this.ks = null;
			this.tokenLib_key = null;
			this.tokenType_key = null;
			throw var9;
		}
	}

	public void asTrustStore(String tokenType, String tokenlib, String tokenPwd, String contextProvider,
			boolean pureAcceleration) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "asTrustStore() : contextProvider: " + contextProvider);
		}

		String pkcsType = pkcsTypeIBM;
		if (contextProvider != null && contextProvider.startsWith("SunPKCS11")) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Sun's provider is detected. Default context provider will be selected.");
			}

			contextProvider = null;
			pkcsType = pkcsTypeSun;
		}

		this.jsseProvider = JSSEProviderFactory.getInstance(contextProvider);

		try {
			if (this.tokenLib_trust == null || this.tokenLib_trust.compareToIgnoreCase(tokenlib) != 0
					|| this.ts == null) {
				if (this.tokenLib_key != null && tokenlib.compareTo(this.tokenLib_key) == 0 && this.ks != null) {
					this.tmf = this.jsseProvider.getTrustManagerFactoryInstance();
					this.ts = this.ks;
					if (!pureAcceleration) {
						this.tmf.init(this.ks);
					}
				} else {
					this.tmf = this.jsseProvider.getTrustManagerFactoryInstance();
					this.ts = KeyStore.getInstance(pkcsType, hwProvider.getName());
					if (!pureAcceleration) {
						try {
							this.ts.load((InputStream) null, tokenPwd.toCharArray());
							this.tmf.init(this.ts);
						} catch (Exception var8) {
							if (tokenPwd.length() != 0) {
								throw var8;
							}

							Tr.debug(tc, "substitute null for empty string on ts.load");
							this.ts.load((InputStream) null, (char[]) null);
							this.tmf.init(this.ts);
						}
					}
				}

				this.tokenLib_trust = new String(tokenlib);
				this.tokenType_trust = new String(tokenType);
			}
		} catch (Exception var9) {
			this.tmf = null;
			this.ts = null;
			this.tokenLib_trust = null;
			this.tokenType_trust = null;
			throw var9;
		}
	}

	public KeyManagerFactory getKMF() {
		return this.kmf;
	}

	public KeyStore getKS() {
		return this.ks;
	}

	public TrustManagerFactory getTMF() {
		return this.tmf;
	}

	public KeyStore getTS() {
		return this.ts;
	}

	public String getlibName_key() {
		return this.tokenLib_key;
	}

	public String getlibName_trust() {
		return this.tokenLib_trust;
	}

	public String gettokType_key() {
		return this.tokenType_key;
	}

	public String gettokType_trust() {
		return this.tokenType_trust;
	}

	public void initializePKCS11ImplProvider(String tokenLibraryFile, String tokenPassword) throws Exception {
      Class pkcs11ProviderClass = getPKCS11ProviderClass();
      if (pkcs11ProviderClass != null && pkcs11ProviderClass.getName().contains("IBMPKCS11Impl")) {
         Provider pkcs11implProvider = Security.getProvider("IBMPKCS11Impl");
         if (pkcs11implProvider == null && tokenLibraryFile != null && tokenPassword != null) {
            Preferences prefs = Preferences.userNodeForPackage(pkcs11ProviderClass);
            prefs.put("IBMPKCSImpl DLL", tokenLibraryFile);
            prefs.put("IBMPKCSImpl password", tokenPassword);
            new AddHardwareProviderAction();
            Class finalPKCS11ProviderClass = pkcs11ProviderClass;

            try {
               AccessController.doPrivileged(new 1(this, finalPKCS11ProviderClass));
            } catch (Exception var12) {
               Manager.Ffdc.log(var12, this, "com.ibm.ws.security.orbssl.WSPKCSInKeyStore", "249");
               throw var12;
            } finally {
               if (prefs != null) {
                  prefs.remove("IBMPKCSImpl DLL");
                  prefs.remove("IBMPKCSImpl password");
               }

            }

            pkcs11implProvider = Security.getProvider("IBMPKCS11Impl");
         }
      }

   }

	public void initializePKCS11ImplProvider(String tokenConfigName) throws Exception {
      String configFile = tokenConfigName;

      try {
         AccessController.doPrivileged(new 2(this, configFile));
      } catch (PrivilegedActionException var5) {
         Exception ex = var5.getException();
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Cannot initialize PKCS11 provider: ", new Object[]{ex});
         }

         Manager.Ffdc.log(ex, this, "com.ibm.ws.security.orbssl.WSPKCSInKeyStore", "259");
         throw ex;
      }

      this.convertFileToBuffer(tokenConfigName);
   }

	private static Provider getPKCS11Provider(String configFileName) throws Exception {
		Provider provider = null;
		Class pkcs11ProviderClass = getPKCS11ProviderClass();
		provider = createPKCS11ProviderFromClassAndConfigFileName(pkcs11ProviderClass, configFileName);
		return provider;
	}

	private static Class getPKCS11ProviderClass() throws Exception {
		Class providerClass = findPKCS11ProviderClassFromSecurityProperties();
		return changeProviderClassToIBMPKCS11ImplIfProviderIsIBMPKCS11(providerClass);
	}

	private static Class findPKCS11ProviderClassFromSecurityProperties() {
		Provider[] installedProviders = Security.getProviders();
		Class pkcs11ProviderClass = null;
		Provider[] arr$ = installedProviders;
		int len$ = installedProviders.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Provider provider = arr$[i$];
			Class providerClass = provider.getClass();
			String providerClassName = providerClass.getName();
			if (isPKCS11Provider(providerClassName)) {
				pkcs11ProviderClass = providerClass;
				break;
			}
		}

		return pkcs11ProviderClass;
	}

	private static boolean isPKCS11Provider(String providerClassName) {
		return providerClassName.contains("PKCS11");
	}

	private static Class changeProviderClassToIBMPKCS11ImplIfProviderIsIBMPKCS11(Class providerClass)
			throws ClassNotFoundException {
		if (providerClass != null && isAnIBMPKCS11Provider(providerClass.getName())) {
			providerClass = Class.forName("com.ibm.crypto.pkcs11impl.provider.IBMPKCS11Impl");
		}

		return providerClass;
	}

	private static boolean isAnIBMPKCS11Provider(String providerClassName) {
		return providerClassName != null && providerClassName.contains("IBMPKCS11")
				&& !providerClassName.contains("IBMPKCS11Impl");
	}

	private static Provider createPKCS11ProviderFromClassAndConfigFileName(Class pkcs11ProviderClass,
			String configFileName) throws Exception {
		Provider provider = null;
		if (pkcs11ProviderClass != null) {
			if (configFileName != null && !configFileName.isEmpty()) {
				Constructor constructor = pkcs11ProviderClass.getDeclaredConstructor(String.class);
				provider = (Provider) constructor.newInstance(configFileName);
			} else {
				provider = (Provider) pkcs11ProviderClass.newInstance();
			}
		}

		return provider;
	}

	public Provider getHWCryptoProviderInstance(String tokenConfigName) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getHWCryptoProviderInstance(String)");
		}

		return hwProvider;
	}

	private BufferedReader convertFileToBuffer(String tokenConfigName) throws Exception {
		StringBuffer sb = new StringBuffer();
		String inLine = null;

		try {
			if (this.fileReader == null) {
				this.fileReader = new BufferedReader(new FileReader(tokenConfigName));

				try {
					while ((inLine = this.fileReader.readLine()) != null) {
						String str = inLine.trim();
						if (str.startsWith("name")) {
							this.nameAttribute = str;
						} else {
							this.tokenConfigBuffer.append(str).append(LINE_SEPARATOR);
						}
					}
				} catch (IOException var13) {
					Manager.Ffdc.log(var13, this, "com.ibm.ws.security.orbssl.WSPKCSInKeyStore", "333");
					throw var13;
				} finally {
					if (this.fileReader != null) {
						try {
							this.fileReader.close();
						} catch (IOException var12) {
							Manager.Ffdc.log(var12, this, "com.ibm.ws.security.orbssl.WSPKCSInKeyStore", "342");
							throw var12;
						}
					}

				}
			}

			sb.append(this.nameAttribute).append(this.noOfProvidersCreated).append(LINE_SEPARATOR)
					.append(this.tokenConfigBuffer);
		} catch (FileNotFoundException var15) {
			Manager.Ffdc.log(var15, this, "com.ibm.ws.security.orbssl.WSPKCSInKeyStore", "352");
			throw var15;
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Name attribute and other card related info: " + this.nameAttribute + ":"
					+ this.tokenConfigBuffer.toString());
		}

		return new BufferedReader(new StringReader(sb.toString()));
	}

	public Provider getHWCryptoProviderInstance(String tokenLib, String tokenSlot) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getHWCryptoProviderInstance(String, String)");
		}

		return hwProvider;
	}

	public void returnHWCryptoProviderInstance(Provider providerInstance) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "returnHWCryptoProviderInstance()");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "returnHWCryptoProviderInstance()");
		}

	}
}