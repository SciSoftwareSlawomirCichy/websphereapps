package com.google.common.base;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.CharMatcher.1;
import com.google.common.base.CharMatcher.And;
import com.google.common.base.CharMatcher.Any;
import com.google.common.base.CharMatcher.AnyOf;
import com.google.common.base.CharMatcher.Ascii;
import com.google.common.base.CharMatcher.BitSetMatcher;
import com.google.common.base.CharMatcher.BreakingWhitespace;
import com.google.common.base.CharMatcher.Digit;
import com.google.common.base.CharMatcher.ForPredicate;
import com.google.common.base.CharMatcher.InRange;
import com.google.common.base.CharMatcher.Invisible;
import com.google.common.base.CharMatcher.Is;
import com.google.common.base.CharMatcher.IsEither;
import com.google.common.base.CharMatcher.IsNot;
import com.google.common.base.CharMatcher.JavaDigit;
import com.google.common.base.CharMatcher.JavaIsoControl;
import com.google.common.base.CharMatcher.JavaLetter;
import com.google.common.base.CharMatcher.JavaLetterOrDigit;
import com.google.common.base.CharMatcher.JavaLowerCase;
import com.google.common.base.CharMatcher.JavaUpperCase;
import com.google.common.base.CharMatcher.Negated;
import com.google.common.base.CharMatcher.None;
import com.google.common.base.CharMatcher.Or;
import com.google.common.base.CharMatcher.SingleWidth;
import com.google.common.base.CharMatcher.Whitespace;
import java.util.BitSet;

@GwtCompatible(emulated = true)
public abstract class CharMatcher implements Predicate<Character> {
	private static final int DISTINCT_CHARS = 65536;

	public static CharMatcher any() {
		return Any.INSTANCE;
	}

	public static CharMatcher none() {
		return None.INSTANCE;
	}

	public static CharMatcher whitespace() {
		return Whitespace.INSTANCE;
	}

	public static CharMatcher breakingWhitespace() {
		return BreakingWhitespace.INSTANCE;
	}

	public static CharMatcher ascii() {
		return Ascii.INSTANCE;
	}

	@Deprecated
	public static CharMatcher digit() {
		return Digit.INSTANCE;
	}

	@Deprecated
	public static CharMatcher javaDigit() {
		return JavaDigit.INSTANCE;
	}

	@Deprecated
	public static CharMatcher javaLetter() {
		return JavaLetter.INSTANCE;
	}

	@Deprecated
	public static CharMatcher javaLetterOrDigit() {
		return JavaLetterOrDigit.INSTANCE;
	}

	@Deprecated
	public static CharMatcher javaUpperCase() {
		return JavaUpperCase.INSTANCE;
	}

	@Deprecated
	public static CharMatcher javaLowerCase() {
		return JavaLowerCase.INSTANCE;
	}

	public static CharMatcher javaIsoControl() {
		return JavaIsoControl.INSTANCE;
	}

	@Deprecated
	public static CharMatcher invisible() {
		return Invisible.INSTANCE;
	}

	@Deprecated
	public static CharMatcher singleWidth() {
		return SingleWidth.INSTANCE;
	}

	public static CharMatcher is(char match) {
		return new Is(match);
	}

	public static CharMatcher isNot(char match) {
		return new IsNot(match);
	}

	public static CharMatcher anyOf(CharSequence sequence) {
		switch (sequence.length()) {
			case 0 :
				return none();
			case 1 :
				return is(sequence.charAt(0));
			case 2 :
				return isEither(sequence.charAt(0), sequence.charAt(1));
			default :
				return new AnyOf(sequence);
		}
	}

	public static CharMatcher noneOf(CharSequence sequence) {
		return anyOf(sequence).negate();
	}

	public static CharMatcher inRange(char startInclusive, char endInclusive) {
		return new InRange(startInclusive, endInclusive);
	}

	public static CharMatcher forPredicate(Predicate<? super Character> predicate) {
		return (CharMatcher) (predicate instanceof CharMatcher ? (CharMatcher) predicate : new ForPredicate(predicate));
	}

	public abstract boolean matches(char var1);

	public CharMatcher negate() {
		return new Negated(this);
	}

	public CharMatcher and(CharMatcher other) {
		return new And(this, other);
	}

	public CharMatcher or(CharMatcher other) {
		return new Or(this, other);
	}

	public CharMatcher precomputed() {
		return Platform.precomputeCharMatcher(this);
	}

	@GwtIncompatible
   CharMatcher precomputedInternal() {
      BitSet table = new BitSet();
      this.setBits(table);
      int totalCharacters = table.cardinality();
      if (totalCharacters * 2 <= 65536) {
         return precomputedPositive(totalCharacters, table, this.toString());
      } else {
         table.flip(0, 65536);
         int negatedCharacters = 65536 - totalCharacters;
         String suffix = ".negate()";
         String description = this.toString();
         String negatedDescription = description.endsWith(suffix) ? description.substring(0, description.length() - suffix.length()) : description + suffix;
         return new 1(this, precomputedPositive(negatedCharacters, table, negatedDescription), description);
      }
   }

	@GwtIncompatible
   private static CharMatcher precomputedPositive(int totalCharacters, BitSet table, String description) {
      switch(totalCharacters) {
      case 0:
         return none();
      case 1:
         return is((char)table.nextSetBit(0));
      case 2:
         char c1 = (char)table.nextSetBit(0);
         char c2 = (char)table.nextSetBit(c1 + 1);
         return isEither(c1, c2);
      default:
         return (CharMatcher)(isSmall(totalCharacters, table.length()) ? SmallCharMatcher.from(table, description) : new BitSetMatcher(table, description, (1)null));
      }
   }

	@GwtIncompatible
	private static boolean isSmall(int totalCharacters, int tableLength) {
		return totalCharacters <= 1023 && tableLength > totalCharacters * 4 * 16;
	}

	@GwtIncompatible
	void setBits(BitSet table) {
		for (int c = 65535; c >= 0; --c) {
			if (this.matches((char) c)) {
				table.set(c);
			}
		}

	}

	public boolean matchesAnyOf(CharSequence sequence) {
		return !this.matchesNoneOf(sequence);
	}

	public boolean matchesAllOf(CharSequence sequence) {
		for (int i = sequence.length() - 1; i >= 0; --i) {
			if (!this.matches(sequence.charAt(i))) {
				return false;
			}
		}

		return true;
	}

	public boolean matchesNoneOf(CharSequence sequence) {
		return this.indexIn(sequence) == -1;
	}

	public int indexIn(CharSequence sequence) {
		return this.indexIn(sequence, 0);
	}

	public int indexIn(CharSequence sequence, int start) {
		int length = sequence.length();
		Preconditions.checkPositionIndex(start, length);

		for (int i = start; i < length; ++i) {
			if (this.matches(sequence.charAt(i))) {
				return i;
			}
		}

		return -1;
	}

	public int lastIndexIn(CharSequence sequence) {
		for (int i = sequence.length() - 1; i >= 0; --i) {
			if (this.matches(sequence.charAt(i))) {
				return i;
			}
		}

		return -1;
	}

	public int countIn(CharSequence sequence) {
		int count = 0;

		for (int i = 0; i < sequence.length(); ++i) {
			if (this.matches(sequence.charAt(i))) {
				++count;
			}
		}

		return count;
	}

	public String removeFrom(CharSequence sequence) {
		String string = sequence.toString();
		int pos = this.indexIn(string);
		if (pos == -1) {
			return string;
		} else {
			char[] chars = string.toCharArray();
			int spread = 1;

			label25 : while (true) {
				++pos;

				while (pos != chars.length) {
					if (this.matches(chars[pos])) {
						++spread;
						continue label25;
					}

					chars[pos - spread] = chars[pos];
					++pos;
				}

				return new String(chars, 0, pos - spread);
			}
		}
	}

	public String retainFrom(CharSequence sequence) {
		return this.negate().removeFrom(sequence);
	}

	public String replaceFrom(CharSequence sequence, char replacement) {
		String string = sequence.toString();
		int pos = this.indexIn(string);
		if (pos == -1) {
			return string;
		} else {
			char[] chars = string.toCharArray();
			chars[pos] = replacement;

			for (int i = pos + 1; i < chars.length; ++i) {
				if (this.matches(chars[i])) {
					chars[i] = replacement;
				}
			}

			return new String(chars);
		}
	}

	public String replaceFrom(CharSequence sequence, CharSequence replacement) {
		int replacementLen = replacement.length();
		if (replacementLen == 0) {
			return this.removeFrom(sequence);
		} else if (replacementLen == 1) {
			return this.replaceFrom(sequence, replacement.charAt(0));
		} else {
			String string = sequence.toString();
			int pos = this.indexIn(string);
			if (pos == -1) {
				return string;
			} else {
				int len = string.length();
				StringBuilder buf = new StringBuilder(len * 3 / 2 + 16);
				int oldpos = 0;

				do {
					buf.append(string, oldpos, pos);
					buf.append(replacement);
					oldpos = pos + 1;
					pos = this.indexIn(string, oldpos);
				} while (pos != -1);

				buf.append(string, oldpos, len);
				return buf.toString();
			}
		}
	}

	public String trimFrom(CharSequence sequence) {
		int len = sequence.length();

		int first;
		for (first = 0; first < len && this.matches(sequence.charAt(first)); ++first) {
			;
		}

		int last;
		for (last = len - 1; last > first && this.matches(sequence.charAt(last)); --last) {
			;
		}

		return sequence.subSequence(first, last + 1).toString();
	}

	public String trimLeadingFrom(CharSequence sequence) {
		int len = sequence.length();

		for (int first = 0; first < len; ++first) {
			if (!this.matches(sequence.charAt(first))) {
				return sequence.subSequence(first, len).toString();
			}
		}

		return "";
	}

	public String trimTrailingFrom(CharSequence sequence) {
		int len = sequence.length();

		for (int last = len - 1; last >= 0; --last) {
			if (!this.matches(sequence.charAt(last))) {
				return sequence.subSequence(0, last + 1).toString();
			}
		}

		return "";
	}

	public String collapseFrom(CharSequence sequence, char replacement) {
		int len = sequence.length();

		for (int i = 0; i < len; ++i) {
			char c = sequence.charAt(i);
			if (this.matches(c)) {
				if (c != replacement || i != len - 1 && this.matches(sequence.charAt(i + 1))) {
					StringBuilder builder = (new StringBuilder(len)).append(sequence, 0, i).append(replacement);
					return this.finishCollapseFrom(sequence, i + 1, len, replacement, builder, true);
				}

				++i;
			}
		}

		return sequence.toString();
	}

	public String trimAndCollapseFrom(CharSequence sequence, char replacement) {
		int len = sequence.length();
		int first = 0;

		int last;
		for (last = len - 1; first < len && this.matches(sequence.charAt(first)); ++first) {
			;
		}

		while (last > first && this.matches(sequence.charAt(last))) {
			--last;
		}

		return first == 0 && last == len - 1
				? this.collapseFrom(sequence, replacement)
				: this.finishCollapseFrom(sequence, first, last + 1, replacement, new StringBuilder(last + 1 - first),
						false);
	}

	private String finishCollapseFrom(CharSequence sequence, int start, int end, char replacement,
			StringBuilder builder, boolean inMatchingGroup) {
		for (int i = start; i < end; ++i) {
			char c = sequence.charAt(i);
			if (this.matches(c)) {
				if (!inMatchingGroup) {
					builder.append(replacement);
					inMatchingGroup = true;
				}
			} else {
				builder.append(c);
				inMatchingGroup = false;
			}
		}

		return builder.toString();
	}

	@Deprecated
	public boolean apply(Character character) {
		return this.matches(character);
	}

	public String toString() {
		return super.toString();
	}

	private static String showCharacter(char c) {
		String hex = "0123456789ABCDEF";
		char[] tmp = new char[]{'\\', 'u', ' ', ' ', ' ', ' '};

		for (int i = 0; i < 4; ++i) {
			tmp[5 - i] = hex.charAt(c & 15);
			c = (char) (c >> 4);
		}

		return String.copyValueOf(tmp);
	}

	private static IsEither isEither(char c1, char c2) {
		return new IsEither(c1, c2);
	}
}