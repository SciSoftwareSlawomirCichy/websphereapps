package com.google.common.graph;

import com.google.common.graph.MapRetrievalCache.CacheEntry;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

class MapRetrievalCache<K, V> extends MapIteratorCache<K, V> {
	@NullableDecl
	private transient CacheEntry<K, V> cacheEntry1;
	@NullableDecl
	private transient CacheEntry<K, V> cacheEntry2;

	MapRetrievalCache(Map<K, V> backingMap) {
		super(backingMap);
	}

	public V get(@NullableDecl Object key) {
		V value = this.getIfCached(key);
		if (value != null) {
			return value;
		} else {
			value = this.getWithoutCaching(key);
			if (value != null) {
				this.addToCache(key, value);
			}

			return value;
		}
	}

	protected V getIfCached(@NullableDecl Object key) {
		V value = super.getIfCached(key);
		if (value != null) {
			return value;
		} else {
			CacheEntry<K, V> entry = this.cacheEntry1;
			if (entry != null && entry.key == key) {
				return entry.value;
			} else {
				entry = this.cacheEntry2;
				if (entry != null && entry.key == key) {
					this.addToCache(entry);
					return entry.value;
				} else {
					return null;
				}
			}
		}
	}

	protected void clearCache() {
		super.clearCache();
		this.cacheEntry1 = null;
		this.cacheEntry2 = null;
	}

	private void addToCache(K key, V value) {
		this.addToCache(new CacheEntry(key, value));
	}

	private void addToCache(CacheEntry<K, V> entry) {
		this.cacheEntry2 = this.cacheEntry1;
		this.cacheEntry1 = entry;
	}
}