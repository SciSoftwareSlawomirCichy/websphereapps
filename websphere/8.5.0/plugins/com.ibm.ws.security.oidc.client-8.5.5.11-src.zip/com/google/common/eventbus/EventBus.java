package com.google.common.eventbus;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.base.Throwables;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.SetMultimap;
import com.google.common.eventbus.EventBus.1;
import com.google.common.eventbus.EventBus.2;
import com.google.common.eventbus.EventBus.3;
import com.google.common.eventbus.EventBus.EventWithHandler;
import com.google.common.util.concurrent.UncheckedExecutionException;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

@Beta
public class EventBus {
	private static final LoadingCache<Class<?>, Set<Class<?>>> flattenHierarchyCache = CacheBuilder.newBuilder().weakKeys().build(new 1());
	private final SetMultimap<Class<?>, EventHandler> handlersByType;
	private final ReadWriteLock handlersByTypeLock;
	private final Logger logger;
	private final HandlerFindingStrategy finder;
	private final ThreadLocal<Queue<EventWithHandler>> eventsToDispatch;
	private final ThreadLocal<Boolean> isDispatching;

	public EventBus() {
		this("default");
	}

	public EventBus(String identifier) {
      this.handlersByType = HashMultimap.create();
      this.handlersByTypeLock = new ReentrantReadWriteLock();
      this.finder = new AnnotatedHandlerFinder();
      this.eventsToDispatch = new 2(this);
      this.isDispatching = new 3(this);
      this.logger = Logger.getLogger(EventBus.class.getName() + "." + (String)Preconditions.checkNotNull(identifier));
   }

	public void register(Object object) {
		Multimap<Class<?>, EventHandler> methodsInListener = this.finder.findAllHandlers(object);
		this.handlersByTypeLock.writeLock().lock();

		try {
			this.handlersByType.putAll(methodsInListener);
		} finally {
			this.handlersByTypeLock.writeLock().unlock();
		}

	}

	public void unregister(Object object) {
		Multimap<Class<?>, EventHandler> methodsInListener = this.finder.findAllHandlers(object);
		Iterator i$ = methodsInListener.asMap().entrySet().iterator();

		while (i$.hasNext()) {
			Entry<Class<?>, Collection<EventHandler>> entry = (Entry) i$.next();
			Class<?> eventType = (Class) entry.getKey();
			Collection<EventHandler> eventMethodsInListener = (Collection) entry.getValue();
			this.handlersByTypeLock.writeLock().lock();

			try {
				Set<EventHandler> currentHandlers = this.handlersByType.get(eventType);
				if (!currentHandlers.containsAll(eventMethodsInListener)) {
					throw new IllegalArgumentException(
							"missing event handler for an annotated method. Is " + object + " registered?");
				}

				currentHandlers.removeAll(eventMethodsInListener);
			} finally {
				this.handlersByTypeLock.writeLock().unlock();
			}
		}

	}

	public void post(Object event) {
		Set<Class<?>> dispatchTypes = this.flattenHierarchy(event.getClass());
		boolean dispatched = false;
		Iterator i$ = dispatchTypes.iterator();

		while (i$.hasNext()) {
			Class<?> eventType = (Class) i$.next();
			this.handlersByTypeLock.readLock().lock();

			try {
				Set<EventHandler> wrappers = this.handlersByType.get(eventType);
				if (!wrappers.isEmpty()) {
					dispatched = true;
					Iterator i$ = wrappers.iterator();

					while (i$.hasNext()) {
						EventHandler wrapper = (EventHandler) i$.next();
						this.enqueueEvent(event, wrapper);
					}
				}
			} finally {
				this.handlersByTypeLock.readLock().unlock();
			}
		}

		if (!dispatched && !(event instanceof DeadEvent)) {
			this.post(new DeadEvent(this, event));
		}

		this.dispatchQueuedEvents();
	}

	void enqueueEvent(Object event, EventHandler handler) {
		((Queue) this.eventsToDispatch.get()).offer(new EventWithHandler(event, handler));
	}

	void dispatchQueuedEvents() {
		if (!(Boolean) this.isDispatching.get()) {
			this.isDispatching.set(true);

			try {
				Queue events = (Queue) this.eventsToDispatch.get();

				EventWithHandler eventWithHandler;
				while ((eventWithHandler = (EventWithHandler) events.poll()) != null) {
					this.dispatch(eventWithHandler.event, eventWithHandler.handler);
				}
			} finally {
				this.isDispatching.remove();
				this.eventsToDispatch.remove();
			}

		}
	}

	void dispatch(Object event, EventHandler wrapper) {
		try {
			wrapper.handleEvent(event);
		} catch (InvocationTargetException var4) {
			this.logger.log(Level.SEVERE, "Could not dispatch event: " + event + " to handler " + wrapper, var4);
		}

	}

	@VisibleForTesting
	Set<Class<?>> flattenHierarchy(Class<?> concreteClass) {
		try {
			return (Set) flattenHierarchyCache.getUnchecked(concreteClass);
		} catch (UncheckedExecutionException var3) {
			throw Throwables.propagate(var3.getCause());
		}
	}
}