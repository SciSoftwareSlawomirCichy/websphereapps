package com.ibm.ws.security.oidc.client.filter;

public interface IRequestInfo {
	String getHeader(String var1);

	StringBuffer getRequestURL();

	String getQueryString();

	String getRemoteAddr();

	String getApplicationName();

	String getReferer();

	String getRequestURI();
}