package com.ibm.ejs.container;

public class IsolationLevelChangeException extends ContainerException {
	private static final long serialVersionUID = 9149265483640550976L;
}