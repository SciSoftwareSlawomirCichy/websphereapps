package com.ibm.ejs.container;

public class BMStatefulBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, EJSHome h) {
		return new BMStatefulBeanO(c, h);
	}
}