package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLWarning;
import java.sql.Statement;

public class StatementProxy extends Proxy implements Statement {
	private static final TraceNLS NLS = TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages");
	protected Statement statement;
	protected ResultSet resultSet;
	protected PortabilityLayer portabilityLayer;
	private boolean addBatchUsed = false;
	private static final TraceComponent tc = Tr.register(StatementProxy.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public boolean isPoolable() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isPoolable()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setPoolable(boolean poolable) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setPoolable(boolean)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isWrapperFor(Class<?>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "unwrap(Class<T>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setURL(int i, URL url) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setURL(int, java.net.URL)");
		throw new SQLException("This method is not supported.");
	}

	public ParameterMetaData getParameterMetaData() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getParameterMetaData()");
		throw new SQLException("This method is not supported.");
	}

	public boolean execute(String s, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "execute(String, int)");
		throw new SQLException("This method is not supported.");
	}

	public boolean execute(String s, int[] i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "execute(String, int[])");
		throw new SQLException("This method is not supported.");
	}

	public int executeUpdate(String s, int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "executeUpdate(String, int)");
		throw new SQLException("This method is not supported.");
	}

	public int executeUpdate(String s, int[] i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "executeUpdate(String, int[])");
		throw new SQLException("This method is not supported.");
	}

	public boolean execute(String s, String[] ss) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "execute(String, String[])");
		throw new SQLException("This method is not supported.");
	}

	public int executeUpdate(String s, String[] ss) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "executeUpdate(String, String[])");
		throw new SQLException("This method is not supported.");
	}

	public ResultSet getGeneratedKeys() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getGeneratedKeys()");
		throw new SQLException("This method is not supported.");
	}

	public boolean getMoreResults(int i) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getMoreResults(int)");
		throw new SQLException("This method is not supported.");
	}

	public int getResultSetHoldability() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getResultSetHoldability()");
		throw new SQLException("This method is not supported.");
	}

	StatementProxy(ConnectionProxy parent, Statement statement) {
		super(parent);
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", new Object[]{parent, statement});
		}

		this.statement = statement;

		try {
			this.portabilityLayer = (PortabilityLayer) parent.getPortabilityLayer();
		} catch (SQLException var4) {
			;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void close() throws SQLException {
		if (!this.isClosed()) {
			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "close");
			}

			synchronized (this.getLockObject()) {
				this.reallyClose();
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "close");
			}

		}
	}

	protected void closeFromParent() throws SQLException {
		if (!this.isClosed()) {
			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "closeFromParent");
			}

			this.reallyClose();
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "closeFromParent");
			}

		}
	}

	public void reallyClose() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "reallyClose");
		}

		SQLException caughtException = null;

		try {
			if (this.addBatchUsed) {
				this.clearBatch();
			}

			super.close();
		} catch (SQLException var40) {
			caughtException = var40;
		} finally {
			try {
				if (this.statement != null) {
					this.statement.close();
				}
			} catch (SQLException var41) {
				if (caughtException == null) {
					caughtException = this.translateException(var41);
					if (tc.isEventEnabled()) {
						Tr.event(tc, "Exception closing statement", caughtException);
					}
				} else if (tc.isEventEnabled()) {
					Tr.event(tc, "Secondary exception closing statement", var41);
				}
			} finally {
				this.statement = null;
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "reallyClose");
				}

			}

		}

		if (caughtException != null) {
			throw caughtException;
		}
	}

	public final void setFetchDirection(int dir) throws SQLException {
		this.getStatement().setFetchDirection(dir);
	}

	public final int getFetchDirection() throws SQLException {
		return this.getStatement().getFetchDirection();
	}

	public final void setFetchSize(int count) throws SQLException {
		this.getStatement().setFetchSize(count);
	}

	public final int getFetchSize() throws SQLException {
		return this.getStatement().getFetchSize();
	}

	public final int getResultSetType() throws SQLException {
		return this.getStatement().getResultSetType();
	}

	public final int getResultSetConcurrency() throws SQLException {
		return this.getStatement().getResultSetConcurrency();
	}

	public final void addBatch(String sql) throws SQLException {
		this.addBatchUsed = true;
		this.getStatement().addBatch(this.portabilityLayer.scanSQL(sql));
	}

	public final void clearBatch() throws SQLException {
		this.addBatchUsed = false;
		this.getStatement().clearBatch();
	}

	public final int[] executeBatch() throws SQLException {
		SQLException x = null;
		this.addBatchUsed = false;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				int[] result = null;

				try {
					this.__preInvoke(true);
					result = this.getStatement().executeBatch();
				} catch (SQLException var10) {
					x = var10;
				} finally {
					this.__postInvoke(x);
					if (x != null) {
						x = this.translateException(x);
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "executeUpdateCommon - SQLException", x);
						}

						throw x;
					} else {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "executeUpdateCommon", result);
						}

						return result;
					}
				}
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed.");
		}
	}

	public final Connection getConnection() throws SQLException {
		return (Connection) this.getParent();
	}

	public void cancel() throws SQLException {
		Object var1 = null;

		try {
			this.getStatement().cancel();
		} catch (SQLException var6) {
			throw this.translateException(var6);
		} finally {
			;
		}
	}

	public void clearWarnings() throws SQLException {
		this.getStatement().clearWarnings();
	}

	public boolean execute(String sql) throws SQLException {
		this.addBatchUsed = false;
		return this.executeCommon(sql, false);
	}

	public boolean executeCommon(String sql, boolean preparedStatement) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "executeCommon", new Object[]{sql, new Boolean(preparedStatement)});
		}

		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				boolean result = false;

				try {
					this.__preInvoke(true);
					if (preparedStatement) {
						result = ((PreparedStatement) this.getStatement()).execute();
					} else {
						result = this.getStatement().execute(this.portabilityLayer.scanSQL(sql));
					}
				} catch (SQLException var12) {
					x = var12;
				} finally {
					this.__postInvoke(x);
					if (x != null) {
						x = this.translateException(x);
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "executeCommon - SQLException", x);
						}

						throw x;
					} else {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "executeCommon", new Boolean(result));
						}

						return result;
					}
				}
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public ResultSet executeQuery(String sql) throws SQLException {
		this.addBatchUsed = false;
		return this.executeQueryCommon(sql, false);
	}

	public ResultSet executeQueryCommon(String sql, boolean preparedStatement) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "executeQueryCommon", new Object[]{sql, new Boolean(preparedStatement)});
		}

		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				ResultSet result = null;

				try {
					if (this.getLocalResultSet() != null) {
						try {
							this.resultSet.close();
						} finally {
							this.resultSet = null;
						}
					}

					this.__preInvoke(true);
					if (preparedStatement) {
						result = ((PreparedStatement) this.getStatement()).executeQuery();
					} else {
						result = this.getStatement().executeQuery(this.portabilityLayer.scanSQL(sql));
					}

					if (result != null) {
						this.resultSet = new ResultSetProxy(this, result);
						result = this.resultSet;
					}
				} catch (SQLException var18) {
					x = var18;
				} finally {
					this.__postInvoke(x);
					if (x != null) {
						x = this.translateException(x);
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "executeQueryCommon - SQLException", x);
						}

						throw x;
					} else {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "executeQueryCommon", result);
						}

						return result;
					}
				}
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed.");
		}
	}

	public int executeUpdate(String sql) throws SQLException {
		this.addBatchUsed = false;
		return this.executeUpdateCommon(sql, false);
	}

	public int executeUpdateCommon(String sql, boolean preparedStatement) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "executeUpdateCommon", new Object[]{sql, new Boolean(preparedStatement)});
		}

		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				int result = -1;

				try {
					this.__preInvoke(true);
					if (preparedStatement) {
						result = ((PreparedStatement) this.getStatement()).executeUpdate();
					} else {
						result = this.getStatement().executeUpdate(this.portabilityLayer.scanSQL(sql));
					}
				} catch (SQLException var12) {
					x = var12;
				} finally {
					this.__postInvoke(x);
					if (x != null) {
						x = this.translateException(x);
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "executeUpdateCommon - SQLException", x);
						}

						throw x;
					} else {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "executeUpdateCommon", new Integer(result));
						}

						return result;
					}
				}
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed.");
		}
	}

	public int getMaxFieldSize() throws SQLException {
		return this.getStatement().getMaxFieldSize();
	}

	public int getMaxRows() throws SQLException {
		return this.getStatement().getMaxRows();
	}

	public boolean getMoreResults() throws SQLException {
		return this.getStatement().getMoreResults();
	}

	public int getQueryTimeout() throws SQLException {
		return this.getStatement().getQueryTimeout();
	}

	public ResultSet getResultSet() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				ResultSet var4;
				try {
					this.__preInvoke();
					ResultSet rs = this.getStatement().getResultSet();
					if (rs == null) {
						this.resultSet = null;
					} else {
						this.resultSet = new ResultSetProxy(this, rs);
					}

					var4 = this.resultSet;
				} catch (SQLException var10) {
					x = var10;
					throw this.translateException(var10);
				} finally {
					this.__postInvoke(x);
				}

				return var4;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed.");
		}
	}

	public int getUpdateCount() throws SQLException {
		return this.getStatement().getUpdateCount();
	}

	public SQLWarning getWarnings() throws SQLException {
		return this.getStatement().getWarnings();
	}

	public void setCursorName(String name) throws SQLException {
		this.getStatement().setCursorName(name);
	}

	public void setEscapeProcessing(boolean enable) throws SQLException {
		this.getStatement().setEscapeProcessing(enable);
	}

	public void setMaxFieldSize(int max) throws SQLException {
		this.getStatement().setMaxFieldSize(max);
	}

	public void setMaxRows(int max) throws SQLException {
		this.getStatement().setMaxRows(max);
	}

	public void closeOnCompletion() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public boolean isCloseOnCompletion() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public void setQueryTimeout(int timeout) throws SQLException {
		this.getStatement().setQueryTimeout(timeout);
	}

	protected final Statement getStatement() throws SQLException {
		if (this.isClosed()) {
			throw new StaleConnectionException(this.getClass() + " is closed");
		} else {
			return this.statement;
		}
	}

	protected final ResultSet getLocalResultSet() throws SQLException {
		if (this.isClosed()) {
			throw new StaleConnectionException(this.getClass() + " is closed");
		} else {
			return this.resultSet;
		}
	}
}