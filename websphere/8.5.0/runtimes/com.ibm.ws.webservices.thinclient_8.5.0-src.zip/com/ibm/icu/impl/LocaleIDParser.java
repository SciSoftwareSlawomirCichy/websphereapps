package com.ibm.icu.impl;

import com.ibm.icu.impl.LocaleIDParser.1;
import com.ibm.icu.impl.locale.AsciiUtil;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

public final class LocaleIDParser {
	private char[] id;
	private int index;
	private char[] buffer;
	private int blen;
	private boolean canonicalize;
	private boolean hadCountry;
	Map<String, String> keywords;
	String baseName;
	private static final char KEYWORD_SEPARATOR = '@';
	private static final char HYPHEN = '-';
	private static final char KEYWORD_ASSIGN = '=';
	private static final char COMMA = ',';
	private static final char ITEM_SEPARATOR = ';';
	private static final char DOT = '.';
	private static final char UNDERSCORE = '_';
	private static final char DONE = '￿';

	public LocaleIDParser(String localeID) {
		this(localeID, false);
	}

	public LocaleIDParser(String localeID, boolean canonicalize) {
		this.id = localeID.toCharArray();
		this.index = 0;
		this.buffer = new char[this.id.length + 5];
		this.blen = 0;
		this.canonicalize = canonicalize;
	}

	private void reset() {
		this.index = this.blen = 0;
	}

	private void append(char c) {
		try {
			this.buffer[this.blen] = c;
		} catch (IndexOutOfBoundsException var4) {
			if (this.buffer.length > 512) {
				throw var4;
			}

			char[] nbuffer = new char[this.buffer.length * 2];
			System.arraycopy(this.buffer, 0, nbuffer, 0, this.buffer.length);
			nbuffer[this.blen] = c;
			this.buffer = nbuffer;
		}

		++this.blen;
	}

	private void addSeparator() {
		this.append('_');
	}

	private String getString(int start) {
		return start == this.blen ? "" : new String(this.buffer, start, this.blen - start);
	}

	private void set(int pos, String s) {
		this.blen = pos;
		this.append(s);
	}

	private void append(String s) {
		for (int i = 0; i < s.length(); ++i) {
			this.append(s.charAt(i));
		}

	}

	private char next() {
		if (this.index == this.id.length) {
			++this.index;
			return '￿';
		} else {
			return this.id[this.index++];
		}
	}

	private void skipUntilTerminatorOrIDSeparator() {
		while (!this.isTerminatorOrIDSeparator(this.next())) {
			;
		}

		--this.index;
	}

	private boolean atTerminator() {
		return this.index >= this.id.length || this.isTerminator(this.id[this.index]);
	}

	private boolean isTerminator(char c) {
		return c == '@' || c == '￿' || c == '.';
	}

	private boolean isTerminatorOrIDSeparator(char c) {
		return c == '@' || c == '_' || c == '-' || c == '￿' || c == '.';
	}

	private boolean haveExperimentalLanguagePrefix() {
		if (this.id.length > 2) {
			char c = this.id[1];
			if (c == '-' || c == '_') {
				c = this.id[0];
				return c == 'x' || c == 'X' || c == 'i' || c == 'I';
			}
		}

		return false;
	}

	private boolean haveKeywordAssign() {
		for (int i = this.index; i < this.id.length; ++i) {
			if (this.id[i] == '=') {
				return true;
			}
		}

		return false;
	}

	private int parseLanguage() {
		if (this.haveExperimentalLanguagePrefix()) {
			this.append(Character.toLowerCase(this.id[0]));
			this.append('-');
			this.index = 2;
		}

		char c;
		while (!this.isTerminatorOrIDSeparator(c = this.next())) {
			this.append(Character.toLowerCase(c));
		}

		--this.index;
		if (this.blen == 3) {
			String lang = LocaleIDs.threeToTwoLetterLanguage(this.getString(0));
			if (lang != null) {
				this.set(0, lang);
			}
		}

		return 0;
	}

	private void skipLanguage() {
		if (this.haveExperimentalLanguagePrefix()) {
			this.index = 2;
		}

		this.skipUntilTerminatorOrIDSeparator();
	}

	private int parseScript() {
		if (!this.atTerminator()) {
			int oldIndex = this.index++;
			int oldBlen = this.blen;

			char c;
			while (!this.isTerminatorOrIDSeparator(c = this.next())) {
				if (this.blen == oldBlen) {
					this.addSeparator();
					this.append(Character.toUpperCase(c));
				} else {
					this.append(Character.toLowerCase(c));
				}
			}

			--this.index;
			if (this.index - oldIndex != 5) {
				this.index = oldIndex;
				this.blen = oldBlen;
			} else {
				++oldBlen;
			}

			return oldBlen;
		} else {
			return this.blen;
		}
	}

	private void skipScript() {
		if (!this.atTerminator()) {
			int oldIndex = this.index++;
			this.skipUntilTerminatorOrIDSeparator();
			if (this.index - oldIndex != 5) {
				this.index = oldIndex;
			}
		}

	}

	private int parseCountry() {
		if (this.atTerminator()) {
			return this.blen;
		} else {
			int oldIndex = this.index++;

			int oldBlen;
			char c;
			for (oldBlen = this.blen; !this.isTerminatorOrIDSeparator(c = this.next()); this
					.append(Character.toUpperCase(c))) {
				if (oldBlen == this.blen) {
					this.hadCountry = true;
					this.addSeparator();
					++oldBlen;
				}
			}

			--this.index;
			int charsAppended = this.blen - oldBlen;
			if (charsAppended != 0) {
				if (charsAppended >= 2 && charsAppended <= 3) {
					if (charsAppended == 3) {
						String region = LocaleIDs.threeToTwoLetterRegion(this.getString(oldBlen));
						if (region != null) {
							this.set(oldBlen, region);
						}
					}
				} else {
					this.index = oldIndex;
					--oldBlen;
					this.blen = oldBlen;
					this.hadCountry = false;
				}
			}

			return oldBlen;
		}
	}

	private void skipCountry() {
		if (!this.atTerminator()) {
			++this.index;
			int oldIndex = this.index;
			this.skipUntilTerminatorOrIDSeparator();
			int charsSkipped = this.index - oldIndex;
			if (charsSkipped < 2 || charsSkipped > 3) {
				this.index = oldIndex;
			}
		}

	}

	private int parseVariant() {
		int oldBlen = this.blen;
		boolean start = true;
		boolean needSeparator = true;
		boolean skipping = false;

		char c;
		while ((c = this.next()) != '￿') {
			if (c == '.') {
				start = false;
				skipping = true;
			} else if (c == '@') {
				if (this.haveKeywordAssign()) {
					break;
				}

				skipping = false;
				start = false;
				needSeparator = true;
			} else if (start) {
				start = false;
			} else if (!skipping) {
				if (needSeparator) {
					boolean incOldBlen = this.blen == oldBlen;
					needSeparator = false;
					if (incOldBlen && !this.hadCountry) {
						this.addSeparator();
						++oldBlen;
					}

					this.addSeparator();
					if (incOldBlen) {
						++oldBlen;
					}
				}

				c = Character.toUpperCase(c);
				if (c == '-' || c == ',') {
					c = '_';
				}

				this.append(c);
			}
		}

		--this.index;
		return oldBlen;
	}

	public String getLanguage() {
		this.reset();
		return this.getString(this.parseLanguage());
	}

	public String getScript() {
		this.reset();
		this.skipLanguage();
		return this.getString(this.parseScript());
	}

	public String getCountry() {
		this.reset();
		this.skipLanguage();
		this.skipScript();
		return this.getString(this.parseCountry());
	}

	public String getVariant() {
		this.reset();
		this.skipLanguage();
		this.skipScript();
		this.skipCountry();
		return this.getString(this.parseVariant());
	}

	public String[] getLanguageScriptCountryVariant() {
		this.reset();
		return new String[]{this.getString(this.parseLanguage()), this.getString(this.parseScript()),
				this.getString(this.parseCountry()), this.getString(this.parseVariant())};
	}

	public void setBaseName(String baseName) {
		this.baseName = baseName;
	}

	public void parseBaseName() {
		if (this.baseName != null) {
			this.set(0, this.baseName);
		} else {
			this.reset();
			this.parseLanguage();
			this.parseScript();
			this.parseCountry();
			this.parseVariant();
			if (this.blen > 1 && this.buffer[this.blen - 1] == '_') {
				--this.blen;
			}
		}

	}

	public String getBaseName() {
		if (this.baseName != null) {
			return this.baseName;
		} else {
			this.parseBaseName();
			return this.getString(0);
		}
	}

	public String getName() {
		this.parseBaseName();
		this.parseKeywords();
		return this.getString(0);
	}

	private boolean setToKeywordStart() {
		for (int i = this.index; i < this.id.length; ++i) {
			if (this.id[i] == '@') {
				if (this.canonicalize) {
					++i;

					for (int j = i; j < this.id.length; ++j) {
						if (this.id[j] == '=') {
							this.index = i;
							return true;
						}
					}

					return false;
				} else {
					++i;
					if (i < this.id.length) {
						this.index = i;
						return true;
					}
					break;
				}
			}
		}

		return false;
	}

	private static boolean isDoneOrKeywordAssign(char c) {
		return c == '￿' || c == '=';
	}

	private static boolean isDoneOrItemSeparator(char c) {
		return c == '￿' || c == ';';
	}

	private String getKeyword() {
		int start = this.index;

		while (!isDoneOrKeywordAssign(this.next())) {
			;
		}

		--this.index;
		return AsciiUtil.toLowerString((new String(this.id, start, this.index - start)).trim());
	}

	private String getValue() {
		int start = this.index;

		while (!isDoneOrItemSeparator(this.next())) {
			;
		}

		--this.index;
		return (new String(this.id, start, this.index - start)).trim();
	}

	private Comparator<String> getKeyComparator() {
      Comparator<String> comp = new 1(this);
      return comp;
   }

	public Map<String, String> getKeywordMap() {
		if (this.keywords == null) {
			TreeMap<String, String> m = null;
			if (this.setToKeywordStart()) {
				do {
					String key = this.getKeyword();
					if (key.length() == 0) {
						break;
					}

					char c = this.next();
					if (c != '=') {
						if (c == '￿') {
							break;
						}
					} else {
						String value = this.getValue();
						if (value.length() != 0) {
							if (m == null) {
								m = new TreeMap(this.getKeyComparator());
							} else if (m.containsKey(key)) {
								continue;
							}

							m.put(key, value);
						}
					}
				} while (this.next() == ';');
			}

			this.keywords = (Map) (m != null ? m : Collections.emptyMap());
		}

		return this.keywords;
	}

	private int parseKeywords() {
		int oldBlen = this.blen;
		Map<String, String> m = this.getKeywordMap();
		if (!m.isEmpty()) {
			boolean first = true;
			Iterator i$ = m.entrySet().iterator();

			while (i$.hasNext()) {
				Entry<String, String> e = (Entry) i$.next();
				this.append((char) (first ? '@' : ';'));
				first = false;
				this.append((String) e.getKey());
				this.append('=');
				this.append((String) e.getValue());
			}

			if (this.blen != oldBlen) {
				++oldBlen;
			}
		}

		return oldBlen;
	}

	public Iterator<String> getKeywords() {
		Map<String, String> m = this.getKeywordMap();
		return m.isEmpty() ? null : m.keySet().iterator();
	}

	public String getKeywordValue(String keywordName) {
		Map<String, String> m = this.getKeywordMap();
		return m.isEmpty() ? null : (String) m.get(AsciiUtil.toLowerString(keywordName.trim()));
	}

	public void defaultKeywordValue(String keywordName, String value) {
		this.setKeywordValue(keywordName, value, false);
	}

	public void setKeywordValue(String keywordName, String value) {
		this.setKeywordValue(keywordName, value, true);
	}

	private void setKeywordValue(String keywordName, String value, boolean reset) {
		if (keywordName == null) {
			if (reset) {
				this.keywords = Collections.emptyMap();
			}
		} else {
			keywordName = AsciiUtil.toLowerString(keywordName.trim());
			if (keywordName.length() == 0) {
				throw new IllegalArgumentException("keyword must not be empty");
			}

			if (value != null) {
				value = value.trim();
				if (value.length() == 0) {
					throw new IllegalArgumentException("value must not be empty");
				}
			}

			Map<String, String> m = this.getKeywordMap();
			if (m.isEmpty()) {
				if (value != null) {
					this.keywords = new TreeMap(this.getKeyComparator());
					this.keywords.put(keywordName, value.trim());
				}
			} else if (reset || !m.containsKey(keywordName)) {
				if (value != null) {
					m.put(keywordName, value);
				} else {
					m.remove(keywordName);
					if (m.isEmpty()) {
						this.keywords = Collections.emptyMap();
					}
				}
			}
		}

	}
}