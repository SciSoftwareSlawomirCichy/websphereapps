package com.ibm.ejs.cm;

import com.ibm.ISecurityUtilityImpl.InvalidPasswordDecodingException;
import com.ibm.ISecurityUtilityImpl.InvalidPasswordEncodingException;
import com.ibm.ISecurityUtilityImpl.PasswordUtil;
import com.ibm.ISecurityUtilityImpl.UnsupportedCryptoAlgorithmException;
import com.ibm.ejs.cm.DataSourceProperties.1;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import com.ibm.ws.security.util.AccessController;
import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.PrivilegedActionException;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.DataSource;
import javax.sql.XADataSource;

public class DataSourceProperties implements Cloneable, Serializable {
	private static final long serialVersionUID = -8336911552307721517L;
	public static final int DATASOURCE = 1;
	public static final int CONNECTIONPOOL_DATASOURCE = 2;
	public static final int XA_DATASOURCE = 4;
	private String className;
	private transient Class dataSourceClass = null;
	private transient int dataSourceType = 0;
	private Properties props;
	private static final String bundleName = "com.ibm.ejs.resources.CONMMessages";
	private static final TraceComponent tc = Tr.register(DataSourceProperties.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public DataSourceProperties() {
		this.props = new Properties();
	}

	public DataSourceProperties(String dsClassName, Properties dsProps) {
		this.setDataSourceClassName(dsClassName);
		this.props = dsProps;
	}

	public String getDataSourceClassName() {
		return this.className;
	}

	public void setDataSourceClassName(String dsClassName) {
		this.className = dsClassName;
		this.dataSourceClass = null;
		this.dataSourceType = 0;
	}

	public DataSource getDataSource() throws SQLException {
		DataSource ds = null;

		try {
			ds = (DataSource) this.getGenericDataSource();
			return ds;
		} catch (ClassCastException var4) {
			Tr.error(tc, "MSG_CONM_7005E", this.className);
			String defaultStr = "The class (" + this.className + ") does not implement" + " javax.sql.DataSource";
			throw new SQLException(TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages")
					.getFormattedMessage("MSG_CONM_7005E", new Object[]{this.className}, defaultStr));
		}
	}

	public ConnectionPoolDataSource getConnectionPoolDataSource() throws SQLException {
		ConnectionPoolDataSource ds = null;

		try {
			ds = (ConnectionPoolDataSource) this.getGenericDataSource();
			return ds;
		} catch (ClassCastException var4) {
			Tr.error(tc, "MSG_CONM_7005E", this.className);
			String defaultStr = "The class (" + this.className + ") does not implement"
					+ " javax.sql.ConnectionPoolDataSource";
			throw new SQLException(TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages")
					.getFormattedMessage("MSG_CONM_7005E", new Object[]{this.className}, defaultStr));
		}
	}

	public XADataSource getXADataSource() throws SQLException {
		XADataSource ds = null;

		try {
			ds = (XADataSource) this.getGenericDataSource();
			return ds;
		} catch (ClassCastException var4) {
			Tr.error(tc, "MSG_CONM_7005E", this.className);
			String defaultStr = "The class (" + this.className + ") does not implement" + " javax.sql.XADataSource";
			throw new SQLException(TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages")
					.getFormattedMessage("MSG_CONM_7005E", new Object[]{this.className}, defaultStr));
		}
	}

	private Object getGenericDataSource() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getGenericDataSource");
		}

		Object ds = this.instantiateObject(this.getDataSourceClassName());
		this.setGenericDataSourceProperties(ds);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getGenericDataSource", ds);
		}

		return ds;
	}

	public int getDataSourceType() throws SQLException {
		if (this.dataSourceType == 0) {
			if (this.dataSourceClass == null) {
				this.loadDataSourceClass();
			}

			if (DataSource.class.isAssignableFrom(this.dataSourceClass)) {
				++this.dataSourceType;
			}

			if (ConnectionPoolDataSource.class.isAssignableFrom(this.dataSourceClass)) {
				this.dataSourceType += 2;
			}

			if (XADataSource.class.isAssignableFrom(this.dataSourceClass)) {
				this.dataSourceType += 4;
			}
		}

		return this.dataSourceType;
	}

	public Object setProperty(String key, String value) {
		return this.props.setProperty(key, value);
	}

	public String getProperty(String value) {
		if (value.equals("password")) {
			return PasswordUtil.passwordDecode(this.props.getProperty(value));
		} else if (value.equalsIgnoreCase("connectionProperties")) {
			try {
				return decodeOracleConnectionPropertiesPwds(this.props.getProperty(value));
			} catch (Exception var3) {
				var3.printStackTrace();
				return this.props.getProperty(value);
			}
		} else {
			return this.props.getProperty(value);
		}
	}

	public Enumeration propertyNames() {
		return this.props.propertyNames();
	}

	public Object remove(Object key) {
		return this.props.remove(key);
	}

	public boolean equals(Object o) {
		try {
			DataSourceProperties dsProps = (DataSourceProperties) o;
			return (this.className == null && dsProps.className == null || this.className.equals(dsProps.className))
					&& this.props.equals(dsProps.props);
		} catch (ClassCastException var3) {
			return false;
		}
	}

	public Object clone() {
		DataSourceProperties clone = null;

		try {
			clone = (DataSourceProperties) super.clone();
		} catch (CloneNotSupportedException var3) {
			;
		}

		if (this.props != null) {
			clone.props = (Properties) this.props.clone();
		}

		return clone;
	}

	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("DataSource Properties [" + this.getDataSourceClassName() + "]: {");

		for (Enumeration e = this.props.propertyNames(); e.hasMoreElements(); buf.append(";")) {
			String key = (String) e.nextElement();
			if (key.equals("password")) {
				buf.append("password=XXXXXXXX");
			} else if (key.equals("tmpPassword")) {
				buf.append("tmpPassword=XXXXXXXX");
			} else if (key.equalsIgnoreCase("connectionproperties")) {
				buf.append(key + "=" + hideOracleConnectionPropertiesPwds(this.props.getProperty(key)));
			} else {
				buf.append(key + "=" + this.props.getProperty(key));
			}
		}

		buf.append("}");
		return buf.toString();
	}

	private Object instantiateObject(String className) throws SQLException {
		Object dataSource = null;
		if (this.dataSourceClass == null) {
			this.loadDataSourceClass();
		}

		try {
			dataSource = this.dataSourceClass.newInstance();
			return dataSource;
		} catch (InstantiationException var4) {
			Tr.error(tc, "MSG_CONM_7006E", new Object[]{className, "<unknown>", var4});
			throw new SQLException(TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages").getFormattedMessage(
					"MSG_CONM_7006E", new Object[]{className, "<unknown>", var4}, "MSG_CONM_7006E"));
		} catch (IllegalAccessException var5) {
			Tr.error(tc, "MSG_CONM_7006E", new Object[]{className, "<unknown>", var5});
			throw new SQLException(TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages").getFormattedMessage(
					"MSG_CONM_7006E", new Object[]{className, "<unknown>", var5}, "MSG_CONM_7006E"));
		}
	}

	private void loadDataSourceClass() throws SQLException {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		if (classLoader == null) {
			classLoader = ClassLoader.getSystemClassLoader();
		}

		try {
			this.dataSourceClass = classLoader.loadClass(this.className);
		} catch (ClassNotFoundException var3) {
			Tr.error(tc, "MSG_CONM_1006E", new Object[]{this.className, "<unknown>"});
			throw new SQLException(TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages").getFormattedMessage(
					"MSG_CONM_1006E", new Object[]{this.className, "<unknown>"}, "MSG_CONM_1006E"));
		}
	}

	private void setGenericDataSourceProperties(Object dataSource) {
		String methodName = "setGenericDataSourceProperties";
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setGenericDataSourceProperties", dataSource);
		}

		Class dsClass = dataSource.getClass();
		PropertyDescriptor[] propDescriptors = null;

		try {
			propDescriptors = this.getPropertyDescriptors(dsClass);
		} catch (IntrospectionException var8) {
			Tr.error(tc, "MSG_CONM_7001E", new Object[]{dsClass.getName(), var8});
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "setGenericDataSourceProperties", var8);
			}

			return;
		}

		Enumeration e = this.props.propertyNames();

		while (e.hasMoreElements()) {
			String propertyName = (String) e.nextElement();
			String propertyValue = this.props.getProperty(propertyName);
			if (!propertyName.equals("tmpUser") && !propertyName.equals("tmpPassword") && !propertyValue.equals("")
					&& propertyValue != null) {
				this.setProperty(propertyName, propertyValue, dataSource, propDescriptors);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setGenericDataSourceProperties");
		}

	}

	private PropertyDescriptor[] getPropertyDescriptors(Class c) throws IntrospectionException {
      String methodName = "getPropertyDescriptors";
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "getPropertyDescriptors", c);
      }

      BeanInfo bi = null;

      try {
         bi = (BeanInfo)AccessController.doPrivileged(new 1(this, c));
      } catch (PrivilegedActionException var5) {
         throw (IntrospectionException)var5.getException();
      }

      PropertyDescriptor[] pd = bi.getPropertyDescriptors();
      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "getPropertyDescriptors");
      }

      return pd;
   }

	private PropertyDescriptor findPropertyDescriptorFor(String propertyName, PropertyDescriptor[] pds) {
		String methodName = "findPropertyDescriptorFor";
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "findPropertyDescriptorFor", new Object[]{propertyName, pds});
		}

		PropertyDescriptor pd = null;

		for (int i = 0; i < pds.length; ++i) {
			if (pds[i].getName().equals(propertyName)) {
				pd = pds[i];
				break;
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "findPropertyDescriptorFor", pd);
		}

		return pd;
	}

	private boolean setProperty(String propertyName, String propertyValue, Object obj,
			PropertyDescriptor[] propDescriptors) {
		if (propertyName == null) {
			return false;
		} else {
			String methodName = "setProperty";
			if (tc.isEntryEnabled()) {
				if (propertyName.equalsIgnoreCase("connectionproperties")) {
					Tr.entry(tc, "setProperty",
							new Object[]{propertyName, hideOracleConnectionPropertiesPwds(propertyValue)});
				} else if (!propertyName.equalsIgnoreCase("password")) {
					Tr.entry(tc, "setProperty", new Object[]{propertyName, propertyValue});
				} else {
					Tr.entry(tc, "setProperty", new Object[]{propertyName, "XXXXXX"});
				}
			}

			Class c = obj.getClass();
			PropertyDescriptor pd = this.findPropertyDescriptorFor(propertyName, propDescriptors);
			if (pd == null) {
				Tr.warning(tc, "MSG_CONM_7002W", new Object[]{propertyName, c.getName()});
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "setProperty", "false");
				}

				return false;
			} else {
				Object convPropVal = this.convertToDeclaredPropertyType(propertyValue, pd);
				Method method = pd.getWriteMethod();
				if (method == null) {
					Tr.warning(tc, "MSG_CONM_7003W", new Object[]{propertyName, c.getName()});
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "setProperty", "false");
					}

					return false;
				} else {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Got write method", method);
					}

					Object[] params = new Object[]{convPropVal};

					try {
						method.invoke(obj, params);
					} catch (IllegalAccessException var12) {
						Tr.warning(tc, "MSG_CONM_7004W", new Object[]{propertyName, c.getName(), var12});
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "setProperty", "false");
						}

						return false;
					} catch (IllegalArgumentException var13) {
						Tr.warning(tc, "MSG_CONM_7004W", new Object[]{propertyName, c.getName(), var13});
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "setProperty", "false");
						}

						return false;
					} catch (InvocationTargetException var14) {
						Tr.warning(tc, "MSG_CONM_7004W",
								new Object[]{propertyName, c.getName(), var14.getTargetException()});
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "setProperty", "false");
						}

						return false;
					}

					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "setProperty", "true");
					}

					return true;
				}
			}
		}
	}

	private Object convertToDeclaredPropertyType(String propertyValue, PropertyDescriptor propDescriptor) {
		String methodName = "convertToDeclaredPropertyType";
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "convertToDeclaredPropertyType", propDescriptor);
		}

		Object convertedPropertyValue = propertyValue;
		Class declaredPropertyType = propDescriptor.getPropertyType();
		if (declaredPropertyType.isAssignableFrom(String.class)) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "convertToDeclaredPropertyType");
			}

			return propertyValue;
		} else {
			Class givenPropertyType = propertyValue.getClass();
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "GivenPropertyType=" + givenPropertyType.getName() + "; DeclaredPropertyType = "
						+ declaredPropertyType.getName());
			}

			try {
				if (!declaredPropertyType.isAssignableFrom(Integer.TYPE)
						&& !declaredPropertyType.isAssignableFrom(Integer.class)) {
					if (!declaredPropertyType.isAssignableFrom(Boolean.TYPE)
							&& !declaredPropertyType.isAssignableFrom(Boolean.class)) {
						if (!declaredPropertyType.isAssignableFrom(Short.TYPE)
								&& !declaredPropertyType.isAssignableFrom(Short.class)) {
							if (declaredPropertyType.isAssignableFrom(Properties.class)) {
								convertedPropertyValue = this.convertStringToProperties(propertyValue);
							} else if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Conversion to declared method type " + declaredPropertyType.getName()
										+ " will not occur because class is unknown.");
							}
						} else {
							convertedPropertyValue = Short.valueOf(propertyValue);
						}
					} else {
						convertedPropertyValue = Boolean.valueOf(propertyValue);
					}
				} else {
					convertedPropertyValue = Integer.valueOf(propertyValue);
				}
			} catch (NumberFormatException var8) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc,
							"Attempt to convert property to Integer because the declared method is int/Integer failed",
							var8);
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "convertToDeclaredPropertyType", convertedPropertyValue);
			}

			return convertedPropertyValue;
		}
	}

	private Properties convertStringToProperties(String propStr) {
		String methodName = "convertStringToProperties";
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "convertStringToProperties", propStr);
		}

		Properties props = new Properties();
		StringTokenizer st = new StringTokenizer(propStr, ";=");

		while (st.hasMoreTokens()) {
			props.setProperty(st.nextToken(), st.nextToken());
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "convertStringToProperties", props);
		}

		return props;
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		String pwd = this.getProperty("password");
		if (pwd != null) {
			this.setProperty("password", PasswordUtil.passwordEncode(pwd));
		}

		String connectionProperties = this.getProperty("connectionProperties");
		if (connectionProperties != null) {
			try {
				this.setProperty("connectionProperties", encodeOracleConnectionPropertiesPwds(connectionProperties));
			} catch (Exception var6) {
				var6.printStackTrace();
			}
		}

		stream.defaultWriteObject();
		if (pwd != null) {
			this.setProperty("password", PasswordUtil.passwordDecode(pwd));
		}

		if (connectionProperties != null) {
			try {
				this.setProperty("connectionProperties", decodeOracleConnectionPropertiesPwds(connectionProperties));
			} catch (Exception var5) {
				var5.printStackTrace();
			}
		}

	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		String pwd = this.getProperty("password");
		if (pwd != null) {
			this.setProperty("password", PasswordUtil.passwordDecode(pwd));
		}

		String connectionProperties = this.getProperty("connectionProperties");
		if (connectionProperties != null) {
			try {
				this.setProperty("connectionProperties", decodeOracleConnectionPropertiesPwds(connectionProperties));
			} catch (Exception var5) {
				var5.printStackTrace();
			}
		}

	}

	private static String decodeOracleConnectionPropertiesPwds(String connProp)
			throws InvalidPasswordDecodingException, UnsupportedCryptoAlgorithmException {
		String pattern1 = "javax\\.net\\.ssl\\.keyStorePassword\\s*=\\s*(.*?)\\s*(;|$)";
		String pattern2 = "javax\\.net\\.ssl\\.trustStorePassword\\s*=\\s*(.*?)\\s*(;|$)";
		connProp = decodeEmbeddedPassword(connProp, "javax\\.net\\.ssl\\.keyStorePassword\\s*=\\s*(.*?)\\s*(;|$)", 1);
		return decodeEmbeddedPassword(connProp, "javax\\.net\\.ssl\\.trustStorePassword\\s*=\\s*(.*?)\\s*(;|$)", 1);
	}

	private static String decodeEmbeddedPassword(String input, String pattern, int groupNumber)
			throws InvalidPasswordDecodingException, UnsupportedCryptoAlgorithmException {
		Matcher matcher = Pattern.compile(pattern).matcher(input);
		if (!matcher.find()) {
			return input;
		} else {
			String password = matcher.group(groupNumber);
			password = PasswordUtil.getCryptoAlgorithm(password) == null ? password : PasswordUtil.decode(password);
			return (new StringBuilder(input)).replace(matcher.start(groupNumber), matcher.end(groupNumber), password)
					.toString();
		}
	}

	private static String hideOracleConnectionPropertiesPwds(String connProp) {
		String pattern1 = "javax\\.net\\.ssl\\.keyStorePassword\\s*=\\s*(.*?)\\s*(;|$)";
		String pattern2 = "javax\\.net\\.ssl\\.trustStorePassword\\s*=\\s*(.*?)\\s*(;|$)";
		connProp = hideEmbeddedPassword(connProp, "javax\\.net\\.ssl\\.keyStorePassword\\s*=\\s*(.*?)\\s*(;|$)", 1);
		return hideEmbeddedPassword(connProp, "javax\\.net\\.ssl\\.trustStorePassword\\s*=\\s*(.*?)\\s*(;|$)", 1);
	}

	private static String hideEmbeddedPassword(String input, String pattern, int groupNumber) {
		Matcher matcher = Pattern.compile(pattern).matcher(input);
		if (!matcher.find()) {
			return input;
		} else {
			String asterisks = "******";
			return (new StringBuilder(input)).replace(matcher.start(groupNumber), matcher.end(groupNumber), asterisks)
					.toString();
		}
	}

	private static String encodeOracleConnectionPropertiesPwds(String connProp)
			throws UnsupportedCryptoAlgorithmException, InvalidPasswordEncodingException {
		String pattern1 = "javax\\.net\\.ssl\\.keyStorePassword\\s*=\\s*(.*?)\\s*(;|$)";
		String pattern2 = "javax\\.net\\.ssl\\.trustStorePassword\\s*=\\s*(.*?)\\s*(;|$)";
		connProp = encodeEmbeddedPassword(connProp, "javax\\.net\\.ssl\\.keyStorePassword\\s*=\\s*(.*?)\\s*(;|$)", 1);
		return encodeEmbeddedPassword(connProp, "javax\\.net\\.ssl\\.trustStorePassword\\s*=\\s*(.*?)\\s*(;|$)", 1);
	}

	private static String encodeEmbeddedPassword(String input, String pattern, int groupNumber)
			throws UnsupportedCryptoAlgorithmException, InvalidPasswordEncodingException {
		Matcher matcher = Pattern.compile(pattern).matcher(input);
		if (!matcher.find()) {
			return input;
		} else {
			String password = matcher.group(groupNumber);
			password = PasswordUtil.getCryptoAlgorithm(password) != null ? password : PasswordUtil.encode(password);
			return (new StringBuilder(input)).replace(matcher.start(groupNumber), matcher.end(groupNumber), password)
					.toString();
		}
	}
}