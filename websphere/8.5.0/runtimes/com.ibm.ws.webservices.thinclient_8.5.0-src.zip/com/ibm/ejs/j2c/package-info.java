package com.ibm.ejs.j2c;

interface package-info {
}