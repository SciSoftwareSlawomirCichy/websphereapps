package com.ibm.ws.wim.security.authz;

import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.security.authz.SDOHelper.1;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eclipse.emf.ecore.sdo.EProperty;
import org.eclipse.emf.ecore.sdo.EType;

public class SDOHelper {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = SDOHelper.class.getName();
	private static final Logger msgLogger = WIMLogger.getMessageLogger("com.ibm.ws.wim.security.authz");
	private static final Logger trcLogger = WIMLogger.getTraceLogger("com.ibm.ws.wim.security.authz");
	public static final String NAMESPACE = "http://www.ibm.com/websphere/wim";
	public static final String CLASSNAME_ENTITY = "Entity";
	public static final String CLASSNAME_PERSON = "Person";
	public static final String CLASSNAME_PROPERTYCTRL = "PropertyControl";
	public static final String CLASSNAME_VIEWCTRL = "ViewControl";
	public static final String CLASSNAME_ENTITLECTRL = "EntitlementControl";
	public static final String PROPERTY_ROOT = "Root";
	public static final String PROPERTY_ROOT_CONTEXTS = "contexts";
	public static final String PROPERTY_ROOT_CONTROLS = "controls";
	public static final String PROPERTY_ROOT_ENTITIES = "entities";
	public static final String PROPERTY_CONTEXT_KEY = "key";
	public static final String PROPERTY_CONTEXT_VALUE = "value";
	public static final String PROPERTY_PROPERTYCTRL_PROPERTIES = "properties";
	public static final String PROPERTY_ENTITLECTRL_GET_EXCLUSIVELY = "getExclusively";
	public static final String PROPERTY_ENTITLECTRL_GET_ROLES = "getRoles";
	public static final String PROPERTY_ENTITLECTRL_GET_OBJ_ENTITLE = "getObjectEntitlements";
	public static final String PROPERTY_ENTITLECTRL_GET_ATTR_ENTITLE = "getAttributeEntitlements";
	public static final String PROPERTY_ENTITLECTRL_ENTITLE_ATTR = "entitlementAttributes";
	public static final String PROPERTY_ENTITLECTRL_ENTITLE_FILTER = "entitlementFilter";
	public static final String PROPERTY_ENTITLECTRL_ENTITLE_CHECK = "entitlementCheck";
	public static final String PROPERTY_VIEWCTRL_VIEWNAME = "viewName";
	public static final String PROPERTY_ENTITY_IDENTIFIER = "identifier";
	public static final String PROPERTY_ENTITY_UNIQUENAME = "identifier/uniqueName";
	public static final String PROPERTY_ENTITY_UNIQUEID = "identifier/uniqueId";
	public static final String PROPERTY_ENTITY_VIEW_IDS = "viewIdentifiers";
	public static final String PROPERTY_ENTITY_VIEW_IDS_VIEWNAME = "viewName";
	public static final String PROPERTY_ENTITY_VIEW_IDS_ENTRYNAME = "viewEntryName";
	public static final String PROPERTY_ENTITY_ENTITLEINFO = "entitlementInfo";
	public static final String PROPERTY_ENTITLEINFO_ROLES = "roles";
	public static final String PROPERTY_ENTITLEINFO_ENTITLEMENTS = "entitlements";
	public static final String PROPERTY_ENTITLEINFO_CHECKRESULT = "entitlementCheckResult";
	public static final String PROPERTY_ENTITLEMENT_METHOD = "method";
	public static final String PROPERTY_ENTITLEMENT_OBJECT = "object";
	public static final String PROPERTY_ENTITLEMENT_ATTRIBUTE = "attribute";
	public static final String CONFIG_ROOT = "configurationProvider";
	public static final String CONFIG_AUTHORIZATION = "authorization";
	public static final String CONFIG_SECURITY_ENABLED = "isSecurityEnabled";
	public static final String CONFIG_USE_SYSTEM_JACC_PROVIDER = "useSystemJACCProvider";
	public static final String CONFIG_IMPORT_POLICY_FROM_FILE = "importPolicyFromFile";
	public static final String CONFIG_ATTRIB_GROUPING_ENABLED = "isAttributeGroupingEnabled";
	public static final String CONFIG_JACC_POLICY_CLASS = "jaccPolicyClass";
	public static final String CONFIG_JACC_ROLEMAPPING_CLASS = "jaccRoleMappingClass";
	public static final String CONFIG_JACC_POLICY_FACTORY_CLASS = "jaccPolicyConfigFactoryClass";
	public static final String CONFIG_JACC_ROLEMAPPING_FACTORY_CLASS = "jaccRoleMappingConfigFactoryClass";
	public static final String CONFIG_JACC_ROLEPERMISSION_POLICY_ID = "jaccRoleToPermissionPolicyId";
	public static final String CONFIG_JACC_PRINCIPALROLE_POLICY_ID = "jaccPrincipalToRolePolicyId";
	public static final String CONFIG_JACC_ROLEPERMISSION_FILENAME = "jaccRoleToPermissionPolicyFileName";
	public static final String CONFIG_JACC_PRINCIPALROLE_FILENAME = "jaccPrincipalToRolePolicyFileName";
	public static final String CONFIG_DEFAULT_ATTR_GROUP = "defaultAttributeGroup";
	public static final String CONFIG_ATTRGROUPS = "attributeGroups";
	public static final String CONFIG_ATTRGROUPS_GROUPNAME = "groupName";
	public static final String CONFIG_ATTRGROUPS_ATTRNAMES = "attributeNames";
	public static final boolean TRUST_SDO_TYPE = true;
	public static final boolean TRUST_NOT_SDO_TYPE = false;
	public static final boolean GET_ATTR_ALL = true;
	public static final boolean GET_ATTR_ACTIVE = false;
	public static final boolean GET_QUALIFIED = true;
	public static final boolean GET_UNQUALIFIED = false;

	public static String getEntityDisplayName(DataObject var0) {
		String var1 = null;
		if (var0 != null && var0.get("identifier") != null
				&& (var1 = var0.getString("identifier/uniqueName")) == null) {
			var1 = var0.getString("identifier/uniqueId");
		}

		return var1 == null ? "<non-existent>" : var1;
	}

	public static String getEntityViewId(String var0, DataObject var1) {
		String var2 = null;
		List var3 = var1.getList("viewIdentifiers");
		Iterator var5 = var3.iterator();

		while (var5.hasNext()) {
			DataObject var4 = (DataObject) var5.next();
			if (var4.getString("viewName").equals(var0)) {
				var2 = var4.getString("viewEntryName");
				break;
			}
		}

		return var2;
	}

	public static Set getEntityAttributes(DataObject var0, boolean var1, boolean var2) {
		HashSet var6 = new HashSet();
		List var5 = var0.getType().getProperties();
		Iterator var7 = var5.iterator();

		while (true) {
			Property var4;
			do {
				if (!var7.hasNext()) {
					return var6;
				}

				var4 = (Property) var7.next();
			} while (!var1 && !var0.isSet(var4));

			String var3 = var2 ? getQualifiedPropertyName(var4) : var4.getName();
			var6.add(var3);
		}
	}

	public static String getEntityType(DataObject var0, boolean var1) throws WIMException {
      EClass var5;
      if (!var1) {
         DataObject var2;
         if ((var2 = var0.getDataObject("identifier")) == null) {
            return "<unknown type>";
         }

         String var3 = (String)ProfileSecurityManager.singleton().runAsSuperUser(new 1(var2));
         var5 = SchemaManager.singleton().getEClass(var3);
      } else {
         var5 = ((EDataObject)var0).eClass();
      }

      String var4 = getClassHierarchy(var5);
      trcLogger.log(Level.FINEST, "The entity ''{0}'' is of type ''{1}''", new Object[]{getEntityDisplayName(var0), var4});
      return var4;
   }

	public static String getEntityAttributeType(DataObject var0, String var1) throws WIMException {
		String var2 = var0.getType().getProperty(var1).getType().getName();
		EClass var3 = SchemaManager.singleton().getEClass(var2);
		return var3 != null ? getClassHierarchy(var3) : var2;
	}

	public static String getClassHierarchy(EClass var0) throws WIMException {
		StringBuffer var2 = new StringBuffer();
		String var1 = getQualifiedClassName(var0);
		var2.append(var1 + "/");
		if (var0.getESuperTypes().size() != 0) {
			for (var0 = (EClass) var0.getESuperTypes().iterator()
					.next(); var0 != null; var0 = var0.getESuperTypes().size() != 0
							? (EClass) var0.getESuperTypes().iterator().next()
							: null) {
				var1 = getQualifiedClassName(var0);
				var2.insert(0, var1 + "/");
			}
		}

		return var2.toString();
	}

	private static String getQualifiedClassName(EClass var0) throws WIMException {
		SchemaManager var1 = SchemaManager.singleton();
		return var1.getQualifiedTypeName(var0.getEPackage().getNsURI(), var0.getName());
	}

	private static String getQualifiedPropertyName(Property var0) {
		try {
			SchemaManager var1 = SchemaManager.singleton();
			return var1.getQualifiedPropertyName(((EProperty) var0).getEStructuralFeature());
		} catch (Exception var2) {
			return null;
		}
	}

	public static boolean isAttributeEntityType(DataObject var0, String var1) throws WIMException {
		if (var0.getType().getProperty(var1) == null) {
			return false;
		} else {
			EClassifier var2 = ((EType) var0.getType().getProperty(var1).getType()).getEClassifier();
			return isAttributeComplex(var0, var1) && getClassHierarchy((EClass) var2).startsWith("Entity");
		}
	}

	public static boolean isAttributeComplex(DataObject var0, String var1) {
		return var0.getType().getProperty(var1).getType().getProperties().size() > 0;
	}

	public static boolean isAttributeMultiValued(DataObject var0, String var1) {
		return var0.getType().getProperty(var1).isMany();
	}
}