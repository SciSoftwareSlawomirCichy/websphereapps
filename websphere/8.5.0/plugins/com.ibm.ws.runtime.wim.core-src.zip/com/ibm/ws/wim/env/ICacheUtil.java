package com.ibm.ws.wim.env;

import java.util.Map;
import java.util.Set;

public interface ICacheUtil extends Map {
	int SHARED_NA = -1;

	boolean isCacheInitialized();

	boolean isCacheAvailable();

	int getNotSharedInt();

	int getSharedPushInt();

	int getSharedPushPullInt();

	void setSharingPolicy(int var1);

	int getSharingPolicyInt(String var1);

	void setTimeToLive(int var1);

	Object get(Object var1);

	Object put(Object var1, Object var2);

	Object put(Object var1, Object var2, int var3, int var4, int var5, Object[] var6);

	void invalidate(Object var1);

	int size(boolean var1);

	boolean isEmpty(boolean var1);

	boolean containsKey(Object var1);

	boolean containsKey(Object var1, boolean var2);

	Set keySet(boolean var1);

	ICacheUtil initialize(String var1, int var2, boolean var3);

	ICacheUtil initialize(String var1, int var2, boolean var3, int var4);
}