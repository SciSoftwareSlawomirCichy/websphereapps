package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists.1;
import com.google.common.collect.Lists.2;
import com.google.common.collect.Lists.AbstractListWrapper;
import com.google.common.collect.Lists.CharSequenceAsList;
import com.google.common.collect.Lists.OnePlusArrayList;
import com.google.common.collect.Lists.Partition;
import com.google.common.collect.Lists.RandomAccessPartition;
import com.google.common.collect.Lists.RandomAccessReverseList;
import com.google.common.collect.Lists.ReverseList;
import com.google.common.collect.Lists.StringAsImmutableList;
import com.google.common.collect.Lists.TransformingRandomAccessList;
import com.google.common.collect.Lists.TransformingSequentialList;
import com.google.common.collect.Lists.TwoPlusArrayList;
import com.google.common.primitives.Ints;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
public final class Lists {
	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayList() {
		return new ArrayList();
	}

	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayList(E... elements) {
		Preconditions.checkNotNull(elements);
		int capacity = computeArrayListCapacity(elements.length);
		ArrayList<E> list = new ArrayList(capacity);
		Collections.addAll(list, elements);
		return list;
	}

	@VisibleForTesting
	static int computeArrayListCapacity(int arraySize) {
		Preconditions.checkArgument(arraySize >= 0);
		return Ints.saturatedCast(5L + (long) arraySize + (long) (arraySize / 10));
	}

	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayList(Iterable<? extends E> elements) {
		Preconditions.checkNotNull(elements);
		return elements instanceof Collection
				? new ArrayList(Collections2.cast(elements))
				: newArrayList(elements.iterator());
	}

	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayList(Iterator<? extends E> elements) {
		Preconditions.checkNotNull(elements);
		ArrayList list = newArrayList();

		while (elements.hasNext()) {
			list.add(elements.next());
		}

		return list;
	}

	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayListWithCapacity(int initialArraySize) {
		Preconditions.checkArgument(initialArraySize >= 0);
		return new ArrayList(initialArraySize);
	}

	@GwtCompatible(serializable = true)
	public static <E> ArrayList<E> newArrayListWithExpectedSize(int estimatedSize) {
		return new ArrayList(computeArrayListCapacity(estimatedSize));
	}

	@GwtCompatible(serializable = true)
	public static <E> LinkedList<E> newLinkedList() {
		return new LinkedList();
	}

	@GwtCompatible(serializable = true)
	public static <E> LinkedList<E> newLinkedList(Iterable<? extends E> elements) {
		LinkedList<E> list = newLinkedList();
		Iterator i$ = elements.iterator();

		while (i$.hasNext()) {
			E element = i$.next();
			list.add(element);
		}

		return list;
	}

	@GwtIncompatible("CopyOnWriteArrayList")
	public static <E> CopyOnWriteArrayList<E> newCopyOnWriteArrayList() {
		return new CopyOnWriteArrayList();
	}

	@GwtIncompatible("CopyOnWriteArrayList")
	public static <E> CopyOnWriteArrayList<E> newCopyOnWriteArrayList(Iterable<? extends E> elements) {
		Collection<? extends E> elementsCollection = elements instanceof Collection
				? Collections2.cast(elements)
				: newArrayList(elements);
		return new CopyOnWriteArrayList((Collection) elementsCollection);
	}

	public static <E> List<E> asList(@Nullable E first, E[] rest) {
		return new OnePlusArrayList(first, rest);
	}

	public static <E> List<E> asList(@Nullable E first, @Nullable E second, E[] rest) {
		return new TwoPlusArrayList(first, second, rest);
	}

	static <B> List<List<B>> cartesianProduct(List<? extends List<? extends B>> lists) {
		return CartesianList.create(lists);
	}

	static <B> List<List<B>> cartesianProduct(List... lists) {
		return cartesianProduct(Arrays.asList(lists));
	}

	public static <F, T> List<T> transform(List<F> fromList, Function<? super F, ? extends T> function) {
		return (List) (fromList instanceof RandomAccess
				? new TransformingRandomAccessList(fromList, function)
				: new TransformingSequentialList(fromList, function));
	}

	public static <T> List<List<T>> partition(List<T> list, int size) {
		Preconditions.checkNotNull(list);
		Preconditions.checkArgument(size > 0);
		return (List) (list instanceof RandomAccess
				? new RandomAccessPartition(list, size)
				: new Partition(list, size));
	}

	@Beta
	public static ImmutableList<Character> charactersOf(String string) {
		return new StringAsImmutableList((String) Preconditions.checkNotNull(string));
	}

	@Beta
	public static List<Character> charactersOf(CharSequence sequence) {
		return new CharSequenceAsList((CharSequence) Preconditions.checkNotNull(sequence));
	}

	public static <T> List<T> reverse(List<T> list) {
		if (list instanceof ReverseList) {
			return ((ReverseList) list).getForwardList();
		} else {
			return (List) (list instanceof RandomAccess ? new RandomAccessReverseList(list) : new ReverseList(list));
		}
	}

	static int hashCodeImpl(List<?> list) {
		int hashCode = 1;

		for (Iterator i$ = list.iterator(); i$.hasNext(); hashCode = ~(~hashCode)) {
			Object o = i$.next();
			hashCode = 31 * hashCode + (o == null ? 0 : o.hashCode());
		}

		return hashCode;
	}

	static boolean equalsImpl(List<?> list, @Nullable Object object) {
		if (object == Preconditions.checkNotNull(list)) {
			return true;
		} else if (!(object instanceof List)) {
			return false;
		} else {
			List<?> o = (List) object;
			return list.size() == o.size() && Iterators.elementsEqual(list.iterator(), o.iterator());
		}
	}

	static <E> boolean addAllImpl(List<E> list, int index, Iterable<? extends E> elements) {
		boolean changed = false;
		ListIterator<E> listIterator = list.listIterator(index);

		for (Iterator i$ = elements.iterator(); i$.hasNext(); changed = true) {
			E e = i$.next();
			listIterator.add(e);
		}

		return changed;
	}

	static int indexOfImpl(List<?> list, @Nullable Object element) {
		ListIterator listIterator = list.listIterator();

		do {
			if (!listIterator.hasNext()) {
				return -1;
			}
		} while (!Objects.equal(element, listIterator.next()));

		return listIterator.previousIndex();
	}

	static int lastIndexOfImpl(List<?> list, @Nullable Object element) {
		ListIterator listIterator = list.listIterator(list.size());

		do {
			if (!listIterator.hasPrevious()) {
				return -1;
			}
		} while (!Objects.equal(element, listIterator.previous()));

		return listIterator.nextIndex();
	}

	static <E> ListIterator<E> listIteratorImpl(List<E> list, int index) {
		return (new AbstractListWrapper(list)).listIterator(index);
	}

	static <E> List<E> subListImpl(List<E> list, int fromIndex, int toIndex) {
      Object wrapper;
      if (list instanceof RandomAccess) {
         wrapper = new 1(list);
      } else {
         wrapper = new 2(list);
      }

      return ((List)wrapper).subList(fromIndex, toIndex);
   }

	static <T> List<T> cast(Iterable<T> iterable) {
		return (List) iterable;
	}
}