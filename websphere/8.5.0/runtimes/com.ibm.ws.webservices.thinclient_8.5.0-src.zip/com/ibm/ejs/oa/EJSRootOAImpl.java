package com.ibm.ejs.oa;

import com.ibm.CORBA.iiop.IOR;
import com.ibm.CORBA.iiop.ORB;
import com.ibm.CORBA.iiop.ObjectKey;
import com.ibm.CORBA.iiop.ObjectResolver;
import com.ibm.CORBA.iiop.Profile;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.ByteArray;
import com.ibm.ejs.util.FastHashtable;
import com.ibm.ejs.util.MathUtil;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.csi.ORBDispatchInterceptor;
import com.ibm.websphere.csi.ObjectAdapter;
import com.ibm.websphere.csi.ServantManager;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.wsspi.cluster.Identity;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.util.Hashtable;
import org.omg.CORBA.SystemException;
import org.omg.CosNaming.NamingContext;

public class EJSRootOAImpl implements EJSRootObjectAdapter, ObjectResolver {
	private static final TraceComponent tc = Tr.register(EJSRootOAImpl.class, "ObjectAdapter",
			"com.ibm.ws.runtime.runtime");
	private static final String CLASS_NAME = "com.ibm.ejs.oa.EJSRootOAImpl";
	private static final int DEFAULT_SERVANT_CACHE_SIZE = 7001;
	public static final String RemoteObjectCacheSize = "com.ibm.websphere.RemoteObjectCacheSize";
	private ORB orb;
	private final Hashtable objAdapters = new Hashtable();
	private final FastHashtable ivServantObjects;
	private final FastHashtable ivServantKeys;
	private final int ivServantCacheSize;
	private boolean quiesce = false;
	private SystemException quiesceException = null;
	private byte[] serverNameBytes = null;
	private byte[] modelNameBytes = null;
	private ORBDispatchInterceptor ivORBDispatchInterceptor;

	protected EJSRootOAImpl() {
		int servantCacheSize = 7001;
		String cacheSizeString = System.getProperty("com.ibm.websphere.RemoteObjectCacheSize");
		if (cacheSizeString != null) {
			try {
				int cacheSize = Integer.parseInt(cacheSizeString);
				if (cacheSize >= 100 && cacheSize <= 50000) {
					servantCacheSize = MathUtil.findNextPrime(cacheSize);
					Tr.info(tc, "WSVR0115I", Integer.toString(servantCacheSize));
				} else {
					Tr.warning(tc, "WSVR0116W", new Object[]{cacheSizeString, Integer.toString(servantCacheSize)});
				}
			} catch (NumberFormatException var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.oa.EJSRootOAImpl.<init>", "144", this);
				Tr.warning(tc, "WSVR0117W", new Object[]{cacheSizeString, Integer.toString(servantCacheSize)});
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "RemoteObjectCacheSize = " + servantCacheSize);
		}

		this.ivServantObjects = new FastHashtable(servantCacheSize);
		this.ivServantKeys = new FastHashtable(servantCacheSize);
		this.ivServantCacheSize = servantCacheSize;
	}

	public void setORBDispatchInterceptor(ORBDispatchInterceptor interceptor) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setORBDispatchInterceptor: " + interceptor);
		}

		this.ivORBDispatchInterceptor = interceptor;
	}

	public void setModelName(String modelName) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setModelName: " + modelName);
		}

		if (modelName != null) {
			this.modelNameBytes = modelName.getBytes();
		}

	}

	public void init(ORB orb, NamingContext nc, String serverName) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "init: " + serverName);
		}

		this.orb = orb;
		this.serverNameBytes = serverName.getBytes();
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "init: " + serverName);
		}

	}

	public Object keyToObject(byte[] byteKey) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "keyToObject", byteKey);
		}

		if (this.quiesce) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "keyToObject: Server in quiesce state, throw exception");
			}

			throw this.quiesceException;
		} else {
			try {
				UserKey key = new UserKey(byteKey);
				Object result = this.ivServantObjects.get(key);
				if (result == null) {
					ByteArray oaKey = new ByteArray(key.getOAKey());
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "OA key: " + oaKey);
					}

					EJSOAImpl ejsOA = (EJSOAImpl) this.objAdapters.get(oaKey);
					if (ejsOA == null) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
							Tr.exit(tc, "keyToObject: Unknown object adapter");
						}

						throw new NoSuchObjectException("Unknown object adapter");
					}

					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Cache miss, calling OA", ejsOA);
					}

					result = ejsOA.keyToObject(key.getServantKey());
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "keyToObject: " + Util.identity(result));
				}

				return result;
			} catch (InvalidUserKeyException var6) {
				FFDCFilter.processException(var6, "com.ibm.ejs.oa.EJSRootOAImpl.keyToObject", "264", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "keyToObject: Invalid object key");
				}

				throw new NoSuchObjectException("Invalid object key");
			}
		}
	}

	public byte[] objectToKey(Object object) {
		Tr.warning(tc, "WSVR0055W", new Object[]{object});
		return null;
	}

	public Object preinvoke(Object object, String operation) {
		return this.ivORBDispatchInterceptor != null
				? this.ivORBDispatchInterceptor.preInvokeORBDispatch(object, operation)
				: null;
	}

	public void postinvoke(Object object) {
		if (this.ivORBDispatchInterceptor != null) {
			this.ivORBDispatchInterceptor.postInvokeORBDispatch(object);
		}

	}

	public ObjectAdapter createObjectAdapter(String name) throws AdapterAlreadyExistsException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "createObjectAdapter: " + name);
		}

		ObjectAdapter ejsoa = null;
		ByteArray key = new ByteArray(name.getBytes());
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "OA key: " + key);
		}

		Hashtable var4 = this.objAdapters;
		EJSOAImpl ejsoa;
		synchronized (this.objAdapters) {
			ejsoa = (ObjectAdapter) this.objAdapters.get(key);
			if (ejsoa != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "createObjectAdapter: Adapter already exists.");
				}

				throw new AdapterAlreadyExistsException();
			}

			ejsoa = new EJSOAImpl(this, name);
			this.objAdapters.put(key, ejsoa);
			if (!EJSPlatformHelper.isZOS()) {
				LocationService.registerObjectAdapter(this.orb, name);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "createObjectAdapter", ejsoa);
		}

		return ejsoa;
	}

	public EJSObjectAdapter createObjectAdapter(String name, ServantManager manager)
			throws AdapterAlreadyExistsException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "createObjectAdapter: " + name);
		}

		EJSObjectAdapter ejsoa = null;
		ByteArray key = new ByteArray(name.getBytes());
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "OA key: " + key);
		}

		Hashtable var5 = this.objAdapters;
		EJSOAImpl ejsoa;
		synchronized (this.objAdapters) {
			ejsoa = (EJSObjectAdapter) this.objAdapters.get(key);
			if (ejsoa != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "createObjectAdapter: Adapter already exists.");
				}

				throw new AdapterAlreadyExistsException();
			}

			ejsoa = new EJSOAImpl(this, name, manager);
			this.objAdapters.put(key, ejsoa);
			if (!EJSPlatformHelper.isZOS()) {
				LocationService.registerObjectAdapter(this.orb, name);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "createObjectAdapter", ejsoa);
		}

		return ejsoa;
	}

	public void destroyObjectAdapter(String name) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "destroyObjectAdapter: " + name);
		}

		this.objAdapters.remove(new ByteArray(name.getBytes()));
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "destroyObjectAdapter");
		}

	}

	public void quiesce(SystemException e) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "quiesce: exception to throw for new incoming requests=" + e);
		}

		this.quiesce = true;
		this.quiesceException = e;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "quiesce");
		}

	}

	public void retireObjectAdapter(String name) {
		if (!EJSPlatformHelper.isZOS()) {
			LocationService.unregisterObjectAdapter(this.orb, name);
		}

	}

	public ObjectAdapter getObjectAdapter(String name) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getObjectAdapter", name);
		}

		ObjectAdapter ejsoa = null;
		ByteArray key = new ByteArray(name.getBytes());
		ejsoa = (ObjectAdapter) this.objAdapters.get(key);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getObjectAdapter", ejsoa);
		}

		return ejsoa;
	}

	void registerServant(org.omg.CORBA.Object servant, byte[] key, boolean wlmable, boolean useLsd, EJSOAImpl oa) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "registerServant", new Object[]{Util.identity(servant), new ByteArray(key),
					new Boolean(wlmable), new Boolean(useLsd), oa});
		}

		UserKey completeKey = null;

		try {
			if (wlmable && this.modelNameBytes != null) {
				completeKey = new UserKey(this.modelNameBytes, true, oa.getKey().getBytes(), key);
			} else {
				completeKey = new UserKey(this.serverNameBytes, false, oa.getKey().getBytes(), key);
			}

			Profile profile = null;
			if (!EJSPlatformHelper.isZOS()) {
				if (useLsd) {
					profile = LocationService.getLSDIORProfile();
				}

				if (profile == null) {
					profile = this.orb.getTransportProfile();
				}

				if (wlmable && this.modelNameBytes != null) {
					profile = (Profile) profile.clone();
					if (WLMProfileService.getService() != null) {
						WLMProfileService.getService().setProfile(profile);
					}
				}
			}

			this.orb.register(servant, completeKey.getBytes(), profile);
			this.ivServantObjects.put(completeKey, servant);
			this.ivServantKeys.put(servant, completeKey);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				int numServants = this.ivServantObjects.size();
				Tr.debug(tc, "ServantCache: " + numServants + "/" + this.ivServantCacheSize);
				if (numServants > this.ivServantCacheSize) {
					Tr.debug(tc, "ServantCache: Optimal capacity exceeded!");
				}
			}
		} catch (InvalidUserKeyException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.oa.EJSRootOAImpl.registerServant", "574", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "registerServant", var9);
			}

			throw new Error("Invalid servant key");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "registerServant");
		}

	}

	void registerServant(org.omg.CORBA.Object servant, byte[] key, Identity cluster, boolean useLsd, EJSOAImpl oa) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "registerServant",
					new Object[]{Util.identity(servant), new ByteArray(key), cluster, new Boolean(useLsd), oa});
		}

		UserKey completeKey = null;
		boolean wlmable = cluster != null;

		try {
			if (wlmable && this.modelNameBytes != null) {
				completeKey = new UserKey(this.modelNameBytes, true, oa.getKey().getBytes(), key);
			} else {
				completeKey = new UserKey(this.serverNameBytes, false, oa.getKey().getBytes(), key);
			}

			Profile profile = null;
			if (!EJSPlatformHelper.isZOS()) {
				if (useLsd) {
					profile = LocationService.getLSDIORProfile();
				}

				if (profile == null) {
					profile = this.orb.getTransportProfile();
				}

				if (cluster != null) {
					profile = (Profile) profile.clone();
					if (WLMProfileService.getService() != null) {
						WLMProfileService.getService().setProfile(profile, cluster);
					}
				}
			}

			this.orb.register(servant, completeKey.getBytes(), profile);
			this.ivServantObjects.put(completeKey, servant);
			this.ivServantKeys.put(servant, completeKey);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				int numServants = this.ivServantObjects.size();
				Tr.debug(tc, "ServantCache: " + numServants + "/" + this.ivServantCacheSize);
				if (numServants > this.ivServantCacheSize) {
					Tr.debug(tc, "ServantCache: Optimal capacity exceeded!");
				}
			}
		} catch (InvalidUserKeyException var10) {
			FFDCFilter.processException(var10, "com.ibm.ejs.oa.EJSRootOAImpl.registerServant", "574", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "registerServant", var10);
			}

			throw new Error("Invalid servant key");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "registerServant");
		}

	}

	void registerServant(org.omg.CORBA.Object servant, ByteArray key, boolean wlmable, boolean useLsd, EJSOAImpl oa) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "registerServant",
					new Object[]{Util.identity(servant), key, new Boolean(wlmable), new Boolean(useLsd), oa});
		}

		UserKey completeKey = null;

		try {
			if (wlmable && this.modelNameBytes != null) {
				completeKey = new UserKey(this.modelNameBytes, true, oa.getKey().getBytes(), key);
			} else {
				completeKey = new UserKey(this.serverNameBytes, false, oa.getKey().getBytes(), key);
			}

			Profile profile = null;
			if (!EJSPlatformHelper.isZOS()) {
				if (useLsd) {
					profile = LocationService.getLSDIORProfile();
				}

				if (profile == null) {
					profile = this.orb.getTransportProfile();
				}

				if (wlmable && this.modelNameBytes != null) {
					profile = (Profile) profile.clone();
					if (WLMProfileService.getService() != null) {
						WLMProfileService.getService().setProfile(profile);
					}
				}
			}

			this.orb.register(servant, completeKey.getBytes(), profile);
			this.ivServantObjects.put(completeKey, servant);
			this.ivServantKeys.put(servant, completeKey);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				int numServants = this.ivServantObjects.size();
				Tr.debug(tc, "ServantCache: " + numServants + "/" + this.ivServantCacheSize);
				if (numServants > this.ivServantCacheSize) {
					Tr.debug(tc, "ServantCache: Optimal capacity exceeded!");
				}
			}
		} catch (InvalidUserKeyException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.oa.EJSRootOAImpl.registerServant", "667", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "registerServant", var9);
			}

			throw new Error("Invalid servant key");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "registerServant");
		}

	}

	void registerServant(org.omg.CORBA.Object servant, ByteArray key, Identity cluster, boolean useLsd, EJSOAImpl oa) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "registerServant",
					new Object[]{Util.identity(servant), key, cluster, new Boolean(useLsd), oa});
		}

		UserKey completeKey = null;
		boolean wlmable = cluster != null;

		try {
			if (wlmable && this.modelNameBytes != null) {
				completeKey = new UserKey(this.modelNameBytes, true, oa.getKey().getBytes(), key);
			} else {
				completeKey = new UserKey(this.serverNameBytes, false, oa.getKey().getBytes(), key);
			}

			Profile profile = null;
			if (!EJSPlatformHelper.isZOS()) {
				if (useLsd) {
					profile = LocationService.getLSDIORProfile();
				}

				if (profile == null) {
					profile = this.orb.getTransportProfile();
				}

				if (cluster != null) {
					profile = (Profile) profile.clone();
					if (WLMProfileService.getService() != null) {
						WLMProfileService.getService().setProfile(profile, cluster);
					}
				}
			}

			this.orb.register(servant, completeKey.getBytes(), profile);
			this.ivServantObjects.put(completeKey, servant);
			this.ivServantKeys.put(servant, completeKey);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				int numServants = this.ivServantObjects.size();
				Tr.debug(tc, "ServantCache: " + numServants + "/" + this.ivServantCacheSize);
				if (numServants > this.ivServantCacheSize) {
					Tr.debug(tc, "ServantCache: Optimal capacity exceeded!");
				}
			}
		} catch (InvalidUserKeyException var10) {
			FFDCFilter.processException(var10, "com.ibm.ejs.oa.EJSRootOAImpl.registerServant", "764", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "registerServant", var10);
			}

			throw new Error("Invalid servant key");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "registerServant");
		}

	}

	void registerServant(org.omg.CORBA.Object servant) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "registerServant", Util.identity(servant));
		}

		this.orb.connect(servant);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "registerServant");
		}

	}

	void unregisterServant(org.omg.CORBA.Object servant) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "unregisterServant", Util.identity(servant));
		}

		boolean var6 = false;

		try {
			var6 = true;
			this.orb.disconnect(servant);
			var6 = false;
		} finally {
			if (var6) {
				UserKey key = (UserKey) this.ivServantKeys.get(servant);
				if (key != null) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Removing servant from cache");
					}

					this.ivServantObjects.remove(key);
					this.ivServantKeys.remove(servant);
				} else if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Servant not found in cache");
				}

			}
		}

		UserKey key = (UserKey) this.ivServantKeys.get(servant);
		if (key != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Removing servant from cache");
			}

			this.ivServantObjects.remove(key);
			this.ivServantKeys.remove(servant);
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			Tr.event(tc, "Servant not found in cache");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "unregisterServant");
		}

	}

	void unregisterServantNoOrb(org.omg.CORBA.Object servant) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "unregisterServantNoOrb", Util.identity(servant));
		}

		UserKey key = (UserKey) this.ivServantKeys.get(servant);
		if (key != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Removing servant from cache");
			}

			this.ivServantObjects.remove(key);
			this.ivServantKeys.remove(servant);
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			Tr.event(tc, "Servant not found in cache");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "unregisterServantNoOrb");
		}

	}

	public IOR createIOR(ByteArray key, Identity cluster, boolean useLsd, String typeid, EJSOAImpl oa) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "createIOR", new Object[]{key, cluster, new Boolean(useLsd), oa});
		}

		UserKey completeKey = null;
		IOR ior = null;
		boolean wlmable = cluster != null;

		try {
			if (wlmable && this.modelNameBytes != null) {
				completeKey = new UserKey(this.modelNameBytes, true, oa.getKey().getBytes(), key);
			} else {
				completeKey = new UserKey(this.serverNameBytes, false, oa.getKey().getBytes(), key);
			}

			Profile profile = null;
			if (!EJSPlatformHelper.isZOS()) {
				if (useLsd) {
					profile = LocationService.getLSDIORProfile();
				}

				if (profile == null) {
					profile = this.orb.getTransportProfile();
				}

				if (wlmable && this.modelNameBytes != null) {
					profile = (Profile) ((Profile) profile).clone();
					if (WLMProfileService.getService() != null) {
						WLMProfileService.getService().setProfile((Profile) profile, cluster);
					}
				}
			} else if (wlmable && this.modelNameBytes != null && WLMProfileService.getService() != null) {
				profile = new com.ibm.rmi.Profile(this.orb);
				WLMProfileService.getService().setProfile((Profile) profile, cluster);
			}

			new ObjectKey(completeKey.getBytes());
			ORB var10000 = this.orb;
			ior = ORB.createIOR(this.orb, typeid, (Profile) profile, 1, completeKey);
		} catch (InvalidUserKeyException var11) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "createIOR", var11);
			}

			throw new Error("Invalid key");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "createIOR");
		}

		return ior;
	}

	public UserKey createCompleteKey(boolean wlmable, EJSOAImpl oa, byte[] key) {
		UserKey completeKey = null;

		try {
			if (wlmable && this.modelNameBytes != null) {
				completeKey = new UserKey(this.modelNameBytes, true, oa.getKey().getBytes(), key);
			} else {
				completeKey = new UserKey(this.serverNameBytes, false, oa.getKey().getBytes(), key);
			}

			return completeKey;
		} catch (InvalidUserKeyException var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.oa.EJSRootOAImpl.createCompleteKey", "1066", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "createCompleteKey", var6);
			}

			throw new Error("Invalid servant key");
		}
	}
}