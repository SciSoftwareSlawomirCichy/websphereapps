package com.ibm.ejs.csi;

interface package-info {
}