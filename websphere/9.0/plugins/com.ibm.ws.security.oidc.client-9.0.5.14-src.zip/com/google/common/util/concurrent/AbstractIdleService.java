package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Supplier;
import com.google.common.util.concurrent.AbstractIdleService.1;
import com.google.common.util.concurrent.AbstractIdleService.DelegateService;
import com.google.common.util.concurrent.AbstractIdleService.ThreadNameSupplier;
import com.google.common.util.concurrent.Service.Listener;
import com.google.common.util.concurrent.Service.State;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Beta
@GwtIncompatible
public abstract class AbstractIdleService implements Service {
	private final Supplier<String> threadNameSupplier = new ThreadNameSupplier(this, (1)null);
	private final Service delegate = new DelegateService(this, (1)null);

	protected abstract void startUp() throws Exception;

	protected abstract void shutDown() throws Exception;

	protected Executor executor() {
      return new 1(this);
   }

	public String toString() {
		return this.serviceName() + " [" + this.state() + "]";
	}

	public final boolean isRunning() {
		return this.delegate.isRunning();
	}

	public final State state() {
		return this.delegate.state();
	}

	public final void addListener(Listener listener, Executor executor) {
		this.delegate.addListener(listener, executor);
	}

	public final Throwable failureCause() {
		return this.delegate.failureCause();
	}

	@CanIgnoreReturnValue
	public final Service startAsync() {
		this.delegate.startAsync();
		return this;
	}

	@CanIgnoreReturnValue
	public final Service stopAsync() {
		this.delegate.stopAsync();
		return this;
	}

	public final void awaitRunning() {
		this.delegate.awaitRunning();
	}

	public final void awaitRunning(long timeout, TimeUnit unit) throws TimeoutException {
		this.delegate.awaitRunning(timeout, unit);
	}

	public final void awaitTerminated() {
		this.delegate.awaitTerminated();
	}

	public final void awaitTerminated(long timeout, TimeUnit unit) throws TimeoutException {
		this.delegate.awaitTerminated(timeout, unit);
	}

	protected String serviceName() {
		return this.getClass().getSimpleName();
	}
}