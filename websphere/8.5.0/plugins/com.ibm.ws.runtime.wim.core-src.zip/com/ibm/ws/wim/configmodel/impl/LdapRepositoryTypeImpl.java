package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.AttributeConfigurationType;
import com.ibm.ws.wim.configmodel.CacheConfigurationType;
import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ContextPoolType;
import com.ibm.ws.wim.configmodel.GroupConfigurationType;
import com.ibm.ws.wim.configmodel.LdapEntityTypesType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class LdapRepositoryTypeImpl extends ProfileRepositoryTypeImpl implements LdapRepositoryType {
	protected LdapServerConfigurationType ldapServerConfiguration = null;
	protected EList ldapEntityTypes = null;
	protected GroupConfigurationType groupConfiguration = null;
	protected AttributeConfigurationType attributeConfiguration = null;
	protected ContextPoolType contextPool = null;
	protected CacheConfigurationType cacheConfiguration = null;
	protected static final String CERTIFICATE_FILTER_EDEFAULT = null;
	protected String certificateFilter;
	protected static final String CERTIFICATE_MAP_MODE_EDEFAULT = "exactdn";
	protected String certificateMapMode;
	protected boolean certificateMapModeESet;
	protected static final String LDAP_SERVER_TYPE_EDEFAULT = null;
	protected String ldapServerType;
	protected static final boolean TRANSLATE_RDN_EDEFAULT = false;
	protected boolean translateRDN;
	protected boolean translateRDNESet;

	protected LdapRepositoryTypeImpl() {
		this.certificateFilter = CERTIFICATE_FILTER_EDEFAULT;
		this.certificateMapMode = "exactdn";
		this.certificateMapModeESet = false;
		this.ldapServerType = LDAP_SERVER_TYPE_EDEFAULT;
		this.translateRDN = false;
		this.translateRDNESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getLdapRepositoryType();
	}

	public LdapServerConfigurationType getLdapServerConfiguration() {
		return this.ldapServerConfiguration;
	}

	public NotificationChain basicSetLdapServerConfiguration(LdapServerConfigurationType var1, NotificationChain var2) {
		LdapServerConfigurationType var3 = this.ldapServerConfiguration;
		this.ldapServerConfiguration = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 18, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setLdapServerConfiguration(LdapServerConfigurationType var1) {
		if (var1 != this.ldapServerConfiguration) {
			NotificationChain var2 = null;
			if (this.ldapServerConfiguration != null) {
				var2 = ((InternalEObject) this.ldapServerConfiguration).eInverseRemove(this, -19, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -19, (Class) null, var2);
			}

			var2 = this.basicSetLdapServerConfiguration(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 18, var1, var1));
		}

	}

	public LdapServerConfigurationType createLdapServerConfiguration() {
		LdapServerConfigurationType var1 = ConfigmodelFactory.eINSTANCE.createLdapServerConfigurationType();
		this.setLdapServerConfiguration(var1);
		return var1;
	}

	public LdapEntityTypesType[] getLdapEntityTypesAsArray() {
		List var1 = this.getLdapEntityTypes();
		return (LdapEntityTypesType[]) ((LdapEntityTypesType[]) var1.toArray(new LdapEntityTypesType[var1.size()]));
	}

	public List getLdapEntityTypes() {
		if (this.ldapEntityTypes == null) {
			this.ldapEntityTypes = new EObjectContainmentEList(LdapEntityTypesType.class, this, 19);
		}

		return this.ldapEntityTypes;
	}

	public LdapEntityTypesType createLdapEntityTypes() {
		LdapEntityTypesType var1 = ConfigmodelFactory.eINSTANCE.createLdapEntityTypesType();
		this.getLdapEntityTypes().add(var1);
		return var1;
	}

	public GroupConfigurationType getGroupConfiguration() {
		return this.groupConfiguration;
	}

	public NotificationChain basicSetGroupConfiguration(GroupConfigurationType var1, NotificationChain var2) {
		GroupConfigurationType var3 = this.groupConfiguration;
		this.groupConfiguration = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 20, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setGroupConfiguration(GroupConfigurationType var1) {
		if (var1 != this.groupConfiguration) {
			NotificationChain var2 = null;
			if (this.groupConfiguration != null) {
				var2 = ((InternalEObject) this.groupConfiguration).eInverseRemove(this, -21, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -21, (Class) null, var2);
			}

			var2 = this.basicSetGroupConfiguration(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 20, var1, var1));
		}

	}

	public GroupConfigurationType createGroupConfiguration() {
		GroupConfigurationType var1 = ConfigmodelFactory.eINSTANCE.createGroupConfigurationType();
		this.setGroupConfiguration(var1);
		return var1;
	}

	public AttributeConfigurationType getAttributeConfiguration() {
		return this.attributeConfiguration;
	}

	public NotificationChain basicSetAttributeConfiguration(AttributeConfigurationType var1, NotificationChain var2) {
		AttributeConfigurationType var3 = this.attributeConfiguration;
		this.attributeConfiguration = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 21, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setAttributeConfiguration(AttributeConfigurationType var1) {
		if (var1 != this.attributeConfiguration) {
			NotificationChain var2 = null;
			if (this.attributeConfiguration != null) {
				var2 = ((InternalEObject) this.attributeConfiguration).eInverseRemove(this, -22, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -22, (Class) null, var2);
			}

			var2 = this.basicSetAttributeConfiguration(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 21, var1, var1));
		}

	}

	public AttributeConfigurationType createAttributeConfiguration() {
		AttributeConfigurationType var1 = ConfigmodelFactory.eINSTANCE.createAttributeConfigurationType();
		this.setAttributeConfiguration(var1);
		return var1;
	}

	public ContextPoolType getContextPool() {
		return this.contextPool;
	}

	public NotificationChain basicSetContextPool(ContextPoolType var1, NotificationChain var2) {
		ContextPoolType var3 = this.contextPool;
		this.contextPool = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 22, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setContextPool(ContextPoolType var1) {
		if (var1 != this.contextPool) {
			NotificationChain var2 = null;
			if (this.contextPool != null) {
				var2 = ((InternalEObject) this.contextPool).eInverseRemove(this, -23, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -23, (Class) null, var2);
			}

			var2 = this.basicSetContextPool(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 22, var1, var1));
		}

	}

	public ContextPoolType createContextPool() {
		ContextPoolType var1 = ConfigmodelFactory.eINSTANCE.createContextPoolType();
		this.setContextPool(var1);
		return var1;
	}

	public CacheConfigurationType getCacheConfiguration() {
		return this.cacheConfiguration;
	}

	public NotificationChain basicSetCacheConfiguration(CacheConfigurationType var1, NotificationChain var2) {
		CacheConfigurationType var3 = this.cacheConfiguration;
		this.cacheConfiguration = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 23, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setCacheConfiguration(CacheConfigurationType var1) {
		if (var1 != this.cacheConfiguration) {
			NotificationChain var2 = null;
			if (this.cacheConfiguration != null) {
				var2 = ((InternalEObject) this.cacheConfiguration).eInverseRemove(this, -24, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -24, (Class) null, var2);
			}

			var2 = this.basicSetCacheConfiguration(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 23, var1, var1));
		}

	}

	public CacheConfigurationType createCacheConfiguration() {
		CacheConfigurationType var1 = ConfigmodelFactory.eINSTANCE.createCacheConfigurationType();
		this.setCacheConfiguration(var1);
		return var1;
	}

	public String getCertificateFilter() {
		return this.certificateFilter;
	}

	public void setCertificateFilter(String var1) {
		String var2 = this.certificateFilter;
		this.certificateFilter = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 24, var2, this.certificateFilter));
		}

	}

	public String getCertificateMapMode() {
		return this.certificateMapMode;
	}

	public void setCertificateMapMode(String var1) {
		String var2 = this.certificateMapMode;
		this.certificateMapMode = var1;
		boolean var3 = this.certificateMapModeESet;
		this.certificateMapModeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 25, var2, this.certificateMapMode, !var3));
		}

	}

	public void unsetCertificateMapMode() {
		String var1 = this.certificateMapMode;
		boolean var2 = this.certificateMapModeESet;
		this.certificateMapMode = "exactdn";
		this.certificateMapModeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 25, var1, "exactdn", var2));
		}

	}

	public boolean isSetCertificateMapMode() {
		return this.certificateMapModeESet;
	}

	public String getLdapServerType() {
		return this.ldapServerType;
	}

	public void setLdapServerType(String var1) {
		String var2 = this.ldapServerType;
		this.ldapServerType = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 26, var2, this.ldapServerType));
		}

	}

	public boolean isTranslateRDN() {
		return this.translateRDN;
	}

	public void setTranslateRDN(boolean var1) {
		boolean var2 = this.translateRDN;
		this.translateRDN = var1;
		boolean var3 = this.translateRDNESet;
		this.translateRDNESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 27, var2, this.translateRDN, !var3));
		}

	}

	public void unsetTranslateRDN() {
		boolean var1 = this.translateRDN;
		boolean var2 = this.translateRDNESet;
		this.translateRDN = false;
		this.translateRDNESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 27, var1, false, var2));
		}

	}

	public boolean isSetTranslateRDN() {
		return this.translateRDNESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 2 :
					return ((InternalEList) this.getBaseEntries()).basicRemove(var1, var4);
				case 3 :
				case 4 :
				case 5 :
				case 6 :
				case 7 :
				case 8 :
				case 10 :
				case 11 :
				case 12 :
				case 13 :
				case 14 :
				case 15 :
				case 16 :
				case 17 :
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
				case 9 :
					return ((InternalEList) this.getCustomProperties()).basicRemove(var1, var4);
				case 18 :
					return this.basicSetLdapServerConfiguration((LdapServerConfigurationType) null, var4);
				case 19 :
					return ((InternalEList) this.getLdapEntityTypes()).basicRemove(var1, var4);
				case 20 :
					return this.basicSetGroupConfiguration((GroupConfigurationType) null, var4);
				case 21 :
					return this.basicSetAttributeConfiguration((AttributeConfigurationType) null, var4);
				case 22 :
					return this.basicSetContextPool((ContextPoolType) null, var4);
				case 23 :
					return this.basicSetCacheConfiguration((CacheConfigurationType) null, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getAdapterClassName();
			case 1 :
				return this.getId();
			case 2 :
				return this.getBaseEntries();
			case 3 :
				return this.getEntityTypesNotAllowCreate();
			case 4 :
				return this.getEntityTypesNotAllowUpdate();
			case 5 :
				return this.getEntityTypesNotAllowRead();
			case 6 :
				return this.getEntityTypesNotAllowDelete();
			case 7 :
				return this.getRepositoriesForGroups();
			case 8 :
				return this.getLoginProperties();
			case 9 :
				return this.getCustomProperties();
			case 10 :
				return this.isIsExtIdUnique() ? Boolean.TRUE : Boolean.FALSE;
			case 11 :
				return this.isReadOnly() ? Boolean.TRUE : Boolean.FALSE;
			case 12 :
				return this.isSupportAsyncMode() ? Boolean.TRUE : Boolean.FALSE;
			case 13 :
				return this.isSupportExternalName() ? Boolean.TRUE : Boolean.FALSE;
			case 14 :
				return this.isSupportPaging() ? Boolean.TRUE : Boolean.FALSE;
			case 15 :
				return this.isSupportSorting() ? Boolean.TRUE : Boolean.FALSE;
			case 16 :
				return this.isSupportTransactions() ? Boolean.TRUE : Boolean.FALSE;
			case 17 :
				return this.getSupportChangeLog();
			case 18 :
				return this.getLdapServerConfiguration();
			case 19 :
				return this.getLdapEntityTypes();
			case 20 :
				return this.getGroupConfiguration();
			case 21 :
				return this.getAttributeConfiguration();
			case 22 :
				return this.getContextPool();
			case 23 :
				return this.getCacheConfiguration();
			case 24 :
				return this.getCertificateFilter();
			case 25 :
				return this.getCertificateMapMode();
			case 26 :
				return this.getLdapServerType();
			case 27 :
				return this.isTranslateRDN() ? Boolean.TRUE : Boolean.FALSE;
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName((String) var2);
				return;
			case 1 :
				this.setId((String) var2);
				return;
			case 2 :
				this.getBaseEntries().clear();
				this.getBaseEntries().addAll((Collection) var2);
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				this.getEntityTypesNotAllowCreate().addAll((Collection) var2);
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				this.getEntityTypesNotAllowUpdate().addAll((Collection) var2);
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				this.getEntityTypesNotAllowRead().addAll((Collection) var2);
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				this.getEntityTypesNotAllowDelete().addAll((Collection) var2);
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				this.getRepositoriesForGroups().addAll((Collection) var2);
				return;
			case 8 :
				this.getLoginProperties().clear();
				this.getLoginProperties().addAll((Collection) var2);
				return;
			case 9 :
				this.getCustomProperties().clear();
				this.getCustomProperties().addAll((Collection) var2);
				return;
			case 10 :
				this.setIsExtIdUnique((Boolean) var2);
				return;
			case 11 :
				this.setReadOnly((Boolean) var2);
				return;
			case 12 :
				this.setSupportAsyncMode((Boolean) var2);
				return;
			case 13 :
				this.setSupportExternalName((Boolean) var2);
				return;
			case 14 :
				this.setSupportPaging((Boolean) var2);
				return;
			case 15 :
				this.setSupportSorting((Boolean) var2);
				return;
			case 16 :
				this.setSupportTransactions((Boolean) var2);
				return;
			case 17 :
				this.setSupportChangeLog((String) var2);
				return;
			case 18 :
				this.setLdapServerConfiguration((LdapServerConfigurationType) var2);
				return;
			case 19 :
				this.getLdapEntityTypes().clear();
				this.getLdapEntityTypes().addAll((Collection) var2);
				return;
			case 20 :
				this.setGroupConfiguration((GroupConfigurationType) var2);
				return;
			case 21 :
				this.setAttributeConfiguration((AttributeConfigurationType) var2);
				return;
			case 22 :
				this.setContextPool((ContextPoolType) var2);
				return;
			case 23 :
				this.setCacheConfiguration((CacheConfigurationType) var2);
				return;
			case 24 :
				this.setCertificateFilter((String) var2);
				return;
			case 25 :
				this.setCertificateMapMode((String) var2);
				return;
			case 26 :
				this.setLdapServerType((String) var2);
				return;
			case 27 :
				this.setTranslateRDN((Boolean) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName(ADAPTER_CLASS_NAME_EDEFAULT);
				return;
			case 1 :
				this.setId(ID_EDEFAULT);
				return;
			case 2 :
				this.getBaseEntries().clear();
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				return;
			case 8 :
				this.getLoginProperties().clear();
				return;
			case 9 :
				this.getCustomProperties().clear();
				return;
			case 10 :
				this.unsetIsExtIdUnique();
				return;
			case 11 :
				this.unsetReadOnly();
				return;
			case 12 :
				this.unsetSupportAsyncMode();
				return;
			case 13 :
				this.unsetSupportExternalName();
				return;
			case 14 :
				this.unsetSupportPaging();
				return;
			case 15 :
				this.unsetSupportSorting();
				return;
			case 16 :
				this.unsetSupportTransactions();
				return;
			case 17 :
				this.unsetSupportChangeLog();
				return;
			case 18 :
				this.setLdapServerConfiguration((LdapServerConfigurationType) null);
				return;
			case 19 :
				this.getLdapEntityTypes().clear();
				return;
			case 20 :
				this.setGroupConfiguration((GroupConfigurationType) null);
				return;
			case 21 :
				this.setAttributeConfiguration((AttributeConfigurationType) null);
				return;
			case 22 :
				this.setContextPool((ContextPoolType) null);
				return;
			case 23 :
				this.setCacheConfiguration((CacheConfigurationType) null);
				return;
			case 24 :
				this.setCertificateFilter(CERTIFICATE_FILTER_EDEFAULT);
				return;
			case 25 :
				this.unsetCertificateMapMode();
				return;
			case 26 :
				this.setLdapServerType(LDAP_SERVER_TYPE_EDEFAULT);
				return;
			case 27 :
				this.unsetTranslateRDN();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return ADAPTER_CLASS_NAME_EDEFAULT == null
						? this.adapterClassName != null
						: !ADAPTER_CLASS_NAME_EDEFAULT.equals(this.adapterClassName);
			case 1 :
				return ID_EDEFAULT == null ? this.id != null : !ID_EDEFAULT.equals(this.id);
			case 2 :
				return this.baseEntries != null && !this.baseEntries.isEmpty();
			case 3 :
				return this.entityTypesNotAllowCreate != null && !this.entityTypesNotAllowCreate.isEmpty();
			case 4 :
				return this.entityTypesNotAllowUpdate != null && !this.entityTypesNotAllowUpdate.isEmpty();
			case 5 :
				return this.entityTypesNotAllowRead != null && !this.entityTypesNotAllowRead.isEmpty();
			case 6 :
				return this.entityTypesNotAllowDelete != null && !this.entityTypesNotAllowDelete.isEmpty();
			case 7 :
				return this.repositoriesForGroups != null && !this.repositoriesForGroups.isEmpty();
			case 8 :
				return this.loginProperties != null && !this.loginProperties.isEmpty();
			case 9 :
				return this.customProperties != null && !this.customProperties.isEmpty();
			case 10 :
				return this.isSetIsExtIdUnique();
			case 11 :
				return this.isSetReadOnly();
			case 12 :
				return this.isSetSupportAsyncMode();
			case 13 :
				return this.isSetSupportExternalName();
			case 14 :
				return this.isSetSupportPaging();
			case 15 :
				return this.isSetSupportSorting();
			case 16 :
				return this.isSetSupportTransactions();
			case 17 :
				return this.isSetSupportChangeLog();
			case 18 :
				return this.ldapServerConfiguration != null;
			case 19 :
				return this.ldapEntityTypes != null && !this.ldapEntityTypes.isEmpty();
			case 20 :
				return this.groupConfiguration != null;
			case 21 :
				return this.attributeConfiguration != null;
			case 22 :
				return this.contextPool != null;
			case 23 :
				return this.cacheConfiguration != null;
			case 24 :
				return CERTIFICATE_FILTER_EDEFAULT == null
						? this.certificateFilter != null
						: !CERTIFICATE_FILTER_EDEFAULT.equals(this.certificateFilter);
			case 25 :
				return this.isSetCertificateMapMode();
			case 26 :
				return LDAP_SERVER_TYPE_EDEFAULT == null
						? this.ldapServerType != null
						: !LDAP_SERVER_TYPE_EDEFAULT.equals(this.ldapServerType);
			case 27 :
				return this.isSetTranslateRDN();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (certificateFilter: ");
			var1.append(this.certificateFilter);
			var1.append(", certificateMapMode: ");
			if (this.certificateMapModeESet) {
				var1.append(this.certificateMapMode);
			} else {
				var1.append("<unset>");
			}

			var1.append(", ldapServerType: ");
			var1.append(this.ldapServerType);
			var1.append(", translateRDN: ");
			if (this.translateRDNESet) {
				var1.append(this.translateRDN);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}