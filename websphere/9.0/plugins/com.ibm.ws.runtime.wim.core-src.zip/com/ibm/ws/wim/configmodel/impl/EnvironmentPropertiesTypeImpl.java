package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.EnvironmentPropertiesType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class EnvironmentPropertiesTypeImpl extends EDataObjectImpl implements EnvironmentPropertiesType {
	protected static final String NAME_EDEFAULT = null;
	protected String name;
	protected static final String VALUE_EDEFAULT = null;
	protected String value;

	protected EnvironmentPropertiesTypeImpl() {
		this.name = NAME_EDEFAULT;
		this.value = VALUE_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getEnvironmentPropertiesType();
	}

	public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		String var2 = this.name;
		this.name = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.name));
		}

	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String var1) {
		String var2 = this.value;
		this.value = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.value));
		}

	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getName();
			case 1 :
				return this.getValue();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setName((String) var2);
				return;
			case 1 :
				this.setValue((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setName(NAME_EDEFAULT);
				return;
			case 1 :
				this.setValue(VALUE_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return NAME_EDEFAULT == null ? this.name != null : !NAME_EDEFAULT.equals(this.name);
			case 1 :
				return VALUE_EDEFAULT == null ? this.value != null : !VALUE_EDEFAULT.equals(this.value);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (name: ");
			var1.append(this.name);
			var1.append(", value: ");
			var1.append(this.value);
			var1.append(')');
			return var1.toString();
		}
	}
}