package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.SPIBridgeRepositoryType;
import java.util.Collection;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.InternalEList;

public class SPIBridgeRepositoryTypeImpl extends ProfileRepositoryTypeImpl implements SPIBridgeRepositoryType {
	protected static final String WMM_ADAPTER_CLASS_NAME_EDEFAULT = null;
	protected String wMMAdapterClassName;

	protected SPIBridgeRepositoryTypeImpl() {
		this.wMMAdapterClassName = WMM_ADAPTER_CLASS_NAME_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getSPIBridgeRepositoryType();
	}

	public String getWMMAdapterClassName() {
		return this.wMMAdapterClassName;
	}

	public void setWMMAdapterClassName(String var1) {
		String var2 = this.wMMAdapterClassName;
		this.wMMAdapterClassName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 18, var2, this.wMMAdapterClassName));
		}

	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 2 :
					return ((InternalEList) this.getBaseEntries()).basicRemove(var1, var4);
				case 9 :
					return ((InternalEList) this.getCustomProperties()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getAdapterClassName();
			case 1 :
				return this.getId();
			case 2 :
				return this.getBaseEntries();
			case 3 :
				return this.getEntityTypesNotAllowCreate();
			case 4 :
				return this.getEntityTypesNotAllowUpdate();
			case 5 :
				return this.getEntityTypesNotAllowRead();
			case 6 :
				return this.getEntityTypesNotAllowDelete();
			case 7 :
				return this.getRepositoriesForGroups();
			case 8 :
				return this.getLoginProperties();
			case 9 :
				return this.getCustomProperties();
			case 10 :
				return this.isIsExtIdUnique() ? Boolean.TRUE : Boolean.FALSE;
			case 11 :
				return this.isReadOnly() ? Boolean.TRUE : Boolean.FALSE;
			case 12 :
				return this.isSupportAsyncMode() ? Boolean.TRUE : Boolean.FALSE;
			case 13 :
				return this.isSupportExternalName() ? Boolean.TRUE : Boolean.FALSE;
			case 14 :
				return this.isSupportPaging() ? Boolean.TRUE : Boolean.FALSE;
			case 15 :
				return this.isSupportSorting() ? Boolean.TRUE : Boolean.FALSE;
			case 16 :
				return this.isSupportTransactions() ? Boolean.TRUE : Boolean.FALSE;
			case 17 :
				return this.getSupportChangeLog();
			case 18 :
				return this.getWMMAdapterClassName();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName((String) var2);
				return;
			case 1 :
				this.setId((String) var2);
				return;
			case 2 :
				this.getBaseEntries().clear();
				this.getBaseEntries().addAll((Collection) var2);
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				this.getEntityTypesNotAllowCreate().addAll((Collection) var2);
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				this.getEntityTypesNotAllowUpdate().addAll((Collection) var2);
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				this.getEntityTypesNotAllowRead().addAll((Collection) var2);
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				this.getEntityTypesNotAllowDelete().addAll((Collection) var2);
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				this.getRepositoriesForGroups().addAll((Collection) var2);
				return;
			case 8 :
				this.getLoginProperties().clear();
				this.getLoginProperties().addAll((Collection) var2);
				return;
			case 9 :
				this.getCustomProperties().clear();
				this.getCustomProperties().addAll((Collection) var2);
				return;
			case 10 :
				this.setIsExtIdUnique((Boolean) var2);
				return;
			case 11 :
				this.setReadOnly((Boolean) var2);
				return;
			case 12 :
				this.setSupportAsyncMode((Boolean) var2);
				return;
			case 13 :
				this.setSupportExternalName((Boolean) var2);
				return;
			case 14 :
				this.setSupportPaging((Boolean) var2);
				return;
			case 15 :
				this.setSupportSorting((Boolean) var2);
				return;
			case 16 :
				this.setSupportTransactions((Boolean) var2);
				return;
			case 17 :
				this.setSupportChangeLog((String) var2);
				return;
			case 18 :
				this.setWMMAdapterClassName((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName(ADAPTER_CLASS_NAME_EDEFAULT);
				return;
			case 1 :
				this.setId(ID_EDEFAULT);
				return;
			case 2 :
				this.getBaseEntries().clear();
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				return;
			case 8 :
				this.getLoginProperties().clear();
				return;
			case 9 :
				this.getCustomProperties().clear();
				return;
			case 10 :
				this.unsetIsExtIdUnique();
				return;
			case 11 :
				this.unsetReadOnly();
				return;
			case 12 :
				this.unsetSupportAsyncMode();
				return;
			case 13 :
				this.unsetSupportExternalName();
				return;
			case 14 :
				this.unsetSupportPaging();
				return;
			case 15 :
				this.unsetSupportSorting();
				return;
			case 16 :
				this.unsetSupportTransactions();
				return;
			case 17 :
				this.unsetSupportChangeLog();
				return;
			case 18 :
				this.setWMMAdapterClassName(WMM_ADAPTER_CLASS_NAME_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return ADAPTER_CLASS_NAME_EDEFAULT == null
						? this.adapterClassName != null
						: !ADAPTER_CLASS_NAME_EDEFAULT.equals(this.adapterClassName);
			case 1 :
				return ID_EDEFAULT == null ? this.id != null : !ID_EDEFAULT.equals(this.id);
			case 2 :
				return this.baseEntries != null && !this.baseEntries.isEmpty();
			case 3 :
				return this.entityTypesNotAllowCreate != null && !this.entityTypesNotAllowCreate.isEmpty();
			case 4 :
				return this.entityTypesNotAllowUpdate != null && !this.entityTypesNotAllowUpdate.isEmpty();
			case 5 :
				return this.entityTypesNotAllowRead != null && !this.entityTypesNotAllowRead.isEmpty();
			case 6 :
				return this.entityTypesNotAllowDelete != null && !this.entityTypesNotAllowDelete.isEmpty();
			case 7 :
				return this.repositoriesForGroups != null && !this.repositoriesForGroups.isEmpty();
			case 8 :
				return this.loginProperties != null && !this.loginProperties.isEmpty();
			case 9 :
				return this.customProperties != null && !this.customProperties.isEmpty();
			case 10 :
				return this.isSetIsExtIdUnique();
			case 11 :
				return this.isSetReadOnly();
			case 12 :
				return this.isSetSupportAsyncMode();
			case 13 :
				return this.isSetSupportExternalName();
			case 14 :
				return this.isSetSupportPaging();
			case 15 :
				return this.isSetSupportSorting();
			case 16 :
				return this.isSetSupportTransactions();
			case 17 :
				return this.isSetSupportChangeLog();
			case 18 :
				return WMM_ADAPTER_CLASS_NAME_EDEFAULT == null
						? this.wMMAdapterClassName != null
						: !WMM_ADAPTER_CLASS_NAME_EDEFAULT.equals(this.wMMAdapterClassName);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (wMMAdapterClassName: ");
			var1.append(this.wMMAdapterClassName);
			var1.append(')');
			return var1.toString();
		}
	}
}