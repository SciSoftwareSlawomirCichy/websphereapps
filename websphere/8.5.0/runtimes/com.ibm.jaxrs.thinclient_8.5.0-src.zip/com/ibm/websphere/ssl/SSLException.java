package com.ibm.websphere.ssl;

public class SSLException extends Exception {
	public SSLException() {
	}

	public SSLException(Exception e) {
		super(e);
	}

	public SSLException(String message) {
		super(message);
	}

	public SSLException(String message, Exception e) {
		super(message, e);
	}
}