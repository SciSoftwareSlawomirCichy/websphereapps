package com.ibm.ws.wim.adapter.ldap.change;

import com.ibm.websphere.wim.exception.WIMException;
import java.util.List;

public interface IChangeHandler {
	String getCurrentCheckPoint() throws WIMException;

	List searchChangedEntities(String var1, List var2, String var3, String var4, int var5, List var6, List var7,
			int var8, int var9) throws WIMException;
}