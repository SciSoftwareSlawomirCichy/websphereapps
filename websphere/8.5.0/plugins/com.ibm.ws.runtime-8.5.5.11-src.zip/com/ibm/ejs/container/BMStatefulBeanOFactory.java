package com.ibm.ejs.container;

import com.ibm.ws.managedobject.ManagedObject;

public class BMStatefulBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		return new BMStatefulBeanO(c, mo, b, h);
	}
}