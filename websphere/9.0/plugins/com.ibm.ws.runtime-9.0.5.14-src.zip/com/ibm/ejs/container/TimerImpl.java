package com.ibm.ejs.container;

import com.ibm.ejs.container.passivator.PassivatorSerializable;
import com.ibm.ejs.container.passivator.PassivatorSerializableHandle;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.TransactionAttribute;
import com.ibm.websphere.scheduler.Scheduler;
import com.ibm.websphere.scheduler.SchedulerException;
import com.ibm.websphere.scheduler.TaskInvalid;
import com.ibm.websphere.scheduler.TaskPending;
import com.ibm.websphere.scheduler.TaskStatus;
import com.ibm.ws.ejbcontainer.util.ParsedScheduleExpression;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.metadata.ejb.TimerMethodData.AutomaticTimer;
import com.ibm.ws.runtime.component.WASEJBRuntime;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import javax.ejb.EJBException;
import javax.ejb.NoMoreTimeoutsException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.ScheduleExpression;
import javax.ejb.Timer;
import javax.ejb.TimerHandle;

public final class TimerImpl implements Timer, PassivatorSerializable {
	private static final TraceComponent tc = Tr.register(TimerImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.TimerImpl";
	private String ivTaskId;
	private BeanId ivBeanId;
	private EJSHome ivHome;
	private Scheduler ivScheduler;
	private int ivHashCode;
	protected boolean ivIsExecutingEJBTimeout;
	protected TaskStatus ivStatus;
	protected TimerTaskHandler ivHandler;
	protected boolean ivIsHandlerInfoUsed;
	boolean ivNoMoreTimeouts;

	private static Scheduler getScheduler(EJSHome home) {
		return ((WASEJBRuntime) home.container.getEJBRuntime()).getTimerServiceScheduler();
	}

	private TimerImpl(BeanId beanId) {
		this.ivIsExecutingEJBTimeout = false;
		this.ivIsHandlerInfoUsed = false;
		this.ivBeanId = beanId;
		this.ivHome = (EJSHome) beanId.home;
		this.ivScheduler = getScheduler(this.ivHome);
	}

	public TimerImpl(BeanId beanId, Date expiration, long interval, Serializable info) {
		this(beanId);
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			String infoClassName = info == null ? null : info.getClass().getName();
			Tr.entry(tc, "TimerImpl: " + beanId + ", " + expiration + ", " + interval + ", " + infoClassName);
		}

		this.createSchedulerTask(expiration, interval, (ParsedScheduleExpression) null, info);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, this.toString());
		}

	}

	public TimerImpl(BeanId beanId, ParsedScheduleExpression parsedExpr, Serializable info) {
		this(beanId);
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			String infoClassName = info == null ? null : info.getClass().getName();
			Tr.entry(tc, "TimerImpl (calendar): " + beanId + ", " + infoClassName);
		}

		long firstTimeout = parsedExpr.getFirstTimeout();
		if (firstTimeout != -1L) {
			this.createSchedulerTask(new Date(firstTimeout), -1L, parsedExpr, info);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, this.toString());
		}

	}

	TimerImpl(BeanId beanId, String taskId, int hashCode) {
		this(beanId);
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "TimerImpl : " + beanId + ", " + taskId);
		}

		this.ivTaskId = taskId;
		this.ivHashCode = hashCode;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, this.toString());
		}

	}

	private void createSchedulerTask(Date expiration, long interval, ParsedScheduleExpression parsedSchedule,
			Serializable info) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createSchedulerTask: " + expiration + ", " + interval);
		}

		try {
			TimerTaskInfoImpl taskInfo = createSchedulerTaskInfo(((EJSHome) this.ivBeanId.home).beanMetaData,
					this.ivBeanId, (AutomaticTimer) null, expiration, interval, parsedSchedule, info);
			this.ivStatus = this.ivScheduler.create(taskInfo);
			this.ivHandler = taskInfo.getHandler();
			this.ivTaskId = this.ivStatus.getTaskId();
			this.ivHashCode = this.ivStatus.hashCode();
		} catch (Throwable var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.container.TimerImpl.<init>", "128", this);
			TimerServiceException tse = new TimerServiceException(this.toString(), var9);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "TimerImpl: " + tse);
			}

			throw tse;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createSchedulerTask: " + this.ivTaskId);
		}

	}

	public static TimerTaskInfoImpl createSchedulerTaskInfo(BeanMetaData bmd, BeanId beanId, AutomaticTimer autoTimer,
			Date expiration, long interval, ParsedScheduleExpression parsedSchedule, Serializable info)
			throws IOException {
		boolean runInGlobalTx = false;
		int methodId = autoTimer == null ? 0 : autoTimer.getMethod().getMethodId();
		TransactionAttribute txAttr = bmd.timedMethodInfos[methodId].getTransactionAttribute();
		if (txAttr == TransactionAttribute.TX_REQUIRED) {
			runInGlobalTx = true;
		}

		return new TimerTaskInfoImpl(beanId, autoTimer, expiration, interval, parsedSchedule, info, getTaskName(beanId),
				runInGlobalTx);
	}

	public void cancel() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "cancel: " + this);
		}

		this.checkTimerAccess();
		int retryCount = 0;
		long startTime = -1L;
		TaskStatus status = null;

		TimerServiceException tse;
		try {
			while (status == null) {
				try {
					status = this.ivScheduler.cancel(this.ivTaskId, true);
				} catch (TaskPending var9) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "cancel: pending : retryCount = " + retryCount);
					}

					long currentTime = System.currentTimeMillis();
					if (startTime == -1L) {
						startTime = currentTime;
					}

					if (currentTime - startTime > ContainerProperties.TimerCancelTimeout) {
						throw var9;
					}

					++retryCount;
					if (retryCount > 9) {
						Thread.sleep(1000L);
						retryCount = 0;
					} else if (retryCount > 7) {
						Thread.sleep(500L);
					} else if (retryCount > 1) {
						Thread.sleep(50L);
					} else {
						Thread.yield();
					}
				}
			}
		} catch (TaskInvalid var10) {
			NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(this.toString(), var10);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "cancel: " + nsoe);
			}

			throw nsoe;
		} catch (TaskPending var11) {
			FFDCFilter.processException(var11, "com.ibm.ejs.container.TimerImpl.cancel", "419", this);
			tse = new TimerServiceException("Timer is in use and could not be cancelled : " + this, var11);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "cancel: " + tse);
			}

			throw tse;
		} catch (Throwable var12) {
			FFDCFilter.processException(var12, "com.ibm.ejs.container.TimerImpl.cancel", "215", this);
			tse = new TimerServiceException(this.toString(), var12);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "cancel: " + tse);
			}

			throw tse;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "cancel: successful");
		}

	}

	private boolean isCachingAllowed(int operation) {
		return this.ivIsExecutingEJBTimeout
				|| (this.ivHome.beanMetaData.allowCachedTimerDataForMethods & operation) != 0;
	}

	private TaskStatus getTaskStatus(int operation) throws SchedulerException {
		if (this.ivStatus == null || !this.isCachingAllowed(operation)) {
			this.ivStatus = this.ivScheduler.getStatus(this.ivTaskId);
		}

		return this.ivStatus;
	}

	private TimerTaskHandler getTaskHandler(int operation) throws SchedulerException {
		if (this.ivHandler == null || !this.isCachingAllowed(operation)) {
			TimerTaskInfoImpl taskInfo = (TimerTaskInfoImpl) this.ivScheduler.getTask(this.ivTaskId);
			this.ivHandler = taskInfo.getHandler();
		}

		return this.ivHandler;
	}

	public long getTimeRemaining() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		Date nextTime = this.getNextTimeout(8);
		long currentTime = System.currentTimeMillis();
		long remaining = nextTime.getTime() - currentTime;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getTimeRemaining: " + remaining);
		}

		return remaining;
	}

	public Date getNextTimeout() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getNextTimeout: " + this);
		}

		Date nextTime = this.getNextTimeout(4);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getNextTimeout: " + nextTime);
		}

		return nextTime;
	}

	private Date getNextTimeout(int operation) throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getNextTimeout: " + operation);
		}

		this.checkTimerAccess();
		if (this.ivNoMoreTimeouts) {
			NoMoreTimeoutsException nmte = new NoMoreTimeoutsException(this.toString());
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getNextTimeout: " + nmte);
			}

			throw nmte;
		} else {
			Date nextTime = null;

			try {
				TaskStatus taskStatus = this.getTaskStatus(operation);
				nextTime = taskStatus.getNextFireTime();
			} catch (TaskInvalid var6) {
				NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(this.toString(), var6);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "getNextTimeout: " + nsoe);
				}

				throw nsoe;
			} catch (Throwable var7) {
				FFDCFilter.processException(var7, "com.ibm.ejs.container.TimerImpl.getNextTimeout", "300", this);
				TimerServiceException tse = new TimerServiceException(this.toString(), var7);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "getNextTimeout: " + tse);
				}

				throw tse;
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getNextTimeout: " + nextTime);
			}

			return nextTime;
		}
	}

	public Serializable getInfo() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getInfo: " + this);
		}

		this.checkTimerAccess();
		Serializable userInfo = null;

		try {
			if (this.ivHandler == null || !this.isCachingAllowed(2) || this.ivIsHandlerInfoUsed) {
				TimerTaskInfoImpl taskInfo = (TimerTaskInfoImpl) this.ivScheduler.getTask(this.ivTaskId);
				this.ivHandler = taskInfo.getHandler();
			}

			if ((ContainerProperties.PI95982 || !this.ivIsExecutingEJBTimeout)
					&& (this.ivHome.beanMetaData.allowCachedTimerDataForMethods & 2) == 0) {
				userInfo = this.ivHandler.getInfo();
				this.ivIsHandlerInfoUsed = true;
			} else {
				userInfo = this.ivHome.container.ivObjectCopier.copy(this.ivHandler.getInfo());
			}
		} catch (TaskInvalid var5) {
			NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(this.toString(), var5);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getInfo: " + nsoe);
			}

			throw nsoe;
		} catch (Throwable var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.container.TimerImpl.getInfo", "363", this);
			TimerServiceException tse = new TimerServiceException(this.toString(), var6);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getInfo: " + tse);
			}

			throw tse;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getInfo: " + userInfo);
		}

		return userInfo;
	}

	public TimerHandle getHandle() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getHandle: " + this);
		}

		this.checkTimer(1);
		TimerHandleImpl timerHandle = new TimerHandleImpl(this.ivBeanId, this.ivTaskId, this.ivHashCode, false);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getHandle: " + timerHandle);
		}

		return timerHandle;
	}

	private ParsedScheduleExpression getParsedSchedule(int operation) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getParsedSchedule: " + this + ": " + operation);
		}

		this.checkTimerAccess();

		ParsedScheduleExpression parsedSchedule;
		try {
			TimerTaskHandler handler = this.getTaskHandler(operation);
			parsedSchedule = handler.getParsedSchedule();
		} catch (TaskInvalid var6) {
			NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(this.toString(), var6);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getScheduleImpl: " + nsoe);
			}

			throw nsoe;
		} catch (Throwable var7) {
			FFDCFilter.processException(var7, "com.ibm.ejs.container.TimerImpl.getParsedSchedule", "637", this);
			TimerServiceException tse = new TimerServiceException(this.toString(), var7);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getParsedSchedule: " + tse);
			}

			throw tse;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getParsedSchedule");
		}

		return parsedSchedule;
	}

	public ScheduleExpression getSchedule() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getSchedule: " + this);
		}

		ParsedScheduleExpression parsedSchedule = this.getParsedSchedule(16);
		if (parsedSchedule == null) {
			IllegalStateException ise = new IllegalStateException(
					"Timer is not a calendar-based timer: " + this.toString());
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getSchedule: " + ise);
			}

			throw ise;
		} else {
			ScheduleExpression schedule = this.ivHome.container.ivObjectCopier.copy(parsedSchedule.getSchedule());
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getSchedule: " + schedule);
			}

			return schedule;
		}
	}

	public boolean isPersistent() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isPersistent: " + this);
		}

		this.checkTimer(32);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isPersistent");
		}

		return true;
	}

	public boolean isCalendarTimer() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCalendarTimer: " + this);
		}

		boolean result = this.getParsedSchedule(64) != null;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isCalendarTimer: " + result);
		}

		return result;
	}

	public PassivatorSerializableHandle getSerializableObject() {
		TimerHandleImpl timerHandle = new TimerHandleImpl(this.ivBeanId, this.ivTaskId, this.ivHashCode, true);
		return timerHandle;
	}

	private static boolean isTimerBeanId(TimerTaskInfoImpl task, BeanId beanId) {
		return beanId.getJ2EEName().equals(task.getHandler().getJ2EEName())
				&& beanId.equals((BeanId) task.getTimedObjectId());
	}

	public static Collection<Timer> findTimersByBeanId(BeanId beanId) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "findTimersByBeanId: " + beanId);
		}

		ArrayList<Timer> timers = new ArrayList();
		String taskName = getTaskName(beanId);
		EJSHome home = (EJSHome) beanId.home;
		Scheduler scheduler = getScheduler(home);
		long numFound = 0L;
		Iterator tasks = null;

		try {
			tasks = scheduler.findTasksByName(taskName);
		} catch (Throwable var12) {
			FFDCFilter.processException(var12, "com.ibm.ejs.container.TimerImpl.findTimersByBeanId", "487");
			TimerServiceException tse = new TimerServiceException(beanId.toString(), var12);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "findTimersByBeanId: " + tse);
			}

			throw tse;
		}

		for (; tasks.hasNext(); ++numFound) {
			TimerTaskInfoImpl task = (TimerTaskInfoImpl) tasks.next();
			if (isTimerBeanId(task, beanId)) {
				BeanId timedObjectId = (BeanId) task.getTimedObjectId();
				TimerImpl timer = new TimerImpl(timedObjectId, task.getTaskId(), task.hashCode());
				timer.ivStatus = task;
				timer.ivHandler = task.getHandler();
				timers.add(timer);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "findTimersByBeanId: " + timers.size() + "(of " + numFound + " found)");
		}

		return timers;
	}

	public static void removeTimersByBeanId(BeanId beanId) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "removeTimersByBeanId: " + beanId);
		}

		String taskName = getTaskName(beanId);
		EJSHome home = (EJSHome) beanId.home;
		Scheduler scheduler = getScheduler(home);
		long numFound = 0L;
		long numRemoved = 0L;
		Iterator tasks = null;

		try {
			tasks = scheduler.findTasksByName(taskName);
		} catch (Throwable var13) {
			FFDCFilter.processException(var13, "com.ibm.ejs.container.TimerImpl.removeTimersByBeanId", "559");
			TimerServiceException tse = new TimerServiceException(beanId.toString(), var13);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "removeTimersByBeanId: " + tse);
			}

			throw tse;
		}

		for (; tasks.hasNext(); ++numFound) {
			TimerTaskInfoImpl task = (TimerTaskInfoImpl) tasks.next();
			if (isTimerBeanId(task, beanId)) {
				try {
					scheduler.cancel(task.getTaskId(), true);
					++numRemoved;
				} catch (TaskInvalid var14) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "TaskInvalid ignored : " + task.getTaskId());
					}
				} catch (Throwable var15) {
					FFDCFilter.processException(var15, "com.ibm.ejs.container.TimerImpl.removeTimersByBeanId", "601");
					TimerServiceException tse = new TimerServiceException(task.toString(), var15);
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "removeTimersByBeanId: " + tse);
					}

					throw tse;
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "removeTimersByBeanId: " + numRemoved + "(of " + numFound + " found)");
		}

	}

	private static String getTaskName(BeanId beanId) {
		J2EEName j2eeName = beanId.getJ2EEName();
		StringBuffer sb = new StringBuffer(j2eeName.getComponent());
		if (sb.length() > 240) {
			sb.setLength(240);
		}

		sb.append("_").append(beanId.hashCode());
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "taskName = " + sb);
		}

		return sb.toString();
	}

	private void checkTimer(int operation) {
		this.checkTimerAccess();

		try {
			this.getTaskStatus(operation);
		} catch (TaskInvalid var4) {
			NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(this.toString(), var4);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "checkTimer: " + nsoe);
			}

			throw nsoe;
		} catch (Throwable var5) {
			FFDCFilter.processException(var5, "com.ibm.ejs.container.TimerImpl.checkTimer", "980", this);
			TimerServiceException tse = new TimerServiceException(this.toString(), var5);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "checkTimer: " + tse);
			}

			throw tse;
		}
	}

	protected void checkTimerAccess() {
		BeanO beanO = EJSContainer.getCallbackBeanO();
		if (beanO != null) {
			beanO.checkTimerServiceAccess();
		} else {
			if (!EJSContainer.getDefaultContainer().allowTimerAccessOutsideBean) {
				IllegalStateException ise = new IllegalStateException(
						"Timer: Timer methods not allowed - no active EJB");
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkTimerAccess: " + ise);
				}

				throw ise;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerAccess: Timer access permitted outside of bean");
			}
		}

		if (this.ivTaskId == null) {
			NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(this.toString());
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerAccess: " + nsoe);
			}

			throw nsoe;
		}
	}

	public boolean equals(Object obj) {
		if (obj instanceof TimerImpl) {
			if (this.ivTaskId == null) {
				return this == obj;
			}

			TimerImpl timer = (TimerImpl) obj;
			if (this.ivHashCode == timer.ivHashCode && this.ivTaskId.equals(timer.ivTaskId)) {
				return true;
			}
		}

		return false;
	}

	public boolean equals(TimerImpl timer) {
		if (timer != null) {
			if (this.ivTaskId == null) {
				return this == timer;
			}

			if (this.ivHashCode == timer.ivHashCode && this.ivTaskId.equals(timer.ivTaskId)) {
				return true;
			}
		}

		return false;
	}

	public int hashCode() {
		return this.ivHashCode;
	}

	public String toString() {
		return "TimerImpl(" + this.ivTaskId + ", " + this.ivBeanId + ")";
	}

	public static Collection<Timer> findTimersByModule(Iterator<?> tasks, String moduleName) {
		HashSet timers = new HashSet();

		while (tasks.hasNext()) {
			Object next = tasks.next();
			if (next instanceof TimerTaskInfoImpl) {
				TimerTaskInfoImpl timerInfo = (TimerTaskInfoImpl) next;
				if (timerInfo.getModule().equals(moduleName)) {
					timers.add(new TimerImpl((BeanId) timerInfo.getTimedObjectId(), timerInfo.getTaskId(),
							timerInfo.getHandler().hashCode()));
				}
			}
		}

		return timers;
	}
}