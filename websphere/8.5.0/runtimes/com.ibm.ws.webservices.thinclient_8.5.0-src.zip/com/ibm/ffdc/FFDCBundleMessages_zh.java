package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_zh extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"FFDCAddedFormatter", "FFDC1005I: FFDC 格式化程序添加的 {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: 分析引擎正在使用数据库：{0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: 无法解析分析引擎："},
			{"FFDCDataCollectorAdded", "FFDC1011I: FFDC 数据收集器添加的 {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: FFDC 数据收集器除去的 {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: 在 SystemErr 上释放的 FFDC 事件：{0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC 处于故障保护模式，请检查错误 {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: FFDC 事件转发器添加的 {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: FFDC 事件转发器除去的 {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: 已在 {0} {1} {2} 发出 FFDC 事件。"},
			{"FFDCProviderAborted", "FFDC1000I:  FFDC 提供程序 {0} 中止，后跟异常"},
			{"FFDCProviderAbortedE", "FFDC1001I: FFDC 提供程序中止，异常为 {0}"},
			{"FFDCProviderException", "FFDC1008I: FFDC 提供程序异常："},
			{"FFDCProviderInstalled", "FFDC1007I: FFDC 提供程序安装：{0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: FFDC 格式化程序除去的 {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}