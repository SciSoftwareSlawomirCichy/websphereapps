package com.ibm.icu.impl;

import com.ibm.icu.impl.LocaleDisplayNamesImpl.ICUDataTables;

public class ICULangDataTables extends ICUDataTables {
	public ICULangDataTables() {
		super("com/ibm/icu/impl/data/icudt44b/lang");
	}
}