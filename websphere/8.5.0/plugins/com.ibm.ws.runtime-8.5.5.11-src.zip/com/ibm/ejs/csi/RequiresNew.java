package com.ibm.ejs.csi;

import com.ibm.ejs.container.ContainerProperties;
import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.ffdc.FFDCFilter;
import javax.transaction.Transaction;

final class RequiresNew extends TranStrategy {
	private static final TraceComponent tc = Tr.register(RequiresNew.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	RequiresNew(TransactionControlImpl txCtrl) {
		super(txCtrl);
	}

	TxCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		Transaction suspended = null;
		LocalTransactionCoordinator savedLocalTx = null;
		if (this.globalTxExists(false)) {
			suspended = this.suspendGlobalTx(2);
			if (ContainerProperties.PI10351) {
				savedLocalTx = this.ltcCurrent.getLocalTranCoord();
				this.suspendLocalTx(savedLocalTx);
			}
		} else {
			savedLocalTx = this.ltcCurrent.getLocalTranCoord();
			this.suspendLocalTx(savedLocalTx);
		}

		try {
			this.beginGlobalTx(key, methodInfo);
		} catch (CSIException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.csi.RequiresNew.preInvoke", "85", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Begin of global tx failed", var9);
			}

			try {
				if (suspended != null) {
					this.resumeGlobalTx(suspended, 2);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Resumed suspended global tran after start of new global tran failed");
					}
				} else if (savedLocalTx != null) {
					this.resumeLocalTx(savedLocalTx);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Resumed suspended local tran after start of new global tran failed");
					}
				}
			} catch (Throwable var8) {
				FFDCFilter.processException(var8, "com.ibm.ejs.csi.RequiresNew.preInvoke", "95", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Saved local/global tx resume failed", var8);
				}
			}

			throw var9;
		}

		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		TxCookieImpl cookie = new TxCookieImpl(true, false, this, suspended);
		cookie.suspendedLocalTx = savedLocalTx;
		return cookie;
	}

	void postInvoke(EJBKey key, TxCookieImpl txCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		super.postInvoke(key, txCookie, methodInfo);
		if (entryEnabled) {
			Tr.exit(tc, "postInvoke");
		}

	}
}