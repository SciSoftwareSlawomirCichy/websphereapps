package com.ibm.ISecurityUtilityImpl;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.ws.bootstrap.ExtClassLoader;
import com.ibm.wsspi.security.crypto.CustomPasswordEncryption;
import com.ibm.wsspi.security.crypto.EncryptedInfo;
import com.ibm.wsspi.security.crypto.PasswordDecryptException;
import com.ibm.wsspi.security.crypto.PasswordEncryptException;
import java.io.UnsupportedEncodingException;
import java.util.StringTokenizer;

public class PasswordCipherUtil {
	private static final byte XOR_MASK = 95;
	private static final TraceComponent tc = Tr.register(PasswordCipherUtil.class, "SASRas",
			"com.ibm.ejs.resources.security");
	private static String[] _supported_crypto_algorithms = null;
	private static final String DEFAULT_CRYPTO_ALGORITHM_PROPERTY = "os400.security.password.encoding.algorithm";
	private static final String VALIDATION_LIST_PROPERTY = "os400.security.password.validation.list.object";
	private static final String[] DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS = new String[]{"xor", "os400", "custom"};
	private static final String DEFAULT_CUSTOM_CRYPTO_CLASS = "com.ibm.wsspi.security.crypto.CustomPasswordEncryptionImpl";
	private static final String CUSTOM_CRYPTO_CLASS_PROPERTY = "com.ibm.wsspi.security.crypto.customPasswordEncryptionClass";
	private static final String CUSTOM_CRYPTO_ENABLE_PROPERTY = "com.ibm.wsspi.security.crypto.customPasswordEncryptionEnabled";
	private static final int XOR_INDEX = 0;
	private static final int OS400_INDEX = 1;
	private static final int CUSTOM_INDEX = 2;
	private static final int ADVANCED_EDITION = 0;
	private static final int ADVANCED_EDITION_SINGLE_SERVER = 1;
	private static String[] _validation_list_objects = null;
	private static CustomPasswordEncryption customPasswordEncryptionClass = null;
	private static boolean _standalone = false;
	private static int _edition = 0;
	private static boolean _debug = false;
	private static String custom_crypto_class = null;
	private static boolean custom_crypto_enabled = false;
	private static final Class thisClass = PasswordCipherUtil.class;
	private static boolean initialized = false;
	static String osName;

	public static byte[] decipher(byte[] encrypted_bytes, String crypto_algorithm)
			throws InvalidPasswordCipherException, UnsupportedCryptoAlgorithmException {
		if (crypto_algorithm == null) {
			throw new UnsupportedCryptoAlgorithmException();
		} else {
			byte[] decrypted_bytes = null;
			if (crypto_algorithm.equalsIgnoreCase(DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[0])) {
				decrypted_bytes = xor(encrypted_bytes);
			} else {
				String keyAlias;
				if (crypto_algorithm.startsWith(DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[2])) {
					try {
						if (customPasswordEncryptionClass != null) {
							int index = crypto_algorithm.indexOf(":");
							keyAlias = null;
							if (index != -1) {
								keyAlias = crypto_algorithm.substring(index + 1);
							}

							decrypted_bytes = customPasswordEncryptionClass
									.decrypt(new EncryptedInfo(encrypted_bytes, keyAlias));
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Successfully decrypted password using custom encryption plug point.");
							}
						}
					} catch (PasswordDecryptException var6) {
						Manager.Ffdc.log(var6, thisClass, "com.ibm.ISecurityUtilityImpl.PasswordCipherUtil.decipher",
								"291");
						Tr.error(tc, "PasswordDecryptException during custom decryption: " + var6.getMessage());
						throw new InvalidPasswordCipherException();
					} catch (Exception var7) {
						Manager.Ffdc.log(var7, thisClass, "com.ibm.ISecurityUtilityImpl.PasswordCipherUtil.decipher",
								"297");
						Tr.error(tc, "Exception during custom decryption: " + var7.getMessage());
						PasswordUtil.debugMessage(var7);
						throw new InvalidPasswordCipherException();
					}
				} else {
					if (osName.compareTo("OS/400") != 0
							|| !crypto_algorithm.equalsIgnoreCase(DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[1])) {
						throw new UnsupportedCryptoAlgorithmException();
					}

					try {
						keyAlias = new String(encrypted_bytes, "UTF8");
						String result = ntv_os400Decipher(keyAlias, _validation_list_objects, _edition, _standalone,
								_debug);
						if (result == null) {
							throw new InvalidPasswordCipherException();
						}

						decrypted_bytes = result.getBytes("UTF8");
					} catch (UnsupportedEncodingException var5) {
						throw new InvalidPasswordCipherException();
					}
				}
			}

			if (decrypted_bytes == null) {
				throw new InvalidPasswordCipherException();
			} else {
				return decrypted_bytes;
			}
		}
	}

	public static byte[] encipher(byte[] decrypted_bytes, String crypto_algorithm)
			throws InvalidPasswordCipherException, UnsupportedCryptoAlgorithmException {
		try {
			EncryptedInfo info = encipher_internal(decrypted_bytes, crypto_algorithm);
			return info.getEncryptedBytes();
		} catch (PasswordEncryptException var3) {
			throw new InvalidPasswordCipherException();
		}
	}

	protected static EncryptedInfo encipher_internal(byte[] decrypted_bytes, String crypto_algorithm)
			throws InvalidPasswordCipherException, UnsupportedCryptoAlgorithmException, PasswordEncryptException {
		PasswordUtil.debugMessage(
				"enciper_internal: crypto_algorithm:" + crypto_algorithm + "decrypted_bytes:" + decrypted_bytes);
		if (crypto_algorithm == null) {
			throw new UnsupportedCryptoAlgorithmException();
		} else {
			EncryptedInfo info = null;
			byte[] encrypted_bytes = null;
			byte[] encrypted_bytes;
			if (crypto_algorithm.equalsIgnoreCase(DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[0])) {
				PasswordUtil.debugMessage("XOR default algorithm.");
				encrypted_bytes = xor(decrypted_bytes);
				if (encrypted_bytes != null) {
					info = new EncryptedInfo(encrypted_bytes, "");
				}
			} else if (crypto_algorithm.startsWith(DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[2])) {
				PasswordUtil.debugMessage("custom algorithm.");

				try {
					if (customPasswordEncryptionClass != null) {
						PasswordUtil.debugMessage("customPasswordEncryptionClass is found: "
								+ customPasswordEncryptionClass + " Calling encrypt");
						info = customPasswordEncryptionClass.encrypt(decrypted_bytes);
						PasswordUtil.debugMessage("Successfully encrypted password using custom encryption plug point");
					} else {
						PasswordUtil
								.debugMessage("customPasswordEncryptionClass is null. Falling back on XOR encoding");
						encrypted_bytes = xor(decrypted_bytes);
						if (encrypted_bytes != null) {
							info = new EncryptedInfo(encrypted_bytes, "");
						}
					}
				} catch (PasswordEncryptException var7) {
					Manager.Ffdc.log(var7, thisClass, "com.ibm.ISecurityUtilityImpl.PasswordCipherUtil.encipher",
							"402");
					Tr.error(tc, "PasswordEncryptException during custom encryption: " + var7.getMessage());
					return new EncryptedInfo(xor(decrypted_bytes), "");
				} catch (Exception var8) {
					Manager.Ffdc.log(var8, thisClass, "com.ibm.ISecurityUtilityImpl.PasswordCipherUtil.encipher",
							"408");
					Tr.error(tc,
							"Received a password encrypted with a custom algorithm that is not currently configured. Exception is: "
									+ var8.toString() + " e.getMessage():" + var8.getMessage());
					PasswordUtil.debugMessage(var8);
					return new EncryptedInfo(xor(decrypted_bytes), "");
				}
			} else {
				if (osName.compareTo("OS/400") != 0
						|| !crypto_algorithm.equalsIgnoreCase(DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[1])) {
					PasswordUtil.debugMessage("Algorithm is not XOR, custom nor OS/400 ");
					throw new UnsupportedCryptoAlgorithmException();
				}

				PasswordUtil.debugMessage("OS/400 algorithm.");

				try {
					String result = ntv_os400Encipher(new String(decrypted_bytes, "UTF8"), _validation_list_objects,
							_edition, _standalone, _debug);
					if (result == null) {
						throw new InvalidPasswordCipherException();
					}

					encrypted_bytes = result.getBytes("UTF8");
					if (encrypted_bytes != null) {
						info = new EncryptedInfo(encrypted_bytes, "");
					}
				} catch (UnsupportedEncodingException var6) {
					throw new InvalidPasswordCipherException();
				}
			}

			if (info == null) {
				PasswordUtil.debugMessage("Info is null");
				throw new InvalidPasswordCipherException();
			} else {
				PasswordUtil.debugMessage("Returning info: keyAlias= " + info.getKeyAlias() + "encryptedBytes="
						+ info.getEncryptedBytes());
				return info;
			}
		}
	}

	public static String[] getSupportedCryptoAlgorithms() {
		return _supported_crypto_algorithms;
	}

	public static String getFailSafeCryptoAlgorithm() {
		return DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[0];
	}

	public static void updateValidationList() {
		Tr.entry(tc, "updateValidationList");
		if (osName.compareTo("OS/400") == 0) {
			String validation_list_names = System.getProperty("os400.security.password.validation.list.object",
					(String) null);

			try {
				int number_of_names = 0;
				int n;
				if (validation_list_names != null && validation_list_names.length() != 0) {
					validation_list_names = validation_list_names.toUpperCase();
					if (validation_list_names.indexOf(58) == -1) {
						++number_of_names;
					} else {
						for (int m = 0; m < validation_list_names.length()
								&& (n = validation_list_names.indexOf(58, m)) > -1; m = n + 1) {
							++number_of_names;
						}

						++number_of_names;
					}
				}

				_validation_list_objects = new String[number_of_names];
				StringTokenizer st = new StringTokenizer(validation_list_names, ":");

				for (n = 0; st.hasMoreTokens(); ++n) {
					_validation_list_objects[n] = st.nextToken();
				}
			} catch (Exception var4) {
				_validation_list_objects = null;
			}
		}

		Tr.exit(tc, "updateValidationList");
	}

	public static boolean isInitializedWithoutError() {
		return initialized;
	}

	private static byte[] xor(byte[] bytes) {
		byte[] xor_bytes = null;
		if (bytes != null) {
			xor_bytes = new byte[bytes.length];

			for (int i = 0; i < bytes.length; ++i) {
				xor_bytes[i] = (byte) (95 ^ bytes[i]);
			}
		}

		return xor_bytes;
	}

	private static void initializeCustomPasswordEncryption() {
		if (customPasswordEncryptionClass == null) {
			try {
				String custom_crypto_enabled_string = System
						.getProperty("com.ibm.wsspi.security.crypto.customPasswordEncryptionEnabled");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "com.ibm.wsspi.security.crypto.customPasswordEncryptionEnabled = "
							+ custom_crypto_enabled_string);
				}

				if (custom_crypto_enabled_string != null
						&& (custom_crypto_enabled_string == null || !custom_crypto_enabled_string.equalsIgnoreCase("no")
								&& !custom_crypto_enabled_string.equalsIgnoreCase("false"))) {
					if (custom_crypto_enabled_string != null && (custom_crypto_enabled_string.equalsIgnoreCase("yes")
							|| custom_crypto_enabled_string.equalsIgnoreCase("true"))) {
						custom_crypto_enabled = true;
					}
				} else {
					custom_crypto_enabled = false;
					initialized = true;
				}

				custom_crypto_class = System.getProperty("com.ibm.wsspi.security.crypto.customPasswordEncryptionClass");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc,
							"com.ibm.wsspi.security.crypto.customPasswordEncryptionClass = " + custom_crypto_class);
				}

				if (custom_crypto_class == null) {
					custom_crypto_class = "com.ibm.wsspi.security.crypto.CustomPasswordEncryptionImpl";
				}

				if (custom_crypto_class != null) {
					try {
						Class c = null;

						try {
							ClassLoader ccl = ExtClassLoader.getInstance();
							if (ccl == null) {
								ccl = PasswordCipherUtil.class.getClassLoader();
							}

							c = Class.forName(custom_crypto_class, true, (ClassLoader) ccl);
						} catch (Exception var3) {
							;
						}

						if (c == null) {
							c = Class.forName(custom_crypto_class);
						}

						customPasswordEncryptionClass = (CustomPasswordEncryption) c.newInstance();
						if (customPasswordEncryptionClass != null && custom_crypto_enabled_string == null
								&& custom_crypto_class
										.equals("com.ibm.wsspi.security.crypto.CustomPasswordEncryptionImpl")) {
							custom_crypto_enabled = true;
						}

						initialized = true;
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Successfully loaded the custom encryption class: " + custom_crypto_class);
						}
					} catch (Exception var4) {
						if (!"com.ibm.wsspi.security.crypto.CustomPasswordEncryptionImpl".equals(custom_crypto_class)) {
							Manager.Ffdc.log(var4, thisClass,
									"com.ibm.ISecurityUtilityImpl.PasswordCipherUtil.initializeCustomPasswordEncryption",
									"638");
							initialized = false;
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "An exception is caught while loading a custom encryption class.");
							}
						} else {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc,
										"An exception is caught while loading a default custom encryption class. This is normal unless a custom encryption class has been placed. : "
												+ var4);
							}

							initialized = true;
						}

						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Could not load the custom encryption class: " + custom_crypto_class);
						}

						custom_crypto_enabled = false;
					}
				}
			} catch (Exception var5) {
				Manager.Ffdc.log(var5, thisClass, "com.ibm.ISecurityUtilityImpl.PasswordCipherUtil", "656");
				Tr.error(tc, "Could not load class: " + custom_crypto_class);
				custom_crypto_enabled = false;
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Custom encryption enabled = " + custom_crypto_enabled);
		}

	}

	private static native String ntv_os400Encipher(String var0, String[] var1, int var2, boolean var3, boolean var4);

	private static native String ntv_os400Decipher(String var0, String[] var1, int var2, boolean var3, boolean var4);

	private static native void ntv_os400ReportBadDefaultCryptoAlgorithm(int var0, boolean var1, boolean var2);

	static {
		initializeCustomPasswordEncryption();
		osName = System.getProperty("os.name");
		String validation_list_names;
		if (osName.compareTo("OS/400") == 0) {
			validation_list_names = System.getProperty("was.install.library");

			try {
				Tr.debug(tc, "Loading native library: /QSYS.LIB/" + validation_list_names + ".LIB/QWASPMGT.SRVPGM");
				System.load("/QSYS.LIB/" + validation_list_names + ".LIB/QWASPMGT.SRVPGM");
				String standaloneProperty = System.getProperty("was.standalone", "false");
				if (standaloneProperty.equalsIgnoreCase("true")) {
					_standalone = true;
				}

				String debugProperty = System.getProperty("os400.security.password.debug", "false");
				if (debugProperty.equalsIgnoreCase("true")) {
					_debug = true;
				}

				String default_crypto_algorithm = System.getProperty("os400.security.password.encoding.algorithm",
						DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[0]);
				if (custom_crypto_enabled && customPasswordEncryptionClass != null) {
					default_crypto_algorithm = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[2];
				}

				int number_of_crypto_algorithms = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS.length;
				boolean matched = false;
				default_crypto_algorithm = default_crypto_algorithm.trim();

				label104 : for (int i = 0; i < number_of_crypto_algorithms; ++i) {
					if (default_crypto_algorithm.equalsIgnoreCase(DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[i])) {
						matched = true;
						_supported_crypto_algorithms = new String[number_of_crypto_algorithms];
						_supported_crypto_algorithms[0] = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[i];
						int j = 1;
						int k = 0;

						while (true) {
							if (k >= number_of_crypto_algorithms) {
								break label104;
							}

							if (k != i) {
								_supported_crypto_algorithms[j++] = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[k];
							}

							++k;
						}
					}
				}

				if (!matched) {
					ntv_os400ReportBadDefaultCryptoAlgorithm(_edition, _standalone, _debug);
				}
			} catch (Throwable var10) {
				_supported_crypto_algorithms = null;
			}

			if (_supported_crypto_algorithms == null) {
				_supported_crypto_algorithms = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS;
			}
		} else if (_supported_crypto_algorithms == null) {
			if (custom_crypto_enabled && customPasswordEncryptionClass != null) {
				_supported_crypto_algorithms = new String[2];
				_supported_crypto_algorithms[0] = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[2];
				_supported_crypto_algorithms[1] = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[0];
			} else if (customPasswordEncryptionClass != null) {
				_supported_crypto_algorithms = new String[2];
				_supported_crypto_algorithms[0] = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[0];
				_supported_crypto_algorithms[1] = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[2];
			} else {
				_supported_crypto_algorithms = new String[1];
				_supported_crypto_algorithms[0] = DEFAULT_SUPPORTED_CRYPTO_ALGORITHMS[0];
			}
		}

		if (osName.compareTo("OS/400") == 0) {
			validation_list_names = System.getProperty("os400.security.password.validation.list.object", (String) null);

			try {
				int number_of_names = 0;
				int n;
				if (validation_list_names != null && validation_list_names.length() != 0) {
					validation_list_names = validation_list_names.toUpperCase();
					if (validation_list_names.indexOf(58) == -1) {
						++number_of_names;
					} else {
						for (int m = 0; m < validation_list_names.length()
								&& (n = validation_list_names.indexOf(58, m)) > -1; m = n + 1) {
							++number_of_names;
						}

						++number_of_names;
					}
				}

				_validation_list_objects = new String[number_of_names];
				StringTokenizer st = new StringTokenizer(validation_list_names, ":");

				for (n = 0; st.hasMoreTokens(); ++n) {
					_validation_list_objects[n] = st.nextToken();
				}
			} catch (Exception var9) {
				_validation_list_objects = null;
			}
		}

	}
}