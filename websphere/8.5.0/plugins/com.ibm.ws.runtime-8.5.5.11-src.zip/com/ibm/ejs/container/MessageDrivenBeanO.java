package com.ibm.ejs.container;

import com.ibm.ejs.container.interceptors.InterceptorMetaData;
import com.ibm.ejs.container.interceptors.InterceptorProxy;
import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ejbcontainer.MessageDrivenContextExtension;
import com.ibm.ws.ejbcontainer.CallbackKind;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import com.ibm.wsspi.injectionengine.InjectionEngine;
import com.ibm.wsspi.injectionengine.InjectionTarget;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.security.Principal;
import java.util.Map;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.EJBLocalHome;
import javax.ejb.EnterpriseBean;
import javax.ejb.MessageDrivenBean;
import javax.ejb.RemoveException;
import javax.ejb.TimerService;
import javax.transaction.UserTransaction;

public class MessageDrivenBeanO extends ManagedBeanOBase
		implements
			MessageDrivenContextExtension,
			UserTransactionEnabledContext,
			Serializable {
	private static final long serialVersionUID = -7199444167428525287L;
	private static final TraceComponent tc = Tr.register(MessageDrivenBeanO.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.MessageDrivenBeanO";
	public MessageDrivenBean messageDrivenBean;
	protected boolean reentrant = false;
	protected boolean discarded = false;
	protected int currentIsolationLevel = -1;
	protected boolean allowRollbackOnly = false;
	CallbackKind ivCallbackKind;
	public static final int DESTROYED = 0;
	public static final int POOLED = 1;
	public static final int IN_METHOD = 2;
	public static final int PRE_CREATE = 3;
	public static final int CREATING = 4;
	protected static final String[] StateStrs = new String[]{"DESTROYED", "POOLED", "IN_METHOD", "PRE_CREATE",
			"CREATING"};

	public MessageDrivenBeanO(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		super(c, mo, b, h);
		if (b instanceof MessageDrivenBean) {
			this.messageDrivenBean = (MessageDrivenBean) b;
		}

	}

	protected void initialize() throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "initialize");
		}

		this.stateStrs = StateStrs;
		BeanMetaData bmd = this.home.beanMetaData;
		this.ivCallbackKind = bmd.ivCallbackKind;
		this.state = 3;
		UnspecifiedContextHelper contextHelper = new UnspecifiedContextHelper(this);

		try {
			this.allowRollbackOnly = false;
			if (this.home != null) {
				this.setId(this.home.ivStatelessId);
			}

			contextHelper.begin(true);
			InterceptorMetaData imd = bmd.ivInterceptorMetaData;
			if (imd != null) {
				this.createInterceptors(imd);
			}

			if (this.messageDrivenBean != null) {
				this.messageDrivenBean.setMessageDrivenContext(this);
			}

			if (bmd.ivBeanInjectionTargets != null) {
				try {
					InjectionEngine injectionEngine = this.getInjectionEngine();
					InjectionTarget[] targets = bmd.ivBeanInjectionTargets;
					if (targets != null) {
						InjectionTarget[] arr$ = targets;
						int len$ = targets.length;

						for (int i$ = 0; i$ < len$; ++i$) {
							InjectionTarget injectionTarget = arr$[i$];
							injectionEngine.inject(this.ivEjbInstance, injectionTarget, this);
						}
					}
				} catch (Throwable var40) {
					FFDCFilter.processException(var40, "com.ibm.ejs.container.MessageDrivenBeanO.<init>", "216", this);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Injection failure", var40);
					}

					throw ExceptionUtil.EJBException("Injection failure", var40);
				}
			}

			this.setState(4);
			if (this.ivCallbackKind == CallbackKind.MessageDrivenBean) {
				Method m = bmd.ivEjbCreateMethod;
				if (m != null) {
					try {
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallEntry("ejbCreate");
						}

						m.invoke(this.ivEjbInstance);
					} catch (InvocationTargetException var35) {
						Throwable targetEx = var35.getCause();
						if (targetEx == null) {
							targetEx = var35;
						}

						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "MDB ejbCreate failure", targetEx);
						}

						throw new CreateFailureException((Throwable) targetEx);
					} catch (Throwable var36) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "MDB ejbCreate failure", var36);
						}

						throw new CreateFailureException(var36);
					} finally {
						if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
							TEBeanLifeCycleInfo.traceEJBCallExit("ejbCreate");
						}

					}
				}
			} else if (this.ivCallbackKind == CallbackKind.InvocationContext) {
				try {
					if (imd != null) {
						InterceptorProxy[] proxies = imd.ivPostConstructInterceptors;
						if (proxies != null) {
							if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
								TEBeanLifeCycleInfo.traceEJBCallEntry("PostConstruct");
							}

							InvocationContextImpl inv = new InvocationContextImpl();
							inv.initialize(this.ivEjbInstance, this.ivInterceptors);
							inv.doLifeCycle(proxies, bmd._moduleMetaData);
						}
					}
				} catch (Throwable var38) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "MDB PostConstruct failure", var38);
					}

					throw ExceptionUtil.EJBException("MDB PostConstruct failure", var38);
				} finally {
					if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled() && imd != null
							&& imd.ivPostConstructInterceptors != null) {
						TEBeanLifeCycleInfo.traceEJBCallExit("PostConstruct");
					}

				}
			}

			this.allowRollbackOnly = true;
			this.setState(1);
		} finally {
			contextHelper.complete(true);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "initialize");
		}

	}

	public final void postCreate(boolean supportEJBPostCreateChanges) throws CreateException, RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "postCreate : NotImplementedException");
		}

		throw new NotImplementedException();
	}

	public boolean isRemoved() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isRemoved : false");
		}

		return false;
	}

	public void discard() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "discard");
		}

		this.discarded = true;
		if (this.state != 0) {
			this.setState(0);
			this.destroyHandleList();
			this.releaseManagedObjectState();
			if (this.pmiBean != null) {
				this.pmiBean.discardCount();
				this.pmiBean.beanDestroyed();
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "discard");
			}

		}
	}

	public boolean isDiscarded() {
		return this.discarded;
	}

	public final void invalidate() {
	}

	public final void activate(BeanId id, ContainerTx tx) throws RemoteException {
	}

	public final boolean enlist(ContainerTx tx) throws RemoteException {
		this.ivContainerTx = tx;
		return false;
	}

	public final Object preInvoke(EJSDeployedSupport s, ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "preInvoke");
		}

		this.setState(1, 2);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "preInvoke");
		}

		return this.ivEjbInstance;
	}

	public final void postInvoke(int id, EJSDeployedSupport s) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "postInvoke: " + this);
		}

		if (this.state != 0) {
			if (this.ivContainerTx != null && this.ivContainerTx.isBmtActive(s.methodInfo)) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "MDB method is not allowed to leave a BMT active.  Discarding bean.");
				}

				this.discard();
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "postInvoke");
			}

		}
	}

	public void returnToPool() throws RemoteException {
		if (this.isDestroyed()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "returnToPool: skipped: " + this);
			}
		} else {
			this.setState(2, 1);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "returnToPool: " + this);
			}

			this.beanPool.put(this);
		}

	}

	public final void commit(ContainerTx tx) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "commit");
		}

		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Msg Bean commit not allowed");
	}

	public final void rollback(ContainerTx tx) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "rollback");
		}

		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Msg Bean rollback not allowed");
	}

	public final void store() throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "store");
		}

		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Msg Bean store not allowed");
	}

	public final void passivate() throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "passivate");
		}

		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Msg Bean passivate not allowed");
	}

	public final void remove() throws RemoteException, RemoveException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "remove");
		}

		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Msg Bean remove not allowed");
	}

	public final void beforeCompletion() throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "beforeCompletion");
		}

		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Msg Bean beforeCompletion not allowed");
	}

	public int getIsolationLevel() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getIsolationLevel : " + this.currentIsolationLevel);
		}

		return this.currentIsolationLevel;
	}

	public boolean isDestroyed() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isDestroyed");
		}

		if (this.state == 0) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "isDestroyed");
			}

			return true;
		} else {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "isDestroyed");
			}

			return false;
		}
	}

	public final synchronized void destroy() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy");
		}

		if (this.state != 0) {
			long removeStartTime = -1L;
			if (this.pmiBean != null) {
				removeStartTime = this.pmiBean.initalTime(15);
			}

			this.allowRollbackOnly = false;
			String traceString = null;
			UnspecifiedContextHelper contextHelper = new UnspecifiedContextHelper(this);
			BeanMetaData bmd = this.home.beanMetaData;
			ComponentMetaDataAccessorImpl cmdAccessor = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor();

			try {
				cmdAccessor.beginContext(bmd);
				contextHelper.begin(this.ivCallbackKind != CallbackKind.None);
				if (this.ivCallbackKind == CallbackKind.MessageDrivenBean) {
					if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
						traceString = "ejbRemove";
						TEBeanLifeCycleInfo.traceEJBCallEntry(traceString);
					}

					this.messageDrivenBean.ejbRemove();
				} else if (this.ivCallbackKind == CallbackKind.InvocationContext) {
					if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
						traceString = "PreDestroy";
						TEBeanLifeCycleInfo.traceEJBCallEntry(traceString);
					}

					InterceptorMetaData imd = bmd.ivInterceptorMetaData;
					InterceptorProxy[] proxies = imd.ivPreDestroyInterceptors;
					if (proxies != null) {
						InvocationContextImpl inv = new InvocationContextImpl();
						inv.initialize(this.ivEjbInstance, this.ivInterceptors);
						inv.doLifeCycle(proxies, bmd._moduleMetaData);
					}
				}
			} catch (Throwable var19) {
				FFDCFilter.processException(var19, "com.ibm.ejs.container.MessageDrivenBeanO.destroy", "376", this);
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, traceString + " threw and exception:", new Object[]{this, var19});
				}
			} finally {
				cmdAccessor.endContext();

				try {
					contextHelper.complete(true);
				} catch (Throwable var18) {
					FFDCFilter.processException(var18, "com.ibm.ejs.container.MessageDrivenBeanO.destroy", "848", this);
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "destroy caught exception: ", new Object[]{this, var18});
					}
				}

				if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled() && traceString != null) {
					TEBeanLifeCycleInfo.traceEJBCallExit(traceString);
				}

			}

			this.setState(0);
			this.destroyHandleList();
			this.releaseManagedObjectState();
			if (this.pmiBean != null) {
				this.pmiBean.beanDestroyed();
				this.pmiBean.finalTime(15, removeStartTime);
			}

			this.allowRollbackOnly = true;
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "destroy");
			}

		}
	}

	public void checkTimerServiceAccess() throws IllegalStateException {
		if (this.state != 2) {
			IllegalStateException ise = new IllegalStateException(
					"MessageDrivenBean: Timer Service  methods not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerServiceAccess: " + ise);
			}

			throw ise;
		}
	}

	public synchronized UserTransaction getUserTransaction() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getUserTransaction");
		}

		if (this.state == 3) {
			IllegalStateException ise = new IllegalStateException(
					"MessageDrivenBean: getUserTransaction not allowed from state = " + this.stateStrs[this.state]);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.exit(tc, "getUserTransaction", ise);
			}

			throw ise;
		} else {
			UserTransaction userTransactionWrapper = UserTransactionWrapper.INSTANCE;
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getUserTransaction", userTransactionWrapper);
			}

			return userTransactionWrapper;
		}
	}

	public void setRollbackOnly() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "setRollbackOnly");
		}

		synchronized (this) {
			if (!this.allowRollbackOnly) {
				throw new IllegalStateException();
			}
		}

		super.setRollbackOnly();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "setRollbackOnly");
		}

	}

	public boolean getRollbackOnly() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getRollbackOnly");
		}

		synchronized (this) {
			if (!this.allowRollbackOnly) {
				throw new IllegalStateException();
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getRollbackOnly");
		}

		return super.getRollbackOnly();
	}

	public Object getBeanInstance() {
		return this.ivEjbInstance;
	}

	public final EnterpriseBean getEnterpriseBean() throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getEnterpriseBean");
		}

		throw new NotImplementedException();
	}

	public Object[] getInterceptors() {
		return this.ivInterceptors;
	}

	public Principal getCallerPrincipal() {
		if (this.state == 3) {
			IllegalStateException ise = new IllegalStateException(
					"MessageDrivenBean: getCallerPrincipal not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getCallerPrincipal: " + ise);
			}

			throw ise;
		} else {
			return super.getCallerPrincipal();
		}
	}

	public boolean isCallerInRole(String roleName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCallerInRole, role = " + roleName + ", state = " + StateStrs[this.state]);
		}

		Object bean = null;
		synchronized (this) {
			if (this.state == 3 || this.state == 4 || !this.allowRollbackOnly) {
				throw new IllegalStateException();
			}

			if (this.state == 2) {
				bean = this.ivEjbInstance;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isCallerInRole");
		}

		return super.isCallerInRole(roleName, bean);
	}

	public EJBHome getEJBHome() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getEJBHome");
		}

		Tr.error(tc, "METHOD_NOT_ALLOWED_CNTR0047E", "MessageDrivenBeanO.getEJBHome()");
		throw new IllegalStateException(
				"Method Not Allowed Exception: See Message-drive Bean Component Contract section of the applicable EJB Specification.");
	}

	public EJBLocalHome getEJBLocalHome() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getEJBLocalHome");
		}

		Tr.error(tc, "METHOD_NOT_ALLOWED_CNTR0047E", "MessageDrivenBeanO.getEJBLocalHome()");
		throw new IllegalStateException(
				"Method Not Allowed Exception: See Message-drive Bean Component Contract section of the applicable EJB Specification.");
	}

	public TimerService getTimerService() throws IllegalStateException {
		if (this.state == 3) {
			IllegalStateException ise = new IllegalStateException(
					"MessageDrivenBean: getTimerService not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getTimerService: " + ise);
			}

			throw ise;
		} else {
			return super.getTimerService();
		}
	}

	public Map<String, Object> getContextData() {
		if (this.state != 3 && this.state != 0) {
			return super.getContextData();
		} else {
			IllegalStateException ise = new IllegalStateException(
					"MessageDrivenBean: getContextData not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getContextData: " + ise);
			}

			throw ise;
		}
	}

	public void flushCache() {
		if (this.state == 3) {
			IllegalStateException ise = new IllegalStateException(
					"MessageDrivenBean: flushCache not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "flushCache: " + ise);
			}

			throw ise;
		} else {
			super.flushCache();
		}
	}

	public void ensurePersistentState(ContainerTx tx) throws RemoteException {
	}

	public int getModuleVersion() {
		return this.home.beanMetaData.ivModuleVersion;
	}

	public final String toString() {
		return "MessageDrivenBeanO(" + this.beanId + ", state = " + StateStrs[this.state] + ")";
	}
}