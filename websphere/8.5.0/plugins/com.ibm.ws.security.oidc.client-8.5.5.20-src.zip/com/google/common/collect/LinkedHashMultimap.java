package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Objects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(serializable = true, emulated = true)
public final class LinkedHashMultimap<K, V> extends LinkedHashMultimapGwtSerializationDependencies<K, V> {
	private static final int DEFAULT_KEY_CAPACITY = 16;
	private static final int DEFAULT_VALUE_SET_CAPACITY = 2;
	@VisibleForTesting
	static final double VALUE_SET_LOAD_FACTOR = 1.0;
	@VisibleForTesting
	transient int valueSetCapacity = 2;
	private transient ValueEntry<K, V> multimapHeaderEntry;
	@GwtIncompatible
	private static final long serialVersionUID = 1L;

	public static <K, V> LinkedHashMultimap<K, V> create() {
		return new LinkedHashMultimap(16, 2);
	}

	public static <K, V> LinkedHashMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey) {
		return new LinkedHashMultimap(Maps.capacity(expectedKeys), Maps.capacity(expectedValuesPerKey));
	}

	public static <K, V> LinkedHashMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap) {
		LinkedHashMultimap<K, V> result = create(multimap.keySet().size(), 2);
		result.putAll(multimap);
		return result;
	}

	private static <K, V> void succeedsInValueSet(ValueSetLink<K, V> pred, ValueSetLink<K, V> succ) {
		pred.setSuccessorInValueSet(succ);
		succ.setPredecessorInValueSet(pred);
	}

	private static <K, V> void succeedsInMultimap(ValueEntry<K, V> pred, ValueEntry<K, V> succ) {
		pred.setSuccessorInMultimap(succ);
		succ.setPredecessorInMultimap(pred);
	}

	private static <K, V> void deleteFromValueSet(ValueSetLink<K, V> entry) {
		succeedsInValueSet(entry.getPredecessorInValueSet(), entry.getSuccessorInValueSet());
	}

	private static <K, V> void deleteFromMultimap(ValueEntry<K, V> entry) {
		succeedsInMultimap(entry.getPredecessorInMultimap(), entry.getSuccessorInMultimap());
	}

	private LinkedHashMultimap(int keyCapacity, int valueSetCapacity) {
		super(Platform.newLinkedHashMapWithExpectedSize(keyCapacity));
		CollectPreconditions.checkNonnegative(valueSetCapacity, "expectedValuesPerKey");
		this.valueSetCapacity = valueSetCapacity;
		this.multimapHeaderEntry = new ValueEntry((Object) null, (Object) null, 0, (ValueEntry) null);
		succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
	}

	Set<V> createCollection() {
		return Platform.newLinkedHashSetWithExpectedSize(this.valueSetCapacity);
	}

	Collection<V> createCollection(K key) {
		return new ValueSet(key, this.valueSetCapacity);
	}

	@CanIgnoreReturnValue
	public Set<V> replaceValues(@NullableDecl K key, Iterable<? extends V> values) {
		return super.replaceValues(key, values);
	}

	public Set<Map.Entry<K, V>> entries() {
		return super.entries();
	}

	public Set<K> keySet() {
		return super.keySet();
	}

	public Collection<V> values() {
		return super.values();
	}

	Iterator<Map.Entry<K, V>> entryIterator() {
		return new Iterator<Map.Entry<K, V>>() {
			ValueEntry<K, V> nextEntry;
			@NullableDecl
			ValueEntry<K, V> toRemove;

			{
				this.nextEntry = LinkedHashMultimap.this.multimapHeaderEntry.successorInMultimap;
			}

			public boolean hasNext() {
				return this.nextEntry != LinkedHashMultimap.this.multimapHeaderEntry;
			}

			public Map.Entry<K, V> next() {
				if (!this.hasNext()) {
					throw new NoSuchElementException();
				} else {
					ValueEntry<K, V> result = this.nextEntry;
					this.toRemove = result;
					this.nextEntry = this.nextEntry.successorInMultimap;
					return result;
				}
			}

			public void remove() {
				CollectPreconditions.checkRemove(this.toRemove != null);
				LinkedHashMultimap.this.remove(this.toRemove.getKey(), this.toRemove.getValue());
				this.toRemove = null;
			}
		};
	}

	Iterator<V> valueIterator() {
		return Maps.valueIterator(this.entryIterator());
	}

	public void clear() {
		super.clear();
		succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
	}

	@GwtIncompatible
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
		stream.writeInt(this.keySet().size());
		Iterator var2 = this.keySet().iterator();

		while (var2.hasNext()) {
			K key = var2.next();
			stream.writeObject(key);
		}

		stream.writeInt(this.size());
		var2 = this.entries().iterator();

		while (var2.hasNext()) {
			Map.Entry<K, V> entry = (Map.Entry) var2.next();
			stream.writeObject(entry.getKey());
			stream.writeObject(entry.getValue());
		}

	}

	@GwtIncompatible
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();
		this.multimapHeaderEntry = new ValueEntry((Object) null, (Object) null, 0, (ValueEntry) null);
		succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
		this.valueSetCapacity = 2;
		int distinctKeys = stream.readInt();
		Map<K, Collection<V>> map = Platform.newLinkedHashMapWithExpectedSize(12);

		int entries;
		for (entries = 0; entries < distinctKeys; ++entries) {
			K key = stream.readObject();
			map.put(key, this.createCollection(key));
		}

		entries = stream.readInt();

		for (int i = 0; i < entries; ++i) {
			K key = stream.readObject();
			V value = stream.readObject();
			((Collection) map.get(key)).add(value);
		}

		this.setMap(map);
	}

	@VisibleForTesting
	final class ValueSet extends Sets.ImprovedAbstractSet<V> implements ValueSetLink<K, V> {
		private final K key;
		@VisibleForTesting
		ValueEntry<K, V>[] hashTable;
		private int size = 0;
		private int modCount = 0;
		private ValueSetLink<K, V> firstEntry;
		private ValueSetLink<K, V> lastEntry;

		ValueSet(K key, int expectedValues) {
			this.key = key;
			this.firstEntry = this;
			this.lastEntry = this;
			int tableSize = Hashing.closedTableSize(expectedValues, 1.0);
			ValueEntry<K, V>[] hashTable = new ValueEntry[tableSize];
			this.hashTable = hashTable;
		}

		private int mask() {
			return this.hashTable.length - 1;
		}

		public ValueSetLink<K, V> getPredecessorInValueSet() {
			return this.lastEntry;
		}

		public ValueSetLink<K, V> getSuccessorInValueSet() {
			return this.firstEntry;
		}

		public void setPredecessorInValueSet(ValueSetLink<K, V> entry) {
			this.lastEntry = entry;
		}

		public void setSuccessorInValueSet(ValueSetLink<K, V> entry) {
			this.firstEntry = entry;
		}

		public Iterator<V> iterator() {
			return new Iterator<V>() {
				ValueSetLink<K, V> nextEntry;
				@NullableDecl
				ValueEntry<K, V> toRemove;
				int expectedModCount;

				{
					this.nextEntry = ValueSet.this.firstEntry;
					this.expectedModCount = ValueSet.this.modCount;
				}

				private void checkForComodification() {
					if (ValueSet.this.modCount != this.expectedModCount) {
						throw new ConcurrentModificationException();
					}
				}

				public boolean hasNext() {
					this.checkForComodification();
					return this.nextEntry != ValueSet.this;
				}

				public V next() {
					if (!this.hasNext()) {
						throw new NoSuchElementException();
					} else {
						ValueEntry<K, V> entry = (ValueEntry) this.nextEntry;
						V result = entry.getValue();
						this.toRemove = entry;
						this.nextEntry = entry.getSuccessorInValueSet();
						return result;
					}
				}

				public void remove() {
					this.checkForComodification();
					CollectPreconditions.checkRemove(this.toRemove != null);
					ValueSet.this.remove(this.toRemove.getValue());
					this.expectedModCount = ValueSet.this.modCount;
					this.toRemove = null;
				}
			};
		}

		public int size() {
			return this.size;
		}

		public boolean contains(@NullableDecl Object o) {
			int smearedHash = Hashing.smearedHash(o);

			for (ValueEntry<K, V> entry = this.hashTable[smearedHash
					& this.mask()]; entry != null; entry = entry.nextInValueBucket) {
				if (entry.matchesValue(o, smearedHash)) {
					return true;
				}
			}

			return false;
		}

		public boolean add(@NullableDecl V value) {
			int smearedHash = Hashing.smearedHash(value);
			int bucket = smearedHash & this.mask();
			ValueEntry<K, V> rowHead = this.hashTable[bucket];

			ValueEntry entry;
			for (entry = rowHead; entry != null; entry = entry.nextInValueBucket) {
				if (entry.matchesValue(value, smearedHash)) {
					return false;
				}
			}

			entry = new ValueEntry(this.key, value, smearedHash, rowHead);
			LinkedHashMultimap.succeedsInValueSet(this.lastEntry, entry);
			LinkedHashMultimap.succeedsInValueSet(entry, this);
			LinkedHashMultimap
					.succeedsInMultimap(LinkedHashMultimap.this.multimapHeaderEntry.getPredecessorInMultimap(), entry);
			LinkedHashMultimap.succeedsInMultimap(entry, LinkedHashMultimap.this.multimapHeaderEntry);
			this.hashTable[bucket] = entry;
			++this.size;
			++this.modCount;
			this.rehashIfNecessary();
			return true;
		}

		private void rehashIfNecessary() {
			if (Hashing.needsResizing(this.size, this.hashTable.length, 1.0)) {
				ValueEntry<K, V>[] hashTable = new ValueEntry[this.hashTable.length * 2];
				this.hashTable = hashTable;
				int mask = hashTable.length - 1;

				for (ValueSetLink<K, V> entry = this.firstEntry; entry != this; entry = entry
						.getSuccessorInValueSet()) {
					ValueEntry<K, V> valueEntry = (ValueEntry) entry;
					int bucket = valueEntry.smearedValueHash & mask;
					valueEntry.nextInValueBucket = hashTable[bucket];
					hashTable[bucket] = valueEntry;
				}
			}

		}

		@CanIgnoreReturnValue
		public boolean remove(@NullableDecl Object o) {
			int smearedHash = Hashing.smearedHash(o);
			int bucket = smearedHash & this.mask();
			ValueEntry<K, V> prev = null;

			for (ValueEntry<K, V> entry = this.hashTable[bucket]; entry != null; entry = entry.nextInValueBucket) {
				if (entry.matchesValue(o, smearedHash)) {
					if (prev == null) {
						this.hashTable[bucket] = entry.nextInValueBucket;
					} else {
						prev.nextInValueBucket = entry.nextInValueBucket;
					}

					LinkedHashMultimap.deleteFromValueSet(entry);
					LinkedHashMultimap.deleteFromMultimap(entry);
					--this.size;
					++this.modCount;
					return true;
				}

				prev = entry;
			}

			return false;
		}

		public void clear() {
			Arrays.fill(this.hashTable, (Object) null);
			this.size = 0;

			for (ValueSetLink<K, V> entry = this.firstEntry; entry != this; entry = entry.getSuccessorInValueSet()) {
				ValueEntry<K, V> valueEntry = (ValueEntry) entry;
				LinkedHashMultimap.deleteFromMultimap(valueEntry);
			}

			LinkedHashMultimap.succeedsInValueSet(this, this);
			++this.modCount;
		}
	}

	@VisibleForTesting
	static final class ValueEntry<K, V> extends ImmutableEntry<K, V> implements ValueSetLink<K, V> {
		final int smearedValueHash;
		@NullableDecl
		ValueEntry<K, V> nextInValueBucket;
		@NullableDecl
		ValueSetLink<K, V> predecessorInValueSet;
		@NullableDecl
		ValueSetLink<K, V> successorInValueSet;
		@NullableDecl
		ValueEntry<K, V> predecessorInMultimap;
		@NullableDecl
		ValueEntry<K, V> successorInMultimap;

		ValueEntry(@NullableDecl K key, @NullableDecl V value, int smearedValueHash,
				@NullableDecl ValueEntry<K, V> nextInValueBucket) {
			super(key, value);
			this.smearedValueHash = smearedValueHash;
			this.nextInValueBucket = nextInValueBucket;
		}

		boolean matchesValue(@NullableDecl Object v, int smearedVHash) {
			return this.smearedValueHash == smearedVHash && Objects.equal(this.getValue(), v);
		}

		public ValueSetLink<K, V> getPredecessorInValueSet() {
			return this.predecessorInValueSet;
		}

		public ValueSetLink<K, V> getSuccessorInValueSet() {
			return this.successorInValueSet;
		}

		public void setPredecessorInValueSet(ValueSetLink<K, V> entry) {
			this.predecessorInValueSet = entry;
		}

		public void setSuccessorInValueSet(ValueSetLink<K, V> entry) {
			this.successorInValueSet = entry;
		}

		public ValueEntry<K, V> getPredecessorInMultimap() {
			return this.predecessorInMultimap;
		}

		public ValueEntry<K, V> getSuccessorInMultimap() {
			return this.successorInMultimap;
		}

		public void setSuccessorInMultimap(ValueEntry<K, V> multimapSuccessor) {
			this.successorInMultimap = multimapSuccessor;
		}

		public void setPredecessorInMultimap(ValueEntry<K, V> multimapPredecessor) {
			this.predecessorInMultimap = multimapPredecessor;
		}
	}

	private interface ValueSetLink<K, V> {
		ValueSetLink<K, V> getPredecessorInValueSet();

		ValueSetLink<K, V> getSuccessorInValueSet();

		void setPredecessorInValueSet(ValueSetLink<K, V> var1);

		void setSuccessorInValueSet(ValueSetLink<K, V> var1);
	}
}