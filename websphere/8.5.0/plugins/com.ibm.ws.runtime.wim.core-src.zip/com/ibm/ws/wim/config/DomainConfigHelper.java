package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.DomainConstants;
import com.ibm.websphere.wim.ServiceProvider;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.InvalidArgumentException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.sm.workspace.RepositoryContext;
import com.ibm.ws.sm.workspace.WorkSpace;
import com.ibm.ws.sm.workspace.WorkSpaceException;
import com.ibm.ws.sm.workspace.WorkSpaceManagerFactory;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.EventManager;
import com.ibm.ws.wim.ProfileManager;
import com.ibm.ws.wim.PropertyManager;
import com.ibm.ws.wim.RealmManager;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.security.authz.ProfileSecurityManager;
import com.ibm.ws.wim.util.DomainManagerUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.Resource.Factory;

public class DomainConfigHelper implements DomainConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final String FILE_REGISTRY = "fileRegistry.xml";
	private static final String schar;
	WorkSpace workspace = null;
	RepositoryContext context = null;

	public void copyDomainFiles(String var1, Map var2, String var3) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "copyDomainFiles", WIMMessageHelper.generateMsgParms(var1, var2));
		}

		String var5 = null;
		String var6 = null;
		String var7 = null;
		String var8 = null;
		var5 = (String) var2.get("srcDomainName");
		var6 = (String) var2.get("destDomainName");
		if (!"admin".equals(var6) && !"global".equals(var6)) {
			if (var5.equals(var6)) {
				throw new InvalidArgumentException("SOURCE_DEST_CANNOT_HAVE_SAME_VALUE");
			} else {
				if ("admin".equals(var5)) {
					var7 = ConfigManager.singleton().getWIMHomePath();
				} else if ("global".equals(var5)) {
					var7 = ConfigManager.singleton().getGlobalWIMHomePath();
				} else {
					var7 = DomainManagerUtils.getDomainPath(var5);
					if (!(new File(var7)).isDirectory()) {
						var7 = DomainManagerUtils.getDomainPathFromTemp(var5, var3);
						if (!(new File(var7)).isDirectory()) {
							DomainManagerUtils.validateDomainName(var5);
						}
					}

					var7 = var7 + "wim" + schar;
				}

				var8 = DomainManagerUtils.getDomainPathFromTemp(var6, var3);
				this.workspace = WorkSpaceManagerFactory.getManager().getWorkSpace(var1);
				this.context = this.workspace
						.findContext(DomainManagerUtils.RELATIVE_WIM_CONFIG_DOMAIN_PATH + schar + var6 + schar);
				new File(this.context.getPath() + schar + "wim");
				String var10 = var7 + ".." + schar + "fileRegistry.xml";
				String var11 = var8 + "fileRegistry.xml";
				if ((new File(var10)).exists()) {
					this.copyDirectory(new File(var10), new File(var11));
					this.context.notifyChanged(0, "wim" + schar + "fileRegistry.xml");
				}

				File var12 = new File(var7);
				var8 = var8 + "wim" + schar;
				File var13 = new File(var8);
				var13.mkdir();
				this.copyDirectory(var12, var13);
				new File(this.context.getPath() + schar + "wim");
				this.context = this.workspace
						.findContext(DomainManagerUtils.RELATIVE_WIM_CONFIG_DOMAIN_PATH + schar + var6 + schar);
				Set var14 = this.context.getFiles();
				int var15 = var14.size();

				for (int var16 = 0; var16 < var14.toArray().length; ++var16) {
					this.context.notifyChanged(0, var14.toArray()[var16].toString());
					if (var14.toArray()[var16].toString().indexOf(this.context.toString()) > 0) {
						this.context.notifyChanged(0,
								var14.toArray()[var16].toString()
										.substring(var14.toArray()[var16].toString().indexOf(this.context.toString())
												+ this.context.toString().length()));
						this.moveWIMFiles(this.context, this.workspace,
								var14.toArray()[var16].toString()
										.substring(var14.toArray()[var16].toString().indexOf(this.context.toString())
												+ this.context.toString().length()));
					} else {
						this.context.notifyChanged(0, var14.toArray()[var16].toString());
						this.moveWIMFiles(this.context, this.workspace, var14.toArray()[var16].toString());
					}
				}

				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "copyDomainFiles");
				}

			}
		} else {
			throw new InvalidArgumentException("DESTINATION_DOMAIN_CANNOT_BE_ADMIN_OR_GLOBAL");
		}
	}

	public void moveWIMFiles(RepositoryContext var1, WorkSpace var2, String var3) throws WorkSpaceException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "moveWIMFiles", WIMMessageHelper.generateMsgParms(var1, var2, var3));
		}

		if (var1.isAvailable(var3)) {
			var1.extract(var3, false);
		} else {
			Factory var5 = var2.getResourceFactoryRegistry().getFactory(URI.createURI(var3));
			Resource var6 = var5.createResource(URI.createURI(var3));
			boolean var7 = var1.getResourceSet().getResources().add(var6);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "moveWIMFiles");
		}

	}

	public void copyDirectory(File var1, File var2) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "copyDirectory", WIMMessageHelper.generateMsgParms(var1, var2));
		}

		try {
			if (var1.isDirectory()) {
				if (!var2.exists()) {
					var2.mkdir();
				}

				String[] var4 = var1.list();

				for (int var5 = 0; var5 < var4.length; ++var5) {
					this.copyDirectory(new File(var1, var4[var5]), new File(var2, var4[var5]));
				}
			} else {
				if (var1.exists()) {
					if (var1.canRead()) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "copyDirectory",
									"Source File exists and can be read");
						} else if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "copyDirectory",
									"Source File exists but cannot be read");
						}
					}
				} else if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "copyDirectory", "Source File does not exist");
				}

				if (var2.exists()) {
					if (var2.canWrite()) {
						if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "copyDirectory",
									"Target File exists and can be written");
						} else if (trcLogger.isLoggable(Level.FINER)) {
							trcLogger.logp(Level.FINER, CLASSNAME, "copyDirectory",
									"Target File exists but cannot be written");
						}
					}
				} else if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "copyDirectory", "Target File does not exist");
				}

				FileInputStream var16 = new FileInputStream(var1);
				FileOutputStream var17 = new FileOutputStream(var2);
				byte[] var6 = new byte[1024];

				try {
					int var7;
					try {
						while ((var7 = var16.read(var6)) > 0) {
							var17.write(var6, 0, var7);
						}
					} catch (IOException var13) {
						throw new WIMConfigurationException("COULD_NOT_COPY_VMM_RELATED_FILES", CLASSNAME,
								"copyDirectory", var13);
					}
				} finally {
					var16.close();
					var17.close();
					this.context.notifyChanged(0,
							var2.toString().substring(this.context.getPath().toString().length() + 1));
				}
			}
		} catch (FileNotFoundException var15) {
			throw new InitializationException("FILE_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1), Level.SEVERE,
					CLASSNAME, "copyDirectory", var15);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "copyDirectory");
		}

	}

	public void deleteDomainCache(Map var1) throws Exception {
		String var2 = var1.get("securityDomainName").toString();
		ServiceProvider.clearCache(var2);
		ConfigManager.clearCache(var2);
		EventManager.clearCache(var2);
		ProfileManager.clearCache(var2);
		ConfigSessionManager.clearCache(var2);
		PropertyManager.clearCache(var2);
		RealmManager.clearCache(var2);
		RepositoryManager.clearCache(var2);
		SchemaManager.clearCache(var2);
		ProfileSecurityManager.clearCache(var2);
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010;
		CLASSNAME = DomainConfigHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		schar = File.separator;
	}
}