package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_ja extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"security.openid20.client.authrequestfailed",
					"CWTAI3002E: 例外 [{0}] のため、OpenID リライング・パーティー (RP) は、 ユーザーを認証用 OpenID プロバイダー (OP) へリダイレクトできませんでした。"},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: OpenID リライング・パーティー (RP) は、WebSphere サーバーのデフォルトの SSLContext を取得できなかったため、初期化できませんでした。例外は [{0}] です"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: 例外 [{1}] のため、OpenID リライング・パーティー (RP) は、ID [{0}] で指定された OpenID プロバイダー (OP) に接続できませんでした。"},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: 例外 [{0}] のため、OpenID リライング・パーティー (RP) を初期化できませんでした。"},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: [{0}] プロパティーの値が正しくフォーマット設定されていないため、OpenID リライング・パーティー (RP) が初期化しました。"},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: トークン値が無効のため、OpenID リライング・パーティー (RP) は、基本認証トークンを使用して要求を認証することができませんでした。"},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: [{0}] プロパティーが正しく指定されていないため、OpenID リライング・パーティー (RP) を初期化できませんでした。このプロパティーは、有効な URL である必要があります。"},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: OpenID リライング・パーティー (RP) は、OpenID プロバイダー (OP) から正しくない応答を受信しました。このエラーの原因は [{0}] です。"},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: 内部キャッシュの最大容量に達したため、OpenID リライング・パーティー (RP) は、認証を実行できませんでした。"},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: 必須プロパティー axRequiredAttribute[n] が欠落しているため、OpenID リライング・パーティー (RP) を初期化できませんでした。少なくとも 1 つのプロパティーを定義する必要があります。"},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: 必須プロパティー [{0}] の値が欠落しているか、または空であるため、OpenID リライング・パーティー (RP) を初期化できませんでした。"},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: OpenID リライング・パーティー (RP) は SSL (HTTPS) を必要としていますが、OpenID プロバイダー (OP) URL は HTTP です: [{0}]。[{1}] 属性は、ターゲット URL スキームと一致しなければなりません。"},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: OpenID リライング・パーティー (RP) は、OpenID 仕様バージョン 2 をサポートしていない OpenID プロバイダー (OP) から応答を受信しました。"},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: OpenID リライング・パーティー (RP) が、OpenID プロバイダー (OP) から受信した応答の検証中に失敗しました。例外は [{0}] でした。"}};

	public Object[][] getContents() {
		return resources;
	}
}