package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface LdapRepositoryType extends ProfileRepositoryType {
	LdapServerConfigurationType getLdapServerConfiguration();

	void setLdapServerConfiguration(LdapServerConfigurationType var1);

	LdapServerConfigurationType createLdapServerConfiguration();

	List getLdapEntityTypes();

	LdapEntityTypesType[] getLdapEntityTypesAsArray();

	LdapEntityTypesType createLdapEntityTypes();

	GroupConfigurationType getGroupConfiguration();

	void setGroupConfiguration(GroupConfigurationType var1);

	GroupConfigurationType createGroupConfiguration();

	AttributeConfigurationType getAttributeConfiguration();

	void setAttributeConfiguration(AttributeConfigurationType var1);

	AttributeConfigurationType createAttributeConfiguration();

	ContextPoolType getContextPool();

	void setContextPool(ContextPoolType var1);

	ContextPoolType createContextPool();

	CacheConfigurationType getCacheConfiguration();

	void setCacheConfiguration(CacheConfigurationType var1);

	CacheConfigurationType createCacheConfiguration();

	String getCertificateFilter();

	void setCertificateFilter(String var1);

	String getCertificateMapMode();

	void setCertificateMapMode(String var1);

	void unsetCertificateMapMode();

	boolean isSetCertificateMapMode();

	String getLdapServerType();

	void setLdapServerType(String var1);

	boolean isTranslateRDN();

	void setTranslateRDN(boolean var1);

	void unsetTranslateRDN();

	boolean isSetTranslateRDN();
}