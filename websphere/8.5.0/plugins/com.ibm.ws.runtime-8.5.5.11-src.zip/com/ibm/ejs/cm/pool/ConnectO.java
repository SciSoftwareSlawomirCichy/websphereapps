package com.ibm.ejs.cm.pool;

import com.ibm.ejs.cm.CMPropertiesImpl;
import com.ibm.ejs.cm.CMXAResourceImpl;
import com.ibm.ejs.cm.ConnectionManagerTracer;
import com.ibm.ejs.cm.cache.StatementCache;
import com.ibm.ejs.cm.exception.IllegalConnectionUseException;
import com.ibm.ejs.cm.exception.IllegalTransactionStateException;
import com.ibm.ejs.cm.exception.TransactionAbortedException;
import com.ibm.ejs.cm.exception.WorkRolledbackException;
import com.ibm.ejs.cm.pool.ConnectO.1;
import com.ibm.ejs.cm.portability.OraclePortabilityLayer;
import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.cm.portability.PortabilityLayerExt;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import com.ibm.ejs.util.QueueElement;
import com.ibm.ejs.util.am.Alarm;
import com.ibm.ejs.util.am.AlarmListener;
import com.ibm.ejs.util.am.AlarmManager;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import com.ibm.ws.LocalTransaction.LTCSystemException;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.Transaction.IllegalResourceIn2PCTransactionException;
import com.ibm.ws.Transaction.OnePhaseXAResource;
import com.ibm.ws.Transaction.TransactionManagerFactory;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.service.EJBContainer;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import java.lang.reflect.Method;
import java.security.PrivilegedActionException;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.ClientInfoStatus;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;
import java.util.concurrent.Executor;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.PooledConnection;
import javax.sql.XAConnection;
import javax.transaction.RollbackException;
import javax.transaction.Synchronization;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;

public class ConnectO extends QueueElement
		implements
			ExtendedConnection,
			OnePhaseXAResource,
			Synchronization,
			AlarmListener,
			InvocationCollaborator {
	private static final TraceNLS NLS = TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages");
	private Xid xid;
	private boolean rolledBack = false;
	protected Connection connection;
	protected final ConnectionPool pool;
	private final String username;
	private final String password;
	protected UOWCoordinator uowCoord;
	private boolean isGlobalCoordinator = false;
	private StatementCache statementCache;
	protected int state = 0;
	protected static final int FREE = 0;
	protected static final int ALLOCATED = 1;
	protected static final int ALLOCATED_REG_SYNC = 2;
	protected static final int ALLOCATED_TX = 3;
	protected static final int PREPARING = 4;
	protected static final int DESTROYED = 5;
	private static final String[] stateStrings = new String[]{"FREE", "ALLOCATED", "ALLOCATED_REG_SYNC", "ALLOCATED_TX",
			"PREPARING", "DESTROYED"};
	private boolean autoCommit = true;
	private boolean autoCommit_Last = true;
	private int isolationLevel = 0;
	private boolean isolationLevelChanged = false;
	private boolean readOnlyChanged = false;
	private Alarm idleAlarm;
	private static final Object IDLE_ALARM = new Object();
	private Vector listeners = new Vector(4);
	private boolean canAddListener = true;
	protected boolean dirty = false;
	protected int refCount = 0;
	protected int numInUse = 0;
	protected boolean orphaned = false;
	protected int aged = 0;
	protected boolean cleanwarning = false;
	protected boolean maybeStale = false;
	protected boolean alreadyDestroyed = false;
	protected static final int ENLISTED_IN_NOTRAN = 0;
	protected static final int INVOLVED_IN_LOCALTRAN = 1;
	protected static final int ENLISTED_IN_LOCALTRAN = 2;
	protected static final int ENLISTED_IN_GLOBALTRAN = 3;
	protected static final int INVOLVED_IN_RRSLOCALTRAN = 4;
	protected static final int INVOLVED_IN_RRSGLOBALTRAN = 5;
	protected int transactionState = 0;
	private static final String[] tranStateStrings = new String[]{"ENLISTED_IN_NOTRAN", "INVOLVED_IN_LOCALTRAN",
			"ENLISTED_IN_LOCALTRAN", "ENLISTED_IN_GLOBALTRAN", "INVOLVED_IN_RRSLOCALTRAN", "INVOLVED_IN_RRSGLOBALTRAN"};
	private XAConnection xaConnection = null;
	private PooledConnection pooledConnection = null;
	boolean supports2PC = false;
	boolean rrsTransactional = false;
	public boolean oraTransLoose = false;
	private Method getCurrentUOW = null;
	private static EJBContainer ejbContainer;
	private ConnectionManagerTracer tracer = null;
	private static final TraceComponent tc = Tr.register(ConnectO.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createArrayOf(String, Object[])");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Blob createBlob() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createBlob()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Clob createClob() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createClob()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public NClob createNClob() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createNClob()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public SQLXML createSQLXML() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createSQLXML()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createStruct(String, Object[])");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Properties getClientInfo() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getClientInfo()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public String getClientInfo(String name) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getClientInfo(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public boolean isValid(int timeout) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isValid(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setClientInfo(Properties properties) throws SQLClientInfoException {
		Tr.error(tc, "MSG_CONM_8001E", "setClientInfo(Properties)");
		HashMap<String, ClientInfoStatus> hm = null;
		if (properties != null && properties.size() != 0) {
			hm = new HashMap();
			Enumeration keys = properties.keys();

			while (keys.hasMoreElements()) {
				Object key = keys.nextElement();
				if (key != null) {
					hm.put(key.toString(), ClientInfoStatus.REASON_UNKNOWN);
				} else {
					hm.put((Object) null, ClientInfoStatus.REASON_UNKNOWN);
				}
			}
		} else {
			hm = new HashMap(0);
		}

		throw new SQLClientInfoException(NLS.getString("MSG_CONM_8002E", "This method is not supported."), hm);
	}

	public void setClientInfo(String name, String value) throws SQLClientInfoException {
		Tr.error(tc, "MSG_CONM_8001E", "setClientInfo(String, String)");
		HashMap<String, ClientInfoStatus> hm = new HashMap(1);
		hm.put(name, ClientInfoStatus.REASON_UNKNOWN);
		throw new SQLClientInfoException(NLS.getString("MSG_CONM_8002E", "This method is not supported."), hm);
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isWrapperFor(Class<?>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "unwrap(Class<T>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setHoldability(int h) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setHoldability(int)");
		throw new SQLException("This method is not supported.");
	}

	public int getHoldability() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getHoldability()");
		throw new SQLException("This method is not supported.");
	}

	public Savepoint setSavepoint() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setSavepoint()");
		throw new SQLException("This method is not supported.");
	}

	public Savepoint setSavepoint(String s) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setSavepoint(String)");
		throw new SQLException("This method is not supported.");
	}

	public void rollback(Savepoint sp) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "rollback(Savepoint)");
		throw new SQLException("This method is not supported.");
	}

	public void releaseSavepoint(Savepoint sp) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "releaseSavepoint(Savepoint)");
		throw new SQLException("This method is not supported.");
	}

	public Statement createStatement(int x, int y, int z) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "createStatement(int, int, int)");
		throw new SQLException("This method is not supported.");
	}

	public PreparedStatement prepareStatement(String s, int x, int y, int z) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareStatement(String, int, int, int)");
		throw new SQLException("This method is not supported.");
	}

	public CallableStatement prepareCall(String s, int x, int y, int z) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareCall(String, int, int, int)");
		throw new SQLException("This method is not supported.");
	}

	public PreparedStatement prepareStatement(String s, int x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareStatement(String, int)");
		throw new SQLException("This method is not supported.");
	}

	public PreparedStatement prepareStatement(String s, int[] x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareStatement(String, int[])");
		throw new SQLException("This method is not supported.");
	}

	public PreparedStatement prepareStatement(String s, String[] strs) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareStatement(String, String[])");
		throw new SQLException("This method is not supported.");
	}

	protected ConnectO(PooledConnection pooledConnection, ConnectionPool pool, String username, String password)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "1 Phase ConnectO Constructor");
		}

		try {
			ClassLoader cl = Thread.currentThread().getContextClassLoader();
			Class cr = cl.loadClass("com.ibm.ejs.j2c.ConnectorRuntime");
			this.getCurrentUOW = cr.getMethod("getCurrentUOW", (Class[]) null);
		} catch (Exception var7) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Could not find getCurrentUOW in ConnectorRuntime");
			}

			throw new SQLException(var7.getMessage());
		}

		this.pooledConnection = pooledConnection;
		((PortabilityLayer) pool.getPortabilityLayer()).configurePooledConnection(pooledConnection,
				pool.getAttributes());
		this.connection = pooledConnection.getConnection();
		this.supports2PC = false;
		this.pool = pool;
		this.username = username != null ? username : "_null_username";
		this.password = password != null ? password : "_null_password";
		this.initialize(username, password);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "1 Phase ConnectO Constructor");
		}

	}

	protected ConnectO(XAConnection xaConnection, ConnectionPool pool, String username, String password)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "2PC Constructor");
		}

		CMPropertiesImpl cmProps = (CMPropertiesImpl) pool.getAttributes();
		this.oraTransLoose = cmProps.getOraTransLoose();

		try {
			ClassLoader cl = Thread.currentThread().getContextClassLoader();
			Class cr = cl.loadClass("com.ibm.ejs.j2c.ConnectorRuntime");
			this.getCurrentUOW = cr.getMethod("getCurrentUOW", (Class[]) null);
		} catch (Exception var8) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Could not find getCurrentUOW in ConnectorRuntime");
			}

			throw new SQLException(var8.getMessage());
		}

		this.xaConnection = xaConnection;
		((PortabilityLayer) pool.getPortabilityLayer()).configureXAConnection(xaConnection, pool.getAttributes());
		this.connection = xaConnection.getConnection();
		this.supports2PC = true;
		this.pool = pool;
		this.username = username != null ? username : "_null_username";
		this.password = password != null ? password : "_null_password";
		this.initialize(username, password);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "2PC Constructor");
		}

	}

	protected ConnectO(PooledConnection pooledConnection, ConnectionPool pool, String username, String password,
			String rrsString) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "RRSTransactional ConnectO Constructor");
		}

		try {
			ClassLoader cl = Thread.currentThread().getContextClassLoader();
			Class cr = cl.loadClass("com.ibm.ejs.j2c.ConnectorRuntime");
			this.getCurrentUOW = cr.getMethod("getCurrentUOW", (Class[]) null);
		} catch (Exception var8) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Could not find getCurrentUOW in ConnectorRuntime");
			}

			throw new SQLException(var8.getMessage());
		}

		this.pooledConnection = pooledConnection;
		((PortabilityLayer) pool.getPortabilityLayer()).configurePooledConnection(pooledConnection,
				pool.getAttributes());
		this.connection = pooledConnection.getConnection();
		this.supports2PC = false;
		this.rrsTransactional = true;
		this.pool = pool;
		this.username = username != null ? username : "_null_username";
		this.password = password != null ? password : "_null_password";
		this.initialize(username, password);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "RRSTransactional ConnectO Constructor");
		}

	}

	public void setCurrentSQLID(String currentSQLID) throws SQLException {
		if (currentSQLID != null) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Setting currentSQLID to " + currentSQLID);
			}

			String sql = "set current sqlid = '" + currentSQLID + "'";
			Statement stmt = this.connection.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
		}

	}

	private void initialize(String username, String password) throws SQLException {
		this.isolationLevel = this.connection.getTransactionIsolation();
		this.autoCommit = this.connection.getAutoCommit();
		((PortabilityLayer) this.pool.getPortabilityLayer()).configureConnection(this.connection,
				(CMPropertiesImpl) this.pool.getAttributes());
		if (tc.isEventEnabled()) {
			Tr.event(tc, "Initial settings: isolattionLevel, autoCommit, 2PC, RRSTransactional, user ",
					new Object[]{new Integer(this.isolationLevel), new Boolean(this.autoCommit),
							new Boolean(this.supports2PC), new Boolean(this.rrsTransactional),
							new String(this.username)});
		}

	}

	public final void addEventListener(ConnectOEventListener l) throws SQLException {
		if (this.canAddListener) {
			this.listeners.addElement(l);
		} else {
			throw new StaleConnectionException("ConnectO is no longer available.");
		}
	}

	public final void removeEventListener(ConnectOEventListener l) {
		this.listeners.removeElement(l);
	}

	public final ConnectionPool getPool() {
		return this.pool;
	}

	public final String toString() {
		return this.getClass().getName() + "@" + System.identityHashCode(this) + " [supports2PC=" + this.supports2PC()
				+ ", rrsTransactional=" + this.supportsRRSTransactional() + ", " + this.getStateString() + ", "
				+ this.getTransactionStateString() + ", RefCNT=" + this.refCount + "]";
	}

	protected final String getStateString() {
		return stateStrings[this.state];
	}

	protected final String getTransactionStateString() {
		return tranStateStrings[this.transactionState];
	}

	protected boolean supports2PC() {
		return this.supports2PC;
	}

	public boolean supportsRRSTransactional() {
		return this.rrsTransactional;
	}

	protected synchronized void incRef() {
		switch (this.state) {
			case 1 :
			case 2 :
			case 3 :
			case 4 :
				++this.refCount;
				return;
			default :
				Error e = new Error("Illegal ConnectO state: " + this.getStateString());
				if (tc.isEventEnabled()) {
					Tr.event(tc, "Illegal ConnectO state", e);
				}

				throw e;
		}
	}

	protected void decRef() throws SQLException {
		boolean free = false;
		boolean throwRollbackException = false;
		synchronized (this) {
			Error e;
			if (this.refCount == 0) {
				e = new Error("Reference counting error");
				if (tc.isEventEnabled()) {
					Tr.event(tc, "Reference counting error", e);
				}

				throw e;
			}

			if (this.refCount == 1 && (this.rolledBack || this.transactionState == 0 && this.dirty)) {
				try {
					if (this.connection != null) {
						if (tc.isEventEnabled()) {
							Tr.event(tc, "decRef(): Performing delayed 1PC rollback");
						}

						this.connection.rollback();
						if (tc.isEventEnabled()) {
							Tr.event(tc, "decRef(): Delayed 1PC rollback is complete");
						}
					} else if (tc.isEventEnabled()) {
						Tr.event(tc, "decRef(): Null Connection, rollback not performed.");
					}
				} catch (SQLException var10) {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "decRef(): Exception rolling back connection", var10);
					}
				} finally {
					this.dirty = false;
					if (!this.rolledBack) {
						throwRollbackException = true;
					}

					this.rolledBack = false;
				}
			}

			switch (this.state) {
				case 1 :
					--this.refCount;
					free = this.refCount == 0;
					break;
				case 2 :
				case 3 :
				case 4 :
					if (this.refCount == 1) {
						e = new Error("Reference counting error");
						if (tc.isEventEnabled()) {
							Tr.event(tc,
									"decRef(): Attempted to drop final reference while associated with transaction", e);
						}

						throw e;
					}
				case 5 :
					--this.refCount;
					break;
				default :
					e = new Error("Illegal ConnectO state: " + this.getStateString());
					if (tc.isEventEnabled()) {
						Tr.event(tc, "decRef():  Illegal ConnectO state", e);
					}

					throw e;
			}
		}

		if (free) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "decRef(): Ref count dropped to 0; freeing connection back to pool.");
			}

			this.free();
		}

		if (throwRollbackException) {
			throw new WorkRolledbackException();
		}
	}

	public int getRefCount() {
		return this.refCount;
	}

	protected boolean incNumInUse() throws IllegalConnectionUseException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "incNumInUse()");
		}

		synchronized (this) {
			if (this.state == 0) {
				return false;
			}

			++this.numInUse;
			if (this.numInUse > 1) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc,
							"Error: Multi-threaded access of connection detected, a connection may have been leaked",
							new Object[]{this});
				}

				throw new IllegalConnectionUseException();
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "incNumInUse: New numInUse=" + this.numInUse);
		}

		return true;
	}

	protected void decNumInUse() {
		synchronized (this) {
			--this.numInUse;
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "decNumInUse: New numInUse=" + this.numInUse);
		}

	}

	protected final void enlist() throws SQLException {
		if (this.uowCoord == null) {
			UOWCurrent uowCurrent = TransactionManagerFactory.getUOWCurrent();
			this.uowCoord = uowCurrent.getUOWCoord();
		}

		this.enlist(this.uowCoord, false);
	}

	protected synchronized void enlist(UOWCoordinator uowCoord, boolean regForSyncOnly) throws SQLException {
      if (tc.isEntryEnabled()) {
         if (uowCoord == null) {
            Tr.entry(tc, "enlist", new Object[]{uowCoord, new Boolean(regForSyncOnly)});
         } else {
            Tr.entry(tc, "enlist", new Object[]{uowCoord, new Boolean(uowCoord.isGlobal()), new Boolean(regForSyncOnly)});
         }
      }

      if (uowCoord != null || this.state != 1 && this.state != 2) {
         if (this.rrsTransactional && this.state == 2) {
            if (!this.isolationLevelChanged()) {
               this.setConnectionIsolation(uowCoord);
            }

         } else {
            LocalTransactionCoordinator LTCoord;
            switch(this.state) {
            case 1:
            case 2:
               TransactionAbortedException x;
               if (this.state == 1) {
                  try {
                     if (tc.isEventEnabled()) {
                        Tr.event(tc, "enlist(): about to register for synchronization with Tran. ", uowCoord);
                     }

                     try {
                        if (uowCoord == null) {
                           throw new SQLException("INTERNAL ERROR: No valid transaction context present");
                        }

                        if (uowCoord.isGlobal()) {
                           TransactionManagerFactory.getTransactionManager().registerSynchronization(uowCoord, this);
                           this.isGlobalCoordinator = true;
                           if (this.rrsTransactional) {
                              this.transactionState = 5;
                              if (tc.isDebugEnabled()) {
                                 Tr.debug(tc, "enlist(): connection involved in RRS Global Transanaction.", this);
                              }
                           }
                        } else {
                           LTCoord = (LocalTransactionCoordinator)uowCoord;
                           LTCoord.enlistSynchronization(this);
                           this.isGlobalCoordinator = false;
                           if (this.rrsTransactional) {
                              this.transactionState = 4;
                              if (tc.isDebugEnabled()) {
                                 Tr.debug(tc, "enlist(): connection involved in RRS Local Transanaction.", this);
                              }
                           }
                        }
                     } catch (Exception var17) {
                        if (this.refCount == 0) {
                           this.free();
                        }

                        throw var17;
                     }

                     this.incRef();
                     this.uowCoord = uowCoord;
                     this.state = 2;
                     this.fireConnectionEnlisted(uowCoord);
                     if (regForSyncOnly) {
                        if (tc.isEntryEnabled()) {
                           Tr.exit(tc, "enlist");
                        }

                        return;
                     }
                  } catch (IllegalStateException var18) {
                     if (tc.isEventEnabled()) {
                        Tr.event(tc, "enlist: Can't register now", var18);
                     }

                     Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"IllegalStateException", "enlist", "IllegalTransactionStateException", var18});
                     throw new IllegalTransactionStateException();
                  } catch (RollbackException var19) {
                     if (tc.isEventEnabled()) {
                        Tr.event(tc, "enlist: Transaction rolled back", var19);
                     }

                     Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"RollbackException", "enlist", "TransactionAbortedException", var19});
                     throw new TransactionAbortedException();
                  } catch (SystemException var20) {
                     if (tc.isEventEnabled()) {
                        Tr.event(tc, "enlist: System exception", var20);
                     }

                     Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"SystemException", "enlist", "TransactionAbortedException", var20});
                     throw new TransactionAbortedException();
                  } catch (LTCSystemException var21) {
                     if (tc.isEventEnabled()) {
                        Tr.event(tc, "enlist: LTC System exception", var21);
                     }

                     Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"LTCSystemException", "enlist", "TransactionAbortedException", var21});
                     throw new TransactionAbortedException();
                  } catch (Exception var22) {
                     Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"Exception", "enlist", "TransactionAbortedException", var22});
                     x = new TransactionAbortedException();
                     if (tc.isEntryEnabled()) {
                        Tr.exit(tc, "enlist:", x);
                     }

                     throw x;
                  }
               }

               if (!regForSyncOnly) {
                  if (uowCoord == null) {
                     throw new SQLException("INTERNAL ERROR: No valid transaction context present");
                  }

                  if (uowCoord.isGlobal()) {
                     if (this.dirty) {
                        if (tc.isEventEnabled()) {
                           Tr.event(tc, "enlist: Connection is dirty: cannot join global transaction");
                        }

                        Tr.error(tc, "MSG_CONM_6013E", this.pool.getAttributes().getName());
                        throw new IllegalStateException("Connection is dirty: cannot join global transaction");
                     }

                     if (this.supports2PC() && this.getPortabilityLayer() instanceof OraclePortabilityLayer) {
                        if (tc.isEventEnabled()) {
                           Tr.event(tc, "Oracle XAConnection detected, autocommit is already set to false");
                        }
                     } else if (this.rrsTransactional) {
                        if (tc.isDebugEnabled()) {
                           Tr.debug(tc, "Global tran using RRS detected .... setAutoCommit() is skipped when in RRS Global tran.");
                        }
                     } else {
                        this.setAutoCommit(false);
                     }

                     if (!this.isolationLevelChanged()) {
                        this.setConnectionIsolation(uowCoord);
                     }

                     if (this.supports2PC()) {
                        CMXAResourceImpl r = new CMXAResourceImpl(this.xaConnection.getXAResource(), this);
                        x = null;

                        try {
                           Class var26 = (Class)AccessController.doPrivileged(new 1(this));
                        } catch (PrivilegedActionException var9) {
                           Tr.error(tc, "MSG_CONM_6015E", new Object[]{"enlist", this.pool.getXAResourceFactoryName(), "TransactionAbortedException"});
                           throw (TransactionAbortedException)(new TransactionAbortedException()).initCause(var9.getException());
                        }

                        try {
                           if (tc.isEventEnabled()) {
                              Tr.event(tc, "enlist(): about to Enlist XAResource in Global Tran. " + this.toString(), uowCoord);
                           }

                           boolean returnValue;
                           try {
                              returnValue = TransactionManagerFactory.getTransactionManager().enlist(uowCoord, r, this.pool.getXAResourceFactoryName(), this.pool.getXAResourceInfo());
                           } catch (org.omg.CORBA.SystemException var7) {
                              this.pool.destroyConnection(this);
                              throw new TransactionAbortedException();
                           }

                           if (tc.isEventEnabled()) {
                              Tr.event(tc, "Enlist completed with return code: " + returnValue);
                           }

                           if (!returnValue) {
                              Tr.error(tc, "MSG_CONM_6016E", "TransactionAbortedException");
                              this.pool.destroyConnection(this);
                              throw new TransactionAbortedException();
                           }

                           this.state = 3;
                           this.transactionState = 3;
                           this.incRef();
                        } catch (Exception var8) {
                           this.pool.destroyConnection(this);
                           Tr.error(tc, "MSG_CONM_6016E", "TransactionAbortedException");
                           throw new TransactionAbortedException();
                        }
                     } else if (this.supportsRRSTransactional()) {
                        if (tc.isEventEnabled()) {
                           Tr.event(tc, "RRS transactional already enlisted in transaction.");
                        }
                     } else {
                        try {
                           if (tc.isEventEnabled()) {
                              Tr.event(tc, "enlist(): about to Enlist in GlobalTran. " + this.toString(), uowCoord);
                           }

                           TransactionManagerFactory.getTransactionManager().enlistOnePhase(uowCoord, this);
                           this.state = 3;
                           this.transactionState = 3;
                           this.incRef();
                        } catch (IllegalStateException var12) {
                           if (tc.isEventEnabled()) {
                              Tr.event(tc, "enlist(): Can't enlist now", var12);
                           }

                           if (var12 instanceof IllegalResourceIn2PCTransactionException) {
                              FFDCFilter.processException(var12, "com.ibm.ejs.cm.pool.ConnectO.enlist", "1054", this);
                           }

                           Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"IllegalStateException", "enlist", "IllegalTransactionStateException", var12});
                           throw new IllegalTransactionStateException();
                        } catch (RollbackException var13) {
                           if (tc.isEventEnabled()) {
                              Tr.event(tc, "enlist(): Transaction rolled back", var13);
                           }

                           Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"RollbackException", "enlist", "TransactionAbortedException", var13});
                           throw new TransactionAbortedException();
                        } catch (SystemException var14) {
                           if (tc.isEventEnabled()) {
                              Tr.event(tc, "enlist(): System exception", var14);
                           }

                           Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"SystemException", "enlist", "TransactionAbortedException", var14});
                           throw new TransactionAbortedException();
                        }
                     }
                  } else if (!this.getAutoCommit()) {
                     try {
                        if (!this.isolationLevelChanged()) {
                           this.setConnectionIsolation(uowCoord);
                        }

                        if (tc.isEventEnabled()) {
                           Tr.event(tc, "enlist(): about to Enlist in LocalTran. " + this.toString(), uowCoord);
                        }

                        LTCoord = (LocalTransactionCoordinator)uowCoord;
                        LTCoord.enlistForCleanup(this);
                        this.state = 3;
                        this.transactionState = 2;
                        this.incRef();
                     } catch (IllegalStateException var15) {
                        if (tc.isEventEnabled()) {
                           Tr.event(tc, "enlist: Can't enlist now", var15);
                        }

                        Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"IllegalStateException", "enlist", "IllegalTransactionStateException", var15});
                        throw new IllegalTransactionStateException();
                     } catch (Exception var16) {
                        Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"Exception", "enlist", "TransactionAbortedException", var16});
                        x = new TransactionAbortedException();
                        if (tc.isEntryEnabled()) {
                           Tr.exit(tc, "enlist:", x);
                        }

                        throw x;
                     }
                  }
               }
               break;
            case 3:
               if (this.transactionState == 1 && !this.autoCommit) {
                  try {
                     if (tc.isEventEnabled()) {
                        Tr.event(tc, "enlist(): about to reEnlist in LocalTran. " + this.toString(), uowCoord);
                     }

                     LTCoord = (LocalTransactionCoordinator)uowCoord;
                     LTCoord.enlistForCleanup(this);
                     this.incRef();
                     this.transactionState = 2;
                  } catch (IllegalStateException var10) {
                     if (tc.isEventEnabled()) {
                        Tr.event(tc, "enlist(): Can't enlist now", var10);
                     }

                     Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"IllegalStateException", "enlist", "IllegalTransactionStateException", var10});
                     throw new IllegalTransactionStateException();
                  } catch (LTCSystemException var11) {
                     if (tc.isEventEnabled()) {
                        Tr.event(tc, "enlist(): LTC System exception", var11);
                     }

                     Tr.audit(tc, "MSG_CONM_6014I", new Object[]{"LTCSystemException", "enlist", "TransactionAbortedException", var11});
                     throw new TransactionAbortedException();
                  }
               }
            case 4:
               if (uowCoord != null && (this.transactionState == 3 || this.transactionState == 1) && !uowCoord.equals(this.uowCoord)) {
                  Tr.error(tc, "MSG_CONM_6017E");
                  RuntimeException e = new IllegalStateException("Connection already associated with transaction");
                  if (tc.isEntryEnabled()) {
                     Tr.exit(tc, "enlist:", e);
                  }

                  throw e;
               }
               break;
            default:
               Tr.error(tc, "MSG_CONM_6011E", new Object[]{this.getStateString(), this.pool.getAttributes().getName()});
               Error e = new Error("Illegal ConnectO state: " + this.getStateString());
               if (tc.isEntryEnabled()) {
                  Tr.exit(tc, "enlist:", e);
               }

               throw e;
            }

            if (tc.isEntryEnabled()) {
               Tr.exit(tc, "enlist");
            }

         }
      } else {
         this.transactionState = 0;
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "enlist(): connection enlisted in No Transanaction.", this);
         }

      }
   }

	protected boolean allocate(UOWCoordinator uowCoord) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "allocate", uowCoord);
		}

		synchronized (this) {
			if (this.state != 0) {
				Tr.error(tc, "MSG_CONM_6011E",
						new Object[]{this.getStateString(), this.pool.getAttributes().getName()});
				Error e = new Error("Illegal ConnectO state: " + this.getStateString());
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "allocate:", e);
				}

				throw e;
			}

			this.state = 1;
			this.isolationLevelChanged = false;
			if (this.idleAlarm != null) {
				this.idleAlarm.cancel();
				this.idleAlarm = null;
			}

			this.enlist(uowCoord, true);
		}

		try {
			if (uowCoord != null && uowCoord.isGlobal()) {
				if (this.supports2PC() && this.getPortabilityLayer() instanceof OraclePortabilityLayer) {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "Oracle XAConnection detected, autocommit is already set to false");
					}
				} else if (this.rrsTransactional) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc,
								"Global tran using RRS detected .... setAutoCommit() is skipped when in RRS Global tran.");
					}
				} else {
					this.setAutoCommit(false);
				}
			} else if (this.supports2PC() && this.getPortabilityLayer() instanceof OraclePortabilityLayer) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "Oracle XAConnection detected, autocommit was not set to true for Local Transaction");
				}
			} else {
				this.setAutoCommit(true);
			}
		} catch (SQLException var5) {
			if (this.refCount == 0) {
				this.free();
			}

			Tr.error(tc, "MSG_CONM_6012E", this.pool.getAttributes().getName());
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "allocate: Error", var5);
			}

			throw this.translateException(var5);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "allocate");
		}

		return true;
	}

	protected void free() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "free");
		}

		SQLWarning warnings = null;
		synchronized (this) {
			Error e;
			if (this.refCount != 0) {
				e = new Error("Reference counting error");
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "free():", e);
				}

				throw e;
			}

			if (this.state == 5) {
				return;
			}

			if (this.state != 1) {
				e = new Error("Illegal ConnectO state: " + this.getStateString());
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "free():", e);
				}

				throw e;
			}

			if (this.statementCache != null) {
				this.statementCache.releaseStatements();
			}

			if (this.pool.getIdleTimeoutInMillis() > 0) {
				this.idleAlarm = AlarmManager.create((long) this.pool.getIdleTimeoutInMillis(), this, IDLE_ALARM);
			}

			this.state = 0;
			this.canAddListener = true;
		}

		try {
			warnings = this.connection.getWarnings();
		} catch (SQLException var6) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "free(): SQLException while getting warnings");
			}
		}

		if (this.cleanwarning || warnings != null) {
			try {
				this.connection.clearWarnings();
			} catch (SQLException var5) {
				;
			}

			this.cleanwarning = false;
		}

		this.pool.returnConnection(this);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "free");
		}

	}

	protected void checkForOrphan() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkForOrphan");
		}

		int initialState = true;
		int initialState;
		synchronized (this) {
			if (!this.orphaned) {
				if (this.numInUse == 0) {
					this.orphaned = true;
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "checkForOrphan");
				}

				return;
			}

			this.orphaned = false;
			initialState = this.state;
		}

		switch (initialState) {
			case 0 :
			case 2 :
			case 3 :
			case 4 :
			case 5 :
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "checkForOrphan(): ignore OrphanTimeout alarm", this);
				}
				break;
			case 1 :
				CMPropertiesImpl cmPropImpl = (CMPropertiesImpl) this.pool.getAttributes();
				if (cmPropImpl.isDiagOptionEnabled(1 | 2)) {
					if (this.tracer != null && cmPropImpl.isDiagOptionEnabled(2)) {
						Tr.warning(tc, "MSG_CONM_6020W",
								new Object[]{this.pool.getAttributes().getName(), this.tracer});
					} else {
						Tr.warning(tc, "MSG_CONM_6027W",
								new Object[]{"diagOptions", new Integer(2), this.pool.getAttributes().getName()});
					}
				}

				this.fireOrphanTimeoutEvent();
				break;
			default :
				IllegalStateException e = new IllegalStateException(this.getStateString());
				if (tc.isEventEnabled()) {
					Tr.event(tc, "checkForOrphan(): Illegal state", e);
				}

				throw e;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "checkForOrphan");
		}

	}

	protected void checkForAged() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkForAged");
		}

		if (this.aged == 0) {
			this.aged = 1;
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "checkForAged - Marked Aged");
			}

		} else {
			int initialState = this.state;
			switch (initialState) {
				case 0 :
					this.fireConnectionAgedTimeout();
					break;
				case 1 :
				case 2 :
				case 3 :
				case 4 :
					this.aged = -1;
					break;
				case 5 :
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "checkForAged(): ignore AgedTimeout alarm", this);
					}
					break;
				default :
					IllegalStateException e = new IllegalStateException(this.getStateString());
					if (tc.isEventEnabled()) {
						Tr.event(tc, "checkForAged): Illegal state", e);
					}

					throw e;
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "checkForAged");
			}

		}
	}

	protected void destroy() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy");
		}

		boolean needJTSRollback = false;
		synchronized (this) {
			Vector l = (Vector) this.listeners.clone();
			if (tc.isEventEnabled()) {
				Tr.event(tc, ": number of listeners " + l.size());
			}

			int initialState;
			for (initialState = 0; initialState < l.size(); ++initialState) {
				((ConnectOEventListener) l.elementAt(initialState)).setDestroyed(this);
			}

			if (this.xaConnection != null && this.transactionState == 3 && this.supports2PC()) {
				try {
					new CMXAResourceImpl(this.xaConnection.getXAResource(), this);
					if (tc.isEventEnabled()) {
						Tr.event(tc, "destroy(): about to delist from GlobalTran. ", this.uowCoord);
					}

					if (this.state == 3) {
						this.decRef();
					}
				} catch (SQLException var11) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "destroy(): failed during delist from GlobalTran", var11);
					}

					Tr.warning(tc, "MSG_CONM_6002W", var11);
				}
			} else if (this.transactionState == 2) {
				try {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "destroy(): about to delist from LocalTran. ", this.uowCoord);
					}

					LocalTransactionCoordinator LTCoord = (LocalTransactionCoordinator) this.uowCoord;
					LTCoord.delistFromCleanup(this);
					this.decRef();
				} catch (SQLException var10) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "destroy(): failed during delist from LocalTran", var10);
					}

					Tr.warning(tc, "MSG_CONM_7016W", var10);
				}
			} else if (this.transactionState == 3 && !this.supports2PC()) {
				try {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "destroy(): about to delist from Global Tran. ", this.uowCoord);
					}

					this.decRef();
				} catch (SQLException var12) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "destroy(): failed during delist from LocalTran", var12);
					}

					Tr.warning(tc, "MSG_CONM_7016W", var12);
				}
			}

			initialState = this.state;
			this.state = 5;
			switch (initialState) {
				case 1 :
					if (tc.isEventEnabled()) {
						Tr.event(tc, "destroy: ALLOCATED");
					}

					if (this.connection != null) {
						try {
							this.connection.rollback();
						} catch (SQLException var13) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "destroy(): failed during rollback of connection. ", var13);
							}
						}
					}
				case 0 :
					if (tc.isEventEnabled()) {
						Tr.event(tc, "destroy: FREE");
					}

					this.destroyFinally();
					break;
				case 2 :
					if (tc.isEventEnabled()) {
						Tr.event(tc, "destroy: ALLOCATED_REG_SYNC");
					}
				case 3 :
					if (tc.isEventEnabled()) {
						Tr.event(tc, "destroy: ALLOCATED_TX");
					}
				case 4 :
					if (tc.isEventEnabled()) {
						Tr.event(tc, "destroy: PREPARING");
					}

					needJTSRollback = true;
					break;
				case 5 :
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "destroy(): Already destroyed");
					}

					return;
				default :
					Error e = new Error("Illegal ConnectO state: " + this.getStateString());
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "destroy(): Illegal state", e);
					}

					throw e;
			}
		}

		if (needJTSRollback) {
			try {
				if (this.isGlobalCoordinator) {
					TransactionManagerFactory.getTransactionManager().getTransaction().setRollbackOnly();
				} else {
					((LocalTransactionCoordinator) this.uowCoord).setRollbackOnly();
				}
			} catch (Exception var9) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "destroy(): Exception from rollback_only", var9);
				}
			}
		}

		if (this.xaConnection != null) {
			try {
				this.xaConnection.close();
			} catch (SQLException var8) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "destroy(): Exception closing XAConnection", var8);
				}
			}

			this.xaConnection = null;
		}

		if (this.pooledConnection != null) {
			try {
				this.pooledConnection.close();
			} catch (SQLException var7) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "destroy(): Exception closing PooledConnection", var7);
				}
			}

			this.pooledConnection = null;
		}

		this.fireConnectionDestroyed();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "destroy");
		}

	}

	final String getUsername() {
		return this.username;
	}

	final String getPassword() {
		return this.password;
	}

	public final synchronized void preInvoke(boolean enlist) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "preInvoke: " + this.toString(), new Boolean(enlist));
		}

		this.incRef();
		this.orphaned = false;
		this.incNumInUse();
		switch (this.state) {
			case 1 :
			case 2 :
			case 3 :
			case 4 :
				this.enlist();
				if (!this.autoCommit) {
					this.dirty = true;
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "preInvoke");
				}

				return;
			default :
				IllegalStateException e = new IllegalStateException(this.getStateString());
				if (tc.isEventEnabled()) {
					Tr.event(tc, "preInvoke(): Illegal state", e);
				}

				throw e;
		}
	}

	public final void postInvoke(SQLException e) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "postInvoke", e);
		}

		this.decRef();
		this.orphaned = false;
		this.decNumInUse();
		if (e != null) {
			if (e instanceof SQLWarning) {
				this.cleanwarning = true;
			} else if (e instanceof SQLException) {
				try {
					if (this.autoCommit && this.getPortabilityLayer() instanceof OraclePortabilityLayer) {
						this.connection.rollback();
					}
				} catch (SQLException var3) {
					;
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "postInvoke");
		}

	}

	public final void alarm(Object type) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "alarm", type);
		}

		if (type == IDLE_ALARM) {
			synchronized (this) {
				this.idleAlarm = null;
				switch (this.state) {
					case 0 :
						break;
					default :
						return;
				}
			}

			this.fireConnectionIdleTimeout();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "alarm");
		}

	}

	public synchronized void beforeCompletion() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "beforeCompletion");
		}

		switch (this.state) {
			case 1 :
			case 2 :
			case 3 :
			case 5 :
				this.state = 4;
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "beforeCompletion");
				}

				return;
			case 4 :
			default :
				Tr.error(tc, "MSG_CONM_6011E",
						new Object[]{this.getStateString(), this.pool.getAttributes().getName()});
				Error e = new Error("Illegal ConnectO state: " + this.getStateString());
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "beforeCompletion():", e);
				}

				throw e;
		}
	}

	public void afterCompletion(int status) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "afterCompletion", new Integer(status));
		}

		this.fireConnectionTxComplete(status, this.uowCoord);
		synchronized (this) {
			label73 : {
				switch (this.state) {
					case 2 :
						this.uowCoord = null;
						this.isGlobalCoordinator = false;
						this.dirty = false;
						this.state = 1;
						break label73;
					case 3 :
						if (status != 4) {
							Tr.error(tc, "MSG_CONM_6011E",
									new Object[]{this.getStateString(), this.pool.getAttributes().getName()});
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "afterCompletion(): illegal state for commit");
							}

							throw new Error("Illegal ConnectO state" + this.getStateString());
						}
					case 4 :
						break;
					case 5 :
						this.uowCoord = null;
						this.destroyFinally();
						break label73;
					default :
						Tr.error(tc, "MSG_CONM_6011E",
								new Object[]{this.getStateString(), this.pool.getAttributes().getName()});
						Error e = new Error("Illegal ConnectO state: " + this.getStateString());
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "afterCompletion():", e);
						}

						throw e;
				}

				this.state = 1;
				this.uowCoord = null;
				this.isGlobalCoordinator = false;
				this.dirty = false;
				if (this.supports2PC() && this.transactionState == 3) {
					try {
						this.decRef();
					} catch (SQLException var6) {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "afterCompletion():", var6);
						}
					}
				}

				this.transactionState = 0;
			}
		}

		try {
			this.decRef();
		} catch (SQLException var5) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "afterCompletion():", var5);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "afterCompletion");
		}

	}

	public final Connection getPhysicalConnection() {
		return this.connection;
	}

	public void unilateralCommit() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "unilateralCommit");
		}

		if (this.supports2PC() && this.transactionState == 3) {
			Tr.error(tc, "MSG_CONM_6018E");
			if (tc.isEventEnabled()) {
				Tr.event(tc, "unilateralCommit(): unilateralCommit not allowed for 2PC global tran.");
			}

			throw new SQLException("Illegal operation");
		} else {
			try {
				synchronized (this) {
					switch (this.state) {
						case 1 :
						case 2 :
						case 4 :
							throw new IllegalStateException("Illegal operation for state " + this.getStateString());
						case 3 :
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "unilateralCommit(): commiting connection");
							}

							this.connection.commit();
							break;
						default :
							throw new Error("Illegal ConnectO state: " + this.getStateString());
					}
				}
			} catch (SQLException var5) {
				try {
					((Transaction) this.uowCoord).setRollbackOnly();
				} catch (SystemException var3) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "unilateralCommit(): Exception from setRollbackOnly", var3);
					}
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "unilateralCommit(): Exception committing connection", var5);
				}

				throw var5;
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "unilateralCommit");
			}

		}
	}

	public final PortabilityLayerExt getPortabilityLayer() throws SQLException {
		return this.pool.getPortabilityLayer();
	}

	public final SQLException translateException(SQLException e) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "translateException");
		}

		SQLException x = this.pool.getErrorMap().translateException(e);
		if (x instanceof StaleConnectionException) {
			if (!this.alreadyDestroyed) {
				ConnectionPool var3 = this.pool;
				synchronized (this.pool) {
					if (this.maybeStale) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Connection was marked stale. Destroying");
						}

						this.pool.destroyConnection(this);
					} else {
						if (tc.isEventEnabled()) {
							Tr.event(tc, "StaleConnectionException caught - purging the pool");
						}

						this.pool.destroyConnection(this);
						this.pool.destroyAllFreeConnections();
					}
				}
			} else if (tc.isEventEnabled()) {
				Tr.event(tc, "Connection was already in process of destruction, skipped destroy calls");
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "translateException");
		}

		return x;
	}

	public final String getColumnTypeSpec(int type) throws SQLException {
		return ((PortabilityLayer) this.pool.getPortabilityLayer()).getColumnTypeSpec(type);
	}

	public final String addRowLockHint(String sql) {
		return ((PortabilityLayer) this.pool.getPortabilityLayer()).addRowLockHint(sql);
	}

	public final Statement createStatement(int type, int concurrency) throws SQLException {
		return this.connection.createStatement(type, concurrency);
	}

	public final PreparedStatement prepareStatement(String sql, int type, int concurrency) throws SQLException {
		CMPropertiesImpl cmProps = (CMPropertiesImpl) ((CMPropertiesImpl) this.pool.getAttributes());
		if (cmProps.getMaxStatementCacheSize() > 0) {
			synchronized (this) {
				if (this.statementCache == null) {
					this.statementCache = this.pool.createStatementCache(this.connection, this);
				}
			}

			return this.statementCache.prepareStatement(sql, type, concurrency);
		} else {
			return type == 1003 && concurrency == 1007
					? this.connection.prepareStatement(sql)
					: this.connection.prepareStatement(sql, type, concurrency);
		}
	}

	public final CallableStatement prepareCall(String sql, int type, int concurrency) throws SQLException {
		return this.connection.prepareCall(sql, type, concurrency);
	}

	public final Map<String, Class<?>> getTypeMap() throws SQLException {
		return this.connection.getTypeMap();
	}

	public final void setTypeMap(Map<String, Class<?>> types) throws SQLException {
		this.connection.setTypeMap(types);
	}

	public final Statement createStatement() throws SQLException {
		return this.connection.createStatement();
	}

	public final PreparedStatement prepareStatement(String sql) throws SQLException {
		return this.prepareStatement(sql, 1003, 1007);
	}

	public final CallableStatement prepareCall(String sql) throws SQLException {
		return this.connection.prepareCall(sql);
	}

	public final String nativeSQL(String sql) throws SQLException {
		return this.connection.nativeSQL(sql);
	}

	public final synchronized void setAutoCommit(boolean autoCommit) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setAutoCommit", new Boolean(autoCommit));
		}

		boolean originalAutoCommit = this.autoCommit;
		IllegalStateException e;
		switch (this.state) {
			case 3 :
				if (autoCommit && this.transactionState == 3) {
					e = new IllegalStateException("Cannot enable auto commit within JTS transaction");
					if (tc.isEventEnabled()) {
						Tr.event(tc, "setAutoCommit: Illegal state", e);
					}

					throw e;
				}
			case 1 :
			case 2 :
				if (autoCommit && this.transactionState == 5) {
					e = new IllegalStateException("Cannot enable auto commit within RRS Global transaction");
					if (tc.isEventEnabled()) {
						Tr.event(tc, "setAutoCommit: Illegal state", e);
					}

					throw e;
				}

				if (this.autoCommit != autoCommit) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "setAutoCommit(): changing autoCommit to:", new Boolean(autoCommit));
					}

					this.connection.setAutoCommit(autoCommit);
					this.autoCommit = autoCommit;
					this.dirty = false;
				}

				if (!originalAutoCommit && autoCommit && this.transactionState == 2) {
					this.dirty = false;
					if (tc.isEventEnabled()) {
						Tr.event(tc, "setAutoCommit(): about to delist from LocalTran. " + this.toString(),
								this.uowCoord);
					}

					LocalTransactionCoordinator LTCoord = (LocalTransactionCoordinator) this.uowCoord;
					LTCoord.delistFromCleanup(this);
					this.decRef();
					this.transactionState = 1;
					if (this.state == 3) {
						this.state = 2;
					}

					if (tc.isEventEnabled()) {
						Tr.event(tc, "delisted ConnectO from local tran", this);
					}
				}

				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "setAutoCommit");
				}

				return;
			default :
				e = new IllegalStateException(this.getStateString());
				if (tc.isEventEnabled()) {
					Tr.event(tc, "setAutoCommit: Illegal state", e);
				}

				throw e;
		}
	}

	public final boolean getAutoCommit() throws SQLException {
		return this.autoCommit;
	}

	public final synchronized void commit() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "commit - connection local");
		}

		switch (this.state) {
			case 1 :
			case 2 :
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "commiting connection");
				}

				try {
					this.connection.commit();
					break;
				} catch (SQLException var16) {
					if (this.supports2PC() && this.getPortabilityLayer() instanceof OraclePortabilityLayer) {
						if (tc.isEventEnabled()) {
							Tr.event(tc, "It is illegal to use a connection commit with an Oracle XAConnection");
						}

						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "commit(): Error", var16);
						}

						throw new IllegalConnectionUseException();
					}

					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "commit(): Error", var16);
					}

					throw this.translateException(var16);
				} finally {
					this.dirty = false;
					this.isolationLevelChanged = false;
				}
			case 3 :
				if (this.transactionState != 1 && this.transactionState != 2) {
					throw new IllegalStateException("Illegal operation: tried to commit connection in global tran");
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "commiting connection");
				}

				try {
					this.connection.commit();
				} catch (SQLException var20) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "commit(): Error", var20);
					}

					throw this.translateException(var20);
				} finally {
					this.dirty = false;
					this.isolationLevelChanged = false;
				}

				try {
					if (this.transactionState == 2) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "commit(): about to delist from LocalTran. " + this.toString(), this.uowCoord);
						}

						LocalTransactionCoordinator LTCoord = (LocalTransactionCoordinator) this.uowCoord;
						LTCoord.delistFromCleanup(this);
						this.decRef();
						this.transactionState = 1;
						this.state = 2;
						if (tc.isEventEnabled()) {
							Tr.event(tc, "delisted ConnectO from local tran", this);
						}
					}
					break;
				} catch (IllegalStateException var18) {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "delist: Can't delist now", var18);
					}

					throw new IllegalTransactionStateException();
				} catch (Exception var19) {
					Tr.error(tc, "MSG_CONM_7017E", var19);
					if (tc.isEventEnabled()) {
						Tr.event(tc, "Exception on delistResource for Local Tran", var19);
					}

					SQLException x = new TransactionAbortedException();
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist:", x);
					}

					throw x;
				}
			default :
				throw new IllegalStateException("Illegal operation");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "commit");
		}

	}

	public final synchronized void rollback() throws SQLException {
		switch (this.state) {
			case 1 :
			case 2 :
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "rolling back connection");
				}

				try {
					this.connection.rollback();
					break;
				} catch (SQLException var20) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "rollback: Error", var20);
					}

					throw this.translateException(var20);
				} finally {
					this.dirty = false;
					this.isolationLevelChanged = false;
				}
			case 3 :
				if (this.transactionState != 1 && this.transactionState != 2) {
					throw new IllegalStateException("Illegal operation: tried to commit connection in global tran");
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "rolling back connection");
				}

				try {
					this.connection.rollback();
				} catch (SQLException var16) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "rollback: Error", var16);
					}

					throw this.translateException(var16);
				} finally {
					this.dirty = false;
					this.isolationLevelChanged = false;
				}

				try {
					if (this.transactionState == 2) {
						if (tc.isEventEnabled()) {
							Tr.event(tc, "rollback(): about to delist from LocalTran. " + this.toString(),
									this.uowCoord);
						}

						LocalTransactionCoordinator LTCoord = (LocalTransactionCoordinator) this.uowCoord;
						LTCoord.delistFromCleanup(this);
						this.decRef();
						this.transactionState = 1;
						this.state = 2;
						if (tc.isEventEnabled()) {
							Tr.event(tc, "delisted ConnectO from local tran", this);
						}
					}
					break;
				} catch (IllegalStateException var18) {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "delist: Can't delist now", var18);
					}

					throw new IllegalTransactionStateException();
				} catch (Exception var19) {
					Tr.error(tc, "MSG_CONM_7017E", var19);
					if (tc.isEventEnabled()) {
						Tr.event(tc, "Exception on delistResource for Local Tran", var19);
					}

					SQLException x = new TransactionAbortedException();
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "enlist:", x);
					}

					throw x;
				}
			default :
				throw new IllegalStateException("Illegal operation");
		}

	}

	public final void close() {
		throw new Error("Illegal call to ConnectO.close");
	}

	public final boolean isClosed() throws SQLException {
		return this.connection.isClosed();
	}

	public final DatabaseMetaData getMetaData() throws SQLException {
		return this.connection.getMetaData();
	}

	public final void setReadOnly(boolean readOnly) throws SQLException {
		if (!readOnly) {
			this.readOnlyChanged = false;
		} else {
			this.readOnlyChanged = true;
		}

		this.connection.setReadOnly(readOnly);
	}

	public final boolean isReadOnly() throws SQLException {
		return this.connection.isReadOnly();
	}

	public final void setCatalog(String catalog) throws SQLException {
		this.connection.setCatalog(catalog);
	}

	public final String getCatalog() throws SQLException {
		return this.connection.getCatalog();
	}

	public final synchronized void setTransactionIsolation(int level) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setTransactionIsolation", new Integer(level));
		}

		this.isolationLevelChanged = true;
		switch (this.state) {
			case 1 :
			case 2 :
				if (this.isolationLevel != level) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Setting isolation level");
					}

					((PortabilityLayer) this.pool.getPortabilityLayer()).setTransactionIsolation(this.connection,
							level);
					this.isolationLevel = level;
				}
				break;
			case 3 :
				if (this.isolationLevel != level) {
					if (this.transactionState != 1) {
						throw new IllegalIsolationLevelChangeException();
					}

					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Setting isolation level");
					}

					((PortabilityLayer) this.pool.getPortabilityLayer()).setTransactionIsolation(this.connection,
							level);
					this.isolationLevel = level;
				}
				break;
			default :
				IllegalStateException e = new IllegalStateException(this.getStateString());
				if (tc.isEventEnabled()) {
					Tr.event(tc, "setTransactionIsolation: Illegal state", e);
				}

				throw e;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setTransactionIsolation");
		}

	}

	public final int getTransactionIsolation() throws SQLException {
		return this.isolationLevel;
	}

	public final SQLWarning getWarnings() throws SQLException {
		return this.connection.getWarnings();
	}

	public final void clearWarnings() throws SQLException {
		this.connection.clearWarnings();
	}

	private void setConnectionIsolation(Object coord) throws SQLException {
		try {
			if (ejbContainer == null) {
				ejbContainer = (EJBContainer) (new InitialContext()).lookup("services:websphere/EJBContainer");
			}

			int level = ejbContainer.getIsolationLevel((SynchronizationRegistryUOWScope) this.uowCoord,
					this.getPortabilityLayer());
			this.setTransactionIsolation(level);
		} catch (NamingException var3) {
			throw new SQLException(var3.getMessage());
		}
	}

	protected boolean isolationLevelChanged() {
		return this.isolationLevelChanged;
	}

	protected boolean isReadOnlyChanged() {
		return this.readOnlyChanged;
	}

	private final void destroyFinally() {
		if (this.idleAlarm != null) {
			this.idleAlarm.cancel();
			this.idleAlarm = null;
		}

		if (this.statementCache != null) {
			this.statementCache.destroy();
			this.statementCache = null;
		}

		if (this.connection != null) {
			try {
				this.connection.close();
			} catch (SQLException var2) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "Exception closing connection", var2);
				}
			}

			this.connection = null;
		}

	}

	private final void fireConnectionDestroyed() {
		this.canAddListener = false;
		Vector l = (Vector) this.listeners.clone();

		for (int i = 0; i < l.size(); ++i) {
			((ConnectOEventListener) l.elementAt(i)).connectionDestroyed(this);
		}

		this.listeners.removeAllElements();
		this.canAddListener = true;
	}

	private final void fireConnectionEnlisted(Object coord) {
		for (int i = 0; i < this.listeners.size(); ++i) {
			((ConnectOEventListener) this.listeners.elementAt(i)).connectionEnlisted(this, coord);
		}

	}

	private final void fireConnectionIdleTimeout() {
		for (int i = 0; i < this.listeners.size(); ++i) {
			boolean destroyed = ((ConnectOEventListener) this.listeners.elementAt(i)).connectionIdleTimeout(this);
			if (!destroyed) {
				this.idleAlarm = AlarmManager.create((long) this.pool.getIdleTimeoutInMillis(), this, IDLE_ALARM);
			}
		}

	}

	private final void fireConnectionAgedTimeout() {
		for (int i = 0; i < this.listeners.size(); ++i) {
			boolean var2 = ((ConnectOEventListener) this.listeners.elementAt(i)).connectionAgedTimeout(this);
		}

	}

	private final void fireConnectionTxComplete(int status, Object tx) {
		this.canAddListener = false;
		Vector l = (Vector) this.listeners.clone();

		for (int i = 0; i < l.size(); ++i) {
			((ConnectOEventListener) l.elementAt(i)).connectionTxComplete(this, status, tx);
		}

		this.canAddListener = true;
	}

	private final void fireOrphanTimeoutEvent() {
		this.canAddListener = false;
		Vector l = (Vector) this.listeners.clone();

		for (int i = 0; i < l.size(); ++i) {
			((ConnectOEventListener) l.elementAt(i)).connectionOrphaned(this);
		}

		this.canAddListener = true;
	}

	public boolean validate() {
		boolean returnValue = true;
		String theSQL = ((CMPropertiesImpl) this.pool.getAttributes()).getValidateSQL();
		ResultSet rs = null;
		Statement stmt = null;

		try {
			stmt = this.connection.createStatement();
			rs = stmt.executeQuery(theSQL);
			if (!this.connection.getAutoCommit()) {
				this.connection.commit();
			}
		} catch (SQLException var18) {
			Tr.warning(tc, "MSG_CONM_6019W", new Object[]{this.pool.getAttributes().getName(), var18});
			returnValue = false;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException var17) {
				;
			}

			try {
				if (stmt != null) {
					stmt.close();
				}
			} catch (SQLException var16) {
				;
			}

		}

		return returnValue;
	}

	public void setMaybeStale(boolean value) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setMaybeStale", new Boolean(value));
		}

		this.maybeStale = value;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setMaybeStale", new Boolean(this.maybeStale));
		}

	}

	public final int prepare(Xid xid) throws XAException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "prepare", xid);
		}

		Tr.warning(tc, "MSG_CONM_6000W", this.pool.getAttributes().getName());
		XAException e = new XAException(103);
		FFDCFilter.processException(e, "com.ibm.ejs.cm.pool.ConnectO.prepare", "3383", this);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "prepare", e);
		}

		throw e;
	}

	public final synchronized void commit(Xid xid, boolean onePhase) throws XAException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "commit", new Object[]{xid, new Boolean(onePhase)});
		}

		XAException e;
		if (this.xid != null && !xid.equals(this.xid)) {
			e = new XAException(-4);
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Error: Connection is already involved in different transaction.", e);
			}

			throw e;
		} else if (!onePhase) {
			e = new XAException(-6);
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Illegal 2PC commit attempt", e);
			}

			throw e;
		} else if (this.state != 4) {
			Error e = new Error("Illegal ConnectO state: " + this.getStateString());
			if (tc.isEventEnabled()) {
				Tr.event(tc, "commit:", e);
			}

			throw e;
		} else {
			try {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "Performing 1PC commit");
				}

				this.connection.commit();
			} catch (SQLException var11) {
				if (tc.isEventEnabled()) {
					Tr.event(tc, "1PC commit failed", var11);
				}

				throw new XAException(100);
			} finally {
				this.xid = null;
				this.dirty = false;

				try {
					this.decRef();
				} catch (SQLException var10) {
					if (tc.isEventEnabled()) {
						Tr.event(tc, "decRef failed", var10);
					}
				}

			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "commit");
			}

		}
	}

	public final synchronized void rollback(Xid xid) throws XAException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "rollback", xid);
		}

		if (this.xid != null && !xid.equals(this.xid)) {
			XAException e = new XAException(-4);
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Mismatched Xid", e);
			}

			throw e;
		} else {
			this.xid = null;
			switch (this.state) {
				case 3 :
				case 4 :
				case 5 :
					if (this.refCount == 0) {
						try {
							if (tc.isEventEnabled()) {
								Tr.event(tc, "Performing 1PC rollback");
							}

							this.connection.rollback();
						} catch (SQLException var8) {
							if (tc.isEventEnabled()) {
								Tr.event(tc, "Exception rolling back connection", var8);
							}
						} finally {
							this.dirty = false;
						}
					} else {
						if (tc.isEventEnabled()) {
							Tr.event(tc, "Calls outstanding: delaying 1PC rollback");
						}

						this.rolledBack = true;
					}

					try {
						this.decRef();
					} catch (SQLException var7) {
						if (tc.isEventEnabled()) {
							Tr.event(tc, "decRef Exception rolling back connection", var7);
						}
					}

					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "rollback");
					}

					return;
				default :
					Error e = new Error("Illegal ConnectO state: " + this.getStateString());
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "rollback:", e);
					}

					throw e;
			}
		}
	}

	public final void start(Xid xid, int flags) throws XAException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "start", new Object[]{xid, new Integer(flags)});
		}

		if (this.state != 2) {
			Error e = new Error("Illegal ConnectO state: " + this.getStateString());
			if (tc.isEventEnabled()) {
				Tr.event(tc, "start:", e);
			}

			throw e;
		} else if (this.xid != null) {
			XAException e = new XAException(-6);
			if (tc.isEventEnabled()) {
				Tr.event(tc, "start: Already associated with tx", e);
			}

			throw e;
		} else {
			this.xid = xid;
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "start");
			}

		}
	}

	public final void end(Xid xid, int flags) throws XAException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "end", new Object[]{xid, new Integer(flags)});
		}

		if (this.state != 4 && this.state != 3) {
			Error e = new Error("Illegal ConnectO state: " + this.getStateString());
			if (tc.isEventEnabled()) {
				Tr.event(tc, "end:", e);
			}

			throw e;
		} else if (!xid.equals(this.xid)) {
			XAException e = new XAException(-4);
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Mismatched Xid", e);
			}

			throw e;
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "end");
			}

		}
	}

	public final void forget(Xid xid) throws XAException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "forget", xid);
		}

		if (this.state != 3) {
			Error e = new Error("Illegal ConnectO state: " + this.getStateString());
			if (tc.isEventEnabled()) {
				Tr.event(tc, "forget:", e);
			}

			throw e;
		} else if (!xid.equals(this.xid)) {
			XAException e = new XAException(-4);
			if (tc.isEventEnabled()) {
				Tr.event(tc, "Mismatched Xid", e);
			}

			throw e;
		} else {
			this.xid = null;
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "forget");
			}

		}
	}

	public final Xid[] recover(int flag) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "recover", new Integer(flag));
			Tr.exit(tc, "recover");
		}

		return new Xid[0];
	}

	public final boolean isSameRM(XAResource xares) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isSameRM", xares);
		}

		boolean result = xares == this;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isSameRM", new Boolean(result));
		}

		return result;
	}

	public final int getTransactionTimeout() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTransactionTimeout");
			Tr.exit(tc, "getTransactionTimeout", new Integer(0));
		}

		return 0;
	}

	public final boolean setTransactionTimeout(int seconds) {
		return false;
	}

	public String getResourceName() {
		return this.pool.getAttributes().getName();
	}

	public void abort(Executor executor) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public int getNetworkTimeout() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public String getSchema() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public void setSchema(String schema) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	void setTracer(String message) {
		this.tracer = new ConnectionManagerTracer(message);
	}

	void setTracer() {
		this.tracer = new ConnectionManagerTracer();
	}

	void unsetTracer() {
		this.tracer = null;
	}

	ConnectionManagerTracer getTracer() {
		return this.tracer;
	}
}