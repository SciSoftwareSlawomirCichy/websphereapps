package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

public class PreparedStatementProxy extends StatementProxy implements PreparedStatement {
	private static final TraceNLS NLS = TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages");
	private static final TraceComponent tc = Tr.register(PreparedStatementProxy.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setAsciiStream(int, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setAsciiStream(int, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBinaryStream(int, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBinaryStream(int, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBlob(int, InputStream)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setBlob(int, InputStream, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setCharacterStream(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setCharacterStream(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setClob(int parameterIndex, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setClob(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setClob(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNCharacterStream(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNCharacterStream(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNClob(int parameterIndex, NClob value) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNClob(int, NClob)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNClob(int parameterIndex, Reader reader) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNClob(int, Reader)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNClob(int, Reader, long)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setNString(int parameterIndex, String value) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setNString(int, String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setRowId(int parameterIndex, RowId x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setRowId(int, RowId)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "setSQLXML(int, SQLXML)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	PreparedStatementProxy(ConnectionProxy parent, PreparedStatement statement) {
		super(parent, statement);
	}

	public boolean execute() throws SQLException {
		return this.executeCommon((String) null, true);
	}

	public ResultSet executeQuery() throws SQLException {
		return this.executeQueryCommon((String) null, true);
	}

	public int executeUpdate() throws SQLException {
		return this.executeUpdateCommon((String) null, true);
	}

	public void addBatch() throws SQLException {
		((PreparedStatement) this.getStatement()).addBatch();
	}

	public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
		((PreparedStatement) this.getStatement()).setCharacterStream(parameterIndex, reader, length);
	}

	public void setRef(int i, Ref x) throws SQLException {
		((PreparedStatement) this.getStatement()).setRef(i, x);
	}

	public void setBlob(int i, Blob x) throws SQLException {
		((PreparedStatement) this.getStatement()).setBlob(i, x);
	}

	public void setClob(int i, Clob x) throws SQLException {
		((PreparedStatement) this.getStatement()).setClob(i, x);
	}

	public void setArray(int i, Array x) throws SQLException {
		((PreparedStatement) this.getStatement()).setArray(i, x);
	}

	public ResultSetMetaData getMetaData() throws SQLException {
		return ((PreparedStatement) this.getStatement()).getMetaData();
	}

	public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
		((PortabilityLayer) ((ConnectionProxy) this.getParent()).getConnection().getPool().getPortabilityLayer())
				.setDate((PreparedStatement) this.getStatement(), parameterIndex, x, cal);
	}

	public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
		((PortabilityLayer) ((ConnectionProxy) this.getParent()).getConnection().getPool().getPortabilityLayer())
				.setTime((PreparedStatement) this.getStatement(), parameterIndex, x, cal);
	}

	public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
		if (x == null) {
			((PreparedStatement) this.getStatement()).setNull(parameterIndex, 93);
		} else {
			((PreparedStatement) this.getStatement()).setTimestamp(parameterIndex, x, cal);
		}

	}

	public void setNull(int paramIndex, int sqlType, String typeName) throws SQLException {
		((PreparedStatement) this.getStatement()).setNull(paramIndex, sqlType, typeName);
	}

	public void setNull(int parameterIndex, int sqlType) throws SQLException {
		((PreparedStatement) this.getStatement()).setNull(parameterIndex, sqlType);
	}

	public void setBoolean(int parameterIndex, boolean x) throws SQLException {
		((PreparedStatement) this.getStatement()).setBoolean(parameterIndex, x);
	}

	public void setByte(int parameterIndex, byte x) throws SQLException {
		((PreparedStatement) this.getStatement()).setByte(parameterIndex, x);
	}

	public void setShort(int parameterIndex, short x) throws SQLException {
		((PreparedStatement) this.getStatement()).setShort(parameterIndex, x);
	}

	public void setInt(int parameterIndex, int x) throws SQLException {
		((PreparedStatement) this.getStatement()).setInt(parameterIndex, x);
	}

	public void setLong(int parameterIndex, long x) throws SQLException {
		((PreparedStatement) this.getStatement()).setLong(parameterIndex, x);
	}

	public void setFloat(int parameterIndex, float x) throws SQLException {
		((PreparedStatement) this.getStatement()).setFloat(parameterIndex, x);
	}

	public void setDouble(int parameterIndex, double x) throws SQLException {
		((PreparedStatement) this.getStatement()).setDouble(parameterIndex, x);
	}

	public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
		((PreparedStatement) this.getStatement()).setBigDecimal(parameterIndex, x);
	}

	public void setString(int parameterIndex, String x) throws SQLException {
		((PreparedStatement) this.getStatement()).setString(parameterIndex, x);
	}

	public void setBytes(int parameterIndex, byte[] x) throws SQLException {
		((PreparedStatement) this.getStatement()).setBytes(parameterIndex, x);
	}

	public void setDate(int parameterIndex, Date x) throws SQLException {
		((PortabilityLayer) ((ConnectionProxy) this.getParent()).getConnection().getPool().getPortabilityLayer())
				.setDate((PreparedStatement) this.getStatement(), parameterIndex, x);
	}

	public void setTime(int parameterIndex, Time x) throws SQLException {
		((PortabilityLayer) ((ConnectionProxy) this.getParent()).getConnection().getPool().getPortabilityLayer())
				.setTime((PreparedStatement) this.getStatement(), parameterIndex, x);
	}

	public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
		if (x == null) {
			((PreparedStatement) this.getStatement()).setNull(parameterIndex, 93);
		} else {
			((PreparedStatement) this.getStatement()).setTimestamp(parameterIndex, x);
		}

	}

	public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
		((PreparedStatement) this.getStatement()).setAsciiStream(parameterIndex, x, length);
	}

	public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
		((PreparedStatement) this.getStatement()).setUnicodeStream(parameterIndex, x, length);
	}

	public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
		((PreparedStatement) this.getStatement()).setBinaryStream(parameterIndex, x, length);
	}

	public void clearParameters() throws SQLException {
		((PreparedStatement) this.getStatement()).clearParameters();
	}

	public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
		((PreparedStatement) this.getStatement()).setObject(parameterIndex, x, targetSqlType, scale);
	}

	public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
		((PreparedStatement) this.getStatement()).setObject(parameterIndex, x, targetSqlType);
	}

	public void setObject(int parameterIndex, Object x) throws SQLException {
		((PreparedStatement) this.getStatement()).setObject(parameterIndex, x);
	}
}