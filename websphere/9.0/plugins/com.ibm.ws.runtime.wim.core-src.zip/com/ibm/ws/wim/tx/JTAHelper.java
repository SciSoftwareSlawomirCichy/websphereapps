package com.ibm.ws.wim.tx;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.extensionhelper.ExtensionHelper;
import com.ibm.ws.extensionhelper.TransactionControl;
import com.ibm.ws.extensionhelper.TxHandle;
import com.ibm.ws.extensionhelper.exception.InconsistentTransactionException;
import com.ibm.ws.wim.EnvironmentManager;
import com.ibm.ws.wim.env.ITransactionUtil;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.InvalidTransactionException;
import javax.transaction.SystemException;

public class JTAHelper implements ITransactionUtil {
	private static final String COPYRIGHT_NOTICE;
	private final String className = JTAHelper.class.getName();
	private Logger jtaHelperTrace;
	public final String EXT_HELPER;

	public JTAHelper() {
		this.jtaHelperTrace = WIMLogger.getTraceLogger(this.className);
		this.EXT_HELPER = "services:websphere/ExtensionHelper";
		String var1 = "JTAHelper";
	}

	public Object preinvoke(Object var1, boolean var2, boolean var3) throws Exception {
		return ((TransactionControl) var1).preinvoke(var2, var3);
	}

	public Object getTransactionControl(Object var1, EnvironmentManager var2) {
		String var3 = "getTransactionControl";
		if (this.jtaHelperTrace.isLoggable(Level.FINER)) {
			this.jtaHelperTrace.entering(this.className, var3,
					"inputTxControl = \"" + var1 + "\", inputEnvManager = \"" + var2 + "\"");
		}

		TransactionControl var4 = (TransactionControl) var1;
		if (var1 == null && var2 != null && !var2.isDirectAccessMode()) {
			try {
				InitialContext var5 = new InitialContext();
				ExtensionHelper var6 = (ExtensionHelper) var5.lookup("services:websphere/ExtensionHelper");
				var4 = var6.getTransactionControl();
			} catch (NamingException var7) {
				if (this.jtaHelperTrace.isLoggable(Level.FINE)) {
					this.jtaHelperTrace.logp(Level.SEVERE, this.className, var3, "",
							WIMMessageHelper.generateMsgParms(var7));
				}
			}
		}

		if (this.jtaHelperTrace.isLoggable(Level.FINER)) {
			this.jtaHelperTrace.exiting(this.className, var3, "returnValue = \"" + var4 + "\"");
		}

		return var4;
	}

	public boolean useTransaction(Object var1, EnvironmentManager var2) {
		String var3 = "useTransaction";
		boolean var4 = false;
		if (this.jtaHelperTrace.isLoggable(Level.FINER)) {
			this.jtaHelperTrace.entering(this.className, var3,
					"inputTxControl = \"" + var1 + "\", inputEnvManager = \"" + var2 + "\"");
		}

		var4 = var1 != null && var2 != null && !var2.isDirectAccessMode();
		if (this.jtaHelperTrace.isLoggable(Level.FINER)) {
			this.jtaHelperTrace.exiting(this.className, var3, "returnValue = \"" + var4 + "\"");
		}

		return var4;
	}

	public void closeTransaction(String var1, Object var2, Object var3, boolean var4) {
		String var5 = "closeTransaction";
		if (this.jtaHelperTrace.isLoggable(Level.FINER)) {
			this.jtaHelperTrace.entering(this.className, var5, "inputMethod = \"" + var1 + "\", inControl = \"" + var2
					+ "\", inHandle = \"" + var3 + "\", inputSuccess = \"" + var4 + "\"");
		}

		TransactionControl var6 = (TransactionControl) var2;
		TxHandle var7 = (TxHandle) var3;
		if (var4) {
			try {
				var6.postinvoke(var7);
			} catch (SystemException var9) {
				if (this.jtaHelperTrace.isLoggable(Level.FINE)) {
					this.jtaHelperTrace.logp(Level.SEVERE, this.className, var1, "",
							WIMMessageHelper.generateMsgParms(var9));
				}

				var6.handleException(var7);
			} catch (InvalidTransactionException var10) {
				if (this.jtaHelperTrace.isLoggable(Level.FINE)) {
					this.jtaHelperTrace.logp(Level.SEVERE, this.className, var1, "",
							WIMMessageHelper.generateMsgParms(var10));
				}

				var6.handleException(var7);
			} catch (InconsistentTransactionException var11) {
				if (this.jtaHelperTrace.isLoggable(Level.FINE)) {
					this.jtaHelperTrace.logp(Level.SEVERE, this.className, var1, "",
							WIMMessageHelper.generateMsgParms(var11));
				}

				var6.handleException(var7);
			}
		} else {
			var6.handleException(var7);
		}

		if (this.jtaHelperTrace.isLoggable(Level.FINER)) {
			this.jtaHelperTrace.exiting(this.className, var5);
		}

	}

	public void handleException(Exception var1) throws WIMException, RemoteException {
		String var2 = "handleException";
		if (this.jtaHelperTrace.isLoggable(Level.FINE)) {
			this.jtaHelperTrace.logp(Level.SEVERE, this.className, var2, "", WIMMessageHelper.generateMsgParms(var1));
		}

		if (var1 instanceof WIMException) {
			throw (WIMException) var1;
		} else if (var1 instanceof RemoteException) {
			throw (RemoteException) var1;
		} else {
			throw new WIMException(var1);
		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
	}
}