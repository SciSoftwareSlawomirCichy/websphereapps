package com.ibm.icu.impl;

import com.ibm.icu.impl.ICULocaleService.LocaleKey;
import com.ibm.icu.impl.ICULocaleService.SimpleLocaleKeyFactory;
import com.ibm.icu.impl.ICUService.Factory;
import com.ibm.icu.impl.ICUService.Key;
import com.ibm.icu.util.ULocale;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

public class ICULocaleService extends ICUService {
	private ULocale fallbackLocale;
	private String fallbackLocaleName;

	public ICULocaleService() {
	}

	public ICULocaleService(String name) {
		super(name);
	}

	public Object get(ULocale locale) {
		return this.get(locale, -1, (ULocale[]) null);
	}

	public Object get(ULocale locale, int kind) {
		return this.get(locale, kind, (ULocale[]) null);
	}

	public Object get(ULocale locale, ULocale[] actualReturn) {
		return this.get(locale, -1, actualReturn);
	}

	public Object get(ULocale locale, int kind, ULocale[] actualReturn) {
		Key key = this.createKey(locale, kind);
		if (actualReturn == null) {
			return this.getKey(key);
		} else {
			String[] temp = new String[1];
			Object result = this.getKey(key, temp);
			if (result != null) {
				int n = temp[0].indexOf("/");
				if (n >= 0) {
					temp[0] = temp[0].substring(n + 1);
				}

				actualReturn[0] = new ULocale(temp[0]);
			}

			return result;
		}
	}

	public Factory registerObject(Object obj, ULocale locale) {
		return this.registerObject(obj, locale, -1, true);
	}

	public Factory registerObject(Object obj, ULocale locale, boolean visible) {
		return this.registerObject(obj, locale, -1, visible);
	}

	public Factory registerObject(Object obj, ULocale locale, int kind) {
		return this.registerObject(obj, locale, kind, true);
	}

	public Factory registerObject(Object obj, ULocale locale, int kind, boolean visible) {
		Factory factory = new SimpleLocaleKeyFactory(obj, locale, kind, visible);
		return this.registerFactory(factory);
	}

	public Locale[] getAvailableLocales() {
		Set<String> visIDs = this.getVisibleIDs();
		Locale[] locales = new Locale[visIDs.size()];
		int n = 0;

		Locale loc;
		for (Iterator i$ = visIDs.iterator(); i$.hasNext(); locales[n++] = loc) {
			String id = (String) i$.next();
			loc = LocaleUtility.getLocaleFromName(id);
		}

		return locales;
	}

	public ULocale[] getAvailableULocales() {
		Set<String> visIDs = this.getVisibleIDs();
		ULocale[] locales = new ULocale[visIDs.size()];
		int n = 0;

		String id;
		for (Iterator i$ = visIDs.iterator(); i$.hasNext(); locales[n++] = new ULocale(id)) {
			id = (String) i$.next();
		}

		return locales;
	}

	public String validateFallbackLocale() {
		ULocale loc = ULocale.getDefault();
		if (loc != this.fallbackLocale) {
			synchronized (this) {
				if (loc != this.fallbackLocale) {
					this.fallbackLocale = loc;
					this.fallbackLocaleName = loc.getBaseName();
					this.clearServiceCache();
				}
			}
		}

		return this.fallbackLocaleName;
	}

	public Key createKey(String id) {
		return LocaleKey.createWithCanonicalFallback(id, this.validateFallbackLocale());
	}

	public Key createKey(String id, int kind) {
		return LocaleKey.createWithCanonicalFallback(id, this.validateFallbackLocale(), kind);
	}

	public Key createKey(ULocale l, int kind) {
		return LocaleKey.createWithCanonical(l, this.validateFallbackLocale(), kind);
	}
}