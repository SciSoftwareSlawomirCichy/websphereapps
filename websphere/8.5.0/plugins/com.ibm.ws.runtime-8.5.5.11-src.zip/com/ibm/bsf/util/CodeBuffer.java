package com.ibm.bsf.util;

import com.ibm.bsf.util.cf.CodeFormatter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Hashtable;
import java.util.Stack;
import java.util.Vector;

public class CodeBuffer {
	private StringWriter fieldDeclSW = new StringWriter();
	private StringWriter methodDeclSW = new StringWriter();
	private StringWriter initializerSW = new StringWriter();
	private StringWriter constructorSW = new StringWriter();
	private StringWriter serviceMethodSW = new StringWriter();
	private PrintWriter fieldDeclPW;
	private PrintWriter methodDeclPW;
	private PrintWriter initializerPW;
	private PrintWriter constructorPW;
	private PrintWriter serviceMethodPW;
	private Stack symbolTableStack;
	private Hashtable symbolTable;
	private Hashtable usedSymbolIndices;
	private ObjInfo finalStatementInfo;
	private CodeBuffer parent;
	private Vector imports;
	private Vector constructorArguments;
	private Vector constructorExceptions;
	private Vector serviceMethodExceptions;
	private Vector implementsVector;
	private String packageName;
	private String className;
	private String serviceMethodName;
	private String extendsName;
	private Class serviceMethodReturnType;

	public CodeBuffer() {
		this.fieldDeclPW = new PrintWriter(this.fieldDeclSW);
		this.methodDeclPW = new PrintWriter(this.methodDeclSW);
		this.initializerPW = new PrintWriter(this.initializerSW);
		this.constructorPW = new PrintWriter(this.constructorSW);
		this.serviceMethodPW = new PrintWriter(this.serviceMethodSW);
		this.symbolTableStack = new Stack();
		this.symbolTable = new Hashtable();
		this.usedSymbolIndices = new Hashtable();
		this.symbolTableStack.push(this.symbolTable);
		this.imports = new Vector();
		this.constructorArguments = new Vector();
		this.constructorExceptions = new Vector();
		this.serviceMethodExceptions = new Vector();
		this.implementsVector = new Vector();
		this.packageName = null;
		this.className = "Test";
		this.serviceMethodName = "exec";
		this.extendsName = null;
		this.serviceMethodReturnType = Void.TYPE;
	}

	public CodeBuffer(CodeBuffer var1) {
		this.fieldDeclPW = new PrintWriter(this.fieldDeclSW);
		this.methodDeclPW = new PrintWriter(this.methodDeclSW);
		this.initializerPW = new PrintWriter(this.initializerSW);
		this.constructorPW = new PrintWriter(this.constructorSW);
		this.serviceMethodPW = new PrintWriter(this.serviceMethodSW);
		this.symbolTableStack = new Stack();
		this.symbolTable = new Hashtable();
		this.usedSymbolIndices = new Hashtable();
		this.symbolTableStack.push(this.symbolTable);
		this.imports = new Vector();
		this.constructorArguments = new Vector();
		this.constructorExceptions = new Vector();
		this.serviceMethodExceptions = new Vector();
		this.implementsVector = new Vector();
		this.packageName = null;
		this.className = "Test";
		this.serviceMethodName = "exec";
		this.extendsName = null;
		this.serviceMethodReturnType = Void.TYPE;
		this.parent = var1;
	}

	public void addConstructorArgument(ObjInfo var1) {
		this.constructorArguments.addElement(var1);
	}

	public void addConstructorException(String var1) {
		if (!this.constructorExceptions.contains(var1)) {
			this.constructorExceptions.addElement(var1);
		}

	}

	public void addConstructorStatement(String var1) {
		this.constructorPW.println(var1);
	}

	public void addFieldDeclaration(String var1) {
		this.fieldDeclPW.println(var1);
	}

	public void addImplements(String var1) {
		if (!this.implementsVector.contains(var1)) {
			this.implementsVector.addElement(var1);
		}

	}

	public void addImport(String var1) {
		if (!this.imports.contains(var1)) {
			this.imports.addElement(var1);
		}

	}

	public void addInitializerStatement(String var1) {
		this.initializerPW.println(var1);
	}

	public void addMethodDeclaration(String var1) {
		this.methodDeclPW.println(var1);
	}

	public void addServiceMethodException(String var1) {
		if (!this.serviceMethodExceptions.contains(var1)) {
			this.serviceMethodExceptions.addElement(var1);
		}

	}

	public void addServiceMethodStatement(String var1) {
		this.serviceMethodPW.println(var1);
	}

	private void appendIfNecessary(PrintWriter var1, StringBuffer var2) {
		if (var2.length() > 0) {
			var1.print(var2.toString());
		}

	}

	public String buildNewSymbol(String var1) {
		Integer var2 = this.getSymbolIndex(var1);
		if (var2 == null) {
			var2 = new Integer(0);
		}

		int var3 = var2;

		String var4;
		for (var4 = var1 + "_" + var3; this.getSymbol(var4) != null; var4 = var1 + "_" + var3) {
			++var3;
		}

		this.putSymbolIndex(var1, new Integer(var3 + 1));
		return var4;
	}

	public void clearSymbolTable() {
		this.symbolTable = new Hashtable();
		this.symbolTableStack = new Stack();
		this.symbolTableStack.push(this.symbolTable);
		this.usedSymbolIndices = new Hashtable();
	}

	public String getClassName() {
		return this.className;
	}

	public Vector getConstructorArguments() {
		return this.constructorArguments;
	}

	public StringBuffer getConstructorBuffer() {
		this.constructorPW.flush();
		return this.constructorSW.getBuffer();
	}

	public Vector getConstructorExceptions() {
		return this.constructorExceptions;
	}

	public String getExtends() {
		return this.extendsName;
	}

	public StringBuffer getFieldBuffer() {
		this.fieldDeclPW.flush();
		return this.fieldDeclSW.getBuffer();
	}

	public ObjInfo getFinalServiceMethodStatement() {
		return this.finalStatementInfo;
	}

	public Vector getImplements() {
		return this.implementsVector;
	}

	public Vector getImports() {
		return this.imports;
	}

	public StringBuffer getInitializerBuffer() {
		this.initializerPW.flush();
		return this.initializerSW.getBuffer();
	}

	public StringBuffer getMethodBuffer() {
		this.methodDeclPW.flush();
		return this.methodDeclSW.getBuffer();
	}

	public String getPackageName() {
		return this.packageName;
	}

	public StringBuffer getServiceMethodBuffer() {
		this.serviceMethodPW.flush();
		return this.serviceMethodSW.getBuffer();
	}

	public Vector getServiceMethodExceptions() {
		return this.serviceMethodExceptions;
	}

	public String getServiceMethodName() {
		return this.serviceMethodName;
	}

	public Class getServiceMethodReturnType() {
		if (this.finalStatementInfo != null) {
			return this.finalStatementInfo.objClass;
		} else {
			return this.serviceMethodReturnType != null ? this.serviceMethodReturnType : Void.TYPE;
		}
	}

	public ObjInfo getSymbol(String var1) {
		ObjInfo var2 = (ObjInfo) this.symbolTable.get(var1);
		if (var2 == null && this.parent != null) {
			var2 = this.parent.getSymbol(var1);
		}

		return var2;
	}

	Integer getSymbolIndex(String var1) {
		return this.parent != null ? this.parent.getSymbolIndex(var1) : (Integer) this.usedSymbolIndices.get(var1);
	}

	public Hashtable getSymbolTable() {
		return this.symbolTable;
	}

	public void merge(CodeBuffer var1) {
		Vector var2 = var1.getImports();

		for (int var3 = 0; var3 < var2.size(); ++var3) {
			this.addImport((String) var2.elementAt(var3));
		}

		this.appendIfNecessary(this.fieldDeclPW, var1.getFieldBuffer());
		this.appendIfNecessary(this.methodDeclPW, var1.getMethodBuffer());
		this.appendIfNecessary(this.initializerPW, var1.getInitializerBuffer());
		this.appendIfNecessary(this.constructorPW, var1.getConstructorBuffer());
		this.appendIfNecessary(this.serviceMethodPW, var1.getServiceMethodBuffer());
		ObjInfo var4 = this.getFinalServiceMethodStatement();
		if (var4 != null && var4.isExecutable()) {
			this.addServiceMethodStatement(var4.objName + ";");
		}

		this.setFinalServiceMethodStatement(var1.getFinalServiceMethodStatement());
	}

	public void popSymbolTable() {
		this.symbolTableStack.pop();
		this.symbolTable = (Hashtable) this.symbolTableStack.peek();
	}

	public void print(PrintWriter var1, boolean var2) {
		if (var2) {
			(new CodeFormatter()).formatCode(new StringReader(this.toString()), var1);
		} else {
			var1.print(this.toString());
		}

		var1.flush();
	}

	public void pushSymbolTable() {
		this.symbolTable = (Hashtable) this.symbolTableStack.push(new ScriptSymbolTable(this.symbolTable));
	}

	public void putSymbol(String var1, ObjInfo var2) {
		this.symbolTable.put(var1, var2);
	}

	void putSymbolIndex(String var1, Integer var2) {
		if (this.parent != null) {
			this.parent.putSymbolIndex(var1, var2);
		} else {
			this.usedSymbolIndices.put(var1, var2);
		}

	}

	public void setClassName(String var1) {
		this.className = var1;
	}

	public void setExtends(String var1) {
		this.extendsName = var1;
	}

	public void setFinalServiceMethodStatement(ObjInfo var1) {
		this.finalStatementInfo = var1;
	}

	public void setPackageName(String var1) {
		this.packageName = var1;
	}

	public void setServiceMethodName(String var1) {
		this.serviceMethodName = var1;
	}

	public void setServiceMethodReturnType(Class var1) {
		this.serviceMethodReturnType = var1;
	}

	public void setSymbolTable(Hashtable var1) {
		this.symbolTable = var1;
	}

	public boolean symbolTableIsStacked() {
		return this.symbolTable instanceof ScriptSymbolTable;
	}

	public String toString() {
		StringWriter var1 = new StringWriter();
		PrintWriter var2 = new PrintWriter(var1);
		ObjInfo var3 = this.finalStatementInfo;
		if (this.packageName != null && !this.packageName.equals("")) {
			var2.println("package " + this.packageName + ";");
			var2.println();
		}

		if (this.imports.size() > 0) {
			for (int var4 = 0; var4 < this.imports.size(); ++var4) {
				var2.println("import " + this.imports.elementAt(var4) + ";");
			}

			var2.println();
		}

		var2.println("public class " + this.className
				+ (this.extendsName != null && !this.extendsName.equals("") ? " extends " + this.extendsName : "")
				+ (this.implementsVector.size() > 0
						? " implements " + StringUtils.getCommaListFromVector(this.implementsVector)
						: ""));
		var2.println("{");
		var2.print(this.getFieldBuffer().toString());
		StringBuffer var5 = this.getInitializerBuffer();
		if (var5.length() > 0) {
			var2.println();
			var2.println("{");
			var2.print(var5.toString());
			var2.println("}");
		}

		var5 = this.getConstructorBuffer();
		if (var5.length() > 0) {
			var2.println();
			var2.println("public " + this.className + "("
					+ (this.constructorArguments.size() > 0
							? StringUtils.getCommaListFromVector(this.constructorArguments)
							: "")
					+ ")"
					+ (this.constructorExceptions.size() > 0
							? " throws " + StringUtils.getCommaListFromVector(this.constructorExceptions)
							: ""));
			var2.println("{");
			var2.print(var5.toString());
			var2.println("}");
		}

		var5 = this.getServiceMethodBuffer();
		if (var5.length() > 0 || var3 != null) {
			var2.println();
			var2.println("public " + StringUtils.getClassName(this.getServiceMethodReturnType()) + " "
					+ this.serviceMethodName + "()"
					+ (this.serviceMethodExceptions.size() > 0
							? " throws " + StringUtils.getCommaListFromVector(this.serviceMethodExceptions)
							: ""));
			var2.println("{");
			var2.print(var5.toString());
			if (var3 != null) {
				if (var3.isValueReturning()) {
					var2.println();
					var2.println("return " + var3.objName + ";");
				} else if (var3.isExecutable()) {
					var2.println(var3.objName + ";");
				}
			}

			var2.println("}");
		}

		var2.print(this.getMethodBuffer().toString());
		var2.println("}");
		var2.flush();
		return var1.toString();
	}
}