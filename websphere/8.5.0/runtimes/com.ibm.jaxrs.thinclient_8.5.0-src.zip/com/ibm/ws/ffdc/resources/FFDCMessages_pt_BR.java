package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_pt_BR extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Mecanismo de Análise que usa o banco de dados: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Incidente de FFDC emitido em {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: O gerenciamento de arquivo de log do FFDC está tentando excluir o arquivo {0}"},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: O gerenciamento de arquivo de log do FFDC removeu {0} de {1} arquivos que alcançaram seu tempo máximo configurado"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: O gerenciamento de arquivo de log do FFDC falhou ao excluir o arquivo {0}"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: O gerenciamento de arquivo de log do FFDC falhou ao obter a lista de arquivos de exceção"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: O FFDC fechou o arquivo de fluxo de incidentes {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: O FFDC abriu o arquivo de fluxo de incidentes {0}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: O FFDC falhou ao fechar o arquivo de fluxo de incidentes {0}, exceção capturada {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: O FFDC falhou ao abrir ou criar o arquivo de fluxo de incidentes {0}, exceção capturada {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: O FFDC falhou ao gravar o arquivo de fluxo de incidentes {0}, exceção capturada {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}