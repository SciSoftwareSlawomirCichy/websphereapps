package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.EntryNotFoundException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InvalidIdentifierException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.RealmManager;
import com.ibm.ws.wim.registry.dataobject.IDAndRealm;
import com.ibm.ws.wim.util.StringUtil;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UniqueIdBridge {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private final String className = UniqueIdBridge.class.getName();
	private Logger uniqueIdBridgeTrace;
	private TypeMappings propertyMap;
	private BridgeUtils mappingUtils;
	private String groupRDN;

	public UniqueIdBridge() {
		this.uniqueIdBridgeTrace = WIMLogger.getTraceLogger(this.className);
		this.propertyMap = new TypeMappings();
		this.mappingUtils = BridgeUtils.singleton();
		this.groupRDN = "cn";
		String var1 = "UniqueIdBridge";
		if (this.uniqueIdBridgeTrace.isLoggable(Level.FINER)) {
			this.uniqueIdBridgeTrace.entering(this.className, var1);
		}

		try {
			List var2 = ConfigManager.singleton().getRDNProperties("Group");
			if (var2 != null && var2.size() > 0) {
				this.groupRDN = (String) var2.get(0);
			}
		} catch (WIMException var3) {
			this.uniqueIdBridgeTrace.log(Level.FINE, var3.getMessage(), var3);
		}

		if (this.uniqueIdBridgeTrace.isLoggable(Level.FINER)) {
			this.uniqueIdBridgeTrace.exiting(this.className, var1);
		}

	}

	public String getUniqueUserId(String var1) throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = "getUniqueUserId";
		if (this.uniqueIdBridgeTrace.isLoggable(Level.FINER)) {
			this.uniqueIdBridgeTrace.entering(this.className, var2, "inputUserSecurityName = \"" + var1 + "\"");
		}

		String var3 = "";

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
				DataObject var6 = var5.createDataObject("contexts");
				var6.set("key", "allowOperationIfReposDown");
				var6.set("value", RealmManager.singleton().getAllowOperationIfReposDown(var4.getRealm()));
			}

			String var22 = "'";
			String var7 = var4.getId();
			if (var7.indexOf("'") != -1) {
				var22 = "\"";
			}

			String var8 = this.propertyMap.getInputUserSecurityName(var4.getRealm());
			var8 = this.mappingUtils.getRealInputAttrName(var8, var7, true);
			String var9 = this.propertyMap.getOutputUniqueUserId(var4.getRealm());
			BridgeUtils var10000 = this.mappingUtils;
			boolean var10 = BridgeUtils.allowDNAsPrincipalName;
			DataObject var11;
			if (var10) {
				var11 = var5.createDataObject("contexts");
				var11.set("key", "allowDNPrincipalNameAsLiteral");
				var11.set("value", var10);
			}

			var11 = null;

			try {
				var11 = this.mappingUtils.getEntityByIdentifier(var5, var8, var7, var9, this.mappingUtils);
			} catch (WIMException var20) {
				if (!var10) {
					throw var20;
				}
			}

			if (var11 != null) {
				var5 = var11;
			} else {
				var7 = StringUtil.escapeSearchExpression(var7);
				if (var10) {
					var8 = "principalName";
				}

				DataObject var12 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"SearchControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputUniqueUserId(var4.getRealm()))) {
					var12.getList("properties").add(this.propertyMap.getOutputUniqueUserId(var4.getRealm()));
				}

				var12.setString("expression",
						"//entities[@xsi:type='LoginAccount' and " + var8 + "=" + var22 + var7 + var22 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
			}

			List var23 = var5.getList("entities");
			if (var23.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var2);
			}

			if (var23.size() != 1) {
				boolean var24 = false;
				int var14 = var23.size();
				StringBuilder var15 = new StringBuilder();
				HashSet var16 = new HashSet();

				for (int var25 = 0; var25 < var14; ++var25) {
					DataObject var17 = (DataObject) var23.get(var25);
					if (var17.get("identifier") != null) {
						DataObject var18 = (DataObject) var17.get("identifier");
						if (var18.get("repositoryId") != null) {
							String var19 = String.valueOf(var18.get("repositoryId"));
							if (!var16.contains(var19)) {
								var16.add(var19);
							}
						}
					}
				}

				if (var16.size() == 0) {
					var15.append("repositories");
				} else {
					var15.append(var16);
				}

				throw new EntityNotFoundException("MULTIPLE_PRINCIPALS_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var15), this.className, var2);
			}

			DataObject var13 = (DataObject) var23.get(0);
			if (!this.mappingUtils.isIdentifierTypeProperty(this.propertyMap.getOutputUniqueUserId(var4.getRealm()))) {
				var3 = var13.getString(this.propertyMap.getOutputUniqueUserId(var4.getRealm()));
			} else {
				var3 = var13.getString("identifier/" + this.propertyMap.getOutputUniqueUserId(var4.getRealm()));
			}

			var10000 = this.mappingUtils;
			if (BridgeUtils.returnRealmInfoInUniqueUserId && var4.isRealmDefined()
					&& !RealmManager.singleton().getDefaultRealmName().equals(var4.getRealm())) {
				var3 = var3 + var4.getDelimiter() + var4.getRealm();
			}
		} catch (WIMException var21) {
			this.mappingUtils.logException(var21, this.className);
			if (!(var21 instanceof EntityNotFoundException) && !(var21 instanceof InvalidIdentifierException)) {
				throw new CustomRegistryException(var21);
			}

			throw new EntryNotFoundException(var21);
		}

		if (this.uniqueIdBridgeTrace.isLoggable(Level.FINER)) {
			this.uniqueIdBridgeTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getUniqueGroupId(String var1)
			throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = "getUniqueGroupId";
		if (this.uniqueIdBridgeTrace.isLoggable(Level.FINER)) {
			this.uniqueIdBridgeTrace.entering(this.className, var2, "inputGroupSecurityName = \"" + var1 + "\"");
		}

		String var3 = "";

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
			}

			String var6 = "'";
			String var7 = var4.getId();
			if (var7.indexOf("'") != -1) {
				var6 = "\"";
			}

			String var8 = this.propertyMap.getInputGroupSecurityName(var4.getRealm());
			var8 = this.mappingUtils.getRealInputAttrName(var8, var7, false);
			String var9 = this.propertyMap.getOutputUniqueGroupId(var4.getRealm());
			DataObject var10 = null;
			var10 = this.mappingUtils.getEntityByIdentifier(var5, var8, var7, var9, this.mappingUtils);
			if (var10 != null) {
				var5 = var10;
			} else {
				DataObject var11 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"SearchControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputUniqueGroupId(var4.getRealm()))) {
					var11.getList("properties").add(this.propertyMap.getOutputUniqueGroupId(var4.getRealm()));
				}

				var11.setString("expression",
						"//entities[@xsi:type='Group' and " + var8 + "=" + var6 + var7 + var6 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
			}

			List var20 = var5.getList("entities");
			if (var20.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var2);
			}

			if (var20.size() != 1) {
				boolean var21 = false;
				int var13 = var20.size();
				StringBuilder var14 = new StringBuilder();
				HashSet var15 = new HashSet();

				for (int var22 = 0; var22 < var13; ++var22) {
					DataObject var16 = (DataObject) var20.get(var22);
					if (var16.get("identifier") != null) {
						DataObject var17 = (DataObject) var16.get("identifier");
						if (var17.get("repositoryId") != null) {
							String var18 = String.valueOf(var17.get("repositoryId"));
							if (!var15.contains(var18)) {
								var15.add(var18);
							}
						}
					}
				}

				if (var15.size() == 0) {
					var14.append("repositories");
				} else {
					var14.append(var15);
				}

				throw new EntityNotFoundException("MULTIPLE_PRINCIPALS_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var14), this.className, var2);
			}

			DataObject var12 = (DataObject) var20.get(0);
			if (!this.mappingUtils.isIdentifierTypeProperty(this.propertyMap.getOutputUniqueGroupId(var4.getRealm()))) {
				var3 = var12.getString(this.propertyMap.getOutputUniqueGroupId(var4.getRealm()));
			} else {
				var3 = var12.getString("identifier/" + this.propertyMap.getOutputUniqueGroupId(var4.getRealm()));
			}
		} catch (WIMException var19) {
			this.mappingUtils.logException(var19, this.className);
			if (!(var19 instanceof EntityNotFoundException) && !(var19 instanceof InvalidIdentifierException)) {
				throw new CustomRegistryException(var19);
			}

			throw new EntryNotFoundException(var19);
		}

		if (this.uniqueIdBridgeTrace.isLoggable(Level.FINER)) {
			this.uniqueIdBridgeTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}
}