package com.ibm.ejs.cm;

import com.ibm.websphere.advanced.cm.factory.CMFactoryException;
import javax.naming.NamingException;
import javax.naming.Reference;

public interface CMProperties {
	Reference getReference() throws NamingException;

	CMProperties loadFromReference(Reference var1) throws NumberFormatException, CMFactoryException;

	String getName();

	String getDataSourceClassName();

	boolean isDisable2Phase();

	void validate() throws CMFactoryException;

	boolean getLogOrphan();

	boolean getOraTransLoose();

	String getDataBaseVersion();

	void setDataBaseVersion(String var1);
}