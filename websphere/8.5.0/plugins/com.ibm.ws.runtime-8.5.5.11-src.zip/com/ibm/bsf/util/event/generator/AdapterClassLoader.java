package com.ibm.bsf.util.event.generator;

import com.ibm.bsf.debug.util.DebugLog;
import java.util.Hashtable;

public class AdapterClassLoader extends ClassLoader {
	private static Hashtable classCache = new Hashtable();
	private Class c;

	public synchronized Class defineClass(String var1, byte[] var2) {
		if ((this.c = this.getLoadedClass(var1)) == null) {
			this.c = this.defineClass(var1, var2, 0, var2.length);
			this.put(var1, this.c);
		} else {
			DebugLog.stderrPrintln("AdapterClassLoader: " + this.c + " previously loaded. Can not redefine class.", 2);
		}

		return this.c;
	}

	protected final Class findClass(String var1) {
		return this.get(var1);
	}

	protected final Class get(String var1) {
		return (Class) classCache.get(var1);
	}

	public synchronized Class getLoadedClass(String var1) {
		Class var2 = this.findLoadedClass(var1);
		if (var2 == null) {
			try {
				var2 = this.findSystemClass(var1);
			} catch (ClassNotFoundException var4) {
				;
			}
		}

		if (var2 == null) {
			var2 = this.findClass(var1);
		}

		return var2;
	}

	protected synchronized Class loadClass(String var1, boolean var2) throws ClassNotFoundException {
		Class var3 = this.getLoadedClass(var1);
		if (var3 != null && var2) {
			this.resolveClass(var3);
		}

		return var3;
	}

	protected final void put(String var1, Class var2) {
		classCache.put(var1, var2);
	}
}