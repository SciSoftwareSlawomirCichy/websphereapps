package com.ibm.ejs.csi;

import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.ContainerProperties;
import com.ibm.ejs.container.HomeRecord;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.dopriv.SystemGetPropertyPrivileged;
import com.ibm.websphere.cpmi.PMModuleCookie;
import com.ibm.websphere.csi.EJBModuleMetaData;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ejbcontainer.runtime.EJBApplicationEventListener;
import com.ibm.ws.ejbcontainer.runtime.JCDIHelper;
import com.ibm.ws.javaee.dd.ejb.Interceptor;
import com.ibm.ws.metadata.ejb.AutomaticTimerBean;
import com.ibm.ws.metadata.ejb.EJBInterceptorBinding;
import com.ibm.ws.metadata.ejb.InterceptorMethodKind;
import com.ibm.ws.metadata.ejb.ModuleInitData;
import com.ibm.ws.runtime.metadata.ApplicationMetaData;
import com.ibm.ws.runtime.metadata.ComponentMetaData;
import com.ibm.ws.runtime.metadata.MetaDataImpl;
import com.ibm.ws.security.util.AccessController;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.ejb.ApplicationException;

public class EJBModuleMetaDataImpl extends MetaDataImpl implements EJBModuleMetaData {
	private static final String CLASS_NAME = EJBModuleMetaDataImpl.class.getName();
	private static final TraceComponent tc;
	public ModuleInitData ivInitData;
	public String ivName;
	public String ivLogicalName;
	public String ivAppName;
	public J2EEName ivJ2EEName;
	public int ivModuleVersion;
	private EJBApplicationMetaData ivEJBApplicationMetaData;
	public Hashtable<String, HomeRecord> ivHomeMap;
	public boolean ivSfsbFailover;
	public String ivFailoverInstanceId;
	public PMModuleCookie ivPMModuleCookie;
	public boolean ivMetadataComplete = false;
	public boolean ivReadWCCMInterceptors = true;
	public Map<String, ApplicationException> ivApplicationExceptionMap;
	public IdentityHashMap<Class<?>, EnumMap<InterceptorMethodKind, List<Method>>> ivInterceptorsMap;
	public Map<String, List<EJBInterceptorBinding>> ivInterceptorBindingMap;
	public String ivCurrentBackendId = null;
	public String ivDefaultCmpConnectionFactory = null;
	public String ivDefaultDataSource = null;
	public String ivDefaultDataSourceUser = null;
	public String ivDefaultDataSourcePassword = null;
	public Map<String, Interceptor> ivInterceptorMap;
	public boolean ivMBeanRegistered = false;
	public final Map<String, String> ivMessageDestinationBindingMap = new HashMap();
	public boolean ivMetaDataDestroyRequired = false;
	public boolean ivUseExtendedSetRollbackOnlyBehavior = false;
	public List<AutomaticTimerBean> ivAutomaticTimerBeans;
	public Map<String, BeanMetaData> ivBeanMetaDatas = new LinkedHashMap();
	private int ivNumFullyInitializedBeans;
	public List<EJBApplicationEventListener> ivApplicationEventListeners;
	public boolean ivStopping;
	public boolean ivEJBInWAR;
	public boolean ivManagedBeansInClient;
	public boolean ivManagedBeansOnly;
	public JCDIHelper ivJCDIHelper;
	public Boolean ivHasInterceptorJavaGlobalRef;
	public String ivVersionedAppBaseName;
	public String ivVersionedModuleBaseName;

	public EJBModuleMetaDataImpl(int slotCnt, EJBApplicationMetaData ejbAMD) {
		super(slotCnt);
		this.ivEJBApplicationMetaData = ejbAMD;
		this.ivHomeMap = new Hashtable();
	}

	public Boolean getApplicationExceptionRollback(Throwable t) {
		Class<?> klass = t.getClass();
		ApplicationException ae = this.getApplicationException(klass);
		Boolean rollback = null;
		if (ae != null) {
			rollback = ae.rollback();
		} else if (!ContainerProperties.EE5Compatibility) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "searching for inherited application exception for " + klass.getName());
			}

			for (Class superClass = klass.getSuperclass(); superClass != Throwable.class; superClass = superClass
					.getSuperclass()) {
				ae = this.getApplicationException(superClass);
				if (ae != null) {
					if (ae.inherited()) {
						rollback = ae.rollback();
					}
					break;
				}
			}
		}

		return rollback;
	}

	private ApplicationException getApplicationException(Class<?> klass) {
		ApplicationException result = null;
		if (this.ivApplicationExceptionMap != null) {
			result = (ApplicationException) this.ivApplicationExceptionMap.get(klass.getName());
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled() && result != null) {
				Tr.debug(tc, "found application-exception for " + klass.getName() + ", rollback=" + result.rollback()
						+ ", inherited=" + result.inherited());
			}
		}

		if (result == null) {
			result = (ApplicationException) klass.getAnnotation(ApplicationException.class);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled() && result != null) {
				Tr.debug(tc, "found ApplicationException for " + klass.getName() + ", rollback=" + result.rollback()
						+ ", inherited=" + result.inherited());
			}
		}

		return result;
	}

	public String getName() {
		return this.ivName;
	}

	public int getEJBModuleVersion() {
		return this.ivModuleVersion;
	}

	public J2EEName getJ2EEName() {
		return this.ivJ2EEName;
	}

	public ComponentMetaData[] getComponentMetaDatas() {
		ComponentMetaData[] initializedComponentMetaDatas = null;
		EJBApplicationMetaData var2 = this.ivEJBApplicationMetaData;
		synchronized (this.ivEJBApplicationMetaData) {
			initializedComponentMetaDatas = new ComponentMetaData[this.ivNumFullyInitializedBeans];
			int i = 0;
			Iterator i$ = this.ivBeanMetaDatas.values().iterator();

			while (i$.hasNext()) {
				BeanMetaData bmd = (BeanMetaData) i$.next();
				if (bmd.fullyInitialized) {
					initializedComponentMetaDatas[i++] = bmd;
				}
			}

			return initializedComponentMetaDatas;
		}
	}

	public ApplicationMetaData getApplicationMetaData() {
		return this.ivEJBApplicationMetaData.getApplicationMetaData();
	}

	public EJBApplicationMetaData getEJBApplicationMetaData() {
		return this.ivEJBApplicationMetaData;
	}

	public void release() {
	}

	public String toDumpString() {
		String newLine = (String) AccessController
				.doPrivileged(new SystemGetPropertyPrivileged("line.separator", "\n"));
		StringBuilder sb = new StringBuilder(this.toString());
		String indent = "   ";
		sb.append(newLine + newLine + "--- Dump EJBModuleMetaDataImpl fields ---");
		if (this.ivName != null) {
			sb.append(newLine + indent + "Module name = " + this.ivName);
		} else {
			sb.append(newLine + indent + "Module name = null");
		}

		if (this.ivLogicalName != null) {
			sb.append(newLine + indent + "Module logical name = " + this.ivLogicalName);
		} else {
			sb.append(newLine + indent + "Module logical name = null");
		}

		sb.append(newLine + indent + "Module version = " + this.ivModuleVersion);
		if (this.getApplicationMetaData() != null) {
			sb.append(newLine + indent + "Application metadata = " + this.getApplicationMetaData());
		} else {
			sb.append(newLine + indent + "Application metadata = null");
		}

		if (this.ivHomeMap != null) {
			sb.append(newLine + indent + "Home map = " + this.ivHomeMap);
		} else {
			sb.append(newLine + indent + "Home map = null");
		}

		if (this.ivApplicationExceptionMap != null) {
			sb.append(newLine + indent + "Application Exception map contents:");
			Iterator i$ = this.ivApplicationExceptionMap.entrySet().iterator();

			while (i$.hasNext()) {
				Entry<String, ApplicationException> entry = (Entry) i$.next();
				ApplicationException value = (ApplicationException) entry.getValue();
				sb.append(newLine + indent + indent + "Exception: " + (String) entry.getKey() + ", rollback = "
						+ value.rollback() + ", inherited = " + value.inherited());
			}
		} else {
			sb.append(newLine + indent + "Application Exception map = null");
		}

		sb.append(newLine + indent + "SFSB failover = " + this.ivSfsbFailover);
		if (this.ivFailoverInstanceId != null) {
			sb.append(newLine + indent + "Failover instance ID = " + this.ivFailoverInstanceId);
		} else {
			sb.append(newLine + indent + "Failover instance ID = null");
		}

		sb.append(newLine + indent + "Fully initialized bean count = " + this.ivNumFullyInitializedBeans);
		if (this.ivJCDIHelper != null) {
			sb.append(newLine + indent + "JCDI is enabled : " + this.ivJCDIHelper);
		} else {
			sb.append(newLine + indent + "JCDI is NOT enabled");
		}

		sb.append(
				newLine + indent + "UseExtendedSetRollbackOnlyBehavior = " + this.ivUseExtendedSetRollbackOnlyBehavior);
		sb.append(newLine + indent + "VersionedBaseName = " + this.ivVersionedAppBaseName + "#"
				+ this.ivVersionedModuleBaseName);
		this.toString(sb, newLine, indent);
		sb.append(newLine + "--- End EJBModuleMetaDataImpl fields ---");
		sb.append(newLine);
		return sb.toString();
	}

	protected void toString(StringBuilder sb, String nl, String indent) {
	}

	public boolean isEJBDeployed() {
		return this.ivModuleVersion < 30 && !this.ivEJBInWAR;
	}

	public final List<EJBInterceptorBinding> getEJBInterceptorBindings(String ejbName) {
		return (List) this.ivInterceptorBindingMap.get(ejbName);
	}

	public final List<EJBInterceptorBinding> removeEJBInterceptorBindings(String ejbName) {
		return (List) this.ivInterceptorBindingMap.remove(ejbName);
	}

	public void addApplicationEventListener(EJBApplicationEventListener listener) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "addApplicationEventListener: " + listener);
		}

		if (this.ivApplicationEventListeners == null) {
			this.ivApplicationEventListeners = new ArrayList();
		}

		this.ivApplicationEventListeners.add(listener);
	}

	public void addAutomaticTimerBean(AutomaticTimerBean timerBean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "addAutomaticTimerBean: " + timerBean.getBeanMetaData().j2eeName);
		}

		if (this.ivAutomaticTimerBeans == null) {
			this.ivAutomaticTimerBeans = new ArrayList();
		}

		this.ivAutomaticTimerBeans.add(timerBean);
	}

	public void freeResourcesAfterAllBeansInitialized(BeanMetaData bmd) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "freeResourcesAfterAllBeansInitialized: " + bmd.j2eeName + ", "
					+ (this.ivNumFullyInitializedBeans + 1) + "/" + this.ivBeanMetaDatas.size());
		}

		++this.ivNumFullyInitializedBeans;
		boolean freeResources = this.ivNumFullyInitializedBeans == this.ivBeanMetaDatas.size();
		if (freeResources) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "all beans are initialized in module name = " + this.ivName
						+ ", freeing resources no longer needed");
			}

			this.ivInterceptorMap = null;
			this.ivInterceptorBindingMap = null;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "freeResourcesAfterAllBeansInitialized");
		}

	}

	public void setVersionedModuleBaseName(String appBaseName, String modBaseName) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "ModuleName = " + this.ivName + ", VersionedBaseName = " + appBaseName + "#" + modBaseName);
		}

		if (this.ivInitData == null) {
			throw new IllegalStateException("ModuleMetaData has finished creation.");
		} else if (appBaseName == null) {
			throw new IllegalArgumentException("appBaseName is null");
		} else if (modBaseName == null) {
			throw new IllegalArgumentException("modBaseName is null");
		} else {
			this.ivEJBApplicationMetaData.validateVersionedModuleBaseName(appBaseName, modBaseName);
			this.ivVersionedAppBaseName = appBaseName;
			this.ivVersionedModuleBaseName = modBaseName;
		}
	}

	public boolean isVersionedModule() {
		return this.ivVersionedModuleBaseName != null;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}