package com.ibm.bsf.util;

import com.ibm.bsf.BSFEngine;
import com.ibm.bsf.BSFException;
import com.ibm.bsf.BSFManager;

public class BSFFunctions {
	BSFManager mgr;
	BSFEngine engine;

	public BSFFunctions(BSFManager var1, BSFEngine var2) {
		this.mgr = var1;
		this.engine = var2;
	}

	public void addEventListener(Object var1, String var2, String var3, Object var4) throws BSFException {
		EngineUtils.addEventListener(var1, var2, var3, this.engine, this.mgr, "<event-binding>", 0, 0, var4);
	}

	public Object lookupBean(String var1) {
		return this.mgr.lookupBean(var1);
	}

	public void registerBean(String var1, Object var2) {
		this.mgr.registerBean(var1, var2);
	}

	public void unregisterBean(String var1) {
		this.mgr.unregisterBean(var1);
	}
}