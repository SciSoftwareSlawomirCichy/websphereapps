package com.ibm.ws.wim.management;

import com.ibm.websphere.wim.ras.WIMLogger;
import java.io.Serializable;
import java.util.Vector;
import java.util.logging.Logger;

public class EventDataWrapper extends Vector implements Serializable {
	private String eventSubType;
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = EventDataWrapper.class.getName();
	private static final Logger trcLogger;

	public EventDataWrapper() {
		this.eventSubType = "";
	}

	public EventDataWrapper(String var1, Object[] var2) {
		this.eventSubType = var1;
		if (var2 != null) {
			for (int var3 = 0; var3 < var2.length; ++var3) {
				this.add(var2[var3]);
			}
		}

	}

	public EventDataWrapper(String var1, Object var2) {
		this.eventSubType = var1;
		if (var2 != null) {
			this.add(var2);
		}

	}

	public Object[] getObjects() {
		Object[] var1 = null;
		synchronized (this) {
			var1 = this.toArray();
			return var1;
		}
	}

	public Object getObject() {
		Object var1 = null;
		synchronized (this) {
			if (this.size() > 0) {
				var1 = this.get(0);
			}

			return var1;
		}
	}

	public String getEventSubType() {
		return this.eventSubType;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}