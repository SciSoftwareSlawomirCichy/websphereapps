package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

class MSSQLServerPortabilityLayer extends PortabilityLayerImpl {
	private static MSSQLServerPortabilityLayer instance;
	protected static final String FOR_UPDATE = "FOR UPDATE";
	protected static final String HOLDLOCK = "(UPDLOCK)";
	protected static final String WHERE = "WHERE";
	protected static final int CHAR_COUNT = 10;
	private static final String[] SPECIAL_KEYS = new String[]{"integratedSecurity"};
	private static final TraceComponent tc = Tr.register(MSSQLServerPortabilityLayer.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	protected MSSQLServerPortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.errorMap.put(new Integer(2714), TableAlreadyExistsException.class);
		this.errorMap.put(new Integer(2627), DuplicateKeyException.class);
		this.errorMap.put(new Integer(4), ResourceAllocationException.class);
		this.errorMap.put("08S01", StaleConnectionException.class);
		this.errorMap.put(new Integer(230), StaleConnectionException.class);
		this.errorMap.put(new Integer(1779), PrimarykeyAlreadyDefinedException.class);
		this.errorMap.put(new Integer(3701), TableDoesNotExistException.class);
		this.errorMap.put(new Integer(208), TableDoesNotExistException.class);
		this.errorMap.put(new Integer(4902), TableDoesNotExistException.class);
		this.typeMap.setElementAt(" TEXT NOT NULL ", 7);
		this.typeMap.setElementAt(" TEXT ", 8);
		this.typeMap.setElementAt(" IMAGE ", 9);
		this.typeMap.setElementAt(" VARBINARY(2048) ", 10);
		this.defaultDataSourceProps.setProperty("integratedSecurity", "false");
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void createTable(Connection connection, String schema, String sql) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTable", new Object[]{connection, schema, sql});
		}

		String doctoredSql = replaceString(sql, "BLOB(1M)", "IMAGE");
		super.createTable(connection, schema, doctoredSql);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTable");
		}

	}

	public void createTableForPersister(Connection connection, String schema, String name, String sql)
			throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "createTableForPersister", new Object[]{connection, schema, sql});
		}

		String doctoredSql = replaceString(sql, "BLOB(1M)", "IMAGE");
		if (doctoredSql.indexOf(" DOUBLE") > 0) {
			doctoredSql = replaceString(doctoredSql, " DOUBLE ", " FLOAT ");
			doctoredSql = replaceString(doctoredSql, " DOUBLE,", " FLOAT,");
			doctoredSql = replaceString(doctoredSql, " DOUBLE(", " FLOAT(");
			doctoredSql = replaceString(doctoredSql, " DOUBLE)", " FLOAT)");
		}

		if (doctoredSql.indexOf(" DATE") > 0) {
			doctoredSql = replaceString(doctoredSql, " DATE ", " DATETIME ");
			doctoredSql = replaceString(doctoredSql, " DATE,", " DATETIME,");
			doctoredSql = replaceString(doctoredSql, " DATE)", " DATETIME)");
		}

		if (doctoredSql.indexOf(" TIME") > 0) {
			doctoredSql = replaceString(doctoredSql, " TIME ", " DATETIME ");
			doctoredSql = replaceString(doctoredSql, " TIME,", " DATETIME,");
			doctoredSql = replaceString(doctoredSql, " TIME)", " DATETIME)");
		}

		super.createTableForPersister(connection, schema, name, doctoredSql);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "createTableForPersister");
		}

	}

	public String addRowLockHint(String sql) {
		return sql + "FOR UPDATE";
	}

	public boolean supportsRowLockHint() {
		return true;
	}

	public String scanSQL(String sql) {
		if (sql == null) {
			return null;
		} else {
			StringBuffer sb = new StringBuffer(sql);
			sql = sql.toUpperCase();
			int last = 0;

			int f;
			for (int numReplaced = 0; (f = sql.indexOf("FOR UPDATE", last)) > 0; ++numReplaced) {
				int w = sql.indexOf("WHERE", last);
				if (w < 0 || w > f) {
					w = f;
				}

				last = f + 10;
				sb.delete(f + 14 * numReplaced, last + 14 * numReplaced);
				sb.insert(w + 14 * numReplaced, "WITH (UPDLOCK, ROWLOCK) ");
			}

			return sb.toString();
		}
	}

	public String processSQL(String sqlString, int isolevel, boolean addForUpdate, boolean addextendedforUpdateSyntax) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "processSQL - sqlString, isolevel, addForUpdate, addextendedforupdate: ",
					new Object[]{sqlString, new Integer(isolevel), new Boolean(addForUpdate),
							new Boolean(addextendedforUpdateSyntax)});
		}

		if (addForUpdate && sqlString != null) {
			StringBuffer stmt = new StringBuffer(sqlString.length() + 24);
			stmt.append(sqlString);
			sqlString = sqlString.toUpperCase();
			int w = sqlString.indexOf("WHERE", 0);
			if (w == -1) {
				stmt.append(" WITH (UPDLOCK, ROWLOCK)");
			} else {
				stmt.insert(w, "WITH (UPDLOCK, ROWLOCK) ");
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "processSQL - The modified sqlString is: ", stmt);
			}

			return new String(stmt);
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "processSQL - no change");
			}

			return sqlString;
		}
	}

	public static PortabilityLayer getInstance(DataSourceProperties dsProps) {
		if (instance == null) {
			instance = new MSSQLServerPortabilityLayer();
		}

		return instance;
	}

	public static PortabilityLayer getInstance() {
		if (instance == null) {
			instance = new MSSQLServerPortabilityLayer();
		}

		return instance;
	}

	protected void handleSpecialKey(DataSourceProperties dsProps, Properties defaultProps, String key) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "handleSpecialKey", key);
		}

		if (key.equals(SPECIAL_KEYS[0])) {
			String dsPropsValue = dsProps.getProperty(key);
			String defaultPropsValue = defaultProps.getProperty(key);
			if (dsPropsValue != null && !dsPropsValue.equalsIgnoreCase(defaultPropsValue)) {
				Tr.warning(tc, "MSG_CONM_1000E", new Object[]{dsPropsValue, key, ""});
				dsProps.setProperty(key, defaultPropsValue);
			} else if (dsPropsValue == null) {
				dsProps.setProperty(key, defaultPropsValue);
			}
		}

	}
}