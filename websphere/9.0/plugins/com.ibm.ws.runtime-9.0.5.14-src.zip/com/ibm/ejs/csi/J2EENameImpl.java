package com.ibm.ejs.csi;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.util.HeapDumpMarker;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;

public class J2EENameImpl implements J2EEName {
	private static final long serialVersionUID = 7488184044073147667L;
	private static final String CLASS_NAME = J2EENameImpl.class.getName();
	private static final TraceComponent tc;
	private static final String SEPARATOR = "#";
	private static HashMap<String, J2EENameImpl> activeJ2EEName;
	private transient String ivApplication;
	private transient String ivModule;
	private transient String ivComponent;
	private transient String ivJ2eeName;
	private transient int ivNameHashValue;
	private transient J2EEName ivParent;
	private transient HeapDumpMarker ivHeapDumpMarker;
	private byte[] j2eeNameBytes;
	private int activeListIndex;

	public J2EENameImpl(String application, String module, String component) {
		this.ivApplication = application;
		this.ivModule = module;
		this.ivComponent = component;
		if (application == null) {
			throw new IllegalArgumentException("Application name required.");
		} else {
			StringBuffer sb = new StringBuffer(application);
			if (module != null) {
				sb.append("#").append(module);
			}

			if (module != null && component != null) {
				sb.append("#").append(component);
			}

			if (module == null && component != null) {
				throw new IllegalArgumentException(
						"Module name is null yet Component name is non-null, this is not acceptable");
			} else {
				this.ivJ2eeName = sb.toString();
				this.j2eeNameBytes = this.ivJ2eeName.getBytes();
				this.ivNameHashValue = this.ivJ2eeName.hashCode();
				HashMap var5 = activeJ2EEName;
				synchronized (activeJ2EEName) {
					J2EENameImpl existing = (J2EENameImpl) activeJ2EEName.get(this.ivJ2eeName);
					if (existing == null) {
						this.activeListIndex = activeJ2EEName.size();
						activeJ2EEName.put(this.ivJ2eeName, this);
						this.initializeHeapDumpMarkers();
					} else {
						this.activeListIndex = existing.activeListIndex;
						this.ivJ2eeName = existing.ivJ2eeName;
						this.ivParent = existing.ivParent;
						this.ivHeapDumpMarker = existing.ivHeapDumpMarker;
					}
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "<init>: " + this.toDebugString());
				}

			}
		}
	}

	public J2EENameImpl(byte[] j2eenameBytes) {
		this.activeListIndex = -1;
		this.resetFromByteArray(j2eenameBytes);
	}

	private void initializeHeapDumpMarkers() {
		J2EENameImpl app;
		if (this.ivComponent != null) {
			app = (J2EENameImpl) activeJ2EEName.get(this.ivApplication + '#' + this.ivModule);
			if (app == null) {
				app = new J2EENameImpl(this.ivApplication, this.ivModule, (String) null);
			}

			this.ivParent = app;
			this.ivHeapDumpMarker = HeapDumpMarker.create(this.ivComponent);
		} else if (this.ivModule != null) {
			app = (J2EENameImpl) activeJ2EEName.get(this.ivApplication);
			if (app == null) {
				app = new J2EENameImpl(this.ivApplication, (String) null, (String) null);
			}

			this.ivParent = app;
			this.ivHeapDumpMarker = HeapDumpMarker.create(this.ivModule);
		} else {
			this.ivHeapDumpMarker = HeapDumpMarker.create(this.ivApplication);
		}

	}

	private String toDebugString() {
		StringBuilder sb = new StringBuilder(super.toString());
		sb.append('[');
		sb.append(this.toString());
		sb.append(", #");
		sb.append(this.activeListIndex);
		sb.append(", ");

		for (int i = 0; i < this.j2eeNameBytes.length; ++i) {
			int b = this.j2eeNameBytes[i] & 255;
			sb.append(Character.forDigit(b & 15, 16)).append(Character.forDigit(b >> 4, 16));
		}

		return sb.append(']').toString();
	}

	public String toString() {
		return this.ivJ2eeName;
	}

	public String getApplication() {
		return this.ivApplication;
	}

	public String getModule() {
		return this.ivModule;
	}

	public String getComponent() {
		return this.ivComponent;
	}

	public byte[] getBytes() {
		return this.j2eeNameBytes;
	}

	public int hashCode() {
		return this.ivNameHashValue;
	}

	public boolean equals(Object o) {
		if (o != null && o instanceof J2EENameImpl) {
			return ((J2EENameImpl) o).activeListIndex == this.activeListIndex;
		} else {
			return false;
		}
	}

	public boolean equals(J2EENameImpl j2eeName) {
		if (j2eeName == null) {
			return false;
		} else {
			return j2eeName.activeListIndex == this.activeListIndex;
		}
	}

	void resetFromByteArray(byte[] j2eenameBytes) {
		this.ivApplication = null;
		this.ivModule = null;
		this.ivComponent = null;
		this.j2eeNameBytes = j2eenameBytes;
		this.ivJ2eeName = new String(j2eenameBytes);
		int index = this.ivJ2eeName.indexOf("#");
		if (index == -1) {
			this.ivApplication = this.ivJ2eeName;
		} else {
			this.ivApplication = new String(this.ivJ2eeName.substring(0, index));
			int nextIndex = this.ivJ2eeName.indexOf("#", index + 1);
			if (nextIndex == -1) {
				this.ivModule = new String(this.ivJ2eeName.substring(index + 1));
			} else {
				this.ivModule = new String(this.ivJ2eeName.substring(index + 1, nextIndex));
				this.ivComponent = new String(this.ivJ2eeName.substring(nextIndex + 1));
			}
		}

		this.ivNameHashValue = this.ivJ2eeName.hashCode();
		HashMap var7 = activeJ2EEName;
		synchronized (activeJ2EEName) {
			J2EENameImpl existing = (J2EENameImpl) activeJ2EEName.get(this.ivJ2eeName);
			if (existing == null) {
				this.activeListIndex = activeJ2EEName.size();
				activeJ2EEName.put(this.ivJ2eeName, this);
				this.initializeHeapDumpMarkers();
			} else {
				this.activeListIndex = existing.activeListIndex;
				this.ivJ2eeName = existing.ivJ2eeName;
				this.ivParent = existing.ivParent;
				this.ivHeapDumpMarker = existing.ivHeapDumpMarker;
			}

		}
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		this.activeListIndex = -1;
		this.resetFromByteArray(this.j2eeNameBytes);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "readObject: " + this.toDebugString());
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		activeJ2EEName = new HashMap();
	}
}