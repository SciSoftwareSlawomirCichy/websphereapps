package com.ibm.icu.impl;

import com.ibm.icu.impl.RelativeDateFormat.1;
import com.ibm.icu.impl.RelativeDateFormat.URelativeString;
import com.ibm.icu.text.DateFormat;
import com.ibm.icu.text.MessageFormat;
import com.ibm.icu.util.Calendar;
import com.ibm.icu.util.TimeZone;
import com.ibm.icu.util.ULocale;
import com.ibm.icu.util.UResourceBundle;
import com.ibm.icu.util.UResourceBundleIterator;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.util.Date;
import java.util.MissingResourceException;
import java.util.Set;
import java.util.TreeSet;

public class RelativeDateFormat extends DateFormat {
	private static final long serialVersionUID = 1131984966440549435L;
	private DateFormat fDateFormat;
	private DateFormat fTimeFormat;
	private MessageFormat fCombinedFormat;
	int fDateStyle;
	int fTimeStyle;
	ULocale fLocale;
	private transient URelativeString[] fDates = null;

	public RelativeDateFormat(int timeStyle, int dateStyle, ULocale locale) {
		this.fLocale = locale;
		this.fTimeStyle = timeStyle;
		this.fDateStyle = dateStyle;
		int newStyle;
		if (this.fDateStyle != -1) {
			newStyle = this.fDateStyle & -129;
			this.fDateFormat = DateFormat.getDateInstance(newStyle, locale);
		} else {
			this.fDateFormat = null;
		}

		if (this.fTimeStyle != -1) {
			newStyle = this.fTimeStyle & -129;
			this.fTimeFormat = DateFormat.getTimeInstance(newStyle, locale);
		} else {
			this.fTimeFormat = null;
		}

		this.initializeCalendar((TimeZone) null, this.fLocale);
		this.loadDates();
		this.initializeCombinedFormat(this.calendar, this.fLocale);
	}

	public StringBuffer format(Calendar cal, StringBuffer toAppendTo, FieldPosition fieldPosition) {
		String dayString = null;
		if (this.fDateStyle != -1) {
			int dayDiff = dayDifference(cal);
			dayString = this.getStringForDay(dayDiff);
		}

		if (this.fTimeStyle == -1) {
			if (dayString != null) {
				toAppendTo.append(dayString);
			} else if (this.fDateStyle != -1) {
				this.fDateFormat.format(cal, toAppendTo, fieldPosition);
			}
		} else {
			if (dayString == null && this.fDateStyle != -1) {
				dayString = this.fDateFormat.format(cal, new StringBuffer(), fieldPosition).toString();
			}

			FieldPosition timePos = new FieldPosition(fieldPosition.getField());
			String timeString = this.fTimeFormat.format(cal, new StringBuffer(), timePos).toString();
			this.fCombinedFormat.format(new Object[]{dayString, timeString}, toAppendTo, new FieldPosition(0));
			int offset;
			if (fieldPosition.getEndIndex() > 0 && (offset = toAppendTo.toString().indexOf(dayString)) >= 0) {
				fieldPosition.setBeginIndex(fieldPosition.getBeginIndex() + offset);
				fieldPosition.setEndIndex(fieldPosition.getEndIndex() + offset);
			} else if (timePos.getEndIndex() > 0 && (offset = toAppendTo.toString().indexOf(timeString)) >= 0) {
				fieldPosition.setBeginIndex(timePos.getBeginIndex() + offset);
				fieldPosition.setEndIndex(timePos.getEndIndex() + offset);
			}
		}

		return toAppendTo;
	}

	public void parse(String text, Calendar cal, ParsePosition pos) {
		throw new UnsupportedOperationException("Relative Date parse is not implemented yet");
	}

	private String getStringForDay(int day) {
		if (this.fDates == null) {
			this.loadDates();
		}

		for (int i = 0; i < this.fDates.length; ++i) {
			if (this.fDates[i].offset == day) {
				return this.fDates[i].string;
			}
		}

		return null;
	}

	private synchronized void loadDates() {
      CalendarData calData = new CalendarData(this.fLocale, this.calendar.getType());
      UResourceBundle rb = calData.get("fields", "day", "relative");
      Set<URelativeString> datesSet = new TreeSet(new 1(this));
      UResourceBundleIterator i = rb.getIterator();

      while(i.hasNext()) {
         UResourceBundle line = i.next();
         String k = line.getKey();
         String v = line.getString();
         URelativeString rs = new URelativeString(this, k, v);
         datesSet.add(rs);
      }

      this.fDates = (URelativeString[])datesSet.toArray(new URelativeString[0]);
   }

	private static int dayDifference(Calendar until) {
		Calendar nowCal = (Calendar) until.clone();
		Date nowDate = new Date(System.currentTimeMillis());
		nowCal.clear();
		nowCal.setTime(nowDate);
		int dayDiff = until.get(20) - nowCal.get(20);
		return dayDiff;
	}

	private Calendar initializeCalendar(TimeZone zone, ULocale locale) {
		if (this.calendar == null) {
			if (zone == null) {
				this.calendar = Calendar.getInstance(locale);
			} else {
				this.calendar = Calendar.getInstance(zone, locale);
			}
		}

		return this.calendar;
	}

	private MessageFormat initializeCombinedFormat(Calendar cal, ULocale locale) {
		String pattern = "{1} {0}";

		try {
			CalendarData calData = new CalendarData(locale, cal.getType());
			String[] patterns = calData.getDateTimePatterns();
			if (patterns != null && patterns.length >= 9) {
				int glueIndex = 8;
				if (patterns.length >= 13) {
					switch (this.fDateStyle) {
						case 0 :
						case 128 :
							++glueIndex;
							break;
						case 1 :
						case 129 :
							glueIndex += 2;
							break;
						case 2 :
						case 130 :
							glueIndex += 3;
							break;
						case 3 :
						case 131 :
							glueIndex += 4;
					}
				}

				pattern = patterns[glueIndex];
			}
		} catch (MissingResourceException var7) {
			;
		}

		this.fCombinedFormat = new MessageFormat(pattern, locale);
		return this.fCombinedFormat;
	}
}