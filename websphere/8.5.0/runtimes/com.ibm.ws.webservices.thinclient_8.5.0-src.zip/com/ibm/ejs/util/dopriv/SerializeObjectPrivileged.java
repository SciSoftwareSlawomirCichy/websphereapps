package com.ibm.ejs.util.dopriv;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.PrivilegedExceptionAction;

public final class SerializeObjectPrivileged implements PrivilegedExceptionAction {
	private static final SerializeObjectPrivileged[] svPool = new SerializeObjectPrivileged[10];
	private static int svPoolSize = 0;
	public Object ivObjToSerialize;
	public byte[] ivSerializedObj;
	private ByteArrayOutputStream ivBaos = null;

	private SerializeObjectPrivileged() {
		this.ivBaos = new ByteArrayOutputStream();
	}

	public static SerializeObjectPrivileged getSerializeObjectPrivileged() {
		SerializeObjectPrivileged rtnObj = null;
		SerializeObjectPrivileged[] var1 = svPool;
		synchronized (svPool) {
			if (svPoolSize > 0) {
				--svPoolSize;
				rtnObj = svPool[svPoolSize];
				svPool[svPoolSize] = null;
			}
		}

		if (rtnObj == null) {
			rtnObj = new SerializeObjectPrivileged();
		}

		return rtnObj;
	}

	public static void releaseSerializeObjectPrivileged(SerializeObjectPrivileged rtnObj) {
		rtnObj.ivObjToSerialize = null;
		rtnObj.ivSerializedObj = null;
		SerializeObjectPrivileged[] var1 = svPool;
		synchronized (svPool) {
			if (svPoolSize < svPool.length) {
				svPool[svPoolSize] = rtnObj;
				++svPoolSize;
			}

		}
	}

	public Object run() throws IOException {
		return this.serializeObject(this.ivObjToSerialize);
	}

	public byte[] serializeObject(Object obj) throws IOException {
		if (obj == null) {
			return null;
		} else {
			ObjectOutputStream out = new ObjectOutputStream(this.ivBaos);
			out.writeObject(obj);
			out.flush();
			this.ivSerializedObj = this.ivBaos.toByteArray();
			this.ivBaos.reset();
			return this.ivSerializedObj;
		}
	}
}