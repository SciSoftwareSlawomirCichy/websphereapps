package com.ibm.ejs.container;

import com.ibm.ejs.container.interceptors.InterceptorMetaData;
import com.ibm.ejs.container.interceptors.InterceptorProxy;
import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.j2c.HandleList;
import com.ibm.ejs.j2c.HandleListInterface;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.CallbackKind;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.traceinfo.ejbcontainer.TEBeanLifeCycleInfo;
import com.ibm.wsspi.injectionengine.InjectionEngine;
import com.ibm.wsspi.injectionengine.InjectionTarget;
import java.rmi.RemoteException;
import java.security.Identity;
import java.security.Principal;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
import javax.ejb.ConcurrentAccessTimeoutException;
import javax.ejb.EJBHome;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.ejb.EnterpriseBean;
import javax.ejb.IllegalLoopbackException;
import javax.ejb.LockType;
import javax.ejb.RemoveException;
import javax.ejb.TimerService;
import javax.transaction.UserTransaction;

public final class SingletonBeanO extends SessionBeanO {
	private static final String CLASS_NAME = SingletonBeanO.class.getName();
	private static final TraceComponent tc;
	public static final int METHOD_READY = 3;
	public static final int PRE_DESTROY = 4;
	static final String[] StateStrs;
	private final boolean ivContainerManagedConcurrency;
	private final ReentrantReadWriteLock ivLock;
	private final ReadLock ivReadLock;
	private final WriteLock ivWriteLock;
	private final boolean ivBMT;

	public SingletonBeanO(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		super(c, mo, b, h);
		BeanMetaData bmd = this.home.beanMetaData;
		this.ivBMT = bmd.usesBeanManagedTx;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			if (this.ivBMT) {
				Tr.debug(tc, bmd.j2eeName + " - initialized for bean managed transaction");
			} else {
				Tr.debug(tc, bmd.j2eeName + " - initialized for container managed transaction");
			}
		}

		this.ivContainerManagedConcurrency = !bmd.ivSingletonUsesBeanManagedConcurrency;
		if (this.ivContainerManagedConcurrency) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, bmd.j2eeName + " - initializing for container managed concurrency control");
			}

			this.ivLock = new ReentrantReadWriteLock(ContainerProperties.UseFairSingletonLockingPolicy);
			this.ivReadLock = this.ivLock.readLock();
			this.ivWriteLock = this.ivLock.writeLock();
		} else {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, bmd.j2eeName + " - initializing for bean managed concurrency control");
			}

			this.ivLock = null;
			this.ivReadLock = null;
			this.ivWriteLock = null;
		}

	}

	private void callTransactionalLifecycleInterceptors(InterceptorProxy[] proxies, int methodId)
			throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		LifecycleInterceptorWrapper wrapper = new LifecycleInterceptorWrapper(this.container, this);
		EJSDeployedSupport s = new EJSDeployedSupport();
		s.ivIgnoreApplicationExceptions = true;

		try {
			this.container.preInvokeForLifecycleInterceptors(wrapper, methodId, s, this);
			if (isTraceOn) {
				if (TEBeanLifeCycleInfo.isTraceEnabled()) {
					TEBeanLifeCycleInfo.traceEJBCallEntry(LifecycleInterceptorWrapper.TRACE_NAMES[methodId]);
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "callLifecycleInterceptors");
				}
			}

			InvocationContextImpl inv = new InvocationContextImpl();
			inv.initialize(this.ivEjbInstance, this.ivInterceptors);
			BeanMetaData bmd = this.home.beanMetaData;
			inv.doLifeCycle(proxies, bmd._moduleMetaData);
		} catch (Throwable var11) {
			s.setUncheckedLocalException(var11);
		} finally {
			if (isTraceOn && TEBeanLifeCycleInfo.isTraceEnabled()) {
				TEBeanLifeCycleInfo.traceEJBCallExit(LifecycleInterceptorWrapper.TRACE_NAMES[methodId]);
			}

			this.container.postInvokeForLifecycleInterceptors(wrapper, methodId, s);
		}

	}

	protected final void initialize() throws RemoteException {
		this.stateStrs = StateStrs;
		this.state = 1;
		BeanMetaData bmd = this.home.beanMetaData;
		this.setId(this.home.ivStatelessId);
		InterceptorMetaData imd = bmd.ivInterceptorMetaData;
		UnspecifiedContextHelper contextHelper = new UnspecifiedContextHelper(this);
		contextHelper.begin(true);

		try {
			if (imd != null) {
				this.createInterceptors(imd);
			}

			if (bmd.ivBeanInjectionTargets != null) {
				try {
					InjectionEngine injectionEngine = this.getInjectionEngine();
					InjectionTarget[] targets = bmd.ivBeanInjectionTargets;
					if (targets != null) {
						InjectionTarget[] arr$ = targets;
						int len$ = targets.length;

						for (int i$ = 0; i$ < len$; ++i$) {
							InjectionTarget injectionTarget = arr$[i$];
							injectionEngine.inject(this.ivEjbInstance, injectionTarget, this);
						}
					}
				} catch (Throwable var13) {
					FFDCFilter.processException(var13, CLASS_NAME + ".<init>", "226", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Injection failure", var13);
					}

					throw ExceptionUtil.EJBException("Injection failure", var13);
				}
			}
		} finally {
			contextHelper.complete(true);
		}

		this.setState(2);
		if (imd != null && this.ivCallbackKind == CallbackKind.InvocationContext) {
			InterceptorProxy[] proxies = imd.ivPostConstructInterceptors;
			if (proxies != null) {
				this.callTransactionalLifecycleInterceptors(proxies, 0);
			}
		}

		this.setState(3);
	}

	HandleList getHandleList(boolean create) {
		HandleList hl;
		if (this.state != 1 && this.state != 2) {
			EJSDeployedSupport s = EJSContainer.getMethodContext();
			hl = s.ivHandleList;
			if (hl == null && create) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getHandleList: created " + hl);
				}

				hl = new HandleList();
				s.ivHandleList = hl;
			}
		} else {
			hl = super.getHandleList(create);
		}

		return hl;
	}

	HandleListInterface reAssociateHandleList() {
		return HandleListProxy.INSTANCE;
	}

	void parkHandleList() {
		if (this.state != 1 && this.state != 2) {
			EJSDeployedSupport s = EJSContainer.getMethodContext();
			HandleList hl = s.ivHandleList;
			if (hl != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "parkHandleList: closing " + hl);
				}

				hl.close();
			}
		} else {
			this.destroyHandleList();
		}

	}

	public Object preInvoke(EJSDeployedSupport s, ContainerTx tx) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "preInvoke");
		}

		s.ivLockAcquired = false;
		if (this.ivContainerManagedConcurrency) {
			EJBMethodInfoImpl mInfo = s.methodInfo;
			LockType lockType = mInfo.ivLockType;
			if (lockType == LockType.WRITE && !this.ivLock.isWriteLockedByCurrentThread()
					&& this.ivLock.getReadHoldCount() > 0) {
				throw new IllegalLoopbackException(
						"A loopback method call is not allowed to upgrade from a READ to a WRITE lock.");
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "preInvoke attempting to acquire a " + mInfo.ivLockType.name() + " lock. "
						+ this.ivLock.toString());
			}

			long lockStartTime = 0L;
			byte lockStatType = 0;
			boolean var17 = false;

			long timeout;
			try {
				var17 = true;
				timeout = mInfo.ivAccessTimeout;
				if (timeout == -1L) {
					if (lockType == LockType.READ) {
						if (this.pmiBean != null) {
							lockStatType = 36;
							lockStartTime = this.pmiBean.initalTime(lockStatType);
						}

						this.ivReadLock.lock();
					} else {
						if (this.pmiBean != null) {
							lockStatType = 37;
							lockStartTime = this.pmiBean.initalTime(lockStatType);
						}

						this.ivWriteLock.lock();
					}

					s.ivLockAcquired = true;
					if (isTraceOn) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "preInvoke acquired a " + mInfo.ivLockType.name() + " lock. "
									+ this.ivLock.toString());
							var17 = false;
						} else {
							var17 = false;
						}
					} else {
						var17 = false;
					}
				} else {
					try {
						if (lockType == LockType.READ) {
							if (this.pmiBean != null) {
								lockStatType = 36;
								lockStartTime = this.pmiBean.initalTime(lockStatType);
							}

							s.ivLockAcquired = this.ivReadLock.tryLock(timeout, TimeUnit.MILLISECONDS);
						} else {
							if (this.pmiBean != null) {
								lockStatType = 37;
								lockStartTime = this.pmiBean.initalTime(lockStatType);
							}

							s.ivLockAcquired = this.ivWriteLock.tryLock(timeout, TimeUnit.MILLISECONDS);
						}

						if (!s.ivLockAcquired) {
							if (this.pmiBean != null) {
								this.pmiBean.countCancelledLocks();
							}

							throw new ConcurrentAccessTimeoutException(
									"preInvoke timed out in attempt to acquire a " + mInfo.ivLockType.name()
											+ " lock for method signature = " + mInfo.getMethodSignature()
											+ ".  Access timeout value = " + timeout + " milli-seconds");
						}

						if (isTraceOn) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "preInvoke acquired a " + mInfo.ivLockType.name() + " lock. "
										+ this.ivLock.toString());
								var17 = false;
							} else {
								var17 = false;
							}
						} else {
							var17 = false;
						}
					} catch (InterruptedException var18) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "InterruptedException prevented lock from being acquired.");
						}

						if (this.pmiBean != null) {
							this.pmiBean.countCancelledLocks();
						}

						throw ExceptionUtil.EJBException("InterruptedException prevented lock from being acquired.",
								var18);
					}
				}
			} finally {
				if (var17) {
					if (this.pmiBean != null) {
						long lockDuration = this.pmiBean.finalTime(lockStatType, lockStartTime);
						if (lockDuration > 0L) {
							s.pmiCookie += lockDuration;
						}
					}

				}
			}

			if (this.pmiBean != null) {
				timeout = this.pmiBean.finalTime(lockStatType, lockStartTime);
				if (timeout > 0L) {
					s.pmiCookie += timeout;
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "preInvoke");
		}

		return this.ivEjbInstance;
	}

	public void postInvoke(int id, EJSDeployedSupport s) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "postInvoke");
		}

		if (this.ivContainerManagedConcurrency && s.ivLockAcquired) {
			EJBMethodInfoImpl mInfo = s.methodInfo;
			LockType lockType = mInfo.ivLockType;
			if (lockType == LockType.READ) {
				this.ivReadLock.unlock();
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "postInvoke released read lock: " + this.ivLock.toString());
				}
			} else {
				this.ivWriteLock.unlock();
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "postInvoke released write lock: " + this.ivLock.toString());
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "postInvoke");
		}

	}

	public boolean getRollbackOnly() {
		if (this.ivBMT) {
			throw new IllegalStateException("getRollbackOnly not allowed for bean managed transaction.");
		} else if (this.state > 1) {
			return super.getRollbackOnly();
		} else {
			throw new IllegalStateException(
					"setRollbackOnly operation not allowed in current state: " + StateStrs[this.state]);
		}
	}

	public void setRollbackOnly() {
		if (this.ivBMT) {
			throw new IllegalStateException("getRollbackOnly not allowed for bean managed transaction.");
		} else if (this.state > 1) {
			super.setRollbackOnly();
		} else {
			throw new IllegalStateException(
					"setRollbackOnly operation not allowed in current state: " + StateStrs[this.state]);
		}
	}

	public final UserTransaction getUserTransaction() throws IllegalStateException {
		if (this.ivBMT) {
			if (this.state <= 1) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Incorrect state: " + this.stateStrs[this.state]);
				}

				throw new IllegalStateException(this.stateStrs[this.state]);
			} else {
				return UserTransactionWrapper.INSTANCE;
			}
		} else {
			throw new IllegalStateException(
					"getUserTransaction not allowed for Singleton with container managed transactions.");
		}
	}

	public final void activate(BeanId arg0, ContainerTx arg1) throws RemoteException {
	}

	public final void checkTimerServiceAccess() throws IllegalStateException {
		if (this.state < 2) {
			IllegalStateException ise = new IllegalStateException(
					"Singleton Session Bean: Timer Service methods not allowed from state = "
							+ this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerServiceAccess: " + ise);
			}

			throw ise;
		}
	}

	public final TimerService getTimerService() throws IllegalStateException {
		if (this.state < 2) {
			IllegalStateException ise = new IllegalStateException(
					"Singleton: getTimerService not allowed from state = " + this.stateStrs[this.state]);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getTimerService: " + ise);
			}

			throw ise;
		} else {
			return super.getTimerService();
		}
	}

	public final void commit(ContainerTx arg0) throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Singleton commit not allowed");
	}

	public final synchronized void destroy() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy");
		}

		if (this.state != 0) {
			long removeStartTime = -1L;
			if (this.pmiBean != null) {
				removeStartTime = this.pmiBean.initalTime(15);
			}

			this.setState(4);
			if (this.ivCallbackKind == CallbackKind.InvocationContext) {
				InterceptorMetaData imd = this.home.beanMetaData.ivInterceptorMetaData;
				InterceptorProxy[] proxies = imd.ivPreDestroyInterceptors;
				if (proxies != null) {
					try {
						this.callTransactionalLifecycleInterceptors(proxies, 1);
					} catch (Throwable var7) {
						FFDCFilter.processException(var7, CLASS_NAME + ".destroy", "824", this);
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "destroy caught exception", new Object[]{this, var7});
						}
					}
				}
			}

			this.setState(0);
			this.releaseManagedObjectState();
			if (this.pmiBean != null) {
				this.pmiBean.beanDestroyed();
				this.pmiBean.finalTime(15, removeStartTime);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "destroy");
			}

		}
	}

	public void discard() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "discard: " + this.stateStrs[this.state]);
		}

		if (this.state == 1 || this.state == 2) {
			this.setState(0);
			this.releaseManagedObjectState();
			if (this.pmiBean != null) {
				this.pmiBean.discardCount();
				this.pmiBean.beanDestroyed();
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "discard");
		}

	}

	public final boolean enlist(ContainerTx arg0) throws RemoteException {
		return false;
	}

	public final EnterpriseBean getEnterpriseBean() throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Singleton getEnterpriseBean not allowed");
	}

	public final boolean isDiscarded() {
		return false;
	}

	public final boolean isRemoved() {
		return false;
	}

	public final void passivate() throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Singleton passivate not allowed");
	}

	public final void remove() throws RemoteException, RemoveException {
	}

	public final void rollback(ContainerTx arg0) throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Singleton rollback not allowed");
	}

	public final void store() throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Singleton store not allowed");
	}

	public final void beforeCompletion() throws RemoteException {
		throw new InvalidBeanOStateException(StateStrs[this.state], "NONE: Singleton beforeCompletion is not allowed");
	}

	public final void postCreate(boolean arg0) {
		throw new NotImplementedException();
	}

	public final Principal getCallerPrincipal() {
		if (this.state == 3) {
			return super.getCallerPrincipal();
		} else {
			throw new IllegalStateException(
					"For Singleton, getCallerPrincipal only allowed while in METHOD_READY state");
		}
	}

	public final boolean isCallerInRole(String roleName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCallerInRole, role = " + roleName + ", state = " + StateStrs[this.state]);
		}

		if (this.state == 3) {
			boolean inRole = super.isCallerInRole(roleName, this.ivEjbInstance);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "isCallerInRole: " + inRole);
			}

			return inRole;
		} else {
			throw new IllegalStateException("For Singleton, isCallerInRole only allowed while in METHOD_READY state");
		}
	}

	@Deprecated
	public final Identity getCallerIdentity() {
		throw new IllegalStateException("getCallerIdentity is deprecated, getCallerPrincipal must be used.");
	}

	@Deprecated
	public final boolean isCallerInRole(Identity id) {
		throw new IllegalStateException("isCallerInRole(Identity) is deprecated, isCallerInRole(Strimg) must be used.");
	}

	public final EJBLocalObject getEJBLocalObject() throws IllegalStateException {
		throw new IllegalStateException("getEJBLocalObject not allowed for Singleton.");
	}

	public final EJBObject getEJBObject() throws IllegalStateException {
		throw new IllegalStateException("getEJBObject not allowed for Singleton.");
	}

	public final EJBHome getEJBHome() {
		throw new IllegalStateException("getEJBHome not allowed for Singleton.");
	}

	public final EJBLocalHome getEJBLocalHome() {
		throw new IllegalStateException("getEJBLocalHome not allowed for Singleton.");
	}

	public final Properties getEnvironment() {
		throw new IllegalStateException("deprecated getEnvironment not allowed for Singleton.");
	}

	public final Class<?> getInvokedBusinessInterface() throws IllegalStateException {
		if (this.state == 3) {
			return super.getInvokedBusinessInterface();
		} else {
			throw new IllegalStateException(
					"For Singleton, getInvokedBusinessInterface only allowed while in METHOD_READY state");
		}
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		StateStrs = new String[]{"DESTROYED", "PRE_CREATE", "CREATING", "METHOD_READY", "PRE_DESTROY"};
	}
}