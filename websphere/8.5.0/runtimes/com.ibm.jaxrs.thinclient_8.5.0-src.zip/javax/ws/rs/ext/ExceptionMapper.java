package javax.ws.rs.ext;

import javax.ws.rs.core.Response;

public interface ExceptionMapper<T extends Throwable> {
	Response toResponse(T var1);
}