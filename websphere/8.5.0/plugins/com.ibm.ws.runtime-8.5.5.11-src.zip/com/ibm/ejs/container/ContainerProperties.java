package com.ibm.ejs.container;

import com.ibm.ejs.container.util.DeploymentUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.ws.ejbcontainer.diagnostics.TrDumpWriter;
import com.ibm.wsspi.ejbcontainer.JITDeploy;
import java.util.ArrayList;

public final class ContainerProperties {
	private static final String CLASS_NAME = ContainerProperties.class.getName();
	private static final TraceComponent tc;
	public static final String AllowCachedTimerDataFor;
	public static final String AllowCustomFinderSQLForUpdate;
	public static final boolean AllowEarlyInsert;
	public static final boolean AllowPrimaryKeyMutation;
	private static final int ALLOW_SPEC_VIOLATION_ON_ROLLBACK = 4;
	public static final boolean AllowSpecViolationOnRollback;
	public static final long AsyncNoResponseBackoff;
	public static final boolean BlockWorkUntilAppStarted;
	public static final long BlockWorkUntilAppStartedWaitTime;
	public static final boolean CheckAppConfig;
	public static final boolean CreateInstanceAtStart;
	public static final boolean DeclaredUncheckedAreSystemExceptions;
	public static final long DefaultSessionAccessTimeout;
	public static final long DefaultStatefulSessionTimeout;
	public static final boolean DisableAsyncMethods;
	public static final boolean DisableAsyncResultRetries;
	public static final boolean DisableAutomaticLightweightMethods;
	public static final boolean DisableMDBs;
	public static final boolean DisableRemote;
	public static final ArrayList<String> DisableShortDefaultBindings;
	public static final boolean DisableTimers;
	public static final boolean DisablePersistentTimers;
	public static final boolean EE5Compatibility;
	public static final boolean ExcludeNestedExceptions;
	public static final boolean ExpandCMPCFJNDIName;
	public static final ArrayList<String> ExtendSetRollbackOnlyBehaviorBeyondInstanceFor;
	public static final boolean FbpkAlwaysReadOnly;
	public static final boolean IgnoreDuplicateEJBBindings;
	private static final int INCLUDE_NESTED_EXCEPTIONS = 1;
	public static final boolean IncludeNestedExceptions;
	private static final int INCLUDE_NESTED_EXCEPTIONS_EXTENDED = 2;
	public static final boolean IncludeNestedExceptionsExtended;
	public static final boolean IndirectLocalProxies;
	public static final String InitializeEJBsAtStartup;
	public static final ArrayList<String> LimitSetRollbackOnlyBehaviorToInstanceFor;
	public static final String LineSeparator;
	public static final long MaxAsyncResultWaitTime;
	public static final int MaxUnclaimedAsyncResults;
	public static final boolean NoEJBPool;
	public static final boolean NoPrimaryKeyMutation;
	public static final String PassivationPolicy;
	public static final boolean PI10351;
	public static final String PoolSize;
	public static final boolean Portable;
	public static final String PortableFinder;
	public static final int RMICCompatible;
	public static final long TimerCancelTimeout;
	public static final boolean TimerQOSAtLeastOnceForRequired;
	public static final boolean UseFairSingletonLockingPolicy;
	public static final String UserInstallRoot;
	public static final boolean ValidateMergedXML;
	public static final boolean ValidateMergedXMLFail;
	public static final boolean WLMAllowOptionAReadOnly;

	public static void introspect(IntrospectionWriter writer) {
		writer.printHeader("Container Properties");
		writer.println("Property: AllowCachedTimerDataFor = " + AllowCachedTimerDataFor);
		writer.println("Property: AllowCustomFinderSQLForUpdate = " + AllowCustomFinderSQLForUpdate);
		writer.println("Property: AllowEarlyInsert        = " + AllowEarlyInsert);
		writer.println("Property: AllowPrimaryKeyMutation = " + AllowPrimaryKeyMutation);
		writer.println("Property: AllowSpecViolationOnRollback = " + AllowSpecViolationOnRollback);
		writer.println("Property: AsyncResultNoResponseBackoff = " + AsyncNoResponseBackoff);
		writer.println("Property: BlockWorkUntilAppStarted = " + BlockWorkUntilAppStarted);
		writer.println("Property: BlockWorkUntilAppStartedWaitTime = " + BlockWorkUntilAppStartedWaitTime);
		writer.println("Property: CheckAppConfig          = " + CheckAppConfig);
		writer.println("Property: CreateInstanceAtStart   = " + CreateInstanceAtStart);
		writer.println("Property: DefaultSessionAccessTimeout = " + DefaultSessionAccessTimeout);
		writer.println("Property: DefaultStatefulSessionTimeout  = " + DefaultStatefulSessionTimeout);
		writer.println("Property: DisableAsyncMethods     = " + DisableAsyncMethods);
		writer.println("Property: DisableAsyncResultRetries = " + DisableAsyncResultRetries);
		writer.println("Property: DisableAutomaticLightweightMethods = " + DisableAutomaticLightweightMethods);
		writer.println("Property: DisableMDBs             = " + DisableMDBs);
		writer.println("Property: DisableRemote           = " + DisableRemote);
		writer.println("Property: DisableShortDefaultBindings = " + DisableShortDefaultBindings);
		writer.println("Property: DisableTimers           = " + DisableTimers);
		writer.println("Property: DisablePersistentTimers = " + DisablePersistentTimers);
		writer.println("Property: EE5Compatibility        = " + EE5Compatibility);
		writer.println("Property: ExcludeNestedExceptions = " + ExcludeNestedExceptions);
		writer.println("Property: ExpandCMPCFJNDIName     = " + ExpandCMPCFJNDIName);
		writer.println("Property: FbpkAlwaysReadOnly      = " + FbpkAlwaysReadOnly);
		writer.println("Property: IgnoreDuplicateEJBBindings = " + IgnoreDuplicateEJBBindings);
		writer.println("Property: IncludeNestedExceptions = " + IncludeNestedExceptions);
		writer.println("Property: IncludeNestedExceptionsExtended = " + IncludeNestedExceptionsExtended);
		writer.println("Property: IndirectLocalProxies    = " + IndirectLocalProxies);
		writer.println("Property: InitializeEJBsAtStartup = " + InitializeEJBsAtStartup);
		writer.println("Property: MaxAsyncResultWaitTime  = " + MaxAsyncResultWaitTime);
		writer.println("Property: MaxUnclaimedAsyncResults = " + MaxUnclaimedAsyncResults);
		writer.println("Property: NoEJBPool               = " + NoEJBPool);
		writer.println("Property: NoPrimaryKeyMutation    = " + NoPrimaryKeyMutation);
		writer.println("Property: PassivationPolicy       = " + PassivationPolicy);
		writer.println("Property: PoolSize                = " + PoolSize);
		writer.println("Property: PI10351                 = " + PI10351);
		writer.println("Property: Portable                = " + Portable);
		writer.println("Property: PortableFinder          = " + PortableFinder);
		writer.println("Property: RMICCompatible          = " + RMICCompatible);
		writer.println("Property: TimerCancelTimeout      = " + TimerCancelTimeout);
		writer.println("Property: TimerQOSAtLeastOnceForRequired = " + TimerQOSAtLeastOnceForRequired);
		writer.println("Property: UseFairSingletonLockingPolicy = " + UseFairSingletonLockingPolicy);
		writer.println("Property: UserInstallRoot         = " + UserInstallRoot);
		writer.println("Property: WLMAllowOptionAReadOnly = " + WLMAllowOptionAReadOnly);
		writer.println("Property: ExtendSetRollbackOnlyBehaviorBeyondInstanceFor = "
				+ ExtendSetRollbackOnlyBehaviorBeyondInstanceFor);
		writer.println(
				"Property: LimitSetRollbackOnlyBehaviorToInstanceFor = " + LimitSetRollbackOnlyBehaviorToInstanceFor);
		writer.printFooter();
	}

	public static Class<ContainerProperties> init() {
		return ContainerProperties.class;
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		AsyncNoResponseBackoff = ClientAsyncResult.AsyncResultNoResponseBackoff;
		DisableAsyncResultRetries = ClientAsyncResult.DisableAsyncResultRetries;
		RMICCompatible = JITDeploy.RMICCompatible;
		AllowCachedTimerDataFor = System.getProperty("com.ibm.websphere.ejbcontainer.allowCachedTimerDataFor");
		AllowCustomFinderSQLForUpdate = System
				.getProperty("com.ibm.websphere.ejbcontainer.customfinder.honorAccessIntent");
		AllowEarlyInsert = System.getProperty("com.ibm.websphere.ejbcontainer.allowEarlyInsert", "false")
				.equalsIgnoreCase("true");
		AllowPrimaryKeyMutation = System.getProperty("com.ibm.websphere.ejbcontainer.allowPrimaryKeyMutation", "false")
				.equalsIgnoreCase("true");
		CheckAppConfig = System.getProperty("com.ibm.websphere.ejbcontainer.checkEJBApplicationConfiguration", "false")
				.equalsIgnoreCase("true");
		CreateInstanceAtStart = System.getProperty("com.ibm.websphere.ejbcontainer.createInstanceAtStart", "true")
				.equalsIgnoreCase("true");
		DeclaredUncheckedAreSystemExceptions = DeploymentUtil.DeclaredUncheckedAreSystemExceptions;
		long accessTimeout = Long.getLong("com.ibm.websphere.ejbcontainer.defaultSessionAccessTimeout", -1L);
		DefaultSessionAccessTimeout = accessTimeout >= -1L ? accessTimeout : -1L;
		long tmpStatefulSessionTimeout = 10L;
		boolean caughtNFE = false;

		try {
			tmpStatefulSessionTimeout = Long.getLong("com.ibm.websphere.ejbcontainer.defaultStatefulSessionTimeout",
					10L);
			if (tmpStatefulSessionTimeout == 0L) {
				tmpStatefulSessionTimeout = 10L;
			} else if (tmpStatefulSessionTimeout < 0L) {
				caughtNFE = true;
			}
		} catch (NumberFormatException var14) {
			caughtNFE = true;
		}

		if (caughtNFE) {
			Object[] parms = new Object[]{"com.ibm.websphere.ejbcontainer.defaultStatefulSessionTimeout",
					tmpStatefulSessionTimeout, "10"};
			Tr.warning(tc, "INVALID_STATEFUL_TIMEOUT_TIMEOUT_CNTR0313W", parms);
			tmpStatefulSessionTimeout = 10L;
		}

		tmpStatefulSessionTimeout = tmpStatefulSessionTimeout * 60L * 1000L;
		DefaultStatefulSessionTimeout = tmpStatefulSessionTimeout;
		DisableAsyncMethods = System.getProperty("com.ibm.ws.ejbcontainer.disableAsyncMethods", "false")
				.equalsIgnoreCase("true");
		DisableAutomaticLightweightMethods = System
				.getProperty("com.ibm.websphere.ejbcontainer.disableAutomaticLightweightMethods", "false")
				.equalsIgnoreCase("true");
		DisableMDBs = System.getProperty("com.ibm.ws.ejbcontainer.disableMDBs", "false").equalsIgnoreCase("true");
		DisableRemote = System.getProperty("com.ibm.ws.ejbcontainer.disableRemote", "false").equalsIgnoreCase("true");
		DisableTimers = System.getProperty("com.ibm.ws.ejbcontainer.disableTimers", "false").equalsIgnoreCase("true");
		DisablePersistentTimers = System.getProperty("com.ibm.websphere.ejbcontainer.disablePersistentTimers", "false")
				.equalsIgnoreCase("true");
		EE5Compatibility = Boolean.getBoolean("com.ibm.websphere.ejbcontainer.EE5Compatibility");
		ExcludeNestedExceptions = Boolean.getBoolean("com.ibm.websphere.ejbcontainer.excludeRootExceptionOnRollback");
		ExpandCMPCFJNDIName = System.getProperty("com.ibm.websphere.ejbcontainer.expandCMPCFJNDIName", "true")
				.equalsIgnoreCase("true");
		FbpkAlwaysReadOnly = System.getProperty("com.ibm.websphere.ejbcontainer.FbpkAlwaysReadOnly", "false")
				.equalsIgnoreCase("true");
		IgnoreDuplicateEJBBindings = Boolean.getBoolean("com.ibm.websphere.ejbcontainer.ignoreDuplicateEJBBindings");
		String tmp = System.getProperty("com.ibm.websphere.ejbcontainer.includeRootExceptionOnRollback");
		int op = 0;
		if (tmp != null) {
			if ("true".equalsIgnoreCase(tmp)) {
				op = 1;
			} else {
				try {
					op = Integer.parseInt(tmp);
				} catch (NumberFormatException var15) {
					op = 0;
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Caught NumberFormatException: " + var15);
					}
				}
			}
		}

		IncludeNestedExceptionsExtended = (op & 2) > 0;
		AllowSpecViolationOnRollback = (op & 4) > 0;
		IncludeNestedExceptions = (op & 1) > 0 || IncludeNestedExceptionsExtended;
		IndirectLocalProxies = Boolean.getBoolean("com.ibm.websphere.ejbcontainer.indirectLocalProxies");
		InitializeEJBsAtStartup = System.getProperty("com.ibm.websphere.ejbcontainer.initializeEJBsAtStartup");
		LineSeparator = System.getProperty("line.separator", "\n");
		MaxAsyncResultWaitTime = (long) (Integer.getInteger("com.ibm.websphere.ejbcontainer.maxAsyncResultWaitTime",
				150) * 1000);
		MaxUnclaimedAsyncResults = Integer.getInteger("com.ibm.websphere.ejbcontainer.maxUnclaimedAsyncResults", 1000);
		NoEJBPool = System.getProperty("com.ibm.websphere.ejbcontainer.noEJBPool", "false").equalsIgnoreCase("true");
		NoPrimaryKeyMutation = System.getProperty("com.ibm.websphere.ejbcontainer.noPrimaryKeyMutation", "false")
				.equalsIgnoreCase("true");
		PassivationPolicy = System.getProperty("com.ibm.websphere.csi.passivationpolicy");
		PI10351 = Boolean.getBoolean("com.ibm.websphere.ejbcontainer.PI10351");
		PoolSize = System.getProperty("com.ibm.websphere.ejbcontainer.poolSize");
		Portable = System.getProperty("com.ibm.websphere.container.portable", "true").equalsIgnoreCase("true");
		PortableFinder = System.getProperty("com.ibm.websphere.container.portable.finder");
		TimerCancelTimeout = (long) (Integer.getInteger("com.ibm.websphere.ejbcontainer.timerCancelTimeout", 60)
				* 1000);
		TimerQOSAtLeastOnceForRequired = Boolean
				.getBoolean("com.ibm.websphere.ejbcontainer.timerQOSAtLeastOnceForRequired");
		UseFairSingletonLockingPolicy = Boolean
				.getBoolean("com.ibm.websphere.ejbcontainer.useFairSingletonLockingPolicy");
		BlockWorkUntilAppStarted = Boolean.getBoolean("com.ibm.websphere.ejbcontainer.blockWorkUntilAppStarted");
		BlockWorkUntilAppStartedWaitTime = (long) (Integer
				.getInteger("com.ibm.websphere.ejbcontainer.blockWorkUntilAppStartedWaitTime", 120) * 1000);
		String installRoot = System.getProperty("user.install.root");
		if (installRoot == null) {
			installRoot = System.getProperty("was.install.root", "");
		}

		UserInstallRoot = installRoot;
		String validateMergedXMLValue = System.getProperty("com.ibm.websphere.ejbcontainer.validateMergedXML");
		ValidateMergedXMLFail = "fail".equals(validateMergedXMLValue);
		ValidateMergedXML = ValidateMergedXMLFail | "log".equals(validateMergedXMLValue);
		WLMAllowOptionAReadOnly = System.getProperty("com.ibm.websphere.ejbcontainer.wlmAllowOptionAReadOnly", "false")
				.equalsIgnoreCase("true");
		String simpleIntBindingsProperty = System
				.getProperty("com.ibm.websphere.ejbcontainer.disableShortDefaultBindings");
		if (simpleIntBindingsProperty != null) {
			DisableShortDefaultBindings = new ArrayList();
			if (!simpleIntBindingsProperty.equalsIgnoreCase("*")) {
				String[] apps = simpleIntBindingsProperty.split(":");

				for (int i = 0; i < apps.length; ++i) {
					DisableShortDefaultBindings.add(apps[i]);
				}
			}
		} else {
			DisableShortDefaultBindings = null;
		}

		String extendSetRollbackOnlyProperty = System
				.getProperty("com.ibm.websphere.ejbcontainer.extendSetRollbackOnlyBehaviorBeyondInstanceFor");
		if (extendSetRollbackOnlyProperty != null) {
			ExtendSetRollbackOnlyBehaviorBeyondInstanceFor = new ArrayList();
			String[] apps = extendSetRollbackOnlyProperty.split(":");

			for (int i = 0; i < apps.length; ++i) {
				ExtendSetRollbackOnlyBehaviorBeyondInstanceFor.add(apps[i]);
			}
		} else {
			ExtendSetRollbackOnlyBehaviorBeyondInstanceFor = null;
		}

		String limitSetRollbackOnlyProperty = System
				.getProperty("com.ibm.websphere.ejbcontainer.limitSetRollbackOnlyBehaviorToInstanceFor");
		if (limitSetRollbackOnlyProperty != null) {
			LimitSetRollbackOnlyBehaviorToInstanceFor = new ArrayList();
			String[] apps = limitSetRollbackOnlyProperty.split(":");

			for (int i = 0; i < apps.length; ++i) {
				LimitSetRollbackOnlyBehaviorToInstanceFor.add(apps[i]);
			}
		} else {
			LimitSetRollbackOnlyBehaviorToInstanceFor = null;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			introspect(new TrDumpWriter(tc));
		}

	}
}