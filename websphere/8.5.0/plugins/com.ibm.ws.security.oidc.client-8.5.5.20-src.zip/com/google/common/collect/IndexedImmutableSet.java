package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;

@GwtCompatible(emulated = true)
abstract class IndexedImmutableSet<E> extends ImmutableSet<E> {
	abstract E get(int var1);

	public UnmodifiableIterator<E> iterator() {
		return this.asList().iterator();
	}

	@GwtIncompatible
	int copyIntoArray(Object[] dst, int offset) {
		return this.asList().copyIntoArray(dst, offset);
	}

	ImmutableList<E> createAsList() {
		return new ImmutableList<E>() {
			public E get(int index) {
				return IndexedImmutableSet.this.get(index);
			}

			boolean isPartialView() {
				return IndexedImmutableSet.this.isPartialView();
			}

			public int size() {
				return IndexedImmutableSet.this.size();
			}
		};
	}
}