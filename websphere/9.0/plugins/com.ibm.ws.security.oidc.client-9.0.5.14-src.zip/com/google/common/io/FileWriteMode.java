package com.google.common.io;

import com.google.common.annotations.GwtIncompatible;

@GwtIncompatible
public enum FileWriteMode {
	APPEND;
}