package com.ibm.ws.wim.security.authz;

import com.ibm.sec.authz.jaccx.resource.TreeBasedResource;
import commonj.sdo.DataObject;

public class EntityResource extends TreeBasedResource {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private DataObject root;
	private DataObject entity;
	private String entityType;
	private String resourceId;

	public EntityResource(DataObject var1, DataObject var2) {
		super("", "");
		this.root = var1;
		this.entity = var2;
	}

	public EntityResource(EntityResource var1, String var2, String var3) {
		super("", var3);
		this.root = var1.root;
		this.entity = var1.entity;
		this.entityType = var2;
		this.resourceId = var3;
	}

	public DataObject getRoot() {
		return this.root;
	}

	public DataObject getEntity() {
		return this.entity;
	}

	public String getEntityType() {
		return this.entityType;
	}

	public String getResourceId() {
		return this.resourceId;
	}
}