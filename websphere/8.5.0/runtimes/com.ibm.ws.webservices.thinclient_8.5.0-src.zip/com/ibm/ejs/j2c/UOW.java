package com.ibm.ejs.j2c;

public final class UOW {
	public static final int GLOBAL_TRAN_ACTIVE = 0;
	public static final int LOCAL_TRAN_ACTIVE = 1;
	public static final int NO_TRAN_ACTIVE = 2;
	public static final Object NULL_COORDINATOR = new Object();
	private int scope;
	private Object coordinator;

	UOW() {
		this.scope = 2;
		this.coordinator = NULL_COORDINATOR;
	}

	UOW(int scope, Object coordinator) {
		this.scope = scope;
		this.coordinator = coordinator;
	}

	public Object getCoordinator() {
		return this.coordinator;
	}

	public Object getJdbcCoordinator() {
		return this.coordinator == NULL_COORDINATOR ? null : this.coordinator;
	}

	public int getScope() {
		return this.scope;
	}

	public void setScope(int newScope) {
		this.scope = newScope;
	}

	public void setCoordinator(Object newCoordinator) {
		this.coordinator = newCoordinator;
	}
}