package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.TreeBasedTable.1;
import com.google.common.collect.TreeBasedTable.2;
import com.google.common.collect.TreeBasedTable.Factory;
import com.google.common.collect.TreeBasedTable.TreeRow;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;

@GwtCompatible(serializable = true)
public class TreeBasedTable<R, C, V> extends StandardRowSortedTable<R, C, V> {
	private final Comparator<? super C> columnComparator;
	private static final long serialVersionUID = 0L;

	public static <R extends Comparable, C extends Comparable, V> TreeBasedTable<R, C, V> create() {
		return new TreeBasedTable(Ordering.natural(), Ordering.natural());
	}

	public static <R, C, V> TreeBasedTable<R, C, V> create(Comparator<? super R> rowComparator,
			Comparator<? super C> columnComparator) {
		Preconditions.checkNotNull(rowComparator);
		Preconditions.checkNotNull(columnComparator);
		return new TreeBasedTable(rowComparator, columnComparator);
	}

	public static <R, C, V> TreeBasedTable<R, C, V> create(TreeBasedTable<R, C, ? extends V> table) {
		TreeBasedTable<R, C, V> result = new TreeBasedTable(table.rowComparator(), table.columnComparator());
		result.putAll(table);
		return result;
	}

	TreeBasedTable(Comparator<? super R> rowComparator, Comparator<? super C> columnComparator) {
		super(new TreeMap(rowComparator), new Factory(columnComparator));
		this.columnComparator = columnComparator;
	}

	@Deprecated
	public Comparator<? super R> rowComparator() {
		return this.rowKeySet().comparator();
	}

	@Deprecated
	public Comparator<? super C> columnComparator() {
		return this.columnComparator;
	}

	public SortedMap<C, V> row(R rowKey) {
		return new TreeRow(this, rowKey);
	}

	public SortedSet<R> rowKeySet() {
		return super.rowKeySet();
	}

	public SortedMap<R, Map<C, V>> rowMap() {
		return super.rowMap();
	}

	Iterator<C> createColumnKeyIterator() {
      Comparator<? super C> comparator = this.columnComparator();
      Iterator<C> merged = Iterators.mergeSorted(Iterables.transform(this.backingMap.values(), new 1(this)), comparator);
      return new 2(this, merged, comparator);
   }
}