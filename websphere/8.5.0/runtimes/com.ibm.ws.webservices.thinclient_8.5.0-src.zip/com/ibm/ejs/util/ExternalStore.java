package com.ibm.ejs.util;

import java.io.IOException;

public interface ExternalStore {
	String store(Object var1) throws IOException;

	void store(Object var1, Object var2) throws IOException;

	Object retrieve(Object var1) throws IOException, ClassNotFoundException;
}