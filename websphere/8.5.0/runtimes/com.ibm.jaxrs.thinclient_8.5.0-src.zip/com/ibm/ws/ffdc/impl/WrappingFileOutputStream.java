package com.ibm.ws.ffdc.impl;

import com.ibm.ws.exception.WsException;
import com.ibm.ws.ffdc.impl.WrappingFileOutputStream.1;
import com.ibm.ws.security.util.AccessController;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.security.PrivilegedActionException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WrappingFileOutputStream extends OutputStream {
	private static String className = "com.ibm.ws.ffdc.impl.WrappingFileOutputStream";
	private static Logger logger;
	private String ivMainFileName = null;
	private File ivMainFile = null;
	private String ivDirectory = null;
	private String ivNamePrefix = null;
	private String ivNameSuffix = null;
	private String ivSepChar = "_";
	private int ivMaxBackups;
	private String[] ivBackupFiles = null;
	private String ivPreviousTimeStamp = null;
	private int ivTimeStampCounter = 1;
	private DateFormat ivDateFormatter = new SimpleDateFormat("yy.M.d_H.mm.ss");
	private long ivMaxFileSize;
	private long ivCurFileSize = 0L;
	private FileOutputStream ivFileStream = null;

	public WrappingFileOutputStream(String fileName, int rollover, int maxBackups) throws IOException, WsException {
		this.ivMainFile = new File(fileName);
		this.ivMainFileName = fileName;
		int index = this.ivMainFileName.lastIndexOf(File.separator);
		if (index == -1) {
			throw new WsException(fileName + " does not contain a path separator character");
		} else {
			this.ivDirectory = this.ivMainFileName.substring(0, index);
			String fName = this.ivMainFileName.substring(index + 1, this.ivMainFileName.length());
			if (fName != null && !fName.equals("")) {
				index = fName.lastIndexOf(46);
				if (index == -1) {
					this.ivNamePrefix = fName;
					this.ivNameSuffix = null;
				} else {
					this.ivNamePrefix = fName.substring(0, index);
					this.ivNameSuffix = fName.substring(index, fName.length());
				}

				boolean exists = FFDCHelper.fileExists(this.ivMainFile);
				if (!exists) {
					this.ivCurFileSize = 0L;
				} else {
					this.ivCurFileSize = FFDCHelper.getFileLength(this.ivMainFile);
				}

				this.ivMaxFileSize = (long) rollover;
				this.ivMaxBackups = maxBackups;
				if (this.ivMaxBackups > 0) {
					this.ivBackupFiles = this.generateBackupFileList();
				}

				try {
					this.ivFileStream = createFileOutputStream(this.ivMainFileName, true);
					logger.logp(Level.FINEST, className, "<init>", "opened FileOutputStream - " + this.ivMainFileName);
				} catch (PrivilegedActionException var8) {
					throw new WsException(this.ivMainFileName + " failed to create", var8);
				}
			} else {
				throw new WsException(fileName + " is not a proper fully qualified file name");
			}
		}
	}

	public void write(int b) throws IOException {
		this.incrementCount(1);
		this.ivFileStream.write(b);
	}

	public void write(byte[] bytes) throws IOException {
		this.incrementCount(bytes.length);
		this.ivFileStream.write(bytes);
	}

	public void write(byte[] bytes, int off, int len) throws IOException {
		this.incrementCount(len);
		this.ivFileStream.write(bytes, off, len);
	}

	public void flush() throws IOException {
		this.ivFileStream.flush();
	}

	public void close() throws IOException {
		this.ivFileStream.close();
		logger.logp(Level.FINEST, className, "close", "closing FileOutputStream - " + this.ivMainFileName);
	}

	private void incrementCount(int count) throws IOException {
		this.ivCurFileSize += (long) count;
		if (this.ivCurFileSize >= this.ivMaxFileSize) {
			this.switchFiles();
			this.ivCurFileSize = (long) count;
		}

	}

	private void switchFiles() throws IOException {
		logger.entering(className, "switchFiles");
		this.ivFileStream.flush();
		this.ivFileStream.close();
		String backupFileName = this.createBackupFileName();
		File backup = new File(backupFileName);
		boolean success = FFDCHelper.renameFile(this.ivMainFile, backup);
		if (logger.isLoggable(Level.FINEST)) {
			String mainStr = this.ivMainFile == null ? "null" : this.ivMainFile.getCanonicalPath();
			String backupStr = backup == null ? "null" : backup.getCanonicalPath();
			String successStr = success ? "Succeeded" : "Failed";
			logger.logp(Level.FINEST, className, "switchFiles", "{0} in renaming {1} to {2}",
					new Object[]{successStr, mainStr, backupStr});
		}

		try {
			this.ivFileStream = createFileOutputStream(this.ivMainFileName, false);
		} catch (PrivilegedActionException var7) {
			IOException ex = new IOException(this.ivMainFileName + " failed to create");
			logger.exiting(className, "switchFiles", ex);
			throw ex;
		}

		this.ivCurFileSize = 0L;
		logger.exiting(className, "switchFiles");
	}

	private String createBackupFileName() {
		Date date = new Date(System.currentTimeMillis());
		String ts = this.ivDateFormatter.format(date);
		if (this.ivPreviousTimeStamp == null) {
			this.ivPreviousTimeStamp = ts;
		} else {
			if (this.ivPreviousTimeStamp.startsWith(ts)) {
				ts = ts + Integer.toHexString(this.ivTimeStampCounter++);
			}

			this.ivPreviousTimeStamp = ts;
		}

		String backupFileName = this.ivDirectory + File.separator + this.ivNamePrefix + this.ivSepChar + ts
				+ this.ivNameSuffix;
		if (this.ivBackupFiles == null) {
			this.ivBackupFiles = new String[]{null};
		}

		int lastIndex = this.ivBackupFiles.length - 1;
		String oldName = this.ivBackupFiles[lastIndex];
		if (oldName != null) {
			FFDCHelper.deleteFile(new File(oldName));
		}

		int i = lastIndex;

		for (int j = lastIndex - 1; i > 0; --j) {
			this.ivBackupFiles[i] = this.ivBackupFiles[j];
			--i;
		}

		this.ivBackupFiles[0] = backupFileName;
		return backupFileName;
	}

	private String[] generateBackupFileList() {
		String[] files = FFDCHelper.listFileNames(new File(this.ivDirectory));
		if (files != null && files.length != 0) {
			String dir = this.ivDirectory + File.separator;
			int size = files.length;
			Vector fileNames = new Vector(size);
			Vector timestamps = new Vector(size);
			int arrayIndex = 0;

			for (int i = 0; i < size; ++i) {
				String fqFileName = dir + files[i];
				File candidate = new File(fqFileName);
				if (FFDCHelper.isFile(candidate)) {
					long time = this.getFileTimestamp(files[i]);
					if (time != 0L) {
						fileNames.addElement(fqFileName);
						timestamps.addElement(new Long(time));
						++arrayIndex;
					}
				}
			}

			if (!fileNames.isEmpty()) {
				return this.sortAndDeleteFiles(fileNames, timestamps);
			} else {
				String[] retVal = new String[this.ivMaxBackups];

				for (int i = 0; i < this.ivMaxBackups; ++i) {
					retVal[i] = null;
				}

				return retVal;
			}
		} else {
			return new String[this.ivMaxBackups];
		}
	}

	private long getFileTimestamp(String fileName) {
		if (fileName.startsWith(this.ivNamePrefix)) {
			fileName = fileName.substring(this.ivNamePrefix.length() + 1);
			if (this.ivNameSuffix != null) {
				if (!fileName.endsWith(this.ivNameSuffix)) {
					return 0L;
				}

				fileName = fileName.substring(0, fileName.length() - this.ivNameSuffix.length());
			}

			try {
				Date date = this.ivDateFormatter.parse(fileName);
				return date.getTime();
			} catch (Throwable var3) {
				return 0L;
			}
		} else {
			return 0L;
		}
	}

	private String[] sortAndDeleteFiles(Vector fileNameVector, Vector timestampsVector) {
		int size = fileNameVector.size();
		String[] fileNames = new String[size];
		long[] timestamps = new long[size];

		int length;
		for (length = 0; length < size; ++length) {
			fileNames[length] = (String) fileNameVector.elementAt(length);
			timestamps[length] = (Long) timestampsVector.elementAt(length);
		}

		length = fileNames.length;
		boolean changed = true;

		int i;
		while (changed) {
			changed = false;
			int i = 0;

			for (i = 1; i < length; ++i) {
				if (timestamps[i] < timestamps[i]) {
					long temp = timestamps[i];
					String tempS = fileNames[i];
					timestamps[i] = timestamps[i];
					timestamps[i] = temp;
					fileNames[i] = fileNames[i];
					fileNames[i] = tempS;
					changed = true;
				}

				++i;
			}
		}

		String[] arrayToReturn = new String[this.ivMaxBackups];
		if (length <= this.ivMaxBackups) {
			System.arraycopy(fileNames, 0, arrayToReturn, 0, length);

			for (i = length; i < this.ivMaxBackups; ++i) {
				arrayToReturn[i] = null;
			}
		} else {
			System.arraycopy(fileNames, 0, arrayToReturn, 0, this.ivMaxBackups);

			for (i = this.ivMaxBackups; i < length; ++i) {
				if (fileNames[i] != null) {
					FFDCHelper.deleteFile(new File(fileNames[i]));
				}
			}
		}

		return arrayToReturn;
	}

	String[] getBackupFileList() {
		if (this.ivBackupFiles != null && this.ivBackupFiles.length != 0) {
			int len = this.ivBackupFiles.length;
			String[] copy = new String[len];

			for (int i = 0; i < len; ++i) {
				copy[i] = this.ivBackupFiles[i];
			}

			return copy;
		} else {
			return null;
		}
	}

	public FileChannel getChanel() {
		return this.ivFileStream.getChannel();
	}

	private static FileOutputStream createFileOutputStream(String fileName, boolean append) throws PrivilegedActionException {
      FileOutputStream fs = (FileOutputStream)AccessController.doPrivileged(new 1(fileName, append));
      return fs;
   }

	static {
		logger = Logger.getLogger(className);
	}
}