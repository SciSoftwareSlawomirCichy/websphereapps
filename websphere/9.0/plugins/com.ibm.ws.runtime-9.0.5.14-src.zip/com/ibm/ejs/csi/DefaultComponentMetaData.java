package com.ibm.ejs.csi;

import com.ibm.ejs.oa.EJSORBFactory;
import com.ibm.websphere.csi.GlobalTranConfigData;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.LocalTranConfigData;
import com.ibm.websphere.csi.ResRefList;
import com.ibm.websphere.naming.JndiHelper;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.naming.java.javaNameSpace;
import com.ibm.ws.runtime.metadata.ComponentMetaData;
import com.ibm.ws.runtime.metadata.ContainerComponentMetaData;
import com.ibm.ws.runtime.metadata.MetaDataSlot;
import com.ibm.ws.runtime.metadata.ModuleMetaData;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.naming.Reference;

public class DefaultComponentMetaData implements ContainerComponentMetaData {
	private static final String CLASS_NAME = "com.ibm.websphere.csi.DefaultComponentMetaData";
	private static final DefaultComponentMetaData cvTheInstance = new DefaultComponentMetaData();
	private Context ivJavaColonContext;
	private javaNameSpace ivJavaNameSpace;
	private LocalTranConfigData localTranConfig;
	private GlobalTranConfigData globalTranConfig;

	public static final ComponentMetaData getInstance() {
		return cvTheInstance;
	}

	private DefaultComponentMetaData() {
		try {
			this.ivJavaNameSpace = javaNameSpace.createJavaNameSpace();
			this.ivJavaNameSpace.setAsDefaultJavaNameSpace();
			this.ivJavaColonContext = initializeJavaNameSpace(this.ivJavaNameSpace);
			this.localTranConfig = new BasicLocalTranConfigDataImpl();
			this.globalTranConfig = new BasicGlobalTranConfigDataImpl();
		} catch (Throwable var2) {
			var2.printStackTrace();
			FFDCFilter.processException(var2, "com.ibm.websphere.csi.DefaultComponentMetaData.DefaultComponentMetaData",
					"34", this);
		}

	}

	public static Context initializeJavaNameSpace(javaNameSpace jns) throws NamingException {
		Properties jndiEnv = new Properties();
		jndiEnv.put("com.ibm.ws.naming.java.javanamespace", jns);
		jndiEnv.put("java.naming.factory.initial", "com.ibm.ws.naming.java.javaURLInitialContextFactory");
		Context javaColonContext = new InitialContext(jndiEnv);
		Context compContext = JndiHelper.recursiveCreateSubcontext(javaColonContext, "comp");
		Reference indirectORBRef = new Reference("org.omg.CORBA.ORB", EJSORBFactory.class.getName(), (String) null);
		JndiHelper.recursiveRebind(compContext, "ORB", indirectORBRef);
		indirectORBRef = new Reference("javax.ejb.spi.HandleDelegate", HandleDelegateFactory.class.getName(),
				(String) null);
		JndiHelper.recursiveRebind(compContext, "HandleDelegate", indirectORBRef);
		return javaColonContext;
	}

	public final ModuleMetaData getModuleMetaData() {
		return null;
	}

	public final J2EEName getJ2EEName() {
		return null;
	}

	public final Context getJavaNameSpaceContext() {
		return this.ivJavaColonContext;
	}

	public final javaNameSpace getJavaNameSpace() {
		return this.ivJavaNameSpace;
	}

	public final String getName() {
		return null;
	}

	public final void setMetaData(MetaDataSlot slot, Object metadata) {
	}

	public final Object getMetaData(MetaDataSlot slot) {
		return null;
	}

	public final void release() {
	}

	public final LocalTranConfigData getLocalTran() {
		return this.localTranConfig;
	}

	public final LocalTranConfigData getLocalTranConfigData() {
		return this.localTranConfig;
	}

	public final GlobalTranConfigData getGlobalTranConfigData() {
		return this.globalTranConfig;
	}

	public ResRefList getResourceRefList() {
		return null;
	}
}