package com.ibm.icu.text;

import com.ibm.icu.impl.ICULocaleService;
import com.ibm.icu.impl.ICUResourceBundle;
import com.ibm.icu.impl.ICUService.Factory;
import com.ibm.icu.text.Collator.CollatorFactory;
import com.ibm.icu.text.Collator.ServiceShim;
import com.ibm.icu.text.CollatorServiceShim.1CFactory;
import com.ibm.icu.text.CollatorServiceShim.CService;
import com.ibm.icu.util.ULocale;
import java.util.Locale;
import java.util.MissingResourceException;

final class CollatorServiceShim extends ServiceShim {
	private static ICULocaleService service = new CService();

	Collator getInstance(ULocale locale) {
		try {
			ULocale[] actualLoc = new ULocale[1];
			Collator coll = (Collator) service.get(locale, actualLoc);
			if (coll == null) {
				throw new MissingResourceException("Could not locate Collator data", "", "");
			} else {
				coll = (Collator) coll.clone();
				coll.setLocale(actualLoc[0], actualLoc[0]);
				return coll;
			}
		} catch (CloneNotSupportedException var4) {
			throw new IllegalStateException(var4.getMessage());
		}
	}

	Object registerInstance(Collator collator, ULocale locale) {
		return service.registerObject(collator, locale);
	}

	Object registerFactory(CollatorFactory f) {
      return service.registerFactory(new 1CFactory(this, f));
   }

	boolean unregister(Object registryKey) {
		return service.unregisterFactory((Factory) registryKey);
	}

	Locale[] getAvailableLocales() {
		Locale[] result;
		if (service.isDefault()) {
			ClassLoader cl = this.getClass().getClassLoader();
			result = ICUResourceBundle.getAvailableLocales("com/ibm/icu/impl/data/icudt44b/coll", cl);
		} else {
			result = service.getAvailableLocales();
		}

		return result;
	}

	ULocale[] getAvailableULocales() {
		ULocale[] result;
		if (service.isDefault()) {
			ClassLoader cl = this.getClass().getClassLoader();
			result = ICUResourceBundle.getAvailableULocales("com/ibm/icu/impl/data/icudt44b/coll", cl);
		} else {
			result = service.getAvailableULocales();
		}

		return result;
	}

	String getDisplayName(ULocale objectLocale, ULocale displayLocale) {
		String id = objectLocale.getName();
		return service.getDisplayName(id, displayLocale);
	}
}