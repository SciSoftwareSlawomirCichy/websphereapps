package com.ibm.ws.wim.adapter.file.was;

import com.ibm.websphere.wim.ras.WIMLogger;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileUserAccountLockoutData {
	private static final String CLASSNAME = FileUserAccountLockoutData.class.getName();
	private static final Logger trcLogger;
	private final String loginName;
	private final long firstTimeStamp;
	private long lastTimeStamp = -1L;
	private volatile int numberOfFailures = 0;
	private volatile boolean isLocked = false;
	private final int accountLockoutThreshold;

	public FileUserAccountLockoutData(String var1, int var2) {
		this.loginName = var1;
		this.firstTimeStamp = System.currentTimeMillis();
		this.lastTimeStamp = this.firstTimeStamp;
		this.accountLockoutThreshold = var2;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "WIM_SPI ",
					var1 + " had a first failed logon, initializing their account lockout data with a theshold of "
							+ var2 + " : " + this.toString());
		}

	}

	public boolean updateAccountForLoginFailure() {
		++this.numberOfFailures;
		this.lastTimeStamp = System.currentTimeMillis();
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "WIM_SPI updateUserFailure",
					this.loginName + " had a failed logon: " + this.toString());
		}

		if (this.numberOfFailures >= this.accountLockoutThreshold) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "WIM_SPI updateUserFailure",
						"Marking " + this.loginName + " as locked. numberOfFailures: " + this.numberOfFailures
								+ ", accountLockoutThreshold: " + this.accountLockoutThreshold);
			}

			this.isLocked = true;
		}

		return this.isLocked;
	}

	public String toString() {
		StringBuffer var1 = new StringBuffer();
		var1.append("loginName: " + this.loginName);
		var1.append(", firstTimeStamp: " + this.firstTimeStamp);
		var1.append(", lastTimeStamp: " + this.lastTimeStamp);
		var1.append(", numberOfFailures: " + this.numberOfFailures);
		return var1.toString();
	}

	public long getLastTimeStamp() {
		return this.lastTimeStamp;
	}

	public int getNumberOfFailures() {
		return this.numberOfFailures;
	}

	public String getLoginName() {
		return this.loginName;
	}

	public long getFirstTimeStamp() {
		return this.firstTimeStamp;
	}

	public boolean isLocked() {
		return this.isLocked;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}