package com.ibm.ejs.container;

import com.ibm.ejs.container.passivator.PassivatorSerializable;
import com.ibm.ejs.container.passivator.PassivatorSerializableHandle;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.ws.ejbcontainer.util.ParsedScheduleExpression;
import java.io.Serializable;
import java.util.Date;
import javax.ejb.EJBException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.ScheduleExpression;
import javax.ejb.Timer;
import javax.ejb.TimerHandle;

public abstract class PersistentTimer implements Timer, PassivatorSerializable {
	private static final TraceComponent tc = Tr.register(PersistentTimer.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	protected Long taskId;
	protected J2EEName j2eeName;
	protected boolean isTimeoutCallback;
	protected int cachedTimerDataAllowed;
	protected PersistentTimerTaskHandler cachedTaskHandler;

	protected PersistentTimer(Long taskId, J2EEName j2eeName, int cachedTimerDataAllowed,
			PersistentTimerTaskHandler taskHandler) {
		this.taskId = taskId;
		this.j2eeName = j2eeName;
		this.cachedTimerDataAllowed = cachedTimerDataAllowed;
		this.cachedTaskHandler = taskHandler;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> : " + this);
		}

	}

	public long getTimeRemaining() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		Date nextTime = this.getNextTimeout(8);
		long currentTime = System.currentTimeMillis();
		long remaining = nextTime.getTime() - currentTime;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getTimeRemaining: " + remaining);
		}

		return remaining;
	}

	public Date getNextTimeout() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		Date nextTime = this.getNextTimeout(4);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getNextTimeout: " + nextTime);
		}

		return nextTime;
	}

	public Serializable getInfo() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getInfo: " + this);
		}

		this.checkTimerAccess();
		PersistentTimerTaskHandler taskHandler = this.getTimerTaskHandler(2);
		Serializable userInfo = taskHandler.getUserInfo();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getInfo: " + Util.identity(userInfo));
		}

		return userInfo;
	}

	public TimerHandle getHandle() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getHandle: " + this);
		}

		this.checkTimerAccess();
		this.checkTimerExists(1);
		TimerHandle timerHandle = new PersistentTimerHandle(this.taskId, false);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getHandle: " + timerHandle);
		}

		return timerHandle;
	}

	public ScheduleExpression getSchedule() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getSchedule: " + this);
		}

		this.checkTimerAccess();
		PersistentTimerTaskHandler taskHandler = this.getTimerTaskHandler(16);
		ParsedScheduleExpression parsedSchedule = taskHandler.getParsedSchedule();
		if (parsedSchedule == null) {
			IllegalStateException ise = new IllegalStateException(
					"Timer is not a calendar-based timer: " + this.toString());
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getSchedule: " + ise);
			}

			throw ise;
		} else {
			ScheduleExpression schedule = EJSContainer.getDefaultContainer().ivObjectCopier
					.copy(parsedSchedule.getSchedule());
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getSchedule: " + schedule);
			}

			return schedule;
		}
	}

	public boolean isPersistent() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isPersistent: " + this);
		}

		this.checkTimerAccess();
		this.checkTimerExists(32);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isPersistent: true");
		}

		return true;
	}

	public boolean isCalendarTimer() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isCalendarTimer: " + this);
		}

		this.checkTimerAccess();
		PersistentTimerTaskHandler taskHandler = this.getTimerTaskHandler(64);
		boolean result = taskHandler.getParsedSchedule() != null;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isCalendarTimer: " + result);
		}

		return result;
	}

	public PassivatorSerializableHandle getSerializableObject() {
		return new PersistentTimerHandle(this.taskId, true);
	}

	protected abstract Date getNextTimeout(int var1)
			throws IllegalStateException, NoSuchObjectLocalException, EJBException;

	protected boolean isAnyCachingAllowed() {
		return this.isTimeoutCallback || this.cachedTimerDataAllowed != 0;
	}

	protected boolean isCachingAllowed(int operation) {
		return this.isTimeoutCallback || (this.cachedTimerDataAllowed & operation) != 0;
	}

	protected abstract PersistentTimerTaskHandler getTimerTaskHandler(int var1);

	protected void checkTimerAccess() {
		BeanO beanO = EJSContainer.getCallbackBeanO();
		if (beanO != null) {
			beanO.checkTimerServiceAccess();
		} else {
			if (!EJSContainer.getDefaultContainer().allowTimerAccessOutsideBean) {
				IllegalStateException ise = new IllegalStateException("Timer methods not allowed - no active EJB");
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkTimerAccess: " + ise);
				}

				throw ise;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerAccess: Timer access permitted outside of bean");
			}
		}

		if (this.taskId == null) {
			NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(this.toString());
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerAccess: " + nsoe);
			}

			throw nsoe;
		}
	}

	protected abstract void checkTimerExists(int var1);

	public boolean equals(Object obj) {
		if (obj instanceof PersistentTimer) {
			if (this.taskId == null) {
				return this == obj;
			} else {
				PersistentTimer timer = (PersistentTimer) obj;
				return this.taskId.equals(timer.taskId);
			}
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.taskId == null ? 0 : (int) (this.taskId % 2147483647L);
	}

	public String toString() {
		return this.getClass().getSimpleName() + "(" + this.taskId + ", " + this.j2eeName + ")";
	}
}