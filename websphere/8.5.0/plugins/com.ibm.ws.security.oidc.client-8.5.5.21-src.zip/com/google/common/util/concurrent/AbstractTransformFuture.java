package com.google.common.util.concurrent;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.AbstractTransformFuture.AsyncTransformFuture;
import com.google.common.util.concurrent.AbstractTransformFuture.TransformFuture;
import com.google.common.util.concurrent.FluentFuture.TrustedFuture;
import com.google.errorprone.annotations.ForOverride;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AbstractTransformFuture<I, O, F, T> extends TrustedFuture<O> implements Runnable {
	@NullableDecl
	ListenableFuture<? extends I> inputFuture;
	@NullableDecl
	F function;

	static <I, O> ListenableFuture<O> create(ListenableFuture<I> input, AsyncFunction<? super I, ? extends O> function,
			Executor executor) {
		Preconditions.checkNotNull(executor);
		AsyncTransformFuture<I, O> output = new AsyncTransformFuture(input, function);
		input.addListener(output, MoreExecutors.rejectionPropagatingExecutor(executor, output));
		return output;
	}

	static <I, O> ListenableFuture<O> create(ListenableFuture<I> input, Function<? super I, ? extends O> function,
			Executor executor) {
		Preconditions.checkNotNull(function);
		TransformFuture<I, O> output = new TransformFuture(input, function);
		input.addListener(output, MoreExecutors.rejectionPropagatingExecutor(executor, output));
		return output;
	}

	AbstractTransformFuture(ListenableFuture<? extends I> inputFuture, F function) {
		this.inputFuture = (ListenableFuture) Preconditions.checkNotNull(inputFuture);
		this.function = Preconditions.checkNotNull(function);
	}

	public final void run() {
		ListenableFuture<? extends I> localInputFuture = this.inputFuture;
		F localFunction = this.function;
		if (!(this.isCancelled() | localInputFuture == null | localFunction == null)) {
			this.inputFuture = null;
			if (localInputFuture.isCancelled()) {
				this.setFuture(localInputFuture);
			} else {
				Object sourceResult;
				try {
					sourceResult = Futures.getDone(localInputFuture);
				} catch (CancellationException var13) {
					this.cancel(false);
					return;
				} catch (ExecutionException var14) {
					this.setException(var14.getCause());
					return;
				} catch (RuntimeException var15) {
					this.setException(var15);
					return;
				} catch (Error var16) {
					this.setException(var16);
					return;
				}

				Object transformResult;
				label85 : {
					try {
						transformResult = this.doTransform(localFunction, sourceResult);
						break label85;
					} catch (Throwable var17) {
						this.setException(var17);
					} finally {
						this.function = null;
					}

					return;
				}

				this.setResult(transformResult);
			}
		}
	}

	@NullableDecl
	@ForOverride
	abstract T doTransform(F var1, @NullableDecl I var2) throws Exception;

	@ForOverride
	abstract void setResult(@NullableDecl T var1);

	protected final void afterDone() {
		this.maybePropagateCancellationTo(this.inputFuture);
		this.inputFuture = null;
		this.function = null;
	}

	protected String pendingToString() {
		ListenableFuture<? extends I> localInputFuture = this.inputFuture;
		F localFunction = this.function;
		String superString = super.pendingToString();
		String resultString = "";
		if (localInputFuture != null) {
			resultString = "inputFuture=[" + localInputFuture + "], ";
		}

		if (localFunction != null) {
			return resultString + "function=[" + localFunction + "]";
		} else {
			return superString != null ? resultString + superString : null;
		}
	}
}