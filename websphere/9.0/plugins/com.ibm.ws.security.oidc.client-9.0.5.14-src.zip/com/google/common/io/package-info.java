package com.google.common.io;

import com.google.errorprone.annotations.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;

// $FF: synthetic class
@CheckReturnValue
@ParametersAreNonnullByDefault
interface package-info {
}