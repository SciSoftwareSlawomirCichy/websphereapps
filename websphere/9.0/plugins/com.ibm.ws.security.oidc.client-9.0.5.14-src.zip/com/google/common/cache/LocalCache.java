package com.google.common.cache;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Equivalence;
import com.google.common.base.Preconditions;
import com.google.common.base.Stopwatch;
import com.google.common.base.Ticker;
import com.google.common.cache.AbstractCache.StatsCounter;
import com.google.common.cache.CacheBuilder.NullListener;
import com.google.common.cache.CacheBuilder.OneWeigher;
import com.google.common.cache.CacheLoader.InvalidCacheLoadException;
import com.google.common.cache.CacheLoader.UnsupportedLoadingOperationException;
import com.google.common.cache.LocalCache.1;
import com.google.common.cache.LocalCache.2;
import com.google.common.cache.LocalCache.EntryFactory;
import com.google.common.cache.LocalCache.EntrySet;
import com.google.common.cache.LocalCache.KeySet;
import com.google.common.cache.LocalCache.NullEntry;
import com.google.common.cache.LocalCache.Segment;
import com.google.common.cache.LocalCache.Strength;
import com.google.common.cache.LocalCache.ValueReference;
import com.google.common.cache.LocalCache.Values;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.primitives.Ints;
import com.google.common.util.concurrent.ExecutionError;
import com.google.common.util.concurrent.UncheckedExecutionException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
class LocalCache<K, V> extends AbstractMap<K, V> implements ConcurrentMap<K, V> {
	static final int MAXIMUM_CAPACITY = 1073741824;
	static final int MAX_SEGMENTS = 65536;
	static final int CONTAINS_VALUE_RETRIES = 3;
	static final int DRAIN_THRESHOLD = 63;
	static final int DRAIN_MAX = 16;
	static final Logger logger = Logger.getLogger(LocalCache.class.getName());
	final int segmentMask;
	final int segmentShift;
	final Segment<K, V>[] segments;
	final int concurrencyLevel;
	final Equivalence<Object> keyEquivalence;
	final Equivalence<Object> valueEquivalence;
	final Strength keyStrength;
	final Strength valueStrength;
	final long maxWeight;
	final Weigher<K, V> weigher;
	final long expireAfterAccessNanos;
	final long expireAfterWriteNanos;
	final long refreshNanos;
	final Queue<RemovalNotification<K, V>> removalNotificationQueue;
	final RemovalListener<K, V> removalListener;
	final Ticker ticker;
	final EntryFactory entryFactory;
	final StatsCounter globalStatsCounter;
	@NullableDecl
	final CacheLoader<? super K, V> defaultLoader;
	static final ValueReference<Object, Object> UNSET = new 1();
	static final Queue<?> DISCARDING_QUEUE = new 2();
	@MonotonicNonNullDecl
	Set<K> keySet;
	@MonotonicNonNullDecl
	Collection<V> values;
	@MonotonicNonNullDecl
	Set<Entry<K, V>> entrySet;

	LocalCache(CacheBuilder<? super K, ? super V> builder, @NullableDecl CacheLoader<? super K, V> loader) {
		this.concurrencyLevel = Math.min(builder.getConcurrencyLevel(), 65536);
		this.keyStrength = builder.getKeyStrength();
		this.valueStrength = builder.getValueStrength();
		this.keyEquivalence = builder.getKeyEquivalence();
		this.valueEquivalence = builder.getValueEquivalence();
		this.maxWeight = builder.getMaximumWeight();
		this.weigher = builder.getWeigher();
		this.expireAfterAccessNanos = builder.getExpireAfterAccessNanos();
		this.expireAfterWriteNanos = builder.getExpireAfterWriteNanos();
		this.refreshNanos = builder.getRefreshNanos();
		this.removalListener = builder.getRemovalListener();
		this.removalNotificationQueue = (Queue) (this.removalListener == NullListener.INSTANCE
				? discardingQueue()
				: new ConcurrentLinkedQueue());
		this.ticker = builder.getTicker(this.recordsTime());
		this.entryFactory = EntryFactory.getFactory(this.keyStrength, this.usesAccessEntries(),
				this.usesWriteEntries());
		this.globalStatsCounter = (StatsCounter) builder.getStatsCounterSupplier().get();
		this.defaultLoader = loader;
		int initialCapacity = Math.min(builder.getInitialCapacity(), 1073741824);
		if (this.evictsBySize() && !this.customWeigher()) {
			initialCapacity = (int) Math.min((long) initialCapacity, this.maxWeight);
		}

		int segmentShift = 0;

		int segmentCount;
		for (segmentCount = 1; segmentCount < this.concurrencyLevel
				&& (!this.evictsBySize() || (long) (segmentCount * 20) <= this.maxWeight); segmentCount <<= 1) {
			++segmentShift;
		}

		this.segmentShift = 32 - segmentShift;
		this.segmentMask = segmentCount - 1;
		this.segments = this.newSegmentArray(segmentCount);
		int segmentCapacity = initialCapacity / segmentCount;
		if (segmentCapacity * segmentCount < initialCapacity) {
			++segmentCapacity;
		}

		int segmentSize;
		for (segmentSize = 1; segmentSize < segmentCapacity; segmentSize <<= 1) {
			;
		}

		if (this.evictsBySize()) {
			long maxSegmentWeight = this.maxWeight / (long) segmentCount + 1L;
			long remainder = this.maxWeight % (long) segmentCount;

			for (int i = 0; i < this.segments.length; ++i) {
				if ((long) i == remainder) {
					--maxSegmentWeight;
				}

				this.segments[i] = this.createSegment(segmentSize, maxSegmentWeight,
						(StatsCounter) builder.getStatsCounterSupplier().get());
			}
		} else {
			for (int i = 0; i < this.segments.length; ++i) {
				this.segments[i] = this.createSegment(segmentSize, -1L,
						(StatsCounter) builder.getStatsCounterSupplier().get());
			}
		}

	}

	boolean evictsBySize() {
		return this.maxWeight >= 0L;
	}

	boolean customWeigher() {
		return this.weigher != OneWeigher.INSTANCE;
	}

	boolean expires() {
		return this.expiresAfterWrite() || this.expiresAfterAccess();
	}

	boolean expiresAfterWrite() {
		return this.expireAfterWriteNanos > 0L;
	}

	boolean expiresAfterAccess() {
		return this.expireAfterAccessNanos > 0L;
	}

	boolean refreshes() {
		return this.refreshNanos > 0L;
	}

	boolean usesAccessQueue() {
		return this.expiresAfterAccess() || this.evictsBySize();
	}

	boolean usesWriteQueue() {
		return this.expiresAfterWrite();
	}

	boolean recordsWrite() {
		return this.expiresAfterWrite() || this.refreshes();
	}

	boolean recordsAccess() {
		return this.expiresAfterAccess();
	}

	boolean recordsTime() {
		return this.recordsWrite() || this.recordsAccess();
	}

	boolean usesWriteEntries() {
		return this.usesWriteQueue() || this.recordsWrite();
	}

	boolean usesAccessEntries() {
		return this.usesAccessQueue() || this.recordsAccess();
	}

	boolean usesKeyReferences() {
		return this.keyStrength != Strength.STRONG;
	}

	boolean usesValueReferences() {
		return this.valueStrength != Strength.STRONG;
	}

	static <K, V> ValueReference<K, V> unset() {
		return UNSET;
	}

	static <K, V> ReferenceEntry<K, V> nullEntry() {
		return NullEntry.INSTANCE;
	}

	static <E> Queue<E> discardingQueue() {
		return DISCARDING_QUEUE;
	}

	static int rehash(int h) {
		h += h << 15 ^ -12931;
		h ^= h >>> 10;
		h += h << 3;
		h ^= h >>> 6;
		h += (h << 2) + (h << 14);
		return h ^ h >>> 16;
	}

	@VisibleForTesting
	ReferenceEntry<K, V> newEntry(K key, int hash, @NullableDecl ReferenceEntry<K, V> next) {
		Segment<K, V> segment = this.segmentFor(hash);
		segment.lock();

		ReferenceEntry var5;
		try {
			var5 = segment.newEntry(key, hash, next);
		} finally {
			segment.unlock();
		}

		return var5;
	}

	@VisibleForTesting
	ReferenceEntry<K, V> copyEntry(ReferenceEntry<K, V> original, ReferenceEntry<K, V> newNext) {
		int hash = original.getHash();
		return this.segmentFor(hash).copyEntry(original, newNext);
	}

	@VisibleForTesting
	ValueReference<K, V> newValueReference(ReferenceEntry<K, V> entry, V value, int weight) {
		int hash = entry.getHash();
		return this.valueStrength.referenceValue(this.segmentFor(hash), entry, Preconditions.checkNotNull(value),
				weight);
	}

	int hash(@NullableDecl Object key) {
		int h = this.keyEquivalence.hash(key);
		return rehash(h);
	}

	void reclaimValue(ValueReference<K, V> valueReference) {
		ReferenceEntry<K, V> entry = valueReference.getEntry();
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimValue(entry.getKey(), hash, valueReference);
	}

	void reclaimKey(ReferenceEntry<K, V> entry) {
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimKey(entry, hash);
	}

	@VisibleForTesting
	boolean isLive(ReferenceEntry<K, V> entry, long now) {
		return this.segmentFor(entry.getHash()).getLiveValue(entry, now) != null;
	}

	Segment<K, V> segmentFor(int hash) {
		return this.segments[hash >>> this.segmentShift & this.segmentMask];
	}

	Segment<K, V> createSegment(int initialCapacity, long maxSegmentWeight, StatsCounter statsCounter) {
		return new Segment(this, initialCapacity, maxSegmentWeight, statsCounter);
	}

	@NullableDecl
	V getLiveValue(ReferenceEntry<K, V> entry, long now) {
		if (entry.getKey() == null) {
			return null;
		} else {
			V value = entry.getValueReference().get();
			if (value == null) {
				return null;
			} else {
				return this.isExpired(entry, now) ? null : value;
			}
		}
	}

	boolean isExpired(ReferenceEntry<K, V> entry, long now) {
		Preconditions.checkNotNull(entry);
		if (this.expiresAfterAccess() && now - entry.getAccessTime() >= this.expireAfterAccessNanos) {
			return true;
		} else {
			return this.expiresAfterWrite() && now - entry.getWriteTime() >= this.expireAfterWriteNanos;
		}
	}

	static <K, V> void connectAccessOrder(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next) {
		previous.setNextInAccessQueue(next);
		next.setPreviousInAccessQueue(previous);
	}

	static <K, V> void nullifyAccessOrder(ReferenceEntry<K, V> nulled) {
		ReferenceEntry<K, V> nullEntry = nullEntry();
		nulled.setNextInAccessQueue(nullEntry);
		nulled.setPreviousInAccessQueue(nullEntry);
	}

	static <K, V> void connectWriteOrder(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next) {
		previous.setNextInWriteQueue(next);
		next.setPreviousInWriteQueue(previous);
	}

	static <K, V> void nullifyWriteOrder(ReferenceEntry<K, V> nulled) {
		ReferenceEntry<K, V> nullEntry = nullEntry();
		nulled.setNextInWriteQueue(nullEntry);
		nulled.setPreviousInWriteQueue(nullEntry);
	}

	void processPendingNotifications() {
		RemovalNotification notification;
		while ((notification = (RemovalNotification) this.removalNotificationQueue.poll()) != null) {
			try {
				this.removalListener.onRemoval(notification);
			} catch (Throwable var3) {
				logger.log(Level.WARNING, "Exception thrown by removal listener", var3);
			}
		}

	}

	final Segment<K, V>[] newSegmentArray(int ssize) {
		return new Segment[ssize];
	}

	public void cleanUp() {
		Segment[] var1 = this.segments;
		int var2 = var1.length;

		for (int var3 = 0; var3 < var2; ++var3) {
			Segment<?, ?> segment = var1[var3];
			segment.cleanUp();
		}

	}

	public boolean isEmpty() {
		long sum = 0L;
		Segment<K, V>[] segments = this.segments;

		int i;
		for (i = 0; i < segments.length; ++i) {
			if (segments[i].count != 0) {
				return false;
			}

			sum += (long) segments[i].modCount;
		}

		if (sum != 0L) {
			for (i = 0; i < segments.length; ++i) {
				if (segments[i].count != 0) {
					return false;
				}

				sum -= (long) segments[i].modCount;
			}

			if (sum != 0L) {
				return false;
			}
		}

		return true;
	}

	long longSize() {
		Segment<K, V>[] segments = this.segments;
		long sum = 0L;

		for (int i = 0; i < segments.length; ++i) {
			sum += (long) Math.max(0, segments[i].count);
		}

		return sum;
	}

	public int size() {
		return Ints.saturatedCast(this.longSize());
	}

	@NullableDecl
	public V get(@NullableDecl Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).get(key, hash);
		}
	}

	V get(K key, CacheLoader<? super K, V> loader) throws ExecutionException {
		int hash = this.hash(Preconditions.checkNotNull(key));
		return this.segmentFor(hash).get(key, hash, loader);
	}

	@NullableDecl
	public V getIfPresent(Object key) {
		int hash = this.hash(Preconditions.checkNotNull(key));
		V value = this.segmentFor(hash).get(key, hash);
		if (value == null) {
			this.globalStatsCounter.recordMisses(1);
		} else {
			this.globalStatsCounter.recordHits(1);
		}

		return value;
	}

	@NullableDecl
	public V getOrDefault(@NullableDecl Object key, @NullableDecl V defaultValue) {
		V result = this.get(key);
		return result != null ? result : defaultValue;
	}

	V getOrLoad(K key) throws ExecutionException {
		return this.get(key, this.defaultLoader);
	}

	ImmutableMap<K, V> getAllPresent(Iterable<?> keys) {
		int hits = 0;
		int misses = 0;
		Map<K, V> result = Maps.newLinkedHashMap();
		Iterator var5 = keys.iterator();

		while (var5.hasNext()) {
			Object key = var5.next();
			V value = this.get(key);
			if (value == null) {
				++misses;
			} else {
				result.put(key, value);
				++hits;
			}
		}

		this.globalStatsCounter.recordHits(hits);
		this.globalStatsCounter.recordMisses(misses);
		return ImmutableMap.copyOf(result);
	}

	ImmutableMap<K, V> getAll(Iterable<? extends K> keys) throws ExecutionException {
		int hits = 0;
		int misses = 0;
		Map<K, V> result = Maps.newLinkedHashMap();
		Set<K> keysToLoad = Sets.newLinkedHashSet();
		Iterator var6 = keys.iterator();

		Object key;
		while (var6.hasNext()) {
			K key = var6.next();
			key = this.get(key);
			if (!result.containsKey(key)) {
				result.put(key, key);
				if (key == null) {
					++misses;
					keysToLoad.add(key);
				} else {
					++hits;
				}
			}
		}

		ImmutableMap var16;
		try {
			if (!keysToLoad.isEmpty()) {
				Iterator var17;
				try {
					Map<K, V> newEntries = this.loadAll(keysToLoad, this.defaultLoader);
					var17 = keysToLoad.iterator();

					while (var17.hasNext()) {
						key = var17.next();
						V value = newEntries.get(key);
						if (value == null) {
							throw new InvalidCacheLoadException("loadAll failed to return a value for " + key);
						}

						result.put(key, value);
					}
				} catch (UnsupportedLoadingOperationException var13) {
					var17 = keysToLoad.iterator();

					while (var17.hasNext()) {
						key = var17.next();
						--misses;
						result.put(key, this.get(key, this.defaultLoader));
					}
				}
			}

			var16 = ImmutableMap.copyOf(result);
		} finally {
			this.globalStatsCounter.recordHits(hits);
			this.globalStatsCounter.recordMisses(misses);
		}

		return var16;
	}

	@NullableDecl
	Map<K, V> loadAll(Set<? extends K> keys, CacheLoader<? super K, V> loader) throws ExecutionException {
		Preconditions.checkNotNull(loader);
		Preconditions.checkNotNull(keys);
		Stopwatch stopwatch = Stopwatch.createStarted();
		boolean success = false;

		Map result;
		try {
			Map<K, V> map = loader.loadAll(keys);
			result = map;
			success = true;
		} catch (UnsupportedLoadingOperationException var17) {
			success = true;
			throw var17;
		} catch (InterruptedException var18) {
			Thread.currentThread().interrupt();
			throw new ExecutionException(var18);
		} catch (RuntimeException var19) {
			throw new UncheckedExecutionException(var19);
		} catch (Exception var20) {
			throw new ExecutionException(var20);
		} catch (Error var21) {
			throw new ExecutionError(var21);
		} finally {
			if (!success) {
				this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
			}

		}

		if (result == null) {
			this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
			throw new InvalidCacheLoadException(loader + " returned null map from loadAll");
		} else {
			stopwatch.stop();
			boolean nullsPresent = false;
			Iterator var7 = result.entrySet().iterator();

			while (true) {
				while (var7.hasNext()) {
					Entry<K, V> entry = (Entry) var7.next();
					K key = entry.getKey();
					V value = entry.getValue();
					if (key != null && value != null) {
						this.put(key, value);
					} else {
						nullsPresent = true;
					}
				}

				if (nullsPresent) {
					this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
					throw new InvalidCacheLoadException(loader + " returned null keys or values from loadAll");
				}

				this.globalStatsCounter.recordLoadSuccess(stopwatch.elapsed(TimeUnit.NANOSECONDS));
				return result;
			}
		}
	}

	ReferenceEntry<K, V> getEntry(@NullableDecl Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).getEntry(key, hash);
		}
	}

	void refresh(K key) {
		int hash = this.hash(Preconditions.checkNotNull(key));
		this.segmentFor(hash).refresh(key, hash, this.defaultLoader, false);
	}

	public boolean containsKey(@NullableDecl Object key) {
		if (key == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).containsKey(key, hash);
		}
	}

	public boolean containsValue(@NullableDecl Object value) {
		if (value == null) {
			return false;
		} else {
			long now = this.ticker.read();
			Segment<K, V>[] segments = this.segments;
			long last = -1L;

			for (int i = 0; i < 3; ++i) {
				long sum = 0L;
				Segment[] var10 = segments;
				int var11 = segments.length;

				for (int var12 = 0; var12 < var11; ++var12) {
					Segment<K, V> segment = var10[var12];
					int unused = segment.count;
					AtomicReferenceArray<ReferenceEntry<K, V>> table = segment.table;

					for (int j = 0; j < table.length(); ++j) {
						for (ReferenceEntry e = (ReferenceEntry) table.get(j); e != null; e = e.getNext()) {
							V v = segment.getLiveValue(e, now);
							if (v != null && this.valueEquivalence.equivalent(value, v)) {
								return true;
							}
						}
					}

					sum += (long) segment.modCount;
				}

				if (sum == last) {
					break;
				}

				last = sum;
			}

			return false;
		}
	}

	public V put(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, false);
	}

	public V putIfAbsent(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, true);
	}

	public void putAll(Map<? extends K, ? extends V> m) {
		Iterator var2 = m.entrySet().iterator();

		while (var2.hasNext()) {
			Entry<? extends K, ? extends V> e = (Entry) var2.next();
			this.put(e.getKey(), e.getValue());
		}

	}

	public V remove(@NullableDecl Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash);
		}
	}

	public boolean remove(@NullableDecl Object key, @NullableDecl Object value) {
		if (key != null && value != null) {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash, value);
		} else {
			return false;
		}
	}

	public boolean replace(K key, @NullableDecl V oldValue, V newValue) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(newValue);
		if (oldValue == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).replace(key, hash, oldValue, newValue);
		}
	}

	public V replace(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).replace(key, hash, value);
	}

	public void clear() {
		Segment[] var1 = this.segments;
		int var2 = var1.length;

		for (int var3 = 0; var3 < var2; ++var3) {
			Segment<K, V> segment = var1[var3];
			segment.clear();
		}

	}

	void invalidateAll(Iterable<?> keys) {
		Iterator var2 = keys.iterator();

		while (var2.hasNext()) {
			Object key = var2.next();
			this.remove(key);
		}

	}

	public Set<K> keySet() {
		Set<K> ks = this.keySet;
		return ks != null ? ks : (this.keySet = new KeySet(this, this));
	}

	public Collection<V> values() {
		Collection<V> vs = this.values;
		return vs != null ? vs : (this.values = new Values(this, this));
	}

	@GwtIncompatible
	public Set<Entry<K, V>> entrySet() {
		Set<Entry<K, V>> es = this.entrySet;
		return es != null ? es : (this.entrySet = new EntrySet(this, this));
	}

	private static <E> ArrayList<E> toArrayList(Collection<E> c) {
		ArrayList<E> result = new ArrayList(c.size());
		Iterators.addAll(result, c.iterator());
		return result;
	}
}