package com.ibm.ejs.container;

import com.ibm.ejs.container.MDBInterceptorWrapper.CheckedException;
import com.ibm.ejs.jms.listener.ServerSessionDispatcher;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;
import javax.jms.Message;
import javax.jms.MessageListener;

public class MDBWrapper extends EJSLocalWrapper implements MessageListener {
	protected static final TraceComponent tc = Tr.register(MDBWrapper.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.MDBWrapper";

	public void onMessage() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "onMessage: " + this.beanId);
		}

		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();

		try {
			Throwable t;
			try {
				t = null;
				this.container.EjbPreInvoke(this, 0, _EJS_s, t);
				MessageDrivenBeanO beanO = (MessageDrivenBeanO) _EJS_s.beanO;
				MessageListener listener = this.methodInfos[0].ivAroundInterceptors != null
						? new MDBInterceptorWrapper(beanO, _EJS_s)
						: (MessageListener) beanO.ivEjbInstance;
				ServerSessionDispatcher.dispatch((MessageListener) listener, beanO);
			} catch (RemoteException var15) {
				FFDCFilter.processException(var15, "com.ibm.ejs.container.MDBWrapper.onMessage", "80", this);
				_EJS_s.setUncheckedLocalException(var15);
			} catch (Throwable var16) {
				t = var16;
				if (var16 instanceof CheckedException) {
					t = ((CheckedException) var16).getCause();
				}

				FFDCFilter.processException(t, "com.ibm.ejs.container.MDBWrapper.onMessage", "83", this);
				_EJS_s.setUncheckedLocalException(t);
			}
		} finally {
			try {
				this.container.postInvoke(this, 0, _EJS_s);
			} catch (RemoteException var14) {
				FFDCFilter.processException(var14, "com.ibm.ejs.container.MDBWrapper.onMessage", "91", this);
				_EJS_s.setUncheckedLocalException(var14);
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "onMessage");
			}

		}

	}

	public void onMessage(Message jmsMessage) {
		this.onMessage();
	}
}