package com.ibm.ejs.cm.pool;

import java.io.PrintWriter;
import java.sql.SQLException;
import javax.sql.ConnectionPoolDataSource;

public final class RRSJdbcConnectionFactory implements ConnectionFactory {
	private ConnectionPoolDataSource ds;
	private String currentSQLID = null;

	public RRSJdbcConnectionFactory(ConnectionPoolDataSource ds) {
		this.ds = ds;
	}

	public ConnectO createConnection(ConnectionPool pool) throws SQLException {
		ConnectO conn = new ConnectO(this.ds.getPooledConnection(), pool, (String) null, (String) null, "RRS");
		conn.setCurrentSQLID(this.currentSQLID);
		return conn;
	}

	public ConnectO createConnection(ConnectionPool pool, String username, String password) throws SQLException {
		ConnectO conn = new ConnectO(this.ds.getPooledConnection(username, password), pool, username, password, "RRS");
		conn.setCurrentSQLID(this.currentSQLID);
		return conn;
	}

	public PrintWriter getLogWriter() throws SQLException {
		return this.ds.getLogWriter();
	}

	public void setLogWriter(PrintWriter out) throws SQLException {
		this.ds.setLogWriter(out);
	}

	public int getLoginTimeout(int seconds) throws SQLException {
		return this.ds.getLoginTimeout();
	}

	public void setLoginTimeout(int seconds) throws SQLException {
		this.ds.setLoginTimeout(seconds);
	}

	public String getCurrentSQLID() {
		return this.currentSQLID;
	}

	public void setCurrentSQLID(String newSQLID) {
		this.currentSQLID = newSQLID;
	}
}