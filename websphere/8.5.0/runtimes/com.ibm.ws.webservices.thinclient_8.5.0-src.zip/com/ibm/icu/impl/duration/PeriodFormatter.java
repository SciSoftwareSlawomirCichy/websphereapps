package com.ibm.icu.impl.duration;

public interface PeriodFormatter {
	String format(Period var1);

	PeriodFormatter withLocale(String var1);
}