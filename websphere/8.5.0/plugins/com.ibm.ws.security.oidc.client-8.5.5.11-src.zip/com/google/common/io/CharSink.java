package com.google.common.io;

import com.google.common.base.Preconditions;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;

public abstract class CharSink {
	public abstract Writer openStream() throws IOException;

	public BufferedWriter openBufferedStream() throws IOException {
		Writer writer = this.openStream();
		return writer instanceof BufferedWriter ? (BufferedWriter) writer : new BufferedWriter(writer);
	}

	public void write(CharSequence charSequence) throws IOException {
		Preconditions.checkNotNull(charSequence);
		Closer closer = Closer.create();

		try {
			Writer out = (Writer) closer.register(this.openStream());
			out.append(charSequence);
		} catch (Throwable var7) {
			throw closer.rethrow(var7);
		} finally {
			closer.close();
		}

	}

	public void writeLines(Iterable<? extends CharSequence> lines) throws IOException {
		this.writeLines(lines, System.getProperty("line.separator"));
	}

	public void writeLines(Iterable<? extends CharSequence> lines, String lineSeparator) throws IOException {
		Preconditions.checkNotNull(lines);
		Preconditions.checkNotNull(lineSeparator);
		Closer closer = Closer.create();

		try {
			BufferedWriter out = (BufferedWriter) closer.register(this.openBufferedStream());
			Iterator i$ = lines.iterator();

			while (i$.hasNext()) {
				CharSequence line = (CharSequence) i$.next();
				out.append(line).append(lineSeparator);
			}
		} catch (Throwable var10) {
			throw closer.rethrow(var10);
		} finally {
			closer.close();
		}

	}

	public long writeFrom(Readable readable) throws IOException {
		Preconditions.checkNotNull(readable);
		Closer closer = Closer.create();

		long var4;
		try {
			Writer out = (Writer) closer.register(this.openStream());
			var4 = CharStreams.copy(readable, out);
		} catch (Throwable var9) {
			throw closer.rethrow(var9);
		} finally {
			closer.close();
		}

		return var4;
	}
}