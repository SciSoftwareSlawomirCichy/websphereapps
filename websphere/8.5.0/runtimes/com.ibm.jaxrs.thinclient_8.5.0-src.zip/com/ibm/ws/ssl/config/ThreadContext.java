package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.Properties;

public class ThreadContext {
	private static final TraceComponent tc = Tr.register(ThreadContext.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	private Properties sslProperties = null;
	private boolean setSignerOnThread = false;
	private boolean autoAcceptBootstrapSigner = false;
	private boolean autoAcceptBootstrapSignerWithoutStorage = false;
	private X509Certificate[] signer = null;
	private Map inboundConnectionInfo = null;
	private Map outboundConnectionInfo = null;
	private Map outboundConnectionInfoInternal = null;

	public Properties getProperties() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProperties");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getProperties");
		}

		return this.sslProperties;
	}

	public void setProperties(Properties sslProps) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setPropertiesOnThread");
		}

		this.sslProperties = sslProps;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setPropertiesOnThread");
		}

	}

	public boolean getSetSignerOnThread() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSetSignerOnThread");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSetSignerOnThread");
		}

		return this.setSignerOnThread;
	}

	public boolean getAutoAcceptBootstrapSigner() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getAutoAcceptBootstrapSigner");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getAutoAcceptBootstrapSigner");
		}

		return this.autoAcceptBootstrapSigner;
	}

	public Map getInboundConnectionInfo() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getInboundConnectionInfo");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getInboundConnectionInfo");
		}

		return this.inboundConnectionInfo;
	}

	public void setAutoAcceptBootstrapSigner(boolean autoAccept) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setAutoAcceptBootstrapSigner -> " + autoAccept);
		}

		this.autoAcceptBootstrapSigner = autoAccept;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setAutoAcceptBootstrapSigner");
		}

	}

	public boolean getAutoAcceptBootstrapSignerWithoutStorage() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getAutoAcceptBootstrapSignerWithoutStorage");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getAutoAcceptBootstrapSignerWithoutStorage");
		}

		return this.autoAcceptBootstrapSignerWithoutStorage;
	}

	public void setAutoAcceptBootstrapSignerWithoutStorage(boolean autoAccept) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setAutoAcceptBootstrapSignerWithoutStorage -> " + autoAccept);
		}

		this.autoAcceptBootstrapSignerWithoutStorage = autoAccept;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setAutoAcceptBootstrapSignerWithoutStorage");
		}

	}

	public void setSetSignerOnThread(boolean setSigner) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setSetSignerOnThread");
		}

		this.setSignerOnThread = setSigner;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setSetSignerOnThread");
		}

	}

	public X509Certificate[] getSignerChain() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSignerChain");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSignerChain");
		}

		return this.signer;
	}

	public void setSignerChain(X509Certificate[] signerChain) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setSignerChain");
		}

		this.signer = signerChain;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setSignerChain");
		}

	}

	public void setInboundConnectionInfo(Map connectionInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setInboundConnectionInfo");
		}

		this.inboundConnectionInfo = connectionInfo;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setInboundConnectionInfo");
		}

	}

	public Map getOutboundConnectionInfo() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getOutboundConnectionInfo");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getOutboundConnectionInfo");
		}

		return this.outboundConnectionInfo;
	}

	public void setOutboundConnectionInfo(Map connectionInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setOutboundConnectionInfo");
		}

		this.outboundConnectionInfo = connectionInfo;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setOutboundConnectionInfo");
		}

	}

	public Map getOutboundConnectionInfoInternal() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getOutboundConnectionInfoInternal");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getOutboundConnectionInfoInternal :" + this.outboundConnectionInfoInternal);
		}

		return this.outboundConnectionInfoInternal;
	}

	public void setOutboundConnectionInfoInternal(Map connectionInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setOutboundConnectionInfoInternal :" + connectionInfo);
		}

		this.outboundConnectionInfoInternal = connectionInfo;
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setOutboundConnectionInfoInternal");
		}

	}
}