package com.ibm.ws.wim.config;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.AdminContext;
import com.ibm.websphere.management.AdminServiceFactory;
import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.configservice.ConfigDataId;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.management.configservice.ConfigServiceFactory;
import com.ibm.websphere.management.configservice.ConfigServiceHelper;
import com.ibm.websphere.management.configservice.ConfigServiceProxy;
import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmDefaultParentType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.util.DomainManagerUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.AttributeList;
import javax.management.ObjectName;
import javax.management.QueryExp;

public class WASURHelper implements ConfigUIConstants {
	String fakeSessionId = "111";
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2008";
	static final String CLASSNAME = WASURHelper.class.getName();
	private static final Logger trcLogger;
	private static final String VMM_DEFAULT_PARENT_INFO = "vmmDefaultParentInfo";
	private static final String WAS_UR_INFO = "wasURInfo";
	private static final String UR_TYPE = "userRegistryType";
	private static final String WIM_USER_REGISTRY_CLASS = "com.ibm.ws.wim.registry.WIMUserRegistry";
	private static final String UNSUPPORTED_REGISTRY_TYPE = "unsupportedRegistryType";
	private static final String LDAP_USER_REGISTRY = "LDAPUserRegistry";
	private static final String WIM_USER_REGISTRY = "WIMUserRegistry";
	private static final String CUSTOM_USER_REGISTRY = "CustomUserRegistry";
	private static Map<String, Boolean> resultCache;

	public boolean isWASUserRegistry(String var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		boolean var4 = false;
		if (var3) {
			trcLogger.entering(CLASSNAME, "isWASUserRegistry(String entityType)", "entityType: " + var1);
		}

		String var5 = AdminContext.peek();
		if (resultCache.containsKey(var5)) {
			var4 = (Boolean) resultCache.get(var5);
			if (var3) {
				trcLogger.exiting(CLASSNAME, "isWASUserRegistry(String entityType)",
						"result for context=" + var5 + ": " + var4);
			}

			return var4;
		} else {
			Map var6 = getWASURInfoIfLDAP(var5);
			if (var3) {
				trcLogger.logp(Level.FINE, CLASSNAME, "isWASUserRegistry(String entityType)", "wasURInfo = " + var6);
			}

			if (var6 == null) {
				var4 = false;
			} else if ("com.ibm.ws.wim.registry.WIMUserRegistry"
					.equalsIgnoreCase((String) var6.get("userRegistryType"))) {
				var4 = true;
			} else if ("LDAPUserRegistry".equalsIgnoreCase((String) var6.get("userRegistryType"))) {
				Map var7 = this.getEntityTypeDefaultParentLDAP(var1);
				if (var3) {
					trcLogger.logp(Level.FINE, CLASSNAME, "isWASUserRegistry(String entityType)",
							"vmmDefaultParentInfo = " + var7);
				}

				if (var7 != null) {
					String var8 = (String) var7.get("host");
					List var9 = (List) var7.get("baseEntries");
					Integer var10 = (Integer) var7.get("port");
					String var11 = (String) var6.get("host");
					String var12 = (String) var6.get("baseDN");
					Integer var13 = (Integer) var6.get("port");
					if (var8 != null && var8.equalsIgnoreCase(var11) && this.matchBaseDN(var9, var12) && var10 != null
							&& var10.equals(var13)) {
						var4 = true;
					}
				}
			} else {
				var4 = false;
			}

			if (var5 != null) {
				resultCache.put(var5, new Boolean(var4));
			}

			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "isWASUserRegistry(String entityType)",
						"resultCache: " + resultCache);
				trcLogger.exiting(CLASSNAME, "isWASUserRegistry(String entityType)", "result: " + var4);
			}

			return var4;
		}
	}

	private boolean matchBaseDN(List var1, String var2) {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "matchBaseDN(List repoBaseDNs, String wasBaseDN)",
					"repoBaseEntries: " + var1 + ", wasBaseDN: " + var2);
		}

		boolean var5 = false;

		for (int var6 = 0; var6 < var1.size(); ++var6) {
			BaseEntriesType var7 = (BaseEntriesType) var1.get(var6);
			String var8 = var7.getName();
			if (var8 != null) {
				if (var8.equals(var2)) {
					var5 = true;
					break;
				}

				if (var8.endsWith("," + var2)) {
					var5 = true;
					break;
				}
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "matchBaseDN(List repoBaseDNs, String wasBaseDN)", "foundMatch: " + var5);
		}

		return var5;
	}

	private Map getEntityTypeDefaultParentLDAP(String var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getEntityTypeDefaultParentLDAP(String entityType)", "entityType = " + var1);
		}

		HashMap var4 = new HashMap();
		ProfileRepositoryType var5 = null;
		String var6 = null;
		var6 = this.getEntityTypeDefaultParent(var1);
		String var7 = (new RealmConfigHelper()).getIdMgrDefaultRealm(this.fakeSessionId);
		RealmConfigurationType var8 = ConfigUtils.getRealmConfig(this.fakeSessionId);
		RealmType var9 = ConfigUtils.getRealm(var7, var8);
		String var10 = this.getDefaultParentFromRealm(var9, var1);
		if (var10 != null) {
			var6 = var10;
		}

		List var11 = this.getIdMgrRepositoriesForRealm(this.fakeSessionId, var7);
		if (var6 != null) {
			var5 = this.getInformationForBaseEntry(this.fakeSessionId, var6, var11);
		}

		if (var5 != null && var5 instanceof LdapRepositoryType) {
			var4.put("baseEntries", var5.getBaseEntries());
			var4.put("repositoryType", "LDAP");
			LdapRepositoryType var12 = (LdapRepositoryType) var5;
			var4.put("specificRepositoryType", var12.getLdapServerType());
			List var13 = var12.getLdapServerConfiguration().getLdapServers();
			LdapServersType var14 = (LdapServersType) var13.get(0);
			List var15 = var14.getConnections();
			ConnectionsType var16 = (ConnectionsType) var15.get(0);
			var4.put("host", var16.getHost());
			if (var16.isSetPort()) {
				var4.put("port", new Integer(var16.getPort()));
			}
		} else {
			var4 = null;
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "getEntityTypeDefaultParentLDAP(String entityType)", "Map: " + var4);
		}

		return var4;
	}

	private String getEntityTypeDefaultParent(String var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getEntityTypeDefaultParentLDAP(String entityType)", "entityType = " + var1);
		}

		HashMap var4 = new HashMap();
		var4.put("name", var1);
		Map var5 = (new SupportedEntityTypeConfigHelper()).getIdMgrSupportedEntityType(this.fakeSessionId, var4);
		String var6 = (String) var5.get("defaultParent");
		if (var3) {
			trcLogger.exiting(CLASSNAME, "getEntityTypeDefaultParentLDAP(String entityType)",
					"supportedEntityTypeDefaultParent: " + var6);
		}

		return var6;
	}

	private String getDefaultParentFromRealm(RealmType var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getDefaultParentFromRealm(RealmType realm, String entityType)");
		}

		String var5 = null;
		List var6 = var1.getDefaultParents();

		for (int var7 = 0; var7 < var6.size(); ++var7) {
			RealmDefaultParentType var8 = (RealmDefaultParentType) var6.get(var7);
			String var9 = var8.getEntityTypeName();
			if (var2 != null && var2.equals(var9)) {
				var5 = var8.getParentUniqueName();
				break;
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getDefaultParentFromRealm(RealmType realm, String entityType)",
					"defaultParentName: " + var5);
		}

		return var5;
	}

	private List getIdMgrRepositoriesForRealm(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getIdMgrRepositoriesForRealm(String sessionId, String name)");
		}

		List var5 = (new RealmConfigHelper()).listIdMgrRealmBaseEntries(var1, var2);
		List var6 = ConfigUtils.getProfileRepositories(var1);
		ArrayList var7 = new ArrayList();

		for (int var8 = 0; var8 < var5.size(); ++var8) {
			String var9 = (String) var5.get(var8);
			ProfileRepositoryType var10 = this.getInformationForBaseEntry(var1, var9, var6);
			if (var10 != null) {
				var7.add(var10);
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "getIdMgrRepositoriesForRealm(String sessionId, String name)");
		}

		return var7;
	}

	private ProfileRepositoryType getInformationForBaseEntry(String var1, String var2, List var3) throws Exception {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME,
					"getInformationForBaseEntry(String sessionId, String baseEntryName, List repos)");
		}

		ProfileRepositoryType var6 = null;

		for (int var7 = 0; var7 < var3.size(); ++var7) {
			ProfileRepositoryType var8 = (ProfileRepositoryType) var3.get(var7);
			List var9 = var8.getBaseEntries();
			if (this.matchBaseDN(var2, var9)) {
				var6 = var8;
				break;
			}
		}

		if (var5) {
			trcLogger.exiting(CLASSNAME,
					"getInformationForBaseEntry(String sessionId, String baseEntryName, List repos)");
		}

		return var6;
	}

	private static Map getWASURInfoIfLDAP(String var0) throws Exception {
		boolean var2 = trcLogger.isLoggable(Level.FINER);
		if (var2) {
			trcLogger.entering(CLASSNAME, "getWASURInfoIfLDAP()", "uuid=" + var0);
		}

		HashMap var3 = new HashMap();
		String var4 = null;
		String var5 = null;
		ObjectName var6 = null;
		Object var7 = null;

		try {
			AdminClient var8 = AdminServiceFactory.getAdminService().getDeploymentManagerAdminClient();
			var7 = new ConfigServiceProxy(var8);
		} catch (Exception var26) {
			;
		}

		if (var7 == null) {
			var7 = ConfigServiceFactory.getConfigService();
		}

		if (var7 == null) {
			return null;
		} else {
			Session var30 = null;

			try {
				var30 = new Session();
				ObjectName var10;
				ObjectName[] var11;
				if (!DomainManagerUtils.isAdminDomain()) {
					String var9 = DomainManagerUtils.getDomainName();
					var10 = ConfigServiceHelper.createObjectName((ConfigDataId) null, "SecurityDomain");
					var11 = ((ConfigService) var7).queryConfigObjects(var30, (ObjectName) null, var10, (QueryExp) null);
					ObjectName var12 = null;

					for (int var13 = 0; var13 < var11.length; ++var13) {
						ObjectName var14 = var11[var13];
						String var15 = (String) ((ConfigService) var7).getAttribute(var30, var14, "name");
						if (var15.equals(var9)) {
							var10 = ConfigServiceHelper.createObjectName((ConfigDataId) null, "AppSecurity");
							var12 = ((ConfigService) var7).queryConfigObjects(var30, var14, var10, (QueryExp) null)[0];
							if (var12 != null) {
								break;
							}
						}
					}

					var6 = (ObjectName) ((ConfigService) var7).getAttribute(var30, var12, "activeUserRegistry");
					if (var6 == null) {
						if (var2) {
							trcLogger.logp(Level.FINER, CLASSNAME, "getWASURInfoIfLDAP()", "Domain, " + var9
									+ " does not have a active UserRegistry defined. Will be using Admin Domain UR");
						}
					} else if (var2) {
						trcLogger.logp(Level.FINER, CLASSNAME, "getWASURInfoIfLDAP()",
								"Got AppSecurity: " + var12 + " from App Domain: " + var9);
					}
				}

				if (var6 == null || DomainManagerUtils.isAdminDomain()) {
					ObjectName var31 = null;
					var10 = ConfigServiceHelper.createObjectName((ConfigDataId) null, "Security");
					ObjectName var33 = ((ConfigService) var7).resolve(var30, "Cell=")[0];
					ObjectName[] var37;
					if (var33 != null) {
						var37 = ((ConfigService) var7).queryConfigObjects(var30, var33, var10, (QueryExp) null);
						if (var37 != null && var37.length != 0) {
							var31 = var37[0];
						}
					}

					if (var31 == null) {
						var37 = ((ConfigService) var7).queryConfigObjects(var30, (ObjectName) null, var10,
								(QueryExp) null);
						if (var37 != null && var37.length != 0) {
							var31 = var37[0];
						}
					}

					trcLogger.logp(Level.FINER, CLASSNAME, "getWASURInfoIfLDAP()",
							"Got AdminSecurity: " + var31 + "for  admin/global Domain");
					var6 = (ObjectName) ((ConfigService) var7).getAttribute(var30, var31, "activeUserRegistry");
				}

				var4 = ConfigServiceHelper.getConfigDataType(var6);
				boolean var32 = false;

				try {
					HashMap var35;
					if ("WIMUserRegistry".equalsIgnoreCase(var4)) {
						var3.put("userRegistryType", "com.ibm.ws.wim.registry.WIMUserRegistry");
						var35 = var3;
						return var35;
					}

					if ("CustomUserRegistry".equalsIgnoreCase(var4)) {
						var5 = (String) ((ConfigService) var7).getAttribute(var30, var6, "customRegistryClassName");
						var3.put("userRegistryType", var5);
						var35 = var3;
						return var35;
					}

					if (!"LDAPUserRegistry".equalsIgnoreCase(var4)) {
						var3.put("userRegistryType", "unsupportedRegistryType");
						var35 = var3;
						return var35;
					}

					var3.put("userRegistryType", "LDAPUserRegistry");
					var32 = true;
				} catch (Exception var27) {
					;
				}

				var10 = null;

				try {
					String var34 = (String) ((ConfigService) var7).getAttribute(var30, var6, "serverId");
				} catch (Exception var25) {
					;
				}

				if (!var32) {
					if (var2) {
						trcLogger.logp(Level.FINER, CLASSNAME, "getWASURInfoIfLDAP()",
								"The active registry is not LDAP");
					}

					var11 = null;
					return var11;
				}

				if (var2) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getWASURInfoIfLDAP()", "This is LDAP user registry.");
				}

				ArrayList var36 = (ArrayList) ((ConfigService) var7).getAttribute(var30, var6, "hosts");
				String var38 = "";
				String var39 = "ldap://";
				if (var36 != null) {
					for (int var40 = 0; var40 < var36.size(); ++var40) {
						AttributeList var42 = (AttributeList) var36.get(var40);
						String var16 = (String) ConfigServiceHelper.getAttributeValue(var42, "host");
						Integer var17 = (Integer) ConfigServiceHelper.getAttributeValue(var42, "port");
						var3.put("port", var17);
						var3.put("host", var16);
						StringBuffer var18 = new StringBuffer();
						if (var16.startsWith(var39)) {
							var16 = var16.substring(var39.length());
						}

						var18.append(var39).append(var16);
						if (var17 != null && var17 > 0) {
							var18.append(":" + var17);
						}

						if (var18 != null && var18.length() > 0) {
							if (var38 == "") {
								var38 = var18.toString();
							} else if (var38.indexOf(var18.toString()) == -1) {
								var38 = var38 + " " + var18.toString();
							}
						}
					}
				}

				String var41 = (String) ((ConfigService) var7).getAttribute(var30, var6, "baseDN");
				var3.put("baseDN", var41);
				if (var2) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getWASURInfoIfLDAP()",
							"LDAP Information: " + var3.toString());
				}
			} catch (Exception var28) {
				if (var2) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getWASURInfoIfLDAP()", "Exception ", var28);
				}
			} finally {
				if (var7 != null) {
					((ConfigService) var7).discard(var30);
				}

			}

			if (var2) {
				trcLogger.exiting(CLASSNAME, "getWASURInfoIfLDAP()");
			}

			return var3;
		}
	}

	public static void clearCache(String var0) {
		boolean var2 = false;
		trcLogger.logp(Level.FINE, CLASSNAME, "clearCache",
				"key=" + var0 + ", cached results[" + resultCache.size() + "]=" + resultCache.keySet());
		if (resultCache.containsKey(var0)) {
			resultCache.remove(var0);
			var2 = true;
		}

		trcLogger.logp(Level.FINE, CLASSNAME, "clearCache", "cleared=" + var2);
	}

	private boolean matchBaseDN(String var1, List var2) {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "matchBaseDN(String defaultParent, List repoBaseEntries)",
					"repoBaseEntries: " + var2 + ", defaultParent: " + var1);
		}

		boolean var5 = false;

		for (int var6 = 0; var6 < var2.size(); ++var6) {
			BaseEntriesType var7 = (BaseEntriesType) var2.get(var6);
			String var8 = var7.getName();
			if (var8 != null) {
				if (var8.equals(var1)) {
					var5 = true;
					break;
				}

				if (var1.endsWith("," + var8)) {
					var5 = true;
					break;
				}
			}
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "matchBaseDN(String defaultParent, List repoBaseEntries)",
					"foundMatch: " + var5);
		}

		return var5;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		resultCache = new HashMap(1);
	}
}