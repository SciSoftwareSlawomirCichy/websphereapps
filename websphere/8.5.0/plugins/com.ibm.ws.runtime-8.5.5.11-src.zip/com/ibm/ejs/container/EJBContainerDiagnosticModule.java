package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.dopriv.SystemGetPropertyPrivileged;
import com.ibm.tx.jta.embeddable.EmbeddableTransactionManagerFactory;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.ejbcontainer.diagnostics.IncidentStreamWriter;
import com.ibm.ws.ffdc.DiagnosticModule;
import com.ibm.ws.ffdc.FFDC;
import com.ibm.ws.ffdc.IncidentStream;
import com.ibm.ws.runtime.component.EJBContainerImpl;
import com.ibm.ws.runtime.metadata.ComponentMetaData;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.naming.NameAlreadyBoundException;

public class EJBContainerDiagnosticModule extends DiagnosticModule {
	private static final TraceComponent tc = Tr.register(EJBContainerDiagnosticModule.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String JNDI_NAME = "     jndi name = ";
	private static final String EXPLICIT_BEAN = "                 explicit bean      = ";
	private static final String EXPLICIT_INTF = "                 explicit interface = ";
	private static final String IMPLICIT_BEAN = "                 implicit beans     = ";
	private static EJBContainerDiagnosticModule svInstance = null;
	private boolean ivRegisteredWithFFDC = false;
	private EJBContainerImpl ivEJBContainer = null;
	private EJSContainer ivEJSContainer = null;
	private HomeOfHomes ivHomeOfHomes;
	private String[] ivPackageList = new String[]{"com.ibm.ejs.container", "com.ibm.ejs.csi", "com.ibm.ejs.persistence",
			"com.ibm.ejs.util.cache", "com.ibm.ejs.util.opool", "com.ibm.ejs.util.tran", "com.ibm.websphere.cpi",
			"com.ibm.websphere.cpmi", "com.ibm.websphere.csi", "com.ibm.ws.ejb.portable", "com.ibm.ws.ejbcontainer",
			"com.ibm.ws.cpi", "com.ibm.ws.cpmi", "com.ibm.ws.metadata.ejb",
			"com.ibm.ws.runtime.component.EJBContainerImpl",
			"com.ibm.ws.threadContext.ws.ComponentMetaDataAccessorImpl",
			"com.ibm.ws.threadContext.ws.EJBMethodInfoAccessorImpl",
			"com.ibm.ws.threadContext.ws.EJSDeployedSupportAccessorImpl"};

	public static synchronized EJBContainerDiagnosticModule instance() {
		if (svInstance == null) {
			svInstance = new EJBContainerDiagnosticModule();
		}

		return svInstance;
	}

	public synchronized void initialize(EJBContainerImpl service, EJSContainer internal) {
		this.ivEJBContainer = service;
		this.ivEJSContainer = internal;
		this.ivHomeOfHomes = internal.getHomeOfHomes();
	}

	public synchronized boolean registerWithFFDCService() {
		boolean result = true;
		boolean abort = false;
		int retCode = false;
		int packageIndex = 0;
		if (this.ivRegisteredWithFFDC) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "EJBContainerDiagnosticModule already registered");
			}

			result = false;
			abort = true;
		}

		if (this.ivEJBContainer == null || this.ivEJSContainer == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc,
						"EJBContainerDiagnosticModule not initialized: registration with FFDC Service not performed");
			}

			result = false;
			abort = true;
		}

		for (; !abort && packageIndex < this.ivPackageList.length; ++packageIndex) {
			int retCode = FFDC.registerDiagnosticModule(this, this.ivPackageList[packageIndex]);
			switch (retCode) {
				case 0 :
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "EJBContainerDiagnosticModule successfully registered for package "
								+ this.ivPackageList[packageIndex]);
					}
					break;
				case 1 :
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc,
								"Unable to register EJBContainerDiagnosticModule as another diagnostic module has already been registered with the package "
										+ this.ivPackageList[packageIndex]);
					}

					result = false;
					break;
				case 2 :
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc,
								"Unable to register EJBContainerDiagnosticModule as it does not support the minimum diagnostic module interface.");
					}

					result = false;
					abort = true;
					break;
				case 3 :
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Unable to register EJBContainerDiagnosticModule due to an unknown failure.");
					}

					result = false;
					abort = true;
					break;
				default :
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc,
								"EJBContainerDiagnosticModule registration with " + this.ivPackageList[packageIndex]
										+ " resulted in an " + "unexpected return code: " + retCode);
					}

					result = false;
					abort = true;
			}
		}

		return result;
	}

	public void ffdcDumpDefault(Throwable th, IncidentStream is, Object callerThis, Object[] o, String sourceId) {
		if (o == null) {
			is.writeLine(">EJB DM: Object array.", o);
		} else {
			List<Object> oaList = new ArrayList(Arrays.asList(o));
			oaList.remove(this.ivEJSContainer);
			o = oaList.toArray();
			is.introspectAndWrite(">EJB DM: Object array", o, 2);
		}

		this.ivEJSContainer.ffdcDump(is);
		this.ivHomeOfHomes.ffdcDump(is);
	}

	public void ffdcDumpDefaultEJBThreadData(Throwable th, IncidentStream is, Object callerThis, Object[] o,
			String sourceId) {
		EJBThreadData threadData = EJSContainer.getThreadData();
		is.writeLine("CallbackBeanO", threadData.getCallbackBeanO());
	}

	public void ffdcDumpDefaultComponentMetaData(Throwable th, IncidentStream is, Object callerThis, Object[] o,
			String sourceId) {
		ComponentMetaData cmd = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor().getComponentMetaData();
		is.writeLine("Dump of ComponentMetaData", cmd);
	}

	public void ffdcDumpDefaultContainerTx(Throwable th, IncidentStream is, Object callerThis, Object[] o,
			String sourceId) {
		ContainerTx currentTx = null;
		EJSDeployedSupport s = null;
		if (callerThis instanceof ContainerTx) {
			currentTx = (ContainerTx) callerThis;
		} else {
			try {
				UOWCurrent uowCurrent = EmbeddableTransactionManagerFactory.getUOWCurrent();
				Object uowId = uowCurrent.getUOWCoord();
				if (uowId != null) {
					currentTx = (ContainerTx) ((SynchronizationRegistryUOWScope) uowId)
							.getResource(EJSContainer.containerTxResourceKey);
				}
			} catch (Throwable var11) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "ffdcDumpDefaultContainerTx : Unable to find ContainerTx : " + var11);
				}
			}

			try {
				s = EJSContainer.getMethodContext();
			} catch (Throwable var10) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "ffdcDumpDefaultContainerTx : Unable to find ContainerTx : " + var10);
				}
			}
		}

		if (currentTx != null) {
			is.writeLine("Dump of ContainerTx", "");
			currentTx.ffdcDump(is);
		} else {
			is.writeLine("Dump of ContainerTx", "CountainerTx not found for current thread");
		}

		if (s != null && s.currentTx != null && s.currentTx != currentTx) {
			is.writeLine("Dump of ContinerTx from EJSDeployedSupport", "");
			s.currentTx.ffdcDump(is);
		}

	}

	public void ffdcDumpDefaultEJBMethodInfo(Throwable th, IncidentStream is, Object callerThis, Object[] o,
			String sourceId) {
		SystemGetPropertyPrivileged pa = new SystemGetPropertyPrivileged("line.separator", "\n");
		String newLine = (String) AccessController.doPrivileged(pa);
		IncidentStreamWriter writer = new IncidentStreamWriter(is);

		try {
			EJSDeployedSupport s = EJSContainer.getMethodContext();
			EJBMethodInfoImpl ctxMethodInfo = null;
			if (s != null) {
				ctxMethodInfo = s.methodInfo;
				if (ctxMethodInfo != null) {
					writer.printHeader("Thread Context EJBMethodInfoImpl (from EJSDeployedSupport)");
					writer.indent();
					ctxMethodInfo.introspect(writer, (String) null, s.methodId, true);
					writer.outdent();
					writer.printFooter();
				}
			}

			EJBMethodInfoImpl callerMethodInfo = null;
			if (callerThis != ctxMethodInfo && callerThis instanceof EJBMethodInfoImpl) {
				callerMethodInfo = (EJBMethodInfoImpl) callerThis;
				writer.printHeader("EJBMethodInfo where exception occured");
				writer.indent();
				callerMethodInfo.introspect(writer, (String) null, Integer.MAX_VALUE, true);
				writer.outdent();
				writer.printFooter();
			}
		} catch (Throwable var12) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, newLine + "ffdcDumpDefaultEJBMethodInfo unable to find EJBMethodInfo: " + var12);
			}
		}

	}

	public void ffdcDumpDefaultBindingsMaps(Throwable th, IncidentStream is, Object callerThis, Object[] o,
			String sourceId) {
		if (th instanceof NameAlreadyBoundException) {
			StringBuilder sb = new StringBuilder();
			HashMap<String, BindingData> bindings = null;
			SystemGetPropertyPrivileged pa = new SystemGetPropertyPrivileged("line.separator", "\n");
			String newLine = (String) AccessController.doPrivileged(pa);
			bindings = BindingsHelper.cvAllRemoteBindings;
			sb.append(" Total Entries : " + bindings.size()).append(newLine);
			Iterator i$ = bindings.keySet().iterator();

			String jndiName;
			BindingData bdata;
			while (i$.hasNext()) {
				jndiName = (String) i$.next();
				bdata = (BindingData) bindings.get(jndiName);
				sb.append(newLine);
				sb.append("     jndi name = ").append(jndiName);
				sb.append(newLine);
				sb.append("                 explicit bean      = ").append(bdata.ivExplicitBean);
				sb.append(newLine);
				sb.append("                 explicit interface = ").append(bdata.ivExplicitInterface);
				sb.append(newLine);
				sb.append("                 implicit beans     = ").append(bdata.ivImplicitBeans);
			}

			if (bindings.size() > 0) {
				sb.append(newLine);
			}

			sb.append(newLine).append("End Dump of Remote Bindings Map");
			is.writeLine(newLine + "Start Dump of Remote Bindings Map", sb.toString());
			sb.setLength(0);
			bindings = BindingsHelper.cvAllLocalBindings;
			sb.append(" Total Entries : " + bindings.size()).append(newLine);
			i$ = bindings.keySet().iterator();

			while (i$.hasNext()) {
				jndiName = (String) i$.next();
				bdata = (BindingData) bindings.get(jndiName);
				sb.append(newLine);
				sb.append("     jndi name = ").append(jndiName);
				sb.append(newLine);
				sb.append("                 explicit bean      = ").append(bdata.ivExplicitBean);
				sb.append(newLine);
				sb.append("                 explicit interface = ").append(bdata.ivExplicitInterface);
				sb.append(newLine);
				sb.append("                 implicit beans     = ").append(bdata.ivImplicitBeans);
			}

			if (bindings.size() > 0) {
				sb.append(newLine);
			}

			sb.append(newLine).append("End Dump of Local Bindings Map");
			sb.append(newLine);
			is.writeLine(newLine + "Dump of Local Bindings Map", sb.toString());
		}

	}
}