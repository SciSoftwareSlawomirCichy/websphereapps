package com.ibm.ejs.container;

import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.csi.EJBComponentMetaData;
import com.ibm.websphere.csi.EJBMethodInfo;
import com.ibm.ws.appprofile.accessintent.EJBAccessIntent;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.wsspi.security.policy.EJBSecurityPolicy;

public class SharedEJBMethodInfoImpl extends EJBMethodInfoImpl implements EJBMethodInfo {
	final EJBSecurityPolicyImpl ivSecurityPolicy = new EJBSecurityPolicyImpl(false, false, (String[]) null, this);

	public SharedEJBMethodInfoImpl(int slotSize) {
		super(slotSize);
	}

	public EJBComponentMetaData getEJBComponentMetaData() {
		return (EJBComponentMetaData) this.bmd;
	}

	public void setSecurityPolicy(boolean denyAll, boolean permitAll, String[] rolesAllowed) {
		super.setSecurityPolicy(denyAll, permitAll, rolesAllowed);
		this.ivSecurityPolicy.ivDenyAll = denyAll;
		this.ivSecurityPolicy.ivPermitAll = permitAll;
		this.ivSecurityPolicy.ivRolesAllowed = rolesAllowed;
	}

	public EJBSecurityPolicy getEJBSecurityPolicy() {
		return this.ivSecurityPolicy;
	}

	public void introspectSecurityInfo(IntrospectionWriter writer) {
		this.ivSecurityPolicy.introspect(writer);
	}

	public AccessIntent getAccessIntent(EJBAccessIntent aiService) {
		throw new UnsupportedOperationException();
	}

	public AccessIntent getMethodAccessIntent(EJBAccessIntent aiService) {
		throw new UnsupportedOperationException();
	}

	public void setPMInternalAccessIntent(AccessIntent ai) {
		throw new UnsupportedOperationException();
	}
}