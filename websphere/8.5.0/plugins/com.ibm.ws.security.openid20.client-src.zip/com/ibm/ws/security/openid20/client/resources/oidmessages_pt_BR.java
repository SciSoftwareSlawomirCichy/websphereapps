package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages_pt_BR extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: A parte confiável (RP) do OpenID falhou ao redirecionar o usuário usando o provedor do OpenID (OP) para autenticação devido à exceção [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: A parte confiável (RP) do OpenID falhou ao inicializar porque falhou ao obter o SSLContext padrão para o WebSphere Server. A exceção é [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: A parte confiável (RP) do OpenID falhou ao conectar-se ao provedor do OpenID (OP) especificado pelo identificador [{0}] devido à exceção [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: A parte confiável (RP) do OpenID falhou ao inicializar devido à exceção [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: A parte confiável (RP) do OpenID não foi inicializada porque o valor da propriedade [{0}] não está formatado corretamente."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: A parte confiável (RP) do OpenID Connect falhou ao autenticar uma solicitação usando o token de Autenticação Básica, porque o valor do token não é válido."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: A parte confiável (RP) do OpenID falhou ao inicializar porque a propriedade [{0}] não está especificada corretamente. Deve ser uma URL válida."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: A parte confiável (RP) do OpenID recebeu uma resposta incorreta do provedor do OpenID (OP). A causa desse erro é [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: A parte confiável (RP) do OpenID falhou ao executar a autenticação porque atingiu a capacidade máxima de seu cache interno."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: A parte confiável (RP) do OpenID falhou ao inicializar porque a propriedade obrigatória axRequiredAttribute[n] está ausente. Pelo menos uma propriedade precisa ser definida."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: A parte confiável (RP) do OpenID falhou ao inicializar porque o valor para a propriedade obrigatória [{0}] está ausente ou vazio."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: A parte confiável (RP) do OpenID requer SSL (HTTPS), mas a URL do provedor do provedor do OpenID (OP) é HTTP: [{0}].  O atributo [{1}] deve corresponder ao nome da URL de destino. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: A parte confiável (RP) do OpenID recebeu uma resposta do provedor do OpenID (OP), que não suporta a versão 2 da especificação do OpenID."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: A parte confiável (RP) do OpenID falhou durante a verificação da resposta recebida do provedor do OpenID (OP). A exceção foi [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}