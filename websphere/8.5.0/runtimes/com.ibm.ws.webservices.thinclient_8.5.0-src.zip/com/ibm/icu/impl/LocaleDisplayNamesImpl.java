package com.ibm.icu.impl;

import com.ibm.icu.impl.LocaleDisplayNamesImpl.1;
import com.ibm.icu.impl.LocaleDisplayNamesImpl.Appender;
import com.ibm.icu.impl.LocaleDisplayNamesImpl.Cache;
import com.ibm.icu.impl.LocaleDisplayNamesImpl.DataTable;
import com.ibm.icu.impl.LocaleDisplayNamesImpl.DataTableType;
import com.ibm.icu.impl.LocaleDisplayNamesImpl.ICUDataTables;
import com.ibm.icu.impl.LocaleDisplayNamesImpl.LangDataTables;
import com.ibm.icu.impl.LocaleDisplayNamesImpl.RegionDataTables;
import com.ibm.icu.lang.UScript;
import com.ibm.icu.text.LocaleDisplayNames;
import com.ibm.icu.text.MessageFormat;
import com.ibm.icu.text.LocaleDisplayNames.DialectHandling;
import com.ibm.icu.util.ULocale;
import java.util.Iterator;
import java.util.Locale;

public class LocaleDisplayNamesImpl extends LocaleDisplayNames {
	private final ULocale locale;
	private final DialectHandling dialectHandling;
	private final DataTable langData;
	private final DataTable regionData;
	private final Appender appender;
	private final MessageFormat format;
	private static final Cache cache = new Cache((1)null);

	public static LocaleDisplayNames getInstance(ULocale locale, DialectHandling dialectHandling) {
		Cache var2 = cache;
		synchronized (cache) {
			return cache.get(locale, dialectHandling);
		}
	}

	public LocaleDisplayNamesImpl(ULocale locale, DialectHandling dialectHandling) {
		this.dialectHandling = dialectHandling;
		this.langData = LangDataTables.impl.get(locale);
		this.regionData = RegionDataTables.impl.get(locale);
		this.locale = ULocale.ROOT.equals(this.langData.getLocale())
				? this.regionData.getLocale()
				: this.langData.getLocale();
		String sep = this.langData.get("localeDisplayPattern", "separator");
		if ("separator".equals(sep)) {
			sep = ", ";
		}

		this.appender = new Appender(sep);
		String pattern = this.langData.get("localeDisplayPattern", "pattern");
		if ("pattern".equals(pattern)) {
			pattern = "{0} ({1})";
		}

		this.format = new MessageFormat(pattern);
	}

	public ULocale getLocale() {
		return this.locale;
	}

	public DialectHandling getDialectHandling() {
		return this.dialectHandling;
	}

	public String localeDisplayName(ULocale locale) {
		return this.localeDisplayNameInternal(locale);
	}

	public String localeDisplayName(Locale locale) {
		return this.localeDisplayNameInternal(ULocale.forLocale(locale));
	}

	public String localeDisplayName(String localeId) {
		return this.localeDisplayNameInternal(new ULocale(localeId));
	}

	private String localeDisplayNameInternal(ULocale locale) {
		String resultName = null;
		String lang = locale.getLanguage();
		if (locale.getBaseName().length() == 0) {
			lang = "root";
		}

		String script = locale.getScript();
		String country = locale.getCountry();
		String variant = locale.getVariant();
		boolean hasScript = script.length() > 0;
		boolean hasCountry = country.length() > 0;
		boolean hasVariant = variant.length() > 0;
		if (this.dialectHandling == DialectHandling.DIALECT_NAMES) {
			label83 : {
				String langCountry;
				String result;
				if (hasScript && hasCountry) {
					langCountry = lang + '_' + script + '_' + country;
					result = this.localeIdName(langCountry);
					if (!result.equals(langCountry)) {
						resultName = result;
						hasScript = false;
						hasCountry = false;
						break label83;
					}
				}

				if (hasScript) {
					langCountry = lang + '_' + script;
					result = this.localeIdName(langCountry);
					if (!result.equals(langCountry)) {
						resultName = result;
						hasScript = false;
						break label83;
					}
				}

				if (hasCountry) {
					langCountry = lang + '_' + country;
					result = this.localeIdName(langCountry);
					if (!result.equals(langCountry)) {
						resultName = result;
						hasCountry = false;
					}
				}
			}
		}

		if (resultName == null) {
			resultName = this.localeIdName(lang);
		}

		StringBuilder buf = new StringBuilder();
		if (hasScript) {
			buf.append(this.scriptDisplayName(script));
		}

		if (hasCountry) {
			this.appender.append(this.regionDisplayName(country), buf);
		}

		if (hasVariant) {
			this.appender.append(this.variantDisplayName(variant), buf);
		}

		Iterator<String> keys = locale.getKeywords();
		String resultRemainder;
		if (keys != null) {
			while (keys.hasNext()) {
				resultRemainder = (String) keys.next();
				String value = locale.getKeywordValue(resultRemainder);
				this.appender.append(this.keyDisplayName(resultRemainder), buf).append("=")
						.append(this.keyValueDisplayName(resultRemainder, value));
			}
		}

		resultRemainder = null;
		if (buf.length() > 0) {
			resultRemainder = buf.toString();
		}

		return resultRemainder != null ? this.format.format(new Object[]{resultName, resultRemainder}) : resultName;
	}

	private String localeIdName(String localeId) {
		return this.langData.get("Languages", localeId);
	}

	public String languageDisplayName(String lang) {
		return !lang.equals("root") && lang.indexOf(95) == -1 ? this.langData.get("Languages", lang) : lang;
	}

	public String scriptDisplayName(String script) {
		return this.langData.get("Scripts", script);
	}

	public String scriptDisplayName(int scriptCode) {
		return this.scriptDisplayName(UScript.getShortName(scriptCode));
	}

	public String regionDisplayName(String region) {
		return this.regionData.get("Countries", region);
	}

	public String variantDisplayName(String variant) {
		return this.langData.get("Variants", variant);
	}

	public String keyDisplayName(String key) {
		return this.langData.get("Keys", key);
	}

	public String keyValueDisplayName(String key, String value) {
		return this.langData.get("Types", key, value);
	}

	public static boolean haveData(DataTableType type) {
      switch(1.$SwitchMap$com$ibm$icu$impl$LocaleDisplayNamesImpl$DataTableType[type.ordinal()]) {
      case 1:
         return LangDataTables.impl instanceof ICUDataTables;
      case 2:
         return RegionDataTables.impl instanceof ICUDataTables;
      default:
         throw new IllegalArgumentException("unknown type: " + type);
      }
   }
}