package com.ibm.icu.impl.duration.impl;

import java.util.Collection;

public abstract class PeriodFormatterDataService {
	public abstract PeriodFormatterData get(String var1);

	public abstract Collection<String> getAvailableLocales();
}