package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.CMPropertiesImpl;
import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.cm.pool.ConnectOEventListener;
import com.ibm.ejs.cm.pool.ExtendedConnection;
import com.ibm.ejs.cm.portability.PortabilityLayer;
import com.ibm.ejs.cm.portability.PortabilityLayerExt;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceNLS;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.ClientInfoStatus;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

public class ConnectionProxy extends Proxy implements ExtendedConnection, ConnectOEventListener {
	private static final TraceNLS NLS = TraceNLS.getTraceNLS("com.ibm.ejs.resources.CONMMessages");
	protected ConnectO connection;
	protected boolean disableCleanup;
	private static final TraceComponent tc = Tr.register(ConnectionProxy.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createArrayOf(String, Object[])");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Blob createBlob() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createBlob()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Clob createClob() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createClob()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public NClob createNClob() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createNClob()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public SQLXML createSQLXML() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createSQLXML()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "createStruct(String, Object[])");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public Properties getClientInfo() throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getClientInfo()");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public String getClientInfo(String name) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "getClientInfo(String)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public boolean isValid(int timeout) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isValid(int)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setClientInfo(Properties properties) throws SQLClientInfoException {
		Tr.error(tc, "MSG_CONM_8001E", "setClientInfo(Properties)");
		HashMap<String, ClientInfoStatus> hm = null;
		if (properties != null && properties.size() != 0) {
			hm = new HashMap();
			Enumeration keys = properties.keys();

			while (keys.hasMoreElements()) {
				Object key = keys.nextElement();
				if (key != null) {
					hm.put(key.toString(), ClientInfoStatus.REASON_UNKNOWN);
				} else {
					hm.put((Object) null, ClientInfoStatus.REASON_UNKNOWN);
				}
			}
		} else {
			hm = new HashMap(0);
		}

		throw new SQLClientInfoException(NLS.getString("MSG_CONM_8002E", "This method is not supported."), hm);
	}

	public void setClientInfo(String name, String value) throws SQLClientInfoException {
		Tr.error(tc, "MSG_CONM_8001E", "setClientInfo(String, String)");
		HashMap<String, ClientInfoStatus> hm = new HashMap(1);
		hm.put(name, ClientInfoStatus.REASON_UNKNOWN);
		throw new SQLClientInfoException(NLS.getString("MSG_CONM_8002E", "This method is not supported."), hm);
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "isWrapperFor(Class<?>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		Tr.error(tc, "MSG_CONM_8001E", "unwrap(Class<T>)");
		throw new SQLFeatureNotSupportedException(NLS.getString("MSG_CONM_8002E", "This method is not supported."));
	}

	public void setHoldability(int h) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setHoldability(int)");
		throw new SQLException("This method is not supported.");
	}

	public int getHoldability() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "getHoldability()");
		throw new SQLException("This method is not supported.");
	}

	public Savepoint setSavepoint() throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setSavepoint()");
		throw new SQLException("This method is not supported.");
	}

	public Savepoint setSavepoint(String s) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "setSavepoint(String)");
		throw new SQLException("This method is not supported.");
	}

	public void rollback(Savepoint sp) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "rollback(Savepoint)");
		throw new SQLException("This method is not supported.");
	}

	public void releaseSavepoint(Savepoint sp) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "releaseSavepoint(Savepoint)");
		throw new SQLException("This method is not supported.");
	}

	public Statement createStatement(int x, int y, int z) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "createStatement(int, int, int)");
		throw new SQLException("This method is not supported.");
	}

	public PreparedStatement prepareStatement(String s, int x, int y, int z) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareStatement(String, int, int, int)");
		throw new SQLException("This method is not supported.");
	}

	public CallableStatement prepareCall(String s, int x, int y, int z) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareCall(String, int, int, int)");
		throw new SQLException("This method is not supported.");
	}

	public PreparedStatement prepareStatement(String s, int x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareStatement(String, int)");
		throw new SQLException("This method is not supported.");
	}

	public PreparedStatement prepareStatement(String s, int[] x) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareStatement(String, int[])");
		throw new SQLException("This method is not supported.");
	}

	public PreparedStatement prepareStatement(String s, String[] strs) throws SQLException {
		Tr.error(tc, "MSG_CONM_8000E", "prepareStatement(String, String[])");
		throw new SQLException("This method is not supported.");
	}

	public ConnectionProxy(ConnectO connection) {
		super(connection);
		this.lockObject = new Object();
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", connection);
		}

		this.connection = connection;
		this.disableCleanup = ((CMPropertiesImpl) ((CMPropertiesImpl) connection.getPool().getAttributes()))
				.isAutoConnCleanupDisabled();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void connectionEnlisted(ConnectO c, Object coord) {
	}

	public void connectionDestroyed(ConnectO c) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connectionDestroyed", c);
		}

		try {
			this.close();
		} catch (SQLException var3) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "connectionDestroyed error", var3);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connectionDestroyed");
		}

	}

	public void setDestroyed(ConnectO c) {
		if (tc.isEventEnabled()) {
			Tr.event(tc, "setDestroyed", c);
		}

		super.setDestroyedProxy();
	}

	public boolean connectionIdleTimeout(ConnectO c) {
		return true;
	}

	public boolean connectionAgedTimeout(ConnectO c) {
		return true;
	}

	public void connectionTxComplete(ConnectO c, int status, Object tx) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connectionTxComplete", new Object[]{c, new Integer(status), tx});
		}

		try {
			if (!this.disableCleanup) {
				this.close();
			}
		} catch (SQLException var5) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "connectionTxComplete - error", var5);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connectionTxComplete");
		}

	}

	public void connectionOrphaned(ConnectO c) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connectionOrphaned", c);
		}

		try {
			this.close();
		} catch (SQLException var3) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "connectionOrphaned error", var3);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connectionOrphaned");
		}

	}

	public PortabilityLayerExt getPortabilityLayer() throws SQLException {
		return this.getConnection().getPortabilityLayer();
	}

	public SQLException translateException(SQLException e) throws SQLException {
		return this.getConnection().translateException(e);
	}

	public String getColumnTypeSpec(int type) throws SQLException {
		try {
			return this.getConnection().getColumnTypeSpec(type);
		} catch (SQLException var3) {
			throw this.translateException(var3);
		}
	}

	public String addRowLockHint(String sql) throws SQLException {
		try {
			return this.getConnection().addRowLockHint(sql);
		} catch (SQLException var3) {
			throw this.translateException(var3);
		}
	}

	public Connection getPhysicalConnection() throws SQLException {
		try {
			return this.getConnection().getPhysicalConnection();
		} catch (SQLException var2) {
			throw this.translateException(var2);
		}
	}

	public void unilateralCommit() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke(false);
					this.getConnection().unilateralCommit();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
					this.close();
				}
			}
		}

	}

	public Statement createStatement(int type, int concurrency) throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				StatementProxy var6;
				try {
					this.__preInvoke();
					Statement stmt = this.getConnection().createStatement(type, concurrency);
					if (stmt == null) {
						var6 = null;
						return var6;
					}

					var6 = new StatementProxy(this, stmt);
				} catch (SQLException var12) {
					x = var12;
					throw this.translateException(var12);
				} finally {
					this.__postInvoke(x);
				}

				return var6;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public PreparedStatement prepareStatement(String sql, int type, int concurrency) throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				PreparedStatementProxy var7;
				try {
					this.__preInvoke();
					PreparedStatement ps = this.getConnection().prepareStatement(
							((PortabilityLayer) this.getPortabilityLayer()).scanSQL(sql), type, concurrency);
					if (ps == null) {
						var7 = null;
						return var7;
					}

					var7 = new PreparedStatementProxy(this, ps);
				} catch (SQLException var13) {
					x = var13;
					throw this.translateException(var13);
				} finally {
					this.__postInvoke(x);
				}

				return var7;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public CallableStatement prepareCall(String sql, int type, int concurrency) throws SQLException {
		SQLException x = null;
		if (this.isClosed()) {
			throw new StaleConnectionException(this.getClass() + " is closed");
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Preparing call for " + sql);
			}

			synchronized (this.getLockObject()) {
				CallableStatementProxy var7;
				try {
					this.__preInvoke();
					CallableStatement cs = this.getConnection().prepareCall(
							((PortabilityLayer) this.getPortabilityLayer()).scanSQL(sql), type, concurrency);
					if (cs != null) {
						var7 = new CallableStatementProxy(this, cs);
						return var7;
					}

					var7 = null;
				} catch (SQLException var13) {
					x = var13;
					throw this.translateException(var13);
				} finally {
					this.__postInvoke(x);
				}

				return var7;
			}
		}
	}

	public final Map<String, Class<?>> getTypeMap() throws SQLException {
		try {
			return this.getConnection().getTypeMap();
		} catch (SQLException var2) {
			throw this.translateException(var2);
		}
	}

	public final void setTypeMap(Map<String, Class<?>> types) throws SQLException {
		try {
			this.getConnection().setTypeMap(types);
		} catch (SQLException var3) {
			throw this.translateException(var3);
		}
	}

	public Statement createStatement() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				StatementProxy var4;
				try {
					this.__preInvoke();
					Statement cs = this.getConnection().createStatement();
					if (cs != null) {
						var4 = new StatementProxy(this, cs);
						return var4;
					}

					var4 = null;
				} catch (SQLException var10) {
					x = var10;
					throw this.translateException(var10);
				} finally {
					this.__postInvoke(x);
				}

				return var4;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public PreparedStatement prepareStatement(String sql) throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				PreparedStatementProxy var5;
				try {
					this.__preInvoke();
					PreparedStatement ps = this.getConnection()
							.prepareStatement(((PortabilityLayer) this.getPortabilityLayer()).scanSQL(sql));
					if (ps == null) {
						var5 = null;
						return var5;
					}

					var5 = new PreparedStatementProxy(this, ps);
				} catch (SQLException var11) {
					x = var11;
					throw this.translateException(var11);
				} finally {
					this.__postInvoke(x);
				}

				return var5;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public CallableStatement prepareCall(String sql) throws SQLException {
		SQLException x = null;
		if (this.isClosed()) {
			throw new StaleConnectionException(this.getClass() + " is closed");
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Preparing call for " + sql);
			}

			synchronized (this.getLockObject()) {
				CallableStatementProxy var5;
				try {
					this.__preInvoke();
					CallableStatement cs = this.getConnection()
							.prepareCall(((PortabilityLayer) this.getPortabilityLayer()).scanSQL(sql));
					if (cs != null) {
						var5 = new CallableStatementProxy(this, cs);
						return var5;
					}

					var5 = null;
				} catch (SQLException var11) {
					x = var11;
					throw this.translateException(var11);
				} finally {
					this.__postInvoke(x);
				}

				return var5;
			}
		}
	}

	public final String nativeSQL(String sql) throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				String var5;
				try {
					this.__preInvoke();
					String scannedSQL = ((PortabilityLayer) this.getPortabilityLayer()).scanSQL(sql);
					var5 = this.getConnection().nativeSQL(scannedSQL);
				} catch (SQLException var11) {
					x = var11;
					throw this.translateException(var11);
				} finally {
					this.__postInvoke(x);
				}

				return var5;
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public final void setAutoCommit(boolean autoCommit) throws SQLException {
		try {
			this.getConnection().setAutoCommit(autoCommit);
		} catch (SQLException var3) {
			throw this.translateException(var3);
		}
	}

	public final boolean getAutoCommit() throws SQLException {
		try {
			return this.getConnection().getAutoCommit();
		} catch (SQLException var2) {
			throw this.translateException(var2);
		}
	}

	public final void commit() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getConnection().commit();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public final void rollback() throws SQLException {
		SQLException x = null;
		if (!this.isClosed()) {
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					this.getConnection().rollback();
				} catch (SQLException var9) {
					x = var9;
					throw this.translateException(var9);
				} finally {
					this.__postInvoke(x);
				}
			}
		}

	}

	public void close() throws SQLException {
		if (!this.isClosed()) {
			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "close");
			}

			SQLException caughtException = null;
			synchronized (this.getLockObject()) {
				try {
					super.setisConnClosing(true);
					super.close();
					super.setisConnClosing(false);
				} catch (SQLException var46) {
					caughtException = var46;
				} finally {
					try {
						if (this.connection != null) {
							this.connection.removeEventListener(this);
							this.connection.getPool().freeConnection(this.connection);
						}
					} catch (SQLException var47) {
						if (caughtException == null) {
							caughtException = var47;
							if (tc.isEventEnabled()) {
								Tr.event(tc, "Exception closing connection", var47);
							}
						} else if (tc.isEventEnabled()) {
							Tr.event(tc, "Secondary exception closing connection", var47);
						}
					} finally {
						this.connection = null;
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "close");
						}

					}

				}

				if (caughtException != null) {
					throw caughtException;
				}

				if (this.connection != null) {
					ConnectO connO = this.connection;
					this.connection = null;
					connO.removeEventListener(this);
					connO.getPool().freeConnection(connO);
				}
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "close");
			}

		}
	}

	public final DatabaseMetaData getMetaData() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getMetaData");
		}

		SQLException x = null;
		if (!this.isClosed()) {
			DatabaseMetaData result = null;
			synchronized (this.getLockObject()) {
				try {
					this.__preInvoke();
					result = this.getConnection().getMetaData();
				} catch (SQLException var10) {
					x = var10;
				} finally {
					this.__postInvoke(x);
					if (x != null) {
						x = this.translateException(x);
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "getMetaData - SQLException", x);
						}

						throw x;
					} else {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "getMetaData", result);
						}

						return result;
					}
				}
			}
		} else {
			throw new StaleConnectionException(this.getClass() + " is closed");
		}
	}

	public final void setReadOnly(boolean readOnly) throws SQLException {
		try {
			this.getConnection().setReadOnly(readOnly);
		} catch (SQLException var3) {
			throw this.translateException(var3);
		}
	}

	public final boolean isReadOnly() throws SQLException {
		try {
			return this.getConnection().isReadOnly();
		} catch (SQLException var2) {
			throw this.translateException(var2);
		}
	}

	public final void setCatalog(String catalog) throws SQLException {
		try {
			this.getConnection().setCatalog(catalog);
		} catch (SQLException var3) {
			throw this.translateException(var3);
		}
	}

	public final String getCatalog() throws SQLException {
		try {
			return this.getConnection().getCatalog();
		} catch (SQLException var2) {
			throw this.translateException(var2);
		}
	}

	public final void setTransactionIsolation(int level) throws SQLException {
		try {
			this.getConnection().setTransactionIsolation(level);
		} catch (SQLException var3) {
			throw this.translateException(var3);
		}
	}

	public final int getTransactionIsolation() throws SQLException {
		try {
			return this.getConnection().getTransactionIsolation();
		} catch (SQLException var2) {
			throw this.translateException(var2);
		}
	}

	public final SQLWarning getWarnings() throws SQLException {
		try {
			return this.getConnection().getWarnings();
		} catch (SQLException var2) {
			throw this.translateException(var2);
		}
	}

	public final void clearWarnings() throws SQLException {
		try {
			this.getConnection().clearWarnings();
		} catch (SQLException var2) {
			throw this.translateException(var2);
		}
	}

	public void abort(Executor executor) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public int getNetworkTimeout() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public String getSchema() throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	public void setSchema(String schema) throws SQLException {
		throw new SQLFeatureNotSupportedException();
	}

	protected final ConnectO getConnection() throws SQLException {
		if (this.isClosed()) {
			throw new StaleConnectionException("Connection is closed");
		} else {
			return this.connection;
		}
	}

	protected Object getLockObject() {
		return this.lockObject;
	}
}