package com.ibm.ejs.container;

public class IllegalSessionMethodLocalException extends ContainerLocalException {
	private static final long serialVersionUID = 2467827007726460881L;
}