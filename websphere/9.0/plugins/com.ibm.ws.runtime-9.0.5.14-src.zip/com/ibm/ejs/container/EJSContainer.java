package com.ibm.ejs.container;

import com.ibm.ejs.container.EJSContainer.1;
import com.ibm.ejs.container.activator.ActivationStrategy;
import com.ibm.ejs.container.activator.Activator;
import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.container.lock.LockManager;
import com.ibm.ejs.container.passivator.StatefulPassivator;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.container.util.MethodAttribUtils;
import com.ibm.ejs.csi.UOWControl;
import com.ibm.ejs.ras.Dumpable;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.FastHashtable;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.cpi.PersisterFactory;
import com.ibm.websphere.csi.CSIAccessException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.ContainerExtensionFactory;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.J2EENameFactory;
import com.ibm.websphere.csi.MethodInterface;
import com.ibm.websphere.csi.ORBDispatchInterceptor;
import com.ibm.websphere.csi.OrbUtils;
import com.ibm.websphere.csi.StatefulSessionHandleFactory;
import com.ibm.websphere.csi.StatefulSessionKeyFactory;
import com.ibm.websphere.csi.TransactionAttribute;
import com.ibm.websphere.ejbcontainer.EJBStoppedException;
import com.ibm.ws.csi.DispatchEventListenerCookie;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import com.ibm.ws.ejbcontainer.EJBPMICollaboratorFactory;
import com.ibm.ws.ejbcontainer.EJBRequestCollaborator;
import com.ibm.ws.ejbcontainer.EJBRequestData;
import com.ibm.ws.ejbcontainer.EJBSecurityCollaborator;
import com.ibm.ws.ejbcontainer.diagnostics.IncidentStreamWriter;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.ws.ejbcontainer.diagnostics.TrDumpWriter;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ejbcontainer.jitdeploy.JITDeploy;
import com.ibm.ws.ejbcontainer.runtime.EJBRuntime;
import com.ibm.ws.ejbcontainer.util.ObjectCopier;
import com.ibm.ws.ejbcontainer.util.Pool;
import com.ibm.ws.ejbcontainer.util.PoolManager;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.ffdc.FFDCSelfIntrospectable;
import com.ibm.ws.ffdc.IncidentStream;
import com.ibm.ws.managedobject.ManagedObjectContext;
import com.ibm.ws.traceinfo.ejbcontainer.TEEJBInvocationInfo;
import com.ibm.ws.traceinfo.ejbcontainer.TETxLifeCycleInfo;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import com.ibm.ws.uow.embeddable.UOWManager;
import com.ibm.ws.uow.embeddable.UOWManagerFactory;
import com.ibm.ws.util.StatefulBeanEnqDeq;
import com.ibm.wsspi.ejbcontainer.WSEJBEndpointManager;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;
import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.ejb.EJBAccessException;
import javax.ejb.EJBException;
import javax.ejb.EJBHome;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBObject;
import javax.ejb.EJBTransactionRolledbackException;
import javax.ejb.EnterpriseBean;
import javax.ejb.NoSuchEJBException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.RemoveException;
import javax.ejb.Timer;
import javax.rmi.PortableRemoteObject;
import javax.rmi.CORBA.Tie;
import javax.transaction.TransactionRolledbackException;
import javax.transaction.UserTransaction;
import org.omg.CORBA.OBJECT_NOT_EXIST;
import org.omg.CORBA.portable.UnknownException;

public class EJSContainer implements Dumpable, ORBDispatchInterceptor, FFDCSelfIntrospectable {
	private static final String CLASS_NAME = EJSContainer.class.getName();
	private static final TraceComponent tc = Tr.register(EJSContainer.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final TraceComponent tcClntInfo = Tr.register("WAS.clientinfopluslogging",
			"WAS.clientinfopluslogging", "com.ibm.ejs.container.container");
	public static final int MID_getLink = -1;
	public static final int MID_LOCAL_HOME_INDEX = -2;
	public static final int MID_REMOTE_HOME_INDEX = -3;
	public static final int MID_MANDATORY_LOCAL_HOME_INDEX = -4;
	public static final int MID_MANDATORY_REMOTE_HOME_INDEX = -5;
	public static final int MID_BUSINESS_REMOVE = -6;
	public static final String NOARG_CTOR_NOT_FOUND = "A public no-arg constructor has not been provided for the enterprise bean implementation class.";
	public static final String NOARG_CTOR_FAILURE = "An operation in the enterprise bean constructor failed. It is recommended that component initialization logic be placed in a PostConstruct method instead of the bean class no-arg constructor.";
	protected StatefulBeanEnqDeq ivStatefulBeanEnqDeq;
	protected DispatchEventListenerManager ivDispatchEventListenerManager;
	protected static final boolean isZOS = EJSPlatformHelper.isZOS();
	protected static final boolean isZOSCRA = EJSPlatformHelper.isZOSCRA();
	private boolean initialized;
	protected static EJSContainer defaultContainer;
	public static HomeOfHomes homeOfHomes;
	protected WrapperManager wrapperManager;
	protected EntityHelper ivEntityHelper;
	protected Activator activator;
	protected LockManager lockManager;
	protected StatefulPassivator passivator;
	protected static StatefulSessionKeyFactory sessionKeyFactory;
	protected StatefulSessionHandleFactory sessionHandleFactory;
	public PersisterFactory persisterFactory;
	public ObjectCopier ivObjectCopier;
	protected Hashtable<J2EEName, BeanMetaData> internalBeanMetaDataStore;
	protected static ClassLoader classLoader;
	private static ThreadLocal<EJBThreadData> svThreadData = new 1();
	protected static final FastHashtable<Object, ContainerAS> containerASMap = new FastHashtable(251);
	public static final String containerTxResourceKey;
	protected UOWControl uowCtrl;
	protected UserTransaction userTransactionImpl;
	protected UOWManager ivUOWManager;
	protected volatile EJBSecurityCollaborator<?> ivSecurityCollaborator;
	protected EJBRequestCollaborator<?>[] ivAfterActivationCollaborators;
	protected EJBRequestCollaborator<?>[] ivBeforeActivationCollaborators;
	protected EJBRequestCollaborator<?>[] ivBeforeActivationAfterCompletionCollaborators;
	protected int maxRetries;
	protected EJBPMICollaboratorFactory pmiFactory;
	protected static J2EENameFactory j2eeNameFactory;
	protected OrbUtils orbUtils;
	protected boolean dumped;
	protected String ivName;
	public PoolManager poolManager;
	protected ContainerExtensionFactory containerExtFactory;
	protected Pool ivTimedObjectPool;
	protected boolean allowTimerAccessOutsideBean;
	protected boolean transactionalStatefulLifecycleMethods;
	protected boolean noMethodInterfaceMDBEnabled;
	private SfFailoverCache ivSfFailoverCache;
	private boolean ivSFSBFailoverEnabled;
	public final boolean ivEmbedded;
	private EJBRuntime ivEJBRuntime;

	public EJSContainer() {
		this(false);
	}

	public EJSContainer(boolean embedded) {
		this.initialized = false;
		this.lockManager = null;
		this.internalBeanMetaDataStore = new Hashtable();
		this.maxRetries = 10;
		this.pmiFactory = null;
		this.orbUtils = null;
		this.dumped = false;
		this.ivTimedObjectPool = null;
		this.allowTimerAccessOutsideBean = true;
		this.transactionalStatefulLifecycleMethods = true;
		this.noMethodInterfaceMDBEnabled = true;
		this.ivEJBRuntime = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> " + String.valueOf(embedded));
		}

		this.ivEmbedded = embedded;
	}

	public synchronized void initialize(ContainerConfig configData) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "initialize");
		}

		if (this.initialized) {
			throw new CSIException("already initialized");
		} else {
			this.containerExtFactory = configData.getContainerExtensionFactory();
			this.ivEJBRuntime = configData.getEJBRuntime();
			classLoader = configData.getClassLoader();
			if (classLoader == null) {
				classLoader = this.getClass().getClassLoader();
			}

			this.ivName = configData.getContainerName();
			this.persisterFactory = configData.getPersisterFactory();
			sessionKeyFactory = configData.getSessionKeyFactory();
			this.sessionHandleFactory = configData.getStatefulSessionHandleFactory();
			this.ivSecurityCollaborator = configData.getSecurityCollaborator();
			this.uowCtrl = configData.getUOWControl();
			this.userTransactionImpl = this.uowCtrl.getUserTransaction();
			this.ivUOWManager = UOWManagerFactory.getUOWManager();
			this.ivAfterActivationCollaborators = configData.getAfterActivationCollaborators();
			this.ivBeforeActivationCollaborators = configData.getBeforeActivationCollaborators();
			this.ivBeforeActivationAfterCompletionCollaborators = configData
					.getBeforeActivationAfterCompletionCollaborators();
			j2eeNameFactory = configData.getJ2EENameFactory();
			this.pmiFactory = configData.getPmiBeanFactory();
			this.ivObjectCopier = configData.getObjectCopier();
			this.orbUtils = configData.getOrbUtils();
			this.ivEntityHelper = configData.getEntityHelper();
			this.ivSFSBFailoverEnabled = configData.isEnabledSFSBFailover();
			this.ivSfFailoverCache = configData.getStatefulFailoverCache();
			this.passivator = configData.getStatefulPassivator();
			this.ivStatefulBeanEnqDeq = configData.getStatefulBeanEnqDeq();
			this.ivDispatchEventListenerManager = configData.getDispatchEventListenerManager();
			this.poolManager = configData.getPoolManager();
			this.activator = new Activator(this, configData.getEJBCache(), configData.getPassivationPolicy(),
					this.passivator, this.ivSfFailoverCache);
			homeOfHomes = new HomeOfHomes(this, this.activator);
			int uncached = 0;
			ActivationStrategy as = this.activator.getActivationStrategy(uncached);
			homeOfHomes.setActivationStrategy(as);
			this.wrapperManager = configData.getWrapperManager();
			this.ivUOWManager.registerRunUnderUOWCallback(new RunUnderUOWCallback());
			this.initialized = true;
			defaultContainer = this;
			Tr.registerDumpable(tc, this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "initialize");
			}

		}
	}

	public void terminate() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "terminate");
		}

		if (this.passivator != null) {
			this.passivator.terminate();
		}

		if (this.activator != null) {
			this.activator.terminate();
		}

		if (this.wrapperManager != null) {
			this.wrapperManager.destroy();
		}

		defaultContainer = null;
		homeOfHomes = null;
		this.activator = null;
		this.passivator = null;
		this.wrapperManager = null;
		this.poolManager.cancel();
		this.poolManager = null;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "terminate");
		}

	}

	public EJBRuntime getEJBRuntime() {
		return this.ivEJBRuntime;
	}

	public void setSecurityCollaborator(EJBSecurityCollaborator<?> securityCollaborator) {
		this.ivSecurityCollaborator = securityCollaborator;
	}

	public void setPMICollaboratorFactory(EJBPMICollaboratorFactory factory) {
		this.pmiFactory = factory;
	}

	public EJSDeployedSupport getEJSDeployedSupport(EJSWrapperBase wrapper) {
		return new EJSDeployedSupport();
	}

	public void putEJSDeployedSupport(EJSDeployedSupport s) {
		if (s.methodId < 0) {
			s.ivThreadData.getEJBMethodInfoStack().done(s.methodInfo);
		}

	}

	public WSEJBEndpointManager createWebServiceEndpointManager(J2EEName j2eeName, Class<?> provider, Method[] methods)
			throws EJBException, EJBConfigurationException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createWebServiceEndpointManager : " + j2eeName, new Object[]{provider, methods});
		}

		EJSHome home = (EJSHome) homeOfHomes.getHome(j2eeName);
		if (home == null) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createWebServiceEndpointManager could not find home for : " + j2eeName);
			}

			throw ExceptionUtil.EJBException("Unable to find EJB component: " + j2eeName, (Throwable) null);
		} else {
			BeanMetaData bmd = home.beanMetaData;
			Method[] endpointMethods = methods;
			synchronized (bmd) {
				if (!bmd.ivWebServiceEndpointCreated) {
					if (provider != null) {
						if (bmd.webserviceEndpointInterfaceClass != null) {
							Tr.error(tc, "WS_ENDPOINT_PROVIDER_CONFLICT_CNTR0176E",
									new Object[]{bmd.webserviceEndpointInterfaceClass.getName(),
											bmd.j2eeName.getComponent(), bmd.j2eeName.getModule(),
											bmd.j2eeName.getApplication()});
							throw new EJBConfigurationException(
									"Web Service Provider interface conflicts with the configured Web Service Endpoint interface "
											+ bmd.webserviceEndpointInterfaceClass.getName() + " for the "
											+ bmd.j2eeName.getComponent() + " bean in the " + bmd.j2eeName.getModule()
											+ " module of the " + bmd.j2eeName.getApplication() + " application.");
						}

						endpointMethods = provider.getMethods();
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "provider methods : ", endpointMethods);
						}
					}

					boolean hasAroundInvoke = WSEJBWrapper.resolveWebServiceEndpointMethods(bmd, endpointMethods);
					if (hasAroundInvoke) {
						try {
							bmd.ivWebServiceEndpointProxyClass = JITDeploy.generateWSEJBProxy(bmd.classLoader,
									bmd.ivWebServiceEndpointProxyName, provider, endpointMethods,
									bmd.wsEndpointMethodInfos, bmd.enterpriseBeanClassName, bmd.j2eeName.toString(),
									this.getEJBRuntime().getClassDefiner());
						} catch (ClassNotFoundException var12) {
							Tr.error(tc, "WS_EJBPROXY_FAILURE_CNTR0177E", new Object[]{bmd.j2eeName.getComponent(),
									bmd.j2eeName.getModule(), bmd.j2eeName.getApplication(), var12});
							throw ExceptionUtil.EJBException(
									"Failure occurred attempting to create a Web service endpoint proxy for the "
											+ bmd.j2eeName.getComponent() + " bean in the " + bmd.j2eeName.getModule()
											+ " module of the " + bmd.j2eeName.getApplication() + " application.",
									var12);
						}
					}

					bmd.ivWebServiceEndpointCreated = true;
					bmd.dump();
				}
			}

			WSEJBWrapper wrapper = new WSEJBWrapper();
			wrapper.container = this;
			wrapper.wrapperManager = this.wrapperManager;
			wrapper.ivCommon = null;
			wrapper.isManagedWrapper = false;
			wrapper.ivInterface = WrapperInterface.SERVICE_ENDPOINT;
			wrapper.beanId = home.ivStatelessId;
			wrapper.bmd = bmd;
			wrapper.methodInfos = bmd.wsEndpointMethodInfos;
			wrapper.methodNames = bmd.wsEndpointMethodNames;
			wrapper.isolationAttrs = null;
			wrapper.ivPmiBean = home.pmiBean;
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createWebServiceEndpointManager : " + wrapper);
			}

			return wrapper;
		}
	}

	public EJSHome getStartedHome(J2EEName beanName) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "getStartedHome : " + beanName);
		}

		HomeRecord hr = homeOfHomes.getHomeRecord(beanName);
		EJSHome hi = hr.getHomeAndInitialize();
		if (hi == null) {
			String msgTxt = "The " + beanName.getComponent() + " bean in the " + beanName.getModule()
					+ " module of the " + beanName.getApplication()
					+ " application has been stopped and may no longer be used."
					+ " Wait for the bean to be started, and then try again.";
			throw new EJBStoppedException(msgTxt);
		} else {
			return hi;
		}
	}

	public EJSHome getInstalledHome(J2EEName beanName) throws EJBNotFoundException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "getInstalledHome : " + beanName);
		}

		HomeRecord hr = homeOfHomes.getHomeRecord(beanName);
		if (hr != null) {
			return hr.getHomeAndInitialize();
		} else {
			Tr.warning(tc, "HOME_NOT_FOUND_CNTR0092W", beanName.toString());
			throw new EJBNotFoundException("Attempted to access bean " + beanName.getComponent() + " in module "
					+ beanName.getModule() + " of application " + beanName.getApplication()
					+ " that has not been started or does not exist.");
		}
	}

	EJSWrapperCommon getHomeWrapperCommon(J2EEName beanName) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getHomeWrapperCommon : " + beanName);
		}

		EJSHome hi = this.getStartedHome(beanName);

		EJSWrapperCommon result;
		try {
			result = hi.getWrapper();
		} catch (CSIException var6) {
			FFDCFilter.processException(var6, CLASS_NAME + ".getHomeWrapperCommon", "740", this);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "CSIException occurred", var6);
			}

			throw var6;
		} catch (RemoteException var7) {
			FFDCFilter.processException(var7, CLASS_NAME + ".getHomeWrapperCommon", "745", this);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Remote Exception occurred", var7);
			}

			throw new CSIException("failed to get home instance", var7);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getHomeWrapperCommon : " + result);
		}

		return result;
	}

	public void stopBean(BeanMetaData bmd) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "stopBean : " + bmd.j2eeName);
		}

		try {
			this.uninstallBean(bmd, false);
		} catch (Throwable var4) {
			FFDCFilter.processException(var4, CLASS_NAME + ".stopBean", "876", this);
			throw new CSIException("Stop on bean " + bmd.j2eeName + " failed", var4);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "stopBean");
		}

	}

	private void uninstallBean(BeanMetaData bmd, boolean terminate) throws ContainerException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		J2EEName beanHomeName = bmd.j2eeName;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "uninstallBean : " + beanHomeName);
		}

		if (!this.internalBeanMetaDataStore.containsKey(bmd.j2eeName)) {
			homeOfHomes.removeHome(bmd);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "uninstallBean");
			}

		} else {
			BeanMetaData ibmd = (BeanMetaData) this.internalBeanMetaDataStore.get(bmd.j2eeName);
			IllegalStateException isex;
			if (bmd != ibmd) {
				isex = new IllegalStateException("Mismatch in internal bean metadata : " + bmd.j2eeName);
				FFDCFilter.processException(isex, CLASS_NAME + ".uninstallBean", "1500", this, new Object[]{bmd, ibmd});
			}

			isex = null;

			try {
				EJSHome home = homeOfHomes.removeHome(bmd);
				if (home != null) {
					try {
						if (home.isMessageDrivenHome()) {
							((MDBInternalHome) home).deactivateEndpoint();
						}
					} catch (Throwable var17) {
						FFDCFilter.processException(var17, CLASS_NAME + ".uninstallBean", "988", this);
					}

					try {
						if (!terminate) {
							this.activator.uninstallBean(beanHomeName);
						}
					} catch (Throwable var16) {
						FFDCFilter.processException(var16, CLASS_NAME + ".uninstallBean", "1853", this);
					}

					home.destroy();

					try {
						this.wrapperManager.unregisterHome(beanHomeName, home);
					} catch (Throwable var15) {
						FFDCFilter.processException(var15, CLASS_NAME + ".uninstallBean", "999", this);
					}
				}
			} catch (Throwable var18) {
				FFDCFilter.processException(var18, CLASS_NAME + ".uninstallBean", "1430", this);
				ContainerEJBException ex = new ContainerEJBException("Failed to destroy the home.", var18);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var18, ex.toString()});
				throw ex;
			} finally {
				this.internalBeanMetaDataStore.remove(beanHomeName);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "uninstallBean");
				}

			}

		}
	}

	public EJSHome startBean(BeanMetaData bmd) throws ContainerException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "startBean: " + bmd.j2eeName);
		}

		J2EEName homeKey = bmd.j2eeName;
		EJSHome ejsHome = null;

		try {
			this.internalBeanMetaDataStore.put(homeKey, bmd);
			bmd.dump();
			ejsHome = homeOfHomes.create(bmd);
			ejsHome.initialize(this, new BeanId(homeOfHomes, homeKey, true), bmd);
			homeOfHomes.setActivationStrategy(ejsHome, bmd);
			ejsHome.completeInitialization();
			if (bmd.persister != null) {
				bmd.persister.setHome(ejsHome);
			}
		} catch (Throwable var8) {
			FFDCFilter.processException(var8, CLASS_NAME + ".startBean", "1126", this);
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Caught exception", var8);
			}

			if (ejsHome != null) {
				try {
					ejsHome.destroy();
				} catch (Throwable var7) {
					FFDCFilter.processException(var7, CLASS_NAME + ".startBean", "1831", this);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Caught exception destroying home", var7);
					}
				}
			}

			String msgTxt = "Failed to start " + homeKey;
			throw new ContainerException(msgTxt, var8);
		}

		ejsHome.homeRecord.homeInternal = ejsHome;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "startBean");
		}

		return ejsHome;
	}

	public HomeOfHomes getHomeOfHomes() {
		return homeOfHomes;
	}

	protected J2EENameFactory getJ2EENameFactory() {
		return j2eeNameFactory;
	}

	public final LockManager getLockManager() {
		return this.lockManager;
	}

	public WrapperManager getWrapperManager() {
		return this.wrapperManager;
	}

	public Activator getActivator() {
		return this.activator;
	}

	public final boolean isStatelessSessionBean(BeanId id) {
		boolean result = id.getHome().isStatelessSessionHome();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isStatelessSessionBean : " + result + ", " + id);
		}

		return result;
	}

	public final boolean isStatefulSessionBean(BeanId id) {
		boolean result = id.getHome().isStatefulSessionHome();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isStatefulSessionBean : " + result + ", " + id);
		}

		return result;
	}

	public void setCustomFinderAccessIntentThreadState(boolean cfwithupdateaccess, boolean readonly,
			String methodname) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "setCustomFinderAccessIntentThreadState");
		}

		CMP11CustomFinderAccIntentState _state = new CMP11CustomFinderAccIntentState(methodname, cfwithupdateaccess,
				readonly);
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "current thread CMP11 Finder state" + _state);
		}

		((EJBThreadData) svThreadData.get()).ivCMP11CustomFinderAccIntentState = _state;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "setCustomFinderAccessIntentThreadState");
		}

	}

	public CMP11CustomFinderAccIntentState getCustomFinderAccessIntentThreadState() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		CMP11CustomFinderAccIntentState state = null;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getCustomFinderAccessIntentThreadState");
		}

		state = ((EJBThreadData) svThreadData.get()).ivCMP11CustomFinderAccIntentState;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getCustomFinderAccessIntentThreadState");
		}

		return state;
	}

	public void resetCustomFinderAccessIntentContext() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "resetCustomFinderAccessIntentContext");
		}

		((EJBThreadData) svThreadData.get()).ivCMP11CustomFinderAccIntentState = null;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "resetCustomFinderAccessIntentContext");
		}

	}

	public void containerTxCompleted(ContainerTx containerTx) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "containerTxCompleted (" + ContainerTx.uowIdToString(containerTx.ivTxKey) + ")");
		}

		if (this.lockManager != null) {
			this.lockManager.unlock(containerTx);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "containerTxCompleted");
		}

	}

	public void containerASCompleted(Object asKey) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "containerASCompleted : " + asKey);
		}

		containerASMap.remove(asKey);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "containerASCompleted");
		}

	}

	public ContainerTx getCurrentContainerTx() {
		ContainerTx result = null;
		SynchronizationRegistryUOWScope currTxKey = null;

		try {
			currTxKey = this.uowCtrl.getCurrentTransactionalUOW(false);
		} catch (CSITransactionRolledbackException var4) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getCurrentContainerTx: " + var4);
			}
		}

		if (currTxKey != null) {
			result = (ContainerTx) currTxKey.getResource(containerTxResourceKey);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getCurrentContainerTx() : " + result);
		}

		return result;
	}

	public ContainerTx getActiveContainerTx() throws CSITransactionRolledbackException {
		ContainerTx result = null;
		SynchronizationRegistryUOWScope currTxKey = this.uowCtrl.getCurrentTransactionalUOW(true);
		if (currTxKey != null) {
			result = (ContainerTx) currTxKey.getResource(containerTxResourceKey);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getActiveContainerTx() : " + result);
		}

		return result;
	}

	@Deprecated
	public ContainerTx getCurrentTx() throws CSITransactionRolledbackException {
		return this.getCurrentTx(true);
	}

	@Deprecated
	public ContainerTx getCurrentTx(boolean checkMarkedRollback) throws CSITransactionRolledbackException {
		ContainerTx result = null;
		SynchronizationRegistryUOWScope currTxKey = this.uowCtrl.getCurrentTransactionalUOW(checkMarkedRollback);
		if (currTxKey != null) {
			result = (ContainerTx) currTxKey.getResource(containerTxResourceKey);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getCurrentTx() : " + result);
		}

		return result;
	}

	public ContainerTx getCurrentTx(SynchronizationRegistryUOWScope uowId, boolean isLocal)
			throws CSITransactionRolledbackException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc,
					"getCurrentTx (" + ContainerTx.uowIdToString(uowId) + ", " + (isLocal ? "local" : "global") + ")");
		}

		ContainerTx result = null;
		SynchronizationRegistryUOWScope currTxKey = uowId;
		if (uowId != null) {
			result = (ContainerTx) uowId.getResource(containerTxResourceKey);
			if (result == null) {
				result = this.ivEJBRuntime.createContainerTx(this, !isLocal, uowId, this.uowCtrl);

				try {
					this.uowCtrl.enlistWithTransaction(currTxKey, result);
				} catch (CSIException var7) {
					FFDCFilter.processException(var7, CLASS_NAME + ".getCurrentTx", "1305", this);
					this.uowCtrl.setRollbackOnly();
					throw new CSITransactionRolledbackException("Enlistment with transaction failed", var7);
				}

				uowId.putResource(containerTxResourceKey, result);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getCurrentTx : " + result);
		}

		return result;
	}

	public ContainerAS getCurrentSessionalUOW(boolean checkMarkedReset)
			throws CSIException, CSITransactionRolledbackException {
		ContainerAS result = null;
		Object currASKey = this.uowCtrl.getCurrentSessionalUOW(checkMarkedReset);
		if (currASKey == null) {
			return null;
		} else {
			result = (ContainerAS) containerASMap.get(currASKey);
			if (result == null) {
				result = new ContainerAS(this, currASKey);
				this.uowCtrl.enlistWithSession(result);
				containerASMap.put(currASKey, result);
			}

			return result;
		}
	}

	public static EJBThreadData getUserTransactionThreadData() {
		EJBThreadData threadData = getThreadData();
		BeanO beanO = threadData.getCallbackBeanO();
		if (beanO == null) {
			EJBException ex = new EJBException("EJB UserTransaction can only be used from an EJB");
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getUserTransactionThreadData: " + ex);
			}

			throw ex;
		} else {
			try {
				beanO.getUserTransaction();
				return threadData;
			} catch (IllegalStateException var4) {
				EJBException ex2 = new EJBException("EJB UserTransaction cannot be used: " + var4, var4);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getUserTransactionThreadData: " + beanO + ": " + ex2);
				}

				throw ex2;
			}
		}
	}

	public void processTxContextChange(EJBThreadData threadData, boolean isLocal) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "processTxContextChange (" + isLocal + ")");
		}

		SynchronizationRegistryUOWScope uowId = this.uowCtrl.getCurrentTransactionalUOW(true);
		ContainerTx tx = this.getCurrentTx(uowId, isLocal);
		EJSDeployedSupport s = threadData.getMethodContext();
		if (s != null && !threadData.isLifeCycleMethodTransactionActive()) {
			s.currentTx = tx;
			s.uowCookie.setTransactionalUOW(uowId);
			if (s.ivRunUnderUOW > 0) {
				s.resetCurrentTx = true;
			}

			if (!isLocal) {
				EJBMethodInfoImpl methodInfo = s.methodInfo;
				String taskName = methodInfo.getBeanClassName() + "." + methodInfo.getMethodName();
				this.ivUOWManager.putResource("com.ibm.websphere.profile", taskName);
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "Set JPA task name: " + taskName);
				}
			}
		}

		if (isTraceOn && TETxLifeCycleInfo.isTraceEnabled()) {
			String idStr;
			if (isLocal) {
				if (uowId != null) {
					idStr = "" + System.identityHashCode(uowId);
					TETxLifeCycleInfo.traceLocalTxBegin(idStr, "Local Tx Begin");
				}
			} else {
				idStr = uowId.toString();
				int idx;
				idStr = idStr != null
						? ((idx = idStr.indexOf("(")) != -1
								? idStr.substring(idx + 1, idStr.indexOf(")"))
								: ((idx = idStr.indexOf("tid=")) != -1 ? idStr.substring(idx + 4) : idStr))
						: "NoTx";
				TETxLifeCycleInfo.traceUserTxBegin(idStr, "User Tx Begin");
			}
		}

		if (tx != null) {
			BeanO beanO = threadData.getCallbackBeanO();
			UserTransactionEnabledContext utxBeanO = (UserTransactionEnabledContext) beanO;
			if (utxBeanO.getModuleVersion() == 11) {
				tx.setIsolationLevel(utxBeanO.getIsolationLevel());
			}

			if (utxBeanO.enlist(tx)) {
				this.activator.enlistBean(tx, beanO);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "processTxContextChange");
		}

	}

	boolean transitionToStickyGlobalTran(BeanId beanId, ContainerTx currentTx, ContainerTx expectedTx) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "transitionToStickyGlobalTran (" + beanId + "," + currentTx + ", " + expectedTx + ")");
		}

		ContainerTx resumedTx = null;
		EJSDeployedSupport s = getMethodContext();
		EJBMethodInfoImpl methodInfo = s.methodInfo;
		BeanMetaData bmd = beanId.getBeanMetaData();

		try {
			currentTx.postInvoke(s);
			this.uowCtrl.postInvoke(beanId, s.uowCookie, s.exType, methodInfo);
			s.uowCtrlPreInvoked = false;
			s.currentTx = null;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "transitionToStickyGlobalTran : local tx completed");
			}

			s.uowCookie = this.uowCtrl.preInvoke(beanId, methodInfo);
			s.uowCtrlPreInvoked = true;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "transitionToStickyGlobalTran : sticky global resumed");
			}

			boolean isLocal = s.uowCookie.isLocalTx();
			SynchronizationRegistryUOWScope UOWid = s.uowCookie.getTransactionalUOW();
			resumedTx = this.getCurrentTx(UOWid, isLocal);
			s.currentTx = resumedTx;
			resumedTx.preInvoke(s);
			int isolationLevel = methodInfo.isolationAttr;
			if (bmd.ivModuleVersion <= 11 || bmd.ivModuleVersion >= 20 && bmd.cmpVersion == 1) {
				resumedTx.setIsolationLevel(isolationLevel);
			}

			s.currentIsolationLevel = isolationLevel;
		} catch (RemoteException var12) {
			FFDCFilter.processException(var12, CLASS_NAME + ".getBean", "1542", this);
			throw ExceptionUtil.EJBException("A failure occured resuming a bean managed transaction", var12);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "transitionToStickyGlobalTran : " + (resumedTx == expectedTx));
		}

		return resumedTx == expectedTx;
	}

	public static int getIsolationLevel(SynchronizationRegistryUOWScope txKey) {
		ContainerTx ctx = (ContainerTx) txKey.getResource(containerTxResourceKey);
		if (ctx == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "ContainerTx is null, returning default");
			}

			return 4;
		} else {
			int isolationLevel = ctx.getIsolationLevel();
			if (isolationLevel == 0) {
				isolationLevel = 4;
			}

			return isolationLevel;
		}
	}

	public static int getIsolationLevel(SynchronizationRegistryUOWScope txKey, int preferredIsolationLevel) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getIsolationLevel: " + txKey);
		}

		ContainerTx ctx = (ContainerTx) txKey.getResource(containerTxResourceKey);
		int isolationLevel;
		if (ctx == null) {
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "ContainerTx is null, determining from PortabilityLayer");
			}

			isolationLevel = preferredIsolationLevel;
		} else {
			isolationLevel = ctx.getIsolationLevel();
			if (isolationLevel == 0) {
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "Determining from PortabilityLayer");
				}

				isolationLevel = preferredIsolationLevel;

				try {
					ctx.setIsolationLevel(isolationLevel);
				} catch (IsolationLevelChangeException var6) {
					FFDCFilter.processException(var6, CLASS_NAME + ".getIsolationLevel", "1433");
					Tr.error(tc, "IGNORING_UNEXPECTED_EXCEPTION_CNTR0033E", var6);
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getIsolationLevel: " + MethodAttribUtils.getIsolationLevelString(isolationLevel));
		}

		return isolationLevel;
	}

	public int getIsolationLevel(int preferred) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getIsolationLevel: " + preferred);
		}

		ContainerTx ctx = null;

		try {
			ctx = this.getCurrentTx(false);
		} catch (CSITransactionRolledbackException var7) {
			FFDCFilter.processException(var7, CLASS_NAME + ".getIsolationLevel", "1614");
			Tr.error(tc, "IGNORING_UNEXPECTED_EXCEPTION_CNTR0033E", var7);
		}

		int isolationLevel;
		if (ctx == null) {
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "ContainerTx is null, returning specified default");
			}

			isolationLevel = preferred;
		} else {
			isolationLevel = ctx.getIsolationLevel();
			if (isolationLevel == 0) {
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "Using specified default");
				}

				isolationLevel = preferred;

				try {
					ctx.setIsolationLevel(isolationLevel);
				} catch (IsolationLevelChangeException var6) {
					FFDCFilter.processException(var6, CLASS_NAME + ".getIsolationLevel", "1645");
					Tr.error(tc, "IGNORING_UNEXPECTED_EXCEPTION_CNTR0033E", var6);
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getIsolationLevel: " + MethodAttribUtils.getIsolationLevelString(isolationLevel));
		}

		return isolationLevel;
	}

	public BeanO addBean(BeanO beanO, ContainerTx containerTx) throws DuplicateKeyException, RemoteException {
		return this.activator.addBean(containerTx, beanO);
	}

	public boolean lockBean(BeanO beanO, ContainerTx containerTx) throws RemoteException {
		return this.activator.lockBean(containerTx, beanO.beanId);
	}

	public EJBObject getBean(ContainerTx tx, BeanId id) throws RemoteException {
		EJBObject result = null;
		BeanO beanO = this.activator.getBean(tx, id);
		if (beanO != null) {
			try {
				result = this.wrapperManager.getWrapper(id).getRemoteWrapper();
			} catch (IllegalStateException var6) {
				FFDCFilter.processException(var6, CLASS_NAME + ".getBean", "1542", this);
			}
		}

		return result;
	}

	public void removeBean(EJSWrapperBase w) throws RemoteException, RemoveException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (w.bmd.ivCacheReloadType != 0) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "RemoveException: Read only EJB may not be removed.");
			}

			throw new RemoveException("Read only EJB may not be removed.");
		} else {
			int methodId = -6;
			if (w.ivInterface == WrapperInterface.LOCAL || w.ivInterface == WrapperInterface.REMOTE) {
				methodId = w.methodInfos.length - 1;
			}

			EJSDeployedSupport s = new EJSDeployedSupport();
			boolean isStateless = this.isStatelessSessionBean(w.beanId);

			try {
				RemoveException rex;
				try {
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.entry(tc, "removeBean(wrapperBase) : " + w.beanId);
					}

					this.EjbPreInvoke(w, methodId, s, new Object[0]);
					if (methodId == -6) {
						s.currentTx.ivRemoveBeanO = s.beanO;
					} else {
						s.beanO.remove();
					}

					if (!isStateless && s.unpinOnPostInvoke) {
						boolean removed = this.wrapperManager.unregister(w.beanId, true);
						if (removed) {
							s.unpinOnPostInvoke = false;
						}
					}
				} catch (UnknownException var80) {
					FFDCFilter.processException(var80, CLASS_NAME + ".removeBean", "1589", this);
					if ((isStateless || this.isStatefulSessionBean(w.beanId))
							&& var80.originalEx instanceof BeanNotReentrantException) {
						rex = new RemoveException(var80.originalEx.toString());
						s.setCheckedException(rex);
						throw rex;
					}

					s.setUncheckedException(var80);
				} catch (EJBException var81) {
					FFDCFilter.processException(var81, CLASS_NAME + ".removeBean", "2077", this);
					if ((isStateless || this.isStatefulSessionBean(w.beanId))
							&& var81.getCausedByException() instanceof BeanNotReentrantException) {
						rex = new RemoveException(var81.getCausedByException().toString());
						s.setCheckedException(rex);
						throw rex;
					}

					s.setUncheckedException(var81);
				} catch (RemoveException var82) {
					FFDCFilter.processException(var82, CLASS_NAME + ".removeBean", "1605", this);
					s.setCheckedException(var82);
					throw var82;
				} catch (RemoteException var83) {
					FFDCFilter.processException(var83, CLASS_NAME + ".removeBean", "1609", this);
					s.setUncheckedException(var83);
					throw var83;
				} catch (Throwable var84) {
					FFDCFilter.processException(var84, CLASS_NAME + ".removeBean", "1612", this);
					s.setUncheckedException(var84);
				}
			} finally {
				try {
					this.postInvoke(w, methodId, s);
				} finally {
					this.putEJSDeployedSupport(s);
				}

				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "removeBean(wrapperBase)");
				}

			}

		}
	}

	public void removeBean(BeanO beanO) throws CSITransactionRolledbackException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "removeBean with BeanO");
		}

		BeanId id = beanO.getId();
		if (id != null) {
			try {
				ContainerTx currentTx = this.getCurrentTx(false);
				if (currentTx.delist(beanO)) {
					this.activator.removeBean(currentTx, beanO);
				} else if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "BeanO not enlisted - not removed from tx or cache");
				}
			} catch (Throwable var5) {
				FFDCFilter.processException(var5, CLASS_NAME + ".removeBean(BeanO)", "1949", this);
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "Exception thrown in removeBean()", new Object[]{beanO, var5});
				}
			}
		} else if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "BeanId is null");
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "removeBean");
		}

	}

	public boolean removeStatefulBean(Object bean) throws RemoteException, RemoveException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "removeStatefulBean : " + Util.identity(bean));
		}

		EJSWrapperBase wrapper = null;
		if (bean instanceof EJSWrapperBase) {
			wrapper = (EJSWrapperBase) bean;
		} else {
			if (!(bean instanceof LocalBeanWrapper)) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "removeStatefulBean : RemoveException:" + Util.identity(bean));
				}

				throw new RemoveException(
						"Object to remove is not an enterprise bean reference : " + Util.identity(bean));
			}

			wrapper = EJSWrapperCommon.getLocalBeanWrapperBase((LocalBeanWrapper) bean);
		}

		if (!this.isStatefulSessionBean(wrapper.beanId)) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "removeStatefulBean : RemoveException:not stateful : " + wrapper.beanId);
			}

			throw new RemoveException("Object to remove is not a stateful bean reference : " + wrapper.beanId);
		} else {
			try {
				this.removeBean(wrapper);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "removeStatefulBean : true");
				}

				return true;
			} catch (NoSuchEJBException var6) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "removeStatefulBean : false (NoSuchEJBException)");
				}

				return false;
			} catch (NoSuchObjectLocalException var7) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "removeStatefulBean : false (NoSuchObjectLocalException)");
				}

				return false;
			} catch (OBJECT_NOT_EXIST var8) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "removeStatefulBean : false (OBJECT_NOT_EXIST)");
				}

				return false;
			} catch (EJBException var9) {
				if (var9.getCause() instanceof RemoveException) {
					RemoveException rex = (RemoveException) var9.getCause();
					throw rex;
				} else {
					throw var9;
				}
			}
		}
	}

	public static Object resolveWrapperProxy(BusinessLocalWrapperProxy proxy) {
		WrapperProxyState state = proxy.ivState;
		Object wrapper = state.ivWrapper;
		if (wrapper == null) {
			do {
				state = state.reconnect();
				wrapper = state.ivWrapper;
			} while (wrapper == null);

			proxy.ivState = state;
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "resolveWrapperProxy: " + state);
		}

		return wrapper;
	}

	public static Object resolveWrapperProxy(EJSLocalWrapperProxy proxy) {
		WrapperProxyState state = proxy.ivState;
		Object wrapper = state.ivWrapper;
		if (wrapper == null) {
			do {
				state = state.reconnect();
				wrapper = state.ivWrapper;
			} while (wrapper == null);

			proxy.ivState = state;
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "resolveWrapperProxy: " + state);
		}

		return wrapper;
	}

	private EJBMethodInfoImpl mapMethodInfo(EJSDeployedSupport s, EJSWrapperBase wrapper, int methodId,
			String methodSignature) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "mapMethodInfo(" + methodId + "," + methodSignature + ")");
		}

		EJBMethodInfoImpl rtnInfo = null;
		s.methodId = methodId;
		s.ivWrapper = wrapper;
		if (methodId < 0) {
			if (methodId == -6) {
				rtnInfo = s.ivThreadData.getEJBMethodInfoStack().get("$remove:", (String) null, wrapper,
						wrapper.ivInterface == WrapperInterface.BUSINESS_LOCAL
								? MethodInterface.LOCAL
								: MethodInterface.REMOTE,
						wrapper.bmd.usesBeanManagedTx
								? TransactionAttribute.TX_BEAN_MANAGED
								: TransactionAttribute.TX_NOT_SUPPORTED);
				rtnInfo.setClassLoader = true;
			} else {
				rtnInfo = this.ivEntityHelper.getPMMethodInfo(s, wrapper, methodId, methodSignature);
			}
		} else {
			if (wrapper.methodInfos == null) {
				throw new IllegalStateException(
						"An attempt was made to invoke a method on a bean interface that is not defined.");
			}

			rtnInfo = wrapper.methodInfos[methodId];
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "mapMethodInfo");
		}

		return rtnInfo;
	}

	public EnterpriseBean preInvoke(EJSWrapper wrapper, int methodId, EJSDeployedSupport s) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "old preinvoke called by EJBDeploy, not new JACC preinvoke");
		}

		Object[] args = null;
		return this.preInvoke(wrapper, methodId, s, (Object[]) args);
	}

	public EnterpriseBean preInvoke(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "old preinvoke called by EJBDeploy, not new JACC preinvoke");
		}

		Object[] args = null;
		return this.preInvoke(wrapper, methodId, s, (Object[]) args);
	}

	public final boolean doesJaccNeedsEJBArguments(EJSWrapperBase wrapper) {
		EJBSecurityCollaborator<?> securityCollaborator = this.ivSecurityCollaborator;
		boolean result = securityCollaborator != null && securityCollaborator.areRequestMethodArgumentsRequired();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "doesJaccNeedsEJBArguments returning " + result);
		}

		return result;
	}

	public EnterpriseBean preInvoke(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s, Object[] args)
			throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		EJBMethodInfoImpl methodInfo = this.mapMethodInfo(s, wrapper, methodId, (String) null);

		try {
			if (isTraceOn) {
				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeBegins(s, wrapper);
				}

				if (tc.isEntryEnabled()) {
					Tr.entry(tc, "EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")");
				}

				if (tcClntInfo.isDebugEnabled()) {
					Tr.debug(tcClntInfo, "preInvoke(" + methodInfo.getMethodName() + ")");
				}
			}

			Object bean = null;
			if (methodInfo.isStatelessSessionBean && methodInfo.isHomeCreate) {
				bean = this.preInvokeForStatelessSessionCreate(wrapper, methodId, s, methodInfo, args);
			} else {
				bean = this.preInvokeActivate(wrapper, methodId, s, methodInfo);
				this.preInvokeAfterActivate(wrapper, bean, s, args);
			}

			if (isTraceOn) {
				if (tc.isEntryEnabled()) {
					ContainerTx containerTx = s.currentTx;
					Tr.exit(tc,
							"EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ") " + " Invoking method '"
									+ methodInfo.getMethodName() + "' on bean '" + wrapper.getClass().getName() + "("
									+ wrapper.beanId + ")" + "', '" + containerTx + "', isGlobalTx="
									+ (containerTx != null
											? (containerTx.isTransactionGlobal() ? "true" : "false")
											: "Unknown"));
				}

				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeEnds(s, wrapper);
				}
			}

			return (EnterpriseBean) bean;
		} catch (Throwable var9) {
			this.preinvokeHandleException(var9, wrapper, methodId, s, methodInfo);
			return null;
		}
	}

	public Object EjbPreInvoke(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s, Object[] args)
			throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		EJBMethodInfoImpl methodInfo = this.mapMethodInfo(s, wrapper, methodId, (String) null);

		try {
			if (isTraceOn) {
				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeBegins(s, wrapper);
				}

				if (tc.isEntryEnabled()) {
					Tr.entry(tc, "EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")");
				}

				if (tcClntInfo.isDebugEnabled()) {
					Tr.debug(tcClntInfo, "preInvoke(" + methodInfo.getMethodName() + ")");
				}
			}

			Object bean = this.preInvokeActivate(wrapper, methodId, s, methodInfo);
			this.preInvokeAfterActivate(wrapper, bean, s, args);
			if (isTraceOn) {
				if (tc.isEntryEnabled()) {
					ContainerTx containerTx = s.currentTx;
					if (methodInfo.isAsynchMethod()) {
						Tr.exit(tc,
								"EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ") "
										+ " Invoking asynch method '" + methodInfo.getMethodName() + "' on bean '"
										+ wrapper.getClass().getName() + "(" + wrapper.beanId + ")" + "', '"
										+ containerTx + "', isGlobalTx="
										+ (containerTx != null
												? (containerTx.isTransactionGlobal() ? "true" : "false")
												: "Unknown"));
					} else {
						Tr.exit(tc,
								"EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ") "
										+ " Invoking method '" + methodInfo.getMethodName() + "' on bean '"
										+ wrapper.getClass().getName() + "(" + wrapper.beanId + ")" + "', '"
										+ containerTx + "', isGlobalTx="
										+ (containerTx != null
												? (containerTx.isTransactionGlobal() ? "true" : "false")
												: "Unknown"));
					}
				}

				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeEnds(s, wrapper);
				}
			}

			return bean;
		} catch (Throwable var9) {
			this.preinvokeHandleException(var9, wrapper, methodId, s, methodInfo);
			return null;
		}
	}

	private EnterpriseBean preInvokePmInternal(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s,
			EJBMethodInfoImpl methodInfo) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();

		try {
			if (isTraceOn) {
				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeBegins(s, wrapper);
				}

				if (tc.isEntryEnabled()) {
					Tr.entry(tc, "EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")");
				}
			}

			Object bean = null;
			if (methodInfo.isStatelessSessionBean && methodInfo.isHomeCreate) {
				bean = this.preInvokeForStatelessSessionCreate(wrapper, methodId, s, methodInfo, (Object[]) null);
			} else {
				bean = this.preInvokeActivate(wrapper, methodId, s, methodInfo);
				this.preInvokeAfterActivate(wrapper, bean, s, (Object[]) null);
			}

			if (isTraceOn) {
				if (tc.isEntryEnabled()) {
					ContainerTx containerTx = s.currentTx;
					Tr.exit(tc,
							"EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ") " + " Invoking method '"
									+ methodInfo.getMethodName() + "' on bean '" + wrapper.getClass().getName() + "("
									+ wrapper.beanId + ")" + "', '" + containerTx + "', isGlobalTx="
									+ (containerTx != null
											? (containerTx.isTransactionGlobal() ? "true" : "false")
											: "Unknown"));
				}

				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeEnds(s, wrapper);
				}
			}

			return (EnterpriseBean) bean;
		} catch (Throwable var8) {
			this.preinvokeHandleException(var8, wrapper, methodId, s, methodInfo);
			return null;
		}
	}

	public Object preInvokeMdbActivate(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s) throws Exception {
		EJBMethodInfoImpl methodInfo = this.mapMethodInfo(s, wrapper, methodId, (String) null);
		if (TraceComponent.isAnyTracingEnabled()) {
			if (TEEJBInvocationInfo.isTraceEnabled()) {
				TEEJBInvocationInfo.tracePreInvokeBegins(s, wrapper);
			}

			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")");
			}
		}

		Object bean = this.preInvokeActivate(wrapper, methodId, s, methodInfo);
		return bean;
	}

	public void preInvokeMdbAfterActivate(EJSWrapperBase wrapper, EJSDeployedSupport s, Object eb, Object[] args)
			throws RemoteException {
		this.preInvokeAfterActivate(wrapper, eb, s, args);
		if (TraceComponent.isAnyTracingEnabled()) {
			if (tc.isEntryEnabled()) {
				int methodId = s.methodId;
				EJBMethodInfoImpl methodInfo = s.methodInfo;
				ContainerTx containerTx = s.currentTx;
				Tr.exit(tc, "EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ") " + " Invoking method '"
						+ methodInfo.getMethodName() + "' on bean '" + wrapper.getClass().getName() + "("
						+ wrapper.beanId + ")" + "', '" + containerTx + "', isGlobalTx="
						+ (containerTx != null ? (containerTx.isTransactionGlobal() ? "true" : "false") : "Unknown"));
			}

			if (TEEJBInvocationInfo.isTraceEnabled()) {
				TEEJBInvocationInfo.tracePreInvokeEnds(s, wrapper);
			}
		}

	}

	public void preinvokeHandleException(Throwable t, EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s,
			EJBMethodInfoImpl methodInfo) throws RemoteException {
		s.preInvokeException = true;
		if (TraceComponent.isAnyTracingEnabled()) {
			if (tc.isEntryEnabled()) {
				ContainerTx containerTx = s.currentTx;
				Tr.exit(tc, "EJBpreInvoke(" + methodId + ":" + methodInfo.getMethodName() + ") " + " Invoking method '"
						+ methodInfo.getMethodName() + "' on bean '" + wrapper.getClass().getName() + "("
						+ wrapper.beanId + ")" + "', '" + containerTx + "', isGlobalTx="
						+ (containerTx != null ? (containerTx.isTransactionGlobal() ? "true" : "false") : "Unknown"));
			}

			if (TEEJBInvocationInfo.isTraceEnabled()) {
				TEEJBInvocationInfo.tracePreInvokeException(s, wrapper, t);
			}
		}

		s.setUncheckedException(t);
	}

	public EnterpriseBean preInvoke(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s,
			EJBMethodInfoImpl methodInfo) throws RemoteException {
		s.methodId = methodId;
		s.ivWrapper = wrapper;
		return this.preInvokePmInternal(wrapper, methodId, s, methodInfo);
	}

	public EnterpriseBean preInvoke(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s, String methodSignature)
			throws RemoteException {
		EJBMethodInfoImpl methodInfo = this.mapMethodInfo(s, wrapper, methodId, methodSignature);
		return this.preInvokePmInternal(wrapper, methodId, s, methodInfo);
	}

	private Object preInvokeActivate(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s,
			EJBMethodInfoImpl methodInfo) throws Exception {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		EJBThreadData threadData = s.ivThreadData;
		ContainerTx containerTx = null;
		s.isLightweight = methodInfo.isLightweight;
		s.methodInfo = methodInfo;
		s.ivCallerContext = threadData.pushMethodContext(s);
		DispatchEventListenerCookie[] dispatchEventListenerCookies = null;
		if (isZOS) {
			if (isZOSCRA) {
				throw new EJBException("EJB access not permitted in Adjunct process");
			}

			if (this.ivDispatchEventListenerManager != null
					&& this.ivDispatchEventListenerManager.dispatchEventListenersAreActive()) {
				dispatchEventListenerCookies = this.ivDispatchEventListenerManager
						.getNewDispatchEventListenerCookieArray();
				s.ivDispatchEventListenerCookies = dispatchEventListenerCookies;
			}
		}

		s.unpinOnPostInvoke = wrapper.isManagedWrapper ? this.wrapperManager.preInvoke(wrapper) : false;
		int isolationLevel = methodInfo.isolationAttr;
		EJBPMICollaborator pmiBean = wrapper.ivPmiBean;
		if (pmiBean != null) {
			s.pmiCookie = pmiBean.methodPreInvoke(wrapper.beanId, methodInfo);
			s.pmiPreInvoked = true;
		}

		BeanMetaData bmd = wrapper.bmd;
		threadData.ivComponentMetaDataContext.beginContext(bmd);
		Object cookie;
		if (!s.isLightweight) {
			if (methodInfo.setClassLoader) {
				s.oldClassLoader = EJBThreadData.svThreadContextAccessor
						.pushContextClassLoaderForUnprivileged(bmd.ivContextClassLoader);
			}

			int i;
			if (this.ivBeforeActivationCollaborators != null) {
				for (i = 0; i < this.ivBeforeActivationCollaborators.length; ++i) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc,
								"preInvokeActivate : Invoking EJBComponentInitializationCollaborator.preInvoke method on: "
										+ this.ivBeforeActivationCollaborators[i].getClass().getName());
					}

					cookie = this.ivBeforeActivationCollaborators[i].preInvoke(s);
					if (cookie != null) {
						if (s.ivBeforeActivationCookies == null) {
							s.ivBeforeActivationCookies = new Object[this.ivBeforeActivationCollaborators.length];
						}

						s.ivBeforeActivationCookies[i] = cookie;
					}

					++s.ivBeforeActivationPreInvoked;
				}
			}

			if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
				i = this.ivBeforeActivationAfterCompletionCollaborators.length;

				for (int i = 0; i < i; ++i) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc,
								"preInvokeActivate : Invoking BeforeActivationAfterCompletionCollaborator.preInvoke method on: "
										+ this.ivBeforeActivationAfterCompletionCollaborators[i].getClass().getName());
					}

					Object cookie = this.ivBeforeActivationAfterCompletionCollaborators[i].preInvoke(s);
					if (cookie != null) {
						if (s.ivBeforeActivationAfterCompletionCookies == null) {
							s.ivBeforeActivationAfterCompletionCookies = new Object[this.ivBeforeActivationAfterCompletionCollaborators.length];
						}

						s.ivBeforeActivationAfterCompletionCookies[i] = cookie;
					}

					++s.ivBeforeActivationAfterCompletionPreInvoked;
				}
			}
		}

		if (methodInfo.isLightweightTxCapable) {
			if (s.isLightweight) {
				EJSDeployedSupport sCaller = s.ivCallerContext;
				if (sCaller != null && sCaller.ivRunUnderUOW == 0) {
					ContainerTx currentTx = sCaller.currentTx;
					if (currentTx != null && currentTx.isActiveGlobal()) {
						containerTx = currentTx;
						s.currentTx = currentTx;
						currentTx.preInvoke(s);
					}
				}
			} else {
				SynchronizationRegistryUOWScope uow = this.uowCtrl.getCurrentTransactionalUOW(false);
				if (uow != null) {
					boolean isLocal = uow.getUOWType() != 1;
					if (isLocal || bmd.type != 4) {
						this.uowCtrl.completeTxTimeout();
						containerTx = this.getCurrentTx(uow, isLocal);
						s.currentTx = containerTx;
						containerTx.preInvoke(s);
					}
				}
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Lightweight: Tx = " + containerTx);
			}
		}

		if (containerTx == null) {
			s.uowCookie = this.uowCtrl.preInvoke(wrapper.beanId, methodInfo);
			s.uowCtrlPreInvoked = true;
			boolean isLocal = s.uowCookie.isLocalTx();
			SynchronizationRegistryUOWScope UOWid = s.uowCookie.getTransactionalUOW();
			containerTx = this.getCurrentTx(UOWid, isLocal);
			if (containerTx != null) {
				s.currentTx = containerTx;
				containerTx.preInvoke(s);
				if (bmd.ivModuleVersion <= 11 || bmd.ivModuleVersion >= 20 && bmd.cmpVersion == 1) {
					containerTx.setIsolationLevel(isolationLevel);
				}

				s.currentIsolationLevel = isolationLevel;
			}
		}

		if (isZOS && dispatchEventListenerCookies != null) {
			this.ivDispatchEventListenerManager.callDispatchEventListeners(1, dispatchEventListenerCookies, methodInfo);
		}

		BeanO beanO = this.activator.preInvokeActivateBean(threadData, containerTx, wrapper.beanId);
		s.ivPopCallbackBeanORequired = beanO.home != null;
		s.beanO = beanO;
		cookie = beanO.preInvoke(s, containerTx);
		return cookie;
	}

	private void preInvokeAfterActivate(EJSWrapperBase wrapper, Object bean, EJSDeployedSupport s, Object[] args)
			throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		s.ivEJBMethodArguments = args;
		if (!s.isLightweight) {
			try {
				EJBSecurityCollaborator<?> securityCollaborator = this.ivSecurityCollaborator;
				if (securityCollaborator != null && s.methodId > -1) {
					s.securityCookie = this.notifySecurityCollaboratorPreInvoke(securityCollaborator, s);
					s.ivSecurityCollaborator = securityCollaborator;
				}

				if (this.ivAfterActivationCollaborators != null) {
					for (int i = 0; i < this.ivAfterActivationCollaborators.length; ++i) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"preInvokeAfterActivate : Invoking AfterActivationCollaborator.preInvoke method on: "
											+ this.ivAfterActivationCollaborators[i].getClass().getName());
						}

						Object cookie = this.ivAfterActivationCollaborators[i].preInvoke(s);
						if (cookie != null) {
							if (s.ivAfterActivationCookies == null) {
								s.ivAfterActivationCookies = new Object[this.ivAfterActivationCollaborators.length];
							}

							s.ivAfterActivationCookies[i] = cookie;
						}

						++s.ivAfterActivationPreInvoked;
					}
				}
			} catch (RuntimeException var9) {
				throw var9;
			} catch (CSIException var10) {
				throw var10;
			} catch (Exception var11) {
				throw new CSIException("", var11);
			}
		}

		if (isZOS) {
			DispatchEventListenerCookie[] dispatchEventListenerCookies = s.ivDispatchEventListenerCookies;
			if (dispatchEventListenerCookies != null) {
				this.ivDispatchEventListenerManager.callDispatchEventListeners(6, dispatchEventListenerCookies,
						s.methodInfo);
			}
		}

	}

	private Object notifySecurityCollaboratorPreInvoke(EJBSecurityCollaborator<?> collaborator, EJBRequestData request)
			throws CSIException {
		try {
			return collaborator.preInvoke(request);
		} catch (EJBAccessException var5) {
			CSIAccessException csiEx = new CSIAccessException(var5.getMessage());
			csiEx.setStackTrace(var5.getStackTrace());
			throw csiEx;
		} catch (RuntimeException var6) {
			throw var6;
		} catch (CSIException var7) {
			throw var7;
		} catch (Exception var8) {
			throw new CSIException("", var8);
		}
	}

	private EnterpriseBean preInvokeForStatelessSessionCreate(EJSWrapperBase wrapper, int methodId,
			EJSDeployedSupport s, EJBMethodInfoImpl methodInfo, Object[] args) throws RemoteException {
		s.methodInfo = methodInfo;
		s.ivEJBMethodArguments = args;
		EnterpriseBean eb = null;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();

		try {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc,
						"EJBpreInvokeForStatelessSessionCreate(" + methodId + ":" + methodInfo.getMethodName() + ")");
			}

			s.ivThreadData.pushMethodContext(s);
			s.unpinOnPostInvoke = wrapper.isManagedWrapper ? this.wrapperManager.preInvoke(wrapper) : false;
			EJBSecurityCollaborator<?> securityCollaborator = this.ivSecurityCollaborator;
			if (securityCollaborator != null) {
				s.securityCookie = this.notifySecurityCollaboratorPreInvoke(securityCollaborator, s);
				s.ivSecurityCollaborator = securityCollaborator;
			}

			eb = (EnterpriseBean) wrapper.bmd.homeRecord.homeInternal;
			if (isTraceOn) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc,
							"EJBpreInvokeForStatelessSessionCreate(" + methodId + ":" + methodInfo.getMethodName()
									+ ") " + " Invoking method '" + methodInfo.getMethodName() + "' on bean '"
									+ wrapper.getClass().getName() + "(" + wrapper.beanId + ")");
				}

				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeEnds(s, wrapper);
				}
			}

			return eb;
		} catch (Throwable var9) {
			FFDCFilter.processException(var9, CLASS_NAME + ".preInvokeForStatelessSessionCreate", "2139",
					new Object[]{this, wrapper, methodId, s, methodInfo});
			s.preInvokeException = true;
			if (isTraceOn) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc,
							"EJBpreInvokeForStatelessSessionCreate(" + methodId + ":" + methodInfo.getMethodName()
									+ ") " + " Invoking method '" + methodInfo.getMethodName() + "' on bean '"
									+ wrapper.getClass().getName() + "(" + wrapper.beanId + ")");
				}

				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeException(s, wrapper, var9);
				}
			}

			s.setUncheckedException(var9);
			return null;
		}
	}

	public Object EjbPreInvokeForStatelessCreate(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s,
			Object[] args) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		EJBMethodInfoImpl methodInfo = this.mapMethodInfo(s, wrapper, methodId, (String) null);

		try {
			if (isTraceOn) {
				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeBegins(s, wrapper);
				}

				if (tc.isEntryEnabled()) {
					Tr.entry(tc, "EjbPreInvokeForStatelessCreate(" + methodId + ":" + methodInfo.getMethodName() + ")");
				}

				if (tcClntInfo.isDebugEnabled()) {
					Tr.debug(tcClntInfo, "preInvoke(" + methodInfo.getMethodName() + ")");
				}
			}

			s.methodInfo = methodInfo;
			s.ivEJBMethodArguments = args;
			s.ivThreadData.pushMethodContext(s);
			s.unpinOnPostInvoke = wrapper.isManagedWrapper ? this.wrapperManager.preInvoke(wrapper) : false;
			EJBSecurityCollaborator<?> securityCollaborator = this.ivSecurityCollaborator;
			if (securityCollaborator != null) {
				s.securityCookie = this.notifySecurityCollaboratorPreInvoke(securityCollaborator, s);
				s.ivSecurityCollaborator = securityCollaborator;
			}

			Object bean = wrapper.bmd.homeRecord.homeInternal;
			if (isTraceOn) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc,
							"EjbPreInvokeForStatelessCreate(" + methodId + ":" + methodInfo.getMethodName() + ") "
									+ " Invoking method '" + methodInfo.getMethodName() + "' on bean '"
									+ wrapper.getClass().getName() + "(" + wrapper.beanId + ")");
				}

				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeEnds(s, wrapper);
				}
			}

			return bean;
		} catch (Throwable var9) {
			FFDCFilter.processException(var9, CLASS_NAME + ".EjbPreInvokeForStatelessCreate", "3894",
					new Object[]{this, wrapper, methodId, s, methodInfo});
			s.preInvokeException = true;
			if (isTraceOn) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc,
							"EjbPreInvokeForStatelessCreate(" + methodId + ":" + methodInfo.getMethodName() + ") "
									+ " Invoking method '" + methodInfo.getMethodName() + "' on bean '"
									+ wrapper.getClass().getName() + "(" + wrapper.beanId + ")");
				}

				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeException(s, wrapper, var9);
				}
			}

			s.setUncheckedException(var9);
			return null;
		}
	}

	public Object EjbPreInvokeForManagedBean(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s, BeanO beanO,
			Object[] args) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		EJBMethodInfoImpl methodInfo = this.mapMethodInfo(s, wrapper, methodId, (String) null);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "EjbPreInvokeForManagedBean(" + methodId + ":" + methodInfo.getMethodName() + ")");
		}

		s.methodInfo = methodInfo;
		s.ivEJBMethodArguments = args;
		s.beanO = beanO;
		s.unpinOnPostInvoke = false;
		Object bean = beanO.getBeanInstance();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "EjbPreInvokeForManagedBean(" + methodId + ":" + methodInfo.getMethodName() + ") "
					+ " Invoking method '" + methodInfo.getMethodName() + "' on bean " + Util.identity(bean));
		}

		return bean;
	}

	public void preInvokeForLifecycleInterceptors(LifecycleInterceptorWrapper wrapper, int methodId,
			EJSDeployedSupport s, BeanO beanO) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		EJBThreadData threadData = s.ivThreadData;
		EJBMethodInfoImpl methodInfo = this.mapMethodInfo(s, wrapper, methodId, (String) null);
		if (isTraceOn) {
			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "preInvokeForLifecycleInterceptors(" + methodId + ":" + methodInfo.getMethodName() + ")");
			}

			if (tcClntInfo.isDebugEnabled()) {
				Tr.debug(tcClntInfo, "preInvoke(" + methodInfo.getMethodName() + ")");
			}
		}

		BeanMetaData bmd = wrapper.bmd;
		s.methodInfo = methodInfo;
		s.ivCallerContext = threadData.pushMethodContext(s);
		threadData.ivComponentMetaDataContext.beginContext(bmd);
		threadData.pushCallbackBeanO(beanO);
		s.beanO = beanO;
		s.ivPopCallbackBeanORequired = true;
		s.oldClassLoader = EJBThreadData.svThreadContextAccessor
				.pushContextClassLoaderForUnprivileged(bmd.ivContextClassLoader);

		try {
			s.uowCookie = this.uowCtrl.preInvoke(wrapper.beanId, methodInfo);
			s.uowCtrlPreInvoked = true;
			s.currentTx = this.getCurrentTx(s.uowCookie.getTransactionalUOW(), false);
			s.currentTx.preInvoke(s);
			s.currentIsolationLevel = methodInfo.isolationAttr;
			EJBSecurityCollaborator<?> securityCollaborator = this.ivSecurityCollaborator;
			if (securityCollaborator != null) {
				s.securityCookie = this.notifySecurityCollaboratorPreInvoke(securityCollaborator, s);
				s.ivSecurityCollaborator = securityCollaborator;
			}

			if (isTraceOn) {
				if (tc.isEntryEnabled()) {
					ContainerTx containerTx = s.currentTx;
					Tr.exit(tc,
							"preInvokeForLifecycleInterceptors(" + methodId + ":" + methodInfo.getMethodName() + ") "
									+ " Invoking method '" + methodInfo.getMethodName() + "' on bean '"
									+ wrapper.getClass().getName() + "(" + wrapper.beanId + ")" + "', '" + containerTx
									+ "', isGlobalTx="
									+ (containerTx != null
											? (containerTx.isTransactionGlobal() ? "true" : "false")
											: "Unknown"));
				}

				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePreInvokeEnds(s, wrapper);
				}
			}
		} catch (Throwable var11) {
			this.preinvokeHandleException(var11, wrapper, methodId, s, methodInfo);
		}

	}

	public void postInvoke(EJSWrapper wrapper, int methodId, EJSDeployedSupport s) throws RemoteException {
		this.postInvoke((EJSWrapperBase) wrapper, methodId, s);
	}

	public void postInvoke(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s) throws RemoteException {
		DispatchEventListenerCookie[] dispatchEventListenerCookies = null;
		EJBMethodInfoImpl methodInfo = s.methodInfo;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (methodInfo.isStatelessSessionBean && methodInfo.isHomeCreate) {
			this.EjbPostInvokeForStatelessCreate(wrapper, methodId, s);
		} else {
			if (isTraceOn) {
				if (TEEJBInvocationInfo.isTraceEnabled()) {
					TEEJBInvocationInfo.tracePostInvokeBegins(s, wrapper);
				}

				if (tcClntInfo.isDebugEnabled()) {
					Tr.debug(tcClntInfo, "postInvoke(" + methodInfo.getMethodName() + ")");
				}

				if (tc.isEntryEnabled()) {
					Tr.entry(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")");
				}
			}

			EJBThreadData threadData = s.ivThreadData;
			BeanId beanId = wrapper.beanId;
			BeanO beanO = null;
			BeanMetaData bmd = null;
			if (s.resetCurrentTx) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "s.currentTx may be invalid; reset");
				}

				s.currentTx = this.getCurrentContainerTx();
			}

			if (isZOS) {
				dispatchEventListenerCookies = s.ivDispatchEventListenerCookies;
				if (dispatchEventListenerCookies != null) {
					this.ivDispatchEventListenerManager.callDispatchEventListeners(7, dispatchEventListenerCookies,
							methodInfo);
				}
			}

			boolean var95 = false;

			int i;
			Object cookie;
			ContainerTx currentTx;
			EJBPMICollaborator pmiBean;
			label8884 : {
				try {
					var95 = true;
					beanO = s.beanO;
					if (s.exType != ExceptionType.NO_EXCEPTION) {
						if (s.exType == ExceptionType.CHECKED_EXCEPTION) {
							if (isTraceOn && tc.isEventEnabled()) {
								Tr.event(tc, "Bean method threw exception", s.getException());
							}
						} else if (s.exType == ExceptionType.UNCHECKED_EXCEPTION) {
							if (isTraceOn && tc.isEventEnabled()) {
								Tr.event(tc, "Bean method threw unchecked exception", s.getException());
							}

							if (beanO != null && !s.preInvokeException) {
								beanO.discard();
							}

							if (isTraceOn && tc.isEventEnabled()) {
								Tr.event(tc, "Bean Discarded as non null");
							}
						}
					}

					bmd = wrapper.bmd;
					int i;
					Object cookie;
					if (this.ivBeforeActivationCollaborators != null) {
						for (i = 0; i < s.ivBeforeActivationPreInvoked; ++i) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "postInvoke : Invoking BeforeActivationCollaborator.postInvoke method on: "
										+ this.ivBeforeActivationCollaborators[i].getClass().getName());
							}

							cookie = s.ivBeforeActivationCookies == null ? null : s.ivBeforeActivationCookies[i];
							notifyPostInvoke(this.ivBeforeActivationCollaborators[i], s, cookie);
						}
					}

					if (this.ivAfterActivationCollaborators != null) {
						for (i = 0; i < s.ivAfterActivationPreInvoked; ++i) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "postInvoke : Invoking AfterActivationCollaborator.postInvoke method on: "
										+ this.ivAfterActivationCollaborators[i].getClass().getName());
							}

							cookie = s.ivAfterActivationCookies == null ? null : s.ivAfterActivationCookies[i];
							notifyPostInvoke(this.ivAfterActivationCollaborators[i], s, cookie);
						}
					}

					if (beanO != null) {
						beanO.postInvoke(methodId, s);
						var95 = false;
					} else {
						var95 = false;
					}
					break label8884;
				} catch (RemoteException var108) {
					FFDCFilter.processException(var108, CLASS_NAME + ".postInvoke", "2268",
							new Object[]{this, wrapper, methodId, s});
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "postInvoke failed", var108);
					}

					throw var108;
				} catch (Throwable var109) {
					FFDCFilter.processException(var109, CLASS_NAME + ".postInvoke", "2273",
							new Object[]{this, wrapper, methodId, s});
					if (isTraceOn && tc.isEventEnabled()) {
						Tr.event(tc, "postInvoke failed", var109);
					}

					s.setUncheckedException(var109);
					var95 = false;
				} finally {
					if (var95) {
						if (isZOS && dispatchEventListenerCookies != null) {
							this.ivDispatchEventListenerManager.callDispatchEventListeners(12,
									dispatchEventListenerCookies, methodInfo);
						}

						ContainerTx currentTx = s.currentTx;
						boolean var79 = false;

						label8800 : {
							EJBPMICollaborator pmiBean;
							int i;
							Object cookie;
							label8801 : {
								label8802 : {
									try {
										label8357 : {
											try {
												var79 = true;
												if (beanO != null) {
													this.activator.postInvoke(currentTx, beanO);
												}

												if (currentTx != null) {
													currentTx.postInvoke(s);
												}

												if (s.uowCtrlPreInvoked) {
													if (s.began && currentTx != null
															&& currentTx.ivPostInvokeContext == null) {
														currentTx.ivPostInvokeContext = s;
													}

													this.uowCtrl.postInvoke(beanId, s.uowCookie, s.exType, methodInfo);
												} else if (methodInfo.isLightweightTxCapable && s.currentTx != null) {
													if (s.isLightweight) {
														if (s.exType == ExceptionType.UNCHECKED_EXCEPTION) {
															if (isTraceOn && tc.isDebugEnabled()) {
																Tr.debug(tc, "Lightweight:handleException - rollback");
															}

															this.uowCtrl.setRollbackOnly();
															throw new CSITransactionRolledbackException(
																	"Unexpected Exception from Lightweight EJB method");
														}
													} else if (beanO != null && bmd.type == 4) {
														beanO.beforeCompletion();
														this.simulateCommitBean(beanO, currentTx);
													}
												}

												if (currentTx != null) {
													if (currentTx.ivRemoveBeanO == null) {
														var79 = false;
														break label8802;
													}

													if (!bmd.usesBeanManagedTx && !bmd.usesBeanManagedAS) {
														try {
															currentTx.delist(beanO);
														} catch (TransactionRolledbackException var96) {
															FFDCFilter.processException(var96,
																	CLASS_NAME + ".postInvoke", "4641", this);
															if (isTraceOn && tc.isEventEnabled()) {
																Tr.event(tc,
																		"Exception thrown from ContainerTx.delist()",
																		new Object[]{beanO, var96});
															}
														}

														this.simulateCommitBean(beanO, currentTx);
														var79 = false;
														break label8802;
													}

													currentTx.ivRemoveBeanO = null;
													throw new RemoveException(
															"Cannot remove stateful session bean within a transaction.");
												}

												var79 = false;
												break label8802;
											} catch (CSITransactionRolledbackException var97) {
												FFDCFilter.processException(var97, CLASS_NAME + ".postInvoke", "2326",
														new Object[]{this, wrapper, methodId, s});
												this.postInvokeRolledbackException(s, var97);
												var79 = false;
												break label8357;
											} catch (Throwable var98) {
												FFDCFilter.processException(var98, CLASS_NAME + ".postInvoke", "2366",
														this);
												if (isTraceOn && tc.isDebugEnabled()) {
													Tr.debug(tc,
															"postInvoke: Exception in finally clause. An unexpected case",
															var98);
												}
											}

											if (s.exType == ExceptionType.NO_EXCEPTION) {
												s.setUncheckedException(var98);
												var79 = false;
											} else {
												var79 = false;
											}
											break label8801;
										}
									} finally {
										if (var79) {
											if (currentTx == null) {
												this.postInvokePopCallbackContexts(s);
											} else if (!s.began || currentTx.ivPostInvokeContext != null) {
												this.postInvokePopCallbackContexts(s);
												if (currentTx.ivPostInvokeContext == s) {
													currentTx.ivPostInvokeContext = null;
												}
											}

											EJBPMICollaborator pmiBean = wrapper.ivPmiBean;
											if (pmiBean != null && s.pmiPreInvoked) {
												pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
												if (methodInfo.isHomeCreate()) {
													if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
														pmiBean.finalTime(14, s.pmiCookie);
													}
												} else if (methodInfo.isComponentRemove()
														&& (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
													pmiBean.finalTime(15, s.pmiCookie);
												}
											}

											if (s.ivSecurityCollaborator != null) {
												notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
											}

											if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
												for (int i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
													if (isTraceOn && tc.isDebugEnabled()) {
														Tr.debug(tc,
																"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
																		+ this.ivBeforeActivationAfterCompletionCollaborators[i]
																				.getClass().getName());
													}

													Object cookie = s.ivBeforeActivationAfterCompletionCookies == null
															? null
															: s.ivBeforeActivationAfterCompletionCookies[i];
													notifyPostInvoke(
															this.ivBeforeActivationAfterCompletionCollaborators[i], s,
															cookie);
												}
											}

											if (s.ivEJBMethodCallback != null) {
												s.invocationCallbackPostInvoke();
											}

											if (s.unpinOnPostInvoke) {
												this.wrapperManager.postInvoke(wrapper);
											}

											if (s.currentTx != null && s.began) {
												s.currentTx.releaseResources();
												s.currentTx = null;
											}

											if (methodInfo.setClassLoader) {
												EJBThreadData.svThreadContextAccessor
														.popContextClassLoaderForUnprivileged(s.oldClassLoader);
											} else {
												threadData.popORBWrapperClassLoader();
											}

											threadData.popMethodContext();
											if (isTraceOn) {
												if (tc.isEntryEnabled()) {
													Tr.exit(tc,
															"EJBpostInvoke(" + methodId + ":"
																	+ methodInfo.getMethodName() + ")"
																	+ (s.ivException != null
																			? "**** throws " + s.ivException
																			: ""));
												}

												if (TEEJBInvocationInfo.isTraceEnabled()) {
													if (s.ivException == null) {
														TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
													} else {
														TEEJBInvocationInfo.tracePostInvokeException(s, wrapper,
																s.ivException);
													}
												}
											}

										}
									}

									if (currentTx == null) {
										this.postInvokePopCallbackContexts(s);
									} else if (!s.began || currentTx.ivPostInvokeContext != null) {
										this.postInvokePopCallbackContexts(s);
										if (currentTx.ivPostInvokeContext == s) {
											currentTx.ivPostInvokeContext = null;
										}
									}

									pmiBean = wrapper.ivPmiBean;
									if (pmiBean != null && s.pmiPreInvoked) {
										pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
										if (methodInfo.isHomeCreate()) {
											if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
												pmiBean.finalTime(14, s.pmiCookie);
											}
										} else if (methodInfo.isComponentRemove()
												&& (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
											pmiBean.finalTime(15, s.pmiCookie);
										}
									}

									if (s.ivSecurityCollaborator != null) {
										notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
									}

									if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
										for (i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
											if (isTraceOn && tc.isDebugEnabled()) {
												Tr.debug(tc,
														"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
																+ this.ivBeforeActivationAfterCompletionCollaborators[i]
																		.getClass().getName());
											}

											cookie = s.ivBeforeActivationAfterCompletionCookies == null
													? null
													: s.ivBeforeActivationAfterCompletionCookies[i];
											notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s,
													cookie);
										}
									}

									if (s.ivEJBMethodCallback != null) {
										s.invocationCallbackPostInvoke();
									}

									if (s.unpinOnPostInvoke) {
										this.wrapperManager.postInvoke(wrapper);
									}

									if (s.currentTx != null && s.began) {
										s.currentTx.releaseResources();
										s.currentTx = null;
									}

									if (methodInfo.setClassLoader) {
										EJBThreadData.svThreadContextAccessor
												.popContextClassLoaderForUnprivileged(s.oldClassLoader);
									} else {
										threadData.popORBWrapperClassLoader();
									}

									threadData.popMethodContext();
									if (isTraceOn) {
										if (tc.isEntryEnabled()) {
											Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName()
													+ ")"
													+ (s.ivException != null ? "**** throws " + s.ivException : ""));
										}

										if (TEEJBInvocationInfo.isTraceEnabled()) {
											if (s.ivException == null) {
												TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
											} else {
												TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
											}
										}
									}
									break label8800;
								}

								if (currentTx == null) {
									this.postInvokePopCallbackContexts(s);
								} else if (!s.began || currentTx.ivPostInvokeContext != null) {
									this.postInvokePopCallbackContexts(s);
									if (currentTx.ivPostInvokeContext == s) {
										currentTx.ivPostInvokeContext = null;
									}
								}

								pmiBean = wrapper.ivPmiBean;
								if (pmiBean != null && s.pmiPreInvoked) {
									pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
									if (methodInfo.isHomeCreate()) {
										if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
											pmiBean.finalTime(14, s.pmiCookie);
										}
									} else if (methodInfo.isComponentRemove()
											&& (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
										pmiBean.finalTime(15, s.pmiCookie);
									}
								}

								if (s.ivSecurityCollaborator != null) {
									notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
								}

								if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
									for (i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
										if (isTraceOn && tc.isDebugEnabled()) {
											Tr.debug(tc,
													"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
															+ this.ivBeforeActivationAfterCompletionCollaborators[i]
																	.getClass().getName());
										}

										cookie = s.ivBeforeActivationAfterCompletionCookies == null
												? null
												: s.ivBeforeActivationAfterCompletionCookies[i];
										notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s,
												cookie);
									}
								}

								if (s.ivEJBMethodCallback != null) {
									s.invocationCallbackPostInvoke();
								}

								if (s.unpinOnPostInvoke) {
									this.wrapperManager.postInvoke(wrapper);
								}

								if (s.currentTx != null && s.began) {
									s.currentTx.releaseResources();
									s.currentTx = null;
								}

								if (methodInfo.setClassLoader) {
									EJBThreadData.svThreadContextAccessor
											.popContextClassLoaderForUnprivileged(s.oldClassLoader);
								} else {
									threadData.popORBWrapperClassLoader();
								}

								threadData.popMethodContext();
								if (isTraceOn) {
									if (tc.isEntryEnabled()) {
										Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
												+ (s.ivException != null ? "**** throws " + s.ivException : ""));
									}

									if (TEEJBInvocationInfo.isTraceEnabled()) {
										if (s.ivException == null) {
											TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
										} else {
											TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
										}
									}
								}
								break label8800;
							}

							if (currentTx == null) {
								this.postInvokePopCallbackContexts(s);
							} else if (!s.began || currentTx.ivPostInvokeContext != null) {
								this.postInvokePopCallbackContexts(s);
								if (currentTx.ivPostInvokeContext == s) {
									currentTx.ivPostInvokeContext = null;
								}
							}

							pmiBean = wrapper.ivPmiBean;
							if (pmiBean != null && s.pmiPreInvoked) {
								pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
								if (methodInfo.isHomeCreate()) {
									if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
										pmiBean.finalTime(14, s.pmiCookie);
									}
								} else if (methodInfo.isComponentRemove()
										&& (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
									pmiBean.finalTime(15, s.pmiCookie);
								}
							}

							if (s.ivSecurityCollaborator != null) {
								notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
							}

							if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
								for (i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
									if (isTraceOn && tc.isDebugEnabled()) {
										Tr.debug(tc,
												"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
														+ this.ivBeforeActivationAfterCompletionCollaborators[i]
																.getClass().getName());
									}

									cookie = s.ivBeforeActivationAfterCompletionCookies == null
											? null
											: s.ivBeforeActivationAfterCompletionCookies[i];
									notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s, cookie);
								}
							}

							if (s.ivEJBMethodCallback != null) {
								s.invocationCallbackPostInvoke();
							}

							if (s.unpinOnPostInvoke) {
								this.wrapperManager.postInvoke(wrapper);
							}

							if (s.currentTx != null && s.began) {
								s.currentTx.releaseResources();
								s.currentTx = null;
							}

							if (methodInfo.setClassLoader) {
								EJBThreadData.svThreadContextAccessor
										.popContextClassLoaderForUnprivileged(s.oldClassLoader);
							} else {
								threadData.popORBWrapperClassLoader();
							}

							threadData.popMethodContext();
							if (isTraceOn) {
								if (tc.isEntryEnabled()) {
									Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
											+ (s.ivException != null ? "**** throws " + s.ivException : ""));
								}

								if (TEEJBInvocationInfo.isTraceEnabled()) {
									if (s.ivException == null) {
										TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
									} else {
										TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
									}
								}
							}
						}

					}
				}

				if (isZOS && dispatchEventListenerCookies != null) {
					this.ivDispatchEventListenerManager.callDispatchEventListeners(12, dispatchEventListenerCookies,
							methodInfo);
				}

				currentTx = s.currentTx;
				boolean var63 = false;

				label8885 : {
					label8886 : {
						try {
							try {
								var63 = true;
								if (beanO != null) {
									this.activator.postInvoke(currentTx, beanO);
								}

								if (currentTx != null) {
									currentTx.postInvoke(s);
								}

								if (s.uowCtrlPreInvoked) {
									if (s.began && currentTx != null && currentTx.ivPostInvokeContext == null) {
										currentTx.ivPostInvokeContext = s;
									}

									this.uowCtrl.postInvoke(beanId, s.uowCookie, s.exType, methodInfo);
								} else if (methodInfo.isLightweightTxCapable && s.currentTx != null) {
									if (s.isLightweight) {
										if (s.exType == ExceptionType.UNCHECKED_EXCEPTION) {
											if (isTraceOn && tc.isDebugEnabled()) {
												Tr.debug(tc, "Lightweight:handleException - rollback");
											}

											this.uowCtrl.setRollbackOnly();
											throw new CSITransactionRolledbackException(
													"Unexpected Exception from Lightweight EJB method");
										}
									} else if (beanO != null && bmd.type == 4) {
										beanO.beforeCompletion();
										this.simulateCommitBean(beanO, currentTx);
									}
								}

								if (currentTx != null) {
									if (currentTx.ivRemoveBeanO == null) {
										var63 = false;
										break label8885;
									}

									if (!bmd.usesBeanManagedTx && !bmd.usesBeanManagedAS) {
										try {
											currentTx.delist(beanO);
										} catch (TransactionRolledbackException var100) {
											FFDCFilter.processException(var100, CLASS_NAME + ".postInvoke", "4641",
													this);
											if (isTraceOn && tc.isEventEnabled()) {
												Tr.event(tc, "Exception thrown from ContainerTx.delist()",
														new Object[]{beanO, var100});
											}
										}

										this.simulateCommitBean(beanO, currentTx);
										var63 = false;
										break label8885;
									}

									currentTx.ivRemoveBeanO = null;
									throw new RemoveException(
											"Cannot remove stateful session bean within a transaction.");
								}

								var63 = false;
								break label8885;
							} catch (CSITransactionRolledbackException var101) {
								FFDCFilter.processException(var101, CLASS_NAME + ".postInvoke", "2326",
										new Object[]{this, wrapper, methodId, s});
								this.postInvokeRolledbackException(s, var101);
								var63 = false;
								break label8886;
							} catch (Throwable var102) {
								FFDCFilter.processException(var102, CLASS_NAME + ".postInvoke", "2366", this);
								if (isTraceOn && tc.isDebugEnabled()) {
									Tr.debug(tc, "postInvoke: Exception in finally clause. An unexpected case", var102);
								}
							}

							if (s.exType == ExceptionType.NO_EXCEPTION) {
								s.setUncheckedException(var102);
								var63 = false;
							} else {
								var63 = false;
							}
						} finally {
							if (var63) {
								if (currentTx == null) {
									this.postInvokePopCallbackContexts(s);
								} else if (!s.began || currentTx.ivPostInvokeContext != null) {
									this.postInvokePopCallbackContexts(s);
									if (currentTx.ivPostInvokeContext == s) {
										currentTx.ivPostInvokeContext = null;
									}
								}

								EJBPMICollaborator pmiBean = wrapper.ivPmiBean;
								if (pmiBean != null && s.pmiPreInvoked) {
									pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
									if (methodInfo.isHomeCreate()) {
										if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
											pmiBean.finalTime(14, s.pmiCookie);
										}
									} else if (methodInfo.isComponentRemove()
											&& (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
										pmiBean.finalTime(15, s.pmiCookie);
									}
								}

								if (s.ivSecurityCollaborator != null) {
									notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
								}

								if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
									for (int i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
										if (isTraceOn && tc.isDebugEnabled()) {
											Tr.debug(tc,
													"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
															+ this.ivBeforeActivationAfterCompletionCollaborators[i]
																	.getClass().getName());
										}

										Object cookie = s.ivBeforeActivationAfterCompletionCookies == null
												? null
												: s.ivBeforeActivationAfterCompletionCookies[i];
										notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s,
												cookie);
									}
								}

								if (s.ivEJBMethodCallback != null) {
									s.invocationCallbackPostInvoke();
								}

								if (s.unpinOnPostInvoke) {
									this.wrapperManager.postInvoke(wrapper);
								}

								if (s.currentTx != null && s.began) {
									s.currentTx.releaseResources();
									s.currentTx = null;
								}

								if (methodInfo.setClassLoader) {
									EJBThreadData.svThreadContextAccessor
											.popContextClassLoaderForUnprivileged(s.oldClassLoader);
								} else {
									threadData.popORBWrapperClassLoader();
								}

								threadData.popMethodContext();
								if (isTraceOn) {
									if (tc.isEntryEnabled()) {
										Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
												+ (s.ivException != null ? "**** throws " + s.ivException : ""));
									}

									if (TEEJBInvocationInfo.isTraceEnabled()) {
										if (s.ivException == null) {
											TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
										} else {
											TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
										}
									}
								}

							}
						}

						if (currentTx == null) {
							this.postInvokePopCallbackContexts(s);
						} else if (!s.began || currentTx.ivPostInvokeContext != null) {
							this.postInvokePopCallbackContexts(s);
							if (currentTx.ivPostInvokeContext == s) {
								currentTx.ivPostInvokeContext = null;
							}
						}

						pmiBean = wrapper.ivPmiBean;
						if (pmiBean != null && s.pmiPreInvoked) {
							pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
							if (methodInfo.isHomeCreate()) {
								if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
									pmiBean.finalTime(14, s.pmiCookie);
								}
							} else if (methodInfo.isComponentRemove()
									&& (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
								pmiBean.finalTime(15, s.pmiCookie);
							}
						}

						if (s.ivSecurityCollaborator != null) {
							notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
						}

						if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
							for (i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
								if (isTraceOn && tc.isDebugEnabled()) {
									Tr.debug(tc,
											"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
													+ this.ivBeforeActivationAfterCompletionCollaborators[i].getClass()
															.getName());
								}

								cookie = s.ivBeforeActivationAfterCompletionCookies == null
										? null
										: s.ivBeforeActivationAfterCompletionCookies[i];
								notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s, cookie);
							}
						}

						if (s.ivEJBMethodCallback != null) {
							s.invocationCallbackPostInvoke();
						}

						if (s.unpinOnPostInvoke) {
							this.wrapperManager.postInvoke(wrapper);
						}

						if (s.currentTx != null && s.began) {
							s.currentTx.releaseResources();
							s.currentTx = null;
						}

						if (methodInfo.setClassLoader) {
							EJBThreadData.svThreadContextAccessor
									.popContextClassLoaderForUnprivileged(s.oldClassLoader);
						} else {
							threadData.popORBWrapperClassLoader();
						}

						threadData.popMethodContext();
						if (isTraceOn) {
							if (tc.isEntryEnabled()) {
								Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
										+ (s.ivException != null ? "**** throws " + s.ivException : ""));
							}

							if (TEEJBInvocationInfo.isTraceEnabled()) {
								if (s.ivException == null) {
									TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
								} else {
									TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
								}

								return;
							}
						}

						return;
					}

					if (currentTx == null) {
						this.postInvokePopCallbackContexts(s);
					} else if (!s.began || currentTx.ivPostInvokeContext != null) {
						this.postInvokePopCallbackContexts(s);
						if (currentTx.ivPostInvokeContext == s) {
							currentTx.ivPostInvokeContext = null;
						}
					}

					pmiBean = wrapper.ivPmiBean;
					if (pmiBean != null && s.pmiPreInvoked) {
						pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
						if (methodInfo.isHomeCreate()) {
							if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
								pmiBean.finalTime(14, s.pmiCookie);
							}
						} else if (methodInfo.isComponentRemove()
								&& (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
							pmiBean.finalTime(15, s.pmiCookie);
						}
					}

					if (s.ivSecurityCollaborator != null) {
						notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
					}

					if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
						for (i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc,
										"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
												+ this.ivBeforeActivationAfterCompletionCollaborators[i].getClass()
														.getName());
							}

							cookie = s.ivBeforeActivationAfterCompletionCookies == null
									? null
									: s.ivBeforeActivationAfterCompletionCookies[i];
							notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s, cookie);
						}
					}

					if (s.ivEJBMethodCallback != null) {
						s.invocationCallbackPostInvoke();
					}

					if (s.unpinOnPostInvoke) {
						this.wrapperManager.postInvoke(wrapper);
					}

					if (s.currentTx != null && s.began) {
						s.currentTx.releaseResources();
						s.currentTx = null;
					}

					if (methodInfo.setClassLoader) {
						EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(s.oldClassLoader);
					} else {
						threadData.popORBWrapperClassLoader();
					}

					threadData.popMethodContext();
					if (isTraceOn) {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
									+ (s.ivException != null ? "**** throws " + s.ivException : ""));
						}

						if (TEEJBInvocationInfo.isTraceEnabled()) {
							if (s.ivException == null) {
								TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
							} else {
								TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
							}

							return;
						}
					}

					return;
				}

				if (currentTx == null) {
					this.postInvokePopCallbackContexts(s);
				} else if (!s.began || currentTx.ivPostInvokeContext != null) {
					this.postInvokePopCallbackContexts(s);
					if (currentTx.ivPostInvokeContext == s) {
						currentTx.ivPostInvokeContext = null;
					}
				}

				pmiBean = wrapper.ivPmiBean;
				if (pmiBean != null && s.pmiPreInvoked) {
					pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
					if (methodInfo.isHomeCreate()) {
						if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
							pmiBean.finalTime(14, s.pmiCookie);
						}
					} else if (methodInfo.isComponentRemove() && (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
						pmiBean.finalTime(15, s.pmiCookie);
					}
				}

				if (s.ivSecurityCollaborator != null) {
					notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
				}

				if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
					for (i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
											+ this.ivBeforeActivationAfterCompletionCollaborators[i].getClass()
													.getName());
						}

						cookie = s.ivBeforeActivationAfterCompletionCookies == null
								? null
								: s.ivBeforeActivationAfterCompletionCookies[i];
						notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s, cookie);
					}
				}

				if (s.ivEJBMethodCallback != null) {
					s.invocationCallbackPostInvoke();
				}

				if (s.unpinOnPostInvoke) {
					this.wrapperManager.postInvoke(wrapper);
				}

				if (s.currentTx != null && s.began) {
					s.currentTx.releaseResources();
					s.currentTx = null;
				}

				if (methodInfo.setClassLoader) {
					EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(s.oldClassLoader);
				} else {
					threadData.popORBWrapperClassLoader();
				}

				threadData.popMethodContext();
				if (isTraceOn) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
								+ (s.ivException != null ? "**** throws " + s.ivException : ""));
					}

					if (TEEJBInvocationInfo.isTraceEnabled()) {
						if (s.ivException == null) {
							TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
						} else {
							TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
						}

						return;
					}
				}

				return;
			}

			if (isZOS && dispatchEventListenerCookies != null) {
				this.ivDispatchEventListenerManager.callDispatchEventListeners(12, dispatchEventListenerCookies,
						methodInfo);
			}

			currentTx = s.currentTx;
			boolean var47 = false;

			label8887 : {
				label8888 : {
					try {
						var47 = true;
						if (beanO != null) {
							this.activator.postInvoke(currentTx, beanO);
						}

						if (currentTx != null) {
							currentTx.postInvoke(s);
						}

						if (s.uowCtrlPreInvoked) {
							if (s.began && currentTx != null && currentTx.ivPostInvokeContext == null) {
								currentTx.ivPostInvokeContext = s;
							}

							this.uowCtrl.postInvoke(beanId, s.uowCookie, s.exType, methodInfo);
						} else if (methodInfo.isLightweightTxCapable && s.currentTx != null) {
							if (s.isLightweight) {
								if (s.exType == ExceptionType.UNCHECKED_EXCEPTION) {
									if (isTraceOn && tc.isDebugEnabled()) {
										Tr.debug(tc, "Lightweight:handleException - rollback");
									}

									this.uowCtrl.setRollbackOnly();
									throw new CSITransactionRolledbackException(
											"Unexpected Exception from Lightweight EJB method");
								}
							} else if (beanO != null && bmd.type == 4) {
								beanO.beforeCompletion();
								this.simulateCommitBean(beanO, currentTx);
							}
						}

						if (currentTx != null) {
							if (currentTx.ivRemoveBeanO == null) {
								var47 = false;
							} else {
								if (bmd.usesBeanManagedTx || bmd.usesBeanManagedAS) {
									currentTx.ivRemoveBeanO = null;
									throw new RemoveException(
											"Cannot remove stateful session bean within a transaction.");
								}

								try {
									currentTx.delist(beanO);
								} catch (TransactionRolledbackException var104) {
									FFDCFilter.processException(var104, CLASS_NAME + ".postInvoke", "4641", this);
									if (isTraceOn && tc.isEventEnabled()) {
										Tr.event(tc, "Exception thrown from ContainerTx.delist()",
												new Object[]{beanO, var104});
									}
								}

								this.simulateCommitBean(beanO, currentTx);
								var47 = false;
							}
						} else {
							var47 = false;
						}
					} catch (CSITransactionRolledbackException var105) {
						FFDCFilter.processException(var105, CLASS_NAME + ".postInvoke", "2326",
								new Object[]{this, wrapper, methodId, s});
						this.postInvokeRolledbackException(s, var105);
						var47 = false;
						break label8887;
					} catch (Throwable var106) {
						FFDCFilter.processException(var106, CLASS_NAME + ".postInvoke", "2366", this);
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "postInvoke: Exception in finally clause. An unexpected case", var106);
						}

						if (s.exType == ExceptionType.NO_EXCEPTION) {
							s.setUncheckedException(var106);
							var47 = false;
						} else {
							var47 = false;
						}
						break label8888;
					} finally {
						if (var47) {
							if (currentTx == null) {
								this.postInvokePopCallbackContexts(s);
							} else if (!s.began || currentTx.ivPostInvokeContext != null) {
								this.postInvokePopCallbackContexts(s);
								if (currentTx.ivPostInvokeContext == s) {
									currentTx.ivPostInvokeContext = null;
								}
							}

							EJBPMICollaborator pmiBean = wrapper.ivPmiBean;
							if (pmiBean != null && s.pmiPreInvoked) {
								pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
								if (methodInfo.isHomeCreate()) {
									if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
										pmiBean.finalTime(14, s.pmiCookie);
									}
								} else if (methodInfo.isComponentRemove()
										&& (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
									pmiBean.finalTime(15, s.pmiCookie);
								}
							}

							if (s.ivSecurityCollaborator != null) {
								notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
							}

							if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
								for (int i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
									if (isTraceOn && tc.isDebugEnabled()) {
										Tr.debug(tc,
												"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
														+ this.ivBeforeActivationAfterCompletionCollaborators[i]
																.getClass().getName());
									}

									Object cookie = s.ivBeforeActivationAfterCompletionCookies == null
											? null
											: s.ivBeforeActivationAfterCompletionCookies[i];
									notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s, cookie);
								}
							}

							if (s.ivEJBMethodCallback != null) {
								s.invocationCallbackPostInvoke();
							}

							if (s.unpinOnPostInvoke) {
								this.wrapperManager.postInvoke(wrapper);
							}

							if (s.currentTx != null && s.began) {
								s.currentTx.releaseResources();
								s.currentTx = null;
							}

							if (methodInfo.setClassLoader) {
								EJBThreadData.svThreadContextAccessor
										.popContextClassLoaderForUnprivileged(s.oldClassLoader);
							} else {
								threadData.popORBWrapperClassLoader();
							}

							threadData.popMethodContext();
							if (isTraceOn) {
								if (tc.isEntryEnabled()) {
									Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
											+ (s.ivException != null ? "**** throws " + s.ivException : ""));
								}

								if (TEEJBInvocationInfo.isTraceEnabled()) {
									if (s.ivException == null) {
										TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
									} else {
										TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
									}
								}
							}

						}
					}

					if (currentTx == null) {
						this.postInvokePopCallbackContexts(s);
					} else if (!s.began || currentTx.ivPostInvokeContext != null) {
						this.postInvokePopCallbackContexts(s);
						if (currentTx.ivPostInvokeContext == s) {
							currentTx.ivPostInvokeContext = null;
						}
					}

					pmiBean = wrapper.ivPmiBean;
					if (pmiBean != null && s.pmiPreInvoked) {
						pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
						if (methodInfo.isHomeCreate()) {
							if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
								pmiBean.finalTime(14, s.pmiCookie);
							}
						} else if (methodInfo.isComponentRemove()
								&& (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
							pmiBean.finalTime(15, s.pmiCookie);
						}
					}

					if (s.ivSecurityCollaborator != null) {
						notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
					}

					if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
						for (i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc,
										"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
												+ this.ivBeforeActivationAfterCompletionCollaborators[i].getClass()
														.getName());
							}

							cookie = s.ivBeforeActivationAfterCompletionCookies == null
									? null
									: s.ivBeforeActivationAfterCompletionCookies[i];
							notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s, cookie);
						}
					}

					if (s.ivEJBMethodCallback != null) {
						s.invocationCallbackPostInvoke();
					}

					if (s.unpinOnPostInvoke) {
						this.wrapperManager.postInvoke(wrapper);
					}

					if (s.currentTx != null && s.began) {
						s.currentTx.releaseResources();
						s.currentTx = null;
					}

					if (methodInfo.setClassLoader) {
						EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(s.oldClassLoader);
					} else {
						threadData.popORBWrapperClassLoader();
					}

					threadData.popMethodContext();
					if (isTraceOn) {
						if (tc.isEntryEnabled()) {
							Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
									+ (s.ivException != null ? "**** throws " + s.ivException : ""));
						}

						if (TEEJBInvocationInfo.isTraceEnabled()) {
							if (s.ivException == null) {
								TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
							} else {
								TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
							}

							return;
						}
					}

					return;
				}

				if (currentTx == null) {
					this.postInvokePopCallbackContexts(s);
				} else if (!s.began || currentTx.ivPostInvokeContext != null) {
					this.postInvokePopCallbackContexts(s);
					if (currentTx.ivPostInvokeContext == s) {
						currentTx.ivPostInvokeContext = null;
					}
				}

				pmiBean = wrapper.ivPmiBean;
				if (pmiBean != null && s.pmiPreInvoked) {
					pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
					if (methodInfo.isHomeCreate()) {
						if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
							pmiBean.finalTime(14, s.pmiCookie);
						}
					} else if (methodInfo.isComponentRemove() && (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
						pmiBean.finalTime(15, s.pmiCookie);
					}
				}

				if (s.ivSecurityCollaborator != null) {
					notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
				}

				if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
					for (i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc,
									"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
											+ this.ivBeforeActivationAfterCompletionCollaborators[i].getClass()
													.getName());
						}

						cookie = s.ivBeforeActivationAfterCompletionCookies == null
								? null
								: s.ivBeforeActivationAfterCompletionCookies[i];
						notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s, cookie);
					}
				}

				if (s.ivEJBMethodCallback != null) {
					s.invocationCallbackPostInvoke();
				}

				if (s.unpinOnPostInvoke) {
					this.wrapperManager.postInvoke(wrapper);
				}

				if (s.currentTx != null && s.began) {
					s.currentTx.releaseResources();
					s.currentTx = null;
				}

				if (methodInfo.setClassLoader) {
					EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(s.oldClassLoader);
				} else {
					threadData.popORBWrapperClassLoader();
				}

				threadData.popMethodContext();
				if (isTraceOn) {
					if (tc.isEntryEnabled()) {
						Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
								+ (s.ivException != null ? "**** throws " + s.ivException : ""));
					}

					if (TEEJBInvocationInfo.isTraceEnabled()) {
						if (s.ivException == null) {
							TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
						} else {
							TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
						}

						return;
					}
				}

				return;
			}

			if (currentTx == null) {
				this.postInvokePopCallbackContexts(s);
			} else if (!s.began || currentTx.ivPostInvokeContext != null) {
				this.postInvokePopCallbackContexts(s);
				if (currentTx.ivPostInvokeContext == s) {
					currentTx.ivPostInvokeContext = null;
				}
			}

			pmiBean = wrapper.ivPmiBean;
			if (pmiBean != null && s.pmiPreInvoked) {
				pmiBean.methodPostInvoke(wrapper.beanId, methodInfo, s.pmiCookie);
				if (methodInfo.isHomeCreate()) {
					if (bmd.isStatefulSessionBean() || bmd.isEntityBean()) {
						pmiBean.finalTime(14, s.pmiCookie);
					}
				} else if (methodInfo.isComponentRemove() && (bmd.isStatefulSessionBean() || bmd.isEntityBean())) {
					pmiBean.finalTime(15, s.pmiCookie);
				}
			}

			if (s.ivSecurityCollaborator != null) {
				notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
			}

			if (this.ivBeforeActivationAfterCompletionCollaborators != null) {
				for (i = 0; i < s.ivBeforeActivationAfterCompletionPreInvoked; ++i) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc,
								"postInokve : Invoking BeforeActivationAfterCompletionCollaborator.postInvoke method on: "
										+ this.ivBeforeActivationAfterCompletionCollaborators[i].getClass().getName());
					}

					cookie = s.ivBeforeActivationAfterCompletionCookies == null
							? null
							: s.ivBeforeActivationAfterCompletionCookies[i];
					notifyPostInvoke(this.ivBeforeActivationAfterCompletionCollaborators[i], s, cookie);
				}
			}

			if (s.ivEJBMethodCallback != null) {
				s.invocationCallbackPostInvoke();
			}

			if (s.unpinOnPostInvoke) {
				this.wrapperManager.postInvoke(wrapper);
			}

			if (s.currentTx != null && s.began) {
				s.currentTx.releaseResources();
				s.currentTx = null;
			}

			if (methodInfo.setClassLoader) {
				EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(s.oldClassLoader);
			} else {
				threadData.popORBWrapperClassLoader();
			}

			threadData.popMethodContext();
			if (isTraceOn) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "EJBpostInvoke(" + methodId + ":" + methodInfo.getMethodName() + ")"
							+ (s.ivException != null ? "**** throws " + s.ivException : ""));
				}

				if (TEEJBInvocationInfo.isTraceEnabled()) {
					if (s.ivException == null) {
						TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
					} else {
						TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
					}
				}
			}
		}

	}

	void postInvokePopCallbackContexts(EJSDeployedSupport s) {
		if (s.ivPopCallbackBeanORequired) {
			s.ivThreadData.popCallbackBeanO();
			BeanO beanO = s.beanO;
			if (beanO != null) {
				BeanMetaData bmd = beanO.home.beanMetaData;
				if (bmd.type == 3 || bmd.type == 7) {
					try {
						beanO.returnToPool();
					} catch (RemoteException var5) {
						FFDCFilter.processException(var5, CLASS_NAME + ".postInvoke", "359", this);
					}
				}
			}
		}

		s.ivThreadData.ivComponentMetaDataContext.endContext();
	}

	private static <T> void notifyPostInvoke(EJBRequestCollaborator<T> collaborator, EJBRequestData request,
			Object preInvokeData) throws CSIException {
		try {
			collaborator.postInvoke(request, preInvokeData);
		} catch (RuntimeException var4) {
			throw var4;
		} catch (CSIException var5) {
			throw var5;
		} catch (Exception var6) {
			throw new CSIException("", var6);
		}
	}

	private void postInvokeRolledbackException(EJSDeployedSupport s, CSITransactionRolledbackException ex)
			throws RemoteException {
		if (!s.ivBeginnerSetRollbackOnly && (!s.began || s.exType != ExceptionType.CHECKED_EXCEPTION)
				|| s.methodInfo.ivInterface == MethodInterface.TIMED_OBJECT) {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "postInvoke: transaction rollback in finally", ex);
			}

			if (s.currentTx != null && s.currentTx.ivPostProcessingException != null) {
				s.getExceptionMappingStrategy().setUncheckedException(s, s.currentTx.ivPostProcessingException);
				ex.detail = s.getRootCause();
			} else if (ex.detail == null) {
				ex.detail = s.getRootCause();
			} else {
				Throwable exceptionToUse = s.getRootCause();
				if (exceptionToUse == null) {
					s.rootEx = s.getExceptionMappingStrategy().findRootCause(ex.detail);
				} else {
					ex.detail = exceptionToUse;
				}
			}

			Exception crex = s.mapCSITransactionRolledBackException(ex);
			if (crex instanceof RemoteException) {
				throw (RemoteException) crex;
			}

			if (crex instanceof RuntimeException) {
				throw (RuntimeException) crex;
			}
		}

	}

	private void simulateCommitBean(BeanO beanO, ContainerTx containerTx) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "simulateCommitBean");
		}

		try {
			beanO.commit(containerTx);
		} catch (Throwable var6) {
			FFDCFilter.processException(var6, CLASS_NAME + ".simulateCommitBean", "5300", new Object[]{this, beanO});
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Exception thrown from BeanO.commit()", new Object[]{beanO, var6});
			}
		}

		try {
			this.activator.commitBean(containerTx, beanO);
		} catch (Throwable var5) {
			FFDCFilter.processException(var5, CLASS_NAME + ".simulateCommitBean", "5313", new Object[]{this, beanO});
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Exception thrown from commitBean()", new Object[]{beanO, var5});
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "simulateCommitBean");
		}

	}

	public void EjbPostInvokeForStatelessCreate(EJSWrapperBase wrapper, int methodId, EJSDeployedSupport s)
			throws RemoteException {
		EJBMethodInfoImpl methodInfo = s.methodInfo;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn) {
			if (TEEJBInvocationInfo.isTraceEnabled()) {
				TEEJBInvocationInfo.tracePostInvokeBegins(s, wrapper);
			}

			if (tcClntInfo.isDebugEnabled()) {
				Tr.debug(tcClntInfo, "postInvoke(" + methodInfo.getMethodName() + ")");
			}

			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "EjbPostInvokeForStatelessCreate(" + methodId + ":" + methodInfo.getMethodName() + ")");
			}
		}

		if (s.resetCurrentTx) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "s.currentTx may be invalid; reset");
			}

			s.currentTx = this.getCurrentContainerTx();
		}

		EJBThreadData threadData = s.ivThreadData;
		if (!methodInfo.setClassLoader) {
			threadData.popORBWrapperClassLoader();
		}

		if (s.ivSecurityCollaborator != null) {
			notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
		}

		if (s.unpinOnPostInvoke) {
			this.wrapperManager.postInvoke(wrapper);
		}

		threadData.popMethodContext();
		if (isTraceOn) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "EjbPostInvokeForStatelessCreate(" + methodId + ":" + methodInfo.getMethodName() + ")");
			}

			if (TEEJBInvocationInfo.isTraceEnabled()) {
				if (s.ivException == null) {
					TEEJBInvocationInfo.tracePostInvokeEnds(s, wrapper);
				} else {
					TEEJBInvocationInfo.tracePostInvokeException(s, wrapper, s.ivException);
				}
			}
		}

	}

	public void postInvokeForLifecycleInterceptors(LifecycleInterceptorWrapper wrapper, int methodId,
			EJSDeployedSupport s) throws RemoteException {
		EJBMethodInfoImpl methodInfo = s.methodInfo;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn) {
			if (TEEJBInvocationInfo.isTraceEnabled()) {
				TEEJBInvocationInfo.tracePostInvokeBegins(s, wrapper);
			}

			if (tcClntInfo.isDebugEnabled()) {
				Tr.debug(tcClntInfo, "postInvoke(" + methodInfo.getMethodName() + ")");
			}

			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "postInvokeForLifecycleInterceptors(" + methodId + ":" + methodInfo.getMethodName() + ")");
			}
		}

		if (s.resetCurrentTx) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "s.currentTx may be invalid; reset");
			}

			s.currentTx = this.getCurrentContainerTx();
		}

		s.currentTx.postInvoke(s);

		try {
			boolean isRollbackOnly = this.uowCtrl.getRollbackOnly();

			try {
				if (s.began && s.currentTx.ivPostInvokeContext == null) {
					s.currentTx.ivPostInvokeContext = s;
				}

				this.uowCtrl.postInvoke(wrapper.beanId, s.uowCookie, s.exType, methodInfo);
			} catch (CSITransactionRolledbackException var11) {
				this.postInvokeRolledbackException(s, var11);
			}

			if (methodId == 0 && isRollbackOnly) {
				String msg = "setRollbackOnly called from within a singleton post construct method.";
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, msg);
				}

				throw new EJBTransactionRolledbackException(msg);
			}
		} finally {
			if (!s.began || s.currentTx.ivPostInvokeContext != null) {
				this.postInvokePopCallbackContexts(s);
			}

			if (s.ivSecurityCollaborator != null) {
				notifyPostInvoke(s.ivSecurityCollaborator, s, s.securityCookie);
			}

			if (s.currentTx != null && s.began) {
				s.currentTx.releaseResources();
				s.currentTx = null;
			}

			EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(s.oldClassLoader);
			s.ivThreadData.popMethodContext();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "postInvokeForLifecycleInterceptors(" + methodId + ":" + methodInfo.getMethodName() + ")"
						+ (s.ivException != null ? "**** throws " + s.ivException : ""));
			}

		}

	}

	public EJSWrapperCommon getWrapper(BeanId id) throws CSIException, RemoteException {
		return this.wrapperManager.getWrapper(id);
	}

	public EJSWrapperCommon createWrapper(BeanId beanId) throws RemoteException, CSIException {
		HomeInternal home = beanId.getHome();
		if (home == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Unknown beanId home name", beanId);
			}

			throw new InvalidBeanIdException();
		} else {
			EJSWrapperCommon result = null;

			try {
				result = home.internalCreateWrapper(beanId);
			} catch (CreateException var5) {
				FFDCFilter.processException(var5, CLASS_NAME + ".createWrapper", "2651", this);
			}

			return result;
		}
	}

	public static EJSContainer getContainer(String containerName) {
		return getDefaultContainer();
	}

	public static EJSContainer getDefaultContainer() {
		return defaultContainer;
	}

	public static EJBThreadData getThreadData() {
		return (EJBThreadData) svThreadData.get();
	}

	public static BeanO getCallbackBeanO() {
		return ((EJBThreadData) svThreadData.get()).getCallbackBeanO();
	}

	public static ClassLoader getClassLoader() {
		return classLoader;
	}

	public OrbUtils getOrbUtils() {
		return this.orbUtils;
	}

	public ContainerExtensionFactory getContainerExtensionFactory() {
		return this.containerExtFactory;
	}

	public static EJSDeployedSupport getMethodContext() {
		return getThreadData().getMethodContext();
	}

	public static ClassLoader getClassLoader(J2EEName beanName) {
		ClassLoader cl = null;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getClassLoader(" + beanName + ")");
		}

		HomeInternal hi = homeOfHomes.getHome(beanName);
		if (hi != null) {
			cl = hi.getClassLoader();
		} else if (isTraceOn && tc.isDebugEnabled()) {
			Tr.exit(tc, "getClassLoader: Home not found!");
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getClassLoader: " + cl);
		}

		return cl;
	}

	public void flush() throws RemoteException {
		ContainerTx containerTx = this.getCurrentTx(false);
		containerTx.flush();
	}

	public void dump() {
		if (tc.isDumpEnabled() && !this.dumped) {
			try {
				this.introspect(new TrDumpWriter(tc), true);
			} finally {
				this.dumped = true;
			}

		}
	}

	public void resetDump() {
		this.dumped = false;
	}

	public Object preInvokeORBDispatch(Object object, String operation) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			String objStr = null;
			if (object != null) {
				objStr = object.getClass().getName();
			}

			Tr.debug(tc, "preInvokeORBDispatch(" + objStr + ", " + operation + ")");
		}

		EJBThreadData threadData = null;
		if (object instanceof Tie) {
			Object object = ((Tie) object).getTarget();
			if (object instanceof EJSWrapperBase) {
				EJSWrapperBase wrapper = (EJSWrapperBase) object;
				BeanMetaData bmd = wrapper.bmd;
				if (bmd != null) {
					threadData = (EJBThreadData) svThreadData.get();
					threadData.pushClassLoader(bmd);
				}
			}
		}

		return threadData;
	}

	public void postInvokeORBDispatch(Object object) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "postInvokeORBDispatch: " + (object != null));
		}

		if (object != null) {
			((EJBThreadData) object).popClassLoader();
		}

	}

	public EJBHome getEJBHome(J2EEName name) throws ContainerEJBException {
		try {
			EJSWrapperCommon wrapperCommon = this.getHomeWrapperCommon(name);
			EJSWrapper wrapper = wrapperCommon.getRemoteWrapper();
			return (EJBHome) PortableRemoteObject.toStub(wrapper);
		} catch (RemoteException var4) {
			FFDCFilter.processException(var4, CLASS_NAME + ".getEJBHome", "2955", this);
			if (var4.detail == null) {
				throw new ContainerEJBException("Could not get EJBHome", var4);
			} else {
				throw new ContainerEJBException("Could not get EJBHome", var4.detail);
			}
		} catch (Throwable var5) {
			FFDCFilter.processException(var5, CLASS_NAME + ".getEJBHome", "2967", this);
			throw new ContainerEJBException("Could not get EJBHome", var5);
		}
	}

	public EJBLocalHome getEJBLocalHome(J2EEName name) throws ContainerEJBException {
		try {
			EJSWrapperCommon wrapperCommon = this.getHomeWrapperCommon(name);
			return (EJBLocalHome) wrapperCommon.getLocalObject();
		} catch (Throwable var3) {
			FFDCFilter.processException(var3, CLASS_NAME + ".getEJBLocalHome", "2993", this);
			throw new ContainerEJBException("Could not get EJBLocalHome", var3);
		}
	}

	public Object createAggregateLocalReference(J2EEName beanName, ManagedObjectContext context)
			throws EJBNotFoundException, CreateException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createAggregateLocalReference : " + beanName);
		}

		EJSHome home = this.getInstalledHome(beanName);
		if (!home.beanMetaData.isSessionBean()) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createAggregateLocalReference : not a session bean!");
			}

			throw new EJBException("The " + beanName.getComponent() + " bean in the " + beanName.getModule()
					+ " module of the " + beanName.getApplication() + " application has no business local interfaces.");
		} else {
			Object reference = null;
			reference = home.createAggregateLocalReference(context);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createAggregateLocalReference : " + Util.identity(reference));
			}

			return reference;
		}
	}

	public J2EEName getJ2EEName(EJSWrapperBase wrapper) {
		return wrapper.beanId.getJ2EEName();
	}

	public void setInactivePoolCleanupInterval(long interval) {
		this.poolManager.setDrainInterval(interval);
	}

	public void setInactiveCacheCleanupInterval(long interval) {
		this.activator.setCacheSweepInterval(interval);
		this.wrapperManager.setWrapperCacheSweepInterval(3L * interval);
	}

	public void setPreferredCacheSize(long size) {
		int intSize = (int) size;
		this.activator.setCachePreferredMaxSize(intSize);
		this.wrapperManager.setWrapperCacheSize(2 * intSize);
	}

	public void setupTimers() {
		if (this.ivTimedObjectPool == null) {
			this.ivTimedObjectPool = this.poolManager.createThreadSafePool(5, 50);
		}

	}

	public void setAllowTimerAccessOutsideBean(boolean allowAccess) {
		this.allowTimerAccessOutsideBean = allowAccess;
	}

	public void setTransactionalStatefulLifecycleMethods(boolean transactional) {
		this.transactionalStatefulLifecycleMethods = transactional;
	}

	public boolean isTransactionStatefulLifecycleMethods() {
		return this.transactionalStatefulLifecycleMethods;
	}

	public void setNoMethodInterfaceMDBEnabled(boolean enable) {
		this.noMethodInterfaceMDBEnabled = enable;
	}

	public boolean isNoMethodInterfaceMDBEnabled() {
		return this.noMethodInterfaceMDBEnabled;
	}

	public synchronized void initOptACleanUpLockManager() {
		if (this.lockManager == null) {
			this.lockManager = new LockManager();
		}

	}

	public Class<?> getEJBPrimaryKeyClass(J2EEName j2eeName) {
		Class<?> rtnPKeyClass = null;
		BeanMetaData bmd = (BeanMetaData) this.internalBeanMetaDataStore.get(j2eeName);
		if (bmd != null) {
			rtnPKeyClass = bmd.pKeyClass;
		}

		return rtnPKeyClass;
	}

	public final boolean isEnableSFSBFailover() {
		return this.ivSFSBFailoverEnabled;
	}

	public SfFailoverCache getSfFailoverCache() {
		return this.ivSfFailoverCache;
	}

	public Object invoke(EJSDeployedSupport s, Timer timer) throws Exception {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "EJBinvoke(" + s.methodId + ":" + s.methodInfo.getMethodName() + ")");
		}

		ManagedBeanOBase beanO = (ManagedBeanOBase) s.beanO;
		InvocationContextImpl<?> invCtx = beanO.getInvocationContext();
		invCtx.setTimer(timer);
		EJBMethodInfoImpl methodInfo = s.methodInfo;
		return invCtx.doAroundInvoke(methodInfo.ivAroundInterceptors, methodInfo.ivMethod, s.ivEJBMethodArguments, s);
	}

	public Object invoke(EJSDeployedSupport s, Object[] parameters) throws Exception {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "WS-EJBinvoke(" + s.methodId + ":" + s.methodInfo.getMethodName() + ")");
		}

		SessionBeanO beanO = (SessionBeanO) s.beanO;
		InvocationContextImpl<?> invCtx = beanO.getInvocationContext();
		EJBMethodInfoImpl methodInfo = s.methodInfo;
		return invCtx.doAroundInvoke(methodInfo.ivAroundInterceptors, methodInfo.ivMethod, parameters, s);
	}

	public Object invokeProceed(EJSDeployedSupport s, Method businessMethod, Object bean, Object[] methodParameters,
			boolean parametersModified) throws Exception {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJBinvokeProceed(" + s.methodId + ":" + s.methodInfo.getMethodName() + ")");
		}

		if (parametersModified) {
			s.ivEJBMethodArguments = methodParameters;
			if (this.doesJaccNeedsEJBArguments((EJSWrapperBase) null) && s.ivSecurityCollaborator != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "invoking EJBSecurityCollaborator.argumentsUpdated");
				}

				notifySecurityCollaboratorArgumentsUpdated(s.ivSecurityCollaborator, s);
			}
		}

		Object returnValue = businessMethod.invoke(bean, methodParameters);
		if (isTraceOn && tc.isEntryEnabled()) {
			StringBuilder sb = new StringBuilder();
			sb.append("EJBinvokeProceed(").append(s.methodId).append(":");
			sb.append(s.methodInfo.getMethodName()).append(") returning ");
			if (returnValue == null) {
				sb.append("null");
			} else {
				sb.append(returnValue.getClass().getName());
				sb.append("@").append(returnValue.hashCode());
			}

			Tr.exit(tc, sb.toString());
		}

		return returnValue;
	}

	private static <T> void notifySecurityCollaboratorArgumentsUpdated(EJBSecurityCollaborator<T> collaborator,
			EJSDeployedSupport s) throws Exception {
		T preInvokeData = s.securityCookie;
		collaborator.argumentsUpdated(s, preInvokeData);
	}

	public Object getExPcBindingContext() {
		EJSDeployedSupport s = getMethodContext();
		return s != null ? s.getExPcBindingContext() : null;
	}

	public Future<?> scheduleAsynchMethod(EJSWrapperBase wrapper, int methodId, Object[] args) throws RemoteException {
		return this.ivEJBRuntime.scheduleAsync(wrapper, wrapper.methodInfos[methodId], methodId, args);
	}

	public String[] introspectSelf() {
		return new String[0];
	}

	public void ffdcDump(IncidentStream is) {
		this.introspect(new IncidentStreamWriter(is), false);
	}

	public void introspect(IntrospectionWriter writer, boolean fullBMD) {
		writer.begin("EJSContainer Dump ---> " + this);
		writer.println("ivName                = " + this.ivName);
		writer.println("ivEJBRuntime          = " + this.ivEJBRuntime);
		writer.println("ivEmbedded            = " + this.ivEmbedded);
		writer.println("ivEntityHelper        = " + this.ivEntityHelper);
		writer.println("ivSFSBFailoverEnabled = " + this.ivSFSBFailoverEnabled);
		writer.println("ivUOWManager          = " + this.ivUOWManager);
		writer.println("pmiFactory            = " + this.pmiFactory);
		writer.println("uowCtrl               = " + this.uowCtrl);
		writer.println("userTransactionImpl   = " + this.userTransactionImpl);
		writer.begin("Collaborators");
		writer.println("securityCollaborator                                    = " + this.ivSecurityCollaborator);
		this.introspectCollab("beforeActivationCollaborators", this.ivBeforeActivationCollaborators, writer);
		this.introspectCollab("beforeActivationAfterCompletionCollaborators",
				this.ivBeforeActivationAfterCompletionCollaborators, writer);
		this.introspectCollab("afterActivationCollaborators", this.ivAfterActivationCollaborators, writer);
		writer.end();
		writer.begin("internalBeanMetaDataStore : " + this.internalBeanMetaDataStore.size() + " installed beans");
		Hashtable var3 = this.internalBeanMetaDataStore;
		synchronized (this.internalBeanMetaDataStore) {
			if (fullBMD) {
				Enumeration en = this.internalBeanMetaDataStore.elements();

				while (en.hasMoreElements()) {
					BeanMetaData bmd = (BeanMetaData) en.nextElement();
					bmd.introspect(writer);
				}
			} else {
				List<String> keyNames = new ArrayList();
				Iterator i$ = this.internalBeanMetaDataStore.keySet().iterator();

				while (i$.hasNext()) {
					J2EEName name = (J2EEName) i$.next();
					keyNames.add(name.toString());
				}

				Collections.sort(keyNames);
				Set<J2EEName> keys = this.internalBeanMetaDataStore.keySet();
				Iterator i$ = keyNames.iterator();

				label45 : while (true) {
					while (true) {
						if (!i$.hasNext()) {
							break label45;
						}

						String keyName = (String) i$.next();
						Iterator i$ = keys.iterator();

						while (i$.hasNext()) {
							J2EEName key = (J2EEName) i$.next();
							if (keyName.equals(key.toString())) {
								writer.println(keyName + " : " + this.internalBeanMetaDataStore.get(key));
								break;
							}
						}
					}
				}
			}
		}

		writer.end();
		this.activator.introspect(writer);
		this.wrapperManager.introspect(writer);
		writer.end();
	}

	private void introspectCollab(String name, EJBRequestCollaborator<?>[] collabArray, IntrospectionWriter writer) {
		if (collabArray != null && collabArray.length > 0) {
			int i = 0;
			EJBRequestCollaborator[] arr$ = collabArray;
			int len$ = collabArray.length;

			for (int i$ = 0; i$ < len$; ++i$) {
				Object element = arr$[i$];
				String outString = name + "[" + i++ + "]";
				String format = String.format("%-55s = %s", outString, Util.identity(element));
				writer.println(format);
			}
		} else {
			String outString = name + "[]";
			String format = String.format("%-55s %s", outString, "is empty.");
			writer.println(format);
		}

	}

	static {
		containerTxResourceKey = CLASS_NAME;
		j2eeNameFactory = null;
	}
}