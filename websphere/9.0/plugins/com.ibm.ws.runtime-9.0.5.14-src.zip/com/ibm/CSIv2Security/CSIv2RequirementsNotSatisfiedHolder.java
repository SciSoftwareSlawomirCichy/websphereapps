package com.ibm.CSIv2Security;

import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.Streamable;

public final class CSIv2RequirementsNotSatisfiedHolder implements Streamable {
	public CSIv2RequirementsNotSatisfied value = null;

	public CSIv2RequirementsNotSatisfiedHolder() {
	}

	public CSIv2RequirementsNotSatisfiedHolder(CSIv2RequirementsNotSatisfied var1) {
		this.value = var1;
	}

	public void _read(InputStream var1) {
		this.value = CSIv2RequirementsNotSatisfiedHelper.read(var1);
	}

	public void _write(OutputStream var1) {
		CSIv2RequirementsNotSatisfiedHelper.write(var1, this.value);
	}

	public TypeCode _type() {
		return CSIv2RequirementsNotSatisfiedHelper.type();
	}
}