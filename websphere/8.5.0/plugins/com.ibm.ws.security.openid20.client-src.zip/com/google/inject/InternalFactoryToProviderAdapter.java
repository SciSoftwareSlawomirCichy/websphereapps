package com.google.inject;

import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.InternalContext;
import com.google.inject.internal.InternalFactory;
import com.google.inject.internal.Preconditions;
import com.google.inject.internal.SourceProvider;
import com.google.inject.spi.Dependency;

class InternalFactoryToProviderAdapter<T> implements InternalFactory<T> {
	private final Initializable<Provider<? extends T>> initializable;
	private final Object source;

	public InternalFactoryToProviderAdapter(Initializable<Provider<? extends T>> initializable) {
		this(initializable, SourceProvider.UNKNOWN_SOURCE);
	}

	public InternalFactoryToProviderAdapter(Initializable<Provider<? extends T>> initializable, Object source) {
		this.initializable = (Initializable) Preconditions.checkNotNull(initializable, "provider");
		this.source = Preconditions.checkNotNull(source, "source");
	}

	public T get(Errors errors, InternalContext context, Dependency<?> dependency) throws ErrorsException {
		try {
			return errors.checkForNull(((Provider) this.initializable.get(errors)).get(), this.source, dependency);
		} catch (RuntimeException var5) {
			throw errors.withSource(this.source).errorInProvider(var5).toException();
		}
	}

	public String toString() {
		return this.initializable.toString();
	}
}