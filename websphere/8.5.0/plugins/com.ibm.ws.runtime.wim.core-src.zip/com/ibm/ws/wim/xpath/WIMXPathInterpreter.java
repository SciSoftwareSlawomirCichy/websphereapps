package com.ibm.ws.wim.xpath;

import com.ibm.websphere.wim.exception.AttributeNotSupportedException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.xpath.WIMXPathInterpreter.1;
import com.ibm.ws.wim.xpath.WIMXPathInterpreter.JJCalls;
import com.ibm.ws.wim.xpath.WIMXPathInterpreter.LookaheadSuccess;
import com.ibm.ws.wim.xpath.mapping.datatype.FederationLogicalNode;
import com.ibm.ws.wim.xpath.mapping.datatype.FederationParenthesisNode;
import com.ibm.ws.wim.xpath.mapping.datatype.LogicalNode;
import com.ibm.ws.wim.xpath.mapping.datatype.ParenthesisNode;
import com.ibm.ws.wim.xpath.mapping.datatype.PropertyNode;
import com.ibm.ws.wim.xpath.mapping.datatype.XPathNode;
import com.ibm.ws.wim.xpath.util.MetadataMapper;
import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WIMXPathInterpreter implements WIMXPathInterpreterConstants {
	static String CLASSNAME = WIMXPathInterpreter.class.getName();
	private static final Logger trcLogger;
	private XPathNode node = null;
	StringBuffer reposXPathExpression = new StringBuffer();
	StringBuffer laXPathExpression = new StringBuffer();
	List entityTypes = null;
	private String xsiType = "xsi:type";
	private final String la = "LA";
	private final String repos = "REPOS";
	private final String repos_and_la = "REPOSNLA";
	private boolean checkLocation = false;
	private MetadataMapper _metaDataMapper = null;
	private boolean _bDebug = false;
	public WIMXPathInterpreterTokenManager token_source;
	SimpleCharStream jj_input_stream;
	public Token token;
	public Token jj_nt;
	private int jj_ntk;
	private Token jj_scanpos;
	private Token jj_lastpos;
	private int jj_la;
	public boolean lookingAhead = false;
	private boolean jj_semLA;
	private int jj_gen;
	private final int[] jj_la1 = new int[10];
	private static int[] jj_la1_0;
	private static int[] jj_la1_1;
	private final JJCalls[] jj_2_rtns = new JJCalls[5];
	private boolean jj_rescan = false;
	private int jj_gc = 0;
	private final LookaheadSuccess jj_ls = new LookaheadSuccess((1)null);
	private Vector jj_expentries = new Vector();
	private int[] jj_expentry;
	private int jj_kind = -1;
	private int[] jj_lasttokens = new int[100];
	private int jj_endpos;

	public List getEntityTypes() {
		return this.entityTypes;
	}

	private boolean checkEntityType(String var1) throws ParseException {
		return this._metaDataMapper.isValidEntityType(var1);
	}

	private String checkProperty(String var1) throws AttributeNotSupportedException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "WIM_SPI checkProperty", "propName  : " + var1);
		}

		boolean var3 = false;
		boolean var4 = false;
		if (var1.equals(this.xsiType)) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "checkProperty", " " + var1 + " is defined in Repository " + "REPOS");
			}

			return "REPOS";
		} else {
			var3 = false;

			int var5;
			for (var5 = 0; var5 < this.entityTypes.size() && !var3; ++var5) {
				var3 = this._metaDataMapper.isPropertyInRepository(var1, (String) this.entityTypes.get(var5));
			}

			if (var3) {
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.exiting(CLASSNAME, "checkProperty",
							"Property " + var1 + " is defined in Repository " + "REPOS");
				}

				return "REPOS";
			} else {
				for (var5 = 0; var5 < this.entityTypes.size(); ++var5) {
					var4 = this._metaDataMapper.isPropertyInLookAside(var1, (String) this.entityTypes.get(var5));
				}

				if (!var3 && !var4) {
					throw new AttributeNotSupportedException("ATTRIBUTE_NOT_SUPPORTED",
							WIMMessageHelper.generateMsgParms(var1), CLASSNAME, "checkProperty");
				} else {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "checkProperty",
								"Property " + var1 + " is defined in Repository " + "LA");
					}

					return "LA";
				}
			}
		}
	}

	private String getPropertyLocation(XPathNode var1) throws AttributeNotSupportedException {
		Iterator var2 = var1.getPropertyNodes(new HashMap());
		String var3 = "";

		while (var2.hasNext()) {
			PropertyNode var4 = (PropertyNode) var2.next();
			String var5 = this.checkProperty(var4.getName());
			if (var5.equals("REPOS")) {
				var4.setPropertyLocation(true);
				if (var3.equals("")) {
					var3 = var5;
				} else if (var3.equals(var5)) {
					var3 = "REPOS";
				} else {
					var3 = "REPOSNLA";
				}
			} else {
				var4.setPropertyLocation(false);
				if (var3.equals("")) {
					var3 = var5;
				} else if (var3.equals(var5)) {
					var3 = "LA";
				} else {
					var3 = "REPOSNLA";
				}
			}
		}

		if (var3.equals("")) {
			return null;
		} else {
			return var3;
		}
	}

	private void setPredicate(XPathNode var1) {
		String var2 = "setPredicate";
		this.node = var1;
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, var2, "Predicate condition : " + var1);
		}

	}

	private void printVector(Vector var1) {
		String var2 = "printVector";
		StringBuffer var3 = new StringBuffer();
		Enumeration var4 = var1.elements();

		while (var4.hasMoreElements()) {
			var3.append((String) var4.nextElement() + " ");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, var2, var3.toString());
		}

	}

	public final XPathNode parse(MetadataMapper var1) throws ParseException, AttributeNotSupportedException {
		this._metaDataMapper = var1;
		if (this._metaDataMapper != null) {
			this.checkLocation = true;
		}

		this.XPath();
		return this.node;
	}

	public final void XPath() throws ParseException, AttributeNotSupportedException {
		this.wimexpr();
		this.jj_consume_token(0);
	}

	public final void wimexpr() throws ParseException, AttributeNotSupportedException {
		switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
			case 2 :
			case 7 :
				if (this.jj_2_2(Integer.MAX_VALUE)) {
					this.predefinedPredicate();
					break;
				} else {
					switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
						case 7 :
							this.orEntityTypeExpr();
							return;
						default :
							this.jj_la1[1] = this.jj_gen;
							this.jj_consume_token(-1);
							throw new ParseException();
					}
				}
			case 31 :
				this.jj_consume_token(31);
				this.jj_consume_token(12);
				if (this.jj_2_1(Integer.MAX_VALUE)) {
					this.predefinedLocPredicate();
					break;
				} else {
					switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
						case 4 :
							this.locOrEntityTypeExpr();
							return;
						default :
							this.jj_la1[0] = this.jj_gen;
							this.jj_consume_token(-1);
							throw new ParseException();
					}
				}
			default :
				this.jj_la1[2] = this.jj_gen;
				this.jj_consume_token(-1);
				throw new ParseException();
		}

	}

	public final void predefinedPredicate() throws ParseException, AttributeNotSupportedException {
		switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
			case 2 :
				this.jj_consume_token(2);
				this.orEntityTypeExpr();
				this.jj_consume_token(3);
				this.jj_consume_token(1);
				this.predicateExpr();
				break;
			case 7 :
				this.entityTypeExpr();
				this.jj_consume_token(1);
				this.predicateExpr();
				break;
			default :
				this.jj_la1[3] = this.jj_gen;
				this.jj_consume_token(-1);
				throw new ParseException();
		}

	}

	public final void predefinedLocPredicate() throws ParseException, AttributeNotSupportedException {
		this.jj_consume_token(4);
		this.predefinedPredicate();
		this.jj_consume_token(5);
	}

	public final void locOrEntityTypeExpr() throws ParseException {
		this.jj_consume_token(4);
		this.orEntityTypeExpr();
		this.jj_consume_token(5);
	}

	public final void orEntityTypeExpr() throws ParseException {
		this.entityTypeExpr();

		while (true) {
			switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
				case 6 :
					this.jj_consume_token(6);
					this.entityTypeExpr();
					break;
				default :
					this.jj_la1[4] = this.jj_gen;
					return;
			}
		}
	}

	public final void internalPredicate() throws ParseException, AttributeNotSupportedException {
		this.jj_consume_token(4);
		this.predicateExpr();
		this.jj_consume_token(5);
	}

	public final void entityTypeExpr() throws ParseException {
		this.jj_consume_token(7);
		Token var1 = this.jj_consume_token(22);
		Token var2 = this.jj_consume_token(23);
		if (this.entityTypes == null) {
			this.entityTypes = new ArrayList();
		}

		this.entityTypes.add(var2.image.substring(1, var2.image.length() - 1));
	}

	public final void predicate() throws ParseException, AttributeNotSupportedException {
		Token var1 = this.getToken(0);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "predicate", "Context token for predicate '" + var1.image + "'");
		}

		this.predicateExpr();
	}

	public final void predicateExpr() throws ParseException, AttributeNotSupportedException {
		XPathNode var1 = this.simpleSelectionExpr();
		this.setPredicate(var1);
	}

	public final XPathNode simpleSelectionExpr() throws ParseException, AttributeNotSupportedException {
		Object var1 = null;
		XPathNode var2 = null;
		XPathNode var3 = null;

		for (var2 = this.andExpr(); this.jj_2_3(2); var3 = this.simpleSelectionExpr()) {
			this.jj_consume_token(6);
		}

		if (var3 == null) {
			return var2;
		} else {
			Object var4 = new LogicalNode();
			if (this.checkLocation) {
				String var5 = this.getPropertyLocation(var2);
				String var6 = this.getPropertyLocation(var3);
				if (!var5.equals(var6)) {
					var4 = new FederationLogicalNode();
					((LogicalNode) var4).setPropertyLocation(false);
				} else if (!var5.equals("REPOSNLA") && !var6.equals("REPOSNLA")) {
					((LogicalNode) var4).setPropertyLocation(var5.equals("REPOS"));
				} else {
					var4 = new FederationLogicalNode();
					((LogicalNode) var4).setPropertyLocation(false);
				}
			}

			((LogicalNode) var4).setLeftChild(var2);
			((LogicalNode) var4).setOperator("or");
			((LogicalNode) var4).setRightChild(var3);
			return (XPathNode) var4;
		}
	}

	public final XPathNode orExpr() throws ParseException, AttributeNotSupportedException {
		Object var1 = null;
		Object var2 = null;
		Object var3 = null;
		Object var4 = null;
		XPathNode var5 = null;
		XPathNode var6 = null;
		var5 = this.andExpr();

		while (true) {
			switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
				case 6 :
					this.jj_consume_token(6);
					var6 = this.andExpr();
					break;
				default :
					this.jj_la1[5] = this.jj_gen;
					if (var6 != null) {
						if (var5 != null) {
							Object var7 = new LogicalNode();
							if (this.checkLocation) {
								String var8 = this.getPropertyLocation(var5);
								String var9 = this.getPropertyLocation(var6);
								if (!var8.equals(var9)) {
									var7 = new FederationLogicalNode();
									((LogicalNode) var7).setPropertyLocation(false);
								} else {
									((LogicalNode) var7).setPropertyLocation(var8.equals("REPOS"));
								}
							}

							((LogicalNode) var7).setLeftChild(var5);
							((LogicalNode) var7).setOperator("or");
							((LogicalNode) var7).setRightChild(var6);
							return (XPathNode) var7;
						}

						return (XPathNode) var2;
					}

					return var5;
			}
		}
	}

	public final XPathNode andExpr() throws ParseException, AttributeNotSupportedException {
		XPathNode var1 = null;
		XPathNode var2 = null;
		XPathNode var3 = null;
		Object var4 = null;
		Object var5;
		switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
			case 2 :
				this.jj_consume_token(2);
				var1 = this.simpleSelectionExpr();
				this.jj_consume_token(3);

				while (this.jj_2_4(2)) {
					this.jj_consume_token(1);
					var3 = this.simpleSelectionExpr();
				}

				if (var3 != null) {
					var5 = new LogicalNode();
					Object var14 = new ParenthesisNode();
					boolean var15 = false;
					if (this.checkLocation) {
						String var8 = this.getPropertyLocation(var1);
						String var9 = this.getPropertyLocation(var3);
						if (!var8.equals(var9)) {
							var5 = new FederationLogicalNode();
						} else {
							var15 = var8.equals("REPOS");
						}

						short var10 = var1.getNodeType();
						switch (var10) {
							case 4 :
							case 8 :
								var14 = new FederationParenthesisNode();
								var5 = new FederationLogicalNode();
								((LogicalNode) var5).setPropertyLocation(var15);
								break;
							default :
								String var11 = this.getPropertyLocation(var1);
								var15 = var11.equals("REPOS");
								((ParenthesisNode) var14).setPropertyLocation(var15);
								String var12 = this.getPropertyLocation(var3);
								if (var15) {
									var15 = var12.equals(var11);
								} else {
									var15 = false;
								}

								((LogicalNode) var5).setPropertyLocation(var15);
						}
					}

					((ParenthesisNode) var14).setChild(var1);
					((LogicalNode) var5).setLeftChild(var14);
					((LogicalNode) var5).setOperator("and");
					((LogicalNode) var5).setRightChild(var3);
					return (XPathNode) var5;
				} else {
					var5 = new ParenthesisNode();
					if (this.checkLocation) {
						short var13 = var1.getNodeType();
						switch (var13) {
							case 0 :
								((ParenthesisNode) var5)
										.setPropertyLocation(((PropertyNode) var1).isPropertyInRepository());
								break;
							case 1 :
								((ParenthesisNode) var5)
										.setPropertyLocation(((LogicalNode) var1).isPropertyInRepository());
								break;
							case 2 :
								((ParenthesisNode) var5)
										.setPropertyLocation(((ParenthesisNode) var1).isPropertyInRepository());
							case 3 :
							case 5 :
							case 6 :
							case 7 :
							default :
								break;
							case 4 :
							case 8 :
								var5 = new FederationParenthesisNode();
								if (var1 instanceof FederationParenthesisNode) {
									((ParenthesisNode) var5).setPropertyLocation(
											((FederationParenthesisNode) var1).isPropertyInRepository());
								} else {
									((ParenthesisNode) var5).setPropertyLocation(
											((FederationLogicalNode) var1).isPropertyInRepository());
								}
						}
					}

					((ParenthesisNode) var5).setChild(var1);
					return (XPathNode) var5;
				}
			case 13 :
			case 14 :
			case 21 :
				for (var2 = this.relationalExpr(); this.jj_2_5(2); var3 = this.simpleSelectionExpr()) {
					this.jj_consume_token(1);
				}

				if (var3 != null) {
					var5 = new LogicalNode();
					if (this.checkLocation) {
						String var6 = this.getPropertyLocation(var2);
						String var7 = this.getPropertyLocation(var3);
						if (!var6.equals(var7)) {
							var5 = new FederationLogicalNode();
						} else {
							((LogicalNode) var5).setPropertyLocation(var6.equals("REPOS"));
						}
					}

					((LogicalNode) var5).setLeftChild(var2);
					((LogicalNode) var5).setOperator("and");
					((LogicalNode) var5).setRightChild(var3);
					return (XPathNode) var5;
				}

				return var2;
			default :
				this.jj_la1[6] = this.jj_gen;
				this.jj_consume_token(-1);
				throw new ParseException();
		}
	}

	public final XPathNode relationalExpr() throws ParseException, AttributeNotSupportedException {
		String var1 = this.faname();
		Token var3 = this.jj_consume_token(22);
		String var2 = this.processToken();
		PropertyNode var4 = new PropertyNode();
		String var5;
		if (this.checkLocation) {
			var5 = this.checkProperty(var1);
			var4.setPropertyLocation(var5.equals("REPOS"));
		}

		var4.setName(var1);
		var4.setOperator(var3.image);
		var5 = var2.replaceAll("''", "'");
		var2 = var5.replaceAll("\"\"", "\"");
		var4.setValue(var2);
		return var4;
	}

	public final String name() throws ParseException {
		Token var1;
		switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
			case 13 :
				var1 = this.jj_consume_token(13);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "name", "name = " + var1.image);
				}

				return var1.image;
			case 14 :
				var1 = this.jj_consume_token(14);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "name", "name = " + var1.image);
				}

				return var1.image;
			default :
				this.jj_la1[7] = this.jj_gen;
				this.jj_consume_token(-1);
				throw new ParseException();
		}
	}

	public final String faname() throws ParseException {
		switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
			case 21 :
				this.jj_consume_token(21);
				break;
			default :
				this.jj_la1[8] = this.jj_gen;
		}

		String var1 = this.name();
		return var1;
	}

	public final String processToken() throws ParseException {
		Token var1;
		switch (this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
			case 23 :
				var1 = this.jj_consume_token(23);
				if (this.checkLocation) {
					return var1.image;
				}

				return var1.image.substring(1, var1.image.length() - 1);
			case 24 :
				var1 = this.jj_consume_token(24);
				return var1.image;
			case 25 :
				var1 = this.jj_consume_token(25);
				return var1.image;
			default :
				this.jj_la1[9] = this.jj_gen;
				this.jj_consume_token(-1);
				throw new ParseException();
		}
	}

	private final boolean jj_2_1(int var1) {
		this.jj_la = var1;
		this.jj_lastpos = this.jj_scanpos = this.token;

		boolean var3;
		try {
			boolean var2 = !this.jj_3_1();
			return var2;
		} catch (LookaheadSuccess var7) {
			var3 = true;
		} finally {
			this.jj_save(0, var1);
		}

		return var3;
	}

	private final boolean jj_2_2(int var1) {
		this.jj_la = var1;
		this.jj_lastpos = this.jj_scanpos = this.token;

		boolean var3;
		try {
			boolean var2 = !this.jj_3_2();
			return var2;
		} catch (LookaheadSuccess var7) {
			var3 = true;
		} finally {
			this.jj_save(1, var1);
		}

		return var3;
	}

	private final boolean jj_2_3(int var1) {
		this.jj_la = var1;
		this.jj_lastpos = this.jj_scanpos = this.token;

		boolean var3;
		try {
			boolean var2 = !this.jj_3_3();
			return var2;
		} catch (LookaheadSuccess var7) {
			var3 = true;
		} finally {
			this.jj_save(2, var1);
		}

		return var3;
	}

	private final boolean jj_2_4(int var1) {
		this.jj_la = var1;
		this.jj_lastpos = this.jj_scanpos = this.token;

		boolean var3;
		try {
			boolean var2 = !this.jj_3_4();
			return var2;
		} catch (LookaheadSuccess var7) {
			var3 = true;
		} finally {
			this.jj_save(3, var1);
		}

		return var3;
	}

	private final boolean jj_2_5(int var1) {
		this.jj_la = var1;
		this.jj_lastpos = this.jj_scanpos = this.token;

		boolean var3;
		try {
			boolean var2 = !this.jj_3_5();
			return var2;
		} catch (LookaheadSuccess var7) {
			var3 = true;
		} finally {
			this.jj_save(4, var1);
		}

		return var3;
	}

	private final boolean jj_3R_18() {
		if (this.jj_3R_19()) {
			return true;
		} else if (this.jj_scan_token(22)) {
			return true;
		} else {
			return this.jj_3R_23();
		}
	}

	private final boolean jj_3R_12() {
		if (this.jj_scan_token(7)) {
			return true;
		} else if (this.jj_scan_token(22)) {
			return true;
		} else {
			return this.jj_scan_token(23);
		}
	}

	private final boolean jj_3R_17() {
		if (this.jj_scan_token(6)) {
			return true;
		} else {
			return this.jj_3R_12();
		}
	}

	private final boolean jj_3R_22() {
		return this.jj_scan_token(13);
	}

	private final boolean jj_3_5() {
		if (this.jj_scan_token(1)) {
			return true;
		} else {
			return this.jj_3R_8();
		}
	}

	private final boolean jj_3R_8() {
		if (this.jj_3R_11()) {
			return true;
		} else {
			Token var1;
			do {
				var1 = this.jj_scanpos;
			} while (!this.jj_3_3());

			this.jj_scanpos = var1;
			return false;
		}
	}

	private final boolean jj_3_1() {
		return this.jj_3R_6();
	}

	private final boolean jj_3R_26() {
		return this.jj_scan_token(25);
	}

	private final boolean jj_3R_21() {
		return this.jj_scan_token(14);
	}

	private final boolean jj_3R_20() {
		Token var1 = this.jj_scanpos;
		if (this.jj_3R_21()) {
			this.jj_scanpos = var1;
			if (this.jj_3R_22()) {
				return true;
			}
		}

		return false;
	}

	private final boolean jj_3R_25() {
		return this.jj_scan_token(24);
	}

	private final boolean jj_3R_19() {
		Token var1 = this.jj_scanpos;
		if (this.jj_scan_token(21)) {
			this.jj_scanpos = var1;
		}

		return this.jj_3R_20();
	}

	private final boolean jj_3R_14() {
		if (this.jj_3R_12()) {
			return true;
		} else {
			Token var1;
			do {
				var1 = this.jj_scanpos;
			} while (!this.jj_3R_17());

			this.jj_scanpos = var1;
			return false;
		}
	}

	private final boolean jj_3R_13() {
		return this.jj_3R_8();
	}

	private final boolean jj_3R_24() {
		return this.jj_scan_token(23);
	}

	private final boolean jj_3R_23() {
		Token var1 = this.jj_scanpos;
		if (this.jj_3R_24()) {
			this.jj_scanpos = var1;
			if (this.jj_3R_25()) {
				this.jj_scanpos = var1;
				if (this.jj_3R_26()) {
					return true;
				}
			}
		}

		return false;
	}

	private final boolean jj_3R_6() {
		if (this.jj_scan_token(4)) {
			return true;
		} else if (this.jj_3R_7()) {
			return true;
		} else {
			return this.jj_scan_token(5);
		}
	}

	private final boolean jj_3R_16() {
		if (this.jj_3R_18()) {
			return true;
		} else {
			Token var1;
			do {
				var1 = this.jj_scanpos;
			} while (!this.jj_3_5());

			this.jj_scanpos = var1;
			return false;
		}
	}

	private final boolean jj_3_2() {
		return this.jj_3R_7();
	}

	private final boolean jj_3_4() {
		if (this.jj_scan_token(1)) {
			return true;
		} else {
			return this.jj_3R_8();
		}
	}

	private final boolean jj_3R_10() {
		if (this.jj_scan_token(2)) {
			return true;
		} else if (this.jj_3R_14()) {
			return true;
		} else if (this.jj_scan_token(3)) {
			return true;
		} else if (this.jj_scan_token(1)) {
			return true;
		} else {
			return this.jj_3R_13();
		}
	}

	private final boolean jj_3R_7() {
		Token var1 = this.jj_scanpos;
		if (this.jj_3R_9()) {
			this.jj_scanpos = var1;
			if (this.jj_3R_10()) {
				return true;
			}
		}

		return false;
	}

	private final boolean jj_3R_9() {
		if (this.jj_3R_12()) {
			return true;
		} else if (this.jj_scan_token(1)) {
			return true;
		} else {
			return this.jj_3R_13();
		}
	}

	private final boolean jj_3R_11() {
		Token var1 = this.jj_scanpos;
		if (this.jj_3R_15()) {
			this.jj_scanpos = var1;
			if (this.jj_3R_16()) {
				return true;
			}
		}

		return false;
	}

	private final boolean jj_3R_15() {
		if (this.jj_scan_token(2)) {
			return true;
		} else if (this.jj_3R_8()) {
			return true;
		} else if (this.jj_scan_token(3)) {
			return true;
		} else {
			Token var1;
			do {
				var1 = this.jj_scanpos;
			} while (!this.jj_3_4());

			this.jj_scanpos = var1;
			return false;
		}
	}

	private final boolean jj_3_3() {
		if (this.jj_scan_token(6)) {
			return true;
		} else {
			return this.jj_3R_8();
		}
	}

	private static void jj_la1_0() {
		jj_la1_0 = new int[]{16, 128, -2147483516, 132, 64, 64, 2121732, 24576, 2097152, 58720256};
	}

	private static void jj_la1_1() {
		jj_la1_1 = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	}

	public WIMXPathInterpreter(InputStream var1) {
		this.jj_input_stream = new SimpleCharStream(var1, 1, 1, 1024);
		this.token_source = new WIMXPathInterpreterTokenManager(this.jj_input_stream);
		this.token = new Token();
		this.jj_ntk = -1;
		this.jj_gen = 0;

		int var2;
		for (var2 = 0; var2 < 10; ++var2) {
			this.jj_la1[var2] = -1;
		}

		for (var2 = 0; var2 < this.jj_2_rtns.length; ++var2) {
			this.jj_2_rtns[var2] = new JJCalls();
		}

	}

	public void ReInit(InputStream var1) {
		this.jj_input_stream.ReInit(var1, 1, 1, 1024);
		this.token_source.ReInit(this.jj_input_stream);
		this.token = new Token();
		this.jj_ntk = -1;
		this.jj_gen = 0;

		int var2;
		for (var2 = 0; var2 < 10; ++var2) {
			this.jj_la1[var2] = -1;
		}

		for (var2 = 0; var2 < this.jj_2_rtns.length; ++var2) {
			this.jj_2_rtns[var2] = new JJCalls();
		}

	}

	public WIMXPathInterpreter(Reader var1) {
		this.jj_input_stream = new SimpleCharStream(var1, 1, 1, 1024);
		this.token_source = new WIMXPathInterpreterTokenManager(this.jj_input_stream);
		this.token = new Token();
		this.jj_ntk = -1;
		this.jj_gen = 0;

		int var2;
		for (var2 = 0; var2 < 10; ++var2) {
			this.jj_la1[var2] = -1;
		}

		for (var2 = 0; var2 < this.jj_2_rtns.length; ++var2) {
			this.jj_2_rtns[var2] = new JJCalls();
		}

	}

	public void ReInit(Reader var1) {
		this.jj_input_stream.ReInit(var1, 1, 1, 1024);
		this.token_source.ReInit(this.jj_input_stream);
		this.token = new Token();
		this.jj_ntk = -1;
		this.jj_gen = 0;

		int var2;
		for (var2 = 0; var2 < 10; ++var2) {
			this.jj_la1[var2] = -1;
		}

		for (var2 = 0; var2 < this.jj_2_rtns.length; ++var2) {
			this.jj_2_rtns[var2] = new JJCalls();
		}

	}

	public WIMXPathInterpreter(WIMXPathInterpreterTokenManager var1) {
		this.token_source = var1;
		this.token = new Token();
		this.jj_ntk = -1;
		this.jj_gen = 0;

		int var2;
		for (var2 = 0; var2 < 10; ++var2) {
			this.jj_la1[var2] = -1;
		}

		for (var2 = 0; var2 < this.jj_2_rtns.length; ++var2) {
			this.jj_2_rtns[var2] = new JJCalls();
		}

	}

	public void ReInit(WIMXPathInterpreterTokenManager var1) {
		this.token_source = var1;
		this.token = new Token();
		this.jj_ntk = -1;
		this.jj_gen = 0;

		int var2;
		for (var2 = 0; var2 < 10; ++var2) {
			this.jj_la1[var2] = -1;
		}

		for (var2 = 0; var2 < this.jj_2_rtns.length; ++var2) {
			this.jj_2_rtns[var2] = new JJCalls();
		}

	}

	private final Token jj_consume_token(int var1) throws ParseException {
		Token var2 = this.token;
		if (this.token.next != null) {
			this.token = this.token.next;
		} else {
			this.token = this.token.next = this.token_source.getNextToken();
		}

		this.jj_ntk = -1;
		if (this.token.kind != var1) {
			this.token = var2;
			this.jj_kind = var1;
			throw this.generateParseException();
		} else {
			++this.jj_gen;
			if (++this.jj_gc > 100) {
				this.jj_gc = 0;

				for (int var3 = 0; var3 < this.jj_2_rtns.length; ++var3) {
					for (JJCalls var4 = this.jj_2_rtns[var3]; var4 != null; var4 = var4.next) {
						if (var4.gen < this.jj_gen) {
							var4.first = null;
						}
					}
				}
			}

			return this.token;
		}
	}

	private final boolean jj_scan_token(int var1) {
		if (this.jj_scanpos == this.jj_lastpos) {
			--this.jj_la;
			if (this.jj_scanpos.next == null) {
				this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken();
			} else {
				this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next;
			}
		} else {
			this.jj_scanpos = this.jj_scanpos.next;
		}

		if (this.jj_rescan) {
			int var2 = 0;

			Token var3;
			for (var3 = this.token; var3 != null && var3 != this.jj_scanpos; var3 = var3.next) {
				++var2;
			}

			if (var3 != null) {
				this.jj_add_error_token(var1, var2);
			}
		}

		if (this.jj_scanpos.kind != var1) {
			return true;
		} else if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) {
			throw this.jj_ls;
		} else {
			return false;
		}
	}

	public final Token getNextToken() {
		if (this.token.next != null) {
			this.token = this.token.next;
		} else {
			this.token = this.token.next = this.token_source.getNextToken();
		}

		this.jj_ntk = -1;
		++this.jj_gen;
		return this.token;
	}

	public final Token getToken(int var1) {
		Token var2 = this.lookingAhead ? this.jj_scanpos : this.token;

		for (int var3 = 0; var3 < var1; ++var3) {
			if (var2.next != null) {
				var2 = var2.next;
			} else {
				var2 = var2.next = this.token_source.getNextToken();
			}
		}

		return var2;
	}

	private final int jj_ntk() {
		return (this.jj_nt = this.token.next) == null
				? (this.jj_ntk = (this.token.next = this.token_source.getNextToken()).kind)
				: (this.jj_ntk = this.jj_nt.kind);
	}

	private void jj_add_error_token(int var1, int var2) {
		if (var2 < 100) {
			if (var2 == this.jj_endpos + 1) {
				this.jj_lasttokens[this.jj_endpos++] = var1;
			} else if (this.jj_endpos != 0) {
				this.jj_expentry = new int[this.jj_endpos];

				for (int var3 = 0; var3 < this.jj_endpos; ++var3) {
					this.jj_expentry[var3] = this.jj_lasttokens[var3];
				}

				boolean var7 = false;
				Enumeration var4 = this.jj_expentries.elements();

				label48 : do {
					int[] var5;
					do {
						if (!var4.hasMoreElements()) {
							break label48;
						}

						var5 = (int[]) ((int[]) var4.nextElement());
					} while (var5.length != this.jj_expentry.length);

					var7 = true;

					for (int var6 = 0; var6 < this.jj_expentry.length; ++var6) {
						if (var5[var6] != this.jj_expentry[var6]) {
							var7 = false;
							break;
						}
					}
				} while (!var7);

				if (!var7) {
					this.jj_expentries.addElement(this.jj_expentry);
				}

				if (var2 != 0) {
					this.jj_lasttokens[(this.jj_endpos = var2) - 1] = var1;
				}
			}

		}
	}

	public ParseException generateParseException() {
		this.jj_expentries.removeAllElements();
		boolean[] var1 = new boolean[40];

		int var2;
		for (var2 = 0; var2 < 40; ++var2) {
			var1[var2] = false;
		}

		if (this.jj_kind >= 0) {
			var1[this.jj_kind] = true;
			this.jj_kind = -1;
		}

		int var3;
		for (var2 = 0; var2 < 10; ++var2) {
			if (this.jj_la1[var2] == this.jj_gen) {
				for (var3 = 0; var3 < 32; ++var3) {
					if ((jj_la1_0[var2] & 1 << var3) != 0) {
						var1[var3] = true;
					}

					if ((jj_la1_1[var2] & 1 << var3) != 0) {
						var1[32 + var3] = true;
					}
				}
			}
		}

		for (var2 = 0; var2 < 40; ++var2) {
			if (var1[var2]) {
				this.jj_expentry = new int[1];
				this.jj_expentry[0] = var2;
				this.jj_expentries.addElement(this.jj_expentry);
			}
		}

		this.jj_endpos = 0;
		this.jj_rescan_token();
		this.jj_add_error_token(0, 0);
		int[][] var4 = new int[this.jj_expentries.size()][];

		for (var3 = 0; var3 < this.jj_expentries.size(); ++var3) {
			var4[var3] = (int[]) ((int[]) this.jj_expentries.elementAt(var3));
		}

		return new ParseException(this.token, var4, tokenImage);
	}

	public final void enable_tracing() {
	}

	public final void disable_tracing() {
	}

	private final void jj_rescan_token() {
		this.jj_rescan = true;

		for (int var1 = 0; var1 < 5; ++var1) {
			JJCalls var2 = this.jj_2_rtns[var1];

			do {
				if (var2.gen > this.jj_gen) {
					this.jj_la = var2.arg;
					this.jj_lastpos = this.jj_scanpos = var2.first;
					switch (var1) {
						case 0 :
							this.jj_3_1();
							break;
						case 1 :
							this.jj_3_2();
							break;
						case 2 :
							this.jj_3_3();
							break;
						case 3 :
							this.jj_3_4();
							break;
						case 4 :
							this.jj_3_5();
					}
				}

				var2 = var2.next;
			} while (var2 != null);
		}

		this.jj_rescan = false;
	}

	private final void jj_save(int var1, int var2) {
		JJCalls var3;
		for (var3 = this.jj_2_rtns[var1]; var3.gen > this.jj_gen; var3 = var3.next) {
			if (var3.next == null) {
				var3 = var3.next = new JJCalls();
				break;
			}
		}

		var3.gen = this.jj_gen + var2 - this.jj_la;
		var3.first = this.token;
		var3.arg = var2;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		jj_la1_0();
		jj_la1_1();
	}
}