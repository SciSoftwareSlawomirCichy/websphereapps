package com.ibm.ejs.csi;

import com.ibm.ejs.models.base.extensions.commonext.globaltran.GlobalTransaction;
import com.ibm.ejs.models.base.extensions.ejbext.EnterpriseBeanExtension;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;

public class GlobalTranConfigDataImpl extends BasicGlobalTranConfigDataImpl {
	private static final TraceComponent tc = Tr.register(GlobalTranConfigDataImpl.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public GlobalTranConfigDataImpl() {
	}

	public GlobalTranConfigDataImpl(EnterpriseBeanExtension ebx) {
		if (ebx != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "CTOR was passed non-null EnterpriseBeanExtension object for config data");
			}

			GlobalTransaction globalTransaction = ebx.getGlobalTransaction();
			if (globalTransaction != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "We have a globlTransaction object, so use the 5.0 or later config data");
				}

				this.init(globalTransaction);
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "CTOR was passed a null EnterpriseBeanExtension object for config data");
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "CTOR was passed a null EnterpriseBeanExtension object, using default values for config data");
		}

	}

	public GlobalTranConfigDataImpl(GlobalTransaction gtx) {
		this.init(gtx);
	}

	private void init(GlobalTransaction gtx) {
		if (gtx != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "init was passed non-null GlobalTransaction object for config data");
			}

			this.timeout = gtx.getComponentTransactionTimeout();
			this.isSendWSAT = gtx.isSendWSAT();
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "init was passed a null GlobalTransaction object, using default values for config data");
		}

	}
}