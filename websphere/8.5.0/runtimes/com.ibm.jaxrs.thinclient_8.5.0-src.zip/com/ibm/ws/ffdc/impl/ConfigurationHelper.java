package com.ibm.ws.ffdc.impl;

import com.ibm.ffdc.util.provider.FfdcProviderDependent;
import com.ibm.websphere.runtime.ServerName;
import com.ibm.ws.bootstrap.WSLauncher;
import com.ibm.ws.exception.WsException;
import com.ibm.ws.ffdc.FFDC;
import com.ibm.ws.ffdc.impl.ConfigurationHelper.1;
import com.ibm.ws.ffdc.impl.ConfigurationHelper.2;
import com.ibm.ws.ffdc.impl.ConfigurationHelper.3;
import com.ibm.ws.ffdc.impl.ConfigurationHelper.4;
import com.ibm.ws.ffdc.impl.ConfigurationHelper.SvcException;
import com.ibm.ws.runtime.service.Server;
import com.ibm.ws.runtime.service.ThreadPoolMgr;
import com.ibm.ws.runtime.service.VariableMap;
import com.ibm.ws.util.ThreadPool;
import com.ibm.ws.util.ThreadPoolListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.security.AccessController;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConfigurationHelper extends FfdcProviderDependent<FfdcProvider>
		implements
			PropertyChangeListener,
			ThreadPoolListener {
	private static final String thisClass = ConfigurationHelper.class.getName();
	private static final Logger LOGGER;
	static final String FFDC_LOG = "com.ibm.ffdc.log";
	static final String FFDC_LOG_ENV = "com_ibm_ffdc_log";
	public static boolean isLegacyFFDCInitialized;

	protected ConfigurationHelper(FfdcProvider provider) {
		super(provider);
		this.initialize();
	}

	public synchronized void initialize() {
      if (!isLegacyFFDCInitialized) {
         isLegacyFFDCInitialized = true;

         String serviceLogDir;
         try {
            Server server = (Server)this.getService(Server.class);
            server.addPropertyChangeListener("state", this);
            String serverName = server.getName();
            serviceLogDir = server.getCellName() + '_' + server.getNodeName() + '_' + serverName;
            FFDC.setServerName(serverName, serviceLogDir);
            FFDC.setServer();
         } catch (SvcException var9) {
            var9.report();
         } catch (Throwable var10) {
            this.ffdcerror(var10);
         }

         try {
            ThreadPoolMgr tpm = (ThreadPoolMgr)this.getService(ThreadPoolMgr.class);
            if (tpm != null) {
               tpm.addThreadPoolListener(this);
            }
         } catch (SvcException var7) {
            var7.report();
         } catch (Throwable var8) {
            this.ffdcerror(var8);
         }

         try {
            String log = (String)AccessController.doPrivileged(new 1(this));
            if (log != null) {
               FFDC.setLogRoot(log);
            } else {
               VariableMap vMap = (VariableMap)this.getService(VariableMap.class);
               if (vMap != null) {
                  serviceLogDir = vMap.expand("${LOG_ROOT}");
                  FFDC.setLogRoot(serviceLogDir);
               }
            }
         } catch (SvcException var5) {
            var5.report();
         } catch (Throwable var6) {
            this.ffdcerror(var6);
         }

         try {
            if (WSLauncher.isZOS()) {
               FFDC.setZos(true);
               FFDC.setzOSjobAttributes(ServerName.getjsabjbid(), ServerName.getjsabjbnm().trim(), ServerName.getPrintableStoken());
            }
         } catch (Throwable var4) {
            this.ffdcerror(var4);
         }

      }
   }

	private <T> T getService(Class<T> cl) throws ClassCastException, SvcException {
      try {
         T service = AccessController.doPrivileged(new 2(this, cl));
         return service;
      } catch (ClassCastException var3) {
         throw var3;
      } catch (Exception var4) {
         throw new SvcException(var4, cl);
      }
   }

	public void propertyChange(PropertyChangeEvent pce) {
		if (pce.getNewValue().equals("STARTED")) {
			FFDC.setState(2);
		} else if (pce.getNewValue().equals("STOPPING")) {
			FFDC.setState(3);
		}

	}

	public void destroy() {
	}

	public void threadPoolCreated(ThreadPool tp) {
	}

	public void threadCreated(ThreadPool tp, int poolSize) {
	}

	public void threadStarted(ThreadPool tp, int activeThreads, int maxThreads) {
	}

	public void threadReturned(ThreadPool tp, int activeThreads, int maxThreads) {
		try {
			FFDC.resetThread();
		} catch (Throwable var5) {
			this.ffdcerror(var5);
		}

	}

	public void threadDestroyed(ThreadPool tp, int poolSize) {
		try {
			FFDC.resetThread();
		} catch (Throwable var4) {
			this.ffdcerror(var4);
		}

	}

	protected Configure getConfiguration() {
		if (!isLegacyFFDCInitialized) {
			this.initialize();
		}

		return FFDC.getConfiguration();
	}

	protected boolean hasPermissionForLogging() {
		if (!isLegacyFFDCInitialized) {
			this.initialize();
		}

		return FFDC.hasPermissionForLogging();
	}

	public WrappingFileOutputStream getIncidentSummaryStream() throws WsException, IOException {
		int maxValue = 1048576;
		Configure cfg = this.getConfiguration();
		int filesize = cfg == null ? 0 : cfg.exceptionFileSize;
		int filenum = cfg == null ? 0 : cfg.exceptionFileBackup;
		if (filesize > 1048576) {
			filesize = 1048576;
		}

		int openFileSize = filesize * 1024;
		if (openFileSize < 0) {
			openFileSize = 1048576;
		}

		String exceptionFileName = getIncidentSummaryFileName();
		this.renameExceptionFileIfExists(exceptionFileName);
		return new WrappingFileOutputStream(exceptionFileName, openFileSize, filenum);
	}

	public int getFfdcSize() {
		int maxValue = 104857600;
		int minValue = true;
		Configure cfg = this.getConfiguration();
		int filesize = cfg == null ? 0 : cfg.introspectMaxSize * 1024;
		if (filesize > 104857600) {
			filesize = 104857600;
		}

		if (filesize < 10240) {
			filesize = 10240;
		}

		return filesize;
	}

	private void renameExceptionFileIfExists(String exceptionFileName) {
      File tFile = new File(exceptionFileName);
      Boolean fileExist = null;

      try {
         fileExist = (Boolean)AccessController.doPrivileged(new 3(this, tFile));
      } catch (Exception var10) {
         System.err.println("Failure to check file existence: " + var10);
      }

      if (fileExist) {
         long milliHolder = System.currentTimeMillis();
         String backupname = exceptionFileName + "." + milliHolder + FFDC.getExceptionFileExtension();
         File backupFile = new File(backupname);
         if (LOGGER.isLoggable(Level.FINE)) {
            LOGGER.logp(Level.FINE, thisClass, "getIncidentSummaryStream", "Old SummaryFile existed, renaming it to: " + exceptionFileName + "." + milliHolder + FFDC.getExceptionFileExtension());
         }

         try {
            AccessController.doPrivileged(new 4(this, tFile, backupFile));
         } catch (Exception var9) {
            System.err.println("Failure to roll old exception Summary: " + var9);
         }

      }
   }

	private static String getIncidentSummaryFileName() throws WsException {
		String fileName = "exception";
		String serverName = FFDCHelper.getServerName();
		if (serverName == null || serverName.length() == 0) {
			serverName = "serverName";
		}

		String baseDir = FFDCHelper.getDefaultLoggingDirectory();
		StringBuffer sb = new StringBuffer(64);
		sb.append(baseDir);
		sb.append(File.separatorChar);
		sb.append(serverName);
		sb.append('_');
		sb.append(fileName);
		if (FFDC.isZos()) {
			String jobName = FFDC.getzOSjobName();
			String startedTaskId = FFDC.getzOSjobNumber();
			if (jobName != null && !jobName.equals("")) {
				sb.append("_" + jobName);
			}

			if (startedTaskId != null && !startedTaskId.equals("")) {
				sb.append("_" + startedTaskId);
			}
		}

		sb.append(FFDC.getExceptionIndexFileNameExtension());
		return new String(sb);
	}

	static {
		LOGGER = Logger.getLogger(thisClass, "com.ibm.ws.ffdc.resources.FFDCMessages");
		isLegacyFFDCInitialized = false;
	}
}