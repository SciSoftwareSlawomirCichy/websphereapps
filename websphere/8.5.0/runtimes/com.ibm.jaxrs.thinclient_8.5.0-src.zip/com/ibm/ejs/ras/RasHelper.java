package com.ibm.ejs.ras;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.LogRecord;

public class RasHelper {
	public static final String $sccsid = "@(#) 1.3 SERV1/ws/code/ras.lite/src/com/ibm/ejs/ras/RasHelper.java, WAS.ras.lite, WAS855.SERV1, cf051506.04 07/08/30 15:32:50 [2/19/15 14:14:30]";

	public static boolean isServer() {
		return false;
	}

	public static String getThreadId() {
		return getThreadId(new LogRecord(Level.FINE, ""));
	}

	public static String getThreadId(LogRecord logRecord) {
		StringBuffer buffer = new StringBuffer(16);
		String tid = Integer.toHexString(logRecord.getThreadID());
		int length = tid.length();

		for (int i = length; i < 8; ++i) {
			buffer.append('0');
		}

		return buffer.append(tid).toString();
	}

	public static String getVersionId() {
		return "";
	}

	public static String getServerName() {
		return "";
	}

	public static String getProcessId() {
		return "";
	}

	public static final String throwableToString(Throwable t) {
		StringWriter s = new StringWriter();
		PrintWriter p = new PrintWriter(s);
		if (t == null) {
			p.println("none");
		} else {
			t.printStackTrace(p);
		}

		return s.toString();
	}
}