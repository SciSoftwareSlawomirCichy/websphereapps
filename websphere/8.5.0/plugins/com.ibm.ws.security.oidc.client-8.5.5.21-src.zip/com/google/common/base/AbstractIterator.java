package com.google.common.base;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.AbstractIterator.1;
import com.google.common.base.AbstractIterator.State;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
abstract class AbstractIterator<T> implements Iterator<T> {
	private State state;
	@NullableDecl
	private T next;

	protected AbstractIterator() {
		this.state = State.NOT_READY;
	}

	protected abstract T computeNext();

	@NullableDecl
	@CanIgnoreReturnValue
	protected final T endOfData() {
		this.state = State.DONE;
		return null;
	}

	public final boolean hasNext() {
      Preconditions.checkState(this.state != State.FAILED);
      switch(1.$SwitchMap$com$google$common$base$AbstractIterator$State[this.state.ordinal()]) {
      case 1:
         return true;
      case 2:
         return false;
      default:
         return this.tryToComputeNext();
      }
   }

	private boolean tryToComputeNext() {
		this.state = State.FAILED;
		this.next = this.computeNext();
		if (this.state != State.DONE) {
			this.state = State.READY;
			return true;
		} else {
			return false;
		}
	}

	public final T next() {
		if (!this.hasNext()) {
			throw new NoSuchElementException();
		} else {
			this.state = State.NOT_READY;
			T result = this.next;
			this.next = null;
			return result;
		}
	}

	public final void remove() {
		throw new UnsupportedOperationException();
	}
}