package com.ibm.ws.security.openid20.client;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.openid20.util.DynaCacheUtils;
import com.ibm.ws.security.openid20.util.MessageHelper;
import com.ibm.ws.security.openid20.util.OidUtil;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.security.auth.Subject;

public enum RequestCache {
	CACHE;

	private static final TraceComponent tc = Tr.register(RequestCache.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private int maxCacheSize;
	private long cacheCleanupFrequency;
	private long lastCleanupTime = 0L;
	private boolean dynamicCacheEnabled = false;
	private boolean cacheInitialized = false;
	private String jndiCacheName = null;
	private Map cache = null;

	public void init(OpenIDClientConfig config) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "init(config[" + OidUtil.getObjState(config) + "])");
		}

		this.maxCacheSize = config.getMaxDiscoveryCacheSize();
		this.cacheCleanupFrequency = config.getCacheCleanupFrequency();
		this.jndiCacheName = config.getJNDICacheName();
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "init returns");
		}

	}

	private void initCache() {
		if (!this.cacheInitialized) {
			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "initCache");
			}

			this.cache = DynaCacheUtils.init(this.maxCacheSize, this.jndiCacheName);
			this.dynamicCacheEnabled = DynaCacheUtils.isDynamicCacheEnabled();
			if (this.cache != null) {
				this.cacheInitialized = true;
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "initCache");
			}

		}
	}

	public synchronized void put(String key, RequestData value) throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "put(key[" + key + "],value[" + OidUtil.getObjState(value) + "])");
		}

		this.initCache();
		if (this.cache.size() >= this.maxCacheSize) {
			String msg = MessageHelper.getMessage("security.openid20.client.maxcachesizereached");
			Tr.error(tc, msg);
			throw new OpenIDRelyingPartyException(msg);
		} else {
			this.cache.put(key, value);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "put returns");
			}

		}
	}

	public synchronized void update(String key, Subject subject, String username) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "put(key[" + key + "],value[" + OidUtil.getObjState(subject) + "]username[" + username + "])");
		}

		RequestData rData = this.get(key);
		rData.setSubject(subject);
		rData.setUserName(username);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "put returns");
		}

	}

	public RequestData get(String key) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "get(key[" + key + "])");
		}

		this.initCache();
		RequestData rData = (RequestData) this.cache.get(key);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "get returns [" + OidUtil.getObjState(rData) + "]");
		}

		return rData;
	}

	public void purge(String key) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "purge(key[" + key + "])");
		}

		this.initCache();
		RequestData rData = (RequestData) this.cache.get(key);
		rData.purge();
		this.cache.remove(key);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "purge returns");
		}

	}

	synchronized void cleanup() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "cleanup()");
		}

		this.initCache();
		if (this.dynamicCacheEnabled) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Dynamic cache is enabled.  Cleanup is handled by DynaCache. No action required.");
			}
		} else {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Dynamic cache is not enabled.  Proceeding to cleanup local cache.");
			}

			Long currentTime = System.currentTimeMillis();
			Long cleanupTime = this.lastCleanupTime + this.cacheCleanupFrequency * 1000L;
			if (currentTime > cleanupTime) {
				Set<String> keys = this.cache.keySet();
				Iterator i$ = keys.iterator();

				while (i$.hasNext()) {
					String key = (String) i$.next();
					RequestData rd = (RequestData) this.cache.get(key);
					if (rd.getCreationTime() + 3600000L < currentTime) {
						rd.purge();
						this.cache.remove(key);
					}
				}

				this.lastCleanupTime = currentTime;
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "cleanup");
		}

	}
}