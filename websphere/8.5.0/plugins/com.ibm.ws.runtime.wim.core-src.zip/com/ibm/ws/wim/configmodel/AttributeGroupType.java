package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface AttributeGroupType {
	String getGroupName();

	void setGroupName(String var1);

	List getAttributeNames();

	String[] getAttributeNamesAsArray();
}