package com.ibm.ws.wim.xpath.mapping.datatype;

import java.util.HashMap;
import java.util.Iterator;

public class ParenthesisNode implements XPathParenthesisNode {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private Object child = null;
	boolean inRepos = true;

	public void setChild(Object var1) {
		this.child = var1;
	}

	public Object getChild() {
		return this.child;
	}

	public short getNodeType() {
		return 2;
	}

	public Iterator getPropertyNodes(HashMap var1) {
		HashMap var2 = var1;
		if (var1 == null) {
			var2 = new HashMap();
		}

		return ((XPathNode) this.child).getPropertyNodes(var2);
	}

	public void setPropertyLocation(boolean var1) {
		this.inRepos = var1;
	}

	public boolean isPropertyInRepository() {
		return this.inRepos;
	}

	public String toString() {
		StringBuffer var1 = new StringBuffer();
		var1 = var1.append("(" + this.child.toString() + ")");
		return var1.toString();
	}
}