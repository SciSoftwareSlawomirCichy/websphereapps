package com.ibm.ws.wim.configmodel;

public interface FileRepositoryType extends ProfileRepositoryType {
	String getBaseDirectory();

	void setBaseDirectory(String var1);

	boolean isCaseSensitive();

	void setCaseSensitive(boolean var1);

	void unsetCaseSensitive();

	boolean isSetCaseSensitive();

	String getFileName();

	void setFileName(String var1);

	String getMessageDigestAlgorithm();

	void setMessageDigestAlgorithm(String var1);

	void unsetMessageDigestAlgorithm();

	boolean isSetMessageDigestAlgorithm();

	int getSaltLength();

	void setSaltLength(int var1);

	void unsetSaltLength();

	boolean isSetSaltLength();

	int getKeyLength();

	void setKeyLength(int var1);

	void unsetKeyLength();

	boolean isSetKeyLength();

	int getHashIterations();

	void setHashIterations(int var1);

	void unsetHashIterations();

	boolean isSetHashIterations();

	int getAccountLockoutThreshold();

	void setAccountLockoutThreshold(int var1);

	void unsetAccountLockoutThreshold();

	boolean isSetAccountLockoutThreshold();

	int getAccountLockoutDuration();

	void setAccountLockoutDuration(int var1);

	void unsetAccountLockoutDuration();

	boolean isSetAccountLockoutDuration();

	int getIgnoreFailedLoginAfter();

	void setIgnoreFailedLoginAfter(int var1);

	void unsetIgnoreFailedLoginAfter();

	boolean isSetIgnoreFailedLoginAfter();
}