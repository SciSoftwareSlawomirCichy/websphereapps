package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.ws.ejbcontainer.mdb.BaseMessageEndpointFactory;
import com.ibm.ws.j2c.MessageEndpointFactory;
import com.ibm.ws.j2c.RALifeCycleManager;
import com.ibm.ws.j2c.RALifeCycleManagerFactory;
import com.ibm.ws.j2c.MessageEndpointFactory.JCAVersion;
import java.rmi.RemoteException;
import javax.resource.ResourceException;

public class MessageEndpointFactoryImpl extends BaseMessageEndpointFactory implements MessageEndpointFactory {
	private static final long serialVersionUID = 6055819285757596987L;
	private static final String CLASS_NAME = MessageEndpointFactoryImpl.class.getName();
	private static final TraceComponent tc;
	private String ivDeactivationKey = null;

	public MessageEndpointFactoryImpl() throws RemoteException {
	}

	public void activateEndpoint() throws ResourceException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "MEF.activateEndpoint for enterprise class " + this.beanMetaData.enterpriseBeanName);
		}

		ResourceException ex = null;
		RALifeCycleManager r = RALifeCycleManagerFactory.getInstance();
		String deactivationKey = null;
		Thread currentThread = Thread.currentThread();
		EJBThreadData threadData = EJSContainer.getThreadData();
		threadData.pushMetaDataContexts(this.beanMetaData);

		try {
			Object var8;
			try {
				Object var7 = this.ivStateLock;
				synchronized (this.ivStateLock) {
					if (this.ivState == 0) {
						this.ivState = 1;
						this.ivActivatingThread = currentThread;
					} else if (this.ivState == 2) {
						r = null;
					} else {
						r = null;
						ex = new ResourceException("can not activate until deactivate completes");
					}
				}

				if (r != null) {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc,
								"MEF calling activateEndpoint(" + this.beanMetaData.ivActivationSpecJndiName + ", "
										+ Util.identity(this) + ", " + this.beanMetaData.j2eeName + ", "
										+ this.beanMetaData.ivActivationSpecAuthAlias + ", "
										+ this.beanMetaData.ivMessageDestinationJndiName + ")");
					}

					deactivationKey = r.activateEndpoint(this.beanMetaData.ivActivationSpecJndiName, this,
							this.beanMetaData.ivActivationConfig, this.beanMetaData.j2eeName,
							this.beanMetaData.ivActivationSpecAuthAlias,
							this.beanMetaData.ivMessageDestinationJndiName);
					var7 = this.ivStateLock;
					synchronized (this.ivStateLock) {
						this.ivDeactivationKey = deactivationKey;
					}
				}
			} catch (ResourceException var24) {
				var8 = this.ivStateLock;
				synchronized (this.ivStateLock) {
					this.ivState = 0;
				}

				ex = var24;
			} catch (Throwable var25) {
				var8 = this.ivStateLock;
				synchronized (this.ivStateLock) {
					this.ivState = 0;
				}

				ex = new ResourceException(var25);
			}
		} finally {
			threadData.popMetaDataContexts();
		}

		this.beanMetaData.ivActivationConfig = null;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "MEF.activateEndpoint for enterprise class " + this.beanMetaData.enterpriseBeanName);
		}

		if (ex != null) {
			throw ex;
		}
	}

	public void deactivateEndpoint() throws ResourceException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "MEF.deactivateEndpoint for enterprise class " + this.beanMetaData.enterpriseBeanName);
		}

		RALifeCycleManager r = RALifeCycleManagerFactory.getInstance();
		String deactivationKey = null;
		Object var4 = this.ivStateLock;
		synchronized (this.ivStateLock) {
			if (this.ivState != 2 && this.ivState != 4) {
				if (this.ivState != 0) {
					throw new ResourceException("illegal state for deactivate");
				}
			} else {
				this.ivState = 3;
				deactivationKey = this.ivDeactivationKey;
				if (deactivationKey == null) {
					this.ivState = 0;
				}
			}
		}

		if (deactivationKey != null) {
			EJBThreadData threadData = EJSContainer.getThreadData();
			threadData.pushMetaDataContexts(this.beanMetaData);
			boolean var14 = false;

			try {
				var14 = true;
				r.deactivateEndPoint(deactivationKey);
				var14 = false;
			} finally {
				if (var14) {
					threadData.popMetaDataContexts();
					Object var8 = this.ivStateLock;
					synchronized (this.ivStateLock) {
						this.ivState = 0;
						this.ivDeactivationKey = null;
					}
				}
			}

			threadData.popMetaDataContexts();
			Object var5 = this.ivStateLock;
			synchronized (this.ivStateLock) {
				this.ivState = 0;
				this.ivDeactivationKey = null;
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "MEF.deactivateEndpoint for enterprise class " + this.beanMetaData.enterpriseBeanName);
		}

	}

	public void messageEndpointForcefullyDeactivated() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "MEF.messageEndpointForcefullyDeactivated called for enterprise class "
					+ this.beanMetaData.enterpriseBeanName);
		}

		Object var2 = this.ivStateLock;
		synchronized (this.ivStateLock) {
			this.ivDeactivationKey = null;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "MEF.messageEndpointForcefullyDeactivated exit for enterprise class "
					+ this.beanMetaData.enterpriseBeanName);
		}

	}

	protected boolean isEndpointActive() {
		Object var1 = this.ivStateLock;
		synchronized (this.ivStateLock) {
			return this.ivDeactivationKey != null;
		}
	}

	public int getMaxPoolSize() {
		return this.ivMaxCreation;
	}

	public void setJCAVersion(JCAVersion version) {
		if (version == JCAVersion.JCA_VERSION_17) {
			this.majorJCAVersion = 1;
			this.minorJCAVersion = 7;
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "MessageEndpointFactoryImpl.setJCAVersionJCA: Version " + this.majorJCAVersion + "."
						+ this.minorJCAVersion + " is set");
			}
		} else if (version == JCAVersion.JCA_VERSION_16) {
			this.majorJCAVersion = 1;
			this.minorJCAVersion = 6;
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "MessageEndpointFactoryImpl.setJCAVersionJCA: Version " + this.majorJCAVersion + "."
						+ this.minorJCAVersion + " is set");
			}
		} else {
			if (version != JCAVersion.JCA_VERSION_15) {
				throw new IllegalArgumentException("JCA Version " + version + " is not supported");
			}

			this.majorJCAVersion = 1;
			this.minorJCAVersion = 5;
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "MessageEndpointFactoryImpl.setJCAVersionJCA: Version " + this.majorJCAVersion + "."
						+ this.minorJCAVersion + " is set");
			}
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}