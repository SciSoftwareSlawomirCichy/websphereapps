package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.util.Properties;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.ejb.Handle;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.naming.NoInitialContextException;
import javax.rmi.PortableRemoteObject;

public class EntityHandle implements Handle, Serializable {
	private static final TraceComponent tc = Tr.register(EntityHandle.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	String homeJNDIName;
	String homeInterface;
	Serializable key;
	final Properties initialContextProperties;
	transient EJBObject object;
	transient ClassLoader classLoader;
	private static final long serialVersionUID = 2909502407438195167L;

	EntityHandle(BeanId id, BeanMetaData bmd, Properties props) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", id);
		}

		this.homeJNDIName = id.getJNDIName();
		this.key = id.getPrimaryKey();
		this.homeInterface = bmd.homeInterfaceClass.getName();
		this.initialContextProperties = props;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public EJBObject getEJBObject() throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBObject");
		}

		if (this.object == null) {
			if (this.homeJNDIName != null && this.homeJNDIName.contains(":")) {
				throw new NoSuchObjectException("EJBHome JNDI name not allowed : " + this.homeJNDIName);
			}

			NoSuchObjectException ctx;
			try {
				Class homeClass = null;

				try {
					ClassLoader cl = Thread.currentThread().getContextClassLoader();
					if (cl == null) {
						throw new ClassNotFoundException();
					}

					homeClass = cl.loadClass(this.homeInterface);
				} catch (ClassNotFoundException var9) {
					try {
						homeClass = Class.forName(this.homeInterface);
					} catch (ClassNotFoundException var8) {
						throw new ClassNotFoundException(this.homeInterface);
					}
				}

				ctx = null;
				EJBHome home = null;

				InitialContext ctx;
				try {
					if (this.initialContextProperties == null) {
						ctx = new InitialContext();
					} else {
						try {
							ctx = new InitialContext(this.initialContextProperties);
							if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
								Tr.debug(tc,
										"Created an initial context with the initialContextProperties, providerURL = "
												+ (String) this.initialContextProperties.get("java.naming.provider.url")
												+ " INITIAL_CONTEXT_FACTORY = " + (String) this.initialContextProperties
														.get("java.naming.factory.initial"));
							}
						} catch (NamingException var6) {
							ctx = new InitialContext();
						}
					}

					home = (EJBHome) PortableRemoteObject.narrow(ctx.lookup(this.homeJNDIName), homeClass);
				} catch (NoInitialContextException var7) {
					Properties p = new Properties();
					p.put("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
					ctx = new InitialContext(p);
					home = (EJBHome) PortableRemoteObject.narrow(ctx.lookup(this.homeJNDIName), homeClass);
				}

				Method fbpk = this.findFindByPrimaryKey(homeClass);
				this.object = (EJBObject) fbpk.invoke(home, this.key);
			} catch (InvocationTargetException var10) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBObject", var10);
				}

				Throwable t = var10.getTargetException();
				if (t instanceof RemoteException) {
					throw (RemoteException) t;
				}

				throw new RemoteException("Could not find bean", t);
			} catch (NamingException var11) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBObject", var11);
				}

				ctx = new NoSuchObjectException("Could not find home in JNDI");
				ctx.detail = var11;
				throw ctx;
			} catch (ClassNotFoundException var12) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBObject", var12);
				}

				throw new RemoteException("Could not load home interface", var12);
			} catch (IllegalAccessException var13) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "getEJBObject", var13);
				}

				throw new RemoteException("Bad home interface definition", var13);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEJBObject");
		}

		return this.object;
	}

	private Method findFindByPrimaryKey(Class<?> c) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "findFindByPrimaryKey", c);
		}

		Method[] methods = c.getMethods();

		for (int i = 0; i < methods.length; ++i) {
			if (methods[i].getName().equals("findByPrimaryKey")) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "findFindByPrimaryKey");
				}

				return methods[i];
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "findFindByPrimaryKey: method findByPrimaryKey not found!");
		}

		return null;
	}
}