package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.AbstractFuture.1;
import com.google.common.util.concurrent.AbstractFuture.AtomicHelper;
import com.google.common.util.concurrent.AbstractFuture.Cancellation;
import com.google.common.util.concurrent.AbstractFuture.Failure;
import com.google.common.util.concurrent.AbstractFuture.Listener;
import com.google.common.util.concurrent.AbstractFuture.SafeAtomicHelper;
import com.google.common.util.concurrent.AbstractFuture.SetFuture;
import com.google.common.util.concurrent.AbstractFuture.SynchronizedHelper;
import com.google.common.util.concurrent.AbstractFuture.Trusted;
import com.google.common.util.concurrent.AbstractFuture.UnsafeAtomicHelper;
import com.google.common.util.concurrent.AbstractFuture.Waiter;
import com.google.common.util.concurrent.internal.InternalFutureFailureAccess;
import com.google.common.util.concurrent.internal.InternalFutures;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.ForOverride;
import com.google.j2objc.annotations.ReflectionSupport;
import com.google.j2objc.annotations.ReflectionSupport.Level;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Logger;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
@ReflectionSupport(Level.FULL)
public abstract class AbstractFuture<V> extends InternalFutureFailureAccess implements ListenableFuture<V> {
	private static final boolean GENERATE_CANCELLATION_CAUSES = Boolean
			.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
	private static final Logger log = Logger.getLogger(AbstractFuture.class.getName());
	private static final long SPIN_THRESHOLD_NANOS = 1000L;
	private static final AtomicHelper ATOMIC_HELPER;
	private static final Object NULL;
	@NullableDecl
	private volatile Object value;
	@NullableDecl
	private volatile Listener listeners;
	@NullableDecl
	private volatile Waiter waiters;

	private void removeWaiter(Waiter node) {
		node.thread = null;

		label28 : while (true) {
			Waiter pred = null;
			Waiter curr = this.waiters;
			if (curr == Waiter.TOMBSTONE) {
				return;
			}

			Waiter succ;
			for (; curr != null; curr = succ) {
				succ = curr.next;
				if (curr.thread != null) {
					pred = curr;
				} else if (pred != null) {
					pred.next = succ;
					if (pred.thread == null) {
						continue label28;
					}
				} else if (!ATOMIC_HELPER.casWaiters(this, curr, succ)) {
					continue label28;
				}
			}

			return;
		}
	}

	@CanIgnoreReturnValue
	public V get(long timeout, TimeUnit unit) throws InterruptedException, TimeoutException, ExecutionException {
		long timeoutNanos = unit.toNanos(timeout);
		long remainingNanos = timeoutNanos;
		if (Thread.interrupted()) {
			throw new InterruptedException();
		} else {
			Object localValue = this.value;
			if (localValue != null & !(localValue instanceof SetFuture)) {
				return this.getDoneValue(localValue);
			} else {
				long endNanos = timeoutNanos > 0L ? System.nanoTime() + timeoutNanos : 0L;
				if (timeoutNanos >= 1000L) {
					label136 : {
						Waiter oldHead = this.waiters;
						if (oldHead != Waiter.TOMBSTONE) {
							Waiter node = new Waiter();

							do {
								node.setNext(oldHead);
								if (ATOMIC_HELPER.casWaiters(this, oldHead, node)) {
									do {
										LockSupport.parkNanos(this, remainingNanos);
										if (Thread.interrupted()) {
											this.removeWaiter(node);
											throw new InterruptedException();
										}

										localValue = this.value;
										if (localValue != null & !(localValue instanceof SetFuture)) {
											return this.getDoneValue(localValue);
										}

										remainingNanos = endNanos - System.nanoTime();
									} while (remainingNanos >= 1000L);

									this.removeWaiter(node);
									break label136;
								}

								oldHead = this.waiters;
							} while (oldHead != Waiter.TOMBSTONE);
						}

						return this.getDoneValue(this.value);
					}
				}

				while (remainingNanos > 0L) {
					localValue = this.value;
					if (localValue != null & !(localValue instanceof SetFuture)) {
						return this.getDoneValue(localValue);
					}

					if (Thread.interrupted()) {
						throw new InterruptedException();
					}

					remainingNanos = endNanos - System.nanoTime();
				}

				String futureToString = this.toString();
				String unitString = unit.toString().toLowerCase(Locale.ROOT);
				String message = "Waited " + timeout + " " + unit.toString().toLowerCase(Locale.ROOT);
				if (remainingNanos + 1000L < 0L) {
					message = message + " (plus ";
					long overWaitNanos = -remainingNanos;
					long overWaitUnits = unit.convert(overWaitNanos, TimeUnit.NANOSECONDS);
					long overWaitLeftoverNanos = overWaitNanos - unit.toNanos(overWaitUnits);
					boolean shouldShowExtraNanos = overWaitUnits == 0L || overWaitLeftoverNanos > 1000L;
					if (overWaitUnits > 0L) {
						message = message + overWaitUnits + " " + unitString;
						if (shouldShowExtraNanos) {
							message = message + ",";
						}

						message = message + " ";
					}

					if (shouldShowExtraNanos) {
						message = message + overWaitLeftoverNanos + " nanoseconds ";
					}

					message = message + "delay)";
				}

				if (this.isDone()) {
					throw new TimeoutException(message + " but future completed as timeout expired");
				} else {
					throw new TimeoutException(message + " for " + futureToString);
				}
			}
		}
	}

	@CanIgnoreReturnValue
	public V get() throws InterruptedException, ExecutionException {
		if (Thread.interrupted()) {
			throw new InterruptedException();
		} else {
			Object localValue = this.value;
			if (localValue != null & !(localValue instanceof SetFuture)) {
				return this.getDoneValue(localValue);
			} else {
				Waiter oldHead = this.waiters;
				if (oldHead != Waiter.TOMBSTONE) {
					Waiter node = new Waiter();

					do {
						node.setNext(oldHead);
						if (ATOMIC_HELPER.casWaiters(this, oldHead, node)) {
							do {
								LockSupport.park(this);
								if (Thread.interrupted()) {
									this.removeWaiter(node);
									throw new InterruptedException();
								}

								localValue = this.value;
							} while (!(localValue != null & !(localValue instanceof SetFuture)));

							return this.getDoneValue(localValue);
						}

						oldHead = this.waiters;
					} while (oldHead != Waiter.TOMBSTONE);
				}

				return this.getDoneValue(this.value);
			}
		}
	}

	private V getDoneValue(Object obj) throws ExecutionException {
		if (obj instanceof Cancellation) {
			throw cancellationExceptionWithCause("Task was cancelled.", ((Cancellation) obj).cause);
		} else if (obj instanceof Failure) {
			throw new ExecutionException(((Failure) obj).exception);
		} else {
			return obj == NULL ? null : obj;
		}
	}

	public boolean isDone() {
		Object localValue = this.value;
		return localValue != null & !(localValue instanceof SetFuture);
	}

	public boolean isCancelled() {
		Object localValue = this.value;
		return localValue instanceof Cancellation;
	}

	@CanIgnoreReturnValue
	public boolean cancel(boolean mayInterruptIfRunning) {
		Object localValue = this.value;
		boolean rValue = false;
		if (localValue == null | localValue instanceof SetFuture) {
			Object valueToSet = GENERATE_CANCELLATION_CAUSES
					? new Cancellation(mayInterruptIfRunning, new CancellationException("Future.cancel() was called."))
					: (mayInterruptIfRunning ? Cancellation.CAUSELESS_INTERRUPTED : Cancellation.CAUSELESS_CANCELLED);
			AbstractFuture abstractFuture = this;

			while (true) {
				while (!ATOMIC_HELPER.casValue(abstractFuture, localValue, valueToSet)) {
					localValue = abstractFuture.value;
					if (!(localValue instanceof SetFuture)) {
						return rValue;
					}
				}

				rValue = true;
				if (mayInterruptIfRunning) {
					abstractFuture.interruptTask();
				}

				complete(abstractFuture);
				if (!(localValue instanceof SetFuture)) {
					break;
				}

				ListenableFuture<?> futureToPropagateTo = ((SetFuture) localValue).future;
				if (!(futureToPropagateTo instanceof Trusted)) {
					futureToPropagateTo.cancel(mayInterruptIfRunning);
					break;
				}

				AbstractFuture<?> trusted = (AbstractFuture) futureToPropagateTo;
				localValue = trusted.value;
				if (!(localValue == null | localValue instanceof SetFuture)) {
					break;
				}

				abstractFuture = trusted;
			}
		}

		return rValue;
	}

	protected void interruptTask() {
	}

	protected final boolean wasInterrupted() {
		Object localValue = this.value;
		return localValue instanceof Cancellation && ((Cancellation) localValue).wasInterrupted;
	}

	public void addListener(Runnable listener, Executor executor) {
		Preconditions.checkNotNull(listener, "Runnable was null.");
		Preconditions.checkNotNull(executor, "Executor was null.");
		if (!this.isDone()) {
			Listener oldHead = this.listeners;
			if (oldHead != Listener.TOMBSTONE) {
				Listener newNode = new Listener(listener, executor);

				do {
					newNode.next = oldHead;
					if (ATOMIC_HELPER.casListeners(this, oldHead, newNode)) {
						return;
					}

					oldHead = this.listeners;
				} while (oldHead != Listener.TOMBSTONE);
			}
		}

		executeListener(listener, executor);
	}

	@CanIgnoreReturnValue
	protected boolean set(@NullableDecl V value) {
		Object valueToSet = value == null ? NULL : value;
		if (ATOMIC_HELPER.casValue(this, (Object) null, valueToSet)) {
			complete(this);
			return true;
		} else {
			return false;
		}
	}

	@CanIgnoreReturnValue
	protected boolean setException(Throwable throwable) {
		Object valueToSet = new Failure((Throwable) Preconditions.checkNotNull(throwable));
		if (ATOMIC_HELPER.casValue(this, (Object) null, valueToSet)) {
			complete(this);
			return true;
		} else {
			return false;
		}
	}

	@Beta
	@CanIgnoreReturnValue
	protected boolean setFuture(ListenableFuture<? extends V> future) {
		Preconditions.checkNotNull(future);
		Object localValue = this.value;
		if (localValue == null) {
			if (future.isDone()) {
				Object value = getFutureValue(future);
				if (ATOMIC_HELPER.casValue(this, (Object) null, value)) {
					complete(this);
					return true;
				}

				return false;
			}

			SetFuture valueToSet = new SetFuture(this, future);
			if (ATOMIC_HELPER.casValue(this, (Object) null, valueToSet)) {
				try {
					future.addListener(valueToSet, DirectExecutor.INSTANCE);
				} catch (Throwable var8) {
					Throwable t = var8;

					Failure failure;
					try {
						failure = new Failure(t);
					} catch (Throwable var7) {
						failure = Failure.FALLBACK_INSTANCE;
					}

					ATOMIC_HELPER.casValue(this, valueToSet, failure);
				}

				return true;
			}

			localValue = this.value;
		}

		if (localValue instanceof Cancellation) {
			future.cancel(((Cancellation) localValue).wasInterrupted);
		}

		return false;
	}

	private static Object getFutureValue(ListenableFuture<?> future) {
		if (future instanceof Trusted) {
			Object v = ((AbstractFuture) future).value;
			if (v instanceof Cancellation) {
				Cancellation c = (Cancellation) v;
				if (c.wasInterrupted) {
					v = c.cause != null ? new Cancellation(false, c.cause) : Cancellation.CAUSELESS_CANCELLED;
				}
			}

			return v;
		} else {
			if (future instanceof InternalFutureFailureAccess) {
				Throwable throwable = InternalFutures
						.tryInternalFastPathGetFailure((InternalFutureFailureAccess) future);
				if (throwable != null) {
					return new Failure(throwable);
				}
			}

			boolean wasCancelled = future.isCancelled();
			if (!GENERATE_CANCELLATION_CAUSES & wasCancelled) {
				return Cancellation.CAUSELESS_CANCELLED;
			} else {
				try {
					Object v = getUninterruptibly(future);
					if (wasCancelled) {
						return new Cancellation(false, new IllegalArgumentException(
								"get() did not throw CancellationException, despite reporting isCancelled() == true: "
										+ future));
					} else {
						return v == null ? NULL : v;
					}
				} catch (ExecutionException var3) {
					return wasCancelled
							? new Cancellation(false, new IllegalArgumentException(
									"get() did not throw CancellationException, despite reporting isCancelled() == true: "
											+ future,
									var3))
							: new Failure(var3.getCause());
				} catch (CancellationException var4) {
					return !wasCancelled
							? new Failure(new IllegalArgumentException(
									"get() threw CancellationException, despite reporting isCancelled() == false: "
											+ future,
									var4))
							: new Cancellation(false, var4);
				} catch (Throwable var5) {
					return new Failure(var5);
				}
			}
		}
	}

	private static <V> V getUninterruptibly(Future<V> future) throws ExecutionException {
		boolean interrupted = false;

		try {
			while (true) {
				try {
					Object var2 = future.get();
					return var2;
				} catch (InterruptedException var6) {
					interrupted = true;
				}
			}
		} finally {
			if (interrupted) {
				Thread.currentThread().interrupt();
			}

		}
	}

	private static void complete(AbstractFuture<?> future) {
		Listener next = null;

		label23 : while (true) {
			future.releaseWaiters();
			future.afterDone();
			next = future.clearListeners(next);
			future = null;

			while (next != null) {
				Listener curr = next;
				next = next.next;
				Runnable task = curr.task;
				if (task instanceof SetFuture) {
					SetFuture<?> setFuture = (SetFuture) task;
					future = setFuture.owner;
					if (future.value == setFuture) {
						Object valueToSet = getFutureValue(setFuture.future);
						if (ATOMIC_HELPER.casValue(future, setFuture, valueToSet)) {
							continue label23;
						}
					}
				} else {
					executeListener(task, curr.executor);
				}
			}

			return;
		}
	}

	@Beta
	@ForOverride
	protected void afterDone() {
	}

	@NullableDecl
	protected final Throwable tryInternalFastPathGetFailure() {
		if (this instanceof Trusted) {
			Object obj = this.value;
			if (obj instanceof Failure) {
				return ((Failure) obj).exception;
			}
		}

		return null;
	}

	final void maybePropagateCancellationTo(@NullableDecl Future<?> related) {
		if (related != null & this.isCancelled()) {
			related.cancel(this.wasInterrupted());
		}

	}

	private void releaseWaiters() {
		Waiter head;
		do {
			head = this.waiters;
		} while (!ATOMIC_HELPER.casWaiters(this, head, Waiter.TOMBSTONE));

		for (Waiter currentWaiter = head; currentWaiter != null; currentWaiter = currentWaiter.next) {
			currentWaiter.unpark();
		}

	}

	private Listener clearListeners(Listener onto) {
		Listener head;
		do {
			head = this.listeners;
		} while (!ATOMIC_HELPER.casListeners(this, head, Listener.TOMBSTONE));

		Listener reversedList;
		Listener tmp;
		for (reversedList = onto; head != null; reversedList = tmp) {
			tmp = head;
			head = head.next;
			tmp.next = reversedList;
		}

		return reversedList;
	}

	public String toString() {
		StringBuilder builder = (new StringBuilder()).append(super.toString()).append("[status=");
		if (this.isCancelled()) {
			builder.append("CANCELLED");
		} else if (this.isDone()) {
			this.addDoneString(builder);
		} else {
			String pendingDescription;
			try {
				pendingDescription = this.pendingToString();
			} catch (RuntimeException var4) {
				pendingDescription = "Exception thrown from implementation: " + var4.getClass();
			}

			if (pendingDescription != null && !pendingDescription.isEmpty()) {
				builder.append("PENDING, info=[").append(pendingDescription).append("]");
			} else if (this.isDone()) {
				this.addDoneString(builder);
			} else {
				builder.append("PENDING");
			}
		}

		return builder.append("]").toString();
	}

	@NullableDecl
	protected String pendingToString() {
		Object localValue = this.value;
		if (localValue instanceof SetFuture) {
			return "setFuture=[" + this.userObjectToString(((SetFuture) localValue).future) + "]";
		} else {
			return this instanceof ScheduledFuture
					? "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]"
					: null;
		}
	}

	private void addDoneString(StringBuilder builder) {
		try {
			V value = getUninterruptibly(this);
			builder.append("SUCCESS, result=[").append(this.userObjectToString(value)).append("]");
		} catch (ExecutionException var3) {
			builder.append("FAILURE, cause=[").append(var3.getCause()).append("]");
		} catch (CancellationException var4) {
			builder.append("CANCELLED");
		} catch (RuntimeException var5) {
			builder.append("UNKNOWN, cause=[").append(var5.getClass()).append(" thrown from get()]");
		}

	}

	private String userObjectToString(Object o) {
		return o == this ? "this future" : String.valueOf(o);
	}

	private static void executeListener(Runnable runnable, Executor executor) {
		try {
			executor.execute(runnable);
		} catch (RuntimeException var3) {
			log.log(java.util.logging.Level.SEVERE,
					"RuntimeException while executing runnable " + runnable + " with executor " + executor, var3);
		}

	}

	private static CancellationException cancellationExceptionWithCause(@NullableDecl String message,
			@NullableDecl Throwable cause) {
		CancellationException exception = new CancellationException(message);
		exception.initCause(cause);
		return exception;
	}

	static {
      Throwable thrownUnsafeFailure = null;
      Throwable thrownAtomicReferenceFieldUpdaterFailure = null;

      Object helper;
      try {
         helper = new UnsafeAtomicHelper((1)null);
      } catch (Throwable var6) {
         thrownUnsafeFailure = var6;

         try {
            helper = new SafeAtomicHelper(AtomicReferenceFieldUpdater.newUpdater(Waiter.class, Thread.class, "thread"), AtomicReferenceFieldUpdater.newUpdater(Waiter.class, Waiter.class, "next"), AtomicReferenceFieldUpdater.newUpdater(AbstractFuture.class, Waiter.class, "waiters"), AtomicReferenceFieldUpdater.newUpdater(AbstractFuture.class, Listener.class, "listeners"), AtomicReferenceFieldUpdater.newUpdater(AbstractFuture.class, Object.class, "value"));
         } catch (Throwable var5) {
            thrownAtomicReferenceFieldUpdaterFailure = var5;
            helper = new SynchronizedHelper((1)null);
         }
      }

      ATOMIC_HELPER = (AtomicHelper)helper;
      Class<?> ensureLoaded = LockSupport.class;
      if (thrownAtomicReferenceFieldUpdaterFailure != null) {
         log.log(java.util.logging.Level.SEVERE, "UnsafeAtomicHelper is broken!", thrownUnsafeFailure);
         log.log(java.util.logging.Level.SEVERE, "SafeAtomicHelper is broken!", thrownAtomicReferenceFieldUpdaterFailure);
      }

      NULL = new Object();
   }
}