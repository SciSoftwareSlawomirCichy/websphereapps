package com.ibm.ejs.container;

import com.ibm.websphere.csi.CSIServant;
import com.ibm.websphere.csi.TransactionalObject;
import java.rmi.RemoteException;
import java.rmi.UnexpectedException;
import javax.rmi.CORBA.Stub;
import javax.rmi.CORBA.Util;
import org.omg.CORBA.SystemException;
import org.omg.CORBA.portable.ApplicationException;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.RemarshalException;
import org.omg.CORBA.portable.ServantObject;

public class _EJSRemoteWrapper_Stub extends Stub implements CSIServant, TransactionalObject {
	private static final String[] _type_ids = new String[]{
			"RMI:com.ibm.ejs.container.EJSRemoteWrapper:0000000000000000",
			"RMI:com.ibm.websphere.csi.CSIServant:0000000000000000",
			"RMI:com.ibm.websphere.csi.TransactionalObject:0000000000000000"};

	public String[] _ids() {
		return (String[]) _type_ids.clone();
	}

	public boolean wlmable() throws RemoteException {
		while (true) {
			boolean var2;
			if (!Util.isLocal(this)) {
				InputStream var25 = null;

				try {
					try {
						OutputStream var5 = this._request("wlmable", true);
						var25 = this._invoke(var5);
						var2 = var25.read_boolean();
					} catch (ApplicationException var19) {
						var25 = var19.getInputStream();
						String var26 = var25.read_string();
						throw new UnexpectedException(var26);
					} catch (RemarshalException var20) {
						continue;
					}
				} catch (SystemException var21) {
					throw Util.mapSystemException(var21);
				} finally {
					this._releaseReply(var25);
				}

				return var2;
			} else {
				ServantObject var1 = this._servant_preinvoke("wlmable", class$com$ibm$websphere$csi$CSIServant != null
						? class$com$ibm$websphere$csi$CSIServant
						: (class$com$ibm$websphere$csi$CSIServant = class$("com.ibm.websphere.csi.CSIServant")));
				if (var1 != null) {
					try {
						var2 = ((CSIServant) var1.servant).wlmable();
					} catch (Throwable var23) {
						Throwable var6 = (Throwable) Util.copyObject(var23, this._orb());
						throw Util.wrapException(var6);
					} finally {
						this._servant_postinvoke(var1);
					}

					return var2;
				}
			}
		}
	}
}