package com.ibm.ejs.util.dopriv;

import java.lang.reflect.AccessibleObject;
import java.security.PrivilegedExceptionAction;

public class SetAccessiblePrivilegedAction implements PrivilegedExceptionAction<AccessibleObject> {
	private AccessibleObject ivObject;
	private boolean ivAccessible;

	public SetAccessiblePrivilegedAction() {
		this.ivObject = null;
		this.ivAccessible = true;
	}

	public SetAccessiblePrivilegedAction(AccessibleObject obj, boolean accessible) {
		this.ivObject = obj;
		this.ivAccessible = accessible;
	}

	public void setParameters(AccessibleObject obj, boolean accessible) {
		this.ivObject = obj;
		this.ivAccessible = accessible;
	}

	public AccessibleObject run() throws SecurityException {
		AccessibleObject rv = this.ivObject;
		this.ivObject = null;
		if (rv != null) {
			rv.setAccessible(this.ivAccessible);
		}

		return rv;
	}
}