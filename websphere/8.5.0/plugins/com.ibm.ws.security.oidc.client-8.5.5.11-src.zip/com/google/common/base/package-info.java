package com.google.common.base;

import javax.annotation.ParametersAreNonnullByDefault;

// $FF: synthetic class
@ParametersAreNonnullByDefault
interface package-info {
}