package com.ibm.ffdc.impl;

import com.ibm.ffdc.Ffdc;
import com.ibm.ffdc.config.DataCollector;
import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.config.IncidentForwarder;
import com.ibm.ffdc.impl.EmptyProvider.EmptyFfdc;
import com.ibm.ffdc.provider.FfdcProvider;
import com.ibm.ffdc.util.provider.Incident;
import java.util.Collections;
import java.util.List;

final class EmptyProvider implements FfdcProvider {
	public Ffdc getFfdc(Throwable exception, Object reporter, String sourceId, String probeId) {
		return new EmptyFfdc();
	}

	public Ffdc getFfdc(Throwable exception, Object reporter, String sourceId) {
		return new EmptyFfdc();
	}

	public void log(Throwable exception, Object reporter, String sourceId, String probeId, Object... args) {
	}

	public void log(Throwable exception, Object reporter, String sourceId, String probeId) {
	}

	public void register(Formatter formatter) {
	}

	public void deregister(Formatter formatter) {
	}

	public void register(DataCollector dataCollector) {
	}

	public void deregister(DataCollector dataCollector) {
	}

	public void register(IncidentForwarder dataCollector) {
	}

	public void deregister(IncidentForwarder dataCollector) {
	}

	public void release() {
	}

	public List<Incident> getIncidents() {
		return Collections.emptyList();
	}

	public boolean unblockLogging(Incident incident) {
		return false;
	}

	public void unblockLogging() {
	}

	public String toString() {
		return "com.ibm.ffdc.EmptyProvider(silent)";
	}
}