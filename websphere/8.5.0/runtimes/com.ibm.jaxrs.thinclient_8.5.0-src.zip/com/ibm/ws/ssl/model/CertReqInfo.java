package com.ibm.ws.ssl.model;

public class CertReqInfo {
	String label = null;
	int size = Integer.parseInt("2048");
	String subjectDN = null;
	int validDays = 365;
	KeyStoreInfo ksInfo = null;
	String filename = null;
	String profileUUID = null;
	String signatureAlgorithm = "SHA1withRSA";

	public CertReqInfo() {
		this.label = null;
		this.size = Integer.parseInt("2048");
		this.subjectDN = null;
		this.validDays = 365;
		this.filename = null;
		this.ksInfo = null;
		this.signatureAlgorithm = "SHA1withRSA";
	}

	public CertReqInfo(String l, int s, String dn, int days, KeyStoreInfo info, String path,
			String signatureAlgorithm) {
		this.setLabel(l);
		this.setSize(s);
		this.setSubjectDN(dn);
		this.setValidDays(days);
		this.setKsInfo(info);
		this.setFilename(path);
		this.setSignatureAlgorithm(signatureAlgorithm);
	}

	public CertReqInfo(String l, int s, String dn, int days, KeyStoreInfo info, String path) {
		if (l != null) {
			this.label = l;
		}

		if (s > 0) {
			this.size = s;
		}

		if (dn != null) {
			this.subjectDN = dn;
		}

		if (days > 0) {
			if (days == 1) {
				this.validDays = days + 1;
			} else {
				this.validDays = days;
			}
		}

		if (info != null) {
			this.ksInfo = info;
		}

		if (path != null) {
			this.filename = path;
		}

	}

	public void setLabel(String l) {
		this.label = l;
	}

	public void setSize(int s) {
		this.size = s;
	}

	public void setSubjectDN(String dn) {
		this.subjectDN = dn;
	}

	public void setValidDays(int days) {
		this.validDays = days;
	}

	public void setKsInfo(KeyStoreInfo info) {
		this.ksInfo = info;
	}

	public void setSignatureAlgorithm(String signatureAlgorithm) {
		this.signatureAlgorithm = signatureAlgorithm;
	}

	public String getLabel() {
		return this.label;
	}

	public int getSize() {
		return this.size;
	}

	public String getSubjectDN() {
		return this.subjectDN;
	}

	public int getValidDays() {
		return this.validDays;
	}

	public KeyStoreInfo getKsInfo() {
		return this.ksInfo;
	}

	public String getSignatureAlgorithm() {
		return this.signatureAlgorithm;
	}

	public String getFilename() {
		return this.filename;
	}

	public void setFilename(String file) {
		this.filename = file;
	}

	public String getProfileUUID() {
		return this.profileUUID;
	}

	public void setProfileUUID(String uuid) {
		this.profileUUID = uuid;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		new StringBuffer();
		sb.append("\tCertReqInfo:");
		sb.append("\n\t").append("label = ").append(this.label);
		sb.append("\n\t").append("size = ").append(Integer.toString(this.size));
		sb.append("\n\t").append("subjectDN = ").append(this.subjectDN);
		sb.append("\n\t").append("validDays = ").append(Integer.toString(this.validDays));
		sb.append("\n\t").append("filename = ").append(this.filename);
		sb.append("\n\t").append("profileUUID = ").append(this.profileUUID);
		sb.append("\n\t").append("signatureAlgorithm = ").append(this.signatureAlgorithm);
		return sb.toString();
	}
}