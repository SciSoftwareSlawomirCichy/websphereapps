package com.ibm.ejs.container.lock;

public class DeadlockException extends LockException {
	private static final long serialVersionUID = 6641400854594164270L;
}