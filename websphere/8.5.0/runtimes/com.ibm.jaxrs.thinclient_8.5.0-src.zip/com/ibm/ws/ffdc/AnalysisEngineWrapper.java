package com.ibm.ws.ffdc;

import com.ibm.etools.analysis.engine.Directive;
import com.ibm.etools.analysis.engine.Incident;
import com.ibm.etools.analysis.engine.Solution;
import com.ibm.etools.analysis.engine.engines.FFDCAnalysisEngine;
import com.ibm.ws.ffdc.impl.FFDCHelper;
import com.ibm.ws.ffdc.impl.WrappingFileOutputStream;
import java.io.File;
import java.io.PrintStream;

class AnalysisEngineWrapper {
	private static FFDCAnalysisEngine analysisEngine = null;
	private static boolean commandLineCall = false;
	private static String databaseName = "ffdcdb.xml";
	private static Object fileGuard = new Object();

	private static synchronized FFDCAnalysisEngine getAnalysisEngine() {
		String qualifiedName = null;
		if (analysisEngine == null) {
			try {
				if (commandLineCall) {
					qualifiedName = databaseName;
				} else {
					qualifiedName = FFDCHelper.getQualifiedDatabaseName(databaseName);
				}
			} catch (Throwable var2) {
				return null;
			}

			analysisEngine = FFDCAnalysisEngine.getInstance(qualifiedName);
		}

		return analysisEngine;
	}

	static void setUpForCommandLineCall(String inDatabaseName) {
		commandLineCall = true;
		if (inDatabaseName != null) {
			databaseName = inDatabaseName;
		}

	}

	static String[] checkKnowledgeBase(String exceptionName, String[] callStack, String header, int filesize,
			int backupFiles) {
		return checkKnowledgeBase(exceptionName, callStack, header, (String) null, filesize, backupFiles);
	}

	static synchronized String[] checkKnowledgeBase(String exceptionName, String[] callStack, String header,
			String displayPrintStack, int filesize, int backupFiles) {
		FFDCAnalysisEngine analysisEngine = null;
		Directive d = null;
		String[] stringDirectives = null;
		int directiveCounter = 0;
		String saveDirective = null;
		Incident incident = new Incident((String) null);
		analysisEngine = getAnalysisEngine();
		if (analysisEngine == null) {
			return (String[]) null;
		} else {
			incident.setMessageId(exceptionName);
			incident.setRawData(callStack);
			Solution[] solution = analysisEngine.analyzeForSolutions(incident);
			if (commandLineCall && solution.length == 0) {
				String msg = "NOT FOUND -- See attached call stack for more details about the problem.";
				msg = msg + header + '\n' + displayPrintStack;
				if (callStack.length == 0) {
					msg = msg + " -- Call Stack was not set to anything";
				}

				printSolution("****** " + msg + " ******", exceptionName, header, 1, 1, filesize, backupFiles);
			}

			Directive[] directive;
			int innerloop;
			int directiveIndex;
			for (directiveIndex = 0; directiveIndex < solution.length; ++directiveIndex) {
				directive = solution[directiveIndex].getDirectives();
				if (directive != null) {
					for (innerloop = 0; innerloop < directive.length; ++innerloop) {
						++directiveCounter;
						if (directiveCounter == 1) {
							saveDirective = directive[innerloop].getDirectiveString();
						}
					}
				}

				if (solution[directiveIndex].getDescription() != null) {
					printSolution(solution[directiveIndex].getDescription(), exceptionName, header, directiveIndex + 1,
							solution.length, filesize, backupFiles);
				}
			}

			if (directiveCounter > 1) {
				stringDirectives = new String[directiveCounter];
				directiveIndex = 0;

				for (innerloop = 0; innerloop < solution.length; ++innerloop) {
					directive = solution[innerloop].getDirectives();
					if (directive != null) {
						for (int innerloop = 0; innerloop < directive.length; ++innerloop) {
							stringDirectives[directiveIndex] = directive[innerloop].getDirectiveString();
							++directiveIndex;
						}
					}
				}
			} else if (directiveCounter == 1) {
				stringDirectives = new String[]{saveDirective};
			}

			return stringDirectives;
		}
	}

	private static void printSolution(String solution, String exName, String header, int entry, int total, int filesize,
			int filenum) {
		PrintStream ps = null;
		if (commandLineCall) {
			System.out.println("----------------------------------------------------------------------");
			System.out.println("Key Value : " + header);
			if (total > 1) {
				System.out.println("Multiple entries found for symptom, entry " + entry + " of " + total);
			}

			System.out.println("Exception Name : " + exName);
			System.out.println("Solution : " + solution);
			System.out.println("----------------------------------------------------------------------");
		} else {
			Object var8 = fileGuard;
			synchronized (fileGuard) {
				try {
					ps = openFile(filesize, filenum);
					if (ps == null) {
						return;
					}

					ps.println("----------------------------------------------------------------------");
					ps.println("Key Value : " + header);
					ps.println("Exception Name : " + exName);
					ps.println("Solution : " + solution);
					ps.println("----------------------------------------------------------------------");
					ps.close();
				} catch (Throwable var11) {
					return;
				}

			}
		}
	}

	private static PrintStream openFile(int filesize, int filenum) {
		PrintStream ps = null;
		String exceptionFileName = null;
		int maxValue = 1048576;
		int openFileSize = false;
		if (filesize > 1048576) {
			filesize = 1048576;
		}

		int openFileSize = filesize * 1024;
		if (openFileSize < 0) {
			openFileSize = 1048576;
		}

		try {
			exceptionFileName = getFileName();
			if (exceptionFileName == null) {
				return null;
			} else {
				WrappingFileOutputStream wfs = new WrappingFileOutputStream(exceptionFileName, openFileSize, filenum);
				ps = new PrintStream(wfs);
				return ps;
			}
		} catch (Throwable var7) {
			var7.printStackTrace();
			return null;
		}
	}

	private static String getFileName() {
		String fileName = "solution";
		String serverName = null;
		serverName = FFDCHelper.getServerName();
		if (serverName == null || serverName.length() == 0) {
			serverName = "serverName";
		}

		try {
			String baseDir = FFDCHelper.getDefaultLoggingDirectory();
			StringBuffer sb = new StringBuffer(64);
			sb.append(baseDir);
			sb.append(File.separatorChar);
			sb.append(serverName);
			sb.append('_');
			sb.append(fileName);
			sb.append(FFDC.getExceptionIndexFileNameExtension());
			return new String(sb);
		} catch (Throwable var4) {
			return null;
		}
	}
}