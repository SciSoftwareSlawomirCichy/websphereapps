package com.ibm.ws.wim.federation;

import java.util.HashMap;

public class FederationEntity {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	static final String CLASSNAME = FederationEntity.class.getName();
	private String entityType = null;
	private String uniqueId = null;
	private String repositoryId = null;
	private String externalId = null;
	private String uniqueName = null;

	public FederationEntity() {
	}

	public FederationEntity(String var1, String var2, String var3, String var4, String var5) {
		if (var1 != null) {
			this.uniqueId = var1.trim();
		}

		if (var2 != null) {
			this.uniqueName = var2.trim();
		}

		if (var3 != null) {
			this.entityType = var3.trim();
		}

		if (var4 != null) {
			this.repositoryId = var4.trim();
		}

		if (var5 != null) {
			this.externalId = var5.trim();
		}

	}

	public HashMap toHashMap() {
		HashMap var1 = new HashMap();
		var1.put("UNIQUE_ID", this.getUniqueId());
		var1.put("ENTITY_TYPE", this.getEntityType());
		var1.put("REPOS_ID", this.getRepositoryId());
		var1.put("EXT_ID", this.getExternalId());
		return var1;
	}

	public String getUniqueId() {
		return this.uniqueId;
	}

	public void setUniqueId(String var1) {
		if (var1 != null) {
			this.uniqueId = var1.trim();
		} else {
			this.uniqueId = null;
		}

	}

	public String getEntityType() {
		return this.entityType;
	}

	public void setEntityType(String var1) {
		if (var1 != null) {
			this.entityType = var1.trim();
		} else {
			this.entityType = null;
		}

	}

	public String getExternalId() {
		return this.externalId;
	}

	public void setExternalId(String var1) {
		if (var1 != null) {
			this.externalId = var1.trim();
		} else {
			this.externalId = null;
		}

	}

	public String getRepositoryId() {
		return this.repositoryId;
	}

	public void setRepositoryId(String var1) {
		if (var1 != null) {
			this.repositoryId = var1.trim();
		} else {
			this.repositoryId = null;
		}

	}

	public boolean equals(FederationEntity var1) {
		if (var1 == null) {
			return false;
		} else if (this.getUniqueId() == null && var1.getUniqueId() == null) {
			return true;
		} else {
			return this.getUniqueId() != null ? this.getUniqueId().equals(var1.getUniqueId()) : false;
		}
	}

	public String getUniqueName() {
		return this.uniqueName;
	}

	public void setUniqueName(String var1) {
		if (var1 != null) {
			this.uniqueName = var1.trim();
		} else {
			this.uniqueName = null;
		}

	}
}