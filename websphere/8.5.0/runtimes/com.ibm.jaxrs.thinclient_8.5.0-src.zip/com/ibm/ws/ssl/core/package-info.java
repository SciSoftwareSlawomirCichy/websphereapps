package com.ibm.ws.ssl.core;

interface package-info {
}