package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.PasswordCheckFailedException;
import com.ibm.websphere.security.Result;
import com.ibm.websphere.wim.Service;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.ws.wim.SPIServiceProvider;
import com.ibm.ws.wim.config.ConfigUtils;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.UserRegistryInfoMappingType;
import com.ibm.ws.wim.registry.dataobject.IDAndRealm;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserRegistryValidator {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = UserRegistryValidator.class.getName();
	private static final Logger trcLogger;
	public static final String SESSION_ID = "SESSIONID";
	private BridgeUtils mappingUtils = BridgeUtils.singleton();
	private Service SPIService = null;
	private ConfigurationProviderType configDO = null;
	private RealmConfigurationType realmConfig = null;
	private String defaultRealm = null;
	private String defaultRealmDelimiter = null;
	private Set virtualRealms = new HashSet();
	private Map virtualRealmsDelimiter = new HashMap();

	public UserRegistryValidator(String var1) throws CustomRegistryException, RemoteException {
		String var2 = "<init>";
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, var2, "sessionId = " + var1);
		}

		Properties var3 = new Properties();
		var3.put("SESSIONID", var1);
		this.initialize(var3);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var2);
		}

	}

	public void initialize(Properties var1) throws CustomRegistryException, RemoteException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize", "inputProperties = " + var1);
		}

		try {
			this.SPIService = new SPIServiceProvider((String) var1.get("SESSIONID"));
			trcLogger.logp(Level.FINE, CLASSNAME, "initialize", "SPIService initialized: " + this.SPIService);
			this.configDO = (ConfigurationProviderType) this.SPIService.getConfig();
			this.realmConfig = this.configDO.getRealmConfiguration();
			this.defaultRealm = this.realmConfig.getDefaultRealm();
			trcLogger.logp(Level.FINE, CLASSNAME, "initialize", "default realm=" + this.defaultRealm);
			List var3 = this.realmConfig.getRealms();
			int var4 = 0;

			while (true) {
				if (var4 >= var3.size()) {
					trcLogger.logp(Level.FINE, CLASSNAME, "initialize", "realms=" + this.virtualRealms);
					trcLogger.logp(Level.FINE, CLASSNAME, "initialize",
							"realmsDelimiter=" + this.virtualRealmsDelimiter);
					break;
				}

				RealmType var5 = (RealmType) var3.get(var4);
				if (this.defaultRealm.equals(var5.getName())) {
					this.defaultRealmDelimiter = var5.getDelimiter();
				}

				this.virtualRealms.add(var5.getName());
				this.virtualRealmsDelimiter.put(var5.getName(), var5.getDelimiter());
				++var4;
			}
		} catch (WIMException var6) {
			throw new CustomRegistryException(var6);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

	}

	public String checkPassword(String var1, String var2)
			throws PasswordCheckFailedException, CustomRegistryException, RemoteException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "checkPassword", "inputUser = \"" + var1 + "\", inputPassword = *");
		}

		StringBuffer var4 = new StringBuffer();

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var5 = this.mappingUtils.seperateIDAndRealm(var1, this.defaultRealm, this.defaultRealmDelimiter,
					this.virtualRealms, this.virtualRealmsDelimiter);
			DataObject var6 = this.SPIService.createRootDataObject();
			if (var5.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var6, var5.getRealm());
			}

			if (!this.mappingUtils.isIdentifierTypeProperty(this.getOutputUserSecurityName(var5.getRealm()))) {
				this.mappingUtils.createLoginControlDataObject(var6, this.getOutputUserSecurityName(var5.getRealm()));
			}

			DataObject var7 = var6.createDataObject("entities", "http://www.ibm.com/websphere/wim", "LoginAccount");
			trcLogger.logp(Level.FINE, CLASSNAME, "checkPassword",
					"DataObject with LoginAccount=" + WIMTraceHelper.printDataGraph(var6));
			var7.set("principalName", var5.getId());
			var7.set("password", PasswordUtil.getByteArrayPassword(var2));
			trcLogger.logp(Level.FINE, CLASSNAME, "checkPassword",
					"DataObject before login=" + WIMTraceHelper.printDataGraph(var6));
			var6 = this.SPIService.login(var6);
			trcLogger.logp(Level.FINE, CLASSNAME, "checkPassword",
					"DataObject after login=" + WIMTraceHelper.printDataGraph(var6));
			List var8 = var6.getList("entities");
			if (var8.isEmpty()) {
				throw new com.ibm.websphere.wim.exception.PasswordCheckFailedException("ENTITY_NOT_FOUND",
						WIMMessageHelper.generateMsgParms(var1), CLASSNAME, "checkPassword");
			}

			DataObject var9 = (DataObject) var8.get(0);
			if (!this.mappingUtils.isIdentifierTypeProperty(this.getOutputUserSecurityName(var5.getRealm()))) {
				var4.append(var9.getString(this.getOutputUserSecurityName(var5.getRealm())));
			} else {
				var4.append(var9.getString("identifier/" + this.getOutputUserSecurityName(var5.getRealm())));
			}

			if (var5.isRealmDefined() && !this.defaultRealm.equals(var5.getRealm())) {
				var4.append(var5.getDelimiter() + var5.getRealm());
			}
		} catch (WIMException var10) {
			this.mappingUtils.logException(var10, CLASSNAME);
			if (var10 instanceof com.ibm.websphere.wim.exception.PasswordCheckFailedException) {
				throw new PasswordCheckFailedException(var10);
			}

			if (var10 instanceof EntityNotFoundException) {
				throw new PasswordCheckFailedException(var10);
			}

			throw new CustomRegistryException(var10);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "checkPassword", "returnValue = \"" + var4 + "\"");
		}

		return var4.toString();
	}

	public Result getUsers(String var1, int var2) throws CustomRegistryException, RemoteException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getUsers",
					"inputPattern = \"" + var1 + "\", inputLimit = \"" + Integer.toString(var2) + "\"");
		}

		Result var4 = new Result();

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var5 = this.mappingUtils.seperateIDAndRealm(var1, this.defaultRealm, this.defaultRealmDelimiter,
					this.virtualRealms, this.virtualRealmsDelimiter);
			DataObject var6 = this.SPIService.createRootDataObject();
			if (var5.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var6, var5.getRealm());
			}

			DataObject var7 = var6.createDataObject("controls", "http://www.ibm.com/websphere/wim", "SearchControl");
			if (!this.mappingUtils.isIdentifierTypeProperty(this.getOutputUserSecurityName(var5.getRealm()))) {
				var7.getList("properties").add(this.getOutputUserSecurityName(var5.getRealm()));
			}

			String var8 = "'";
			String var9 = var5.getId();
			if (var9.indexOf("'") != -1) {
				var8 = "\"";
			}

			var7.setString("expression", "//entities[@xsi:type='LoginAccount' and "
					+ this.getInputUserSecurityName(var5.getRealm()) + "=" + var8 + var9 + var8 + "]");
			if (var2 > 0) {
				var7.setString("countLimit", Integer.toString(var2 + 1));
			} else {
				var7.setString("countLimit", Integer.toString(var2));
			}

			trcLogger.logp(Level.FINE, CLASSNAME, "getUsers",
					"DataObject before search=" + WIMTraceHelper.printDataGraph(var6));
			var6 = this.SPIService.search(var6);
			trcLogger.logp(Level.FINE, CLASSNAME, "getUsers",
					"DataObject after search=" + WIMTraceHelper.printDataGraph(var6));
			List var10 = var6.getList("entities");
			if (var10.isEmpty()) {
				var4.setList(new ArrayList());
			} else {
				ArrayList var11 = new ArrayList();

				for (int var12 = 0; var12 < var10.size(); ++var12) {
					if (var2 > 0 && var12 == var2) {
						var4.setHasMore();
						break;
					}

					DataObject var13 = (DataObject) var10.get(var12);
					if (!this.mappingUtils.isIdentifierTypeProperty(this.getOutputUserSecurityName(var5.getRealm()))) {
						var11.add(var13.getString(this.getOutputUserSecurityName(var5.getRealm())));
					} else {
						var11.add(var13.getString("identifier/" + this.getOutputUserSecurityName(var5.getRealm())));
					}
				}

				var4.setList(var11);
			}
		} catch (WIMException var14) {
			if (!(var14 instanceof EntityNotFoundException)) {
				this.mappingUtils.logException(var14, CLASSNAME);
				throw new CustomRegistryException(var14);
			}

			var4.setList(new ArrayList());
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getUsers", "returnValue = \"" + var4.getList() + "\"");
		}

		return var4;
	}

	private String getOutputUserSecurityName(String var1) throws WIMException, RemoteException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getOutputUserSecurityName", "realmName=" + var1);
		}

		String var3 = null;
		ConfigurationProviderType var4 = (ConfigurationProviderType) this.SPIService.getConfig();
		RealmConfigurationType var5 = var4.getRealmConfiguration();
		RealmType var6 = ConfigUtils.getRealm(var1, var5, true);
		UserRegistryInfoMappingType var7 = var6.getUserSecurityNameMapping();
		var3 = var7.getPropertyForOutput();
		if (var3 == null || var3.equals("")) {
			var3 = "principalName";
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getOutputUserSecurityName", "returnValue=" + var3);
		}

		return var3;
	}

	private String getInputUserSecurityName(String var1) throws WIMException, RemoteException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getInputUserSecurityName", "realmName=" + var1);
		}

		String var3 = null;
		ConfigurationProviderType var4 = (ConfigurationProviderType) this.SPIService.getConfig();
		RealmConfigurationType var5 = var4.getRealmConfiguration();
		RealmType var6 = ConfigUtils.getRealm(var1, var5, true);
		UserRegistryInfoMappingType var7 = var6.getUserSecurityNameMapping();
		var3 = var7.getPropertyForInput();
		if (var3 == null || var3.equals("") || this.mappingUtils.isIdentifierTypeProperty(var3)) {
			var3 = "principalName";
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getInputUserSecurityName", "returnValue=" + var3);
		}

		return var3;
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}