package com.google.common.util.concurrent;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.util.concurrent.ExecutionList.RunnableExecutorPair;
import java.util.Queue;
import java.util.concurrent.Executor;
import java.util.logging.Logger;

public final class ExecutionList {
	@VisibleForTesting
	static final Logger log = Logger.getLogger(ExecutionList.class.getName());
	private final Queue<RunnableExecutorPair> runnables = Lists.newLinkedList();
	private boolean executed = false;

	public void add(Runnable runnable, Executor executor) {
		Preconditions.checkNotNull(runnable, "Runnable was null.");
		Preconditions.checkNotNull(executor, "Executor was null.");
		boolean executeImmediate = false;
		Queue var4 = this.runnables;
		synchronized (this.runnables) {
			if (!this.executed) {
				this.runnables.add(new RunnableExecutorPair(runnable, executor));
			} else {
				executeImmediate = true;
			}
		}

		if (executeImmediate) {
			(new RunnableExecutorPair(runnable, executor)).execute();
		}

	}

	public void execute() {
		Queue var1 = this.runnables;
		synchronized (this.runnables) {
			if (this.executed) {
				return;
			}

			this.executed = true;
		}

		while (!this.runnables.isEmpty()) {
			((RunnableExecutorPair) this.runnables.poll()).execute();
		}

	}
}