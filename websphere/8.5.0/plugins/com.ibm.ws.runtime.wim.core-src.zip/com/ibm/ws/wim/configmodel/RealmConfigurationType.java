package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface RealmConfigurationType {
	List getRealms();

	RealmType[] getRealmsAsArray();

	RealmType createRealms();

	String getDefaultRealm();

	void setDefaultRealm(String var1);
}