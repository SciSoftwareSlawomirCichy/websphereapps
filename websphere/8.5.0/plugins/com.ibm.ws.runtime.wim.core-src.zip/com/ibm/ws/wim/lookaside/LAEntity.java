package com.ibm.ws.wim.lookaside;

public class LAEntity {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private long entityId;
	private String entityType;
	private String externalId;
	private String repositoryId;

	public long getEntityId() {
		return this.entityId;
	}

	public void setEntityId(long var1) {
		this.entityId = var1;
	}

	public String getEntityType() {
		return this.entityType;
	}

	public void setEntityType(String var1) {
		this.entityType = var1;
	}

	public String getExternalId() {
		return this.externalId;
	}

	public void setExternalId(String var1) {
		this.externalId = var1;
	}

	public String getRepositoryId() {
		return this.repositoryId;
	}

	public void setRepositoryId(String var1) {
		this.repositoryId = var1;
	}
}