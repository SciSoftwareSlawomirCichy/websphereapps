package com.google.inject;

import com.google.inject.internal.ImmutableMap;
import com.google.inject.spi.InjectionPoint;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import org.aopalliance.intercept.MethodInterceptor;

interface ConstructionProxy<T> {
	T newInstance(Object... var1) throws InvocationTargetException;

	InjectionPoint getInjectionPoint();

	Constructor<T> getConstructor();

	ImmutableMap<Method, List<MethodInterceptor>> getMethodInterceptors();
}