package com.ibm.ws.ssl.provider;

interface package-info {
}