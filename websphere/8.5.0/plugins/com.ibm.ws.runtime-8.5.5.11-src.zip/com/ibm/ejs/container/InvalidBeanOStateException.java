package com.ibm.ejs.container;

public class InvalidBeanOStateException extends ContainerInternalError {
	private static final long serialVersionUID = -8193296452469430090L;
	public final String currentState;
	public final String expectedState;
	public final String msg;

	public InvalidBeanOStateException(String current, String expected) {
		this.msg = "";
		this.currentState = current;
		this.expectedState = expected;
	}

	public InvalidBeanOStateException(String msg) {
		this.msg = msg;
		this.currentState = "";
		this.expectedState = "";
	}

	public String toString() {
		return this.msg != null && !this.msg.equals("")
				? "InvalidBeanOStateException(" + this.msg + ")"
				: "InvalidBeanOStateException(current = " + this.currentState + ", expected = " + this.expectedState
						+ ")";
	}
}