package com.ibm.ejs.container;

import com.ibm.ejs.container.lock.Locker;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.container.util.MethodAttribUtils;
import com.ibm.ejs.csi.UOWControl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.cpi.CPIException;
import com.ibm.websphere.cpi.PersisterTx;
import com.ibm.websphere.csi.BeanInstanceInfo;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.TransactionListener;
import com.ibm.websphere.csi.TxContextChange;
import com.ibm.ws.LocalTransaction.ContainerSynchronization;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;
import com.ibm.ws.ejbcontainer.diagnostics.IncidentStreamWriter;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.ffdc.IncidentStream;
import com.ibm.ws.runtime.metadata.ComponentMetaData;
import com.ibm.ws.threadContext.ComponentMetaDataAccessorImpl;
import com.ibm.ws.traceinfo.ejbcontainer.TETxLifeCycleInfo;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import com.ibm.ws.util.ThreadContextAccessor;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import javax.transaction.Synchronization;
import javax.transaction.TransactionRolledbackException;

public class ContainerTx implements Locker, Synchronization, PersisterTx, ContainerSynchronization {
	private static final TraceComponent tc = Tr.register(ContainerTx.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.ContainerTx";
	private static final int ACTIVE = 0;
	private static final int PREPARING = 1;
	private static final int COMMITTED = 2;
	private static final int ROLLEDBACK = 3;
	private static final String[] stateStrs = new String[]{"Active", "Preparing", "Committed", "Rolledback"};
	private static final int MAX_ENLISTMENT_ITERATIONS = 30;
	private EJSContainer ivContainer;
	private HashMap<BeanId, BeanO> beanOs = null;
	private boolean origLock = false;
	protected TransactionListener txListener;
	private ArrayList<BeanO> beanOList = null;
	private ArrayList<BeanO> tempList = null;
	private HashMap<BeanId, BeanO> currentBeanOs = null;
	private ArrayList<BeanO> afterList = null;
	protected HashMap<EJSHome, ArrayList<BeanO>> homesForPMManagedBeans;
	public HashMap<String, TimerNpImpl> timersQueuedToStart;
	public HashMap<String, TimerNpImpl> timersCanceled;
	protected BeanO ivRemoveBeanO;
	private boolean ivBeanOsEnlistedInTx = false;
	protected boolean began = false;
	protected EJSDeployedSupport ivPostInvokeContext;
	private int ivIsolationLevel;
	private int state;
	protected boolean globalTransaction;
	private boolean markedRollbackOnly = false;
	SynchronizationRegistryUOWScope ivTxKey;
	private ContainerAS containerAS;
	private boolean isActivitySessionCompleting = true;
	private UOWControl uowCtrl;
	private ComponentMetaDataAccessorImpl cmdAccessor;
	private ArrayList<Synchronization> finderSyncList = null;
	protected boolean ivFlushRequired = false;
	protected boolean ivCMP11FlushActive = false;
	protected Throwable ivPostProcessingException = null;
	private long ivTxCacheHits = 0L;
	private long ivTxCacheSearch = 0L;

	private final void becomePreparing() {
		if (this.state != 0) {
			throw new IllegalStateException(stateStrs[this.state]);
		} else {
			this.state = 1;
		}
	}

	private final void initialize_beanO_vectors() {
		if (!this.ivBeanOsEnlistedInTx) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Lazy beanOs vector creation");
			}

			this.beanOs = new HashMap(16);
			this.beanOList = new ArrayList(10);
			this.afterList = new ArrayList(10);
			this.homesForPMManagedBeans = new HashMap(16);
			this.ivBeanOsEnlistedInTx = true;
		}

	}

	private final void becomeCommitted() {
		if (this.state != 1) {
			throw new IllegalStateException(stateStrs[this.state]);
		} else {
			this.state = 2;
		}
	}

	private final void becomeRolledback() {
		this.state = 3;
	}

	private final void ensureActive() throws TransactionRolledbackException {
		switch (this.state) {
			case 0 :
				return;
			case 3 :
				throw new TransactionRolledbackException();
			default :
				throw new IllegalStateException(stateStrs[this.state]);
		}
	}

	public ContainerTx(EJSContainer container, boolean isTransactionGlobal, SynchronizationRegistryUOWScope txKey,
			UOWControl UOWCtrl) {
		this.ivContainer = container;
		this.ivIsolationLevel = 0;
		this.ivTxKey = txKey;
		this.uowCtrl = UOWCtrl;
		this.state = 0;
		this.globalTransaction = isTransactionGlobal;
		this.isActivitySessionCompleting = true;
		this.cmdAccessor = ComponentMetaDataAccessorImpl.getComponentMetaDataAccessor();

		try {
			this.containerAS = container.getCurrentSessionalUOW(false);
		} catch (CSIException var6) {
			FFDCFilter.processException(var6, "com.ibm.ejs.container.ContainerTx.<init>", "359", this);
			this.containerAS = null;
			Tr.error(tc, "IGNORING_UNEXPECTED_EXCEPTION_CNTR0033E", var6);
		}

	}

	public boolean isTransactionGlobal() {
		return this.globalTransaction;
	}

	public final boolean isActiveGlobal() {
		return this.globalTransaction && this.state == 0;
	}

	public void beforeCompletion() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn) {
			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "beforeCompletion",
						new Object[]{this.globalTransaction, this, this.isActivitySessionCompleting});
			}

			if (TETxLifeCycleInfo.isTraceEnabled()) {
				String tid = this.getTxId();
				if (tid != null) {
					if (this.globalTransaction) {
						TETxLifeCycleInfo.traceGlobalTxBeforeCompletion(tid, "Global/User Tx BeforeCompletion");
					} else {
						TETxLifeCycleInfo.traceLocalTxBeforeCompletion(tid, "Local Tx BeforeCompletion");
					}
				}
			}
		}

		if (this.finderSyncList != null) {
			int numberofCallers = this.finderSyncList.size();

			for (int i = 0; i < numberofCallers; ++i) {
				((Synchronization) this.finderSyncList.get(i)).beforeCompletion();
			}
		}

		if (this.ivBeanOsEnlistedInTx) {
			this.origLock = true;
			EJBThreadData threadData = EJSContainer.getThreadData();
			BeanO beanO = null;
			boolean popCallbackBeanO = false;
			ComponentMetaData prevCMD = null;
			boolean resetCMD = false;
			ClassLoader prevClassLoader = null;
			Object origClassLoader = ThreadContextAccessor.UNCHANGED;

			try {
				int iterationCount = 0;

				for (ArrayList iterationBeanOs = this.beanOList; iterationBeanOs != null; this.tempList = null) {
					if (iterationCount++ > 30) {
						beanO = null;
						throw new RuntimeException("Exceeded 30 enlistment iterations in beforeCompletion");
					}

					int i = 0;

					for (int size = iterationBeanOs.size(); i < size; ++i) {
						beanO = (BeanO) iterationBeanOs.get(i);
						BeanMetaData bmd = beanO.home.beanMetaData;
						if (this.isActivitySessionCompleting || bmd.isEntityBean()) {
							threadData.pushCallbackBeanO(beanO);
							popCallbackBeanO = true;
							if (bmd != prevCMD) {
								if (resetCMD) {
									this.cmdAccessor.endContext();
								}

								this.cmdAccessor.beginContext(bmd);
								prevCMD = bmd;
								resetCMD = true;
								ClassLoader classLoader = bmd.ivContextClassLoader;
								if (classLoader != prevClassLoader) {
									prevClassLoader = classLoader;
									origClassLoader = EJBThreadData.svThreadContextAccessor
											.repushContextClassLoaderForUnprivileged(origClassLoader, classLoader);
								}
							}

							if (this.isActivitySessionCompleting
									&& (this.globalTransaction || bmd._localTran.getBoundary() == 1)) {
								beanO.beforeCompletion();
							} else {
								TxContextChange changedContext = this.uowCtrl.setupLocalTxContext(beanO.getId());

								try {
									if (this.isActivitySessionCompleting) {
										beanO.beforeCompletion();
									} else {
										beanO.store();
									}
								} finally {
									this.uowCtrl.teardownLocalTxContext(changedContext);
								}
							}

							popCallbackBeanO = false;
							threadData.popCallbackBeanO();
						}
					}

					iterationBeanOs = this.tempList;
				}
			} catch (Throwable var27) {
				FFDCFilter.processException(var27, "com.ibm.ejs.container.ContainerTx.beforeCompletion", "562", this);
				if (isTraceOn && tc.isEventEnabled()) {
					Tr.event(tc, "Exception during beforeCompletion(): rolling back", new Object[]{beanO, var27});
				}

				if (beanO != null) {
					beanO.destroy();
				}

				this.ivContainer.uowCtrl.setRollbackOnly();
				ExceptionUtil.logException(tc, var27, (EJBMethodMetaData) null, beanO);
				if (this.ivPostProcessingException == null) {
					this.ivPostProcessingException = var27;
				}

				throw new RuntimeException("", var27);
			} finally {
				EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(origClassLoader);
				if (resetCMD) {
					this.cmdAccessor.endContext();
				}

				if (popCallbackBeanO) {
					threadData.popCallbackBeanO();
				}

			}
		}

		if (this.isActivitySessionCompleting) {
			this.becomePreparing();
		}

		if (this.txListener != null) {
			try {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Calling txListener.beforeCompletion()");
				}

				this.txListener.beforeCompletion();
			} catch (Throwable var26) {
				FFDCFilter.processException(var26, "com.ibm.ejs.container.ContainerTx.beforeCompletion", "734", this);
				if (this.ivPostProcessingException == null) {
					this.ivPostProcessingException = var26;
				}

				throw new RuntimeException("txListener exception" + var26.toString());
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "beforeCompletion");
		}

	}

	public void afterCompletion(int status) {
		boolean committed = true;
		boolean reLoad = false;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (status != 3) {
			committed = false;
		}

		if (isTraceOn && TETxLifeCycleInfo.isTraceEnabled()) {
			String tid = this.getTxId();
			if (tid != null) {
				if (this.globalTransaction) {
					TETxLifeCycleInfo.traceGlobalTxAfterCompletion(tid, "Global/User Tx AfterCompletion");
				} else {
					TETxLifeCycleInfo.traceLocalTxAfterCompletion(tid, "Local Tx AfterCompletion");
				}
			}
		}

		int i;
		int afterListSize;
		if (this.finderSyncList != null) {
			afterListSize = this.finderSyncList.size();

			for (i = 0; i < afterListSize; ++i) {
				((Synchronization) this.finderSyncList.get(i)).afterCompletion(status);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "afterCompletion",
					new Object[]{this.globalTransaction, this, committed, this.isActivitySessionCompleting});
		}

		if (this.ivPostInvokeContext != null) {
			this.ivContainer.postInvokePopCallbackContexts(this.ivPostInvokeContext);
			this.ivPostInvokeContext = null;
		}

		try {
			BeanO beanO;
			Iterator i$;
			TimerNpImpl timer;
			if (committed) {
				if (this.isActivitySessionCompleting) {
					this.becomeCommitted();
					if (this.timersQueuedToStart != null) {
						i$ = this.timersQueuedToStart.values().iterator();

						while (i$.hasNext()) {
							timer = (TimerNpImpl) i$.next();
							timer.start();
						}
					}

					if (this.timersCanceled != null) {
						i$ = this.timersCanceled.values().iterator();

						while (i$.hasNext()) {
							timer = (TimerNpImpl) i$.next();
							timer.remove(true);
						}
					}

					if (this.ivBeanOsEnlistedInTx) {
						afterListSize = this.afterList.size();

						for (i = 0; i < afterListSize; ++i) {
							beanO = (BeanO) this.afterList.get(i);

							try {
								beanO.commit(this);
							} catch (Throwable var117) {
								FFDCFilter.processException(var117, "com.ibm.ejs.container.ContainerTx.afterCompletion",
										"795", this);
								if (isTraceOn && tc.isEventEnabled()) {
									Tr.event(tc, "Exception thrown in commit()", new Object[]{beanO, var117});
								}
							} finally {
								try {
									this.ivContainer.activator.commitBean(this, beanO);
								} catch (Throwable var112) {
									FFDCFilter.processException(var112,
											"com.ibm.ejs.container.ContainerTx.afterCompletion", "811", this);
									if (isTraceOn && tc.isEventEnabled()) {
										Tr.event(tc, "Exception thrown in commitBean()", new Object[]{beanO, var112});
									}
								}

							}
						}
					}
				} else {
					reLoad = true;
				}
			} else if (this.isActivitySessionCompleting) {
				this.becomeRolledback();
				if (this.timersCanceled != null) {
					i$ = this.timersCanceled.values().iterator();

					while (i$.hasNext()) {
						timer = (TimerNpImpl) i$.next();
						timer.start();
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "rollback re-started queued-as-canceled timer: " + timer);
						}
					}
				}

				if (this.timersQueuedToStart != null) {
					i$ = this.timersQueuedToStart.values().iterator();

					while (i$.hasNext()) {
						timer = (TimerNpImpl) i$.next();
						timer.remove(true);
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "rollback destroyed queued-to-start timer: " + timer);
						}
					}
				}

				if (this.ivBeanOsEnlistedInTx) {
					afterListSize = this.afterList.size();

					for (i = 0; i < afterListSize; ++i) {
						beanO = (BeanO) this.afterList.get(i);

						try {
							beanO.rollback(this);
						} catch (Throwable var115) {
							FFDCFilter.processException(var115, "com.ibm.ejs.container.ContainerTx.afterCompletion",
									"863", this);
							if (isTraceOn && tc.isEventEnabled()) {
								Tr.event(tc, "Exception thrown in rollback()", new Object[]{beanO, var115});
							}
						} finally {
							try {
								this.ivContainer.activator.rollbackBean(this, beanO);
							} catch (Throwable var111) {
								FFDCFilter.processException(var111, "com.ibm.ejs.container.ContainerTx.afterCompletion",
										"879", this);
								if (isTraceOn && tc.isEventEnabled()) {
									Tr.event(tc, "Exception thrown in rollbackBean()", new Object[]{beanO, var111});
								}
							}

						}
					}
				}
			} else {
				reLoad = true;
			}
		} catch (Throwable var119) {
			FFDCFilter.processException(var119, "com.ibm.ejs.container.ContainerTx.afterCompletion", "913", this);
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Exception during afterCompletion", var119);
			}

			throw new RuntimeException(var119.toString());
		} finally {
			try {
				if (this.txListener != null) {
					try {
						this.txListener.afterCompletion(status);
						this.txListener = null;
					} catch (Throwable var108) {
						FFDCFilter.processException(var108, "com.ibm.ejs.container.ContainerTx.afterCompletion", "929",
								this);
						throw new Exception("txListener exception" + var108.toString());
					}
				}
			} catch (Throwable var109) {
				FFDCFilter.processException(var109, "com.ibm.ejs.container.ContainerTx.afterCompletion", "934", this);
			}

			if (!reLoad) {
				this.ivContainer.containerTxCompleted(this);
			}

		}

		if (reLoad && this.afterList != null && !this.afterList.isEmpty()) {
			EJBThreadData threadData = EJSContainer.getThreadData();
			boolean popCallbackBeanO = false;
			ComponentMetaData prevCMD = null;
			boolean resetCMD = false;
			ClassLoader prevClassLoader = null;
			Object origClassLoader = ThreadContextAccessor.UNCHANGED;

			try {
				int afterListSize = this.afterList.size();

				for (int i = 0; i < afterListSize; ++i) {
					BeanO beanO = (BeanO) this.afterList.get(i);

					try {
						BeanMetaData bmd = beanO.home.beanMetaData;
						if (bmd.type == 6 || bmd.type == 5) {
							this.attachListener();
							if (this.txListener == null) {
								throw new Exception("Error: Null Transaction Listener");
							}

							this.txListener.afterBegin();
							if (!bmd.optionACommitOption && bmd.ivCacheReloadType == 0) {
								threadData.pushCallbackBeanO(beanO);
								popCallbackBeanO = true;
								if (bmd != prevCMD && bmd.type == 5) {
									if (resetCMD) {
										this.cmdAccessor.endContext();
									}

									this.cmdAccessor.beginContext(bmd);
									prevCMD = bmd;
									resetCMD = true;
									ClassLoader classLoader = bmd.ivContextClassLoader;
									if (classLoader != prevClassLoader) {
										prevClassLoader = classLoader;
										origClassLoader = EJBThreadData.svThreadContextAccessor
												.repushContextClassLoaderForUnprivileged(origClassLoader, classLoader);
									}
								}

								Object cmdCtxSet = null;
								TxContextChange changedContext = null;

								try {
									cmdCtxSet = this.cmdAccessor.beginContext(bmd);
									changedContext = this.uowCtrl.setupLocalTxContext(beanO.getId());
									((EntityBeanO) beanO).load(this, false);
								} finally {
									this.uowCtrl.teardownLocalTxContext(changedContext);
									if (cmdCtxSet != null) {
										this.cmdAccessor.endContext();
									}

								}

								popCallbackBeanO = false;
								threadData.popCallbackBeanO();
							} else {
								((EntityBeanO) beanO).enlistForOptionA(this);
							}
						}
					} catch (Throwable var113) {
						FFDCFilter.processException(var113, "com.ibm.ejs.container.ContainerTx.afterCompletion", "978",
								this);
						if (isTraceOn && tc.isEventEnabled()) {
							Tr.event(tc, "Exception thrown attempting to reload bean due to activitySession reset",
									new Object[]{beanO, var113});
						}

						beanO.destroy();
						this.ivContainer.uowCtrl.setRollbackOnly();
						ExceptionUtil.logException(tc, var113, (EJBMethodMetaData) null, beanO);
						throw new RuntimeException(var113.toString());
					}
				}
			} finally {
				EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(origClassLoader);
				if (resetCMD) {
					this.cmdAccessor.endContext();
				}

				if (popCallbackBeanO) {
					threadData.popCallbackBeanO();
				}

			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "afterCompletion");
		}

	}

	protected void attachListener() {
	}

	public void queueTimerToStart(TimerNpImpl timer) {
		if (this.globalTransaction) {
			if (this.timersQueuedToStart == null) {
				this.timersQueuedToStart = new HashMap();
			}

			this.timersQueuedToStart.put(timer.getTaskId(), timer);
		} else {
			timer.start();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "tran ctx is not global, so started timer immediately.");
			}
		}

	}

	public BeanO find(BeanId beanId) {
		BeanO bean = null;
		if (this.beanOs != null) {
			bean = (BeanO) this.beanOs.get(beanId);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			++this.ivTxCacheSearch;
			if (bean != null) {
				++this.ivTxCacheHits;
				Tr.debug(tc, "Bean found in Transaction cache (Hit Rate:" + this.ivTxCacheHits + "/"
						+ this.ivTxCacheSearch + ")");
			} else {
				Tr.debug(tc, "Bean not in Transaction cache (Hit Rate:" + this.ivTxCacheHits + "/"
						+ this.ivTxCacheSearch + ")");
			}
		}

		return bean;
	}

	protected boolean enlist(BeanO beanO) throws TransactionRolledbackException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "enlist", new Object[]{this.globalTransaction, this, beanO});
		}

		this.ensureActive();
		if (!this.ivBeanOsEnlistedInTx) {
			this.initialize_beanO_vectors();
		}

		boolean wasEnlisted = false;
		BeanO oldBeanO = (BeanO) this.beanOs.put(beanO.beanId, beanO);
		if (oldBeanO == null) {
			BeanMetaData bmd = beanO.home.beanMetaData;
			if (bmd.cmpVersion == 2 && bmd.ivCacheReloadType == 0) {
				ArrayList<BeanO> bundle = (ArrayList) this.homesForPMManagedBeans.get(beanO.home);
				if (bundle == null) {
					bundle = new ArrayList();
					this.homesForPMManagedBeans.put(beanO.home, bundle);
				}

				bundle.add(beanO);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Added this BeanO to CMP20 structure");
				}
			}

			this.afterList.add(beanO);
			if (!this.origLock) {
				this.beanOList.add(beanO);
			} else {
				this.setupTempLists();
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "sec enlist new : " + beanO);
				}

				this.currentBeanOs.put(beanO.beanId, beanO);
				this.tempList.add(beanO);
			}

			wasEnlisted = true;
		} else if (this.origLock) {
			this.setupTempLists();
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "enlist in beforeCompletion: putting in list");
			}

			BeanO obO = (BeanO) this.currentBeanOs.put(beanO.beanId, beanO);
			if (obO == null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Secondary enlist old : " + beanO);
				}

				this.tempList.add(beanO);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "enlist : " + wasEnlisted);
		}

		return wasEnlisted;
	}

	private void setupTempLists() {
		if (this.tempList == null) {
			this.tempList = new ArrayList();
			this.currentBeanOs = new HashMap();
		}

	}

	public void registerSynchronization(Synchronization s) throws CPIException {
		try {
			this.ivContainer.uowCtrl.enlistWithTransaction(s);
		} catch (CSIException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.ContainerTx.registerSynchronization", "1143",
					this);
			throw new CPIException(var3.toString());
		}
	}

	public boolean delist(BeanO beanO) throws TransactionRolledbackException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "delist", new Object[]{this.globalTransaction, this, beanO});
		}

		boolean removed = false;
		this.ensureActive();
		if (this.beanOs == null) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "delist : false : no beanOs");
			}

			return removed;
		} else if (this.origLock) {
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Attempt to delist after beforeCompletion");
			}

			throw new RuntimeException("Delisted after starting beforeCompletion");
		} else {
			if (this.beanOList.contains(beanO)) {
				this.beanOs.remove(beanO.beanId);
				this.beanOList.remove(this.beanOList.indexOf(beanO));
				this.afterList.remove(this.afterList.indexOf(beanO));
				removed = true;
				if (beanO.home.beanMetaData.cmpVersion == 2) {
					ArrayList<BeanO> bundle = (ArrayList) this.homesForPMManagedBeans.get(beanO.home);
					bundle.remove(bundle.lastIndexOf(beanO));
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "delist : " + removed);
			}

			return removed;
		}
	}

	protected BeanO[] getAllEnlistedBeanOs() {
		if (this.beanOs == null) {
			return null;
		} else {
			BeanO[] result = (BeanO[]) this.beanOList.toArray(new BeanO[this.beanOList.size()]);
			return result;
		}
	}

	protected final void preInvoke(EJSDeployedSupport s) throws TransactionRolledbackException {
		this.ensureActive();
		s.previousBegan = this.began;
		if (s.uowCookie == null) {
			this.began = false;
		} else {
			this.began = s.uowCookie.beganTx();
		}

		s.began = this.began;
	}

	protected void setIsolationLevel(int isolationLevel) throws IsolationLevelChangeException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			Tr.event(tc, "current isolation level = " + MethodAttribUtils.getIsolationLevelString(this.ivIsolationLevel)
					+ ", attempting to change to = " + MethodAttribUtils.getIsolationLevelString(isolationLevel));
		}

		if (this.ivIsolationLevel == 0) {
			this.ivIsolationLevel = isolationLevel;
		} else if (this.ivIsolationLevel != isolationLevel && isolationLevel != 0) {
			throw new IsolationLevelChangeException();
		}

	}

	protected final void postInvoke(EJSDeployedSupport s) {
		this.began = s.previousBegan;
	}

	protected void flush(BeanO[] theBeanOs, HashSet<BeanInstanceInfo> cmp2xBeansToFlush) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.entry(tc, "flush: num=" + (theBeanOs == null ? null : theBeanOs.length) + ", cmp2x="
					+ (cmp2xBeansToFlush == null ? null : cmp2xBeansToFlush.size()));
		}

		if (theBeanOs != null) {
			EJBThreadData threadData = EJSContainer.getThreadData();
			boolean popCallbackBeanO = false;
			ComponentMetaData prevCMD = null;
			boolean resetCMD = false;
			ClassLoader prevClassLoader = null;
			Object origClassLoader = ThreadContextAccessor.UNCHANGED;

			try {
				for (int i = 0; i < theBeanOs.length; ++i) {
					BeanO beanO = theBeanOs[i];
					BeanMetaData bmd = beanO.home.beanMetaData;
					if (bmd.cmpVersion == 2 && cmp2xBeansToFlush != null && !cmp2xBeansToFlush.remove(beanO)) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "Excluded from flush: " + beanO);
						}
					} else {
						threadData.pushCallbackBeanO(beanO);
						popCallbackBeanO = true;
						if (bmd != prevCMD && bmd.type == 5) {
							if (resetCMD) {
								this.cmdAccessor.endContext();
							}

							this.cmdAccessor.beginContext(bmd);
							prevCMD = bmd;
							resetCMD = true;
							ClassLoader classLoader = bmd.ivContextClassLoader;
							if (classLoader != prevClassLoader) {
								prevClassLoader = classLoader;
								origClassLoader = EJBThreadData.svThreadContextAccessor
										.repushContextClassLoaderForUnprivileged(origClassLoader, classLoader);
							}
						}

						try {
							beanO.store();
						} catch (RemoteException var17) {
							FFDCFilter.processException(var17, "com.ibm.ejs.container.ContainerTx.flush", "1505", this);
							throw new CSIException("Problem storing an enlisted bean", var17);
						}

						popCallbackBeanO = false;
						threadData.popCallbackBeanO();
					}
				}
			} finally {
				EJBThreadData.svThreadContextAccessor.popContextClassLoaderForUnprivileged(origClassLoader);
				if (resetCMD) {
					this.cmdAccessor.endContext();
				}

				if (popCallbackBeanO) {
					threadData.popCallbackBeanO();
				}

			}
		}

		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.exit(tc, "flush");
		}

	}

	protected void flush() throws CSIException {
	}

	public final boolean beganInThisScope() {
		return this.began;
	}

	public final int getIsolationLevel() {
		return this.ivIsolationLevel;
	}

	public final void setRollbackOnly() {
		this.markedRollbackOnly = true;
		this.ivContainer.uowCtrl.setRollbackOnly();
	}

	public final boolean getRollbackOnly() {
		return this.markedRollbackOnly;
	}

	protected final boolean getGlobalRollbackOnly() {
		return this.ivContainer.uowCtrl.getRollbackOnly();
	}

	public boolean isLock() {
		return false;
	}

	public int getLockMode(Object lockName) {
		BeanId beanId = (BeanId) lockName;
		if (beanId.isHome()) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "getLockMode: locking home bean: EXCLUSIVE");
			}

			return 1;
		} else {
			EntityBeanO beanO = null;
			beanO = (EntityBeanO) this.ivContainer.activator.getBean(this, beanId);
			if (beanO == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "getLockMode: failed to get bean");
				}

				return 1;
			} else {
				return beanO.getLockMode();
			}
		}
	}

	public final ContainerAS getContainerAS() {
		return this.containerAS;
	}

	protected final void setContainerAS(ContainerAS cas) {
		this.containerAS = cas;
	}

	public ContainerTx getCurrentTx() throws CSITransactionRolledbackException {
		return this.ivContainer.getCurrentTx(false);
	}

	public void setCompleting(boolean isCompleting) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setCompleting= " + isCompleting);
		}

		this.isActivitySessionCompleting = isCompleting;
		if (this.finderSyncList != null) {
			int numberofCallers = this.finderSyncList.size();

			for (int i = 0; i < numberofCallers; ++i) {
				((ContainerSynchronization) this.finderSyncList.get(i)).setCompleting(isCompleting);
			}
		}

		if (this.txListener != null) {
			try {
				this.txListener.setCompleting(isCompleting);
			} catch (Throwable var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.container.ContainerTx.afterCompletion", "1733", this);
				throw new RuntimeException("txListener exception" + var4.toString());
			}
		}

	}

	public void enlistContainerSync(Synchronization s) throws CPIException {
		if (!(s instanceof ContainerSynchronization)) {
			throw new CPIException("Must implement ContainerSynchronization interface");
		} else {
			if (this.finderSyncList == null) {
				this.finderSyncList = new ArrayList();
			}

			this.finderSyncList.add(s);
		}
	}

	public boolean getCMP11FlushActive() {
		return this.ivCMP11FlushActive;
	}

	protected void releaseResources() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "releaseResources : State = " + stateStrs[this.state]);
		}

		if (this.state == 2 || this.state == 3) {
			this.afterList = null;
			this.beanOList = null;
			this.beanOs = null;
			this.cmdAccessor = null;
			this.containerAS = null;
			this.currentBeanOs = null;
			this.finderSyncList = null;
			this.homesForPMManagedBeans = null;
			this.ivContainer = null;
			this.ivPostProcessingException = null;
			this.ivTxKey = null;
			this.tempList = null;
			this.txListener = null;
			this.uowCtrl = null;
			this.timersQueuedToStart = null;
			this.timersCanceled = null;
		}
	}

	public void ffdcDump(IncidentStream is) {
		this.introspect(new IncidentStreamWriter(is));
	}

	public void introspect(IntrospectionWriter writer) {
		writer.begin("Start ContainerTx Dump ---> " + this);
		writer.println("Tx Key                  = " + this.ivTxKey);
		writer.println("State                   = " + stateStrs[this.state]);
		writer.println("Entered beforCompletion = " + this.origLock);
		writer.println("Marked Rollback Only    = " + this.markedRollbackOnly);
		writer.println("Method Began            = " + this.began);
		writer.println("Isolation Level         = " + MethodAttribUtils.getIsolationLevelString(this.ivIsolationLevel));
		if (!this.isActivitySessionCompleting) {
			writer.println("isActivitySessionCompleting = " + this.isActivitySessionCompleting);
		}

		int numEnlisted = this.beanOList == null ? 0 : this.beanOList.size();
		writer.begin("Enlisted Beans : " + numEnlisted);

		for (int i = 0; i < numEnlisted; ++i) {
			writer.println(((BeanO) this.beanOList.get(i)).toString());
		}

		writer.end();
		this.introspectAccessIntent(writer);
		writer.end();
	}

	protected void introspectAccessIntent(IntrospectionWriter writer) {
	}

	protected String getTxId() {
		String rtnStr = null;
		if (this.ivTxKey != null) {
			if (this.globalTransaction) {
				rtnStr = this.ivTxKey.toString();
				int idx;
				rtnStr = rtnStr != null
						? ((idx = rtnStr.indexOf("#")) != -1 ? rtnStr.substring(idx + 5) : rtnStr)
						: "NoTx";
			} else {
				rtnStr = Integer.toHexString(System.identityHashCode(this.ivTxKey));
			}
		}

		return rtnStr;
	}

	protected static String uowIdToString(Object uowId) {
		String tidStr = null;
		if (uowId != null) {
			if (uowId instanceof LocalTransactionCoordinator) {
				tidStr = "tid=" + Integer.toHexString(uowId.hashCode()) + "(LTC)";
			} else {
				tidStr = uowId.toString();
				int idx;
				if ((idx = tidStr.lastIndexOf("#")) != -1) {
					tidStr = tidStr.substring(idx + 1);
				}
			}
		}

		return tidStr;
	}

	boolean isBmtActive(EJBMethodInfoImpl methodInfo) {
		return this.uowCtrl.isBmtActive(methodInfo);
	}

	public String toString() {
		String toString = "ContainerTx@" + Integer.toHexString(this.hashCode());
		if (this.ivTxKey != null) {
			if (this.globalTransaction) {
				toString = toString + "#tid=" + this.getTxId();
			} else {
				toString = toString + "#tid=" + this.getTxId() + "(LTC)";
			}
		} else {
			toString = toString + "#NoTx";
		}

		return toString;
	}

	public boolean isFlushRequired() {
		return this.ivFlushRequired;
	}
}