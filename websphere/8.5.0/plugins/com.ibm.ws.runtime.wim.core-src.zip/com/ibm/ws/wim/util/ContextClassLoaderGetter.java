package com.ibm.ws.wim.util;

import java.security.AccessController;
import java.security.PrivilegedAction;

public class ContextClassLoaderGetter implements PrivilegedAction {
	public Object run() {
		return Thread.currentThread().getContextClassLoader();
	}

	public ClassLoader getContextClassLoader() {
		return (ClassLoader) AccessController.doPrivileged(this);
	}
}