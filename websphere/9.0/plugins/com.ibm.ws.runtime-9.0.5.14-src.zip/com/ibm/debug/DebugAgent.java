package com.ibm.debug;

import com.ibm.debug.DebugAgent.1;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.etools.logging.tracing.agent.AgentControllerUnavailableException;
import com.ibm.etools.logging.tracing.agent.LoggingAgent;

public class DebugAgent {
	private LoggingAgent _agent;
	private static final TraceComponent tc = Tr.register(DebugComponentImpl.class.getName(), "DebugComponent");

	public void initialize() {
      try {
         this._agent = new LoggingAgent("IBM Distributed Debugger", "Debugger");
         this._agent.setCommandHandler(new 1(this));
         this._agent.initialize();
      } catch (AgentControllerUnavailableException var2) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "RAC not available");
         }
      }

   }
}