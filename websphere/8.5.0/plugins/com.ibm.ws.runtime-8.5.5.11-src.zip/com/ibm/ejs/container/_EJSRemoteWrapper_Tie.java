package com.ibm.ejs.container;

import java.rmi.Remote;
import javax.rmi.CORBA.Tie;
import org.omg.CORBA.BAD_OPERATION;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.CORBA.SystemException;
import org.omg.CORBA.portable.Delegate;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ResponseHandler;
import org.omg.CORBA.portable.UnknownException;
import org.omg.CORBA_2_3.portable.ObjectImpl;

public class _EJSRemoteWrapper_Tie extends ObjectImpl implements Tie {
	private EJSRemoteWrapper target = null;
	private ORB orb = null;
	private static final String[] _type_ids = new String[]{
			"RMI:com.ibm.ejs.container.EJSRemoteWrapper:0000000000000000",
			"RMI:com.ibm.websphere.csi.CSIServant:0000000000000000",
			"RMI:com.ibm.websphere.csi.TransactionalObject:0000000000000000"};

	public String[] _ids() {
		return (String[]) _type_ids.clone();
	}

	public OutputStream _invoke(String var1, InputStream var2, ResponseHandler var3) throws SystemException {
		try {
			org.omg.CORBA_2_3.portable.InputStream var4 = (org.omg.CORBA_2_3.portable.InputStream) var2;
			if (var1.equals("wlmable")) {
				return this.wlmable(var4, var3);
			} else {
				throw new BAD_OPERATION();
			}
		} catch (SystemException var5) {
			throw var5;
		} catch (Throwable var6) {
			throw new UnknownException(var6);
		}
	}

	public void _set_delegate(Delegate var1) {
		super._set_delegate(var1);
		if (var1 != null) {
			this.orb = this._orb();
		} else {
			this.orb = null;
		}

	}

	public void deactivate() {
		if (this.orb != null) {
			this.orb.disconnect(this);
			this._set_delegate((Delegate) null);
		}

	}

	public Remote getTarget() {
		return this.target;
	}

	public ORB orb() {
		return this._orb();
	}

	public void orb(ORB var1) {
		var1.connect(this);
	}

	public void setTarget(Remote var1) {
		this.target = (EJSRemoteWrapper) var1;
	}

	public Object thisObject() {
		return this;
	}

	private OutputStream wlmable(org.omg.CORBA_2_3.portable.InputStream var1, ResponseHandler var2) throws Throwable {
		boolean var3 = this.target.wlmable();
		OutputStream var4 = var2.createReply();
		var4.write_boolean(var3);
		return var4;
	}
}