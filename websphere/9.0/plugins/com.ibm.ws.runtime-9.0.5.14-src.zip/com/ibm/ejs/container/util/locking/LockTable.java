package com.ibm.ejs.container.util.locking;

public final class LockTable {
	private final Object[] locks;

	public LockTable(int size) {
		this.locks = new Object[size];
	}

	public Object getLock(Object key) {
		int index = (key.hashCode() & Integer.MAX_VALUE) % this.locks.length;
		Object lock = this.locks[index];
		if (lock == null) {
			synchronized (this) {
				lock = this.locks[index];
				if (lock == null) {
					lock = new Object();
					this.locks[index] = lock;
				}
			}
		}

		return lock;
	}
}