package com.ibm.ejs.ras;

import com.ibm.ejs.ras.TraceNLS.1;
import com.ibm.ws.ffdc.FFDCFilter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public class TraceNLS {
	public static final String $sccsid = "@(#) 1.5 SERV1/ws/code/ras.lite/src/com/ibm/ejs/ras/TraceNLS.java, WAS.ras.lite, WAS855.SERV1, cf172003.01 10/04/06 04:00:17 [1/28/20 10:11:16]";
	private static final String nullKey = "null Key";
	private static final String svNullBundleName = "Resource Bundle name is null, key = {0}";
	private static final String svBundleNotLoaded = "Unable to load ResourceBundle {0}";
	private static final String svNullKeyMessage = "Null key passed while using ResourceBundle {0}";
	private static final String svMalformedMessage = "No message text associated with key {0} in bundle {1}";
	private String ivBundleName = null;

	public static TraceNLS getTraceNLS(String bundleName) {
		return new TraceNLS(bundleName);
	}

	public static TraceNLS getTraceNLS(Class<?> caller, String bundleName) {
		return getTraceNLS(bundleName);
	}

	private TraceNLS(String bundleName) {
		this.ivBundleName = bundleName;
	}

	public String getString(String key) {
		return worker((ResourceBundle) null, this.ivBundleName, key, (Object[]) null, (String) null, false,
				(Locale) null, false);
	}

	public String getString(String key, String defaultString) {
		return worker((ResourceBundle) null, this.ivBundleName, key, (Object[]) null, defaultString, false,
				(Locale) null, false);
	}

	public String getFormattedMessage(String key, Object[] args, String defaultString) {
		return worker((ResourceBundle) null, this.ivBundleName, key, args, defaultString, true, (Locale) null, false);
	}

	public String getFormattedMessage(String key, Object[] args, String defaultString, boolean quiet) {
		return worker((ResourceBundle) null, this.ivBundleName, key, args, defaultString, true, (Locale) null, quiet);
	}

	public static String getStringFromBundle(String bundleName, String key) {
		return worker((ResourceBundle) null, bundleName, key, (Object[]) null, (String) null, false, (Locale) null,
				false);
	}

	public static String getStringFromBundle(String bundleName, String key, String defaultString) {
		return worker((ResourceBundle) null, bundleName, key, (Object[]) null, defaultString, false, (Locale) null,
				false);
	}

	public static String getFormattedMessage(String bundleName, String key, Object[] args, String defaultString) {
		return worker((ResourceBundle) null, bundleName, key, args, defaultString, true, (Locale) null, false);
	}

	public static String getFormattedMessage(String bundleName, String key, Object[] args, String defaultString,
			boolean quiet) {
		return worker((ResourceBundle) null, bundleName, key, args, defaultString, true, (Locale) null, quiet);
	}

	public static String getStringFromBundle(String bundleName, String key, Locale locale) {
		return worker((ResourceBundle) null, bundleName, key, (Object[]) null, (String) null, false, locale, false);
	}

	public static String getStringFromBundle(String bundleName, String key, Locale locale, String defaultString) {
		return worker((ResourceBundle) null, bundleName, key, (Object[]) null, defaultString, false, locale, false);
	}

	public static String getStringFromBundle(ResourceBundle bundle, String bundleName, String key, Locale locale) {
		return worker(bundle, bundleName, key, (Object[]) null, (String) null, false, locale, false);
	}

	public static String getStringFromBundle(ResourceBundle bundle, String bundleName, String key, Locale locale,
			String defaultString) {
		return worker(bundle, bundleName, key, (Object[]) null, defaultString, false, locale, false);
	}

	public static String getFormattedMessage(String bundleName, String key, Locale locale, Object[] args,
			String defaultString) {
		return worker((ResourceBundle) null, bundleName, key, args, defaultString, true, locale, false);
	}

	public static String getFormattedMessage(String bundleName, String key, Locale locale, Object[] args,
			String defaultString, boolean quiet) {
		return worker((ResourceBundle) null, bundleName, key, args, defaultString, true, locale, quiet);
	}

	public static String getFormattedMessageFromLocalizedMessage(String localizedMessage, Object[] args,
			boolean quiet) {
		return workerFormatLocalizedMessage(localizedMessage, args);
	}

	private static String worker(ResourceBundle bundle, String bundleName, String key, Object[] args,
			String defaultString, boolean format, Locale locale, boolean quiet) {
		String returnValue = null;
		if (locale == null) {
			locale = Locale.getDefault();
		}

		try {
			if (bundle == null) {
				bundle = getResourceBundle(bundleName, locale);
			}

			returnValue = bundle.getString(key);
			if (returnValue.equals("")) {
				if (defaultString == null) {
					returnValue = key;
				} else {
					returnValue = defaultString;
				}
			}

			return !format ? returnValue : workerFormatLocalizedMessage(returnValue, args);
		} catch (RuntimeException var10) {
			if (bundleName == null) {
				if (key == null && defaultString == null) {
					return MessageFormat.format("Resource Bundle name is null, key = {0}", "null Key");
				} else {
					if (defaultString == null) {
						returnValue = key;
					} else {
						returnValue = defaultString;
					}

					return !format ? returnValue : workerFormatLocalizedMessage(returnValue, args);
				}
			} else if (bundle == null) {
				if (key == null && defaultString == null) {
					return MessageFormat.format("Unable to load ResourceBundle {0}",
							(Object[]) (new String[]{bundleName}));
				} else {
					if (defaultString == null) {
						returnValue = key;
					} else {
						returnValue = defaultString;
					}

					return !format ? returnValue : workerFormatLocalizedMessage(returnValue, args);
				}
			} else if (key == null) {
				if (defaultString == null) {
					return MessageFormat.format("Null key passed while using ResourceBundle {0}",
							(Object[]) (new String[]{bundleName}));
				} else {
					return !format ? defaultString : workerFormatLocalizedMessage(defaultString, args);
				}
			} else {
				if (defaultString == null) {
					returnValue = key;
				} else {
					returnValue = defaultString;
				}

				return !format ? returnValue : workerFormatLocalizedMessage(returnValue, args);
			}
		}
	}

	private static String workerFormatLocalizedMessage(String message, Object[] args) {
		if (args == null) {
			return message;
		} else {
			for (int i = 0; i < args.length; ++i) {
				if (args[i] instanceof Throwable) {
					Object[] newArgs = new Object[args.length];
					System.arraycopy(args, 0, newArgs, 0, args.length);
					StringWriter sw = new StringWriter();
					PrintWriter pw = new PrintWriter(sw);

					for (StringBuffer sb = sw.getBuffer(); i < args.length; ++i) {
						if (args[i] instanceof Throwable) {
							((Throwable) args[i]).printStackTrace(pw);
							newArgs[i] = sb.toString();
							sb.setLength(0);
						}
					}

					args = newArgs;
					break;
				}
			}

			String formattedMessage = null;

			try {
				formattedMessage = MessageFormat.format(message, args);
				return formattedMessage;
			} catch (IllegalArgumentException var7) {
				return message;
			}
		}
	}

	public static ResourceBundle getResourceBundle(String bundleName, Locale locale) {
      ResourceBundle bundle = null;
      if (locale == null) {
         locale = Locale.getDefault();
      }

      try {
         bundle = ResourceBundle.getBundle(bundleName, locale);
      } catch (RuntimeException var7) {
         ClassLoader classLoader = null;

         try {
            classLoader = (ClassLoader)AccessController.doPrivileged(new 1());
         } catch (PrivilegedActionException var6) {
            FFDCFilter.processException(var6, "com.ibm.ejs.ras.TraceNLS", "1");
            throw new RuntimeException(var6);
         }

         bundle = ResourceBundle.getBundle(bundleName, locale, classLoader);
      }

      return bundle;
   }

	public static boolean isMessageIdConversionEnabled() {
		return false;
	}
}