package com.ibm.ws.wim.env.was;

import com.ibm.ws.security.util.WSEncoderDecoder;
import com.ibm.ws.wim.env.IEncryptionUtil;

public class EncryptionUtilImpl implements IEncryptionUtil {
	private WSEncoderDecoder encoderDecoder = null;

	public EncryptionUtilImpl() {
		this.encoderDecoder = new WSEncoderDecoder();
	}

	public String decode(String var1) {
		return this.encoderDecoder.decode(var1);
	}

	public String encode(String var1) {
		return this.encoderDecoder.encode(var1);
	}
}