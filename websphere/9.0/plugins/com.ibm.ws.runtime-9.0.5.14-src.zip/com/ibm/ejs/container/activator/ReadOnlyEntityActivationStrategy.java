package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanMetaData;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerAS;
import com.ibm.ejs.container.ContainerInternalError;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.container.EJSHome;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.IllegalOperationException;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public class ReadOnlyEntityActivationStrategy extends SingletonActivationStrategy {
	private static final TraceComponent tc = Tr.register(ReadOnlyEntityActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.activator.ReadOnlyEntityActivationStrategy";

	public ReadOnlyEntityActivationStrategy(Activator activator) {
		super(activator);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init> complete");
		}

	}

	BeanO atActivate(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atActivate (" + beanId + ")", tx);
		}

		Throwable exception = null;
		boolean pinned = false;
		boolean enlisted = false;
		boolean pushedCallbackBeanO = false;
		ContainerAS as = null;
		BeanO bean = tx.find(beanId);
		if (bean != null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Found bean in Tran Cache");
			}

			threadData.pushCallbackBeanO(bean);
		} else if ((as = tx.getContainerAS()) != null) {
			bean = as.find(beanId);
			if (bean != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Found bean in AS Cache");
				}

				threadData.pushCallbackBeanO(bean);
				bean.enlist(tx);
			}
		}

		if (bean == null) {
			TimeoutKey key = new TimeoutKey(beanId);
			boolean var31 = false;

			try {
				var31 = true;
				synchronized (this.locks.getLock(key)) {
					EJSHome home;
					BeanMetaData bmd;
					if ((bean = (BeanO) this.cache.find(key)) == null) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "Bean not in EJB Cache");
						}

						home = (EJSHome) beanId.getHome();
						bean = home.createBeanO(threadData, tx, beanId);
						pushedCallbackBeanO = true;
						bmd = home.getBeanMetaData();
						key.setTimeoutByInterval(bmd.ivCacheReloadType, bmd.ivCacheReloadInterval);
						this.cache.insert(key, bean);
						bean.ivCacheKey = key;
						pinned = true;
					} else {
						key = (TimeoutKey) bean.ivCacheKey;
						if (key.expirationDetected()) {
							if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
								Tr.debug(tc, "Found bean in EJB Cache - Expired");
							}

							home = (EJSHome) beanId.getHome();
							bmd = home.getBeanMetaData();
							key.setTimeoutByInterval(bmd.ivCacheReloadType, bmd.ivCacheReloadInterval);
							bean.invalidate();
						} else {
							if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
								Tr.debug(tc, "Found bean in EJB Cache");
							}

							key.setInUse(true);
						}

						pinned = true;
						threadData.pushCallbackBeanO(bean);
						pushedCallbackBeanO = true;
					}
				}

				synchronized (bean) {
					bean.activate(beanId, tx);
					enlisted = bean.enlist(tx);
				}

				if ((as = tx.getContainerAS()) != null) {
					as.enlist(bean);
					var31 = false;
				} else {
					var31 = false;
				}
			} catch (NoSuchObjectException var36) {
				exception = var36;
				throw var36;
			} catch (RemoteException var37) {
				FFDCFilter.processException(var37,
						"com.ibm.ejs.container.activator.ReadOnlyEntityActivationStrategy.atActivate", "135", this);
				exception = var37;
				throw var37;
			} catch (RuntimeException var38) {
				FFDCFilter.processException(var38,
						"com.ibm.ejs.container.activator.ReadOnlyEntityActivationStrategy.atActivate", "313", this);
				exception = var38;
				throw var38;
			} catch (Throwable var39) {
				FFDCFilter.processException(var39,
						"com.ibm.ejs.container.activator.ReadOnlyEntityActivationStrategy.atActivate", "319", this);
				exception = var39;
				throw ExceptionUtil.EJBException(var39);
			} finally {
				if (var31) {
					if (exception != null) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
							Tr.event(tc, "atActivate: exception raised", exception);
						}

						try {
							if (enlisted) {
								tx.delist(bean);
							}

							if (pinned) {
								synchronized (this.locks.getLock(key)) {
									this.cache.remove(key, true);
								}
							}

							if (bean != null) {
								if (pushedCallbackBeanO) {
									threadData.popCallbackBeanO();
								}

								bean.destroy();
							}
						} catch (IllegalOperationException var40) {
							if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
								Tr.debug(tc, "atActivate: cache remove failed,  just unpinning, not unlocking");
							}

							this.cache.unpin(key);
						}

						if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
							Tr.exit(tc, "atActivate: " + exception);
						}
					}

				}
			}

			if (exception != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "atActivate: exception raised", exception);
				}

				try {
					if (enlisted) {
						tx.delist(bean);
					}

					if (pinned) {
						synchronized (this.locks.getLock(key)) {
							this.cache.remove(key, true);
						}
					}

					if (bean != null) {
						if (pushedCallbackBeanO) {
							threadData.popCallbackBeanO();
						}

						bean.destroy();
					}
				} catch (IllegalOperationException var42) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "atActivate: cache remove failed,  just unpinning, not unlocking");
					}

					this.cache.unpin(key);
				}

				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "atActivate: " + exception);
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atActivate: " + bean);
		}

		return bean;
	}

	void atPostInvoke(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "atPostInvoke (" + bean + ")", tx);
		}

	}

	BeanO atCreate(ContainerTx tx, BeanO bean) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "atCreate should never be called!!!");
		}

		throw new ContainerInternalError(new CreateException("Attempt made to create Read Only EJB"));
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit (" + bean + ")", tx);
		}

		if (tx.getContainerAS() == null) {
			this.commonUnitOfWorkEnd(bean);
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "ActivitySession present - cache pin held");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCommit");
		}

	}

	void atRollback(ContainerTx tx, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRollback (" + bean + ")", tx);
		}

		if (tx.getContainerAS() == null) {
			this.commonUnitOfWorkEnd(bean);
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "ActivitySession present - cache pin held");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRollback");
		}

	}

	void atUnitOfWorkEnd(ContainerAS as, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atUnitOfWorkEnd (" + bean + ")", as);
		}

		this.commonUnitOfWorkEnd(bean);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atUnitOfWorkEnd");
		}

	}

	private void commonUnitOfWorkEnd(BeanO bean) {
		BeanO removedBean = null;
		TimeoutKey key = (TimeoutKey) bean.ivCacheKey;
		synchronized (this.locks.getLock(key)) {
			int pinned = this.cache.unpin(key);
			if (pinned == 0) {
				if (key.expirationDetected()) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Bean expired / no pins -> removing from Cache");
					}

					removedBean = (BeanO) this.cache.remove(key, false);
				} else {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Marking Bean no longer in use");
					}

					key.setInUse(false);
				}
			} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "Bean in use by other threads : " + pinned);
			}
		}

		if (removedBean != null) {
			try {
				removedBean.passivate();
			} catch (RemoteException var8) {
				FFDCFilter.processException(var8,
						"com.ibm.ejs.container.activator.ReadOnlyEntityActivationStrategy.atUnitOfWorkEnd", "320",
						this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "Exception while passivating bean", var8);
				}
			}
		}

	}

	BeanO atGet(ContainerTx tx, BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atGet (" + beanId + ")", tx);
		}

		BeanO result = null;
		TimeoutKey key = new TimeoutKey(beanId);
		synchronized (this.locks.getLock(key)) {
			result = (BeanO) this.cache.find(key);
			if (result != null) {
				this.cache.unpin(key);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atGet : " + result);
		}

		return result;
	}

	void atDiscard(BeanO bean) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atDiscard (" + bean + ")");
		}

		try {
			bean.ivCacheKey = null;
			bean.passivate();
		} catch (RemoteException var3) {
			FFDCFilter.processException(var3,
					"com.ibm.ejs.container.activator.ReadOnlyEntityActivationStrategy.atDiscard", "423", this);
			Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{bean, this, var3});
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atDiscard", var3);
			}

			throw var3;
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "atDiscard");
		}

	}

	void atUninstall(BeanId beanId, BeanO bean) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "atUninstall (" + bean + ")");
		}

		Object key = bean.ivCacheKey;
		if (key == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUninstall: ReadOnly bean already removed");
			}

		} else {
			synchronized (this.locks.getLock(key)) {
				try {
					bean = (BeanO) this.cache.remove(key, false);
					if (bean != null) {
						if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
							Tr.debug(tc, "ReadOnly bean removed from EJB Cache");
						}

						bean.ivCacheKey = null;
						bean.destroy();
					} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "ReadOnly bean NOT found in EJB Cache");
					}
				} catch (IllegalOperationException var7) {
					FFDCFilter.processException(var7,
							"com.ibm.ejs.container.activator.ReadOnlyEntityActivationStrategy.atUninstall", "457",
							this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
						Tr.event(tc, "Unable to remove uninstalled bean instance", var7);
					}

					((TimeoutKey) key).setDiscarded();
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUninstall");
			}

		}
	}
}