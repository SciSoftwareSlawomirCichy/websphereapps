package com.ibm.ejs.util.debug;

interface package-info {
}