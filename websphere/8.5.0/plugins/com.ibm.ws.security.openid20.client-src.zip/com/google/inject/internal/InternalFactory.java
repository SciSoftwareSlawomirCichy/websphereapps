package com.google.inject.internal;

import com.google.inject.spi.Dependency;

public interface InternalFactory<T> {
	T get(Errors var1, InternalContext var2, Dependency<?> var3) throws ErrorsException;
}