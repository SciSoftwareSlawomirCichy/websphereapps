package com.ibm.ws.ffdc.impl;

import com.ibm.ffdc.config.Formatter;
import com.ibm.ws.ffdc.FFDCSelfIntrospectable;
import com.ibm.ws.ffdc.impl.Formatters.1;
import com.ibm.ws.ffdc.impl.Formatters.2;
import com.ibm.ws.ffdc.impl.Formatters.IntrospectSelfFormatter;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedActionException;

public class Formatters extends com.ibm.ffdc.util.provider.Formatters<FfdcProvider> {
	public Formatters(FfdcProvider provider) {
		super(provider);
	}

	protected <T> Formatter makeFormatter(Class<T> cl) throws PrivilegedActionException {
      Formatter f = super.makeFormatter(cl);
      if (!this.isIntrospector(f)) {
         return f;
      } else {
         Method introspectSelfMethod;
         if (FFDCSelfIntrospectable.class.isAssignableFrom(cl)) {
            introspectSelfMethod = (Method)AccessController.doPrivileged(new 1(this, cl));
            return (Formatter)(introspectSelfMethod == null ? f : new IntrospectSelfFormatter(cl, introspectSelfMethod));
         } else {
            introspectSelfMethod = (Method)AccessController.doPrivileged(new 2(this, cl));
            return (Formatter)(introspectSelfMethod == null ? f : new IntrospectSelfFormatter(cl, introspectSelfMethod));
         }
      }
   }
}