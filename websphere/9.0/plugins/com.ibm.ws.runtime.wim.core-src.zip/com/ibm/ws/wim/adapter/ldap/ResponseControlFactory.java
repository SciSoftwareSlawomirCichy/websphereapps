package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.ras.WIMLogger;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.naming.ldap.Control;
import javax.naming.ldap.ControlFactory;

public class ResponseControlFactory extends ControlFactory {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public Control getControlInstance(Control var1) throws NamingException {
		Object var3 = null;

		try {
			if ("1.3.6.1.4.1.42.2.27.8.5.1".equals(var1.getID())) {
				var3 = new PasswordPolicyResponseControl(var1);
			} else {
				var3 = var1;
			}
		} catch (Exception var5) {
			trcLogger.logp(Level.WARNING, CLASSNAME, "getControlInstance",
					"Failure while trying to create  a password policy control");
		}

		return (Control) var3;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2014;
		CLASSNAME = ResponseControlFactory.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}