package com.google.common.io;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.io.CharStreams.NullWriter;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.List;

@Beta
@GwtIncompatible
public final class CharStreams {
	private static final int DEFAULT_BUF_SIZE = 2048;

	static CharBuffer createBuffer() {
		return CharBuffer.allocate(2048);
	}

	@CanIgnoreReturnValue
	public static long copy(Readable from, Appendable to) throws IOException {
		if (from instanceof Reader) {
			return to instanceof StringBuilder
					? copyReaderToBuilder((Reader) from, (StringBuilder) to)
					: copyReaderToWriter((Reader) from, asWriter(to));
		} else {
			Preconditions.checkNotNull(from);
			Preconditions.checkNotNull(to);
			long total = 0L;
			CharBuffer buf = createBuffer();

			while (from.read(buf) != -1) {
				buf.flip();
				to.append(buf);
				total += (long) buf.remaining();
				buf.clear();
			}

			return total;
		}
	}

	@CanIgnoreReturnValue
	static long copyReaderToBuilder(Reader from, StringBuilder to) throws IOException {
		Preconditions.checkNotNull(from);
		Preconditions.checkNotNull(to);
		char[] buf = new char[2048];

		int nRead;
		long total;
		for (total = 0L; (nRead = from.read(buf)) != -1; total += (long) nRead) {
			to.append(buf, 0, nRead);
		}

		return total;
	}

	@CanIgnoreReturnValue
	static long copyReaderToWriter(Reader from, Writer to) throws IOException {
		Preconditions.checkNotNull(from);
		Preconditions.checkNotNull(to);
		char[] buf = new char[2048];

		int nRead;
		long total;
		for (total = 0L; (nRead = from.read(buf)) != -1; total += (long) nRead) {
			to.write(buf, 0, nRead);
		}

		return total;
	}

	public static String toString(Readable r) throws IOException {
		return toStringBuilder(r).toString();
	}

	private static StringBuilder toStringBuilder(Readable r) throws IOException {
		StringBuilder sb = new StringBuilder();
		if (r instanceof Reader) {
			copyReaderToBuilder((Reader) r, sb);
		} else {
			copy(r, sb);
		}

		return sb;
	}

	public static List<String> readLines(Readable r) throws IOException {
		List<String> result = new ArrayList();
		LineReader lineReader = new LineReader(r);

		String line;
		while ((line = lineReader.readLine()) != null) {
			result.add(line);
		}

		return result;
	}

	@CanIgnoreReturnValue
	public static <T> T readLines(Readable readable, LineProcessor<T> processor) throws IOException {
		Preconditions.checkNotNull(readable);
		Preconditions.checkNotNull(processor);
		LineReader lineReader = new LineReader(readable);

		String line;
		while ((line = lineReader.readLine()) != null && processor.processLine(line)) {
			;
		}

		return processor.getResult();
	}

	@CanIgnoreReturnValue
	public static long exhaust(Readable readable) throws IOException {
		long total = 0L;
		CharBuffer buf = createBuffer();

		long read;
		while ((read = (long) readable.read(buf)) != -1L) {
			total += read;
			buf.clear();
		}

		return total;
	}

	public static void skipFully(Reader reader, long n) throws IOException {
		Preconditions.checkNotNull(reader);

		while (n > 0L) {
			long amt = reader.skip(n);
			if (amt == 0L) {
				throw new EOFException();
			}

			n -= amt;
		}

	}

	public static Writer nullWriter() {
		return NullWriter.access$000();
	}

	public static Writer asWriter(Appendable target) {
		return (Writer) (target instanceof Writer ? (Writer) target : new AppendableWriter(target));
	}
}