package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface LdapEntityTypesType {
	List getRdnAttributes();

	RdnAttributesType[] getRdnAttributesAsArray();

	RdnAttributesType createRdnAttributes();

	List getObjectClasses();

	String[] getObjectClassesAsArray();

	List getObjectClassesForCreate();

	String[] getObjectClassesForCreateAsArray();

	List getSearchBases();

	String[] getSearchBasesAsArray();

	String getName();

	void setName(String var1);

	String getSearchFilter();

	void setSearchFilter(String var1);
}