package com.google.inject;

import com.google.inject.Key.AnnotationInstanceStrategy;
import com.google.inject.Key.AnnotationStrategy;
import com.google.inject.Key.AnnotationTypeStrategy;
import com.google.inject.Key.NullAnnotationStrategy;
import com.google.inject.internal.Annotations;
import com.google.inject.internal.MoreTypes;
import com.google.inject.internal.Preconditions;
import com.google.inject.internal.ToStringBuilder;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

public class Key<T> {
	private final AnnotationStrategy annotationStrategy;
	private final TypeLiteral<T> typeLiteral;
	private final int hashCode;

	protected Key(Class<? extends Annotation> annotationType) {
		this.annotationStrategy = strategyFor(annotationType);
		this.typeLiteral = TypeLiteral.fromSuperclassTypeParameter(this.getClass());
		this.hashCode = this.computeHashCode();
	}

	protected Key(Annotation annotation) {
		this.annotationStrategy = strategyFor(annotation);
		this.typeLiteral = TypeLiteral.fromSuperclassTypeParameter(this.getClass());
		this.hashCode = this.computeHashCode();
	}

	protected Key() {
		this.annotationStrategy = NullAnnotationStrategy.INSTANCE;
		this.typeLiteral = TypeLiteral.fromSuperclassTypeParameter(this.getClass());
		this.hashCode = this.computeHashCode();
	}

	private Key(Type type, AnnotationStrategy annotationStrategy) {
		this.annotationStrategy = annotationStrategy;
		this.typeLiteral = MoreTypes.makeKeySafe(TypeLiteral.get(type));
		this.hashCode = this.computeHashCode();
	}

	private Key(TypeLiteral<T> typeLiteral, AnnotationStrategy annotationStrategy) {
		this.annotationStrategy = annotationStrategy;
		this.typeLiteral = MoreTypes.makeKeySafe(typeLiteral);
		this.hashCode = this.computeHashCode();
	}

	private int computeHashCode() {
		return this.typeLiteral.hashCode() * 31 + this.annotationStrategy.hashCode();
	}

	public final TypeLiteral<T> getTypeLiteral() {
		return this.typeLiteral;
	}

	public final Class<? extends Annotation> getAnnotationType() {
		return this.annotationStrategy.getAnnotationType();
	}

	public final Annotation getAnnotation() {
		return this.annotationStrategy.getAnnotation();
	}

	boolean hasAnnotationType() {
		return this.annotationStrategy.getAnnotationType() != null;
	}

	String getAnnotationName() {
		Annotation annotation = this.annotationStrategy.getAnnotation();
		return annotation != null ? annotation.toString() : this.annotationStrategy.getAnnotationType().toString();
	}

	Class<? super T> getRawType() {
		return this.typeLiteral.getRawType();
	}

	Key<Provider<T>> providerKey() {
		return this.ofType(this.typeLiteral.providerType());
	}

	public final boolean equals(Object o) {
		if (o == this) {
			return true;
		} else if (!(o instanceof Key)) {
			return false;
		} else {
			Key<?> other = (Key) o;
			return this.annotationStrategy.equals(other.annotationStrategy)
					&& this.typeLiteral.equals(other.typeLiteral);
		}
	}

	public final int hashCode() {
		return this.hashCode;
	}

	public final String toString() {
		return (new ToStringBuilder(Key.class)).add("type", this.typeLiteral).add("annotation", this.annotationStrategy)
				.toString();
	}

	static <T> Key<T> get(Class<T> type, AnnotationStrategy annotationStrategy) {
		return new Key(type, annotationStrategy);
	}

	public static <T> Key<T> get(Class<T> type) {
		return new Key(type, NullAnnotationStrategy.INSTANCE);
	}

	public static <T> Key<T> get(Class<T> type, Class<? extends Annotation> annotationType) {
		return new Key(type, strategyFor(annotationType));
	}

	public static <T> Key<T> get(Class<T> type, Annotation annotation) {
		return new Key(type, strategyFor(annotation));
	}

	public static Key<?> get(Type type) {
		return new Key(type, NullAnnotationStrategy.INSTANCE);
	}

	public static Key<?> get(Type type, Class<? extends Annotation> annotationType) {
		return new Key(type, strategyFor(annotationType));
	}

	public static Key<?> get(Type type, Annotation annotation) {
		return new Key(type, strategyFor(annotation));
	}

	public static <T> Key<T> get(TypeLiteral<T> typeLiteral) {
		return new Key(typeLiteral, NullAnnotationStrategy.INSTANCE);
	}

	public static <T> Key<T> get(TypeLiteral<T> typeLiteral, Class<? extends Annotation> annotationType) {
		return new Key(typeLiteral, strategyFor(annotationType));
	}

	public static <T> Key<T> get(TypeLiteral<T> typeLiteral, Annotation annotation) {
		return new Key(typeLiteral, strategyFor(annotation));
	}

	<T> Key<T> ofType(Class<T> type) {
		return new Key(type, this.annotationStrategy);
	}

	Key<?> ofType(Type type) {
		return new Key(type, this.annotationStrategy);
	}

	<T> Key<T> ofType(TypeLiteral<T> type) {
		return new Key(type, this.annotationStrategy);
	}

	boolean hasAttributes() {
		return this.annotationStrategy.hasAttributes();
	}

	Key<T> withoutAttributes() {
		return new Key(this.typeLiteral, this.annotationStrategy.withoutAttributes());
	}

	static boolean isMarker(Class<? extends Annotation> annotationType) {
		return annotationType.getDeclaredMethods().length == 0;
	}

	static AnnotationStrategy strategyFor(Annotation annotation) {
		Preconditions.checkNotNull(annotation, "annotation");
		Class<? extends Annotation> annotationType = annotation.annotationType();
		ensureRetainedAtRuntime(annotationType);
		ensureIsBindingAnnotation(annotationType);
		return (AnnotationStrategy) (annotationType.getDeclaredMethods().length == 0
				? new AnnotationTypeStrategy(annotationType, annotation)
				: new AnnotationInstanceStrategy(annotation));
	}

	static AnnotationStrategy strategyFor(Class<? extends Annotation> annotationType) {
		Preconditions.checkNotNull(annotationType, "annotation type");
		ensureRetainedAtRuntime(annotationType);
		ensureIsBindingAnnotation(annotationType);
		return new AnnotationTypeStrategy(annotationType, (Annotation) null);
	}

	private static void ensureRetainedAtRuntime(Class<? extends Annotation> annotationType) {
		Preconditions.checkArgument(Annotations.isRetainedAtRuntime(annotationType),
				"%s is not retained at runtime. Please annotate it with @Retention(RUNTIME).",
				new Object[]{annotationType.getName()});
	}

	private static void ensureIsBindingAnnotation(Class<? extends Annotation> annotationType) {
		Preconditions.checkArgument(isBindingAnnotation(annotationType),
				"%s is not a binding annotation. Please annotate it with @BindingAnnotation.",
				new Object[]{annotationType.getName()});
	}

	static boolean isBindingAnnotation(Annotation annotation) {
		return isBindingAnnotation(annotation.annotationType());
	}

	static boolean isBindingAnnotation(Class<? extends Annotation> annotationType) {
		return annotationType.isAnnotationPresent(BindingAnnotation.class);
	}
}