package com.ibm.ws.wim.lookaside;

public class LACompositePropertyValue {
	private long compositeAttributeValueId;
	private int attributeId;
	private long entityId;
	private long compositeId;

	public long getCompositeId() {
		return this.compositeId;
	}

	public void setCompositeId(long var1) {
		this.compositeId = var1;
	}

	public int getAttributeId() {
		return this.attributeId;
	}

	public void setAttributeId(int var1) {
		this.attributeId = var1;
	}

	public long getCompositeAttributeValueId() {
		return this.compositeAttributeValueId;
	}

	public void setCompositeAttributeValueId(long var1) {
		this.compositeAttributeValueId = var1;
	}

	public long getEntityId() {
		return this.entityId;
	}

	public void setEntityId(long var1) {
		this.entityId = var1;
	}
}