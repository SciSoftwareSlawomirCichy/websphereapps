package com.ibm.ws.wim.dao.db2zos;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.ws.wim.dao.QuerySet;

public class DB2ZOSQuerySet extends QuerySet {
	static final String COPYRIGHT_NOTICE;

	public DB2ZOSQuerySet() {
		this.initDB2ZSQL();
	}

	public DB2ZOSQuerySet(String var1) {
		super(var1);
		this.initDB2ZSQL();
	}

	public void initDB2ZSQL() {
		this.UNION = " UNION ALL ";
		this.updateDBStringValueWithOldValue = "UPDATE " + this.DBSTRPROP
				+ " SET PROPVALUE = ?, VALUE_KEY= ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND VALUE_KEY LIKE ?";
		this.updateLAStringValueWithOldValue = "UPDATE " + this.LASTRPROP
				+ " SET PROPVALUE = ?, VALUE_KEY= ? WHERE PROP_ID = ? AND ENTITY_ID = ? AND VALUE_KEY LIKE ?";
		this.selectGEntIdwithGNames = "SELECT ENTITY_ID FROM " + this.DBENTITY + " WHERE UNIQUE_NAME_KEY LIKE ?";
		this.findDescendantsByUniqueNames = "SELECT DESCENDANT_ID FROM " + this.DBENTREL + ", " + this.DBENTITY
				+ " WHERE ANCESTOR_ID = ENTITY_ID AND UNIQUE_NAME_KEY LIKE ?";
		this.findUniqueIdByUniqueNameKey = "SELECT UNIQUE_ID FROM " + this.DBENTITY + " WHERE UNIQUE_NAME_KEY LIKE ?";
		this.findDBEntityByUniqueNameKey = "SELECT ENTITY_ID, ENTITY_TYPE, UNIQUE_ID, UNIQUE_NAME, UNIQUE_NAME_KEY FROM "
				+ this.DBENTITY + " WHERE UNIQUE_NAME_KEY LIKE ?";
		this.findChildrenByUniqueNameKey = "SELECT T2.DESCENDANT_ID FROM " + this.DBENTITY + " T1, " + this.DBENTREL
				+ " T2, " + this.DBENTITY
				+ " T3 WHERE T1.ENTITY_ID = T2.ANCESTOR_ID AND T1.UNIQUE_NAME_KEY LIKE ? AND T2.DESCENDANT_ID = T3.ENTITY_ID ";
		this.findDBEntityIdByTruncUniqueName = "SELECT ENTITY_ID FROM " + this.DBENTITY
				+ " WHERE UNIQUE_NAME_KEY LIKE ?";
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
	}
}