package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import java.util.Collection;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.InternalEList;

public class FileRepositoryTypeImpl extends ProfileRepositoryTypeImpl implements FileRepositoryType {
	protected static final String BASE_DIRECTORY_EDEFAULT = null;
	protected String baseDirectory;
	protected static final boolean CASE_SENSITIVE_EDEFAULT = false;
	protected boolean caseSensitive;
	protected boolean caseSensitiveESet;
	protected static final String FILE_NAME_EDEFAULT = null;
	protected String fileName;
	protected static final String MESSAGE_DIGEST_ALGORITHM_EDEFAULT = "PBKDF2WithHmacSHA1";
	protected String messageDigestAlgorithm;
	protected boolean messageDigestAlgorithmESet;
	protected static final int SALT_LENGTH_EDEFAULT = 32;
	protected int saltLength;
	protected boolean saltLengthESet;
	protected static final int KEY_LENGTH_EDEFAULT = 32;
	protected int keyLength;
	protected boolean keyLengthESet;
	protected static final int HASH_ITERATIONS_EDEFAULT = 100000;
	protected int hashIterations;
	protected boolean hashIterationsESet;
	protected static final int ACCOUNT_LOCKOUT_THRESHOLD_EDEFAULT = 5;
	protected int accountLockoutThreshold;
	protected boolean accountLockoutThresholdESet;
	protected static final int ACCOUNT_LOCKOUT_DURATION_EDEFAULT = 15;
	protected int accountLockoutDuration;
	protected boolean accountLockoutDurationESet;
	protected static final int IGNORE_FAILED_LOGIN_AFTER_EDEFAULT = 15;
	protected int ignoreFailedLoginAfter;
	protected boolean ignoreFailedLoginAfterESet;

	protected FileRepositoryTypeImpl() {
		this.baseDirectory = BASE_DIRECTORY_EDEFAULT;
		this.caseSensitive = false;
		this.caseSensitiveESet = false;
		this.fileName = FILE_NAME_EDEFAULT;
		this.messageDigestAlgorithm = "PBKDF2WithHmacSHA1";
		this.messageDigestAlgorithmESet = false;
		this.saltLength = 32;
		this.saltLengthESet = false;
		this.keyLength = 32;
		this.keyLengthESet = false;
		this.hashIterations = 100000;
		this.hashIterationsESet = false;
		this.accountLockoutThreshold = 5;
		this.accountLockoutThresholdESet = false;
		this.accountLockoutDuration = 15;
		this.accountLockoutDurationESet = false;
		this.ignoreFailedLoginAfter = 15;
		this.ignoreFailedLoginAfterESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getFileRepositoryType();
	}

	public String getBaseDirectory() {
		return this.baseDirectory;
	}

	public void setBaseDirectory(String var1) {
		String var2 = this.baseDirectory;
		this.baseDirectory = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 18, var2, this.baseDirectory));
		}

	}

	public boolean isCaseSensitive() {
		return this.caseSensitive;
	}

	public void setCaseSensitive(boolean var1) {
		boolean var2 = this.caseSensitive;
		this.caseSensitive = var1;
		boolean var3 = this.caseSensitiveESet;
		this.caseSensitiveESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 19, var2, this.caseSensitive, !var3));
		}

	}

	public void unsetCaseSensitive() {
		boolean var1 = this.caseSensitive;
		boolean var2 = this.caseSensitiveESet;
		this.caseSensitive = false;
		this.caseSensitiveESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 19, var1, false, var2));
		}

	}

	public boolean isSetCaseSensitive() {
		return this.caseSensitiveESet;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String var1) {
		String var2 = this.fileName;
		this.fileName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 20, var2, this.fileName));
		}

	}

	public String getMessageDigestAlgorithm() {
		return this.messageDigestAlgorithm;
	}

	public void setMessageDigestAlgorithm(String var1) {
		String var2 = this.messageDigestAlgorithm;
		this.messageDigestAlgorithm = var1;
		boolean var3 = this.messageDigestAlgorithmESet;
		this.messageDigestAlgorithmESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 21, var2, this.messageDigestAlgorithm, !var3));
		}

	}

	public void unsetMessageDigestAlgorithm() {
		String var1 = this.messageDigestAlgorithm;
		boolean var2 = this.messageDigestAlgorithmESet;
		this.messageDigestAlgorithm = "PBKDF2WithHmacSHA1";
		this.messageDigestAlgorithmESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 21, var1, "PBKDF2WithHmacSHA1", var2));
		}

	}

	public boolean isSetMessageDigestAlgorithm() {
		return this.messageDigestAlgorithmESet;
	}

	public int getSaltLength() {
		return this.saltLength;
	}

	public void setSaltLength(int var1) {
		int var2 = this.saltLength;
		this.saltLength = var1;
		boolean var3 = this.saltLengthESet;
		this.saltLengthESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 22, var2, this.saltLength, !var3));
		}

	}

	public void unsetSaltLength() {
		int var1 = this.saltLength;
		boolean var2 = this.saltLengthESet;
		this.saltLength = 32;
		this.saltLengthESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 22, var1, 32, var2));
		}

	}

	public boolean isSetSaltLength() {
		return this.saltLengthESet;
	}

	public int getKeyLength() {
		return this.keyLength;
	}

	public void setKeyLength(int var1) {
		int var2 = this.keyLength;
		this.keyLength = var1;
		boolean var3 = this.keyLengthESet;
		this.keyLengthESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 23, var2, this.saltLength, !var3));
		}

	}

	public void unsetKeyLength() {
		int var1 = this.keyLength;
		boolean var2 = this.keyLengthESet;
		this.keyLength = 32;
		this.keyLengthESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 23, var1, 32, var2));
		}

	}

	public boolean isSetKeyLength() {
		return this.keyLengthESet;
	}

	public int getHashIterations() {
		return this.hashIterations;
	}

	public void setHashIterations(int var1) {
		int var2 = this.hashIterations;
		this.hashIterations = var1;
		boolean var3 = this.hashIterationsESet;
		this.hashIterationsESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 24, var2, this.hashIterations, !var3));
		}

	}

	public void unsetHashIterations() {
		int var1 = this.hashIterations;
		boolean var2 = this.hashIterationsESet;
		this.hashIterations = 100000;
		this.hashIterationsESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 24, var1, 100000, var2));
		}

	}

	public boolean isSetHashIterations() {
		return this.hashIterationsESet;
	}

	public int getAccountLockoutThreshold() {
		return this.accountLockoutThreshold;
	}

	public void setAccountLockoutThreshold(int var1) {
		int var2 = this.accountLockoutThreshold;
		this.accountLockoutThreshold = var1;
		boolean var3 = this.accountLockoutThresholdESet;
		this.accountLockoutThresholdESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 25, var2, this.accountLockoutThreshold, !var3));
		}

	}

	public void unsetAccountLockoutThreshold() {
		int var1 = this.accountLockoutThreshold;
		boolean var2 = this.accountLockoutThresholdESet;
		this.accountLockoutThreshold = 5;
		this.accountLockoutThresholdESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 25, var1, 5, var2));
		}

	}

	public boolean isSetAccountLockoutThreshold() {
		return this.accountLockoutThresholdESet;
	}

	public int getAccountLockoutDuration() {
		return this.accountLockoutDuration;
	}

	public void setAccountLockoutDuration(int var1) {
		int var2 = this.accountLockoutDuration;
		this.accountLockoutDuration = var1;
		boolean var3 = this.accountLockoutDurationESet;
		this.accountLockoutDurationESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 26, var2, this.accountLockoutDuration, !var3));
		}

	}

	public void unsetAccountLockoutDuration() {
		int var1 = this.accountLockoutDuration;
		boolean var2 = this.accountLockoutDurationESet;
		this.accountLockoutDuration = 15;
		this.accountLockoutDurationESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 26, var1, 15, var2));
		}

	}

	public boolean isSetAccountLockoutDuration() {
		return this.accountLockoutDurationESet;
	}

	public int getIgnoreFailedLoginAfter() {
		return this.ignoreFailedLoginAfter;
	}

	public void setIgnoreFailedLoginAfter(int var1) {
		int var2 = this.ignoreFailedLoginAfter;
		this.ignoreFailedLoginAfter = var1;
		boolean var3 = this.ignoreFailedLoginAfterESet;
		this.ignoreFailedLoginAfterESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 27, var2, this.ignoreFailedLoginAfter, !var3));
		}

	}

	public void unsetIgnoreFailedLoginAfter() {
		int var1 = this.ignoreFailedLoginAfter;
		boolean var2 = this.ignoreFailedLoginAfterESet;
		this.ignoreFailedLoginAfter = 15;
		this.ignoreFailedLoginAfterESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 27, var1, 15, var2));
		}

	}

	public boolean isSetIgnoreFailedLoginAfter() {
		return this.ignoreFailedLoginAfterESet;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 2 :
					return ((InternalEList) this.getBaseEntries()).basicRemove(var1, var4);
				case 9 :
					return ((InternalEList) this.getCustomProperties()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getAdapterClassName();
			case 1 :
				return this.getId();
			case 2 :
				return this.getBaseEntries();
			case 3 :
				return this.getEntityTypesNotAllowCreate();
			case 4 :
				return this.getEntityTypesNotAllowUpdate();
			case 5 :
				return this.getEntityTypesNotAllowRead();
			case 6 :
				return this.getEntityTypesNotAllowDelete();
			case 7 :
				return this.getRepositoriesForGroups();
			case 8 :
				return this.getLoginProperties();
			case 9 :
				return this.getCustomProperties();
			case 10 :
				return this.isIsExtIdUnique() ? Boolean.TRUE : Boolean.FALSE;
			case 11 :
				return this.isReadOnly() ? Boolean.TRUE : Boolean.FALSE;
			case 12 :
				return this.isSupportAsyncMode() ? Boolean.TRUE : Boolean.FALSE;
			case 13 :
				return this.isSupportExternalName() ? Boolean.TRUE : Boolean.FALSE;
			case 14 :
				return this.isSupportPaging() ? Boolean.TRUE : Boolean.FALSE;
			case 15 :
				return this.isSupportSorting() ? Boolean.TRUE : Boolean.FALSE;
			case 16 :
				return this.isSupportTransactions() ? Boolean.TRUE : Boolean.FALSE;
			case 17 :
				return this.getSupportChangeLog();
			case 18 :
				return this.getBaseDirectory();
			case 19 :
				return this.isCaseSensitive() ? Boolean.TRUE : Boolean.FALSE;
			case 20 :
				return this.getFileName();
			case 21 :
				return this.getMessageDigestAlgorithm();
			case 22 :
				return new Integer(this.getSaltLength());
			case 23 :
				return new Integer(this.getKeyLength());
			case 24 :
				return new Integer(this.getHashIterations());
			case 25 :
				return new Integer(this.getAccountLockoutThreshold());
			case 26 :
				return new Integer(this.getAccountLockoutDuration());
			case 27 :
				return new Integer(this.getIgnoreFailedLoginAfter());
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName((String) var2);
				return;
			case 1 :
				this.setId((String) var2);
				return;
			case 2 :
				this.getBaseEntries().clear();
				this.getBaseEntries().addAll((Collection) var2);
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				this.getEntityTypesNotAllowCreate().addAll((Collection) var2);
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				this.getEntityTypesNotAllowUpdate().addAll((Collection) var2);
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				this.getEntityTypesNotAllowRead().addAll((Collection) var2);
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				this.getEntityTypesNotAllowDelete().addAll((Collection) var2);
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				this.getRepositoriesForGroups().addAll((Collection) var2);
				return;
			case 8 :
				this.getLoginProperties().clear();
				this.getLoginProperties().addAll((Collection) var2);
				return;
			case 9 :
				this.getCustomProperties().clear();
				this.getCustomProperties().addAll((Collection) var2);
				return;
			case 10 :
				this.setIsExtIdUnique((Boolean) var2);
				return;
			case 11 :
				this.setReadOnly((Boolean) var2);
				return;
			case 12 :
				this.setSupportAsyncMode((Boolean) var2);
				return;
			case 13 :
				this.setSupportExternalName((Boolean) var2);
				return;
			case 14 :
				this.setSupportPaging((Boolean) var2);
				return;
			case 15 :
				this.setSupportSorting((Boolean) var2);
				return;
			case 16 :
				this.setSupportTransactions((Boolean) var2);
				return;
			case 17 :
				this.setSupportChangeLog((String) var2);
				return;
			case 18 :
				this.setBaseDirectory((String) var2);
				return;
			case 19 :
				this.setCaseSensitive((Boolean) var2);
				return;
			case 20 :
				this.setFileName((String) var2);
				return;
			case 21 :
				this.setMessageDigestAlgorithm((String) var2);
				return;
			case 22 :
				this.setSaltLength((Integer) var2);
				return;
			case 23 :
				this.setKeyLength((Integer) var2);
				return;
			case 24 :
				this.setHashIterations((Integer) var2);
				return;
			case 25 :
				this.setAccountLockoutThreshold((Integer) var2);
				return;
			case 26 :
				this.setAccountLockoutDuration((Integer) var2);
				return;
			case 27 :
				this.setIgnoreFailedLoginAfter((Integer) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setAdapterClassName(ADAPTER_CLASS_NAME_EDEFAULT);
				return;
			case 1 :
				this.setId(ID_EDEFAULT);
				return;
			case 2 :
				this.getBaseEntries().clear();
				return;
			case 3 :
				this.getEntityTypesNotAllowCreate().clear();
				return;
			case 4 :
				this.getEntityTypesNotAllowUpdate().clear();
				return;
			case 5 :
				this.getEntityTypesNotAllowRead().clear();
				return;
			case 6 :
				this.getEntityTypesNotAllowDelete().clear();
				return;
			case 7 :
				this.getRepositoriesForGroups().clear();
				return;
			case 8 :
				this.getLoginProperties().clear();
				return;
			case 9 :
				this.getCustomProperties().clear();
				return;
			case 10 :
				this.unsetIsExtIdUnique();
				return;
			case 11 :
				this.unsetReadOnly();
				return;
			case 12 :
				this.unsetSupportAsyncMode();
				return;
			case 13 :
				this.unsetSupportExternalName();
				return;
			case 14 :
				this.unsetSupportPaging();
				return;
			case 15 :
				this.unsetSupportSorting();
				return;
			case 16 :
				this.unsetSupportTransactions();
				return;
			case 17 :
				this.unsetSupportChangeLog();
				return;
			case 18 :
				this.setBaseDirectory(BASE_DIRECTORY_EDEFAULT);
				return;
			case 19 :
				this.unsetCaseSensitive();
				return;
			case 20 :
				this.setFileName(FILE_NAME_EDEFAULT);
				return;
			case 21 :
				this.unsetMessageDigestAlgorithm();
				return;
			case 22 :
				this.unsetSaltLength();
				return;
			case 23 :
				this.unsetKeyLength();
				return;
			case 24 :
				this.unsetHashIterations();
				return;
			case 25 :
				this.unsetAccountLockoutThreshold();
				return;
			case 26 :
				this.unsetAccountLockoutDuration();
				return;
			case 27 :
				this.unsetIgnoreFailedLoginAfter();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return ADAPTER_CLASS_NAME_EDEFAULT == null
						? this.adapterClassName != null
						: !ADAPTER_CLASS_NAME_EDEFAULT.equals(this.adapterClassName);
			case 1 :
				return ID_EDEFAULT == null ? this.id != null : !ID_EDEFAULT.equals(this.id);
			case 2 :
				return this.baseEntries != null && !this.baseEntries.isEmpty();
			case 3 :
				return this.entityTypesNotAllowCreate != null && !this.entityTypesNotAllowCreate.isEmpty();
			case 4 :
				return this.entityTypesNotAllowUpdate != null && !this.entityTypesNotAllowUpdate.isEmpty();
			case 5 :
				return this.entityTypesNotAllowRead != null && !this.entityTypesNotAllowRead.isEmpty();
			case 6 :
				return this.entityTypesNotAllowDelete != null && !this.entityTypesNotAllowDelete.isEmpty();
			case 7 :
				return this.repositoriesForGroups != null && !this.repositoriesForGroups.isEmpty();
			case 8 :
				return this.loginProperties != null && !this.loginProperties.isEmpty();
			case 9 :
				return this.customProperties != null && !this.customProperties.isEmpty();
			case 10 :
				return this.isSetIsExtIdUnique();
			case 11 :
				return this.isSetReadOnly();
			case 12 :
				return this.isSetSupportAsyncMode();
			case 13 :
				return this.isSetSupportExternalName();
			case 14 :
				return this.isSetSupportPaging();
			case 15 :
				return this.isSetSupportSorting();
			case 16 :
				return this.isSetSupportTransactions();
			case 17 :
				return this.isSetSupportChangeLog();
			case 18 :
				return BASE_DIRECTORY_EDEFAULT == null
						? this.baseDirectory != null
						: !BASE_DIRECTORY_EDEFAULT.equals(this.baseDirectory);
			case 19 :
				return this.isSetCaseSensitive();
			case 20 :
				return FILE_NAME_EDEFAULT == null ? this.fileName != null : !FILE_NAME_EDEFAULT.equals(this.fileName);
			case 21 :
				return this.isSetMessageDigestAlgorithm();
			case 22 :
				return this.isSetSaltLength();
			case 23 :
				return this.isSetKeyLength();
			case 24 :
				return this.isSetHashIterations();
			case 25 :
				return this.isSetAccountLockoutThreshold();
			case 26 :
				return this.isSetAccountLockoutDuration();
			case 27 :
				return this.isSetIgnoreFailedLoginAfter();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (baseDirectory: ");
			var1.append(this.baseDirectory);
			var1.append(", caseSensitive: ");
			if (this.caseSensitiveESet) {
				var1.append(this.caseSensitive);
			} else {
				var1.append("<unset>");
			}

			var1.append(", fileName: ");
			var1.append(this.fileName);
			var1.append(", messageDigestAlgorithm: ");
			if (this.messageDigestAlgorithmESet) {
				var1.append(this.messageDigestAlgorithm);
			} else {
				var1.append("<unset>");
			}

			var1.append(", saltLength: ");
			if (this.saltLengthESet) {
				var1.append(this.saltLength);
			} else {
				var1.append("<unset>");
			}

			var1.append(", keyLength: ");
			if (this.keyLengthESet) {
				var1.append(this.keyLength);
			} else {
				var1.append("<unset>");
			}

			var1.append(", hashIterations: ");
			if (this.hashIterationsESet) {
				var1.append(this.hashIterations);
			} else {
				var1.append("<unset>");
			}

			var1.append(", accountLockoutThreshold: ");
			if (this.accountLockoutThresholdESet) {
				var1.append(this.accountLockoutThreshold);
			} else {
				var1.append("<unset>");
			}

			var1.append(", accountLockoutDuration: ");
			if (this.accountLockoutDurationESet) {
				var1.append(this.accountLockoutDuration);
			} else {
				var1.append("<unset>");
			}

			var1.append(", ignoreFailedLoginAfter: ");
			if (this.ignoreFailedLoginAfterESet) {
				var1.append(this.ignoreFailedLoginAfter);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}