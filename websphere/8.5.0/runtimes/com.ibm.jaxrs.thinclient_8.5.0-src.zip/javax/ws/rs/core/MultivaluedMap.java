package javax.ws.rs.core;

import java.util.List;
import java.util.Map;

public interface MultivaluedMap<K, V> extends Map<K, List<V>> {
	void add(K var1, V var2);

	V getFirst(K var1);

	void putSingle(K var1, V var2);
}