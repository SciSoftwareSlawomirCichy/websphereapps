package com.ibm.ejs.oa.pool;

interface package-info {
}