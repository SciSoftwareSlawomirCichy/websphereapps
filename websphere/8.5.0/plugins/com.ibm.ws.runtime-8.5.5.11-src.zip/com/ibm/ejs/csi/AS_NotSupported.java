package com.ibm.ejs.csi;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.ws.ActivitySession.ActivitySession;
import javax.transaction.Transaction;

final class AS_NotSupported extends ActivitySessionStrategy {
	private static final TraceComponent tc = Tr.register(AS_NotSupported.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	AS_NotSupported(UOWControlImpl UOWCtrl) {
		super(UOWCtrl);
	}

	ASCookieImpl preInvoke(EJBKey key, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "preInvoke");
		}

		ActivitySession suspendedAS = null;
		if (this.ASExists()) {
			suspendedAS = this.suspendAS();
		}

		if (entryEnabled) {
			Tr.exit(tc, "preInvoke");
		}

		return new ASCookieImpl(false, this, suspendedAS, (Transaction) null);
	}

	void postInvoke(EJBKey key, ASCookieImpl ASCookie, EJBMethodInfoImpl methodInfo) throws CSIException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "postInvoke");
		}

		if (ASCookie.suspendedAS != null) {
			this.resumeAS(ASCookie.suspendedAS);
		}

		if (entryEnabled) {
			Tr.exit(tc, "postInvoke");
		}

	}
}