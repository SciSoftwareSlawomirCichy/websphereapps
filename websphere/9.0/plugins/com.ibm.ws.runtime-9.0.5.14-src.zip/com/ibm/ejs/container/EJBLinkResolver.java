package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.csi.J2EENameFactory;
import com.ibm.websphere.ejbcontainer.EJBFactory;
import com.ibm.ws.ejbcontainer.runtime.EJBRuntime;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import javax.ejb.EJBException;

public class EJBLinkResolver implements EJBFactory {
	private static final String CLASS_NAME = EJBLinkResolver.class.getName();
	private static final TraceComponent tc = Tr.register(EJBLinkResolver.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private HomeOfHomes homeOfHomes;
	private J2EENameFactory j2eeNameFactory;

	public EJBLinkResolver initialize(HomeOfHomes homeOfHomes, J2EENameFactory j2eeNameFactory) {
		this.homeOfHomes = homeOfHomes;
		this.j2eeNameFactory = j2eeNameFactory;
		return this;
	}

	public Object create(String application, String beanName, String interfaceName)
			throws EJBException, RemoteException {
		if (application == null) {
			throw new IllegalArgumentException("Application name not specified");
		} else if (beanName == null) {
			throw new IllegalArgumentException("Bean name not specified");
		} else if (interfaceName == null) {
			throw new IllegalArgumentException("Interface name not specified");
		} else {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "create : application = " + application + ", beanName = " + beanName + ", interface = "
						+ interfaceName);
			}

			EJSHome home = null;

			try {
				HomeRecord hr = this.homeOfHomes.resolveEJBLink(application, (String) null, beanName);
				home = hr.getHomeAndInitialize();
			} catch (Throwable var8) {
				FFDCFilter.processException(var8, CLASS_NAME + ".create", "186", this);
				EJBException ejbex = ExceptionUtil.EJBException("Failure locating " + beanName, var8);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "create: " + ejbex);
				}

				throw ejbex;
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "home = " + home.getJ2EEName());
			}

			Object retObj = this.create(home, interfaceName);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "create : " + retObj.getClass().getName());
			}

			return retObj;
		}
	}

	public Object create(String application, String module, String beanName, String interfaceName)
			throws EJBException, RemoteException {
		if (application == null) {
			throw new IllegalArgumentException("Application name not specified");
		} else if (module == null) {
			throw new IllegalArgumentException("Module name not specified");
		} else if (!module.endsWith(".jar") && !module.endsWith(".war")) {
			throw new IllegalArgumentException("Module must be a .jar or .war file");
		} else if (beanName == null) {
			throw new IllegalArgumentException("Bean name not specified");
		} else if (interfaceName == null) {
			throw new IllegalArgumentException("Interface name not specified");
		} else {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "create : application = " + application + ", module = " + module + ", bean = " + beanName
						+ ", interface = " + interfaceName);
			}

			Object retObj = null;
			EJSHome home = null;
			J2EEName j2eeName = null;

			try {
				j2eeName = this.j2eeNameFactory.create(application, module, beanName);
				home = (EJSHome) this.homeOfHomes.getHome(j2eeName);
				if (home == null) {
					throw new EJBNotFoundException("EJB named " + beanName + " not present in module " + module
							+ " of application " + application);
				}
			} catch (Throwable var11) {
				FFDCFilter.processException(var11, CLASS_NAME + ".create", "182", this);
				EJBException ejbex = ExceptionUtil.EJBException("Failure locating " + j2eeName, var11);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "create: " + ejbex);
				}

				throw ejbex;
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "home = " + home.getJ2EEName());
			}

			retObj = this.create(home, interfaceName);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "create : " + retObj.getClass().getName());
			}

			return retObj;
		}
	}

	private Object create(EJSHome home, String interfaceName) throws EJBException, RemoteException {
		BeanMetaData bmd = home.getBeanMetaData();
		if (interfaceName.equals(bmd.localHomeInterfaceClassName)) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "match on local home");
			}

			return home.getWrapper().getLocalObject();
		} else if (interfaceName.equals(bmd.homeInterfaceClassName)) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "match on remote home");
			}

			return this.getRemoteHomeReference(home, interfaceName);
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "looking for match on business interface");
			}

			return this.createBusinessObject(home, bmd, interfaceName, true);
		}
	}

	public Object findByBeanName(String application, String beanName, String interfaceName)
			throws EJBException, RemoteException {
		if (application == null) {
			throw new IllegalArgumentException("Application name not specified");
		} else if (beanName == null) {
			throw new IllegalArgumentException("Bean name not specified");
		} else if (interfaceName == null) {
			throw new IllegalArgumentException("Interface name not specified");
		} else {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "findByBeanName : App = " + application + ", bean = " + beanName + ", interface = "
						+ interfaceName);
			}

			Object retObj = null;
			EJSHome home = null;

			try {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "looking for home in all app modules...");
				}

				home = this.homeOfHomes.getHomeByName(application, beanName);
			} catch (Throwable var9) {
				FFDCFilter.processException(var9, CLASS_NAME + ".findByBeanName", "182", this);
				EJBException ejbex = ExceptionUtil
						.EJBException("Failure locating bean " + beanName + " in application " + application, var9);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "findByBeanName: " + ejbex);
				}

				throw ejbex;
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "home = " + home.getJ2EEName());
			}

			BeanMetaData bmd = home.getBeanMetaData();
			if (interfaceName.equals(bmd.localHomeInterfaceClassName)) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "match on local home");
				}

				retObj = home.getWrapper().getLocalObject();
			} else if (interfaceName.equals(bmd.homeInterfaceClassName)) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "match on remote home");
				}

				retObj = this.getRemoteHomeReference(home, interfaceName);
			} else {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "looking for match on business interface");
				}

				retObj = this.createBusinessObject(home, bmd, interfaceName, true);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "findByBeanName : " + retObj.getClass().getName());
			}

			return retObj;
		}
	}

	public Object findByInterface(String application, String interfaceName) throws EJBException, RemoteException {
		if (application == null) {
			throw new IllegalArgumentException("Application name not specified");
		} else if (interfaceName == null) {
			throw new IllegalArgumentException("Interface name not specified");
		} else {
			boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.entry(tc, "findByInterface : App = " + application + ", interface = " + interfaceName);
			}

			Object retObj = null;
			EJSHome home = null;

			try {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "bean name not specified, auto-link on " + interfaceName);
				}

				home = this.homeOfHomes.getHomeByInterface(application, (String) null, interfaceName);
			} catch (Throwable var8) {
				FFDCFilter.processException(var8, CLASS_NAME + ".findByInterface", "182", this);
				EJBException ejbex = ExceptionUtil.EJBException(
						"Failure locating interface " + interfaceName + " in application " + application, var8);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "findByInterface: " + ejbex);
				}

				throw ejbex;
			}

			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "home = " + home.getJ2EEName());
			}

			BeanMetaData bmd = home.getBeanMetaData();
			if (interfaceName.equals(bmd.localHomeInterfaceClassName)) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "match on local home");
				}

				retObj = home.getWrapper().getLocalObject();
			} else if (interfaceName.equals(bmd.homeInterfaceClassName)) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "match on remote home");
				}

				retObj = this.getRemoteHomeReference(home, interfaceName);
			} else {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "looking for match on business interface");
				}

				retObj = this.createBusinessObject(home, bmd, interfaceName, false);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "findByInterface : " + retObj.getClass().getName());
			}

			return retObj;
		}
	}

	private Object createBusinessObject(EJSHome home, BeanMetaData bmd, String interfaceName, boolean ejblink)
			throws EJBException, NoSuchObjectException {
		Object retObj = null;

		try {
			retObj = home.createBusinessObject(interfaceName, ejblink);
		} catch (Throwable var8) {
			FFDCFilter.processException(var8, CLASS_NAME + ".createBusinessObject", "281", this);
			EJBException ejbex = ExceptionUtil.EJBException(
					"Failure creating instance of " + home.getJ2EEName() + " of type " + interfaceName, var8);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "createBusinessObject: " + ejbex);
			}

			throw ejbex;
		}

		if (retObj == null) {
			EJBException ejbex = new EJBException(
					"Unable to create instance of " + home.getJ2EEName() + " of type " + interfaceName);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "createBusinessObject: " + ejbex);
			}

			throw ejbex;
		} else {
			return retObj;
		}
	}

	private Object getRemoteHomeReference(EJSHome home, String interfaceName)
			throws EJBException, NoSuchObjectException {
		Object retObj = null;

		try {
			this.checkHomeSupported(home, interfaceName);
			EJBRuntime runtime = home.getContainer().getEJBRuntime();
			runtime.checkRemoteSupported(home, interfaceName);
			EJSWrapper wrapper = home.getWrapper().getRemoteWrapper();
			retObj = runtime.getRemoteReference(wrapper);
		} catch (Throwable var6) {
			FFDCFilter.processException(var6, CLASS_NAME + ".getRemoteHomeReference", "281", this);
			EJBException ejbex = ExceptionUtil.EJBException(
					"Failure obtaining remote home reference of " + home.getJ2EEName() + " of type " + interfaceName,
					var6);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getRemoteHomeReference: " + ejbex);
			}

			throw ejbex;
		}

		if (retObj == null) {
			EJBException ejbex = new EJBException(
					"Unable to obtain remote reference of " + home.getJ2EEName() + " of type " + interfaceName);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getRemoteHomeReference: " + ejbex);
			}

			throw ejbex;
		} else {
			return retObj;
		}
	}

	protected void checkHomeSupported(EJSHome home, String homeInterface) throws EJBNotFoundException {
	}
}