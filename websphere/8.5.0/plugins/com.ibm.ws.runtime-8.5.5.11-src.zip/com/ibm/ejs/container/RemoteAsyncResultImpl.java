package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejbcontainer.EJBPMICollaborator;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.rmi.PortableRemoteObject;

public final class RemoteAsyncResultImpl extends ServerAsyncResult implements RemoteAsyncResultExtended {
	private static final String CLASS_NAME = RemoteAsyncResultImpl.class.getName();
	private static final TraceComponent tc;
	private final RemoteAsyncResultReaper ivRemoteAsyncResultReaper;
	private boolean ivUnexported;
	private boolean ivAddedToReaper;
	private long ivTimeoutStartTime;
	private Observer ivObserver;

	public RemoteAsyncResultImpl(RemoteAsyncResultReaper reaper, EJBPMICollaborator pmiBean) throws RemoteException {
		super(pmiBean);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>: " + this);
		}

		this.ivRemoteAsyncResultReaper = reaper;
		PortableRemoteObject.exportObject(this);
	}

	public String toString() {
		return super.toString() + "[exported=" + !this.ivUnexported + ", timeout="
				+ (this.ivTimeoutStartTime == 0L ? null : new Date(this.ivTimeoutStartTime)) + ']';
	}

	boolean setObserver(Observer observer) {
		boolean success;
		Observer oldObserver;
		synchronized (this) {
			oldObserver = this.ivObserver;
			success = oldObserver != null || !this.isDone();
			this.ivObserver = success ? observer : null;
		}

		if (oldObserver != null) {
			oldObserver.update((Observable) null, observer);
		}

		return success;
	}

	protected void done() {
		Observer oldObserver;
		synchronized (this) {
			super.done();
			oldObserver = this.ivObserver;
			this.ivObserver = null;
		}

		if (oldObserver != null) {
			oldObserver.update((Observable) null, (Object) null);
		}

		RemoteAsyncResultReaper var2 = this.ivRemoteAsyncResultReaper;
		synchronized (this.ivRemoteAsyncResultReaper) {
			if (!this.ivUnexported) {
				this.ivTimeoutStartTime = System.currentTimeMillis();
				this.ivRemoteAsyncResultReaper.add(this);
				this.ivAddedToReaper = true;
			}

		}
	}

	public boolean cancel(boolean mayInterruptIfRunning) {
		boolean cancelled = super.cancel(mayInterruptIfRunning);
		if (cancelled) {
			this.releaseResources();
		}

		return cancelled;
	}

	public Object get() throws CancellationException, ExecutionException, InterruptedException {
		try {
			Object result = super.get();
			this.releaseResources();
			return result;
		} catch (ExecutionException var3) {
			this.releaseResources();
			throw var3;
		}
	}

	public Object get(long timeout, String unit)
			throws CancellationException, ExecutionException, InterruptedException, TimeoutException {
		try {
			Object result = super.get(timeout, TimeUnit.valueOf(unit));
			this.releaseResources();
			return result;
		} catch (ExecutionException var6) {
			this.releaseResources();
			throw var6;
		}
	}

	public Object[] waitForResult(long waitTime) throws ExecutionException, InterruptedException, RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn) {
			Tr.entry(tc, "waitForResult: " + waitTime);
		}

		if (waitTime <= 0L || waitTime >= ContainerProperties.MaxAsyncResultWaitTime) {
			waitTime = ContainerProperties.MaxAsyncResultWaitTime;
		}

		if (!this.await(waitTime, TimeUnit.MILLISECONDS)) {
			if (isTraceOn) {
				Tr.exit(tc, "waitForResult: timeout");
			}

			return null;
		} else {
			Object result = this.get();
			if (isTraceOn) {
				Tr.exit(tc, "waitForResult: result");
			}

			return new Object[]{result};
		}
	}

	public long getTimeoutStartTime() {
		return this.ivTimeoutStartTime;
	}

	private void releaseResources() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "releaseResources");
		}

		RemoteAsyncResultReaper var2 = this.ivRemoteAsyncResultReaper;
		synchronized (this.ivRemoteAsyncResultReaper) {
			if (this.ivAddedToReaper) {
				this.ivRemoteAsyncResultReaper.remove(this);
			} else {
				this.unexportResources();
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "releaseResources");
		}

	}

	protected void unexportResources() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "unexportResources: " + this);
		}

		if (!this.ivUnexported) {
			try {
				PortableRemoteObject.unexportObject(this);
			} catch (Throwable var3) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "unexportObject exception", var3);
				}

				FFDCFilter.processException(var3, CLASS_NAME + ".unexportResources", "237", this);
			}

			this.ivUnexported = true;
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}