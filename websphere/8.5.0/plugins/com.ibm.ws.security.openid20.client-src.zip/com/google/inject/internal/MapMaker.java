package com.google.inject.internal;

import com.google.inject.internal.CustomConcurrentHashMap.Builder;
import com.google.inject.internal.MapMaker.1;
import com.google.inject.internal.MapMaker.StrategyImpl;
import com.google.inject.internal.MapMaker.Strength;
import com.google.inject.internal.MapMaker.ValueReference;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

public final class MapMaker {
	private Strength keyStrength;
	private Strength valueStrength;
	private long expirationNanos;
	private boolean useCustomMap;
	private final Builder builder;
	private static final ValueReference<Object, Object> COMPUTING = new 1();

	public MapMaker() {
		this.keyStrength = Strength.STRONG;
		this.valueStrength = Strength.STRONG;
		this.expirationNanos = 0L;
		this.builder = new Builder();
	}

	public MapMaker initialCapacity(int initialCapacity) {
		this.builder.initialCapacity(initialCapacity);
		return this;
	}

	public MapMaker loadFactor(float loadFactor) {
		this.builder.loadFactor(loadFactor);
		return this;
	}

	public MapMaker concurrencyLevel(int concurrencyLevel) {
		this.builder.concurrencyLevel(concurrencyLevel);
		return this;
	}

	public MapMaker weakKeys() {
		return this.setKeyStrength(Strength.WEAK);
	}

	public MapMaker softKeys() {
		return this.setKeyStrength(Strength.SOFT);
	}

	private MapMaker setKeyStrength(Strength strength) {
		if (this.keyStrength != Strength.STRONG) {
			throw new IllegalStateException("Key strength was already set to " + this.keyStrength + ".");
		} else {
			this.keyStrength = strength;
			this.useCustomMap = true;
			return this;
		}
	}

	public MapMaker weakValues() {
		return this.setValueStrength(Strength.WEAK);
	}

	public MapMaker softValues() {
		return this.setValueStrength(Strength.SOFT);
	}

	private MapMaker setValueStrength(Strength strength) {
		if (this.valueStrength != Strength.STRONG) {
			throw new IllegalStateException("Value strength was already set to " + this.valueStrength + ".");
		} else {
			this.valueStrength = strength;
			this.useCustomMap = true;
			return this;
		}
	}

	public MapMaker expiration(long duration, TimeUnit unit) {
		if (this.expirationNanos != 0L) {
			throw new IllegalStateException("expiration time of " + this.expirationNanos + " ns was already set");
		} else if (duration <= 0L) {
			throw new IllegalArgumentException("invalid duration: " + duration);
		} else {
			this.expirationNanos = unit.toNanos(duration);
			this.useCustomMap = true;
			return this;
		}
	}

	public <K, V> ConcurrentMap<K, V> makeMap() {
		return (ConcurrentMap) (this.useCustomMap
				? (new StrategyImpl(this)).map
				: new ConcurrentHashMap(this.builder.initialCapacity, this.builder.loadFactor,
						this.builder.concurrencyLevel));
	}

	public <K, V> ConcurrentMap<K, V> makeComputingMap(Function<? super K, ? extends V> computer) {
		return (new StrategyImpl(this, computer)).map;
	}

	private static <K, V> ValueReference<K, V> computing() {
		return COMPUTING;
	}
}