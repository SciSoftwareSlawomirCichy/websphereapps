package com.ibm.ws.ffdc.impl;

import java.io.File;
import java.io.FileFilter;

public class FFDCExceptionFileFilter implements FileFilter {
	private String i_FileNameBaseToAccept = null;
	private String i_FileNameBaseToReject = null;
	private String i_FileExtensionToAccept = null;
	private String i_FileExtensionToReject = null;
	private long i_FileAgeMinimum = -1L;
	private long i_FileAgeMaximum = -1L;

	public void setFileSelectionAttributes(String baseNameToAccept, String baseNameToReject, String extensionToAccept,
			String extensionToReject, long minimumFileAge, long maximumFileAge) {
		this.i_FileNameBaseToAccept = baseNameToAccept;
		this.i_FileNameBaseToReject = baseNameToReject;
		this.i_FileExtensionToAccept = extensionToAccept;
		this.i_FileExtensionToReject = extensionToReject;
		this.i_FileAgeMinimum = minimumFileAge;
		this.i_FileAgeMaximum = maximumFileAge;
	}

	public boolean accept(File fileObject) {
		boolean acceptFlag = false;
		if (fileObject != null && fileObject.exists() && fileObject.isFile()) {
			String fileName = fileObject.getName();
			if (fileName.length() > 0) {
				acceptFlag = (this.i_FileNameBaseToAccept == null || fileName.startsWith(this.i_FileNameBaseToAccept))
						&& (this.i_FileNameBaseToReject == null || !fileName.startsWith(this.i_FileNameBaseToReject))
						&& (this.i_FileExtensionToAccept == null || fileName.endsWith(this.i_FileExtensionToAccept))
						&& (this.i_FileExtensionToReject == null || !fileName.endsWith(this.i_FileExtensionToReject))
						&& (this.i_FileAgeMinimum < 0L || fileObject.lastModified() >= this.i_FileAgeMinimum)
						&& (this.i_FileAgeMaximum < 0L || fileObject.lastModified() <= this.i_FileAgeMaximum);
			}
		}

		return acceptFlag;
	}
}