package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_ko extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"FFDCAddedFormatter", "FFDC1005I: FFDC 포맷터 추가됨 {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: 데이터베이스를 사용한 분석 엔진: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: 분석 엔진 해석 실패:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: FFDC 데이터 콜렉터 추가됨 {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: FFDC 데이터 콜렉터 제거됨 {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: SystemErr에서 발생한 FFDC 문제: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: 실패 안전 모드의 FFDC입니다. {0} 오류에 대해 검사하십시오."},
			{"FFDCForwarderAdded", "FFDC1013I: FFDC 문제 전달자 추가됨 {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: FFDC 문제 전달자 제거됨 {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: FFDC 문제가 {0} {1} {2}에서 발생했습니다."},
			{"FFDCProviderAborted", "FFDC1000I: FFDC 제공자 {0}이(가) 중단되었습니다. 예외는 다음과 같습니다."},
			{"FFDCProviderAbortedE", "FFDC1001I: {0} 예외로 FFDC 제공자가 중단되었습니다."},
			{"FFDCProviderException", "FFDC1008I: FFDC 제공자 예외:"},
			{"FFDCProviderInstalled", "FFDC1007I: FFDC 제공자가 설치되었습니다. {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: FFDC 포맷터 제거됨 {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}