package com.ibm.ws.wim.env.was;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.env.ISSLUtil;
import com.ibm.ws.wim.env.was.SSLUtilImpl.1;
import com.ibm.ws.wim.env.was.SSLUtilImpl.2;
import com.ibm.ws.wim.env.was.SSLUtilImpl.3;
import com.ibm.ws.wim.env.was.SSLUtilImpl.4;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SSLUtilImpl implements ISSLUtil {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	private Properties getProperties(String var1) throws PrivilegedActionException {
      return (Properties)AccessController.doPrivileged(new 1(this, var1));
   }

	private Properties getProperties(String var1, Map<?, ?> var2) throws PrivilegedActionException {
      return (Properties)AccessController.doPrivileged(new 2(this, var1, var2));
   }

	public Properties getSSLPropertiesOnThread() {
      return (Properties)AccessController.doPrivileged(new 3(this));
   }

	public void setSSLPropertiesOnThread(Properties var1) {
      AccessController.doPrivileged(new 4(this, var1));
   }

	public void setSSLAlias(String var1, Hashtable var2) throws WIMConfigurationException {
		trcLogger.entering(CLASSNAME, "setSSLAlias");

		try {
			HashMap var4 = null;
			String var6 = (String) var2.get("java.naming.provider.url");
			if (var6 != null) {
				StringTokenizer var7 = new StringTokenizer(var6);
				var6 = var7.nextToken();
				var6 = var6.replaceFirst("ldap", "http");
				URL var8 = new URL(var6);
				var4 = new HashMap();
				var4.put("com.ibm.ssl.direction", "outbound");
				var4.put("com.ibm.ssl.remoteHost", var8.getHost());
				var4.put("com.ibm.ssl.remotePort", var8.getPort() == -1 ? "636" : Integer.toString(var8.getPort()));
			}

			Properties var5;
			if (var4 != null) {
				var5 = this.getProperties(var1, var4);
			} else {
				var5 = this.getProperties(var1);
			}

			this.setSSLPropertiesOnThread(var5);
			trcLogger.logp(Level.FINE, CLASSNAME, "setSSLAlias", "Properties for SSL Alias '" + var1 + "':" + var5);
		} catch (Exception var9) {
			throw new WIMConfigurationException("INVALID_INIT_PROPERTY",
					WIMMessageHelper.generateMsgParms("sslConfiguration"), CLASSNAME, "setSSLAlias", var9);
		}

		trcLogger.exiting(CLASSNAME, "setSSLAlias");
	}

	public void resetSSLAlias() {
		this.setSSLPropertiesOnThread((Properties) null);
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010;
		CLASSNAME = SSLUtilImpl.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}