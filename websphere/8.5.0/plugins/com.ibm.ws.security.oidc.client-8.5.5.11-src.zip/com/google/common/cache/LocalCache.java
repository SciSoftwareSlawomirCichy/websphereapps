package com.google.common.cache;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Equivalence;
import com.google.common.base.Preconditions;
import com.google.common.base.Stopwatch;
import com.google.common.base.Ticker;
import com.google.common.cache.AbstractCache.StatsCounter;
import com.google.common.cache.CacheBuilder.NullListener;
import com.google.common.cache.CacheBuilder.OneWeigher;
import com.google.common.cache.CacheLoader.InvalidCacheLoadException;
import com.google.common.cache.CacheLoader.UnsupportedLoadingOperationException;
import com.google.common.cache.LocalCache.1;
import com.google.common.cache.LocalCache.2;
import com.google.common.cache.LocalCache.EntryFactory;
import com.google.common.cache.LocalCache.EntrySet;
import com.google.common.cache.LocalCache.KeySet;
import com.google.common.cache.LocalCache.NullEntry;
import com.google.common.cache.LocalCache.ReferenceEntry;
import com.google.common.cache.LocalCache.Segment;
import com.google.common.cache.LocalCache.Strength;
import com.google.common.cache.LocalCache.ValueReference;
import com.google.common.cache.LocalCache.Values;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.primitives.Ints;
import com.google.common.util.concurrent.ExecutionError;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.common.util.concurrent.UncheckedExecutionException;
import java.util.AbstractMap;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;
import javax.annotation.concurrent.GuardedBy;

@GwtCompatible(emulated = true)
class LocalCache<K, V> extends AbstractMap<K, V> implements ConcurrentMap<K, V> {
	static final int MAXIMUM_CAPACITY = 1073741824;
	static final int MAX_SEGMENTS = 65536;
	static final int CONTAINS_VALUE_RETRIES = 3;
	static final int DRAIN_THRESHOLD = 63;
	static final int DRAIN_MAX = 16;
	static final Logger logger = Logger.getLogger(LocalCache.class.getName());
	static final ListeningExecutorService sameThreadExecutor = MoreExecutors.sameThreadExecutor();
	final int segmentMask;
	final int segmentShift;
	final Segment<K, V>[] segments;
	final int concurrencyLevel;
	final Equivalence<Object> keyEquivalence;
	final Equivalence<Object> valueEquivalence;
	final Strength keyStrength;
	final Strength valueStrength;
	final long maxWeight;
	final Weigher<K, V> weigher;
	final long expireAfterAccessNanos;
	final long expireAfterWriteNanos;
	final long refreshNanos;
	final Queue<RemovalNotification<K, V>> removalNotificationQueue;
	final RemovalListener<K, V> removalListener;
	final Ticker ticker;
	final EntryFactory entryFactory;
	final StatsCounter globalStatsCounter;
	@Nullable
	final CacheLoader<? super K, V> defaultLoader;
	static final ValueReference<Object, Object> UNSET = new 1();
	static final Queue<? extends Object> DISCARDING_QUEUE = new 2();
	Set<K> keySet;
	Collection<V> values;
	Set<Entry<K, V>> entrySet;

	LocalCache(CacheBuilder<? super K, ? super V> builder, @Nullable CacheLoader<? super K, V> loader) {
		this.concurrencyLevel = Math.min(builder.getConcurrencyLevel(), 65536);
		this.keyStrength = builder.getKeyStrength();
		this.valueStrength = builder.getValueStrength();
		this.keyEquivalence = builder.getKeyEquivalence();
		this.valueEquivalence = builder.getValueEquivalence();
		this.maxWeight = builder.getMaximumWeight();
		this.weigher = builder.getWeigher();
		this.expireAfterAccessNanos = builder.getExpireAfterAccessNanos();
		this.expireAfterWriteNanos = builder.getExpireAfterWriteNanos();
		this.refreshNanos = builder.getRefreshNanos();
		this.removalListener = builder.getRemovalListener();
		this.removalNotificationQueue = (Queue) (this.removalListener == NullListener.INSTANCE
				? discardingQueue()
				: new ConcurrentLinkedQueue());
		this.ticker = builder.getTicker(this.recordsTime());
		this.entryFactory = EntryFactory.getFactory(this.keyStrength, this.usesAccessEntries(),
				this.usesWriteEntries());
		this.globalStatsCounter = (StatsCounter) builder.getStatsCounterSupplier().get();
		this.defaultLoader = loader;
		int initialCapacity = Math.min(builder.getInitialCapacity(), 1073741824);
		if (this.evictsBySize() && !this.customWeigher()) {
			initialCapacity = Math.min(initialCapacity, (int) this.maxWeight);
		}

		int segmentShift = 0;

		int segmentCount;
		for (segmentCount = 1; segmentCount < this.concurrencyLevel
				&& (!this.evictsBySize() || (long) (segmentCount * 20) <= this.maxWeight); segmentCount <<= 1) {
			++segmentShift;
		}

		this.segmentShift = 32 - segmentShift;
		this.segmentMask = segmentCount - 1;
		this.segments = this.newSegmentArray(segmentCount);
		int segmentCapacity = initialCapacity / segmentCount;
		if (segmentCapacity * segmentCount < initialCapacity) {
			++segmentCapacity;
		}

		int segmentSize;
		for (segmentSize = 1; segmentSize < segmentCapacity; segmentSize <<= 1) {
			;
		}

		if (this.evictsBySize()) {
			long maxSegmentWeight = this.maxWeight / (long) segmentCount + 1L;
			long remainder = this.maxWeight % (long) segmentCount;

			for (int i = 0; i < this.segments.length; ++i) {
				if ((long) i == remainder) {
					--maxSegmentWeight;
				}

				this.segments[i] = this.createSegment(segmentSize, maxSegmentWeight,
						(StatsCounter) builder.getStatsCounterSupplier().get());
			}
		} else {
			for (int i = 0; i < this.segments.length; ++i) {
				this.segments[i] = this.createSegment(segmentSize, -1L,
						(StatsCounter) builder.getStatsCounterSupplier().get());
			}
		}

	}

	boolean evictsBySize() {
		return this.maxWeight >= 0L;
	}

	boolean customWeigher() {
		return this.weigher != OneWeigher.INSTANCE;
	}

	boolean expires() {
		return this.expiresAfterWrite() || this.expiresAfterAccess();
	}

	boolean expiresAfterWrite() {
		return this.expireAfterWriteNanos > 0L;
	}

	boolean expiresAfterAccess() {
		return this.expireAfterAccessNanos > 0L;
	}

	boolean refreshes() {
		return this.refreshNanos > 0L;
	}

	boolean usesAccessQueue() {
		return this.expiresAfterAccess() || this.evictsBySize();
	}

	boolean usesWriteQueue() {
		return this.expiresAfterWrite();
	}

	boolean recordsWrite() {
		return this.expiresAfterWrite() || this.refreshes();
	}

	boolean recordsAccess() {
		return this.expiresAfterAccess();
	}

	boolean recordsTime() {
		return this.recordsWrite() || this.recordsAccess();
	}

	boolean usesWriteEntries() {
		return this.usesWriteQueue() || this.recordsWrite();
	}

	boolean usesAccessEntries() {
		return this.usesAccessQueue() || this.recordsAccess();
	}

	boolean usesKeyReferences() {
		return this.keyStrength != Strength.STRONG;
	}

	boolean usesValueReferences() {
		return this.valueStrength != Strength.STRONG;
	}

	static <K, V> ValueReference<K, V> unset() {
		return UNSET;
	}

	static <K, V> ReferenceEntry<K, V> nullEntry() {
		return NullEntry.INSTANCE;
	}

	static <E> Queue<E> discardingQueue() {
		return DISCARDING_QUEUE;
	}

	static int rehash(int h) {
		h += h << 15 ^ -12931;
		h ^= h >>> 10;
		h += h << 3;
		h ^= h >>> 6;
		h += (h << 2) + (h << 14);
		return h ^ h >>> 16;
	}

	@GuardedBy("Segment.this")
	@VisibleForTesting
	ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable ReferenceEntry<K, V> next) {
		return this.segmentFor(hash).newEntry(key, hash, next);
	}

	@GuardedBy("Segment.this")
	@VisibleForTesting
	ReferenceEntry<K, V> copyEntry(ReferenceEntry<K, V> original, ReferenceEntry<K, V> newNext) {
		int hash = original.getHash();
		return this.segmentFor(hash).copyEntry(original, newNext);
	}

	@GuardedBy("Segment.this")
	@VisibleForTesting
	ValueReference<K, V> newValueReference(ReferenceEntry<K, V> entry, V value, int weight) {
		int hash = entry.getHash();
		return this.valueStrength.referenceValue(this.segmentFor(hash), entry, Preconditions.checkNotNull(value),
				weight);
	}

	int hash(@Nullable Object key) {
		int h = this.keyEquivalence.hash(key);
		return rehash(h);
	}

	void reclaimValue(ValueReference<K, V> valueReference) {
		ReferenceEntry<K, V> entry = valueReference.getEntry();
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimValue(entry.getKey(), hash, valueReference);
	}

	void reclaimKey(ReferenceEntry<K, V> entry) {
		int hash = entry.getHash();
		this.segmentFor(hash).reclaimKey(entry, hash);
	}

	@VisibleForTesting
	boolean isLive(ReferenceEntry<K, V> entry, long now) {
		return this.segmentFor(entry.getHash()).getLiveValue(entry, now) != null;
	}

	Segment<K, V> segmentFor(int hash) {
		return this.segments[hash >>> this.segmentShift & this.segmentMask];
	}

	Segment<K, V> createSegment(int initialCapacity, long maxSegmentWeight, StatsCounter statsCounter) {
		return new Segment(this, initialCapacity, maxSegmentWeight, statsCounter);
	}

	@Nullable
	V getLiveValue(ReferenceEntry<K, V> entry, long now) {
		if (entry.getKey() == null) {
			return null;
		} else {
			V value = entry.getValueReference().get();
			if (value == null) {
				return null;
			} else {
				return this.isExpired(entry, now) ? null : value;
			}
		}
	}

	boolean isExpired(ReferenceEntry<K, V> entry, long now) {
		Preconditions.checkNotNull(entry);
		if (this.expiresAfterAccess() && now - entry.getAccessTime() >= this.expireAfterAccessNanos) {
			return true;
		} else {
			return this.expiresAfterWrite() && now - entry.getWriteTime() >= this.expireAfterWriteNanos;
		}
	}

	@GuardedBy("Segment.this")
	static <K, V> void connectAccessOrder(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next) {
		previous.setNextInAccessQueue(next);
		next.setPreviousInAccessQueue(previous);
	}

	@GuardedBy("Segment.this")
	static <K, V> void nullifyAccessOrder(ReferenceEntry<K, V> nulled) {
		ReferenceEntry<K, V> nullEntry = nullEntry();
		nulled.setNextInAccessQueue(nullEntry);
		nulled.setPreviousInAccessQueue(nullEntry);
	}

	@GuardedBy("Segment.this")
	static <K, V> void connectWriteOrder(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next) {
		previous.setNextInWriteQueue(next);
		next.setPreviousInWriteQueue(previous);
	}

	@GuardedBy("Segment.this")
	static <K, V> void nullifyWriteOrder(ReferenceEntry<K, V> nulled) {
		ReferenceEntry<K, V> nullEntry = nullEntry();
		nulled.setNextInWriteQueue(nullEntry);
		nulled.setPreviousInWriteQueue(nullEntry);
	}

	void processPendingNotifications() {
		RemovalNotification notification;
		while ((notification = (RemovalNotification) this.removalNotificationQueue.poll()) != null) {
			try {
				this.removalListener.onRemoval(notification);
			} catch (Throwable var3) {
				logger.log(Level.WARNING, "Exception thrown by removal listener", var3);
			}
		}

	}

	final Segment<K, V>[] newSegmentArray(int ssize) {
		return new Segment[ssize];
	}

	public void cleanUp() {
		Segment[] arr$ = this.segments;
		int len$ = arr$.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Segment<?, ?> segment = arr$[i$];
			segment.cleanUp();
		}

	}

	public boolean isEmpty() {
		long sum = 0L;
		Segment<K, V>[] segments = this.segments;

		int i;
		for (i = 0; i < segments.length; ++i) {
			if (segments[i].count != 0) {
				return false;
			}

			sum += (long) segments[i].modCount;
		}

		if (sum != 0L) {
			for (i = 0; i < segments.length; ++i) {
				if (segments[i].count != 0) {
					return false;
				}

				sum -= (long) segments[i].modCount;
			}

			if (sum != 0L) {
				return false;
			}
		}

		return true;
	}

	long longSize() {
		Segment<K, V>[] segments = this.segments;
		long sum = 0L;

		for (int i = 0; i < segments.length; ++i) {
			sum += (long) segments[i].count;
		}

		return sum;
	}

	public int size() {
		return Ints.saturatedCast(this.longSize());
	}

	@Nullable
	public V get(@Nullable Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).get(key, hash);
		}
	}

	@Nullable
	public V getIfPresent(Object key) {
		int hash = this.hash(Preconditions.checkNotNull(key));
		V value = this.segmentFor(hash).get(key, hash);
		if (value == null) {
			this.globalStatsCounter.recordMisses(1);
		} else {
			this.globalStatsCounter.recordHits(1);
		}

		return value;
	}

	V get(K key, CacheLoader<? super K, V> loader) throws ExecutionException {
		int hash = this.hash(Preconditions.checkNotNull(key));
		return this.segmentFor(hash).get(key, hash, loader);
	}

	V getOrLoad(K key) throws ExecutionException {
		return this.get(key, this.defaultLoader);
	}

	ImmutableMap<K, V> getAllPresent(Iterable<?> keys) {
		int hits = 0;
		int misses = 0;
		Map<K, V> result = Maps.newLinkedHashMap();
		Iterator i$ = keys.iterator();

		while (i$.hasNext()) {
			Object key = i$.next();
			V value = this.get(key);
			if (value == null) {
				++misses;
			} else {
				result.put(key, value);
				++hits;
			}
		}

		this.globalStatsCounter.recordHits(hits);
		this.globalStatsCounter.recordMisses(misses);
		return ImmutableMap.copyOf(result);
	}

	ImmutableMap<K, V> getAll(Iterable<? extends K> keys) throws ExecutionException {
		int hits = 0;
		int misses = 0;
		Map<K, V> result = Maps.newLinkedHashMap();
		Set<K> keysToLoad = Sets.newLinkedHashSet();
		Iterator i$ = keys.iterator();

		Object key;
		while (i$.hasNext()) {
			K key = i$.next();
			key = this.get(key);
			if (!result.containsKey(key)) {
				result.put(key, key);
				if (key == null) {
					++misses;
					keysToLoad.add(key);
				} else {
					++hits;
				}
			}
		}

		ImmutableMap var16;
		try {
			if (!keysToLoad.isEmpty()) {
				Iterator i$;
				try {
					Map<K, V> newEntries = this.loadAll(keysToLoad, this.defaultLoader);
					i$ = keysToLoad.iterator();

					while (i$.hasNext()) {
						key = i$.next();
						V value = newEntries.get(key);
						if (value == null) {
							throw new InvalidCacheLoadException("loadAll failed to return a value for " + key);
						}

						result.put(key, value);
					}
				} catch (UnsupportedLoadingOperationException var13) {
					i$ = keysToLoad.iterator();

					while (i$.hasNext()) {
						key = i$.next();
						--misses;
						result.put(key, this.get(key, this.defaultLoader));
					}
				}
			}

			var16 = ImmutableMap.copyOf(result);
		} finally {
			this.globalStatsCounter.recordHits(hits);
			this.globalStatsCounter.recordMisses(misses);
		}

		return var16;
	}

	@Nullable
	Map<K, V> loadAll(Set<? extends K> keys, CacheLoader<? super K, V> loader) throws ExecutionException {
		Preconditions.checkNotNull(loader);
		Preconditions.checkNotNull(keys);
		Stopwatch stopwatch = (new Stopwatch()).start();
		boolean success = false;

		Map result;
		try {
			Map<K, V> map = loader.loadAll(keys);
			result = map;
			success = true;
		} catch (UnsupportedLoadingOperationException var17) {
			success = true;
			throw var17;
		} catch (InterruptedException var18) {
			Thread.currentThread().interrupt();
			throw new ExecutionException(var18);
		} catch (RuntimeException var19) {
			throw new UncheckedExecutionException(var19);
		} catch (Exception var20) {
			throw new ExecutionException(var20);
		} catch (Error var21) {
			throw new ExecutionError(var21);
		} finally {
			if (!success) {
				this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
			}

		}

		if (result == null) {
			this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
			throw new InvalidCacheLoadException(loader + " returned null map from loadAll");
		} else {
			stopwatch.stop();
			boolean nullsPresent = false;
			Iterator i$ = result.entrySet().iterator();

			while (true) {
				while (i$.hasNext()) {
					Entry<K, V> entry = (Entry) i$.next();
					K key = entry.getKey();
					V value = entry.getValue();
					if (key != null && value != null) {
						this.put(key, value);
					} else {
						nullsPresent = true;
					}
				}

				if (nullsPresent) {
					this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
					throw new InvalidCacheLoadException(loader + " returned null keys or values from loadAll");
				}

				this.globalStatsCounter.recordLoadSuccess(stopwatch.elapsed(TimeUnit.NANOSECONDS));
				return result;
			}
		}
	}

	ReferenceEntry<K, V> getEntry(@Nullable Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).getEntry(key, hash);
		}
	}

	void refresh(K key) {
		int hash = this.hash(Preconditions.checkNotNull(key));
		this.segmentFor(hash).refresh(key, hash, this.defaultLoader, false);
	}

	public boolean containsKey(@Nullable Object key) {
		if (key == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).containsKey(key, hash);
		}
	}

	public boolean containsValue(@Nullable Object value) {
		if (value == null) {
			return false;
		} else {
			long now = this.ticker.read();
			Segment<K, V>[] segments = this.segments;
			long last = -1L;

			for (int i = 0; i < 3; ++i) {
				long sum = 0L;
				Segment[] arr$ = segments;
				int len$ = segments.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					Segment<K, V> segment = arr$[i$];
					int c = segment.count;
					AtomicReferenceArray<ReferenceEntry<K, V>> table = segment.table;

					for (int j = 0; j < table.length(); ++j) {
						for (ReferenceEntry e = (ReferenceEntry) table.get(j); e != null; e = e.getNext()) {
							V v = segment.getLiveValue(e, now);
							if (v != null && this.valueEquivalence.equivalent(value, v)) {
								return true;
							}
						}
					}

					sum += (long) segment.modCount;
				}

				if (sum == last) {
					break;
				}

				last = sum;
			}

			return false;
		}
	}

	public V put(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, false);
	}

	public V putIfAbsent(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).put(key, hash, value, true);
	}

	public void putAll(Map<? extends K, ? extends V> m) {
		Iterator i$ = m.entrySet().iterator();

		while (i$.hasNext()) {
			Entry<? extends K, ? extends V> e = (Entry) i$.next();
			this.put(e.getKey(), e.getValue());
		}

	}

	public V remove(@Nullable Object key) {
		if (key == null) {
			return null;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash);
		}
	}

	public boolean remove(@Nullable Object key, @Nullable Object value) {
		if (key != null && value != null) {
			int hash = this.hash(key);
			return this.segmentFor(hash).remove(key, hash, value);
		} else {
			return false;
		}
	}

	public boolean replace(K key, @Nullable V oldValue, V newValue) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(newValue);
		if (oldValue == null) {
			return false;
		} else {
			int hash = this.hash(key);
			return this.segmentFor(hash).replace(key, hash, oldValue, newValue);
		}
	}

	public V replace(K key, V value) {
		Preconditions.checkNotNull(key);
		Preconditions.checkNotNull(value);
		int hash = this.hash(key);
		return this.segmentFor(hash).replace(key, hash, value);
	}

	public void clear() {
		Segment[] arr$ = this.segments;
		int len$ = arr$.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Segment<K, V> segment = arr$[i$];
			segment.clear();
		}

	}

	void invalidateAll(Iterable<?> keys) {
		Iterator i$ = keys.iterator();

		while (i$.hasNext()) {
			Object key = i$.next();
			this.remove(key);
		}

	}

	public Set<K> keySet() {
		Set<K> ks = this.keySet;
		return ks != null ? ks : (this.keySet = new KeySet(this, this));
	}

	public Collection<V> values() {
		Collection<V> vs = this.values;
		return vs != null ? vs : (this.values = new Values(this, this));
	}

	@GwtIncompatible("Not supported.")
	public Set<Entry<K, V>> entrySet() {
		Set<Entry<K, V>> es = this.entrySet;
		return es != null ? es : (this.entrySet = new EntrySet(this, this));
	}
}