package com.google.inject.internal;

final class CustomConcurrentHashMap {
	private static int rehash(int h) {
		h += h << 15 ^ -12931;
		h ^= h >>> 10;
		h += h << 3;
		h ^= h >>> 6;
		h += (h << 2) + (h << 14);
		return h ^ h >>> 16;
	}
}