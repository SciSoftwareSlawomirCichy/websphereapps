package com.ibm.ws.wim.xpath.mapping.datatype;

public interface XPathPropertyNode extends XPathNode {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";

	void setOperator(String var1);

	String getOperator();

	void setName(String var1);

	String getName();

	void setValue(Object var1);

	Object getValue();

	void setPropertyLocation(boolean var1);

	boolean isPropertyInRepository();
}