package com.ibm.ws.ssl.provider;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import com.ibm.websphere.ssl.SSLException;
import com.ibm.ws.security.config.ServerStatusHelper;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.ssl.JSSEProvider;
import com.ibm.ws.ssl.JSSEProviderFactory;
import com.ibm.ws.ssl.config.KeyManagerData;
import com.ibm.ws.ssl.config.KeyStoreManager;
import com.ibm.ws.ssl.config.SSLConfig;
import com.ibm.ws.ssl.config.SSLConfigManager;
import com.ibm.ws.ssl.config.ThreadManager;
import com.ibm.ws.ssl.config.TrustManagerData;
import com.ibm.ws.ssl.config.WSKeyStore;
import com.ibm.ws.ssl.core.KeyManagerHolder;
import com.ibm.ws.ssl.core.TraceNLSHelper;
import com.ibm.ws.ssl.core.TrustManagerHolder;
import com.ibm.ws.ssl.core.WSPKCSInKeyStore;
import com.ibm.ws.ssl.core.WSPKCSInKeyStoreList;
import com.ibm.ws.ssl.core.WSX509KeyManager;
import com.ibm.ws.ssl.core.WSX509TrustManager;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider.1;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider.2;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider.3;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider.4;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider.5;
import com.ibm.ws.ssl.provider.AbstractJSSEProvider.6;
import com.ibm.ws.util.PlatformHelperFactory;
import com.ibm.wsspi.ssl.KeyManagerExtendedInfo;
import com.ibm.wsspi.ssl.TrustManagerExtendedInfo;
import java.lang.reflect.Method;
import java.net.URLStreamHandler;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.SecureRandom;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertStore;
import java.security.cert.LDAPCertStoreParameters;
import java.security.cert.PKIXBuilderParameters;
import java.security.cert.X509CertSelector;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import javax.net.ssl.CertPathTrustManagerParameters;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.ManagerFactoryParameters;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509KeyManager;
import javax.net.ssl.X509TrustManager;

public abstract class AbstractJSSEProvider implements JSSEProvider {
	private static final TraceComponent tc = Tr.register(AbstractJSSEProvider.class, "SSL",
			"com.ibm.ws.ssl.resources.ssl");
	private static final WSPKCSInKeyStoreList pkcsStoreList = new WSPKCSInKeyStoreList();
	private static HashMap sslContextCacheJAVAX = new HashMap();
	private static HashMap sslContextCacheJSSE2 = new HashMap();
	private static boolean handlersInitialized = false;
	private static String SSL_SOCKET_FACTORY_NAME = "com.ibm.websphere.ssl.protocol.SSLSocketFactory";
	private static String SSL_SERVER_SOCKET_FACTORY_NAME = "com.ibm.websphere.ssl.protocol.SSLServerSocketFactory";
	private static String CUSTOM_SECURE_RANDOM_PROPERTY = "com.ibm.websphere.ssl.provider.customSecureRandom";
	private static String OVERWRITE_SOCKET_FACTORY = "com.ibm.websphere.ssl.provider.overwrite";
	private static boolean createHttpsURLHandlerFlag = true;
	private static String CREATE_HTTPS_URL_HANDLER_JVM_PROP = "com.ibm.websphere.ssl.provider.create.https.handler";
	private static String URL_HANDLER_PROP = "java.protocol.handler.pkgs";
	private static final String PKGNAME_DELIMITER = "|";
	private static final PrivilegedAction getCtxClassLoader = new 6();

	public AbstractJSSEProvider() {
		if (JSSEProviderFactory.isFips140_2Enabled()) {
			try {
				JSSEProviderFactory.initializeFips();
			} catch (Exception var2) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception caught initializing FIPS.", new Object[]{var2});
				}
			}
		}

	}

	public void initializeHandlers(String protocolPackage) {
		if (protocolPackage == null) {
			protocolPackage = "com.ibm.net.ssl.www2.protocol";
		}

		registerPackage(protocolPackage);
		if (!handlersInitialized) {
			addHandlers(protocolPackage);
		}

	}

	public String getDefaultSSLSocketFactoryClass(String socketFactory) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getDefaultSSLSocketFactoryClass: " + socketFactory);
		}

		return socketFactory;
	}

	public abstract String getSSLProtocolPackageHandler();

	public String[] getCiphersForSecurityLevel(boolean isClient, String securityLevel) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "getCiphersForSecurityLevel: ", new Object[]{new Boolean(isClient), securityLevel});
		}

		String[] supportedCiphers = null;
		if (isClient) {
			SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
			supportedCiphers = factory.getSupportedCipherSuites();
		} else {
			SSLServerSocketFactory factory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
			supportedCiphers = factory.getSupportedCipherSuites();
		}

		return SSLConfigManager.getInstance().adjustSupportedCiphersToSecurityLevel(supportedCiphers, securityLevel);
	}

	public SSLContext getSSLContext(Map connectionInfo, SSLConfig sslConfig) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLContext", new Object[]{connectionInfo, sslConfig});
		}

		SSLContext sslContext = (SSLContext) sslContextCacheJAVAX.get(sslConfig);
		this.setOutboundConnectionInfoInternal(connectionInfo);
		String skipCacheProp = System.getProperty("com.ibm.ws.ssl.skipSSLContextCache");
		boolean skipCache = Boolean.valueOf(skipCacheProp);
		if (skipCache) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "com.ibm.ws.ssl.skipSSLContextCache=true, not using cached value");
			}
		} else if (sslContext != null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getSSLContext -> (from cache)");
			}

			return sslContext;
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "SSLContext cache miss, generating new SSLContext.");
		}

		sslContext = this.generateNewSSLContext(connectionInfo, sslConfig);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSSLContext -> (new)");
		}

		return sslContext;
	}

	protected SSLContext generateNewSSLContext(Map connectionInfo, SSLConfig sslConfig) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "generateNewSSLContext", new Object[]{connectionInfo, sslConfig});
		}

		SSLContext sslContext = this.getSSLContextInstance(sslConfig);
		TrustManagerHolder tmHolder = new TrustManagerHolder();
		KeyManagerHolder kmHolder = new KeyManagerHolder();
		this.getKeyTrustManagers(connectionInfo, sslConfig, kmHolder, tmHolder);
		TrustManager[] trustManagers = tmHolder.getTrustManagers();
		KeyManager[] keyManagers = kmHolder.getKeyManagers();
		if (keyManagers != null && trustManagers != null) {
			sslContext.init(keyManagers, trustManagers, this.getSecureRandom(sslConfig));
			this.updateSSLContextCache(sslConfig, sslContext);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "generateNewSSLContext");
			}

			return sslContext;
		} else {
			throw new SSLException("Null trust or key managers.");
		}
	}

	protected SecureRandom getSecureRandom(SSLConfig sslConfig) {
		SecureRandom sr = null;
		boolean processIsServer = false;
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSecureRandom");
		}

		if (SSLConfigManager.getInstance() != null) {
			processIsServer = SSLConfigManager.getInstance().isServerProcess();
		}

		String s = this.getSSLContextProperty(CUSTOM_SECURE_RANDOM_PROPERTY, sslConfig, processIsServer);
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, CUSTOM_SECURE_RANDOM_PROPERTY + "=" + s);
		}

		try {
			if (s != null && s.equalsIgnoreCase("true")) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Using SHA1PRNG/IBMJCE");
				}

				sr = SecureRandom.getInstance("SHA1PRNG", "IBMJCE");
			} else if (s != null && s.contains("|")) {
				String[] values = s.split("\\|", 2);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "algorithm=" + values[0] + "provider=" + values[1]);
				}

				sr = SecureRandom.getInstance(values[0], values[1]);
			}
		} catch (Exception var6) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception caught. " + var6.getMessage());
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "sr=" + sr);
		}

		return sr;
	}

	protected void updateSSLContextCache(SSLConfig sslConfig, SSLContext sslContext) {
		if (sslContextCacheJAVAX.size() > 100) {
			sslContextCacheJAVAX.clear();
		}

		sslContextCacheJAVAX.put(sslConfig, sslContext);
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "SSLContext cache size: " + sslContextCacheJAVAX.size());
		}

	}

	public com.ibm.jsse2.SSLContext getSSLContext_JSSE2(Map connectionInfo, SSLConfig sslConfig) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLContext_JSSE2", new Object[]{connectionInfo, sslConfig});
		}

		com.ibm.jsse2.SSLContext sslContext = (com.ibm.jsse2.SSLContext) sslContextCacheJSSE2.get(sslConfig);
		this.setOutboundConnectionInfoInternal(connectionInfo);
		String skipCacheProp = System.getProperty("com.ibm.ws.ssl.skipSSLContextCache");
		boolean skipCache = Boolean.valueOf(skipCacheProp);
		if (skipCache) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "com.ibm.ws.ssl.skipSSLContextCache=true, not using cached value");
			}
		} else if (sslContext != null) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getSSLContext_JSSE2 -> (from cache)");
			}

			return sslContext;
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "SSLContextJAVAX cache miss, generating new SSLContext.");
		}

		sslContext = this.generateNewSSLContext_JSSE2(connectionInfo, sslConfig);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSSLContext_JSSE2 -> (new)");
		}

		return sslContext;
	}

	protected com.ibm.jsse2.SSLContext generateNewSSLContext_JSSE2(Map connectionInfo, SSLConfig sslConfig)
			throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "generateNewSSLContext_JSSE2", new Object[]{connectionInfo, sslConfig});
		}

		com.ibm.jsse2.SSLContext sslContext = this.getSSLContextInstanceJSSE2(sslConfig);
		TrustManagerHolder tmHolder = new TrustManagerHolder();
		KeyManagerHolder kmHolder = new KeyManagerHolder();
		this.getKeyTrustManagers(connectionInfo, sslConfig, kmHolder, tmHolder);
		TrustManager[] trustManagers = tmHolder.getTrustManagers();
		KeyManager[] keyManagers = kmHolder.getKeyManagers();
		if (keyManagers != null && trustManagers != null) {
			sslContext.init(keyManagers, trustManagers, (SecureRandom) null);
			this.updateSSLContextCacheJSSE2(sslConfig, sslContext);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "generateNewSSLContext_JSSE2");
			}

			return sslContext;
		} else {
			throw new SSLException("Null trust or key managers.");
		}
	}

	protected void updateSSLContextCacheJSSE2(SSLConfig sslConfig, com.ibm.jsse2.SSLContext sslContext) {
		if (sslContextCacheJSSE2.size() > 100) {
			sslContextCacheJSSE2.clear();
		}

		sslContextCacheJSSE2.put(sslConfig, sslContext);
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "SSLContextJSSE2 cache size: " + sslContextCacheJSSE2.size());
		}

	}

	private void getKeyTrustManagers(Map connectionInfo, SSLConfig sslConfig, KeyManagerHolder kmHolder,
			TrustManagerHolder tmHolder) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getKeyTrustManagers", new Object[]{connectionInfo, sslConfig});
		}

		TrustManagerFactory trustManagerFactory = null;
		KeyManagerFactory keyManagerFactory = null;
		SSLContext sslContext = null;
		KeyStore keyStore = null;
		KeyStore trustStore = null;
		String direction = "unknown";
		if (connectionInfo != null) {
			direction = (String) connectionInfo.get("com.ibm.ssl.direction");
		}

		try {
			boolean processIsServer = SSLConfigManager.getInstance().isServerProcess();
			String trustFileName = this.getSSLContextProperty("com.ibm.ssl.trustStoreName", sslConfig, processIsServer);
			WSKeyStore wsts = null;
			if (trustFileName != null) {
				wsts = KeyStoreManager.getInstance().getKeyStore(trustFileName);
			}

			String trustFileProvider = wsts != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStoreProvider", wsts, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.trustStoreProvider", sslConfig, processIsServer);
			String trustFileLocation = wsts != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStore", wsts, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.trustStore", sslConfig, processIsServer);
			String trustFilePassword = wsts != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStorePassword", wsts, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.trustStorePassword", sslConfig, processIsServer);
			String trustFileScope = wsts != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStoreScope", wsts, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.trustStoreScope", sslConfig, processIsServer);
			String trustFileType = wsts != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStoreType", wsts, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.trustStoreType", sslConfig, processIsServer);
			String keyFileName = this.getSSLContextProperty("com.ibm.ssl.keyStoreName", sslConfig, processIsServer);
			WSKeyStore wsks = null;
			if (keyFileName != null) {
				wsks = KeyStoreManager.getInstance().getKeyStore(keyFileName);
			}

			String keyFileProvider = wsks != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStoreProvider", wsks, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.keyStoreProvider", sslConfig, processIsServer);
			String keyFileLocation = wsks != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStore", wsks, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.keyStore", sslConfig, processIsServer);
			String keyFilePassword = wsks != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStorePassword", wsks, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.keyStorePassword", sslConfig, processIsServer);
			String keyFileScope = wsks != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStoreScope", wsks, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.keyStoreScope", sslConfig, processIsServer);
			String keyFileType = wsks != null
					? this.getSSLContextProperty("com.ibm.ssl.keyStoreType", wsks, processIsServer)
					: this.getSSLContextProperty("com.ibm.ssl.keyStoreType", sslConfig, processIsServer);
			boolean usingHwCryptoTrustStore = false;
			boolean usingHwCryptoKeyStore = false;
			String contextProvider = this.getSSLContextProperty("com.ibm.ssl.contextProvider", sslConfig,
					processIsServer);
			this.getSSLContextProperty("com.ibm.ssl.protocol", sslConfig, processIsServer);
			String keyManager = this.getSSLContextProperty("com.ibm.ssl.keyManager", sslConfig, processIsServer);
			String trustManager = this.getSSLContextProperty("com.ibm.ssl.trustManager", sslConfig, processIsServer);
			String customTrustManagers = this.getSSLContextProperty("com.ibm.ssl.customTrustManagers", sslConfig,
					processIsServer);
			String customKeyManager = this.getSSLContextProperty("com.ibm.ssl.customKeyManager", sslConfig,
					processIsServer);
			String clientAuthentication = this.getSSLContextProperty("com.ibm.ssl.clientAuthentication", sslConfig,
					processIsServer);
			String clientAliasName = this.getSSLContextProperty("com.ibm.ssl.keyStoreClientAlias", sslConfig,
					processIsServer);
			String serverAliasName = this.getSSLContextProperty("com.ibm.ssl.keyStoreServerAlias", sslConfig,
					processIsServer);
			boolean tokenEnabled = this.getSSLContextProperty("com.ibm.ssl.tokenEnabled", sslConfig, processIsServer)
					.equals("true");
			String tokenLibraryFile = this.getSSLContextProperty("com.ibm.ssl.tokenLibraryFile", sslConfig,
					processIsServer);
			String tokenPassword = this.getSSLContextProperty("com.ibm.ssl.tokenPassword", sslConfig, processIsServer);
			String tokenType = this.getSSLContextProperty("com.ibm.ssl.tokenType", sslConfig, processIsServer);
			String tokenSlot = this.getSSLContextProperty("com.ibm.ssl.tokenSlot", sslConfig, processIsServer);
			int slotnum = tokenSlot != null ? Integer.valueOf(tokenSlot) : 0;
			char[] passPhrase = null;
			WSPKCSInKeyStore pKS;
			if (trustFileLocation != null && trustFilePassword != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Using trust store: " + trustFileLocation);
				}

				trustStore = KeyStoreManager.getInstance().getKeyStore(trustFileName, trustFileType, trustFileProvider,
						trustFileLocation, trustFilePassword, trustFileScope, false, sslConfig);
			} else if (tokenLibraryFile != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "No trust store specified, but found hardware crypto");
				}

				pKS = pkcsStoreList.insert(tokenType, tokenLibraryFile, tokenPassword, false, contextProvider, false);
				if (pKS != null) {
					trustStore = pKS.getTS();
					trustManagerFactory = pKS.getTMF();
					usingHwCryptoTrustStore = true;
				}
			} else {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "No trust store specified and no hardware crypto defined");
				}

				if (direction == null || !direction.equals("inbound") || clientAuthentication == null
						|| !clientAuthentication.equals("false")) {
					throw new IllegalArgumentException("Invalid trust file name of null");
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "trust store permitted to be null since this is inbound and client auth is false");
				}
			}

			if (!usingHwCryptoTrustStore) {
				trustManagerFactory = this.getTrustManagerFactoryInstance(trustManager, contextProvider);
				this.initializeTrustManagerFactory(trustManagerFactory, trustStore);
			}

			if (keyFileLocation != null && keyFilePassword != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Using software keystore: " + keyFileLocation);
				}

				if (keyFileType.equals(trustFileType) && keyFileProvider.equals(trustFileProvider)
						&& keyFileLocation.equals(trustFileLocation) && keyFilePassword.equals(trustFilePassword)) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Reusing key store from Trust Manager");
					}

					keyStore = trustStore;
				} else {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Creating new key store for Key Manager");
					}

					keyStore = KeyStoreManager.getInstance().getKeyStore(keyFileName, keyFileType, keyFileProvider,
							keyFileLocation, keyFilePassword, keyFileScope, false, sslConfig);
				}

				if (keyFilePassword != null) {
					passPhrase = keyFilePassword.toCharArray();
				}
			} else {
				if (tokenLibraryFile == null) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "No key store specified and no hardware crypto defined");
					}

					throw new IllegalArgumentException("No key store specified and no hardware crypto defined");
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "No key store specified, but found hardware crypto");
				}

				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Reusing key store from Trust Manager");
				}

				pKS = pkcsStoreList.insert(tokenType, tokenLibraryFile, tokenPassword, true, contextProvider, false);
				if (pKS != null) {
					keyStore = pKS.getKS();
					keyManagerFactory = pKS.getKMF();
					usingHwCryptoKeyStore = true;
				}
			}

			if (!usingHwCryptoKeyStore) {
				keyManagerFactory = this.getKeyManagerFactoryInstance(keyManager, contextProvider);

				try {
					keyManagerFactory.init(keyStore, passPhrase);
				} catch (UnrecoverableKeyException var51) {
					throw new UnrecoverableKeyException(
							var51.getMessage() + ": invalid password for file '" + keyFileLocation + "'");
				}
			}

			X509KeyManager customX509KeyManager = null;
			if (customKeyManager != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Processing custom KeyManager.");
				}

				customX509KeyManager = this.getCustomKeyManager(keyManagerFactory, keyStore, passPhrase, sslConfig,
						customKeyManager);
			}

			WSX509KeyManager wsKeyManager = new WSX509KeyManager(keyStore, passPhrase, keyManagerFactory, sslConfig,
					customX509KeyManager);
			if (serverAliasName != null && serverAliasName.length() > 0) {
				wsKeyManager.setServerAlias(serverAliasName, slotnum);
			}

			if (clientAliasName != null && clientAliasName.length() > 0) {
				wsKeyManager.setClientAlias(clientAliasName, slotnum);
			}

			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Initializing WSX509KeyManager.",
						new Object[]{serverAliasName, clientAliasName, tokenSlot});
			}

			KeyManager[] kmArrayHolder = new KeyManager[]{wsKeyManager};
			kmHolder.setKeyManagers(kmArrayHolder);
			TrustManager[] defaultTMArray = trustManagerFactory.getTrustManagers();
			TrustManager[] completeTMArray = null;
			if (customTrustManagers != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Processing custom TrustManagers.");
				}

				completeTMArray = this.getTrustManagerArray(defaultTMArray, trustStore, sslConfig, customTrustManagers);
				if (completeTMArray != null) {
					defaultTMArray = completeTMArray;
				}
			}

			WSX509TrustManager wsTrustManager = new WSX509TrustManager(defaultTMArray, connectionInfo, sslConfig,
					trustStore, trustFileLocation, trustFilePassword);
			TrustManager[] tmArrayHolder = new TrustManager[]{wsTrustManager};
			tmHolder.setTrustManagers(tmArrayHolder);
		} catch (Exception var52) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception caught during init, " + var52);
			}

			Manager.Ffdc.log(var52, this, "com.ibm.ws.ssl.provider.AbstractJSSEProvider", "597", new Object[]{this});
			throw var52;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getKeyTrustManagers");
		}

	}

	void initializeTrustManagerFactory(TrustManagerFactory trustManagerFactory, KeyStore trustStore)
			throws KeyStoreException, InvalidAlgorithmParameterException, NoSuchAlgorithmException {
		String ldapCertstoreHost = System.getProperty("com.ibm.security.ldap.certstore.host");
		String ldapCertstorePortS = System.getProperty("com.ibm.security.ldap.certstore.port");
		int ldapCertstorePort = ldapCertstorePortS == null ? 389 : Integer.parseInt(ldapCertstorePortS);
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "certStoreHost: " + ldapCertstoreHost);
			Tr.debug(tc, "certStorePort: " + ldapCertstorePort);
			Tr.debug(tc, "trustManagerAlgorithm: " + trustManagerFactory.getAlgorithm());
		}

		if (ldapCertstoreHost != null && trustManagerFactory.getAlgorithm().equals("IbmPKIX")) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Adding ldap cert store " + ldapCertstoreHost + ":" + ldapCertstorePort + " ");
			}

			ManagerFactoryParameters trustParams = this.buildManagerFactoryParameters(trustStore, ldapCertstoreHost,
					ldapCertstorePort);
			trustManagerFactory.init(trustParams);
		} else {
			trustManagerFactory.init(trustStore);
		}

	}

	ManagerFactoryParameters buildManagerFactoryParameters(KeyStore trustStore, String ldapCertstoreHost,
			int ldapCertstorePort)
			throws KeyStoreException, InvalidAlgorithmParameterException, NoSuchAlgorithmException {
		PKIXBuilderParameters pkixParams = new PKIXBuilderParameters(trustStore, new X509CertSelector());
		LDAPCertStoreParameters LDAPParms = new LDAPCertStoreParameters(ldapCertstoreHost, ldapCertstorePort);
		pkixParams.addCertStore(CertStore.getInstance("LDAP", LDAPParms));
		pkixParams.setRevocationEnabled(true);
		ManagerFactoryParameters trustParams = new CertPathTrustManagerParameters(pkixParams);
		return trustParams;
	}

	private String getSSLContextProperty(String propertyName, Properties prop, boolean processIsServer) {
		String value = null;
		if (prop != null) {
			value = prop.getProperty(propertyName);
		} else {
			value = System.getProperty(propertyName);
			if (value == null) {
				value = SSLConfigManager.getInstance().getGlobalProperty(propertyName);
			}
		}

		return value;
	}

	public X509KeyManager getCustomKeyManager(KeyManagerFactory keyManagerFactory, KeyStore keyStore, char[] passPhrase,
			SSLConfig sslConfig, String customKeyManager) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getCustomKeyManager", customKeyManager);
		}

		KeyManagerData kmData = SSLConfigManager.getInstance().getKeyManagerData(customKeyManager);
		X509KeyManager customKM = null;
		KeyManagerFactory customKMF = null;
		String algorithm;
		if (kmData != null) {
			algorithm = kmData.getAlgorithm();
			String customClass = kmData.getKeyManagerClass();
			if (customClass != null) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Loading custom key manager class: " + customClass);
				}

				customKM = this.loadCustomKeyManager(customClass);
				if (customKM != null && customKM instanceof KeyManagerExtendedInfo) {
					((KeyManagerExtendedInfo) customKM).setCustomProperties(kmData.getAdditionalKeyManagerAttrs());
				}
			} else if (algorithm != null) {
				String provider = kmData.getProvider();
				customKMF = this.getKeyManagerFactoryInstance(algorithm, provider);

				try {
					customKMF.init(keyStore, passPhrase);
				} catch (UnrecoverableKeyException var14) {
					throw new UnrecoverableKeyException(var14.getMessage());
				}

				KeyManager[] keyManagerArray = customKMF.getKeyManagers();
				if (keyManagerArray != null && keyManagerArray[0] != null) {
					customKM = (X509KeyManager) keyManagerArray[0];
				}

				if (customKM != null && customKM instanceof KeyManagerExtendedInfo) {
					((KeyManagerExtendedInfo) customKM).setCustomProperties(kmData.getAdditionalKeyManagerAttrs());
				}
			}
		} else if (customKeyManager.indexOf(".") != -1) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Loading custom key manager class: " + customKeyManager);
			}

			customKM = this.loadCustomKeyManager(customKeyManager);
		} else {
			algorithm = sslConfig.getProperty("com.ibm.ssl.contextProvider");
			customKMF = this.getKeyManagerFactoryInstance(customKeyManager, algorithm);

			try {
				customKMF.init(keyStore, passPhrase);
			} catch (UnrecoverableKeyException var13) {
				throw new UnrecoverableKeyException(var13.getMessage());
			}

			KeyManager[] keyManagerArray = customKMF.getKeyManagers();
			if (keyManagerArray != null && keyManagerArray[0] != null) {
				customKM = (X509KeyManager) keyManagerArray[0];
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getCustomKeyManager");
		}

		return customKM;
	}

	public TrustManager[] getTrustManagerArray(TrustManager[] defaultTMArray, KeyStore trustStore, SSLConfig sslConfig,
			String customTrustManagers) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getTrustManagerArray", customTrustManagers);
		}

		ArrayList tmList = new ArrayList();
		X509TrustManager customTM = null;
		TrustManagerFactory customTMF = null;

		for (int i = 0; i < defaultTMArray.length; ++i) {
			tmList.add(defaultTMArray[i]);
		}

		String[] customTMStringArray = customTrustManagers.split(",");
		if (customTMStringArray != null && customTMStringArray.length > 0) {
			for (int j = 0; j < customTMStringArray.length; ++j) {
				TrustManagerData tmData = SSLConfigManager.getInstance().getTrustManagerData(customTMStringArray[j]);
				String contextProvider;
				if (tmData != null) {
					contextProvider = tmData.getAlgorithm();
					String customClass = tmData.getTrustManagerClass();
					if (customClass != null) {
						customTM = this.loadCustomTrustManager(customClass);
						if (customTM != null) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Adding custom trust manager \"" + customClass
										+ "\" to the trust manager list.");
							}

							tmList.add(customTM);
						}

						if (customTM != null && customTM instanceof TrustManagerExtendedInfo) {
							((TrustManagerExtendedInfo) customTM)
									.setCustomProperties(tmData.getAdditionalTrustManagerAttrs());
						}
					} else if (contextProvider != null) {
						String provider = tmData.getProvider();
						customTMF = this.getTrustManagerFactoryInstance(contextProvider, provider);
						customTMF.init(trustStore);
						TrustManager[] trustManagerArray = customTMF.getTrustManagers();
						if (trustManagerArray != null && trustManagerArray[0] != null) {
							customTM = (X509TrustManager) trustManagerArray[0];
						}

						if (customTM != null) {
							if (tc.isDebugEnabled()) {
								Tr.debug(tc, "Adding custom trust manager \"" + customClass
										+ "\" to the trust manager list.");
							}

							tmList.add(customTM);
						}

						if (customTM != null && customTM instanceof TrustManagerExtendedInfo) {
							((TrustManagerExtendedInfo) customTM)
									.setCustomProperties(tmData.getAdditionalTrustManagerAttrs());
						}
					}
				} else if (customTMStringArray[j] != null && customTMStringArray[j].indexOf(".") != -1) {
					customTM = this.loadCustomTrustManager(customTMStringArray[j]);
					if (customTM != null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Adding custom trust manager \"" + customTMStringArray[j]
									+ "\" to the trust manager list.");
						}

						tmList.add(customTM);
					}
				} else if (customTMStringArray[j] != null) {
					contextProvider = sslConfig.getProperty("com.ibm.ssl.contextProvider");
					customTMF = this.getTrustManagerFactoryInstance(customTMStringArray[j], contextProvider);
					customTMF.init(trustStore);
					TrustManager[] trustManagerArray = customTMF.getTrustManagers();
					if (trustManagerArray != null && trustManagerArray[0] != null) {
						customTM = (X509TrustManager) trustManagerArray[0];
					}

					if (customTM != null) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Adding custom trust manager \"" + customTMStringArray[j]
									+ "\" to the trust manager list.");
						}

						tmList.add(customTM);
					}
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getTrustManagerArray");
		}

		return (TrustManager[]) ((TrustManager[]) tmList.toArray(new TrustManager[0]));
	}

	public URLStreamHandler getURLStreamHandler(SSLConfig config) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getURLStreamHandler");
		}

		URLStreamHandler urlStreamHandler = null;
		Properties existingProps = null;

		URLStreamHandler var4;
		try {
			existingProps = ThreadManager.getInstance().getPropertiesOnThread();
			ThreadManager.getInstance().setPropertiesOnThread(config);
			urlStreamHandler = this.getHandler();
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getURLStreamHandler");
			}

			var4 = urlStreamHandler;
		} catch (Exception var8) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getURLStreamHandler().", new Object[]{var8});
			}

			Manager.Ffdc.log(var8, this, "com.ibm.ws.ssl.provider.AbstractJSSEProvider.getURLStreamHandler", "906",
					new Object[]{this});
			if (var8 instanceof SSLException) {
				throw (javax.net.ssl.SSLException) var8;
			}

			throw new SSLException(var8);
		} finally {
			ThreadManager.getInstance().setPropertiesOnThread(existingProps);
		}

		return var4;
	}

	public SSLServerSocketFactory getSSLServerSocketFactory(SSLConfig config) throws SSLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLServerSocketFactory");
		}

		try {
			SSLContext context = this.getSSLContext((Map) null, config);
			if (context != null) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "getSSLServerSocketFactory");
				}

				return context.getServerSocketFactory();
			}
		} catch (Exception var3) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "The following exception occurred in getSSLServerSocketFactory().", new Object[]{var3});
			}

			Manager.Ffdc.log(var3, this, "com.ibm.ws.ssl.provider.AbstractJSSEProvider.getSSLServerSocketFactory",
					"937", new Object[]{this});
			if (var3 instanceof SSLException) {
				throw (SSLException) var3;
			}

			throw new SSLException(var3);
		}

		throw new SSLException("SSLContext could not be created to return an SSLServerSocketFactory.");
	}

	public SSLSocketFactory getSSLSocketFactory(Map connectionInfo, SSLConfig config) throws Exception {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSSLSocketFactory", new Object[]{connectionInfo});
		}

		SSLContext context = this.getSSLContext(connectionInfo, config);
		if (context != null) {
			SSLSocketFactory factory = context.getSocketFactory();
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getSSLSocketFactory -> " + factory.getClass().getName());
			}

			return factory;
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getSSLSocketFactory -> NULL");
			}

			throw new SSLException("SSLContext could not be created to return an SSLSocketFactory.");
		}
	}

	public SSLContext getSSLContextInstance(SSLConfig config) throws SSLException {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "getSSLContextInstance");
      }

      String contextProvider = JSSEProviderFactory.isFipsEnabled() ? "IBMJSSE2" : config.getProperty("com.ibm.ssl.contextProvider");
      String protocol = SSLConfigManager.getInstance().getSSLProtocolForFipsLevel(config);
      String alias = config.getProperty("com.ibm.ssl.alias");
      String configURL = config.getProperty("com.ibm.ssl.configURLLoadedFrom");
      SSLContext sslContext = null;
      if (protocol == null) {
         throw new IllegalArgumentException("Protocol is not specified.");
      } else {
         try {
            sslContext = (SSLContext)AccessController.doPrivileged(new 1(this, contextProvider, protocol));
         } catch (PrivilegedActionException var10) {
            Exception ex = var10.getException();
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Exception occurred getting SSL context.", new Object[]{ex});
            }

            String message;
            if (ex instanceof NoSuchAlgorithmException) {
               message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.no.such.algorithm.CWPKI0028E", new Object[]{protocol, alias, configURL, ex.getMessage()}, "CWPKI0028E: SSL handshake protocol " + protocol + " is not valid.  This protocol is specified in the SSL configuration alias " + alias + " loaded from SSL configuration file " + configURL + ".  The extended error message is: " + ex.getMessage() + ".");
               Tr.error(tc, message);
               throw new SSLException(message, ex);
            }

            if (ex instanceof NoSuchProviderException) {
               message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.invalid.context.provider.CWPKI0029E", new Object[]{"IBMJSSE2", alias, configURL, ex.getMessage()}, "CWPKI0029E: SSL context provider IBMJSSE2 is not valid.  This provider is specified in the SSL configuration alias " + alias + " loaded from SSL configuration file " + configURL + ".  The extended error message is: " + ex.getMessage() + ".");
               Tr.error(tc, message);
               throw new SSLException(message, ex);
            }

            throw new SSLException(ex);
         }

         if (tc.isEntryEnabled()) {
            Tr.exit(tc, "getSSLContextInstance");
         }

         return sslContext;
      }
   }

	public com.ibm.jsse2.SSLContext getSSLContextInstanceJSSE2(SSLConfig config) throws SSLException {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "getSSLContextInstanceJSSE2");
      }

      com.ibm.jsse2.SSLContext sslContext = null;
      String protocol = SSLConfigManager.getInstance().getSSLProtocolForFipsLevel(config);
      String alias = config.getProperty("com.ibm.ssl.alias");
      String configURL = config.getProperty("com.ibm.ssl.configURLLoadedFrom");
      if (protocol == null) {
         throw new IllegalArgumentException("Protocol is not specified.");
      } else {
         try {
            sslContext = (com.ibm.jsse2.SSLContext)AccessController.doPrivileged(new 2(this, protocol));
         } catch (PrivilegedActionException var9) {
            Exception ex = var9.getException();
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "Exception occurred getting SSL context.", new Object[]{ex});
            }

            String message;
            if (ex instanceof NoSuchAlgorithmException) {
               message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.no.such.algorithm.CWPKI0028E", new Object[]{protocol, alias, configURL, ex.getMessage()}, "CWPKI0028E: SSL handshake protocol " + protocol + " is not valid.  This protocol is specified in the SSL configuration alias " + alias + " loaded from SSL configuration file " + configURL + ".  The extended error message is: " + ex.getMessage() + ".");
               Tr.error(tc, message);
               throw new SSLException(message, ex);
            }

            if (ex instanceof NoSuchProviderException) {
               message = TraceNLSHelper.getInstance().getFormattedMessage("ssl.invalid.context.provider.CWPKI0029E", new Object[]{"IBMJSSE2", alias, configURL, ex.getMessage()}, "CWPKI0029E: SSL context provider IBMJSSE2 is not valid.  This provider is specified in the SSL configuration alias " + alias + " loaded from SSL configuration file " + configURL + ".  The extended error message is: " + ex.getMessage() + ".");
               Tr.error(tc, message);
               throw new SSLException(message, ex);
            }

            throw new SSLException(ex);
         }

         if (tc.isEntryEnabled()) {
            Tr.exit(tc, "getSSLContextInstanceJSSE2");
         }

         return sslContext;
      }
   }

	public TrustManagerFactory getTrustManagerFactoryInstance(String trustManager, String contextProvider)
			throws NoSuchAlgorithmException, NoSuchProviderException {
		String provider = contextProvider;
		if (trustManager.indexOf("|") != -1) {
			String[] trustManagerArray = trustManager.split("\\|");
			if (trustManagerArray != null && trustManagerArray.length == 2) {
				trustManager = trustManagerArray[0];
				provider = trustManagerArray[1];
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "return TrustManagerFactory.getInstance(" + trustManager + ", " + provider + ")");
		}

		return TrustManagerFactory.getInstance(trustManager, provider);
	}

	public KeyManagerFactory getKeyManagerFactoryInstance(String keyManager, String contextProvider)
			throws NoSuchAlgorithmException, NoSuchProviderException {
		if (keyManager.indexOf("|") != -1) {
			String[] keyManagerArray = keyManager.split("\\|");
			if (keyManagerArray != null && keyManagerArray.length == 2) {
				keyManager = keyManagerArray[0];
				String var3 = keyManagerArray[1];
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "return KeyManagerFactory.getInstance(" + keyManager + ", " + contextProvider + ")");
		}

		return KeyManagerFactory.getInstance(keyManager, contextProvider);
	}

	public KeyStore getKeyStoreInstance(String type, String keyStoreProvider)
			throws KeyStoreException, NoSuchProviderException {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "KeyStore.getInstance(" + type + ", " + keyStoreProvider + ")");
		}

		return keyStoreProvider != null ? KeyStore.getInstance(type, keyStoreProvider) : KeyStore.getInstance(type);
	}

	protected static void registerPackage(String pkgNamePrefix) {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "registerPackage -> " + pkgNamePrefix);
      }

      ArrayList transportPackages = new ArrayList();
      String currentPackageList = System.getProperty(URL_HANDLER_PROP);
      if (currentPackageList != null) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Current package list: " + currentPackageList);
         }

         StringTokenizer tok = new StringTokenizer(currentPackageList, "|");

         while(tok.hasMoreTokens()) {
            transportPackages.add(tok.nextToken());
         }
      }

      if (!transportPackages.contains(pkgNamePrefix)) {
         transportPackages.add(pkgNamePrefix);
         StringBuffer currentPackages = new StringBuffer();
         Iterator i = transportPackages.iterator();

         while(i.hasNext()) {
            String thisPackage = (String)i.next();
            currentPackages.append(thisPackage);
            if (i.hasNext()) {
               currentPackages.append('|');
            }
         }

         AccessController.doPrivileged(new 3(currentPackages));
         if (tc.isEntryEnabled()) {
            Tr.exit(tc, "registerPackage");
         }

      }
   }

	public URLStreamHandler getHandler() throws Exception {
		String handlerString = this.getSSLProtocolPackageHandler() + ".https.Handler";
		URLStreamHandler streamHandler = null;
		if (!createHttpsURLHandler()) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Not creating http url handler. Returning null streamHandler");
			}

			return streamHandler;
		} else {
			try {
				ClassLoader cl = (ClassLoader) java.security.AccessController.doPrivileged(getCtxClassLoader);
				if (cl != null) {
					streamHandler = (URLStreamHandler) cl.loadClass(handlerString).newInstance();
				} else {
					streamHandler = (URLStreamHandler) Class.forName(handlerString).newInstance();
				}

				return streamHandler;
			} catch (Exception var4) {
				Manager.Ffdc.log(var4, this, "com.ibm.ws.ssl.provider.AbstractJSSEProvider.getHandler", "1211",
						new Object[]{this});
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Exception loading https stream handler.", new Object[]{var4});
				}

				Tr.error(tc, "ssl.load.https.stream.handler.CWPKI0025E",
						new Object[]{handlerString, var4.getMessage()});
				throw var4;
			}
		}
	}

	public static void addHandlers(String protocolPackage) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "addHandlers", new Object[]{protocolPackage});
		}

		boolean createHttpsHandler = createHttpsURLHandler();
		if (!handlersInitialized) {
			String packageHandler;
			if (!ServerStatusHelper.isServer()) {
				packageHandler = System.getProperty(OVERWRITE_SOCKET_FACTORY);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, OVERWRITE_SOCKET_FACTORY + " from JVM property=" + packageHandler);
				}

				if (packageHandler != null && packageHandler.equalsIgnoreCase("false")) {
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "Skipping setDefaultSocketFactories");
					}
				} else {
					setDefaultSocketFactories();
				}
			} else {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Calling setDefaultSocketFactories");
				}

				setDefaultSocketFactories();
			}

			try {
				if (createHttpsHandler) {
					if (!queryHandler()) {
						createStreamHandler();
					}

					if (!queryProvider("https")) {
						packageHandler = protocolPackage + ".https.Handler";
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Adding handler: " + packageHandler);
						}

						addProvider("https", packageHandler);
					}
				}
			} catch (Throwable var4) {
				Manager.Ffdc.log(var4, AbstractJSSEProvider.class,
						"com.ibm.ws.ssl.provider.AbstractJSSEProvider.addHandlers", "1263");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc,
							"Unable to create https stream handler.  This error can be ignored as Java has default https handler",
							var4);
				}
			}

			try {
				if (PlatformHelperFactory.getPlatformHelper().isZOS()) {
					if (!queryHandler()) {
						createStreamHandler();
					}

					if (!queryProvider("safkeyring")) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Adding handler:  com.ibm.crypto.provider.safkeyring.Handler");
						}

						addProvider("safkeyring", "com.ibm.crypto.provider.safkeyring.Handler");
					}

					if (!queryProvider("safkeyringhw")) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Adding handler: com.ibm.crypto.hdwrCCA.provider.safkeyring.Handler");
						}

						addProvider("safkeyringhw", "com.ibm.crypto.hdwrCCA.provider.safkeyring.Handler");
					}

					if (!queryProvider("safkeyringhybrid")) {
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "Adding handler: com.ibm.crypto.ibmjcehybrid.provider.safkeyring.Handler");
						}

						addProvider("safkeyringhybrid", "com.ibm.crypto.ibmjcehybrid.provider.safkeyring.Handler");
					}
				}

				handlersInitialized = true;
			} catch (Throwable var3) {
				Manager.Ffdc.log(var3, AbstractJSSEProvider.class,
						"com.ibm.ws.ssl.provider.AbstractJSSEProvider.addHandlers", "1292");
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Unable to set safkeyring stream handler", var3);
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "addHandlers");
		}

	}

	public static void setDefaultSocketFactories() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setDefaultSocketFactories");
		}

		String SSLSocketFactoryClass = Security.getProperty("ssl.SocketFactory.provider");
		String SSLServerSocketFactoryClass = Security.getProperty("ssl.ServerSocketFactory.provider");
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Original SSLSocketFactory: " + SSLSocketFactoryClass + "\nOriginal SSLServerSocketFactory: "
					+ SSLServerSocketFactoryClass);
		}

		SSLSocketFactoryClass = setSSLSocketFactoryClass(SSLSocketFactoryClass);
		SSLServerSocketFactoryClass = setSSLServerSocketFactoryClass(SSLServerSocketFactoryClass);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setDefaultSocketFactories:\nCurrent SSLSocketFactory: " + SSLSocketFactoryClass
					+ "\nCurrent SSLServerSocketFactory: " + SSLServerSocketFactoryClass);
		}

	}

	static String setSSLServerSocketFactoryClass(String SSLServerSocketFactoryClass) {
      if (SSLServerSocketFactoryClass == null) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Default SSLServerSocketFactoryClass isn't set, try to load WebSphere SSLServerSocketFactory");
         }

         if (isClassAvailable(SSL_SERVER_SOCKET_FACTORY_NAME)) {
            AccessController.doPrivileged(new 4());
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "setDefaultSocketFactories", "The following server socket factory has been set: " + SSL_SERVER_SOCKET_FACTORY_NAME);
            }

            SSLServerSocketFactoryClass = SSL_SERVER_SOCKET_FACTORY_NAME;
         } else if (tc.isDebugEnabled()) {
            Tr.debug(tc, "IBM SSLServerSocketFactory doesn't exist, use current setting");
         }
      }

      return SSLServerSocketFactoryClass;
   }

	static String setSSLSocketFactoryClass(String SSLSocketFactoryClass) {
      if (SSLSocketFactoryClass == null) {
         if (tc.isDebugEnabled()) {
            Tr.debug(tc, "Default SSLSocketFactoryClass isn't set, try to load WebSphere SSLSocketFactory");
         }

         if (isClassAvailable(SSL_SOCKET_FACTORY_NAME)) {
            AccessController.doPrivileged(new 5());
            if (tc.isDebugEnabled()) {
               Tr.debug(tc, "setDefaultSocketFactories", "The following socket factories have been set: " + SSL_SOCKET_FACTORY_NAME);
            }

            SSLSocketFactoryClass = SSL_SOCKET_FACTORY_NAME;
         } else if (tc.isDebugEnabled()) {
            Tr.debug(tc, "IBM SSLSocketFactory doesn't exist, use current setting");
         }
      }

      return SSLSocketFactoryClass;
   }

	private static boolean isClassAvailable(String ClassName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isClassAvaiable", ClassName);
		}

		boolean result = true;

		try {
			Thread.currentThread().getContextClassLoader().loadClass(ClassName);
		} catch (ClassNotFoundException var3) {
			if (tc.isEntryEnabled()) {
				Tr.debug(tc, "isClassAvailable", "Unable to load class \"" + ClassName + "\".");
			}

			result = false;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isClassAvaiable", result);
		}

		return result;
	}

	private X509KeyManager loadCustomKeyManager(String kmClass) throws Exception {
		X509KeyManager km = null;

		try {
			ClassLoader cl = (ClassLoader) java.security.AccessController.doPrivileged(getCtxClassLoader);
			if (cl != null) {
				try {
					km = (X509KeyManager) cl.loadClass(kmClass).newInstance();
				} catch (Exception var5) {
					;
				}
			}

			if (km == null) {
				km = (X509KeyManager) Class.forName(kmClass).newInstance();
			}

			return km;
		} catch (Exception var6) {
			Manager.Ffdc.log(var6, this, "com.ibm.ws.ssl.provider.AbstractJSSEProvider.loadCustomKeyManager", "1424",
					new Object[]{this});
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception loading custom KeyManager.", new Object[]{var6});
			}

			Tr.error(tc, "ssl.load.keymanager.error.CWPKI0021E", new Object[]{kmClass, var6.getMessage()});
			throw var6;
		}
	}

	private X509TrustManager loadCustomTrustManager(String tmClass) throws Exception {
		X509TrustManager tm = null;

		try {
			ClassLoader cl = (ClassLoader) java.security.AccessController.doPrivileged(getCtxClassLoader);
			if (cl != null) {
				try {
					tm = (X509TrustManager) cl.loadClass(tmClass).newInstance();
				} catch (Exception var5) {
					;
				}
			}

			if (tm == null) {
				tm = (X509TrustManager) Class.forName(tmClass).newInstance();
			}

			return tm;
		} catch (Exception var6) {
			Manager.Ffdc.log(var6, this, "com.ibm.ws.ssl.provider.AbstractJSSEProvider.loadCustomTrustManager", "1461",
					new Object[]{this});
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception loading custom TrustManager.", new Object[]{var6});
			}

			Tr.error(tc, "ssl.load.trustmanager.error.CWPKI0020E", new Object[]{tmClass, var6.getMessage()});
			throw var6;
		}
	}

	private static boolean queryHandler() {
		try {
			Class<?> shuClass = Class.forName("com.ibm.ws.runtime.util.StreamHandlerUtils");
			Method shuClassQueryHandlerMethod = shuClass.getMethod("queryHandler");
			Boolean handlerStatus = (Boolean) shuClassQueryHandlerMethod.invoke((Object) null);
			if (handlerStatus != null) {
				return handlerStatus;
			}
		} catch (Exception var3) {
			Manager.Ffdc.log(var3, AbstractJSSEProvider.class,
					"com.ibm.ws.ssl.provider.AbstractJSSEProvider.queryHandler", "1494");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception: ", new Object[]{var3});
			}
		}

		return false;
	}

	private static boolean queryProvider(String provider) {
		try {
			Class<?> shuClass = Class.forName("com.ibm.ws.runtime.util.StreamHandlerUtils");
			Method shuClassQueryProviderMethod = shuClass.getMethod("queryProvider", String.class);
			Boolean providerStatus = (Boolean) shuClassQueryProviderMethod.invoke((Object) null, provider);
			if (providerStatus != null) {
				return providerStatus;
			}
		} catch (Exception var4) {
			Manager.Ffdc.log(var4, AbstractJSSEProvider.class,
					"com.ibm.ws.ssl.provider.AbstractJSSEProvider.queryProvider", "1513");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception: ", new Object[]{var4});
			}
		}

		return false;
	}

	private static void addProvider(String provider, String handler) {
		try {
			Class shuClass = Class.forName("com.ibm.ws.runtime.util.StreamHandlerUtils");
			Method shuClassStaticAddProviderMethod = shuClass.getMethod("addProvider", String.class, String.class);
			shuClassStaticAddProviderMethod.invoke((Object) null, provider, handler);
		} catch (Exception var4) {
			Manager.Ffdc.log(var4, AbstractJSSEProvider.class,
					"com.ibm.ws.ssl.provider.AbstractJSSEProvider.addProvider", "1531");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception: ", new Object[]{var4});
			}
		}

	}

	private static void createStreamHandler() {
		try {
			Class<?> shuClass = Class.forName("com.ibm.ws.runtime.util.StreamHandlerUtils");
			Method shuClassStaticCreateStreamHandlerMethod = shuClass.getMethod("createStreamHandler");
			shuClassStaticCreateStreamHandlerMethod.invoke((Object) null);
		} catch (Exception var2) {
			Manager.Ffdc.log(var2, AbstractJSSEProvider.class,
					"com.ibm.ws.ssl.provider.AbstractJSSEProvider.createStreamHandler", "1548");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Exception: ", new Object[]{var2});
			}
		}

	}

	public static void clearSSLContextCache() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "clearSSLContextCache");
		}

		if (sslContextCacheJAVAX != null && sslContextCacheJAVAX.size() > 0) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Clearing standard javax.net.ssl.SSLContext cache.");
			}

			sslContextCacheJAVAX.clear();
		}

		if (sslContextCacheJSSE2 != null && sslContextCacheJSSE2.size() > 0) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Clearing com.ibm.jsse2.SSLContext cache.");
			}

			sslContextCacheJSSE2.clear();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "clearSSLContextCache");
		}

	}

	private void setOutboundConnectionInfoInternal(Map connectionInfo) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setOutboundConnectionInfoInternal");
		}

		Map outbound = null;
		if (connectionInfo != null) {
			String direction = (String) connectionInfo.get("com.ibm.ssl.direction");
			if (direction != null && direction.length() > 0 && direction.equalsIgnoreCase("outbound")) {
				outbound = connectionInfo;
			}
		}

		ThreadManager.getInstance().setOutboundConnectionInfoInternal(outbound);
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "outboundConnectionInfo: " + outbound);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setOutboundConnectionInfoInternal");
		}

	}

	private static boolean createHttpsURLHandler() {
		if (!handlersInitialized) {
			String prop = System.getProperty(CREATE_HTTPS_URL_HANDLER_JVM_PROP);
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "JVM System property:" + CREATE_HTTPS_URL_HANDLER_JVM_PROP + " is set to "
						+ createHttpsURLHandlerFlag);
			}

			if (prop != null && prop.equalsIgnoreCase("false")) {
				createHttpsURLHandlerFlag = false;
			}
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "createHttpsURLHandler:" + createHttpsURLHandlerFlag);
		}

		return createHttpsURLHandlerFlag;
	}
}