package com.ibm.ws.wim.adapter.ldap.change.ad;

import com.ibm.websphere.wim.SchemaConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.adapter.ldap.DeletedControl;
import com.ibm.ws.wim.adapter.ldap.LdapConnection;
import com.ibm.ws.wim.adapter.ldap.LdapEntry;
import com.ibm.ws.wim.adapter.ldap.change.IChangeHandler;
import com.ibm.ws.wim.util.StringUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;

public class ADChangeHandler implements IChangeHandler, SchemaConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private final String ROOT_DSE_CHANGE_CHECKPOINT_ATTR = "highestCommittedUSN";
	private final String DEFAULT_LDAP_FILTER = "(objectclass=*)";
	private final String ROOT_DSE_BASE = "";
	private final String USN_CHANGED = "uSNChanged";
	private final String USN_CREATED = "uSNCreated";
	private final String LAST_KNOWN_PARENT = "lastKnownParent";
	private final String IS_DELETED = "isDeleted";
	private final String NAMING_CONTEXTS_ATTR = "namingContexts";
	private LdapConnection _ldapConn;

	public ADChangeHandler(LdapConnection var1) throws WIMException {
		this._ldapConn = var1;
	}

	public String getCurrentCheckPoint() throws WIMException {
		String var2 = null;
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getCurrentCheckPoint");
		}

		try {
			NamingEnumeration var4 = this._ldapConn.search_skip_cache("", "(objectclass=*)", 0,
					new String[]{"highestCommittedUSN"}, (Control[]) null);
			if (var4.hasMore()) {
				SearchResult var5 = (SearchResult) var4.next();
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getCurrentCheckPoint", "searchResult=" + var5);
				}

				Attribute var6 = var5.getAttributes().get("highestCommittedUSN");
				String var7 = (String) var6.get();
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "getCurrentCheckPoint", "highestCommittedUSNVal=" + var7);
				}

				long var8 = new Long(var7) + 1L;
				var2 = Long.toString(var8);
			}
		} catch (NamingException var10) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var10.toString(true)),
					Level.SEVERE, CLASSNAME, "getCurrentCheckPoint", var10);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getCurrentCheckPoint", "Checkpoint = " + var2);
		}

		return var2;
	}

	public List searchChangedEntities(String var1, List var2, String var3, String var4, int var5, List var6, List var7,
			int var8, int var9) throws WIMException {
		ArrayList var11 = null;
		Control[] var12 = null;
		boolean var13 = trcLogger.isLoggable(Level.FINER);
		if (var13) {
			trcLogger.entering(CLASSNAME, "searchChangedEntities", "CheckPoint=" + var1);
		}

		String var14 = "(&(uSNChanged>=" + var1 + ")" + var4 + ")";

		try {
			var7.add("uSNChanged");
			var7.add("uSNCreated");
			var7.add("lastKnownParent");
			var7.add("isDeleted");
			Set var15 = this._ldapConn.searchEntities_skip_cache(var3, var14, var5, var6, var7, var8, var9, var12);
			NamingEnumeration var17;
			Attribute var19;
			String var21;
			String var23;
			if (var2 == null || var2.size() == 0 || var2.contains("*") || var2.contains("delete")) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "searchChangedEntities",
							"Change type is delete or *(all changetypes) or null.");
				}

				String var16 = null;
				var17 = this._ldapConn.search_skip_cache("", "(objectclass=*)", 0, new String[]{"namingContexts"},
						(Control[]) null);
				if (var17.hasMore()) {
					SearchResult var18 = (SearchResult) var17.next();
					if (var13) {
						trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities", "namingContext=" + var18);
					}

					var19 = var18.getAttributes().get("namingContexts");
					NamingEnumeration var20 = var19.getAll();

					label142 : while (true) {
						do {
							do {
								if (!var20.hasMore()) {
									break label142;
								}

								var21 = var20.next().toString();
							} while (!StringUtil.endsWithIgnoreCase(var3, var21));
						} while (var16 != null && var16.length() >= var21.length());

						var16 = var21;
					}
				}

				if (var16 != null) {
					if (var13) {
						trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities",
								"Searching for Deleted Objects in " + var16 + " Naming Context.");
					}

					var12 = new Control[]{new DeletedControl()};
					String var30 = "(&(" + var14 + ")(" + "isDeleted" + "=TRUE))";
					Set var32 = this._ldapConn.searchEntities_skip_cache(var16, var30, 2, var6, var7, var8, var9,
							var12);
					Iterator var34 = var32.iterator();
					int var37 = 0;

					while (var34.hasNext()) {
						LdapEntry var22 = (LdapEntry) var34.next();
						var23 = (String) var22.getAttributes().get("lastKnownParent").get();
						if (StringUtil.endsWithIgnoreCase(var23, var3)) {
							var15.add(var22);
							++var37;
						}
					}

					if (var13) {
						trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities",
								var37 + " Objects were deleted from subtree " + var3);
					}
				} else if (var13) {
					trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities",
							"Not Searching for Deleted Objects because matching Naming Context not found.");
				}
			}

			Iterator var28 = var15.iterator();
			var17 = null;
			if (var28.hasNext()) {
				var11 = new ArrayList(10);
			}

			while (true) {
				LdapEntry var29;
				String var33;
				do {
					if (!var28.hasNext()) {
						return var11;
					}

					var29 = (LdapEntry) var28.next();
					Attributes var31 = var29.getAttributes();
					if (var13) {
						trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities", "attrs=" + var31);
					}

					var19 = null;
					if (var31.get("isDeleted") != null) {
						var33 = "delete";
						String var35 = var29.getDN();
						var21 = (String) var31.get("lastKnownParent").get();
						if (var13) {
							trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities",
									"DN = " + var35 + ". Parent of deleted entry = " + var21);
						}

						int var38 = var35.indexOf("\n");
						if (var38 >= 0) {
							var23 = var35.substring(0, var38);
							String var24 = var23 + "," + var21;
							String var25 = var29.getType();
							if (var13) {
								trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities",
										"entityType=" + var25 + ", oldDN = " + var24);
							}

							String var26 = this._ldapConn.getUniqueName(var24, var25, var31);
							var29.setIUniqueName(var26);
							if (var13) {
								trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities", "newDN = " + var26);
							}
						}
					} else {
						long var36 = Long.parseLong(var31.get("uSNChanged").get().toString()) + 1L;
						long var39 = Long.parseLong(var31.get("uSNCreated").get().toString()) + 1L;
						if (var13) {
							trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities",
									"For added, modified or deleted entry, the value of attribute usnCreated = " + var39
											+ " usnChanged = " + var36);
						}

						if (var36 - var39 == 1L) {
							if (var13) {
								trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities",
										"Since the attributes usnCreated == usnChanged, changeType for the entry is add");
							}

							var33 = "add";
						} else {
							if (var13) {
								trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities",
										"Since the attributes usnCreated(" + var39 + ") != usnChanged(" + var36
												+ "), changeType for the entry is modify");
							}

							var33 = "modify";
						}
					}

					var29.setChangeType(var33);
				} while (var2 != null && var2.size() != 0 && !var2.contains("*") && !var2.contains(var33)
						&& (!var2.contains("rename") || !"modify".equals(var33)));

				if (var13) {
					trcLogger.logp(Level.FINER, CLASSNAME, "searchChangedEntities",
							"LDAP entry being added to final result set is : " + var29);
				}

				var11.add(var29);
			}
		} catch (NamingException var27) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var27.toString(true)),
					Level.SEVERE, CLASSNAME, "searchChangedEntities", var27);
		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2010;
		CLASSNAME = ADChangeHandler.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}