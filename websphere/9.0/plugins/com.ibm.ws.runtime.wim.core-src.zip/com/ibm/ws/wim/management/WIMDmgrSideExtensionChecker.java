package com.ibm.ws.wim.management;

import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.cmdframework.AdminCommand;
import com.ibm.websphere.management.cmdframework.CommandMgr;
import com.ibm.websphere.management.cmdframework.CommandResult;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.management.configservice.ConfigServiceFactory;
import com.ibm.websphere.management.exception.ConfigServiceException;
import com.ibm.websphere.management.exception.ConnectorException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.management.util.Utils;
import com.ibm.ws.wim.config.ConfigValidator;
import com.ibm.ws.wim.config.ConfigValidator.InterOpFeatures;
import com.ibm.wsspi.management.tools.DmgrSideExtensionChecker;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WIMDmgrSideExtensionChecker implements DmgrSideExtensionChecker {
	private static final String CLASS_NAME = WIMDmgrSideExtensionChecker.class.getName();
	private static final Logger logger;

	public void checkCompatibility(Properties var1, Properties var2) throws Exception {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(CLASS_NAME, "checkCompatibility(Properties,Properties)", new Object[]{var1, var2});
		}

		ArrayList var4 = null;
		String var5 = var1.getProperty("com.ibm.websphere.baseProductVersion");
		if (logger.isLoggable(Level.FINEST)) {
			logger.finest("checkCompatibility(Properties,Properties): Remote node product version is " + var5);
		}

		String var6 = ConfigValidator.getVersionToCompare(var5, InterOpFeatures.HASH);
		if (logger.isLoggable(Level.FINEST)) {
			logger.finest("checkCompatibility(Properties,Properties): Hash version to compare is " + var6);
		}

		if (Utils.compareVersions(var5, var6) < 0) {
			if (logger.isLoggable(Level.FINEST)) {
				logger.finest(
						"checkCompatibility(Properties,Properties): The remote node's version does not support the new hashing algorithms.");
			}

			if (var4 == null) {
				var4 = new ArrayList();
				var4.addAll(listSecurityDomains());
			}

			Iterator var7 = var4.iterator();

			while (var7.hasNext()) {
				String var8 = (String) var7.next();
				List var9 = ConfigValidator.checkWIMUserRegistryForFeature(var8, InterOpFeatures.HASH);
				if (!var9.isEmpty()) {
					var8 = var8.trim().isEmpty() ? "admin" : var8;
					String var10 = (new WIMConfigurationException("UNSUPPORTED_HASHING_ALGORITHM_ADD_NODE",
							new Object[]{var9, var8})).getMessage();
					throw new WIMConfigurationException(var10);
				}
			}
		}

		String var12 = ConfigValidator.getVersionToCompare(var5, InterOpFeatures.GSSAPI);
		if (logger.isLoggable(Level.FINEST)) {
			logger.finest(
					"checkCompatibility(Properties,Properties): Version to compare for bindAuthMechanism is " + var12);
		}

		if (Utils.compareVersions(var5, var12) < 0) {
			if (logger.isLoggable(Level.FINEST)) {
				logger.finest(
						"checkCompatibility(Properties,Properties): The remote node's version does not support the new bindAuthMechanism for GSSAPI/Kerberos.");
			}

			if (var4 == null) {
				var4 = new ArrayList();
				var4.addAll(listSecurityDomains());
			}

			Iterator var13 = var4.iterator();

			while (var13.hasNext()) {
				String var14 = (String) var13.next();
				List var15 = ConfigValidator.checkWIMUserRegistryForFeature(var14, InterOpFeatures.GSSAPI);
				if (!var15.isEmpty()) {
					var14 = var14.trim().isEmpty() ? "admin" : var14;
					String var11 = (new WIMConfigurationException("UNSUPPORTED_AUTH_MECH_ADD_NODE",
							new Object[]{var15, var14, "GSSAPI (Kerberos)"})).getMessage();
					throw new WIMConfigurationException(var11);
				}
			}
		}

		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(CLASS_NAME, "checkCompatibility(Properties,Properties)");
		}

	}

	private static List<String> listSecurityDomains() throws Exception {
		if (logger.isLoggable(Level.FINER)) {
			logger.entering(CLASS_NAME, "listSecurityDomains()");
		}

		List var1 = null;
		CommandMgr var2 = CommandMgr.getCommandMgr();
		if (var2 != null) {
			AdminCommand var3 = var2.createCommand("listSecurityDomains");
			ConfigService var4 = ConfigServiceFactory.getConfigService();
			Session var5 = new Session();

			try {
				var3.setConfigSession(var5);
				var3.execute();
				CommandResult var6 = var3.getCommandResult();
				if (!var6.isSuccessful()) {
					Throwable var7 = var6.getException();
					if (var7 instanceof Exception) {
						throw (Exception) var7;
					}

					throw new Exception(var7.getMessage(), var7);
				}

				var1 = (List) var6.getResult();
			} finally {
				try {
					var4.discard(var5);
				} catch (ConnectorException var15) {
					logger.finest("listSecurityDomains(): Ignoring: " + var15.getMessage());
				} catch (ConfigServiceException var16) {
					logger.finest("listSecurityDomains(): Ignoring: " + var16.getMessage());
				}

			}
		}

		var1.add(0, "");
		if (logger.isLoggable(Level.FINER)) {
			logger.exiting(CLASS_NAME, "listSecurityDomains()", var1);
		}

		return var1;
	}

	static {
		logger = WIMLogger.getTraceLogger(CLASS_NAME);
	}
}