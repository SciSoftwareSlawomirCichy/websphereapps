package com.google.common.primitives;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.primitives.Booleans.BooleanArrayAsList;
import com.google.common.primitives.Booleans.LexicographicalComparator;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@GwtCompatible
public final class Booleans {
	public static int hashCode(boolean value) {
		return value ? 1231 : 1237;
	}

	public static int compare(boolean a, boolean b) {
		return a == b ? 0 : (a ? 1 : -1);
	}

	public static boolean contains(boolean[] array, boolean target) {
		boolean[] arr$ = array;
		int len$ = array.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			boolean value = arr$[i$];
			if (value == target) {
				return true;
			}
		}

		return false;
	}

	public static int indexOf(boolean[] array, boolean target) {
		return indexOf(array, target, 0, array.length);
	}

	private static int indexOf(boolean[] array, boolean target, int start, int end) {
		for (int i = start; i < end; ++i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static int indexOf(boolean[] array, boolean[] target) {
		Preconditions.checkNotNull(array, "array");
		Preconditions.checkNotNull(target, "target");
		if (target.length == 0) {
			return 0;
		} else {
			label28 : for (int i = 0; i < array.length - target.length + 1; ++i) {
				for (int j = 0; j < target.length; ++j) {
					if (array[i + j] != target[j]) {
						continue label28;
					}
				}

				return i;
			}

			return -1;
		}
	}

	public static int lastIndexOf(boolean[] array, boolean target) {
		return lastIndexOf(array, target, 0, array.length);
	}

	private static int lastIndexOf(boolean[] array, boolean target, int start, int end) {
		for (int i = end - 1; i >= start; --i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static boolean[] concat(boolean[]... arrays) {
		int length = 0;
		boolean[][] arr$ = arrays;
		int pos = arrays.length;

		for (int i$ = 0; i$ < pos; ++i$) {
			boolean[] array = arr$[i$];
			length += array.length;
		}

		boolean[] result = new boolean[length];
		pos = 0;
		boolean[][] arr$ = arrays;
		int len$ = arrays.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			boolean[] array = arr$[i$];
			System.arraycopy(array, 0, result, pos, array.length);
			pos += array.length;
		}

		return result;
	}

	public static boolean[] ensureCapacity(boolean[] array, int minLength, int padding) {
		Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[]{minLength});
		Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[]{padding});
		return array.length < minLength ? copyOf(array, minLength + padding) : array;
	}

	private static boolean[] copyOf(boolean[] original, int length) {
		boolean[] copy = new boolean[length];
		System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
		return copy;
	}

	public static String join(String separator, boolean... array) {
		Preconditions.checkNotNull(separator);
		if (array.length == 0) {
			return "";
		} else {
			StringBuilder builder = new StringBuilder(array.length * 7);
			builder.append(array[0]);

			for (int i = 1; i < array.length; ++i) {
				builder.append(separator).append(array[i]);
			}

			return builder.toString();
		}
	}

	public static Comparator<boolean[]> lexicographicalComparator() {
		return LexicographicalComparator.INSTANCE;
	}

	public static boolean[] toArray(Collection<Boolean> collection) {
		if (collection instanceof BooleanArrayAsList) {
			return ((BooleanArrayAsList) collection).toBooleanArray();
		} else {
			Object[] boxedArray = collection.toArray();
			int len = boxedArray.length;
			boolean[] array = new boolean[len];

			for (int i = 0; i < len; ++i) {
				array[i] = (Boolean) Preconditions.checkNotNull(boxedArray[i]);
			}

			return array;
		}
	}

	public static List<Boolean> asList(boolean... backingArray) {
		return (List) (backingArray.length == 0 ? Collections.emptyList() : new BooleanArrayAsList(backingArray));
	}
}