package com.ibm.ejs.container;

public class BeanManagedBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, EJSHome h) {
		return new BeanManagedBeanOImpl(c, h);
	}
}