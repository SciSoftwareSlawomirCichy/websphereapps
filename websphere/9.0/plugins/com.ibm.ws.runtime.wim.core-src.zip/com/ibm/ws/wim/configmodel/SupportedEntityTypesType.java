package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface SupportedEntityTypesType {
	List getRdnProperties();

	String[] getRdnPropertiesAsArray();

	String getDefaultParent();

	void setDefaultParent(String var1);

	String getName();

	void setName(String var1);
}