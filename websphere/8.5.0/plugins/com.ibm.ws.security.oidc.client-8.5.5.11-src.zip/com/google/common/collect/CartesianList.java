package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.CartesianList.1;
import com.google.common.collect.ImmutableList.Builder;
import com.google.common.math.IntMath;
import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import javax.annotation.Nullable;

@GwtCompatible
final class CartesianList<E> extends AbstractList<List<E>> {
	private final transient ImmutableList<List<E>> axes;
	private final transient int[] axesSizeProduct;

	static <E> List<List<E>> create(List<? extends List<? extends E>> lists) {
		Builder<List<E>> axesBuilder = new Builder(lists.size());
		Iterator i$ = lists.iterator();

		while (i$.hasNext()) {
			List<? extends E> list = (List) i$.next();
			List<E> copy = ImmutableList.copyOf(list);
			if (copy.isEmpty()) {
				return ImmutableList.of();
			}

			axesBuilder.add(copy);
		}

		return new CartesianList(axesBuilder.build());
	}

	CartesianList(ImmutableList<List<E>> axes) {
		this.axes = axes;
		int[] axesSizeProduct = new int[axes.size() + 1];
		axesSizeProduct[axes.size()] = 1;

		try {
			for (int i = axes.size() - 1; i >= 0; --i) {
				axesSizeProduct[i] = IntMath.checkedMultiply(axesSizeProduct[i + 1], ((List) axes.get(i)).size());
			}
		} catch (ArithmeticException var4) {
			throw new IllegalArgumentException("Cartesian product too large; must have size at most Integer.MAX_VALUE");
		}

		this.axesSizeProduct = axesSizeProduct;
	}

	private int getAxisIndexForProductIndex(int index, int axis) {
		return index / this.axesSizeProduct[axis + 1] % ((List) this.axes.get(axis)).size();
	}

	public ImmutableList<E> get(int index) {
      Preconditions.checkElementIndex(index, this.size());
      return new 1(this, index);
   }

	public int size() {
		return this.axesSizeProduct[0];
	}

	public boolean contains(@Nullable Object o) {
		if (!(o instanceof List)) {
			return false;
		} else {
			List<?> list = (List) o;
			if (list.size() != this.axes.size()) {
				return false;
			} else {
				ListIterator itr = list.listIterator();

				int index;
				do {
					if (!itr.hasNext()) {
						return true;
					}

					index = itr.nextIndex();
				} while (((List) this.axes.get(index)).contains(itr.next()));

				return false;
			}
		}
	}

	public int indexOf(Object o) {
		if (!(o instanceof List)) {
			return -1;
		} else {
			List<?> l = (List) o;
			if (l.size() != this.axes.size()) {
				return -1;
			} else {
				Iterator<?> lIterator = l.iterator();
				int i = 0;

				List axis;
				int axisIndex;
				for (Iterator i$ = this.axes.iterator(); i$.hasNext(); i = i * axis.size() + axisIndex) {
					axis = (List) i$.next();
					Object lElement = lIterator.next();
					axisIndex = axis.indexOf(lElement);
					if (axisIndex == -1) {
						return -1;
					}
				}

				return i;
			}
		}
	}

	public int lastIndexOf(Object o) {
		if (!(o instanceof List)) {
			return -1;
		} else {
			List<?> l = (List) o;
			if (l.size() != this.axes.size()) {
				return -1;
			} else {
				Iterator<?> lIterator = l.iterator();
				int i = 0;

				List axis;
				int axisIndex;
				for (Iterator i$ = this.axes.iterator(); i$.hasNext(); i = i * axis.size() + axisIndex) {
					axis = (List) i$.next();
					Object lElement = lIterator.next();
					axisIndex = axis.lastIndexOf(lElement);
					if (axisIndex == -1) {
						return -1;
					}
				}

				return i;
			}
		}
	}
}