package com.ibm.ws.wim.configmodel;

import com.ibm.ws.wim.configmodel.impl.ConfigmodelPackageImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

public interface ConfigmodelPackage extends EPackage {
	String eNAME = "com.ibm.ws.wim.configmodel";
	String eNS_URI = "http://www.ibm.com/websphere/wim/config";
	String eNS_PREFIX = "config";
	ConfigmodelPackage eINSTANCE = ConfigmodelPackageImpl.init();
	int ATTRIBUTE_CONFIGURATION_TYPE = 0;
	int ATTRIBUTE_CONFIGURATION_TYPE__EXTERNAL_ID_ATTRIBUTES = 0;
	int ATTRIBUTE_CONFIGURATION_TYPE__ATTRIBUTES = 1;
	int ATTRIBUTE_CONFIGURATION_TYPE__PROPERTIES_NOT_SUPPORTED = 2;
	int ATTRIBUTE_CONFIGURATION_TYPE_FEATURE_COUNT = 3;
	int ATTRIBUTE_GROUP_TYPE = 1;
	int ATTRIBUTE_GROUP_TYPE__GROUP_NAME = 0;
	int ATTRIBUTE_GROUP_TYPE__ATTRIBUTE_NAMES = 1;
	int ATTRIBUTE_GROUP_TYPE_FEATURE_COUNT = 2;
	int ATTRIBUTES_CACHE_TYPE = 2;
	int ATTRIBUTES_CACHE_TYPE__ATTRIBUTE_SIZE_LIMIT = 0;
	int ATTRIBUTES_CACHE_TYPE__CACHE_SIZE = 1;
	int ATTRIBUTES_CACHE_TYPE__CACHE_TIME_OUT = 2;
	int ATTRIBUTES_CACHE_TYPE__ENABLED = 3;
	int ATTRIBUTES_CACHE_TYPE__SERVER_TTL_ATTRIBUTE = 4;
	int ATTRIBUTES_CACHE_TYPE__CACHE_DIST_POLICY = 5;
	int ATTRIBUTES_CACHE_TYPE_FEATURE_COUNT = 6;
	int ATTRIBUTE_TYPE = 3;
	int ATTRIBUTE_TYPE__ENTITY_TYPES = 0;
	int ATTRIBUTE_TYPE__DEFAULT_ATTRIBUTE = 1;
	int ATTRIBUTE_TYPE__DEFAULT_VALUE = 2;
	int ATTRIBUTE_TYPE__NAME = 3;
	int ATTRIBUTE_TYPE__PROPERTY_NAME = 4;
	int ATTRIBUTE_TYPE__SYNTAX = 5;
	int ATTRIBUTE_TYPE__WIM_GENERATE = 6;
	int ATTRIBUTE_TYPE_FEATURE_COUNT = 7;
	int AUTHORIZATION_TYPE = 4;
	int AUTHORIZATION_TYPE__ATTRIBUTE_GROUPS = 0;
	int AUTHORIZATION_TYPE__DEFAULT_ATTRIBUTE_GROUP = 1;
	int AUTHORIZATION_TYPE__IMPORT_POLICY_FROM_FILE = 2;
	int AUTHORIZATION_TYPE__IS_ATTRIBUTE_GROUPING_ENABLED = 3;
	int AUTHORIZATION_TYPE__IS_SECURITY_ENABLED = 4;
	int AUTHORIZATION_TYPE__JACC_POLICY_CLASS = 5;
	int AUTHORIZATION_TYPE__JACC_POLICY_CONFIG_FACTORY_CLASS = 6;
	int AUTHORIZATION_TYPE__JACC_PRINCIPAL_TO_ROLE_POLICY_FILE_NAME = 7;
	int AUTHORIZATION_TYPE__JACC_PRINCIPAL_TO_ROLE_POLICY_ID = 8;
	int AUTHORIZATION_TYPE__JACC_ROLE_MAPPING_CLASS = 9;
	int AUTHORIZATION_TYPE__JACC_ROLE_MAPPING_CONFIG_FACTORY_CLASS = 10;
	int AUTHORIZATION_TYPE__JACC_ROLE_TO_PERMISSION_POLICY_FILE_NAME = 11;
	int AUTHORIZATION_TYPE__JACC_ROLE_TO_PERMISSION_POLICY_ID = 12;
	int AUTHORIZATION_TYPE__USE_SYSTEM_JACC_PROVIDER = 13;
	int AUTHORIZATION_TYPE_FEATURE_COUNT = 14;
	int BASE_ENTRIES_TYPE = 5;
	int BASE_ENTRIES_TYPE__NAME = 0;
	int BASE_ENTRIES_TYPE__NAME_IN_REPOSITORY = 1;
	int BASE_ENTRIES_TYPE_FEATURE_COUNT = 2;
	int CACHE_CONFIGURATION_TYPE = 6;
	int CACHE_CONFIGURATION_TYPE__ATTRIBUTES_CACHE = 0;
	int CACHE_CONFIGURATION_TYPE__SEARCH_RESULTS_CACHE = 1;
	int CACHE_CONFIGURATION_TYPE__CACHES_DISK_OFF_LOAD = 2;
	int CACHE_CONFIGURATION_TYPE_FEATURE_COUNT = 3;
	int CONFIGURATION_PROVIDER_TYPE = 7;
	int CONFIGURATION_PROVIDER_TYPE__DYNAMIC_MODEL = 0;
	int CONFIGURATION_PROVIDER_TYPE__STATIC_MODEL = 1;
	int CONFIGURATION_PROVIDER_TYPE__SUPPORTED_ENTITY_TYPES = 2;
	int CONFIGURATION_PROVIDER_TYPE__ENTRY_MAPPING_REPOSITORY = 3;
	int CONFIGURATION_PROVIDER_TYPE__PROPERTY_EXTENSION_REPOSITORY = 4;
	int CONFIGURATION_PROVIDER_TYPE__REPOSITORIES = 5;
	int CONFIGURATION_PROVIDER_TYPE__REALM_CONFIGURATION = 6;
	int CONFIGURATION_PROVIDER_TYPE__PLUGIN_MANAGER_CONFIGURATION = 7;
	int CONFIGURATION_PROVIDER_TYPE__AUTHORIZATION = 8;
	int CONFIGURATION_PROVIDER_TYPE__MAX_PAGING_RESULTS = 9;
	int CONFIGURATION_PROVIDER_TYPE__MAX_SEARCH_RESULTS = 10;
	int CONFIGURATION_PROVIDER_TYPE__MAX_TOTAL_PAGING_RESULTS = 11;
	int CONFIGURATION_PROVIDER_TYPE__PAGED_CACHE_TIME_OUT = 12;
	int CONFIGURATION_PROVIDER_TYPE__PAGING_CACHES_DISK_OFF_LOAD = 13;
	int CONFIGURATION_PROVIDER_TYPE__PAGING_ENTITY_OBJECT = 14;
	int CONFIGURATION_PROVIDER_TYPE__SEARCH_TIME_OUT = 15;
	int CONFIGURATION_PROVIDER_TYPE_FEATURE_COUNT = 16;
	int CONNECTIONS_TYPE = 8;
	int CONNECTIONS_TYPE__HOST = 0;
	int CONNECTIONS_TYPE__PORT = 1;
	int CONNECTIONS_TYPE_FEATURE_COUNT = 2;
	int CONTEXT_POOL_TYPE = 9;
	int CONTEXT_POOL_TYPE__ENABLED = 0;
	int CONTEXT_POOL_TYPE__INIT_POOL_SIZE = 1;
	int CONTEXT_POOL_TYPE__MAX_POOL_SIZE = 2;
	int CONTEXT_POOL_TYPE__POOL_TIME_OUT = 3;
	int CONTEXT_POOL_TYPE__POOL_WAIT_TIME = 4;
	int CONTEXT_POOL_TYPE__PREF_POOL_SIZE = 5;
	int CONTEXT_POOL_TYPE_FEATURE_COUNT = 6;
	int CUSTOM_PROPERTIES_TYPE = 10;
	int CUSTOM_PROPERTIES_TYPE__NAME = 0;
	int CUSTOM_PROPERTIES_TYPE__VALUE = 1;
	int CUSTOM_PROPERTIES_TYPE_FEATURE_COUNT = 2;
	int REPOSITORY_TYPE = 41;
	int REPOSITORY_TYPE__ADAPTER_CLASS_NAME = 0;
	int REPOSITORY_TYPE__ID = 1;
	int REPOSITORY_TYPE_FEATURE_COUNT = 2;
	int PROFILE_REPOSITORY_TYPE = 34;
	int PROFILE_REPOSITORY_TYPE__ADAPTER_CLASS_NAME = 0;
	int PROFILE_REPOSITORY_TYPE__ID = 1;
	int PROFILE_REPOSITORY_TYPE__BASE_ENTRIES = 2;
	int PROFILE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_CREATE = 3;
	int PROFILE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_UPDATE = 4;
	int PROFILE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_READ = 5;
	int PROFILE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_DELETE = 6;
	int PROFILE_REPOSITORY_TYPE__REPOSITORIES_FOR_GROUPS = 7;
	int PROFILE_REPOSITORY_TYPE__LOGIN_PROPERTIES = 8;
	int PROFILE_REPOSITORY_TYPE__CUSTOM_PROPERTIES = 9;
	int PROFILE_REPOSITORY_TYPE__IS_EXT_ID_UNIQUE = 10;
	int PROFILE_REPOSITORY_TYPE__READ_ONLY = 11;
	int PROFILE_REPOSITORY_TYPE__SUPPORT_ASYNC_MODE = 12;
	int PROFILE_REPOSITORY_TYPE__SUPPORT_EXTERNAL_NAME = 13;
	int PROFILE_REPOSITORY_TYPE__SUPPORT_PAGING = 14;
	int PROFILE_REPOSITORY_TYPE__SUPPORT_SORTING = 15;
	int PROFILE_REPOSITORY_TYPE__SUPPORT_TRANSACTIONS = 16;
	int PROFILE_REPOSITORY_TYPE__SUPPORT_CHANGE_LOG = 17;
	int PROFILE_REPOSITORY_TYPE_FEATURE_COUNT = 18;
	int DATABASE_REPOSITORY_TYPE = 11;
	int DATABASE_REPOSITORY_TYPE__ADAPTER_CLASS_NAME = 0;
	int DATABASE_REPOSITORY_TYPE__ID = 1;
	int DATABASE_REPOSITORY_TYPE__BASE_ENTRIES = 2;
	int DATABASE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_CREATE = 3;
	int DATABASE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_UPDATE = 4;
	int DATABASE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_READ = 5;
	int DATABASE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_DELETE = 6;
	int DATABASE_REPOSITORY_TYPE__REPOSITORIES_FOR_GROUPS = 7;
	int DATABASE_REPOSITORY_TYPE__LOGIN_PROPERTIES = 8;
	int DATABASE_REPOSITORY_TYPE__CUSTOM_PROPERTIES = 9;
	int DATABASE_REPOSITORY_TYPE__IS_EXT_ID_UNIQUE = 10;
	int DATABASE_REPOSITORY_TYPE__READ_ONLY = 11;
	int DATABASE_REPOSITORY_TYPE__SUPPORT_ASYNC_MODE = 12;
	int DATABASE_REPOSITORY_TYPE__SUPPORT_EXTERNAL_NAME = 13;
	int DATABASE_REPOSITORY_TYPE__SUPPORT_PAGING = 14;
	int DATABASE_REPOSITORY_TYPE__SUPPORT_SORTING = 15;
	int DATABASE_REPOSITORY_TYPE__SUPPORT_TRANSACTIONS = 16;
	int DATABASE_REPOSITORY_TYPE__SUPPORT_CHANGE_LOG = 17;
	int DATABASE_REPOSITORY_TYPE__DATABASE_TYPE = 18;
	int DATABASE_REPOSITORY_TYPE__DATA_SOURCE_NAME = 19;
	int DATABASE_REPOSITORY_TYPE__DB_ADMIN_ID = 20;
	int DATABASE_REPOSITORY_TYPE__DB_ADMIN_PASSWORD = 21;
	int DATABASE_REPOSITORY_TYPE__DB_URL = 22;
	int DATABASE_REPOSITORY_TYPE__DB_SCHEMA = 23;
	int DATABASE_REPOSITORY_TYPE__ENCRYPTION_KEY = 24;
	int DATABASE_REPOSITORY_TYPE__ENTITY_RETRIEVAL_LIMIT = 25;
	int DATABASE_REPOSITORY_TYPE__JDBC_DRIVER_CLASS = 26;
	int DATABASE_REPOSITORY_TYPE__SALT_LENGTH = 27;
	int DATABASE_REPOSITORY_TYPE__HASH_ALGORITHM = 28;
	int DATABASE_REPOSITORY_TYPE__HASH_ITERATIONS = 29;
	int DATABASE_REPOSITORY_TYPE__HASH_KEY_LENGTH = 30;
	int DATABASE_REPOSITORY_TYPE__HASH_SALT_LENGTH = 31;
	int DATABASE_REPOSITORY_TYPE_FEATURE_COUNT = 32;
	int DOCUMENT_ROOT = 12;
	int DOCUMENT_ROOT__MIXED = 0;
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;
	int DOCUMENT_ROOT__CONFIGURATION_PROVIDER = 3;
	int DOCUMENT_ROOT_FEATURE_COUNT = 4;
	int DYNAMIC_MEMBER_ATTRIBUTES_TYPE = 13;
	int DYNAMIC_MEMBER_ATTRIBUTES_TYPE__NAME = 0;
	int DYNAMIC_MEMBER_ATTRIBUTES_TYPE__OBJECT_CLASS = 1;
	int DYNAMIC_MEMBER_ATTRIBUTES_TYPE_FEATURE_COUNT = 2;
	int DYNAMIC_MODEL_TYPE = 14;
	int DYNAMIC_MODEL_TYPE__XSD_FILE_NAME = 0;
	int DYNAMIC_MODEL_TYPE__USE_GLOBAL_SCHEMA = 1;
	int DYNAMIC_MODEL_TYPE_FEATURE_COUNT = 2;
	int ENTRY_MAPPING_REPOSITORY_TYPE = 15;
	int ENTRY_MAPPING_REPOSITORY_TYPE__ADAPTER_CLASS_NAME = 0;
	int ENTRY_MAPPING_REPOSITORY_TYPE__ID = 1;
	int ENTRY_MAPPING_REPOSITORY_TYPE__DATABASE_TYPE = 2;
	int ENTRY_MAPPING_REPOSITORY_TYPE__DATA_SOURCE_NAME = 3;
	int ENTRY_MAPPING_REPOSITORY_TYPE__DB_ADMIN_ID = 4;
	int ENTRY_MAPPING_REPOSITORY_TYPE__DB_ADMIN_PASSWORD = 5;
	int ENTRY_MAPPING_REPOSITORY_TYPE__DB_URL = 6;
	int ENTRY_MAPPING_REPOSITORY_TYPE__DB_SCHEMA = 7;
	int ENTRY_MAPPING_REPOSITORY_TYPE__JDBC_DRIVER_CLASS = 8;
	int ENTRY_MAPPING_REPOSITORY_TYPE_FEATURE_COUNT = 9;
	int ENVIRONMENT_PROPERTIES_TYPE = 16;
	int ENVIRONMENT_PROPERTIES_TYPE__NAME = 0;
	int ENVIRONMENT_PROPERTIES_TYPE__VALUE = 1;
	int ENVIRONMENT_PROPERTIES_TYPE_FEATURE_COUNT = 2;
	int FILE_REPOSITORY_TYPE = 17;
	int FILE_REPOSITORY_TYPE__ADAPTER_CLASS_NAME = 0;
	int FILE_REPOSITORY_TYPE__ID = 1;
	int FILE_REPOSITORY_TYPE__BASE_ENTRIES = 2;
	int FILE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_CREATE = 3;
	int FILE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_UPDATE = 4;
	int FILE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_READ = 5;
	int FILE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_DELETE = 6;
	int FILE_REPOSITORY_TYPE__REPOSITORIES_FOR_GROUPS = 7;
	int FILE_REPOSITORY_TYPE__LOGIN_PROPERTIES = 8;
	int FILE_REPOSITORY_TYPE__CUSTOM_PROPERTIES = 9;
	int FILE_REPOSITORY_TYPE__IS_EXT_ID_UNIQUE = 10;
	int FILE_REPOSITORY_TYPE__READ_ONLY = 11;
	int FILE_REPOSITORY_TYPE__SUPPORT_ASYNC_MODE = 12;
	int FILE_REPOSITORY_TYPE__SUPPORT_EXTERNAL_NAME = 13;
	int FILE_REPOSITORY_TYPE__SUPPORT_PAGING = 14;
	int FILE_REPOSITORY_TYPE__SUPPORT_SORTING = 15;
	int FILE_REPOSITORY_TYPE__SUPPORT_TRANSACTIONS = 16;
	int FILE_REPOSITORY_TYPE__SUPPORT_CHANGE_LOG = 17;
	int FILE_REPOSITORY_TYPE__BASE_DIRECTORY = 18;
	int FILE_REPOSITORY_TYPE__CASE_SENSITIVE = 19;
	int FILE_REPOSITORY_TYPE__FILE_NAME = 20;
	int FILE_REPOSITORY_TYPE__MESSAGE_DIGEST_ALGORITHM = 21;
	int FILE_REPOSITORY_TYPE__SALT_LENGTH = 22;
	int FILE_REPOSITORY_TYPE__KEY_LENGTH = 23;
	int FILE_REPOSITORY_TYPE__HASH_ITERATIONS = 24;
	int FILE_REPOSITORY_TYPE__ACCOUNT_LOCKOUT_THRESHOLD = 25;
	int FILE_REPOSITORY_TYPE__ACCOUNT_LOCKOUT_DURATION = 26;
	int FILE_REPOSITORY_TYPE__IGNORE_FAILED_LOGIN_AFTER = 27;
	int FILE_REPOSITORY_TYPE_FEATURE_COUNT = 28;
	int GROUP_CONFIGURATION_TYPE = 18;
	int GROUP_CONFIGURATION_TYPE__MEMBER_ATTRIBUTES = 0;
	int GROUP_CONFIGURATION_TYPE__DYNAMIC_MEMBER_ATTRIBUTES = 1;
	int GROUP_CONFIGURATION_TYPE__MEMBERSHIP_ATTRIBUTE = 2;
	int GROUP_CONFIGURATION_TYPE__UPDATE_GROUP_MEMBERSHIP = 3;
	int GROUP_CONFIGURATION_TYPE_FEATURE_COUNT = 4;
	int INLINE_EXIT = 19;
	int INLINE_EXIT__MODIFICATION_SUBSCRIBER_LIST = 0;
	int INLINE_EXIT__INLINE_EXIT_NAME = 1;
	int INLINE_EXIT_FEATURE_COUNT = 2;
	int LDAP_ENTITY_TYPES_TYPE = 20;
	int LDAP_ENTITY_TYPES_TYPE__RDN_ATTRIBUTES = 0;
	int LDAP_ENTITY_TYPES_TYPE__OBJECT_CLASSES = 1;
	int LDAP_ENTITY_TYPES_TYPE__OBJECT_CLASSES_FOR_CREATE = 2;
	int LDAP_ENTITY_TYPES_TYPE__SEARCH_BASES = 3;
	int LDAP_ENTITY_TYPES_TYPE__NAME = 4;
	int LDAP_ENTITY_TYPES_TYPE__SEARCH_FILTER = 5;
	int LDAP_ENTITY_TYPES_TYPE_FEATURE_COUNT = 6;
	int LDAP_REPOSITORY_TYPE = 21;
	int LDAP_REPOSITORY_TYPE__ADAPTER_CLASS_NAME = 0;
	int LDAP_REPOSITORY_TYPE__ID = 1;
	int LDAP_REPOSITORY_TYPE__BASE_ENTRIES = 2;
	int LDAP_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_CREATE = 3;
	int LDAP_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_UPDATE = 4;
	int LDAP_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_READ = 5;
	int LDAP_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_DELETE = 6;
	int LDAP_REPOSITORY_TYPE__REPOSITORIES_FOR_GROUPS = 7;
	int LDAP_REPOSITORY_TYPE__LOGIN_PROPERTIES = 8;
	int LDAP_REPOSITORY_TYPE__CUSTOM_PROPERTIES = 9;
	int LDAP_REPOSITORY_TYPE__IS_EXT_ID_UNIQUE = 10;
	int LDAP_REPOSITORY_TYPE__READ_ONLY = 11;
	int LDAP_REPOSITORY_TYPE__SUPPORT_ASYNC_MODE = 12;
	int LDAP_REPOSITORY_TYPE__SUPPORT_EXTERNAL_NAME = 13;
	int LDAP_REPOSITORY_TYPE__SUPPORT_PAGING = 14;
	int LDAP_REPOSITORY_TYPE__SUPPORT_SORTING = 15;
	int LDAP_REPOSITORY_TYPE__SUPPORT_TRANSACTIONS = 16;
	int LDAP_REPOSITORY_TYPE__SUPPORT_CHANGE_LOG = 17;
	int LDAP_REPOSITORY_TYPE__LDAP_SERVER_CONFIGURATION = 18;
	int LDAP_REPOSITORY_TYPE__LDAP_ENTITY_TYPES = 19;
	int LDAP_REPOSITORY_TYPE__GROUP_CONFIGURATION = 20;
	int LDAP_REPOSITORY_TYPE__ATTRIBUTE_CONFIGURATION = 21;
	int LDAP_REPOSITORY_TYPE__CONTEXT_POOL = 22;
	int LDAP_REPOSITORY_TYPE__CACHE_CONFIGURATION = 23;
	int LDAP_REPOSITORY_TYPE__CERTIFICATE_FILTER = 24;
	int LDAP_REPOSITORY_TYPE__CERTIFICATE_MAP_MODE = 25;
	int LDAP_REPOSITORY_TYPE__LDAP_SERVER_TYPE = 26;
	int LDAP_REPOSITORY_TYPE__TRANSLATE_RDN = 27;
	int LDAP_REPOSITORY_TYPE_FEATURE_COUNT = 28;
	int LDAP_SERVER_CONFIGURATION_TYPE = 22;
	int LDAP_SERVER_CONFIGURATION_TYPE__LDAP_SERVERS = 0;
	int LDAP_SERVER_CONFIGURATION_TYPE__ALLOW_WRITE_TO_SECONDARY_SERVERS = 1;
	int LDAP_SERVER_CONFIGURATION_TYPE__ATTRIBUTE_RANGE_STEP = 2;
	int LDAP_SERVER_CONFIGURATION_TYPE__PRIMARY_SERVER_QUERY_TIME_INTERVAL = 3;
	int LDAP_SERVER_CONFIGURATION_TYPE__RETURN_TO_PRIMARY_SERVER = 4;
	int LDAP_SERVER_CONFIGURATION_TYPE__SEARCH_COUNT_LIMIT = 5;
	int LDAP_SERVER_CONFIGURATION_TYPE__SEARCH_PAGE_SIZE = 6;
	int LDAP_SERVER_CONFIGURATION_TYPE__SEARCH_TIME_LIMIT = 7;
	int LDAP_SERVER_CONFIGURATION_TYPE__SSL_CONFIGURATION = 8;
	int LDAP_SERVER_CONFIGURATION_TYPE__SSL_KEY_STORE = 9;
	int LDAP_SERVER_CONFIGURATION_TYPE__SSL_KEY_STORE_PASSWORD = 10;
	int LDAP_SERVER_CONFIGURATION_TYPE__SSL_KEY_STORE_TYPE = 11;
	int LDAP_SERVER_CONFIGURATION_TYPE__SSL_TRUST_STORE = 12;
	int LDAP_SERVER_CONFIGURATION_TYPE__SSL_TRUST_STORE_PASSWORD = 13;
	int LDAP_SERVER_CONFIGURATION_TYPE__SSL_TRUST_STORE_TYPE = 14;
	int LDAP_SERVER_CONFIGURATION_TYPE_FEATURE_COUNT = 15;
	int LDAP_SERVERS_TYPE = 23;
	int LDAP_SERVERS_TYPE__CONNECTIONS = 0;
	int LDAP_SERVERS_TYPE__ENVIRONMENT_PROPERTIES = 1;
	int LDAP_SERVERS_TYPE__AUTHENTICATION = 2;
	int LDAP_SERVERS_TYPE__BIND_DN = 3;
	int LDAP_SERVERS_TYPE__BIND_PASSWORD = 4;
	int LDAP_SERVERS_TYPE__CONNECTION_POOL = 5;
	int LDAP_SERVERS_TYPE__CONNECT_TIMEOUT = 6;
	int LDAP_SERVERS_TYPE__DEREF_ALIASES = 7;
	int LDAP_SERVERS_TYPE__REFERAL = 8;
	int LDAP_SERVERS_TYPE__SSL_ENABLED = 9;
	int LDAP_SERVERS_TYPE__BINDAUTHMECHANISM = 10;
	int LDAP_SERVERS_TYPE__KRB5AUTHENTICATION = 11;
	int LDAP_SERVERS_TYPE_FEATURE_COUNT = 12;
	int MEMBER_ATTRIBUTES_TYPE = 24;
	int MEMBER_ATTRIBUTES_TYPE__DUMMY_MEMBER = 0;
	int MEMBER_ATTRIBUTES_TYPE__NAME = 1;
	int MEMBER_ATTRIBUTES_TYPE__OBJECT_CLASS = 2;
	int MEMBER_ATTRIBUTES_TYPE__SCOPE = 3;
	int MEMBER_ATTRIBUTES_TYPE_FEATURE_COUNT = 4;
	int MEMBERSHIP_ATTRIBUTE_TYPE = 25;
	int MEMBERSHIP_ATTRIBUTE_TYPE__NAME = 0;
	int MEMBERSHIP_ATTRIBUTE_TYPE__SCOPE = 1;
	int MEMBERSHIP_ATTRIBUTE_TYPE_FEATURE_COUNT = 2;
	int MODIFICATION_SUBSCRIBER = 26;
	int MODIFICATION_SUBSCRIBER__MODIFICATION_SUBSCRIBER_REFERENCE = 0;
	int MODIFICATION_SUBSCRIBER__REALM_LIST = 1;
	int MODIFICATION_SUBSCRIBER_FEATURE_COUNT = 2;
	int MODIFICATION_SUBSCRIBER_LIST = 27;
	int MODIFICATION_SUBSCRIBER_LIST__MODIFICATION_SUBSCRIBER = 0;
	int MODIFICATION_SUBSCRIBER_LIST_FEATURE_COUNT = 1;
	int NOTIFICATION_SUBSCRIBER = 28;
	int NOTIFICATION_SUBSCRIBER__NOTIFICATION_SUBSCRIBER_REFERENCE = 0;
	int NOTIFICATION_SUBSCRIBER__REALM_LIST = 1;
	int NOTIFICATION_SUBSCRIBER_FEATURE_COUNT = 2;
	int NOTIFICATION_SUBSCRIBER_LIST = 29;
	int NOTIFICATION_SUBSCRIBER_LIST__NOTIFICATION_SUBSCRIBER = 0;
	int NOTIFICATION_SUBSCRIBER_LIST_FEATURE_COUNT = 1;
	int PARTICIPATING_BASE_ENTRIES_TYPE = 30;
	int PARTICIPATING_BASE_ENTRIES_TYPE__NAME = 0;
	int PARTICIPATING_BASE_ENTRIES_TYPE_FEATURE_COUNT = 1;
	int PLUGIN_MANAGER_CONFIGURATION_TYPE = 31;
	int PLUGIN_MANAGER_CONFIGURATION_TYPE__TOPIC_SUBSCRIBER_LIST = 0;
	int PLUGIN_MANAGER_CONFIGURATION_TYPE__TOPIC_REGISTRATION_LIST = 1;
	int PLUGIN_MANAGER_CONFIGURATION_TYPE_FEATURE_COUNT = 2;
	int POST_EXIT = 32;
	int POST_EXIT__MODIFICATION_SUBSCRIBER_LIST = 0;
	int POST_EXIT__NOTIFICATION_SUBSCRIBER_LIST = 1;
	int POST_EXIT_FEATURE_COUNT = 2;
	int PRE_EXIT = 33;
	int PRE_EXIT__NOTIFICATION_SUBSCRIBER_LIST = 0;
	int PRE_EXIT__MODIFICATION_SUBSCRIBER_LIST = 1;
	int PRE_EXIT_FEATURE_COUNT = 2;
	int PROPERTIES_NOT_SUPPORTED_TYPE = 35;
	int PROPERTIES_NOT_SUPPORTED_TYPE__ENTITY_TYPES = 0;
	int PROPERTIES_NOT_SUPPORTED_TYPE__NAME = 1;
	int PROPERTIES_NOT_SUPPORTED_TYPE_FEATURE_COUNT = 2;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE = 36;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__ADAPTER_CLASS_NAME = 0;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__ID = 1;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__DATABASE_TYPE = 2;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__DATA_SOURCE_NAME = 3;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__DB_ADMIN_ID = 4;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__DB_ADMIN_PASSWORD = 5;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__DB_URL = 6;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__DB_SCHEMA = 7;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__ENTITY_RETRIEVAL_LIMIT = 8;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE__JDBC_DRIVER_CLASS = 9;
	int PROPERTY_EXTENSION_REPOSITORY_TYPE_FEATURE_COUNT = 10;
	int RDN_ATTRIBUTES_TYPE = 37;
	int RDN_ATTRIBUTES_TYPE__NAME = 0;
	int RDN_ATTRIBUTES_TYPE__OBJECT_CLASS = 1;
	int RDN_ATTRIBUTES_TYPE_FEATURE_COUNT = 2;
	int REALM_CONFIGURATION_TYPE = 38;
	int REALM_CONFIGURATION_TYPE__REALMS = 0;
	int REALM_CONFIGURATION_TYPE__DEFAULT_REALM = 1;
	int REALM_CONFIGURATION_TYPE_FEATURE_COUNT = 2;
	int REALM_DEFAULT_PARENT_TYPE = 39;
	int REALM_DEFAULT_PARENT_TYPE__ENTITY_TYPE_NAME = 0;
	int REALM_DEFAULT_PARENT_TYPE__PARENT_UNIQUE_NAME = 1;
	int REALM_DEFAULT_PARENT_TYPE_FEATURE_COUNT = 2;
	int REALM_TYPE = 40;
	int REALM_TYPE__PARTICIPATING_BASE_ENTRIES = 0;
	int REALM_TYPE__DEFAULT_PARENTS = 1;
	int REALM_TYPE__UNIQUE_USER_ID_MAPPING = 2;
	int REALM_TYPE__USER_SECURITY_NAME_MAPPING = 3;
	int REALM_TYPE__USER_DISPLAY_NAME_MAPPING = 4;
	int REALM_TYPE__UNIQUE_GROUP_ID_MAPPING = 5;
	int REALM_TYPE__GROUP_SECURITY_NAME_MAPPING = 6;
	int REALM_TYPE__GROUP_DISPLAY_NAME_MAPPING = 7;
	int REALM_TYPE__DELIMITER = 8;
	int REALM_TYPE__NAME = 9;
	int REALM_TYPE__SECURITY_USE = 10;
	int REALM_TYPE__ALLOW_OPERATION_IF_REPOS_DOWN = 11;
	int REALM_TYPE_FEATURE_COUNT = 12;
	int SEARCH_RESULTS_CACHE_TYPE = 42;
	int SEARCH_RESULTS_CACHE_TYPE__CACHE_SIZE = 0;
	int SEARCH_RESULTS_CACHE_TYPE__CACHE_TIME_OUT = 1;
	int SEARCH_RESULTS_CACHE_TYPE__ENABLED = 2;
	int SEARCH_RESULTS_CACHE_TYPE__SEARCH_RESULT_SIZE_LIMIT = 3;
	int SEARCH_RESULTS_CACHE_TYPE__CACHE_DIST_POLICY = 4;
	int SEARCH_RESULTS_CACHE_TYPE_FEATURE_COUNT = 5;
	int SPI_BRIDGE_REPOSITORY_TYPE = 43;
	int SPI_BRIDGE_REPOSITORY_TYPE__ADAPTER_CLASS_NAME = 0;
	int SPI_BRIDGE_REPOSITORY_TYPE__ID = 1;
	int SPI_BRIDGE_REPOSITORY_TYPE__BASE_ENTRIES = 2;
	int SPI_BRIDGE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_CREATE = 3;
	int SPI_BRIDGE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_UPDATE = 4;
	int SPI_BRIDGE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_READ = 5;
	int SPI_BRIDGE_REPOSITORY_TYPE__ENTITY_TYPES_NOT_ALLOW_DELETE = 6;
	int SPI_BRIDGE_REPOSITORY_TYPE__REPOSITORIES_FOR_GROUPS = 7;
	int SPI_BRIDGE_REPOSITORY_TYPE__LOGIN_PROPERTIES = 8;
	int SPI_BRIDGE_REPOSITORY_TYPE__CUSTOM_PROPERTIES = 9;
	int SPI_BRIDGE_REPOSITORY_TYPE__IS_EXT_ID_UNIQUE = 10;
	int SPI_BRIDGE_REPOSITORY_TYPE__READ_ONLY = 11;
	int SPI_BRIDGE_REPOSITORY_TYPE__SUPPORT_ASYNC_MODE = 12;
	int SPI_BRIDGE_REPOSITORY_TYPE__SUPPORT_EXTERNAL_NAME = 13;
	int SPI_BRIDGE_REPOSITORY_TYPE__SUPPORT_PAGING = 14;
	int SPI_BRIDGE_REPOSITORY_TYPE__SUPPORT_SORTING = 15;
	int SPI_BRIDGE_REPOSITORY_TYPE__SUPPORT_TRANSACTIONS = 16;
	int SPI_BRIDGE_REPOSITORY_TYPE__SUPPORT_CHANGE_LOG = 17;
	int SPI_BRIDGE_REPOSITORY_TYPE__WMM_ADAPTER_CLASS_NAME = 18;
	int SPI_BRIDGE_REPOSITORY_TYPE_FEATURE_COUNT = 19;
	int STATIC_MODEL_TYPE = 44;
	int STATIC_MODEL_TYPE__PACKAGE_NAME = 0;
	int STATIC_MODEL_TYPE__USE_GLOBAL_SCHEMA = 1;
	int STATIC_MODEL_TYPE_FEATURE_COUNT = 2;
	int SUPPORTED_ENTITY_TYPES_TYPE = 45;
	int SUPPORTED_ENTITY_TYPES_TYPE__RDN_PROPERTIES = 0;
	int SUPPORTED_ENTITY_TYPES_TYPE__DEFAULT_PARENT = 1;
	int SUPPORTED_ENTITY_TYPES_TYPE__NAME = 2;
	int SUPPORTED_ENTITY_TYPES_TYPE_FEATURE_COUNT = 3;
	int TOPIC_EMITTER = 46;
	int TOPIC_EMITTER__PRE_EXIT = 0;
	int TOPIC_EMITTER__INLINE_EXIT = 1;
	int TOPIC_EMITTER__POST_EXIT = 2;
	int TOPIC_EMITTER__TOPIC_EMITTER_NAME = 3;
	int TOPIC_EMITTER_FEATURE_COUNT = 4;
	int TOPIC_REGISTRATION_LIST = 47;
	int TOPIC_REGISTRATION_LIST__TOPIC_EMITTER = 0;
	int TOPIC_REGISTRATION_LIST_FEATURE_COUNT = 1;
	int TOPIC_SUBSCRIBER = 48;
	int TOPIC_SUBSCRIBER__CLASS_NAME = 0;
	int TOPIC_SUBSCRIBER__TOPIC_SUBSCRIBER_NAME = 1;
	int TOPIC_SUBSCRIBER__TOPIC_SUBSCRIBER_TYPE = 2;
	int TOPIC_SUBSCRIBER_FEATURE_COUNT = 3;
	int TOPIC_SUBSCRIBER_LIST = 49;
	int TOPIC_SUBSCRIBER_LIST__TOPIC_SUBSCRIBER = 0;
	int TOPIC_SUBSCRIBER_LIST_FEATURE_COUNT = 1;
	int USER_REGISTRY_INFO_MAPPING_TYPE = 50;
	int USER_REGISTRY_INFO_MAPPING_TYPE__PROPERTY_FOR_INPUT = 0;
	int USER_REGISTRY_INFO_MAPPING_TYPE__PROPERTY_FOR_OUTPUT = 1;
	int USER_REGISTRY_INFO_MAPPING_TYPE_FEATURE_COUNT = 2;
	int SUBSCRIBER_TYPE = 51;
	int CACHE_SIZE_LIMIT_TYPE = 52;
	int CACHE_SIZE_LIMIT_TYPE_OBJECT = 53;
	int CACHE_SIZE_TYPE = 54;
	int CACHE_SIZE_TYPE_OBJECT = 55;
	int CACHE_TIME_OUT_TYPE = 56;
	int CACHE_TIME_OUT_TYPE_OBJECT = 57;
	int DN_TYPE = 58;
	int INIT_POOL_SIZE_TYPE = 59;
	int INIT_POOL_SIZE_TYPE_OBJECT = 60;
	int MAX_POOL_SIZE_TYPE = 61;
	int MAX_POOL_SIZE_TYPE_OBJECT = 62;
	int POOL_TIME_OUT_TYPE = 63;
	int POOL_TIME_OUT_TYPE_OBJECT = 64;
	int POOL_WAIT_TIME_TYPE = 65;
	int POOL_WAIT_TIME_TYPE_OBJECT = 66;
	int PREF_POOL_SIZE_TYPE = 67;
	int PREF_POOL_SIZE_TYPE_OBJECT = 68;
	int REALM_LIST_TYPE = 69;
	int REALM_LIST_TYPE1 = 70;
	int SUBSCRIBER_TYPE_OBJECT = 71;
	int KRB5_AUTHENTICATION_TYPE = 72;
	int KRB5_AUTHENTICATION_TYPE__KRB5PRINCIPAL = 0;
	int KRB5_AUTHENTICATION_TYPE__KRB5TICKETCACHE = 1;
	int KRB5_AUTHENTICATION_TYPE__KRB5CONFIG = 2;

	EClass getAttributeConfigurationType();

	EReference getAttributeConfigurationType_ExternalIdAttributes();

	EReference getAttributeConfigurationType_Attributes();

	EReference getAttributeConfigurationType_PropertiesNotSupported();

	EClass getAttributeGroupType();

	EAttribute getAttributeGroupType_GroupName();

	EAttribute getAttributeGroupType_AttributeNames();

	EClass getAttributesCacheType();

	EAttribute getAttributesCacheType_AttributeSizeLimit();

	EAttribute getAttributesCacheType_CacheSize();

	EAttribute getAttributesCacheType_CacheTimeOut();

	EAttribute getAttributesCacheType_Enabled();

	EAttribute getAttributesCacheType_ServerTTLAttribute();

	EAttribute getAttributesCacheType_CacheDistPolicy();

	EClass getAttributeType();

	EAttribute getAttributeType_EntityTypes();

	EAttribute getAttributeType_DefaultAttribute();

	EAttribute getAttributeType_DefaultValue();

	EAttribute getAttributeType_Name();

	EAttribute getAttributeType_PropertyName();

	EAttribute getAttributeType_Syntax();

	EAttribute getAttributeType_WimGenerate();

	EClass getAuthorizationType();

	EReference getAuthorizationType_AttributeGroups();

	EAttribute getAuthorizationType_DefaultAttributeGroup();

	EAttribute getAuthorizationType_ImportPolicyFromFile();

	EAttribute getAuthorizationType_IsAttributeGroupingEnabled();

	EAttribute getAuthorizationType_IsSecurityEnabled();

	EAttribute getAuthorizationType_JaccPolicyClass();

	EAttribute getAuthorizationType_JaccPolicyConfigFactoryClass();

	EAttribute getAuthorizationType_JaccPrincipalToRolePolicyFileName();

	EAttribute getAuthorizationType_JaccPrincipalToRolePolicyId();

	EAttribute getAuthorizationType_JaccRoleMappingClass();

	EAttribute getAuthorizationType_JaccRoleMappingConfigFactoryClass();

	EAttribute getAuthorizationType_JaccRoleToPermissionPolicyFileName();

	EAttribute getAuthorizationType_JaccRoleToPermissionPolicyId();

	EAttribute getAuthorizationType_UseSystemJACCProvider();

	EClass getBaseEntriesType();

	EAttribute getBaseEntriesType_Name();

	EAttribute getBaseEntriesType_NameInRepository();

	EClass getCacheConfigurationType();

	EReference getCacheConfigurationType_AttributesCache();

	EReference getCacheConfigurationType_SearchResultsCache();

	EAttribute getCacheConfigurationType_CachesDiskOffLoad();

	EClass getConfigurationProviderType();

	EReference getConfigurationProviderType_DynamicModel();

	EReference getConfigurationProviderType_StaticModel();

	EReference getConfigurationProviderType_SupportedEntityTypes();

	EReference getConfigurationProviderType_EntryMappingRepository();

	EReference getConfigurationProviderType_PropertyExtensionRepository();

	EReference getConfigurationProviderType_Repositories();

	EReference getConfigurationProviderType_RealmConfiguration();

	EReference getConfigurationProviderType_PluginManagerConfiguration();

	EReference getConfigurationProviderType_Authorization();

	EAttribute getConfigurationProviderType_MaxPagingResults();

	EAttribute getConfigurationProviderType_MaxSearchResults();

	EAttribute getConfigurationProviderType_MaxTotalPagingResults();

	EAttribute getConfigurationProviderType_PagedCacheTimeOut();

	EAttribute getConfigurationProviderType_PagingCachesDiskOffLoad();

	EAttribute getConfigurationProviderType_PagingEntityObject();

	EAttribute getConfigurationProviderType_SearchTimeOut();

	EClass getConnectionsType();

	EAttribute getConnectionsType_Host();

	EAttribute getConnectionsType_Port();

	EClass getContextPoolType();

	EAttribute getContextPoolType_Enabled();

	EAttribute getContextPoolType_InitPoolSize();

	EAttribute getContextPoolType_MaxPoolSize();

	EAttribute getContextPoolType_PoolTimeOut();

	EAttribute getContextPoolType_PoolWaitTime();

	EAttribute getContextPoolType_PrefPoolSize();

	EClass getCustomPropertiesType();

	EAttribute getCustomPropertiesType_Name();

	EAttribute getCustomPropertiesType_Value();

	EClass getDatabaseRepositoryType();

	EAttribute getDatabaseRepositoryType_DatabaseType();

	EAttribute getDatabaseRepositoryType_DataSourceName();

	EAttribute getDatabaseRepositoryType_DbAdminId();

	EAttribute getDatabaseRepositoryType_DbAdminPassword();

	EAttribute getDatabaseRepositoryType_DbURL();

	EAttribute getDatabaseRepositoryType_DbSchema();

	EAttribute getDatabaseRepositoryType_EncryptionKey();

	EAttribute getDatabaseRepositoryType_EntityRetrievalLimit();

	EAttribute getDatabaseRepositoryType_JDBCDriverClass();

	EAttribute getDatabaseRepositoryType_SaltLength();

	EAttribute getDatabaseRepositoryType_HashAlgorithm();

	EAttribute getDatabaseRepositoryType_HashIterations();

	EAttribute getDatabaseRepositoryType_HashKeyLength();

	EAttribute getDatabaseRepositoryType_HashSaltLength();

	EClass getDocumentRoot();

	EAttribute getDocumentRoot_Mixed();

	EReference getDocumentRoot_XMLNSPrefixMap();

	EReference getDocumentRoot_XSISchemaLocation();

	EReference getDocumentRoot_ConfigurationProvider();

	EClass getDynamicMemberAttributesType();

	EAttribute getDynamicMemberAttributesType_Name();

	EAttribute getDynamicMemberAttributesType_ObjectClass();

	EClass getDynamicModelType();

	EAttribute getDynamicModelType_XsdFileName();

	EAttribute getDynamicModelType_UseGlobalSchema();

	EClass getEntryMappingRepositoryType();

	EAttribute getEntryMappingRepositoryType_DatabaseType();

	EAttribute getEntryMappingRepositoryType_DataSourceName();

	EAttribute getEntryMappingRepositoryType_DbAdminId();

	EAttribute getEntryMappingRepositoryType_DbAdminPassword();

	EAttribute getEntryMappingRepositoryType_DbURL();

	EAttribute getEntryMappingRepositoryType_DbSchema();

	EAttribute getEntryMappingRepositoryType_JDBCDriverClass();

	EClass getEnvironmentPropertiesType();

	EAttribute getEnvironmentPropertiesType_Name();

	EAttribute getEnvironmentPropertiesType_Value();

	EClass getFileRepositoryType();

	EAttribute getFileRepositoryType_BaseDirectory();

	EAttribute getFileRepositoryType_CaseSensitive();

	EAttribute getFileRepositoryType_FileName();

	EAttribute getFileRepositoryType_MessageDigestAlgorithm();

	EAttribute getFileRepositoryType_SaltLength();

	EAttribute getFileRepositoryType_KeyLength();

	EAttribute getFileRepositoryType_HashIterations();

	EAttribute getFileRepositoryType_AccountLockoutThreshold();

	EAttribute getFileRepositoryType_AccountLockoutDuration();

	EAttribute getFileRepositoryType_IgnoreFailedLoginAfter();

	EClass getGroupConfigurationType();

	EReference getGroupConfigurationType_MemberAttributes();

	EReference getGroupConfigurationType_DynamicMemberAttributes();

	EReference getGroupConfigurationType_MembershipAttribute();

	EAttribute getGroupConfigurationType_UpdateGroupMembership();

	EClass getInlineExit();

	EReference getInlineExit_ModificationSubscriberList();

	EAttribute getInlineExit_InlineExitName();

	EClass getLdapEntityTypesType();

	EReference getLdapEntityTypesType_RdnAttributes();

	EAttribute getLdapEntityTypesType_ObjectClasses();

	EAttribute getLdapEntityTypesType_ObjectClassesForCreate();

	EAttribute getLdapEntityTypesType_SearchBases();

	EAttribute getLdapEntityTypesType_Name();

	EAttribute getLdapEntityTypesType_SearchFilter();

	EClass getLdapRepositoryType();

	EReference getLdapRepositoryType_LdapServerConfiguration();

	EReference getLdapRepositoryType_LdapEntityTypes();

	EReference getLdapRepositoryType_GroupConfiguration();

	EReference getLdapRepositoryType_AttributeConfiguration();

	EReference getLdapRepositoryType_ContextPool();

	EReference getLdapRepositoryType_CacheConfiguration();

	EAttribute getLdapRepositoryType_CertificateFilter();

	EAttribute getLdapRepositoryType_CertificateMapMode();

	EAttribute getLdapRepositoryType_LdapServerType();

	EAttribute getLdapRepositoryType_TranslateRDN();

	EClass getLdapServerConfigurationType();

	EReference getLdapServerConfigurationType_LdapServers();

	EAttribute getLdapServerConfigurationType_AllowWriteToSecondaryServers();

	EAttribute getLdapServerConfigurationType_AttributeRangeStep();

	EAttribute getLdapServerConfigurationType_PrimaryServerQueryTimeInterval();

	EAttribute getLdapServerConfigurationType_ReturnToPrimaryServer();

	EAttribute getLdapServerConfigurationType_SearchCountLimit();

	EAttribute getLdapServerConfigurationType_SearchPageSize();

	EAttribute getLdapServerConfigurationType_SearchTimeLimit();

	EAttribute getLdapServerConfigurationType_SslConfiguration();

	EAttribute getLdapServerConfigurationType_SslKeyStore();

	EAttribute getLdapServerConfigurationType_SslKeyStorePassword();

	EAttribute getLdapServerConfigurationType_SslKeyStoreType();

	EAttribute getLdapServerConfigurationType_SslTrustStore();

	EAttribute getLdapServerConfigurationType_SslTrustStorePassword();

	EAttribute getLdapServerConfigurationType_SslTrustStoreType();

	EClass getLdapServersType();

	EReference getLdapServersType_Connections();

	EReference getLdapServersType_EnvironmentProperties();

	EReference getLdapServersType_Krb5Authentication();

	EAttribute getLdapServersType_Authentication();

	EAttribute getLdapServersType_BindDN();

	EAttribute getLdapServersType_BindPassword();

	EAttribute getLdapServersType_ConnectionPool();

	EAttribute getLdapServersType_ConnectTimeout();

	EAttribute getLdapServersType_DerefAliases();

	EAttribute getLdapServersType_Referal();

	EAttribute getLdapServersType_SslEnabled();

	EAttribute getLdapServersType_BindAuthMechanism();

	EClass getMemberAttributesType();

	EAttribute getMemberAttributesType_DummyMember();

	EAttribute getMemberAttributesType_Name();

	EAttribute getMemberAttributesType_ObjectClass();

	EAttribute getMemberAttributesType_Scope();

	EClass getMembershipAttributeType();

	EAttribute getMembershipAttributeType_Name();

	EAttribute getMembershipAttributeType_Scope();

	EClass getKrb5AuthenticationType();

	EAttribute getKrb5AuthenticationType_Krb5Principal();

	EAttribute getKrb5AuthenticationType_Krb5TicketCache();

	EClass getModificationSubscriber();

	EAttribute getModificationSubscriber_ModificationSubscriberReference();

	EAttribute getModificationSubscriber_RealmList();

	EClass getModificationSubscriberList();

	EReference getModificationSubscriberList_ModificationSubscriber();

	EClass getNotificationSubscriber();

	EAttribute getNotificationSubscriber_NotificationSubscriberReference();

	EAttribute getNotificationSubscriber_RealmList();

	EClass getNotificationSubscriberList();

	EReference getNotificationSubscriberList_NotificationSubscriber();

	EClass getParticipatingBaseEntriesType();

	EAttribute getParticipatingBaseEntriesType_Name();

	EClass getPluginManagerConfigurationType();

	EReference getPluginManagerConfigurationType_TopicSubscriberList();

	EReference getPluginManagerConfigurationType_TopicRegistrationList();

	EClass getPostExit();

	EReference getPostExit_ModificationSubscriberList();

	EReference getPostExit_NotificationSubscriberList();

	EClass getPreExit();

	EReference getPreExit_NotificationSubscriberList();

	EReference getPreExit_ModificationSubscriberList();

	EClass getProfileRepositoryType();

	EReference getProfileRepositoryType_BaseEntries();

	EAttribute getProfileRepositoryType_EntityTypesNotAllowCreate();

	EAttribute getProfileRepositoryType_EntityTypesNotAllowUpdate();

	EAttribute getProfileRepositoryType_EntityTypesNotAllowRead();

	EAttribute getProfileRepositoryType_EntityTypesNotAllowDelete();

	EAttribute getProfileRepositoryType_RepositoriesForGroups();

	EAttribute getProfileRepositoryType_LoginProperties();

	EReference getProfileRepositoryType_CustomProperties();

	EAttribute getProfileRepositoryType_IsExtIdUnique();

	EAttribute getProfileRepositoryType_ReadOnly();

	EAttribute getProfileRepositoryType_SupportAsyncMode();

	EAttribute getProfileRepositoryType_SupportExternalName();

	EAttribute getProfileRepositoryType_SupportPaging();

	EAttribute getProfileRepositoryType_SupportSorting();

	EAttribute getProfileRepositoryType_SupportTransactions();

	EAttribute getProfileRepositoryType_SupportChangeLog();

	EClass getPropertiesNotSupportedType();

	EAttribute getPropertiesNotSupportedType_EntityTypes();

	EAttribute getPropertiesNotSupportedType_Name();

	EClass getPropertyExtensionRepositoryType();

	EAttribute getPropertyExtensionRepositoryType_DatabaseType();

	EAttribute getPropertyExtensionRepositoryType_DataSourceName();

	EAttribute getPropertyExtensionRepositoryType_DbAdminId();

	EAttribute getPropertyExtensionRepositoryType_DbAdminPassword();

	EAttribute getPropertyExtensionRepositoryType_DbURL();

	EAttribute getPropertyExtensionRepositoryType_DbSchema();

	EAttribute getPropertyExtensionRepositoryType_EntityRetrievalLimit();

	EAttribute getPropertyExtensionRepositoryType_JDBCDriverClass();

	EClass getRdnAttributesType();

	EAttribute getRdnAttributesType_Name();

	EAttribute getRdnAttributesType_ObjectClass();

	EClass getRealmConfigurationType();

	EReference getRealmConfigurationType_Realms();

	EAttribute getRealmConfigurationType_DefaultRealm();

	EClass getRealmDefaultParentType();

	EAttribute getRealmDefaultParentType_EntityTypeName();

	EAttribute getRealmDefaultParentType_ParentUniqueName();

	EClass getRealmType();

	EReference getRealmType_ParticipatingBaseEntries();

	EReference getRealmType_DefaultParents();

	EReference getRealmType_UniqueUserIdMapping();

	EReference getRealmType_UserSecurityNameMapping();

	EReference getRealmType_UserDisplayNameMapping();

	EReference getRealmType_UniqueGroupIdMapping();

	EReference getRealmType_GroupSecurityNameMapping();

	EReference getRealmType_GroupDisplayNameMapping();

	EAttribute getRealmType_AllowOperationIfReposDown();

	EAttribute getRealmType_Delimiter();

	EAttribute getRealmType_Name();

	EAttribute getRealmType_SecurityUse();

	EClass getRepositoryType();

	EAttribute getRepositoryType_AdapterClassName();

	EAttribute getRepositoryType_Id();

	EClass getSearchResultsCacheType();

	EAttribute getSearchResultsCacheType_CacheSize();

	EAttribute getSearchResultsCacheType_CacheTimeOut();

	EAttribute getSearchResultsCacheType_Enabled();

	EAttribute getSearchResultsCacheType_SearchResultSizeLimit();

	EAttribute getSearchResultsCacheType_CacheDistPolicy();

	EClass getSPIBridgeRepositoryType();

	EAttribute getSPIBridgeRepositoryType_WMMAdapterClassName();

	EClass getStaticModelType();

	EAttribute getStaticModelType_PackageName();

	EAttribute getStaticModelType_UseGlobalSchema();

	EClass getSupportedEntityTypesType();

	EAttribute getSupportedEntityTypesType_RdnProperties();

	EAttribute getSupportedEntityTypesType_DefaultParent();

	EAttribute getSupportedEntityTypesType_Name();

	EClass getTopicEmitter();

	EReference getTopicEmitter_PreExit();

	EReference getTopicEmitter_InlineExit();

	EReference getTopicEmitter_PostExit();

	EAttribute getTopicEmitter_TopicEmitterName();

	EClass getTopicRegistrationList();

	EReference getTopicRegistrationList_TopicEmitter();

	EClass getTopicSubscriber();

	EAttribute getTopicSubscriber_ClassName();

	EAttribute getTopicSubscriber_TopicSubscriberName();

	EAttribute getTopicSubscriber_TopicSubscriberType();

	EClass getTopicSubscriberList();

	EReference getTopicSubscriberList_TopicSubscriber();

	EClass getUserRegistryInfoMappingType();

	EAttribute getUserRegistryInfoMappingType_PropertyForInput();

	EAttribute getUserRegistryInfoMappingType_PropertyForOutput();

	EEnum getSubscriberType();

	EDataType getCacheSizeLimitType();

	EDataType getCacheSizeLimitTypeObject();

	EDataType getCacheSizeType();

	EDataType getCacheSizeTypeObject();

	EDataType getCacheTimeOutType();

	EDataType getCacheTimeOutTypeObject();

	EDataType getDNType();

	EDataType getInitPoolSizeType();

	EDataType getInitPoolSizeTypeObject();

	EDataType getMaxPoolSizeType();

	EDataType getMaxPoolSizeTypeObject();

	EDataType getPoolTimeOutType();

	EDataType getPoolTimeOutTypeObject();

	EDataType getPoolWaitTimeType();

	EDataType getPoolWaitTimeTypeObject();

	EDataType getPrefPoolSizeType();

	EDataType getPrefPoolSizeTypeObject();

	EDataType getRealmListType();

	EDataType getRealmListType1();

	EDataType getSubscriberTypeObject();

	ConfigmodelFactory getConfigmodelFactory();
}