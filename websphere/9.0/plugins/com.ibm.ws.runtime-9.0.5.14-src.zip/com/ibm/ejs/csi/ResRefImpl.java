package com.ibm.ejs.csi;

import com.ibm.ejs.csi.ResRefImpl.Attribute;
import com.ibm.ejs.csi.ResRefImpl.AuthType;
import com.ibm.ejs.csi.ResRefImpl.BranchCoupling;
import com.ibm.ejs.csi.ResRefImpl.IsolationLevel;
import com.ibm.ejs.csi.ResRefImpl.PropertyImpl;
import com.ibm.ejs.csi.ResRefImpl.SharingScope;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.dopriv.SystemGetPropertyPrivileged;
import com.ibm.websphere.csi.ResRef;
import com.ibm.websphere.csi.ResRef.Property;
import com.ibm.ws.resource.ResourceRefConfig;
import com.ibm.ws.resource.ResourceRefConfig.MergeConflict;
import com.ibm.ws.security.util.AccessController;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EPackage.Registry;

public class ResRefImpl implements ResRef, ResourceRefConfig, Serializable {
	private static final long serialVersionUID = 8057636555519507253L;
	private static final String CLASS_NAME = ResRefImpl.class.getName();
	static final TraceComponent tc;
	private static final String AUTHENTICATION_ALIAS_LOGIN_NAME = "DefaultPrincipalMapping";
	private static final String AUTHENTICATION_ALIAS_PROPERTY = "com.ibm.mapping.authDataAlias";
	private static final AuthType[] AUTH_TYPE_VALUES;
	private static final SharingScope[] SHARING_SCOPE_VALUES;
	private static final IsolationLevel[] ISOLATION_LEVEL_VALUES;
	private static final BranchCoupling[] BRANCH_COUPLING_VALUES;
	private transient String _description;
	private final String _name;
	private String _type;
	private String _jndiName;
	private int _commitPriority;
	private BranchCoupling _branchCoupling;
	private AuthType _resAuth;
	private SharingScope _resSharingScope;
	private IsolationLevel _resIsolationLevel;
	private String _loginConfigurationName;
	private List<Property> _loginProperties;

	ResRefImpl(String name) {
		this._name = name;
	}

	public ResRefImpl(String description, String name, String jndiName, String type, int resAuth, int resSharingScope,
			int resIsolationLevel) {
		this._name = name;
		this.initialize(description, jndiName, type, resAuth, resSharingScope, resIsolationLevel, (String) null,
				(EList) null, (List) null);
	}

	public ResRefImpl(String description, String name, String jndiName, String type, int resAuth, int resSharingScope,
			int resIsolationLevel, String loginConfigurationName, EList loginProperties) {
		this._name = name;
		this.initialize(description, jndiName, type, resAuth, resSharingScope, resIsolationLevel,
				loginConfigurationName, loginProperties, (List) null);
	}

	public ResRefImpl(ResRef rri) {
		this._name = rri.getName();
		this.initialize(rri.getDescription(), rri.getJNDIName(), rri.getType(), rri.getAuth(), rri.getSharingScope(),
				rri.getIsolationLevel(), rri.getLoginConfigurationName(), (EList) null, rri.getLoginPropertyList());
	}

	private void initialize(String description, String jndiName, String type, int resAuth, int resSharingScope,
			int resIsolationLevel, String loginConfigurationName, EList loginProperties,
			List<Property> loginPropertyList) {
		this._description = description;
		this._type = type;
		this._jndiName = jndiName;
		this.setResAuthType(resAuth);
		this.setSharingScope(resSharingScope);
		this.setIsolationLevel(resIsolationLevel);
		this._loginConfigurationName = loginConfigurationName;
		if (loginProperties == null) {
			this._loginProperties = loginPropertyList;
		} else {
			this.setLoginProperties(loginProperties);
		}

	}

	public String getDescription() {
		return this._description;
	}

	public String getName() {
		return this._name;
	}

	public String getType() {
		return this._type;
	}

	public int getAuth() {
		AuthType value = this._resAuth != null ? this._resAuth : AuthType.Application;
		return value.ordinal();
	}

	public int getSharingScope() {
		SharingScope value = this._resSharingScope != null ? this._resSharingScope : SharingScope.Shareable;
		return value.ordinal();
	}

	public int getIsolationLevel() {
		IsolationLevel value = this._resIsolationLevel != null
				? this._resIsolationLevel
				: IsolationLevel.TRANSACTION_NONE;
		return value._value;
	}

	public String getJNDIName() {
		return this._jndiName;
	}

	public String getLoginConfigurationName() {
		return this._loginConfigurationName;
	}

	public EList getLoginProperties() {
		if (this._loginProperties == null) {
			return null;
		} else {
			List<EObject> loginProperties = new BasicEList();
			if (!this._loginProperties.isEmpty()) {
				EPackage pkg = Registry.INSTANCE.getEPackage("commonbnd.xmi");
				EClass klass = (EClass) pkg.getEClassifiers().get(6);
				EStructuralFeature nameFeature = klass.getEStructuralFeature(0);
				EStructuralFeature valueFeature = klass.getEStructuralFeature(2);
				EFactory factory = pkg.getEFactoryInstance();
				Iterator i$ = this._loginProperties.iterator();

				while (i$.hasNext()) {
					Property property = (Property) i$.next();
					EObject object = factory.create(klass);
					object.eSet(nameFeature, property.getName());
					object.eSet(valueFeature, property.getValue());
					loginProperties.add(object);
				}
			}

			return (EList) loginProperties;
		}
	}

	public List<Property> getLoginPropertyList() {
		return this._loginProperties;
	}

	public void setIsolationLevel(int isoLevel) {
		this._resIsolationLevel = isoLevel >= 0 && isoLevel < ISOLATION_LEVEL_VALUES.length
				? ISOLATION_LEVEL_VALUES[isoLevel]
				: null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setIsolationLevel: res-ref-name=" + this._name + ", isolation-level=" + isoLevel + "="
					+ this._resIsolationLevel);
		}

	}

	public void setCommitPriority(int commitPriority) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setCommitPriority: res-ref-name=" + this._name + ", commit-priority=" + commitPriority);
		}

		this._commitPriority = commitPriority;
	}

	public int getCommitPriority() {
		return this._commitPriority;
	}

	public void setBranchCoupling(int branchCoupling) {
		this._branchCoupling = branchCoupling >= 0 && branchCoupling < BRANCH_COUPLING_VALUES.length
				? BRANCH_COUPLING_VALUES[branchCoupling]
				: null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setBranchCoupling: res-ref-name=" + this._name + ", branch-coupling=" + branchCoupling + "="
					+ this._branchCoupling);
		}

	}

	public int getBranchCoupling() {
		return this._branchCoupling == null ? -1 : this._branchCoupling.ordinal();
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		String separator = (String) AccessController
				.doPrivileged(new SystemGetPropertyPrivileged("line.separator", "\n"));
		String sep = "                                 ";
		sb.append(separator + sep + "    ******* Resource-Ref ******* ");
		sb.append(separator + sep + "Description=" + this._description);
		sb.append(separator + sep + "Name=" + this._name);
		sb.append(separator + sep + "JNDIName=" + this._jndiName);
		sb.append(separator + sep + "Type=" + this._type);
		sb.append(separator + sep + "ResAuth=" + this._resAuth);
		sb.append(separator + sep + "ResSharingScope=" + this._resSharingScope);
		sb.append(separator + sep + "IsolationLevel=" + this._resIsolationLevel);
		sb.append(separator + sep + "loginConfigurationName=" + this._loginConfigurationName);
		sb.append(separator + sep + "loginProperties=" + this._loginProperties);
		sb.append(separator + sep + "CommitPriority=" + this._commitPriority);
		sb.append(separator + sep + "BranchCoupling=" + this._branchCoupling);
		return sb.toString();
	}

	public void setSharingScope(int resSharable) {
		this._resSharingScope = resSharable >= 0 && resSharable < SHARING_SCOPE_VALUES.length
				? SHARING_SCOPE_VALUES[resSharable]
				: null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setSharingScope: res-ref-name=" + this._name + ", res-sharing-scope=" + resSharable + "="
					+ this._resSharingScope);
		}

	}

	public void setResAuthType(int resAuth) {
		this._resAuth = resAuth >= 0 && resAuth < AUTH_TYPE_VALUES.length ? AUTH_TYPE_VALUES[resAuth] : null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setResAuthType: res-ref-name=" + this._name + ", res-auth=" + resAuth + "=" + this._resAuth);
		}

	}

	public void setLoginConfigurationName(String loginConfigurationName) {
		this._loginConfigurationName = loginConfigurationName;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setLoginConfigurationName: res-ref-name=" + this._name + ", custom-login-configuration name="
					+ loginConfigurationName);
		}

	}

	void setLoginProperties(List<?> loginProperties) {
		this._loginProperties = new ArrayList();
		if (!loginProperties.isEmpty()) {
			EPackage pkg = Registry.INSTANCE.getEPackage("commonbnd.xmi");
			EClass klass = (EClass) pkg.getEClassifiers().get(6);
			EStructuralFeature nameFeature = klass.getEStructuralFeature(0);
			EStructuralFeature valueFeature = klass.getEStructuralFeature(2);
			Iterator i$ = loginProperties.iterator();

			while (i$.hasNext()) {
				Object object = i$.next();
				EObject property = (EObject) object;
				String propertyName = (String) property.eGet(nameFeature);
				String propertyValue = (String) property.eGet(valueFeature);
				this._loginProperties.add(new PropertyImpl(propertyName, propertyValue));
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "setLoginProperties: res-ref-name=" + this._name + ", name=" + propertyName
							+ ", value=" + propertyValue);
				}
			}
		}

	}

	public void clearLoginProperties() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "clearLoginProperties: res-ref-name=" + this._name);
		}

		this._loginProperties = null;
	}

	public void addLoginProperty(String name, String value) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "addLoginProperty: res-ref-name=" + this._name + ", name=" + name + ", value=" + value);
		}

		if (this._loginProperties == null) {
			this._loginProperties = new ArrayList();
		}

		this._loginProperties.add(new PropertyImpl(name, value));
	}

	public void setAuthenticationAliasName(String name) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc,
					"setAuthenticationAliasName: res-ref-name=" + this._name + ", authentication-alias name=" + name);
		}

		this._loginConfigurationName = "DefaultPrincipalMapping";
		this._loginProperties = new ArrayList();
		this._loginProperties.add(new PropertyImpl("com.ibm.mapping.authDataAlias", name));
	}

	public void setDescription(String description) {
		this._description = description;
	}

	public void setType(String type) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setType: res-ref-name=" + this._name + ", res-type=" + type);
		}

		this._type = type;
	}

	public void setJNDIName(String jndiName) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "setJNDIName: res-ref-name=" + this._name + ", binding-name=" + jndiName);
		}

		this._jndiName = jndiName;
	}

	public void mergeBindingsAndExtensions(ResourceRefConfig[] resRefs, List<MergeConflict> conflicts) {
		this.mergeBindingsAndExtensions(resRefs, conflicts, false);
	}

	public List<MergeConflict> compareBindingsAndExtensions(ResourceRefConfig resRef) {
		List<MergeConflict> conflicts = new ArrayList();
		this.mergeBindingsAndExtensions(new ResourceRefConfig[]{this, resRef}, conflicts, true);
		return conflicts;
	}

	private void mergeBindingsAndExtensions(ResourceRefConfig[] resRefs, List<MergeConflict> conflicts,
			boolean compareOnly) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "mergeBindingsAndExtensions: " + this.getName() + ", " + resRefs.length + ", " + compareOnly);
		}

		boolean strict = compareOnly;
		Attribute<String> bindingName = new Attribute(this, "binding-name", conflicts, compareOnly);
		Attribute<String> loginConfigurationName = new Attribute(this, "custom-login-configuration", conflicts,
				compareOnly);
		Map<String, Attribute<String>> loginProperties = null;
		Attribute<IsolationLevel> isolationLevel = new Attribute(this, "isolation-level", conflicts, compareOnly);
		Attribute<Integer> commitPriority = new Attribute(this, "commit-priority", conflicts, compareOnly);
		Attribute<BranchCoupling> branchCoupling = new Attribute(this, "branch-coupling", conflicts, compareOnly);

		for (int i = 0; i < resRefs.length; ++i) {
			ResourceRefConfig resRef = resRefs[i];
			if (resRef != null) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "merging " + i + ": " + resRef);
				}

				bindingName.merge(i, resRef.getJNDIName());
				loginConfigurationName.merge(i, resRef.getLoginConfigurationName());
				List<? extends com.ibm.ws.resource.ResourceRefInfo.Property> loginPropertyList = resRef
						.getLoginPropertyList();
				Iterator i$;
				if (loginPropertyList != null) {
					if (loginProperties == null) {
						loginProperties = new LinkedHashMap();
					}

					if (strict && i != 0) {
						Set<String> newNames = new HashSet();
						Iterator i$ = loginPropertyList.iterator();

						while (i$.hasNext()) {
							com.ibm.ws.resource.ResourceRefInfo.Property property = (com.ibm.ws.resource.ResourceRefInfo.Property) i$
									.next();
							newNames.add(property.getName());
						}

						i$ = loginProperties.entrySet().iterator();

						while (i$.hasNext()) {
							Entry<String, Attribute<String>> entry = (Entry) i$.next();
							if (!newNames.contains(entry.getKey())) {
								((Attribute) entry.getValue()).merge(i, (Object) null);
							}
						}
					}

					Attribute attribute;
					com.ibm.ws.resource.ResourceRefInfo.Property property;
					for (i$ = loginPropertyList.iterator(); i$.hasNext(); attribute.merge(i, property.getValue())) {
						property = (com.ibm.ws.resource.ResourceRefInfo.Property) i$.next();
						String propertyName = property.getName();
						attribute = (Attribute) loginProperties.get(propertyName);
						if (attribute == null) {
							String attributeName;
							if (propertyName.equals("com.ibm.mapping.authDataAlias")) {
								attributeName = "authentication-alias";
							} else {
								attributeName = "custom-login-configuration " + propertyName;
							}

							attribute = new Attribute(this, attributeName, conflicts, strict);
							loginProperties.put(propertyName, attribute);
							if (strict && i != 0) {
								attribute.merge(i, (Object) null);
							}
						}
					}
				} else if (strict && loginProperties != null) {
					i$ = loginProperties.values().iterator();

					while (i$.hasNext()) {
						Attribute<String> attribute = (Attribute) i$.next();
						attribute.merge(i, (Object) null);
					}
				}

				isolationLevel.merge(i, ISOLATION_LEVEL_VALUES[resRef.getIsolationLevel()]);
				commitPriority.merge(i, resRef.getCommitPriority());
				int branchCouplingValue = resRef.getBranchCoupling();
				if (branchCouplingValue != -1) {
					branchCoupling.merge(i, BRANCH_COUPLING_VALUES[branchCouplingValue]);
				} else if (strict) {
					branchCoupling.merge(i, (Object) null);
				}
			}
		}

		if (!compareOnly) {
			this._jndiName = (String) bindingName.ivValue;
			this._loginConfigurationName = (String) loginConfigurationName.ivValue;
			if (loginProperties != null) {
				this._loginProperties = new ArrayList(loginProperties.size());
				Iterator i$ = loginProperties.entrySet().iterator();

				while (i$.hasNext()) {
					Entry<String, Attribute<String>> entry = (Entry) i$.next();
					this._loginProperties.add(
							new PropertyImpl((String) entry.getKey(), (String) ((Attribute) entry.getValue()).ivValue));
				}
			}

			this._resIsolationLevel = (IsolationLevel) isolationLevel.ivValue;
			if (commitPriority.ivValue != null) {
				this.setCommitPriority((Integer) commitPriority.ivValue);
			}

			this._branchCoupling = (BranchCoupling) branchCoupling.ivValue;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "mergeBindingsAndExtensions");
		}

	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		AUTH_TYPE_VALUES = AuthType.values();
		SHARING_SCOPE_VALUES = SharingScope.values();
		ISOLATION_LEVEL_VALUES = new IsolationLevel[]{IsolationLevel.TRANSACTION_NONE,
				IsolationLevel.TRANSACTION_READ_UNCOMMITTED, IsolationLevel.TRANSACTION_READ_COMMITTED, null,
				IsolationLevel.TRANSACTION_REPEATABLE_READ, null, null, null, IsolationLevel.TRANSACTION_SERIALIZABLE};
		BRANCH_COUPLING_VALUES = BranchCoupling.values();
	}
}