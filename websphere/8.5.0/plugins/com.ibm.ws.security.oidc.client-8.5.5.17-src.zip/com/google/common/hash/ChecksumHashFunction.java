package com.google.common.hash;

import com.google.common.base.Preconditions;
import com.google.common.hash.ChecksumHashFunction.1;
import com.google.common.hash.ChecksumHashFunction.ChecksumHasher;
import com.google.errorprone.annotations.Immutable;
import java.io.Serializable;
import java.util.zip.Checksum;

@Immutable
final class ChecksumHashFunction extends AbstractHashFunction implements Serializable {
	private final ImmutableSupplier<? extends Checksum> checksumSupplier;
	private final int bits;
	private final String toString;
	private static final long serialVersionUID = 0L;

	ChecksumHashFunction(ImmutableSupplier<? extends Checksum> checksumSupplier, int bits, String toString) {
		this.checksumSupplier = (ImmutableSupplier) Preconditions.checkNotNull(checksumSupplier);
		Preconditions.checkArgument(bits == 32 || bits == 64, "bits (%s) must be either 32 or 64", bits);
		this.bits = bits;
		this.toString = (String) Preconditions.checkNotNull(toString);
	}

	public int bits() {
		return this.bits;
	}

	public Hasher newHasher() {
      return new ChecksumHasher(this, (Checksum)this.checksumSupplier.get(), (1)null);
   }

	public String toString() {
		return this.toString;
	}
}