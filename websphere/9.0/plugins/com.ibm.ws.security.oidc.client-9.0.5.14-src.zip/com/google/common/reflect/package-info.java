package com.google.common.reflect;

import com.google.errorprone.annotations.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;

// $FF: synthetic class
@CheckReturnValue
@ParametersAreNonnullByDefault
interface package-info {
}