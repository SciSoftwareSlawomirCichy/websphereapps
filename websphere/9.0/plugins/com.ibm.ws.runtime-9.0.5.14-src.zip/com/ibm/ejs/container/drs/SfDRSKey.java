package com.ibm.ejs.container.drs;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.util.ByteArray;
import com.ibm.ws.ejbcontainer.failover.SfFailoverKey;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public final class SfDRSKey implements SfFailoverKey {
	private static final long serialVersionUID = 2106363575981494098L;
	private transient int ivHashCode;
	private transient ByteArray ivByteArray;

	public SfDRSKey(BeanId beanId) {
		this.ivByteArray = beanId.getByteArray();
		this.ivHashCode = this.ivByteArray.hashCode();
	}

	public SfDRSKey(ByteArray ba) {
		this.ivByteArray = ba;
		this.ivHashCode = ba.hashCode();
	}

	public SfDRSKey() {
	}

	public ByteArray getByteArray() {
		return this.ivByteArray;
	}

	public byte[] getBytes() {
		byte[] bytes = this.ivByteArray == null ? null : this.ivByteArray.getBytes();
		return bytes;
	}

	public boolean equals(SfDRSKey key) {
		boolean returnValue = false;
		if (key != null && this.ivByteArray != null) {
			returnValue = this.ivByteArray.equals(key.ivByteArray);
		}

		return returnValue;
	}

	public boolean equals(Object obj) {
		boolean returnValue = false;
		if (obj != null && obj instanceof SfDRSKey && this.ivByteArray != null) {
			SfDRSKey key = (SfDRSKey) obj;
			returnValue = this.ivByteArray.equals(key.ivByteArray);
		}

		return returnValue;
	}

	public int hashCode() {
		return this.ivHashCode;
	}

	public String toString() {
		String s = null;
		if (this.ivByteArray != null) {
			s = this.ivByteArray.toString();
		}

		return s;
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		int n = in.readInt();
		if (n == 0) {
			this.ivByteArray = null;
		} else {
			byte[] bytes = new byte[n];
			int bytesRead = false;

			int bytesRead;
			for (int offset = 0; offset < n; offset += bytesRead) {
				bytesRead = in.read(bytes, offset, n - offset);
				if (bytesRead == -1) {
					throw new IOException("end of input stream while reading SFSB DRS key");
				}
			}

			this.ivByteArray = new ByteArray(bytes);
			if (this.ivByteArray != null) {
				this.ivHashCode = this.ivByteArray.hashCode();
			} else {
				this.ivHashCode = 0;
			}
		}

	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
		byte[] bytes = this.getBytes();
		if (bytes == null) {
			out.writeInt(0);
		} else {
			out.writeInt(bytes.length);
			out.write(bytes);
		}

	}
}