package com.ibm.ejs.cm.portability;

import java.sql.SQLException;

public abstract class PortableSQLException extends com.ibm.websphere.ce.cm.PortableSQLException {
	protected PortableSQLException(SQLException nativeException) {
		super(nativeException);
	}

	protected PortableSQLException(String message) {
		super(message);
	}

	protected PortableSQLException() {
	}

	public PortableSQLException(String reason, String state, int errCode) {
		super(reason, state, errCode);
	}

	public final SQLException getNativeException() {
		return super.getNextException();
	}

	protected final void setNativeException(SQLException nativeException) {
		this.setNextException(nativeException);
	}
}