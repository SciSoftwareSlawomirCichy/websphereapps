package com.ibm.ejs.sm.exception;

public class OpException extends Exception {
	public OpException(String s) {
		super(s);
	}

	public OpException() {
	}
}