package com.google.common.hash;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.hash.BloomFilter.SerialForm;
import com.google.common.hash.BloomFilter.Strategy;
import com.google.common.hash.BloomFilterStrategies.BitArray;
import java.io.Serializable;
import javax.annotation.Nullable;

@Beta
public final class BloomFilter<T> implements Predicate<T>, Serializable {
	private final BitArray bits;
	private final int numHashFunctions;
	private final Funnel<T> funnel;
	private final Strategy strategy;

	private BloomFilter(BitArray bits, int numHashFunctions, Funnel<T> funnel, Strategy strategy) {
		Preconditions.checkArgument(numHashFunctions > 0, "numHashFunctions (%s) must be > 0",
				new Object[]{numHashFunctions});
		Preconditions.checkArgument(numHashFunctions <= 255, "numHashFunctions (%s) must be <= 255",
				new Object[]{numHashFunctions});
		this.bits = (BitArray) Preconditions.checkNotNull(bits);
		this.numHashFunctions = numHashFunctions;
		this.funnel = (Funnel) Preconditions.checkNotNull(funnel);
		this.strategy = (Strategy) Preconditions.checkNotNull(strategy);
	}

	public BloomFilter<T> copy() {
		return new BloomFilter(this.bits.copy(), this.numHashFunctions, this.funnel, this.strategy);
	}

	public boolean mightContain(T object) {
		return this.strategy.mightContain(object, this.funnel, this.numHashFunctions, this.bits);
	}

	public boolean apply(T input) {
		return this.mightContain(input);
	}

	public boolean put(T object) {
		return this.strategy.put(object, this.funnel, this.numHashFunctions, this.bits);
	}

	public double expectedFpp() {
		return Math.pow((double) this.bits.bitCount() / (double) this.bits.size(), (double) this.numHashFunctions);
	}

	@Deprecated
	public double expectedFalsePositiveProbability() {
		return this.expectedFpp();
	}

	public boolean equals(@Nullable Object object) {
		if (object == this) {
			return true;
		} else if (!(object instanceof BloomFilter)) {
			return false;
		} else {
			BloomFilter<?> that = (BloomFilter) object;
			return this.numHashFunctions == that.numHashFunctions && this.funnel.equals(that.funnel)
					&& this.bits.equals(that.bits) && this.strategy.equals(that.strategy);
		}
	}

	public int hashCode() {
		return Objects.hashCode(new Object[]{this.numHashFunctions, this.funnel, this.strategy, this.bits});
	}

	public static <T> BloomFilter<T> create(Funnel<T> funnel, int expectedInsertions, double fpp) {
		Preconditions.checkNotNull(funnel);
		Preconditions.checkArgument(expectedInsertions >= 0, "Expected insertions (%s) must be >= 0",
				new Object[]{expectedInsertions});
		Preconditions.checkArgument(fpp > 0.0D, "False positive probability (%s) must be > 0.0", new Object[]{fpp});
		Preconditions.checkArgument(fpp < 1.0D, "False positive probability (%s) must be < 1.0", new Object[]{fpp});
		if (expectedInsertions == 0) {
			expectedInsertions = 1;
		}

		long numBits = optimalNumOfBits((long) expectedInsertions, fpp);
		int numHashFunctions = optimalNumOfHashFunctions((long) expectedInsertions, numBits);

		try {
			return new BloomFilter(new BitArray(numBits), numHashFunctions, funnel,
					BloomFilterStrategies.MURMUR128_MITZ_32);
		} catch (IllegalArgumentException var8) {
			throw new IllegalArgumentException("Could not create BloomFilter of " + numBits + " bits", var8);
		}
	}

	public static <T> BloomFilter<T> create(Funnel<T> funnel, int expectedInsertions) {
		return create(funnel, expectedInsertions, 0.03D);
	}

	@VisibleForTesting
	static int optimalNumOfHashFunctions(long n, long m) {
		return Math.max(1, (int) Math.round((double) (m / n) * Math.log(2.0D)));
	}

	@VisibleForTesting
	static long optimalNumOfBits(long n, double p) {
		if (p == 0.0D) {
			p = Double.MIN_VALUE;
		}

		return (long) ((double) (-n) * Math.log(p) / (Math.log(2.0D) * Math.log(2.0D)));
	}

	private Object writeReplace() {
		return new SerialForm(this);
	}
}