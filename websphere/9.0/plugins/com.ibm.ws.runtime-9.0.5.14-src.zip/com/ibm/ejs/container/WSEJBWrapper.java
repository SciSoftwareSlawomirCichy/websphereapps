package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.wsspi.ejbcontainer.WSEJBEndpointManager;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.Map;

public class WSEJBWrapper extends EJSWrapperBase implements WSEJBEndpointManager {
	private static final String CLASS_NAME = WSEJBWrapper.class.getName();
	private static final TraceComponent tc;
	private Method ivMethod = null;
	private EJSDeployedSupport ivMethodContext = null;
	private int ivMethodIndex = Integer.MIN_VALUE;

	public Object ejbPreInvoke(Method method, Map<String, Object> context) throws RemoteException {
		if (this.ivMethod != null) {
			throw new IllegalStateException(
					"WSEJBEndpointManager.ejbPreInvoke called previously : " + this.ivMethod.getName());
		} else if (method == null) {
			throw new IllegalArgumentException("WSEJBEndpointManager.ejbPreInvoke requires a method");
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.entry(tc, "ejbPreInvoke : " + method.getName());
			}

			Object[] args = null;
			this.ivMethod = method;
			this.ivMethodIndex = this.getMethodIndex(method);
			this.ivMethodContext = new EJSDeployedSupport();
			this.ivMethodContext.ivContextData = context;
			Object bean = this.container.EjbPreInvoke(this, this.ivMethodIndex, this.ivMethodContext, (Object[]) args);
			if (this.bmd.ivWebServiceEndpointProxyClass != null) {
				try {
					WSEJBProxy proxy = (WSEJBProxy) this.bmd.ivWebServiceEndpointProxyClass.newInstance();
					proxy.ivContainer = this.container;
					proxy.ivMethodContext = this.ivMethodContext;
					proxy.ivEjbInstance = bean;
					bean = proxy;
				} catch (Throwable var6) {
					FFDCFilter.processException(var6, CLASS_NAME + ".ejbPreInvoke", "192", this);
					throw ExceptionUtil.EJBException("Failed to create proxy for Web service endpoint", var6);
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "ejbPreInvoke : " + this.ivMethod.getName() + " : " + bean.getClass().getName());
			}

			return bean;
		}
	}

	public void ejbPostInvoke() throws RemoteException {
		if (this.ivMethod == null) {
			throw new IllegalStateException("WSEJBEndpointManager.ejbPreInvoke must be called first.");
		} else if (this.ivMethodContext == null) {
			if (this.ivMethodIndex != Integer.MIN_VALUE) {
				throw new IllegalStateException("WSEJBEndpointManager.ejbPostInvoke already called.");
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.entry(tc, "ejbPostInvoke : " + this.ivMethod.getName());
			}

			try {
				this.container.postInvoke(this, this.ivMethodIndex, this.ivMethodContext);
			} finally {
				this.ivMethodContext = null;
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "ejbPostInvoke : " + this.ivMethod.getName());
				}

			}

		}
	}

	public Throwable setException(Throwable ex) {
		if (this.ivMethod == null) {
			throw new IllegalStateException("WSEJBEndpointManager.ejbPreInvoke must be called first.");
		} else if (this.ivMethodContext == null) {
			if (this.ivMethodIndex != Integer.MIN_VALUE) {
				throw new IllegalStateException("WSEJBEndpointManager.ejbPostInvoke already called.");
			} else {
				return ex;
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.entry(tc, "setException : " + ex.getClass().getName());
			}

			Throwable mappedException = null;
			ExceptionMappingStrategy exStrategy = this.ivMethodContext.getExceptionMappingStrategy();
			if (ex instanceof Exception && !(ex instanceof RemoteException)) {
				Class<?> exceptionClass = ex.getClass();
				Class<?>[] checkedExceptions = this.ivMethod.getExceptionTypes();
				Class[] arr$ = checkedExceptions;
				int len$ = checkedExceptions.length;

				for (int i$ = 0; i$ < len$; ++i$) {
					Class<?> checkedClass = arr$[i$];
					if (checkedClass.isAssignableFrom(exceptionClass)) {
						exStrategy.setCheckedException(this.ivMethodContext, (Exception) ex);
						if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
							Tr.exit(tc, "setException : " + ex.getClass().getName());
						}

						return ex;
					}
				}
			}

			mappedException = exStrategy.setUncheckedException(this.ivMethodContext, ex);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "setException : " + mappedException.getClass().getName());
			}

			return mappedException;
		}
	}

	private int getMethodIndex(Method method) {
		for (int i = 0; i < this.methodInfos.length; ++i) {
			if (this.methodInfos[i].methodsMatch(method)) {
				return i;
			}
		}

		Tr.error(tc, "WS_ENDPOINT_METHOD_MISSING_CNTR0178E", new Object[]{method.getName(),
				this.bmd.j2eeName.getComponent(), this.bmd.j2eeName.getModule(), this.bmd.j2eeName.getApplication()});
		throw ExceptionUtil
				.EJBException(
						"Configured Web service endpoint method " + method.getName() + " is not implemented by the "
								+ this.bmd.j2eeName.getComponent() + " bean in the " + this.bmd.j2eeName.getModule()
								+ " module of the " + this.bmd.j2eeName.getApplication() + " application.",
						(Throwable) null);
	}

	static boolean resolveWebServiceEndpointMethods(BeanMetaData bmd, Method[] endpointMethods)
			throws EJBConfigurationException {
		if (endpointMethods != null && endpointMethods.length != 0) {
			if (bmd.wsEndpointMethodInfos == null) {
				throw new EJBConfigurationException(
						"Web service endpoint is only allwed for stateless session beans, and a Web service endpoint interface must be configured in ejb-jar.xml if the module level is prior to 3.0 : "
								+ bmd.j2eeName);
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.entry(tc, "resolveWebServiceEndpointMethods : " + bmd.j2eeName);
				}

				boolean hasAroundInvoke = false;
				int numMethodInfos = bmd.wsEndpointMethodInfos.length;
				int numEndpointMethods = endpointMethods.length;
				String[] endpointMethodNames = new String[numEndpointMethods];
				EJBMethodInfoImpl[] endpointMethodInfos = new EJBMethodInfoImpl[numEndpointMethods];

				for (int i = 0; i < numEndpointMethods; ++i) {
					Method method = endpointMethods[i];

					for (int j = 0; j < numMethodInfos; ++j) {
						EJBMethodInfoImpl methodInfo = bmd.wsEndpointMethodInfos[j];
						if (methodInfo.methodsMatch(method)) {
							endpointMethodInfos[i] = methodInfo;
							endpointMethodNames[i] = method.getName();
							if (methodInfo.ivAroundInterceptors != null) {
								hasAroundInvoke = true;
							}

							if (methodInfo.getBridgeMethod() != null) {
								break;
							}
						}
					}

					if (endpointMethodInfos[i] == null) {
						Tr.error(tc, "WS_ENDPOINT_METHOD_MISSING_CNTR0178E", new Object[]{method.getName(),
								bmd.j2eeName.getComponent(), bmd.j2eeName.getModule(), bmd.j2eeName.getApplication()});
						throw new EJBConfigurationException("Configured Web service endpoint method " + method.getName()
								+ " is not implemented by the " + bmd.j2eeName.getComponent() + " bean in the "
								+ bmd.j2eeName.getModule() + " module of the " + bmd.j2eeName.getApplication()
								+ " application.");
					}
				}

				bmd.wsEndpointMethodInfos = endpointMethodInfos;
				bmd.wsEndpointMethodNames = endpointMethodNames;
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "resolveWebServiceEndpointMethods : " + bmd.j2eeName + " : aroundInvoke = "
							+ hasAroundInvoke);
				}

				return hasAroundInvoke;
			}
		} else {
			throw new EJBConfigurationException("Web service endpoint configurd with no methods : " + bmd.j2eeName);
		}
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}