package com.ibm.ejs.csi;

import com.ibm.ejs.oa.EJSORB;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import javax.ejb.Handle;
import javax.rmi.CORBA.Stub;

public class SessionHandle implements Handle, Serializable {
	private static final long serialVersionUID = -8306435371140344968L;
	private static final TraceComponent tc = Tr.register(SessionHandle.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	EJBObject object;
	private boolean isConnected = false;

	SessionHandle(EJBObject object) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>", object);
		}

		this.object = object;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public EJBObject getEJBObject() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEJBObject");
		}

		try {
			if (!this.isConnected) {
				this.getReference();
			}
		} catch (RemoteException var2) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "ERROR:getEJBObject: Could not get the handle reference", var2);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEJBObject");
		}

		return this.object;
	}

	private void writeObject(ObjectOutputStream outStream) throws IOException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "writeObject");
		}

		this.isConnected = false;
		outStream.defaultWriteObject();
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "writeObject");
		}

	}

	private void getReference() throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getReference");
		}

		try {
			((Stub) this.object)._orb();
		} catch (Exception var2) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "connecting EJBObject to ORB", this.object);
			}

			((Stub) this.object).connect(EJSORB.init());
		}

		this.isConnected = true;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getReference");
		}

	}
}