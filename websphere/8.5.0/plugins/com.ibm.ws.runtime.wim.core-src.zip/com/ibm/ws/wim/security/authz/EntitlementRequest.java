package com.ibm.ws.wim.security.authz;

import com.ibm.websphere.wim.security.authz.Entitlement;
import commonj.sdo.DataObject;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.eclipse.emf.ecore.sdo.EDataObject;

public class EntitlementRequest {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private boolean isExclusive = false;
	private boolean isRolesDesired = false;
	private boolean isObjectEntitlementsDesired = false;
	private boolean isAttributeEntitlementsDesired = false;
	private Set entitlementAttributes;
	private Entitlement entitlementFilter;
	private Entitlement entitlementCheck;

	public EntitlementRequest(DataObject var1) {
		List var3 = var1.getList("controls");
		Iterator var4 = var3.iterator();

		while (var4.hasNext()) {
			DataObject var2 = (DataObject) var4.next();
			if (((EDataObject) var2).eClass().getName().equals("EntitlementControl")) {
				this.isExclusive = var2.getBoolean("getExclusively");
				this.isRolesDesired = var2.getBoolean("getRoles");
				this.isObjectEntitlementsDesired = var2.getBoolean("getObjectEntitlements");
				this.isAttributeEntitlementsDesired = var2.getBoolean("getAttributeEntitlements");
				if (var2.getList("entitlementAttributes").size() != 0) {
					this.entitlementAttributes = new HashSet(var2.getList("entitlementAttributes"));
				}

				this.entitlementFilter = EntitlementHelper
						.getEntitlementFromDataObject(var2.getDataObject("entitlementFilter"));
				this.entitlementCheck = EntitlementHelper
						.getEntitlementFromDataObject(var2.getDataObject("entitlementCheck"));
				break;
			}
		}

	}

	public EntitlementRequest(boolean var1, boolean var2, boolean var3, boolean var4, Set var5, Entitlement var6,
			Entitlement var7) {
		this.isExclusive = var1;
		this.isRolesDesired = var2;
		this.isObjectEntitlementsDesired = var3;
		this.isAttributeEntitlementsDesired = var4;
		this.entitlementAttributes = var5;
		this.entitlementFilter = var6;
		this.entitlementCheck = var7;
	}

	public boolean isEmpty() {
		return !this.isRolesDesired && !this.isObjectEntitlementsDesired && !this.isAttributeEntitlementsDesired
				&& this.entitlementFilter == null && this.entitlementCheck == null;
	}

	public boolean isExclusive() {
		return this.isExclusive;
	}

	public boolean isRolesDesired() {
		return this.isRolesDesired;
	}

	public boolean isObjectEntitlementsDesired() {
		return this.isObjectEntitlementsDesired;
	}

	public boolean isAttributeEntitlementsDesired() {
		return this.isAttributeEntitlementsDesired;
	}

	public Set getEntitlementAttributes() {
		return this.entitlementAttributes;
	}

	public Entitlement getEntitlementFilter() {
		return this.entitlementFilter;
	}

	public Entitlement getEntitlementCheck() {
		return this.entitlementCheck;
	}
}