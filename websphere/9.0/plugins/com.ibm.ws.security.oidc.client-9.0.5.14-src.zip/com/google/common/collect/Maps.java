package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Converter;
import com.google.common.base.Equivalence;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps.1;
import com.google.common.collect.Maps.10;
import com.google.common.collect.Maps.11;
import com.google.common.collect.Maps.12;
import com.google.common.collect.Maps.13;
import com.google.common.collect.Maps.2;
import com.google.common.collect.Maps.3;
import com.google.common.collect.Maps.4;
import com.google.common.collect.Maps.5;
import com.google.common.collect.Maps.6;
import com.google.common.collect.Maps.7;
import com.google.common.collect.Maps.8;
import com.google.common.collect.Maps.9;
import com.google.common.collect.Maps.AbstractFilteredMap;
import com.google.common.collect.Maps.AsMapView;
import com.google.common.collect.Maps.BiMapConverter;
import com.google.common.collect.Maps.EntryFunction;
import com.google.common.collect.Maps.EntryTransformer;
import com.google.common.collect.Maps.FilteredEntryBiMap;
import com.google.common.collect.Maps.FilteredEntryMap;
import com.google.common.collect.Maps.FilteredEntryNavigableMap;
import com.google.common.collect.Maps.FilteredEntrySortedMap;
import com.google.common.collect.Maps.FilteredKeyMap;
import com.google.common.collect.Maps.MapDifferenceImpl;
import com.google.common.collect.Maps.NavigableAsMapView;
import com.google.common.collect.Maps.SortedAsMapView;
import com.google.common.collect.Maps.SortedMapDifferenceImpl;
import com.google.common.collect.Maps.TransformedEntriesMap;
import com.google.common.collect.Maps.TransformedEntriesNavigableMap;
import com.google.common.collect.Maps.TransformedEntriesSortedMap;
import com.google.common.collect.Maps.UnmodifiableBiMap;
import com.google.common.collect.Maps.UnmodifiableEntrySet;
import com.google.common.collect.Maps.UnmodifiableNavigableMap;
import com.google.common.collect.Maps.ValueDifferenceImpl;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Properties;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
public final class Maps {
	static <K> Function<Entry<K, ?>, K> keyFunction() {
		return EntryFunction.KEY;
	}

	static <V> Function<Entry<?, V>, V> valueFunction() {
		return EntryFunction.VALUE;
	}

	static <K, V> Iterator<K> keyIterator(Iterator<Entry<K, V>> entryIterator) {
      return new 1(entryIterator);
   }

	static <K, V> Iterator<V> valueIterator(Iterator<Entry<K, V>> entryIterator) {
      return new 2(entryIterator);
   }

	@GwtCompatible(serializable = true)
	@Beta
	public static <K extends Enum<K>, V> ImmutableMap<K, V> immutableEnumMap(Map<K, ? extends V> map) {
		if (map instanceof ImmutableEnumMap) {
			ImmutableEnumMap<K, V> result = (ImmutableEnumMap) map;
			return result;
		} else {
			Iterator<? extends Entry<K, ? extends V>> entryItr = map.entrySet().iterator();
			if (!entryItr.hasNext()) {
				return ImmutableMap.of();
			} else {
				Entry<K, ? extends V> entry1 = (Entry) entryItr.next();
				K key1 = (Enum) entry1.getKey();
				V value1 = entry1.getValue();
				CollectPreconditions.checkEntryNotNull(key1, value1);
				Class<K> clazz = key1.getDeclaringClass();
				EnumMap<K, V> enumMap = new EnumMap(clazz);
				enumMap.put(key1, value1);

				while (entryItr.hasNext()) {
					Entry<K, ? extends V> entry = (Entry) entryItr.next();
					K key = (Enum) entry.getKey();
					V value = entry.getValue();
					CollectPreconditions.checkEntryNotNull(key, value);
					enumMap.put(key, value);
				}

				return ImmutableEnumMap.asImmutable(enumMap);
			}
		}
	}

	public static <K, V> HashMap<K, V> newHashMap() {
		return new HashMap();
	}

	public static <K, V> HashMap<K, V> newHashMap(Map<? extends K, ? extends V> map) {
		return new HashMap(map);
	}

	public static <K, V> HashMap<K, V> newHashMapWithExpectedSize(int expectedSize) {
		return new HashMap(capacity(expectedSize));
	}

	static int capacity(int expectedSize) {
		if (expectedSize < 3) {
			CollectPreconditions.checkNonnegative(expectedSize, "expectedSize");
			return expectedSize + 1;
		} else {
			return expectedSize < 1073741824 ? (int) ((float) expectedSize / 0.75F + 1.0F) : Integer.MAX_VALUE;
		}
	}

	public static <K, V> LinkedHashMap<K, V> newLinkedHashMap() {
		return new LinkedHashMap();
	}

	public static <K, V> LinkedHashMap<K, V> newLinkedHashMap(Map<? extends K, ? extends V> map) {
		return new LinkedHashMap(map);
	}

	public static <K, V> LinkedHashMap<K, V> newLinkedHashMapWithExpectedSize(int expectedSize) {
		return new LinkedHashMap(capacity(expectedSize));
	}

	public static <K, V> ConcurrentMap<K, V> newConcurrentMap() {
		return new ConcurrentHashMap();
	}

	public static <K extends Comparable, V> TreeMap<K, V> newTreeMap() {
		return new TreeMap();
	}

	public static <K, V> TreeMap<K, V> newTreeMap(SortedMap<K, ? extends V> map) {
		return new TreeMap(map);
	}

	public static <C, K extends C, V> TreeMap<K, V> newTreeMap(@NullableDecl Comparator<C> comparator) {
		return new TreeMap(comparator);
	}

	public static <K extends Enum<K>, V> EnumMap<K, V> newEnumMap(Class<K> type) {
		return new EnumMap((Class) Preconditions.checkNotNull(type));
	}

	public static <K extends Enum<K>, V> EnumMap<K, V> newEnumMap(Map<K, ? extends V> map) {
		return new EnumMap(map);
	}

	public static <K, V> IdentityHashMap<K, V> newIdentityHashMap() {
		return new IdentityHashMap();
	}

	public static <K, V> MapDifference<K, V> difference(Map<? extends K, ? extends V> left,
			Map<? extends K, ? extends V> right) {
		if (left instanceof SortedMap) {
			SortedMap<K, ? extends V> sortedLeft = (SortedMap) left;
			return difference(sortedLeft, right);
		} else {
			return difference(left, right, Equivalence.equals());
		}
	}

	public static <K, V> MapDifference<K, V> difference(Map<? extends K, ? extends V> left,
			Map<? extends K, ? extends V> right, Equivalence<? super V> valueEquivalence) {
		Preconditions.checkNotNull(valueEquivalence);
		Map<K, V> onlyOnLeft = newLinkedHashMap();
		Map<K, V> onlyOnRight = new LinkedHashMap(right);
		Map<K, V> onBoth = newLinkedHashMap();
		Map<K, ValueDifference<V>> differences = newLinkedHashMap();
		doDifference(left, right, valueEquivalence, onlyOnLeft, onlyOnRight, onBoth, differences);
		return new MapDifferenceImpl(onlyOnLeft, onlyOnRight, onBoth, differences);
	}

	public static <K, V> SortedMapDifference<K, V> difference(SortedMap<K, ? extends V> left,
			Map<? extends K, ? extends V> right) {
		Preconditions.checkNotNull(left);
		Preconditions.checkNotNull(right);
		Comparator<? super K> comparator = orNaturalOrder(left.comparator());
		SortedMap<K, V> onlyOnLeft = newTreeMap(comparator);
		SortedMap<K, V> onlyOnRight = newTreeMap(comparator);
		onlyOnRight.putAll(right);
		SortedMap<K, V> onBoth = newTreeMap(comparator);
		SortedMap<K, ValueDifference<V>> differences = newTreeMap(comparator);
		doDifference(left, right, Equivalence.equals(), onlyOnLeft, onlyOnRight, onBoth, differences);
		return new SortedMapDifferenceImpl(onlyOnLeft, onlyOnRight, onBoth, differences);
	}

	private static <K, V> void doDifference(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right,
			Equivalence<? super V> valueEquivalence, Map<K, V> onlyOnLeft, Map<K, V> onlyOnRight, Map<K, V> onBoth,
			Map<K, ValueDifference<V>> differences) {
		Iterator var7 = left.entrySet().iterator();

		while (var7.hasNext()) {
			Entry<? extends K, ? extends V> entry = (Entry) var7.next();
			K leftKey = entry.getKey();
			V leftValue = entry.getValue();
			if (right.containsKey(leftKey)) {
				V rightValue = onlyOnRight.remove(leftKey);
				if (valueEquivalence.equivalent(leftValue, rightValue)) {
					onBoth.put(leftKey, leftValue);
				} else {
					differences.put(leftKey, ValueDifferenceImpl.create(leftValue, rightValue));
				}
			} else {
				onlyOnLeft.put(leftKey, leftValue);
			}
		}

	}

	private static <K, V> Map<K, V> unmodifiableMap(Map<K, ? extends V> map) {
		return (Map) (map instanceof SortedMap
				? Collections.unmodifiableSortedMap((SortedMap) map)
				: Collections.unmodifiableMap(map));
	}

	static <E> Comparator<? super E> orNaturalOrder(@NullableDecl Comparator<? super E> comparator) {
		return (Comparator) (comparator != null ? comparator : Ordering.natural());
	}

	public static <K, V> Map<K, V> asMap(Set<K> set, Function<? super K, V> function) {
		return new AsMapView(set, function);
	}

	public static <K, V> SortedMap<K, V> asMap(SortedSet<K> set, Function<? super K, V> function) {
		return new SortedAsMapView(set, function);
	}

	@GwtIncompatible
	public static <K, V> NavigableMap<K, V> asMap(NavigableSet<K> set, Function<? super K, V> function) {
		return new NavigableAsMapView(set, function);
	}

	static <K, V> Iterator<Entry<K, V>> asMapEntryIterator(Set<K> set, Function<? super K, V> function) {
      return new 3(set.iterator(), function);
   }

	private static <E> Set<E> removeOnlySet(Set<E> set) {
      return new 4(set);
   }

	private static <E> SortedSet<E> removeOnlySortedSet(SortedSet<E> set) {
      return new 5(set);
   }

	@GwtIncompatible
   private static <E> NavigableSet<E> removeOnlyNavigableSet(NavigableSet<E> set) {
      return new 6(set);
   }

	public static <K, V> ImmutableMap<K, V> toMap(Iterable<K> keys, Function<? super K, V> valueFunction) {
		return toMap(keys.iterator(), valueFunction);
	}

	public static <K, V> ImmutableMap<K, V> toMap(Iterator<K> keys, Function<? super K, V> valueFunction) {
		Preconditions.checkNotNull(valueFunction);
		LinkedHashMap builder = newLinkedHashMap();

		while (keys.hasNext()) {
			K key = keys.next();
			builder.put(key, valueFunction.apply(key));
		}

		return ImmutableMap.copyOf(builder);
	}

	@CanIgnoreReturnValue
	public static <K, V> ImmutableMap<K, V> uniqueIndex(Iterable<V> values, Function<? super V, K> keyFunction) {
		return uniqueIndex(values.iterator(), keyFunction);
	}

	@CanIgnoreReturnValue
	public static <K, V> ImmutableMap<K, V> uniqueIndex(Iterator<V> values, Function<? super V, K> keyFunction) {
		Preconditions.checkNotNull(keyFunction);
		Builder builder = ImmutableMap.builder();

		while (values.hasNext()) {
			V value = values.next();
			builder.put(keyFunction.apply(value), value);
		}

		try {
			return builder.build();
		} catch (IllegalArgumentException var4) {
			throw new IllegalArgumentException(
					var4.getMessage() + ". To index multiple values under a key, use Multimaps.index.");
		}
	}

	@GwtIncompatible
	public static ImmutableMap<String, String> fromProperties(Properties properties) {
		Builder<String, String> builder = ImmutableMap.builder();
		Enumeration e = properties.propertyNames();

		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			builder.put(key, properties.getProperty(key));
		}

		return builder.build();
	}

	@GwtCompatible(serializable = true)
	public static <K, V> Entry<K, V> immutableEntry(@NullableDecl K key, @NullableDecl V value) {
		return new ImmutableEntry(key, value);
	}

	static <K, V> Set<Entry<K, V>> unmodifiableEntrySet(Set<Entry<K, V>> entrySet) {
		return new UnmodifiableEntrySet(Collections.unmodifiableSet(entrySet));
	}

	static <K, V> Entry<K, V> unmodifiableEntry(Entry<? extends K, ? extends V> entry) {
      Preconditions.checkNotNull(entry);
      return new 7(entry);
   }

	static <K, V> UnmodifiableIterator<Entry<K, V>> unmodifiableEntryIterator(Iterator<Entry<K, V>> entryIterator) {
      return new 8(entryIterator);
   }

	@Beta
	public static <A, B> Converter<A, B> asConverter(BiMap<A, B> bimap) {
		return new BiMapConverter(bimap);
	}

	public static <K, V> BiMap<K, V> synchronizedBiMap(BiMap<K, V> bimap) {
		return Synchronized.biMap(bimap, (Object) null);
	}

	public static <K, V> BiMap<K, V> unmodifiableBiMap(BiMap<? extends K, ? extends V> bimap) {
		return new UnmodifiableBiMap(bimap, (BiMap) null);
	}

	public static <K, V1, V2> Map<K, V2> transformValues(Map<K, V1> fromMap, Function<? super V1, V2> function) {
		return transformEntries(fromMap, asEntryTransformer(function));
	}

	public static <K, V1, V2> SortedMap<K, V2> transformValues(SortedMap<K, V1> fromMap,
			Function<? super V1, V2> function) {
		return transformEntries(fromMap, asEntryTransformer(function));
	}

	@GwtIncompatible
	public static <K, V1, V2> NavigableMap<K, V2> transformValues(NavigableMap<K, V1> fromMap,
			Function<? super V1, V2> function) {
		return transformEntries(fromMap, asEntryTransformer(function));
	}

	public static <K, V1, V2> Map<K, V2> transformEntries(Map<K, V1> fromMap,
			EntryTransformer<? super K, ? super V1, V2> transformer) {
		return new TransformedEntriesMap(fromMap, transformer);
	}

	public static <K, V1, V2> SortedMap<K, V2> transformEntries(SortedMap<K, V1> fromMap,
			EntryTransformer<? super K, ? super V1, V2> transformer) {
		return new TransformedEntriesSortedMap(fromMap, transformer);
	}

	@GwtIncompatible
	public static <K, V1, V2> NavigableMap<K, V2> transformEntries(NavigableMap<K, V1> fromMap,
			EntryTransformer<? super K, ? super V1, V2> transformer) {
		return new TransformedEntriesNavigableMap(fromMap, transformer);
	}

	static <K, V1, V2> EntryTransformer<K, V1, V2> asEntryTransformer(Function<? super V1, V2> function) {
      Preconditions.checkNotNull(function);
      return new 9(function);
   }

	static <K, V1, V2> Function<V1, V2> asValueToValueFunction(EntryTransformer<? super K, V1, V2> transformer, K key) {
      Preconditions.checkNotNull(transformer);
      return new 10(transformer, key);
   }

	static <K, V1, V2> Function<Entry<K, V1>, V2> asEntryToValueFunction(EntryTransformer<? super K, ? super V1, V2> transformer) {
      Preconditions.checkNotNull(transformer);
      return new 11(transformer);
   }

	static <V2, K, V1> Entry<K, V2> transformEntry(EntryTransformer<? super K, ? super V1, V2> transformer, Entry<K, V1> entry) {
      Preconditions.checkNotNull(transformer);
      Preconditions.checkNotNull(entry);
      return new 12(entry, transformer);
   }

	static <K, V1, V2> Function<Entry<K, V1>, Entry<K, V2>> asEntryToEntryFunction(EntryTransformer<? super K, ? super V1, V2> transformer) {
      Preconditions.checkNotNull(transformer);
      return new 13(transformer);
   }

	static <K> Predicate<Entry<K, ?>> keyPredicateOnEntries(Predicate<? super K> keyPredicate) {
		return Predicates.compose(keyPredicate, keyFunction());
	}

	static <V> Predicate<Entry<?, V>> valuePredicateOnEntries(Predicate<? super V> valuePredicate) {
		return Predicates.compose(valuePredicate, valueFunction());
	}

	public static <K, V> Map<K, V> filterKeys(Map<K, V> unfiltered, Predicate<? super K> keyPredicate) {
		Preconditions.checkNotNull(keyPredicate);
		Predicate<Entry<K, ?>> entryPredicate = keyPredicateOnEntries(keyPredicate);
		return (Map) (unfiltered instanceof AbstractFilteredMap
				? filterFiltered((AbstractFilteredMap) unfiltered, entryPredicate)
				: new FilteredKeyMap((Map) Preconditions.checkNotNull(unfiltered), keyPredicate, entryPredicate));
	}

	public static <K, V> SortedMap<K, V> filterKeys(SortedMap<K, V> unfiltered, Predicate<? super K> keyPredicate) {
		return filterEntries(unfiltered, keyPredicateOnEntries(keyPredicate));
	}

	@GwtIncompatible
	public static <K, V> NavigableMap<K, V> filterKeys(NavigableMap<K, V> unfiltered,
			Predicate<? super K> keyPredicate) {
		return filterEntries(unfiltered, keyPredicateOnEntries(keyPredicate));
	}

	public static <K, V> BiMap<K, V> filterKeys(BiMap<K, V> unfiltered, Predicate<? super K> keyPredicate) {
		Preconditions.checkNotNull(keyPredicate);
		return filterEntries(unfiltered, keyPredicateOnEntries(keyPredicate));
	}

	public static <K, V> Map<K, V> filterValues(Map<K, V> unfiltered, Predicate<? super V> valuePredicate) {
		return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
	}

	public static <K, V> SortedMap<K, V> filterValues(SortedMap<K, V> unfiltered, Predicate<? super V> valuePredicate) {
		return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
	}

	@GwtIncompatible
	public static <K, V> NavigableMap<K, V> filterValues(NavigableMap<K, V> unfiltered,
			Predicate<? super V> valuePredicate) {
		return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
	}

	public static <K, V> BiMap<K, V> filterValues(BiMap<K, V> unfiltered, Predicate<? super V> valuePredicate) {
		return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
	}

	public static <K, V> Map<K, V> filterEntries(Map<K, V> unfiltered, Predicate<? super Entry<K, V>> entryPredicate) {
		Preconditions.checkNotNull(entryPredicate);
		return (Map) (unfiltered instanceof AbstractFilteredMap
				? filterFiltered((AbstractFilteredMap) unfiltered, entryPredicate)
				: new FilteredEntryMap((Map) Preconditions.checkNotNull(unfiltered), entryPredicate));
	}

	public static <K, V> SortedMap<K, V> filterEntries(SortedMap<K, V> unfiltered,
			Predicate<? super Entry<K, V>> entryPredicate) {
		Preconditions.checkNotNull(entryPredicate);
		return (SortedMap) (unfiltered instanceof FilteredEntrySortedMap
				? filterFiltered((FilteredEntrySortedMap) unfiltered, entryPredicate)
				: new FilteredEntrySortedMap((SortedMap) Preconditions.checkNotNull(unfiltered), entryPredicate));
	}

	@GwtIncompatible
	public static <K, V> NavigableMap<K, V> filterEntries(NavigableMap<K, V> unfiltered,
			Predicate<? super Entry<K, V>> entryPredicate) {
		Preconditions.checkNotNull(entryPredicate);
		return (NavigableMap) (unfiltered instanceof FilteredEntryNavigableMap
				? filterFiltered((FilteredEntryNavigableMap) unfiltered, entryPredicate)
				: new FilteredEntryNavigableMap((NavigableMap) Preconditions.checkNotNull(unfiltered), entryPredicate));
	}

	public static <K, V> BiMap<K, V> filterEntries(BiMap<K, V> unfiltered,
			Predicate<? super Entry<K, V>> entryPredicate) {
		Preconditions.checkNotNull(unfiltered);
		Preconditions.checkNotNull(entryPredicate);
		return (BiMap) (unfiltered instanceof FilteredEntryBiMap
				? filterFiltered((FilteredEntryBiMap) unfiltered, entryPredicate)
				: new FilteredEntryBiMap(unfiltered, entryPredicate));
	}

	private static <K, V> Map<K, V> filterFiltered(AbstractFilteredMap<K, V> map,
			Predicate<? super Entry<K, V>> entryPredicate) {
		return new FilteredEntryMap(map.unfiltered, Predicates.and(map.predicate, entryPredicate));
	}

	private static <K, V> SortedMap<K, V> filterFiltered(FilteredEntrySortedMap<K, V> map,
			Predicate<? super Entry<K, V>> entryPredicate) {
		Predicate<Entry<K, V>> predicate = Predicates.and(map.predicate, entryPredicate);
		return new FilteredEntrySortedMap(map.sortedMap(), predicate);
	}

	@GwtIncompatible
	private static <K, V> NavigableMap<K, V> filterFiltered(FilteredEntryNavigableMap<K, V> map,
			Predicate<? super Entry<K, V>> entryPredicate) {
		Predicate<Entry<K, V>> predicate = Predicates.and(FilteredEntryNavigableMap.access$500(map), entryPredicate);
		return new FilteredEntryNavigableMap(FilteredEntryNavigableMap.access$600(map), predicate);
	}

	private static <K, V> BiMap<K, V> filterFiltered(FilteredEntryBiMap<K, V> map,
			Predicate<? super Entry<K, V>> entryPredicate) {
		Predicate<Entry<K, V>> predicate = Predicates.and(map.predicate, entryPredicate);
		return new FilteredEntryBiMap(map.unfiltered(), predicate);
	}

	@GwtIncompatible
	public static <K, V> NavigableMap<K, V> unmodifiableNavigableMap(NavigableMap<K, ? extends V> map) {
		Preconditions.checkNotNull(map);
		return (NavigableMap) (map instanceof UnmodifiableNavigableMap ? map : new UnmodifiableNavigableMap(map));
	}

	@NullableDecl
	private static <K, V> Entry<K, V> unmodifiableOrNull(@NullableDecl Entry<K, ? extends V> entry) {
		return entry == null ? null : unmodifiableEntry(entry);
	}

	@GwtIncompatible
	public static <K, V> NavigableMap<K, V> synchronizedNavigableMap(NavigableMap<K, V> navigableMap) {
		return Synchronized.navigableMap(navigableMap);
	}

	static <V> V safeGet(Map<?, V> map, @NullableDecl Object key) {
		Preconditions.checkNotNull(map);

		try {
			return map.get(key);
		} catch (NullPointerException | ClassCastException var3) {
			return null;
		}
	}

	static boolean safeContainsKey(Map<?, ?> map, Object key) {
		Preconditions.checkNotNull(map);

		try {
			return map.containsKey(key);
		} catch (NullPointerException | ClassCastException var3) {
			return false;
		}
	}

	static <V> V safeRemove(Map<?, V> map, Object key) {
		Preconditions.checkNotNull(map);

		try {
			return map.remove(key);
		} catch (NullPointerException | ClassCastException var3) {
			return null;
		}
	}

	static boolean containsKeyImpl(Map<?, ?> map, @NullableDecl Object key) {
		return Iterators.contains(keyIterator(map.entrySet().iterator()), key);
	}

	static boolean containsValueImpl(Map<?, ?> map, @NullableDecl Object value) {
		return Iterators.contains(valueIterator(map.entrySet().iterator()), value);
	}

	static <K, V> boolean containsEntryImpl(Collection<Entry<K, V>> c, Object o) {
		return !(o instanceof Entry) ? false : c.contains(unmodifiableEntry((Entry) o));
	}

	static <K, V> boolean removeEntryImpl(Collection<Entry<K, V>> c, Object o) {
		return !(o instanceof Entry) ? false : c.remove(unmodifiableEntry((Entry) o));
	}

	static boolean equalsImpl(Map<?, ?> map, Object object) {
		if (map == object) {
			return true;
		} else if (object instanceof Map) {
			Map<?, ?> o = (Map) object;
			return map.entrySet().equals(o.entrySet());
		} else {
			return false;
		}
	}

	static String toStringImpl(Map<?, ?> map) {
		StringBuilder sb = Collections2.newStringBuilderForCollection(map.size()).append('{');
		boolean first = true;
		Iterator var3 = map.entrySet().iterator();

		while (var3.hasNext()) {
			Entry<?, ?> entry = (Entry) var3.next();
			if (!first) {
				sb.append(", ");
			}

			first = false;
			sb.append(entry.getKey()).append('=').append(entry.getValue());
		}

		return sb.append('}').toString();
	}

	static <K, V> void putAllImpl(Map<K, V> self, Map<? extends K, ? extends V> map) {
		Iterator var2 = map.entrySet().iterator();

		while (var2.hasNext()) {
			Entry<? extends K, ? extends V> entry = (Entry) var2.next();
			self.put(entry.getKey(), entry.getValue());
		}

	}

	@NullableDecl
	static <K> K keyOrNull(@NullableDecl Entry<K, ?> entry) {
		return entry == null ? null : entry.getKey();
	}

	@NullableDecl
	static <V> V valueOrNull(@NullableDecl Entry<?, V> entry) {
		return entry == null ? null : entry.getValue();
	}

	static <E> ImmutableMap<E, Integer> indexMap(Collection<E> list) {
		Builder<E, Integer> builder = new Builder(list.size());
		int i = 0;
		Iterator var3 = list.iterator();

		while (var3.hasNext()) {
			E e = var3.next();
			builder.put(e, i++);
		}

		return builder.build();
	}

	@Beta
	@GwtIncompatible
	public static <K extends Comparable<? super K>, V> NavigableMap<K, V> subMap(NavigableMap<K, V> map,
			Range<K> range) {
		if (map.comparator() != null && map.comparator() != Ordering.natural() && range.hasLowerBound()
				&& range.hasUpperBound()) {
			Preconditions.checkArgument(map.comparator().compare(range.lowerEndpoint(), range.upperEndpoint()) <= 0,
					"map is using a custom comparator which is inconsistent with the natural ordering.");
		}

		if (range.hasLowerBound() && range.hasUpperBound()) {
			return map.subMap(range.lowerEndpoint(), range.lowerBoundType() == BoundType.CLOSED, range.upperEndpoint(),
					range.upperBoundType() == BoundType.CLOSED);
		} else if (range.hasLowerBound()) {
			return map.tailMap(range.lowerEndpoint(), range.lowerBoundType() == BoundType.CLOSED);
		} else {
			return range.hasUpperBound()
					? map.headMap(range.upperEndpoint(), range.upperBoundType() == BoundType.CLOSED)
					: (NavigableMap) Preconditions.checkNotNull(map);
		}
	}
}