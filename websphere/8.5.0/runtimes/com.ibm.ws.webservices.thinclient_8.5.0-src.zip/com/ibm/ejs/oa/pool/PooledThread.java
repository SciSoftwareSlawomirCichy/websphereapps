package com.ibm.ejs.oa.pool;

import com.ibm.CORBA.iiop.WorkUnit;
import com.ibm.ws.util.ObjectPool;

class PooledThread implements Runnable {
	WorkUnit workUnit;
	ObjectPool pool;

	public PooledThread(ObjectPool owner) {
		this.pool = owner;
	}

	void handleRequest(WorkUnit newWorkUnit) {
		this.workUnit = newWorkUnit;
	}

	public void run() {
		try {
			if (this.workUnit != null) {
				this.workUnit.doWork();
			}
		} finally {
			this.workUnit = null;
			this.pool.add(this);
		}

	}
}