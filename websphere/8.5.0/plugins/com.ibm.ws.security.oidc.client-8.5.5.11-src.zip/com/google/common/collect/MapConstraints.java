package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.MapConstraints.1;
import com.google.common.collect.MapConstraints.2;
import com.google.common.collect.MapConstraints.ConstrainedAsMapEntries;
import com.google.common.collect.MapConstraints.ConstrainedBiMap;
import com.google.common.collect.MapConstraints.ConstrainedEntries;
import com.google.common.collect.MapConstraints.ConstrainedEntrySet;
import com.google.common.collect.MapConstraints.ConstrainedListMultimap;
import com.google.common.collect.MapConstraints.ConstrainedMap;
import com.google.common.collect.MapConstraints.ConstrainedMultimap;
import com.google.common.collect.MapConstraints.ConstrainedSetMultimap;
import com.google.common.collect.MapConstraints.ConstrainedSortedSetMultimap;
import com.google.common.collect.MapConstraints.NotNullMapConstraint;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

@Beta
@GwtCompatible
public final class MapConstraints {
	public static MapConstraint<Object, Object> notNull() {
		return NotNullMapConstraint.INSTANCE;
	}

	public static <K, V> Map<K, V> constrainedMap(Map<K, V> map, MapConstraint<? super K, ? super V> constraint) {
		return new ConstrainedMap(map, constraint);
	}

	public static <K, V> Multimap<K, V> constrainedMultimap(Multimap<K, V> multimap,
			MapConstraint<? super K, ? super V> constraint) {
		return new ConstrainedMultimap(multimap, constraint);
	}

	public static <K, V> ListMultimap<K, V> constrainedListMultimap(ListMultimap<K, V> multimap,
			MapConstraint<? super K, ? super V> constraint) {
		return new ConstrainedListMultimap(multimap, constraint);
	}

	public static <K, V> SetMultimap<K, V> constrainedSetMultimap(SetMultimap<K, V> multimap,
			MapConstraint<? super K, ? super V> constraint) {
		return new ConstrainedSetMultimap(multimap, constraint);
	}

	public static <K, V> SortedSetMultimap<K, V> constrainedSortedSetMultimap(SortedSetMultimap<K, V> multimap,
			MapConstraint<? super K, ? super V> constraint) {
		return new ConstrainedSortedSetMultimap(multimap, constraint);
	}

	private static <K, V> Entry<K, V> constrainedEntry(Entry<K, V> entry, MapConstraint<? super K, ? super V> constraint) {
      Preconditions.checkNotNull(entry);
      Preconditions.checkNotNull(constraint);
      return new 1(entry, constraint);
   }

	private static <K, V> Entry<K, Collection<V>> constrainedAsMapEntry(Entry<K, Collection<V>> entry, MapConstraint<? super K, ? super V> constraint) {
      Preconditions.checkNotNull(entry);
      Preconditions.checkNotNull(constraint);
      return new 2(entry, constraint);
   }

	private static <K, V> Set<Entry<K, Collection<V>>> constrainedAsMapEntries(Set<Entry<K, Collection<V>>> entries,
			MapConstraint<? super K, ? super V> constraint) {
		return new ConstrainedAsMapEntries(entries, constraint);
	}

	private static <K, V> Collection<Entry<K, V>> constrainedEntries(Collection<Entry<K, V>> entries,
			MapConstraint<? super K, ? super V> constraint) {
		return (Collection) (entries instanceof Set
				? constrainedEntrySet((Set) entries, constraint)
				: new ConstrainedEntries(entries, constraint));
	}

	private static <K, V> Set<Entry<K, V>> constrainedEntrySet(Set<Entry<K, V>> entries,
			MapConstraint<? super K, ? super V> constraint) {
		return new ConstrainedEntrySet(entries, constraint);
	}

	public static <K, V> BiMap<K, V> constrainedBiMap(BiMap<K, V> map, MapConstraint<? super K, ? super V> constraint) {
		return new ConstrainedBiMap(map, (BiMap) null, constraint);
	}

	private static <K, V> Collection<V> checkValues(K key, Iterable<? extends V> values,
			MapConstraint<? super K, ? super V> constraint) {
		Collection<V> copy = Lists.newArrayList(values);
		Iterator i$ = copy.iterator();

		while (i$.hasNext()) {
			V value = i$.next();
			constraint.checkKeyValue(key, value);
		}

		return copy;
	}

	private static <K, V> Map<K, V> checkMap(Map<? extends K, ? extends V> map,
			MapConstraint<? super K, ? super V> constraint) {
		Map<K, V> copy = new LinkedHashMap(map);
		Iterator i$ = copy.entrySet().iterator();

		while (i$.hasNext()) {
			Entry<K, V> entry = (Entry) i$.next();
			constraint.checkKeyValue(entry.getKey(), entry.getValue());
		}

		return copy;
	}
}