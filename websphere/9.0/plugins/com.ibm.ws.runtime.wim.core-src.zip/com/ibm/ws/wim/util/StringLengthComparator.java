package com.ibm.ws.wim.util;

import java.io.Serializable;
import java.util.Comparator;

public class StringLengthComparator implements Comparator, Serializable {
	public int compare(Object var1, Object var2) {
		if (var1 instanceof String && var2 instanceof String) {
			String var3 = (String) var1;
			String var4 = (String) var2;
			int var5 = var3.length();
			int var6 = var4.length();
			return var6 - var5;
		} else {
			return 0;
		}
	}
}