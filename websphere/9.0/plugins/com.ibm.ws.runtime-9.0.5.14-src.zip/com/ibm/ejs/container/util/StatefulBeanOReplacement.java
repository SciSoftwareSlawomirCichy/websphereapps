package com.ibm.ejs.container.util;

import java.io.Serializable;

public class StatefulBeanOReplacement implements Serializable {
	private static final long serialVersionUID = -7308408948738957218L;
}