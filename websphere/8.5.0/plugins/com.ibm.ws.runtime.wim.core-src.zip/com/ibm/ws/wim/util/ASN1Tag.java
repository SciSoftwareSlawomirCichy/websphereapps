package com.ibm.ws.wim.util;

public class ASN1Tag {
	public static final int UNIVERSAL_TAG_CLASS = 0;
	public static final int APPLICATION_TAG_CLASS = 1;
	public static final int CONTEXT_TAG_CLASS = 2;
	public static final int PRIVATE_TAG_CLASS = 3;
	public static final int INVALID = 0;
	public static final int BOOLEAN = 1;
	public static final int INTEGER = 2;
	public static final int BITSTRING = 3;
	public static final int OCTETSTRING = 4;
	public static final int NULL = 5;
	public static final int OBJECTIDENTIFIER = 6;
	public static final int OD = 7;
	public static final int EXTERNAL = 8;
	public static final int REAL = 9;
	public static final int ENUMERATION = 10;
	public static final int SEQUENCE = 16;
	public static final int SEQUENCEOF = 16;
	public static final int SET = 17;
	public static final int SETOF = 17;
	public static final int NUMERICSTRING = 18;
	public static final int PRINTABLESTRING = 19;
	public static final int T61STRING = 20;
	public static final int VIDEOTEXSTRING = 21;
	public static final int IA5STRING = 22;
	public static final int UTCTIME = 23;
	public static final int GENERALIZEDTIME = 24;
	public static final int GRAPHICSTRING = 25;
	public static final int VISIBLESTRING = 26;
	public static final int GENERALSTRING = 27;
	public static final int BMPSTRING = 30;
	private static final int TAG_CLASS_SHIFT = 30;
	private static final int TAG_NUMBER_MASK = 1073741823;
	private static final int TAG_CLASS_MASK = -1073741824;
	public static final int MAX_TAG_NUMBER = 1073741823;
	private static final String[] tagClasses = new String[]{"Universal", "Application", "Context", "Private"};
	private static final String[] universalTagNames = new String[]{"End-of-Indefinite-Encoding", "Boolean", "Integer",
			"BitString", "OctetString", "Null", "ObjectIdentifier", "OD", "External", "Real", "Enumeration", "11", "12",
			"13", "14", "15", "Sequence (of)", "Set (of)", "NumericString", "PrintableString", "T61String",
			"TeletexString", "IA5String", "UTCTime", "GeneralizedTime", "GraphicString", "VisibleString",
			"GeneralString"};
	private static long stringTags = 243007512L;

	public static boolean isUniversalStringTag(int var0) {
		if (getTagClass(var0) != 0) {
			throw new IllegalArgumentException("Tag is not a universal tag");
		} else if (var0 >= 64) {
			return false;
		} else {
			return (stringTags & (long) (1 << var0)) != 0L;
		}
	}

	public static int getTagClass(int var0) {
		return var0 >>> 30;
	}

	public static int getTagNumber(int var0) {
		return var0 & 1073741823;
	}

	public static int makeTag(int var0, int var1) {
		if (var1 >= 0 && var1 <= 1073741823) {
			return var0 << 30 | var1;
		} else {
			throw new IllegalArgumentException("Tag number too big");
		}
	}

	public static int makeUniversalTag(int var0) throws Exception {
		return makeTag(0, var0);
	}

	public static int makeContextTag(int var0) throws Exception {
		return makeTag(2, var0);
	}

	public static int makeApplicationTag(int var0) throws Exception {
		return makeTag(1, var0);
	}

	public static String universalTagNumberToString(int var0) {
		if (getTagClass(var0) != 0) {
			throw new IllegalArgumentException("Tag is not a universal tag");
		} else {
			return var0 >= universalTagNames.length ? Integer.toString(var0) : universalTagNames[var0];
		}
	}

	public static String tagClassToString(int var0) {
		return tagClasses[getTagClass(var0)];
	}

	public static String tagToString(int var0) {
		return getTagClass(var0) != 0
				? tagClassToString(var0) + " " + Integer.toString(getTagNumber(var0))
				: tagClassToString(var0) + " " + universalTagNumberToString(var0);
	}
}