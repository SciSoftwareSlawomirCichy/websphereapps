package com.ibm.ejs.container;

public interface WrapperProxy {
}