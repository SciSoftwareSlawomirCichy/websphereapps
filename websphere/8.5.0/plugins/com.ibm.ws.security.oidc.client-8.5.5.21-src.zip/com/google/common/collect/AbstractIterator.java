package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.AbstractIterator.1;
import com.google.common.collect.AbstractIterator.State;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public abstract class AbstractIterator<T> extends UnmodifiableIterator<T> {
	private State state;
	@NullableDecl
	private T next;

	protected AbstractIterator() {
		this.state = State.NOT_READY;
	}

	protected abstract T computeNext();

	@CanIgnoreReturnValue
	protected final T endOfData() {
		this.state = State.DONE;
		return null;
	}

	@CanIgnoreReturnValue
   public final boolean hasNext() {
      Preconditions.checkState(this.state != State.FAILED);
      switch(1.$SwitchMap$com$google$common$collect$AbstractIterator$State[this.state.ordinal()]) {
      case 1:
         return false;
      case 2:
         return true;
      default:
         return this.tryToComputeNext();
      }
   }

	private boolean tryToComputeNext() {
		this.state = State.FAILED;
		this.next = this.computeNext();
		if (this.state != State.DONE) {
			this.state = State.READY;
			return true;
		} else {
			return false;
		}
	}

	@CanIgnoreReturnValue
	public final T next() {
		if (!this.hasNext()) {
			throw new NoSuchElementException();
		} else {
			this.state = State.NOT_READY;
			T result = this.next;
			this.next = null;
			return result;
		}
	}

	public final T peek() {
		if (!this.hasNext()) {
			throw new NoSuchElementException();
		} else {
			return this.next;
		}
	}
}