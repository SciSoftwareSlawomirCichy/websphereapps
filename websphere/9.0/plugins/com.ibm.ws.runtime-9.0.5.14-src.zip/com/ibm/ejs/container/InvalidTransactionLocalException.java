package com.ibm.ejs.container;

public class InvalidTransactionLocalException extends ContainerLocalException {
	private static final long serialVersionUID = -7960288866356505362L;

	public InvalidTransactionLocalException() {
	}

	public InvalidTransactionLocalException(String message) {
		super(message);
	}

	public InvalidTransactionLocalException(String message, Exception ex) {
		super(message, ex);
	}
}