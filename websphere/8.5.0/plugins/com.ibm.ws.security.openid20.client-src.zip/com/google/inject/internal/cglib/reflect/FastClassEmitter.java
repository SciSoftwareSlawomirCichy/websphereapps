package com.google.inject.internal.cglib.reflect;

import com.google.inject.internal.asm.ClassVisitor;
import com.google.inject.internal.asm.Label;
import com.google.inject.internal.asm.Type;
import com.google.inject.internal.cglib.core.Block;
import com.google.inject.internal.cglib.core.ClassEmitter;
import com.google.inject.internal.cglib.core.CodeEmitter;
import com.google.inject.internal.cglib.core.CollectionUtils;
import com.google.inject.internal.cglib.core.Constants;
import com.google.inject.internal.cglib.core.DuplicatesPredicate;
import com.google.inject.internal.cglib.core.EmitUtils;
import com.google.inject.internal.cglib.core.MethodInfoTransformer;
import com.google.inject.internal.cglib.core.ObjectSwitchCallback;
import com.google.inject.internal.cglib.core.ReflectUtils;
import com.google.inject.internal.cglib.core.Signature;
import com.google.inject.internal.cglib.core.TypeUtils;
import com.google.inject.internal.cglib.core.VisibilityPredicate;
import com.google.inject.internal.cglib.reflect.FastClassEmitter.1;
import com.google.inject.internal.cglib.reflect.FastClassEmitter.2;
import com.google.inject.internal.cglib.reflect.FastClassEmitter.3;
import com.google.inject.internal.cglib.reflect.FastClassEmitter.4;
import com.google.inject.internal.cglib.reflect.FastClassEmitter.GetIndexCallback;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class FastClassEmitter extends ClassEmitter {
	private static final Signature CSTRUCT_CLASS = TypeUtils.parseConstructor("Class");
	private static final Signature METHOD_GET_INDEX = TypeUtils.parseSignature("int getIndex(String, Class[])");
	private static final Signature SIGNATURE_GET_INDEX;
	private static final Signature TO_STRING;
	private static final Signature CONSTRUCTOR_GET_INDEX;
	private static final Signature INVOKE;
	private static final Signature NEW_INSTANCE;
	private static final Signature GET_MAX_INDEX;
	private static final Signature GET_SIGNATURE_WITHOUT_RETURN_TYPE;
	private static final Type FAST_CLASS;
	private static final Type ILLEGAL_ARGUMENT_EXCEPTION;
	private static final Type INVOCATION_TARGET_EXCEPTION;
	private static final Type[] INVOCATION_TARGET_EXCEPTION_ARRAY;
	private static final int TOO_MANY_METHODS = 100;

	public FastClassEmitter(ClassVisitor v, String className, Class type) {
		super(v);
		Type base = Type.getType(type);
		this.begin_class(46, 1, className, FAST_CLASS, (Type[]) null, "<generated>");
		CodeEmitter e = this.begin_method(1, CSTRUCT_CLASS, (Type[]) null);
		e.load_this();
		e.load_args();
		e.super_invoke_constructor(CSTRUCT_CLASS);
		e.return_value();
		e.end_method();
		VisibilityPredicate vp = new VisibilityPredicate(type, false);
		List methods = ReflectUtils.addAllMethods(type, new ArrayList());
		CollectionUtils.filter(methods, vp);
		CollectionUtils.filter(methods, new DuplicatesPredicate());
		List constructors = new ArrayList(Arrays.asList(type.getDeclaredConstructors()));
		CollectionUtils.filter(constructors, vp);
		this.emitIndexBySignature(methods);
		this.emitIndexByClassArray(methods);
		e = this.begin_method(1, CONSTRUCTOR_GET_INDEX, (Type[]) null);
		e.load_args();
		List info = CollectionUtils.transform(constructors, MethodInfoTransformer.getInstance());
		EmitUtils.constructor_switch(e, info, new GetIndexCallback(e, info));
		e.end_method();
		e = this.begin_method(1, INVOKE, INVOCATION_TARGET_EXCEPTION_ARRAY);
		e.load_arg(1);
		e.checkcast(base);
		e.load_arg(0);
		invokeSwitchHelper(e, methods, 2, base);
		e.end_method();
		e = this.begin_method(1, NEW_INSTANCE, INVOCATION_TARGET_EXCEPTION_ARRAY);
		e.new_instance(base);
		e.dup();
		e.load_arg(0);
		invokeSwitchHelper(e, constructors, 1, base);
		e.end_method();
		e = this.begin_method(1, GET_MAX_INDEX, (Type[]) null);
		e.push(methods.size() - 1);
		e.return_value();
		e.end_method();
		this.end_class();
	}

	private void emitIndexBySignature(List methods) {
      CodeEmitter e = this.begin_method(1, SIGNATURE_GET_INDEX, (Type[])null);
      List signatures = CollectionUtils.transform(methods, new 1(this));
      e.load_arg(0);
      e.invoke_virtual(Constants.TYPE_OBJECT, TO_STRING);
      this.signatureSwitchHelper(e, signatures);
      e.end_method();
   }

	private void emitIndexByClassArray(List methods) {
      CodeEmitter e = this.begin_method(1, METHOD_GET_INDEX, (Type[])null);
      List signatures;
      if (methods.size() > 100) {
         signatures = CollectionUtils.transform(methods, new 2(this));
         e.load_args();
         e.invoke_static(FAST_CLASS, GET_SIGNATURE_WITHOUT_RETURN_TYPE);
         this.signatureSwitchHelper(e, signatures);
      } else {
         e.load_args();
         signatures = CollectionUtils.transform(methods, MethodInfoTransformer.getInstance());
         EmitUtils.method_switch(e, signatures, new GetIndexCallback(e, signatures));
      }

      e.end_method();
   }

	private void signatureSwitchHelper(CodeEmitter e, List signatures) {
      ObjectSwitchCallback callback = new 3(this, e, signatures);
      EmitUtils.string_switch(e, (String[])((String[])signatures.toArray(new String[signatures.size()])), 1, callback);
   }

	private static void invokeSwitchHelper(CodeEmitter e, List members, int arg, Type base) {
      List info = CollectionUtils.transform(members, MethodInfoTransformer.getInstance());
      Label illegalArg = e.make_label();
      Block block = e.begin_block();
      e.process_switch(getIntRange(info.size()), new 4(info, e, arg, base, illegalArg));
      block.end();
      EmitUtils.wrap_throwable(block, INVOCATION_TARGET_EXCEPTION);
      e.mark(illegalArg);
      e.throw_exception(ILLEGAL_ARGUMENT_EXCEPTION, "Cannot find matching method/constructor");
   }

	private static int[] getIntRange(int length) {
		int[] range = new int[length];

		for (int i = 0; i < length; range[i] = i++) {
			;
		}

		return range;
	}

	static {
		SIGNATURE_GET_INDEX = new Signature("getIndex", Type.INT_TYPE, new Type[]{Constants.TYPE_SIGNATURE});
		TO_STRING = TypeUtils.parseSignature("String toString()");
		CONSTRUCTOR_GET_INDEX = TypeUtils.parseSignature("int getIndex(Class[])");
		INVOKE = TypeUtils.parseSignature("Object invoke(int, Object, Object[])");
		NEW_INSTANCE = TypeUtils.parseSignature("Object newInstance(int, Object[])");
		GET_MAX_INDEX = TypeUtils.parseSignature("int getMaxIndex()");
		GET_SIGNATURE_WITHOUT_RETURN_TYPE = TypeUtils
				.parseSignature("String getSignatureWithoutReturnType(String, Class[])");
		FAST_CLASS = TypeUtils.parseType("com.google.inject.internal.cglib.reflect.FastClass");
		ILLEGAL_ARGUMENT_EXCEPTION = TypeUtils.parseType("IllegalArgumentException");
		INVOCATION_TARGET_EXCEPTION = TypeUtils.parseType("java.lang.reflect.InvocationTargetException");
		INVOCATION_TARGET_EXCEPTION_ARRAY = new Type[]{INVOCATION_TARGET_EXCEPTION};
	}
}