package com.ibm.ejs.cm.pool;

import java.io.PrintWriter;
import java.sql.SQLException;

public interface ConnectionFactory {
	ConnectO createConnection(ConnectionPool var1) throws SQLException;

	ConnectO createConnection(ConnectionPool var1, String var2, String var3) throws SQLException;

	PrintWriter getLogWriter() throws SQLException;

	void setLogWriter(PrintWriter var1) throws SQLException;

	int getLoginTimeout(int var1) throws SQLException;

	void setLoginTimeout(int var1) throws SQLException;
}