package com.google.inject.spi;

import com.google.inject.Binding;

public interface UntargettedBinding<T> extends Binding<T> {
}