package com.ibm.icu.impl.duration.impl;

import com.ibm.icu.impl.duration.impl.DataRecord.EDecimalHandling;
import com.ibm.icu.impl.duration.impl.DataRecord.EFractionHandling;
import com.ibm.icu.impl.duration.impl.DataRecord.EGender;
import com.ibm.icu.impl.duration.impl.DataRecord.EHalfPlacement;
import com.ibm.icu.impl.duration.impl.DataRecord.EHalfSupport;
import com.ibm.icu.impl.duration.impl.DataRecord.EMilliSupport;
import com.ibm.icu.impl.duration.impl.DataRecord.ENumberSystem;
import com.ibm.icu.impl.duration.impl.DataRecord.EPluralization;
import com.ibm.icu.impl.duration.impl.DataRecord.EZeroHandling;
import com.ibm.icu.impl.duration.impl.DataRecord.ScopeData;
import java.util.ArrayList;

public class DataRecord {
	byte pl;
	String[][] pluralNames;
	byte[] genders;
	String[] singularNames;
	String[] halfNames;
	String[] numberNames;
	String[] mediumNames;
	String[] shortNames;
	String[] measures;
	String[] rqdSuffixes;
	String[] optSuffixes;
	String[] halves;
	byte[] halfPlacements;
	byte[] halfSupport;
	String fifteenMinutes;
	String fiveMinutes;
	boolean requiresDigitSeparator;
	String digitPrefix;
	String countSep;
	String shortUnitSep;
	String[] unitSep;
	boolean[] unitSepRequiresDP;
	boolean[] requiresSkipMarker;
	byte numberSystem;
	char zero;
	char decimalSep;
	boolean omitSingularCount;
	boolean omitDualCount;
	byte zeroHandling;
	byte decimalHandling;
	byte fractionHandling;
	String skippedUnitMarker;
	boolean allowZero;
	boolean weeksAloneOnly;
	byte useMilliseconds;
	ScopeData[] scopeData;

	public static DataRecord read(String ln, RecordReader in) {
		if (!in.open("DataRecord")) {
			throw new InternalError("did not find DataRecord while reading " + ln);
		} else {
			DataRecord record = new DataRecord();
			record.pl = in.namedIndex("pl", EPluralization.names);
			record.pluralNames = in.stringTable("pluralName");
			record.genders = in.namedIndexArray("gender", EGender.names);
			record.singularNames = in.stringArray("singularName");
			record.halfNames = in.stringArray("halfName");
			record.numberNames = in.stringArray("numberName");
			record.mediumNames = in.stringArray("mediumName");
			record.shortNames = in.stringArray("shortName");
			record.measures = in.stringArray("measure");
			record.rqdSuffixes = in.stringArray("rqdSuffix");
			record.optSuffixes = in.stringArray("optSuffix");
			record.halves = in.stringArray("halves");
			record.halfPlacements = in.namedIndexArray("halfPlacement", EHalfPlacement.names);
			record.halfSupport = in.namedIndexArray("halfSupport", EHalfSupport.names);
			record.fifteenMinutes = in.string("fifteenMinutes");
			record.fiveMinutes = in.string("fiveMinutes");
			record.requiresDigitSeparator = in.bool("requiresDigitSeparator");
			record.digitPrefix = in.string("digitPrefix");
			record.countSep = in.string("countSep");
			record.shortUnitSep = in.string("shortUnitSep");
			record.unitSep = in.stringArray("unitSep");
			record.unitSepRequiresDP = in.boolArray("unitSepRequiresDP");
			record.requiresSkipMarker = in.boolArray("requiresSkipMarker");
			record.numberSystem = in.namedIndex("numberSystem", ENumberSystem.names);
			record.zero = in.character("zero");
			record.decimalSep = in.character("decimalSep");
			record.omitSingularCount = in.bool("omitSingularCount");
			record.omitDualCount = in.bool("omitDualCount");
			record.zeroHandling = in.namedIndex("zeroHandling", EZeroHandling.names);
			record.decimalHandling = in.namedIndex("decimalHandling", EDecimalHandling.names);
			record.fractionHandling = in.namedIndex("fractionHandling", EFractionHandling.names);
			record.skippedUnitMarker = in.string("skippedUnitMarker");
			record.allowZero = in.bool("allowZero");
			record.weeksAloneOnly = in.bool("weeksAloneOnly");
			record.useMilliseconds = in.namedIndex("useMilliseconds", EMilliSupport.names);
			if (in.open("ScopeDataList")) {
				ArrayList list = new ArrayList();

				ScopeData data;
				while (null != (data = ScopeData.read(in))) {
					list.add(data);
				}

				if (in.close()) {
					record.scopeData = (ScopeData[]) list.toArray(new ScopeData[list.size()]);
				}
			}

			if (in.close()) {
				return record;
			} else {
				throw new InternalError("null data read while reading " + ln);
			}
		}
	}

	public void write(RecordWriter out) {
		out.open("DataRecord");
		out.namedIndex("pl", EPluralization.names, this.pl);
		out.stringTable("pluralName", this.pluralNames);
		out.namedIndexArray("gender", EGender.names, this.genders);
		out.stringArray("singularName", this.singularNames);
		out.stringArray("halfName", this.halfNames);
		out.stringArray("numberName", this.numberNames);
		out.stringArray("mediumName", this.mediumNames);
		out.stringArray("shortName", this.shortNames);
		out.stringArray("measure", this.measures);
		out.stringArray("rqdSuffix", this.rqdSuffixes);
		out.stringArray("optSuffix", this.optSuffixes);
		out.stringArray("halves", this.halves);
		out.namedIndexArray("halfPlacement", EHalfPlacement.names, this.halfPlacements);
		out.namedIndexArray("halfSupport", EHalfSupport.names, this.halfSupport);
		out.string("fifteenMinutes", this.fifteenMinutes);
		out.string("fiveMinutes", this.fiveMinutes);
		out.bool("requiresDigitSeparator", this.requiresDigitSeparator);
		out.string("digitPrefix", this.digitPrefix);
		out.string("countSep", this.countSep);
		out.string("shortUnitSep", this.shortUnitSep);
		out.stringArray("unitSep", this.unitSep);
		out.boolArray("unitSepRequiresDP", this.unitSepRequiresDP);
		out.boolArray("requiresSkipMarker", this.requiresSkipMarker);
		out.namedIndex("numberSystem", ENumberSystem.names, this.numberSystem);
		out.character("zero", this.zero);
		out.character("decimalSep", this.decimalSep);
		out.bool("omitSingularCount", this.omitSingularCount);
		out.bool("omitDualCount", this.omitDualCount);
		out.namedIndex("zeroHandling", EZeroHandling.names, this.zeroHandling);
		out.namedIndex("decimalHandling", EDecimalHandling.names, this.decimalHandling);
		out.namedIndex("fractionHandling", EFractionHandling.names, this.fractionHandling);
		out.string("skippedUnitMarker", this.skippedUnitMarker);
		out.bool("allowZero", this.allowZero);
		out.bool("weeksAloneOnly", this.weeksAloneOnly);
		out.namedIndex("useMilliseconds", EMilliSupport.names, this.useMilliseconds);
		if (this.scopeData != null) {
			out.open("ScopeDataList");

			for (int i = 0; i < this.scopeData.length; ++i) {
				this.scopeData[i].write(out);
			}

			out.close();
		}

		out.close();
	}
}