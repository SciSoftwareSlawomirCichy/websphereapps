package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.Transaction.UOWCallback;
import com.ibm.ws.Transaction.UOWCoordinator;

public class RunUnderUOWCallback implements UOWCallback {
	private static final String CLASS_NAME = RunUnderUOWCallback.class.getName();
	private static final TraceComponent tc;

	public void contextChange(int typeOfChange, UOWCoordinator UOW) throws IllegalStateException {
		EJSDeployedSupport s = EJSContainer.getMethodContext();
		if (s != null) {
			switch (typeOfChange) {
				case 1 :
					++s.ivRunUnderUOW;
					break;
				case 3 :
					--s.ivRunUnderUOW;
					break;
				default :
					throw new IllegalStateException(
							"Illegal type of change for runUnderUOW callback : " + this.getTypeString(typeOfChange));
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "contextChange : " + this.getTypeString(typeOfChange) + " : "
					+ (s == null ? null : "depth=" + s.ivRunUnderUOW + ", " + s));
		}

	}

	private String getTypeString(int typeOfChange) {
		switch (typeOfChange) {
			case 0 :
				return "PRE_BEGIN";
			case 1 :
				return "POST_BEGIN";
			case 2 :
				return "PRE_END";
			case 3 :
				return "POST_END";
			default :
				return "UNKNOWN";
		}
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}