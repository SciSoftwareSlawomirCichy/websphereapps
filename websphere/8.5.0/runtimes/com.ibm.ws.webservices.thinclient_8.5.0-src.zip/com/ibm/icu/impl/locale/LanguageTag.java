package com.ibm.icu.impl.locale;

import com.ibm.icu.impl.locale.AsciiUtil.CaseInsensitiveKey;
import com.ibm.icu.impl.locale.LanguageTag.ParseStatus;
import com.ibm.icu.impl.locale.LanguageTag.Parser;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;

public class LanguageTag {
	private static final boolean JDKIMPL = false;
	public static final String SEP = "-";
	public static final String PRIVATEUSE = "x";
	public static String UNDETERMINED = "und";
	private static final String JAVAVARIANT = "variant";
	private static final String JAVASEP = "_";
	private static final SortedMap<Character, Extension> EMPTY_EXTENSION_MAP = new TreeMap();
	public static final Parser DEFAULT_PARSER = new Parser(false);
	public static final Parser JAVA_VARIANT_COMPATIBLE_PARSER = new Parser(true);
	private String _grandfathered = "";
	private String _language = "";
	private String _script = "";
	private String _region = "";
	private String _privateuse = "";
	private List<String> _extlangs = Collections.emptyList();
	private List<String> _variants = Collections.emptyList();
	private SortedMap<Character, Extension> _extensions;
	private boolean _javaCompatVariants;
	private static final Map<CaseInsensitiveKey, String[]> GRANDFATHERED = new HashMap();

	private LanguageTag() {
		this._extensions = EMPTY_EXTENSION_MAP;
		this._javaCompatVariants = false;
	}

	public String getLanguage() {
		return this._language;
	}

	public List<String> getExtlangs() {
		return Collections.unmodifiableList(this._extlangs);
	}

	public String getScript() {
		return this._script;
	}

	public String getRegion() {
		return this._region;
	}

	public List<String> getVariants() {
		return Collections.unmodifiableList(this._variants);
	}

	public SortedMap<Character, Extension> getExtensions() {
		return Collections.unmodifiableSortedMap(this._extensions);
	}

	public String getPrivateuse() {
		return this._privateuse;
	}

	public String getGrandfathered() {
		return this._grandfathered;
	}

	private String getJavaVariant() {
		StringBuilder buf = new StringBuilder();

		String var;
		for (Iterator i$ = this._variants.iterator(); i$.hasNext(); buf.append(var)) {
			var = (String) i$.next();
			if (buf.length() > 0) {
				buf.append("_");
			}
		}

		if (this._javaCompatVariants) {
			return getJavaCompatibleVariant(buf.toString(), this._privateuse);
		} else {
			return buf.toString();
		}
	}

	private String getJavaPrivateuse() {
		return this._javaCompatVariants ? getJavaCompatiblePrivateuse(this._privateuse) : this._privateuse;
	}

	static String getJavaCompatibleVariant(String bcpVariants, String bcpPrivuse) {
		StringBuilder buf = new StringBuilder(bcpVariants);
		if (bcpPrivuse.length() > 0) {
			int idx = true;
			int idx;
			if (bcpPrivuse.startsWith("variant-")) {
				idx = "variant-".length();
			} else {
				idx = bcpPrivuse.indexOf("-variant-");
				if (idx != -1) {
					idx += "-variant-".length();
				}
			}

			if (idx != -1) {
				if (buf.length() != 0) {
					buf.append("_");
				}

				buf.append(bcpPrivuse.substring(idx).replace("-", "_"));
			}
		}

		return buf.toString();
	}

	static String getJavaCompatiblePrivateuse(String bcpPrivuse) {
		if (bcpPrivuse.length() > 0) {
			int idx = true;
			int idx;
			if (bcpPrivuse.startsWith("variant-")) {
				idx = 0;
			} else {
				idx = bcpPrivuse.indexOf("-variant-");
			}

			if (idx != -1) {
				return bcpPrivuse.substring(0, idx);
			}
		}

		return bcpPrivuse;
	}

	public BaseLocale getBaseLocale() {
		String lang = this._language;
		if (this._extlangs.size() > 0) {
			lang = (String) this._extlangs.get(0);
		}

		if (lang.equals(UNDETERMINED)) {
			lang = "";
		}

		return BaseLocale.getInstance(lang, this._script, this._region, this.getJavaVariant());
	}

	public LocaleExtensions getLocaleExtensions() {
		String javaPrivuse = this.getJavaPrivateuse();
		if (this._extensions == null && javaPrivuse.length() == 0) {
			return LocaleExtensions.EMPTY_EXTENSIONS;
		} else {
			SortedMap<Character, Extension> exts = new TreeMap();
			if (this._extensions != null) {
				exts.putAll(this._extensions);
			}

			if (javaPrivuse.length() > 0) {
				PrivateuseExtension pext = new PrivateuseExtension(javaPrivuse);
				exts.put('x', pext);
			}

			return LocaleExtensions.getInstance(exts);
		}
	}

	public String getID() {
		if (this._grandfathered.length() > 0) {
			return this._grandfathered;
		} else {
			StringBuilder buf = new StringBuilder();
			if (this._language.length() > 0) {
				buf.append(this._language);
				Iterator i$;
				String var;
				if (this._extlangs.size() > 0) {
					i$ = this._extlangs.iterator();

					while (i$.hasNext()) {
						var = (String) i$.next();
						buf.append("-");
						buf.append(var);
					}
				}

				if (this._script.length() > 0) {
					buf.append("-");
					buf.append(this._script);
				}

				if (this._region.length() > 0) {
					buf.append("-");
					buf.append(this._region);
				}

				if (this._variants.size() > 0) {
					i$ = this._variants.iterator();

					while (i$.hasNext()) {
						var = (String) i$.next();
						buf.append("-");
						buf.append(var);
					}
				}

				if (this._extensions.size() > 0) {
					Set<Entry<Character, Extension>> exts = this._extensions.entrySet();
					Iterator i$ = exts.iterator();

					while (i$.hasNext()) {
						Entry<Character, Extension> ext = (Entry) i$.next();
						buf.append("-");
						buf.append(ext.getKey());
						buf.append("-");
						buf.append(((Extension) ext.getValue()).getValue());
					}
				}
			}

			if (this._privateuse.length() > 0) {
				if (buf.length() > 0) {
					buf.append("-");
				}

				buf.append("x");
				buf.append("-");
				buf.append(this._privateuse);
			}

			return buf.toString();
		}
	}

	public String toString() {
		return this.getID();
	}

	public static boolean isLanguage(String s) {
		return s.length() >= 2 && s.length() <= 8 && AsciiUtil.isAlphaString(s);
	}

	public static boolean isExtlang(String s) {
		return s.length() == 3 && AsciiUtil.isAlphaString(s);
	}

	public static boolean isScript(String s) {
		return s.length() == 4 && AsciiUtil.isAlphaString(s);
	}

	public static boolean isRegion(String s) {
		return s.length() == 2 && AsciiUtil.isAlphaString(s) || s.length() == 3 && AsciiUtil.isNumericString(s);
	}

	public static boolean isVariant(String s) {
		int len = s.length();
		if (len >= 5 && len <= 8) {
			return AsciiUtil.isAlphaNumericString(s);
		} else if (len != 4) {
			return false;
		} else {
			return AsciiUtil.isNumeric(s.charAt(0)) && AsciiUtil.isAlphaNumeric(s.charAt(1))
					&& AsciiUtil.isAlphaNumeric(s.charAt(2)) && AsciiUtil.isAlphaNumeric(s.charAt(3));
		}
	}

	public static boolean isExtensionSingleton(String s) {
		return s.length() == 1 && AsciiUtil.isAlphaString(s) && !AsciiUtil.caseIgnoreMatch("x", s);
	}

	public static boolean isExtensionSubtag(String s) {
		return s.length() >= 2 && s.length() <= 8 && AsciiUtil.isAlphaNumericString(s);
	}

	public static boolean isPrivateuseSingleton(String s) {
		return s.length() == 1 && AsciiUtil.caseIgnoreMatch("x", s);
	}

	public static boolean isPrivateuseSubtag(String s) {
		return s.length() >= 1 && s.length() <= 8 && AsciiUtil.isAlphaNumericString(s);
	}

	public static String canonicalizeLanguage(String s) {
		return AsciiUtil.toLowerString(s);
	}

	public static String canonicalizeExtlang(String s) {
		return AsciiUtil.toLowerString(s);
	}

	public static String canonicalizeScript(String s) {
		return AsciiUtil.toTitleString(s);
	}

	public static String canonicalizeRegion(String s) {
		return AsciiUtil.toUpperString(s);
	}

	public static String canonicalizeVariant(String s) {
		return AsciiUtil.toLowerString(s);
	}

	public static String canonicalizeExtensionSingleton(String s) {
		return AsciiUtil.toLowerString(s);
	}

	public static String canonicalizeExtensionSubtag(String s) {
		return AsciiUtil.toLowerString(s);
	}

	public static String canonicalizePrivateuseSubtag(String s) {
		return AsciiUtil.toLowerString(s);
	}

	public static LanguageTag parse(String str, boolean javaCompatVar) {
		LanguageTag tag = new LanguageTag();
		tag.parseString(str, javaCompatVar);
		return tag;
	}

	public static LanguageTag parseStrict(String str, boolean javaCompatVar) throws LocaleSyntaxException {
		LanguageTag tag = new LanguageTag();
		ParseStatus sts = tag.parseString(str, javaCompatVar);
		if (sts.isError()) {
			throw new LocaleSyntaxException(sts.errorMsg, sts.errorIndex);
		} else {
			return tag;
		}
	}

	public static LanguageTag parseLocale(BaseLocale base, LocaleExtensions locExts) {
		LanguageTag tag = new LanguageTag();
		tag._javaCompatVariants = true;
		String language = base.getLanguage();
		String script = base.getScript();
		String region = base.getRegion();
		String variant = base.getVariant();
		String privuseVar = null;
		if (language.length() > 0 && isLanguage(language)) {
			language = canonicalizeLanguage(language);
			if (language.equals("iw")) {
				language = "he";
			} else if (language.equals("ji")) {
				language = "yi";
			} else if (language.equals("in")) {
				language = "id";
			}

			tag._language = language;
		}

		if (script.length() > 0 && isScript(script)) {
			tag._script = canonicalizeScript(script);
		}

		if (region.length() > 0 && isRegion(region)) {
			tag._region = canonicalizeRegion(region);
		}

		if (variant.length() > 0) {
			List<String> variants = null;
			StringTokenIterator varitr = new StringTokenIterator(variant, "_");

			while (!varitr.isDone()) {
				String var = varitr.current();
				if (!isVariant(var)) {
					break;
				}

				if (variants == null) {
					variants = new ArrayList();
				}

				variants.add(canonicalizeVariant(var));
				varitr.next();
			}

			if (variants != null) {
				tag._variants = variants;
			}

			if (!varitr.isDone()) {
				StringBuilder buf = new StringBuilder();

				while (!varitr.isDone()) {
					String prvv = varitr.current();
					if (!isPrivateuseSubtag(prvv)) {
						break;
					}

					if (buf.length() > 0) {
						buf.append("-");
					}

					prvv = AsciiUtil.toLowerString(prvv);
					buf.append(prvv);
					varitr.next();
				}

				if (buf.length() > 0) {
					privuseVar = buf.toString();
				}
			}
		}

		TreeMap<Character, Extension> extensions = null;
		String privateuse = null;
		Set<Character> locextKeys = locExts.getKeys();
		Iterator i$ = locextKeys.iterator();

		while (i$.hasNext()) {
			Character locextKey = (Character) i$.next();
			Extension ext = locExts.getExtension(locextKey);
			if (ext instanceof PrivateuseExtension) {
				privateuse = ext.getValue();
			} else {
				if (extensions == null) {
					extensions = new TreeMap();
				}

				extensions.put(locextKey, ext);
			}
		}

		if (extensions != null) {
			tag._extensions = extensions;
		}

		if (privuseVar != null) {
			if (privateuse == null) {
				privateuse = "variant-" + privuseVar;
			} else {
				privateuse = privateuse + "-" + "variant" + "-" + privuseVar.replace("_", "-");
			}
		}

		if (privateuse != null) {
			tag._privateuse = privateuse;
		} else if (tag._language.length() == 0) {
			tag._language = UNDETERMINED;
		}

		return tag;
	}

	private ParseStatus parseString(String str, boolean javaCompatVar) {
		String[] gfmap = (String[]) GRANDFATHERED.get(new CaseInsensitiveKey(str));
		ParseStatus sts;
		if (gfmap != null) {
			this._grandfathered = gfmap[0];
			sts = this.parseLanguageTag(gfmap[1], javaCompatVar);
			sts.parseLength = str.length();
		} else {
			this._grandfathered = "";
			sts = this.parseLanguageTag(str, javaCompatVar);
		}

		return sts;
	}

	private ParseStatus parseLanguageTag(String langtag, boolean javaCompat) {
		ParseStatus sts = new ParseStatus();
		StringTokenIterator itr = new StringTokenIterator(langtag, "-");
		Parser parser = javaCompat ? JAVA_VARIANT_COMPATIBLE_PARSER : DEFAULT_PARSER;
		this._javaCompatVariants = javaCompat;
		this._language = parser.parseLanguage(itr, sts);
		if (this._language.length() > 0) {
			this._extlangs = parser.parseExtlangs(itr, sts);
			this._script = parser.parseScript(itr, sts);
			this._region = parser.parseRegion(itr, sts);
			this._variants = parser.parseVariants(itr, sts);
			this._extensions = parser.parseExtensions(itr, sts);
		}

		this._privateuse = parser.parsePrivateuse(itr, sts);
		if (!itr.isDone() && !sts.isError()) {
			String s = itr.current();
			sts.errorIndex = itr.currentStart();
			if (s.length() == 0) {
				sts.errorMsg = "Empty subtag";
			} else {
				sts.errorMsg = "Invalid subtag: " + s;
			}
		}

		return sts;
	}

	static {
		String[][] entries = new String[][]{{"art-lojban", "jbo"}, {"cel-gaulish", "cel-gaulish"},
				{"en-GB-oed", "en-GB"}, {"i-ami", "ami"}, {"i-bnn", "bnn"}, {"i-default", UNDETERMINED},
				{"i-enochian", UNDETERMINED}, {"i-hak", "hak"}, {"i-klingon", "tlh"}, {"i-lux", "lb"},
				{"i-mingo", UNDETERMINED}, {"i-navajo", "nv"}, {"i-pwn", "pwn"}, {"i-tao", "tao"}, {"i-tay", "tay"},
				{"i-tsu", "tsu"}, {"no-bok", "nb"}, {"no-nyn", "nn"}, {"sgn-BE-FR", "sfb"}, {"sgn-BE-NL", "vgt"},
				{"sgn-CH-DE", "sgg"}, {"zh-guoyu", "cmn"}, {"zh-hakka", "hak"}, {"zh-min", "zh"}, {"zh-min-nan", "nan"},
				{"zh-xiang", "hsn"}};
		String[][] arr$ = entries;
		int len$ = entries.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			String[] e = arr$[i$];
			GRANDFATHERED.put(new CaseInsensitiveKey(e[0]), e);
		}

	}
}