package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.util.AccessController;
import com.ibm.ws.ssl.config.FIPSUtils.1;
import com.ibm.ws.ssl.core.Constants;
import java.security.Security;
import java.util.ArrayList;
import java.util.List;

public class FIPSUtils {
	static TraceComponent tc = Tr.register(FIPSUtils.class, "SSL", "com.ibm.ws.ssl.resources.sslCommandTask");

	public static boolean checkFipsEnabled() {
      if (tc.isEntryEnabled()) {
         Tr.entry(tc, "checkFipsEnabled");
      }

      boolean fipsEnabled = false;
      String useFIPS = (String)AccessController.doPrivileged(new 1());
      if (useFIPS != null && useFIPS.equalsIgnoreCase("true")) {
         fipsEnabled = true;
      }

      if (tc.isEntryEnabled()) {
         Tr.exit(tc, "fipsEnabled", fipsEnabled);
      }

      return fipsEnabled;
   }

	public static String checkFipsLevel() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkFipsLevel");
		}

		String fipsLevel = "";
		fipsLevel = SSLConfigManager.getInstance().getGlobalProperty("com.ibm.websphere.security.FIPSLevel");
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "checkFipsLevel", fipsLevel);
		}

		return fipsLevel;
	}

	public static String checkSuiteBLevel() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "checkSuiteBLevel");
		}

		String suiteBLevel = "";
		suiteBLevel = SSLConfigManager.getInstance().getGlobalProperty("com.ibm.websphere.security.suiteb");
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "checkFipsLevel", suiteBLevel);
		}

		return suiteBLevel;
	}

	public static int getFipsSecurityMode() {
		return getFipsSecurityMode(checkFipsEnabled(), checkFipsLevel(), checkSuiteBLevel());
	}

	public static int getFipsSecurityMode(boolean fipsEnabled, String fipsLevel, String suiteBLevel) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getFipsSecurityMode fipsEnabled=" + fipsEnabled + " fipsLevel=" + fipsLevel + " suiteBLevel="
					+ suiteBLevel);
		}

		int securityMode = 0;
		if (fipsEnabled) {
			securityMode = 1;
			if (fipsLevel != null && !fipsLevel.isEmpty()) {
				if (fipsLevel.equalsIgnoreCase("FIPS140-2")) {
					securityMode = 1;
				} else if (fipsLevel.equalsIgnoreCase("transition")) {
					securityMode = 2;
				} else if (fipsLevel.equalsIgnoreCase("SP800-131")) {
					securityMode = 3;
				}
			} else if (suiteBLevel != null && suiteBLevel.equalsIgnoreCase("128")) {
				securityMode = 4;
			} else if (suiteBLevel != null && suiteBLevel.equalsIgnoreCase("192")) {
				securityMode = 5;
			} else if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Invalid suiteBlevel=" + suiteBLevel + " is specified. Ignoring");
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "initFipsecurityMode", Constants.securityModeName[securityMode]);
		}

		return securityMode;
	}

	public static void setJavaPropsForFips(boolean fipsEnabled, String fipsLevel, String suiteBLevel) {
		setJavaPropsForPostFips800_131(fipsEnabled, fipsLevel, suiteBLevel);
	}

	public static void setJavaPropsForPreFips800_131(boolean fipsEnabled) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setJavaPropsForPreFips800_131");
		}

		if (fipsEnabled) {
			Security.setProperty("USEFIPS_ENABLED", "true");
			Security.setProperty("com.ibm.websphere.security.fips.enabled", "true");
		} else {
			Security.setProperty("USEFIPS_ENABLED", "false");
			Security.setProperty("com.ibm.websphere.security.fips.enabled", "false");
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setJavaPropsForPreFips800-131");
		}

	}

	public static void setJavaPropsForPostFips800_131(boolean fipsEnabled, String fipsLevel, String suiteBLevel) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setJavaPropsForPostFips800-131");
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "First, clear Java System Properties that are FIPS related");
		}

		setJavaSystemProperty("com.ibm.jsse2.usefipsprovider", "false");
		setJavaSystemProperty("com.ibm.jsse2.sp800-131", "");
		setJavaSystemProperty("com.ibm.jsse2.suiteB", "");
		int securityMode = getFipsSecurityMode(fipsEnabled, fipsLevel, suiteBLevel);
		if (securityMode != 0) {
			if (securityMode == 1) {
				setJavaPropsForPreFips800_131(fipsEnabled);
				setJavaSystemProperty("com.ibm.jsse2.usefipsprovider", "true");
			} else if (securityMode == 2) {
				setJavaSystemProperty("com.ibm.jsse2.sp800-131", "transition");
				setJavaSystemProperty("com.ibm.jsse2.suiteB", "false");
			} else if (securityMode == 3) {
				setJavaSystemProperty("com.ibm.jsse2.sp800-131", "strict");
				setJavaSystemProperty("com.ibm.jsse2.suiteB", "false");
			} else if (securityMode == 4) {
				setJavaSystemProperty("com.ibm.jsse2.suiteB", "128");
			} else if (securityMode == 5) {
				setJavaSystemProperty("com.ibm.jsse2.suiteB", "192");
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setJavaPropsForPostFips800-131");
		}

	}

	public static boolean isFips140_2Enabled(boolean fipsEnabled, String fipsLevel, String suiteBLevel) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isFips140_2Enabled");
		}

		boolean isFips140_2Enabled = false;
		int securityMode = getFipsSecurityMode(fipsEnabled, fipsLevel, suiteBLevel);
		if (securityMode == 1) {
			isFips140_2Enabled = true;
		}

		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isFips140_2Enabled", isFips140_2Enabled);
		}

		return isFips140_2Enabled;
	}

	protected static void setSecurityProviders(boolean fipsEnabled, String fipsLevel, String suiteBLevel) {
		boolean fips140_2Enabled = isFips140_2Enabled(fipsEnabled, fipsLevel, suiteBLevel);
		if (fips140_2Enabled) {
			Security.setProperty("DEFAULT_JCE_PROVIDER", "IBMJCEFIPS");
		} else {
			Security.setProperty("DEFAULT_JCE_PROVIDER", "IBMJCE");
		}

		Security.setProperty("com.ibm.websphere.security.fips.jsseProviders", "IBMJSSE2");
		Security.setProperty("com.ibm.websphere.security.fips.jceProviders", "IBMJCEFIPS");
	}

	public static List<String> getProtocolTypes(boolean fipsEnabled, String fipsLevel, String suiteBLevel) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProtocolTypes");
		}

		List<String> protocolTypes = new ArrayList();
		int securityMode = getFipsSecurityMode(fipsEnabled, fipsLevel, suiteBLevel);
		if (securityMode <= 0) {
			protocolTypes = Constants.ALL_PROTOCOLS;
		} else if (securityMode == 1) {
			protocolTypes = Constants.FIPS_140_2_PROTOCOLS;
		} else if (securityMode == 2) {
			protocolTypes = Constants.TLS_PROTOCOLS;
		} else if (2 < securityMode && securityMode <= 5) {
			protocolTypes = Constants.FIPS_STRICT_PROTOCOLS;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getProtocolTypes", protocolTypes);
		}

		return (List) protocolTypes;
	}

	public static List<String> getSignatureAlgorithms(boolean fipsEnabled, String fipsLevel, String suiteBLevel) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getSignatureAlgorithms");
		}

		List<String> signatureAlgorithms = new ArrayList();
		int securityMode = getFipsSecurityMode(fipsEnabled, fipsLevel, suiteBLevel);
		if (securityMode != 0 && securityMode != 2) {
			if (securityMode == 1) {
				signatureAlgorithms = Constants.FIPS_140_2_SIGNATURE_ALGORITHMS;
			} else if (securityMode == 3) {
				signatureAlgorithms = Constants.FIPS_STRICT_ALGORITHMS;
			} else if (securityMode == 4) {
				signatureAlgorithms = Constants.FIPS_SUITEB_128_192_ALGORITHMS;
			} else if (securityMode == 5) {
				signatureAlgorithms = Constants.FIPS_SUITEB_192_ALGORITHMS;
			}
		} else {
			signatureAlgorithms = Constants.ALL_SIGNATURE_ALGORITHMS;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getSignatureAlgorithms", signatureAlgorithms);
		}

		return (List) signatureAlgorithms;
	}

	public static String getKeyTypeFromSignatureAlgorithm(String signatureAlgorithm) {
		return (String) Constants.signatureAlgorithmToKeyType.get(signatureAlgorithm);
	}

	public static int getMinimumSupportedKeySize(String fipsLevel, String suiteBLevel, String keyType) {
		int securityMode = getFipsSecurityMode(true, fipsLevel, suiteBLevel);
		int minSupportedKeySize = -1;
		if (securityMode >= 0 && securityMode < 2) {
			if (keyType.equals("RSA")) {
				minSupportedKeySize = 1024;
			} else if (keyType.equals("DSA")) {
				minSupportedKeySize = 1024;
			} else if (keyType.equals("EC")) {
				minSupportedKeySize = 256;
			}
		}

		if (securityMode == 2) {
			if (keyType.equals("RSA")) {
				minSupportedKeySize = 1024;
			} else if (keyType.equals("DSA")) {
				minSupportedKeySize = 1024;
			} else if (keyType.equals("EC")) {
				minSupportedKeySize = 256;
			}
		}

		if (securityMode > 2) {
			if (keyType.equals("RSA")) {
				minSupportedKeySize = 2048;
			} else if (keyType.equals("DSA")) {
				minSupportedKeySize = 2048;
			} else if (keyType.equals("EC") && (securityMode == 4 || securityMode == 3)) {
				minSupportedKeySize = 256;
			} else if (keyType.equals("EC") && securityMode == 5) {
				minSupportedKeySize = 384;
			}
		}

		return minSupportedKeySize;
	}

	static void setJavaSystemProperty(String prop, String value) {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "Setting Java System property:" + prop + " to " + value);
		}

		System.setProperty(prop, value);
	}
}