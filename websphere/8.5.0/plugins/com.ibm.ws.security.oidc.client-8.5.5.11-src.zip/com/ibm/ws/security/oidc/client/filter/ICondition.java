package com.ibm.ws.security.oidc.client.filter;

public interface ICondition {
	String getKey();

	boolean checkCondition(IValue var1) throws FilterException;

	String toString();
}