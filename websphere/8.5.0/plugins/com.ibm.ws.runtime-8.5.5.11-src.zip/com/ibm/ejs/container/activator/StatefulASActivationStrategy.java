package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerAS;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJBThreadData;
import com.ibm.ejs.container.StatefulBeanO;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.IllegalOperationException;
import com.ibm.websphere.csi.PassivationPolicy;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ffdc.FFDCFilter;
import java.rmi.RemoteException;
import javax.transaction.TransactionRolledbackException;

public class StatefulASActivationStrategy extends StatefulActivateTranActivationStrategy {
	private static final String CLASS_NAME = StatefulASActivationStrategy.class.getName();
	private static final TraceComponent tc;

	public StatefulASActivationStrategy(Activator activator, PassivationPolicy policy, SfFailoverCache failoverCache) {
		super(activator, policy, failoverCache);
	}

	BeanO atCreate(ContainerTx tx, BeanO bean) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCreate (" + tx + ", " + bean + ")");
		}

		ContainerAS as = tx.getContainerAS();
		super.atCreate(tx, bean);
		if (as != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "atCreate : running in AS : " + as);
			}

			bean.setContainerTx(tx);
			if (as.enlist(bean)) {
				this.cache.pinElement(((StatefulBeanO) bean).ivCacheElement);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCreate : null");
		}

		return null;
	}

	BeanO atActivate(EJBThreadData threadData, ContainerTx tx, BeanId beanId) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atActivate (" + tx + ", " + beanId + ")");
		}

		ContainerAS as = tx.getContainerAS();
		BeanO bean = super.atActivate(threadData, tx, beanId);
		if (as != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "atActivate : running in AS : " + as);
			}

			bean.setContainerTx(tx);
			if (!as.enlist(bean)) {
				this.cache.unpinElement(((StatefulBeanO) bean).ivCacheElement);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atActivate : " + bean);
		}

		return bean;
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit (" + tx + ", " + bean + ")");
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as != null && as.isEnlisted(bean.getId())) {
			this.resetBeanOContainerTx(bean);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atCommit");
			}

		} else {
			super.atCommit(tx, bean);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atCommit");
			}

		}
	}

	private void resetBeanOContainerTx(BeanO bean) {
		StatefulBeanO sfbean = (StatefulBeanO) bean;
		Object lock = sfbean.ivCacheLock;
		synchronized (lock) {
			if (bean.ivCacheKey != null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "resetBeanOContainerTx : " + sfbean);
				}

				this.cache.unpinElement(sfbean.ivCacheElement);
				sfbean.setContainerTx((ContainerTx) null);
				sfbean.unlock(lock);
			}

		}
	}

	void atRollback(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRollback (" + tx + ", " + bean + ")");
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as != null && as.isEnlisted(bean.getId())) {
			this.resetBeanOContainerTx(bean);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atRollback");
			}

		} else {
			super.atRollback(tx, bean);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atRollback");
			}

		}
	}

	void atEnlist(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atEnlist (" + tx + ", " + bean + ")");
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		super.atEnlist(tx, bean);
		if (as != null) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "atEnlist : running in AS : " + as);
			}

			bean.setContainerTx(tx);
			as.enlist(bean);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atEnlist");
		}

	}

	void atPostInvoke(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atPostInvoke (" + tx + ", " + bean + ")");
		}

		ContainerAS as = ContainerAS.getContainerAS(tx);
		if (as != null && as.isEnlisted(bean.getId())) {
			StatefulBeanO sfbean = (StatefulBeanO) bean;
			BeanId id = bean.getId();
			Object lock = sfbean.ivCacheLock;
			synchronized (lock) {
				if (bean.ivCacheKey != null) {
					if (!bean.isRemoved() && !bean.isDiscarded()) {
						sfbean.setLastAccessTime(System.currentTimeMillis());
					} else {
						this.cache.unpinElement(sfbean.ivCacheElement);
						if (tx != null) {
							try {
								tx.delist(bean);
							} catch (TransactionRolledbackException var11) {
								FFDCFilter.processException(var11, CLASS_NAME + ".atPostInvoke", "258", this);
								Tr.debug(tc, "atPostInvoke : transaction has rolledback");
							}
						}

						bean.setContainerTx((ContainerTx) null);
						as.delist(bean);
						this.cache.removeElement(sfbean.ivCacheElement, true);
						sfbean.destroy();
						bean.ivCacheKey = null;
						this.reaper.remove(id);
					}

					sfbean.unlock(lock);
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atPostInvoke");
			}

		} else {
			super.atPostInvoke(tx, bean);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atPostInvoke");
			}

		}
	}

	void atDiscard(BeanO bean) throws RemoteException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atDiscard (" + bean + ")");
		}

		ContainerAS as = ContainerAS.getCurrentContainerAS();
		if (as != null && as.isEnlisted(bean.getId())) {
			try {
				BeanId beanId = ((StatefulBeanO) bean).getId();
				StatefulBeanO statefulBeanO = (StatefulBeanO) bean;
				if (!statefulBeanO.isTimedOut()) {
					as.delist(bean);
					bean.setContainerTx((ContainerTx) null);
					bean.ivCacheKey = null;
					bean.passivate();
				} else {
					Tr.event(tc, "Discarding session bean", bean);
					this.reaper.remove(beanId);
					statefulBeanO.destroy();
					bean.ivCacheKey = null;
				}
			} catch (RemoteException var6) {
				FFDCFilter.processException(var6, CLASS_NAME + ".atDiscard", "484", this);
				Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{bean, this, var6});
				throw var6;
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atDiscard");
			}

		} else {
			super.atDiscard(bean);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atDiscard");
			}

		}
	}

	void atUnitOfWorkEnd(ContainerAS as, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atUnitOfWorkEnd (" + as + ", " + bean + ")");
		}

		if (as != null && as.isEnlisted(bean.getId())) {
			Object key = bean.ivCacheKey;
			StatefulBeanO sfbean = null;
			synchronized (this.locks.getLock(key)) {
				sfbean = (StatefulBeanO) this.cache.find(key);
				if (sfbean != null) {
					this.cache.unpin(key);
					if (!sfbean.isRemoved() && sfbean.getState() != 4) {
						try {
							this.cache.remove(key, true);
							sfbean.ivCacheKey = null;
							bean.setContainerTx((ContainerTx) null);
							sfbean.passivate();
						} catch (IllegalOperationException var9) {
							if (isTraceOn && tc.isDebugEnabled()) {
								Tr.debug(tc, "Ignoring IllegalOperationException.");
							}

							this.cache.unpin(key);
						} catch (RemoteException var10) {
							FFDCFilter.processException(var10, CLASS_NAME + ".atUnitOfWorkEnd", "64", this);
							Tr.warning(tc, "UNABLE_TO_PASSIVATE_EJB_CNTR0005W", new Object[]{bean, this, var10});
						}
					}
				} else if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Bean not found in cache");
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUnitOfWorkEnd");
			}

		} else {
			super.atUnitOfWorkEnd(as, bean);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "atUnitOfWorkEnd");
			}

		}
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}