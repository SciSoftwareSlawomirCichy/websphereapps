package com.ibm.icu.text;

import com.ibm.icu.impl.UCharacterProperty;
import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.CollationParsedRuleBuilder.InverseUCA;
import com.ibm.icu.text.CollationRuleParser.IndirectBoundaries;
import com.ibm.icu.text.CollationRuleParser.OptionSet;
import com.ibm.icu.text.CollationRuleParser.ParsedToken;
import com.ibm.icu.text.CollationRuleParser.Token;
import com.ibm.icu.text.CollationRuleParser.TokenListHeader;
import com.ibm.icu.text.CollationRuleParser.TokenOption;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Hashtable;

final class CollationRuleParser {
	static final int TOKEN_RESET_ = -559038737;
	int m_resultLength_;
	TokenListHeader[] m_listHeader_;
	Token m_variableTop_;
	OptionSet m_options_;
	StringBuilder m_source_;
	Hashtable<Token, Token> m_hashTable_;
	private ParsedToken m_parsedToken_;
	private String m_rules_;
	private int m_current_;
	private int m_optionEnd_;
	private int m_extraCurrent_;
	UnicodeSet m_copySet_;
	UnicodeSet m_removeSet_;
	private int m_prevStrength_;
	private static final int TOKEN_UNSET_ = -1;
	private static final int TOKEN_POLARITY_POSITIVE_ = 1;
	private static final int TOKEN_TOP_MASK_ = 4;
	private static final int TOKEN_VARIABLE_TOP_MASK_ = 8;
	private static final int TOKEN_BEFORE_ = 3;
	private static final int TOKEN_SUCCESS_MASK_ = 16;
	private static final IndirectBoundaries[] INDIRECT_BOUNDARIES_ = new IndirectBoundaries[15];
	private static final TokenOption[] RULES_OPTIONS_;
	private Token m_utilToken_ = new Token();
	private CollationElementIterator m_UCAColEIter_;
	private int[] m_utilCEBuffer_;
	private int m_optionarg_;

	CollationRuleParser(String rules) throws ParseException {
		this.m_UCAColEIter_ = RuleBasedCollator.UCA_.getCollationElementIterator("");
		this.m_utilCEBuffer_ = new int[2];
		this.m_optionarg_ = 0;
		this.extractSetsFromRules(rules);
		this.m_source_ = new StringBuilder(Normalizer.decompose(rules, false).trim());
		this.m_rules_ = this.m_source_.toString();
		this.m_current_ = 0;
		this.m_extraCurrent_ = this.m_source_.length();
		this.m_variableTop_ = null;
		this.m_parsedToken_ = new ParsedToken();
		this.m_hashTable_ = new Hashtable();
		this.m_options_ = new OptionSet(RuleBasedCollator.UCA_);
		this.m_listHeader_ = new TokenListHeader[512];
		this.m_resultLength_ = 0;
		this.m_prevStrength_ = -1;
	}

	void setDefaultOptionsInCollator(RuleBasedCollator collator) {
		collator.m_defaultStrength_ = this.m_options_.m_strength_;
		collator.m_defaultDecomposition_ = this.m_options_.m_decomposition_;
		collator.m_defaultIsFrenchCollation_ = this.m_options_.m_isFrenchCollation_;
		collator.m_defaultIsAlternateHandlingShifted_ = this.m_options_.m_isAlternateHandlingShifted_;
		collator.m_defaultIsCaseLevel_ = this.m_options_.m_isCaseLevel_;
		collator.m_defaultCaseFirst_ = this.m_options_.m_caseFirst_;
		collator.m_defaultIsHiragana4_ = this.m_options_.m_isHiragana4_;
		collator.m_defaultVariableTopValue_ = this.m_options_.m_variableTopValue_;
	}

	int assembleTokenList() throws ParseException {
		Token lastToken = null;
		this.m_parsedToken_.m_strength_ = -1;
		int sourcelimit = this.m_source_.length();
		int expandNext = 0;

		while (true) {
			do {
				if (this.m_current_ >= sourcelimit) {
					if (this.m_resultLength_ > 0 && this.m_listHeader_[this.m_resultLength_ - 1].m_first_ == null) {
						--this.m_resultLength_;
					}

					return this.m_resultLength_;
				}

				this.m_parsedToken_.m_prefixOffset_ = 0;
			} while (this.parseNextToken(lastToken == null) < 0);

			char specs = this.m_parsedToken_.m_flags_;
			boolean variableTop = (specs & 8) != 0;
			boolean top = (specs & 4) != 0;
			int lastStrength = -1;
			if (lastToken != null) {
				lastStrength = lastToken.m_strength_;
			}

			this.m_utilToken_.m_source_ = this.m_parsedToken_.m_charsLen_ << 24 | this.m_parsedToken_.m_charsOffset_;
			this.m_utilToken_.m_rules_ = this.m_source_;
			Token sourceToken = (Token) this.m_hashTable_.get(this.m_utilToken_);
			int start;
			int size;
			if (this.m_parsedToken_.m_strength_ != -559038737) {
				if (lastToken == null) {
					throwParseException(this.m_source_.toString(), 0);
				}

				if (sourceToken == null) {
					sourceToken = new Token();
					sourceToken.m_rules_ = this.m_source_;
					sourceToken.m_source_ = this.m_parsedToken_.m_charsLen_ << 24 | this.m_parsedToken_.m_charsOffset_;
					sourceToken.m_prefix_ = this.m_parsedToken_.m_prefixLen_ << 24
							| this.m_parsedToken_.m_prefixOffset_;
					sourceToken.m_polarity_ = 1;
					sourceToken.m_next_ = null;
					sourceToken.m_previous_ = null;
					sourceToken.m_CELength_ = 0;
					sourceToken.m_expCELength_ = 0;
					this.m_hashTable_.put(sourceToken, sourceToken);
				} else if (sourceToken.m_strength_ != -559038737 && lastToken != sourceToken) {
					if (sourceToken.m_next_ != null) {
						if (sourceToken.m_next_.m_strength_ > sourceToken.m_strength_) {
							sourceToken.m_next_.m_strength_ = sourceToken.m_strength_;
						}

						sourceToken.m_next_.m_previous_ = sourceToken.m_previous_;
					} else {
						sourceToken.m_listHeader_.m_last_ = sourceToken.m_previous_;
					}

					if (sourceToken.m_previous_ != null) {
						sourceToken.m_previous_.m_next_ = sourceToken.m_next_;
					} else {
						sourceToken.m_listHeader_.m_first_ = sourceToken.m_next_;
					}

					sourceToken.m_next_ = null;
					sourceToken.m_previous_ = null;
				}

				sourceToken.m_strength_ = this.m_parsedToken_.m_strength_;
				sourceToken.m_listHeader_ = lastToken.m_listHeader_;
				if (lastStrength != -559038737 && sourceToken.m_listHeader_.m_first_ != null) {
					if (sourceToken != lastToken) {
						if (lastToken.m_polarity_ == sourceToken.m_polarity_) {
							while (lastToken.m_next_ != null
									&& lastToken.m_next_.m_strength_ > sourceToken.m_strength_) {
								lastToken = lastToken.m_next_;
							}

							sourceToken.m_previous_ = lastToken;
							if (lastToken.m_next_ != null) {
								lastToken.m_next_.m_previous_ = sourceToken;
							} else {
								sourceToken.m_listHeader_.m_last_ = sourceToken;
							}

							sourceToken.m_next_ = lastToken.m_next_;
							lastToken.m_next_ = sourceToken;
						} else {
							while (lastToken.m_previous_ != null
									&& lastToken.m_previous_.m_strength_ > sourceToken.m_strength_) {
								lastToken = lastToken.m_previous_;
							}

							sourceToken.m_next_ = lastToken;
							if (lastToken.m_previous_ != null) {
								lastToken.m_previous_.m_next_ = sourceToken;
							} else {
								sourceToken.m_listHeader_.m_first_ = sourceToken;
							}

							sourceToken.m_previous_ = lastToken.m_previous_;
							lastToken.m_previous_ = sourceToken;
						}
					} else if (lastStrength < sourceToken.m_strength_) {
						sourceToken.m_strength_ = lastStrength;
					}
				} else if (sourceToken.m_listHeader_.m_first_ == null) {
					sourceToken.m_listHeader_.m_first_ = sourceToken;
					sourceToken.m_listHeader_.m_last_ = sourceToken;
				} else if (sourceToken.m_listHeader_.m_first_.m_strength_ <= sourceToken.m_strength_) {
					sourceToken.m_next_ = sourceToken.m_listHeader_.m_first_;
					sourceToken.m_next_.m_previous_ = sourceToken;
					sourceToken.m_listHeader_.m_first_ = sourceToken;
					sourceToken.m_previous_ = null;
				} else {
					for (lastToken = sourceToken.m_listHeader_.m_first_; lastToken.m_next_ != null
							&& lastToken.m_next_.m_strength_ > sourceToken.m_strength_; lastToken = lastToken.m_next_) {
						;
					}

					if (lastToken.m_next_ != null) {
						lastToken.m_next_.m_previous_ = sourceToken;
					} else {
						sourceToken.m_listHeader_.m_last_ = sourceToken;
					}

					sourceToken.m_previous_ = lastToken;
					sourceToken.m_next_ = lastToken.m_next_;
					lastToken.m_next_ = sourceToken;
				}

				if (variableTop && this.m_variableTop_ == null) {
					variableTop = false;
					this.m_variableTop_ = sourceToken;
				}

				sourceToken.m_expansion_ = this.m_parsedToken_.m_extensionLen_ << 24
						| this.m_parsedToken_.m_extensionOffset_;
				if (expandNext != 0) {
					if (sourceToken.m_strength_ == 0) {
						expandNext = 0;
					} else if (sourceToken.m_expansion_ == 0) {
						sourceToken.m_expansion_ = expandNext;
					} else {
						start = expandNext & 16777215;
						size = expandNext >>> 24;
						if (size > 0) {
							this.m_source_.append(this.m_source_.substring(start, start + size));
						}

						start = this.m_parsedToken_.m_extensionOffset_;
						this.m_source_
								.append(this.m_source_.substring(start, start + this.m_parsedToken_.m_extensionLen_));
						sourceToken.m_expansion_ = size + this.m_parsedToken_.m_extensionLen_ << 24
								| this.m_extraCurrent_;
						this.m_extraCurrent_ += size + this.m_parsedToken_.m_extensionLen_;
					}
				}

				if ((lastToken.m_flags_ & 3) != 0) {
					start = (lastToken.m_flags_ & 3) - 1;
					if (start != sourceToken.m_strength_) {
						throwParseException(this.m_source_.toString(), this.m_current_);
					}
				}
			} else {
				if (lastToken != null && lastStrength == -559038737 && this.m_resultLength_ > 0
						&& this.m_listHeader_[this.m_resultLength_ - 1].m_first_ == null) {
					--this.m_resultLength_;
				}

				if (sourceToken == null) {
					for (start = this.m_parsedToken_.m_charsLen_; start > 1
							&& sourceToken == null; sourceToken = (Token) this.m_hashTable_.get(this.m_utilToken_)) {
						--start;
						this.m_utilToken_.m_source_ = start << 24 | this.m_parsedToken_.m_charsOffset_;
						this.m_utilToken_.m_rules_ = this.m_source_;
					}

					if (sourceToken != null) {
						expandNext = this.m_parsedToken_.m_charsLen_ - start << 24
								| this.m_parsedToken_.m_charsOffset_ + start;
					}
				}

				int expand;
				if ((specs & 3) != 0) {
					if (!top) {
						start = (specs & 3) - 1;
						if (sourceToken != null && sourceToken.m_strength_ != -559038737) {
							while (sourceToken.m_strength_ > start && sourceToken.m_previous_ != null) {
								sourceToken = sourceToken.m_previous_;
							}

							if (sourceToken.m_strength_ == start) {
								if (sourceToken.m_previous_ != null) {
									sourceToken = sourceToken.m_previous_;
								} else {
									sourceToken = sourceToken.m_listHeader_.m_reset_;
								}
							} else {
								sourceToken = sourceToken.m_listHeader_.m_reset_;
								sourceToken = this.getVirginBefore(sourceToken, start);
							}
						} else {
							sourceToken = this.getVirginBefore(sourceToken, start);
						}
					} else {
						top = false;
						this.m_listHeader_[this.m_resultLength_] = new TokenListHeader();
						this.m_listHeader_[this.m_resultLength_].m_previousCE_ = 0;
						this.m_listHeader_[this.m_resultLength_].m_previousContCE_ = 0;
						this.m_listHeader_[this.m_resultLength_].m_indirect_ = true;
						start = (specs & 3) - 1;
						size = INDIRECT_BOUNDARIES_[this.m_parsedToken_.m_indirectIndex_].m_startCE_;
						expand = INDIRECT_BOUNDARIES_[this.m_parsedToken_.m_indirectIndex_].m_startContCE_;
						int[] ce = new int[2];
						if (size >>> 24 >= RuleBasedCollator.UCA_CONSTANTS_.PRIMARY_IMPLICIT_MIN_
								&& size >>> 24 <= RuleBasedCollator.UCA_CONSTANTS_.PRIMARY_IMPLICIT_MAX_) {
							int primary = size & -65536 | (expand & -65536) >> 16;
							int raw = RuleBasedCollator.impCEGen_.getRawFromImplicit(primary);
							int primaryCE = RuleBasedCollator.impCEGen_.getImplicitFromRaw(raw - 1);
							ce[0] = primaryCE & -65536 | 1285;
							ce[1] = primaryCE << 16 & -65536 | 192;
						} else {
							InverseUCA invuca = CollationParsedRuleBuilder.INVERSE_UCA_;
							invuca.getInversePrevCE(size, expand, start, ce);
						}

						this.m_listHeader_[this.m_resultLength_].m_baseCE_ = ce[0];
						this.m_listHeader_[this.m_resultLength_].m_baseContCE_ = ce[1];
						this.m_listHeader_[this.m_resultLength_].m_nextCE_ = 0;
						this.m_listHeader_[this.m_resultLength_].m_nextContCE_ = 0;
						sourceToken = new Token();
						expandNext = this.initAReset(0, sourceToken);
					}
				}

				if (sourceToken == null) {
					if (this.m_listHeader_[this.m_resultLength_] == null) {
						this.m_listHeader_[this.m_resultLength_] = new TokenListHeader();
					}

					if (!top) {
						CollationElementIterator coleiter = RuleBasedCollator.UCA_.getCollationElementIterator(
								this.m_source_.substring(this.m_parsedToken_.m_charsOffset_,
										this.m_parsedToken_.m_charsOffset_ + this.m_parsedToken_.m_charsLen_));
						size = coleiter.next();
						expand = coleiter.getOffset() + this.m_parsedToken_.m_charsOffset_;
						int SecondCE = coleiter.next();
						this.m_listHeader_[this.m_resultLength_].m_baseCE_ = size & -193;
						if (RuleBasedCollator.isContinuation(SecondCE)) {
							this.m_listHeader_[this.m_resultLength_].m_baseContCE_ = SecondCE;
						} else {
							this.m_listHeader_[this.m_resultLength_].m_baseContCE_ = 0;
						}

						this.m_listHeader_[this.m_resultLength_].m_nextCE_ = 0;
						this.m_listHeader_[this.m_resultLength_].m_nextContCE_ = 0;
						this.m_listHeader_[this.m_resultLength_].m_previousCE_ = 0;
						this.m_listHeader_[this.m_resultLength_].m_previousContCE_ = 0;
						this.m_listHeader_[this.m_resultLength_].m_indirect_ = false;
						sourceToken = new Token();
						expandNext = this.initAReset(expand, sourceToken);
					} else {
						top = false;
						this.m_listHeader_[this.m_resultLength_].m_previousCE_ = 0;
						this.m_listHeader_[this.m_resultLength_].m_previousContCE_ = 0;
						this.m_listHeader_[this.m_resultLength_].m_indirect_ = true;
						IndirectBoundaries ib = INDIRECT_BOUNDARIES_[this.m_parsedToken_.m_indirectIndex_];
						this.m_listHeader_[this.m_resultLength_].m_baseCE_ = ib.m_startCE_;
						this.m_listHeader_[this.m_resultLength_].m_baseContCE_ = ib.m_startContCE_;
						this.m_listHeader_[this.m_resultLength_].m_nextCE_ = ib.m_limitCE_;
						this.m_listHeader_[this.m_resultLength_].m_nextContCE_ = ib.m_limitContCE_;
						sourceToken = new Token();
						expandNext = this.initAReset(0, sourceToken);
					}
				} else {
					top = false;
				}
			}

			lastToken = sourceToken;
		}
	}

	private static final void throwParseException(String rules, int offset) throws ParseException {
		String precontext = rules.substring(0, offset);
		String postcontext = rules.substring(offset, rules.length());
		StringBuilder error = new StringBuilder("Parse error occurred in rule at offset ");
		error.append(offset);
		error.append("\n after the prefix \"");
		error.append(precontext);
		error.append("\" before the suffix \"");
		error.append(postcontext);
		throw new ParseException(error.toString(), offset);
	}

	private final boolean doSetTop() {
		this.m_parsedToken_.m_charsOffset_ = this.m_extraCurrent_;
		this.m_source_.append('￾');
		IndirectBoundaries ib = INDIRECT_BOUNDARIES_[this.m_parsedToken_.m_indirectIndex_];
		this.m_source_.append((char) (ib.m_startCE_ >> 16));
		this.m_source_.append((char) (ib.m_startCE_ & '￿'));
		this.m_extraCurrent_ += 3;
		if (INDIRECT_BOUNDARIES_[this.m_parsedToken_.m_indirectIndex_].m_startContCE_ == 0) {
			this.m_parsedToken_.m_charsLen_ = 3;
		} else {
			this.m_source_
					.append((char) (INDIRECT_BOUNDARIES_[this.m_parsedToken_.m_indirectIndex_].m_startContCE_ >> 16));
			this.m_source_
					.append((char) (INDIRECT_BOUNDARIES_[this.m_parsedToken_.m_indirectIndex_].m_startContCE_ & '￿'));
			this.m_extraCurrent_ += 2;
			this.m_parsedToken_.m_charsLen_ = 5;
		}

		return true;
	}

	private static boolean isCharNewLine(char c) {
		switch (c) {
			case '\n' :
			case '\f' :
			case '\r' :
			case '' :
			case ' ' :
			case ' ' :
				return true;
			default :
				return false;
		}
	}

	private int parseNextToken(boolean startofrules) throws ParseException {
		boolean variabletop = false;
		boolean top = false;
		boolean inchars = true;
		boolean inquote = false;
		boolean wasinquote = false;
		byte before = 0;
		boolean isescaped = false;
		int newextensionlen = 0;
		int extensionoffset = 0;
		int newstrength = -1;
		this.m_parsedToken_.m_charsLen_ = 0;
		this.m_parsedToken_.m_charsOffset_ = 0;
		this.m_parsedToken_.m_prefixOffset_ = 0;
		this.m_parsedToken_.m_prefixLen_ = 0;
		this.m_parsedToken_.m_indirectIndex_ = 0;

		for (int limit = this.m_rules_.length(); this.m_current_ < limit; ++this.m_current_) {
			char ch = this.m_source_.charAt(this.m_current_);
			if (inquote) {
				if (ch == '\'') {
					inquote = false;
				} else if (this.m_parsedToken_.m_charsLen_ != 0 && !inchars) {
					if (newextensionlen == 0) {
						extensionoffset = this.m_extraCurrent_;
					}

					++newextensionlen;
				} else {
					if (this.m_parsedToken_.m_charsLen_ == 0) {
						this.m_parsedToken_.m_charsOffset_ = this.m_extraCurrent_;
					}

					++this.m_parsedToken_.m_charsLen_;
				}
			} else if (isescaped) {
				isescaped = false;
				if (newstrength == -1) {
					throwParseException(this.m_rules_, this.m_current_);
				}

				if (ch != 0 && this.m_current_ != limit) {
					if (inchars) {
						if (this.m_parsedToken_.m_charsLen_ == 0) {
							this.m_parsedToken_.m_charsOffset_ = this.m_current_;
						}

						++this.m_parsedToken_.m_charsLen_;
					} else {
						if (newextensionlen == 0) {
							extensionoffset = this.m_current_;
						}

						++newextensionlen;
					}
				}
			} else if (!UCharacterProperty.isRuleWhiteSpace(ch)) {
				label235 : switch (ch) {
					case '!' :
						break;
					case '#' :
						while (true) {
							++this.m_current_;
							ch = this.m_source_.charAt(this.m_current_);
							if (isCharNewLine(ch)) {
								break label235;
							}
						}
					case '&' :
						if (newstrength != -1) {
							return this.doEndParseNextToken(newstrength, top, extensionoffset, newextensionlen,
									variabletop, before);
						}

						newstrength = -559038737;
						this.m_prevStrength_ = -1;
						break;
					case '\'' :
						if (newstrength == -1) {
							if (this.m_prevStrength_ == -1) {
								throwParseException(this.m_rules_, this.m_current_);
							} else {
								newstrength = this.m_prevStrength_;
							}
						}

						inquote = true;
						if (inchars) {
							if (!wasinquote) {
								this.m_parsedToken_.m_charsOffset_ = this.m_extraCurrent_;
							}

							if (this.m_parsedToken_.m_charsLen_ != 0) {
								this.m_source_.append(this.m_source_
										.substring(this.m_current_ - this.m_parsedToken_.m_charsLen_, this.m_current_));
								this.m_extraCurrent_ += this.m_parsedToken_.m_charsLen_;
							}

							++this.m_parsedToken_.m_charsLen_;
						} else {
							if (!wasinquote) {
								extensionoffset = this.m_extraCurrent_;
							}

							if (newextensionlen != 0) {
								this.m_source_.append(
										this.m_source_.substring(this.m_current_ - newextensionlen, this.m_current_));
								this.m_extraCurrent_ += newextensionlen;
							}

							++newextensionlen;
						}

						wasinquote = true;
						++this.m_current_;
						ch = this.m_source_.charAt(this.m_current_);
						if (ch == '\'') {
							this.m_source_.append(ch);
							++this.m_extraCurrent_;
							inquote = false;
						}
						break;
					case ',' :
						if (newstrength != -1) {
							return this.doEndParseNextToken(newstrength, top, extensionoffset, newextensionlen,
									variabletop, before);
						}

						if (startofrules) {
							this.m_parsedToken_.m_indirectIndex_ = 5;
							top = this.doSetTop();
							return this.doEndParseNextToken(-559038737, top, extensionoffset, newextensionlen,
									variabletop, before);
						}

						newstrength = 2;
						this.m_prevStrength_ = -1;
						break;
					case '/' :
						wasinquote = false;
						inchars = false;
						break;
					case ';' :
						if (newstrength != -1) {
							return this.doEndParseNextToken(newstrength, top, extensionoffset, newextensionlen,
									variabletop, before);
						}

						if (startofrules) {
							this.m_parsedToken_.m_indirectIndex_ = 5;
							top = this.doSetTop();
							return this.doEndParseNextToken(-559038737, top, extensionoffset, newextensionlen,
									variabletop, before);
						}

						newstrength = 1;
						this.m_prevStrength_ = -1;
						break;
					case '<' :
						if (newstrength != -1) {
							return this.doEndParseNextToken(newstrength, top, extensionoffset, newextensionlen,
									variabletop, before);
						}

						if (startofrules) {
							this.m_parsedToken_.m_indirectIndex_ = 5;
							top = this.doSetTop();
							return this.doEndParseNextToken(-559038737, top, extensionoffset, newextensionlen,
									variabletop, before);
						}

						if (this.m_source_.charAt(this.m_current_ + 1) == '<') {
							++this.m_current_;
							if (this.m_source_.charAt(this.m_current_ + 1) == '<') {
								++this.m_current_;
								newstrength = 2;
							} else {
								newstrength = 1;
							}
						} else {
							newstrength = 0;
						}

						if (this.m_source_.charAt(this.m_current_ + 1) == '*') {
							++this.m_current_;
							this.m_prevStrength_ = newstrength;
						} else {
							this.m_prevStrength_ = -1;
						}
						break;
					case '=' :
						if (newstrength != -1) {
							return this.doEndParseNextToken(newstrength, top, extensionoffset, newextensionlen,
									variabletop, before);
						}

						if (startofrules) {
							this.m_parsedToken_.m_indirectIndex_ = 5;
							top = this.doSetTop();
							return this.doEndParseNextToken(-559038737, top, extensionoffset, newextensionlen,
									variabletop, before);
						}

						newstrength = 15;
						if (this.m_source_.charAt(this.m_current_ + 1) == '*') {
							++this.m_current_;
							this.m_prevStrength_ = newstrength;
						} else {
							this.m_prevStrength_ = -1;
						}
						break;
					case '@' :
						if (newstrength == -1) {
							this.m_options_.m_isFrenchCollation_ = true;
							break;
						}
					case '|' :
						this.m_parsedToken_.m_prefixOffset_ = this.m_parsedToken_.m_charsOffset_;
						this.m_parsedToken_.m_prefixLen_ = this.m_parsedToken_.m_charsLen_;
						if (inchars) {
							if (!wasinquote) {
								this.m_parsedToken_.m_charsOffset_ = this.m_extraCurrent_;
							}

							if (this.m_parsedToken_.m_charsLen_ != 0) {
								String prefix = this.m_source_
										.substring(this.m_current_ - this.m_parsedToken_.m_charsLen_, this.m_current_);
								this.m_source_.append(prefix);
								this.m_extraCurrent_ += this.m_parsedToken_.m_charsLen_;
							}

							++this.m_parsedToken_.m_charsLen_;
						}

						wasinquote = true;

						while (true) {
							++this.m_current_;
							ch = this.m_source_.charAt(this.m_current_);
							if (!UCharacterProperty.isRuleWhiteSpace(ch)) {
								break label235;
							}
						}
					case '[' :
						this.m_optionEnd_ = this.m_rules_.indexOf(93, this.m_current_);
						if (this.m_optionEnd_ != -1) {
							byte result = this.readAndSetOption();
							this.m_current_ = this.m_optionEnd_;
							if ((result & 4) != 0) {
								if (newstrength == -559038737) {
									top = this.doSetTop();
									if (before != 0) {
										this.m_source_.append('-');
										this.m_source_.append((char) before);
										this.m_extraCurrent_ += 2;
										this.m_parsedToken_.m_charsLen_ += 2;
									}

									++this.m_current_;
									return this.doEndParseNextToken(newstrength, true, extensionoffset, newextensionlen,
											variabletop, before);
								}

								throwParseException(this.m_rules_, this.m_current_);
							} else if ((result & 8) != 0) {
								if (newstrength != -559038737 && newstrength != -1) {
									variabletop = true;
									this.m_parsedToken_.m_charsOffset_ = this.m_extraCurrent_;
									this.m_source_.append('￿');
									++this.m_extraCurrent_;
									++this.m_current_;
									this.m_parsedToken_.m_charsLen_ = 1;
									return this.doEndParseNextToken(newstrength, top, extensionoffset, newextensionlen,
											variabletop, before);
								}

								throwParseException(this.m_rules_, this.m_current_);
							} else if ((result & 3) != 0) {
								if (newstrength == -559038737) {
									before = (byte) (result & 3);
								} else {
									throwParseException(this.m_rules_, this.m_current_);
								}
							}
						}
						break;
					case '\\' :
						isescaped = true;
						break;
					default :
						if (newstrength == -1) {
							if (this.m_prevStrength_ == -1) {
								throwParseException(this.m_rules_, this.m_current_);
							} else {
								newstrength = this.m_prevStrength_;
							}
						}

						if (isSpecialChar(ch) && !inquote) {
							throwParseException(this.m_rules_, this.m_current_);
						}

						if (ch != 0 || this.m_current_ + 1 != limit) {
							if (inchars) {
								if (this.m_parsedToken_.m_charsLen_ == 0) {
									this.m_parsedToken_.m_charsOffset_ = this.m_current_;
								}

								++this.m_parsedToken_.m_charsLen_;
								if (this.m_prevStrength_ != -1) {
									char[] fullchar = Character
											.toChars(Character.codePointAt(this.m_source_, this.m_current_));
									this.m_current_ += fullchar.length;
									this.m_parsedToken_.m_charsLen_ += fullchar.length - 1;
									return this.doEndParseNextToken(newstrength, top, extensionoffset, newextensionlen,
											variabletop, before);
								}
							} else {
								if (newextensionlen == 0) {
									extensionoffset = this.m_current_;
								}

								++newextensionlen;
							}
						}
				}
			}

			if (wasinquote && ch != '\'') {
				this.m_source_.append(ch);
				++this.m_extraCurrent_;
			}
		}

		return this.doEndParseNextToken(newstrength, top, extensionoffset, newextensionlen, variabletop, before);
	}

	private int doEndParseNextToken(int newstrength, boolean top, int extensionoffset, int newextensionlen,
			boolean variabletop, int before) throws ParseException {
		if (newstrength == -1) {
			return -1;
		} else {
			if (this.m_parsedToken_.m_charsLen_ == 0 && !top) {
				throwParseException(this.m_rules_, this.m_current_);
			}

			this.m_parsedToken_.m_strength_ = newstrength;
			this.m_parsedToken_.m_extensionOffset_ = extensionoffset;
			this.m_parsedToken_.m_extensionLen_ = newextensionlen;
			this.m_parsedToken_.m_flags_ = (char) ((variabletop ? 8 : 0) | (top ? 4 : 0) | before);
			return this.m_current_;
		}
	}

	private Token getVirginBefore(Token sourcetoken, int strength) throws ParseException {
		int basece;
		if (sourcetoken != null) {
			basece = sourcetoken.m_source_ & 16777215;
			this.m_UCAColEIter_.setText(this.m_source_.substring(basece, basece + 1));
		} else {
			this.m_UCAColEIter_.setText(this.m_source_.substring(this.m_parsedToken_.m_charsOffset_,
					this.m_parsedToken_.m_charsOffset_ + 1));
		}

		basece = this.m_UCAColEIter_.next() & -193;
		int basecontce = this.m_UCAColEIter_.next();
		if (basecontce == -1) {
			basecontce = 0;
		}

		int ch = false;
		if (basece >>> 24 >= RuleBasedCollator.UCA_CONSTANTS_.PRIMARY_IMPLICIT_MIN_
				&& basece >>> 24 <= RuleBasedCollator.UCA_CONSTANTS_.PRIMARY_IMPLICIT_MAX_) {
			int primary = basece & -65536 | (basecontce & -65536) >> 16;
			int raw = RuleBasedCollator.impCEGen_.getRawFromImplicit(primary);
			int ch = RuleBasedCollator.impCEGen_.getCodePointFromRaw(raw - 1);
			int primaryCE = RuleBasedCollator.impCEGen_.getImplicitFromRaw(raw - 1);
			this.m_utilCEBuffer_[0] = primaryCE & -65536 | 1285;
			this.m_utilCEBuffer_[1] = primaryCE << 16 & -65536 | 192;
			this.m_parsedToken_.m_charsOffset_ = this.m_extraCurrent_;
			this.m_source_.append('￾');
			this.m_source_.append((char) ch);
			this.m_extraCurrent_ += 2;
			++this.m_parsedToken_.m_charsLen_;
			this.m_utilToken_.m_source_ = this.m_parsedToken_.m_charsLen_ << 24 | this.m_parsedToken_.m_charsOffset_;
			this.m_utilToken_.m_rules_ = this.m_source_;
			sourcetoken = (Token) this.m_hashTable_.get(this.m_utilToken_);
			if (sourcetoken == null) {
				this.m_listHeader_[this.m_resultLength_] = new TokenListHeader();
				this.m_listHeader_[this.m_resultLength_].m_baseCE_ = this.m_utilCEBuffer_[0] & -193;
				if (RuleBasedCollator.isContinuation(this.m_utilCEBuffer_[1])) {
					this.m_listHeader_[this.m_resultLength_].m_baseContCE_ = this.m_utilCEBuffer_[1];
				} else {
					this.m_listHeader_[this.m_resultLength_].m_baseContCE_ = 0;
				}

				this.m_listHeader_[this.m_resultLength_].m_nextCE_ = 0;
				this.m_listHeader_[this.m_resultLength_].m_nextContCE_ = 0;
				this.m_listHeader_[this.m_resultLength_].m_previousCE_ = 0;
				this.m_listHeader_[this.m_resultLength_].m_previousContCE_ = 0;
				this.m_listHeader_[this.m_resultLength_].m_indirect_ = false;
				sourcetoken = new Token();
				this.initAReset(-1, sourcetoken);
			}
		} else {
			CollationParsedRuleBuilder.INVERSE_UCA_.getInversePrevCE(basece, basecontce, strength,
					this.m_utilCEBuffer_);
			if (CollationParsedRuleBuilder.INVERSE_UCA_.getCEStrengthDifference(basece, basecontce,
					this.m_utilCEBuffer_[0], this.m_utilCEBuffer_[1]) < strength) {
				if (strength == 1) {
					this.m_utilCEBuffer_[0] = basece - 512;
				} else {
					this.m_utilCEBuffer_[0] = basece - 2;
				}

				if (RuleBasedCollator.isContinuation(basecontce)) {
					if (strength == 1) {
						this.m_utilCEBuffer_[1] = basecontce - 512;
					} else {
						this.m_utilCEBuffer_[1] = basecontce - 2;
					}
				}
			}

			this.m_parsedToken_.m_charsOffset_ -= 10;
			this.m_parsedToken_.m_charsLen_ += 10;
			this.m_listHeader_[this.m_resultLength_] = new TokenListHeader();
			this.m_listHeader_[this.m_resultLength_].m_baseCE_ = this.m_utilCEBuffer_[0] & -193;
			if (RuleBasedCollator.isContinuation(this.m_utilCEBuffer_[1])) {
				this.m_listHeader_[this.m_resultLength_].m_baseContCE_ = this.m_utilCEBuffer_[1];
			} else {
				this.m_listHeader_[this.m_resultLength_].m_baseContCE_ = 0;
			}

			this.m_listHeader_[this.m_resultLength_].m_nextCE_ = 0;
			this.m_listHeader_[this.m_resultLength_].m_nextContCE_ = 0;
			this.m_listHeader_[this.m_resultLength_].m_previousCE_ = 0;
			this.m_listHeader_[this.m_resultLength_].m_previousContCE_ = 0;
			this.m_listHeader_[this.m_resultLength_].m_indirect_ = false;
			sourcetoken = new Token();
			this.initAReset(-1, sourcetoken);
		}

		return sourcetoken;
	}

	private int initAReset(int expand, Token targetToken) throws ParseException {
		if (this.m_resultLength_ == this.m_listHeader_.length - 1) {
			TokenListHeader[] temp = new TokenListHeader[this.m_resultLength_ << 1];
			System.arraycopy(this.m_listHeader_, 0, temp, 0, this.m_resultLength_ + 1);
			this.m_listHeader_ = temp;
		}

		targetToken.m_rules_ = this.m_source_;
		targetToken.m_source_ = this.m_parsedToken_.m_charsLen_ << 24 | this.m_parsedToken_.m_charsOffset_;
		targetToken.m_expansion_ = this.m_parsedToken_.m_extensionLen_ << 24 | this.m_parsedToken_.m_extensionOffset_;
		targetToken.m_flags_ = this.m_parsedToken_.m_flags_;
		if (this.m_parsedToken_.m_prefixOffset_ != 0) {
			throwParseException(this.m_rules_, this.m_parsedToken_.m_charsOffset_ - 1);
		}

		targetToken.m_prefix_ = 0;
		targetToken.m_polarity_ = 1;
		targetToken.m_strength_ = -559038737;
		targetToken.m_next_ = null;
		targetToken.m_previous_ = null;
		targetToken.m_CELength_ = 0;
		targetToken.m_expCELength_ = 0;
		targetToken.m_listHeader_ = this.m_listHeader_[this.m_resultLength_];
		this.m_listHeader_[this.m_resultLength_].m_first_ = null;
		this.m_listHeader_[this.m_resultLength_].m_last_ = null;
		this.m_listHeader_[this.m_resultLength_].m_first_ = null;
		this.m_listHeader_[this.m_resultLength_].m_last_ = null;
		this.m_listHeader_[this.m_resultLength_].m_reset_ = targetToken;
		int result = 0;
		if (expand > 0 && this.m_parsedToken_.m_charsLen_ > 1) {
			targetToken.m_source_ = expand - this.m_parsedToken_.m_charsOffset_ << 24
					| this.m_parsedToken_.m_charsOffset_;
			result = this.m_parsedToken_.m_charsLen_ + this.m_parsedToken_.m_charsOffset_ - expand << 24 | expand;
		}

		++this.m_resultLength_;
		this.m_hashTable_.put(targetToken, targetToken);
		return result;
	}

	private static final boolean isSpecialChar(char ch) {
		return ch <= '/' && ch >= ' ' || ch <= '?' && ch >= ':' || ch <= '`' && ch >= '[' || ch <= '~' && ch >= '}'
				|| ch == '{';
	}

	private UnicodeSet readAndSetUnicodeSet(String source, int start) throws ParseException {
		while (source.charAt(start) != '[') {
			++start;
		}

		int noOpenBraces = 1;

		int current;
		for (current = 1; start + current < source.length() && noOpenBraces != 0; ++current) {
			if (source.charAt(start + current) == '[') {
				++noOpenBraces;
			} else if (source.charAt(start + current) == ']') {
				--noOpenBraces;
			}
		}

		if (noOpenBraces != 0 || source.indexOf("]", start + current) == -1) {
			throwParseException(this.m_rules_, start);
		}

		return new UnicodeSet(source.substring(start, start + current));
	}

	private int readOption(String rules, int start, int optionend) {
		this.m_optionarg_ = 0;

		int i;
		for (i = 0; i < RULES_OPTIONS_.length; ++i) {
			String option = TokenOption.access$000(RULES_OPTIONS_[i]);
			int optionlength = option.length();
			if (rules.length() > start + optionlength
					&& option.equalsIgnoreCase(rules.substring(start, start + optionlength))) {
				if (optionend - start > optionlength) {
					for (this.m_optionarg_ = start + optionlength; this.m_optionarg_ < optionend
							&& (UCharacter.isWhitespace(rules.charAt(this.m_optionarg_)) || UCharacterProperty
									.isRuleWhiteSpace(rules.charAt(this.m_optionarg_))); ++this.m_optionarg_) {
						;
					}
				}
				break;
			}
		}

		if (i == RULES_OPTIONS_.length) {
			i = -1;
		}

		return i;
	}

	private byte readAndSetOption() throws ParseException {
		int start = this.m_current_ + 1;
		int i = this.readOption(this.m_rules_, start, this.m_optionEnd_);
		int optionarg = this.m_optionarg_;
		if (i < 0) {
			throwParseException(this.m_rules_, start);
		}

		int noOpenBraces;
		String subname;
		int size;
		if (i < 7) {
			if (optionarg != 0) {
				for (noOpenBraces = 0; noOpenBraces < TokenOption
						.access$100(RULES_OPTIONS_[i]).length; ++noOpenBraces) {
					subname = TokenOption.access$100(RULES_OPTIONS_[i])[noOpenBraces];
					size = optionarg + subname.length();
					if (this.m_rules_.length() > size
							&& subname.equalsIgnoreCase(this.m_rules_.substring(optionarg, size))) {
						this.setOptions(this.m_options_, TokenOption.access$200(RULES_OPTIONS_[i]),
								TokenOption.access$300(RULES_OPTIONS_[i])[noOpenBraces]);
						return 16;
					}
				}
			}

			throwParseException(this.m_rules_, optionarg);
		} else {
			if (i == 7) {
				return 24;
			}

			if (i == 8) {
				return 16;
			}

			if (i == 9) {
				if (optionarg != 0) {
					for (noOpenBraces = 0; noOpenBraces < TokenOption
							.access$100(RULES_OPTIONS_[i]).length; ++noOpenBraces) {
						subname = TokenOption.access$100(RULES_OPTIONS_[i])[noOpenBraces];
						size = optionarg + subname.length();
						if (this.m_rules_.length() > size && subname
								.equalsIgnoreCase(this.m_rules_.substring(optionarg, optionarg + subname.length()))) {
							return (byte) (16 | TokenOption.access$300(RULES_OPTIONS_[i])[noOpenBraces] + 1);
						}
					}
				}

				throwParseException(this.m_rules_, optionarg);
			} else {
				if (i == 10) {
					this.m_parsedToken_.m_indirectIndex_ = 0;
					return 20;
				}

				if (i < 13) {
					for (noOpenBraces = 0; noOpenBraces < TokenOption
							.access$100(RULES_OPTIONS_[i]).length; ++noOpenBraces) {
						subname = TokenOption.access$100(RULES_OPTIONS_[i])[noOpenBraces];
						size = optionarg + subname.length();
						if (this.m_rules_.length() > size
								&& subname.equalsIgnoreCase(this.m_rules_.substring(optionarg, size))) {
							this.m_parsedToken_.m_indirectIndex_ = (char) (i - 10 + (noOpenBraces << 1));
							return 20;
						}
					}

					throwParseException(this.m_rules_, optionarg);
				} else {
					if (i == 13 || i == 14) {
						noOpenBraces = 1;
						++this.m_current_;

						for (; this.m_current_ < this.m_source_.length() && noOpenBraces != 0; ++this.m_current_) {
							if (this.m_source_.charAt(this.m_current_) == '[') {
								++noOpenBraces;
							} else if (this.m_source_.charAt(this.m_current_) == ']') {
								--noOpenBraces;
							}
						}

						this.m_optionEnd_ = this.m_current_ - 1;
						return 16;
					}

					throwParseException(this.m_rules_, optionarg);
				}
			}
		}

		return 16;
	}

	private void setOptions(OptionSet optionset, int attribute, int value) {
		switch (attribute) {
			case 0 :
				optionset.m_isFrenchCollation_ = value == 17;
				break;
			case 1 :
				optionset.m_isAlternateHandlingShifted_ = value == 20;
				break;
			case 2 :
				optionset.m_caseFirst_ = value;
				break;
			case 3 :
				optionset.m_isCaseLevel_ = value == 17;
				break;
			case 4 :
				if (value == 17) {
					value = 17;
				}

				optionset.m_decomposition_ = value;
				break;
			case 5 :
				optionset.m_strength_ = value;
				break;
			case 6 :
				optionset.m_isHiragana4_ = value == 17;
		}

	}

	UnicodeSet getTailoredSet() throws ParseException {
		boolean startOfRules = true;
		UnicodeSet tailored = new UnicodeSet();
		CanonicalIterator it = new CanonicalIterator("");
		this.m_parsedToken_.m_strength_ = -1;
		int sourcelimit = this.m_source_.length();

		while (true) {
			do {
				do {
					if (this.m_current_ >= sourcelimit) {
						return tailored;
					}

					this.m_parsedToken_.m_prefixOffset_ = 0;
				} while (this.parseNextToken(startOfRules) < 0);

				startOfRules = false;
			} while (this.m_parsedToken_.m_strength_ == -559038737);

			it.setSource(this.m_source_.substring(this.m_parsedToken_.m_charsOffset_,
					this.m_parsedToken_.m_charsOffset_ + this.m_parsedToken_.m_charsLen_));

			for (String pattern = it.next(); pattern != null; pattern = it.next()) {
				if (Normalizer.quickCheck(pattern, Normalizer.FCD, 0) != Normalizer.NO) {
					tailored.add(pattern);
				}
			}
		}
	}

	private final void extractSetsFromRules(String rules) throws ParseException {
		int optionNumber = true;
		int setStart = false;

		for (int i = 0; i < rules.length(); ++i) {
			if (rules.charAt(i) == '[') {
				int optionNumber = this.readOption(rules, i + 1, rules.length());
				int setStart = this.m_optionarg_;
				UnicodeSet newSet;
				if (optionNumber == 13) {
					newSet = this.readAndSetUnicodeSet(rules, setStart);
					if (this.m_copySet_ == null) {
						this.m_copySet_ = newSet;
					} else {
						this.m_copySet_.addAll(newSet);
					}
				} else if (optionNumber == 14) {
					newSet = this.readAndSetUnicodeSet(rules, setStart);
					if (this.m_removeSet_ == null) {
						this.m_removeSet_ = newSet;
					} else {
						this.m_removeSet_.addAll(newSet);
					}
				}
			}
		}

	}

	static {
		INDIRECT_BOUNDARIES_[0] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.LAST_NON_VARIABLE_,
				RuleBasedCollator.UCA_CONSTANTS_.FIRST_IMPLICIT_);
		INDIRECT_BOUNDARIES_[1] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.FIRST_PRIMARY_IGNORABLE_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[2] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.LAST_PRIMARY_IGNORABLE_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[3] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.FIRST_SECONDARY_IGNORABLE_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[4] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.LAST_SECONDARY_IGNORABLE_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[5] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.FIRST_TERTIARY_IGNORABLE_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[6] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.LAST_TERTIARY_IGNORABLE_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[7] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.FIRST_VARIABLE_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[8] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.LAST_VARIABLE_, (int[]) null);
		INDIRECT_BOUNDARIES_[9] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.FIRST_NON_VARIABLE_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[10] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.LAST_NON_VARIABLE_,
				RuleBasedCollator.UCA_CONSTANTS_.FIRST_IMPLICIT_);
		INDIRECT_BOUNDARIES_[11] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.FIRST_IMPLICIT_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[12] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.LAST_IMPLICIT_,
				RuleBasedCollator.UCA_CONSTANTS_.FIRST_TRAILING_);
		INDIRECT_BOUNDARIES_[13] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.FIRST_TRAILING_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[14] = new IndirectBoundaries(RuleBasedCollator.UCA_CONSTANTS_.LAST_TRAILING_,
				(int[]) null);
		INDIRECT_BOUNDARIES_[14].m_limitCE_ = RuleBasedCollator.UCA_CONSTANTS_.PRIMARY_SPECIAL_MIN_ << 24;
		RULES_OPTIONS_ = new TokenOption[19];
		String[] option = new String[]{"non-ignorable", "shifted"};
		int[] value = new int[]{21, 20};
		RULES_OPTIONS_[0] = new TokenOption("alternate", 1, option, value);
		option = new String[]{"2"};
		value = new int[]{17};
		RULES_OPTIONS_[1] = new TokenOption("backwards", 0, option, value);
		String[] offonoption = new String[]{"off", "on"};
		int[] offonvalue = new int[]{16, 17};
		RULES_OPTIONS_[2] = new TokenOption("caseLevel", 3, offonoption, offonvalue);
		option = new String[]{"lower", "upper", "off"};
		value = new int[]{24, 25, 16};
		RULES_OPTIONS_[3] = new TokenOption("caseFirst", 2, option, value);
		RULES_OPTIONS_[4] = new TokenOption("normalization", 4, offonoption, offonvalue);
		RULES_OPTIONS_[5] = new TokenOption("hiraganaQ", 6, offonoption, offonvalue);
		option = new String[]{"1", "2", "3", "4", "I"};
		value = new int[]{0, 1, 2, 3, 15};
		RULES_OPTIONS_[6] = new TokenOption("strength", 5, option, value);
		RULES_OPTIONS_[7] = new TokenOption("variable top", 7, (String[]) null, (int[]) null);
		RULES_OPTIONS_[8] = new TokenOption("rearrange", 7, (String[]) null, (int[]) null);
		option = new String[]{"1", "2", "3"};
		value = new int[]{0, 1, 2};
		RULES_OPTIONS_[9] = new TokenOption("before", 7, option, value);
		RULES_OPTIONS_[10] = new TokenOption("top", 7, (String[]) null, (int[]) null);
		String[] firstlastoption = new String[]{"primary", "secondary", "tertiary", "variable", "regular", "implicit",
				"trailing"};
		int[] firstlastvalue = new int[7];
		Arrays.fill(firstlastvalue, 0);
		RULES_OPTIONS_[11] = new TokenOption("first", 7, firstlastoption, firstlastvalue);
		RULES_OPTIONS_[12] = new TokenOption("last", 7, firstlastoption, firstlastvalue);
		RULES_OPTIONS_[13] = new TokenOption("optimize", 7, (String[]) null, (int[]) null);
		RULES_OPTIONS_[14] = new TokenOption("suppressContractions", 7, (String[]) null, (int[]) null);
		RULES_OPTIONS_[15] = new TokenOption("undefined", 7, (String[]) null, (int[]) null);
		RULES_OPTIONS_[16] = new TokenOption("scriptOrder", 7, (String[]) null, (int[]) null);
		RULES_OPTIONS_[17] = new TokenOption("charsetname", 7, (String[]) null, (int[]) null);
		RULES_OPTIONS_[18] = new TokenOption("charset", 7, (String[]) null, (int[]) null);
	}
}