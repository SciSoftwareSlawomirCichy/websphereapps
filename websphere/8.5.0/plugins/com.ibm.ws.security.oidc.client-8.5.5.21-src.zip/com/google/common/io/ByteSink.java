package com.google.common.io;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.io.ByteSink.1;
import com.google.common.io.ByteSink.AsCharSink;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

@GwtIncompatible
public abstract class ByteSink {
	public CharSink asCharSink(Charset charset) {
      return new AsCharSink(this, charset, (1)null);
   }

	public abstract OutputStream openStream() throws IOException;

	public OutputStream openBufferedStream() throws IOException {
		OutputStream out = this.openStream();
		return out instanceof BufferedOutputStream ? (BufferedOutputStream) out : new BufferedOutputStream(out);
	}

	public void write(byte[] bytes) throws IOException {
		Preconditions.checkNotNull(bytes);
		Closer closer = Closer.create();

		try {
			OutputStream out = (OutputStream) closer.register(this.openStream());
			out.write(bytes);
			out.flush();
		} catch (Throwable var7) {
			throw closer.rethrow(var7);
		} finally {
			closer.close();
		}

	}

	@CanIgnoreReturnValue
	public long writeFrom(InputStream input) throws IOException {
		Preconditions.checkNotNull(input);
		Closer closer = Closer.create();

		long var6;
		try {
			OutputStream out = (OutputStream) closer.register(this.openStream());
			long written = ByteStreams.copy(input, out);
			out.flush();
			var6 = written;
		} catch (Throwable var11) {
			throw closer.rethrow(var11);
		} finally {
			closer.close();
		}

		return var6;
	}
}