package com.ibm.ws.wim.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.eclipse.emf.ecore.EPackage.Registry;
import org.eclipse.emf.ecore.impl.DebugStreamInstance;
import org.eclipse.emf.ecore.impl.EPackageRegistryImpl;

public class VMMPackageRegistry extends EPackageRegistryImpl {
	private static final long serialVersionUID = 1L;
	public static final String CLASSNAME = VMMPackageRegistry.class.getName();
	private static Map<String, HashMap<String, Object>> vmmDomainPackageMap = new HashMap();
	private static boolean debugEnabled = EPackageRegistryImpl.debugEnabled();

	private Object vmmget(Object var1) {
		Object var2 = null;
		String var3 = "admin";
		String var4 = "vmmget";
		if (vmmDomainPackageMap.size() > 0) {
			var3 = EMFDomainUtils.getDomainId();
			var2 = vmmDomainPackageMap.get(var3) != null ? ((HashMap) vmmDomainPackageMap.get(var3)).get(var1) : null;
		}

		if (var2 != null && debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var4,
					"Found the package " + (String) var1 + " in domain : " + var3 + " map");
		}

		if (var2 == null) {
			var2 = super.get(var1);
			if (var2 != null && debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var4,
						"Found the package " + (String) var1 + " in original package map");
			}
		}

		return var2;
	}

	private Object vmmput(Object var1, Object var2) {
		String var3 = "vmmput";
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var3, "ENTER key", var1);
			DebugStreamInstance.debug(CLASSNAME, var3, "ENTER value", var2);
		}

		Object var4 = null;
		String var5 = EMFDomainUtils.getDomainId();
		synchronized (this) {
			if (vmmDomainPackageMap.get(var5) == null) {
				vmmDomainPackageMap.put(var5, new HashMap());
				if (debugEnabled) {
					DebugStreamInstance.debug(CLASSNAME, var3, "Created package map for domain:", var5);
				}
			}
		}

		var4 = ((HashMap) vmmDomainPackageMap.get(var5)).put((String) var1, var2);
		if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var3,
					"Stored package:" + (String) var1 + " in domain " + var5 + " package map");
			DebugStreamInstance.debug(CLASSNAME, var3, "RETURN - oldValue", var4);
		}

		return var4;
	}

	private Set vmmentrySet() {
		String var1 = "vmmentrySet";
		if (vmmDomainPackageMap.size() == 0) {
			return super.entrySet();
		} else {
			HashSet var2 = new HashSet();
			String var3 = EMFDomainUtils.getDomainId();
			if (vmmDomainPackageMap.get(var3) == null) {
				super.entrySet();
			}

			Set var4 = super.entrySet();
			if (var4 != null) {
				var2.addAll(var4);
			}

			Set var5 = ((HashMap) vmmDomainPackageMap.get(var3)).entrySet();
			if (var5 != null) {
				var2.addAll(var5);
			}

			if (var2.size() > 0) {
				if (debugEnabled) {
					DebugStreamInstance.debug(CLASSNAME, var1,
							"Obtained entryset=" + var2 + " from domain " + var3 + " package map and original map");
				}

				return var2;
			} else {
				return null;
			}
		}
	}

	private Set vmmkeySet() {
		String var1 = "vmmkeySet";
		if (vmmDomainPackageMap.size() == 0) {
			return super.keySet();
		} else {
			HashSet var2 = new HashSet();
			String var3 = EMFDomainUtils.getDomainId();
			if (vmmDomainPackageMap.get(var3) == null) {
				return super.keySet();
			} else {
				Set var4 = super.keySet();
				if (var4 != null) {
					var2.addAll(var4);
				}

				Set var5 = ((HashMap) vmmDomainPackageMap.get(var3)).keySet();
				if (var5 != null) {
					var2.addAll(var5);
				}

				if (var2.size() > 0) {
					if (debugEnabled) {
						DebugStreamInstance.debug(CLASSNAME, var1,
								"Obtained keyset=" + var2 + " from domain " + var3 + " package map and original map");
					}

					return var2;
				} else {
					return null;
				}
			}
		}
	}

	private int vmmsize() {
		String var1 = "vmmsize";
		int var2 = 0;
		if (vmmDomainPackageMap.size() == 0) {
			return super.size();
		} else {
			String var3 = EMFDomainUtils.getDomainId();
			if (vmmDomainPackageMap.get(var3) != null) {
				var2 = ((HashMap) vmmDomainPackageMap.get(var3)).size() + super.size();
				if (debugEnabled) {
					DebugStreamInstance.debug(CLASSNAME, var1,
							"Obtained size=" + var2 + "from domain" + var3 + " package map and orginal map");
				}
			}

			return var2;
		}
	}

	private Object vmmremove(Object var1) {
		String var2 = "vmmremove";
		Object var3 = null;
		if (vmmDomainPackageMap.size() == 0) {
			return null;
		} else {
			String var4 = EMFDomainUtils.getDomainId();
			if (vmmDomainPackageMap.get(var4) != null) {
				var3 = ((HashMap) vmmDomainPackageMap.get(var4)).remove(var1);
				if (var3 != null && debugEnabled) {
					DebugStreamInstance.debug(CLASSNAME, var2,
							"Removed the key=" + var1 + "from domain" + var4 + " package map");
				}
			}

			return var3;
		}
	}

	private void vmmclear() {
		String var1 = "vmmclear";
		if (vmmDomainPackageMap.size() != 0) {
			String var2 = EMFDomainUtils.getDomainId();
			if (vmmDomainPackageMap.get(var2) != null) {
				((HashMap) vmmDomainPackageMap.get(var2)).clear();
				if (debugEnabled) {
					DebugStreamInstance.debug(CLASSNAME, var1, "Clears the domain +" + var2 + " package map");
				}
			}

		}
	}

	private Collection vmmvalues() {
		String var1 = "vmmvalues";
		if (vmmDomainPackageMap.size() == 0) {
			return super.values();
		} else {
			ArrayList var2 = new ArrayList();
			String var3 = EMFDomainUtils.getDomainId();
			if (vmmDomainPackageMap.get(var3) == null) {
				return super.values();
			} else {
				Collection var4 = ((HashMap) vmmDomainPackageMap.get(var3)).values();
				if (var4 != null) {
					var2.addAll(var4);
				}

				Collection var5 = super.values();
				if (var5 != null) {
					var2.addAll(var5);
				}

				if (debugEnabled) {
					DebugStreamInstance.debug(CLASSNAME, var1,
							"RETURNED values=" + var2 + " from domain " + var3 + " package map and original map");
				}

				return var2;
			}
		}
	}

	private boolean vmmcontainsValue(Object var1) {
		boolean var2 = false;
		String var3 = "vmmcontainsValue";
		if (vmmDomainPackageMap.size() == 0) {
			return false;
		} else {
			String var4 = EMFDomainUtils.getDomainId();
			if (vmmDomainPackageMap.get(var4) != null) {
				var2 = ((HashMap) vmmDomainPackageMap.get(var4)).containsValue(var1);
				if (var2 && debugEnabled) {
					DebugStreamInstance.debug(CLASSNAME, var3,
							"Found the value=" + var1 + " in domain " + var4 + " package map");
				}
			}

			return var2;
		}
	}

	private boolean vmmcontainsKey(Object var1) {
		boolean var2 = false;
		String var3 = "vmmcontainsKey";
		if (vmmDomainPackageMap.size() == 0) {
			return false;
		} else {
			String var4 = EMFDomainUtils.getDomainId();
			if (vmmDomainPackageMap.get(var4) != null) {
				var2 = ((HashMap) vmmDomainPackageMap.get(var4)).containsKey(var1);
				if (var2 && debugEnabled) {
					DebugStreamInstance.debug(CLASSNAME, var3,
							"Found the key=" + var1 + " in domain " + var4 + " package map");
				}
			}

			return var2;
		}
	}

	private boolean vmmisEmpty() {
		boolean var1 = true;
		if (vmmDomainPackageMap.size() == 0) {
			return true;
		} else {
			String var2 = EMFDomainUtils.getDomainId();
			if (vmmDomainPackageMap.get(var2) != null) {
				var1 = ((HashMap) vmmDomainPackageMap.get(var2)).isEmpty();
			}

			return var1;
		}
	}

	public VMMPackageRegistry() {
	}

	public VMMPackageRegistry(Registry var1) {
		super(var1);
	}

	public Object get(Object var1) {
		Object var2 = null;
		var2 = this.vmmget(var1);
		return var2;
	}

	public Object put(Object var1, Object var2) {
		Object var3 = null;
		String var4 = "put";
		if (EMFDomainUtils.isInVMMDomainThreadContext()) {
			this.vmmput(var1, var2);
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var4,
						"Stored the package " + (String) var1 + " in domain package map");
			}
		} else {
			super.put(var1, var2);
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var4,
						"Stored the package " + (String) var1 + " in original package map");
			}
		}

		return var2;
	}

	public void putAll(Map var1) {
		Iterator var2 = var1.entrySet().iterator();

		while (var2.hasNext()) {
			Entry var3 = (Entry) var2.next();
			this.put(var3.getKey(), var3.getValue());
		}

	}

	public void clear() {
		super.clear();
		this.vmmclear();
	}

	public Set keySet() {
		Set var1 = null;
		String var2 = "keySet";
		if (EMFDomainUtils.isInVMMDomainThreadContext()) {
			var1 = this.vmmkeySet();
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2,
						"Obtained keySet=" + var1 + "from domain and original package map backed by a duplicate map");
			}
		} else {
			var1 = super.keySet();
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2,
						"Obtained keySet=" + var1 + " from original package map backed by the original package map");
			}
		}

		return var1;
	}

	public Collection values() {
		Collection var1 = null;
		String var2 = "values";
		if (EMFDomainUtils.isInVMMDomainThreadContext()) {
			var1 = this.vmmvalues();
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2, "Obtained values=" + var1
						+ " from domain package map and original package map backed by duplicate map");
			}
		} else {
			var1 = super.values();
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2,
						"Obtained values=" + var1 + " from original package map backed by original package map");
			}
		}

		return var1;
	}

	public Set entrySet() {
		Set var1 = null;
		String var2 = "entrySet";
		if (EMFDomainUtils.isInVMMDomainThreadContext()) {
			var1 = this.vmmentrySet();
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2, "Obtained entrySet=" + var1
						+ " from domain package map and original package map backed by duplicate map");
			}
		} else {
			var1 = super.entrySet();
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2,
						"Obtained entrySet=" + var1 + " from original package map backed by original package map");
			}
		}

		return var1;
	}

	public int size() {
		boolean var1 = false;
		String var2 = "size";
		int var3;
		if (EMFDomainUtils.isInVMMDomainThreadContext()) {
			var3 = this.vmmsize();
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2,
						"Obtained size=" + var3 + " from domain package map and original package map");
			}
		} else {
			var3 = super.size();
			if (debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var2, "Obtained size=" + var3 + "from original package map");
			}
		}

		return var3;
	}

	public Object remove(Object var1) {
		Object var2 = null;
		String var3 = "remove";
		var2 = super.remove(var1);
		if (var2 == null) {
			var2 = this.vmmremove(var1);
			if (var2 != null && debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var3, "Removed the key=" + var1 + " from dmain map");
			}
		} else if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var3, "Removed the key=" + var1 + " from original package map");
		}

		return var2;
	}

	public boolean containsValue(Object var1) {
		boolean var2 = false;
		String var3 = "containsValue";
		var2 = super.containsValue(var1);
		if (!var2) {
			var2 = this.vmmcontainsValue(var1);
			if (var2 && debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var3, "Found the value=" + var1 + " in domain package map");
			}
		} else if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var3, "Found the value=" + var1 + " in original package map");
		}

		return var2;
	}

	public boolean containsKey(Object var1) {
		boolean var2 = false;
		String var3 = "containsValue";
		var2 = super.containsKey(var1);
		if (!var2) {
			var2 = this.vmmcontainsKey(var1);
			if (var2 && debugEnabled) {
				DebugStreamInstance.debug(CLASSNAME, var3, "Found the key=" + var1 + " in domain package map");
			}
		} else if (debugEnabled) {
			DebugStreamInstance.debug(CLASSNAME, var3, "Found the key=" + var1 + " in original package map");
		}

		return var2;
	}

	public boolean isEmpty() {
		boolean var1 = true;
		var1 = super.isEmpty();
		if (var1) {
			var1 = this.vmmisEmpty();
		}

		return var1;
	}
}