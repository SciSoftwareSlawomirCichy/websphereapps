package com.ibm.ws.wim.policy.ldap;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.policy.PolicyHandler;
import java.util.logging.Logger;

public class TDSHandler extends PolicyHandler {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2014;
		CLASSNAME = TDSHandler.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}