package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface LdapServersType {
	List getConnections();

	ConnectionsType[] getConnectionsAsArray();

	ConnectionsType createConnections();

	List getEnvironmentProperties();

	EnvironmentPropertiesType[] getEnvironmentPropertiesAsArray();

	EnvironmentPropertiesType createEnvironmentProperties();

	String getAuthentication();

	void setAuthentication(String var1);

	void unsetAuthentication();

	boolean isSetAuthentication();

	String getBindDN();

	void setBindDN(String var1);

	String getBindPassword();

	void setBindPassword(String var1);

	boolean isConnectionPool();

	void setConnectionPool(boolean var1);

	void unsetConnectionPool();

	boolean isSetConnectionPool();

	int getConnectTimeout();

	void setConnectTimeout(int var1);

	void unsetConnectTimeout();

	boolean isSetConnectTimeout();

	String getDerefAliases();

	void setDerefAliases(String var1);

	void unsetDerefAliases();

	boolean isSetDerefAliases();

	String getReferal();

	void setReferal(String var1);

	void unsetReferal();

	boolean isSetReferal();

	boolean isSslEnabled();

	void setSslEnabled(boolean var1);

	void unsetSslEnabled();

	boolean isSetSslEnabled();
}