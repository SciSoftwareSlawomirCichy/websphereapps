package com.ibm.ws.wim.security.authz.jacc;

import java.io.Serializable;
import java.security.Principal;

public class GroupPrincipal implements Serializable, Principal {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String principalName;

	public GroupPrincipal(String var1) {
		this.principalName = var1;
	}

	public String getName() {
		return this.principalName;
	}

	public boolean equals(Object var1) {
		return var1 instanceof GroupPrincipal && ((GroupPrincipal) var1).getName().equals(this.principalName);
	}

	public int hashCode() {
		return this.principalName.hashCode();
	}
}