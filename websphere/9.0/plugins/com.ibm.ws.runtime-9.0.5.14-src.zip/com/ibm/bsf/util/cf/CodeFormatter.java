package com.ibm.bsf.util.cf;

import com.ibm.bsf.util.IndentWriter;
import com.ibm.bsf.util.StringUtils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

public class CodeFormatter {
	public static final int DEFAULT_MAX = 74;
	public static final int DEFAULT_STEP = 2;
	public static final String DEFAULT_DELIM = "(+";
	public static final String DEFAULT_S_DELIM = ",";
	private int maxLineLength = 74;
	private int indentationStep = 2;
	private String delimiters = "(+";
	private String stickyDelimiters = ",";
	private int indent;
	private int hangingIndent;
	private int origIndent;
	private boolean inCPP_Comment;

	private void addTok(StringBuffer var1, StringBuffer var2, IndentWriter var3) {
		int var4 = var2.length();
		int var5 = var1.length();
		if (this.indent + var5 + var4 > this.maxLineLength) {
			if (var5 == 0) {
				var3.println(this.indent, var2.toString());
				this.indent = this.hangingIndent;
				var1.setLength(0);
				return;
			}

			var3.println(this.indent, var1.toString().trim());
			this.indent = this.hangingIndent;
			var1.setLength(0);
		}

		var1.append(var2.toString());
	}

	public void formatCode(Reader var1, Writer var2) {
		BufferedReader var4 = new BufferedReader(var1);
		IndentWriter var5 = new IndentWriter(new BufferedWriter(var2), true);

		try {
			this.origIndent = 0;
			this.inCPP_Comment = false;

			String var3;
			while ((var3 = var4.readLine()) != null) {
				var3 = var3.trim();
				if (var3.length() > 0) {
					this.indent = this.origIndent;
					this.hangingIndent = this.indent + this.indentationStep;
					this.printLine(var3, var5);
				} else {
					var5.println();
				}
			}
		} catch (IOException var7) {
			var7.printStackTrace();
		}

	}

	public String getDelimiters() {
		return this.delimiters;
	}

	public int getIndentationStep() {
		return this.indentationStep;
	}

	public int getMaxLineLength() {
		return this.maxLineLength;
	}

	public String getStickyDelimiters() {
		return this.stickyDelimiters;
	}

	private void printLine(String var1, IndentWriter var2) {
		char[] var3 = var1.toCharArray();
		char var5 = ' ';
		boolean var6 = false;
		boolean var7 = false;
		StringBuffer var8 = new StringBuffer();
		StringBuffer var9 = new StringBuffer(this.hangingIndent + var1.length());

		for (int var10 = 0; var10 < var3.length; ++var10) {
			char var4 = var3[var10];
			if (var6) {
				var8.append(var4);
				var6 = false;
			} else if (var7) {
				switch (var4) {
					case '\t' :
						var8.append(var4);
						break;
					case '"' :
					case '\'' :
						var8.append(var4);
						if (var4 == var5) {
							this.addTok(var9, var8, var2);
							var8.setLength(0);
							var7 = false;
						}
						break;
					case '\\' :
						var8.append('\\');
						var6 = true;
						break;
					default :
						if (var4 > 31) {
							var8.append(var4);
						}
				}
			} else if (this.inCPP_Comment) {
				var8.append(var4);
				if (var4 == '/' && var10 > 0 && var3[var10 - 1] == '*') {
					this.inCPP_Comment = false;
				}
			} else {
				switch (var4) {
					case '\t' :
						var8.append(StringUtils.getChars(this.indentationStep, ' '));
						break;
					case '"' :
					case '\'' :
						this.addTok(var9, var8, var2);
						var8.setLength(0);
						var8.append(var4);
						var5 = var4;
						var7 = true;
						break;
					case '*' :
						var8.append(var4);
						if (var10 > 0 && var3[var10 - 1] == '/') {
							this.inCPP_Comment = true;
						}
						break;
					case '/' :
						var8.append(var4);
						if (var10 > 0 && var3[var10 - 1] == '/') {
							String var11 = var8.append(var3, var10 + 1, var3.length - (var10 + 1)).toString();
							var2.println(this.indent, var9.append(var11).toString());
							return;
						}
						break;
					case '{' :
						var8.append(var4);
						this.origIndent += this.indentationStep;
						break;
					case '}' :
						var8.append(var4);
						this.origIndent -= this.indentationStep;
						if (var10 == 0) {
							this.indent = this.origIndent;
						}
						break;
					default :
						if (var4 > 31) {
							if (this.delimiters.indexOf(var4) != -1) {
								this.addTok(var9, var8, var2);
								var8.setLength(0);
								var8.append(var4);
							} else if (this.stickyDelimiters.indexOf(var4) != -1) {
								var8.append(var4);
								this.addTok(var9, var8, var2);
								var8.setLength(0);
							} else {
								var8.append(var4);
							}
						}
				}
			}
		}

		if (var8.length() > 0) {
			this.addTok(var9, var8, var2);
		}

		String var12 = var9.toString().trim();
		if (var12.length() > 0) {
			var2.println(this.indent, var12);
		}

	}

	public void setDelimiters(String var1) {
		this.delimiters = var1;
	}

	public void setIndentationStep(int var1) {
		this.indentationStep = var1 < 0 ? 0 : var1;
	}

	public void setMaxLineLength(int var1) {
		this.maxLineLength = var1 < 0 ? 0 : var1;
	}

	public void setStickyDelimiters(String var1) {
		this.stickyDelimiters = var1;
	}
}