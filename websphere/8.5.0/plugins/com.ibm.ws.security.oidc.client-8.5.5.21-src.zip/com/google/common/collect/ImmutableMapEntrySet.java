package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.collect.ImmutableMapEntrySet.EntrySetSerializedForm;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
abstract class ImmutableMapEntrySet<K, V> extends ImmutableSet<Entry<K, V>> {
	abstract ImmutableMap<K, V> map();

	public int size() {
		return this.map().size();
	}

	public boolean contains(@NullableDecl Object object) {
		if (!(object instanceof Entry)) {
			return false;
		} else {
			Entry<?, ?> entry = (Entry) object;
			V value = this.map().get(entry.getKey());
			return value != null && value.equals(entry.getValue());
		}
	}

	boolean isPartialView() {
		return this.map().isPartialView();
	}

	@GwtIncompatible
	boolean isHashCodeFast() {
		return this.map().isHashCodeFast();
	}

	public int hashCode() {
		return this.map().hashCode();
	}

	@GwtIncompatible
	Object writeReplace() {
		return new EntrySetSerializedForm(this.map());
	}
}