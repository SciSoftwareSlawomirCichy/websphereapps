package com.google.inject.internal.cglib.core;

import com.google.inject.internal.asm.ClassWriter;
import com.google.inject.internal.cglib.core.DebuggingClassWriter.1;
import java.security.AccessController;

public class DebuggingClassWriter extends ClassWriter {
	public static final String DEBUG_LOCATION_PROPERTY = "cglib.debugLocation";
	private static String debugLocation = System.getProperty("cglib.debugLocation");
	private static boolean traceEnabled;
	private String className;
	private String superName;

	public DebuggingClassWriter(int flags) {
		super(flags);
	}

	public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
		this.className = name.replace('/', '.');
		this.superName = superName.replace('/', '.');
		super.visit(version, access, name, signature, superName, interfaces);
	}

	public String getClassName() {
		return this.className;
	}

	public String getSuperName() {
		return this.superName;
	}

	public byte[] toByteArray() {
      return (byte[])((byte[])AccessController.doPrivileged(new 1(this)));
   }

	static {
		if (debugLocation != null) {
			System.err.println("CGLIB debugging enabled, writing to '" + debugLocation + "'");

			try {
				Class.forName("com.google.inject.internal.asm.util.TraceClassVisitor");
				traceEnabled = true;
			} catch (Throwable var1) {
				;
			}
		}

	}
}