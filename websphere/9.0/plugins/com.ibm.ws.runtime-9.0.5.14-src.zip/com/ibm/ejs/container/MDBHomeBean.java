package com.ibm.ejs.container;

import com.ibm.ejs.jms.listener.MDBListener;
import com.ibm.ejs.jms.listener.MDBListenerManager;
import com.ibm.ejs.jms.listener.MDBPool;
import com.ibm.websphere.csi.EJBConfigData;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.component.WASEJBRuntime;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.jms.MessageListener;
import javax.resource.ResourceException;

public class MDBHomeBean extends EJSHome implements MDBPool, MDBInternalHome {
	private static final long serialVersionUID = -3269027470663262731L;
	private static final String CLASS_NAME = "com.ibm.ejs.container.MDBHomeBean";
	private MDBListener messageListener = null;
	private EJBConfigData ivConfigData;

	public MDBHomeBean() throws RemoteException {
	}

	public void initialize(EJSContainer ejbContainer, BeanId id, BeanMetaData bmd) throws RemoteException {
		WASBeanMetaData wasBMD = (WASBeanMetaData) bmd;
		this.ivConfigData = wasBMD.ejbConfigData;
		super.initialize(ejbContainer, id, bmd);
	}

	public MessageListener create() throws CreateException, RemoteException {
		BeanO beanO = null;
		MessageListener result = null;
		boolean createFailed = false;

		try {
			result = (MessageListener) super.createWrapper_Local((BeanId) null);
		} catch (CreateException var10) {
			FFDCFilter.processException(var10, "com.ibm.ejs.container.MDBHomeBean.create", "60", this);
			createFailed = true;
			throw var10;
		} catch (RemoteException var11) {
			FFDCFilter.processException(var11, "com.ibm.ejs.container.MDBHomeBean.create", "64", this);
			createFailed = true;
			throw var11;
		} catch (Throwable var12) {
			FFDCFilter.processException(var12, "com.ibm.ejs.container.MDBHomeBean.create", "68", this);
			createFailed = true;
			throw new CreateFailureException(var12);
		} finally {
			if (createFailed) {
				super.createFailure((BeanO) beanO);
			}

		}

		return result;
	}

	public MDBListener getMessageListener() {
		return this.messageListener;
	}

	public void setMessageListener(MDBListener mdbListener) {
		this.messageListener = mdbListener;
	}

	public MessageListener getMDB() {
		MessageListener result = null;

		try {
			result = this.create();
			return result;
		} catch (Exception var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.MDBHomeBean.getMDB", "99", this);
			throw new EJBException("Unable to obtain MDB Instance from pool", var3);
		}
	}

	public void returnMDB(MessageListener wrapper) {
		try {
			this.wrapperManager.unregister(((MDBWrapper) wrapper).beanId, true);
		} catch (Exception var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.container.MDBHomeBean.returnMDB", "115", this);
			throw new EJBException("Unable to remove wrapper from wrapper cache", var3);
		}
	}

	public void activateEndpoint() throws ResourceException {
		MDBListenerManager mdbListenManager = ((WASEJBRuntime) this.container.getEJBRuntime()).getMDBListenerManager();
		if (mdbListenManager != null) {
			try {
				this.messageListener = mdbListenManager.create(this, this.ivConfigData);
			} catch (Throwable var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.MDBHomeBean.activateEndpoint", "113", this);
				throw new ResourceException(var3);
			}

			this.ivConfigData = null;
		}

	}

	public void deactivateEndpoint() throws ResourceException {
		MDBListenerManager mdbListenManager = ((WASEJBRuntime) this.container.getEJBRuntime()).getMDBListenerManager();
		if (mdbListenManager != null && this.messageListener != null) {
			mdbListenManager.remove(this.messageListener);
		}

	}
}