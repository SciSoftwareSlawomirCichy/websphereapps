package com.ibm.ejs.container.interceptors;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.dopriv.SetAccessiblePrivilegedAction;
import com.ibm.ws.ffdc.FFDCFilter;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import javax.interceptor.InvocationContext;

public class InterceptorProxy {
	private static final String CLASS_NAME = InterceptorProxy.class.getName();
	private static final TraceComponent tc = Tr.register(InterceptorProxy.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final Object[] NO_ARGS = new Object[0];
	public final Method ivInterceptorMethod;
	final int ivInterceptorIndex;
	final boolean ivBeanInterceptor;
	final boolean ivRequiresInvocationContext;

	public InterceptorProxy(Method m, int interceptorIndex) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "InterceptorProxy");
		}

		this.ivInterceptorIndex = interceptorIndex;
		this.ivInterceptorMethod = m;
		this.ivBeanInterceptor = interceptorIndex < 0;
		this.ivRequiresInvocationContext = m.getParameterTypes().length > 0;
		SetAccessiblePrivilegedAction priviledgedAction = new SetAccessiblePrivilegedAction();
		priviledgedAction.setParameters(m, true);

		try {
			AccessController.doPrivileged(priviledgedAction);
		} catch (PrivilegedActionException var9) {
			FFDCFilter.processException(var9, CLASS_NAME + ".<init>", "178", this);
			SecurityException ex = (SecurityException) var9.getException();
			throw ex;
		} finally {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, this.toString());
			}

		}

	}

	public final Object invokeInterceptor(Object bean, InvocationContext inv, Object[] interceptors) throws Exception {
		Object interceptorInstance = this.ivBeanInterceptor ? bean : interceptors[this.ivInterceptorIndex];
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "invoking " + this);
			Tr.debug(tc, "interceptor instance = " + interceptorInstance);
		}

		if (this.ivRequiresInvocationContext) {
			Object[] args = new Object[]{inv};
			return this.ivInterceptorMethod.invoke(interceptorInstance, args);
		} else {
			return this.ivInterceptorMethod.invoke(interceptorInstance, NO_ARGS);
		}
	}

	public String toString() {
		return "InterceptorProxy(" + this.ivInterceptorIndex + "): " + this.ivInterceptorMethod.toGenericString();
	}

	public String getMethodGenericString() {
		return this.ivInterceptorMethod.toGenericString();
	}
}