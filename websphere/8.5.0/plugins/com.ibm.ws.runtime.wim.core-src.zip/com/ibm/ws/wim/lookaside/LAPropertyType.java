package com.ibm.ws.wim.lookaside;

public class LAPropertyType {
	private String datatypeId;
	private String description;

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String var1) {
		this.description = var1;
	}

	public String getDatatypeId() {
		return this.datatypeId;
	}

	public void setDatatypeId(String var1) {
		this.datatypeId = var1;
	}
}