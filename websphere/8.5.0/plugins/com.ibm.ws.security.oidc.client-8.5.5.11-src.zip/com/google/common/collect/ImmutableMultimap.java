package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.ImmutableMultimap.1;
import com.google.common.collect.ImmutableMultimap.Builder;
import com.google.common.collect.ImmutableMultimap.EntryCollection;
import com.google.common.collect.ImmutableMultimap.Keys;
import com.google.common.collect.ImmutableMultimap.Values;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(emulated = true)
public abstract class ImmutableMultimap<K, V> extends AbstractMultimap<K, V> implements Serializable {
	final transient ImmutableMap<K, ? extends ImmutableCollection<V>> map;
	final transient int size;
	private static final long serialVersionUID = 0L;

	public static <K, V> ImmutableMultimap<K, V> of() {
		return ImmutableListMultimap.of();
	}

	public static <K, V> ImmutableMultimap<K, V> of(K k1, V v1) {
		return ImmutableListMultimap.of(k1, v1);
	}

	public static <K, V> ImmutableMultimap<K, V> of(K k1, V v1, K k2, V v2) {
		return ImmutableListMultimap.of(k1, v1, k2, v2);
	}

	public static <K, V> ImmutableMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		return ImmutableListMultimap.of(k1, v1, k2, v2, k3, v3);
	}

	public static <K, V> ImmutableMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
		return ImmutableListMultimap.of(k1, v1, k2, v2, k3, v3, k4, v4);
	}

	public static <K, V> ImmutableMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
		return ImmutableListMultimap.of(k1, v1, k2, v2, k3, v3, k4, v4, k5, v5);
	}

	public static <K, V> Builder<K, V> builder() {
		return new Builder();
	}

	public static <K, V> ImmutableMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap) {
		if (multimap instanceof ImmutableMultimap) {
			ImmutableMultimap<K, V> kvMultimap = (ImmutableMultimap) multimap;
			if (!kvMultimap.isPartialView()) {
				return kvMultimap;
			}
		}

		return ImmutableListMultimap.copyOf(multimap);
	}

	ImmutableMultimap(ImmutableMap<K, ? extends ImmutableCollection<V>> map, int size) {
		this.map = map;
		this.size = size;
	}

	@Deprecated
	public ImmutableCollection<V> removeAll(Object key) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public ImmutableCollection<V> replaceValues(K key, Iterable<? extends V> values) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public void clear() {
		throw new UnsupportedOperationException();
	}

	public abstract ImmutableCollection<V> get(K var1);

	public abstract ImmutableMultimap<V, K> inverse();

	@Deprecated
	public boolean put(K key, V value) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public boolean putAll(K key, Iterable<? extends V> values) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public boolean putAll(Multimap<? extends K, ? extends V> multimap) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	public boolean remove(Object key, Object value) {
		throw new UnsupportedOperationException();
	}

	boolean isPartialView() {
		return this.map.isPartialView();
	}

	public boolean containsKey(@Nullable Object key) {
		return this.map.containsKey(key);
	}

	public int size() {
		return this.size;
	}

	public ImmutableSet<K> keySet() {
		return this.map.keySet();
	}

	public ImmutableMap<K, Collection<V>> asMap() {
		return this.map;
	}

	Map<K, Collection<V>> createAsMap() {
		throw new AssertionError("should never be called");
	}

	public ImmutableCollection<Entry<K, V>> entries() {
		return (ImmutableCollection) super.entries();
	}

	ImmutableCollection<Entry<K, V>> createEntries() {
		return new EntryCollection(this);
	}

	UnmodifiableIterator<Entry<K, V>> entryIterator() {
      Iterator<? extends Entry<K, ? extends ImmutableCollection<V>>> mapIterator = this.map.entrySet().iterator();
      return new 1(this, mapIterator);
   }

	public ImmutableMultiset<K> keys() {
		return (ImmutableMultiset) super.keys();
	}

	ImmutableMultiset<K> createKeys() {
		return new Keys(this);
	}

	public ImmutableCollection<V> values() {
		return (ImmutableCollection) super.values();
	}

	ImmutableCollection<V> createValues() {
		return new Values(this);
	}
}