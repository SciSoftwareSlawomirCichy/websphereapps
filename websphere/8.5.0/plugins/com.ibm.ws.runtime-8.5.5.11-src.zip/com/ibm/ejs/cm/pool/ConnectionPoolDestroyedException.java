package com.ibm.ejs.cm.pool;

import com.ibm.ejs.cm.portability.PortableSQLException;

public class ConnectionPoolDestroyedException extends PortableSQLException {
	private static final long serialVersionUID = -5435619454496842500L;

	ConnectionPoolDestroyedException() {
		super("The connection pool has been destroyed");
	}
}