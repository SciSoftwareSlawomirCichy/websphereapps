package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_en extends ListResourceBundle {
	private static final Object[][] resources = new Object[0][];

	public Object[][] getContents() {
		return resources;
	}
}