package com.google.inject.internal;

import com.google.inject.internal.ImmutableList.1;
import com.google.inject.internal.ImmutableList.Builder;
import com.google.inject.internal.ImmutableList.SerializedForm;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public abstract class ImmutableList<E> extends ImmutableCollection<E> implements List<E>, RandomAccess {
	private static final ImmutableList<?> EMPTY_IMMUTABLE_LIST = new ImmutableList.EmptyImmutableList((1)null);

	public static <E> ImmutableList<E> of() {
		return EMPTY_IMMUTABLE_LIST;
	}

	public static <E> ImmutableList<E> of(E element) {
      return new ImmutableList.RegularImmutableList(copyIntoArray(element), (1)null);
   }

	public static <E> ImmutableList<E> of(E e1, E e2) {
      return new ImmutableList.RegularImmutableList(copyIntoArray(e1, e2), (1)null);
   }

	public static <E> ImmutableList<E> of(E e1, E e2, E e3) {
      return new ImmutableList.RegularImmutableList(copyIntoArray(e1, e2, e3), (1)null);
   }

	public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4) {
      return new ImmutableList.RegularImmutableList(copyIntoArray(e1, e2, e3, e4), (1)null);
   }

	public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5) {
      return new ImmutableList.RegularImmutableList(copyIntoArray(e1, e2, e3, e4, e5), (1)null);
   }

	public static <E> ImmutableList<E> of(E... elements) {
      return (ImmutableList)(elements.length == 0 ? of() : new ImmutableList.RegularImmutableList(copyIntoArray(elements), (1)null));
   }

	public static <E> ImmutableList<E> copyOf(Iterable<? extends E> elements) {
		if (elements instanceof ImmutableList) {
			ImmutableList<E> list = (ImmutableList) elements;
			return list;
		} else if (elements instanceof Collection) {
			Collection<? extends E> coll = (Collection) elements;
			return copyOfInternal(coll);
		} else {
			return copyOfInternal(Lists.newArrayList(elements));
		}
	}

	public static <E> ImmutableList<E> copyOf(Iterator<? extends E> elements) {
		return copyOfInternal(Lists.newArrayList(elements));
	}

	private static <E> ImmutableList<E> copyOfInternal(ArrayList<? extends E> list) {
      return (ImmutableList)(list.isEmpty() ? of() : new ImmutableList.RegularImmutableList(nullChecked(list.toArray()), (1)null));
   }

	private static Object[] nullChecked(Object[] array) {
		int i = 0;

		for (int len = array.length; i < len; ++i) {
			if (array[i] == null) {
				throw new NullPointerException("at index " + i);
			}
		}

		return array;
	}

	private static <E> ImmutableList<E> copyOfInternal(Collection<? extends E> collection) {
		int size = collection.size();
		return size == 0 ? of() : createFromIterable(collection, size);
	}

	private ImmutableList() {
	}

	public abstract UnmodifiableIterator<E> iterator();

	public abstract int indexOf(@Nullable Object var1);

	public abstract int lastIndexOf(@Nullable Object var1);

	public abstract ImmutableList<E> subList(int var1, int var2);

	public final boolean addAll(int index, Collection<? extends E> newElements) {
		throw new UnsupportedOperationException();
	}

	public final E set(int index, E element) {
		throw new UnsupportedOperationException();
	}

	public final void add(int index, E element) {
		throw new UnsupportedOperationException();
	}

	public final E remove(int index) {
		throw new UnsupportedOperationException();
	}

	private static Object[] copyIntoArray(Object... source) {
		Object[] array = new Object[source.length];
		int index = 0;
		Object[] arr$ = source;
		int len$ = source.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			Object element = arr$[i$];
			if (element == null) {
				throw new NullPointerException("at index " + index);
			}

			array[index++] = element;
		}

		return array;
	}

	private static <E> ImmutableList<E> createFromIterable(Iterable<?> source, int estimatedSize) {
      Object[] array = new Object[estimatedSize];
      int index = 0;

      Object element;
      for(Iterator i$ = source.iterator(); i$.hasNext(); array[index++] = element) {
         element = i$.next();
         if (index == estimatedSize) {
            estimatedSize = (estimatedSize / 2 + 1) * 3;
            array = copyOf(array, estimatedSize);
         }

         if (element == null) {
            throw new NullPointerException("at index " + index);
         }
      }

      if (index == 0) {
         return of();
      } else {
         if (index != estimatedSize) {
            array = copyOf(array, index);
         }

         return new ImmutableList.RegularImmutableList(array, 0, index, (1)null);
      }
   }

	private static Object[] copyOf(Object[] oldArray, int newSize) {
		Object[] newArray = new Object[newSize];
		System.arraycopy(oldArray, 0, newArray, 0, Math.min(oldArray.length, newSize));
		return newArray;
	}

	private void readObject(ObjectInputStream stream) throws InvalidObjectException {
		throw new InvalidObjectException("Use SerializedForm");
	}

	Object writeReplace() {
		return new SerializedForm(this.toArray());
	}

	public static <E> Builder<E> builder() {
		return new Builder();
	}

	private static final class RegularImmutableList<E> extends ImmutableList<E> {
		private final int offset;
		private final int size;
		private final Object[] array;

		private RegularImmutableList(Object[] array, int offset, int size) {
         super((1)null);
         this.offset = offset;
         this.size = size;
         this.array = array;
      }

		private RegularImmutableList(Object[] array) {
			this(array, 0, array.length);
		}

		public int size() {
			return this.size;
		}

		public boolean isEmpty() {
			return false;
		}

		public boolean contains(Object target) {
			return this.indexOf(target) != -1;
		}

		public UnmodifiableIterator<E> iterator() {
			return Iterators.forArray(this.array, this.offset, this.size);
		}

		public Object[] toArray() {
			Object[] newArray = new Object[this.size()];
			System.arraycopy(this.array, this.offset, newArray, 0, this.size);
			return newArray;
		}

		public <T> T[] toArray(T[] other) {
			if (other.length < this.size) {
				other = ObjectArrays.newArray(other, this.size);
			} else if (other.length > this.size) {
				other[this.size] = null;
			}

			System.arraycopy(this.array, this.offset, other, 0, this.size);
			return other;
		}

		public E get(int index) {
			Preconditions.checkElementIndex(index, this.size);
			return this.array[index + this.offset];
		}

		public int indexOf(Object target) {
			if (target != null) {
				for (int i = this.offset; i < this.offset + this.size; ++i) {
					if (this.array[i].equals(target)) {
						return i - this.offset;
					}
				}
			}

			return -1;
		}

		public int lastIndexOf(Object target) {
			if (target != null) {
				for (int i = this.offset + this.size - 1; i >= this.offset; --i) {
					if (this.array[i].equals(target)) {
						return i - this.offset;
					}
				}
			}

			return -1;
		}

		public ImmutableList<E> subList(int fromIndex, int toIndex) {
			Preconditions.checkPositionIndexes(fromIndex, toIndex, this.size);
			return (ImmutableList) (fromIndex == toIndex
					? ImmutableList.of()
					: new ImmutableList.RegularImmutableList(this.array, this.offset + fromIndex, toIndex - fromIndex));
		}

		public ListIterator<E> listIterator() {
			return this.listIterator(0);
		}

		public ListIterator<E> listIterator(int start) {
         Preconditions.checkPositionIndex(start, this.size);
         return new com.google.inject.internal.ImmutableList.RegularImmutableList.1(this, start);
      }

		public boolean equals(@Nullable Object object) {
			if (object == this) {
				return true;
			} else if (!(object instanceof List)) {
				return false;
			} else {
				List<?> that = (List) object;
				if (this.size() != that.size()) {
					return false;
				} else {
					int index = this.offset;
					if (object instanceof ImmutableList.RegularImmutableList) {
						ImmutableList.RegularImmutableList<?> other = (ImmutableList.RegularImmutableList) object;

						for (int i = other.offset; i < other.offset + other.size; ++i) {
							if (!this.array[index++].equals(other.array[i])) {
								return false;
							}
						}
					} else {
						Iterator i$ = that.iterator();

						while (i$.hasNext()) {
							Object element = i$.next();
							if (!this.array[index++].equals(element)) {
								return false;
							}
						}
					}

					return true;
				}
			}
		}

		public int hashCode() {
			int hashCode = 1;

			for (int i = this.offset; i < this.offset + this.size; ++i) {
				hashCode = 31 * hashCode + this.array[i].hashCode();
			}

			return hashCode;
		}

		public String toString() {
			StringBuilder sb = new StringBuilder(this.size() * 16);
			sb.append('[').append(this.array[this.offset]);

			for (int i = this.offset + 1; i < this.offset + this.size; ++i) {
				sb.append(", ").append(this.array[i]);
			}

			return sb.append(']').toString();
		}
	}

	private static final class EmptyImmutableList extends ImmutableList<Object> {
		private static final Object[] EMPTY_ARRAY = new Object[0];

		private EmptyImmutableList() {
         super((1)null);
      }

		public int size() {
			return 0;
		}

		public boolean isEmpty() {
			return true;
		}

		public boolean contains(Object target) {
			return false;
		}

		public UnmodifiableIterator<Object> iterator() {
			return Iterators.emptyIterator();
		}

		public Object[] toArray() {
			return EMPTY_ARRAY;
		}

		public <T> T[] toArray(T[] a) {
			if (a.length > 0) {
				a[0] = null;
			}

			return a;
		}

		public Object get(int index) {
			Preconditions.checkElementIndex(index, 0);
			throw new AssertionError("unreachable");
		}

		public int indexOf(Object target) {
			return -1;
		}

		public int lastIndexOf(Object target) {
			return -1;
		}

		public ImmutableList<Object> subList(int fromIndex, int toIndex) {
			Preconditions.checkPositionIndexes(fromIndex, toIndex, 0);
			return this;
		}

		public ListIterator<Object> listIterator() {
			return Iterators.emptyListIterator();
		}

		public ListIterator<Object> listIterator(int start) {
			Preconditions.checkPositionIndex(start, 0);
			return Iterators.emptyListIterator();
		}

		public boolean containsAll(Collection<?> targets) {
			return targets.isEmpty();
		}

		public boolean equals(@Nullable Object object) {
			if (object instanceof List) {
				List<?> that = (List) object;
				return that.isEmpty();
			} else {
				return false;
			}
		}

		public int hashCode() {
			return 1;
		}

		public String toString() {
			return "[]";
		}
	}
}