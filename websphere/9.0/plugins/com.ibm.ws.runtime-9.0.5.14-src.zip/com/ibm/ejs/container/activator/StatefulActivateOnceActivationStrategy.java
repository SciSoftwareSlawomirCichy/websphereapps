package com.ibm.ejs.container.activator;

import com.ibm.ejs.container.BeanO;
import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.StatefulBeanO;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.PassivationPolicy;

public class StatefulActivateOnceActivationStrategy extends StatefulSessionActivationStrategy {
	private static final TraceComponent tc = Tr.register(StatefulActivateOnceActivationStrategy.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public StatefulActivateOnceActivationStrategy(Activator activator, PassivationPolicy policy) {
		super(activator, policy);
	}

	void atCommit(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atCommit: " + bean, tx);
		}

		StatefulBeanO sfbean = (StatefulBeanO) bean;
		Object lock = sfbean.ivCacheLock;
		synchronized (lock) {
			if (!sfbean.isRemoved()) {
				this.cache.unpinElement(sfbean.ivCacheElement);
			} else {
				this.cache.removeElement(sfbean.ivCacheElement, true);
				sfbean.destroy();
				sfbean.ivCacheKey = null;
				this.reaper.remove(sfbean.getId());
			}

			sfbean.setCurrentTx((ContainerTx) null);
			sfbean.unlock(lock);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atCommit: " + bean);
		}

	}

	void atRollback(ContainerTx tx, BeanO bean) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "atRollback: " + bean, tx);
		}

		StatefulBeanO sfbean = (StatefulBeanO) bean;
		Object lock = sfbean.ivCacheLock;
		synchronized (lock) {
			if (!sfbean.isRemoved()) {
				this.cache.unpinElement(sfbean.ivCacheElement);
			} else {
				this.cache.removeElement(sfbean.ivCacheElement, true);
				sfbean.destroy();
				sfbean.ivCacheKey = null;
				this.reaper.remove(sfbean.getId());
			}

			sfbean.setCurrentTx((ContainerTx) null);
			sfbean.unlock(lock);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "atRollback: " + bean);
		}

	}
}