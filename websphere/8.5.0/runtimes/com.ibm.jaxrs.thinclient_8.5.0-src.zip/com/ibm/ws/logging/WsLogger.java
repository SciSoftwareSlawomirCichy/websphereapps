package com.ibm.ws.logging;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.ras.TraceStateChangeListener;
import com.ibm.ws.logging.WsLogger.1;
import java.security.AccessController;
import java.util.logging.Logger;

public class WsLogger extends Logger implements TraceStateChangeListener {
	private TraceComponent _tc;

	public WsLogger(String name, String resourceBundleName) {
		super(name, resourceBundleName);
		if (name != null && name.length() > 0) {
			this._tc = Tr.register(name);
			this._tc.setLoggerForCallback(this);
			this.traceStateChanged();
		}

	}

	public void traceStateChanged() {
      AccessController.doPrivileged(new 1(this));
   }

	public void addLoggerToGroup(String group) {
		this._tc.addGroup(group);
		Tr.updateTraceSpec(this._tc);
	}
}