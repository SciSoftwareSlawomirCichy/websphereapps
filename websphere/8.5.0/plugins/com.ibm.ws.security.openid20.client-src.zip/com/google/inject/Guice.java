package com.google.inject;

import java.util.Arrays;

public final class Guice {
	public static Injector createInjector(Module... modules) {
		return createInjector((Iterable) Arrays.asList(modules));
	}

	public static Injector createInjector(Iterable<? extends Module> modules) {
		return createInjector(Stage.DEVELOPMENT, modules);
	}

	public static Injector createInjector(Stage stage, Module... modules) {
		return createInjector(stage, (Iterable) Arrays.asList(modules));
	}

	public static Injector createInjector(Stage stage, Iterable<? extends Module> modules) {
		return (new InjectorBuilder()).stage(stage).addModules(modules).build();
	}
}