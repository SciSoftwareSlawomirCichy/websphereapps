package com.ibm.ejs.container.finder;

import com.ibm.ws.ejb.portable.Constants;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;
import java.util.Vector;

public class FinderResultClientIterator extends FinderResultClientBase implements Iterator {
	static final byte[] frciEyecatcher;
	static final short frciPlatform = 1;
	static final short frciVersionID = 1;
	private static final long serialVersionUID = 94441000330697159L;

	public FinderResultClientIterator(FinderResultServer server, Vector colWrappers,
			FinderResultClientCollection parentCollection, int chunkSize) {
		super(server, colWrappers, parentCollection, chunkSize);
	}

	public boolean hasNext() {
		return this.hasMoreElements();
	}

	public Object next() {
		return this.nextElement();
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
		out.write(frciEyecatcher);
		out.writeShort(1);
		out.writeShort(1);
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		byte[] ec = new byte[4];
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < 4; i += bytesRead) {
			bytesRead = in.read(ec, i, 4 - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < frciEyecatcher.length; ++i) {
			if (frciEyecatcher[i] != ec[i]) {
				String eyeCatcherString = new String(ec);
				throw new IOException(
						"Invalid eye catcher '" + eyeCatcherString + "' in FinderResultClientIterator input stream");
			}
		}

		in.readShort();
		in.readShort();
	}

	static {
		frciEyecatcher = Constants.FINDER_RESULT_CLIENT_ITERATOR_EYE_CATCHER;
	}
}