package com.ibm.ejs.container.drs;

import com.ibm.ejs.container.BeanId;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.drs.SfDRSCache.1;
import com.ibm.ejs.container.drs.SfDRSCache.CacheEntry;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.FastHashtable;
import com.ibm.ws.ejbcontainer.failover.SfFailoverCache;
import com.ibm.ws.ejbcontainer.failover.SfFailoverClient;
import com.ibm.ws.ejbcontainer.failover.SfFailoverKey;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.service.MultibrokerDomain;
import com.ibm.wsspi.cluster.ClusterObserver;
import com.ibm.wsspi.drs.DRSBootstrap;
import com.ibm.wsspi.drs.DRSDataXfer;
import com.ibm.wsspi.drs.DRSSettings;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;

public class SfDRSCache implements SfFailoverCache {
	private static final TraceComponent tc = Tr.register(SfDRSCache.class, "EJBDRSCache",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.drs.SfDRSCache";
	private final FastHashtable<SfFailoverKey, CacheEntry> ivCache;
	private final FastHashtable<String, SfDRSClient> ivSfDRSClientCache;
	private final MultibrokerDomain ivMultibrokerDomain;
	private String ivContainerId;
	private SfDRSClient ivContainerSfDRSClient;
	private EJSContainer ivContainer;

	public SfDRSCache(MultibrokerDomain mbd) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "SfDRSCache CTOR");
		}

		this.ivCache = new FastHashtable(97);
		this.ivSfDRSClientCache = new FastHashtable(17);
		this.ivMultibrokerDomain = mbd;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "SfDRSCache created");
		}

	}

	public final SfDRSClient getContainerSfDRSClient() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getContainerSfDRSClient", this.ivContainerSfDRSClient);
		}

		return this.ivContainerSfDRSClient;
	}

	public SfDRSClient getSfDRSClient(String id, DRSSettings drsSettings) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getSfDRSClient for DRS instance ID = " + id);
		}

		SfDRSClient drsClient = (SfDRSClient) this.ivSfDRSClientCache.get(id);
		if (drsClient == null) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "creating DRS instance for ID = " + id);
			}

			try {
				SfDRSCacheMsgListener ml = new SfDRSCacheMsgListener(this);
				String domainName = drsSettings.getMessageBrokerDomainName();
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "DRS replication domain: " + domainName);
				}

				HashMap<String, Object> miscParms = new HashMap();
				miscParms.put("Configure DRS Controller Instance", "EJB Container DRS Controller Instance");
				miscParms.put("MISC_PARM_JOIN_CLUSTER", Boolean.TRUE);
				DRSDataXfer ddx = this.ivMultibrokerDomain.createInstance(id, ml, (DRSBootstrap) null, drsSettings,
						(ClusterObserver) null, miscParms);
				SfDRSClient sfDrsClient = new SfDRSClient(ddx, id, ml);
				ml.setSfDRSClient(sfDrsClient);
				this.ivSfDRSClientCache.put(id, sfDrsClient);
				drsClient = sfDrsClient;
			} catch (Throwable var9) {
				FFDCFilter.processException(var9, "com.ibm.ejs.container.drs.SfDRSCache.getSfDRSClient", "216", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "creating DRS instance failed: " + var9);
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getSfDRSClient returning " + drsClient);
		}

		return drsClient;
	}

	public SfFailoverClient getCachedSfFailoverClient(String id) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getSfDRSClient for DRS instance ID = " + id);
		}

		SfDRSClient drsClient = (SfDRSClient) this.ivSfDRSClientCache.get(id);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "getSfDRSClient returning " + drsClient);
		}

		return drsClient;
	}

	public boolean beanDoesNotExistOrHasTimedOut(BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "beanDoesNotExistOrHasTimedOut for BeanId = " + beanId);
		}

		SfFailoverKey key = beanId.getFailoverKey();
		CacheEntry cacheEntry = (CacheEntry) this.ivCache.get(key);
		if (cacheEntry == null) {
			cacheEntry = this.faultDataIntoCache(beanId);
		}

		boolean returnValue = true;
		if (cacheEntry != null) {
			synchronized (cacheEntry) {
				returnValue = this.beanTimedOut(cacheEntry);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "beanDoesNotExistOrHasTimedOut returning " + returnValue + " for BeanId = " + beanId);
		}

		return returnValue;
	}

	public void addCacheEntry(SfFailoverKey key, SfDRSCacheEntry newEntry, SfDRSCacheMsgListener ml) {
      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.entry(tc, "addCacheEntry for key = " + key);
      }

      CacheEntry cacheEntry = (CacheEntry)this.ivCache.get(key);
      if (cacheEntry != null) {
         this.updateCacheEntry(key, newEntry, ml);
      } else {
         cacheEntry = new CacheEntry(this, (1)null);
         cacheEntry.ivData = newEntry.ivData;
         cacheEntry.ivSequenceNumber = newEntry.ivSequenceNumber;
         cacheEntry.ivPassivated = newEntry.ivPassivated;
         cacheEntry.ivStickyUOW = newEntry.ivStickyUOW;
         cacheEntry.ivTimeoutValue = newEntry.ivTimeoutValue;
         cacheEntry.ivLastAccessTime = newEntry.ivLastAccessTime;
         cacheEntry.ivKey = key;
         cacheEntry.ivOwner = ml;
         this.ivCache.put(key, cacheEntry);
         if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
            Tr.debug(tc, "added: " + cacheEntry);
         }
      }

      if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
         Tr.exit(tc, "addCacheEntry");
      }

   }

	public final boolean beanExists(BeanId beanId) {
		SfFailoverKey key = beanId.getFailoverKey();
		return this.beanExists(key);
	}

	final boolean beanExists(SfFailoverKey key) {
		CacheEntry cacheEntry = (CacheEntry) this.ivCache.get(key);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, cacheEntry != null ? "Session bean is in DRS cache" : "Session bean is not DRS cache");
		}

		return cacheEntry != null;
	}

	private boolean beanTimedOut(CacheEntry cacheEntry) {
		if (cacheEntry.ivTimeoutValue > 0L) {
			long currentTime = System.currentTimeMillis();
			long elapsedTime = currentTime - cacheEntry.ivLastAccessTime;
			if (elapsedTime >= cacheEntry.ivTimeoutValue) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Date currentDate = new Date(currentTime);
					Date lastAccessTime = new Date(cacheEntry.ivLastAccessTime);
					Tr.event(tc, "SFSB DRS cache entry timed out ",
							"DRS Key: " + cacheEntry.ivKey + ", Current Time: " + currentDate.toString()
									+ ", Last Access Time: " + lastAccessTime.toString() + " Timeout: "
									+ cacheEntry.ivTimeoutValue + " ms");
				}

				return true;
			}
		}

		return false;
	}

	public boolean beanExistsAndTimedOut(BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "beanExistsAndTimedOut for BeanId = " + beanId);
		}

		boolean existsAndTimedOut = false;
		SfFailoverKey key = beanId.getFailoverKey();
		CacheEntry cacheEntry = (CacheEntry) this.ivCache.get(key);
		if (cacheEntry != null) {
			synchronized (cacheEntry) {
				existsAndTimedOut = this.beanTimedOut(cacheEntry);
			}
		} else {
			cacheEntry = this.faultDataIntoCache(beanId);
			if (cacheEntry != null) {
				synchronized (cacheEntry) {
					existsAndTimedOut = this.beanTimedOut(cacheEntry);
				}
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "beanExistsAndTimedOut returning " + existsAndTimedOut + " for BeanId = " + beanId);
		}

		return existsAndTimedOut;
	}

	private CacheEntry faultDataIntoCache(BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "faultDataIntoCache for BeanId: " + beanId);
		}

		CacheEntry entry = null;
		SfDRSClient drs = (SfDRSClient) beanId.getBeanMetaData().getSfFailoverClient();
		if (drs != null) {
			SfDRSCacheEntry newEntry = drs.getEntry(beanId);
			if (newEntry != null) {
				SfFailoverKey key = beanId.getFailoverKey();
				this.addCacheEntry(key, newEntry, drs.ivSfDRSCacheMsgListener);
				entry = (CacheEntry) this.ivCache.get(key);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "faultDataIntoCache returning: " + entry + "for BeanId = " + beanId);
		}

		return entry;
	}

	public byte[] getAndRemoveData(BeanId beanId, SfFailoverClient failoverClient) {
		SfFailoverKey key = beanId.getFailoverKey();
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "getAndRemoveData, key = " + key);
		}

		byte[] data = null;
		CacheEntry cacheEntry = (CacheEntry) this.ivCache.remove(key);
		if (cacheEntry != null) {
			data = cacheEntry.ivData;
			SfDRSCacheEntry e = new SfDRSCacheEntry(cacheEntry.ivKey, cacheEntry.ivTimeoutValue);
			e.ivData = data;
			e.ivLastAccessTime = cacheEntry.ivLastAccessTime;
			e.ivPassivated = cacheEntry.ivPassivated;
			e.ivSequenceNumber = cacheEntry.ivSequenceNumber;
			e.ivStickyUOW = cacheEntry.ivStickyUOW;
			((SfDRSClient) failoverClient).createEntry(beanId, e);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			int n = data != null ? data.length : 0;
			Tr.exit(tc, "getAndRemoveData returning data of length: " + n);
		}

		return data;
	}

	SfDRSCacheEntry getCacheEntry(SfFailoverKey key) {
		SfDRSCacheEntry newEntry = null;
		CacheEntry entry = (CacheEntry) this.ivCache.get(key);
		if (entry != null) {
			newEntry = new SfDRSCacheEntry(key, entry.ivTimeoutValue);
			synchronized (entry) {
				newEntry.ivSequenceNumber = entry.ivSequenceNumber;
				newEntry.ivData = entry.ivData;
				newEntry.ivPassivated = entry.ivPassivated;
				newEntry.ivStickyUOW = entry.ivStickyUOW;
				newEntry.ivLastAccessTime = entry.ivLastAccessTime;
			}
		}

		return newEntry;
	}

	public void initialize(EJSContainer container, DRSSettings drsSettings) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "initialize for MultiBrokerDomain: " + this.ivMultibrokerDomain);
		}

		this.ivContainer = container;
		if (drsSettings != null) {
			this.ivContainerId = container.getHomeOfHomes().getJ2EEName().getApplication();
			this.ivContainerSfDRSClient = this.getSfDRSClient(this.ivContainerId, drsSettings);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "initialize");
		}

	}

	public boolean inStickyUOW(BeanId beanId) {
		boolean stickyUOW = false;
		SfFailoverKey key = beanId.getFailoverKey();
		CacheEntry cacheEntry = (CacheEntry) this.ivCache.get(key);
		if (cacheEntry != null) {
			synchronized (cacheEntry) {
				stickyUOW = cacheEntry.ivStickyUOW;
			}
		}

		return stickyUOW;
	}

	public final void removeCacheEntry(SfFailoverKey key) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "removeCacheEntry, key = " + key);
		}

		CacheEntry cacheEntry = (CacheEntry) this.ivCache.remove(key);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			if (cacheEntry != null) {
				Tr.debug(tc, "removed cache entry: " + cacheEntry);
			} else {
				Tr.debug(tc, "cache entry not removed since it was not found");
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "removeCacheEntry");
		}

	}

	public final void removeCacheEntry(BeanId beanId) {
		SfFailoverKey key = beanId.getFailoverKey();
		this.removeCacheEntry(key);
	}

	public void sweep() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "sweep : DRS Cache size = " + this.ivCache.size());
		}

		Enumeration e = this.ivCache.elements();

		while (e.hasMoreElements()) {
			boolean tryToDelete = false;
			CacheEntry cacheEntry = (CacheEntry) e.nextElement();
			synchronized (cacheEntry) {
				if (this.beanTimedOut(cacheEntry)) {
					tryToDelete = true;
				}
			}

			if (tryToDelete) {
				SfFailoverKey key = cacheEntry.ivKey;
				this.ivCache.remove(key);
				cacheEntry.ivOwner.removeIfPrimary(key);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "sweep : DRS Cache size = " + this.ivCache.size());
		}

	}

	public void updateCacheEntry(SfFailoverKey key, SfDRSCacheEntry newEntry, SfDRSCacheMsgListener ml) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "updateCacheEntry for key = " + key);
		}

		CacheEntry entry = (CacheEntry) this.ivCache.get(key);
		if (entry == null) {
			this.addCacheEntry(key, newEntry, ml);
		} else if (newEntry.ivSequenceNumber > entry.ivSequenceNumber) {
			synchronized (entry) {
				entry.ivSequenceNumber = newEntry.ivSequenceNumber;
				entry.ivStickyUOW = newEntry.ivStickyUOW;
				entry.ivPassivated = newEntry.ivPassivated;
				entry.ivLastAccessTime = newEntry.ivLastAccessTime;
				if (newEntry.ivData != null) {
					entry.ivData = newEntry.ivData;
				}
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "cached updated: " + entry);
			}
		} else if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "stale data cache entry: " + newEntry);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "updateCacheEntry");
		}

	}

	public String getContainerDrsInstanceId() {
		return this.ivContainerId;
	}

	public final boolean isContainerSFSBFailoverEnabled() {
		return this.ivContainer.isEnableSFSBFailover();
	}
}