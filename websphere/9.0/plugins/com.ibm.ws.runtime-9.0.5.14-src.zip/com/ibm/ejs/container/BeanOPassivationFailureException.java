package com.ibm.ejs.container;

public class BeanOPassivationFailureException extends ContainerException {
	private static final long serialVersionUID = 8894821895189549685L;
}