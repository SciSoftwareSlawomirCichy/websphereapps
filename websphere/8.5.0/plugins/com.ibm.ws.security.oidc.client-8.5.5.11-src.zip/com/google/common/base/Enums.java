package com.google.common.base;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Enums.1;
import com.google.common.base.Enums.ValueOfFunction;
import java.lang.reflect.Field;

@GwtCompatible(emulated = true)
@Beta
public final class Enums {
	@GwtIncompatible("reflection")
	public static Field getField(Enum<?> enumValue) {
		Class clazz = enumValue.getDeclaringClass();

		try {
			return clazz.getDeclaredField(enumValue.name());
		} catch (NoSuchFieldException var3) {
			throw new AssertionError(var3);
		}
	}

	public static <T extends Enum<T>> Function<String, T> valueOfFunction(Class<T> enumClass) {
      return new ValueOfFunction(enumClass, (1)null);
   }

	public static <T extends Enum<T>> Optional<T> getIfPresent(Class<T> enumClass, String value) {
		Preconditions.checkNotNull(enumClass);
		Preconditions.checkNotNull(value);

		try {
			return Optional.of(Enum.valueOf(enumClass, value));
		} catch (IllegalArgumentException var3) {
			return Optional.absent();
		}
	}
}