package com.ibm.websphere.crypto;

import java.util.Properties;

public interface KeyPairGenerator {
	void init(Properties var1);

	KeyPair generateKeyPair() throws KeyException;
}