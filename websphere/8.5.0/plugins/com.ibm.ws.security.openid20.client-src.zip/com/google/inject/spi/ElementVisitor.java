package com.google.inject.spi;

import com.google.inject.Binding;

public interface ElementVisitor<V> {
	<T> V visit(Binding<T> var1);

	V visit(InterceptorBinding var1);

	V visit(ScopeBinding var1);

	V visit(TypeConverterBinding var1);

	V visit(InjectionRequest var1);

	V visit(StaticInjectionRequest var1);

	<T> V visit(ProviderLookup<T> var1);

	<T> V visit(MembersInjectorLookup<T> var1);

	V visit(Message var1);

	V visit(PrivateElements var1);

	V visit(TypeListenerBinding var1);
}