package com.ibm.ejs.container.finder;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.util.Enumeration;

public class FinderResultClientEnumeration_Local extends FinderResultClientBase_Local implements Enumeration {
	private static final TraceComponent tc = Tr.register(FinderResultClientEnumeration_Local.class, "EJBContainer",
			"com.ibm.ejs.container.container");

	public FinderResultClientEnumeration_Local(FinderResultServerImpl serverImpl) {
		super(serverImpl);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "FinderResultClientEnumeration_Local CTOR");
		}

	}

	public int getServerWrapperSize() {
		return this.serverImpl.getWrappers().size();
	}
}