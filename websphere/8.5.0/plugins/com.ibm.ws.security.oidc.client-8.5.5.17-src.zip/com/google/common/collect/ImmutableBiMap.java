package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.collect.ImmutableBiMap.Builder;
import com.google.common.collect.ImmutableBiMap.SerializedForm;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;

@GwtCompatible(serializable = true, emulated = true)
public abstract class ImmutableBiMap<K, V> extends ImmutableMap<K, V> implements BiMap<K, V> {
	public static <K, V> ImmutableBiMap<K, V> of() {
		return RegularImmutableBiMap.EMPTY;
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		return new RegularImmutableBiMap(new Object[]{k1, v1}, 1);
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		return new RegularImmutableBiMap(new Object[]{k1, v1, k2, v2}, 2);
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		CollectPreconditions.checkEntryNotNull(k3, v3);
		return new RegularImmutableBiMap(new Object[]{k1, v1, k2, v2, k3, v3}, 3);
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		CollectPreconditions.checkEntryNotNull(k3, v3);
		CollectPreconditions.checkEntryNotNull(k4, v4);
		return new RegularImmutableBiMap(new Object[]{k1, v1, k2, v2, k3, v3, k4, v4}, 4);
	}

	public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
		CollectPreconditions.checkEntryNotNull(k1, v1);
		CollectPreconditions.checkEntryNotNull(k2, v2);
		CollectPreconditions.checkEntryNotNull(k3, v3);
		CollectPreconditions.checkEntryNotNull(k4, v4);
		CollectPreconditions.checkEntryNotNull(k5, v5);
		return new RegularImmutableBiMap(new Object[]{k1, v1, k2, v2, k3, v3, k4, v4, k5, v5}, 5);
	}

	public static <K, V> Builder<K, V> builder() {
		return new Builder();
	}

	@Beta
	public static <K, V> Builder<K, V> builderWithExpectedSize(int expectedSize) {
		CollectPreconditions.checkNonnegative(expectedSize, "expectedSize");
		return new Builder(expectedSize);
	}

	public static <K, V> ImmutableBiMap<K, V> copyOf(Map<? extends K, ? extends V> map) {
		if (map instanceof ImmutableBiMap) {
			ImmutableBiMap<K, V> bimap = (ImmutableBiMap) map;
			if (!bimap.isPartialView()) {
				return bimap;
			}
		}

		return copyOf((Iterable) map.entrySet());
	}

	@Beta
	public static <K, V> ImmutableBiMap<K, V> copyOf(Iterable<? extends Entry<? extends K, ? extends V>> entries) {
		int estimatedSize = entries instanceof Collection ? ((Collection) entries).size() : 4;
		return (new Builder(estimatedSize)).putAll(entries).build();
	}

	public abstract ImmutableBiMap<V, K> inverse();

	public ImmutableSet<V> values() {
		return this.inverse().keySet();
	}

	final ImmutableSet<V> createValues() {
		throw new AssertionError("should never be called");
	}

	@Deprecated
	@CanIgnoreReturnValue
	public V forcePut(K key, V value) {
		throw new UnsupportedOperationException();
	}

	Object writeReplace() {
		return new SerializedForm(this);
	}
}