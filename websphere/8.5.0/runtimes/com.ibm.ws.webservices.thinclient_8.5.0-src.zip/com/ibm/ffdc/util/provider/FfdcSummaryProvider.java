package com.ibm.ffdc.util.provider;

import com.ibm.ffdc.util.provider.IncidentEntry.Key;

public abstract class FfdcSummaryProvider extends FfdcProvider {
	protected abstract void logSummary();

	protected synchronized IncidentEntry getIncident(Key key, ClassLoader cldr) {
		IncidentEntry incident = super.getIncident(key, cldr);
		this.logSummary();
		return incident;
	}
}