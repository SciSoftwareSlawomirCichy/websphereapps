package com.google.common.escape;

import com.google.common.annotations.GwtCompatible;
import com.google.common.escape.Platform.1;

@GwtCompatible(emulated = true)
final class Platform {
	private static final ThreadLocal<char[]> DEST_TL = new 1();

	static char[] charBufferFromThreadLocal() {
		return (char[]) DEST_TL.get();
	}
}