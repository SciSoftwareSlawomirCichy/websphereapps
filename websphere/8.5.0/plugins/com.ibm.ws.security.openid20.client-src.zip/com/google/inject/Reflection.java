package com.google.inject;

import com.google.inject.Reflection.InvalidConstructor;
import java.lang.reflect.Constructor;

class Reflection {
	static <T> Constructor<T> invalidConstructor() {
		try {
			return InvalidConstructor.class.getDeclaredConstructor();
		} catch (NoSuchMethodException var1) {
			throw new AssertionError(var1);
		}
	}
}