package com.ibm.ejs.util.am;

import com.ibm.ejs.ras.Dumpable;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ffdc.Manager;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentSkipListMap;

class AlarmManagerThreadCSLM implements Dumpable, Runnable {
	private static final TraceComponent tc = Tr.register(AlarmManagerThreadCSLM.class, (String) null, (String) null);
	protected boolean dumped = false;
	ConcurrentSkipListMap<_Alarm, _Alarm> alarmQ;
	boolean deferredAlarms = false;
	volatile _Alarm waitingOn;

	AlarmManagerThreadCSLM(ConcurrentSkipListMap<_Alarm, _Alarm> _AlarmQ, boolean runDeferred) {
		Tr.registerDumpable(tc, this);
		this.alarmQ = _AlarmQ;
		this.deferredAlarms = runDeferred;
	}

	public void run() {
		boolean threadContinue = true;

		while (threadContinue) {
			try {
				boolean isAnyTracingEnabled = TraceComponent.isAnyTracingEnabled();
				Entry<_Alarm, _Alarm> next = null;
				ConcurrentSkipListMap var4 = this.alarmQ;
				synchronized (this.alarmQ) {
					next = this.alarmQ.firstEntry();

					label101 : while (true) {
						while (true) {
							long currentTime = AlarmManager.getMillisTime();
							_Alarm a;
							if (next != null && ((_Alarm) next.getValue()).expirationTime - currentTime <= 0L) {
								next = this.alarmQ.pollFirstEntry();
								if (next != null) {
									a = (_Alarm) next.getValue();
									synchronized (a) {
										if (!a.fired) {
											if (a.expirationTime - currentTime <= 0L) {
												a.fired = true;
												break label101;
											}

											this.alarmQ.put(a, a);
										}
									}
								}
							}

							a = next == null ? null : (_Alarm) next.getValue();
							this.waitingOn = a;
							next = this.alarmQ.firstEntry();
							if (next == null) {
								if (a == null) {
									this.alarmQ.wait();
								}
							} else if (next.getValue() == a) {
								long delta = ((_Alarm) next.getValue()).expirationTime - currentTime;
								if (this.deferredAlarms && AlarmManager.getActiveWork() <= 0) {
									if (isAnyTracingEnabled && tc.isDebugEnabled()) {
										Tr.debug(tc, "Alarm Manager waiting for next server work request");
									}

									this.alarmQ.wait();
								} else {
									if (isAnyTracingEnabled && tc.isDebugEnabled()) {
										Tr.debug(tc, "Alarm manager thread waiting",
												new Object[]{next.getValue(), delta});
									}

									this.alarmQ.wait(delta);
								}
							}
						}
					}
				}

				((_Alarm) next.getValue()).execute();
			} catch (InterruptedException var14) {
				InterruptedException ex = var14;

				try {
					Manager.Ffdc.log(ex, this, "com.ibm.ejs.util.am.AlarmManagerThread.run", "121", new Object[]{this});
				} catch (NoClassDefFoundError var11) {
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "Alarm manager thread received an exception: ", var11);
					}

					threadContinue = false;
				}
			}
		}

	}

	public void dump() {
		if (!this.dumped) {
			try {
				Tr.dump(tc, "-- Alarm Manager Dump --");
				Tr.dump(tc, this.alarmQ.size() + " scheduled alarms");
				ConcurrentSkipListMap var1 = this.alarmQ;
				synchronized (this.alarmQ) {
					Tr.dump(tc, "alarm queue contents", this.alarmQ.values());
				}
			} finally {
				this.dumped = true;
			}

		}
	}

	public void resetDump() {
		this.dumped = false;
	}
}