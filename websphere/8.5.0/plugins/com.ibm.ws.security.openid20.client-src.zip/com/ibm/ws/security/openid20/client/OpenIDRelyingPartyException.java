package com.ibm.ws.security.openid20.client;

public class OpenIDRelyingPartyException extends Exception {
	public OpenIDRelyingPartyException() {
	}

	public OpenIDRelyingPartyException(String msg) {
		super(msg);
	}
}