package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.spi.BindingTargetVisitor;
import com.google.inject.spi.LinkedKeyBinding;

public final class LinkedBindingImpl<T> extends BindingImpl<T> implements LinkedKeyBinding<T> {
	final Key<? extends T> targetKey;

	public LinkedBindingImpl(Injector injector, Key<T> key, Object source, InternalFactory<? extends T> internalFactory,
			Scoping scoping, Key<? extends T> targetKey) {
		super(injector, key, source, internalFactory, scoping);
		this.targetKey = targetKey;
	}

	public LinkedBindingImpl(Object source, Key<T> key, Scoping scoping, Key<? extends T> targetKey) {
		super(source, key, scoping);
		this.targetKey = targetKey;
	}

	public <V> V acceptTargetVisitor(BindingTargetVisitor<? super T, V> visitor) {
		return visitor.visit(this);
	}

	public Key<? extends T> getLinkedKey() {
		return this.targetKey;
	}

	public BindingImpl<T> withScoping(Scoping scoping) {
		return new LinkedBindingImpl(this.getSource(), this.getKey(), scoping, this.targetKey);
	}

	public BindingImpl<T> withKey(Key<T> key) {
		return new LinkedBindingImpl(this.getSource(), key, this.getScoping(), this.targetKey);
	}

	public void applyTo(Binder binder) {
		this.getScoping().applyTo(binder.withSource(this.getSource()).bind(this.getKey()).to(this.getLinkedKey()));
	}

	public String toString() {
		return (new ToStringBuilder(LinkedKeyBinding.class)).add("key", this.getKey()).add("source", this.getSource())
				.add("scope", this.getScoping()).add("target", this.targetKey).toString();
	}
}