package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.MembershipAttributeType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class MembershipAttributeTypeImpl extends EDataObjectImpl implements MembershipAttributeType {
	protected static final String NAME_EDEFAULT = null;
	protected String name;
	protected static final String SCOPE_EDEFAULT = "direct";
	protected String scope;
	protected boolean scopeESet;

	protected MembershipAttributeTypeImpl() {
		this.name = NAME_EDEFAULT;
		this.scope = "direct";
		this.scopeESet = false;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getMembershipAttributeType();
	}

	public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		String var2 = this.name;
		this.name = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.name));
		}

	}

	public String getScope() {
		return this.scope;
	}

	public void setScope(String var1) {
		String var2 = this.scope;
		this.scope = var1;
		boolean var3 = this.scopeESet;
		this.scopeESet = true;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.scope, !var3));
		}

	}

	public void unsetScope() {
		String var1 = this.scope;
		boolean var2 = this.scopeESet;
		this.scope = "direct";
		this.scopeESet = false;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 2, 1, var1, "direct", var2));
		}

	}

	public boolean isSetScope() {
		return this.scopeESet;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getName();
			case 1 :
				return this.getScope();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setName((String) var2);
				return;
			case 1 :
				this.setScope((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setName(NAME_EDEFAULT);
				return;
			case 1 :
				this.unsetScope();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return NAME_EDEFAULT == null ? this.name != null : !NAME_EDEFAULT.equals(this.name);
			case 1 :
				return this.isSetScope();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (name: ");
			var1.append(this.name);
			var1.append(", scope: ");
			if (this.scopeESet) {
				var1.append(this.scope);
			} else {
				var1.append("<unset>");
			}

			var1.append(')');
			return var1.toString();
		}
	}
}