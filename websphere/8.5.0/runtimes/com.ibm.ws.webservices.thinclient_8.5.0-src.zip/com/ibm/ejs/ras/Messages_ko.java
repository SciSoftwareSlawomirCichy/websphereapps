package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_ko extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: 설치된 Application Server 클라이언트 컴포넌트의 빌드 레벨이 불일치함을 발견했습니다. 클라이언트 컴포넌트 {0}의 설치된 빌드 레벨 {1}이(가) 클라이언트 컴포넌트 {2}의 빌드 레벨 {3}과(와) 다릅니다."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: 설치된 Application Server 클라이언트 컴포넌트의 빌드 레벨이 불일치하므로 더 이상 실행되지 않습니다."},
			{"EXCP_CWSJE0003E", "CWSJE0003E: {0} 예외로 인해 {1} 자원에 액세스할 수 없습니다."}};

	public Object[][] getContents() {
		return resources;
	}
}