package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.tx.jta.embeddable.EmbeddableTransactionManagerFactory;
import com.ibm.ws.Transaction.UOWCoordinator;
import com.ibm.ws.Transaction.UOWCurrent;
import com.ibm.ws.csi.MessageEndpointTestExtension;
import com.ibm.ws.csi.MessageEndpointTestResults;
import com.ibm.ws.ejbcontainer.mdb.MessageEndpointBase;

public class WASMessageEndpointBase extends MessageEndpointBase implements MessageEndpointTestExtension {
	private static final TraceComponent tc = Tr.register(WASMessageEndpointBase.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private MessageEndpointTestResults ivMessageEndpointTestResults = null;

	public void notifyMessageDelivered() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "notifyMessageDelivered: results = " + this.ivMessageEndpointTestResults);
		}

		if (this.ivMessageEndpointTestResults != null) {
			UOWCurrent uowCurrent = EmbeddableTransactionManagerFactory.getUOWCurrent();
			UOWCoordinator uowCoord = uowCurrent.getUOWCoord();
			if (uowCoord.isGlobal()) {
				this.ivMessageEndpointTestResults.setRunningInGlobalTransactionContext();
			} else {
				this.ivMessageEndpointTestResults.setRunningInLocalTransactionContext();
			}
		}

	}

	public void setTestResults(MessageEndpointTestResults results) {
		this.ivMessageEndpointTestResults = results;
	}

	public void unsetTestResults() {
		this.ivMessageEndpointTestResults = null;
	}
}