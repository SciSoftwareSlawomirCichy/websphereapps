package com.ibm.ws.wim.env.was;

import com.ibm.sec.auth.subjectx.VirtualPrincipal;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.security.authz.AccessException;
import com.ibm.websphere.wim.security.authz.AuthSystemException;
import com.ibm.websphere.wim.security.authz.Entitlement;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.EnvironmentManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.env.IAuthorizationService;
import com.ibm.ws.wim.env.was.JACCAuthorizationService.1;
import com.ibm.ws.wim.env.was.JACCAuthorizationService.2;
import com.ibm.ws.wim.env.was.JACCAuthorizationService.3;
import com.ibm.ws.wim.pluginmanager.PluginManager;
import com.ibm.ws.wim.security.authz.AccessHandler;
import com.ibm.ws.wim.security.authz.AuthPrivilegedException;
import com.ibm.ws.wim.security.authz.EntitlementHelper;
import com.ibm.ws.wim.security.authz.EntitlementRequest;
import com.ibm.ws.wim.security.authz.EntityResource;
import com.ibm.ws.wim.security.authz.ProfileAccessHandler;
import com.ibm.ws.wim.security.authz.SDOHelper;
import com.ibm.ws.wim.security.authz.jacc.JACCPolicyDefinition;
import com.ibm.ws.wim.security.authz.jacc.JACCSecurityManager;
import com.ibm.ws.wim.util.DataGraphHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.io.File;
import java.security.AccessController;
import java.security.Principal;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.Subject;

public class JACCAuthorizationService implements IAuthorizationService {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger msgLogger;
	private static final Logger trcLogger;
	private AccessHandler accessHandler = new ProfileAccessHandler();
	private boolean isSecurityEnabled = false;
	private boolean isAttributeGroupingEnabled;
	private JACCSecurityManager secManager;
	private String defaultAttributeGroup;
	private Map attributeGroups;
	private Subject runAsSubject;
	public DataGraph finalConfig = null;
	public Object finalObject = null;
	public boolean isArgusLoaded = false;

	public synchronized void initialize(DataGraph var1) throws WIMException {
		this.initialize(var1, (Object) null);
	}

	public synchronized void initialize(DataGraph var1, Object var2) throws WIMException {
      DataGraph var4 = var1;
      Object var5 = var2;

      try {
         AccessController.doPrivileged(new 1(this, var4, var5));
      } catch (Exception var7) {
         throw new WIMException(var7.getMessage(), CLASSNAME, "initialize", var7);
      }
   }

	private void initialize2(DataGraph var1, Object var2) throws WIMException {
		if (!this.isArgusLoaded && null == var1) {
			trcLogger.logp(Level.FINER, CLASSNAME, "initialize2", "config is null, get if from configManager");
			var1 = ConfigManager.singleton().getConfig().getDataGraph();
			trcLogger.logp(Level.FINER, CLASSNAME, "initialize2", WIMTraceHelper.printDataGraph(var1));
		}

		this.finalConfig = var1;
		this.finalObject = var2;
		if (EnvironmentManager.getWASServerStatus() && !this.isArgusLoaded) {
			trcLogger.entering(CLASSNAME, "initialize2()");
			JACCSecurityManager var4 = (JACCSecurityManager) var2;
			if (this.secManager == null) {
				DataObject var5 = var1.getRootObject().getDataObject("configurationProvider");
				DataObject var6 = var5.getDataObject("authorization");
				this.isSecurityEnabled = var6.getBoolean("isSecurityEnabled");
				if (this.isSecurityEnabled) {
					if (var4 == null) {
						String var8;
						if (DomainManagerUtils.isAdminDomain()) {
							var8 = ConfigManager.singleton().getWIMHomePath() + JACCPolicyDefinition.POLICY_SUBDIR;
						} else {
							var8 = DomainManagerUtils.getDomainPath(DomainManagerUtils.getDomainName()) + "wim"
									+ File.separator + JACCPolicyDefinition.POLICY_SUBDIR;
						}

						JACCPolicyDefinition var7;
						if (!var6.getBoolean("useSystemJACCProvider")) {
							var7 = new JACCPolicyDefinition(var6.getString("jaccPolicyClass"),
									var6.getString("jaccRoleMappingClass"),
									var6.getString("jaccPolicyConfigFactoryClass"),
									var6.getString("jaccRoleMappingConfigFactoryClass"), var8);
						} else {
							var7 = new JACCPolicyDefinition();
						}

						if (var6.getBoolean("importPolicyFromFile")) {
							var7.loadPolicy(var6.getString("jaccRoleToPermissionPolicyId"),
									var6.getString("jaccPrincipalToRolePolicyId"),
									var8 + File.separator + var6.getString("jaccRoleToPermissionPolicyFileName"),
									var8 + File.separator + var6.getString("jaccPrincipalToRolePolicyFileName"));
						}

						this.secManager = var7;
					} else {
						this.secManager = var4;
					}

					this.secManager.registerPolicy(var6.getString("jaccRoleToPermissionPolicyId"),
							var6.getString("jaccPrincipalToRolePolicyId"), this.accessHandler);
					this.loadAttributeGroups(var6);
					msgLogger.log(Level.INFO, "AUTH_INIT_SUCCESS");
				}
			}

			this.refreshPolicy();
			this.isArgusLoaded = true;
			trcLogger.exiting(CLASSNAME, "initialize()");
		}

	}

	public void refresh() {
		trcLogger.entering(CLASSNAME, "refreshPolicy()");
		if (this.isSecurityEnabled) {
			this.secManager.refreshPolicy();
		}

		trcLogger.entering(CLASSNAME, "refreshPolicy()");
	}

	private void loadAttributeGroups(DataObject var1) throws WIMException {
		trcLogger.entering(CLASSNAME, "loadAttributeGroups()");
		this.isAttributeGroupingEnabled = var1.getBoolean("isAttributeGroupingEnabled");
		this.defaultAttributeGroup = var1.getString("defaultAttributeGroup");
		List var2 = var1.getList("attributeGroups");
		this.attributeGroups = new Hashtable();

		for (int var3 = 0; var3 < var2.size(); ++var3) {
			DataObject var5 = (DataObject) var2.get(var3);
			String var7 = var5.getString("groupName");
			int var4 = var5.getList("attributeNames").size();

			for (int var8 = 0; var8 < var4; ++var8) {
				String var6 = var5.getString("attributeNames." + Integer.toString(var8));
				if (this.attributeGroups.put(var6, var7) != null) {
					throw new AuthSystemException("AUTH_ATTR_MULTIPLE_GROUP", new Object[]{var6}, Level.SEVERE);
				}
			}
		}

		trcLogger.exiting(CLASSNAME, "loadAttributeGroups()");
	}

	public void refreshPolicy() {
		trcLogger.entering(CLASSNAME, "refreshPolicy()");
		if (this.isSecurityEnabled) {
			this.secManager.refreshPolicy();
		}

		trcLogger.entering(CLASSNAME, "refreshPolicy()");
	}

	public void checkPermission_SuperUser(Entitlement var1) throws WIMException {
		trcLogger.entering(CLASSNAME, "checkPermission_SuperUser()");
		if (this.isSecurityEnabled) {
			Subject var2 = this.getCallerSubject();
			if (this.secManager.isServerSecurityEnabled() && !this.secManager.isSuperUser(var2)
					&& !this.secManager.isAdministrator(var2)) {
				throw new AccessException(this.getCallerSubjectUniqueName(), "administrator", var1, Level.SEVERE);
			}
		}

		trcLogger.exiting(CLASSNAME, "checkPermission_SuperUser()");
	}

	public boolean isCallerSuperUser() throws WIMException {
		this.initialize(this.finalConfig, this.finalObject);
		trcLogger.entering(CLASSNAME, "isCallerSuperUser()");
		Subject var1 = this.getCallerSubject();
		boolean var2 = this.isSecurityEnabled && this.secManager.isSuperUser(var1)
				|| this.isSecurityEnabled && this.secManager.isAdministrator(var1);
		trcLogger.exiting(CLASSNAME, "isCallerSuperUser() - " + var2);
		return var2;
	}

	public void checkPermission_CREATE(EntityResource var1) throws WIMException {
		trcLogger.entering(CLASSNAME, "checkPermission_CREATE()");
		this.initialize(this.finalConfig, this.finalObject);
		Subject var2 = this.getCallerSubject();
		Entitlement var6 = null;
		if (this.isSecurityEnabled) {
			if (this.secManager.isSuperUser(var2)) {
				trcLogger.log(Level.FINER,
						"Bypassing the authorization check because the caller has **SUPER USER** status");
				return;
			}

			Set var7 = this.secManager.getRoles(var2);
			boolean var3;
			if (this.hasWriteAccess(var7)) {
				var3 = true;
				this.traceAccessResult(" The caller has ''{0}'' Access since the caller has required VMM role", var7,
						Level.FINEST);
			} else {
				String var4 = SDOHelper.getEntityType(var1.getEntity(), true);
				String var5 = this.getDelegatedAdminViewId(var1, "CREATE");
				var1 = new EntityResource(var1, var4, var5);
				var3 = this.secManager.hasEntitlement(var2, var1, var6 = new Entitlement("CREATE", var4));
				this.checkAccessResult(var1, var6, var3);
				this.checkAttributePermissions(var1, "WRITE", false, false);
			}
		}

		trcLogger.exiting(CLASSNAME, "checkPermission_CREATE()");
	}

	public void checkPermission_DELETE(EntityResource var1, boolean var2) throws WIMException {
		trcLogger.entering(CLASSNAME, "checkPermission_DELETE()");
		this.initialize(this.finalConfig, this.finalObject);
		Subject var3 = this.getCallerSubject();
		Entitlement var7 = null;
		Entitlement var8 = null;
		if (this.isSecurityEnabled) {
			if (this.secManager.isSuperUser(var3)) {
				trcLogger.log(Level.FINER,
						"Bypassing the authorization check because the caller has **SUPER USER** status");
				return;
			}

			Set var9 = this.secManager.getRoles(var3);
			boolean var4;
			if (this.hasWriteAccess(var9)) {
				var4 = true;
				this.traceAccessResult(" The caller has ''{0}'' Access since the caller has required VMM role", var9,
						Level.FINEST);
			} else {
				String var5 = SDOHelper.getEntityType(var1.getEntity(), false);
				String var6 = this.getDelegatedAdminViewId(var1, "DELETE");
				var1 = new EntityResource(var1, var5, var6);
				var7 = new Entitlement("DELETE", var5);
				var8 = new Entitlement("DELETE_DESCENDANTS", var5);
				var4 = this.secManager.hasEntitlement(var3, var1, var2 ? var8 : var7);
				if (!var2 && !var4) {
					var4 = this.secManager.hasEntitlement(var3, var1, var8);
				}

				this.checkAccessResult(var1, var2 ? var8 : var7, var4);
			}
		}

		trcLogger.exiting(CLASSNAME, "checkPermission_DELETE()");
	}

	public void checkPermission_UPDATE(EntityResource var1) throws WIMException {
		trcLogger.entering(CLASSNAME, "checkPermission_UPDATE()");
		this.initialize(this.finalConfig, this.finalObject);
		Subject var2 = this.getCallerSubject();
		Entitlement var6 = null;
		if (this.isSecurityEnabled) {
			if (this.secManager.isSuperUser(var2)) {
				trcLogger.log(Level.FINER,
						"Bypassing the authorization check because the caller has **SUPER USER** status");
				return;
			}

			Set var7 = this.secManager.getRoles(var2);
			boolean var3;
			if (this.hasWriteAccess(var7)) {
				var3 = true;
				this.traceAccessResult(" The caller has ''{0}'' Access since the caller has required VMM role", var7,
						Level.FINEST);
			} else {
				String var4 = SDOHelper.getEntityType(var1.getEntity(), false);
				String var5 = this.getDelegatedAdminViewId(var1, "UPDATE");
				var1 = new EntityResource(var1, var4, var5);
				var3 = this.secManager.hasEntitlement(var2, var1, var6 = new Entitlement("UPDATE", var4));
				this.checkAccessResult(var1, var6, var3);
				this.checkAttributePermissions(var1, "WRITE", false, false);
			}
		}

		trcLogger.exiting(CLASSNAME, "checkPermission_UPDATE()");
	}

	public DataObject checkPermission_GET(EntityResource var1) throws WIMException {
		trcLogger.entering(CLASSNAME, "checkPermission_GET()");
		this.initialize(this.finalConfig, this.finalObject);
		Subject var2 = this.getCallerSubject();
		if (this.isSecurityEnabled) {
			if (this.secManager.isSuperUser(var2)) {
				trcLogger.log(Level.FINER,
						"Bypassing the authorization check because the caller has **SUPER USER** status");
				return var1.getEntity();
			}

			Set var7 = this.secManager.getRoles(var2);
			boolean var3;
			if (this.hasReadAccess(var7)) {
				var3 = true;
				this.traceAccessResult(" The caller has ''{0}'' Access since the caller has required VMM role", var7,
						Level.FINEST);
				return var1.getEntity();
			}

			String var4 = SDOHelper.getEntityType(var1.getEntity(), true);
			String var5 = this.getDelegatedAdminViewId(var1, "GET");
			var1 = new EntityResource(var1, var4, var5);
			Entitlement var6;
			var3 = this.secManager.hasEntitlement(var2, var1, var6 = new Entitlement("GET", var4));
			this.checkAccessResult(var1, var6, var3);
			this.checkAttributePermissions(var1, "READ", true, true);
		}

		trcLogger.exiting(CLASSNAME, "checkPermission_GET()");
		return var1.getEntity();
	}

	public DataObject checkPermission_LOGIN(EntityResource var1) throws WIMException {
		trcLogger.entering(CLASSNAME, "checkPermission_LOGIN()");
		this.initialize(this.finalConfig, this.finalObject);
		trcLogger.exiting(CLASSNAME, "checkPermission_LOGIN()");
		return var1.getEntity();
	}

	public DataObject checkPermission_SEARCH(EntityResource var1, Entitlement var2) throws WIMException {
		trcLogger.entering(CLASSNAME, "checkPermission_SEARCH()");
		this.initialize(this.finalConfig, this.finalObject);
		Subject var3 = this.getCallerSubject();
		boolean var5 = false;
		if (this.isSecurityEnabled) {
			if (this.secManager.isSuperUser(var3)) {
				trcLogger.log(Level.FINER,
						"Bypassing the authorization check because the caller has **SUPER USER** status");
				return var1.getEntity();
			}

			Set var9 = this.secManager.getRoles(var3);
			boolean var4;
			if (this.hasReadAccess(var9)) {
				var4 = true;
				this.traceAccessResult(" The caller has ''{0}'' Access since the caller has required VMM role", var9,
						Level.FINEST);
				return var1.getEntity();
			}

			String var6 = SDOHelper.getEntityType(var1.getEntity(), true);
			String var7 = this.getDelegatedAdminViewId(var1, "SEARCH");
			var1 = new EntityResource(var1, var6, var7);
			Entitlement var8;
			var4 = this.secManager.hasEntitlement(var3, var1, var8 = new Entitlement("SEARCH", var6));
			if (var4 && var2 != null) {
				var4 = this.secManager.hasEntitlement(var3, var1, var8 = this.getMappedEntitlement(var2));
				var5 = true;
			}

			if (!var4) {
				this.traceAccessResult(var5
						? "Entitlement check for principal ''{0}'' failed for the following entitlement\n    ''{1}'' ''{2}''"
						: "Access check for principal ''{0}'' failed for the following entitlement\n    ''{1}'' ''{2}''",
						Level.FINE, var1, var8);
				return null;
			}

			this.traceAccessResult(var5
					? "Entitlement check for principal ''{0}'' succeeded for the following entitlement\n    ''{1}'' ''{2}''"
					: "Access check for principal ''{0}'' succeeded for the following entitlement\n    ''{1}'' ''{2}''",
					Level.FINEST, var1, var8);
			this.checkAttributePermissions(var1, "READ", true, false);
		}

		trcLogger.exiting(CLASSNAME, "checkPermission_SEARCH()");
		return var1.getEntity();
	}

	private void checkAttributePermissions(EntityResource var1, String var2, boolean var3, boolean var4)
			throws WIMException {
		trcLogger.entering(CLASSNAME, "checkAttributePermissions()");
		Subject var5 = this.getCallerSubject();
		Hashtable var11 = new Hashtable();
		DataObject var12 = var1.getEntity();
		Set var9 = SDOHelper.getEntityAttributes(var12, false, false);
		Iterator var14 = var9.iterator();

		while (true) {
			while (var14.hasNext()) {
				String var7 = (String) var14.next();
				String var8 = this.getGroupForAttribute(var7);
				if (var4 && SDOHelper.isAttributeEntityType(var12, var7)) {
					Object var10;
					if (!SDOHelper.isAttributeMultiValued(var12, var7)) {
						var10 = new ArrayList();
						((List) var10).add(var12.getDataObject(var7));
					} else {
						var10 = var12.getList(var7);
					}

					Iterator var15 = ((List) var10).iterator();

					while (var15.hasNext()) {
						this.checkPermission_GET(new EntityResource(var1.getRoot(), (DataObject) var15.next()));
					}
				} else {
					Entitlement var13;
					boolean var6 = this.hasAttributeEntitlement(var5, var1,
							var13 = new Entitlement(var2, var1.getEntityType(), var8), var11);
					if (!var6 && var2.equals("READ") && var3) {
						var12.unset(var7);
						this.traceAccessResult(
								"Access check for principal ''{0}'' failed for the following entitlement\n    ''{1}'' ''{2}''",
								Level.FINE, var1, var13);
					} else {
						this.checkAccessResult(var1, var13, var6);
					}
				}
			}

			trcLogger.exiting(CLASSNAME, "checkAttributePermissions()");
			return;
		}
	}

	private boolean hasAttributeEntitlement(Subject var1, EntityResource var2, Entitlement var3, Map var4)
			throws WIMException {
		trcLogger.entering(CLASSNAME, "hasAttributeEntitlement()");
		String var5 = var3.getMethod() + ":" + var3.getAttribute();
		Boolean var6;
		if ((var6 = (Boolean) var4.get(var5)) == null) {
			var6 = this.secManager.hasEntitlement(var1, var2, var3);
			var4.put(var5, var6);
		}

		trcLogger.exiting(CLASSNAME, "hasAttributeEntitlement()");
		return var6;
	}

	private Entitlement getMappedEntitlement(Entitlement var1) {
		trcLogger.entering(CLASSNAME, "getMappedEntitlement()");
		Entitlement var2;
		if (var1.isAttributeEntitlement()) {
			var2 = new Entitlement(var1.getMethod(), var1.getObject(), this.getGroupForAttribute(var1.getAttribute()));
		} else {
			var2 = var1;
		}

		trcLogger.exiting(CLASSNAME, "getMappedEntitlement()");
		return var2;
	}

	public Set getRoles(EntityResource var1) throws WIMException {
		trcLogger.entering(CLASSNAME, "getRoles()");
		Subject var2 = this.getCallerSubject();
		Set var3 = null;
		if (this.isSecurityEnabled) {
			var1 = new EntityResource(var1, SDOHelper.getEntityType(var1.getEntity(), true),
					this.getDelegatedAdminViewId(var1, "GET_ENTITLEMENTS"));
			var3 = this.secManager.getRoles(var2, var1);
		}

		trcLogger.exiting(CLASSNAME, "getRoles()");
		return var3;
	}

	public boolean doesEntitlementExist(EntityResource var1, Entitlement var2) throws WIMException {
		trcLogger.entering(CLASSNAME, "doesEntitlementExist()");
		Subject var3 = this.getCallerSubject();
		boolean var4 = false;
		if (this.isSecurityEnabled) {
			var1 = new EntityResource(var1, SDOHelper.getEntityType(var1.getEntity(), true),
					this.getDelegatedAdminViewId(var1, "GET_ENTITLEMENTS"));
			var4 = this.secManager.doesEntitlementExist(var3, var1, this.getMappedEntitlement(var2));
		}

		trcLogger.exiting(CLASSNAME, "doesEntitlementExist()");
		return var4;
	}

	public Set getEntitlements(EntityResource var1, EntitlementRequest var2) throws WIMException {
		trcLogger.entering(CLASSNAME, "getEntitlements()");
		Subject var3 = this.getCallerSubject();
		HashSet var9 = null;
		Hashtable var11 = new Hashtable();
		if (this.isSecurityEnabled) {
			String var4 = SDOHelper.getEntityType(var1.getEntity(), true);
			String var5 = this.getDelegatedAdminViewId(var1, "GET_ENTITLEMENTS");
			var1 = new EntityResource(var1, var4, var5);
			Set var10 = this.secManager.getEntitlements(var3, var1);
			var9 = new HashSet();
			Iterator var13 = var10.iterator();

			while (var13.hasNext()) {
				Entitlement var12 = (Entitlement) var13.next();
				if (var2.isObjectEntitlementsDesired() && !var12.isAttributeEntitlement()
						&& this.isEntitlementApplicable(var4, var12)) {
					var12 = new Entitlement(var12.getMethod(), var4);
					if (!var9.contains(var12)) {
						var9.add(var12);
					}
				}
			}

			if (var2.isAttributeEntitlementsDesired()) {
				Set var8 = var2.getEntitlementAttributes() == null
						? SDOHelper.getEntityAttributes(var1.getEntity(), true, false)
						: var2.getEntitlementAttributes();
				var13 = var8.iterator();

				while (var13.hasNext()) {
					String var6 = (String) var13.next();
					String var7 = this.getGroupForAttribute(var6);
					if (!SDOHelper.isAttributeEntityType(var1.getEntity(), var6)
							&& this.hasAttributeEntitlement(var3, var1, new Entitlement("READ", var4, var7), var11)) {
						var9.add(new Entitlement("READ", var4, var6));
					}

					if (this.hasAttributeEntitlement(var3, var1, new Entitlement("WRITE", var4, var7), var11)) {
						var9.add(new Entitlement("WRITE", var4, var6));
					}
				}
			}
		}

		trcLogger.exiting(CLASSNAME, "getEntitlements()");
		return var9;
	}

	public DataObject setEntitlements(DataObject var1, DataObject var2, EntitlementRequest var3) throws WIMException {
		trcLogger.entering(CLASSNAME,
				"setEntitlements(DataObject inputRoot, DataObject outputRoot, EntitlementRequest entitleRequest)");
		if (this.isSecurityEnabled && !var3.isEmpty()) {
			List var4 = var2.getList("entities");
			Iterator var5 = var4.iterator();

			while (var5.hasNext()) {
				this.setEntitlements(new EntityResource(var1, (DataObject) var5.next()), var3);
			}
		}

		trcLogger.exiting(CLASSNAME,
				"setEntitlements(DataObject inputRoot, DataObject outputRoot, EntitlementRequest entitleRequest)");
		return var2;
	}

	private DataObject setEntitlements(EntityResource var1, EntitlementRequest var2) throws WIMException {
		trcLogger.entering(CLASSNAME, "setEntitlements(EntityResource resource, EntitlementRequest entitleRequest)");
		DataObject var7 = var1.getEntity();
		DataObject var9 = var7.createDataObject("entitlementInfo");
		if (var2.isRolesDesired()) {
			var9.setList("roles", new ArrayList(this.getRoles(var1)));
		}

		Iterator var11;
		if (var2.isObjectEntitlementsDesired() || var2.isAttributeEntitlementsDesired()) {
			Set var5 = this.getEntitlements(var1, var2);
			var11 = var5.iterator();

			while (var11.hasNext()) {
				Entitlement var10 = (Entitlement) var11.next();
				DataObject var8 = var9.createDataObject("entitlements");
				EntitlementHelper.setEntitlementToDataObject(var10, var8);
			}
		}

		if (var2.getEntitlementCheck() != null) {
			var9.setBoolean("entitlementCheckResult", this.doesEntitlementExist(var1, var2.getEntitlementCheck()));
		}

		Set var6 = SDOHelper.getEntityAttributes(var7, false, false);
		var11 = var6.iterator();

		while (true) {
			String var3;
			do {
				if (!var11.hasNext()) {
					trcLogger.exiting(CLASSNAME,
							"setEntitlements(EntityResource resource, EntitlementRequest entitleRequest)");
					return var7;
				}

				var3 = (String) var11.next();
			} while (!SDOHelper.isAttributeEntityType(var7, var3));

			Object var4;
			if (!SDOHelper.isAttributeMultiValued(var7, var3)) {
				var4 = new ArrayList();
				((List) var4).add(var7.getDataObject(var3));
			} else {
				var4 = var7.getList(var3);
			}

			Iterator var12 = ((List) var4).iterator();

			while (var12.hasNext()) {
				this.setEntitlements(new EntityResource(var1.getRoot(), (DataObject) var12.next()), var2);
			}
		}
	}

	private boolean isEntitlementApplicable(String var1, Entitlement var2) {
		Entitlement var3 = new Entitlement(var2.getMethod(), var1, var2.getAttribute());
		return EntitlementHelper.getMethodPermission(var2).implies(EntitlementHelper.getMethodPermission(var3));
	}

	public void setRunAsSubject(Subject var1) {
		this.runAsSubject = var1;
	}

	public Object runAsSuperUser(PrivilegedExceptionAction var1) throws WIMException {
		trcLogger.entering(CLASSNAME, "runAsSuperUser()");
		if (EnvironmentManager.getWASServerStatus() && !this.isArgusLoaded) {
			this.initialize(this.finalConfig, this.finalObject);
		}

		Object var2;
		if (this.isSecurityEnabled) {
			try {
				var2 = this.secManager.runAsSuperUser(var1);
			} catch (PrivilegedActionException var5) {
				if (var5.getCause() instanceof WIMException) {
					throw (WIMException) var5.getCause();
				}

				throw new AuthPrivilegedException("An error occured while performing a task as the super user",
						var5.getCause(), Level.FINE);
			}
		} else {
			try {
				var2 = var1.run();
			} catch (Exception var4) {
				if (var4 instanceof WIMException) {
					throw (WIMException) var4;
				}

				throw new AuthPrivilegedException("An error occured while performing a task as the super user", var4,
						Level.FINE);
			}
		}

		trcLogger.exiting(CLASSNAME, "runAsSuperUser()");
		return var2;
	}

	private Subject getAnonymousSubject() {
      return (Subject)AccessController.doPrivileged(new 2(this));
   }

	private Subject getCallerSubject() throws WIMException {
      trcLogger.entering(CLASSNAME, "getCallerSubject()");

      try {
         return (Subject)AccessController.doPrivileged(new 3(this));
      } catch (PrivilegedActionException var2) {
         throw (AuthSystemException)var2.getException();
      }
   }

	private String getCallerSubjectUniqueName() throws WIMException {
		trcLogger.entering(CLASSNAME, "getCallerSubjectUniqueName()");
		if (!this.isArgusLoaded) {
			this.initialize(this.finalConfig, this.finalObject);
		}

		Subject var2 = this.getCallerSubject();
		Principal var3 = (Principal) var2.getPrincipals().iterator().next();
		String var1;
		if (var3.equals(VirtualPrincipal.AnonymousUser) && this.secManager.isSuperUser(var2)) {
			var1 = "**SUPER USER**";
		} else {
			var1 = this.accessHandler.getSubjectPrincipal(this.getCallerSubject()).getName();
		}

		trcLogger.exiting(CLASSNAME, "getCallerSubjectUniqueName()");
		return var1;
	}

	private String getGroupForAttribute(String var1) {
		trcLogger.entering(CLASSNAME, "getGroupForAttribute()");
		String var2;
		if (this.isAttributeGroupingEnabled) {
			var2 = (String) this.attributeGroups.get(var1);
			if (var2 == null) {
				var2 = this.defaultAttributeGroup;
			}

			trcLogger.log(Level.FINEST, "The attribute ''{0}'' was mapped to group ''{1}'' for the access check",
					new Object[]{var1, var2});
		} else {
			var2 = var1;
		}

		trcLogger.exiting(CLASSNAME, "getGroupForAttribute()");
		return var2;
	}

	private Set getAttributesForGroup(String var1) {
		trcLogger.entering(CLASSNAME, "getAttributesForGroup()");
		HashSet var2 = new HashSet();
		if (this.isAttributeGroupingEnabled) {
			Iterator var3 = this.attributeGroups.entrySet().iterator();

			while (var3.hasNext()) {
				Entry var4 = (Entry) var3.next();
				if (var4.getValue().equals(var1)) {
					var2.add(var4.getKey());
				}
			}
		} else {
			var2.add(var1);
		}

		trcLogger.exiting(CLASSNAME, "getAttributesForGroup()");
		return var2;
	}

	private void traceAccessResult(String var1, Level var2, EntityResource var3, Entitlement var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.log(var2, var1, new Object[]{this.getCallerSubjectUniqueName(), var4.toSimpleString(),
					SDOHelper.getEntityDisplayName(var3.getEntity())});
		}

	}

	private void traceAccessResult(String var1, Set var2, Level var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.log(var3, var1, new Object[]{this.getCallerSubjectUniqueName(), var2});
		}

	}

	private void checkAccessResult(EntityResource var1, Entitlement var2, boolean var3) throws WIMException {
		if (!var3) {
			throw new AccessException(this.getCallerSubjectUniqueName(),
					SDOHelper.getEntityDisplayName(var1.getEntity()), var1.getResourceId(), var2, Level.SEVERE);
		} else {
			this.traceAccessResult(
					"Access check for principal ''{0}'' succeeded for the following entitlement\n    ''{1}'' ''{2}''",
					Level.FINEST, var1, var2);
		}
	}

	private String getDelegatedAdminViewId(EntityResource var1, String var2) throws WIMException {
		trcLogger.entering(CLASSNAME, "getDelegatedAdminViewId()");
		this.initialize(this.finalConfig, this.finalObject);
		String var3 = null;
		String var5 = "DefaultDAView";
		DataObject var8 = var1.getEntity();
		if (var2.equals("GET_ENTITLEMENTS")) {
			var3 = SDOHelper.getEntityViewId(var5, var8);
		}

		if (var3 == null) {
			String var4 = "com.ibm.ws.wim.authz.ProfileSecurityManager";
			DataObject var9 = DataGraphHelper.cloneDataObject(var8);
			if (var2.equals("CREATE")) {
				var9.unset("identifier");
			}

			DataObject var6 = SchemaManager.singleton().createRootDataObject();
			var6.getList("entities").add(var9);
			DataObject var11 = var6.createDataObject("controls", "http://www.ibm.com/websphere/wim", "ViewControl");
			var11.setString("viewName", var5);
			var6 = PluginManager.getPluginManager().preExitCall(var4, var6);
			var6 = PluginManager.getPluginManager().inlineExitCall(var4, var6, "getInViewExplicit");
			var6 = PluginManager.getPluginManager().postExitCall(var4, var6, var6);
			DataObject var7 = var6.getDataGraph().getRootObject().getDataObject("Root");
			DataObject var10 = var7.getDataObject("entities.0");
			var3 = SDOHelper.getEntityViewId(var5, var10);
		}

		if (var3 == null) {
			throw new AuthSystemException("AUTH_VIEW_PLUGIN_FAILURE",
					new Object[]{SDOHelper.getEntityDisplayName(var1.getEntity())}, Level.SEVERE);
		} else {
			trcLogger.log(Level.FINEST, "The entity ''{0}'' was mapped to the delegated administration path ''{1}''",
					new Object[]{SDOHelper.getEntityDisplayName(var1.getEntity()), var3});
			trcLogger.exiting(CLASSNAME, "getDelegatedAdminViewId()");
			return var3;
		}
	}

	private boolean hasReadAccess(Set var1) {
		return var1.contains("IdMgrAdmin") || var1.contains("IdMgrWriter") || var1.contains("IdMgrReader");
	}

	private boolean hasWriteAccess(Set var1) {
		return var1.contains("IdMgrAdmin") || var1.contains("IdMgrWriter");
	}

	public JACCSecurityManager getAuthzPolicy() {
		return this.secManager;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = JACCAuthorizationService.class.getName();
		msgLogger = WIMLogger.getMessageLogger("com.ibm.ws.wim.security.authz");
		trcLogger = WIMLogger.getTraceLogger("com.ibm.ws.wim.security.authz");
	}
}