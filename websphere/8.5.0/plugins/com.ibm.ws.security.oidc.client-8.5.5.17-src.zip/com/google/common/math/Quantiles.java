package com.google.common.math;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.math.Quantiles.1;
import com.google.common.math.Quantiles.Scale;
import com.google.common.math.Quantiles.ScaleAndIndex;

@Beta
@GwtIncompatible
public final class Quantiles {
	public static ScaleAndIndex median() {
		return scale(2).index(1);
	}

	public static Scale quartiles() {
		return scale(4);
	}

	public static Scale percentiles() {
		return scale(100);
	}

	public static Scale scale(int scale) {
      return new Scale(scale, (1)null);
   }

	private static boolean containsNaN(double... dataset) {
		double[] var1 = dataset;
		int var2 = dataset.length;

		for (int var3 = 0; var3 < var2; ++var3) {
			double value = var1[var3];
			if (Double.isNaN(value)) {
				return true;
			}
		}

		return false;
	}

	private static double interpolate(double lower, double upper, double remainder, double scale) {
		if (lower == Double.NEGATIVE_INFINITY) {
			return upper == Double.POSITIVE_INFINITY ? Double.NaN : Double.NEGATIVE_INFINITY;
		} else {
			return upper == Double.POSITIVE_INFINITY
					? Double.POSITIVE_INFINITY
					: lower + (upper - lower) * remainder / scale;
		}
	}

	private static void checkIndex(int index, int scale) {
		if (index < 0 || index > scale) {
			throw new IllegalArgumentException("Quantile indexes must be between 0 and the scale, which is " + scale);
		}
	}

	private static double[] longsToDoubles(long[] longs) {
		int len = longs.length;
		double[] doubles = new double[len];

		for (int i = 0; i < len; ++i) {
			doubles[i] = (double) longs[i];
		}

		return doubles;
	}

	private static double[] intsToDoubles(int[] ints) {
		int len = ints.length;
		double[] doubles = new double[len];

		for (int i = 0; i < len; ++i) {
			doubles[i] = (double) ints[i];
		}

		return doubles;
	}

	private static void selectInPlace(int required, double[] array, int from, int to) {
		int partitionPoint;
		if (required == from) {
			partitionPoint = from;

			for (int index = from + 1; index <= to; ++index) {
				if (array[partitionPoint] > array[index]) {
					partitionPoint = index;
				}
			}

			if (partitionPoint != from) {
				swap(array, partitionPoint, from);
			}

		} else {
			while (to > from) {
				partitionPoint = partition(array, from, to);
				if (partitionPoint >= required) {
					to = partitionPoint - 1;
				}

				if (partitionPoint <= required) {
					from = partitionPoint + 1;
				}
			}

		}
	}

	private static int partition(double[] array, int from, int to) {
		movePivotToStartOfSlice(array, from, to);
		double pivot = array[from];
		int partitionPoint = to;

		for (int i = to; i > from; --i) {
			if (array[i] > pivot) {
				swap(array, partitionPoint, i);
				--partitionPoint;
			}
		}

		swap(array, from, partitionPoint);
		return partitionPoint;
	}

	private static void movePivotToStartOfSlice(double[] array, int from, int to) {
		int mid = from + to >>> 1;
		boolean toLessThanMid = array[to] < array[mid];
		boolean midLessThanFrom = array[mid] < array[from];
		boolean toLessThanFrom = array[to] < array[from];
		if (toLessThanMid == midLessThanFrom) {
			swap(array, mid, from);
		} else if (toLessThanMid != toLessThanFrom) {
			swap(array, from, to);
		}

	}

	private static void selectAllInPlace(int[] allRequired, int requiredFrom, int requiredTo, double[] array, int from,
			int to) {
		int requiredChosen = chooseNextSelection(allRequired, requiredFrom, requiredTo, from, to);
		int required = allRequired[requiredChosen];
		selectInPlace(required, array, from, to);

		int requiredBelow;
		for (requiredBelow = requiredChosen - 1; requiredBelow >= requiredFrom
				&& allRequired[requiredBelow] == required; --requiredBelow) {
			;
		}

		if (requiredBelow >= requiredFrom) {
			selectAllInPlace(allRequired, requiredFrom, requiredBelow, array, from, required - 1);
		}

		int requiredAbove;
		for (requiredAbove = requiredChosen + 1; requiredAbove <= requiredTo
				&& allRequired[requiredAbove] == required; ++requiredAbove) {
			;
		}

		if (requiredAbove <= requiredTo) {
			selectAllInPlace(allRequired, requiredAbove, requiredTo, array, required + 1, to);
		}

	}

	private static int chooseNextSelection(int[] allRequired, int requiredFrom, int requiredTo, int from, int to) {
		if (requiredFrom == requiredTo) {
			return requiredFrom;
		} else {
			int centerFloor = from + to >>> 1;
			int low = requiredFrom;
			int high = requiredTo;

			while (high > low + 1) {
				int mid = low + high >>> 1;
				if (allRequired[mid] > centerFloor) {
					high = mid;
				} else {
					if (allRequired[mid] >= centerFloor) {
						return mid;
					}

					low = mid;
				}
			}

			if (from + to - allRequired[low] - allRequired[high] > 0) {
				return high;
			} else {
				return low;
			}
		}
	}

	private static void swap(double[] array, int i, int j) {
		double temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
}