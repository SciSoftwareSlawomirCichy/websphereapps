package com.ibm.ejs.container.finder;

import java.rmi.Remote;
import java.util.Vector;
import javax.rmi.CORBA.Tie;
import org.omg.CORBA.BAD_OPERATION;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.CORBA.SystemException;
import org.omg.CORBA.portable.Delegate;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ResponseHandler;
import org.omg.CORBA.portable.UnknownException;
import org.omg.CORBA_2_3.portable.ObjectImpl;

public class _FinderResultServerImpl_Tie extends ObjectImpl implements Tie {
	private FinderResultServerImpl target = null;
	private ORB orb = null;
	private static final String[] _type_ids = new String[]{
			"RMI:com.ibm.ejs.container.finder.FinderResultServer:0000000000000000"};

	public String[] _ids() {
		return (String[]) _type_ids.clone();
	}

	public OutputStream _invoke(String var1, InputStream var2, ResponseHandler var3) throws SystemException {
		try {
			org.omg.CORBA_2_3.portable.InputStream var4 = (org.omg.CORBA_2_3.portable.InputStream) var2;
			switch (var1.length()) {
				case 4 :
					if (var1.equals("size")) {
						return this.size(var4, var3);
					}
				case 24 :
					if (var1.equals("getNextWrapperCollection")) {
						return this.getNextWrapperCollection(var4, var3);
					}
				default :
					throw new BAD_OPERATION();
			}
		} catch (SystemException var5) {
			throw var5;
		} catch (Throwable var6) {
			throw new UnknownException(var6);
		}
	}

	public void _set_delegate(Delegate var1) {
		super._set_delegate(var1);
		if (var1 != null) {
			this.orb = this._orb();
		} else {
			this.orb = null;
		}

	}

	public void deactivate() {
		if (this.orb != null) {
			this.orb.disconnect(this);
			this._set_delegate((Delegate) null);
		}

	}

	private OutputStream getNextWrapperCollection(org.omg.CORBA_2_3.portable.InputStream var1, ResponseHandler var2)
			throws Throwable {
		int var3 = var1.read_long();
		int var4 = var1.read_long();
		Vector var5 = this.target.getNextWrapperCollection(var3, var4);
		org.omg.CORBA_2_3.portable.OutputStream var6 = (org.omg.CORBA_2_3.portable.OutputStream) var2.createReply();
		var6.write_value(var5,
				class$java$util$Vector != null
						? class$java$util$Vector
						: (class$java$util$Vector = class$("java.util.Vector")));
		return var6;
	}

	public Remote getTarget() {
		return this.target;
	}

	public ORB orb() {
		return this._orb();
	}

	public void orb(ORB var1) {
		var1.connect(this);
	}

	public void setTarget(Remote var1) {
		this.target = (FinderResultServerImpl) var1;
	}

	private OutputStream size(org.omg.CORBA_2_3.portable.InputStream var1, ResponseHandler var2) throws Throwable {
		int var3 = this.target.size();
		OutputStream var4 = var2.createReply();
		var4.write_long(var3);
		return var4;
	}

	public Object thisObject() {
		return this;
	}
}