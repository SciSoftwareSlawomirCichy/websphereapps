package com.ibm.icu.text;

import com.ibm.icu.text.RemoveTransliterator.1;
import com.ibm.icu.text.Transliterator.Position;

class RemoveTransliterator extends Transliterator {
	private static String _ID = "Any-Remove";

	static void register() {
      Transliterator.registerFactory(_ID, new 1());
      Transliterator.registerSpecialInverse("Remove", "Null", false);
   }

	public RemoveTransliterator() {
		super(_ID, (UnicodeFilter) null);
	}

	protected void handleTransliterate(Replaceable text, Position index, boolean incremental) {
		text.replace(index.start, index.limit, "");
		int len = index.limit - index.start;
		index.contextLimit -= len;
		index.limit -= len;
	}
}