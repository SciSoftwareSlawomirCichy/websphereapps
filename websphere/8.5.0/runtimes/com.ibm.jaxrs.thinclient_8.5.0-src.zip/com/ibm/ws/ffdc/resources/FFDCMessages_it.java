package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_it extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Motore di analisi che utilizza il database: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Incidente FFDC emesso in {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: Tentativo da parte della gestione file di log FFDC di eliminare il file {0}"},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: La gestione file di log FFDC ha rimosso {0} di {1} file che hanno raggiunto la durata massima configurata"},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: La gestione file di log FFDC non è riuscita a eliminare il file {0}"},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: La gestione file di log FFDC non è riuscita a ottenere l'elenco dei file di eccezione"},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC ha chiuso il file di flusso dell''incidente {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC ha aperto il file di flusso dell''incidente {0}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: FFDC non è riuscito a chiudere il file di flusso dell''incidente {0}, eccezione rilevata {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: FFDC non è riuscito ad aprire o a creare il file di flusso dell''incidente {0}, eccezione rilevata {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: FFDC non è riuscito a scrivere nel file di flusso dell''incidente {0}, eccezione rilevata {1}"}};

	public Object[][] getContents() {
		return resources;
	}
}