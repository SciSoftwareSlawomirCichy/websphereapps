package com.ibm.ws.ffdc.resources;

import java.util.ListResourceBundle;

public class FFDCMessages_fr extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Moteur d''analyse utilisant la base de données : {0}."},
			{"FFDCIncidentEmitted", "FFDC1003I: Incident FFDC émis sur {0} {1} {2}"},
			{"FFDCJANITOR_ATTEMPTING_TO_DELETE_FILE",
					"FFDC0002I: La fonction de gestion des journaux FFDC a tenté de supprimer le fichier {0}."},
			{"FFDCJANITOR_DELETED_FILES",
					"FFDC0004I: La fonction de gestion des journaux FFDC a supprimé {0} des {1} fichiers qui avaient atteint la date maximale configurée."},
			{"FFDCJANITOR_FAILED_TO_DELETE_FILE",
					"FFDC0003I: La fonction de gestion des journaux FFDC n''est pas parvenue à supprimer le fichier {0}."},
			{"FFDCJANITOR_FAILED_TO_GET_EXCEPTION_FILES_LIST",
					"FFDC0001W: La fonction de gestion des journaux FFDC n'est pas parvenue à obtenir la liste des fichiers d'exceptions."},
			{"INCIDENTSTREAMIMPL_CLOSED_FILE", "FFDC0010I: FFDC a fermé le fichier STREAM d''incident {0}"},
			{"INCIDENTSTREAMIMPL_CREATED_FILE", "FFDC0009I: FFDC a ouvert le fichier {0} de flux des incidents."},
			{"INCIDENTSTREAMIMPL_FAILED_TO_CLOSE_FILE",
					"FFDC0012I: FFDC n''est pas parvenu à fermer le fichier STREAM d''incident {0} ; interception de l''exception {1}."},
			{"INCIDENTSTREAMIMPL_FAILED_TO_OPEN_FILE",
					"FFDC0011I: FFDC n''a pas pu ouvrir ou créer le fichier STREAM d''incident {0}. Interception de l''exception {1}"},
			{"INCIDENTSTREAMIMPL_FAILED_TO_WRITE_TO_FILE",
					"FFDC0013I: FFDC n''est pas parvenu à écrire le fichier STREAM d''incident {0} ; interception de l''exception {1}."}};

	public Object[][] getContents() {
		return resources;
	}
}