package com.ibm.ejs.cm.portability;

public class HugeString {
	private String myString = null;

	public HugeString(String ins) {
		this.myString = ins;
	}

	public int length() {
		return this.myString.length();
	}

	public String getString() {
		return this.myString;
	}
}