package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import com.ibm.ws.wim.configmodel.TopicSubscriberList;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class PluginManagerConfigurationTypeImpl extends EDataObjectImpl implements PluginManagerConfigurationType {
	protected TopicSubscriberList topicSubscriberList = null;
	protected TopicRegistrationList topicRegistrationList = null;

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getPluginManagerConfigurationType();
	}

	public TopicSubscriberList getTopicSubscriberList() {
		return this.topicSubscriberList;
	}

	public NotificationChain basicSetTopicSubscriberList(TopicSubscriberList var1, NotificationChain var2) {
		TopicSubscriberList var3 = this.topicSubscriberList;
		this.topicSubscriberList = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 0, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setTopicSubscriberList(TopicSubscriberList var1) {
		if (var1 != this.topicSubscriberList) {
			NotificationChain var2 = null;
			if (this.topicSubscriberList != null) {
				var2 = ((InternalEObject) this.topicSubscriberList).eInverseRemove(this, -1, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -1, (Class) null, var2);
			}

			var2 = this.basicSetTopicSubscriberList(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var1, var1));
		}

	}

	public TopicSubscriberList createTopicSubscriberList() {
		TopicSubscriberList var1 = ConfigmodelFactory.eINSTANCE.createTopicSubscriberList();
		this.setTopicSubscriberList(var1);
		return var1;
	}

	public TopicRegistrationList getTopicRegistrationList() {
		return this.topicRegistrationList;
	}

	public NotificationChain basicSetTopicRegistrationList(TopicRegistrationList var1, NotificationChain var2) {
		TopicRegistrationList var3 = this.topicRegistrationList;
		this.topicRegistrationList = var1;
		if (this.eNotificationRequired()) {
			ENotificationImpl var4 = new ENotificationImpl(this, 1, 1, var3, var1);
			if (var2 == null) {
				var2 = var4;
			} else {
				((NotificationChain) var2).add(var4);
			}
		}

		return (NotificationChain) var2;
	}

	public void setTopicRegistrationList(TopicRegistrationList var1) {
		if (var1 != this.topicRegistrationList) {
			NotificationChain var2 = null;
			if (this.topicRegistrationList != null) {
				var2 = ((InternalEObject) this.topicRegistrationList).eInverseRemove(this, -2, (Class) null, var2);
			}

			if (var1 != null) {
				var2 = ((InternalEObject) var1).eInverseAdd(this, -2, (Class) null, var2);
			}

			var2 = this.basicSetTopicRegistrationList(var1, var2);
			if (var2 != null) {
				var2.dispatch();
			}
		} else if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var1, var1));
		}

	}

	public TopicRegistrationList createTopicRegistrationList() {
		TopicRegistrationList var1 = ConfigmodelFactory.eINSTANCE.createTopicRegistrationList();
		this.setTopicRegistrationList(var1);
		return var1;
	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return this.basicSetTopicSubscriberList((TopicSubscriberList) null, var4);
				case 1 :
					return this.basicSetTopicRegistrationList((TopicRegistrationList) null, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getTopicSubscriberList();
			case 1 :
				return this.getTopicRegistrationList();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setTopicSubscriberList((TopicSubscriberList) var2);
				return;
			case 1 :
				this.setTopicRegistrationList((TopicRegistrationList) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setTopicSubscriberList((TopicSubscriberList) null);
				return;
			case 1 :
				this.setTopicRegistrationList((TopicRegistrationList) null);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.topicSubscriberList != null;
			case 1 :
				return this.topicRegistrationList != null;
			default :
				return this.eDynamicIsSet(var1);
		}
	}
}