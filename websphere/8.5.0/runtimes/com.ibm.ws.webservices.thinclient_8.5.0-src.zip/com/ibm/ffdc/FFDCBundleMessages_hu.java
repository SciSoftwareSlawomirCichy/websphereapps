package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_hu extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: FFDC formázó hozzáadva: {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Az elemző alrendszer által használt adatbázis: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: Nem sikerült feloldani az elemzési alrendszert:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: FFDC adatgyűjtő hozzáadva: {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: FFDC adatgyűjtő eltávolítva: {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: FFDC incidens lett kiadva a SystemErr helyen: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC hibatűrő módban, ellenőrizze a hibákat: {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: FFDC incidenstovábbító hozzáadva: {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: FFDC incidenstovábbító eltávolítva: {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: FFDC incidens lett kiadva a következő helyen: {0} {1} {2}"},
			{"FFDCProviderAborted",
					"FFDC1000I: A(z) {0} FFDC szolgáltató megszakadt, a kivételt a következő üzenet tartalmazza."},
			{"FFDCProviderAbortedE", "FFDC1001I: Az FFDC szolgáltató {0} kivétellel megszakadt."},
			{"FFDCProviderException", "FFDC1008I: FFDC szolgáltató kivétel:"},
			{"FFDCProviderInstalled", "FFDC1007I: FFDC szolgáltató telepítve: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: FFDC formázó eltávolítva: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}