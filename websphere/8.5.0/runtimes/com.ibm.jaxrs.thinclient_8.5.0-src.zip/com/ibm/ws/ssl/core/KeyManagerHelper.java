package com.ibm.ws.ssl.core;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.security.KeyStore;

public class KeyManagerHelper {
	private static final TraceComponent tc = Tr.register(KeyManagerHelper.class, "SSL", "com.ibm.ws.ssl.resources.ssl");

	String normalizeAliasName(String alias, KeyStore ks) {
		String newAlias = null;
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "normalizeAliasName", new Object[]{alias});
		}

		if (alias != null) {
			if (this.doesKeyStoreSupportMixedCaseAliases(ks)) {
				newAlias = alias;
			} else {
				newAlias = alias.toLowerCase();
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "normalizeAliasName", new Object[]{newAlias});
		}

		return newAlias;
	}

	boolean doesKeyStoreSupportMixedCaseAliases(KeyStore ks) {
		String type = ks.getType();
		return type != null && (type.equals("CMSKS") || type.equals("JCERACFKS") || type.equals("JCECCARACFKS")
				|| type.equals("JCEHYBRIDRACFKS"));
	}

	String getAlias(String alias, String[] list) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getAlias", new Object[]{alias, list});
		}

		String matchedAlias = null;
		if (alias != null && !alias.equals("") && list != null && list.length > 0) {
			int i;
			for (i = 0; i < list.length; ++i) {
				if (alias.equals(list[i])) {
					matchedAlias = list[i];
					if (tc.isDebugEnabled()) {
						Tr.debug(tc, "exact match. Alias name :  " + matchedAlias);
					}
				}
			}

			if (matchedAlias == null) {
				for (i = 0; i < list.length; ++i) {
					if (alias.equalsIgnoreCase(list[i])) {
						matchedAlias = list[i];
						if (tc.isDebugEnabled()) {
							Tr.debug(tc, "case insensitive match. Alias name :  " + matchedAlias);
						}
					}
				}
			}

			if (tc.isDebugEnabled()) {
				StringBuffer aliases = new StringBuffer("");

				for (int i = 0; i < list.length; ++i) {
					aliases.append(list[i]);
					aliases.append(" ");
				}

				Tr.debug(tc, "list of Alias names : " + aliases);
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getAlias", new Object[]{matchedAlias});
		}

		return matchedAlias;
	}
}