package com.ibm.ejs.cm.proxy;

import com.ibm.db2.jcc.DB2Wrapper;
import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.cm.portability.DB2390LocalPortabilityLayer;
import com.ibm.ejs.cm.portability.DB2UniversalConnectPortabilityLayer;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.sql.Connection;
import java.sql.SQLException;

public final class DB2ConnectionProxy extends ConnectionProxy implements DB2Wrapper {
	private static final TraceComponent tc = Tr.register(DB2ConnectionProxy.class);

	public DB2ConnectionProxy(ConnectO connection) {
		super(connection);
	}

	public Object getDB2Object() {
		Connection db2Connection;
		try {
			if (!(this.invoker.getPortabilityLayer() instanceof DB2390LocalPortabilityLayer)
					&& !(this.invoker.getPortabilityLayer() instanceof DB2UniversalConnectPortabilityLayer)) {
				db2Connection = null;
				if (tc.isDebugEnabled()) {
					Tr.debug(tc,
							"getDB2Object() returned null.The Connection managed by the ConnectO is not a DB2 390 Local connection.");
				}
			} else {
				db2Connection = this.invoker.getPhysicalConnection();
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "getDB2Object() returned DB2 390 Local connection.");
				}
			}
		} catch (SQLException var3) {
			db2Connection = null;
			Tr.error(tc, "SQLException occured during getDB2Object(). A null object was returned to the caller.");
		}

		return db2Connection;
	}
}