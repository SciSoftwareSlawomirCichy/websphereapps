package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.management.Session;
import com.ibm.websphere.management.configservice.ConfigService;
import com.ibm.websphere.wim.ConfigConstants;
import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.SchemaConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.EntityAlreadyExistsException;
import com.ibm.websphere.wim.exception.EntityHasDescendantsException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InvalidInitPropertyException;
import com.ibm.websphere.wim.exception.MissingInitPropertyException;
import com.ibm.websphere.wim.exception.OperationNotSupportedException;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.ws.security.auth.SubjectHelper;
import com.ibm.ws.security.util.ConfigUtils;
import com.ibm.ws.wim.FactoryManager;
import com.ibm.ws.wim.config.ConfigUtils.GlobalKrb5Config;
import com.ibm.ws.wim.env.ICacheUtil;
import com.ibm.ws.wim.env.IEncryptionUtil;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.NodeHelper;
import com.sun.jndi.ldap.LdapName;
import commonj.sdo.DataObject;
import java.io.File;
import java.net.MalformedURLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.CommunicationException;
import javax.naming.ContextNotEmptyException;
import javax.naming.Name;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.PartialResultException;
import javax.naming.ServiceUnavailableException;
import javax.naming.SizeLimitExceededException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.LdapContext;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginException;

public class LdapConnection extends LdapConnectionBase
		implements
			DynamicConfigService,
			ConfigConstants,
			SchemaConstants,
			LdapConstants {
	private static Properties ldapBindTimeoutProperties = new Properties();
	private static AtomicLong LDAP_STATS_TIMER = new AtomicLong(0L);
	private static AtomicInteger QUICK_LDAP_BIND = new AtomicInteger(0);
	private static int LDAP_CONNECT_TIMEOUT_TRACE = 1000;
	private static int LDAP_BIND_MAX_THREADS_TO_BLOCK = 5;
	static final String COPYRIGHT_NOTICE;
	public static final String WIM_SSL_SOCKE_FACTORY = "com.ibm.ws.security.registry.ldap.LdapSSLSocketFactory";
	public static final String JNDI_CALL = "JNDI_CALL ";
	public static final String WAS_SSL_SOCKE_FACTORY = "com.ibm.websphere.ssl.protocol.SSLSocketFactory";
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private LdapConfigManager iLdapConfigMgr = null;
	private String iReposId = null;
	private static final int URLTYPE_SINGLE = 0;
	private static final int URLTYPE_SEQUENCE = 1;
	private static final String ENVKEY_URL_LIST = "_URL_LIST_";
	private static final String ENVKEY_ACTIVE_URL = "_ACTIVE_URL_";
	private Hashtable iEnvironment = null;
	private String iSSLAlias = null;
	private boolean iEnableContextPool = true;
	private int iInitPoolSize = 1;
	private int iMaxPoolSize = 1;
	private int iPrefPoolSize = 1;
	private int iPoolTimeOut = 0;
	private int iPoolWaitTime = 3000;
	private List<DirContext> iContexts = null;
	private long iPoolCreateTimestamp = 0L;
	private long iPoolCreateTimestampMillisec = 0L;
	private int iLiveContexts = 0;
	private static Object lock;
	private Semaphore lockThreads = null;
	private Control[] iConnCtls = null;
	private int iTimeLimit = 0;
	private int iCountLimit = 0;
	private int iPageSize = 0;
	private NameParser iNameParser = null;
	private boolean iDiskOffLoad = false;
	private String iAttrsCacheName = "AttributesCache";
	private ICacheUtil iAttrsCache = null;
	private int iAttrsCacheSize = 4000;
	private int iAttrsCacheTimeOut = 1200;
	private int iAttrsSizeLmit = 2000;
	private String iServerTTLAttr = null;
	private int sharedPushPolicy = FactoryManager.getCacheUtil().getSharedPushInt();
	private int iAttrsCacheDistPolicy;
	private String iSearchResultsCacheName;
	private ICacheUtil iSearchResultsCache;
	private int iSearchResultsCacheSize;
	private int iSearchResultsCacheTimeOut;
	private int iSearchResultSizeLmit;
	private int iSearchResultsCacheDistPolicy;
	private Map iEnityAttrIds;
	private String[] iAttrIds;
	private boolean iAttrsCacheEnabled;
	private boolean iSearchResultsCacheEnabled;
	private int iAttrRangeStep;
	private static final String ATTR_RANGE_KEYWORD = ";range=";
	private static final String ATTR_RANGE_QUERY = ";range={0}-{1}";
	private static final String ATTR_RANGE_LAST_QUERY = ";range={0}-*";
	private boolean iWriteToSecondary;
	private boolean iReturnToPrimary;
	private long iQueryInterval;
	private long iLastQueryTime;
	private String authentication;
	private String bindAuthMechanism;
	private String krb5Principal;
	private String krb5TicketCache;
	private String krb5Config;
	private String krb5Keytab;
	private KerberosService krbs;

	private void handleBindStat(long var1) {
		String var3 = "handleBindStat(long)";
		if (var1 < (long) LDAP_CONNECT_TIMEOUT_TRACE) {
			QUICK_LDAP_BIND.getAndIncrement();
		}

		long var4 = System.currentTimeMillis();
		if (var4 - LDAP_STATS_TIMER.get() > 1800000L) {
			long var6 = LDAP_STATS_TIMER.getAndSet(var4);
			if (var4 - var6 > 1800000L && trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, var3, "**LDAPBindStat: " + QUICK_LDAP_BIND.get()
						+ " binds took less then " + LDAP_CONNECT_TIMEOUT_TRACE + " ms");
			}
		}

	}

	public LdapConnection(LdapConfigManager var1) {
		this.iAttrsCacheDistPolicy = this.sharedPushPolicy;
		this.iSearchResultsCacheName = "SearchResultsCache";
		this.iSearchResultsCache = null;
		this.iSearchResultsCacheSize = 2000;
		this.iSearchResultsCacheTimeOut = 600;
		this.iSearchResultSizeLmit = 2000;
		this.iSearchResultsCacheDistPolicy = this.sharedPushPolicy;
		this.iEnityAttrIds = null;
		this.iAttrIds = null;
		this.iAttrsCacheEnabled = true;
		this.iSearchResultsCacheEnabled = true;
		this.iAttrRangeStep = 0;
		this.iWriteToSecondary = false;
		this.iReturnToPrimary = false;
		this.iQueryInterval = 900L;
		this.iLastQueryTime = System.currentTimeMillis() / 1000L;
		this.authentication = "simple";
		this.bindAuthMechanism = null;
		this.krb5Principal = null;
		this.krb5TicketCache = null;
		this.krb5Config = null;
		this.krb5Keytab = null;
		this.krbs = null;
		this.iLdapConfigMgr = var1;
	}

	public void initializeRetrieveAttrIds() {
		this.iEnityAttrIds = new Hashtable();
		LdapEntity[] var1 = this.iLdapConfigMgr.getLdapEntities();
		HashSet var2 = new HashSet();
		String[] var3 = new String[0];

		for (int var4 = 0; var4 < var1.length; ++var4) {
			Set var5 = var1[var4].getAttributes();
			var5.add("objectClass");
			String var6 = var1[var4].getExtId();
			if (!"distinguishedName".equalsIgnoreCase(var6)) {
				var5.add(var6);
			}

			var5.remove("userPassword");
			var5.remove("unicodePwd");
			if (this.iServerTTLAttr != null) {
				var5.add(this.iServerTTLAttr);
			}

			String var7 = this.iLdapConfigMgr.getMembershipAttribute();
			if (var7 != null) {
				var5.add(var7);
			}

			this.iEnityAttrIds.put(var1[var4].getName(), (String[]) ((String[]) var5.toArray(var3)));
			var2.addAll(var5);
		}

		var2.add("objectClass");
		String[] var8 = this.iLdapConfigMgr.getMemberAttributes();
		HashSet var9 = new HashSet(var2);

		for (int var10 = 0; var10 < var8.length; ++var10) {
			var9.add(var8[var10]);
		}

		this.iAttrIds = (String[]) ((String[]) var2.toArray(var3));
	}

	public void invalidateAttributes(String var1, String var2, String var3) {
		if (this.getAttributesCache() != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "invalidateAttributes(String, String, String)",
						WIMMessageHelper.generateMsgParms(var1, var2, var3));
			}

			if (var1 != null) {
				this.getAttributesCache().invalidate(toKey(var1));
			}

			if (var2 != null) {
				this.getAttributesCache().invalidate(var2);
			}

			if (var3 != null) {
				this.getAttributesCache().invalidate(toKey(var3));
			}

			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.exiting(CLASSNAME, "invalidateAttributes(String, String, String)",
						this.iAttrsCacheName + " size: " + this.getAttributesCache().size());
			}
		}

	}

	public void invalidateUserSecurityName(String var1) {
		if (this.getAttributesCache() != null) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.entering(CLASSNAME, "invalidateAttributes(String userSecurityName)",
						WIMMessageHelper.generateMsgParms(var1));
			}

			if (var1 != null) {
				String[] var3 = this.iLdapConfigMgr.getLdapNodes();

				for (int var4 = 0; var4 < var3.length; ++var4) {
					String var5 = var3[var4];
					String var6 = toKey(var1, var5);
					this.getAttributesCache().invalidate(var6);
				}
			}

			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.exiting(CLASSNAME, "invalidateAttributes(String userSecurityName)",
						this.iAttrsCacheName + " size: " + this.getAttributesCache().size());
			}
		}

	}

	public void invalidateNamesCache() {
		if (this.getSearchResultsCache() != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "invalidateNamesCache()");
			}

			this.getSearchResultsCache().clear();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "invalidateNamesCache()");
			}
		}

	}

	public void invalidateAttributeCache() {
		if (this.getAttributesCache() != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "invalidateAttributeCache()");
			}

			this.getAttributesCache().clear();
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "invalidateAttributeCache()");
			}
		}

	}

	private ICacheUtil getAttributesCache() {
		if (this.iAttrsCache == null) {
			this.createAttributesCache();
		}

		return this.iAttrsCache;
	}

	private void createAttributesCache() {
		if (this.iAttrsCacheEnabled && FactoryManager.getCacheUtil().isCacheAvailable()) {
			this.iAttrsCache = FactoryManager.getCacheUtil().initialize(this.iAttrsCacheName, this.iAttrsCacheSize,
					this.iDiskOffLoad, this.iAttrsCacheDistPolicy);
			if (this.iAttrsCache != null && trcLogger.isLoggable(Level.FINER)) {
				StringBuffer var2 = new StringBuffer();
				var2.append("\nAttributes Cache: ").append(this.iAttrsCacheName).append(" is enabled:\n");
				var2.append("\tCacheSize: ").append(this.iAttrsCacheSize).append("\n");
				var2.append("\tCacheTimeOut: ").append(this.iAttrsCacheTimeOut).append("\n");
				var2.append("\tDiskOffLoad: ").append(this.iDiskOffLoad).append("\n");
				var2.append("\tCacheDistPolicy: ").append(this.iAttrsCacheDistPolicy);
				trcLogger.logp(Level.FINER, CLASSNAME, "createAttributesCache", var2.toString());
			}
		}

	}

	private ICacheUtil getSearchResultsCache() {
		if (this.iSearchResultsCache == null) {
			this.createSearchResultsCache();
		}

		return this.iSearchResultsCache;
	}

	private void createSearchResultsCache() {
		if (this.iSearchResultsCacheEnabled && FactoryManager.getCacheUtil().isCacheAvailable()) {
			this.iSearchResultsCache = FactoryManager.getCacheUtil().initialize(this.iSearchResultsCacheName,
					this.iSearchResultsCacheSize, this.iDiskOffLoad, this.iSearchResultsCacheDistPolicy);
			if (this.iSearchResultsCache != null && trcLogger.isLoggable(Level.FINER)) {
				StringBuffer var2 = new StringBuffer();
				var2.append("\nSearch Results Cache: ").append(this.iSearchResultsCacheName).append(" is enabled:\n");
				var2.append("\tCacheSize: ").append(this.iSearchResultsCacheSize).append("\n");
				var2.append("\tCacheTimeOut: ").append(this.iSearchResultsCacheTimeOut).append("\n");
				var2.append("\tDiskOffLoad: ").append(this.iDiskOffLoad).append("\n");
				var2.append("\tCacheDistPolicy: ").append(this.iSearchResultsCacheDistPolicy);
				trcLogger.logp(Level.FINER, CLASSNAME, "createSearchResultsCache", var2.toString());
			}
		}

	}

	private void initializeCaches(DataObject var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initializeCaches(DataObject)");
		}

		if (var1 != null) {
			this.iDiskOffLoad = var1.getBoolean("cachesDiskOffLoad");
			DataObject var3 = var1.getDataObject("attributesCache");
			if (var3 != null) {
				this.iAttrsCacheEnabled = var3.getBoolean("enabled");
				if (this.iAttrsCacheEnabled) {
					this.iAttrsCacheSize = var3.getInt("cacheSize");
					this.iAttrsCacheTimeOut = var3.getInt("cacheTimeOut");
					this.iAttrsSizeLmit = var3.getInt("attributeSizeLimit");
					this.iServerTTLAttr = var3.getString("serverTTLAttribute");
					String var4 = var3.getString("cacheDistPolicy");
					if (var4 != null) {
						this.iAttrsCacheDistPolicy = LdapHelper.getCacheDistPolicyInt(var4);
					}

					this.initializeRetrieveAttrIds();
				}
			}

			DataObject var6 = var1.getDataObject("searchResultsCache");
			if (var6 != null) {
				this.iSearchResultsCacheEnabled = var6.getBoolean("enabled");
				if (this.iSearchResultsCacheEnabled) {
					this.iSearchResultsCacheSize = var6.getInt("cacheSize");
					this.iSearchResultsCacheTimeOut = var6.getInt("cacheTimeOut");
					this.iSearchResultSizeLmit = var6.getInt("searchResultSizeLimit");
					String var5 = var6.getString("cacheDistPolicy");
					if (var5 != null) {
						this.iSearchResultsCacheDistPolicy = LdapHelper.getCacheDistPolicyInt(var5);
					}
				}
			}
		}

		if (this.iAttrsCacheEnabled) {
			this.createAttributesCache();
			if (this.iAttrsCache == null && trcLogger.isLoggable(Level.CONFIG)) {
				trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeCaches(DataObject)", "Attributes Cache: "
						+ this.iAttrsCacheName + " is not available because DynaCache is not available yet.");
			}
		} else if (trcLogger.isLoggable(Level.CONFIG)) {
			trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeCaches(DataObject)",
					"Attributes Cache: " + this.iAttrsCacheName + " is disabled.");
		}

		if (this.iSearchResultsCacheEnabled) {
			this.createSearchResultsCache();
			if (this.iSearchResultsCache == null && trcLogger.isLoggable(Level.CONFIG)) {
				trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeCaches(DataObject)", "Search Results Cache: "
						+ this.iSearchResultsCacheName + " is not available because DynaCache is not available yet.");
			}
		} else if (trcLogger.isLoggable(Level.CONFIG)) {
			trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeCaches(DataObject)",
					"Search Results Cache: " + this.iSearchResultsCacheName + " is disabled.");
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initializeCaches(DataObject)");
		}

	}

	private void initializeContextPool(DataObject var1) throws WIMException {
		this.iEnableContextPool = false;
		if (var1 != null) {
			this.iEnableContextPool = var1.getBoolean("enabled");
		}

		if (this.iEnableContextPool) {
			if (var1 != null) {
				if (var1.isSet("initPoolSize")) {
					this.iInitPoolSize = var1.getInt("initPoolSize");
					if (this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock()) {
						LDAP_BIND_MAX_THREADS_TO_BLOCK = this.iLdapConfigMgr.getMaxThreadsToBlock();
						LDAP_CONNECT_TIMEOUT_TRACE = this.iLdapConfigMgr.getBindTimeout();
					}

					this.lockThreads = new Semaphore(LDAP_BIND_MAX_THREADS_TO_BLOCK);
				}

				if (var1.isSet("maxPoolSize")) {
					this.iMaxPoolSize = var1.getInt("maxPoolSize");
				}

				if (var1.isSet("prefPoolSize")) {
					this.iPrefPoolSize = var1.getInt("prefPoolSize");
				}

				if (this.iMaxPoolSize != 0 && this.iMaxPoolSize < this.iInitPoolSize) {
					throw new InvalidInitPropertyException("INIT_POOL_SIZE_TOO_BIG", WIMMessageHelper
							.generateMsgParms(new Integer(this.iInitPoolSize), new Integer(this.iMaxPoolSize)),
							CLASSNAME, "initializeContextPool(DataObject)");
				}

				if (this.iMaxPoolSize != 0 && this.iPrefPoolSize != 0 && this.iMaxPoolSize < this.iPrefPoolSize) {
					throw new InvalidInitPropertyException("PREF_POOL_SIZE_TOO_BIG", WIMMessageHelper
							.generateMsgParms(new Integer(this.iInitPoolSize), new Integer(this.iMaxPoolSize)),
							CLASSNAME, "initializeContextPool(DataObject)");
				}

				if (var1.isSet("poolTimeOut")) {
					this.iPoolTimeOut = var1.getInt("poolTimeOut");
				}

				if (var1.isSet("poolWaitTime")) {
					this.iPoolWaitTime = var1.getInt("poolWaitTime");
				}
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				StringBuffer var3 = new StringBuffer();
				var3.append("\nContext Pool is enabled: ").append("\n");
				var3.append("\tInitPoolSize: ").append(this.iInitPoolSize).append("\n");
				var3.append("\tMaxPoolSize: ").append(this.iMaxPoolSize).append("\n");
				var3.append("\tPrefPoolSize: ").append(this.iPrefPoolSize).append("\n");
				var3.append("\tPoolTimeOut: ").append(this.iPoolTimeOut).append("\n");
				var3.append("\tPoolWaitTime: ").append(this.iPoolWaitTime);
				trcLogger.logp(Level.FINER, CLASSNAME, "initializeContextPool(DataObject)", var3.toString());
			}
		} else {
			trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeContextPool(DataObject)", "\nContext Pool is disabled.");
		}

	}

	private void createContextPool(int var1, String var2) throws NamingException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "createContextPool",
					WIMMessageHelper.generateMsgParms(new Integer(var1), var2, Thread.currentThread()));
		}

		if (var2 == null) {
			var2 = this.getPrimaryURL();
		}

		if (this.iEnableContextPool) {
			long var4 = System.currentTimeMillis();
			long var6 = var4 / 1000L;
			if (var4 - this.iPoolCreateTimestampMillisec > 1000L) {
				Vector var8 = new Vector(var1);
				Hashtable var9 = this.getEnvironment(1, var2);
				String var10 = null;

				try {
					for (int var11 = 0; var11 < var1; ++var11) {
						long var20 = System.currentTimeMillis();
						DirContext var14 = this.createDirContext(var9, var6);
						long var15 = System.currentTimeMillis();
						if (var15 - var20 > (long) LDAP_CONNECT_TIMEOUT_TRACE) {
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "createContextPool",
										"**LDAPConnect time: " + (var15 - var20) + " ms, lock held "
												+ Thread.holdsLock(lock) + ", pool create");
							}
						} else {
							this.handleBindStat(var15 - var20);
						}

						var10 = this.getProviderURL(var14);
						if (!var2.equalsIgnoreCase(var10)) {
							var9 = this.getEnvironment(1, var10);
							var2 = var10;
						}

						var8.add(var14);
					}
				} catch (NamingException var18) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createContextPool", "Context Pool creation FAILED for "
								+ Thread.currentThread() + ", iLiveContext=" + this.iLiveContexts, var18);
					}

					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createContextPool",
								"Cleanup contexts in temp pool: " + var8.size());
					}

					for (int var12 = 0; var12 < var8.size(); ++var12) {
						try {
							DirContext var13 = (DirContext) var8.get(var12);
							var13.close();
						} catch (Exception var17) {
							;
						}
					}

					throw var18;
				}

				this.iLiveContexts += var1;
				this.setActiveURL(var2);
				List var19 = this.iContexts;
				this.iContexts = var8;
				this.iPoolCreateTimestamp = var6;
				this.iPoolCreateTimestampMillisec = var4;
				this.closeContextPool(var19);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "createContextPool",
							"Active Provider URL: " + this.getActiveURL());
					trcLogger.logp(Level.FINEST, CLASSNAME, "createContextPool",
							"ContextPool: total=" + this.iLiveContexts + ", poolSize=" + this.iContexts.size());
				}
			} else {
				trcLogger.logp(Level.FINEST, CLASSNAME, "createContextPool",
						"Pool has already been purged within past second... skipping purge");
			}
		} else {
			this.setActiveURL(var2);
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "createContextPool", "Pool creation completed for " + Thread.currentThread());
		}

	}

	private void closeContextPool(List var1) {
		if (var1 != null) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "closeContextPool", "Context pool being closed by "
						+ Thread.currentThread() + ", Context pool size=" + var1.size());
			}

			for (int var3 = 0; var3 < var1.size(); ++var3) {
				DirContext var4 = (DirContext) var1.get(var3);

				try {
					var4.close();
					--this.iLiveContexts;
				} catch (NamingException var6) {
					trcLogger.logp(Level.FINE, CLASSNAME, "closeContextPool",
							"Can not close LDAP connection: " + var6.toString(true));
				}
			}
		}

	}

	public DirContext createDirContext(String var1, byte[] var2, Control[] var3, NamingException var4)
			throws NamingException {
		String var6 = this.getActiveURL();
		Hashtable var7 = this.getEnvironment(0, var6);
		var7.put("java.naming.security.principal", var1);
		var7.put("java.naming.security.credentials", var2);
		var7.put("java.naming.security.authentication", this.authentication);
		String var8 = DomainManagerUtils.getDomainName();
		Properties var9 = FactoryManager.getSSLUtil().getSSLPropertiesOnThread();

		TimedDirContext var46;
		try {
			if (this.iSSLAlias != null) {
				try {
					trcLogger.logp(Level.FINE, CLASSNAME,
							"createDirContext(String, byte[], Control[], NamingException)",
							"Use WAS SSL Configuration.");
					setWASSSLAlias(this.iSSLAlias, var7);
				} catch (Exception var39) {
					throw new NamingException(var39.getMessage());
				}
			}

			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.entering(CLASSNAME, "JNDI_CALL createDirContext(String, byte[], Control[], NamingException)",
						new Object[]{var7.get("java.naming.provider.url"), var1, this.authentication});
			}

			TimedDirContext var10 = null;

			try {
				long var11 = System.currentTimeMillis();
				var10 = new TimedDirContext(var7, var3, this.iLdapConfigMgr);
				long var13 = System.currentTimeMillis();
				if (var13 - var11 > (long) LDAP_CONNECT_TIMEOUT_TRACE) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME,
								"createDirContext(String, byte[], Control[], NamingException)",
								"**LDAPConnect time: " + (var13 - var11) + " ms, lock held " + Thread.holdsLock(lock)
										+ ", principal=" + var1);
					}
				} else {
					this.handleBindStat(var13 - var11);
				}
			} catch (NamingException var43) {
				if (!isConnectionException(var43, "createDirContext(String, byte[], Control[], NamingException)")) {
					throw var43;
				}

				var7 = this.getEnvironment(1, this.getNextURL(var6));
				long var12 = System.currentTimeMillis();
				var10 = new TimedDirContext(var7, var3, this.iLdapConfigMgr);
				long var14 = System.currentTimeMillis();
				if (var14 - var12 > (long) LDAP_CONNECT_TIMEOUT_TRACE) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME,
								"createDirContext(String, byte[], Control[], NamingException)",
								"**LDAPConnect time: " + (var14 - var12) + " ms, lock held " + Thread.holdsLock(lock)
										+ ", principal=" + var1);
					}
				} else {
					this.handleBindStat(var14 - var12);
				}

				String var16 = this.getProviderURL(var10);
				long var17 = System.currentTimeMillis();
				boolean var19 = false;
				if (this.iEnableContextPool) {
					try {
						var19 = this.lockThreads.tryAcquire(0L, TimeUnit.SECONDS);
					} catch (InterruptedException var42) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.warning(
									CLASSNAME + " " + "createDirContext(String, byte[], Control[], NamingException)"
											+ " Unable to obtain semaphore [" + var42.getMessage() + "]");
						}
					}
				}

				if (!var19 && trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME,
							"createDirContext(String, byte[], Control[], NamingException)",
							"**LDAPBind - failed to acquire semaphore");
				}

				trcLogger.logp(Level.CONFIG, CLASSNAME, "createDirContext(String, byte[], Control[], NamingException)",
						"hasSemaphore = " + var19 + " && blockThread= "
								+ !this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock());
				if (!var19 && this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock()) {
					throw var43;
				}

				try {
					trcLogger.logp(Level.CONFIG, CLASSNAME,
							"createDirContext(String, byte[], Control[], NamingException)", "HERE TO ACQUIRE LOCK");
					Object var20 = lock;
					synchronized (lock) {
						if (var17 > this.iPoolCreateTimestampMillisec) {
							this.createContextPool(this.iLiveContexts, var16);
							((TimedDirContext) var10).setCreateTimestamp(this.iPoolCreateTimestamp);
						}
					}
				} finally {
					if (var19) {
						this.lockThreads.release();
						trcLogger.logp(Level.CONFIG, CLASSNAME,
								"createDirContext(String, byte[], Control[], NamingException)", "Releasing Semaphore");
					}

				}
			}

			if (this.iLdapConfigMgr.getIsPolicyEnforced() != null && var10 != null) {
				var10.removeFromEnvironment("java.naming.security.principal");
				var10.removeFromEnvironment("java.naming.security.credentials");
				var10.addToEnvironment("java.naming.security.principal", var1);
				var10.addToEnvironment("java.naming.security.credentials", var2);
				if (var3 != null) {
					((LdapContext) var10).setRequestControls(var3);
				}

				try {
					String[] var45 = this.iLdapConfigMgr.getTopLdapNodes();
					trcLogger.log(Level.INFO, var45.toString());
					if (var45 != null && var45.length > 0) {
						var10.getAttributes(var45[0]);
					} else {
						var10.lookup("");
					}
				} catch (NamingException var41) {
					var4.setRootCause(var41);
				}

				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.exiting(CLASSNAME,
							"JNDI_CALL createDirContext(String, byte[], Control[], NamingException)",
							var10.getEnvironment().get("java.naming.provider.url"));
				}
			}

			var46 = var10;
		} finally {
			FactoryManager.getSSLUtil().setSSLPropertiesOnThread(var9);
		}

		return var46;
	}

	public DirContext reCreateDirContext(DirContext var1, String var2) throws WIMSystemException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "DirContext reCreateDirContext(String errorMessage)",
					"Communication exception occurs: " + var2 + " Creating a new connection.");
		}

		String var4 = DomainManagerUtils.getDomainName();

		try {
			Long var5 = ((TimedDirContext) var1).getCreateTimestamp();
			DirContext var6;
			if (var5 < this.iPoolCreateTimestamp) {
				var6 = this.getDirContext();
			} else {
				String var7 = this.getProviderURL(var1);
				var6 = this.createDirContext(this.getEnvironment(1, this.getNextURL(var7)));
				String var8 = this.getProviderURL(var6);
				boolean var9 = false;

				try {
					var9 = this.lockThreads.tryAcquire(0L, TimeUnit.SECONDS);
				} catch (InterruptedException var19) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.warning(CLASSNAME + " " + "DirContext reCreateDirContext(String errorMessage)"
								+ " Unable to obtain semaphore [" + var19.getMessage() + "]");
					}
				}

				if (!var9 && trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "DirContext reCreateDirContext(String errorMessage)",
							"**LDAPBind - failed to acquire semaphore");
				}

				trcLogger.logp(Level.CONFIG, CLASSNAME, "DirContext reCreateDirContext(String errorMessage)",
						"hasSemaphore = " + var9 + " && blockThread= "
								+ !this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock());
				if (!var9 && this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock()) {
					throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var2),
							Level.SEVERE, CLASSNAME, "DirContext reCreateDirContext(String errorMessage)");
				}

				trcLogger.logp(Level.CONFIG, CLASSNAME, "DirContext reCreateDirContext(String errorMessage)",
						"HERE TO ACQUIRE LOCK");

				try {
					Object var10 = lock;
					synchronized (lock) {
						if (((TimedDirContext) var1).getCreateTimestamp() >= this.iPoolCreateTimestamp) {
							this.createContextPool(this.iLiveContexts - 1, var8);
							((TimedDirContext) var6).setCreateTimestamp(this.iPoolCreateTimestamp);
						}
					}
				} finally {
					if (var9) {
						this.lockThreads.release();
						trcLogger.logp(Level.CONFIG, CLASSNAME, "DirContext reCreateDirContext(String errorMessage)",
								"Releasing Semaphore");
					}

				}
			}

			var1.close();
			msgLogger.logp(Level.INFO, CLASSNAME, "DirContext reCreateDirContext(String errorMessage)",
					"CURRENT_LDAP_SERVER", WIMMessageHelper.generateMsgParms(this.getActiveURL()));
			return var6;
		} catch (NamingException var20) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var20.toString(true)),
					Level.SEVERE, CLASSNAME, "DirContext reCreateDirContext(String errorMessage)");
		}
	}

	public DirContext createDirContext(Hashtable var1) throws NamingException {
		return this.createDirContext(var1, System.currentTimeMillis() / 1000L);
	}

	public DirContext createDirContext(Hashtable var1, long var2) throws NamingException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "JNDI_CALL createDirContext(Hashtable, long)",
					WIMMessageHelper.generateMsgParms(var1.get("java.naming.provider.url"),
							var1.get("java.naming.security.principal")));
		}

		Properties var5 = FactoryManager.getSSLUtil().getSSLPropertiesOnThread();

		TimedDirContext var12;
		try {
			if (this.iSSLAlias != null) {
				try {
					setWASSSLAlias(this.iSSLAlias, var1);
				} catch (Exception var18) {
					throw new NamingException(var18.getMessage());
				}
			}

			long var6 = System.currentTimeMillis();
			if (this.isKerberosBindAuth()) {
				try {
					Subject var8 = this.handleKerberos();
					var1.put("javax.security.sasl.credentials", SubjectHelper.getGSSCredentialFromSubject(var8));
				} catch (LoginException var19) {
					NamingException var23 = new NamingException(var19.getMessage());
					var23.setRootCause(var19);
					throw var23;
				} catch (MalformedURLException var20) {
					WIMSystemException var9 = new WIMSystemException("FILE_NOT_FOUND",
							WIMMessageHelper.generateMsgParms(
									this.krb5TicketCache != null ? this.krb5TicketCache : this.krb5Keytab),
							Level.SEVERE, CLASSNAME, "createDirContext(Hashtable, long)", var20);
					NamingException var10 = new NamingException(var9.getMessage());
					var10.setRootCause(var9);
					throw var10;
				}
			}

			TimedDirContext var22 = new TimedDirContext(var1, this.getConnectionRequsetControls(), var2,
					this.iLdapConfigMgr);
			long var24 = System.currentTimeMillis();
			if (var24 - var6 > (long) LDAP_CONNECT_TIMEOUT_TRACE) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "createDirContext(Hashtable, long)",
							"**LDAPConnect time: " + (var24 - var6) + " ms, lock held " + Thread.holdsLock(lock));
				}
			} else {
				this.handleBindStat(var24 - var6);
			}

			String var11 = this.getProviderURL(var22);
			if (!this.iEnableContextPool && !var11.equalsIgnoreCase(this.getActiveURL())) {
				this.setActiveURL(var11);
			}

			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.exiting(CLASSNAME, "JNDI_CALL createDirContext(Hashtable, long)",
						var22.getEnvironment().get("java.naming.provider.url"));
			}

			var12 = var22;
		} finally {
			FactoryManager.getSSLUtil().setSSLPropertiesOnThread(var5);
		}

		return var12;
	}

	private void checkWritePermission(DirContext var1) throws OperationNotSupportedException {
		if (!this.iWriteToSecondary) {
			String var2 = this.getProviderURL(var1);
			if (!this.getPrimaryURL().equalsIgnoreCase(var2)) {
				throw new OperationNotSupportedException("WRITE_TO_SECONDARY_SERVERS_NOT_ALLOWED",
						WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME, "checkWritePermission");
			}
		}

	}

	public Object lookup(String var1) throws NamingException, WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "Object lookup(String name)", WIMMessageHelper.generateMsgParms(var1));
		}

		DirContext var3 = this.getDirContext();
		Object var4 = null;

		try {
			var4 = var3.lookup(var1);
		} catch (CommunicationException var9) {
			var3 = this.reCreateDirContext(var3, var9.toString());
			var4 = var3.lookup(var1);
		} finally {
			this.releaseDirContext(var3);
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "Object lookup(String name)", WIMMessageHelper.generateMsgParms(var4));
		}

		return var4;
	}

	private static boolean isConnectionException(NamingException var0, String var1) {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, var1, "Exception caught:", var0);
		}

		return var0 instanceof CommunicationException || var0 instanceof ServiceUnavailableException;
	}

	public DirContext createSubcontext(String var1, Attributes var2) throws WIMException {
		DirContext var4 = null;
		DirContext var5 = this.getDirContext();
		this.checkWritePermission(var5);

		try {
			try {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.entering(CLASSNAME, "JNDI_CALL createSubcontext",
							WIMMessageHelper.generateMsgParms(var1, this.printAttributes(var2)));
				}

				long var6 = System.currentTimeMillis();
				var4 = var5.createSubcontext(new LdapName(var1), var2);
				long var8 = System.currentTimeMillis();
				if (var8 - var6 > (long) LDAP_CONNECT_TIMEOUT_TRACE) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createSubcontext", "**LDAPConnect time: " + (var8 - var6)
								+ " ms, lock held " + Thread.holdsLock(lock) + ", principal=" + var1);
					}
				} else {
					this.handleBindStat(var8 - var6);
				}

				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.exiting(CLASSNAME, "JNDI_CALL createSubcontext");
				}
			} catch (NamingException var17) {
				if (!isConnectionException(var17, "createSubcontext")) {
					throw var17;
				}

				var5 = this.reCreateDirContext(var5, var17.toString());
				long var7 = System.currentTimeMillis();
				var4 = var5.createSubcontext(new LdapName(var1), var2);
				long var9 = System.currentTimeMillis();
				if (var9 - var7 > (long) LDAP_CONNECT_TIMEOUT_TRACE) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "createSubcontext", "**LDAPConnect time: " + (var9 - var7)
								+ " ms, lock held " + Thread.holdsLock(lock) + ", principal=" + var1);
					}
				} else {
					this.handleBindStat(var9 - var7);
				}
			}
		} catch (NameAlreadyBoundException var18) {
			throw new EntityAlreadyExistsException("ENTITY_ALREADY_EXIST", WIMMessageHelper.generateMsgParms(var1),
					CLASSNAME, "createSubcontext");
		} catch (NameNotFoundException var19) {
			throw new EntityNotFoundException("PARENT_NOT_FOUND",
					WIMMessageHelper.generateMsgParms(var1, var19.toString(true)), CLASSNAME, "createSubcontext");
		} catch (NamingException var20) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var20.toString(true)),
					Level.SEVERE, CLASSNAME, "createSubcontext");
		} finally {
			this.releaseDirContext(var5);
		}

		return var4;
	}

	public void destroySubcontext(String var1) throws WIMException {
		DirContext var3 = this.getDirContext();
		this.checkWritePermission(var3);

		try {
			try {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.entering(CLASSNAME, "JNDI_CALL destroySubcontext",
							WIMMessageHelper.generateMsgParms(var1));
				}

				var3.destroySubcontext(new LdapName(var1));
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.exiting(CLASSNAME, "JNDI_CALL destroySubcontext");
				}
			} catch (NamingException var11) {
				if (!isConnectionException(var11, "destroySubcontext")) {
					throw var11;
				}

				var3 = this.reCreateDirContext(var3, var11.toString());
				var3.destroySubcontext(new LdapName(var1));
			}
		} catch (ContextNotEmptyException var12) {
			throw new EntityHasDescendantsException("ENTITY_HAS_DESCENDENTS", WIMMessageHelper.generateMsgParms(var1),
					Level.WARNING, CLASSNAME, "destroySubcontext");
		} catch (NameNotFoundException var13) {
			throw new EntityNotFoundException("LDAP_ENTRY_NOT_FOUND",
					WIMMessageHelper.generateMsgParms(var1, var13.toString(true)), CLASSNAME, "destroySubcontext");
		} catch (NamingException var14) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var14.toString(true)),
					Level.SEVERE, CLASSNAME, "destroySubcontext");
		} finally {
			this.releaseDirContext(var3);
		}

	}

	private int getTTLAttributeValue(Attributes var1) throws WIMSystemException {
		if (this.iServerTTLAttr != null && var1 != null) {
			Attribute var3 = var1.get(this.iServerTTLAttr);
			if (var3 != null) {
				try {
					return Integer.parseInt((String) var3.get());
				} catch (NumberFormatException var5) {
					return -1;
				} catch (NamingException var6) {
					throw new WIMSystemException("NAMING_EXCEPTION",
							WIMMessageHelper.generateMsgParms(var6.toString(true)), Level.SEVERE, CLASSNAME,
							"getTTLAttributeValue(Attributes");
				}
			} else {
				return -1;
			}
		} else {
			return -1;
		}
	}

	public Attributes getAttributes(String var1, String[] var2) throws WIMException {
		Object var4 = null;
		if (this.iLdapConfigMgr.getUseEncodingInSearchExpression() != null) {
			var1 = LdapHelper.encodeAttribute(var1, this.iLdapConfigMgr.getUseEncodingInSearchExpression());
		}

		if (this.iAttrRangeStep > 0) {
			var4 = this.getRangeAttributes(var1, var2);
		} else {
			DirContext var5 = this.getDirContext();

			try {
				try {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.entering(CLASSNAME, "JNDI_CALL getAttributes",
								WIMMessageHelper.generateMsgParms(var1, WIMTraceHelper.printObjectArray(var2)));
					}

					var4 = var5.getAttributes(new LdapName(var1), var2);
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.exiting(CLASSNAME, "JNDI_CALL getAttributes", var4.toString());
					}
				} catch (PartialResultException var13) {
					if (!this.iLdapConfigMgr.getvmmHandleReferal().contains("ignore")) {
						throw var13;
					}

					trcLogger.logp(Level.FINEST, CLASSNAME, "getAttributes", "Consuming PartialResultException");
					var4 = new BasicAttributes();
				} catch (NamingException var14) {
					if (!isConnectionException(var14, "getAttributes")) {
						throw var14;
					}

					var5 = this.reCreateDirContext(var5, var14.toString());
					var4 = var5.getAttributes(new LdapName(var1), var2);
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.exiting(CLASSNAME, "JNDI_CALL getAttributes", var4.toString());
					}
				}
			} catch (NameNotFoundException var15) {
				throw new EntityNotFoundException("LDAP_ENTRY_NOT_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var15.toString(true)), CLASSNAME, "getAttributes");
			} catch (NamingException var16) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var16.toString(true)), Level.SEVERE, CLASSNAME,
						"getAttributes");
			} finally {
				this.releaseDirContext(var5);
			}
		}

		return (Attributes) var4;
	}

	private Attributes getRangeAttributes(String var1, String[] var2) throws WIMException {
		Attributes var5 = null;
		DirContext var6 = this.getDirContext();

		try {
			try {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.entering(CLASSNAME, "JNDI_CALL getAttributes(String, String[])",
							WIMMessageHelper.generateMsgParms(var1, WIMTraceHelper.printObjectArray(var2)));
				}

				var5 = var6.getAttributes(new LdapName(var1), var2);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.exiting(CLASSNAME, "JNDI_CALL getAttributes(String, String[])", var5.toString());
				}
			} catch (NamingException var13) {
				if (!isConnectionException(var13, "getRangeAttributes")) {
					throw var13;
				}

				var6 = this.reCreateDirContext(var6, var13.toString());
				var5 = var6.getAttributes(new LdapName(var1), var2);
			}

			this.supportRangeAttributes(var5, var1, var6);
		} catch (NameNotFoundException var14) {
			throw new EntityNotFoundException("LDAP_ENTRY_NOT_FOUND",
					WIMMessageHelper.generateMsgParms(var1, var14.toString(true)), CLASSNAME, "getRangeAttributes");
		} catch (NamingException var15) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var15.toString(true)),
					Level.SEVERE, CLASSNAME, "getRangeAttributes");
		} finally {
			this.releaseDirContext(var6);
		}

		return var5;
	}

	private boolean cacheAttributes(String[] var1, Attributes var2) throws WIMException {
		if (this.iAttrsSizeLmit == 0) {
			return true;
		} else {
			NamingEnumeration var3 = var2.getAll();

			while (var3.hasMoreElements()) {
				Attribute var4 = (Attribute) var3.nextElement();
				if (var4 != null) {
					String var5 = var4.getID();
					int var6 = var4.size();
					if (var6 > this.iAttrsSizeLmit) {
						return false;
					}
				}
			}

			return true;
		}
	}

	private boolean cacheAttributes(Attributes var1) throws WIMException {
		if (this.iAttrsSizeLmit == 0) {
			return true;
		} else {
			NamingEnumeration var2 = var1.getAll();

			while (var2.hasMoreElements()) {
				Attribute var3 = (Attribute) var2.nextElement();
				if (var3 != null) {
					String var4 = var3.getID();
					int var5 = var3.size();
					if (var5 > this.iAttrsSizeLmit) {
						return false;
					}
				}
			}

			return true;
		}
	}

	private String[] getRetrieveAttributes(String var1, boolean var2) {
		String[] var3 = null;
		if (var1 != null) {
			var3 = (String[]) ((String[]) this.iEnityAttrIds.get(var1));
		} else {
			var3 = this.iAttrIds;
		}

		if (var2) {
			String[] var4 = this.iLdapConfigMgr.getMemberAttributes();
			String[] var5 = new String[var3.length + var4.length];
			System.arraycopy(var3, 0, var5, 0, var3.length);
			System.arraycopy(var4, 0, var5, var4.length, var4.length);
			return var5;
		} else {
			return var3;
		}
	}

	private void updateAttributesCache1(String var1, Attributes var2, Attributes var3) {
		if (var2.size() > 0) {
			boolean var5 = false;
			if (var3 == null) {
				var5 = true;
				var3 = new BasicAttributes(true);
			}

			NamingEnumeration var6 = var2.getAll();

			while (true) {
				Attribute var7;
				do {
					if (!var6.hasMoreElements()) {
						if (var5) {
							this.getAttributesCache().put(var1, var3, 1, this.iAttrsCacheTimeOut,
									this.iAttrsCacheDistPolicy, (Object[]) null);
						}

						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "updateAttributeCache(key,missAttrs,cachedAttrs)",
									"Update " + this.iAttrsCacheName + "(size: " + this.getAttributesCache().size()
											+ " newEntry " + var5 + ")\n" + var1 + ": " + var3);
						}

						return;
					}

					var7 = (Attribute) var6.nextElement();
				} while (this.iAttrsSizeLmit > 0 && var7.size() > this.iAttrsSizeLmit);

				((Attributes) var3).put(var7);
			}
		}
	}

	private void updateAttributesCache(String var1, Attributes var2, Attributes var3, String[] var4) {
		if (var4 != null) {
			if (var4.length > 0) {
				boolean var6 = false;
				if (var3 == null) {
					var6 = true;
					var3 = new BasicAttributes(true);
				}

				for (int var7 = 0; var7 < var4.length; ++var7) {
					boolean var8 = false;
					NamingEnumeration var9 = var2.getAll();

					while (var9.hasMoreElements()) {
						Attribute var10 = (Attribute) var9.nextElement();
						if (var10.getID().equalsIgnoreCase(var4[var7])) {
							var8 = true;
							if (this.iAttrsSizeLmit <= 0 || var10.size() <= this.iAttrsSizeLmit) {
								((Attributes) var3).put(var10);
							}
							break;
						}

						int var11 = var10.getID().indexOf(";");
						if (var11 > 0 && var4[var7].equalsIgnoreCase(var10.getID().substring(0, var11))) {
							var8 = true;
							if (this.iAttrsSizeLmit <= 0 || var10.size() <= this.iAttrsSizeLmit) {
								((Attributes) var3).put(var10);
							}
							break;
						}
					}

					if (!var8) {
						BasicAttribute var12 = new BasicAttribute(var4[var7], (Object) null);
						((Attributes) var3).put(var12);
					}
				}

				if (var6) {
					this.getAttributesCache().put(var1, var3, 1, this.iAttrsCacheTimeOut, this.iAttrsCacheDistPolicy,
							(Object[]) null);
				}

				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "updateAttributeCache",
							"Update " + this.iAttrsCacheName + "(size: " + this.getAttributesCache().size()
									+ " newEntry " + var6 + ")\n" + var1 + ": " + var3);
				}
			}
		} else {
			this.updateAttributesCache1(var1, var2, (Attributes) var3);
		}

	}

	private void updateAttributesCache(String var1, String var2, Attributes var3, String[] var4) {
		this.getAttributesCache().put(var1, var2, 1, this.iAttrsCacheTimeOut, this.iAttrsCacheDistPolicy,
				(Object[]) null);
		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "updateAttributesCache(key,dn,newAttrs)", "Update "
					+ this.iAttrsCacheName + "(size: " + this.getAttributesCache().size() + ")\n" + var1 + ": " + var2);
		}

		String var6 = toKey(var2);
		Object var7 = this.getAttributesCache().get(var6);
		Attributes var8 = null;
		if (var7 != null && var7 instanceof Attributes) {
			var8 = (Attributes) var7;
		}

		this.updateAttributesCache(var6, var3, var8, var4);
	}

	private void addAttributes(Attributes var1, Attributes var2) {
		NamingEnumeration var3 = var1.getAll();

		while (var3.hasMoreElements()) {
			var2.put((Attribute) var3.nextElement());
		}

	}

	public Attributes checkAttributesCache(String var1, String[] var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "checkAttributesCache",
					WIMMessageHelper.generateMsgParms(var1, WIMTraceHelper.printObjectArray(var2)));
		}

		Object var4 = null;
		if (this.getAttributesCache() != null) {
			String var5 = toKey(var1);
			Object var6 = this.getAttributesCache().get(var5);
			if (var6 != null && var6 instanceof Attributes) {
				ArrayList var7 = new ArrayList(var2.length);
				Attributes var8 = (Attributes) var6;
				var4 = new BasicAttributes(true);

				for (int var9 = 0; var9 < var2.length; ++var9) {
					Attribute var10 = LdapHelper.getIngoreCaseAttribute(var8, var2[var9]);
					if (var10 != null) {
						((Attributes) var4).put(var10);
					} else {
						var7.add(var2[var9]);
					}
				}

				if (var7.size() > 0) {
					String[] var12 = (String[]) ((String[]) var7.toArray(new String[0]));
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "checkAttributesCache",
								"Miss cache: " + var5 + " " + WIMTraceHelper.printObjectArray(var12));
					}

					Attributes var11 = this.getAttributes(var1, var12);
					this.addAttributes(var11, (Attributes) var4);
					this.updateAttributesCache(var5, var11, var8, var12);
				} else if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "checkAttributesCache", "Hit cache: " + var5);
				}
			} else {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "checkAttributesCache", "Miss cache: " + var5);
				}

				var4 = this.getAttributes(var1, var2);
				this.updateAttributesCache(var5, (Attributes) var4, (Attributes) null, var2);
			}
		} else {
			var4 = this.getAttributes(var1, var2);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "checkAttributesCache", var4.toString());
		}

		return (Attributes) var4;
	}

	public Name getCompoundName(String var1) throws WIMException {
		try {
			return this.getNameParser().parse(var1);
		} catch (NamingException var4) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var4.toString(true)),
					Level.SEVERE, CLASSNAME, "getCompoundName(String)");
		}
	}

	public Control[] getConnectionRequsetControls() {
		return this.iConnCtls;
	}

	public long getCountLimit() {
		return (long) this.iCountLimit;
	}

	public void releaseDirContext(DirContext var1) throws WIMException {
		if (this.iEnableContextPool) {
			Object var3 = lock;
			synchronized (lock) {
				if (this.iContexts.size() < this.iPrefPoolSize
						&& (this.iMaxPoolSize == 0 || this.iLiveContexts <= this.iMaxPoolSize)
						&& ((TimedDirContext) var1).getCreateTimestamp() >= this.iPoolCreateTimestamp
						&& this.getProviderURL(var1).equalsIgnoreCase(this.getActiveURL())) {
					if (this.iContexts != null && this.iContexts.size() > 0 && this.iContexts.contains(var1)) {
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "releaseDirContext",
									"Context already present in Context pool. No need to add it again to context pool.  ContextPool: total="
											+ this.iLiveContexts + ", poolSize=" + this.iContexts.size());
						}
					} else {
						this.iContexts.add(var1);
						if (this.iPoolTimeOut > 0) {
							((TimedDirContext) var1).setPoolTimeStamp(System.currentTimeMillis() / 1000L);
						}

						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "releaseDirContext",
									"Before Notifying the waiting threads and Context is back to pool.  ContextPool: total="
											+ this.iLiveContexts + ", poolSize=" + this.iContexts.size());
						}
					}

					lock.notifyAll();
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "releaseDirContext", "Context is back to pool.");
					}
				} else {
					try {
						--this.iLiveContexts;
						var1.close();
					} catch (NamingException var7) {
						throw new WIMSystemException("NAMING_EXCEPTION",
								WIMMessageHelper.generateMsgParms(var7.toString(true)), Level.SEVERE, CLASSNAME,
								"releaseDirContext");
					}

					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "releaseDirContext", "Context is discarded.");
					}
				}
			}

			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "releaseDirContext",
						"ContextPool: total=" + this.iLiveContexts + ", poolSize=" + this.iContexts.size());
			}
		} else {
			try {
				var1.close();
			} catch (NamingException var6) {
				throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.toString(true)),
						Level.SEVERE, CLASSNAME, "releaseDirContext");
			}
		}

	}

	private Hashtable getEnvironment(int var1, String var2) {
		Hashtable var3 = new Hashtable(this.iEnvironment);
		List var4 = (List) var3.remove("_URL_LIST_");
		int var5 = var4.size();
		int var6 = this.getURLIndex(var2, var4);
		String var7 = null;

		for (int var8 = var6; var8 < var6 + var5; ++var8) {
			if (var8 > var6) {
				var7 = var7 + " " + (String) var4.get(var8 % var5);
			} else {
				var7 = (String) var4.get(var8 % var5);
			}

			if (var1 == 0) {
				break;
			}
		}

		var3.put("java.naming.provider.url", var7);
		var3.remove("_ACTIVE_URL_");
		return var3;
	}

	private int getURLIndex(String var1, List var2) {
		int var3 = 0;
		int var4 = var2.size();
		if (var1 != null) {
			for (int var5 = 0; var5 < var4; ++var5) {
				if (((String) var2.get(var5)).equalsIgnoreCase(var1)) {
					var3 = var5;
					break;
				}
			}
		}

		return var3;
	}

	private String getNextURL(String var1) {
		List var2 = this.getEnvURLList();
		int var3 = this.getURLIndex(var1, var2);
		return (String) var2.get((var3 + 1) % var2.size());
	}

	private List getEnvURLList() {
		return (List) this.iEnvironment.get("_URL_LIST_");
	}

	private String getPrimaryURL() {
		return (String) this.getEnvURLList().get(0);
	}

	private String getActiveURL() {
		return (String) this.iEnvironment.get("_ACTIVE_URL_");
	}

	private void setActiveURL(String var1) {
		Object var2 = lock;
		synchronized (lock) {
			this.iEnvironment.put("_ACTIVE_URL_", var1);
		}
	}

	private String getProviderURL(DirContext var1) {
		try {
			return this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers() != null
					? this.getPrimaryURL()
					: (String) var1.getEnvironment().get("java.naming.provider.url");
		} catch (NamingException var3) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "getProviderURL", var3.toString(true));
			}

			return "(null)";
		}
	}

	public DirContext getDirContext() throws WIMSystemException {
		DirContext var2 = null;
		long var3 = System.currentTimeMillis() / 1000L;
		if (!this.iEnableContextPool) {
			try {
				if (this.iReturnToPrimary && var3 - this.iLastQueryTime > this.iQueryInterval) {
					String var63 = this.getPrimaryURL();
					if (!var63.equalsIgnoreCase(this.getActiveURL())) {
						Hashtable var65 = this.getEnvironment(0, var63);

						try {
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINER, CLASSNAME, "getDirContext",
										"Ping primary server '" + var63 + "'...");
							}

							var2 = this.createDirContext(var65);
							if (trcLogger.isLoggable(Level.FINER)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "getDirContext",
										"Ping primary server '" + var63 + "': success");
							}

							msgLogger.logp(Level.INFO, CLASSNAME, "getDirContext", "CURRENT_LDAP_SERVER",
									WIMMessageHelper.generateMsgParms(this.getActiveURL()));
						} catch (NamingException var55) {
							msgLogger.logp(Level.INFO, CLASSNAME, "getDirContext", "CAN_NOT_CONNECT_LDAP_SERVER",
									WIMMessageHelper.generateMsgParms(var63));
							if (trcLogger.isLoggable(Level.FINE)) {
								trcLogger.logp(Level.FINE, CLASSNAME, "getDirContext",
										"Ping primary server '" + var63 + "': fail");
							}
						}
					}

					this.iLastQueryTime = var3;
				}

				if (var2 == null) {
					var2 = this.createDirContext(this.getEnvironment(1, this.getActiveURL()));
					msgLogger.logp(Level.INFO, CLASSNAME, "getDirContext", "CURRENT_LDAP_SERVER",
							WIMMessageHelper.generateMsgParms(var2.getEnvironment().get("java.naming.provider.url")));
				}
			} catch (NamingException var56) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var56.toString(true)), Level.SEVERE, CLASSNAME,
						"getDirContext");
			}
		} else {
			while (true) {
				boolean var5 = false;
				if (this.iContexts == null) {
					var5 = true;
				}

				boolean var6 = true;
				boolean var7 = false;
				trcLogger.logp(Level.CONFIG, CLASSNAME, "getDirContext", "needSemaphore = " + var5);
				if (var5) {
					var6 = false;

					try {
						var6 = this.lockThreads.tryAcquire(0L, TimeUnit.SECONDS);
					} catch (InterruptedException var62) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.warning(CLASSNAME + " " + "getDirContext" + " Unable to obtain semaphore ["
									+ var62.getMessage() + "]");
						}
					}

					if (!var6 && trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "getDirContext",
								"**LDAPBind - failed to acquire semaphore");
					}
				}

				label862 : {
					trcLogger.logp(Level.CONFIG, CLASSNAME, "getDirContext", "hasSemaphore = " + var6
							+ " && blockThread= " + !this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock());
					if (var6 || !this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock()) {
						trcLogger.logp(Level.CONFIG, CLASSNAME, "getDirContext", "HERE TO ACQUIRE LOCK");

						try {
							Object var8 = lock;
							synchronized (lock) {
								if (this.iContexts == null) {
									try {
										this.createContextPool(this.iInitPoolSize, (String) null);
									} catch (NamingException var52) {
										throw new WIMSystemException("NAMING_EXCEPTION",
												WIMMessageHelper.generateMsgParms(var52.toString(true)), Level.SEVERE,
												CLASSNAME, "getDirContext");
									}
								}

								if (this.iContexts.size() > 0) {
									var2 = (DirContext) this.iContexts.remove(this.iContexts.size() - 1);
								} else {
									if (this.iLiveContexts >= this.iMaxPoolSize && this.iMaxPoolSize != 0) {
										try {
											lock.wait((long) this.iPoolWaitTime);
										} catch (Exception var51) {
											;
										}
										break label862;
									}

									++this.iLiveContexts;
									var7 = true;
								}
							}
						} finally {
							if (var5 && var6) {
								this.lockThreads.release();
								trcLogger.logp(Level.CONFIG, CLASSNAME, "getDirContext", "Releasing Semaphore");
							}

						}
					}

					DirContext var64 = null;
					if (var2 != null) {
						if (this.iPoolTimeOut > 0
								&& var3 - ((TimedDirContext) var2).getPoolTimestamp() > (long) this.iPoolTimeOut) {
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "getDirContext",
										"ContextPool: context is time out.");
							}

							var64 = var2;
							var2 = null;
						}
					} else if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "getDirContext",
								"ContextPool: no free context, create a new one...");
					}

					if (var2 == null) {
						try {
							var2 = this.createDirContext(this.getEnvironment(1, this.getActiveURL()));
						} catch (NamingException var53) {
							if (var7) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "getDirContext",
										"Communication exception : decreasing iLiveContexts ");
								--this.iLiveContexts;
							} else {
								trcLogger.logp(Level.FINEST, CLASSNAME, "getDirContext",
										"Communication exception : not decreasing iLiveContexts ");
							}

							throw new WIMSystemException("NAMING_EXCEPTION",
									WIMMessageHelper.generateMsgParms(var53.toString(true)), Level.SEVERE, CLASSNAME,
									"getDirContext");
						}
					} else if (this.iReturnToPrimary && var3 - this.iLastQueryTime > this.iQueryInterval) {
						try {
							String var9 = this.getProviderURL(var2);
							String var10 = this.getPrimaryURL();
							if (!var10.equalsIgnoreCase(var9)) {
								Hashtable var11 = this.getEnvironment(0, var10);
								boolean var12 = false;

								try {
									if (trcLogger.isLoggable(Level.FINER)) {
										trcLogger.logp(Level.FINER, CLASSNAME, "getDirContext",
												"Ping primary server '" + var10 + "'...");
									}

									DirContext var13 = this.createDirContext(var11);
									if (trcLogger.isLoggable(Level.FINER)) {
										trcLogger.logp(Level.FINE, CLASSNAME, "getDirContext",
												"Ping primary server '" + var10 + "': success");
									}

									msgLogger.logp(Level.INFO, CLASSNAME, "getDirContext", "CURRENT_LDAP_SERVER",
											WIMMessageHelper.generateMsgParms(var10));
									var12 = true;
									DirContext var14 = var2;

									try {
										var14.close();
									} catch (NamingException var50) {
										trcLogger.logp(Level.FINE, CLASSNAME, "getDirContext",
												"Can not close LDAP connection: " + var50.toString(true));
									}

									var2 = var13;
								} catch (NamingException var58) {
									if (trcLogger.isLoggable(Level.FINE)) {
										trcLogger.logp(Level.FINE, CLASSNAME, "getDirContext",
												"Ping primary server '" + var10 + "': fail");
									}

									msgLogger.logp(Level.INFO, CLASSNAME, "getDirContext",
											"CAN_NOT_CONNECT_LDAP_SERVER", WIMMessageHelper.generateMsgParms(var10));
								}

								var6 = false;

								try {
									var6 = this.lockThreads.tryAcquire(0L, TimeUnit.SECONDS);
								} catch (InterruptedException var57) {
									if (trcLogger.isLoggable(Level.FINE)) {
										trcLogger.warning(CLASSNAME + " " + "getDirContext"
												+ " Unable to obtain semaphore [" + var57.getMessage() + "]");
									}
								}

								if (!var6 && trcLogger.isLoggable(Level.FINE)) {
									trcLogger.logp(Level.FINE, CLASSNAME, "getDirContext",
											"**LDAPBind - failed to acquire semaphore");
								}

								trcLogger.logp(Level.CONFIG, CLASSNAME, "getDirContext",
										"hasSemaphore = " + var6 + " && blockThread= "
												+ !this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock());
								if (var6 || !this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock()) {
									trcLogger.logp(Level.CONFIG, CLASSNAME, "getDirContext", "HERE TO ACQUIRE LOCK");

									try {
										if (var12) {
											Object var66 = lock;
											synchronized (lock) {
												if (!this.getActiveURL().equalsIgnoreCase(var10)) {
													this.createContextPool(this.iLiveContexts - 1, var10);
													((TimedDirContext) var2)
															.setCreateTimestamp(this.iPoolCreateTimestamp);
												}
											}
										}
									} finally {
										if (var6) {
											this.lockThreads.release();
											trcLogger.logp(Level.CONFIG, CLASSNAME, "getDirContext",
													"Releasing Semaphore");
										}

									}
								}
							}

							this.iLastQueryTime = var3;
						} catch (NamingException var59) {
							throw new WIMSystemException("NAMING_EXCEPTION",
									WIMMessageHelper.generateMsgParms(var59.toString(true)), Level.SEVERE, CLASSNAME,
									"getDirContext");
						}
					}

					if (var64 != null) {
						try {
							var64.close();
						} catch (NamingException var48) {
							trcLogger.logp(Level.FINE, CLASSNAME, "getDirContext",
									"Can not close LDAP connection: " + var48.toString(true));
						}
					}
				}

				if (var2 != null) {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.logp(Level.FINEST, CLASSNAME, "getDirContext",
								"ContextPool: total=" + this.iLiveContexts + ", poolSize=" + this.iContexts.size());
					}
					break;
				}
			}
		}

		return var2;
	}

	public NameParser getNameParser() throws WIMException {
		if (this.iNameParser == null) {
			DirContext var2 = this.getDirContext();

			try {
				try {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.entering(CLASSNAME, "JNDI_CALL getNameParser()",
								WIMMessageHelper.generateMsgParms(""));
					}

					this.iNameParser = var2.getNameParser("");
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.exiting(CLASSNAME, "JNDI_CALL getNameParser()");
					}
				} catch (NamingException var8) {
					if (!isConnectionException(var8, "getNameParser()")) {
						throw var8;
					}

					var2 = this.reCreateDirContext(var2, var8.toString());
					this.iNameParser = var2.getNameParser("");
				}
			} catch (NamingException var9) {
				throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var9.toString(true)),
						Level.SEVERE, CLASSNAME, "getNameParser()");
			} finally {
				this.releaseDirContext(var2);
			}
		}

		return this.iNameParser;
	}

	public void initialize(DataObject var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize(DataObject)");
		}

		this.iReposId = var1.getString("id");
		this.initializeServers(var1.getDataObject("ldapServerConfiguration"));
		this.initializeContextPool(var1.getDataObject("contextPool"));
		String var3 = DomainManagerUtils.getDomainId();
		if (var3 != null && !"admin".equalsIgnoreCase(var3)) {
			this.iAttrsCacheName = var3 + "/" + this.iReposId + "/" + this.iAttrsCacheName;
			this.iSearchResultsCacheName = var3 + "/" + this.iReposId + "/" + this.iSearchResultsCacheName;
		} else {
			this.iAttrsCacheName = this.iReposId + "/" + this.iAttrsCacheName;
			this.iSearchResultsCacheName = this.iReposId + "/" + this.iSearchResultsCacheName;
		}

		try {
			this.createContextPool(this.iInitPoolSize, (String) null);
		} catch (NamingException var5) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "initialize(DataObject)",
						"Can not create context pool: " + var5.toString(true));
			}
		}

		this.initializeCaches(var1.getDataObject("cacheConfiguration"));
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize(DataObject)");
		}

	}

	private void initializeServers(DataObject var1) throws WIMException {
		this.iTimeLimit = var1.getInt("searchTimeLimit");
		this.iCountLimit = var1.getInt("searchCountLimit");
		if (var1.isSet("searchPageSize")) {
			this.iPageSize = var1.getInt("searchPageSize");
		} else if (this.iLdapConfigMgr.getLdapType().startsWith("AD")
				|| this.iLdapConfigMgr.getLdapType().equals("ADAM")) {
			this.iPageSize = 1000;
		}

		if (var1.isSet("attributeRangeStep")) {
			this.iAttrRangeStep = var1.getInt("attributeRangeStep");
		} else if (!this.iLdapConfigMgr.getLdapType().equals("AD2000")
				&& !this.iLdapConfigMgr.getLdapType().equals("ADAM")) {
			if (this.iLdapConfigMgr.getLdapType().startsWith("AD2003")) {
				this.iAttrRangeStep = 1500;
			}
		} else {
			this.iAttrRangeStep = 1000;
		}

		this.iWriteToSecondary = var1.getBoolean("allowWriteToSecondaryServers");
		this.iReturnToPrimary = var1.getBoolean("returnToPrimaryServer");
		this.iQueryInterval = (long) (var1.getInt("primaryServerQueryTimeInterval") * 60);
		this.initializeSSL(var1);
		List var2 = var1.getList("ldapServers");
		DataObject var3 = (DataObject) var2.get(0);
		this.iEnvironment = this.initializeEnvironmentProperties(var3);
	}

	private Hashtable initializeEnvironmentProperties(DataObject var1)
			throws MissingInitPropertyException, WIMSystemException {
		Hashtable var3 = new Hashtable();
		var3.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
		List var4 = var1.getList("connections");
		boolean var5 = var1.getBoolean("sslEnabled");
		String var6 = null;
		if (var5) {
			if (this.iSSLFactory != null) {
				var3.put("java.naming.ldap.factory.socket", this.iSSLFactory);
			}

			var3.put("java.naming.security.protocol", "ssl");
			if (this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers() != null) {
				var6 = "ldaps:///";
			} else {
				var6 = "ldaps://";
			}
		} else if (this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers() != null) {
			var6 = "ldap:///";
		} else {
			var6 = "ldap://";
		}

		Vector var7 = new Vector();
		String var10;
		if (this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers() != null) {
			var7.add(var6 + this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers());
		} else {
			for (int var8 = 0; var8 < var4.size(); ++var8) {
				DataObject var9 = (DataObject) var4.get(var8);
				var10 = var9.getString("host");
				if ((!var10.startsWith("[") || !var10.endsWith("]")) && ConfigUtils.isIPv6Addr(var10)) {
					var10 = ConfigUtils.formatIPv6Addr(var10);
					var9.setString("host", var10);
				}

				int var11 = var9.getInt("port");
				var7.add(var6 + var10.trim() + ":" + var11);
			}
		}

		String var21 = (String) var7.get(0);
		var3.put("_URL_LIST_", var7);
		var3.put("_ACTIVE_URL_", var21);
		var3.put("java.naming.provider.url", var21);
		String var22 = var1.getString("bindDN");
		this.authentication = var1.getString("authentication");
		if (var1.getString("bindAuthMechanism") != null && !var1.getString("bindAuthMechanism").trim().isEmpty()) {
			this.bindAuthMechanism = var1.getString("bindAuthMechanism");
		}

		if (this.bindAuthMechanism != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initializeEnvironmentProperties",
						"Using bindAuthMechanism for admin bind: " + this.bindAuthMechanism);
			}

			var3.put("java.naming.security.authentication", this.bindAuthMechanism);
		} else if (this.authentication != null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initializeEnvironmentProperties",
						"Using authentication for admin bind: " + this.authentication);
			}

			var3.put("java.naming.security.authentication", this.authentication);
		} else {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initializeEnvironmentProperties",
						"Missing authentication and bindAutheMechanism, defaulting to simple for admin bind.");
			}

			var3.put("java.naming.security.authentication", "simple");
		}

		var10 = null;
		String var23;
		if (this.isKerberosBindAuth()) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "initializeEnvironmentProperties",
						"Processing krb5Principal and related krb5 config.");
			}

			DataObject var24 = var1.getDataObject("krb5Authentication");
			if (var24 != null) {
				this.krb5Principal = var24.getString("krb5Principal");
				this.krb5TicketCache = var24.getString("krb5TicketCache");
				if (this.krb5Principal == null || this.krb5Principal.trim().isEmpty()) {
					this.krb5Principal = null;
				}

				if (this.krb5TicketCache == null || this.krb5TicketCache.trim().isEmpty()) {
					this.krb5TicketCache = null;
				}

				if (this.krb5TicketCache != null && !this.krb5TicketCache.trim().isEmpty()) {
					var10 = ConfigUtils.expandString(this.krb5TicketCache);
					File var12 = new File(var10);
					if (!var12.exists()) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME, "initializeEnvironmentProperties",
									"Ticketcache does not exist (" + this.krb5TicketCache + "), expanded: " + var10);
						}

						throw new MissingInitPropertyException("FILE_NOT_FOUND",
								WIMMessageHelper.generateMsgParms(var10), Level.SEVERE, CLASSNAME,
								"initializeEnvironmentProperties");
					}

					if (!var12.canRead()) {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.logp(Level.FINE, CLASSNAME, "initializeEnvironmentProperties",
									"Ticketcache cannot be read (" + this.krb5TicketCache + "), expanded: " + var10);
						}

						throw new MissingInitPropertyException("CANNOT_READ_KRB5_FILE",
								WIMMessageHelper.generateMsgParms(this.getRepositoryId(), var10), Level.SEVERE,
								CLASSNAME, "initializeEnvironmentProperties");
					}
				}

				try {
					if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.finest(
								"initializeEnvironmentProperties: Checking for keytab and config file in security config");
					}

					GlobalKrb5Config var25 = com.ibm.ws.wim.config.ConfigUtils
							.getSecurityKrb5Config(this.getRepositoryId(), (Session) null, (ConfigService) null);
					if (var25 != null) {
						if (var25.keytab != null) {
							this.krb5Keytab = var25.keytab;
						}

						if (var25.config != null) {
							this.krb5Config = var25.config;
						}
					} else if (trcLogger.isLoggable(Level.FINEST)) {
						trcLogger.finest("initializeEnvironmentProperties: krb5ConfigFromSec was null");
					}
				} catch (WIMConfigurationException var20) {
					throw new MissingInitPropertyException(var20.getMessage(), var20);
				}

				if (this.krb5TicketCache != null && this.krb5Keytab != null) {
					msgLogger.log(Level.INFO, "KRB5_TICKETCACHE_USED", WIMMessageHelper.generateMsgParms(
							this.getRepositoryId(), var10, ConfigUtils.expandString(this.krb5Keytab)));
				}
			}
		} else {
			if (trcLogger.isLoggable(Level.CONFIG)) {
				trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeEnvironmentProperties",
						"Processing bindDN and bindPassword.");
			}

			if (var22 != null && var22.length() > 0) {
				var3.put("java.naming.security.principal", var22);
				var23 = var1.getString("bindPassword");
				if (var23 == null || var23.length() == 0) {
					throw new MissingInitPropertyException("MISSING_INI_PROPERTY",
							WIMMessageHelper.generateMsgParms("bindPassword"), CLASSNAME,
							"initializeEnvironmentProperties");
				}

				var23 = FactoryManager.getEncryptionUtil().decode(var23);
				var3.put("java.naming.security.credentials", PasswordUtil.getByteArrayPassword(var23));
			}
		}

		var23 = var1.getString("referal");
		var3.put("java.naming.referral", var23);
		String var26 = var1.getString("derefAliases");
		if (!"always".equalsIgnoreCase(var26)) {
			var3.put("java.naming.ldap.derefAliases", var26);
		}

		boolean var13 = var1.getBoolean("connectionPool");
		var3.put("com.sun.jndi.ldap.connect.pool", Boolean.toString(var13));
		if (var1.isSet("connectTimeout")) {
			int var14 = var1.getInt("connectTimeout");
			if (var14 > 0) {
				var3.put("com.sun.jndi.ldap.connect.timeout", Integer.toString(var14 * 1000));
				var3.put("com.sun.jndi.ldap.read.timeout", Integer.toString(var14 * 1000));
			}
		}

		String var27 = this.getBinaryAttributes();
		if (var27 != null && var27.length() > 0) {
			var3.put("java.naming.ldap.attributes.binary", var27);
		}

		List var15 = var1.getList("environmentProperties");

		for (int var16 = 0; var16 < var15.size(); ++var16) {
			DataObject var17 = (DataObject) var15.get(var16);
			String var18 = var17.getString("name");
			String var19 = var17.getString("value");
			var3.put(var18, var19);
		}

		if (trcLogger.isLoggable(Level.CONFIG)) {
			StringBuffer var28 = new StringBuffer();
			var28.append("\nLDAP Server(s): ").append(var7).append("\n");
			var28.append("\tBindAuthMechanism: ").append(this.bindAuthMechanism).append("\n");
			if (this.isKerberosBindAuth()) {
				var28.append("\tKrb5Principal: ").append(this.krb5Principal).append("\n");
				var28.append("\tKrb5TicketCache: ").append(this.krb5TicketCache).append("\n");
				var28.append("\tKrb5Config: ").append(this.krb5Config).append("\n");
				var28.append("\tKrb5Keytab: ").append(this.krb5Keytab).append("\n");
				var28.append("\tKrb5TicketCache expanded (if needed): ").append(var10).append("\n");
				var28.append("\tKrb5Config expanded (if needed): ").append(ConfigUtils.expandString(this.krb5Config))
						.append("\n");
				var28.append("\tKrb5Keytab expanded (if needed): ").append(ConfigUtils.expandString(this.krb5Keytab))
						.append("\n");
			} else if (!"none".equals(this.bindAuthMechanism)) {
				var28.append("\tBind DN: ").append(var22).append("\n");
			}

			var28.append("\tAuthenticate: ").append(this.authentication).append("\n");
			var28.append("\tReferal: ").append(var23).append("\n");
			var28.append("\tEnable Connection Pool: ").append(var13).append("\n");
			var28.append("\tBinary Attributes: ").append(var27).append("\n");
			var28.append("\tAdditional Evn Props: ").append(var15);
			trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeEnvironmentProperties", var28.toString());
		}

		return var3;
	}

	public String getSSLFactory() {
		return this.iSSLFactory;
	}

	private void initializeWIMSSL(DataObject var1) {
		String var3 = var1.getString("sslKeyStore");
		String var4 = var1.getString("sslTrustStore");
		if (var3 == null && var4 == null) {
			if (trcLogger.isLoggable(Level.CONFIG)) {
				trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeWIMSSL(DataObject)", "Use default SSL settings.");
			}

		} else {
			if (trcLogger.isLoggable(Level.CONFIG)) {
				trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeWIMSSL(DataObject)", "Use SSL system properties.");
			}

			IEncryptionUtil var5 = FactoryManager.getEncryptionUtil();
			String var6;
			String var7;
			if (var3 != null) {
				System.setProperty("javax.net.ssl.keyStore", var3);
				var6 = var1.getString("sslKeyStoreType");
				if (var6 != null) {
					System.setProperty("javax.net.ssl.keyStoreType", var6);
				}

				var7 = var1.getString("sslKeyStorePassword");
				if (var7 != null) {
					var7 = var5.decode(var7);
					System.setProperty("javax.net.ssl.keyStorePassword", var7);
				}

				if (trcLogger.isLoggable(Level.CONFIG)) {
					trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeWIMSSL(DataObject)",
							"javax.net.ssl.keyStore=" + var3);
				}
			}

			if (var4 != null) {
				System.setProperty("javax.net.ssl.trustStore", var4);
				var6 = var1.getString("sslTrustStoreType");
				if (var6 != null) {
					System.setProperty("javax.net.ssl.trustStoreType", var6);
				}

				var7 = var1.getString("sslTrustStorePassword");
				if (var7 != null) {
					var7 = var5.decode(var7);
					System.setProperty("javax.net.ssl.trustStorePassword", var7);
				}

				if (trcLogger.isLoggable(Level.CONFIG)) {
					trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeWIMSSL(DataObject)",
							"javax.net.ssl.trustStore=" + var4);
				}
			}

		}
	}

	private void initializeSSL(DataObject var1) throws WIMConfigurationException {
		String var3 = var1.getString("sslConfiguration");
		if (var3 != null) {
			if (trcLogger.isLoggable(Level.CONFIG)) {
				trcLogger.logp(Level.CONFIG, CLASSNAME, "initializeSSL(DataObject)", "Use WAS SSL Configuration.");
			}

			this.iSSLAlias = var3;
			this.iSSLFactory = "com.ibm.websphere.ssl.protocol.SSLSocketFactory";
		} else {
			this.initializeWIMSSL(var1);
		}

	}

	private String getBinaryAttributes() {
		StringBuffer var1 = new StringBuffer(10);
		Map var2 = this.iLdapConfigMgr.getAttributes();
		Iterator var3 = var2.keySet().iterator();

		while (var3.hasNext()) {
			String var4 = (String) var3.next();
			LdapAttribute var5 = (LdapAttribute) var2.get(var4);
			if ("octetString".equalsIgnoreCase(var5.getSyntax())) {
				var1.append(var5.getName()).append(" ");
			}
		}

		return var1.toString().trim();
	}

	public void modifyAttributes(String var1, ModificationItem[] var2) throws NamingException, WIMException {
		DirContext var4 = this.getDirContext();
		this.checkWritePermission(var4);

		try {
			try {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.entering(CLASSNAME, "JNDI_CALL modifyAttributes(Name name, ModificationItem[] mods)",
							WIMMessageHelper.generateMsgParms(var1, this.printModificationItem(var2)));
				}

				var4.modifyAttributes(new LdapName(var1), var2);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.exiting(CLASSNAME, "JNDI_CALL modifyAttributes(Name name, ModificationItem[] mods)");
				}
			} catch (NamingException var11) {
				if (!isConnectionException(var11, "modifyAttributes(Name name, ModificationItem[] mods)")) {
					throw var11;
				}

				var4 = this.reCreateDirContext(var4, var11.toString());
				var4.modifyAttributes(new LdapName(var1), var2);
			}
		} catch (NameNotFoundException var12) {
			throw new EntityNotFoundException("NAMING_EXCEPTION",
					WIMMessageHelper.generateMsgParms(var12.toString(true)), CLASSNAME,
					"modifyAttributes(Name name, ModificationItem[] mods)");
		} catch (NamingException var13) {
			trcLogger.logp(Level.SEVERE, CLASSNAME, "modifyAttributes(Name name, ModificationItem[] mods)",
					var13.toString(true));
			throw var13;
		} finally {
			this.releaseDirContext(var4);
		}

	}

	public void modifyAttributes(String var1, int var2, Attributes var3) throws NamingException, WIMException {
		DirContext var5 = this.getDirContext();
		this.checkWritePermission(var5);

		try {
			try {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.entering(CLASSNAME, "JNDI_CALL modifyAttributes(Name, int, Attributes)",
							WIMMessageHelper.generateMsgParms(var1, new Integer(var2), this.printAttributes(var3)));
				}

				var5.modifyAttributes(new LdapName(var1), var2, var3);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.exiting(CLASSNAME, "JNDI_CALL modifyAttributes(Name, int, Attributes)");
				}
			} catch (NamingException var12) {
				if (!isConnectionException(var12, "modifyAttributes(Name, int, Attributes)")) {
					throw var12;
				}

				var5 = this.reCreateDirContext(var5, var12.toString());
				var5.modifyAttributes(new LdapName(var1), var2, var3);
			}
		} catch (NameNotFoundException var13) {
			throw new EntityNotFoundException("NAMING_EXCEPTION",
					WIMMessageHelper.generateMsgParms(var13.toString(true)), CLASSNAME,
					"modifyAttributes(Name, int, Attributes)");
		} catch (NamingException var14) {
			trcLogger.logp(Level.SEVERE, CLASSNAME, "modifyAttributes(Name, int, Attributes)", var14.toString(true));
			throw var14;
		} finally {
			this.releaseDirContext(var5);
		}

	}

	public void rename(String var1, String var2) throws WIMException {
		DirContext var4 = this.getDirContext();
		this.checkWritePermission(var4);

		try {
			try {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.entering(CLASSNAME, "JNDI_CALL rename", WIMMessageHelper.generateMsgParms(var1, var2));
				}

				var4.rename(var1, var2);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.exiting(CLASSNAME, "JNDI_CALL rename");
				}
			} catch (NamingException var10) {
				if (!isConnectionException(var10, "rename")) {
					throw var10;
				}

				var4 = this.reCreateDirContext(var4, var10.toString());
				var4.rename(var1, var2);
			}
		} catch (NamingException var11) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var11.toString(true)),
					Level.SEVERE, CLASSNAME, "rename");
		} finally {
			this.releaseDirContext(var4);
		}

	}

	public Attributes getAttributesByExtId(String var1, String[] var2, List var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "getAttributesByExtId",
					WIMMessageHelper.generateMsgParms(var1, WIMTraceHelper.printObjectArray(var2), var3));
		}

		Attributes var5 = null;
		String var6 = null;
		boolean var7 = false;
		Object var8 = null;
		if (this.getAttributesCache() != null) {
			var7 = true;
			var8 = this.getAttributesCache().get(var1);
		}

		if (var8 != null && var8 instanceof String) {
			var6 = (String) var8;

			try {
				var5 = this.checkAttributesCache(var6, var2);
				if (var5 != null) {
					var5.put("distinguishedName", var6);
				}

				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.exiting(CLASSNAME, "getAttributesByExtId", this.printAttributes(var5));
				}

				return var5;
			} catch (EntityNotFoundException var51) {
				this.getAttributesCache().invalidate(var1);
			}
		}

		if (var7 && trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "getAttributesByExtId", "Miss cache: " + var1);
		}

		String[] var10 = null;
		Object var11 = null;
		boolean var12 = false;
		if (var3 != null && var3.size() > 0) {
			var11 = new HashSet(var3.size());
			ArrayList var13 = new ArrayList(var3.size());

			for (int var14 = 0; var14 < var3.size(); ++var14) {
				List var15 = this.iLdapConfigMgr.getAllLdapEntities((String) var3.get(var14));
				if (var15 != null && var15.size() != 0) {
					for (int var16 = 0; var16 < var15.size(); ++var16) {
						LdapEntity var17 = (LdapEntity) var15.get(var16);
						((Set) var11).add(var17.getExtId());
						var13.addAll(var17.getSearchBaseList());
					}
				} else {
					var12 = true;
				}
			}

			if (!var12) {
				var10 = (String[]) ((String[]) var13.toArray(new String[0]));
				var10 = NodeHelper.getTopNodes(var10);
			}
		}

		if (var10 == null) {
			var11 = this.iLdapConfigMgr.getExtIds();
			var10 = this.iLdapConfigMgr.getTopLdapNodes();
		}

		if (((Set) var11).size() == 0) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1), CLASSNAME,
					"getAttributesByExtId");
		} else {
			StringBuffer var52 = new StringBuffer(256);
			ArrayList var53 = new ArrayList(((Set) var11).size());
			Iterator var54 = ((Set) var11).iterator();

			while (var54.hasNext()) {
				String var56 = (String) var54.next();

				try {
					Object var58 = this.iLdapConfigMgr.getLdapValue(var1, "String", var56);
					if (var58 != null) {
						var53.add(var58);
						var52.append("(").append(var56).append("={").append(var53.size() - 1).append("})");
					}
				} catch (WIMSystemException var44) {
					if ("SYSTEM_EXCEPTION".equalsIgnoreCase(var44.getMessageKey())) {
						throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
								Level.FINE, CLASSNAME, "getAttributesByExtId");
					}

					throw var44;
				}
			}

			if (var53.size() > 1) {
				var52 = new StringBuffer("(|" + var52 + ")");
			}

			Object[] var55 = var53.toArray();
			SearchControls var57 = new SearchControls();
			var57.setTimeLimit(this.iTimeLimit);
			var57.setCountLimit((long) this.iCountLimit);
			var57.setSearchScope(2);
			var57.setReturningAttributes(var2);
			var57.setReturningObjFlag(false);
			DirContext var59 = this.getDirContext();
			String var19 = null;

			try {
				for (int var20 = 0; var20 < var10.length; ++var20) {
					var19 = var10[var20];
					NamingEnumeration var21 = null;

					try {
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.entering(CLASSNAME, "JNDI_CALL search(String, String, Object[], SearchControls",
									WIMMessageHelper.generateMsgParms(var19, var52,
											WIMTraceHelper.printObjectArray(var55),
											LdapHelper.printSearchControls(var57),
											"java.naming.referral: " + this.iEnvironment.get("java.naming.referral")));
						}

						var21 = var59.search(var19, var52.toString(), var55, var57);
						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.exiting(CLASSNAME, "JNDI_CALL search(String, String, Object[], SearchControls");
						}
					} catch (NamingException var48) {
						if (!isConnectionException(var48, "getAttributesByExtId")) {
							throw var48;
						}

						var59 = this.reCreateDirContext(var59, var48.toString());
						var21 = var59.search(var19, var52.toString(), var55, var57);
					}

					if (var21.hasMoreElements()) {
						SearchResult var22 = (SearchResult) var21.nextElement();
						if (var22 != null) {
							var6 = LdapHelper.prepareDN(var22.getName(), var19,
									this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers());
							var5 = var22.getAttributes();
							if (var21.hasMoreElements()) {
								throw new WIMSystemException("DUPLICATE_EXTTERNAL_ID",
										WIMMessageHelper.generateMsgParms(var1), CLASSNAME, "getAttributesByExtId");
							}

							if (this.iAttrRangeStep > 0) {
								this.supportRangeAttributes(var5, var6, var59);
							}
							break;
						}
					}
				}
			} catch (NamingException var49) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var49.toString(true)), Level.SEVERE, CLASSNAME,
						"getAttributesByExtId");
			} finally {
				this.releaseDirContext(var59);
			}

			if (var5 != null) {
				if (var7) {
					this.updateAttributesCache(var1, var6, var5, var2);
				}

				var5.put("distinguishedName", var6);
			} else {
				boolean var60 = true;
				if (!this.iLdapConfigMgr.getLdapType().equalsIgnoreCase("SUNONE")) {
					var60 = true;
				} else {
					int var61 = this.iLdapConfigMgr.getLdapEntities().length;
					LdapEntity[] var62 = this.iLdapConfigMgr.getLdapEntities();
					boolean var23 = false;

					int var24;
					for (var24 = 0; var24 < var61; ++var24) {
						if (var62[var24].getName().equalsIgnoreCase("group")
								&& var62[var24].getObjectClasses().contains("ldapsubentry")) {
							var23 = true;
							break;
						}
					}

					if (var23) {
						var60 = false;
						var52 = new StringBuffer("(&(objectclass=ldapsubentry)" + var52 + ")");
						var59 = this.getDirContext();
						var19 = null;

						try {
							for (var24 = 0; var24 < var10.length; ++var24) {
								var19 = var10[var24];
								NamingEnumeration var25 = null;

								try {
									if (trcLogger.isLoggable(Level.FINE)) {
										trcLogger.entering(CLASSNAME,
												"JNDI_CALL search(String, String, Object[], SearchControls",
												WIMMessageHelper.generateMsgParms(var19, var52,
														WIMTraceHelper.printObjectArray(var55),
														LdapHelper.printSearchControls(var57), "java.naming.referral: "
																+ this.iEnvironment.get("java.naming.referral")));
									}

									var25 = var59.search(var19, var52.toString(), var55, var57);
									if (trcLogger.isLoggable(Level.FINE)) {
										trcLogger.exiting(CLASSNAME,
												"JNDI_CALL search(String, String, Object[], SearchControls");
									}

									if (var25.hasMoreElements()) {
										SearchResult var26 = (SearchResult) var25.nextElement();
										if (var26 != null) {
											var6 = LdapHelper.prepareDN(var26.getName(), var19, this.iLdapConfigMgr
													.getDomainNameForAutomaticDiscoveryOfLDAPServers().toLowerCase());
											var5 = var26.getAttributes();
											if (var25.hasMoreElements()) {
												throw new WIMSystemException("DUPLICATE_EXTTERNAL_ID",
														WIMMessageHelper.generateMsgParms(var1), CLASSNAME,
														"getAttributesByExtId");
											}
											break;
										}
									}
								} catch (NamingException var45) {
									throw var45;
								}
							}
						} catch (NamingException var46) {
							throw new WIMSystemException("NAMING_EXCEPTION",
									WIMMessageHelper.generateMsgParms(var46.toString(true)), Level.SEVERE, CLASSNAME,
									"getAttributesByExtId");
						} finally {
							this.releaseDirContext(var59);
						}
					} else {
						var60 = true;
					}
				}

				if (var60 || var5 == null) {
					throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
							CLASSNAME, "getAttributesByExtId");
				}

				if (var7) {
					this.updateAttributesCache(var1, var6, var5, var2);
				}

				var5.put("distinguishedName", var6);
			}

			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.exiting(CLASSNAME, "getAttributesByExtId", this.printAttributes(var5));
			}

			return var5;
		}
	}

	public Attributes getAttributesByUniqueName(String var1, String[] var2, List var3) throws WIMException {
		String var5 = null;
		Attributes var6 = null;
		var1 = this.iLdapConfigMgr.switchToLdapNode(var1);
		boolean var7 = false;
		if (this.iLdapConfigMgr.needTranslateRDN()) {
			if (var3 != null && var3.size() > 0) {
				for (int var8 = 0; var8 < var3.size(); ++var8) {
					if (this.iLdapConfigMgr.needTranslateRDN((String) var3.get(var8))) {
						var7 = true;
						break;
					}
				}
			} else {
				var7 = true;
			}
		}

		if (!var7) {
			var6 = this.checkAttributesCache(var1, var2);
			var6.put("distinguishedName", var1);
			return var6;
		} else {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.entering(CLASSNAME, "getAttributesByUniqueName",
						WIMMessageHelper.generateMsgParms(var1, WIMTraceHelper.printObjectArray(var2), var3));
			}

			boolean var29 = false;
			Object var9 = null;
			String var10 = toKey(var1);
			if (this.getAttributesCache() != null) {
				var29 = true;
				var9 = this.getAttributesCache().get(var10);
			}

			if (var9 != null && var9 instanceof String) {
				var5 = (String) var9;

				try {
					var6 = this.checkAttributesCache(var5, var2);
					var6.put("distinguishedName", var5);
					return var6;
				} catch (EntityNotFoundException var28) {
					this.getAttributesCache().invalidate(var10);
				}
			}

			String var11 = this.iLdapConfigMgr.getLdapRDNFilter((LdapEntity) null, LdapHelper.getRDN(var1));
			String var12 = LdapHelper.getParentDN(var1);
			SearchControls var13 = new SearchControls();
			var13.setTimeLimit(this.iTimeLimit);
			var13.setCountLimit((long) this.iCountLimit);
			var13.setSearchScope(1);
			var13.setReturningAttributes(var2);
			var13.setReturningObjFlag(false);
			DirContext var14 = this.getDirContext();
			NamingEnumeration var15 = null;

			try {
				try {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.entering(CLASSNAME, "JNDI_CALL search(String, String SearchControls)",
								WIMMessageHelper.generateMsgParms(var12, var11, LdapHelper.printSearchControls(var13),
										"java.naming.referral: " + this.iEnvironment.get("java.naming.referral")));
					}

					var15 = var14.search(var12, var11, var13);
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.exiting(CLASSNAME, "JNDI_CALL search(String, String SearchControls)");
					}
				} catch (NamingException var24) {
					if (!isConnectionException(var24, "getAttributesByUniqueName")) {
						throw var24;
					}

					var14 = this.reCreateDirContext(var14, var24.toString());
					var15 = var14.search(var12, var11, var13);
				}

				if (var15.hasMoreElements()) {
					SearchResult var17 = (SearchResult) var15.nextElement();
					if (var17 != null) {
						var5 = LdapHelper.prepareDN(var17.getName(), var12,
								this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers());
						var6 = var17.getAttributes();
						if (this.iAttrRangeStep > 0) {
							this.supportRangeAttributes(var6, var5, var14);
						}
					}
				}
			} catch (NameNotFoundException var25) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var12),
						CLASSNAME, "getAttributesByUniqueName");
			} catch (NamingException var26) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var26.toString(true)), Level.SEVERE, CLASSNAME,
						"getAttributesByUniqueName");
			} finally {
				this.releaseDirContext(var14);
			}

			if (var6 != null) {
				if (var29) {
					this.updateAttributesCache(var10, var5, var6, var2);
				}

				var6.put("distinguishedName", var5);
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.exiting(CLASSNAME, "getAttributesByUniqueName", this.printAttributes(var6));
				}

				return var6;
			} else {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						CLASSNAME, "getAttributesByUniqueName");
			}
		}
	}

	public LdapEntry getEntityByIdentifier(DataObject var1, List var2, List var3, boolean var4, boolean var5)
			throws WIMException {
		return this.getEntityByIdentifier(var1.getString("externalName"), var1.getString("externalId"),
				var1.getString("uniqueName"), var2, var3, var4, var5);
	}

	public LdapEntry getEntityByIdentifier(String var1, String var2, String var3, List var4, List var5, boolean var6,
			boolean var7) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getEntityByIdentifier",
					WIMMessageHelper.generateMsgParms(var1, var2, var3, var4, var5, var6, var7));
		}

		String[] var9 = this.iLdapConfigMgr.getAttributeNames(var4, var5, var6, var7);
		Attributes var10 = null;
		Object var11 = null;
		String var12 = this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers();
		if (var1 == null && !this.iLdapConfigMgr.needTranslateRDN()) {
			var1 = this.iLdapConfigMgr.switchToLdapNode(var3);
		}

		int var13;
		if (var2 != null) {
			if (this.iLdapConfigMgr.isAnyExtIdDN()) {
				var1 = LdapHelper.getValidDN(var2);
				if (var1 != null) {
					if (var12 != null && var1.toLowerCase().contains(var12.toLowerCase())) {
						var13 = var1.toLowerCase().indexOf(var12.toLowerCase());
						var1 = var1.substring(0, var13 - 1);
					}

					var10 = this.checkAttributesCache(var1, var9);
				} else {
					if (var3 == null) {
						throw new EntityNotFoundException("ENTITY_NOT_FOUND",
								WIMMessageHelper.generateMsgParms((Object) null), CLASSNAME, "getEntityByIdentifier");
					}

					var10 = this.getAttributesByUniqueName(var3, var9, var4);
					var1 = LdapHelper.getDNFromAttributes(var10);
				}
			} else {
				var10 = this.getAttributesByExtId(var2, var9, var4);
				var1 = LdapHelper.getDNFromAttributes(var10);
			}
		} else if (var1 != null) {
			if (var12 != null && var1.toLowerCase().contains(var12.toLowerCase())) {
				var13 = var1.toLowerCase().indexOf(var12.toLowerCase());
				var1 = var1.substring(0, var13 - 1);
			}

			var10 = this.checkAttributesCache(var1, var9);
		} else {
			if (var3 == null) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms((Object) null),
						CLASSNAME, "getEntityByIdentifier");
			}

			var10 = this.getAttributesByUniqueName(var3, var9, var4);
			var1 = LdapHelper.getDNFromAttributes(var10);
		}

		if (var12 != null && var1.toLowerCase().contains(var12.toLowerCase())) {
			var13 = var1.toLowerCase().indexOf(var12.toLowerCase());
			var1 = var1.substring(0, var13 - 1);
		}

		String var16 = this.iLdapConfigMgr.getEntityType(var10, var3, var1, var2, var4);
		if (this.iLdapConfigMgr.isReturnUniqueNameInNormalCaseIfExtIdMapToDN()) {
			if (var3 == null) {
				var3 = this.getUniqueName(var1, var16, var10);
			}
		} else {
			var3 = this.getUniqueName(var1, var16, var10);
		}

		if (var2 == null) {
			var2 = this.iLdapConfigMgr.getExtIdFromAttributes(var1, var16, var10);
		}

		if (this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers() != null) {
			var1 = LdapHelper.prepareDN(var1, "",
					this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers());
			if (var3 != null && !var3.equals("")) {
				try {
					new LdapName(var3);
					if (!var3.toLowerCase()
							.endsWith(this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServersLowerCase())) {
						var3 = var3 + "," + this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers();
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "getEntityByIdentifier",
									"Override unique name, add getDomainNameForAutomaticDiscoveryOfLDAPServers "
											+ var3);
						}
					}
				} catch (Exception var15) {
					;
				}
			}
		}

		LdapEntry var14 = new LdapEntry(var1, var2, var3, var16, var10);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getEntityByIdentifier", var14.toString());
		}

		return var14;
	}

	private NamingEnumeration updateSearchCache(String var1, String var2, NamingEnumeration var3, String[] var4)
			throws WIMSystemException {
		CachedNamingEnumeration var6 = new CachedNamingEnumeration();
		CachedNamingEnumeration var7 = new CachedNamingEnumeration();
		int var8 = cloneSearchResults(var3, var6, var7);
		if (this.iSearchResultSizeLmit == 0 || var8 < this.iSearchResultSizeLmit) {
			this.getSearchResultsCache().put(var2, var7, 1, this.iSearchResultsCacheTimeOut,
					this.iSearchResultsCacheDistPolicy, (Object[]) null);
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "updateSearchCache", "Update " + this.iSearchResultsCacheName
						+ "(size: " + this.getSearchResultsCache().size() + ")\n" + var2);
			}

			if (this.getAttributesCache() != null) {
				try {
					var8 = 0;

					while (var7.hasMore()) {
						SearchResult var9 = (SearchResult) var7.nextElement();
						String var10 = LdapHelper.prepareDN(var9.getName(), var1,
								this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers());
						Object var11 = this.getAttributesCache().get(var10);
						Attributes var12 = null;
						if (var11 != null && var11 instanceof Attributes) {
							var12 = (Attributes) var11;
						}

						this.updateAttributesCache(var10, var9.getAttributes(), var12, var4);
						++var8;
						if (var8 > 20) {
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "updateSearchCache",
										"attribute cache updated with " + (var8 - 1) + " entries. skipping rest.");
							}
							break;
						}
					}
				} catch (NamingException var13) {
					;
				}
			}
		}

		return var6;
	}

	public NamingEnumeration checkSearchCache(String var1, String var2, Object[] var3, SearchControls var4)
			throws WIMException {
		NamingEnumeration var6 = null;
		Object var10;
		if (this.getSearchResultsCache() != null) {
			String var7 = null;
			if (var3 == null) {
				var7 = toKey(var1, var2, var4);
			} else {
				var7 = toKey(var1, var2, var3, var4);
			}

			CachedNamingEnumeration var8 = (CachedNamingEnumeration) this.getSearchResultsCache().get(var7);
			if (var8 == null) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "checkSearchCache", "Miss cache: " + var7);
				}

				var6 = this.search(var1, var2, var3, var4, (Control[]) null);
				String[] var9 = var4.getReturningAttributes();
				var10 = this.updateSearchCache(var1, var7, var6, var9);
			} else {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "checkSearchCache", "Hit cache: " + var7);
				}

				var10 = (CachedNamingEnumeration) var8.clone();
			}
		} else {
			var10 = this.search(var1, var2, var3, var4, (Control[]) null);
		}

		return (NamingEnumeration) var10;
	}

	NamingEnumeration search(String var1, String var2, Object[] var3, SearchControls var4, Control[] var5)
			throws WIMException {
		if (this.iPageSize == 0) {
			DirContext var44 = this.getDirContext();
			NamingEnumeration var45 = null;

			try {
				try {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.entering(CLASSNAME, "JNDI_CALL search(String, String, Object[], SearchControls)",
								WIMMessageHelper.generateMsgParms(var1, var2, WIMTraceHelper.printObjectArray(var3),
										LdapHelper.printSearchControls(var4),
										"java.naming.referral: " + this.iEnvironment.get("java.naming.referral")));
					}

					if (var3 == null) {
						var45 = var44.search(new LdapName(var1), var2, var4);
					} else {
						var45 = var44.search(new LdapName(var1), var2, var3, var4);
					}

					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.exiting(CLASSNAME, "JNDI_CALL search(String, String, Object[], SearchControls)");
					}
				} catch (NamingException var37) {
					if (!isConnectionException(var37, "search(String, String, Object[], SearchControls)")) {
						throw var37;
					}

					var44 = this.reCreateDirContext(var44, var37.toString());
					if (var3 == null) {
						var45 = var44.search(new LdapName(var1), var2, var4);
					} else {
						var45 = var44.search(new LdapName(var1), var2, var3, var4);
					}

					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.exiting(CLASSNAME, "JNDI_CALL search(String, String, Object[], SearchControls)");
					}
				}
			} catch (NameNotFoundException var38) {
				throw new EntityNotFoundException("LDAP_ENTRY_NOT_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var38.toString(true)), CLASSNAME,
						"search(String, String, Object[], SearchControls)");
			} catch (NamingException var39) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var39.toString(true)), Level.SEVERE, CLASSNAME,
						"search(String, String, Object[], SearchControls)");
			} finally {
				this.releaseDirContext(var44);
			}

			return var45;
		} else {
			LdapContext var7 = (LdapContext) this.getDirContext();

			CachedNamingEnumeration var46;
			try {
				if (var5 != null) {
					var7.setRequestControls(new Control[]{var5[0], new PagedResultsControl(this.iPageSize)});
				} else {
					var7.setRequestControls(new Control[]{new PagedResultsControl(this.iPageSize)});
				}

				byte[] var8 = null;
				int var9 = 1;
				int var10 = 0;
				CachedNamingEnumeration var11 = new CachedNamingEnumeration();
				int var12 = 0;

				boolean var13;
				do {
					var13 = false;
					NamingEnumeration var14 = null;

					try {
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "search(String, String, Object[], SearchControls)",
									"Search page: " + var9 + ", Retries: " + var12);
						}

						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.entering(CLASSNAME, "JNDI_CALL search(String, String, Object[], SearchControls)",
									WIMMessageHelper.generateMsgParms(var1, var2, WIMTraceHelper.printObjectArray(var3),
											LdapHelper.printSearchControls(var4),
											"java.naming.referral: " + this.iEnvironment.get("java.naming.referral")));
						}

						if (var3 == null) {
							var14 = var7.search(new LdapName(var1), var2, var4);
						} else {
							var14 = var7.search(new LdapName(var1), var2, var3, var4);
						}

						if (trcLogger.isLoggable(Level.FINE)) {
							trcLogger.exiting(CLASSNAME, "JNDI_CALL search(String, String, Object[], SearchControls)");
						}

						if (var14 != null) {
							++var9;

							while (var14.hasMoreElements()) {
								var11.add(var14.nextElement());
								++var10;
							}

							Control[] var15 = var7.getResponseControls();
							if (var15 != null && var15.length > 0) {
								PagedResultsControl var16 = new PagedResultsControl(var15[0].getEncodedValue());
								var8 = var16.getCookie();
								if (var8.length > 0) {
									var7.setRequestControls(
											new Control[]{new PagedResultsControl(this.iPageSize, var8)});
								}
							}
						}
					} catch (NamingException var41) {
						if (!isConnectionException(var41, "search(String, String, Object[], SearchControls)")
								|| var12 != 0) {
							throw var41;
						}

						var13 = true;
						++var12;
						var9 = 1;
						var8 = null;
						var11 = new CachedNamingEnumeration();
						var10 = 0;
						var7 = (LdapContext) this.reCreateDirContext(var7, var41.toString());
						if (var5 != null) {
							var7.setRequestControls(new Control[]{var5[0], new PagedResultsControl(this.iPageSize)});
						} else {
							var7.setRequestControls(new Control[]{new PagedResultsControl(this.iPageSize)});
						}
					}
				} while (var13 || var8 != null && var8.length > 0 && (long) var10 < var4.getCountLimit());

				var46 = var11;
			} catch (NamingException var42) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var42.toString(true)), Level.SEVERE, CLASSNAME,
						"search(String, String, Object[], SearchControls)");
			} finally {
				try {
					var7.setRequestControls((Control[]) null);
				} catch (NamingException var36) {
					trcLogger.logp(Level.SEVERE, CLASSNAME, "search(String, String, Object[], SearchControls)",
							var36.toString(true));
				}

				this.releaseDirContext(var7);
			}

			return var46;
		}
	}

	public NamingEnumeration search(String var1, String var2, int var3, String[] var4, int var5, int var6)
			throws WIMException {
		SearchControls var7 = new SearchControls(var3, (long) var5, var6, var4, false, false);
		return this.checkSearchCache(var1, var2, (Object[]) null, var7);
	}

	public NamingEnumeration search(String var1, String var2, Object[] var3, int var4, String[] var5, int var6,
			int var7) throws WIMException {
		SearchControls var8 = new SearchControls(var4, (long) var6, var7, var5, false, false);
		return this.checkSearchCache(var1, var2, var3, var8);
	}

	public NamingEnumeration search(String var1, String var2, int var3, String[] var4) throws WIMException {
		SearchControls var5 = new SearchControls(var3, (long) this.iCountLimit, this.iTimeLimit, var4, false, false);
		return this.checkSearchCache(var1, var2, (Object[]) null, var5);
	}

	public Set searchEntities(String var1, String var2, Object[] var3, int var4, List var5, List var6, boolean var7,
			boolean var8) throws WIMException {
		return this.searchEntities(var1, var2, var3, var4, var5, var6, var7, var8, this.iCountLimit, this.iTimeLimit);
	}

	public Map getDynamicGroups(String[] var1, List var2, boolean var3) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "getDynamicGroups",
					WIMMessageHelper.generateMsgParms(WIMTraceHelper.printObjectArray(var1), var2));
		}

		HashMap var5 = new HashMap();
		String[] var6 = this.iLdapConfigMgr.getAttributeNames(this.iLdapConfigMgr.getGroupTypes(), var2, var3, false);
		String[] var7 = this.iLdapConfigMgr.getDynamicMemberAttributes();
		String[] var8 = var6;
		var6 = new String[var6.length + var7.length];
		System.arraycopy(var8, 0, var6, 0, var8.length);
		System.arraycopy(var7, 0, var6, var8.length, var7.length);
		String var9 = this.iLdapConfigMgr.getDynamicGroupFilter();
		int var10 = 0;

		for (int var11 = var1.length; var10 < var11; ++var10) {
			String var12 = var1[var10];
			NamingEnumeration var13 = this.search(var12, var9, 2, var6);

			while (var13.hasMoreElements()) {
				SearchResult var14 = (SearchResult) var13.nextElement();
				if (var14 != null) {
					String var15 = var14.getName();
					if (var15 != null && var15.trim().length() != 0) {
						String var16 = LdapHelper.prepareDN(var15, var12,
								this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers());
						Attributes var17 = var14.getAttributes();
						String var18 = this.iLdapConfigMgr.getExtIdFromAttributes(var16, "Group", var17);
						String var19 = this.getUniqueName(var16, "Group", var17);
						LdapEntry var20 = new LdapEntry(var16, var18, var19, "Group", var17);
						var5.put(var20.getDN(), var20);
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "getDynamicGroups", var5);
		}

		return var5;
	}

	public boolean isMemberInURLQuery(LdapURL[] var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "isMemberInURLQuery",
					WIMMessageHelper.generateMsgParms(WIMTraceHelper.printObjectArray(var1), var2));
		}

		boolean var4 = false;
		String[] var5 = new String[0];
		String var6 = LdapHelper.getRDN(var2);
		if (var1 != null) {
			for (int var7 = 0; var7 < var1.length; ++var7) {
				LdapURL var8 = var1[var7];
				if (var8.parsedOK()) {
					String var9 = var8.get_dn();
					if (LdapHelper.isUnderBases(var2, var9)) {
						int var10 = var8.get_searchScope();
						String var11 = var8.get_filter();
						NamingEnumeration var12;
						if (var10 == 2) {
							if (var11 == null) {
								var4 = true;
								break;
							}

							var12 = this.search(var2, var11, 2, var5);
							if (var12.hasMoreElements()) {
								var4 = true;
								break;
							}
						} else {
							if (var11 == null) {
								var11 = var6;
							} else {
								var11 = "(&(" + var11 + ")(" + var6 + "))";
							}

							var12 = this.search(var9, var11, var10, var5);
							if (var12.hasMoreElements()) {
								SearchResult var13 = (SearchResult) var12.nextElement();
								if (var13 != null) {
									String var14 = LdapHelper.prepareDN(var13.getName(), var9,
											this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers());
									if (var2.equalsIgnoreCase(var14)) {
										var4 = true;
										break;
									}
								}
							}
						}
					}
				}
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "isMemberInURLQuery", var4);
		}

		return var4;
	}

	private Set populateResultSet(NamingEnumeration var1, String var2, int var3, List var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "populateResultSet",
					WIMMessageHelper.generateMsgParms(var1, var2, new Integer(var3), var4));
		}

		HashSet var6 = new HashSet();

		try {
			while (var1.hasMore()) {
				SearchResult var7 = (SearchResult) var1.nextElement();
				if (var7 != null) {
					String var8 = var7.getName();
					String var9 = LdapHelper.prepareDN(var8, var2,
							this.iLdapConfigMgr.getDomainNameForAutomaticDiscoveryOfLDAPServers());
					if (var3 == 0 || !var2.equalsIgnoreCase(var9)) {
						Attributes var10 = var7.getAttributes();
						String var11 = this.iLdapConfigMgr.getEntityType(var10, (String) null, var9, (String) null,
								var4);
						String var12 = this.iLdapConfigMgr.getExtIdFromAttributes(var9, var11, var10);
						String var13 = this.getUniqueName(var9, var11, var10);
						LdapEntry var14 = new LdapEntry(var9, var12, var13, var11, var10);
						var6.add(var14);
					}
				}
			}
		} catch (SizeLimitExceededException var15) {
			trcLogger.logp(Level.FINE, CLASSNAME, "populateResultSet", var15.toString(true), var15);
		} catch (NamingException var16) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var16.toString(true)),
					Level.SEVERE, CLASSNAME, "populateResultSet");
		}

		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "populateResultSet", var6);
		}

		return var6;
	}

	public NamingEnumeration search_skip_cache(String var1, String var2, int var3, String[] var4, Control[] var5)
			throws WIMException {
		SearchControls var6 = new SearchControls(var3, (long) this.iCountLimit, this.iTimeLimit, var4, true, false);
		return this.search(var1, var2, (Object[]) null, var6, var5);
	}

	public Set searchEntities_skip_cache(String var1, String var2, int var3, List var4, List var5, int var6, int var7,
			Control[] var8) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "searchEntities_skip_cache",
					WIMMessageHelper.generateMsgParms(var1, var2, new Integer(var3), var4, var5));
		}

		String[] var10 = this.iLdapConfigMgr.getAttributeNames(var4, var5, false, false);
		NamingEnumeration var11 = this.search_skip_cache(var1, var2, var3, var10, var8);
		Set var12 = this.populateResultSet(var11, var1, var3, var4);
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "searchEntities_skip_cache", var12);
		}

		return var12;
	}

	public Set searchEntities(String var1, String var2, Object[] var3, int var4, List var5, List var6, boolean var7,
			boolean var8, int var9, int var10) throws WIMException {
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.entering(CLASSNAME, "searchEntities", WIMMessageHelper.generateMsgParms(var1, var2,
					WIMTraceHelper.printObjectArray(var3), new Integer(var4), var5, var6, var7, var8));
		}

		String var12 = null;
		ArrayList var13 = new ArrayList();
		if (var6 != null) {
			var13.addAll(var6);
		}

		Iterator var15;
		if (var5 != null && var5.size() > 0) {
			var13.clear();
			var15 = var5.iterator();

			label43 : while (true) {
				List var14;
				do {
					if (!var15.hasNext()) {
						break label43;
					}

					Object var16 = var15.next();
					var12 = (String) var16;
					var14 = this.iLdapConfigMgr.getSupportedProperties(var12, var6);
				} while (var14 == null);

				Iterator var17 = var14.iterator();

				while (var17.hasNext()) {
					Object var18 = var17.next();
					if (!var13.contains(var18)) {
						var13.add(var18);
					}
				}
			}
		}

		String[] var19 = this.iLdapConfigMgr.getAttributeNames(var5, var13, var7, var8);
		var15 = null;
		NamingEnumeration var20;
		if (var3 == null) {
			var20 = this.search(var1, var2, var4, var19, var9, var10);
		} else {
			var20 = this.search(var1, var2, var3, var4, var19, var9, var10);
		}

		Set var21 = this.populateResultSet(var20, var1, var4, var5);
		if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.exiting(CLASSNAME, "searchEntities", var21);
		}

		return var21;
	}

	public void setConnectionRequsetControls(Control[] var1) {
		this.iConnCtls = var1;
	}

	public boolean setCountLimit(int var1) {
		if (var1 >= 0) {
			this.iCountLimit = var1;
			return true;
		} else {
			return false;
		}
	}

	private static String toKey(String var0, String var1) {
		int var2 = var0.length() + var1.length() + 2;
		StringBuffer var3 = new StringBuffer(var2);
		var3.append(var0).append("|").append(var1.toLowerCase());
		return var3.toString();
	}

	private static String toKey(String var0) {
		return LdapConfigManager.isCaseSensitiveDNForAttributeCache() ? var0 : var0.toLowerCase();
	}

	private static String toKey(String var0, String var1, SearchControls var2) {
		int var3 = var0.length() + var1.length() + 100;
		StringBuffer var4 = new StringBuffer(var3);
		var4.append(var0);
		var4.append("|");
		var4.append(var1);
		var4.append("|");
		var4.append(var2.getSearchScope());
		var4.append("|");
		var4.append(var2.getCountLimit());
		var4.append("|");
		var4.append(var2.getTimeLimit());
		String[] var5 = var2.getReturningAttributes();
		if (var5 != null) {
			for (int var6 = 0; var6 < var5.length; ++var6) {
				var4.append("|");
				var4.append(var5[var6]);
			}
		}

		return var4.toString();
	}

	private static String toKey(String var0, String var1, Object[] var2, SearchControls var3) {
		int var4 = var0.length() + var1.length() + var2.length + 200;
		StringBuffer var5 = new StringBuffer(var4);
		var5.append(var0);
		var5.append("|");
		var5.append(var1);
		String[] var6 = var3.getReturningAttributes();

		int var7;
		for (var7 = 0; var7 < var2.length; ++var7) {
			var5.append("|");
			var5.append(var2[var7]);
		}

		if (var6 != null) {
			for (var7 = 0; var7 < var6.length; ++var7) {
				var5.append("|");
				var5.append(var6[var7]);
			}
		}

		return var5.toString();
	}

	private static int cloneSearchResults(NamingEnumeration var0, CachedNamingEnumeration var1,
			CachedNamingEnumeration var2) throws WIMSystemException {
		int var4 = 0;

		try {
			while (var0.hasMore()) {
				SearchResult var5 = (SearchResult) var0.nextElement();
				Attributes var6 = (Attributes) var5.getAttributes().clone();
				SearchResult var7 = new SearchResult(var5.getName(), (String) null, (Object) null, var6);
				var1.add(var5);
				var2.add(var7);
				++var4;
			}
		} catch (SizeLimitExceededException var8) {
			trcLogger.logp(Level.FINE, CLASSNAME,
					"cloneSearchResults(NamingEnumeration, CachedNamingEnumeration, CachedNamingEnumeration)",
					var8.toString(true), var8);
		} catch (NamingException var9) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var9.toString(true)),
					Level.SEVERE, CLASSNAME,
					"cloneSearchResults(NamingEnumeration, CachedNamingEnumeration, CachedNamingEnumeration)");
		}

		return var4;
	}

	private String printAttributes(Attributes var1) {
		if (var1 == null) {
			return "null";
		} else {
			Set var2 = this.iLdapConfigMgr.getConfidentialAttributes();
			HashSet var3 = new HashSet(var2.size());
			NamingEnumeration var4 = var1.getIDs();

			while (var4.hasMoreElements()) {
				String var5 = (String) var4.nextElement();
				if (var2.contains(var5.toLowerCase())) {
					var3.add(var5);
				}
			}

			if (var3.size() == 0) {
				return var1.toString();
			} else {
				Attributes var8 = (Attributes) var1.clone();
				Iterator var9 = var3.iterator();

				while (var9.hasNext()) {
					String var6 = (String) var9.next();
					BasicAttribute var7 = new BasicAttribute(var6, "****");
					var8.put(var7);
				}

				return var8.toString();
			}
		}
	}

	private String printModificationItem(ModificationItem[] var1) {
		if (var1 == null) {
			return null;
		} else {
			StringBuffer var2 = new StringBuffer(400);
			Set var3 = this.iLdapConfigMgr.getConfidentialAttributes();
			var2.append("[");

			for (int var4 = 0; var4 < var1.length; ++var4) {
				ModificationItem var5 = var1[var4];
				if (var5 != null) {
					Attribute var6 = var5.getAttribute();
					if (var6 != null && var3.contains(var6.getID().toLowerCase())) {
						BasicAttribute var7 = new BasicAttribute(var6.getID(), "****");
						var2.append(new ModificationItem(var5.getModificationOp(), var7));
					} else {
						var2.append(var5);
					}
				} else {
					var2.append("null");
				}

				if (var4 != var1.length - 1) {
					var2.append(", ");
				}
			}

			var2.append("]");
			return var2.toString();
		}
	}

	public List getAncestorDNs(String var1, int var2) throws WIMException {
		if (var1 != null && var1.trim().length() != 0) {
			try {
				NameParser var4 = this.getNameParser();
				Name var5 = var4.parse(var1);
				int var6 = var5.size();
				ArrayList var7 = new ArrayList();
				if (var2 == 0) {
					var2 = var6;
				}

				for (int var8 = var6 - 1; var8 >= var6 - var2; --var8) {
					var5.remove(var8);
					var7.add(var5.toString());
				}

				return var7;
			} catch (NamingException var9) {
				throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var9.toString(true)),
						Level.SEVERE, CLASSNAME, "getAncestorDNs");
			}
		} else {
			return null;
		}
	}

	public String getUniqueName(String var1, String var2, Attributes var3) throws WIMException {
		String var5 = null;
		var1 = this.iLdapConfigMgr.switchToNode(var1);
		if (this.iLdapConfigMgr.needTranslateRDN() && this.iLdapConfigMgr.needTranslateRDN(var2)) {
			try {
				if (var2 != null) {
					LdapEntity var6 = this.iLdapConfigMgr.getLdapEntity(var2);
					if (var6 != null) {
						String[] var7 = LdapHelper.getRDNAttributes(var1);
						String[][] var8 = var6.getWIMRDNProperties();
						String[][] var9 = var6.getWIMRDNAttributes();
						String[][] var10 = var6.getRDNAttributes();
						Attribute[] var11 = new Attribute[var8.length];
						String[] var12 = new String[var8.length];

						for (int var13 = 0; var13 < var10.length; ++var13) {
							String[] var14 = var10[var13];
							boolean var15 = true;

							for (int var16 = 0; var16 < var14.length; ++var16) {
								if (!var14[var16].equalsIgnoreCase(var7[var16])) {
									var15 = false;
								}
							}

							if (var15) {
								String[] var21 = var8[var13];
								String[] var17 = var9[var13];
								boolean var18 = false;
								int var19;
								if (var3 == null) {
									var18 = true;
								} else {
									for (var19 = 0; var19 < var17.length; ++var19) {
										if (var3.get(var17[var19]) == null) {
											var18 = true;
											break;
										}
									}
								}

								if (var18) {
									var3 = this.getAttributes(var1, var17);
								}

								for (var19 = 0; var19 < var17.length; ++var19) {
									var11[var19] = var3.get(var17[var19]);
									if (var11[var19] != null) {
										var12[var19] = (String) var11[var19].get();
									}
								}

								var5 = LdapHelper.replaceRDN(var1, var21, var12);
							}
						}
					}
				}
			} catch (NamingException var20) {
				throw new WIMSystemException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var20.toString(true)), Level.SEVERE, CLASSNAME,
						"getUniqueName");
			}
		}

		if (var5 == null) {
			var5 = var1;
		} else if (trcLogger.isLoggable(Level.FINE)) {
			trcLogger.logp(Level.FINE, CLASSNAME, "getUniqueName", "Translated uniqueName: " + var5);
		}

		return var5;
	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		String var4 = DomainManagerUtils.getDomainName();
		if ("websphere.usermanager.serviceprovider.update.ldap.bindinfo".equalsIgnoreCase(var1)) {
			DataObject var5 = (DataObject) var2.get("DYNA_CONFIG_KEY_REPOS_CONFIG");
			Hashtable var6 = null;
			DataObject var7 = var5.getDataObject("ldapServerConfiguration");
			List var8 = var7.getList("ldapServers");
			DataObject var9 = (DataObject) var8.get(0);
			var6 = this.initializeEnvironmentProperties(var9);
			String var10 = (String) var2.get("DYNA_CONFIG_KEY_LDAP_BIND_DN");
			byte[] var11 = (byte[]) ((byte[]) var2.get("DYNA_CONFIG_KEY_LDAP_BIND_PASSWORD"));
			if (var10 != null) {
				var6.remove("java.naming.security.principal");
				var6.put("java.naming.security.principal", var10);
			}

			if (var11 != null) {
				var6.remove("java.naming.security.credentials");
				var6.put("java.naming.security.credentials", var11);
			}

			try {
				DirContext var12 = this.createDirContext(var6);
				var12.close();
			} catch (NamingException var22) {
				throw new DynamicUpdateConfigException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var22.toString(true)), Level.SEVERE, CLASSNAME,
						"dynamicUpdateConfig");
			}

			if (var5 != null) {
				this.initializeContextPool(var5.getDataObject("contextPool"));
			}

			try {
				boolean var26 = false;

				try {
					var26 = this.lockThreads.tryAcquire(0L, TimeUnit.SECONDS);
				} catch (InterruptedException var24) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.warning(CLASSNAME + " " + "dynamicUpdateConfig" + " Unable to obtain semaphore ["
								+ var24.getMessage() + "]");
					}
				}

				if (!var26 && trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "dynamicUpdateConfig",
							"**LDAPBind - failed to acquire semaphore");
				}

				trcLogger.logp(Level.CONFIG, CLASSNAME, "dynamicUpdateConfig", "hasSemaphore = " + var26
						+ " && blockThread= " + !this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock());
				if (var26 || !this.iLdapConfigMgr.isMinimizeContextPoolThreadBlock()) {
					trcLogger.logp(Level.CONFIG, CLASSNAME, "dynamicUpdateConfig", "HERE TO ACQUIRE LOCK");

					try {
						Object var13 = lock;
						synchronized (lock) {
							this.iEnvironment = var6;
							this.createContextPool(this.iInitPoolSize, (String) null);
						}
					} finally {
						if (var26) {
							this.lockThreads.release();
							trcLogger.logp(Level.CONFIG, CLASSNAME, "dynamicUpdateConfig", "Releasing Semaphore");
						}

					}
				}
			} catch (NamingException var25) {
				throw new DynamicUpdateConfigException("NAMING_EXCEPTION",
						WIMMessageHelper.generateMsgParms(var25.toString(true)), Level.SEVERE, CLASSNAME,
						"dynamicUpdateConfig");
			}
		}

	}

	public String getRepositoryType() {
		return this.iLdapConfigMgr.getLdapType();
	}

	public String getRepositoryId() {
		return this.iReposId;
	}

	private void supportRangeAttributes(Attributes var1, String var2, DirContext var3)
			throws WIMException, NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "supportRangeAttributes");
		}

		NamingEnumeration var6 = var1.getAll();

		while (true) {
			Attribute var7;
			String var8;
			int var9;
			do {
				if (!var6.hasMoreElements()) {
					if (trcLogger.isLoggable(Level.FINER)) {
						trcLogger.exiting(CLASSNAME, "supportRangeAttributes");
					}

					return;
				}

				var7 = (Attribute) var6.nextElement();
				var8 = var7.getID();
				var9 = var8.indexOf(";range=");
			} while (var9 <= -1);

			String var10 = var8.substring(0, var9);
			BasicAttribute var11 = new BasicAttribute(var10);
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "supportRangeAttributes", "Range attribute retrieved: " + var8);
			}

			NamingEnumeration var12 = var7.getAll();

			while (var12.hasMoreElements()) {
				var11.add(var12.nextElement());
			}

			int var24 = this.parseRangeAttribute(var8);
			int var13 = var24;

			try {
				var13 = Integer.parseInt(var8.substring(var8.indexOf(45) + 1)) + 1;
			} catch (NumberFormatException var22) {
				;
			}

			int var14 = var13 + var24 - 1;
			boolean var15 = false;

			do {
				String var16 = null;
				Object[] var17 = new Object[]{(new Integer(var13)).toString(), (new Integer(var14)).toString()};
				var16 = var10 + MessageFormat.format(";range={0}-{1}", var17);
				Attributes var18 = null;
				String[] var19 = new String[]{var16};

				try {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.entering(CLASSNAME, "JNDI_CALL getAttributes(String, String[])",
								WIMMessageHelper.generateMsgParms(var2, WIMTraceHelper.printObjectArray(var19)));
					}

					var18 = var3.getAttributes(new LdapName(var2), var19);
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.exiting(CLASSNAME, "JNDI_CALL getAttributes(String, String[])", var18.toString());
					}
				} catch (NamingException var23) {
					if (!isConnectionException(var23, "JNDI_CALL getAttributes(String, String[])")) {
						throw var23;
					}

					var3 = this.reCreateDirContext(var3, var23.toString());
					var18 = var3.getAttributes(new LdapName(var2), var19);
				}

				Attribute var20 = var18.get(var16);
				if (var20 == null) {
					Object[] var21 = new Object[]{(new Integer(var13)).toString()};
					var16 = var10 + MessageFormat.format(";range={0}-*", var21);
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "supportRangeAttributes",
								"Result was null, now parsing results for " + var16);
					}

					var20 = var18.get(var16);
					if (var20 != null) {
						var15 = true;
					}
				}

				if (var20 == null) {
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "supportRangeAttributes",
								"Quitting the supportRangeAttributes loop. The ranged results were not found or not parsed correctly.");
					}

					var15 = true;
				} else {
					NamingEnumeration var25 = var20.getAll();

					while (var25.hasMoreElements()) {
						var11.add(var25.nextElement());
					}

					var13 = var14 + 1;
					var14 = var13 + var24 - 1;
				}
			} while (!var15);

			var1.put(var11);
			var1.remove(var8);
		}
	}

	private int parseRangeAttribute(String var1) {
		try {
			int var3 = Integer.parseInt(var1.substring(var1.indexOf(61) + 1, var1.indexOf(45)));
			int var4 = Integer.parseInt(var1.substring(var1.indexOf(45) + 1));
			int var5 = var4 - var3 + 1;
			if (this.iAttrRangeStep > var5) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "parseRangeAttribute",
							"The value for attrRangeStep, " + this.iAttrRangeStep
									+ ", is invalid. The maximum number of results allowed by LDAP is " + var5
									+ ", so this will be used as the range step.");
				}

				return var5;
			}
		} catch (NumberFormatException var6) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "parseRangeAttribute",
						"The range attribute was not parsed correctly. Use current value for iAttrRangeStep.");
			}
		}

		return this.iAttrRangeStep;
	}

	private Subject handleKerberos() throws LoginException, MalformedURLException {
		if (!this.isKerberosBindAuth()) {
			if (trcLogger.isLoggable(Level.FINE)) {
				trcLogger.logp(Level.FINE, CLASSNAME, "handleKerberos",
						"Kerberos login method was called, but Kerberos is not enabled. BindAuthMechanism is "
								+ this.bindAuthMechanism);
			}

			return null;
		} else {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "handleKerberos", this.krb5Principal);
			}

			if (this.krbs == null) {
				this.krbs = KerberosService.getInstance();
			}

			Subject var2 = null;
			var2 = this.krbs.getOrCreateSubject(this.krb5Principal, this.krb5Config, this.krb5TicketCache,
					this.krb5Keytab);
			String var3 = var2 != null ? "subject is not null." : "subject is null.";
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "handleKerberos", var3);
			}

			return var2;
		}
	}

	private boolean isKerberosBindAuth() {
		return "GSSAPI".equals(this.bindAuthMechanism);
	}

	private void clearKerberosSubjectCache() {
		if (this.isKerberosBindAuth()) {
			if (this.krbs == null) {
				this.krbs = KerberosService.getInstance();
			}

			try {
				this.krbs.clearPrincipalFromCache(this.krb5Principal);
			} catch (LoginException var3) {
				if (trcLogger.isLoggable(Level.FINE)) {
					trcLogger.logp(Level.FINE, CLASSNAME, "clearKerberosSubjectCache",
							"Exception clearing the Kerberos subject cache", var3);
				}
			}

		}
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2011;
		CLASSNAME = LdapConnection.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
		lock = new Object();
	}
}