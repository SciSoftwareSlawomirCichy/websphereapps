package com.ibm.ws.wim.configmodel;

public interface MemberAttributesType {
	String getDummyMember();

	void setDummyMember(String var1);

	String getName();

	void setName(String var1);

	String getObjectClass();

	void setObjectClass(String var1);

	String getScope();

	void setScope(String var1);

	void unsetScope();

	boolean isSetScope();
}