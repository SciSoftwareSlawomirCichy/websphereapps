package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface ConfigurationProviderType {
	DynamicModelType getDynamicModel();

	void setDynamicModel(DynamicModelType var1);

	DynamicModelType createDynamicModel();

	StaticModelType getStaticModel();

	void setStaticModel(StaticModelType var1);

	StaticModelType createStaticModel();

	List getSupportedEntityTypes();

	SupportedEntityTypesType[] getSupportedEntityTypesAsArray();

	SupportedEntityTypesType createSupportedEntityTypes();

	EntryMappingRepositoryType getEntryMappingRepository();

	void setEntryMappingRepository(EntryMappingRepositoryType var1);

	EntryMappingRepositoryType createEntryMappingRepository();

	PropertyExtensionRepositoryType getPropertyExtensionRepository();

	void setPropertyExtensionRepository(PropertyExtensionRepositoryType var1);

	PropertyExtensionRepositoryType createPropertyExtensionRepository();

	List getRepositories();

	ProfileRepositoryType[] getRepositoriesAsArray();

	ProfileRepositoryType createRepositories();

	RealmConfigurationType getRealmConfiguration();

	void setRealmConfiguration(RealmConfigurationType var1);

	RealmConfigurationType createRealmConfiguration();

	PluginManagerConfigurationType getPluginManagerConfiguration();

	void setPluginManagerConfiguration(PluginManagerConfigurationType var1);

	PluginManagerConfigurationType createPluginManagerConfiguration();

	AuthorizationType getAuthorization();

	void setAuthorization(AuthorizationType var1);

	AuthorizationType createAuthorization();

	int getMaxPagingResults();

	void setMaxPagingResults(int var1);

	void unsetMaxPagingResults();

	boolean isSetMaxPagingResults();

	int getMaxSearchResults();

	void setMaxSearchResults(int var1);

	void unsetMaxSearchResults();

	boolean isSetMaxSearchResults();

	int getMaxTotalPagingResults();

	void setMaxTotalPagingResults(int var1);

	void unsetMaxTotalPagingResults();

	boolean isSetMaxTotalPagingResults();

	int getPagedCacheTimeOut();

	void setPagedCacheTimeOut(int var1);

	void unsetPagedCacheTimeOut();

	boolean isSetPagedCacheTimeOut();

	boolean isPagingCachesDiskOffLoad();

	void setPagingCachesDiskOffLoad(boolean var1);

	void unsetPagingCachesDiskOffLoad();

	boolean isSetPagingCachesDiskOffLoad();

	boolean isPagingEntityObject();

	void setPagingEntityObject(boolean var1);

	void unsetPagingEntityObject();

	boolean isSetPagingEntityObject();

	String getSearchTimeOut();

	void setSearchTimeOut(String var1);

	void unsetSearchTimeOut();

	boolean isSetSearchTimeOut();
}