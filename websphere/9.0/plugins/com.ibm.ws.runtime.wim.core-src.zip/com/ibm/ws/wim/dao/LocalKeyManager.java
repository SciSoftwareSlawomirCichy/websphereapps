package com.ibm.ws.wim.dao;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.util.DomainManagerUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;

public class LocalKeyManager {
	private static final String COPYRIGHT_NOTICE;
	public static final String CLASSNAME;
	private static final Logger trcLogger;
	private static Map<String, LocalKeyManager> singleton;
	private Hashtable dbKeys = new Hashtable();
	private Hashtable laKeys = new Hashtable();
	public static final int KEY_TYPE_DB = 1;
	public static final int KEY_TYPE_LA = 2;
	private boolean dbInit = false;
	private boolean laInit = false;
	QuerySet qs = null;
	String dbSchema = null;

	public static synchronized LocalKeyManager singleton() throws NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "singleton");
		}

		String var1 = DomainManagerUtils.getDomainId();
		if (singleton.get(var1) == null) {
			singleton.put(var1, new LocalKeyManager());
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "singleton");
		}

		return (LocalKeyManager) singleton.get(var1);
	}

	public synchronized long getDBKeyForTable(Connection var1, String var2) throws SQLException, NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getDBKeyForTable");
		}

		if (this.dbSchema != null && !this.dbSchema.trim().equals("")) {
			var2 = this.dbSchema.trim() + "." + var2;
		}

		var2 = var2.trim().toUpperCase();
		if (!this.dbInit) {
			this.initialize(var1, 1);
		}

		long[] var8 = (long[]) ((long[]) this.dbKeys.get(var2));
		long var4 = var8[0];
		long var6 = var8[1];
		if (var4 > var6) {
			var4 = this.updateKey(var1, var2, 1);
			var8 = (long[]) ((long[]) this.dbKeys.get(var2));
		}

		long var9 = var4++;
		var8[0] = var4;
		this.dbKeys.put(var2, var8);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getDBKeyForTable");
		}

		return var9;
	}

	public synchronized long getLAKeyForTable(Connection var1, String var2) throws SQLException, NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "getLAKeyForTable");
		}

		if (this.dbSchema != null && !this.dbSchema.trim().equals("")) {
			var2 = this.dbSchema.trim() + "." + var2;
		}

		var2 = var2.trim().toUpperCase();
		if (!this.laInit) {
			this.initialize(var1, 2);
		}

		long[] var8 = (long[]) ((long[]) this.laKeys.get(var2));
		long var4 = var8[0];
		long var6 = var8[1];
		if (var4 > var6) {
			var4 = this.updateKey(var1, var2, 2);
			var8 = (long[]) ((long[]) this.laKeys.get(var2));
		}

		long var9 = var4++;
		var8[0] = var4;
		this.laKeys.put(var2, var8);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "getLAKeyForTable");
		}

		return var9;
	}

	private synchronized void initialize(Connection var1, int var2) throws SQLException, NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "initialize");
		}

		long[] var4 = new long[]{0L, -1L};
		Hashtable var5 = new Hashtable();
		String var6 = null;
		String var7 = this.qs.selectDBKeys;
		if (var2 == 2) {
			var7 = this.qs.selectLAKeys;
		}

		PreparedStatement var8 = var1.prepareStatement(var7);
		ResultSet var9 = var8.executeQuery();

		while (var9.next()) {
			var6 = var9.getString("TABLENAME");
			var5.put(var6.trim().toUpperCase(), var4);
		}

		if (var2 == 1) {
			this.dbKeys = var5;
			this.dbInit = true;
		} else if (var2 == 2) {
			this.laKeys = var5;
			this.laInit = true;
		}

		if (var9 != null) {
			try {
				var9.close();
			} catch (Exception var12) {
				;
			}
		}

		if (var8 != null) {
			try {
				var8.close();
			} catch (Exception var11) {
				;
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "initialize");
		}

	}

	private long updateKey(Connection var1, String var2, int var3) throws SQLException, NamingException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateKey");
		}

		long var5 = -1L;
		long var7 = -1L;
		long var9 = -1L;
		long var11 = -1L;
		String var13 = this.qs.selectDBKeysByTable;
		if (var3 == 2) {
			var13 = this.qs.selectLAKeysByTable;
		}

		PreparedStatement var14 = var1.prepareStatement(var13);
		var14.setString(1, var2);
		ResultSet var15 = var14.executeQuery();
		if (var15.next()) {
			var5 = var15.getLong("COUNTER");
			var7 = var15.getLong("PREFETCH_SIZE");
			if (var15 != null) {
				try {
					var15.close();
				} catch (Exception var21) {
					;
				}
			}

			if (var14 != null) {
				try {
					var14.close();
				} catch (Exception var20) {
					;
				}
			}

			var9 = var5 + var7;
			var11 = var9 + 1L;
			long[] var16 = new long[]{var5, var9};
			String var17 = this.qs.updateDBKeysByTable;
			long[] var18;
			if (var3 == 1) {
				var18 = (long[]) ((long[]) this.dbKeys.get(var2));
				if (var18[0] == var11) {
					var5 = var11;
					var9 = var11 + var7;
					var11 = var9 + 1L;
					var16[0] = var5;
					var16[1] = var9;
				}

				this.dbKeys.put(var2, var16);
			} else if (var3 == 2) {
				var18 = (long[]) ((long[]) this.laKeys.get(var2));
				if (var18[0] == var11) {
					var5 = var11;
					var9 = var11 + var7;
					var11 = var9 + 1L;
					var16[0] = var5;
					var16[1] = var9;
				}

				var17 = this.qs.updateLAKeysByTable;
				this.laKeys.put(var2, var16);
			}

			try {
				PreparedStatement var23 = var1.prepareStatement(var17);
				var23.setLong(1, var11);
				var23.setString(2, var2);
				var23.executeUpdate();
				if (trcLogger.isLoggable(Level.FINER)) {
					StringBuffer var19 = new StringBuffer();
					var19.append("Update Key: Query=").append(var17).append(", table=").append(var2)
							.append(", nextValue=").append(var11);
					trcLogger.logp(Level.FINER, CLASSNAME, "updateKey", var19.toString());
				}
			} catch (Exception var22) {
				throw new SQLException(var22.toString());
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.entering(CLASSNAME, "updateKey");
			}

			return var5;
		} else {
			throw new SQLException("Key not found");
		}
	}

	public void setQuerySet(QuerySet var1) {
		this.qs = var1;
	}

	public void setSchema(String var1) {
		this.dbSchema = var1;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = LocalKeyManager.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		singleton = Collections.synchronizedMap(new HashMap());
	}
}