package com.ibm.ffdc;

import java.util.ListResourceBundle;

public class FFDCBundleMessages_pt_BR extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"FFDCAddedFormatter", "FFDC1005I: Formatador do FFDC Incluído {0}"},
			{"FFDCAnalysisEngineUsing", "FFDC1009I: Mecanismo de Análise que usa o banco de dados: {0}"},
			{"FFDCAnalysisEngineUsingE", "FFDC1010W: Falha ao resolver o Mecanismo de Análise:"},
			{"FFDCDataCollectorAdded", "FFDC1011I: Coletor de Dados FFDC Incluído {0}"},
			{"FFDCDataCollectorRemoved", "FFDC1012I: Coletor de Dados FFDC Removido {0}"},
			{"FFDCEmittedOnSysErr", "FFDC1004I: Incidente de FFDC emitido no SystemErr: {0} {1}"},
			{"FFDCFailSafeErrChk", "FFDC1002W: FFDC no modo failsafe, verifique os erros {0}"},
			{"FFDCForwarderAdded", "FFDC1013I: Encaminhador de Incidente de FFDC Incluído {0}"},
			{"FFDCForwarderRemoved", "FFDC1014I: Encaminhador de Incidente de FFDC Removido {0}"},
			{"FFDCIncidentEmitted", "FFDC1003I: Incidente de FFDC emitido em {0} {1} {2}"},
			{"FFDCProviderAborted", "FFDC1000I: Provedor FFDC {0} interrompido, Exceção a seguir"},
			{"FFDCProviderAbortedE", "FFDC1001I: O provedor FFDC foi interrompido com a exceção {0}"},
			{"FFDCProviderException", "FFDC1008I: Exceção do Provedor FFDC:"},
			{"FFDCProviderInstalled", "FFDC1007I: Provedor FFDC Instalado: {0}"},
			{"FFDCRemovedFormatter", "FFDC1006I: Formatador do FFDC Removido {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}