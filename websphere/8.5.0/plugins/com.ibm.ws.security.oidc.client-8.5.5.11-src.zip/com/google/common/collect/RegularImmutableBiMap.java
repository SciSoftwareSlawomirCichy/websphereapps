package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.collect.RegularImmutableBiMap.1;
import com.google.common.collect.RegularImmutableBiMap.BiMapEntry;
import com.google.common.collect.RegularImmutableBiMap.Inverse;
import com.google.common.collect.RegularImmutableBiMap.NonTerminalBiMapEntry;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;
import javax.annotation.Nullable;

@GwtCompatible(serializable = true, emulated = true)
class RegularImmutableBiMap<K, V> extends ImmutableBiMap<K, V> {
	static final double MAX_LOAD_FACTOR = 1.2D;
	private final transient BiMapEntry<K, V>[] kToVTable;
	private final transient BiMapEntry<K, V>[] vToKTable;
	private final transient BiMapEntry<K, V>[] entries;
	private final transient int mask;
	private final transient int hashCode;
	private transient ImmutableBiMap<V, K> inverse;

	RegularImmutableBiMap(Collection<? extends Entry<? extends K, ? extends V>> entriesToAdd) {
		int n = entriesToAdd.size();
		int tableSize = Hashing.closedTableSize(n, 1.2D);
		this.mask = tableSize - 1;
		BiMapEntry<K, V>[] kToVTable = createEntryArray(tableSize);
		BiMapEntry<K, V>[] vToKTable = createEntryArray(tableSize);
		BiMapEntry<K, V>[] entries = createEntryArray(n);
		int i = 0;
		int hashCode = 0;

		int keyHash;
		int valueHash;
		for (Iterator i$ = entriesToAdd.iterator(); i$.hasNext(); hashCode += keyHash ^ valueHash) {
			Entry<? extends K, ? extends V> entry = (Entry) i$.next();
			K key = Preconditions.checkNotNull(entry.getKey());
			V value = Preconditions.checkNotNull(entry.getValue());
			keyHash = key.hashCode();
			valueHash = value.hashCode();
			int keyBucket = Hashing.smear(keyHash) & this.mask;
			int valueBucket = Hashing.smear(valueHash) & this.mask;
			BiMapEntry<K, V> nextInKToVBucket = kToVTable[keyBucket];

			BiMapEntry nextInVToKBucket;
			for (nextInVToKBucket = nextInKToVBucket; nextInVToKBucket != null; nextInVToKBucket = nextInVToKBucket
					.getNextInKToVBucket()) {
				if (key.equals(nextInVToKBucket.getKey())) {
					throw new IllegalArgumentException(
							"Multiple entries with same key: " + entry + " and " + nextInVToKBucket);
				}
			}

			nextInVToKBucket = vToKTable[valueBucket];

			for (BiMapEntry vToKEntry = nextInVToKBucket; vToKEntry != null; vToKEntry = vToKEntry
					.getNextInVToKBucket()) {
				if (value.equals(vToKEntry.getValue())) {
					throw new IllegalArgumentException(
							"Multiple entries with same value: " + entry + " and " + vToKEntry);
				}
			}

			BiMapEntry<K, V> newEntry = nextInKToVBucket == null && nextInVToKBucket == null
					? new BiMapEntry(key, value)
					: new NonTerminalBiMapEntry(key, value, nextInKToVBucket, nextInVToKBucket);
			kToVTable[keyBucket] = (BiMapEntry) newEntry;
			vToKTable[valueBucket] = (BiMapEntry) newEntry;
			entries[i++] = (BiMapEntry) newEntry;
		}

		this.kToVTable = kToVTable;
		this.vToKTable = vToKTable;
		this.entries = entries;
		this.hashCode = hashCode;
	}

	private static <K, V> BiMapEntry<K, V>[] createEntryArray(int length) {
		return new BiMapEntry[length];
	}

	@Nullable
	public V get(@Nullable Object key) {
		if (key == null) {
			return null;
		} else {
			int bucket = Hashing.smear(key.hashCode()) & this.mask;

			for (BiMapEntry entry = this.kToVTable[bucket]; entry != null; entry = entry.getNextInKToVBucket()) {
				if (key.equals(entry.getKey())) {
					return entry.getValue();
				}
			}

			return null;
		}
	}

	ImmutableSet<Entry<K, V>> createEntrySet() {
      return new 1(this);
   }

	boolean isPartialView() {
		return false;
	}

	public int size() {
		return this.entries.length;
	}

	public ImmutableBiMap<V, K> inverse() {
      ImmutableBiMap<V, K> result = this.inverse;
      return result == null ? (this.inverse = new Inverse(this, (1)null)) : result;
   }
}