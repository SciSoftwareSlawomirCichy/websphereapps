package com.ibm.ws.wim.adapter.ldap;

import com.ibm.websphere.wim.exception.MissingInitPropertyException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.ws.wim.util.NodeHelper;
import commonj.sdo.DataObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;
import javax.naming.directory.Attribute;
import javax.naming.directory.BasicAttribute;

public class LdapEntity {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private static final String CLASSNAME = LdapEntity.class.getName();
	private static final Logger trcLogger;
	private String iQEntityType = null;
	private String[][] iWIMRDNProps = (String[][]) null;
	private String[][] iWIMRDNAttrs = (String[][]) null;
	private String[][] iRDNAttrs = (String[][]) null;
	private String[] iRDNObjectClass = null;
	private List iObjectClasses = null;
	private Attribute[] iObjectClassAttrs = null;
	private String[] iSearchBases = null;
	private boolean iSearchBaseConfigured = false;
	private List iSearchBaseList = null;
	private String iSearchFilter = null;
	private Set iProps = null;
	private Map iPropToAttrMap = null;
	private Map iAttrToPropMap = null;
	private String iExtId = null;
	private boolean iTranslatedRDN = false;
	private Set iAttrs = null;

	public LdapEntity(DataObject var1) throws WIMException {
		this.iQEntityType = var1.getString("name");
		this.setRDNAttributes(var1.getList("rdnAttributes"));
		this.setObjectClasses(var1.getList("objectClasses"));
		this.setObjectClassesForCreate(var1.getList("objectClassesForCreate"));
		this.setSearchBases(var1.getList("searchBases"));
		if (this.getSearchBases() == null) {
			this.iSearchBaseConfigured = false;
		} else {
			this.iSearchBaseConfigured = true;
		}

		this.setSearchFilter(var1.getString("searchFilter"));
		this.iAttrToPropMap = new Hashtable();
		this.iPropToAttrMap = new Hashtable();
		this.iAttrs = new HashSet();
		this.iProps = new HashSet();
	}

	public LdapEntity(String var1) throws WIMException {
		this.iQEntityType = var1;
		this.iAttrToPropMap = new Hashtable();
		this.iPropToAttrMap = new Hashtable();
		this.iAttrs = new HashSet();
		this.iProps = new HashSet();
	}

	public String getName() {
		return this.iQEntityType;
	}

	public void setObjectClasses(List var1) {
		int var2 = var1.size();
		this.iObjectClasses = new ArrayList(var1.size());

		for (int var3 = 0; var3 < var2; ++var3) {
			String var4 = ((String) var1.get(var3)).toLowerCase();
			if (!this.iObjectClasses.contains(var4)) {
				this.iObjectClasses.add(var4);
			}
		}

	}

	public void setObjectClassesForCreate(List var1) {
		int var2;
		if (this.iRDNObjectClass != null && this.iRDNObjectClass.length > 1) {
			this.iObjectClassAttrs = new Attribute[this.iRDNObjectClass.length];

			for (var2 = 0; var2 < this.iRDNObjectClass.length; ++var2) {
				this.iObjectClassAttrs[var2] = new BasicAttribute("objectClass", this.iRDNObjectClass[var2]);
				var1.remove(this.iRDNObjectClass[var2]);
			}

			for (var2 = 0; var2 < this.iObjectClassAttrs.length; ++var2) {
				for (int var3 = 0; var3 < var1.size(); ++var3) {
					this.iObjectClassAttrs[var2].add(var1.get(var3));
				}
			}
		} else {
			this.iObjectClassAttrs = new Attribute[1];
			this.iObjectClassAttrs[0] = new BasicAttribute("objectClass");
			if (var1.size() > 0) {
				for (var2 = 0; var2 < var1.size(); ++var2) {
					this.iObjectClassAttrs[0].add(var1.get(var2));
				}
			} else {
				for (var2 = 0; var2 < this.iObjectClasses.size(); ++var2) {
					this.iObjectClassAttrs[0].add((String) this.iObjectClasses.get(var2));
				}
			}
		}

	}

	public Attribute getObjectClassAttribute(String var1) {
		if (this.iObjectClassAttrs.length != 1 && var1 != null) {
			String[] var2 = LdapHelper.getRDNAttributes(var1);

			for (int var3 = 0; var3 < this.iRDNAttrs.length; ++var3) {
				String[] var4 = this.iRDNAttrs[var3];

				for (int var5 = 0; var5 < var4.length; ++var5) {
					for (int var6 = 0; var6 < var4.length; ++var6) {
						if (var4[var5].equals(var2[var6])) {
							return this.iObjectClassAttrs[var3];
						}
					}
				}
			}

			return null;
		} else {
			return this.iObjectClassAttrs[0];
		}
	}

	public boolean startWithSameRDN(String var1) {
		var1 = var1.toLowerCase();
		String[][] var2 = this.iRDNAttrs != null ? this.iRDNAttrs : this.iWIMRDNAttrs;

		for (int var3 = 0; var3 < var2.length; ++var3) {
			String[] var4 = var2[var3];

			for (int var5 = 0; var5 < var4.length; ++var5) {
				if (var1.startsWith(var4[var5])) {
					return true;
				}
			}
		}

		return false;
	}

	public List getObjectClasses() {
		return this.iObjectClasses;
	}

	public String[][] getRDNAttributes() {
		return this.iRDNAttrs == null ? this.iWIMRDNAttrs : this.iRDNAttrs;
	}

	public List getRDNAttributesList() {
		String[][] var1 = this.getRDNAttributes();
		ArrayList var2 = new ArrayList();

		for (int var3 = 0; var3 < var1.length; ++var3) {
			for (int var4 = 0; var4 < var1[var3].length; ++var4) {
				var2.add(var1[var3][var4]);
			}
		}

		return var2;
	}

	public String[][] getWIMRDNAttributes() {
		return this.iWIMRDNAttrs;
	}

	public String[][] getWIMRDNProperties() {
		return this.iWIMRDNProps;
	}

	public void setRDNAttributes(String[][] var1, String[] var2) {
		this.iRDNAttrs = var1;
		this.iRDNObjectClass = var2;
	}

	public void setRDNAttributes(List var1) throws MissingInitPropertyException {
		int var3 = var1.size();
		if (var3 > 0) {
			this.iRDNAttrs = new String[var3][];
			this.iRDNObjectClass = new String[var3];
			if (var3 == 1) {
				DataObject var4 = (DataObject) var1.get(0);
				String[] var5 = LdapHelper.getRDNs(var4.getString("name"));
				this.iRDNAttrs[0] = var5;
			} else {
				for (int var9 = 0; var9 < var1.size(); ++var9) {
					DataObject var10 = (DataObject) var1.get(var9);
					String var6 = var10.getString("name");
					String[] var7 = LdapHelper.getRDNs(var10.getString("name"));
					this.iRDNAttrs[var9] = var7;
					String var8 = var10.getString("objectClass");
					if (var8 == null) {
						throw new MissingInitPropertyException("MISSING_INI_PROPERTY",
								WIMMessageHelper.generateMsgParms("objectClass"), CLASSNAME, "setRDNAttributes");
					}

					this.iRDNObjectClass[var9] = var8.toLowerCase();
				}
			}
		}

	}

	public void setSearchBases(List var1) {
		if (var1.size() > 0) {
			this.iSearchBases = new String[0];
			this.iSearchBases = (String[]) ((String[]) var1.toArray(this.iSearchBases));
			this.iSearchBases = NodeHelper.getTopNodes(this.iSearchBases);
			this.iSearchBaseList = new ArrayList(this.iSearchBases.length);

			for (int var2 = 0; var2 < this.iSearchBases.length; ++var2) {
				this.iSearchBaseList.add(this.iSearchBases[var2]);
			}
		}

	}

	public void setSearchBases(String[] var1) {
		this.iSearchBases = var1;
		this.iSearchBaseList = new ArrayList(this.iSearchBases.length);

		for (int var2 = 0; var2 < this.iSearchBases.length; ++var2) {
			this.iSearchBaseList.add(this.iSearchBases[var2]);
		}

	}

	public String[] getSearchBases() {
		return this.iSearchBases;
	}

	public boolean isSearchBaseConfigured() {
		return this.iSearchBaseConfigured;
	}

	public List getSearchBaseList() {
		return this.iSearchBaseList;
	}

	public void setSearchFilter(String var1) {
		if (var1 != null && var1.trim().length() > 0) {
			var1 = var1.trim();
			if (var1.length() > 0) {
				if (var1.charAt(0) != '(' || var1.charAt(var1.length() - 1) != ')') {
					var1 = "(" + var1 + ")";
				}

				this.iSearchFilter = var1;
			}
		} else {
			int var3 = this.iObjectClasses.size();
			StringBuffer var4 = new StringBuffer(var3 * 20);
			if (var3 > 1) {
				var4.append("(|");
			}

			for (int var5 = 0; var5 < var3; ++var5) {
				var4.append("(").append("objectClass").append("=").append(this.iObjectClasses.get(var5)).append(")");
			}

			if (var3 > 1) {
				var4.append(")");
			}

			this.iSearchFilter = var4.toString();
		}

	}

	public String getSearchFilter() {
		return this.iSearchFilter;
	}

	public Set getProperty(String var1) {
		return (Set) this.iAttrToPropMap.get(var1.toLowerCase());
	}

	public String getAttribute(String var1) {
		Object var2 = this.iPropToAttrMap.get(var1);
		return var2 != null ? (String) var2 : null;
	}

	public void addPropertyAttributeMap(String var1, String var2) {
		String var3 = var1;
		if (var1.equalsIgnoreCase("ibm-primaryEmail")) {
			var3 = "ibmPrimaryEmail";
		} else if (var1.equalsIgnoreCase("ibm-jobTitle")) {
			var3 = "ibmJobTitle";
		}

		if (var1.equalsIgnoreCase("ibmPrimaryEmail") && var2.equalsIgnoreCase("ibmPrimaryEmail")) {
			var2 = "ibm-primaryEmail";
		}

		if (var1.equalsIgnoreCase("ibmJobTitle") && var2.equalsIgnoreCase("ibmJobTitle")) {
			var2 = "ibm-jobTitle";
		}

		if (!var1.equalsIgnoreCase("ibm-primaryEmail") && !var1.equalsIgnoreCase("ibm-jobTitle")) {
			this.iPropToAttrMap.put(var3, var2);
		} else {
			this.iPropToAttrMap.put(var3, var2);
			this.iPropToAttrMap.put(var1, var2);
		}

		String var4 = var2.toLowerCase();
		Object var5 = (Set) this.iAttrToPropMap.get(var4);
		if (var5 == null) {
			var5 = new HashSet();
			this.iAttrToPropMap.put(var4, var5);
		}

		if (!var1.equalsIgnoreCase("ibm-primaryEmail") && !var1.equalsIgnoreCase("ibm-jobTitle")) {
			((Set) var5).add(var3);
			this.addProperty(var3);
		} else {
			((Set) var5).add(var3);
			((Set) var5).add(var1);
			this.addProperty(var1);
			this.addProperty(var3);
		}

		this.addAttribute(var2);
	}

	public void setExtId(String var1) {
		this.iExtId = var1;
	}

	public String getExtId() {
		return this.iExtId;
	}

	public void setRDNProperties(String[][] var1, String[][] var2) {
		this.iWIMRDNAttrs = var2;
		this.iWIMRDNProps = var1;
		int var3;
		if (this.iRDNAttrs != null) {
			if (this.iRDNAttrs.length != this.iWIMRDNAttrs.length) {
				this.iTranslatedRDN = true;
				return;
			}

			for (var3 = 0; var3 < this.iRDNAttrs.length; ++var3) {
				if (!Arrays.equals(this.iRDNAttrs[var3], this.iWIMRDNAttrs[var3])) {
					this.iTranslatedRDN = true;
					return;
				}
			}
		} else {
			for (var3 = 0; var3 < this.iWIMRDNAttrs.length; ++var3) {
				if (!Arrays.equals(this.iWIMRDNAttrs[var3], this.iWIMRDNProps[var3])) {
					this.iTranslatedRDN = true;
					return;
				}
			}
		}

	}

	public void addObjectClass(String var1) {
		var1 = var1.toLowerCase();
		if (!this.iObjectClasses.contains(var1)) {
			this.iObjectClasses.add(var1);
		}

	}

	private void addAttribute(String var1) {
		this.iAttrs.add(var1);
	}

	private void addProperty(String var1) {
		this.iProps.add(var1);
	}

	public Set getAttributes() {
		return this.iAttrs;
	}

	public Set getProperties() {
		return this.iProps;
	}

	public boolean needTranslateRDN() {
		return this.iTranslatedRDN;
	}

	public String toString() {
		StringBuffer var1 = new StringBuffer();
		var1.append("\nEntityType: ").append(this.iQEntityType).append("\n");
		var1.append("\tWIMRDNProps: ").append(WIMTraceHelper.printObjectArray(this.iWIMRDNProps)).append("\n");
		var1.append("\tWIMRDNAttrs: ").append(WIMTraceHelper.printObjectArray(this.iWIMRDNAttrs)).append("\n");
		var1.append("\tRDNAttrs: ").append(WIMTraceHelper.printObjectArray(this.iRDNAttrs)).append("\n");
		var1.append("\tRDNObjectClasses: ").append(WIMTraceHelper.printObjectArray(this.iRDNObjectClass)).append("\n");
		var1.append("\tNeedTranslateRDN: ").append(this.iTranslatedRDN).append("\n");
		var1.append("\tObjectClasses: ").append(this.iObjectClasses).append("\n");
		var1.append("\tObjectClassesForCreate: ").append(WIMTraceHelper.printObjectArray(this.iObjectClassAttrs))
				.append("\n");
		var1.append("\tSearchBases: ").append(WIMTraceHelper.printObjectArray(this.iSearchBases)).append("\n");
		var1.append("\tSearchFilter: ").append(this.iSearchFilter).append("\n");
		var1.append("\tPropToAttrMap: ").append(this.iPropToAttrMap).append("\n");
		var1.append("\tAttrToPropMap: ").append(this.iAttrToPropMap).append("\n");
		var1.append("\tExtIdAttr: ").append(this.iExtId).append("\n");
		var1.append("\tAttributes: ").append(this.iAttrs).append("\n");
		return var1.toString();
	}

	static {
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}