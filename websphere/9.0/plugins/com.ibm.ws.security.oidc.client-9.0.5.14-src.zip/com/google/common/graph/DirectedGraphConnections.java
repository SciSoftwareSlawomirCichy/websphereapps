package com.google.common.graph;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import com.google.common.graph.DirectedGraphConnections.1;
import com.google.common.graph.DirectedGraphConnections.2;
import com.google.common.graph.DirectedGraphConnections.PredAndSucc;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

final class DirectedGraphConnections<N, V> implements GraphConnections<N, V> {
	private static final Object PRED = new Object();
	private final Map<N, Object> adjacentNodeValues;
	private int predecessorCount;
	private int successorCount;

	private DirectedGraphConnections(Map<N, Object> adjacentNodeValues, int predecessorCount, int successorCount) {
		this.adjacentNodeValues = (Map) Preconditions.checkNotNull(adjacentNodeValues);
		this.predecessorCount = Graphs.checkNonNegative(predecessorCount);
		this.successorCount = Graphs.checkNonNegative(successorCount);
		Preconditions.checkState(
				predecessorCount <= adjacentNodeValues.size() && successorCount <= adjacentNodeValues.size());
	}

	static <N, V> DirectedGraphConnections<N, V> of() {
		int initialCapacity = 4;
		return new DirectedGraphConnections(new HashMap(initialCapacity, 1.0F), 0, 0);
	}

	static <N, V> DirectedGraphConnections<N, V> ofImmutable(Set<N> predecessors, Map<N, V> successorValues) {
		Map<N, Object> adjacentNodeValues = new HashMap();
		adjacentNodeValues.putAll(successorValues);
		Iterator var3 = predecessors.iterator();

		while (var3.hasNext()) {
			N predecessor = var3.next();
			Object value = adjacentNodeValues.put(predecessor, PRED);
			if (value != null) {
				adjacentNodeValues.put(predecessor, new PredAndSucc(value));
			}
		}

		return new DirectedGraphConnections(ImmutableMap.copyOf(adjacentNodeValues), predecessors.size(),
				successorValues.size());
	}

	public Set<N> adjacentNodes() {
		return Collections.unmodifiableSet(this.adjacentNodeValues.keySet());
	}

	public Set<N> predecessors() {
      return new 1(this);
   }

	public Set<N> successors() {
      return new 2(this);
   }

	public V value(N node) {
		Object value = this.adjacentNodeValues.get(node);
		if (value == PRED) {
			return null;
		} else {
			return value instanceof PredAndSucc ? PredAndSucc.access$500((PredAndSucc) value) : value;
		}
	}

	public void removePredecessor(N node) {
		Object previousValue = this.adjacentNodeValues.get(node);
		if (previousValue == PRED) {
			this.adjacentNodeValues.remove(node);
			Graphs.checkNonNegative(--this.predecessorCount);
		} else if (previousValue instanceof PredAndSucc) {
			this.adjacentNodeValues.put(node, PredAndSucc.access$500((PredAndSucc) previousValue));
			Graphs.checkNonNegative(--this.predecessorCount);
		}

	}

	public V removeSuccessor(Object node) {
		Object previousValue = this.adjacentNodeValues.get(node);
		if (previousValue != null && previousValue != PRED) {
			if (previousValue instanceof PredAndSucc) {
				this.adjacentNodeValues.put(node, PRED);
				Graphs.checkNonNegative(--this.successorCount);
				return PredAndSucc.access$500((PredAndSucc) previousValue);
			} else {
				this.adjacentNodeValues.remove(node);
				Graphs.checkNonNegative(--this.successorCount);
				return previousValue;
			}
		} else {
			return null;
		}
	}

	public void addPredecessor(N node, V unused) {
		Object previousValue = this.adjacentNodeValues.put(node, PRED);
		if (previousValue == null) {
			Graphs.checkPositive(++this.predecessorCount);
		} else if (previousValue instanceof PredAndSucc) {
			this.adjacentNodeValues.put(node, previousValue);
		} else if (previousValue != PRED) {
			this.adjacentNodeValues.put(node, new PredAndSucc(previousValue));
			Graphs.checkPositive(++this.predecessorCount);
		}

	}

	public V addSuccessor(N node, V value) {
		Object previousValue = this.adjacentNodeValues.put(node, value);
		if (previousValue == null) {
			Graphs.checkPositive(++this.successorCount);
			return null;
		} else if (previousValue instanceof PredAndSucc) {
			this.adjacentNodeValues.put(node, new PredAndSucc(value));
			return PredAndSucc.access$500((PredAndSucc) previousValue);
		} else if (previousValue == PRED) {
			this.adjacentNodeValues.put(node, new PredAndSucc(value));
			Graphs.checkPositive(++this.successorCount);
			return null;
		} else {
			return previousValue;
		}
	}

	private static boolean isPredecessor(@NullableDecl Object value) {
		return value == PRED || value instanceof PredAndSucc;
	}

	private static boolean isSuccessor(@NullableDecl Object value) {
		return value != PRED && value != null;
	}
}