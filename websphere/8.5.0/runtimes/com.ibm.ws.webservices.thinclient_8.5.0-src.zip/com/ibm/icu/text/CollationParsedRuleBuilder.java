package com.ibm.icu.text;

import com.ibm.icu.impl.IntTrieBuilder;
import com.ibm.icu.impl.Norm2AllModes;
import com.ibm.icu.impl.Normalizer2Impl;
import com.ibm.icu.impl.TrieIterator;
import com.ibm.icu.impl.UCharacterProperty;
import com.ibm.icu.impl.Utility;
import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.CollationParsedRuleBuilder.BasicContractionTable;
import com.ibm.icu.text.CollationParsedRuleBuilder.BuildTable;
import com.ibm.icu.text.CollationParsedRuleBuilder.CEGenerator;
import com.ibm.icu.text.CollationParsedRuleBuilder.CombinClassTable;
import com.ibm.icu.text.CollationParsedRuleBuilder.ContractionTable;
import com.ibm.icu.text.CollationParsedRuleBuilder.Elements;
import com.ibm.icu.text.CollationParsedRuleBuilder.InverseUCA;
import com.ibm.icu.text.CollationParsedRuleBuilder.MaxExpansionTable;
import com.ibm.icu.text.CollationParsedRuleBuilder.MaxJamoExpansionTable;
import com.ibm.icu.text.CollationParsedRuleBuilder.WeightRange;
import com.ibm.icu.text.CollationRuleParser.OptionSet;
import com.ibm.icu.text.CollationRuleParser.Token;
import com.ibm.icu.text.CollationRuleParser.TokenListHeader;
import com.ibm.icu.text.RuleBasedCollator.DataManipulate;
import com.ibm.icu.util.RangeValueIterator;
import com.ibm.icu.util.RangeValueIterator.Element;
import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Vector;

final class CollationParsedRuleBuilder {
	static final InverseUCA INVERSE_UCA_;
	private static final String INV_UCA_VERSION_MISMATCH_ = "UCA versions of UCA and inverse UCA should match";
	private static final String UCA_NOT_INSTANTIATED_ = "UCA is not instantiated!";
	private static final int CE_BASIC_STRENGTH_LIMIT_ = 3;
	private static final int CE_STRENGTH_LIMIT_ = 16;
	private static final int[] STRENGTH_MASK_;
	private static final int CE_NOT_FOUND_ = -268435456;
	private static final int CE_NOT_FOUND_TAG_ = 0;
	private static final int CE_EXPANSION_TAG_ = 1;
	private static final int CE_CONTRACTION_TAG_ = 2;
	private static final int CE_SURROGATE_TAG_ = 5;
	private static final int CE_IMPLICIT_TAG_ = 10;
	private static final int CE_SPEC_PROC_TAG_ = 11;
	private static final int CE_LONG_PRIMARY_TAG_ = 12;
	private static final int UNSAFECP_TABLE_SIZE_ = 1056;
	private static final int UNSAFECP_TABLE_MASK_ = 8191;
	private static final int UPPER_CASE_ = 128;
	private static final int MIXED_CASE_ = 64;
	private static final int LOWER_CASE_ = 0;
	private static final int CONTRACTION_TABLE_NEW_ELEMENT_ = 16777215;
	private CollationRuleParser m_parser_;
	private CollationElementIterator m_utilColEIter_;
	private CEGenerator[] m_utilGens_ = new CEGenerator[]{new CEGenerator(), new CEGenerator(), new CEGenerator()};
	private int[] m_utilCEBuffer_ = new int[3];
	private int[] m_utilIntBuffer_ = new int[16];
	private Elements m_utilElement_ = new Elements();
	private Elements m_utilElement2_ = new Elements();
	private Token m_utilToken_ = new Token();
	private int[] m_utilCountBuffer_ = new int[6];
	private long[] m_utilLongBuffer_ = new long[5];
	private WeightRange[] m_utilLowerWeightRange_ = new WeightRange[]{new WeightRange(), new WeightRange(),
			new WeightRange(), new WeightRange(), new WeightRange()};
	private WeightRange[] m_utilUpperWeightRange_ = new WeightRange[]{new WeightRange(), new WeightRange(),
			new WeightRange(), new WeightRange(), new WeightRange()};
	private WeightRange m_utilWeightRange_ = new WeightRange();
	private final Normalizer2Impl m_nfcImpl_;
	private CanonicalIterator m_utilCanIter_;
	private StringBuilder m_utilStringBuffer_;
	private static boolean buildCMTabFlag;

	CollationParsedRuleBuilder(String rules) throws ParseException {
		this.m_nfcImpl_ = Norm2AllModes.getNFCInstance().impl;
		this.m_utilCanIter_ = new CanonicalIterator("");
		this.m_utilStringBuffer_ = new StringBuilder("");
		this.m_parser_ = new CollationRuleParser(rules);
		this.m_parser_.assembleTokenList();
		this.m_utilColEIter_ = RuleBasedCollator.UCA_.getCollationElementIterator("");
	}

	void setRules(RuleBasedCollator collator) throws Exception {
		if (this.m_parser_.m_resultLength_ <= 0 && this.m_parser_.m_removeSet_ == null) {
			collator.setWithUCATables();
		} else {
			this.assembleTailoringTable(collator);
		}

		this.m_parser_.setDefaultOptionsInCollator(collator);
	}

	private void copyRangeFromUCA(BuildTable t, int start, int end) {
		int u = false;

		for (int u = start; u <= end; ++u) {
			int CE = t.m_mapping_.getValue(u);
			if (CE == -268435456 || isContractionTableElement(CE) && getCE(t.m_contractions_, CE, 0) == -268435456) {
				this.m_utilElement_.m_uchars_ = UCharacter.toString(u);
				this.m_utilElement_.m_cPoints_ = this.m_utilElement_.m_uchars_;
				this.m_utilElement_.m_prefix_ = 0;
				this.m_utilElement_.m_CELength_ = 0;
				this.m_utilElement_.m_prefixChars_ = null;
				this.m_utilColEIter_.setText(this.m_utilElement_.m_uchars_);

				while (CE != -1) {
					CE = this.m_utilColEIter_.next();
					if (CE != -1) {
						this.m_utilElement_.m_CEs_[this.m_utilElement_.m_CELength_++] = CE;
					}
				}

				this.addAnElement(t, this.m_utilElement_);
			}
		}

	}

	void assembleTailoringTable(RuleBasedCollator collator) throws Exception {
		for (int i = 0; i < this.m_parser_.m_resultLength_; ++i) {
			if (this.m_parser_.m_listHeader_[i].m_first_ != null) {
				this.initBuffers(this.m_parser_.m_listHeader_[i]);
			}
		}

		if (this.m_parser_.m_variableTop_ != null) {
			this.m_parser_.m_options_.m_variableTopValue_ = this.m_parser_.m_variableTop_.m_CE_[0] >>> 16;
			if (this.m_parser_.m_variableTop_.m_listHeader_.m_first_ == this.m_parser_.m_variableTop_) {
				this.m_parser_.m_variableTop_.m_listHeader_.m_first_ = this.m_parser_.m_variableTop_.m_next_;
			}

			if (this.m_parser_.m_variableTop_.m_listHeader_.m_last_ == this.m_parser_.m_variableTop_) {
				this.m_parser_.m_variableTop_.m_listHeader_.m_last_ = this.m_parser_.m_variableTop_.m_previous_;
			}

			if (this.m_parser_.m_variableTop_.m_next_ != null) {
				this.m_parser_.m_variableTop_.m_next_.m_previous_ = this.m_parser_.m_variableTop_.m_previous_;
			}

			if (this.m_parser_.m_variableTop_.m_previous_ != null) {
				this.m_parser_.m_variableTop_.m_previous_.m_next_ = this.m_parser_.m_variableTop_.m_next_;
			}
		}

		BuildTable t = new BuildTable(this.m_parser_);

		for (int i = 0; i < this.m_parser_.m_resultLength_; ++i) {
			this.createElements(t, this.m_parser_.m_listHeader_[i]);
		}

		this.m_utilElement_.clear();
		StringBuilder str = new StringBuilder();
		this.copyRangeFromUCA(t, 0, 255);
		if (this.m_parser_.m_copySet_ != null) {
			int i = false;

			for (int i = 0; i < this.m_parser_.m_copySet_.getRangeCount(); ++i) {
				this.copyRangeFromUCA(t, this.m_parser_.m_copySet_.getRangeStart(i),
						this.m_parser_.m_copySet_.getRangeEnd(i));
			}
		}

		char[] conts = RuleBasedCollator.UCA_CONTRACTIONS_;

		for (int offset = 0; conts[offset] != 0; offset += 3) {
			int tailoredCE = t.m_mapping_.getValue(conts[offset]);
			Elements prefixElm = null;
			if (tailoredCE != -268435456) {
				boolean needToAdd = true;
				if (isContractionTableElement(tailoredCE)
						&& isTailored(t.m_contractions_, tailoredCE, conts, offset + 1)) {
					needToAdd = false;
				}

				if (!needToAdd && isPrefix(tailoredCE) && conts[offset + 1] == 0) {
					Elements elm = new Elements();
					elm.m_cPoints_ = this.m_utilElement_.m_uchars_;
					elm.m_CELength_ = 0;
					elm.m_uchars_ = UCharacter.toString(conts[offset]);
					elm.m_prefixChars_ = UCharacter.toString(conts[offset + 2]);
					elm.m_prefix_ = 0;
					prefixElm = (Elements) t.m_prefixLookup_.get(elm);
					if (prefixElm == null || prefixElm.m_prefixChars_.charAt(0) != conts[offset + 2]) {
						needToAdd = true;
					}
				}

				if (this.m_parser_.m_removeSet_ != null && this.m_parser_.m_removeSet_.contains(conts[offset])) {
					needToAdd = false;
				}

				if (needToAdd) {
					int CE;
					if (conts[offset + 1] != 0) {
						this.m_utilElement_.m_prefix_ = 0;
						this.m_utilElement_.m_prefixChars_ = null;
						this.m_utilElement_.m_cPoints_ = this.m_utilElement_.m_uchars_;
						str.delete(0, str.length());
						str.append(conts[offset]);
						str.append(conts[offset + 1]);
						if (conts[offset + 2] != 0) {
							str.append(conts[offset + 2]);
						}

						this.m_utilElement_.m_uchars_ = str.toString();
						this.m_utilElement_.m_CELength_ = 0;
						this.m_utilColEIter_.setText(this.m_utilElement_.m_uchars_);
					} else {
						CE = 0;
						str.delete(0, str.length());
						this.m_utilElement_.m_cPoints_ = UCharacter.toString(conts[offset]);
						this.m_utilElement_.m_CELength_ = 0;
						this.m_utilElement_.m_uchars_ = UCharacter.toString(conts[offset]);
						this.m_utilElement_.m_prefixChars_ = UCharacter.toString(conts[offset + 2]);
						if (prefixElm == null) {
							this.m_utilElement_.m_prefix_ = 0;
						} else {
							this.m_utilElement_.m_prefix_ = this.m_utilElement_.m_prefix_;
						}

						this.m_utilColEIter_.setText(this.m_utilElement_.m_prefixChars_);

						while (this.m_utilColEIter_.next() != -1) {
							++CE;
						}

						str.append(conts[offset + 2]);
						str.append(conts[offset]);
						this.m_utilColEIter_.setText(str.toString());

						while (CE-- > 0 && this.m_utilColEIter_.next() != -1) {
							;
						}
					}

					while (true) {
						CE = this.m_utilColEIter_.next();
						if (CE == -1) {
							this.addAnElement(t, this.m_utilElement_);
							break;
						}

						this.m_utilElement_.m_CEs_[this.m_utilElement_.m_CELength_++] = CE;
					}
				}
			} else if (this.m_parser_.m_removeSet_ != null && this.m_parser_.m_removeSet_.contains(conts[offset])) {
				this.copyRangeFromUCA(t, conts[offset], conts[offset]);
			}
		}

		this.processUCACompleteIgnorables(t);
		this.canonicalClosure(t);
		this.assembleTable(t, collator);
	}

	private void initBuffers(TokenListHeader listheader) throws Exception {
		Token token = listheader.m_last_;
		Arrays.fill(this.m_utilIntBuffer_, 0, 16, 0);
		token.m_toInsert_ = 1;

		for (this.m_utilIntBuffer_[token.m_strength_] = 1; token.m_previous_ != null; token.m_toInsert_ = this.m_utilIntBuffer_[token.m_strength_]) {
			if (token.m_previous_.m_strength_ < token.m_strength_) {
				this.m_utilIntBuffer_[token.m_strength_] = 0;
				++this.m_utilIntBuffer_[token.m_previous_.m_strength_];
			} else if (token.m_previous_.m_strength_ > token.m_strength_) {
				this.m_utilIntBuffer_[token.m_previous_.m_strength_] = 1;
			} else {
				++this.m_utilIntBuffer_[token.m_strength_];
			}

			token = token.m_previous_;
		}

		token.m_toInsert_ = this.m_utilIntBuffer_[token.m_strength_];
		INVERSE_UCA_.getInverseGapPositions(listheader);
		token = listheader.m_first_;
		int fstrength = true;
		int initstrength = 15;
		this.m_utilCEBuffer_[0] = mergeCE(listheader.m_baseCE_, listheader.m_baseContCE_, 0);
		this.m_utilCEBuffer_[1] = mergeCE(listheader.m_baseCE_, listheader.m_baseContCE_, 1);

		for (this.m_utilCEBuffer_[2] = mergeCE(listheader.m_baseCE_, listheader.m_baseContCE_,
				2); token != null; token = token.m_next_) {
			int fstrength = token.m_strength_;
			if (fstrength >= initstrength) {
				if (token.m_strength_ == 2) {
					this.m_utilCEBuffer_[2] = this.getNextGenerated(this.m_utilGens_[2]);
				} else if (token.m_strength_ == 1) {
					this.m_utilCEBuffer_[1] = this.getNextGenerated(this.m_utilGens_[1]);
					this.m_utilCEBuffer_[2] = this.getSimpleCEGenerator(this.m_utilGens_[2], token, 2);
				} else if (token.m_strength_ == 0) {
					this.m_utilCEBuffer_[0] = this.getNextGenerated(this.m_utilGens_[0]);
					this.m_utilCEBuffer_[1] = this.getSimpleCEGenerator(this.m_utilGens_[1], token, 1);
					this.m_utilCEBuffer_[2] = this.getSimpleCEGenerator(this.m_utilGens_[2], token, 2);
				}
			} else {
				initstrength = fstrength;
				if (listheader.m_pos_[fstrength] == -1) {
					while (listheader.m_pos_[fstrength] == -1 && fstrength > 0) {
						--fstrength;
					}

					if (listheader.m_pos_[fstrength] == -1) {
						throw new Exception("Internal program error");
					}
				}

				if (fstrength == 2) {
					this.m_utilCEBuffer_[0] = listheader.m_gapsLo_[fstrength * 3];
					this.m_utilCEBuffer_[1] = listheader.m_gapsLo_[fstrength * 3 + 1];
					this.m_utilCEBuffer_[2] = this.getCEGenerator(this.m_utilGens_[2], listheader.m_gapsLo_,
							listheader.m_gapsHi_, token, fstrength);
				} else if (fstrength == 1) {
					this.m_utilCEBuffer_[0] = listheader.m_gapsLo_[fstrength * 3];
					this.m_utilCEBuffer_[1] = this.getCEGenerator(this.m_utilGens_[1], listheader.m_gapsLo_,
							listheader.m_gapsHi_, token, fstrength);
					this.m_utilCEBuffer_[2] = this.getSimpleCEGenerator(this.m_utilGens_[2], token, 2);
				} else {
					this.m_utilCEBuffer_[0] = this.getCEGenerator(this.m_utilGens_[0], listheader.m_gapsLo_,
							listheader.m_gapsHi_, token, fstrength);
					this.m_utilCEBuffer_[1] = this.getSimpleCEGenerator(this.m_utilGens_[1], token, 1);
					this.m_utilCEBuffer_[2] = this.getSimpleCEGenerator(this.m_utilGens_[2], token, 2);
				}
			}

			this.doCE(this.m_utilCEBuffer_, token);
		}

	}

	private int getNextGenerated(CEGenerator g) {
		g.m_current_ = nextWeight(g);
		return g.m_current_;
	}

	private int getSimpleCEGenerator(CEGenerator g, Token token, int strength) throws Exception {
		int count = true;
		int maxbyte = strength == 2 ? 63 : 255;
		int high;
		int low;
		int count;
		if (strength == 1) {
			low = -2046820352;
			high = -1;
			count = 121;
		} else {
			low = 83886080;
			high = 1073741824;
			count = 59;
		}

		if (token.m_next_ != null && token.m_next_.m_strength_ == strength) {
			count = token.m_next_.m_toInsert_;
		}

		g.m_rangesLength_ = this.allocateWeights(low, high, count, maxbyte, g.m_ranges_);
		g.m_current_ = 83886080;
		if (g.m_rangesLength_ == 0) {
			throw new Exception("Internal program error");
		} else {
			return g.m_current_;
		}
	}

	private static int mergeCE(int ce1, int ce2, int strength) {
		int mask = 255;
		if (strength == 1) {
			mask = 65280;
		} else if (strength == 0) {
			mask = -65536;
		}

		ce1 &= mask;
		ce2 &= mask;
		switch (strength) {
			case 0 :
				return ce1 | ce2 >>> 16;
			case 1 :
				return ce1 << 16 | ce2 << 8;
			default :
				return ce1 << 24 | ce2 << 16;
		}
	}

	private int getCEGenerator(CEGenerator g, int[] lows, int[] highs, Token token, int fstrength) throws Exception {
		int strength = token.m_strength_;
		int low = lows[fstrength * 3 + strength];
		int high = highs[fstrength * 3 + strength];
		int maxbyte = false;
		short maxbyte;
		if (strength == 2) {
			maxbyte = 63;
		} else if (strength == 0) {
			maxbyte = 254;
		} else {
			maxbyte = 255;
		}

		int count = token.m_toInsert_;
		if (Utility.compareUnsigned(low, high) >= 0 && strength > 0) {
			int s = strength;

			while (true) {
				--s;
				if (lows[fstrength * 3 + s] != highs[fstrength * 3 + s]) {
					if (strength == 1) {
						if (low < -2046820352) {
							low = -2046820352;
						}

						high = -1;
					} else {
						if (low < 83886080) {
							low = 83886080;
						}

						high = 1073741824;
					}
					break;
				}

				if (s < 0) {
					throw new Exception("Internal program error");
				}
			}
		}

		if (low == 0) {
			low = 16777216;
		}

		if (strength == 1) {
			if (Utility.compareUnsigned(low, 83886080) >= 0 && Utility.compareUnsigned(low, -2046820352) < 0) {
				low = -2046820352;
			}

			if (Utility.compareUnsigned(high, 83886080) > 0 && Utility.compareUnsigned(high, -2046820352) < 0) {
				high = -2046820352;
			}

			if (Utility.compareUnsigned(low, 83886080) < 0) {
				g.m_rangesLength_ = this.allocateWeights(50331648, high, count, maxbyte, g.m_ranges_);
				g.m_current_ = nextWeight(g);
				return g.m_current_;
			}
		}

		g.m_rangesLength_ = this.allocateWeights(low, high, count, maxbyte, g.m_ranges_);
		if (g.m_rangesLength_ == 0) {
			throw new Exception("Internal program error");
		} else {
			g.m_current_ = nextWeight(g);
			return g.m_current_;
		}
	}

	private void doCE(int[] ceparts, Token token) throws Exception {
		int cei;
		for (cei = 0; cei < 3; ++cei) {
			this.m_utilIntBuffer_[cei] = countBytes(ceparts[cei]);
		}

		cei = 0;

		for (boolean var4 = false; cei << 1 < this.m_utilIntBuffer_[0] || cei < this.m_utilIntBuffer_[1]
				|| cei < this.m_utilIntBuffer_[2]; ++cei) {
			int value;
			if (cei > 0) {
				value = 192;
			} else {
				value = 0;
			}

			if (cei << 1 < this.m_utilIntBuffer_[0]) {
				value |= (ceparts[0] >> 32 - (cei + 1 << 4) & '￿') << 16;
			}

			if (cei < this.m_utilIntBuffer_[1]) {
				value |= (ceparts[1] >> 32 - (cei + 1 << 3) & 255) << 8;
			}

			if (cei < this.m_utilIntBuffer_[2]) {
				value |= ceparts[2] >> 32 - (cei + 1 << 3) & 63;
			}

			token.m_CE_[cei] = value;
		}

		if (cei == 0) {
			token.m_CELength_ = 1;
			token.m_CE_[0] = 0;
		} else {
			token.m_CELength_ = cei;
		}

		if (token.m_CE_[0] != 0) {
			int startoftokenrule = token.m_source_ & 255;
			int length;
			if (token.m_source_ >>> 24 > 1) {
				length = token.m_source_ >>> 24;
				String tokenstr = token.m_rules_.substring(startoftokenrule, startoftokenrule + length);
				token.m_CE_[0] |= this.getCaseBits(tokenstr);
			} else {
				length = this.getFirstCE(token.m_rules_.charAt(startoftokenrule));
				token.m_CE_[0] |= length & 192;
			}
		}

	}

	private static final int countBytes(int ce) {
		int mask = -1;

		int result;
		for (result = 0; mask != 0; mask >>>= 8) {
			if ((ce & mask) != 0) {
				++result;
			}
		}

		return result;
	}

	private void createElements(BuildTable t, TokenListHeader lh) {
		Token tok = lh.m_first_;
		this.m_utilElement_.clear();

		while (tok != null) {
			int len;
			int i;
			int fcd;
			if (tok.m_expansion_ == 0) {
				tok.m_expCELength_ = 0;
			} else {
				len = tok.m_expansion_ >>> 24;
				fcd = tok.m_expansion_ & 16777215;
				this.m_utilToken_.m_source_ = len | fcd;
				this.m_utilToken_.m_rules_ = this.m_parser_.m_source_;

				label83 : while (true) {
					do {
						if (len <= 0) {
							break label83;
						}

						for (i = len; i > 0; --i) {
							this.m_utilToken_.m_source_ = i << 24 | fcd;
							Token expt = (Token) this.m_parser_.m_hashTable_.get(this.m_utilToken_);
							if (expt != null && expt.m_strength_ != -559038737) {
								int noOfCEsToCopy = expt.m_CELength_;

								for (int j = 0; j < noOfCEsToCopy; ++j) {
									tok.m_expCE_[tok.m_expCELength_ + j] = expt.m_CE_[j];
								}

								tok.m_expCELength_ += noOfCEsToCopy;
								fcd += i;
								len -= i;
								break;
							}
						}
					} while (i != 0);

					this.m_utilColEIter_.setText(this.m_parser_.m_source_.substring(fcd, fcd + 1));

					while (true) {
						int order = this.m_utilColEIter_.next();
						if (order == -1) {
							++fcd;
							--len;
							break;
						}

						tok.m_expCE_[tok.m_expCELength_++] = order;
					}
				}
			}

			this.m_utilElement_.m_CELength_ = tok.m_CELength_ + tok.m_expCELength_;
			System.arraycopy(tok.m_CE_, 0, this.m_utilElement_.m_CEs_, 0, tok.m_CELength_);
			System.arraycopy(tok.m_expCE_, 0, this.m_utilElement_.m_CEs_, tok.m_CELength_, tok.m_expCELength_);
			this.m_utilElement_.m_prefix_ = 0;
			this.m_utilElement_.m_cPointsOffset_ = 0;
			if (tok.m_prefix_ != 0) {
				len = tok.m_prefix_ >> 24;
				i = tok.m_prefix_ & 16777215;
				this.m_utilElement_.m_prefixChars_ = this.m_parser_.m_source_.substring(i, i + len);
				len = (tok.m_source_ >> 24) - (tok.m_prefix_ >> 24);
				i = (tok.m_source_ & 16777215) + (tok.m_prefix_ >> 24);
				this.m_utilElement_.m_uchars_ = this.m_parser_.m_source_.substring(i, i + len);
			} else {
				this.m_utilElement_.m_prefixChars_ = null;
				len = tok.m_source_ & 16777215;
				i = tok.m_source_ >>> 24;
				this.m_utilElement_.m_uchars_ = this.m_parser_.m_source_.substring(len, len + i);
			}

			this.m_utilElement_.m_cPoints_ = this.m_utilElement_.m_uchars_;
			boolean containCombinMarks = false;

			for (i = 0; i < this.m_utilElement_.m_cPoints_.length() - this.m_utilElement_.m_cPointsOffset_; ++i) {
				if (isJamo(this.m_utilElement_.m_cPoints_.charAt(i))) {
					t.m_collator_.m_isJamoSpecial_ = true;
					break;
				}

				if (!buildCMTabFlag) {
					fcd = this.m_nfcImpl_.getFCD16FromSingleLead(this.m_utilElement_.m_cPoints_.charAt(i));
					if ((fcd & 255) == 0) {
						containCombinMarks = false;
					} else {
						containCombinMarks = true;
					}
				}
			}

			if (!buildCMTabFlag && containCombinMarks) {
				buildCMTabFlag = true;
			}

			this.addAnElement(t, this.m_utilElement_);
			tok = tok.m_next_;
		}

	}

	private final int getCaseBits(String src) throws Exception {
		int uCount = 0;
		int lCount = 0;
		src = Normalizer.decompose(src, true);
		this.m_utilColEIter_.setText(src);

		for (int i = 0; i < src.length(); ++i) {
			this.m_utilColEIter_.setText(src.substring(i, i + 1));
			int order = this.m_utilColEIter_.next();
			if (RuleBasedCollator.isContinuation(order)) {
				throw new Exception("Internal program error");
			}

			if ((order & 192) == 128) {
				++uCount;
			} else {
				char ch = src.charAt(i);
				if (UCharacter.isLowerCase(ch)) {
					++lCount;
				} else if (toSmallKana(ch) == ch && toLargeKana(ch) != ch) {
					++lCount;
				}
			}
		}

		if (uCount != 0 && lCount != 0) {
			return 64;
		} else if (uCount != 0) {
			return 128;
		} else {
			return 0;
		}
	}

	private static final char toLargeKana(char ch) {
		if (12354 < ch && ch < 12527) {
			switch (ch - 12288) {
				case 65 :
				case 67 :
				case 69 :
				case 71 :
				case 73 :
				case 99 :
				case 131 :
				case 133 :
				case 142 :
				case 161 :
				case 163 :
				case 165 :
				case 167 :
				case 169 :
				case 195 :
				case 227 :
				case 229 :
				case 238 :
					++ch;
					break;
				case 245 :
					ch = 12459;
					break;
				case 246 :
					ch = 12465;
			}
		}

		return ch;
	}

	private static final char toSmallKana(char ch) {
		if (12354 < ch && ch < 12527) {
			switch (ch - 12288) {
				case 66 :
				case 68 :
				case 70 :
				case 72 :
				case 74 :
				case 100 :
				case 132 :
				case 134 :
				case 143 :
				case 162 :
				case 164 :
				case 166 :
				case 168 :
				case 170 :
				case 196 :
				case 228 :
				case 230 :
				case 239 :
					--ch;
					break;
				case 171 :
					ch = 12533;
					break;
				case 177 :
					ch = 12534;
			}
		}

		return ch;
	}

	private int getFirstCE(char ch) {
		this.m_utilColEIter_.setText(UCharacter.toString(ch));
		return this.m_utilColEIter_.next();
	}

	private int addAnElement(BuildTable t, Elements element) {
		Vector<Integer> expansions = t.m_expansions_;
		element.m_mapCE_ = 0;
		int expansion;
		int expansion;
		if (element.m_CELength_ == 1) {
			element.m_mapCE_ = element.m_CEs_[0];
		} else if (element.m_CELength_ == 2 && RuleBasedCollator.isContinuation(element.m_CEs_[1])
				&& (element.m_CEs_[1] & 16777023) == 0 && (element.m_CEs_[0] >> 8 & 255) == 5
				&& (element.m_CEs_[0] & 255) == 5) {
			element.m_mapCE_ = -67108864 | element.m_CEs_[0] >> 8 & 16776960 | element.m_CEs_[1] >> 24 & 255;
		} else {
			expansion = -251658240 | addExpansion(expansions, element.m_CEs_[0]) << 4 & 16777200;

			for (expansion = 1; expansion < element.m_CELength_; ++expansion) {
				addExpansion(expansions, element.m_CEs_[expansion]);
			}

			if (element.m_CELength_ <= 15) {
				expansion |= element.m_CELength_;
			} else {
				addExpansion(expansions, 0);
			}

			element.m_mapCE_ = expansion;
			setMaxExpansion(element.m_CEs_[element.m_CELength_ - 1], (byte) element.m_CELength_, t.m_maxExpansions_);
			if (isJamo(element.m_cPoints_.charAt(0))) {
				t.m_collator_.m_isJamoSpecial_ = true;
				setMaxJamoExpansion(element.m_cPoints_.charAt(0), element.m_CEs_[element.m_CELength_ - 1],
						(byte) element.m_CELength_, t.m_maxJamoExpansions_);
			}
		}

		expansion = 0;
		if (element.m_uchars_.length() == 2 && UTF16.isLeadSurrogate(element.m_uchars_.charAt(0))) {
			expansion = UCharacterProperty.getRawSupplementary(element.m_uchars_.charAt(0),
					element.m_uchars_.charAt(1));
		} else if (element.m_uchars_.length() == 1) {
			expansion = element.m_uchars_.charAt(0);
		}

		if (expansion != 0 && UCharacter.isDigit(expansion)) {
			expansion = -50331647;
			if (element.m_mapCE_ != 0) {
				expansion |= addExpansion(expansions, element.m_mapCE_) << 4;
			} else {
				expansion |= addExpansion(expansions, element.m_CEs_[0]) << 4;
			}

			element.m_mapCE_ = expansion;
		}

		if (element.m_prefixChars_ != null && element.m_prefixChars_.length() - element.m_prefix_ > 0) {
			this.m_utilElement2_.m_caseBit_ = element.m_caseBit_;
			this.m_utilElement2_.m_CELength_ = element.m_CELength_;
			this.m_utilElement2_.m_CEs_ = element.m_CEs_;
			this.m_utilElement2_.m_mapCE_ = element.m_mapCE_;
			this.m_utilElement2_.m_sizePrim_ = element.m_sizePrim_;
			this.m_utilElement2_.m_sizeSec_ = element.m_sizeSec_;
			this.m_utilElement2_.m_sizeTer_ = element.m_sizeTer_;
			this.m_utilElement2_.m_variableTop_ = element.m_variableTop_;
			this.m_utilElement2_.m_prefix_ = element.m_prefix_;
			this.m_utilElement2_.m_prefixChars_ = Normalizer.compose(element.m_prefixChars_, false);
			this.m_utilElement2_.m_uchars_ = element.m_uchars_;
			this.m_utilElement2_.m_cPoints_ = element.m_cPoints_;
			this.m_utilElement2_.m_cPointsOffset_ = 0;
			if (t.m_prefixLookup_ != null) {
				Elements uCE = (Elements) t.m_prefixLookup_.get(element);
				if (uCE != null) {
					element.m_mapCE_ = this.addPrefix(t, uCE.m_mapCE_, element);
				} else {
					element.m_mapCE_ = this.addPrefix(t, -268435456, element);
					uCE = new Elements(element);
					uCE.m_cPoints_ = uCE.m_uchars_;
					t.m_prefixLookup_.put(uCE, uCE);
				}

				if (this.m_utilElement2_.m_prefixChars_.length() != element.m_prefixChars_.length() - element.m_prefix_
						|| !this.m_utilElement2_.m_prefixChars_.regionMatches(0, element.m_prefixChars_,
								element.m_prefix_, this.m_utilElement2_.m_prefixChars_.length())) {
					this.m_utilElement2_.m_mapCE_ = this.addPrefix(t, element.m_mapCE_, this.m_utilElement2_);
				}
			}
		}

		if (element.m_cPoints_.length() - element.m_cPointsOffset_ > 1
				&& (element.m_cPoints_.length() - element.m_cPointsOffset_ != 2
						|| !UTF16.isLeadSurrogate(element.m_cPoints_.charAt(0))
						|| !UTF16.isTrailSurrogate(element.m_cPoints_.charAt(1)))) {
			this.m_utilCanIter_.setSource(element.m_cPoints_);

			for (String source = this.m_utilCanIter_.next(); source != null
					&& source.length() > 0; source = this.m_utilCanIter_.next()) {
				if (Normalizer.quickCheck(source, Normalizer.FCD, 0) != Normalizer.NO) {
					element.m_uchars_ = source;
					element.m_cPoints_ = element.m_uchars_;
					finalizeAddition(t, element);
				}
			}

			return element.m_mapCE_;
		} else {
			return finalizeAddition(t, element);
		}
	}

	private static final int addExpansion(Vector<Integer> expansions, int value) {
		expansions.add(new Integer(value));
		return expansions.size() - 1;
	}

	private static int setMaxExpansion(int endexpansion, byte expansionsize, MaxExpansionTable maxexpansion) {
		int start = 0;
		int limit = maxexpansion.m_endExpansionCE_.size();
		long unsigned = (long) endexpansion;
		unsigned &= 4294967295L;
		int result = -1;

		while (start < limit - 1) {
			int mid = start + (limit - start >> 1);
			long unsignedce = (long) (Integer) maxexpansion.m_endExpansionCE_.get(mid);
			unsignedce &= 4294967295L;
			if (unsigned <= unsignedce) {
				limit = mid;
			} else {
				start = mid;
			}
		}

		if ((Integer) maxexpansion.m_endExpansionCE_.get(start) == endexpansion) {
			result = start;
		} else if ((Integer) maxexpansion.m_endExpansionCE_.get(limit) == endexpansion) {
			result = limit;
		}

		if (result > -1) {
			Object currentsize = maxexpansion.m_expansionCESize_.get(result);
			if ((Byte) currentsize < expansionsize) {
				maxexpansion.m_expansionCESize_.set(result, new Byte(expansionsize));
			}
		} else {
			maxexpansion.m_endExpansionCE_.insertElementAt(new Integer(endexpansion), start + 1);
			maxexpansion.m_expansionCESize_.insertElementAt(new Byte(expansionsize), start + 1);
		}

		return maxexpansion.m_endExpansionCE_.size();
	}

	private static int setMaxJamoExpansion(char ch, int endexpansion, byte expansionsize,
			MaxJamoExpansionTable maxexpansion) {
		boolean isV = true;
		if (ch >= 4352 && ch <= 4370) {
			if (maxexpansion.m_maxLSize_ < expansionsize) {
				maxexpansion.m_maxLSize_ = expansionsize;
			}

			return maxexpansion.m_endExpansionCE_.size();
		} else {
			if (ch >= 4449 && ch <= 4469 && maxexpansion.m_maxVSize_ < expansionsize) {
				maxexpansion.m_maxVSize_ = expansionsize;
			}

			if (ch >= 4520 && ch <= 4546) {
				isV = false;
				if (maxexpansion.m_maxTSize_ < expansionsize) {
					maxexpansion.m_maxTSize_ = expansionsize;
				}
			}

			int pos = maxexpansion.m_endExpansionCE_.size();

			do {
				if (pos <= 0) {
					maxexpansion.m_endExpansionCE_.add(new Integer(endexpansion));
					maxexpansion.m_isV_.add(isV ? Boolean.TRUE : Boolean.FALSE);
					return maxexpansion.m_endExpansionCE_.size();
				}

				--pos;
			} while ((Integer) maxexpansion.m_endExpansionCE_.get(pos) != endexpansion);

			return maxexpansion.m_endExpansionCE_.size();
		}
	}

	private int addPrefix(BuildTable t, int CE, Elements element) {
		ContractionTable contractions = t.m_contractions_;
		String oldCP = element.m_cPoints_;
		int oldCPOffset = element.m_cPointsOffset_;
		contractions.m_currentTag_ = 11;
		int size = element.m_prefixChars_.length() - element.m_prefix_;

		int firstContractionOffset;
		for (firstContractionOffset = 1; firstContractionOffset < size; ++firstContractionOffset) {
			char ch = element.m_prefixChars_.charAt(firstContractionOffset + element.m_prefix_);
			if (!UTF16.isTrailSurrogate(ch)) {
				unsafeCPSet(t.m_unsafeCP_, ch);
			}
		}

		this.m_utilStringBuffer_.delete(0, this.m_utilStringBuffer_.length());

		int position;
		for (firstContractionOffset = 0; firstContractionOffset < size; ++firstContractionOffset) {
			position = element.m_prefixChars_.length() - firstContractionOffset - 1;
			this.m_utilStringBuffer_.append(element.m_prefixChars_.charAt(position));
		}

		element.m_prefixChars_ = this.m_utilStringBuffer_.toString();
		element.m_prefix_ = 0;
		if (!UTF16.isTrailSurrogate(element.m_cPoints_.charAt(0))) {
			unsafeCPSet(t.m_unsafeCP_, element.m_cPoints_.charAt(0));
		}

		element.m_cPoints_ = element.m_prefixChars_;
		element.m_cPointsOffset_ = element.m_prefix_;
		if (!UTF16.isTrailSurrogate(element.m_cPoints_.charAt(element.m_cPoints_.length() - 1))) {
			ContrEndCPSet(t.m_contrEndCP_, element.m_cPoints_.charAt(element.m_cPoints_.length() - 1));
		}

		if (isJamo(element.m_prefixChars_.charAt(element.m_prefix_))) {
			t.m_collator_.m_isJamoSpecial_ = true;
		}

		if (!isPrefix(CE)) {
			firstContractionOffset = addContraction(contractions, 16777215, ' ', CE);
			position = processContraction(contractions, element, -268435456);
			addContraction(contractions, firstContractionOffset, element.m_prefixChars_.charAt(element.m_prefix_),
					position);
			addContraction(contractions, firstContractionOffset, '￿', CE);
			CE = constructSpecialCE(11, firstContractionOffset);
		} else {
			char ch = element.m_prefixChars_.charAt(element.m_prefix_);
			position = findCP(contractions, CE, ch);
			if (position > 0) {
				int eCE = getCE(contractions, CE, position);
				int newCE = processContraction(contractions, element, eCE);
				setContraction(contractions, CE, position, ch, newCE);
			} else {
				processContraction(contractions, element, -268435456);
				insertContraction(contractions, CE, ch, element.m_mapCE_);
			}
		}

		element.m_cPoints_ = oldCP;
		element.m_cPointsOffset_ = oldCPOffset;
		return CE;
	}

	private static final boolean isContraction(int CE) {
		return isSpecial(CE) && getCETag(CE) == 2;
	}

	private static final boolean isPrefix(int CE) {
		return isSpecial(CE) && getCETag(CE) == 11;
	}

	private static final boolean isSpecial(int CE) {
		return (CE & -268435456) == -268435456;
	}

	private static final int getCETag(int CE) {
		return (CE & 251658240) >>> 24;
	}

	private static final int getCE(ContractionTable table, int element, int position) {
		element &= 16777215;
		BasicContractionTable tbl = getBasicContractionTable(table, element);
		if (tbl == null) {
			return -268435456;
		} else {
			return position <= tbl.m_CEs_.size() && position != -1 ? (Integer) tbl.m_CEs_.get(position) : -268435456;
		}
	}

	private static final void unsafeCPSet(byte[] table, char c) {
		int hash = c;
		if (c >= 8448) {
			if (c >= '?' && c <= '') {
				return;
			}

			hash = (c & 8191) + 256;
		}

		table[hash >> 3] = (byte) (table[hash >> 3] | 1 << (hash & 7));
	}

	private static final void ContrEndCPSet(byte[] table, char c) {
		int hash = c;
		if (c >= 8448) {
			hash = (c & 8191) + 256;
		}

		table[hash >> 3] = (byte) (table[hash >> 3] | 1 << (hash & 7));
	}

	private static int addContraction(ContractionTable table, int element, char codePoint, int value) {
		BasicContractionTable tbl = getBasicContractionTable(table, element);
		if (tbl == null) {
			tbl = addAContractionElement(table);
			element = table.m_elements_.size() - 1;
		}

		tbl.m_CEs_.add(new Integer(value));
		tbl.m_codePoints_.append(codePoint);
		return constructSpecialCE(table.m_currentTag_, element);
	}

	private static BasicContractionTable addAContractionElement(ContractionTable table) {
		BasicContractionTable result = new BasicContractionTable();
		table.m_elements_.add(result);
		return result;
	}

	private static final int constructSpecialCE(int tag, int CE) {
		return -268435456 | tag << 24 | CE & 16777215;
	}

	private static int processContraction(ContractionTable contractions, Elements element, int existingCE) {
		int firstContractionOffset = false;
		if (element.m_cPoints_.length() - element.m_cPointsOffset_ == 1) {
			if (isContractionTableElement(existingCE) && getCETag(existingCE) == contractions.m_currentTag_) {
				changeContraction(contractions, existingCE, ' ', element.m_mapCE_);
				changeContraction(contractions, existingCE, '￿', element.m_mapCE_);
				return existingCE;
			} else {
				return element.m_mapCE_;
			}
		} else {
			++element.m_cPointsOffset_;
			int position;
			if (!isContractionTableElement(existingCE)) {
				int firstContractionOffset = addContraction(contractions, 16777215, ' ', existingCE);
				position = processContraction(contractions, element, -268435456);
				addContraction(contractions, firstContractionOffset,
						element.m_cPoints_.charAt(element.m_cPointsOffset_), position);
				addContraction(contractions, firstContractionOffset, '￿', existingCE);
				existingCE = constructSpecialCE(contractions.m_currentTag_, firstContractionOffset);
			} else {
				position = findCP(contractions, existingCE, element.m_cPoints_.charAt(element.m_cPointsOffset_));
				int eCE;
				if (position > 0) {
					eCE = getCE(contractions, existingCE, position);
					int newCE = processContraction(contractions, element, eCE);
					setContraction(contractions, existingCE, position,
							element.m_cPoints_.charAt(element.m_cPointsOffset_), newCE);
				} else {
					eCE = processContraction(contractions, element, -268435456);
					insertContraction(contractions, existingCE, element.m_cPoints_.charAt(element.m_cPointsOffset_),
							eCE);
				}
			}

			--element.m_cPointsOffset_;
			return existingCE;
		}
	}

	private static final boolean isContractionTableElement(int CE) {
		return isSpecial(CE) && (getCETag(CE) == 2 || getCETag(CE) == 11);
	}

	private static int findCP(ContractionTable table, int element, char codePoint) {
		BasicContractionTable tbl = getBasicContractionTable(table, element);
		if (tbl == null) {
			return -1;
		} else {
			int position = 0;

			do {
				if (codePoint <= tbl.m_codePoints_.charAt(position)) {
					if (codePoint == tbl.m_codePoints_.charAt(position)) {
						return position;
					}

					return -1;
				}

				++position;
			} while (position <= tbl.m_codePoints_.length());

			return -1;
		}
	}

	private static final BasicContractionTable getBasicContractionTable(ContractionTable table, int offset) {
		offset &= 16777215;
		return offset == 16777215 ? null : (BasicContractionTable) table.m_elements_.get(offset);
	}

	private static final int changeContraction(ContractionTable table, int element, char codePoint, int newCE) {
		BasicContractionTable tbl = getBasicContractionTable(table, element);
		if (tbl == null) {
			return 0;
		} else {
			int position = 0;

			do {
				if (codePoint <= tbl.m_codePoints_.charAt(position)) {
					if (codePoint == tbl.m_codePoints_.charAt(position)) {
						tbl.m_CEs_.set(position, new Integer(newCE));
						return element & 16777215;
					}

					return -268435456;
				}

				++position;
			} while (position <= tbl.m_codePoints_.length());

			return -268435456;
		}
	}

	private static final int setContraction(ContractionTable table, int element, int offset, char codePoint,
			int value) {
		element &= 16777215;
		BasicContractionTable tbl = getBasicContractionTable(table, element);
		if (tbl == null) {
			tbl = addAContractionElement(table);
			element = table.m_elements_.size() - 1;
		}

		tbl.m_CEs_.set(offset, new Integer(value));
		tbl.m_codePoints_.setCharAt(offset, codePoint);
		return constructSpecialCE(table.m_currentTag_, element);
	}

	private static final int insertContraction(ContractionTable table, int element, char codePoint, int value) {
		element &= 16777215;
		BasicContractionTable tbl = getBasicContractionTable(table, element);
		if (tbl == null) {
			tbl = addAContractionElement(table);
			element = table.m_elements_.size() - 1;
		}

		int offset;
		for (offset = 0; tbl.m_codePoints_.charAt(offset) < codePoint
				&& offset < tbl.m_codePoints_.length(); ++offset) {
			;
		}

		tbl.m_CEs_.insertElementAt(new Integer(value), offset);
		tbl.m_codePoints_.insert(offset, codePoint);
		return constructSpecialCE(table.m_currentTag_, element);
	}

	private static final int finalizeAddition(BuildTable t, Elements element) {
		int CE = -268435456;
		int cp;
		if (element.m_mapCE_ == 0) {
			for (cp = 0; cp < element.m_cPoints_.length(); ++cp) {
				char ch = element.m_cPoints_.charAt(cp);
				if (!UTF16.isTrailSurrogate(ch)) {
					unsafeCPSet(t.m_unsafeCP_, ch);
				}
			}
		}

		if (element.m_cPoints_.length() - element.m_cPointsOffset_ > 1) {
			cp = UTF16.charAt(element.m_cPoints_, element.m_cPointsOffset_);
			CE = t.m_mapping_.getValue(cp);
			CE = addContraction(t, CE, element);
		} else {
			CE = t.m_mapping_.getValue(element.m_cPoints_.charAt(element.m_cPointsOffset_));
			if (CE != -268435456) {
				if (isContractionTableElement(CE)) {
					if (!isPrefix(element.m_mapCE_)) {
						setContraction(t.m_contractions_, CE, 0, ' ', element.m_mapCE_);
						changeLastCE(t.m_contractions_, CE, element.m_mapCE_);
					}
				} else {
					t.m_mapping_.setValue(element.m_cPoints_.charAt(element.m_cPointsOffset_), element.m_mapCE_);
					if (element.m_prefixChars_ != null && element.m_prefixChars_.length() > 0 && getCETag(CE) != 10) {
						Elements origElem = new Elements();
						origElem.m_prefixChars_ = null;
						origElem.m_uchars_ = element.m_cPoints_;
						origElem.m_cPoints_ = origElem.m_uchars_;
						origElem.m_CEs_[0] = CE;
						origElem.m_mapCE_ = CE;
						origElem.m_CELength_ = 1;
						finalizeAddition(t, origElem);
					}
				}
			} else {
				t.m_mapping_.setValue(element.m_cPoints_.charAt(element.m_cPointsOffset_), element.m_mapCE_);
			}
		}

		return CE;
	}

	private static int addContraction(BuildTable t, int CE, Elements element) {
		ContractionTable contractions = t.m_contractions_;
		contractions.m_currentTag_ = 2;
		int cp = UTF16.charAt(element.m_cPoints_, 0);
		int cpsize = 1;
		if (UCharacter.isSupplementary(cp)) {
			cpsize = 2;
		}

		if (cpsize < element.m_cPoints_.length()) {
			int size = element.m_cPoints_.length() - element.m_cPointsOffset_;

			int position;
			for (position = 1; position < size; ++position) {
				if (!UTF16.isTrailSurrogate(element.m_cPoints_.charAt(element.m_cPointsOffset_ + position))) {
					unsafeCPSet(t.m_unsafeCP_, element.m_cPoints_.charAt(element.m_cPointsOffset_ + position));
				}
			}

			if (!UTF16.isTrailSurrogate(element.m_cPoints_.charAt(element.m_cPoints_.length() - 1))) {
				ContrEndCPSet(t.m_contrEndCP_, element.m_cPoints_.charAt(element.m_cPoints_.length() - 1));
			}

			if (isJamo(element.m_cPoints_.charAt(element.m_cPointsOffset_))) {
				t.m_collator_.m_isJamoSpecial_ = true;
			}

			element.m_cPointsOffset_ += cpsize;
			int eCE;
			if (!isContraction(CE)) {
				position = addContraction(contractions, 16777215, ' ', CE);
				eCE = processContraction(contractions, element, -268435456);
				addContraction(contractions, position, element.m_cPoints_.charAt(element.m_cPointsOffset_), eCE);
				addContraction(contractions, position, '￿', CE);
				CE = constructSpecialCE(2, position);
			} else {
				position = findCP(contractions, CE, element.m_cPoints_.charAt(element.m_cPointsOffset_));
				if (position > 0) {
					eCE = getCE(contractions, CE, position);
					int newCE = processContraction(contractions, element, eCE);
					setContraction(contractions, CE, position, element.m_cPoints_.charAt(element.m_cPointsOffset_),
							newCE);
				} else {
					eCE = processContraction(contractions, element, -268435456);
					insertContraction(contractions, CE, element.m_cPoints_.charAt(element.m_cPointsOffset_), eCE);
				}
			}

			element.m_cPointsOffset_ -= cpsize;
			t.m_mapping_.setValue(cp, CE);
		} else if (!isContraction(CE)) {
			t.m_mapping_.setValue(cp, element.m_mapCE_);
		} else {
			changeContraction(contractions, CE, ' ', element.m_mapCE_);
			changeContraction(contractions, CE, '￿', element.m_mapCE_);
		}

		return CE;
	}

	private static final int changeLastCE(ContractionTable table, int element, int value) {
		BasicContractionTable tbl = getBasicContractionTable(table, element);
		if (tbl == null) {
			return 0;
		} else {
			tbl.m_CEs_.set(tbl.m_CEs_.size() - 1, new Integer(value));
			return constructSpecialCE(table.m_currentTag_, element & 16777215);
		}
	}

	private static int nextWeight(CEGenerator cegenerator) {
		if (cegenerator.m_rangesLength_ > 0) {
			int maxByte = cegenerator.m_ranges_[0].m_count_;
			int weight = cegenerator.m_ranges_[0].m_start_;
			if (weight == cegenerator.m_ranges_[0].m_end_) {
				--cegenerator.m_rangesLength_;
				if (cegenerator.m_rangesLength_ > 0) {
					System.arraycopy(cegenerator.m_ranges_, 1, cegenerator.m_ranges_, 0, cegenerator.m_rangesLength_);
					cegenerator.m_ranges_[0].m_count_ = maxByte;
				}
			} else {
				cegenerator.m_ranges_[0].m_start_ = incWeight(weight, cegenerator.m_ranges_[0].m_length2_, maxByte);
			}

			return weight;
		} else {
			return -1;
		}
	}

	private static final int incWeight(int weight, int length, int maxByte) {
		while (true) {
			int b = getWeightByte(weight, length);
			if (b < maxByte) {
				return setWeightByte(weight, length, b + 1);
			}

			weight = setWeightByte(weight, length, 4);
			--length;
		}
	}

	private static final int getWeightByte(int weight, int index) {
		return weight >> (4 - index << 3) & 255;
	}

	private static final int setWeightByte(int weight, int index, int b) {
		index <<= 3;
		int mask = -1 >>> index;
		index = 32 - index;
		mask |= -256 << index;
		return weight & mask | b << index;
	}

	private int allocateWeights(int lowerLimit, int upperLimit, int n, int maxByte, WeightRange[] ranges) {
		int countBytes = maxByte - 4 + 1;
		this.m_utilLongBuffer_[0] = 1L;
		this.m_utilLongBuffer_[1] = (long) countBytes;
		this.m_utilLongBuffer_[2] = this.m_utilLongBuffer_[1] * (long) countBytes;
		this.m_utilLongBuffer_[3] = this.m_utilLongBuffer_[2] * (long) countBytes;
		this.m_utilLongBuffer_[4] = this.m_utilLongBuffer_[3] * (long) countBytes;
		int rangeCount = this.getWeightRanges(lowerLimit, upperLimit, maxByte, countBytes, ranges);
		if (rangeCount <= 0) {
			return 0;
		} else {
			long maxCount = 0L;

			int minLength;
			for (minLength = 0; minLength < rangeCount; ++minLength) {
				maxCount += (long) ranges[minLength].m_count_ * this.m_utilLongBuffer_[4 - ranges[minLength].m_length_];
			}

			if (maxCount < (long) n) {
				return 0;
			} else {
				for (minLength = 0; minLength < rangeCount; ++minLength) {
					ranges[minLength].m_length2_ = ranges[minLength].m_length_;
					ranges[minLength].m_count2_ = ranges[minLength].m_count_;
				}

				label63 : while (true) {
					minLength = ranges[0].m_length2_;
					Arrays.fill(this.m_utilCountBuffer_, 0);

					int i;
					for (i = 0; i < rangeCount; ++i) {
						this.m_utilCountBuffer_[ranges[i].m_length2_] += ranges[i].m_count2_;
					}

					if (n <= this.m_utilCountBuffer_[minLength] + this.m_utilCountBuffer_[minLength + 1]) {
						maxCount = 0L;
						rangeCount = 0;

						while (true) {
							maxCount += (long) ranges[rangeCount].m_count2_;
							++rangeCount;
							if ((long) n <= maxCount) {
								break label63;
							}
						}
					}

					if (n <= ranges[0].m_count2_ * countBytes) {
						rangeCount = 1;
						long power_1 = this.m_utilLongBuffer_[minLength - ranges[0].m_length_];
						long power = power_1 * (long) countBytes;
						int count2 = (int) (((long) n + power - 1L) / power);
						int count1 = ranges[0].m_count_ - count2;
						if (count1 < 1) {
							lengthenRange(ranges, 0, maxByte, countBytes);
						} else {
							rangeCount = 2;
							ranges[1].m_end_ = ranges[0].m_end_;
							ranges[1].m_length_ = ranges[0].m_length_;
							ranges[1].m_length2_ = minLength;
							int i = ranges[0].m_length_;
							int b = getWeightByte(ranges[0].m_start_, i) + count1 - 1;
							if (b <= maxByte) {
								ranges[0].m_end_ = setWeightByte(ranges[0].m_start_, i, b);
							} else {
								ranges[0].m_end_ = setWeightByte(incWeight(ranges[0].m_start_, i - 1, maxByte), i,
										b - countBytes);
							}

							b = maxByte << 24 | maxByte << 16 | maxByte << 8 | maxByte;
							ranges[0].m_end_ = truncateWeight(ranges[0].m_end_, i)
									| b >>> (i << 3) & b << (4 - minLength << 3);
							ranges[1].m_start_ = incWeight(ranges[0].m_end_, minLength, maxByte);
							ranges[0].m_count_ = count1;
							ranges[1].m_count_ = count2;
							ranges[0].m_count2_ = (int) ((long) count1 * power_1);
							ranges[1].m_count2_ = (int) ((long) count2 * power_1);
							lengthenRange(ranges, 1, maxByte, countBytes);
						}
						break;
					}

					for (i = 0; ranges[i].m_length2_ == minLength; ++i) {
						lengthenRange(ranges, i, maxByte, countBytes);
					}
				}

				if (rangeCount > 1) {
					Arrays.sort(ranges, 0, rangeCount);
				}

				ranges[0].m_count_ = maxByte;
				return rangeCount;
			}
		}
	}

	private static final int lengthenRange(WeightRange[] range, int offset, int maxByte, int countBytes) {
		int length = range[offset].m_length2_ + 1;
		range[offset].m_start_ = setWeightTrail(range[offset].m_start_, length, 4);
		range[offset].m_end_ = setWeightTrail(range[offset].m_end_, length, maxByte);
		range[offset].m_count2_ *= countBytes;
		range[offset].m_length2_ = length;
		return length;
	}

	private static final int setWeightTrail(int weight, int length, int trail) {
		length = 4 - length << 3;
		return weight & -256 << length | trail << length;
	}

	private int getWeightRanges(int lowerLimit, int upperLimit, int maxByte, int countBytes, WeightRange[] ranges) {
		int lowerLength = lengthOfWeight(lowerLimit);
		int upperLength = lengthOfWeight(upperLimit);
		if (Utility.compareUnsigned(lowerLimit, upperLimit) >= 0) {
			return 0;
		} else if (lowerLength < upperLength && lowerLimit == truncateWeight(upperLimit, lowerLength)) {
			return 0;
		} else {
			int weight;
			for (weight = 0; weight < 5; ++weight) {
				this.m_utilLowerWeightRange_[weight].clear();
				this.m_utilUpperWeightRange_[weight].clear();
			}

			this.m_utilWeightRange_.clear();
			weight = lowerLimit;

			int length;
			int length;
			for (length = lowerLength; length >= 2; --length) {
				this.m_utilLowerWeightRange_[length].clear();
				length = getWeightByte(weight, length);
				if (length < maxByte) {
					this.m_utilLowerWeightRange_[length].m_start_ = incWeightTrail(weight, length);
					this.m_utilLowerWeightRange_[length].m_end_ = setWeightTrail(weight, length, maxByte);
					this.m_utilLowerWeightRange_[length].m_length_ = length;
					this.m_utilLowerWeightRange_[length].m_count_ = maxByte - length;
				}

				weight = truncateWeight(weight, length - 1);
			}

			this.m_utilWeightRange_.m_start_ = incWeightTrail(weight, 1);
			weight = upperLimit;

			for (length = upperLength; length >= 2; --length) {
				length = getWeightByte(weight, length);
				if (length > 4) {
					this.m_utilUpperWeightRange_[length].m_start_ = setWeightTrail(weight, length, 4);
					this.m_utilUpperWeightRange_[length].m_end_ = decWeightTrail(weight, length);
					this.m_utilUpperWeightRange_[length].m_length_ = length;
					this.m_utilUpperWeightRange_[length].m_count_ = length - 4;
				}

				weight = truncateWeight(weight, length - 1);
			}

			this.m_utilWeightRange_.m_end_ = decWeightTrail(weight, 1);
			this.m_utilWeightRange_.m_length_ = 1;
			if (Utility.compareUnsigned(this.m_utilWeightRange_.m_end_, this.m_utilWeightRange_.m_start_) >= 0) {
				this.m_utilWeightRange_.m_count_ = (this.m_utilWeightRange_.m_end_
						- this.m_utilWeightRange_.m_start_ >>> 24) + 1;
			} else {
				this.m_utilWeightRange_.m_count_ = 0;

				label78 : for (length = 4; length >= 2; --length) {
					if (this.m_utilLowerWeightRange_[length].m_count_ > 0
							&& this.m_utilUpperWeightRange_[length].m_count_ > 0) {
						length = this.m_utilUpperWeightRange_[length].m_start_;
						int end = this.m_utilLowerWeightRange_[length].m_end_;
						if (end >= length || incWeight(end, length, maxByte) == length) {
							length = this.m_utilLowerWeightRange_[length].m_start_;
							end = this.m_utilLowerWeightRange_[length].m_end_ = this.m_utilUpperWeightRange_[length].m_end_;
							this.m_utilLowerWeightRange_[length].m_count_ = getWeightByte(end, length)
									- getWeightByte(length, length) + 1
									+ countBytes * (getWeightByte(end, length - 1) - getWeightByte(length, length - 1));
							this.m_utilUpperWeightRange_[length].m_count_ = 0;

							while (true) {
								--length;
								if (length < 2) {
									break label78;
								}

								this.m_utilLowerWeightRange_[length].m_count_ = this.m_utilUpperWeightRange_[length].m_count_ = 0;
							}
						}
					}
				}
			}

			length = 0;
			if (this.m_utilWeightRange_.m_count_ > 0) {
				ranges[0] = new WeightRange(this.m_utilWeightRange_);
				length = 1;
			}

			for (length = 2; length <= 4; ++length) {
				if (this.m_utilUpperWeightRange_[length].m_count_ > 0) {
					ranges[length] = new WeightRange(this.m_utilUpperWeightRange_[length]);
					++length;
				}

				if (this.m_utilLowerWeightRange_[length].m_count_ > 0) {
					ranges[length] = new WeightRange(this.m_utilLowerWeightRange_[length]);
					++length;
				}
			}

			return length;
		}
	}

	private static final int truncateWeight(int weight, int length) {
		return weight & -1 << (4 - length << 3);
	}

	private static final int lengthOfWeight(int weight) {
		if ((weight & 16777215) == 0) {
			return 1;
		} else if ((weight & '￿') == 0) {
			return 2;
		} else {
			return (weight & 255) == 0 ? 3 : 4;
		}
	}

	private static final int incWeightTrail(int weight, int length) {
		return weight + (1 << (4 - length << 3));
	}

	private static int decWeightTrail(int weight, int length) {
		return weight - (1 << (4 - length << 3));
	}

	private static int findCP(BasicContractionTable tbl, char codePoint) {
		int position = 0;

		do {
			if (codePoint <= tbl.m_codePoints_.charAt(position)) {
				if (codePoint == tbl.m_codePoints_.charAt(position)) {
					return position;
				}

				return -1;
			}

			++position;
		} while (position <= tbl.m_codePoints_.length());

		return -1;
	}

	private static int findCE(ContractionTable table, int element, char ch) {
		if (table == null) {
			return -268435456;
		} else {
			BasicContractionTable tbl = getBasicContractionTable(table, element);
			if (tbl == null) {
				return -268435456;
			} else {
				int position = findCP(tbl, ch);
				return position <= tbl.m_CEs_.size() && position >= 0 ? (Integer) tbl.m_CEs_.get(position) : -268435456;
			}
		}
	}

	private static boolean isTailored(ContractionTable table, int element, char[] array, int offset) {
		while (array[offset] != 0) {
			element = findCE(table, element, array[offset]);
			if (element == -268435456) {
				return false;
			}

			if (!isContractionTableElement(element)) {
				return true;
			}

			++offset;
		}

		if (getCE(table, element, 0) != -268435456) {
			return true;
		} else {
			return false;
		}
	}

	private void assembleTable(BuildTable t, RuleBasedCollator collator) {
		IntTrieBuilder mapping = t.m_mapping_;
		Vector<Integer> expansions = t.m_expansions_;
		ContractionTable contractions = t.m_contractions_;
		MaxExpansionTable maxexpansion = t.m_maxExpansions_;
		collator.m_contractionOffset_ = 0;
		int contractionsSize = this.constructTable(contractions);
		getMaxExpansionJamo(mapping, maxexpansion, t.m_maxJamoExpansions_, collator.m_isJamoSpecial_);
		setAttributes(collator, t.m_options_);
		int size = expansions.size();
		collator.m_expansion_ = new int[size];

		int i;
		for (i = 0; i < size; ++i) {
			collator.m_expansion_[i] = (Integer) expansions.get(i);
		}

		if (contractionsSize != 0) {
			collator.m_contractionIndex_ = new char[contractionsSize];
			contractions.m_codePoints_.getChars(0, contractionsSize, collator.m_contractionIndex_, 0);
			collator.m_contractionCE_ = new int[contractionsSize];

			for (i = 0; i < contractionsSize; ++i) {
				collator.m_contractionCE_[i] = (Integer) contractions.m_CEs_.get(i);
			}
		}

		collator.m_trie_ = mapping.serialize(t, DataManipulate.getInstance());
		collator.m_expansionOffset_ = 0;
		size = maxexpansion.m_endExpansionCE_.size();
		collator.m_expansionEndCE_ = new int[size - 1];

		for (i = 1; i < size; ++i) {
			collator.m_expansionEndCE_[i - 1] = (Integer) maxexpansion.m_endExpansionCE_.get(i);
		}

		collator.m_expansionEndCEMaxSize_ = new byte[size - 1];

		for (i = 1; i < size; ++i) {
			collator.m_expansionEndCEMaxSize_[i - 1] = (Byte) maxexpansion.m_expansionCESize_.get(i);
		}

		this.unsafeCPAddCCNZ(t);

		for (i = 0; i < 1056; ++i) {
			t.m_unsafeCP_[i] |= RuleBasedCollator.UCA_.m_unsafe_[i];
		}

		collator.m_unsafe_ = t.m_unsafeCP_;

		for (i = 0; i < 1056; ++i) {
			t.m_contrEndCP_[i] |= RuleBasedCollator.UCA_.m_contractionEnd_[i];
		}

		collator.m_contractionEnd_ = t.m_contrEndCP_;
	}

	private static final void setAttributes(RuleBasedCollator collator, OptionSet option) {
		collator.latinOneFailed_ = true;
		collator.m_caseFirst_ = option.m_caseFirst_;
		collator.setDecomposition(option.m_decomposition_);
		collator.setAlternateHandlingShifted(option.m_isAlternateHandlingShifted_);
		collator.setCaseLevel(option.m_isCaseLevel_);
		collator.setFrenchCollation(option.m_isFrenchCollation_);
		collator.m_isHiragana4_ = option.m_isHiragana4_;
		collator.setStrength(option.m_strength_);
		collator.m_variableTopValue_ = option.m_variableTopValue_;
		collator.latinOneFailed_ = false;
	}

	private int constructTable(ContractionTable table) {
		int tsize = table.m_elements_.size();
		if (tsize == 0) {
			return 0;
		} else {
			table.m_offsets_.clear();
			int position = 0;

			for (int i = 0; i < tsize; ++i) {
				table.m_offsets_.add(new Integer(position));
				position += ((BasicContractionTable) table.m_elements_.get(i)).m_CEs_.size();
			}

			table.m_CEs_.clear();
			table.m_codePoints_.delete(0, table.m_codePoints_.length());
			StringBuilder cpPointer = table.m_codePoints_;
			Vector<Integer> CEPointer = table.m_CEs_;

			int i;
			for (i = 0; i < tsize; ++i) {
				BasicContractionTable bct = (BasicContractionTable) table.m_elements_.get(i);
				int size = bct.m_CEs_.size();
				char ccMax = 0;
				char ccMin = 255;
				int offset = CEPointer.size();
				CEPointer.add(bct.m_CEs_.get(0));

				int j;
				for (j = 1; j < size; ++j) {
					char ch = bct.m_codePoints_.charAt(j);
					char cc = (char) (UCharacter.getCombiningClass(ch) & 255);
					if (cc > ccMax) {
						ccMax = cc;
					}

					if (cc < ccMin) {
						ccMin = cc;
					}

					cpPointer.append(ch);
					CEPointer.add(bct.m_CEs_.get(j));
				}

				cpPointer.insert(offset, (char) ((ccMin == ccMax ? 1 : 0) | ccMax));

				for (j = 0; j < size; ++j) {
					if (isContractionTableElement((Integer) CEPointer.get(offset + j))) {
						int ce = (Integer) CEPointer.get(offset + j);
						CEPointer.set(offset + j, new Integer(constructSpecialCE(getCETag(ce),
								(Integer) table.m_offsets_.get(getContractionOffset(ce)))));
					}
				}
			}

			for (i = 0; i <= 1114111; ++i) {
				int CE = table.m_mapping_.getValue(i);
				if (isContractionTableElement(CE)) {
					CE = constructSpecialCE(getCETag(CE), (Integer) table.m_offsets_.get(getContractionOffset(CE)));
					table.m_mapping_.setValue(i, CE);
				}
			}

			return position;
		}
	}

	private static final int getContractionOffset(int ce) {
		return ce & 16777215;
	}

	private static void getMaxExpansionJamo(IntTrieBuilder mapping, MaxExpansionTable maxexpansion,
			MaxJamoExpansionTable maxjamoexpansion, boolean jamospecial) {
		int VBASE = 4449;
		int TBASE = 4520;
		int VCOUNT = 21;
		int TCOUNT = 28;
		int v = VBASE + VCOUNT - 1;

		int t;
		int count;
		for (t = TBASE + TCOUNT - 1; v >= VBASE; --v) {
			count = mapping.getValue(v);
			if ((count & -268435456) != -268435456) {
				setMaxExpansion(count, (byte) 2, maxexpansion);
			}
		}

		for (; t >= TBASE; --t) {
			count = mapping.getValue(t);
			if ((count & -268435456) != -268435456) {
				setMaxExpansion(count, (byte) 3, maxexpansion);
			}
		}

		if (jamospecial) {
			count = maxjamoexpansion.m_endExpansionCE_.size();
			byte maxTSize = (byte) (maxjamoexpansion.m_maxLSize_ + maxjamoexpansion.m_maxVSize_
					+ maxjamoexpansion.m_maxTSize_);
			byte maxVSize = (byte) (maxjamoexpansion.m_maxLSize_ + maxjamoexpansion.m_maxVSize_);

			while (count > 0) {
				--count;
				if ((Boolean) maxjamoexpansion.m_isV_.get(count)) {
					setMaxExpansion((Integer) maxjamoexpansion.m_endExpansionCE_.get(count), maxVSize, maxexpansion);
				} else {
					setMaxExpansion((Integer) maxjamoexpansion.m_endExpansionCE_.get(count), maxTSize, maxexpansion);
				}
			}
		}

	}

	private final void unsafeCPAddCCNZ(BuildTable t) {
		boolean buildCMTable = buildCMTabFlag & t.cmLookup == null;
		char[] cm = null;
		int[] index = new int[256];
		int count = 0;
		if (buildCMTable) {
			cm = new char[65536];
		}

		for (char c = 0; c < '￿'; ++c) {
			int fcd = this.m_nfcImpl_.getFCD16FromSingleLead(c);
			if (fcd >= 256 || UTF16.isLeadSurrogate(c) && fcd != 0) {
				unsafeCPSet(t.m_unsafeCP_, c);
				if (buildCMTable && fcd != 0) {
					int cc = fcd & 255;
					int pos = (cc << 8) + index[cc];
					cm[pos] = c;
					++index[cc];
					++count;
				}
			}
		}

		if (t.m_prefixLookup_ != null) {
			Enumeration els = t.m_prefixLookup_.elements();

			while (els.hasMoreElements()) {
				Elements e = (Elements) els.nextElement();
				String comp = Normalizer.compose(e.m_cPoints_, false);
				unsafeCPSet(t.m_unsafeCP_, comp.charAt(0));
			}
		}

		if (buildCMTable) {
			t.cmLookup = new CombinClassTable();
			t.cmLookup.generate(cm, count, index);
		}

	}

	private boolean enumCategoryRangeClosureCategory(BuildTable t, RuleBasedCollator collator,
			CollationElementIterator colEl, int start, int limit, int type) {
		if (type != 0 && type != 17) {
			for (int u32 = start; u32 < limit; ++u32) {
				String decomp = this.m_nfcImpl_.getDecomposition(u32);
				if (decomp != null) {
					String comp = UCharacter.toString(u32);
					if (!collator.equals(comp, decomp)) {
						this.m_utilElement_.m_cPoints_ = decomp;
						this.m_utilElement_.m_prefix_ = 0;
						Elements prefix = (Elements) t.m_prefixLookup_.get(this.m_utilElement_);
						if (prefix == null) {
							this.m_utilElement_.m_cPoints_ = comp;
							this.m_utilElement_.m_prefix_ = 0;
							this.m_utilElement_.m_prefixChars_ = null;
							colEl.setText(decomp);
							int ce = colEl.next();

							for (this.m_utilElement_.m_CELength_ = 0; ce != -1; ce = colEl.next()) {
								this.m_utilElement_.m_CEs_[this.m_utilElement_.m_CELength_++] = ce;
							}
						} else {
							this.m_utilElement_.m_cPoints_ = comp;
							this.m_utilElement_.m_prefix_ = 0;
							this.m_utilElement_.m_prefixChars_ = null;
							this.m_utilElement_.m_CELength_ = 1;
							this.m_utilElement_.m_CEs_[0] = prefix.m_mapCE_;
						}

						this.addAnElement(t, this.m_utilElement_);
					}
				}
			}
		}

		return true;
	}

	private static final boolean isJamo(char ch) {
		return ch >= 4352 && ch <= 4370 || ch >= 4469 && ch <= 4449 || ch >= 4520 && ch <= 4546;
	}

	private void canonicalClosure(BuildTable t) {
		BuildTable temp = new BuildTable(t);
		this.assembleTable(temp, temp.m_collator_);
		CollationElementIterator coleiter = temp.m_collator_.getCollationElementIterator("");
		RangeValueIterator typeiter = UCharacter.getTypeIterator();
		Element element = new Element();

		while (typeiter.next(element)) {
			this.enumCategoryRangeClosureCategory(t, temp.m_collator_, coleiter, element.start, element.limit,
					element.value);
		}

		t.cmLookup = temp.cmLookup;
		temp.cmLookup = null;

		for (int i = 0; i < this.m_parser_.m_resultLength_; ++i) {
			Token tok = this.m_parser_.m_listHeader_[i].m_first_;
			this.m_utilElement_.clear();

			for (; tok != null; tok = tok.m_next_) {
				this.m_utilElement_.m_prefix_ = 0;
				this.m_utilElement_.m_cPointsOffset_ = 0;
				int j;
				int fcd;
				if (tok.m_prefix_ != 0) {
					j = tok.m_prefix_ >> 24;
					fcd = tok.m_prefix_ & 16777215;
					this.m_utilElement_.m_prefixChars_ = this.m_parser_.m_source_.substring(fcd, fcd + j);
					j = (tok.m_source_ >> 24) - (tok.m_prefix_ >> 24);
					fcd = (tok.m_source_ & 16777215) + (tok.m_prefix_ >> 24);
					this.m_utilElement_.m_uchars_ = this.m_parser_.m_source_.substring(fcd, fcd + j);
				} else {
					this.m_utilElement_.m_prefixChars_ = null;
					j = tok.m_source_ & 16777215;
					fcd = tok.m_source_ >>> 24;
					this.m_utilElement_.m_uchars_ = this.m_parser_.m_source_.substring(j, j + fcd);
				}

				this.m_utilElement_.m_cPoints_ = this.m_utilElement_.m_uchars_;
				char firstCM = 0;
				char baseChar = 0;

				for (j = 0; j < this.m_utilElement_.m_cPoints_.length() - this.m_utilElement_.m_cPointsOffset_; ++j) {
					fcd = this.m_nfcImpl_.getFCD16FromSingleLead(this.m_utilElement_.m_cPoints_.charAt(j));
					if ((fcd & 255) == 0) {
						baseChar = this.m_utilElement_.m_cPoints_.charAt(j);
					} else if (baseChar != 0 && firstCM == 0) {
						firstCM = this.m_utilElement_.m_cPoints_.charAt(j);
					}
				}

				if (baseChar != 0 && firstCM != 0) {
					this.addTailCanonicalClosures(t, temp.m_collator_, coleiter, baseChar, firstCM);
				}
			}
		}

	}

	private void addTailCanonicalClosures(BuildTable t, RuleBasedCollator m_collator, CollationElementIterator colEl,
			char baseChar, char cMark) {
		if (t.cmLookup != null) {
			CombinClassTable cmLookup = t.cmLookup;
			int[] index = cmLookup.index;
			int cClass = this.m_nfcImpl_.getFCD16FromSingleLead(cMark) & 255;
			int maxIndex = 0;
			char[] precompCh = new char[256];
			int[] precompClass = new int[256];
			int precompLen = 0;
			Elements element = new Elements();
			if (cClass > 0) {
				maxIndex = index[cClass - 1];
			}

			for (int i = 0; i < maxIndex; ++i) {
				StringBuilder decompBuf = new StringBuilder();
				decompBuf.append(baseChar).append(cmLookup.cPoints[i]);
				String comp = Normalizer.compose(decompBuf.toString(), false);
				if (comp.length() == 1) {
					precompCh[precompLen] = comp.charAt(0);
					precompClass[precompLen] = this.m_nfcImpl_.getFCD16FromSingleLead(cmLookup.cPoints[i]) & 255;
					++precompLen;
					StringBuilder decomp = new StringBuilder();

					for (int j = 0; j < this.m_utilElement_.m_cPoints_.length(); ++j) {
						if (this.m_utilElement_.m_cPoints_.charAt(j) == cMark) {
							decomp.append(cmLookup.cPoints[i]);
						} else {
							decomp.append(this.m_utilElement_.m_cPoints_.charAt(j));
						}
					}

					comp = Normalizer.compose(decomp.toString(), false);
					StringBuilder buf = new StringBuilder(comp);
					buf.append(cMark);
					decomp.append(cMark);
					comp = buf.toString();
					element.m_cPoints_ = decomp.toString();
					element.m_CELength_ = 0;
					element.m_prefix_ = 0;
					Elements prefix = (Elements) t.m_prefixLookup_.get(element);
					element.m_cPoints_ = comp;
					element.m_uchars_ = comp;
					if (prefix == null) {
						element.m_prefix_ = 0;
						element.m_prefixChars_ = null;
						colEl.setText(decomp.toString());
						int ce = colEl.next();

						for (element.m_CELength_ = 0; ce != -1; ce = colEl.next()) {
							element.m_CEs_[element.m_CELength_++] = ce;
						}
					} else {
						element.m_cPoints_ = comp;
						element.m_prefix_ = 0;
						element.m_prefixChars_ = null;
						element.m_CELength_ = 1;
						element.m_CEs_[0] = prefix.m_mapCE_;
					}

					this.setMapCE(t, element);
					finalizeAddition(t, element);
					if (comp.length() > 2) {
						this.addFCD4AccentedContractions(t, colEl, comp, element);
					}

					if (precompLen > 1) {
						precompLen = this.addMultiCMontractions(t, colEl, element, precompCh, precompClass, precompLen,
								cMark, i, decomp.toString());
					}
				}
			}

		}
	}

	private void setMapCE(BuildTable t, Elements element) {
		Vector<Integer> expansions = t.m_expansions_;
		element.m_mapCE_ = 0;
		if (element.m_CELength_ == 2 && RuleBasedCollator.isContinuation(element.m_CEs_[1])
				&& (element.m_CEs_[1] & 16777023) == 0 && (element.m_CEs_[0] >> 8 & 255) == 5
				&& (element.m_CEs_[0] & 255) == 5) {
			element.m_mapCE_ = -67108864 | element.m_CEs_[0] >> 8 & 16776960 | element.m_CEs_[1] >> 24 & 255;
		} else {
			int expansion = -251658240 | addExpansion(expansions, element.m_CEs_[0]) << 4 & 16777200;

			for (int i = 1; i < element.m_CELength_; ++i) {
				addExpansion(expansions, element.m_CEs_[i]);
			}

			if (element.m_CELength_ <= 15) {
				expansion |= element.m_CELength_;
			} else {
				addExpansion(expansions, 0);
			}

			element.m_mapCE_ = expansion;
			setMaxExpansion(element.m_CEs_[element.m_CELength_ - 1], (byte) element.m_CELength_, t.m_maxExpansions_);
		}

	}

	private int addMultiCMontractions(BuildTable t, CollationElementIterator colEl, Elements element, char[] precompCh,
			int[] precompClass, int maxComp, char cMark, int cmPos, String decomp) {
		CombinClassTable cmLookup = t.cmLookup;
		char[] combiningMarks = new char[]{cMark};
		int cMarkClass = UCharacter.getCombiningClass(cMark) & 255;
		String comMark = new String(combiningMarks);
		int noOfPrecomposedChs = maxComp;

		for (int j = 0; j < maxComp; ++j) {
			int count = 0;

			do {
				StringBuilder temp;
				String newDecomp;
				if (count == 0) {
					newDecomp = Normalizer.decompose(new String(precompCh, j, 1), false);
					temp = new StringBuilder(newDecomp);
					temp.append(cmLookup.cPoints[cmPos]);
					newDecomp = temp.toString();
				} else {
					temp = new StringBuilder(decomp);
					temp.append(precompCh[j]);
					newDecomp = temp.toString();
				}

				String comp = Normalizer.compose(newDecomp, false);
				if (comp.length() == 1) {
					temp.append(cMark);
					element.m_cPoints_ = temp.toString();
					element.m_CELength_ = 0;
					element.m_prefix_ = 0;
					Elements prefix = (Elements) t.m_prefixLookup_.get(element);
					element.m_cPoints_ = comp + comMark;
					if (prefix == null) {
						element.m_prefix_ = 0;
						element.m_prefixChars_ = null;
						colEl.setText(temp.toString());
						int ce = colEl.next();

						for (element.m_CELength_ = 0; ce != -1; ce = colEl.next()) {
							element.m_CEs_[element.m_CELength_++] = ce;
						}
					} else {
						element.m_cPoints_ = comp;
						element.m_prefix_ = 0;
						element.m_prefixChars_ = null;
						element.m_CELength_ = 1;
						element.m_CEs_[0] = prefix.m_mapCE_;
					}

					this.setMapCE(t, element);
					finalizeAddition(t, element);
					precompCh[noOfPrecomposedChs] = comp.charAt(0);
					precompClass[noOfPrecomposedChs] = cMarkClass;
					++noOfPrecomposedChs;
				}

				++count;
			} while (count < 2 && precompClass[j] == cMarkClass);
		}

		return noOfPrecomposedChs;
	}

	private void addFCD4AccentedContractions(BuildTable t, CollationElementIterator colEl, String data,
			Elements element) {
		String decomp = Normalizer.decompose(data, false);
		String comp = Normalizer.compose(data, false);
		element.m_cPoints_ = decomp;
		element.m_CELength_ = 0;
		element.m_prefix_ = 0;
		Elements prefix = (Elements) t.m_prefixLookup_.get(element);
		if (prefix == null) {
			element.m_cPoints_ = comp;
			element.m_prefix_ = 0;
			element.m_prefixChars_ = null;
			element.m_CELength_ = 0;
			colEl.setText(decomp);
			int ce = colEl.next();

			for (element.m_CELength_ = 0; ce != -1; ce = colEl.next()) {
				element.m_CEs_[element.m_CELength_++] = ce;
			}

			this.addAnElement(t, element);
		}

	}

	private void processUCACompleteIgnorables(BuildTable t) {
		TrieIterator trieiterator = new TrieIterator(RuleBasedCollator.UCA_.m_trie_);
		Element element = new Element();

		while (true) {
			int start;
			int limit;
			do {
				if (!trieiterator.next(element)) {
					return;
				}

				start = element.start;
				limit = element.limit;
			} while (element.value != 0);

			for (; start < limit; ++start) {
				int CE = t.m_mapping_.getValue(start);
				if (CE == -268435456) {
					this.m_utilElement_.m_prefix_ = 0;
					this.m_utilElement_.m_uchars_ = UCharacter.toString(start);
					this.m_utilElement_.m_cPoints_ = this.m_utilElement_.m_uchars_;
					this.m_utilElement_.m_cPointsOffset_ = 0;
					this.m_utilElement_.m_CELength_ = 1;
					this.m_utilElement_.m_CEs_[0] = 0;
					this.addAnElement(t, this.m_utilElement_);
				}
			}
		}
	}

	static {
		InverseUCA temp = null;

		try {
			temp = CollatorReader.getInverseUCA();
		} catch (IOException var2) {
			;
		}

		if (temp != null && RuleBasedCollator.UCA_ != null) {
			if (!temp.m_UCA_version_.equals(RuleBasedCollator.UCA_.m_UCA_version_)) {
				throw new RuntimeException("UCA versions of UCA and inverse UCA should match");
			} else {
				INVERSE_UCA_ = temp;
				STRENGTH_MASK_ = new int[]{-65536, -256, -1};
				buildCMTabFlag = false;
			}
		} else {
			throw new RuntimeException("UCA is not instantiated!");
		}
	}
}