package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.AttributeGroupType;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EDataTypeEList;

public class AttributeGroupTypeImpl extends EDataObjectImpl implements AttributeGroupType {
	protected static final String GROUP_NAME_EDEFAULT = null;
	protected String groupName;
	protected EList attributeNames;

	protected AttributeGroupTypeImpl() {
		this.groupName = GROUP_NAME_EDEFAULT;
		this.attributeNames = null;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getAttributeGroupType();
	}

	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String var1) {
		String var2 = this.groupName;
		this.groupName = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.groupName));
		}

	}

	public String[] getAttributeNamesAsArray() {
		List var1 = this.getAttributeNames();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getAttributeNames() {
		if (this.attributeNames == null) {
			this.attributeNames = new EDataTypeEList(String.class, this, 1);
		}

		return this.attributeNames;
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getGroupName();
			case 1 :
				return this.getAttributeNames();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setGroupName((String) var2);
				return;
			case 1 :
				this.getAttributeNames().clear();
				this.getAttributeNames().addAll((Collection) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setGroupName(GROUP_NAME_EDEFAULT);
				return;
			case 1 :
				this.getAttributeNames().clear();
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return GROUP_NAME_EDEFAULT == null
						? this.groupName != null
						: !GROUP_NAME_EDEFAULT.equals(this.groupName);
			case 1 :
				return this.attributeNames != null && !this.attributeNames.isEmpty();
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (groupName: ");
			var1.append(this.groupName);
			var1.append(", attributeNames: ");
			var1.append(this.attributeNames);
			var1.append(')');
			return var1.toString();
		}
	}
}