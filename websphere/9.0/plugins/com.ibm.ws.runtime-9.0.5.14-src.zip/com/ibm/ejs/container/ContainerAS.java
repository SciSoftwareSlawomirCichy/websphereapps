package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.cpi.CPIException;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.EJBKey;
import com.ibm.ws.LocalTransaction.ContainerSynchronization;
import com.ibm.ws.ffdc.FFDCFilter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import javax.transaction.Synchronization;

public class ContainerAS implements Synchronization, ContainerSynchronization {
	private static final String CLASS_NAME = ContainerAS.class.getName();
	private static final TraceComponent tc;
	private static final int ACTIVE = 0;
	private static final int PREPARING = 1;
	private static final String[] stateStrs;
	private EJSContainer ivContainer;
	private HashMap<BeanId, BeanO> ivBeanOs;
	private ArrayList<BeanO> ivBeanOList;
	private int ivState;
	private Object ivASKey;
	private long ivASCacheHits = 0L;
	private long ivASCacheSearch = 0L;

	private final void becomePreparing() {
		if (this.ivState != 0) {
			throw new IllegalStateException(stateStrs[this.ivState]);
		} else {
			this.ivState = 1;
		}
	}

	private final void ensureActive() {
		switch (this.ivState) {
			case 0 :
				return;
			default :
				throw new IllegalStateException(stateStrs[this.ivState]);
		}
	}

	public ContainerAS(EJSContainer container, Object asKey) {
		this.ivContainer = container;
		this.ivASKey = asKey;
		this.ivBeanOs = new HashMap();
		this.ivBeanOList = new ArrayList();
		this.ivState = 0;
	}

	public void beforeCompletion() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "beforeCompletion");
		}

		this.becomePreparing();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "beforeCompletion");
		}

	}

	public void afterCompletion(int status) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "afterCompletion (" + status + ") : " + this);
		}

		try {
			BeanO[] beanOs = this.getBeanOs();
			EJBKey[] ejbKeys = this.getEJBKeys(beanOs);
			if (beanOs != null) {
				for (int i = 0; i < beanOs.length; ++i) {
					BeanO beanO = beanOs[i];

					try {
						this.ivContainer.activator.unitOfWorkEnd(this, beanO);
					} catch (Throwable var12) {
						FFDCFilter.processException(var12, CLASS_NAME + ".afterCompletion", "214", this);
						if (isTraceOn && tc.isEventEnabled()) {
							Tr.event(tc, "Exception thrown in afterCompletion()", new Object[]{beanO, var12});
						}
					}
				}
			}

			this.ivContainer.uowCtrl.sessionEnded(ejbKeys);
			ContainerTx tx = this.ivContainer.getCurrentTx(false);
			if (tx != null) {
				tx.setContainerAS((ContainerAS) null);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "removed ContainerAS during afterCompletion");
				}
			}
		} catch (Throwable var13) {
			FFDCFilter.processException(var13, CLASS_NAME + ".afterCompletion", "219", this);
			if (isTraceOn && tc.isEventEnabled()) {
				Tr.event(tc, "Exception during afterCompletion", var13);
			}

			throw new RuntimeException(var13.toString());
		} finally {
			this.ivContainer.containerASCompleted(this.ivASKey);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "afterCompletion");
		}

	}

	public BeanO find(BeanId beanId) {
		BeanO bean = (BeanO) this.ivBeanOs.get(beanId);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			++this.ivASCacheSearch;
			if (bean != null) {
				++this.ivASCacheHits;
				Tr.debug(tc, "Bean found in ActivitySession cache (Hit Rate:" + this.ivASCacheHits + "/"
						+ this.ivASCacheSearch + ")");
			} else {
				Tr.debug(tc, "Bean not in ActivitySession cache (Hit Rate:" + this.ivASCacheHits + "/"
						+ this.ivASCacheSearch + ")");
			}
		}

		return bean;
	}

	public boolean isEnlisted(BeanId beanId) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "isEnlisted : " + (this.ivBeanOs.get(beanId) != null));
		}

		return this.ivBeanOs.get(beanId) != null;
	}

	public boolean enlist(BeanO beanO) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "enlist : " + beanO);
		}

		this.ensureActive();
		BeanO oldBeanO = (BeanO) this.ivBeanOs.put(beanO.beanId, beanO);
		if (oldBeanO == null) {
			this.ivBeanOList.add(beanO);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "enlist : true");
			}

			return true;
		} else {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "enlist : false");
			}

			return false;
		}
	}

	public void delist(BeanO beanO) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "delist : " + beanO);
		}

		this.ensureActive();
		this.ivBeanOs.remove(beanO.beanId);
		this.ivBeanOList.remove(beanO);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "delist : " + beanO);
		}

	}

	public void registerSynchronization(Synchronization s) throws CPIException {
		try {
			this.ivContainer.uowCtrl.enlistWithSession(s);
		} catch (CSIException var3) {
			throw new CPIException(var3.toString());
		}
	}

	private EJBKey[] getEJBKeys(BeanO[] beans) {
		EJBKey[] result = null;
		if (beans != null) {
			result = new EJBKey[beans.length];

			for (int i = 0; i < beans.length; ++i) {
				result[i] = beans[i].getId();
			}
		}

		return result;
	}

	private BeanO[] getBeanOs() {
		BeanO[] result = new BeanO[this.ivBeanOs.size()];
		Iterator<BeanO> iter = this.ivBeanOs.values().iterator();

		for (int var3 = 0; iter.hasNext(); result[var3++] = (BeanO) iter.next()) {
			;
		}

		return result;
	}

	boolean isBmasActive(EJBMethodInfoImpl methodInfo) {
		return this.ivContainer.uowCtrl.isBmasActive(methodInfo);
	}

	public static ContainerAS getContainerAS(ContainerTx tx) {
		ContainerAS as = null;

		try {
			if (tx != null) {
				as = tx.getContainerAS();
				return as;
			}

			as = getCurrentContainerAS();
		} catch (CSIException var3) {
			FFDCFilter.processException(var3, CLASS_NAME + ".getContainerAS", "402");
			if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
				Tr.event(tc, "Exception thrown getting ContainerAS", var3);
			}
		}

		return as;
	}

	public static ContainerAS getCurrentContainerAS() throws CSIException, CSITransactionRolledbackException {
		EJSContainer container = EJSContainer.getDefaultContainer();
		ContainerAS cas = null;
		cas = container.getCurrentSessionalUOW(false);
		return cas;
	}

	public void setCompleting(boolean isCompleting) {
	}

	public void dump() {
		Tr.dump(tc, "-- ContainerAS Dump --", new Object[]{this, this.ivBeanOs});
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
		stateStrs = new String[]{"Active", "Preparing"};
	}
}