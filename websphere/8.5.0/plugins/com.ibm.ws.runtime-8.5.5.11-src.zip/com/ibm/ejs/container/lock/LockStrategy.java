package com.ibm.ejs.container.lock;

import com.ibm.ejs.container.ContainerTx;
import com.ibm.ejs.container.EJSContainer;

public class LockStrategy {
	public static LockStrategy EXCLUSIVE_LOCK_STRATEGY = new ExclusiveLockStrategy();
	public static LockStrategy NULL_LOCK_STRATEGY = new LockStrategy();

	public boolean lock(EJSContainer c, ContainerTx tx, Object lockName, int mode) throws LockException {
		return true;
	}

	public void unlock(EJSContainer c, Object lockName, Locker locker) {
	}
}