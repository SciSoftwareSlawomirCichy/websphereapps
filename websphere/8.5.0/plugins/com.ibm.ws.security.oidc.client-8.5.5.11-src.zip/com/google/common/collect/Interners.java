package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Interners.1;
import com.google.common.collect.Interners.InternerFunction;
import com.google.common.collect.Interners.WeakInterner;
import java.util.concurrent.ConcurrentMap;

@Beta
public final class Interners {
	public static <E> Interner<E> newStrongInterner() {
      ConcurrentMap<E, E> map = (new MapMaker()).makeMap();
      return new 1(map);
   }

	@GwtIncompatible("java.lang.ref.WeakReference")
   public static <E> Interner<E> newWeakInterner() {
      return new WeakInterner((1)null);
   }

	public static <E> Function<E, E> asFunction(Interner<E> interner) {
		return new InternerFunction((Interner) Preconditions.checkNotNull(interner));
	}
}