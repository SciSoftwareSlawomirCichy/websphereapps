package com.google.inject.internal;

import com.google.inject.internal.AbstractIterator.1;
import com.google.inject.internal.AbstractIterator.State;
import java.util.Iterator;
import java.util.NoSuchElementException;

public abstract class AbstractIterator<T> implements Iterator<T> {
	private State state;
	private T next;

	public AbstractIterator() {
		this.state = State.NOT_READY;
	}

	protected abstract T computeNext();

	protected final T endOfData() {
		this.state = State.DONE;
		return null;
	}

	public boolean hasNext() {
      Preconditions.checkState(this.state != State.FAILED);
      switch(1.$SwitchMap$com$google$inject$internal$AbstractIterator$State[this.state.ordinal()]) {
      case 1:
         return false;
      case 2:
         return true;
      default:
         return this.tryToComputeNext();
      }
   }

	private boolean tryToComputeNext() {
		this.state = State.FAILED;
		this.next = this.computeNext();
		if (this.state != State.DONE) {
			this.state = State.READY;
			return true;
		} else {
			return false;
		}
	}

	public T next() {
		if (!this.hasNext()) {
			throw new NoSuchElementException();
		} else {
			this.state = State.NOT_READY;
			return this.next;
		}
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}
}