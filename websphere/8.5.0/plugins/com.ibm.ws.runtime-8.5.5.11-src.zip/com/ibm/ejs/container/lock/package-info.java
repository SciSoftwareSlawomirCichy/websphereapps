package com.ibm.ejs.container.lock;

interface package-info {
}