package com.ibm.debug;

import com.ibm.bsf.BSFManager;
import com.ibm.debug.DebugAppServerComponentImpl.ActionThread;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.exception.ComponentDisabledException;
import com.ibm.ws.exception.ConfigurationError;
import com.ibm.ws.exception.ConfigurationWarning;
import com.ibm.ws.runtime.component.ComponentImpl;
import com.ibm.ws.runtime.service.EJBContainer;
import com.ibm.ws.webcontainer.WebContainerService;
import java.util.ArrayList;
import java.util.List;

public class DebugAppServerComponentImpl extends ComponentImpl {
	private boolean debugMode = false;
	DebugComponentImpl debugComponentImpl = null;
	public static DebugAgent fDebugAgent;
	public static List debugClassFilters;
	private static final TraceComponent tc = Tr.register(DebugAppServerComponentImpl.class.getName(),
			"DebugAppServerComponent");
	private static ActionThread fActionThread = null;
	private static volatile int fXsltDebugEnabled = 0;
	private static InterruptedException fInterruptedException = new InterruptedException();
	public static final String DEFAULT_FACTORY_KEY = "javax.xml.transform.TransformerFactory";
	public static final String DEBUG_TRANSFORM_CLASS = "com.ibm.debug.xdi.jaxp.xalan.interpreted.DebugTransformerFactory";

	public void setEJBContainer(EJBContainer ejbContainer) {
		if (tc.isDebugEnabled() && TraceComponent.isAnyTracingEnabled()) {
			Tr.debug(tc, "registering EJB Debug Collaborator");
		}

		ejbContainer.addAfterActivationCollaborator(new DebugEJBCollaborator());
		if (tc.isDebugEnabled() && TraceComponent.isAnyTracingEnabled()) {
			Tr.debug(tc, "EJB debug collaborator registered.");
		}

	}

	public void setWebContainer(WebContainerService webContainerService) {
		if (tc.isDebugEnabled() && TraceComponent.isAnyTracingEnabled()) {
			Tr.debug(tc, "registering Web Container Debug Collaborator");
		}

		webContainerService.addWebAppCollaborator(new DebugWebAppInvocationCollaborator());
		if (tc.isDebugEnabled() && TraceComponent.isAnyTracingEnabled()) {
			Tr.debug(tc, "Web Container Debug Collaborator registered");
		}

	}

	public void initialize(Object config) throws ComponentDisabledException, ConfigurationWarning, ConfigurationError {
		if (tc.isEntryEnabled() && TraceComponent.isAnyTracingEnabled()) {
			Tr.entry(tc, "initialize()");
		}

		this.debugMode = Boolean.getBoolean("was.debug.mode");
		if (tc.isDebugEnabled() && TraceComponent.isAnyTracingEnabled()) {
			Tr.debug(tc, "Server debugMode is " + this.debugMode);
		}

		if (!this.debugMode) {
			throw new ComponentDisabledException();
		} else {
			this.debugComponentImpl = (DebugComponentImpl) this.getService(DebugComponentImpl.class);
			if (this.debugComponentImpl != null) {
				List filters = this.debugComponentImpl.getDebugFilterClasses();
				debugClassFilters = new ArrayList();

				for (int i = 0; i < filters.size(); ++i) {
					String filter = (String) filters.get(i);
					debugClassFilters.add(filter);
				}

				this.releaseService(this.debugComponentImpl);
			}

			fDebugAgent = new DebugAgent();
			fDebugAgent.initialize();
			if (this.attachAgentEnabled()) {
				DebugAttachAgent.initialize();
				this.debugAttachAgentIsReady();
			}

			this.performActions();
			if (tc.isEntryEnabled() && TraceComponent.isAnyTracingEnabled()) {
				Tr.exit(tc, "initialize()");
			}

		}
	}

	public void start() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "start");
		}

		if (this.debugMode) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "starting BSFDebugManager");
			}

			DebugComponentImpl debugCI = (DebugComponentImpl) this.getService(DebugComponentImpl.class);
			if (debugCI != null) {
				System.setProperty("com.ibm.bsf.serverPort", String.valueOf(debugCI.getBSFDebugPort()));
				this.releaseService(debugCI);
			}

			BSFManager.initBSFDebugManager();
			this.debugBSFPortisSet();
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "start");
		}

	}

	public void debugBSFPortisSet() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "BSFDebugManager started");
		}

	}

	public void debugAttachAgentIsReady() {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "DebugAttachAgent is ready");
		}

	}

	public boolean attachAgentEnabled() {
		String enabled = System.getProperty("com.ibm.debug.attach.agent.enabled");
		return enabled == null || !enabled.equals("false");
	}

	public void stop() {
	}

	public void destroy() {
	}

	public String getName() {
		return "com.ibm.debug.DebugComponentImpl";
	}

	public String getState() {
		return "working";
	}

	void performActions() {
		if (fXsltDebugEnabled == 1) {
			System.setProperty("javax.xml.transform.TransformerFactory",
					"com.ibm.debug.xdi.jaxp.xalan.interpreted.DebugTransformerFactory");
		} else if (fXsltDebugEnabled == 0 && "com.ibm.debug.xdi.jaxp.xalan.interpreted.DebugTransformerFactory"
				.equals(System.getProperty("javax.xml.transform.TransformerFactory"))) {
			System.clearProperty("javax.xml.transform.TransformerFactory");
		}

		if (fActionThread == null) {
			fActionThread = new ActionThread(this);
			fActionThread.start();
		}

	}
}