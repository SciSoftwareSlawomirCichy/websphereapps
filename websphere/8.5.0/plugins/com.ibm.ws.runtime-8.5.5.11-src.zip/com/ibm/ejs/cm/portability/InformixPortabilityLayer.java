package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.CMPropertiesImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

class InformixPortabilityLayer extends PortabilityLayerImpl {
	private static InformixPortabilityLayer instance;
	private static final TraceComponent tc = Tr.register(InformixPortabilityLayer.class);

	protected InformixPortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.typeMap.setElementAt(" TEXT NOT NULL", 5);
		this.typeMap.setElementAt(" TEXT ", 8);
		this.typeMap.setElementAt(" TEXT NOT NULL", 7);
		this.typeMap.setElementAt(" BYTE ", 9);
		this.typeMap.setElementAt(" BYTE ", 10);
		this.typeMap.setElementAt(" VARCHAR(255) NOT NULL ", 3);
		this.typeMap.setElementAt(" VARCHAR(255) ", 4);
		this.typeMap.setElementAt(" VARCHAR(255) NOT NULL ", 11);
		this.typeMap.setElementAt(" VARCHAR(255) ", 12);
		this.errorMap.put(new Integer(43012), StaleConnectionException.class);
		this.errorMap.put(new Integer(-908), StaleConnectionException.class);
		this.errorMap.put(new Integer(-25580), StaleConnectionException.class);
		this.errorMap.put(new Integer(-27002), StaleConnectionException.class);
		this.errorMap.put(new Integer(-43207), StaleConnectionException.class);
		this.errorMap.put(new Integer(-79716), StaleConnectionException.class);
		this.errorMap.put(new Integer(-79735), StaleConnectionException.class);
		this.errorMap.put(new Integer(-268), DuplicateKeyException.class);
		this.errorMap.put(new Integer(-310), TableAlreadyExistsException.class);
		this.errorMap.put(new Integer(-704), PrimarykeyAlreadyDefinedException.class);
		this.errorMap.put(new Integer(-206), TableDoesNotExistException.class);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public void configureConnection(Connection conn, CMPropertiesImpl props) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "configureConnection", props);
		}

		int seconds = props.getInformixLockModeWait();
		Statement stmt;
		if (seconds > 0) {
			stmt = conn.createStatement();
			stmt.execute("SET LOCK MODE TO WAIT " + seconds);
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Lock mode set to wait " + seconds + " seconds");
			}
		} else if (seconds < 0) {
			stmt = conn.createStatement();
			stmt.execute("SET LOCK MODE TO WAIT");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Lock mode set to wait indefinately");
			}
		} else if (seconds == 0) {
			stmt = conn.createStatement();
			stmt.execute("SET LOCK MODE TO NOT WAIT");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Lock mode set to not wait");
			}
		}

		boolean allowNewLine = props.getInformixAllowNewLine();
		if (allowNewLine) {
			Statement stmt = conn.createStatement();
			stmt.execute("EXECUTE PROCEDURE IFX_ALLOW_NEWLINE('T')");
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Allow New Line set to True.");
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "configureConnection");
		}

	}

	public void setHugeStringForPreparedStatement(HugeString bigstr, PreparedStatement ps, int index)
			throws SQLException {
		ps.setBytes(index, bigstr.getString().getBytes());
	}

	static PortabilityLayer getPortabilityLayer(Connection conn) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getPortabilityLayer in InformixPBL");
		}

		DatabaseMetaData metaData = conn.getMetaData();
		if (metaData != null) {
			String productName = metaData.getDatabaseProductName();
			if (productName != null && productName.equals("INFORMIX-OnLine")) {
				return Informix7PortabilityLayer.getInstance();
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getPortabilityLayer in InformixPBL");
		}

		return getInstance();
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new InformixPortabilityLayer();
		}

		return instance;
	}
}