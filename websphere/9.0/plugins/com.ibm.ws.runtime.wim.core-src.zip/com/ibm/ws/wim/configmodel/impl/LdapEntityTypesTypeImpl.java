package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelFactory;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.LdapEntityTypesType;
import com.ibm.ws.wim.configmodel.RdnAttributesType;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;
import org.eclipse.emf.ecore.util.EDataTypeEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

public class LdapEntityTypesTypeImpl extends EDataObjectImpl implements LdapEntityTypesType {
	protected EList rdnAttributes = null;
	protected EList objectClasses = null;
	protected EList objectClassesForCreate = null;
	protected EList searchBases = null;
	protected static final String NAME_EDEFAULT = null;
	protected String name;
	protected static final String SEARCH_FILTER_EDEFAULT = null;
	protected String searchFilter;

	protected LdapEntityTypesTypeImpl() {
		this.name = NAME_EDEFAULT;
		this.searchFilter = SEARCH_FILTER_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getLdapEntityTypesType();
	}

	public RdnAttributesType[] getRdnAttributesAsArray() {
		List var1 = this.getRdnAttributes();
		return (RdnAttributesType[]) ((RdnAttributesType[]) var1.toArray(new RdnAttributesType[var1.size()]));
	}

	public List getRdnAttributes() {
		if (this.rdnAttributes == null) {
			this.rdnAttributes = new EObjectContainmentEList(RdnAttributesType.class, this, 0);
		}

		return this.rdnAttributes;
	}

	public RdnAttributesType createRdnAttributes() {
		RdnAttributesType var1 = ConfigmodelFactory.eINSTANCE.createRdnAttributesType();
		this.getRdnAttributes().add(var1);
		return var1;
	}

	public String[] getObjectClassesAsArray() {
		List var1 = this.getObjectClasses();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getObjectClasses() {
		if (this.objectClasses == null) {
			this.objectClasses = new EDataTypeEList(String.class, this, 1);
		}

		return this.objectClasses;
	}

	public String[] getObjectClassesForCreateAsArray() {
		List var1 = this.getObjectClassesForCreate();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getObjectClassesForCreate() {
		if (this.objectClassesForCreate == null) {
			this.objectClassesForCreate = new EDataTypeEList(String.class, this, 2);
		}

		return this.objectClassesForCreate;
	}

	public String[] getSearchBasesAsArray() {
		List var1 = this.getSearchBases();
		return (String[]) ((String[]) var1.toArray(new String[var1.size()]));
	}

	public List getSearchBases() {
		if (this.searchBases == null) {
			this.searchBases = new EDataTypeEList(String.class, this, 3);
		}

		return this.searchBases;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		String var2 = this.name;
		this.name = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 4, var2, this.name));
		}

	}

	public String getSearchFilter() {
		return this.searchFilter;
	}

	public void setSearchFilter(String var1) {
		String var2 = this.searchFilter;
		this.searchFilter = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 5, var2, this.searchFilter));
		}

	}

	public NotificationChain eInverseRemove(InternalEObject var1, int var2, Class var3, NotificationChain var4) {
		if (var2 >= 0) {
			switch (this.eDerivedStructuralFeatureID(var2, var3)) {
				case 0 :
					return ((InternalEList) this.getRdnAttributes()).basicRemove(var1, var4);
				default :
					return this.eDynamicInverseRemove(var1, var2, var3, var4);
			}
		} else {
			return this.eBasicSetContainer((InternalEObject) null, var2, var4);
		}
	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getRdnAttributes();
			case 1 :
				return this.getObjectClasses();
			case 2 :
				return this.getObjectClassesForCreate();
			case 3 :
				return this.getSearchBases();
			case 4 :
				return this.getName();
			case 5 :
				return this.getSearchFilter();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getRdnAttributes().clear();
				this.getRdnAttributes().addAll((Collection) var2);
				return;
			case 1 :
				this.getObjectClasses().clear();
				this.getObjectClasses().addAll((Collection) var2);
				return;
			case 2 :
				this.getObjectClassesForCreate().clear();
				this.getObjectClassesForCreate().addAll((Collection) var2);
				return;
			case 3 :
				this.getSearchBases().clear();
				this.getSearchBases().addAll((Collection) var2);
				return;
			case 4 :
				this.setName((String) var2);
				return;
			case 5 :
				this.setSearchFilter((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.getRdnAttributes().clear();
				return;
			case 1 :
				this.getObjectClasses().clear();
				return;
			case 2 :
				this.getObjectClassesForCreate().clear();
				return;
			case 3 :
				this.getSearchBases().clear();
				return;
			case 4 :
				this.setName(NAME_EDEFAULT);
				return;
			case 5 :
				this.setSearchFilter(SEARCH_FILTER_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.rdnAttributes != null && !this.rdnAttributes.isEmpty();
			case 1 :
				return this.objectClasses != null && !this.objectClasses.isEmpty();
			case 2 :
				return this.objectClassesForCreate != null && !this.objectClassesForCreate.isEmpty();
			case 3 :
				return this.searchBases != null && !this.searchBases.isEmpty();
			case 4 :
				return NAME_EDEFAULT == null ? this.name != null : !NAME_EDEFAULT.equals(this.name);
			case 5 :
				return SEARCH_FILTER_EDEFAULT == null
						? this.searchFilter != null
						: !SEARCH_FILTER_EDEFAULT.equals(this.searchFilter);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (objectClasses: ");
			var1.append(this.objectClasses);
			var1.append(", objectClassesForCreate: ");
			var1.append(this.objectClassesForCreate);
			var1.append(", searchBases: ");
			var1.append(this.searchBases);
			var1.append(", name: ");
			var1.append(this.name);
			var1.append(", searchFilter: ");
			var1.append(this.searchFilter);
			var1.append(')');
			return var1.toString();
		}
	}
}