package com.google.common.util.concurrent;

public interface FutureCallback<V> {
	void onSuccess(V var1);

	void onFailure(Throwable var1);
}