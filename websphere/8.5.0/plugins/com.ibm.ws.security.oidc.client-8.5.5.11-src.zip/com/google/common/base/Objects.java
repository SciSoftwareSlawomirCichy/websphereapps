package com.google.common.base;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Objects.1;
import com.google.common.base.Objects.ToStringHelper;
import java.util.Arrays;
import javax.annotation.Nullable;

@GwtCompatible
public final class Objects {
	public static boolean equal(@Nullable Object a, @Nullable Object b) {
		return a == b || a != null && a.equals(b);
	}

	public static int hashCode(@Nullable Object... objects) {
		return Arrays.hashCode(objects);
	}

	public static ToStringHelper toStringHelper(Object self) {
      return new ToStringHelper(simpleName(self.getClass()), (1)null);
   }

	public static ToStringHelper toStringHelper(Class<?> clazz) {
      return new ToStringHelper(simpleName(clazz), (1)null);
   }

	public static ToStringHelper toStringHelper(String className) {
      return new ToStringHelper(className, (1)null);
   }

	private static String simpleName(Class<?> clazz) {
		String name = clazz.getName();
		name = name.replaceAll("\\$[0-9]+", "\\$");
		int start = name.lastIndexOf(36);
		if (start == -1) {
			start = name.lastIndexOf(46);
		}

		return name.substring(start + 1);
	}

	public static <T> T firstNonNull(@Nullable T first, @Nullable T second) {
		return first != null ? first : Preconditions.checkNotNull(second);
	}
}