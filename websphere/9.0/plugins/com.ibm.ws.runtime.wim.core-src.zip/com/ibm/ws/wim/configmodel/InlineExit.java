package com.ibm.ws.wim.configmodel;

public interface InlineExit {
	ModificationSubscriberList getModificationSubscriberList();

	void setModificationSubscriberList(ModificationSubscriberList var1);

	ModificationSubscriberList createModificationSubscriberList();

	String getInlineExitName();

	void setInlineExitName(String var1);
}