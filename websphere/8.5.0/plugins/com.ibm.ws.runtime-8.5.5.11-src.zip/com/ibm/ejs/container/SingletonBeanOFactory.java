package com.ibm.ejs.container;

import com.ibm.ws.managedobject.ManagedObject;

public class SingletonBeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		return new SingletonBeanO(c, mo, b, h);
	}
}