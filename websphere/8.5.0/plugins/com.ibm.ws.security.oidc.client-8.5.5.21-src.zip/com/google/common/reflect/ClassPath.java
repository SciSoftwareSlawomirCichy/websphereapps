package com.google.common.reflect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Splitter;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.UnmodifiableIterator;
import com.google.common.collect.ImmutableSet.Builder;
import com.google.common.reflect.ClassPath.1;
import com.google.common.reflect.ClassPath.ClassInfo;
import com.google.common.reflect.ClassPath.DefaultScanner;
import com.google.common.reflect.ClassPath.ResourceInfo;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.logging.Logger;

@Beta
public final class ClassPath {
	private static final Logger logger = Logger.getLogger(ClassPath.class.getName());
	private static final Predicate<ClassInfo> IS_TOP_LEVEL = new 1();
	private static final Splitter CLASS_PATH_ATTRIBUTE_SEPARATOR = Splitter.on(" ").omitEmptyStrings();
	private static final String CLASS_FILE_NAME_EXTENSION = ".class";
	private final ImmutableSet<ResourceInfo> resources;

	private ClassPath(ImmutableSet<ResourceInfo> resources) {
		this.resources = resources;
	}

	public static ClassPath from(ClassLoader classloader) throws IOException {
		DefaultScanner scanner = new DefaultScanner();
		scanner.scan(classloader);
		return new ClassPath(scanner.getResources());
	}

	public ImmutableSet<ResourceInfo> getResources() {
		return this.resources;
	}

	public ImmutableSet<ClassInfo> getAllClasses() {
		return FluentIterable.from(this.resources).filter(ClassInfo.class).toSet();
	}

	public ImmutableSet<ClassInfo> getTopLevelClasses() {
		return FluentIterable.from(this.resources).filter(ClassInfo.class).filter(IS_TOP_LEVEL).toSet();
	}

	public ImmutableSet<ClassInfo> getTopLevelClasses(String packageName) {
		Preconditions.checkNotNull(packageName);
		Builder<ClassInfo> builder = ImmutableSet.builder();
		UnmodifiableIterator var3 = this.getTopLevelClasses().iterator();

		while (var3.hasNext()) {
			ClassInfo classInfo = (ClassInfo) var3.next();
			if (classInfo.getPackageName().equals(packageName)) {
				builder.add(classInfo);
			}
		}

		return builder.build();
	}

	public ImmutableSet<ClassInfo> getTopLevelClassesRecursive(String packageName) {
		Preconditions.checkNotNull(packageName);
		String packagePrefix = packageName + '.';
		Builder<ClassInfo> builder = ImmutableSet.builder();
		UnmodifiableIterator var4 = this.getTopLevelClasses().iterator();

		while (var4.hasNext()) {
			ClassInfo classInfo = (ClassInfo) var4.next();
			if (classInfo.getName().startsWith(packagePrefix)) {
				builder.add(classInfo);
			}
		}

		return builder.build();
	}

	@VisibleForTesting
	static String getClassName(String filename) {
		int classNameEnd = filename.length() - ".class".length();
		return filename.substring(0, classNameEnd).replace('/', '.');
	}

	@VisibleForTesting
	static File toFile(URL url) {
		Preconditions.checkArgument(url.getProtocol().equals("file"));

		try {
			return new File(url.toURI());
		} catch (URISyntaxException var2) {
			return new File(url.getPath());
		}
	}
}