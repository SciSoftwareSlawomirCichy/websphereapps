package com.ibm.ws.wim.management;

public interface EventHandler {
	String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";

	void processEvent(String var1, EventDataWrapper var2);

	boolean isListeningToEvent(String var1);

	String[] getEventProcessList();
}