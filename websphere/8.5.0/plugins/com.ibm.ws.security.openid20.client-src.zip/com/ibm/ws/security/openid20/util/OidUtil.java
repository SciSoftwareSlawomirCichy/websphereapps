package com.ibm.ws.security.openid20.util;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.security.openid20.client.OpenIDRelyingPartyException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

public class OidUtil {
	private static final TraceComponent tc = Tr.register(OidUtil.class, "OpenIDClient",
			"com.ibm.ws.security.openid20.client.resources.oidmessages");
	private static final String[] TRUE_VALUES = new String[]{"yes", "on", "true", "1"};
	private static final String[] FALSE_VALUES = new String[]{"no", "off", "false", "0"};

	public static ArrayList<String> getUris(Properties props, String propertyName, String defaultValue)
			throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getUris(props[" + getObjState(props) + "],propertyName[" + propertyName + "],defaultValue["
					+ defaultValue + "])");
		}

		String plists = getProperty(props, propertyName, defaultValue);
		ArrayList<String> uris = parseUris(plists);
		if (uris == null) {
			String msg = MessageHelper.getMessage("security.oidc.client.missingproperty", propertyName);
			Tr.error(tc, msg);
			throw new OpenIDRelyingPartyException(msg);
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getUris returns array with size [" + uris.size() + "]");
			}

			return uris;
		}
	}

	public static ArrayList<String> getUris(Properties props, String propertyName) throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getUris(props[" + getObjState(props) + "],propertyName[" + propertyName + "])");
		}

		String plists = getOptionalProperty(props, propertyName, false);
		ArrayList<String> uris = parseUris(plists);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getUris returns array [" + getObjState(uris) + "]");
		}

		return uris;
	}

	private static ArrayList<String> parseUris(String uris) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "parseUris(uris[" + uris + "])");
		}

		ArrayList<String> listUris = new ArrayList();
		if (uris != null) {
			if (uris.indexOf(",") != -1) {
				StringTokenizer st = new StringTokenizer(uris, ",");

				while (st.hasMoreTokens()) {
					String token = st.nextToken();
					listUris.add(token.replaceAll(" ", ""));
				}
			} else {
				listUris.add(uris.replaceAll(" ", ""));
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "parseUris returns array size = [" + listUris.size() + "]");
		}

		return listUris;
	}

	public static String[] split(String origStr, String delimiter) throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "split(origStr[" + getObjState(origStr) + "],delimiter[" + delimiter + "])");
		}

		String[] resp = origStr.split(delimiter);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "split returns array with length [" + resp.length + "]");
		}

		return resp;
	}

	public static String[] split(String origStr, String delimiter, int limit) throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc,
					"split(origStr[" + getObjState(origStr) + "],delimiter[" + delimiter + "],limit[" + limit + "])");
		}

		String[] resp = origStr.split(delimiter, limit);
		int checklimit = limit == 0 ? 2 : limit;
		if (resp.length < checklimit) {
			if (tc.isDebugEnabled()) {
				Tr.debug(tc, "Could not split the string [" + origStr + "] correctly");
			}

			throw new OpenIDRelyingPartyException("Could not split the string [" + origStr + "] correctly");
		} else {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "split returns array with length [" + resp.length + "]");
			}

			return resp;
		}
	}

	public static boolean isTrue(String flag) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isTrue(String flag[" + flag + "])");
		}

		boolean ret = false;
		if (flag != null) {
			flag = flag.trim();

			for (int i = 0; i < TRUE_VALUES.length; ++i) {
				if (TRUE_VALUES[i].equalsIgnoreCase(flag)) {
					ret = true;
					break;
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isTrue(String) returns boolean[" + ret + "]");
		}

		return ret;
	}

	public static boolean isFalse(String flag) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "isFalse(String flag[" + flag + "])");
		}

		boolean ret = false;
		if (flag != null) {
			flag = flag.trim();

			for (int i = 0; i < FALSE_VALUES.length; ++i) {
				if (FALSE_VALUES[i].equalsIgnoreCase(flag)) {
					ret = true;
					break;
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "isFalse returns [" + ret + "]");
		}

		return ret;
	}

	public static boolean hasValue(String str) {
		return str != null && str.length() > 0;
	}

	public static boolean hasValue(char[] str) {
		return str != null && str.length > 0;
	}

	public static String getNonBlankString(String str) {
		String retVal = null;
		if (str != null) {
			retVal = str.trim();
			if (str.length() == 0) {
				retVal = null;
			}
		}

		return retVal;
	}

	public static String getProperty(Map<String, String> _map, String propName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProperty(_map, " + propName + ")");
		}

		String propValue = (String) _map.get(propName);
		String retVal = null;
		if (hasValue(propValue)) {
			retVal = propValue;
		}

		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProperty returns [" + retVal + "]");
		}

		return retVal;
	}

	public static boolean getIsTrueProperty(Map<?, ?> _map, String propName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getIsTrueProperty(_map, " + propName + ")");
		}

		String propValue = (String) _map.get(propName);
		boolean retVal = false;
		if (hasValue(propValue) && isTrue(propValue)) {
			retVal = true;
		}

		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getIsTrueProperty returns [" + retVal + "]");
		}

		return retVal;
	}

	public static boolean getIsFalseProperty(Map<?, ?> _map, String propName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getIsFalseProperty(_map, " + propName + ")");
		}

		String propValue = (String) _map.get(propName);
		boolean retVal = true;
		if (hasValue(propValue) && isFalse(propValue)) {
			retVal = false;
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getIsFalseProperty returns [" + retVal + "]");
		}

		return retVal;
	}

	public static long processLongProperty(String propName, String strValue, long defValue) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "processLongProperty(propName='" + propName + "', strValue='" + strValue + "', defValue="
					+ defValue);
		}

		long retValue = defValue;
		String tmpValue = getNonBlankString(strValue);
		if (tmpValue != null) {
			try {
				retValue = Long.parseLong(tmpValue);
			} catch (Throwable var8) {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "'" + strValue + "' is not a valid number. " + "The default value, " + defValue
							+ ", will be used for " + propName + ".");
				}
			}
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "processLongProperty returns " + retValue);
		}

		return retValue;
	}

	public static String getObjState(Object inObj) {
		String returnString = inObj == null ? "null" : "not null";
		return returnString;
	}

	public static String getObjType(Object inObj) {
		String returnString = inObj == null ? "null" : inObj.getClass().getName();
		return returnString;
	}

	public static String getProperty(Properties props, String propertyName, String defaultValue)
			throws OpenIDRelyingPartyException {
		return getProperty(props, propertyName, defaultValue, false);
	}

	public static String getProperty(Properties props, String propertyName, String defaultValue, boolean secret)
			throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProperty(props[" + getObjState(props) + "],propertyName[" + propertyName
					+ "],defaultValue[" + defaultValue + "],secret[" + secret + "])");
		}

		if (props != null && propertyName != null) {
			String propertyValue = props.getProperty(propertyName, defaultValue);
			if (!hasValue(propertyValue)) {
				String msg = MessageHelper.getMessage("security.openid20.client.missingproperty", propertyName);
				Tr.error(tc, msg);
				throw new OpenIDRelyingPartyException(msg);
			} else {
				if (tc.isEntryEnabled()) {
					if (secret) {
						Tr.exit(tc, "getProperty returns [" + getObjState(propertyValue) + "]");
					} else {
						Tr.exit(tc, "getProperty returns [" + propertyValue + "]");
					}
				}

				return propertyValue;
			}
		} else {
			throw new OpenIDRelyingPartyException("One or more parameters passed to this method is null");
		}
	}

	public static String getOptionalProperty(Properties props, String propertyName, boolean secret)
			throws OpenIDRelyingPartyException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getProperty(props[" + getObjState(props) + "],propertyName[" + propertyName + "],secret["
					+ secret + "])");
		}

		if (props != null && propertyName != null) {
			String propertyValue = props.getProperty(propertyName);
			if (tc.isEntryEnabled()) {
				if (secret) {
					Tr.exit(tc, "getProperty returns [" + getObjState(propertyValue) + "]");
				} else {
					Tr.exit(tc, "getProperty returns [" + propertyValue + "]");
				}
			}

			return propertyValue;
		} else {
			throw new OpenIDRelyingPartyException("One or more parameters passed to this method is null");
		}
	}

	public static String getSecretProperty(Properties props, String propertyName, String defaultValue)
			throws OpenIDRelyingPartyException {
		return getProperty(props, propertyName, defaultValue, true);
	}
}