package com.ibm.ws.wim.xpath.mapping.datatype;

import java.util.HashMap;
import java.util.Iterator;

public class LogicalNode implements XPathLogicalNode {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String operator = null;
	private Object leftChild = null;
	private Object rightChild = null;
	boolean inRepos = true;

	public void setOperator(String var1) {
		this.operator = var1;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setLeftChild(Object var1) {
		this.leftChild = var1;
	}

	public Object getLeftChild() {
		return this.leftChild;
	}

	public void setRightChild(Object var1) {
		this.rightChild = var1;
	}

	public Object getRightChild() {
		return this.rightChild;
	}

	public short getNodeType() {
		return 1;
	}

	public Iterator getPropertyNodes(HashMap var1) {
		HashMap var2 = var1;
		if (var1 == null) {
			var2 = new HashMap();
		}

		((XPathNode) this.leftChild).getPropertyNodes(var2);
		return ((XPathNode) this.rightChild).getPropertyNodes(var2);
	}

	public void setPropertyLocation(boolean var1) {
		this.inRepos = var1;
	}

	public boolean isPropertyInRepository() {
		return this.inRepos;
	}

	public String toString() {
		StringBuffer var1 = new StringBuffer();
		var1 = var1.append(this.leftChild.toString() + " " + this.operator + " " + this.rightChild.toString());
		return var1.toString();
	}
}