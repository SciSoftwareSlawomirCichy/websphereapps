package com.ibm.ejs.oa;

public class InvalidUserKeyException extends Exception {
	private static final long serialVersionUID = 8749153380997311402L;

	public InvalidUserKeyException() {
	}

	public InvalidUserKeyException(String message) {
		super(message);
	}
}