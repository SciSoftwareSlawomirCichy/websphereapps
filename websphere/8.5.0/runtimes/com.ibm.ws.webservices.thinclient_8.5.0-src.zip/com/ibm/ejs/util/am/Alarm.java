package com.ibm.ejs.util.am;

public interface Alarm {
	void cancel();
}