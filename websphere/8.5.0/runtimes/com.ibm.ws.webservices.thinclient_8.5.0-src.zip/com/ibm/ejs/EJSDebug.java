package com.ibm.ejs;

public interface EJSDebug {
	boolean EJSDEBUG = false;
}