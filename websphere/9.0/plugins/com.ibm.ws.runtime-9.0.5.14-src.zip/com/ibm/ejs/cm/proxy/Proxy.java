package com.ibm.ejs.cm.proxy;

import com.ibm.ejs.cm.exception.ConnectionPoolInternalErrorException;
import com.ibm.ejs.cm.exception.IllegalConnectionUseException;
import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.sql.SQLException;
import java.util.ArrayList;

public abstract class Proxy {
	protected final ConnectO invoker;
	private ArrayList children;
	protected Proxy parent;
	private int state = 0;
	private Boolean proxyInUse;
	private boolean isConnClosing;
	private boolean isParentClosing;
	private boolean isRolledBack;
	private boolean isDestroyed;
	private static final int OPEN = 0;
	private static final int CLOSED = 1;
	protected Object lockObject;
	private static final String[] stateStrings = new String[]{"OPEN", "CLOSED"};
	private static final TraceComponent tc = Tr.register(Proxy.class);

	protected Proxy(ConnectO invoker) {
		this.proxyInUse = Boolean.FALSE;
		this.isConnClosing = false;
		this.isParentClosing = false;
		this.isRolledBack = false;
		this.isDestroyed = false;
		this.lockObject = null;
		this.invoker = invoker;
	}

	protected Proxy(Proxy parent) {
		this.proxyInUse = Boolean.FALSE;
		this.isConnClosing = false;
		this.isParentClosing = false;
		this.isRolledBack = false;
		this.isDestroyed = false;
		this.lockObject = null;
		this.parent = parent;
		parent.addChild(this);
		this.invoker = parent.invoker;
	}

	public boolean isClosed() throws SQLException {
		return this.state == 1;
	}

	public void close() throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "close");
		}

		SQLException caughtException = null;
		if (this.isClosed()) {
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "close");
			}

		} else {
			boolean internalError = false;
			boolean connectionUseError = false;

			try {
				if (this.children != null) {
					this.isParentClosing = true;
					if (tc.isEventEnabled()) {
						Tr.event(tc, "Closing a proxy's children proxies");
					}

					int vSize = this.children.size();

					for (int i = 0; i < vSize; ++i) {
						try {
							if (tc.isEventEnabled()) {
								Tr.event(tc, "Close child proxy", (Proxy) this.children.get(i));
							}

							((Proxy) this.children.get(i)).closeFromParent();
							if (tc.isEventEnabled()) {
								Tr.event(tc, "Done closing child proxy");
							}
						} catch (SQLException var11) {
							if (caughtException == null) {
								caughtException = this.translateException(var11);
							}
						} catch (Exception var12) {
							internalError = true;
							if (tc.isEventEnabled()) {
								Tr.event(tc, "Internal error", var12);
							}
						}
					}

					this.isParentClosing = false;
				}
			} finally {
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "Mark proxy closed");
				}

				this.state = 1;
				this.children = null;
				if (this.parent != null && !this.parent.isConnClosing && !this.parent.isParentClosing) {
					this.parent.removeChild(this);
				}

			}

			if (caughtException != null) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "close");
				}

				throw caughtException;
			} else if (internalError) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "close");
				}

				throw new ConnectionPoolInternalErrorException("Error occurred while closing Proxy children");
			} else if (connectionUseError) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "close");
				}

				throw new IllegalConnectionUseException();
			} else {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "close");
				}

			}
		}
	}

	protected void closeFromParent() throws SQLException {
		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "in closeFromParent on Proxy, you should never get here!!");
		}

	}

	public final String toString() {
		return this.getClass().getName() + "@" + System.identityHashCode(this) + " [" + this.getStateString() + "]";
	}

	protected final void __preInvoke() throws SQLException {
		this.__preInvoke(false);
	}

	protected final void __preInvoke(boolean enlist) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "__preInvoke", new Boolean(enlist));
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "state: ", this.getStateString());
		}

		switch (this.state) {
			case 0 :
				this.invoker.preInvoke(enlist);
				this.proxyInUse = Boolean.TRUE;
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "__preInvoke");
				}

				return;
			case 1 :
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "__preInvoke: Proxy is closed");
				}

				throw new StaleConnectionException(this.getClass() + " is closed");
			default :
				throw new Error("Illegal state");
		}
	}

	protected final void __postInvoke(SQLException e) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "__postInvoke");
		}

		if (tc.isDebugEnabled()) {
			Tr.debug(tc, "state: ", this.getStateString());
		}

		switch (this.state) {
			case 0 :
				this.invoker.postInvoke(e);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "__postInvoke: Proxy is no longer in use " + new Object[]{this});
				}

				this.proxyInUse = Boolean.FALSE;
				break;
			case 1 :
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "__postInvoke: Proxy is closed");
				}
				break;
			default :
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "__postInvoke - Illegal state");
				}
		}

	}

	protected final Proxy getParent() {
		return this.parent;
	}

	private final void addChild(Proxy child) {
		synchronized (this.getLockObject()) {
			if (this.children == null) {
				this.children = new ArrayList(5);
			}

			this.children.add(child);
		}
	}

	private final void removeChild(Proxy child) {
		synchronized (this.getLockObject()) {
			if (this.children != null) {
				this.children.remove(child);
				if (tc.isDebugEnabled()) {
					Tr.debug(tc, "remove child from parent's array list !");
				}
			}

		}
	}

	public SQLException translateException(SQLException sqle) throws SQLException {
		return this.invoker.translateException(sqle);
	}

	private final String getStateString() {
		return stateStrings[this.state];
	}

	protected final void setisRolledBack(boolean txRB) {
		this.isRolledBack = txRB;
	}

	public void setDestroyedProxy() {
		this.isDestroyed = true;
		if (tc.isEventEnabled()) {
			Tr.event(tc, "setDestroyedProxy ");
		}

	}

	protected Object getLockObject() {
		return this.parent == null ? null : this.parent.getLockObject();
	}

	public void setisConnClosing(boolean b) {
		this.isConnClosing = b;
		if (tc.isEventEnabled()) {
			Tr.event(tc, "isConnClosing is being set to " + b);
		}

	}
}