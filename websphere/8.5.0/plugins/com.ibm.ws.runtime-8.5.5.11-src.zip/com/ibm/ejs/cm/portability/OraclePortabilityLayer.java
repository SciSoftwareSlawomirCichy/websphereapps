package com.ibm.ejs.cm.portability;

import com.ibm.ejs.cm.CMPropertiesImpl;
import com.ibm.ejs.cm.DataSourceProperties;
import com.ibm.ejs.cm.pool.ConnectO;
import com.ibm.ejs.cm.proxy.ConnectionProxy;
import com.ibm.ejs.cm.proxy.OracleConnectionProxy;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.ce.cm.StaleConnectionException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.PooledConnection;
import javax.sql.XAConnection;

public class OraclePortabilityLayer extends PortabilityLayerImpl {
	private static OraclePortabilityLayer instance;
	private static Method stmtCacheSizeMethod = null;
	private static final TraceComponent tc = Tr.register(OraclePortabilityLayer.class, (String) null,
			"com.ibm.ejs.resources.CONMMessages");

	protected OraclePortabilityLayer() {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "<init>");
		}

		this.errorMap.put(new Integer(1), DuplicateKeyException.class);
		this.errorMap.put(new Integer(955), TableAlreadyExistsException.class);
		this.errorMap.put(new Integer(2260), PrimarykeyAlreadyDefinedException.class);
		this.errorMap.put(new Integer(942), TableDoesNotExistException.class);
		this.errorMap.put(new Integer(1000), ResourceAllocationException.class);
		this.errorMap.put(new Integer(20), ResourceAllocationException.class);
		this.errorMap.put(new Integer(28), StaleConnectionException.class);
		this.errorMap.put(new Integer(1012), StaleConnectionException.class);
		this.errorMap.put(new Integer(1014), StaleConnectionException.class);
		this.errorMap.put(new Integer(1033), StaleConnectionException.class);
		this.errorMap.put(new Integer(1034), StaleConnectionException.class);
		this.errorMap.put(new Integer(1035), StaleConnectionException.class);
		this.errorMap.put(new Integer(1089), StaleConnectionException.class);
		this.errorMap.put(new Integer(1090), StaleConnectionException.class);
		this.errorMap.put(new Integer(1092), StaleConnectionException.class);
		this.errorMap.put(new Integer(2068), StaleConnectionException.class);
		this.errorMap.put(new Integer(3113), StaleConnectionException.class);
		this.errorMap.put(new Integer(3114), StaleConnectionException.class);
		this.errorMap.put(new Integer(12541), StaleConnectionException.class);
		this.errorMap.put(new Integer(12560), StaleConnectionException.class);
		this.errorMap.put(new Integer(12571), StaleConnectionException.class);
		this.errorMap.put(new Integer(17002), StaleConnectionException.class);
		this.errorMap.put(new Integer(17008), StaleConnectionException.class);
		this.errorMap.put(new Integer(17009), StaleConnectionException.class);
		this.errorMap.put(new Integer(17410), StaleConnectionException.class);
		this.errorMap.put(new Integer(17401), StaleConnectionException.class);
		this.errorMap.put(new Integer(17430), StaleConnectionException.class);
		this.errorMap.put(new Integer(25408), StaleConnectionException.class);
		this.errorMap.put("Connection reset by peer", StaleConnectionException.class);
		this.typeMap.setElementAt(" LONG NOT NULL ", 7);
		this.typeMap.setElementAt(" LONG ", 8);
		this.typeMap.setElementAt(" LONG RAW ", 9);
		this.typeMap.setElementAt(" RAW(2000) ", 10);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>");
		}

	}

	public boolean checkCMPStoreOperation(String beanId, Connection c, boolean loadedForUpdate) throws SQLException {
		boolean logged = false;
		if (!loadedForUpdate && c.getTransactionIsolation() == 2) {
			logged = true;
			Tr.service(tc, "MSG_CONM_7009W", beanId);
		}

		return logged;
	}

	public void setTransactionIsolation(Connection connection, int isolationLevel) throws SQLException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "setTransactionIsolation", new Object[]{connection, new Integer(isolationLevel)});
		}

		switch (isolationLevel) {
			case 1 :
				isolationLevel = 2;
				break;
			case 4 :
				isolationLevel = 8;
		}

		super.setTransactionIsolation(connection, isolationLevel);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "setTransactionIsolation");
		}

	}

	public void configurePooledConnection(PooledConnection pconn, CMPropertiesImpl props) throws SQLException {
		this.setStmtCacheSize(pconn, props);
	}

	public void configureXAConnection(XAConnection xaconn, CMPropertiesImpl props) throws SQLException {
		this.setStmtCacheSize(xaconn, props);
	}

	private void setStmtCacheSize(Object conn, CMPropertiesImpl props) throws SQLException {
		int cacheSize = props.getOracleStmtCacheSize();
		if (cacheSize != 0) {
			try {
				if (stmtCacheSizeMethod == null) {
					Class connClass = conn.getClass();
					stmtCacheSizeMethod = connClass.getMethod("setStmtCacheSize", Integer.TYPE);
				}

				stmtCacheSizeMethod.invoke(conn, new Integer(cacheSize));
			} catch (NoSuchMethodException var7) {
				Tr.error(tc, "MSG_CONM_7003W", new Object[]{"stmtCacheSize", conn.getClass()});
				throw new SQLException("NoSuchMethodException: " + var7.getMessage());
			} catch (IllegalAccessException var8) {
				Tr.error(tc, "MSG_CONM_7004W",
						new Object[]{"stmtCacheSize", conn.getClass(), "IllegalAccessException: " + var8.getMessage()});
				throw new SQLException("IllegalAccessException: " + var8.getMessage());
			} catch (InvocationTargetException var9) {
				Throwable target = var9.getTargetException();
				String text = target.getClass().getName() + ": " + target.getMessage();
				Tr.error(tc, "MSG_CONM_7004W", new Object[]{"stmtCacheSize", conn.getClass(), text});
				throw new SQLException(text);
			}
		}
	}

	public int getPreferredIsolationLevel() {
		return 2;
	}

	public ConnectionProxy createConnectionProxy(ConnectO connection) {
		return new OracleConnectionProxy(connection);
	}

	public static PortabilityLayer getInstance(DataSourceProperties dsProps) throws SQLException {
		if (instance == null) {
			instance = new OraclePortabilityLayer();
		}

		return instance;
	}

	public static PortabilityLayer getInstance() throws SQLException {
		if (instance == null) {
			instance = new OraclePortabilityLayer();
		}

		return instance;
	}
}