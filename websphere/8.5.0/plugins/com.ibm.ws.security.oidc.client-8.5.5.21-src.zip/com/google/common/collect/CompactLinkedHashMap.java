package com.google.common.collect;

import com.google.common.annotations.GwtIncompatible;
import com.google.common.annotations.VisibleForTesting;
import java.util.Arrays;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;

@GwtIncompatible
class CompactLinkedHashMap<K, V> extends CompactHashMap<K, V> {
	private static final int ENDPOINT = -2;
	@MonotonicNonNullDecl
	@VisibleForTesting
	transient long[] links;
	private transient int firstEntry;
	private transient int lastEntry;
	private final boolean accessOrder;

	public static <K, V> CompactLinkedHashMap<K, V> create() {
		return new CompactLinkedHashMap();
	}

	public static <K, V> CompactLinkedHashMap<K, V> createWithExpectedSize(int expectedSize) {
		return new CompactLinkedHashMap(expectedSize);
	}

	CompactLinkedHashMap() {
		this(3);
	}

	CompactLinkedHashMap(int expectedSize) {
		this(expectedSize, 1.0F, false);
	}

	CompactLinkedHashMap(int expectedSize, float loadFactor, boolean accessOrder) {
		super(expectedSize, loadFactor);
		this.accessOrder = accessOrder;
	}

	void init(int expectedSize, float loadFactor) {
		super.init(expectedSize, loadFactor);
		this.firstEntry = -2;
		this.lastEntry = -2;
		this.links = new long[expectedSize];
		Arrays.fill(this.links, -1L);
	}

	private int getPredecessor(int entry) {
		return (int) (this.links[entry] >>> 32);
	}

	int getSuccessor(int entry) {
		return (int) this.links[entry];
	}

	private void setSuccessor(int entry, int succ) {
		long succMask = 4294967295L;
		this.links[entry] = this.links[entry] & ~succMask | (long) succ & succMask;
	}

	private void setPredecessor(int entry, int pred) {
		long predMask = -4294967296L;
		this.links[entry] = this.links[entry] & ~predMask | (long) pred << 32;
	}

	private void setSucceeds(int pred, int succ) {
		if (pred == -2) {
			this.firstEntry = succ;
		} else {
			this.setSuccessor(pred, succ);
		}

		if (succ == -2) {
			this.lastEntry = pred;
		} else {
			this.setPredecessor(succ, pred);
		}

	}

	void insertEntry(int entryIndex, K key, V value, int hash) {
		super.insertEntry(entryIndex, key, value, hash);
		this.setSucceeds(this.lastEntry, entryIndex);
		this.setSucceeds(entryIndex, -2);
	}

	void accessEntry(int index) {
		if (this.accessOrder) {
			this.setSucceeds(this.getPredecessor(index), this.getSuccessor(index));
			this.setSucceeds(this.lastEntry, index);
			this.setSucceeds(index, -2);
			++this.modCount;
		}

	}

	void moveLastEntry(int dstIndex) {
		int srcIndex = this.size() - 1;
		this.setSucceeds(this.getPredecessor(dstIndex), this.getSuccessor(dstIndex));
		if (dstIndex < srcIndex) {
			this.setSucceeds(this.getPredecessor(srcIndex), dstIndex);
			this.setSucceeds(dstIndex, this.getSuccessor(srcIndex));
		}

		super.moveLastEntry(dstIndex);
	}

	void resizeEntries(int newCapacity) {
		super.resizeEntries(newCapacity);
		this.links = Arrays.copyOf(this.links, newCapacity);
	}

	int firstEntryIndex() {
		return this.firstEntry;
	}

	int adjustAfterRemove(int indexBeforeRemove, int indexRemoved) {
		return indexBeforeRemove >= this.size() ? indexRemoved : indexBeforeRemove;
	}

	public void clear() {
		super.clear();
		this.firstEntry = -2;
		this.lastEntry = -2;
	}
}