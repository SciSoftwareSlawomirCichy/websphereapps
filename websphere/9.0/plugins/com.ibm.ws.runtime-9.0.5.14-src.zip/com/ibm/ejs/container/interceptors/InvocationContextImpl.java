package com.ibm.ejs.container.interceptors;

import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSDeployedSupport;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.csi.EJBModuleMetaDataImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.ws.managedobject.ConstructionCallback;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.managedobject.ManagedObjectContext;
import com.ibm.ws.managedobject.ManagedObjectInvocationContext;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.Arrays;
import java.util.Map;
import javax.ejb.EJBException;
import javax.ejb.Timer;
import javax.interceptor.InvocationContext;

public class InvocationContextImpl<T> implements InvocationContext, ManagedObjectInvocationContext<T> {
	private static final TraceComponent tc = Tr.register(InvocationContextImpl.class, "EJB3Interceptors",
			"com.ibm.ejs.container.container");
	private Method ivMethod;
	private T ivBean;
	private Object[] ivParameters = new Object[0];
	private Timer ivTimer;
	private InterceptorProxy[] ivInterceptorProxies;
	private int ivNextIndex;
	private int ivNumberOfInterceptors;
	private Object[] ivInterceptors;
	private boolean ivParametersModified = false;
	private EJSDeployedSupport ivEJSDeployedSupport;
	private final EJSContainer ivContainer = EJSContainer.getDefaultContainer();
	private ConstructionCallback<T> ivConstructCallback;
	private boolean ivIsAroundConstruct;
	public Exception ivAroundConstructException;
	private ManagedObjectContext ivManagedObjectContext;

	public void initialize(T bean, ManagedObjectContext managedObjectContext, Object[] interceptors) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "initialize for bean = " + bean + ", context = " + managedObjectContext + ", interceptors = "
					+ Arrays.toString(interceptors));
		}

		this.ivBean = bean;
		this.ivManagedObjectContext = managedObjectContext;
		this.ivInterceptors = interceptors;
		this.ivInterceptorProxies = null;
		this.ivTimer = null;
	}

	public void setTimer(Timer timer) {
		this.ivTimer = timer;
	}

	public void initializeForAroundConstruct(ManagedObjectContext managedObjectContext, Object[] interceptors,
			InterceptorProxy[] proxies) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "initializeForAroundConstruct : context = " + managedObjectContext + " interceptors = "
					+ Arrays.toString(interceptors) + ", proxies = " + Arrays.toString(proxies));
		}

		this.ivBean = null;
		this.ivManagedObjectContext = managedObjectContext;
		this.ivInterceptors = interceptors;
		this.ivInterceptorProxies = proxies;
		this.ivTimer = null;
	}

	public T aroundConstruct(ConstructionCallback<T> constructionCallback, Object[] parameters,
			Map<String, Object> data) throws Exception {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "aroundConstruct : " + constructionCallback + ", " + Util.identity(parameters) + ", " + data);
		}

		Object var5;
		try {
			this.ivConstructCallback = constructionCallback;
			this.ivParameters = parameters;
			this.ivIsAroundConstruct = true;
			if (data != null && data.size() > 0) {
				this.getContextData().putAll(data);
			}

			this.doAroundInterceptor();
			var5 = this.ivBean;
		} finally {
			this.ivConstructCallback = null;
			this.ivParameters = null;
			this.ivIsAroundConstruct = false;
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "aroundConstruct");
			}

		}

		return var5;
	}

	public Object doAroundInvoke(InterceptorProxy[] proxies, Method businessMethod, Object[] parameters,
			EJSDeployedSupport s) throws Exception {
		this.ivMethod = businessMethod;
		this.ivParameters = parameters;
		this.ivEJSDeployedSupport = s;
		this.ivInterceptorProxies = proxies;
		this.ivIsAroundConstruct = false;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "doAroundInvoke for business method: " + this.ivMethod.getName());
		}

		Object var5;
		try {
			var5 = this.doAroundInterceptor();
		} finally {
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "doAroundInvoke for business method: " + this.ivMethod.getName());
			}

			this.ivMethod = null;
			this.ivParameters = null;
		}

		return var5;
	}

	private Object doAroundInterceptor() throws Exception {
		this.ivNextIndex = 0;
		this.ivNumberOfInterceptors = this.ivInterceptorProxies == null ? 0 : this.ivInterceptorProxies.length;
		this.ivParametersModified = false;
		return this.proceed();
	}

	public void doLifeCycle(InterceptorProxy[] proxies, EJBModuleMetaDataImpl mmd) {
		this.ivMethod = null;
		this.ivParameters = null;
		this.ivInterceptorProxies = proxies;
		this.ivNumberOfInterceptors = this.ivInterceptorProxies.length;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "doLifeCycle, number of interceptors = " + this.ivNumberOfInterceptors);
		}

		if (this.ivNumberOfInterceptors > 0) {
			this.ivNextIndex = 0;

			try {
				this.proceed();
			} catch (Throwable var7) {
				this.lifeCycleExceptionHandler(var7, mmd);
			} finally {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "doLifeCycle");
				}

			}
		}

	}

	private void lifeCycleExceptionHandler(Throwable t, EJBModuleMetaDataImpl mmd) {
		if (t instanceof RuntimeException) {
			RuntimeException rtex = (RuntimeException) t;
			if (mmd.getApplicationExceptionRollback(rtex) != null) {
				InterceptorProxy w = this.ivInterceptorProxies[this.ivNextIndex - 1];
				String lifeCycle = w.getMethodGenericString();
				EJBException ex = ExceptionUtil
						.EJBException(lifeCycle + " is not allowed to throw an application exception", rtex);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "lifeCycleExceptionHandler throwing EJBException", ex);
				}

				throw ex;
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc,
							"lifeCycleExceptionHandler is rethrowing RuntimeException from lifecycle callback method: "
									+ t,
							t);
				}

				throw rtex;
			}
		} else if (t instanceof Error) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "lifeCycleExceptionHandler is rethrowing Error from lifecycle callback method: " + t, t);
			}

			throw (Error) t;
		} else {
			InterceptorProxy w = this.ivInterceptorProxies[this.ivNextIndex - 1];
			String lifeCycle = w.getMethodGenericString();
			EJBException ex = ExceptionUtil.EJBException(lifeCycle + " is not allowed to throw a checked exception", t);
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "lifeCycleExceptionHandler throwing EJBException", ex);
			}

			throw ex;
		}
	}

	public Object getTarget() {
		return this.ivBean;
	}

	public Method getMethod() {
		return this.ivMethod;
	}

	public Object[] getParameters() {
		if (this.ivMethod == null && !this.ivIsAroundConstruct) {
			throw new IllegalStateException(
					"InvocationContext.getParameter can not be called by lifecycle callback methods");
		} else {
			return this.ivParameters;
		}
	}

	public Object getTimer() {
		return this.ivTimer;
	}

	public void setParameters(Object[] args) {
		if (this.ivMethod == null && !this.ivIsAroundConstruct) {
			throw new IllegalStateException(
					"InvocationContext.setParameter can not be called by lifecycle callback methods");
		} else {
			Constructor<?> con = this.getConstructor();
			Class<?>[] parmTypes = con != null ? con.getParameterTypes() : this.ivMethod.getParameterTypes();
			String debug = con != null
					? "constructor: " + con.getName()
					: "business method: " + this.ivMethod.getName();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "setParameters for " + debug);
			}

			int n = parmTypes.length;
			if (args == null) {
				if (n > 0) {
					throw new IllegalArgumentException("null not valid as argument for setParameters method.");
				}
			} else {
				if (args.length != n) {
					throw new IllegalArgumentException("wrong number of parameters for method being invoked.");
				}

				for (int i = 0; i < n; ++i) {
					Class<?> parmType = parmTypes[i];
					if (!parmType.isPrimitive()) {
						if (args[i] != null && !parmType.isInstance(args[i])) {
							throw new IllegalArgumentException("wrong data type for parameter " + (i + 1));
						}
					} else {
						if (parmType == Integer.TYPE && !(args[i] instanceof Integer)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Integer");
						}

						if (parmType == Long.TYPE && !(args[i] instanceof Long)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Long");
						}

						if (parmType == Short.TYPE && !(args[i] instanceof Short)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Short");
						}

						if (parmType == Boolean.TYPE && !(args[i] instanceof Boolean)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Boolean");
						}

						if (parmType == Byte.TYPE && !(args[i] instanceof Byte)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Byte");
						}

						if (parmType == Character.TYPE && !(args[i] instanceof Character)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Character");
						}

						if (parmType == Float.TYPE && !(args[i] instanceof Float)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Float");
						}

						if (parmType == Double.TYPE && !(args[i] instanceof Double)) {
							throw new IllegalArgumentException("parameter " + (i + 1) + " is a "
									+ args[i].getClass().getName() + ", but it is required to be a Double");
						}
					}
				}

				this.ivParameters = args;
				this.ivParametersModified = true;
			}

		}
	}

	public Map<String, Object> getContextData() {
		return EJSContainer.getThreadData().getContextData();
	}

	public Object proceed() throws Exception {
		Object returnValue = null;

		try {
			if (this.ivNextIndex < this.ivNumberOfInterceptors) {
				InterceptorProxy w = this.ivInterceptorProxies[this.ivNextIndex];
				if (w.ivRequiresInvocationContext) {
					++this.ivNextIndex;
					returnValue = w.invokeInterceptor(this.ivBean, this, this.ivInterceptors);
				} else {
					while (w != null) {
						++this.ivNextIndex;
						returnValue = w.invokeInterceptor(this.ivBean, this, this.ivInterceptors);
						w = this.ivNextIndex < this.ivNumberOfInterceptors
								? this.ivInterceptorProxies[this.ivNextIndex]
								: null;
					}
				}
			} else if (this.ivMethod != null) {
				returnValue = this.ivContainer.invokeProceed(this.ivEJSDeployedSupport, this.ivMethod, this.ivBean,
						this.ivParameters, this.ivParametersModified);
			} else if (this.ivIsAroundConstruct) {
				try {
					this.ivBean = this.ivConstructCallback.proceed(this.ivParameters, this.getContextData());
				} catch (Exception var3) {
					this.ivAroundConstructException = var3;
					throw var3;
				}

				return null;
			}
		} catch (UndeclaredThrowableException var4) {
			this.throwUndeclaredExceptionCause(var4);
		} catch (InvocationTargetException var5) {
			this.throwUndeclaredExceptionCause(var5);
		}

		return this.ivMethod == null ? null : returnValue;
	}

	private void throwUndeclaredExceptionCause(Throwable undeclaredException) throws Exception {
		Throwable cause = undeclaredException.getCause();
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "proceed unwrappering " + undeclaredException.getClass().getSimpleName() + " : " + cause,
					cause);
		}

		if (cause instanceof UndeclaredThrowableException) {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "proceed unwrappering " + cause.getClass().getSimpleName() + " : " + cause,
						cause.getCause());
			}

			cause = cause.getCause();
		}

		if (cause instanceof RuntimeException) {
			throw (RuntimeException) cause;
		} else if (cause instanceof Error) {
			throw (Error) cause;
		} else {
			throw (Exception) cause;
		}
	}

	public Constructor<T> getConstructor() {
		return this.ivIsAroundConstruct ? this.ivConstructCallback.getConstructor() : null;
	}

	public ManagedObjectContext getManagedObjectContext() {
		return this.ivManagedObjectContext;
	}

	public void prePostConstruct(ManagedObject<T> mo) {
	}
}