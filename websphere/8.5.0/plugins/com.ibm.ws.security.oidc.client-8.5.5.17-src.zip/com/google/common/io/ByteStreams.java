package com.google.common.io;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import com.google.common.io.ByteStreams.1;
import com.google.common.io.ByteStreams.ByteArrayDataInputStream;
import com.google.common.io.ByteStreams.ByteArrayDataOutputStream;
import com.google.common.io.ByteStreams.LimitedInputStream;
import com.google.common.math.IntMath;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

@Beta
@GwtIncompatible
public final class ByteStreams {
	private static final int BUFFER_SIZE = 8192;
	private static final int ZERO_COPY_CHUNK_SIZE = 524288;
	private static final int MAX_ARRAY_LEN = 2147483639;
	private static final int TO_BYTE_ARRAY_DEQUE_SIZE = 20;
	private static final OutputStream NULL_OUTPUT_STREAM = new 1();

	static byte[] createBuffer() {
		return new byte[8192];
	}

	@CanIgnoreReturnValue
	public static long copy(InputStream from, OutputStream to) throws IOException {
		Preconditions.checkNotNull(from);
		Preconditions.checkNotNull(to);
		byte[] buf = createBuffer();
		long total = 0L;

		while (true) {
			int r = from.read(buf);
			if (r == -1) {
				return total;
			}

			to.write(buf, 0, r);
			total += (long) r;
		}
	}

	@CanIgnoreReturnValue
	public static long copy(ReadableByteChannel from, WritableByteChannel to) throws IOException {
		Preconditions.checkNotNull(from);
		Preconditions.checkNotNull(to);
		long oldPosition;
		if (from instanceof FileChannel) {
			FileChannel sourceChannel = (FileChannel) from;
			oldPosition = sourceChannel.position();
			long position = oldPosition;

			long copied;
			do {
				do {
					copied = sourceChannel.transferTo(position, 524288L, to);
					position += copied;
					sourceChannel.position(position);
				} while (copied > 0L);
			} while (position < sourceChannel.size());

			return position - oldPosition;
		} else {
			ByteBuffer buf = ByteBuffer.wrap(createBuffer());
			oldPosition = 0L;

			while (from.read(buf) != -1) {
				buf.flip();

				while (buf.hasRemaining()) {
					oldPosition += (long) to.write(buf);
				}

				buf.clear();
			}

			return oldPosition;
		}
	}

	private static byte[] toByteArrayInternal(InputStream in, Deque<byte[]> bufs, int totalLen) throws IOException {
		for (int bufSize = 8192; totalLen < 2147483639; bufSize = IntMath.saturatedMultiply(bufSize, 2)) {
			byte[] buf = new byte[Math.min(bufSize, 2147483639 - totalLen)];
			bufs.add(buf);

			int r;
			for (int off = 0; off < buf.length; totalLen += r) {
				r = in.read(buf, off, buf.length - off);
				if (r == -1) {
					return combineBuffers(bufs, totalLen);
				}

				off += r;
			}
		}

		if (in.read() == -1) {
			return combineBuffers(bufs, 2147483639);
		} else {
			throw new OutOfMemoryError("input is too large to fit in a byte array");
		}
	}

	private static byte[] combineBuffers(Deque<byte[]> bufs, int totalLen) {
		byte[] result = new byte[totalLen];

		int bytesToCopy;
		for (int remaining = totalLen; remaining > 0; remaining -= bytesToCopy) {
			byte[] buf = (byte[]) bufs.removeFirst();
			bytesToCopy = Math.min(remaining, buf.length);
			int resultOffset = totalLen - remaining;
			System.arraycopy(buf, 0, result, resultOffset, bytesToCopy);
		}

		return result;
	}

	public static byte[] toByteArray(InputStream in) throws IOException {
		Preconditions.checkNotNull(in);
		return toByteArrayInternal(in, new ArrayDeque(20), 0);
	}

	static byte[] toByteArray(InputStream in, long expectedSize) throws IOException {
		Preconditions.checkArgument(expectedSize >= 0L, "expectedSize (%s) must be non-negative", expectedSize);
		if (expectedSize > 2147483639L) {
			throw new OutOfMemoryError(expectedSize + " bytes is too large to fit in a byte array");
		} else {
			byte[] bytes = new byte[(int) expectedSize];

			int b;
			int read;
			for (int remaining = (int) expectedSize; remaining > 0; remaining -= read) {
				b = (int) expectedSize - remaining;
				read = in.read(bytes, b, remaining);
				if (read == -1) {
					return Arrays.copyOf(bytes, b);
				}
			}

			b = in.read();
			if (b == -1) {
				return bytes;
			} else {
				Deque<byte[]> bufs = new ArrayDeque(22);
				bufs.add(bytes);
				bufs.add(new byte[]{(byte) b});
				return toByteArrayInternal(in, bufs, bytes.length + 1);
			}
		}
	}

	@CanIgnoreReturnValue
	public static long exhaust(InputStream in) throws IOException {
		long total = 0L;

		long read;
		for (byte[] buf = createBuffer(); (read = (long) in.read(buf)) != -1L; total += read) {
			;
		}

		return total;
	}

	public static ByteArrayDataInput newDataInput(byte[] bytes) {
		return newDataInput(new ByteArrayInputStream(bytes));
	}

	public static ByteArrayDataInput newDataInput(byte[] bytes, int start) {
		Preconditions.checkPositionIndex(start, bytes.length);
		return newDataInput(new ByteArrayInputStream(bytes, start, bytes.length - start));
	}

	public static ByteArrayDataInput newDataInput(ByteArrayInputStream byteArrayInputStream) {
		return new ByteArrayDataInputStream((ByteArrayInputStream) Preconditions.checkNotNull(byteArrayInputStream));
	}

	public static ByteArrayDataOutput newDataOutput() {
		return newDataOutput(new ByteArrayOutputStream());
	}

	public static ByteArrayDataOutput newDataOutput(int size) {
		if (size < 0) {
			throw new IllegalArgumentException(String.format("Invalid size: %s", size));
		} else {
			return newDataOutput(new ByteArrayOutputStream(size));
		}
	}

	public static ByteArrayDataOutput newDataOutput(ByteArrayOutputStream byteArrayOutputSteam) {
		return new ByteArrayDataOutputStream((ByteArrayOutputStream) Preconditions.checkNotNull(byteArrayOutputSteam));
	}

	public static OutputStream nullOutputStream() {
		return NULL_OUTPUT_STREAM;
	}

	public static InputStream limit(InputStream in, long limit) {
		return new LimitedInputStream(in, limit);
	}

	public static void readFully(InputStream in, byte[] b) throws IOException {
		readFully(in, b, 0, b.length);
	}

	public static void readFully(InputStream in, byte[] b, int off, int len) throws IOException {
		int read = read(in, b, off, len);
		if (read != len) {
			throw new EOFException(
					"reached end of stream after reading " + read + " bytes; " + len + " bytes expected");
		}
	}

	public static void skipFully(InputStream in, long n) throws IOException {
		long skipped = skipUpTo(in, n);
		if (skipped < n) {
			throw new EOFException(
					"reached end of stream after skipping " + skipped + " bytes; " + n + " bytes expected");
		}
	}

	static long skipUpTo(InputStream in, long n) throws IOException {
		long totalSkipped = 0L;

		long skipped;
		for (byte[] buf = createBuffer(); totalSkipped < n; totalSkipped += skipped) {
			long remaining = n - totalSkipped;
			skipped = skipSafely(in, remaining);
			if (skipped == 0L) {
				int skip = (int) Math.min(remaining, (long) buf.length);
				if ((skipped = (long) in.read(buf, 0, skip)) == -1L) {
					break;
				}
			}
		}

		return totalSkipped;
	}

	private static long skipSafely(InputStream in, long n) throws IOException {
		int available = in.available();
		return available == 0 ? 0L : in.skip(Math.min((long) available, n));
	}

	@CanIgnoreReturnValue
	public static <T> T readBytes(InputStream input, ByteProcessor<T> processor) throws IOException {
		Preconditions.checkNotNull(input);
		Preconditions.checkNotNull(processor);
		byte[] buf = createBuffer();

		int read;
		do {
			read = input.read(buf);
		} while (read != -1 && processor.processBytes(buf, 0, read));

		return processor.getResult();
	}

	@CanIgnoreReturnValue
	public static int read(InputStream in, byte[] b, int off, int len) throws IOException {
		Preconditions.checkNotNull(in);
		Preconditions.checkNotNull(b);
		if (len < 0) {
			throw new IndexOutOfBoundsException("len is negative");
		} else {
			int total;
			int result;
			for (total = 0; total < len; total += result) {
				result = in.read(b, off + total, len - total);
				if (result == -1) {
					break;
				}
			}

			return total;
		}
	}
}