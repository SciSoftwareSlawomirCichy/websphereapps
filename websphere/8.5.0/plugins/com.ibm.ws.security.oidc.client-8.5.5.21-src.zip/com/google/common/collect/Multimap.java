package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.CompatibleWith;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible
public interface Multimap<K, V> {
	int size();

	boolean isEmpty();

	boolean containsKey(@NullableDecl @CompatibleWith("K") Object var1);

	boolean containsValue(@NullableDecl @CompatibleWith("V") Object var1);

	boolean containsEntry(@NullableDecl @CompatibleWith("K") Object var1,
			@NullableDecl @CompatibleWith("V") Object var2);

	@CanIgnoreReturnValue
	boolean put(@NullableDecl K var1, @NullableDecl V var2);

	@CanIgnoreReturnValue
	boolean remove(@NullableDecl @CompatibleWith("K") Object var1, @NullableDecl @CompatibleWith("V") Object var2);

	@CanIgnoreReturnValue
	boolean putAll(@NullableDecl K var1, Iterable<? extends V> var2);

	@CanIgnoreReturnValue
	boolean putAll(Multimap<? extends K, ? extends V> var1);

	@CanIgnoreReturnValue
	Collection<V> replaceValues(@NullableDecl K var1, Iterable<? extends V> var2);

	@CanIgnoreReturnValue
	Collection<V> removeAll(@NullableDecl @CompatibleWith("K") Object var1);

	void clear();

	Collection<V> get(@NullableDecl K var1);

	Set<K> keySet();

	Multiset<K> keys();

	Collection<V> values();

	Collection<Entry<K, V>> entries();

	Map<K, Collection<V>> asMap();

	boolean equals(@NullableDecl Object var1);

	int hashCode();
}