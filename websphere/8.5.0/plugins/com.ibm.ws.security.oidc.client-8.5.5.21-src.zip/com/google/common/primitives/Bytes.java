package com.google.common.primitives;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Preconditions;
import com.google.common.primitives.Bytes.ByteArrayAsList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@GwtCompatible
public final class Bytes {
	public static int hashCode(byte value) {
		return value;
	}

	public static boolean contains(byte[] array, byte target) {
		byte[] var2 = array;
		int var3 = array.length;

		for (int var4 = 0; var4 < var3; ++var4) {
			byte value = var2[var4];
			if (value == target) {
				return true;
			}
		}

		return false;
	}

	public static int indexOf(byte[] array, byte target) {
		return indexOf(array, target, 0, array.length);
	}

	private static int indexOf(byte[] array, byte target, int start, int end) {
		for (int i = start; i < end; ++i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static int indexOf(byte[] array, byte[] target) {
		Preconditions.checkNotNull(array, "array");
		Preconditions.checkNotNull(target, "target");
		if (target.length == 0) {
			return 0;
		} else {
			label28 : for (int i = 0; i < array.length - target.length + 1; ++i) {
				for (int j = 0; j < target.length; ++j) {
					if (array[i + j] != target[j]) {
						continue label28;
					}
				}

				return i;
			}

			return -1;
		}
	}

	public static int lastIndexOf(byte[] array, byte target) {
		return lastIndexOf(array, target, 0, array.length);
	}

	private static int lastIndexOf(byte[] array, byte target, int start, int end) {
		for (int i = end - 1; i >= start; --i) {
			if (array[i] == target) {
				return i;
			}
		}

		return -1;
	}

	public static byte[] concat(byte[]... arrays) {
		int length = 0;
		byte[][] var2 = arrays;
		int pos = arrays.length;

		for (int var4 = 0; var4 < pos; ++var4) {
			byte[] array = var2[var4];
			length += array.length;
		}

		byte[] result = new byte[length];
		pos = 0;
		byte[][] var9 = arrays;
		int var10 = arrays.length;

		for (int var6 = 0; var6 < var10; ++var6) {
			byte[] array = var9[var6];
			System.arraycopy(array, 0, result, pos, array.length);
			pos += array.length;
		}

		return result;
	}

	public static byte[] ensureCapacity(byte[] array, int minLength, int padding) {
		Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", minLength);
		Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", padding);
		return array.length < minLength ? Arrays.copyOf(array, minLength + padding) : array;
	}

	public static byte[] toArray(Collection<? extends Number> collection) {
		if (collection instanceof ByteArrayAsList) {
			return ((ByteArrayAsList) collection).toByteArray();
		} else {
			Object[] boxedArray = collection.toArray();
			int len = boxedArray.length;
			byte[] array = new byte[len];

			for (int i = 0; i < len; ++i) {
				array[i] = ((Number) Preconditions.checkNotNull(boxedArray[i])).byteValue();
			}

			return array;
		}
	}

	public static List<Byte> asList(byte... backingArray) {
		return (List) (backingArray.length == 0 ? Collections.emptyList() : new ByteArrayAsList(backingArray));
	}

	public static void reverse(byte[] array) {
		Preconditions.checkNotNull(array);
		reverse(array, 0, array.length);
	}

	public static void reverse(byte[] array, int fromIndex, int toIndex) {
		Preconditions.checkNotNull(array);
		Preconditions.checkPositionIndexes(fromIndex, toIndex, array.length);
		int i = fromIndex;

		for (int j = toIndex - 1; i < j; --j) {
			byte tmp = array[i];
			array[i] = array[j];
			array[j] = tmp;
			++i;
		}

	}
}