package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Ordering;
import com.google.common.util.concurrent.Futures.1;
import com.google.common.util.concurrent.Futures.2;
import com.google.common.util.concurrent.Futures.3;
import com.google.common.util.concurrent.Futures.4;
import com.google.common.util.concurrent.Futures.5;
import com.google.common.util.concurrent.Futures.6;
import com.google.common.util.concurrent.Futures.ChainingListenableFuture;
import com.google.common.util.concurrent.Futures.CombinedFuture;
import com.google.common.util.concurrent.Futures.FallbackFuture;
import com.google.common.util.concurrent.Futures.ImmediateCancelledFuture;
import com.google.common.util.concurrent.Futures.ImmediateFailedCheckedFuture;
import com.google.common.util.concurrent.Futures.ImmediateFailedFuture;
import com.google.common.util.concurrent.Futures.ImmediateSuccessfulCheckedFuture;
import com.google.common.util.concurrent.Futures.ImmediateSuccessfulFuture;
import com.google.common.util.concurrent.Futures.MappingCheckedFuture;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.annotation.Nullable;

@Beta
public final class Futures {
	private static final AsyncFunction<ListenableFuture<Object>, Object> DEREFERENCER = new 3();
	private static final Ordering<Constructor<?>> WITH_STRING_PARAM_FIRST = Ordering.natural().onResultOf(new 5()).reverse();

	public static <V, X extends Exception> CheckedFuture<V, X> makeChecked(ListenableFuture<V> future,
			Function<Exception, X> mapper) {
		return new MappingCheckedFuture((ListenableFuture) Preconditions.checkNotNull(future), mapper);
	}

	public static <V> ListenableFuture<V> immediateFuture(@Nullable V value) {
		return new ImmediateSuccessfulFuture(value);
	}

	public static <V, X extends Exception> CheckedFuture<V, X> immediateCheckedFuture(@Nullable V value) {
		return new ImmediateSuccessfulCheckedFuture(value);
	}

	public static <V> ListenableFuture<V> immediateFailedFuture(Throwable throwable) {
		Preconditions.checkNotNull(throwable);
		return new ImmediateFailedFuture(throwable);
	}

	public static <V> ListenableFuture<V> immediateCancelledFuture() {
		return new ImmediateCancelledFuture();
	}

	public static <V, X extends Exception> CheckedFuture<V, X> immediateFailedCheckedFuture(X exception) {
		Preconditions.checkNotNull(exception);
		return new ImmediateFailedCheckedFuture(exception);
	}

	public static <V> ListenableFuture<V> withFallback(ListenableFuture<? extends V> input,
			FutureFallback<? extends V> fallback) {
		return withFallback(input, fallback, MoreExecutors.sameThreadExecutor());
	}

	public static <V> ListenableFuture<V> withFallback(ListenableFuture<? extends V> input,
			FutureFallback<? extends V> fallback, Executor executor) {
		Preconditions.checkNotNull(fallback);
		return new FallbackFuture(input, fallback, executor);
	}

	public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input,
			AsyncFunction<? super I, ? extends O> function) {
		return transform(input, (AsyncFunction) function, MoreExecutors.sameThreadExecutor());
	}

	public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, AsyncFunction<? super I, ? extends O> function, Executor executor) {
      ChainingListenableFuture<I, O> output = new ChainingListenableFuture(function, input, (1)null);
      input.addListener(output, executor);
      return output;
   }

	public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input,
			Function<? super I, ? extends O> function) {
		return transform(input, (Function) function, MoreExecutors.sameThreadExecutor());
	}

	public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, Function<? super I, ? extends O> function, Executor executor) {
      Preconditions.checkNotNull(function);
      AsyncFunction<I, O> wrapperFunction = new 1(function);
      return transform(input, (AsyncFunction)wrapperFunction, executor);
   }

	@Beta
   public static <I, O> Future<O> lazyTransform(Future<I> input, Function<? super I, ? extends O> function) {
      Preconditions.checkNotNull(input);
      Preconditions.checkNotNull(function);
      return new 2(input, function);
   }

	@Beta
	public static <V> ListenableFuture<V> dereference(
			ListenableFuture<? extends ListenableFuture<? extends V>> nested) {
		return transform(nested, DEREFERENCER);
	}

	@Beta
	public static <V> ListenableFuture<List<V>> allAsList(ListenableFuture... futures) {
		return listFuture(ImmutableList.copyOf(futures), true, MoreExecutors.sameThreadExecutor());
	}

	@Beta
	public static <V> ListenableFuture<List<V>> allAsList(Iterable<? extends ListenableFuture<? extends V>> futures) {
		return listFuture(ImmutableList.copyOf(futures), true, MoreExecutors.sameThreadExecutor());
	}

	@Beta
	public static <V> ListenableFuture<List<V>> successfulAsList(ListenableFuture... futures) {
		return listFuture(ImmutableList.copyOf(futures), false, MoreExecutors.sameThreadExecutor());
	}

	@Beta
	public static <V> ListenableFuture<List<V>> successfulAsList(
			Iterable<? extends ListenableFuture<? extends V>> futures) {
		return listFuture(ImmutableList.copyOf(futures), false, MoreExecutors.sameThreadExecutor());
	}

	public static <V> void addCallback(ListenableFuture<V> future, FutureCallback<? super V> callback) {
		addCallback(future, callback, MoreExecutors.sameThreadExecutor());
	}

	public static <V> void addCallback(ListenableFuture<V> future, FutureCallback<? super V> callback, Executor executor) {
      Preconditions.checkNotNull(callback);
      Runnable callbackListener = new 4(future, callback);
      future.addListener(callbackListener, executor);
   }

	@Beta
	public static <V, X extends Exception> V get(Future<V> future, Class<X> exceptionClass) throws X {
		Preconditions.checkNotNull(future);
		Preconditions.checkArgument(!RuntimeException.class.isAssignableFrom(exceptionClass),
				"Futures.get exception type (%s) must not be a RuntimeException", new Object[]{exceptionClass});

		try {
			return future.get();
		} catch (InterruptedException var3) {
			Thread.currentThread().interrupt();
			throw newWithCause(exceptionClass, var3);
		} catch (ExecutionException var4) {
			wrapAndThrowExceptionOrError(var4.getCause(), exceptionClass);
			throw new AssertionError();
		}
	}

	@Beta
	public static <V, X extends Exception> V get(Future<V> future, long timeout, TimeUnit unit, Class<X> exceptionClass)
			throws X {
		Preconditions.checkNotNull(future);
		Preconditions.checkNotNull(unit);
		Preconditions.checkArgument(!RuntimeException.class.isAssignableFrom(exceptionClass),
				"Futures.get exception type (%s) must not be a RuntimeException", new Object[]{exceptionClass});

		try {
			return future.get(timeout, unit);
		} catch (InterruptedException var6) {
			Thread.currentThread().interrupt();
			throw newWithCause(exceptionClass, var6);
		} catch (TimeoutException var7) {
			throw newWithCause(exceptionClass, var7);
		} catch (ExecutionException var8) {
			wrapAndThrowExceptionOrError(var8.getCause(), exceptionClass);
			throw new AssertionError();
		}
	}

	private static <X extends Exception> void wrapAndThrowExceptionOrError(Throwable cause, Class<X> exceptionClass)
			throws X {
		if (cause instanceof Error) {
			throw new ExecutionError((Error) cause);
		} else if (cause instanceof RuntimeException) {
			throw new UncheckedExecutionException(cause);
		} else {
			throw newWithCause(exceptionClass, cause);
		}
	}

	@Beta
	public static <V> V getUnchecked(Future<V> future) {
		Preconditions.checkNotNull(future);

		try {
			return Uninterruptibles.getUninterruptibly(future);
		} catch (ExecutionException var2) {
			wrapAndThrowUnchecked(var2.getCause());
			throw new AssertionError();
		}
	}

	private static void wrapAndThrowUnchecked(Throwable cause) {
		if (cause instanceof Error) {
			throw new ExecutionError((Error) cause);
		} else {
			throw new UncheckedExecutionException(cause);
		}
	}

	private static <X extends Exception> X newWithCause(Class<X> exceptionClass, Throwable cause) {
		List<Constructor<X>> constructors = Arrays.asList(exceptionClass.getConstructors());
		Iterator i$ = preferringStrings(constructors).iterator();

		Exception instance;
		do {
			if (!i$.hasNext()) {
				throw new IllegalArgumentException("No appropriate constructor for exception of type " + exceptionClass
						+ " in response to chained exception", cause);
			}

			Constructor<X> constructor = (Constructor) i$.next();
			instance = (Exception) newFromConstructor(constructor, cause);
		} while (instance == null);

		if (instance.getCause() == null) {
			instance.initCause(cause);
		}

		return instance;
	}

	private static <X extends Exception> List<Constructor<X>> preferringStrings(List<Constructor<X>> constructors) {
		return WITH_STRING_PARAM_FIRST.sortedCopy(constructors);
	}

	@Nullable
	private static <X> X newFromConstructor(Constructor<X> constructor, Throwable cause) {
		Class<?>[] paramTypes = constructor.getParameterTypes();
		Object[] params = new Object[paramTypes.length];

		for (int i = 0; i < paramTypes.length; ++i) {
			Class<?> paramType = paramTypes[i];
			if (paramType.equals(String.class)) {
				params[i] = cause.toString();
			} else {
				if (!paramType.equals(Throwable.class)) {
					return null;
				}

				params[i] = cause;
			}
		}

		try {
			return constructor.newInstance(params);
		} catch (IllegalArgumentException var6) {
			return null;
		} catch (InstantiationException var7) {
			return null;
		} catch (IllegalAccessException var8) {
			return null;
		} catch (InvocationTargetException var9) {
			return null;
		}
	}

	private static <V> ListenableFuture<List<V>> listFuture(ImmutableList<ListenableFuture<? extends V>> futures, boolean allMustSucceed, Executor listenerExecutor) {
      return new CombinedFuture(futures, allMustSucceed, listenerExecutor, new 6());
   }
}