package com.ibm.ws.wim.lookaside;

public class LACompositeRelation {
	private int compositeId;
	private int componentId;
	private int requiredInComposite = 0;
	private int keyInComposite = 0;

	public int getComponentId() {
		return this.componentId;
	}

	public int getCompositeId() {
		return this.compositeId;
	}

	public int getRequiredInComposite() {
		return this.requiredInComposite;
	}

	public void setComponentId(int var1) {
		this.componentId = var1;
	}

	public void setCompositeId(int var1) {
		this.compositeId = var1;
	}

	public void setRequiredInComposite(int var1) {
		this.requiredInComposite = var1;
	}

	public int getKeyInComposite() {
		return this.keyInComposite;
	}

	public void setKeyInComposite(int var1) {
		this.keyInComposite = var1;
	}
}