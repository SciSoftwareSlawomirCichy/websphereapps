package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;

public abstract class TimerNpRunnable implements Runnable {
	private static final String CLASS_NAME = TimerNpRunnable.class.getName();
	private static final TraceComponent tc = Tr.register(TimerNpRunnable.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private BeanId ivBeanId;
	private final int ivMethodId;
	private long ivRetries = 0L;
	private final int ivRetryLimit;
	private final long ivRetryInterval;
	protected final TimerNpImpl ivTimer;

	public TimerNpRunnable(TimerNpImpl timerNpImpl, int retryLimit, long retryInterval) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>: " + timerNpImpl);
		}

		this.ivBeanId = timerNpImpl.getIvBeanId();
		this.ivMethodId = timerNpImpl.ivMethodId;
		this.ivTimer = timerNpImpl;
		this.ivRetryLimit = retryLimit;
		this.ivRetryInterval = retryInterval;
	}

	public String toString() {
		return this.getClass().getSimpleName() + "(" + this.ivTimer.ivTaskId + ", " + this.ivBeanId + ", "
				+ this.ivRetries + ")";
	}

	public void run() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "run: " + this.ivTimer.ivTaskId);
		}

		if (this.ivRetries == 0L) {
			this.ivTimer.calculateNextExpiration();
		}

		this.ivTimer.checkLateTimerThreshold();

		try {
			if (this.ivTimer.isIvDestroyed()) {
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "Timer has been cancelled; aborting");
				}

				return;
			}

			this.doWork();
			this.ivRetries = 0L;
			this.ivTimer.scheduleNext();
		} catch (Throwable var3) {
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "NP Timer failed : " + var3.getClass().getName() + ":" + var3.getMessage(), var3);
			}

			if (this.ivRetryLimit != -1 && this.ivRetries >= (long) this.ivRetryLimit) {
				this.ivTimer.calculateNextExpiration();
				this.ivTimer.scheduleNext();
				this.ivRetries = 0L;
				Tr.warning(tc, "NP_TIMER_RETRY_LIMIT_REACHED_CNTR0179W", this.ivRetryLimit);
				if (isTraceOn && tc.isEntryEnabled()) {
					Tr.exit(tc, "Timer retry limit has been reached; aborting");
				}

				return;
			}

			++this.ivRetries;
			if (this.ivRetries == 1L) {
				this.run();
			} else {
				this.ivTimer.scheduleRetry(this.ivRetryInterval);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "run");
		}

	}

	private void doWork() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "doWork: " + this.ivTimer);
		}

		try {
			this.ivBeanId = this.ivBeanId.getInitializedBeanId();
		} catch (Exception var7) {
			FFDCFilter.processException(var7, CLASS_NAME + ".doWork", "247", this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "doWork: " + var7);
			}

			throw ExceptionUtil.EJBException(var7);
		}

		EJSHome home = (EJSHome) this.ivBeanId.home;
		TimedObjectWrapper timedObject = home.getTimedObjectWrapper(this.ivBeanId);

		try {
			this.ivTimer.ivTimeoutThread = Thread.currentThread();
			timedObject.invokeCallback(this.ivTimer, this.ivMethodId, false);
		} finally {
			this.ivTimer.ivTimeoutThread = null;
			home.putTimedObjectWrapper(timedObject);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "doWork");
			}

		}

	}

	protected abstract void schedule(long var1);

	protected abstract void scheduleNext(long var1);

	protected abstract void scheduleRetry(long var1);

	protected abstract void cancel();
}