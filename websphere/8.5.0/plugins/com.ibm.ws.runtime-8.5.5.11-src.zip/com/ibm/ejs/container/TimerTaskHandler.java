package com.ibm.ejs.container;

import com.ibm.ejs.container.util.ByteArray;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.dopriv.DeserializeObjectPrivileged;
import com.ibm.ejs.util.dopriv.SerializeObjectPrivileged;
import com.ibm.websphere.csi.J2EEName;
import com.ibm.websphere.scheduler.TaskStatus;
import com.ibm.ws.ejb.portable.Constants;
import com.ibm.ws.ejbcontainer.util.ParsedScheduleExpression;
import com.ibm.ws.ejbcontainer.util.ScheduleExpressionParser;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.metadata.ejb.TimerMethodData;
import com.ibm.ws.metadata.ejb.TimerMethodData.AutomaticTimer;
import com.ibm.ws.scheduler.Runnable;
import com.ibm.ws.security.util.AccessController;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.security.PrivilegedActionException;
import java.util.Arrays;
import javax.ejb.EJBException;

final class TimerTaskHandler extends Runnable {
	private static final TraceComponent tc = Tr.register(TimerTaskHandler.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.TimerTaskHandler";
	private static final long serialVersionUID = -8200752857441853748L;
	private static final byte[] EYECATCHER;
	private static final short PLATFORM = 1;
	private transient BeanId ivBeanId;
	private transient byte[] ivBeanIdBytes;
	private transient int ivMethodId;
	private transient String ivAutomaticMethodName;
	private transient String ivAutomaticClassName;
	private transient Serializable ivInfo;
	private transient byte[] ivInfoBytes;
	private transient ParsedScheduleExpression ivParsedSchedule;
	private transient TimerServiceException ivBeanIdException;
	private transient TimerServiceException ivInfoException;

	TimerTaskHandler(BeanId beanId, AutomaticTimer autoTimer, Serializable info,
			ParsedScheduleExpression parsedSchedule) throws IOException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			String infoClassName = info == null ? null : info.getClass().getName();
			Tr.entry(tc, "<init>: " + beanId + ", " + infoClassName);
		}

		this.ivBeanId = beanId;
		this.ivBeanIdBytes = beanId.getByteArrayBytes();
		this.ivBeanIdException = null;
		if (autoTimer != null) {
			TimerMethodData timerMethod = autoTimer.getMethod();
			this.ivMethodId = timerMethod.getMethodId();
			this.ivAutomaticMethodName = timerMethod.getMethod().getName();
			if (!autoTimer.isXML()) {
				this.ivAutomaticClassName = timerMethod.getMethod().getDeclaringClass().getName();
			}
		}

		this.ivInfo = info;
		this.ivInfoBytes = serializeObject(info);
		this.ivInfoException = null;
		this.ivParsedSchedule = parsedSchedule;
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init>: " + this);
		}

	}

	public void doWork() throws Throwable {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "doWork: " + this.ivBeanId);
		}

		if (this.ivBeanIdException == null && this.ivInfoException == null) {
			this.ivBeanId = this.ivBeanId.getInitializedBeanId();
			EJSHome home = (EJSHome) this.ivBeanId.home;
			if (!home.enabled) {
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "doWork: home disabled - rebuilding beanId");
				}

				EJSContainer container = EJSContainer.getDefaultContainer();
				this.ivBeanId = BeanId.getBeanId(this.ivBeanId.getByteArray(), container);
				home = (EJSHome) this.ivBeanId.home;
				if (home.beanMetaData.timedMethodInfos == null) {
					Tr.warning(tc, "HOME_NOT_FOUND_CNTR0092W", this.ivBeanId.getJ2EEName());
					throw new EJBNotFoundException("Incompatible Application Change: " + this.ivBeanId.getJ2EEName()
							+ " no longer has timers.");
				}
			}

			if (this.ivAutomaticMethodName != null && !this.validateAutomaticTimer(home.beanMetaData)) {
				J2EEName j2eeName = this.ivBeanId.getJ2EEName();
				Tr.error(tc, "AUTOMATIC_TIMER_VALIDATION_FAILED_CNTR0301E", new Object[]{j2eeName.getComponent(),
						j2eeName.getModule(), j2eeName.getApplication(), this.ivAutomaticMethodName});
				throw new EJBException("CNTR0220I: The " + j2eeName.getComponent() + " enterprise bean in the "
						+ j2eeName.getModule() + " module of the " + j2eeName.getApplication()
						+ " application has an automatic timer for the " + this.ivAutomaticMethodName
						+ " method, but an incompatible change was made to the application since the server created the timer.");
			} else {
				TaskStatus status = this.getTaskStatus();
				String taskId = status.getTaskId();
				int hashCode = status.hashCode();
				TimerImpl timer = new TimerImpl(this.ivBeanId, taskId, hashCode);
				TimedObjectWrapper timedObject = home.getTimedObjectWrapper(this.ivBeanId);

				try {
					timer.ivIsExecutingEJBTimeout = true;
					timer.ivStatus = status;
					timer.ivHandler = this;
					timer.ivNoMoreTimeouts = this.ivParsedSchedule != null && status.getRepeatsLeft() == 0;
					timedObject.invokeCallback(timer, this.ivMethodId);
				} finally {
					timer.ivIsExecutingEJBTimeout = false;
					timer.ivNoMoreTimeouts = false;
					home.putTimedObjectWrapper(timedObject);
					if (isTraceOn && tc.isEntryEnabled()) {
						Tr.exit(tc, "doWork: " + this.ivBeanId);
					}

				}

			}
		} else {
			TimerServiceException exception = this.ivBeanIdException != null
					? this.ivBeanIdException
					: this.ivInfoException;
			exception.fillInStackTrace();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "doWork: " + exception);
			}

			throw exception;
		}
	}

	private boolean validateAutomaticTimer(BeanMetaData bmd) {
		if (bmd.timedMethodInfos != null && this.ivMethodId <= bmd.timedMethodInfos.length) {
			Method method = bmd.timedMethodInfos[this.ivMethodId].ivMethod;
			if (!method.getName().equals(this.ivAutomaticMethodName)) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "validateAutomaticTimer: ivAutomaticMethodName=" + this.ivAutomaticMethodName + " != "
							+ method.getName());
				}

				return false;
			} else if (this.ivAutomaticClassName != null
					&& !this.ivAutomaticClassName.equals(method.getDeclaringClass().getName())) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "validateAutomaticTimer: ivAutomaticClassName=" + this.ivAutomaticClassName + " != "
							+ method.getDeclaringClass().getName());
				}

				return false;
			} else {
				return true;
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "validateAutomaticTimer: ivMethodId=" + this.ivMethodId + " > "
						+ Arrays.toString(bmd.timedMethodInfos));
			}

			return false;
		}
	}

	public BeanId getTimedObjectId() throws TimerServiceException {
		if (this.ivBeanIdException != null) {
			this.ivBeanIdException.fillInStackTrace();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getTimedObjectId: " + this.ivBeanIdException);
			}

			throw this.ivBeanIdException;
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getTimedObjectId: " + this.ivBeanId);
			}

			return this.ivBeanId;
		}
	}

	public Serializable getInfo() throws TimerServiceException {
		if (this.ivInfoException != null) {
			this.ivInfoException.fillInStackTrace();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getInfo: " + this.ivInfoException);
			}

			throw this.ivInfoException;
		} else {
			return this.ivInfo;
		}
	}

	ParsedScheduleExpression getParsedSchedule() {
		return this.ivParsedSchedule;
	}

	String getAutomaticClassName() {
		return this.ivAutomaticClassName;
	}

	String getAutomaticMethodName() {
		return this.ivAutomaticMethodName;
	}

	public J2EEName getJ2EEName() throws TimerServiceException, IllegalStateException {
		J2EEName j2eeName = null;
		if (this.ivBeanId != null) {
			j2eeName = this.ivBeanId.getJ2EEName();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getJ2EEName: BeanId: " + j2eeName);
			}
		} else {
			if (this.ivBeanIdBytes == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getJ2EEName: BeanId not set: IllegalStateException");
				}

				throw new IllegalStateException("TimedObject Identity not set.");
			}

			try {
				byte[] j2eeNameBytes = BeanId.getJ2EENameBytes(this.ivBeanIdBytes);
				j2eeName = EJSContainer.getDefaultContainer().getJ2EENameFactory().create(j2eeNameBytes);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getJ2EEName: BeanIdBytes: " + j2eeName);
				}
			} catch (Throwable var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.TimerTaskHandler.getJ2EEName", "361", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getJ2EEName: BeanIdBytes: " + var3);
				}

				throw new TimerServiceException("Failure deserializing TimedObject identity", var3);
			}
		}

		return j2eeName;
	}

	public Serializable getPrimaryKey() throws TimerServiceException, IllegalStateException {
		Serializable pkey = null;
		if (this.ivBeanId != null) {
			pkey = this.ivBeanId.getPrimaryKey();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getPrimaryKey: BeanId: " + pkey);
			}
		} else {
			if (this.ivBeanIdBytes == null) {
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getPrimaryKey: BeanId not set: IllegalStateException");
				}

				throw new IllegalStateException("TimedObject Identity not set.");
			}

			try {
				pkey = BeanId.getPrimaryKey(this.ivBeanIdBytes);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getPrimaryKey: BeanIdBytes: " + pkey);
				}
			} catch (Throwable var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.TimerTaskHandler.getPrimaryKey", "437", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "getPrimaryKey: BeanIdBytes: " + var3);
				}

				throw new TimerServiceException("Failure deserializing TimedObject identity", var3);
			}
		}

		return pkey;
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "writeObject: " + this);
		}

		int version = 1;
		if (this.ivParsedSchedule != null) {
			version = 2;
		}

		out.defaultWriteObject();
		out.write(EYECATCHER);
		out.writeShort(1);
		out.writeShort(version);
		out.writeObject(this.ivBeanIdBytes);
		out.writeObject(this.ivInfoBytes);
		if (version >= 2) {
			out.writeObject(this.ivParsedSchedule);
			out.writeInt(this.ivMethodId);
			out.writeObject(this.ivAutomaticMethodName);
			out.writeObject(this.ivAutomaticClassName);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "writeObject");
		}

	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "readObject");
		}

		in.defaultReadObject();
		byte[] eyeCatcher = new byte[EYECATCHER.length];
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < EYECATCHER.length; i += bytesRead) {
			bytesRead = in.read(eyeCatcher, i, EYECATCHER.length - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < EYECATCHER.length; ++i) {
			if (EYECATCHER[i] != eyeCatcher[i]) {
				String eyeCatcherString = new String(eyeCatcher);
				throw new IOException("Invalid eye catcher '" + eyeCatcherString + "' in TimerHandle input stream");
			}
		}

		short incoming_platform = in.readShort();
		short incoming_vid = in.readShort();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "version = " + incoming_vid);
		}

		if (incoming_vid != 1 && incoming_vid != 2) {
			throw new InvalidObjectException(
					"EJB TimerTaskHandler data stream is not of the correct version, this client should be updated.");
		} else {
			this.ivBeanIdBytes = (byte[]) ((byte[]) in.readObject());
			this.ivInfoBytes = (byte[]) ((byte[]) in.readObject());

			try {
				ByteArray byteArray = new ByteArray(this.ivBeanIdBytes);
				EJSContainer container = EJSContainer.getDefaultContainer();
				this.ivBeanId = BeanId.getBeanId(byteArray, container);
			} catch (Throwable var10) {
				FFDCFilter.processException(var10, "com.ibm.ejs.container.TimerTaskHandler.readObject", "567", this);
				this.ivBeanIdException = new TimerServiceException("Failure deserializing TimedObject identity", var10);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "readObject: " + this.ivBeanIdException);
				}
			}

			try {
				this.ivInfo = (Serializable) deserializeObject(this.ivInfoBytes);
			} catch (Throwable var9) {
				FFDCFilter.processException(var9, "com.ibm.ejs.container.TimerTaskHandler.readObject", "585", this);
				this.ivInfoException = new TimerServiceException("Failure deserializing TimedObject identity", var9);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "readObject: " + this.ivInfoException);
				}
			}

			if (incoming_vid >= 2) {
				this.ivParsedSchedule = (ParsedScheduleExpression) in.readObject();
				this.ivMethodId = in.readInt();
				this.ivAutomaticMethodName = (String) in.readObject();
				this.ivAutomaticClassName = (String) in.readObject();
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "readObject: " + this);
			}

		}
	}

	private static byte[] serializeObject(Object obj) throws IOException {
		if (obj == null) {
			return null;
		} else {
			SerializeObjectPrivileged sop = SerializeObjectPrivileged.getSerializeObjectPrivileged();
			sop.ivObjToSerialize = obj;

			try {
				AccessController.doPrivileged(sop);
			} catch (PrivilegedActionException var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.container.TimerTaskHandler.serializeObject", "642");
				IOException rootex = (IOException) var4.getException();
				throw rootex;
			}

			byte[] rtnObj = sop.ivSerializedObj;
			SerializeObjectPrivileged.releaseSerializeObjectPrivileged(sop);
			return rtnObj;
		}
	}

	private static Object deserializeObject(byte[] bytes) throws IOException, ClassNotFoundException {
		if (bytes == null) {
			return null;
		} else {
			Object rtnObj = null;
			DeserializeObjectPrivileged dop = DeserializeObjectPrivileged.getDeserializeObjectPrivileged();
			dop.ivBytesToDeserialize = bytes;

			try {
				rtnObj = AccessController.doPrivileged(dop);
			} catch (PrivilegedActionException var5) {
				FFDCFilter.processException(var5, "com.ibm.ejs.container.TimerTaskHandler.deserializeObject", "698");
				Exception rootex = var5.getException();
				if (rootex instanceof IOException) {
					throw (IOException) rootex;
				}

				throw (ClassNotFoundException) rootex;
			}

			DeserializeObjectPrivileged.releaseDeserializeObjectPrivileged(dop);
			return rtnObj;
		}
	}

	public boolean equals(Object obj) {
		if (this.ivBeanIdException == null && this.ivInfoException == null) {
			if (obj instanceof TimerTaskHandler && super.equals(obj)) {
				TimerTaskHandler taskHandler = (TimerTaskHandler) obj;
				if (this.ivBeanId.equals(taskHandler.ivBeanId) && this.ivInfo.equals(taskHandler.ivInfo)) {
					return true;
				}
			}

			return false;
		} else {
			TimerServiceException exception = this.ivBeanIdException != null
					? this.ivBeanIdException
					: this.ivInfoException;
			exception.fillInStackTrace();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "equals: " + exception);
			}

			throw exception;
		}
	}

	public boolean equals(TimerTaskHandler taskHandler) {
		if (this.ivBeanIdException == null && this.ivInfoException == null) {
			return super.equals(taskHandler) && this.ivBeanId.equals(taskHandler.ivBeanId)
					&& this.ivInfo.equals(taskHandler.ivInfo);
		} else {
			TimerServiceException exception = this.ivBeanIdException != null
					? this.ivBeanIdException
					: this.ivInfoException;
			exception.fillInStackTrace();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "equals: " + exception);
			}

			throw exception;
		}
	}

	public int hashCode() {
		return super.hashCode();
	}

	public String toString() {
		String taskId = null;
		TaskStatus status = this.getTaskStatus();
		if (status != null) {
			taskId = status.getTaskId();
		}

		return "TimerTaskHandler(" + taskId + ", " + this.ivBeanId + ", " + this.ivMethodId + ", "
				+ (this.ivParsedSchedule == null
						? null
						: ScheduleExpressionParser.toString(this.ivParsedSchedule.getSchedule()));
	}

	static {
		EYECATCHER = Constants.TIMER_TASK_EYE_CATCHER;
	}
}