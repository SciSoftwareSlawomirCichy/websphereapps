package com.google.inject;

import com.google.inject.State.1;
import com.google.inject.internal.BindingImpl;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ImmutableList;
import com.google.inject.internal.MatcherAndConverter;
import com.google.inject.spi.TypeListenerBinding;
import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Map;

interface State {
	State NONE = new 1();

	State parent();

	<T> BindingImpl<T> getExplicitBinding(Key<T> var1);

	Map<Key<?>, Binding<?>> getExplicitBindingsThisLevel();

	void putBinding(Key<?> var1, BindingImpl<?> var2);

	Scope getScope(Class<? extends Annotation> var1);

	void putAnnotation(Class<? extends Annotation> var1, Scope var2);

	void addConverter(MatcherAndConverter var1);

	MatcherAndConverter getConverter(String var1, TypeLiteral<?> var2, Errors var3, Object var4);

	Iterable<MatcherAndConverter> getConvertersThisLevel();

	void addMethodAspect(MethodAspect var1);

	ImmutableList<MethodAspect> getMethodAspects();

	void addTypeListener(TypeListenerBinding var1);

	List<TypeListenerBinding> getTypeListenerBindings();

	void blacklist(Key<?> var1);

	boolean isBlacklisted(Key<?> var1);

	Object lock();
}