package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.ws.wim.registry.dataobject.IDAndRealm;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ValidBridge {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private final String className = ValidBridge.class.getName();
	private Logger validBridgeTrace;
	private TypeMappings propertyMap;
	private BridgeUtils mappingUtils;

	public ValidBridge() {
		this.validBridgeTrace = WIMLogger.getTraceLogger(this.className);
		this.propertyMap = new TypeMappings();
		this.mappingUtils = BridgeUtils.singleton();
		String var1 = "ValidBridge";
		if (this.validBridgeTrace.isLoggable(Level.FINER)) {
			this.validBridgeTrace.entering(this.className, var1);
		}

		if (this.validBridgeTrace.isLoggable(Level.FINER)) {
			this.validBridgeTrace.exiting(this.className, var1);
		}

	}

	public boolean isValidUser(String var1) throws CustomRegistryException, RemoteException {
		String var2 = "isValidUser";
		if (this.validBridgeTrace.isLoggable(Level.FINER)) {
			this.validBridgeTrace.entering(this.className, var2, "inputUserSecurityName = \"" + var1 + "\"");
		}

		boolean var3 = false;

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
			}

			String var6 = "'";
			String var7 = var4.getId();
			if (var7.indexOf("'") != -1) {
				var6 = "\"";
			}

			String var8 = this.propertyMap.getInputUserSecurityName(var4.getRealm());
			String var9 = this.propertyMap.getOutputUniqueUserId(var4.getRealm());
			DataObject var10 = this.mappingUtils.getEntityByIdentifier(var5, var8, var7, var9, this.mappingUtils);
			if (var10 != null) {
				var5 = var10;
			} else {
				DataObject var11 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"SearchControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var4.getRealm()))) {
					var11.getList("properties").add(this.propertyMap.getOutputUserSecurityName(var4.getRealm()));
				}

				var11.setString("expression", "//entities[@xsi:type='LoginAccount' and "
						+ this.propertyMap.getInputUserSecurityName(var4.getRealm()) + "=" + var6 + var7 + var6 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
			}

			List var13 = var5.getList("entities");
			if (var13.size() == 1) {
				var3 = true;
			}
		} catch (WIMException var12) {
			this.mappingUtils.logException(var12, this.className);
			throw new CustomRegistryException(var12);
		}

		if (this.validBridgeTrace.isLoggable(Level.FINER)) {
			this.validBridgeTrace.exiting(this.className, var2, new Object[]{Boolean.toString(var3)});
		}

		return var3;
	}

	public boolean isValidGroup(String var1) throws CustomRegistryException, RemoteException {
		String var2 = "isValidGroup";
		if (this.validBridgeTrace.isLoggable(Level.FINER)) {
			this.validBridgeTrace.entering(this.className, var2, new Object[]{var1});
		}

		boolean var3 = false;

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
			}

			String var6 = "'";
			String var7 = var4.getId();
			if (var7.indexOf("'") != -1) {
				var6 = "\"";
			}

			String var8 = this.propertyMap.getInputGroupSecurityName(var4.getRealm());
			String var9 = this.propertyMap.getOutputUniqueGroupId(var4.getRealm());
			DataObject var10 = this.mappingUtils.getEntityByIdentifier(var5, var8, var7, var9, this.mappingUtils);
			if (var10 != null) {
				var5 = var10;
			} else {
				DataObject var11 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim",
						"SearchControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputGroupSecurityName(var4.getRealm()))) {
					var11.getList("properties").add(this.propertyMap.getOutputGroupSecurityName(var4.getRealm()));
				}

				var11.setString("expression", "//entities[@xsi:type='Group' and "
						+ this.propertyMap.getInputGroupSecurityName(var4.getRealm()) + "=" + var6 + var7 + var6 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
			}

			List var13 = var5.getList("entities");
			if (var13.size() == 1) {
				var3 = true;
			}
		} catch (WIMException var12) {
			this.mappingUtils.logException(var12, this.className);
			throw new CustomRegistryException(var12);
		}

		if (this.validBridgeTrace.isLoggable(Level.FINER)) {
			this.validBridgeTrace.exiting(this.className, var2, "returnValue = \"" + Boolean.toString(var3) + "\"");
		}

		return var3;
	}
}