package com.ibm.ejs.container;

public class ContainerObjectNotFoundException extends ContainerException {
	private static final long serialVersionUID = 4916404802059115748L;

	public ContainerObjectNotFoundException(String s) {
		super(s);
	}

	public ContainerObjectNotFoundException() {
	}
}