package com.ibm.ws.wim.registry.util;

import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.EntryNotFoundException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.EntityNotInRealmScopeException;
import com.ibm.websphere.wim.exception.InvalidIdentifierException;
import com.ibm.websphere.wim.exception.InvalidUniqueNameException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.RealmManager;
import com.ibm.ws.wim.registry.dataobject.IDAndRealm;
import commonj.sdo.DataObject;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SecurityNameBridge {
	private static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private final String className = SecurityNameBridge.class.getName();
	private Logger securityNameBridgeTrace;
	private TypeMappings propertyMap;
	private BridgeUtils mappingUtils;

	public SecurityNameBridge() {
		this.securityNameBridgeTrace = WIMLogger.getTraceLogger(this.className);
		this.propertyMap = new TypeMappings();
		this.mappingUtils = BridgeUtils.singleton();
		String var1 = "SecurityNameBridge";
		if (this.securityNameBridgeTrace.isLoggable(Level.FINER)) {
			this.securityNameBridgeTrace.entering(this.className, var1);
		}

		if (this.securityNameBridgeTrace.isLoggable(Level.FINER)) {
			this.securityNameBridgeTrace.exiting(this.className, var1);
		}

	}

	public String getUserSecurityName(String var1)
			throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = "getUserSecurityName";
		if (this.securityNameBridgeTrace.isLoggable(Level.FINER)) {
			this.securityNameBridgeTrace.entering(this.className, var2, "inputUniqueUserId = \"" + var1 + "\"");
		}

		String var3 = "";

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
				DataObject var6 = var5.createDataObject("contexts");
				var6.set("key", "allowOperationIfReposDown");
				var6.set("value", RealmManager.singleton().getAllowOperationIfReposDown(var4.getRealm()));
			}

			BridgeUtils var10000 = this.mappingUtils;
			boolean var16 = BridgeUtils.allowDNAsPrincipalName;
			DataObject var7;
			if (var16) {
				var7 = var5.createDataObject("contexts");
				var7.set("key", "allowDNPrincipalNameAsLiteral");
				var7.set("value", var16);
			}

			if (!this.mappingUtils.isIdentifierTypeProperty(this.propertyMap.getInputUniqueUserId(var4.getRealm()))
					|| var16) {
				var7 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim", "SearchControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var4.getRealm()))) {
					var7.getList("properties").add(this.propertyMap.getOutputUserSecurityName(var4.getRealm()));
				}

				String var8 = "'";
				String var9 = var4.getId();
				if (var9.indexOf("'") != -1) {
					var8 = "\"";
				}

				String var10 = null;
				if (var16) {
					var10 = "principalName";
				} else {
					var10 = this.propertyMap.getInputUniqueUserId(var4.getRealm());
				}

				var7.setString("expression",
						"//entities[@xsi:type='LoginAccount' and " + var10 + "=" + var8 + var9 + var8 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
			}

			List var17 = var5.getList("entities");
			DataObject var18;
			if (this.mappingUtils.isIdentifierTypeProperty(this.propertyMap.getInputUniqueUserId(var4.getRealm()))
					&& (var17 == null || var17.size() == 0)) {
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var4.getRealm()))) {
					this.mappingUtils.createPropertyControlDataObject(var5,
							this.propertyMap.getOutputUserSecurityName(var4.getRealm()));
				}

				var18 = var5.createDataObject("entities", "http://www.ibm.com/websphere/wim", "LoginAccount");
				var18.createDataObject("identifier").setString(this.propertyMap.getInputUniqueUserId(var4.getRealm()),
						var4.getId());
				if (this.propertyMap.getInputUniqueUserId(var4.getRealm()).equals("externalName")) {
					var5.createDataObject("controls", "http://www.ibm.com/websphere/wim", "ExternalNameControl");
				}

				var5 = this.mappingUtils.getWimService().get(var5);
			}

			var17 = var5.getList("entities");
			if (var17.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var2);
			}

			if (var17.size() != 1) {
				boolean var20 = false;
				int var19 = var17.size();
				StringBuilder var22 = new StringBuilder();
				HashSet var11 = new HashSet();

				for (int var21 = 0; var21 < var19; ++var21) {
					DataObject var12 = (DataObject) var17.get(var21);
					if (var12.get("identifier") != null) {
						DataObject var13 = (DataObject) var12.get("identifier");
						if (var13.get("repositoryId") != null) {
							String var14 = String.valueOf(var13.get("repositoryId"));
							if (!var11.contains(var14)) {
								var11.add(var14);
							}
						}
					}
				}

				if (var11.size() == 0) {
					var22.append("repositories");
				} else {
					var22.append(var11);
				}

				throw new EntityNotFoundException("MULTIPLE_PRINCIPALS_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var22), this.className, var2);
			}

			var18 = (DataObject) var17.get(0);
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputUserSecurityName(var4.getRealm()))) {
				var3 = var18.getString(this.propertyMap.getOutputUserSecurityName(var4.getRealm()));
			} else {
				var3 = var18.getString("identifier/" + this.propertyMap.getOutputUserSecurityName(var4.getRealm()));
			}
		} catch (WIMException var15) {
			this.mappingUtils.logException(var15, this.className);
			if (var15 instanceof EntityNotFoundException) {
				throw new EntryNotFoundException(var15);
			}

			if (var15 instanceof EntityNotInRealmScopeException) {
				throw new EntryNotFoundException(var15);
			}

			if (var15 instanceof InvalidUniqueNameException) {
				throw new EntryNotFoundException(var15);
			}

			if (var15 instanceof InvalidIdentifierException) {
				throw new EntryNotFoundException(var15);
			}

			throw new CustomRegistryException(var15);
		}

		if (this.securityNameBridgeTrace.isLoggable(Level.FINER)) {
			this.securityNameBridgeTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}

	public String getGroupSecurityName(String var1)
			throws EntryNotFoundException, CustomRegistryException, RemoteException {
		String var2 = "getGroupSecurityName";
		if (this.securityNameBridgeTrace.isLoggable(Level.FINER)) {
			this.securityNameBridgeTrace.entering(this.className, var2, "inputUniqueGroupId = \"" + var1 + "\"");
		}

		String var3 = "";

		try {
			this.mappingUtils.validateId(var1);
			IDAndRealm var4 = this.mappingUtils.seperateIDAndRealm(var1);
			DataObject var5 = this.mappingUtils.getWimService().createRootDataObject();
			if (var4.isRealmDefined()) {
				this.mappingUtils.createRealmDataObject(var5, var4.getRealm());
			}

			DataObject var6;
			if (this.mappingUtils.isIdentifierTypeProperty(this.propertyMap.getInputUniqueGroupId(var4.getRealm()))) {
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputGroupSecurityName(var4.getRealm()))) {
					this.mappingUtils.createPropertyControlDataObject(var5,
							this.propertyMap.getOutputGroupSecurityName(var4.getRealm()));
				}

				var6 = var5.createDataObject("entities", "http://www.ibm.com/websphere/wim", "Group");
				var6.createDataObject("identifier").setString(this.propertyMap.getInputUniqueGroupId(var4.getRealm()),
						var4.getId());
				if (this.propertyMap.getInputUniqueGroupId(var4.getRealm()).equals("externalName")) {
					var5.createDataObject("controls", "http://www.ibm.com/websphere/wim", "ExternalNameControl");
				}

				var5 = this.mappingUtils.getWimService().get(var5);
			} else {
				var6 = var5.createDataObject("controls", "http://www.ibm.com/websphere/wim", "SearchControl");
				if (!this.mappingUtils
						.isIdentifierTypeProperty(this.propertyMap.getOutputGroupSecurityName(var4.getRealm()))) {
					var6.getList("properties").add(this.propertyMap.getOutputGroupSecurityName(var4.getRealm()));
				}

				String var7 = "'";
				String var8 = var4.getId();
				if (var8.indexOf("'") != -1) {
					var7 = "\"";
				}

				var6.setString("expression", "//entities[@xsi:type='Group' and "
						+ this.propertyMap.getInputUniqueGroupId(var4.getRealm()) + "=" + var7 + var8 + var7 + "]");
				var5 = this.mappingUtils.getWimService().search(var5);
			}

			List var15 = var5.getList("entities");
			if (var15.isEmpty()) {
				throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1),
						this.className, var2);
			}

			if (var15.size() != 1) {
				boolean var17 = false;
				int var18 = var15.size();
				StringBuilder var9 = new StringBuilder();
				HashSet var10 = new HashSet();

				for (int var19 = 0; var19 < var18; ++var19) {
					DataObject var11 = (DataObject) var15.get(var19);
					if (var11.get("identifier") != null) {
						DataObject var12 = (DataObject) var11.get("identifier");
						if (var12.get("repositoryId") != null) {
							String var13 = String.valueOf(var12.get("repositoryId"));
							if (!var10.contains(var13)) {
								var10.add(var13);
							}
						}
					}
				}

				if (var10.size() == 0) {
					var9.append("repositories");
				} else {
					var9.append(var10);
				}

				throw new EntityNotFoundException("MULTIPLE_PRINCIPALS_FOUND",
						WIMMessageHelper.generateMsgParms(var1, var9), this.className, var2);
			}

			DataObject var16 = (DataObject) var15.get(0);
			if (!this.mappingUtils
					.isIdentifierTypeProperty(this.propertyMap.getOutputGroupSecurityName(var4.getRealm()))) {
				var3 = var16.getString(this.propertyMap.getOutputGroupSecurityName(var4.getRealm()));
			} else {
				var3 = var16.getString("identifier/" + this.propertyMap.getOutputGroupSecurityName(var4.getRealm()));
			}
		} catch (WIMException var14) {
			this.mappingUtils.logException(var14, this.className);
			if (var14 instanceof EntityNotFoundException) {
				throw new EntryNotFoundException(var14);
			}

			if (var14 instanceof EntityNotInRealmScopeException) {
				throw new EntryNotFoundException(var14);
			}

			if (var14 instanceof InvalidUniqueNameException) {
				throw new EntryNotFoundException(var14);
			}

			if (var14 instanceof InvalidIdentifierException) {
				throw new EntryNotFoundException(var14);
			}

			throw new CustomRegistryException(var14);
		}

		if (this.securityNameBridgeTrace.isLoggable(Level.FINER)) {
			this.securityNameBridgeTrace.exiting(this.className, var2, "returnValue = \"" + var3 + "\"");
		}

		return var3;
	}
}