package com.ibm.CORBA.services;

interface package-info {
}