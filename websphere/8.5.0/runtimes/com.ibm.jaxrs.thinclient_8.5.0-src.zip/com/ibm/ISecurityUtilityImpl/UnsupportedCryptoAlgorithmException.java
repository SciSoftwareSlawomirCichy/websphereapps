package com.ibm.ISecurityUtilityImpl;

import org.omg.CORBA.UserException;

public class UnsupportedCryptoAlgorithmException extends UserException {
	private static final long serialVersionUID = -1038233301900299114L;
}