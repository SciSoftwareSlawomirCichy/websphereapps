package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.concurrent.Future;
import javax.ejb.Timer;

public class AsyncMethodWrapper extends EJSWrapperBase implements Runnable {
	private static final String CLASS_NAME = AsyncMethodWrapper.class.getName();
	private static final TraceComponent tc = Tr.register(AsyncMethodWrapper.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	protected final int ivMethodId;
	private Object[] ivArgs = null;
	private ServerAsyncResult ivServerFuture = null;
	private long ivStartTime;

	public AsyncMethodWrapper(EJSWrapperBase theCallingWrapper, int theMethodId, Object[] theMethodArgs,
			ServerAsyncResult theServerFuture) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "<init> : " + theCallingWrapper + ", " + theMethodId + ", " + theServerFuture);
		}

		super.container = theCallingWrapper.container;
		super.wrapperManager = theCallingWrapper.wrapperManager;
		super.beanId = theCallingWrapper.beanId;
		super.bmd = theCallingWrapper.bmd;
		super.isolationAttrs = theCallingWrapper.isolationAttrs;
		super.ivCommon = theCallingWrapper.ivCommon;
		super.isManagedWrapper = false;
		super.ivPmiBean = theCallingWrapper.ivPmiBean;
		super.methodInfos = theCallingWrapper.methodInfos;
		super.methodNames = theCallingWrapper.methodNames;
		super.ivInterface = theCallingWrapper.ivInterface;
		super.ivBusinessInterfaceIndex = theCallingWrapper.ivBusinessInterfaceIndex;
		this.ivMethodId = theMethodId;
		this.ivArgs = theMethodArgs;
		this.ivServerFuture = theServerFuture;
		if (this.ivPmiBean != null) {
			this.ivStartTime = this.ivPmiBean.initialTime(39);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "<init> : " + this);
		}

	}

	public void run() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "run : async method " + this.methodInfos[this.ivMethodId].getMethodName() + " : " + this);
		}

		if (this.ivPmiBean != null && this.ivStartTime > 0L) {
			this.ivPmiBean.finalTime(39, this.ivStartTime);
			this.ivPmiBean.asyncQueSizeDecrement();
		}

		Future<?> theResult = null;
		EJBMethodInfoImpl methodInfo = this.methodInfos[this.ivMethodId];
		Method theMethod = methodInfo.ivMethod;
		EJSDeployedSupport s = new EJSDeployedSupport();
		s.ivAsyncResult = this.ivServerFuture;
		boolean isVoidReturnType = theMethod.getReturnType() == Void.TYPE;
		s.ivIgnoreApplicationExceptions = isVoidReturnType;

		try {
			try {
				Object theBean = this.container.EjbPreInvoke(this, this.ivMethodId, s, this.ivArgs);
				if (methodInfo.getAroundInterceptorProxies() == null) {
					try {
						theResult = (Future) theMethod.invoke(theBean, this.ivArgs);
					} catch (InvocationTargetException var19) {
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, "Caught InvocationTargetException, unwrapping : " + var19);
						}

						throw var19.getCause();
					}
				} else {
					theResult = (Future) this.container.invoke(s, (Timer) null);
				}

				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Async method completed successfully");
				}
			} catch (Throwable var20) {
				boolean declared = this.isApplicationException(var20, methodInfo);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "Caught Throwable (declared=" + declared + "): " + var20);
				}

				if (declared) {
					s.setCheckedException((Exception) var20);
					throw var20;
				}

				s.setUncheckedLocalException(var20);
			} finally {
				try {
					this.container.postInvoke(this, this.ivMethodId, s);
				} catch (RemoteException var18) {
					FFDCFilter.processException(var18, CLASS_NAME + ".run", "242", this);
					s.setUncheckedLocalException(var18);
				}

			}
		} catch (Throwable var22) {
			Throwable ex = var22;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "Async method completed with exception : " + var22);
			}

			if (this.ivServerFuture != null) {
				ex = this.mapSystemExceptionBackToRemoteException(var22);
				this.ivServerFuture.setException(ex);
			}

			if (this.ivPmiBean != null && isVoidReturnType) {
				this.ivPmiBean.asyncFNFFailed();
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "run : " + ex);
			}

			return;
		}

		if (this.ivServerFuture != null) {
			this.ivServerFuture.setResult(theResult);
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "run");
		}

	}

	private boolean isApplicationException(Throwable ex, EJBMethodInfoImpl methodInfo) {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "isApplicationException : " + ex.getClass().getName() + ", " + methodInfo);
		}

		if (ex instanceof Exception
				&& (!ContainerProperties.DeclaredUncheckedAreSystemExceptions || !(ex instanceof RuntimeException))) {
			Class<?>[] declaredExceptions = null;
			int len$;
			int i$;
			if (this.ivInterface != WrapperInterface.LOCAL && this.ivInterface != WrapperInterface.REMOTE) {
				if (this.ivBusinessInterfaceIndex == -2) {
					Class[][] arr$ = methodInfo.ivDeclaredExceptions;
					len$ = arr$.length;

					for (i$ = 0; i$ < len$; ++i$) {
						Class<?>[] declaredEx = arr$[i$];
						if (declaredEx != null) {
							declaredExceptions = declaredEx;
							break;
						}
					}
				} else {
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "ivBusinessInterfaceIndex=" + this.ivBusinessInterfaceIndex);
					}

					declaredExceptions = methodInfo.ivDeclaredExceptions[this.ivBusinessInterfaceIndex];
				}
			} else {
				declaredExceptions = methodInfo.ivDeclaredExceptionsComp;
			}

			if (declaredExceptions != null) {
				Class[] arr$ = declaredExceptions;
				len$ = declaredExceptions.length;

				for (i$ = 0; i$ < len$; ++i$) {
					Class<?> declaredException = arr$[i$];
					if (declaredException.isAssignableFrom(ex.getClass())) {
						if (isTraceOn && tc.isEntryEnabled()) {
							Tr.exit(tc, "isApplicationException : true");
						}

						return true;
					}
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "isApplicationException : false");
		}

		return false;
	}

	protected Throwable mapSystemExceptionBackToRemoteException(Throwable ex) {
		return ex;
	}
}