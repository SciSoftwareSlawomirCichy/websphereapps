package com.ibm.ws.security.openid20.client.resources;

import java.util.ListResourceBundle;

public class oidmessages extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{{"security.openid20.client.authrequestfailed",
			"CWTAI3002E: The OpenID relying party (RP) failed to redirect the user to the OpenID provider (OP) for authentication because of exception [{0}]."},
			{"security.openid20.client.defaultsslcontext",
					"CWTAI3014E: The OpenID relying party (RP) failed to initialize because it failed to get the default SSLContext for the WebSphere server. The exception is [{0}]"},
			{"security.openid20.client.discoveryfailed",
					"CWTAI3003E: The OpenID relying party (RP) failed to connect to the OpenID provider (OP) specified by the identifier [{0}] because of the exception [{1}]."},
			{"security.openid20.client.initializationfailed",
					"CWTAI3005E: The OpenID relying party (RP) failed to initialize because of exception [{0}]."},
			{"security.openid20.client.invalidaxrequired",
					"CWTAI3009E: The OpenID relying party (RP) did initialize because the value for the [{0}] property is not formatted correctly."},
			{"security.openid20.client.invalidbasicauthheader",
					"CWTAI3008E: The OpenID relying party (RP) failed to authenticate a request using the Basic Auth token because the token value is not valid."},
			{"security.openid20.client.invalidprovideridentifier",
					"CWTAI3011E: The OpenID relying party (RP) failed to initialize because the [{0}] property is not specified correctly. It should be a valid URL."},
			{"security.openid20.client.invalidresponse",
					"CWTAI3013E: The OpenID relying party (RP) received an incorrect response from the OpenID provider (OP). The cause of this error is [{0}]. "},
			{"security.openid20.client.maxcachesizereached",
					"CWTAI3012E: The OpenID relying party (RP) failed to perform authentication because it has reached the maximum capacity of its internal cache."},
			{"security.openid20.client.minaxrequired",
					"CWTAI3010E: The OpenID relying party (RP) failed to initialize because of missing required property axRequiredAttribute[n]. At least one property needs to be defined."},
			{"security.openid20.client.missingproperty",
					"CWTAI3001E: The OpenID relying party (RP) failed to initialize because the value for the mandatory property [{0}] is missing or empty."},
			{"security.openid20.client.opendpointnothttps",
					"CWTAI3007E: The OpenID relying party (RP) requires SSL (HTTPS) but the OpenID provider (OP) URL is HTTP: [{0}].  The [{1}] attribute should match the target URL scheme. "},
			{"security.openid20.client.opnotversion2warn",
					"CWTAI3006W: The OpenID relying party (RP) received a response from the OpenID provider (OP) which does not support OpenID specification version 2."},
			{"security.openid20.client.verifyauthresponsefailed",
					"CWTAI3004E: The OpenID relying party (RP) failed during verification of the response received from the OpenID provider (OP). The exception was [{0}]."}};

	public Object[][] getContents() {
		return resources;
	}
}