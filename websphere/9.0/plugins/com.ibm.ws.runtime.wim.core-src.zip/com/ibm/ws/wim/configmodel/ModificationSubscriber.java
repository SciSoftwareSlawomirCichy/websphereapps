package com.ibm.ws.wim.configmodel;

import java.util.List;

public interface ModificationSubscriber {
	String getModificationSubscriberReference();

	void setModificationSubscriberReference(String var1);

	List getRealmList();

	void setRealmList(List var1);

	void unsetRealmList();

	boolean isSetRealmList();
}