package com.ibm.ejs.cm.pool;

import java.io.PrintWriter;
import java.sql.SQLException;
import javax.sql.ConnectionPoolDataSource;

public final class JDBC1xConnectionFactory implements ConnectionFactory {
	private ConnectionPoolDataSource ds;

	public JDBC1xConnectionFactory(ConnectionPoolDataSource ds) {
		this.ds = ds;
	}

	public ConnectO createConnection(ConnectionPool pool) throws SQLException {
		return new ConnectO(this.ds.getPooledConnection(), pool, (String) null, (String) null);
	}

	public ConnectO createConnection(ConnectionPool pool, String username, String password) throws SQLException {
		return new ConnectO(this.ds.getPooledConnection(username, password), pool, username, password);
	}

	public PrintWriter getLogWriter() throws SQLException {
		return this.ds.getLogWriter();
	}

	public void setLogWriter(PrintWriter out) throws SQLException {
		this.ds.setLogWriter(out);
	}

	public int getLoginTimeout(int seconds) throws SQLException {
		return this.ds.getLoginTimeout();
	}

	public void setLoginTimeout(int seconds) throws SQLException {
		this.ds.setLoginTimeout(seconds);
	}
}