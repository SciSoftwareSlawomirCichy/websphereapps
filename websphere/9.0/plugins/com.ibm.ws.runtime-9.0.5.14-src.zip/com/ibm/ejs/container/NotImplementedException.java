package com.ibm.ejs.container;

public class NotImplementedException extends RuntimeException {
	private static final long serialVersionUID = 1235463249107176980L;
}