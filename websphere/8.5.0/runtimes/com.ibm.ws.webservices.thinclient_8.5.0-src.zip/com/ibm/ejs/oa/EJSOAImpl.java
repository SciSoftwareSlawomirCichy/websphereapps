package com.ibm.ejs.oa;

import com.ibm.CORBA.iiop.IOR;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.ByteArray;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSIServant;
import com.ibm.websphere.csi.ObjectAdapter;
import com.ibm.websphere.csi.ServantManager;
import com.ibm.wsspi.cluster.Identity;
import java.rmi.Remote;
import java.rmi.RemoteException;
import javax.rmi.PortableRemoteObject;
import javax.rmi.CORBA.Util;
import org.omg.CORBA.Object;

public class EJSOAImpl implements EJSObjectAdapter, ObjectAdapter {
	private final EJSRootOAImpl rootOA;
	private ServantManager sm;
	private final ByteArray key;
	private static final TraceComponent tc = Tr.register(EJSOAImpl.class, "ObjectAdapter",
			"com.ibm.ws.runtime.runtime");

	EJSOAImpl(EJSRootOAImpl rootOA, String oaName, ServantManager sm) {
		this.rootOA = rootOA;
		this.sm = sm;
		this.key = new ByteArray(oaName.getBytes());
	}

	EJSOAImpl(EJSRootOAImpl rootOA, String oaName) {
		this.rootOA = rootOA;
		this.sm = null;
		this.key = new ByteArray(oaName.getBytes());
	}

	public void registerServantManager(ServantManager servantManager) throws CSIException {
		this.sm = servantManager;
	}

	public void registerServant(CSIServant servant, byte[] key) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.registerServant(CSIServant, byte[])");
		}

		try {
			this.registerServant(servant, (byte[]) key, servant.wlmable(), false);
		} catch (Exception var4) {
			throw new CSIException("registerServant failed", var4);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.registerServant(CSIServant, byte[])");
		}

	}

	public void registerServant(CSIServant servant, byte[] key, boolean useLsd) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.registerServant(CSIServant, byte[], useLsd)");
		}

		try {
			this.registerServant(servant, (byte[]) key, servant.wlmable(), useLsd);
		} catch (Exception var5) {
			throw new CSIException("registerServant failed", var5);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.registerServant(CSIServant, byte[], useLsd)");
		}

	}

	public void registerServant(CSIServant servant, ByteArray key, boolean useLsd) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.registerServant(CSIServant, ByteArray, useLsd)");
		}

		try {
			this.registerServant(servant, (ByteArray) key, servant.wlmable(), useLsd);
		} catch (Exception var5) {
			throw new CSIException("registerServant failed", var5);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.registerServant(CSIServant, ByteArray, useLsd)");
		}

	}

	public void registerServant(Remote servant, byte[] key, boolean wlmable, boolean useLsd)
			throws InvalidServantException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.registerServant(Remote, byte[], wlmable, useLsd)");
		}

		try {
			if (!EJSPlatformHelper.isZOS()) {
				PortableRemoteObject.exportObject(servant);
			}

			Object tie = (Object) Util.getTie(servant);
			if (tie.getClass().getName().equals("com.ibm.ejs.container._EJSWrapper_Tie")) {
				String remoteClassName = servant.getClass().getName();
				Tr.warning(tc, "WSVR0056W", remoteClassName);
			}

			this.rootOA.registerServant(tie, key, wlmable, useLsd, this);
		} catch (RemoteException var7) {
			throw new InvalidServantException("PortableRemoteObject.exportObject failed", var7);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.registerServant(Remote, byte[], wlmable, useLsd)");
		}

	}

	public void registerServant(Remote servant, ByteArray key, boolean wlmable, boolean useLsd)
			throws InvalidServantException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.registerServant(Remote, ByteArray, wlmable, useLsd)");
		}

		try {
			if (!EJSPlatformHelper.isZOS()) {
				PortableRemoteObject.exportObject(servant);
			}

			Object tie = (Object) Util.getTie(servant);
			if (tie.getClass().getName().equals("com.ibm.ejs.container._EJSWrapper_Tie")) {
				String remoteClassName = servant.getClass().getName();
				Tr.warning(tc, "WSVR0056W", remoteClassName);
			}

			this.rootOA.registerServant(tie, key, wlmable, useLsd, this);
		} catch (RemoteException var7) {
			throw new InvalidServantException("PortableRemoteObject.exportObject failed", var7);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.registerServant(Remote, ByteArray, wlmable, useLsd)");
		}

	}

	public void registerServant(Remote servant, ByteArray key, Identity cluster, boolean useLsd) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.registerServant(Remote, ByteArray, Identity, useLsd)");
		}

		try {
			if (!EJSPlatformHelper.isZOS()) {
				try {
					PortableRemoteObject.exportObject(servant);
				} catch (RemoteException var7) {
					throw new InvalidServantException("PortableRemoteObject.exportObject failed", var7);
				}
			}

			Object tie = (Object) Util.getTie(servant);
			if (tie.getClass().getName().equals("com.ibm.ejs.container._EJSWrapper_Tie")) {
				String remoteClassName = servant.getClass().getName();
				Tr.warning(tc, "WSVR0056W", remoteClassName);
			}

			this.rootOA.registerServant(tie, key, cluster, useLsd, this);
		} catch (Exception var8) {
			throw new CSIException("registerServant failed", var8);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.registerServant(Remote, ByteArray, Identity, useLsd)");
		}

	}

	public void registerServant(Object servant) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.registerServant(org.omg.CORBA.Object)");
		}

		this.rootOA.registerServant(servant);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.registerServant(org.omg.CORBA.Object)");
		}

	}

	public void registerServant(Object servant, byte[] key) throws InvalidServantException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.registerServant(org.omg.CORBA.Object, byte[])");
		}

		this.registerServant(servant, key, false);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.registerServant(org.omg.CORBA.Object, byte[])");
		}

	}

	public void registerServant(Object servant, byte[] key, boolean wlmable) throws InvalidServantException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "registerServant(org.omg.CORBA.Object, byte[], wlmable)");
		}

		this.rootOA.registerServant(servant, key, wlmable, true, this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "registerServant(org.omg.CORBA.Object, byte[], wlmable)");
		}

	}

	public void registerServant(Object servant, byte[] key, Identity cluster) throws InvalidServantException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "registerServant(org.omg.CORBA.Object, byte[], Identity)");
		}

		this.rootOA.registerServant(servant, key, cluster, true, this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "registerServant(org.omg.CORBA.Object, byte[], Identity)");
		}

	}

	public void unregisterServant(CSIServant servant) throws CSIException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "unregisterServant");
		}

		try {
			Object tie = (Object) Util.getTie(servant);
			if (!EJSPlatformHelper.isZOS()) {
				this.rootOA.unregisterServantNoOrb(tie);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "> PortableRemoteObject.unexportObject");
				}

				PortableRemoteObject.unexportObject(servant);
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "< PortableRemoteObject.unexportObject");
				}
			} else {
				this.rootOA.unregisterServant(tie);
			}
		} catch (RemoteException var3) {
			throw new CSIException("PortableRemoteObject.unexportObject failed", var3);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.unregisterServant");
		}

	}

	public void unregisterServant(Object servant) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.unregisterServant");
		}

		this.rootOA.unregisterServant(servant);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.unregisterServant");
		}

	}

	final ByteArray getKey() {
		return this.key;
	}

	public Object keyToObject(byte[] key) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "keyToObject", key);
		}

		java.lang.Object servant = null;
		if (this.sm != null) {
			servant = this.sm.keyToObject(key);
			if (servant instanceof Remote) {
				servant = Util.getTie((Remote) servant);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "keyToObject", com.ibm.ejs.util.Util.identity(servant));
		}

		return (Object) servant;
	}

	public IOR createIOR(ByteArray key, Identity cluster, boolean useLsd, String typeid) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "EJSOAImpl.createIOR(byte[], Identity, boolean, String)");
		}

		IOR ior = this.rootOA.createIOR(key, cluster, useLsd, typeid, this);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "EJSOAImpl.createIOR(byte[], Identity, boolean, String)");
		}

		return ior;
	}
}