package com.ibm.ejs.container.util;

import com.ibm.websphere.csi.J2EEName;
import java.io.Serializable;

public class EJBInterfaceInfo implements Serializable {
	private static final long serialVersionUID = -4638070374419093229L;
	private final J2EEName ivJ2EEName;
	private final String ivInterfaceName;
	private final boolean ivIsHome;
	private final boolean ivIsLocal;

	public EJBInterfaceInfo(J2EEName j2eeName, String interfaceName, boolean isHome, boolean isLocal) {
		this.ivJ2EEName = j2eeName;
		this.ivInterfaceName = interfaceName;
		this.ivIsHome = isHome;
		this.ivIsLocal = isLocal;
	}

	public J2EEName getJ2eeName() {
		return this.ivJ2EEName;
	}

	public String getInterfaceName() {
		return this.ivInterfaceName;
	}

	public boolean isHomeInterfaceName() {
		return this.ivIsHome;
	}

	public boolean isLocalInterfaceName() {
		return this.ivIsLocal;
	}
}