package com.ibm.bsf.test.engineTests;

import com.ibm.bsf.BSFEngine;
import com.ibm.bsf.BSFException;
import com.ibm.bsf.test.BSFEngineTestTmpl;

public class jythonTest extends BSFEngineTestTmpl {
	private BSFEngine jythonEngine;

	public jythonTest(String var1) {
		super(var1);
	}

	public void setUp() {
		super.setUp();

		try {
			this.jythonEngine = this.bsfManager.loadScriptingEngine("jython");
		} catch (Exception var2) {
			fail(this.failMessage("Failure attempting to load jython", var2));
		}

	}

	public void testExec() {
		try {
			this.jythonEngine.exec("Test.py", 0, 0, "print \"PASSED\",");
		} catch (Exception var2) {
			fail(this.failMessage("exec() test failed", var2));
		}

		assertEquals("PASSED", this.getTmpOutStr());
	}

	public void testEval() {
		Integer var1 = null;

		try {
			var1 = new Integer(this.jythonEngine.eval("Test.py", 0, 0, "1 + 1").toString());
		} catch (Exception var3) {
			fail(this.failMessage("eval() test failed", var3));
		}

		assertEquals(new Integer(2), var1);
	}

	public void testCall() {
		Object[] var1 = new Object[]{new Integer(1)};
		Integer var2 = null;

		try {
			this.jythonEngine.exec("Test.py", 0, 0, "def addOne(f):\n\t return f + 1\n");
			var2 = new Integer(this.jythonEngine.call((Object) null, "addOne", var1).toString());
		} catch (Exception var4) {
			fail(this.failMessage("call() test failed", var4));
		}

		assertEquals(new Integer(2), var2);
	}

	public void testIexec() {
		try {
			this.jythonEngine.iexec("Test.py", 0, 0, "print \"PASSED\",\nprint \"FAILED\",");
		} catch (Exception var2) {
			fail(this.failMessage("iexec() test failed", var2));
		}

		assertEquals("PASSED", this.getTmpOutStr());
	}

	public void testBSFManagerEval() {
		Integer var1 = null;

		try {
			var1 = new Integer(this.bsfManager.eval("jython", "Test.py", 0, 0, "1 + 1").toString());
		} catch (Exception var3) {
			fail(this.failMessage("BSFManager eval() test failed", var3));
		}

		assertEquals(new Integer(2), var1);
	}

	public void testBSFManagerAvailability() {
		Object var1 = null;

		try {
			var1 = this.jythonEngine.eval("Test.py", 0, 0, "bsf.lookupBean(\"foo\")");
		} catch (Exception var3) {
			fail(this.failMessage("Test of BSFManager availability failed", var3));
		}

		assertEquals("None", var1.toString());
	}

	public void testRegisterBean() {
		Integer var1 = new Integer(1);
		Integer var2 = null;

		try {
			this.bsfManager.registerBean("foo", var1);
			var2 = new Integer(this.jythonEngine.eval("Test.py", 0, 0, "bsf.lookupBean(\"foo\")").toString());
		} catch (Exception var4) {
			fail(this.failMessage("registerBean() test failed", var4));
		}

		assertEquals(var1, var2);
	}

	public void testUnregisterBean() {
		Integer var1 = new Integer(1);
		Object var2 = null;

		try {
			this.bsfManager.registerBean("foo", var1);
			this.bsfManager.unregisterBean("foo");
			var2 = this.jythonEngine.eval("Test.py", 0, 0, "bsf.lookupBean(\"foo\")");
		} catch (Exception var4) {
			fail(this.failMessage("unregisterBean() test failed", var4));
		}

		assertEquals("None", var2.toString());
	}

	public void testDeclareBean() {
		Integer var1 = new Integer(1);
		Integer var2 = null;

		try {
			this.bsfManager.declareBean("foo", var1,
					class$java$lang$Integer == null
							? (class$java$lang$Integer = class$("java.lang.Integer"))
							: class$java$lang$Integer);
			var2 = new Integer(this.jythonEngine.eval("Test.py", 0, 0, "foo + 1").toString());
		} catch (Exception var4) {
			fail(this.failMessage("declareBean() test failed", var4));
		}

		assertEquals(new Integer(2), var2);
	}

	public void testUndeclareBean() {
		Integer var1 = new Integer(1);
		Integer var2 = null;

		try {
			this.bsfManager.declareBean("foo", var1,
					class$java$lang$Integer == null
							? (class$java$lang$Integer = class$("java.lang.Integer"))
							: class$java$lang$Integer);
			this.bsfManager.undeclareBean("foo");
			var2 = new Integer(this.jythonEngine.eval("Test.py", 0, 0, "foo + 1").toString());
		} catch (BSFException var4) {
			;
		} catch (Exception var5) {
			fail(this.failMessage("undeclareBean() test failed", var5));
		}

		assertNull(var2);
	}
}