package com.ibm.ws.security.oidc.client.filter;

import com.ibm.ws.security.oidc.util.MessageHelper;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class ValueIPAddress implements IValue {
	InetAddress myIP;

	public ValueIPAddress(String ip) throws FilterException {
		try {
			this.myIP = InetAddress.getByName(ip);
		} catch (UnknownHostException var4) {
			String msg = MessageHelper.getMessage("security.tai.ipstring.convert.error", new Object[]{ip});
			throw new FilterException(msg, var4);
		}
	}

	public boolean equals(IValue ip) {
		return ip.getClass() != ValueIPAddress.class ? false : ((ValueIPAddress) ip).getIP().equals(this.getIP());
	}

	public boolean greaterThan(IValue ip) {
		return ip.getClass() != ValueIPAddress.class
				? false
				: IPAddressRange.greaterThan(this.getIP(), ((ValueIPAddress) ip).getIP());
	}

	public boolean lessThan(IValue ip) {
		return ip.getClass() != ValueIPAddress.class
				? false
				: IPAddressRange.lessThan(this.getIP(), ((ValueIPAddress) ip).getIP());
	}

	public boolean containedBy(IValue ip) {
		return this.equals(ip);
	}

	public String toString() {
		return this.getIP().toString();
	}

	protected InetAddress getIP() {
		return this.myIP;
	}
}