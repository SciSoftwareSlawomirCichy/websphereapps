package com.ibm.bsf;

import com.ibm.bsf.util.CodeBuffer;
import java.beans.PropertyChangeListener;
import java.util.Vector;

public interface BSFEngine extends PropertyChangeListener {

	void disconnectedDebuggerNotify();

	Object getSpecificDebuggingInterface();

	void placeBreakpointAtLine(int var1, String var2, int var3) throws BSFException;

	void placeBreakpointAtOffset(int var1, String var2, int var3) throws BSFException;

	void removeBreakpoint(String var1, int var2) throws BSFException;

	void setEntryExit(String var1, boolean var2) throws BSFException;

	Object apply(String var1, int var2, int var3, Object var4, Vector var5, Vector var6) throws BSFException;

	Object call(Object var1, String var2, Object[] var3) throws BSFException;

	void compileApply(String var1, int var2, int var3, Object var4, Vector var5, Vector var6, CodeBuffer var7)
			throws BSFException;

	void compileExpr(String var1, int var2, int var3, Object var4, CodeBuffer var5) throws BSFException;

	void compileScript(String var1, int var2, int var3, Object var4, CodeBuffer var5) throws BSFException;

	void declareBean(BSFDeclaredBean var1) throws BSFException;

	Object eval(String var1, int var2, int var3, Object var4) throws BSFException;

	void exec(String var1, int var2, int var3, Object var4) throws BSFException;

	void iexec(String var1, int var2, int var3, Object var4) throws BSFException;

	void initialize(BSFManager var1, String var2, Vector var3) throws BSFException;

	void terminate();

	void undeclareBean(BSFDeclaredBean var1) throws BSFException;
}