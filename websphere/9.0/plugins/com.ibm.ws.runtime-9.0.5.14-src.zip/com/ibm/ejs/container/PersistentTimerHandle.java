package com.ibm.ejs.container;

import com.ibm.ejs.container.passivator.PassivatorSerializableHandle;
import com.ibm.ejs.container.util.EJSPlatformHelper;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ejb.portable.Constants;
import com.ibm.ws.ejbcontainer.runtime.EJBRuntime;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.ejb.EJBException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.Timer;
import javax.ejb.TimerHandle;

public final class PersistentTimerHandle implements TimerHandle, PassivatorSerializableHandle {
	private static final TraceComponent tc = Tr.register(PersistentTimerHandle.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final long serialVersionUID = -7720620493313660153L;
	private static final byte[] EYECATCHER;
	private static final short PLATFORM = 1;
	private static final short VERSION_ID = 1;
	protected transient Long taskId;
	protected transient boolean isTimer;

	protected PersistentTimerHandle(long taskId, boolean timer) {
		this.taskId = taskId;
		this.isTimer = timer;
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, this.toString());
		}

	}

	public Timer getTimer() throws IllegalStateException, NoSuchObjectLocalException, EJBException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getTimer: " + this);
		}

		if (EJSPlatformHelper.isZOSCRA()) {
			NoSuchObjectLocalException nsoe = new NoSuchObjectLocalException(
					this.toString() + " -- called from the adjunct control region.");
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getTimer: " + nsoe);
			}

			throw nsoe;
		} else {
			this.checkTimerAccess();
			EJBRuntime ejbRuntime = EJSContainer.getDefaultContainer().getEJBRuntime();
			Timer timer = ejbRuntime.getPersistentTimerFromStore(this.taskId);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "getTimer: " + timer);
			}

			return timer;
		}
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "writeObject: " + this);
		}

		out.defaultWriteObject();
		out.write(EYECATCHER);
		out.writeShort(1);
		out.writeShort(1);
		out.writeBoolean(this.isTimer);
		out.writeLong(this.taskId);
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "writeObject");
		}

	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "readObject");
		}

		in.defaultReadObject();
		byte[] eyeCatcher = new byte[EYECATCHER.length];
		int bytesRead = false;

		int i;
		int bytesRead;
		for (i = 0; i < EYECATCHER.length; i += bytesRead) {
			bytesRead = in.read(eyeCatcher, i, EYECATCHER.length - i);
			if (bytesRead == -1) {
				throw new IOException("end of input stream while reading eye catcher");
			}
		}

		for (i = 0; i < EYECATCHER.length; ++i) {
			if (EYECATCHER[i] != eyeCatcher[i]) {
				String eyeCatcherString = new String(eyeCatcher);
				throw new IOException("Invalid eye catcher '" + eyeCatcherString + "' in TimerHandle input stream");
			}
		}

		short incoming_platform = in.readShort();
		short incoming_vid = in.readShort();
		if (isTraceOn && tc.isDebugEnabled()) {
			Tr.debug(tc, "readObject: platform = " + incoming_platform + ", version = " + incoming_vid);
		}

		if (incoming_vid != 1) {
			throw new InvalidObjectException(
					"EJB TimerHandle data stream is not of the correct version, this client should be updated.");
		} else {
			this.isTimer = in.readBoolean();
			this.taskId = in.readLong();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "readObject: " + this);
			}

		}
	}

	public Object getSerializedObject() {
		if (this.isTimer) {
			EJBRuntime ejbRuntime = EJSContainer.getDefaultContainer().getEJBRuntime();
			return ejbRuntime.getPersistentTimer(this.taskId);
		} else {
			return this;
		}
	}

	private void checkTimerAccess() throws IllegalStateException {
		BeanO beanO = EJSContainer.getCallbackBeanO();
		if (beanO != null) {
			beanO.checkTimerServiceAccess();
		} else {
			if (!EJSContainer.getDefaultContainer().allowTimerAccessOutsideBean) {
				IllegalStateException ise = new IllegalStateException(
						"TimerHandle methods not allowed - no active EJB");
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "checkTimerAccess: " + ise);
				}

				throw ise;
			}

			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "checkTimerAccess: TimerHandle access permitted outside of bean");
			}
		}

	}

	public boolean equals(Object obj) {
		if (obj instanceof PersistentTimerHandle) {
			PersistentTimerHandle timerHandle = (PersistentTimerHandle) obj;
			return this.taskId.equals(timerHandle.taskId);
		} else {
			return false;
		}
	}

	public int hashCode() {
		return (int) (this.taskId % 2147483647L);
	}

	public String toString() {
		return "PersistentTimerHandle(" + this.taskId + ")";
	}

	static {
		EYECATCHER = Constants.TIMER_HANDLE_EYE_CATCHER;
	}
}