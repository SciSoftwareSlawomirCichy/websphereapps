package com.ibm.icu.impl.locale;

import com.ibm.icu.impl.locale.LanguageTag.ParseStatus;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public final class InternalLocaleBuilder {
	private String _language;
	private String _script;
	private String _region;
	private String _variant;
	private SortedMap<Character, Extension> _extMap;
	private final boolean _lenientVariant;
	private static final String LOCALESEP = "_";

	public InternalLocaleBuilder() {
		this(false);
	}

	public InternalLocaleBuilder(boolean lenientVariant) {
		this._language = "";
		this._script = "";
		this._region = "";
		this._variant = "";
		this._lenientVariant = lenientVariant;
	}

	public boolean isLenientVariant() {
		return this._lenientVariant;
	}

	public InternalLocaleBuilder setLanguage(String language) throws LocaleSyntaxException {
		String newval = "";
		if (language.length() > 0) {
			if (!LanguageTag.isLanguage(language)) {
				throw new LocaleSyntaxException("Ill-formed language: " + language, 0);
			}

			newval = LanguageTag.canonicalizeLanguage(language);
		}

		this._language = newval;
		return this;
	}

	public InternalLocaleBuilder setScript(String script) throws LocaleSyntaxException {
		String newval = "";
		if (script.length() > 0) {
			if (!LanguageTag.isScript(script)) {
				throw new LocaleSyntaxException("Ill-formed script: " + script, 0);
			}

			newval = LanguageTag.canonicalizeScript(script);
		}

		this._script = newval;
		return this;
	}

	public InternalLocaleBuilder setRegion(String region) throws LocaleSyntaxException {
		String newval = "";
		if (region.length() > 0) {
			if (!LanguageTag.isRegion(region)) {
				throw new LocaleSyntaxException("Ill-formed region: " + region);
			}

			newval = LanguageTag.canonicalizeRegion(region);
		}

		this._region = newval;
		return this;
	}

	public InternalLocaleBuilder setVariant(String variant) throws LocaleSyntaxException {
		String newval = "";
		if (variant.length() > 0) {
			if (this._lenientVariant) {
				newval = variant;
			} else {
				newval = this.processVariant(variant);
			}
		}

		this._variant = newval;
		return this;
	}

	public InternalLocaleBuilder setUnicodeLocaleExtension(String key, String type) throws LocaleSyntaxException {
		if (key.length() == 0) {
			throw new LocaleSyntaxException("Empty Unicode locale extension key");
		} else if (!UnicodeLocaleExtension.isKey(key)) {
			throw new LocaleSyntaxException("Ill-formed Unicode locale extension key: " + key, 0);
		} else {
			key = UnicodeLocaleExtension.canonicalizeKey(key);
			UnicodeLocaleExtension ulext = null;
			if (this._extMap != null) {
				ulext = (UnicodeLocaleExtension) this._extMap.get('u');
			}

			if (type.length() == 0) {
				if (ulext != null) {
					ulext.remove(key);
					if (ulext.isEmpty()) {
						this._extMap.remove('u');
					}
				}
			} else {
				StringBuilder buf = new StringBuilder();
				StringTokenIterator sti = new StringTokenIterator(type, "-");

				for (String subtag = sti.first(); !sti.isDone(); subtag = sti.next()) {
					if (!UnicodeLocaleExtension.isTypeSubtag(subtag)) {
						throw new LocaleSyntaxException("Ill-formed Unicode locale extension type: " + type,
								sti.currentStart());
					}

					if (buf.length() > 0) {
						buf.append("-");
					}

					buf.append(UnicodeLocaleExtension.canonicalizeTypeSubtag(subtag));
				}

				if (ulext == null) {
					SortedMap<String, String> ktmap = new TreeMap();
					ktmap.put(key, buf.toString());
					ulext = new UnicodeLocaleExtension(ktmap);
					if (this._extMap == null) {
						this._extMap = new TreeMap();
					}

					this._extMap.put('u', ulext);
				} else {
					ulext.put(key, buf.toString());
				}
			}

			return this;
		}
	}

	public InternalLocaleBuilder setExtension(char singleton, String value) throws LocaleSyntaxException {
		String strSingleton = String.valueOf(singleton);
		if (!LanguageTag.isExtensionSingleton(strSingleton) && !LanguageTag.isPrivateuseSingleton(strSingleton)) {
			throw new LocaleSyntaxException("Ill-formed extension key: " + singleton);
		} else {
			strSingleton = LanguageTag.canonicalizeExtensionSingleton(strSingleton);
			Character key = strSingleton.charAt(0);
			if (value.length() == 0) {
				if (this._extMap != null) {
					this._extMap.remove(key);
				}
			} else {
				StringTokenIterator sti = new StringTokenIterator(value, "-");
				ParseStatus sts = new ParseStatus();
				Extension ext = Extension.create(key, sti, sts);
				if (sts.isError()) {
					throw new LocaleSyntaxException(sts.errorMsg, sts.errorIndex);
				}

				if (sts.parseLength != value.length() || ext == null) {
					throw new LocaleSyntaxException("Ill-formed extension value: " + value, sti.currentStart());
				}

				if (this._extMap == null) {
					this._extMap = new TreeMap();
				}

				this._extMap.put(key, ext);
			}

			return this;
		}
	}

	public InternalLocaleBuilder setLocale(BaseLocale base, LocaleExtensions extensions) throws LocaleSyntaxException {
		String language = base.getLanguage();
		String script = base.getScript();
		String region = base.getRegion();
		String variant = base.getVariant();
		if (language.length() > 0) {
			if (!LanguageTag.isLanguage(language)) {
				throw new LocaleSyntaxException("Ill-formed language: " + language);
			}

			language = LanguageTag.canonicalizeLanguage(language);
		}

		if (script.length() > 0) {
			if (!LanguageTag.isScript(script)) {
				throw new LocaleSyntaxException("Ill-formed script: " + script);
			}

			script = LanguageTag.canonicalizeScript(script);
		}

		if (region.length() > 0) {
			if (!LanguageTag.isRegion(region)) {
				throw new LocaleSyntaxException("Ill-formed region: " + region);
			}

			region = LanguageTag.canonicalizeRegion(region);
		}

		if (this._lenientVariant) {
			String privuse = extensions.getExtensionValue("x".charAt(0));
			if (privuse != null) {
				variant = LanguageTag.getJavaCompatibleVariant(variant, privuse);
			}
		} else if (variant.length() > 0) {
			variant = this.processVariant(variant);
		}

		this._language = language;
		this._script = script;
		this._region = region;
		this._variant = variant;
		if (this._extMap == null) {
			this._extMap = new TreeMap();
		} else {
			this._extMap.clear();
		}

		Set<Character> extKeys = extensions.getKeys();

		Character key;
		Object ext;
		for (Iterator i$ = extKeys.iterator(); i$.hasNext(); this._extMap.put(key, ext)) {
			key = (Character) i$.next();
			ext = extensions.getExtension(key);
			if (this._lenientVariant && ext instanceof PrivateuseExtension) {
				String modPrivuse = LanguageTag.getJavaCompatiblePrivateuse(((Extension) ext).getValue());
				if (!modPrivuse.equals(((Extension) ext).getValue())) {
					ext = new PrivateuseExtension(modPrivuse);
				}
			}
		}

		return this;
	}

	public InternalLocaleBuilder clear() {
		this._language = "";
		this._script = "";
		this._region = "";
		this._variant = "";
		this.removeLocaleExtensions();
		return this;
	}

	public InternalLocaleBuilder removeLocaleExtensions() {
		if (this._extMap != null) {
			this._extMap.clear();
		}

		return this;
	}

	public BaseLocale getBaseLocale() {
		return BaseLocale.getInstance(this._language, this._script, this._region, this._variant);
	}

	public LocaleExtensions getLocaleExtensions() {
		return this._extMap != null && this._extMap.size() > 0
				? LocaleExtensions.getInstance(this._extMap)
				: LocaleExtensions.EMPTY_EXTENSIONS;
	}

	private String processVariant(String variant) throws LocaleSyntaxException {
		StringTokenIterator sti = new StringTokenIterator(variant, "_");
		ParseStatus sts = new ParseStatus();
		List<String> variants = LanguageTag.DEFAULT_PARSER.parseVariants(sti, sts);
		if (sts.parseLength != variant.length()) {
			throw new LocaleSyntaxException("Ill-formed variant: " + variant, sti.currentStart());
		} else {
			StringBuilder buf = new StringBuilder();

			String var;
			for (Iterator i$ = variants.iterator(); i$.hasNext(); buf.append(var)) {
				var = (String) i$.next();
				if (buf.length() != 0) {
					buf.append("_");
				}
			}

			return buf.toString();
		}
	}
}