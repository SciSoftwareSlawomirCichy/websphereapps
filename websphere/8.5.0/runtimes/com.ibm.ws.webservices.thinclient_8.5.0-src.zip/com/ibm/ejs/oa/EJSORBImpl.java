package com.ibm.ejs.oa;

import com.ibm.CORBA.iiop.ORB;
import com.ibm.ejs.oa.EJSORBImpl.1;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.orb.GlobalORBFactory;
import com.ibm.ws.security.util.AccessController;
import java.applet.Applet;
import java.util.Properties;

abstract class EJSORBImpl {
	protected static final String OBJECT_RESOLVER_PROPERTY = "com.ibm.CORBA.ObjectResolver";
	protected static final String SERVER_NAME_PROPERTY = "com.ibm.CORBA.ServerName";
	protected static final String SERVER_ID_PROPERTY = "com.ibm.CORBA.ServerId";
	protected static final String SERVER_UUID_PROPERTY = "com.ibm.CORBA.ServerUUID";

	protected static final String LSD_HOSTNAME_PROPERTY = "com.ibm.CORBA.LSDHostName";

	protected static final String LSD_PORT_PROPERTY = "com.ibm.CORBA.LSDPort";
	protected static final String BOOTSTRAP_PORT_PROPERTY = "com.ibm.CORBA.BootstrapPort";
	protected static final String BOOTSTRAP_HOST_PROPERTY = "com.ibm.CORBA.BootstrapHost";
	protected static final String LISTENER_PORT_PROPERTY = "com.ibm.CORBA.ListenerPort";
	protected static final String ORB_CLASS_PROPERTY = "org.omg.CORBA.ORBClass";
	protected static final String REQUEST_TIMEOUT_PROPERTY = "com.ibm.CORBA.requestTimeout";
	protected static final String LOCAL_HOST_PROPERTY = "com.ibm.CORBA.LocalHost";

	protected static final String SSL_PORT_PROPERTY = "com.ibm.CORBA.SSLPort";

	protected static final String LSDSSL_PORT_PROPERTY = "com.ibm.CORBA.LSDSSLPort";

	protected static final String LSDSSL_PORT_PROPERTY_DEFAULT_VAL = "9001";
	protected ORB orb = null;
	private static final TraceComponent tc = Tr.register(EJSORBImpl.class, "ObjectAdapter",
			"com.ibm.ws.runtime.runtime");
	protected static final Properties defaultProperties = new Properties();

	abstract void terminate();

	final ORB getORB() {
		return this.orb;
	}

	final int getBootstrapPort() {
		return this.orb.getBootstrapPort();
	}

	final String getBootstrapHost() {
		return this.orb.getBootstrapHost();
	}

	protected void initializeORB(Applet applet, String bootstrapHost, int bootstrapPort, Properties orbProperties) {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "initializeORB",
					new Object[]{applet, bootstrapHost, new Integer(bootstrapPort), orbProperties});
		}

		if (bootstrapHost != null && bootstrapHost.length() != 0) {
			orbProperties.put("com.ibm.CORBA.BootstrapHost", bootstrapHost);
		}

		if (bootstrapPort > 0) {
			orbProperties.put("com.ibm.CORBA.BootstrapPort", String.valueOf(bootstrapPort));
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "Initializing ORB", orbProperties);
		}

		if (applet == null) {
			Class var5 = GlobalORBFactory.class;
			synchronized (GlobalORBFactory.class) {
				this.orb = GlobalORBFactory.globalORB();
				if (this.orb == null) {
					this.orb = GlobalORBFactory.init(new String[0], orbProperties);
				}
			}
		} else {
			this.orb = GlobalORBFactory.init(applet, orbProperties);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "initializeORB");
		}

	}

	static {
      AccessController.doPrivileged(new 1());
      if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
         Tr.debug(tc, "Default ORB initializaiton properties", defaultProperties);
      }

   }
}