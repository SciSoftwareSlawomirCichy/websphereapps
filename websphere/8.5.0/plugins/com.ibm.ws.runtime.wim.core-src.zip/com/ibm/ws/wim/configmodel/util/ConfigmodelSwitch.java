package com.ibm.ws.wim.configmodel.util;

import com.ibm.ws.wim.configmodel.AttributeConfigurationType;
import com.ibm.ws.wim.configmodel.AttributeGroupType;
import com.ibm.ws.wim.configmodel.AttributeType;
import com.ibm.ws.wim.configmodel.AttributesCacheType;
import com.ibm.ws.wim.configmodel.AuthorizationType;
import com.ibm.ws.wim.configmodel.BaseEntriesType;
import com.ibm.ws.wim.configmodel.CacheConfigurationType;
import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.ConnectionsType;
import com.ibm.ws.wim.configmodel.ContextPoolType;
import com.ibm.ws.wim.configmodel.CustomPropertiesType;
import com.ibm.ws.wim.configmodel.DatabaseRepositoryType;
import com.ibm.ws.wim.configmodel.DocumentRoot;
import com.ibm.ws.wim.configmodel.DynamicMemberAttributesType;
import com.ibm.ws.wim.configmodel.DynamicModelType;
import com.ibm.ws.wim.configmodel.EntryMappingRepositoryType;
import com.ibm.ws.wim.configmodel.EnvironmentPropertiesType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.GroupConfigurationType;
import com.ibm.ws.wim.configmodel.InlineExit;
import com.ibm.ws.wim.configmodel.LdapEntityTypesType;
import com.ibm.ws.wim.configmodel.LdapRepositoryType;
import com.ibm.ws.wim.configmodel.LdapServerConfigurationType;
import com.ibm.ws.wim.configmodel.LdapServersType;
import com.ibm.ws.wim.configmodel.MemberAttributesType;
import com.ibm.ws.wim.configmodel.MembershipAttributeType;
import com.ibm.ws.wim.configmodel.ModificationSubscriber;
import com.ibm.ws.wim.configmodel.ModificationSubscriberList;
import com.ibm.ws.wim.configmodel.NotificationSubscriber;
import com.ibm.ws.wim.configmodel.NotificationSubscriberList;
import com.ibm.ws.wim.configmodel.ParticipatingBaseEntriesType;
import com.ibm.ws.wim.configmodel.PluginManagerConfigurationType;
import com.ibm.ws.wim.configmodel.PostExit;
import com.ibm.ws.wim.configmodel.PreExit;
import com.ibm.ws.wim.configmodel.ProfileRepositoryType;
import com.ibm.ws.wim.configmodel.PropertiesNotSupportedType;
import com.ibm.ws.wim.configmodel.PropertyExtensionRepositoryType;
import com.ibm.ws.wim.configmodel.RdnAttributesType;
import com.ibm.ws.wim.configmodel.RealmConfigurationType;
import com.ibm.ws.wim.configmodel.RealmDefaultParentType;
import com.ibm.ws.wim.configmodel.RealmType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.configmodel.SPIBridgeRepositoryType;
import com.ibm.ws.wim.configmodel.SearchResultsCacheType;
import com.ibm.ws.wim.configmodel.StaticModelType;
import com.ibm.ws.wim.configmodel.SupportedEntityTypesType;
import com.ibm.ws.wim.configmodel.TopicEmitter;
import com.ibm.ws.wim.configmodel.TopicRegistrationList;
import com.ibm.ws.wim.configmodel.TopicSubscriber;
import com.ibm.ws.wim.configmodel.TopicSubscriberList;
import com.ibm.ws.wim.configmodel.UserRegistryInfoMappingType;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

public class ConfigmodelSwitch {
	protected static ConfigmodelPackage modelPackage;

	public ConfigmodelSwitch() {
		if (modelPackage == null) {
			modelPackage = ConfigmodelPackage.eINSTANCE;
		}

	}

	public Object doSwitch(EObject var1) {
		return this.doSwitch(var1.eClass(), var1);
	}

	protected Object doSwitch(EClass var1, EObject var2) {
		if (var1.eContainer() == modelPackage) {
			return this.doSwitch(var1.getClassifierID(), var2);
		} else {
			EList var3 = var1.getESuperTypes();
			return var3.isEmpty() ? this.defaultCase(var2) : this.doSwitch((EClass) var3.get(0), var2);
		}
	}

	protected Object doSwitch(int var1, EObject var2) {
		Object var4;
		switch (var1) {
			case 0 :
				AttributeConfigurationType var54 = (AttributeConfigurationType) var2;
				var4 = this.caseAttributeConfigurationType(var54);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 1 :
				AttributeGroupType var53 = (AttributeGroupType) var2;
				var4 = this.caseAttributeGroupType(var53);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 2 :
				AttributesCacheType var52 = (AttributesCacheType) var2;
				var4 = this.caseAttributesCacheType(var52);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 3 :
				AttributeType var51 = (AttributeType) var2;
				var4 = this.caseAttributeType(var51);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 4 :
				AuthorizationType var50 = (AuthorizationType) var2;
				var4 = this.caseAuthorizationType(var50);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 5 :
				BaseEntriesType var49 = (BaseEntriesType) var2;
				var4 = this.caseBaseEntriesType(var49);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 6 :
				CacheConfigurationType var48 = (CacheConfigurationType) var2;
				var4 = this.caseCacheConfigurationType(var48);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 7 :
				ConfigurationProviderType var47 = (ConfigurationProviderType) var2;
				var4 = this.caseConfigurationProviderType(var47);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 8 :
				ConnectionsType var46 = (ConnectionsType) var2;
				var4 = this.caseConnectionsType(var46);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 9 :
				ContextPoolType var45 = (ContextPoolType) var2;
				var4 = this.caseContextPoolType(var45);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 10 :
				CustomPropertiesType var44 = (CustomPropertiesType) var2;
				var4 = this.caseCustomPropertiesType(var44);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 11 :
				DatabaseRepositoryType var43 = (DatabaseRepositoryType) var2;
				var4 = this.caseDatabaseRepositoryType(var43);
				if (var4 == null) {
					var4 = this.caseProfileRepositoryType(var43);
				}

				if (var4 == null) {
					var4 = this.caseRepositoryType(var43);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 12 :
				DocumentRoot var42 = (DocumentRoot) var2;
				var4 = this.caseDocumentRoot(var42);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 13 :
				DynamicMemberAttributesType var41 = (DynamicMemberAttributesType) var2;
				var4 = this.caseDynamicMemberAttributesType(var41);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 14 :
				DynamicModelType var40 = (DynamicModelType) var2;
				var4 = this.caseDynamicModelType(var40);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 15 :
				EntryMappingRepositoryType var39 = (EntryMappingRepositoryType) var2;
				var4 = this.caseEntryMappingRepositoryType(var39);
				if (var4 == null) {
					var4 = this.caseRepositoryType(var39);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 16 :
				EnvironmentPropertiesType var38 = (EnvironmentPropertiesType) var2;
				var4 = this.caseEnvironmentPropertiesType(var38);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 17 :
				FileRepositoryType var37 = (FileRepositoryType) var2;
				var4 = this.caseFileRepositoryType(var37);
				if (var4 == null) {
					var4 = this.caseProfileRepositoryType(var37);
				}

				if (var4 == null) {
					var4 = this.caseRepositoryType(var37);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 18 :
				GroupConfigurationType var36 = (GroupConfigurationType) var2;
				var4 = this.caseGroupConfigurationType(var36);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 19 :
				InlineExit var35 = (InlineExit) var2;
				var4 = this.caseInlineExit(var35);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 20 :
				LdapEntityTypesType var34 = (LdapEntityTypesType) var2;
				var4 = this.caseLdapEntityTypesType(var34);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 21 :
				LdapRepositoryType var33 = (LdapRepositoryType) var2;
				var4 = this.caseLdapRepositoryType(var33);
				if (var4 == null) {
					var4 = this.caseProfileRepositoryType(var33);
				}

				if (var4 == null) {
					var4 = this.caseRepositoryType(var33);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 22 :
				LdapServerConfigurationType var32 = (LdapServerConfigurationType) var2;
				var4 = this.caseLdapServerConfigurationType(var32);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 23 :
				LdapServersType var31 = (LdapServersType) var2;
				var4 = this.caseLdapServersType(var31);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 24 :
				MemberAttributesType var30 = (MemberAttributesType) var2;
				var4 = this.caseMemberAttributesType(var30);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 25 :
				MembershipAttributeType var29 = (MembershipAttributeType) var2;
				var4 = this.caseMembershipAttributeType(var29);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 26 :
				ModificationSubscriber var28 = (ModificationSubscriber) var2;
				var4 = this.caseModificationSubscriber(var28);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 27 :
				ModificationSubscriberList var27 = (ModificationSubscriberList) var2;
				var4 = this.caseModificationSubscriberList(var27);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 28 :
				NotificationSubscriber var26 = (NotificationSubscriber) var2;
				var4 = this.caseNotificationSubscriber(var26);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 29 :
				NotificationSubscriberList var25 = (NotificationSubscriberList) var2;
				var4 = this.caseNotificationSubscriberList(var25);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 30 :
				ParticipatingBaseEntriesType var24 = (ParticipatingBaseEntriesType) var2;
				var4 = this.caseParticipatingBaseEntriesType(var24);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 31 :
				PluginManagerConfigurationType var23 = (PluginManagerConfigurationType) var2;
				var4 = this.casePluginManagerConfigurationType(var23);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 32 :
				PostExit var22 = (PostExit) var2;
				var4 = this.casePostExit(var22);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 33 :
				PreExit var21 = (PreExit) var2;
				var4 = this.casePreExit(var21);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 34 :
				ProfileRepositoryType var20 = (ProfileRepositoryType) var2;
				var4 = this.caseProfileRepositoryType(var20);
				if (var4 == null) {
					var4 = this.caseRepositoryType(var20);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 35 :
				PropertiesNotSupportedType var19 = (PropertiesNotSupportedType) var2;
				var4 = this.casePropertiesNotSupportedType(var19);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 36 :
				PropertyExtensionRepositoryType var18 = (PropertyExtensionRepositoryType) var2;
				var4 = this.casePropertyExtensionRepositoryType(var18);
				if (var4 == null) {
					var4 = this.caseRepositoryType(var18);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 37 :
				RdnAttributesType var17 = (RdnAttributesType) var2;
				var4 = this.caseRdnAttributesType(var17);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 38 :
				RealmConfigurationType var16 = (RealmConfigurationType) var2;
				var4 = this.caseRealmConfigurationType(var16);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 39 :
				RealmDefaultParentType var15 = (RealmDefaultParentType) var2;
				var4 = this.caseRealmDefaultParentType(var15);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 40 :
				RealmType var14 = (RealmType) var2;
				var4 = this.caseRealmType(var14);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 41 :
				RepositoryType var13 = (RepositoryType) var2;
				var4 = this.caseRepositoryType(var13);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 42 :
				SearchResultsCacheType var12 = (SearchResultsCacheType) var2;
				var4 = this.caseSearchResultsCacheType(var12);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 43 :
				SPIBridgeRepositoryType var11 = (SPIBridgeRepositoryType) var2;
				var4 = this.caseSPIBridgeRepositoryType(var11);
				if (var4 == null) {
					var4 = this.caseProfileRepositoryType(var11);
				}

				if (var4 == null) {
					var4 = this.caseRepositoryType(var11);
				}

				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 44 :
				StaticModelType var10 = (StaticModelType) var2;
				var4 = this.caseStaticModelType(var10);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 45 :
				SupportedEntityTypesType var9 = (SupportedEntityTypesType) var2;
				var4 = this.caseSupportedEntityTypesType(var9);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 46 :
				TopicEmitter var8 = (TopicEmitter) var2;
				var4 = this.caseTopicEmitter(var8);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 47 :
				TopicRegistrationList var7 = (TopicRegistrationList) var2;
				var4 = this.caseTopicRegistrationList(var7);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 48 :
				TopicSubscriber var6 = (TopicSubscriber) var2;
				var4 = this.caseTopicSubscriber(var6);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 49 :
				TopicSubscriberList var5 = (TopicSubscriberList) var2;
				var4 = this.caseTopicSubscriberList(var5);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			case 50 :
				UserRegistryInfoMappingType var3 = (UserRegistryInfoMappingType) var2;
				var4 = this.caseUserRegistryInfoMappingType(var3);
				if (var4 == null) {
					var4 = this.defaultCase(var2);
				}

				return var4;
			default :
				return this.defaultCase(var2);
		}
	}

	public Object caseAttributeConfigurationType(AttributeConfigurationType var1) {
		return null;
	}

	public Object caseAttributeGroupType(AttributeGroupType var1) {
		return null;
	}

	public Object caseAttributesCacheType(AttributesCacheType var1) {
		return null;
	}

	public Object caseAttributeType(AttributeType var1) {
		return null;
	}

	public Object caseAuthorizationType(AuthorizationType var1) {
		return null;
	}

	public Object caseBaseEntriesType(BaseEntriesType var1) {
		return null;
	}

	public Object caseCacheConfigurationType(CacheConfigurationType var1) {
		return null;
	}

	public Object caseConfigurationProviderType(ConfigurationProviderType var1) {
		return null;
	}

	public Object caseConnectionsType(ConnectionsType var1) {
		return null;
	}

	public Object caseContextPoolType(ContextPoolType var1) {
		return null;
	}

	public Object caseCustomPropertiesType(CustomPropertiesType var1) {
		return null;
	}

	public Object caseDatabaseRepositoryType(DatabaseRepositoryType var1) {
		return null;
	}

	public Object caseDocumentRoot(DocumentRoot var1) {
		return null;
	}

	public Object caseDynamicMemberAttributesType(DynamicMemberAttributesType var1) {
		return null;
	}

	public Object caseDynamicModelType(DynamicModelType var1) {
		return null;
	}

	public Object caseEntryMappingRepositoryType(EntryMappingRepositoryType var1) {
		return null;
	}

	public Object caseEnvironmentPropertiesType(EnvironmentPropertiesType var1) {
		return null;
	}

	public Object caseFileRepositoryType(FileRepositoryType var1) {
		return null;
	}

	public Object caseGroupConfigurationType(GroupConfigurationType var1) {
		return null;
	}

	public Object caseInlineExit(InlineExit var1) {
		return null;
	}

	public Object caseLdapEntityTypesType(LdapEntityTypesType var1) {
		return null;
	}

	public Object caseLdapRepositoryType(LdapRepositoryType var1) {
		return null;
	}

	public Object caseLdapServerConfigurationType(LdapServerConfigurationType var1) {
		return null;
	}

	public Object caseLdapServersType(LdapServersType var1) {
		return null;
	}

	public Object caseMemberAttributesType(MemberAttributesType var1) {
		return null;
	}

	public Object caseMembershipAttributeType(MembershipAttributeType var1) {
		return null;
	}

	public Object caseModificationSubscriber(ModificationSubscriber var1) {
		return null;
	}

	public Object caseModificationSubscriberList(ModificationSubscriberList var1) {
		return null;
	}

	public Object caseNotificationSubscriber(NotificationSubscriber var1) {
		return null;
	}

	public Object caseNotificationSubscriberList(NotificationSubscriberList var1) {
		return null;
	}

	public Object caseParticipatingBaseEntriesType(ParticipatingBaseEntriesType var1) {
		return null;
	}

	public Object casePluginManagerConfigurationType(PluginManagerConfigurationType var1) {
		return null;
	}

	public Object casePostExit(PostExit var1) {
		return null;
	}

	public Object casePreExit(PreExit var1) {
		return null;
	}

	public Object caseProfileRepositoryType(ProfileRepositoryType var1) {
		return null;
	}

	public Object casePropertiesNotSupportedType(PropertiesNotSupportedType var1) {
		return null;
	}

	public Object casePropertyExtensionRepositoryType(PropertyExtensionRepositoryType var1) {
		return null;
	}

	public Object caseRdnAttributesType(RdnAttributesType var1) {
		return null;
	}

	public Object caseRealmConfigurationType(RealmConfigurationType var1) {
		return null;
	}

	public Object caseRealmDefaultParentType(RealmDefaultParentType var1) {
		return null;
	}

	public Object caseRealmType(RealmType var1) {
		return null;
	}

	public Object caseRepositoryType(RepositoryType var1) {
		return null;
	}

	public Object caseSearchResultsCacheType(SearchResultsCacheType var1) {
		return null;
	}

	public Object caseSPIBridgeRepositoryType(SPIBridgeRepositoryType var1) {
		return null;
	}

	public Object caseStaticModelType(StaticModelType var1) {
		return null;
	}

	public Object caseSupportedEntityTypesType(SupportedEntityTypesType var1) {
		return null;
	}

	public Object caseTopicEmitter(TopicEmitter var1) {
		return null;
	}

	public Object caseTopicRegistrationList(TopicRegistrationList var1) {
		return null;
	}

	public Object caseTopicSubscriber(TopicSubscriber var1) {
		return null;
	}

	public Object caseTopicSubscriberList(TopicSubscriberList var1) {
		return null;
	}

	public Object caseUserRegistryInfoMappingType(UserRegistryInfoMappingType var1) {
		return null;
	}

	public Object defaultCase(EObject var1) {
		return null;
	}
}