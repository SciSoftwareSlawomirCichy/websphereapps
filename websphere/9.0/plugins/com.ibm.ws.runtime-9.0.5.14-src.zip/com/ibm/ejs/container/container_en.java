package com.ibm.ejs.container;

import java.util.ListResourceBundle;

public class container_en extends ListResourceBundle {
	private static final Object[][] resources = new Object[0][];

	public Object[][] getContents() {
		return resources;
	}
}