package com.ibm.ws.wim.adapter.ldap;

import javax.naming.directory.Attributes;

public class LdapEntry {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005, 2009";
	private String iDN = null;
	private String iExtId = null;
	private String iUniqueName = null;
	private String iType = null;
	private Attributes iAttrs = null;
	private String iChangeType = null;

	public LdapEntry(String var1, String var2, String var3, String var4, Attributes var5) {
		this.iDN = var1;
		this.iExtId = var2;
		this.iUniqueName = var3;
		this.iType = var4;
		this.iAttrs = var5;
		this.iChangeType = null;
	}

	public Attributes getAttributes() {
		return this.iAttrs;
	}

	public void setAttributes(Attributes var1) {
		this.iAttrs = var1;
	}

	public String getDN() {
		return this.iDN;
	}

	public void setDN(String var1) {
		this.iDN = var1;
	}

	public String getExtId() {
		return this.iExtId;
	}

	public void setExtId(String var1) {
		this.iExtId = var1;
	}

	public String getType() {
		return this.iType;
	}

	public void setType(String var1) {
		this.iType = var1;
	}

	public String getUniqueName() {
		return this.iUniqueName;
	}

	public void setIUniqueName(String var1) {
		this.iUniqueName = var1;
	}

	public String toString() {
		StringBuffer var1 = new StringBuffer();
		var1.append("\nDN: ").append(this.iDN).append("  ");
		var1.append("ExtId: ").append(this.iExtId).append("  ");
		var1.append("UniqueName: ").append(this.iUniqueName).append("  ");
		var1.append("Type: ").append(this.iType).append("\n");
		var1.append("Attributes: ").append(this.iAttrs);
		return var1.toString();
	}

	public void setChangeType(String var1) {
		this.iChangeType = var1;
	}

	public String getChangeType() {
		return this.iChangeType;
	}
}