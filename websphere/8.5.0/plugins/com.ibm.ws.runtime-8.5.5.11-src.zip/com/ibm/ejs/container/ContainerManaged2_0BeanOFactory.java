package com.ibm.ejs.container;

import com.ibm.ws.managedobject.ManagedObject;
import javax.ejb.EnterpriseBean;

public class ContainerManaged2_0BeanOFactory extends BeanOFactory {
	protected BeanO newInstance(EJSContainer c, ManagedObject mo, Object b, EJSHome h) {
		return new ContainerManaged2_0BeanO(c, (EnterpriseBean) b, h);
	}
}