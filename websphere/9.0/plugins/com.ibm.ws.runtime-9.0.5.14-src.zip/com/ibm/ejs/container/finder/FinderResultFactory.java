package com.ibm.ejs.container.finder;

import com.ibm.ejs.container.EJBMethodInfoImpl;
import com.ibm.ejs.container.EJSContainer;
import com.ibm.ejs.container.EJSDeployedSupport;
import com.ibm.ejs.container.EJSHome;
import com.ibm.ejs.container.EntityContainerTx;
import com.ibm.ejs.container.EntityHelperImpl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.csi.EJBMethodInfo;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Vector;
import javax.ejb.FinderException;

public abstract class FinderResultFactory {
	private static final TraceComponent tc = Tr.register(FinderResultFactory.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.finder.FinderResultFactory";

	public static Collection getCMP20FinderResultCollection(Collection pKeys, EJSHome home, EntityContainerTx txInfo,
			EntityHelperImpl entityHelper) throws FinderException, RemoteException {
		return finderResultCollection_Common(pKeys, home, txInfo, true, entityHelper);
	}

	public static Collection getCMP20FinderResultCollection_Local(Collection pKeys, EJSHome home,
			EntityContainerTx txInfo, EntityHelperImpl entityHelper) throws FinderException, RemoteException {
		return finderResultCollection_Common(pKeys, home, txInfo, false, entityHelper);
	}

	public static Collection getCMP20FinderResultCollection(Collection pKeys, EJSHome home, EntityContainerTx txInfo,
			AccessIntent ai, boolean isRemote) throws FinderException, RemoteException {
		int cScope = ai.getCollectionScope();
		return finderResultCollection_create(pKeys, home, txInfo, isRemote, (AccessIntent) null, cScope,
				Integer.MAX_VALUE);
	}

	public static Enumeration getCMP20FinderResultEnumeration(Enumeration pKeys, EJSHome home, EntityContainerTx txInfo,
			EntityHelperImpl entityhelper) throws FinderException, RemoteException {
		return finderResultEnumeration_Common(pKeys, home, txInfo, true, entityhelper);
	}

	public static Enumeration getCMP20FinderResultEnumeration_Local(Enumeration pKeys, EJSHome home,
			EntityContainerTx txInfo, EntityHelperImpl entityHelper) throws FinderException, RemoteException {
		return finderResultEnumeration_Common(pKeys, home, txInfo, false, entityHelper);
	}

	private static Collection finderResultCollection_Common(Collection pKeys, EJSHome home, EntityContainerTx txInfo,
			boolean isRemote, EntityHelperImpl entityHelper) throws FinderException, RemoteException {
		EJSDeployedSupport s = EJSContainer.getMethodContext();
		AccessIntent accessIntent = null;
		if (home.hasMethodLevelAccessIntentSet()) {
			EJBMethodInfo methodInfo = EntityHelperImpl.getEJBMethodInfo();
			accessIntent = methodInfo.getAccessIntent(entityHelper.getEJBAccessIntent());
		} else {
			accessIntent = EntityHelperImpl.getBeanLevelAccessIntent(home);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			EJBMethodInfoImpl methodInfo = s.getEJBMethodInfoImpl();
			Tr.entry(tc, "finderResultCollection_Common",
					new Object[]{methodInfo.getMethodSignature(), home, txInfo, isRemote, accessIntent});
		}

		int cScope = accessIntent.getCollectionScope();
		int cIncrement = accessIntent.getCollectionIncrement();
		if (txInfo.isTransactionGlobal() && !s.beganAndEndInThisScope()) {
			if (cIncrement == 0) {
				cIncrement = Integer.MAX_VALUE;
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "finderResultCollection_Common tran begins/ends in this scope");
			}

			cIncrement = Integer.MAX_VALUE;
			accessIntent = null;
		}

		Collection c = finderResultCollection_create(pKeys, home, txInfo, isRemote, accessIntent, cScope, cIncrement);
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "finderResultCollection_Common");
		}

		return c;
	}

	private static Collection finderResultCollection_create(Collection pKeys, EJSHome home, EntityContainerTx txInfo,
			boolean isRemote, AccessIntent accessIntent, int cScope, int cIncrement)
			throws FinderException, RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "finderResultCollection_create");
		}

		Collection c = null;
		FinderResultServerImpl serverImpl = new FinderResultServerImpl(pKeys, home, txInfo, isRemote, accessIntent);
		boolean asscope = serverImpl.setScope(cScope);
		Vector allWrappers;
		if (cIncrement != Integer.MAX_VALUE && !asscope) {
			allWrappers = null;
			serverImpl.exportFinderResultServerImpleResources();
			c = isRemote
					? new FinderResultClientCollection(serverImpl, cIncrement)
					: new FinderResultClientCollection_Local(serverImpl);
			txInfo.enlistContainerSync(serverImpl);
		} else {
			allWrappers = serverImpl.getAllWrapperCollection();
			c = isRemote
					? new FinderResultClientCollection(allWrappers)
					: new FinderResultClientCollection_Local(serverImpl);
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "finderResultCollection_create");
		}

		return (Collection) c;
	}

	private static Enumeration finderResultEnumeration_Common(Enumeration pKeys, EJSHome home, EntityContainerTx txInfo,
			boolean isRemote, EntityHelperImpl entityhelper) throws FinderException, RemoteException {
		EJSDeployedSupport s = EJSContainer.getMethodContext();
		EJBMethodInfo methodInfo = EntityHelperImpl.getEJBMethodInfo();
		AccessIntent accessIntent = methodInfo.getAccessIntent(entityhelper.getEJBAccessIntent());
		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.entry(tc, "finderResultEnumeration_Common",
					new Object[]{methodInfo.getMethodSignature(), home, txInfo, isRemote, accessIntent});
		}

		int cScope = accessIntent.getCollectionScope();
		int cIncrement = accessIntent.getCollectionIncrement();
		if (txInfo.isTransactionGlobal() && !s.beganAndEndInThisScope()) {
			if (cIncrement == 0) {
				cIncrement = Integer.MAX_VALUE;
			}
		} else {
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "finderResultEnumeration_Common tran begins/ends in this scope");
			}

			cIncrement = Integer.MAX_VALUE;
			accessIntent = null;
		}

		Enumeration vEnum = null;
		FinderResultServerImpl serverImpl = new FinderResultServerImpl(pKeys, home, txInfo, isRemote, accessIntent);
		serverImpl.setScope(cScope);
		Vector allWrappers;
		if (cIncrement == Integer.MAX_VALUE) {
			allWrappers = serverImpl.getAllWrapperCollection();
			vEnum = isRemote
					? new FinderResultClientEnumeration(allWrappers)
					: new FinderResultClientEnumeration_Local(serverImpl);
		} else {
			allWrappers = null;
			serverImpl.exportFinderResultServerImpleResources();
			vEnum = isRemote
					? new FinderResultClientEnumeration(serverImpl, cIncrement)
					: new FinderResultClientEnumeration_Local(serverImpl);
			switch (cScope) {
				case 1 :
				case 2 :
				default :
					txInfo.enlistContainerSync(serverImpl);
			}
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "finderResultEnumeration_Common");
		}

		return (Enumeration) vEnum;
	}
}