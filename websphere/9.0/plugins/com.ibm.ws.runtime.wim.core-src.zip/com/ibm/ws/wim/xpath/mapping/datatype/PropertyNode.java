package com.ibm.ws.wim.xpath.mapping.datatype;

import java.util.HashMap;
import java.util.Iterator;

public class PropertyNode implements XPathPropertyNode {
	static final String COPYRIGHT_NOTICE = "(c) Copyright International Business Machines Corporation 2005";
	private String operator = null;
	private String name = null;
	private Object value = null;
	private boolean inRepos = true;

	public void setOperator(String var1) {
		this.operator = var1;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setName(String var1) {
		this.name = var1;
	}

	public String getName() {
		return this.name;
	}

	public void setValue(Object var1) {
		this.value = var1;
	}

	public Object getValue() {
		return this.value;
	}

	public short getNodeType() {
		return 0;
	}

	public Iterator getPropertyNodes(HashMap var1) {
		HashMap var2 = var1;
		if (var1 == null) {
			var2 = new HashMap();
		}

		var2.put(new Integer(this.hashCode()), this);
		return var2.values().iterator();
	}

	public void setPropertyLocation(boolean var1) {
		this.inRepos = var1;
	}

	public boolean isPropertyInRepository() {
		return this.inRepos;
	}

	public String toString() {
		StringBuffer var1 = new StringBuffer();
		var1 = var1.append(this.name + " " + this.operator + " " + this.value.toString());
		return var1.toString();
	}
}