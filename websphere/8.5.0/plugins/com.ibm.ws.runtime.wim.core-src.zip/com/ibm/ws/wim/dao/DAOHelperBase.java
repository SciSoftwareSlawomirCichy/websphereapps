package com.ibm.ws.wim.dao;

import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DatabaseTypeNotSupportedException;
import com.ibm.websphere.wim.exception.PropertyNotDefinedException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.util.SDOHelper;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.dao.db2.DB2DAO;
import com.ibm.ws.wim.dao.db2.DB2QuerySet;
import com.ibm.ws.wim.dao.db2iseries.DB2iSeriesDAO;
import com.ibm.ws.wim.dao.db2iseries.DB2iSeriesQuerySet;
import com.ibm.ws.wim.dao.db2zos.DB2ZOSDAO;
import com.ibm.ws.wim.dao.db2zos.DB2ZOSQuerySet;
import com.ibm.ws.wim.dao.derby.DerbyDAO;
import com.ibm.ws.wim.dao.derby.DerbyQuerySet;
import com.ibm.ws.wim.dao.informix.InformixDAO;
import com.ibm.ws.wim.dao.informix.InformixQuerySet;
import com.ibm.ws.wim.dao.oracle.OracleDAO;
import com.ibm.ws.wim.dao.oracle.OracleQuerySet;
import com.ibm.ws.wim.dao.schema.DBDataType;
import com.ibm.ws.wim.dao.schema.DBRepositoryProperty;
import com.ibm.ws.wim.dao.sqlserver.SQLServerDAO;
import com.ibm.ws.wim.dao.sqlserver.SQLServerQuerySet;
import commonj.sdo.DataObject;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DAOHelperBase {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	public static final short DB_SCHEMA = 0;
	public static final short LA_SCHEMA = 1;
	public static final short FED_SCHEMA = 2;
	public static final String DB2_DAO_CLASSNAME = "com.ibm.ws.wim.dao.db2.DB2DAO";
	public static final String ORACLE_DAO_CLASSNAME = "com.ibm.ws.wim.dao.oracle.OracleDAO";
	public static final String SQLSERVER_DAO_CLASSNAME = "com.ibm.ws.wim.dao.sqlserver.SqlServerDAO";
	public static final String INFORMIX_DAO_CLASSNAME = "com.ibm.ws.wim.dao.informix.InformixDAO";
	public static final String CLOUDSCAPE_DAO_CLASSNAME = "com.ibm.ws.wim.dao.cloudscape.CloudscapeDAO";
	public static final String DB2_ISERIES_DAO_CLASSNAME = "com.ibm.ws.wim.dao.db2iseries.DB2iSeriesDAO";
	public static final String DB2_ZOS_DAO_CLASSNAME = "com.ibm.ws.wim.dao.db2zos.DB2zOSDAO";
	public static final short DATATYPE_ID_STRING = 0;
	public static final short DATATYPE_ID_LONG = 1;
	public static final short DATATYPE_ID_DOUBLE = 2;
	public static final short DATATYPE_ID_INTEGER = 3;
	public static final short DATATYPE_ID_TIMESTAMP = 4;
	public static final short DATATYPE_ID_IDENTIFIER = 5;
	public static final short DATATYPE_ID_OBJECT = 6;
	public static final String[] types;
	public static final String DBTYPE_DB2 = "db2";
	public static final String DBTYPE_ORACLE = "oracle";
	public static final String DBTYPE_SQLSERVER = "sqlserver";
	public static final String DBTYPE_INFORMIX = "informix";
	public static final String DBTYPE_DERBY = "derby";
	public static final String DBTYPE_DB2ISERIES = "db2iseries";
	public static final String DBTYPE_DB2ZOS = "db2zos";
	public static final String DB_ENTITY = "DBENTITY";
	public static final String DB_PROPERTY_TYPE = "DBPROPTYPE";
	public static final String DB_PROPERTY = "DBPROP";
	public static final String DB_PROPERTY_ENTITY = "DBPROPENT";
	public static final String DB_PROPERTY_LONG_VALUE = "DBLONGPROP";
	public static final String DB_PROPERTY_BLOB_VALUE = "DBBLOBPROP";
	public static final String DB_PROPERTY_DOUBLE_VALUE = "DBDBLPROP";
	public static final String DB_PROPERTY_INTEGER_VALUE = "DBINTPROP";
	public static final String DB_PROPERTY_REFERENCE_VALUE = "DBREFPROP";
	public static final String DB_PROPERTY_STRING_VALUE = "DBSTRPROP";
	public static final String DB_PROPERTY_TIMESTAMP_VALUE = "DBTSPROP";
	public static final String DB_COMPOSITE_RELATION = "DBCOMPREL";
	public static final String DB_COMPOSITE_PROPERTY_VALUE = "DBCOMPPROP";
	public static final String DB_ENTITY_RELATION = "DBENTREL";
	public static final String DB_KEYS = "DBKEYS";
	public static final String DB_GROUP_RELATION = "DBGRPREL";
	public static final String DB_ACCOUNT = "DBACCT";
	public static final String LA_ENTITY = "LAENTITY";
	public static final String LA_ENTITY_EXT_ID = "LAEXTID";
	public static final String LA_KEYS = "LAKEYS";
	public static final String LA_PROPERTY = "LAPROP";
	public static final String LA_PROPERTY_TYPE = "LAPROPTYPE";
	public static final String LA_PROPERTY_ENTITY = "LAPROPENT";
	public static final String LA_PROPERTY_LONG_VALUE = "LALONGPROP";
	public static final String LA_PROPERTY_BLOB_VALUE = "LABLOBPROP";
	public static final String LA_PROPERTY_DOUBLE_VALUE = "LADBLPROP";
	public static final String LA_PROPERTY_INTEGER_VALUE = "LAINTPROP";
	public static final String LA_PROPERTY_REFERENCE_VALUE = "LAREFPROP";
	public static final String LA_PROPERTY_STRING_VALUE = "LASTRPROP";
	public static final String LA_PROPERTY_TIMESTAMP_VALUE = "LATSPROP";
	public static final String LA_COMPOSITE_RELATION = "LACOMPREL";
	public static final String LA_COMPOSITE_PROPERTY_VALUE = "LACOMPPROP";
	public static final String COL_PROP_ID = "PROP_ID";
	public static final String COL_TYPE_ID = "TYPE_ID";
	public static final String COL_ENTITY_ID = "ENTITY_ID";
	public static final String COL_ENTITY_TYPE = "ENTITY_TYPE";
	public static final String COL_EXT_ID = "EXT_ID";
	public static final String COL_FULL_EXT_ID = "FULL_EXT_ID";
	public static final String COL_REPOS_ID = "REPOS_ID";
	public static final String TABLE_NAME = "TABLE_NAME";
	public static final int GET_PROP_QUERY_LENGTH = 256;
	public static final int GET_ENTITY_QUERY_LENGTH = 256;
	public static final int PROP_ID_LENGTH = 8;
	public static final int DEFAULT_VALUE_INDEX = -100;
	public static final String COMPOSITE_COMPONENT_SEPERATOR = "/";
	public static final int LONG_QUERY_LENGTH = 1024;
	public static final String OPERATOR_NOT_EQUAL = "!=";
	public static final String OPERATOR_EQUAL = "=";
	public static final String FED_ENTITY = "FEDENTITY";
	public static final int UNIQUE_NAME_KEY_LENGTH = 236;
	public static final int TRUNC_EXT_ID_LENGTH = 200;
	public static final String COMMA = ",";
	public static final String WASVAR_JDBC_CLASSPATH = "VMM_JDBC_CLASSPATH";
	public static ConcurrentHashMap dbClassMap;

	public static DataAccessObject getNewDAOClass(String var0, String var1, String var2, String var3, String var4,
			String var5, String var6) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getNewDAOClass(String dbType, String datasourceName, String dbURL, String dbSchema, String dbUserId, String dbPwd, String dbDriver)");
		}

		if (var0.equalsIgnoreCase("db2")) {
			return new DB2DAO(var1, var2, var3, var4, var5, var6);
		} else if (var0.equalsIgnoreCase("oracle")) {
			return new OracleDAO(var1, var2, var3, var4, var5, var6);
		} else if (var0.equalsIgnoreCase("sqlserver")) {
			return new SQLServerDAO(var1, var2, var3, var4, var5, var6);
		} else if (var0.equalsIgnoreCase("informix")) {
			return new InformixDAO(var1, var2, var3, var4, var5, var6);
		} else if (var0.equalsIgnoreCase("derby")) {
			return new DerbyDAO(var1, var2, var3, var4, var5, var6);
		} else if (var0.equalsIgnoreCase("db2iseries")) {
			return new DB2iSeriesDAO(var1, var2, var3, var4, var5, var6);
		} else if (var0.equalsIgnoreCase("db2zos")) {
			return new DB2ZOSDAO(var1, var2, var3, var4, var5, var6);
		} else {
			throw new DatabaseTypeNotSupportedException("DB_TYPE_NOT_SUPPORTED",
					WIMMessageHelper.generateMsgParms(var0), CLASSNAME,
					"getNewDAOClass(String dbType, String datasourceName, String dbURL, String dbSchema, String dbUserId, String dbPwd, String dbDriver)");
		}
	}

	public static DataAccessObject getNewDAOClass(String var0, String var1, String var2, String var3, String var4,
			String var5) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"getNewDAOClass(String dbType, String datasourceName, String dbURL, String dbUserId, String dbPwd, String dbDriver)");
		}

		return getNewDAOClass(var0, var1, var2, (String) null, var3, var4, var5);
	}

	public static QuerySet getQuerySet(String var0) {
		return getQuerySet(var0, (String) null);
	}

	public static QuerySet getQuerySet(String var0, String var1) {
		Object var2 = new DB2QuerySet(var1);
		if (var0.equalsIgnoreCase("oracle")) {
			var2 = new OracleQuerySet(var1);
		} else if (var0.equalsIgnoreCase("sqlserver")) {
			var2 = new SQLServerQuerySet(var1);
		} else if (var0.equalsIgnoreCase("informix")) {
			var2 = new InformixQuerySet(var1);
		} else if (var0.equalsIgnoreCase("derby")) {
			var2 = new DerbyQuerySet(var1);
		} else if (var0.equalsIgnoreCase("db2iseries")) {
			var2 = new DB2iSeriesQuerySet(var1);
		} else if (var0.equalsIgnoreCase("db2zos")) {
			var2 = new DB2ZOSQuerySet(var1);
		}

		return (QuerySet) var2;
	}

	public static String getValueTableName(short var0, short var1) {
		String var2 = null;
		if (var0 == 0) {
			switch (var1) {
				case 0 :
					var2 = "DBSTRPROP";
					break;
				case 1 :
					var2 = "DBLONGPROP";
					break;
				case 2 :
					var2 = "DBDBLPROP";
					break;
				case 3 :
					var2 = "DBINTPROP";
					break;
				case 4 :
					var2 = "DBTSPROP";
					break;
				case 5 :
					var2 = "DBREFPROP";
					break;
				case 6 :
					var2 = "DBBLOBPROP";
			}
		} else if (var0 == 1) {
			switch (var1) {
				case 0 :
					var2 = "LASTRPROP";
					break;
				case 1 :
					var2 = "LALONGPROP";
					break;
				case 2 :
					var2 = "LADBLPROP";
					break;
				case 3 :
					var2 = "LAINTPROP";
					break;
				case 4 :
					var2 = "LATSPROP";
					break;
				case 5 :
					var2 = "LAREFPROP";
					break;
				case 6 :
					var2 = "LABLOBPROP";
			}
		}

		return var2;
	}

	public static String getDataType(short var0) {
		switch (var0) {
			case 0 :
				return "STRING";
			case 1 :
				return "LONG";
			case 2 :
				return "DOUBLE";
			case 3 :
				return "INTEGER";
			case 4 :
				return "TIMESTAMP";
			case 5 :
				return "IDENTIFIER";
			case 6 :
				return "OBJECT";
			default :
				return null;
		}
	}

	public static DBDataType getDBDataTypeFromCommonDataType(String var0) {
		DBDataType var1 = new DBDataType();
		if (!var0.equalsIgnoreCase("String") && !var0.equalsIgnoreCase("Token")) {
			if (var0.equalsIgnoreCase("Double")) {
				var1.setDatatype("DOUBLE");
			} else if (!var0.equalsIgnoreCase("DateTime") && !var0.equalsIgnoreCase("Date")) {
				if (var0.equalsIgnoreCase("Base64Binary")) {
					var1.setDatatype("BYTEARRAY");
				} else if (!var0.equalsIgnoreCase("Int") && !var0.equalsIgnoreCase("Short")) {
					if (var0.equalsIgnoreCase("Long")) {
						var1.setDatatype("LONG");
					} else if (var0.equalsIgnoreCase("IdentifierType")) {
						var1.setDatatype("IDENTIFIER");
					} else if (var0.equalsIgnoreCase("Boolean")) {
						var1.setDatatype("OBJECT");
						var1.setClassname("java.lang.Boolean");
					} else if (var0.equalsIgnoreCase("AnySimpleType")) {
						var1.setDatatype("OBJECT");
						var1.setClassname("java.lang.Object");
					} else if (var0.equalsIgnoreCase("AnyURI")) {
						var1.setDatatype("STRING");
						var1.setClassname("java.lang.String");
					} else {
						var1.setDatatype("OBJECT");
					}
				} else {
					var1.setDatatype("INTEGER");
				}
			} else {
				var1.setDatatype("TIMESTAMP");
			}
		} else {
			var1.setDatatype("STRING");
		}

		return var1;
	}

	public static short getDataTypeId(String var0) {
		if (var0.equalsIgnoreCase("STRING")) {
			return 0;
		} else if (var0.equalsIgnoreCase("INTEGER")) {
			return 3;
		} else if (var0.equalsIgnoreCase("LONG")) {
			return 1;
		} else if (var0.equalsIgnoreCase("DOUBLE")) {
			return 2;
		} else if (var0.equalsIgnoreCase("TIMESTAMP")) {
			return 4;
		} else if (var0.equalsIgnoreCase("IDENTIFIER")) {
			return 5;
		} else {
			return (short) (!var0.equalsIgnoreCase("OBJECT") && !var0.equalsIgnoreCase("BYTEARRAY") ? -1 : 6);
		}
	}

	public static String resumeComponentName(String var0, String var1) {
		return var0.substring(var1.length() + "/".length(), var0.length());
	}

	public static Object getRightTypeValue(ResultSet var0, short var1, int var2)
			throws SQLException, IOException, ClassNotFoundException {
		switch (var1) {
			case 0 :
				return var0.getString(var2);
			case 1 :
				return new Long(var0.getLong(var2));
			case 2 :
				return new Double(var0.getDouble(var2));
			case 3 :
				return new Integer(var0.getInt(var2));
			case 4 :
				try {
					Timestamp var9 = var0.getTimestamp(var2);
					Date var4 = new Date(var9.getTime());
					String var5 = SDOHelper.getDateString(var4);
					return var5;
				} catch (NullPointerException var7) {
					return null;
				}
			case 5 :
				String[] var3 = new String[]{var0.getString(var2), var0.getString(var2 + 1).trim(), null};
				return var3;
			default :
				try {
					Blob var10 = var0.getBlob(var2);
					InputStream var11 = var10.getBinaryStream();
					ObjectInputStream var6 = new ObjectInputStream(var11);
					return var6.readObject();
				} catch (NullPointerException var8) {
					return null;
				}
		}
	}

	public static String[] getRightReferenceTypeValue(ResultSet var0, int var1, int var2, int var3)
			throws SQLException {
		String[] var4 = new String[]{var0.getString(var1), var0.getString(var2), var0.getString(var3).trim()};
		return var4;
	}

	public static String getTruncatedUniqueName(String var0) {
		String var1 = var0;
		if (var0.length() > 236) {
			var1 = var0.substring(0, 236);
		}

		return var1.toLowerCase();
	}

	public static String getTruncatedExternalId(String var0) {
		String var1 = var0;
		if (var0.length() > 200) {
			var1 = var0.substring(0, 200);
		}

		return var1.toLowerCase();
	}

	public static String formatValueForDB(String var0) {
		return replaceAll(var0, "'", "''");
	}

	public static final String replaceAll(String var0, String var1, String var2) {
		if (var0 == null) {
			return null;
		} else {
			if (var1 == null) {
				var1 = "";
			}

			if (var2 == null) {
				var2 = "";
			}

			for (int var3 = var0.indexOf(var1); var3 != -1; var3 = var0.indexOf(var1, var3 + var2.length())) {
				var0 = var0.substring(0, var3) + var2 + var0.substring(var3 + var1.length());
			}

			return var0;
		}
	}

	public static boolean isPropInCommonSchema(String var0, Set var1) throws WIMException {
		Iterator var2 = var1.iterator();

		String var3;
		String var4;
		do {
			if (!var2.hasNext()) {
				return false;
			}

			var3 = (String) var2.next();
			if (SchemaManager.singleton().getProperty(var3, var0) != null) {
				return true;
			}

			var4 = getCompName(var0);
		} while (var4 == null || SchemaManager.singleton().getProperty(var3, var4) == null);

		return true;
	}

	public static String buildEntityIdSQL(Map var0) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "buildEntityIdSQL(Map entities)", WIMMessageHelper.generateMsgParms(var0));
		}

		StringBuffer var2 = new StringBuffer(256);
		if (var0 != null && var0.size() > 0) {
			Iterator var3 = var0.keySet().iterator();
			if (var3.hasNext()) {
				var2.append(var3.next().toString());
			}

			while (var3.hasNext()) {
				var2.append(",");
				var2.append(var3.next().toString());
			}
		}

		return var2.toString();
	}

	public static String getCompName(String var0) {
		String var1 = null;
		byte var2 = 47;
		int var3 = var0.indexOf(var2);
		if (var3 != -1) {
			var1 = var0.substring(0, var3);
		}

		return var1;
	}

	public static void setPropertySchema(DBRepositoryProperty var0, String var1, DataObject var2, String var3)
			throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"setPropertySchema(DBRepositoryProperty prop, String name, DataObject pSchema, String entityTypeName)",
					var1);
		}

		Set var5 = var0.getApplicableEntityTypes();
		if (var3 != null && !var5.contains(var3)) {
			throw new PropertyNotDefinedException("PROPERTY_NOT_DEFINED_FOR_ENTITY",
					WIMMessageHelper.generateMsgParms(var0.getName(), var3), CLASSNAME,
					"setPropertySchema(DBRepositoryProperty prop, String name, DataObject pSchema, String entityTypeName)");
		} else {
			String var6 = SchemaManager.singleton().getTypeName(var1);
			String var7 = SchemaManager.singleton().getTypeNsURI(var1);
			var2.setString("propertyName", var6);
			var2.set("nsURI", var7);
			var2.set("nsPrefix", SchemaManager.singleton().getNsPrefix(var7));
			DataObject var8 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "MetaDataType");
			var8.set("name", "repositoryDataType");
			var8.getList("values").add(var0.getDataType());
			var2.getList("metaData").add(var8);
			if (var0.getDataType().equalsIgnoreCase("STRING")) {
				var8 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "MetaDataType");
				var8.set("name", "valueLength");
				var8.getList("values").add(String.valueOf(var0.getValueLength()));
				var2.getList("metaData").add(var8);
				var8 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "MetaDataType");
				var8.set("name", "caseExactMatch");
				var8.getList("values").add(String.valueOf(var0.isCaseSensitive()));
				var2.getList("metaData").add(var8);
			}

			if (var0.getDataType().equalsIgnoreCase("OBJECT") && !var0.isComposite()) {
				var8 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "MetaDataType");
				var8.set("name", "classname");
				var8.getList("values").add(var0.getClassName());
				var2.getList("metaData").add(var8);
			}

			var8 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "MetaDataType");
			var8.set("name", "multiValued");
			var8.getList("values").add(String.valueOf(var0.isMultipleValued()));
			var2.getList("metaData").add(var8);
			var8 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "MetaDataType");
			var8.set("name", "readOnly");
			var8.getList("values").add(String.valueOf(var0.isReadOnly()));
			var2.getList("metaData").add(var8);
			var8 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "MetaDataType");
			var8.set("name", "applicationId");
			var8.getList("values").add(var0.getApplicationId());
			var2.getList("metaData").add(var8);
			if (var0.getDescription() != null && var0.getDescription().trim().length() != 0) {
				var8 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "MetaDataType");
				var8.set("name", "description");
				var8.getList("values").add(var0.getDescription());
				var2.getList("metaData").add(var8);
			}

			var8 = SDOHelper.createDataObject("http://www.ibm.com/websphere/wim", "MetaDataType");
			var8.set("name", "isComposite");
			var8.getList("values").add(String.valueOf(var0.isComposite()));
			var2.getList("metaData").add(var8);
			Iterator var9 = var5.iterator();

			while (var9.hasNext()) {
				var2.getList("applicableEntityTypeNames").add(SchemaManager.singleton()
						.getQualifiedTypeName("http://www.ibm.com/websphere/wim", (String) var9.next()));
			}

			Set var10 = var0.getRequiredEntityTypes();
			Iterator var11 = var10.iterator();

			while (var11.hasNext()) {
				var2.getList("requiredEntityTypeNames").add(SchemaManager.singleton()
						.getQualifiedTypeName("http://www.ibm.com/websphere/wim", (String) var11.next()));
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME,
						"setPropertySchema(DBRepositoryProperty prop, String name, DataObject pSchema, String entityTypeName)");
			}

		}
	}

	public static String getDefaultDBDriver(String var0) {
		String var1 = getDB2Type4JDBCDriver();
		if (var0.equalsIgnoreCase("oracle")) {
			var1 = "oracle.jdbc.driver.OracleDriver";
		} else if (var0.equalsIgnoreCase("sqlserver")) {
			var1 = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
		} else if (var0.equalsIgnoreCase("derby")) {
			var1 = "org.apache.derby.jdbc.EmbeddedDriver";
		} else if (var0.equalsIgnoreCase("informix")) {
			var1 = "com.informix.jdbc.IfxDriver";
		} else if (var0.equalsIgnoreCase("db2iseries")) {
			var1 = "com.ibm.as400.access.AS400JDBCDriver";
		}

		return var1;
	}

	public static String getDB2Type4JDBCDriver() {
		return "com.ibm.db2.jcc.DB2Driver";
	}

	public static Class loadJDBCClass(String var0) throws WIMSystemException {
		Class var2 = null;
		ClassLoader var3 = null;
		trcLogger.entering(CLASSNAME, "loadJDBCClass(String dbDriver)", "dbDriver=" + var0);
		if ((var2 = (Class) dbClassMap.get(var0)) == null) {
			trcLogger.log(Level.FINE, "Loading JDBC driver class: " + var0);

			try {
				var3 = DAOHelper.class.getClassLoader();
				trcLogger.log(Level.FINER, "Loading JDBC driver... using " + var3);
				var2 = var3.loadClass(var0);
				trcLogger.log(Level.FINER, "Loaded JDBC driver successfully");
			} catch (ClassNotFoundException var5) {
				throw new WIMSystemException(var5);
			}

			dbClassMap.put(var0, var2);
		} else {
			trcLogger.log(Level.FINE, "Retrieving JDBC driver class from cache: " + var0);
		}

		trcLogger.exiting(CLASSNAME, "loadJDBCClass(String dbDriver)");
		return var2;
	}

	public static Connection createConnection(String var0, String var1, Properties var2) throws WIMSystemException {
		trcLogger.entering(CLASSNAME, "createConnection");
		Connection var4 = null;
		if (var2 == null) {
			var2 = new Properties();
		}

		try {
			Class var5 = DAOHelper.loadJDBCClass(var0);
			Object var9 = var5.newInstance();
			Method var7 = var5.getMethod("connect", String.class, Properties.class);
			var4 = (Connection) var7.invoke(var9, var1, var2);
		} catch (Exception var8) {
			if (var8 instanceof InvocationTargetException && var8.getCause() instanceof SQLException) {
				SQLException var6 = (SQLException) var8.getCause();
				throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.getMessage()),
						CLASSNAME, "createConnection", var6);
			}

			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var8.getMessage()),
					CLASSNAME, "createConnection", var8);
		}

		trcLogger.exiting(CLASSNAME, "createConnection");
		return var4;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = DAOHelperBase.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		types = new String[]{"STRING", "LONG", "DOUBLE", "INTEGER", "TIMESTAMP", "IDENTIFIER", "OBJECT"};
		dbClassMap = new ConcurrentHashMap();
	}
}