package com.google.inject.spi;

import com.google.inject.Module;
import com.google.inject.Stage;
import com.google.inject.spi.Elements.1;
import com.google.inject.spi.Elements.2;
import com.google.inject.spi.Elements.RecordingBinder;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class Elements {
	private static final BindingTargetVisitor<Object, Object> GET_INSTANCE_VISITOR = new 1();

	public static List<Element> getElements(Module... modules) {
		return getElements(Stage.DEVELOPMENT, (Iterable) Arrays.asList(modules));
	}

	public static List<Element> getElements(Stage stage, Module... modules) {
		return getElements(stage, (Iterable) Arrays.asList(modules));
	}

	public static List<Element> getElements(Iterable<? extends Module> modules) {
		return getElements(Stage.DEVELOPMENT, modules);
	}

	public static List<Element> getElements(Stage stage, Iterable<? extends Module> modules) {
      RecordingBinder binder = new RecordingBinder(stage, (1)null);
      Iterator i$ = modules.iterator();

      while(i$.hasNext()) {
         Module module = (Module)i$.next();
         binder.install(module);
      }

      return Collections.unmodifiableList(RecordingBinder.access$100(binder));
   }

	public static Module getModule(Iterable<? extends Element> elements) {
      return new 2(elements);
   }

	static <T> BindingTargetVisitor<T, T> getInstanceVisitor() {
		return GET_INSTANCE_VISITOR;
	}
}