package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.collect.AbstractBiMap.1;
import com.google.common.collect.AbstractBiMap.EntrySet;
import com.google.common.collect.AbstractBiMap.Inverse;
import com.google.common.collect.AbstractBiMap.KeySet;
import com.google.common.collect.AbstractBiMap.ValueSet;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.j2objc.annotations.RetainedWith;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

@GwtCompatible(emulated = true)
abstract class AbstractBiMap<K, V> extends ForwardingMap<K, V> implements BiMap<K, V>, Serializable {
	@MonotonicNonNullDecl
	private transient Map<K, V> delegate;
	@MonotonicNonNullDecl
	@RetainedWith
	transient AbstractBiMap<V, K> inverse;
	@MonotonicNonNullDecl
	private transient Set<K> keySet;
	@MonotonicNonNullDecl
	private transient Set<V> valueSet;
	@MonotonicNonNullDecl
	private transient Set<Entry<K, V>> entrySet;
	@GwtIncompatible
	private static final long serialVersionUID = 0L;

	AbstractBiMap(Map<K, V> forward, Map<V, K> backward) {
		this.setDelegates(forward, backward);
	}

	private AbstractBiMap(Map<K, V> backward, AbstractBiMap<V, K> forward) {
		this.delegate = backward;
		this.inverse = forward;
	}

	protected Map<K, V> delegate() {
		return this.delegate;
	}

	@CanIgnoreReturnValue
	K checkKey(@NullableDecl K key) {
		return key;
	}

	@CanIgnoreReturnValue
	V checkValue(@NullableDecl V value) {
		return value;
	}

	void setDelegates(Map<K, V> forward, Map<V, K> backward) {
		Preconditions.checkState(this.delegate == null);
		Preconditions.checkState(this.inverse == null);
		Preconditions.checkArgument(forward.isEmpty());
		Preconditions.checkArgument(backward.isEmpty());
		Preconditions.checkArgument(forward != backward);
		this.delegate = forward;
		this.inverse = this.makeInverse(backward);
	}

	AbstractBiMap<V, K> makeInverse(Map<V, K> backward) {
		return new Inverse(backward, this);
	}

	void setInverse(AbstractBiMap<V, K> inverse) {
		this.inverse = inverse;
	}

	public boolean containsValue(@NullableDecl Object value) {
		return this.inverse.containsKey(value);
	}

	@CanIgnoreReturnValue
	public V put(@NullableDecl K key, @NullableDecl V value) {
		return this.putInBothMaps(key, value, false);
	}

	@CanIgnoreReturnValue
	public V forcePut(@NullableDecl K key, @NullableDecl V value) {
		return this.putInBothMaps(key, value, true);
	}

	private V putInBothMaps(@NullableDecl K key, @NullableDecl V value, boolean force) {
		this.checkKey(key);
		this.checkValue(value);
		boolean containedKey = this.containsKey(key);
		if (containedKey && Objects.equal(value, this.get(key))) {
			return value;
		} else {
			if (force) {
				this.inverse().remove(value);
			} else {
				Preconditions.checkArgument(!this.containsValue(value), "value already present: %s", value);
			}

			V oldValue = this.delegate.put(key, value);
			this.updateInverseMap(key, containedKey, oldValue, value);
			return oldValue;
		}
	}

	private void updateInverseMap(K key, boolean containedKey, V oldValue, V newValue) {
		if (containedKey) {
			this.removeFromInverseMap(oldValue);
		}

		this.inverse.delegate.put(newValue, key);
	}

	@CanIgnoreReturnValue
	public V remove(@NullableDecl Object key) {
		return this.containsKey(key) ? this.removeFromBothMaps(key) : null;
	}

	@CanIgnoreReturnValue
	private V removeFromBothMaps(Object key) {
		V oldValue = this.delegate.remove(key);
		this.removeFromInverseMap(oldValue);
		return oldValue;
	}

	private void removeFromInverseMap(V oldValue) {
		this.inverse.delegate.remove(oldValue);
	}

	public void putAll(Map<? extends K, ? extends V> map) {
		Iterator var2 = map.entrySet().iterator();

		while (var2.hasNext()) {
			Entry<? extends K, ? extends V> entry = (Entry) var2.next();
			this.put(entry.getKey(), entry.getValue());
		}

	}

	public void clear() {
		this.delegate.clear();
		this.inverse.delegate.clear();
	}

	public BiMap<V, K> inverse() {
		return this.inverse;
	}

	public Set<K> keySet() {
      Set<K> result = this.keySet;
      return result == null ? (this.keySet = new KeySet(this, (1)null)) : result;
   }

	public Set<V> values() {
      Set<V> result = this.valueSet;
      return result == null ? (this.valueSet = new ValueSet(this, (1)null)) : result;
   }

	public Set<Entry<K, V>> entrySet() {
      Set<Entry<K, V>> result = this.entrySet;
      return result == null ? (this.entrySet = new EntrySet(this, (1)null)) : result;
   }

	Iterator<Entry<K, V>> entrySetIterator() {
      Iterator<Entry<K, V>> iterator = this.delegate.entrySet().iterator();
      return new 1(this, iterator);
   }
}