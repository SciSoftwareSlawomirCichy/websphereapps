package com.ibm.ws.wim.config;

import com.ibm.websphere.wim.ConfigUIConstants;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.WIMConfigurationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.ws.wim.ConfigManager;
import com.ibm.ws.wim.configmodel.ConfigurationProviderType;
import com.ibm.ws.wim.configmodel.FileRepositoryType;
import com.ibm.ws.wim.configmodel.RepositoryType;
import com.ibm.ws.wim.util.PasswordEncryptionUtil;
import commonj.sdo.DataObject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EcoreUtil;

public class FileRepositoryConfigHelper implements ConfigUIConstants {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;

	public String createIdMgrFileRepository(String var1, Map var2) throws WIMException {
		boolean var4 = trcLogger.isLoggable(Level.FINER);
		if (var4) {
			trcLogger.entering(CLASSNAME, "createIdMgrFileRepository", "params=" + var2);
		}

		String var5 = (String) var2.get("id");
		String var6 = (String) var2.get("messageDigestAlgorithm");
		Integer var7 = (Integer) var2.get("saltLength");
		Integer var8 = (Integer) var2.get("keyLength");
		Integer var9 = (Integer) var2.get("hashIterations");
		ValidationHelper.validateIntegerInput("saltLength", CLASSNAME, "createIdMgrFileRepository", var7);
		ValidationHelper.validateIntegerInput("keyLength", CLASSNAME, "createIdMgrFileRepository", var8);
		ValidationHelper.validateIntegerInput("hashIterations", CLASSNAME, "createIdMgrFileRepository", var9);
		Integer var10 = (Integer) var2.get("accountLockoutThreshold");
		Integer var11 = null;
		Integer var12 = null;
		if (var10 > 0) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.finest("createIdMgrFileRepository: accountLockoutThreshold is set to " + var10);
			}

			var11 = (Integer) var2.get("accountLockoutDuration");
			if (var11 == null) {
				var11 = ACCOUNT_LOCKOUT_DURATION_DEFAULT;
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.finest(
							"createIdMgrFileRepository: accountLockoutDuration was not set, setting to default value: "
									+ var11);
				}
			}

			ValidationHelper.validateIntegerInputPositive("accountLockoutDuration", CLASSNAME,
					"createIdMgrFileRepository", var11);
			var12 = (Integer) var2.get("ignoreFailedLoginAfter");
			if (var12 == null) {
				var12 = IGNORE_FAILED_LOGIN_AFTER_DEFAULT;
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.finest(
							"createIdMgrFileRepository: ignoreFailedLoginAfter was not set, setting to default value: "
									+ var12);
				}
			}

			ValidationHelper.validateIntegerInputPositive("ignoreFailedLoginAfter", CLASSNAME,
					"createIdMgrFileRepository", var12);
		} else if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.finest(
					"createIdMgrFileRepository: accountLockoutThreshold is not configured, accountLockoutDuration and ignoreFailedAfter not processed.");
		}

		ConfigValidator.validateRepositoryParams(var5, "FileRepositoryType", var2);
		ConfigurationProviderType var13 = ConfigUtils.getConfigProvider(var1);
		if (!var5.equals("InternalFileRepository")) {
			ConfigUtils.checkForValidRepositoryById(var1, var5);
		} else {
			RepositoryType var14 = ConfigUtils.getRepositoryById(var1, var5, false);
			if (var14 != null) {
				throw new WIMConfigurationException("REPOSITORY_ID_ALREADY_EXISTS",
						WIMMessageHelper.generateMsgParms(var5), Level.SEVERE, CLASSNAME, "createIdMgrFileRepository");
			}
		}

		EClass var17 = ConfigManager.singleton().getConfigEClass("FileRepositoryType");
		DataObject var15 = (DataObject) EcoreUtil.create(var17);
		var15.setString("id", var5);
		var13.getRepositories().add(var15);
		FileRepositoryType var16 = (FileRepositoryType) ConfigUtils.getRepositoryById(var13, var5);
		ConfigUtils.setCommonRepositoryProperties(var16, var2, this.getDefaultValue(), false);
		if (var2.get("baseDirectory") != null && ((String) var2.get("baseDirectory")).trim().length() > 0) {
			var16.setBaseDirectory((String) var2.get("baseDirectory"));
		}

		if (var2.get("fileName") != null) {
			var16.setFileName((String) var2.get("fileName"));
		}

		if (var7 != null) {
			var16.setSaltLength(var7);
		}

		if (var8 != null) {
			var16.setKeyLength(var8);
		}

		if (var9 != null) {
			var16.setHashIterations(var9);
		}

		if (var6 != null) {
			var16.setMessageDigestAlgorithm(var6);
		}

		if (var10 != null && var10 > 0) {
			var16.setAccountLockoutThreshold(var10);
		} else {
			var16.unsetAccountLockoutThreshold();
		}

		if (var11 != null) {
			var16.setAccountLockoutDuration(var11);
		}

		if (var12 != null) {
			var16.setIgnoreFailedLoginAfter(var12);
		}

		if (var4) {
			trcLogger.exiting(CLASSNAME, "createIdMgrFileRepository");
		}

		ConfigUtils.saveConfig(var1);
		return "MUST_ADD_BASE_ENTRY_TO_REPOSITORY";
	}

	public String updateIdMgrFileRepository(String var1, Map var2) throws Exception {
		String var4 = (String) var2.get("id");
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "updateIdMgrFileRepository", "params=" + var2);
		}

		FileRepositoryType var6 = (FileRepositoryType) ConfigUtils.validateAndGetRepository(var1, var4,
				"FileRepositoryType");
		String var7 = (String) var2.get("messageDigestAlgorithm");
		ConfigValidator.validateFileParams(var4, var2);
		Integer var8 = (Integer) var2.get("saltLength");
		ValidationHelper.validateIntegerInput("saltLength", CLASSNAME, "updateIdMgrFileRepository", var8);
		Integer var9 = (Integer) var2.get("keyLength");
		ValidationHelper.validateIntegerInput("keyLength", CLASSNAME, "updateIdMgrFileRepository", var9);
		Integer var10 = (Integer) var2.get("hashIterations");
		ValidationHelper.validateIntegerInput("hashIterations", CLASSNAME, "updateIdMgrFileRepository", var10);
		Integer var11 = (Integer) var2.get("accountLockoutThreshold");
		Integer var12 = (Integer) var2.get("accountLockoutDuration");
		ValidationHelper.validateIntegerInput("accountLockoutDuration", CLASSNAME, "updateIdMgrFileRepository", var12);
		Integer var13 = (Integer) var2.get("ignoreFailedLoginAfter");
		ValidationHelper.validateIntegerInputPositive("ignoreFailedLoginAfter", CLASSNAME, "updateIdMgrFileRepository",
				var13);
		if (var11 != null && var11 > 0) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.finest("updateIdMgrFileRepository: accountLockoutThreshold is set to " + var11);
			}

			if (var12 == null) {
				var12 = ACCOUNT_LOCKOUT_DURATION_DEFAULT;
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.finest(
							"updateIdMgrFileRepository: accountLockoutDuration was not set, setting to default value: "
									+ var12);
				}
			} else {
				ValidationHelper.validateIntegerInputPositive("accountLockoutDuration", CLASSNAME,
						"updateIdMgrFileRepository", var12);
			}

			var13 = (Integer) var2.get("ignoreFailedLoginAfter");
			if (var13 == null) {
				var13 = IGNORE_FAILED_LOGIN_AFTER_DEFAULT;
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.finest(
							"updateIdMgrFileRepository: ignoreFailedLoginAfter was not set, setting to default value: "
									+ var13);
				}
			} else {
				ValidationHelper.validateIntegerInputPositive("ignoreFailedLoginAfter", CLASSNAME,
						"updateIdMgrFileRepository", var13);
			}
		}

		String var14 = (String) var2.get("baseDirectory");
		if (var14 != null && var14.trim().length() > 0) {
			var6.setBaseDirectory(var14.trim());
		} else if (var14 != null && var14.trim().length() == 0) {
			var6.setBaseDirectory((String) null);
		}

		if (var2.get("fileName") != null) {
			var6.setFileName((String) var2.get("fileName"));
		}

		if (var8 != null) {
			var6.setSaltLength(var8);
		}

		if (var9 != null) {
			var6.setKeyLength(var9);
		}

		if (var10 != null) {
			var6.setHashIterations(var10);
		}

		if (var7 != null) {
			var6.setMessageDigestAlgorithm(var7);
		}

		if (var11 != null && var11 < 1) {
			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.finest("updateIdMgrFileRepository: account lockout settings are unset");
			}

			var6.unsetAccountLockoutThreshold();
			var6.unsetAccountLockoutDuration();
			var6.unsetIgnoreFailedLoginAfter();
		} else {
			if (var11 != null) {
				var6.setAccountLockoutThreshold(var11);
			}

			if (var12 != null) {
				var6.setAccountLockoutDuration(var12);
			}

			if (var13 != null) {
				var6.setIgnoreFailedLoginAfter(var13);
			}
		}

		if (var5) {
			trcLogger.exiting(CLASSNAME, "updateIdMgrFileRepository");
		}

		return ConfigUtils.saveConfig(var1);
	}

	public List listIdMgrSupportedMessageDigestAlgorithms(String var1) throws WIMException {
		return PasswordEncryptionUtil.getSupportedHashingAlgorithms();
	}

	private Map<String, Object> getDefaultValue() {
		HashMap var1 = new HashMap();
		var1.put("adapterClassName", "com.ibm.ws.wim.adapter.file.was.FileAdapter");
		var1.put("supportPaging", Boolean.valueOf("false"));
		var1.put("supportSorting", Boolean.valueOf("false"));
		var1.put("supportTransactions", Boolean.valueOf("false"));
		var1.put("isExtIdUnique", Boolean.valueOf("true"));
		var1.put("supportExternalName", Boolean.valueOf("false"));
		var1.put("supportExternalName", Boolean.valueOf("false"));
		return var1;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = FileRepositoryConfigHelper.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}