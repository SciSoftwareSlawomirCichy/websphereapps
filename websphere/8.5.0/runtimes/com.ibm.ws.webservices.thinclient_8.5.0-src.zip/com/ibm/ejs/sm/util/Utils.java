package com.ibm.ejs.sm.util;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.sm.util.Utils.1;
import com.ibm.ejs.sm.util.Utils.2;
import com.ibm.ejs.sm.util.Utils.3;
import com.ibm.ejs.sm.util.Utils.4;
import com.ibm.ejs.sm.util.Utils.5;
import com.ibm.ejs.sm.util.Utils.6;
import com.ibm.ejs.sm.util.Utils.7;
import com.ibm.ejs.sm.util.Utils.8;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.security.util.AccessController;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.security.PrivilegedActionException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import javax.ejb.EJBObject;

public class Utils {
	private static final String rootContextPrefix = "ejsadmin/";
	private static final int UUID_LENGTH = 16;
	private static TraceComponent tc = Tr.register(Utils.class);

	public static String getIdString(EJBObject obj) throws RemoteException {
		return Long.toString((Long) ((Long) obj.getPrimaryKey()));
	}

	public static String getIdString(Long id) {
		return Long.toString(id);
	}

	public static Long getId(String stringVal) {
		return new Long(Long.parseLong(stringVal));
	}

	public static final String relativeName(String className) {
		int index = className.lastIndexOf(46);
		return index != -1 ? className.substring(index + 1, className.length()) : className;
	}

	public static final String packageName(String className) {
		int index = className.lastIndexOf(46);
		return index != -1 ? className.substring(0, index) : null;
	}

	public static Properties byteArrayToProperties(byte[] val) throws RemoteException {
		try {
			Properties result = new Properties();
			ByteArrayInputStream bi = new ByteArrayInputStream(val);
			result.load(bi);
			return result;
		} catch (IOException var3) {
			FFDCFilter.processException(var3, "com.ibm.ejs.sm.util.Utils.byteArrayToProperties", "70");
			throw new RemoteException("", var3);
		}
	}

	public static byte[] propertiesToByteArray(Properties val) {
		ByteArrayOutputStream bo = new ByteArrayOutputStream();
		val.save(bo, "");
		return bo.toByteArray();
	}

	public static byte[] serializeObject(Object obj) throws RemoteException {
		if (obj == null) {
			return null;
		} else {
			try {
				ByteArrayOutputStream bo = new ByteArrayOutputStream();
				ObjectOutputStream oo = new ObjectOutputStream(bo);
				oo.writeObject(obj);
				oo.flush();
				return bo.toByteArray();
			} catch (IOException var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.sm.util.Utils.serializeObject", "93");
				throw new RemoteException("", var3);
			}
		}
	}

	public static Object deserializeObject(byte[] val) throws RemoteException {
		if (val == null) {
			return null;
		} else {
			try {
				ByteArrayInputStream bi = new ByteArrayInputStream(val);
				ObjectInputStream oi = new ObjectInputStream(bi);
				return oi.readObject();
			} catch (IOException var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.sm.util.Utils.deserializeObject", "107");
				throw new RemoteException("", var3);
			} catch (ClassNotFoundException var4) {
				FFDCFilter.processException(var4, "com.ibm.ejs.sm.util.Utils.deserializeObject", "110");
				throw new RemoteException("", var4);
			}
		}
	}

	public static boolean intToBoolean(int val) {
		return val > 0;
	}

	public static int booleanToInt(boolean val) {
		return val ? 1 : 0;
	}

	public static int enumLength(Enumeration vEnum) {
		int length;
		Object var2;
		for (length = 0; vEnum.hasMoreElements(); var2 = vEnum.nextElement()) {
			++length;
		}

		return length;
	}

	public static String getLocalHostName() throws RemoteException {
      try {
         return (String)AccessController.doPrivileged(new 1());
      } catch (PrivilegedActionException var1) {
         FFDCFilter.processException(var1, "com.ibm.ejs.sm.util.Utils.getLocalHostName", "146");
         throw (RemoteException)var1.getException();
      }
   }

	public static InetAddress getLocalHostIPAddress() throws RemoteException {
      try {
         return (InetAddress)AccessController.doPrivileged(new 2());
      } catch (PrivilegedActionException var2) {
         FFDCFilter.processException(var2, "com.ibm.ejs.sm.util.Utils.getLocalHostIPAddress", "163");
         UnknownHostException e = (UnknownHostException)var2.getException();
         throw new RemoteException("", e);
      }
   }

	public static String getUuid(long id) {
		String uuid = Long.toHexString(id);
		if (uuid.length() < 16) {
			for (int i = 16 - uuid.length(); i > 0; --i) {
				uuid = uuid + "0";
			}
		}

		return uuid;
	}

	public static void main(String[] args) {
		System.out.println(new String(getUuid(1L)));
	}

	public static String replaceString(String oriStr, String oldStr, String newStr) {
		StringBuffer strBuf = null;
		int oldStrLength = oldStr.length();

		int i;
		for (boolean var5 = false; (i = oriStr.indexOf(oldStr)) > -1; oriStr = strBuf.toString()) {
			strBuf = (new StringBuffer()).append(oriStr.substring(0, i));
			strBuf.append(newStr);
			strBuf.append(oriStr.substring(i + oldStrLength));
		}

		return oriStr;
	}

	public static String getRootContextPrefix() {
		return "ejsadmin/";
	}

	public static String qualifyRepositoryHomeName(String nodeName, String homeName) {
		return "ejsadmin/homes/" + homeName;
	}

	public static String unqualifyRepositoryHomeName(String nodeName, String homeName) {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "unqualifyRepositoryHomeName", new Object[]{nodeName, homeName});
		}

		String unqualifiedHomeName = homeName;
		String prefix = "ejsadmin/homes/";
		if (!homeName.startsWith(prefix)) {
			Tr.event(tc, "home prefix was not qualified: cannot unqualify", homeName);
		} else {
			unqualifiedHomeName = homeName.substring(prefix.length());
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "unqualifyRepositoryHomeName", unqualifiedHomeName);
		}

		return unqualifiedHomeName;
	}

	public static String defaultNodeName(String hostName, boolean qualifyHomeNameEnabled) throws UnknownHostException, RemoteException {
      InetAddress ipAddress = null;
      boolean ipAddressAsName = false;
      boolean localHost = false;
      String name = null;
      if (hostName == null || hostName.equals("") || hostName.equalsIgnoreCase("localhost")) {
         localHost = true;
         ipAddress = getLocalHostIPAddress();
         hostName = (String)AccessController.doPrivileged(new 3(ipAddress));
         if (hostName == null) {
            hostName = (String)AccessController.doPrivileged(new 4(ipAddress));
            ipAddressAsName = true;
            Tr.event(tc, "IP address is used as node name", hostName);
         }
      }

      name = hostName;
      if (!localHost) {
         try {
            ipAddress = (InetAddress)AccessController.doPrivileged(new 5(name));
         } catch (PrivilegedActionException var8) {
            FFDCFilter.processException(var8, "com.ibm.ejs.sm.util.Utils.defaultNodeName", "303");
            UnknownHostException ex = (UnknownHostException)var8.getException();
            Tr.event(tc, "DNS lookup for hostName failed. ", ex);
            throw ex;
         }

         if (hostName.equals(ipAddress.getHostAddress())) {
            name = (String)AccessController.doPrivileged(new 6(ipAddress));
            if (name == null) {
               name = (String)AccessController.doPrivileged(new 7(ipAddress));
               ipAddressAsName = true;
               Tr.event(tc, "IP address is used as node name", name);
            }
         }
      }

      if (qualifyHomeNameEnabled && !ipAddressAsName) {
         StringTokenizer hostNameTokens = new StringTokenizer(name, ".");
         name = hostNameTokens.nextToken();
      }

      String os = (String)AccessController.doPrivileged(new 8());
      return os.indexOf("netware") != -1 ? name.toLowerCase() : name;
   }
}