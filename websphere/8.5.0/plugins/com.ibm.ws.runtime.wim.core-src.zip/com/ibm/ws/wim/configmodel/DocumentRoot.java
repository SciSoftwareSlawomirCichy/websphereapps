package com.ibm.ws.wim.configmodel;

import commonj.sdo.Sequence;
import java.util.Map;

public interface DocumentRoot {
	Sequence getMixed();

	Map getXMLNSPrefixMap();

	Map getXSISchemaLocation();

	ConfigurationProviderType getConfigurationProvider();

	void setConfigurationProvider(ConfigurationProviderType var1);

	ConfigurationProviderType createConfigurationProvider();
}