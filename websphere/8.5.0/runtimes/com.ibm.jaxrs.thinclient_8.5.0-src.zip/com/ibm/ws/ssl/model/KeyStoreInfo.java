package com.ibm.ws.ssl.model;

import java.io.Serializable;
import java.util.List;
import javax.management.ObjectName;

public class KeyStoreInfo implements Serializable {
	private String name;
	private String location;
	private String password;
	private String provider;
	private String type;
	private Boolean fileBased;
	private String hostList;
	private ObjectName scopeName;
	private String scopeNameString;
	private Boolean readOnly;
	private Boolean initializeAtStartup;
	private Boolean stashFile;
	private String customProvider;
	private Integer slot;
	private Boolean accelerator;
	private List customProps;
	private String description;
	private String usage;

	public KeyStoreInfo() {
		this.name = null;
		this.location = null;
		this.password = null;
		this.provider = "IBMJCE";
		this.type = "JKS";
		this.fileBased = Boolean.TRUE;
		this.hostList = null;
		this.scopeName = null;
		this.scopeNameString = null;
		this.readOnly = Boolean.FALSE;
		this.initializeAtStartup = Boolean.FALSE;
		this.stashFile = Boolean.FALSE;
		this.customProvider = null;
		this.slot = null;
		this.accelerator = Boolean.FALSE;
		this.customProps = null;
		this.description = null;
		this.usage = null;
	}

	public KeyStoreInfo(String _name, String _location, String _password, String _provider, String _type,
			Boolean _fileBased, String _hostList, String _scopeNameString, ObjectName _scopeName, Boolean _readOnly,
			Boolean _initializeAtStartup, Boolean _stashFile, String _customProvider, Integer _slot,
			Boolean _accelerator, List _customProps, String _description) {
		this.name = _name;
		this.location = _location;
		this.password = _password;
		this.provider = _provider == null ? "IBMJCE" : _provider;
		this.type = _type == null ? "JKS" : _type;
		this.fileBased = _fileBased;
		this.hostList = _hostList;
		this.scopeName = _scopeName;
		this.scopeNameString = _scopeNameString;
		this.readOnly = _readOnly;
		this.initializeAtStartup = _initializeAtStartup;
		this.stashFile = _stashFile;
		this.customProvider = _customProvider;
		this.slot = _slot;
		this.accelerator = _accelerator;
		this.customProps = _customProps;
		this.description = _description;
	}

	public void setName(String _name) {
		this.name = _name;
	}

	public void setLocation(String _location) {
		this.location = _location;
	}

	public void setPassword(String _password) {
		this.password = _password;
	}

	public void setType(String _type) {
		this.type = _type;
	}

	public void setProvider(String _provider) {
		this.provider = _provider;
	}

	public void setFileBased(Boolean _fileBased) {
		this.fileBased = _fileBased;
	}

	public void setHostList(String _hostList) {
		this.hostList = _hostList;
	}

	public void setScopeName(ObjectName _scopeName) {
		this.scopeName = _scopeName;
	}

	public void setScopeNameString(String _scopeNameString) {
		this.scopeNameString = _scopeNameString;
	}

	public void setReadOnly(Boolean _readOnly) {
		this.readOnly = _readOnly;
	}

	public void setInitializeAtStartup(Boolean _initializeAtStartup) {
		this.initializeAtStartup = _initializeAtStartup;
	}

	public void setStashFile(Boolean _stashFile) {
		this.stashFile = _stashFile;
	}

	public void setCustomProvider(String _customProvider) {
		this.customProvider = _customProvider;
	}

	public void setSlot(Integer _slot) {
		this.slot = _slot;
	}

	public void setAccelerator(Boolean _accelerator) {
		this.accelerator = _accelerator;
	}

	public void setCustomProps(List _customProps) {
		this.customProps = _customProps;
	}

	public void setDescription(String _description) {
		this.description = _description;
	}

	public void setUsage(String _usage) {
		this.usage = _usage;
	}

	public String getName() {
		return this.name;
	}

	public String getLocation() {
		return this.location;
	}

	public String getPassword() {
		return this.password;
	}

	public String getProvider() {
		return this.provider;
	}

	public String getType() {
		return this.type;
	}

	public Boolean getFileBased() {
		return this.fileBased;
	}

	public String getHostList() {
		return this.hostList;
	}

	public ObjectName getScopeName() {
		return this.scopeName;
	}

	public String getScopeNameString() {
		return this.scopeNameString;
	}

	public Boolean getReadOnly() {
		return this.readOnly;
	}

	public Boolean getInitializeAtStartup() {
		return this.initializeAtStartup;
	}

	public Boolean getStashFile() {
		return this.stashFile;
	}

	public String getCustomProvider() {
		return this.customProvider;
	}

	public List getCustomProps() {
		return this.customProps;
	}

	public Boolean getAccelerator() {
		return this.accelerator;
	}

	public Integer getSlot() {
		return this.slot;
	}

	public String getDescription() {
		return this.description;
	}

	public String getUsage() {
		return this.usage;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		StringBuffer passwordMask = new StringBuffer();
		sb.append("\tKeyStoreInfo:");
		sb.append("\n\t").append("name = ").append(this.name);
		sb.append("\n\t").append("location = ").append(this.location);
		if (this.password != null) {
			for (int i = 0; i < this.password.length(); ++i) {
				passwordMask.append("*");
			}
		} else {
			passwordMask.append("<null>");
		}

		sb.append("\n\t").append("password = ").append(passwordMask);
		sb.append("\n\t").append("provider = ").append(this.provider);
		sb.append("\n\t").append("type = ").append(this.type);
		String value = null;
		if (this.fileBased == null) {
			value = "<null>";
		} else if (this.fileBased) {
			value = "yes";
		} else {
			value = "no";
		}

		sb.append("\n\t").append("fileBased = ").append(value);
		sb.append("\n\t").append("hostList = ").append(this.hostList);
		sb.append("\n\t").append("scopeName = ").append(this.scopeNameString);
		if (this.readOnly == null) {
			value = "<null>";
		} else if (this.readOnly) {
			value = "yes";
		} else {
			value = "no";
		}

		sb.append("\n\t").append("readOnly = ").append(value);
		if (this.initializeAtStartup == null) {
			value = "<null>";
		} else if (this.initializeAtStartup) {
			value = "yes";
		} else {
			value = "no";
		}

		sb.append("\n\t").append("initializeAtStartup = ").append(value);
		if (this.stashFile == null) {
			value = "<null>";
		} else if (this.stashFile) {
			value = "yes";
		} else {
			value = "no";
		}

		sb.append("\n\t").append("stashFile = ").append(value);
		sb.append("\n\t").append("customProvider = ").append(this.customProvider);
		if (this.slot != null) {
			value = this.slot.toString();
		} else {
			value = "<null>";
		}

		sb.append("\n\t").append("slot = ").append(value);
		if (this.customProps != null) {
			for (int j = 0; j < this.customProps.size(); ++j) {
				sb.append("\n\t").append("customProps=").append(this.customProps.get(j));
			}
		} else {
			sb.append("\n\t").append("customProps=<null>");
		}

		sb.append("\n\t").append("description = ").append(this.description);
		sb.append("\n\t").append("usage = ").append(this.usage);
		return sb.toString();
	}
}