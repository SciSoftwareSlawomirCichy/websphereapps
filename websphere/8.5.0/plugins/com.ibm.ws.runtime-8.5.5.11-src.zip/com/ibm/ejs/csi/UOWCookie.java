package com.ibm.ejs.csi;

import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;

public interface UOWCookie {
	boolean isLocalTx();

	boolean beganTx();

	SynchronizationRegistryUOWScope getTransactionalUOW();

	void setTransactionalUOW(SynchronizationRegistryUOWScope var1);

	SynchronizationRegistryUOWScope getSuspendedTransactionalUOW();
}