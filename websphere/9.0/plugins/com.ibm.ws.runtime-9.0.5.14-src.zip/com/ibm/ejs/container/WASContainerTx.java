package com.ibm.ejs.container;

import com.ibm.ejs.csi.UOWControl;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.appprofile.accessintent.AccessIntent;
import com.ibm.websphere.cpmi.PMHomeInfo;
import com.ibm.websphere.cpmi.PersistenceManager;
import com.ibm.websphere.csi.BeanBundle;
import com.ibm.websphere.csi.BeanInstanceInfo;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.InconsistentAccessIntentException;
import com.ibm.websphere.csi.TransactionListener;
import com.ibm.ws.ejbcontainer.diagnostics.IntrospectionWriter;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.uow.embeddable.SynchronizationRegistryUOWScope;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;

public class WASContainerTx extends ContainerTx implements EntityContainerTx {
	private static final TraceComponent tc = Tr.register(WASContainerTx.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.WASContainerTx";
	private PersistenceManager pmManager = null;
	HashMap<BeanId, AccessIntent> ivAICache = new HashMap();

	public WASContainerTx(EJSContainer container, boolean isTransactionGlobal, SynchronizationRegistryUOWScope txKey,
			PersistenceManager pmm, UOWControl UOWCtrl) {
		super(container, isTransactionGlobal, txKey, UOWCtrl);
		this.pmManager = pmm;
	}

	public final boolean isTransactionGlobal() {
		return this.globalTransaction;
	}

	public BeanBundle[] getEnlistedEntityBeans(PMHomeInfo[] homes) {
		int numHomes = 0;
		int numBundles = 0;
		int totalBeans = 0;
		ArrayList<BeanBundle> bundles = null;
		BeanBundle[] result = null;
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "getEnlistedEntityBeans (" + homes + ")");
		}

		BeanO callbackBeanO = EJSContainer.getThreadData().getCallbackBeanO();
		if (callbackBeanO != null && !callbackBeanO.home.beanMetaData.isPreFindFlushEnabled) {
			result = null;
		} else {
			if (homes == null && this.homesForPMManagedBeans != null && this.homesForPMManagedBeans.size() > 0) {
				homes = new PMHomeInfo[this.homesForPMManagedBeans.size()];
				homes = (PMHomeInfo[]) this.homesForPMManagedBeans.keySet().toArray(homes);
			}

			if (homes != null && this.homesForPMManagedBeans != null) {
				numHomes = homes.length;
				bundles = new ArrayList(numHomes);
			}

			for (int i = 0; i < numHomes; ++i) {
				PMHomeInfo homeRecord = homes[i];
				HomeInternal home = ((HomeRecord) homeRecord).homeInternal;
				ArrayList<BeanO> homeBeanOs = null;
				if (home != null) {
					homeBeanOs = (ArrayList) this.homesForPMManagedBeans.get(home);
				}

				if (homeBeanOs != null) {
					int numBeans = homeBeanOs.size();
					if (numBeans > 0) {
						totalBeans += numBeans;
						BeanInstanceInfo[] instances = new BeanInstanceInfo[numBeans];
						instances = (BeanInstanceInfo[]) homeBeanOs.toArray(instances);
						if (isTraceOn && tc.isDebugEnabled()) {
							Tr.debug(tc, numBeans + " enlisted beans for " + home);
						}

						BeanBundle bundle = new BeanBundle();
						bundle.ejbHome = homeRecord;
						bundle.beanInstances = instances;
						bundles.add(bundle);
						++numBundles;
					} else if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "0 enlisted beans for " + home);
					}
				} else if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "No enlisted beans for " + home);
				}
			}

			result = new BeanBundle[numBundles];
			if (numBundles > 0) {
				result = (BeanBundle[]) bundles.toArray(result);
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "getEnlistedEntityBeans : homes = " + numBundles + ", beans = " + totalBeans + " : " + result);
		}

		return result;
	}

	public void flush(BeanBundle[] beans) throws CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "flush (" + beans + ")");
		}

		this.ivFlushRequired = false;
		EJBThreadData threadData = EJSContainer.getThreadData();
		BeanO callbackBeanO = threadData.getCallbackBeanO();
		if (callbackBeanO != null && !callbackBeanO.home.beanMetaData.isPreFindFlushEnabled) {
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "flush(BeanBundle[]): disabled");
			}

		} else {
			BeanO[] enlistedBeans = this.getAllEnlistedBeanOs();
			if (enlistedBeans != null && enlistedBeans.length > 0 && beans != null) {
				HashSet<BeanInstanceInfo> cmp2xBeansToFlush = new HashSet(251);

				for (int i = 0; i < beans.length; ++i) {
					for (int j = 0; j < beans[i].beanInstances.length; ++j) {
						cmp2xBeansToFlush.add(beans[i].beanInstances[j]);
					}
				}

				this.flush(enlistedBeans, cmp2xBeansToFlush);
			} else if (enlistedBeans != null) {
				this.flush(enlistedBeans, (HashSet) null);
				if (isTraceOn && tc.isDebugEnabled()) {
					Tr.debug(tc, "All " + enlistedBeans.length + " enlisted beans were flushed.");
				}
			} else if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "No beans enlisted in this tran, therefore none were flushed.");
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "flush(BeanBundle[])");
			}

		}
	}

	public TransactionListener getTxListener() throws ContainerEJBException {
		if (this.txListener == null) {
			try {
				this.pmManager.attachListener(this);
				if (this.txListener == null) {
					throw new ContainerEJBException("Error: Null Transaction Listener");
				}

				this.txListener.afterBegin();
			} catch (Throwable var3) {
				FFDCFilter.processException(var3, "com.ibm.ejs.container.WASContainerTx.preInvoke", "1254", this);
				ContainerEJBException ex2 = new ContainerEJBException("Major Error, No Transaction Listener", var3);
				Tr.error(tc, "CAUGHT_EXCEPTION_THROWING_NEW_EXCEPTION_CNTR0035E", new Object[]{var3, ex2.toString()});
				if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
					Tr.debug(tc, "Caught unexpected Throwable from PM.attachListener", var3);
				}

				throw ex2;
			}
		}

		return this.txListener;
	}

	public void setTxListener(TransactionListener tl) {
		this.txListener = tl;
	}

	public boolean finderStartedTransaction() {
		return this.began;
	}

	protected void attachListener() {
		this.pmManager.attachListener(this);
	}

	public void flush() throws CSIException {
		this.flush(this.getAllEnlistedBeanOs(), (HashSet) null);
		this.pmManager.flushDeferredOperation(this, (PMHomeInfo[]) null);
	}

	public AccessIntent cacheAccessIntent(BeanId id, AccessIntent newAI) throws InconsistentAccessIntentException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "cacheAccessIntent : " + id + ", " + EntityHelperImpl.getAccessIntentString(newAI));
		}

		AccessIntent ai = (AccessIntent) this.ivAICache.get(id);
		if (ai == null) {
			this.ivAICache.put(id, newAI);
			ai = newAI;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "cacheAccessIntent added new entry to TX cache");
			}
		} else if (ai != newAI && aiConsistencyCheck(ai, newAI)) {
			this.ivAICache.put(id, newAI);
			ai = newAI;
			if (isTraceOn && tc.isDebugEnabled()) {
				Tr.debug(tc, "cacheAccessIntent promoted wsPessimisticRead to wsPessimisticUpdate");
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "cacheAccessIntent : " + id + ", " + EntityHelperImpl.getAccessIntentString(ai));
		}

		return ai;
	}

	static boolean aiConsistencyCheck(AccessIntent ai, AccessIntent newAI) throws InconsistentAccessIntentException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "aiConsistentCheck : " + EntityHelperImpl.getAccessIntentString(ai) + " : "
					+ EntityHelperImpl.getAccessIntentString(newAI));
		}

		boolean promote = false;
		int concurrency = ai.getConcurrencyControl();
		int newConcurrency = newAI.getConcurrencyControl();
		if (newConcurrency != concurrency) {
			throw new InconsistentAccessIntentException("Change in concurrency control not allowed");
		} else {
			int accessType = ai.getAccessType();
			int lockHint;
			if (accessType == 2) {
				lockHint = newAI.getAccessType();
				if (lockHint == 1) {
					throw new InconsistentAccessIntentException("Read access can not be changed to update access");
				}
			}

			if (concurrency == 1) {
				lockHint = ai.getPessimisticUpdateLockHint();
				int newLockHint = newAI.getPessimisticUpdateLockHint();
				if (newLockHint != lockHint) {
					if (lockHint == 2) {
						if (newLockHint != 3) {
							throw new InconsistentAccessIntentException(
									"Same transaction accessing same bean using inconsistent pessimistic update policies.");
						}
					} else {
						if (lockHint != 3) {
							throw new InconsistentAccessIntentException(
									"Same transaction accessing same bean using inconsistent pessimistic update policies.");
						}

						if (newLockHint != 2) {
							throw new InconsistentAccessIntentException(
									"Same transaction accessing same bean using inconsistent pessimistic update policies.");
						}
					}
				}
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "aiConsistentCheck returning " + promote);
			}

			return promote;
		}
	}

	public AccessIntent getCachedAccessIntent(BeanId id) {
		AccessIntent ai = (AccessIntent) this.ivAICache.get(id);
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "getCacheAccessIntent : " + id + ", " + EntityHelperImpl.getAccessIntentString(ai));
		}

		return ai;
	}

	protected void introspectAccessIntent(IntrospectionWriter writer) {
		int numAIs = this.ivAICache == null ? 0 : this.ivAICache.size();
		if (numAIs > 0) {
			writer.begin("Access Intents : " + numAIs);
			Iterator i$ = this.ivAICache.entrySet().iterator();

			while (i$.hasNext()) {
				Entry<BeanId, AccessIntent> entry = (Entry) i$.next();
				writer.println(entry.getKey() + " --> "
						+ EntityHelperImpl.getAccessIntentString((AccessIntent) entry.getValue()));
			}

			writer.end();
		}

	}
}