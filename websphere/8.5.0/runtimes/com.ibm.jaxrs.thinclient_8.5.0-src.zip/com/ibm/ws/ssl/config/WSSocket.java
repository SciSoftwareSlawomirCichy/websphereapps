package com.ibm.ws.ssl.config;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.nio.channels.SocketChannel;
import javax.net.ssl.HandshakeCompletedListener;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class WSSocket extends SSLSocket {
	private static final TraceComponent tc = Tr.register(WSSocket.class, "SSL", "com.ibm.ws.ssl.resources.ssl");
	protected Socket socket;

	public WSSocket(Socket s) {
		this.socket = s;
	}

	public SocketChannel getChannel() {
		return this.socket.getChannel();
	}

	public InetAddress getInetAddress() {
		return this.socket.getInetAddress();
	}

	public boolean getKeepAlive() throws SocketException {
		return this.socket.getKeepAlive();
	}

	public InetAddress getLocalAddress() {
		return this.socket.getLocalAddress();
	}

	public int getLocalPort() {
		return this.socket.getLocalPort();
	}

	public SocketAddress getLocalSocketAddress() {
		return this.socket.getLocalSocketAddress();
	}

	public boolean getOOBInline() throws SocketException {
		return this.socket.getOOBInline();
	}

	public int getPort() {
		return this.socket.getPort();
	}

	public int getReceiveBufferSize() throws SocketException {
		return this.socket.getReceiveBufferSize();
	}

	public SocketAddress getRemoteSocketAddress() {
		return this.socket.getRemoteSocketAddress();
	}

	public boolean getReuseAddress() throws SocketException {
		return this.socket.getReuseAddress();
	}

	public int getSendBufferSize() throws SocketException {
		return this.socket.getSendBufferSize();
	}

	public int getSoLinger() throws SocketException {
		return this.socket.getSoLinger();
	}

	public int getSoTimeout() throws SocketException {
		return this.socket.getSoTimeout();
	}

	public boolean getTcpNoDelay() throws SocketException {
		return this.socket.getTcpNoDelay();
	}

	public int getTrafficClass() throws SocketException {
		return this.socket.getTrafficClass();
	}

	public boolean isBound() {
		return this.socket.isBound();
	}

	public boolean isClosed() {
		return this.socket.isClosed();
	}

	public boolean isConnected() {
		return this.socket.isConnected();
	}

	public boolean isInputShutdown() {
		return this.socket.isInputShutdown();
	}

	public boolean isOutputShutdown() {
		return this.socket.isOutputShutdown();
	}

	public void sendUrgentData(int data) throws IOException {
		this.socket.sendUrgentData(data);
	}

	public void setKeepAlive(boolean on) throws SocketException {
		this.socket.setKeepAlive(on);
	}

	public void setOOBInline(boolean on) throws SocketException {
		this.socket.setOOBInline(on);
	}

	public void setReceiveBufferSize(int size) throws SocketException {
		this.socket.setReceiveBufferSize(size);
	}

	public void setReuseAddress(boolean on) throws SocketException {
		this.socket.setReuseAddress(on);
	}

	public void setSendBufferSize(int size) throws SocketException {
		this.socket.setSendBufferSize(size);
	}

	public void setSoLinger(boolean on, int l) throws SocketException {
		this.socket.setSoLinger(on, l);
	}

	public void setSoTimeout(int timeout) throws SocketException {
		this.socket.setSoTimeout(timeout);
	}

	public void setTcpNoDelay(boolean on) throws SocketException {
		this.socket.setTcpNoDelay(on);
	}

	public void setTrafficClass(int tc) throws SocketException {
		this.socket.setTrafficClass(tc);
	}

	public void shutdownInput() throws IOException {
		this.socket.shutdownInput();
	}

	public void shutdownOutput() throws IOException {
		this.socket.shutdownOutput();
	}

	public OutputStream getOutputStream() throws IOException {
		return this.socket.getOutputStream();
	}

	public InputStream getInputStream() throws IOException {
		return this.socket.getInputStream();
	}

	public String toString() {
		return this.socket.toString();
	}

	public void bind(SocketAddress bindpoint) throws IOException {
		this.socket.bind(bindpoint);
	}

	public void close() throws IOException {
		this.socket.close();
	}

	public void connect(SocketAddress endpoint) throws IOException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connect(0)", new Object[]{endpoint});
		}

		this.socket.connect(endpoint);
		if (endpoint instanceof InetSocketAddress) {
			InetSocketAddress ep = (InetSocketAddress) endpoint;
			int port = ep.getPort();
			String host = ep.getHostName();
			SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
			this.socket = factory.createSocket(this.socket, host, port, true);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connect(0)");
		}

	}

	public void connect(SocketAddress endpoint, int timeout) throws IOException {
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "connect(1)", new Object[]{endpoint, timeout});
		}

		this.socket.connect(endpoint, timeout);
		if (endpoint instanceof InetSocketAddress) {
			InetSocketAddress ep = (InetSocketAddress) endpoint;
			int port = ep.getPort();
			String host = ep.getHostName();
			SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
			this.socket = factory.createSocket(this.socket, host, port, true);
		}

		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "connect(1)");
		}

	}

	public void addHandshakeCompletedListener(HandshakeCompletedListener listener) {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).addHandshakeCompletedListener(listener);
		}

	}

	public String[] getEnabledCipherSuites() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getEnabledCipherSuites() : null;
	}

	public String[] getEnabledProtocols() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getEnabledProtocols() : null;
	}

	public boolean getEnableSessionCreation() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getEnableSessionCreation() : false;
	}

	public boolean getNeedClientAuth() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getNeedClientAuth() : false;
	}

	public SSLSession getSession() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getSession() : null;
	}

	public SSLParameters getSSLParameters() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getSSLParameters() : null;
	}

	public String[] getSupportedCipherSuites() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getSupportedCipherSuites() : null;
	}

	public String[] getSupportedProtocols() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getSupportedProtocols() : null;
	}

	public boolean getUseClientMode() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getUseClientMode() : false;
	}

	public boolean getWantClientAuth() {
		return this.socket instanceof SSLSocket ? ((SSLSocket) this.socket).getWantClientAuth() : false;
	}

	public void removeHandshakeCompletedListener(HandshakeCompletedListener listener) {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).removeHandshakeCompletedListener(listener);
		}

	}

	public void setEnabledCipherSuites(String[] suites) {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).setEnabledCipherSuites(suites);
		}

	}

	public void setEnabledProtocols(String[] protocols) {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).setEnabledProtocols(protocols);
		}

	}

	public void setEnableSessionCreation(boolean flag) {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).setEnableSessionCreation(flag);
		}

	}

	public void setNeedClientAuth(boolean need) {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).setNeedClientAuth(need);
		}

	}

	public void setSSLParameters(SSLParameters params) {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).setSSLParameters(params);
		}

	}

	public void setUseClientMode(boolean mode) {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).setUseClientMode(mode);
		}

	}

	public void setWantClientAuth(boolean want) {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).setWantClientAuth(want);
		}

	}

	public void startHandshake() throws IOException {
		if (this.socket instanceof SSLSocket) {
			((SSLSocket) this.socket).startHandshake();
		}

	}
}