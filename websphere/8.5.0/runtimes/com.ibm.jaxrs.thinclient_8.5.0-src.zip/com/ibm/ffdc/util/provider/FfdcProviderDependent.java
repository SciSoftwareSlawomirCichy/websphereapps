package com.ibm.ffdc.util.provider;

public abstract class FfdcProviderDependent<T extends FfdcProvider> {
	protected final T provider;

	protected FfdcProviderDependent(T provider) {
		this.provider = provider;
	}

	protected void ffdcerror(Throwable th) {
		this.provider.ffdcerror(th);
	}
}