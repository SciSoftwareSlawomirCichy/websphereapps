package com.ibm.ejs.cm;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.Transaction.DestroyXAResourceException;
import com.ibm.ws.Transaction.XAResourceFactory;
import com.ibm.ws.Transaction.XAResourceInfo;
import com.ibm.ws.Transaction.XAResourceNotAvailableException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Hashtable;
import javax.sql.XAConnection;
import javax.sql.XADataSource;
import javax.transaction.xa.XAResource;

public class CMXAResourceFactory implements XAResourceFactory {
	private static TraceComponent tc = Tr.register(CMXAResourceFactory.class);
	private static Hashtable xaResConnection = new Hashtable();

	public XAResource getXAResource(XAResourceInfo xaresinfo) throws XAResourceNotAvailableException {
		String methodName = "getXAResource";
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "getXAResource", xaresinfo);
		}

		CMXAResourceInfo cmxaresinfo = (CMXAResourceInfo) xaresinfo;
		DataSourceProperties dsProps = cmxaresinfo.getDataSourceProperties();
		XADataSource xads = null;
		XAConnection xaconn = null;
		XAResource xares = null;
		Object conn = null;

		try {
			xads = dsProps.getXADataSource();
			if (dsProps.getProperty("user") == null) {
				xaconn = xads.getXAConnection();
			} else {
				xaconn = xads.getXAConnection(dsProps.getProperty("user"), dsProps.getProperty("password"));
			}

			xares = xaconn.getXAResource();
		} catch (SQLException var17) {
			Tr.warning(tc, "WTRN0005_ERR_CREATING_XACONNECTION_AND_XARESOURCE", var17);
			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "getXAResource");
			}

			throw new XAResourceNotAvailableException(var17);
		} finally {
			if (conn != null) {
				try {
					((Connection) conn).close();
				} catch (SQLException var16) {
					;
				}
			}

		}

		xaResConnection.put(xares, xaconn);
		if (tc.isEntryEnabled()) {
			Tr.exit(tc, "getXAResource");
		}

		return xares;
	}

	public void destroyXAResource(XAResource xares) throws DestroyXAResourceException {
		String methodName = "destroyXAResource";
		if (tc.isEntryEnabled()) {
			Tr.entry(tc, "destroyXAResource");
		}

		XAConnection xacon = (XAConnection) xaResConnection.get(xares);
		if (xacon == null) {
			if (tc.isEventEnabled()) {
				Tr.event(tc, "xacon has already been closed.");
			}

		} else {
			try {
				xacon.close();
				xaResConnection.remove(xares);
			} catch (SQLException var5) {
				Tr.warning(tc, "WTRN0006_ERR_CLOSING_XA_CONNECTION", new Object[]{xacon, var5});
				throw new DestroyXAResourceException(var5);
			}

			if (tc.isEntryEnabled()) {
				Tr.exit(tc, "destroyXAResource");
			}

		}
	}
}