package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.csi.CSIException;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObjectContext;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public final class ManagedBeanHome extends EJSHome {
	private static final long serialVersionUID = -2989564306972856906L;
	private static final String CLASS_NAME = ManagedBeanHome.class.getName();
	private static final TraceComponent tc;
	private WeakManagedBeanCache ivWeakCache;

	public ManagedBeanHome() throws RemoteException {
	}

	public void completeInitialization() throws RemoteException {
		this.enterpriseBeanClass = this.beanMetaData.enterpriseBeanClass;
		this.localEJBObjectClass = this.beanMetaData.localImplClass;
		if (this.beanMetaData.ivInterceptorMetaData != null
				&& this.beanMetaData.ivInterceptorMetaData.ivPreDestroyInterceptors != null) {
			this.ivWeakCache = WeakManagedBeanCache.instance();
		}

	}

	public synchronized void destroy() {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "destroy home " + this.j2eeName);
		}

		if (this.enabled) {
			if (this.ivWeakCache != null) {
				this.ivWeakCache.remove(this);
			}

			super.destroy();
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "destroy home " + this.j2eeName);
			}

		}
	}

	public boolean isManagedBeanHome() {
		return true;
	}

	public Object createBusinessObject(String businessInterface, boolean useSupporting)
			throws CreateException, RemoteException, CSIException {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createBusinessObject: " + businessInterface);
		}

		this.homeEnabled();

		Object bean;
		try {
			BeanO beanO = this.createNewBeanO((ManagedObjectContext) null);
			if (this.beanMetaData.ivManagedBeanBeanOField == null) {
				bean = beanO.getBeanInstance();
			} else {
				bean = this.createManagedBeanWrapper(beanO);
			}
		} catch (RuntimeException var8) {
			FFDCFilter.processException(var8, CLASS_NAME + ".createBusinessObject", "123", this);
			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createBusinessObject returning: " + var8);
			}

			throw var8;
		} catch (Exception var9) {
			FFDCFilter.processException(var9, CLASS_NAME + ".createBusinessObject", "129", this);
			RuntimeException rex = null;

			for (Throwable cause = var9.getCause(); cause != null; cause = cause.getCause()) {
				if (cause instanceof RuntimeException) {
					rex = (RuntimeException) cause;
					break;
				}
			}

			if (rex == null) {
				rex = new RuntimeException(
						"Failure creating instance of " + this.beanMetaData.j2eeName + " ManagedBean : " + var9, var9);
			}

			if (isTraceOn && tc.isEntryEnabled()) {
				Tr.exit(tc, "createBusinessObject returning: " + rex);
			}

			throw rex;
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createBusinessObject returning: " + Util.identity(bean));
		}

		return bean;
	}

	private Object createManagedBeanWrapper(BeanO beanO) throws IllegalAccessException, InstantiationException {
		Object wrapper = this.beanMetaData.ivBusinessLocalImplClasses[0].newInstance();
		BusinessLocalWrapper bLocal = new BusinessLocalWrapper();
		this.beanMetaData.ivLocalBeanContainerField.set(wrapper, this.container);
		this.beanMetaData.ivLocalBeanWrapperField.set(wrapper, bLocal);
		this.beanMetaData.ivManagedBeanBeanOField.set(wrapper, beanO);
		bLocal.container = this.container;
		bLocal.wrapperManager = this.wrapperManager;
		bLocal.ivCommon = null;
		bLocal.isManagedWrapper = false;
		bLocal.ivInterface = WrapperInterface.BUSINESS_LOCAL;
		bLocal.beanId = beanO.beanId;
		bLocal.bmd = this.beanMetaData;
		bLocal.methodInfos = this.beanMetaData.localMethodInfos;
		bLocal.methodNames = this.beanMetaData.localMethodNames;
		bLocal.isolationAttrs = null;
		bLocal.ivPmiBean = this.pmiBean;
		if (this.ivWeakCache != null) {
			this.ivWeakCache.add(bLocal, beanO);
		}

		return wrapper;
	}

	public Object createLocalBusinessObject(String interfaceName, boolean useSupporting)
			throws RemoteException, CreateException {
		return this.createBusinessObject(interfaceName, useSupporting);
	}

	public Object createRemoteBusinessObject(String interfaceName, boolean useSupporting)
			throws RemoteException, CreateException {
		return this.createBusinessObject(interfaceName, useSupporting);
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}