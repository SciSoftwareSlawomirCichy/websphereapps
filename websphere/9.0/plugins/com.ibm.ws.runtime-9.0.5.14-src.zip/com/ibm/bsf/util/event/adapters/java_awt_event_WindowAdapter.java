package com.ibm.bsf.util.event.adapters;

import com.ibm.bsf.util.event.EventAdapterImpl;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class java_awt_event_WindowAdapter extends EventAdapterImpl implements WindowListener {
	public void windowActivated(WindowEvent var1) {
		this.eventProcessor.processEvent("windowActivated", new Object[]{var1});
	}

	public void windowClosed(WindowEvent var1) {
		this.eventProcessor.processEvent("windowClosed", new Object[]{var1});
	}

	public void windowClosing(WindowEvent var1) {
		this.eventProcessor.processEvent("windowClosing", new Object[]{var1});
	}

	public void windowDeactivated(WindowEvent var1) {
		this.eventProcessor.processEvent("windowDeactivated", new Object[]{var1});
	}

	public void windowDeiconified(WindowEvent var1) {
		this.eventProcessor.processEvent("windowDeiconified", new Object[]{var1});
	}

	public void windowIconified(WindowEvent var1) {
		this.eventProcessor.processEvent("windowIconified", new Object[]{var1});
	}

	public void windowOpened(WindowEvent var1) {
		this.eventProcessor.processEvent("windowOpened", new Object[]{var1});
	}
}