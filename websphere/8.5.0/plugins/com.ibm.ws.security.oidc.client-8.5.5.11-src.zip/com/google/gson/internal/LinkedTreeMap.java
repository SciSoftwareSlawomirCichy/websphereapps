package com.google.gson.internal;

import com.google.gson.internal.LinkedTreeMap.1;
import com.google.gson.internal.LinkedTreeMap.EntrySet;
import com.google.gson.internal.LinkedTreeMap.KeySet;
import com.google.gson.internal.LinkedTreeMap.Node;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.Map.Entry;

public final class LinkedTreeMap<K, V> extends AbstractMap<K, V> implements Serializable {
	private static final Comparator<Comparable> NATURAL_ORDER = new 1();
	Comparator<? super K> comparator;
	Node<K, V> root;
	int size;
	int modCount;
	final Node<K, V> header;
	private LinkedTreeMap<K, V>.EntrySet entrySet;
	private LinkedTreeMap<K, V>.KeySet keySet;

	public LinkedTreeMap() {
		this(NATURAL_ORDER);
	}

	public LinkedTreeMap(Comparator<? super K> comparator) {
		this.size = 0;
		this.modCount = 0;
		this.header = new Node();
		this.comparator = comparator != null ? comparator : NATURAL_ORDER;
	}

	public int size() {
		return this.size;
	}

	public V get(Object key) {
		Node<K, V> node = this.findByObject(key);
		return node != null ? node.value : null;
	}

	public boolean containsKey(Object key) {
		return this.findByObject(key) != null;
	}

	public V put(K key, V value) {
		if (key == null) {
			throw new NullPointerException("key == null");
		} else {
			Node<K, V> created = this.find(key, true);
			V result = created.value;
			created.value = value;
			return result;
		}
	}

	public void clear() {
		this.root = null;
		this.size = 0;
		++this.modCount;
		Node<K, V> header = this.header;
		header.next = header.prev = header;
	}

	public V remove(Object key) {
		Node<K, V> node = this.removeInternalByKey(key);
		return node != null ? node.value : null;
	}

	Node<K, V> find(K key, boolean create) {
		Comparator<? super K> comparator = this.comparator;
		Node<K, V> nearest = this.root;
		int comparison = 0;
		Node created;
		if (nearest != null) {
			Comparable comparableKey = comparator == NATURAL_ORDER ? (Comparable) key : null;

			while (true) {
				comparison = comparableKey != null
						? comparableKey.compareTo(nearest.key)
						: comparator.compare(key, nearest.key);
				if (comparison == 0) {
					return nearest;
				}

				created = comparison < 0 ? nearest.left : nearest.right;
				if (created == null) {
					break;
				}

				nearest = created;
			}
		}

		if (!create) {
			return null;
		} else {
			Node<K, V> header = this.header;
			if (nearest == null) {
				if (comparator == NATURAL_ORDER && !(key instanceof Comparable)) {
					throw new ClassCastException(key.getClass().getName() + " is not Comparable");
				}

				created = new Node(nearest, key, header, header.prev);
				this.root = created;
			} else {
				created = new Node(nearest, key, header, header.prev);
				if (comparison < 0) {
					nearest.left = created;
				} else {
					nearest.right = created;
				}

				this.rebalance(nearest, true);
			}

			++this.size;
			++this.modCount;
			return created;
		}
	}

	Node<K, V> findByObject(Object key) {
		try {
			return key != null ? this.find(key, false) : null;
		} catch (ClassCastException var3) {
			return null;
		}
	}

	Node<K, V> findByEntry(Entry<?, ?> entry) {
		Node<K, V> mine = this.findByObject(entry.getKey());
		boolean valuesEqual = mine != null && this.equal(mine.value, entry.getValue());
		return valuesEqual ? mine : null;
	}

	private boolean equal(Object a, Object b) {
		return a == b || a != null && a.equals(b);
	}

	void removeInternal(Node<K, V> node, boolean unlink) {
		if (unlink) {
			node.prev.next = node.next;
			node.next.prev = node.prev;
		}

		Node<K, V> left = node.left;
		Node<K, V> right = node.right;
		Node<K, V> originalParent = node.parent;
		if (left != null && right != null) {
			Node<K, V> adjacent = left.height > right.height ? left.last() : right.first();
			this.removeInternal(adjacent, false);
			int leftHeight = 0;
			left = node.left;
			if (left != null) {
				leftHeight = left.height;
				adjacent.left = left;
				left.parent = adjacent;
				node.left = null;
			}

			int rightHeight = 0;
			right = node.right;
			if (right != null) {
				rightHeight = right.height;
				adjacent.right = right;
				right.parent = adjacent;
				node.right = null;
			}

			adjacent.height = Math.max(leftHeight, rightHeight) + 1;
			this.replaceInParent(node, adjacent);
		} else {
			if (left != null) {
				this.replaceInParent(node, left);
				node.left = null;
			} else if (right != null) {
				this.replaceInParent(node, right);
				node.right = null;
			} else {
				this.replaceInParent(node, (Node) null);
			}

			this.rebalance(originalParent, false);
			--this.size;
			++this.modCount;
		}
	}

	Node<K, V> removeInternalByKey(Object key) {
		Node<K, V> node = this.findByObject(key);
		if (node != null) {
			this.removeInternal(node, true);
		}

		return node;
	}

	private void replaceInParent(Node<K, V> node, Node<K, V> replacement) {
		Node<K, V> parent = node.parent;
		node.parent = null;
		if (replacement != null) {
			replacement.parent = parent;
		}

		if (parent != null) {
			if (parent.left == node) {
				parent.left = replacement;
			} else {
				assert parent.right == node;

				parent.right = replacement;
			}
		} else {
			this.root = replacement;
		}

	}

	private void rebalance(Node<K, V> unbalanced, boolean insert) {
		for (Node node = unbalanced; node != null; node = node.parent) {
			Node<K, V> left = node.left;
			Node<K, V> right = node.right;
			int leftHeight = left != null ? left.height : 0;
			int rightHeight = right != null ? right.height : 0;
			int delta = leftHeight - rightHeight;
			Node leftLeft;
			Node leftRight;
			int leftRightHeight;
			int leftLeftHeight;
			int leftDelta;
			if (delta == -2) {
				leftLeft = right.left;
				leftRight = right.right;
				leftRightHeight = leftRight != null ? leftRight.height : 0;
				leftLeftHeight = leftLeft != null ? leftLeft.height : 0;
				leftDelta = leftLeftHeight - leftRightHeight;
				if (leftDelta != -1 && (leftDelta != 0 || insert)) {
					assert leftDelta == 1;

					this.rotateRight(right);
					this.rotateLeft(node);
				} else {
					this.rotateLeft(node);
				}

				if (insert) {
					break;
				}
			} else if (delta == 2) {
				leftLeft = left.left;
				leftRight = left.right;
				leftRightHeight = leftRight != null ? leftRight.height : 0;
				leftLeftHeight = leftLeft != null ? leftLeft.height : 0;
				leftDelta = leftLeftHeight - leftRightHeight;
				if (leftDelta == 1 || leftDelta == 0 && !insert) {
					this.rotateRight(node);
				} else {
					assert leftDelta == -1;

					this.rotateLeft(left);
					this.rotateRight(node);
				}

				if (insert) {
					break;
				}
			} else if (delta == 0) {
				node.height = leftHeight + 1;
				if (insert) {
					break;
				}
			} else {
				assert delta == -1 || delta == 1;

				node.height = Math.max(leftHeight, rightHeight) + 1;
				if (!insert) {
					break;
				}
			}
		}

	}

	private void rotateLeft(Node<K, V> root) {
		Node<K, V> left = root.left;
		Node<K, V> pivot = root.right;
		Node<K, V> pivotLeft = pivot.left;
		Node<K, V> pivotRight = pivot.right;
		root.right = pivotLeft;
		if (pivotLeft != null) {
			pivotLeft.parent = root;
		}

		this.replaceInParent(root, pivot);
		pivot.left = root;
		root.parent = pivot;
		root.height = Math.max(left != null ? left.height : 0, pivotLeft != null ? pivotLeft.height : 0) + 1;
		pivot.height = Math.max(root.height, pivotRight != null ? pivotRight.height : 0) + 1;
	}

	private void rotateRight(Node<K, V> root) {
		Node<K, V> pivot = root.left;
		Node<K, V> right = root.right;
		Node<K, V> pivotLeft = pivot.left;
		Node<K, V> pivotRight = pivot.right;
		root.left = pivotRight;
		if (pivotRight != null) {
			pivotRight.parent = root;
		}

		this.replaceInParent(root, pivot);
		pivot.right = root;
		root.parent = pivot;
		root.height = Math.max(right != null ? right.height : 0, pivotRight != null ? pivotRight.height : 0) + 1;
		pivot.height = Math.max(root.height, pivotLeft != null ? pivotLeft.height : 0) + 1;
	}

	public Set<Entry<K, V>> entrySet() {
		LinkedTreeMap<K, V>.EntrySet result = this.entrySet;
		return result != null ? result : (this.entrySet = new EntrySet(this));
	}

	public Set<K> keySet() {
		LinkedTreeMap<K, V>.KeySet result = this.keySet;
		return result != null ? result : (this.keySet = new KeySet(this));
	}

	private Object writeReplace() throws ObjectStreamException {
		return new LinkedHashMap(this);
	}
}