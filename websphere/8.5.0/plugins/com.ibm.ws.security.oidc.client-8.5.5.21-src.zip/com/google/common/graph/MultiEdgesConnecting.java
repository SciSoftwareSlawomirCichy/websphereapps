package com.google.common.graph;

import com.google.common.base.Preconditions;
import com.google.common.collect.UnmodifiableIterator;
import com.google.common.graph.MultiEdgesConnecting.1;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

abstract class MultiEdgesConnecting<E> extends AbstractSet<E> {
	private final Map<E, ?> outEdgeToNode;
	private final Object targetNode;

	MultiEdgesConnecting(Map<E, ?> outEdgeToNode, Object targetNode) {
		this.outEdgeToNode = (Map) Preconditions.checkNotNull(outEdgeToNode);
		this.targetNode = Preconditions.checkNotNull(targetNode);
	}

	public UnmodifiableIterator<E> iterator() {
      Iterator<? extends Entry<E, ?>> entries = this.outEdgeToNode.entrySet().iterator();
      return new 1(this, entries);
   }

	public boolean contains(@NullableDecl Object edge) {
		return this.targetNode.equals(this.outEdgeToNode.get(edge));
	}
}