package com.ibm.ejs.container;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.tx.jta.embeddable.EmbeddableTransactionManagerFactory;
import com.ibm.ws.LocalTransaction.LocalTransactionCoordinator;
import com.ibm.ws.LocalTransaction.LocalTransactionCurrent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.traceinfo.ejbcontainer.TETxLifeCycleInfo;
import com.ibm.ws.tx.embeddable.EmbeddableWebSphereTransactionManager;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.rmi.RemoteException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
import javax.transaction.UserTransaction;

public class UserTransactionWrapper implements UserTransaction, Serializable {
	private static final long serialVersionUID = 8016621367906146400L;
	private static final TraceComponent tc = Tr.register(UserTransactionWrapper.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.UserTransactionWrapper";
	public static final UserTransaction INSTANCE = new UserTransactionWrapper();
	private transient EJSContainer container;
	private transient UserTransaction userTransactionImpl;
	private transient EmbeddableWebSphereTransactionManager txCurrent;

	public UserTransactionWrapper() {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "<init>");
		}

		this.initialize();
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
			Tr.debug(tc, "readObject");
		}

		this.initialize();
	}

	private void initialize() {
		this.container = EJSContainer.getDefaultContainer();
		this.userTransactionImpl = this.container.userTransactionImpl;
		this.txCurrent = EmbeddableTransactionManagerFactory.getTransactionManager();
	}

	public void begin() throws NotSupportedException, SystemException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "UserTransactionWrapper.begin");
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			LocalTransactionCurrent ltcCurrent = EmbeddableTransactionManagerFactory.getLocalTransactionCurrent();
			LocalTransactionCoordinator lCoord = ltcCurrent.getLocalTranCoord();
			if (lCoord != null) {
				Tr.event(tc,
						"Tx Service will complete LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
			}
		}

		EJBThreadData threadData = EJSContainer.getUserTransactionThreadData();
		this.userTransactionImpl.begin();
		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled() && this.txCurrent != null) {
			Tr.event(tc, "User Code began TX cntxt: " + this.txCurrent.getTransaction());
		}

		try {
			this.container.processTxContextChange(threadData, false);
		} catch (RemoteException var4) {
			FFDCFilter.processException(var4, "com.ibm.ejs.container.UserTransactionWrapper.begin", "145", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "Exception during begin()", var4);
			}

			this.userTransactionImpl.rollback();
			throw new SystemException(var4.toString());
		}

		if (entryEnabled) {
			Tr.exit(tc, "UserTransactionWrapper.begin");
		}

	}

	public void commit() throws RollbackException, HeuristicMixedException, HeuristicRollbackException,
			SecurityException, IllegalStateException, SystemException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "UserTransactionWrapper.commit");
		}

		Transaction transaction = null;
		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled() && this.txCurrent != null) {
			transaction = this.txCurrent.getTransaction();
			Tr.event(tc, "User Code committing TX cntxt: " + transaction);
		}

		String idStr = null;
		if (TraceComponent.isAnyTracingEnabled() && TETxLifeCycleInfo.isTraceEnabled()) {
			if (this.txCurrent != null && transaction != null) {
				idStr = transaction.toString();
			} else {
				idStr = "NoTxCurrent";
			}
		}

		EJBThreadData threadData = EJSContainer.getUserTransactionThreadData();

		try {
			this.userTransactionImpl.commit();
			if (TraceComponent.isAnyTracingEnabled() && TETxLifeCycleInfo.isTraceEnabled()) {
				int idx;
				idStr = idStr != null
						? ((idx = idStr.indexOf("(")) != -1
								? idStr.substring(idx + 1, idStr.indexOf(")"))
								: ((idx = idStr.indexOf("tid=")) != -1 ? idStr.substring(idx + 4) : idStr))
						: "NoTx";
				TETxLifeCycleInfo.traceUserTxCommit(idStr, "User Tx Commit");
			}

			this.changeToLocalContext(threadData);
		} catch (RollbackException var8) {
			FFDCFilter.processException(var8, "com.ibm.ejs.container.UserTransactionWrapper.commit", "285", this);
			if (TraceComponent.isAnyTracingEnabled()) {
				if (tc.isEntryEnabled()) {
					Tr.exit(tc, "Exception during commit()", var8);
				}

				if (TETxLifeCycleInfo.isTraceEnabled()) {
					int idx;
					idStr = idStr != null
							? ((idx = idStr.indexOf("(")) != -1
									? idStr.substring(idx + 1, idStr.indexOf(")"))
									: ((idx = idStr.indexOf("tid=")) != -1 ? idStr.substring(idx + 4) : idStr))
							: "NoTx";
					TETxLifeCycleInfo.traceUserTxCommit(idStr, "User Tx Commit Failed");
				}
			}

			try {
				this.changeToLocalContext(threadData);
			} catch (Throwable var7) {
				FFDCFilter.processException(var8, "com.ibm.ejs.container.UserTransactionWrapper.commit", "312", this);
				if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
					Tr.exit(tc, "Exception during changeToLocalContext()", var7);
				}
			}

			throw var8;
		} catch (RemoteException var9) {
			FFDCFilter.processException(var9, "com.ibm.ejs.container.UserTransactionWrapper.commit", "197", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "Exception during commit()", var9);
			}

			throw new SystemException(var9.toString());
		}

		if (entryEnabled) {
			Tr.exit(tc, "UserTransactionWrapper.commit");
		}

	}

	public void rollback() throws IllegalStateException, SecurityException, SystemException {
		String idStr = null;
		if (TraceComponent.isAnyTracingEnabled()) {
			if (tc.isEntryEnabled()) {
				Tr.entry(tc, "UserTransactionWrapper.rollback");
			}

			Transaction transaction = this.txCurrent != null ? this.txCurrent.getTransaction() : null;
			if (tc.isEventEnabled()) {
				Tr.event(tc, "User Code rolling back TX cntxt: " + transaction);
			}

			if (TETxLifeCycleInfo.isTraceEnabled()) {
				if (this.txCurrent != null && transaction != null) {
					idStr = transaction.toString();
				} else {
					idStr = "NoTxCurrent";
				}
			}
		}

		EJBThreadData threadData = EJSContainer.getUserTransactionThreadData();
		this.userTransactionImpl.rollback();

		try {
			if (TraceComponent.isAnyTracingEnabled() && TETxLifeCycleInfo.isTraceEnabled()) {
				int idx;
				idStr = idStr != null
						? ((idx = idStr.indexOf("(")) != -1
								? idStr.substring(idx + 1, idStr.indexOf(")"))
								: ((idx = idStr.indexOf("tid=")) != -1 ? idStr.substring(idx + 4) : idStr))
						: "NoTx";
				TETxLifeCycleInfo.traceUserTxCommit(idStr, "User Tx Rollback");
			}

			this.changeToLocalContext(threadData);
		} catch (RemoteException var4) {
			FFDCFilter.processException(var4, "com.ibm.ejs.container.UserTransactionWrapper.rollback", "237", this);
			if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
				Tr.exit(tc, "Exception during rollback()", var4);
			}

			throw new SystemException(var4.toString());
		}

		if (TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled()) {
			Tr.exit(tc, "UserTransactionWrapper.rollback");
		}

	}

	public void setRollbackOnly() throws IllegalStateException, SystemException {
		boolean entryEnabled = TraceComponent.isAnyTracingEnabled() && tc.isEntryEnabled();
		if (entryEnabled) {
			Tr.entry(tc, "UserTransactionWrapper.setRollbackOnly");
		}

		this.userTransactionImpl.setRollbackOnly();
		if (entryEnabled) {
			Tr.exit(tc, "UserTransactionWrapper.setRollbackOnly");
		}

	}

	public int getStatus() throws SystemException {
		return this.userTransactionImpl.getStatus();
	}

	public void setTransactionTimeout(int seconds) throws SystemException {
		this.userTransactionImpl.setTransactionTimeout(seconds);
		if (TraceComponent.isAnyTracingEnabled() && TETxLifeCycleInfo.isTraceEnabled()) {
			String idStr = "NoTxCurrent";
			if (this.txCurrent != null) {
				Transaction transaction = this.txCurrent.getTransaction();
				if (transaction != null) {
					idStr = transaction.toString();
				}

				int idx;
				idStr = idStr != null
						? ((idx = idStr.indexOf("(")) != -1
								? idStr.substring(idx + 1, idStr.indexOf(")"))
								: ((idx = idStr.indexOf("tid=")) != -1 ? idStr.substring(idx + 4) : idStr))
						: "NoTx";
			}

			TETxLifeCycleInfo.traceUserTxSetTimeout(idStr, "User Tx Set Timeout=" + seconds);
		}

	}

	private void changeToLocalContext(EJBThreadData threadData) throws RemoteException {
		if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
			LocalTransactionCurrent ltcCurrent = EmbeddableTransactionManagerFactory.getLocalTransactionCurrent();
			LocalTransactionCoordinator lCoord = ltcCurrent.getLocalTranCoord();
			if (lCoord != null) {
				Tr.event(tc, "Tx Service began LTC cntxt: tid=" + Integer.toHexString(lCoord.hashCode()) + "(LTC)");
			}
		}

		this.container.processTxContextChange(threadData, true);
	}
}