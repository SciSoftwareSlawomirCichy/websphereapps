package org.apache.http.client.protocol;

public interface ClientContext {
	String SCHEME_REGISTRY = "http.scheme-registry";
	String COOKIESPEC_REGISTRY = "http.cookiespec-registry";
	String COOKIE_SPEC = "http.cookie-spec";
	String COOKIE_ORIGIN = "http.cookie-origin";
	String COOKIE_STORE = "http.cookie-store";
	String AUTHSCHEME_REGISTRY = "http.authscheme-registry";
	String CREDS_PROVIDER = "http.auth.credentials-provider";
	String TARGET_AUTH_STATE = "http.auth.target-scope";
	String PROXY_AUTH_STATE = "http.auth.proxy-scope";
	String AUTH_SCHEME_PREF = "http.auth.scheme-pref";
	String USER_TOKEN = "http.user-token";
}