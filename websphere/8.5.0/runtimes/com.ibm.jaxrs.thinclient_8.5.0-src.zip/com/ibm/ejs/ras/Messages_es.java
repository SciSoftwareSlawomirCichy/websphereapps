package com.ibm.ejs.ras;

import java.util.ListResourceBundle;

public class Messages_es extends ListResourceBundle {
	private static final Object[][] resources = new Object[][]{
			{"-------------------------------------------------------------------------------------------------", ""},
			{"BUILDLEVELS_NOT_SAME_CWSJE0001E",
					"CWSJE0001E: Se ha detectado una incoherencia en los niveles build de los componentes del cliente del servidor de aplicaciones instalado. El nivel build del componente de cliente {0} que es {1} es diferente al nivel build del componente de cliente {2} que es {3}."},
			{"BUILDLEVELS_NOT_SAME_CWSJE0002E",
					"CWSJE0002E: Una incoherencia en los niveles build de los componentes del cliente del servidor de aplicaciones instalado impide la ejecución posterior."},
			{"EXCP_CWSJE0003E", "CWSJE0003E: No se puede acceder al recurso {1} debido a la excepción: {0}"}};

	public Object[][] getContents() {
		return resources;
	}
}