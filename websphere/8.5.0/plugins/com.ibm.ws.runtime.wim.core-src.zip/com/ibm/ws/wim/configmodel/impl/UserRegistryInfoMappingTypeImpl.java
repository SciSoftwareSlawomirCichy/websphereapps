package com.ibm.ws.wim.configmodel.impl;

import com.ibm.ws.wim.configmodel.ConfigmodelPackage;
import com.ibm.ws.wim.configmodel.UserRegistryInfoMappingType;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

public class UserRegistryInfoMappingTypeImpl extends EDataObjectImpl implements UserRegistryInfoMappingType {
	protected static final String PROPERTY_FOR_INPUT_EDEFAULT = null;
	protected String propertyForInput;
	protected static final String PROPERTY_FOR_OUTPUT_EDEFAULT = null;
	protected String propertyForOutput;

	protected UserRegistryInfoMappingTypeImpl() {
		this.propertyForInput = PROPERTY_FOR_INPUT_EDEFAULT;
		this.propertyForOutput = PROPERTY_FOR_OUTPUT_EDEFAULT;
	}

	protected EClass eStaticClass() {
		return ConfigmodelPackage.eINSTANCE.getUserRegistryInfoMappingType();
	}

	public String getPropertyForInput() {
		return this.propertyForInput;
	}

	public void setPropertyForInput(String var1) {
		String var2 = this.propertyForInput;
		this.propertyForInput = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 0, var2, this.propertyForInput));
		}

	}

	public String getPropertyForOutput() {
		return this.propertyForOutput;
	}

	public void setPropertyForOutput(String var1) {
		String var2 = this.propertyForOutput;
		this.propertyForOutput = var1;
		if (this.eNotificationRequired()) {
			this.eNotify(new ENotificationImpl(this, 1, 1, var2, this.propertyForOutput));
		}

	}

	public Object eGet(EStructuralFeature var1, boolean var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return this.getPropertyForInput();
			case 1 :
				return this.getPropertyForOutput();
			default :
				return this.eDynamicGet(var1, var2);
		}
	}

	public void eSet(EStructuralFeature var1, Object var2) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setPropertyForInput((String) var2);
				return;
			case 1 :
				this.setPropertyForOutput((String) var2);
				return;
			default :
				this.eDynamicSet(var1, var2);
		}
	}

	public void eUnset(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				this.setPropertyForInput(PROPERTY_FOR_INPUT_EDEFAULT);
				return;
			case 1 :
				this.setPropertyForOutput(PROPERTY_FOR_OUTPUT_EDEFAULT);
				return;
			default :
				this.eDynamicUnset(var1);
		}
	}

	public boolean eIsSet(EStructuralFeature var1) {
		switch (this.eDerivedStructuralFeatureID(var1)) {
			case 0 :
				return PROPERTY_FOR_INPUT_EDEFAULT == null
						? this.propertyForInput != null
						: !PROPERTY_FOR_INPUT_EDEFAULT.equals(this.propertyForInput);
			case 1 :
				return PROPERTY_FOR_OUTPUT_EDEFAULT == null
						? this.propertyForOutput != null
						: !PROPERTY_FOR_OUTPUT_EDEFAULT.equals(this.propertyForOutput);
			default :
				return this.eDynamicIsSet(var1);
		}
	}

	public String toString() {
		if (this.eIsProxy()) {
			return super.toString();
		} else {
			StringBuffer var1 = new StringBuffer(super.toString());
			var1.append(" (propertyForInput: ");
			var1.append(this.propertyForInput);
			var1.append(", propertyForOutput: ");
			var1.append(this.propertyForOutput);
			var1.append(')');
			return var1.toString();
		}
	}
}