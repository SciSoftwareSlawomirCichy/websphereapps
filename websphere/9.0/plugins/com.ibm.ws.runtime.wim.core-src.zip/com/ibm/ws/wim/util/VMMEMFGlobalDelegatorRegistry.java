package com.ibm.ws.wim.util;

import com.ibm.ws.wim.util.VMMEMFGlobalDelegatorRegistry.DummyRegistry;
import org.eclipse.emf.ecore.EPackage.Registry;
import org.eclipse.emf.ecore.impl.EPackageRegistryImpl.Delegator;

public class VMMEMFGlobalDelegatorRegistry extends Delegator {
	protected Registry delegateRegistry(ClassLoader var1) {
		return DummyRegistry.getRegistry(var1);
	}
}