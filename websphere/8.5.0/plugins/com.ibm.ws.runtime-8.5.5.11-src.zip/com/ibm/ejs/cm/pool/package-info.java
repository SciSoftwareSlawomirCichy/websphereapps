package com.ibm.ejs.cm.pool;

interface package-info {
}