package com.ibm.ejs.container.interceptors;

import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.managedobject.ManagedObject;
import com.ibm.ws.managedobject.ManagedObjectContext;
import com.ibm.ws.managedobject.ManagedObjectException;
import com.ibm.ws.managedobject.ManagedObjectFactory;
import com.ibm.ws.managedobject.ManagedObjectState;
import com.ibm.wsspi.injectionengine.InjectionEngine;
import com.ibm.wsspi.injectionengine.InjectionTarget;
import com.ibm.wsspi.injectionengine.InjectionTargetContext;
import java.lang.reflect.Method;

public class InterceptorMetaData {
	private static final String CLASS_NAME = InterceptorMetaData.class.getName();
	private static final TraceComponent tc;
	public final Class<?>[] ivInterceptorClasses;
	public final ManagedObjectFactory[] ivInterceptorFactories;
	public final InterceptorProxy[] ivPrePassivateInterceptors;
	public final InterceptorProxy[] ivPreDestroyInterceptors;
	public final InterceptorProxy[] ivPostConstructInterceptors;
	public final InterceptorProxy[] ivPostActivateInterceptors;
	public final Method[] ivBeanLifecycleMethods;
	public InjectionTarget[][] ivInterceptorInjectionTargets;

	public InterceptorMetaData(Class<?>[] classes, ManagedObjectFactory[] factories, InterceptorProxy[] postConstruct,
			InterceptorProxy[] postActivate, InterceptorProxy[] prePassivate, InterceptorProxy[] preDestroy,
			Method[] beanLifecycleMethods) {
		this.ivInterceptorClasses = classes;
		this.ivInterceptorFactories = factories;
		this.ivPostConstructInterceptors = postConstruct;
		this.ivPostActivateInterceptors = postActivate;
		this.ivPrePassivateInterceptors = prePassivate;
		this.ivPreDestroyInterceptors = preDestroy;
		this.ivBeanLifecycleMethods = beanLifecycleMethods;
	}

	public void createInterceptorInstances(InjectionEngine injectionEngine, Object[] interceptors,
			ManagedObjectState[] managedObjectStates, ManagedObjectContext objectContext,
			InjectionTargetContext targetContext) throws Exception {
		boolean isTraceOn = TraceComponent.isAnyTracingEnabled();
		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.entry(tc, "createInterceptorInstances");
		}

		if (this.ivInterceptorClasses != null) {
			int numberOfInterceptors = this.ivInterceptorClasses.length;

			for (int i = 0; i < numberOfInterceptors; ++i) {
				int len$;
				if (this.ivInterceptorFactories != null && this.ivInterceptorFactories[i] != null) {
					ManagedObject managedObject;
					try {
						managedObject = this.ivInterceptorFactories[i].create(objectContext);
					} catch (ManagedObjectException var14) {
						for (len$ = 0; len$ < i; ++len$) {
							managedObjectStates[len$].release();
						}

						Throwable cause = var14.getCause();
						throw (Exception) (cause instanceof Exception ? (Exception) cause : var14);
					}

					interceptors[i] = managedObject.getObject();
					managedObjectStates[i] = managedObject;
				} else {
					interceptors[i] = this.ivInterceptorClasses[i].newInstance();
				}

				try {
					InjectionTarget[] targetsForClass = this.ivInterceptorInjectionTargets[i];
					if (targetsForClass.length > 0) {
						InjectionTarget[] arr$ = targetsForClass;
						len$ = targetsForClass.length;

						for (int i$ = 0; i$ < len$; ++i$) {
							InjectionTarget oneTarget = arr$[i$];
							injectionEngine.inject(interceptors[i], oneTarget, targetContext);
						}
					}
				} catch (Throwable var15) {
					FFDCFilter.processException(var15, CLASS_NAME + "createInterceptorInstances", "229", this);
					if (isTraceOn && tc.isDebugEnabled()) {
						Tr.debug(tc, "Injection failure", var15);
					}

					throw ExceptionUtil.EJBException("Injection failure", var15);
				}
			}
		}

		if (isTraceOn && tc.isEntryEnabled()) {
			Tr.exit(tc, "createInterceptorInstances");
		}

	}

	public String toString() {
		StringBuffer buffer = new StringBuffer("Interceptor MetaData:\n");
		int b;
		int i$;
		if (this.ivInterceptorClasses != null) {
			buffer.append("     Interceptor classes:\n");
			Class[] arr$ = this.ivInterceptorClasses;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				Class<?> oneClass = arr$[i$];
				buffer.append("          " + oneClass.getName() + "\n");
			}
		} else {
			buffer.append("     Interceptor classes: NONE\n");
		}

		InterceptorProxy[] arr$;
		InterceptorProxy oneProxy;
		if (this.ivPostConstructInterceptors != null) {
			buffer.append("     PostConstruct interceptor methods:\n");
			arr$ = this.ivPostConstructInterceptors;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				oneProxy = arr$[i$];
				buffer.append("          " + oneProxy.toString() + "\n");
			}
		} else {
			buffer.append("     PostConstruct interceptor methods: NONE");
		}

		if (this.ivPostActivateInterceptors != null) {
			buffer.append("     PostActivate interceptor methods:\n");
			arr$ = this.ivPostActivateInterceptors;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				oneProxy = arr$[i$];
				buffer.append("          " + oneProxy.toString() + "\n");
			}
		} else {
			buffer.append("     PostActivate interceptor methods: NONE");
		}

		if (this.ivPrePassivateInterceptors != null) {
			buffer.append("     PrePassivate interceptor methods:\n");
			arr$ = this.ivPrePassivateInterceptors;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				oneProxy = arr$[i$];
				buffer.append("          " + oneProxy.toString() + "\n");
			}
		} else {
			buffer.append("     PrePassivate interceptor methods: NONE");
		}

		if (this.ivPreDestroyInterceptors != null) {
			buffer.append("     PreDestroy interceptor methods:\n");
			arr$ = this.ivPreDestroyInterceptors;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				oneProxy = arr$[i$];
				buffer.append("          " + oneProxy.toString() + "\n");
			}
		} else {
			buffer.append("     PreDestroy interceptor methods: NONE");
		}

		if (this.ivBeanLifecycleMethods != null) {
			buffer.append("     BeanLifecycle methods:\n");
			Method[] arr$ = this.ivBeanLifecycleMethods;
			b = arr$.length;

			for (i$ = 0; i$ < b; ++i$) {
				Method oneMethod = arr$[i$];
				if (oneMethod != null) {
					buffer.append("          " + oneMethod.getName() + "\n");
				} else {
					buffer.append("      Lifecycle method was null.\n");
				}
			}
		} else {
			buffer.append("     BeanLifeCycle methods: NONE");
		}

		if (this.ivInterceptorInjectionTargets != null) {
			buffer.append("     InjectionTargets for interceptor classes:");

			for (int a = 0; a < this.ivInterceptorInjectionTargets.length; ++a) {
				buffer.append("          Interceptor class: " + a);

				for (b = 0; b < this.ivInterceptorInjectionTargets[a].length; ++b) {
					buffer.append("               " + this.ivInterceptorInjectionTargets[a][b]);
				}
			}
		} else {
			buffer.append("     InjectionTargets for interceptor classes: NONE");
		}

		return buffer.toString();
	}

	static {
		tc = Tr.register(CLASS_NAME, "EJBContainer", "com.ibm.ejs.container.container");
	}
}