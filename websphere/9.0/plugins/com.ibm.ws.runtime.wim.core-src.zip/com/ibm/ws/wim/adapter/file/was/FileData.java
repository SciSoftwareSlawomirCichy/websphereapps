package com.ibm.ws.wim.adapter.file.was;

import com.ibm.websphere.management.AdminContext;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.EntityHasDescendantsException;
import com.ibm.websphere.wim.exception.EntityNotFoundException;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.InvalidArgumentException;
import com.ibm.websphere.wim.exception.InvalidEntityTypeException;
import com.ibm.websphere.wim.exception.WIMApplicationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.ras.WIMTraceHelper;
import com.ibm.websphere.wim.util.PasswordUtil;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.sm.workspace.RepositoryContext;
import com.ibm.ws.sm.workspace.WorkSpace;
import com.ibm.ws.sm.workspace.WorkSpaceManagerFactory;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.SchemaManager;
import com.ibm.ws.wim.adapter.file.was.FileData.EntityRefData;
import com.ibm.ws.wim.management.DynamicReloadManager;
import com.ibm.ws.wim.management.EventDataWrapper;
import com.ibm.ws.wim.util.DataGraphHelper;
import com.ibm.ws.wim.util.DomainManagerUtils;
import com.ibm.ws.wim.util.PasswordEncryptionUtil;
import com.ibm.xml.crypto.util.Base64;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.directory.Attribute;
import javax.naming.directory.ModificationItem;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.Resource.Factory;

public class FileData {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final Logger msgLogger;
	private static final String DEFAULT_FILE_NAME = "fileRegistry.xml";
	private static final int ENTITY_TYPE = 0;
	private static final int IDENTIFIER_TYPE = 1;
	private static final int MULTI_VALUED = 0;
	private static final int SINGLE_VALUED = 1;
	public static final int EVENT_DATA_SIZE = 3;
	private String sessionId;
	private String baseDir;
	private String fileName;
	private String absoluteFileName;
	private String fileID;
	private List baseEntries;
	private Object[] handbackObjectArray;
	private Map entityRDN;
	private Map entityDN2DO;
	private Map entityID2DN;
	private Map entityReference;
	private DataGraph entityDG;
	private DataObject entityRoot;
	private int numOfEntities;
	private SchemaManager schemaMgr;
	private boolean caseSensitive;
	private String sFileSep;
	private String domainID;
	private final AccountLockoutCacheConfig accountLockoutCacheConfig;
	SimpleDateFormat sdf;

	public FileData(String var1, String var2, String var3, Map var4, String var5, List var6, boolean var7)
			throws WIMException {
		this(var1, var2, var3, var4, var5, var6, var7, (String) null);
	}

	public FileData(String var1, String var2, String var3, Map var4, String var5, List var6, boolean var7, String var8)
			throws WIMException {
		this(var1, var2, var3, var4, var5, var6, var7, var8, (AccountLockoutCacheConfig) null);
	}

	public FileData(String var1, String var2, String var3, Map var4, String var5, List var6, boolean var7, String var8,
			AccountLockoutCacheConfig var9) throws WIMException {
		this.handbackObjectArray = new Object[3];
		this.entityDN2DO = new ConcurrentHashMap();
		this.entityID2DN = new ConcurrentHashMap();
		this.entityReference = new ConcurrentHashMap();
		this.caseSensitive = false;
		this.sFileSep = File.separator;
		this.domainID = null;
		this.sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.ENGLISH);
		boolean var11 = trcLogger.isLoggable(Level.FINER);
		if (var11) {
			trcLogger.entering(CLASSNAME, "<init>",
					"sessionId=" + var1 + ", baseDir=" + var2 + ", fileName=" + var3 + ", fileID=" + var5
							+ ", baseEntries=" + var6 + ", caseSensitive=" + var7 + ", domainID=" + var8
							+ "\n entityRDN=" + var4);
		}

		this.sessionId = var1;
		this.baseDir = var2;
		this.entityRDN = var4;
		this.fileID = var5;
		this.baseEntries = var6;
		this.caseSensitive = var7;
		this.domainID = var8;
		this.accountLockoutCacheConfig = var9;
		if (var3 != null && var3.trim().length() != 0) {
			this.fileName = var3;
		} else {
			this.fileName = "fileRegistry.xml";
		}

		if (!var2.endsWith(this.sFileSep) && !var2.endsWith("/") && !var2.endsWith("\\")) {
			this.absoluteFileName = var2 + this.sFileSep + this.fileName;
		} else {
			this.absoluteFileName = var2 + this.fileName;
		}

		this.handbackObjectArray[0] = var5;
		Iterator var12 = var4.keySet().iterator();

		while (true) {
			while (var12.hasNext()) {
				String var13 = (String) var12.next();
				Vector var14;
				if (isSuperType("Group", var13)) {
					var14 = new Vector(1);
					var14.add(new EntityRefData(this, "members", 0, 0));
					this.entityReference.put(var13, var14);
				} else if (isSuperType("Person", var13) || isSuperType("PersonAccount", var13)) {
					var14 = new Vector(2);
					var14.add(new EntityRefData(this, "manager", 0, 1));
					var14.add(new EntityRefData(this, "secretary", 0, 1));
					this.entityReference.put(var13, var14);
				}
			}

			if (var11) {
				trcLogger.exiting(CLASSNAME, "<init>",
						"sessionId=" + this.sessionId + ", baseDir=" + this.baseDir + ", fileName=" + this.fileName
								+ ", absoluteFileName=" + this.absoluteFileName + ", fileID=" + this.fileID
								+ ", baseEntries=" + this.baseEntries + ", caseSensitive=" + this.caseSensitive
								+ "\n entityRDN=" + this.entityRDN + "\n entityReference=" + this.entityReference);
			}

			return;
		}
	}

	private RepositoryContext extractFileInWorkspaceContext(String var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "extractFileInWorkspaceContext", "sessionId=" + var1);
		}

		WorkSpace var4 = WorkSpaceManagerFactory.getManager().getWorkSpace(var1);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "getWorkspace",
					"UserPath: " + var4.getUserPath() + ", Path: " + var4.getPath() + ", RootContextPath-Name: "
							+ var4.getRootContext().getName() + ", RootContextPath-Path: "
							+ var4.getRootContext().getPath() + ", RootContextPath-URI: "
							+ var4.getRootContext().getURI());
		}

		RepositoryContext var5 = null;
		if (DomainManagerUtils.isAdminDomain()) {
			var5 = var4.findContext("cells/" + DynamicReloadManager.getCellName());
		} else {
			var5 = var4.findContext(DomainManagerUtils.RELATIVE_WIM_CONFIG_DOMAIN_PATH + this.sFileSep
					+ DomainManagerUtils.getDomainName() + this.sFileSep);
		}

		if (var5 != null) {
			if (var5.isAvailable(this.fileName)) {
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "extractFileInWorkspaceContext",
							"File " + this.fileName + " is available in the context.");
				}

				var5.extract(this.fileName, false);
			} else {
				String var6 = this.absoluteFileName;
				File var7 = new File(var6);
				if (!DomainManagerUtils.isAdminAgent() && var7.exists() && var7.canRead()) {
					return null;
				}

				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "extractFileInWorkspaceContext",
							"File " + this.fileName + " is unavailable and hence creating it.");
				}

				Factory var8 = var4.getResourceFactoryRegistry().getFactory(URI.createURI(this.fileName));
				Resource var9 = var8.createResource(URI.createURI(this.fileName));
				boolean var10 = var5.getResourceSet().getResources().add(var9);
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "extractFileInWorkspaceContext", "resourceAdded=" + var10);
				}
			}
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "extractFileInWorkspaceContext", "context=" + var5);
		}

		return var5;
	}

	public synchronized void load(DataObject var1) throws WIMException {
		boolean var3 = trcLogger.isLoggable(Level.FINER);
		if (var3) {
			trcLogger.entering(CLASSNAME, "load", "domainID: " + this.domainID);
		}

		String var4 = this.absoluteFileName;
		HashMap var5 = null;
		DataObject var8;
		if (var1 == null) {
			try {
				if (this.sessionId != null) {
					if (var3) {
						trcLogger.logp(Level.FINER, CLASSNAME, "load", "loading for session=" + this.sessionId);
					}

					RepositoryContext var6 = this.extractFileInWorkspaceContext(this.sessionId);
					if (var6 != null) {
						var4 = var6.getPath() + File.separator + this.fileName;
						if (var3) {
							trcLogger.logp(Level.FINER, CLASSNAME, "load", "Loading file: " + var4);
						}

						this.entityDG = FileUtils.loadFileAsDataGraph(var4);
					} else {
						if (var3) {
							trcLogger.logp(Level.FINER, CLASSNAME, "load", "Loading file: " + var4);
						}

						this.entityDG = FileUtils.loadFileAsDataGraph(var4);
					}
				} else {
					if (var3) {
						trcLogger.logp(Level.FINER, CLASSNAME, "load", "Loading file: " + var4);
					}

					this.entityDG = FileUtils.loadFileAsDataGraph(var4);
				}
			} catch (FileNotFoundException var14) {
				trcLogger.logp(Level.FINER, CLASSNAME, "load", var14.getMessage());
			} catch (Exception var15) {
				throw new InitializationException("ERROR_READING_FILE",
						WIMMessageHelper.generateMsgParms(var4, var15.getMessage()), Level.SEVERE, CLASSNAME, "load",
						var15);
			}
		} else {
			if (this.isAccountLockoutEnabled()) {
				if (var3) {
					trcLogger.logp(Level.FINER, CLASSNAME, "load", "Saving off DNs for an account lockout check.");
				}

				var5 = new HashMap(this.entityDN2DO.size());

				try {
					Iterator var17 = this.entityDN2DO.entrySet().iterator();

					while (var17.hasNext()) {
						Entry var7 = (Entry) var17.next();
						var8 = (DataObject) var7.getValue();
						if (!isSuperType("Group", var8.getType().getName())) {
							var5.put((String) var7.getKey(), var8.getBytes("password"));
						}
					}
				} catch (Exception var16) {
					FFDCFilter.processException(var16, CLASSNAME + "." + "load", "387");
					if (trcLogger.isLoggable(Level.FINE)) {
						trcLogger.logp(Level.FINE, CLASSNAME, "WIM_SPI load",
								"Exception while trying to create list of DNs/Pwds to check for locked accounts",
								var16);
					}

					msgLogger.logp(Level.SEVERE, CLASSNAME, "load", "GENERIC",
							WIMMessageHelper.generateMsgParms(var16));
				}
			}

			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "load",
						"Refreshing the cache with new root DO. Previous numOfEntities " + this.numOfEntities);
			}

			this.entityDG = var1.getDataGraph();
			trcLogger.logp(Level.FINEST, CLASSNAME, "load", "Loaded Data:" + this.entityDG);
		}

		this.entityRoot = null;
		this.numOfEntities = 0;
		this.entityID2DN.clear();
		this.entityDN2DO.clear();
		if (this.entityDG != null) {
			this.entityRoot = this.entityDG.getRootObject().getDataObject("Root");
			List var18 = this.entityRoot.getList("entities");
			this.numOfEntities = var18.size();
			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "load", "Number of entities=" + this.numOfEntities);
			}

			String var10;
			for (int var19 = 0; var19 < this.numOfEntities; ++var19) {
				var8 = (DataObject) var18.get(var19);
				String var9 = this.getEntityID(var8);
				var10 = var8.getString("identifier/uniqueName");
				this.entityID2DN.put(var9, var10);
				this.entityDN2DO.put(var10, var8);
			}

			if (trcLogger.isLoggable(Level.FINEST)) {
				trcLogger.logp(Level.FINEST, CLASSNAME, "load",
						"Data in File Registry=\n" + WIMTraceHelper.printDataGraph(this.entityDG));
			}

			if (this.isAccountLockoutEnabled() && var5 != null) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "load",
							"Comparing all DN passwords to see if we need to clear the account lockout cache.");
				}

				HashSet var20 = new HashSet();
				Iterator var21 = var5.entrySet().iterator();

				while (var21.hasNext()) {
					Entry var22 = (Entry) var21.next();
					var10 = (String) var22.getKey();
					DataObject var11 = (DataObject) this.entityDN2DO.get(var10);
					if (var11 == null) {
						if (trcLogger.isLoggable(Level.FINEST)) {
							trcLogger.logp(Level.FINEST, CLASSNAME, "load",
									"DN, " + var10 + ", is missing from new fileRegistry");
						}

						var20.add(var10);
					} else {
						byte[] var12 = (byte[]) var22.getValue();
						byte[] var13 = var11.getBytes("password");
						if (!Arrays.equals(var12, var13)) {
							if (trcLogger.isLoggable(Level.FINEST)) {
								trcLogger.logp(Level.FINEST, CLASSNAME, "load", "DN, " + var10 + " has a changed pwd");
							}

							var20.add(var10);
						}
					}
				}

				var5 = null;
				this.accountLockoutCacheConfig.clearUsersFromCache(var20, "updated fileRegistry from dmgr");
			}
		} else {
			if (var3) {
				trcLogger.logp(Level.FINER, CLASSNAME, "load",
						"No data exists in the file registry or root DO is empty.");
			}

			if (this.isAccountLockoutEnabled() && var5 != null) {
				if (trcLogger.isLoggable(Level.FINEST)) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "load", "Remove all DNs from the account lockout cache.");
				}

				this.accountLockoutCacheConfig.clearUsersFromCache(var5.keySet(),
						"synchronized file from dmgr, all users removed");
			}
		}

	}

	public synchronized void addEntity(String var1, DataObject var2, boolean var3) throws WIMException {
		boolean var5 = trcLogger.isLoggable(Level.FINER);
		if (var5) {
			trcLogger.entering(CLASSNAME, "addEntity", var1);
		}

		if (trcLogger.isLoggable(Level.FINEST)) {
			trcLogger.logp(Level.FINER, CLASSNAME, "addEntity", "inputDO=" + WIMTraceHelper.printDataObject(var2));
		}

		String var6 = null;

		try {
			if (this.entityDG == null) {
				if (var5) {
					trcLogger.logp(Level.FINER, CLASSNAME, "addEntity",
							"Creating first entity in the file: entityType=" + var1);
				}

				this.entityRoot = SchemaManager.singleton().createRootDataObject();
				this.entityDG = this.entityRoot.getDataGraph();
			}

			this.entityRoot.getList("entities").add(var2);
			++this.numOfEntities;
			String var7 = this.getEntityID(var2);
			var6 = var2.getString("identifier/uniqueName");
			this.entityID2DN.put(var7, var6);
			this.entityDN2DO.put(var6, var2);
			if (var5) {
				trcLogger.logp(Level.FINER, CLASSNAME, "addEntity", "Number of entities=" + this.numOfEntities);
			}

			if (var3) {
				this.saveEntities();
			}
		} catch (WIMException var9) {
			throw var9;
		} catch (Exception var10) {
			WIMApplicationException var8 = new WIMApplicationException("ENTITY_CREATE_FAILED",
					WIMMessageHelper.generateMsgParms(var6, var10.getMessage()), Level.SEVERE, CLASSNAME, "addEntity",
					var10);
			var8.setRootErrorSource(this.fileID);
		}

		if (var5) {
			trcLogger.exiting(CLASSNAME, "addEntity", "Added " + var1 + ":" + var6);
		}

	}

	public String getEntityID(DataObject var1) {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getEntityID", "entity: " + WIMTraceHelper.printDataGraph(var1));
		}

		String var4 = var1.getString("identifier/externalId");
		if (var4 == null) {
			var4 = var1.getString("identifier/uniqueId");
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "getEntityID", "ID: " + var4);
		}

		return var4;
	}

	public String getIDFromIdentifier(DataObject var1) {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getIDFromIdentifier", "identifier: " + WIMTraceHelper.printDataGraph(var1));
		}

		String var4 = var1.getString("externalId");
		if (var4 == null) {
			var4 = var1.getString("externalId");
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "getIDFromIdentifier", "ID: " + var4);
		}

		return var4;
	}

	public static boolean isSuperType(String var0, String var1) throws WIMException {
		return var0.equals(var1) || SchemaManager.singleton().isSuperType(var0, var1);
	}

	public void addMemberDNToGroup(String var1, String var2, boolean var3) throws Exception {
		boolean var5 = trcLogger.isLoggable(Level.FINEST);
		if (var5) {
			trcLogger.entering(CLASSNAME, "addMemberDNToGroup", "adding member " + var2 + " to group " + var1);
		}

		DataObject var6 = this.getByDN(var1);
		boolean var7 = this.checkGroupMembership(var6, var2, 1, 0);
		if (!var7) {
			DataObject var8 = this.getByDN(var2);
			DataGraphHelper.copyDataObject(var6.createDataObject("members"), var8, (List) null, (List) null,
					FileAdapter.IDENTIFIER_REF);
			var6.set("modifyTimestamp", this.getDateString());
			if (var3) {
				this.saveEntities();
			}
		}

		if (var5) {
			trcLogger.exiting(CLASSNAME, "addMemberDNToGroup", "member added=" + !var7);
		}

	}

	public void removeMemberDNFromGroup(String var1, String var2, boolean var3) throws Exception {
		boolean var5 = trcLogger.isLoggable(Level.FINEST);
		if (var5) {
			trcLogger.entering(CLASSNAME, "removeMemberDNFromGroup", var1);
		}

		DataObject var6 = this.getByDN(var1);
		boolean var7 = false;
		List var8 = var6.getList("members");

		for (int var9 = 0; var9 < var8.size(); ++var9) {
			DataObject var10 = (DataObject) var8.get(var9);
			String var11 = var10.getString("identifier/uniqueName");
			if (this.normalizedStringsAreEqual(var11, var2)) {
				var10.delete();
				var6.set("modifyTimestamp", this.getDateString());
				var7 = true;
				if (var3) {
					this.saveEntities();
				}
				break;
			}
		}

		if (var5) {
			trcLogger.exiting(CLASSNAME, "removeMemberDNFromGroup", "member deleted=" + var7);
		}

	}

	public List getGroupsForEntity(String var1, FileXPathHelper var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINEST);
		if (var4) {
			trcLogger.entering(CLASSNAME, "getGroupsForEntity", var1);
		}

		ArrayList var5 = new ArrayList();
		Iterator var6 = this.entityDN2DO.keySet().iterator();

		while (true) {
			while (true) {
				String var7;
				DataObject var8;
				do {
					do {
						if (!var6.hasNext()) {
							if (var4) {
								trcLogger.exiting(CLASSNAME, "getGroupsForEntity", "returning:" + var5);
							}

							return var5;
						}

						var7 = (String) var6.next();
						var8 = this.getByDN(var7);
					} while (!isSuperType("Group", var8.getType().getName()));
				} while (var2 != null && !var2.evaluate(var8));

				List var9 = var8.getList("members");

				for (int var10 = 0; var10 < var9.size(); ++var10) {
					DataObject var11 = (DataObject) var9.get(var10);
					String var12 = var11.getString("identifier/uniqueName");
					if (this.normalizedStringsAreEqual(var1, var12)) {
						var5.add(var7);
						break;
					}
				}
			}
		}
	}

	public boolean checkGroupMembership(DataObject var1, int var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINEST);
		if (var4) {
			trcLogger.entering(CLASSNAME, "checkGroupMembership(entity,level)", "level=" + var2);
		}

		boolean var5 = false;
		String var6 = null;
		String var7 = null;
		String var8;
		if (isSuperType("Group", var1.getType().getName())) {
			var6 = var1.getString("identifier/uniqueName");
			if (var6 == null) {
				var8 = this.getEntityID(var1);
				var6 = this.getDNForID(var8);
			}

			var7 = var1.getString("members.0/identifier/uniqueName");
			if (var7 == null) {
				var8 = this.getEntityID(var1.getDataObject("members.0"));
				var7 = this.getDNForID(var8);
			}
		} else {
			var7 = var1.getString("identifier/uniqueName");
			if (var7 == null) {
				var8 = this.getEntityID(var1);
				var7 = this.getDNForID(var8);
			}

			var6 = var1.getString("groups.0/identifier/uniqueName");
			if (var6 == null) {
				var8 = this.getEntityID(var1.getDataObject("groups.0"));
				var6 = this.getDNForID(var8);
			}
		}

		DataObject var9 = this.getByDN(var6);
		this.getByDN(var7);
		if (var4) {
			trcLogger.logp(Level.FINEST, CLASSNAME, "checkGroupMembership(entity,level)", "memberDN=" + var7);
		}

		var5 = this.checkGroupMembership(var9, var7, var2, 0);
		if (var4) {
			trcLogger.exiting(CLASSNAME, "checkGroupMembership(entity,level)", "inGroup=" + var5);
		}

		return var5;
	}

	private boolean checkGroupMembership(DataObject var1, String var2, int var3, int var4) throws Exception {
		boolean var6 = trcLogger.isLoggable(Level.FINEST);
		if (var6) {
			trcLogger.entering(CLASSNAME, "checkGroupMembership",
					"currentLevel=" + var4 + ", groupDN=" + var1.getString("identifier/uniqueName"));
		}

		int var7 = var4 + 1;
		boolean var8 = false;
		if (isSuperType("Group", var1.getType().getName())) {
			List var9 = var1.getList("members");

			int var10;
			DataObject var11;
			for (var10 = 0; var10 < var9.size(); ++var10) {
				var11 = (DataObject) var9.get(var10);
				String var12 = var11.getString("identifier/uniqueName");
				if (this.normalizedStringsAreEqual(var12, var2)) {
					var8 = true;
					break;
				}
			}

			if (!var8 && (var3 == 0 || var7 < var3)) {
				var9 = var1.getList("members");

				for (var10 = 0; var10 < var9.size(); ++var10) {
					var11 = (DataObject) var9.get(var10);
					DataObject var13 = this.getByDN(var11.getString("identifier/uniqueName"));
					if (isSuperType("Group", var13.getType().getName())) {
						var8 |= this.checkGroupMembership(var13, var2, var3, var7);
					}
				}
			}
		}

		if (var6) {
			trcLogger.exiting(CLASSNAME, "checkGroupMembership", "inGroup=" + var8);
		}

		return var8;
	}

	public boolean accountExists(String var1, String var2) throws Exception {
		boolean var3 = false;
		Iterator var4 = this.entityDN2DO.keySet().iterator();

		while (var4.hasNext()) {
			String var5 = (String) var4.next();
			DataObject var6 = this.getByDN(var5);
			if (isSuperType("LoginAccount", var6.getType().getName())
					&& this.normalizedStringsAreEqual(var1, var6.getString(var2))) {
				var3 = true;
				break;
			}
		}

		return var3;
	}

	public boolean mustExist(String var1, String var2) throws EntityNotFoundException {
		if (!this.normalizedBaseEntriesAreEqual(var2) && !this.exists(var1, var2)) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var2), Level.SEVERE,
					CLASSNAME, "mustExist");
		} else {
			return true;
		}
	}

	public boolean groupMustExist(String var1, String var2) throws Exception {
		if (this.mustExist(var1, var2)) {
			DataObject var3 = null;
			if (var1 != null) {
				var3 = this.getByID(var1);
			} else {
				var3 = this.getByDN(var2);
			}

			if (!isSuperType("Group", var3.getType().getName())) {
				String var4 = var1 != null ? var1 : var2;
				throw new InvalidEntityTypeException("ENTITY_IS_NOT_A_GROUP", WIMMessageHelper.generateMsgParms(var4),
						Level.SEVERE, CLASSNAME, "groupMustExist");
			}
		}

		return true;
	}

	public boolean exists(String var1, String var2) {
		boolean var4 = trcLogger.isLoggable(Level.FINEST);
		if (var4) {
			trcLogger.entering(CLASSNAME, "exists", "uniqueId: " + var1 + ", uniqueName: " + var2);
		}

		boolean var5 = false;
		if (var1 != null && this.entityID2DN.containsKey(var1)
				|| var2 != null && this.containsNormalizedKey(this.entityDN2DO, var2) != null) {
			var5 = true;
		}

		if (var4) {
			trcLogger.entering(CLASSNAME, "exists", "exists? " + var5);
		}

		return var5;
	}

	public List search(String var1, FileXPathHelper var2, boolean var3, boolean var4) throws Exception {
		boolean var6 = trcLogger.isLoggable(Level.FINEST);
		if (var6) {
			trcLogger.entering(CLASSNAME, "search",
					var1 + ", searchStr=" + var2.getNode() + " searchAll=" + var3 + " returnSubType=" + var4);
		}

		Vector var7 = new Vector();
		if (var2.getPrincipalNameDN() != null) {
			DataObject var10 = this.getByDN(var2.getPrincipalNameDN());
			if (var10 != null) {
				var7.add(var10);
			}

			if (var6) {
				trcLogger.exiting(CLASSNAME, "search",
						"Number of matched entities (getByDN) =" + var7.size() + " out of " + this.entityDN2DO.size());
			}

			return var7;
		} else {
			Iterator var8 = this.entityDN2DO.values().iterator();

			while (var8.hasNext()) {
				DataObject var9 = (DataObject) var8.next();
				if ((var1.equals(var9.getType().getName()) || var4 && isSuperType(var1, var9.getType().getName()))
						&& var2.evaluate(var9)) {
					var7.add(var9);
					if (!var3) {
						break;
					}
				}
			}

			if (var6) {
				trcLogger.exiting(CLASSNAME, "search",
						"Number of matched entities=" + var7.size() + " out of " + this.entityDN2DO.size());
			}

			return var7;
		}
	}

	public List search(List var1, FileXPathHelper var2, boolean var3, boolean var4) throws Exception {
		boolean var6 = trcLogger.isLoggable(Level.FINEST);
		if (var6) {
			trcLogger.entering(CLASSNAME, "search(List)", var1 + ", searchStr=" + var2.getNode());
		}

		Vector var7 = new Vector();
		if (var2.getPrincipalNameDN() != null) {
			DataObject var13 = this.getByDN(var2.getPrincipalNameDN());
			if (var13 != null) {
				var7.add(var13);
			}

			if (var6) {
				trcLogger.exiting(CLASSNAME, "search(List)",
						"Number of matched entities (getByDN) =" + var7.size() + " out of " + this.entityDN2DO.size());
			}

			return var7;
		} else {
			Iterator var8 = this.entityDN2DO.values().iterator();

			while (var8.hasNext()) {
				DataObject var9 = (DataObject) var8.next();
				boolean var10 = false;

				for (int var11 = 0; var11 < var1.size(); ++var11) {
					String var12 = (String) var1.get(var11);
					if (var12.equals(var9.getType().getName())
							|| var4 && isSuperType(var12, var9.getType().getName())) {
						var10 = true;
						break;
					}
				}

				if (var10 && var2.evaluate(var9)) {
					var7.add(var9);
					if (!var3) {
						break;
					}
				}
			}

			if (var6) {
				trcLogger.exiting(CLASSNAME, "search(List)",
						"Number of matched entities=" + var7.size() + " out of " + this.entityDN2DO.size());
			}

			return var7;
		}
	}

	public DataObject get(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINEST);
		if (var4) {
			trcLogger.entering(CLASSNAME, "get", var1 + ":" + var2);
		}

		DataObject var5 = this.entityDG != null ? this.entityRoot.getDataObject(var2) : null;
		if (var4) {
			trcLogger.exiting(CLASSNAME, "get", WIMTraceHelper.printDataObject(var5));
		}

		return var5;
	}

	public DataObject getByDN(String var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getByDN(DN)", "DN:" + var1);
		}

		DataObject var4 = (DataObject) this.entityDN2DO.get(var1);
		if (var4 == null && !this.caseSensitive) {
			String var5 = this.containsNormalizedKey(this.entityDN2DO, var1);
			if (var5 != null) {
				var4 = (DataObject) this.entityDN2DO.get(var5);
			}
		}

		if (var4 == null) {
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "getByDN",
						"Did not find " + var1 + " Number of possible keys " + this.entityDN2DO.size());
			}

			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1), CLASSNAME,
					"getByDN");
		} else {
			if (var3) {
				trcLogger.exiting(CLASSNAME, "getByDN(DN)", WIMTraceHelper.printDataGraph(var4));
			}

			return var4;
		}
	}

	public String getDNForID(String var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getDNForID(ID)", "ID:" + var1);
		}

		String var4 = (String) this.entityID2DN.get(var1);
		if (var4 == null) {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1), Level.FINE,
					CLASSNAME, "getDNForID");
		} else {
			if (var3) {
				trcLogger.exiting(CLASSNAME, "getDNForID(ID)", "DN: " + var4);
			}

			return var4;
		}
	}

	public DataObject getByID(String var1) throws Exception {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getByID(ID)", "ID:" + var1);
		}

		DataObject var4 = this.getByDN((String) this.entityID2DN.get(var1));
		if (var3) {
			trcLogger.exiting(CLASSNAME, "getByID(ID)", WIMTraceHelper.printDataGraph(var4));
		}

		return var4;
	}

	public Set getImmediateDescendants(String var1) {
		boolean var3 = trcLogger.isLoggable(Level.FINEST);
		if (var3) {
			trcLogger.entering(CLASSNAME, "getImmediateDescendants(DN)", "DN:" + var1);
		}

		HashSet var4 = new HashSet();
		if (this.entityDG != null) {
			List var5 = this.entityRoot.getList("entities");
			if (var5 != null) {
				for (int var6 = 0; var6 < var5.size(); ++var6) {
					DataObject var7 = (DataObject) var5.get(var6);
					DataObject var8 = var7.getDataObject("parent");
					if (this.identifierMatches((String) null, var1, var8, 0)) {
						var4.add(var7.getString("identifier/uniqueName"));
					}
				}
			}
		}

		if (var3) {
			trcLogger.exiting(CLASSNAME, "getImmediateDescendants(DN)", "Descendants:" + var4);
		}

		return var4;
	}

	public synchronized List deleteEntity(String var1, boolean var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINEST);
		if (var4) {
			trcLogger.entering(CLASSNAME, "deleteEntity(DN,save)", "DN:" + var1 + " #save=" + var2);
		}

		ArrayList var5 = null;
		DataObject var6 = (DataObject) this.entityDN2DO.remove(var1);
		String var7;
		if (var6 == null && !this.caseSensitive) {
			var7 = this.containsNormalizedKey(this.entityDN2DO, var1);
			if (var7 != null) {
				var6 = (DataObject) this.entityDN2DO.remove(var7);
			}
		}

		if (var6 != null) {
			var5 = new ArrayList();
			var5.add(var6.getType().getName());
			var7 = this.getEntityID(var6);
			var5.add(var7);
			this.entityID2DN.remove(var7);
			var6.delete();
			--this.numOfEntities;
			if (var2) {
				this.saveEntities();
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "deleteEntity(DN,save)",
						"deleted " + var5 + ", numOfEntities=" + this.numOfEntities);
			}

			return var5;
		} else {
			throw new EntityNotFoundException("ENTITY_NOT_FOUND", WIMMessageHelper.generateMsgParms(var1), CLASSNAME,
					"deleteEntity(DN,save)");
		}
	}

	private DataObject hasReference(DataObject var1, EntityRefData var2, String var3, String var4) {
		DataObject var5 = null;
		String var6 = var2.getRefProperty();
		int var7 = var2.getValueType();
		int var8 = var2.getEntityType();
		if (var7 == 0) {
			List var9 = var1.getList(var6);
			if (var9 == null) {
				return var5;
			}

			for (int var10 = 0; var10 < var9.size(); ++var10) {
				DataObject var11 = (DataObject) var9.get(var10);
				if (this.identifierMatches(var3, var4, var11, var8)) {
					var5 = var11;
					break;
				}
			}
		} else {
			DataObject var12 = var1.getDataObject(var6);
			if (this.identifierMatches(var3, var4, var12, var8)) {
				var5 = var12;
			}
		}

		return var5;
	}

	public synchronized void cleanReferences(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINEST);
		if (var4) {
			trcLogger.entering(CLASSNAME, "cleanReferences(ID, DN)", "ID:" + var1 + ", #DN:" + var2);
		}

		HashSet var5 = new HashSet();
		boolean var6 = false;
		List var7 = this.entityRoot.getList("entities");
		if (var7 != null && var7.size() != 0) {
			for (int var8 = 0; var8 < var7.size(); ++var8) {
				DataObject var9 = (DataObject) var7.get(var8);
				Vector var10 = (Vector) this.entityReference.get(var9.getType().getName());
				if (var10 != null) {
					for (int var11 = 0; var11 < var10.size(); ++var11) {
						DataObject var12 = this.hasReference(var9, (EntityRefData) var10.get(var11), var1, var2);
						if (var12 != null) {
							var6 = true;
							var12.delete();
							var5.add(var9.getString("identifier/uniqueName"));
							var9.set("modifyTimestamp", this.getDateString());
						}
					}
				}
			}

			if (var6) {
				this.saveEntities();
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "cleanReferences(ID, DN)", "References deleted from:" + var5);
			}

		} else {
			if (var4) {
				trcLogger.exiting(CLASSNAME, "cleanReferences(ID, DN)", "No entities in the repository");
			}

		}
	}

	public synchronized void changeReferences(String var1, String var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINEST);
		if (var4) {
			trcLogger.entering(CLASSNAME, "changeReferences(oldDN,newDN)", "oldDN:" + var1 + ", #newDN:" + var2);
		}

		HashSet var5 = new HashSet();
		List var6 = this.entityRoot.getList("entities");
		if (var6 != null && var6.size() != 0) {
			for (int var7 = 0; var7 < var6.size(); ++var7) {
				DataObject var8 = (DataObject) var6.get(var7);
				Vector var9 = (Vector) this.entityReference.get(var8.getType().getName());
				if (var9 != null) {
					for (int var10 = 0; var10 < var9.size(); ++var10) {
						DataObject var11 = this.hasReference(var8, (EntityRefData) var9.get(var10), (String) null,
								var1);
						if (var11 != null) {
							if (var11.getType().getName().equals("identifier")) {
								var11.setString("uniqueName", var2);
								var11.setString("externalName", var2);
							} else {
								var11.setString("identifier/uniqueName", var2);
								var11.setString("identifier/externalName", var2);
							}

							var5.add(var8.getString("identifier/uniqueName"));
							var8.set("modifyTimestamp", this.getDateString());
						}
					}
				}
			}

			if (var4) {
				trcLogger.exiting(CLASSNAME, "changeReferences(oldDN,newDN)", "References updated for:" + var5);
			}

		} else {
			if (var4) {
				trcLogger.exiting(CLASSNAME, "changeReferences(oldDN,newDN)", "No entities in the repository");
			}

		}
	}

	public void modifyProperties(String var1, List var2) throws Exception {
		boolean var4 = trcLogger.isLoggable(Level.FINEST);
		if (var4) {
			trcLogger.entering(CLASSNAME, "modifyProperties(DN,modItems)", "DN:" + var1);
		}

		DataObject var5 = this.getByDN(var1);

		for (int var6 = 0; var6 < var2.size(); ++var6) {
			ModificationItem var7 = (ModificationItem) var2.get(var6);
			int var8 = var7.getModificationOp();
			Attribute var9 = var7.getAttribute();
			String var10 = var9.getID();
			if (var8 == 2 || var8 == 3) {
				if (var4) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "modifyProperties(DN,modItems)",
							"removing property:" + var10);
				}

				var5.unset(var10);
			}

			if (var8 == 2 || var8 == 1) {
				if (var4) {
					trcLogger.logp(Level.FINEST, CLASSNAME, "modifyProperties(DN,modItems)",
							"adding property:" + var10);
				}

				Object var11 = var9.get();
				if (var11 instanceof List) {
					List var12 = (List) var11;

					for (int var13 = 0; var13 < var12.size(); ++var13) {
						if (var12.get(var13) instanceof DataObject) {
							DataObject var14 = var5.createDataObject(var10);
							DataGraphHelper.copyDataObject(var14, (DataObject) var12.get(var13),
									DataGraphHelper.WILDCARD_LIST, DataGraphHelper.WILDCARD_LIST,
									DataGraphHelper.WILDCARD_LIST);
						} else {
							var5.getList(var10).add(var12.get(var13));
						}
					}
				} else {
					var5.set(var10, var11);
				}
			}
		}

		var5.set("modifyTimestamp", this.getDateString());
		if (var4) {
			trcLogger.exiting(CLASSNAME, "modifyProperties(DN,modItems)");
		}

	}

	public DataObject rename(String var1, String var2, String var3) throws Exception {
		boolean var5 = trcLogger.isLoggable(Level.FINEST);
		if (var5) {
			trcLogger.entering(CLASSNAME, "rename(entityType,DN,newDN)", "DN:" + var2 + " #newDN:" + var3);
		}

		if (var2 != null && var3 != null) {
			if (isSuperType("OrgContainer", var1) && this.getImmediateDescendants(var2).size() > 0) {
				throw new EntityHasDescendantsException("ENTITY_HAS_DESCENDENTS",
						WIMMessageHelper.generateMsgParms(var2), Level.SEVERE, CLASSNAME,
						"rename(entityType,DN,newDN)");
			} else {
				DataObject var6 = this.getByDN(var2);
				DataObject var7 = var6.getDataObject("identifier");
				String var8 = var7.getString("uniqueName");
				String var9 = this.getEntityID(var6);
				var7.set("uniqueName", var3);
				var7.set("externalName", var3);
				var6.set("modifyTimestamp", this.getDateString());
				this.entityDN2DO.remove(var8);
				this.entityDN2DO.put(var3, var6);
				this.entityID2DN.put(var9, var3);
				this.changeReferences(var8, var3);
				if (var5) {
					trcLogger.exiting(CLASSNAME, "rename(entityType,DN,newDN)");
				}

				return var6;
			}
		} else {
			throw new InvalidArgumentException("ENTITY_IDENTIFIER_NOT_SPECIFIED", (Object[]) null, Level.SEVERE,
					CLASSNAME, "rename(entityType,DN,newDN)");
		}
	}

	public void updateGroupMembership(String var1, List var2, int var3) throws Exception {
		if (var3 == 2) {
			List var4 = this.getGroupsForEntity(var1, (FileXPathHelper) null);
			if (var4 != null) {
				for (int var5 = 0; var5 < var4.size(); ++var5) {
					this.removeMemberDNFromGroup((String) var4.get(var5), var1, false);
				}
			}
		}

		int var6;
		if (var3 != 1 && var3 != 2) {
			if (var3 == 3) {
				for (var6 = 0; var6 < var2.size(); ++var6) {
					this.removeMemberDNFromGroup((String) var2.get(var6), var1, false);
				}
			}
		} else {
			for (var6 = 0; var6 < var2.size(); ++var6) {
				this.addMemberDNToGroup((String) var2.get(var6), var1, false);
			}
		}

	}

	public void updateGroupMembers(String var1, List var2, int var3) throws Exception {
		if (var3 == 2) {
			DataObject var4 = this.getByDN(var1);
			var4.unset("members");
		}

		int var5;
		if (var3 != 1 && var3 != 2) {
			if (var3 == 3) {
				for (var5 = 0; var5 < var2.size(); ++var5) {
					this.removeMemberDNFromGroup(var1, (String) var2.get(var5), false);
				}
			}
		} else {
			for (var5 = 0; var5 < var2.size(); ++var5) {
				this.addMemberDNToGroup(var1, (String) var2.get(var5), false);
			}
		}

	}

	public boolean identifierMatches(String var1, String var2, DataObject var3, int var4) {
		if (var3 == null) {
			return false;
		} else {
			DataObject var5 = 0 == var4 ? var3.getDataObject("identifier") : var3;
			if (var5 == null) {
				return false;
			} else {
				String var6 = this.getIDFromIdentifier(var5);
				String var7 = var5.getString("uniqueName");
				if (var1 != null && var6 != null && var1.equals(var6)) {
					return true;
				} else {
					return var2 != null && var7 != null && this.normalizedStringsAreEqual(var2, var7);
				}
			}
		}
	}

	public synchronized void saveEntities() throws WIMException {
		boolean var2 = trcLogger.isLoggable(Level.FINEST);
		if (var2) {
			trcLogger.entering(CLASSNAME, "saveEntities",
					"filename=" + this.fileName + ", absoluteFileName=" + this.absoluteFileName);
		}

		String var3 = this.absoluteFileName;

		try {
			if (this.sessionId != null) {
				if (var2) {
					trcLogger.logp(Level.FINER, CLASSNAME, "saveEntities", "saving for session=" + this.sessionId);
				}

				RepositoryContext var4 = this.extractFileInWorkspaceContext(this.sessionId);
				if (var4 == null) {
					trcLogger.logp(Level.FINER, CLASSNAME, "saveEntities", "Repository Context is null.");
					throw new WIMApplicationException("ERROR_WRITING_FILE",
							WIMMessageHelper.generateMsgParms(var3, "Null Workspace Context"), Level.SEVERE, CLASSNAME,
							"saveEntities");
				}

				byte var5 = 1;
				if (!var4.isAvailable(this.fileName)) {
					var5 = 0;
				}

				var3 = var4.getPath() + File.separator + this.fileName;
				if (var2) {
					trcLogger.logp(Level.FINER, CLASSNAME, "saveEntities", "operation=" + var5);
					trcLogger.logp(Level.FINER, CLASSNAME, "saveEntities", "saving to " + var3);
				}

				DataGraphHelper.saveDataGraphWithoutCopyright(this.entityDG, var3);
				var4.notifyChanged(var5, this.fileName);
				if (var2) {
					List var6 = var4.getModifiedList(true);
					if (var6.size() > 0) {
						Iterator var7 = var6.iterator();

						while (var7.hasNext()) {
							trcLogger.logp(Level.FINER, CLASSNAME, "saveEntities",
									"Status changed for " + var7.next().toString());
						}
					} else {
						trcLogger.logp(Level.FINER, CLASSNAME, "saveEntities", "No resource was modified");
					}
				}
			} else {
				DataGraphHelper.saveDataGraphWithoutCopyright(this.entityDG, var3);
				if (DynamicReloadManager.isRunningOnDeploymentManager()
						|| DynamicReloadManager.isRunningOnAdminAgent() && AdminContext.peek() != null) {
					this.handbackObjectArray[1] = this.entityDG.getRootObject();
					this.handbackObjectArray[2] = this.domainID;
					EventDataWrapper var9 = new EventDataWrapper("websphere.usermanager.fileregistry.change",
							this.handbackObjectArray);
					DynamicReloadManager.singleton().broadcastEventAtDeploymentManager(
							"websphere.usermanager.fileregistry.change",
							"File Registry Change Event for " + this.fileID + " on domain " + this.domainID, var9);
				}
			}
		} catch (Exception var8) {
			throw new WIMApplicationException("ERROR_WRITING_FILE",
					WIMMessageHelper.generateMsgParms(var3, var8.getMessage()), Level.SEVERE, CLASSNAME, "saveEntities",
					var8);
		}

		if (var2) {
			trcLogger.exiting(CLASSNAME, "saveEntities", "saved to file=" + var3);
		}

	}

	protected static byte[] hash(byte[] var0, int var1, String var2) throws WIMException {
		String var3 = PasswordEncryptionUtil.generateSalt(var1);
		return hash(var0, var3, var2);
	}

	protected static byte[] hash(byte[] var0, String var1, String var2) throws WIMException {
		byte[] var3 = PasswordUtil.getByteArrayPassword(var1);
		byte[] var4 = new byte[var3.length + var0.length];

		int var5;
		for (var5 = 0; var5 < var3.length; ++var5) {
			var4[var5] = var3[var5];
		}

		for (int var6 = 0; var6 < var0.length; ++var6) {
			var4[var5++] = var0[var6];
		}

		String var8 = PasswordEncryptionUtil.hash(var4, var2);
		StringBuffer var7 = new StringBuffer(var2);
		var7.append(":");
		var7.append(var1);
		var7.append(":");
		var7.append(var8);
		PasswordUtil.erasePassword(var4);
		return var7.toString().getBytes();
	}

	protected static byte[] hashBPM(byte[] var0, String var1, String var2, String var3, String var4) {
		String var5 = null;
		if (var4 == null) {
			byte[] var6 = Base64.decode(var1);
			byte[] var7 = new byte[var6.length + var0.length];

			int var8;
			for (var8 = 0; var8 < var6.length; ++var8) {
				var7[var8] = var6[var8];
			}

			for (int var9 = 0; var9 < var0.length; ++var9) {
				var7[var8++] = var0[var9];
			}

			var5 = PasswordEncryptionUtil.hash(var7, var2, var3);
		} else {
			var5 = var4;
		}

		StringBuffer var10 = new StringBuffer(var2);
		var10.append(":");
		var10.append(var3);
		var10.append(":");
		var10.append(var1);
		var10.append(":");
		var10.append(var5);
		return var10.toString().getBytes();
	}

	protected static byte[] hashPbkdf2(byte[] var0, int var1, int var2, int var3, String var4) throws WIMException {
		byte[] var5 = PasswordEncryptionUtil.generateSaltPbkdf2(var1);
		String var6 = Base64.encode(var5);
		return PasswordEncryptionUtil.hashPbkdf2(var0, var6, var4, String.valueOf(var2), String.valueOf(var3))
				.getBytes();
	}

	public boolean normalizedStringsAreEqual(String var1, String var2) {
		return this.caseSensitive ? var1.equals(var2) : var1.equalsIgnoreCase(var2);
	}

	private boolean normalizedBaseEntriesAreEqual(String var1) {
		return this.caseSensitive
				? this.baseEntries.contains(var1)
				: RepositoryManager.matchBaseEntryIgnoreCase(this.baseEntries, var1);
	}

	public String containsNormalizedKey(Map var1, String var2) {
		if (var1.containsKey(var2)) {
			return var2;
		} else {
			if (!this.caseSensitive) {
				Iterator var3 = var1.keySet().iterator();

				while (var3.hasNext()) {
					String var4 = (String) var3.next();
					if (var4.equalsIgnoreCase(var2)) {
						return var4;
					}
				}
			}

			return null;
		}
	}

	public String getDateString() {
		StringBuffer var1 = new StringBuffer(this.sdf.format(new Date()));
		var1.insert(var1.length() - 2, ":");
		return var1.toString();
	}

	protected void dumpFileData() {
		boolean var2 = trcLogger.isLoggable(Level.FINE);
		if (var2) {
			trcLogger.entering(CLASSNAME, "dumpFileData");
			trcLogger.logp(Level.FINE, CLASSNAME, "dumpFileData", "entityRDN=" + this.entityRDN);
			trcLogger.logp(Level.FINE, CLASSNAME, "dumpFileData", "entityRererence=" + this.entityReference);
			trcLogger.logp(Level.FINE, CLASSNAME, "dumpFileData", "numOfEntities=" + this.numOfEntities);
			trcLogger.logp(Level.FINE, CLASSNAME, "dumpFileData", "entityDNs=" + this.entityDN2DO.keySet());
			trcLogger.logp(Level.FINE, CLASSNAME, "dumpFileData", "entityID2DNs=" + this.entityID2DN);
			trcLogger.logp(Level.FINE, CLASSNAME, "dumpFileData",
					"entityDG=" + WIMTraceHelper.printDataGraph(this.entityDG));
		}

	}

	public synchronized void addBaseEntry(String var1) {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "addBaseEntry", "Adding " + var1);
		}

		this.baseEntries.add(var1);
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "addBaseEntry", "baseEntries=" + this.baseEntries);
		}

	}

	private boolean isAccountLockoutEnabled() {
		return this.accountLockoutCacheConfig != null;
	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = FileData.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
		msgLogger = WIMLogger.getMessageLogger(CLASSNAME);
	}
}