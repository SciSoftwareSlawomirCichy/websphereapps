package com.ibm.ws.wim.federation;

import com.ibm.websphere.wim.DynamicConfigService;
import com.ibm.websphere.wim.copyright.IBMCopyright;
import com.ibm.websphere.wim.exception.DynamicUpdateConfigException;
import com.ibm.websphere.wim.exception.InitializationException;
import com.ibm.websphere.wim.exception.WIMException;
import com.ibm.websphere.wim.exception.WIMSystemException;
import com.ibm.websphere.wim.ras.WIMLogger;
import com.ibm.websphere.wim.ras.WIMMessageHelper;
import com.ibm.websphere.wim.util.UniqueIdGenerator;
import com.ibm.ws.wim.RepositoryManager;
import com.ibm.ws.wim.dao.DAOHelper;
import com.ibm.ws.wim.dao.DataAccessObject;
import commonj.sdo.DataObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;

public class FederationAdapter implements FederationRepository, DynamicConfigService {
	static final String COPYRIGHT_NOTICE;
	private static final String CLASSNAME;
	private static final Logger trcLogger;
	private static final String SCHEMA_UNIQUE_ID = "UNIQUE_ID";
	private static final String SCHEMA_UNIQUE_NAME = "UNIQUE_NAME";
	private static final String SCHEMA_UNIQUE_NAME_KEY = "UNIQUE_NAME_KEY";
	private static final String SCHEMA_ENTITY_TYPE = "ENTITY_TYPE";
	private static final String SCHEMA_REPOSITORY_ID = "REPOS_ID";
	private static final String SCHEMA_EXTERNAL_ID = "EXT_ID";
	private static final String SCHEMA_FULL_EXTERNAL_ID = "FULL_EXT_ID";
	private DataAccessObject dao = null;

	public String create(String var1, String var2, String var3, String var4) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "create(entityType,uniqueName,repositoryId,externalId)",
					"( " + var1 + ", " + var2 + ", " + var3 + ", " + var4 + ")");
		}

		String var6 = null;
		if (RepositoryManager.singleton().isGenerateUniqueId(var3)) {
			var6 = UniqueIdGenerator.newUniqueId();
		} else {
			var6 = var4;
		}

		FederationEntity var7 = new FederationEntity();
		var7.setEntityType(var1);
		var7.setUniqueId(var6);
		var7.setRepositoryId(var3);
		var7.setExternalId(var4);
		var7.setUniqueName(var2);

		try {
			this.createFederationEntity(var7);
		} catch (SQLException var9) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var9.getMessage()),
					CLASSNAME, "create(entityType,uniqueName,repositoryId,externalId)", var9);
		} catch (NamingException var10) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var10.getMessage()),
					CLASSNAME, "create(entityType,uniqueName,repositoryId,externalId)", var10);
		} catch (WIMException var11) {
			throw var11;
		} catch (Exception var12) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var12.getMessage()), CLASSNAME,
					"create(entityType,uniqueName,repositoryId,externalId)", var12);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var6 + " " + "create(entityType,uniqueName,repositoryId,externalId)");
		}

		return var6;
	}

	public FederationEntity get(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "get(repositoryId,extId)", "( " + var1 + ", " + var2 + " )");
		}

		FederationEntity var4 = null;

		try {
			FederationEntity var5 = this.findFederationEntityByRepositoryIdAndExternalId(var1, var2);
			if (var5 != null) {
				var4 = var5;
			}
		} catch (SQLException var6) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.getMessage()),
					CLASSNAME, "get(repositoryId,extId)", var6);
		} catch (NamingException var7) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var7.getMessage()),
					CLASSNAME, "get(repositoryId,extId)", var7);
		} catch (WIMException var8) {
			throw var8;
		} catch (Exception var9) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var9.getMessage()), CLASSNAME,
					"get(repositoryId,extId)", var9);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var4 + " " + "get(repositoryId,extId)");
		}

		return var4;
	}

	public FederationEntity get(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "get(uniqueId)", "( " + var1 + ")");
		}

		FederationEntity var3 = null;

		try {
			FederationEntity var4 = this.findFederationEntityByEntityId(var1);
			if (var4 != null) {
				var3 = var4;
			}
		} catch (SQLException var5) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var5.getMessage()),
					CLASSNAME, "get(uniqueId)", var5);
		} catch (NamingException var6) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.getMessage()),
					CLASSNAME, "get(uniqueId)", var6);
		} catch (WIMException var7) {
			throw var7;
		} catch (Exception var8) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var8.getMessage()), CLASSNAME,
					"get(uniqueId)", var8);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var3 + " " + "get(uniqueId)");
		}

		return var3;
	}

	public Map lookup(String var1, Set var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "lookup(repositoryId,extIds)", "(" + var1 + ", " + var2 + " )");
		}

		Map var4 = null;

		try {
			var4 = this.findFederationEntitiesByRepositoryIdAndExternalIds(var1, var2);
		} catch (SQLException var6) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.getMessage()),
					CLASSNAME, "lookup(repositoryId,extIds)", var6);
		} catch (NamingException var7) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var7.getMessage()),
					CLASSNAME, "lookup(repositoryId,extIds)", var7);
		} catch (WIMException var8) {
			throw var8;
		} catch (Exception var9) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var9.getMessage()), CLASSNAME,
					"lookup(repositoryId,extIds)", var9);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, var4 + " " + "lookup(repositoryId,extIds)");
		}

		return var4;
	}

	public void remove(FederationEntity var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "remove( fedEntity )", "" + var1);
		}

		try {
			this.removeFederationEntity(var1);
		} catch (SQLException var4) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var4.getMessage()),
					CLASSNAME, "remove( fedEntity )", var4);
		} catch (NamingException var5) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var5.getMessage()),
					CLASSNAME, "remove( fedEntity )", var5);
		} catch (WIMException var6) {
			throw var6;
		} catch (Exception var7) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var7.getMessage()), CLASSNAME,
					"remove( fedEntity )", var7);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "remove( fedEntity )");
		}

	}

	public void updateExtId(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateExtId(uniqueId,newExtId)", "( " + var1 + ", " + var2 + " )");
		}

		try {
			this.updateFederationExternalIdByUniqueId(var1, var2);
		} catch (SQLException var5) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var5.getMessage()),
					CLASSNAME, "updateExtId(uniqueId,newExtId)", var5);
		} catch (NamingException var6) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.getMessage()),
					CLASSNAME, "updateExtId(uniqueId,newExtId)", var6);
		} catch (WIMException var7) {
			throw var7;
		} catch (Exception var8) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var8.getMessage()), CLASSNAME,
					"updateExtId(uniqueId,newExtId)", var8);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updateExtId(uniqueId,newExtId)");
		}

	}

	public boolean initialize(DataObject var1) throws WIMException {
		if (var1 == null) {
			throw new InitializationException("GENERIC", WIMMessageHelper.generateMsgParms("configObj is null."),
					CLASSNAME, "initialize");
		} else {
			String var4 = var1.getString("dataSourceName");
			String var3 = var1.getString("databaseType");
			String var5 = var1.getString("dbURL");
			String var6 = var1.getString("dbAdminId");
			String var7 = var1.getString("dbAdminPassword");
			String var8 = var1.getString("JDBCDriverClass");
			String var9 = var1.getString("dbSchema");
			if (var4 == null || var4.length() == 0) {
				var4 = "jdbc/wimDS";
			}

			if (var3 == null || var3.length() == 0) {
				var3 = "db2";
			}

			this.dao = DAOHelper.getNewDAOClass(var3, var4, var5, var9, var6, var7, var8);
			return true;
		}
	}

	private void createFederationEntity(FederationEntity var1) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "createFederationEntity");
		}

		String var3 = var1.getEntityType();
		String var4 = var1.getUniqueId();
		String var5 = var1.getExternalId();
		String var6 = var1.getRepositoryId();
		String var7 = var1.getUniqueName();
		HashSet var8 = new HashSet();
		var8.add(var5);
		Map var9 = this.findFederationEntitiesByRepositoryIdAndExternalIds(var6, var8);
		if (var9 != null && var9.size() == 1) {
			FederationEntity var16 = (FederationEntity) var9.get(var5);
			String var17 = var16.getUniqueId();
			this.updateFederationUniqueNameByUniqueId(var17, var7);
		} else {
			Connection var10 = this.getConnection();
			PreparedStatement var11 = null;

			try {
				String var12 = this.dao.getQuerySet().createFederationEntity;
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "createFederationEntity", var12);
				}

				var11 = var10.prepareStatement(var12);
				var11.setString(1, var4);
				var11.setString(2, DAOHelper.getTruncatedUniqueName(var7));
				var11.setString(3, var7);
				var11.setString(4, var3);
				var11.setString(5, var6);
				var11.setString(6, DAOHelper.getTruncatedExternalId(var5));
				var11.setString(7, var5);
				var11.executeUpdate();
			} finally {
				if (var11 != null) {
					var11.close();
				}

				this.dao.closeConnection(var10);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "createFederationEntity");
			}

		}
	}

	private FederationEntity findFederationEntityByRepositoryIdAndExternalId(String var1, String var2)
			throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "findFederationEntityByrepositoryIdAndExternalId(repId,extId)");
		}

		Connection var4 = this.dao.getConnection();
		PreparedStatement var5 = null;
		ResultSet var6 = null;
		FederationEntity var7 = new FederationEntity();

		try {
			String var8 = this.dao.getQuerySet().findFederationEntityByRepositoryAndExternalId;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "findFederationEntityByrepositoryIdAndExternalId(repId,extId)",
						var8);
			}

			var5 = var4.prepareStatement(var8);
			var5.setString(1, var1);
			var5.setString(2, DAOHelper.getTruncatedExternalId(var2));
			var6 = var5.executeQuery();
			if (var6.next()) {
				var7.setUniqueId(var6.getString("UNIQUE_ID"));
				var7.setUniqueName(var6.getString("UNIQUE_NAME"));
				var7.setEntityType(var6.getString("ENTITY_TYPE"));
				var7.setRepositoryId(var6.getString("REPOS_ID"));
				var7.setExternalId(var6.getString("FULL_EXT_ID"));
			} else {
				var7 = null;
			}
		} finally {
			if (var5 != null) {
				var5.close();
			}

			this.dao.closeConnection(var4);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "findFederationEntityByrepositoryIdAndExternalId(repId,extId)", var7);
		}

		return var7;
	}

	private FederationEntity findFederationEntityByEntityId(String var1) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "findFederationEntityByEntityId(uniqueId)");
		}

		Connection var3 = this.dao.getConnection();
		PreparedStatement var4 = null;
		ResultSet var5 = null;
		FederationEntity var6 = new FederationEntity();

		try {
			String var7 = this.dao.getQuerySet().findFederationEntityByUniqueId;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "findFederationEntityByEntityId(uniqueId)", var7);
			}

			var4 = var3.prepareStatement(var7);
			var4.setString(1, var1);
			var5 = var4.executeQuery();
			if (var5.next()) {
				var6.setUniqueId(var5.getString("UNIQUE_ID"));
				var6.setUniqueName(var5.getString("UNIQUE_NAME"));
				var6.setEntityType(var5.getString("ENTITY_TYPE"));
				var6.setRepositoryId(var5.getString("REPOS_ID"));
				var6.setExternalId(var5.getString("FULL_EXT_ID"));
			} else {
				var6 = null;
			}
		} finally {
			if (var4 != null) {
				var4.close();
			}

			this.dao.closeConnection(var3);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "findFederationEntityByEntityId(uniqueId)", var6);
		}

		return var6;
	}

	private FederationEntity findFederationEntityByUniqueName(String var1) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "findFederationEntityByUniqueName(uniqueName)");
		}

		if (var1 != null && var1.trim().length() != 0) {
			Connection var3 = this.dao.getConnection();
			PreparedStatement var4 = null;
			ResultSet var5 = null;
			FederationEntity var6 = new FederationEntity();

			try {
				String var7 = this.dao.getQuerySet().findFederationEntityByUniqueName;
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "findFederationEntityByUniqueName(uniqueName)", var7);
				}

				var4 = var3.prepareStatement(var7);
				var4.setString(1, DAOHelper.getTruncatedUniqueName(var1));
				var5 = var4.executeQuery();
				if (var5.next()) {
					var6.setUniqueId(var5.getString("UNIQUE_ID"));
					var6.setUniqueName(var5.getString("UNIQUE_NAME"));
					var6.setEntityType(var5.getString("ENTITY_TYPE"));
					var6.setRepositoryId(var5.getString("REPOS_ID"));
					var6.setExternalId(var5.getString("FULL_EXT_ID"));
				} else {
					var6 = null;
				}
			} finally {
				if (var4 != null) {
					var4.close();
				}

				this.dao.closeConnection(var3);
			}

			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.exiting(CLASSNAME, "findFederationEntityByUniqueName(uniqueName)", var6);
			}

			return var6;
		} else {
			return null;
		}
	}

	private Map findFederationEntitiesByRepositoryIdAndExternalIds(String var1, Set var2) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME,
					"findFederationEntitiesByRepositoryIdAndExternalIds(repositoryId,externalIdSet)");
		}

		Connection var4 = this.dao.getConnection();
		PreparedStatement var5 = null;
		ResultSet var6 = null;
		HashMap var7 = new HashMap();

		try {
			String var8 = this.dao.getQuerySet().findFederationEntitiesByReposIdAndExtIds;
			int var9 = var2.size();
			StringBuffer var10 = new StringBuffer();

			int var11;
			for (var11 = 0; var11 < var9; ++var11) {
				if (var10.length() == 0) {
					var10.append(this.dao.getQuerySet().PARAM_MARKER);
				} else {
					var10.append(this.dao.getQuerySet().COMMA_AND_SPACE + this.dao.getQuerySet().PARAM_MARKER);
				}
			}

			var8 = var8 + var10.toString() + this.dao.getQuerySet().RIGHT_BRACKET;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME,
						"findFederationEntitiesByRepositoryIdAndExternalIds(repositoryId,externalIdSet)", var8);
			}

			var5 = var4.prepareStatement(var8);
			var5.setString(1, var1);
			var11 = 2;
			Iterator var12 = var2.iterator();

			while (var12.hasNext()) {
				var5.setString(var11++, DAOHelper.getTruncatedExternalId((String) var12.next()));
			}

			var6 = var5.executeQuery();

			while (var6.next()) {
				var7.put(var6.getString("FULL_EXT_ID"),
						new FederationEntity(var6.getString("UNIQUE_ID"), var6.getString("UNIQUE_NAME"),
								var6.getString("ENTITY_TYPE"), var6.getString("REPOS_ID"),
								var6.getString("FULL_EXT_ID")));
			}
		} finally {
			if (var5 != null) {
				var5.close();
			}

			this.dao.closeConnection(var4);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME,
					"findFederationEntitiesByRepositoryIdAndExternalIds(repositoryId,externalIdSet)", var7);
		}

		return var7;
	}

	private void removeFederationEntity(FederationEntity var1) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "removeFederationEntity(fedEntity)");
		}

		Connection var3 = this.dao.getConnection();
		PreparedStatement var4 = null;
		Object var5 = null;

		try {
			String var6 = var1.getUniqueId();
			String var7 = var1.getUniqueName();
			String var8 = var1.getExternalId();
			String var9 = var1.getRepositoryId();
			String var10;
			if (var6 != null && var6.length() > 0) {
				var10 = this.dao.getQuerySet().removeFederationEntityByEntityId;
				var4 = var3.prepareStatement(var10);
				var4.setString(1, var6);
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "removeFederationEntity(fedEntity)",
							var10 + ", uniqueId = " + var6);
				}
			} else if (var7 != null && var7.length() > 0) {
				var10 = this.dao.getQuerySet().removeFederationEntityByEntityName;
				var4 = var3.prepareStatement(var10);
				var4.setString(1, DAOHelper.getTruncatedUniqueName(var7));
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "removeFederationEntity(fedEntity)",
							var10 + ", uniqueName = " + var7);
				}
			} else {
				var10 = this.dao.getQuerySet().removeFederationEntityByExternalId;
				var4 = var3.prepareStatement(var10);
				var4.setString(1, var9);
				var4.setString(2, DAOHelper.getTruncatedExternalId(var8));
				if (trcLogger.isLoggable(Level.FINER)) {
					trcLogger.logp(Level.FINER, CLASSNAME, "removeFederationEntity(fedEntity)",
							var10 + ", repositoryId = " + var9 + "/externalId = " + var8);
				}
			}

			var4.executeUpdate();
		} finally {
			if (var4 != null) {
				var4.close();
			}

			this.dao.closeConnection(var3);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "removeFederationEntity(fedEntity)");
		}

	}

	private void updateFederationExternalIdByUniqueId(String var1, String var2) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateFederationExternalIdByUniqueId(niqueId,newExtId)");
		}

		Connection var4 = this.dao.getConnection();
		PreparedStatement var5 = null;
		Object var6 = null;

		try {
			String var7 = this.dao.getQuerySet().updateFederationExternalIdByUniqueId;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "updateFederationExternalIdByUniqueId(niqueId,newExtId)", var7);
			}

			var5 = var4.prepareStatement(var7);
			var5.setString(1, var2);
			var5.setString(2, DAOHelper.getTruncatedExternalId(var2));
			var5.setString(3, var1);
			var5.executeUpdate();
		} finally {
			if (var5 != null) {
				var5.close();
			}

			this.dao.closeConnection(var4);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updateFederationExternalIdByUniqueId(niqueId,newExtId)");
		}

	}

	private void updateFederationUniqueNameByUniqueId(String var1, String var2) throws Exception {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateFederationUniqueNameByUniqueId(uniqueid,uniqueName)");
		}

		Connection var4 = this.dao.getConnection();
		PreparedStatement var5 = null;
		Object var6 = null;

		try {
			String var7 = this.dao.getQuerySet().updateFederationUniqueNameByUniqueId;
			if (trcLogger.isLoggable(Level.FINER)) {
				trcLogger.logp(Level.FINER, CLASSNAME, "updateFederationUniqueNameByUniqueId(uniqueid,uniqueName)",
						var7);
			}

			var5 = var4.prepareStatement(var7);
			var5.setString(1, var2);
			var5.setString(2, DAOHelper.getTruncatedUniqueName(var2));
			var5.setString(3, var1);
			var5.executeUpdate();
		} finally {
			if (var5 != null) {
				var5.close();
			}

			this.dao.closeConnection(var4);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updateFederationUniqueNameByUniqueId(uniqueid,uniqueName)");
		}

	}

	private Connection getConnection() throws WIMException {
		return this.dao.getConnection();
	}

	public FederationEntity lookupByUniqueId(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "lookupByUniqueId(uniqueId)");
		}

		FederationEntity var3 = null;

		try {
			var3 = this.findFederationEntityByEntityId(var1);
		} catch (SQLException var5) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var5.getMessage()),
					CLASSNAME, "lookupByUniqueId(uniqueId)", var5);
		} catch (NamingException var6) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.getMessage()),
					CLASSNAME, "lookupByUniqueId(uniqueId)", var6);
		} catch (WIMException var7) {
			throw var7;
		} catch (Exception var8) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var8.getMessage()), CLASSNAME,
					"lookupByUniqueId(uniqueId)", var8);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "lookupByUniqueId(uniqueId)", var3);
		}

		return var3;
	}

	public FederationEntity lookupByUniqueName(String var1) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "lookupByUniqueName(uniqueName)");
		}

		FederationEntity var3 = null;

		try {
			var3 = this.findFederationEntityByUniqueName(var1);
		} catch (SQLException var5) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var5.getMessage()),
					CLASSNAME, "lookupByUniqueName(uniqueName)", var5);
		} catch (NamingException var6) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.getMessage()),
					CLASSNAME, "lookupByUniqueName(uniqueName)", var6);
		} catch (WIMException var7) {
			throw var7;
		} catch (Exception var8) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var8.getMessage()), CLASSNAME,
					"lookupByUniqueName(uniqueName)", var8);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "lookupByUniqueName(uniqueName)", var3);
		}

		return var3;
	}

	public void updateUniqueName(String var1, String var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "updateUniqueName(uniqueId,uniqueName)");
		}

		try {
			this.updateFederationUniqueNameByUniqueId(var1, var2);
		} catch (SQLException var5) {
			throw new WIMSystemException("SQL_EXCEPTION", WIMMessageHelper.generateMsgParms(var5.getMessage()),
					CLASSNAME, "updateUniqueName(uniqueId,uniqueName)", var5);
		} catch (NamingException var6) {
			throw new WIMSystemException("NAMING_EXCEPTION", WIMMessageHelper.generateMsgParms(var6.getMessage()),
					CLASSNAME, "updateUniqueName(uniqueId,uniqueName)", var6);
		} catch (WIMException var7) {
			throw var7;
		} catch (Exception var8) {
			throw new WIMSystemException("GENERIC", WIMMessageHelper.generateMsgParms(var8.getMessage()), CLASSNAME,
					"updateUniqueName(uniqueId,uniqueName)", var8);
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "updateUniqueName(uniqueId,uniqueName)");
		}

	}

	public void dynamicUpdateConfig(String var1, Hashtable var2) throws WIMException {
		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.entering(CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
		}

		if (var1.equals("websphere.usermanager.serviceprovider.update.entrymapping.adminidpassword")) {
			byte[] var4 = (byte[]) ((byte[]) var2.get("DYNA_CONFIG_KEY_DB_ADMIN_PASSWORD"));

			try {
				String var5 = new String(var4, "UTF-8");
				this.dao.reload(var5);
			} catch (Exception var7) {
				Object var6;
				for (var6 = var7; ((Throwable) var6).getCause() != null; var6 = ((Throwable) var6).getCause()) {
					;
				}

				throw new DynamicUpdateConfigException("REPOSITORY_CONNECTION_FAILED",
						WIMMessageHelper.generateMsgParms("FED", "DYNA_CONFIG_KEY_DB_ADMIN_PASSWORD",
								var6.getClass().getName()),
						CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
			}
		}

		if (trcLogger.isLoggable(Level.FINER)) {
			trcLogger.exiting(CLASSNAME, "dynamicUpdateConfig(String updateEvent, Map configData)");
		}

	}

	static {
		COPYRIGHT_NOTICE = IBMCopyright.COPYRIGHT_NOTICE_LONG_2005_2010;
		CLASSNAME = FederationAdapter.class.getName();
		trcLogger = WIMLogger.getTraceLogger(CLASSNAME);
	}
}