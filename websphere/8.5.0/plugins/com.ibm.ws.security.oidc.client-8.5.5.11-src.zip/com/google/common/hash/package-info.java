package com.google.common.hash;

import javax.annotation.ParametersAreNonnullByDefault;

// $FF: synthetic class
@ParametersAreNonnullByDefault
interface package-info {
}