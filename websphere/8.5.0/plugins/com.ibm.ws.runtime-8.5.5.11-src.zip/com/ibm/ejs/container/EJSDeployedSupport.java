package com.ibm.ejs.container;

import com.ibm.ejs.container.interceptors.InvocationContextImpl;
import com.ibm.ejs.container.util.ExceptionUtil;
import com.ibm.ejs.csi.EJBModuleMetaDataImpl;
import com.ibm.ejs.csi.UOWCookie;
import com.ibm.ejs.j2c.HandleList;
import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.websphere.csi.CSIException;
import com.ibm.websphere.csi.CSITransactionRolledbackException;
import com.ibm.websphere.csi.ExceptionType;
import com.ibm.ws.csi.DispatchEventListenerCookie;
import com.ibm.ws.ejbcontainer.EJBMethodMetaData;
import com.ibm.ws.ejbcontainer.EJBRequestData;
import com.ibm.ws.ejbcontainer.EJBSecurityCollaborator;
import com.ibm.ws.ffdc.FFDCFilter;
import com.ibm.ws.runtime.metadata.ComponentMetaData;
import com.ibm.ws.runtime.metadata.MethodMetaData;
import com.ibm.ws.util.InvocationCallback;
import com.ibm.ws.util.InvocationToken;
import com.ibm.ws.util.ThreadContextAccessor;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.ejb.EJBException;
import javax.ejb.Timer;

public class EJSDeployedSupport implements EJBRequestData, InvocationToken {
	private static final TraceComponent tc = Tr.register(EJSDeployedSupport.class, "EJBContainer",
			"com.ibm.ejs.container.container");
	private static final String CLASS_NAME = "com.ibm.ejs.container.EJSDeployedSupport";
	final EJBThreadData ivThreadData;
	UOWCookie uowCookie;
	boolean uowCtrlPreInvoked;
	long pmiCookie;
	boolean pmiPreInvoked;
	EJBSecurityCollaborator<?> ivSecurityCollaborator;
	int ivBeforeActivationPreInvoked;
	int ivBeforeActivationAfterCompletionPreInvoked;
	int ivAfterActivationPreInvoked;
	boolean began;
	boolean previousBegan;
	BeanO beanO;
	boolean preInvokeException;
	boolean unpinOnPostInvoke = true;
	EJBMethodInfoImpl methodInfo;
	int methodId;
	Object[] ivBeforeActivationCookies;
	Object[] ivBeforeActivationAfterCompletionCookies;
	Object[] ivAfterActivationCookies;
	Object securityCookie;
	ContainerTx currentTx;
	int currentIsolationLevel;
	int oldIsolationLevel;
	Object oldClassLoader;
	ExceptionType exType;
	Throwable ivException;
	Throwable rootEx;
	Exception exceptionToBeThrown;
	boolean ivIgnoreApplicationExceptions;
	protected Object[] ivEJBMethodArguments;
	protected boolean ivBeginnerSetRollbackOnly;
	ArrayList<InvocationCallback> ivEJBMethodCallback;
	ArrayList<Object> ivEJBMethodCallbackCookie;
	protected boolean isLightweight;
	protected EJSWrapperBase ivWrapper;
	private InvocationContextImpl ivInvocationContext;
	Map<String, Object> ivContextData;
	protected int ivRunUnderUOW;
	protected StatefulBeanO ivCreateBeanO;
	protected EJSDeployedSupport ivCallerContext;
	protected DispatchEventListenerCookie[] ivDispatchEventListenerCookies;
	protected HandleList ivHandleList;
	protected boolean ivLockAcquired;
	InternalAsyncResult ivAsyncResult;
	boolean ivPopCallbackBeanORequired;

	public EJSDeployedSupport() {
		this.oldClassLoader = ThreadContextAccessor.UNCHANGED;
		this.exType = ExceptionType.NO_EXCEPTION;
		this.ivThreadData = EJSContainer.getThreadData();
	}

	public String toString() {
		return this.getClass().getSimpleName() + '[' + this.methodInfo.getMethodSignature() + ", "
				+ this.methodInfo.getEJBMethodInterface() + ", "
				+ (this.beanO != null ? this.beanO : this.ivWrapper.beanId) + ']';
	}

	public EJBMethodMetaData getEJBMethodMetaData() {
		return this.methodInfo;
	}

	public Object[] getMethodArguments() {
		return this.ivEJBMethodArguments;
	}

	public BeanId getBeanId() {
		return this.ivWrapper.beanId;
	}

	public Object getBeanInstance() {
		if (this.methodInfo.isHome()) {
			return null;
		} else if (this.beanO == null) {
			IllegalStateException ex = new IllegalStateException();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getBeanInstance: called before activation", ex);
			}

			throw ex;
		} else {
			return this.beanO.getBeanInstance();
		}
	}

	public final Throwable getException() {
		return this.ivException;
	}

	public final Throwable getRootCause() {
		return this.rootEx;
	}

	public final void setCheckedException(Exception ex) {
		this.getExceptionMappingStrategy().setCheckedException(this, ex);
	}

	public final void setUncheckedException(Throwable ex) throws RemoteException {
		ExceptionMappingStrategy exceptionStrategy = this.getExceptionMappingStrategy();
		Throwable mappedException = exceptionStrategy.setUncheckedException(this, ex);
		if (mappedException != null) {
			if (mappedException instanceof RemoteException) {
				throw (RemoteException) mappedException;
			} else if (mappedException instanceof RuntimeException) {
				throw (RuntimeException) mappedException;
			} else if (mappedException instanceof Error) {
				throw (Error) mappedException;
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "unexpected Throwable returned by exception mapping strategy",
							new Object[]{mappedException, exceptionStrategy});
				}

				throw ExceptionUtil.RemoteException(mappedException);
			}
		}
	}

	public final void setUncheckedException(Exception ex) throws RemoteException {
		this.setUncheckedException((Throwable) ex);
	}

	public final void setUncheckedLocalException(Throwable ex) throws EJBException {
		ExceptionMappingStrategy exceptionStrategy = this.getExceptionMappingStrategy();
		Throwable mappedException = exceptionStrategy.setUncheckedException(this, ex);
		if (mappedException != null) {
			if (mappedException instanceof EJBException) {
				throw (EJBException) mappedException;
			} else if (mappedException instanceof RuntimeException) {
				throw (RuntimeException) mappedException;
			} else if (mappedException instanceof Error) {
				throw (Error) mappedException;
			} else {
				if (TraceComponent.isAnyTracingEnabled() && tc.isEventEnabled()) {
					Tr.event(tc, "unexpected Throwable returned by exception mapping strategy",
							new Object[]{mappedException, exceptionStrategy});
				}

				throw ExceptionUtil.EJBException(mappedException);
			}
		}
	}

	public final BeanO getBeanO() {
		return this.beanO;
	}

	public final ContainerTx getCurrentTx() {
		return this.currentTx;
	}

	public final EJSContainer getContainer() {
		return this.ivWrapper == null ? EJSContainer.getDefaultContainer() : this.ivWrapper.container;
	}

	public StatefulBeanO getCachedWrapperBeanO() {
		EJSWrapperCommon wc = this.ivWrapper.ivCommon;
		return wc == null ? null : wc.ivCachedBeanO;
	}

	final void setEJBMethodInfo(EJBMethodInfoImpl m) {
		this.methodInfo = m;
	}

	public EJBMethodInfoImpl getEJBMethodInfoImpl() {
		return this.methodInfo;
	}

	public final long getConcurrencyAccessTimeout() {
		return this.methodInfo.ivAccessTimeout;
	}

	public final ExceptionType getExceptionType() {
		return this.exType;
	}

	protected Boolean getApplicationExceptionRollback(Throwable t) {
		Boolean rollback;
		if (this.ivIgnoreApplicationExceptions) {
			rollback = null;
		} else {
			ComponentMetaData cmd = this.getComponentMetaData();
			EJBModuleMetaDataImpl mmd = (EJBModuleMetaDataImpl) cmd.getModuleMetaData();
			rollback = mmd.getApplicationExceptionRollback(t);
		}

		return rollback;
	}

	ExceptionMappingStrategy getExceptionMappingStrategy() {
		return this.ivWrapper.ivInterface.ivExceptionStrategy;
	}

	public final Exception mapCSITransactionRolledBackException(CSITransactionRolledbackException ex)
			throws CSIException {
		return this.getExceptionMappingStrategy().mapCSITransactionRolledBackException(this, ex);
	}

	public final void setEJBMethodId(int methodid) {
		this.methodId = methodid;
	}

	public final int getEJBMethodId() {
		return this.methodId;
	}

	public final boolean beganInThisScope() {
		return this.began || this.previousBegan && this.methodId < 0;
	}

	public final boolean beganAndEndInThisScope() {
		return this.began || this.previousBegan && this.methodId < 0;
	}

	public void enlistInvocationCallback(InvocationCallback callback, Object cookie) {
		if (this.ivEJBMethodCallback == null) {
			this.ivEJBMethodCallback = new ArrayList();
			this.ivEJBMethodCallbackCookie = new ArrayList();
		}

		this.ivEJBMethodCallback.add(callback);
		this.ivEJBMethodCallbackCookie.add(cookie);
	}

	public void invocationCallbackPostInvoke() {
		if (this.ivEJBMethodCallback != null) {
			int n = this.ivEJBMethodCallback.size();

			for (int i = 0; i < n; ++i) {
				try {
					InvocationCallback callback = (InvocationCallback) this.ivEJBMethodCallback.get(i);
					callback.postInvoke(this.ivEJBMethodCallbackCookie.get(i));
				} catch (Throwable var4) {
					FFDCFilter.processException(var4,
							"com.ibm.ejs.container.EJSDeployedSupport.ejbMethodCallbackPostInvoke", "332", this);
					if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
						Tr.debug(tc, "ignoring exception thrown by EJBMethodCallback.postInvoke", var4);
					}
				}
			}
		}

	}

	public final int getContainerType() {
		return 2;
	}

	public final ComponentMetaData getComponentMetaData() {
		return this.methodInfo.getComponentMetaData();
	}

	public final MethodMetaData getMethodMetaData() {
		return this.methodInfo;
	}

	public InvocationContextImpl getInvocationContext(Object instance, Object[] interceptors, Timer timer) {
		if (this.ivInvocationContext == null) {
			this.ivInvocationContext = new InvocationContextImpl();
		}

		this.ivInvocationContext.initialize(instance, interceptors, timer);
		return this.ivInvocationContext;
	}

	public Map<String, Object> getContextData() {
		if (this.ivContextData == null) {
			this.ivContextData = new HashMap();
			if (TraceComponent.isAnyTracingEnabled() && tc.isDebugEnabled()) {
				Tr.debug(tc, "getContextData: created empty");
			}
		}

		return this.ivContextData;
	}

	public Object getExPcBindingContext() {
		Object jpaContext = null;
		if (this.ivCreateBeanO != null) {
			jpaContext = this.ivCreateBeanO.ivExPcContext;
		} else if (this.beanO != null) {
			if (this.beanO.home != null) {
				if (this.beanO instanceof StatefulBeanO) {
					jpaContext = ((StatefulBeanO) this.beanO).ivExPcContext;
				}
			} else if (this.ivWrapper.bmd.isStatefulSessionBean() && this.ivCallerContext != null) {
				jpaContext = this.ivCallerContext.getExPcBindingContext();
			}
		}

		return jpaContext;
	}

	public boolean isTxEnlistNeededForActivate() {
		return this.uowCtrlPreInvoked;
	}
}