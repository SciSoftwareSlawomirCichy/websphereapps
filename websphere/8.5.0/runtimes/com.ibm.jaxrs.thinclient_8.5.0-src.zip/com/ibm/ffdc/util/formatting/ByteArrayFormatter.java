package com.ibm.ffdc.util.formatting;

import com.ibm.ffdc.config.Formatter;
import com.ibm.ffdc.config.IncidentStream;
import com.ibm.ffdc.config.IncidentStream.Writer;
import com.ibm.ffdc.util.Klass;
import com.ibm.ffdc.util.formatting.ByteArrayFormatter.1;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Array;

public class ByteArrayFormatter implements Formatter {
	int COLUMN_BYTES = 4;
	int COLUMN_TOTAL = 4;
	private static final String DEAD_CHAR = ".";
	char[] hexChars = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

	public final void formatTo(Object o, IncidentStream is) {
      Class<?> cl = o.getClass();
      Class<?> componentType = cl.getComponentType();
      if (componentType == null) {
         throw new IllegalArgumentException();
      } else if (Klass.isByte(componentType)) {
         Writer<OutputStream> writer = new 1(this, o);
         is.write(writer);
      } else {
         this.formatTo(is, o);
      }
   }

	private void formatTo(PrintWriter pw, Object objectToFormat) {
		int length = Array.getLength(objectToFormat);
		byte[] bytes = new byte[length];
		StringBuffer sb = new StringBuffer();
		int charCount = 0;
		pw.print('[');
		this.printColumnHeadings(pw);

		for (int i = 0; i < length; ++i) {
			byte o = Array.getByte(objectToFormat, i);
			bytes[i] = o;
			String charString = pad(Integer.toHexString(o), 2);
			String tempString;
			if (!charString.equalsIgnoreCase("00") && !charString.equalsIgnoreCase("09")
					&& !charString.equalsIgnoreCase("0a") && !charString.equalsIgnoreCase("0b")
					&& !charString.equalsIgnoreCase("0c") && !charString.equalsIgnoreCase("0d")
					&& !charString.equalsIgnoreCase("07")) {
				tempString = new String(bytes, i, 1);
			} else {
				tempString = ".";
			}

			if (i % this.COLUMN_BYTES == 0) {
				pw.print(" ");
				if (i % (this.COLUMN_BYTES * this.COLUMN_TOTAL) == 0) {
					if (i != 0) {
						pw.print("| " + sb.toString());
						pw.print("\n");
						pw.print(" ");
						sb.delete(0, sb.length());
						charCount = 0;
					}

					pw.print("0x" + pad(Integer.toHexString(i), 8) + " (" + pad(Integer.valueOf(i).toString(), 8, " ")
							+ ") : ");
				}

				++charCount;
			}

			sb.append(tempString);
			pw.print(this.hexChars[o >> 4 & 15]);
			pw.print(this.hexChars[o & 15]);
			charCount += 2;
			if (length - i == 1) {
				for (int padding = charCount; padding < 2 * this.COLUMN_TOTAL * this.COLUMN_BYTES
						+ this.COLUMN_TOTAL; ++padding) {
					pw.print(" ");
				}

				pw.print(" | ");
				pw.print(sb.toString());
			}
		}

		pw.print(']');
		pw.println();
	}

	private void formatTo(IncidentStream is, Object objectToFormat) {
		int alength = Array.getLength(objectToFormat);
		is.write((String) null, '[');

		for (int i = 0; i < alength; ++i) {
			Object o = Array.get(objectToFormat, i);
			is.write((String) null, o);
		}

		is.write((String) null, ']');
	}

	public String[] getSupportedTypeNames() {
		return new String[]{"[.*"};
	}

	public boolean isSupported(Class<?> klass) {
		return klass.isArray() ? klass.getComponentType().equals(Byte.TYPE) : false;
	}

	public void printColumnHeadings(PrintWriter pw) {
		char[] hexChars = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
		pw.print("        offset        : ");
		int c = 0;

		int h;
		for (h = 0; c < this.COLUMN_BYTES * this.COLUMN_TOTAL; ++h) {
			if (c % this.COLUMN_BYTES == 0 && c != 0) {
				pw.print(" ");
			}

			if (h == hexChars.length) {
				h = 0;
			}

			pw.print(hexChars[h] + " ");
			++c;
		}

		pw.print("   ");
		c = 0;

		for (h = 0; c < this.COLUMN_BYTES * this.COLUMN_TOTAL / 2; h += 2) {
			if (h >= hexChars.length) {
				h = 0;
			}

			pw.print(hexChars[h] + " ");
			++c;
		}

		pw.print("\n");
	}

	private static String pad(String s, int l) {
		return pad(s, l, (String) null);
	}

	private static String pad(String s, int l, String p) {
		if (p == null) {
			p = "0";
		}

		String rc;
		if (s.length() < l) {
			StringBuffer sb = new StringBuffer();

			for (int i = 0; i < l - s.length(); ++i) {
				sb.append(p);
			}

			rc = sb.toString() + s;
		} else {
			rc = s.substring(s.length() - l);
		}

		return rc;
	}
}