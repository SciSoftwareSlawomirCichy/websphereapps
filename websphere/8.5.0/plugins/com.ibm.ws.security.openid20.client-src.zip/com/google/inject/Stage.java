package com.google.inject;

public enum Stage {
	TOOL, DEVELOPMENT, PRODUCTION;
}