package javax.ws.rs.core;

import javax.ws.rs.ext.RuntimeDelegate;
import javax.ws.rs.ext.RuntimeDelegate.HeaderDelegate;

public class Cookie {
	public static final int DEFAULT_VERSION = 1;
	private final String name;
	private final String value;
	private final String path;
	private final String domain;
	private final int version;
	private static final HeaderDelegate<Cookie> headerDelegate = RuntimeDelegate.getInstance()
			.createHeaderDelegate(Cookie.class);

	public Cookie(String name, String value) {
		this(name, value, (String) null, (String) null);
	}

	public Cookie(String name, String value, String path, String domain) {
		this(name, value, path, domain, 1);
	}

	public Cookie(String name, String value, String path, String domain, int version) {
		if (name == null) {
			throw new IllegalArgumentException();
		} else {
			this.name = name;
			this.value = value;
			this.path = path;
			this.domain = domain;
			this.version = version;
		}
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		} else if (obj == null) {
			return false;
		} else if (this.getClass() != obj.getClass()) {
			return false;
		} else {
			Cookie other = (Cookie) obj;
			if (!this.name.equals(other.name)) {
				return false;
			} else if (this.version != other.version) {
				return false;
			} else {
				if (this.value == null) {
					if (other.value != null) {
						return false;
					}
				} else if (!this.value.equals(other.value)) {
					return false;
				}

				if (this.path == null) {
					if (other.path != null) {
						return false;
					}
				} else if (!this.path.equals(other.path)) {
					return false;
				}

				if (this.domain == null) {
					if (other.domain != null) {
						return false;
					}
				} else if (!this.domain.equals(other.domain)) {
					return false;
				}

				return true;
			}
		}
	}

	public int hashCode() {
		int result = 17;
		int result = 31 * result + this.name.hashCode();
		result = 31 * result + (this.value == null ? 0 : this.value.hashCode());
		result = 31 * result + (this.path == null ? 0 : this.path.hashCode());
		result = 31 * result + (this.domain == null ? 0 : this.domain.hashCode());
		result = 31 * result + this.version;
		return result;
	}

	public String getDomain() {
		return this.domain;
	}

	public String getName() {
		return this.name;
	}

	public String getPath() {
		return this.path;
	}

	public String getValue() {
		return this.value;
	}

	public int getVersion() {
		return this.version;
	}

	public String toString() {
		return headerDelegate.toString(this);
	}

	public static Cookie valueOf(String value) {
		return (Cookie) headerDelegate.fromString(value);
	}
}