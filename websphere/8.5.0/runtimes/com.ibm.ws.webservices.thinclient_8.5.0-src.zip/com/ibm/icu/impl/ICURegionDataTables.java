package com.ibm.icu.impl;

import com.ibm.icu.impl.LocaleDisplayNamesImpl.ICUDataTables;

public class ICURegionDataTables extends ICUDataTables {
	public ICURegionDataTables() {
		super("com/ibm/icu/impl/data/icudt44b/region");
	}
}